<?php

global $lang;

$lang['en_US']['RecaptchaField']['EMPTY'] = array(
	'Please answer the captcha question',
	PR_MEDIUM,
	'Recaptcha (http://recaptcha.net) provides two words in an image, and expects a user to type them in a textfield'
);
$lang['en_US']['RecaptchaField']['VALIDSOLUTION'] = array(
	'Your answer didn\'t match the captcha words, please try again',
	PR_MEDIUM,
	'Recaptcha (http://recaptcha.net) provides two words in an image, and expects a user to type them in a textfield'
);

?>