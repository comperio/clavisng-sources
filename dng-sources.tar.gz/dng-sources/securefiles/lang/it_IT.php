<?php
/**
 * Italian language pack
 * @package securefiles
 * @subpackage i18n
 */
global $lang;

$lang['it_IT']['SecureFiles']['SECUREFILEACCESS'] = 'Accesso ai file protetti';
$lang['it_IT']['SecureFiles']['SECUREFILESETTINGS'] = 'Gestione delle impostazioni dei file protetti';
$lang['it_IT']['SecureFiles']['SECUREFILETABNAME'] = 'Protezione';
$lang['it_IT']['SecureFiles']['INHERITED'] = 'Questa cartella eredita le impostazioni di protezione dalla cartella madre.';
$lang['it_IT']['SecureFiles']['SECUREFOLDER'] = 'La cartella è protetta.';
$lang['it_IT']['SecureFiles']['FOLDERSECURITY'] = 'Protezione della cartella';
$lang['it_IT']['SecureFiles']['NONE'] = '(Nessuna)';
$lang['it_IT']['SecureFiles']['NEVEREXPIRES'] =  'Mai';

// GROUP PERMISSION
$lang['it_IT']['SecureFiles']['GROUPACCESSTITLE'] = 'Accesso di gruppo';
$lang['it_IT']['SecureFiles']['GROUPACCESSFIELD'] = 'Permessi di accesso di gruppo';
$lang['it_IT']['SecureFiles']['GROUPINHERITEDPERMS'] = 'Eredita i permessi di gruppo';

// MEMBER PERMISSOIN
$lang['it_IT']['SecureFiles']['MEMBERACCESSTITLE'] = 'Accesso Utente';
$lang['it_IT']['SecureFiles']['MEMBERINHERITEDPERMS'] = 'Eredita i permessi Utente';

// TOKEN PERMISSION
$lang['it_IT']['SecureFiles']['TOKENACCESSTITLE'] = 'Accesso via Token';
$lang['it_IT']['SecureFiles']['NOFILESINFOLDER'] = 'Non vi sono file in questa cartella.';
