<?php
/**
 * Classes that implement TestOnly are only to be used during testing
 * @package sapphire
 * @subpackage testing
 */
interface TestOnly {

}

?>