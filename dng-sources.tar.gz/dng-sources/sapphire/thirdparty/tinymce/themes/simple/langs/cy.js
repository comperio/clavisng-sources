tinyMCE.addI18n('cy.simple',{
bold_desc:"Trwm (Ctrl+B)",
italic_desc:"Italig (Ctrl+I)",
underline_desc:"Tanlinellu (Ctrl+U)",
striketrough_desc:"Taro drwodd",
bullist_desc:"Rhestr didrenus",
numlist_desc:"Rhestr trenus",
undo_desc:"Dadwneud (Ctrl+Z)",
redo_desc:"Ailwneud (Ctrl+Y)",
cleanup_desc:"Glanhau c\u00F4d anhrefnus"
});