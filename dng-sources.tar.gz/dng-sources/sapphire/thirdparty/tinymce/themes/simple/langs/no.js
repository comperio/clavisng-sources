tinyMCE.addI18n('no.simple',{
bold_desc:"Fet",
italic_desc:"Kursiv",
underline_desc:"Understrek",
striketrough_desc:"Gjennomstrek",
bullist_desc:"Punktliste",
numlist_desc:"Nummerliste",
undo_desc:"Angre",
redo_desc:"Gj\u00F8r om",
cleanup_desc:"Rens grisete kode"
});