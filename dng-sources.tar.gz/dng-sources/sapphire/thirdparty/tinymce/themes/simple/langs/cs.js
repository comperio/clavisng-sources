tinyMCE.addI18n('cs.simple',{
bold_desc:"Tu\u010Dn\u00E9 (Ctrl+B)",
italic_desc:"Kurz\u00EDva (Ctrl+I)",
underline_desc:"Podtr\u017Een\u00E9 (Ctrl+U)",
striketrough_desc:"P\u0159e\u0161krtnut\u00E9",
bullist_desc:"Seznam s odr\u00E1\u017Ekami",
numlist_desc:"\u010C\u00EDslovan\u00FD seznam",
undo_desc:"Zp\u011Bt (Ctrl+Z)",
redo_desc:"Znovu (Ctrl+Y)",
cleanup_desc:"Vy\u010Distit k\u00F3d"
});