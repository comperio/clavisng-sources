<?php
require_once 'HTML/HTMLBBCodeParser.php';

/**
 * Dummy class that filters need to extend from.
 * @package  sapphire
 * @subpackage misc
 */
class SSHTMLBBCodeParser_Filter extends SSHTMLBBCodeParser
{
}
?>