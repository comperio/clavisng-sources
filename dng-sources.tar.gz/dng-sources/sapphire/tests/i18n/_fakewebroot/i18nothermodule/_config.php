<?php
Object::extend('i18nTestModule', 'i18nTestModuleDecorator');
?>