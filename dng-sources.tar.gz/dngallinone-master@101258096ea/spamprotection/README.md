# SpamProtection Module

## Maintainer Contact

 * Saophalkun Ponlu
   <phalkunz (at) silverstripe (dot) com>

 * Will Rossiter
   <will (at) silverstripe (dot) com>

## Requirements

SilverStripe 2.3.2 or greater

## Documentation

http://doc.silverstripe.org/modules:spamprotection

## Installation Instructions

See docs/Install

## Usage Overview

See docs/Install

## Known issues
