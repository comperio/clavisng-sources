<?php

global $lang;

$lang['en_US']['EditableSpamProtectionField']['PLURALNAME'] = array(
	'Spam Protection Fields',
	50,
	'Pural name of the object, used in dropdowns and to generally identify a collection of this object in the interface'
);
$lang['en_US']['EditableSpamProtectionField']['SINGULARNAME'] = array(
	'Spam Protection Field',
	50,
	'Singular name of the object, used in dropdowns and to generally identify a single object in the interface'
);

?>