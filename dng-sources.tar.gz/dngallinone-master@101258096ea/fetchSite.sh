#!/bin/bash
#
# Usage:
# ./fetchSite.sh [-u ssh-username] server site
# Result:
# Copy the /var/www/dng-multisite/sites/site directory to sites/site, and rewrite "localhost" occurrences in "server"
#
USERNAME="root"

while getopts "u:" opt; do
  case "$opt" in
    u)
      USERNAME=$OPTARG
      ;;
    \?)
      echo "Invalid option: -$OPTARG" >&2
      ;;
  esac
done
shift $(( OPTIND -1 ))

if [ ! -d "sites/$2" ]; then
    # Control will enter here if $DIRECTORY exists.
    mkdir sites/$2
    rsync -av --exclude assets --exclude silverstripe-cache --exclude */.svn ${USERNAME}@$1:/var/www/dng-multisite/sites/$2 sites
    #sed -i "" 's/http:\/\/localhost/http:\/\/${1}/g' sites/$2/*.php
    sed -i "" "s/http:\/\/localhost/http:\/\/${1}/g" sites/$2/*.yml
    sed -i "" "s/http:\/\/127\.0\.0\.1/http:\/\/${1}/g" sites/$2/*.yml
    mkdir sites/$2/assets
    mkdir sites/$2/silverstripe-cache
    chmod -R 777 sites/$2
else
    echo "Error: The site directory sites/$2 already exists."
fi
