<?php
/**
 * This file is part of dng
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

/**
 * Class NewRelicDecorator
 *
 * Decorate Content class using onAfterInit hook
 */
class NewRelicDecorator extends Extension
{
    public function onAfterInit()
    {
        if (extension_loaded('newrelic')) {
            global $dngSite;
            $member = Member::currentUser();
            newrelic_set_appname ("DNG - $dngSite");
            newrelic_name_transaction(get_class($this->owner));
            if ($member)
                newrelic_add_custom_parameter('MemberID', $member->ID);

            //newrelic RUM headers and footers
            Page_Controller::$inHeader[] = newrelic_get_browser_timing_header();
            Page_Controller::$inFooter[] = newrelic_get_browser_timing_footer();
        }
    }
}