### DNG - The Social OPAC
For informations visit the project homepage at
http://www.comperio.it/soluzioni/discoveryng/panoramica/
