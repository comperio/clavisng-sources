<?php
class i18nOtherModule extends Object {
	function mymethod() {
		_t(
			'i18nOtherModule.ENTITY', 
			'Other Module Entity'
		);
	}
}
?>