tinyMCE.addI18n('de.tinymce_ssbuttons',{
insertlink: 'Link einfügen',
insertimage: 'Bild einfügen',
insertflash: 'Flash Objekt einfügen'
});