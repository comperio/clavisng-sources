tinyMCE.addI18n('nl.tinymce_ssbuttons', {
insertlink: 'Link Invoegen',
insertimage: 'Afbeelding invoegen',
insertflash: 'Flash Object invoegen'
});