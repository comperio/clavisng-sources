tinyMCE.addI18n('it.tinymce_ssbuttons', {
insertlink: 'Inserisci Link',
insertimage: 'Inserisci Immagine',
insertflash: 'Inserisci Oggetto Flash'
});