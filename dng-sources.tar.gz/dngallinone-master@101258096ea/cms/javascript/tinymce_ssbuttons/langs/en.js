tinyMCE.addI18n('en.tinymce_ssbuttons', {
insertlink: 'Insert Link',
insertimage: 'Insert Image',
insertflash: 'Insert Flash Object'
});