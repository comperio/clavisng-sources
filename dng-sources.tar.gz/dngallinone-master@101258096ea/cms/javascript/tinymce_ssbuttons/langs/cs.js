tinyMCE.addI18n('cs.tinymce_ssbuttons', {
insertlink: 'Vložit odkaz',
insertimage: 'Vložit obrázek',
insertflash: 'Vložit Flash animaci'
});