# SilverStripe CMS

This is a fork of the 2.4.x branch of [SilverStripe CMS](http://github.com/silverstripe/silverstripe-cms)
used by the OPAC software [DiscoveryNG](http://www.comperio.it/soluzioni/discoveryng/panoramica/).

Changes are mainly little fixes and small tweaks.
