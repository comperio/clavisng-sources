# Tests #

Given I click on the "Tab Name" tab
Given I close window and go back to clean state
Given I fill out the log in form with user "user" and password "password"
Given I get a permission denied error
Given I go to the draft site
Given I log in as Fred
Given I log in as user
Given I log into the CMS as Fred@example.com
Given I log out
Given I visit admin/security
Given I wait for a status message
Given I wait for a success message
Given a "Blog" page called "News" as a child of "Blogs"
Given a "Publishers" group
Given a top-level "BlogPage" page called "News"
Given a user called "Fred" in the "Authors" group
Given the "News" page can be edited by the "Publishers" group
Given the site can be edited by the "Publishers" group
