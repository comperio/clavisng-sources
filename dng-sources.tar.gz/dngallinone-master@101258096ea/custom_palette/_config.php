<?php

define('COLORPALETTE_PATH', __DIR__);
define('COLORPALETTE_DIR', basename(__DIR__));
