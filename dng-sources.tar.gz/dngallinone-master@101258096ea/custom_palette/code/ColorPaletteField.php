<?php

class ColorPaletteField extends DropdownField {

    public function Field($properties = array()) {
        Requirements::css(COLORPALETTE_DIR . '/css/PaletteField.css');

        $options = '';
        $odd = 0;
        $colors = $this->getSource();
        $id = $this->id();

        foreach ($colors as $hex => $color) {
            $checked = ($hex == $this->value) ? ' checked="checked" ' : '';
            $itemID = $id . "_" . preg_replace('#[^a-zA-Z0-9]+#', '', $color);
            $odd = ($odd + 1) % 2;
            $extraClass = $odd ? "odd" : "even";
            $extraClass .= " val" . preg_replace('/[^a-zA-Z0-9\-\_]/', '_', $color);
            $options .= '<li class="' . $extraClass . '">'
                    . '<input id="' . $itemID . '" name="' . $this->name . '" type="radio" value="' . $hex . '"' . $checked  . 'class="radio" />'
                    . '<label for="' . $itemID . '" style="background-color: ' . $hex . '"></label>'
                    . '</li>';
        }
        
        return '<ul id="' . $id . '" class="optionset ' . $extraClass . '">' . $options . '</ul>';

    }

}
