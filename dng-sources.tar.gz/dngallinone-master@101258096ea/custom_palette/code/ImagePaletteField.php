<?php

class ImagePaletteField extends DropdownField {

    function __construct($name, $title = null, $source = array(), $value = "", $form = null, $emptyString = null, $motherFolder = null, $resolution = null) {
        $this->motherFolder = $motherFolder;
        $this->resolution = !is_null($resolution) ? $resolution : "50x50";
        parent::__construct($name, $title, $source, $value, $form, $emptyString);
    }

    public function Field($properties = array()) {
        Requirements::css(COLORPALETTE_DIR . '/css/ColorPaletteField.css');

        $bannerFolderID = DB::query("SELECT `ID` FROM `File` WHERE `ClassName` = 'Folder' AND `Title` = 'Pattern';")->value();
        $html = "Nessuna palette disponibile!";

        if (!is_null($bannerFolderID)) {
            $bannerImages = File::get("File", " ParentID = " . $bannerFolderID);
            $options = '';
            $odd = 0;
            $id = $this->id();

            foreach ($bannerImages as $image) {
                $checked = ($image->ID == $this->value) ? ' checked="checked" ' : '';
                $itemID = $id . "_" . preg_replace('#[^a-zA-Z0-9]+#', '', $image->Name);
                $odd = ($odd + 1) % 2;
                $extraClass = $odd ? "odd" : "even";
                $extraClass .= " val" . preg_replace('/[^a-zA-Z0-9\-\_]/', '_', $image->Name);
                
                list($width, $height) = getimagesize(Director::absoluteBaseURL()."/".$image->Filename);
                list($w, $h) = explode("x", $this->resolution);
                if ($width > $height)
                    $h = $w / ($width / $height);
                if ($width < $height)
                    $w = $h / ($height / $width);

                $options .= '<li class="' . $extraClass . '">'
                        . '<label>'
                        . '<input id="' . $itemID . '" name="' . $this->name . '" type="radio" value="' . $image->ID . '"' . $checked . 'class="radio" />'
                        . '<img src="' . $image->Filename . '" alt="' . $image->Title . '" style="width:' . $w . 'px; height:' . $h . 'px;" />'
                        . '</label>'
                        . '</li>';
            }
            $html = '<ul id="' . $id . '" class="optionset ' . $extraClass . '">' . $options . '</ul>';
        }
        
        return $html;
    }

}
