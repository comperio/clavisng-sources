<?php

/* HTTPS DA ESTERNO, HTTP PER NGINX */
if(isset($_SERVER['HTTP_X_FORWARDED_PROTO'])) {
    if($_SERVER['HTTP_X_FORWARDED_PROTO'] == "https") {
        $_SERVER['HTTPS'] = "on";
        $_SERVER['REMOTE_ADDR'] = $_SERVER['HTTP_X_REAL_IP'];
        $_SERVER['SERVER_PORT'] = $_SERVER['HTTP_X_FORWARDED_PORT'];
        $_SERVER['REQUEST_SCHEME'] = "https";
    }
}

// Fix error reporting for php 5.4
error_reporting(E_ALL & ~(E_DEPRECATED | E_STRICT | E_NOTICE));

/**
 * Handle maintenance mode.
 * Maintenance mode is enabled by the presence of a file named "maintenance-enabled".
 * Create it to activate maintenance mode, or delete it to deactivate.
 * Administrators can bypass the maintenance mode setting a cookie named "bypass-maintenance"
 */

if (php_sapi_name() != "cli" && file_exists(__DIR__.DIRECTORY_SEPARATOR.'maintenance-enabled')){
    if(! isset($_COOKIE['dng-bypass-maintenance']) && php_sapi_name() != "cli"){
        $protocol = $_SERVER["SERVER_PROTOCOL"];
        if (('HTTP/1.1' != $protocol) && ('HTTP/1.0' != $protocol)) { $protocol = 'HTTP/1.0'; }
        header( "$protocol 503 Service Unavailable", true, 503 );
        header( 'Content-Type: text/html; charset=utf-8' );
        header( 'Retry-After: 600' );
        include 'maintenance.html';
        exit;
    }
}

include '_ss_environment_conf.php';

/**
 * Handling of forceDevMode
 */
global $forceDevMode, $forceDevModeSecret;
$forceDevMode = false;
if(isset($_COOKIE['dng-force-dev'])){
    if ($forceDevModeSecret && $_COOKIE['dng-force-dev'] == $forceDevModeSecret){
        $forceDevMode = true;
    }
}

/**
 * Multisite handling
 */
global $dngSite;

$dngSite = include 'sites/_map_request_to_site.php';

if (!$dngSite || !file_exists(__DIR__."/sites/$dngSite")) {
        $protocol = $_SERVER["SERVER_PROTOCOL"];
        if (('HTTP/1.1' != $protocol) && ('HTTP/1.0' != $protocol)) { $protocol = 'HTTP/1.0'; }
        header( "$protocol 404 Page Not Found", true, 404 );
        header( 'Content-Type: text/html; charset=utf-8' );
        echo 'Site not available';
        exit;
}

/**
 * Gestione maintenance su singolo site (modificare .htaccess)
 */
if ((isset($_SERVER["HTTP_X_DNG_MAINTENANCE"]) && ($_SERVER["HTTP_X_DNG_MAINTENANCE"]) != "")) {
    $sites = explode(",",$_SERVER["HTTP_X_DNG_MAINTENANCE"]);
    if (in_array($dngSite, $sites)) {
        if(! isset($_COOKIE['dng-bypass-maintenance']) && php_sapi_name() != "cli"){
            $protocol = $_SERVER["SERVER_PROTOCOL"];
            if (('HTTP/1.1' != $protocol) && ('HTTP/1.0' != $protocol)) { $protocol = 'HTTP/1.0'; }
            header( "$protocol 503 Service Unavailable", true, 503 );
            header( 'Content-Type: text/html; charset=utf-8' );
            header( 'Retry-After: 600' );
            include 'maintenance.html';
            exit;
        }
    }
}

define('ASSETS_DIR', "sites/$dngSite/assets");
define('TEMP_FOLDER', __DIR__."/sites/$dngSite/silverstripe-cache");