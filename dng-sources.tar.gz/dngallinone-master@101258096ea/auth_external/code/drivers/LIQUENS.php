<?php

class LIQUENS_Authenticator {

	public static $webservice_url;

    /**
     * Token to use in SOAP sessions
     * @var string
     */
    private static $auth_token = ''; // token to use in SOAP clavis dialog

	/**
     * Tries to find the anchor for a given mail address and source
     *
     * @access public
     *
     * @param string $source          The Authentication source to be used
     * @param string $mailaddr        The mail address entered
     *
     * @return mixed    Anchor as string or false if not found
     **/
    public function getAnchor($source, $mailaddr) {
        ExternalAuthenticator::AuthLog($mailaddr.'.liquens - Anchor lookup not supported by source ' . $source);
        return false;
    }

	/**
     * Tries to logon versus a Clavis connection with given id and password
     *
     * @access public
     *
     * @param string $source          The Authentication source to be used
     * @param string $external_uid    The username entered
     * @param string $external_passwd The password of the user
     *
     * @return mixed    Account details if succesful , false if not
     */
    public function Authenticate($source, $external_uid, $external_passwd) {
        // format $username e $password
        if (!$external_uid) {
            ExternalAuthenticator::AuthLog($external_uid.'.liquens - Error, username is blank.');
			return false;
        }
        if (!$external_passwd) {
            ExternalAuthenticator::AuthLog($external_uid.'.liquens - Error, password is blank.');
			return false;
        }
		// get liquens connector, auth user and retrieve data.
		ExternalAuthenticator::AuthLog($external_uid.'.liquens - Searching for user with liquens connector.');
        global $sc;
        $connector = $sc->get('liquens.connector');
		$success = $connector->loginUser($external_uid, $external_passwd);
		if (!$success) {
			ExternalAuthenticator::AuthLog($external_uid.'.liquens - Authentication failed.');
			return false;
		}
		$userdata = $connector->getUserData($external_uid);
		return $userdata;
	}
}
