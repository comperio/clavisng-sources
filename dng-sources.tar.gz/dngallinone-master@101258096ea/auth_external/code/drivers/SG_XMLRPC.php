<?php

require Director::baseFolder().'/auth_external/com_libs/xmlrpc/xmlrpc.inc';
require Director::baseFolder().'/auth_external/com_libs/xmlrpc/xmlrpcs.inc';
require Director::baseFolder().'/auth_external/com_libs/xmlrpc/xmlrpc_wrappers.inc';

/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
class SG_XMLRPC_Authenticator {

    protected static $auth_token = ''; // token to use in XMLRPC dialog
    protected static $xmlrpc_server_url = 'http://www.sangiorgio.comune.pistoia.it/xmlrpc/comXmlRpc.php';
    protected static $com_token='xxxPolipoIgnaro';
    public static $SgGroupTitle='Gruppo San Giorgio';
    public static $SgGroupCode='gruppo-san-giorgio';

    /**
     * Authenticate a Opac User (Parton or Librarian) versus Clavis
     * 
     * @param string $source
     * @param string $username
     * @param string $passwd
     *
     * @return boolean  True if the authentication was a success, false
     *                  otherwise
     */
    public function Authenticate($source='', $username=null, $passwd=null){
        // check source
        if($this->sourceExist($source)===false) return false;
        // format $username e $password
        if(is_null($username) || $username==''){
            ExternalAuthenticator::AuthLog(_t('ExternalAuthenticator.FailedUsernameBlank', "Username can't be blank!"));
            ExternalAuthenticator::setAuthMessage('Login failed: Username is blank');
        }
        if(is_null($passwd) || $passwd==''){
            ExternalAuthenticator::AuthLog(_t('ExternalAuthenticator.FailedPasswordBlank', "Password can't be blank!"));
            ExternalAuthenticator::setAuthMessage('Login failed: Password is blank');
        }
        // call soap methods
            // retrive user data
            // OR return an error or false

        // call checkInMember
            // YES continue
            // NO create: call addClavisMember,addClavisMemberToGroup

        return true;
    }

    /**
     * Check if source exists in  Authenticator list.
     * @param string $source
     * @return boolean
     */
    public function sourceExist($source){
        $source_exist=false;
        $ext_sources=ExternalAuthenticator::getSources();
        foreach($ext_sources as $k=>$v){
            if($v==$source){
                $source_exist=true;
                //Debug::message($v);
                break;
            }
        }
        return $source_exist;
    }

    /* SOAP DIALOG */

    /**
     * Test method ( !!! Preproduction only !!! )
     * @param string $username
     * @param string $pass
     * @return array (user data)
     */
    public function retriveUserData($username,$pass){
        $client=$this->getXmlRpcClient();
        Debug::message(" DA RETRIVE USER ".$username." ".$pass);
        $retStruct = new xmlrpcval(
            array(
                "email" => new xmlrpcval($username, 'string'),
                "passwd" => new xmlrpcval($pass, 'string'),
                //"token" => new xmlrpcval($com_token, 'string'),
            ),
            "struct"
        );
        $m=new xmlrpcmsg('comperio.retriveMemberData',array($retStruct));
        $r=$client->send($m);
        if (!$r->faultCode()) {
            //while (list($key, $v) = $v->structEach())
            //{
            //    echo "Element $key of the struct is of type ".$v->kindOf();
            //}
            //print_r($r->value());
            //die;
          return $r->value();
        }else{
             $err="Fault <BR>";
            $err.="Code: " . htmlentities($r->faultCode()) . "<BR>" .
            $err.="Reason: '" . htmlentities($r->faultString()) . "'<BR>";

            return $err;
        }
    }

     /**
     * Define the Soap Client for CLAVIS o BOOKMARKWEB
     * @param string $library_id
     * @return soap client or null
     */
    public function getXmlRpcClient()
    {
        $client = new xmlrpc_client(self::$xmlrpc_server_url);        
        return $client;
    }

    public function getConsortiaWebService(){
        // query to SiteConfig (?)
    }

    /* END SOAP DIALOG */








    /* MEMBERS AND GROUPS */







    public function checkInMember(){
        $NewMember=new Member();

    }

    public function addClavisMember($SQL_memberdata=array()){
        if(is_array($SQL_memberdata) && count($SQL_memberdata)){
            $member = new Member;
            $member->update($SQL_memberdata);
            $member->ID = null;
            if($member->write()){
                return $member;
            }
        }
        return null;
    }

    public function checkInGroup(){

    }

    public function addClavisGroup(){

    }

    public function addClavisMemberToGroup(){

    }

    public function getClavisLibraryConsortia(){

    }

    public function getClavisLibrary(){

    }

    public function getClavisGroupMembers(){
        // the same of (?):
        //$group=new Group($record, $isSingleton);
        //$group->Members();
    }

    public function memberIsPatron($member=null){
        $group='clavis'; // @TODO: set to clavis_patron
        if(!is_null($member) && ($member instanceof Member)){
            if($member->inGroup($group)){
                return true;
            }
        }
        return false;
    }

    public function memberIsLibrarian($member=null){
        $group='clavis_librarian';
        if(!is_null($member) && ($member instanceof Member)){
            if($member->inGroup($group)){
                return true;
            }
        }
        return false;
    }


}
?>
