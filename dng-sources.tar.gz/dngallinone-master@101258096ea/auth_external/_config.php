<?php

/**
 * See the docs directory for configuration examples
 * */
//Authenticator::unregister_authenticator('MemberAuthenticator');

Authenticator::register_authenticator('ExternalAuthenticator');
ExternalAuthenticator::createSource('liquens', 'LIQUENS', 'Liquens authenticator');
ExternalAuthenticator::setUseAnchor(true);
ExternalAuthenticator::setAnchorDesc('Username');
ExternalAuthenticator::setAutoAdd('liquens', array(
    'patron' => 'patron',
    'sitemaster' => 'sitemaster',
    'webmaster' => 'webmaster'));

//Allow different users with same Email
ExternalAuthenticator::$merge_on_same_email = false;
