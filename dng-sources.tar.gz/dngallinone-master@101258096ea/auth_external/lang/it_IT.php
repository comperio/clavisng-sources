<?php

global $lang;

$lang['it_IT']['ExternalAuthenticator']['ModFormHead'] = 'ID della sorgente di autenticazione esterna';
$lang['it_IT']['ExternalAuthenticator']['EnterUser'] = 'Inserisci l\'ID dell\'utente e la sua sorgente di autenticazione';
$lang['it_IT']['ExternalAuthenticator']['EnterNewId'] = 'Inserisci il nuovo ID utilizzato per questa sorgente';
$lang['it_IT']['ExternalAuthenticator']['UserExists'] = 'Esiste gi&agrave; un utente con queste credenziali';
$lang['it_IT']['ExternalAuthenticator']['Failed'] = 'Autenticazione fallita';
$lang['it_IT']['ExternalAuthenticator']['EnterUID'] = 'Si prega di inserire un %s';
$lang['it_IT']['ExternalAuthenticator']['MailAddr'] = 'Indirizzo e-Mail';
$lang['it_IT']['ExternalAuthenticator']['EnterMailAddr'] = 'Si prega di inserire un indirizzo e-Mail';
$lang['it_IT']['ExternalAuthenticator']['GroupExists'] = 'Esistono gi&agrave; delle credenziali con il tuo indirizzo e-Mail';
$lang['it_IT']['ExternalAuthenticator']['Title'] = 'Accesso da sorgente esterna';
$lang['it_IT']['ExternalAuthenticator']['LogOutIn'] = 'Entra come qualcun altro';
$lang['it_IT']['ExternalAuthenticator']['Password'] = 'Password';
$lang['it_IT']['ExternalAuthenticator']['Remember'] = 'Devo ricordarmi di te?';
$lang['it_IT']['ExternalAuthenticator']['Sources'] = 'Sorgente di autenticazione';
$lang['it_IT']['ExternalAuthenticator']['Login'] = 'Log in';
$lang['it_IT']['ExternalAuthenticator']['LogFailed'] = 'Scrittura dell\'operazione di logging sul file di debug fallita';
$lang['it_IT']['ExternalAuthenticator']['FailedUsernameBlank'] = 'Lo username non deve essere vuoto.';
$lang['it_IT']['ExternalAuthenticator']['FailedPasswordBlank'] = 'La password non deve ssere vuota.';
$lang['it_IT']['FTP_Authenticator']['NoConnect'] = 'Non &egrave; possibile connettersi al server FTP';
$lang['it_IT']['IMAP_Authenticator']['Protocol'] = 'Il protocollo non &egrave; impostato ad un tipo valido';
$lang['it_IT']['LDAP_Authenticator']['NotConnected'] = 'Collegamento con il server LDAP fallito.';
$lang['it_IT']['LDAP_Authenticator']['Version'] = 'Impostazione della versione del protocollo LDAP a %d  &egrave; fallito.';
$lang['it_IT']['LDAP_Authenticator']['TLS'] = 'Avvio del TLS fallito: [%d] %s';
$lang['it_IT']['LDAP_Authenticator']['NoBind'] = 'Non &egrave; possibile entrare in collegamento al server LDAP.';
$lang['it_IT']['LDAP_Authenticator']['NoPasswd'] = 'Si prega di inserire una password';
$lang['it_IT']['LDAP_Authenticator']['Expired'] = 'La tua password &egrave; scaduta';
$lang['it_IT']['LDAP_Authenticator']['WillExpire'] = 'La tua password scadr&agrave; fra %d giorni.';
