module.exports = function(grunt) {
  // Load plugins
  require('load-grunt-tasks')(grunt);
  var options = {
      serveruser: grunt.option('server-user') || 'www-data',
      servergroup: grunt.option('server-group') || grunt.option('server-user') || 'www-data',
      site: grunt.option('site') || 'site',
      theme: grunt.option('theme') || 'dng',
      version: grunt.option('dngversion') || '0.0.0'
  };
  

  // Project configuration.
  grunt.initConfig({
    pkg: grunt.file.readJSON('package.json'),
    options: options,
    requirejs: {
      compile: {
        options: {
          appDir: 'liquens/javascript',
          baseUrl: '.',
          dir: "liquens/javascript-built",
          mainConfigFile: 'liquens/javascript/config.js',
          optimize: "uglify2",
          generateSourceMaps: true,
          preserveLicenseComments: false,
          findNestedDependencies: true,
          modules: [
                  {
                      name: "./common",
                      include: ["../../bower_components/requirejs/require.js"]
                  },
                  {
                      name: "./empty",
                      exclude: ["./common"]
                  },
                  {
                      name: "./advancedsearch",
                      exclude: ["./common"]
                  },
                  {
                      name: "./events",
                      exclude: ["./common"]
                  },
                  {
                      name: "./librarieslist",
                      exclude: ["./common"]
                  },
                  {
                      //include: ["jquery-colorbox", "dng-datatables"],
                      name: "./manifestation",
                      exclude: ["./common"]
                  },
                  {
                      name: "./mydiscovery",
                      //include: ["dng-datatables", "dng-contacts", "dng-loans"],
                      exclude: ["./common"]
                  },
                  {
                      name: "./resultpage",
                      exclude: ["./common"]
                  },
                  {
                      name: "./timetable",
                      exclude: ["./common"]
                  }
              ]
        }
      }
    },
    watch: {
      less: {
        files: 'liquens/css/less/*.less',
        tasks: ['less:dev'],
        options: {
          interrupt : true
        }
      },
      livereload: {
	      options: { livereload: true },
	      files: ["themes/dng/css/theme.css"]
	    },
      templates: {
        options: { livereload: true },
        files: ['liquens/templates/*.ss','liquens/templates/**/*.ss']
      },
      javascript: {
      	files: ['liquens/javascript/*.js', 'liquens/javascript/**/*.js'],
      	tasks: ['requirejs:compile']
      }
    },
    less: {
      dev: {
        options: {
          sourceMap: true,
          sourceMapRootpath: '../../../'
        },
        files: {
          "themes/dng/css/theme.css": "liquens/css/less/liquens.less"
        }
      },
      cms: {
        options: {
          sourceMap: true,
          sourceMapRootpath: '../../'
        },
        files: {
          "liquens/css/editor.css": "liquens/css/less/editor.less",
          "liquens/css/eventcalendaradmin.css": "liquens/css/less/eventcalendaradmin.less",
          "liquens/css/cms.css": "liquens/css/less/cms.less"
        }
      },
      prod: {
        options: {
          paths: ["liquens/css/less"],
          compress: true
        },
        files: {
          "themes/dng/css/theme.css": "liquens/css/less/liquens.less",
          "liquens/css/editor.css": "liquens/css/less/editor.less",
          "liquens/css/eventcalendaradmin.css": "liquens/css/less/eventcalendaradmin.less",
          "liquens/css/cms.css": "liquens/css/less/cms.less"
        }
      },
      themes: {
        option: {
          compress: true
        },
        files: [
          {
            expand: true,
            cwd: 'themes/',
            src: '*/css/*.less',
            dest: 'themes/',
            ext: '.css'
          }
        ]
      },
        theme: {
            options: {
                compress: true
            },            
            files: [
              {
                expand: true,
                cwd: 'themes/<%= options.theme %>',
                src: 'css/*.less',
                dest: 'themes/<%= options.theme %>',
                ext: '.css'
              }
            ]
        }
    },
    clean: {
      all: {
        files: [
          {
            expand: true,
            cwd: 'sites/',
            src: ['*/silverstripe-cache/{,.}*']
          }
        ]
      },
      config: {
        files: [
          {
            expand: true,
            cwd: 'sites/',
            src: ['*/silverstripe-cache/DngContainer.php']
          }
        ]
      }
    },
    shell: {
    	build: {
        options: {
            stdout: true
        },
        command: [
            'echo "\nComposer install:\n"',
            'composer install',
            'echo "======================="',
            'echo "\nBower install:\n"',
            'bower install',
            'echo "======================="'
        ].join('&&')
    	},
        newsite: {
          options: { stdout: true, stderr: true },
          command: [
            'cp -va sites/.skeleton sites/<%= options.site %>'
          ].join('&&')
        },
        copydist: {
          options: { stdout: true, stderr: true },
          command: [
            'cp -vp _ss_environment_conf.php.dist _ss_environment_conf.php',
            'cp -vp .htaccess.dist .htaccess',
            'cp -vp robots.txt.dist robots.txt',
            'cp -vp debug.log.dist debug.log',
            'cp -vp sites/_map_request_to_site.php.dist sites/_map_request_to_site.php',
          ].join('&&')
        },
        owners: {
          options: { stdout: true, stderr: true, stdin: true },
          command: [
            'sudo chown -vR <%= options.serveruser %> logs',
            'sudo chown -vR <%= options.serveruser %> liquens/lang',
            'sudo chown -vR <%= options.serveruser %> sites/.skeleton/assets',
            'sudo chown -vR <%= options.serveruser %> sites/.skeleton/lang',
            'sudo chown -vR <%= options.serveruser %> sites/.skeleton/silverstripe-cache',
            'sudo chown -vR <%= options.serveruser %> sites/*/assets',
            'sudo chown -vR <%= options.serveruser %> sites/*/lang',
            'sudo chown -vR <%= options.serveruser %> sites/*/silverstripe-cache',
            'sudo chown -v <%= options.serveruser %> liquens/config/lang.yml',
            'sudo chown -v <%= options.serveruser %> debug.log'
          ].join('&&')
        },
        littlekisses: {
          options: { stdout: true, stderr: true, stdin: true },
          command: [
              //'[ -f sites/<%= options.site %>/libraryMap.php ] && sudo rm sites/<%= options.site %>/libraryMap.php',
              'sudo touch sites/<%= options.site %>/libraryMap.php',
              'sudo chown -v <%= options.serveruser %> sites/<%= options.site %>/libraryMap.php'
          ].join('&&')
        },
        installsake: {
          options: { stdout: true, stderr: true, stdin: true },
          command: 'sudo ./sapphire/sake installsake'
        },
        dngsetup: {
          options: { stdout: true, stderr: true, stdin: true },
          command: 'sudo -u <%= options.serveruser %> php sakeall.php --only=<%= options.site %> dev/tasks/DngSetUp'
        },      
        synclittlekisses: {
          options: { stdout: true, stderr: true, stdin: true },
          command: 'sudo -u <%= options.serveruser %> php sakeall.php --only=<%= options.site %> dev/tasks/SyncLittleKisses'
        },
        release: {
          options: { stdout: true, stderr: true, stdin: true, failOnError: true },
          command: [
              'git tag <%= options.version %>',
              'git push origin <%= options.version %>'
          ].join('&&')
        },
        "releasebuild-pre": {
          options: { stdout: true, stderr: true, stdin: true, failOnError: true },
          command: [
              'git pull',
              'git fetch --all',
              'git merge <%= options.version %> --no-commit -X theirs'
          ].join('&&')
        },
        "releasebuild-post": {
          options: { stdout: true, stderr: true, stdin: true, failOnError: true },
          command: [
              'git add -A',
              'git commit -am "Build <%= options.version %>"',
              'git tag build-<%= options.version %>',
              'git push origin build',
              'git push origin build-<%= options.version %>'
          ].join('&&')
        }
    }
  });

  // Default task(s).
  grunt.registerTask('default', [
    'less:prod',
    'less:themes',
    'requirejs'
    ]);
  grunt.registerTask('build', [
    'shell:build',
    'less:prod',
    'less:themes',
    'requirejs'
    ]);
  grunt.registerTask('dev', 'watch');
  grunt.registerTask('themes', 'less:themes');
  grunt.registerTask('flush', 'clean:all');
  grunt.registerTask('newsite', 'shell:newsite');
  grunt.registerTask('release', 'shell:release');
  grunt.registerTask('release-build', ['shell:releasebuild-pre', 'build', 'shell:releasebuild-post']);
  grunt.registerTask('install', ['newsite', 'shell:copydist', 'shell:owners', 'shell:installsake', 'shell:littlekisses', 'alldone']);
  grunt.registerTask('installbuild', ['newsite', 'shell:copydist', 'shell:owners', 'shell:installsake', 'shell:littlekisses', 'alldone']);
  grunt.registerTask('addlittlekisses', ['shell:littlekisses', 'shell:synclittlekisses']);
  grunt.registerTask('dngsetup', 'shell:dngsetup');

  grunt.registerTask('alldone', function() {
    grunt.log.ok('Installation completed.');
    grunt.log.writeln('Now please edit sites/' + options.site +  '/config.yml file and then launch');
    grunt.log.writeln('grunt dngsetup --site=' + options.site + ' --server-user=' + options.serveruser);
  });

};
