<?php
/**
 * This file is part of dng
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

class OpenSearchController extends Page_Controller
{
    public static $allowed_actions = array(
        'opensearch'
    );

    public static $url_handlers = array(
        'opensearch.xml' => 'opensearch'
    );

    /**
     * This should be hit only when there is no sites/site/assets/opensearch.xml file
     * regenerate the file in that case.
     *
     * @param HttpRequest $request
     *
     * @return string
     */
    public function opensearch(SS_HttpRequest $request)
    {
        $response =  $this->renderWith(array('OpenSearch'));
        file_put_contents(ASSETS_PATH . DIRECTORY_SEPARATOR . 'opensearch.xml', $response);

        return $response;
    }
} 
