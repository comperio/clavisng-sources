<?php

/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class DataController extends Page_Controller
{

    static $url_handlers = array(
        'appLogin' => 'appLogin',
        'appLogout' => 'appLogout',
        'appSlider/$sourceName!/$key0' => 'appSlider',
        'libraryTimetable' => 'libraryTimetable',
        'json/$sourceName!/$key0/$key1/$key2/$key3/$key4' => 'json',
        'html/$sourceName!/$key0/$key1/$key2/$key3/$key4' => 'html',
        'xml/$sourceName!/$key0/$key1/$key2/$key3/$key4' => 'xml',
        'jshelf/$sourceName!/$key0/$key1/$key2/$key3/$key4' => 'jshelf',
        'jsonDataApi' => 'jsonDataApi',
        'uploadNewFile' => 'uploadNewFile',
        'layerFromMapId' => 'layerFromMapId'
    );
    static $allowed_actions = array(
        'appLogin', 'appLogout', 'appSlider', 'libraryTimetable', 'json', 'html', 'xml', 'jshelf', 'jsonDataApi', 'uploadNewFile', 'layerFromMapId'
    );

    /**
     * An array of named dataSources,
     * @var array
     */
    private $dataSources = array();

    public function init()
    {
        $this->registerDataSources(static::getContainer()->getParameter('data_sources'));
        parent::init();
    }

    /**
     * Da dataobject_manager/templates/includes/NewFilesUploader.ss
     *
     * @param type $request
     * @throws Exception
     */
    public function uploadNewFile($request)
    {
        try {
            if (!Member::currentUser()) {
                throw new Exception('File non caricato.');
            }

            $title = Convert::raw2sql($request->postVar('title'));
            $file = $request->postVar('file');
            $id = Convert::raw2sql($request->postVar('id'));

            if ($id <= 0) {
                throw new Exception('Errore nel caricamento.');
            }

            $extensions = ['jpg', 'jpeg', 'png', 'gif', 'mov', 'flv', 'mp4', 'doc', 'pdf', 'xls', 'odt', 'txt'];

            $imageType = ['jpg', 'jpeg', 'png', 'gif'];
            $audioType = ['mp3'];
            $videoType = ['mov', 'flv', 'mp4', 'avi'];

            $file_name = Convert::raw2sql($file['name']);
            $file_tmp = Convert::raw2sql($file['tmp_name']);
            $file_size = Convert::raw2sql($file['size']);
            $temp = explode('.', $file_name);
            $file_ext = strtolower(end($temp));

            if (!in_array($file_ext, $extensions)) {
                throw new Exception('Estensione non ammessa ' . $file_ext);
            }

            $fileType = 'File';
            if (in_array($file_ext, $imageType)) {
                $fileType = 'Image';
            } else if (in_array($file_ext, $audioType)) {
                $fileType = 'MP3';
            } else if (in_array($file_ext, $videoType)) {
                $fileType = 'FLV';
            }

            if ($file_size > 5242880) {
                throw new Exception('Massima dimensione ammessa 5MB: ' . $file_size . ' MB');
            }

            $file_name = str_replace("." . $file_ext, "", $file_name);
            $file_name = preg_replace('/[\W]/', '_', $file_name);

            $path = DB::query("SELECT Filename FROM File WHERE `ClassName` LIKE 'Folder' AND `ID` = '" . (int)$id . "'")->value();
            $file = Director::baseFolder() . "/" . $path . $file_name . "_" . date('Y-m-d_H-i-s') . "." . $file_ext;

            if (!move_uploaded_file($file_tmp, $file)) {
                throw new Exception('Dimensione file superiore al consentito oppure estensione non ammessa.');
            }

            $dbFile = new File();
            $dbFile->ClassName = $fileType;
            $dbFile->Name = $file_name;
            $dbFile->Title = $title != '' ? preg_replace('/[\W]/', '_', $title) : $file_name;
            $dbFile->Filename = $file;
            $dbFile->Content = null;
            $dbFile->Sort = 0;
            $dbFile->SortOrder = DB::query("SELECT MAX(SortOrder) FROM File WHERE `ClassName` LIKE 'File' AND `ParentID` = '" . (int)$id . "'")->value() + 1;
            $dbFile->ParentID = (int)$id;
            $dbFile->ShowInSearch = 1;
            $dbFile->OwnerID = Member::currentUser()->ID;
            if (!$dbFile->write())
                throw new Exception('Problemi di salvataggio');

        } catch (Exception $e) {
            die('Attenzione: ' . $e->getMessage());
        }
    }

    /**
     * Autologin per applicazione esterna, accetta username e password e restituisce il RememberLoginToken (OTP)
     *
     * @param type $request
     * @return type
     */
    public function appLogin($request)
    {
        $dummyArray = array();
        $dummyArray["AuthenticationMethod"] = "ExternalAuthenticator";
        $dummyArray["External_MailAddr"] = "empty";
        $dummyArray["External_SourceID"] = "liquens";
        $dummyArray["External_Anchor"] = $request->postVar('u');
        $dummyArray["Password"] = $request->postVar('p');
        $dummyArray["action_dologin"] = "";
        $dummyArray['Remember'] = true;

        ExternalLoginForm::performLogin($dummyArray, "appLogin");

        return json_encode(array("autologin_token" => Member::currentUser()->RememberLoginToken, 'sid' => session_id()));
    }

    public function appLogout($request)
    {
        // IDP Initiated FLOW
        // ------------------------------------------------------------------
        // setto cookie phpsessionid a session che voglio distruggere nella richiesta
        // fatta da clavis a questo endpoint.
        // chiamo da clavis n volte questo metodo quante sono le ssessioni istanziate per
        // l'utente corrente nelle patron_action.
        // ------------------------------------------------------------------
        //
        $session_id = $request->postVar('s');
        if ($session_id != '') {
            session_id($session_id);
        }
        session_start();
        session_destroy();
    }

    /**
     * Crea la risposta json relativamente alle immagini da mostrare con lo slider esterno
     *
     * @param SS_HTTPRequest $request
     * @return type
     * @global type $sc
     */
    public function appSlider(SS_HTTPRequest $request)
    {
        $manifestationId = $request->getVar('manID');
        global $sc;
        $repo = $sc->get('manifestation_repo');
        $manifestation = $repo->getOneById($manifestationId);
        $issue = array();
        $i = 0;

        if (isset($manifestation->cover_url)) {
            $issue["children"][$i]["text"] = isset($manifestation->cover_title) ? $manifestation->cover_title : "Copertina";
            $issue["children"][$i]["file"] = $manifestation->cover_url;
            $issue["children"][$i]["manID"] = $manifestationId;
            $issue["children"][$i]["index"] = $i;
            // d = DNG
            $issue["children"][$i]["type"] = "d";
            $issue["children"][$i]["state"]["opened"] = true;
            $i++;
        }
        if (isset($manifestation->images)) {
            foreach ($manifestation->images as $key => $image) {
                $issue["children"][$key + 1]["text"] = isset($image->attachment_title) ? $image->attachment_title : "Immagine " . $key + 1;
                $issue["children"][$key + 1]["file"] = $image->url;
                $issue["children"][$key + 1]["manID"] = $manifestationId;
                $issue["children"][$key + 1]["index"] = $i;
                $issue["children"][$key + 1]["type"] = "d";
                if ($i == 0)
                    $issue["children"][$key + 1]["state"]["opened"] = true;
                $i++;
            }
        }
        if (isset($manifestation->attachments)) {
            foreach ($manifestation->attachments as $key => $attachment) {
                $issue["attachment"][$key]["text"] = isset($attachment->attachment_title) ? $attachment->attachment_title : "Allegato " . $key + 1;
                $issue["attachment"][$key]["file"] = $attachment->url;
                // p = PDF
                $issue["attachment"][$key]["type"] = "p";
            }
        }
        $issue["title"] = $manifestation->title_and_author;
        // s = seriali
        $issue["type"] = "s";
        $issue["total"] = $i;
        $issue["state"]["opened"] = true;
        $issue["state"]["disabled"] = true;
        return json_encode([$issue]);
    }

    /**
     * Chiamata dall'esterno per gli orari delle biblioteche (Andrea - Empoli)
     *
     * @param type $request
     * @return type
     * @global type $sc
     */
    public function libraryTimetable($request)
    {
        global $sc;
        return json_encode($sc->get('liquens.connector')->getSoapClient('consortia')->getLibraryTimetable($request->postVar('i'), $request->postVar('f'), $request->postVar('t')));
    }

    /**
     * Register a datasource for the controller
     *
     * @param $name
     * @param array|callable $dataSource
     * @param array $options
     * @return DataController
     * @throws InvalidArgumentException
     */
    public function registerDataSource($name, $dataSource = array(), $options = array())
    {
        if (!is_callable($dataSource) && !is_array($dataSource)) {
            throw new InvalidArgumentException('DataController::registerDataSource second argument must be an array or a callable');
        }

        $this->dataSources[$name] = array($dataSource, $options);

        return $this;
    }

    /**
     * Retrieve a registered datasource from its name
     *
     * @param $name
     * @return mixed
     * @throws InvalidArgumentException
     */
    public function getDataSource($name)
    {
        if (!isset($this->dataSources[$name]))
            throw new InvalidArgumentException('Data source ' . $name . ' is not defined');

        return $this->dataSources[$name][0];
    }

    /**
     * Retrieve the json options registered with a data source
     *
     * @param $name
     * @return int
     * @throws InvalidArgumentException
     */
    public function getDataSourceOptions($name)
    {
        if (!isset($this->dataSources[$name]))
            throw new InvalidArgumentException('Data source ' . $name . ' is not defined');

        return $this->dataSources[$name][1];
    }

    /**
     * Register multiple datasources at a time
     *
     * @param array $dataSourcesMap
     * @return DataController
     */
    public function registerDataSources(array $dataSourcesMap)
    {
        foreach ($dataSourcesMap as $name => $dataSource) {
            $source = $dataSource[0];
            $options = isset($dataSource[1]) ? $dataSource[1] : array();

            $this->registerDataSource($name, $source, $options);
        }

        return $this;
    }

    /**
     * Transform a request to the data returned by the datasource
     *
     * @param SS_HTTPRequest $request
     * @return mixed|null
     * @throws Exception
     */
    public function getDataFromRequest(SS_HTTPRequest $request)
    {
        //build key array
        $dataSource = $this->getDataSource($request->param('sourceName'));
        $keys = $this->buildKeysArrayFromRequest($request);

        if (is_array($dataSource)) {
            $data = $this->getNestedArrayValue($keys, $dataSource);
        } elseif (is_callable($dataSource)) {
            $data = call_user_func_array($dataSource, $keys);

            //If the result is an array and there are more keys than callable arguments,
            //use the exceeding keys to pick a nested value
            if (is_array($data)) {
                $reflection = new ReflectionFunction($dataSource);
                $num = $reflection->getNumberOfParameters();
                $nestedKeys = array_slice($keys, $num);
                if ($nestedKeys) {
                    $data = $this->getNestedArrayValue($nestedKeys, $data);
                }
            }
        } else {
            throw new Exception("DataSource must be an array or a callable");
        }

        return $data;
    }

    /**
     * Returns nested arrays values from an arrays of keys. If the array of keys
     * is empty, it returns directly the array (or the value).
     *
     * @param array $keys
     * @param $arrayOrValue
     * @return mixed
     */
    private function getNestedArrayValue(array $keys, $arrayOrValue)
    {
        $value = null;

        if (!count($keys)) {
            $value = $arrayOrValue;
        } else {
            $currKey = array_shift($keys);
            if (isset($arrayOrValue[$currKey])) {
                $value = $this->getNestedArrayValue(
                    $keys, $arrayOrValue[$currKey]
                );
            }
        }

        return $value;
    }

    /**
     * Builds the keys array from the request (@param SS_HTTPRequest $request
     * @return array
     * @see DataController::$url_handlers)
     */
    private function buildKeysArrayFromRequest(SS_HTTPRequest $request)
    {
        //build key array
        $keys = array();
        $keyIndex = 0;

        while ($request->param('key' . $keyIndex) !== null) {
            $keys[] = $request->param('key' . $keyIndex);
            $keyIndex++;
        }

        return $keys;
    }

    /**
     * @param SS_HTTPRequest $request
     * @return string
     */
    public function json(SS_HTTPRequest $request)
    {
        $options = $this->getDataSourceOptions($request->param('sourceName'));
        $jsonOptions = isset($options['JSON_OPTION']) ? $options['JSON_OPTION'] : 0;
        $body = json_encode($this->getDataFromRequest($request), $jsonOptions);
        $response = new SS_HTTPResponse($body);
        $response->addHeader("Content-type", "application/json");
        return $response;
    }

    public function html(SS_HTTPRequest $request)
    {
        $data = $this->getDataFromRequest($request);
        $response = new SS_HTTPResponse($data);
        $response->addHeader("Content-type", "text/html");

        return $response;
    }

    public function xml(SS_HTTPRequest $request)
    {
        $data = $this->getDataFromRequest($request);
        $response = new SS_HTTPResponse($data);
        $response->addHeader("Content-type", "application/xml");

        return $response;
    }

    /**
     *
     * Utilizzo: https://<opac_url>/data/jsonDataApi
     * ?type=<element_type>
     *
     * &shelfid=<shelf_widget_id_esistente>
     * &trine=<clavis_trine_id>
     * &q=<fulltext_simple_search_string>
     * &op_1=and&field_4=title&lop_4=1&value_4=...<parameters_advanced_search_string>
     *
     * &page=<numero_risultati>
     * &sort=<ordinamento_risultati_ricerca>
     * &ttl=<time_to_live_apc_cache_in_secondi>
     *
     * @param SS_HTTPRequest $request
     * @return type
     * @global type $sc
     */
    public function jsonDataApi(SS_HTTPRequest $request, $toWrap = null)
    {
        global $sc;
//        $solrDB = $sc->getParameter('lq.solrDatabase');
        $opac_url = $sc->getParameter('opac_direct_url');

        // Valori fissi
        // Verifica bypass da chiamata interna
        if (!is_null($toWrap)) {
            $type = $toWrap['type'];
            $elnum = !is_null($toWrap['page']) ? (int)$toWrap['page'] : 20;
            $ttl = !is_null((int)$toWrap['ttl']) ? (int)$toWrap['ttl'] : 0;
        } else {
            $type = $request->getVar('type');
            $elnum = !is_null($request->getVar('page')) ? (int)$request->getVar('page') : 20;
            $ttl = !is_null((int)$request->getVar('ttl')) ? (int)$request->getVar('ttl') : 0;
        }

        // Costruzione chiave per APC
        switch ($type) {
            case "sh":
                if (!is_null($toWrap))
                    $value = (int)$toWrap['shelfid'];
                else
                    $value = (int)$request->getVar('shelfid');
                break;
            case "mn":
                $value = Convert::raw2sql($request->getVar('trine'));
                break;
            case "ss":
//            case "as":
                $value = $request;
                break;
            default:
                return 0;
        }

//        $apcKey = "jsonDataApi_" . $solrDB . "_" . implode(":", array($type, $value, $elnum, $ttl));

//        If (($ttl == 0) || (!apc_exists($apcKey) || !apc_fetch($apcKey) == "SUCCESS")) {
        // Richiesta dati effettivi
        switch ($type) {
            /* SCAFFALE */
            case "sh":
                $className = DB::query("SELECT ClassName FROM Widget WHERE `ID` LIKE " . $value)->value();
                $widgetID = DB::query("SELECT WidgetID FROM " . $className . " WHERE `ID` LIKE " . $value)->value();
                $shelfRef = DB::query("SELECT ShelfRef FROM ShelfWidget WHERE `ID` LIKE " . $widgetID)->value();
                $shelfWidget = new ShelfWidget();
                $shelf = $shelfWidget->Shelf($shelfRef);
                $manifestations = $shelfWidget->getManifestations($shelf, $elnum);
                $result = array();
                foreach ($manifestations as $id => $manifestation) {
                    $result[$id]["full_author"] = $manifestation->full_author;
                    $result[$id]["cover_title"] = $manifestation->cover_title;
                    if ($manifestation->cover_url != "") {
                        $i = $manifestation->cover_url;
                    } else {
                        $i = 'fake-ean';
                        if (isset($manifestation->identification_numbers->ean)) {
                            $i = $manifestation->identification_numbers->ean;
                        } elseif (isset($manifestation->identification_numbers->isbn)) {
                            $i = $manifestation->identification_numbers->isbn;
                        }
                        $i = LQConfig::get('coverServerUrl') . $i;
                    }
                    if (isset($manifestation->abstract) && preg_replace("/[^A-Za-z0-9?!\s]/", "", $manifestation->abstract) != '')
                        $result[$id]["abstract"] = trim($manifestation->abstract);
                    $result[$id]["cover_url"] = $i;
                    $result[$id]["opac_url"] = $opac_url . 'opac/detail/view/' . $manifestation->solr_database . ":" . $manifestation->solr_catalog . ":" . $manifestation->external_id;
                    /* Vedi tutti */
                    $result[$id]["view_all"] = $opac_url . $shelfWidget->ShelfPageLink();
                }
                break;
            /* SIMPLE SEARCH */
            case "ss":
            case "as":
                $simpleSearch = new SearchPage_Controller();
                $manifestations = $simpleSearch->getResultsForJson($request, 'simple');
                $result = array();
                foreach ($manifestations as $manifestation) {
                    foreach ($manifestation->items as $items) {
                        $result[$items->trine_id]["full_author"] = $items->full_author;
                        $result[$items->trine_id]["cover_title"] = $items->cover_title;
                        if ($items->cover_url != "") {
                            $i = $items->cover_url;
                        } else {
                            $i = 'fake-ean';
                            if (isset($items->identification_numbers->ean)) {
                                $i = $items->identification_numbers->ean;
                            } elseif (isset($items->identification_numbers->isbn)) {
                                $i = $items->identification_numbers->isbn;
                            }
                            $i = LQConfig::get('coverServerUrl') . $i;
                        }
                        if (isset($items->abstract) && preg_replace("/[^A-Za-z0-9?!\s]/", "", $items->abstract) != '')
                            $result[$items->trine_id]["abstract"] = trim($items->abstract);
                        $result[$items->trine_id]["cover_url"] = $i;
                        $result[$items->trine_id]["opac_url"] = $opac_url . 'opac/detail/view/' . $items->trine_id;
                        $result[$items->trine_id]["availability"] = count($items->items);
                        $result[$items->trine_id]["type"] = $items->bibliographic_type->simple;
                    }
                }
                break;
            /* ADVANCED SEARCH */
            //            case "as":
            //                $simpleSearch = new SearchPage_Controller();
            //                $manifestations = $simpleSearch->getResultsForJson($request);
            ////echo "<pre>" . print_r($manifestations, true) . "</pre>";
            //                $result = array();
            //                foreach ($manifestations as $manifestation) {
            //                    foreach ($manifestation->items as $items) {
            //                        $result[$items->trine_id]["full_author"] = $items->full_author;
            //                        $result[$items->trine_id]["cover_title"] = $items->cover_title;
            //                        if ($items->cover_url != "") {
            //                            $i = $items->cover_url;
            //                        } else {
            //                            $i = 'fake-ean';
            //                            if (isset($items->identification_numbers->ean)) {
            //                                $i = $items->identification_numbers->ean;
            //                            } elseif (isset($items->identification_numbers->isbn)) {
            //                                $i = $items->identification_numbers->isbn;
            //                            }
            //                        }
            //                        if (isset($items->abstract))
            //                            $result[$items->trine_id]["abstract"] = trim($items->abstract);
            //                        $result[$items->trine_id]["cover_url"] = LQConfig::get('coverServerUrl') . $i;
            //                        $result[$items->trine_id]["opac_url"] = Director::absoluteBaseURL() . 'opac/detail/view/' . $items->trine_id;
            //                        $result[$items->trine_id]["availability"] = count($items->items);
            //                        $result[$items->trine_id]["type"] = $items->bibliographic_type->simple;
            //                    }
            //                }
            //                break;
            /* MANIFESTATION */
            case "mn":
                $repo = $sc->get('manifestation_repo');
                $manifestation = $repo->getOneById($value);
                $result = array();

                $result[$value]["full_author"] = $manifestation->full_author;
                $result[$value]["cover_title"] = $manifestation->cover_title;
                $result[$value]["full_title"] = $manifestation->full_title;
                $result[$value]["publication"] = $manifestation->publication;
                $result[$value]["publication_date"] = $manifestation->publication_date;

                $t = array();
                foreach ($manifestation->languages as $lang) {
                    $t[] = $lang->text . " (" . $lang->type . ")";
                }
                $result[$value]["languages"] = join(", ", $t);

                $t = array();
                foreach ($manifestation->countries as $country) {
                    $t[] = $country->text;
                }
                $result[$value]["countries"] = join(", ", $t);

                $t = array();
                foreach ($manifestation->works as $work) {
                    $t[] = $work->text;
                }
                $result[$value]["works"] = join(", ", $t);

                $t = array();
                foreach ($manifestation->authorities as $authority) {
                    if ($authority->type == "names") {
                        foreach ($authority->authority_elements as $element) {
                            $t[] = $element->text;
                        }
                    }
                }
                $result[$value]["authorities"] = join(", ", $t);

                $id_num = '';
                if (isset($manifestation->identification_numbers->ean)) {
                    $id_num = $manifestation->identification_numbers->ean;
                    $result[$value]["ean"] = $id_num;
                } elseif (isset($manifestation->identification_numbers->isbn)) {
                    $id_num = $manifestation->identification_numbers->isbn;
                    $result[$value]["isbn"] = $id_num;
                }
                if ($manifestation->cover_url != "") {
                    $i = $manifestation->cover_url;
                } else {
                    $i = $id_num == '' ? 'fake-ean' : $id_num;
                    $i = LQConfig::get('coverServerUrl') . $i;
                }

                $t = array();
                foreach ($manifestation->physical_descriptions as $physical_description) {
                    $t[] = $physical_description->text;
                }
                $result[$value]["physical_descriptions"] = join(" | ", $t);

                if (isset($manifestation->abstract) && preg_replace("/[^A-Za-z0-9?!\s]/", "", $manifestation->abstract) != '')
                    $result[$value]["abstract"] = trim($manifestation->abstract);

                $result[$value]["cover_url"] = $i;
                $result[$value]["opac_url"] = $opac_url . 'opac/detail/view/' . $manifestation->solr_database . ":" . $manifestation->solr_catalog . ":" . $manifestation->external_id;

                $items = array();
                foreach ($manifestation->items as $item) {
                    $items[$item->id] = array(
                        "library_name" => $item->library_name,
                        "collocation" => $item->collocation,
                        "inventary_number" => $item->inventary_number,
                        "status" => $item->status,
                        "loanability" => $item->loanability,
                        "due_date" => isset($item->due_date) ? $item->due_date->value : "-"
                    );
                }
                $result[$value]["items"] = $items;
                break;
        }
//            if ($ttl != 0) {
//                apc_store($apcKey, json_encode($result), $ttl);
//            } else {
//                apc_store($apcKey, json_encode($result));
//            }
//        }
//        return apc_fetch($apcKey);  
        return json_encode($result);
    }

    /**
     * Restituisce uno scaffale in formato json (Brescia)
     * Utilizzo: https://<opac_url>/data/jshelf/widget/<shelf_widget_id_esistente>/<numero_risultati>/<time_to_live_apc_cache_in_secondi>
     * Esempio: https://opac.provincia.brescia.it/data/jshelf/widget/1825/20/100
     *
     * La chiamata viene convertita per la nuova funziona interna
     *
     * @param SS_HTTPRequest $request
     * @return type
     * @global type $sc
     */
    public function jshelf(SS_HTTPRequest $request)
    {
        return $this->jsonDataApi($request, array("type" => "sh", "shelfid" => $request->param('key0'), "elnum" => $request->param('key1'), "ttl" => $request->param('key2')));
    }

    public function layerFromMapId(SS_HTTPRequest $request)
    {
        $libId = $request->getVar('libId');
        $layer = DataObject::get_by_id("Geomap", (int)$libId)->OverTile;
        if ($layer)
            return json_encode(array($layer));
        return 0;
    }

}
