<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

/**
 * This class offers various validation methods, using the jQuery
 * validation plugin for client-side validation, and replicating some of
 * that validation server-side.
 *
 * The constructor takes two argument, $rules and $messages, and they follow
 * and replicate the same logic of the arguments ruels and messages of the
 * validate method of jQuery validation plugin
 * (http://docs.jquery.com/Plugins/Validation/validate#options)
 */
class ComplexValidator extends Validator
{
    /**
     * @var array The rules for validation
     */
    private $_rules = array();

    /**
     * @var array The messages for the validation
     * (they use the same logic described here:
     *  http://docs.jquery.com/Plugins/Validation/validate#options)
     */
    private $_messages = array();

    /**
     * @var string The namespace used by i18n to extend messages property
     */
    public $localizationNamespace = 'validation';

    /**
     * Extends validation messages with the current locale
     * 
     * @return ComplexValidator
     */
    private function extendMessages()
    {
        foreach($this->_rules as $fieldname => $rules){
            if (!is_array($rules))
                $rules = array($rules => true);

            foreach ($rules as $rule => $ruleValue){
                if (! $this->getMessage($fieldname, $rule)) {
                    $localized = _t($this->localizationNamespace . '.' . $rule);
                    if ($localized)
                        $this->_messages[$fieldname][$rule] = $localized;
                }
            }
        }

        return $this;
    }

    /**
     * Apply the right validation method associated to $rulename
     *
     * @param string $rulename The name of the rule
     * @param mixed $value the value of the field
     * @param mixed $options the options passed to the rule
     * @param array $data the Form data
     * @param bool $strict If true validation fails with validation method
     *  does not exist
     * @return bool
     */
    public function validateByRulename($rulename, $value, $options, $data, $strict = true)
    {
        $methodName =  'validate' . ucfirst($rulename);

        return
            (
                method_exists($this, $methodName)
                && $this->$methodName($value, $options, $data)
            ) or (
                !method_exists($this, $methodName)
                || !$strict
            )
        ;
    }

    /**
     * Validate a form field against a set of rules
     *
     * @param string $fieldName The name of the field
     * @param array|string $rules The set of rules
     * @param array $data The Form data
     *
     * @return bool
     */
    public function validateField($fieldName, $rules, $data)
    {
        $valid = true;

        if (!is_array($rules))
            $rules = array($rules => true);

        foreach($rules as $rulename => $rulevalue) {
            if (!isset($data[$fieldName]))
                continue;
            $fieldValue = $data[$fieldName];

            //Do not do validation for optional empty fields
            if ($this->isRuleAppliedToField('required', $fieldName) || $fieldValue !== ''){
                if (!$this->validateByRulename($rulename, $fieldValue, $rulevalue, $data)){
                    $valid = false;
                    $this->validationError(
                        $fieldName,
                        $this->getMessage($fieldName, $rulename),
                        $rulename
                    );
                }
            }
        }

        return $valid;
    }


    /**
     * @param array $rules
     * @param array $messages
     */
    public function __construct($rules = array(), $messages = array())
    {
        $this->_rules = $rules;
        $this->_messages = $messages;
        $this->extendMessages();
        
        parent::__construct();
    }

    /**
     * Returns the javascript code
     * @return string
     */
    public function javascript()
    {
        $js = '';
        $formID = $this->form->FormName();
        $rulesjson = json_encode($this->_rules);
        $messagesjson = json_encode($this->_messages);
        
        $js .= <<<JS
                    $("#$formID").validate({
                        rules: $rulesjson,
                        messages: $messagesjson,
                        highlight: function(element, errorClass, validClass) {
                             $(element).addClass(errorClass).removeClass(validClass);
                             $(element).closest('.inputwrapper')
                                            .addClass(errorClass);
                        },
                        unhighlight: function(element, errorClass, validClass) {
                             $(element).removeClass(errorClass).addClass(validClass);
                             $(element).closest('.inputwrapper')
                                            .removeClass(errorClass);
                        }
                    });
JS;

        return $js;
    }

    /**
     * Server-side validation
     * @param array $data
     * @return bool
     */
    public function php($data)
    {
        $valid = true;

        foreach($this->_rules as $fieldName => $rules) {
            if (!$this->validateField($fieldName, $rules, $data))
                $valid = false;
        }

        return $valid;
    }

    /**
     * Take the right error message from $this->_messages
     * related to that $fieldname and $rule
     *
     * @param string $fieldname The form element's name attribute
     * @param null|string $rule  The name of the rule
     * @return string The error message
     */
    public function getMessage($fieldname, $rule = null)
    {
        $respMessage = '';

        if (isset($this->_messages[$fieldname])){
            $message = $this->_messages[$fieldname];
            
            if (is_array($message)) {
                if (isset($message[$rule])){
                    $respMessage = $message[$rule];
                }
            }
            else {
                $respMessage = $message;
            }
        }

        return $respMessage;
    }

    /**
     * Overwrite {@link Validator} generation of the JS code
     * @return void
     */
    public function includeJavascriptValidation()
    {
        $lang = i18n::get_lang_from_locale(i18n::get_locale());

        $code = $this->javascript();

        $js = <<<JS
        require(["common"], function(){
            require(['jquery', "dng-validation"], function ($) {
                require(["liquens/javascript/validation-localization/messages_{$lang}.js"], function() {
                    $(document).ready(function() {
                        $code
                    });
                });
            });
        });
JS;

        Requirements::customScript($js);
        //HACK Notify the form that the validators client-side validation code has already been included
        if($this->form)
            $this->form->jsValidationIncluded = true;
    }

    /**
     * Check if a rule is applied to a field
     * 
     * @param string $rule
     * @param string $fieldName
     * @return bool
     */
    public function isRuleAppliedToField($rule, $fieldName)
    {
        return
            isset($this->_rules[$fieldName]) &&
            (
                $rule == $this->_rules[$fieldName] ||
                (
                    is_array($this->_rules[$fieldName]) &&
                    isset($this->_rules[$fieldName][$rule]) &&
                    $this->_rules[$fieldName][$rule]
                )
            )
        ;
    }

    /**
     * Check if a value is not empty
     * 
     * @param string $value
     * @return bool
     */
    public function validateRequired($value)
    {
        return !empty($value);
    }

    /**
     * Check if $value is a well-written email address
     * @param $value
     * @return bool
     */
    public function validateEmail($value)
    {
        $pcrePattern = '^[a-z0-9!#$%&\'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&\'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$';

		// PHP uses forward slash (/) to delimit start/end of pattern, so it must be escaped
		$pregSafePattern = str_replace('/', '\\/', $pcrePattern);
        
        return (bool) preg_match('/' . $pregSafePattern . '/i', $value);
    }

    /**
     * Check if $value represents a number
     * 
     * @param string $value
     * @return bool
     */
    public function validateNumber($value)
    {
        $regexp = '/^-?(?:\\d+|\\d{1,3}(?:,\\d{3})+)(?:\\.\\d+)?$/';
        return (bool) preg_match($regexp, $value);
    }

    /**
     * Check if $value contains only digits
     * @param string $value
     * @return bool
     */
    public function validateDigits($value)
    {
        $regexp = '/^\\d+$/';
        return (bool) preg_match($regexp, $value);
    }

    /**
     * Check if the string $value has length less than $maxlen
     *
     * @param string $value
     * @param int $maxlen
     * @return bool
     */
    public function validateMaxlength($value, $maxlen)
    {
        return strlen($value) <= $maxlen;
    }

    /**
     * Check if the string $value has length greater than $minlen
     *
     * @param string $value
     * @param $minlen
     * @return bool
     */
    public function validateMinlength($value, $minlen)
    {
        return strlen($value) >= $minlen;
    }

    /**
     * @param string $value
     * @param $min
     * @return bool
     */
    public function validateMin($value, $min)
    {
        return $value >= $min;
    }

    /**
     * @param $value
     * @param $max
     * @return bool
     */
    public function validateMax($value, $max)
    {
        return $value <= $max;
    }

    /**
     * Check if $value is equal to the value of the form element
     * with name attribute equal to $elName
     *
     * @param string $value The value to check
     * @param string $elName The name attribute of the form element
     * @param array $data The array of the data passed to the form
     * @return bool
     */
    public function validateEqualToByName($value, $elName, $data)
    {
        if (isset($data[$elName]))
            return $data[$elName] == $value;

        return false;
    }

    public function validateConditionalValidation($value, $options, $data)
    {
        //If the field specified by ReferringField exists...
        if (isset($data[$options['referringField']])){
            $refFieldValue = $data[$options['referringField']];

            //If there exists a rule set associated to the $refFieldValue...
            if (isset($options['rulesMap'][$refFieldValue])){
                $rules = $options['rulesMap'][$refFieldValue];

                if (!is_array($rules))
                    $rules = array($rules => true);

                $valid = true;
                foreach ($rules as $rule => $ruleOptions){
                    if (!$this->validateByRulename($rule, $value, $ruleOptions, $data))
                        $valid = false;
                }

                return $valid;
            }

            return true;
        }

        return false;
    }

    /**
     * Check if $value contains only alphanumeric characters
     * 
     * @param string $value
     * @return bool
     */
    public function validateAlphanumeric($value)
    {
        $regexp = '/^[a-zA-Z0-9_\-]*$/';
        return (bool) preg_match($regexp, $value);
    }

    public function validateItalianDate($value)
    {
        $regexp = '#^(([1-9])|(0[1-9])|([1-2]\d)|(3[0-1]))/((0[1-9])|(1[0-2])|([1-9]))/(\d\d\d\d)$#';
        return (bool) preg_match($regexp, $value);
    }
}
