<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

class LqTranslatedDataObject extends DataObject
{
    /**
     * Set this var to true to enable translatable overloading
     *
     * @var bool
     */
    public static $enabled = false;

    /**
     * The array of properties that have to be mantained equal to those
     * in the default language version of the object.
     *
     * @var array
     */
    public static $fields_to_mantain = array(
        'ID',
        'ParentID',
    );

    static $extensions = array(
    	"Versioned('Stage', 'Live')",
        "Translatable"
    );

    /**
     * Automatically augment  the object with translation if self::enabled
     * is set to true
     *
     * @param null $record
     * @param bool $isSingleton
     */
    public function __construct($record = null, $isSingleton = false)
    {
        parent::__construct($record, $isSingleton);

        if (static::$enabled)
            $this->augmentWithTranslation();
    }

    /**
     * Returns the array of fieldname->value couples fetched from the
     * current object
     *
     * @return array
     */
    public function getValuesToMantain()
    {
        $values = array();

        foreach(static::$fields_to_mantain as $fieldName) {
            $value = null;
            if (isset($this->$fieldName)){
                $value = $this->$fieldName;
            }

            $values[$fieldName] = $value;
        }

        return $values;
    }

    /**
     * The heart of the class. It changes the current dataobject properties to the
     * properties of the translation, preserving the ID, the ParentID and
     * the URLSegment, and setting the Locale to the default locale.
     *
     * @return LqTranslatedPage
     */
    public function augmentWithTranslation()
    {
        static $fetchTranslation = true;

        if (!self::$enabled) return;

        $oldLocale = $this->Locale;

        if ($fetchTranslation){
            $fetchTranslation = false;
            $translatedDataRecord =
                $this->getTranslation(i18n::get_locale());


            if (isset($translatedDataRecord) && $translatedDataRecord) {
                $valuesToMantain = $this->getValuesToMantain();
                $this->update($translatedDataRecord->toMap());
                $this->update($valuesToMantain);
            }

            elseif(i18n::default_locale() != $oldLocale){
                $defTranslation = $this->getTranslation(i18n::default_locale());
                if ($defTranslation){
                       $this->update($defTranslation->getValuesToMantain());
                }
            }
            $this->Locale = Translatable::default_locale();
            $fetchTranslation = true;
        }

        return $this;
    }
}
