<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Isacco Occhiali <isacco@comperio.it>
 */
/**
 * ClavisShelvesSet
 */
class ClavisShelvesSet extends FieldGroup {
	
    /**
     * @var array
     */
    public $dropDownFields = array();
   
    /**
     * The label 
     * @var string
     */
    public $returnLabel;
    
    public $controllerLink;
    
    public $libraryDropDownName;
    
    public $clavisShelvesDropDownName;
	
    public function __construct($librariesDropDown, $clavisShelvesDropDown, $returnLabel = '', $controllerLink='') {
    	
		$this->returnLabel = $returnLabel;
        $this->controllerLink = $controllerLink;
		$name = "";
        if($librariesDropDown instanceof DropdownField) {
            $this->dropDownFields[] = $librariesDropDown;
            $name = $librariesDropDown->Name();
            $this->libraryDropDownName = $librariesDropDown->Name();
        }
        if ($clavisShelvesDropDown instanceof DropdownField) {
            $this->dropDownFields[] = $clavisShelvesDropDown;
            $name = $clavisShelvesDropDown->Name();
            $this->clavisShelvesDropDownName = $clavisShelvesDropDown->Name();
        }
		$this->name = $name;

        parent::__construct($this->dropDownFields);
    }
	
    public function hasData() {return true;}

    public function FieldHolder() {

            //$updateLink = $this->controllerLink.'updateCSDropDown'; // action in ShelfPage_Controller
    //$libraryDDName = $this->libraryDropDownName;
    //$clavisShelvesDDName = $this->clavisShelvesDropDownName;
        Requirements::javascript(THIRDPARTY_DIR.'/jquery/jquery.js');
        Requirements::javascript(THIRDPARTY_DIR.'/jquery-metadata/jquery.metadata.js');
    //Requirements::javascript('liquens/javascript/clavisShelvesBehaviour.js');
    // pulire all'inizio la tendina di arrivo

        return parent::FieldHolder();
    }
}