<?php

class MlolShelvesSet extends FieldGroup {
	
    /**
     * @var array
     */
    public $dropDownFields = array();
   
    /**
     * The label 
     * @var string
     */
    public $returnLabel;
    
    public $controllerLink;
    
    public $mlolShelvesDropDownName;
    
    public $mlolResourcesDropDownName;
	
    public function __construct($mlolShelvesDropDown, $mlolResourcesDropDown, $returnLabel = '', $controllerLink='') {
    	
        $this->returnLabel = $returnLabel;
        $this->controllerLink = $controllerLink;
        $name = "";
        if($mlolShelvesDropDown instanceof DropdownField) {
            $this->dropDownFields[] = $mlolShelvesDropDown;
            $name = $mlolShelvesDropDown->Name();
            $this->mlolShelvesDropdownName = $mlolShelvesDropDown->Name();
        }
        if ($mlolResourcesDropDown instanceof DropdownField) {
            $this->dropDownFields[] = $mlolResourcesDropDown;
            $name = $mlolResourcesDropDown->Name();
            $this->clavisShelvesDropDownName = $mlolResourcesDropDown->Name();
        }
        $this->name = $name;

        parent::__construct($this->dropDownFields);
    }
	
    public function hasData() {return true;}

    public function FieldHolder() {

            //$updateLink = $this->controllerLink.'updateCSDropDown'; // action in ShelfPage_Controller
    //$libraryDDName = $this->libraryDropDownName;
    //$clavisShelvesDDName = $this->clavisShelvesDropDownName;
        Requirements::javascript(THIRDPARTY_DIR.'/jquery/jquery.js');
        Requirements::javascript(THIRDPARTY_DIR.'/jquery-metadata/jquery.metadata.js');
    //Requirements::javascript('liquens/javascript/clavisShelvesBehaviour.js');
    // pulire all'inizio la tendina di arrivo

        return parent::FieldHolder();
    }
}