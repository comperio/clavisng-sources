<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

/**
 * A discriminator that match everything with specificity equal to 1
 */
class NullDataObjectDiscriminator extends DataObjectDiscriminator
{
    /**
     * @param \DataObject $object
     * @return int
     */
    public function discriminate(DataObject $object)
    {
        return 1;
    }

}
