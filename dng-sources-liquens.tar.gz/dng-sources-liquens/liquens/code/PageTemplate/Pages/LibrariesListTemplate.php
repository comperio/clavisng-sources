<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class LibrariesListTemplate implements PageTemplate
{
    /**
     * Fill a SiteTree page with the template content
     * @param SiteTree $page
     * @return PageTemplate the current instance
     */
    public function fill(SiteTree $page)
    {
        //Fields
        $page->Title = $page->MenuTitle = _t('SiteTree.LIBRARYMAINTITLE', 'Libraries');

        //Widgets
        $area = $page->TopWidgetArea();

        if ($area->Widgets()->Count())
            return;

        if (!$area->isInDB()) {
            $area->write();
            $page->TopWidgetAreaID = $area->ID;
        }

        $area->Widgets()->add($this->getLibrariesMapWidget());

        // Libraries
        $libraryDataObjects = DataObject::get("LibraryDataObject", "Internal = 1") ?: new DataObjectSet();

        foreach ($libraryDataObjects as $library) {
            $page->Libraries()->add($library);
        }
    }

    /**
     * Build LibrariesMap Widget
     * @return LibrariesMapWidget
     */
    private function getLibrariesMapWidget()
    {
        $map = new LibrariesMapWidget();

        $map->write();

        return $map;
    }

}