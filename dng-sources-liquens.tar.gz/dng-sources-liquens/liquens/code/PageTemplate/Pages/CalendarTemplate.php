<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

class CalendarTemplate implements PageTemplate
{
    /**
     * Fill a SiteTree page with the template content
     * @param SiteTree $page
     * @return PageTemplate the current instance
     */
    public function fill(SiteTree $page)
    {
        $page->Title = _t('Library.CALENDAR', 'Calendar');
        $page->MenuTitle = _t('Library.CALENDAR', 'Calendar');
        $page->URLSegment = 'cal';
        $page->ShowInMenus = false;
    }

}