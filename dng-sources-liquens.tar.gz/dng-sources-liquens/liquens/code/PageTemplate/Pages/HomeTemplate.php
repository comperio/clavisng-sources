<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

class HomeTemplate extends GridTemplate
{
    /**
     * Returns an array of the kind
     * <code>
     * [
     *      GridWidget1, [Span1, NewLine1],
     *      GridWidget2, [Span2, NewLine2],
     * ]
     * </code>
     * @param SiteTree $page
     * @return array
     */
    public function getGrid(SiteTree $page)
    {
        return array(
            array($this->getLastinShelfWidget(), array(12, true)),
            array(new ContentWidget(), array(12, true)),
            array($this->getMostReadShelf(), array(4, true)),
            array($this->getMostRequestedhelf(), array(4, false)),
            array($this->getLastEvents(), array(4, false)),
            array($this->getLastPosts(), array(6, true)),
            array($this->getInformativeBox(), array(6, false)),
        );
    }

    /**
     * {@inheritdoc}
     */
    public function fill(SiteTree $page)
    {
        $page->Content = '<p style="text-align: center;">Messaggio di benvenuto al catalogo.</p>';
        $page->Title = _t('SiteTree.HOMETITLE', 'Home');
        $page->MenuTitle = _t('SiteTree.HOMETITLE', 'Home');

        parent::fill($page);
    }


    /**
     * @return ShelfWidget
     */
    private function getLastinShelfWidget()
    {
        $shelf = new ShelfWidget;
        $shelf->update(array(
            'Title' => _t('DefaultWidgets.SHELF_LASTIN_TITLE'),
            'Template' => 'ShelfWidgetCarouselHorizontal',
            'Limit' => 20,
            'ShelfRef' => 'predefined:lastin',
            'ShowShowAllLink' => true,
        ));

        return $shelf;
    }

    /**
     * @return ShelfWidget
     */
    private function getMostReadShelf()
    {
        $shelf = new ShelfWidget;
        $shelf->update(array(
            'Title' => _t('DefaultWidgets.SHELF_MOSTREAD_TITLE'),
            'Template' => 'ShelfWidgetNum',
            'Limit' => 10,
            'ShelfRef' => 'predefined:most_loaned',
            'ShowShowAllLink' => true,
        ));

        return $shelf;
    }

    /**
     * @return ShelfWidget
     */
    private function getMostRequestedhelf()
    {
        $shelf = new ShelfWidget;
        $shelf->update(array(
            'Title' => _t('DefaultWidgets.SHELF_MOSTREQUESTED_TITLE'),
            'Template' => 'ShelfWidgetNum',
            'Limit' => 10,
            'ShelfRef' => 'predefined:most_requested',
            'ShowShowAllLink' => true,
        ));

        return $shelf;
    }

    /**
     * @return EventsWidget
     */
    private function getLastEvents()
    {
        $widget = new EventsWidget();

        $widget->update(array(
            'Title' => _t('DefaultWidgets.EVENTS_NEXTEVENTS_TITLE'),
            'Limit' => 5,
        ));

        return $widget;
    }

    /**
     * @return ForumLastPosts
     */
    private function getLastPosts()
    {
        $widget = new ForumLastPosts();

        $widget->Title = _t('DefaultWidgets.POSTS_LASTREVIEWS_TITLE');
        $widget->NumberToShow = 2;
        $widget->ShowPostTitles = true;

        return $widget;
    }

    /**
     * @return HtmlWidget
     */
    private function getInformativeBox()
    {
        $widget = new HtmlWidget();

        $widget->Title = 'Info Box';

        $widget->Html =
                "<p class='content-box-info'>"
                    . _t('DefaultWidgets.HTML_INFO_DEFAULTMSG')
                . "</p>"
        ;

        return $widget;
    }
}