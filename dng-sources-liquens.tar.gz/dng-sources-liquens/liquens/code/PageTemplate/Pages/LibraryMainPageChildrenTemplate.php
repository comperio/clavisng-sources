<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

/**
 * Abstract template that builds children pages of LibraryMainPages
 */
class LibraryMainPageChildrenTemplate extends ChildrenTemplate
{
    /**
     * Return an array of SiteTrees and optional templates.
     * An example:
     * [
     *
     *      [SiteTree1, Template1],
     *      [SiteTree2, Template2],
     *      [SiteTree3, [Template31, Template32, ...]]
     *      SiteTree4,
     *      SiteTree5,
     *      ...
     * ]
     *
     * @param SiteTree $page
     * @return array
     */
    public function getChildrenAndTemplates(SiteTree $page)
    {
        return array(
            new LibraryStaffPage(),
            new Calendar(),
            new LibraryTimeTablePage(),
        );
    }
}