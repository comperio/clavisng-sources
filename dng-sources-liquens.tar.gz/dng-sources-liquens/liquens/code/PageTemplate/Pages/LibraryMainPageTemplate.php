<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

/**
 * Template for LibraryMainPage. It is supposed that LibraryObjectID is set.
 * Class LibraryMainPageTemplate
 */
class LibraryMainPageTemplate extends GridTemplate
{
    /**
     * {@inheritdoc}
     */
    public function getGrid(SiteTree $page)
    {
        return array(
            array(new ContentWidget(), array(12, true)),
            array($this->getLastEvents($page), array(8, true)),
        );
    }

    /**
     * {@inheritdoc}
     */
    public function fill(SiteTree $page)
    {
        /** @var Library $library */
        if ($page->LibraryObjectID) {
            $library = $page->getLibrary();
            $page->Title = $library->getFullName();
            $page->MenuTitle = $library->getShortName();
            $page->URLSegment = $library->getShortName();
        }

        $page->Status = 'Published';
        $page->CanEditType = 'OnlyTheseUsers';
        $page->ShowInMenus = false;

        parent::fill($page);
    }

    /**
     * @param SiteTree $page
     * @return EventsWidget
     */
    private function getLastEvents(SiteTree $page)
    {
        $widget = new EventsWidget();

        $widget->update(array(
            'Title' => _t('DefaultWidgets.EVENTS_NEXTEVENTS_TITLE'),
            'Limit' => 5,
            'LibraryMainPageID' => $page->ID,
            'ShowLibraryName' => false,
        ));

        return $widget;
    }
}