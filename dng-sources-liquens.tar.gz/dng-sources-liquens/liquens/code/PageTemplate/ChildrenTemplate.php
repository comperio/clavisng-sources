<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

/**
 * Abstract template that builds children pages
 */
abstract class ChildrenTemplate implements PageTemplate
{
    /**
     * {@inheritdoc}
     */
    public function fill(SiteTree $page)
    {
        foreach ($this->getChildrenAndTemplates($page) as $index => $data) {
            list($child, $templates) = $this->getPageAndTemplates($data);

            $child->Sort = $index + 1;
            $child->ParentID = $page->ID;

            $child->write();

            /** @var $template PageTemplate */
            foreach ($templates as $template) {
                $template->fill($child);
            }

            if ($templates)
                $child->write();
        }
    }

    /**
     * Return an array of SiteTrees and optional templates.
     * An example:
     * [
     *
     *      [SiteTree1, Template1],
     *      [SiteTree2, Template2],
     *      [SiteTree3, [Template31, Template32, ...]]
     *      SiteTree4,
     *      SiteTree5,
     *      ...
     * ]
     *
     * @param SiteTree $page
     * @return array
     */
    abstract public function getChildrenAndTemplates(SiteTree $page);


    /**
     * Normalize the data returned by getChildrenTemplates
     * The returned array will be in the form
     * [SiteTree, PageTemplate[]]
     * @param mixed $data A row returned by getChildrenAndTemplates
     *
     * @return array
     */
    private function getPageAndTemplates($data)
    {
        if ($data instanceof SiteTree) {
            return array($data, array());
        }

        list($page, $templates) = $data;

        if (!is_array($templates))
            $templates = array($templates);

        return array($page, $templates);
    }
}