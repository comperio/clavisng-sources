<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

class ContentWidgetTemplate extends GridTemplate
{
    /**
     * {@intheritdoc}
     */
    public function getGrid(SiteTree $page)
    {
        return array(
            array(new ContentWidget, array(12, true))
        );
    }
}