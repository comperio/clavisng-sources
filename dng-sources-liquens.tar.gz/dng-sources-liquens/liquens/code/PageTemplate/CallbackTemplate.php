<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class CallbacksTemplate implements PageTemplate
{
    /**
     * @var callable[]
     */
    private $callbacks = array();

    /**
     * @var array[]
     */
    private $options = array();

    /**
     * @param callable $callback
     * @param array $options
     */
    public function addCallback($callback, $options = array())
    {
        $this->callbacks[] = $callback;
        $this->options[] = $options;
    }

    /**
     * {@inheritdoc}
     */
    public function fill(SiteTree $page)
    {
        foreach ($this->callbacks as $i => $callback) {
            $options = $this->options[$i];
            array_unshift($options, $page);
            call_user_func_array($callback, $options);
        }

        return $this;
    }

}