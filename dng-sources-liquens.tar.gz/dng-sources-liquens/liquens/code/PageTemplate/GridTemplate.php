<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

/**
 * Class GridTemplate: fill a GridWidgetArea of a page
 */
abstract class GridTemplate implements PageTemplate
{
    /**
     * @var string
     */
    private $areaName;

    /**
     * @var bool
     */
    private $skipIfNotEmpty;

    /**
     * @param string $areaName The WidgetArea to fill
     * @param bool $skipIfNotEmpty If true, do nothing when the widget area already has widgets
     */
    public function __construct($areaName = 'WidgetArea', $skipIfNotEmpty = true)
    {
        $this->areaName = $areaName;
    }

    /**
     * Returns an array of the kind
     * <code>
     * [
     *      GridWidget1, [Span1, NewLine1],
     *      GridWidget2, [Span2, NewLine2],
     * ]
     * </code>
     * @param SiteTree $page
     * @return array
     */
    abstract public function getGrid(SiteTree $page);

    /**
     * {@inheritdoc}
     */
    public function fill(SiteTree $page)
    {
        $area = $this->getArea($page);

        if ($area->Widgets()->Count())
            return;

        foreach ($this->getGrid($page) as $index => $data) {
            list($widget, $gridOptions) = $data;
            list($span, $newline) = $gridOptions;

            $area->Widgets()->add($this->getGridWidget($widget, $span, $newline, $index + 1));
        }
    }

    /**
     * Get WidgetArea, and save it if it not in DB yet
     * @param SiteTree $page
     * @return mixed
     */
    private function getArea(SiteTree $page)
    {
        $areaName = $this->areaName;
        $area = $page->$areaName();
        if (!$area->isInDB()) {
            $area->write();
            $idKey = $areaName . 'ID';
            $page->$idKey = $area->ID;
        }

        return $area;
    }

    /**
     * Wrap a widget with a GridWidget. Save the GridWidget if it is not in DB yet.
     *
     * @param Widget $widget
     * @param string $span The Span property of the GridWidget
     * @param bool $newline The NewLine property of the GridWidget
     * @param int $sort The Sort property of the widget
     */
    public function getGridWidget(Widget $widget, $span, $newline, $sort = 1)
    {
        if (!$widget->isInDB())
            $widget->write();

        $gridWidget = new GridWidget();
        $gridWidget->WidgetID = $widget->ID;
        $gridWidget->Span = $span;
        $gridWidget->NewLine = $newline;
        $gridWidget->Sort = $sort;

        $gridWidget->write();

        return $gridWidget;
    }
}