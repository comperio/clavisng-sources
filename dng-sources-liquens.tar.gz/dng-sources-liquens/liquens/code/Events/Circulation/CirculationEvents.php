<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
final class CirculationEvents
{
    /**
     * Event thrown each time an user perform a reservation or remove a reservation
     *
     * @var string
     */
    const RESERVATIONS_UPDATED = 'reservations.updated';
}