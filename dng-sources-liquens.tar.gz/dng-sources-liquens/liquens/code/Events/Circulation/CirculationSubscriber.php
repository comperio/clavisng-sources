<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

use Symfony\Component\EventDispatcher\EventSubscriberInterface;

class CirculationSubscriber implements EventSubscriberInterface
{
    /**
     * {@intheritdoc}
     */
    public static function getSubscribedEvents()
    {
        return array(
            CirculationEvents::RESERVATIONS_UPDATED => array('onReservationsUpdated'),
        );
    }

    /**
     * Invalidate cache for reservations count.
     *
     * @param ReservationsUpdatedEvent $event
     */
    public function onReservationsUpdated(ReservationsUpdatedEvent $event)
    {
        CachedUserData::invalidate_cache('ReservationsCount', $event->getMember()->ID);
    }
}