<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class WidgetRenderer extends Page_Controller
{
    static $url_handlers = array(
        'html/$widgetId!' => 'html',
    );

    /**
     * Register a datasource for the controller
     *
     * @param $name
     * @param array|callable $dataSource
     * @param array $options
     * @return DataController
     * @throws InvalidArgumentException
     */
    public function registerDataSource($name, $dataSource = array(), $options = array())
    {
        if (!is_callable($dataSource) && !is_array($dataSource)){
            throw new InvalidArgumentException('DataController::registerDataSource second argument must be an array or a callable');
        }

        $this->dataSources[$name] = array($dataSource, $options);

        return $this;
    }

    public function html(SS_HTTPRequest $request)
    {
        $data = $this->getDataFromRequest($request);
        $response = new SS_HTTPResponse($data);
        $response->addHeader("Content-type", "text/html");

        return $response;
    }

    public function xml(SS_HTTPRequest $request)
    {
        $data = $this->getDataFromRequest($request);
        $response = new SS_HTTPResponse($data);
        $response->addHeader("Content-type", "application/xml");

        return $response;
    }
}
