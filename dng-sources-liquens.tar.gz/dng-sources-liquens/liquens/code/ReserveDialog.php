<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

/**
 * This class encapsulate the logic for Reserve Dialog Visualization
 */

class ReserveDialog extends ViewableData
{
    /**
     * @var \Member
     */
    private $member;

    /**
     * If the bibtype of the manifestation is "serial", in addition
     * to the manifestation id we need the issue id to perform the reservation
     * request
     *
     * @var string
     */
    private $issueId;

    /**
     * @var Manifestation
     */
    private $manifestation;

    /**
     * @var DataObjectSet
     */
    private $cachedLibList;

    /**
     * Used to keep track if the localizations strings have already been loaded
     *
     * @var bool
     */
    private static $localization_strings_loaded = false;

    /**
     * @param Member $member
     * @param Manifestation $manifestation
     * @param null|string $issueId
     */
    public function __construct(Member $member = null, Manifestation $manifestation = null, $issueId = null, $reservationNote = null)
    {
        $this->member = $member;
        $this->manifestation = $manifestation;
        $this->issueId = $issueId;
        $this->reservationNote = $reservationNote;

        if (!self::$localization_strings_loaded) {
            Controller::curr()->i18nToJs(array(
                'ReserveDialog.WAIT' => 'Loading...',
                'ReserveDialog.RESERVE' => 'Reserve',
                'ReserveDialog.CANCEL' => 'Cancel',
                'ReserveDialog.SORRYRESERVENOTAVAILABLE' => 'Sorry, reservation is not available on the selected title',
                'ReserveDialog.RESERVENOTAVAILABLE' => 'Reservation not available',
                'ReserveDialog.MUSTSELECTLIBRARY' => 'You must select a library'
            ));

            self::$localization_strings_loaded = true;
        }
    }

    /**
     * Get the map of retire libraries
     *
     * @return array
     */
    public function getLibrariesMap() {
        if ($member = Member::currentUser()) { return $member->getRetireLibrariesMap(); }
        return array();
    }

    /**
     *
     */
    public function getManifestation()
    {
        return $this->manifestation;
    }
    
    public function getReservationMessage() {
        return DataObject::get_one('SiteConfig')->ReservationString;
    }
    
    /**
     * Calcolo della migliore manifestation in base alla presenza di edizioni diverse
     * 
     * @param type $trineId
     * @return \DataObjectSet
     */
    public function BestManifestation($bibRitiro = null, $manifestationId = null, $output = null) {
        global $sc;
        if ($sc->getParameter('other_editions_loans')) {
            $bestManId = array('0','');
            // Verifico che non sia stata modificata la biblioteca di ritiro
            if (is_null($bibRitiro)) { $bibRitiro = $this->member->getExternalProp('PreferredLibraryId'); }
            // Controllo sul turbomarc se esistono copie disponibili nella propria biblioteca
            $repo = $sc->get('manifestation_repo');
            // Estraggo l'edition key per quella manifestation
            if (is_null($manifestationId)) { $manifestationId = Controller::curr()->urlParams['key0']; }
            $manifestation = $repo->getOneById($manifestationId);
            if ((string)$manifestation->bibliographic_type->type != 'm') { return false; }
            $manifestationEdKey = (string)$manifestation->edition_key;
            if ($manifestationEdKey != "") {
                // Query per le manifestations con medesima edition_key e bibtype
                $manifestations = $repo->getByOtherEditions(
                    '"'.html_entity_decode($manifestationEdKey, ENT_COMPAT, 'UTF-8').'"',
                    (string)$manifestation->bibliographic_type->code
                );
                if ($manifestations) {
                    $manifestationsTM = array();
                    $trovato = false;
                    $new = array('', 0);
                    foreach ($manifestations as $m) {
                        $manifestationsTM[$m->trine_id] = array('tmarc' => simplexml_load_string($m->sourceXml));
                        // Anno di edizione
                        $time = (int)trim(substr($manifestationsTM[$m->trine_id]['tmarc']->d100->sa,9,4));                    
                        foreach ($manifestationsTM[$m->trine_id]['tmarc']->d950 as $i) {
                            if (    ((int)$i->sa == $bibRitiro) &&
                                    (((string)$i->sp == "B")&&((string)$i->s2 == "A")) &&
                                    ((int)$manifestationsTM[$m->trine_id]['tmarc']->d909->sa == 0)
                                ) { // biblioteca, classe, status e prenotazioni nulle
                                // Calcolo dell'anno di edizione più recente
                                if ($time >= $new[1]) {
                                    $new[0] = $m->trine_id;
                                    $new[1] = $time;
                                    $trovato = true;
                                }
                            }
                        }
                    }
                    if ($trovato) {
                        $bestManId[0] = $new[0];
                        $bestManId[1] = "Questa edizione è già disponibile nella biblioteca scelta per il ritiro";
                    // Altrimenti calcolo le probabilità di avere una copia da un'altra biblioteca in base al minimo rapporto prenotazioni / #copie
                    } else {
                        if ($sc->getParameter('little_kisses') == true) { 
                            $bacino = $this->getSameBasinLibrariesMap($bibRitiro); 
                            $stessoBacino = array();
                        }
                        // Prepara dove memorizzare il minimo e il massimo
                        $min = array('0', 100000);
                        $max = array('0', 0);
                        $trovato = false;
                        // Dal blocco delle manifestations, ne estrae una alla volta
                        foreach ($manifestationsTM as $key => $manifestation) {
                            if ($sc->getParameter('little_kisses') == true) { $stessoBacino[$key] = 0; }
                            $tot = 0;
                            // Per ognuna, conta gli item "prestabili"
                            foreach ($manifestation['tmarc']->d950 as $i) {
                                if ($i->sp == "B") { 
                                    $tot++;
                                    $pos = (int)$i->so;
                                    if (($sc->getParameter('little_kisses') == true) && in_array($pos, $bacino)) { $stessoBacino[$key]++; } 
                                }
                            }
                            if ($tot != 0) {
                                // Suddivido la ricerca in base a #disp - #pren (> 0) e (<= 0)
                                if (($tot - $manifestation['tmarc']->d909->sa) > 0) {
                                    // Differenze e valore maggiore
                                    $valore = $tot - $manifestation['tmarc']->d909->sa;
                                    // Aggiorna il massimo salvandosi anche il trine_id relativo alla manifestation
                                    if ($valore > $max[1]) {
                                        $max[0] = $key;
                                        $max[1] = $valore;
                                        $trovato = true;
                                    }
                                } elseif (!$trovato) {
                                    // Indice di sofferenza e valore minore
                                    // Calcola l'indice per ogni item prestabile
                                    $valore = $manifestation['tmarc']->d909->sa / $tot;
                                    // Aggiorna il minimo salvandosi anche il trine_id relativo alla manifestation
                                    if ($valore < $min[1]) {
                                        $min[0] = $key;
                                        $min[1] = $valore;
                                    }
                                }
                            }
                        }
                        if (($sc->getParameter('little_kisses') == true) && (array_sum($stessoBacino) != 0)) {
                            $bestManId[0] = array_search(max($stessoBacino), $stessoBacino);
                        } elseif ($trovato) {
                            $bestManId[0] = $max[0];
                        } elseif ($min[1] != '0') {
                            $bestManId[0] = $min[0];
                        } else { return false; }
                        $bestManId[1] = "Questa edizione potrebbe essere disponibile per te in minor tempo";
                    }
                } else { return false; }
            }
            $repository = Page::getContainer()->get('manifestation_repo_essential');
            $manOk = new Manifestation();
            $manOk = $repository->getOneById($bestManId[0]);
            $result = array('idBest' => (string)$bestManId[0],
                'manTesto' => (string)$bestManId[1],
                'bibType' => (string)$manOk->bibliographic_type->simple,
                'autori' => (string)$manOk->full_author,
                'titolo' => (string)$manOk->full_title,
                'edizione' => (string)$manOk->edition != '' ? '<b>Edizione</b>: '.(string)$manOk->edition : '',
                'pubblicazione' => (string)$manOk->publication != '' ? '<b>Pubblicazione</b>: '.(string)$manOk->publication : '',
                'urlImage' => $manOk->getCoverUrl(),
                'idModule' => $manOk->getIdModule(),
                'truncatedCoverInfosTitle' => $manOk->getTruncatedCoverInfos()->Title,
                'truncatedCoverInfosAuthor' => $manOk->getTruncatedCoverInfos()->Author,
                'descrizione' => (string)$manOk->physical_description != '' ? '<b>Descrizione fisica</b>: '.(string)$manOk->physical_description : '',
                'gestioneCopie' => '<b>Copie Totali</b>: '.(string)$manOk->total_items.' <b>In Prestito</b>: '.(string)$manOk->onloan_items.' <b>Prenotazioni</b>: '.(string)$manOk->reservations.'</b>',
                'urlEdizione' => '<a href="opac/detail/view/'.(string)$bestManId[0].'">Vedi questa edizione ('.(string)$bestManId[0].')</a>'
            );
            if (isset($output) && ($output == true)) { return json_encode($result); }
            $doBestManifestation = new DataObjectSet();
            $doBestManifestation->push(new ArrayData($result));
            return $doBestManifestation;
        } else { return false; }
    }

    public function getSameBasinLibrariesMap($favLibraryId) {
        $areaMap = LibrariesListPage::get_libraries_area_map();
        $memberArea = false;
        foreach ($areaMap as $area => $libs) {
            if (in_array($favLibraryId, $libs)) {
                $memberArea = $areaMap[$area];
                break;
            }
        }
        return $memberArea;
    }    
    
    /**
     * Returns a DataObjectList of the libraries, specifying the default
     * user's library
     *
     * @return DataObjectSet
     */
    public function LibrariesList()
    {
        if (!isset($this->cachedLibList)) {
            $list = $this->getLibrariesMap();

            $doLibraries = new DataObjectSet();
            $defLibrary = $this->member->getExternalProp('PreferredLibraryId');
            $isFavouriteInList = false;

            foreach ($list as $libId => $libLabel) {
                if (!$isFavouriteInList) { $isFavouriteInList = ($libId == $defLibrary); }
                $doLibraries->push(new DataObject(array(
                    'id' => $libId,
                    'label' => $libLabel,
                    'default' => $libId == $defLibrary,
                )));
            }

            $doLibraries->sort('label');

            if (!$isFavouriteInList)
                $doLibraries->insertFirst(new DataObject(array(
                    'id' => '',
                    'label' => '---',
                    'default' => false,
                )));

            $this->cachedLibList = $doLibraries;
        }
        
        return $this->cachedLibList;
    }

    /**
     * Tells if there is a default library in the list, i.e. if the user's favourite
     * library is a Return Library
     * @return bool
     */
    public function IsFavouriteInList()
    {
        foreach ($this->LibrariesList() as $library) {
            if ($library->default)
                return true;
        }

        return false;
    }

    /**
     * @return null|string
     */
    public function IssueId()
    {
        return $this->issueId;
    }

    /**
     * @return bool
     */
    public function EmptyDlg()
    {
        return isset($this->manifestation);
    }
    
    /**
     * Originale su Manifestation.php
     * 
     * @global type $sc
     * @return boolean
     */
    public function EditionKeyShardReservation() {
        global $sc;
        $query = $this->UrlEditionKeyShard('t');
        if ($query != '') {
            // Query a solr con url già creato
            $mr = new ManifestationRepository(new SolrSearcher($sc->getParameter('lq.baseURL')));
            $r = $mr->getRowCount($query);
            // Verifica se ho almeno una edizione locale
            if ($r > 0) {
                apc_store("shardEdK_" . $this->manifestation->trine_id, $query);
                return TRUE;
            }
        }
        return FALSE;
    }
    
    /**
     * Originale su Manifestation.php
     * 
     * @param type $encoding
     * @return type
     */
    public function UrlEditionKeyShard($encoding = 't') {
        $tot = array();
        // Verifico che esista edition_key nel TBM
        if (($this->manifestation->edition_key != "") && (strpos($this->manifestation->edition_key,'EDKEY') === false)) {
            // Manipolazione della stringa relativa all'edition key da cercare
            if ($encoding == "t") {
                // Per PHP
                $title = str_replace(":", "\\:", str_replace(" ", "\\ ", addslashes(str_replace(" *", "*", rtrim(preg_replace("/\<[^>]+\>/", "*", html_entity_decode($this->manifestation->edition_key, ENT_COMPAT, 'UTF-8')))))));
            } else {
                // Per PHP + JAVASCRIPT
                $title = str_replace(":", "\\\\:", str_replace(" ", "\\\\ ", addslashes(str_replace(" *", "*", rtrim(preg_replace("/\<[^>]+\>/", "*", html_entity_decode($this->manifestation->edition_key, ENT_COMPAT, 'UTF-8')))))));
            }
            $tot["ek"] = 'edition_key:' . $title;
        }
        
        if (isset($this->manifestation->identification_numbers->ean)) {
            $tot["isbn"] = 'fldin_txt_numbers:' . $this->manifestation->identification_numbers->ean;
        } elseif (isset($this->manifestation->identification_numbers->isbn)) {
            $tot["isbn"] = 'fldin_txt_numbers:' . $this->manifestation->identification_numbers->isbn;
        }
        
        // Creo risultato aggiungendo OR se e dove serve
        // Patch Bergamo
        return join(" OR ", $tot) . ' AND (faceti_libvisi:[* TO *] OR (*:* NOT (mrc_d901_sb:m AND (mrc_d901_sd:3 OR mrc_d901_sd:0 OR (*:* -mrc_d901_sd:[* TO *])))) OR (mrc_d901_sa:l02 OR mrc_d980_sb:1)) AND ((*:* NOT mrc_d901_sb:s) OR (mrc_d950_sx:U OR mrc_d950_sx:A OR mrc_d945_sn:[* TO *]))';
//        return join(" OR ", $tot);
    }
}