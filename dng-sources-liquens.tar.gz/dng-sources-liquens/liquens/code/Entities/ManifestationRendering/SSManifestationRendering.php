<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class SSManifestationRendering implements ManifestationRendering
{
    /**
     * @var The name of the ss used in the transformations, without the ss extension
     */
    private $templateBaseName;

    /**
     * An arbitrary set of options
     *
     * @var array
     */
    private $options = array();

    /**
     * @see $templateBaseName
     * @param $tempalteBaseName
     * @param array $options
     */
    public function __construct($tempalteBaseName, $options = array())
    {
        $this->templateBaseName = $tempalteBaseName;
        $this->options = $options;
    }

    /**
     * Transform a Manifestation in a rendered string, like an html snippet of code
     *
     * @param Manifestation $manifestation
     *
     * @return string The manifestation rendered in some format
     */
    public function render(Manifestation $manifestation)
    {
        return $manifestation->renderWith(
            $this->getSS($manifestation)
        );
    }

    /**
     * @param $optionName The name of the option
     * @param $optionValue The value of the option
     *
     * @return \SSManifestationRendering
     */
    public function setOption($optionName, $optionValue)
    {
        $this->options[$optionName] = $optionValue;

        return $this;
    }

    /**
     * Get a an argument to pass to ViewableData->renderWith()
     *
     * @abstract
     * @param Manifestation $manifestation
     *
     * @return array|string the argument to pass to ViewableData
     */
    private function getSS(Manifestation $manifestation)
    {
        //if isset $options[viewtype], we will use the template templatename_viewtype.ss
        $suffix = isset($this->options['view_type'])
            ? '_' . $this->options['view_type']
            : ''
        ;
        $templateName = $this->templateBaseName . $suffix;

        //Array of template names: the first found wins.
        return array($templateName, $this->templateBaseName);
    }
}
