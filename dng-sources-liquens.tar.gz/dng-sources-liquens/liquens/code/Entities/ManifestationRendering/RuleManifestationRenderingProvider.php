<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class RuleManifestationRenderingProvider implements ManifestationRenderingProvider
{
    /**
     * An array of renderingName=>rendering
     *
     * @var array
     */
    private $renderings = array();

    /**
     * A map discriminator => renderingName
     *
     * @var SplObjectStorage
     */
    private $discriminatorsMap;

    /**
     * Peforms parameters initilizations
     */
    public function __construct()
    {
        $this->discriminatorsMap = new SplObjectStorage();
    }

    /**
     * Return a ManifestationRendering from a Manifestation and an optionally options array
     *
     * @param Manifestation $manifestation
     * @param array $options
     * @throws Exception
     * @return ManifestationRendering
     */
    public function getRendering(Manifestation $manifestation, array $options = array())
    {
        $higherSpecificity = 0;
        $winnerRenderingName = null;

        /** @var $discriminator DataObjectDiscriminator */
        foreach($this->discriminatorsMap as $discriminator){
            $renderingName = $this->discriminatorsMap[$discriminator];

            if (! $this->renderingExists($renderingName))
                continue;

            $discriminatorInput = new DataObject(array(
                'manifestation' => $manifestation,
                'options' => new DataObject($options)
            ));

            $specificity = $discriminator->discriminate($discriminatorInput);

            if ($specificity > $higherSpecificity){
                $higherSpecificity = $specificity;
                $winnerRenderingName = $renderingName;
            }
        }

        if (null !== $winnerRenderingName) {
            return $this->renderings[$winnerRenderingName];
        } else {
            throw new Exception('No discriminators matched the Manifestation');
        }
    }

    /**
     * Register a discriminator linked to a renderingName. This means that if that discriminator wins,
     * the rendering with name renderingName will be returned.
     *
     * @param $renderingName
     * @param DataObjectDiscriminator $discriminator
     */
    public function registerDiscriminator($renderingName, DataObjectDiscriminator $discriminator)
    {
        $this->discriminatorsMap[$discriminator] = $renderingName;

        return $this;
    }

    /**
     * Add a rendering to the provider
     *
     * @param $name
     * @param ManifestationRendering $rendering
     * @return ManifestationRenderingProvider
     */
    public function registerRendering($name, ManifestationRendering $rendering)
    {
        $this->renderings[$name] = $rendering;

        return $this;
    }

    /**
     * Remove a rendering from the provider
     *
     * @param $renderingName
     * @return RuleManifestationRenderingProvider
     */
    public function unregisterRendering($renderingName)
    {
        if (isset($this->renderings[$renderingName]))
            unset($this->renderings[$renderingName]);

        return $this;
    }

    /**
     * Check if there is a rendering registered with renderingName
     *
     * @param $renderingName
     * @return bool
     */
    public function renderingExists($renderingName)
    {
        return isset($this->renderings[$renderingName]);
    }

}
