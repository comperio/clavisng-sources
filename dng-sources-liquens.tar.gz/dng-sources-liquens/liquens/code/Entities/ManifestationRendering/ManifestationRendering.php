<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
interface ManifestationRendering
{
    /**
     * Transform a Manifestation in a rendered string, like an html snippet of code
     *
     * @abstract
     * @param Manifestation $manifestation
     *
     * @return string The manifestation rendered in some format
     */
    public function render(Manifestation $manifestation);

    /**
     * @abstract
     * @param $optionName The name of the option
     * @param $optionValue The value of the option
     *
     * @return ManifestationRendering
     */
    public function setOption($optionName, $optionValue);
}
