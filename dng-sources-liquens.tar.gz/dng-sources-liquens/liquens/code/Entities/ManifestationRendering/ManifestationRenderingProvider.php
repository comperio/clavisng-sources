<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

interface ManifestationRenderingProvider
{
    /**
     * @abstract
     * Return a ManifestationRendering from a Manifestation and an optionally options array
     *
     * @param Manifestation $manifestation
     * @param array $options
     * @return ManifestationRendering
     */
    public function getRendering(Manifestation $manifestation, array $options = array());

    /**
     * @abstract
     * @param $name
     * @param ManifestationRendering $rendering
     * @return ManifestationRenderingProvider
     */
    public function registerRendering($name, ManifestationRendering $rendering);
}