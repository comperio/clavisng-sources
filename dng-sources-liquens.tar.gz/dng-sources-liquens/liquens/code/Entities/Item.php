<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class Item extends DataObject
{
    /**
     * @var LibraryRepository
     */
    private $libraryRepository;

    /**
     * Set LibraryRepository
     *
     * @param  $libraryRepository
     *
     * @return Item The current instance
     */
    public function setLibraryRepository($libraryRepository)
    {
        $this->libraryRepository = $libraryRepository;

        return $this;
    }

    /**
     * Get LibraryRepository
     *
     * @return LibraryRepository
     */
    public function getLibraryRepository()
    {
        if (!isset($this->libraryRepository)) {
            global $sc;
            $this->libraryRepository = $sc->get('library.repository');
        }

        return $this->libraryRepository;
    }

    /**
     * Returns the library linked to this item
     *
     * @return Library
     */
    public function getLibrary()
    {
        return $this->getLibraryRepository()->getByExternalId('CLAVIS', $this->library_id);
    }

    /**
     * A viewable Library objecy
     *
     * @return ViewableObject
     */
    public function getViewableLibrary()
    {
        if ($this->id)
            return new ViewableObject($this->getLibrary());
        else
            return false;
    }
}
