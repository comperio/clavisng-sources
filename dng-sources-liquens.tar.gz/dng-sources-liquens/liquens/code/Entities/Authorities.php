<?php

/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class Authorities extends DataObjectSet {

    public function getGroupByType($type) {
        return $this->find('type', $type);
    }

    public function getGroupList() {
        $groups = new DataObject();
        
        foreach ($this as $group) {
            if (!$groups->hasField($group->type))
                $groups->setField($group->type, true);
        }

        return $groups;
    }

    public function getFusedKS() {
        global $sc;
        if ($sc->getParameter('fusion_KS') != false) {
            return true;
        } else {
            return false;
        }
    }
    
}
