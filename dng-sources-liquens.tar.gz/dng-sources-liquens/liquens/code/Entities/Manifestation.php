<?php

/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class Manifestation extends DataObject {

    /**
     * @var ManifestationRendering
     */
    private $rendering;

    /**
     * Tell if the manifestation is an extra-system
     *
     * @var DataObjectDiscriminator
     */
    private $extraDiscriminator;

    /**
     * @var DataObjectDiscriminator
     */
    private $reservationDiscriminator;

    /**
     * @var DataObjectDiscriminator
     */
    private $extraReservationDiscriminator;

    /**
     * Overload constructor to load injections
     *
     * @param null $record
     * @param bool $isSingleton
     */
    public function __construct($record = null, $isSingleton = false) {
        parent::__construct($record, $isSingleton);

        global $sc;
        Kernel::load_injections($this, $sc);
    }

    /**
     * @static
     * @param $manifestationId
     * @return string
     */
    public static function default_detail_url($manifestationId) {
        return 'opac/detail/view/' . $manifestationId;
    }

    public function GeoTagManifestationActive() {
        global $sc;
        if ($sc->getParameter('geotagging') != false) {
            return true;
        } else {
            return false;
        }
    }

    public function isGeotagged() {
        if ($this->geoTaggedCount() > 0) {
            return true;
        }
        return false;
    }

    public function geoTaggedCount() {
        $query = "SELECT count(*) FROM Post WHERE `ManifestationID` = '" . $this->trine_id . "' AND `IsGeotag` = 1";
        return DB::query($query)->value();
    }

    public function getGeoTag() {
//        $count = DB::query("SELECT count(*) FROM Post WHERE `ManifestationID` = '".$this->trine_id."'")->value();
        $doSet = new DataObjectSet();
        $tags = array('t' => array());
        $geoTags = DataObject::get("Post", "`ManifestationID` = '" . $this->trine_id . "'");
        foreach ($geoTags as $tag) {
            $tags['t']['lat'] = $tag->CenterLat;
            $tags['t']['lon'] = $tag->CenterLon;
            $doSet->push(new ArrayData($tags));
        }
        return $doSet;
    }

    public function isGeotaggedPost() {
        if (DB::query("SELECT count(*) FROM Post WHERE `ID` = '" . Controller::curr()->PostID() . "' AND `IsGeotag` = 1")->value() > 0) {
            return true;
        }
        return false;
    }

    public function getGeoTagPost() {
        $geoTags = DB::query("SELECT * FROM Post WHERE `ID` = '" . Controller::curr()->PostID() . "'")->first();
        if (($geoTags['IsGeotag'] != 0)) {
            return $geoTags['CenterLat'] . '_' . $geoTags['CenterLon'] . '_' . Controller::curr()->PostID() . '_' . $geoTags['GeoType'];
        }
        return '';
    }

    public function getGeoTagPostId() {
        return Controller::curr()->PostID();
    }

    /**
     * Manipulate cover_title and cover_author fields, in such a way the sum of the
     * strlens of the two fields dows not exceeds 80 chars, and without
     * truncating words
     *
     * @param int $maxChars
     * @return ArrayData
     */
    public function getTruncatedCoverInfos($maxChars = 80) {
        $wrappedTruncation = function($string, $length) {
            $wrapped = wordwrap($string, $length, '<?!#>');
            $pieces = explode('<?!#>', $wrapped);

            return $pieces[0];
        };

        //Store cover data
        $coverTitleTruncated = $wrappedTruncation($this->cover_title, $maxChars);
        $coverAuthorTruncated = '';

        if (isset($this->cover_author)) {
            $coverAuthorTruncated = $wrappedTruncation($this->cover_author, $maxChars - strlen($coverTitleTruncated));
        }

        return new ArrayData(array(
            'Title' => $coverTitleTruncated,
            'Author' => $coverAuthorTruncated
        ));
    }

    /**
     * Returns the url of the cover image, using the coverserverurl if the
     * manifestation has no cover_url field
     *
     * @return string
     */
    public function getCoverUrl() {
        LQConfig::get('coverServerUrl');

        if (isset($this->cover_url)) {
            return $this->cover_url;
        }

        $id = 'fake-ean';

        if (isset($this->identification_numbers->ean)) {
            $id = $this->identification_numbers->ean;
        } elseif (isset($this->identification_numbers->isbn)) {
            $id = $this->identification_numbers->isbn;
        }

        return LQConfig::get('coverServerUrl') . $id;
    }

    public function getEan() {
        if (isset($this->identification_numbers->ean)) {
            return $this->identification_numbers->ean;
        } elseif (isset($this->identification_numbers->isbn)) {
            return $this->identification_numbers->isbn;
        } else {
            return 0;
        }
    }

    public function getLeggereBuy() {
        global $sc;
        return $sc->getParameter('leggereBuy.active') ? 1 : 0;
    }

    public function getLeggereBuyCode() {
        global $sc;
        return (string) $sc->getParameter('leggereBuy.code');
    }

    public function getLeggereBuyColor() {
        global $sc;
        return (string) $sc->getParameter('leggereBuy.color');
    }

    public function getLeggereBuyUrl() {
        global $sc;
        return $sc->getParameter('leggereBuy.url');
    }

    /**
     * EXPERIMENTAL (POMPOSA)
     * Check the leader of the record to get the entity type when is set
     * ' ' = bibliographic entity
     * 'a' = archivistic entity
     * 
     */
    public function entityType() {
        if ($this->entity_type != ' ' ) {
            return $this->entity_type;
        } else {
            return 0;
        }
    }

    /**
     * Return a number between 1 and max based on the manifestation id number
     *
     * @param int $base
     * @return int
     */
    public function getIdModule($base = 8) {
        return ((int) $this->external_id % $base) + 1;
    }

    /**
     * @return mixed
     */
    public function getId() {
        return $this->external_id;
    }

    /**
     * Returns the id of the form database:catalog:id
     * @return string
     */
    public function getTrineId() {
        return isset($this->trine_id) ? $this->trine_id : '';
    }

    /**
     * @return array
     */
    public function toArray($object = null) {
        if (!isset($object)) {
            $object = $this;
        }

        if (is_object($object) && method_exists($object, 'getValue')) {
            return $object->getValue();
        }

        $map = array();

        if ($object instanceof DataObject) {
            $objectToIterateOn = $object->toMap();
        } elseif ($object instanceof DataObjectSet) {
            $objectToIterateOn = $object;
        } else {
            return (string) $object;
        }

        foreach ($objectToIterateOn as $key => $value) {
            if (is_object($value) && $key != 'ParentNode') {
                $map[$key] = $this->toArray($value);
            } else {
                $map[$key] = $value;
            }
        }

        return $map;
    }

    /**
     * Build the url to the manifestation page
     *
     * @param string $baseUrl
     * @return string
     */
    public function getUrl() {
        return $this->default_detail_url($this->getTrineId());
    }

    /**
     * Truncate the title to $chars characters
     *
     * @param int $chars
     * @return string
     */
    public function getTruncatedTitle($chars = 110) {
        if (strlen($this->full_title) > $chars) {
            return substr($this->full_title, 0, $chars) . '...';
        }

        return $this->full_title;
    }

    /**
     * Check if the Manifestation is a magazine or not
     *
     * @return bool
     */
    public function isMagazine() {
        return $this->bibliographic_type->type == 's';
    }

    public function isMonography() {
        return $this->bibliographic_type->type == 'm';
    }

    public function getMonographyReserve() {
        return $this->isMonography() == 'm' ? 1 : 0;
    }

    public function getSmartReserve() {
        global $sc;
        return $sc->getParameter('other_editions_loans') ? 1 : 0;
    }

    public function getIssueSrv() {
        global $sc;
        if ($sc->getParameter('issueSrv_url') != false)
            return $sc->getParameter('issueSrv_url') . "?type=s&manID=" . $this->getTrineId();
        return 0;
    }

//    public function getIssueFromTurbomarc() {
//        if (isset($this->cover_url) || isset($this->images)) {
//            global $sc;
//            return $sc->getParameter('issueSrv_url') . "?type=d&manID=" . $this->getTrineId();
//        } else {
//            return json_encode(['result' => false]);
//        }
//    }

    public function getItemIconsArray() {
        $icons = array();
        foreach($this->items as $item) {
            if (($item->item_icon != '') && ($item->item_icon != '000'))
                $icons[$this->getItemIconsUrl().$item->item_icon.".png"] = "";
        }
        if (!empty($icons)) {
            $doSet = new DataObjectSet();
            $tags = array('i' => array());
            foreach ($icons as $key => $icon) {
                $tags['i']['html'] = '<img src="'.$key.'" alt="" style="display:inline; border:0px; background-color:transparent; width:50px; height:50px; float:right; margin-left: 5px;">';
                $doSet->push(new ArrayData($tags));
            }
            return $doSet;
        }
        return false;
    }
    
    public function getItemIcons() {
        global $sc;
        if ($sc->getParameter('itemIcon_Url') != false) {
            if (isset($this->items)) {
                $icons = array();
                foreach($this->items as $item) {
                    if (($item->item_icon != '') && ($item->item_icon != '000'))
                        $icons[$this->getItemIconsUrl().$item->item_icon.".png"] = "";
                }
                if (empty($icons))
                    return 0;
                return 1;
            }
        }
        return 0;
    }
    
    public function getItemIconsUrl() {
        global $sc;
        return $sc->getParameter('itemIcon_Url');
    }
    
    /**
     * Check loanable_since Date. If it is in the past or it is not set, return true.
     * Return false otherwise
     *
     * @return bool
     */
    public function isLoanable() {
        //$this->loanable_since->setValue(strtotime("+2 day"));

        if ($this->loanable_since) {
            return !$this->loanable_since->InFuture();
        }

        return true;
    }

    public function isShard() {
        //Extra discriminator looks to manifestation field
        $dataObject = new DataObject();
        $dataObject->manifestation = $this;

        return (bool) $this->getShardDiscriminator()->discriminate($dataObject);
    }

    /**
     * Is the manifestation an extra catalog?
     *
     * @return bool
     */
    public function isExtra() {
        //Extra discriminator looks to manifestation field
        $dataObject = new DataObject();
        $dataObject->manifestation = $this;

        return (bool) $this->getExtraDiscriminator()->discriminate($dataObject);
    }

    /**
     * Is the manifestation a MLOL record?
     *
     * @return bool
     */
    public function isMLOL() {
        return $this->mlol;
    }

    public function multiMlolActive() {
        global $sc;
        if ($sc->getParameter('mlol.multi.active') == true) {
            return true;
        }
        return false;
    }
    
    public function multiMlolUrl() {
        if ($this->multiMlolActive()) {
            global $sc;
            $result =  new DataObjectSet();
            foreach ($sc->getParameter('mlol.multi.url') as $value) {
                list($nome, $url) = explode("|", $value);
                $result->push(new DataObject(
                        array(
                            'nome' => $nome, 
                            'url' => $url.$this->external_id
                            )
                ));
            }
            return $result;
        }
        return false;
    }
    
    /**
     * Returns true if the manifestation has issues or has consistency notes.
     *
     * @return bool
     */
    public function hasIssuesOrNotes() {
        return
                $this->issues && $this->issues->Count() ||
                $this->consistency_notes && $this->consistency_notes->Count()
        ;
    }

    /**
     * Does DNG consider this manifestation reservable?
     *
     * @return bool
     */
    public function isOpacReservable() {
        $result = new DataObject();
        $result->Value = true;
        $result->Label = false;

        if ($this->getActualReservationDiscriminator()->discriminate($this) == 0) {
            $result->Value = false;
            $result->Label = $this->getActualReservationDiscriminator()->getFailedCondition();

            return $result;
        }

        //$this->loanable_since->setValue(strtotime("+2 day"));
        if ($this->loanable_since) {
            $loanableSinceTimestamp = strtotime($this->loanable_since->getValue());

            $interval = time() - $loanableSinceTimestamp + LQConfig::get('reservable_days_interval') * 24 * 3600;

            $result->Value = $interval > 0;
            $result->Label = 'Il titolo non può essere attualmente prenotato.';

            return $result;
        }

        return $result;
    }

    public function getActiveSendEmail() {
        $ShardActiveEmailButton = DataObject::get_one('SiteConfig')->ShardActiveEmailButton;
        if ($ShardActiveEmailButton == 1)
            return true;
        return false;
    }
    
    
    /**
     * Esegue la query a solr per lo shard e verifica che esista almeno 1 edizione
     * 
     * @return type
     */
    public function getEditionKeyShard() {
        return $this->getEditionKey(0);
    }

    /**
     * Esegue la query a solr e verifica che esista più di 1 edizione
     * Copia su ReserveDialog.php
     * 
     * @return boolean
     */
    public function getEditionKey($n = 1) {
        $query = $this->getUrlEditionKey('t');
        if ($query != '') {
            // Query a solr con url già creato
            global $sc;
            $mr = new ManifestationRepository(new SolrSearcher($sc->getParameter('lq.baseURL')));
            $r = $mr->getRowCount($query);
            // Verifica se ho almeno una edizione locale
            if ($r > $n) {
                apc_store("shardEdK_" . $this->trine_id, $query);
                return TRUE;
            }
        }
        return FALSE;
    }

    /**
     * Crea la query per solr
     * Copia su ReserveDialog
     * 
     * @return type
     */
    public function getUrlEditionKey($encoding = 'l') {
        $tot = array();
        // Verifico che esista edition_key nel TBM
        if (($this->edition_key != "")  && (strpos($this->edition_key,'EDKEY') === false)) {
            // Manipolazione della stringa relativa all'edition key da cercare
            if ($encoding == "t") {
                // Per PHP
                $title = str_replace(":", "\\:", str_replace(" ", "\\ ", addslashes(str_replace(" *", "*", rtrim(preg_replace("/\<[^>]+\>/", "*", html_entity_decode($this->edition_key, ENT_COMPAT, 'UTF-8')))))));
            } else {
                // Per PHP + JAVASCRIPT
                $title = str_replace(":", "\\\\:", str_replace(" ", "\\\\ ", addslashes(str_replace(" *", "*", rtrim(preg_replace("/\<[^>]+\>/", "*", html_entity_decode($this->edition_key, ENT_COMPAT, 'UTF-8')))))));
            }

            $tot["ek"] = 'edition_key:' . $title;
            $tot["ek"] = str_replace("]", "\]", str_replace("[", "\[", $tot["ek"]));
            
        }
        // Verifico che esistano delle opere e ne faccio AND degli ID
        if (isset($this->record["works"])) {
            $id = array();
            foreach ($this->record["works"] as $key => $record) {
                $id[$key] = "mrc_d500_s3:" . $this->record["works"]->items[$key]->record["id"];
            }
            $tot["ids"] = "(" . join(" AND ", $id) . ")";
        }
        
        if (isset($this->identification_numbers->ean)) {
            $tot["isbn"] = 'fldin_txt_numbers:' . $this->identification_numbers->ean;
        } elseif (isset($this->identification_numbers->isbn)) {
            $tot["isbn"] = 'fldin_txt_numbers:' . $this->identification_numbers->isbn;
        }
        
        // Creo risultato aggiungendo OR se e dove serve
        return join(" OR ", $tot);
    }

    /**
     * Returns the turbomarc as a formatted string
     *
     * @return string|boolean
     */
    public function getTurbomarc() {
        if (isset($this->sourceXml)) {
            $dom = new DOMDocument();
            $dom->loadXML($this->sourceXml);
            $dom->formatOutput = true;
            return htmlentities($dom->saveXML());
        }

        return false;
    }

    /**
     * Returns a reserve dialog for this manifestation
     * @return ReserveDialog
     */
    public function getReserveDialog($issueId = null) {
        if (LQConfig::get('dngFlags', 'users') && LQConfig::get('dngFlags', 'reservations')) {
            return new ReserveDialog(Member::currentUser(), $this, $issueId);
        } else {
            return false;
        }
    }

    public function Top() {
        return $this->dTop();
    }

    /**
     * Inject the ManifestationRendering object
     *
     * @param ManifestationRendering $rendering
     */
    public function setRendering(ManifestationRendering $rendering) {
        $this->rendering = $rendering;
    }

    /**
     * If the $rendering is defined, render this manifestation into a string
     *
     * @return string
     * @throws Exception
     */
    public function getRenderedManifestation() {
        if (!isset($this->rendering)) {
            throw new Exception('Rendering not defined');
        }

        return $this->rendering->render($this);
    }

    /**
     * @return \DataObjectDiscriminator
     */
    public function getActualReservationDiscriminator() {
        if ($this->isExtra()) {
            return $this->getExtraReservationDiscriminator();
        } elseif ($this->isShard()) {
            return $this->getShardReservationDiscriminator();
        } else {
            return $this->getReservationDiscriminator();
        }
    }

    /**
     * @param \DataObjectDiscriminator $reservationDiscriminator
     *
     * @return Manifestation the current instance
     */
    public function setReservationDiscriminator($reservationDiscriminator) {
        $this->reservationDiscriminator = $reservationDiscriminator;

        return $this;
    }

    /**
     * @return \DataObjectDiscriminator
     */
    public function getReservationDiscriminator() {
        return $this->reservationDiscriminator;
    }

    /**
     * Set ExtraReservationDiscriminator
     *
     * @param \DataObjectDiscriminator $extraReservationDiscriminator
     *
     * @return Manifestation The current instance
     */
    public function setExtraReservationDiscriminator(\DataObjectDiscriminator $extraReservationDiscriminator) {
        $this->extraReservationDiscriminator = $extraReservationDiscriminator;

        return $this;
    }

    /**
     * Get ExtraReservationDiscriminator
     *
     * @return \DataObjectDiscriminator
     */
    public function getExtraReservationDiscriminator() {
        return $this->extraReservationDiscriminator;
    }

    /**
     * Set ExtraDiscriminator
     *
     * @param \DataObjectDiscriminator $extraDiscriminator
     *
     * @return Manifestation The current instance
     */
    public function setExtraDiscriminator(\DataObjectDiscriminator $extraDiscriminator) {
        $this->extraDiscriminator = $extraDiscriminator;

        return $this;
    }

    /**
     * Get ExtraDiscriminator
     *
     * @return \DataObjectDiscriminator
     */
    public function getExtraDiscriminator() {
        return $this->extraDiscriminator;
    }

    private $shardReservationDiscriminator;
    private $shardDiscriminator;

    public function setShardReservationDiscriminator(\DataObjectDiscriminator $shardReservationDiscriminator) {
        $this->shardReservationDiscriminator = $shardReservationDiscriminator;

        return $this;
    }

    public function getShardReservationDiscriminator() {
        return $this->shardReservationDiscriminator;
    }

    public function setShardDiscriminator(\DataObjectDiscriminator $shardDiscriminator) {
        $this->shardDiscriminator = $shardDiscriminator;

        return $this;
    }

    public function getShardDiscriminator() {
        return $this->shardDiscriminator;
    }

    public function shardName($m_id = null) {
        global $sc;
        $key = $sc->getParameter('lq.solrDatabase') . "_shards";
        if (apc_exists($key)) {
            if (!is_null($m_id)) {
                $equal = $m_id;
            } else {
                $equal = $this->trine_id;
            }
            $shards = unserialize(apc_fetch($key));
            foreach ($shards as $shard) {
                if (explode("#", $shard)[3] == explode(":", $equal)[0]) {
                    return explode("#", $shard)[0];
                }
            }
        }
    }

    public function shardLink() {
        global $sc;
        $key = $sc->getParameter('lq.solrDatabase') . "_shards";
        if (apc_exists($key)) {
            $shards = unserialize(apc_fetch($key));
            foreach ($shards as $shard) {
                if (explode("#", $shard)[3] == explode(":", $this->trine_id)[0]) {
                    return explode("#", $shard)[2] . "opac/detail/view/" . $this->trine_id;
                }
            }
        }
    }
    
    public function shardString() {
        return (string) DataObject::get_one('SiteConfig')->EditionKeyOtherSystemString;
    }

}
