<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

/**
 * This Driver is used to enrich a set of Manifestation objects with DNG-specific data, like
 * comments, shelves and ratings.
 *
 * Options: through the constructor, or the @see setOption() method, you can specify what fields
 * to add to the manifestations.
 *
 * These are the currently supported options
 *   * comments => true
 *          load comments_count into comments_cound field
 *   * shelves => true
 *          load current member data for shelves into shelves_data field. @see loadShelvesData()
 *   * average_rating => true
 *          load average rating into average_rating field (@see loadAverageRatings). Require
 *          a RatingService setted through @see setRatingService
 *   * member_ratings => true
 *          load current member ratings for each manifestations into curr_member_rating field.
 *          Require a RatingService setted through @see setRatingService
 */
class DngManifestationEnrichment implements ManifestationDriver
{
    /**
     * Options used in @see loadEnrichmentData()
     * @var array options
     */
    private $options = array();

    /**
     * @var RatingService
     */
    private $ratingService;

    /**
     * @param array $options an array of options
     */
    public function __construct($options = array())
    {
        $this->options = $options;
    }

    /**
     * Inject a RatingService used to retrieve ratings infos.
     *
     * @param RatingService $ratingService
     *
     * @return DngManifestationEnrichment
     */
    public function setRatingService(RatingService $ratingService)
    {
        $this->ratingService = $ratingService;

        return $this;
    }

    /**
     * Fill a set of manifestations with extra datas
     *
     * @param $manfestations
     * @param $dataSources
     */
    public function fillManifestations($manfestations, array $dataSources = array())
    {
        $this->loadEnrichmentData($manfestations);
    }

    /**
     * Fill a manifestation with extra data
     *
     * @param $dataSource
     * @param Manifestation $manifestation
     *
     * @return Manifestation
     */
    public function fillManifestation(Manifestation $manifestation, $dataSource = array())
    {
        $this->fillManifestations(array($manifestation), array($manifestation->getId() => $dataSource));
    }

    /**
     * Performs the manifestations enrichment
     *
     * @param $manifestations
     */
    private function loadEnrichmentData($manifestations)
    {
        $trineIds = $this->getManifestationsIds($manifestations, true);

        if (isset($this->options['comments']) && $this->options['comments'])
            $this->loadCommentCounts($manifestations, $trineIds);

        if (isset($this->options['shelves']) && $this->options['shelves'])
            $this->loadShelvesData($manifestations);

        if (isset($this->options['average_rating']) && $this->options['average_rating'])
            $this->loadAverageRatings($manifestations, $trineIds);

        if (isset($this->options['member_ratings']) && $this->options['member_ratings'])
            $this->loadCurrMemberRatings($manifestations, $trineIds);

        if (isset($this->options['DAI']) && $this->options['DAI'])
            $this->loadDaiFlags($manifestations);

    }

    /**
     * Load total comments for each manifestations
     *
     * @param $manifestations
     * @param array $trineIds The array of Manifestations Ids in the form db:catalog:id
     * @return array
     */
    private function loadCommentCounts($manifestations, $trineIds)
    {
        $numbers = array();
        $idsString = "'" . implode("', '", array_map(array('Convert', 'raw2sql'), $trineIds)) . "'";
        $query = Db::query(
            "SELECT  ManifestationID, COUNT(ManifestationID) AS Total from Post
                WHERE ManifestationID IN ($idsString)
                GROUP BY ManifestationID"
        );

        //Build an array ManifestationID => Total
        $map = $query->map();

        foreach ($manifestations as $manifestation){
            if (isset($map[$manifestation->getTrineID()])){
                $manifestation->comments_count = $map[$manifestation->getTrineID()];
            } else {
                $manifestation->comments_count = 0;
            }
        }

        return $numbers;
    }

    /**
     * Load shelves data into each manifestation
     *
     * @param $manifestations
     */
    private function loadShelvesData($manifestations)
    {
        $shelves = Shelf::get_shelves_for_owner(Member::currentUser(), 'ManifestationsShelf');

        //Add information about shelves
        //foreach ($this->manifestationsInfos as $manId => &$info) {
        foreach($manifestations as $manifestation){
            $trineId = $manifestation->getTrineId();
            $shelvesData = array();
            $shelvesCount = 0;

            /** @var $shelf ManifestationsShelf */
            foreach($shelves as $shelf){
                $inShelf = $shelf->isManifestationInShelf($trineId);

                $shelvesData[] = array(
                    'shelf' => $shelf,
                    'in_shelf' => $inShelf,
                    'id' => $trineId
                );

                if ($inShelf)
                    $shelvesCount++;
            }

            $manifestation->shelves_count = $shelvesCount;
            $manifestation->shelves_data = new DataObjectSet($shelvesData);
        }
    }

    /**
     * Load average ratings infos into each manifestation
     * Require a RatingService setted through @see setRatingService
     *
     * @param $manifestations
     *
     * @return mixed
     */
    private function loadAverageRatings($manifestations, $trineIds)
    {
        if (!$this->ratingService)
            return;

        $ratingInfos = $this->ratingService->getRatingsInfos(
             RatingType::get_by_name('star'),
            'Manifestation',
            $trineIds
        );

        foreach ($manifestations as $manifestation ){
            $averageRating = new DataObject();
            if (isset($ratingInfos[$manifestation->getTrineId()])){
                $ratingInfo = $ratingInfos[$manifestation->getTrineId()];

                $averageRating->Value = (int) ($ratingInfo['average']);
                $averageRating->Count = $ratingInfo['count'];
            } else {
                $averageRating->Value = 0;
                $averageRating->Count = 0;
            }

            $manifestation->average_rating = $averageRating;
        }
    }

    /**
     * For each manifestation, load a past rating performed by the member to the manifestation
     * Require a RatingService setted through @see setRatingService.
     *
     * @param $manifestations
     * @param $trineIds
     *
     * @return mixed
     */
    private function loadCurrMemberRatings($manifestations, $trineIds)
    {
        if (!$this->ratingService)
            return;

        $ratings = $this->ratingService->getRatings(
            Member::currentUser(),
            RatingType::get_by_name('star'),
            'Manifestation',
            $trineIds
        );

        /** @var $manifestation Manifestation */
        if ($ratings){
            foreach ($manifestations as $manifestation){
                /** @var $rating Rating */
                $rating = $ratings->find('RatedId', $manifestation->getTrineId());

                if ($rating)
                    $manifestation->curr_member_rating = $rating;
            }
        }
    }

    /**
     * Perform an xmlRpc call to ambrosiana rpc
     *
     * @param $manifestations
     */
    private function loadDaiFlags($manifestations)
    {
        $client = new Zend_XmlRpc_Client('http://dai.ambrosiana.eu/navrpc');

        /** @var $manifestation Manifestation */
        foreach ($manifestations as $manifestation){
            if ($manifestation->items && $manifestation->items->Count()){
                $item = $manifestation->items->First();

                try {
                    $ret = $client->call('nav_rpc.xml_exist_external', Array('MI0133', '2', '', $item->collocation));
                } catch(Exception $e) {
                    $ret = false;
                }

                if ($ret !== false) {
                    $manifestation->DAILink = sprintf(
                        "http://dai.ambrosiana.eu/nav/info?f1stId=&resId=&s2ndId=%s&agency=MI0133&agencyType=2&submitType=external",
                        urlencode($item->collocation)
                    );
                } else {
                    $manifestation->DAIRequest = sprintf(
                        "https://store.codex2.cineca.it/store#/reqDigitization?altagency=MI0133&amp;title=%s&amp;author=%s&amp;id=%s&amp;shelfmark=%s",
                        urlencode($manifestation->cover_title),
                        urlencode($manifestation->full_author),
                        urlencode($manifestation->getId()),
                        urlencode($item->collocation)
                    );
                }
            }
        }
    }

    /**
     * Returns an array of ids of a set of manifestations
     *
     * @param $manifestations
     * @param bool|string $trine
     * @return array
     */
    private function getManifestationsIds($manifestations, $trine = false)
    {
        $ids = array();

        foreach ($manifestations as $manifestation){
            if ($trine)
                $ids[] = $manifestation->getTrineId();
            else
                $ids[] = $manifestation->getId();
        }

        return $ids;
    }

    /**
     * Set an option
     *
     * @param $optionName
     * @param $optionValue
     */
    public function setOption($optionName, $optionValue)
    {
        $this->options[$optionName] = $optionValue;
    }

    /**
     * Overwrite options with $options
     *
     * @param array $options
     *
     * @return \DngManifestationEnrichment
     */
    public function setOptions($options)
    {
        $this->options = $options;

        return $this;
    }

    /**
     * Get current options
     *
     * @return array
     */
    public function getOptions()
    {
        return $this->options;
    }
}
