<?php

/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class XslManifestationDriver implements ManifestationDriver {

    /**
     * @var array
     */
    private $valueMap = array();

    /**
     * The Xsl used for the transformation
     *
     * @var string
     */
    private $xsl;

    /**
     * @var XSLTProcessor
     */
    private $xslt;

    /**
     * @var boolean
     */
    private $attachSourceXml;

    /**
     * When hydrating from the transformed xml, when the driver founds a node
     * which name is a key in this array, it creates, instead of a string/DataObject/DataObjectSet,
     * an instance of a class with name equal to item's value
     *
     * @var array
     */
    private static $hydration_map = array(
        'authorities' => 'Authorities',
        'item' => 'Item',
        'issues' => 'IssueSet',
        'issue' => 'Issue',
        'linked_titles_group' => 'LinkedTitlesGroup',
        'manifestation' => 'Manifestation',
        'date_lastinv' => 'SS_Datetime'
    );

    /**
     * This parameter will be passed to the xsl as the $simple parameter, and it is intended
     * to tell to the xslt transformation to return a "simplified" version of the xml
     *
     * @var bool
     */
    private $simple = false;

    /**
     * @param string $xsl The xsl to use in the transformation
     */
    public function __construct($xsl, $attachSourceXml = false) {
        $this->xsl = BASE_PATH . DIRECTORY_SEPARATOR . $xsl;
        $this->attachSourceXml = (bool) $attachSourceXml;

        $xsl = new DomDocument();
        $xsl->load($this->xsl);

        $xslt = new XSLTProcessor();
        $xslt->importStylesheet($xsl);
        $xslt->registerPHPFunctions();

        $this->xslt = $xslt;

        //Register Date map
        $this->addValueMap('date', array($this, 'getDate'));
    }

    /**
     * Convert a node to a Date object
     *
     * @param SimpleXmlNode $node
     * @return Date
     */
    private function getDate(SimpleXmlElement $node) {
        $date = new Date();
        $dateString = (string) $node;

        //String in yyyymmdd format
        if (strpos($dateString, '-') === false && strlen($dateString) == 8) {
            $dateString = substr($dateString, 0, 4) . '-' . substr($dateString, 4, 2) . '-' . substr($dateString, 6, 2);
        }

        $date->setValue((string) $dateString);

        return $date;
    }

    /**
     * Add a map to the driver
     * $key must be the value of _map-name attribute of the node in the generated xml
     * $map can be an array or a callable
     *
     * If $map is an array, it means that it will transform a xml node to the value of $map[$node['_map-key']]
     * Example:
     * <code>
     *      <text _map-name="language" _map-key="it" />
     * </code>
     * And we add the map
     * <code>
     *  $this->addValueMap('language', array('en' => 'English', 'it' => 'Italiano')
     * </code>
     * Then
     * <code>
     *  $this->getMappedValue('language', $node);
     * </code>
     * will return 'Italiano'
     *
     * If $map is a callable:
     * <code>
     *  $this->addValueMap('capitalize', function(SimpleXmlNode $node){return strtoupper((string) $node;}
     * </code>
     * If the node is
     * <code>
     *  <text _map-name="capitalize">Hellooooo!!!</text>
     * </code>
     *  then
     * <code>
     *  $this->getMappedValue('language', $node);
     * </code>
     * will return "HELLOOOOO!!!"
     *
     * @param string $key
     * @param closure|array $map
     * @return XslManifestationDriver
     */
    public function addValueMap($key, $map) {
        if (!is_array($map) && !is_callable($map))
            throw new InvalidArgumentException('Map must be an array or a callable object');

        $this->valueMap[$key] = $map;

        return $this;
    }

    /**
     * Given a mapname, convert a node using that map
     * @see addValueMap
     *
     * @param string $mapName
     * @param SimpleXMLElement $node
     * @return bool|mixed|string
     */
    public function getMappedValue($mapName, SimpleXMLElement $node) {
        if (isset($this->valueMap[$mapName])) {
            $map = $this->valueMap[$mapName];

            if (is_callable($map)) {
                return call_user_func($map, $node);
            } elseif (is_array($map)) {
                $mapKey = (string) $node['_map-key'];
                return isset($map[$mapKey]) ? $map[$mapKey] : $mapKey;
            }
        }

        return false;
    }

    /**
     * Check if the node has the _map-name attribute. If so, returns the mapped value.
     *
     * @param SimpleXMLElement $node
     * @return bool|mixed|string
     */
    private function getMappedValueIfMapSpecified(SimpleXMLElement $node) {
        if (isset($node['_map-name'])) {
            return $this->getMappedValue((string) $node['_map-name'], $node);
        }

        return htmlspecialchars((string) $node);
    }

    /**
     * Apply the xsl transformation to the source xml and returns the transformed xml
     * into a SimpleXML object
     *
     * @param string $solrData
     * @return SimpleXML
     */
    private function getTransformedXml($solrData) {
        $this->addParametersToXslt($this->xslt);
        $sourceXml = $solrData['solr_doc']['turbo_marc'];
        $xmlDOM = new DOMDocument();
        $xmlDOM->loadXML($sourceXml);
        $r = $xmlDOM->getElementsByTagName('r')->item(0);

        // Estrazione edizioni per la manifestation
        $editionKey = NULL;
        if ((isset($solrData['solr_doc']['edition_key'])) && (array_key_exists('edition_key', $solrData['solr_doc']))) {
            $pulita = str_replace('&', '&amp;', $solrData['solr_doc']['edition_key']);
            $editionKey = $xmlDOM->createElement('edition_key', $pulita);
            $r->appendChild($editionKey);
        }

        //Add solr database and catalog data
        $solrData = $this->getSolrDatabaseAndCatalog($solrData['solr_doc']['id']);
        $databaseElement = $xmlDOM->createElement('solr_database', $solrData['database']);
        $catalogElement = $xmlDOM->createElement('solr_catalog', $solrData['catalog']);

        /* Verifico se è presente SHARD in APC */
        global $sc;
        $key = $sc->getParameter('lq.solrDatabase') . "_shards";
        if (apc_exists($key)) {
            $shards = unserialize(apc_fetch($key));
            foreach ($shards as $shard) {
                if (explode("#", $shard)[3] == $solrData['database']) {
                    /* Se esiste il core diverso dall'originale, cambio la collection */
                    $catalogElement = $xmlDOM->createElement('solr_catalog', "shard");
                }
            }
        }

        $r->appendChild($databaseElement);
        $r->appendChild($catalogElement);

        $xmlDOM->formatOutput = true;
        //Debug::dump(htmlspecialchars($xmlDOM->saveXML()));

        $resultDOM = $this->xslt->transformToDoc($xmlDOM);
        $resultDOM->formatOutput = true;

        #Debug::dump(htmlspecialchars($resultDOM->saveXML()));

        return simplexml_import_dom($resultDOM);
    }

    /**
     * Extract SolrDatabase and SolrCatalog from a string of the form
     * "solr_database:solr_catalog:xxx"
     *
     * Returns an array of the form
     * <code>
     * array(
     *      'database' => solr_database,
     *      'catalog' => solr_catalog,
     * );
     * </code>
     * @param $trineId
     * @return array
     */
    private function getSolrDatabaseAndCatalog($trineId) {
        $pieces = explode(':', $trineId);

        return array(
            'database' => isset($pieces[0]) ? $pieces[0] : '',
            'catalog' => $pieces[1] ? $pieces[1] : $pieces[1],
        );
    }

    /**
     * Add some parameter to the XSLT processor
     *
     * @param XSLTProcessor $xslt
     * @return XslManifestationDriver
     */
    private function addParametersToXslt(XSLTProcessor $xslt) {
        $xslt->setParameter('', 'simple', $this->getSimple());

        return $this;
    }

    /**
     * Get a Manifestation object from an arbitrary data source.
     *
     * @param \Manifestation $manifestation
     * @param $dataSource
     *
     * @return Manifestation
     */
    public function fillManifestation(Manifestation $manifestation, $dataSource = array()) {
        $xml = $this->getTransformedXml($dataSource);

        $manifestation = $this->convertNode($xml, $manifestation);

        $manifestation->trine_id = $dataSource['solr_doc']['id'];

        if ($this->attachSourceXml) {
            $manifestation->sourceXml = $dataSource['solr_doc']['turbo_marc'];
        }

        //set the due date next only if onloan_items = total_items
        if (isset($manifestation->due_date_next)) {
            if ($manifestation->onloan_items != $manifestation->total_items) {
                $manifestation->due_date_next = null;
            }
        }

        // Rielaborazione note notizia con titolo e raggruppamento (Pomposa)
        $manifestation->full_notes = $manifestation->notes;
        if (!is_null($manifestation->full_notes)) {
            $group_notes = array();
            foreach ($manifestation->full_notes as $notes) {
                $note_number = (int) filter_var($notes->note_name, FILTER_SANITIZE_NUMBER_INT);  
                $tag_name = _t('LV_UNI3XX.' . $note_number);
                $tag_original = $notes->note_name;
                if ($tag_name != '') {
                    $notes->note_name = $tag_name;
                }
                $group_notes[$tag_original][$notes->note_name][] = $notes->text;
            }
            $out = '';
            foreach ($group_notes as $tag) {
                foreach ($tag as $nome => $contenuto) {
                    if (count($contenuto) > 1) {
                        $out .= "<ul>";
                        foreach ($contenuto as $con) {
                            if(strpos($con, "\n") !== FALSE) {
                                $con = '<ul style="list-style-type:none; padding-left: 0px;"><li>' . str_replace(array("\r\n", "\r", "\n"), "</li><li>", $con) . "</li></ul>";
                            }
                            $out .= "<li>" . $con . "</li>";
                        }
                        $out .= "</ul>";
                    } else {
                        foreach ($contenuto as $con) {
                            if(strpos($con, "\n") !== FALSE) {
                                $con = '<ul style="list-style-type:none;"><li>' . str_replace(array("\r\n", "\r", "\n"), "</li><li>", $con) . "</li></ul>";
                            } else {
                                $con = '<ul style="list-style-type:none;"><li>' . $con . "</li></ul>";
                            }
                            $out .= $con;
                        }
                    }
                }

                $notes->full_note .= "<li><strong>" . $nome . "</strong>: " . $out . "</li>";
                $out = '';
            }
        }
        
        return $manifestation;
    }

    /**
     * @param $manfestations
     * @param array $dataSources
     * @throws InvalidArgumentException
     */
    public function fillManifestations($manfestations, array $dataSources = array()) {
        if (!is_array($manfestations) && !$manfestations instanceof Traversable)
            throw new InvalidArgumentException('First argument of XslManifestation::fillManifestations must be an array or a Traversable');

        $index = 0;
        foreach ($manfestations as $manifestation) {
            if (!$manifestation instanceof Manifestation)
                throw new InvalidArgumentException('$manifestations items must be an instance of class Manifestation');

            /** @var $manifestation Manifestation */
            $dataSource = isset($dataSources[$index]) ? $dataSources[$index] : array()
            ;

            $this->fillManifestation($manifestation, $dataSource);
            $index++;
        }
    }

    /**
     * Recursive function to convert an XML node to a DataObject, DataObjectSet or a string
     *
     * @param SimpleXMLElement $node
     * @param null|DataObject $objectToFill If specified, fill this object instead
     *  of creating a new one
     * @throws Exception
     * @return DataObject|string
     */
    private function convertNode(SimpleXMLElement $node, $objectToFill = null) {
        if (!count($node->children()) && !isset(static::$hydration_map[$node->getName()])) {
            return $this->getMappedValueIfMapSpecified($node);
        } else {
            if (!$objectToFill) {
                $objectToFill = $this->getObjectToFill($node);
            }

            if ($objectToFill instanceof DataObjectSet) {
                foreach ($node as $childNode) {
                    $convertedNode = $this->convertNode($childNode);
                    if ($convertedNode !== null) {
                        if ($convertedNode instanceof ViewableData)
                            $convertedNode->ParentNode = $objectToFill;
                        $objectToFill->push($convertedNode);
                    }
                }
            } elseif ($objectToFill instanceof DataObject) {
                foreach ($node->attributes() as $attName => $attValue) {
                    $objectToFill->setField($attName, $attValue);
                }
                /** @var $childNode SimpleXMLElement */
                foreach ($node as $childNode) {
                    $convertedNode = $this->convertNode($childNode);
                    if ($convertedNode !== null) {
                        if ($convertedNode instanceof ViewableData)
                            $convertedNode->ParentNode = $objectToFill;
                        $objectToFill->setField($childNode->getName(), $convertedNode);
                    }
                }
            } elseif ($objectToFill instanceof DBField) {
                $objectToFill->setValue($this->getMappedValueIfMapSpecified($node));
            } else {
                throw new Exception('$objectToFill must be a DataObject or a DataObjectSet');
            }

            return $objectToFill;
        }
    }

    /**
     * Given an xml node, it returns the object to hydrate
     *
     * @param SimpleXMLElement $node
     *
     * @return DataObject|DataObjectSet
     * @throws Exception
     */
    private function getObjectToFill(SimpleXMLElement $node) {
        if (isset(static::$hydration_map[$node->getName()])) {
            $className = static::$hydration_map[$node->getName()];
            if (!class_exists($className))
                throw new Exception("Class $className does not exist");

            return new $className;
        }

        if (isset($node['set']))
            return new DataObjectSet;

        return new DataObject();
    }

    /**
     * @see $simple
     * @param boolean $simple
     *
     * @return \XslManifestationDriver
     */
    public function setSimple($simple) {
        $this->simple = $simple;

        return $this;
    }

    /**
     * @see $simple
     *
     * @return boolean
     */
    public function getSimple() {
        return $this->simple;
    }

}
