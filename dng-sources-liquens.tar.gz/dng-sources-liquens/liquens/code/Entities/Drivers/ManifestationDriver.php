<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
interface ManifestationDriver
{
    /**
     * Get a Manifestation object from an arbitrary data source.
     *
     * @abstract
     * @param $dataSource
     * @param Manifestation $manifestation
     *
     * @return Manifestation
     */
    public function fillManifestation(Manifestation $manifestation, $dataSource = array());

    /**
     * @abstract
     * @param $manfestations
     * @param $dataSources
     */
    public function fillManifestations($manfestations, array $dataSources = array());
}
