<?php

class Authority extends DataObject {
    
    public $auth_turbomarc;
    public $auth_name;
    public $auth_id;
    public $auth_type;
    public $auth_fulltype;
    
    private $authority_type = array(
        '0' => 'Tutte',
        'A' => 'Argomento',
        'C' => 'Classe',
        'D' => 'Serie',
        'E' => 'Ente',
        'F' => 'Famiglia',
        'G' => 'Nome geografico/luogo',
        'H' => 'Marca tipografica',
        'L' => 'Luogo di edizione',
        'M' => 'Marca commerciale',
        'O' => 'Opera',
        'P' => 'Persona',
        'S' => 'Soggetto',
        'T' => 'Indicazione cronologica'
    );
    
    public function __construct() {
        $this->auth_turbomarc = '';
        $this->auth_name = '';
        $this->auth_id = '';
        $this->auth_type = '';
        $this->auth_fulltype = '';
    }
    
    /**
     * 
     * @return type
     */
    public function getTurbomarc() {
        return $this->auth_turbomarc;
    }
    
    public function getSubjectCount($value) {
        $tot = 0;
        if (!empty((array)$this->auth_turbomarc)) {
            foreach ($this->auth_turbomarc->$value as $v) { $tot++; }
        }
        return $tot;
    }
    
    /**
     * campo d901 - sm
     * 
     * @return type
     */
    public function getType() {
        if ($this->auth_type == '' && !empty((array)$this->auth_turbomarc)) {
            $this->auth_type = (string) $this->auth_turbomarc->d901->sm;
        }        
        return $this->auth_type;
    }
    
    public function getFullType() {
        if ($this->auth_fulltype == '' && !empty((array)$this->auth_turbomarc)) {
            $this->auth_fulltype = $this->authority_type[strtoupper($this->auth_turbomarc->d901->sm)];
        }        
        return $this->auth_fulltype;
    }    
    
    /**
     * 
     * @return type
     */
//    public function getTag() {
//        return $this->auth_tag;
//    }
    
    /**
     * campo d299 - sa
     * 
     * @return type
     */
    public function getName($tag, $s) {
        if ($this->auth_name == '' && !empty((array)$this->auth_turbomarc)) {
            $this->auth_name = (string) $this->auth_turbomarc->$tag->$s;
        }
        return $this->auth_name;
    }
    
    /**
     * campo c001
     * 
     * @return type
     */
    public function getId() {
        if ($this->auth_id == '' && !empty((array)$this->auth_turbomarc)) {
            $this->auth_id = (int) $this->auth_turbomarc->c001;
        }
        return $this->auth_id;
    }
    
    public function requireTable() {}
}