<?php

class AuthorityRepository {
    /**
     * A SolrSearcher Instance
     *
     * @var SolrSearcher
     */
    private $solrSearcher;

    /**
     * Store the last solr response
     *
     * @var SolrResponse
     */
    private $lastSolrResponse;

    /**
     * @param SolrSearcher $searcher
     */
    public function __construct(SolrSearcher $searcher)
    {
        $this->solrSearcher = $searcher;
    }

    /**
     * Get the Last solr response
     *
     * @return SolrResponse
     */
    public function getLastSolrResponse()
    {
        return $this->lastSolrResponse;
    }

    /**
     * Richiama il solrSearcher per eseguire la query
     * 
     * @param type $parametri
     * @return type
     */
    public function getAuthority($parametri) {
        return $this->solrSearcher->getQueryAuthority($parametri);
    }
    
    public function getAuthorityOtherSubject($parametri) {
        return $this->solrSearcher->getQueryAuthorityOtherSubject($parametri);        
    }
    
    public function getAuthorityOtherSubjectCount($parametri) {
        return $this->solrSearcher->getQueryAuthorityOtherSubject($parametri);        
    }    
    
    /**
     * Verifica se nella query-string è richiesta qualche informazione sulle authority
     * 
     * @global type $sc
     * @param type $temp
     */
    public function testIfAuthority($temp) {
        foreach ($temp->mapper->queryAry as $field) {
            if (    (isset($field['field'])) && 
                    (   ($field['field'] == 'id-auth') ||
                        ($field['field'] == 'id-subj') ||
                        ($field['field'] == 'id-name') ||
                        ($field['field'] == 'id-work')  )
                    ) {
                global $sc;
                $value = new DataObject();
                $value->system = $sc->getParameter('lq.solrdatabase');
                $value->auth_collection = $sc->getParameter('authority_collection');
                $value->auth_id = $field['value']['value'];
                $result = Controller::curr()->getAuthorityRepository()->getAuthority($value);
                if ($result['response']['numFound'] != 0) {
                    $authority_test = new Authority();
                    $authority_test->auth_turbomarc = simplexml_load_string($result['response']['docs'][0]['turbo_marc']);
                    return $authority_test;
                }
            }
        }
        return null;
    }

    public function getFullAuthority($id) {
        global $sc;
        $value = new DataObject();
        $value->system = $sc->getParameter('lq.solrdatabase');
        $value->auth_collection = $sc->getParameter('authority_collection');
        $value->auth_id = $id;
        $result = Controller::curr()->getAuthorityRepository()->getAuthority($value);
        if ($result['response']['numFound'] != 0) {
            $authority_test = new Authority();
            $authority_test->auth_turbomarc = simplexml_load_string($result['response']['docs'][0]['turbo_marc']);
            return $authority_test;
        }
        return null;
    }
    
    public function searchAuthorityTypeNumberList($value) {
        $result = Controller::curr()->getAuthorityRepository()->getAuthorityOtherSubject($value);
        $temp = array();
        $temp = $result["facet_counts"]["facet_fields"]["fldis_str_auth_type"];
        ksort($temp);
        $totale = array();        
        $totale[0] = $result["response"]["numFound"];
        $totale = $totale + $temp;
        return $totale;
    }
    
    public function searchAuthorityOtherSubject($value) {
        /* $auth_id, $start = 0, $rows = 10, $other = null */
        $result = Controller::curr()->getAuthorityRepository()->getAuthorityOtherSubject($value);
        if ($result['response']['numFound'] != 0) {
            $subject_test = Array();
            $subject_test = $result['response']['docs'];
            return $subject_test;
        }
        return null;
    }
    
    public function countAuthorityOtherSubject($value) {
        $result = Controller::curr()->getAuthorityRepository()->getAuthorityOtherSubjectCount($value);
        return $result['response']['numFound'];
    }
}
