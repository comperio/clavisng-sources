<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class Issue extends DataObject
{
    /**
     * @var DataObjectDiscriminator
     */
    private $reservationDiscriminator;

    /**
     * Overload constructor to load injections
     *
     * @param null $record
     * @param bool $isSingleton
     */
    public function __construct($record = null, $isSingleton = false)
    {
        parent::__construct($record, $isSingleton);

        global $sc;

        Kernel::load_injections($this, $sc);
    }

    /**
     * @param \DataObjectDiscriminator $reservationDiscriminator
     *
     * @return Issue the current instance
     */
    public function setReservationDiscriminator($reservationDiscriminator)
    {
        $this->reservationDiscriminator = $reservationDiscriminator;

        return $this;
    }

    /**
     * @return \DataObjectDiscriminator
     */
    public function getReservationDiscriminator()
    {
        return $this->reservationDiscriminator;
    }

    /**
     * A viewable Library objecy
     *
     * @return ViewableObject
     */
    public function getViewableLibrary()
    {
        return new ViewableObject($this->getLibrary());
    }

    /**
     * Does DNG consider this issue reservable?
     *
     * @return bool
     */
    public function isOpacReservable()
    {
        $discriminator = $this->getReservationDiscriminator();
        if ($discriminator && $discriminator->discriminate($this) == 0) {
            return false;
        }

        return true;
    }

    /**
     * @return Manifestation
     */
    public function getManifestation()
    {
        return $this->ParentNode->ParentNode;
    }

    /**
     * @return ReserveDialog
     */
    public function getReserveDialog()
    {
        return $this->getManifestation()->getReserveDialog($this->id);
    }
}
