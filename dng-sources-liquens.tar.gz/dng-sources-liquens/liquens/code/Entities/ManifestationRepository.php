<?php

/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class ManifestationRepository {

    /**
     * An array of ManifestationDriver objects
     * @var array
     */
    private $drivers = array();

    /**
     * A SolrSearcher Instance
     *
     * @var SolrSearcher
     */
    private $solrSearcher;

    /**
     * Store the last solr response
     *
     * @var SolrResponse
     */
    private $lastSolrResponse;

    /**
     * Optional dependency. If set each manifestation will be enriched with the $manifestationrendering
     * given by the provider.
     *
     * @var ManifestationRenderingProvider
     */
    private $renderingProvider;

    /**
     * @param SolrSearcher $searcher
     */
    public function __construct(SolrSearcher $searcher) {
        $this->solrSearcher = $searcher;
    }

    /**
     * @see $renderingProvider
     * @param ManifestationRenderingProvider $provider
     */
    public function setRenderingProvider(ManifestationRenderingProvider $provider) {
        $this->renderingProvider = $provider;
    }

    /**
     * Register a manifestation driver
     *
     * @param ManifestationDriver $driver
     * @return ManifestationRepository
     */
    public function registerDriver(ManifestationDriver $driver) {
        $this->drivers[] = $driver;

        return $this;
    }

    /**
     * Retrieve and build a set of manifestations of a solrquery object
     *
     * @param SolrQuery $query
     * @return DataObjectSet
     */
    public function getBySolrQuery(SolrQuery $query) {
        $solrResponse = $this->solrSearcher->search($query);
        $this->lastSolrResponse = $solrResponse;
        $docs = $solrResponse->getDocs();

        $manifestations = $this->getEmptyManifestationsSet(count($docs));

        $dataSources = array_map(function($solrDoc) {
            return array('solr_doc' => $solrDoc);
        }, $docs);

        foreach ($this->drivers as $driver) {
            $driver->fillManifestations($manifestations, $dataSources);
        }

        if ($this->renderingProvider) {
            foreach ($manifestations as $manifestation) {
                $manifestation->setRendering($this->renderingProvider->getRendering($manifestation));
            }
        }

        return $manifestations;
    }

    /**
     * Esegue la query per ricerca di edizioni simili, dello stesso tipo e non tenendo conto degli extrasistema
     * 
     * @param type $edKey
     * @param type $bibtype
     * @return boolean
     */
    public function getByOtherEditions($edKey, $bibtype) {
//         EDITION_KEY DA VERIFICARE se ci va \: o solo :
//        $testo = 'edition_key\:' . $edKey;
        $testo = 'edition_key:' . $edKey;
//         --
        $testo = str_replace("]", "\]", str_replace("[", "\[", $testo));

        $query = new SolrQuery();
        $query->setMainQuery($testo);
        $query->setRawField('rows', $this->getRowCount($testo));
        $query->appendCondition("mrc_d901_sa:" . $bibtype, "AND");
        $query->appendCondition("collection:extra", "NOT");
        $manifestationsSet = $this->getBySolrQuery($query);
        if ($manifestationsSet->Count() > 1) {
            return $manifestationsSet;
        }
        return false;
    }

    /**
     * Verifica la presenza degli shards e li estrapola modificando il server SOLR
     * 
     * @global type $sc
     * @param type $manifestationId
     * @return type
     */
    public function getShard($manifestationId) {
        /* Ricerca dello shard in APC ed eventualmente ricalcolandolo dal DB */
        global $sc;
        if (explode(":", $manifestationId)[0] != $sc->getParameter('lq.solrDatabase')) {
            $key = $sc->getParameter('lq.solrDatabase') . "_shards";
            if (apc_exists($key)) {
                $shards = unserialize(apc_fetch($key));
                /* Confronta il primo termine del trine_id con i CORE dei motori SOLR e ne estrae gli indirizzi dei server per modificare la chiamata */
                foreach ($shards as $shard) {
                    if (explode("#", $shard)[3] == explode(":", $manifestationId)[0]) {
                        return explode("#", $shard)[1];
                    }
                }
            }
        }
        return null;
    }

    /**
     * Fetch the first manifestation given as result from a solr query
     *
     * @param SolrQuery $query
     * @return bool|DataObject|null
     */
    public function getOneBySolrQuery(SolrQuery $query) {
        $query->setRawField('rows', 1);

        $manifestationsSet = $this->getBySolrQuery($query);

        if ($manifestationsSet->Count())
            return $manifestationsSet->First();

        return null;
    }
    
    /**
     * Cerca attraverso il BID fornito
     * 
     * @param type $BID
     * @return type
     */
    public function getOneByBID($BID) {
        $query = new SolrQuery();
        $query->appendCondition("mrc_d035_sa:" . explode(":",$BID)[1]);
        return $this->getOneBySolrQuery($query)->trine_id;
    }
    
    /**
     * @param $manifestationId
     * @return bool|\DataObject|null
     */
    public function getOneById($manifestationId) {
        $query = new SolrQuery();
        if (strpos($manifestationId, ':') !== false) {
            $query->setMainQuery('id:' . $this->solrSearcher->escape($manifestationId));
            if (!is_null($this->getShard($manifestationId))) {
                $query->setRawField('shards', $this->getShard($manifestationId));
            }
        } else {
            $query->setMainQuery('fldin_txt_numbers:' . $this->solrSearcher->escape($manifestationId));
        }

        return $this->getOneBySolrQuery($query);
    }

    /**
     * Get the Last solr response
     *
     * @return SolrResponse
     */
    public function getLastSolrResponse() {
        return $this->lastSolrResponse;
    }

    /**
     * Build a dataobjecset of empty manifestations object
     *
     * @param int $n
     * @return DataObjectSet
     */
    private function getEmptyManifestationsSet($n = 1) {
        $manifestations = new DataObjectSet();

        for ($i = 0; $i < $n; $i++) {
            $manifestations->push(new Manifestation());
        }

        return $manifestations;
    }

    /**
     * Riceve una query per SolR e restituisce il numero di 'row'
     * 
     * @param type $query
     * @return type
     */
    public function getRowCount($query) {
        return $this->solrSearcher->getQueryRowCount($query);
    }
    
    /**
     * Riceve una query per SolR, ne cambia il core e restituisce il numero di 'row'
     * 
     * @param type $query
     * @param type $originalSolr
     * @return type
     */
    public function getRowCountShard($query, $originalSolr) {
        $this->solrSearcher->solrURL = $originalSolr;
        return $this->solrSearcher->getQueryRowCount($query);
    }

}
