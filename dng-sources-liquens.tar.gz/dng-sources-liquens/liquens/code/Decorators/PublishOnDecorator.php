<?php

/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

/**
 * With this extension you can set, for each page, a date/time of publication.
 * Before that time the page is not displayed.
 *
 * This is done augmenting the SQL for pages retrivial.
 */
class PublishOnDecorator extends DataObjectDecorator {

    /**
     * @return array
     */
    public function extraStatics() {
        return array(
            'db' => array(
                'PublishOn' => 'SS_Datetime',
            ),
            'indexes' => array('PublishOn' => true)
        );
    }

    /**
     * When the current stage is the live stage, add a condition on the "PublishedOn field
     *
     * @param SQLQuery $query
     */
    public function augmentSQL(SQLQuery &$query) {
        $liveStage = Versioned::get_live_stage();

        if (Versioned::current_stage() == $liveStage && array_key_exists('SiteTree', $query->from)) {
            $now = date('Y-m-d H:i:s');
            $table = "SiteTree_$liveStage";
            $query->where(sprintf(
                            '%s.PublishOn IS NULL OR %s.PublishOn < \'%s\'', $table, $table, Convert::raw2sql($now)
            ));
        }
        parent::augmentSQL($query);
    }

    /**
     * Add the field for the data picking
     *
     * @param FieldSet $fields
     */
    public function updateCMSFields(FieldSet &$fields) {
        $fields->addFieldToTab('Root.Behaviour', new DngDateTimeField('PublishOn', 'Data di pubblicazione', '', 'Data', 'Ora'));
    }

    /**
     * If PublishOn is not set, set the current time as publication time when the page
     * is published for the first time
     */
    public function onAfterWrite() {
        if (!$this->owner->PublishOn && Versioned::current_stage() == Versioned::get_live_stage()) {
            $this->owner->PublishOn = date('Y-m-d H:i:s');

            //Save the PublishOn date also in the stage version
            Versioned::reading_stage('Stage');
            $this->owner->write();
            Versioned::reading_stage(Versioned::get_live_stage());
        }

        parent::onAfterWrite();
    }

}
