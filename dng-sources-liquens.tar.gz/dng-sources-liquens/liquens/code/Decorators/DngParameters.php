<?php

/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class DngParameters extends DataObjectDecorator {

    function extraStatics() {
        return array(
            'db' => array(
                'GoogleAnalyticsAccountID' => 'Text',
                'CustomCSS' => 'Text',
                'CustomHeaderCode' => 'Text',
                'ShareCode' => 'Text',
                'FullImageHeaderAlignment' => 'Enum(array("left", "middle", "right"), "middle")',
                'FullImageHeaderWidth' => 'Text',
                'FullImageHeaderHeight' => 'DBInt',
                'PwdRecoveryLink' => 'Text',
                'PwdRecoveryTitle' => 'Text',
                'PwdRecoveryBody' => 'HTMLText',
                'PwdRecoveryEmailSubject' => 'VarChar(50)',
                'PwdRecoveryEmailBody' => 'HTMLText',
                'PwdRecoveryTTL' => 'DBInt(3600)',
                'PwdRecoveryNickname' => 'Boolean(1)',
                'PwdRecoveryBarcode' => 'Boolean(1)',
                'PwdRecoveryEmail' => 'Boolean(1)',
                'PwdRecoveryCF' => 'Boolean(1)',
                'GoogleKey' => 'VarChar(50)',
                'GoogleMaps' => 'Boolean',
                'CustomLogin' => 'HTMLText',
                'CategoriesList' => 'Text',
                'RawViewLibrariesContacts' => 'Boolean',
                'EditionKeyOtherSystemString' => 'VarChar(50)',
                'ReservationString' => 'HTMLText',
                'ShardReceiverGlobalEmail' => 'VarChar(100)',
                'ShardReceiverFallbackEmail' => 'VarChar(100)',
                'ShardActiveEmailButton' => 'Boolean'
            ),
            'has_one' => array(
                'Logo' => 'Image',
                'Favicon' => 'Image',
                'FullImageHeader' => 'Image',
                'Footer' => 'WidgetArea'
            ),
            'defaults' => array(
                'GoogleAnalyticsAccountID' => '',
                'GoogleKey' => '',
                'GoogleMaps' => false,
                'RawViewLibrariesContacts' => false,
                'EditionKeyOtherSystemString' => 'Attenzione! Questo titolo è del sistema di ',
                'ReservationString' => '',
                'ShardReceiverGlobalEmail' => '',
                'ShardReceiverFallbackEmail' => '',
                'ShardActiveEmailButton' => false
            )
        );
    }

    function updateCMSFields(FieldSet &$fields) {
        $fields->addFieldToTab('Root.Main', new ImageField('Logo', 'Site Logo'));
        $fields->addFieldToTab('Root.Main', new ImageField('Favicon', 'Site Favicon'));
        $fields->addFieldToTab('Root.Main', new TextareaField('ShareCode', _t('SiteConfig.SHARINGCODE')));
        $fields->addFieldToTab('Root.Main', new TextField('GoogleAnalyticsAccountID', 'Google Analytics Code (Example: UA-XXXXXXXX-X)', '', 13));

        $fields->addFieldToTab('Root.PersonalizzazioneTestoLogin', new HTMLEditorField('CustomLogin', 'Personalizzazione testo del modale di login', 10, 10));
        
        $fields->addFieldToTab('Root.AltreEdizioniMultiOpac', new TextField('EditionKeyOtherSystemString', 'Personalizzazione testo di riferimento per altri sistemi'));
        $fields->addFieldToTab('Root.AltreEdizioniMultiOpac', new TextField('ShardReceiverGlobalEmail', "Unica email destinataria dell'intero Sistema Bibliotecario. Qui convergeranno tutte le richieste fatte dagli utenti tramite multiopac"));
        $fields->addFieldToTab('Root.AltreEdizioniMultiOpac', new TextField('ShardReceiverFallbackEmail', "Email di backup nel caso in cui qualche biblioteca non abbia l'email compilata"));
        $fields->addFieldToTab('Root.AltreEdizioniMultiOpac', new CheckboxField('ShardActiveEmailButton', "Mettere la spunta per visualizzare il bottone di invio email per il multi-opac"));
        
        $fields->addFieldToTab('Root.TestoPrenotazione', new HTMLEditorField('ReservationString', 'Personalizzazione testo del modale di prenotazione'));
        
        $fields->addFieldToTab('Root.ContattiEsplicitiBiblioteche', new CheckBoxField('RawViewLibrariesContacts', 'Seleziona per mostrare esplicitamente i contatti delle biblioteche invece delle icone'));

        $fields->addFieldToTab('Root.CustomCSS', new TextareaField('CustomCSS', 'Custom CSS', 20, 30));

        $fields->addFieldToTab('Root.CustomHeaderCode', new TextareaField('CustomHeaderCode', 'Custom Header Code', 20, 30));

        $fields->addFieldToTab('Root.TemaFullImageHeader', new ReadonlyField('FullImageHeaderContent', '--- IMPORTANTE! ---', 'Questa modalità funziona solamente selezionando il tema "fullHeaderImage" nel tab "Main"'));
        $fields->addFieldToTab('Root.TemaFullImageHeader', new ImageField('FullImageHeader', 'Immagine Full Size Header'));
        $fields->addFieldToTab('Root.TemaFullImageHeader', new TextField('FullImageHeaderWidth', 'Larghezza immagine in pixel (scrivere "auto" per larghezza automatica)', '', 4));
        $fields->addFieldToTab('Root.TemaFullImageHeader', new NumericField('FullImageHeaderHeight', 'Altezza immagine in pixel (default 150)'));
        $fields->addFieldToTab("Root.TemaFullImageHeader", new OptionsetField("FullImageHeaderAlignment", "Allineamento immagine", array("left" => "Sinistra", "middle" => "Centro", "right" => "Destra")));

        $fields->addFieldToTab('Root.RecuperoPassword', new TextField('PwdRecoveryLink', 'Testo del link per il recupero password', '', 100));
        $fields->addFieldToTab('Root.RecuperoPassword', new TextField('PwdRecoveryTitle', 'Titolo della pagina', '', 100));
        $fields->addFieldToTab('Root.RecuperoPassword', new HTMLEditorField('PwdRecoveryBody', 'Contenuto della pagina', 10, 10));
        $fields->addFieldToTab('Root.RecuperoPassword', new NumericField('PwdRecoveryTTL', 'Validità della richiesta (in secondi)'));
        $fields->addFieldToTab('Root.RecuperoPassword', new CheckboxField('PwdRecoveryNickname', 'Visualizza Nickname'));
        $fields->addFieldToTab('Root.RecuperoPassword', new CheckboxField('PwdRecoveryBarcode', 'Visualizza Barcode'));
        $fields->addFieldToTab('Root.RecuperoPassword', new CheckboxField('PwdRecoveryEmail', 'Visualizza Email'));
        $fields->addFieldToTab('Root.RecuperoPassword', new CheckboxField('PwdRecoveryCF', 'Visualizza Codice Fiscale'));
        $fields->addFieldToTab('Root.RecuperoPassword', new TextField('PwdRecoveryEmailSubject', "Soggetto dell'email inviata. Segnaposto #SISTEMA", '', 100));
        $fields->addFieldToTab('Root.RecuperoPassword', new HTMLEditorField('PwdRecoveryEmailBody', "Contenuto dell'email inviata. Segnaposti #NOME, #LINK, #NICKNAME, #BARCODE, #EMAIL, #CODICEFISCALE, #SISTEMA", 10, 10));
        

        $fields->addFieldToTab('Root.VisualizzazioneMappe', new CheckBoxField('GoogleMaps', 'Seleziona per le "Mappe di Google". Togli la spunta per "Open Street Maps". Salva dopo ogni modifica.'));
        if ($this->owner->GoogleMaps)
            $fields->addFieldToTab('Root.VisualizzazioneMappe', new TextField('GoogleKey', 'Chiave di attivazione Google Maps (solo se hai scelto "Mappe di Google" sopra)'));

        global $sc;
        $defaultCategories = $sc->getParameter('eventDefaultCategories');
        $dc = array();
        foreach ($defaultCategories as $v => $c)
            $dc[] = $c . ":" . $v;
        if ($this->owner->CategoriesList == "") {
            $dcc = array();
            $LqEventCategories = DataObject::get("LqEventCategories", null, "ID ASC");
            foreach ($LqEventCategories as $category) {
                if (!array_key_exists($category->CValue, $defaultCategories)) {
                    $dcc[] = $category->Category . ":" . $category->CValue;
                }
            }
            if (!empty($dcc))
                $this->owner->CategoriesList = join("\n", $dcc);
        }
        $fields->addFieldToTab('Root.GestioneCategorie', new ReadonlyField('CategoriesDefault', 'Categorie non modificabili', join("\n", $dc)));
        $fields->addFieldToTab('Root.GestioneCategorie', new TextareaField('CategoriesList', 'Categorie personalizzate (formato: NomeCategora:Codice, "Codice" di 3 caratteri massimo, una categoria per ogni riga). Si sommano alle categorie già esistenti di default.', 10));

        $fields->addFieldToTab('Root.Footer', new GridWidgetAreaEditor('Footer'));
        // If there is no ID field, the trigger BeforeSave will not be triggered on SiteConfig save.
        // (See LeftAndMain_right.js:168)
        $fields->push(new HiddenField('ID', 'ID'));

        parent::updateCMSFields($fields);
    }

    public function onBeforeWrite() {
        parent::onBeforeWrite();
        if ((!is_numeric($this->owner->FullImageHeaderWidth)) && ($this->owner->FullImageHeaderWidth != "auto"))
            $this->owner->FullImageHeaderWidth = "auto";
        if (($this->owner->PwdRecoveryLink == "") || is_null($this->owner->PwdRecoveryLink))
            $this->owner->PwdRecoveryLink = "Hai dimenticato la password?";
        if (($this->owner->PwdRecoveryTitle == "") || is_null($this->owner->PwdRecoveryTitle))
            $this->owner->PwdRecoveryTitle = "Hai dimenticato la password?";
        if (($this->owner->PwdRecoveryBody == "") || is_null($this->owner->PwdRecoveryBody))
            $this->owner->PwdRecoveryBody = "Inserisci uno dei seguenti valori, riceverai una email con le istruzioni per creare una nuova password.";
        if (($this->owner->PwdRecoveryEmailSubject == "") || is_null($this->owner->PwdRecoveryEmailSubject))
            $this->owner->PwdRecoveryEmailSubject = "Richiesta di recupero password - #SISTEMA";
        if (($this->owner->PwdRecoveryEmailBody == "") || is_null($this->owner->PwdRecoveryEmailBody))
            $this->owner->PwdRecoveryEmailBody = 'Ciao #NOME,<br><br>qualcuno ha recentemente richiesto di modificare la password del tuo account su #SISTEMA.<br><br>Se sei stato tu, puoi impostare una nuova password cliccando <a href="#LINK">qui</a><br><br>Il tuo username per accedere a OPAC: #NICKNAME<br><br>Se non desideri cambiare la password, ignora questo messaggio.<br><br>Grazie<br><br>#SISTEMA';

        $row = array_filter(explode("|", str_replace("\n", "|", $this->owner->CategoriesList)));
        if (!is_null($row)) {
            global $sc;
            $defaultCategories = $sc->getParameter('eventDefaultCategories');
            foreach ($row as $k => $r) {
                list($c, $v) = explode(":", $r);
                if (array_key_exists($v, $defaultCategories))
                    unset($row[$k]);
            }
            $this->owner->CategoriesList = join("\n", $row);
        }
        
        if (($this->owner->EditionKeyOtherSystemString == "") || is_null($this->owner->EditionKeyOtherSystemString))
            $this->owner->EditionKeyOtherSystemString = "Attenzione! Questo titolo è del sistema di ";

        
    }

    public function onAfterWrite() {
        parent::onAfterWrite();

        /* Categorie esistenti */
        $LqEventCategories = DataObject::get("LqEventCategories", null, "ID ASC");

        /* Categorie default */
        global $sc;
        $defaultCategories = $sc->getParameter('eventDefaultCategories');

        /* Separazione tra categorie aggiuntive e default */
        $categories_base = array();
        $categories_plus = array();
        $idMax = 0;
        foreach ($LqEventCategories as $category) {
            if (!array_key_exists($category->CValue, $defaultCategories)) {
                $categories_plus[$category->CValue]["category"] = $category->Category;
                $categories_plus[$category->CValue]["ID"] = $category->ID;
            } else {
                $categories_base[$category->CValue]["category"] = $category->Category;
                $categories_base[$category->CValue]["ID"] = $category->ID;
            }
            if ($idMax < $category->ID)
                $idMax = $category->ID;
        }

        /* Gestione categorie aggiuntive */
        $sqlQuery = new SQLQuery();
        $sqlQuery->select = array('CategoriesList AS cl');
        $sqlQuery->from = array("SiteConfig");
        $sqlQuery->where = array("CategoriesList IS NOT NULL");
        $result = $sqlQuery->execute();

        /* Recupero stringa cat. aggiuntive */
        foreach ($result as $row) {
            if (!is_null($row['cl']))
                $row = array_filter(explode("|", str_replace("\n", "|", $row['cl'])));
            else
                $row = null;
        }

        if ((isset($row)) && (!is_null($row))) {

            $toAdd = array();
            $toDelete = array();

            /* Estrapolo categorie custom da testo libero */
            foreach ($row as $r) {
                list($c, $v) = explode(":", $r);
                $toDelete[$v] = $c;
                /* Inserimento nuove categorie nella lista */
                if (!array_key_exists($v, $categories_plus)) {
                    $idMax++;
                    $categories_plus[$v]["category"] = $c;
                    $categories_plus[$v]["ID"] = $idMax;
                }
            }
            
            /* Verifico che nelle Cat_Plus ci sia o meno quelle da testo libero */
            foreach ($categories_plus as $c_v => $c_plus) {
                /* Cancello se non esiste */
                if (!array_key_exists($c_v, $toDelete)) {
                    unset($categories_plus[$c_v]);
                }
            }
            
            /* Salvataggio su database */
            DB::query("TRUNCATE `LqEventCategories`;");
            foreach ($categories_base as $c_v => $c_base) {
                $record = new LqEventCategories();
                $record->ID = $c_base["ID"];
                $record->Category = $c_base["category"];
                $record->CValue = $c_v;
                $record->write();
            }
            if (!is_null($row)) {
                foreach ($categories_plus as $c_v => $c_plus) {
                    $record = new LqEventCategories();
                    $record->ID = $c_plus["ID"];
                    $record->Category = $c_plus["category"];
                    $record->CValue = $c_v;
                    $record->write();
                }
            }
        }

        Requirements::customScript('location.reload();');
    }

}
