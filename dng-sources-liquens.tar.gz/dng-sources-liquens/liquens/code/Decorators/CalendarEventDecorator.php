<?php

/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class CalendarEventDecorator extends DataObjectDecorator {

    /**
     * Add a Where field
     *
     * @return array
     */
    public function extraStatics() {
        return array(
            'db' => array(
                'Where' => 'Varchar(255)',
                'LqTags' => 'Varchar(255)'
            ),
        );
    }

    /**
     * @param FieldSet $fields
     */
    public function updateCMSFields(FieldSet &$fields) {
        $tab = $fields->findOrMakeTab('Root.Content.EventData');

        $tab->FieldSet()->insertFirst(new TextField('LqTags', 'Tags'));
        $tab->FieldSet()->insertFirst(new TextField('Where', _t('Liquens.WHERE', 'Where')));
    }

    /**
     * Returns the LibraryMainPage which the page is grand son of
     *
     * @return mixed
     */
    public function getLibraryMainPage() {
        return $this->owner->Parent()->Parent();
    }

    /**
     * Explode the LqTags fields and returns it as a DataObjectSet
     *
     * @return DataObjectSet
     */
    public function getTags() {
        $tags = new DataObjectSet();

        $tagsStrings = explode(',', $this->owner->LqTags);

        foreach ($tagsStrings as $tagString) {
            $tag = new ArrayData(array('Value' => trim($tagString)));
            $tags->push($tag);
        }

        return $tags;
    }

}
