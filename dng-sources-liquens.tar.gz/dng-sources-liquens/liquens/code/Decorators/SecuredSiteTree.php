<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

/**
 * Class created to secure some pages in the cms.
 *
 * If a user has the SITETREE_EDIT_MY_LIBRARIES Permission, check if the page
 * is a descendant of some LibraryMainPage, and in that case returns LibraryMainPage
 * edit permissions.
 */
class SecuredSiteTree extends SiteTreeDecorator
{
    /**
     * Permission check used for edit and delete permissions
     * @param $member
     * @return bool|null
     */
    private function getLiquensPermission($member)
    {
        if (is_int($member))
            $member = DataObject::get_by_id('Member', $member);
        elseif (!$member instanceof Member)
            $member = Member::currentUser();

        if ($libMainPage = $this->findLibraryMainPage()){
            return $libMainPage->LibraryObject()->canEdit($member);
        }

        //Return null, i.e. go on with the default permission handling
        return null;
    }

    /**
     * @return bool|LibraryMainPage
     */
    private function findLibraryMainPage()
    {
        $libMainPage = false;
        $page = $this->owner;

        //The page has a LibraryMainPage as ancestor?
        //If so, put it in $libMainPage
        while ($page){
            if(get_class($page) === 'LibraryMainPage'){
                $libMainPage = $page;
                $page = false;
            } else {
                $page = $page->getParent();
            }
        }

        return $libMainPage;
    }

    /**
     * @param $member
     * @return bool|null|void
     */
    public function canEdit($member = null)
    {
        return $this->getLiquensPermission($member);
    }

    /**
     * @param null $member
     * @return bool|null|void
     */
    public function canDelete($member = null)
    {
        $liquensPermission = $this->getLiquensPermission($member);

        if ($liquensPermission !== null){
            if ('LibraryMainPage' == get_class($this->owner)){
                return false;
            }
        }

        return $liquensPermission;
    }


}
