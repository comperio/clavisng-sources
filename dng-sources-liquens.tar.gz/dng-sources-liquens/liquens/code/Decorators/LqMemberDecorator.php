<?php

/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Isacco Occhiali <isacco@comperio.it>
 */

/**
 * LqMemberDecorator extends the Member table and methods to tune the Members data for Liquens
 * functionalities
 */
class LqMemberDecorator extends DataObjectDecorator {

    protected $externalDataCache;

    /**
     * @var array
     */
    private $activeLoans;

    /**
     * @var DataObjectSet
     */
    private $pendingLoans;

    /**
     * @var array
     */
    private $activeRequests = array();

    /**
     * @var LibraryRepository
     */
    private $libraryRepository;

    /**
     * @var UserDataBag
     */
    private $dataBag;

    /**
     * Define extra database fields
     *
     * Returns a map where the keys are db, has_one, etc, and the values are
     * additional fields/relations to be defined
     *
     * @return array Returns a map where the keys are db, has_one, etc, and
     *               the values are additional fields/relations to be defined
     */
    function extraStatics() {
        return array(
            'db' => array(
                'PhotoURL' => 'Text',
                'Biography' => 'Text',
                'Privacy' => 'Text',
                'Username' => 'VarChar(255)'
            ),
            'has_one' => array(),
            'defaults' => array(),
            'indexes' => array(
                'Username' => true
            )
        );
    }

    /**
     * Edit the given query object to support queries for this extension
     *
     * At the moment this method does nothing.
     *
     * @param SQLQuery $query Query to augment.
     */
    function augmentSQL(SQLQuery &$query) {
        
    }

    /**
     * Update the database schema as required by this extension
     *
     * At the moment this method does nothing.
     */
    function augmentDatabase() {
        
    }

    /*     * * EXTRA METHODS ** */

    /**
     * Update the Member object with the logged in userdata
     * @param $userdata
     * @return write Member
     */
    protected function updateSensibleData($userdata) {
        $member = $this->owner;
        $write = false;
        if (!isset($userdata['firstname'])) {
            $userdata['firstname'] = '';
        }
        if (!isset($userdata['surname'])) {
            $userdata['surname'] = '';
        }
        if ($userdata['firstname'] != $member->FirstName) {
            $member->FirstName = $userdata['firstname'];
            $write = true;
        }
        if ($userdata['surname'] != $member->Surname) {
            $member->Surname = $userdata['surname'];
            $write = true;
        }
        if (isset($userdata['email']) && $userdata['email'] && $userdata['email'] != $member->Email) {
            $member->Email = $userdata['email'];
            $write = true;
        } elseif (!isset($userdata['email']) || !$userdata['email']) {
            //Prevent empty emails. They caused problems in groups management in the CMS
            $member->Email = "noemail-{$member->ID}@comperio.it";
            $write = true;
        }

        if (isset($userdata['photoUrl']) && $userdata['photoUrl'] != $member->PhotoURL) {
            $member->PhotoURL = $userdata['photoUrl'];
            $write = true;
        }

        CachedUserData::flush($member->ID);

        if ($write)
            $member->write();
    }

    /**
     * Return the gravatar image by member Email
     * @param int $size
     * @return string src of image
     */
    public function AvatarURL($size = 85) {
        // TBD: check if user has an avatar URL, if so return it.
        if ($this->owner->AvatarID && $avatar = $this->owner->Avatar()) {
            if ($resizedAvatar = $avatar->CroppedImage($size, $size)) {
                return $resizedAvatar->URL;
            }
        }
        // If user has no avatar URL, search&return gravatar.
        global $sc;
        return sprintf($sc->getParameter('gravatar.url'),md5(strtolower(trim($this->owner->Email))),$size);
    }

    public function getProfileURL() {
        if ($this->getPrivacySetting('use_only_user_id')) {
            return 'profile/id/' . $this->owner->ID;
        } else {
            return 'profile/view/' . $this->getUsername();
        }
    }

    public function getLeggereBuyCode() {
        global $sc;
        return (string)$sc->getParameter('leggereBuy.code');
    }
    
    public function getLeggereBuyColor() {
        global $sc;
        return (string)$sc->getParameter('leggereBuy.color');
    }

    /**
     * Check is this member is a Patron
     * @return boolean
     */
    public function isPatron() {
        return $this->owner->inGroup('patron');
    }

    /**
     * Check if this member is a librarian
     * @return boolean
     */
    public function isLibrarian() {
        return $this->isWebmaster() || $this->isSitemaster();
    }

    /**
     * Check if this librarian member is a webmaster
     * @return boolean
     */
    public function isWebmaster() {
        return $this->owner->inGroup('webmaster');
    }

    /**
     * Check if this librarian member is a sitemaster
     * @return boolean
     */
    public function isSitemaster() {
        return $this->owner->inGroup('sitemaster');
    }

    /**
     * Has the user cms access?
     *
     * @return bool
     */
    public function canAccessCMS() {
        return $this->owner->isAdmin() || $this->owner->isLibrarian();
    }

    /**
     * Get the Notifies object of actual member
     * @return DataObjectSet
     */
    public function CurrentMemberNotifies() {
        return new DataObjectSet();
    }

    /**
     * Insert the member in the right group and logs this member in
     * This is a hook of Member logIn method (see Member.php row: 353)
     * @return bool
     */
    public function memberLoggedIn() {
        //Non faccio nulla se siamo in onlyCatalog mode o se l'utente non proviene da una sorgente esterna
        if (empty($this->owner->External_SourceID)) {
            return;
        }
        // update sensible data, if changed
        $c = $this->getConnector();
        $data = $c->getUserData($this->getUsername());
        $this->updateSensibleData($data);
        $this->updateMemberGroups($data);
    }

    /**
     * Check if the user is opac-enabled (only for clavis users). I he is not, logout the user
     *
     * @param bool $force If true does not check if the check has already been made
     * in the session
     * @return bool true if the check succeded, false otherwise
     */
    public function checkOpacEnable($force = false) {
        if ($this->owner->External_SourceID != 'liquens') {
            return true;
        }

        if ($this->isLibrarian()) {
            return true;
        }

        if ($force || !Session::get('LiquensValidated')) {
            if ($this->getExternalProp('patron.OpacEnable')) {
                Session::set('LiquensValidated', 1);
                return true;
            } else {
                //Do logout
                Session::set('LiquensValidated', null);
                $this->owner->logOut();

                ErrorPage::response_for(403);

                return false;
            }
        }
    }

    /**
     * @param $userData The userData returned by the Connector
     */
    public function updateMemberGroups($userData) {
        $ownerGroups = $this->owner->Groups();
        $ownerGroupCodes = array();

        //I can't call owner->inGroup every time due to horrible performance
        foreach ($ownerGroups as $group) {
            $ownerGroupCodes[] = $group->Code;
        }

        if (!in_array('patron', $ownerGroupCodes)) {
            $this->owner->addToGroupByCode('patron');
        }
        if (!in_array('forum-members', $ownerGroupCodes)) {
            $this->owner->addToGroupByCode('forum-members');
        }

        //If Member is a sitemaster or webmaster...
        if (in_array($userData['group'], array('sitemaster', 'webmaster'))) {
            //Add sitemaster or webmaster group
            $groupName = $userData['group'];
            if (!in_array($groupName, $ownerGroupCodes)) {
                $this->owner->addToGroupByCode($groupName);
            }
        }
    }

    /**
     * Check if the current member is owner of an object (shelf or savedsearch)
     * @param integer $DataObjectMemberId
     * @return boolean
     */
    static function isOwnerOfObject($DataObjectMemberId = null) {
        if (!is_null($DataObjectMemberId)) {
            $CurrentMemberID = Member::currentUserID();
            if ($CurrentMemberID == $DataObjectMemberId) {
                return true;
            }
        }
        return false;
    }

    /**
     * Load external data into cache
     *
     * @return LqMemberDecorator
     */
    public function loadExternalData() {
        $lq = $this->getConnector();

        $this->externalDataCache = $lq->getUserData($this->owner->Username);

        return $this;
    }

    /**
     * Get External data cache
     *
     * @param boolean $cached
     * @return LqMemberDecorator
     */
    public function getExternalData($cached = true) {
        if (!$cached || !$this->externalDataCache) {
            $this->loadExternalData();
        }

        return $this->externalDataCache;
    }

    /**
     * Get external data prop
     *
     * @param string $prop
     * @return boolean of array
     */
    public function getExternalProp($prop) {
        $data = $this->getExternalData();

        $keys = explode('.', $prop);

        return $this->getNestedValue($data, $keys);
    }

    /**
     * Returns an email set in the contacts of the external data source.
     * Returns false if no email is found
     * If the email is set as "Preferred" in the external source, it returns that email
     *
     * @return bool|string
     */
    public function getExternalEmail() {
        $contacts = $this->getContactsAry();
        $email = false;

        foreach ($contacts as $contact) {
            if ($contact['ContactType'] == 'E') {
                if (!$email || $contact['ContactPref'] == '1') {
                    $email = $contact['ContactValue'];
                }
            }
        }

        return $email;
    }

    /**
     * Get nested values of an array
     *
     * @param $array
     * @param $keys
     * @return mixed
     */
    private function getNestedValue($array, $keys) {
        $currentKey = array_shift($keys);

        if (!isset($array[$currentKey])) {
            return null;
        }

        if (count($keys) === 0) {
            return $array[$currentKey];
        } else {
            return $this->getNestedValue($array[$currentKey], $keys);
        }
    }

    /**
     * Return libraries linked to this user.
     *
     * @return array|bool
     */
    public function getLinkedLibraries() {
        $libroles = $this->getExternalProp('libroles');

        if ($libroles) {
            return array_keys($libroles);
        }

        return array();
    }

    /**
     * Returns a DataObjectSet of the LibraryMainPages of the library linked to this user.
     *
     * @return mixed
     */
    public function getLinkedLibrariesPages() {
        if ($this->isLibrarian()) {
            $libIds = $this->getLinkedLibraries();
            $idsString = implode(', ', $libIds);
            $filter = "`LibraryDataObject`.ExternalID IN ($idsString) AND `LibraryDataObject`.ExternalSource = 'CLAVIS'";
        } else {
            $filter = '';
        }

        return DataObject::get(
                        'LibraryMainPage', $filter, '', 'LEFT JOIN `LibraryDataObject` ON `LibraryDataObject`.ID = `LibraryMainPage`.LibraryObjectID'
        );
    }

    /**
     * Returns the libraries in the same area of the user's favourite library and that are return libraries
     *
     * @return array
     */
    public function getSameAreaLibrariesMap() {
        $areaMap = LibrariesListPage::get_libraries_area_map();

        $allLibraries = $this->getLibraryRepository()->getReturnLibraries('ExternalID', 'shortName');

        $favLibraryId = (int) $this->getExternalProp('PreferredLibraryId');

        $memberArea = false;

        if (is_array($areaMap)) {
            foreach ($areaMap as $area => $libs) {
                if (in_array($favLibraryId, $libs)) {
                    $memberArea = $area;
                    break;
                }
            }
        }

        if ($memberArea) {
            return array_intersect_key($allLibraries, array_flip($areaMap[$area]));
        } else {
            return array();
        }
    }

    /**
     * Returns the libraries where the user is allowed to request the loan retire
     *
     * @return array
     */
    public function getRetireLibrariesMap() {
        global $sc;
        // No smart
        if ($sc->getParameter('other_editions_loans') == false) {
            return $this->getSameAreaLibrariesMap() ?: $this->getLibraryRepository()->getReturnLibraries('ExternalID', 'shortName');
        }
        // Smart
        return $this->getLibraryRepository()->getReturnLibraries('ExternalID', 'shortName');
    }

    /**
     * @return ViewableHash
     */
    public function getViewableRetireLibrariesMap() {
        if (is_null($this->getRetireLibrariesMap()))
            return new ViewableHash(array());
        return new ViewableHash($this->getRetireLibrariesMap());
    }

    /**
     * Returns the complete name of the member
     *
     * @return string
     */
    public function CompleteName() {

        return trim($this->owner->FirstName . ' ' . $this->owner->Surname);
    }

    /**
     * @return string
     */
    public function getUsername() {
        return $this->owner->getField('Username');
    }

    /**
     * @return string
     */
    public function getDisplayedName() {
        if ($this->getPrivacySetting('use_only_user_id'))
            return _t('Liquens.USER') . ' ' . $this->owner->ID;

        if ($this->getPrivacySetting('use_only_username'))
            return $this->getUsername();

        return $this->CompleteName();
    }

    /**
     * Returns the link to the search page with all user posts
     *
     * @param null $forum
     *
     * @return string
     */
    public function getAllPostsLink($forum = null) {
        $holder = DataObject::get_one('ForumHolder');
        if (!$holder) return false;
        $link = $holder->Link('search');
        return $link . '?Search=&order=date&MemberID=' . $this->owner->ID;
    }

    /**
     * Get an array of user's contacts
     *
     * @return array
     */
    public function getContactsAry() {
        $data = $this->getExternalData();

        //Localize
        if (isset($data['contacts'])) {
            foreach ($data['contacts'] as &$contact) {
                $contact['ContactTypeLabel'] = _tdef('LV_CONTACTTYPE.' . $contact['ContactType']);
            }

            return $data['contacts'];
        } else {
            return array();
        }
    }

    public function getFavouriteLibraryPage() {
        $libraryId = (int) $this->getExternalProp('PreferredLibraryId');

        if ($libraryId) {
            $pages = DataObject::get(
                            'LibraryMainPage', "`LibraryDataObject`.ID=$libraryId", '', 'LEFT JOIN `LibraryDataObject` ON `LibraryDataObject`.ID = `LibraryMainPage`.LibraryObjectID', 1
                    ) ?: new DataObjectSet();

            return $pages->First();
        }

        return false;
    }

    public function getCheckRenewExtra() {
        global $sc;
        if ($sc->getParameter('extra_renew') === true) {
            return 1;
        }
        return 0;
    }
    
    public function getCheckRenewOutOfCatalog() {
        global $sc;
        if ($sc->getParameter('out_catalog_renew') === true) {
            return 1;
        }
        return 0;
    }

    /**
     * Get a DataObjectSet of user's contacts
     *
     * @return DataObjectSet
     */
    public function getContacts() {
        return new DataObjectSet($this->getContactsAry());
    }

    /**
     * Return a single user's contact by contact id
     *
     * @param int $contactId
     *
     * @throws InvalidArgumentException
     * @return array
     */
    public function getContact($contactId) {
        foreach ($this->getContactsAry() as $contact) {
            if ($contact['ContactId'] == $contactId)
                return $contact;
        }

        throw new InvalidArgumentException('User does not own contacts with id ' . $contactId);
    }

    /**
     * Get an array of user's adresses
     *
     * @return DataObjectSet
     */
    public function getAddressesAry() {
        $data = $this->getExternalData();

        if (isset($data['addresses'])) {
            foreach ($data['addresses'] as &$address) {
                $address['AddressTypeLabel'] = _tdef('LV_ADDRESSTYPE.' . $address['AddressType']);
                $address['StreetTypeLabel'] = _tdef('LV_STREET.' . $address['StreetType']);
            }

            return $data['addresses'];
        } else {
            return array();
        }
    }

    /**
     * Get a DataObjectSet of user's adresses
     *
     * @return DataObjectSet
     */
    public function getAddresses() {
        return new DataObjectSet($this->getAddressesAry());
    }

    /**
     * Return a single user's address by address id
     *
     * @param int $addressId
     *
     * @throws InvalidArgumentException
     * @return array
     */
    public function getAddress($addressId) {
        foreach ($this->getAddressesAry() as $address) {
            if ($address['AddressId'] == $addressId)
                return $address;
        }

        throw new InvalidArgumentException('User does not own addresses with id ' . $addressId);
    }

    /**
     * @param bool $cached If true returns, if availanle, the result of
     *  a previous call
     *
     * @return array The active loans
     */
    public function getActiveLoansAry($cached = true) {
        global $sc;

        $activeLoansFilter = array('B', 'M', 'N');

        if (!$cached || !$this->activeLoans) {
            $connector = $this->getConnector();

            try {
                $response = $connector->getPatronActiveLoans($this->getUsername());
            } catch (Exception $e) {
                return array();
            }

            foreach ($response as $index => $loan) {
                if (!in_array($loan['LoanStatus'], $activeLoansFilter))
                    unset($response[$index]);
            }

            $that = $this;

            $response = array_map(function($loan) use($that) {
                $actualLibrary = $that->getLibraryRepository()->getByExternalId('CLAVIS', $loan['ActualLibraryId']);
                $loan['ActualLibraryLabel'] = is_object($actualLibrary) ? $actualLibrary->getShortName() : "-";
                $loan['LoanStatusLabel'] = _tdef('LV_LOANSTATUS.' . $loan['LoanStatus']);
                $loan['ManifestationUrl'] = ManifestationPage::getDefaultUrl($loan['ManifestationId']);

                $date = new Date();
                $date->setValue($loan['DueDate']);
                $loan['DueDate'] = $date;
                //Debugging renews:
                //$loan['Renewable'] = 1;
                //$loan['ExtraLib'] = 0;

                return $loan;
            }, $response);

            $this->activeLoans = $response;
        }

        return $this->activeLoans;
    }

    /**
     * @param bool $cached If true returns, if availanle, the result of
     *  a previous call
     *
     * @return DataObjectSet The active loans
     */
    public function getActiveLoans($cached = true) {
        return new DataObjectSet($this->getActiveLoansAry($cached));
    }

    private $maxDeliveryTimeout;

    /**
     * @param bool $cached If true returns, if available, the result of
     *   a previous call
     * @return DataObjectSet The pending loans
     */
    public function getPendingLoans($cached = true) {

        if (!$cached || !$this->pendingLoans) {
            $connector = $this->getConnector();

            try {
                $response = $connector->getPatronPendingLoans($this->getUsername());
            } catch (Exception $e) {
                return new DataObjectSet();
            }

           $this->maxDeliveryTimeout = '0';
            if (isset($response["maxDeliveryTimeout"])) {
                $this->maxDeliveryTimeout = (string) $response["maxDeliveryTimeout"];
                unset($response["maxDeliveryTimeout"]);
            }

            $that = $this;

            $response = array_map(function($loan) use($that) {
                $deliveryLibrary = $that->getLibraryRepository()->getByExternalId('CLAVIS', $loan['DeliveryLibraryId']);
                $loan['LoanStatusLabel'] = _tdef('LV_LOANSTATUS.' . $loan['LoanStatus']);
                $loan['ManifestationUrl'] = ManifestationPage::getDefaultUrl($loan['ManifestationId']);
                $loan['DeliveryLibraryLabel'] = is_object($deliveryLibrary) ? $deliveryLibrary->getShortName() : "-";

                if ($loan['LoanStatus'] == "F")
                    $loan['MaxDeliveryToDate'] = date('d/m/Y', strtotime($loan['LastSeen']. ' + '. $this->maxDeliveryTimeout . ' days'));

                return $loan;
            }, $response);

            $this->pendingLoans = new DataObjectSet($response);
        }

        return $this->pendingLoans;
    }

    private $lastPageClosedLoans;
    private $totalClosedLoans;
    private $searchTextClosedLoans;
    private $actualPageClosedLoans;

    /**
     * Prestiti conclusi con paginazione a blocchi di 10
     * 
     * @param type $page
     * @param type $orderByTitle
     * @param type $orderByBeginDate
     * @param type $orderByEndDate
     * @param type $output
     * @return \DataObjectSet
     */
    public function getClosedLoans($page = 0, $orderByTitle = 1, $orderByBeginDate = 1, $orderByEndDate = 2, $search = "", $output = null) {
        $download = 0;
        $limit = 10;
        if ($page === "D") {
            $page = 0;
            $download = 1;
            $limit = 1;
        }
        $start = ($page * $limit);
        global $sc;
        $connector = $sc->get('liquens.connector');
        if (isset($output) && ($output == true)) {
            $member = Member::currentUser()->username;
        } else {
            $member = $this->getUsername();
        }

        $orderBy = null;
        $orderDirection = null;

        /* 0: ^ ASC, 1: neutro, 2: v DESC */
        if ($orderByTitle != 1) {
            $orderBy = "orderByTitle";
            if ($orderByTitle == 0) {
                $orderDirection = "ASC";
            } else {
                $orderDirection = "DESC";
            }
            $orderByBeginDate = 1;
            $orderByEndDate = 1;
        } else if ($orderByBeginDate != 1) {
            $orderBy = "orderByLoanDateBegin";
            if ($orderByBeginDate == 0) {
                $orderDirection = "ASC";
            } else {
                $orderDirection = "DESC";
            }
            $orderByTitle = 1;
            $orderByEndDate = 1;
        } else if ($orderByEndDate != 1) {
            $orderBy = "orderByLoanDateEnd";
            if ($orderByEndDate == 0) {
                $orderDirection = "ASC";
            } else {
                $orderDirection = "DESC";
            }
            $orderByTitle = 1;
            $orderByBeginDate = 1;
        }

        $search = strip_tags(json_decode($search, true));
        
        try {
            $response = $connector->getPatronClosedLoans($member, $start, $limit, $search, $orderBy, $orderDirection);
        } catch (Exception $e) {
            $response = array();
        }

        if (!empty($response)) {

            if ($response[0] > 0) {
                if ($download == 1) {
                    try {
                        $response = $connector->getPatronClosedLoans($member, 0, $response[0], $search, $orderBy, $orderDirection);
                    } catch (Exception $e) {
                        $response = array();
                    }
                }
                /* Salvataggio testo ricerca */
                $this->searchTextClosedLoans = $search;
                /* Salvataggio totale risultati */
                $this->totalClosedLoans = $response[0];
                unset($response[0]);
                /* Salvataggio numero logico di pagina attuale */
                $this->actualPageClosedLoans = $page + 1;
                /* Calcolo numero totale di pagine necessarie */
                $this->lastPageClosedLoans = ((int) ($this->totalClosedLoans / $limit)) + (($this->totalClosedLoans % $limit) > 0 ? 1 : 0);

                $result = array_map(function($loan) {
                    $loan['ManifestationUrl'] = ManifestationPage::getDefaultUrl($loan['ManifestationId']);
                    //Transform dates in SS Date objects
                    $date = new Date();
                    $date->setValue($loan['LoanDateBegin']);
                    $loan['LoanDateBegin'] = $date;
                    $loan['ajaxLoanDateBegin'] = date_format(date_create($date->value), 'd/m/Y');
                    $loan['ajaxLoanDateBeginData'] = strtotime(date_format(date_create($date->value), 'd-m-Y'));
                    $date = new Date();
                    $date->setValue($loan['LoanDateEnd']);
                    $loan['LoanDateEnd'] = $date;
                    $loan['ajaxLoanDateEnd'] = date_format(date_create($date->value), 'd/m/Y');
                    $loan['ajaxLoanDateEndData'] = strtotime(date_format(date_create($date->value), 'd-m-Y'));
                    return $loan;
                }, $response);
                if (isset($output) && ($output == true)) {
                    if ($download == 1) {
                        $result[0] = join('_', array(
                            $this->totalClosedLoans,
                            Member::currentUser()->FirstName . "-" . Member::currentUser()->Surname,
                            date("d-m-Y")
                                )
                        );
                    } else {
                        $result[0] = join('-', array(
                            $page, /* Numero pagina attuale */
                            $orderByTitle,
                            $orderByBeginDate,
                            $orderByEndDate,
                            $page > 0 ? 1 : 0, /* Tasti pagine precedenti */
                            ($this->lastPageClosedLoans > ($page + 1)) ? 1 : 0, /* Tasti pagine successive */
                            ($this->lastPageClosedLoans >= 1) ? $this->lastPageClosedLoans : 0, /* Numero totale di pagine */
                            $this->totalClosedLoans,
                            $this->actualPageClosedLoans,
                            $this->searchTextClosedLoans)
                        );
                    }
                }
            } else {
                return false;
            }
            if (isset($output) && ($output == true)) {
                return json_encode($result);
            }
            return new DataObjectSet($result);
        } else {
            return false;
        }
    }

    public function ActualPageClosedLoans() {
        return $this->actualPageClosedLoans;
    }

    public function SearchtextClosedLoans() {
        return $this->searchTextClosedLoans;
    }

    public function LastPageClosedLoans() {
        return $this->lastPageClosedLoans;
    }

    /**
     * Calcolo necessità di più pagine
     * 
     * @return type
     */
    public function MultiPagesClosedLoans() {
        return ($this->lastPageClosedLoans > 1) ? true : false;
    }

    public function TotalClosedLoans() {
        return $this->totalClosedLoans;
    }

    private $multiplePagesProposals;
    private $totalProposals;
    private $lastPageProposals;
    private $actualPageProposals;

    /**
     * Proposte inviate con paginazione a blocchi di 10
     * 
     * @global type $sc
     * @param type $page
     * @param type $output
     * @return \DataObjectSet
     * 
     */
    public function getPurchaseProposals($page = 0, $output = null) {
        $limit = 10;
        $start = ($page * $limit);
        global $sc;
        $connector = $sc->get('liquens.connector');
        if (isset($output) && ($output == true)) {
            $member = Member::currentUser()->username;
        } else {
            $member = $this->getUsername();
        }
        try {
            $response = $connector->getPurchaseProposalList($member, '', $start, $limit);
        } catch (Exception $e) {
            $response = array();
        }

        if (!empty($response)) {
//            if (is_array($response[0])) { $this->totalClosedLoans = count($response); } else { $this->totalClosedLoans = $response[0]; unset($response[0]); }
            $this->totalProposals = $response[0];
            unset($response[0]);

            $this->actualPageProposals = $page + 1;
            $this->lastPageProposals = ((int) ($this->totalProposals / $limit)) + (($this->totalProposals % $limit) > 0 ? 1 : 0);

            $result = array_map(function($proposal) {
                $date = new Date();
                $date->setValue($proposal['ProposalDate']);
                $proposal['ProposalDate'] = $date;
                $proposal['StatusLabel'] = _tdef('LV_PROPOSALSTATUS.' . $proposal['Status']);
                $proposal['Author'] = !empty($proposal['Author']) ? ucwords($proposal['Author']) : '';
                $proposal['ajaxProposalDate'] = date_format(date_create($date->value), 'd/m/Y');
                $proposal['ajaxProposalDateData'] = strtotime(date_format(date_create($date->value), 'd-m-Y'));
                $proposal['ajaxStatusLabel'] = _tdef('LV_PROPOSALSTATUS.' . $proposal['Status']);
                $proposal['ajaxAuthor'] = !empty($proposal['Author']) ? ' (' . ucwords($proposal['Author']) . ')' : '';
                $proposal['ajaxLibrarianNotes'] = !is_null($proposal['LibrarianNotes']) ? '<br><i>' . $proposal['LibrarianNotes'] . '</i>' : '';
                return $proposal;
            }, $response);

            $this->multiplePagesProposals = $this->totalProposals > $limit;

            if (isset($output) && ($output == true)) {
                $result[0] = join('-', array(
                    $page,
                    $page > 0 ? 1 : 0,
                    ($this->totalProposals / $limit) > ($page + 1) ? 1 : 0,
                    $this->lastPageProposals >= 1 ? $this->lastPageProposals : 0,
                    $this->actualPageProposals)
                );
            }

            if (isset($output) && ($output == true)) {
                return json_encode($result);
            }
            return new DataObjectSet($result);
        }
    }

    public function TotalProposals() {
        return $this->totalProposals;
    }

    public function MultiPagesProposals() {
        return $this->multiplePagesProposals;
    }

    public function LastPageProposals() {
        return $this->lastPageProposals - 1;
    }

    public function MaxPageProposals() {
        return $this->lastPageProposals;
    }

    public function ActualPageProposals() {
        return $this->actualPageProposals;
    }

    /**
     * @param bool $cached If true returns, if available, the result of
     *   a previous call
     *
     * @return array The active requests
     */
    public function getActiveRequestsAry($cached = true) {
        if (!$cached || !$this->activeRequests) {
            $connector = $this->getConnector();

            try {
                $response = $connector->getPatronActiveRequests($this->getUsername());
            } catch (Exception $e) {
                $response = array();
            }

            $that = $this;

            $response = array_map(function($request) use($that) {
                $deliveryLibrary = $that->getLibraryRepository()->getByExternalId('CLAVIS', $request['DeliveryLibraryId']);

                $request['RequestStatusLabel'] = _tdef("LV_ITEMREQUESTSTATUS.{$request['RequestStatus']}");

                $dateRequest = new Date();
                $dateRequest->setValue($request['RequestDate']);
                $request['RequestDate'] = $dateRequest;

                $dateExpire = new Date();
                $dateExpire->setValue($request['ExpireDate']);
                
                $request['ExpireDate'] = $dateExpire;
                $request['DeliveryLibraryLabel'] = is_object($deliveryLibrary) ? $deliveryLibrary->getShortName() : "-";
                $request['ManifestationUrl'] = ManifestationPage::getDefaultUrl($request['ManifestationId']);
                $request['QueueNice'] = $request['Queue'];
                $request['IsExtra'] = $request['RequestNote'] == 'EXTRA-AUTO';

                return $request;
            }, $response);

            $this->activeRequests = $response;
        }

        return $this->activeRequests;
    }

    /**
     * @param bool $cached If true returns, if available, the result of
     *   a previous call
     *
     * @return DataObjectSet The active requests
     */
    public function getActiveRequests($cached = true) {
        return new DataObjectSet($this->getActiveRequestsAry($cached));
    }

    /**
     * Tells if the request is owned by the member
     *
     * @param int $requestId
     * @return boolean
     */
    public function ownsRequest($requestId) {
        foreach ($this->getActiveRequestsAry() as $reservation) {
            if ($reservation['RequestId'] == $requestId)
                return true;
        }

        return false;
    }

    /**
     * Return member's privacy settings
     *
     * @return array
     */
    public function getPrivacySettings() {
        $settings = $this->owner->Privacy ? unserialize($this->owner->Privacy) : array();

        return array_merge(LQConfig::get('defaultPrivacySettings'), $settings);
    }

    /**
     * Sets a privacy value
     *
     * @param string $setting The name of the setting
     * @param mixed $value A serializable value
     * @return LqMemberDecorator
     */
    public function setPrivacySetting($setting, $value) {
        $settings = $this->owner->Privacy ? unserialize($this->owner->Privacy) : array();

        $settings[$setting] = $value;

        $this->owner->Privacy = serialize($settings);

        return $this;
    }

    /**
     * Returns the value of a privacy setting
     *
     * @param string $setting The name of the setting
     * @return mixed
     * @throws Exception
     */
    public function getPrivacySetting($setting) {
        $settings = $this->getPrivacySettings();

        if (!isset($settings[$setting])) {
            throw new \InvalidArgumentException(sprintf('%s is not a valid privacy setting', $setting));
        }

        return $settings[$setting];
    }

    public function loginAsAnotherUser($username) {
        if (!$this->isSitemaster()) {
            return false;
        }

        $usernameSafe = Convert::raw2sql($username);
        $memberId = 0;
        $member = Member::get_one('Member', "External_SourceID='liquens' AND Username='$usernameSafe'");

        //The member already exist in dng
        if ($member) {
            $memberId = $member->ID;
        }
        //The member exists in Clavis but not in DNG
        elseif ($userData = $this->getConnector()->getUserData($username)) {
            //Create the user
            /** @var $member Member */
            $member = SSObject::create('Member');
            $member->External_SourceID = 'liquens';
            $member->External_Anchor = $userData['ClavisUserType'] . ':' . $userData['ClavisUserID'];
            $member->Username = $username;
            $member->write();
            $member->memberLoggedIn();

            $memberId = $member->ID;
        }
        //The member does not exist
        else {
            return false;
        }

        Session::set("loggedInAs", $memberId);
    }

    /*
     * Created default shelves based on $data
     * Example of valid $data argument:
     * <code>
     * array(
     *    'Favourites' => array(
     *        'ClassName' => 'ManifestationsShelf',
     *        'Description' => '',
     *        'Visibility' => 'public',
     *        'Data' => array()
     *    ),
     *    'Finished' => array(
     *        'ClassName' => 'ManifestationsShelf',
     *        'Description' => '',
     *        'Visibility' => 'public',
     *        'Data' => array()
     *    ),
     *    'Not Finished' => array(
     *        'ClassName' => 'ManifestationsShelf',
     *        'Description' => '',
     *        'Visibility' => 'public',
     *        'Data' => array()
     *    ),
     *
     *  );
     * </code>
     * @param array $data
     */

    public function createShelves($data) {
        foreach ($data as $shelfName => $shelfData) {
            //Check if the shelf already exists
            $filter = sprintf("OwnerID = %d AND Name = '%s'", $this->owner->ID, Convert::raw2sql($shelfName));
            $shelf = DataObject::get_one($shelfData['ClassName'], $filter);

            //Otherwise we create it
            if (!$shelf) {
                /** @var $shelf Shelf */
                $shelf = new $shelfData['ClassName'];
                $shelf->Name = $shelfName;
                $shelf->Description = $shelfData['Description'];
                $shelf->OwnerID = $this->owner->ID;
                $shelf->visibility = $shelfData['Visibility'];
                $shelf->setData($shelfData['Data']);
                $shelf->write();
            }
        }
    }

    /**
     * Returns the shelves owned by the member
     *
     * @param null $visibility
     * @param string $className
     * @return DataObjectSet
     */
    public function Shelves($visibility = null, $className = 'ManifestationsShelf') {
        return Shelf::get_shelves_for_owner($this->owner, $className, $visibility);
    }

    /**
     * @param null $visibility
     * @return DataObjectSet
     */
    public function SavedSearches($visibility = null) {
        return Shelf::get_shelves_for_owner($this->owner, 'MappedSearchShelf', $visibility);
    }

    /**
     * @return LiquensConnector
     */
    private function getConnector() {
        global $sc;
        return $sc->get('liquens.connector');
    }

    /**
     * Set LibraryRepository
     *
     * @param \LibraryRepository $libraryRepository
     *
     * @return LqMemberDecorator The current instance
     */
    public function setLibraryRepository(\LibraryRepository $libraryRepository) {
        $this->libraryRepository = $libraryRepository;
        return $this;
    }

    /**
     * Get LibraryRepository
     *
     * @return \LibraryRepository
     */
    public function getLibraryRepository() {
        if (!isset($this->libraryRepository)) {
            global $sc;

            $this->libraryRepository = $sc->get('library.repository');
        }

        return $this->libraryRepository;
    }

    /**
     * @return UserDataBag|UserDataBagProxy
     */
    public function getUserDataBag() {
        if (!isset($this->dataBag)) {
            global $sc;
            $cachingInterval = $sc->getParameter('userdata.caching_interval');
            $this->dataBag = new UserDataBagProxy(new UserDataBag($this->owner->ID), $cachingInterval);
        }

        return $this->dataBag;
    }

    /**
     * Retrieve a data value from the UserDataBag
     *
     * @param string $name The name of the user data
     * @return mixed
     */
    public function UserData($name) {
        try {
            return $this->getUserDataBag()->getData($name)->getValue();
        } catch (Exception $e) {
            return null;
        }
    }

    /**
     * @return mixed
     */
    public function LateLoansCount() {
        return $this->UserData('LateLoansCount');
    }

    /**
     * @return mixed
     */
    public function PatronStatus() {
        $status = $this->UserData('PatronStatus');

        if (in_array($status, array('C', 'B', 'R'))) {
            return _t("LV_PATRONSTATE.$status", '');
        }

        return false;
    }

}
