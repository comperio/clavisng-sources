<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class CalendarDateTimeDecorator extends DataObjectDecorator
{
    /**
     * Tells if the datetime spans only one day
     * @return bool
     */
    public function isInOneDay()
    {
        if(! $this->owner->EndDate) {
            return true;
        }

        return $this->owner->EndDate == $this->owner->StartDate;
    }

    /**
     * @return bool
     */
    public function isInOneMonth()
    {
        if(! $this->owner->EndDate) {
            return true;
        }

        return date('Y-F', strtotime($this->owner->StartDate)) == date('Y-F', strtotime($this->owner->EndDate)) ;
    }

    /**
     * @return bool
     */
    public function isInOneYear()
    {
        if(! $this->owner->EndDate) {
            return true;
        }

        return date('Y', strtotime($this->owner->StartDate)) == date('Y', strtotime($this->owner->EndDate)) ;
    }


    /**
     * @return bool
     */
    public function startInCurrentYear()
    {
        return date('Y', strtotime($this->owner->StartDate)) == date('Y') ;
    }

    /**
     * @return string
     */
    public function SmartStartDate()
    {
        $format = "%e";

        if($this->isInOneDay() || !$this->isInOneMonth())
            $format .= " %B";

        if(($this->isInOneDay() && !$this->startInCurrentYear()) || !$this->isInOneYear())
            $format .= " %Y";

        return strftime($format, strtotime($this->owner->StartDate));
    }

    /**
     * @return string
     */
    public function SmartEndDate()
    {
        $format = "%e %B";

        if(!$this->startInCurrentYear())
            $format .= " %Y";

        return strftime($format, strtotime($this->owner->EndDate));
    }
}
