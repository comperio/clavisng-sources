<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class LqDataObjectDecorator extends Extension
{
    /**
     * Function siimlar to Top to get the current controller even if the controller is not at the top of the stack
     *
     * @return Controller
     */
    public function dTop()
    {
        $top = Controller::curr();
        return $top;
    }

    /**
     * Workaround for SS limits in if statements in templates. In a tempalte I cannot use the expression
     * <% if Modulus(3)=1 %> or <% if MultipleOF(3,1) %>
     * This method take both the base and the module in the same string, separated by a '-'
     *
     * @param $baseAndModule
     *
     * @return bool
     */
    public function ModuleIs($baseAndModule)
    {
        list($base, $module) = explode('-', $baseAndModule);

        return $this->owner->Pos() % $base == $module;
    }

    /**
     * Returns true if the dataset has only one entry
     */
    public function OnlyOne()
    {
        return $this->owner->Count() == 1;
    }

    /**
     * @return bool
     */
    public function IsLastPage()
    {
        return $this->owner->CurrentPage() == $this->owner->TotalPages();
    }

    /**
     * Put to 0 all WidgetArea keys.
     */
    public function resetAllWidgetAreas()
    {
        foreach (SSObject::get_static(get_class($this->getOwner()), 'has_one') as $name => $class) {
            if ($class === 'WidgetArea') {
                $keyFieldName = $name . 'ID';
                $this->owner->$keyFieldName = 0;
            }
        }
    }

    /**
     * Duplicate all children areas of the decorated object
     */
    public function duplicateOwnedWidgetAreas()
    {
        foreach (SSObject::get_static(get_class($this->getOwner()), 'has_one') as $name => $class) {
            if ($class === 'WidgetArea') {
                $clonedArea = $this->duplicateWidgetArea($this->owner->$name());
                $keyFieldName = $name . 'ID';
                $this->owner->$keyFieldName = $clonedArea->ID;
            }
        }
        $this->owner->write();
    }

    /**
     * Duplicate a widget area and its child widgets
     *
     * @param WidgetArea $area
     * @return WidgetArea
     */
    public function duplicateWidgetArea(WidgetArea $area)
    {
        $clonedArea = new WidgetArea;
        $clonedArea->write();

        foreach ($area->Widgets() as $widget) {
            $clonedWidget = $widget->duplicate();
            $clonedArea->Widgets()->add($clonedWidget);
        }

        return $clonedArea;
    }
}
