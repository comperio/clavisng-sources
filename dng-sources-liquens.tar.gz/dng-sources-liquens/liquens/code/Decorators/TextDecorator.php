<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class TextDecorator extends Extension
{
	/**
	 * @param int $numWords
	 * @param string $add
	 * 
	 * @return string 
	 */
    public function NoHTMLAndLimitWordCount($numWords = 15, $add = '...')
    {
        $value = strip_tags($this->owner->getValue());

        $value = trim(Convert::xml2raw($value));

        $ret = explode(' ', $value, $numWords + 1);

        if(count($ret) <= $numWords - 1) {
            $ret = $value;
        } else {
            array_pop($ret);
            $ret = implode(' ', $ret) . $add;
        }

        return $ret;
    }
}
