<?php

/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class EventCalendarAdmin extends ModelAdmin {

    /** @var string */
    public static $collection_controller_class = "EventCalendarAdmin_CollectionController";

    /** @var string */
    public static $record_controller_class = "EventCalendarAdmin_RecordController";

    /** @var array */
    public static $managed_models = array(
        'CalendarEvent',
    );

    /**
     * Class name of the form field used for the results list.  Overloading this in subclasses
     * can let you customise the results table field.
     */
    protected $resultsTableClassName = 'EventCalendarTableListField';

    /** @var string The url segment in the cms */
    static $url_segment = 'events';

    /** @var string The menu Label shown in the CMS */
    static $menu_title = 'Eventi';

    /**
     * Load some js and css requirements
     *
     * @return SS_HTTPResponse|void
     */
    public function init() {
        parent::init();

        Requirements::javascript('liquens/javascript/cms/eventcalendaradmin.js');
        Requirements::css('liquens/css/eventcalendaradmin.css');
    }

}

class EventCalendarAdmin_CollectionController extends ModelAdmin_CollectionController {

    /**
     * @var LibraryRepository
     */
    private $libraryRepository;

    /**
     * Get a combination of the Search, Import and Create forms that can be inserted into a {@link ModelAdmin} sidebar.
     *
     * @return string
     */
    public function getModelSidebar() {
        return $this->renderWith('EventCalendarModelSidebar');
    }

    /**
     * Overload SearchForm method
     *
     * @return Form
     */
    public function SearchForm() {
        $context = $this->getSearchContext();
        $fields = $context->getSearchFields();

        $validator = new RequiredFields();
        $validator->setJavascriptValidationHandler('none');

        $form = new Form($this, "SearchForm", $fields, new FieldSet(
                new FormAction('search', 'Visualizza Eventi'), $clearAction = new ResetFormAction('clearsearch', _t('ModelAdmin.CLEAR_SEARCH', 'Clear Search'))
                ), $validator
        );
        //$form->setFormAction(Controller::join_links($this->Link(), "search"));
        $form->setFormMethod('get');
        $form->setHTMLID("Form_SearchForm_" . $this->modelClass);
        $form->disableSecurityToken();
        $clearAction->useButtonTag = true;
        $clearAction->addExtraClass('minorAction');

        return $form;
    }

    /**
     * Overload of ResultForm method
     *
     * @param $searchCriteria
     * @return Form
     */
    public function ResultsForm($searchCriteria) {
        $title = 'Tutti gli eventi del sistema';

        if ($searchCriteria['libraryId']) {
            $libraryMainPage = $this->getLibraryMainPage($searchCriteria);
            $title = 'Tutti gli eventi della biblioteca di ' . $libraryMainPage->MenuTitle;
        }

        if (!$searchCriteria['include_expired']) {
            $title .= " (correnti e futuri)";
        } else {
            $title .= ' (compresi quelli passati)';
        }

        $form = parent::ResultsForm($searchCriteria);

        //Remove "Search Result" Header
        $form->Fields()->shift();
        $form->Fields()->insertFirst(new LiteralField('aaa', "<h1 class='searchResultsTitle'>$title</h1>"));

        return $form;
    }

    /**
     * @return bool|Form
     */
    public function CreateForm() {
        $form = parent::CreateForm();
        $librariesMap = Member::currentUser()->getLinkedLibrariesPages()->map('ID', 'MenuTitle');
        $userFavLib = $this->getCurrentUserFavouriteLibraryID();

        if (count($librariesMap) > 1)
            $librariesMap = array('' => 'Seleziona una biblioteca') + $librariesMap;


        $libraryDropDown = new DropdownField(
                'newEventLibraryId', 'per la biblioteca', $librariesMap, $userFavLib
        );

        $form->Fields()->push($libraryDropDown);

        //Don't allow to create events if there is no library selected
        if (!$userFavLib && count($librariesMap) > 1)
            $form->Actions()->First()->setReadonly(true);

        $form->Actions()->renameField('action_add', 'Crea Evento');

        return $form;
    }

    /**
     * Remove export permissions from EventCalendarTableListField
     *
     * @param array $searchCriteria
     *
     * @return EventCalendarTableListField
     */
    public function getResultsTable($searchCriteria) {
        $resultsTable = parent::getResultsTable($searchCriteria);
        $resultsTable->setPermissions(array_merge(array('view'), TableListField::permissions_for_object($this->modelClass)));

        return $resultsTable;
    }

    /**
     * Taken from http://www.leftandmain.com/uncategorized/2011/02/25/taming-the-beast-remodeling-modeladmin/
     *
     * @param unknown_type $request
     * @return unknown
     */
    public function add($request) {
        $newRecord = new $this->modelClass();
        $newRecord->Title = 'Nuovo evento';

        if ($libraryId = $this->request->postVar('newEventLibraryId')) {
            $calendar = DataObject::get_one('Calendar', sprintf("SiteTree.ParentID=%d", $libraryId));
            $newRecord->ParentID = $calendar->ID;
        }

        $newRecord->write();

        $class = $this->parentController->getRecordControllerClass($this->getModelClass());
        $response = new $class($this, $newRecord, $newRecord->ID);

        return $response->edit($request);
    }

    /**
     * Used to specify the main column header. Other Columns are created directly in the tamplete
     * @return array
     */
    public function columnsAvailable() {
        return array('Title' => 'Nome dell\'evento');
    }

    /**
     * Returns a libraryMainPage from a searchCriteria
     *
     * @param $searchCriteria
     * @return bool|LibraryMainPage
     */
    private function getLibraryMainPage($searchCriteria) {
        if (isset($searchCriteria['libraryId'])) {
            $libraryMainPage = LibraryMainPage::get_by_id(
                            'LibraryMainPage', (int) $searchCriteria['libraryId']
            );
        } else {
            $libraryMainPage = false;
        }

        return $libraryMainPage;
    }

    /**
     * Return the current user Favourite Library ID
     *
     * @return string
     */
    public function getCurrentUserFavouriteLibraryID() {
        //TODO: Caching the call?
        $libraryPage = Member::currentUser()->getFavouriteLibraryPage();
        $defaultLibraryId = $libraryPage ? $libraryPage->ID : '';

        return $defaultLibraryId;
    }

    /**
     * We do not want to use the default search context for the CalendarEvent Model!
     *
     * @param array $searchCriteria
     * @return SQLQuery
     */
    public function getSearchQuery($searchCriteria) {
        $context = $this->getSearchContext();
        return $context->getQuery($searchCriteria);
    }

    /**
     * Build the search context
     *
     * @return EventsSearchContext
     */
    private function getSearchContext() {
        global $sc;
        $fields = new FieldSet();
        $libraryPages = DataObject::get('LibraryMainPage');
        if ($sc->getParameter('is_library') == true) {
            $fields->push(new DropdownField(
                    'libraryId', _t('Liquens.LIBRARY', 'Biblioteca'), array('' => _t('EventsWidget.ALLLIBRARIES', 'Tutte le biblioteche')) + $libraryPages->map('ID', 'MenuTitle'), $this->getCurrentUserFavouriteLibraryID()
            ));
        } else {
            $fields->push(new DropdownField(
                    'libraryId', _t('Liquens.MUSEUM', 'Museo'), array('' => _t('EventsWidget.ALLMUSEUMS', 'Tutti i musei')) + $libraryPages->map('ID', 'MenuTitle'), $this->getCurrentUserFavouriteLibraryID()
            ));
        }
        $fields->push(new CheckboxField('include_expired', 'Includi anche gli eventi passati', false));

        return new EventsSearchContext('CalendarEvent', $fields);
    }

    /**
     * Set LibraryRepository
     *
     * @param \LibraryRepository $libraryRepository
     *
     * @return EventCalendarAdmin_CollectionController The current instance
     */
    public function setLibraryRepository(\LibraryRepository $libraryRepository) {
        $this->libraryRepository = $libraryRepository;

        return $this;
    }

    /**
     * Get LibraryRepository
     *
     * @return \LibraryRepository
     */
    public function getLibraryRepository() {
        if (!isset($this->libraryRepository)) {
            global $sc;
            $this->libraryRepository = $sc->get('library.repository');
        }

        return $this->libraryRepository;
    }

}

class EventCalendarAdmin_RecordController extends ModelAdmin_RecordController {

    /**
     * @return mixed
     */
    public function getLibraryMainPage() {
        return $this->getCurrentRecord()->Parent()->Parent();
    }

    /**
     * @return Form
     */
    public function EditForm() {
        $form = parent::EditForm();
        $libPage = $this->getLibraryMainPage();
        $event = $this->getCurrentRecord();
        $title = $event->Title ? : "Nuovo evento per la biblioteca di {$libPage->MenuTitle}";

        $live_link = Controller::join_links($this->currentRecord->Link(), '?stage=Live');
        $stage_link = Controller::join_links($this->currentRecord->Link(), '?stage=Stage');

        $form->setActions($this->currentRecord->getCMSActions());

        $form->Fields()->insertFirst(new LiteralField('back', '<h1 class="searchResultsTitle">' . $title . '</h1>', 'searchResultsTitle'));
        $form->Fields()->insertFirst(new LiteralField('back', '<h4>' . $libPage->Title . '</h4>'));
        $form->Fields()->insertFirst(new LiteralField('view', '<div id="eventCalendarAdminNav"><div class="modelpagenav clr">
                       			<button id="list_view">« Ritorna alla lista eventi</button>
           </div>
            <div class="publishpreviews clr">Vedi evento: <a href="' . $live_link . '" target="_blank">Sito Live</a>
            <a href="' . $stage_link . '" target="_blank">Sito bozza</a></div></div>'
        ));

        //$form->Fields()->push(new LiteralField('message', '<p id="statusMessage" style="visibility:hidden"></p>'));

        return $form;
    }

    /**
     * Publish action
     *
     * @param $data
     * @param $form
     * @param $request
     * @return SS_HTTPResponse
     */
    public function publish($data, $form, $request) {
        if ($this->currentRecord && !$this->currentRecord->canPublish()) {
            return Security::permissionFailure($this);
        }

        $form->saveInto($this->currentRecord);
        $this->currentRecord->doPublish();

        if (Director::is_ajax()) {
            return new SS_HTTPResponse(
                    Convert::array2json(array(
                        'html' => $this->EditForm()->forAjaxTemplate(),
                        'message' => _t('ModelAdmin.PUBLISHED', 'Published')
                    )), 200
            );
        } else {
            Director::redirectBack();
        }
    }

    /**
     * Unpublish action
     *
     * @param $data
     * @param $form
     * @param $request
     * @return SS_HTTPResponse
     */
    public function unpublish($data, $form, $request) {
        if ($this->currentRecord && !$this->currentRecord->canDeleteFromLive()) {
            return Security::permissionFailure($this);
        }

        $this->currentRecord->doUnpublish();

        if (Director::is_ajax()) {
            return new SS_HTTPResponse(
                    Convert::array2json(array(
                        'html' => $this->EditForm()->forAjaxTemplate(),
                        'message' => _t('ModelAdmin.UNPUBLISHED', 'Unpublished')
                    )), 200
            );
        } else {
            Director::redirectBack();
        }
    }

    /**
     * Rollback action
     *
     * @param $id
     * @param $version
     * @return DataObject|SS_HTTPResponse
     */
    protected function performRollback($id, $version) {
        $record = DataObject::get_by_id($this->currentRecord->class, $id);
        if ($record && !$record->canEdit()) {
            return Security::permissionFailure($this);
        }

        $record->doRollbackTo($version);
        return $record;
    }

    /**
     * Rollback action
     *
     * @param $data
     * @param $form
     * @param $request
     * @return SS_HTTPResponse
     */
    public function rollback($data, $form, $request) {
        $record = $this->performRollback($this->currentRecord->ID, "Live");
        if (Director::is_ajax()) {
            return new SS_HTTPResponse(
                    Convert::array2json(array(
                        'html' => $this->EditForm()->forAjaxTemplate(),
                        'message' => _t('ModelAdmin.ROLLEDBACK', 'Rolled back version')
                    )), 200
            );
        } else {
            Director::redirectBack();
        }
    }

    /**
     * Delete action
     *
     * @param $data
     * @param $form
     * @param $request
     * @return SS_HTTPResponse
     */
    public function delete($data, $form, $request) {
        $record = $this->currentRecord;
        if ($record && !$record->canDelete()) {
            return Security::permissionFailure();
        }

        // save ID and delete record
        $recordID = $record->ID;
        $record->delete();

        if (Director::is_ajax()) {
            $body = "";
            return new SS_HTTPResponse(
                    Convert::array2json(array(
                        'html' => $this->EditForm()->forAjaxTemplate(),
                        'message' => _t('ModelAdmin.DELETED', 'Deleted')
                    )), 200
            );
        } else {
            Director::redirectBack();
        }
    }

    public function save($data, $form, $request) {
        if ($this->currentRecord && !$this->currentRecord->canEdit()) {
            return Security::permissionFailure($this);
        }

        $form->saveInto($this->currentRecord);
        $this->currentRecord->write();

        if (Director::is_ajax()) {
            return new SS_HTTPResponse(
                    Convert::array2json(array(
                        'html' => $this->EditForm()->forAjaxTemplate(),
                        'message' => _t('ModelAdmin.SAVED', 'Saved')
                    )), 200
            );
        } else {
            Director::redirectBack();
        }
    }

    /**
     * @param $data
     * @param $form
     * @param $request
     * @return SS_HTTPResponse
     */
    public function deletefromlive($data, $form, $request) {
        Versioned::reading_stage('Live');
        $record = $this->currentRecord;
        if ($record && !($record->canDelete() && $record->canDeleteFromLive())) {
            return Security::permissionFailure($this);
        }

        $descRemoved = '';
        $descendantsRemoved = 0;

        // before deleting the records, get the descendants of this tree
        if ($record) {
            $descendantIDs = $record->getDescendantIDList();

            // then delete them from the live site too
            $descendantsRemoved = 0;
            foreach ($descendantIDs as $descID) {
                if ($descendant = DataObject::get_by_id('SiteTree', $descID)) {
                    $descendant->doDeleteFromLive();
                    $descendantsRemoved++;
                }
            }

            // delete the record
            $record->doDeleteFromLive();
        }

        Versioned::reading_stage('Stage');

        if (Director::is_ajax()) {
            $body = $this->parentController->ListView()->getBody();
            return new SS_HTTPResponse(
                    Convert::array2json(array(
                        'html' => $body,
                        'message' => _t('ModelAdmin.DELETEDFROMLIVE', 'Deleted')
                    )), 200
            );
        } else {
            Director::redirectBack();
        }
    }

}

/**
 * This context is used only to generate the SQLQuery used to retrieve the events
 */
class EventsSearchContext extends SearchContext {

    /**
     * @param array $searchParams
     * @param bool $sort
     * @param bool $limit
     * @param null $existingQuery
     * @return null|SQLQuery
     */
    public function getQuery($searchParams, $sort = false, $limit = false, $existingQuery = null) {
        $model = singleton($this->modelClass);

        /** @var $query SQLQuery */
        if ($existingQuery) {
            $query = $existingQuery;
        } else {
            $query = $model->extendedSQL();
        }

        $SQL_limit = Convert::raw2sql($limit);
        $query->limit($SQL_limit);
        $expiredCondition = "IF(ISNULL(`dt`.EndDate), `dt`.StartDate, `dt`.EndDate) >= DATE(NOW())";

        $SQL_sort = (!empty($sort)) ? Convert::raw2sql($sort) : singleton($this->modelClass)->stat('default_sort');

        if (is_object($searchParams)) {
            $searchParamArray = $searchParams->getVars();
        } else {
            $searchParamArray = $searchParams;
        }

        //Note Backticks are necessary! Because SS substitute table names in SQL augmentation, but only
        //those enclosed in backticks
        $query->leftJoin('CalendarEvent', '`CalendarEvent`.ID=`SiteTree`.ID');
        $query->leftJoin(
                'CalendarDateTime', '`dt`.EventID=`SiteTree`.ID', 'dt'
        );
        $query->select[] = '`dt`.StartDate as EventStartDate';
        $query->select[] = 'IF(ISNULL(`dt`.EndDate), `dt`.StartDate, `dt`.EndDate) AS EventEndDate';
        $query->select[] = '`dt`.StartTime as EventStartTime';
        $query->select[] = '`dt`.EndTime as EventEndTime';

        $query->select[] = "IF($expiredCondition, GREATEST(NOW(), CONCAT(`dt`.StartDate, ' ', IF(ISNULL(`dt`.StartTime),'00:00',`dt`.StartTime))),`dt`.StartDate) AS EventOrderDateTime";
        $query->select[] = "IF($expiredCondition, GREATEST(CONCAT(CURDATE(),' ', IF(ISNULL(`dt`.StartTime),'00:00',`dt`.StartTime)), CONCAT(`dt`.StartDate, ' ', IF(ISNULL(`dt`.StartTime),'00:00',`dt`.StartTime))), `dt`.StartDate) AS EventDateTime";

        $query->orderby('EventStartDate DESC, ID DESC');

        // If split events is specified, the query does not group on event id, so the same event is
        // returned multiple times, one for each CalendarDateTime relation
        if (!isset($searchParamArray['splitEvents']) || !$searchParamArray['splitEvents'])
            $query->groupby('`SiteTree`.ID');

        if (isset($searchParamArray['libraryId']) && $searchParamArray['libraryId']) {
            $searchParamArray['libraryId'] = Convert::raw2sql($searchParamArray['libraryId']);
            $query->leftJoin('SiteTree', '`c`.ID=`SiteTree`.ParentID', 'c');
            $query->leftJoin('LibraryMainPage', '`c`.ParentID=`l`.ID', 'l');
            $query->where('`l`.ID', $searchParamArray['libraryId']);
        }

        if (!isset($searchParamArray['include_expired']) || !$searchParamArray['include_expired']) {
            $query->where($expiredCondition);
        }

        if (isset($searchParamArray['month']) && $searchParamArray['month']) {
            $query->where(sprintf(
                            "'%s' BETWEEN DATE_FORMAT(`dt`.StartDate, '%%Y-%%m') AND DATE_FORMAT(`dt`.EndDate, '%%Y-%%m')", Convert::raw2sql($searchParamArray['month'])
            ));
        }

        if (isset($searchParamArray['categories']) && $searchParamArray['categories']) {
            $safeCats = array_map(function($catId) {
                return (int) $catId;
            }, $searchParamArray['categories']);

            $implodedCats = implode(', ', $safeCats);

            $query->leftJoin('CalendarEvent_LqEventCategories', '`cat`.CalendarEventID=`SiteTree`.ID', 'cat');
            $query->where("`cat`.LqEventCategoriesID IN ($implodedCats)");
            $query->distinct = true;
        }

        if (isset($searchParamArray['tags']) && $searchParamArray['tags']) {
            $safeTagsConditions = array_map(function($tag) {
                return "`CalendarEvent`.LqTags LIKE '%" . Convert::raw2sql($tag) . "%'";
            }, $searchParamArray['tags']);

            $condition = implode(' OR ', $safeTagsConditions);

            $query->where($condition);
        }

        if (isset($searchParamArray['text']) && $searchParamArray['text']) {
            $safeText = Convert::raw2sql($searchParamArray['text']);

            $query->where("`SiteTree`.Title LIKE '%$safeText%' OR `SiteTree`.Content LIKE '%$safeText%'");
        }

        $model->extend('augmentSQL', $query);

        return $query;
    }

}
