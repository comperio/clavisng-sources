<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class GeomapsAdmin extends ModelAdmin {

    public static $managed_models = array(
        'Geomap' => array(
            'title' => "Mappe",
            'collection_controller' => 'GeomapsAdmin_CollectionController',
            'record_controller' => 'GeomapsAdmin_RecordController'
        ),
        'GeomapPath' => array(
            'title' => "Percorsi",
            'collection_controller' => 'GeomapPathsAdmin_CollectionController',
            'record_controller' => 'GeomapPathsAdmin_RecordController'
        ),
        'GeomapPoint' => array(
            'title' => "Punti",
            'collection_controller' => 'GeomapPointsAdmin_CollectionController',
            'record_controller' => 'GeomapPointsAdmin_RecordController'
        )
    );
    public $showImportForm = false;
    static $url_segment = 'geomaps';
    static $menu_title = 'Mappe';

    public function init() {
        parent::init();

        Requirements::javascript('liquens/javascript/cms/geomaps.js');
        Requirements::css('liquens/css/geomaps.css');
    }

}

class GeomapsAdmin_CollectionController extends ModelAdmin_CollectionController {

    public function ColumnSelectionField() {
        return new LiteralField('', '');
    }

    public function AddForm() {
        $form = parent::AddForm();

        /* Se la mappa ha almeno un percorso, non mostro i campi sottostanti (da fare) */
        $form->Fields()->push(new ReadonlyField("Instructions", "Istruzioni", 'Di seguito potrai inserire i punti sulla mappa e decidere alcune informazioni sul percorso. Per aggiungere ulteriori punti dovrai utilizzare l\'interfaccia completa, cioè i tab "Percorsi" e "Punti".'));
        $form->Fields()->push(new TextField("NewPathName", "Inserisci il nome del percorso che associa la mappa ai punti"));
        $form->Fields()->push(new DropdownField("NewPathPoints", "Scegli la tipologia di percorso", array("punto" => "punto/i", "linea" => "linea")));
        $form->Fields()->push(new OsmapField("OsmapFirstInsert", "Clicca sulla mappa per fissare i punti", "[]", "100%", "600", 1, 5, "OverTile"));

        $form->Fields()->removeByName('GeomapPaths');

        return $form;
    }

    public function columnsAvailable() {
        return array('TitleMap' => 'Titolo', 'DescriptionMap' => 'Descrizione', 'MapLinkedPaths' => 'Percorsi e punti collegati');
    }

    public function ResultsForm($searchCriteria) {

        $form = parent::ResultsForm($searchCriteria);
        $form->Fields()->shift();
        $form->Fields()->insertFirst(new LiteralField('aaa', "<h1 class='searchResultsTitle'>Tutte le mappe del sistema</h1>"));

        return $form;
    }

    public function getResultsTable($searchCriteria) {
        
        $resultsTable = parent::getResultsTable($searchCriteria);
        $resultsTable->setPermissions(array_merge(array('view'), TableListField::permissions_for_object($this->modelClass)));

        return $resultsTable;
    }

}

class GeomapsAdmin_RecordController extends ModelAdmin_RecordController {
    
}

/**/

class GeomapPathsAdmin_CollectionController extends ModelAdmin_CollectionController {

    public function ColumnSelectionField() {
        return new LiteralField('', '');
    }

    public function AddForm() {
        $form = parent::AddForm();

        $form->Fields()->push(new ReadonlyField("InstructionsPath", "Istruzioni", 'Di seguito potrai inserire i punti sulla mappa del nuovo percorso. Se non vuoi associare alcuna mappa a questo percorso, non scegliere la mappa.'));
        $form->Fields()->push(new DropdownField("LinkedGeomapID", "Mappa a cui aggiungere il percorso", DataObject::get('Geomap')->toDropdownMap('ID', 'TitleMap', _t('DropdownField.CHOOSE'), true)));
        $form->Fields()->push(new OsmapField("OsmapFirstInsertPath", "Clicca sulla mappa per fissare i punti", "[]", "100%", "600", 1, 5));
        
        $script = '<script>(function ($) { $(document).ready(function () { '
                . '$("select#LinkedGeomapID").change(function () {'
                . ' var src = document.getElementById("OsmapIframe_OsmapFirstInsertPath").src; '
                . ' src = src.split("#"); '
                . ' var element = src[1].split("?"); '
                . ' if ($("select#LinkedGeomapID").val() != "") '
                . ' element[4] = $("select#LinkedGeomapID").val(); '
                . ' else '
                . ' delete(element[4]); '
                . ' document.getElementById("OsmapIframe_OsmapFirstInsertPath").src = src[0]+"#"+element.join("?"); '
                . ' document.getElementById("OsmapIframe_OsmapFirstInsertPath").contentWindow.location.reload(true); '
                . '});'
                . '});})(jQuery);</script>';
        $form->Fields()->push(new LiteralField('ScriptForReloadIFrame', $script));

        $form->Fields()->removeByName('Percorsi esistenti');

        return $form;
    }

    public function columnsAvailable() {
        return array('TitlePath' => 'Titolo', 'DescriptionPath' => 'Descrizione', 'TypePath' => 'Tipologia percorso', 'MapsLinkedPoints' => 'Mappe e punti collegati');
    }

    public function ResultsForm($searchCriteria) {

        $form = parent::ResultsForm($searchCriteria);

        $form->Fields()->shift();
        $form->Fields()->insertFirst(new LiteralField('aaa', "<h1 class='searchResultsTitle'>Tutti i percorsi del sistema</h1>"));

        return $form;
    }
    
    public function getResultsTable($searchCriteria) {
        
        $resultsTable = parent::getResultsTable($searchCriteria);
        $resultsTable->setPermissions(array_merge(array('view'), TableListField::permissions_for_object($this->modelClass)));

        return $resultsTable;
    }

}

class GeomapPathsAdmin_RecordController extends ModelAdmin_RecordController {

    public function EditForm() {
        $form = parent::EditForm();

        $form->Fields()->removeByName('Percorsi esistenti');

        return $form;
    }

}

/**/

class GeomapPointsAdmin_CollectionController extends ModelAdmin_CollectionController {

    public function ColumnSelectionField() {
        return new LiteralField('', '');
    }

    public function AddForm() {
        $form = parent::AddForm();

        $form->Fields()->push(new OsmapField("OsmapSinglePoint", "Clicca sulla mappa per fissare il nuovo punto", "[]", "25%", "250", 0, 4));

        $form->Fields()->removeByName('Percorsi');

        return $form;
    }

    public function columnsAvailable() {
        return array('TitlePoint' => 'Titolo', 'DescriptionPoint' => 'Descrizione',
            'TypePoint' => 'Tipologia media', 'CenterLat' => 'Latitudine',
            'CenterLon' => 'Longitudine', 'PathOrder' => 'Ordine dei punti', 'PointLinkedMaps' => 'Mappe e percorsi collegati');
    }

    public function ResultsForm($searchCriteria) {

        $form = parent::ResultsForm($searchCriteria);

        $form->Fields()->shift();
        $form->Fields()->insertFirst(new LiteralField('aaa', "<h1 class='searchResultsTitle'>Tutti i punti del sistema</h1>"));

        return $form;
    }

    public function getResultsTable($searchCriteria) {
        
        $resultsTable = parent::getResultsTable($searchCriteria);
        $resultsTable->setPermissions(array_merge(array('view'), TableListField::permissions_for_object($this->modelClass)));

        return $resultsTable;
    }
}

class GeomapPointsAdmin_RecordController extends ModelAdmin_RecordController {

    public function EditForm() {
        $form = parent::EditForm();

        $point = DataObject::get_by_id("GeomapPoint", $this->currentRecord->ID);
        $form->Fields()->push(new OsmapField("OsmapSinglePointChange", "Clicca sulla mappa per cambiare posizione punto", "{'lat':" . $point->CenterLat . ",'lng':" . $point->CenterLon . "}", "25%", "250", 0, 9));

        return $form;
    }

}
