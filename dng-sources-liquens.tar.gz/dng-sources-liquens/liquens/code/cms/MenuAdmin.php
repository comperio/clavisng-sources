<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class MenuAdmin extends ModelAdmin
{
    /** @var array */
    public static $managed_models = array(
         'MenuItem',
      );

    // Hide import form
    public $showImportForm = false;

    /** @var string */
    static $url_segment = 'menus'; // will be linked as /admin/products

    /** @var string */
     static $menu_title = 'Menu';

    /** @var string */
    public static $record_controller_class = "MenuAdmin_RecordController";

    /** @var string */
    public static $collection_controller_class = "MenuAdmin_CollectionController";

    /**
     * @return SS_HTTPResponse|void
     */
    public function init()
    {
        parent::init();
        Requirements::javascript('liquens/javascript/cms/menu.js');
    }
}

class MenuAdmin_RecordController extends ModelAdmin_RecordController
{
    /**
     * Overload parent method in order to save submenus items
     *
     * @param array $data
     * @param Form $form
     * @param SS_HTTPRequest $request
     * @return array|bool|DataObject|mixed|null|SS_HTTPResponse|string|ViewableObject
     */
    function doSave($data, $form, $request)
    {
        $this->currentRecord->Name = $data['Name'];
        $this->currentRecord->Locale = $data['Locale'];
        $form->saveInto($this->currentRecord);

        try {
            $this->currentRecord->write();
        } catch(ValidationException $e) {
            $form->sessionMessage($e->getResult()->message(), 'bad');
        }

        //Save subvoices
        if (isset($data['Subitems']))
            $this->currentRecord->saveSubitems($data['Subitems']);

        // Behaviour switched on ajax.
        if(Director::is_ajax()) {
            return $this->edit($request);
        } else {
            Director::redirectBack();
        }
    }

    /**
     * Copied from parent only to modify loadDataFrom... ARGH!
     */
    public function EditForm()
    {
        $fields = $this->currentRecord->getCMSFields();
        $fields->push(new HiddenField("ID"));

        $validator = ($this->currentRecord->hasMethod('getCMSValidator')) ? $this->currentRecord->getCMSValidator() : new RequiredFields();
        $validator->setJavascriptValidationHandler('none');

        $actions = $this->currentRecord->getCMSActions();
        if($this->currentRecord->canEdit(Member::currentUser())){
            $actions->push(new FormAction("doSave", _t('ModelAdmin.SAVE', "Save")));
        }else{
            $fields = $fields->makeReadonly();
        }

        if($this->currentRecord->canDelete(Member::currentUser())) {
            $actions->insertFirst($deleteAction = new FormAction('doDelete', _t('ModelAdmin.DELETE', 'Delete')));
            $deleteAction->addExtraClass('delete');
        }

        $actions->insertFirst(new FormAction("goBack", _t('ModelAdmin.GOBACK', "Back")));

        $form = new Form($this, "EditForm", $fields, $actions, $validator);
        $form->loadDataFrom($this->currentRecord, false, array());

        return $form;
    }


}

class MenuAdmin_CollectionController extends ModelAdmin_CollectionController
{
    /**
     * We do not want the column selection feature.
     *
     * @return LiteralField
     */
    public function ColumnSelectionField()
    {
       return new LiteralField('', '');
    }

    /**
     * Only Root MenuItem has to be displayed
     *
     * @param $searchCriteria
     * @return SQLQuery
     */
    function getSearchQuery($searchCriteria)
    {
        $query = parent::getSearchQuery($searchCriteria);

        $query->where[] = 'ParentID = 0 AND Locale =\'' . Convert::raw2sql($searchCriteria['Locale']) . '\'';
        $query->groupby[] = 'Name';
        $query->orderby = 'LastEdited DESC';

        return $query;
    }

    /**
     * * Overload parent method in order to save submenus items
     *
     * @param $data
     * @param $form
     * @param $request
     * @return SS_HTTPResponse
     */
    function doCreate($data, $form, $request) {
   		$className = $this->getModelClass();
   		$model = new $className();
   		// We write before saveInto, since this will let us save has-many and many-many relationships :-)
   		$model->write();
   		$form->saveInto($model);

        $model->Name = $data['Name'];
        $model->Locale = $data['Locale'];
   		$model->write();

        if (isset($data['Subitems']))
            $model->saveSubitems($data['Subitems']);

   		if(Director::is_ajax()) {
   			$class = $this->parentController->getRecordControllerClass($this->getModelClass());
   			$recordController = new $class($this, $request, $model->ID);
   			return new SS_HTTPResponse(
   				$recordController->EditForm()->forAjaxTemplate(),
   				200,
   				sprintf(
   					_t('ModelAdmin.LOADEDFOREDITING', "Loaded '%s' for editing."),
   					$model->Title
   				)
   			);
   		} else {
   			Director::redirect(Controller::join_links($this->Link(), $model->ID , 'edit'));
   		}
   	}

    public function SearchForm()
    {
        $form = parent::SearchForm();

        $fields = new FieldSet();Translatable::get_allowed_locales();
        $fields->push(new LocaleDropdown('Locale', 'Lingua del menù', i18n::get_locale()));

        $form->setFields($fields);

        return $form;
    }


    /**
     * Return the html for a new menu voice
     */
    public function newmenuitem(SS_HTTPRequest $request)
    {
        $item = new MenuItem;
        $item->Position = (int) $request->getVar('position');
        $item->Index = (int) $this->request->getVar('index');
        $item->Context = $item->getNamespacedValue($item->Index, $item->getSubitemsContext($request->getVar('parentContext')));

        return $item->getSubitemFields();
    }

    /**
     * Delete a menu item by its id
     *
     * @param SS_HTTPRequest $request
     * @return bool
     */
    public function deletemenuitem(SS_HTTPRequest $request)
    {
        $item = DataObject::get_by_id('MenuItem', (int) $request->postVar('id'));

        if ($item && $item->canDelete(Member::currentUser())) {
            $item->delete();
            return true;
        }

        return false;
    }

    /**
     * Delete all children of a menu item
     *
     * @param SS_HTTPRequest $request
     * @return bool
     */
    public function deletemenusubitems(SS_HTTPRequest $request)
    {
        $item = DataObject::get_by_id('MenuItem', (int) $request->postVar('id'));

        $item->deleteSubitems();

        return true;
    }
}
