<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

/**
 * Overload the TableListField for the CalendarEvents Objects
 * @see EventCalendarAdmin
 */
class EventCalendarTableListField extends TableListField
{
    protected $template = "EventCalendarTableListField";
    protected $permissions = array();

    public $actions = array();
    public $itemClass = 'EventCalendarTableListField_Item';

}

/**
 * Overload the row class of the EventCalendarTableListField
 */
class EventCalendarTableListField_Item extends TableListField_Item
{
    /**
     * Returns the CalendarEvent object
     *
     * @return DataObject
     */
    public function Item()
    {
        return $this->item;
    }

    /**
     * Gives the GrandParent Page, that should be a LibraryMainPage
     *
     * @return false|SiteTree
     */
    public function LibraryMainPage()
    {
        return $this->Item()->Parent()->Parent();
    }
}