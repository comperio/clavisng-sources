<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class LibraryAdmin extends ModelAdmin
{
    /** @var array */
    public static $managed_models = array(
         'LibraryDataObject',
      );

    // Hide import form
    public $showImportForm = false;

    /** @var string */
    static $url_segment = 'libraries'; // will be linked as /admin/products

    /** @var string */
     static $menu_title = 'Biblioteche';

    /** @var string */
    public static $record_controller_class = "LibraryAdmin_RecordController";

    /** @var string */
    public static $collection_controller_class = "LibraryAdmin_CollectionController";

    /**
     * @return SS_HTTPResponse|void
     */
    public function init()
    {
        parent::init();
        Requirements::javascript('liquens/javascript/cms/library.js');
    }
}

class LibraryAdmin_RecordController extends ModelAdmin_RecordController
{
    /**
     * Fetch data from the external source
     * @param $data
     * @param $form
     * @param $request
     * @return SS_HTTPResponse
     */
    public function fetchFromExternalSource($data, $form, $request)
    {
        $record = $this->getCurrentRecord();
        LibrariesSync::fill_library($record);

        try {
            LibrariesSync::fill_library($record);
            $record->write();
        } catch(ValidationException $e) {
            $form->sessionMessage($e->getResult()->message(), 'bad');
        } catch (Exception $e) {
            $form->sessionMessage($e->getMessage(), 'bad');
        }

      /*  // Behaviour switched on ajax.
        if(Director::is_ajax()) {
            return $this->edit($request);
        } else {
            Director::redirectBack();
        }*/

        if(Director::is_ajax()) {
            return new SS_HTTPResponse(
                Convert::array2json(array(
                    'html' => $this->EditForm()->forAjaxTemplate(),
                    'message' => 'Library updated',
                )),
                200
            );
        } else {
            Director::redirectBack();
        }
    }

    /**
     * @return Form
     */
    public function EditForm()
    {
        $form =  parent::EditForm();

        $form->Fields()->insertFirst(new LiteralField('',
            $this->renderWith('LibraryAdminHeader')
        ));

        return $form;
    }
}

class LibraryAdmin_CollectionController extends ModelAdmin_CollectionController
{
    /**
     * We do not want the column selection feature.
     *
     * @return LiteralField
     */
    public function ColumnSelectionField()
    {
       return new LiteralField('', '');
    }
}
