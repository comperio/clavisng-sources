<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
abstract class LibraryRepository
{
    /**
     * Get a library by its DNG ID
     *
     * @param $id
     * @return Library
     */
    abstract public function getByID($id);

    /**
     * @abstract
     *
     * @param string $source The identifier of the external source
     * @param int|string $id The id in the external source
     *
     * @return Library
     */
    abstract public function getByExternalId($source, $id);

    /**
     * @abstract
     * @param \LibraryDataObject $page
     * @return Library
     */
    abstract public function getByLibraryDataObject(LibraryDataObject $page);

    /**
     * @param null|string $keyColumn
     * @param null|string $valueColumn
     *
     * @return array The array of all library objects
     */
    abstract public function getAllLibraries($keyColumn = null, $valueColumn = null);

    /**
     * Returns the list of internal libraries
     *
     * @param null|string $keyColumn
     * @param null|string $valueColumn
     *
     * @return mixed
     */
    abstract public function getInternalLibraries($keyColumn = null, $valueColumn = null);

    /**
     * Returns the list of libraries an user can ask the return to
     *
     * @param null $keyColumn
     * @param null $valueColumn
     * @return mixed
     */
    abstract public function getReturnLibraries($keyColumn = null, $valueColumn = null);

    /**
     * Returns the list of internal libraries
     *
     * @param null|string $keyColumn
     * @param null|string $valueColumn
     *
     * @return mixed
     */
    abstract public function getRegistrationLibraries($keyColumn = null, $valueColumn = null);
    
    /**
     * Returns libraries that have a linked LibraryMainPage
     * @abstract
     * @param null $keyColumn
     * @param null $valueColumn
     * @return mixed
     */
    abstract public function getLibrariesWithPages($keyColumn = null, $valueColumn = null);

    /**
     * This method transforms a dataset of LibrariesDataObjects to an array of Libraries.
     * If $identifier is not null, returns a map identifier->value instead of an array of Libraries.
     *
     * @param DataObjectSet $set
     * @param null|string $keyColumn If set returns an hash with this field
     * @param null|string $valueColumn The value to use in the hash
     * @throws InvalidArgumentException
     * @return array the array of library objects
     */
    public function dataSetToLibraries(DataObjectSet $set, $keyColumn = null, $valueColumn = null)
    {
        $libraries = array();

        //transform non-DataObjectSet sets in empty datasets
        if (! ($set instanceof DataObjectSet)) {
            $set = new DataObjectSet();
        }

        foreach($set as $libraryObject) {
            if (!$libraryObject instanceof LibraryDataObject)
                continue;

            $library = $this->getByLibraryDataObject($libraryObject);

            if ($keyColumn) {
                $methodKeyName = 'get' . ucfirst($keyColumn);
                $methodValueName = 'get' . ucfirst($valueColumn);

                if (method_exists($library, $methodValueName) && method_exists($library, $methodKeyName) ) {
                    $libraries[$library->$methodKeyName()] = $library->$methodValueName();
                } else {
                    throw new InvalidArgumentException('Class ' . get_class($library) .
                            ' has not a method named ' . $methodKeyName  . ' or a method named ' . $methodValueName);
                }
            } else {
                $libraries[] = $this->getByLibraryDataObject($libraryObject);
            }
        }

        return $libraries;
    }
}
