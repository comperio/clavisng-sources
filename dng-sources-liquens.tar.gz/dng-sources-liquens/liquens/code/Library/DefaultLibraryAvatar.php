<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

/**
 * Default avatars for libraries
 */
class DefaultLibraryAvatar extends Image
{
    private $avatarsDir = 'liquens/images/defaultLibAvatars';
    private $totalAvatars = 12;

    public function __construct(Library $library = null)
    {
        parent::__construct();

        if (isset($library))
            $this->setFilename($this->getFileNameFromLibrary($library));
    }

    private function getFileNameFromLibrary(Library $library)
    {
        $avatarIndex = ($library->getID() % $this->totalAvatars) + 1;

        return $this->avatarsDir . '/avatar' . $avatarIndex . '.jpeg';
    }
}
