<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
abstract class Library
{
    /**
     * @abstract
     * @return mixed
     */
    abstract public function getID();

    /**
     * @abstract
     * @return mixed
     */
    abstract public function getExternalID();

    /**
     * @abstract
     * @return mixed
     */
    abstract public function getExternalSource();

    /**
     * @abstract
     * @return string
     */
    abstract public function getShortName();

    /**
     * @abstract
     * @return string
     */
    abstract public function getFullName();

    /**
     * @abstract
     * @return string
     */
    abstract public function getPhone();

    /**
     * @abstract
     * @return string
     */
    abstract public function getFax();

    /**
     * @abstract
     * @return string
     */
    abstract public function getAddress();

    /**
     * @abstract
     * @return mixed
     */
    abstract public function getProvince();

    /**
     * @abstract
     * @return mixed
     */
    abstract public function getCity();

    /**
     * @abstract
     * @return mixed
     */
    abstract public function getEmail();

    /**
     * @abstract
     * @return mixed
     */
    abstract public function getWebsite();

    /**
     * @abstract
     * @return ComponentSet
     */
    abstract public function getContacts();

    /**
     * @return DataObjectSet
     */
    abstract public function getAllContacts();

    /**
     * @abstract
     * @return float
     */
    abstract public function getLatitude();

    /**
     * @abstract
     * @return float
     */
    abstract public function getLongitude();

    /**
     * @return bool
     */
    abstract public function getInternal();

    /**
     * @return bool
     */
    abstract public function getAllowReturn();

    /**
     * @return bool
     */
    abstract public function getAllowRegistration();
    
    /**
     * @return null|Image
     */
    abstract public function getAvatar();

    /**
     * @abstract
     * @param $from
     * @param $to
     * @return mixed
     */
    abstract public function getTimeTable($from = null, $to = null);

    /**
     * @param int $time Unix Timestamp. Leave blank for taking current time
     *
     * @return bool
     */
    public function isOpenedAt($time = null)
    {
        if (!isset($time))
            $time = time();

        $timetable = $this->getTimeTable($time, strtotime('+1 day'));

        if (!isset($timetable[0]))
            return false;

        $times = $timetable[0];
        $intervals = array();

        $datetime = new DateTime();
        $datetime->setTimestamp($time);

        // Convert a time to the timestamp of today at that time
        $getTimestamp = function ($t) use ($datetime) {
            call_user_func_array(array($datetime, 'setTime'), explode(':', $t));
            return $datetime->getTimestamp();
        };

        //Create timestamped intervals
        for ($i = 1; $i <= 3; $i++) {
            if (isset($times["Time{$i}Start"]) && isset($times["Time{$i}End"])) {
                $intervals[] = array(
                    $getTimestamp($times["Time{$i}Start"]),
                    $getTimestamp($times["Time{$i}End"]),
                );
            }
        }

        //Finally iterate through intervals and check if $now is in some interval
        foreach ($intervals as $interval) {
            if ($interval[0] <= $time && $time <= $interval[1])
                return true;
        }

        return false;
    }

    /**
     * @return mixed
     */
    abstract public function getCatalogLinkMode();

    /**
     * The link to show when the library is showed in catalog pages
     *
     * @return bool|mixed|string
     */
    public function getCatalogLink()
    {
        $link = false;

        switch ($this->getCatalogLinkMode()) {
            case 'Page':
                $link = 'libpage/id/' . $this->getID();
                break;
            case "Website":
                $link = $website = $this->getWebsite();
                if (strpos($website, 'http://') !== 0 && strpos($website, 'https://') !== 0) {
                    $link = 'http://' . $link;
                }
                break;
        }

        return $link;
    }

    /**
     * Returns a template-viewable version of the Library Timetable
     *
     * @param null $from
     * @param null $to
     *
     * @return DataObjectSet
     */
    public function getViewableTimeTable($from = null, $to = null)
    {
        $times = new DataObjectSet;

        $timetable = $this->getTimeTable($from, $to);

        if (count($timetable)) {
            foreach ($timetable as $k => $table) {
                $timesData = array();
                if (array_key_exists('TimetableDay', $table)) {
                    $timesData['Day'] = CalendarUtil::zend_i18n_date("%a", $table['TimetableDay']);
                    $timesData['DayNum'] = date('d', $table['TimetableDay']);
                    $timesData['WeekDay'] = date('N', $table['TimetableDay']);
                    $timesData['MonthName'] = CalendarUtil::zend_i18n_date("%B", $table['TimetableDay']);
                    if (date('d-m', $table['TimetableDay']) == date('d-m', time())) {
                        $timesData['isToday'] = '1';
                    }
                }
                if (isset($table['TimetableNote']))
                    $timesData['TimetableNote'] = $table['TimetableNote'];

                $timesData['Times'] = new DataObjectSet();

                for ($i = 1; $i <= 3; $i++) {
                    $keyStart = "Time{$i}Start";
                    $keyEnd = "Time{$i}End";

                    if (isset($table[$keyStart]) && isset($table[$keyEnd])) {
                        $interval = new DataObject(array(
                            'Start' => substr($table[$keyStart], 0, -3),
                            'End' => substr($table[$keyEnd], 0, -3),
                        ));

                        $timesData['Times']->push($interval);
                    }
                }

                $times->push(new DataObject($timesData));
            }
        }

        return $times;
    }

    /**
     * @return array
     */
    public function toArray()
    {
        return array(
            'shortName' => $this->getShortName(),
            'fullName' => $this->getFullName(),
            'province' => $this->getProvince(),
            'city' => $this->getCity(),
            'website' => $this->getWebsite(),
            'email' => $this->getEmail(),
            'address' => $this->getAddress(),
            'phone' => $this->getPhone(),
            'fax' => $this->getFax(),
            'timetable' => $this->getTimeTable(time(), strtotime("+5 day")),
            'latitude' => $this->getLatitude(),
            'longitude' => $this->getLongitude(),
            'catalogLink' => $this->getCatalogLink(),
            'internal' => $this->getInternal(),
        );
    }
}
