<?php

/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class LibraryDataObject extends DataObject {

    static $db = array(
        'ShortName' => 'VarChar(255)',
        'FullName' => 'VarChar(255)',
        'ExternalSource' => 'VarChar',
        'ExternalID' => 'VarChar',
        'Address' => 'VarChar(255)',
        'City' => 'VarChar(255)',
        'Province' => 'VarChar',
        'ExternalWebsite' => 'VarChar(255)',
        'Phone' => 'VarChar',
        'Email' => 'VarChar(1024)',
        'Latitude' => 'DngDecimal(10,7)',
        'Longitude' => 'DngDecimal(10,7)',
        'CatalogLinkMode' => "Enum('None, Page, Website')",
        'Internal' => 'Boolean',
        'AllowReturn' => 'Boolean',
        'AllowRegistration' => 'Boolean'
    );
    static $indexes = array(
        'RatedObject' => '(ExternalSource, ExternalID)',
    );
    static $searchable_fields = array(
        'FullName',
        'Internal'
    );
    static $summary_fields = array(
        'FullName',
        'ExternalID',
        'Email'
    );
    static $defaults = array(
        'CatalogLinkMode' => "Page",
        'AllowReturn' => true,
        'AllowRegistration' => true
    );
    static $default_sort = 'ShortName';
    static $has_one = array(
        'Avatar' => 'Image',
    );
    static $has_many = array(
        'LibraryMainPages' => 'LibraryMainPage.LibraryObject'
    );
    static $many_many = array(
        'Contacts' => 'Contact',
    );
    private $tabsMap = array(
        'Root.Contatti' => array('Phone', 'Email', 'ExternalWebsite', 'Latitude', 'Longitude',
            'Contacts_Twitter', 'Contacts_Facebook', 'Contacts_Anobii', 'Contacts_Youtube',
            'Contacts_GooglePlus', 'Contacts_Foursquare', 'Contacts_Instagram', 'Contacts_Pinterest'),
        'Root.Catalogo' => array('CatalogLinkMode', 'Internal', 'AllowReturn',),
        'Root.Registrazione' => array('AllowRegistration'),
        'Root.Avanzate' => array('ExternalSource', 'ExternalID'),
    );
    private $availableSocialContacts = array(
        'Facebook', 'Twitter', 'Anobii', 'Youtube', 'GooglePlus', 'Foursquare', 'Instagram', 'Pinterest'
    );

    /**
     * @return FieldSet
     */
    public function getCMSActions() {
        $actions = parent::getCMSActions();

        if ($this->canEdit(Member::currentUser()))
            $actions->push(new FormAction("fetchFromExternalSource", _t("LibraryDataObject.FetchFromSource", "Update data from external source")));

        return $actions;
    }

    /**
     * Remove LibraryMainPages from default form fields
     *
     * @param null $_params
     * @return FieldSet
     */
    public function scaffoldFormFields($_params = null) {
        $fields = parent::scaffoldFormFields($_params);

        $fields->fieldByName('Root')->removeByName('LibraryMainPages');


        $linkMode = new OptionsetField('CatalogLinkMode', _t('LibraryDataObject.db_CatalogLinkMode'), array(
            'Page' => 'Link ad una pagina biblioteca esistente in DNG',
            'Website' => 'Link al sito esterno della biblioteca',
            'None' => 'Nessun link, solo il titolo della biblioteca',
        ));

        foreach ($this->availableSocialContacts as $serviceName) {
            $contact = $this->getContact($serviceName);
            $value = $contact ? $contact->ServiceURL : '';
            $fields->addFieldToTab('Root.Main', new TextField('Contacts_' . $serviceName, $serviceName, $value));
        }

        $fields->removeByName('Contacts');
        $fields->replaceField('CatalogLinkMode', $linkMode);

        $this->rearrangeFieldsIntoTabs($this->tabsMap, $fields);

        return $fields;
    }

    /**
     * Set the default search value for Internal in the default search fields
     *
     * @param null $_params
     * @return FieldSet
     */
    public function scaffoldSearchFields($_params = null) {
        $fields = parent::scaffoldSearchFields($_params);

        $fields->fieldByName('Internal')->setValue(true);

        return $fields;
    }

    /**
     * Load social networks contacts
     */
    protected function onAfterWrite() {
        $contacts = $this->Contacts();

        foreach ($this->record as $name => $value) {
            if (0 !== strpos($name, 'Contacts_'))
                continue;

            $serviceName = substr($name, strlen('Contacts_'));

            $found = false;
            foreach ($contacts as $currContact) {
                if ($currContact->ServiceName == $serviceName) {
                    $found = true;
                    if ($value) {
                        $currContact->ServiceURL = $value;
                        $currContact->write();
                    } else {
                        $currContact->delete();
                    }
                    break;
                }
            }

            if (!$found && $value) {
                $contact = new Contact();
                $contact->ServiceName = $serviceName;
                $contact->ServiceURL = $value;
                $contact->write();
                $contacts->add($contact);
            }
        }
        parent::onAfterWrite();
    }

    /**
     * Gets the contact for a given servicename
     *
     * @param string $serviceName (Like Facebook, Anobii, etc.)
     * @return bool
     */
    public function getContact($serviceName) {
        return $this->Contacts()->find('ServiceName', $serviceName) ?: false;
    }

    /**
     * Verifica che amministratori o sitemaster possano creare nuove biblioteche
     * 
     * @param type $member
     * @return type
     */
    public function canCreate($member = null) {
        if (!$member)
            $member = Member::currentUser();
        return $member->isAdmin() || $member->isSitemaster();
    }

    /**
     * Allow editing only if the user is linked to the library
     *
     * @param null $member
     * @return bool
     */
    public function canEdit($member = null) {
        if (!$member)
            return false;

        if (Permission::checkMember($member, 'EDIT_ALL_LIBRARIES'))
            return true;

        if (!Permission::checkMember($member, 'SITETREE_EDIT_MY_LIBRARIES'))
            return false;

        $libs = array_map(function($clavisID) {
            return array('ExternalSource' => 'CLAVIS', 'ExternalID' => $clavisID);
        }, $member->getLinkedLibraries()
        );

        foreach ($libs as $lib) {
            if ($this->ExternalSource == $lib['ExternalSource'] && $this->ExternalID == $lib['ExternalID']) {
                return true;
            }
        }

        return parent::canEdit($member);
    }

    private function rearrangeFieldsIntoTabs(array $tabsMap, FieldSet $fieldSet) {
        foreach ($tabsMap as $tabIdentifier => $fields) {
            foreach ($fields as $fieldName) {
                $fieldNestedIdentifier = 'Root.Main.' . $fieldName;
                $field = $fieldSet->fieldByName($fieldNestedIdentifier);
                if ($field) {
                    $fieldSet->removeByName($fieldNestedIdentifier);
                    $fieldSet->findOrMakeTab($tabIdentifier)->push($field);
                }
            }
        }
    }

}
