<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class DngLibraryRepository extends LibraryRepository
{
    /**
     * @var LiquensConnector
     */
    private $connector;

    /**
     * @param LiquensConnector $connector
     */
    public function __construct(LiquensConnector $connector)
    {
        $this->connector = $connector;
    }

    /**
     * Get a library by its DNG ID
     *
     * @param $id
     * @return Library
     */
    public function getByID($id)
    {
        return $this->getByLibraryDataObject(DataObject::get_by_id('LibraryDataObject', $id));
    }


    /**
     * @param string $source
     * @param $id The id in the external source
     *
     * @return Library
     */
    public function getByExternalId($source, $id)
    {
	$lib = $this->getLibraryDOByExternalId($source, $id);
	if($lib)
	        return $this->getByLibraryDataObject($lib);
	else
		return null;
    }

    /**
     * @param LibraryDataObject $library
     * @return Library
     */
    public function getByLibraryDataObject(LibraryDataObject $library)
    {
        if (! $library instanceof LibraryDataObject) {
            return false;
        }

        $service = new ClavisLibraryService($this->connector);
        $service->setExternalId($library->ExternalID);

        $serviceDo = new DataObjectService($library);
        $serviceDo->setPropMap(array(
         'ID' => 'ID',
         'externalID' => 'ExternalID',
         'externalSource' => 'ExternalSource',
         'fullName' => 'FullName',
         'shortName' => 'ShortName',
         'address' => 'Address',
         'city' => 'City',
         'province' => 'Province',
         'phone' => 'Phone',
         'fax' => 'Fax',
         'email' => 'Email',
         'website' => 'ExternalWebsite',
         'latitude' => 'Latitude',
         'longitude' => 'Longitude',
         'catalogLinkMode' => 'CatalogLinkMode',
         'internal' => 'Internal',
         'allowReturn' => 'AllowReturn',
         'avatar' => 'Avatar',
         'contacts' => 'Contacts'
        ));

        $composite = new CompositeDataService();
        $composite
            ->addService($serviceDo, 10)
            ->addService($service, 1)
        ;

        return new DngLibrary($composite);
    }

    /**
     * @param null|string $keyColumn
     * @param null|string $valueColumn
     *
     * @return array The array of all library objects
     */
    public function getAllLibraries($keyColumn = null, $valueColumn = null)
    {
	$libobj = DataObject::get('LibraryDataObject');
	if($libobj)
	        return $this->dataSetToLibraries($libobj, $keyColumn, $valueColumn);
	else
		return null;
    }

    /**
     * Returns libraries that have a linked LibraryMainPage
     * @param null $keyColumn
     * @param null $valueColumn
     * @return mixed
     */
    public function getLibrariesWithPages($keyColumn = null, $valueColumn = null)
    {
        $librariesSet = DataObject::get("LibraryDataObject",
                  "",
                  "",
                  "LEFT JOIN `LibraryMainPage` ON `LibraryMainPage`.LibraryObjectID = `LibraryDataObject`.ID");

        return $this->dataSetToLibraries($librariesSet, $keyColumn, $valueColumn);
    }

    /**
     * Returns the list of internal libraries
     *
     * @param null|string $keyColumn
     * @param null|string $valueColumn
     *
     * @return mixed
     */
    public function getInternalLibraries($keyColumn = null, $valueColumn = null)
    {
        $librariesSet = DataObject::get("LibraryDataObject", "Internal = 1");

        return $this->dataSetToLibraries($librariesSet, $keyColumn, $valueColumn);
    }

    /**
     * Returns the list of libraries an user can ask the return to
     *
     * @param null $keyColumn
     * @param null $valueColumn
     * @return mixed
     */
    public function getReturnLibraries($keyColumn = null, $valueColumn = null)
    {
        $librariesSet = DataObject::get("LibraryDataObject", "AllowReturn = 1 AND Internal = 1");

        if ($librariesSet)
        return $this->dataSetToLibraries($librariesSet, $keyColumn, $valueColumn);
        else return null;
    }

    public function getRegistrationLibraries($keyColumn = null, $valueColumn = null)
    {
        $librariesSet = DataObject::get("LibraryDataObject", "AllowRegistration = 1 AND Internal = 1");

        if ($librariesSet)
        return $this->dataSetToLibraries($librariesSet, $keyColumn, $valueColumn);
        else return null;
    }
    
    /**
     * @param $source the identifier of the external source
     * @param int|string $id The id of the library in the external source
     * @return LibraryDataObject
     */
    private function getLibraryDOByExternalId($source, $id)
    {
        $lib = DataObject::get_one(
            'LibraryDataObject',
            sprintf(
                "ExternalSource = '%s' AND ExternalID = '%s'",
                Convert::raw2sql($source),
                Convert::raw2sql($id)
            )
        );

        return $lib;
    }

}
