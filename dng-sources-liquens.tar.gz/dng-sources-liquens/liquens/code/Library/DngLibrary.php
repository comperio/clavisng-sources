<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class DngLibrary extends Library
{
    /**
     * @var DataService
     */
    private $dataService;

    /**
     * @param DataService $dataService
     */
    public function __construct(DataService $dataService)
    {
        $this->setDataService($dataService);
    }

    /**
     * @return mixed
     */
    public function getID()
    {
        return $this->getDataService()->getProp('ID');
    }


    /**
     * @return mixed
     */
    public function getExternalID()
    {
        return $this->getDataService()->getProp('externalID');
    }

    /**
     * @return mixed
     */
    public function getExternalSource()
    {
        return $this->getDataService()->getProp('externalSource');
    }


    /**
     * @return mixed
     */
    public function getProvince()
    {
        return $this->getDataService()->getProp('province');
    }

    /**
     * @return mixed
     */
    public function getCity()
    {
        return $this->getDataService()->getProp('city');
    }

    /**
     * @return mixed
     */
    public function getEmail()
    {
        return $this->getDataService()->getProp('email');
    }

    /**
     * @return mixed
     */
    public function getWebsite()
    {
        return $this->getDataService()->getProp('website');
    }

    /**
     * @return ComponentSet
     */
    public function getContacts()
    {
        return $this->getDataService()->getProp('contacts');
    }

    /**
     * Returns a set of all contacts, social ones plus the website
     *
     * @return DataObjectSet|void
     */
    public function getAllContacts()
    {
        $website = $this->getWebsite();
        $email = $this->getEmail();
        $contacts = new DataObjectSet();
        if ($website) {
            $contact = new Contact();
            $contact->ServiceName = 'Website';
            $contact->ServiceURL = $website;
            $contacts->push($contact);
        }
        if ($email) {
            $contact = new Contact();
            $contact->ServiceName = 'Email';
            $contact->ServiceURL = 'mailto:' . $email;
            $contacts->push($contact);
        }

        $contacts->merge($this->getContacts());

        return $contacts;
    }

    public function getAllClearContacts()
    {
        $website = $this->getWebsite();
        $email = $this->getEmail();
        $contacts = new DataObjectSet();
        if ($website) {
            $contact = new Contact();
            $contact->ServiceName = 'website';
            $contact->ServiceURL = $website;
            $contacts->push($contact);
        }
        if ($email) {
            $contact = new Contact();
            $contact->ServiceName = 'email';
            $contact->ServiceURL = $email;
            $contacts->push($contact);
        }

        $contacts->merge($this->getContacts());

        return $contacts;
    }
    
    /**
     * @return string
     */
    public function getShortName()
    {
        return $this->getDataService()->getProp('shortName');
    }

    /**
     * @return string
     */
    public function getFullName()
    {
        return $this->getDataService()->getProp('fullName');
    }

    /**
     * @return string
     */
    public function getPhone()
    {
        return $this->getDataService()->getProp('phone');
    }

    /**
     * @return string
     */
    public function getFax()
    {
        return $this->getDataService()->getProp('fax');
    }

    /**
     * @return string
     */
    public function getAddress()
    {
        return $this->getDataService()->getProp('address');
    }

    /**
     * @return float
     */
    public function getLatitude()
    {
        return $this->getDataService()->getProp('latitude');
    }

    /**
     * @return float
     */
    public function getLongitude()
    {
        return $this->getDataService()->getProp('longitude');
    }

    /**
     * @return bool
     */
    public function getInternal()
    {
        return $this->getDataService()->getProp('internal');
    }

    /**
     * @return bool
     */
    public function getAllowReturn()
    {
        return $this->getDataService()->getProp('allowReturn');
    }
    
    /**
     * @return bool
     */
    public function getAllowRegistration()
    {
        return $this->getDataService()->getProp('AllowRegistration');
    }

    /**
     * @return null|Image
     */
    public function getAvatar()
    {
        $avatar = $this->getDataService()->getProp('Avatar');

        if (!$avatar->ID)
            $avatar = new DefaultLibraryAvatar($this);

        return $avatar;
    }

    /**
     * @param $from
     * @param $to
     *
     * @return mixed
     */
    public function getTimeTable($from = null, $to = null)
    {
        return $this->getDataService()->getProp('timetable', array($from, $to));
    }

    /**
     * @return mixed
     */
    public function getCatalogLinkMode()
    {
        return $this->getDataService()->getProp('catalogLinkMode');
    }


    /**
     * Set DataService
     *
     * @param \DataService $dataService
     *
     * @return DngLibrary The current instance
     */
    public function setDataService($dataService)
    {
        $this->dataService = $dataService;

        return $this;
    }

    /**
     * Get DataService
     *
     * @return \DataService
     */
    public function getDataService()
    {
        return $this->dataService;
    }

}
