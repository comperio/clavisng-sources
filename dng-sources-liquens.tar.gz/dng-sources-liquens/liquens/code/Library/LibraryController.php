<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class LibraryController extends Page_Controller
{
    /**
     * @var LibraryRepository
     */
    private $libraryRepository;

    public static $url_handlers = array(
        '$LibraryID!/info' => 'info',
    );

    public static $allowed_actions = array(
        'info'
    );

    /**
     * Returns basic informations on the library.
     *
     * @param SS_HTTPRequest $request
     * @return string
     */
    public function info(SS_HTTPRequest $request)
    {
        $lib = $this->getLibraryRepository()->getByID($request->param('LibraryID'));
        $viewableLib = new ViewableObject($lib);

        return $viewableLib->renderWith('LibraryMapInfo');
    }

    /**
     * Set LibraryRepository
     *
     * @param \LibraryRepository $libraryRepository
     *
     * @return LibraryController The current instance
     */
    public function setLibraryRepository(\LibraryRepository $libraryRepository)
    {
        $this->libraryRepository = $libraryRepository;

        return $this;
    }

    /**
     * Get LibraryRepository
     *
     * @return \LibraryRepository
     */
    public function getLibraryRepository()
    {
        return $this->libraryRepository;
    }


}
