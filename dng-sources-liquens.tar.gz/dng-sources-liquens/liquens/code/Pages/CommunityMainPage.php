<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 */

class CommunityMainPage extends Page
{
    public static $has_one = array(
        'SidebarWidgetArea' => 'WidgetArea'
    );
    
    static $allowed_children = array(
        'ProfilePage'
    );

    function getCMSFields($params = NULL)
    {
        $fields = parent::getCMSFields();
        $fields->addFieldToTab("Root.Content.SidebarWidget", new WidgetAreaEditor('SidebarWidgetArea'));
        return $fields;
    }
}

/**
 * Class CommunityMainPage_Controller
 */
class CommunityMainPage_Controller extends Page_Controller
{
    public static $allowed_actions = array();

    /**
     * @return DataobjectSet
     */
    public function LastRegisteredUsers($n = 10)
    {
        return DataObject::get('Member', '', 'Created DESC', '', $n);
    }

    /**
     * @return DataobjectSet
     */
    public function OnlineUsers($n = 10)
    {
        return DataObject::get(
            'Member', "\"LastVisited\" > NOW() - INTERVAL 15 MINUTE", 'LastVisited DESC', '', $n
        );
    }

    /**
     * Return ForumLastPosts rendered
     * @return string
     */
    public function ForumLastPosts()
    {
        $widget = new ForumLastPosts();
        $widget->Title = _t('Community.POSTS_TITLE', 'Forum last posts');
        $widget->NoPostMessage = _t('Community.POSTS_NOPOSTS', 'There are no posts yet');
        $widget->ShowPostTitles = true;
        $widget->AvatarSize = 'medium';

        return $widget->renderWith("DngWidgetHolder");
    }
}
