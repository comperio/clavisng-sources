<?php

class RegistrationTwilioPage extends Page {

    static $db = array(
        'ConfirmationContentTwilio' => 'HTMLText',
        'ConfirmationContentTwilioForeign' => 'HTMLText',
        'ModalContent' => 'HTMLText',
        'ModalCountdown' => 'DBInt',
        'DefaultLibrary' => 'DBInt',
        'ErrorCountdown' => 'HTMLText',
        'ErrorCF' => 'HTMLText',
        'ErrorTextCF' => 'HTMLText',
        'ErrorCFContent' => 'HTMLText',
        'ErrorNumber' => 'HTMLText',
        'ErrorEmail' => 'HTMLText',
        'ErrorGeneric' => 'HTMLText',
        'ErrorUsername' => 'HTMLText',
        'ErrorTextUsername' => 'HTMLText',
        'ErrorLibrary' => 'HTMLText',
        'ErrorLibrarianUsername' => 'HTMLText',
        'ErrorGenericUsername' => 'HTMLText',
        'ConfirmationTextEmail' => 'HTMLText',
        'ConfirmationLibraryEmail' => 'VarChar(255)',
        "RegistrationLibraries" => "Varchar(1)",
        'PrivacyTextBox' => 'VarChar(255)'
    );
    
    static $has_one = array();
    
    public $rules = array(
        'lastname' => 'required',
        'name' => 'required',
        'national_id' => array(
            'minlength' => 16,
            'maxlength' => 16,
            'required' => true
        ),
        'contact_email' => array(
            'email' => true,
//            'required' => true
        ),
        'contact_value' => array(
            'minlength' => 9,
            'required' => true,
//            'digits' => true
        ),
        'password' => array(
            'minlength' => 6,
            'maxlength' => 16,
            'required' => true
        ),
        'confirm_password' => array(
            'equalToByName' => 'password',
            'required' => true
        ),
//        'preferred_library_id' => 'required',
        'privacy_approve' => 'required'
    );

    public function getCMSFields($params = NULL) {
        $fields = parent::getCMSFields();
        $fields->addFieldToTab('Root.Content.Configurazione', new NumericField('ModalCountdown', _t('Registration.CONFIRMTWILIOCOUNTDOWN', 'Value of the countdown (in seconds)')));
        $fields->addFieldToTab('Root.Content.Configurazione', new NumericField('DefaultLibrary', _t('Registration.CONFIRMTWILIODEFAULTLIBRARY', 'Default registration library ID from Clavis')));
        $fields->addFieldToTab('Root.Content.Configurazione', new TextField("ConfirmationLibraryEmail", "Email mittente da usare nella conferma della registrazione"));
        $fields->addFieldToTab("Root.Content.Configurazione", new CheckboxField("RegistrationLibraries", "Selezionare per usare la lista delle biblioteche che permettono la registrazione. Altrimenti verranno visualizzate tutte le biblioteche interne."));
        
        $fields->addFieldToTab('Root.Content.PrivacyUtenti', new TextField("PrivacyTextBox", "Testo per approvazione privacy (è permesso inserire HTML)"));

        $fields->addFieldToTab('Root.Content.Modali', new HtmlEditorField("ModalContent", _t('Registration.CONFIRMTWILIOLABEL', "Content to be displayed on the verification modal of the telephone number")));
        $fields->addFieldToTab('Root.Content.Modali', new HtmlEditorField("ErrorGeneric", _t('Registration.ERRORTWILIOGENERIC', "Content to be displayed on the modal in case of generic error")));
        $fields->addFieldToTab('Root.Content.Modali', new HtmlEditorField("ErrorCountdown", _t('Registration.ERRORTWILIOCOUNTDOWN', "Content to be displayed on the modal in case of expiry of the count down")));
        $fields->addFieldToTab('Root.Content.Modali', new HtmlEditorField("ErrorUsername", _t('Registration.ERRORTWILIOUSERNAME', "Content to be displayed on the modal in case of duplicate Username")));
        $fields->addFieldToTab('Root.Content.Modali', new HtmlEditorField("ErrorCF", _t('Registration.ERRORTWILIOCF', "Content to be displayed on the modal in case of duplicate National ID")));
        $fields->addFieldToTab('Root.Content.Modali', new HtmlEditorField("ErrorCFContent", _t('Registration.ERRORTWILIOCFCONTENT', "Content to be displayed on the modal in case of name and surname in National ID mismatched")));
        $fields->addFieldToTab('Root.Content.Modali', new HtmlEditorField("ErrorNumber", _t('Registration.ERROTTWILIOCELPHONE', "Content to be displayed on the modal in case of duplicate celphone number")));
        $fields->addFieldToTab('Root.Content.Modali', new HtmlEditorField("ErrorEmail", _t('Registration.ERRORTWILIOEMAIL', "Content to be displayed on the modal in case of duplicate email")));

        $fields->addFieldToTab('Root.Content.Errori', new HtmlEditorField("ErrorTextUsername", _t('Registration.ERRORTWILIOTEXTUSERNAME', "Content to be displayed on the error in case of duplicate Username")));
        $fields->addFieldToTab('Root.Content.Errori', new HtmlEditorField("ErrorTextCF", _t('Registration.ERRORTWILIOTEXTCF', "Content to be displayed on the error in case of duplicate National ID")));
        $fields->addFieldToTab('Root.Content.Errori', new HtmlEditorField("ErrorLibrary", "Contenuto da mostrare nell'errore in caso di problemi con la biblioteca di registrazione"));
        $fields->addFieldToTab('Root.Content.Errori', new HtmlEditorField("ErrorLibrarianUsername", "Contenuto da mostrare nell'errore in caso di username duplicato di un operatore Clavis"));
        $fields->addFieldToTab('Root.Content.Errori', new HtmlEditorField("ErrorGenericUsername", "Contenuto da mostrare nell'errore in caso di problemi di salvataggio dei dati utente"));

        $fields->addFieldToTab('Root.Content.Conferma', new HtmlEditorField("ConfirmationContentTwilio", _t('Registration.CONFIRMLABEL', "Content to be displayed after the pre registration. Place card: #NOME, #COGNOME, #NUMERO, #CF"),6));
        $fields->addFieldToTab('Root.Content.Conferma', new HtmlEditorField("ConfirmationContentTwilioForeign", _t('Registration.CONFIRMLABELFOREIGNER', "Content to be displayed after the pre registration of a foreign user registration. Place card: #NOME, #COGNOME, #NUMERO, #CF"),6));
        $fields->addFieldToTab('Root.Content.Conferma', new HtmlEditorField("ConfirmationTextEmail", "Template dell'email di conferma. Segnaposto: #NOME, #COGNOME, #NUMERO, #CF",6));
        return $fields;
    }

    public function getValidationMessages() {
        return array(
            'confirm_password' => _t('Validation.PASSWORDEQUALS', 'Password must match')
        );
    }

    public function addCssClasses(Form $form) {
        foreach ($form->Fields() as $field) {
            if ($form->getValidator()->isRuleAppliedToField('required', $field->Name())) {
                $requiredSuffix = ' <sup title="' . _t('Registration.MANDATORYFIELD', 'Mandatory Field') . '">*</sup>';
                $field->addExtraClass('lqvalidation_required');
                $field->setTitle($field->Title() . $requiredSuffix);
            }
        }
        return $this;
    }
    
    public function onBeforeWrite() {
        parent::onBeforeWrite();
        
        if (($this->owner->PrivacyTextBox == "") || is_null($this->owner->PrivacyTextBox))
            $this->owner->PrivacyTextBox = "Dichiaro di aver letto ed accettato le condizioni sulla Privacy";
       
    }

}

class RegistrationTwilioPage_Controller extends Page_Controller {

    public static $allowed_actions = array(
        'RegistrationFormTwilio',
        'register',
        'twiliotoapc',
        'twiliostatus',
        'twiliochecking',
        'twiliodelete'
    );
    private $libraryRepository;
    private $username = '';
    private $nationald_id = '';
    private $foreigner = "false";
    private $_consonanti = array('B', 'C', 'D', 'F', 'G', 'H', 'J', 'K', 'L', 'M', 'N', 'P', 'Q', 'R', 'S', 'T', 'V', 'W', 'X', 'Y', 'Z');
    private $_vocali = array('A', 'E', 'I', 'O', 'U');

    public function RegistrationFormTwilio() {
        SecurityToken::disable();

        if ((int) $this->RegistrationLibraries != 0)
            $librariesList = $this->getLibraryRepository()->getRegistrationLibraries('ExternalID', 'shortName');
        else
            $librariesList = $this->getLibraryRepository()->getInternalLibraries('ExternalID', 'shortName');
        
        $fields = new FieldSet(
                new TextField("name", _t('Registration.NAME', 'Name')),
                new TextField("lastname", _t('Registration.LASTNAME', 'Lastname')),
                new CheckboxField("foreigner", _t('Registration.FOREIGNER', 'I am a foreigner'), false),
                new TextField('national_id', _t('Registration.NATIONALID', 'National ID')),
                new EmailField("contact_email", "Email"),
                new TextField('contact_value', _t('Liquens.CELL_NUMBER')),
                new PasswordField("password", _t('Registration.PASSWORD', 'Password')),
                new PasswordField("confirm_password", _t('Registration.CONFIRMPASSWORD', 'Confirm Password')),
                new DropdownField("preferred_library_id", _t('Registration.PREFERRED_LIBRARY_NOT_MANDATORY', "Favourite library (not mandatory)"), $librariesList, '', null, '---'),
                new CheckboxField("privacy_approve", $this->PrivacyTextBox, false)
        );

        $actions = new FieldSet(new FormAction("register", _t('Registration.REGISTER', 'Register')));

        $validator = new ComplexValidator($this->rules, $this->getValidationMessages());
        $form = new CustomizedForm($this, "RegistrationFormTwilio", $fields, $actions, $validator);

        $this->addCssClasses($form);

        $oldData = $this->getOldFormData($form);
        if ($oldData)
            $form->loadDataFrom($oldData);

        return $form;
    }

    /**
     * Verifica che il numero sia stato notificato dal server Twilio
     * 
     * @param SS_HTTPRequest $request
     * @return type
     */
    public function twiliostatus(SS_HTTPRequest $request) {
        global $sc;
        $key = $sc->getParameter('lq.solrDatabase') . "_T" . $request->getVar('number');
        if (apc_exists($key) && apc_fetch($key) == "SUCCESS") {
            apc_delete($key);
            return json_encode(true);
        }
        return json_encode(false);
    }

    /**
     * Salva il numero di telefono in APC
     * 
     * @global type $sc
     * @param SS_HTTPRequest $request
     * @return type
     */
    public function twiliotoapc(SS_HTTPRequest $request) {
        global $sc;
        $connector = $sc->get('liquens.connector');

        $key = $request->getVar('number');
        /* Elimina ciò che non è un numero e il carattere "+" */
        $key = preg_replace("/[^0-9\+]/", "", $key);
        /* Se la stringa che rimane è vuota o solamente il + allora esco */
        if ($key == "" || $key == "+") {
            Debug::log('Risposta contact_value errato: "' . $key . '"');
            return json_encode(1);
        }
        /* Verifica che il primo carattere sia "+" */
        if ((!preg_match('/^' . preg_quote('+', '/') . '/', $key)) || (strlen($key) < 12)) {
            Debug::log('Risposta contact_value non conforme: "' . $key . '"');
            return json_encode(1);
        }

        /* Verifico se l'utente è italiano e verifico il CF */
        $this->foreigner = (string) $request->getVar('foreigner');
        if ($this->foreigner == "false") {
            $check = $connector->getUserContacts($request->getVar('cf'), 'national_id');
            if ($check) {
                Debug::log('Risposta CF: ' . $check);
                return json_encode(3);
            }
            if (!$this->verificaCF($request->getVar('cf'), $request->getVar('nome'), $request->getVar('cognome'))) {
                Debug::log('Verifica CF nome o cognome errati: true');
                return json_encode(4);
            }
            /* Verifico esistenza numero di telefono */
            $check = $connector->getUserContacts($key, 'contact_value');
            if ($check) {
                Debug::log('Risposta contact_value: ' . $check);
                return json_encode(1);
            }
        } else { /* straniero */
            $check = $connector->getUserContacts($key, 'contact_value');
            if ($check) {
                Debug::log('Risposta contact_value: ' . $check);
                return json_encode(1);
            }
            $check = $connector->getUserContacts($key, 'username');
            if ($check) {
                Debug::log('Risposta username(contact_value): ' . $check);
                return json_encode(5);
            }
            $check = $connector->getUserContacts($key, 'national_id');
            if ($check) {
                Debug::log('Risposta CF(contact_value): ' . $check);
                return json_encode(1);
            }
        }

        /* Non essendo obbligatoria l'email, verifico se esiste solo se è settata */
        if (null !== $request->getVar('email')) {
            $check = $connector->getUserContacts($request->getVar('email'), 'email');
            if ($check) {
                Debug::log('Risposta email: ' . $check);
                return json_encode(2);
            }
        }

        $key = $sc->getParameter('lq.solrDatabase') . "_T" . $key;

        if (apc_exists($key)) {
            apc_delete($key);
        }
        apc_store($key, "WAITING", $this->ModalCountdown);
        return json_encode(0);
    }

    /**
     * Riceve la notifica da parte del server Twilio
     * Chiude la telefonata con segnale "occupato"
     * 
     * @param type $request
     */
    public function twiliochecking($request) {
        global $sc;
        Debug::log('Numero da Twilio: ' . $request->postVars('From')['From']);
        
        // Modifica per accettare solo numeri italiani
        if(substr($request->postVars('From')['From'],0,3) != "+39") die;
        
        $key = $sc->getParameter('lq.solrDatabase') . "_T" . $request->postVars('From')['From'];
        if (apc_exists($key)) {
            apc_store($key, "SUCCESS");
        }
        $response = '<?xml version="1.0" encoding="UTF-8"?><Response><Reject reason="busy" /></Response>';
        echo $response;
        die;
    }

    public function twiliodelete(SS_HTTPRequest $request) {
        global $sc;
        $key = $request->getVar('number');
        $key = preg_replace("/[^0-9\+]/", "", $key);
        if (!preg_match('/^' . preg_quote('+', '/') . '/', $key)) {
            $key = "+39" . $key;
        }
        $key = $sc->getParameter('lq.solrDatabase') . "_T" . $key;
        if (apc_exists($key)) {
            apc_delete($key);
        }
        return json_encode(true);
    }

    private function verificaCF($cf, $n, $c) {
        /* Elimina ciò che non dovrebbe far parte del CF */
        $cf = preg_replace("/[^0-9A-Za-z]*/", "", $cf);
        if (strlen($cf) < 16) {
            Debug::log('Verifica CF lunghezza errata: ' . $cf);
            return false;
        }
        $cfa = substr($cf, 0, 6) . substr($cf, 8, 1) . substr($cf, 11, 1) . substr($cf, 15, 1);
        $cfn = substr($cf, 6, 2) . substr($cf, 9, 2) . substr($cf, 12, 3);
        if (!ctype_alpha($cfa) || !ctype_digit($cfn)) {
            Debug::log('Verifica CF struttura errata: ' . $cfa . " " . $cfn . " " . $cf);
            return false;
        }
        $check = $this->calcolaCognome($c);
        if (strtoupper(substr($cf, 0, 3)) != $check) {
            Debug::log('Verifica CF cognome errato: ' . substr($cf, 0, 3) . "<>" . $check);
            return false;
        }
        $check = $this->calcolaNome($n);
        if (strtoupper(substr($cf, 3, 3)) != $check) {
            Debug::log('Verifica CF nome errato: ' . substr($cf, 3, 3) . "<>" . $check);
            return false;
        }
        return true;
    }

    private function _sanitize($string, $toupper = true) {
        $result = preg_replace('/[^A-Za-z]*/', '', $string);
        return ($toupper) ? strtoupper($result) : $result;
    }

    private function _addMissingX($string) {
        $code = $string;
        while (strlen($code) < 3) {
            $code .= 'X';
        }
        return $code;
    }

    private function _getLettere($string, array $haystack) {
        $letters = array();
        foreach (str_split($string) as $needle) {
            if (in_array($needle, $haystack)) {
                $letters[] = $needle;
            }
        }
        return $letters;
    }

    private function _getConsonanti($string) {
        return $this->_getLettere($string, $this->_consonanti);
    }

    private function _getVocali($string) {
        return $this->_getLettere($string, $this->_vocali);
    }

    private function calcolaNome($string) {
        $nome = $this->_sanitize($string);
        if (strlen($nome) < 3) {
            return $this->_addMissingX($nome);
        }
        $nome_cons = $this->_getConsonanti($nome);
        if (count($nome_cons) <= 3) {
            $code = implode('', $nome_cons);
        } else {
            for ($i = 0; $i < 4; $i++) {
                if ($i == 1)
                    continue;
                if (!empty($nome_cons[$i])) {
                    $code .= $nome_cons[$i];
                }
            }
        }
        if (strlen($code) < 3) {
            $nome_voc = $this->_getVocali($nome);
            while (strlen($code) < 3) {
                $code .= array_shift($nome_voc);
            }
        }
        return $code;
    }

    private function calcolaCognome($string) {
        $cognome = $this->_sanitize($string);
        if (strlen($cognome) < 3) {
            return $this->_addMissingX($cognome);
        }
        $cognome_cons = $this->_getConsonanti($cognome);
        $code = '';
        for ($i = 0; $i < 3; $i++) {
            if (array_key_exists($i, $cognome_cons)) {
                $code .= $cognome_cons[$i];
            }
        }
        if (strlen($code) < 3) {
            $cognome_voc = $this->_getVocali($cognome);
            while (strlen($code) < 3) {
                $code .= array_shift($cognome_voc);
            }
        }
        return $code;
    }

    public function register($formData, Form $form) {
        $success = true;
        try {
            $response = $this->preRegister($formData);
        } catch (Exception $e) {
            $success = false;
            $this->addMessage('Error preRegister: ', $this->{$e->getMessage()});
            $this->saveOldFormData($form);
            $this->redirectBack();
            return;
        }
        if ($success) {
            try {
                $this->updateContacts($formData);
                if (isset($formData['contact_email'])) {
                    $this->sendRegistrationEmail($formData);
                }
            } catch (Exception $e) {
                $this->addMessage('Error updateContacts: ', $e->getMessage());
            }
            if ($formData['foreigner'] != '1')
                $pageContent = $this->ConfirmationContentTwilio;
            else /* straniero */
                $pageContent = $this->ConfirmationContentTwilioForeign;
            /* Sostituzione segnaposto  */
            $pageContent = str_replace("#NOME", $formData['name'], $pageContent);
            $pageContent = str_replace("#COGNOME", $formData['lastname'], $pageContent);
            $pageContent = str_replace("#NUMERO", $formData['contact_value'], $pageContent);
            $pageContent = str_replace("#CF", $this->nationald_id, $pageContent);
        }
        return $this->customise(
                        array(
                            'PageContent' => $pageContent
                        )
                )->renderWith(array('RegistrationTwilioConfirmPage', 'Page'));
    }

    public function preRegister($formData) {

        global $sc;
        $patronStatus = $sc->getParameter('user.patronStatus');
        $patronLoanClass = $sc->getParameter('user.loanClass');
        $opacPwdExpire = $sc->getParameter('opac_password_expire') == false ? NULL : date('Y-m-d', strtotime("+".$sc->getParameter('opac_password_expire')." days"));

        if ($formData['foreigner'] != '1') {
            $this->nationald_id = $formData['national_id'];
            $this->username = $formData['national_id'];
        } else {
            /* straniero */
            $this->nationald_id = $formData['contact_value'];
            $this->username = $formData['contact_value'];
        }
        
        $connector = $this->getContainer()->get('liquens.connector');
        $response = $connector->registerNewUser(
                $this->username, $formData['password'], $opacPwdExpire,
                $formData['name'], $formData['lastname'], 
                $formData['preferred_library_id'] == "" ? $this->DefaultLibrary : $formData['preferred_library_id'], 
                $this->nationald_id, 
                NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
                $patronStatus, $patronLoanClass, 
                isset($formData['privacy_approve']) ? true : false,
                NULL, NULL, NULL,
                "twilio"
        );

        return $response;
    }

    public function sendRegistrationEmail($formData) {
        $siteTitle = DataObject::get_one('SiteConfig')->Title;

        $bodyContent = $this->ConfirmationTextEmail;
        /* Sostituzione segnaposto  */
        $bodyContent = str_replace("#NOME", $formData['name'], $bodyContent);
        $bodyContent = str_replace("#COGNOME", $formData['lastname'], $bodyContent);
        $bodyContent = str_replace("#NUMERO", $formData['contact_value'], $bodyContent);
        $bodyContent = str_replace("#CF", $this->nationald_id, $bodyContent);

        global $sc;

        $mail = new PHPMailer;
        
        /* TEST PER CLUBMEDICI */
        $mail->CharSet = 'utf-8';

        $mail->isSMTP();
        $mail->Host = $sc->getParameter('phpmailer.smtp');
        $mail->Port = $sc->getParameter('phpmailer.smtp_port');
        $mail->SMTPAuth = $sc->getParameter('phpmailer.auth');

        if (!is_null($sc->getParameter('phpmailer.username')))
            $mail->Username = $sc->getParameter('phpmailer.username');
        if (!is_null($sc->getParameter('phpmailer.password')))
            $mail->Password = $sc->getParameter('phpmailer.password');
        if (!is_null($sc->getParameter('phpmailer.security')))
            $mail->SMTPSecure = $sc->getParameter('phpmailer.security');

        if (!is_null($sc->getParameter('phpmailer.forcedFrom'))) 
            $mail->setFrom($sc->getParameter('phpmailer.forcedFrom'), $siteTitle);
        else
            $mail->setFrom($sc->getParameter('system_email'), $siteTitle);
        
        $mail->addAddress($formData['contact_email']);
        $mail->addReplyTo($this->ConfirmationLibraryEmail, $siteTitle);

        $mail->isHTML(true);

        $mail->Subject = 'Registrazione - ' . $siteTitle;
        $mail->Body = $this->customise(
                        array(
                            'SiteTitle' => $siteTitle,
                            'BodyContent' => $bodyContent
                        )
                )->renderWith('RegistrationTwilioConfirmEmail');

        /* Invio email */
        try {
            if (!$mail->send()) {
                $this->addMessage('Error', _t('MyDiscovery.ASSISTANCE_MAIL_ERROR', 'E-mail is not sent.'));
                Debug::log('PHPMailer '.$siteTitle.' Errore registrazione twilio: ' . $mail->ErrorInfo);
            } else {
                $this->addMessage('Success', _t('MyDiscovery.ASSISTANCE_MAIL_OK', 'E-mail successfully sent'));
            }
        } catch (Exception $e) {
            $this->addMessage('Error', _t('MyDiscovery.ASSISTANCE_MAIL_ERROR', 'E-mail is not sent.') ." Error: ". $e->getMessage());
            return;
        }
    }

    public function setLibraryRepository(\LibraryRepository $libraryRepository) {
        $this->libraryRepository = $libraryRepository;
        return $this;
    }

    public function getLibraryRepository() {
        return $this->libraryRepository;
    }

    private function getOldFormData(Form $form) {
        return Session::get("FormInfo.{$form->FormName()}.lq.oldData");
    }

    private function updateContacts($formData) {
        /** @var $connector CLAVISConnector */
        $connector = $this->getContainer()->get('liquens.connector');
        if (isset($formData['contact_email'])) {
            $connector->editContact(
                    $this->username, '', //contact_id. Empty for new contact
                    'E', //contact_type
                    $formData['contact_email'], 1 //contact_pref: Set as preferred contact
            );
        }
        if (isset($formData['contact_value'])) {
            $connector->editContact(
                    $this->username, '', //contact_id. Empty for new contact
                    'C', //contact_type
                    $formData['contact_value'], 0 //contact_pref
            );
        }
        return true;
    }

    public function getForeignerUser() {
        if ($this->foreigner == "false") {
            return false;
        } else {
            return true;
        }
    }

    public function getUsernameLogin() {
        return $this->username;
    }

    private function saveOldFormData(Form $form) {
        Session::set("FormInfo.{$form->FormName()}.lq.oldData", $form->getData());
        return $this;
    }

}
