<?php

class UserPublicSearchPage extends Page {
    public static $db = array();
}

class UserPublicSearchPage_Controller extends Page_Controller {
    
  private $cachedUPSList;
	 
    public static $allowed_actions = array(
        'Replicate'
    );
    
    public static $url_handlers = array(
        'replicate' => 'Replicate'
    );

    public function init() {
        parent::init();
    }
    
    public function listPublicSearches() {
        if (!isset($this->cachedUPSList)) {
            $searches = DataObject::get('Shelf', '`Visibility` = \'public\' AND `SerializedData` NOT LIKE \'N;\' AND `ClassName` = \'MappedSearchShelf\'', 'Created DESC', '', '');
            if (is_null($searches)) { return false; }
            $searchesSet = new DataObjectSet();
            foreach ($searches as $search) {
                $searchesSet->push(new ArrayData(array(
                    'Nome' => $search->Name,
                    'ID' => $search->ID,
                    'Desc' => $search->Description,
                    'Link' => 'shelf/view/'.$search->ID.'/lst?',
                    'User' => Member::get_one('Member', "ID = '$search->OwnerID'")->Username,
                    'DataC' => date_format(date_create($search->Created), 'd-m-Y'),
                    'DataM' => date_format(date_create($search->LastEdited), 'd-m-Y')
                )));
            }
            $this->cachedUPSList = $searchesSet;
        }
        return $this->cachedUPSList;
    }

    public function Replicate(SS_HTTPRequest $request) {
        
        $member = Member::currentUser();
        if (!$member) { $this->htmlHttpError(404); }

        $searchID = $request->getVar('searchID');
        
        $originalSearch = DataObject::get('Shelf', '`ID` = '.$searchID, '', '', 1);
        foreach ($originalSearch as $search) {
            $clonedSearch = new MappedSearchShelf();
            $clonedSearch->OwnerID = $member->ID;
            $clonedSearch->Visibility = 'public';
            $clonedSearch->SerializedData = $search->SerializedData;
            $clonedSearch->Name = "_Replica_ ".str_replace("_Replica_ ", "", $search->Name);
            $clonedSearch->Description = "Replica dello scaffale con ID ".$searchID." dell'utente '".Member::get_one('Member', "ID = '$search->OwnerID'")->Username."'";
            $clonedSearch->CenterLat = $search->CenterLat;
            $clonedSearch->CenterLon = $search->CenterLon;
            $clonedSearch->GeoType = $search->GeoType;
            $clonedSearch->IsGeotag = $search->IsGeotag;
            $clonedSearch->write();
        }
    } 
    
}