<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

class LibraryPage extends Page {
   
   static $has_one = array(
        'WidgetArea' => 'WidgetArea', //Old widget area
        'GridWidgetArea' => 'WidgetArea'     //New GridWidgetArea
    );
   
   static $allowed_children = array(
        'LibraryPage',
        'ShelfPage'
    );

   function getCMSFields($params = NULL) {
      $fields = parent::getCMSFields();
      $fields->addFieldToTab("Root.Content.GridWidgetArea", new GridWidgetAreaEditor('GridWidgetArea'));
      $fields->insertFirst(new LiteralField('', (string) new ContentWidgetWarning($this, 'GridWidgetArea')));

      return $fields;
   }

    /**
     * {@inheritdoc}
     */
    public function getPageTemplates()
    {
        $templates = parent::getPageTemplates();
        $templates[] = new ContentWidgetTemplate('GridWidgetArea');

        return $templates;
    }
}

class LibraryPage_Controller extends Page_Controller
{
    public static $allowed_actions = array();

    /**
     * @return array
     */
    public function getBodyClasses()
    {
        $libmainPage = $this->Level(2);

        $classes = array();
        if ($libmainPage)
            $classes = array('libmainpage-id-' . $this->Level(2)->ID);

        return array_merge(parent::getBodyClasses(), $classes);
    }
}