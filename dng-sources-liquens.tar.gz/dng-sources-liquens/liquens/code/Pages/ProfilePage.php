<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

class ProfilePage extends Page
{
    static $allowed_children = array(
        'none' => 'none'
    );
}


class ProfilePage_Controller extends Page_Controller
{
    public static $allowed_actions = array(
        'view',
        'id'
    );

    /**
     * @var Member
     */
    private $member;

    /**
     * {@inheritdoc}
     */
    public function init()
    {
        parent::init();
        
        // translate
        $this->i18nToJs(array(
            'Profile.CREATESHELF' => 'Create shelf',
            'Profile.CLOSEDIALOG' => 'Close',
            'Profile.SAVESEARCH' => 'Save search',
            'Profile.SEARCHDELETE' => 'Delete search',
            'Profile.CHOOSEASHELFFAULT' => 'Please choose a shelf to continue.',
            'Profile.CONFIRM' => 'Confirm',
        ));
    }

    /**
     * @return bool
     */
    public function isCurrentMemberProfileMember()
    {
        $currentMember = Member::currentUser();

        return $currentMember && ($currentMember->ID == $this->getProfileMember()->ID);
    }

    /* ACTIONS */

    /**
     * Get the list of bibliographic records
     * by a Solr request
     *
     * Rendered with ResultPage.ss
     *
     * @return page rendering
     */
    public function view()
    {
        return $this->renderProfile();
    }

    /**
     * Acccess to profile through user id
     * @param SS_HTTPRequest $request
     * @return \SS_HTTPResponse|string
     */
    public function id(SS_HTTPRequest $request)
    {
        $userID = (int) $request->param('ID');

        $this->member = Member::get_by_id('Member', $userID);

        return $this->renderProfile();
    }

    /**
     * @return Member|null
     */
    public function getProfileMember()
    {
        if (!isset($this->member)) {
            $request = $this->getRequest();
            $key = $request->param("ID");

            if ($request->getExtension())
                $key .= '.' . $request->getExtension();

            $this->member = $request->param('Action') == 'view'
                ? $this->getMemberyByUsername($key)
                : $this->getMemberByID($key);
        }

        return $this->member;
    }

    /**
     * Retrieve a member by its id
     * @param $id
     * @return Member
     */
    private function getMemberByID($id)
    {
        return Member::get_by_id('Member', (int) $id);
    }

    /**
     * Retrieve a Member by its username
     * @param $username
     * @return Member
     */
    private function getMemberyByUsername($username)
    {
        return DataObject::get_one(
            'Member',
            sprintf("Username = '%s'", Convert::raw2sql($username))
        );
    }

    /**
     * Return user's last comments to manifestations
     *
     * @return string
     */
    public function LastComments()
    {
        $widget = new ForumLastPosts();
        $widget->Title = _t('ProfilePage.COMMENTS_TITLE', 'Your last comments');
        $widget->NoPostMessage = _t('ProfilePage.COMMENTS_NOPOSTS', 'You have inserted no comments yet');
        $widget->ShowPostTitles = true;
        $widget->AvatarSize = 'small';
        $widget->PostType = 'only_comments';
        $widget->AuthorID = $this->getProfileMember()->ID;

        return $widget;
    }

    /**
     * Return user's last comments to manifestations
     *
     * @return string
     */
    public function LastPosts()
    {
        $widget = new ForumLastPosts();
        $widget->Title = _t('ProfilePage.POSTS_TITLE', 'Your last posts');
        $widget->NoPostMessage = _t('ProfilePage.POSTS_NOPOSTS', 'You have inserted no posts in the Forum yet');
        $widget->ShowPostTitles = true;
        $widget->AvatarSize = 'small';
        $widget->PostType = 'only_posts';
        $widget->AuthorID = $this->getProfileMember()->ID;

        return $widget;
    }

    private function renderProfile()
    {
        if (!$this->getProfileMember()) {
            return $this->htmlHttpError(404);
        }

        if (!$this->isCurrentMemberProfileMember() && !$this->getProfileMember()->getPrivacySetting('profile_visible')) {
            return $this->htmlHttpError(
                403,
                _t('Profile.PRIVATE_MESSAGE', 'The user\'s profile is private and can be accessed only by the user.'),
                _t('Profile.PRIVATE_TITLE', 'Profile unavailable')
            );
        }

        $data = array('IsMyProfile' => $this->isCurrentMemberProfileMember());

        $this->toJavascript(
            'lqStrings',
            array(
                'addPurchaseProposalTitle' => _t('Profile.PROPOSAL_DIALOGTITLE', 'New purchase proposal'),
            )
        );

        $this->i18nToJs(array(
            'Liquens.CONFIRMDELETE_TITLE' => 'Deletion confirmation',
            'Liquens.CONFIRMDELETE_CONTENT' => 'Are you sure you want to proceed with the deletion?',
            'Liquens.CONFIRMDELETE_BUTTON_OK' => 'Delete',
            'Liquens.CONFIRMDELETE_BUTTON_CANCEL' => 'Cancel'
        ));

        return $this->customise($data)->renderWith(array('ProfilePage', 'Page'));
    }
}
