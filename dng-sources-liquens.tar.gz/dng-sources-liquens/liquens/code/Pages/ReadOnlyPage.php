<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

/**
 * This is a page whose content cannot be edited, but that it is rendererd with the ss
 * specified by the Template property
 */
class ReadOnlyPage extends Page
{
    static $db = array(
        'Template' => 'Text'
    );

    /**
     * @return FieldSet
     */
    public function getCMSFields($params = NULL)
    {
        global $_TEMPLATE_MANIFEST;

        $templates = array_filter(array_keys($_TEMPLATE_MANIFEST), function($templateName){
            if ('_RO' === substr($templateName, -3))
                return true;
            return false;
        });

        $templatesMap = array();

        foreach($templates as $templateName) {
            $templatesMap[$templateName] = substr($templateName, 0, strlen($templateName)-3);
        }

		$fields = parent::getCMSFields();

        $fields->findOrMakeTab('Root.Content.Main')->removeByName('Content');

        $fields->addFieldToTab('Root.Content.Main',
            new DropdownField(
                "Template",
                "Template",
                $templatesMap
            )
        );

		return $fields;
	}
}

/**
 * The ReadOnlyPage Controller
 */
class ReadOnlyPage_Controller extends Page_Controller
{
    static $allowed_actions = array(
        'index'
    );

    /**
     * The default page action
     */
    public function index()
    {
        return $this->renderWith(array($this->Template, 'Page'));
    }
}
