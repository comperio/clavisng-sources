<?php

class MyDiscoveryPage extends Page {

    public static $db = array(
        "PurchaseProposalType" => "Text",
        
        "PrivacyPolicyTitle" => "VarChar(255)",
        "PrivacyPolicy" => "HTMLText",
        "PrivacyModal" => "VarChar(255)",
        
        "ExternalDataTransmissionCheck" => "Boolean",
        "ExternalDataTransmissionTitle" => "VarChar(255)",
        "ExternalDataTransmission" => "HTMLText",
        "ExternalDataTransmissionClavisParam" => "VarChar(1)",
        
        "NewsletterCheck" => "Boolean",
        "NewsletterTitle" => "VarChar(255)",
        "Newsletter" => "HTMLText",
        "NewsletterClavisParam" => "VarChar(1)",
        
        "Attr3Check" => "Boolean",
        "Attr3Title" => "VarChar(255)",
        "Attr3Text" => "HTMLText",
        "Attr3ClavisParam" => "VarChar(1)",

        "Attr4Check" => "Boolean",
        "Attr4Title" => "VarChar(255)",
        "Attr4Text" => "HTMLText",
        "Attr4ClavisParam" => "VarChar(1)",
        
        "Attr5Check" => "Boolean",
        "Attr5Title" => "VarChar(255)",
        "Attr5Text" => "HTMLText",
        "Attr5ClavisParam" => "VarChar(1)",
        
        "UserContactToLibrary" => "VarChar(1)"
    );

    static $defaults = array(
        'PurchaseProposalType' => "Libro;eBook;CD;DVD;Rivista",
        'UserContactToLibrary' => 1
    );
    
    public function getCMSFields($params = NULL) {
        $fields = parent::getCMSFields();
        
        $fields->addFieldToTab("Root.Content.TipologiaPropostaAcquisto", new TextField('PurchaseProposalType', "Inserire la tipologia della proposta d'acquisto che può scegliere l'utente (formato: nomi separati da ; senza spazi)"));

        $fields->addFieldToTab("Root.Content.UtilizzoDatiUtente", new TextField('PrivacyModal', 'Testo del modale di avviso'));
        $fields->addFieldToTab("Root.Content.UtilizzoDatiUtente", new TextField('PrivacyPolicyTitle', 'Titolo Informativa privacy'));
        $fields->addFieldToTab("Root.Content.UtilizzoDatiUtente", new HtmlEditorField('PrivacyPolicy', 'Testo Informativa privacy', 10));

        $fields->addFieldToTab('Root.Content.UtilizzoDatiUtente', new CheckBoxField('ExternalDataTransmissionCheck', 'Abilitazione primo attributo utente di Clavis. Salva dopo ogni modifica.'));
        if ($this->ExternalDataTransmissionCheck) {
            $fields->addFieldToTab("Root.Content.UtilizzoDatiUtente", new LiteralField('P1Start', '<div class="searchpage_config_options">'));
            $fields->addFieldToTab("Root.Content.UtilizzoDatiUtente", new TextField('ExternalDataTransmissionClavisParam', 'Primo attributo utente (1 carattere)', "", 1));
            $fields->addFieldToTab("Root.Content.UtilizzoDatiUtente", new TextField('ExternalDataTransmissionTitle', 'Titolo Primo attributo utente', "", 255));
            $fields->addFieldToTab("Root.Content.UtilizzoDatiUtente", new HtmlEditorField('ExternalDataTransmission', 'Testo Primo attributo utente', 10));
            $fields->addFieldToTab("Root.Content.UtilizzoDatiUtente", new LiteralField('P1End', '</div>'));
        }

        $fields->addFieldToTab('Root.Content.UtilizzoDatiUtente', new CheckBoxField('NewsletterCheck', 'Abilitazione secondo attributo utente di Clavis. Salva dopo ogni modifica.'));
        if ($this->NewsletterCheck) {
            $fields->addFieldToTab("Root.Content.UtilizzoDatiUtente", new LiteralField('P2Start', '<div class="searchpage_config_options">'));
            $fields->addFieldToTab("Root.Content.UtilizzoDatiUtente", new TextField('NewsletterClavisParam', 'Secondo attributo utente (1 carattere)', "", 1));
            $fields->addFieldToTab("Root.Content.UtilizzoDatiUtente", new TextField('NewsletterTitle', 'Titolo Secondo attributo utente', "", 255));
            $fields->addFieldToTab("Root.Content.UtilizzoDatiUtente", new HtmlEditorField('Newsletter', 'Testo Secondo attributo utente', 10));
            $fields->addFieldToTab("Root.Content.UtilizzoDatiUtente", new LiteralField('P2End', '</div>'));
        }
        
        $fields->addFieldToTab('Root.Content.UtilizzoDatiUtente', new CheckBoxField('Attr3Check', 'Abilitazione terzo attributo utente di Clavis. Salva dopo ogni modifica.'));
        if ($this->Attr3Check) {
            $fields->addFieldToTab("Root.Content.UtilizzoDatiUtente", new LiteralField('P3Start', '<div class="searchpage_config_options">'));
            $fields->addFieldToTab("Root.Content.UtilizzoDatiUtente", new TextField('Attr3ClavisParam', 'Terzo attributo utente (1 carattere)', "", 1));
            $fields->addFieldToTab("Root.Content.UtilizzoDatiUtente", new TextField('Attr3Title', 'Titolo Terzo attributo utente', "", 255));
            $fields->addFieldToTab("Root.Content.UtilizzoDatiUtente", new HtmlEditorField('Attr3Text', 'Testo Terzo attributo utente', 10));
            $fields->addFieldToTab("Root.Content.UtilizzoDatiUtente", new LiteralField('P3End', '</div>'));
        }
        
        $fields->addFieldToTab('Root.Content.UtilizzoDatiUtente', new CheckBoxField('Attr4Check', 'Abilitazione quarto attributo utente di Clavis. Salva dopo ogni modifica.'));
        if ($this->Attr4Check) {
            $fields->addFieldToTab("Root.Content.UtilizzoDatiUtente", new LiteralField('P4Start', '<div class="searchpage_config_options">'));
            $fields->addFieldToTab("Root.Content.UtilizzoDatiUtente", new TextField('Attr4ClavisParam', 'Quarto attributo utente (1 carattere)', "", 1));
            $fields->addFieldToTab("Root.Content.UtilizzoDatiUtente", new TextField('Attr4Title', 'Titolo Quarto attributo utente', "", 255));
            $fields->addFieldToTab("Root.Content.UtilizzoDatiUtente", new HtmlEditorField('Attr4Text', 'Testo Quarto attributo utente', 10));
            $fields->addFieldToTab("Root.Content.UtilizzoDatiUtente", new LiteralField('P4End', '</div>'));
        }
        
        $fields->addFieldToTab('Root.Content.UtilizzoDatiUtente', new CheckBoxField('Attr5Check', 'Abilitazione quinto attributo utente di Clavis. Salva dopo ogni modifica.'));
        if ($this->Attr5Check) {
            $fields->addFieldToTab("Root.Content.UtilizzoDatiUtente", new LiteralField('P5Start', '<div class="searchpage_config_options">'));
            $fields->addFieldToTab("Root.Content.UtilizzoDatiUtente", new TextField('Attr5ClavisParam', 'Quinto attributo utente (1 carattere)', "", 1));
            $fields->addFieldToTab("Root.Content.UtilizzoDatiUtente", new TextField('Attr5Title', 'Titolo Quinto attributo utente', "", 255));
            $fields->addFieldToTab("Root.Content.UtilizzoDatiUtente", new HtmlEditorField('Attr5Text', 'Testo Quinto attributo utente', 10));
            $fields->addFieldToTab("Root.Content.UtilizzoDatiUtente", new LiteralField('P5End', '</div>'));
        }
        
        $fields->addFieldToTab('Root.Content.UtenteContattaBiblioteca', new CheckBoxField('UserContactToLibrary', "Permettere all'utente di contattare la biblioteca?"));
        return $fields;
    }

    public function onBeforeWrite() {
        parent::onBeforeWrite();
        if (!$this->ExternalDataTransmissionCheck) {
            $this->ExternalDataTransmissionClavisParam = "";
            $this->ExternalDataTransmissionTitle = "";
            $this->ExternalDataTransmission = "";
        }
        if (!$this->NewsletterCheck) {
            $this->NewsletterClavisParam = "";
            $this->NewsletterTitle = "";
            $this->Newsletter = "";
        }
        if (!$this->Attr3Check) {
            $this->Attr3ClavisParam = "";
            $this->Attr3Title = "";
            $this->Attr3Text = "";
        }
        if (!$this->Attr4Check) {
            $this->Attr4ClavisParam = "";
            $this->Attr4Title = "";
            $this->Attr4Text = "";
        }
        if (!$this->Attr5Check) {
            $this->Attr5ClavisParam = "";
            $this->Attr5Title = "";
            $this->Attr5Text = "";
        }
        if($this->PurchaseProposalType == '')
            $this->PurchaseProposalType = "Libro;eBook;CD;DVD;Rivista";
        
        if(is_null($this->UserContactToLibrary))
            $this->UserContactToLibrary = 1;
    }

}
