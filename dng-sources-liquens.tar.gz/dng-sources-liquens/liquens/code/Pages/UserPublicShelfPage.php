<?php

class UserPublicShelfPage extends Page {
    public static $db = array();
}

class UserPublicShelfPage_Controller extends Page_Controller {
    
    private $cachedUPSList;
	 
    public static $allowed_actions = array(
        'Replicate'
    );
    
    public static $url_handlers = array(
        'replicate' => 'Replicate'
    );

    public function init() {
        parent::init();
    }
    
    public function listPublicShelves() {
        if (!isset($this->cachedUPSList)) {
            $shelves = DataObject::get('Shelf', '`Visibility` = \'public\' AND `SerializedData` NOT LIKE \'N;\' AND `ClassName` = \'ManifestationsShelf\'', 'Created DESC', '', '');
            if (is_null($shelves)) { return false; }
            $shelvesSet = new DataObjectSet();
            foreach ($shelves as $shelf) {
                $shelvesSet->push(new ArrayData(array(
                    'Nome' => $shelf->Name,
                    'Tot' => count(unserialize($shelf->SerializedData)["manifestations"]),
                    'ID' => $shelf->ID,
                    'Desc' => $shelf->Description,
                    'Link' => 'shelf/view/'.$shelf->ID.'/lst?',
                    'User' => Member::get_one('Member', "ID = '$shelf->OwnerID'")->Username,
                    'DataC' => date_format(date_create($shelf->Created), 'd-m-Y'),
                    'DataM' => date_format(date_create($shelf->LastEdited), 'd-m-Y')
                )));
            }
            $this->cachedUPSList = $shelvesSet;
        }
        return $this->cachedUPSList;
    }

    public function Replicate(SS_HTTPRequest $request) {
        
        $member = Member::currentUser();
        if (!$member) { $this->htmlHttpError(404); }

        $shelfID = $request->getVar('shelfID');
        
        $originalShelf = DataObject::get('Shelf', '`ID` = '.$shelfID, '', '', 1);
        foreach ($originalShelf as $shelf) {
            $clonedShelf = new ManifestationsShelf();
            $clonedShelf->OwnerID = $member->ID;
            $clonedShelf->Visibility = 'public';
            $clonedShelf->SerializedData = $shelf->SerializedData;
            $clonedShelf->Name = "_Replica_ ".str_replace("_Replica_ ", "", $shelf->Name);
            $clonedShelf->Description = "Replica dello scaffale con ID ".$shelfID." dell'utente '".Member::get_one('Member', "ID = '$shelf->OwnerID'")->Username."'";
            $clonedShelf->CenterLat = $shelf->CenterLat;
            $clonedShelf->CenterLon = $shelf->CenterLon;
            $clonedShelf->GeoType = $shelf->GeoType;
            $clonedShelf->IsGeotag = $shelf->IsGeotag;
            $clonedShelf->write();
        }
    } 
    
}