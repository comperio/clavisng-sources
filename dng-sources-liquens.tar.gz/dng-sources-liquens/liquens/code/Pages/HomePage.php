<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

/**
 * Defines the HomePage page type
 */
class HomePage extends Page {

    static $db = array(
    );
    static $has_one = array(
        'TeaserWidgetArea' => 'WidgetArea',
        'ContentWidgetArea' => 'WidgetArea',
        'BottomLeftWidgetArea' => 'WidgetArea',
        'BottomRightWidgetArea' => 'WidgetArea',
        'WidgetArea' => 'WidgetArea'
    );

    function getCMSFields($params = NULL)
    {
        $fields = parent::getCMSFields();
        $fields->addFieldToTab("Root.Content.WidgetArea", new GridWidgetAreaEditor('WidgetArea'));
        $fields->insertFirst(new LiteralField('', (string) new ContentWidgetWarning($this, 'WidgetArea')));

        return $fields;
    }

    /**
     * {@inheritdoc}
     */
    public function getPageTemplates()
    {
        $templates = parent::getPageTemplates();
        $templates[] = new HomeTemplate('WidgetArea');

        return $templates;
    }
}
    
class HomePage_Controller extends Page_Controller
{
    public static $allowed_actions = array();

    /**
     * Returns the list of upcoming system events
     *
     * @return EventsWidget
     */
    public function EventsWidget()
    {
        $eventsWidget = new EventsWidget();
        $eventsWidget->Limit = 15;

        return $eventsWidget;
    }
}



