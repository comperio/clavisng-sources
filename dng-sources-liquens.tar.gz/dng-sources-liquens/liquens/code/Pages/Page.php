<?php

use Symfony\Component\DependencyInjection\ContainerBuilder;

/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class Page extends LqTranslatedPage
{

    public static $db = array(
        'ShareButton' => 'Boolean',
    );
    public static $has_one = array();
    public static $defaults = array(
        'ShowInMenus' => 1,
        'ShareButton' => false,
    );
    private $isFirstWrite = false;

    function getCMSFields($params = NULL)
    {

        //Disable cms extension for Translatable fields issues
        SiteTree::disableCMSFieldsExtensions();
        $fields = parent::getCMSFields();

        //Prevent problems with error pages
        if ($this instanceof ErrorPage)
            return $fields;

        //Remove ProvideComments checkbox
        $fields->findOrMakeTab('Root.Behaviour')->removeByName('ProvideComments');

        $fields->addFieldToTab('Root.Behaviour', new CheckboxField('ShareButton', _t('SiteConfig.SHAREBUTTON')));

        $contentTab = $fields->findOrMakeTab('Root.Content');
        $contentTab->removeByName('Main');

        $titlesTab = new Tab('TitlesTab', _t('CMS.TAB_TITLE'));
        $titlesTab->push(new TextField("Title", $this->fieldLabel('Title')));
        $titlesTab->push(new TextField("MenuTitle", $this->fieldLabel('MenuTitle')));

        $textTab = new Tab('Testo', _t('CMS.TAB_TEXT'));
        $textTab->push(new HtmlEditorField("Content", _t('SiteTree.HTMLEDITORTITLE', "Content", PR_MEDIUM, 'HTML editor title')));

        $contentTab->insertBefore($titlesTab, 'Metadata');
        $contentTab->insertBefore($textTab, 'Metadata');

        //Now we can apply extensions
        SiteTree::enableCMSFieldsExtensions();
        $this->extend('updateCMSFields', $fields);

        return $fields;
    }

    /**
     * Returns base dir for liquens module, relative to the baseHref
     * @return string
     */
    public static function BaseLiquensSegment()
    {
        return 'liquens';
    }

    /**
     * Override pain in the ass Silverstripe behaviour that nullifies the menutitle if it is equal to the
     * title
     *
     * @param string $value
     */
    public function setMenuTitle($value)
    {
        $this->setField("MenuTitle", $value);
    }

    /**
     * Utilizzato per meta da dare in pasto a Facebook
     *
     * @var type
     */
    public $arrayTags = array();

    /**
     * Add the meta-tag
     * @param bool $includeTitle
     *
     * @return string The string of MetaTags
     */
    public function MetaTags($includeTitle = true)
    {
        $locale = i18n::get_locale();
        $this->arrayTags['before'] = parent::MetaTags($includeTitle);
        $this->arrayTags['charset'] = '<meta charset="utf-8"/>';
        $this->arrayTags['language'] = '<meta http-equiv="Content-Language" content="' . $locale . '" />';

        $ret = 'Nessuna descrizione';
        if ($this->Content != '' || !is_null($this->Content)) {
            $numWords = 15;
            $add = '...';
            $value = strip_tags($this->Content);
            $value = trim(Convert::xml2raw($value));
            $ret = explode(' ', $value, $numWords + 1);
            if (count($ret) <= $numWords - 1) {
                $ret = $value;
            } else {
                array_pop($ret);
                $ret = implode(' ', $ret) . $add;
            }
        }
        $this->arrayTags['og:description'] = '<meta property="og:description" content="' . $ret . '" />';

        return join('', $this->arrayTags);
    }

    /**
     * Get URL after BaseHref, to get full URL (also Actions)
     *
     * @return string The Url
     */
    public function urlAfterBase()
    {
        $params = Director::urlParams();
        $url = $params['Lang'] ? $params['Lang'] : '';
        $url .= $params['URLSegment'] ? "/" . $params['URLSegment'] : '';
        $url .= $params['Action'] ? "/" . $params['Action'] : '';
        $url .= $params['ID'] ? "/" . $params['ID'] : '';
        $url = filter_var($url, FILTER_SANITIZE_STRING);
        return $url;
    }

    public function getContainer()
    {
        return Page_Controller::$container;
    }

    /**
     * Returns the first child of the page of type $pageType
     *
     * @param $pageType
     * @return Page
     */
    public function getChildPage($pageType)
    {
        return DataObject::get_one($pageType, sprintf("ParentID = %d", $this->ID));
    }

    /**
     * Augment duplication with AreaWidget duplications
     *
     * @param bool $doWrite
     * @return SiteTree
     */
    public function duplicate($doWrite = true)
    {
        $duplicated = parent::duplicate($doWrite);

        $duplicated->duplicateOwnedWidgetAreas();

        return $duplicated;
    }

    /**
     * Templates that fill the page on page creation
     *
     * @return PageTemplate[]
     */
    public function getPageTemplates()
    {
        return array();
    }

    /**
     * Check if it is the first write. If so, set IsFirstWrite to true
     */
    protected function onBeforeWrite()
    {
        $this->Content = preg_replace('|<iframe(.*)/>|Uims', '<iframe\\1> </iframe>', $this->Content);
        parent::onBeforeWrite();

        if (!$this->isInDB())
            $this->isFirstWrite = true;
    }

    /**
     * Apply templates if it is the first page write
     */
    public function onAfterWrite()
    {
        if ($this->isFirstWrite) {
            $templates = $this->getPageTemplates();
            foreach ($templates as $template) {
                $template->fill($this);
            }
            $this->isFirstWrite = false;
            if ($templates)
                $this->write();
        }

        parent::onAfterWrite();
    }

    /**
     * Publish the page and all its children
     */
    public function publishWithChildren()
    {
        $this->publish('Stage', 'Live');

        $children = $this->AllChildren() ?: new DataObjectSet();

        foreach ($children as $child) {
            $child->publishWithChildren();
        }
    }

}

class Page_Controller extends LqTranslatedPage_Controller
{

    /** @var ContainerBuilder */
    public static $container;
    public static $inHeader = array();
    public static $inFooter = array();

    /**
     * @return DngContainer
     */
    public function getContainer()
    {
        return static::$container;
    }

    /**
     * Inject services
     *
     * @param null $dataRecord
     */
    public function __construct($dataRecord = null)
    {
        parent::__construct($dataRecord);

        global $sc;
        Kernel::load_injections($this, $sc);
    }

    /**
     * @return void
     */
    public function init()
    {
        parent::init();

        $this->initGoogleAnalytics();

        $this->DngFlags = new DataObject(LQConfig::get('dngFlags'));

        $member = Member::currentUser();

        if ($member) {
            $member->checkOpacEnable();

            /* Verifica privacy */
            global $sc;
            if ($sc->getParameter('mandatory_privacy') == true) {
                $externalData = $member->getExternalData();
                if (($externalData["group"] == "patron") && ($externalData["patron"]['PrivacyApprove'] !== "1")) {
                    Session::clear("FeedbackMessages");
                    if (strpos($_SERVER['REQUEST_URI'], '/mydiscovery') === false) {
                        $this->redirect('mydiscovery/#privacy');
                    }
                }
            }

            if (isset($_GET['loginAs'])) {
                $member->loginAsAnotherUser($_GET['loginAs']);
                //$this->redirect('home');
            }
        }

        // Autologin per app esterna
        if (isset($_GET['autoLogin'])) {
            $member = DataObject::get_one('Member', "\"RememberLoginToken\"='" . Convert::raw2sql($_GET['autoLogin']) . "'");
            if ($member) {
                $member->logIn();

                global $sc;
                $myclavis = new CLAVISConnector($sc->getParameter('lq.connector.url'));
                $myclavis->getSoapClient('user')->saveSessionIdentifier(Convert::raw2sql($_GET['autoLogin']), session_id());

                $this->redirect('home');
            }
        }
    }

    public function initGoogleAnalytics()
    {
        $accountId = $this->SiteConfig->GoogleAnalyticsAccountID;

        if ($accountId) {
            $memberType = Member::currentUser() ? 'Member' : 'Visitor';
            Requirements::customScript(<<<JS
                              var _gaq = _gaq || [];
                              _gaq.push(['_setAccount', '$accountId']);
                              _gaq.push(['_trackPageview']);

                              _gaq.push(['_setCustomVar', 1, 'User Type', '{$memberType}', 2]);

                              (function() {
                                var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
                                ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
                                var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
                              })();
JS
            );
        }
    }

    /**
     * Assign $value, encoded to json, to the Javascript variable of name $varname
     * @param string $varname The name tha will have the var in JS
     * @param string|array|int|bool|float|double $value a JSON-able object
     */
    public function toJavascript($varname, $value)
    {
        $jsonValue = json_encode($value);
        Requirements::customScript(<<<JS
            var $varname = $jsonValue;
JS
        );
    }

    /**
     * Usage: i18nToJs(array('key' => 'fallback string', ...)
     *
     * @param string $keys
     *
     * @return Page_Controller
     */
    public static function i18nToJs($keys)
    {
        $localeJs = json_encode(i18n::get_locale());

        //Set the current ss locale in the JS i18n
        $lines = array("ss.i18n.setLocale($localeJs);");

        foreach ($keys as $key => $defaultString) {
            $keyJs = json_encode($key);
            $stringJs = json_encode(_t($key, $defaultString));
            $lines[] = "ss.i18n.addDictionary($localeJs, { $keyJs: $stringJs });";
        }

        Requirements::javascript(SAPPHIRE_DIR . "/javascript/i18n.js");
        Requirements::customScript(implode(PHP_EOL, $lines));
    }

    /**
     * Overwrite redirectBack to give the possibility to specify an hash to append to the url
     *
     * @param string $hash
     * @return bool|void
     */
    public function redirectBack($hash = '')
    {
        if ($this->request->requestVar('_REDIRECT_BACK_URL')) {
            $url = $this->request->requestVar('_REDIRECT_BACK_URL');
        } else if ($this->request->getHeader('Referer')) {
            $url = $this->request->getHeader('Referer');
        } else {
            $url = Director::baseURL();
        }

        if ($hash)
            $url .= '#' . $hash;

        // absolute redirection URLs not located on this site may cause phishing
        if (Director::is_site_url($url)) {
            return $this->redirect($url);
        } else {
            return false;
        }
    }

    /**
     * Set a custom message to be displayed only once
     *
     * @param string $type
     * @param string $message
     * @param string $title
     */
    public function addMessage($type, $message, $title = '')
    {
        $messages = Session::get('FeedbackMessages') ?: array();
        $newMessage = array(
            'Type' => strtolower($type),
            'Content' => $message
        );
        if ($title)
            $newMessage['Title'] = $title;

        $messages[] = $newMessage;

        Session::set('FeedbackMessages', $messages);
    }

    /**
     * Get the current message previously inserted in the Session
     * with addMessage and clear the messages in the session
     *
     * @return DataObjectSet
     */
    public function getMessages()
    {
        if ($messages = Session::get('FeedbackMessages')) {
            Session::clear('FeedbackMessages');
            return new DataObjectSet($messages);
        }

        return new DataObjectSet();
    }

    /**
     * @param $name
     * @return mixed|null
     */
    public function getLQConfigValue($name)
    {
        return LQConfig::get($name);
    }

    /**
     * Pass all Container Parameters as an ArrayData
     *
     * @return ArrayData
     */
    public function getParams()
    {
        return new ArrayData($this->getContainer()->getParameterBag()->all());
    }

    /**
     * Only Used in IFramedPage, to give the capability to specify the
     * @return string
     */
    public function getLinkTarget()
    {
        return $this->getRequest()->getVar('lnk-target') ?: '_parent';
    }

    /**
     * @return DevToolbar
     */
    public function getDevToolbar()
    {
        $toolbar = $this->getContainer()->get('dev_toolbar');

        foreach ($this->extraDevToolbarButtons() as $groupName => $buttons) {
            foreach ($buttons as $button)
                $toolbar->addButton($button, $groupName);
        }

        return $toolbar;
    }

    public function DNGMenuCacheKey()
    {
        return 'DNGMenuCacheKey_' . LangController::get_current_locale();
    }

    public function NavTopRightMenuCacheKey()
    {
        return 'NavTopRightMenuCacheKey_' . LangController::get_current_locale();
    }

    public function FooterCacheKey()
    {
        return 'FooterCacheKey_' . LangController::get_current_locale();
    }

    /**
     * Retrieve a root MenuItem with the given name
     *
     * @param $name
     * @return DataObject
     */
    public function getDNGMenu($name)
    {
        return DataObject::get_one(
            'MenuItem', sprintf("Name = '%s' AND ParentID = 0 AND Locale = '%s'", Convert::raw2sql($name), Convert::raw2sql(i18n::get_locale()))
        );
    }

    /**
     * Estrae l'ID utente
     *
     * @return type
     */
    public function userIdDeadline()
    {
        return Member::currentUserID();
    }

    /**
     * ritorna lo stato di rientro dal modale di login
     *
     * @return type
     */
    public function afterLogin()
    {
        return Session::get('afterLogin');
    }

    /**
     * Dopo il login, verifica le scadenze dell'utente e se ci sono, popola il modale
     *
     * @return boolean|string
     * @global type $sc
     */
    public function getUserDeadline()
    {

        Session::set('afterLogin', FALSE);

        global $sc;

        if ($sc->getParameter('userdata.deadlines') == false) {
            return false;
        }

        if (((split(":", Member::currentUser()->External_Anchor)[0]) == "librarian") ||
            (is_null(Member::currentUser()->External_Anchor))
        ) {
            return false;
        }

        $externalData = $sc->get('liquens.connector')->getUserData(Member::currentUser()->Username);
        $dataBag = new UserDataBagProxy(new UserDataBag(Member::currentUserID()), $sc->getParameter('userdata.caching_interval'));
        $activeLoans = $sc->get('liquens.connector')->getPatronActiveLoans(Member::currentUser()->Username);
        $activeRequests = $sc->get('liquens.connector')->getPatronActiveRequests(Member::currentUser()->Username);

        $giorniScadenzaPrestiti = $sc->getParameter('userdata.lateloansdays');
        $giorniScadenzaPrenotazioni = $sc->getParameter('userdata.pendingloansdays');
        $giorniScadenzaDocumento = $sc->getParameter('userdata.documentexpirydays');
        $giorniScadenzaIscrizione = $sc->getParameter('userdata.cardexpiredays');
        //$attivazioneTipiScadenze = split("-",$sc->getParameter('userdata.deadtypes'));

        $scadenzaPrestiti = 0;
        foreach ($activeLoans as $activeLoan) {
            if ((strtotime($giorniScadenzaPrestiti, strtotime($activeLoan['DueDate'])) < strtotime("now")) &&
                (strtotime($activeLoan['DueDate']) > strtotime("now"))) {
                $scadenzaPrestiti++;
            }
        }
        $scadenzaPrenotazioni = 0;
        foreach ($activeRequests as $activeRequest) {
            if ((strtotime($giorniScadenzaPrenotazioni, strtotime($activeRequest['ExpireDate'])) < strtotime("now")) &&
                (strtotime($activeRequest['ExpireDate']) > strtotime("now"))) {
                $scadenzaPrenotazioni++;
            }
        }

        $patronData = array(
            'patronStatus' => $externalData['patron']['PatronStatus'],
            'patronLateLoansCount' => $dataBag->getData('LateLoansCount')->getValue(),
            'patronDueDateLoansCount' => $scadenzaPrestiti,
            'patronPendingLoansCount' => $dataBag->getData('PendingLoansCount')->getValue(),
            'patronDueDatePendingLoansCount' => $scadenzaPrenotazioni,
            'patronDocumentType' => $externalData['patron']['DocumentType'],
            'patronDocumentExpiry' => $externalData['patron']['DocumentExpiry'],
            'cardExpire' => $externalData['patron']['CardExpire']
        );

        $deadline = false;
        $contenuto = '';
        /* Utente non abilitato */
        if (($patronData['patronStatus'] != 'A') &&
            (in_array($patronData['patronStatus'], array('B', 'C', 'E', 'R', 'D')))) {
            $contenuto .= '<i class="fa fa-user"></i> ' . _t('DEADLINE.STATOUTENTE', 'User with') . ' "' . _t("LV_PATRONSTATE." . $patronData["patronStatus"], '') . '". ' . _t('DEADLINE.MSGSTATOUTENTE', 'Go at your favorite library.');
            $deadline = true;
        }
        /* Prestiti in scadenza o scaduti */
        if ($patronData['patronDueDateLoansCount'] > 0) {
            $contenuto .= ($deadline ? '<hr>' : '') . '<i class="fa fa-book"></i> ' . _t('DEADLINE.PRESTITISCADENZA', 'Loans due within "%s" days:', filter_var(abs($giorniScadenzaPrestiti)), FILTER_SANITIZE_NUMBER_INT) . ' ' . $patronData['patronDueDateLoansCount'] . ' (' . _t('DEADLINE.STATO', 'Check your status at') . ' <a href="mydiscovery#loans_active">MyDiscovery</a>)';
            $deadline = true;
        }
        if ($patronData['patronLateLoansCount'] > 0) {
            $contenuto .= ($deadline ? '<hr>' : '') . '<i class="fa fa-book"></i> ' . _t('DEADLINE.PRESTITISCADUTI', 'Overdue loans') . ' ' . $patronData['patronLateLoansCount'] . ' (' . _t('DEADLINE.STATO', 'Check your status at') . ' <a href="mydiscovery#loans_active">MyDiscovery</a>)';
            $deadline = true;
        }
        /* Prenotazioni in scadenza o scadute */
        if ($patronData['patronDueDatePendingLoansCount'] > 0) {
            $contenuto .= ($deadline ? '<hr>' : '') . '<i class="fa fa-shopping-cart"></i> ' . _t('DEADLINE.PRENOTAZIONISCADENZA', 'Reservations due within "%s" days:', filter_var(abs($giorniScadenzaPrenotazioni)), FILTER_SANITIZE_NUMBER_INT) . ' ' . $patronData['patronDueDatePendingLoansCount'] . ' (' . _t('DEADLINE.STATO', 'Check your status at') . ' <a href="mydiscovery#loans_reservations">MyDiscovery</a>)';
            $deadline = true;
        }
        if ($patronData['patronPendingLoansCount'] > 0) {
            $contenuto .= ($deadline ? '<hr>' : '') . '<i class="fa fa-shopping-cart"></i> ' . _t('DEADLINE.PRENOTAZIONISCADUTE', 'Reservations expired:') . ' ' . $patronData['patronPendingLoansCount'] . ' (' . _t('DEADLINE.STATO', 'Check your status at') . ' <a href="mydiscovery#loans_reservations">MyDiscovery</a>)';
            $deadline = true;
        }

        /* Scadenza documento di identità */
        //if (strtotime($patronData['patronDocumentExpiry']) !== false) {
        if (strlen($patronData['patronDocumentExpiry']) != 10) {
            if ((!is_null($patronData['patronDocumentExpiry'])) &&
                ((strtotime($giorniScadenzaDocumento, strtotime($patronData['patronDocumentExpiry']))) < strtotime("now")) &&
                (strtotime($patronData['patronDocumentExpiry']) > strtotime("now"))) {
                $contenuto .= ($deadline ? '<hr>' : '') . '<i class="fa fa-file-text"></i> ' . _t('DEADLINE.DOCUMENTO', 'The document') . ' ' . _t("LV_IDDOCS." . $patronData['patronDocumentType'], '') . ' ' . _t('DEADLINE.DOCUMENTOSCADENZA', 'expires') . ' ' . date_format(date_create($patronData['patronDocumentExpiry']), "d-m-Y");
                $deadline = true;
            }
            if ((!is_null($patronData['patronDocumentExpiry'])) &&
                (strtotime($patronData['patronDocumentExpiry']) < strtotime("now"))) {
                $contenuto .= ($deadline ? '<hr>' : '') . '<i class="fa fa-file-text"></i> ' . _t('DEADLINE.DOCUMENTO', 'The document') . ' ' . _t("LV_IDDOCS." . $patronData['patronDocumentType'], '') . ' ' . _t('DEADLINE.DOCUMENTOSCADUTO', 'expired on') . ' ' . date_format(date_create($patronData['patronDocumentExpiry']), "d-m-Y");
                $deadline = true;
            }
        }

        /* Scadenza iscrizione alla biblioteca */
        //if (strtotime($patronData['cardExpire']) !== false) {
        if (strlen($patronData['cardExpire']) != 10) {
            if (((strtotime($giorniScadenzaIscrizione, strtotime($patronData['cardExpire']))) < strtotime("now")) &&
                (strtotime($patronData['cardExpire']) > strtotime("now"))) {
                $contenuto .= ($deadline ? '<hr>' : '') . '<i class="fa fa-warning"></i> ' . _t('DEADLINE.ISCRIZIONESCADENZA', 'Deadline for registration at the library on:') . ' ' . date_format(date_create($patronData['cardExpire']), "d-m-Y");
                $deadline = true;
            }
            if ((!is_null($patronData['cardExpire'])) &&
                (strtotime($patronData['cardExpire']) < strtotime("now"))) {
                $contenuto .= ($deadline ? '<hr>' : '') . '<i class="fa fa-warning"></i> ' . _t('DEADLINE.ISCRIZIONESCADUTA', 'Entry to the library expired on:') . ' ' . date_format(date_create($patronData['cardExpire']), "d-m-Y");
                $deadline = true;
            }
        }

        if ($deadline) {
            return $contenuto;
        }
        return false;
    }

    /**
     * Show an error page with a custom http code using the Page template
     *
     * @param int $code
     * @param string $message
     * @param null $title
     * @return SS_HTTPResponse
     */
    public function htmlHttpError($code = 404, $message = '', $title = null)
    {
        if (!isset($title)) {
            $title = _t('ErrorPage.' . $code, $code);
        }
        $body = $this->customise(array(
            'Content' => $message,
            'Title' => $title
        ))->renderWith(array('Page'));

        return new SS_HTTPResponse($body, $code);
    }

    /**
     * Page-specific dev toolbar buttons
     *
     * @return array An array of DevToolbarButtons that will be added to the DevToolbar
     */
    public function extraDevToolbarButtons()
    {
        $buttons = array();

        if ($this->dataRecord->ID) {
            $buttons['librarian'][] = new StaticUrlToolbarLink('editPage', 'Edit', 'admin/show/' . $this->dataRecord->ID);
        }

        return $buttons;
    }

    /**
     * Strings to print in the footer
     * @return string
     */
    public function InFooter()
    {
        return implode("\n", static::$inFooter);
    }

    /**
     * Strings to print in the header
     * @return string
     */
    public function InHeader()
    {
        return implode("\n", static::$inHeader);
    }

    /**
     * @return array
     */
    public function getBodyClasses()
    {
        $classes = array(
            'pagetype-' . $this->dataRecord->ClassName,
            'user-' . (Member::currentUser() ? 'logged' : 'unlogged')
        );

        if ($this->getContainer()->getParameter('invert_cover_column'))
            $classes[] = 'inverted-columns';

        if (!$this->getContainer()->getParameter('fake_covers'))
            $classes[] = 'no-fake-covers';

        return $classes;
    }

    /*
     * @return string
     */

    public function BodyClassAttribute()
    {
        return implode(' ', $this->getBodyClasses());
    }

    /**
     * Convert a json-encodable $value to a json response with the right content-type
     *
     * @param mixed $value Any value digerible by json_encode
     *
     * @return SS_HTTPResponse
     */
    public function jsonResponse($value)
    {
        $response = new SS_HTTPResponse();
        $response->addHeader("Content-type", "application/json");
        $response->setBody(json_encode($value));

        return $response;
    }

}
