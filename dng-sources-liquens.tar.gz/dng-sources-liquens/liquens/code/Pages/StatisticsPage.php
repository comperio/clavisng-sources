<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

/**
 * This is a page whose content cannot be edited, but that it is rendererd with the ss
 * specified by the Template property
 */
class StatisticsPage extends Page
{
    public static $db = array(
        'Token' => 'Text',
    );
}

/**
 * The ReadOnlyPage Controller
 */
class StatisticsPage_Controller extends Page_Controller
{
    /**
     * @var Google_Client
     */
    private $client;

    /**
     * @var Google_AnalyticsService
     */
    private $service;

    /**
     * The google analytics profile ID
     * @var string
     */
    private $profileId;

    private $metrics = array(
        'visits',
        'visitors',
        'percentNewVisits',
        'avgTimeOnSite',
        'pageviews',
        'pageviewsPerVisit',
    );

    private $dimensions = array(
        'pageviewsPerVisit'
    );

    /**
     * @var array
     */
    static $allowed_actions = array(
        'index'
    );



    /**
     * The default page action
     */
    public function index()
    {
        $token= $this->Token;
        if ($token)
            $token = json_decode($token);
        $client = $this->getClient();

        if (isset($_GET['code'])) {
          $client->authenticate();
          $this->dataRecord->Token = $client->getAccessToken();
          $this->dataRecord->write();
          //$this->dataRecord->publish('Stage', 'Live');
          $redirect = 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['PHP_SELF'];
          header('Location: ' . filter_var($redirect, FILTER_SANITIZE_URL));
        }

        if ($this->dataRecord->Token) {
          $client->setAccessToken($this->dataRecord->Token);
        }

        return $this->renderWith(array('StatisticsPage', 'Page'));
    }

    /**
     * Statistics for the last 30 days
     *
     * @return DataObjectSet
     */
    public function getLast30DaysData()
    {
        $dateTo = new DateTime();
        $dateFrom = new DateTime();
        $dateFrom->modify('-1 month');

        $response = $this->getData(
            $dateFrom->format('Y-m-d'),
            $dateTo->format('Y-m-d'),
            $this->metrics
        );

        $data = $this->buildDataObjectSetFromGaData($response);

        return $data;
    }

    /**
     * Statistics for the last 30 days
     *
     * @return DataObjectSet
     */
    public function getLastYearData()
    {
        //End date: the last day of the previous month
        $dateTo = new DateTime();
        $dateTo->setDate($dateTo->format('Y'), $dateTo->format('m'), 1);
        $dateTo->modify('-1 day');

        //Start date: the first day of the same current month of the previous year
        $dateFrom = new DateTime();
        $dateFrom->modify('-1 year');
        $dateFrom->setDate($dateFrom->format('Y'), $dateFrom->format('m'), 1);

        $response = $this->getData(
            $dateFrom->format('Y-m-d'),
            $dateTo->format('Y-m-d'),
            $this->metrics,
            array('month')
        );
        $data = $this->buildDataObjectSetFromGaData($response);
        $this->orderBy($data, 'month', 'DESC', date('n')-1);

        return $data;
    }

    /**
     * Return the link to perform the oauth2 authentication
     *
     * @return bool|string
     */
    public function getConnectLink()
    {
        $client = $this->getClient();
        $member = Member::currentUser();

        if (!$client->getAccessToken()) {
          if ($member && ($member->isAdmin() || $member->isSitemaster()))
            return $client->createAuthUrl();
        }

        return false;
    }

    /**
     * Set Service
     *
     * @param Google_AnalyticsService $service
     *
     * @return StatisticsPage_Controller The current instance
     */
    public function setService($service)
    {
        $this->service = $service;
        return $this;
    }

    /**
     * Get Service
     *
     * @return Google_AnalyticsService
     */
    public function getService()
    {
        return $this->service;
    }

    /**
     * Set Client
     *
     * @param Google_Client $client
     *
     * @return StatisticsPage_Controller The current instance
     */
    public function setClient($client)
    {
        $this->client = $client;

        return $this;
    }

    /**
     * Get Client
     *
     * @return Google_Client
     */
    public function getClient()
    {
        return $this->client;
    }

    /**
     * Set ProfileId
     *
     * @param string $profileId
     *
     * @return StatisticsPage_Controller The current instance
     */
    public function setProfileId($profileId)
    {
        $this->profileId = $profileId;

        return $this;
    }

    /**
     * Get ProfileId
     *
     * @return string
     */
    public function getProfileId()
    {
        return $this->profileId;
    }

    /**
     * Get some analytics data
     *
     * @param string $startDate Get statistics after this day
     * @param string $endDate Get statistics before this day
     * @param $value A plain value or an arrau of values, withous the "ga:" perefix
     * @param array $dimensions An array of dimensions, without "ga:" prefix
     *
     * @return array|Google_GaData
     */
    private function getData($startDate, $endDate, $value, $dimensions = array())
    {
        if (!is_array($value))
            $value = array($value);

        // Add 'ga:' before value names
        $value = array_map(function($v) {
                return 'ga:' . $v;
        }, $value);

        // Add 'ga:' before dimensions
        $dimensions = array_map(function($v) {
                return 'ga:' . $v;
        }, $dimensions);

        $data = array();

        try {
            $data = $this->getService()->data_ga->get(
                'ga:' . $this->getProfileId(),
                $startDate,
                $endDate,
                implode(',', $value),
                array('dimensions' => implode(',', $dimensions))
            );
        } catch (Google_ServiceException $e) {
            $this->addMessage('Error', 'There was an API error : ' . $e->getCode() . ' : ' . $e->getMessage(), 'Google Analytics.');

        } catch (Exception $e) {
            $this->addMessage('Error', 'There was a general error: ' . $e->getCode() . ' : ' . $e->getMessage(), 'General Error.');
        }

        return $data;
    }

    /**
     * Build a DataObjectSet with the data returned by Analytics
     *
     * @param Google_GaData $data
     * @return \DataObjectSet
     */
    private function buildDataObjectSetFromGaData(Google_GaData $data)
    {
        /**
         * An header has this form:
         * (
         *    [dataType] => STRING
         *    [columnType] => DIMENSION
         *    [name] => ga:day
         *   )
         */
        $set = new DataObjectSet();

        if (!$data)
            return $set;
        
        $headers = $data->getColumnHeaders();

        // Remove ga:prefix and put it in label field
        // and flatten header
        foreach ($headers as $index => $header) {
            $headerAry = (array) $header;
            list($ga, $name) = explode(':', $headerAry['name']);
            $headerAry['label'] = $name;

            $headers[$index] = $headerAry;
        }

        foreach ($data->getRows() as $row) {
            $rowDataObject = new DataObject();
            $set->push($rowDataObject);

            foreach ($row as $key => $value) {
                $header = $headers[$key];
                $this->mapIntoRow($rowDataObject, $value, $header['label'], $header['dataType']);
            }
        }

        $totals = array();

        foreach ($data->totalsForAllResults as $key => $total) {
            list($ga, $name) = explode(':', $key);
            $float = new Float('');
            $float->setValue($total);
            $totals[$name] = $float;
        }

        $set->Total = new DataObject($totals);

        return $set;
    }

    /**
     * Map a value into a row
     *
     * @param DataObject $row
     * @param $value
     * @param $label
     * @param $type
     */
    private function mapIntoRow(DataObject $row, $value, $label, $type)
    {
        switch ($label) {
            case 'month':
                $row->month = $value;
                $date = new DateTime();
                $date->setDate(1983, $value, 1);
                $row->monthLabel = strftime('%B', $date->getTimestamp());
                break;
            default:
                $field = new Float('');
                $field->setValue($value);
                $row->setField($label, $field);
        }


    }

    /**
     * Order the dataobject set with the possibility to specify the start index.
     * If the $start parameter is specified, the list will start at $start index,
     * and then it will continue from the beginning when the end of the list is reached
     *
     * @param DataObjectSet $set
     * @param $field
     * @param string $direction
     * @param int $start
     */
    private function orderBy(DataObjectSet $set, $field, $direction = 'ASC', $start = 0)
    {
        $tot = $set->Count();
        $set->sort($field, 'ASC');

        foreach ($set as $index => $entry) {
            $entry->SortField = ($index - $start) >= 0 ? ($index - $start) : ($index - $start) + $tot;
        }

        $set->sort('SortField', $direction);
    }
}
