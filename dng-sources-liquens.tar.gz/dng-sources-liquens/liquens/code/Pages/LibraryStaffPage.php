<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

class LibraryStaffPage extends LibraryPage
{   
    public static $db = array(
        "ShowContacts" => "Boolean"
    );

    public static $defaults = array(
        "ShowContacts" => false
    );

    static $allowed_children = array ();
    static $can_be_root = false;

    function getCMSFields($params = NULL)
    {   
        $fields = parent::getCMSFields();

        $configurationTab = $fields->findOrMakeTab('Root.Configurazione');

        $configurationTab->push(new CheckboxField('ShowContacts', _t('LibraryStaffPage.SHOWCONTACTS')));

        return $fields;
    }

    /**
     * {@inheritdoc}
     */
    public function getPageTemplates()
    {
        $templates = parent::getPageTemplates();

        $templates[] = new StaffTemplate();

        return $templates;
    }
}

class LibraryStaffPage_Controller extends LibraryPage_Controller
{
    public static $allowed_actions = array();

    public $staff;

    public function init()
    {
        parent::init();
        
        $connector = $this->getContainer()->get('liquens.connector');

        $libraryId = $this->Level(2)->getLibrary()->getExternalID();
        // cache staff to avoid multiple queries
        $this->staff = $connector->getLibraryStaff($libraryId);
    }

    /**
     * Get the data of the staff librarians
     * @return DataObjectSet
     */
    public function libraryStaffRoles()
    {      
        //  Order staff by LastName
        usort($this->staff, function ($a, $b) {
            return strcmp($a["LastName"], $b["LastName"]);
        });
        $roleArray = array();
        foreach ($this->staff as $n => $staffData) {
            $staffMember = array();
            if (is_array($staffData)) {
                if (!in_array($staffData['RoleCode'], LQConfig::get('staff_roles_to_hide'))) {
                    $staffMember['FirstName'] = Convert::raw2att($staffData['FirstName']);
                    $staffMember['LastName'] = Convert::raw2att($staffData['LastName']);
                    $staffMember['DisplayedName'] = $staffMember['FirstName'] . ' ' . $staffMember['LastName'];
                    $staffMember['AvatarUrl'] = Convert::raw2att($staffData['PhotoURL']);
                    $staffMember['isLibrarian'] = true;
                    $staffMember['Phone'] = Convert::raw2att($staffData['Phone']);
                    $staffMember['Email'] = Convert::raw2att($staffData['Email']);
                    $staffMember['Bio'] = Convert::html2raw($staffData['Bio']);
                    $staffMember['RoleLabel'] = Convert::raw2att($staffData['RoleLabel']);
                    if (!array_key_exists($staffData['RoleCode'], $roleArray))
                        $roleArray[$staffData['RoleCode']] = new LibrarianRole($staffData['RoleLabel']);
                    $roleArray[$staffData['RoleCode']]->addPerson($staffMember);
                }
            }
        }
        ksort($roleArray);
        unset($roleArray['0']); // hide role '0' - notice: string, not index
        $doStaffRoles = new DataObjectSet();
        foreach ($roleArray as $role => $librarianRole)
            $doStaffRoles->push($librarianRole);
        return $doStaffRoles;
    }
}

class LibrarianRole extends DataObjectSet
{
    public $RoleID;

    private $_staff;

    public function __construct($RoleID = null)
    {
        $this->_staff = new DataObjectSet();
        if ($RoleID)
            $this->RoleID = $RoleID;
    }

    public function getStaffMembers()
    {
        return $this->_staff;
    }

    public function setStaffMembers(array $staff)
    {
        foreach ($staff as $person)
            $this->addPerson($person);
    }

    public function addPerson($person)
    {
        if ($person instanceof ArrayData)
            $this->_staff->push($person);
        else if (is_array($person))
            $this->_staff->push(new ArrayData($person));
    }
}