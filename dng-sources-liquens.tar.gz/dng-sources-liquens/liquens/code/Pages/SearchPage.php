<?php

/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Isacco Occhiali <isacco@comperio.it>
 */
require_once("Zend/XmlRpc/Client.php");
require_once("Zend/Date.php");

/**
 *
 */
class SearchPage extends Page {

    /**
     * @var array
     */
    static $db = array(
        'HasFrontPage' => 'Boolean',
        'DisplaySearchBoxInResults' => 'Boolean',
        'MainSearchField' => 'Text',
        'ForceAndQuery' => 'Text',
        'FacetsFields' => 'Text',
        'SortFields' => 'Text',
        'DefaultViewType' => "Enum('lst,grid,dtl','lst')",
        'AdvancedSearchFieldTypes' => 'Text',
        'AdvancedSearchOpenedFields' => 'Text',
        'AdvancedSearchSS' => 'Text',
        'EnableExternalSearch' => 'Boolean',
        'ExternalSearchDesc' => 'Text',
        'FederatedSearchDesc' => 'Text',
        'EnableFacetFederatedSearch' => 'Boolean',
        'EnableExternalSearchesWidget' => 'Boolean',
        'AdvancedSearchText' => 'HTMLText'
    );

    /**
     * @var array
     */
    static $has_one = array(
        'Image' => 'Image',
        'ExternalSearchesArea' => 'WidgetArea',
        'ExternalSearchesAreaWidget' => 'WidgetArea'
    );

    /**
     * @var array
     */
    static $defaults = array(
        'MainSearchField' => 'q',
        'HasFrontPage' => false,
        'DisplaySearchBoxInResults' => false,
        'EnableExternalSearch' => false,
        'EnableExternalSearchesWidget' => false,
        'EnableFacetFederatedSearch' => false
    );

    /**
     * @var array
     */
    static $many_many = array(
        'AlternativeSearchPages' => 'SearchPage',
        'FederatedSearchPages' => 'SearchPage',
    );

    /**
     * @var array
     */
    static $belongs_many_many = array(
        'AlternativeFor' => 'SearchPage',
    );

    /**
     * @var array
     */
    static $allowed_children = array(
        'none' => 'none'
    );

    /**
     * @static
     * @return string
     */
    public static function getDefaultSearchPageUrl() {
        return Director::absoluteBaseURL() . 'opac/search';
    }

    /**
     * @param int|null $id
     * @return ManifestationPage
     */
    public function getManifestationPage($id = null) {
        $manifestationPage = new ManifestationPage();
        $manifestationPage->ManifestationID = $id;
        $manifestationPage->SearchPage = $this;
        $manifestationPage->setParent($this);

        return $manifestationPage;
    }

    /**
     * Return the default sort field for this search page
     * @return string
     */
    public function getDefaultSortField() {
        return LQConfig::get('defaultSortField');
    }

    /**
     * @return FieldSet
     */
    function getCMSFields($params = NULL)
    {
        $fields = parent::getCMSFields();

        foreach ($this->getContainer()->getParameter('lq.fields') as $fieldName => $fieldConf) {
            $searchFields[$fieldName] = _t('LQFields.' . strtoupper($fieldName), $fieldConf['label']) . " ($fieldName)";
        }

        asort($searchFields);

        $fields->addFieldToTab(
                _t('SearchPage.SEARCHTAB', 'Root.Content.Search'), new LiteralField('SearchTabNote', '<p>' . _t('SearchPage.SEARCHPAGE_CONFIG_DESC') . '</p>'
                )
        );

        $searchFields = array('q' => 'Default (' . _t('LQFields.Q') . ')') + $searchFields;

        $fields->addFieldToTab(
                _t('SearchPage.SEARCHTAB', 'Root.Content.Search'), new DropdownField('MainSearchField', _t(
                        'SearchPage.MAINSEARCHFIELD'), $searchFields
                )
        );
        $fields->addFieldToTab(
                _t('SearchPage.SEARCHTAB', 'Root.Content.Search'), new TextField('ForceAndQuery', _t(
                        'SearchPage.FORCEANDQUERY'
                ))
        );

        $list = join("&#13", LQConfig::get('default_facets'));
        $fields->addFieldToTab(
                _t('SearchPage.SEARCHTAB', 'Root.Content.Search'), new TextField('FacetsFields', _t('SearchPage.SOLRFACETS') . '. Passa il mouse <a title="' . $list . '">qui</a> per vedere la lista dei facets disponibili.'
                )
        );

        $list = join("&#13", LQConfig::get('default_sorting_fields'));
        $fields->addFieldToTab(
                _t('SearchPage.SEARCHTAB', 'Root.Content.Search'), new TextField('SortFields', _t('SearchPage.SOLRSORT') . '. Passa il mouse <a title="' . $list . '">qui</a> per vedere la lista dei campi disponibili.'
                )
        );

        $fields->addFieldToTab(
                _t('SearchPage.SEARCHTAB', 'Root.Content.Search'), new CheckboxField('HasFrontPage', _t(
                        'SearchPage.HASFRONTPAGE'
                ))
        );

        $fields->addFieldToTab(
                _t('SearchPage.SEARCHTAB', 'Root.Content.Search'), new CheckboxField('DisplaySearchBoxInResults', _t(
                        'SearchPage.DISPLAYSEARCHBOX'
                ))
        );

        $fields->addFieldToTab(
                _t('SearchPage.SEARCHTAB', 'Root.Content.Search'), new LiteralField('AdvStart', '<div class="searchpage_config_options"><h5>' . _t('SearchPage.ADVSEARCH_CMS_TITLE') . '</h5><p>' . _t('SearchPage.ADVSEARCH_CMS_DESC') . '</p>'
                )
        );

        $fields->addFieldToTab(
                _t('SearchPage.SEARCHTAB', 'Root.Content.Search'), new TextField('AdvancedSearchSS', _t(
                        'SearchPage.ADVSEARCHSS'
                ))
        );

        $list = join("&#13", LQConfig::get('default_advsearch_fields'));
        $fields->addFieldToTab(
                _t('SearchPage.SEARCHTAB', 'Root.Content.Search'), new TextField('AdvancedSearchFieldTypes', _t('SearchPage.ADVSEARCHFIELDTYPES') . '. Passa il mouse <a title="' . $list . '">qui</a> per vedere la lista dei campi disponibili.')
        );

        $list = join("&#13", LQConfig::get('default_advsearch_opened_fields'));
        $fields->addFieldToTab(
                _t('SearchPage.SEARCHTAB', 'Root.Content.Search'), new TextField('AdvancedSearchOpenedFields', _t('SearchPage.ADVSEARCHOPENEDFIELDS') . '. Passa il mouse <a title="' . $list . '">qui</a> per vedere la lista dei campi disponibili.')
        );

        $fields->addFieldToTab(
                _t('SearchPage.SEARCHTAB', 'Root.Content.Search'), new LiteralField('AdvEnd', '</div>')
        );


        //AlternativeSearchPages
        $fields->addFieldToTab(
                _t('SearchPage.SEARCHTAB', 'Root.Content.Search'), new LiteralField('AlternativeStart', '<div class="searchpage_config_options"><h5>' . _t('SearchPage.ALTERNATIVE_SEARCHES_CMS_TITLE') . '</h5><p>' . _t('SearchPage.ALTERNATIVE_SEARCHES_CMS_DESC') . '</p>'
                )
        );

        $fields->addFieldToTab(
                _t('SearchPage.SEARCHTAB', 'Root.Content.Search'), new ManyManyComplexTableField(
                $this, 'AlternativeSearchPages', 'SearchPage', null, null, "SearchPage.ID != {$this->ID}"
                )
        );

        $fields->addFieldToTab(
                _t('SearchPage.SEARCHTAB', 'Root.Content.Search'), new LiteralField('AlternativeEnd', '</div>')
        );


        //FederatedSearchPages
        $fields->addFieldToTab(
                _t('SearchPage.SEARCHTAB', 'Root.Content.Search'), new LiteralField('FederatedStart', ''
                . '<div class="searchpage_config_options">'
                . '<h5>Ricerca combinata in più Sistemi Bibliotecari</h5>'
                . '<p>Formato richiesto per utilizzare più motori di ricerca SOLR è: <strong>etichetta#solr_url#dng_url#solr_db#collection</strong><br />I motori vanno inseriti uno per ogni riga</p>'
                )
        );

        $fields->addFieldToTab(
                _t('SearchPage.SEARCHTAB', 'Root.Content.Search'), new TextareaField('FederatedSearchDesc', 'Motori di ricerca SOLR.', 15)
        );

        $fields->addFieldToTab(
                _t('SearchPage.SEARCHTAB', 'Root.Content.Search'), new CheckboxField('EnableFacetFederatedSearch', 'Mostra facet relativo ai Sistemi Bibliotecari')
        );


        $fields->addFieldToTab(
                _t('SearchPage.SEARCHTAB', 'Root.Content.Search'), new LiteralField('FederatedEnd', '</div>')
        );

        $fields->addFieldToTab(_t('SearchPage.EXTERNALADVANCEDSEARCHTAB', 'Root.Content.AdvancedSearch'), new HtmlEditorField("AdvancedSearchText", "Testo informativo ricerca avanzata"));


        $fields->addFieldToTab(
                _t('SearchPage.EXTERNALSEARCHTAB', 'Root.Content.ExternalSearch'), new LiteralField('ExternalSearchTabNote', '<p>' . _t('SearchPage.EXTERNALSEARCHTABDESC') . '</p>'
                )
        );

        $fields->addFieldToTab(
                _t('SearchPage.EXTERNALSEARCHTAB', 'Root.Content.ExternalSearch'), new CheckboxField('EnableExternalSearch', _t(
                        'SearchPage.ENABLEEXTERNALSEARCH'
                ))
        );

        $fields->addFieldToTab(
                _t('SearchPage.EXTERNALSEARCHTAB', 'Root.Content.ExternalSearch'), new TextField('ExternalSearchDesc', _t(
                        'SearchPage.EXTERNALSEARCHDESC'
                ))
        );

        $fields->addFieldToTab(
                "Root.Content.Banner", new ImageField('Image', 'Banner', Null, Null, Null, 'Uploads/search_images')
        );

        $fields->addFieldToTab(
                'Root.Content.WidgetsRicercheEsterne', new CheckboxField('EnableExternalSearchesWidget', "Attiva i widget di ricerca")
        );

        $fields->addFieldToTab(
                'Root.Content.WidgetsRicercheEsterne', new TypedWidgetAreaEditor('ExternalSearchesAreaWidget', array('ExternalSearchWidget'))
        );
        return $fields;
    }

    /**
     * @return SearchBox
     */
    public function getSearchBoxWidget() {
        $widget = new SearchBox();
        $widget->SearchPageID = $this->ID;
        $widget->ShowTitle = false;
        $widget->ShowImage = false;

        if (isset($_GET['q'])) {
            $widget->SearchText = filter_var($_GET['q'], FILTER_SANITIZE_STRING);
        }

        return $widget->renderWith(array('DngWidgetHolder'));
    }

    /**
     * Returns the sum of the results of external searches
     *
     * @return int|mixed
     */
    public function getTotalExternalSearchesResults() {
        $widgetControllers = $this->ExternalSearchesArea()->WidgetControllers();
        $total = 0;
        /** @var $widgetController Widget_Controller */
        foreach ($widgetControllers as $widgetController) {
            $widget = $widgetController->getWidget();
            $data = $widget->Data();
            $total += $widgetController->getWidget()->Data()->getField('Total');
        }

        return $total;
    }

    public function getTotalExternalSearchesWidgetResults() {
        $widgetControllers = $this->ExternalSearchesAreaWidget()->WidgetControllers();
        $total = 0;
        /** @var $widgetController Widget_Controller */
        foreach ($widgetControllers as $widgetController) {
            $widget = $widgetController->getWidget();
            $data = $widget->Data();
            $total += $widgetController->getWidget()->Data()->getField('Total');
        }
        return $total;
    }

    /**
     * @return bool
     */
    public function hasUndefinedTotalResults() {
        return false;
    }

    /**
     * @return bool
     */
    public function isSortable() {
        return true;
    }

    /**
     * @return mixed
     */
    public function MainSearchField() {
        return $this->MainSearchField ?: static::$defaults['MainSearchField'];
    }

    /**
     * The available sorting fields for this search page.
     */
    public function SortFields() {
        if ($this->SortFields) {
            return explode(',', $this->SortFields);
        }

        return $this->getContainer()->getParameter('lq.default_sorting_fields');
    }

    public function onBeforeWrite() {
        parent::onBeforeWrite();
        
        if ($this->owner->AdvancedSearchText == "")
            $this->owner->AdvancedSearchText = "<h4>Istruzioni</h4>
                <p>Da questa pagina puoi costruire una ricerca complessa, utilizzando diversi campi a tua disposizione. Seleziona un campo di ricerca
                dalla tendina '<em>Tipo di campo</em>', quindi inserisci o seleziona il testo da ricercare nel box accanto alla tendina. 
                Per alcuni campi di ricerca (ad es. Autore, Classe, Soggetto), iniziando a scrivere il testo da ricercare potrebbe comparire
                una tendina di autocompletamento, da cui puoi selezionare una delle voci presenti nel catalogo.</p>
                <p>Puoi rimuovere o aggiungere un qualsiasi campo di ricerca, che può essere usato più volte e collegato agli altri tramite <em>operatori
                booleani</em>. Scegliendo l'operatore <em>AND</em>, i risultati della ricerca mostreranno documenti del catalogo che contengono tutti i valori inseriti;
                 scegliendo l'operatore <em>OR</em>, sarà sufficiente che i documenti contengano almeno uno dei valori inseriti; con l'operatore <em>NOT</em>
                verranno esclusi dai risultati tutti i documenti che contengono quel valore.
                È possibile costruire ricerche complesse aggiungendo gruppi di campi al cui interno utilizzare diversi operatori booleani. I gruppi
                sono legati tra loro tramite l'operatore AND, ovvero i risultati dovranno rispettare tutte le condizioni di ricerca inserite.</p>
                <p>Prima di compiere la ricerca cliccando il pulsante 'Cerca', puoi scegliere come dovranno essere ordinati i risultati ottenuti e 
                quanti documenti mostrare per pagina.</p>";
    }

    public function onAfterWrite() {

        global $sc;
        $key = $sc->getParameter('lq.solrDatabase') . "_shards";

        /* Dopo il salvataggio, cancella APC in modo da poterla rigenerare */
        if (apc_exists($key)) {
            apc_delete($key);
        }
        if (DB::query("SELECT count(FederatedSearchDesc) FROM SearchPage WHERE FederatedSearchDesc IS NOT NULL")->value() > 0) {
            /* Estrae le stringhe relativi ai motori di ricerca e salva il risultato in APC */
            $sqlQuery = new SQLQuery();
            $sqlQuery->select = array('FederatedSearchDesc AS se');
            $sqlQuery->from = array("SearchPage");
            $sqlQuery->where = array("FederatedSearchDesc IS NOT NULL");
            $result = $sqlQuery->execute();
            $allShards = '';
            foreach ($result as $row) {
                $allShards .= $row['se'] . "|";
            }
            apc_store($key, serialize(explode("|", str_replace("\n", "|", substr($allShards, 0, -1)))));
        }
        
        parent::onAfterWrite();
    }

}

/**
 *
 */
class SearchPage_Controller extends Page_Controller {

    /**
     * @var string
     */
    public $action_advanced_search = 'advanced';

    /**
     * @var string
     */
    public $defaultView = 'lst';

    /**
     * @var array
     */
    static $allowed_actions = array(
        'index',
        'search',
        'detail',
        'advancedsearch',
        'reserve',
        'facetsnav',
        'authoritynav',
        'autosuggest',
        'advancedform',
        'info',
        'toManifestationController',
        'lightSearch',
        'iframeSearch',
        'subfieldsMap',
        'nthResult',
        'externalSearches',
        'externalSearchesWidgets',
        'MLOLframe'
    );

    /**
     * @var array
     */
    public $allowedOperators = array(
        'and' => 'tutti (AND)', 'or' => 'almeno uno (OR)', 'not' => 'nessuno (NOT)'
    );

    /**
     * @var SolrFacetsManager
     */
    protected $facetsManager;

    /**
     * @var SolrSearcher
     */
    protected $solrSearcher;

    /**
     * @var SolrResponse
     */
    public $result;

    /**
     * @var LqAdvancedSearchForm
     */
    public $advancedSearchForm;

    /**
     * Store manifestations data returned by the Liquens Connector
     * @var array
     */
    public $manifestationsInfos = array();

    /**
     * @var array
     */
    public static $url_handlers = array(
        'light' => 'lightSearch',
        'info/$SearchType' => 'info',
        'extsearches' => 'externalSearches',
        'extsearcheswidget' => 'externalSearchesWidgets',
        'search/$ViewType/facetsnav' => 'facetsnav',
        'search/authoritynav' => 'authoritynav',
        'advanced/$ViewType/facetsnav' => 'facetsnav',
        'search/$ViewType' => 'search',
        'advanced/$ViewType' => 'search',
        'detail' => 'toManifestationController',
        'subfieldsMap/$FieldName!' => 'subfieldsMap',
        'nth/$Position' => 'nthResult',
        'MLOLframe' => 'MLOLframe'
    );

    /**
     * @var ManifestationRepository
     */
    private $manifestationRepository;
    private $titleForAuthority;
    private $fullAuthority;

    /**
     *
     * @var type AuthorityRepository
     */
    private $authorityRepository;

    /**
     * @var ManifestationRepository Used in the light action
     */
    private $essentialManifestationRepository;

    /**
     * @var array An hash of SolrQueryMapper objects
     */
    private $solrQueryMappers = array();

    /**
     * @var array
     */
    private $defaultAdvsearchFields = array();

    /**
     * The array of fields opened when the advanced search is loaded
     *
     * @var array
     */
    private $defaultAdvsearchOpenedFields = array();

    /**
     * @var int
     */
    private $defaultResultsPerPage;

    /**
     * @var array
     */
    private $resultsPerPageChoices;

    /**
     * Index Action. If the SearchPage has HasFrontPage setted to true, show only the page content
     * rendered through SearchPage_noresults.ss. Use search action otherwise.
     *
     * @param SS_HTTPRequest $request
     * @return page|string
     */
    public function index(SS_HTTPRequest $request) {
        if ($this->HasFrontPage)
            return $this->renderWith(array('SearchPage_noresults', 'SearchPage_search', 'Page'));

        return $this->search($request);
    }

    /**
     * Delegation to ManifestationController
     *
     * @param \SS_HTTPRequest $request
     * @return array|RequestHandler|SS_HTTPResponse|string
     */
    public function toManifestationController(SS_HTTPRequest $request) {
        $manPage = $this->getManifestationPage($this->request->param('ManifestationID'));
        /** @var ManifestationPage_Controller $controller  */
        $controller = ModelAsController::controller_for($manPage);
        $controller->init();
        $controller->page = $manPage;
        $controller->searchPageController = $this;

        Director::set_current_page($manPage);
        $response = $controller->handleRequest($request);
        Director::set_current_page(null);

        return $response;
    }

    /**
     * @return SS_HTTPResponse|void
     */
    public function init() {
        parent::init();
        // Tell web crawlers to stay away
        Requirements::insertHeadTags('<meta name="robots" content="noindex, nofollow" />');

        //set some translations
        $this->i18nToJs(array(
            'Profile.CREATESHELF' => 'Create shelf',
            'Profile.CLOSEDIALOG' => 'Close',
            'Profile.SAVESEARCH' => 'Save search',
            'Profile.CHOOSEASHELFFAULT' => 'Please choose a shelf to continue',
            'Profile.SHELFADD_SUCCESS' => 'Shelf successfully created',
            'Profile.SHELFADD_ERROR' => 'The shelf has not been created',
            'Profile.SEARCHADD_SUCCESS' => 'Search successfully saved',
            'Profile.SEARCHADD_ERROR' => 'The search has not been saved',
        ));

        //set the locale antisegment for images
        $this->toJavascript('localeAntisegment', $this->getLocaleAntisegment());
        $this->getSolrQueryMapper()
                ->loadQuery($_SERVER['QUERY_STRING'])
                ->removeField('url') //remove ss url parameter
        ;

        //Creazione del FacetManager
        if ($this->FacetsFields) {
            $this->facetsManager->includeOnly = explode(',', $this->FacetsFields);
        } else {
            $this->facetsManager->includeOnly = LQConfig::get('default_facets');
        }

        if ($this->EnableFacetFederatedSearch == 1) {
            array_unshift($this->facetsManager->includeOnly, "database");
            unset($this->facetsManager->includeOnly[array_search("faceti_libvisi", $this->facetsManager->includeOnly)]);
        }
    }

    /**
     * Return "simple" if the search was a simple one, "advanced" if it was
     * an advanced search
     *
     * @return string
     */
    public function getSearchMappingType() {
        $srcAction = strtolower($this->getRequest()->param('Action'));
        //for info action, the src actions is in SearchType param
        if ('info' === $srcAction) {
            $srcAction = $this->getRequest()->param('ID');
        }

        if (in_array($srcAction, array('advanced', 'advancedform'))) {
            return 'advanced';
        } else {
            return 'simple';
        }
    }

    /**
     * Returns a properly filled SolrQuery Object
     *
     * @param bool $getFacets
     * @return SolrQuery
     */
    public function getSolrQueryObject($getFacets = true, $type = null) {
        global $sc;

        if (!is_null($type))
            $query = $this->getSolrQueryMapper($type)->loadQuery($this->request)->removeField('url')->getQuery();
        else
            $query = $this->getSolrQueryMapper()->getQuery();

        if ($getFacets && !isset($_GET['nofacets'])) {
            $query = $this->facetsManager->getQuery($query);
        }

        $query->setRawField('start', $this->StartPos() - 1)
                ->setRawField('rows', $this->PageSize())
                ->setRawField('sort', $this->getCurrentSortingRule())
                ->addFilterQuery(LQConfig::get('global_search_filter'));

        if (!$this->getSearchText("shards")) {
            /* Gestione ricerca con SHARD */
            if (!is_null($this->FederatedSearchDesc)) {
                $hash = "shardCore_" . md5($this->FederatedSearchDesc);
                if (!apc_exists($hash)) {
                    $solrs = explode(PHP_EOL, $this->FederatedSearchDesc);
                    foreach ($solrs as $key => $solr) {
                        if ($solr != '') {
                            $engines[$key] = explode("#", $solr)[1];
                        }
                    }
                    /* Aggiunto stringa shard in APC */
                    apc_store($hash, serialize($engines));
                }
                $query->setRawField('shards', implode(",", unserialize(apc_fetch($hash))));
                /* Rinnovo lista shard in APC */
                $key = $sc->getParameter('lq.solrDatabase') . "_shards";
                if (!apc_exists($key)) {
                    SearchPage::onAfterWrite();
                }
            }
        } else {
            if ($this->getSearchText("shards") == $sc->getParameter('lq.solrDatabase')) {
                $query->setRawField('shards', $sc->getParameter('lq.baseURL'));
            }
        }

        if ($this->ForceAndQuery)
            $query->addFilterQuery($this->ForceAndQuery);

        return $query;
    }

    /**
     * Get urlencoded querystring
     *
     * @return string
     */
    public function getSearchQueryString() {
        return urlencode($this->getSolrQueryMapper()->getQueryString(false));
    }

    /**
     * Get querystring
     *
     * @return string
     */
    public function getUnencodedSearchQueryString() {
        return $this->getSolrQueryMapper()->getQueryString(false);
    }

    /**
     * Get the list of bibliographic records
     * by a Solr request
     *
     * @return page rendering
     */
    public function search() {
        $data = $this->getResults();
        return $this->customise($data)->renderWith(array('SearchPage_search', 'Page'));
    }

    /**
     * Performs a search using as few resources as possible
     *
     * @return string
     */
    public function lightSearch() {
        $data = $this->getLightResults();
        return $this->customise($data)->renderWith(array('SearchPage_light', 'Page'));
    }

    /**
     * Performs a search using as few resources as possible
     *
     * @return string
     */
    public function iframeSearch() {
        $data = $this->getResults();
        return $this->customise($data)->renderWith(array('IFramedPage', 'ResultPage', 'Page'));
    }

    /**
     * @param SS_HTTPRequest $request
     * @return mixed
     */
    public function externalSearches(SS_HTTPRequest $request) {
        return $this->renderWith('ExternalSearches');
    }

    public function externalSearchesWidgets(SS_HTTPRequest $request) {
        return $this->ExternalSearchesAreaWidget()->renderWith('ExternalSearchesWidgets');
    }

    /**
     * @param SS_HTTPRequest $request
     * @return mixed
     */
    public function MLOLframe() {
        return $this->renderWith(array('MLOLframe', 'Page'));
    }

    /**
     * Main search text
     * @return bool
     */
    public function getSearchText($base = 'q') {
        return $this->getRequest()->getVar($base) ?: false;
    }
    
    public function getExtSearchtext($base = 'q') {
        return htmlentities($this->getRequest()->getVar($base)) ?: false;
    }

    /**
     * Perform the Solr Search and build the Manifestations objects using the Solr Response
     *
     * @return array
     */
    public function getResults() {
        $query = $this->getSolrQueryObject();
        $repo = $this->getManifestationRepository();
        $manifestations = $repo->getBySolrQuery($query);
        $this->result = $repo->getLastSolrResponse();
        $doFacetsSet = $this->buildFacetsLists(
                $this->result->getFacetFieldsCounts()
        );
        //Costruisco dataobjectset per activefilters
        $data = array(
            'Manifestations' => $manifestations,
            'Facets' => $doFacetsSet,
        );

        return $data;
    }
    
    /**
     * Ricerca modificata per risultati JSON
     * 
     * @param type $type
     * @return type
     */
    public function getResultsForJson($request, $type = 'simple') {
        $this->request = $request;
        $query = $this->getSolrQueryObject(false, $type);
        $query->setRawField('q',$this->getSearchText());
        $repo = $this->getManifestationRepository();
        $manifestations = $repo->getBySolrQuery($query);
        $this->result = $repo->getLastSolrResponse();
        $data = array('Manifestations' => $manifestations);
        return $data;
    }

    /**
     * Perform the Solr Search and build the Manifestations objects using the Solr Response.
     * Do not request facets and use most efficient drivers to build the manifestations.
     *
     * @return array
     */
    public function getLightResults() {
        $query = $this->getSolrQueryObject(false);
        $manifestations = $this->getEssentialManifestationRepository()->getBySolrQuery($query);

        $this->result = $this->getEssentialManifestationRepository()->getLastSolrResponse();

        //Costruisco dataobjectset per activefilters
        $data = array(
            'Manifestations' => $manifestations,
        );

        return $data;
    }

    /**
     * Redirecto to the detail page of the nth search result
     *
     * @param SS_HTTPRequest $request
     */
    public function nthResult(SS_HTTPRequest $request) {
        $position = $request->param('Position') ?: 1;
        $query = $this->getSolrQueryObject(false)->setRawField('start', $position - 1);
        $result = $this->getSolrSearcher()->search($query)->getDoc();
        $manUrl = $this->Link('detail/view/' . $result['id']);
        $this->redirect($manUrl);
    }

    /**
     * @return int
     */
    public function getNumFound() {
        return $this->result->getNumFound();
    }

    /**
     * @return DataObjectSet
     */
    public function getActiveFilters() {
        $filters = new SensitiveSearchFilters(
                new MapperSearchFilters($this->getSolrQueryMapper(), $this->getActiveFiltersUrlPrefix()));
        return $filters->getFilters();
    }

    /**
     * Dati i facets richiesti a solr, restituisce la lista dei facets da
     * visualizzare.
     * @param null|array $facets
     * @return void
     */
    public function buildFacetsLists($facets = null) {
        global $sc;

        $doFacetsSet = new DataObjectSet();
        $facetsManager = $this->getFacetsManager();

        //Costruzione delle liste dei facets
        if (isset($facets)) {
            $filteredFacets = $facetsManager->mergeAndOrderFacets(
                    array(
                        'facet_fields' => $this->result->getFacetFieldsCounts(),
                        'facet_queries' => $this->result->getFacetQueriesCounts()
                    )
            );

            $facetsListPageBaseUrl = $this->getFacetsListBaseUrl();
            $searchQs = $this->getSolrQueryMapper()->getQueryString(true);
            $currSearchUrl = $this->getSearchBaseUrl();
            foreach ($filteredFacets as $fct
            => $list) {

                $list = $sc->get('transformation.hide_facets')->transform($list);

                if (count($list) > 0) {
                    $facetListLink = $facetsManager->getOption('limit', $fct) > count($list) ?
                            '' : $facetsManager->getFacetsListLink(
                                    $fct, $searchQs, -1, $facetsListPageBaseUrl
                    );

                    $labelCustomization = LQConfig::get('facetsChangeName');
                    if ((!is_null($labelCustomization)) && (array_key_exists($fct, $labelCustomization))) {
                        $locale = i18n::get_locale();
                        $customLabel = $labelCustomization[$fct][$locale];
                    } else {
                        $customLabel = $facetsManager->getLabel($fct);
                    }

                    $facetData = array(
                        "Label" => $customLabel,
                        "SolrField" => $fct,
                        "Field" => $fct,
                        "FacetListLink" => htmlspecialchars($facetListLink),
                        "ListClass" => $facetsManager->configuration[$fct]['field'],
                        "List" => new DataObjectSet(),
                        "IsMultiselect" => $facetsManager->hasOption('multiselect', $fct),
                        "IsUnique" => $facetsManager->hasOption('unique', $fct),
                    );
                    $facetData['List'] = $this->buildFacetFiltersList(
                            $fct, $list, $currSearchUrl
                    );

                    $doFacetsSet->push(new ArrayData($facetData));
                }
            }
        }

        return $doFacetsSet;
    }

    /**
     * Dato un array del tipo $list = array(
     *  'facetValue1' => numFound1,
     *  'facetValue2'=> numFound2,
     *  ... )
     * costruisce la lista dei link ai corrispondenti raffinamenti di ricerca.
     * @param string $facetName
     * @param array $list
     * @param string $currSearchUrl
     * @return DataObjectSet
     */
    public function buildFacetFiltersList($facetName, array $list, $currSearchUrl = '/') {
        $facetsManager = $this->getFacetsManager();
        $filtersList = new DataObjectSet();

        $fieldName = $facetsManager->getOption('field', $facetName);
        $field = $this->getSolrQueryMapper()->getFieldsCollection()->getField($fieldName);

        foreach ($list as $realValue => $count) {
            //Verifico se il filtro facet in questione è attivo
            $isActive = false;
            if ($this->getSolrQueryMapper()->hasValue(
                            $facetsManager->getOption('field', $facetName), $realValue
                    )
            ) {
                $isActive = true;
            }

            //Non voglio che si veda il facet corrente per facets non multiselect
            if (!$isActive || $facetsManager->hasOption('multiselect', $facetName)) {
                $fItem = array(
                    "Facet" => $facetName,
                    "RealValue" => $realValue,
                    "LinkTo" => $facetsManager->getFacetFilterLink(
                            $this->getSolrQueryMapper(), $facetName, $realValue, 0, $currSearchUrl, 'AND'
                    ),
                    "ExcludeLink" => $facetsManager->getFacetFilterLink(
                            $this->getSolrQueryMapper(), $facetName, $realValue, 0, $currSearchUrl, 'NOT'
                    ),
                    "DisplayValue" => $field->setValue($realValue)->getDisplayedValue() != '' ? $field->setValue($realValue)->getDisplayedValue() : 'Non definito',
                    "Count" => $count,
                    "IsActive" => $isActive,
                );
                $filtersList->push(new ArrayData($fItem));
            }
        }

        //Riordino i facets multiselect in ordine alfabetico
        if ($facetsManager->hasOption('unique', $facetName)) {
            $filtersList->sort('DisplayValue');
        }

        if ($facetsManager->hasOption('multiselect', $facetName)) {
            //Rimuovo tutti i filtri per lo stesso facet per costruire il
            //link per l'elemento "Tutti"
            $clMapper = clone($this->getSolrQueryMapper());
            $clMapper->removeField($facetsManager->getOption('field', $facetName));

            //Aggiungo l'elemento "Tutti"
            $allItem = array(
                "Facet" => $facetName,
                'RealValue' => '',
                "LinkTo" => $currSearchUrl . '?' . $clMapper->getQueryString(),
                "DisplayValue" => 'Qualsiasi',
                "IsActive" => !$this->getSolrQueryMapper()->hasField($facetsManager->getOption('field', $facetName))
            );
            $filtersList->insertFirst(new ArrayData($allItem));
        }
        return $filtersList;
    }

    /**
     * Search advanced action.
     * Rendered with AdvancedSearch.ss
     *
     * @return page rendering
     */
    public function advancedsearch() {
        if ($this->AdvancedSearchFieldTypes) {
            $fieldTypes = explode(',', $this->AdvancedSearchFieldTypes);
        } else {
            $fieldTypes = $this->getDefaultAdvsearchFields();
        }

        if ($this->AdvancedSearchOpenedFields) {
            $openedFields = explode(',', $this->AdvancedSearchOpenedFields);
        } else {
            $openedFields = $this->getDefaultAdvsearchOpenedFields();
        }

        $this->advancedSearchForm = new LqAdvancedSearchForm(
                $this->getSolrFieldsConfiguration(), $fieldTypes, $this->allowedOperators);

        $this->advancedSearchForm->loadAvaiableFacets(
                $this->getSolrSearcher(), $this->getFacetsManager()->configuration);

        $this->advancedSearchForm->defaultFields = array(
            array('fieldName' => 'q', 'value' => ''),
        );

        $this->advancedSearchForm->defaultFields = array_map(function($field) {
            return array('fieldName' => $field, 'value' => '');
        }, $openedFields);

        return $this->renderWith(
                        array($this->AdvancedSearchSS ?: 'AdvancedSearch', 'Page')
        );
    }

    /**
     * @param bool $startFieldIndx
     * @param bool $startGrpIndx
     * @return LqAdvancedSearchForm
     * @throws Exception
     */
    public function AdvancedSearchForm($startFieldIndx = false, $startGrpIndx = false) {
        if (!is_a($this->advancedSearchForm, 'LqAdvancedSearchForm'))
            throw new Exception('AdvancedSearchForm must be an LqAdvancedSearchForm object');

        if ($startFieldIndx)
            $this->advancedSearchForm->startFieldIndx = (int) $startFieldIndx;

        if ($startGrpIndx)
            $this->advancedSearchForm->startGrpIndx = (int) $startGrpIndx;

        Requirements::customScript('var advSearchData = ' . $this->advancedSearchForm->JS() . ';');

        return $this->advancedSearchForm;
    }

    /**
     * Returns the current search action
     * @return string
     */
    public function getSearchAction() {
        return $this->getRequest()->param('Action');
    }

    /**
     * @param SS_HTTPRequest $request
     * @return string
     */
    public function facetsnav(SS_HTTPRequest $request) {
        $facetsPerPage = 30;
        $columnSize = $facetsPerPage / 2;

        $facet = $request->getVar('facet_field');
        $page = $request->getVar('facet_page') ?: 1;
        $sort = $request->getVar('facet_sort') ?: 'count';
        $prefix = $request->getVar('facet_prefix') ?: '';

        $prefix = ucwords(strtolower($prefix));

        $facetsManager = $this->getFacetsManager();

        if (LQConfig::get('facets', $facet)) {
            $solrQuery = $this->getSolrQueryObject(false);

            $solrQuery
                    ->addFacet($facet)
                    ->setRawField('facet.mincount', 1)
                    ->setRawField('facet.sort', $sort)
                    ->setRawField('facet.offset', ($page - 1) * $facetsPerPage)
                    ->setRawField('facet.limit', $facetsPerPage + 1)  //One more to check if there is a next page
                    ->setRawField('facet.prefix', $prefix)
                    ->setRawField('start', 0)
                    ->setRawField('rows', 0)
            ;

            $solrResponse = $this->getSolrSearcher()->search($solrQuery);

            $facets = $facetsManager->mergeAndOrderFacets(
                    array(
                        'facet_fields' => $solrResponse->getFacetFieldsCounts(),
                        'facet_queries' => $solrResponse->getFacetQueriesCounts()
                    )
            );


            $searchFieldName = $facetsManager->configuration[$facet]['field'];
            $field = $this->getSolrQueryMapper()->getFieldsCollection()->getField($searchFieldName);

            //Are the values of facet encoded?
            $isMapped = $field instanceof TemplateSolrSearchField && ((bool) $field->getDisplayValueTransformation());

            $doFacetsSet = new DataObjectSet();

            $i = 1;
            foreach ($facets[$facet] as $realValue
            => $count) {

                $link = $facetsManager->getFacetFilterLink(
                        $this->getSolrQueryMapper(), $facet, $realValue, 0, $this->getSearchBaseUrl()
                );

                $excludeLink = $facetsManager->getFacetFilterLink(
                        $this->getSolrQueryMapper(), $facet, $realValue, 0, $this->getSearchBaseUrl(), 'NOT'
                );

                $fItem = array(
                    "RealValue" => $realValue,
                    "Link" => $link,
                    "ExcludeLink" => $excludeLink,
                    "DisplayValue" => $field->setValue($realValue)->getDisplayedValue(),
                    "Count" => $count,
                    "CloseAndOpenColumn" => $i != $facetsPerPage && ($i % $columnSize) == 0
                );
                $doFacetsSet->push(new ArrayData($fItem));
                $i++;
            }

            $hasNextPage = $doFacetsSet->Count() > $facetsPerPage;

            if ($hasNextPage)
                $doFacetsSet->pop();

            parse_str($_SERVER['QUERY_STRING'], $parts);
            unset($parts['url']);
            $uri = $request->getURL() . '?' . http_build_query($parts);

            $Data = array(
                'Request' => htmlentities($solrQuery->getMainQuery()),
                'FacetSort' => $sort,
                'FacetPage' => $page,
                'FacetPrefix' => $prefix,
                'FacetLabel' => $field->getLabel(),
                'Result' => $doFacetsSet,
                'URI' => $uri,
                'FirstPage' => $page == 1,
                'LastPage' => !$hasNextPage,
                'Mapped' => $isMapped
            );

            return $this->customise($Data)->renderWith(
                            array('FacetsNav')
            );
        }
    }

    /**
     * Returns an hash where the keys are the subfields names and the values are the localized
     * fields labels
     *
     * @param SS_HTTPRequest $request
     *
     * @return SS_HTTPResponse
     *
     * @throws Exception
     */
    public function subfieldsMap(SS_HTTPRequest $request) {
        $fieldName = $request->param('FieldName');
        $fieldsConfiguration = $this->getSolrFieldsConfiguration();

        if (!isset($fieldsConfiguration[$fieldName]))
            throw new Exception("$fieldName is not set in solr configuration fields");

        $subfields = isset($fieldsConfiguration[$fieldName]['subfields']) ?
                $fieldsConfiguration[$fieldName]['subfields'] :
                array()
        ;

        $map = array();

        foreach ($subfields as $subfieldName) {
            $fallbackLabel = isset($fieldsConfiguration[$fieldName]['label']) ?
                    $fieldsConfiguration[$fieldName]['label'] :
                    $subfieldName
            ;
            $map[$subfieldName] = _t('LQFields.' . strtoupper($subfieldName), $fallbackLabel);
        }

        $response = new SS_HTTPResponse(json_encode($map));
        $response->addHeader("Content-type", "application/json");

        return $response;
    }

    /**
     * Autosuggestions action
     *
     * @return string A json-encoded list of results
     */
    public function autosuggest(SS_HTTPRequest $request) {
        $fieldName = $request->getVar('field');
        $limit = (int) $request->getVar('limit') ?: 15;
        $term = $request->getVar('term');

        if ($fieldName && LQConfig::get('fields', $fieldName)
        ) {
            $solrField = LQConfig::get('fields', $fieldName, 'field');
        } else {
            return json_encode(array());
        }

        $suggest = $this->getSolrSearcher()->termsuggest($solrField, $term, $limit, 'count');
        $response = array();

        foreach ($suggest['terms'][$solrField] as $k => $c) {
            $response[] = (string) $k;
        }

        return json_encode($response);
    }

    /**
     * Returns the number of results for a given search, in json format
     *
     * @param \SS_HTTPRequest $request
     * @return SS_HTTPResponse
     */
    public function info(SS_HTTPRequest $request) {
        $query = $this->getSolrQueryObject();
        $query
                ->setRawField('rows', '0')
                ->removeFacets()
        ;
        $solrResponse = $this->getSolrSearcher()->search($query);

        $info = array(
            'num_found' => $solrResponse->getNumFound(),
        );
        $body = json_encode($info);
        $response = new SS_HTTPResponse($body);
        $response->addHeader("Content-type", "application/json");

        return $response;
    }

    private $authority_type = array(
        '0' => 'Tutte',
        'A' => 'Argomento',
        'C' => 'Classe',
        'D' => 'Serie',
        'E' => 'Ente',
        'F' => 'Famiglia',
        'G' => 'Nome geografico/luogo',
        'H' => 'Marca tipografica',
        'L' => 'Luogo di edizione',
        'M' => 'Marca commerciale',
        'O' => 'Opera',
        'P' => 'Persona',
        'S' => 'Soggetto',
        'T' => 'Indicazione cronologica'
    );
    private $authority_opera_thesauro = array(
        'd965' => 'Più specifico (NT)',
        'd966' => 'Più generale (BT)',
        'd490' => 'Vedi (USE)',
        'd493' => 'Rinvio da (UF)',
        'd491' => 'Vedi anche (RT)'
    );
    private $authority_opera_type = array(
        'd300' => 'Generale',
        'd305' => 'Vedi anche',
        'd310' => 'Vedi',
        'd320' => 'Nota esplicativa',
        'd330' => 'Nota d\'ambito',
        'd390' => 'Datazione',
        'd391' => 'Contenuto',
        'd392' => 'Responsabilità intellettuale',
        'd393' => 'Storia editoriale',
        'd394' => 'Cast',
        'd395' => 'Premi',
        'd396' => 'Legami'
    );
    private $authority_opera_title = array(
        'd501' => 'Titolo uniforme collettivo',
        'd503' => 'Intestazione convenzionale uniforme',
        'd509' => 'Titolo originale non controllato',
        'd529' => 'Titolo subordinato',
        'd510' => 'Titolo parallelo',
        'd512' => 'Titolo della coperta',
        'd513' => 'Titolo del frontespizio aggiunto',
        'd514' => 'Titolo della prima pagina del testo (intitolazione)',
        'd515' => 'Titolo corrente',
        'd516' => 'Titolo del dorso',
        'd517' => 'Altre varianti del titolo',
        'd518' => 'Titolo nella forma ortografica moderna',
        'd520' => 'Titolo precedente (seriali)',
        'd531' => 'Titolo abbreviato (forma abbreviata del titolo chiave) (seriali)',
        'd532' => 'Titolo esteso (sciolto) (seriali)',
        'd540' => 'Titolo aggiunto supplito dal catalogatore',
        'd541' => 'Titolo tradotto supplito dal catalogatore',
        'd545' => 'Titolo della sezione'
    );
    private $authority_opera_link = array(
        'd969' => 'Soggetto (fiction)',
        'd676' => 'Classe',
        'd686' => 'Classe',
        'd968' => 'Soggetto',
        'd967' => 'Parola chiave',
        'd963' => 'È parola chiave di'
    );

    /**
     * Titoletto che indica la ricerca filtrata per Nome, ecc...
     * 
     * @return null|string
     */
    public function getSensitiveTitle() {
        return (string) $this->titleForAuthority;
    }

    /**
     * 
     * @param type $title
     * @return type
     */
    public function checkAuthorityInSearch($title) {
        $authority = new Authority();
        $authority = AuthorityRepository::testIfAuthority($title);
        if ($authority) {
            return $authority;
        }
        return null;
    }

    /**
     * 
     * @return type
     */
    public function getAuthorityType() {
        return (string) $this->fullAuthority->getType();
    }

    /**
     * 
     * @return type
     */
    public function getAuthorityFullType() {
        return (string) $this->fullAuthority->getFullType();
    }

    /**
     * 
     * @param String $code
     * @return boolean
     */
    public function AuthorityCheckTag($code) {
        $code = (string) $code;
        if (isset($this->fullAuthority->auth_turbomarc->$code)) {
            return true;
        }
        return false;
    }

    public function AuthorityCheckTagDouble($mix) {
        $mix = (string) $mix;
        $code = explode('_', $mix);
        if (    (isset($this->fullAuthority->auth_turbomarc->{$code[0]})) ||
                (isset($this->fullAuthority->auth_turbomarc->{$code[1]}))
            ) { return true; }
        return false;
    }

    public function AuthorityCheckTagMulti($mix) {
        $mix = (string) $mix;
        $code = explode('_', $mix);
        if (isset($this->fullAuthority->auth_turbomarc->{$code[0]})) {
            if (    (
                        (isset($code[1]))&&
                        (isset($this->fullAuthority->auth_turbomarc->{$code[0]}->{$code[1]}))&&
                        (trim($this->fullAuthority->auth_turbomarc->{$code[0]}->{$code[1]}))!="") ||
                    (   (isset($code[2]))&&
                        (isset($this->fullAuthority->auth_turbomarc->{$code[0]}->{$code[2]}))&&
                        (trim($this->fullAuthority->auth_turbomarc->{$code[0]}->{$code[2]}))!="")
                ) { return true; }
        }
        return false;
    }

    /**
     * 
     * @return boolean
     */
    public function AuthorityTypeOpera() {
        if ($this->getAuthorityType() == 'O') {
            return true;
        }
        return false;
    }

    /**
     * 
     * @return boolean
     */
    public function AuthorityTypeSubject() {
        if ($this->getAuthorityType() == 'S') {
            return true;
        }
        return false;
    }

    /**
     * 
     * @return boolean
     */
    public function AuthoritySearch() {
        // Carico il titoletto
        $this->titleForAuthority = new SearchSensitiveTitle($this->getSolrQueryMapper(), $this->Title);
        // Cerco nel titolo la presenza di parole chiave per le authority
        $this->fullAuthority = $this->checkAuthorityInSearch($this->titleForAuthority);
        if (!is_null($this->fullAuthority)) {
            return true;
        }
        return false;
    }

    /**
     * Linked Data (Mantova)
     * 
     * @return \DataObjectSet
     */
    public function AuthorityLinkedData() {
        $doSet = new DataObjectSet();
        $record = array('ld' => array());
        if (isset($this->fullAuthority->auth_turbomarc->d859)) {
            foreach ($this->fullAuthority->auth_turbomarc->d859 as $value) {
                /* volendo estrarre SA contiene la tipologia ma per ora no... */
                $nomelink = htmlspecialchars(trim((string) $value->sl));
                $url = trim((string) $value->su);
                if (strpos($url, 'http') === false) $url = 'http://' .$url;
                if ($nomelink == '') $nomelink = $url;
                $record['ld'] = array('nome' => $nomelink, 'url' => $url);
                $doSet->push(new ArrayData($record));
            }
        }
        return $doSet;
    }
    
    /**
     * Come sopra
     * 
     * @return boolean
     */
    public function AuthorityLinkedDataCheck() {
        if (isset($this->fullAuthority->auth_turbomarc->d859)) {
            return true;
        }
        return false;
    }
    
    /*     * ************************************************* AUTHORITY OPERA ************************************************************** */

    public function AuthorityOperaContent($code) {
        $doSet = new DataObjectSet();
        $record = array('r' => array());
        $sepCount = $this->fullAuthority->getSubjectCount($code) - 1;
        foreach ($this->fullAuthority->auth_turbomarc->$code as $value) {
            $record['r']['nome'] = htmlspecialchars((string) $value->s9);
//            $record['r']['note'] = (string) $value->s7;
            if (isset($value->s4)) {
                $record['r']['rCode'] = '(' . _tdef('LV_RELATORCODE.' . (string) $value->s4) . ')';
            } else {
                $record['r']['rCode'] = '';
            }
            $record['r']['id'] = (string) $value->s3;
            if ($sepCount > 0) {
                $record['r']['sep'] = ' - ';
                $sepCount--;
            } else {
                $record['r']['sep'] = '';
            }
            $doSet->push(new ArrayData($record));
        }
        return $doSet;
    }

    public function AuthorityOperaTitle() {
        $doSet = new DataObjectSet();
        $record = array('O' => array());
        if (isset($this->fullAuthority->auth_turbomarc->d230)) {
            $record['O']['nome'] = htmlspecialchars($this->fullAuthority->getName('d230', 'sa'));
        }
        $doSet->push(new ArrayData($record));
        return $doSet;
    }

    public function AuthorityOperaDate() {
        $doSet = new DataObjectSet();
        $record = array('t' => array());
        $temp = array();
        if (isset($this->fullAuthority->auth_turbomarc->d109)) {
            $temp[] = trim((string) $this->fullAuthority->auth_turbomarc->d109->sa);
            $temp[] = trim((string) $this->fullAuthority->auth_turbomarc->d109->sb);
        }
        if (($temp[0] != '') && ($temp[1] == '') || (($temp[1] != '') && ($temp[0] == ''))) {
            $record['d']['date'] = $temp[0] . $temp[1];
        } else {
            $record['d']['date'] = join(' - ', $temp);
        }
        $doSet->push(new ArrayData($record));
        return $doSet;
    }

//    public function AuthorityOperaTarget() {
//        $doSet = new DataObjectSet();
//        $record = array('t' => array());
//        if (isset($this->fullAuthority->auth_turbomarc->d109)) {
//            $record['t']['target'] = (string) $this->fullAuthority->auth_turbomarc->d109->sc;
//        }
//        $doSet->push(new ArrayData($record));
//        return $doSet;
//    }

    public function AuthorityOperaLanguage() {
        $doSet = new DataObjectSet();
        $record = array('l' => array());
        if (isset($this->fullAuthority->auth_turbomarc->d101)) {
            if (isset($this->fullAuthority->auth_turbomarc->d101->sa)) {
                $record['l']['lingua'] = _tdef('LV_LANGUAGES.' . (string) $this->fullAuthority->auth_turbomarc->d101->sa);
            } else {
                $record['l']['lingua'] = '';
            }
        }
        $doSet->push(new ArrayData($record));
        return $doSet;
    }

    public function AuthorityOperaCountry() {
        $doSet = new DataObjectSet();
        $record = array('c' => array());
        $temp = array();
        if (isset($this->fullAuthority->auth_turbomarc->d102)) {
            foreach ($this->fullAuthority->auth_turbomarc->d102 as $value) {
                if (isset($value->sa)) {
                    $temp[] = _tdef('LV_COUNTRIES.' . (string) $value->sa);
                } else {
                    $temp[] = '';
                }
            }
            $record['c']['paese'] = join(' - ', $temp);
            $doSet->push(new ArrayData($record));
        }
        return $doSet;
    }

    /* ALTRE OPERE ******************************************************************* */

    private $authOperaOtherOperas;

    public function AuthorityOperaOtherOperas() {
        $orderArray = array();
        foreach ($this->fullAuthority->auth_turbomarc->d463 as $value) {
            if (strlen((string) $value->sl) == 3) {
                if (isset($value->s7)) {
                    $nota = ' (' . (string) $value->s7 . ')';
                } else {
                    $nota = '';
                }
                $orderArray[(string) $value->sl][] = array((string) $value->s9, $nota, (string) $value->s3);
            }
        }
        $this->authOperaOtherOperas = $orderArray;
    }

    public function AuthorityOperaOtherOperasContent() {
        $orderArray = $this->authOperaOtherOperas;
        $doSet = new DataObjectSet();
        $record = array('t' => array());
        foreach ($orderArray as $key => $legame) {
            $testo_legame = '(' . _tdef('LV_AUTHLINKTYPE.' . (string) $key) . ') ';
            if ($this->AuthorityOperaOtherOperasOverOne($key) == true) {
                $first = true;
                foreach ($legame as $opera) {
                    $opera[0] = htmlspecialchars($opera[0]);
                    if ($first == true) {
                        $link = ' <a id="authOperaOtherOperasExpander_' . $key . '" href="javascript:void(0)">[' . _t('Catalog.AUTH_EXPANDER_ALL') . ' (' . ($this->AuthorityOperaOtherOperasCount($key) - 1) . ')]</a>';
                        $html = '<ul class="list-unstyled">';
                        $html .= '<li>' . $testo_legame . ' <a href="opac/search/?id-auth[value]=' . $opera[2] . '">' . $opera[0] . '</a>' . $opera[1] . $link . '</li>';
                        $html .= '</ul><ul id="authOperaOtherOperas_' . $key . '" style="display: none" class="list-unstyled">';
                        $first = false;
                    } else {
                        $html .= '<li>' . $testo_legame . ' <a href="opac/search/?id-auth[value]=' . $opera[2] . '">' . $opera[0] . '</a>' . $opera[1] . '</li>';
                    }
                }
                $html .= '</ul><script type="text/javascript">
                    $("#authOperaOtherOperas_' . $key . '").hide();                                
                    var testoExpander = "";
                    $("#authOperaOtherOperasExpander_' . $key . '").click(function() {
                        if ($("#authOperaOtherOperasExpander_' . $key . '").html() != "[' . _t("Catalog.AUTH_EXPANDER_CLOSE") . ']") {
                            $("#authOperaOtherOperas_' . $key . '").show();
                            testoExpander = $("#authOperaOtherOperasExpander_' . $key . '").html();
                            $("#authOperaOtherOperasExpander_' . $key . '").html("[' . _t("Catalog.AUTH_EXPANDER_CLOSE") . ']");
                        } else if ($("#authOperaOtherOperasExpander_' . $key . '").html() == "[' . _t("Catalog.AUTH_EXPANDER_CLOSE") . ']") {
                                    $("#authOperaOtherOperas_' . $key . '").hide();
                                    $("#authOperaOtherOperasExpander_' . $key . '").html(testoExpander);
                                }
                    });
                </script>
                 <style type="text/css">
                    #authOperaOtherOperas_' . $key . ' {
                        padding-left: 0px;
                    //  margin-left: -5px;
                    }
                    #authOperaOtherOperasExpander_' . $key . ' {
                        font-size: .75em;
                        margin: 1.67em 0;
                    }
                </style>';
            } else {
                $html = '<ul class="list-unstyled">
                <li>' . $testo_legame . '<a href="opac/search/?id-auth[value]=' . $legame[0][2] . '">' . htmlspecialchars($legame[0][0]) . '</a>' . $legame[0][1] . '</li>
                </ul>';
            }
            $record['t']['html'] = $html;
            $doSet->push(new ArrayData($record));
        }
        return $doSet;
    }

    public function AuthorityOperaOtherOperasCount($codice) {
        $orderArray = $this->authOperaOtherOperas;
        $i = 0;
        foreach ($orderArray as $key => $legame) {
            foreach ($legame as $opera) {
                if ($key == $codice) {
                    $i++;
                }
            }
        }
        return $i;
    }

    public function AuthorityOperaOtherOperasOverOne($key) {
        if ($this->AuthorityOperaOtherOperasCount($key) > 1) {
            return true;
        }
        return false;
    }

    /* FINE ALTRE OPERE ************************************************************** */

    /* ALTRI TITOLI ****************************************************************** */

    private $authOperaTitlesFirst;
    private $authOperaTitlesOthers;

    public function AuthorityOperaCheckTitles() {
        global $sc;
        $arrayNote = array(explode(',', $sc->getParameter('authority_opera_title.index')));
        foreach ($arrayNote[0] as $value) {
            if (isset($this->fullAuthority->auth_turbomarc->$value)) {
                return true;
            }
        }
        return false;
    }

    public function AuthorityOperaTitles() {
        global $sc;
        $arrayNote = array(explode(',', $sc->getParameter('authority_opera_title.index')));
        $doSet = new DataObjectSet();
        $record = array('t' => array());
        $first = TRUE;
        foreach ($arrayNote[0] as $value) {
            foreach ($this->fullAuthority->auth_turbomarc->$value as $test) {
//                $record['t']['tipo'] = $sc->getParameter('authority_opera_title.'.$value);
                $record['t']['titolo'] = htmlspecialchars((string) $test->sa);
                if ($first == true) {
                    if ($this->AuthorityOperaTitlesOverOne() == true) {
                        $record['t']['link'] = '<a href="javascript:void(0)" id="authOperaTitlesOthersExpander">[' . _t('Catalog.AUTH_EXPANDER_ALL') . ' (' . ($this->AuthorityOperaTitlesCount() - 1) . ')]</a>';
                    } else {
                        $record['t']['link'] = '';
                    }
                    $doFirst = new DataObjectSet();
                    $doFirst->push(new ArrayData($record));
                    $this->authOperaTitlesFirst = $doFirst;
                    $first = FALSE;
                } else {
                    $doSet->push(new ArrayData($record));
                }
            }
        }
        $this->authOperaTitlesOthers = $doSet;
    }

    public function AuthorityOperaTitlesFirst() {
        return $this->authOperaTitlesFirst;
    }

    public function AuthorityOperaTitlesOthers() {
        return $this->authOperaTitlesOthers;
    }

    public function AuthorityOperaTitlesOverOne() {
        if ($this->AuthorityOperaTitlesCount() > 1) {
            return true;
        }
        return false;
    }

    public function AuthorityOperaTitlesCount() {
        global $sc;
        $arrayNote = array(explode(',', $sc->getParameter('authority_opera_title.index')));
        $i = 0;
        foreach ($arrayNote[0] as $value) {
            foreach ($this->fullAuthority->auth_turbomarc->$value as $test) {
                if (isset($test->sa)) {
                    $i++;
                }
            }
        }
        return $i;
    }

    /* FINE ALTRI TITOLI ************************************************************* */

    /* ABSTRACT ********************************************************************** */

    public function AuthorityOperaCheckAbstract() {
        if (isset($this->fullAuthority->auth_turbomarc->d340)) {
            return true;
        }
        return false;
    }

    public function AuthorityOperaAbstract() {
        $doSet = new DataObjectSet();
        $record = array('a' => array());
        if (isset($this->fullAuthority->auth_turbomarc->d340)) {
            $record['a']['nota'] = htmlspecialchars((string) $this->fullAuthority->auth_turbomarc->d340->sa);
            $doSet->push(new ArrayData($record));
        }
        return $doSet;
    }

    /* FINE ABSTRACT **************************************************************** */

    /* NOTE ************************************************************************* */

    private $authOperaNotesFirst;
    private $authOperaNotesOthers;

    public function AuthorityOperaCheckNotes() {
        global $sc;
        $arrayNote = array(explode(',', $sc->getParameter('authority_opera_type.index')));
        foreach ($arrayNote[0] as $value) {
            if (isset($this->fullAuthority->auth_turbomarc->$value)) {
                return true;
            }
        }
        return false;
    }

    public function AuthorityOperaNotes() {
        global $sc;
        $arrayNote = array(explode(',', $sc->getParameter('authority_opera_type.index')));
        $doSet = new DataObjectSet();
        $record = array('n' => array());
        $first = TRUE;
        foreach ($arrayNote[0] as $value) {
            if (isset($this->fullAuthority->auth_turbomarc->$value->sa)) {
//                $record['n']['tipo'] = $this->authority_opera_type[$value];
                $record['n']['nota'] = htmlspecialchars((string) $this->fullAuthority->auth_turbomarc->$value->sa);
                if ($first == true) {
                    if ($this->AuthorityOperaNotesOverOne() == true) {
                        $record['n']['link'] = '<a href="javascript:void(0)" id="authOperaNotesOthersExpander">[' . _t('Catalog.AUTH_EXPANDER_OPEN') . ' (' . ($this->AuthorityOperaNotesCount() - 1) . ')]</a>';
                    } else {
                        $record['n']['link'] = '';
                    }
                    $doFirst = new DataObjectSet();
                    $doFirst->push(new ArrayData($record));
                    $this->authOperaNotesFirst = $doFirst;
                    $first = FALSE;
                } else {
                    $doSet->push(new ArrayData($record));
                }
            }
        }
        $this->authOperaNotesOthers = $doSet;
    }

    public function AuthorityOperaNotesFirst() {
        return $this->authOperaNotesFirst;
    }

    public function AuthorityOperaNotesOverOne() {
        if ($this->AuthorityOperaNotesCount() > 1) {
            return true;
        }
        return false;
    }

    public function AuthorityOperaNotesOthers() {
        return $this->authOperaNotesOthers;
    }

    public function AuthorityOperaNotesCount() {
        global $sc;
        $arrayNote = array(explode(',', $sc->getParameter('authority_opera_type.index')));
        $i = 0;
        foreach ($arrayNote[0] as $value) {
            if (isset($this->fullAuthority->auth_turbomarc->$value->sa)) {
                $i++;
            }
        }
        return $i;
    }

    /* FINE NOTE ******************************************************************** */

    /* LEGAMI *********************************************************************** */

    private $authOperaLinksOthers;
    private $authOperaLinksFirst;

    public function AuthorityOperaLinksContent($codes) {
        $code = explode('_', $codes);
        $doSet = new DataObjectSet();
        $record = array('s' => array());
        $first = TRUE;
        if (isset($code[0])) {
            foreach ($this->fullAuthority->auth_turbomarc->{$code[0]} as $value) {
                $record['s']['nome'] = htmlspecialchars((string) $value->s9);
//                $record['s']['note'] = (string) $value->s7;
                $record['s']['id'] = (string) $value->s3;
                if ($first == true) {
                    if ($this->AuthorityOperaLinksOverOne($code[0]) == true) {
                        $record['s']['link'] = ' <a href="javascript:void(0)" id="authOperaLinksOthersExpander_' . $code[0] . '">[' . _t('Catalog.AUTH_EXPANDER_OPEN') . ' (' . ($this->AuthorityOperaLinksCount($code[0]) - 1) . ')]</a>';
                    } else {
                        $record['s']['link'] = '';
                    }
                    $doFirst = new DataObjectSet();
                    $doFirst->push(new ArrayData($record));
                    $this->authOperaLinksFirst = $doFirst;
                    $first = FALSE;
                } else {
                    $doSet->push(new ArrayData($record));
                }
            }
        }
        if (isset($code[1])) {
            foreach ($this->fullAuthority->auth_turbomarc->{$code[1]} as $value) {
                $record['s']['nome'] = htmlspecialchars((string) $value->s9);
//                $record['s']['note'] = (string) $value->s7;
                $record['s']['id'] = (string) $value->s3;
                if ($first == true) {
                    if ($this->AuthorityOperaLinksOverOne($code[1]) == true) {
                        $record['s']['link'] = ' <a href="javascript:void(0)" id="authOperaLinksOthersExpander_' . $code[0] . '">[' . _t('Catalog.AUTH_EXPANDER_OPEN') . ' (' . ($this->AuthorityOperaLinksCount($code[1]) - 1) . ')]</a>';
                    } else {
                        $record['s']['link'] = '';
                    }
                    $doFirst = new DataObjectSet();
                    $doFirst->push(new ArrayData($record));
                    $this->authOperaLinksFirst = $doFirst;
                    $first = FALSE;
                } else {
                    $doSet->push(new ArrayData($record));
                }
            }
        }
        $this->authOperaLinksOthers = $doSet;
    }

    public function AuthorityOperaLinksOverOne($code) {
        $code = (string) $code;
        if (strpos($code, '_') !== false) {
            $code = explode('_', $code);
            if (($this->AuthorityOperaLinksCount($code[0]) + $this->AuthorityOperaLinksCount($code[1])) > 1) {
                return true;
            }
        } else {
            if ($this->AuthorityOperaLinksCount($code) > 1) {
                return true;
            }
        }
        return false;
    }

    public function AuthorityOperaLinksCount($code) {
        $i = 0;
        foreach ($this->fullAuthority->auth_turbomarc->$code as $value) {
            $i++;
        }
        return $i;
    }

    public function AuthorityOperaLinksFirst() {
        return $this->authOperaLinksFirst;
    }

    public function AuthorityOperaLinksOthers() {
        return $this->authOperaLinksOthers;
    }

    /* FINE LEGAMI ****************************************************************** */

    /*     * ************************************************* FINE AUTHORITY OPERA ********************************************************* */
    /*     * ******************************************************************************************************************************** */
    /*     * ************************************************* AUTHORITY ALTRO ************************************************************** */

    public function AuthorityOtherTitle() {
        $doSet = new DataObjectSet();
        $record = array('X' => array());
        if (isset($this->fullAuthority->auth_turbomarc->d299)) {
            $record['X']['nome'] = htmlspecialchars($this->fullAuthority->getName('d299', 'sa'));
            $record['X']['tipo'] = $this->fullAuthority->getFullType();
        }
        $doSet->push(new ArrayData($record));
        return $doSet;
    }

    /* NOTE ************************************************************************* */

    private $authOtherNotesFirst;
    private $authOtherNotesOthers;

    public function AuthorityOtherCheckNotes() {
        global $sc;
        $arrayNote = array(explode(',', $sc->getParameter('authority_opera_type.index')));
        foreach ($arrayNote[0] as $value) {
            if (isset($this->fullAuthority->auth_turbomarc->$value)) {
                return true;
            }
        }
        return false;
    }

    public function AuthorityOtherNotes() {
        global $sc;
        $arrayNote = array(explode(',', $sc->getParameter('authority_opera_type.index')));
        $doSet = new DataObjectSet();
        $record = array('n' => array());
        $first = TRUE;
        foreach ($arrayNote[0] as $value) {
            if (isset($this->fullAuthority->auth_turbomarc->$value->sa)) {
                $record['n']['nota'] = htmlspecialchars((string) $this->fullAuthority->auth_turbomarc->$value->sa);
                if ($first == true) {
                    if ($this->AuthorityOtherNotesOverOne() == true) {
                        $record['n']['link'] = '<a href="javascript:void(0)" id="authOtherNotesOthersExpander">[' . _t('Catalog.AUTH_EXPANDER_OPEN') . ' (' . ($this->AuthorityOtherNotesCount() - 1) . ')]</a>';
                    } else {
                        $record['n']['link'] = '';
                    }
                    $doFirst = new DataObjectSet();
                    $doFirst->push(new ArrayData($record));
                    $this->authOtherNotesFirst = $doFirst;
                    $first = FALSE;
                } else {
                    $doSet->push(new ArrayData($record));
                }
            }
        }
        $this->authOtherNotesOthers = $doSet;
    }

    public function AuthorityOtherNotesFirst() {
        return $this->authOtherNotesFirst;
    }

    public function AuthorityOtherNotesOverOne() {
        if ($this->AuthorityOtherNotesCount() > 1) {
            return true;
        }
        return false;
    }

    public function AuthorityOtherNotesOthers() {
        return $this->authOtherNotesOthers;
    }

    public function AuthorityOtherNotesCount() {
        global $sc;
        $arrayNote = array(explode(',', $sc->getParameter('authority_opera_type.index')));
        $i = 0;
        foreach ($arrayNote[0] as $value) {
            if (isset($this->fullAuthority->auth_turbomarc->$value->sa)) {
                $i++;
            }
        }
        return $i;
    }

    /* FINE NOTE ******************************************************************** */

    /* ALTRI SOGGETTI *************************************************************** */

    private $authOtherSubjectOthers;
    private $authOtherSubjectCount;

    public function AuthorityOtherSubjectsOthers() {
        return $this->authOtherSubjectOthers;
    }

    public function AuthorityOtherSubjectsOthersOver($max = 1) {
        if ($this->AuthorityOthersSubjectsOthersCount() > $max) {
            return true;
        }
        return false;
    }

    public function AuthorityOthersSubjectsOthersCount($id = null, $start = 0, $rows = 10, $other = null) {
        if (is_null($id)) {
            $count = AuthorityRepository::countAuthorityOtherSubject($this->fullAuthority->getId());
        } else {
            $count = AuthorityRepository::countAuthorityOtherSubject($id, $start, $rows, $other);
        }
        return $count;
    }

    public function AuthorityOtherSubjects() {
        $value = new DataObject();
        $value->auth_id = $this->fullAuthority->getId();
        $value->auth_sort = 'sorts_fulltext asc';
        $value->auth_fl = 'sorts_fulltext,id';
        $subjects = AuthorityRepository::searchAuthorityOtherSubject($value);
        $count = AuthorityRepository::countAuthorityOtherSubject($value);
        $this->authOtherSubjectCount = $count;
        if (isset($subjects)) {
            $doSet = new DataObjectSet();
            $record = array('s' => array());
            $first = TRUE;
            $i = 0;
            foreach ($subjects as $subject) {
                $i++;
                if ($i <= 5) {
                    $record['s']['titolo'] = htmlspecialchars($subject['sorts_fulltext']);
                    $record['s']['id'] = explode(':', $subject['id'])[2];
                    if (($this->AuthorityOtherSubjectsOthersOver(5) == true) && ($i == 5)) {
                        $uri_link = '?modal_type=S&auth_id=' . $this->fullAuthority->getId() . '&auth_page=0';
                        $uri_link = htmlentities(strip_tags($uri_link));
                        $record['s']['link'] = '<br /><i class="fa fa-fw fa-chevron-right"></i><a data-authlist-uri="opac/search/authoritynav' . $uri_link . '" href="javascript:void(0)" id="authOtherSubjectFullExpander">[' . _t('Catalog.AUTH_EXPANDER_ALL') . ' (' . $count . ')]</a>';
                    } else {
                        $record['s']['link'] = '';
                    }
                    $doSet->push(new ArrayData($record));
                }
            }
            $this->authOtherSubjectOthers = $doSet;
            return true;
        }
        return false;
    }

    /**
     *  (A)ll, (S)ubject, (T)hesauro (NT), (O)pere collegate a non opere
     */
    public function authoritynav(SS_HTTPRequest $request) {
        $rows = 15;
        $ModalType = $request->getVar('modal_type');
        switch ($ModalType) {
            case 'A':
                $auth_page = $request->getVar('auth_page');
                $auth_id = $request->getVar('auth_id');
                $auth_fulltext = $request->getVar('auth_fulltext');
                $auth_initialtext = $request->getVar('auth_initialtext');
                $auth_type = $request->getVar('auth_type');
                $doSetAuthList = new DataObjectSet();
                $authorityList = array('s' => array());
                global $sc;
                $AuthIndex = array(explode(',', $sc->getParameter('authority_type.index')));
                $value = new DataObject();
                if ($auth_id != 0) {
                    $value->auth_id = $auth_id;
                }
                $value->auth_start = ($auth_page * $rows);
                $value->auth_rows = $rows;
                $value->auth_facet = 'true';
                $value->auth_facet_field = 'fldis_str_auth_type';
                $value->auth_sort = 'sorts_fulltext asc';
                $search_string = '';
                if ($auth_type != "0") {
                    $search_string .= ' AND fldis_str_auth_type:' . addslashes($auth_type);
                }
                if ($auth_fulltext != "") {
                    $search_string .= ' AND (mrc_d299_sa:(' . addslashes($auth_fulltext) . ') OR mrc_d517_sa:(' . addslashes($auth_fulltext) . '))';
                }
                if ($auth_initialtext != "") {
                    $search_string .= ' AND sorts_fulltext:' . addslashes($auth_initialtext) . '*';
                }
                $value->auth_other = $search_string;
                $occorrenze = AuthorityRepository::searchAuthorityTypeNumberList($value);
                foreach ($occorrenze as $key => $occorrenza) {
                if ($occorrenze[$key] > 0) {
                    $authorityList['s']['codice'] = $key;
                    if ($key == $auth_type) {
                        $authorityList['s']['selected'] = 'selected="selected"';
                    } else {
                        $authorityList['s']['selected'] = '';
                    }
                    if (in_array(strtoupper($key), $AuthIndex[0])) {
                        $authorityList['s']['nome'] = $this->authority_type[strtoupper($key)];
                    } else {
                        $authorityList['s']['nome'] = $key;
                    }
                    $numeroAuth = '';

                    $numeroAuth = ' (' . $occorrenze[$key] . ') ';

                    if ($auth_type != '0' && $key == '0') {
                        $numeroAuth = '';
                    }
                    $authorityList['s']['nome'] .= $numeroAuth;
                    $doSetAuthList->push(new ArrayData($authorityList));
                }
                }
                $doSet = new DataObjectSet();
                $subjects = AuthorityRepository::searchAuthorityOtherSubject($value);
                $total = $occorrenze[0];
                $record = array('s' => array());
                if ($total > 0) {
                    $i = ($auth_page * $rows) + 1;
                    foreach ($subjects as $subject) {
                        $record['s']['posizione'] = $i; //str_pad($i, (int) log10($total)+1, '0', STR_PAD_LEFT);
                        $i++;
                        $record['s']['titolo'] = isset($subject['fldis_str_fulltext'][0]) ? htmlspecialchars($subject['fldis_str_fulltext'][0]) : '';
                        $record['s']['id'] = explode(':', $subject['id'])[2];
                        if (in_array(strtoupper($subject['fldis_str_auth_type'][0]), $AuthIndex[0])) {
                            $record['s']['tipo'] = '(' . $this->authority_type[strtoupper($subject['fldis_str_auth_type'][0])] . ')';
                        } else {
                            $record['s']['tipo'] = '(' . $subject['facets_entitytype'][0] . ')';
                        }
                        // Inserimento Vedi (USE) d490
                        $record['s']['d490'] = '';
                        $turbomarc = simplexml_load_string($subject['turbo_marc']);
                        if (isset($turbomarc->d490->sa)) {
                            $temp = '';
                            foreach ($turbomarc->d490 as $value) {
                                $temp .= '<a href="opac/search/?id-auth[value]=' . (string) $value->s3 . '">' . htmlspecialchars((string) $value->s9) . '</a> ';
                            }
                            $record['s']['d490'] = ' - Vedi (USE): ' . $temp;
                        }
                        $doSet->push(new ArrayData($record));
                    }
                } else {
                    $record['s']['posizione'] = 'Nessun risultato!';
                    $record['s']['titolo'] = '';
                    $record['s']['id'] = '';
                    $doSet->push(new ArrayData($record));
                }
                $hasNextPage = ($total / $rows) > ($auth_page + 1);
                parse_str($_SERVER['QUERY_STRING'], $parts);
                unset($parts['url']);
                $uri = $request->getURL() . '?' . http_build_query($parts);
                $Data = array(
                    'URI' => $uri,
                    'AuthCount' => $total == 0 ? '' : $total,
                    'AuthPage' => $auth_page,
                    'AuthFulltext' => $auth_fulltext,
                    'AuthInitialtext' => $auth_initialtext,
                    'AuthId' => $auth_id,
                    'AuthType' => $auth_type,
                    'ModalType' => $ModalType,
                    'AllAuthority' => true,
                    'ThesauroNT' => false,
                    'OtherSubject' => false,
                    'LinkedOperas' => false,
                    'AuthList' => $doSetAuthList,
                    'Result' => $doSet,
                    'FirstPage' => $auth_page == 0,
                    'LastPage' => !$hasNextPage
                );
                break;
            case 'S':
                $auth_id = $request->getVar('auth_id');
                $auth_page = $request->getVar('auth_page');
                $auth_fulltext = $request->getVar('auth_fulltext');
                $auth_initialtext = $request->getVar('auth_initialtext');
                $search_string = '';
                if ($auth_fulltext != "") {
                    $search_string .= ' AND (mrc_d299_sa:' . addslashes($auth_fulltext) . ' OR mrc_d517_sa:' . addslashes($auth_fulltext) . ')';
                }
                if ($auth_initialtext != "") {
                    $search_string = ' AND sorts_fulltext:' . addslashes($auth_initialtext) . '*';
                }
                $value = new DataObject();
                $value->auth_id = $auth_id;
                $value->auth_start = ($auth_page * $rows);
                $value->auth_rows = $rows;
                $value->auth_other = $search_string;
                $value->auth_sort = 'sorts_fulltext asc';
                $value->auth_fl = 'sorts_fulltext,id';
                $subjects = AuthorityRepository::searchAuthorityOtherSubject($value);
                $total = $this->AuthorityOthersSubjectsOthersCount($value);
                $doSet = new DataObjectSet();
                $record = array('s' => array());
                if ($total > 0) {
                    $i = ($auth_page * $rows) + 1;
                    foreach ($subjects as $subject) {
                        $record['s']['posizione'] = $i; //str_pad($i, (int) log10($total)+1, '0', STR_PAD_LEFT);
                        $i++;
                        $record['s']['titolo'] = htmlspecialchars($subject['sorts_fulltext']);
                        $record['s']['id'] = explode(':', $subject['id'])[2];
                        $doSet->push(new ArrayData($record));
                    }
                } else {
                    $record['s']['posizione'] = 'Nessun risultato';
                    $record['s']['titolo'] = '';
                    $record['s']['id'] = '';
                    $doSet->push(new ArrayData($record));
                }
                $hasNextPage = ($total / $rows) > ($auth_page + 1);
                parse_str($_SERVER['QUERY_STRING'], $parts);
                unset($parts['url']);
                $uri = $request->getURL() . '?' . http_build_query($parts);
                $Data = array(
                    'URI' => $uri,
                    'AuthCount' => $total,
                    'AuthPage' => $auth_page,
                    'AuthFulltext' => $auth_fulltext,
                    'AuthInitialtext' => $auth_initialtext,
                    'AuthId' => $auth_id,
                    'ModalType' => $ModalType,
                    'AllAuthority' => false,
                    'ThesauroNT' => false,
                    'OtherSubject' => true,
                    'LinkedOperas' => false,
                    'Result' => $doSet,
                    'FirstPage' => $auth_page == 0,
                    'LastPage' => !$hasNextPage
                );
                break;
            case 'T':
                $auth_page = $request->getVar('auth_page');
                $auth_id = $request->getVar('auth_id');
                $auth_thesauro = $request->getVar('auth_thesauro');

                $result = AuthorityRepository::getFullAuthority($auth_id);

                $total = 0;
                $temp = array();
                foreach ($result->auth_turbomarc->$auth_thesauro as $val) {
                    $temp[$total]['titolo'] = htmlspecialchars($val->s9);
                    $temp[$total]['id'] = (string) $val->s3;
                    $temp[$total]['tipo'] = '(' . $this->authority_type[(string) $val->s2] . ')';
                    $total++;
                }
                asort($temp);

                $doSet = new DataObjectSet();
                $start = 1 + ($rows * $auth_page);
                $end = $start + $rows - 1;
                $i = 1;
                $record = array('s' => array());
                if (isset($result->auth_turbomarc->d299)) {
                    $nomeAuth = '<b>' . htmlspecialchars($result->auth_turbomarc->d299->sa) . '</b>';
                    $tipoAuth = '<h6>(' . $this->authority_type[strtoupper($result->auth_turbomarc->d901->sm)] . ')</h6><br />';
                }
                foreach ($temp as $val) {
                    if (($i >= $start) && ($i <= $end)) {
                        $record['s']['posizione'] = $i;
                        $record['s']['titolo'] = $val['titolo'];
                        $record['s']['id'] = $val['id'];
                        $record['s']['tipo'] = $val['tipo'];
                        $doSet->push(new ArrayData($record));
                    }
                    $i++;
                }

                $hasNextPage = ($total / $rows) > ($auth_page + 1);
                parse_str($_SERVER['QUERY_STRING'], $parts);
                unset($parts['url']);
                $uri = $request->getURL() . '?' . http_build_query($parts);
                $Data = array(
                    'URI' => $uri,
                    'AuthCount' => $total == 0 ? '' : $total,
                    'AuthPage' => $auth_page,
                    'AuthThesauro' => $auth_thesauro,
                    'AuthId' => $auth_id,
                    'ModalType' => $ModalType,
                    'AllAuthority' => false,
                    'ThesauroNT' => true,
                    'OtherSubject' => false,
                    'LinkedOperas' => false,
                    'Result' => $doSet,
                    'ThesauroName' => $nomeAuth . ' ' . $tipoAuth . ' ' . 'Thesaurus: ' . $this->authority_opera_thesauro[$auth_thesauro],
                    'FirstPage' => $auth_page == 0,
                    'LastPage' => !$hasNextPage
                );
                break;
            case 'O':
                $auth_page = $request->getVar('auth_page');
                $linksType = $request->getVar('link_type');
                $auth_id = $request->getVar('auth_id');
                $auth_fulltext = $request->getVar('auth_fulltext');
                $auth_initialtext = $request->getVar('auth_initialtext');
                $search_string = '';
                if ($auth_fulltext != "") {
                    $search_string .= ' AND (mrc_d299_sa:' . addslashes($auth_fulltext) . ' OR mrc_d517_sa:' . addslashes($auth_fulltext) . ')';
                }
                if ($auth_initialtext != "") {
                    $search_string = ' AND sorts_fulltext:' . addslashes($auth_initialtext) . '*';
                }
                $value = new DataObject();
                $value->auth_sort = 'sorts_fulltext asc';
                $value->auth_fl = 'sorts_fulltext,id,fldis_str_fulltext';
                $value->auth_start = ($auth_page * $rows);
                $value->auth_rows = $rows;
                switch ($linksType) {
                    case 's':
                        $value->auth_other = $search_string . ' AND fldis_str_auth_type:O AND (mrc_d970_s3:' . $auth_id . ' OR mrc_d971_s3:' . $auth_id . ' OR mrc_d972_s3:' . $auth_id . ')';
                        break;
                    case 'a':
                        $value->auth_other = $search_string . ' AND fldis_str_auth_type:O AND (mrc_d230_s3:' . $auth_id . ' OR mrc_d963_s3:' . $auth_id . ' OR mrc_d967_s3:' . $auth_id . ' OR mrc_d968_s3:' . $auth_id . ' OR mrc_d969_s3:' . $auth_id . ')';
                        break;
                }

                $total = AuthorityRepository::countAuthorityOtherSubject($value);
                $subjects = AuthorityRepository::searchAuthorityOtherSubject($value);
                $doSet = new DataObjectSet();
                $record = array('s' => array());
                if ($total > 0) {
                    $i = ($auth_page * $rows) + 1;
                    foreach ($subjects as $subject) {
                        $record['s']['posizione'] = $i; //str_pad($i, (int) log10($total)+1, '0', STR_PAD_LEFT);
                        $i++;
                        //$record['s']['titolo'] = htmlspecialchars($subject['sorts_fulltext']);
                        $record['s']['titolo'] = htmlspecialchars($subject['fldis_str_fulltext'][0]);
                        $record['s']['id'] = explode(':', $subject['id'])[2];
                        $doSet->push(new ArrayData($record));
                    }
                } else {
                    $record['s']['posizione'] = 'Nessun risultato';
                    $record['s']['titolo'] = '';
                    $record['s']['id'] = '';
                    $doSet->push(new ArrayData($record));
                }

                $hasNextPage = ($total / $rows) > ($auth_page + 1);
                parse_str($_SERVER['QUERY_STRING'], $parts);
                unset($parts['url']);
                $uri = $request->getURL() . '?' . http_build_query($parts);
                $Data = array(
                    'URI' => $uri,
                    'AuthCount' => $total == 0 ? '' : $total,
                    'AuthPage' => $auth_page,
                    'AuthId' => $auth_id,
                    'AuthFulltext' => $auth_fulltext,
                    'AuthInitialtext' => $auth_initialtext,
                    'ModalType' => $ModalType,
                    'AllAuthority' => false,
                    'ThesauroNT' => false,
                    'OtherSubject' => false,
                    'LinkedOperas' => true,
                    'Result' => $doSet,
                    'LinkType' => $linksType,
                    'FirstPage' => $auth_page == 0,
                    'LastPage' => !$hasNextPage
                );
                break;
        }

        return $this->customise($Data)->renderWith(array('AuthorityNav'));
    }

    /* FINE ALTRI SOGGETTI ********************************************************** */

    /* THESAURO ********************************************************************* */

    private $authOtherThesauroTags;

    public function AuthorityOtherThesauroOverOne($code) {
        $code = (string) $code;
        if ($this->AuthorityOthersThesauroCount($code) > 1) {
            return true;
        }
        return false;
    }

    public function AuthorityOtherThesauroOverFive($code) {
        $code = (string) $code;
        if ($this->AuthorityOthersThesauroCount($code) > 5) {
            return true;
        }
        return false;
    }

    public function AuthorityOthersThesauroCount($code) {
        $i = 0;
        foreach ($this->fullAuthority->auth_turbomarc->$code as $value) {
            $i++;
        }
        return $i;
    }

    public function AuthorityOtherThesauroContent() {
        $codes = $this->authOtherThesauroTags;
        $doSet = new DataObjectSet();
        $record = array('t' => array());
        // Generazione html che mostra il thesauro
        foreach ($codes as $code) {
            $i = 0;
//            $first = true;
            // Codice html comune
            $html = '<div class="col-md-4 authOtherThesauroHead">' . $this->authority_opera_thesauro[$code] . '</div>';
            $html .= '<div class="col-md-8 authOtherThesauroBody_' . $code . '"><ul>';
            if ($this->AuthorityOtherThesauroOverOne($code) == true) { /* Blocco thesauro, termine multiplo */
                foreach ($this->fullAuthority->auth_turbomarc->$code as $value) {
                    $i++;
                    if ($i <= 5) {
                        $html .= '<li><a href="opac/search/?id-auth[value]=' . $value->s3 . '">' . htmlspecialchars($value->s9) . '</a>';
                        if (($this->AuthorityOtherThesauroOverFive($code) == true) && ($i == 5)) {
                            $uri_link = '?modal_type=T&auth_id=' . $this->fullAuthority->getId() . '&auth_page=0&auth_thesauro=' . $code;
                            $uri_link = htmlentities(strip_tags($uri_link));
                            $html .= '<br /><i class="fa fa-fw fa-chevron-right"></i><a data-authlist-uri="opac/search/authoritynav' . $uri_link . '" href="javascript:void(0)" id="authOtherThesauroOthersExpander">[' . _t('Catalog.AUTH_EXPANDER_ALL') . ' (' . $this->AuthorityOthersThesauroCount($code) . ')]</a>';
                        }
                        $html .= '</li>';
                    }
                }
                $html .= '</ul>
                            <style type="text/css">
                                #authOtherThesauroOthersExpander {
                                    font-size: .75em;
                                    margin: 1.67em 0;
                                }
                            </style>
                        </div>';
            } else { /* Blocco thesauro, singolo termine */
                $html .= '<li><a href="opac/search/?id-auth[value]=' . $this->fullAuthority->auth_turbomarc->$code->s3 . '">' . htmlspecialchars($this->fullAuthority->auth_turbomarc->$code->s9) . '</a>
                          </li></ul></div>';
            }
            $record['t']['html'] = $html;
            $html = '';
            $doSet->push(new ArrayData($record));
        }
        return $doSet;
    }

    public function AuthorityOtherThesauro() {
        global $sc;
        $arrayThes = array(explode(',', $sc->getParameter('authority_opera_thesauro.index')));
        $record = array();
        foreach ($arrayThes[0] as $value) {
            if (isset($this->fullAuthority->auth_turbomarc->$value)) {
                $record[] = (string) $value;
            }
        }
        $this->authOtherThesauroTags = $record;
    }

    public function AuthorityOtherThesauroCheckTag() {
        if (count($this->authOtherThesauroTags) != 0) {
            return true;
        }
        return false;
    }

    /* FINE THESAURO **************************************************************** */

    /* LEGAME ALTRE OPERE *********************************************************** */

    private $authOtherLinksOperaCount;

    public function AuthorityOtherLinksOpera() {
        
    }

    public function AuthorityOtherLinksOperaCheck() {
        $value = new DataObject();
        $value->auth_sort = 'sorts_fulltext asc';
        $value->auth_fl = 'sorts_fulltext,id';
        $value->auth_other = ' AND fldis_str_auth_type:O AND (mrc_d970_s3:' . $this->fullAuthority->getId() . ' OR mrc_d971_s3:' . $this->fullAuthority->getId() . ' OR mrc_d972_s3:' . $this->fullAuthority->getId() . ' OR mrc_d230_s3:' . $this->fullAuthority->getId() . ' OR mrc_d963_s3:' . $this->fullAuthority->getId() . ' OR mrc_d967_s3:' . $this->fullAuthority->getId() . ' OR mrc_d968_s3:' . $this->fullAuthority->getId() . ' OR mrc_d969_s3:' . $this->fullAuthority->getId() . ')';
        if (AuthorityRepository::countAuthorityOtherSubject($value) > 0) {
            return true;
        }
        return false;
    }

    public function AuthorityOtherLinksOperaContent() {
        $value = new DataObject();
        $value->auth_sort = 'sorts_fulltext asc';
        $value->auth_fl = 'sorts_fulltext,id';
        $value->auth_other = ' AND fldis_str_auth_type:O AND (mrc_d970_s3:' . $this->fullAuthority->getId() . ' OR mrc_d971_s3:' . $this->fullAuthority->getId() . ' OR mrc_d972_s3:' . $this->fullAuthority->getId() . ')';
        $autori = AuthorityRepository::countAuthorityOtherSubject($value);
        $value->auth_other = ' AND fldis_str_auth_type:O AND (mrc_d230_s3:' . $this->fullAuthority->getId() . ' OR mrc_d963_s3:' . $this->fullAuthority->getId() . ' OR mrc_d967_s3:' . $this->fullAuthority->getId() . ' OR mrc_d968_s3:' . $this->fullAuthority->getId() . ' OR mrc_d969_s3:' . $this->fullAuthority->getId() . ')';
        $argomenti = AuthorityRepository::countAuthorityOtherSubject($value);
        $html = '<ul class="list-unstyled">';
        $doSet = new DataObjectSet();
        $record = array('c' => array());
        if ($autori > 0) {
            $uri_link = '?modal_type=O&auth_id=' . $this->fullAuthority->getId() . '&auth_page=0&link_type=s';
            $uri_link = htmlentities(strip_tags($uri_link));
            $html .= '<li><a id="authorityOtherLinksOperaExpander" data-authlist-uri="opac/search/authoritynav' . $uri_link . '" href="javascript:void(0)"><i>...come autore (' . $autori . ')</i></a></li>';
        }
        if ($argomenti > 0) {
            $uri_link = '?modal_type=O&auth_id=' . $this->fullAuthority->getId() . '&auth_page=0&link_type=a';
            $uri_link = htmlentities(strip_tags($uri_link));
            $html .= '<li><a id="authorityOtherLinksOperaExpander" data-authlist-uri="opac/search/authoritynav' . $uri_link . '" href="javascript:void(0)"><i>...come argomento (' . $argomenti . ')</i></a></li>';
        }
        $html .= '</ul>';
        $record['c']['html'] = $html;
        $doSet->push(new ArrayData($record));
        return $doSet;
    }

    /* FINE LEGAME ALTRE OPERE ****************************************************** */

    /*     * ************************************************* FINE AUTHORITY ALTRO ********************************************************* */
    /*     * ******************************************************************************************************************************** */
    /*     * ************************************************* AUTHORITY SOGGETTO *********************************************************** */

    public function AuthoritySubjectTitle() {
        $doSet = new DataObjectSet();
        $record = array('S' => array());
        $titleTemp = '';
        $i = 0;
        if (isset($this->fullAuthority->auth_turbomarc->d931)) {
            // Conteggio numero soggetti per inserimento separatore
            $sepCount = $this->fullAuthority->getSubjectCount('d931') - 1;
            // Loop per gli elementi "s3" ed "sa" del campo "d931" (Componenti nome soggetto)
            foreach ($this->fullAuthority->auth_turbomarc->d931 as $title) {
                $record['S']['nome'] = htmlspecialchars((string) $title->sa);
                $record['S']['link'] = (string) $title->s3;
                // Titolo del link
                if ($i > 0) {
                    $titleTemp .= ' - ';
                }
                $titleTemp .= (string) $title->sa;
                $record['S']['titleSave'] = urlencode($titleTemp);
                $record['S']['title'] = htmlspecialchars((string) $title->sa);
                $i++;
                //Separatore per visualizzazione
                if ($sepCount > 0) {
                    $record['S']['sep'] = ' - ';
                    $sepCount--;
                } else {
                    $record['S']['sep'] = '';
                }
                $doSet->push(new ArrayData($record));
            }
        }
        return $doSet;
    }

    public function AuthoritySubjectContent() {
        $doSet = new DataObjectSet();
        $record = array('S' => array());
        if (isset($this->fullAuthority->auth_turbomarc->d931)) {
            // Conteggio numero soggetti per inserimento separatore
            $sepCount = $this->fullAuthority->getSubjectCount('d931') - 1;
            // Loop per gli elementi "s3" ed "sa" del campo "d931" (Componenti nome soggetto)
            foreach ($this->fullAuthority->auth_turbomarc->d931 as $title) {
                $record['S']['nome'] = htmlspecialchars((string) $title->sa);
                $record['S']['link'] = (string) $title->s3;
                //Separatore per visualizzazione
                if ($sepCount > 0) {
                    $record['S']['sep'] = ' - ';
                    $sepCount--;
                } else {
                    $record['S']['sep'] = '';
                }
                $doSet->push(new ArrayData($record));
            }
        }
        return $doSet;
    }

    /* NOTE ************************************************************************* */

    private $authSubjectNotesFirst;
    private $authSubjectNotesOthers;

    public function AuthoritySubjectCheckNotes() {
        global $sc;
        $arrayNote = array(explode(',', $sc->getParameter('authority_opera_type.index')));
        foreach ($arrayNote[0] as $value) {
            if (isset($this->fullAuthority->auth_turbomarc->$value)) {
                return true;
            }
        }
        return false;
    }

    public function AuthoritySubjectNotes() {
        global $sc;
        $arrayNote = array(explode(',', $sc->getParameter('authority_opera_type.index')));
        $doSet = new DataObjectSet();
        $record = array('n' => array());
        $first = TRUE;
        foreach ($arrayNote[0] as $value) {
            if (isset($this->fullAuthority->auth_turbomarc->$value->sa)) {
                $record['n']['nota'] = htmlspecialchars((string) $this->fullAuthority->auth_turbomarc->$value->sa);
                if ($first == true) {
                    if ($this->AuthoritySubjectNotesOverOne() == true) {
                        $record['n']['link'] = '<a href="javascript:void(0)" id="authSubjectNotesOthersExpander">[' . _t('Catalog.AUTH_EXPANDER_OPEN') . ' (' . ($this->AuthoritySubjectNotesCount() - 1) . ')]</a>';
                    } else {
                        $record['n']['link'] = '';
                    }
                    $doFirst = new DataObjectSet();
                    $doFirst->push(new ArrayData($record));
                    $this->authSubjectNotesFirst = $doFirst;
                    $first = FALSE;
                } else {
                    $doSet->push(new ArrayData($record));
                }
            }
        }
        $this->authSubjectNotesOthers = $doSet;
    }

    public function AuthoritySubjectNotesFirst() {
        return $this->authSubjectNotesFirst;
    }

    public function AuthoritySubjectNotesOverOne() {
        if ($this->AuthoritySubjectNotesCount() > 1) {
            return true;
        }
        return false;
    }

    public function AuthoritySubjectNotesOthers() {
        return $this->authSubjectNotesOthers;
    }

    public function AuthoritySubjectNotesCount() {
        global $sc;
        $arrayNote = array(explode(',', $sc->getParameter('authority_opera_type.index')));
        $i = 0;
        foreach ($arrayNote[0] as $value) {
            if (isset($this->fullAuthority->auth_turbomarc->$value->sa)) {
                $i++;
            }
        }
        return $i;
    }

    /* FINE NOTE ******************************************************************** */

    /*     * ************************************************* FINE AUTHORITY SOGGETTO ****************************************************** */

    /**
     * @return int
     */
    public function StartPos() {
        $start = isset($_GET['start']) ? $_GET['start'] : 0;
        return $start + 1;
    }

    /**
     * @return int
     */
    public function EndPos() {
        return ($this->NextPageLink() == false) ? $this->getNumFound() :
                $this->StartPos() + $this->PageSize() - 1;
    }

    /**
     * @return int|string
     */
    public function PageSize() {
        return (isset($_GET['page'])) ? intval($_GET['page']) : $this->getDefaultResultsPerPage();
    }

    /**
     * @param int $start
     * @return string
     */
    public function PaginationLink($start = 0) {
        $raw = $_SERVER['REQUEST_URI'];
        $pieces = explode('?', $raw);
        $qs = isset($pieces[1]) ? $pieces[1] : '';

        $args = array();
        parse_str($qs, $args);

        unset($args['start']);
        if ($start) {
            $args['start'] = $start;
        }

        return $pieces[0] . (count($args) ? '?' . htmlspecialchars(http_build_query($args)) : '');
    }

    /**
     * @return bool|string
     */
    public function NextPageLink() {
        if (!$this->dataRecord->hasUndefinedTotalResults() && $this->StartPos() + $this->PageSize() > $this->getNumFound()) {
            return false;
        }

        return $this->PaginationLink($this->StartPos() + $this->PageSize() - 1);
    }

    /**
     * @return bool|string
     */
    public function PrevPageLink() {
        if ($this->StartPos() - 1 < $this->PageSize()) {
            return false;
        }

        return $this->PaginationLink($this->StartPos() - $this->PageSize() - 1);
    }

    /**
     * @return bool|string
     */
    public function FirstPageLink() {
        return $this->StartPos() == 1 ? false : $this->PaginationLink(0);
    }

    /**
     * @return bool|string
     */
    public function LastPageLink() {
        if ($this->dataRecord->hasUndefinedTotalResults()) {
            return false;
        }

        if ($this->isLastPage()) {
            return false;
        }

        $lastPos = floor(($this->getNumFound() / $this->PageSize())) * $this->PageSize();

        return $this->PaginationLink($lastPos);
    }

    /**
     * @return bool
     */
    public function isLastPage() {
        return $this->StartPos() + $this->PageSize() > $this->getNumFound();
    }

    /**
     * @return string
     */
     public function getCurrentSortingRule() {
        if ($this->SortFields) {
            return (LQConfig::get('sortFields', $this->getCurrentSorting())) ? LQConfig::get('sortFields', $this->getCurrentSorting(), 'rule')."-".explode(',', $this->SortFields)[0] : "base-".explode(',', $this->SortFields)[0];
        }
        return (LQConfig::get('sortFields', $this->getCurrentSorting())) ? LQConfig::get('sortFields', $this->getCurrentSorting(), 'rule') : "base";
    }


    /**
     * @return string
     */
    public function getCurrentSorting() {
        return $rule = (isset($_GET['sort']) && LQConfig::get('sortFields', $_GET['sort'])) ? $_GET['sort'] : '';
    }

    /**
     * Returns the list of sort fields
     *
     * @return DataObjectSet
     */
    public function SortFieldsDO() {
        $currentSorting = $this->getCurrentSorting();
        $configuration = LQConfig::get('sortFields');
        $sortFields = new DataObjectSet();

        $pageSortFields = $this->dataRecord->SortFields();

        if (!in_array($currentSorting, $pageSortFields)) {
            array_unshift($pageSortFields, $currentSorting);
        }

        foreach ($pageSortFields as $sortingField) {
            if (!isset($configuration[$sortingField]))
                continue;

            $sort = $configuration[$sortingField];

            $raw = $_SERVER['REQUEST_URI'];

            if ($currentSorting != "" && substr_count($raw, "sort=$currentSorting")) {
                $link = preg_replace("/(&|\?)sort=$currentSorting/", "$1sort=$sortingField", $raw);
            } else {
                $link = $raw . "&sort=$sortingField";
            }

            $label = _t('LQFields.SORT_' . strtoupper($sortingField), $sort['label']);

            $sortFields->push(new DataObject(array(
                'Selected' => $currentSorting == $sortingField,
                'Label' => $label,
                'Link' => htmlspecialchars($link),
                'Value' => $sortingField
            )));
        }
        return $sortFields;
    }

    /**
     * Returns the list of pagination choices
     * @return DataObjectSet
     */
    public function PaginationChoices() {
        $choices = new DataObjectSet();
        $current = $this->PageSize();

        foreach ($this->getResultsPerPageChoices() as $choice) {
            $choices->push(new ArrayData(array(
                'Value' => $choice,
                'Active' => $choice == $current
            )));
        }

        return $choices;
    }

    /**
     * @return DataObjectSet
     */
    public function ListTypes() {
        $types = array();
        $qs = htmlspecialchars($this->getSolrQueryMapper()->getQueryString(true));

        $currentType = $this->getViewType();

        $types[] = new ArrayData(array(
            'URL'
            =>
            $this->getSearchBaseUrl('dtl') . '?'
            . $qs, 'Label'
            => _t('View.DETAIL', 'Detail View'), 'id' => 'dtl',
            'active' => 'dtl' == $currentType
        ));
        $types[] = new ArrayData(array(
            'URL'
            =>
            $this->getSearchBaseUrl('lst') . '?'
            . $qs, 'Label'
            => _t(
                    'View.LIST', 'List View'
            ), 'id' => 'lst', 'active' => 'lst' == $currentType
        ));
        $types[] = new ArrayData(array(
            'URL'
            =>
            $this->getSearchBaseUrl('grid') . '?'
            . $qs, 'Label'
            => _t('View.COVER', 'Cover View'), 'id' => 'grid',
            'active' => 'grid' == $currentType
        ));

        return new DataObjectSet($types);
    }

    /**
     * @param bool $viewType
     * @param bool $action
     *
     * @return string
     */
    public function getSearchBaseUrl($viewType = false, $action = false) {
        if (false === $action) {
            $action = $this->getRequest()->param('Action');
        }
        if (empty($action)) {
            $action = 'search';
        }
        if (false === $viewType) {
            $viewType = $this->getViewType();
        }

        $url = $this->AbsoluteLink($action) . '/';

        $url .= $viewType;

        return htmlspecialchars($url);
    }

    /**
     * @param bool $viewType
     * @param bool $action
     *
     * @return string
     */
    public function getFacetsListBaseUrl($viewType = false, $action = false) {
        $url = $this->getSearchBaseUrl($viewType, $action);

        if ('/' != $url[strlen($url) - 1]) {
            $url .= '/';
        }
        return $url . 'facetsnav';
    }

    /**
     * Restituisce il tipo di vista (lst, grid o dtl) in base all'url della
     * richiesta.
     * @return string
     */
    public function getViewType() {
        $viewType = $this->getRequest()->param('ViewType');
        
        if (!in_array($viewType, array('lst', 'grid', 'dtl','lst'))) {
            return $this->DefaultViewType;
        }
        
        if ($viewType) {
            return $viewType;
        }
        return $this->DefaultViewType;
    }

    /**
     * The only way I've found to check in templates the type of view
     * inside a control...
     * Because if I am inside a control, the following template lines
     * <code>
     *  <% if Top.ViewType=lst %>
     *    //Do stuff
     *  <% end_if %>
     * </code>
     * do not work, because the expression Top.ViewType is too complicated for ss template
     * engine. (If we are in the root scope, <% if ViewType=lst %> works)
     *
     * @return bool
     */
    public function isViewLst() {
        return $this->getViewType() == 'lst';
    }

    /**
     * @see isViewLst()
     * @return bool
     */
    public function isViewDtl() {
        return $this->getViewType() == 'dtl';
    }

    /**
     * @see isViewLst()
     * @return bool
     */
    public function isViewGrid() {
        return $this->getViewType() == 'grid';
    }

    /**
     * Return the search type
     * @return string $searchType
     */
    public function SearchType() {
        $searchType = 'simple';
        if (in_array(strtolower($this->getRequest()->param('Action')), array('advanced', 'advancedform'))) {
            $searchType = 'advanced';
        }

        return $searchType;
    }

    /**
     * Show the rating controls or not?
     *
     * @return bool
     */
    public function ShowRatingControl() {
        return false;
    }

    public function extraDevToolbarButtons() {
        $buttons = array();

        $buttons['librarian'][] = new QueryParamDevToolbarLink('solrdebug', 'SolrDebug', array('solrdebug' => 1));

        return array_merge_recursive(parent::extraDevToolbarButtons(), $buttons);
    }

    /**
     * @param ManifestationRepository $manifestationRepository
     *
     * @return SearchPage_Controller
     */
    public function setManifestationRepository(ManifestationRepository $manifestationRepository) {
        $this->manifestationRepository = $manifestationRepository;

        return $this;
    }

    /**
     * @return ManifestationRepository
     */
    public function getManifestationRepository() {
        return $this->manifestationRepository;
    }

    public function setAuthorityRepository(AuthorityRepository $authorityRepository) {
        $this->authorityRepository = $authorityRepository;

        return $this;
    }

    public function getAuthorityRepository() {
        return $this->authorityRepository;
    }

    /**
     * @param ManifestationRepository $essentialManifestationRepository
     *
     * @return SearchPage_Controller
     */
    public function setEssentialManifestationRepository(ManifestationRepository $essentialManifestationRepository) {
        $this->essentialManifestationRepository = $essentialManifestationRepository;

        return $this;
    }

    /**
     * @return ManifestationRepository
     */
    public function getEssentialManifestationRepository() {
        return $this->essentialManifestationRepository;
    }

    /**
     * @param $name
     * @param SolrQueryMapper $mapper
     *
     * @return SearchPage_Controller
     */
    public function registerSolrQueryMapper($name, SolrQueryMapper $mapper) {
        $this->solrQueryMappers[$name] = $mapper;

        return $this;
    }

    public function CdfField() {
        $field = new CdfAdvancedSearchField();

        return $field->render();
    }

    /**
     * @param string|null $name
     *
     * @return SolrQueryMapper
     *
     * @throws InvalidArgumentException
     */
    public function getSolrQueryMapper($name = null) {
        if ($name === null) {
            $name = $this->getSearchMappingType();
        }

        if (!isset($this->solrQueryMappers[$name])) {
            throw new InvalidArgumentException("There is no SolrQueryMappers registered with name '$name'");
        }
        return $this->solrQueryMappers[$name];
    }

    /**
     * @param \SolrFacetsManager $facetsManager
     *
     * @return \SearchPage_Controller
     */
    public function setFacetsManager($facetsManager) {
        $this->facetsManager = $facetsManager;

        return $this;
    }

    /**
     * @return \SolrFacetsManager
     */
    public function getFacetsManager() {
        return $this->facetsManager;
    }

    /**
     * @param \SolrSearcher $solrSearcher
     *
     * @return \SearchPage_Controller
     */
    public function setSolrSearcher($solrSearcher) {
        $this->solrSearcher = $solrSearcher;

        return $this;
    }

    /**
     * @return \SolrSearcher
     */
    public function getSolrSearcher() {
        return $this->solrSearcher;
    }

    /**
     * @return array
     */
    public function getSolrFieldsConfiguration() {
        return $this->getContainer()->getParameter('lq.fields');
    }

    /**
     * @param array $defaultAdvsearchFields
     *
     * @return SearchPage_Controller The current instance
     */
    public function setDefaultAdvsearchFields($defaultAdvsearchFields) {
        $this->defaultAdvsearchFields = $defaultAdvsearchFields;

        return $this;
    }

    /**
     * @return array
     */
    public function getDefaultAdvsearchFields() {
        return $this->defaultAdvsearchFields;
    }

    /**
     * @param array $defaultAdvsearchOpenedFields
     *
     * @return SearchPage_Controller The current instance
     */
    public function setDefaultAdvsearchOpenedFields($defaultAdvsearchOpenedFields) {
        $this->defaultAdvsearchOpenedFields = $defaultAdvsearchOpenedFields;

        return $this;
    }

    /**
     * @return array
     */
    public function getDefaultAdvsearchOpenedFields() {
        return $this->defaultAdvsearchOpenedFields;
    }

    /**
     * Set DefaultResultsPerPage
     *
     * @param int $defaultResultsPerPage
     *
     * @return SearchPage_Controller The current instance
     */
    //public function setDefaultResultsPerPage(int $defaultResultsPerPage) {
    public function setDefaultResultsPerPage($defaultResultsPerPage) {
        $this->defaultResultsPerPage = $defaultResultsPerPage;

        return $this;
    }

    /**
     * Get DefaultResultsPerPage
     *
     * @return int
     */
    public function getDefaultResultsPerPage() {
        return $this->defaultResultsPerPage;
    }

    /**
     * Set ResultsPerPageChoices
     *
     * @param array $resultsPerPageChoices
     *
     * @return SearchPage_Controller The current instance
     */
    public function setResultsPerPageChoices(array $resultsPerPageChoices) {
        $this->resultsPerPageChoices = $resultsPerPageChoices;
        return $this;
    }

    /**
     * Get ResultsPerPageChoices
     *
     * @return array
     */
    public function getResultsPerPageChoices() {
        return $this->resultsPerPageChoices;
    }

    /**
     * The url prefix, used to construct active filters links
     * @return string
     */
    protected function getActiveFiltersUrlPrefix() {
        $raw = $_SERVER['REQUEST_URI'];
        return substr($raw, 0, strpos($raw, "?") + 1);
    }

    /**
     * Performs the request to media library and get the raw response.
     *
     * @param $searchString
     */
    private function getMLOLResponse($searchString) {
        $queryString = htmlspecialchars($this->getSearchText());

        $mlol = $this->getContainer()->get('mlol.connector');
        /* try {
          $response = $mlol->doSearch($queryString);
          } catch(Exception $e){
          return $this->jsonResponse(array('response_str' => $e->getMessage()));
          } */
        $response = $mlol->doSearch($queryString);
        return $response;
    }

    /**
     * Transform the response to an array
     *
     * @param $response
     * @return DataObjecty
     */
    private function parseMLOLResponse($response) {

        $data = new DataObject();

        $member = Member::currentUser();

        $data->Total = (string) $response->totale;
        $data->Results = new DataObjectSet();

        foreach ($response->tipologia as $tipologia) {
            $data->Results->push(new ArrayData(array(
                "icon" => (string) $tipologia->icona,
                "url" => (string) $tipologia->url_mlol . '&username=' . $member->Username,
                "name" => (string) $tipologia->nome,
                "total" => (string) $tipologia->risultati,
            )));
        }

        return $data;
    }

    /**
     * Return the results fetched from the MLOL service
     *
     * @return array
     */
    public function MLOLData() {

        if (!isset($this->cachedData))
            $this->cachedData = $this->parseMLOLResponse($this->getMLOLResponse($this->getSearchText()));

        return $this->cachedData;
    }

}
