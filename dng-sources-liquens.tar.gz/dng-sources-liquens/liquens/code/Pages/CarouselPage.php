<?php

class CarouselPage extends Page {

    public static $db = array(
        'Width' => 'DBInt',
        'Pause' => 'DBInt',
        'Selectors' => 'Boolean',
        'Pager' => 'Boolean',
        'AutoControls' => 'Boolean',
    );
    
    static $has_one = array(
        'TopWidgetArea' => 'WidgetArea',
        'SidebarWidgetArea' => 'WidgetArea',
        'BottomWidgetArea' => 'WidgetArea',
        'WidgetArea' => 'WidgetArea'
    );
    
    public static $has_many = array(
        'CarouselItems' => 'CarouselItem'
    );

    static $defaults = array(
        'Width' => 800,
        'Pause' => 3,
        'Selectors' => true,
        'Pager' => true,
        'AutoControls' => true,
    );

    function getCMSFields($params = NULL) {
        $fields = parent::getCMSFields();

        $fields->addFieldToTab('Root.Content.Carosello', new NumericField('Width', 'Larghezza massima consentita'));
        $fields->addFieldToTab('Root.Content.Carosello', new NumericField('Pause', 'Ritardo tra le slide (in secondi)'));
        $fields->addFieldToTab('Root.Content.Carosello', new CheckboxField('Pager', 'Mostra pallini per sequenza immagini'));
        $fields->addFieldToTab('Root.Content.Carosello', new CheckboxField('AutoControls', 'Mostra controlli automatici di avanzamento'));
        $fields->addFieldToTab('Root.Content.Carosello', new CheckboxField('Selectors', 'Visualizza frecce di avanzamento'));
        $fields->addFieldToTab('Root.Content.Carosello', new HasManyComplexTableField($this, 'CarouselItems', 'CarouselItem', 
                array(
                    'Title' => 'Titolo', 
                    'Description' => 'Descrizione',
                    'Active' => 'Attivo: 1 = SI, 0 = NO',
                    'Sort' => "Numero d'ordinamento",
                    'Link' => 'Link URL')));
        $fields->addFieldToTab("Root.Content.WidgetArea", new GridWidgetAreaEditor('WidgetArea'));
        $fields->insertFirst(new LiteralField('', (string) new ContentWidgetWarning($this, 'WidgetArea')));
        return $fields;
    }
    
}

class CarouselPage_Controller extends Page_Controller {

    static $allowed_actions = array();

    public function init() {
        parent::init();
    }

    public function getCarouselWidth() {
        return $this->Width;
    }

    public function getCarouselSelector() {
        return $this->Selectors;
    }

    public function getCarouselPause() {
        return $this->Pause * 1000;
    }

    public function getCarouselPager() {
        return $this->Pager;
    }

    public function getCarouselAutoControls() {
        return $this->AutoControls;
    }

    public function EventsWidget() {
        $eventsWidget = new EventsWidget();
        $eventsWidget->Limit = 15;

        return $eventsWidget;
    }

}
