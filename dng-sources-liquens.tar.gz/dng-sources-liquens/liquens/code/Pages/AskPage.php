<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Isacco Occhiali <isacco@comperio.it>
 */

class AskPage extends Page {
    
    public static $db = array();
   
    public static $has_one = array();

    static $allowed_children = array (
        'UserDefinedForm',
        'ChatPage'
    );

    static $can_be_root = true;
    
    function getCMSFields($params = NULL) {
        $fields = parent::getCMSFields();
        return $fields;
    }
}

class AskPage_Controller extends Page_Controller
{
    static $allowed_actions = array();

    public function init() {
        parent::init();
    }   
}
