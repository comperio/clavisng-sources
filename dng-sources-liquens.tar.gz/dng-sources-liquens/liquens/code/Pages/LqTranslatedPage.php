<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

/**
 * This class handles the overloading of Translatable behavior
 */

class LqTranslatedPage extends SiteTree
{
    /**
     * The array of properties that have to be mantained equal to those
     * in the default language version of the object.
     *
     * @var array
     */
    public static $fields_to_mantain = array(
        'ID',
        'ParentID',
        'URLSegment',
    );

    /**
     * Set this var to true to enable translatable overloading
     *
     * @var bool
     */
    public static $enabled = false;

    /**
     * Automatically augment  the object with translation if self::enabled
     * is set to true
     *
     * @param null $record
     * @param bool $isSingleton
     */
    public function __construct($record = null, $isSingleton = false)
    {
        parent::__construct($record, $isSingleton);

        if (static::$enabled)
            $this->augmentWithTranslation();

        print('');
    }

    /**
     * Returns the array of fieldname->value couples fetched from the
     * current object
     *
     * @return array
     */
    public function getValuesToMantain()
    {
        $values = array();

        foreach(static::$fields_to_mantain as $fieldName) {
            $value = null;
            if (isset($this->$fieldName)){
                $value = $this->$fieldName;
            }

            $values[$fieldName] = $value;
        }

        return $values;
    }

    /**
     * The heart of the class. It changes the current dataobject properties to the
     * properties of the translation, preserving the ID, the ParentID and
     * the URLSegment, and setting the Locale to the default locale.
     *
     * @return LqTranslatedPage
     */
    public function augmentWithTranslation()
    {
        static $fetchTranslation = true;

        if (!self::$enabled) return;

        $oldLocale = $this->Locale;

        if ($fetchTranslation){
            $fetchTranslation = false;

            if ($oldLocale != i18n::get_locale())
                $translatedDataRecord =
                    $this->getTranslation(i18n::get_locale());

            if (isset($translatedDataRecord) && $translatedDataRecord) {
                $valuesToMantain = $this->getValuesToMantain();
                $this->update($translatedDataRecord->toMap());
                $this->update($valuesToMantain);
            }

            elseif(i18n::default_locale() != $oldLocale){
                $defTranslation = $this->getTranslation(i18n::default_locale());
                if ($defTranslation){
                       $this->update($defTranslation->getValuesToMantain());
                }
            }
            $this->Locale = Translatable::default_locale();
            $fetchTranslation = true;
        }

        return $this;
    }

    /**
     * Because the class change the Locale of the DataRecord to the default Locale,
     * we need to set the right locale before getting the SiteConfig to obtain
     * the right SiteConfig translation.
     *
     * @return bool|SiteConfig
     */
    public function getSiteConfig()
    {
        $oldLocale = $this->Locale;
        $this->Locale = LangController::get_current_locale();
        $config = parent::getSiteConfig();
        $this->Locale = $oldLocale;

        return $config;
    }
}

/**
 * Controller for the LqTranslatedPage
 */
class LqTranslatedPage_Controller extends ContentController
{
    public function __construct($dataRecord = null)
    {

        parent::__construct($dataRecord);
    }
    /**
     * Set the Translatable current locale before handling the request. This is necessary
     * because the ModelAsController (line 136), that is called before this one, set the Translatable
     * current locale to the DataObject locale.
     *
     * @param $request
     * @return SS_HTTPResponse
     */
    public function handleRequest(SS_HTTPRequest $request)
    {

        $result =  parent::handleRequest($request);
        return $result;
    }


    public function init()
    {
        parent::init();

        if (isset($_GET['change-lang']))
            LangController::change_language($_GET['change-lang']);

        //Do the same redirect if the lang segment was superflous
        if (LangController::$lang == i18n::get_lang_from_locale(LangController::get_ignoredurl_locale()))
            LangController::change_language(LangController::$lang);
    }

    /**
     * Get the locale url's segment
     *
     * @return string
     */
    public function getLocaleSegment()
    {
        return LangController::localeSegment();
    }

    /**
     * Return the path that annhilates the locale segment in the url
     * I.e., if the url is /it/opac/search,
     * it returns '../'
     *
     * @return string
     */
    public function getLocaleAntisegment()
    {
        return LangController::localeAntisegment();
    }

    /**
     * Returns a DataObjectSet representing the links for changing the language
     * of the current page
     *
     * @return DataObjectSet
     */
    public function getLangLinks()
    {
        $links = new DataObjectSet();

        foreach (Translatable::get_allowed_locales() as $locale){
            $lang = i18n::get_lang_from_locale($locale);

            $_GET['change-lang'] = $lang;

            $request = $this->getRequest();

            if ($request)
                $url = $this->getRequest()->getURL();
            else
                $url = '';

            if ($url == 'home')
                $url = '';

            $links->push(new DataObject(array(
                'URL' => $url . '?' . htmlspecialchars(http_build_query(array_diff_key($_GET, array('url' => '')))),
                'Text' => ucfirst(i18n::get_language_name($lang, true)),
                'LocaleCode' => $locale
            )));
        }

        return $links;
    }

    /**
     * Returns the label for the current language
     *
     * @return string
     */
    public function getCurrentLanguage()
    {
        return ucfirst(i18n::get_language_name(
            i18n::get_lang_from_locale(LangController::get_current_locale()),
            true
        ));
    }

    /**
     * Verifica se si tratta di una lingua rtl o no
     * 
     * @global type $sc
     * @return string
     */
    public function getLanguageDirection() {
        global $sc;
        $dir = $sc->getParameter('rtl_locales');
        if ((is_array($dir)) && (in_array(i18n::get_lang_from_locale(LangController::get_current_locale()), $dir))) {
            return "rtl";
        }
        return "auto";
    }

    /**
     * Returns the language code
     *
     * @return string
     */
    public function getLanguageCode()
    {
        return i18n::get_lang_from_locale(LangController::get_current_locale());
    }
}
