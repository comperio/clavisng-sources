<?php

/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

/**
 * Questa classe rapresenta la pagina della Manifestation, detta anche
 * pagina del Dettaglio.
 */
class ManifestationPage extends Page {

    static $has_one = array(
        'SearchPage' => 'SearchPage'
    );
    static $allowed_children = array(
        'none' => 'none'
    );

    /**
     * @var SolrResponse
     */
    private $solrResponse;

    /**
     * @var DOMDocument
     */
    private $turbomarcXmlDOM;

    /**
     * @var Manifestation
     */
    private $manifestation;

    /**
     * @param $numericalManId
     * @return bool|string
     */
    public static function getDefaultUrl($numericalManId) {
        if (!$numericalManId)
            return false;

        $trineId = LQConfig::get('solrDatabase') . ':' .
                LQConfig::get('solrCatalog') . ':' . $numericalManId;

        return Manifestation::default_detail_url($trineId);
    }

    /**
     * Return Manifestation url
     *
     * @param string $manifestationID
     * @return string
     */
    public function getUrlFromId($manifestationID = '') {
        return $this->SearchPage->Link('detail') . '/' . $manifestationID;
    }

    /**
     * @return DOMDocument
     */
    public function getTurbomarcDOM() {
        return $this->turbomarcXmlDOM;
    }

    /**
     * @return string
     */
    public function getTitle() {
        if (!is_null($this->getManifestation()))
            return strip_tags(trim($this->getManifestation()->title_and_author));
    }

    /**
     * @return FieldSet
     */
    public function getCMSFields($params = NULL) {
        $fields = parent::getCMSFields();

        $fields->addFieldToTab(
                'Root.Content.Main', new TextField('ManifestationID', _t(
                                'SearchPage.ManifestationID', 'Manifestation ID - <em>Database:Catalog:ID</em>'
                        ))
        );

        return $fields;
    }

    /**
     * 
     * @param type $BID
     * @return type
     */
    public function getManifestationIDByBID($BID) {
        return $this->getContainer()->get('manifestation_repo')->getOneByBID($BID);
    }

    /**
     * Get or build the manfiestation object through ManifestationDrivers
     *
     * @return Manifestation
     */
    public function getManifestation() {
        if (!$this->manifestation) {

            $this->manifestation = $this->getContainer()->get('manifestation_repo')->getOneById($this->ManifestationID);
        }
        return $this->manifestation;
    }

}

class ManifestationPage_Controller extends Page_Controller {

    /**
     * @var ManifestationPage
     */
    public $page;

    /**
     * @var SearchPage_Controller
     */
    public $searchPageController;

    /**
     * @var array
     */
    public static $url_handlers = array(
        'view/$ManifestationID!' => 'view',
        'badge/$ManifestationID!' => 'badge',
        'embed/$ManifestationID!' => 'embed',
        '$ManifestationID!/rates' => 'rates',
        '$ManifestationID!/items' => 'items',
        '$ManifestationID!/comments-tab' => 'commentsTab',
        '$ManifestationID!' => 'redirectToview', //Legacy urls
        'json/$ManifestationID!' => 'json'
    );

    /**
     * @var array
     */
    public static $allowed_actions = array(
        'view',
        'badge',
        'embed',
        'rates',
        'items',
        'commentsTab',
        'redirectToView',
        'json'
    );

    /**
     * Crea meta opportuni per Facebook
     * 
     * @return type
     */
    public function MetaTags() {
        $tags = $this->arrayTags;
        unset($tags['og:description']);
        if ($this->page->Manifestation->abstract != '')
            $tags['og:description'] = '<meta property="og:description" content="' . $this->page->Manifestation->abstract . '" />';
        else
            $tags['og:description'] = '<meta property="og:description" content="' . $this->page->Manifestation->full_title . '" />';
        return join('', $tags);
    }

    /**
     * Propertie initialization
     * @return void
     */
    public function init() {
        if ($this->dataRecord->ManifestationID)
            $this->page = $this->dataRecord;
        else
            $this->page = new ManifestationPage();

        parent::init();
    }

    /**
     * Main action
     *
     * @return string
     */
    public function view() {
        if (strtolower(explode(":", $this->request->param('ManifestationID'))[0]) == "bid") {
            $this->page->ManifestationID = $this->page->getManifestationIDByBID($this->request->param('ManifestationID'));
        } else {
            $this->page->ManifestationID = $this->request->param('ManifestationID');
        }
        $manifestation = $this->page->getManifestation();
        if (!$manifestation) {
            $this->httpError(404);
        }
        return $this->renderWith(array('ManifestationPage', 'Page'));
    }

    /**
     * Badge view action
     *
     * @return string
     */
    public function badge() {
        $this->page->ManifestationID = $this->request->param('ManifestationID');

        $manifestation = $this->page->getManifestation();

        if (!$manifestation) {
            $this->httpError(404);
        }

        $data = $this->getBadgeOptions($this->getRequest());
        //91 is: footer hieght + footer border + footer margin-top + footer padding-top .manifestation-badge-body paddings + .manifestation-badge-paddings
        $data['innerHeight'] = $data['height'] - 91;

        foreach ($data as $key => $value)
            $manifestation->$key = $value;

        return $this->customise($data)
                        ->renderWith(array('ManifestationBadge'));
    }

    /**
     * Badge view action
     *
     * @return string
     */
    public function embed() {
        return $this->getBadgeIframe();
    }

    /**
     * @param bool $empty
     * @return string
     */
    public function getBadgeIframe($empty = false) {
        $badgeUrl = Director::absoluteBaseURL() . 'opac/detail/badge/' . $this->getRequest()->param('ManifestationID');

        $data = $this->getBadgeOptions($this->getRequest());
        $badgeUrl .= '?' . http_build_query(array_diff_key($data, array('width' => '')));
        $data['empty'] = $empty;
        $data['BadgeURL'] = $badgeUrl;

        return $this->customise($data)->renderWith(array('ManifestationEmbedCode'));
    }

    /**
     * Rates html snippet
     *
     * @param SS_HTTPRequest $request
     *
     * @return string
     */
    public function rates(SS_HTTPRequest $request) {
        $titleId = $request->param('ManifestationID');

        $manifestation = new Manifestation();
        $manifestation->trine_id = $titleId;

        $enrichment = new DngManifestationEnrichment(array('comments' => true, 'average_rating' => true));
        $enrichment->setRatingService($this->getContainer()->get('rating.service'));

        $enrichment->fillManifestation($manifestation);

        return $manifestation->renderWith('ManifestationRates');
    }

    /**
     * Items html snippet
     *
     * @param SS_HTTPRequest $request
     *
     * @return string
     */
    public function items(SS_HTTPRequest $request) {
        $titleId = $request->param('ManifestationID');
        $this->page->ManifestationID = $titleId;

        /** @var $repository ManifestationRepository */
        $repository = $this->getContainer()->get('manifestation_repo_essential');
        /** @var ManifestationRenderingProvider $renderingProvider */
        $renderingProvider = $this->getContainer()->get('rendering_provider.items');

        $manifestation = $repository->getOneById($titleId);

        return $renderingProvider->getRendering($manifestation)->render($manifestation);
    }

    /**
     * Comments tab html snippet
     *
     * @param SS_HTTPRequest $request
     *
     * @return string
     */
    public function commentsTab(SS_HTTPRequest $request) {
        $titleId = $request->param('ManifestationID');
        $this->page->ManifestationID = $titleId;

        /** @var $repository ManifestationRepository */
        $repository = $this->getContainer()->get('manifestation_repo_essential');

        $manifestation = $repository->getOneById($titleId);
        return $manifestation->renderWith('ManifestationCommentsInner');
    }

    /**
     * Redirecto url of the type detail/manid to detail/view/manid
     * With a permanently moved status code (301)
     *
     * @param \SS_HTTPRequest $request
     * @return void
     */
    public function redirectToView(SS_HTTPRequest $request) {
        $url = str_replace('/detail/', '/detail/view/', $request->getUrl());

        Director::redirect($url, 301);
    }

    /**
     * Returns formatted Turbomarc for display purposes
     *
     * @return bool|string
     */
    public function Turbomarc() {
        if (Director::isDev()) {
            return $this->page->getManifestation()->getTurbomarc();
        }
        return false;
    }

    /**
     * @return string
     */
    public function Title() {
        return $this->page ? $this->page->getTitle() : '';
    }

    /**
     * Since SS templates do not allows too much complex "ifs",
     * this method reads the activetab from the configuration, and returns the string "in"
     * if the given tab is the activetab, an empty string otherwise
     *
     * @param $tabname  The name of the tab, as it appears in the configuration
     * @return string
     */
    public function getTabActiveClass($tabname) {
        return $this->getContainer()->getParameter('manifestation_activetab') == $tabname ? 'in' : '';
    }

    /**
     * @return PanelSet
     */
    public function getPanels() {
        $man = $this->getManifestation();
        if ($man->isExtra())
            $service = 'manifestation_panelset_extra';
        elseif ($man->isMLOL())
            $service = 'manifestation_panelset_mlol';
        elseif ($man->isShard())
            $service = 'manifestation_panelset_shard';
        else
            $service = 'manifestation_panelset';
        $panels = $this->getContainer()->get($service);

        foreach ($panels as $panel) {
            $panel->Manifestation = $man;
        }

        return $panels;
    }

    /**
     * Return ForumLastPosts rendered
     *
     * @param null|string $manid an optional manifestation id. If no is given, take the one of the manifestation page
     *
     * @return string
     */
    public function ForumLastPosts($manid = null) {
        $widget = new ForumLastPosts();
        $widget->Title = _t('Detail.REVIEWS_LASTTITLE', 'Last comments');
        $widget->NoPostMessage = _t('Detail.REVIEWS_NOCOMMENTS', 'There are no comments inserted yet');
        $widget->AvatarSize = 'small';
        $widget->ManifestationID = isset($manid) ? $manid : $this->page->ManifestationID;

        return $widget;
    }

    /**
     * Get the manifestation object
     *
     * @return Manifestation
     */
    public function getManifestation() {
        static $manifestation;

        if (!isset($manifestation)) {
            $manifestation = $this->page->getManifestation();
            $manifestation->comments_count = $this->ForumLastPosts()->TotalPosts();
        }

        return $manifestation;
    }

    /**
     * Show the rating controls or not?
     *
     * @return bool
     */
    public function ShowRatingControl() {
        if ($manifestation = $this->page->getManifestation()) {
            return $manifestation->solr_catalog != 'extra';
        }
        return true;
    }

    /**
     * BBcode help
     * @return DataObjectSet
     */
    public function BBTags() {
        return BBCodeParser::usable_tags();
    }

    /**
     * {@inheritdoc}
     */
    public function extraDevToolbarButtons() {
        $extra = array();

        if (!$this->page->getManifestation())
            return $extra;

        $extra['librarian'] = array(
            new StaticUrlToolbarLink('dng-xml', 'Generated XML', 'data/json/manifestation/' . $this->getManifestation()->getTrineId()),
            new StaticUrlToolbarLink('dng-xml', 'Turbomarc', 'data/xml/turbomarc/' . $this->getManifestation()->getTrineId()),
        );

        $container = $this->getContainer();
        $ilsUrl = $container->getParameter('ils.url');

        if ($ilsUrl) {
            $ilsManifestationUrl = str_replace(
                    '{manifestation_id}', $this->page->getManifestation()->getId(), $ilsUrl . $container->getParameter('ils.manifestation_url')
            );

            $extra['librarian'][] = new StaticUrlToolbarLink('dng-external-manifestation', 'View in the ILS', $ilsManifestationUrl);
        }

        return array_merge_recursive(parent::extraDevToolbarButtons(), $extra);
    }

    /**
     * Fetch and sanitize the list of options for the manifestation badge
     *
     * @param SS_HTTPRequest $request
     *
     * @return array
     */
    private function getBadgeOptions(SS_HTTPRequest $request) {
        $coversize = strip_tags($request->getVar('coversize'));
        if (!in_array($coversize, array('small', 'normal', 'large')))
                $coversize = 'normal';
        return array(
            'width' => $request->getVar('width') ? strip_tags((int) $request->getVar('width')) : 600,
            'height' => (int) $request->getVar('height') ? strip_tags((int) $request->getVar('height')) : 300,
            'showabstract' => (int) $request->getVar('showabstract') ? 1 : 0,
            'coversize' => $coversize
        );
    }

}
