<?php

/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */
class LibraryMainPage extends Page {

    /**
     * The field to check clavis importing of library time table
     * @var Boolean
     */
    public static $db = array(
        "LibraryLat" => "DngDecimal(10,7)",
        "LibraryLng" => "DngDecimal(10,7)",
        "HideSearchBox" => "Boolean",
        "HideEvents" => "Boolean"
    );
    public static $defaults = array(
        "HideSearchBox" => false,
        "HideEvents" => false
    );
    public static $has_one = array(
        'LibraryFeaturedImage' => 'Image',
        'LibraryObject' => 'LibraryDataObject',
        'ContentWidgetArea' => 'WidgetArea',
        'SidebarWidgetArea' => 'WidgetArea',
        'WidgetArea' => 'WidgetArea',
    );

    /**
     * @var array
     */
    static $belongs_many_many = array(
        'LibrariesMapWidgets' => 'LibrariesMapWidget',
    );
    static $indexes = array(
        'LibraryObjectID' => true,
    );
    static $allowed_children = array(
        'LibraryPage',
        'LibraryStaffPage',
        'Calendar',
        'LibraryTimeTablePage',
        'ShelfPage',
        'WidgetPage',
        'UserDefinedForm',
//        'SearchPage'
    );
    static $can_be_root = false;
    static $default_sort = "IF(MenuTitle IS NULL, Title, MenuTitle)";

    public function getCMSFields($params = NULL) {
        $fields = parent::getCMSFields();

        $configurationTab = $fields->findOrMakeTab('Root.Configurazione');
        $configurationTab->push(new FormSectionTitle(_t('LibraryMainPage.LINKED_LIBRARY')));

        $libraryMap = array();
        if ($libraryObjects = DataObject::get('LibraryDataObject')) {
            $libraryMap = $libraryObjects->toDropdownMap('ID', 'ShortName', _t('DropdownField.CHOOSE'), true);
        }

        $libraryDropdown = new DropdownField(
                'LibraryObjectID', 'Seleziona la biblioteca da associare a questa pagina', $libraryMap
        );

        $configurationTab->push($libraryDropdown);
        if ($this->LibraryObjectID) {
            $library = $this->LibraryObject();

            $configurationTab->push(
                    new LiteralField('', "<a href='admin/libraries/LibraryDataObject/{$library->ID}/edit' style='font-size: 1.2em'>Modifica la bilbioteca associata ({$library->FullName})</a>"
            ));
        }

        $configurationTab->push(new FormSectionTitle(_t('LibraryMainPage.SEARCH')));
        $configurationTab->push(new CheckboxField('HideSearchBox', _t('LibraryMainPage.HIDESEARCHBOX')));
        $configurationTab->push(new CheckboxField('HideEvents', _t('LibraryMainPage.HIDEEVENTS')));

        $fields->addFieldToTab('Root.Content.Immagini', new LiteralField('', _t('LibraryMainPage.LIBRARYFEATUREDIMAGE_DESC')));
        $fields->addFieldToTab('Root.Content.Immagini', new ImageField("LibraryFeaturedImage", ''));

        $fields->addFieldToTab("Root.Content.WidgetArea", new GridWidgetAreaEditor('WidgetArea'));

        $fields->insertFirst(new LiteralField('', (string) new ContentWidgetWarning($this, 'WidgetArea')));

        return $fields;
    }

    /**
     * @return Library
     */
    public function getLibrary() {
        /** @var $repo LibraryRepository */
        $repo = $this->getContainer()->get('library.repository');

        return $repo->getByLibraryDataObject($this->LibraryObject());
    }

    /**
     * @return ArrayData
     */
    public function getViewableLibrary() {
        return new ViewableObject($this->getLibrary());
    }

    /**
     * @return SingleLibraryMapWidget
     */
    public function getLibraryMapWidget() {
        $libraryObject = $this->LibraryObject();

        if ((float) $libraryObject->Latitude == 0.0 || (float) $libraryObject->Longitude == 0.0)
            return false;

        $widget = new SingleLibraryMapWidget();
        $widget->Title = '';
        $widget->AllLibraries = false;
        $widget->CenterLat = $libraryObject->Latitude;
        $widget->CenterLong = $libraryObject->Longitude;
        $widget->LibraryObjects()->add($libraryObject);
        $widget->Width = '100%';
        $widget->Height = '20em';
        $widget->ZoomLevel = 15;
        
        $widget->GoogleMaps = DataObject::get_one('SiteConfig')->GoogleMaps;
        $widget->GoogleKey = DataObject::get_one('SiteConfig')->GoogleKey;
        
        $widget->initView();

        return $widget;
    }

    /**
     * {@inheritdoc}
     */
    public function getPageTemplates() {
        $templates = parent::getPageTemplates();
        $templates[] = new LibraryMainPageTemplate('WidgetArea');
        $templates[] = new LibraryMainPageChildrenTemplate();

        return $templates;
    }

}

class LibraryMainPage_Controller extends Page_Controller {

    /**
     * {@inheritdoc}
     */
    public static $allowed_actions = array(
        'pageList',
        'eventList',
        'id',
        'index',
        'info'
    );

    public function index() {
        return $this->renderWith(array('LibraryMainPage', 'LibraryPage', 'Page'));
    }

    public function info() {
        return $this->renderWith(array('LibraryMapInfo'));
    }

    /**
     * Redirect to the librarymainpage Using the LibraryObjectID
     */
    public function id() {
        $page = DataObject::get_one('LibraryMainPage', 'LibraryObjectID = ' . (int) $this->request->param('ID'));
        if ($page) {
            Director::redirect($page->Link());
        } else {
            $this->httpError(
                    401, _t('LibraryMainPage.LIBRARYNOTFOUND', 'Library not found in Liquens database')
            );
        }
    }

    /**
     * @return array
     */
    public function extraDevToolbarButtons() {
        $library = $this->LibraryObject();
        $extraButtons = array();

        if ($library) {
            $extraButtons['librarian'][] = new StaticUrlToolbarLink(
                    'edit-library-object', 'Edit Library', "admin/libraries/LibraryDataObject/{$library->ID}/edit"
            );
        }

        $container = $this->getContainer();
        $ilsUrl = $container->getParameter('ils.url');
        $externalLibraryID = $this->getLibrary()->getExternalID();

        if ($ilsUrl) {
            $ilsLibraryUrl = str_replace(
                    array('{external_source}', '{external_id}'), array('CLAVIS', $externalLibraryID), $ilsUrl . $container->getParameter('ils.library_url')
            );

            $extraButtons['librarian'][] = new StaticUrlToolbarLink('dng-external-library', 'View in the ILS', $ilsLibraryUrl);
        }

        return array_merge_recursive(parent::extraDevToolbarButtons(), $extraButtons);
    }

    /**
     * @return array
     */
    public function getBodyClasses() {
        $classes = array('libmainpage-id-' . $this->ID);

        return array_merge(parent::getBodyClasses(), $classes);
    }
    
    public function getRawViewLibrariesContacts() {
        if (DataObject::get_one('SiteConfig')->RawViewLibrariesContacts == '1')
            return true;
        return false;
    }

}
