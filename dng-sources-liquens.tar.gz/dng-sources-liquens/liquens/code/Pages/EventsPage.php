<?php

/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class EventsPage extends Page {
    
}

class EventsPage_Controller extends Page_Controller {

    static $allowed_actions = array(
        'rss'
    );

    /**
     * @var int
     */
    private $eventsPerPage = 25;

    /**
     * Main EventsPage action
     *
     * @param SS_HTTPRequest $request
     * @return string
     */
    public function index(SS_HTTPRequest $request) {
        return $this->renderWith(array('EventsPage', 'Page'));
    }

    public function rss() {
        $xml = str_replace('&nbsp;', '&#160;', $this->renderWith('EventsPageRSS'));
        $xml = preg_replace('/<!--(.|\s)*?-->/', '', $xml);
        $xml = trim($xml);
        HTTP::add_cache_headers();

        $response = new SS_HTTPResponse($xml);
        $response->addHeader("Content-type", "text/xml");

        return $response;
    }

    private $eventsList;

    /**
     * Returns the set of events to display
     *
     * @param int $limit
     * @param null|string $orderBy
     * @return DataObjectSet A DataObjectSet of CalendarEvent objects
     */
    public function getEvents($orderBy = null) {
        if (!$this->eventsList) {
            $offset = $this->getStart();
            $eventsWidget = new EventsWidget();
            $eventsWidget->Limit = "$offset, {$this->eventsPerPage}";
            $eventsWidget->setAdditionalSearchParams($this->request->getVars());
            if ($orderBy) {
                $eventsWidget->OrderBy = $orderBy;
            } elseif ($this->getIncludeExpired()) {
                $eventsWidget->OrderBy = '`dt`.StartDate ASC, `dt`.StartTime ASC';
            }
            $this->eventsList = $eventsWidget->getEvents();
        }
        return $this->eventsList;
    }

    /**
     * @param int $limit
     * @return DataObjectSet
     */
    public function getRSSEvents() {
        return $this->getEvents('`SiteTree`.Created DESC');
    }

    /**
     * Returns a link to the rss feed of the current search
     * @return string
     */
    public function RSSLink() {
        $vars = $this->request->getVars();
        if (isset($vars['url']))
            unset($vars['url']);

        return $this->Link('rss') . '?' . http_build_query($vars);
    }

    /**
     * Builds the map for the Library filter
     *
     * @return DataObjectSet
     */
    public function getLibrariesMap() {
        $currentLibId = $this->request->getVar('libraryId') ?: '';

        $libraryPages = DataObject::get('LibraryMainPage');

        $map = $libraryPages->map('ID', 'MenuTitle');
        global $sc;
        if ($sc->getParameter('is_library') == true) {
            $map = array('' => _t('LibrariesListPage.ALLLIBRARIES', 'Tutte le biblioteche')) + $map;
        } else {
            $map = array('' => _t('LibrariesListPage.ALLMUSEUMS', 'Tutti i musei')) + $map;
        }
        $mapSet = new DataObjectSet();

        foreach ($map as $id => $label) {
            $mapSet->push(new ArrayData(array(
                'Selected' => $id == $currentLibId,
                'Value' => $id,
                'Label' => $label,
            )));
        }

        return $mapSet;
    }

    /**
     * Build the map for the month filter
     *
     * @param int $limit The number of months to return
     * @param int $offset The month offset. 0 for current month, -1 for the previous month, etc.
     *
     * @return DataObjectSet
     */
    public function getMonths($limit = 12, $offset = 0) {
        $selectedMonth = $this->request->getVar('month');
        $monthsSet = new DataObjectSet();

        $monthsSet->push(new ArrayData(array(
            'Selected' => '' == $selectedMonth,
            'Value' => '',
            'Label' => 'Tutti i mesi',
        )));

        for ($i = $offset; $i < $limit; $i++) {
            $date = new DateTime();
            $date->modify("+$i month");
            $value = $date->format('Y-m');
            $monthsSet->push(new ArrayData(array(
                'Selected' => $value == $selectedMonth,
                'Value' => $value,
                'Label' => strftime('%B %G', $date->getTimestamp()),
            )));
        }

        return $monthsSet;
    }

    /**
     * Ritorna le categorie effettivamente presenti in almeno uno degli eventi risultanti
     *
     * @return DataObjectSet
     */
    public function getCategories() {
        $ids = array();
        foreach ($this->getEvents() as $event) {
            $ids[] = $event->ID;
        }
        $ids = join(",", array_unique($ids));
        if ($ids != "") {
            $selectedCats = $this->request->getVar('categories');
            if (!is_array($selectedCats)) {
                $selectedCats = array();
            }
            $categories = DB::query('SELECT lec.* FROM LqEventCategories lec JOIN CalendarEvent_LqEventCategories celec ON celec.CalendarEventID IN (' . $ids . ') AND lec.ID = celec.LqEventCategoriesID GROUP BY lec.ID');
            $c = new DataObjectSet();
            foreach ($categories as $category) {
                if (in_array($category["ID"], $selectedCats)) {
                    $category["Selected"] = true;
                }
                $c->push(new ArrayData($category));
            }
            return $c;
        } else {
            return new DataObjectSet();
        }
    }

    /**
     * Returns the current text filter value
     *
     * @return string
     */
    public function getText() {
        return $this->request->getVar('text');
    }

    /**
     * Returns the current selected tags
     *
     * @return DataObjectSet
     */
    public function getTags() {
        $tags = $this->request->getVar('tags') ?: array();
        $tagsSet = new DataObjectSet();

        foreach ($tags as $tag) {
            $tagsSet->push(new ArrayData(array(
                'Value' => $tag
            )));
        }

        return $tagsSet;
    }

    /**
     * Tells if we want to list expired events too
     *
     * @return string
     */
    public function getIncludeExpired() {
        return $this->request->getVar('include_expired');
    }

    /**
     * Events offset
     */
    public function getStart() {
        return $this->request->getVar('start') ? (int) $this->request->getVar('start') : 0;
    }

}
