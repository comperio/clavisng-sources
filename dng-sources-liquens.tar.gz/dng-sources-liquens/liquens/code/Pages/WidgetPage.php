<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
/**
 * This is a Page that only have some content and two Widget areas, one for the top of the page,
 * and one for the sidebar
 */
class WidgetPage extends Page
{
    static $db = array(
    );
    static $has_one = array(
        'TopWidgetArea' => 'WidgetArea',
        'SidebarWidgetArea' => 'WidgetArea',
        'BottomWidgetArea' => 'WidgetArea',
        'WidgetArea' => 'WidgetArea'
    );

    /**
     * @return FieldSet
     */
    function getCMSFields($params = NULL)
    {
        $fields = parent::getCMSFields();
        $fields->addFieldToTab("Root.Content.WidgetArea", new GridWidgetAreaEditor('WidgetArea'));
        $fields->insertFirst(new LiteralField('', (string) new ContentWidgetWarning($this, 'WidgetArea')));

        return $fields;
    }

    /**
     * {@inheritdoc}
     */
    public function getPageTemplates()
    {
        $templates = parent::getPageTemplates();
        $templates[] = new ContentWidgetTemplate('WidgetArea');

        return $templates;
    }
}

/**
 * Controller for the WidgetPage
 */
class WidgetPage_Controller extends Page_Controller
{
    static $allowed_actions = array('index');
}
