<?php

class CarouselItem extends DataObject {

    static $db = array(
        'Title' => 'VarChar(255)',
        'Description' => 'Text',
        'Active' => 'Boolean',
        'Sort' => 'VarChar(255)',
        'Link' => 'VarChar(255)'
    );
    static $defaults = array(
        'Active' => true,
        'Sort' => 0
    );
    static $has_one = array(
        'Image' => 'Image',
        'CarouselPage' => 'CarouselPage',
    );
    static $default_sort = '"Sort" ASC';

    public function getCMSFields($params = NULL) {
        $fields = parent::getCMSFields();
        $fields->replaceField('CarouselPageID', new HiddenField('CarouselPageID'));

        return $fields;
    }

    public function canView($member = null) {
        return Permission::check('CMS_ACCESS_CMSMain', 'any', $member);
    }

    public function canEdit($member = null) {
        return Permission::check('CMS_ACCESS_CMSMain', 'any', $member);
    }

    public function canDelete($member = null) {
        return Permission::check('CMS_ACCESS_CMSMain', 'any', $member);
    }

    public function canCreate($member = null) {
        return Permission::check('CMS_ACCESS_CMSMain', 'any', $member);
    }

}
