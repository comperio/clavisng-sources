<?php

class RegistrationPage extends Page {

    static $db = array(
        'ConfirmationContent' => 'HTMLText',
        'ConfirmationTextEmail' => 'HTMLText',
        "PatronStatus" => "Varchar(1)",
        "LoanClass" => "Varchar(1)",
        "AccessAlert" => "Varchar(1)",
        "OpacEnable" => "Varchar(1)",
        "SurfEnable" => "Varchar(1)",
        "RegistrationLibraries" => "Varchar(1)",
        "SendConfirmationEmail" => "Varchar(1)",
        'ReplyToEmail' => 'VarChar(255)',
        'SendToEmail' => 'VarChar(255)',
        'PrivacyTextBox' => 'VarChar(255)'
    );
    
    static $has_one = array();
   
    public $rules = array(
        'username' => array(
            'alphanumeric' => true,
            'required' => true,
            'minlength' => 3,
            'maxlength' => 16
        ),
        'password' => array(
            'minlength' => 6,
            'maxlength' => 16,
            'required' => true
        ),
        'confirm_password' => array(
            'equalToByName' => 'password',
            'required' => true
        ),
        'lastname' => 'required',
        'name' => 'required',
        'birth_date' => array(
            'italianDate' => true,
            'required' => true
        ),
        'document_expiry' => 'italianDate',
        'contact_email' => array(
            'email' => true,
            'required' => true
        ),
        'birth_city' => 'required',
        'birth_country' => 'required',
        'birth_province' => 'required',
        'national_id' => 'required',
        'privacy_approve' => 'required',
        'address_type' => 'required',
        'street_type' => 'required',
        'street' => 'required',
        'street_num' => 'required',
        'zip' => 'required',
        'city' => 'required',
        'province' => 'required',
        'country' => 'required',
        'document_type' => 'required',
        'document_number' => 'required',
        'contact_value' => 'required',
        'preferred_library_id' => 'required',
    );

    public function getCMSFields($params = NULL) {
	$fields = parent::getCMSFields();
        
        $fields->addFieldToTab("Root.Content.Configurazione", new CheckboxField("RegistrationLibraries", "Selezionare per usare la lista delle biblioteche che permettono la registrazione. Altrimenti verranno visualizzate tutte le biblioteche interne."));
        $fields->addFieldToTab("Root.Content.Configurazione", new CheckboxField("SendConfirmationEmail", "Abilitare l'invio dell'email di conferma verso l'utente?"));
        $fields->addFieldToTab('Root.Content.Configurazione', new TextField("SendToEmail", "Email usata per effettuare l'invio agli utenti. Se lasciato vuoto, verrà utilizzata l'email di sistema"));
        $fields->addFieldToTab('Root.Content.Configurazione', new TextField("ReplyToEmail", "Email a cui gli utenti possono rispondere. Se lasciato vuoto, verrà utilizzata l'email della biblioteca preferita selezionata"));

        $fields->addFieldToTab('Root.Content.Messaggi', new HtmlEditorField("ConfirmationContent", _t('Registration.CONFIRMLABEL', "Content to be displayed after the pre registration. Place card: #NOME, #COGNOME, #NUMERO, #CF"), 5));
        $fields->addFieldToTab('Root.Content.Messaggi', new HtmlEditorField("ConfirmationTextEmail", "Template dell'email di conferma. Segnaposto che verranno sostituiti: #NOME, #COGNOME, #NUMERO, #CF", 5));
        
        global $sc;
        $connector = $sc->get('liquens.connector');
        $soap = $connector->getSoapClient('consortia');

        $loanClass = array();
        foreach ($soap->getLookupValues("PATRONLOANCLASS", "it_IT") as $key => $value) {
            $loanClass[$key] = $value;
        }

        $accessAlert = array();
        foreach ($soap->getLookupValues("PATRONALERT", "it_IT") as $key => $value) {
            $accessAlert[$key] = $value;
        }

        $patronState = array();
        foreach ($soap->getLookupValues("PATRONSTATE", "it_IT") as $key => $value) {
            $patronState[$key] = $value;
        }
        $fields->addFieldToTab('Root.Content.GestioneDatiUtente', new DropdownField("PatronStatus", "Stato dell'utente appena registrato", $patronState));
        $fields->addFieldToTab('Root.Content.GestioneDatiUtente', new DropdownField("LoanClass", "Classe di prestito dell'utente appena registrato", $loanClass));
        $fields->addFieldToTab('Root.Content.GestioneDatiUtente', new DropdownField("AccessAlert", "Tipo di avvertimento", $accessAlert));
        $fields->addFieldToTab('Root.Content.GestioneDatiUtente', new CheckboxField("OpacEnable", "Utente deve essere già attivo in OPAC?", $this->ActiveOpac));
        $fields->addFieldToTab('Root.Content.GestioneDatiUtente', new CheckboxField("SurfEnable", "L'utente può già navigare?", $this->SurfEnable));
        $fields->addFieldToTab('Root.Content.GestioneDatiUtente', new TextField("PrivacyTextBox", "Testo per approvazione privacy (è permesso inserire HTML)"));
        

        return $fields;
    }

    /**
     * Build messages array
     * 
     * @return array
     */
    public function getValidationMessages() {
        return array(
            'confirm_password' => _t('Validation.PASSWORDEQUALS', 'Password must match')
        );
    }

    /**
     * Add css classes to form elements based on $rules property
     * 
     * @param Form $form
     * @return RegistrationPage
     */
    public function addCssClasses(Form $form) {
        foreach ($form->Fields() as $field) {
            if ($form->getValidator()->isRuleAppliedToField('required', $field->Name())) {
                $requiredSuffix = ' <sup title="' . _t('Registration.MANDATORYFIELD', 'Mandatory Field') . '">*</sup>';
                $field->addExtraClass('lqvalidation_required');
                $field->setTitle($field->Title() . $requiredSuffix);
            }
        }

        return $this;
    }
    
    public function onBeforeWrite() {
        parent::onBeforeWrite();
        
        if (($this->owner->PrivacyTextBox == "") || is_null($this->owner->PrivacyTextBox))
            $this->owner->PrivacyTextBox = "Dichiaro di aver letto ed accettato le condizioni sulla Privacy";
       
    }

}

/**
 * Controller for the Registration Page
 */
class RegistrationPage_Controller extends Page_Controller {

    public static $allowed_actions = array(
        'RegistrationForm',
        'register'
    );

    /**
     * @var LibraryRepository
     */
    private $libraryRepository;

    /**
     * @param $dateString
     * @return string
     */
    private function getReversedDate($dateString) {
        if (empty($dateString))
            return '';

        $dateString = str_replace('/', '-', $dateString);

        $pieces = array_reverse(explode('-', $dateString));

        return implode('-', $pieces);
    }

    private $antispam;
    
    /**
     * Gives the CustomizedForm object for the Registration page
     * 
     * @return CustomizedForm
     */
    public function RegistrationForm() {
        SecurityToken::disable();

        if ((int) $this->RegistrationLibraries != 0)
            $librariesList = $this->getLibraryRepository()->getRegistrationLibraries('ExternalID', 'shortName');
        else
            $librariesList = $this->getLibraryRepository()->getInternalLibraries('ExternalID', 'shortName');
        
        $this->antispam = new RecaptchaField("recaptcha_field");
        
        $fields = new FieldSet(
            new TextField("username", _t('Registration.USERNAME', 'Username')), 
            new PasswordField("password", _t('Registration.PASSWORD', 'Password')), 
            new PasswordField("confirm_password", _t('Registration.CONFIRMPASSWORD', 'Confirm Password')), 
            new DropdownField("title", _t('Registration.TITLE', 'Title'), i18nExtension::get_namespace_strings('LV_TITLE'), '', null, '---'), 
            new TextField("name", _t('Registration.NAME', 'Name')), 
            new TextField("lastname", _t('Registration.LASTNAME', 'Lastname')), 
            new DropdownField("gender", _t('Registration.GENDER', 'Gender'), i18nExtension::get_namespace_strings('LV_SEX'), '', null, '---'), 
            new TextField('birth_date', _t('Registration.BIRTHDATE', 'Birth date')), 
            new TextField('birth_city', _t('Registration.BIRTHCITY', 'Birth city')), 
            new TextField('birth_province', _t('Registration.BIRTHPROVINCE', 'Birth province')), 
            new TextField('birth_country', _t('Registration.BIRTHCOUNTRY', 'Birth country')), 
            new TextField('national_id', _t('Registration.NATIONALID', 'National ID')), 
            new DropdownField("civil_status", _t('Registration.CIVILSTATUS', 'Civil Status'), i18nExtension::get_namespace_strings('LV_CIVILSTATE'), '', null, '---'), 
            new DropdownField("document_type", _t('Registration.DOCUMENT', 'Document'), i18nExtension::get_namespace_strings('LV_IDDOCS'), '', null, '---'), 
            new TextField('document_expiry', _t('Registration.DOCUMENTEXPIRY', 'Valid until (format: dd/mm/yyyy)')), 
            new TextField('document_number', _t('Registration.DOCUMENTNUMBER', 'Document Number')), 
            new TextField('document_emitter', _t('Registration.DOCUMENTEMITTER', 'Emitted by')), 
            new TextField('citizenship', _t('Registration.CITIZENSHIP', 'Nation of citizenship')), 
            new DropdownField("address_type", _t('Registration.ADDRESSTYPE', 'Address type'), i18nExtension::get_namespace_strings('LV_ADDRESSTYPE'), '', null, '---'), 
            new DropdownField("street_type", _t('Registration.STREETTYPE', 'Street type'), i18nExtension::get_namespace_strings('LV_STREET'), '', null, '---'), 
            new TextField('street', _t('Registration.STREET', 'Street')), 
            new TextField('street_num', _t('Registration.DOCUMENTNUMBER', 'Street Number')), 
            new TextField('zip', _t('Registration.ZIP', 'Zip')), 
            new TextField('city', _t('Registration.CITY', 'City')), 
            new TextField('village', _t('Registration.VILLAGE', 'Village')), 
            new TextField('province', _t('Registration.PROVINCE', 'Province')), 
            new TextField('country', _t('Registration.COUNTRY', 'Country')), 
            new EmailField("contact_email", "Email"),
            /*            new DropdownField("contact_type", _t(
              'Registration.CONTACTTYPE', 'Contact type'
              ), i18nExtension::get_namespace_strings('LV_CONTACTTYPE'), '', null, '---'), */ 
            new HiddenField('contact_type', 'Phone Number', 'C'), 
            new TextField('contact_value', _t('Liquens.NUMBER')), 
            new DropdownField("preferred_library_id", _t('Registration.PREFERRED_LIBRARY', "Favourite library"), $librariesList, '', null, '---'), 
            new CheckboxField("privacy_approve", $this->PrivacyTextBox, false),

            $this->antispam
        );
        
        $actions = new FieldSet(new FormAction("register", _t('Registration.REGISTER', 'Register')));

        $validator = new ComplexValidator($this->rules, $this->getValidationMessages());
        $form = new CustomizedForm($this, "RegistrationForm", $fields, $actions, $validator);

        $this->addCssClasses($form);

        $oldData = $this->getOldFormData($form);
        if ($oldData)
            $form->loadDataFrom($oldData);

        return $form;
    }

    /**
     * Action that handles form submission
     *
     * @param array $formData
     * @param Form $form
     * @return void
     */
    public function register($formData, Form $form) {
        $success = true;

        //The registration is considered failed only if the
        //preRegister method throws an Exception
        try {
            $response = $this->preRegister($formData);
        } catch (Exception $e) {
            $success = false;
            $this->addMessage('Error preRegister: ', $e->getMessage());

            $this->saveOldFormData($form);
            $this->redirectBack();
            return;
        }
        if ($success) {
            try {
                // Recupero eventuale nuovo username dato da trigger su Clavis
                $formData['username'] = $response['OpacUsername'];
                $this->updateAddressData($formData);
                if (isset($formData['contact_email']) && ($this->SendConfirmationEmail)) {
                    $formData['registration_library_id'] = $response['RegistrationLibraryId'];
                    $this->sendRegistrationEmail($formData);
                }
            } catch (Exception $e) {
                $this->addMessage('Error updateAddressData: ', $e->getMessage());
            }
            try {
                $this->updateContacts($formData);
            } catch (Exception $e) {
                $this->addMessage('Error updateContacts: ', $e->getMessage());
            }
        }

        return $this->renderWith(array('RegistrationConfirmPage', 'Page'));
    }

    /**
     * Perform the preregistration through the Liquens Connector
     *
     * @param array $formData
     * @return array
     */
    public function preRegister($formData) {
        
        // Verifica anti-spam
        $antispam = json_decode($this->antispam->recaptchaHTTPPost($formData["g-recaptcha-response"]));
        if ($antispam->success == false)
            throw new Exception("Selezionare l'antispam!");
        
        // Verifica email duplicata dentro DNG
        if (DB::query("SELECT COUNT(`Email`)  FROM `Member` WHERE `Email` LIKE '".Convert::raw2sql($formData['contact_email']) . "'")->value() > 0) {
            throw new Exception('Impossibile registrarsi, i dati inseriti potrebbero essere già presenti!');
        }

        global $sc;
        $connector = $sc->get('liquens.connector');
        // Verifica email duplicata dentro CLAVIS
        if ($connector->getUserContacts($formData['contact_email'], 'email') || $connector->getUserContacts($formData['national_id'], 'national_id') ) {
            throw new Exception('Impossibile registrarsi, i dati inseriti potrebbero essere duplicati!');
        }
        
        // Verifica validità del codice fiscale
        $cf = $this->getCFbyExternal($formData['name'], $formData['lastname'], $formData['birth_city'], $formData['birth_date'], $formData['gender'], $formData['national_id']);
        if ($cf != strtoupper($formData['national_id'])) {
            throw new Exception("Verifica del codice fiscale fallita!");
        }
        
        // Verifica presenza del codice fiscale
        if ($connector->getUserContacts($formData['national_id'], 'national_id') ) {
            throw new Exception('Impossibile registrarsi, i dati inseriti potrebbero essere doppi!');
        }
        
        $patronStatus = $this->PatronStatus;
        $patronLoanClass = $this->LoanClass;
        $patronOpacEnabled = $this->OpacEnable ? 1 : 0;
        $patronSurfEnabled = $this->SurfEnable ? 1 : 0;
        $patronAccessAlert = $this->AccessAlert;
        $opacPwdExpire = $sc->getParameter('opac_password_expire') == false ? NULL : date('Y-m-d', strtotime("+".$sc->getParameter('opac_password_expire')." days"));

        $response = $connector->registerNewUser(
                $formData['username'], $formData['password'], $opacPwdExpire,
                $formData['name'], $formData['lastname'], 
                $formData['preferred_library_id'], 
                strtoupper($formData['national_id']), $formData['gender'], null, $formData['civil_status'], 
                $formData['document_type'], $formData['document_number'], $formData['document_emitter'], $this->getReversedDate($formData['document_expiry']), 
                $formData['citizenship'],
                $this->getReversedDate($formData['birth_date']), $formData['birth_city'], $formData['birth_province'], $formData['birth_country'], 
                $patronStatus, $patronLoanClass, 
                isset($formData['privacy_approve']) ? true : false,
                $patronOpacEnabled,
                $patronSurfEnabled,
                $patronAccessAlert,
                "standard"
        );

        return $response;
    }

    /**
     * Set LibraryRepository
     *
     * @param \LibraryRepository $libraryRepository
     *
     * @return RegistrationPage_Controller The current instance
     */
    public function setLibraryRepository(\LibraryRepository $libraryRepository) {
        $this->libraryRepository = $libraryRepository;
        return $this;
    }

    /**
     * Get LibraryRepository
     *
     * @return \LibraryRepository
     */
    public function getLibraryRepository() {
        return $this->libraryRepository;
    }

    /**
     * Get data of a previous submitted form
     *
     * @param Form $form
     * @return array
     */
    private function getOldFormData(Form $form) {
        return Session::get("FormInfo.{$form->FormName()}.lq.oldData");
    }

    /**
     *
     * @param array $formData
     * @return bool
     */
    private function updateAddressData($formData) {
        $connector = $this->getContainer()->get('liquens.connector');

        if (!isset($formData['username'])) {
            return false;
        }

        return $connector->editAddress(
                        $formData['username'], '', //Create a new Address
                        $formData['address_type'], 1, //address_pref
                        $formData['street_type'], $formData['street'], $formData['street_num'], $formData['village'], $formData['city'], $formData['zip'], $formData['province'], $formData['country']
        );
    }

    /**
     * Add email and other contact data
     *
     * @param array $formData
     * @return bool
     */
    private function updateContacts($formData) {
        if (!isset($formData['username']))
            return false;

        /** @var $connector CLAVISConnector */
        $connector = $this->getContainer()->get('liquens.connector');

        if (isset($formData['contact_email'])) {
            $connector->editContact(
                    $formData['username'], '', //contact_id. Empty for new contact
                    'E', //contact_type
                    $formData['contact_email'], 1 //contact_pref: Set as preferred contact
            );
        }

        if (isset($formData['contact_type']) && isset($formData['contact_value'])) {
            $connector->editContact(
                    $formData['username'], '', //contact_id. Empty for new contact
                    $formData['contact_type'], //contact_type
                    $formData['contact_value'], 0 //contact_pref
            );
        }

        return true;
    }

    /**
     * Save in the session the form data for later use
     *
     * @param Form $form
     * @return RegistrationPage_Controller
     */
    private function saveOldFormData(Form $form) {
        Session::set("FormInfo.{$form->FormName()}.lq.oldData", $form->getData());

        return $this;
    }

    public function sendRegistrationEmail($formData) {
        
        $connector = $this->getContainer()->get('liquens.connector');
        $ownerLibData = $connector->getLibraryData($formData['registration_library_id']);
        if ($ownerLibData['Email'] == "")
            throw new Exception("Impossibile inviare l'email, la biblioteca non è correttamente configurata!");
        
        $siteTitle = DataObject::get_one('SiteConfig')->Title;

        $bodyContent = $this->ConfirmationTextEmail;
        /* Sostituzione segnaposto  */
        $bodyContent = str_replace("#NOME", $formData['name'], $bodyContent);
        $bodyContent = str_replace("#COGNOME", $formData['lastname'], $bodyContent);
        $bodyContent = str_replace("#NUMERO", $formData['contact_value'], $bodyContent);
        $bodyContent = str_replace("#CF", $this->nationald_id, $bodyContent);

        global $sc;

        $mail = new PHPMailer;
        
        /* TEST PER CLUBMEDICI */
        $mail->CharSet = 'utf-8';

        $mail->isSMTP();
        $mail->Host = $sc->getParameter('phpmailer.smtp');
        $mail->Port = $sc->getParameter('phpmailer.smtp_port');
        $mail->SMTPAuth = $sc->getParameter('phpmailer.auth');

        if (!is_null($sc->getParameter('phpmailer.username')))
            $mail->Username = $sc->getParameter('phpmailer.username');
        if (!is_null($sc->getParameter('phpmailer.password')))
            $mail->Password = $sc->getParameter('phpmailer.password');
        if (!is_null($sc->getParameter('phpmailer.security')))
            $mail->SMTPSecure = $sc->getParameter('phpmailer.security');
        
        $mail->addAddress($formData['contact_email']);

        // Email di invio delle comunicazioni
        if ($this->SendToEmail != '' || !is_null($this->SendToEmail)) 
            $mail->setFrom($this->SendToEmail, $siteTitle);
        else {
                if (!is_null($sc->getParameter('phpmailer.forcedFrom'))) 
                    $mail->setFrom($sc->getParameter('phpmailer.forcedFrom'), $siteTitle);
                else
                    $mail->setFrom($sc->getParameter('system_email'), $siteTitle);
            }

        // Email del reply-to oppure email della biblioteca
        if ($this->ReplyToEmail != '' || !is_null($this->ReplyToEmail)) 
            $mail->addReplyTo($this->ReplyToEmail, $siteTitle);
        else 
            $mail->addReplyTo($ownerLibData['Email'], $siteTitle);

        $mail->isHTML(true);

        $mail->Subject = 'Registrazione - ' . $siteTitle;
        $mail->Body = $this->customise(
                        array(
                            'SiteTitle' => $siteTitle,
                            'BodyContent' => $bodyContent
                        )
                )->renderWith('RegistrationTwilioConfirmEmail');

        /* Invio email */
        try {
            if (!$mail->send()) {
                $this->addMessage('Error', _t('MyDiscovery.ASSISTANCE_MAIL_ERROR', 'E-mail is not sent.'));
                Debug::log('PHPMailer ' . $siteTitle . ' Errore registrazione twilio: ' . $mail->ErrorInfo);
            } else {
                $this->addMessage('Success', _t('MyDiscovery.ASSISTANCE_MAIL_OK', 'E-mail successfully sent'));
            }
        } catch (Exception $e) {
            $this->addMessage('Error', _t('MyDiscovery.ASSISTANCE_MAIL_ERROR', 'E-mail is not sent.') . " Error: " . $e->getMessage());
            return;
        }
    }

    /**
     * Verifica codice fiscale con servizio web esterno
     * 
     * @global type $sc
     * @param type $Nome
     * @param type $Cognome
     * @param type $ComuneNascita
     * @param type $DataNascita
     * @param type $Sesso
     * @return string
     */
    private function getCFbyExternal($Nome, $Cognome, $ComuneNascita, $DataNascita, $Sesso, $realCF) {

        global $sc;

        $cfUrl = $sc->getParameter('cf_url');

        $handle = curl_init($cfUrl);
        curl_setopt($handle, CURLOPT_RETURNTRANSFER, TRUE);
        $response = curl_exec($handle);
        $httpCode = curl_getinfo($handle, CURLINFO_HTTP_CODE);
        if ($httpCode == 404) {
            Debug::log('Errore collegamento esterno getCFbyExternal');
            return "bypass";
        }
        curl_close($handle);

        $context = stream_context_create(
                array(
                    'ssl' =>
                    array(
                        'ciphers' => 'RC4-SHA',
                        'verify_peer' => false,
                        'verify_peer_name' => false,
                        'allow_self_signed' => true
                    )
                )
        );

        try {
            $client = new SoapClient(
                    $cfUrl, array(
                'cache_wsdl' => WSDL_CACHE_NONE,
                'connection_timeout' => 60,
                'trace' => 1,
                'exceptions' => 0,
                'compression' => SOAP_COMPRESSION_ACCEPT | SOAP_COMPRESSION_GZIP,
                "stream_context" => $context
                    )
            );
            $data = $client->CalcolaCodiceFiscale(array(
                'Nome' => $Nome,
                'Cognome' => $Cognome,
                'ComuneNascita' => $ComuneNascita,
                'DataNascita' => $DataNascita,
                'Sesso' => $Sesso
            ));
        } catch (Exception $e) {
            Debug::log('Errore esecuzione getCFbyExternal: ' . $e->getMessage() . ' Provo con controllaCF');
            // In caso di errore del webservice, fa fallback sul vecchio algoritmo
            return $this->controllaCF($realCF);
        }
        
        $cf = strtoupper((string) $data->CalcolaCodiceFiscaleResult);
        return $cf;
    }

    /**
     * Controllo approssimativo del codice fiscale (solo per esattezza del formato ma senza verifica reale sul contenuto)
     * 
     * @param type $cf
     * @return string
     */
    private function controllaCF($cf) {
        if ($cf === '')
            throw new Exception("Verifica del codice fiscale fallita!");
        if (strlen($cf) != 16)
            throw new Exception("Verifica del codice fiscale fallita!");
        $cf = strtoupper($cf);
        if (preg_match("/^[A-Z0-9]+\$/", $cf) != 1) {
            throw new Exception("Verifica del codice fiscale fallita!");
        }
        $s = 0;
        for ($i = 1; $i <= 13; $i += 2) {
            $c = $cf[$i];
            if (strcmp($c, "0") >= 0 and strcmp($c, "9") <= 0)
                $s += ord($c) - ord('0');
            else
                $s += ord($c) - ord('A');
        }
        for ($i = 0; $i <= 14; $i += 2) {
            $c = $cf[$i];
            switch ($c) {
                case '0': $s += 1;
                    break;
                case '1': $s += 0;
                    break;
                case '2': $s += 5;
                    break;
                case '3': $s += 7;
                    break;
                case '4': $s += 9;
                    break;
                case '5': $s += 13;
                    break;
                case '6': $s += 15;
                    break;
                case '7': $s += 17;
                    break;
                case '8': $s += 19;
                    break;
                case '9': $s += 21;
                    break;
                case 'A': $s += 1;
                    break;
                case 'B': $s += 0;
                    break;
                case 'C': $s += 5;
                    break;
                case 'D': $s += 7;
                    break;
                case 'E': $s += 9;
                    break;
                case 'F': $s += 13;
                    break;
                case 'G': $s += 15;
                    break;
                case 'H': $s += 17;
                    break;
                case 'I': $s += 19;
                    break;
                case 'J': $s += 21;
                    break;
                case 'K': $s += 2;
                    break;
                case 'L': $s += 4;
                    break;
                case 'M': $s += 18;
                    break;
                case 'N': $s += 20;
                    break;
                case 'O': $s += 11;
                    break;
                case 'P': $s += 3;
                    break;
                case 'Q': $s += 6;
                    break;
                case 'R': $s += 8;
                    break;
                case 'S': $s += 12;
                    break;
                case 'T': $s += 14;
                    break;
                case 'U': $s += 16;
                    break;
                case 'V': $s += 10;
                    break;
                case 'W': $s += 22;
                    break;
                case 'X': $s += 25;
                    break;
                case 'Y': $s += 24;
                    break;
                case 'Z': $s += 23;
                    break;
                /* . missing_default: . */
            }
        }
        if (chr($s % 26 + ord('A')) != $cf[15])
            throw new Exception("Verifica del codice fiscale fallita!");
        return $cf;
    }
    
}
