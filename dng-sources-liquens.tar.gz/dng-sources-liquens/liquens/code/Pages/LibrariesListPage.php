<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Isacco Occhiali <isacco@comperio.it>
 */

class LibrariesListPage extends Page
{
    public static $has_one = array(
        'TopWidgetArea' => 'WidgetArea'
    );

    public static $many_many = array(
        'Libraries' => 'LibraryDataObject',
    );

    static $allowed_children = array (
        'LibraryMainPage'
    );

    /**
     * @var LibraryRepository
     */
    private $libraryRepository;

    public function getCMSFields($params = NULL)
    {
        $fields = parent::getCMSFields();
        $fields->addFieldToTab("Root.Content.TopWidgetArea", new WidgetAreaEditor('TopWidgetArea'));
        $fields->addFieldToTab("Root.Content.Biblioteche", new LiteralField('', '<h4>Biblioteche da visualizzare</h4>'));



        $checkboxSet = new DngCheckboxSetField(
            'Libraries',
            '',
            $this->getLibraryRepository()->getInternalLibraries('ID', 'shortName'),
            $this->Libraries()->column('ID')
        );
        $fields->addFieldToTab("Root.Content.Biblioteche", $checkboxSet);

        return $fields;
    }

    /**
     * Get the array of the librariesIds grouped by LibraryArea
     *
     * @static
     * @return mixed
     */
    public static function get_libraries_area_map()
    {
        global $kernel;
        $file = $kernel->getSitePath() . DIRECTORY_SEPARATOR . 'libraryMap.php';
        if (file_exists($file)) {
            $libraries = include $file;
        } else {
            $libraries = array();
        }

        return $libraries;
    }

    /**
     * Set LibraryRepository
     *
     * @param \LibraryRepository $libraryRepository
     *
     * @return LibrariesListPage The current instance
     */
    public function setLibraryRepository(\LibraryRepository $libraryRepository)
    {
        $this->libraryRepository = $libraryRepository;

        return $this;
    }

    /**
     * Get LibraryRepository
     *
     * @return \LibraryRepository
     */
    public function getLibraryRepository()
    {
        if (!isset($this->libraryRepository)) {
            $this->libraryRepository = $this->getContainer()->get('library.repository');
        }

        return $this->libraryRepository;
    }

    /**
     * {@inheritdoc}
     */
    public function getPageTemplates()
    {
        $templates = parent::getPageTemplates();

        $templates[] = new LibrariesListTemplate();

        return $templates;
    }


}

class LibrariesListPage_Controller extends Page_Controller
{
    /**
     * {@inheritdoc}
     */
    public static $allowed_actions = array(
        'libraryAutosuggest',
        'searchLibrary'
    );

    /**
     * The Number of columns of Libraries to shown
     * @var string
     */
    public static $LibraryColNum='4';

    /**
     *
     */
    public function init()
    {
        parent::init();

        // Note: you should use SS template require tags inside your templates
        // instead of putting Requirements calls here.  However these are
        // included so that our older themes still work
        if(Director::is_ajax() || isset($_GET["ajaxDebug"])) {
            $this->isAjax = true;
        } else {
            $this->isAjax = false;
        }
    }

    /**
     * The main action of the page
     *
     * @param SS_HTTPRequest $request
     *
     * @return string
     */
    public function index(SS_HTTPRequest $request)
    {
        return $this->renderWith(array('LibrariesListPage', 'Page'));
    }

    /**
     * Return the list of Libraries with staff page and TimeTable
     * @return DataobjectSet
     */
    public function Libraries()
    {
        /** @var $repo LibraryRepository */
        $repo = $this->dataRecord->getLibraryRepository();

        $libraries = $repo->dataSetToLibraries($this->dataRecord->Libraries());
        $libraries = ViewableObject::traversable_to_viewable_dataset($libraries);

        $numLibrariesPerColumn = ceil($libraries->Count()/self::$LibraryColNum);

        $i = 1;
        foreach ($libraries as $library) {
            if($i % $numLibrariesPerColumn == 0) {
                $library->isLastOfColumn = true;
            }
            $i++;
        }

        return $libraries;
    }

    /**
     * Execute the redirection to the choosen LibraryMainPage
     * @return execute redirection
     */
    public function searchLibrary(SS_HTTPRequest $request)
    {
        $libID = $request->getVar('library_id');

        /** @var $repo LibraryRepository */
        $repo = $this->dataRecord->getLibraryRepository();

        $library = $repo->getByID($libID);

        if ($library) {
            $this->redirect($library->getCatalogLink());
        } else {
            $this->redirectBack();
        }
    }

    /**
     * Autosuggest for library names
     *
     * @return string json_encode
     */
    public function libraryAutosuggest(SS_HTTPRequest $request)
    {
        if($this->isAjax()){

            $libraries = $this->dataRecord->Libraries(sprintf("FullName LIKE '%%%s%%'", Convert::raw2sql($request->getVar('term'))));

            $response=array();
            foreach ($libraries as $library) {
                $response[] = array("label" => "$library->FullName", "value" => "$library->ID");
            }

            return json_encode($response);
        }
    }
}
