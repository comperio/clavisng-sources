<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Isacco Occhiali <isacco@comperio.it>
 */
/**
 * Class LibraryTimeTablePage.
 *
 * Provides the functions to navigate the Clavis library opening time table
 */
class LibraryTimeTablePage extends LibraryPage
{

    public static $db = array();

    public static $has_one = array();

    static $can_be_root = false;

    static $allowed_children = array();

    function getCMSFields($params = NULL)
    {
        $fields = parent::getCMSFields();
        $fields->addFieldToTab(
            'Root.Behaviour',
            new CheckboxField("VisibleInMainPage", _t('LibraryTimeTablePage.VISIBLEINMAINPAGE', 'Visible in main page'))
        );
        return $fields;
    }

    /**
     * {@inheritdoc}
     */
    public function getPageTemplates()
    {
        $templates = parent::getPageTemplates();

        $templates[] = new TimetableTemplate();

        return $templates;
    }
}

/**
 * Class LibraryTimeTablePage_Controller
 */
class LibraryTimeTablePage_Controller extends LibraryPage_Controller
{
    public static $allowed_actions = array(
        'timetable', 'BrowserPollForm', 'TimeTableFilterForm',
    );

    /**
     * Return the Library timetable
     * @return DataObjesctSet
     */
    public function timetable()
    {
        if (isset($_REQUEST)) {
            $from = time();
            $to = strtotime('+5 days');

            if (array_key_exists('view', $_REQUEST)) {
                switch ($_REQUEST['view']) {
                    case 'w':
                        $from = time();
                        $to = strtotime('+5 days');
                        break;
                    case 'm':
                        $from = time();
                        $to = strtotime('+30 days');
                        break;
                    case 'y':
                        $from = time();
                        $to = strtotime('+364 days');
                        break;
                    default:
                        $from = time();
                        $to = strtotime('+5 days');
                }

            }

            if (array_key_exists('sd', $_REQUEST)) {
                $from = (int) $_REQUEST['sd'];
            }

            if (array_key_exists('ed', $_REQUEST)) {
                $to = (int) $_REQUEST['ed'];
            }

            if ($from && $to) {
                return $this->Parent->getLibrary()->getViewableTimeTable($from, $to);
            }
        }
    }

    /**
     * Return the Library timetable
     * @param integer $data (timestamp)
     * @param integer $form (timestamp)
     */
    public function doBrowserDatesTimes($data, $form)
    {
        $from = null;
        $from = strtotime($data['datepicker']);

        if(!is_null($from) && $this->Link()) {
            $link = $this->Link() . "?sd=$from&ed=$from";
            Director::redirect($link);
        } else {
            Director::redirectBack();
        }
    }
}
