<?php

/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
require_once dirname(__FILE__) . '/../../../vendor/PHPMailer/PHPMailerAutoload.php';

class MyDiscoveryPage_Controller extends Page_Controller {

    /**
     * @var LibraryRepository
     */
    private $libraryRepository;
    protected $resultMlol;
    public static $allowed_actions = array(
        'index',
        'deleteReservation',
        'renewLoan',
        'renewExtra',
        'reserve',
        'reserveExtra',
        'reserveMLOL',
        'reserveShard',
        'PurchaseProposalForm',
        'PurchaseProposalTypeForm',
        'addPurchaseProposal',
        'deletePurchaseProposal',
        'edit',
        'doEdit',
        'editAddress',
        'EditAddressForm',
        'editContact',
        'EditContactForm',
        'deleteAddress',
        'deleteContact',
        'EditProfileForm',
        'changeReservationLib',
        'shelves',
        'searches',
        'reservations',
        'contacts',
        'addresses',
        'contactDialog',
        'addressDialog',
        'activeLoans',
        'reservationsCount',
        'loansMlolOpen',
        'loansMlolClosed',
        'loansMlol',
        'MyLibraryContact',
        'ajaxBestManifestation',
        'ajaxGetClosedLoans',
        'ajaxGetMyProposal',
        'EditPrivacyForm',
        'doPrivacyEdit'
    );
    public static $url_handlers = array(
        'reserve/$ManifestationID!/$LibraryID!/$Tail' => 'reserve',
        'reserveExtra/$ManifestationID!/$LibraryID!/$Tail' => 'reserveExtra',
        'reserveMLOL/$ManifestationID!' => 'reserveMLOL',
        'reserveShard/$ManifestationID!/$LibraryID!/$Tail' => 'reserveShard',
        'renewExtra/$ItemID!' => 'renewExtra',
        'renewShard/$ItemID!' => 'renewShard',
        'reservations-count' => 'reservationsCount',
        'ajaxBestManifestation' => 'ajaxBestManifestation',
        'ajaxGetClosedLoans' => 'ajaxGetClosedLoans',
        'ajaxGetMyProposal' => 'ajaxGetMyProposal'
    );

    public function index() {
        if (!Member::currentUser()) {
            return $this->redirect('home', 401);
        }
        $this->i18nToJs(array(
            'Search.NORESULTS' => 'No results found',
            'Search.SEARCH' => 'Search',
            'Profile.ROWSFORPAGE' => 'Show _MENU_ rows for page',
            'Profile.FROMROWTO' => 'From row _START_ to _END_ of _TOTAL_ total rows',
            'Profile.FROMROWTOEMPTY' => 'Show 0 rows on 0 total rows',
            'Profile.FILTEREDROWS' => '(filtered from _MAX_ total rows)',
        ));
        
        /* Verifica privacy */
        global $sc;
        if ($sc->getParameter('mandatory_privacy') == true) {
            $member = Member::currentUser();
            $externalData = $member->getExternalData();
            if ( ($externalData["group"] == "patron") && ($externalData["patron"]['PrivacyApprove'] !== "1") ) {
                Session::clear("FeedbackMessages");
                $this->addMessage('Warning', $this->owner->PrivacyModal);
                if (strpos($_SERVER['REQUEST_URI'], '/mydiscovery') === false) {
                    $this->redirect('mydiscovery/#privacy');
                }
            }
        }

        return $this->renderWith(array('MyDiscoveryPage', 'Page'));
    }

    /**
     * Ricalcolo della manifestation in base alla diversa biblioteca di ritiro (ReserveDialog.ss)
     * 
     * @param SS_HTTPRequest $request
     * @return boolean
     */
    public function ajaxBestManifestation(SS_HTTPRequest $request) {
        $a = new ReserveDialog();
        return $a->BestManifestation($request->getVar('libId'), $request->getVar('manId'), $request->getVar('output'));
    }

    public function ajaxGetClosedLoans(SS_HTTPRequest $request) {
        $a = new LqMemberDecorator();
        return $a->getClosedLoans(
            $request->getVar('page'), $request->getVar('obtitle'), $request->getVar('obbdate'), $request->getVar('obedate'), $request->getVar('obsearch'), $request->getVar('output')
        );
    }

    public function ajaxGetMyProposal(SS_HTTPRequest $request) {
        $a = new LqMemberDecorator();
        return $a->getPurchaseProposals($request->getVar('page'), $request->getVar('output'));
    }

    /**
     * Returns the shelves tab
     *
     * @return string
     */
    public function shelves() {
        return $this->renderWith('MyShelves');
    }

    /**
     * Returns the shelves tab
     *
     * @return string
     */
    public function searches() {
        return $this->renderWith('MySearches');
    }

    /**
     * Returns the resevations tab
     *
     * @return string
     */
    public function reservations() {
        return $this->renderWith('MyReservations');
    }

    /**
     * Reservations count
     *
     * @return string
     */
    public function reservationsCount() {
        if ($member = Member::currentUser())
            return $member->renderWith('MyReservationsCount');
    }

    /**
     * Returns the contacts list
     *
     * @return string
     */
    public function contacts() {
        return $this->renderWith('MyContacts');
    }

    /**
     * Returns the addresses list
     *
     * @return string
     */
    public function addresses() {
        return $this->renderWith('MyAddresses');
    }

    /**
     * Returns the active loans
     *
     * @return string
     */
    public function activeLoans() {
        return $this->renderWith('MyActiveLoans');
    }

    /**
     * Returns the dialog for managing a contact
     *
     * @param SS_HTTPRequest $request
     * @return string
     */
    public function contactDialog(SS_HTTPRequest $request) {
        $member = Member::currentUser();
        if (!$member)
            $this->htmlHttpError(404);

        try {
            $contact = new DataObject($member->getContact($request->getVar('id')));
        } catch (Exception $e) {
            $contact = new DataObject;
        }

        return $this
                        ->customise(array('Contact' => $contact, 'ContactTypes' => $this->getContactTypes($contact->ContactType)))
                        ->renderWith('MyContactDialog')
        ;
    }

    /**
     * Returns the dialog for managing a contact
     *
     * @return string
     */
    public function addressDialog(SS_HTTPRequest $request) {
        $member = Member::currentUser();
        if (!$member)
            $this->htmlHttpError(404);

        try {
            $address = new DataObject($member->getAddress($request->getVar('id')));
        } catch (Exception $e) {
            $address = new DataObject;
        }

        return $this
                        ->customise(array(
                            'Address' => $address,
                            'AddressTypes' => $this->getAddressTypes($address->AddressType),
                            'StreetTypes' => $this->getStreetTypes($address->StreetType)
                        ))
                        ->renderWith('MyAddressDialog')
        ;
    }

    /**
     * Delete a reservation
     *
     * @param SS_HTTPRequest $request
     */
    public function deleteReservation(SS_HTTPRequest $request) {
        $success = true;
        $params = $this->getURLParams();
        $id = $params['ID'];

        if (Member::currentUser()->ownsRequest($id)) {
            $connector = $this->getContainer()->get('liquens.connector');

            try {
                $this->checkPostAndOpacEnabled($request);
                $connector->cancelReservation($id);
            } catch (Exception $e) {
                $success = false;
                $this->addMessage('Error', $e->getMessage());
            }

            if ($success) {
                $this->addMessage('Success', _t('Profile.RESERVATION_DELETEDSUCCESS', 'The reservation request has been removed successfully'));

                //Throw Reservations updated event
                $this->getContainer()->get('dispatcher')->dispatch(
                        CirculationEvents::RESERVATIONS_UPDATED, new ReservationsUpdatedEvent(Member::currentUser())
                );
            }
        } else {
            $this->addMessage('Error', 'Operation forbidden');
        }
    }

    /**
     * Change the delivery Library of a request
     *
     * @param SS_HTTPRequest $request
     */
    public function changeReservationLib(SS_HTTPRequest $request) {
        $success = true;
        $requestId = $request->postVar('requestId');
        $libraryId = $request->postVar('libraryId');

        if (Member::currentUser()->ownsRequest($requestId)) {
            /** @var $connector LiquensConnector */
            $connector = $this->getContainer()->get('liquens.connector');

            try {
                $this->checkPostAndOpacEnabled($request);
                $connector->changeReservationDeliveryLibrary($requestId, $libraryId);
            } catch (Exception $e) {
                $success = false;
                $this->addMessage('Error', $e->getMessage());
            }

            if ($success)
                $this->addMessage('Success', _t('Profile.RESERVATION_CHANGE_DEVLIB_SUCCESS'));
        } else {
            $this->addMessage('Error', 'Operation forbidden');
        }
    }

    public function TelegramBotActive() {
        global $sc;
        if ($sc->getParameter('telegram_bot_active') != false) {
            $member = Member::currentUser();
            $userDataDng = $member->getExternalData();
            $connector = $this->getContainer()->get('liquens.connector');
            $userDataClavis = $connector->getUserData($userDataDng['username'], 'opac_username');
            $patron_ID = $userDataClavis["patron"]["PatronId"];
            if (!is_null($patron_ID)) {
                return true;
            }
        }
        return false;
    }

    public function TelegramBotUrl() {
        $member = Member::currentUser();
        $userDataDng = $member->getExternalData();
        $connector = $this->getContainer()->get('liquens.connector');
        $userDataClavis = $connector->getUserData($userDataDng['username'], 'opac_username');
        $patron_ID = $userDataClavis["patron"]["PatronId"];
        global $sc;
        if ($sc->getParameter('telegram_bot_name') != '') {
            return $sc->getParameter('telegram_bot_name') . "?start=" . $patron_ID . ":" . md5(crypt($patron_ID, $sc->getParameter('lq.connector.consortia_secret')));
        } else {
            return "javascript;";
        }
    }

    /**
     * Renew a loan
     */
    public function renewLoan(SS_HTTPRequest $request) {
        $success = true;
        $itemId = $request->postVar('id');

        //Check if current member is the owner of the loan
        $itemsIds = array_map(
                function($loan) {
            return $loan['ItemId'];
        }, Member::currentUser()->getActiveLoansAry()
        );

        if (in_array($itemId, $itemsIds)) {
            $connector = $this->getContainer()->get('liquens.connector');

            try {
                $connector->renewItemLoan($itemId);
            } catch (Exception $e) {
                $success = false;
                $this->addMessage('Error', $e->getMessage());
            }

            if ($success)
                $this->addMessage('Success', _t('Profile.LOAN_RENEW_SUCCESS', 'Loan successfully renewed'));
        } else {
            $this->addMessage('Error', 'Operation Forbidden');
        }
    }

    /**
     * Action to reserve a manifestation
     *
     * @param $request
     * @return string
     */
    public function reserve(SS_HTTPRequest $request) {
        try {
            $this->checkPostAndOpacEnabled($request);
        } catch (Exception $e) {
            return $this->jsonResponse(array('response_str' => $e->getMessage()));
        }

        $member = Member::currentUser();

        $libId = $request->param('LibraryID');
        $manId = $request->param('ManifestationID');
        
        $tail = json_decode($request->param('Tail'));
        
        $issueId = $tail[0];
        if ($issueId == 0)
            $issueId = null;
        
	$reserveNote = filter_var(stripslashes(trim($tail[1])), FILTER_SANITIZE_STRING);
        if ($reserveNote == '') 
            $reserveNote = null;
        
        if (strlen($reserveNote) > 255) 
            return $this->jsonResponse(array('response_str' => 'Nota troppo lunga (max 255 caratteri)'));

        // Convert trine ids in numerical ids
        if (strstr($manId, ':')) {
            $pieces = explode(':', $manId);
            $manId = $pieces[count($pieces) - 1];
        }

        $lq = $this->getContainer()->get('liquens.connector');
        try {
            $response = $lq->doReserve($manId, $member->getUsername(), $libId, $issueId ?: null, $reserveNote ?: null);
        } catch (Exception $e) {
            return $this->jsonResponse(array('response_str' => 'Non è stato possibile effettuare la prenotazione per un errore interno'));
        }

        Debug::log("Response reservation: MANID: ".$manId." MEMBER: ".$member->getUsername()." LIBRARYID: ".$libId." -> " . print_r($response, true));

        $response['response_str'] = _t('Reservation.' . $response['response_str'], $response['response_str']);

        //Throw Reservations updated event
        $this->getContainer()->get('dispatcher')->dispatch(
                CirculationEvents::RESERVATIONS_UPDATED, new ReservationsUpdatedEvent(Member::currentUser())
        );

        return $this->jsonResponse($response);
    }

    /**
     * Action to request a title on MLOL
     * The response is an array with the url and parameters to perform the next POST request
     *
     * @param $request
     * @return string
     */
    public function reserveMLOL(SS_HTTPRequest $request) {

        try {
            $this->checkPostAndOpacEnabled($request);
        } catch (Exception $e) {
            return $this->jsonResponse(array('response_str' => $e->getMessage()));
        }

        $member = Member::currentUser();
        // $manID is the numeric part of a MLOL trineId
        $manId = $request->param('ManifestationID');
        $mlol = $this->getContainer()->get('mlol.connector');

        if (is_null($member->External_Anchor)) {
            return false;
        }

        try {
            $response = $mlol->OpenMediaUniqueUser(
                    $manId, $member->Username, $member->External_Anchor
            );
        } catch (Exception $e) {
            return $this->jsonResponse(array('response_str' => $e->getMessage()));
        }

        return $this->jsonResponse($response);
    }

    /**
     * Effettua la richiesta al WS di MLOL acquisendo i dati relativi ai prestiti
     * 
     * @return type
     */
    public function loansMlol() {
        $member = Member::currentUser();
        $mlol = $this->getContainer()->get('mlol.connector');

        try {
            $response = $mlol->getUserLoans($member->Username);
        } catch (Exception $e) {
            return $this->jsonResponse(array('response_str' => $e->getMessage()));
        }

        if ((string) $response->status == 'ok') {
            $this->resultMlol = $response;
            return true;
        }

        return false;
    }

    public function mlolNoUser() {
        $member = Member::currentUser();
        if (is_null($member->External_Anchor)) {
            return false;
        }
    }

    /**
     * Ritorna i soli record dei prestiti in corso di MLOL
     * 
     * @return \DataObjectSet
     */
    public function loansMlolOpen() {
        $doSet = new DataObjectSet();
        $record = array('Incorso' => array());
        foreach ($this->resultMlol->media as $title) {
            if (date("Y-m-d") <= (string) $title->expired) {
                $record['Incorso']['id'] = (string) $title->id;
                $record['Incorso']['titolo'] = (string) $title->dc_title . " / " . $title->dc_creator;
                $record['Incorso']['acquired'] = date("d-m-Y", strtotime((string) $title->acquired));
                $record['Incorso']['expired'] = date("d-m-Y", strtotime((string) $title->expired));
                $doSet->push(new ArrayData($record));
            }
        }
        return $doSet;
    }

    /**
     * Ritorna i soli record dei prestiti conclusi di MLOL
     * 
     * @return \DataObjectSet
     */
    public function loansMlolClosed() {
        $doSet = new DataObjectSet();
        $record = array('Conclusi' => array());
        foreach ($this->resultMlol->media as $title) {
            if (date("Y-m-d") > (string) $title->expired) {
                $record['Conclusi']['id'] = (string) $title->id;
                $record['Conclusi']['titolo'] = (string) $title->dc_title . " / " . $title->dc_creator;
                $record['Conclusi']['acquired'] = date("d-m-Y", strtotime((string) $title->acquired));
                $record['Conclusi']['acquired_original'] = date("Ymd", strtotime((string) $title->acquired));
                $record['Conclusi']['expired'] = date("d-m-Y", strtotime((string) $title->expired));
                $record['Conclusi']['expired_original'] = date("Ymd", strtotime((string) $title->expired));
                $doSet->push(new ArrayData($record));
            }
        }
        return $doSet;
    }

    /**

     * Action to reserve a manifestation of an extra-catalog
     *
     * @param \SS_HTTPRequest $request SS_HTTPRequest
     * @throws Exception
     * @return string
     */
    public function reserveExtra(SS_HTTPRequest $request) {
        if ($request->httpMethod() != 'POST')
            throw new Exception('POST HTTP Method is required for this action');

        $member = Member::currentUser();
        $email = $member->getExternalEmail();

        //User must have a valid email
        if (!$email) {
            return $this->jsonResponse(array('response_str' => _t('Reservation.EXTRA_MEMBER_NOMAIL'), 'response_code' => 0));
        }

        //Library must have a valid email
        $connector = $this->getContainer()->get('liquens.connector');
        $data = $connector->getLibraryData($request->param('LibraryID'));
        if (isset($data['Email']) && trim($data['Email'] != ''))
            $libraryEmail = trim($data['Email']);
        else
            return $this->jsonResponse(array('response_str' => _t('Reservation.EXTRA_LIBRARY_NOMAIL'), 'response_code' => 0));
        
        /** @var $manifestationRepo ManifestationRepository */
        $manifestationRepo = $this->getContainer()->get('manifestation_repo_essential');

        $manifestation = $manifestationRepo->getOneById($request->param('ManifestationID'));

        $tail = $request->param('Tail');
        $tail = json_decode($tail);
        
//        $issueId = $tail[0];
	$reserveNote = filter_var(stripslashes(trim($tail[1])), FILTER_SANITIZE_STRING); 
        
        if (strlen($reserveNote) > 255) 
            return $this->jsonResponse(array('response_str' => 'Nota troppo lunga (max 255 caratteri)'));
        
        $dataToPassToEmail = new DataObject(array(
            'Member' => $member,
            'ManURL' => Director::absoluteURL('opac/detail/view/' . $request->param('ManifestationID')),
            'Manifestation' => $manifestation,
            'NotaUtente' => $reserveNote
        ));

        $body = $dataToPassToEmail->renderWith(array('ExtraSystemReservationEmail'));
        $this->sendEmailToLibrary($libraryEmail, $email, 'Prenotazione Titolo Extra-Sistema', $body);

        $response = array();
        $response['response_str'] = _t('Reservation.EXTRA_SUCCESS');
        $response['response_code'] = 1;

        return $this->jsonResponse($response);
    }

    /**
     * Action to reserve a manifestation of an extra-catalog
     *
     * @param \SS_HTTPRequest $request SS_HTTPRequest
     *
     * @throws Exception
     *
     * @return string
     */
    public function renewExtra(SS_HTTPRequest $request) {
        $itemId = $request->postVar('id');
        $member = Member::currentUser();
        $email = $member->getExternalEmail();

        //User must have a valid email
        if (!$email) {
            $this->addMessage('Error', _t('Reservation.EXTRA_MEMBER_NOMAIL'));
            return;
        }

        $activeLoans = $member->getActiveLoansAry();

        //Check if the itemid is in the activeloans of the user
        $isInMemberActiveLoans = false;
        $loanToRenew = array();

        foreach ($activeLoans as $loan) {
            if (isset($loan['ItemId']) && $loan['ItemId'] == $itemId) {
                $isInMemberActiveLoans = true;
                $loanToRenew = $loan;
                break;
            }
        }

        if (!$isInMemberActiveLoans) {
            $this->addMessage('Error', _t('MyDiscovery.LOANS_EXTRA_RENEW_INVALID'));
            return;
        }

        //Retrieve home library name
        $connector = $this->getContainer()->get('liquens.connector');
        $ownerLibData = $connector->getLibraryData($loanToRenew['OwnerLibraryId']);

        $loanToRenew['OwnerLibrary'] = $ownerLibData;

        $dataToPassToEmail = new DataObject(array(
            'Member' => $member,
            'Loan' => new ArrayData($loanToRenew),
        ));

        //Library must have a valid email
        $connector = $this->getContainer()->get('liquens.connector');
        $data = $connector->getLibraryData($request->param('LibraryID'));
        if (isset($data['Email']) && trim($data['Email'] != ''))
            $libraryEmail = trim($data['Email']);
        else
            return $this->jsonResponse(array('response_str' => _t('Reservation.EXTRA_LIBRARY_NOMAIL'), 'response_code' => 0));
        
        $body = $dataToPassToEmail->renderWith(array('ExtraSystemRenewEmail'));
        try {
            $this->sendEmailToLibrary($libraryEmail, $email, 'Richiesta di rinnovo prestito Extra Sistema', $body);
        } catch (Exception $e) {
            $this->addMessage('Error', "C'è stato un errore nel processare la richiesta. Verifica la correttezza del tuo indirizzo email e riprova.");
            return;
        }

        $this->addMessage('Success', _t('MyDiscovery.LOANS_EXTRA_RENEW_SUCCESS'));
    }

    public function reserveShard(SS_HTTPRequest $request) {
        if ($request->httpMethod() != 'POST')
            throw new Exception('POST HTTP Method is required for this action');

        $member = Member::currentUser();
        $email = $member->getExternalEmail();

        //User must have a valid email
        if (!$email) {
            return $this->jsonResponse(array('response_str' => _t('Reservation.EXTRA_MEMBER_NOMAIL'), 'response_code' => 0));
        }
        
        // Global receiver email
        $libraryEmail = (string) trim(DataObject::get_one('SiteConfig')->ShardReceiverGlobalEmail);
        if (!isset($libraryEmail) || $libraryEmail == '' || is_null($libraryEmail)) {
            //Library must have a valid email
            $connector = $this->getContainer()->get('liquens.connector');
            $data = $connector->getLibraryData($request->param('LibraryID'));
            if (isset($data['Email']) && trim($data['Email']) != '')
                $libraryEmail = trim($data['Email']);
            else {
                // Fallback email
                $fallbackEmail = (string) trim(DataObject::get_one('SiteConfig')->ShardReceiverFallbackEmail);
                if (!isset($fallbackEmail) || $fallbackEmail == '' || is_null($fallbackEmail)) 
                    return $this->jsonResponse(array('response_str' => _t('Reservation.EXTRA_LIBRARY_NOMAIL'), 'response_code' => 0));
                else
                    $libraryEmail = $fallbackEmail;
            }
        }
        
        /** @var $manifestationRepo ManifestationRepository */
        $manifestationRepo = $this->getContainer()->get('manifestation_repo_essential');

        $manifestation = $manifestationRepo->getOneById($request->param('ManifestationID'));
        
        $tail = $request->param('Tail');
        $tail = json_decode($tail);
        
//        $issueId = $tail[0];
	$reserveNote = filter_var(stripslashes(trim($tail[1])), FILTER_SANITIZE_STRING); 
        
        if (strlen($reserveNote) > 255) 
            return $this->jsonResponse(array('response_str' => 'Nota troppo lunga (max 255 caratteri)'));

        $dataToPassToEmail = new DataObject(array(
            'Member' => $member,
            'ClavisLink' => '(<a href="' . Director::absoluteURL('clavisng/index.php?page=Circulation.PatronViewPage&id=' . explode(":", $member->External_Anchor)[1]) . '">Scheda utente in Clavis</a>)',
            'ManURL' => Director::absoluteURL('opac/detail/view/' . $request->param('ManifestationID')),
            'Manifestation' => $manifestation,
            'NotaUtente' => $reserveNote,
            'Sistema' => Manifestation::shardName($request->param('ManifestationID')),
            'Locale' => apc_exists("shardEdK_" . $request->param('ManifestationID')) ? 'Potrebbero essere presenti edizioni nel sistema locale <a href="' . Director::absoluteURL('opac/search/?solr=' . str_replace("\\\\", "\\", apc_fetch("shardEdK_" . $request->param('ManifestationID')))) . '">qui</a><br /><br />' : ""
        ));

        $body = $dataToPassToEmail->renderWith(array('ShardSystemReservationEmail'));
        $this->sendEmailToLibrary($libraryEmail, $email, 'Prenotazione Titolo Extra-Sistema', $body);

        $response = array();
        $response['response_str'] = _t('Reservation.EXTRA_SUCCESS');
        $response['response_code'] = 1;

        return $this->jsonResponse($response);
    }

    public function renewShard(SS_HTTPRequest $request) {
        $itemId = $request->postVar('id');
        $member = Member::currentUser();
        $email = $member->getExternalEmail();

        //User must have a valid email
        if (!$email) {
            $this->addMessage('Error', _t('Reservation.EXTRA_MEMBER_NOMAIL'));
            return;
        }

        $activeLoans = $member->getActiveLoansAry();

        //Check if the itemid is in the activeloans of the user
        $isInMemberActiveLoans = false;
        $loanToRenew = array();

        foreach ($activeLoans as $loan) {
            if (isset($loan['ItemId']) && $loan['ItemId'] == $itemId) {
                $isInMemberActiveLoans = true;
                $loanToRenew = $loan;
                break;
            }
        }

        if (!$isInMemberActiveLoans) {
            $this->addMessage('Error', _t('MyDiscovery.LOANS_EXTRA_RENEW_INVALID'));
            return;
        }

        //Retrieve home library name
        $connector = $this->getContainer()->get('liquens.connector');
        $ownerLibData = $connector->getLibraryData($loanToRenew['OwnerLibraryId']);

        $loanToRenew['OwnerLibrary'] = $ownerLibData;

        $dataToPassToEmail = new DataObject(array(
            'Member' => $member,
            'Loan' => new ArrayData($loanToRenew),
        ));

        // Global receiver email
        $libraryEmail = (string) trim(DataObject::get_one('SiteConfig')->ShardReceiverGlobalEmail);
        if (!isset($libraryEmail) || $libraryEmail == '' || is_null($libraryEmail)) {
            //Library must have a valid email
            $connector = $this->getContainer()->get('liquens.connector');
            $data = $connector->getLibraryData($request->param('LibraryID'));
            if (isset($data['Email']) && trim($data['Email'] != ''))
                $libraryEmail = trim($data['Email']);
            else {
                // Fallback email
                $fallbackEmail = (string) trim(DataObject::get_one('SiteConfig')->ShardReceiverFallbackEmail);
                if (!isset($fallbackEmail) || $fallbackEmail == '' || is_null($fallbackEmail)) 
                    return $this->jsonResponse(array('response_str' => _t('Reservation.EXTRA_LIBRARY_NOMAIL'), 'response_code' => 0));
                else
                    $libraryEmail = $fallbackEmail;
            }
        }
        
        $body = $dataToPassToEmail->renderWith(array('ShardSystemRenewEmail'));
        try {
            $this->sendEmailToLibrary($libraryEmail, $email, 'Richiesta di rinnovo prestito Multi Sistema', $body);
        } catch (Exception $e) {
            $this->addMessage('Error', "C'è stato un errore nel processare la richiesta. Verifica la correttezza del tuo indirizzo email e riprova.");
            return;
        }

        $this->addMessage('Success', _t('MyDiscovery.LOANS_EXTRA_RENEW_SUCCESS'));
    }

    private $CheckProposalTypeArray;
    
    public function CheckProposalType() {
        if ($this->PurchaseProposalType != '') {
            $types = array('' => '---');
            foreach (explode(";", $this->PurchaseProposalType) as $t) {
                $types[trim($t)] = ucfirst(trim($t));
            }
            if (!empty($types)) {
                $this->CheckProposalTypeArray = $types;
                return true;
            }
        }
        return false;
    }
    
    /**
     * Return the contact edit form
     *
     * @return \CustomizedForm
     */
    public function PurchaseProposalForm() {
        SecurityToken::disable();

        $fields = new FieldSet(
                new TextField('author', _t('Profile.PROPOSAL_AUTHOR', 'Author, singer, director')." *"), 
                new TextField('title', _t('Profile.PROPOSAL_TITLE', 'Title')." *"),
                new TextField('publisher', _t('Profile.PROPOSAL_PUBLISHER', 'Publisher, distributor')),
                new TextField('year', _t('Profile.PROPOSAL_YEAR', 'Year')),
                new TextField('ean', _t('Profile.PROPOSAL_EAN', 'EAN')), 
                new TextareaField('note', _t('Profile.PROPOSAL_NOTE', 'Note'))
        );
        
        $actions = new FieldSet(new FormAction("addPurchaseProposal", _t('Profile.SUBMITFORM', 'Submit!')));

        $validator = new ComplexValidator(array(
            'title' => 'required',
            'author' => 'required'
        ));

        $form = new CustomizedForm($this, "PurchaseProposalForm", $fields, $actions, $validator);
        $form->setHTMLID('purchaseProposalForm');

        return $form;
    }

    public function PurchaseProposalTypeForm() {
        SecurityToken::disable();

        $fields = new FieldSet(
                new TextField('author', _t('Profile.PROPOSAL_AUTHOR', 'Author, singer, director')." *"), 
                new TextField('title', _t('Profile.PROPOSAL_TITLE', 'Title')." *"),
                new DropdownField('proposalType', 'Tipologia *', $this->CheckProposalTypeArray),
                new TextField('publisher', _t('Profile.PROPOSAL_PUBLISHER', 'Publisher, distributor')),
                new TextField('year', _t('Profile.PROPOSAL_YEAR', 'Year')),
                new TextField('ean', _t('Profile.PROPOSAL_EAN', 'EAN')), 
                new TextareaField('note', _t('Profile.PROPOSAL_NOTE', 'Note'))
        );
        
        $actions = new FieldSet(new FormAction("addPurchaseProposal", _t('Profile.SUBMITFORM', 'Submit!')));

        $validator = new ComplexValidator(array(
            'title' => 'required',
            'author' => 'required',
            'proposalType' => 'required'
        ));

        $form = new CustomizedForm($this, "PurchaseProposalTypeForm", $fields, $actions, $validator);
        $form->setHTMLID('purchaseProposalForm');

        return $form;
    }
    
    /**
     * Handle the insertion of new Purchase Proposals
     *
     * @param $formData
     * @param Form $form
     */
    public function addPurchaseProposal($formData, Form $form) {
        $connector = $this->getContainer()->get('liquens.connector');
        $success = true;

        try {
            if ($this->CheckProposalType()) 
                $connector->editPurchaseProposal(
                        Member::currentUser()->getUsername(), '', //contact_id. Empty for new proposal
                        $formData['title']. " (" . $formData['proposalType'] . ")", $formData['author'], $formData['publisher'], $formData['year'], $formData['ean'], "(" . $formData['proposalType'] . ") " . $formData['note']
                );
            else 
                $connector->editPurchaseProposal(
                        Member::currentUser()->getUsername(), '', //contact_id. Empty for new proposal
                        $formData['title'], $formData['author'], $formData['publisher'], $formData['year'], $formData['ean'], $formData['note']
                );
        } catch (Exception $e) {
            $this->addMessage('Error', $e->getMessage());
            $success = false;
        }

        if ($success) {
            $this->addMessage('Success', _t('ProfilePage.PROPOSAL_EDITSUCCESS', 'Purchase proposal successfully saved'));
        }

        $this->redirectBack('proposals_my');
    }

    /**
     * Delete a proposal
     */
    public function deletePurchaseProposal(SS_HTTPRequest $request) {
        $success = true;
        $params = $this->getURLParams();
        $id = $params['ID'];

        $connector = $this->getContainer()->get('liquens.connector');
        try {
            $response = $connector->getPurchaseProposalList($member = Member::currentUser()->username, "A");
        } catch (Exception $e) {
            $response = array();
            $this->addMessage('Error', $e->getMessage());
        }

        if (!empty($response)) {
            unset($response[0]);

            try {
                $connector->retirePurchaseProposal($id);
            } catch (Exception $e) {
                $success = false;
                $this->addMessage('Error', $e->getMessage());
            }

            if ($success) {
                $this->addMessage('Success', _t('ProfilePage.PROPOSAL_DELETESUCCESS', 'Purchase proposal successfully removed'));
            } else {
                $this->addMessage('Error', _t('ProfilePage.PROPOSAL_DELETEERROR', 'Purchase proposal not withdrawn'));
            }
        } else {
            $this->addMessage('Error', _t('ProfilePage.PROPOSAL_DELETEERROR', 'Purchase proposal not withdrawn'));
        }

        $this->redirectBack('proposals_my');
    }
    
    public function EditPrivacyCheckPatron() {
        global $sc;
        if ($sc->getParameter('mandatory_privacy') == true) {
            SecurityToken::disable();
            $currMember = Member::currentUser();
            $externalData = $currMember->getExternalData();
            if ($externalData["group"] == "patron") 
                return true;
        }
        return false;
    }
    
    public function EditPrivacyForm() {
        $properties = array();
        
        SecurityToken::disable();
        $currMember = Member::currentUser();
        $externalData = $currMember->getExternalData();

        if($externalData["patron"]['PrivacyApprove'] === "1") {
            $cp = new CheckboxField_Disabled("choose_privacy", "Già accettato. Per eliminare la preferenza rivolgersi alla propria biblioteca.", true);
        } else {
            $cp = new CheckboxField("choose_privacy", "Accetta (obbligatorio)", $externalData["patron"]['PrivacyApprove']);
        }
        
        if( (!empty($externalData['properties'][0])) && (($this->ExternalDataTransmissionCheck) || ($this->NewsletterCheck) || ($this->Attr3Check) || ($this->Attr4Check) || ($this->Attr5Check))){
            foreach ($externalData['properties'][0] as $value) {
                $properties[$value["PropertyClass"]] = 0;
                $v = strtolower($value["PropertyValue"]);
                if ($v == "y" || $v == "yes" || $v == "s" || $v == "si") {
                    $properties[$value["PropertyClass"]] = 1;
                }
            }
            $dv = new CheckboxField("choose_data", "Scegli", $properties[$this->ExternalDataTransmissionClavisParam]);
            $nv = new CheckboxField("choose_newsletter", "Scegli", $properties[$this->NewsletterClavisParam]);
            $p3 = new CheckboxField("choose_p3", "Scegli", $properties[$this->Attr3ClavisParam]);
            $p4 = new CheckboxField("choose_p4", "Scegli", $properties[$this->Attr4ClavisParam]);
            $p5 = new CheckboxField("choose_p5", "Scegli", $properties[$this->Attr5ClavisParam]);            
        } else {
            $dv = new CheckboxField("choose_data", "Scegli", 0);
            $nv = new CheckboxField("choose_newsletter", "Scegli", 0);
            $p3 = new CheckboxField("choose_p3", "Scegli", 0);
            $p4 = new CheckboxField("choose_p4", "Scegli", 0);
            $p5 = new CheckboxField("choose_p5", "Scegli", 0);
        }
        
        $fields = new FieldSet(
                new LiteralField("title_privacy", $this->PrivacyPolicyTitle), new LiteralField("text_privacy", $this->PrivacyPolicy), $cp,
                new LiteralField("title_data", $this->ExternalDataTransmissionTitle),
                new LiteralField("text_data", $this->ExternalDataTransmission), $dv,
                new LiteralField("title_newsletter", $this->NewsletterTitle), new LiteralField("text_newsletter", $this->Newsletter), $nv,
                new LiteralField("title_p3", $this->Attr3Title), new LiteralField("text_p3", $this->Attr3Text), $p3,
                new LiteralField("title_p4", $this->Attr4Title), new LiteralField("text_p4", $this->Attr4Text), $p4,
                new LiteralField("title_p5", $this->Attr5Title), new LiteralField("text_p5", $this->Attr5Text), $p5,
                /* Utile per creare gli if con jquery */
                new HiddenField("hidden_datatransmission", null, $this->ExternalDataTransmissionCheck ? $this->ExternalDataTransmissionClavisParam : 0),
                new HiddenField("hidden_newsletter", null, $this->NewsletterCheck ? $this->NewsletterClavisParam : 0),
                new HiddenField("hidden_p3", null, $this->Attr3Check ? $this->Attr3ClavisParam : 0),
                new HiddenField("hidden_p4", null, $this->Attr4Check ? $this->Attr4ClavisParam : 0),
                new HiddenField("hidden_p5", null, $this->Attr5Check ? $this->Attr5ClavisParam : 0)
        );
        
        $actions = new FieldSet(new FormAction("doPrivacyEdit", _t('Profile.SUBMITFORM', 'Submit!')));
        
        $validator = new ComplexValidator();
        
        $form = new CustomizedForm($this, "EditPrivacyForm", $fields, $actions, $validator);
        return $form;
    }
    
    public function doPrivacyEdit($formData, Form $form) {
        SecurityToken::disable();
        
        $member = Member::currentUser();
        $connector = $this->getContainer()->get('liquens.connector');
        $success = true;
        $pa = null;
        
        if (isset($formData['choose_privacy'])) {
            if ($formData['choose_privacy'] == 0) {
                Session::clear("FeedbackMessages");
                $this->addMessage('Error', $this->owner->PrivacyModal);
                $success = false;
            } else $pa = $formData['choose_privacy'];
        }
        if ($success) {
            $cd = isset($formData['choose_data']) ? $formData['hidden_datatransmission'].":".($formData['choose_data'] == 1 ? "si" : "no") : '';
            $nl = isset($formData['choose_newsletter']) ? $formData['hidden_newsletter'].":".($formData['choose_newsletter'] == 1 ? "si" : "no") : '';
            $p3 = isset($formData['choose_p3']) ? $formData['hidden_p3'].":".($formData['choose_p3'] == 1 ? "si" : "no") : '';
            $p4 = isset($formData['choose_p4']) ? $formData['hidden_p4'].":".($formData['choose_p4'] == 1 ? "si" : "no") : '';
            $p5 = isset($formData['choose_p5']) ? $formData['hidden_p5'].":".($formData['choose_p5'] == 1 ? "si" : "no") : '';

            try {
                $response = $connector->setPrivacy($member->getUsername(), $pa, $cd, $nl, $p3, $p4, $p5);
             } catch (Exception $e) {
                $this->addMessage('Error', $e->getMessage());
                $success = false;
            }

            if ($success) {
                Session::clear("FeedbackMessages");
                $this->addMessage('Success', _t('ProfilePage.EDITSUCCESS', 'Your datas have been updated correctly'));
            }
        }
        
        $this->redirectBack('privacy');
    }
    
    /**
     * Return the profile edit form
     * @return \CustomizedForm
     */
    public function EditProfileForm() {
        SecurityToken::disable();
        $currMember = Member::currentUser();
        $externalData = $currMember->getExternalData();

        $locales = array();
        foreach (Translatable::get_allowed_locales() as $locale) {
            $locales[$locale] = i18n::$all_locales[$locale];
        }

        $avatarField = new SimpleImageField('Avatar', _t('Profile.AVATAR', 'Load here a picture of you'));
        $avatarField->getValidator()->setAllowedExtensions(array('png', 'gif', 'jpg', 'jpeg'));

        global $sc;

        if ($sc->getParameter('is_library') == true) {
            $fields = new FieldSet(
                    new PasswordField("old_password", _t('Profile.OLDPASSWORD', 'Old password')), 
                    new PasswordField("new_password", _t('Profile.NEWPASSWORD', 'New password')), 
                    new PasswordField("confirm_new_password", _t('Profile.CONFIRMNEWPASSWORD', 'Confirm new password')), 
                    new TextareaField("biography", _t('Profile.BIO', 'Tell us something about you'), 5, 20, $currMember->Biography), 
                    $avatarField, 
                    new CheckboxField("gravatar", _t('Profile.PICKFROMGRAVATAR', 'Pick your avatar image from Gravatar (warning: this will overwrite your old avatar)'), !(bool) $currMember->AvatarID), 
                    new DropdownField("preferred_library_id", _t('Registration.PREFERRED_LIBRARY', "Biblioteca preferita"), $this->getLibraryRepository()->getInternalLibraries('ExternalID', 'shortName'), isset($externalData['PreferredLibraryId']) ? $externalData['PreferredLibraryId'] : ''), 
                    new DropdownField("locale", _t('Member.INTERFACELANG', "Interface Language"), $locales, $currMember->Locale), 
                    new CheckboxField("profile_visible", _t('ProfilePage.PRIVACY_PROFILEVISIBLE', 'My profile is public and visible to all users'), Member::currentUser()->getPrivacySetting('profile_visible')), 
                    new CheckboxField("use_only_user_id", _t('ProfilePage.PRIVACY_USEONLYUSERID'), Member::currentUser()->getPrivacySetting('use_only_user_id')), 
                    new CheckboxField("use_only_username", _t('ProfilePage.PRIVACY_USEONLYUSERNAME', 'Display my username instead of my real name'), Member::currentUser()->getPrivacySetting('use_only_username'))
            );
        } else {
            $fields = new FieldSet(
                    new PasswordField("old_password", _t('Profile.OLDPASSWORD', 'Old password')), 
                    new PasswordField("new_password", _t('Profile.NEWPASSWORD', 'New password')), 
                    new PasswordField("confirm_new_password", _t('Profile.CONFIRMNEWPASSWORD', 'Confirm new password')), 
                    new TextareaField("biography", _t('Profile.BIO', 'Tell us something about you'), 5, 20, $currMember->Biography), 
                    $avatarField, 
                    new CheckboxField("gravatar", _t('Profile.PICKFROMGRAVATAR', 'Pick your avatar image from Gravatar (warning: this will overwrite your old avatar)'), !(bool) $currMember->AvatarID), 
                    new DropdownField("preferred_library_id", _t('Registration.PREFERRED_MUSEUM', "Museo preferito"), $this->getLibraryRepository()->getInternalLibraries('ExternalID', 'shortName'), isset($externalData['PreferredLibraryId']) ? $externalData['PreferredLibraryId'] : ''), 
                    new DropdownField("locale", _t('Member.INTERFACELANG', "Interface Language"), $locales, $currMember->Locale), 
                    new CheckboxField("profile_visible", _t('ProfilePage.PRIVACY_PROFILEVISIBLE', 'My profile is public and visible to all users'), Member::currentUser()->getPrivacySetting('profile_visible')), 
                    new CheckboxField("use_only_user_id", _t('ProfilePage.PRIVACY_USEONLYUSERID'), Member::currentUser()->getPrivacySetting('use_only_user_id')), 
                    new CheckboxField("use_only_username", _t('ProfilePage.PRIVACY_USEONLYUSERNAME', 'Display my username instead of my real name'), Member::currentUser()->getPrivacySetting('use_only_username'))
            );
        }
        $actions = new FieldSet(new FormAction("doEdit", _t('Profile.SUBMITFORM', 'Submit!')));

        $validator = new ComplexValidator(
                array(
            "new_password" => array(
                'minlength' => 6,
                'maxlength' => 16,
            ),
            "confirm_new_password" => array(
                "equalToByName" => "new_password"
            ),
                ), array(
            'confirm_new_password' => _t('Validation.PASSWORDEQUALS', 'Password must match')
                )
        );

        $form = new CustomizedForm($this, "EditProfileForm", $fields, $actions, $validator);

        return $form;
    }

    /**
     * Handle EditProfileForm submission
     *
     * @param $formData
     * @param Form $form
     */
    public function doEdit($formData, Form $form) {
        $member = Member::currentUser();
        $connector = $this->getContainer()->get('liquens.connector');
        $success = true;

        try {
            if ($formData['new_password']) {
                global $sc;
                $connector->setNewPassword(
                        $member->getUsername(), 
                        $formData['old_password'], 
                        $formData['new_password'],
                        $sc->getParameter('opac_password_expire') == false ? NULL : date('Y-m-d', strtotime("+".$sc->getParameter('opac_password_expire')." days")));
            }
            
            $userData = $member->getExternalData();

            if ($formData['biography']) {
                $member->Biography = strip_tags($formData['biography']);
            }

            $member->Locale = $formData['locale'];

            if (isset($formData['gravatar']) && $formData['gravatar']) {
                $member->AvatarID = 0;
            }

            if (isset($formData['Avatar']) && $formData['Avatar']['size']) {
                /** @var $imageField SimpleImageField */
                $imageField = $form->Fields()->fieldByName('Avatar');
                $imageField->saveInto($member);
            }

            $member->setPrivacySetting('profile_visible', isset($formData['profile_visible']) && $formData['profile_visible']);
            $member->setPrivacySetting('use_only_username', isset($formData['use_only_username']) && $formData['use_only_username']);
            $member->setPrivacySetting('use_only_user_id', isset($formData['use_only_user_id']) && $formData['use_only_user_id']);

            $member->write();

            $connector->setUserPrefs(
                    $member->getUsername(), $formData['preferred_library_id'], isset($userData['StatisticStudy']) ? $userData['StatisticStudy'] : null, isset($userData['StatisticWork']) ? $userData['StatisticWork'] : null, isset($userData['AreasOfInterest']) ? $userData['AreasOfInterest'] : null
            );
        } catch (Exception $e) {
            $this->addMessage('Error', $e->getMessage());
            $success = false;
        }

        if ($success) {
            $this->addMessage('Success', _t('ProfilePage.EDITSUCCESS', 'Your datas have been updated correctly'));
        }

        $this->redirectBack('settings_data');
    }

    public function CanUserContactLibrary() {
        if ($this->owner->UserContactToLibrary == 1) {
            return true;
        }
        return false;
    }
    
    /**
     * Form per l'invio dell'email di assistenza
     * 
     * @return \CustomizedForm
     */
    public function MyLibraryContact() {

        SecurityToken::disable();
        global $sc;

        if ($sc->getParameter('is_library') == true) {
            $fields = new FieldSet(
                    new TextField("contact_subject", _t('MyDiscovery.ASSISTANCE_USER_OBJECT', 'Subject of the request')), 
                    new TextareaField("contact_text", _t('MyDiscovery.ASSISTANCE_USER_TEXT', 'Write your request')), 
                    new DropdownField("preferred_library_id", _t('Registration.PREFERRED_LIBRARY', "Biblioteca preferita"), $this->getLibraryRepository()->getInternalLibraries('ExternalID', 'shortName'), isset($externalData['PreferredLibraryId']) ? $externalData['PreferredLibraryId'] : '')
            );
        } else {
            $fields = new FieldSet(
                    new TextField("contact_subject", _t('MyDiscovery.ASSISTANCE_USER_OBJECT', 'Subject of the request')), 
                    new TextareaField("contact_text", _t('MyDiscovery.ASSISTANCE_USER_TEXT', 'Write your request')), 
                    new DropdownField("preferred_library_id", _t('Registration.PREFERRED_MUSEUM', "Museo preferito"), $this->getLibraryRepository()->getInternalLibraries('ExternalID', 'shortName'), isset($externalData['PreferredLibraryId']) ? $externalData['PreferredLibraryId'] : '')
            );
        }
        $actions = new FieldSet(new FormAction("doMyLibraryContact", _t('Profile.SUBMITFORM', 'Submit!')));

        $form = new CustomizedForm($this, "MyLibraryContact", $fields, $actions, $validator = null);

        $form->dataFieldByName('contact_subject')->addExtraClass('required');
        $form->dataFieldByName('contact_text')->addExtraClass('required');

        return $form;
    }

    /**
     * Funzione Handle per form MyLibraryContact
     */
    public function doMyLibraryContact($formData, Form $form) {

        $request_text = $formData['contact_text'];
        $request_subject = $formData['contact_subject'];

        $member = Member::currentUser();
        $userDataDng = $member->getExternalData();
        $connector = $this->getContainer()->get('liquens.connector');

        // Dati utente, ricavati da Clavis
        $userDataClavis = $connector->getUserData($userDataDng['username'], 'opac_username');

        // Verifica la presenza dell'email dell'utente
        if (!isset($userDataClavis['email']) || $userDataClavis['email'] == '') {
            $this->addMessage('Error', _t('MyDiscovery.ASSISTANCE_MAIL_KO', 'E-mail is not sent. Missing email. Edit your contacts.'));
            $this->redirectBack('help_library');
        }

        // Ricavo le informazioni sulla biblioteca preferita/selezionata dall'utente
        $pref_lib_id = ($userDataClavis['patron']['PreferredLibraryId'] != 0) ? $userDataClavis['patron']['PreferredLibraryId'] : $userDataClavis['patron']['RegistrationLibraryId'];
        $librarydata = $connector->getLibraryData($pref_lib_id);

        if (!isset($librarydata['Email']) || $librarydata['Email'] == '') {
            $this->addMessage('Error', "La biblioteca non ha alcuna email valida a cui inviare la richiesta.");
            $this->redirectBack('help_library');
        }
        
        $success = true;
        
        // Nome dell'OPAC
        $siteTitle = DataObject::get_one('SiteConfig')->Title;

        global $sc;

        $mail = new PHPMailer;

        $mail->isSMTP();
        $mail->Host = $sc->getParameter('phpmailer.smtp');
        $mail->Port = $sc->getParameter('phpmailer.smtp_port');
        $mail->SMTPAuth = $sc->getParameter('phpmailer.auth');

        if (!is_null($sc->getParameter('phpmailer.username')))
            $mail->Username = $sc->getParameter('phpmailer.username');
        if (!is_null($sc->getParameter('phpmailer.password')))
            $mail->Password = $sc->getParameter('phpmailer.password');
        if (!is_null($sc->getParameter('phpmailer.security')))
            $mail->SMTPSecure = $sc->getParameter('phpmailer.security');

        $mail->isHTML(true);

        // Creo clone dei parametri iniziali
        $mail2 = clone $mail;

        if (!is_null($sc->getParameter('phpmailer.forcedFrom'))) 
            $mail->setFrom($sc->getParameter('phpmailer.forcedFrom'), $siteTitle);
        else
            $mail->setFrom($sc->getParameter('system_email'), $siteTitle);

        $mail->addAddress($librarydata['Email']);
        $mail->addReplyTo($userDataClavis['email'], $siteTitle);

        $mail->Subject = 'Richiesta di assistenza - ' . $siteTitle;
        $mail->Body = $this->customise(
                        array(
                            'Username' => $userDataClavis['username'],
                            'Firstname' => $userDataClavis['firstname'],
                            'Surname' => $userDataClavis['surname'],
                            'Barcode' => $userDataClavis['patron']['Barcode'],
                            'Subject' => $request_subject,
                            'Text' => $request_text,
                            'SiteTitle' => $siteTitle,
                            'Clavislink' => $sc->getParameter('ils.url') . "/index.php?page=Circulation.PatronViewPage&id=" . $userDataClavis['ClavisUserID']
                        )
                )->renderWith('EmailToLibrary');

        /* Invio email a biblioteca */
        try {
            if (!$mail->send()) {
                $this->addMessage('Error', _t('MyDiscovery.ASSISTANCE_MAIL_ERROR', 'E-mail is not sent.'));
                Debug::log('PHPMailer ' . $siteTitle . ' Errore richiesta di assistenza (invio a biblioteca): ' . $mail->ErrorInfo);
                $success = false;
            }
        } catch (Exception $e) {
            $this->addMessage('Error', _t('MyDiscovery.ASSISTANCE_MAIL_ERROR', 'E-mail is not sent..') . " Error: " . $e->getMessage());
            Debug::log('PHPMailer ' . $siteTitle . ' Errore richiesta di assistenza (invio a utente): ' . $e->getMessage());
            $success = false;
            return;
        }

        /* Invio email a utente */
        if (!is_null($sc->getParameter('phpmailer.forcedFrom'))) 
            $mail2->setFrom($sc->getParameter('phpmailer.forcedFrom'), $siteTitle);
        else
            $mail2->setFrom($sc->getParameter('system_email'), $siteTitle);

        $mail2->addAddress($userDataClavis['email']);
        $mail2->addReplyTo($librarydata['Email'], $siteTitle);

        $mail2->Subject = 'Richiesta di assistenza - ' . $siteTitle;
        $mail2->Body = $this->customise(
                        array(
                            'Subject' => $request_subject,
                            'Text' => $request_text,
                            'SiteTitle' => $siteTitle
                        )
                )->renderWith('EmailToUser');
        try {
            if (!$mail2->send()) {
                $this->addMessage('Error', _t('MyDiscovery.ASSISTANCE_MAIL_ERROR', 'E-mail is not sent;'));
                Debug::log('PHPMailer ' . $siteTitle . ' Errore richiesta di assistenza (invio a utente): ' . $mail2->ErrorInfo);
                $success = false;
            }
        } catch (Exception $e) {
            $this->addMessage('Error', _t('MyDiscovery.ASSISTANCE_MAIL_ERROR', 'E-mail is not sent;;') . " Error: " . $e->getMessage());
            Debug::log('PHPMailer ' . $siteTitle . ' Errore richiesta di assistenza (invio a utente): ' . $e->getMessage());
            $success = false;
            return;
        }

        if ($success) {
            $this->addMessage('Success', _t('MyDiscovery.ASSISTANCE_MAIL_OK', 'E-mail successfully sent'));
        }

        $this->redirectBack('help_library');
    }

    /**
     * Add or edit a new Contact
     *
     * @param SS_HTTPRequest $request
     */
    public function editContact(SS_HTTPRequest $request) {
        $connector = $this->getContainer()->get('liquens.connector');
        $success = true;
        $response = array();

        try {
            $contactData = $connector->editContact(
                    Member::currentUser()->getUsername(), $request->postVar('id'), //contact_id. Empty for new contact
                    $request->postVar('type'), //contact_type
                    $request->postVar('value'), $request->postVar('pref') ? 1 : 0//contact_pref
            );
            $response['id'] = $contactData['ContactId'];
        } catch (Exception $e) {
            $this->addMessage('Error', $e->getMessage());
            $success = false;
        }

        if ($success) {
            $this->addMessage('Success', _t('ProfilePage.CONTACT_EDITSUCCESS', 'Your contact has been saved successfully'));
        }

        return $this->jsonResponse($response);
    }

    /**
     * Delete a contact
     */
    public function deleteContact(SS_HTTPRequest $request) {
        $success = true;
        $id = $request->postVar('id');

        //Check if current member is the owner of the address
        $contactsIds = array_map(
                function($contact) {
            return $contact['ContactId'];
        }, Member::currentUser()->getContactsAry()
        );

        if (in_array($id, $contactsIds)) {
            $connector = $this->getContainer()->get('liquens.connector');

            try {
                $connector->deleteContact($id);
            } catch (Exception $e) {
                $success = false;
                $this->addMessage('Error', $e->getMessage());
            }

            if ($success) {
                $this->addMessage('Success', _t('ProfilePage.CONTACT_DELETEDSUCCESS', 'The contact has been deleted successfully'));
            }
        } else {
            $this->addMessage('Error', 'Operation forbidden');
        }
    }

    /**
     * Delete an address
     */
    public function deleteAddress(SS_HTTPRequest $request) {
        $success = true;
        $id = $request->postVar('id');

        //Check if current member is the owner of the address
        $addresssIds = array_map(
                function($address) {
            return $address['AddressId'];
        }, Member::currentUser()->getAddressesAry()
        );

        if (in_array($id, $addresssIds)) {
            $connector = $this->getContainer()->get('liquens.connector');

            try {
                $connector->deleteAddress($id);
            } catch (Exception $e) {
                $success = false;
                $this->addMessage('Error', $e->getMessage());
            }

            if ($success)
                $this->addMessage('Success', _t('ProfilePage.ADDRESS_DELETEDSUCCESS', 'The address has been deleted successfully'));
        } else {
            $this->addMessage('Error', 'Operation forbidden');
        }
    }

    /**
     * Add or edit a new Address
     *
     * @param array $formData
     * @param Form $form
     */
    public function editAddress(SS_HTTPRequest $request) {
        $connector = $this->getContainer()->get('liquens.connector');
        $success = true;
        $response = array();

        try {
            $address = $connector->editAddress(
                    Member::currentUser()->getUsername(), $request->postVar('id'), //Create a new Address
                    $request->postVar('type'), $request->postVar('pref') ? 1 : 0, //address_pref
                    $request->postVar('street_type'), $request->postVar('street'), $request->postVar('street_num'), $request->postVar('village'), $request->postVar('city'), $request->postVar('zip'), $request->postVar('province'), $request->postVar('country')
            );
            $response['id'] = $address['AddressId'];
        } catch (Exception $e) {
            $this->addMessage('Error', $e->getMessage());
            $success = false;
        }

        if ($success) {
            $this->addMessage('Success', _t('ProfilePage.EDITSUCCESS', 'Your address has been saved successfully'));
        }

        return $this->jsonResponse($response);
    }

    /**
     * Check if the current member is logged, if it is opac enabled and
     * if the request use a POST method
     * Throw exceptions when fail.
     *
     * @param \SS_HTTPRequest $request
     * @return void
     * @throws Exception
     */
    private function checkPostAndOpacEnabled(SS_HTTPRequest $request) {
        if ($request->httpMethod() != 'POST')
            throw new Exception('POST HTTP Method is required for this action');

        $member = Member::currentUser();

        if (!$member)
            throw new Exception('User must be logged in');

        $enabled = $member->checkOpacEnable(true);

        if (!$enabled)
            throw new Exception('User must be Opac-Enabled');
    }

    private function sendEmailToLibrary($libraryEmail, $senderEmail, $subject, $body) {
        $siteTitle = DataObject::get_one('SiteConfig')->Title;

        global $sc;

        $mail = new PHPMailer;

        $mail->isSMTP();
        $mail->Host = $sc->getParameter('phpmailer.smtp');
        $mail->Port = $sc->getParameter('phpmailer.smtp_port');
        $mail->SMTPAuth = $sc->getParameter('phpmailer.auth');

        if (!is_null($sc->getParameter('phpmailer.username')))
            $mail->Username = $sc->getParameter('phpmailer.username');
        if (!is_null($sc->getParameter('phpmailer.password')))
            $mail->Password = $sc->getParameter('phpmailer.password');
        if (!is_null($sc->getParameter('phpmailer.security')))
            $mail->SMTPSecure = $sc->getParameter('phpmailer.security');

        if (!is_null($sc->getParameter('phpmailer.forcedFrom'))) 
            $mail->setFrom($sc->getParameter('phpmailer.forcedFrom'), $siteTitle);
        else
            $mail->setFrom($sc->getParameter('system_email'), $siteTitle);

        $mail->addAddress($libraryEmail);
        $mail->addReplyTo($senderEmail, $siteTitle);

        $mail->isHTML(true);

        $mail->Subject = $subject . " - " . $siteTitle;
        $mail->Body = $body;

        /* Invio email */
        try {
            if (!$mail->send()) {
                $this->addMessage('Error', _t('MyDiscovery.ASSISTANCE_MAIL_ERROR', 'E-mail is not sent.'));
                Debug::log('PHPMailer ' . $siteTitle . ' Errore richiesta alla biblioteca: ' . $mail->ErrorInfo);
            } else {
                $this->addMessage('Success', _t('MyDiscovery.ASSISTANCE_MAIL_OK', 'E-mail successfully sent'));
            }
        } catch (Exception $e) {
            $this->addMessage('Error', _t('MyDiscovery.ASSISTANCE_MAIL_ERROR', 'E-mail is not sent.') . " Error: " . $e->getMessage());
            return;
        }
    }

    /**
     * Transform an array to a dataobject set suitable for printing select options
     * in a ss template.
     * @param array $array
     * @param mixed $selected The key of the initial selected option
     * @return DataObjectSet
     */
    private function getSelectOptions(array $array, $selected = null) {
        $options = array(array(
                'Value' => '',
                'Label' => '---',
                'Selected' => $selected === null
        ));

        foreach ($array as $key => $label) {
            $options[] = array(
                'Value' => $key,
                'Label' => $label,
                'Selected' => $selected == $key
            );
        }

        return new DataObjectSet($options);
    }

    /**
     * Returns a viewable contact types hash
     *
     * @param mixed $selected
     * @return DataObjectSet
     */
    private function getContactTypes($selected = null) {
        return $this->getSelectOptions(i18nExtension::get_namespace_strings('LV_CONTACTTYPE'), $selected);
    }

    /**
     * Returns a viewable address types hash
     *
     * @param mixed $selected
     * @return DataObjectSet
     */
    private function getAddressTypes($selected = null) {
        return $this->getSelectOptions(i18nExtension::get_namespace_strings('LV_ADDRESSTYPE'), $selected);
    }

    /**
     * Returns a viewable street ypes hash
     *
     * @param mixed $selected
     * @return DataObjectSet
     */
    private function getStreetTypes($selected = null) {
        return $this->getSelectOptions(i18nExtension::get_namespace_strings('LV_STREET'), $selected);
    }

    public function getSameBasinLibrariesMap($favLibraryId) {
        $areaMap = LibrariesListPage::get_libraries_area_map();
        $memberArea = false;
        foreach ($areaMap as $area => $libs) {
            if (in_array($favLibraryId, $libs)) {
                $memberArea = $areaMap[$area];
                break;
            }
        }
        return $memberArea;
    }

    /**
     * Set LibraryRepository
     *
     * @param \LibraryRepository $libraryRepository
     *
     * @return MyDiscoveryPage_Controller The current instance
     */
    public function setLibraryRepository(\LibraryRepository $libraryRepository) {
        $this->libraryRepository = $libraryRepository;
        return $this;
    }

    /**
     * Get LibraryRepository
     *
     * @return \LibraryRepository
     */
    public function getLibraryRepository() {
        return $this->libraryRepository;
    }

}
