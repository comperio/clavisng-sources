<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
interface AdvancedSearchFieldInterface
{
    /**
     * @param $name
     * @return mixed
     */
    public function setName($name);

    /**
     * @return mixed
     */
    public function getName();

    /**
     * @return string
     */
    public function render();

    /**
     * @param array $options
     * @return AdvancedSearchFieldInterface the current instance
     */
    public function setOptions(array $options);

    /**
     * @return array
     */
    public function getOptions();

    /**
     * Get a single option
     *
     * @param $option
     * @return string|null
     */
    public function getOption($option);
}
