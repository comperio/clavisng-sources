<?php
/**
 * This file is part of dng
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

class SearchSensitiveTitle
{
    private $fields = array(
        'id-work',
        'id-subj',
        'id-auth',
        'id-marca',
        'edition-key'
    );

    /**
     * @var SolrQueryMapper
     */
    public $mapper;

    /**
     * @var string
     */
    private $fallbackTitle;

    /**
     * @param SolrQueryMapper $mapper
     * @param string $fallbackTitle
     * @param array $fields
     */
    public function __construct(SolrQueryMapper $mapper, $fallbackTitle = '', array $fields = null)
    {
        $this->mapper = $mapper;
        $this->fallbackTitle = $fallbackTitle;
        if (isset($fields))
            $this->fields = $fields;
    }

    /**
     * Returns a string of the kind "Auth-type: auth-value".
     * First encontered wins.
     *
     * @return string
     */
    public function __toString()
    {
        foreach ($this->fields as $field) {
            $data = $this->mapper->getFilter($field);
            if (isset($data)) {
                $label = isset($data['type']) ? _t('Catalog.AUTH_' . strtoupper($data['type'])) : '';
                return ($label ? "$label: " : "") . (isset($data['displayed']) ? $data['displayed'] : '');
            }
        }

        return $this->fallbackTitle;
    }
} 