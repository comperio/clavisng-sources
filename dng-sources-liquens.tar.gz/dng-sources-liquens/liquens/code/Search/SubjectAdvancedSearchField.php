<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class SubjectAdvancedSearchField extends AdvancedSearchField
{
    /**
     * @param string $name
     * @param string $template
     */
    public function __construct($name, $template = 'SubjectAdvancedSearchField')
    {
        parent::__construct($name, $template);
    }

    /**
     * Returns the hash of subject types
     *
     * @return ViewableHash
     */
    public function getSubjectTypes()
    {
        $map = i18nExtension::get_namespace_strings('LV_SUBJECTTYPE', array('' => '---'));

        return new ViewableHash($map);
    }
}
