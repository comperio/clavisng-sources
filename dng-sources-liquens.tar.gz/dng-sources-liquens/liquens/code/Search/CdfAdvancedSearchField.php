<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class CdfAdvancedSearchField extends  AdvancedSearchField
{
    /** @var CdfMap */
    private $cdfMap;

    /**
     * @param $name
     * @param string $template
     */
    public function __construct($name, $template = 'CdfAdvancedSearchField')
    {
        parent::__construct($name, $template);
    }

    /**
     * Set CdfMap
     *
     * @param \CdfMap $cdfMap
     *
     * @return CdfAdvancedSearchField The current instance
     */
    public function setCdfMap(\CdfMap $cdfMap)
    {
        $this->cdfMap = $cdfMap;

        return $this;
    }

    /**
     * Get CdfMap
     *
     * @return \CdfMap
     */
    public function getCdfMap()
    {
        if (!isset($this->cdfMap))
            $this->cdfMap = new CdfMap();

        return $this->cdfMap;
    }

    /**
     * An hash of key/values pairs
     *
     * @return ViewableHash
     */
    public function getCdfValues()
    {
        return new ViewableHash($this->getCdfMap()->getMap());
    }
}
