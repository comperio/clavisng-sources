<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class AdvancedSearchFieldWithSubfields extends AdvancedSearchField
{
    /**
     * @param $name
     * @param string $template
     */
    public function __construct($name, $template = 'AdvancedSearchFieldWithSubfields')
    {
        parent::__construct($name, $template);
    }

    /**
     * The hash of subfieldname/label pairs
     * @return ViewableHash
     */
    public function getSubfieldsMap()
    {
        $map = array('' => '---');

        foreach ($this->getOption('field') as $subfieldKey => $subfield) {
            $localizationKey = 'LQFields.' . strtoupper($this->getOption('field_name')) . '_';
            $localizationKey .= strtoupper($subfieldKey);
            $map[$subfieldKey] = _t($localizationKey, $localizationKey);
            //$map[$solrField] = _t('LQFields.' .strtoupper($subfieldName), $subfieldName);
        }

        return new ViewableHash($map);
    }
}
