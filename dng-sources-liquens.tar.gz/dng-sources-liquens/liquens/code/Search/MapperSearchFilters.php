<?php

/**
 * This file is part of dng
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class MapperSearchFilters extends SearchFilters {

    /**
     * @var SolrQueryMapper
     */
    protected $mapper;
    protected $urlSegment;

    /**
     * @param SolrQueryMapper $mapper
     * @param $urlSegment
     */
    public function __construct(SolrQueryMapper $mapper, $urlSegment) {
        $this->mapper = $mapper;
        $this->urlSegment = $urlSegment;
    }

    /**
     * {@inheritdoc}
     */
    public function getMapperFilters() {
        $queryStack = array();

        foreach ($this->mapper->queryAry as $index => $data) {
            $operator = $this->mapper->operators[$data['op_index']];

            $mapper = clone($this->mapper);
            $mapper->removeFieldByIndex($index);

            $field = $this->mapper->getFieldsCollection()->getField($data['field']);
            $field->setValue($data['value']);

            $fieldLabel = $field->getLabel();
            $displayedValue = $field->getDisplayedValue();
            $label = "$fieldLabel: $displayedValue";

            $item = array(
                "FieldLabel" => $fieldLabel,
                "Value" => $displayedValue,
                "Label" => htmlspecialchars($label, ENT_NOQUOTES),
                "LinkToDelete" => $this->urlSegment . $mapper->getQueryString(),
                "SolrField" => $data['field']
            );
            $queryStack[$operator][] = $item;
        }

        return $queryStack;
    }

}
