<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class TextAdvancedSearchField extends AdvancedSearchField
{
    /**
     * @param string $name
     * @param string $template
     */
    public function __construct($name, $template = 'TextAdvancedSearchField')
    {
        parent::__construct($name, $template);
    }

    /**
     * @return string
     */
    public function getAutocompleteField()
    {
        return $this->getOption('autocomplete_field');
    }
}
