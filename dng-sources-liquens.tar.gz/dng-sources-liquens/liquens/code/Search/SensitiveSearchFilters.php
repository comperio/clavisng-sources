<?php
/**
 * This file is part of dng
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

/**
 * Class SearchSensitiveActiveFilters
 *
 * Remove some filters from the current set of active filters. This is used to not show certain filters
 * in the search page that are exposed as the search page title, like works and subjects
 */
class SensitiveSearchFilters extends SearchFilters
{
    /** @var \SearchFilters  */
    private $filters;

    private $fields = array(
        'id-work',
        'id-name',
        'id-subj',
        'id-auth',
        'edition-key'
    );

    /**
     * @param SearchFilters $filters The underlying filters object
     * @param array $fields
     */
    public function __construct(SearchFilters $filters, array $fields = null)
    {
        if (isset($fields)) {
            $this->fields = $fields;
        }

        $this->filters = $filters;
    }

    /**
     * {@inheritdoc}
     */
    public function getMapperFilters()
    {
        $mapperFilters = $this->filters->getMapperFilters();
        if (!isset($mapperFilters['AND']))
            return $mapperFilters;

        foreach ($mapperFilters['AND'] as $index => $filter) {
            foreach ($this->fields as $field) {
                if ($filter['SolrField'] == $field) {
                    unset($mapperFilters['AND'][$index]);
                    if (count($mapperFilters['AND']) == 0)
                        unset($mapperFilters['AND']);
                    return $mapperFilters;
                }
            }
        }

        return $mapperFilters;
    }
} 