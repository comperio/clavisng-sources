<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class AdvancedSearchFieldController extends Page_Controller
{
    /** @var array */
    private $fieldsConfiguration;

    public static $url_handlers = array(
        '$field!' => 'renderFieldFromRequest',
    );

    public static $allowed_actions = array(
        'renderFieldFromRequest'
    );

    /**
     * Transform the field to html using the render method of the field
     *
     * @param SS_HTTPRequest $request
     * @return mixed
     */
    public function renderFieldFromRequest(SS_HTTPRequest $request)
    {
        $field = $request->param('field');
        $name = $request->getVar('name') ?: "{name}";

        return $this->renderField($field, $name);
    }

    /**
     * @param $fieldName
     * @param $inputName
     * @return mixed
     */
    public function renderField($fieldName, $inputName)
    {
        return call_user_func($this->getRendererMethod($fieldName), $inputName, $this->getFieldConf($fieldName));
    }

    /**
     * Given a field name returns a callable that will render the field
     *
     * @param $field
     * @return Callable
     */
    private function getRendererMethod($field)
    {
        $fieldConf = $this->getFieldConf($field);
        $inputType = $fieldConf['input_type'];

        $methodName = $inputType . 'Field';

        if (method_exists($this, $methodName))
            return array($this, $methodName);

        return array($this, 'textField');
    }

    /**
     * Method for cdf Fields
     *
     * @param string $name
     * @param array $options
     * @return FieldSet
     */
    private function cdfField($name, $options)
    {
        $field = new CdfAdvancedSearchField($name);
        $field->setOptions($options);

        return $field->render();
    }

    /**
     * Method for fields with Subfields Fields
     *
     * @param string $name
     * @param array $options
     * @return FieldSet
     */
    private function subfieldsField($name, $options)
    {
        $field = new AdvancedSearchFieldWithSubfields($name);
        $field->setOptions($options);

        return $field->render();
    }

    /**
     * Method for fields with subvalues Fields
     *
     * @param string $name
     * @param array $options
     * @return FieldSet
     */
    private function rangeField($name, $options)
    {
        $field = new RangeAdvancedSearchField($name);
        $field->setOptions($options);

        return $field->render();
    }

    /**
     * Method for subject fields
     *
     * @param string $name
     * @param array $options
     * @return FieldSet
     */
    private function subjectField($name, $options)
    {
        $field = new SubjectAdvancedSearchField($name);
        $field->setOptions($options);

        return $field->render();
    }

    /**
     * Method for mapped fields
     *
     * @param string $name
     * @param array $options
     * @return FieldSet
     */
    private function mapField($name, $options)
    {
        $field = new MapAdvancedSearchField($name);
        $field->setOptions($options);

        return $field->render();
    }

    /**
     * Method for subject fields
     *
     * @param string $name
     * @param array $options
     * @return FieldSet
     */
    private function bibtypeField($name, $options)
    {
        $field = new BibtypeAdvancedSearchField($name);
        $field->setOptions($options);

        return $field->render();
    }

    /**
     * This will render the text fields
     *
     * @param $name
     * @param array $options
     * @return string
     */
    private function textField($name, $options)
    {
        $field = new TextAdvancedSearchField($name);
        $field->setOptions($options);

        return $field->render();
    }

    /**
     * Return a configuration for a specific field
     *
     * @param $field
     * @return mixed
     * @throws InvalidArgumentException
     */
    private function getFieldConf($field)
    {
        $conf = $this->getFieldsConfiguration();

        if (!isset($conf[$field]))
            throw new InvalidArgumentException("Field $field not found in fields configuration");

        $fieldConf = $conf[$field];

        if (!isset($fieldConf['input_type'])){
            $fieldConf['input_type'] = 'text';
        }
        $fieldConf['field_name'] = $field;

        //The corresponding instance of SolrSearchField
        $fieldConf['field_object'] =
            $this->getContainer()->get('solr.fields_collection')->getField($field);

        return $fieldConf;
    }

    /**
     * Returns the fields configuration array
     *
     * @return array|mixed
     */
    private function getFieldsConfiguration()
    {
        if (!isset($this->fieldsConfiguration)) {
            $this->fieldsConfiguration = $this->getContainer()->getParameter('lq.fields');
        }

        return $this->fieldsConfiguration;
    }
}
