<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class MapAdvancedSearchField extends AdvancedSearchField
{
    /**
     * @param string $name
     * @param string $template
     */
    public function __construct($name, $template = 'MapAdvancedSearchField')
    {
        parent::__construct($name, $template);
    }

    /**
     * @return ViewableHash
     */
    public function getMap()
    {
        /** @var $solrField TemplateSolrSearchField */
        $solrField = $this->getOption('field_object');
        $transformation = $solrField->getDisplayValueTransformation();
        if ($transformation instanceof DefinedTransformation) {
            $map = array('' => '---') + $transformation->getCompleteMap();
        }

        return new ViewableHash($map);
    }
}
