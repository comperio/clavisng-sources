<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class AdvancedSearchField implements AdvancedSearchFieldInterface
{
    private $name;
    private $template;
    private $options = array();

    /** @var SolrSearchField */
    private $solrSearchField;

    /** @var CdfMap */
    private $cdfMap;

    /**
     * @param $name
     * @param string $template
     */
    public function __construct($name, $template)
    {
        $this->setName($name);
        $this->template = $template;
    }

    /**
     * @param $name
     * @return mixed
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set SolrSearchField
     *
     * @param \SolrSearchField $solrSearchField
     *
     * @return AdvancedSearchField The current instance
     */
    public function setSolrSearchField(\SolrSearchField $solrSearchField)
    {
        $this->solrSearchField = $solrSearchField;
        return $this;
    }

    /**
     * Get SolrSearchField
     *
     * @return \SolrSearchField
     */
    public function getSolrSearchField()
    {
        return $this->solrSearchField;
    }



    /**
     * Render the field with a template
     *
     * @return FieldSet
     */
    public function render()
    {
        $viewableField = new ViewableObject($this);

        return $viewableField->renderWith($this->template);
    }

    /**
     * @param $subfield
     * @return string
     */
    public function getInputName($subfield)
    {
        return $this->name . '[' . $subfield . ']';
    }

    /**
     * @param array $options
     * @return AdvancedSearchFieldInterface the current instance
     */
    public function setOptions(array $options)
    {
        $this->options = $options;

        return $this;
    }

    /**
     * @return array
     */
    public function getOptions()
    {
        return $this->options;
    }

    /**
     * Get a single option
     *
     * @param $option
     * @return null
     */
    public function getOption($option)
    {
        if (isset($this->options[$option]))
            return $this->options[$option];

        return null;
    }
}
