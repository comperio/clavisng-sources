<?php
/**
 * This file is part of dng
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

abstract class SearchFilters
{
    /**
     * Returns a viewable form of the filters
     *
     * @return DataObjectSet
     */
    public function getFilters()
    {
        $actFilters = new DataObjectSet();
        foreach ($this->getMapperFilters() as $op => $data) {
            $actFilters->push(
                new DataObject(array(
                    'Operator' => $op,
                    'Filters' => new DataObjectSet($data),
                ))
            );
        }

        return $actFilters;
    }

    /**
     * Returns an array of filters of the form
     * [
     *  'OP1' => [
     *     [
     *          "FieldLabel" => $fieldLabel,
     *           "Value" => $displayedValue,
     *           "Label" => htmlspecialchars($label, ENT_NOQUOTES),
     *           "LinkToDelete" => $urlSegment . $mapper->getQueryString(),
     *           "SolrField" => $data['field']
     *     ],
     *     ....
     *  ],
     *  ....
     * ]
     * @return array
     */
    abstract public function getMapperFilters();
} 