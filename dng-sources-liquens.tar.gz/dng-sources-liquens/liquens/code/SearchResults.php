<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

class SearchResults extends ViewableData
{
    /** @var SolrResponse */
    private $solrResponse;

    /** @var array A map manifestationId => data*/
    private $extraDataMap = array();

    /** @var ManifestationRenderingProvider */
    private $renderingProvider;

    /** @var DataObjectSet */
    private $manifestations;


    /**
     * @param \SolrResponse $response
     */
    public function __construct(SolrResponse $response)
    {
        $this->solrResponse = $response;
    }

    /**
     * Return a DataObjectSet of manifestations
     *
     * @param ManifestationDriver|null $driver
     * @return DataObjectSet
     */
    public function getManifestations(ManifestationDriver $driver = null, $providerOptions = array())
    {
        if (!$this->manifestations || $this->manifestations->Count() == 0){
            $this->manifestations = new DataObjectSet();

            foreach ($this->solrResponse->getDocs() as $key => $result) {
                $manifestation = new Manifestation();
                $driver->fillManifestation($manifestation, array(
                    'solr_doc' => $result
                ));
                if ($this->renderingProvider)
                    $manifestation->setRendering($this->renderingProvider->getRendering($manifestation, $providerOptions));

                $this->manifestations->push($manifestation);
            }
        }

        return $this->manifestations;
    }



    /**
     * Returns the array of numerical ids of the manifestations
     * stored in $solrResponse
     *
     * @param bool $numerical If true returns only tha last part
     *   of the one and trine id.
     * @return array
     */
    public function getManifestationsIds($numerical = true)
    {
        $ids = array();
        foreach ($this->solrResponse->getDocs() as $result) {
            if ($numerical) {
                $pieces = explode(':', $result['id']);
                $ids[] = $pieces[count($pieces) - 1];
            }
            else {
                $ids[] = $result['id'];
            }
        }

        return $ids;
    }

    /**
     * @param array $extraDataMap
     * @return SearchResults
     */
    public function setExtraDataMap($extraDataMap)
    {
        $this->extraDataMap = $extraDataMap;

        return $this;
    }

    /**
     * @param $key
     * @return array
     */
    public function getExtraData($key)
    {
        return isset($this->extraDataMap[$key]) ? $this->extraDataMap[$key] : array();
    }

    /**
     * Set the ManifestationRendering provider used to inject the rendering into the manifestations
     *
     * @param \ManifestationRenderingProvider $provider
     * @return SearchResults
     */
    public function setRenderingProvider(ManifestationRenderingProvider $provider)
    {
        $this->renderingProvider = $provider;

        return $this;
    }

    /**
     * Returns the number of results
     * @return int
     */
    public function getCount()
    {
        return $this->solrResponse->getNumFound();
    }
}
