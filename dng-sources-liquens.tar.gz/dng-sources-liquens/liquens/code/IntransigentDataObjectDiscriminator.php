<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

/**
 * A discriminator that does not match anything
 */
class IntransigentDataObjectDiscriminator extends DataObjectDiscriminator
{
    /**
     * @param \DataObject $object
     * @return int
     */
    public function discriminate(DataObject $object)
    {
        return 0;
    }

}
