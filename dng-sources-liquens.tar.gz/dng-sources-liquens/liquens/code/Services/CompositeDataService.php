<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class CompositeDataService implements DataService
{
    /**
     * @var array An array of array(Dataservice, $priority)
     */
    private $services;

    /**
     * @param string $name
     * @param array $options
     * @return mixed
     */
    public function getProp($name, $options = array())
    {
        return $this->resolveService($name)->getProp($name, $options);
    }

    /**
     * @param string $name
     * @param mixed $value
     * @param array $options
     * @return mixed
     */
    public function setProp($name, $value, $options = array())
    {
        $this->resolveService($name)->setProp($name, $value, $options);

        return $this;
    }

    /**
     * @param string $name
     * @return boolean
     */
    public function hasProp($name)
    {
        try {
            return $this->resolveService($name)->hasProp($name);
        } catch (Exception $e) {
            return false;
        }
    }

    /**
     * @return mixed
     */
    public function flush()
    {
        foreach ($this->services as $serviceAry) {
            $service = $serviceAry[0];

            $service->flush();
        }

        return $this;
    }


    /**
     * @param DataService $service
     * @param int $priority
     * @return CompositeDataService
     */
    public function addService(DataService $service, $priority = 1)
    {
        $this->services[] = array($service, $priority);

        $this->orderServices();

        return $this;
    }

    /**
     * @param $propName
     *
     * @return DataService
     *
     * @throws InvalidArgumentException
     */
    public function resolveService($propName)
    {
        foreach ($this->services as $serviceAry) {
            $service = $serviceAry[0];

            if ($service->hasProp($propName))
                return $service;
        }

        throw new InvalidArgumentException("Cannot find a service with the property '$propName'");
    }

    /**
     * Order services putting by priority DESC
     *
     * @return CompositeDataService
     */
    private function orderServices()
    {
        usort($this->services, function($item1, $item2){
            return $item2[1] - $item1[1];
        });

        return $this;
    }
}

