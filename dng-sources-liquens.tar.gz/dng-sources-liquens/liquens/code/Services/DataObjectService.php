<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class DataObjectService implements DataService
{
    /**
     * @var DataObject
     */
    private $dataObject;

    /**
     * @var array A map of properties
     */
    private $propMap = array(

    );

    /**
     * @param DataObject $object
     */
    public function __construct(DataObject $object)
    {
        $this->dataObject = $object;
    }


    /**
     * @param string $name
     * @param array $options
     * @return mixed
     */
    public function getProp($name, $options = array())
    {
        $mappedName = $this->mapPropName($name);

        if ($this->hasRelation($mappedName)) {
            return $this->dataObject->$mappedName();
        }

        return $this->dataObject->$mappedName;
    }

    /**
     * @param string $name
     * @param mixed $value
     * @param array $options
     *
     * @return mixed
     */
    public function setProp($name, $value, $options = array())
    {
        $mappedName = $this->mapPropName($name);

        $this->dataObject->$mappedName = $value;

        return $this;
    }

    /**
     * @param $name
     * @return mixed
     */
    public function hasProp($name)
    {
        $propName = $this->mapPropName($name);

        return $this->dataObject->hasField($propName) || $this->hasRelation($propName);
    }

    /**
     * @return mixed
     */
    public function flush()
    {
        $this->dataObject->write();
    }

    /**
     * Set PropMap
     *
     * @param array $propMap
     *
     * @return DataObjectService The current instance
     */
    public function setPropMap($propMap)
    {
        $this->propMap = $propMap;

        return $this;
    }

    /**
     * Get PropMap
     *
     * @return array
     */
    public function getPropMap()
    {
        return $this->propMap;
    }

    /**
     * @param $name
     * @return mixed
     */
    private function mapPropName($name)
    {
        if (isset($this->propMap[$name]))
            return $this->propMap[$name];

        return $name;
    }

    private function hasRelation($propName)
    {
        $hasOneRelations = SSObject::uninherited_static(get_class($this->dataObject), 'has_one');
        $manyManyRelations = SSObject::uninherited_static(get_class($this->dataObject), 'many_many');

        return array_key_exists($propName, $hasOneRelations) || array_key_exists($propName, $manyManyRelations);
    }
}
