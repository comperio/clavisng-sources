<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
interface DataService
{
    /**
     * @abstract
     * @param string $name
     * @param array $options
     * @return mixed
     */
    public function getProp($name, $options = array());

    /**
     * @abstract
     * @param string $name
     * @param $value
     * @param array $options
     * @return mixed
     */
    public function setProp($name, $value, $options = array());

    /**
     * @abstract
     * @param $name
     * @return mixed
     */
    public function hasProp($name);

    /**
     * @abstract
     * @return mixed
     */
    public function flush();
}
