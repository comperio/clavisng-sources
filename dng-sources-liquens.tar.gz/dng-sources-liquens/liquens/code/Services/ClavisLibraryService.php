<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class ClavisLibraryService implements LibraryService
{
    /**
     * @var LiquensConnector
     */
    private $connector;

    /**
     * @var mixed
     */
    private $externalId;

    /**
     * @var array
     */
    private $changedProps;

    /**
     * @var array A map of properties
     */
    private $propMap = array(
        'address' => 'Address',
        'phone' => 'Phone',
        'fax' => 'Fax',
        'website' => 'Website',
        'city' => 'City',
        'email' => 'Email',
        'country' => 'Country',
        'province' => 'Province',
        'timetable' => 'Timetable',
    );

    /**
     * @var array
     */
    private static $library_data_cache = array();

    /**
     * @var array
     */
    private static $library_timetable_cache = array();

    /**
     * @param LiquensConnector $connector
     */
    public function __construct(LiquensConnector $connector)
    {
        $this->connector = $connector;
    }

    /**
     * @param string $name
     * @param array $options
     *
     * @throws InvalidArgumentException
     *
     * @return mixed
     */
    public function getProp($name, $options = array())
    {
        if (!$this->hasProp($name)) {
            throw new InvalidArgumentException("The property '$name' is not defined for this DataService'");
        }

        if (method_exists($this, $methodName = 'get' . ucfirst($name))) {
            return call_user_func_array(array($this, $methodName), $options);
        }

        $mappedName = $this->mapPropName($name);
        if (! isset(static::$library_data_cache[$this->getExternalId()]))
            $this->fetchLibraryData();

        $response = static::$library_data_cache[$this->getExternalId()];

        if (isset($response[$mappedName])) {
            return $response[$mappedName];
        }

        throw new InvalidArgumentException('Cannot retrieve property ' . $name);
    }

    /**
     * @param $name
     * @return bool|mixed
     */
    public function hasProp($name)
    {
        return in_array($name, array_keys($this->propMap));
    }

    /**
     * @param string $name
     * @param mixed $value
     * @param array $options
     *
     * @return ClavisLibraryService the current instance
     */
    public function setProp($name, $value, $options = array())
    {
        if (!$this->hasProp($name)) {
            throw new InvalidArgumentException("The property '$name' is not defined for this DataService'");
        }

        $this->changedProps[$name]  = $value;

        return $this;
    }

    /**
     * @return ClavisLibraryService the current instance
     */
    public function flush()
    {
        return $this;
    }

    /**
     * Set ExternalId
     *
     * @param mixed $externalId
     *
     * @return ClavisLibraryService The current instance
     */
    public function setExternalId($externalId)
    {
        $this->externalId = $externalId;

        return $this;
    }

    public function getTimetable($from, $to)
    {
        if(is_null($from))
            $from = time();

        if(is_null($to))
            $to = strtotime("+5 day");

        $cacheKey = $this->timeTableCacheKey($from, $to);

        if (! isset(static::$library_timetable_cache[$cacheKey]))
            $this->fetchTimetableData($from, $to);

        return static::$library_timetable_cache[$cacheKey];
    }

    /**
     * Get ExternalId
     *
     * @return mixed
     */
    public function getExternalId()
    {
        return $this->externalId;
    }

    /**
     * Fetch the response from the connector and put in the cache
     *
     * @return ClavisLibraryService The current instance
     */
    private function fetchLibraryData()
    {
        $response = $this->connector->getLibraryData($this->getExternalId());

        static::$library_data_cache[$this->getExternalId()] = $response;
    }

    /**
     * Fetch the response from the connector and put in the cache
     * @param $from
     * @param $to
     *
     * @return ClavisLibraryService The current instance
     */
    private function fetchTimetableData($from = null, $to = null)
    {
        $response = $this->connector->getLibraryTimetable($this->getExternalId(), $from, $to);

        static::$library_timetable_cache[$this->timeTableCacheKey($from, $to)] = $response;
    }

    /**
     * The key used to store cached timetables
     *
     * @param $from
     * @param $to
     * @return string
     */
    private function timeTableCacheKey($from, $to)
    {
        return $this->getExternalId() . serialize(array($from, $to));
    }

    /**
     * Map the propname accordingly to propMap array
     *
     * @param $name
     * @return mixed
     */
    private function mapPropName($name)
    {
        if (isset($this->propMap[$name]))
            return $this->propMap[$name];

        return $name;
    }

}
