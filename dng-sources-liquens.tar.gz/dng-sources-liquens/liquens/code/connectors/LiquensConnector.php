<?php

/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 */
abstract class LiquensConnector {

    /**
     * @param $username
     * @param $password
     * @return mixed
     */
    abstract public function loginUser($username, $password);

    /**
     * @param string $username
     * @return array
     */
    abstract public function logoutUser(string $username): array;

    /**
     * @param array $manids
     * @return mixed
     */
    abstract public function getManifestationListInfo(array $manids);

    /**
     * @abstract
     * @param $shelfId The Shelf id in the external service
     * @return
     */
    abstract public function getShelfManifestations($shelfId);

    /**
     * Helper function to retrieve the shelf name from a shelf id and a libraryId
     *
     * @param $shelfId
     * @param $libraryId
     */
    abstract public function getShelfInfo($shelfId, $libraryId);

    /**
     * @param null $username
     * @return array|bool|null
     */
    abstract public function getUserData($username = null, $searchfield = 'username', $bypass = false);

    /**
     * Perform preregistration
     *
     * @return mixed
     */
    abstract public function registerNewUser();

    /**
     * @param $jsonDataSet
     * @return mixed
     */
    abstract public function registerNewCustomUser($jsonDataSet);

    /**
     * @param $username
     * @param $privacy_approve
     * @param $data_trx
     * @param $newsletter
     * @param $p3
     * @param $p4
     * @param $p5
     * @return mixed
     */
    abstract public function setPrivacy($username, $privacy_approve = null, $data_trx = '', $newsletter = '', $p3 = '', $p4 = '', $p5 = '');
    
    /**
     * Set User Preferences
     *
     * @param $username
     * @param $preferred_library_id
     * @param $statistic_study
     * @param $statistic_work
     * @param $areas_of_interest
     * @return mixed
     */
    abstract public function setUserPrefs($username, $preferred_library_id, $statistic_study, $statistic_work, $areas_of_interest);

    /**
     * Change the user's password
     *
     * @param string $username
     * @param string $oldpassword
     * @param string $newpassword
     * @return array
     */
    abstract public function setNewPassword($username, $oldpassword, $newpassword, $passwordexpire = null);

    /**
     * Reset the user's password
     *
     * @param string $username
     * @param string $newpassword
     * @return array
     */
    abstract public function resetPassword($username, $newpassword, $passwordexpire = null);

    /**
     * Change the user's password
     *
     * @param string $oldusername
     * @param string $newusername
     * @return array
     */
    abstract public function setNewUsername($oldusername, $newusername);

    /**
     * Verifica la presenza di un utente con quel contatto
     * 
     * @param string $search
     * @param string $searchfield
     * @return bool
     */
    abstract public function getUserContacts($search, $searchfield);

    /**
     * Edit user's contact info
     *
     * @param $username
     * @param $contact_id
     * @param $contact_type
     * @param $contact_value
     * @param $contact_pref
     * @return array
     */
    abstract public function editContact($username, $contact_id, $contact_type, $contact_value, $contact_pref);

    /**
     * Delete a contact by id
     *
     * @param $contact_id
     * @return mixed
     * @throws SoapFault
     */
    abstract public function deleteContact($contact_id);

    /**
     * Delete an address by id
     *
     * @param $address_id
     * @return mixed
     * @throws SoapFault
     */
    abstract public function deleteAddress($address_id);

    /**
     * Edit user's address infos
     *
     * @param $username
     * @param $address_id
     * @param $address_type
     * @param $address_pref
     * @param $street_type
     * @param $street
     * @param $street_num
     * @param $village
     * @param $city
     * @param $zip
     * @param $province
     * @param $country
     * @return array
     */
    abstract public function editAddress($username, $address_id, $address_type, $address_pref, $street_type, $street, $street_num, $village, $city, $zip, $province, $country);

    /**
     * Get user's purchase proposal list
     *
     * @abstract
     * @param $username
     * @param string $class
     * @param int $start
     * @param int $limit
     * @return array
     */
    abstract public function getPurchaseProposalList($username, $class = '', $start = null, $limit = null);

    /**
     * Edit an existing purchase proposal
     *
     * @abstract
     * @param string $username
     * @param int $proposal_id
     * @param string $title
     * @param string $author
     * @param string $publisher
     * @param string $year
     * @param string $ean
     * @param string $notes
     * @return array
     */
    abstract public function editPurchaseProposal($username, $proposal_id, $title, $author, $publisher, $year, $ean, $notes);

    /**
     * @param $proposal_id
     * @return mixed
     */
    abstract public function retirePurchaseProposal($proposal_id);

    /**
     * @abstract
     * @param int $n
     */
    abstract public function getLastRegisteredUsers($n = 10);

    /**
     *
     * @param int $library_id
     * @return array
     */
    abstract public function getLibraryStaff($library_id);

    /**
     * Retrieve consortia active Libraries
     * @return array (of library_code)
     */
    abstract public function getConsortiaActiveLibraries();

    /**
     * Retrieve consortia internal Libraries
     * @return array (of library_code)
     */
    abstract public function getConsortiaInternalLibraries();

    /**
     * Returns all libraries, including external ones
     *
     * @return mixed
     */
    abstract public function getAllLibraries();

    /**
     * Get a list of libraries for Librarian
     *
     * @param int $librarian_id
     * @return array
     */
    abstract public function getLibrariesForLibrarian($librarian_id = null);

    /**
     * Get the open time table from clavis libraries
     *
     * @param int $clavis_library_id
     * @param int $from (timestamp)
     * @param int $to (timestamp)
     * @return array
     */
    abstract public function getLibraryTimeTable($clavis_library_id = null, $from = null, $to = null);

    /**
     * Get the Anagraphic data of a library
     *
     * @param string $clavis_library_id
     * @return array
     */
    abstract public function getLibraryData($clavis_library_id);

    /**
     * Perform a reservation request
     *
     * @param $manId
     * @param $patronUsername
     * @param $libraryId
     * @param null $issueId
     * @param null $reserveNote
     * @return array
     */
    abstract public function doReserve($manId, $patronUsername, $libraryId, $issueId = null, $reserveNote = null);

    /**
     * Renew the loan of an item
     *
     * @param $itemId
     * @return mixed
     */
    abstract public function renewItemLoan($itemId);

    /**
     * Get patron's active loan
     * @param string $username The patron's username
     *
     * @return array
     */
    abstract public function getPatronActiveLoans($username);

    /**
     * Get patron's pending loan
     * @param string $username The patron's username
     *
     * @return array
     */
    abstract public function getPatronPendingLoans($username);

    /**
     * Get patron's pending loan
     * @param string $username The patron's username
     * @param int $start Optional Offset
     * @param int $limit Optional Limite dei record
     * @param string $search Optional testo della ricerca
     * @param int $orderByTitle Optional Ordinamento per titolo
     * @param int $orderByBeginDate Optional Ordinamento per data inizio
     * @param int $orderByEndDate Optional Ordinamento per data fine
     * @return array
     * @throws SoapFault
     */
    abstract public function getPatronClosedLoans($username, $start = null, $limit = null, $search = null, $orderBy = null, $orderDirection = null);

    /**
     * Get patron's active requests
     * @param string $username The patron's username
     *
     * @return array
     */
    abstract public function getPatronActiveRequests($username);

    /**
     * Cancel a reservation using its id
     * @param int $reservationId
     *
     * @return string
     */
    abstract public function cancelReservation($reservationId);

    /**
     * Change the delivery library of a request
     *
     * @param $requestId
     * @param $deliveryLibrary
     * @return mixed
     */
    abstract public function changeReservationDeliveryLibrary($requestId, $deliveryLibrary);
}
