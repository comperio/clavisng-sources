<?php

/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

/**
 * Timeout and tracking support for the soap client
 * See http://www.binarytides.com/blog/php-script-set_time_limit-wont-take-into-account-socket-operations/
 */
class LiquensSoapClient extends SoapClient {

    private $timeout;

    public function __setTimeout($timeout) {
        if (!is_int($timeout) && !is_null($timeout)) {
            throw new Exception("LiquensSoapClient: Invalid timeout value. Must be an integer");
        }

        global $sc;
        $this->timeout = $sc->getParameter('lq.connector.timeout');
    }

    public function __doRequest($request, $location, $action, $version, $one_way = FALSE) {
        if (!$this->timeout) {
            // Call via parent because we require no timeout
            $response = parent::__doRequest($request, $location, $action, $version, $one_way);
        } else {
            // Call via Curl and use the timeout
            $curl = curl_init($location);

            if (LQConfig::get('debug_soap_calls')) {
                list ($usec, $sec) = explode(' ', microtime());
                $startTime = ((float) $usec + (float) $sec);
            }

            curl_setopt($curl, CURLOPT_VERBOSE, FALSE);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, TRUE);
            curl_setopt($curl, CURLOPT_POST, TRUE);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $request);
            curl_setopt($curl, CURLOPT_HEADER, FALSE);
            curl_setopt($curl, CURLOPT_HTTPHEADER, array("Content-Type: text/xml"));
            global $sc;
            if ($sc->getParameter('lq.connector.timeout') != 5)
                $this->timeout = $sc->getParameter('lq.connector.timeout');
            curl_setopt($curl, CURLOPT_TIMEOUT, $this->timeout);

            $response = curl_exec($curl);

            if (LQConfig::get('debug_soap_calls')) {
                list ($usec, $sec) = explode(' ', microtime());
                $executionTime = ((float) $usec + (float) $sec) - $startTime;

                Debug::log(
                        "Soap Call Traced ($executionTime s):\r\n" .
                        "Location: $location\r\n" .
                        "Action: $action\r\n"
                );
            }

            if (curl_errno($curl)) {
                $backtrace = SS_Backtrace::backtrace(true);
                Debug::log('SOAP CALL CURL ERROR: ' . curl_error($curl));
                Debug::log(
                        'LiquensSoapClient::__doRequest arguments: ' . print_r(func_get_args(), true) . "\r\n" .
                        SS_Backtrace::get_rendered_backtrace(debug_backtrace(), true)
                );
                throw new Exception(curl_error($curl));
            }

            curl_close($curl);
        }

        // Return?
        if (!$one_way) {
            return $response;
        }
    }

}
