<?php

/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 */
class CLAVISConnector extends LiquensConnector
{

    public static $reservation_responses = array(
        1 => 'OK',
        -1 => 'RSV_NOTAVAIL',
        -2 => 'RSV_PATRONHASITEM',
        -3 => 'RSV_PATRONREQITEM',
        -4 => 'RSV_PATRONMAXREQ',
        -5 => 'RSV_PATRONREQMANIF',
        -6 => 'RSV_ALREADYMANAGED',
        -6.1 => 'RSV_UNMANAGENOTSAMEOPERATOR',
        -6.3 => 'RSV_UNMANAGENOTSAMEOPERATOR',
        -6.5 => 'RSV_NOTMANAGED',
        -7 => 'RSV_RATING',
    );
    private $soapClients;
    private $solrDatabase;
    private $solrCatalog;
    private $cache = array();
    private $consortiaName;
    private $consortiaSecret;
    private $timeout = 5;
    public $webserviceUrl;

    public function __construct($webserviceUrl, $consortiaName = null, $consortiaSecret = null, $timeout = 5)
    {
        $this->webserviceUrl = $webserviceUrl;
        $this->consortiaName = $consortiaName;
        $this->consortiaSecret = $consortiaSecret;
        global $sc;
        if ($sc->getParameter('lq.connector.timeout') != 5)
            $timeout = $sc->getParameter('lq.connector.timeout');
        $this->timeout = $timeout;
    }

    /**
     * Returns the corresponding SoapClient
     * @param string $name
     * @return SoapClient
     */
    public function getSoapClient($name, $isFullWsdlUrl = false)
    {
        $wsdl = $isFullWsdlUrl ? $name : $this->webserviceUrl . $name . '.wsdl';

        global $sc;
        if ($sc->getParameter('lq.connector.timeout') != 5)
            $this->timeout = $sc->getParameter('lq.connector.timeout');

        if (!isset($this->soapClients[$wsdl])) {
            try {
                $client = new LiquensSoapClient(
                    $wsdl, array(
                        'trace' => 1,
                        'exceptions' => 0,
                        'connection_timeout' => $this->timeout,
                        'compression' => SOAP_COMPRESSION_ACCEPT | SOAP_COMPRESSION_GZIP
                    )
                );
                $client->__setTimeout($this->timeout);
                $this->setAuthenticationHeaders($client);
                $this->soapClients[$wsdl] = $client;
            } catch (Exception $e) {
                Debug::log($e->getMessage());
                die($e->getMessage());
                $res = null;
            }
        }

        return $this->soapClients[$wsdl];
    }

    /*     * * END SOAP DIALOG ** */


    /*     * * AUTH ** */

    /**
     * @param $username
     * @param $password
     * @return mixed
     */
    public function loginUser($username, $password)
    {
        $result = $this->getSoapClient('user')->loginUser($username, $password);
        //To prevent things like a SoapFault evaluated as true, and so Authenticating
        //ANYONE When the webservice is Down!
        if (!is_object($result))
            return (bool)$result;

        return false;
    }

    /**
     * @param string $username
     * @return array
     */
    public function logoutUser(string $username): array
    {
        if ($username) {
            $sid = session_id();
            $return = $this->getSoapClient('user')->logoutUser($username . ":" . $sid);

            if (is_array($return) && array_key_exists('action', $return) && array_key_exists('parameters', $return)) {
                return $return;
            }
        }
        return array();
    }

    public static function postRedirect($url, $parameters = array())
    {
        $hidden = array();
        foreach ($parameters as $name => $value) {
            $value = htmlspecialchars($value);
            $hidden[] = "<input type=\"hidden\" name=\"{$name}\" value=\"{$value}\"/>";
        }
        $hidden = implode("\n", $hidden);

        $form = <<<EOT
<?xml version="1.0" encoding="UTF-8"?>
        <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN"
          "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
        <html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
         <body onload="document.forms[0].submit()">
          <noscript>
           <p><strong>Note:</strong> Since your browser does not support JavaScript,
           you must press the Continue button once to proceed.</p>
          </noscript>
          <form action="{$url}" method="post">
            <div>{$hidden}</div>
            <noscript>
             <div><input type="submit" value="Continue"/></div>
            </noscript>
          </form>
         </body>
        </html>
EOT;
        echo $form;
        exit();
    }

    public static function redirect($url, $parameters)
    {
        /* Add encoded parameters */
        if (strpos($url, '?') === false) {
            $paramPrefix = '?';
        } else {
            $paramPrefix = '&';
        }

        foreach ($parameters as $name => $value) {
            if ($value === null) {
                $param = urlencode($name);
            } else if (is_array($value)) {
                $param = "";
                foreach ($value as $val) {
                    $param .= urlencode($name) . "[]=" . urlencode($val) . '&';
                }
                if (!empty($param)) {
                    $param = substr($param, 0, -1);
                }
            } else {
                $param = urlencode($name) . '=' . urlencode($value);
            }

            if (!empty($param)) {
                $url .= $paramPrefix . $param;
                $paramPrefix = '&';
            }
        }



        header('Pragma: no-cache');
        header('Cache-Control: no-cache, must-revalidate');
        header('Location: ' . $url);
        exit();
    }

    /**
     * @param array $manids
     * @return mixed
     */
    public function getManifestationListInfo(array $manids)
    {
        try {
            $result = $this->getSoapClient('catalog')->getManifestationListInfo($manids);
        } catch (Exception $e) {
            Debug::log('GetManifestationListInfoException: ' . $e->getMessage());
            return array();
        }
        return $result;
    }

    /**
     * Returns a list of shelves of the library with the given libraryId
     * @param $libraryId
     * @return array|bool
     */
    public function getShelvesForLibrary($libraryId)
    {
        if (is_null($libraryId))
            return false;
        try {
            $result = $this->getSoapClient('catalog')->getShelvesForLibrary($libraryId);
        } catch (Exception $e) {
            Debug::log('getShelvesForLibraryException: ' . $e->getMessage());
            return array();
        }
        return $result;
    }

    /**
     * Helper function to retrieve the shelf name from a shelf id and a libraryId
     *
     * @param $shelfId
     * @param $libraryId
     */
    public function getShelfInfo($shelfId, $libraryId)
    {
        $shelvesData = $this->getShelvesForLibrary($libraryId);

        foreach ($shelvesData as $shelfData) {
            if ($shelfId == $shelfData['ShelfId']) {
                return $shelfData;
            }
        }
    }

    /**
     * Returns a list of manifestation ids, in the trine form
     *
     * @param $shelfId The Shelf id in the external service
     * @return array
     */
    public function getShelfManifestations($shelfId)
    {
        try {
            $ids = $this->getSoapClient('catalog')->getRecordsInShelf($shelfId);
        } catch (Exception $e) {
            Debug::log('getRecordsInShelf: ' . $e->getMessage());
            $ids = array();
        }

        $trineIds = array();

        //Solr catalog and database
        foreach ($ids as $id) {
            $trineIds[] = $this->getSolrDatabase() . ':' . $this->getSolrCatalog() . ':' . $id;
        }

        return $trineIds;
    }

    /**
     *
     * @param type $search
     * @param type $searchfield
     * @return bool
     */
    public function getUserContacts($search, $searchfield)
    {
        Debug::log('Verifica ' . $searchfield . ':' . $search);
        return $this->getSoapClient('user')->getUserContacts($search, $searchfield);
    }

    /**
     * @param null $username
     * @return array|bool|null
     */
    public function getUserData($contentfield = null, $searchfield = 'username', $bypass = false)
    {
        if (isset($this->cache['userdata'][$contentfield]))
            return $this->cache['userdata'][$contentfield];
        if (!$contentfield)
            return null;

        if ($searchfield == 'omocodia') {
            Debug::log('Valore omocodia: Chiamata a Clavis registrazione custom: ' . $contentfield . " - " . $searchfield);
            $userdata = $this->getSoapClient('user')->getUserData($contentfield, $searchfield);
            Debug::log('Valore omocodia: Risposta da Clavis registrazione custom: ' . print_r($userdata, true));
            if ($userdata[0] == 1) {
                return true;
            } else {
                return false;
            }
        }

        $userdata = $this->getSoapClient('user')->getUserData($contentfield, $searchfield);
        if (is_array($userdata) && count($userdata)) {
            if (in_array($userdata['group'], array('webmaster', 'sitemaster'))) {
                $userdata['ClavisUserID'] = '';
                $userdata['ClavisUserType'] = '';
                // manage librarian data
                if (!isset($userdata['librarian']['Email'])) {
                    ExternalAuthenticator::AuthLog(_t('ExternalAuthenticator.FAILED', "Email cant' be blank!"));
                    ExternalAuthenticator::setAuthMessage(_t('ExternalAuthenticator.LOGINFAILED', 'Login failed: librarian do not have an valid email'));
                    return false;
                }
                // remap fields for Silverstripe
                $userdata['email'] = $userdata['librarian']['Email'];
                $userdata['username'] = $userdata['librarian']['Username'];
                $userdata['firstname'] = $userdata['librarian']['Name'];
                $userdata['surname'] = $userdata['librarian']['Lastname'];

                $userdata['ClavisUserID'] = $userdata['librarian']['LibrarianId'];
                $userdata['ClavisUserType'] = 'librarian';
            }

            if (array_key_exists('patron', $userdata)) {

                // Verifica se la password è scaduta cioè se la data di modifica è già passata
                if (($bypass == false) && (!is_null($userdata['patron']['OpacSecretExpire'])) && (strtotime($userdata['patron']['OpacSecretExpire']) < strtotime(date("Y-m-d")))) {
                    $_SESSION['RENEW'] = $userdata['patron']['OpacUsername'] . "|" . $userdata['patron']['OpacSecretExpire'];
                    ob_start();
                    header('Location: ' . Director::absoluteBaseURL() . 'forgot/renew');
                    ob_end_flush();
                    die();
                }

                // manage patron data
                foreach ($userdata['contacts'] as $contact)
                    if ($contact['ContactType'] == 'E') {
                        $userdata['email'] = $contact['ContactValue'];
                        break;
                    }
                if (!isset($userdata['firstname']))
                    $userdata['firstname'] = $userdata['patron']['Name'];
                if (!isset($userdata['surname']))
                    $userdata['surname'] = $userdata['patron']['Lastname'];
                if (!isset($userdata['username']))
                    $userdata['username'] = $userdata['patron']['OpacUsername'];
                if (!isset($userdata['PreferredLibraryId']))
                    $userdata['PreferredLibraryId'] = $userdata['patron']['PreferredLibraryId'];
                if (!isset($userdata['ClavisUserID']))
                    $userdata['ClavisUserID'] = $userdata['patron']['PatronId'];
                if (!isset($userdata['ClavisUserType']))
                    $userdata['ClavisUserType'] = 'patron';
            }
        } else {
            return false;
        }
        // cache user data for later use
        $this->cache['userdata'] = $userdata;

        return $userdata;
    }

    /**
     *
     * @return mixed
     */
    public function registerNewCustomUser($jsonDataSet)
    {
//        //Arguments fetched with func_get_args
//        Debug::log('registerNewCustomUser Arguments:' . PHP_EOL . print_r(func_get_args(), true));
//        $response = $this->getSoapClient('user')->__soapCall('registerNewCustomUser', func_get_args());
//        if ($response instanceof SoapFault) {
//            Debug::log($response->getCode());
//            Debug::log(print_r(func_get_args(), true));
//            Debug::log('registerNewCustomUser Arguments:' . PHP_EOL . print_r(func_get_args(), true) . PHP_EOL . (string) $response);
//            throw $response;
//        } else {
//            Debug::log('registerNewCustomUser SOAP Response:' . PHP_EOL . print_r($response, true));
//        }
//        return $response;

        $response = $this->getSoapClient('user')->registerNewCustomUser($jsonDataSet);

        if ($response instanceof SoapFault)
            throw $response;

        return $response;
    }


    /**
     * Perform preregistration
     *
     * @return mixed
     */
    public function registerNewUser()
    {
        //Arguments fetched with func_get_args
        Debug::log('Registration Arguments:' . PHP_EOL . print_r(func_get_args(), true));
        $response = $this->getSoapClient('user')->__soapCall('registerNewUser', func_get_args());
        if ($response instanceof SoapFault) {
            Debug::log($response->getCode());
            Debug::log(print_r(func_get_args(), true));
            Debug::log('registerNewUser Arguments:' . PHP_EOL . print_r(func_get_args(), true) . PHP_EOL . (string)$response);
            throw $response;
        } else {
            Debug::log('Registration SOAP Response:' . PHP_EOL . print_r($response, true));
        }
        return $response;
    }

    /**
     *
     * @param $username
     * @param $privacy_approve
     * @param $data_trx
     * @param $newsletter
     * @return mixed
     */
    public function setPrivacy($username, $privacy_approve = null, $data_trx = '', $newsletter = '', $p3 = '', $p4 = '', $p5 = '')
    {
        $response = $this->getSoapClient('user')->setPrivacy($username, $privacy_approve, $data_trx, $newsletter, $p3, $p4, $p5);

        if ($response instanceof SoapFault)
            throw $response;

        return $response;
    }

    /**
     * Set User Preferences
     *
     * @param $username
     * @param $preferred_library_id
     * @param $statistic_study
     * @param $statistic_work
     * @param $areas_of_interest
     * @return mixed
     */
    public function setUserPrefs($username, $preferred_library_id, $statistic_study, $statistic_work, $areas_of_interest)
    {
        $response = $this->getSoapClient('user')->setUserPrefs($username, $preferred_library_id, $statistic_study, $statistic_work, $areas_of_interest);

        if ($response instanceof SoapFault)
            throw $response;

        return $response;
    }

    /**
     * Change the user's password
     *
     * @param string $username
     * @param string $oldpassword
     * @param string $newpassword
     * @return array
     */
    public function setNewPassword($username, $oldpassword, $newpassword, $passwordexpire = null)
    {
        $response = $this->getSoapClient('user')->setNewPassword($username, $oldpassword, $newpassword, $passwordexpire);

        if ($response instanceof SoapFault)
            throw $response;
        if (!$response)
            throw new Exception('Old password was wrong');

        return $response;
    }

    /**
     * {@inheritdoc}
     */
    public function resetPassword($username, $newpassword, $passwordexpire = null)
    {
        if ($newpassword == 'wrong')
            throw new Exception('');

        $response = $this->getSoapClient('user')->setPassword($username, $newpassword, $passwordexpire);

        if ($response instanceof SoapFault)
            throw $response;
        //This method does not return "1" like others
        /*        if (! $response)
          throw new Exception('Something went wrong'); */

        return $response;
    }

    /**
     * Change the user's password
     *
     * @param string $oldusername
     * @param string $newusername
     * @return array
     */
    public function setNewUsername($oldusername, $newusername)
    {
        $response = $this->getSoapClient('user')->setNewUsername($oldusername, $newusername);

        if ($response instanceof SoapFault)
            throw $response;

        return $response;
    }

    /**
     * Edit user's contact info
     *
     * @param $username
     * @param $contact_id
     * @param $contact_type
     * @param $contact_value
     * @param $contact_pref
     * @return array
     */
    public function editContact($username, $contact_id, $contact_type, $contact_value, $contact_pref)
    {
        Debug::log('Contact Arguments:' . PHP_EOL . print_r(func_get_args(), true));
        $response = $this->getSoapClient('user')->editContact($username, $contact_id, $contact_type, $contact_value, $contact_pref);
        if ($response instanceof SoapFault) {
            Debug::log($response->getCode());
            Debug::log(print_r(func_get_args(), true));
            Debug::log('editContact Arguments:' . PHP_EOL . print_r(func_get_args(), true) . PHP_EOL . (string)$response);
            throw $response;
        } else {
            Debug::log('Contact SOAP Response:' . PHP_EOL . print_r($response, true));
        }
        return $response;
    }

    /**
     * Delete a contact by id
     *
     * @param $contact_id
     * @return mixed
     * @throws SoapFault
     */
    public function deleteContact($contact_id)
    {
        $response = $this->getSoapClient('user')->deleteContact($contact_id);

        if ($response instanceof SoapFault)
            throw $response;

        return $response;
    }

    /**
     * Edit user's address infos
     *
     * @param $username
     * @param $address_id
     * @param $address_type
     * @param $address_pref
     * @param $street_type
     * @param $street
     * @param $street_num
     * @param $village
     * @param $city
     * @param $zip
     * @param $province
     * @param $country
     * @return array
     */
    public function editAddress($username, $address_id, $address_type, $address_pref, $street_type, $street, $street_num, $village, $city, $zip, $province, $country)
    {
        Debug::log('Address Arguments:' . PHP_EOL . print_r(func_get_args(), true));
        $response = $this->getSoapClient('user')->editAddress($username, $address_id, $address_type, $address_pref, $street_type, $street, $street_num, $village, $city, $zip, $province, $country);
        if ($response instanceof SoapFault) {
            Debug::log($response->getCode());
            Debug::log(print_r(func_get_args(), true));
            Debug::log('editAddress Arguments:' . PHP_EOL . print_r(func_get_args(), true) . PHP_EOL . (string)$response);
            throw $response;
        } else {
            Debug::log('Address SOAP Response:' . PHP_EOL . print_r($response, true));
        }
        return $response;
    }

    /**
     * Delete a contact by id
     *
     * @param $address_id
     * @return mixed
     * @throws SoapFault
     */
    public function deleteAddress($address_id)
    {
        $response = $this->getSoapClient('user')->deleteAddress($address_id);

        if ($response instanceof SoapFault)
            throw $response;

        return $response;
    }

    /**
     * Get user's purchase proposal list
     *
     * @param $username
     * @param string $class
     * @return array
     */
    public function getPurchaseProposalList($username, $class = '', $start = null, $limit = null)
    {
        $response = $this->getSoapClient('user')->getPurchaseProposalList($username, $class, $start, $limit);

        if ($response instanceof SoapFault)
            throw $response;

        return $response;
    }

    /**
     * Edit an existing purchase proposal
     *
     * @param string $username
     * @param int $proposal_id
     * @param string $title
     * @param string $author
     * @param string $publisher
     * @param string $year
     * @param string $ean
     * @param string $notes
     * @return array
     */
    public function editPurchaseProposal($username, $proposal_id, $title, $author, $publisher, $year, $ean, $notes)
    {
        $response = $this->getSoapClient('user')->editPurchaseProposal($username, $proposal_id, $title, $author, $publisher, $year, $ean, $notes);

        if ($response instanceof SoapFault)
            throw $response;

        return $response;
    }

    /**
     * @param $proposal_id
     * @return mixed
     */
    public function retirePurchaseProposal($proposal_id)
    {
        $response = $this->getSoapClient('user')->retirePurchaseProposal($proposal_id);

        if ($response instanceof SoapFault)
            throw $response;

        return $response;
    }

    /*     * * CONSORTIA DATAS ** */

    /**
     * @param int $n
     * @return mixed
     */
    public function getLastRegisteredUsers($n = 10)
    {
        $users = $this->getSoapClient('user')->getUserList('last_registered', $n);
        return $users;
    }

    /**
     *
     * @param int $library_id
     * @return array
     */
    public function getLibraryStaff($library_id)
    {
        $ldata = $this->getSoapClient('consortia')->getLibraryData($library_id);
        return ($ldata && array_key_exists('staff', $ldata)) ? $ldata['staff'] : array();
    }

    /**
     * Retrieve consortia active Libraries
     * @return array (of library_code)
     */
    public function getConsortiaActiveLibraries()
    {
        $libraries = $this->getSoapClient('consortia')->getActiveLibraries();
        return ($libraries && !$libraries instanceof SoapFault) ? $libraries : array();
    }

    /**
     * Retrieve consortia internal Libraries
     * @return array (of library_code)
     */
    public function getConsortiaInternalLibraries()
    {
        $libraries = $this->getSoapClient('consortia')->getInternalLibraries();
        return ($libraries && !$libraries instanceof SoapFault) ?
            $libraries : array();
    }

    /**
     * Returns all libraries, including external ones
     *
     * @return mixed
     */
    public function getAllLibraries($filter = "all")
    {
        $libraries = $this->getSoapClient('consortia')->getLibraries($filter);

        return ($libraries && !$libraries instanceof SoapFault) ?
            $libraries : array();
    }

    /**
     * Get a list of libraries for Librarian
     *
     * @param int $librarian_id
     * @return array
     */
    public function getLibrariesForLibrarian($librarian_id = null)
    {
        if ($librarian_id) {
            $libraries = $this->getSoapClient('consortia')->getLibrariesForLibrarian($librarian_id);
            return ($libraries && !$libraries instanceof SoapFault) ?
                $libraries : array();
        } else
            return array();
    }

    /**
     * Get the open time table from clavis libraries
     *
     * @param int $clavis_library_id
     * @param int $from (timestamp)
     * @param int $to (timestamp)
     * @return array
     */
    public function getLibraryTimeTable($clavis_library_id = null, $from = null, $to = null)
    {
        if ($clavis_library_id) {
            $timetable = $this->getSoapClient('consortia')->getLibraryTimetable($clavis_library_id, $from, $to);
            return ($timetable && !$timetable instanceof SoapFault) ?
                $timetable : array();
        } else
            return array();
    }

    /**
     * Get the Anagraphic data of a library
     *
     * @param string $clavis_library_id
     * @return array
     */
    public function getLibraryData($clavis_library_id)
    {
        if ($clavis_library_id) {
            $libraryData = $this->getSoapClient('consortia')->getLibraryData($clavis_library_id);

            return ($libraryData && !$libraryData instanceof SoapFault) ?
                $libraryData : array();
        } else
            return array();
    }

    /* END CONSORTIA DATAS */

    /* LOAN */

    /**
     * Perform a reservation request
     *
     * @param $manId
     * @param $patronUsername
     * @param $libraryId
     * @param null $issueId
     * @param null $reserveNote
     * @return array
     */
    public function doReserve($manId, $patronUsername, $libraryId, $issueId = null, $reserveNote = null)
    {

        $response = $this->getSoapClient('loan')->addReservation($manId, $patronUsername, $libraryId, $issueId, $reserveNote);

        $patronIp = isset($_SERVER["HTTP_X_FORWARDED_FOR"]) ? $_SERVER["HTTP_X_FORWARDED_FOR"] : $_SERVER["REMOTE_ADDR"];

        Debug::log(
            "Reservation requested: ID $manId" . PHP_EOL .
            "Patron: $patronUsername" . PHP_EOL .
            "CurrentMemberId: " . Member::currentUserID() . PHP_EOL .
            "LibraryId: " . $libraryId . PHP_EOL .
            "Patron IP: " . $patronIp . PHP_EOL .
            "IssueId: " . $issueId . PHP_EOL .
            "ReserveNote: " . $reserveNote
        );

        if ($response && !$response instanceof SoapFault) {
            return array(
                'response_code' => $response,
                'response_str' => isset(self::$reservation_responses[(int)$response]) ?
                    self::$reservation_responses[(int)$response] : (string)$response
            );
        }

        if ($response instanceof SoapFault)
            throw $response;

        return array();
    }

    /**
     * Renew the loan of an item
     *
     * @param $itemId
     * @return mixed
     * @throws Exception
     */
    public function renewItemLoan($itemId)
    {
        $response = $this->getSoapClient('loan')->renewItemLoan($itemId);

        if ($response instanceof SoapFault)
            throw $response;

        if ($response != 'OK')
            throw new Exception($response);

        return $response;
    }

    /**
     * Get patron's active loan
     * @param string $username The patron's username
     *
     * @return array
     * @throws SoapFault
     */
    public function getPatronActiveLoans($username)
    {
        $response = $this->getSoapClient('loan')->getPatronActiveLoans($username);

        if ($response instanceof SoapFault)
            throw $response;

        return $response;
    }

    /**
     * Get patron's pending loan
     * @param string $username The patron's username
     *
     * @return array
     * @throws SoapFault
     */
    public function getPatronPendingLoans($username)
    {
        $response = $this->getSoapClient('loan')->getPatronPendingLoans($username);

        if ($response instanceof SoapFault)
            throw $response;

        return $response;
    }

    /**
     * Get patron's pending loan
     *
     * @param type $username
     * @param type $start
     * @param type $limit
     * @param type $search
     * @param type $orderByTitle
     * @param type $orderByBeginDate
     * @param type $orderByEndDate
     * @return SoapFault
     * @throws @var:$this@mtd:getSoapClient@mtd:getPatronClosedLoans
     */
    public function getPatronClosedLoans($username, $start = null, $limit = null, $search = null, $orderBy = null, $orderDirection = null)
    {
        $response = $this->getSoapClient('loan')->getPatronClosedLoans($username, $start, $limit, $search, $orderBy, $orderDirection);
        if ($response instanceof SoapFault)
            throw $response;
        return $response;
    }

    /**
     * Get patron's active requests
     * @param string $username The patron's username
     *
     * @return array
     * @throws SoapFault
     */
    public function getPatronActiveRequests($username)
    {
        $response = $this->getSoapClient('loan')->getPatronActiveRequests($username);

        if ($response instanceof SoapFault)
            throw $response;

        return $response;
    }

    /**
     * Cancel a reservation using its id
     * @param int $reservationId
     *
     * @return string
     */
    public function cancelReservation($reservationId)
    {
        $response = $this->getSoapClient('loan')->cancelReservation($reservationId);

        if ($response instanceof SoapFault)
            throw $response;

        if ($response != 'OK')
            throw new Exception($response);

        return $response;
    }

    /**
     * Change the delivery library of a request
     *
     * @param $requestId
     * @param $deliveryLibrary
     * @return mixed
     * @throws Exception
     * @throws SoapFault
     */
    public function changeReservationDeliveryLibrary($requestId, $deliveryLibrary)
    {
        $response = $this->getSoapClient('loan')->changeReservationDeliveryLibrary($requestId, $deliveryLibrary);

        if ($response instanceof SoapFault)
            throw $response;

        if ($response != 'OK')
            throw new Exception($response);

        return $response;
    }

    public function setSolrCatalog($solrCatalog)
    {
        $this->solrCatalog = $solrCatalog;
    }

    public function getSolrCatalog()
    {
        return $this->solrCatalog;
    }

    public function setSolrDatabase($solrDatabase)
    {
        $this->solrDatabase = $solrDatabase;
    }

    public function getSolrDatabase()
    {
        return $this->solrDatabase;
    }

    public function setConsortiaName($consortiaName)
    {
        $this->consortiaName = $consortiaName;
    }

    public function setConsortiaSecret($consortiaSecret)
    {
        $this->consortiaSecret = $consortiaSecret;
    }

    private function setAuthenticationHeaders(LiquensSoapClient $client)
    {
        if (isset($this->consortiaSecret)) {
            $headers[] = new SoapHeader($this->webserviceUrl, 'AuthToken', array($this->consortiaName, $this->consortiaSecret));
            $client->__setSoapHeaders($headers);
        }

        return $this;
    }

}
