<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Giulio Bonanome <giulio@comperio.it>
 */

class MLOLConnector {   
    
    public $webserviceUrl;
    public $api_key;
    public $portal_id;
    public $timeout = 5;

    public function __construct($webserviceUrl = null, $api_key = null, $portal_id = null, $timeout = 5) {
        $this->webserviceUrl = $webserviceUrl;
        $this->api_key = $api_key;
        $this->portal_id = $portal_id;
        global $sc;
        if ($sc->getParameter('lq.connector.timeout') != 5)
            $timeout = $sc->getParameter('lq.connector.timeout');
        $this->timeout = $timeout;
    }

    /**
     * Performs a request for a specific media object on MLOL
     * The response is a one-shot link to another page that perform another post
     * 
     * @param $manId
     * @param $patronUsername
     * @return array
     */
    public function OpenMediaUniqueUser($manId, $patronUsername, $patronExternal_Anchor)
    {   

        if(!isset($this->api_key) || !isset($this->portal_id)) {
            throw new Exception(_t('MLOL.MISSINGPARAMETERS'));
            return array('response_code' => 0);
        }

        $client = new LiquensSoapClient(
            $this->webserviceUrl,
            array('trace' => 1, 'cache_wsdl' =>  WSDL_CACHE_BOTH, 'connection_timeout' => $this->timeout)
        );

        $params = array(
            "api_key" => $this->api_key,
            "portal_id" => $this->portal_id,
            "username" => $patronUsername,
            "media_id" => $manId,
            "unique_user_id" => explode(":", $patronExternal_Anchor)[1]
        );

        try {
            $mediaResult = $client->OpenMediaUniqueUser($params);
        } catch(Exception $e){
            throw new Exception(_t('MLOL.SOAPERROR'));
            return array('response_code' => 0);
        }

        $xml = simplexml_load_string($mediaResult->OpenMediaUniqueUserResult->any);

        if ($xml->status != 'ok') {
            throw new Exception(_t('MLOL.SOAPPARSEERROR'));
            return array('response_code' => 0);
        }

        $result = array(
            "response_code" => 1,
            "url" => $xml->url,
            "param_name" => $xml->param_name,
            "param_value" => $xml->param_value,
        );
        
        return $result;
    }

    /**
     * Performs a simple search on MLOL
     * 
     * @param $keywords
     * @return xml
     */
    public function doSearch($keywords)
    {

        if(!isset($this->api_key) || !isset($this->portal_id)) {
            throw new Exception(_t('MLOL.MISSINGPARAMETERS'));
            return array('response_code' => 0);
        }

        $client = new LiquensSoapClient(
            $this->webserviceUrl,
            array('trace' => 1, 'cache_wsdl' =>  WSDL_CACHE_BOTH, 'connection_timeout' => $this->timeout)
        );

        $params = array(
            "api_key" => $this->api_key,
            "idPortale" => $this->portal_id,
            "keywords" => $keywords
        );

        try {
            $searchResult = $client->Ricerca($params);
        } catch(Exception $e){
            throw new Exception(_t('MLOL.SOAPERROR'));
            return array('response_code' => 0);
        }

        $xml = simplexml_load_string($searchResult->RicercaResult->any);

	if ($xml->stato != 'ok') {
//	Debug::log("MLOL ERR:" . $searchResult->RicercaResult->any);
//	Debug::log("MLOL ERR: {$keywords} {$this->api_key} {$this->portal_id}");
            throw new Exception(_t('MLOL.SOAPPARSEERROR'));
            return array('response_code' => 0);
        }
        
        return $xml;

    }
    
    /**
     * Chiamata alla funzione UserLoans attraverso API MediaLibraryOnline
     * 
     * @param type $patronUsername
     * @return type
     * @throws Exception
     */
    public function getUserLoans($patronUsername) {
        
        // Verifica presenza dei parametri richiesti
        if(!isset($this->api_key) || !isset($this->portal_id)) {
            throw new Exception(_t('MLOL.MISSINGPARAMETERS'));
            return array('response_code' => 0);
        }

        // Collegamento attraverso web service (liquens)
        $client = new LiquensSoapClient(
            $this->webserviceUrl,
            array('trace' => 1, 'cache_wsdl' =>  WSDL_CACHE_BOTH, 'connection_timeout' => $this->timeout)
        );

//        ExternalAuthenticator::AuthLog($patronUsername.".MLOL"." - api_key: ".$this->api_key." portal_id: ".$this->portal_id);
        
        // Versione client web service normale
//        $client = new SoapClient($this->webserviceUrl, array( "trace"=>1, 'cache_wsdl'=>WSDL_CACHE_NONE));

        // Aggiunta parametri
        $params = array(
            "api_key" => $this->api_key,
            "portal_id" => $this->portal_id,
            "username" => $patronUsername
        );
        
        // Attivazione chiamata
        try {
            $mediaResult = $client->UserLoans($params);
        } catch(Exception $e){
            throw new Exception(_t('MLOL.SOAPERROR'));
            return array('response_code' => 0);
        }
        
        // Estrapolazione dati dall'XML
        $xml = simplexml_load_string($mediaResult->UserLoansResult->any);

        return $xml;
    }
    
    /**
     * Chiamata alle funzioni di lista di MLOL.
     * Funzione costruita in modo da essere generica per eventuali nuove liste.
     * 
     * @param type $type
     * @param type $resource
     * @return type
     */
    public function getMediaList($type, $resource) {
                
        // Verifica presenza dei parametri richiesti
        if(!isset($this->api_key) || !isset($this->portal_id)) {
            throw new Exception(_t('MLOL.MISSINGPARAMETERS'));
            return array('response_code' => 0);
        }

        // Collegamento attraverso web service (liquens)
        $client = new LiquensSoapClient(
            $this->webserviceUrl,
            array('trace' => 1, 'cache_wsdl' =>  WSDL_CACHE_BOTH, 'connection_timeout' => $this->timeout)
        );

        // Aggiunta parametri
        $params = array(
            "api_key" => $this->api_key,
            "portal_id" => $this->portal_id,
            "type_id" => $resource
        );
        
        // Attivazione chiamata
        try {
            $mediaResult = $client->$type($params);
        } catch(Exception $e){
            throw new Exception(_t('MLOL.SOAPERROR'));
            return array('response_code' => 0);
        }
        
        $val = (string)$type."Result";
        // Estrapolazione dati dall'XML
        $xml = simplexml_load_string($mediaResult->$val->any);
        
        return $xml;
    }

}
