<?php

/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

/**
 * A utility class for geocoding addresses using the google maps API.
 *
 * @package silverstripe-addressable
 */
class LqGoogleGeocoding {

    const OLD_API_URL = 'http://maps.googleapis.com/maps/api/geocode/xml';
    const API_URL = 'https://cloud2.comperio.it/api/location/place/find/';

    /**
     * Convert an address into a latitude and longitude.
     *
     * @param  string $address The address to geocode.
     * @param  string $region  An optional two letter region code.
     * @return array An associative array with lat and lng keys.
     */
    public static function old_address_to_point($address, $region = null) {
        $service = new RestfulService(self::API_URL, 3600, 30);
        $service->setQueryString(array(
            'address' => $address,
            'sensor' => 'false',
            'region' => $region
        ));
        $response = $service->request()->simpleXML();

        if ($response->status != 'OK') {
            return false;
        }

        $location = $response->result->geometry->location;
        return array(
            'lat' => (float) $location->lat,
            'lng' => (float) $location->lng
        );
    }

    public static function address_to_point($address, $region = null) {

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
        curl_setopt($ch, CURLOPT_URL, self::API_URL . urlencode($address));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 0); 
        curl_setopt($ch, CURLOPT_TIMEOUT, 30); //timeout in seconds
        $response = curl_exec($ch);
        curl_close($ch);

        return is_string($response) && is_array(json_decode($response, true)) ? array(
            'lat' => (float) json_decode($response)->lat,
            'lng' => (float) json_decode($response)->lng
                ) : false;
    }

}
