<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

/**
 * This class has been created to prevent localized float conversion when rendering a float value
 */
class DngNumericField extends NumericField
{
    /**
     * Convert the value to a string where commas are converted to dots.
     *
     * @param $value
     * @return FormField
     */
    function setValue($value)
    {
        $value = str_replace(',', '.', (string) $value);

        return parent::setValue($value);
    }

}
