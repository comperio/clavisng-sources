<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

use Symfony\Component\Yaml\Yaml;
use Symfony\Component\DependencyInjection\Dumper\PhpDumper;
use Symfony\Component\DependencyInjection\ContainerBuilder;
use Symfony\Component\DependencyInjection\Reference;
use Symfony\Component\Config\FileLocator;
use Symfony\Component\Config\ConfigCache;
use Symfony\Component\DependencyInjection\Loader\YamlFileLoader;
use Symfony\Component\DependencyInjection\Compiler\MergeExtensionConfigurationPass;

/**
 *
 */
class Kernel
{
    /**
     * @var
     */
    private $baseApplicationPath;

    /**
     * @var string
     */
    private $baseLiquensPath;

    /**
     * @var
     */
    private $tempPath;

    /**
     * @var
     */
    private $assetsPath;

    /**
     * @var string
     */
    private $containerClass = 'DngContainer';

    /**
     * @var
     */
    private $dngSite;

    /**
     * @var ContainerBuilder
     */
    private $container;

    /**
     * @static
     * @param $object
     * @param Symfony\Component\DependencyInjection\ContainerBuilder $container
     * @return mixed
     */
    public static function load_injections($object, ContainerBuilder $container = null)
    {
        if (!isset($container)) {
            global $sc;
            $container = $sc;
        }

        if(!$container->hasParameter('injection.class_map')) {
            return;
        }

        $map = $container->getParameter('injection.class_map');

        foreach ($map as $className => $injectionsServices) {
            if ($object instanceof $className){
                foreach ($injectionsServices as $injectionService){
                    $container->get($injectionService)->inject($object);
                }
            }
        }
    }

    /**
     * @param $basePath
     * @param $tempPath
     * @param $dngSite
     */
    public function __construct($basePath, $tempPath, $assetsPath, $dngSite)
    {
        $this->baseApplicationPath = $basePath;
        $this->baseLiquensPath = $basePath . DIRECTORY_SEPARATOR . 'liquens';
        $this->tempPath = $tempPath;
        $this->assetsPath = $assetsPath;
        $this->dngSite = $dngSite;
    }

    /**
     * Initialize the configuration
     */
    public function init()
    {
        $this->includeSubmodulesConfig('liquens');

        //See trac's wiki notes (Appunti sulla localizzazione ss)
        i18n::include_by_locale(i18n::get_locale());

        $this->initializeContainer();
        $this->initLocale();

        $this->parseQueryString();
        $this->parseCookies();
    }

    /**
     * To run after initialization
     */
    public function boot()
    {
        global $databaseConfig;

        $container = $this->getContainer();
        $databaseConfig = $container->getParameter('database');
        Director::set_environment_type($container->getParameter('ss.environment'));
        SSViewer::set_theme($container->getParameter('ss.theme'));

        $adminPswd = $container->getParameter('ss.default_admin_pwd');
        RecoverPasswordRequest::$encryption_key = $container->getParameter('encryption_key');

        if ($adminPswd)
            Security::setDefaultAdmin('admin', $adminPswd);

        Security::$autologin_enabled = true;

        MySQLDatabase::set_connection_charset('utf8');

        $this
            ->loadRoutes()
            ->loadDecorators()
            ->setLogOptions()
        ;

        //Set ApplicationText And ApplicationLogoText for CMS
        LeftAndMain::setApplicationName('DNG', 'DNG, the Social OPAC');
        LeftAndMain::$help_link = 'http://docs.comperio.it/dngmanual/';

        File::$allowed_extensions = array_merge(File::$allowed_extensions, array('ods', 'odt', 'odb', 'odb', 'epub'));
    }

    /**
     * Include all files needed for localizations. Must be called after $locale has been set.
     * @param string $locale
     * @return Kernel the current instance
     */
    public function includeLangFiles($locale)
    {
        $this->includeSubmodulesLang('liquens', $locale);
        $this->includeLookupValuesLang($locale);
        i18n::include_by_locale($locale);
        $this->includeSiteLookupValuesLang($locale);
        $this->includeSiteLang($locale);

        return $this;
    }

    /**
     * @return Symfony\Component\DependencyInjection\ContainerBuilder
     */
    public function getContainer()
    {
        return $this->container;
    }

    /**
     * Initializes the service container.
     *
     * The cached version of the service container is used when fresh, otherwise the
     * container is built.
     */
    public function initializeContainer()
    {
        $configCache = new ConfigCache(
            $this->tempPath.DIRECTORY_SEPARATOR."/{$this->containerClass}.php",
            Director::get_environment_type() != 'live'
        );

        $container = new ContainerBuilder;

        $container->setParameter('kernel.application_path', $this->baseApplicationPath);
        $container->setParameter('kernel.liquens_path', $this->baseLiquensPath);
        $container->setParameter('kernel.temp_path', $this->tempPath);

        // I do not put kernel. prefix because I have to access to this param from templates, and...
        $container->setParameter('site_name', $this->dngSite);

        if (!$configCache->isFresh() || isset($_GET['flush']) || isset($_GET['flushconfig'])) {
            $this->registerExtensions($container);

            // Installation-specific configuration
            $globalConfigPath = $this->baseApplicationPath.DIRECTORY_SEPARATOR.'sites'.DIRECTORY_SEPARATOR.'global.config.yml';
            
            // Site-specific configuration
            $siteConfigPath = $this->getSitePath().DIRECTORY_SEPARATOR.'config.yml';

            $loader = new YamlFileLoader($container, new FileLocator(__DIR__));
            $loader->load($this->baseLiquensPath.DIRECTORY_SEPARATOR.'config'.DIRECTORY_SEPARATOR.'config.yml');

            if (file_exists($globalConfigPath)) {
                $loader->load($globalConfigPath);
            }

            if (file_exists($siteConfigPath)) {
                $loader->load($siteConfigPath);
                $this->mergeSiteParameters($container);
            }

            $this->buildInjectionParameter($container);

            $this->loadSolrConfiguration($container);

            $this->dumpContainer($container, $configCache);
            $this->dumpLang();
        }

        require_once $configCache;

        $this->container = new $this->containerClass;
    }

    /**
     * Transform a container into a php-compiled file
     *
     * @param Symfony\Component\DependencyInjection\ContainerBuilder $container
     * @param Symfony\Component\Config\ConfigCache $cache
     */
    public function dumpContainer(ContainerBuilder $container, ConfigCache $cache)
    {
        // cache the container
        $dumper = new PhpDumper($container);
        $content = $dumper->dump(array('class' => $this->containerClass, 'base_class' => 'Symfony\Component\DependencyInjection\ContainerBuilder'));
        $cache->write($content, $container->getResources());
    }

    /**
     * Dump the lang.yml file to standard ss .php files
     */
    public function dumpLang()
    {
        $filePath = implode(DIRECTORY_SEPARATOR, array($this->baseLiquensPath, 'config', 'lang.yml'));
        $fileContent = file_get_contents($filePath);

        $langArray = Yaml::parse($fileContent);
        $ssLang = array();

        //Transform the array parsed from yaml file to an ss lang array
        foreach ($langArray as $namespace => $keys) {
            foreach ($keys as $key => $locales) {
                foreach ($locales as $locale => $string) {
                    $ssLang[$locale][$namespace][$key] = $string;
                }
            }
        }

        foreach ($ssLang as $locale => $namespaces) {
            $fileName = implode(DIRECTORY_SEPARATOR, array($this->baseLiquensPath, 'lang', "$locale.php"));
            SyncLookupValues::dump_array_to_file(array($locale => $ssLang[$locale]), $fileName);
        }
    }

    /**
     * Returns the site path, using the global parameter $dngSite
     * @return string
     */
    public function getSitePath()
    {
        return $this->baseApplicationPath.DIRECTORY_SEPARATOR.'sites'.DIRECTORY_SEPARATOR.$this->dngSite;
    }

    /**
     * Do stuff after container initialization fetching data from the query string
     */
    private function parseQueryString()
    {
        if (isset($_GET['set-solr'])) {
            $solr = $_GET['set-solr'];
            if ($solr == 'default') {
                setcookie('solr', '', time() - 3600, '/');
                unset($_COOKIE['solr']);
            } else {
                setcookie('solr', $_GET['set-solr'], 0, '/');
                $_COOKIE['solr'] = $_GET['set-solr'];
            }
        }

        if (isset($_GET['set-theme'])) {
            $theme = $_GET['set-theme'];
            if ($theme == 'default') {
                setcookie('theme', '', time() - 3600, '/');
                unset($_COOKIE['theme']);
            } else {
                setcookie('theme', $_GET['set-theme'], 0, '/');
                $_COOKIE['theme'] = $_GET['set-theme'];
            }
        }
    }

    /**
     * Do stuff after container initialization fetching data from the cookies
     */
    private function parseCookies()
    {
        if (!$this->getContainer()->getParameter('cookie_config_overwrite')) return;

        if (isset($_COOKIE['solr'])) $this->container->setParameter('lq.baseURL', $_COOKIE['solr']);
        if (isset($_COOKIE['theme'])) $this->container->setParameter('ss.theme', $_COOKIE['theme']);
    }

    private function registerExtensions(ContainerBuilder $container)
    {
        $container->registerExtension(new SolrExtension());
    }

    /**
     * Include all lang files of subdirectories of a module
     *
     * @param string $module
     * @param string $locale
     *
     * @return Kernel The current instance
     */
    private function includeSubmodulesLang($module, $locale)
    {
        $moduleDir = $this->baseApplicationPath.DIRECTORY_SEPARATOR.$module;

        foreach(scandir($moduleDir) as $subModule) {
            // $topLevel is the liquens root, some servers are configured not to allow excess website root's parent level
            // and we don't need to check website root's parent level and website root level for its lang folder, so
            // we skip these 2 levels checking.
            if($subModule[0] == '.') {
                continue;
            }

            if (
                is_dir("$moduleDir/$subModule")
                && file_exists("$moduleDir/$subModule/_config.php")
                && file_exists($file = "$moduleDir/$subModule/lang/$locale.php")
            ) {
                include_once($file);
            }
        }

        return $this;
    }

    /**
     * Include lang files of the current site
     * @param string $locale
     * @return Kernel the current instance
     */
    private function includeSiteLang($locale)
    {
        $path = $this->getSitePath() . "/lang/$locale.php";
        if (file_exists($path)){
            include_once($path);
        }

        return $this;
    }

    /**
     * Include all _config.php files of subdirectories of a module
     *
     * @param $module
     */
    private function includeSubmodulesConfig($module)
    {
        $moduleDir = $this->baseApplicationPath.DIRECTORY_SEPARATOR.$module;

        foreach(scandir($moduleDir) as $subModule) {
            // $topLevel is the liquens root, some servers are configured not to allow excess website root's parent level
            // and we don't need to check website root's parent level and website root level for its lang folder, so
            // we skip these 2 levels checking.
            if($subModule[0] == '.') {
                continue;
            }

            if (is_dir("$moduleDir/$subModule")
                    && file_exists($config = "$moduleDir/$subModule/_config.php"))
            {
                include_once($config);
            }
        }

        return $this;
    }

    /**
     * Include lookup values file
     *
     * @param string $locale
     *
     * @return Kernel the current instance
     */
    private function includeLookupValuesLang($locale)
    {
        $path = implode(DIRECTORY_SEPARATOR, array($this->baseLiquensPath, 'lang', "lookupValues.$locale.php"));

        if(file_exists($path)){
            require_once($path);
        }

        return $this;
    }

    /**
     * Include lookup values site-specific file
     *
     * @param string $locale
     *
     * @return Kernel the current instance
     */
    private function includeSiteLookupValuesLang($locale)
    {
        $sitepath = implode(DIRECTORY_SEPARATOR, array($this->getSitePath(), 'lang', "lookupValues.$locale.php"));

        if(file_exists($sitepath)){
            require_once($sitepath);
        }

        return $this;
    }

    /**
     * @return Kernel
     */
    private function setLogOptions()
    {
        SS_Log::add_writer(new SS_LogFileWriter($this->baseApplicationPath.DIRECTORY_SEPARATOR.'logs/silverstripe.log'), SS_Log::NOTICE, '<=');
        ExternalAuthenticator::setAuthDebug($this->baseApplicationPath.DIRECTORY_SEPARATOR.'logs/sstripe_debug.log');
        ExternalAuthenticator::setAuditLogFile($this->baseApplicationPath.DIRECTORY_SEPARATOR.'logs/sstripe_audit.log');
        ExternalAuthenticator::setAuditLogSStripe(true);

        return $this;
    }

    /**
     * @param Symfony\Component\DependencyInjection\ContainerBuilder $container
     * @return Kernel
     */
    private function buildInjectionParameter(ContainerBuilder $container)
    {
        $tags = $container->findTaggedServiceIds('dataobject.injection');

        $injectionParameter = array();

        foreach ($tags as $serviceId => $tag) {
            $definition = $container->findDefinition($serviceId);
            $arguments = $definition->getArguments();
            $className = $arguments[0];

            $injectionParameter[$className][] = $serviceId;
        }

        $container->setParameter('injection.class_map', $injectionParameter);

        return $this;
    }

    /**
     * @return Kernel
     */
    private function loadDecorators()
    {
        if ($this->getContainer()->hasParameter('ss.extensions')){
            foreach ($this->getContainer()->getParameter('ss.extensions') as $extension) {
                SSObject::add_extension($extension['decorated'], $extension['decorator']);
            }
        }

        return $this;
    }

    /**
     * @return Kernel
     */
    private function loadRoutes()
    {
        if ($this->getContainer()->hasParameter('ss.routes')){
            foreach ($this->getContainer()->getParameter('ss.routes') as $routeName => $routeParameters) {
                Director::addRules($routeParameters['priority'], array($routeParameters['pattern'] => $routeParameters['controller']));
            }
        }

        return $this;
    }

    /**
     * @return Kernel
     */
    private function initLocale()
    {
        Translatable::set_allowed_locales(
           $this->getContainer()->getParameter('available_locales')
        );

        //Must be before of Object::add_extension('SiteTree', 'Translatable');
        i18n::set_locale('it_IT');
        i18n::set_default_locale('it_IT');
        Translatable::set_default_locale('it_IT');
        setlocale(LC_ALL,'it_IT');
        date_default_timezone_set('Europe/Berlin');
        ini_set('date.timezone', 'Europe/Berlin');

        return $this;
    }

    /**
     * Build SolrFields services
     *
     * @param ContainerBuilder $container
     */
    private function loadSolrConfiguration(ContainerBuilder $container)
    {
        $getDefName = function($name) {
            return "solr.fields." . str_replace('-', '_', $name);
        };

        $collectionDef = $container->register('solr.fields_collection', 'SolrSearchFieldCollection');

        $i = 1;
        foreach ($container->getParameter('lq.fields') as $fieldName => $fieldConfig) {
            $className = 'SimpleSolrSearchField';

            if (isset($fieldConfig['class'])) {
                $className = $fieldConfig['class'];
            } elseif (isset($fieldConfig['rangeable']) && $fieldConfig['rangeable']) {
                $className = 'RangeSolrSearchField';
            }

            $definitionName =  $getDefName($fieldName);
            $definition = $container->register($definitionName, $className);

            if ($className === 'CompositeSolrSearchField' || is_subclass_of($className, 'CompositeSolrSearchField')) {
                $definition->addArgument('LQFields.'. strtoupper($fieldName));
                foreach ($fieldConfig['subfields'] as $subfieldName => $regexp) {
                    $definition->addMethodCall('registerField', array($regexp, new Reference($getDefName($subfieldName))));
                }
            }

            if ($className === 'TemplateSolrSearchField' || is_subclass_of($className, 'TemplateSolrSearchField')) {
                if (isset($fieldConfig['template'])) {
                    $definition->addArgument($fieldConfig['template'])->addArgument('LQFields.'. strtoupper($fieldName));
                } else {
                    $solrFields = isset($fieldConfig['field']) ? $fieldConfig['field'] : null;
                    if(!is_array($solrFields)) {
                        $solrFields = array($solrFields);
                    }
                    $definition->addArgument($solrFields)->addArgument('LQFields.'. strtoupper($fieldName));
                }

                if (isset($fieldConfig['phrase']) && $fieldConfig['phrase']) {
                    $definition->addMethodCall('setPhrasized', array(true));
                }

                if (isset($fieldConfig['include_phrase_condition'])) {
                    $definition->addMethodCall('includePhraseCondition', array($fieldConfig['include_phrase_condition']));
                }

                if (isset($fieldConfig['isFacet']) && $fieldConfig['isFacet']) {
                    $definition->addMethodCall('setRelevantForScoring', array(false));
                    $definition->addMethodCall('setPhrasized', array(true));
                } else {
                    if (!isset($fieldConfig['addPlusBetweenWords']) || $fieldConfig['addPlusBetweenWords'])
                        $definition->addMethodCall('setAddPlusBetweenWords', array(true));
                }

                if (isset($fieldConfig['parenthesized'])) {
                    $definition->addMethodCall('setParenthesized', array((bool) $fieldConfig['parenthesized']));
                }

                if (isset($fieldConfig['map'])) {
                    $transfDefName = $definitionName . '.transformation';
                    $container->register($transfDefName, 'MapTransformation')->addArgument($fieldConfig['map']);

                    if (is_string($fieldConfig['map'])) {
                        if ($container->hasDefinition($fieldConfig['map'])) {
                            $container->setAlias($transfDefName, $fieldConfig['map']);
                        }
                    }
                    $definition->addMethodCall('setDisplayValueTransformation', array(new Reference($transfDefName)));
                }
            }

            $collectionDef->addMethodCall('registerField', array($fieldName, new Reference($definitionName)));
            $i++;
        }

        //New solr specification through plain container configuration (not used yet)
        foreach($container->findTaggedServiceIds('search.field') as $id => $attributes) {
            $fieldName = substr($id, strlen('search.field.'));
            if (isset($attributes['field_name']))
                $fieldName = $attributes['field_name'];

            $collectionDef->addMethodCall('registerField', array($fieldName, new Reference($id)));
        }
    }

    /**
     * Merge site.lq.fields parameter with lq.fields
     *
     * @param ContainerBuilder $container
     */
    private function mergeSiteParameters(ContainerBuilder $container)
    {
        if ($container->hasParameter('site.lq.fields')){
            $siteParam = $container->getParameter('site.lq.fields');
            $defaultParam = $container->getParameter('lq.fields');

            $newParam = $siteParam + $defaultParam;

            $container->setParameter('lq.fields', $newParam);
        }
    }
}
