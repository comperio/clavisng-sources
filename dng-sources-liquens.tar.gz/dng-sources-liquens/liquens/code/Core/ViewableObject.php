<?php

/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

/**
 * A simple generic object -> ViewableData adapter.
 */
class ViewableObject extends ViewableData {

    private $object;

    /**
     * Converts a collection of objects into a DataObjectSet of ViewableObjects
     *
     * @param Traversable $objects
     * @return DataObjectSet
     */
    public static function traversable_to_viewable_dataset($objects) {
        $dataset = new DataObjectSet();

        foreach ($objects as $object) {
            $dataset->push(new ViewableObject($object));
        }

        return $dataset;
    }

    /**
     * @param $object
     */
    public function __construct($object) {
        $this->object = $object;
    }

    /**
     * @param $field
     * @param array $arguments
     * @param bool $cache
     * @return mixed
     */
    public function XML_val($field, $arguments = array(), $cache = false) {
        if (!is_array($arguments))
            $arguments = (array) $arguments;

        if (method_exists($this->object, $field)) {
            return call_user_func_array(array($this->object, $field), $arguments);
        } elseif (method_exists($this->object, 'get' . ucfirst($field))) {
            return call_user_func_array(array($this->object, 'get' . ucfirst($field)), $arguments);
        } else if (isset($this->object->$field)) {
            return $this->object->$field;
        }
        return parent::XML_val($field, $arguments, $cache);
    }

    /**
     * Call underlying object methods if object has the method
     *
     * @param string $method
     * @param array $arguments
     * @return mixed
     */
    public function __call($method, $arguments) {
        if (method_exists($this->object, $method)) {
            return call_user_func_array(array($this->object, $method), $arguments);
        } elseif (method_exists($this->object, 'get' . $method)) {
            return call_user_func_array(array($this->object, 'get' . $method), $arguments);
        }

        return parent::__call($method, $arguments);
    }

    /**
     * @param string $property
     * @return mixed
     */
    public function __get($property) {
        if (method_exists($this->object, $property)) {
            return call_user_func_array(array($this->object, $property), array());
        } elseif (method_exists($this->object, 'get' . ucfirst($property))) {
            return call_user_func_array(array($this->object, 'get' . ucfirst($property)), array());
        } else if (isset($this->object->$property)) {
            return $this->object->$property;
        }

        return parent::__get($property);
    }

    /**
     * Function siimlar to Top to get the current controller even if the controller is not at the top of the stack
     *
     * @return Controller
     */
    public function dTop() {
        $top = Controller::curr();
        return $top;
    }

}
