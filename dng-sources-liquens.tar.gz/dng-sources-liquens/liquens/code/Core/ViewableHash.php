<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class ViewableHash extends DataObjectSet
{
    public function __construct(array $hash = array())
    {
        $this->setValue($hash);
    }

    public function setValue(array $hash)
    {
        foreach ($hash as $key => $value) {
           $this->push(new ArrayData(array(
               'key' => $key,
               'value' => $value,
           )));
       }
    }

    /**
     * Function siimlar to Top to get the current controller even if the controller is not at the top of the stack
     *
     * @return Controller
     */
    public function dTop()
    {
        $top = Controller::curr();
        return $top;
    }
}
