<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

/**
 * This class corrects the behaviour of type float in the DNG Orm.
 * The problem was that SS translates float into sql strings using the current locale
 */
class DngDecimal extends Decimal
{
    /**
     * @param mixed $value
     * @return array|int|string
     */
    public function prepValueForDB($value)
    {
        $value = str_replace(',', '.', (string) $value);

        return parent::prepValueForDB($value);
    }

    /**
     * @param null $title
     * @param null $params
     * @return DngNumericField|NumericField
     */
    public function scaffoldFormField($title = null, $params = null)
    {
        return new DngNumericField($this->name, $title);
    }


}
