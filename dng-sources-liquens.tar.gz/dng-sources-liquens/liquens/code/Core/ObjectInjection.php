<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class ObjectInjection
{
    private $methodCalls;
    private $objectClass;

    /**
     * @param $objectClass
     *
     * @throws InvalidArgumentException
     */
    public function __construct($objectClass)
    {
        if (!class_exists($objectClass))
            throw new InvalidArgumentException($objectClass . ' class does not exist.');

        $this->objectClass = $objectClass;
    }

    /**
     * Returns the objectClass property
     *
     * @return string
     */
    public function getObjectClass()
    {
        return $this->objectClass;
    }

    /**
     * Call methods on the given object
     *
     * @param SSObject $object An instance of $this->objectClass class
     *
     * @throws InvalidArgumentException
     */
    public function inject($object)
    {
        if (! $object instanceof $this->objectClass)
            throw new InvalidArgumentException('The object to be injected must be an instance of ' . $this->objectClass);

        foreach ($this->methodCalls as $methodCall) {
            call_user_func_array(array($object, $methodCall[0]), $methodCall[1]);
        }
    }

    /**
     * Adds a method to call after service initialization.
     *
     * @param  string $method    The method name to call
     * @param  array  $arguments An array of arguments to pass to the method call
     *
     * @throws InvalidArgumentException
     *
     * @return ObjectInjection The current instance
     */
    public function addMethodCall($method, array $arguments = array())
    {
        if (! method_exists($this->objectClass, $method))
            throw new InvalidArgumentException("Method {$method} does not exist in class {$this->objectClass}");

        $this->methodCalls[] = array($method, $arguments);

        return $this;
    }

    /**
     * Returns the method calls array
     *
     * @return array The method calls array
     */
    public function getMethodCalls()
    {
        return $this->methodCalls;
    }

    /**
     * Set the method calls array
     *
     * @param array $calls The method calls array
     *
     * @return ObjectInjection The current instance
     */
    public function setMethodCalls(array $calls)
    {
        $this->methodCalls = array();

        foreach ($calls as $call){
            list($methodName, $arguments) = $call;
            $this->addMethodCall($methodName, $arguments);
        }

        return $this;
    }
}
