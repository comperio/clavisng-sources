<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

class PatronStatusDiscriminator extends DataObjectDiscriminator
{
    private $forbiddenStates = array('C', 'B', 'R');

    protected $failedCondition = 'Utente non abilitato alla prenotazione. Contattare la propria biblioteca per maggiori informazioni';

    public function discriminate(DataObject $object)
    {
        $currentMember = Member::currentUser();

        if (!$currentMember)
            return 1;

        $status = $currentMember->UserData('PatronStatus');

        if (in_array($status, $this->getForbiddenStates()))
            return 0;

        return 1;
    }

    /**
     * Set ForbiddenStates
     *
     * @param array $forbiddenStates
     *
     * @return PatronStatusDiscriminator The current instance
     */
    public function setForbiddenStates(array $forbiddenStates)
    {
        $this->forbiddenStates = $forbiddenStates;

        return $this;
    }

    /**
     * Get ForbiddenStates
     *
     * @return array
     */
    public function getForbiddenStates()
    {
        return $this->forbiddenStates;
    }


}