<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class DataObjectDiscriminator
{
    const QUANTIFIER_NONE = 0;
    const QUANTIFIER_ATLEASTONE = 1;
    const QUANTIFIER_ALL = 2;

    /**
     * Specificities will be multiplied by this factor
     * @var int
     */
    private $factor = 10;

    /**
     * Store the conditions of the discriminator in the for
     * array(selector, value)
     *
     * @var array
     */
    private $conditions = array();

    /**
     * The array of the nested discriminators
     *
     * @var array
     */
    private $nestedDiscriminators = array();

    /**
     * Store the failed condition of the last call of discriminate
     *
     * @var
     */
    protected $failedCondition;

    /**
     * @param int @see $factor
     */
    public function __construct($factor = 10)
    {
        $this->factor = 10;
    }

    /**
     * @param string|array $selector
     * @return int
     */
    public function getSelectorSpecificity($selector)
    {
        if (!is_array($selector)){
            $selector = array($selector);
        }

        return $this->factor * (count($selector) + 1);
    }

    /**
     * Add a condition to the discriminator
     *
     * @param $selector
     * @param $value
     * @param bool $include If set to false the condition works like a NOT operator
     * @param string $label a description of the condition
     *
     * @return DataObjectDiscriminator
     */
    public function addCondition($selector, $value, $include = true, $label = '')
    {
        $this->conditions[] = array($selector, $value, $include, $label);

        return $this;
    }

    /**
     * Add a nested discriminator
     *
     * @param $selector
     * @param DataObjectDiscriminator $discriminator
     * @param null|int $quantifier
     * @param string $label a Description of the condition
     *
     * @return DataObjectDescriminator The current instance
     */
    public function addNestedDiscriminator($selector, DataObjectDiscriminator $discriminator, $quantifier = null, $label = '')
    {
        if (!isset($quantifier))
            $quantifier = static::QUANTIFIER_ALL;

        $this->nestedDiscriminators[] = array($selector, $discriminator, $quantifier, $label);

        return $this;
    }

    /**
     * Add a nested condition
     *
     * @param $selector
     * @param $nestedSelector
     * @param $condition
     * @param int $quantifier
     * @param bool $include
     * @param string $label
     * @return DataObjectDiscriminator
     */
    public function addNestedCondition($selector, $nestedSelector, $condition, $quantifier = null, $include = true, $label = '')
    {
        $nestedDisc = new DataObjectDiscriminator($this->factor);
        $nestedDisc->addCondition($nestedSelector, $condition, $include);

        $this->addNestedDiscriminator($selector, $nestedDisc, $quantifier, $label);

        return $this;
    }

    /**
     * The heart of the discriminator. Returns 0 if one condition is not satisfied,
     * the sum of condition specificities otherwise
     *
     * @param DataObject $object
     *
     * @return int
     */
    public function discriminate(DataObject $object)
    {
        $specificity = 0;
        $this->failedCondition = false;

        foreach($this->conditions as $condition){
            list($selector, $value, $include, $label) = $condition;
            $condSpecificity = $this->getConditionSpecificity($object, $selector, $value, $include);

            if (0 === $condSpecificity) {
                $this->failedCondition = $label;
                return 0;
            }

            $specificity += $condSpecificity;
        }

        foreach($this->nestedDiscriminators as $selAndDisc){
            list($selector, $nestedDiscriminator, $quantifier, $label) = $selAndDisc;
            $condSpecificity = $this->getNestedSpecificity($object, $selector, $nestedDiscriminator, $quantifier);

            if (0 === $condSpecificity) {
                $this->failedCondition = $label;
                return 0;
            }

            $specificity += $condSpecificity;
        }

        return $specificity;
    }

    /**
     * Returns the last failed condition label
     *
     * @return string
     */
    public function getFailedCondition()
    {
        return $this->failedCondition;
    }

    /**
     * Get 0 if the condition does not match, selector specificity otherwise
     *
     * @param DataObject $object
     * @param $selector
     * @param $value
     * @param bool $include
     *
     * @return int
     */
    private function getConditionSpecificity(DataObject $object, $selector, $value, $include = true)
    {
        $objectValue = $this->getNestedValue($object, $selector);

        if (!is_array($value)) {
            $value = array($value);
        }

        $failed = (in_array($objectValue, $value) xor ($include));

        if($failed) {
            return 0;
        }

        return $this->getSelectorSpecificity($selector);
    }

    /**
     * @param $object
     * @param DataObjectDiscriminator $discriminator
     *
     * @param bool $include
     * @return int
     */
    private function getNestedSpecificity(DataObject $object, $selector, DataObjectDiscriminator $discriminator, $quantifier)
    {
        $value = $this->getNestedValue($object, $selector);

        if(!$value instanceof Traversable)
                {
                    $value = array($value);
                }

        //Will store the max of children specificities
        $specificity = 0;

        foreach ($value as $dataObject) {
	    if(is_null($dataObject)) break;
            if (is_string($dataObject)) break;

	    $pass = (($discriminator->discriminate($dataObject) > 0) xor ($quantifier == static::QUANTIFIER_NONE));
	    
            if ($pass) {
                $specificity = 1;
                if ($quantifier == static::QUANTIFIER_ATLEASTONE) {
                    break;
                }
            } else {
                if ($quantifier != static::QUANTIFIER_ATLEASTONE) {
                    $specificity = 0;
                    break;
                }
            }
        }

        return $this->getSelectorSpecificity($selector) * $specificity;
    }

    /**
     * Access to nested fields in a dataobject
     *
     * @param DataObject $object
     * @param string|array $keys
     * @return null|mixed null if nothing is found
     */
    private function getNestedValue(DataObject $object, $keys)
    {
        if(!is_array($keys))
            $keys = array($keys);

        if (!$keys)
            return $object;

        if (1 === count($keys)) {
            $fieldName = $keys[0];
            return isset($object->$fieldName) ? $object->$fieldName : null;
        } else {
            $currFieldName = array_shift($keys);
            if (isset($object->$currFieldName)){
                return $this->getNestedValue(
                    $object->$currFieldName, $keys
                );
            }
        }
    }

}
