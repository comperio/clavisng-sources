<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

class RatingController extends Page_Controller
{
    public static $url_handlers = array(
        'rate/$Type/$RatedType/$RatedId/$Value' => 'rate',
        'unrate/$Type/$RatedType/$RatedId' => 'unrate',
    );

    /**
     * Returns a SS_HTTPResponse with mime type application/json and with body
     * set to json_encode($data)
     *
     * @param array $data the data to json_encode
     * @return SS_HTTPResponse
     */
    public function serveJsonResponse($data)
    {
        $response = new SS_HTTPResponse(json_encode($data));
        $response->addHeader("Content-type", "application/json");

        return $response;
    }


    /**
     * Action to rate an object
     *
     * @param SS_HTTPRequest $request
     * @return string The json of the response
     */
    public function rate(SS_HTTPRequest $request)
    {
        /** @var $ratingService RatingService */
        $ratingService = static::$container->get('rating.service');

        $response = array();

        try {
            $ratingService->rate(
                Member::currentUser(),
                RatingType::get_by_name($request->param('Type')),
                $request->param('Value'),
                $request->param('RatedType'),
                $request->param('RatedId')
            );
        } catch (RatingException $e) {
            $response['error'] = _t('Rating.ERROR_' . $e->getCode(), $e->getMessage());
            $response['error_title'] = _t('Liquens.ERROR', 'Error');
        }

        return $this->serveJsonResponse($response);
    }

    /**
     * Action to unrate an object
     *
     * @param SS_HTTPRequest $request
     * @return string The json of the response
     */
    public function unrate(SS_HTTPRequest $request)
    {
        /** @var $ratingService RatingService */
        $ratingService = static::$container->get('rating.service');

        $response = array();

        try {
            $ratingService->unrate(
                Member::currentUser(),
                RatingType::get_by_name($request->param('Type')),
                $request->param('RatedType'),
                $request->param('RatedId')
            );
        } catch (RatingException $e) {
            $response['error'] = _t($e->getMessage(), 'Rating.ERROR_' . $e->getCode());
            $response['error_title'] = _t('Liquens.ERROR', 'Error');
        }

        return $this->serveJsonResponse($response);
    }
}
