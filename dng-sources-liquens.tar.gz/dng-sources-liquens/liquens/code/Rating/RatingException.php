<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class RatingException extends Exception
{
    const UNLOGGED = 0;
    const INVALID_VALUE_FOR_TYPE = 1;
}
