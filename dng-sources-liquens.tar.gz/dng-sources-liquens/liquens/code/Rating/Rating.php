<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class Rating extends DataObject
{
    static $db = array(
        'Value' => 'Decimal',
        'RatedType' => 'Varchar',
        'RatedId' => 'VarChar',
    );

    static $indexes = array(
        'RatedObject' => '(RatedType, RatedId, Value)',
        'RaterID' => true,
        'RatingTypeID' => true
    );

    static $has_one = array(
        'Rater' => 'Member',
        'RatingType' => 'RatingType'
    );

    /**
     * Factory method to get a rating
     *
     * @static
     * @param Member $rater
     * @param RatingType $type
     * @param $ratedType
     * @param $ratedId
     * @return DataObject
     */
    static function get_rating(Member $rater, RatingType $type, $ratedType, $ratedId)
    {
        if (!$rater)
            return false;

        $filter = sprintf("RaterID = %d AND RatingTypeID = %d AND RatedType = '%s' AND RatedId = '%s'",
            $rater->ID,
            $type->ID,
            Convert::raw2sql($ratedType),
            Convert::raw2sql($ratedId)
        );

        return DataObject::get_one(get_class(), $filter);
    }

    /**
     * Factory method to get a list of ratings of a certain user and of a certain type
     *
     * @static
     * @param Member $rater
     * @param RatingType $type
     * @param $ratedType
     * @param array $ratedIds
     * @return bool|mixed
     */
    static function get_ratings(Member $rater, RatingType $type, $ratedType, $ratedIds = array())
    {
        if (!$rater)
            return false;

        $filter = sprintf("RaterID = %d AND RatingTypeID = %d AND RatedType = '%s'",
            $rater->ID,
            $type->ID,
            Convert::raw2sql($ratedType)
        );

        //Add a condition that RatedId is in $rateIds
        if ($ratedIds) {
            $idsSafes = array_map(
                function($id){
                    return "'" . Convert::raw2sql($id) . "'";
            }, $ratedIds);
            $idsCondition = "(" . implode(", ", $idsSafes) . ")";
            $filter .= ' AND RatedId IN ' . $idsCondition;
        }

        return DataObject::get(get_class(), $filter);
    }
}
