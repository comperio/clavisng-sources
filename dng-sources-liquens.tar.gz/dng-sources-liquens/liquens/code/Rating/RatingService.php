<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class RatingService
{
    /** @var String */
    public $ratingClass;

    /**
     * Constructor-injection for rating class
     *
     * @param string $ratingClass
     */
    public function __construct($ratingClass = 'Rating')
    {
        $this->ratingClass = 'Rating';
    }

    /**
     * @param Member $rater
     * @param \RatingType $type
     * @param int $value
     * @param string $ratedType
     * @param string $ratedId
     * @return \Rating
     */
    public function rate(Member $rater, RatingType $type, $value, $ratedType, $ratedId)
    {
        if (!$rater)
            throw new RatingException("Invalid Member", RatingException::UNLOGGED);

        if($type->isValid($value)){
            $rating = $this->getRating($rater, $type, $ratedType, $ratedId);
            $rating->Value = $value;

            $rating->write();
        }
        else {
            throw new RatingException('Invalid rating value for rating type ' . $type->Name, RatingException::INVALID_VALUE_FOR_TYPE);
        }

        return $rating;
    }

    /**
     * Cancel a rating
     *
     * @param Member $rater
     * @param RatingType $type
     * @param string $ratedType
     * @param string $ratedId
     * @return RatingService
     */
    public function unrate(Member $rater, RatingType $type, $ratedType, $ratedId)
    {
        $ratingClassName = $this->ratingClass;

        if ($rating = $ratingClassName::get_rating($rater, $type, $ratedType, $ratedId))
            $rating->delete();

        return $this;
    }

    /**
     * @return Rating
     */
    public function getNewRating()
    {
        $className = $this->ratingClass;
        return new $className();
    }

    /**
     * Returns an existing rating with the field specified
     * or a new rating with the field filled as specified
     *
     * @param Member $rater
     * @param RatingType $type
     * @param $ratedType
     * @param $ratedId
     * @return Rating
     */
    public function getRating(Member $rater, RatingType $type, $ratedType, $ratedId)
    {
        if (!$rater)
            return false;

        $ratingClassName = $this->ratingClass;

        if ($result = $ratingClassName::get_rating($rater, $type, $ratedType, $ratedId))
            $rating = $result;
        else
            $rating = $this->getNewRating();

        $rating->RaterID = $rater->ID;
        $rating->RatingTypeID = $type->ID;
        $rating->RatedType = $ratedType;
        $rating->RatedId = $ratedId;

        return $rating;
    }

    /**
     * Returns a Set of ratings performed by a certain member and of a certain RatingType
     *
     * @param Member $rater
     * @param RatingType $type
     * @param $ratedType
     * @param array $ratedIds
     * @return bool|DataObjectSet
     */
    public function getRatings(Member $rater = null, RatingType $type, $ratedType, array $ratedIds = array())
    {
        if (!$rater)
            return false;

        $ratingClassName = $this->ratingClass;

        return $ratingClassName::get_ratings($rater, $type, $ratedType, $ratedIds);
    }

    /**
     * Get rating average
     *
     * @param RatingType $type
     * @param $ratedType
     * @param $ratedId
     * @return string
     */
    public function getRatingInfos(RatingType $type, $ratedType, $ratedId)
    {
        $infos = $this->getRatingsInfos($type, $ratedType, array($ratedId));

        return reset($infos);
    }

    /**
     * Get rating avarage of a set of rated objects with the same ratedType.
     * Return value is an array of the form
     * <code>
     * array(
     *  'ratedId1' => array(
     *      'average' => ratingaverage1,
     *      'count' => totalratings1
     *  ),
     *  'ratedId2' => array(
     *      'average' => ratingaverage2,
     *      'count' => totalratings2
     *  ),
     *  ...
     * );
     * </code>
     * @param RatingType $type
     * @param $ratedType
     * @param array $ratedIds
     * @return array
     */
    public function getRatingsInfos(RatingType $type, $ratedType, array $ratedIds)
    {
        if (!count($ratedIds))
            return array();

        $sqlQuery = new SQLQuery();
        $tableClasses = ClassInfo::dataClassesFor($this->ratingClass);
        $table = $tableClasses[0];

        $quotedRatedIds = array_map(function($ratedId){
                return "'".Convert::raw2sql($ratedId)."'";
        }, $ratedIds);
        $ratedIdsCommaSeparatedList = implode(', ', $quotedRatedIds);

        $sqlQuery->from = array("$table t");
        $sqlQuery->select = array(
            'AVG(Value) AS average',
            'Count(*) AS count',
            'RatedType',
            'RatedId',
        );
        $sqlQuery->where = array(
            "RatingTypeID = '{$type->ID}'",
            "RatedType = '$ratedType'",
            "RatedId IN ($ratedIdsCommaSeparatedList)"
        );
        $sqlQuery->groupby('RatedId');

        $queryResults =  $sqlQuery->execute();

        $ratingInfos = array();

        foreach($queryResults as $row){
            $ratingInfos[$row['RatedId']] = array(
                'average' => $row['average'],
                'count' => $row['count']
            );
        }

        return $ratingInfos;
    }

}
