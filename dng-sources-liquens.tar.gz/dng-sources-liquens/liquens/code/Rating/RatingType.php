<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class RatingType extends DataObject
{
    public static $db = array(
        'Name' => 'Varchar',
        'Min' => 'DBInt',
        'Max' => 'DBInt',
        'Step' => 'Decimal'
    );

    public static $indexes = array(
        'Name' => 'unique (Name)',
    );

    public static $defaults = array(
        'Min' => 0,
        'Max' => 5,
        'Step' => 1
    );

    /**
     * Factory method to get a type by name
     * @static
     * @param string $name
     * @return Rating
     */
    public static function get_by_name($name)
    {
        $name = Convert::raw2sql($name);

        return DataObject::get_one(get_called_class(), "Name = '$name'");
    }

    /**
     * Check if a rating value is valid for this type of rating
     *
     * @param $value
     * @return bool
     */
    public function isValid($value)
    {
        if (
            $value >= $this->Min
            && $value <= $this->Max
            && $this->isInStep($value)
        )
            return true;

        return false;
    }

    /**
     * Check if the value is in a valid step
     *
     * @param $value
     * @return bool
     */
    private function isInStep($value)
    {
        $normalized = $value - $this->Min;
        $ratio = $normalized / $this->Step;

        return (int)($ratio) == $ratio;
    }

    /**
     * Build default rating types
     */
    public function requireDefaultRecords() {
        //Stars

        if (!static::get_by_name('star')){
            $ratingType = new RatingType();
            $ratingType->Name = 'star';
            $ratingType->Min = 0;
            $ratingType->Max = 5;
            $ratingType->Step = 1;
            $ratingType->write();
        }

        //Likes
        if (!static::get_by_name('like')){
            $ratingType = new RatingType();
            $ratingType->Name = 'like';
            $ratingType->Min = 0;
            $ratingType->Max = 1;
            $ratingType->Step = 1;
            $ratingType->write();
        }
    }
}
