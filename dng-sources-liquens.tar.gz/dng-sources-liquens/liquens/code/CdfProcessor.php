<?php
/*
 * This file is part of dng-git.
 *
 * (c) 2012 Nicolò Martini
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */
/**
 *
 */
class CdfProcessor
{
    /**
     * @var array
     */
    private $fieldSpecifications;

    /**
     * @var CdfMapInterface
     */
    private $cdfMap;

    /**
     * Chars to be considered as empty positions
     *
     * @var string
     */
    private $trimChars = " |";

    /**
     * Factory method. Load specifications fron db
     *
     * @return CdfProcessor
     */
    public static function build_from_db()
    {
        $query = sprintf(
            "SELECT * FROM unimarc_codes_bonified WHERE language = '%s' GROUP BY field_number, subfield_tag, pos",
            Convert::raw2sql(i18n::get_locale())
        );

        $processor = new CdfProcessor();

        foreach (DB::query($query) as $row) {
            $processor->addFieldSpecification(
                $row['field_number'],
                $row['subfield_tag'],
                $row['pos'],
                $row['field_length'],
                $row['repetibility']
            );
        }

        return $processor;
    }

    /**
     * Construct the instance
     * @param array $fieldsSpecifications The array of fields specifications. @see CdfProcessor::addFieldSpecification
     * @param CdfMapInterface $cdfMap
     */
    public function __construct($fieldsSpecifications = array(), CdfMapInterface $cdfMap = null)
    {
        foreach ($fieldsSpecifications as $fieldSpec) {
            $this->addFieldSpecification($fieldSpec[0], $fieldSpec[1], $fieldSpec[2], $fieldSpec[3], $fieldSpec[4]);
        }

        if ($cdfMap === null)
            $cdfMap = new CdfMap;

        $this->cdfMap = $cdfMap;
        $this->fieldSpecifications = $fieldsSpecifications;
    }

    /**
     * Add a field specifications. It tells the processor how to encode a field
     *
     * @param string $field                The unimarc field
     * @param string $subfield             The unimarc subfield
     * @param int $position                The position in the field
     * @param int $length                  The length of the data chunk
     * @param int $repetibility            The repeatibility of the field
     * @return CdfProcessor
     */
    public function addFieldSpecification($field, $subfield, $position, $length = 1, $repetibility = 1)
    {
        $this->fieldSpecifications[$field][$subfield][$position] = array($length, $repetibility);

        return $this;
    }

    /**
     * Get FieldSpecifications
     *
     * @return array
     */
    public function getFieldSpecifications()
    {
        return $this->fieldSpecifications;
    }

    /**
     * Trasform an encoded field to a structured field
     * Return value is of the form
     * <code>
     * [
     *    position1 => [val1, val2, val3],
     *    position2 => [val1, val2, ...],
     *    ...
     * ]
     * </code>
     * @param string $encodedField      The encoded field string
     * @param string $fieldName         The unimarc field name
     * @param string $subfieldName      The subfield name
     * @return array                    The normalized field
     * @throws InvalidArgumentException
     */
    public function process($encodedField, $fieldName, $subfieldName)
    {
        if (!isset($this->fieldSpecifications[$fieldName][$subfieldName]))
            throw new InvalidArgumentException(sprintf(
                'There is no specification for field %s, subfield %s',
                $fieldName, $subfieldName
            ));

        $specification = $this->fieldSpecifications[$fieldName][$subfieldName];
        $processed = array();

        foreach ($specification as $position => $specs) {
            $position = (int) $position;
            list($length, $repeat) = $specs;
            $length = (int) $length;
            if (!$length)
                continue;

            $encodedValues = $this->getEncodedValues($encodedField, (int) $position, (int) $length, (int) $repeat);

            if ($encodedValues)
                $processed[$position] = $this->getEncodedValues($encodedField, (int) $position, (int) $length, (int) $repeat);
        }

        $processed = $this->postProcess($fieldName, $subfieldName, $processed);
        ksort($processed);

        return $processed;
    }

    /**
     * Transform a processed field to a nested arrays of localized labels.
     * It uses the CdfMap
     * It returns an array of the form
     * <code>
     * [
     *    fieldLabel => [
     *      subfieldlabel => [
     *          positionlabel => [
     *              valuelabel1, valuelabel2, ...
     *          ], ...
     *      ]
     * ]
     * </code>
     *
     * @param string $processedField    The field already processed by CdfProcessor::process()
     * @param string $fieldName         The name of the field
     * @param string $subfieldName      The name of the subfield
     * @return array
     */
    public function toLabels($processedField, $fieldName, $subfieldName)
    {
        $labels = array();

        foreach ($processedField as $position => $values) {
            foreach ($values as $value) {
                $row = $this->cdfMap->valueToLabels($fieldName, $subfieldName, $position, $value);
                if ($row) {
                    $value = $row['value_label'];
                } else {
                    $row = $this->cdfMap->valueToLabels($fieldName, $subfieldName, $position);
                }

                $labels
                    [ucfirst($row['field_label'])]
                    [ucfirst($row['subfield_label'])]
                    [ucfirst($row['position_label'])]
                    [] = $value
                ;
            }
        }

        return $labels;
    }

    /**
     * @param $encodedField
     * @param $position
     * @param int $length
     * @param int $repeat
     * @return array
     */
    private function getEncodedValues($encodedField, $position, $length = 1, $repeat = 1)
    {
        $values = array();
        for ($repeatIndex = 1; $repeatIndex <= $repeat; $repeatIndex++) {
            $value = trim(substr($encodedField, $position + ($repeatIndex - 1) * $length, $length), $this->trimChars);
            if ($value)
                $values[] = $value;
        }

        return $values;
    }

    /**
     * Some adjustment in the processed field in order to normalize some fields
     *
     * @param string $fieldName
     * @param string $subfieldName
     * @param array $processedField
     * @return mixed
     */
    private function postProcess($fieldName, $subfieldName, $processedField)
    {
        if ($fieldName == '100' && $subfieldName == 'a') {
             //Process data field when two dates are given
            //See UNIMARC documentation for field 100
            if (isset($processedField[8][0]) && $processedField[8][0] == 'j' && isset($processedField[13][0])) {
                $month = substr($processedField[13][0], 0, 2);
                $day = substr($processedField[13][0], 2, 2);
                if (isset($processedField[9][0])) {
                    $processedField[9][0] = $day .'-' . $month . '-' . $processedField[9][0];
                    unset($processedField[13][0]);
                }
            } elseif (isset($processedField[13][0])) {
                if (isset($processedField[9][0])) {
                    $processedField[9][0] .= '-' . $processedField[13][0];
                    unset($processedField[13][0]);
                }
            }

            //Remove "not a government publication" from cdfs
            if (isset($processedField[20]) && $processedField[20][0] == 'y') {
                unset($processedField[20]);
            }
        }

        return $processedField;
    }
}
