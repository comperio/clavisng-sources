<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class MostCommentedShelf extends ManifestationsShelf
{

    function __construct($record = null, $isSingleton = false)
    {
        parent::__construct($record, $isSingleton);

        $this->applyBoostToPreserveOrder = true;
    }

    /**
     * @param int $start
     * @param null $limit
     * @return array
     */
    public function getManifestationsIds($start = 0, $limit = null)
    {
        if ($limit === null)
            $limit = 100;

        $query = "
            SELECT ManifestationID,
              COUNT(*) AS CommentCount
            FROM Post
            WHERE ManifestationID IS NOT NULL
            GROUP BY ManifestationID
            ORDER BY CommentCount DESC, Created DESC
            LIMIT $start,$limit
        ";

        return DB::query($query)->column('ManifestationID');
    }

    public function isSortable()
    {
        return false;
    }
}
