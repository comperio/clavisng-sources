<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class MyLoansShelf extends ManifestationsListShelf
{
    /** @var LiquensConnector */
    private $connector;

    /**
     * Store an array of all manifestation ids of the shelf
     *
     * @var array
     */
    private $manifestationIdsCache;

    /**
     * Set the external id of the shelf in the external source
     *
     * @param $id
     */
    public function setType($type)
    {
        $this->setDataValue('type', $type);

        return $this;
    }

    /**
     * Set the connector used to retrieve the manifestation ids
     *
     * @param LiquensConnector $connector
     */
    public function setConnector(LiquensConnector $connector)
    {
        $this->connector = $connector;

        return $this;
    }

    /**
     * Returns the array of manifestations ids contained in this shelf
     *
     * @return array
     */
    public function getManifestationsIds($start = 0, $limit = null)
    {
        if ($limit === null)
            $limit = LQConfig::get('max_shelf_items');

        return array_slice($this->getAllManifestationsIds(), $start, $limit);
    }

    /**
     * @return array
     */
    private function getAllManifestationsIds()
    {
        if (!isset($this->manifestationIdsCache)){
            if (!isset($this->connector)){
                global $sc;
                $connector = $sc->get('liquens.connector');
                $this->setConnector($connector);
            }

            $ids = $this->connector->getPatronActiveLoans(Member::currentUser()->getUsername());

            $ids = array_map(function($data){
                return $data['ManifestationId'];
            }, $ids);

            $connector = $this->connector;

            $this->manifestationIdsCache = array_map(function($id) use ($connector) {
                    return $connector->getSolrDatabase() . ':' .
                    $connector->getSolrCatalog() . ':' .
                    $id;
            }, $ids);
        }

        return $this->manifestationIdsCache;
    }

    /**
     * If there is an external_title, override the title with that
     *
     * @return mixed|string
     */
    public function getTranslatedTitle()
    {
        $type = $this->getDataValue('type');
        return _t('Shelf.MYLOANS_' . strtoupper($type), $type);
    }

    /**
     * @return string
     */
    public function getTranslatedDescription()
    {
        $type = $this->getDataValue('type');

        return _t('Shelf.MYLOANS_' . strtoupper($type) . '_DESC', $type);
    }

    public function isSortable()
    {
        return true;
    }
}

