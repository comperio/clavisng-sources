<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class RatingShelf extends ManifestationsListShelf
{
    /**
     * The minimum number of rating of a manifestation to be included in the shelf
     *
     * @var int
     */
    public $minimumRating = 2;

    function __construct($record = null, $isSingleton = false)
    {
        parent::__construct($record, $isSingleton);

        $this->applyBoostToPreserveOrder = true;
    }

    /**
     * @param int $start
     * @param null $limit
     * @return array
     */
    public function getManifestationsIds($start = 0, $limit = null)
    {
        if ($limit === null)
            $limit = 100;

        $query = "
            SELECT RatedId    AS ManifestationID,
                   Avg(VALUE) AS AverageRating,
                   COUNT(*)   AS TotalRating
            FROM   Rating
            WHERE  RatedType = 'Manifestation'
            GROUP  BY RatedId
            HAVING COUNT(*) >= {$this->minimumRating}
            ORDER  BY AverageRating DESC, TotalRating DESC
            LIMIT $start,$limit
        ";

        return DB::query($query)->column('ManifestationID');
    }

    public function isSortable()
    {
        return false;
    }
}
