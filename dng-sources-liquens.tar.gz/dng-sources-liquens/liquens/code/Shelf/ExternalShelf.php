<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class ExternalShelf extends QueryShelf
{
    /**
     * @param $id
     * @return ExternalShelf
     */
    public static function get_by_external_id($id)
    {
        //Legacy shelf name
        $name = 'CLAVISConnector:' . $id;
        $class = get_called_class();

        $shelf = DataObject::get_one($class, sprintf("Name = '%s'", Convert::raw2sql($name)));

        if (!$shelf){
            $shelf = new $class;
            $shelf->setExternalId($id);
        }

        return $shelf;
    }
    /**
     * Set the external id of the shelf in the external source
     *
     * @param $id
     *
     * @return $this
     */
    public function setExternalId($id)
    {
        $this->setDataValue('external_id', $id);

        return $this;
    }

    public function getQuery()
    {
        return 'mrc_d907_s3:' . $this->getDataValue('external_id');
    }


    /**
     * Automatically set Name field on write. The name will be ConnectorClassName:ExternalShelfId
     *
     * @param bool $showDebug
     * @param bool $forceInsert
     * @param bool $forceWrite
     * @param bool $writeComponents
     * @return int
     */
    public function write($showDebug = false, $forceInsert = false, $forceWrite = false, $writeComponents = false)
    {
        if (! $this->Name)
            $this->Name = __CLASS__ . ':' . $this->getDataValue('external_id');

        return parent::write($showDebug, $forceInsert, $forceWrite, $writeComponents);
    }

    /**
     * If there is an external_title, override the title with that
     *
     * @return mixed|string
     */
    public function getTranslatedTitle()
    {
        if ($this->getDataValue('external_title'))
            return $this->getDataValue('external_title');

        return parent::getTranslatedTitle();
    }

    public function getTranslatedDescription()
    {
        if ($this->getDataValue('external_description'))
            return $this->getDataValue('external_description');

        return parent::getTranslatedDescription();
    }

    public function isSortable()
    {
        return true;
    }
    
    /**
     * Pulizia dei doppioni in Shelf mantenendo quello con ID più alto legato a ShelfWidget
     * Update dei record legati agli Shelf (da verificare)
     */
//    public function onAfterWrite() {
//        $biggestId = DB::query("SELECT ID FROM Shelf WHERE `Name` LIKE '".Convert::raw2sql($this->Name)."' ORDER BY ID DESC LIMIT 0 , 1")->value();
//        $sql = "SELECT ID, SerializedData FROM Shelf WHERE `Name` LIKE '".Convert::raw2sql($this->Name)."' AND ID NOT LIKE ($biggestId)";
//        $othersId = DB::query($sql);
//        foreach ($othersId as $otherId) {
//            $data = unserialize($otherId['SerializedData']);
//            $test = DB::query("SELECT ID FROM ShelfWidget WHERE `Shelfref` LIKE 'persistent:".$otherId['ID'].":".$data['library_id']."'")->value();
//            if ($test) { DB::query("UPDATE ShelfWidget SET `ShelfRef`= 'persistent:".$biggestId.":".$data['library_id']."'"." WHERE ID LIKE ".$test); }
//            DB::query("DELETE FROM Shelf WHERE `ID` = ".Convert::raw2sql($otherId['ID']));
//        }
//        parent::onAfterWrite();
//    }    
}

