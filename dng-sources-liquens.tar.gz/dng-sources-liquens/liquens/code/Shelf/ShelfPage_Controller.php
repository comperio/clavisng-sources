<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class ShelfPage_Controller extends SearchPage_Controller
{
    /**
     *
     */
    const MAX_RESULTS_IN_SAVED_SEARCH = 200;

    /**
     * @var array
     */
    public static $url_handlers = array(
        'add/$ManifestationId/$ShelfId' => 'addToShelf',
        'remove/$ManifestationId/$ShelfId' => 'removeFromShelf',
        //This must be before the following one!
        'view/$ShelfRef!/$ViewType!/facetsnav' => 'facetsnav',
        'view/$ShelfRef!/$ViewType' => 'viewShelf',
        'changevisibility/$ShelfId/$Visibility' => 'changeVisibility',
        'empty/$ShelfId' => 'emptyShelf',
        'edit/$ShelfId' => 'editShelf',
        'delete/$ShelfId' => 'deleteShelf',
        'deletes/$ShelfId' => 'deleteSearch',
        'manifestation/$ManifestationId!/shelves' => 'getManifestationShelves',
        'savesearch' => 'saveSearch',
        'putresultsinshelf' => 'putResultsInShelf',
        'updateCSDropDown' => 'updateCSDropDown',
        'checkbox' => 'checkbox',
        'selectOption' => 'selectOption',
        'shelf-dialog/$ShelfId' => 'shelfDialog',
        'search-dialog' => 'searchDialog',
        'savesearch-button' => 'savesearchButton',
        'mlolActiveOnSystem' => 'mlolActiveOnSystem'
    );
    
    public static $allowed_actions = array(
        'addToShelf',
        'removeFromShelf',
        'facetsnav',
        'viewShelf',
        'changeVisibility',
        'emptyShelf',
        'editShelf',
        'deleteShelf',
        'deleteSearch',
        'getManifestationShelves',
        'saveSearch',
        'putResultsInShelf',
        'updateCSDropDown',
        'checkbox',
        'selectOption',
        'shelfDialog',
        'searchDialog',
        'savesearchButton',
        'mlolActiveOnSystem'
    );

    public function getSensitiveTitle()
    {
        return $this->Title;
    }
    
    
    /**
     *
     */
    public function init()
    {
        parent::init();
        if(Director::is_ajax() || isset($_GET["ajaxDebug"])) {
            $this->isAjax = true;
        } else {
            $this->isAjax = false;
        }
    }

    /**
     * Get the list of bibliographic records
     * by a Solr request
     *
     * @return page rendering
     */
    public function search()
    {
        $data = $this->getResults();

        return $this->customise($data)->renderWith(array('ShelfPage_search', 'SearchPage_search', 'Page'));
    }
    
    private $urlShelf = null;
    
    /**
     * {@inheritdoc}
     */
    public function getSolrQueryObject($getFacets = true, $type = null)
    {
        /** @var $query SolrQuery */

        $query = parent::getSolrQueryObject($getFacets, $type);

        // Filtro per loansince
        if      (!is_null($this->urlShelf) && 
                (!empty(explode(":",$this->urlShelf->param('ShelfRef'))[1])) && 
                (isset(explode(":",$this->urlShelf->param('ShelfRef'))[1])) &&
                (explode(":",$this->urlShelf->param('ShelfRef'))[1] == "loanable_since")) {
            global $sc;
            if (apc_exists("LoanSinceShelf_".explode(":",$this->urlShelf->param('ShelfRef'))[3])) {
                $query->setMainQuery(unserialize(apc_fetch("LoanSinceShelf_".explode(":",$this->urlShelf->param('ShelfRef'))[3])));
            }
        }
        
        $this->dataRecord->Shelf()->fillSolrQuery($query, $this->StartPos() - 1, $this->PageSize());

        if ($sortField = $this->getCurrentSorting()){
            $query->setRawField('sort', LQConfig::get('sortFields', $sortField, 'rule'));
        }

        return $query;
    }

    /**
     * @return string
     */
    public function getCurrentSorting()
    {
        $sortField = parent::getCurrentSorting();

        if (!$sortField){
            $shelf = $this->dataRecord->Shelf();
            if ($shelf->getDataValue('sort'))
                return $shelf->getDataValue('sort');
        }

        return $sortField;
    }

    /**
     * @return DataObjectSet
     */
    public function getActiveFilters()
    {
        $filters = new MapperSearchFilters($this->getSolrQueryMapper(), $this->getActiveFiltersUrlPrefix());

        return $filters->getFilters();
    }

    /**
     * Action to view a shelf
     *
     * @param SS_HTTPRequest $request
     * @return page
     * @throws Exception
     */
    public function viewShelf(SS_HTTPRequest $request) {
        $this->urlShelf = $request;
        $this->loadShelfPage($this->urlShelf);
        
        return $this->customise($this->dataRecord)->search();
    }
    
    /**
     * Crea meta opportuni per Facebook
     * 
     * @return type
     */
    public function MetaTags() {
        $tags = $this->arrayTags;
        unset($tags['og:description']);
        if ($this->dataRecord->Description != '')
            $tags['og:description'] = '<meta property="og:description" content="' . $this->dataRecord->Description . '" />';
        else
            $tags['og:description'] = '<meta property="og:description" content="' . $this->dataRecord->Title . '" />';
        return join('', $tags);
    }

    /**
     * @param \SS_HTTPRequest $request
     * @return string
     */
    public function facetsnav(SS_HTTPRequest $request)
    {
        if (! ($this->dataRecord->ID > 0)){
            $this->loadShelfPage($request);
        }
        return parent::facetsnav($request);
    }


    /**
     * Construct the url of the shelf
     *
     * @param bool $viewType
     * @param bool $action
     * @return string
     */
    public function getSearchBaseUrl($viewType = false, $action = false)
    {
        if ($this->dataRecord->ID > 0){
            return parent::getSearchBaseUrl($viewType, $action);
        } else {
            if (false === $viewType)
                $viewType = $this->getViewType();
            $shelfRef = $this->dataRecord->Shelf()->ShelfRef;

            $url = "shelf/view/$shelfRef/$viewType";

            return Director::absoluteURL($url, true);
        }
    }


    /**
     * Action to add a manifestation to a shelf
     *
     * @param SS_HTTPRequest $request
     * @return mixed
     */
    public function addToShelf(SS_HTTPRequest $request)
    {
        return $this->processShelfAction($request, function(SS_HTTPRequest $request, ManifestationsShelf $shelf, ShelfPage_Controller $controller){
            $shelf->addManifestationId($request->param('ManifestationId'));
            return array('MessageType' => 'Success', 'Message' => _t('ProfilePage.SHELFADDITEM_SUCCESS'));
        });
    }

    /**
     * Action to remove a manifestation from a shelf
     *
     * @param SS_HTTPRequest $request
     * @return mixed
     */
    public function removeFromShelf(SS_HTTPRequest $request)
    {
        return $this->processShelfAction($request, function(SS_HTTPRequest $request, ManifestationsShelf $shelf, ShelfPage_Controller $controller){
            $shelf->removeManifestationId($request->param('ManifestationId'));
            return array('MessageType' => 'Success', 'Message' => _t('ProfilePage.SHELFDELETEITEM_SUCCESS'));
        });
    }

    /**
     * @param SS_HTTPRequest $request
     */
    public function changeVisibility(SS_HTTPRequest $request)
    {
        return $this->processShelfAction($request, function(SS_HTTPRequest $request, ManifestationsShelf $shelf, ShelfPage_Controller $controller){
            $shelf->Visibility = $request->param('Visibility');
        });
    }

    /**
     * @param SS_HTTPRequest $request
     */
    public function emptyShelf(SS_HTTPRequest $request) {
        return $this->processShelfAction($request, function(SS_HTTPRequest $request, ManifestationsShelf $shelf, ShelfPage_Controller $controller){
            $shelf->emptyShelf();
            $shelfD = DataObject::get_by_id('Shelf', $request->param('ShelfId'));
            $shelfD->SerializedData = 'N;';
            $shelfD->write();
        });
    }

    /**
     * @param SS_HTTPRequest $request
     * @throws Exception
     */
    public function deleteShelf(SS_HTTPRequest $request)
    {
        return $this->processShelfAction($request, function(SS_HTTPRequest $request, ManifestationsShelf $shelf, ShelfPage_Controller $controller){
            if ($shelf->isDefault())
                throw new Exception('Default shelves cannot be deleted');

            $controller->addMessage(
                'Success',
                _t('ProfilePage.SHELFDELETE_SUCCESS','Shelf successfully deleted.')
            );
        }, true);
    }

    /**
     * @param SS_HTTPRequest $request
     * @throws Exception
     */
    public function deleteSearch(SS_HTTPRequest $request)
    {
        return $this->processShelfAction($request, function(SS_HTTPRequest $request, MappedSearchShelf $shelf, ShelfPage_Controller $controller){
            if ($shelf->isDefault())
                throw new Exception('Default shelves cannot be deleted');

            $controller->addMessage(
                'Success',
                _t('ProfilePage.SHELFDELETE_SUCCESS','Shelf successfully deleted.')
            );
        }, true);
    }
    
    /**
     * @param SS_HTTPRequest $request
     * @throws Exception
     */
    public function putResultsInShelf(SS_HTTPRequest $request)
    {
        $member = Member::currentUser();
        if (!$member)
            throw new Exception('Only logged members can create a shelf');

        $shelf = DataObject::get_by_id('Shelf', $request->postVar('ShelfId'));

        if(!$shelf)
            throw new Exception('The shelf does not exist');
        if (! $this->memberIsOwner($shelf))
            throw new Exception('Current Member is not the owner of the Shelf');

        $mapperClass = $request->postVar('Type') == 'simple' ? 'SolrSimpleQueryMapper' : 'SolrQueryMapper';

        //Construct a searchshelf only to retrieve the manifestations ids
        $searchShelf = new MappedSearchShelf();
        $searchShelf
            ->setMapperClass($mapperClass)
            ->loadByQueryString(urldecode($request->postVar('SearchQueryString')))
        ;

        $query = new SolrQuery();
        $query->addFilterQuery(LQConfig::get('global_search_filter'));
        $searchShelf->setStartQuery($query);

        $shelf->addManifestationsIds($searchShelf->getManifestationsIds(0, static::MAX_RESULTS_IN_SAVED_SEARCH));
        $shelf->write();

        $this->addMessage('Success', _t('Profile.SEARCHADD_SUCCESS', 'Search successfully saved'));

        if ($request->getVar('goback')){
            $this->redirectBack();
        }
    }

    /**
     * @param SS_HTTPRequest $request
     * @throws Exception
     */
    public function editShelf(SS_HTTPRequest $request)
    {
        $member = Member::currentUser();
        if (!$member)
            throw new Exception('Only logged members can manageshelves');

        if (!$shelf = DataObject::get_by_id('Shelf', (int) $request->param('ShelfId'))) {
            $shelf = new ManifestationsShelf();
            $shelf->OwnerID = $member->ID;
        }
        $shelf->Visibility = $request->postVar('visibility');
        $shelf->Name = $request->postVar('name');
        $shelf->Description = $request->postVar('description');

        $shelf->write();
        $response = array('ShelfID' => $shelf->ID, 'MessageType' => 'Success', 'Message' => _t('Profile.SHELFADD_SUCCESS', 'Shelf successfully added'));

        return $this->flushResponse($request, $response);
    }

    /**
     * Action that handle a saved search request
     *
     * @param SS_HTTPRequest $request
     * @throws Exception
     */
    public function saveSearch(SS_HTTPRequest $request)
    {
        $member = Member::currentUser();
        if (!$member)
            throw new Exception('Only logged members can create a shelf');

        $mapperClass = $request->postVar('type') == 'simple' ? 'SolrSimpleQueryMapper' : 'SolrQueryMapper';

        if ($request->postVar('id')) {
            $shelf = DataObject::get_by_id('MappedSearchShelf', (int) $request->postVar('id'));
            if (!$this->memberIsOwner($shelf))
                throw new Exception('Current Member is not the owner of the Shelf');
        } else {
            $shelf = new MappedSearchShelf();
        }

        if(!$shelf)
            throw new Exception('The shelf does not exist');

        $shelf->OwnerID = $member->ID;

        if (!is_null($request->postVar('visibility')))
            $shelf->Visibility = $request->postVar('visibility');
        if (!is_null($request->postVar('name')))
            $shelf->Name = $request->postVar('name');
        if (!is_null($request->postVar('description')))
            $shelf->Description = $request->postVar('description');

        $shelf->setMapperClass($mapperClass);
        $shelf->loadByQueryString(urldecode($request->postVar('search-query-string')));
        $shelf->setDataValue('sort', $request->postVar('search-sort'));

        $searchPageId = (int) $request->requestVar('search-page-id');
        $shelf->setDataValue('search-page-id', $searchPageId);

        $searchPage = DataObject::get_by_id('SearchPage', $searchPageId);

        if ($searchPage && $searchPage->ForceAndQuery)
            $shelf->setSolrFilter($searchPage->ForceAndQuery);

        $shelf->write();

        $link = "<b><a href='shelf/view/{$shelf->ID}/lst'>{$shelf->Title}</a></b>";
        $this->addMessage('Success', sprintf(_t('Profile.SEARCHADD_SUCCESS'), $link));

        $response = array('ShelfID' => $shelf->ID);

        return $this->flushResponse($request, $response);
    }

    /**
     * Render the button for saving / updating saved searches
     *
     * @return string
     */
    public function savesearchButton()
    {
        return $this->renderWith('SaveSearchButton');
    }

    /**
     * Returns the dialog for editing or adding a shelf
     *
     * @param SS_HTTPRequest $request
     * @throws Exception
     * @return string
     */
    public function shelfDialog(SS_HTTPRequest $request)
    {
        $member = Member::currentUser();
        if (!$member)
            $this->htmlHttpError(404);

        $shelf = DataObject::get_by_id('Shelf', (int) $request->param('ShelfId'));

        if ($shelf) {
            if (!$this->memberIsOwner($shelf))
                throw new Exception('Current Member is not the owner of the Shelf');
        } else {
            //Create a new shelf -> empty data
            $shelf = new DataObject();
        }

        return $shelf->renderWith('ShelfDialog');
    }

    /**
     * Returns the dialog for editing or adding a shelf
     *
     * @param SS_HTTPRequest $request
     * @throws Exception
     * @return string
     */
    public function searchDialog(SS_HTTPRequest $request)
    {
        $member = Member::currentUser();
        if (!$member)
            $this->htmlHttpError(404);

        $shelf = DataObject::get_by_id('MappedSearchShelf', (int) $request->getVar('id'));

        if ($shelf) {
            if (!$this->memberIsOwner($shelf))
                throw new Exception('Current Member is not the owner of the Shelf');
        } else {
            //Create a new shelf -> empty data
            $shelf = new DataObject();
        }

        $searchData = array(
            'SearchQueryString' => $request->getVar('search-query-string'),
            'CurrentSorting' => $request->getVar('search-sort'),
            'SearchType' => $request->getVar('type'),
            'PageID' => $request->getVar('search-page-id')
        );

        return $shelf->customise($searchData)->renderWith('SaveSearchDialog');
    }

    /**
     * Render a checkbox for the shelvesdialog
     *
     * @param SS_HTTPRequest $request
     * @return string
     */
    public function checkbox(SS_HTTPRequest $request)
    {
        $shelf = Shelf::get_by_id('Shelf', (int) $request->getVar('id'));

        $arrayData = new ArrayData(array(
             'shelf' => $shelf,
             'in_shelf' => false
        ));

        return $arrayData->renderWith('ShelfCheckbox');
    }

    /**
     * Render an option for the shelves dropdown
     *
     * @param SS_HTTPRequest $request
     * @return string
     */
    public function selectOption(SS_HTTPRequest $request)
    {
        $shelf = Shelf::get_by_id('Shelf', (int) $request->getVar('id'));

        return $shelf->renderWith('ShelfOption');
    }

    /**
     * Return the list of the current member's shelves for the given manifestation
     *
     * @param SS_HTTPRequest $request
     *
     * @return string
     */
    public function getManifestationShelves(SS_HTTPRequest $request)
    {
        $manId = $request->param('ManifestationId');

        $manifestation = new Manifestation();
        $manifestation->trine_id = $manId;

        $enrichment = new DngManifestationEnrichment(array('shelves' => true));

        $enrichment->fillManifestation($manifestation);

        return $manifestation->renderWith('ManifestationShelves');
    }

    /**
     * @return bool
     */
    public function isShelf()
    {
        return true;
    }

    /**
     * Returns a link to the search this shelf was generated from
     *
     * @return string
     */
    public function getSearchPageLink()
    {
        $shelf = $this->dataRecord->Shelf();
        $searchPage = $shelf->getSearchPage();
        $shelfMapper = $shelf->getMapper();
        $pageMapper = $this->getSolrQueryMapper();

        $newMapper = ($pageMapper instanceof SolrSimpleQueryMapper && $shelfMapper instanceof SolrSimpleQueryMapper)
            ? new SolrSimpleQueryMapper($shelfMapper->getFieldsCollection()) : new SolrQueryMapper($shelfMapper->getFieldsCollection());

        $newMapper
            ->merge($shelfMapper)
            ->merge($pageMapper)
        ;

        $action = $newMapper instanceof SolrSimpleQueryMapper ? 'search' : 'advanced';
        $link = "{$searchPage->Link($action)}/lst?" . $newMapper->getQueryString();

        $link .= '&sort=' . $this->getCurrentSorting();

        return $link;
    }

    /**
     * are we in a saved search?
     *
     * @return bool
     */
    public function isSavedSearch()
    {
        return $this->dataRecord->Shelf() instanceof MappedSearchShelf;
    }

    /**
     * Check if current member is the owner of the shelf
     *
     * @param Shelf $shelf
     * @return bool
     */
    private function memberIsOwner(Shelf $shelf)
    {
        $currMember = Member::currentUser();

        if (!$currMember)
            return false;

        return $shelf->OwnerID == $currMember->ID;
    }

    /**
     * Handle a generic shelf action, checking if the member is the owner of the shelf and
     * if the shelf is writeable (i.e. is an instanceof ManifestationsShelf, and then
     * save the shelf to the persistence layer
     *
     * @param SS_HTTPRequest $request
     * @param $callback A callback that performs the concrete shelf action
     * @param bool $delete
     * @throws Exception
     */
    private function processShelfAction(SS_HTTPRequest $request, $callback, $delete = false)
    {
        $shelf = DataObject::get_by_id('Shelf', $request->param('ShelfId'));

        if (! $this->memberIsOwner($shelf))
            throw new Exception('Current Member is not the owner of the Shelf');

        $response = $callback($request, $shelf, $this);

        if ($delete) {
            $shelf->delete();
        }
        else {
            $shelf->write();
        }

        return $this->flushResponse($request, $response);
    }

    /**
     * Output the response to the browser, checking if it is an ajax request or if a goback is requested
     *
     * @param SS_HTTPRequest $request
     * @param $response
     * @return SS_HTTPResponse
     */
    private function flushResponse(SS_HTTPRequest $request, $response)
    {
        if (!$this->isAjax()) {
            if ($request->getVar('goback')){
                $this->redirectBack();
            }
        } else {
            $response = new SS_HTTPResponse(json_encode($response));
            $response->addHeader("Content-type", "application/json");

            return $response;
        }
    }

    /**
     * @param SS_HTTPRequest $request
     * @return string
     */
    public function updateCSDropDown(SS_HTTPRequest $request)
    {
        if($this->isAjax()){
            $connector = $this->getContainer()->get('liquens.connector');
            if(array_key_exists('term', $_GET))
                $shelves = $connector->getShelvesForLibrary("".$_GET['term']."");
            
            /**
             * [17] => Array
                (
                    [ShelfId] => 1047
                    [ShelfName] => - Vivere in tempi di crisi
                    [ShelfDescription] => (senza descrizione)
                    [ShelfStatus] => D
                    [ShelfItemtype] => manifestation
                    [LibrarianId] => 169
                    [LibraryId] => 24
                    [SortableRank] => 
                    [DateCreated] => 2010-09-03 17:56:29
                    [DateUpdated] => 2010-09-03 17:57:20
                    [CreatedBy] => 169
                    [ModifiedBy] => 169
                )
             */
        
            $response = array();
            
            $i = 0;
            foreach ($shelves as $k=>$shelfdata) {
                foreach ($shelfdata as $name => $val) {
                    if($name == 'ShelfItemtype' && $val == 'manifestation') continue;
                    if($name == 'ShelfId') $response[$i]['idx'] = $val;
                    if($name == 'ShelfName') $response[$i]['name'] = $val;
                }
                $i++;
            }
            
            $sortedResponse = $this->sortResponseByKey($response, 'name');
            return json_encode($sortedResponse);
        }
    }

    /**
     * Load shelfpage and shelf from a request
     *
     * @param \SS_HTTPRequest $request
     * @return void
     * @throws Exception
     */
    private function loadShelfPage(SS_HTTPRequest $request) {
        $shelf = Shelf::get_shelf_from_ref($request->param('ShelfRef'));
        
        // Verifica esistenza dello scaffale
        if (!$shelf) {
            try {
                throw new Exception('No Shelf with ref ' . $request->param('ShelfRef'));
            } catch (Exception $e) {
                Debug::log($e->getMessage());
            }
            $this->httpError(404, 'You are not authorized to view this shelf');
        }
        
        //Check for visibility options of the shelf
        if ($shelf->Visibility == 'private' && !$this->memberIsOwner($shelf)) {
            $this->httpError(404, 'You are not authorized to view this shelf');
        }
        $shelfPage = ShelfPage::get_from_shelf($shelf);
        $this->dataRecord = $shelfPage;
        $this->failover = $this->dataRecord;
    }

    /**
     * @param array $array
     * @param $key
     * @param bool $asc
     * @return array
     */
    private function sortResponseByKey(array $array, $key, $asc = true)
    {
        $result = array();
        $values = array();
        foreach ($array as $id => $value) {
            $values[$id] = isset($value[$key]) ? $value[$key] : '';
        }

        if ($asc) {
            asort($values);
        }
        else {
            arsort($values);
        }
        $i = 0;
        foreach ($values as $key => $value) {
            $result[$i] = $array[$key];
            $i++;
        }

        return $result;
    }

    /**
     * Risposta alla richiesta di presenza MLOL nel sistema (admin)
     * 
     * @return string
     */
    public function mlolActiveOnSystem() {
        global $sc;
        if ($sc->getParameter('mlol.connector.active') == true) {
            return 'true';
        }
        return 'false';
    }

}
