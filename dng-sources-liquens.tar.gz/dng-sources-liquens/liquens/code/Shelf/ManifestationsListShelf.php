<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class ManifestationsListShelf extends SolrShelf
{
    /**
     * @var string The name of the solr field to search ids into
     */
    protected $solrFieldName = 'id';

    /**
     * @var float
     */
    public $boostExponent = 1.2;

    /**
     * @var int
     */
    public $boostDecimals = 5;

    /**
     * If true, the or conditions will be followed by a solr boost to preserve
     * the order returned by getManifestationsIds
     *
     * @var bool
     */
    public $applyBoostToPreserveOrder = false;

    /**
     * Returns an array that contains the ids of the manifestations of the shelf.
     * To override in children classes
     *
     * @param int $start
     * @param null $limit
     * @return array
     */
    public function getManifestationsIds($start = 0, $limit = null)
    {
        return array();
    }

    /**
     * @param $fieldName The name of the solr field where search manifestation ids
     *
     * @return \ManifestationsListShelf
     */
    public function setSolrQueryField($fieldName)
    {
        $this->solrFieldName = $fieldName;

        return $this;
    }

    /**
     * @return int The total number of manifestations in the shelf
     */
    public function getCount()
    {
        return count($this->getManifestationsIds());
    }

    /**
     * @param SolrQuery $query
     * @param int $start
     * @param null $limit
     * @return SolrQuery
     */
    public function fillSolrQuery(SolrQuery $query, $start = 0, $limit = null)
    {
        parent::fillSolrQuery($query, $start, $limit);

        $ids = $this->getManifestationsIds();

        if (!$ids){
            $filter = static::NULLQUERY;
        } else {
            $solrFieldName = $this->solrFieldName;

            $pieces = array();

            if ($this->applyBoostToPreserveOrder)
                $boost = pow($this->boostExponent, count($ids));

            foreach ($ids as $id){
                $condition = $solrFieldName . ':' . SolrSearcher::escape($id);
                if ($this->applyBoostToPreserveOrder) {
                    $totalBoost = number_format($boost, $this->boostDecimals, '.', '');
                    $condition .= "^$totalBoost";
                    $boost = $boost / $this->boostExponent;
                }
                $pieces[] = $condition;
            }

            $filter = implode(' OR ', $pieces);
        }

        //If present, move mainquery to filters
        if ($query->getMainQuery())
            $query->addFilterQuery($query->getMainQuery());

        $query->setMainQuery($filter);

        return $query;
    }

    /**
     * Check if a manifestation is in the shelf
     *
     * @param string $manifestationId
     * @return bool
     */
    public function isManifestationInShelf($manifestationId)
    {
        return in_array($manifestationId, $this->getManifestationsIds());
    }

    /**
     * Tells us if the shelf is writeable or not
     * @return bool
     */
    public function isWriteable()
    {
        return true;
    }


}
