<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class ShelfPage extends SearchPage
{
    static $db = array(
        'ShelfRef' => 'Text',
        'ShelfSort' => 'VarChar(255)'
    );

    /**
     * @var Shelf
     */
    private $cachedShelf;

    /**
     * Given a Shelf, returns a ShelfPage built around it
     *
     * @static
     * @param Shelf $shelf
     *
     * @return ShelfPage
     */
    public static function get_from_shelf(Shelf $shelf)
    {
        $shelfPage = new ShelfPage();
        //This avoid that methods like Children() returns all elements with ParentID = 0
        $shelfPage->ID = -1;

        //Tell the template that the shelf page is not in the db
        $shelfPage->NotPersistent = true;

        if (isset($shelf->ShelfRef)){
            $shelfPage->ShelfRef = $shelf->ShelfRef;
        } else {
            $shelfPage->ShelfRef = 'persistent:'.$shelf->ID;
        }

        $shelfPage->Title = $shelf->getTranslatedTitle();
        $shelfPage->Description = $shelf->Description;
        $shelfPage->URLSegment = 'opac';
        $shelfPage->DefaultViewType = 'lst';

        return $shelfPage;
    }
    
    /**
     * Return new tabs and fields
     *
     * @return fields objects
     */
    public function getCMSFields($params = NULL)
    {   
        $fields = parent::getCMSFields();

        $shelfFields = new ShelfFields(null, $this->ShelfRef, array('external','member','predefined'), $this->ShelfSort);

        $fields->addFieldsToTab('Root.Content.Shelf', $shelfFields);

        $fields->findOrMakeTab('Root.Content.Shelf')->setTitle(_t('ShelfPage.LINKED_SHELF_TAB'));

        return $fields;
    }

    public function Shelf()
    {
        if (!isset($this->cachedShelf)) {
            $this->cachedShelf = Shelf::get_shelf_from_ref($this->ShelfRef);
            if ($this->ShelfSort)
                $this->cachedShelf->setDataValue('sort', $this->ShelfSort);
        }

        return $this->cachedShelf;
    }

    /**
     * Handle the connection with the various types of shelves
     */
    public function onBeforeWrite() 
    {
        parent::onBeforeWrite();

        ShelfFields::beforeWriteHook($this);
    }

    public function hasUndefinedTotalResults()
    {
        return $this->Shelf()->hasUndefinedTotalElements();
    }

    public function isSortable()
    {
        return $this->Shelf()->isSortable();
    }
}