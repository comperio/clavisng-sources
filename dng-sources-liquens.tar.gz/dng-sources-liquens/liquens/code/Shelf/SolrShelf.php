<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class SolrShelf extends Shelf
{
    const NULLQUERY = 'id:0';

    /**
     * @var SolrSearcher
     */
    private $solrSearcher;

    /**
     * @var ManifestationDriver
     */
    private $manifestationDriver;

    /**
     * If setted, used in getSolrResponse as an argument to fillSolrQuery.
     * In this way we can add filters to the query
     *
     * @var SolrQuery
     */
    private $startQuery;

    /**
     * If setted, force a filter for the library with $libraryFilterId
     *
     * @var int
     */
    private $libraryFilter;

    /**
     * The field name of the library
     *
     * @var string
     */
    private $solrLibraryFieldName = 'faceti_libvisi';

    /**
     * The heart of a SolrShelfTest: filling a SolrQuery with certain filters
     * @param \SolrQuery $query
     * @param int $start
     * @param null $limit
     *
     * @return SolrQuery
     */
    public function fillSolrQuery(SolrQuery $query, $start = 0, $limit = null)
    {
        if (!$query->getMainQuery())
            $query->setMainQuery('*:*');

        if ($this->getDataValue('sort'))
            $query->setRawField('sort', LQConfig::get('sortFields', $this->getDataValue('sort'), 'rule'));
        if ($this->getLibraryFilter())
            $query->addFilterQuery($this->solrLibraryFieldName . ':' . $this->getLibraryFilter());
        if ($this->getDataValue('solr_filter'))
            $query->addFilterQuery($this->getDataValue('solr_filter'));
        if ($this->getDataValue('max'))
            $query->setRawField('dngForceMax', $this->getDataValue('max'));

        $query->setRawField('start', $start);

        if ($limit !== null){
            $query->setRawField('rows', $limit);
        }

        return $query;
    }

    /**
     * @param int $start
     * @param null $limit
     *
     * @return DataObjectSet
     */
    public function getManifestations($start = 0, $limit = null)
    {
        $solrResponse = $this->getSolrResponse($start, $limit);

        //TODO: unwanted dependency: SearchResultsClass
        $results = new SearchResults($solrResponse);

        return $results->getManifestations($this->manifestationDriver);
    }

    /**
     * REturns an array filled up with manifestations ids
     *
     * @param int $start
     * @param null $limit
     *
     * @return array
     */
    public function getManifestationsIds($start = 0, $limit = null)
    {
        return $this->getSolrResponse($start, $limit)->getDocsProperties('id');
    }


    /**
     * @param \SolrSearcher $solrSearcher
     *
     * @return \SolrShelf
     */
    public function setSolrSearcher($solrSearcher)
    {
        $this->solrSearcher = $solrSearcher;

        return $this;
    }

    /**
     * @param \ManifestationDriver $manifestationDriver
     *
     * @return \SolrShelf
     */
    public function setManifestationDriver($manifestationDriver)
    {
        $this->manifestationDriver = $manifestationDriver;

        return $this;
    }

    /**
     * @param int $start
     * @param null $limit
     *
     * @return SolrResponse
     */
    private function getSolrResponse($start = 0, $limit = null)
    {
        $query = $this->getStartQuery();

        $this->fillSolrQuery($query, $start, $limit);

        return $this->solrSearcher->search($query);
    }

    /**
     * @see $startQuery
     * @param \SolrQuery $startQuery
     *
     * @return \SolrShelf
     */
    public function setStartQuery($startQuery)
    {
        $this->startQuery = $startQuery;

        return $this;
    }

    /**
     * @see $startQuery
     *
     * @return SolrQuery
     */
    public function getStartQuery()
    {
        if (!isset($this->startQuery))
            return new SolrQuery();

        return $this->startQuery;
    }

    /**
     * @see $libraryFilter
     * @param int $libraryFilter
     *
     * @return \SolrShelf
     */
    public function setLibraryFilter($libraryFilter)
    {
        $this->libraryFilter = $libraryFilter;

        return $this;
    }

    /**
     * @see $libraryFilter
     *
     * @return int
     */
    public function getLibraryFilter()
    {
        return $this->libraryFilter;
    }

    /**
     * Return, if setted, a SolrFilter
     *
     * @return mixed
     */
    public function getSolrFilter()
    {
        return $this->getDataValue('solr_filter');
    }

    /**
     * Set an additional filter to pass to the solr query
     *
     * @param $filter
     *
     * @return SolrShelf
     */
    public function setSolrFilter($filter)
    {
        $this->setDataValue('solr_filter', $filter);

        return $this;
    }
}
