<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class ShelfFields extends FieldGroup
{
    private $shelfRef;

    /**
     * @var Shelf
     */
    private $shelf;

    /**
     * @var LiquensConnector
     */
    private $connector;

    /**
     * Determines which types of shelf are shown (@see ShelfFields::shelf_types)
     * @var array
     */
    private $shelfTypesToShow = array();

    /**
     * @var The field the shelf will be sorted by
     */
    private $sort;

    /**
     * The available ways to select a shelf
     *
     * @var array
     */
    public static function shelf_types() {
        $types = array('external', 'member', 'predefined', 'shelfpage');        
        // Verifica collegamento a MLOL per il sistema
        global $sc;
        if ($sc->getParameter('mlol.connector.active') == true) {
            array_push($types, 'shelfmlol');
        }
        $shelfTypes = array();

        foreach ($types as $type) {
            $shelfTypes[$type] = _t('ShelfPage.' . strtoupper($type));
        }

        return $shelfTypes;
    }

    /**
     * @param null $items
     * @param null $shelfRef @see Shelf::get_shelf_from_ref()
     * @param array $shelfTypesToShow @see $shelfTypesToShow
     * @param string $sort
     */
    public function __construct($items = null, $shelfRef = null, $shelfTypesToShow = array(), $sort = '')
    {
        parent::__construct(null);

        if (!$shelfRef){
            $shelfRef = 'predefined:lastin';
        }
        $this->shelfTypesToShow = $shelfTypesToShow;

        $this->shelfRef = $shelfRef;
        $this->sort = $sort;

        $this->shelf = Shelf::get_shelf_from_ref($shelfRef);

        global $sc;
        $this->connector = $sc->get('liquens.connector');

        $this->loadFields();

        $this->addExtraClass('lq_shelfform');

    }

    /**
     * Returns the array @see $shelf_types intersected with the list of @see $shelfTypesToShow
     * @return array
     */
    public function getShelfTypesToShow()
    {   
        $shelfTypes = static::shelf_types();
        if ($this->shelfTypesToShow)
            return array_intersect_key($shelfTypes, array_flip($this->shelfTypesToShow));

        return $shelfTypes;
    }

    /**
     * This method has to be called from object that use ShelfFields to link themselves to a Shelf.
     * The relation of the object with the shelf must be setted through the ShelfRef property.
     * @see Shelf::get_shelf_from_ref()
     *
     * @static
     * @param DataObject $object The objecy that has a relation with a Shelf
     */
    public static function beforeWriteHook(DataObject $object)
    {
        global $sc;
        $connector = $sc->get('liquens.connector');

        $pieces = explode(':', $object->ShelfRef);

        if ('external' == $pieces[0]){
            $id = $pieces[1];
            $libraryId = $pieces[2];
            $externalShelf = ExternalShelf::get_by_external_id($id);
            $externalShelf->setDataValue('library_id', $libraryId);

            $shelfData = $connector->getShelfInfo($id, $libraryId);

            //save if the shelf is not persisted or the name is not setted
            if (isset($shelfData['ShelfName']))
                $externalShelf->setDataValue('external_title', $shelfData['ShelfName']);
            if (isset($shelfData['ShelfDescription']))
                $externalShelf->setDataValue('external_description', $shelfData['ShelfDescription']);
            $externalShelf->write();

            $object->ShelfRef = 'persistent:'.$externalShelf->ID;

            if (isset($pieces[3]))
                $object->ShelfRef .= ':' . $pieces[3];
        }
    }

    /**
     * Build the form fields
     */
    public function loadFields() {

        $shelfType = 'member';
        $memberShelfId = '';
        $shelfPageId = '';

        if ($this->shelfRef){
            list($shelfRefType, $shelfRefId) = explode(':', $this->shelfRef);

            /** @var $shelf Shelf */
            $shelf = Shelf::get_shelf_from_ref($this->shelfRef);

            switch ($shelfRefType){
                case 'persistent':
                    if ($shelf instanceof ExternalShelf){
                        $shelfType = 'external';
                    } else {
                        $shelfType = 'member';
                        $memberShelfId = $shelfRefId;
                    }
                    break;
                case 'shelfpage':
                    $shelfPageId = $shelfRefId;
                    break;
                default:
                    $shelfType = $shelfRefType;
                    break;
            }
        }

        $clavisLibraryId = '';
        $clavisShelfId = '';
        $clavisShelfAry = array();
        if ($this->shelf instanceof ExternalShelf){
            $clavisLibraryId = $shelf->getDataValue('library_id');
            $clavisShelfId = $shelf->getDataValue('external_id');
            $clavisShelfAry[$clavisShelfId] = 'Current shelf';
        }

        Requirements::javascript('liquens/javascript/lq.cms.shelves.js');

        // Genera lista con il tipo di scaffale
        $shelfTypes = new OptionsetField(
            "shelfType",
            _t( 'ShelfPage.SHELFTYPE','Shelf type'),
            $this->getShelfTypesToShow(),
            $shelfType
        );
        $shelfTypes->addExtraClass('lq_shelftype');
        $this->push($shelfTypes);

        // Scaffale notizie da Clavis
        // Lista biblioteche
        $libraries = array('' => _t('ShelfPage.CHOOSELIBRARY','-- Select a library --')) + $this->getLibrariesMap();        
        $libraryDropdown = new DropdownField(
            'library',
            _t( 'ShelfPage.LIBRARIESFORSHELF','Select a Library: '),
            $libraries, $clavisLibraryId
        );
        $libraryDropdown->addExtraClass('lq_library_dropdown');
        // --
        $clavisShelvesDropdown = new DropdownField(
            'clavisShelf',
            _t('ShelfPage.CLAVISSHELVES', 'Select a Shelf: '),
            $clavisShelfAry, $clavisShelfId, null, '---'
        );
        $clavisShelvesDropdown->addExtraClass('lq_externalshelf_dropdown');
        // --
        $clavisShelvesSet = new ClavisShelvesSet(
            $libraryDropdown,
            $clavisShelvesDropdown,
            "ClavisShelves"
        );
        $clavisShelvesSet->addExtraClass('lq_shelf_external_group');
        $this->push($clavisShelvesSet);

        // I tuoi scaffali di DNG
        // Carica gli scaffali dell'utente con visibilità pubblica
        $memberShelves = Member::currentUser()->Shelves('public', null);
        $memberShelvesMap = $memberShelves->map('ID', 'TranslatedTitle');
        //If the current shelf is of another member, mantain the reference in the dropdown
        if ($memberShelfId && ! array_key_exists($memberShelfId, $memberShelvesMap)){
            $memberShelvesMap = array($memberShelfId => _t('ShelfPage.ANOTHER_USER_SHELF')) + $memberShelvesMap;
        }
        $memberShelves = new DropdownField(
            'memberShelf',
            _t('ShelfPage.SETDNGMEMBERSHELF', 'Select one of your public shelves'),
            $memberShelvesMap,
            $memberShelfId
        );
        $memberShelves->addExtraClass('lq_shelf_member_group');
        // dng shelves
        $this->push($memberShelves);

        // Scaffali predefiniti di DNG
        $predefinedShelves = new DropdownField(
            'predefinedShelf',
            _t('ShelfPage.SETDNGPREDEFINED', 'Select one of DNG predefined shelves'),
            Page_Controller::$container->getParameter('available_predefined_shelves')
        );
        $predefinedShelves->addExtraClass('lq_shelf_predefined_group');
        $this->push($predefinedShelves);

        //ShelfPage Shelves
        $shelfPages = DataObject::get('ShelfPage');
        if ($shelfPages) {
            $shelfPages = $shelfPages->toDropdownMap('ID', 'Title', _t('DropdownField.CHOOSE'), true);
        }
        $shelfpageShelves = new DropdownField(
            'shelfpageShelf',
            _t('ShelfPage.SETSHELFPAGESHELF', 'Select a Shelf Page'),
            $shelfPages,
            $shelfPageId
        );
        $shelfpageShelves->addExtraClass('lq_shelf_shelfpage_group');
        $this->push($shelfpageShelves);

        global $sc;
        if ($sc->getParameter('mlol.connector.active') == true) {
            // Scaffali del servizio MLOL
            $mlolShelvesDropdown = new DropdownField(
                'mlolShelf',
                _t('ShelfPage.SETSHELFMLOL', 'Select a shelf MLOL'),
                Page_Controller::$container->getParameter('available_mlol_shelves')
            );
            $mlolShelvesDropdown->addExtraClass('lq_shelf_mlol_dropdown');

            // Risorse disponibili su MLOL
            $mlolResourcesDropdown = new DropdownField(
                'mlolResources',
                _t('ShelfPage.SETMLOLMEDIA', 'Media type'),
                Page_Controller::$container->getParameter('available_mlol_resources')
            );
            $mlolResourcesDropdown->addExtraClass('lq_shelf_resources_dropdown');
            // --
            $mlolShelves = new MlolShelvesSet(
                $mlolShelvesDropdown,
                $mlolResourcesDropdown,
                "MlolShelves"
            );
            $mlolShelves->addExtraClass('lq_shelf_mlol_group');
            $this->push($mlolShelves);        
        }
        
        $spazioUno = new LiteralField('space', '<br class="space_shelf_1" />');
        $this->push($spazioUno);
        $spazioDue = new LiteralField('space', '<br class="space_shelf_2" />');
        $this->push($spazioDue);

        // Ordinamento
        $this->push(new DropdownField('ShelfSort', 'Ordinamento', $this->getSortMap(), $this->sort));

        $spazioTre = new LiteralField('space', '<br class="space_shelf_3" />');
        $this->push($spazioTre);
        $spazioQuattro = new LiteralField('space', '<br class="space_shelf_4" />');
        $this->push($spazioQuattro);
        
        // Filtro per biblioteche o musei
        if ($sc->getParameter('is_library') == true) {
            $libraryFilterDropDown = new DropdownField(
                'libraryFilter',
                _t('ShelfPage.INCLUDERESULTS', 'Includi solo i titoli che contengono copie di '),
                array('' => _t('LibrariesListPage.ALLLIBRARIES', 'Tutte le biblioteche')) + $this->getLibrariesMap(),
                $this->getLibraryFilter()
            );
        } else {
            $libraryFilterDropDown = new DropdownField(
                'libraryFilter',
                _t('ShelfPage.INCLUDERESULTS', 'Includi solo i risultati di '),
                array('' => _t('LibrariesListPage.ALLMUSEUMS', 'Tutti i musei')) + $this->getLibrariesMap(),
                $this->getLibraryFilter()
            );
        }
        $libraryFilterDropDown->addExtraClass('lq_shelf_library_filter');
        $this->push($libraryFilterDropDown);

        // ShelfRef Hidden field
        $shelfRefField = new HiddenField('ShelfRef', '', $this->shelfRef);
        $shelfRefField->addExtraClass('lq_shelf_ref_field');
        $this->push($shelfRefField);

        //
        if ($this->shelf instanceof ExternalShelf) {
            
            $initialLibField = new HiddenField('initial_lib', '', $this->shelf->getDataValue('library_id'));
            $initialLibField->addExtraClass('lq_shelf_initial_lib');
            $this->push($initialLibField);

            $initialExShelfField = new HiddenField('initial_ext_shelf', '', $this->shelf->getDataValue('external_id'));
            $initialExShelfField->addExtraClass('lq_shelf_initial_ext_id');
            $this->push($initialExShelfField);
        }
    }

    /**
     * A ShelfRef can specify a library filter.
     * shelfRef can be of the form shelftype:shelfid:libraryid
     *
     * @return string
     */
    private function getLibraryFilter()
    {
        if (isset($this->shelfRef)){
            $pieces = explode(':', $this->shelfRef);
            if (isset($pieces[2]))
                return $pieces[2];
        }

        return '';
    }

    /**
     * Library map to use in the dropdown
     *
     * @return mixed
     */
    private function getLibrariesMap()
    {
        global $sc;

        return $sc->get('library.repository')->getAllLibraries('ExternalID', 'shortName');
    }

    private function getSortMap()
    {
        $map = array('' => 'Predefinito');

        foreach (LQConfig::get('sortFields') as $name => $specs) {
            $map[$name] = _t('LQFields.SORT_' . strtoupper($name), $specs['label']);
        }

        return $map;
    }
}
