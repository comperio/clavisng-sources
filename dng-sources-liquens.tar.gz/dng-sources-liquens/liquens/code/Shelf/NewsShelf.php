<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class NewsShelf extends QueryShelf
{
    /**
     * @var int
     */
    private $daysInterval = 30;

    /**
     * Returns the Solr query used to retrieve shef's items
     *
     * @return string
     */
    public function getQuery()
    {
        $date = new DateTime("{$this->getDaysInterval()} days ago");

	$from = $date->format('Y-m-d');
        $fromTimestamp = $date->getTimestamp();

        return "(sorts_created:[\"$from\" TO *] AND sorts_lastinvdate:[\"$fromTimestamp\" TO *]) NOT collection:extra";
    }

    /**
     * @param int $daysInterval
     *
     * @return NewsShelf The current instance
     */
    public function setDaysInterval($daysInterval)
    {
        $this->daysInterval = $daysInterval;

        return $this;
    }

    /**
     * @return int
     */
    public function getDaysInterval()
    {
        return $this->daysInterval;
    }
}
