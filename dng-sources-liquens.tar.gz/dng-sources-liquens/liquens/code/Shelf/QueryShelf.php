<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class QueryShelf extends SolrShelf
{
    /**
     * Returns the Solr query used to retrieve shef's items
     *
     * @return string
     */
    public function getQuery()
    {
        return $this->getDataValue('query_filter');
    }

    /**
     * @param SolrQuery $query
     * @param int $start
     * @param null $limit
     * @return SolrQuery
     */
    public function fillSolrQuery(SolrQuery $query, $start = 0, $limit = null)
    {
        parent::fillSolrQuery($query, $start, $limit);

        if (!$query->getMainQuery() || $query->getMainQuery() === '*:*'){
            $query->setMainQuery($this->getQuery());
        } else {
            $query->appendCondition($this->getQuery());
        }

        return $query;
    }


    /**
     * Set the query filter.
     *
     * @param $query
     * @return QueryShelf
     */
    public function setQuery($query)
    {
        $this->setDataValue('query_filter', $query);

        return $this;
    }

}
