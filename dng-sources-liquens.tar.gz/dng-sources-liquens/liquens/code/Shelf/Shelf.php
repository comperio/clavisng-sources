<?php

/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

/**
 * This abstract class represents a basic Shelf object.
 * Concrete implementations must define the getFilterQuery method.
 */
class Shelf extends DataObject {

    private $sortable = true;
    protected $unserialized = array();
    public static $db = array(
        'Name' => 'Varchar(255)',
        'Description' => 'Text',
        'Visibility' => "Enum('public,private','public')",
        'SerializedData' => 'Text',
        'CenterLat' => 'DngDecimal(10,7)',
        'CenterLon' => 'DngDecimal(10,7)',
        "GeoType" => "Varchar(255)",
        "IsGeotag" => "Boolean"
    );
    public static $indexes = array(
        'Name' => true,
        'OwnerID' => true
    );
    static $has_one = array(
        'Owner' => 'Member',
    );
    static $defaults = array(
        "IsGeotag" => "0",
        "GeoType" => "0"
    );

    function __construct($record = null, $isSingleton = false) {
        parent::__construct($record, $isSingleton);

        global $sc;
        Kernel::load_injections($this, $sc);
    }

    /**
     * Factory method that build a shelf from a "referenceString"
     * The reference string is a string of the type
     * reftype:refid
     * Supported reftypes:
     * - persistent:
     *  retrieve a shelf from a db by its id. For example, "persistent:2"
     * will return the Shelf DataObject with ID 2
     * - predefined:
     *  retrieve a shelf from the service container, using its parameter "available_predefined_shelves"
     *  For example, "predefined:most_commented" will return the shelf of most commented manifestations
     * - shelfpage:
     *  retrieve a shelf from a shelfpage
     *
     * @static
     * @param $shelfRef
     * @throws InvalidArgumentException
     * @return Shelf
     */
    public static function get_shelf_from_ref($shelfRef) {
        //If the ref is numeric, reduce to the persistent case
        if (is_numeric($shelfRef))
            $shelfRef = 'persistent:' . $shelfRef;

        $pieces = explode(':', $shelfRef);
        if (count($pieces) < 2)
            return false;

        if (!$pieces[1])
            return false;

        list($type, $id) = $pieces;
        $shelf = static::empty_shelf();

        /** @var $shelf Shelf */
        switch ($type) {
            case 'persistent':
                $shelf = DataObject::get_by_id('Shelf', $id) ?: $shelf;
                break;
            case 'shelfpage':
                $shelfPage = DataObject::get_by_id('ShelfPage', $id);
                if ($shelfPage) {
                    $shelf = $shelfPage->Shelf() ?: $shelf;
                    $shelf->ShelfPage = $shelfPage;
                }
                break;
            case 'predefined':
                $container = Page_Controller::$container;
                if (array_key_exists($id, $container->getParameter('available_predefined_shelves'))) {
                    $shelf = $container->get('shelves.' . $id);
                } else {
                    throw new InvalidArgumentException($id . ' is not a valid predefined shelf type');
                }
                break;
            case 'shelfmlol':
//                global $sc;
//                if ($sc->getParameter('mlol.connector.active') == false) {
//                    return false;
//                }
                break;
            default:
                throw new InvalidArgumentException('Unknown shelf reference type');
        }

        if (isset($pieces[2]) && $shelf instanceof SolrShelf) {
            $shelf->setLibraryFilter($pieces[2]);
        }

        //store shelfref (it can be useful...)
        $shelf->ShelfRef = $shelfRef;

        return $shelf;
    }

    /**
     * Return an array of shelves owned by member
     * @static
     * @param Member|null $member
     * @param null $shelfClass
     * @param null $visibility
     * @return DataObjectSet
     */
    public static function get_shelves_for_owner($member, $shelfClass = null, $visibility = null) {
        if (!$shelfClass)
            $shelfClass = 'Shelf';


        if (!$member instanceof Member)
            return new DataObjectSet();

        $filter = sprintf("OwnerID = %d", $member->ID);

        if ($visibility)
            $filter .= sprintf(" AND Visibility = '%s'", Convert::raw2sql($visibility));

        //Case statement for shelf sorting: first predefined shelves, then other shelves ordered by name
        $predefinedNames = array_map(function ($name) {
            $name = Convert::raw2sql($name);
            return "WHEN '$name' THEN CONCAT('0', Name)";
        }, array_keys(LQConfig::get('default_shelves')));

        $caseStatement = 'CASE Name ' . implode(' ', $predefinedNames) . " ELSE CONCAT('1', Name) END";

        $result = DataObject::get($shelfClass, $filter, $caseStatement);

        return $result ?: new DataObjectSet();
    }

    /*
     * Construct an empty shelf. Used to handle cases in which the the system
     * is unable to find a certain shelf.
     *
     * @return Shelf
     */

    public static function empty_shelf() {
        $shelf = new static;

        $shelf->Name = 'Empty Shelf';
        $shelf->Description = 'Something got wrong: unable to find the shelf';

        return $shelf;
    }

    /**
     * Unserialize Data Field
     *
     * @return array
     */
    public function getData() {
        if (!$this->unserialized)
            $this->unserialized = unserialize($this->SerializedData);

        return $this->unserialized;
    }

    /**
     * Set Data field serializing $data parameter
     *
     * @param array $data
     * @return Shelf
     */
    public function setData(array $data = null) {
        $this->unserialized = $data;
        $this->SerializedData = serialize($data);

        return $this;
    }

    /**
     * Set a key-value pair of the serialized data field
     *
     * @param $key
     * @param $value
     * @return Shelf
     */
    public function setDataValue($key, $value) {
        $data = $this->getData();
        $data[$key] = $value;
        $this->setData($data);

        return $this;
    }

    /**
     * Get the value of a field in the serialized data field
     *
     * @param $key
     * @return mixed
     */
    public function getDataValue($key) {
        $data = $this->getData();

        return isset($data[$key]) ? $data[$key] : null;
    }

    /**
     * The heart of Shelf object. Retrieve the set of manifestations.
     *
     * @param int $start
     * @param null $limit
     * @return DataObjectSet
     */
    public function getManifestations($start = 0, $limit = null) {
        return new DataObjectSet();
    }

    public function getManifestationsIds($start = 0, $limit = null) {
        $manifestations = $this->getManifestations($start, $limit);

        $ids = array();

        foreach ($manifestations as $manifestation) {
            $ids[] = $manifestation->getId();
        }

        return $ids;
    }

    public function getShelfID() {
        return $this->ID;
    }

    public function ShelfGeoTagActive() {
        global $sc;
        if ($sc->getParameter('geotagging') != false) {
            return true;
        } else {
            return false;
        }
    }

    public function getGeoTagShelf() {
        $geoTags = DB::query("SELECT * FROM Shelf WHERE `ID` = '" . $this->getShelfID() . "'")->first();
        if ((isset($geoTags['IsGeotag'])) && ($geoTags['IsGeotag'] != 0)) {
            return $geoTags['CenterLat'] . '_' . $geoTags['CenterLon'] . '_' . $this->getShelfID() . '_' . $geoTags['GeoType'];
        }
        return '';
    }

    /**
     * Tells us if the shelf is writeable or not
     *
     * @return bool
     */
    public function isWriteable() {
        return false;
    }

    /**
     * Tells us if the current logged member is the owner of the shelf
     *
     * @return bool
     */
    public function isCurrentMemberOwner() {
        $member = Member::currentUser();

        return $member && $member->ID == $this->OwnerID;
    }

    /**
     * Check if the shelf is considered by the opac as a default one
     *
     * @return bool
     */
    public function isDefault() {
        return array_key_exists($this->Name, LQConfig::get('default_shelves')) && LQConfig::get('default_shelves', $this->Name, 'ClassName') == get_class($this);
    }

    /**
     * Visibilità di chi ha creato lo scaffale collegato alla shelfpage
     * 
     * @return boolean
     */
     public function isMemberVisible() {
        if ((!isset($this->OwnerID)) || ($this->OwnerID == '')) 
            return false;
        $privacy = unserialize(DB::query("SELECT Privacy FROM `Member` WHERE `ID` = " . $this->OwnerID)->first()["Privacy"]);
        if ( ($privacy["profile_visible"] !== true) || ($privacy["profile_visible"] != 1)) {
            return false;
        }
        return true;
    }

    /**
     * Returns, for the default shelves, a translated version of the descritpion
     *
     * @return string
     */
    public function getTranslatedDescription() {
        if ($this->isDefault())
            return _t($this->geti18nKey('Description'), $this->Description);

        return filter_var($this->Description, FILTER_SANITIZE_STRING);
    }

    /**
     * Return, for the default shelves, a translated version of the description
     *
     * @return string
     */
    public function getTranslatedTitle() {
        if ($this->isDefault())
            return _t($this->geti18nKey('Title'), $this->Name);

        return $this->Name;
    }

    /**
     * Tells if the Shelf is private
     *
     * @return bool
     */
    public function getPrivate() {
        if ($this->Visibility == 'private')
            return true;

        return false;
    }

    /**
     * Tells if it is not possible to calculate shelf total items.
     *
     * @return bool
     */
    public function hasUndefinedTotalElements() {
        return false;
    }

    /**
     * Tells if the Shelf supports sorting
     *
     * @return bool
     */
    public function isSortable() {
        return $this->sortable;
    }

    /**
     * Returns the number of manifestations in the shelf.
     * A null value means that the number cannot be retrieved directly from the shelf
     *
     * @return int The total number of manifestations in the shelf
     */
    public function getCount() {
        return null;
    }

    /**
     * Return the name where the spaces are replaced by scores
     *
     * @return mixed
     */
    public function getSluggedName() {
        return strtolower(str_replace(' ', '-', $this->Name));
    }

    /**
     * Returns the key used to translate fields
     * @param $field
     * @return string
     */
    private function geti18nKey($field) {
        return 'Shelf.' . strtoupper($this->Name . '_' . $field);
    }

    /**
     * @param bool $sortable
     * @return Shelf The current instance
     */
    public function setSortable($sortable) {
        $this->sortable = (bool) $sortable;

        return $this;
    }

}
