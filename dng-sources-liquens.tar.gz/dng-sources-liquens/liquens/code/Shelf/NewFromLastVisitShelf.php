<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class NewFromLastVisitShelf extends QueryShelf
{
    /**
     * @var Member
     */
    private $member;

    /**
     * Set Member
     *
     * @param \Member $member
     *
     * @return NewFromLastVisitShelf The current instance
     */
    public function setMember(\Member $member)
    {
        $this->member = $member;

        return $this;
    }

    /**
     * Get Member
     *
     * @throws Exception
     * @return \Member
     */
    public function getMember()
    {
        if (!isset($this->member))
            $this->member = Member::currentUser();

        if (!$this->member) {
            throw new Exception('Member not setted in the shelf and no user logged in found');
        }

        return $this->member;
    }

    /**
     * Returns the Solr query used to retrieve shef's items
     *
     * @return string
     */
    public function getQuery()
    {
        $date = $this->getDate();

	    $from = $date->format('Y-m-d');
        $fromTimestamp = $date->getTimestamp();

        return "(sorts_created:[\"$from\" TO *] AND sorts_lastinvdate:[\"$fromTimestamp\" TO *]) NOT collection:extra";
    }

    /**
     * @return DateTime
     */
    private function getDate()
    {
        return new DateTime($this->getMember()->LastVisited);
    }

}
