<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class ManifestationsShelf extends ManifestationsListShelf
{
    /**
     * Returns the array of manifestations ids
     *
     * @param int $start
     * @param null $limit
     * @return mixed The array of manifestations ids
     */
    public function getManifestationsIds($start = 0, $limit = null)
    {
        $ids = is_array($this->getDataValue('manifestations')) ?
            $this->getDataValue('manifestations') :
            array()
        ;

        return array_slice($ids, $start, $limit);
    }

    /**
     * Add a manifestation to the shelf
     *
     * @param $id The id of the manifestation
     * @return ManifestationsShelf
     */
    public function addManifestationId($id)
    {
        $this->addManifestationsIds(array($id));

        return $this;
    }

    /**
     * Add manifestations ids to the shelf
     *
     * @param array $ids
     * @return ManifestationsShelf
     */
    public function addManifestationsIds(array $ids)
    {
        $currIds = $newIds = $this->getManifestationsIds();

        //Don't add the same id twice
        foreach($ids as $id)
        {
            if (!in_array($id, $currIds))
                $newIds[] = $id;
        }

        $this->setDataValue(
            'manifestations',
            $newIds
        );

        return $this;
    }

    /**
     * Remove a manifestation from the shelf
     *
     * @param $id
     * @return ManifestationsShelf
     */
    public function removeManifestationId($id)
    {
        $ids = $this->getManifestationsIds();
        $this->setDataValue('manifestations', array_diff($ids, array($id)));

        return $this;
    }

    /**
     * Empties the shelf from all the manifestations
     *
     * @return ManifestationsShelf
     */
    public function emptyShelf()
    {
        $this->setDataValue('manifestations', array());

        return $this;
    }
}
