<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class MappedSearchShelf extends SolrShelf
{
    /**
     * @var SolrQueryMapper
     */
    private $solrQueryMapper;

    /**
     * Load the search from an array of key-value pairs.
     *
     * @param array $searchArray
     * @return MappedSearchShelf
     */
    public function loadByArray(array $searchArray)
    {
        $this->setSearchArray($searchArray);
        $this->solrQueryMapper = null;

        return $this;
    }

    /**
     * @param $queryString
     * @return MappedSearchShelf
     */
    public function loadByQueryString($queryString)
    {
        $array = array();
        parse_str($queryString, $array);

        $this->loadByArray($array);
        $this->solrQueryMapper = null;

        return $this;
    }

    /**
     * Set the SolrQueryMapperClass
     *
     * @param string $mapperClass
     * @return MappedSearchShelf
     */
    public function setMapperClass($mapperClass)
    {
        $this->setDataValue('mapper_class', $mapperClass);
        $this->solrQueryMapper = null;

        return $this;
    }

    /**
     * Get the SolrQueryMapperClass
     *
     * @return string
     */
    public function getMapperClass()
    {
        return $this->getDataValue('mapper_class');
    }

    /**
     * @return array
     */
    public function getSearchArray()
    {
        $ary = $this->getDataValue('search_array');

        return $ary ?: array();
    }

    /**
     * @param array $array
     * @return MappedSearchShelf
     */
    public function setSearchArray(array $array)
    {
        $this->setDataValue('search_array', $array);

        return $this;
    }

    /**
     * Return the SolrQueryMapper loaded with fields of the shelf
     *
     * @return SolrQueryMapper
     */
    public function getMapper()
    {
        global $sc;
        $fieldsCollection = $sc->get('solr.fields_collection');
        if (!$this->solrQueryMapper){
            $mapperClass = $this->getMapperClass();

            /** @var $mapper SolrQueryMapper */
            $mapper = new $mapperClass($fieldsCollection);
            $mapper->loadQuery(http_build_query($this->getSearchArray()));

            $this->solrQueryMapper = $mapper;
        }

        return $this->solrQueryMapper;
    }

    /**
     * The heart of a SolrShelfTest: filling a SolrQuery with certain filters
     * @param \SolrQuery $query
     * @param int $start
     * @param null $limit
     * @return SolrQuery
     */
    public function fillSolrQuery(SolrQuery $query, $start = 0, $limit = null)
    {
        $query = $this->getMapper()->getQuery($query);

        parent::fillSolrQuery($query, $start, $limit);

        return $query;
    }

    /**
     * @return bool|SearchPage
     */
    public function getSearchPage()
    {
        $pageId = $this->getDataValue('search-page-id');
        $searchPage = false;

        if ($pageId) {
            $searchPage = DataObject::get_by_id('SearchPage', $pageId);
        }

        if (!$searchPage) {
            $searchPage = DataObject::get_one('SearchPage', "UrlSegment = 'opac'");
        }

        return $searchPage;
    }
}
