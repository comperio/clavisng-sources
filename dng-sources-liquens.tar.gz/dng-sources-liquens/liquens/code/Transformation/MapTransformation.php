<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

/**
 * Transformation defined by a map oldValue->newValue
 */
class MapTransformation implements DefinedTransformation
{
    /**
     * An array of the map oldValue -> newValue
     * @var SplObjectStorage
     */
    protected $map;

    /**
     * @param $value
     * @return mixed
     */
    public function transform($value)
    {
        $map = $this->getCompleteMap();

        if(isset($map[$value]))
            return $map[$value];

        return $value;
    }

    /**
     * An alias of transform mehtod, that render the Transformation a callable.
     * @param $value
     * @return mixed
     */
    public function __invoke($value)
    {
        return $this->transform($value);
    }


    /**
     * @param array $map
     */
    public function __construct($map = array())
    {
        $this->map = $map;
    }

    /**
     * Returns the complete map of transformations
     * as an array oldvalue => newvalue
     *
     * @return array
     */
    public function getCompleteMap()
    {
        return $this->map;
    }
}
