<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

/**
 * Transformation defined by SS _t localization function
 */
class LocalizationTransformation implements DefinedTransformation
{
    /**
     * If this is set, calls to _t will be prefixed by a "$prefix." string.
     *
     * @var SplObjectStorage
     */
    private $prefix;

    /**
     * @var bool If true, transform the value to underscore before the transformation
     */
    private $lowerize = false;

    /**
     * @param string $prefix
     */
    public function __construct($prefix = '', $lowerize = false)
    {
        $this->prefix = $prefix;
        $this->lowerize = $lowerize;
    }

    /**
     * @param $value
     * @return mixed
     */
    public function transform($value)
    {
        $value = (string) $value;

        if ($this->lowerize)
            $value = strtolower($value);

        $key = $this->prefix ? "{$this->prefix}." . $value : $value;

        return _t($key, $value);
    }

    /**
     * An alias of transform mehtod, that render the Transformation a callable.
     * @param $value
     * @return mixed
     */
    public function __invoke($value)
    {
        return $this->transform($value);
    }

    /**
     * Returns the complete map of transformations
     * as an array oldvalue => newvalue
     *
     * @return array
     */
    public function getCompleteMap()
    {
        return i18nExtension::get_namespace_strings($this->prefix);
    }


}
