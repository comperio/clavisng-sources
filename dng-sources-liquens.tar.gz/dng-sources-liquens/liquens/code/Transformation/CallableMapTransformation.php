<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

/**
 * Transform an object into another using a map given by a callback
 */
class CallableMapTransformation implements DefinedTransformation
{
    private $callable;
    private $completeMapCallable;
    private $arguments;
    private $firstEntries;

    private $cachedMap = array();

    /**
     * @param callable $callable
     * @param array $arguments
     * @param array $firstEntries An array of key/values pairs to append at the beginning of the map
     * @param callable $completeMapCallable An optional callable for getCompleteMap. If none is provided, use $callable.
     */
    public function __construct(callable $callable, $arguments = array(), array $firstEntries = array(), $completeMapCallable = null)
    {
        $this->callable = $callable;
        $this->arguments = $arguments;
        $this->firstEntries = $firstEntries;

        $this->completeMapCallable = isset($completeMapCallable) ? $completeMapCallable : $callable;
    }

    /**
     * Returns the complete map of transformations
     * as an array oldvalue => newvalue
     *
     * @return array
     */
    public function getCompleteMap()
    {
        return $this->firstEntries + call_user_func_array($this->completeMapCallable, $this->arguments);
    }

    /**
     * @return array
     */
    private function getMap()
    {
        if (!$this->cachedMap)
	{
		$callres = call_user_func_array($this->callable, $this->arguments);
		if(is_null($callres)) $callres = [];         	
            $this->cachedMap = $this->firstEntries + $callres;
	}
        return $this->cachedMap;
    }

    /**
     * {@inheritdoc}
     */
    public function transform($value)
    {
        $map = $this->getMap();

        if(isset($map[$value]))
            return $map[$value];

        return $value;
    }

    /**
     * {@inheritdoc}
     */
    public function __invoke($value)
    {
        return $this->transform($value);
    }
}
