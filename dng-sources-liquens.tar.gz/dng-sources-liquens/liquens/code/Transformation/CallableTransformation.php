<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

/**
 * Transform an object into another using a callback
 */
class CallableTransformation implements Transformation
{
    /**
     * @var callback
     */
    private $callable;

    /**
     * @param callback $callback A callable variable
     *  (http://www.php.net/manual/en/language.pseudo-types.php#language.types.callback)
     */
    public function __construct($callback)
    {
        if (is_callable($callback)){
            $this->callable = $callback;
        }
    }

    /**
     * @param $value
     * @return mixed
     */
    public function transform($value)
    {
        if ($this->callable)
            return call_user_func($this->callable, $value);

        return $value;
    }

    /**
     * An alias of transform mehtod, that render the Transformation a callable.
     * @param $value
     * @return mixed
     */
    public function __invoke($value)
    {
        return $this->transform($value);
    }


}
