<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class TransformationCollection
{
    /**
     * The set of transformations
     * @var array
     */
    private $transformations;

    /**
     * @param array $transformations An array of Transformations objects
     */
    public function __construct($transformations = array())
    {
        foreach($transformations as $key => $transformation){
            $this->addTransformation($key, $transformation);
        }
    }

    /**
     * @param $transformationKey
     * @param Transformation $transformation
     * @return TransformationCollection
     */
    public function addTransformation($transformationKey, Transformation $transformation)
    {
        $this->transformations[$transformationKey] = $transformation;

        return $this;
    }

    /**
     * Use the transformation stored in $this->transformations[$transformationKey]
     *  to transform $value
     * @param $transformationKey
     * @param $value
     * @return mixed
     */
    public function transform($transformationKey, $value)
    {
        if (isset($this->transformations[$transformationKey])){
            return $this->transformations[$transformationKey]->transform($value);
        }

        return $value;
    }
}
