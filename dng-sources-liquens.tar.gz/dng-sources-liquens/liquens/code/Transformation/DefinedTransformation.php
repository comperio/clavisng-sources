<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

/**
 * Defined transformations are transformations with a defined domain, i.e. it is
 * possible to retrieve the complete map of trasformation
 */
interface DefinedTransformation extends Transformation
{
    /**
     * Returns the complete map of transformations
     * as an array oldvalue => newvalue
     *
     * @abstract
     * @return array
     */
    public function getCompleteMap();
}
