<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class CdfTransformation implements Transformation
{
    /**
     * @var string
     */
    private $locale;

    /**
     * @var CdfMapInterface
     */
    private $cdfMap;

    /**
     * @param null|string $locale
     * @param CdfMapInterface|null $cdfMap
     */
    public function __construct($locale = null, CdfMapInterface $cdfMap = null)
    {
        if (!isset($locale)) {
            $locale = i18n::get_locale();
        }

        if (!isset($cdfMap))
            $cdfMap = new CdfMap();

        $this->locale = $locale;
        $this->cdfMap = $cdfMap;
    }

    /**
     * Transform $value in something else
     *
     * @param mixed $value
     * @return mixed
     */
    public function transform($value)
    {
        if (!isset($value['v']))
            $value['v'] = null;

        $labels = $this->cdfMap->valueToLabels($value['n'], $value['s'], $value['p'], $value['v']);

        return sprintf('%s: %s',
            $labels['position_label'],
            isset($value['v']) ? $labels['value_label'] : $value['vf']
        );
    }

    /**
     * An alias of transform mehtod, that render the Transformation a callable.
     * @param $value
     * @return mixed
     */
    public function __invoke($value)
    {
        return $this->transform($value);
    }


}
