<?php

class GenLitTransformation extends MapTransformation {

    private $cdfMap;

    public function __construct(CdfMapInterface $cdfMap = null)
    {
        if (!isset($cdfMap))
            $cdfMap = new CdfMap();

        $this->cdfMap = $cdfMap;

        parent::__construct();
    }

    public function getCompleteMap()
    {
        if (!$this->map) {
            $this->map = array();
            foreach ($this->cdfMap->getMap('105', 'a', '11') as $key => $value) {
                $this->map['d105_sa_11_' . $key] = $value;
            }
        }
        return parent::getCompleteMap();
    }
}
