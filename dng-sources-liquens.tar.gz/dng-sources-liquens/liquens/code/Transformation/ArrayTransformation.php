<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class ArrayTransformation implements Transformation
{
    /**
     * The key are the destination keys, the values the keys
     *  where to copy data from
     *
     *
     * Example: if $copyMap is
     * <code>
     * array('a'=>'b');
     * </code>
     *
     * Then
     * <code>
     * $transformed = $this->transform(array('a' => 'avalue', 'b' => 'bvalue'));
     * </code>
     *
     * will be
     * <code>
     * array('a' => 'bvalue', 'b' => 'bvalue');
     * </code>
     *
     * @var array
     */
    private $copyMap = array();

    /**
     * Example: if $setMap is
     * <code>
     * array('a'=>'ciao', 'b'=>'hola');
     * </code>
     *
     * Then
     * <code>
     * $transformed = $this->transform(array('a' => 'notciao'));
     * </code>
     *
     * will be
     * <code>
     * array('a' => 'ciao', 'b' => 'hola');
     * </code>
     *
     * @var array
     */
    private $setMap = array();

    /**
     * Example: if $removeMap is
     * <code>
     * array('a');
     * </code>
     *
     * Then
     * <code>
     * $transformed = $this->transform(array('a' => 'notciao'));
     * </code>
     *
     * will be an empty array
     *
     * @var array
     */
    private $removeKeysMap = array();

    /**
     * An arrays of values to remove
     *
     * @var array
     */
    private $removeValuesMap = array();

    /**
     * @param array $copyMap @see copyMap
     * @param array $setMap @see setMap
     * @param array $removeKeysMap @see $removeKeysMap
     * @param array $removeValuesMap @see $removeValuesMap
     */
    public function __construct($copyMap = array(), $setMap = array(),
        $removeKeysMap = array(), $removeValuesMap = array())
    {
        $this->copyMap = $copyMap;
        $this->setMap = $setMap;
        $this->removeKeysMap = $removeKeysMap;
        $this->removeValuesMap = $removeValuesMap;
    }

    /**
     * @param mixed $value
     * @return mixed
     */
    public function transform($value)
    {
        if (is_array($value)){
            $value = $this->applyCopyMap($value);
            $value = $this->applySetValuesMap($value);
            $value = $this->applyRemoveKeysMap($value);
            $value = $this->applyRemoveValuesMap($value);
        }

        return $value;
    }

    /**
     * An alias of transform mehtod, that render the Transformation a callable.
     * @param $value
     * @return mixed
     */
    public function __invoke($value)
    {
        return $this->transform($value);
    }


    /**
     * Set the transformer to set the value of the input
     * at key $to to the value of the input at key $from
     *
     * @param integer|string $from
     * @param integer|string $to
     * @return \ArrayTransformation
     */
    public function copyValueByKey($from, $to)
    {
        $this->copyMap[$to] = $from;

        return $this;
    }

    /**
     * Set the transformer to set the value of transform
     * result, at key $key, to value $value
     *
     * @param string|integer $key
     * @param mixed $value
     * @return \ArrayTransformation
     */
    public function setValue($key, $value)
    {
        $this->setMap[$key] = $value;

        return $this;
    }

    /**
     * Tell the transformer to unset the value at index $key
     *
     * @param int|string $key
     * @return \ArrayTransformation
     */
    public function removeKey($key)
    {
        $this->removeKeysMap[] = $key;

        return $this;
    }

    /**
     * Tells the transformer to remove all entries with value=$value
     *
     * @param $value
     * @return ArrayTransformation
     */
    public function removeValue($value)
    {
        $this->removeValuesMap[] = $value;

        return $this;
    }

    /**
     * @param $value
     * @return array
     */
    private  function applyCopyMap($value)
    {
        $newValue = $value;

        foreach($this->copyMap as $to => $from){
            if(isset($value[$from]))
                $newValue[$to] = $value[$from];
        }

        return $newValue;
    }

    /**
     * @param array $input
     * @return array
     */
    private function applySetValuesMap($input)
    {
        foreach($this->setMap as $key => $value) {
            $input[$key] = $value;
        }

        return $input;
    }

    /**
     * @param array $input
     * @return array
     */
    private function applyRemoveKeysMap($input)
    {
        foreach($this->removeKeysMap as $key) {
            unset($input[$key]);
        }

        return $input;
    }

    /**
     * @param array $input
     * @return array
     */
    private function applyRemoveValuesMap($input)
    {
        foreach($input as $key => $value) {
            if (is_scalar($value) && in_array($value, $this->removeValuesMap)) {
                unset($input[$key]);
            }
        }

        return $input;
    }
}
