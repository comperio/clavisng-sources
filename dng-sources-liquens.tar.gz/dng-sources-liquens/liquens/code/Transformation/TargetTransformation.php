<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class TargetTransformation extends MapTransformation
{
    /**
     * @var CdfMapInterface
     */
    private $cdfMap;

    /**
     * Construct a Target map from a CdfMapInterface object
     * @param CdfMapInterface $cdfMap
     */
    public function __construct(CdfMapInterface $cdfMap = null)
    {
        if (!isset($cdfMap))
            $cdfMap = new CdfMap();

        $this->cdfMap = $cdfMap;

        parent::__construct();
    }

    public function getCompleteMap()
    {
        if (!$this->map) {
            $this->map = array();
            foreach ($this->cdfMap->getMap('100', 'a', '17') as $key => $value) {
                $this->map['d100_sa_17_' . $key] = $value;
            }
        }
        return parent::getCompleteMap();
    }
}
