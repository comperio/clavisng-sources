<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Isacco Occhiali <isacco@comperio.it>
 */

/**
 * Description of LqSfDate
 *
 * @author iocchiali
 */
class LqSfDate extends sfDate {
    //put your code here
    
    const DAY='d';
    const MONTH='m';
    const YEAR='Y';


    private static $en2it_day=array('Monday'=>'Luned&igrave;',
                            'Tuesday'=>'Marted&igrave;',
                            'Wednesday'=>'Mercoled&igrave;',
                            'Thursday'=>'Gioved&igrave;',
                            'Friday'=>'Venerd&igrave;',
                            'Saturday'=>'Sabato',
                            'Sunday'=>'Domenica');
    
    public static $en_months_map = array (
		'01' => 'Jan',
		'02' => 'Feb',
		'03' => 'Mar',
		'04' => 'Apr',
		'05' => 'May',
		'06' => 'Jun',
		'07' => 'Jul',
		'08' => 'Aug',
		'09' => 'Sep',
		'10' => 'Oct',
		'11' => 'Nov',
		'12' => 'Dec'
	);
	
      private static $it_months_map=array(
                '01'=>'Gennaio',
		'02'=>'Febbraio',
		'03'=>'Marzo',
		'04'=>'Aprile',
		'05'=>'Maggio',
		'06'=>'Giugno',
		'07'=>'Luglio',
		'08'=>'Agosto',
		'09'=>'Settembre',
		'10'=>'Ottobre',
		'11'=>'Novembre',
		'12'=>'Dicembre'
                );
    
    
    private static $en2it_month=array(
                'Jan'=>'Gennaio',
		'Feb'=>'Febbraio',
		'Mar'=>'Marzo',
		'Apr'=>'Aprile',
		'May'=>'Maggio',
		'Jun'=>'Giugno',
		'Jul'=>'Luglio',
		'Aug'=>'Agosto',
		'Sep'=>'Settembre',
		'Oct'=>'Ottobre',
		'Nov'=>'Novembre',
		'Dec'=>'Dicembre'
                );
    
    /**
     * Retrieves the given unit of time from the timestamp.
     *
     * @param	int	unit of time (accepts sfTime constants).
     * @return	int	the unit of time
     *
     * @throws	sfDateTimeException
     */
    public function retrieveItalianDate($unit = LqSfDate::DAY,$timestamp=0)
    {
        switch ($unit)
        {
            case LqSfDate::DAY:
                    $dayname=date('l',$timestamp);
                    return LqSfDate::$en2it_day[$dayname];
            case LqSfDate::MONTH:
                    $monthname=date('m',$timestamp);
                    return LqSfDate::$it_months_map[$monthname];
            case LqSfDate::YEAR:
                    return date('Y', $timestamp);
            
            case LqSfDate::ONEDAYHEADER:
                    return date('W', $timestamp);
            case LqSfDate::ONEMONTHHEADER:
                    return date('m', $timestamp);
            case LqSfDate::ONEYEARHEADER:
                    return date('Y', $timestamp);
            
            default:

        }
    }
        
    
    
}

?>
