<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

/**
 * This controller takes the first part of the URL segment, stores it in the $lang
 * static property and changes the locale based on this segment, and then handle the request
 * as if the lang segment was not present.
 */
class LangController extends Controller
{
    /**
     * The rule pattern used to route the request to this controller
     */
    const DIRECTOR_RULE = '$Lang/$URLSegment//$Action/$ID/$OtherID';

    /**
     * @var bool|string The lang code fetched from the URL
     */
    public static $lang = true;

    /**
     * @var The url of the original request
     */
    public static $original_url;

    /**
     * @static
     * @return string
     */
    public static function localeAntisegment()
    {
        if (static::$lang)
            return '../';

        return '';
    }

    /**
     * @static
     * @return string
     */
    public static function localeSegment()
    {
        if (static::$lang)
            return static::$lang . '/';

        return '';
    }

    /**
     * Returns the locale like as no lang was specified in the url
     *
     * @static
     * @return bool|string
     */
    public static function get_ignoredurl_locale()
    {
        if ($locale = static::get_member_locale())
            return $locale;

        return static::get_conf_locale();
    }

    /**
     * Returns the locale used to visualize the page. It is supposed that
     * self::$lang has already been set properly
     *
     * @static
     * @return string
     */
    public static function get_current_locale()
    {
        if ($locale = static::get_url_locale())
            return $locale;

        return static::get_ignoredurl_locale();
    }

    /**
     * Returns the locale given by the url, or false if the url
     * does not specify a locale. It is supposed that
     * self::$lang has already been set properly
     *
     * @static
     * @return bool|string The URL locale
     */
    public static function get_url_locale()
    {
        if (static::$lang)
            return i18n::get_locale_from_lang(static::$lang);

        return false;
    }

    /**
     * Returns the current member's locale, or false if there is
     * no active member
     * @static
     * @return string|bool The member's locale
     */
    public static function get_member_locale()
    {
        $member = Member::currentUser();

        if($member)
            return $member->Locale;

        return false;
    }

    /**
     * Returns the default locale
     *
     * @static
     * @return String the default locale
     */
    public static function get_default_locale()
    {
        return i18n::default_locale();
    }

    /**
     * Returns the configuration locale
     *
     * @static
     * @return String the configuration locale
     */
    public static function get_conf_locale()
    {
        global $sc;

        return $sc->getParameter('default_locale');
    }

    /**
     * Set the $locale as current locale and enable LqTranslated.
     *
     * @static
     * @param $locale
     */
    public static function init_current_locale($locale)
    {
        i18n::set_locale($locale);
        Translatable::set_current_locale($locale);
        setlocale(LC_ALL, "$locale.utf8", "$locale.UTF-8", $locale);

        global $kernel;
        $kernel->includeLangFiles($locale);
    }

    /**
     * Enable the translations for lqtranslatedpages
     *
     * @param $locale
     */
    public static function init_lqtranslate($locale)
    {
        if ($locale != static::get_default_locale()){
            LqTranslatedPage::$enabled = true;
            LqTranslatedDataObject::$enabled = true;
        }


    }

    /**
     * Change the current language redirecting to the same current page
     * with the lang segment, if necessary, set to $lang
     * @static
     * @param $lang
     * @return bool
     */
    public static function change_language($lang)
    {
       Director::redirect(static::get_current_url_localized($lang));
    }

    /**
     * Change the current language with the lang segment,
     * if necessary, set to $lang
     *
     * @static
     * @param $lang
     * @return string
     */
    public static function get_current_url_localized($lang)
    {
        $locale = i18n::get_locale_from_lang($lang);

        if (in_array($locale, Translatable::get_allowed_locales())) {
           $realLang = $lang;
           $memberLocale = static::get_member_locale();
           $memberLang = $memberLocale ?
                   i18n::get_lang_from_locale($memberLocale)
                   : false
           ;
           $defaultLang = i18n::get_lang_from_locale(static::get_conf_locale());

           //if the member is logged and his lang is equal to $lang
           // or if he is anonymous and the default lang is equal to $lang
           // I remove the lang segment
            if (
                ($memberLang && $memberLang == $lang)
                || (!$memberLang && $defaultLang == $lang)
            ){
                $realLang = '';
            }

            //Build the absolute url
            $url = Director::baseURL() . static::get_url_without_lang_segment(static::$original_url);
            $url = static::change_lang_segment(
                   $url,
                   $realLang
               );

            //Append query string arguments
            $queryArgs = array_diff_key($_GET, array('url' => '', 'change-lang' => ''));
            if ($queryArgs)
                $url .= '?' . http_build_query($queryArgs);

           return $url;
        }

        return static::$original_url;
    }

    /**
     * Remove the lang segment from the URL. It is supposed that self::$lang
     * has already been set properly.
     * It is supposed that self::$lang has already been set.
     *
     * @static
     * @param $url
     * @return string
     */
    public static function get_url_without_lang_segment($url)
    {
        return static::change_lang_segment($url, '');
    }

    /**
     * Manipulate the $url adding or changing the lang segment given by $lang
     * It is supposed that self::$lang has already been set.
     * If the url is absolute, i.e. starting with a slash, the lang segment position
     * is calculated taking into account Director's baseURL (for example
     * '/~nic/dng/it/community'. Otherwise it is supposed
     * to be in first position, like in 'it/community'.
     *
     * @static
     * @param $url The url to change  the lang segment to.
     *   It can be absolute (starting with /) or relative.
     * @param $lang The lang segment (i.e. it or en)
     * @return string The modified url
     */
    public static function change_lang_segment($url, $lang)
    {
        if (isset($url[0]) && $url[0] == '/') {
            $baseUrl = Director::baseURL();
            $secondPartUrl = substr($url, strlen($baseUrl));
            $pieces = explode('/', $baseUrl);

            //The first pop remove the final slash, the second the lang segment
            array_pop($pieces);
            if (static::$lang){
                array_pop($pieces);
            }

            //The first push add the lang segment, the second one the final slash
            if ($lang)
                array_push($pieces, $lang);
            array_push($pieces, '');

            return implode('/', $pieces) . $secondPartUrl;

        } else {

            $pieces = explode('/', $url);

            if (static::$lang)
                array_shift($pieces);

            if($lang)
                array_unshift($pieces, $lang);

            $result = implode('/', $pieces);
            return $result;
        }

    }

    /**
     * @return void
     */
    public function init()
    {
        $urlLang = $this->getUrlLang();
        static::$lang = $urlLang;
        static::$original_url = $this->request->getURL();
        
        if ($urlLang)
            Director::setBaseURL(Director::baseURL() . $urlLang . '/');

        parent::init();
    }


    /**
     * Returns the lang code based on request's URL
     *
     * @return string the Lang code
     */
    public function getUrlLang()
    {
        $locale = $this->getUrlLocale();

        if ($locale){
            return i18n::get_lang_from_locale($locale);
        }

        return false;
    }

    /**
     * Returns the Locale string based on request's URL
     *
     * @return string
     */
    public function getUrlLocale()
    {
        $lang = $this->request->param('Lang');
        $locale = i18n::get_locale_from_lang($lang);

        if (in_array($locale, Translatable::get_allowed_locales())){
            return $locale;
        }
        return false;
    }

    /**
     * Build a request, based on the current one, removing the lang segment
     * 
     * @return SS_HTTPRequest
     */
    private function getRequestWithoutLangSegment()
    {
        $req = new SS_HTTPRequest(
			$this->request->httpMethod(),
			static::get_url_without_lang_segment($this->request->getURL()),
			$this->request->getVars(),
			$this->request->postVars(),
			$this->request->getBody()
		);

        foreach($this->request->getHeaders() as $header => $value ) {
            $req->addHeader($header, $value);
        }

        return $req;
    }

    /**
     * The Direcor's URL rules
     *
     * @return array
     */
    private function getDirectorRules()
    {
        //Hack... Director's rule property is protected... :-|
        $reflection = new ReflectionClass('Director');
        $staticProps = $reflection->getStaticProperties();
        $dirRules = $staticProps['rules'];

        foreach($dirRules as &$patterns){
            foreach($patterns as $pattern => $controller){
                if ($pattern == self::DIRECTOR_RULE)
                    unset($patterns[$pattern]);
            }
        }

        return $dirRules;
    }

    /**
     * Returns true for controllers for wich LqTranslated has to be enabled
     *
     * @param Controller $controller
     * @return bool
     */
    private function isTranslableController(Controller $controller)
    {
        return
            $controller instanceof ModelAsController
            || $controller instanceof RootURLController
            || $controller instanceof AdvancedSearchFieldController
            || $controller instanceof DataController
            || $controller instanceof ShelfPage_Controller
        ;
    }

    /**
     * Replicates the behavior of Director::handleRequest.
     * It removes the lang segment from the request, and acts as if the
     * request was without the lang segment.
     *
     * @param SS_HTTPRequest $inputReq
     * @return string
     */
    public function handleRequest(SS_HTTPRequest $inputReq)
    {
        $this->request = $inputReq;
        $this->init();
        $this->pushCurrent();
        
        $request = $this->getRequestWithoutLangSegment();
        $session = $this->session;

        $dirRules = $this->getDirectorRules();

		krsort($dirRules);

		if(isset($_REQUEST['debug'])) Debug::show($dirRules);
		foreach($dirRules as $priority => $rules) {
			foreach($rules as $pattern => $controllerOptions) {
				if(is_string($controllerOptions)) {
					if(substr($controllerOptions,0,2) == '->') $controllerOptions = array('Redirect' => substr($controllerOptions,2));
					else $controllerOptions = array('Controller' => $controllerOptions);
				}

				if(($arguments = $request->match($pattern, true)) !== false) {
					// controllerOptions provide some default arguments
					$arguments = array_merge($controllerOptions, $arguments);

					// Find the controller name
					if(isset($arguments['Controller'])) $controller = $arguments['Controller'];

					// Pop additional tokens from the tokeniser if necessary
					if(isset($controllerOptions['_PopTokeniser'])) {
						$request->shift($controllerOptions['_PopTokeniser']);
					}

					// Handle redirections
					if(isset($arguments['Redirect'])) {
						return "redirect:" . Director::absoluteURL($arguments['Redirect'], true);

					} else {
						$controllerObj = new $controller();
                        $controllerObj->setSession($session);

                        $this->init_current_locale($this->get_current_locale());
                        if ($this->isTranslableController($controllerObj)){
                            $this->init_lqtranslate($this->get_current_locale());
                        }

						return $controllerObj->handleRequest($request);
					}
				}
			}
		}
	}
}
