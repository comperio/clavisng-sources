<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

interface CdfMapInterface
{
    /**
     * Returns a map of codes => labels for cdf fields.
     * The map are hierarchical. If you specify no arguments, you will get the map of all macro-fields area
     * If you specify the field, you will get the map of subfield => labels for that field... and so on.
     *
     * @param null|string $field
     * @param null|string $subfield
     * @param null|string $position
     * @param null|string $value
     * @return string|array
     */
    public function getMap($field = null, $subfield = null, $position = null, $value = null);

    /**
     * @param null|string $field
     * @param null|string $subfield
     * @param null|string $position
     * @param null|string $value
     * @return mixed
     */
    public function valueToLabels($field = null, $subfield = null, $position = null, $value = null);
}
