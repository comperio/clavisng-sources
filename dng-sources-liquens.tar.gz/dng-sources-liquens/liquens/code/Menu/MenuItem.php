<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

class MenuItem extends DataObject
{
    public static $db = array(
        'Name' => 'VarChar(255)',
        'URI' => 'VarChar(255)',
        'Position' => 'DBInt',
        'Locale' => 'VarChar(7)',
        'Protected' => 'Boolean',
        'Type' => "Enum('internal,external,none,header,divider','external')"
    );

    public static $has_one = array(
        'Page' => 'SiteTree',
        'Parent' => 'MenuItem'
    );

    public static $has_many = array(
        'Children' => 'MenuItem.Parent'
    );

    public static $defaults = array(
        'URI' => '',
        'ParentID' => 0,
        'PageID' => 0,
        'Protected' => false,
        'Type' => 'external'
    );

    public static $indexes = array(
        'Name' => true,
        'ParentID' => true
    );

    /**
     * Build a menu from a sitetree page.
     *
     * @param SiteTree $page If null, retrieve all first-level pages
     * @param int $position
     * @param int $deep The max nesting level
     * @param array $exclude An array of url segments to exclude
     *
     * @return MenuItem
     */
    public static function create_from_sitetree(SiteTree $page = null, $position = 1, $deep = 2, $exclude = array())
    {
        $menuItem = new MenuItem;
        $menuItem->Position = $position;

        if ($page) {
            $menuItem->Name = $page->MenuTitle;
            $menuItem->PageID = $page->ID;
            $menuItem->Locale = $page->Locale;
            $menuItem->Type = 'internal';
            $children = $page->Children();
        } else {
            $children = DataObject::get("SiteTree", "\"ShowInMenus\" = 1 AND \"ParentID\" = 0") ?: new DataObjectSet();
        }

        $menuItem->write();

        if ($deep > 0) {
            $i = 1;
            foreach ($children as $childPage) {
                if (!$childPage->isPublished())
                    continue;
                echo $childPage->RelativeLink(), '<br>';
                if (in_array(static::removeTrailingSlash($childPage->RelativeLink()), $exclude))
                    continue;
                $menuItem->Children()->add(self::create_from_sitetree($childPage, $i, $deep - 1));
                $i++;
            }
        }
        return $menuItem;
    }

    /**
     * Limit the delete permission of protected menus
     * @param null $member
     * @return bool
     */
    public function canDelete($member = null)
    {
        return Permission::checkMember($member, 'ADMIN')
            || (!$this->Protected &&  $this->canEdit($member))
        ;
    }

    /**
     * CanEdit permission: check "CMS_ACCESS_MenuAdmin" permission
     *
     * @param null $member
     * @return bool|int
     */
    public function canEdit($member = null)
    {
        return Permission::checkMember($member, 'CMS_ACCESS_MenuAdmin');
    }

    /**
     * For Protected menus language and name must be editable only by admins.
     *
     * @param null $member
     * @return bool
     */
    public function canEditNameAndLanguage($member = null)
    {
        return $this->canDelete($member);
    }

    /**
     * Creation permissions: same as canEdit permission
     *
     * @param null $member
     * @return bool|int
     */
    public function canCreate($member = null)
    {
        return $this->canEdit($member);
    }
    /**
     * Tell if the item is linkable or not.
     * @return bool
     */
    public function isLinkable()
    {
        return $this->getLinkType() == 'internal' || $this->getLinkType() == 'external';
    }

    /**
     * The link this menu item  points to
     *
     * @return mixed
     */
    public function getLink()
    {
        if (!$this->isLinkable())
            return '#';

        if ($this->getLinkType() == 'internal') {
            if ($page = $this->Page()) {
                $link = $page->RelativeLink();
                //Home page and base href problem with relative link: it must not be '/' but ''
                return $link == '/' ? '' : $link;
            }
        }

        return $this->URI;
    }

    /**
     * @param null $params
     * @return FieldSet
     */
    public function getCMSFields($params = null)
    {
        $fields = new FieldSet();

        // We have to use LazyLiteralField in order to prevent caching issue (the form is loaded twice on saving,
        // the first time before the menuitem is updated)
        $that = $this;
        $fields->push(new LazyLiteralField('', function() use ($that) { return $that->renderWith('MenuItemForm'); }));

        return $fields;
    }

    /**
     * Build a DOS for locale options to be used in CMS.
     * @return DataObjectSet
     */
    public function getLocaleOptions()
    {
        $locales = Translatable::get_allowed_locales();

        $options = new DataObjectSet();

        foreach ($locales as $locale) {
            $options->push(new DataObject(array(
                'Value' => $locale,
                'Label' => i18n::get_language_name(i18n::get_lang_from_locale($locale), false),
                'Selected' => $locale == $this->Locale
            )));
        }

        return $options;
    }

    /**
     * @return string
     */
    public function getSubitemFields()
    {
        return  $this->renderWith('MenuItemFields');
    }

    /**
     * @return string
     */
    public function getSubitemsFields()
    {
        return $this->renderWith('MenuItemsFields');
    }


    /**
     * Get the sorted list of subitems, enriched with context and index informations
     *
     * @param null|int $limit The maximum number of items.
     * @return mixed
     */
    public function getMenuSubitems($limit = null)
    {
        $children = $this->Children();
        $children->sort('Position');

        if (!$this->Context)
            $this->Context = '';

        $i = 1;
        $results = new DataObjectSet();

        //Set index, context, and rewrite position
        foreach ($children as $child) {
            $results->push($child);
            $child->Index = $child->Position = $i;
            $child->Context = $this->getNamespacedValue($i, $this->getSubitemsContext($this->Context));
            $i++;

            if ($limit && $i > $limit)
                break;
        }

        return $results;
    }

    /**
     * Returns the parent context for all menuitems
     * i.e. Subitems for the root node or
     * context[Subitems] for descendants nodes
     *
     * @param $context
     * @return string
     */
    public function getSubitemsContext($context)
    {
        return $this->getNamespacedValue('Subitems', $context);
    }

    /**
     * Get the namespaced value, used for namespacing name attributes in form fields
     *
     * @param $value
     * @return string
     */
    public function Contextualized($value)
    {
        return $this->getNamespacedValue($value, $this->Context);
    }

    /**
     * A namespacing helper function
     * @param $attr
     * @param $context
     * @return string
     */
    public function getNamespacedValue($attr, $context)
    {
        if (!$context)
            return $attr;

        return $context . '[' . $attr . ']';
    }

    /**
     * Is this item a root one, i.e. a menu?
     *
     * @return bool
     */
    public function isMenu()
    {
        return $this->ParentID == 0;
    }

    /**
     * Return true if the item has children or if a Group property is set to true
     * @return bool
     */
    public function isGroup()
    {
        return $this->Children()->Count() > 0
            || $this->Group;
    }

    public function getLinkType()
    {
        return $this->Type;
    }

    /**
     * Tell if the viewed page is the page linked from this item
     *
     * @return bool
     */
    public function isCurrent()
    {
        $current = false;

        if ($this->isLinkable()) {
            $url = Controller::curr()->getRequest()->getURL();
            $menuUri = $this->removeTrailingSlash($this->getLink());

            if ($menuUri) {
                $current = !strncmp($url, $menuUri, strlen($menuUri));
            } else {
                //the menu uri in this case is the home page
                $current = $this->removeTrailingSlash($url) == 'home' || $url == '';
            }
        }

        foreach ($this->Children() as $child) {
            $current = $current || $child->isCurrent();
        }

        return $current;
    }

    /**
     * Tell if the item is viewable by the current user.
     */
    public function isViewable()
    {
        if ($this->getLinkType() != 'internal')
            return true;

        return $this->Page()->canView();
    }

    /**
     * Recursively save subitems as children of this item,
     * where $data is an array of data for subitems, like the one returned by MenuAdmin edit form
     *
     * @param array $data
     */
    public function saveSubitems($data)
    {
        foreach ($data as $subitemData) {
            if ($subitemData['ID']) {
                $subitem = DataObject::get_by_id('MenuItem', (int) $subitemData['ID']);
            } else {
                $subitem = new MenuItem;
                $this->Children()->add($subitem);
            }

            $subitem->Name = $subitemData['Name'];
            $subitem->URI = isset($subitemData['URI']) ? $subitemData['URI'] : '#';
            $subitem->Position = $subitemData['Position'];
            $subitem->Type = $subitemData['Type'];
            $subitem->PageID = $subitemData['Type'] != 'internal'
                ? 0
                : ((int) $subitemData['PageID'])
            ;
            $subitem->write();

            if (isset($subitemData['Subitems'])) {
                $subitem->saveSubitems($subitemData['Subitems']);
            }
        }
    }

    /**
     * Recursively delete all child menuitems
     */
    public function deleteSubitems()
    {
        foreach ($this->Children() as $child) {
            if ($child->canDelete(Member::currentUser())) {
                $child->delete();
            }
        }
    }

    /**
     * Delete subitems too when deleting an item
     */
    public function delete()
    {
        $this->deleteSubitems();
        parent::delete(); // TODO: Change the autogenerated stub
    }


    /**
     * Name attribute for subvoices and
     * @param $index
     * @param $name
     * @return string
     */
    private function subvoiceNameAttr($index, $name, $subindex = null)
    {
        return isset($subindex)
            ? "Subvoices[$index][Subvoices][$subindex][$name]"
            : "Subvoices[$index][$name]"
        ;
    }

    private static function removeTrailingSlash($string)
    {
        if (substr($string, -1) == '/')
            return substr($string, 0, -1);

        return $string;
    }
}