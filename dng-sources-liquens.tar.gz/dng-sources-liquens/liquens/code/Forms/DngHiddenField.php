<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

class DngHiddenField extends HiddenField
{
    private $attributes = array();

    /**
     * Add an html attribute to the input tag
     *
     * @param string $name
     * @param string $value
     * @return DngHiddenField
     */
    public function addAttribute($name, $value)
    {
        $this->attributes[$name] = $value;

        return $this;
    }

    /**
     * Renders the field to html code
     *
     * @return string
     */
    public function Field()
    {
        $parentField = parent::Field();
        $fieldWithoutEndingTag = substr($parentField, 0, -2);

        foreach ($this->attributes as $name => $value) {
            $fieldWithoutEndingTag .= sprintf(
                ' %s="%s"',
                $name,
                Convert::raw2att($value)
            );
        }

        return $fieldWithoutEndingTag . '/>';
    }
}