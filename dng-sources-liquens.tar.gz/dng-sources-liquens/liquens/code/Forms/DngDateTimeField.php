<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

class DngDateTimeField extends DngCompositeField
{
    function __construct($name, $title = null, $value = "", $dateLabel = "", $timeLabel = "")
    {
        parent::__construct($name, $title, $value);

        $this->registerField('date', $dateField = new TextField('date', $dateLabel));
        $dateField->addExtraClass('jqueryDatePicker');
        $this->registerField('time', new TimeField('time', $timeLabel));

        //$dateField->
    }

    /**
     * @param $value
     * @return mixed
     */
    public function normalizeValue($value)
    {
        $normalized = array();

        $pieces = explode(' ', $value);

        $normalized['date'] = $pieces[0];

        if (isset($pieces[1]))
            $normalized['time'] = $pieces[1];

        return $normalized;
    }

    /**
     * @param $value
     * @return mixed
     */
    public function denormalizeValue($value)
    {
        return implode(' ', $value);
    }

}