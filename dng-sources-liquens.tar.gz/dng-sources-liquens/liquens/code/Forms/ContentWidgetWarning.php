<?php
/*
 * This file is part of dng.
 *
 * (c) 2013 Nicolò Martini
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

class ContentWidgetWarning
{
    /**
     * @var SiteTree
     */
    private $page;

    /**
     * @var string
     */
    private $areaName;

    /**
     * @var bool
     */
    private $isGrid;

    /**
     * @param SiteTree $page
     * @param string $areaName
     * @param bool $isGrid
     */
    public function __construct(SiteTree $page, $areaName = 'WidgetArea', $isGrid = true)
    {
        $this->page = $page;
        $this->areaName = $areaName;
        $this->isGrid = $isGrid;
    }

    /**
     * Tells if the widget area has an appropriate Content Widget linked to it
     *
     * @return bool
     */
    public function hasContentWidget()
    {
        foreach ($this->getWidgets() as $widget) {
            if ($this->isContentWidget($this->getRealWidget($widget)))
                return true;
        }

        return false;
    }


    /**
     * The page has a non empty template?
     *
     * @return bool
     */
    public function hasPageContent()
    {
        return (bool) trim($this->page->Content);
    }

    /**
     * The message. Empty if the page already has a content widget
     * @return string
     */
    public function __toString()
    {
        if (!$this->hasPageContent() || $this->hasContentWidget())
            return '';

        return "<div class='content-widget-warning'>"
            . sprintf(_t('CMS.CONTENTWIDGET_WARNING'), $this->areaName)
            . "</div>"
        ;
    }

    /**
     * Return the undelrying widget if $widget is a GridWidget.
     *
     * @param Widget $widget
     * @return Widget
     */
    private function getRealWidget(Widget $widget)
    {
        if (!$this->isGrid || !$widget instanceof GridWidget)
            return $widget;

        return $widget->Widget();
    }

    /**
     * @param Widget $widget
     *
     * @return bool
     */
    private function isContentWidget(Widget $widget)
    {
        return $widget instanceof ContentWidget
            && in_array($widget->PageID, array(0, $this->page->ID));
    }

    /**
     * @return Widget[]
     */
    private function getWidgets()
    {
        $areaName = $this->areaName;

        return $this->page->$areaName()->Widgets();
    }
}