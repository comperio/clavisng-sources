<?php
 /**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

/**
 * Class LazyLiteralField: A lazy version of LiteralField, build to resolve a caching issue with
 * forms and literal fields filled in with a ViewableData::renderWith method
 */
class LazyLiteralField extends DatalessField {

	/**
	 * @var string $content
	 */
	protected $function;

	function __construct($name, $function) {
		$this->function = $function;

		parent::__construct($name);
	}

	function FieldHolder() {
		return $this->getContent();
	}

	function Field() {
		return $this->FieldHolder();
	}

	/**
	 * @return string
	 */
	function getContent() {
		return call_user_func($this->function);
	}

	/**
	 * Do nothing
	 */
	function setValue($value) {

	}

	function performReadonlyTransformation() {
		$clone = clone $this;
		$clone->setReadonly(true);
		return $clone;
	}
}