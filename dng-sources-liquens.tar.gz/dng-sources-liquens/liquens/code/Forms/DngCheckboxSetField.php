<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class DngCheckboxSetField extends CheckboxSetField
{
    private $headerLinks = array();

    /**
     * Bootstrap method
     *
     * @return DngCheckboxSetField The current instance
     */
    public function init()
    {
        $this
            ->addHeaderLink('selectAll', 'Select All')
            ->addHeaderLink('deselectAll', 'Deselect All')
            ->addHeaderLink('invert', 'Invert Selection')
        ;

        Requirements::javascript('liquens/javascript/cms/dngcheckboxsetfield.js');

        return $this;
    }

    /**
     * HTML to put at the tob of the checkboxsetfield
     *
     * @return string
     */
    public function getHeader()
    {
        return $this->getRenderedHeaderLinks();
    }

    /**
     * @return string
     */
    public function Field()
    {
        $this->init();
        return $this->renderWith(array('DngCheckboxSet'));
    }

    /**
     * @return string
     */
    public function Body()
    {
        return parent::Field();
    }

    /**
     * @param $name
     * @param $label
     * @return DngCheckboxSetField The current instance
     */
    public function addHeaderLink($name, $label)
    {
        $this->headerLinks[$name] = _t('DngCheckboxesButtons.' . strtoupper($name) , $label);

        return $this;
    }

    /**
     * @return DataObjectSet
     */
    public function getHeaderLinks()
    {
        $links = new DataObjectSet();

        foreach($this->headerLinks as $name => $label) {
            $links->push(new ArrayData(array(
                'Name' => $name,
                'Label' => $label,
            )));
        }

        return $links;
    }
}
