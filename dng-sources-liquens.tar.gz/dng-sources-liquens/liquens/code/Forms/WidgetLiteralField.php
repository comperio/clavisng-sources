<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

/**
 * Since Widget::CMSEditor iterate through all widget fields and call setValue on each of them,
 * it was not possible to use a literal field in a widget, because setValue method, for
 * literal fields, sets the content.
 *
 * We then overwrite the metod making it do nothing
 */
class WidgetLiteralField extends LiteralField
{
    /**
     * @param $value
     * @return FormField|void
     */
    public function setValue($value)
    {

    }

}