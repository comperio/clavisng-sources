<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

abstract class DngCompositeField extends FormField
{
    /**
     * @var FormField[]
     */
    protected $fields;

    /**
     * A normalized form of value, in the form
     * 'subfieldname' => 'subfieldvalue'
     * @var array
     */
    protected $normalizedValue;

    /**
     * @param The $name
     * @param null $title
     * @param string $value
     */
    function __construct($name, $title = null, $value = "")
    {
        parent::__construct($name, $title, $value);
    }

    /**
     * @param $name
     * @param FormField $field
     */
    public function registerField($name, FormField $field)
    {
        $this->fields[$name] = $field;

        $field->setName($this->name . '[' . $field->name . ']');
    }

    /**
     * @param $form
     */
    public function setForm($form)
    {
   		parent::setForm($form);

        foreach ($this->fields as $field) {
            $field->setForm($form);
        }
   	}

    /**
     * @param $value
     */
    public function setValue($value)
    {
        parent::setValue($value);

        if (is_array($value)) {
            $this->normalizedValue = $value;
        } else {
            $this->normalizedValue = $this->normalizeValue($value);
        }

        foreach ($this->normalizedValue as $name => $subvalue) {
            if (isset($this->fields[$name])) {
                $this->fields[$name]->setValue($subvalue);
            }
        }
    }

    function dataValue()
    {
        return $this->denormalizeValue($this->normalizedValue);
    }

    public function Value()
    {
        return $this->denormalizeValue($this->normalizedValue);
    }

    /**
     * @return string
     */
    public function Field()
    {
   	    $result = '';

        foreach ($this->fields as $field) {
            $result .= $field->FieldHolder();
        }

        return $result;
   	}

    /**
     * @param $value
     * @return mixed
     */
    abstract public function normalizeValue($value);

    /**
     * @param $value
     * @return mixed
     */
    abstract public function denormalizeValue($value);
}