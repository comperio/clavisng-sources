<?php
/*
 * This file is part of dng-git.
 *
 * (c) 2013 Nicolò Martini
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

/**
 * A simple class used to sectioning forms in the CMS
 */
class FormSectionTitle extends LiteralField
{
    function __construct($content)
    {
        parent::__construct('', "<h3 class='form-section-title'>$content</h3>");

    }

}
