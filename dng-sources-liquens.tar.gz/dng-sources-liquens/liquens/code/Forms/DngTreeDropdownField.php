<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

class DngTreeDropdownField extends DngHiddenField
{
    function __construct($name, $title = null, $value = null, $form = null, $rightTitle = null)
    {
        parent::__construct($name, $title, $value, $form, $rightTitle);

        $this->addExtraClass('select2single');
    }

    /**
     * Load attributes before rendering the fields
     *
     * @return string
     */
    public function Field()
    {
        $this->loadAttributes();
        return parent::Field();
    }

    /**
     * Load the map page-id -> page-title as html5 data attributes
     *
     * @return DngTreeDropdownField The current instance
     */
    public function loadAttributes()
    {
        if (!$this->value)
            return $this;

        $page = DataObject::get_by_id('SiteTree', (int) $this->value);

        if ($page)
            $this->addAttribute('data-page-' . $page->ID, $page->Title);

        return $this;
    }
}
