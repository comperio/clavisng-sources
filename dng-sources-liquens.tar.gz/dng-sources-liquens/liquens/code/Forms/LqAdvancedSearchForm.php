<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

class LqAdvancedSearchForm extends ViewableData
{
    /**
     *  Un array le cui chiavi sono i nomi dei campi Solr
     *  che saranno inclusi nei campi mappati con autocompletamento
     *  Può essere popolato con LqAdvancedSearchForm::loadAvaiableFacets.
     * @var array
     */
    public $avaiableFacets = array();

    /**
     * @var array La configurazione dei campi, come in SolrQueryMapper::configuration
     */
    public $fieldsConfiguration = array();

    /**
     * @var array La lista dei campi da mostrare nel dropdown del tipo di campo
     */
    public $fieldTypes = array();

    /**
     * @var array Default fields shown by the form
     * [0] => array('fieldName' => 'nomeCampo', 'value' => 'valore'), ...
     */
    public $defaultFields = array();

    /**
     * @var array Campo da aggiungere in Javascript
     */
    public $defaultJsField = array('fieldName' => 'q', 'value' => '');

    /**
     * @var int Indice di partenza per la numerazione dei campi
     */
    public $startFieldIndx = 1;

    /**
     * @var int Indice di partenza per la numerazione dei fieldset
     */
    public $startGrpIndx = 1;

    /**
     * @var array Lista degli operatori ammissibili
     */
    public $allowedOperators =  array(
        'and' => 'tutti (AND)', 'or' => 'almeno uno (OR)', 'not' => 'nessuno (NOT)'
    );

    /**
     * @var string operatore di default utilizzato nel primo fieldset
     */
    public $defaultOp = 'and';

    /**
     * @var string operatore di default utilizzato nell'aggiunta dei fieldset
     * in JavaScript
     */
    public $defaultJsOp = 'or';

    /**
     * @var array
     */
    private $mapAry = array();

    /**
     * @param array $configuration
     * @param array $fieldTypes
     * @param array $allowedOps
     */
    public function __construct(array $configuration, array $fieldTypes, array $allowedOps)
    {
        $this->fieldsConfiguration = $configuration;
        $this->fieldTypes = $fieldTypes;
        $this->allowedOperators = $allowedOps;
        // translate allowedOperators
        $this->allowedOperators = array(
            'and' => _t('LqAdvancedSearchForm.AND','All (AND)'), 'or' => _t('LqAdvancedSearchForm.OR','at least one (OR)'), 'not' => _t('LqAdvancedSearchForm.NOT','none (NOT)')
        );
        
    }

    /**
     * @return int Ritorna l'indice dell'ultimo campo
     */
    public function getLastFieldIndex()
    {
        return $this->startFieldIndx + count($this->defaultFields) -1;
    }

    /**
     * @return int Ritorna l'indice dell'ultimo gruppo di campi
     */
    public function getLastGrpIndex()
    {
        return $this->startGrpIndx;
    }

    /**
     * Returns the DataObjectSet for the fieldtype dropdown
     * 
     * @param bool $selectedField
     * @return DataObjectSet
     */
    public function FieldTypes($selectedField = false)
    {
        $fieldsAryCopy = clone($this->getFieldsDO());
        $selectedFieldDO = $fieldsAryCopy->find('FieldName', $selectedField);

        //Se il campo non è presente, prendo il primo di fieldsAry
        if(!$selectedFieldDO){
            $selectedFieldDO = $fieldsAryCopy->First();
        }

        $selectedFieldCopy = clone($selectedFieldDO);
        $selectedFieldCopy->setField('Selected', true);
        $fieldsAryCopy->replace($selectedFieldDO, $selectedFieldCopy);
        
        $fieldsOrderedAryCopy = $fieldsAryCopy;
        $fieldsOrderedAryCopy->sort("Label");
        
        return $fieldsOrderedAryCopy;
    }

    /**
     * Returns the DataObject representing a field of the Form
     *
     * @param string $fieldName
     * @param string $value
     * @param int|string $index
     * @param int|string $grpIndex
     *
     * @return string
     */
    public function FormField(
        $fieldName, $value = '', $index = false, $grpIndex = 1
    )
    {
        static $automaticIndex = 0;

        if ($index === false){
            $automaticIndex++;
            $index = $automaticIndex;
        }

        $advFieldController = new AdvancedSearchFieldController();

        return $advFieldController->renderField($fieldName, 'value_' . $index);
    }

    /**
     * Returns the DataObject representing a field of the Form, complete with field type input
     *
     * @param string $fieldName
     * @param string $value
     * @param int|string $index
     * @param int|string $grpIndex
     *
     * @return string
     */
    public function StandaloneFormField(
        $fieldName, $value = '', $index = false, $grpIndex = 1
    )
    {
        static $automaticIndex = 0;

        if ($index === false){
            $automaticIndex++;
            $index = $automaticIndex;
        }

        $advFieldController = new AdvancedSearchFieldController();

        $renderedField = $advFieldController->renderField($fieldName, 'value_' . $index);

        $data = new DataObject(array(
            'RenderedField' => $renderedField,
            'Index' => $index,
            'FieldName' => $fieldName,
            'Value' => $value,
        ));

        return $data->renderWith('AdvancedSearchField');
    }

    /**
     * Build a form row.
     *
     * @param $fieldName
     * @param $value
     * @param int $index
     * @param int $grpIndex
     * @return DataObject
     */
    public function FormRow($fieldName, $value, $index = 1, $grpIndex = 1)
    {
        return new DataObject(array(
               'Index' => $index,
               'GrpIndex' => $grpIndex,
               'FieldTypes' => $this->FieldTypes($fieldName),
               'FormField' => $this->FormField($fieldName, $value, $index, $grpIndex),
               'FieldName' => $fieldName,
          ));
    }

    /**
     * Build a group of the advanced search form
     *
     * @param array $fields
     * @param string $operator Tipo di match
     * @param int|string $groupIndex
     * @param int|string $startFldIndex
     *
     * @return DataObject
     */
    private function _buildAdvSearchFieldSet(
        array $fields, $operator = 'and', $groupIndex = 1, $startFldIndex = 1
    )
    {
        //Costruzione del DataObjectSet per le varie righe del form
        $fieldsObjectSet = new DataObjectSet();

        foreach ($fields as $fieldData) {
            $fieldsObjectSet->push(
                $this->FormRow(
                    $fieldData['fieldName'],
                    $fieldData['value'], $startFldIndex, $groupIndex
                )
            );
            if(is_int($startFldIndex)) {
                $startFldIndex++;
            }
        }

        //DataObjectSet per il dropdown per il tipo di match
        $operators = new DataObjectSet();
        foreach ($this->allowedOperators as $op
            => $label) {
            $operators->push(
                new DataObject(array(
                    'Operator' => $op, 'Label' => $label,
                    'Selected' => $op == strtolower($operator)
               ))
            );
        }

        $data = new DataObject(array(
            'FormRows' => $fieldsObjectSet,
            'GrpIndex' => $groupIndex,
            'Operator' => $operator,
            'Operators' => $operators
        ));

        return $data;
    }

    /**
     * Restituisce un JSON con i dati necessari a js per il caricamento di
     * nuovi campi e gruppi di ricerca.
     *
     * @return string
     */
    public function JS()
    {
        //Dati per l'aggiunta di un campo di ricerca
        $defaultField = $this->defaultJsField['fieldName'];
        $defaultValue = $this->defaultJsField['value'];
        $addFieldData = $this->FormRow(
            $defaultField, $defaultValue, '$fieldIndex', '$grpIndex'
        );
        $jsAddFieldData = array(
            'lastFieldIndex' => $this->getLastFieldIndex(),
            'lastGroupIndex' => $this->getLastGrpIndex(),
            'js' => $addFieldData
                ->customise(array('LocaleAntisegment' => LangController::localeAntisegment()))
                ->renderWith('AdvancedSearchFieldsRow')
        );

        //Dati per l'aggiunta di un gruppo di campi di ricerca
        $addGrpData = $this->_buildAdvSearchFieldSet(
            array($this->defaultJsField), 'or', '$grpIndex', '$fieldIndex'
        );
        $jsAddFieldsetData = array(
            'lastGroupIndex' => $this->getLastGrpIndex(),
            'js' => $addGrpData
                ->renderWith('AdvancedSearchFieldsGroup')
        );

        //Raggruppo i precedenti e codifico in json
        $jsData = array(
            'addField' => $jsAddFieldData,
            'addGrp' => $jsAddFieldsetData,
        );

        return json_encode($jsData);
    }

    /**
     * @return DataObjectSet
     */
    public function DefaultFieldSets()
    {
        return new DataObjectSet($this->_buildAdvSearchFieldSet(
                $this->defaultFields, $this->defaultOp,
                $this->startGrpIndx, $this->startFieldIndx
        ));
    }

    /**
     * @return DataObjectSet
     */
    public function FieldNames()
    {
        return $this->getFieldsDO();
    }

    /**
     * Carica i valori disponibili nell'indice Solr dei facets associati a
     * campi mappati e con autocompletamento
     * @param SolrSearcher $searcher
     * @param $facetsConf
     * @return LqAdvancedSearchForm
     */
    public function loadAvaiableFacets(SolrSearcher $searcher, $facetsConf)
    {
        $solrQuery = new SolrQuery();
        $solrQuery->setMainQuery('*:*')
            ->setRawField('start', 0)
            ->setRawField('rows', 0);

        foreach($this->fieldsConfiguration as $qsField => $cnf) {
            if (
                isset($cnf['map']) &&
                isset($cnf['autocomplete_field']) &&
                isset($facetsConf[$cnf['field']])
            ) {
                $solrQuery->addFacet($cnf['field'])
                    ->setFacetParam($cnf['field'], 'limit', -1)
                    ->setFacetParam($cnf['field'], 'mincount', 1);
            }
        }
        $solrResponse = $searcher->search($solrQuery);

        $this->avaiableFacets = $solrResponse->getFacetFieldsCounts();

        return $this;
    }

    /**
     * Returns the DataObjectSet of FieldTypes
     *
     * @return DataObjectSet
     */
    private function getFieldsDO()
    {
        $fieldsAry = new DataObjectSet();
        foreach ($this->fieldTypes as $fieldName){
            if (array_key_exists($fieldName, $this->fieldsConfiguration)) {
                $fieldsAry->push(
                    new DataObject(array(
                        'FieldName' => $fieldName,
                        'Label' => _t('LQFields.'.strtoupper($fieldName),
                            $this->fieldsConfiguration[$fieldName]['label'])
                    ))
                );
            }
        }

        return $fieldsAry;
    }
}
 
