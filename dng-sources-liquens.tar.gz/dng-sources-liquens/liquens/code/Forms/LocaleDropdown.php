<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */


/**
 * Dropdown for available locales
 *
 * Class LocaleDropdown
 */
class LocaleDropdown extends DropdownField
{
    function __construct($name, $title = null, $value = "", $form = null, $emptyString = null)
    {
        parent::__construct($name, $title, $this->getLocalesMap(), $value, $form, $emptyString);
    }

    /**
     * A map where keys are locales codes and values are locales labels.
     *
     * @return array
     */
    private function getLocalesMap()
    {
        $locales = Translatable::get_allowed_locales();

        $map = array();

        foreach ($locales as $locale) {
            $map[$locale] = i18n::get_language_name(i18n::get_lang_from_locale($locale), false);
        }

        return $map;
    }
}