<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

/**
 * Class that extends Silverstripe's Form class in order to use
 * a custom template
 */
class CustomizedForm extends Form
{
    /**
     * @var string The name of the ss (a default value written by the constructor)
     */
    public $template;

    /**
     * @return string Overload template rendering
     */
    public function forTemplate()
    {
      return $this->renderWith(array(
         $this->template,
         'Form'
      ));
   }

    /**
     * Set $template property to the value of $name constructor param
     * @param $controller
     * @param $name
     * @param FieldSet $fields
     * @param FieldSet $actions
     * @param null $validator
     */
    public function __construct($controller, $name, FieldSet $fields, FieldSet $actions, $validator = null)
    {
        if (!$validator)
            $validator = new ComplexValidator();

        parent::__construct($controller, $name, $fields, $actions, $validator);

        $this->template = $name;
    }
}
