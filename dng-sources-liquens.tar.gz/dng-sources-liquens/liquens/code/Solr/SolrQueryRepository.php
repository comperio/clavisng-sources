<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class SolrQueryRepository
{
    public static function getItemStatusFilterClause($excludedStatus = array())
    {
        $totalItemStatus = array('a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z');
        $itemStatusToShow = array_diff($totalItemStatus, $excludedStatus);
        $solrItemStatusClauses = array_map(function($status){
            return 'mrc_d950_sj:' . $status;
        }, $itemStatusToShow);

        return implode(' OR ', $solrItemStatusClauses);
    }
}
