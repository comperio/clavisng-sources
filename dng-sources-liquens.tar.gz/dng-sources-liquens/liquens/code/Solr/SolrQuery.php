<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

/**
 * Encapsulates the query params to perform a Solr Search
 */
class SolrQuery
{
    /**
     * Raw array representation of a SolrQuery
     * @var array
     */
    private $_rawQuery = array();

    /**
     * @param array $rawQuery
     */
    public function __construct($rawQuery = array())
    {
        $this->_rawQuery = $rawQuery;
    }

    /**
     * @return array
     */
    public function getRawQuery()
    {
        return $this->_rawQuery;
    }

    /**
     * Merge an array into the rawQuery
     * @param array $queryToMerge
     * @return SolrQuery
     */
    public function mergeRawQuery(array $queryToMerge)
    {
        $this->_rawQuery = array_merge($this->_rawQuery, $queryToMerge);

        return $this;
    }

    /**
     * @param string $facetName
     * @param bool $excludeTag
     * @return SolrQuery
     */
    public function addFacet($facetName, $excludeTag = false)
    {
        $this->setRawField('facet', 'true');

        $facetString = $facetName;
        if ($excludeTag)
            $facetString = "{!ex=$facetName}" . $facetString;

        $this->_rawQuery['facet.field'][] = $facetString;

        return $this;
    }

    /**
     * @param string $facetName
     * @param string $param
     * @param string $value
     * @return SolrQuery
     */
    public function setFacetParam($facetName, $param, $value)
    {
        $this->_rawQuery["f.$facetName.facet.$param"] = $value;

        return $this;
    }

    /**
     * @param string $param
     * @param string $value
     * @return SolrQuery
     */
    public function setGlobalFacetParam($param, $value)
    {
        $this->_rawQuery["facet.$param"] = $value;

        return $this;
    }


    /**
     * Remove all facets-related fields from the query
     *
     * @return SolrQuery
     */
    public function removeFacets()
    {
        $this->_rawQuery["facet.field"] = array();
        $facetFieldPrefix = 'f.';

        foreach($this->_rawQuery as $fieldName => $value){
            if (substr($fieldName, 0, strlen($facetFieldPrefix)) === $facetFieldPrefix){
                unset($this->_rawQuery[$fieldName]);
            }
        }

        return $this;
    }

    /**
     * @param string $query
     * @return SolrQuery
     */
    public function setMainQuery($query = null)
    {
        if ($query)
            $this->_rawQuery["q"] = $query;
        else
            $this->_rawQuery["q"] = '*:*';

        return $this;
    }

    /**
     * @return string
     */
    public function getMainQuery()
    {
        if (isset($this->_rawQuery["q"]))
            return $this->_rawQuery["q"];

        return '';
    }

    /**
     * Return the main query and the filter queries joined by AND operators
     *
     * @return string
     */
    public function getAsOneQueryString()
    {
        $queryPieces = array();

        if ($this->getMainQuery())
            $queryPieces[] = $this->getMainQuery();

        $queryPieces = array_merge(
            $queryPieces,
            $this->getFilterQueries()
        );

        //If we have more than one condition, protect the conditions with brackets
        if (count($queryPieces) > 1) {
            $queryPieces = array_map(function($piece){
                return '(' . $piece . ')';
            }, $queryPieces);
        }

        $query = implode(' AND ', $queryPieces);

        return $this->removeTags($query);
    }

    /**
     * @param string $fieldname
     * @param string|array $value
     * @return SolrQuery
     */
    public function setRawField($fieldname, $value)
    {
        $this->_rawQuery[$fieldname] = $value;

        return $this;
    }

    /**
     * @param string $fieldname
     * @return bool
     */
    public function getRawField($fieldname)
    {
        if(isset($this->_rawQuery[$fieldname]))
            return $this->_rawQuery[$fieldname];

        return false;
    }

    /**
     * @param $fieldname
     * @param $value
     * @return SolrQuery
     */
    public function addRawField($fieldname, $value)
    {
        if (isset($this->_rawQuery[$fieldname]) && !is_array($this->_rawQuery[$fieldname]))
        {
            $this->_rawQuery[$fieldname] = array();
        }

        $this->_rawQuery[$fieldname][] = $value;

        return $this;
    }

    /**
     * Returns a query string representation for the query
     * @return string
     */
    public function toQueryString()
    {
        return http_build_query($this->_rawQuery);
    }

    /**
     * @return array
     */
    public function getFilterQueries()
    {
        $queries = $this->getRawField('fq');

        if ($queries === false)
            return array();

        return $queries;
    }

    /**
     * @param string $filterQuery
     * @return SolrQuery
     */
    public function addFilterQuery($filterQuery)
    {
        return $this->addRawField('fq', $filterQuery);
    }

    /**
     * @param $condition
     * @param string $operator
     *
     * @return SolrQuery
     */
    public function appendCondition($condition, $operator = 'AND')
    {
        if (!$this->getMainQuery()){
            $oldQuery = '*:*';
        } else {
            $oldQuery = $this->getMainQuery();
        }

        if ($oldQuery == '*:*' && $operator == 'AND') {
            $newMainQuery = $condition;
        } else if($condition == '*:*' && $operator == 'AND') {
            $newMainQuery = $oldQuery;
        } else {
            $newMainQuery = "($oldQuery) $operator ($condition)";
        }
        
        // Fix per errore su query "disponibili dal"
        $newMainQuery = str_replace(" AND ()", "", $newMainQuery);
        
        $this->setMainQuery($newMainQuery);

        return $this;
    }

    /**
     * @param string $facetQuery
     * @return SolrQuery
     */
    public function addFacetQuery($facetQuery)
    {
        return $this->addRawField('facet.query', $facetQuery);
    }

    /**
     * Merge main query and filter conditions from another query
     *
     * @param SolrQuery $query
     *
     * @return SolrQuery The current instance
     */
    public function merge(SolrQuery $query)
    {
        if ($query->getMainQuery())
            $this->appendCondition($query->getMainQuery(), 'AND');

        foreach ($query->getFilterQueries() as $filterQuery) {
            $this->addFilterQuery($filterQuery);
        }

        return $this;
    }

    /**
     * Remove pieces like {!tag=tagname} from queries
     *
     * @param string $query
     *
     * @return string
     */
    private function removeTags($query)
    {
        return preg_replace('/{!tag=\w*?}/', '', $query);
    }

}
