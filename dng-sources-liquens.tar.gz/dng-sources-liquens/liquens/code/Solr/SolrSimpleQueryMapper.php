<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
/**
 * Questo Mapper usa una mappatura semplificata rispetto a quella del papà.
 * La mappatura è del tipo field1=value1&field2=value2....
 */
class SolrSimpleQueryMapper extends SolrQueryMapper
{
    /**
     * @var string In questo mapper l'operatore è unico
     */
    public $globalOperator = 'AND';

    /**
     * @param $query
     * @param array $excluded
     * @return SolrSimpleQueryMapper
     */
    public function loadQuery($query, array $excluded = array())
    {
        $this->queryAry = array();
        $this->excludedAry = array();
        $this->operators = array();

        $this->registerOperator('AND', $this->globalOperator);
        $this->registerOperator('NOT', 'NOT');

        $inputAry = array();

        if (!$query) {
            return $this;
        }

        if (is_string($query)) {
            parse_str($query, $inputAry);
        } else {
            $inputAry = $query;
        }

        if (is_array($excluded) && count($excluded)) {
            $this->excludedAry = $excluded;
        }

        if (is_array($query)) {
            $this->queryAry = $query;
            return $this;
        }

        foreach ($inputAry as $fieldName => $value) {
            $operator = 'AND';
            $exploded = explode('_', $fieldName);
            $realFieldName = $exploded[0];

            if ($realFieldName[0] === '-') {
                $realFieldName = substr($realFieldName, 1);
                $operator = 'NOT';
            }

            //If it is not a registered field name...
            if (!$this->getFieldsCollection()->hasField($realFieldName)) {
                $this->excludedAry[$fieldName] = $value;
                continue;
            }

            $this->addField($realFieldName, $value, $operator);
        }

        return $this;
    }

    /**
     * Ritorna la query string di ricerca.
     * @param bool $getExcludedFields
     * @return string
     */
    public function getQueryString($getExcludedFields = true)
    {
        $qsAry = array();
        $fieldsCount = array();

        foreach ($this->queryAry as $index
            => $data) {
            //Conteggio dei campi ripetuti (mi serve per costruire i nomi
            // dei campi come campo_1, campo_2 etc
            if (isset($fieldsCount[$data['field']])) {
                $fieldsCount[$data['field']]++;
            } else {
                $fieldsCount[$data['field']] = 1;
            }

            // Prefix for not values
            $prefix = $this->operators[$data['op_index']] == 'NOT' ? '-' : '';

            $qsFieldName = $prefix . $data['field'];
            if (count($this->fieldsIndexAry[$data['field']]) > 1) {
                $qsFieldName .= '_' . $fieldsCount[$data['field']];
            }

            $qsAry[$qsFieldName] = $data['value'];
        }

        if ($getExcludedFields)
            return http_build_query(array_merge($qsAry, $this->excludedAry));

        return http_build_query($qsAry);
    }
}