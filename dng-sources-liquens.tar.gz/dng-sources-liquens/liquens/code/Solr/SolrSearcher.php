<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

class SolrSearcher {

    public $solrURL;
    public $facets;
    public $sort;
    public $fields;
    public $stream;

    /**
     * Servlet mappings
     */
    const PING_SERVLET = 'admin/ping';
    const UPDATE_SERVLET = 'update';
    const SEARCH_SERVLET = 'select';
    const TERM_SERVLET = 'terms';
    const THREADS_SERVLET = 'admin/threads';
    const WT = 'phps';

    /**
     * @var array Parameters that will be added to SolrQuery before the request has been sent
     */
    private $additionalQueryParams = array();


    /**
     * Escape a value for special query characters such as ':', '(', ')', '*', '?', etc.
     *
     * NOTE: inside a phrase fewer characters need escaped, use {@link Apache_Solr_Service::escapePhrase()} instead
     *
     * @param string $value
     * @return string
     */
    static public function escape($value) {
        //list taken from http://lucene.apache.org/java/docs/queryparsersyntax.html#Escaping%20Special%20Characters
        //Removed *, ? and ^ due to Giulio wishes.

        $pattern = '/(\+|-|&&|\|\||!|\(|\)|\{|}|\[|]|~|:|\\\)/';
        $replace = '\\\$1';

        return preg_replace($pattern, $replace, $value);
    }

    /**
     * Escape a value meant to be contained in a phrase for special query characters
     *
     * @param string $value
     * @return string
     */
    static public function escapePhrase($value) {
        $pattern = '/("|\\\)/';
        $replace = '\\\$1';

        return preg_replace($pattern, $replace, $value);
    }

    /**
     * @static
     * @param $value
     * @return string
     */
    static public function phrase($value) {
        return '"' . self::escapePhrase($value) . '"';
    }

    /**
     * @static
     * @param $xmlString
     * @return mixed
     */
    public static function unescapeXml($xmlString)
    {
        return(str_replace(array("&quot;"), array("\""), $xmlString));
        return $xmlString;
    }

    /**
     * @param $solrURL
     */
    public function __construct($solrURL) {
        global $sc;
        $this->solrURL = $solrURL;
        $this->stream = stream_context_create(
            array(
                'http' => array(
                    'method' => 'GET',
                    'timeout' => $sc->getParameter('lq.connector.timeout'),
                ))
        );
    }

    /**
     * @param SolrQuery $query
     * @return SolrResponse
     */
    public function search(SolrQuery $query) {
        $response = new SolrResponse();
        if($query instanceof SolrQuery){
            $query->setRawField('wt', self::WT);

            if (strpos($query->getRawField('sort'), '-') !== false) {
                $sort = explode('-', $query->getRawField('sort'))[1];
                $base = explode('-', $query->getRawField('sort'))[0];
                $query->setRawField('sort', $base);
            } else {
                global $sc;
                $base = $query->getRawField('sort');
                $sort = $sc->getParameter('lq.default_sorting_fields')[0];
            }

            if ($base == 'base') {
                $query->setRawField('sort', LQConfig::get('sortFields', $sort, 'rule'));
            }
            
            $this->injectAdditionalQueryParamsIntoQuery($query);
            $this->fixSolrBugs($query);

            $rawResponse = $this->getResponse($query);
            $response = new SolrResponse($rawResponse);
            $rawResponse = $response->getRawResponse();

            // Adjust numFound if query has dngForceMax parameter
            if ($max = $query->getRawField('dngForceMax')) {
                if ($max < $response->getNumFound()) {
                    $rawResponse['response']['numFound'] = $max;
                    $response->setRawResponse($rawResponse);
                }
            }

            if (isset($_GET['solrdebug'])){
                Debug::dump("SOLR QTime: " . $rawResponse['responseHeader']['QTime']);
                Debug::dump($query->getRawQuery());
            }
            #Debug::dump($rawResponse['debug']);
        }
        return $response;
    }

    /**
     * @see $additionalQueryParams
     *
     * @param array $params
     * @return SolrSearcher
     */
    public function setAdditionalQueryParams($params = array())
    {
        $this->additionalQueryParams = $params;

        return $this;
    }

    /**
     * @return array
     */
    public function getAdditionalQueryParams()
    {
        return $this->additionalQueryParams;
    }

    /**
     * @param $field
     * @param $term
     * @param int $size
     * @param string $sort
     * @return mixed|null
     */
    public function termsuggest($field, $term, $size = 10, $sort = "index") {
        $query = new SolrQuery();

        $query
                ->setRawField('terms.fl', $field)
                ->setRawField('terms.sort', $sort)
                ->setRawField('terms.regex', $this->manipulateTermsuggestRegexp("{$term}.*"))
                ->setRawField('terms.limit', $size)
                ->addRawField('terms.regex.flag', 'unicode_case')
                ->addRawField('terms.regex.flag', 'case_insensitive')
                ->setRawField('wt', 'phps')
        ;

        $result = $this->getResponse($query, self::TERM_SERVLET);

        return $result;
    }

    /**
     * @param SolrQuery $query
     * @return SolrQuery
     */
    private function injectAdditionalQueryParamsIntoQuery(SolrQuery $query)
    {
        foreach ($this->getAdditionalQueryParams() as $field => $value) {
            $query->setRawField($field, $value);
        }

        return $query;
    }

    /**
     * @param SolrQuery $query
     * @param null $servlet
     * @return mixed|null
     */
    private function getResponse(SolrQuery $query, $servlet = null)
    {
        if(!$servlet) {
            $servlet = self::SEARCH_SERVLET;
        }
        // remove index-parts of query inserted by http_build_query
        // i.e. substrings of the form [n] followed by =, where n is a natural number
        $queryString = preg_replace('/%5B(?:[0-9]|[1-9][0-9]+)%5D=/', '=', $query->toQueryString());

        //open connection
        $ch = curl_init();

        //set the url, number of POST vars, POST data
        curl_setopt($ch, CURLOPT_URL, $this->solrURL . $servlet);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $queryString);
        //Set a timeout of 5 seconds
        global $sc;
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $sc->getParameter('lq.connector.timeout'));

        //execute post
        if (isset($_GET['solrdebug'])){
            $uri = "{$this->solrURL}{$servlet}?{$queryString}";
            $uri = str_replace('wt=phps', 'wt=xml', $uri);
            Debug::dump("Request uri: <a href='$uri'>$uri</a>");
            list ($usec, $sec) = explode (' ', microtime());
            $startTime = ((float) $usec + (float) $sec);
        }

        $response = curl_exec($ch);

        if (isset($_GET['solrdebug'])){
            list ($usec, $sec) = explode (' ', microtime());
            $executionTime = ((float) $usec + (float) $sec) - $startTime;
            Debug::log("SOLR Url Request ($executionTime s): $queryString\r\n");
        }

        $errors = $this->getErrorsFromCurl($ch);

        //Sometimes solr fails, in that cases I repeat the request (2 times)
        $i = 0;
        while (($errors || !$response) && $i < 2) {
            if(!$response)
            {
                Debug::log('SOLR Empty Response for request: ' . $queryString);
            }
            if ($errors){
                Debug::log("SOLR Response Errors: \r\n" . implode("\r\n", $errors));
                Debug::log("SOLR Response: \r\n" . $response);
            }
            $response = curl_exec($ch);
            $errors = $this->getErrorsFromCurl($ch);
            $i++;
        }

        curl_close($ch);

        //file_put_contents('/comperio/discoveryng3/liquens/tests/SolrResponseFixture.txt', $response);
        if($response != NULL && !$errors)
        {
            $unserialized = unserialize($response);

            if (isset($_GET['solrdebug'])){
                Debug::log("SOLR QTime: " . $unserialized['responseHeader']['QTime']);
            }

            return $unserialized;
        }
        return NULL;
    }

    /**
     * Riceve una query per SolR e restituisce il numero di 'row'
     * 
     * @param type $query
     * @return type
     */
    public function getQueryRowCount($query) {
        // Crea nuova query solr
        $qr = new SolrQuery();
        // Associa la query
        $qr->setMainQuery($query);
        $qr->setRawField('wt', self::WT);
        // Risultato
        $res = $this->getResponse($qr);
        return $res["response"]["numFound"];
    }
    
    /**
     * Esegue una query per richiedere il contenuto delle authority
     * 
     * @param type $parametri
     * @return type
     */
    public function getQueryAuthority($parametri) {
        $query = new SolrQuery();
        $query->setMainQuery('id:'.$parametri->system.'\\:'.$parametri->auth_collection.'\\:'.$parametri->auth_id);
        $query->setRawField('wt', self::WT);
        $result = $this->getResponse($query);
        return $result;
    }
    
    public function getQueryAuthorityOtherSubject($auth) {
        $query = new SolrQuery();
        $stringaQuery = '';
        if (isset($auth->auth_id)&&($auth->auth_id != 0)) { $stringaQuery = ' AND mrc_d931_s3:'.$auth->auth_id; }
        if (isset($auth->auth_other)&&(!is_null($auth->auth_other))) { $stringaQuery .= $auth->auth_other; }
        $query->setMainQuery('collection:authority'.$stringaQuery);
        /* Fissi */
        $query->setRawField('wt', self::WT);
        $query->setRawField('indent', 'true');
        /* Variabili */
        if (isset($auth->auth_sort)) { $query->setRawField('sort', $auth->auth_sort); }
        if (isset($auth->auth_fl)) { $query->setRawField('fl', $auth->auth_fl); }
        if (isset($auth->auth_facet)) { $query->setRawField('facet', $auth->auth_facet); }
        if (isset($auth->auth_facet_field)) { $query->setRawField('facet.field', $auth->auth_facet_field); }
        if (isset($auth->auth_start)) { $query->setRawField('start', $auth->auth_start); }
        if (isset($auth->auth_rows)) { $query->setRawField('rows', $auth->auth_rows); }
        /**/
        $result = $this->getResponse($query);
        return $result;
    }
    
    /**
     * Returns an array of errors from a curl handler
     *
     * @param $ch
     * @return array
     */
    private function getErrorsFromCurl($ch)
    {
        $errors = array();

        //The httpcode of the response
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        if($code != 200)
        {
            $errors[] = "HTTP CODE ERROR: $code";
        }
        if($error = curl_error($ch))
        {
            $errors[] = $error;
        }

        return $errors;
    }

    private function manipulateTermsuggestRegexp($regexp)
    {
        $map = array(
            'a' => '(a|à|á|ä|ã|â)',
            'e' => '(e|è|é|ë|ę|ė|ē)',
            'i' => '(i|ì|í|ï|î|î)',
            'o' => '(o|ò|ó|ö|õ|ô)',
            'u' => '(u|ù|ú|ü|û)'
        );

        return str_replace(array_keys($map), array_values($map), $regexp);
    }

    /**
     * Addresses version-specific bug of solr
     *
     * @param $query
     *
     * @return $this
     */
    private function fixSolrBugs(SolrQuery $query)
    {
        //https://issues.apache.org/jira/browse/SOLR-3729
        $main = $query->getMainQuery();

        if ($main != '*:*')
            $query->setMainQuery(str_replace('*:*', ' *:*', $main));

        return $this;
    }
}
