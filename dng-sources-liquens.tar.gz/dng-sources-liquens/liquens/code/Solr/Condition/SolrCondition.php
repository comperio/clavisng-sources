<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

/**
 * This interface represent an object that can be converted to a solr condition.
 */
interface SolrCondition
{
    /**
     * @abstract
     * @return string
     */
    public function toSolrString();

    /**
     * @abstract
     * @return SolrQuery
     */
    public function toSolrQuery();
}