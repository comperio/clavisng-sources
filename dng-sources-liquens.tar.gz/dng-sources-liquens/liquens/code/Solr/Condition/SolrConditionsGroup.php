<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class SolrConditionsGroup implements SolrCondition
{
    const NULL_QUERY = '*:*';
    const EMPTY_QUERY = '*:* NOT *:*';

    private $operator;
    private $conditions = array();
    private $solrQueryClass = 'SolrQuery';

    /**
     * @param string $operator
     */
    public function __construct($operator = 'AND')
    {
        $this->operator = $operator;
    }

    /**
     * @return string
     */
    public function toSolrString()
    {
        return $this->toSolrQuery()->getAsOneQueryString();
    }

    /**
     * @param SolrCondition $condition
     *
     * @return SolrConditionsGroup
     */
    public function addCondition(SolrCondition $condition)
    {
        $this->conditions[] = $condition;

        return $this;
    }

    /**
     * Returns the array of conditions
     *
     * @return array
     */
    public function getConditions()
    {
        return $this->conditions;
    }

    /**
     * @return SolrQuery
     */
    public function toSolrQuery()
    {
        $query = $this->createQuery();

        if ('AND' === $this->getOperator()) {
            $this->mergeConditionsIntoQuery($query, $this->getConditions());
        } else {
            $query->setMainQuery($this->implodeConditions($this->getConditions()));
        }

        return $query;
    }

    /**
     * Get the group operator
     *
     * @return string
     */
    public function getOperator()
    {
        return $this->operator;
    }

    /**
     * Implode an array of conditions with the current operator
     *
     * @param array $conditions
     *
     * @return string
     */
    private function implodeConditions(array $conditions)
    {
        $operator = $this->getOperator();

        // If there are no conditions
        if (!$this->getConditions()) {
            if ('OR' === $operator) {
                return self::EMPTY_QUERY;
            } else {
                return self::NULL_QUERY;
            }
        }

        if ('NOT' === $operator) {
            $plainSolrConditions = array_map(function($condition){
                return '-(' . $condition->toSolrQuery()->getAsOneQueryString() . ')';
            }, $conditions);

            return self::NULL_QUERY . ' ' . implode(" ", $plainSolrConditions);
        } else {
            $plainSolrConditions = array_map(function($condition){

                return '(' . $condition->toSolrQuery()->getAsOneQueryString() . ')';
            }, $conditions);

            return implode( " $operator ", $plainSolrConditions);
        }
    }

    /**
     * This method merge all the queries given by the conditions in the SolrQuery specified.
     * Main queries are joined by ands, and filter queries are added to $query's filter queries.
     *
     * @param SolrQuery $query
     *
     * @return SolrConditionsGroup
     */
    private function mergeConditionsIntoQuery(SolrQuery $query)
    {
        $mainQueries = array();

        /** @var $condition SolrCondition */
        foreach ($this->getConditions() as $condition) {
            $condQuery = $condition->toSolrQuery();
            $condMainQuery = $condQuery->getMainQuery();

            if ($condMainQuery && trim($condMainQuery) != static::NULL_QUERY){
                $mainQueries[] = $condMainQuery;
            }

            foreach ($condQuery->getFilterQueries() as $filterQuery) {
                $query->addFilterQuery($filterQuery);
            }
        }

        if (count($mainQueries) > 1) {
            $mainQueries = array_map(function($mainQuery) {
                return '(' . $mainQuery . ')';
            }, $mainQueries);
        }

        $mainQuery = implode(' AND ', $mainQueries);

        if (!$mainQuery) $mainQuery = self::NULL_QUERY;

        $query->setMainQuery($mainQuery);

        return $this;

    }

    /**
     * @return SolrQuery
     */
    private function createQuery()
    {
        $queryClass = $this->solrQueryClass;

        return new $queryClass;
    }
}
