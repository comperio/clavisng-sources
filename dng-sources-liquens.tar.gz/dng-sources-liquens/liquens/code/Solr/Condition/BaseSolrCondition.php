<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class BaseSolrCondition implements SolrCondition
{
    private $solrString;
    private $relevantForScoring;
    private $solrQueryClass = 'SolrQuery';
    private $tagName;

    /**
     * @param $solrCondition
     * @param bool $isRelevantForScoring
     */
    public function __construct($solrCondition, $isRelevantForScoring = true, $tagName = false)
    {
        $this->solrString = $solrCondition;
        $this->relevantForScoring = $isRelevantForScoring;
        $this->tagName = $tagName;
    }

    /**
     * @abstract
     * @return string
     */
    public function toSolrString()
    {
        return $this->solrString;
    }

    /**
     * @return SolrQuery
     */
    public function toSolrQuery()
    {
        $solrQueryClass = $this->solrQueryClass;

        /** @var $query SolrQuery */
        $query = new $solrQueryClass;

        if ($this->isRelevantForScoring()){
            $query->setMainQuery($this->solrString);
        } else {
            $filter = $this->solrString;
            if ($this->tagName)
                $filter = "{!tag={$this->tagName}}" . $filter;

            $query->addFilterQuery($filter);
        }

        return $query;
    }

    /**
     * @abstract
     * @return bool
     */
    public function isRelevantForScoring()
    {
        return $this->relevantForScoring;
    }
}
