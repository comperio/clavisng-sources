<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class SolrConditionsSupergroup extends SolrConditionsGroup
{
    /**
     * An hash of SolrConditionsGroup objects
     * @var array
     */
    private $groups = array();

    /**
     * @param $name
     * @param SolrConditionsGroup $group
     *
     * @return SolrConditionsSupergroup The current instance
     */
    public function registerGroup($name, SolrConditionsGroup $group)
    {
        $this->addCondition($group);
        $this->groups[$name] = $group;

        return $this;
    }

    /**
     * @param $name
     *
     * @return SolrConditionsGroup
     *
     * @throws InvalidArgumentException
     */
    public function getGroup($name)
    {
        if (!isset($this->groups[$name])) {
            throw new InvalidArgumentException("There is no group registered with name $name");
        }

        return $this->groups[$name];
    }
}
