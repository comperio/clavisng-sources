<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

/**
 * This class represents a general solr response
 */
class SolrResponse implements IteratorAggregate
{
    /**
     * Raw response returned by Solr
     * @var array
     */
    private $rawResponse = array();

    /**
     * @param array $rawResponse
     */
    public function __construct($rawResponse = array())
    {
        $this->rawResponse = $rawResponse;
    }

    /**
     * @return array
     */
    public function getRawResponse()
    {
        return $this->rawResponse;
    }

    /**
     * Set the RawResponse
     *
     * @return SolrResponse The current instance
     */
    public function setRawResponse($rawResponse)
    {
        $this->rawResponse = $rawResponse;

        return $this;
    }

    /**
     * Returns response->docs field of raw solr response
     *
     * @return array
     */
    public function getDocs()
    {
        if (isset($this->rawResponse['response']['docs']))
            return $this->rawResponse['response']['docs'];
        
        return array();
    }

    /**
     * Returns nth result
     * 
     * @param int $n
     * @return bool
     */
    public function getDoc($n = 0)
    {
        if (isset($this->rawResponse['response']['docs'][$n]))
            return $this->rawResponse['response']['docs'][$n];

        return false;
    }

    /**
     * Returns facet_counts->facet_fields field of raw solr response
     *
     * @return array
     */
    public function getFacetFieldsCounts()
    {
        if (isset($this->rawResponse['facet_counts']['facet_fields']))
            return $this->rawResponse['facet_counts']['facet_fields'];

        return array();
    }

    /**
     * Returns facet_counts->facet_queries field of raw solr response
     *
     * @return array
     */
    public function getFacetQueriesCounts()
    {
        if (isset($this->rawResponse['facet_counts']['facet_queries']))
            return $this->rawResponse['facet_counts']['facet_queries'];

        return array();
    }

    /**
     * Returns response->numFound field of raw solr response
     * @return int
     */
    public function getNumFound()
    {
        if (isset($this->rawResponse['response']['numFound']))
            return (int) $this->rawResponse['response']['numFound'];

        return 0;
    }

    public function getQuery()
    {
        $params = isset($this->rawResponse['responseHeader']['params']) ?
                $this->rawResponse['responseHeader']['params'] :
                array()
        ;

        return new SolrQuery($params);
    }

    /**
     * Returns ArryIterator for the ArrayAggregate Interface
     *
     * @return ArrayIterator
     */
    public function getIterator()
    {
        if (isset($this->rawResponse['facet_counts']['facet_fields']))
            return new ArrayIterator($this->rawResponse['facet_counts']['facet_fields']);

        return new ArrayIterator(array());
    }

    /**
     * Extract a property from each result and returns them as an array
     * Example: getDocsProperties('id') returns an array filled with all ids of
     * the search result
     *
     * @param $property
     * @return array
     */
    public function getDocsProperties($property)
    {
        return array_map(function($item) use ($property) {
            return isset($item[$property]) ? $item[$property] : null;
        }, $this->getDocs());
    }
}
