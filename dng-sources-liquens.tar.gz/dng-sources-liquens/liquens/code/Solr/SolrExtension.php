<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
// Acme/HelloBundle/DependencyInjection/AcmeHelloExtension.php
use Symfony\Component\DependencyInjection\Extension\ExtensionInterface;
use Symfony\Component\DependencyInjection\ContainerBuilder;
use Symfony\Component\Config\Definition\Processor;

class SolrExtension implements ExtensionInterface
{
    public function load(array $configs, ContainerBuilder $container)
    {
        $processor = new Processor();

        $configuration = new SolrConfiguration();
        $config = $processor->processConfiguration($configuration, $configs);

        var_dump($config);
    }

    public function getXsdValidationBasePath()
    {
        return '';
    }

    public function getNamespace()
    {
        return '';
    }

    public function getAlias()
    {
        return 'solr';
    }
}
