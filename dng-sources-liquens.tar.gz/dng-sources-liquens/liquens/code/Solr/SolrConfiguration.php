<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
// src/Acme/HelloBundle/DependencyInjection/Configuration.php

use Symfony\Component\Config\Definition\Builder\TreeBuilder;
use Symfony\Component\Config\Definition\ConfigurationInterface;

class SolrConfiguration implements ConfigurationInterface
{
    public function getConfigTreeBuilder()
    {
        $treeBuilder = new TreeBuilder();
        $rootNode = $treeBuilder->root('solr');

        $rootNode
            ->children()
                ->arrayNode('fields')
                    ->canBeUnset()
                    ->useAttributeAsKey('name')
                    ->prototype('array')
                        ->children()
                            ->scalarNode('class')->defaultValue('SimpleSolrSearchField')->end()
                            ->arrayNode('solr_fields')
                                ->beforeNormalization()
                                    ->isRequired()
                                    ->ifTrue(function($v) { return !is_array($v); })
                                    ->then(function($v) { return array($v); })
                                ->end()
                            ->end()
                            ->booleanNode('phrasized')->defaultFalse()->end()
                        ->end()
                    ->end()
                ->end()
            ->end()
        ;

        return $treeBuilder;
    }
}
