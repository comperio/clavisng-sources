<?php

/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class SolrFacetsManager {

    /**
     * @var array
     */
    public $configuration;

    /**
     * @var array
     */
    public $includeOnly;

    /**
     * @param array $configuration la configurazione per la mappatura dei facets
     * @param array $includeOnly un array di facets
     */
    public function __construct($configuration = array(), $includeOnly = array()) {
        $this->configuration = $configuration;
        $this->includeOnly = $includeOnly;
    }

    /**
     * Ritorna gli elementi di $this->configuration le cui chiavi sono in
     * $this->includeOnly
     * 
     * @return array
     */
    public function getAllowedFacets() {
        if (empty($this->includeOnly))
            return $this->configuration;

        $facets = array();

        foreach ($this->includeOnly as $key => $facet) {
            
            if (strpos($facet, '|') !== false) {
                list($facet, $codes) = explode("|",$facet);
                $codes = explode(";",$codes);
                foreach ($codes as $code)
                    $configuration[explode("=", $code)[0]] = explode("=", $code)[1];
            }
            
            if (array_key_exists($facet, $this->configuration)) {
                $facets[$facet] = $this->configuration[$facet];
                if (isset($configuration)) {
                    foreach ($configuration as $key => $value)
                        $facets[$facet][$key] = $value;
                    unset($configuration);
                }
            }
        }
        return $facets;
    }

    /**
     * Ritorna il link alla pagina del facet
     *
     * @param string $facetField
     * @param string $searchQueryString
     * @param int $limit
     * @param string $baseUrl
     *
     * @return string
     */
    public function getFacetsListLink(
    $facetField, $searchQueryString, $limit = -1, $baseUrl = '/') {
        $qsAry = array();
        parse_str($searchQueryString, $qsAry);

        $qsAry['facet_field'] = $facetField;
        $qsAry['facet_limit'] = $limit;

        return $baseUrl . '?' . http_build_query($qsAry);
    }

    /**
     * Ritorna il link alla ricerca raffinata con un facet
     *
     * @param SolrQueryMapper $mapper
     * @param string $facetField
     * @param string $facetValue
     * @param int $start
     * @param string $baseUrl
     * @return string
     */
    public function getFacetFilterLink(
    SolrQueryMapper $mapper, $facetField, $facetValue, $start = 0, $baseUrl = '/', $operator = 'AND') {
        $mapperClone = clone($mapper);
        $newExcludedAry = array();

        if (isset($mapper->excludedAry['sort']))
            $newExcludedAry['sort'] = $mapperClone->excludedAry['sort'];

        $mapperClone->excludedAry = $newExcludedAry;

        if (!$mapperClone->isOperatorRegistered($operator)) {
            $mapperClone->registerOperator($operator, $operator);
        }

        if ($this->hasOption('unique', $facetField)) {
            $mapperClone->removeField($this->getOption('field', $facetField));
        }

        if ($mapperClone->hasValue($this->getOption('field', $facetField), $facetValue)) {
            $mapperClone->removeValue($this->getOption('field', $facetField), $facetValue);
        } else {
            $mapperClone->addField($this->getOption('field', $facetField), $facetValue, $operator);
        }

        if ($start)
            $mapperClone->addField('start', $start);
        else
            $mapperClone->removeField('start');

        $result = $baseUrl . '?' . $mapperClone->getQueryString(true);

        return $result;
    }

    /**
     * Restituisce degli elementi di $inputFaces le cui chiavi sono contenute
     * in $this->getAllowedFacets(), preservando l'ordine di quest'ultimo
     * @param array $inputFacets
     * @return array
     */
    public function filterAndOrderFacets(array $inputFacets) {
        $allowed = $this->getAllowedFacets();
        $outputFacets = array();

        foreach ($allowed as $facet => $config) {
            if (array_key_exists($facet, $inputFacets)) {
                $outputFacets[$facet] = $inputFacets[$facet];
            }
        }

        return $outputFacets;
    }

    /**
     * @param string $facetField
     * @return string
     */
    public function getLabel($facetField) {
        $conf = $this->configuration[$facetField];
        $fallbackLabel = isset($conf['label']) ? $conf['label'] : $facetField;

        return _t('LQFields.' . strtoupper($conf['field']), $fallbackLabel);
    }

    /**
     * Trasforma la lista di facet_query in un array
     * valoreVisibileFacet=>numFound
     *
     * @param array $input
     * @return array
     */
    public function transformFacetQueriesToFacetFields(array $input) {
        //Costruisco una mappa $querySolr -> facetField in base alla configuration
        $map = array();
        $results = array();

        foreach ($this->configuration as $facetName => $data) {
            if (!isset($data['queryHashField']) || !$data['queryHashField'])
                continue;

            /** @var $queryHashField QueryHashSearchField */
            $queryHashField = $this->getSolrSearchField($data['queryHashField']);
            $queryHash = $queryHashField->getHash();

            //tacitamente si suppone una query solr sia presente al più in un facet
            foreach ($queryHash as $value => $solrQuery) {
                $map[$solrQuery] = array(
                    'facetName' => $facetName,
                    'value' => $value);
            }
        }

        foreach ($input as $solrQuery => $numFound) {

            if (isset($map[$solrQuery])) {
                if ($numFound)
                    $results[$map[$solrQuery]['facetName']][$map[$solrQuery]['value']] = $numFound;
            }
        }

        //Order by facets count desc
        foreach ($results as $key => $items) {
            asort($items);
            $items = array_reverse($items);
            $results[$key] = $items;
        }

        return $results;
    }

    /**
     * Effettua la trasformazione delle query solr dei facet nei nomi dei facet
     * associati alle query, e unisce tutto ai facet normali. Esempio:
     * trasforma un array del tipo
     * <code>
     * array(
     *   'facet_queries' => array(
     *       'sorti_date:[* TO 1600]' => 23, //corrispondente ad "eta/matusa"
     *       'sorti_date:[1600 TO 1699]' => 0,   // eta/vecchissimo
     *       'sorti_date:[1700 TO 1799]' => 297, // eta/vecchio
     *       'sorti_date:[1800 TO 1899]' => 3,   // eta/obsoleto
     *       'sorti_date:[1900 TO 1999]' => 4,   // eta/bah
     *       'sorti_date:[2000 TO *]' => 5       // eta/giovane
     *   ),
     *   'facet_fields' => array(
     *       'facets_author' => array(
     *           'pascoli' => 1,
     *           'giulio' => 2,
     *           'ciro' => 9090909
     *       )
     *   )
     * )
     * </code>
     * nell'array
     * <code>
     * array(
     *       'facets_author' => array(
     *           'pascoli' => 1,
     *           'giulio' => 2,
     *           'ciro' => 9090909
     *       ),
     *       'eta' => array(
     *           'matusa' => 23,
     *           'vecchio' => 297,
     *           'obsoleto' => 3,
     *           'bah' => 4,
     *           'giovane' => 5
     *       ),
     *   );
     * </code>
     *
     * @param array $input
     * @return array
     */
    public function mergeAndOrderFacets(array $input) {
        $facetQueries = isset($input['facet_queries']) ?
                $this->transformFacetQueriesToFacetFields($input['facet_queries']) :
                array()
        ;

        $facetFields = isset($input['facet_fields']) ?
                $input['facet_fields'] :
                array()
        ;

        return $this->filterAndOrderFacets(array_merge($facetFields, $facetQueries));
    }

    /**
     * Check if the facet $facet has the boolean option $optionName set to true
     * 
     * @param string $facet
     * @param string $optionName
     * @return bool
     */
    public function hasOption($optionName, $facet) {
        return isset($this->configuration[$facet][$optionName]) && $this->configuration[$facet][$optionName];
    }

    /**
     * Returns, the option $optionName for the facet $facet if it exists,
     * null otherwise
     *
     * @param string $optionName the option key in $this->configuration
     * @param string $facet The facet Name
     * @return mixed
     */
    public function getOption($optionName, $facet) {
        $option = null;
        if (isset($this->configuration[$facet][$optionName]))
            $option = $this->configuration[$facet][$optionName];

        return $option;
    }

    /**
     * Get SolrQuery Object filled with facets params
     * @param null|SolrQuery $query
     * @return SolrQuery
     */
    public function getQuery(SolrQuery $query = null) {
        if (!$query)
            $query = new SolrQuery();

        $query->setRawField('facet', 'true');

        foreach ($this->getAllowedFacets() as $facet => $config) {
            if (isset($config['queryHashField']) && $config['queryHashField']) {
                /** @var $queryHashField QueryHashSearchField */
                $queryHashField = $this->getSolrSearchField($config['queryHashField']);
                $queryHash = $queryHashField->getHash();
                foreach ($queryHash as $name => $solrFctQuery) {
                    $query->addFacetQuery($solrFctQuery);
                }
            } else {
                $query->addFacet($facet, $this->hasOption('unique', $facet));

                if (isset($config['mincount']))
                    $query->setFacetParam($facet, 'mincount', $config['mincount']);
                if (isset($config['limit']))
                    $query->setFacetParam($facet, 'limit', $config['limit']);
                if (isset($config['missing']))
                    $query->setFacetParam($facet, 'missing', $config['missing'] == 1 ? "true" : "false");
                if (isset($config['method']))
                    $query->setFacetParam($facet, 'method', $config['method']);
                if (isset($config['offset']))
                    $query->setFacetParam($facet, 'offset', $config['offset']);
                if (isset($config['prefix']))
                    $query->setFacetParam($facet, 'prefix', $config['prefix']);
                if (isset($config['sort']))
                    $query->setFacetParam($facet, 'sort', $config['sort']);
            }
        }

        return $query;
    }

    /**
     * @param $fieldName
     * @return SolrSearchField
     */
    private function getSolrSearchField($fieldName) {
        global $sc;
        return $sc->get('solr.fields_collection')->getField($fieldName);
    }

}
