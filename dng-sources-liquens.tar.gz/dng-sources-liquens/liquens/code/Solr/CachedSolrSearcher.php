<?php
/*
 * This file is part of dng-git.
 *
 * (c) 2012 Nicolò Martini
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */
class CachedSolrSearcher extends SolrSearcher
{
    private $cacheDir;

    public function __construct($solrUrl, $cacheDir = null)
    {
        parent::__construct($solrUrl);

        if (!isset($cacheDir)) {
            $cacheDir = TEMP_FOLDER.DIRECTORY_SEPARATOR.'SolrResponses';
        }

        $this->cacheDir = $cacheDir;
    }

    public function search(SolrQuery $query)
    {
        $fingerPrint = sha1(serialize($query->getRawQuery()));

        $response = $this->getCachedResponse($fingerPrint);

        if (!isset($response)) {
            $response = parent::search($query);
            $this->cacheResponse($fingerPrint, $response);
        }

        return $response;
    }

    private function getCachedResponse($fingerPrint)
    {
        $fileName = $this->cacheDir . DIRECTORY_SEPARATOR . $fingerPrint;
        if (file_exists($fileName)) {
            $rawResponse = unserialize(file_get_contents($fileName));

            return new SolrResponse($rawResponse);
        }

        return null;
    }

    private function cacheResponse($fingerPrint, SolrResponse $response)
    {
        $serialized = serialize($response->getRawResponse());
        $fileName = $this->cacheDir . DIRECTORY_SEPARATOR . $fingerPrint;

        if (!file_exists($this->cacheDir))
            mkdir($this->cacheDir);

        file_put_contents($fileName, $serialized);

        return $this;
    }
}
