<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class SubjTypeSearchField extends SimpleSolrSearchField
{
    private $fields = array(
        600, 601, 602, 603, 604, 605, 606, 607, 608, 609, 610
    );
    /**
     * @return string
     */
    public function toSolrString()
    {
        $value = $this->getValue();

        foreach ($value as &$subvalue) {
            $subvalue = $this->escape($subvalue);
        }

        if ($value['t'] && $value['s']) {
            if (!$this->isQuoted($value))
                $value['s'] = $this->getTransformedValue(false, $value['s']);

            $template = implode(' OR ', array_map(function($field){
                return sprintf('(sf_d%d:"$sa {s_unquoted} $s2 {t_unquoted}"~100 AND mrc_d%d_sa:({s}) AND mrc_d%d_s2:({t}))',
                    $field, $field, $field);
            }, $this->fields));

        } elseif ($value['t']) {
            $template = implode(' OR ', array_map(function($field){
                return sprintf('mrc_d%d_s2:({t})',
                    $field);
            }, $this->fields));
        } elseif ($value['s']) {
            if ($this->isQuoted($value)) {
                $template = 'facets_subject:{s}';
                $this->setAddPlusBetweenWords(false);
            } else {
                //This add plus between words
                $value['s'] = $this->getTransformedValue(false, $value['s']);
                $template = 'fldin_txt_subject:({s})';
            }

        } else {
            $template = '*:*';
        }

        $condition =  str_replace('{s}', $value['s'], $template);
        $condition =  str_replace('{s_unquoted}', str_replace('"', '', $value['s']), $condition);
        $condition =  str_replace('{t}', $value['t'], $condition);
        $condition =  str_replace('{t_unquoted}', str_replace('"', '', $value['t']), $condition);

        return $condition;
    }

    /**
     * @return string
     */
    public function getDisplayedValue()
    {
        $value = $this->getValue();

        $stringPieces = array();
        if (isset($value['s']) && $value['s']) {
            $stringPieces[] = $value['s'];
        }
        if (isset($value['t']) && $value['t']) {
            $soggettario = $this->getDisplayValueTransformation()->transform($value['t']);
            $stringPieces[] = "soggettario \"{$soggettario}\"";
        }
        return implode(', ', $stringPieces);
    }

    private function isQuoted($value)
    {
        return $value['s'][0] === '"' && $value['s'][strlen($value['s'])-1] === '"';
    }
}
