<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class LibraryAreaSearchField extends TemplateSolrSearchField
{
    /**
     * Build the template string to pass to the parent constructor
     *
     * @return array|string
     */
    public function getTemplate()
    {
        $ids = $this->getLibraryIds($this->getValue());

        $conditions = array_map(function($id){
                return "faceti_libvisi:$id";
        }, $ids);

        $condition = implode(' OR ', $conditions);
        return $condition;
    }

    /**
     * @param $mapKey
     *
     * @return array
     */
    private function getLibraryIds($mapKey)
    {
        $libraries = LibrariesListPage::get_libraries_area_map();

        return isset($libraries[$mapKey]) ? $libraries[$mapKey] : array();
    }
}
