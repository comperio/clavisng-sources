<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
abstract class QueryHashSearchField extends TemplateSolrSearchField
{
    /**
     * @param $template
     * @param string $labelKey
     */
    public function __construct($template, $labelKey = '')
    {
        parent::__construct($template, $labelKey);
        $labelKey = $this->labelKey;

        $displayTransformation = new CallableTransformation(
            function($value) use ($labelKey) {
                return _t("{$labelKey}_{$value}", $value);
            }
        );

        $this->setDisplayValueTransformation($displayTransformation);
    }

    /**
     * Return the hash of keys / solr query pairs
     *
     * @return array
     */
    abstract function getHash();

    /**
     * @return string
     */
    public function getTemplate()
    {
        $value = $this->getValue();
        $hash = $this->getHash();

        if (isset($hash[$value])) {
            return $hash[$value];
        }

        return '*:*';
    }
}
