<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class TargetSearchField extends QueryHashSearchField
{
    /** @var CdfMapInterface  */
    private $cdfMap;

    /**
     * @var array
     */
    private $cachedMap;

    public function __construct($template, $labelKey = '')
    {
        parent::__construct($template, $labelKey);

        //Transformation
        $that = $this;
        $this->setDisplayValueTransformation(new CallableTransformation(function($value) use ($that) {
            $map = $that->getComputedMap();
            return isset($map[$value]) ? $map[$value] : $value;
        }));
    }

    /**
     * Set Map
     *
     * @param mixed $map
     *
     * @return TargetSearchField The current instance
     */
    public function setCdfMap(CdfMapInterface $map)
    {
        $this->cdfMap = $map;

        return $this;
    }

    /**
     * Get Map
     *
     * @return CdfMapInterface
     */
    public function getCdfMap()
    {
        if (!isset($this->cdfMap))
            $this->cdfMap = new CdfMap;

        return $this->cdfMap;
    }

    /**
     * Return the hash of keys / solr query pairs
     *
     * @return array
     */
    public function getHash()
    {

        $hash = array();
        foreach ($this->getComputedMap() as $key => $value) {
            $hash[$key] = 'mrc_cdf:d100_sa_17_' . $key;
        }

        return $hash;
    }

    /**
     * @return array|string
     */
    public function getComputedMap()
    {
        if (!isset($this->cachedMap))
            $this->cachedMap = $this->getCdfMap()->getMap('100', 'a', '17');

        return $this->cachedMap;
    }
}
