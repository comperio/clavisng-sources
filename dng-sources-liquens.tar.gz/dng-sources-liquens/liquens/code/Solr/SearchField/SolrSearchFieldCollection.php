<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class SolrSearchFieldCollection
{
    /**
     * @var array An array of SolrSearchField objects
     */
    private $fields = array();

    /**
     * @param string $name
     * @param SolrSearchField $field
     *
     * @return SolrSearchFieldCollection The current instance
     */
    public function registerField($name, SolrSearchField $field)
    {
        $this->fields[$name] = $field;

        return $this;
    }

    /**
     * Check if the field has been registered
     *
     * @param string $name
     *
     * @return bool
     */
    public function hasField($name)
    {
        return isset($this->fields[$name]);
    }

    /**
     * Returns a previously registered searchfield
     *
     * @param string $name
     *
     * @return SolrSearchField
     *
     * @throws InvalidArgumentException
     */
    public function getField($name, $cloned = true)
    {
        if (isset($this->fields[$name])){
            if ($cloned) {
                return clone($this->fields[$name]);
            } else {
                return $this->fields[$name];
            }
        }


        throw new InvalidArgumentException("There is no field registered with name $name");
    }
}
