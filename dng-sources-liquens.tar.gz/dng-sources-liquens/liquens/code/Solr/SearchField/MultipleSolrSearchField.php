<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class MultipleSolrSearchField extends SimpleSolrSearchField
{
    /**
     * @return array|string
     */
    public function getTemplate()
    {
        $value = $this->getValue();

        //Get the template for all fields if the value is a scalar
        if (!is_array($value))
            return parent::getTemplate();

        //Get the template for all fields if the value is an array
        //but the subfield is empty, that means "all fields"
        if (isset($value['subfield']) && ! $value['subfield'])
            return str_replace('{value}', '{value.value}', parent::getTemplate());

        return "{$this->getSelectedSolrField()}:{value.value}";
    }

    /**
     * @inheritdoc
     */
    public function getDisplayedValue()
    {
        return $this->getRealValue();
    }

    /**
     * @return string
     */
    public function getLabel()
    {
        $label = parent::getLabel();
        $value = $this->getValue();

        if (is_array($value) && $value['subfield']) {
            $locKey = $this->labelKey . '_' . strtoupper($value['subfield']);
            $label = _t($locKey, $value['subfield']);
        }

        return $label;
    }


    /**
     * Returns the number
     *
     * @return string
     */
    private function getRealValue()
    {
        $value = $this->getValue();
        if (is_array($value))
            return $value['value'];

        return $value;
    }

    /**
     * Return the selected solr field. An empty string means "all"
     *
     * @return string
     */
    private function getSelectedSolrField()
    {
        $value = $this->getValue();
        $field = '';

        if (is_array($value)) {
            $fields = $this->getSolrFields();
            if (isset($fields[$value['subfield']]))
                $field = $fields[$value['subfield']];
        }

        return $field;
    }
}
