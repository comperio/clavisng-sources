<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class SimpleSolrSearchField extends TemplateSolrSearchField
{
    /**
     * @var array
     */
    private $solrFields;

    /**
     * @param $solrFields
     * @param string $labelKey
     */
    public function __construct($solrFields, $labelKey = '')
    {
        if(!is_array($solrFields))
            $solrFields = array($solrFields);

        $this->solrFields = $solrFields;
        $this->labelKey = $labelKey;

        parent::__construct('', $labelKey);
    }

    /**
     * Get SolrFields
     *
     * @return array
     */
    public function getSolrFields()
    {
        return $this->solrFields;
    }

    /**
     * Build the template string to pass to the parent constructor
     *
     * @return array|string
     */
    public function getTemplate()
    {
        foreach ($this->solrFields as $solrField) {
            $conditions[] = "$solrField:{value}";
        }

        $condition = implode(' OR ', $conditions);

        return $condition;
    }
}
