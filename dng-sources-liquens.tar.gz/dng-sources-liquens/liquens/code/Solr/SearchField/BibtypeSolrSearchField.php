<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class BibtypeSolrSearchField extends SimpleSolrSearchField
{
    public function getTemplate()
    {
        $value = $this->getValue();

        if (is_array($value)){
            if (isset($value['bibtype']) && $value['bibtype']) {
                return 'mrc_d901_sa:{value.bibtype}';
            } else {
                return 'mrc_d901_sc:{value.bibtypefirst}';
            }
        }

        return parent::getTemplate();
    }

    public function getDisplayedValue()
    {
        $value = $this->getValue();

        if (is_array($value)){
            if (isset($value['bibtype']) && $value['bibtype']) {
                global $sc;
                $transformation = $sc->get('transformation.bibtype') ;
                return $transformation->transform($value['bibtype']);
            } else {
                return $this->getDisplayValueTransformation()->transform($value['bibtypefirst']);
            }
        }

        return $this->getDisplayValueTransformation()->transform($value);
    }

}
