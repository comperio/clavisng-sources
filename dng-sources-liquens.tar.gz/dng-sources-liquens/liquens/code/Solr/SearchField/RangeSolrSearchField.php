<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class RangeSolrSearchField extends SimpleSolrSearchField
{
    /**
     * @var bool
     */
    private $strict = false;

    /**
     * @var array
     */
    private $displayValueTemplates;

    /**
     * @return string
     */
    public function __construct($solrFields, $labelKey = '')
    {
        parent::__construct($solrFields, $labelKey);

        $this->displayValueTemplates = array('from' => 'da %s', 'to' => 'fino a %s');
    }

    /**
     * @param null $phrasize
     * @param null $inputValue
     * @return array|mixed|string
     */
    protected function getTransformedValue($phrasize = null, $inputValue = null)
    {
        return $this->getCompletedRange();
    }


    /**
     * If the field is strict, curly brackets will be used instead of square brackets
     *
     * @param bool $strict
     *
     * @return RangeSolrSearchField The current instance
     */
    public function setStrict($strict)
    {
        $this->strict = $strict;

        return $this;
    }

    /**
     * @return bool
     */
    public function isStrict()
    {
        return $this->strict;
    }

    /**
     * @return string
     */
    public function getDisplayedValue()
    {
        if (! is_array($this->getValue())) {
            return parent::getDisplayedValue();
        }

        $rangedValue = $this->getCompletedRange();

        $strings = array();

        if ($rangedValue['from'] != '*') {
            $strings[] = sprintf($this->displayValueTemplates['from'], $rangedValue['from']);
        }

        if ($rangedValue['to'] != '*') {
            $strings[] = sprintf($this->displayValueTemplates['to'], $rangedValue['to']);
        }

        return implode(' ', $strings);
    }

    /**
     * A string used as a template for the getDisplayValue method. The format is the same
     * od php sprintf function.
     *
     * @param array $displayValueTemplates
     *
     * @return RangeSolrSearchField The current instance
     */
    public function setDisplayValueTemplates($displayValueTemplates)
    {
        $this->displayValueTemplates = $displayValueTemplates;

        return $this;
    }

    /**
     * @return string
     */
    public function getDisplayValueTemplates()
    {
        return $this->displayValueTemplates;
    }

    public function getTemplate()
    {
        $parentTemplate = parent::getTemplate();

        return str_replace('{value}', $this->getTemplateRange(), $parentTemplate);
    }


    /**
     * Returns the range string as a template
     * @return string
     */
    private function getTemplateRange()
    {
        if (is_array($this->getValue())) {
            $delimiters = $this->getDelimiters();
            $template = $delimiters[0] . '{value.from}' . ' TO ' . '{value.to}' . $delimiters[1];
        } else {
            $template = '{value}';
        }

        return $template;
    }


    /**
     * @return array|mixed
     */
    private function getCompletedRange()
    {
        $value = $this->getValue();

        if (is_array($value)){
            if (!isset($value['from']) || !$value['from']) {
                $value['from'] = '*';
            } else {
                $value['from'] = $this->escape($value['from']);
            }

            if (!isset($value['to']) || !$value['to']) {
                $value['to'] = '*';
            } else {
                $value['to'] = $this->escape($value['to']);
            }
        }

        return $value;
    }

    /**
     * Returns braces delimiters checking strict option
     *
     * @return array
     */
    private function getDelimiters()
    {
        if($this->isStrict())
                {
                    return array('{', '}');
                }

        return array('[', ']');
    }
}
