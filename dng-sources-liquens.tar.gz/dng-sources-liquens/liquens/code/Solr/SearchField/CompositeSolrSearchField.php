<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

class CompositeSolrSearchField implements SolrSearchField
{
    const REGEX_DELIMITER = '/';

    private $value;

    /**
     * @var array
     */
    private $allowedValues;

    /**
     * @var SolrSearchField[]
     */
    private $fields = array();

    /**
     * @var SolrSearchField[
     */
    private $matchedField;

    private $labelKey;

    public function __construct($labelKey)
    {
        $this->labelKey = $labelKey;
    }

    /**
     * Register a field associated to a regular expression
     *
     * @param string $regexp
     * @param SolrSearchField $field
     *
     * @return CompositeSolrSearchField The current instance
     */
    public function registerField($regexp, SolrSearchField $field)
    {
        if ($regexp[0] !== static::REGEX_DELIMITER || $regexp[strlen($regexp)-1] !== static::REGEX_DELIMITER) {
            $regexp = static::REGEX_DELIMITER . $regexp . static::REGEX_DELIMITER;
        }
        $this->fields[$regexp] = $field;

        return $this;
    }

    /**
     * @return string
     */
    public function toSolrString()
    {
        return $this->matchedField->toSolrString();
    }

    /**
     * @return SolrQuery
     */
    public function toSolrQuery()
    {
        return $this->matchedField->toSolrQuery();
    }

    /**
     * @param mixed $value
     * @return CompositeSolrSearchField the current instance
     */
    public function setValue($value)
    {
        $this->value = $value;

        $this->matchField()->setValue($value);

        return $this;
    }

    /**
     * @return mixed
     */
    public function getValue()
    {
        return $this->value;
    }

    /**
     * @return string
     */
    public function getDisplayedValue()
    {
        return $this->matchedField->getDisplayedValue();
    }

    /**
     * @return string
     */
    public function getLabel()
    {
        return _t($this->labelKey, $this->labelKey);
    }

    /**
     * @param array $allowedValues
     *
     * @return SimpleSolrSearchField The current instance
     */
    public function setAllowedValues($allowedValues)
    {
        $this->allowedValues = $allowedValues;

        return $this;
    }

    /**
     * @return array
     */
    public function getAllowedValues()
    {
        return $this->allowedValues;
    }

    /**
     * @param bool $sortByDisplayValue
     *
     * @return array
     */
    public function getAllowedValuesDisplayMap($sortByDisplayValue = true)
    {
        $map = array();

        foreach ($this->getAllowedValues() as $value) {
            $map[$value] = $value;
        }

        if ($sortByDisplayValue)
            asort($map);

        return $map;
    }

    /**
     * Clone subfields
     */
    public function __clone()
    {
            foreach ($this->fields as $key => $field) {
                $this->fields[$key] = clone $field;
            }
    }

    /**
     * Finds the field that match the current value
     *
     * @return SolrSearchField The matched field
     * @throws LogicException
     */
    private function matchField()
    {
        $matched = null;
        $value = $this->getValue();

        foreach ($this->fields as $regexp => $field) {
            if (preg_match($regexp, $value)) {
                $matched = $field;
                break;
            }
        }

        if (!$matched)
            throw new LogicException('None of field regexps matched the current value');

        $this->matchedField = $matched;

        return $matched;
    }

}