<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class TemplateSolrSearchField implements SolrSearchField
{
    /**
     * @var string
     */
    protected $labelKey;

    /**
     * @var mixed
     */
    private $value;

    /**
     * @var bool
     */
    private $relevantForScoring = true;

    /**
     * @var string
     */
    private $tagName;

    /**
     * @var bool
     */
    private $phrasized = false;

    /**
     * @var bool
     */
    private $parenthesized = true;

    /**
     * @var bool
     */
    private $addPlusBetweenWords = false;

    /**
     * @var array
     */
    private $template;

    /**
     * @var string
     */
    private $solrQueryClass = 'SolrQuery';

    /**
     * @var bool
     */
    private $includePhraseCondition = false;

    /**
     * @var Transformation
     */
    private $displayValueTransformation;

    /**
     * @var array
     */
    private $allowedValues = array();

    /**
     * @param $template
     * @param string $labelKey
     */
    public function __construct($template, $labelKey = '')
    {
        $this->template = $template;
        $this->labelKey = $labelKey;
    }

    /**
     * @return string
     */
    public function toSolrString()
    {
        $orConditions = array();
        if ($this->includePhraseCondition) {
            $orConditions[] = $this->generateQueryFromTemplate($this->getTransformedValue(true));
            $orConditions[] = $this->generateQueryFromTemplate($this->getTransformedValue(false));
        } else {
            $orConditions[] = $this->generateQueryFromTemplate($this->getTransformedValue());
        }

        if (count($orConditions) > 1) {
            return '(' . implode(') OR (', $orConditions) . ')';
        }

        return $orConditions[0];
    }

    /**
     * @return SolrQuery
     */
    public function toSolrQuery()
    {
        $condition = $this->toSolrString();

        $condition = $this->applyTag($condition);

        $query = $this->createQuery();

        if ($this->isRelevantForScoring()) {
            $query->setMainQuery($condition);
        } else {
            $query->addFilterQuery($condition);
        }

        return $query;
    }

    /**
     * @param mixed $value
     * @return mixed
     */
    public function setValue($value)
    {
        $this->value = $value;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getValue()
    {
        return $this->value;
    }

    /**
     * @return string
     */
    public function getDisplayedValue()
    {
        $value = $this->getValue();
        $transformation = $this->getDisplayValueTransformation();

        if(isset($transformation))
                {
                    return $transformation->transform($value);
                }

        return $value;
    }

    /**
     * @return string
     */
    public function getLabel()
    {
        return _t($this->labelKey, $this->labelKey);
    }

    /**
     * @param boolean $relevantForScoring
     *
     * @return \SimpleSolrSearchField
     */
    public function setRelevantForScoring($relevantForScoring)
    {
        $this->relevantForScoring = $relevantForScoring;

        return $this;
    }

    /**
     * @return bool
     */
    public function isRelevantForScoring()
    {
        return $this->relevantForScoring;
    }

    /**
     * @param string $tagName
     *
     * @return SimpleSolrSearchField The current instance
     */
    public function setTagName($tagName)
    {
        $this->tagName = $tagName;

        return $this;
    }

    /**
     * @return string
     */
    public function getTagName()
    {
        return $this->tagName;
    }

    /**
     * @param Transformation $displayValueTransformation
     *
     * @return SimpleSolrSearchField The current instance
     */
    public function setDisplayValueTransformation(Transformation $displayValueTransformation)
    {
        $this->displayValueTransformation = $displayValueTransformation;

        return $this;
    }

    /**
     * @return Transformation
     */
    public function getDisplayValueTransformation()
    {
        return $this->displayValueTransformation;
    }

    /**
     * @param array $allowedValues
     *
     * @return SimpleSolrSearchField The current instance
     */
    public function setAllowedValues($allowedValues)
    {
        $this->allowedValues = $allowedValues;

        return $this;
    }

    /**
     * @return array
     */
    public function getAllowedValues()
    {
        return $this->allowedValues;
    }

    /**
     * @param bool $sortByDisplayValue
     *
     * @return array
     */
    public function getAllowedValuesDisplayMap($sortByDisplayValue = true)
    {
        $transformation = $this->displayValueTransformation;

        $map = array();

        foreach ($this->getAllowedValues() as $value) {
            $transformedValue = $value;
            if(isset($transformation))
                    {
                        $transformedValue = $transformation->transform($value);
                    }
            $map[$value] = $transformedValue;
        }

        asort($map);

        return $map;
    }

    /**
     * @param bool $phrasized
     * @return SimpleSolrSearchField
     */
    public function setPhrasized($phrasized)
    {
        $this->phrasized = $phrasized;

        return $this;
    }

    /**
     * @return bool
     */
    public function isPhrasized()
    {
        return $this->phrasized;
    }

    /**
     * Set Parentesized
     *
     * @param boolean $parentesized
     *
     * @return TemplateSolrSearchField The current instance
     */
    public function setParenthesized($parentesized)
    {
        $this->parenthesized = $parentesized;

        return $this;
    }

    /**
     * Get Parentesized
     *
     * @return boolean
     */
    public function getParenthesized()
    {
        return $this->parenthesized;
    }



    /**
     * @param bool $addPlus
     * @return TemplateSolrSearchField
     */
    public function setAddPlusBetweenWords($addPlus)
    {
        $this->addPlusBetweenWords = $addPlus;

        return $this;
    }

    /**
     * If $include is true, the main condition will be prefixed with the same condition
     * with the values protected by quotes, to boost exact-phrase matching.
     *
     * @param bool $include
     *
     * @return \TemplateSolrSearchField The current instance
     */
    public function includePhraseCondition($include = true)
    {
        $this->includePhraseCondition = $include;

        return $this;
    }

    /**
     * Escape the value and protect it with quotes or brackets
     *
     * @param bool|null $phrasize if true the value will be quoted. If null the value is
     *   taken from TemplateSolrSearchField::isPhrasized()
     * @param null $inputValue If specified, transform this value. Use $this->getValue() otherwise
     *
     * @return string
     */
    protected function getTransformedValue($phrasize = null, $inputValue = null)
    {
        if(!isset($inputValue))
            $inputValue = $this->getValue();

        if(!isset($phrasize))
            $phrasize = $this->isPhrasized();

        if (!is_array($inputValue)) {
            $inputValue = $this->removeTrailingQuestionMark($inputValue);

            if ($phrasize) {
                $value = $this->escapePhrase($inputValue);
                $value = "\"$value\"";
            } else {

                $value = $this->escape($inputValue);
                if ($this->addPlusBetweenWords) {
                    $value = $this->addPlusBetweenWords($value);
                }

                if ($this->getParenthesized())
                    $value = "($value)";
            }

            return $value;
        }

        //Recusrisve part: the value is an array
        $template = $this;
        $transformedArrayValue = array();

        foreach ($inputValue as $key => $subval) {
            $transformedArrayValue[$key] = $this->getTransformedValue($phrasize, $subval);
        }

        return $transformedArrayValue;
    }

    /**
     * Escape a string to be inserted safely as value in a Solr Query
     *
     * @param $value
     * @return string
     */
    protected function escape($value)
    {
        return SolrSearcher::escape($value);
    }

    /**
     * Escape a string to be inserted safely in a phrase of a Solr Query
     *
     * @param $value
     * @return string
     */
    protected function escapePhrase($value)
    {
        return SolrSearcher::escapePhrase($value);
    }

    /**
     * Return the query using the template.
     *
     * @param string|array $value The value to use in replacement
     * @param string $placeHolder {$placeHolder} will be substituted by $value
     * @param null|string $template The template to use in the transformation. Null for the current template
     *
     * @return string
     */
    protected function generateQueryFromTemplate($value, $placeHolder = 'value', $template = null)
    {
        if(!isset($template))
            $template = $this->getTemplate();

        if(!is_array($value))
            return str_replace('{' . $placeHolder . '}', $value, $template);

        //Recursive part
        $query = $template;
        foreach ($value as $key => $subval) {
            $query = $this->generateQueryFromTemplate($subval, "$placeHolder.$key", $query);
        }

        return $query;
    }

    /**
     * @return SolrQuery
     */
    private function createQuery()
    {
        $className = $this->solrQueryClass;

        return new $className;
    }

    /**
     * Apply a tag to a condition, if the tagName field is setted
     *
     * @param string $condition
     *
     * @return string
     */
    private function applyTag($condition)
    {
        if (isset($this->tagName)){
            $condition = "{!tag={$this->tagName}}" . $condition;
        }

        return $condition;
    }

    /**
     * Returns the phrase with plus before words
     * @param $phrase
     * @return string
     */
    private function addPlusBetweenWords($phrase)
    {
        if (strpos($phrase, '"') !== false)
            return $phrase;

        $words = array_filter(explode(' ', $phrase));

        $plussedWords = array_map(function($word){
                return "+$word";
            }, $words);

        return implode(' ', $plussedWords);
    }

    /**
     *
     * @param $value
     * @return string
     */
    private function removeTrailingQuestionMark($value)
    {
        if (substr($value, -1) == '?')  {
            return substr($value, 0, -1);
        }

        return $value;
    }

    /**
     * @return array
     */
    public function getTemplate()
    {
        return $this->template;
    }

}
