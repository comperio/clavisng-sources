<?php
/**
 * This file is part of dng
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

/**
 * Find linked entries by a 4xx field
 */
class LinkedEntriesField extends TemplateSolrSearchField
{
    public function __construct($labelKey = '')
    {
        parent::__construct("mrc_d{value.field}_s0:{value.id}", $labelKey);

        $this->setDisplayValueTransformation(new CallableTransformation(function (array $value) {
            return isset($value['title']) ? $value['title'] : $value['id'];
        }));
    }

    /**
     * @return string
     */
    public function getLabel()
    {
        $value = $this->getValue();

        return _t('LV_UNI4XX.' . $value['field']);
    }
} 