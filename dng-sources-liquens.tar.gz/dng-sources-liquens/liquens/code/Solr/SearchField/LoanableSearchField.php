<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class LoanableSearchField extends QueryHashSearchField
{
    /**
     * Return the hash of keys / solr query pairs
     *
     * @return array
     */
    public function getHash()
    {
        $tomorrow = new DateTime('tomorrow');
        $afterTomorrow = new DateTime('+2 days');
        $eightDays = new DateTime('+8 days');

        return array(
            '0' => $this->getQueryForDay($tomorrow),
            '1' => $this->getQueryForDay($afterTomorrow),
            '2' => $this->getQueryForDay($eightDays),
        );
    }

    /**
     * Get the query for the given day limit
     *
     * @param DateTime $day
     * @return string
     */
    private function getQueryForDay(DateTime $day)
    {
        $stringDate = $day->format('Y-m-d');

        return "*:* NOT mrc_d901_sl:[$stringDate TO *]";
    }
}
