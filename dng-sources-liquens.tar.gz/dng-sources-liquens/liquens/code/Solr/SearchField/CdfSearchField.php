<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class CdfSearchField extends TemplateSolrSearchField
{
    /** @var CdfMapInterface */
    private $cdfMap;

    /**
     * Return the template for the Cdf Search Field
     * @return array|string
     */
    public function getTemplate()
    {
        $value = $this->getValue();

        return isset($value['v']) ?
            'mrc_cdf:d{value.n}_s{value.s}_{value.p}_{value.v}'
            : 'mrc_cdf:d{value.n}_s{value.s}_{value.p}_{value.vf}';
    }

    public function getLabel()
    {
        $value = $this->getValue();
        $lastValue = isset($value['v']) ? $value['v'] : '';
        $labels = $this->getCdfMap()->valueToLabels($value['n'], $value['s'], $value['p'], $lastValue);

        return $labels['subfield_label'];
    }

    /**
     * Set CdfMap
     *
     * @param \CdfMapInterface $cdfMap
     *
     * @return CdfSearchField The current instance
     */
    public function setCdfMap(\CdfMapInterface $cdfMap)
    {
        $this->cdfMap = $cdfMap;
        return $this;
    }

    /**
     * Get CdfMap
     *
     * @return \CdfMapInterface
     */
    public function getCdfMap()
    {
        if (!isset($this->cdfMap)) {
            $this->cdfMap = new CdfMap();
        }

        return $this->cdfMap;
    }


}
