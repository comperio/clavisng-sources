<?php

class EresourceSearchField extends QueryHashSearchField {

    public function getHash() {
        return array(
            'URL' => "*:* AND mrc_d856_su:[* TO *]"
        );
    }

}
