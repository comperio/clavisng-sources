<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

/**
 * This search field simply permits to specify the value that will be displayed.
 *
 * This will be used when it is not possible to retrieve a human-readable value for the field,
 * but the source who links the resource knows the value (authorities links in ManifestationPage)
 */
class CustomValueSolrSearchField extends SimpleSolrSearchField
{
    /**
     * @inheritdoc
     */
    public function getDisplayedValue()
    {
        $value = parent::getValue();

        if (is_array($value)) {
            if (isset($value['displayed'])) {
                return $value['displayed'];
            }
            return $value['value'];
        }

        return parent::getDisplayedValue();
    }

    /**
     * @return mixed
     */
    public function getValue()
    {
        $value = parent::getValue();

        if (is_array($value)) {
            if (isset($value['value'])) {
                return $value['value'];
            }
        }

        return $value;
    }
}
