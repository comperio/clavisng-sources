<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
/**
 * The interface of a SolrSearchField
 */
interface SolrSearchField extends SolrCondition
{
    /**
     * @abstract
     * @param mixed $value
     * @return SolrSearchField the current instance
     */
    public function setValue($value);

    /**
     * @abstract
     * @return mixed
     */
    public function getValue();

    /**
     * @abstract
     * @return string
     */
    public function getDisplayedValue();

    /**
     * @abstract
     * @return string
     */
    public function getLabel();

    /**
     * @param array $allowedValues
     *
     * @return SimpleSolrSearchField The current instance
     */
    public function setAllowedValues($allowedValues);

    /**
     * @return array
     */
    public function getAllowedValues();

    /**
     * @param bool $sortByDisplayValue
     *
     * @return array
     */
    public function getAllowedValuesDisplayMap($sortByDisplayValue = true);
}
