<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

/**
* Questa classe si occupa della mappatura tra querystring di ricerca e query
* solr.
* La mappatura è per qs del tipo field_1=f1&value_1=v_1&op_1=and&field_2=....
*
*/
class SolrQueryMapper
{
    /**
     * @var array Configurazione della mappatura
     */
    public $configuration = array();

    /**
     * @var array Dove verranno memorizzati i campi della qs coinvolti
     * nella ricerca
     */
    public $queryAry = array();

    /**
     * @var array Qui memorizziamo i campi della qs non utilizzati nella ricerca
     */
    public $excludedAry = array();

    /**
     * @var array
     */
    public $operators = array();

    /**
     * @var array Tiene traccia per ogni fieldname a che indici del
     * $queryAry è associato
     */
    protected $fieldsIndexAry = array();

    /**
     * @var array Tiene traccia per ogni facet a che indici del
     * $facetsAry è associato
     */
    protected $facetsIndexAry = array();

    /**
     * @var SolrSearchFieldCollection
     */
    private $fieldsCollection;

    /**
     * @param array $configuration
     */
    public function __construct(SolrSearchFieldCollection $fieldCollection)
    {
        $this->fieldsCollection = $fieldCollection;
    }

    /**
     * Popola le proprietà queryAry ed excludedAry
     *
     * @param string|array $query La querystring di ricerca o un array
     * @param array $excluded eventuale campi da aggiungere all'$excluded_ary
     * @return SolrQueryMapper
     */
    public function loadQuery($query, array $excluded = array())
    {
        $this->queryAry = array();
        $this->excludedAry = array();
        $this->operators = array();

        if (!$query) {
            return $this;
        }

        $inputAry = array();

        if (is_string($query)) {
            parse_str($query, $inputAry);
        } else {
            $inputAry = $query;
        }

        if (is_array($excluded) && count($excluded)) {
            $this->excludedAry = $excluded;
        }

        if (is_array($query)) {
            $this->queryAry = $query;
            return $this;
        }

        ksort($inputAry);

        foreach ($inputAry as $qsFieldName
            => $field) {
            $tokens = explode('_', $qsFieldName);
            $qsFieldType = $tokens[0];

            //Popolamento di excludedAry
            if (count($tokens) == 1
                    || !in_array(
                        $qsFieldType, array('field', 'value', 'op', 'lop')
                    )
            ) {
                $this->excludedAry[$qsFieldName] = $field;
                continue;
            }

            $index = $tokens[1];

            if ('field' != strtolower($qsFieldType)) {
                continue;
            }

            $fieldTokens = explode('_', $field);
            $fieldName = $fieldTokens[0];

            if ($this->fieldsCollection->hasField($fieldName)) {

                if (!isset($inputAry['value_' . $index])) {
                    continue;
                }

                $value = $inputAry['value_' . $index];

                $opIndex = 1;
                if (isset($inputAry['lop_' . $index])) {
                    $opIndex = $inputAry['lop_' . $index];
                }

                $op = 'AND';
                if (isset($inputAry['op_' . $opIndex]))
                    $op = $inputAry['op_' . $opIndex];

                $this->registerOperator($opIndex, $op);
                $this->addField($fieldName, $value, $opIndex);
            } else {
                $this->addField($qsFieldName, $field);
            }
        }

        return $this;
    }

    /**
     * Aggiunge un valore associato ad un campo alla query.
     * @param $fieldName
     * @param $value
     * @param string $opIndex
     * @return SolrQueryMapper
     */
    public function addField($fieldName, $value, $opIndex = '1')
    {
        //Caso 1: $fieldName non è nella fieldsCollection
        if(!$this->fieldsCollection->hasField($fieldName)) {
            $this->excludedAry[$fieldName] = $value;
            return $this;
        }

        if ($this->isValueEmpty($value)) {
            return $this;
        }

        //Caso 2:
        $index = false;
        $this->queryAry[] = array(
            'field' => $fieldName, 'value' => $value, 'op_index' => $opIndex
        );
        $indxAry = &$this->fieldsIndexAry;
        $fldsAry = &$this->queryAry;

        //Trovo l'indice per aggiornare fieldsIndexAry.
        if (false === $index) {
            $copyAry = $fldsAry;
            end($copyAry);
            $index = key($copyAry);
        }

        $indxAry[$fieldName][] = $index;
        $indxAry[$fieldName] = array_unique(
            $indxAry[$fieldName]
        );

        return $this;
    }

    /**
     * Rimuove un campo dalla query. Attenzione: se il campo ha sottocampi essi
     * verranno tutti eliminati. Ad esempio, se nella qs c'erano year_from ed
     * year_to e lanciamo removeField('year'), allora nella qsverranno tolti
     * entrambi. Se invece chiamiamo removeField('year','from') verrà rimosso
     * solo year_from.
     *
     * @param string $fieldname
     * @param null|string $op If provided, remove the field only if it is linked to an operator with value $op
     * @return SolrQueryMapper
     */
    public function removeField($fieldname, $op = null)
    {
        $indxAry = $this->fieldsIndexAry;

        if (isset($indxAry[$fieldname])
                && count($indxAry[$fieldname])
        ) {
            foreach ($indxAry[$fieldname] as $index) {
                if (isset($op) && $this->operators[$this->queryAry[$index]['op_index']] != $op)
                    continue;
                $this->removeFieldByIndex($index);
            }
        }

        if (isset($this->excludedAry[$fieldname])) {
            unset($this->excludedAry[$fieldname]);
        }

        return $this;
    }

    /**
     * @param string $name
     * @param string $operator
     * @return SolrQueryMapper The current instance
     */
    public function registerOperator($name, $operator)
    {
        $this->operators[$name] = strtoupper($operator);

        return $this;
    }

    /**
     * Tells if the operator is registered in the mapper
     *
     * @param string $name The name of the operator
     * @return bool
     */
    public function isOperatorRegistered($name)
    {
        return isset($this->operators[$name]);
    }

    /**
     * Rimuove un campo in base al suo indice
     *
     * @param int $index
     * @return SolrQueryMapper
     */
    public function removeFieldByIndex($index)
    {
        $fieldsAry = &$this->queryAry;
        $indxAry = &$this->fieldsIndexAry;


        if (!isset($fieldsAry[$index])) {
            return $this;
        }

        $fieldName = $fieldsAry[$index]['field'];

        //Aggiorno $this->fieldsIndexAry
        $key = array_search($index, $indxAry[$fieldName]);
        unset($indxAry[$fieldName][$key]);
        if (count($indxAry[$fieldName])) {
            //Tappo eventuali buchi
            $indxAry[$fieldName] = array_values(
                $indxAry[$fieldName]
            );
        } else {
            unset($indxAry[$fieldName]);
        }

        unset($fieldsAry[$index]);

        return $this;
    }

    /**
     * Remove a value related to a field
     * 
     * @param string$fieldname
     * @param string $value
     *
     * @return SolrQueryMapper
     */
    public function removeValue($fieldname, $value)
    {
        $values = array();
        if ($this->hasValue($fieldname, $value)) {

            foreach ($this->fieldsIndexAry[$fieldname] as $fieldIndex) {
                if ($this->queryAry[$fieldIndex]['value'] == $value) {
                    $this->removeFieldByIndex($fieldIndex);
                }
            }
        }

        return $this;
    }

    /**
     * Trasforma un valore in un array di valori per Solr
     *
     * @param string $fieldname
     * @param string|array $value
     * @param bool $phrasize Se lanciare l'eventuale phrasizzazione o meno.
     * @return array
     */
    public function getSolrValues($fieldname, $value, $phrasize = true)
    {        
        $solrValues = array();

        //Handle rangeable fields
        if (is_array($value)) {
            if (isset($this->configuration[$fieldname]['rangeable'])
                    && $this->configuration[$fieldname]['rangeable']
            ) {
                $from = isset($value['from']) ? $this->escape($value['from']) : '*';
                $to = isset($value['to']) ? $this->escape($value['to']) : '*';
                $solrValues[]
                        = '[' . trim($from) . ' TO ' . trim($to) . ']';
            } elseif (isset($this->configuration[$fieldname]['multiple'])
            && $this->configuration[$fieldname]['multiple']
            ) {
                $solrValues = array();
                foreach ($value as $k => $v) {
                    $solrValues[$k] = reset(
                        $this->getSolrValues($fieldname, $v, false)
                    );
                }

                ksort($solrValues);
            } else {
                $solrValues[] = '';
            }
        }
        //Handle facetQuery fields
        elseif(isset($this->configuration[$fieldname]['fctQuery'])
                    && $this->configuration[$fieldname]['fctQuery']) {
            $solrValues[] = '(' . $this->configuration[$fieldname]['fctQueryMap'][$value] . ')';
        }
        //Handle phrase fields
        elseif ($phrasize && isset($this->configuration[$fieldname]['phrase']) && $this->configuration[$fieldname]['phrase']) {
            $solrValues[] = '"' . $this->escape($value) . '"';
        }
        //Handle normal fields
        else {
            $solrValues[] = '(' . $this->escape($value) . ')';
        }

        return $solrValues;
    }

    /**
     * Applica, se specificato in this->configuration, al valore (o ai valori
     * se $value è una array) le virgolette.
     *
     * @param string $fieldname
     * @param string|array $value
     * @return string
     */
    public function phrasize($fieldname, $value)
    {
        if (isset($this->configuration[$fieldname]['phrase'])) {
            if (is_array($value)) {
                foreach ($value as $subfield => &$subvalue) {
                    $subvalue = '"' . trim($subvalue) . '"';
                }

            } else {
                $value = '"' . trim($value) . '"';
            }
        }

        return $value;
    }

    /**
     * Returns the main lucene query
     *
     * @return string
     */
    public function getSolrQuery()
    {
        return $this->getQuery()->getMainQuery();
    }

    /**
     * Returns the GET query string
     *
     * @param bool $getExcludedFields
     * @return string
     */
    public function getQueryString($getExcludedFields = true)
    {
        $qsAry = array();

        $i = 1;
        foreach ($this->queryAry as $data) {
            $qsAry['field_' . $i] = $data['field'];
            $qsAry['value_' . $i] = $data['value'];
            $qsAry['lop_' . $i] = $data['op_index'];

            $i++;
        }

        //aggiungo i campi op_n=operator
        foreach($this->operators as $index => $operator) {
            $qsAry['op_' . $index] = strtolower($operator);
        }


        if ($getExcludedFields)
            return http_build_query(array_merge($qsAry, $this->excludedAry));
        return http_build_query($qsAry);
    }

    /**
     * Returns the array of filter queries. Filterqueries are build using facets fields.
     *
     * @return array
     */
    public function getFilterQueries()
    {
        return $this->getQuery()->getFilterQueries();
    }

    /**
     * @param string $fieldName
     *
     * @return bool
     */
    public function hasField($fieldName)
    {
        foreach ($this->queryAry as $fieldData) {
            if ($fieldData['field'] == $fieldName)
                return true;
        }

        foreach ($this->excludedAry as $key => $value) {
            if ($key == $fieldName)
                return true;
        }

        return false;
    }

    /**
     * @param string $fieldName
     * @param string $value
     *
     * @return bool
     */
    public function hasValue($fieldName, $value)
    {
        foreach ($this->queryAry as $fieldData) {
            if ($fieldData['field'] == $fieldName && $fieldData['value'] == $value)
                return true;
        }

        foreach ($this->excludedAry as $key => $excVal) {
            if ($key === $fieldName && $value == $excVal)
                return true;
        }

        return false;
    }

    /**
     * If there is a field named "$field" under an "and" operator, returns the value of that field.
     * Returns null otherwise.
     *
     * @param $field
     *
     * @return string|null
     */
    public function getFilter($field)
    {
        foreach ($this->queryAry as $data) {
            if ($this->operators[$data['op_index']] != 'AND') continue;
            if ($data['field'] == $field)
                return $data['value'];
        }

        return null;
    }

    /**
     * Escape a string to be inserted safely as value in a Solr Query
     *
     * @param $value
     * @return string
     */
    public function escape($value)
    {
        return SolrSearcher::escape($value);
    }

    /**
     * Get SolrQuery object
     *
     * @param null|\SolrQuery $query
     * @return SolrQuery
     */
    public function getQuery(SolrQuery $query = null)
    {

        if(!$query)
            $query = new SolrQuery();

        //If the query passed has already a main query, move it to filter queries
        /*if ($oldMainQuery = $query->getMainQuery()){
            $query
                ->addFilterQuery($oldMainQuery)
            ;
        }*/

        $conditionsSupergroup = new SolrConditionsSupergroup('AND');
        $conditions = array();
        if (!$this->operators)
            $this->registerOperator('1', 'AND');
        foreach ($this->operators as $index => $operator) {
            $conditionsSupergroup->registerGroup($index, new SolrConditionsGroup($operator));
        }
        
        foreach ($this->queryAry as $index => $ary) {
            $fieldName = $ary['field'];
            $value = $ary['value'];
            $opIndex = $ary['op_index'];

            if (!$this->fieldsCollection->hasField($fieldName))
                continue;

            $field = $this->fieldsCollection->getField($fieldName)->setValue($value);

            $conditions[$opIndex][] = $field;
        }

        foreach($conditions as $opIndex => $sameOpConditions) {
            foreach ($sameOpConditions as $condition) {
                $conditionsSupergroup->getGroup($opIndex)->addCondition(
                    $condition
                );
            }
        }

        $query->merge($conditionsSupergroup->toSolrQuery());

        //Set additional query fields
        if (isset($this->excludedAry['start']))
            $query->setRawField('start', $this->excludedAry['start']);
        if (isset($this->excludedAry['rows']))
            $query->setRawField('rows', $this->excludedAry['rows']);
        if (isset($this->excludedAry['sort']))
            $query->setRawField('sort', $this->excludedAry['sort']);


        return $query;
    }

    /**
     * @return \SolrSearchFieldCollection
     */
    public function getFieldsCollection()
    {
        return $this->fieldsCollection;
    }

    /**
     * @param SolrQueryMapper $mapper
     *
     * @return SolrQueryMapper The current instance
     */
    public function merge(SolrQueryMapper $mapper)
    {
        //Excluded ary
        $this->excludedAry = array_merge($this->excludedAry, $mapper->excludedAry);

        //Operators
        $opsMap = array();

        foreach ($mapper->operators as $name => $operator) {
            $newName = $this->generateOperatorName();
            $this->registerOperator($newName, $operator);
            $opsMap[$name] = $newName;
        }

        //Fields
        foreach ($mapper->queryAry as $fieldData) {
            $this->addField($fieldData['field'], $fieldData['value'], $opsMap[$fieldData['op_index']]);
        }

        return $this;
    }

    /**
     * Generate a new operator name that was not already set
     * @return int
     */
    private function generateOperatorName()
    {
        $index = count($this->operators);

        while (isset($this->operators[$index]))
            $index++;

        return $index;
    }

    private function isValueEmpty($value) {
        if ($value === '')
            return true;

        if (is_array($value)) {
            $hasAtLeastOneValue = false;

            array_walk_recursive($value, function($item, $key) use (&$hasAtLeastOneValue) {
                    if ($item !== '')
                        $hasAtLeastOneValue = true;
            });

            if (!$hasAtLeastOneValue)
                return true;
        }

        return false;
    }
}