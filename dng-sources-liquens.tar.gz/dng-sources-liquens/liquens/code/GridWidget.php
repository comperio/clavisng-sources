<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

/**
 * Class GridWidget
 * With the decorator pattern this widget wraps another widget giving some positioning features.
 * This class is automatically used when the area editor is a GridWidgetAreaEditor
 *
 * Each widget will be printed in a cell of a bootstrap row.
 * The Span property determines the bootstrap span class of the cell
 *
 * The NewLine property tells if we have to put the widget in a new row or not.
 */
class GridWidget extends Widget
{
    static $cmsTitle = "Grid Widget";

    static $description = "Give position features to widgets";

    static $db = array(
        'Span' => 'DBInt',
        'NewLine' => 'Boolean',
    );

    static $has_one = array(
        'Widget' => 'Widget',
    );

    static $defaults = array(
        'Span' => 12,
        'NewLine' => true,
    );

    /**
     * Delegates to underlying widget
     *
     * @return mixed
     */
    public function CMSTitle()
    {
        return $this->getLinkedWidget()->CMSTitle();
    }

    /**
     * Delegates to underlying widget
     * @return mixed
     */
    function Description()
    {
        return $this->getLinkedWidget()->Description();
    }

    /**
     * Returns the underlying widget. If there is no persisted relation, it will be returned
     * a new instance of class $this->WidgetClassName
     *
     * @return Widget
     */
    public function getLinkedWidget()
    {
        $widget = $this->Widget();

        if ($widget->ID)
            return $widget;

        $className = $this->WidgetClassName ?: 'Widget';

        return new $className;
    }

    /**
     * Delegates to underlying object
     * @return mixed
     */
    public function Title()
    {
        return  $this->getLinkedWidget()->Title();
    }

    /**
     * CMS Fields for the widget.
     * Span and new line fields are in WidgetEditor.ss html.
     *
     * @return FieldSet
     */
    public function getCMSFields($params = NULL)
    {
        $fields = parent::getCMSFields();

        $widget = $this->getLinkedWidget();

        $fields->push(new HiddenField('WidgetClassName', 'ClassName'));
        $fields->push(new HiddenField('WidgetID', 'WidgetID', $widget->ID));

        return $fields;
    }

    /**
     * The rendered html for the fields.
     * Returns the linked widget html glued with the html for the current instance
     *
     * Fields of the underlying widget will be prefixed with a [LinkedWidget] string
     *
     * @Todo: put the underlying widget fields in their own namespace
     *
     * @return string
     */
    public function CMSEditor()
    {
        $widget = $this->getLinkedWidget();
        $this->WidgetClassName = $this->getLinkedWidget()->ClassName();

        $gridWidgetFields = parent::CMSEditor();
        $linkedWidgetFields = $widget->CMSEditor();

        //Linked widget fields names are in the form Widget[linked-widget-id][LinkedWidgetField]
        //We replace Widget[linked-widget-id] with Widget[grid-widget-id][LinkedWidget]
        $linkedWidgetFields = preg_replace('/Widget\[[^\[\]]+\]/', "Widget[{$this->ID}][LinkedWidget]", $linkedWidgetFields);

        return $gridWidgetFields . $linkedWidgetFields;
    }


    /**
     * @param $data
     */
    public function populateFromPostData($data)
    {
        switch ($data['Positioning']) {
            case 'newline':
                $data['NewLine'] = true;
                break;
            case 'near':
                $data['NewLine'] = false;
                break;
            case 'below':
                $data['NewLine'] = false;
                $data['Span'] = 0;
                break;
        }

        $data['NewLine'] = isset($data['NewLine']) ? $data['NewLine'] : false;
        parent::populateFromPostData($data);

        $widget = $this->getLinkedWidget();

        $widget->populateFromPostData($data['LinkedWidget']);

        $this->WidgetID = $widget->ID;

        $this->write();
    }

    /**
     * Return 'below' if the span is 0, 'near' if span is not zero and NewLine is false,
     * 'newline' otherwise.
     *
     * @return string
     */
    public function getPositioning()
    {
        if (!$this->Span)
            return 'below';

        if (!$this->NewLine)
            return 'near';

        return 'newline';
    }

    /**
     * This appears in the left side part of the GridWidgetArea
     *
     * @return string
     */
    public function DescriptionSegment()
    {
        return $this->renderWith('GridWidgetDescription');
    }

    /**
     * This appears in the right side of the GridWidgetArea
     *
     * @return string
     */
    public function EditableSegment()
    {
        if (isset($_GET['WidgetClassName']))
            $this->WidgetClassName = $_GET['WidgetClassName'];
        return parent::EditableSegment(); // TODO: Change the autogenerated stub
    }

    /**
     * Duplicate underlying widget on duplication
     * @param bool $doWrite
     * @return DataObject
     */
    function duplicate($doWrite = true)
    {
        $duplicated = parent::duplicate($doWrite);

        if ($this->WidgetID) {
            $clonedLinkedWidget = $this->Widget()->duplicate();
            $duplicated->WidgetID = $clonedLinkedWidget->ID;
            $duplicated->write();
        }

        return $duplicated;
    }
}

/**
 * Class GridWidget_Controller
 */
class GridWidget_Controller extends Widget_Controller
{
    /**
     * @return string
     */
    public function WidgetHolder()
    {
        return $this->renderWith('GridWidgetHolder');
    }

    /**
     * Get a controller linked to the underlying widget
     * @return mixed
     */
    public function getLinkedController()
    {
        $widget = $this->getWidget()->getLinkedWidget();
        $controllerClass = '';
        foreach(array_reverse(ClassInfo::ancestry($widget->class)) as $widgetClass) {
            $controllerClass = "{$widgetClass}_Controller";
            if(class_exists($controllerClass)) break;
        }
        $controller = new $controllerClass($widget);
        $controller->init();

        return $controller;
    }

    /**
     * True when a new line, in the html, must be opened
     * @return bool
     */
    function OpenNewLine()
    {
        return $this->First() || $this->getWidget()->NewLine;
    }

    /**
     * True when the preceeding line has to be closed
     *
     * @return bool
     */
    function ClosePreceedingLine()
    {
        return !$this->First() && $this->getWidget()->NewLine;
    }

    function OpenNewColumn()
    {
        return $this->OpenNewLine() || $this->getWidget()->Span != 0;
    }

    function ClosePreceedingColumn()
    {
        return !$this->First() && $this->OpenNewColumn();
    }
}
