<?php
/*
 * This file is part of dng.
 *
 * (c) 2013 Nicolò Martini
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

class PendingLoansCountUserData extends AbstractUserData
{
    /**
     * {@inheritdoc}
     */
    public function getName()
    {
        return 'PendingLoansCount';
    }

    /**
     * {@inheritdoc}
     */
    public function getValue()
    {
        $member = DataObject::get_by_id('Member', $this->getMemberID());

        if ($member) {
            return $member->getPendingLoans(false)->Count();
        }

        return 0;
    }
}