<?php
/*
 * This file is part of dng.
 *
 * (c) 2013 Nicolò Martini
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

class UserDataCacheProxy implements UserData
{
    /**
     * @var UserData
     */
    protected $userData;

    /**
     * @var int
     */
    private $validTimeInterval;

    /**
     * @param UserData $userData
     * @param int $validTimeInterval
     */
    public function __construct(UserData $userData, $validTimeInterval = 3600)
    {
        $this->userData = $userData;
        $this->validTimeInterval = $validTimeInterval;
    }

    /**
     * @return string
     */
    public function getName()
    {
        return $this->userData->getName();
    }

    /**
     * @return string
     */
    public function getValue()
    {
        $cachedData = $this->getCachedData();

        if (!$cachedData || !$this->isFresh($cachedData))
            $cachedData = $this->cache($cachedData);

        return $cachedData->Value;
    }

    /**
     * {@inheritdoc}
     */
    public function getMemberID()
    {
        return $this->userData->getMemberID();
    }

    /**
     * {@inheritdoc}
     */
    public function setMemberID($memberID)
    {
        $this->userData->setMemberID($memberID);

        return $this;
    }

    /**
     * Tells if the CachedUserData is considered fresh by this proxy
     *
     * @param CachedUserData $data
     *
     * @return bool
     */
    private function isFresh(CachedUserData $data)
    {
        return time() - strtotime($data->LastUpdated) < $this->validTimeInterval;
    }

    /**
     * Store the data and return the stored data
     *
     * @param CachedUserData|bool $oldCache
     * @return CachedUserData the current instance
     */
    private function cache($oldCache = false)
    {
        $data = $oldCache ?: new CachedUserData();

        $data->Name = $this->userData->getName();
        $data->Value = $this->userData->getValue();
        $data->MemberID = $this->userData->getMemberID();
        $data->LastUpdated = date('Y-m-d H:i:s');
        $data->write();

        return $data;
    }

    /**
     * @return bool|CachedUserData
     */
    private function getCachedData()
    {
        return DataObject::get_one(
            'CachedUserData',
            sprintf("Name = '%s' AND MemberID = %d", Convert::raw2sql($this->getName()), $this->getMemberID())
        );
    }
}