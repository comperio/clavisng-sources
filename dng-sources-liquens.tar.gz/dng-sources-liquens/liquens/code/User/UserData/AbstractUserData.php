<?php
/*
 * This file is part of dng.
 *
 * (c) 2013 Nicolò Martini
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

abstract class AbstractUserData implements UserData
{
    private $memberID;

    /**
     * {@inheritdoc}
     */
    abstract public function getName();

    /**
     * {@inheritdoc}
     */
    abstract public function getValue();

    /**
     * {@inheritdoc}
     */
    public function getMemberID()
    {
        return $this->memberID;
    }

    /**
     * {@inheritdoc}
     */
    public function setMemberID($memberID)
    {
        $this->memberID = $memberID;

        return $this;
    }


}