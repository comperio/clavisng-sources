<?php
/*
 * This file is part of dng.
 *
 * (c) 2013 Nicolò Martini
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

class CachedUserData extends DataObject
{
    public static $db = array(
        'Name' => 'VarChar(255)',
        'Value' => 'VarChar(255)',
        'LastUpdated' => 'SS_Datetime',
    );

    public static $has_one = array(
        'Member' => 'Member'
    );

    public static $indexes = array(
        'MemberID_Name' => '(MemberID, Name)'
    );

    /**
     * Invalidate cache entry by setting LastUpdateTime to 0
     * @param $name
     * @param $memberId
     */
    public static function invalidate_cache($name, $memberId)
    {
        /** @var CachedUserData $cachedData */
        $cachedData = static::get_cache($name, $memberId);

        if ($cachedData) {
            $cachedData->invalidate();
        }
    }

    /**
     * Invalidate all cached data attached to an user
     * @param $memberID
     */
    public static function flush($memberID)
    {
        $datas = DataObject::get('CachedUserData', 'MemberID = ' . (int) $memberID) ?: new DataObjectSet;

        foreach ($datas as $cachedData) {
            $cachedData->invalidate();
        }
    }

    /**
     * Get Cache entry by name and member id
     * @param $name
     * @param $memberId
     * @return DataObject
     */
    public static function get_cache($name, $memberId)
    {
        return DataObject::get_one('CachedUserData', sprintf("Name = '%s' AND MemberID = %d", Convert::raw2sql($name), $memberId));
    }

    /**
     * Set LastUpdated field to 0
     */
    public function invalidate()
    {
        $this->LastUpdated = '1970-01-01 01:00:00';
        $this->write();
    }
}