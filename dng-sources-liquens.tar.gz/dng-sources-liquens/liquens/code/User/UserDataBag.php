<?php
/*
 * This file is part of dng.
 *
 * (c) 2013 Nicolò Martini
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

/**
 * Class UserDataBag: A UserData provider
 */
class UserDataBag
{
    /**
     * @var int
     */
    private $memberID;

    /**
     * @param int $memberID
     */
    public function __construct($memberID)
    {
        $this->memberID = $memberID;
    }

    /**
     * @param $name
     *
     * @return UserData
     */
    public function getData($name)
    {
        return $this->createUserData($name);
    }

    /**
     * @param int $memberID
     * @return $this
     */
    public function setMemberID($memberID)
    {
        $this->memberID = $memberID;
        return $this;
    }

    /**
     * @return int
     */
    public function getMemberID()
    {
        return $this->memberID;
    }

    /**
     * Factory method that instantiate a new UserData object given the name of the data
     * @param $dataName
     * @return UserData
     * @throws InvalidArgumentException
     */
    private function createUserData($dataName)
    {
        $className = $dataName . 'UserData';

        if (class_exists($className)) {
            /** @var $userData UserData */
            $userData = new $className;
            $userData->setMemberID($this->getMemberID());

            return $userData;
        }

        throw new InvalidArgumentException("Class $className does not exist");
    }
}