<?php
/*
 * This file is part of dng.
 *
 * (c) 2013 Nicolò Martini
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

/**
 * Class UserDataBagProxy
 * Proxy all UserDatas returned by the underlying UserDataBag with an instance of static::PROXY_CLASS
 */
class UserDataBagProxy extends UserDataBag
{
    /**
     * @var UserDataBag
     */
    private $userDataBag;

    /**
     * @var int
     */
    private $validTimeInterval;

    const PROXY_CLASS = 'UserDataCacheProxy';

    /**
     * @param UserDataBag $bag
     * @param int $validTimeInterval
     */
    public function __construct(UserDataBag $bag, $validTimeInterval = 3600)
    {
        $this->userDataBag = $bag;
        $this->validTimeInterval = $validTimeInterval;
    }

    /**
     * {@inheritdoc}
     */
    public function setMemberID($memberID)
    {
        $this->userDataBag->setMemberID($memberID);

        return $this;
    }

    /**
     * {@inheritdoc}
     */
    public function getMemberID()
    {
        return $this->userDataBag->getMemberID();
    }

    /**
     * {@inheritdoc}
     */
    public function getData($name)
    {
        $className = static::PROXY_CLASS;

        return new $className(parent::getData($name), $this->validTimeInterval);
    }
}