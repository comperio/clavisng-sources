<?php
/**
 * This file is part of dng
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

class Panel extends ViewableData
{
    /**
     * @var string
     */
    private $name;

    /**
     * @var bool
     */
    private $active = false;

    /**
     * @var string
     */
    private $template;

    /**
     * @param string $name
     * @param string $template
     * @param bool $active
     */
    public function __construct($name, $template, $active = false)
    {
        $this->name = $name;
        $this->template = $template;
        $this->active = $active;
    }

    /**
     * Get Name
     *
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Get Active
     *
     * @return boolean
     */
    public function getActive()
    {
        return $this->active;
    }

    /**
     * @return string
     */
    public function getActiveClass()
    {
        return $this->getActive() ? 'in' : 'collapse';
    }

    /**
     * @return string
     */
    public function forTemplate()
    {
        return $this->renderWith($this->template);
    }

    /**
     * Usual function to bypass ss template weirdness
     */
    public function dTop()
    {
        $top = Controller::curr();
        return $top;
    }
} 