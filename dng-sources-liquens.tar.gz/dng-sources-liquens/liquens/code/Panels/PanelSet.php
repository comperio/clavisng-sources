<?php
/**
 * This file is part of dng
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

/**
 * Class PanelSet
 *
 * A set of panels. Used in the manifestation page
 */
class PanelSet extends DataObjectSet
{
    /**
     * @param string $name
     * @param string $template
     * @param bool $active
     * @return $this
     */
    public function addPanel($name, $template, $active = false)
    {
        $this->push(new Panel($name, $template, $active));

        return $this;
    }

    /**
     * @param array $panels
     * @return $this
     */
    public function addPanels(array $panels)
    {
        foreach ($panels as $panel) {
            list($name, $template, $active) = $panel;
            $this->addPanel($name, $template, $active);
        }

        return $this;
    }
} 