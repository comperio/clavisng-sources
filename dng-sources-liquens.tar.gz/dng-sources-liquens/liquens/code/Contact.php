<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

class Contact extends DataObject
{
    public static $db = array(
        'ServiceName' => 'VarChar(255)',
        'ServiceURL' => 'Text',
        'Active' => 'Boolean'
    );

    public static $defaults = array(
        'Active' => true,
    );

    public static $indexes = array(
        'ServiceName' => true,
        'Active' => true,
    );
}