<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

/**
 * This class extends Silverstripe's Requirements class overwriting
 * the method path_for_file, in order to remove the lang segment
 * in the requirements files url.
 */
class LqRequirements extends Requirements_Backend
{
    /**
     * The lang code to remove
     *
     * @var bool|string
     */
    public static $lang = false;

    private $requireJsPrefix = 'requirejs:';

    private $requireJsPath = 'bower_components/requirejs/require.js';

    private $commonModule = 'common';
    private $emptyModule = 'empty';

    private $jsFolder = 'liquens/javascript';

    private $jsOptimizedFolder = 'liquens/javascript-built';

    /**
     * Overwrite javascript inclusion method to allow requirejs main script inclusion.
     * If $file starts with a 'requirejs:' prefix, it will print the requirej script tag with the remaining part
     * of $file string as a data-main attribute.
     *
     * @param string $file
     */
    public function javascript($file)
    {
        if (0 === stripos($file, $this->requireJsPrefix)) {
            $mainFile = substr($file, strlen($this->requireJsPrefix));

            //If mainFile is empty, check if the tag has not been already set
            if (!$mainFile && isset($this->customHeadTags['requirejs']))
                return;

            $dataMain = $this->getMainAttribute($mainFile);
            $localizedDataMain = $this->getLocaleAntiSegment() . $dataMain;
            $srcAttribute = $this->getSrcAttribute();

            $dataMainTimestamp = filemtime(Director::baseFolder() . '/' . $dataMain . '.js');

            $configPath = $this->path_for_file("{$this->getBaseJsFolder()}/config.js");
            $srcAttribute = $this->path_for_file($srcAttribute);

            $this->insertHeadTags(
                "<script src='".htmlentities(strip_tags($configPath))."'></script>\n" .
                "<script data-main='$localizedDataMain.js?m=$dataMainTimestamp' src='".htmlentities(strip_tags($srcAttribute))."'></script>\n",
                'requirejs'
            );
        } else {
            parent::javascript($file);
        }
    }

    /**
     * Overriden in order to inject the custom header code after all requirements.
     *
     * @param $templateFile
     * @param string $content
     * @return mixed|string
     */
    function includeInHTML($templateFile, $content)
    {
        $content = parent::includeInHTML($templateFile, $content);
        $controller = Controller::curr();

        if (isset($controller->SiteConfig->CustomHeaderCode) && $controller->SiteConfig->CustomHeaderCode) {
            $content = preg_replace("/(<\/head>)/i", $controller->SiteConfig->CustomHeaderCode . "\\1", $content);
        }

        return $content;
    }


    /**
     * If the $lang property is setted, removes the lang code segment
     * from the path returned
     *
     * @param string $fileOrUrl
     * @return bool|string
     */
    protected function path_for_file($fileOrUrl)
    {
        $oldBaseUrl = Director::baseURL();

        if (LangController::$lang){

            $pieces = explode('/', $oldBaseUrl);
            unset($pieces[count($pieces)-2]);

            Director::setBaseURL(implode('/', $pieces));

            $path = parent::path_for_file($fileOrUrl);

            Director::setBaseURL($oldBaseUrl);

        } else {

            $path = parent::path_for_file($fileOrUrl);
        }

        return $path;
    }

    protected function isOptimized()
    {
        return !isset($_GET['debugjs']);
    }

    private function getBaseJsFolder()
    {
        return $this->isOptimized() ? $this->jsOptimizedFolder : $this->jsFolder;
    }

    private function getRequireJsPath()
    {
        return $this->requireJsPath;
    }

    private function getMainAttribute($mainFile = '')
    {
        if (!$mainFile)
            $mainFile = 'empty';

        return "{$this->getBaseJsFolder()}/$mainFile";
    }

    private function getSrcAttribute()
    {
        return $this->isOptimized() ?
            "{$this->getBaseJsFolder()}/{$this->commonModule}.js" :
            $this->getRequireJsPath()
        ;
    }

    /**
     * Retrieve the locale antisegment from the current controller
     * @return string
     */
    private function getLocaleAntiSegment()
    {
        $controller = Controller::curr();
        return method_exists($controller, 'getLocaleAntiSegment')
            ? $controller->getLocaleAntiSegment()
            : ''
        ;
    }

}
