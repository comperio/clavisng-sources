<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class TypedWidgetAreaEditor extends WidgetAreaEditor
{
    function AvailableWidgets()
    {
        $widgets= new DataObjectSet();

        foreach($this->widgetClasses as $widgetClass) {
            $classes = ClassInfo::subclassesFor($widgetClass) + ClassInfo::implementorsOf($widgetClass);
            array_shift($classes);
            foreach($classes as $class) {
                //An interface cannot be transformed to an instance, so we check if $class is a class
                if (class_exists($class))
                    $widgets->push(singleton($class));
            }
        }

        return $widgets;
    }
}
