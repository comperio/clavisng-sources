<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

class GridWidgetAreaEditor extends WidgetAreaEditor
{
    public function AvailableWidgets()
    {
        $widgets = new DataObjectSet();

        foreach (parent::AvailableWidgets() as $widget)
        {
            $gridwidget = new GridWidget;
            $gridwidget->WidgetClassName = $widget->ClassName();
            $widgets->push($gridwidget);
        }

        return $widgets;
    }
}