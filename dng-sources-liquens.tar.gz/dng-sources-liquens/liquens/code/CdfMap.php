<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class CdfMap implements CdfMapInterface
{
    private $locale;

    /**
     * @param null $locale
     */
    public function __construct($locale = null)
    {
        if (!isset($locale))
            $locale = i18n::get_locale();

        $this->locale = $locale;
    }

    /**
     * Returns a map of codes => labels for cdf fields.
     * The map are hierarchical. If you specify no arguments, you will get the map of all macro-fields area
     * If you specify the field, you will get the map of subfield => labels for that field... and so on.
     *
     * @param null|string $field
     * @param null|string $subfield
     * @param null|string $position
     * @param null|string $value
     * @return string|array
     */
    public function getMap($field = null, $subfield = null, $position = null, $value = null)
    {
        $result = $this->getQueryResult($field, $subfield, $position, $value);

        return $this->getMapFromResult($result, $field, $subfield, $position, $value);
    }

    /**
     * @param null|string $field
     * @param null|string $subfield
     * @param null|string $position
     * @param null|string $value
     * @return array
     */
    public function valueToLabels($field = null, $subfield = null, $position = null, $value = null)
    {
        $row = $this->getQueryResult($field, $subfield, $position, $value)->current();

        $row = $this->postProcessLabels($row, $field, $subfield, $position, $value);

        return $row;
    }


    /**
     * Performs the query and return its result
     * @param null|string $field
     * @param null|string $subfield
     * @param null|string $position
     * @param null|string $value
     * @return SS_Query
     */
    private function getQueryResult($field = null, $subfield = null, $position = null, $value = null)
    {
        $query =
            $this->getMainQuery() .
            $this->getWhereFilter($field, $subfield, $position, $value) .
            $this->getGroupByStatement($field, $subfield, $position, $value)
        ;

        return Db::query($query);
    }

    /**
     * Returns the main filter to use in the sql query
     *
     * @param null|string $field
     * @param null|string $subfield
     * @param null|string $position
     * @param null|string $value
     * @param $value
     *
     * @return string
     */
    private function getWhereFilter($field, $subfield, $position, $value)
    {
        $filter = '';

        if (isset($field))
            $filter .= ' AND c.field_number = ' . (int) $field;
        else {
            //if no field is selected, the field name must be retrieved with unimarc_labels.subfield_tag = a or null
            $filter .= ' AND l2.subfield_tag=\'a\'';
        }

        if (isset($subfield))
            $filter .= ' AND c.subfield_tag = \'' . Convert::raw2sql($subfield) . '\'';

        if (isset($position))
            $filter .= ' AND c.pos = ' . (int) $position;

        if (isset($value))
            $filter .= ' AND c.code_value = \'' . Convert::raw2sql($value) . '\'';

        return $filter;
    }

    /**
     * Gives the group by statement accordingly to the number of non-null arguments
     *
     * @param $field
     * @param $subfield
     * @param $position
     * @param $value
     *
     * @return string
     */
    private function getGroupByStatement($field, $subfield, $position, $value)
    {
        $groupByPieces = array('field_value');

        if (isset($field)) {
            $groupByPieces[] = 'subfield_value';

            if (isset($subfield)) {
                $groupByPieces[] = 'position_value';

                if (isset($position)) {
                    $groupByPieces[] = 'value';
                }
            }
        }

        return ' GROUP BY ' . implode(', ', $groupByPieces);
    }

    /**
     * Returns the main SQL query
     *
     * @return string
     */
    private function getMainQuery()
    {
        $locale = Convert::raw2sql($this->locale);
        $query = "
        SELECT l2.field_number AS 'field_value',
               IF(l1.label IS NULL, l2.label, l1.label) AS 'field_label',
               l2.subfield_tag AS 'subfield_value',
               l2.label        AS 'subfield_label',
               c.pos           AS 'position_value',
               c.group_label   AS 'position_label',
               c.code_value    AS 'value',
               c.label         AS 'value_label'
        FROM   (unimarc_labels l1
               RIGHT JOIN unimarc_labels l2
                 ON l1.field_number = l2.field_number
                    AND l1.language = l2.language
                    AND l1.subfield_tag = '')
               JOIN unimarc_codes_bonified c
                 ON c.language = l2.language
                    AND c.field_number = l2.field_number
                    AND c.subfield_tag = l2.subfield_tag
        WHERE  c.language = '$locale'
        ";

        return $query;
    }

    /**
     * @param Traversable $result
     * @param null|string $field
     * @param null|string $subfield
     * @param null|string $position
     * @param null|string $value
     *
     * @return array|string
     */
    private function getMapFromResult(Traversable $result, $field = null, $subfield = null, $position = null, $value = null)
    {
        $map = array();

        foreach ($result as $row) {
            $keyValuePair = $this->rowToKeyValuePair($row, $field, $subfield, $position, $value);
            $map[$keyValuePair[0]] = ucfirst($keyValuePair[1]);
        }

        $map = $this->postProcessMap($map, $field, $subfield, $position, $value);

        return $map;
    }

    /**
     * @param array $row
     * @param null $field
     * @param null $subfield
     * @param null $position
     * @param null $value
     * @return array
     */
    private function rowToKeyValuePair(array $row, $field = null, $subfield = null, $position = null, $value = null)
    {
        if (isset($value))
            return array($row['value'], $row['value_label']);

        if (isset($position))
            return array($row['value'], $row['value_label']);

        if (isset($subfield))
            return array($row['position_value'], $row['position_label']);

        if (isset($field))
            return array($row['subfield_value'], $row['subfield_label']);

        return array($row['field_value'], $row['field_label']);
    }

    /**
     * Postprocess maps in order to use internal transformations, like language map for 101 fields
     *
     * @param array $map
     * @param string $field
     * @param string|null $subfield
     * @param string|null $position
     * @param string|null $value
     */
    private function postProcessMap($map, $field, $subfield, $position, $value)
    {
        //field must be 101, subfield and position must be set, $value must be null
        if ($field != '101' || !isset($subfield) || !isset($position) || isset($value))
            return $map;

        return $this->getLangTransformation()->getCompleteMap();
    }

    /**
     * Return the language transformation. Depends on the global $sc... argh!
     * @return LocalizationTransformation
     */
    private function getLangTransformation()
    {
        global $sc;
        $langTransformation = $sc->get('transformation.languages');

        return $langTransformation;
    }

    /**
     * Correct labels in the case of a 101 field
     *
     * @param $labels
     * @param $field
     * @param $subfield
     * @param $position
     * @param $value
     * @return array
     */
    private function postProcessLabels($labels, $field, $subfield, $position, $value)
    {
        //field must be 101, other params must be set
        if ($field != '101' || !isset($subfield) || !isset($position) || !isset($value))
            return $labels;

        $labels = $this->valueToLabels($field, $subfield, $position);
        $transformation = $this->getLangTransformation();

        $labels['value_label'] = $transformation($value);
        $labels['value'] = $value;

        return $labels;
    }
}
