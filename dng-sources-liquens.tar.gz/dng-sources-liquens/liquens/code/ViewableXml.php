<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

/**
 * This class is a wrapper around an SimpleXmlElement Object, that makes the xml avaiable and
 * traversable by an .ss template
 */
class ViewableXml extends ViewableData implements IteratorAggregate, Countable, ArrayAccess
{
    /**
     * @var SimpleXMLElement
     */
    private $_xml;

    /**
     * @param SimpleXMLIterator|string $xml
     */
    public function __construct($xml)
    {
        if (is_string($xml))
            //I need to _xml to be a SimpleXmlIterator, to implement propery IteratorAggregate
            //interface
            $this->_xml = simplexml_load_string($xml, 'SimpleXMLIterator');
        elseif($xml instanceof SimpleXMLIterator)
            $this->_xml = $xml;
        else
            throw new Exception('First argument of Viewable::__construct()
                must be a string or a SimpleXmlIterator');
    }

    /**
     * @return SimpleXMLIterator
     */
    public function getSimpleXml()
    {
        return $this->_xml;
    }

    /**
     * If the underlying XML has a child node with the property
     * $property, returns a ViewableXml linked to that node,
     * otherwise it uses the parent::__get method.
     *
     * @param $property
     * @return ViewableXml
     */
    public function __get($property)
    {
        $node = $this->_xml->$property;

        if(!isset($node))
            return parent::_get($property);
        
        return new ViewableXml($node);
    }

    /**
     * @param $property
     * @param $value
     */
    public function __set($property, $value)
    {
        $this->_xml->$property = $value;
    }

    /**
     * @return int
     */
    public function count()
    {
        return count($this->_xml);
    }

    /**
     * Implementation of the IteratorAggregate Interface
     * @return ViewableXmlIterator
     */
    public function getIterator()
    {
        return new ViewableXmlIterator($this);
    }

    /**
     * @return string
     */
    public function __toString()
    {
        return (string) $this->_xml;
    }

    /**
     * ArrayAccess Interface
     *
     * @param string|int $index
     * @return bool
     */
    public function offsetExists($index)
    {
        return isset($this->_xml[$index]);
    }

    /**
     * ArrayAccess Interface
     *
     * @param string|int $index
     * @return ViewableXml
     */
    public function offsetGet($index)
    {
        return new ViewableXml($this->_xml[$index]);
    }

    /**
     * ArrayAccess Interface
     *
     * @param $index
     * @param $value
     */
    public function offsetSet($index, $value)
    {
        $this->_xml[$index] = $value;
    }

    /**
     * ArrayAccess Interface
     *
     * @param $index
     */
    public function offsetUnset($index)
    {
        unset($this->_xml[$index]);
    }

    /**
     * Returns the name of the root XML Node
     *
     * @return string
     */
    public function Name()
    {
        return $this->_xml->getName();
    }

    /**
     * Value displayed in ss templates
     *
     * @return string
     */
    public function forTemplate()
    {
        return (string) $this;
    }
}

/**
 * A wrapper of the SimpleXmlIterator
 */
class ViewableXmlIterator implements Iterator
{
    /**
     * @param SimpleXMLIterator $object
     */
    public function __construct($object)
    {
        $this->obj = $object;
    }

    /**
     * @return void
     */
    public function rewind()
    {
        $this->obj->getSimpleXml()->rewind();
    }

    /**
     * @return void
     */
    public function next()
    {
        $this->obj->getSimpleXml()->next();
    }

    /**
     * @return string|int
     */
    public function key()
    {
        return $this->obj->getSimpleXml()->key();
    }

    /**
     * @return ViewableXml
     */
    public function current()
    {
        $current = $this->obj->getSimpleXml()->current();

        if (is_string($current))
            return $current;
        else
            return new ViewableXml($current);
    }

    /**
     * @return bool
     */
    public function valid()
    {
        return $this->obj->getSimpleXml()->valid();
    }
}
