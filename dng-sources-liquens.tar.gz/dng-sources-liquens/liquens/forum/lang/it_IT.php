<?php

/**
 * Italian (Italy) language pack
 * @package modules: forum
 * @subpackage i18n
 */
i18n::include_locale_file('liquens/forum', 'en_US');

global $lang;

if(array_key_exists('it_IT', $lang) && is_array($lang['it_IT'])) {
	$lang['it_IT'] = array_merge($lang['en_US'], $lang['it_IT']);
} else {
	$lang['it_IT'] = $lang['en_US'];
}

$lang['it_IT']['Forum']['ADMINFEATURES'] = 'Impostazioni amministrative del forum';
$lang['it_IT']['Forum']['ACCESSATTACH'] = 'Possono gli utenti allegare file?';
$lang['it_IT']['Forum']['ACCESSPOST'] = 'Chi può postare sul forum?';
$lang['it_IT']['Forum']['ACCESSREAD'] = 'Chi può leggere il forum?';
$lang['it_IT']['Forum']['BBCODEHINT'] = 'Aiuto sulla formattazione';
$lang['it_IT']['Forum']['CREDENTIALS'] = 'Inserisci le tue credenziali per accedere al forum.';
$lang['it_IT']['Forum']['DEFAULTCATEGORY'] = 'Generale';
$lang['it_IT']['Forum']['EDITPOST'] = 'Modifica un post';
$lang['it_IT']['Forum']['FORUMCREATED'] = 'La pagina del Forum è stata creata';
$lang['it_IT']['Forum']['FORUMHOLDERCREATED'] = 'Creata la pagina ForumHolder';
$lang['it_IT']['Forum']['GROUPCREATED'] = 'E\' stato creato il gruppo per i membri del Forum';
$lang['it_IT']['Forum']['ISGLOBALSTICKY'] = 'E\' visibile in tutti i forum?';
$lang['it_IT']['Forum']['ISREADONLYTHREAD'] = 'E\' una discussione disponibile solo in lettura?';
$lang['it_IT']['Forum']['ISSTICKYTHREAD'] = 'E\' una discussione permanente?';
$lang['it_IT']['Forum']['LOGINAGAIN'] = 'Sei uscito dal forum. Se vuoi rientrare, inserisci nome utente e la password qui sotto.';
$lang['it_IT']['Forum']['LOGINALREADY'] = 'Spiacente, ma non puoi accedere a questo foum se non sei loggato. Se hai un\'altro account che può accederci, puoi autenticarti qui sotto.';
$lang['it_IT']['Forum']['LOGINDEFAULT'] = 'Inserisci il tuo indirizzo email e la password per visualizzare questo forum';
$lang['it_IT']['Forum']['LOGINTOEDIT'] = 'Specifica il tuo indirizzo email e la password per modificare questo post.';
$lang['it_IT']['Forum']['LOGINTOEDITLOGGEDIN'] = 'Spiacente, non puoi modificare questo post se non sei loggato. E\' necessario essere amministratori o l\'autore del post per poterlo modificare.';
$lang['it_IT']['Forum']['LOGINTOPOST'] = 'E\' necessario fare il login per poter postare sul forum. Puoi autenticarti qui sotto.';
$lang['it_IT']['Forum']['LOGINTOPOSTAGAIN'] = 'Sei uscito dal forum. Se vuoi rientrare, inserisci il nome utente e la password qui sotto.';
$lang['it_IT']['Forum']['LOGINTOPOSTLOGGEDIN'] = 'Mi dispiace, ma non è possibile postare in questo forum fino a quando non hai eseguito l\'accesso. Se hai un altro account che può accederci, puoi autenticarti qui sotto. Se sei registrato e non è ancora possibile postare, allora non hai i permessi per inserire nuovi messaggi.';
$lang['it_IT']['Forum']['NEWTOPIC'] = 'Inizia una nuova discussione';
$lang['it_IT']['Forum']['NO'] = 'No';
$lang['it_IT']['Forum']['POSTNOTFOUND'] = 'Il post corrente non è stato trovato nel database. Ritorna alla discussione che stavi modificando e prova a modificare il post di nuovo. Se il problema persiste, invia un\'email all\'amministratore.';
$lang['it_IT']['Forum']['POSTTOTOPIC'] = 'Post nella discussione \'%s\'';
$lang['it_IT']['Forum']['READANYONE'] = 'Qualsiasi';
$lang['it_IT']['Forum']['READLIST'] = 'Solo queste persone (scegli dalla lista)';
$lang['it_IT']['Forum']['READLOGGEDIN'] = 'Utenti loggati';
$lang['it_IT']['Forum']['READNOONE'] = 'Nessuno. Rendi il Forum di Sola Lettura';
$lang['it_IT']['Forum']['REFRECHTIME'] = 'Aggiorna ogni';
$lang['it_IT']['Forum']['REFRESHFORUM'] = 'Aggiorna questo forum';
$lang['it_IT']['Forum']['REMOVE'] = 'elimina';
$lang['it_IT']['Forum']['RSSFORUM'] = 'Post nel forum \'%s\'';
$lang['it_IT']['Forum']['RSSFORUMPOSTSTO'] = 'Post forum a \'%s\'';
$lang['it_IT']['Forum']['RSSFORUMS'] = 'Messaggi di tutti i forum';
$lang['it_IT']['Forum']['SAVE'] = 'Salva';
$lang['it_IT']['Forum']['SECONDS'] = 'secondi';
$lang['it_IT']['Forum']['SUBSCRIBETOPIC'] = 'Iscriviti a questa discussione (Riceverai un\'email di notifica quando viene inserita una nuova risposta)';
$lang['it_IT']['Forum']['TITLE'] = 'Discussioni Generali';
$lang['it_IT']['Forum']['WELCOMEFORUM'] = 'Benvenuto nel modulo Forum di SilverSTripe! Questa è la pagina Forum di default. Ora puoi aggiungere nuove discussioni.';
$lang['it_IT']['Forum']['WELCOMEFORUMHOLDER'] = 'Benvenuto nel modulo Forum di SilverSTripe! Questa è la pagina ForumHolder di default. Ora puoi aggiungere nuovi forum.';
$lang['it_IT']['Forum']['WRONGPERMISSION'] = 'Non hai i permessi per modificare questo post.';
$lang['it_IT']['Forum']['YES'] = 'Sì';
$lang['it_IT']['Forum']['VIEWFORMATTINGHELP'] = 'Visualizza l\'help della formattazione';
$lang['it_IT']['Forum']['HIDEFORMATTINGHELP'] = 'Nascondi l\'help della formattazione';
$lang['it_IT']['Forum']['SENDPOST'] = 'Invia';

$lang['it_IT']['ForumHolder_search.ss']['PREVLINK'] = 'Prec';
$lang['it_IT']['ForumHolder_search.ss']['NEXTLINK'] = 'Succ';

// forum .ss
$lang['it_IT']['Forum.ss'][''] = 'Vai alla discussione %s';
$lang['it_IT']['Forum.ss']['BY'] = 'da';
$lang['it_IT']['Forum.ss']['CLICKTOUSER'] = 'Clicca qui per vedere';
$lang['it_IT']['Forum.ss']['GOTOFIRSTUNREAD'] = 'Vai al primo post non letto nella discussione %s.';
$lang['it_IT']['Forum.ss']['LASTPOST'] = 'Ultimo Messaggio';
$lang['it_IT']['Forum.ss']['NEWTOPIC'] = 'Clicca qui per iniziare una nuova discussione';
$lang['it_IT']['Forum.ss']['NEWTOPICIMAGE'] = 'Inizia una nuova discussione';
$lang['it_IT']['Forum.ss']['NEWTOPICTEXT'] = 'clicca qui per iniziare una nuova discussione';
$lang['it_IT']['Forum.ss']['NOTOPICS'] = 'Non ci sono discussioni in questo forum, ';
$lang['it_IT']['Forum.ss']['POSTS'] = 'Messaggi';
$lang['it_IT']['Forum.ss']['PREVLNK'] = 'Pagina Precedente';
$lang['it_IT']['Forum.ss']['READONLYFORUM'] = 'Questo Forum è di sola lettura. Non puoi rispondere ai post o inserire nuove discussioni.';
$lang['it_IT']['Forum.ss']['TOPIC'] = 'Discussione';

// Forum Admin
$lang['it_IT']['ForumAdmin']['ARCHIVED'] = 'Discussioni Archiviate';
$lang['it_IT']['ForumAdmin']['AWAITING'] = 'Discussioni in Attesa';
$lang['it_IT']['ForumAdmin']['FORUM'] = 'Forum:';
$lang['it_IT']['ForumAdmin']['MODERATED'] = 'Discussioni Moderate';
$lang['it_IT']['ForumAdmin']['REJECTED'] = 'Discussioni Rifiutate';

// ForumAdmin_right.ss
$lang['it_IT']['ForumAdmin_right.ss']['EDITPAGE'] = 'Modifica Pagina';
$lang['it_IT']['ForumAdmin_right.ss']['WELCOME'] = 'Benvenuto a %s! Seleziona una delle voci sul riquadro a sinistra.';

// ForumFooter.ss
$lang['it_IT']['ForumFooter.ss']['CURRENTLYON'] = 'Utenti Online:';
$lang['it_IT']['ForumFooter.ss']['ISONLINE'] = 'è online';
$lang['it_IT']['ForumFooter.ss']['LATESTMEMBER'] = 'Benvenuto al nostro ultimo membro.';
$lang['it_IT']['ForumFooter.ss']['NOONLINE'] = 'Non c\'è nessuno online.';

// ForumHeader.ss
$lang['it_IT']['ForumHeader.ss']['BY'] = 'di';
$lang['it_IT']['ForumHeader.ss']['IN'] = 'in';
$lang['it_IT']['ForumHeader.ss']['JUMPTO'] = 'Vai a:';
$lang['it_IT']['ForumHeader.ss']['MEMBERS'] = 'membri';
$lang['it_IT']['ForumHeader.ss']['POSTS'] = 'Messaggi';
$lang['it_IT']['ForumHeader.ss']['SEARCH'] = 'Cerca:';
$lang['it_IT']['ForumHeader.ss']['SEARCHBUTTON'] = 'Cerca';
$lang['it_IT']['ForumHeader.ss']['SELECT'] = 'Seleziona';
$lang['it_IT']['ForumHeader.ss']['TOPICS'] = 'Discussioni';

// ForumHolder
$lang['it_IT']['ForumHolder']['SEARCHEDFOR'] = 'Hai cercato \'%s\'';
$lang['it_IT']['ForumHolder']['SEARCHRESULTS'] = 'Risultati della ricerca';
$lang['it_IT']['ForumHolder']['HOLDERABSTRACT'] = '<p>Se &egrave; la tua prima visita per partecipare attivamente al forum &egrave; necessario <a class=\"broken\" title=\"Clicca qui per registrarsi\" href=\"ForumMemberProfile/register\">registrarsi</a>.</p>';

$lang['it_IT']['ForumHolder']['HOLDERSUBTITLE'] = "Benvenuto nel nostro forum!";
$lang['it_IT']['ForumHolder']['PROFILESUBTITLE'] = "Modifica il tuo profilo";
$lang['it_IT']['ForumHolder']['FORUMSUBTITLE'] = "Inizia una nuova discussione";
$lang['it_IT']['ForumHolder']['PROFILEABSTRACT'] = "<p>Compila i campi qui sotto. Puoi scegliere se renderli pubblici spuntando la checkbox corrispondente.</p>";
$lang['it_IT']['ForumHolder']['FORUMASTRACT'] = "<p>Qui puoi cominciare una nuova discussione.</p>";
$lang['it_IT']['ForumHolder']['PROFILEMODIFY'] = "<p>Il tuo profile &egrave; stato modificato con successo.</p>";
$lang['it_IT']['ForumHolder']['PROFILEADD'] = "<p>Ti ringraziamo per la tua iscrizione al forum.</p>";
$lang['it_IT']['ForumHolder']['PPOSTTOALL'] = "Invia a tutti i forum";
$lang['it_IT']['ForumHolder.ss']['FORUM'] = 'Forum';
$lang['it_IT']['ForumHolder.ss']['LASTPOST'] = 'Ultimo Post';
$lang['it_IT']['ForumHolder.ss']['POSTS'] = 'Messaggi';
$lang['it_IT']['ForumHolder.ss']['THREADS'] = 'Discussioni';
$lang['it_IT']['ForumHolder_List.ss']['GOTOLATEST'] = 'Vai nell\'ultimo post in %s';
$lang['it_IT']['ForumHolder_List.ss']['GOTOTHISTOPIC'] = 'Vai nella discussione %s';
$lang['it_IT']['ForumHolder_search.ss'][''] = 'Vai alla discussione %s';
$lang['it_IT']['ForumHolder_search.ss']['BY'] = 'da';
$lang['it_IT']['ForumHolder_search.ss']['CLICKTOUSER'] = 'Clicca qui per vedere';
$lang['it_IT']['ForumHolder_search.ss']['CLICKTOUSER2'] = 'profilo';
$lang['it_IT']['ForumHolder_search.ss']['NORESULTS'] = 'Non ci sono risultati per questa/e parola/e';
$lang['it_IT']['ForumHolder_search.ss']['PAGE'] = 'Pagina:';
$lang['it_IT']['ForumHolder_search.ss']['POST'] = 'Messaggio';
$lang['it_IT']['ForumHolder_search.ss']['TOPIC'] = 'Discussione';

// ForumLogin.ss
$lang['it_IT']['ForumLogin.ss']['LOGGEDINAS'] = 'Sei loggato come';
$lang['it_IT']['ForumLogin.ss']['LOGIN'] = 'Login';
$lang['it_IT']['ForumLogin.ss']['LOGINEXPLICATION'] = 'Clicca qui per fare il login';
$lang['it_IT']['ForumLogin.ss']['LOGOUT'] = 'Scollegati';
$lang['it_IT']['ForumLogin.ss']['LOGOUTEXPLICATION'] = 'Clicca qui per uscire';
$lang['it_IT']['ForumLogin.ss']['LOSTPASS'] = 'Password dimenticata';
$lang['it_IT']['ForumLogin.ss']['LOSTPASSEXPLICATION'] = 'Clicca qui per recuperare la vostra password';
$lang['it_IT']['ForumLogin.ss']['OPENID'] = 'registrati con OpenID';
$lang['it_IT']['ForumLogin.ss']['OPENIDDESC1'] = 'OpenID è un sistema di identificazione per siti Internet che ti permette di accedere a molti siti web con un unico account. ';
$lang['it_IT']['ForumLogin.ss']['OPENIDDESC2'] = 'Con OpenID, il tuo ID diventa un URL (ad esempio http://<strong>username</strong>.myopenid.com/). È possibile ottenere un OpenID da <a href="http://www.myopenid.com">myopenid.com</a>.';
$lang['it_IT']['ForumLogin.ss']['OPENIDDESC3'] = 'Per ulteriori informazioni visita il <a href="http://openid.net">sito ufficiale OpenID.';
$lang['it_IT']['ForumLogin.ss']['OPENIDEXPLICATION'] = 'Clicca qui per registrarti con OpenID';
$lang['it_IT']['ForumLogin.ss']['PROFILE'] = 'Profilo';
$lang['it_IT']['ForumLogin.ss']['PROFILEEXPLICATION'] = 'Clicca qui per modificare questo profilo';
$lang['it_IT']['ForumLogin.ss']['REGEXPLICATION'] = 'Clicca qui per registrarti';
$lang['it_IT']['ForumLogin.ss']['REGISTER'] = 'Registrati';
$lang['it_IT']['ForumLogin.ss']['WHATOPENID'] = 'Cos\'è OpenID?';
$lang['it_IT']['ForumLogin.ss']['WHATOPENIDUPPER'] = 'Cos\'è OpenID?';

// ForumMemberProfile
$lang['it_IT']['ForumMemberProfile']['AUTHENTICATIONFAILED'] = 'L\'autenticazione con OpenID/i-name non è riuscita.';
$lang['it_IT']['ForumMemberProfile']['CANCELLEDVERIFICATION'] = 'La verifica è stata annullata. Riprova.';
$lang['it_IT']['ForumMemberProfile']['EMAILEXISTS'] = 'Spiacente, l\'indirizzo email è già in uso. Specificarne un\'altro.';
$lang['it_IT']['ForumMemberProfile']['ENTEROPENID'] = 'Inserisci il tuo OpenID per continuare la registrazione';
$lang['it_IT']['ForumMemberProfile']['FORUMREGTITLE'] = 'Registrazione al Forum';
$lang['it_IT']['ForumMemberProfile']['FORUMUSERPROFILE'] = 'Profilo Utente del Forum';
$lang['it_IT']['ForumMemberProfile']['FORUMUSERREGISTER'] = 'Registrazione Forum';
$lang['it_IT']['ForumMemberProfile']['NICKNAMEEXISTS'] = 'Spiacente, il nickname è già in uso. Specificarne un\'altro.';
$lang['it_IT']['ForumMemberProfile']['OPENIDEXISTS'] = 'Spiacente, questo OpenID è già registrato. Specificarne un\'altro o registrati senza OpenID';
$lang['it_IT']['ForumMemberProfile']['PASSNOTMATCH'] = 'Password non corrispondenti. Riprova.';
$lang['it_IT']['ForumMemberProfile']['REGISTER'] = 'Registrati';
$lang['it_IT']['ForumMemberProfile']['REGISTEROPENID'] = 'Registrati con OpenID';
$lang['it_IT']['ForumMemberProfile']['SAVECHANGES'] = 'Salva modifiche';
$lang['it_IT']['ForumMemberProfile']['UNEXPECTEDERROR'] = 'Si è verificato un errore inatteso. Riprova ancora o registrati senza OpenID';
$lang['it_IT']['ForumMemberProfile']['USERPROFILE'] = 'Profilo utente';
$lang['it_IT']['ForumMemberProfile']['WRONGPERMISSION'] = 'Non hai i permessi per modificare questo membro.';

// ForumMemberProfile_show.ss
$lang['it_IT']['ForumMemberProfile_show.ss']['AVATAR'] = 'Avatar';
$lang['it_IT']['ForumMemberProfile_show.ss']['COUNTRY'] = 'Paese';
$lang['it_IT']['ForumMemberProfile_show.ss']['EMAIL'] = 'Email';
$lang['it_IT']['ForumMemberProfile_show.ss']['FIRSTNAME'] = 'Nome';
$lang['it_IT']['ForumMemberProfile_show.ss']['FORUMRANK'] = 'Forum ranking';
$lang['it_IT']['ForumMemberProfile_show.ss']['LASTPOST'] = 'Ultimo messaggio: %s';
$lang['it_IT']['ForumMemberProfile_show.ss']['LATESTPOSTS'] = 'Ultimi Messaggi';
$lang['it_IT']['ForumMemberProfile_show.ss']['NICKNAME'] = 'Nickname';
$lang['it_IT']['ForumMemberProfile_show.ss']['NORANK'] = 'No ranking';
$lang['it_IT']['ForumMemberProfile_show.ss']['OCCUPATION'] = 'Occupazione';
$lang['it_IT']['ForumMemberProfile_show.ss']['POSTNO'] = 'Numero di messaggi';
$lang['it_IT']['ForumMemberProfile_show.ss']['PROFILE'] = 'Profilo';
$lang['it_IT']['ForumMemberProfile_show.ss']['SURNAME'] = 'Cognome';
$lang['it_IT']['ForumMemberProfile_show.ss']['USERSAVATAR'] = 'avatar';

// ForumMember_ForgotNicknameEmail.ss
$lang['it_IT']['ForumMember_ForgotNicknameEmail.ss']['HI'] = 'Ciao,';
$lang['it_IT']['ForumMember_ForgotNicknameEmail.ss']['MESSAGE'] = 'Questo è il tuo nome utente per <a href="home/">%s</a>';
$lang['it_IT']['ForumMember_ForgotNicknameEmail.ss']['USERNAME'] = 'Nome utente:';

// ForumMember_TopicNotification.ss
$lang['it_IT']['ForumMember_TopicNotification.ss']['HI'] = 'Salve %s,';
$lang['it_IT']['ForumMember_TopicNotification.ss']['NEWPOSTMESSAGE'] = 'E\' stato inserito un nuovo post alla discussione a cui ti sei iscritto';
$lang['it_IT']['ForumMember_TopicNotification.ss']['NOTIFICATIONMESSAGE'] = 'Non riceverai ulteriori comunicazioni fino a quando non visiterai il forum nuovamente.';
$lang['it_IT']['ForumMember_TopicNotification.ss']['REPLYLINK'] = 'Vai alla discussione';
$lang['it_IT']['ForumMember_TopicNotification.ss']['UNSUBSCRIBETEXT'] = 'Disiscriviti dalla discussione';
$lang['it_IT']['ForumMember_TopicNotification.ss']['THANKS'] = 'Grazie,<br/>il Team del Forum';
$lang['it_IT']['ForumMember_TopicNotification.ss']['NOTENOREPLY'] = 'ATTENZIONE: Questa è una mail automatica, qualsiasi risposta non verrà letta.';

// ForumRole
$lang['it_IT']['ForumRole']['ADMIN'] = 'Amministratore';
$lang['it_IT']['ForumRole']['ANONYMOUS'] = 'Utente Anonimo';
$lang['it_IT']['ForumRole']['AVATAR'] = 'Carica avatar';
$lang['it_IT']['ForumRole']['COMMEMBER'] = 'Membro della community';
$lang['it_IT']['ForumRole']['CONFIRMPASS'] = 'Conferma Password';
$lang['it_IT']['ForumRole']['COUNTRY'] = 'Paese';
$lang['it_IT']['ForumRole']['EMAIL'] = 'Email';
$lang['it_IT']['ForumRole']['FIRSTNAME'] = 'Nome';
$lang['it_IT']['ForumRole']['MOD'] = 'Moderatore';
$lang['it_IT']['ForumRole']['NICKNAME'] = 'Nickname';
$lang['it_IT']['ForumRole']['OCCUPATION'] = 'Occupazione';
$lang['it_IT']['ForumRole']['OPENIDINAME'] = 'OpenID/i-name';
$lang['it_IT']['ForumRole']['PASSOPTMESSAGE'] = 'Dal momento che hai fornito un OpenID, rispettivamente i-name, la password è facoltativa. Se ne inserisci uno, sarai in grado di accedere anche con il tuo indirizzo e-mail.';
$lang['it_IT']['ForumRole']['PASSWORD'] = 'Password';
$lang['it_IT']['ForumRole']['PERSONAL'] = 'Dettagli Personali';
$lang['it_IT']['ForumRole']['RATING'] = 'User rating';
$lang['it_IT']['ForumRole']['SURNAME'] = 'Cognome';
$lang['it_IT']['ForumRole']['TRANSFERSUCCEEDED'] = 'Il trasferimento dati è avvenuto con successo. In ogni caso, per completare, devi eliminare la tabella ForumMember . Per farlo, esegui la query "DROP TABLE \'ForumMember\'".';
$lang['it_IT']['ForumRole']['USERDETAILS'] = 'Dettagli Utente';

// Forum_editpost.ss
$lang['it_IT']['Forum']['AVAILABLEBB'] = 'Tags BB Code disponibili';
$lang['it_IT']['Forum_editpost.ss']['AVAILABLEBB'] = 'Tags BB Code disponibili';
$lang['it_IT']['Forum_editpost.ss']['EXAMPLE'] = 'Esempio';
$lang['it_IT']['Forum_editpost.ss']['NOTLOGGEDINPOST'] = 'Se vuoi postare, devi prima <a href="Security/login" title="log in">accedere</a> o <a href="ForumMemberProfile/register" title="register">registrarti</a>.';

// Forum_reply.ss
$lang['it_IT']['Forum_reply.ss']['AVAILABLEBB'] = 'Tags BB Code disponibili';
$lang['it_IT']['Forum_reply.ss']['EXAMPLE'] = 'Esempio';

// Forum_show.ss
$lang['it_IT']['Forum_show.ss']['AUTHOR'] = 'Autore';
$lang['it_IT']['Forum_show.ss']['CLICKGOTOEND'] = 'Clicca qui per andare alla fine di questo post';
$lang['it_IT']['Forum_show.ss']['CLICKGOTOTOP'] = 'Clicca qui per andare all\'inizio di questo post';
$lang['it_IT']['Forum_show.ss']['CLICKREPLY'] = 'Clicca per Rispondere';
$lang['it_IT']['Forum_show.ss']['CLICKSUBSCRIBE'] = 'Clicca qui per iscriverti a questa discussione';
$lang['it_IT']['Forum_show.ss']['CLICKUNSUBSCRIBE'] = 'Clicca qui per cancellare l\'iscrizione a questa discussione';
$lang['it_IT']['Forum_show.ss']['GOTOEND'] = 'Vai alla Fine';
$lang['it_IT']['Forum_show.ss']['GOTOTOP'] = 'Vai all\'inizio';
$lang['it_IT']['Forum_show.ss']['NEXTLINK'] = 'Succ';
$lang['it_IT']['Forum_show.ss']['NEXTTITLE'] = 'Mostra la pagina successiva';
$lang['it_IT']['Forum_show.ss']['PAGE'] = 'Pagina:';
$lang['it_IT']['Forum_show.ss']['PREVLINK'] = 'Prec';
$lang['it_IT']['Forum_show.ss']['PREVTITLE'] = 'Mostra la pagina precedente';
$lang['it_IT']['Forum_show.ss']['REPLY'] = 'Rispondi';
$lang['it_IT']['Forum_show.ss']['SUBSCRIBE'] = 'Iscriviti';
$lang['it_IT']['Forum_show.ss']['TOPIC'] = 'Messaggio:';
$lang['it_IT']['Forum_show.ss']['UNSUBSCRIBE'] = 'Annulla iscrizione';
$lang['it_IT']['Forum_show.ss']['VIEWS'] = 'Visite';

// Forum_starttopic.ss
$lang['it_IT']['Forum_starttopic.ss']['AVAILABLEBB'] = 'Tags BB Code Disponibili';
$lang['it_IT']['Forum_starttopic.ss']['EXAMPLE'] = 'Esempio';

// Post
$lang['it_IT']['Post']['ACTIVEPOSTS'] = 'Post Attivi';
$lang['it_IT']['Post']['ARCHIVE'] = 'Archivio';
$lang['it_IT']['Post']['ARCHIVED'] = 'Archiviato';
$lang['it_IT']['Post']['AUTHOR'] = 'Autore';
$lang['it_IT']['Post']['AWAITING'] = 'In attesa';
$lang['it_IT']['Post']['AWAITINGPOSTS'] = 'Post in Attesa';
$lang['it_IT']['Post']['CONTENT'] = 'Contenuto';
$lang['it_IT']['Post']['CREATED'] = 'Creato';
$lang['it_IT']['Post']['DELETE'] = 'elimina';
$lang['it_IT']['Post']['EDIT'] = 'modifica';
$lang['it_IT']['Post']['LASTEDIT'] = 'Ultima Modifica';
$lang['it_IT']['Post']['MAIN'] = 'Principale';
$lang['it_IT']['Post']['MODERATED'] = 'Approvato';
$lang['it_IT']['Post']['POSTEDBY'] = 'Inserito Da %s';
$lang['it_IT']['Post']['POSTEDTO'] = 'Postato in: %s';
$lang['it_IT']['Post']['POSTREPLIEDTO'] = 'Post in Risposta a %s';
$lang['it_IT']['Post']['REJECTED'] = 'Rifiutato';
$lang['it_IT']['Post']['REJECTEDPOSTS'] = 'Messaggi Rifiutati';
$lang['it_IT']['Post']['RESPONSE'] = 'R: %s';
$lang['it_IT']['Post']['SAVE'] = 'Salva';
$lang['it_IT']['Post']['STATUS'] = 'Status';
$lang['it_IT']['Post']['TITLE'] = 'Titolo';
$lang['it_IT']['Post']['TOPICCREATED'] = 'Discussioni Create';
$lang['it_IT']['Post']['TOPICDETAILS'] = 'Dettagli Discussione';
$lang['it_IT']['Post']['TOPICINTERNALID'] = 'ID della Discussione';
$lang['it_IT']['Post']['TOPICLASTEDIT'] = 'Ultima Discussione Modificata';
$lang['it_IT']['Post']['TITLE'] = 'Titolo';
$lang['it_IT']['Post']['CONTENT'] = 'Contenuto';
$lang['it_IT']['Post']['MARKASSPAM'] = 'Contrassegna come Spam';
$lang['it_IT']['Post']['REPLYLINK'] = 'Posta la risposta';
$lang['it_IT']['Post']['SHOWLINK'] = 'Mostra l\'argomento';
$lang['it_IT']['Post']['TITLE'] = 'Titolo';
$lang['it_IT']['Post']['CONTENT'] = 'Contenuto';



// SinglePost.ss
$lang['it_IT']['SinglePost.ss']['ATTACHED'] = 'File Allegati';
$lang['it_IT']['SinglePost.ss']['GOTOPROFILE'] = 'Vai a questo Profilo Utente';
$lang['it_IT']['SinglePost.ss']['LASTEDITED'] = 'Ultima modifica:';
$lang['it_IT']['SinglePost.ss']['CLICKREPLY'] = 'Clicca per rispondere';
$lang['it_IT']['SinglePost.ss']['LINKTOPOST'] = 'Collegamento a questo post';
$lang['it_IT']['SinglePost.ss']['REPLY'] = 'Rispondi';

$lang['it_IT']['TopicListing.ss']['BY'] = 'Da';
$lang['it_IT']['TopicListing.ss']['CLICKTOUSER'] = 'Clicca per vedere';
$lang['it_IT']['TopicListing.ss']['GOTOFIRSTUNREAD'] = 'Vai al primo post non ancora letto nella discussione %s .';

// ForumLastPost
$lang['it_IT']['ForumLastPost']['NOPOSTS'] = 'Non vi sono posts al momento.';
$lang['it_IT']['ForumLastPost']['NUMBERTOSHOW'] = 'Numero da visualizzare';
$lang['it_IT']['ForumLastPost']['TOPICID'] = '(opzionale) ID Argomento';
$lang['it_IT']['ForumLastPost']['AUTHORID'] = '(opzionale) ID Autore';
$lang['it_IT']['ForumLastPost']['DISPLAYPOSTTITLES'] = 'Visualizzare il titolo del post?';
$lang['it_IT']['ForumLastPost']['MANIFESTATIONID'] = '(opzionale) ID della notizia';