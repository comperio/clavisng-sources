<?php

/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class LeonardoWidget extends Widget implements ExternalSearchWidget {

    private $cachedData;
    static $cmsTitle = "Leonardo Widget";
    static $description = "Retrieve search results data from Leonardo";
    static $db = array(
        'Title' => 'VarChar(255)'
    );
    static $defaults = array(
        'Title' => 'Leonardo',
    );

    /**
     * Title displayed in the cms
     *
     * @return mixed|string
     */
    public function CMSTitle() {
        return _t('LeonardoWidget.CMS_TITLE') ? : parent::CMSTitle();
    }

    /**
     * @return mixed
     */
    public function Description() {
        return _t('LeonardoWidget.CMS_DESC') ? : parent::Description();
    }

    /**
     * Title displayed in the frontend
     *
     * @return mixed|string
     */
    public function Title() {
        return $this->Title;
    }

    /**
     * Return the results fetched from the service
     *
     * @return array
     */
    public function Data() {
        if (!isset($this->cachedData))
            $this->cachedData = $this->parseResponse($this->getResponse($this->getSearchString()));

        return $this->cachedData;
    }

    /**
     * The fields used to set up the widget
     *
     * @return FieldSet
     */
    public function getCMSFields($params = NULL) {
        $fields = parent::getCMSFields();

        $fields->push(new TextField('Title', 'Titolo da visualizzare sopra il widget'));

        return $fields;
    }

    /**
     * Returns the search string to pass to MediaLibrary Service
     * @return string
     */
    private function getSearchString() {
        return isset($_GET['q']) ? $_GET['q'] : '';
    }

    /**
     * 
     * @global type $sc
     * @param type $searchString
     * @return type
     */
    private function getResponse($searchString) {
        global $sc;
        $url = $sc->getParameter('leonardo.connector.widgeturl') . urlencode(htmlspecialchars($this->getSearchString()));
        libxml_use_internal_errors(true);
        $dom = new DomDocument;
        $dom->loadHTMLFile($url);
        $xpath = new DomXPath($dom);
        $nodes = $xpath->query("//logicrecord");
        return $nodes;
    }

    /**
     * Transform the response to an array
     *
     * @param $response
     * @return DataObjecty
     */
    private function parseResponse($response) {
        global $sc;

        $array = array();
        foreach ($response as $node) {
            $array[] = $node->C14N();
        }

        $data = new DataObject();
        $data->Active = false;
        $data->Results = new DataObjectSet();
        $data->Email = false;

        foreach ($array as $n) {
            if (strpos($n, 'href') !== false) {
                if (strpos($n, $sc->getParameter('leonardo.connector.exclude')) !== false) {
                    continue;
                } else {
                    $n = str_replace("<logicrecord>", "", $n);
                    $n = str_replace("</logicrecord>", "", $n);
                    $n = str_replace("<li></li>", "", $n);
                    $n = str_replace("&#xD;", "", $n);
                    $n = str_replace("<strong>", "", $n);
                    $n = str_replace("</strong>", "", $n);
                    $n = str_replace("<hr>", "", $n);
                    $n = str_replace("javascript:top.AutoWindowOpen('", "", $n);
                    $n = str_replace("','Doc');", "", $n);
                    $n = str_replace("href=", 'target="_blank" href=', $n);
                    $data->Results->push(new ArrayData(array("html" => (string) $n)));
                    $data->Active = true;
                    $data->Email = $this->userEmail();
                }
            }
        }
        return $data;
    }

    /**
     * 
     * @return boolean
     */
    private function userEmail() {
        if (!Member::currentUser()) {
            return false;
        } else {
            $member = Member::currentUser();
            $userDataDng = $member->getExternalData();
            $connector = Page::getContainer()->get('liquens.connector');
            $userDataClavis = $connector->getUserData($userDataDng['username'], 'opac_username', true);
            if (!isset($userDataClavis['email']) || $userDataClavis['email'] == '') {
                return false;
            }
            return true;
        }
    }
}

class LeonardoWidget_Controller extends Widget_Controller {

    public function WidgetHolder() {
        return $this->renderWith(array('LeonardoWidget'));
    }

}
