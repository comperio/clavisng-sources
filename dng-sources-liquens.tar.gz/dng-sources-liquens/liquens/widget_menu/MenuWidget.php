<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

/**
 * This widget displays a list of pages according to customizable criteria
 */
class MenuWidget extends Widget
{
    static $cmsTitle = "Menu Widget";

    static $description = "Display an existing menu";

    static $db = array(
        'Title' => 'VarChar(255)',
        'Limit' => 'DBInt',
    );

    static $has_one = array(
        'Menu' => 'MenuItem'
    );

    static $defaults = array(
        'Title' => 'Menu',
        'Limit' => 0,
    );

    public function Description()
    {
        return _t('MenuWidget.CMS_DESC');
    }

    public function CMSTitle()
    {
        return _t('MenuWidget.CMS_TITLE');
    }

    /**
     * Title displayed in the frontend
     *
     * @return mixed|string
     */
    public function Title()
    {
        return $this->Title;
    }

    /**
     * @return FieldSet|void
     */
    public function getCMSFields($params = NULL)
    {
        $fields = parent::getCMSFields();

        $fields->push(new TextField('Title', _t('Liquens.TITLE')));
        $fields->push(new NumericField('Limit', _t('MenuWidget.LIMIT')));

        $defaultLocale = Translatable::default_locale();
        $menus = DataObject::get('MenuItem', "ParentID = 0 AND Locale = '" . Convert::raw2sql($defaultLocale) . "'") ?: new DataObjectSet;

        $fields->push(new DropdownField('MenuID', _t('MenuWidget.MENU', 'Menu'), $menus->toDropDownMap('ID', 'Name')));

        return $fields;
    }

    /**
     * @return mixed
     */
    public function getMenuItems()
    {
        return $this->Menu()->getMenuSubitems($this->Limit ?: null);
    }
}

class MenuWidget_Controller extends DngWidget_Controller
{

}
