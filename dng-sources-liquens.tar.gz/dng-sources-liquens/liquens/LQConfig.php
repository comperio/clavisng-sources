<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

/**
 * This class is only an adapter for the container parameters bag.
 */

class LQConfig
{
    /**
     * Get a parameter from the container. Supports nested levels.
     *
     * @static
     *
     * @return mixed|null
     */
    public static function get()
    {
        global $sc;

        $keys = func_get_args();

        $firstKey = array_shift($keys);

        if (! $sc->hasParameter('lq.' . $firstKey))
            return null;

        $param = $sc->getParameter('lq.' . $firstKey);
        if (!is_array($param) || !$keys){
            return $param;
        } else {
            return static::getNestedArrayValue($param, $keys);
        }
    }

    /**
     * @static
     * @param $array
     * @param $keys
     * @return null
     */
    private static function getNestedArrayValue($array, $keys)
    {
        $firstKey = array_shift($keys);

        if (!isset($array[$firstKey]))
            return null;

        if (!$keys)
            return $array[$firstKey];

        return static::getNestedArrayValue($array[$firstKey], $keys);
    }
}