<?php
/**
 * This file is part of dng
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

class DevToolbarDropdown extends DevToolbarElement
{
    private $items = array();
    private $active = null;

    /**
     * @param string $name
     * @param array $items
     * @param null $active
     */
    public function __construct($name, array $items, $active = null)
    {
        parent::__construct($name);
        $this->items = $items;
        $this->active = $active;
    }

    /**
     * @return DataObjectSet
     */
    public function Items()
    {
        $set = new DataObjectSet();

        foreach ($this->items as $label => $value) {
            $set->push(new ArrayData(array(
                'Value' => $value,
                'Label' => $label,
                'Active' => $value == $this->active
            )));
        }

        return $set;
    }

    /**
     * {@inheritdoc}
     */
    public function render()
    {
        return $this->renderWith('DevToolbarDropdown');
    }
}