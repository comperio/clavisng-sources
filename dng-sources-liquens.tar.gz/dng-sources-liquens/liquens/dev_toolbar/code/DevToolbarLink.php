<?php
/**
 * This file is part of dng
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

abstract class DevToolbarLink extends DevToolbarElement
{
    /**
     * Returns the text of the button
     *
     * @abstract
     * @return string
     */
    abstract public function getText();

    /**
     * Returns the url of the button
     *
     * @abstract
     * @return mixed
     */
    abstract public function getUrl();

    /**
     * {@inheritdoc}
     */
    public function render()
    {
        return $this->renderWith('DevToolbarLink');
    }
} 