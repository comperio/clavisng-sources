<?php
/**
 * This file is part of dng
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

class DevToolbarThemeDropdown extends DevToolbarDropdown
{
    /**
     * @param string $name
     * @param string $active
     */
    public function __construct($name, $active)
    {
        $flushed = HTTP::setGetVar('flush', 'all', null, '&');
        foreach (array('default' => 'default') + ManifestBuilder::get_themes() as $theme) {
            $items[$theme] = HTTP::setGetVar('set-theme', $theme, $flushed, '&');
        }

        $active = HTTP::setGetVar('set-theme', $active, $flushed, '&');

        parent::__construct($name, $items, $active);
    }
} 