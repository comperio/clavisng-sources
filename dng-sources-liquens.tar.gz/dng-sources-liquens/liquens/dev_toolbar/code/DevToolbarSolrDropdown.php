<?php
/**
 * This file is part of dng
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

class DevToolbarSolrDropdown extends DevToolbarDropdown
{
    /**
     * @param string $name
     * @param array $items
     * @param null $active
     */
    public function __construct($name, array $items, $active = null)
    {
        foreach ($items as &$value)
            $value = HTTP::setGetVar('set-solr', $value, null, '&');

        $active = HTTP::setGetVar('set-solr', $active, null, '&');

        parent::__construct($name, $items, $active);
    }
} 