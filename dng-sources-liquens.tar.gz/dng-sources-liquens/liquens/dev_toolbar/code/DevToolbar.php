<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
class DevToolbar extends ViewableData
{
    /**
     * @var array An hash where keys are button groups names and values are array of buttons
     */
    private $buttons;

    /**
     * Render the toolbar using the right template
     *
     * @return string
     */
    public function forTemplate()
    {
        return $this->renderWith('DevToolbar');
    }

    /**
     * Add a button to the toolbar
     *
     * @param DevToolbarElement $button
     *
     * @return DevToolbar The current instance
     */
    public function addButton(DevToolbarElement $button, $group = 'general')
    {
        $this->buttons[$group][] = $button;

        return $this;
    }

    /**
     * Get Buttons
     *
     * @return array The array of DevToolbarButtons objects
     */
    public function getAllowedButtons()
    {
        $buttonsSet = new DataObjectSet();

        foreach ($this->buttons as $groupName => $buttonsGroup) {
            if ($this->hasUserPermissionOnGroup($groupName)) {
                foreach ($buttonsGroup as $button) {
                    if ($button->isEnabled())
                        $buttonsSet->push($button);
                }
            }
        }

        return $buttonsSet;
    }

    /**
     * @param $groupName
     * @return bool
     */
    private function hasUserPermissionOnGroup($groupName)
    {
        return Permission::check('DEVTOOLBAR_ALL') || Permission::check('DEVTOOLBAR_GRP_' . strtoupper($groupName));
    }
}
