<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

/**
 * This button reload the page adding a query parameter to the get url
 */
class QueryParamDevToolbarLink extends DevToolbarLink
{
    private $text;

    private $parameters = array();

    /**
     * @param string $name An identifier for the button
     * @param string $text The text shown in the button
     * @param array $parameters The name of the query parameter
     */
    public function __construct($name, $text, $parameters)
    {
        $this->text = (string) $text;
        $this->parameters = (array) $parameters;

        parent::__construct($name);
    }

    /**
     * Returns the url of the button
     *
     * @return mixed
     */
    public function getUrl()
    {
        $newUrl = null;

        foreach ($this->parameters as $name => $value) {
            $newUrl = HTTP::setGetVar($name, $value, $newUrl, '&');
        }

        return $newUrl;
    }

    /**
     * Returns the text of the button
     *
     * @return string
     */
    public function getText()
    {
        return $this->text;
    }

}
