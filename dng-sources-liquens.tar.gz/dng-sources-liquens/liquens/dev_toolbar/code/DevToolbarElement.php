<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

/**
 * Abstract class for a generic button of the Dev Toolbar
 */
abstract class DevToolbarElement extends ViewableData
{
    /**
     * @var string An identifier for the button
     */
    private $name;
    private $enabled = true;

    /**
     * @param string $name An identifier for the button
     */
    public function __construct($name)
    {
        $this->name = $name;
    }

    /**
     * @return bool
     */
    public function isEnabled()
    {
        return $this->enabled;
    }

    /**
     * Set the enable flag
     *
     * @param $enabled
     * @return $this
     */
    public function setEnabled($enabled)
    {
        $this->enabled = $enabled;

        return $this;
    }

    /**
     * Returns the name of the button
     *
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Returns the button renderized
     *
     * @return string
     */
    abstract function render();

    /**
     * An alias of $this::render
     *
     * @return string
     */
    public function forTemplate()
    {
        return $this->render();
    }
}
