<?php
/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

/**
 * A static button, where both the url and the name are static
 */
class StaticUrlToolbarLink extends DevToolbarLink
{
    private $url;
    private $text;

    /**
     * @param string $name
     * @param string $text
     * @param string $url
     */
    public function __construct($name, $text, $url)
    {
        parent::__construct($name);

        $this->text = $text;
        $this->url = $url;
    }
    /**
     * Returns the url of the button
     *
     * @return string
     */
    public function getUrl()
    {
        return $this->url;
    }

    /**
     * Returns the text of the button
     *
     * @return string
     */
    public function getText()
    {
        return $this->text;
    }

}
