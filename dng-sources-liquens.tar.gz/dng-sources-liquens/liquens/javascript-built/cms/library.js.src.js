/**
 * Created with JetBrains PhpStorm.
 * User: Nicolò Martini
 * Date: 21/08/12
 * Time: 12:20
 * To change this template use File | Settings | File Templates.
 */

(function ($){
    $('#right input:submit[name=action_fetchFromExternalSource]').unbind('click').live('click', function(){
        if (!confirm("L'operazione sovrascriverà i dati correnti della biblioteca. Continuare?")){
            return false;
        }

        var form = $('#right form');
        var formAction = form.attr('action') + '?' + $(this).fieldSerialize();
        if(typeof tinyMCE != 'undefined') tinyMCE.triggerSave();
        $.ajax({
            url : formAction,
            data : form.formToArray(),
            dataType : "json",
            success : function(json) {
                tinymce_removeAll();

                $('#right #ModelAdminPanel').html(json.html);
                if($('#right #ModelAdminPanel form').hasClass('validationerror')) {
                    statusMessage(ss.i18n._t('ModelAdmin.VALIDATIONERROR', 'Validation Error'), 'bad');
                } else {
                    statusMessage(json.message, 'good');
                }

                Behaviour.apply();
                if(window.onresize) window.onresize();
            }
        });
        return false;
    });

    $(document).ready(function(){
        if ($('#Form_EditForm fieldset').length === 0)
            $('#Form_SearchForm_LibraryDataObject').submit();
    });
})(jQuery);