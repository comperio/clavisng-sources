/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

(function($) {
    $(document).ready(function() {
      //Taming the BEast! (http://www.leftandmain.com/uncategorized/2011/02/25/taming-the-beast-remodeling-modeladmin/)
      var doList = function() {
        $('#Form_SearchForm_CalendarEvent').submit();
        return false;
      };

      $('button[name=action_clearsearch]').click(doList);
      $('#list_view').live("click",doList);
      $('select#newEventLibraryId').live('change', function(){
        if (parseInt($(this).val(), 10) > 0) {
            $('#Form_CreateForm_CalendarEvent_action_add').removeAttr('disabled');
        } else {
            $('#Form_CreateForm_CalendarEvent_action_add').attr('disabled', 'disabled');
        }
      });

        doList();


        $('#right input:submit').unbind('click').live('click', function(){
        	var form = $('#right form');
        	var formAction = form.attr('action') + '?' + $(this).fieldSerialize();
        	if(typeof tinyMCE != 'undefined') tinyMCE.triggerSave();
        	$.ajax({
        		url : formAction,
        		data : form.formToArray(),
        		dataType : "json",
        		success : function(json) {
        			tinymce_removeAll();

        			$('#right #ModelAdminPanel').html(json.html);
        			if($('#right #ModelAdminPanel form').hasClass('validationerror')) {
        				statusMessage(ss.i18n._t('ModelAdmin.VALIDATIONERROR', 'Validation Error'), 'bad');
        			} else {
        				statusMessage(json.message, 'good');
        			}

        			Behaviour.apply();
        			if(window.onresize) window.onresize();
        		}
        	});
        	return false;
        });
    });
})(jQuery);
