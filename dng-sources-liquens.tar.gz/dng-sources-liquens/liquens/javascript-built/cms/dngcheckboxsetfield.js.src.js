/**
 * Created with JetBrains PhpStorm.
 * User: Nicolò Martini
 * Date: 30/08/12
 * Time: 12:32
 * To change this template use File | Settings | File Templates.
 */

(function($){
    var buttonsHandlers = {};

    $('.dngcheckboxset .btnset a.btn_link').live('click', function(event){
        var btnName = $(this).attr('dng_btn_name');
        var checkSet = $(this).closest('.dngcheckboxset');

        if (typeof buttonsHandlers[btnName] != 'undefined') {
            buttonsHandlers[btnName]($(this), checkSet);
        }

        event.preventDefault();
    });

    buttonsHandlers.selectAll = function(linkButton, checkboxSet) {
        checkboxSet.find('input[type=checkbox]').attr('checked', 'checked');
    };

    buttonsHandlers.deselectAll = function(linkButton, checkboxSet) {
        checkboxSet.find('input[type=checkbox]').removeAttr('checked');
    };

    buttonsHandlers.invert= function(linkButton, checkboxSet) {
        checkboxSet.find('input[type=checkbox]').each(function(){
            var checkbox = $(this);
            if (checkbox.attr('checked')) {
                checkbox.removeAttr('checked');
            } else {
                checkbox.attr('checked', 'checked');
            }
        });
    };
})(jQuery);