/**
 * Created with JetBrains PhpStorm.
 * User: Nicolò Martini
 * Date: 21/08/12
 * Time: 12:20
 * To change this template use File | Settings | File Templates.
 */

(function ($) {

    /**
     * Get a an index for the new voice different from existing one
     *
     * @returns {number}
     */
    function getNewIndex(parent) {
        parent = $(parent) || $('body');
        var max = 0;

        //Find first-level menuitems
        parent.find('.menuitem').not(parent.find('.menuitem .menuitem')).each(function() {
            //id is in the form menuvoice-{index}[-{subindex}]
            var index = parseInt($(this).data('index'));
            if (index > max)
                max = index;
        });

        return max + 1;
    }

    /**
     * Compute a default new position value
     *
     * @returns {number}
     */
    function getNewPosition(parent) {
        parent = $(parent) || $('body');
        var max = 0;
        parent
            .find('.menuitem [name*="\\[Position\\]"]')
            .not(parent.find('.menuitem .menuitem[name*="\\[Position\\]"]'))
            .each(function() {

            var index = parseInt($(this).val());
            if (index > max)
                max = index;
        });

        return max + 1;
    }

    /**
     * Given an element inside a .menuitem div, retrieve the id of that menu item
     * @param element
     */
    function getItemId(element)
    {
        return $(element).closest('.menuitem').find('.menuitem-id').length
            ? parseInt($(element).closest('.menuitem').find('.menuitem-id').val())
            : 0
        ;
    }

    function removeGroupIfEmpty(menuitem)
    {
        if (menuitem.find('.menuitem').length == 0) {
            menuitem.find('.isgroup-checkbox').removeAttr('checked').trigger('change');
        }
    }

    $(document).ready(function() {
        if ($('#Form_EditForm fieldset').length === 0)
            $('#Form_SearchForm_MenuItem').submit();

        $('body').delegate('.add-menuitem', 'click', function(event) {
            event.preventDefault();
            var wrapper = $(this).closest('.subitems-wrapper');

            var subitemsContainer = wrapper.find('.subitems').not(wrapper.find('.subitems .subitems'));
            var parentContext = wrapper.closest('.menuitem').data('context') || '';

            $.get('admin/menus/MenuItem/newmenuitem',
                {
                    parentContext: parentContext,
                    index: getNewIndex(subitemsContainer),
                    position: getNewPosition(subitemsContainer)
                },
                function(response) {
                    var newitem = $(response);
                    subitemsContainer.append(newitem);
                }
            );
        });

        $('body').delegate('.delete-menuitem', 'click', function(event) {
            event.preventDefault();
            var confirmed = confirm(ss.i18n._t('ModelAdmin.REALLYDELETE', 'Really delete?'));
            if(!confirmed) {
                return false;
            }
            var menuItemId = getItemId(this);
            var parent = $(event.target).closest('.menuitem').parents('.menuitem').first();

            if (menuItemId > 0) {
                $.post('admin/menus/MenuItem/deletemenuitem',
                    {id: menuItemId},
                    function (success) {
                        if (success) {
                            $(event.target).closest('.menuitem').remove();
                            statusMessage(ss.i18n._t('ModelAdmin.DELETED', 'Successfully deleted'));

                            removeGroupIfEmpty(parent);
                        }
                    }
                );
            } else {
                $(this).closest('.menuitem').remove();
                removeGroupIfEmpty(parent);
            }
        });

        $('body').delegate('.isgroup-checkbox', 'change', function(event) {
            var parent = $(this).closest('.menuitem');
            if ($(this).is(':checked')) {
                parent.find('.add-menuitem').not(parent.find('.menuitem .add-menuitem')).trigger('click');
                parent.addClass('menuitemgroup').addClass('menuitemexpanded');
            } else {
                var confirmed = (parent.find('.menuitem').length == 0) ||
                    confirm(ss.i18n._t('MenuAdmin.DELETESUBVOICES', 'Verranno cancellate tutte le voci di sottomenu, continuare?'));
                if (confirmed) {
                    var menuItemId = getItemId(this);
                    $.post('admin/menus/MenuItem/deletemenusubitems',
                        {id: menuItemId},
                        function (success) {
                            if (success) {
                                statusMessage(ss.i18n._t('ModelAdmin.DELETED', 'Successfully deleted'));
                            }
                        }
                    );
                    parent.find('.subitems').empty();
                    parent.removeClass('menuitemgroup').removeClass('menuitemexpanded');
                } else {
                    //Restore check state if the user has not confirmed the action
                    $(this).attr('checked', true);
                }
            }
        });

        $('body').delegate('.moveup-menuitem,.movedown-menuitem', 'click', function(event) {
            event.preventDefault();
            var isUp = $(this).hasClass('moveup-menuitem');
            var item1 = $(this).closest('.menuitem');
            var item2 = isUp
                ? item1.prev()
                : item1.next()
            ;

            var posinput1 = item1.find('.position').not(item1.find('.menuitem .position'));
            var posinput2 = item2.find('.position').not(item2.find('.menuitem .position'));

            var pos1 = posinput1.val();
            posinput1.val(posinput2.val());
            posinput2.val(pos1);


            item2[isUp ? 'before' : 'after'](item1);
        });

        $('body').delegate('.isexternal-checkbox', 'change', function() {
            var menuitem = $(this).closest('.menuitem');
            if ($(this).is(':checked')) {
                menuitem.addClass('menuitemexternal');
            } else {
                menuitem.removeClass('menuitemexternal');
            }
        });

        $('body').delegate('.linktype', 'change', function() {
            var menuitem = $(this).closest('.menuitem');
            var type = $(this).val();

            menuitem.attr('data-type', type);

            var uriInput = menuitem
                .find('.uri-wrapper input')
                .not(menuitem.find('.menuitem .uri-wrapper input'))
            ;

            if (type != 'external') {
                uriInput.attr('disabled', 'disabled');
            } else {
                uriInput.removeAttr('disabled');
            }
        });

        $('body').delegate('.expand-menuitem,.collapse-menuitem', 'click', function(event) {
            event.preventDefault();
            var expand = $(this).hasClass('expand-menuitem');
            var menuitem = $(this).closest('.menuitem');

            menuitem[expand ? 'addClass' : 'removeClass']('menuitemexpanded');
        });

        $('body').delegate('.menuitem-expandall', 'click', function(event) {
            event.preventDefault();
            $('.menuitemgroup > .submenu-options .expand-menuitem').trigger('click');
        });

        $('body').delegate('.menuitem-collapseall', 'click', function(event) {
            event.preventDefault();
            $('.menuitemgroup > .submenu-options .collapse-menuitem').trigger('click');
        });
    });
})(jQuery);