var mlolActive;

/**
 * 
 * @returns {String}
 */
function testMLOL() {
    var httpRequest = new XMLHttpRequest();
    httpRequest.open('GET', "shelf/mlolActiveOnSystem", false);
    httpRequest.send();
    return httpRequest.responseText;
}

/**
 * Cambiamento del tipo di scaffale
 * 
 * @param {type} element
 * @returns {undefined}
 */
var shelfTypeChanged = function(element) {
    var container = jQuery(element).closest('.lq_shelfform');
    /* Scaffale notizie Clavis */
    var externalGroup = container.find('.lq_shelf_external_group').closest('.fieldgroupField');
    /* Uno dei tuoi scaffali su DNG */
    var memberGroup = container.find('.lq_shelf_member_group').closest('.fieldgroupField');
    /* Scaffale predefinito su DNG */
    var predefinedGroup = container.find('.lq_shelf_predefined_group').closest('.fieldgroupField');
    /* Scaffale da ShelfPage */
    var shelfpageGroup = container.find('.lq_shelf_shelfpage_group').closest('.fieldgroupField');
    /* Scaffale ricavato dal servizio MLOL */
    if (mlolActive == 'true') {
        var shelfmlolGroup = container.find('.lq_shelf_mlol_group').closest('.fieldgroupField');
    }
    /* Filtro per biblioteca */
    var libFilterGroup = container.find('.lq_shelf_library_filter').closest('.fieldgroupField');
    
    var spaceOne = container.find('.space_shelf_1').closest('.fieldgroupField');
    var spaceTwo = container.find('.space_shelf_2').closest('.fieldgroupField');
    var spaceThree = container.find('.space_shelf_3').closest('.fieldgroupField');
    var spaceFour = container.find('.space_shelf_4').closest('.fieldgroupField');
    
    var sortField = container.find('[name*="ShelfSort"]');
    
    var sortFieldGroup = sortField.closest('.fieldgroupField');
    
    var shelfType = getShelfType(container);

    switch (shelfType) {
        /* Scaffale notizie Clavis */
        case 'external':
            externalGroup.show();
            document.querySelector(".lq_shelf_external_group").style.marginLeft = "0px";
            predefinedGroup.hide();
            memberGroup.hide();
            shelfpageGroup.hide();
            if (mlolActive == 'true') { shelfmlolGroup.hide(); }
            libFilterGroup.show();
            spaceOne.hide();
            spaceTwo.hide();
            spaceThree.hide();
            spaceFour.show();
            document.querySelector(".checkbox").style.visibility = "visible";
            break;
        case 'member':
            externalGroup.hide();
            predefinedGroup.hide();
            memberGroup.show();
            shelfpageGroup.hide();
            if (mlolActive == 'true') { shelfmlolGroup.hide(); }
            libFilterGroup.show();
            spaceOne.show();
            spaceTwo.show();
            spaceThree.show();
            spaceFour.show();
            document.querySelector(".checkbox").style.visibility = "visible";
            break;

        case 'predefined':
            externalGroup.hide();
            predefinedGroup.show();
            memberGroup.hide();
            shelfpageGroup.hide();
            if (mlolActive == 'true') { shelfmlolGroup.hide(); }
            libFilterGroup.show();
            spaceOne.hide();
            spaceTwo.hide();
            spaceThree.show();
            spaceFour.show();
            document.querySelector(".checkbox").style.visibility = "visible";
            break;
        case 'shelfpage':
            externalGroup.hide();
            predefinedGroup.hide();
            memberGroup.hide();
            shelfpageGroup.show();
            if (mlolActive == 'true') { shelfmlolGroup.hide(); }
            libFilterGroup.show();
            spaceOne.show();
            spaceTwo.show();
            spaceThree.show();
            spaceFour.show();
            document.querySelector(".checkbox").style.visibility = "visible";
            break;
        case 'shelfmlol':
            if (mlolActive == 'true') {
                externalGroup.hide();
                predefinedGroup.hide();
                memberGroup.hide();
                shelfpageGroup.hide();
                shelfmlolGroup.show();
                document.querySelector(".lq_shelf_mlol_group").style.marginLeft = "0px";
                libFilterGroup.hide();
                spaceOne.hide();
                spaceTwo.hide();
                spaceThree.hide();
                spaceFour.hide();
                document.querySelector(".checkbox").style.visibility = "hidden";
            }
            break; 
    }

    if (shelfType == 'predefined') {
        sortFieldGroup.hide();
        sortField.val('');
    } else {
        sortFieldGroup.show();
    }

    if (mlolActive == 'true') {
        if ((shelfType == 'predefined')||(shelfType == 'shelfmlol')) {
            sortFieldGroup.hide();
            sortField.val('');
        } else {
            sortFieldGroup.show();
        }
    }
    updateShelfRef(container);
};

/**
 * 
 * @param {type} shelfform
 * @returns {undefined}
 */
var libraryFilterChanged = function (shelfform) {
    updateShelfRef(shelfform);
};

/**
 * 
 * @param {type} shelfform
 * @returns {jQuery}
 */
var getShelfType = function(shelfform) {
    return jQuery(shelfform).find("input:radio:checked").val();
};

/**
 * 
 * @param {type} shelfform
 * @returns {undefined}
 */
var updateShelfRef = function(shelfform) {
    var shelfRefField = jQuery(shelfform).find('.lq_shelf_ref_field');
    var shelfRef = '';
    var shelfType = getShelfType(shelfform);

    switch (shelfType) {
        case 'member':
            var memberSelect = shelfform.find('.lq_shelf_member_group');
            shelfRef = 'persistent:'+memberSelect.val();
            break;
        case 'external':
            var externalShelfSelect = shelfform.find('.lq_externalshelf_dropdown');
            var librarySelect = shelfform.find('.lq_library_dropdown');
            shelfRef = 'external:'+externalShelfSelect.val()+':'+librarySelect.val();
            break;
        case 'predefined':
            var predefinedSelect = shelfform.find('.lq_shelf_predefined_group');
            shelfRef = 'predefined:'+predefinedSelect.val();
            break;
        case 'shelfpage':
            var predefinedSelect = shelfform.find('.lq_shelf_shelfpage_group');
            shelfRef = 'shelfpage:'+predefinedSelect.val();
            break;
        case 'shelfmlol':
            if (mlolActive == 'true') {
                var mlolShelfSelect = shelfform.find('.lq_shelf_mlol_dropdown');
                var mediaSelect = shelfform.find('.lq_shelf_resources_dropdown');
                shelfRef = 'shelfmlol:'+mlolShelfSelect.val()+':'+mediaSelect.val();
            }
            break;
    }

    var libraryFilter = jQuery(shelfform).find('.lq_shelf_library_filter').val();
    
    // Evita l'accodamento dell'ID della biblioteca di riferimento
    if ((shelfType != 'shelfmlol')&&(libraryFilter)) {
        shelfRef += ':' + libraryFilter;                
    }

    shelfRefField.val(shelfRef);
};

/**
 * Attiva i rispettivi comandi in base ai valori contenuti in shelfRef
 * 
 * @param {type} shelfform
 * @returns {undefined}
 */
var loadInitialData = function(shelfform) {
    var shelfRef = jQuery(shelfform).find('.lq_shelf_ref_field').val();

    var pieces = shelfRef.split(':');

    var activeType = "predefined";

    if (pieces[0] === 'predefined'){
        activeType = 'predefined';
        jQuery(shelfform).find('.lq_shelf_predefined_group').val(pieces[1]);
        
    } else if (pieces[0] === 'shelfpage') {
        activeType = 'shelfpage';
        jQuery(shelfform).find('.lq_shelf_predefined_group').val(pieces[1]);
    
    } else if (pieces[0] === 'shelfmlol') {
        if (mlolActive == 'true') {
            // Tipo di scaffale
            activeType = 'shelfmlol';
            // Popola le tendine con il tipo di scaffale e il codice della risorsa
            jQuery(shelfform).find('.lq_shelf_mlol_dropdown').val(pieces[1]);
            jQuery(shelfform).find('.lq_shelf_resources_dropdown').val(pieces[2]);
            jQuery(shelfform).find('.lq_shelf_library_filter').val("");
        }
        
    } else if (pieces[0] === 'persistent') {
        if (jQuery(shelfform).find('.lq_shelf_initial_ext_id').length){
            var libid = jQuery(shelfform).find('.lq_shelf_initial_lib').val();
            var libdropdown = jQuery(shelfform).find('.lq_library_dropdown');
            libdropdown.val(libid);
            libdropdown.trigger('change');
            activeType = 'external';
        } else {
            activeType = 'member';
            jQuery(shelfform).find('.lq_shelf_member_group').val(pieces[1]);
        }
    }
    
    jQuery(shelfform).find('input[type=radio]').removeAttr('checked');
    jQuery(shelfform).find('input[type=radio][value='+activeType+']').attr('checked', 'checked');
};

jQuery(document).ready(function() {
    var i = 0;
    mlolActive = testMLOL();
    
    Behaviour.register({
        '#Form_EditForm' : {
            initialize : function() {
                this.observeMethod('PageLoaded', this.pageLoaded);
                this.observeMethod('BeforeSave', this.beforeSave);
                this.observeMethod('WidgetAdded', this.widgetAdded);
                this.pageLoaded(); // call pageload initially too.
            },

            widgetAdded: function(widget) {
                //When a widget is added to the widget area, the pageload event is not called,
                //so we need to select the appropriate shelf type
                jQuery(widget).find('.lq_shelftype').each(function(){shelfTypeChanged(this);});
                //if (jQuery(widget).hasClass('ShelfWidget'))
            },
            pageLoaded: function () {
                i++;
                if (i <= 1){
                    jQuery('#Form_EditForm').delegate('.lq_library_dropdown', 'change', function(){
                        var externalShelfDropdown = jQuery(this).closest('.fieldgroup').find('.lq_externalshelf_dropdown');
                        var libraryId = jQuery(this).find('option:selected').val();
                        var shelfform = jQuery(this).closest('.lq_shelfform');

                        //Load "Loading" option in the select while we are performing the java request
                        var oldval = externalShelfDropdown.val();
                        externalShelfDropdown.empty();
                        externalShelfDropdown.append(jQuery('<option value="'+oldval+'">'+ss.i18n._t('Liquens.LOADDATA')+'</option>'));
                        externalShelfDropdown.attr('disabled','disabled');

                        jQuery.ajax({
                            url: 'shelf/updateCSDropDown',
                            dataType: 'json',
                            data: {
                                term: libraryId
                            },
                            success: function ( data ) {
                                // empties the options
                                externalShelfDropdown.empty();
                                // fill options

                                if (data.length == 0){
                                    externalShelfDropdown.attr('disabled','disabled');
                                    externalShelfDropdown.append(jQuery('<option value="">'+ss.i18n._t('ShelfWidget.NOSHELVES')+'</option>'));
                                } else {
                                    externalShelfDropdown.removeAttr('disabled');
                                    externalShelfDropdown.append(jQuery('<option value="">---</option>'));
                                }

                                for(var i = 0; i < data.length; i++)
                                {
                                    externalShelfDropdown.append(jQuery('<option value=\"' + data[i].idx + '\">' + data[i].name + '</option>'));
                                }

                                //Select the shelf if .lq_shelf_initial_ext_id is present
                                var initialExtidField = jQuery(shelfform).find('.lq_shelf_initial_ext_id');
                                if (initialExtidField.length){
                                    externalShelfDropdown.val(initialExtidField.val());
                                    initialExtidField.remove();
                                    jQuery(shelfform).find('.lq_shelf_initial_lib').remove();
                                }
                            }
                        });
                    });

                    jQuery('#Form_EditForm').delegate('.lq_shelftype', 'change', function(){
                        shelfTypeChanged(this);
                    });

                    // Eventi da controllare per effettuare l'aggiornamento di shelfRef
                    var delegateContent = '.lq_shelf_member_group,.lq_shelf_predefined_group,.lq_externalshelf_dropdown,.lq_shelf_shelfpage_group';
                    if (mlolActive == 'true') { delegateContent += ',.lq_shelf_mlol_dropdown,.lq_shelf_resources_dropdown'; }

                    jQuery('#Form_EditForm')
                        .delegate(delegateContent, 'change', function(){
                        var shelfform = jQuery(this).closest('.lq_shelfform');
                        updateShelfRef(shelfform);
                    });

                    jQuery('#Form_EditForm').delegate('.lq_shelf_library_filter', 'change', function(){
                        var shelfform = jQuery(this).closest('.lq_shelfform');
                        libraryFilterChanged(shelfform);
                    });
                }

                jQuery('.lq_shelfform').each(function(){
                    loadInitialData(this);
                });
                jQuery('.lq_shelftype').each(function(){shelfTypeChanged(this);});
            }
        } // #Form_EditForm
    });
   
});
