/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

/* Making the Tree Tools sticky - from http://www.ssbits.com/snippets/2011/making-the-tree-tools-sticky */
function setSitetreeHolderMarginTop() {
    jQuery("#sitetree_holder").css("margin-top", jQuery("#TreeTools").height()+"px");
    fixHeight_left();
}

(function($) {
   $('#TreeActions button').live('click', function() {
       setSitetreeHolderMarginTop();
   });
})(jQuery); 


function limitChecks(id,n){
   jQuery(id).live('click', function(){
   return jQuery(id).filter(':checked').length <=n;
   });
} 

jQuery(document).ready(function() {
    setTimeout('setSitetreeHolderMarginTop()', 1000);
    limitChecks('#Form_EditForm_LqEventCategories>li input:checkbox',3);
});

var chekboxShowHidesConf = [
    //PAgesListWidget
    {
        selector: '.PagesListWidget input:checkbox[name*="EnableParentFilter"]',
        containerSelector: ".PagesListWidget",
        targetSelector: '.select2-container[id*="ParentFilterID"]'
    },
    {
        selector: '.PagesListWidget input:checkbox[name*="EnableSelectedPagesFilter"]',
        containerSelector: ".PagesListWidget",
        targetSelector: '.select2-container[id*="SelectedPages"]'
    },
    {
        selector: '.PagesListWidget input:checkbox[name*="EnableSelectedPagesFilter"]',
        containerSelector: ".PagesListWidget",
        targetSelector: '.genericFilters',
        invert: true
    },
    {
        selector: 'input:checkbox[name*="DisplayExtract"]',
        containerSelector: ".PagesListWidget",
        targetSelector: '.extractOptions'
    },
    {
        selector: '.PagesListWidget input:checkbox[name*="FullExtract"]',
        containerSelector: ".PagesListWidget",
        targetSelector: '.field[id*="ExtractLength"]',
        invert: true
    },
    {
        selector: '.PagesListWidget input:checkbox[name*="ShowMore"]',
        containerSelector: ".PagesListWidget",
        targetSelector: 'div.field[id*="ShowMoreLength"]'
    },
    //RSS widget
    {
        selector: '.RssWidget input:checkbox[name*="DisplayExtract"]',
        containerSelector: ".RssWidget",
        targetSelector: '.extractOptions'
    },
    {
        selector: '.RssWidget input:checkbox[name*="FullExtract"]',
        containerSelector: ".RssWidget",
        targetSelector: '.field[id*="ExtractLength"]',
        invert: true
    },
    {
        selector: '.RssWidget input:checkbox[name*="ShowMore"]',
        containerSelector: ".RssWidget",
        targetSelector: 'div.field[id*="ShowMoreLength"]'
    },
];

jQuery(document).ready(function()
{
    if (typeof WidgetAreaEditorClass != 'undefined'){
        var oldMethod = WidgetAreaEditorClass.prototype.insertWidgetEditor;
        WidgetAreaEditorClass.prototype.insertWidgetEditor = function (response){
            oldMethod.call(this, response);
            var form = $('Form_EditForm');
            var widget = jQuery('#usedWidgets-'+this.name).find('.Widget')[0];
            form.notify('WidgetAdded', widget);
        };
    }

    jQuery('input.jqueryDatePicker').live('focus', function(){
        var inputElement = jQuery(this);
        /*if (!inputElement.data('datePickerLoaded')) {
            inputElement.datepicker();
            inputElement.data('datePickerLoaded', true);
        }*/

        inputElement.datepicker({dateFormat: 'yy-mm-dd'});
    });
    //$(this).datepicker({dateFormat : date_picker_format, buttonImage : '/sapphire/images/calendar-icon.gif', buttonImageOnly : true});

    function initializeSelect2Fields(parent) {
        parent = parent || 'body';
        var select2Options =
        {
            placeholder: "Cerca una pagina",
            minimumInputLength: 1,
            dropdownCssClass: "bigdrop",
            ajax: { // instead of writing the function to execute the request we use Select2's convenient helper
                url: "data/json/pages",
                data: function (term, page) {
                    return {
                        q: term, // search term
                        limit: 10
                    };
                },
                results: function (data, page) { // parse the results into the format expected by Select2.
                    // since we are using custom formatting functions we do not need to alter remote JSON data
                    return {results: data};
                }
            },
            initSelectionMultiple: function (element, callback) {
                var data = [];
                jQuery(element.val().split(",")).each(function () {
                    data.push({id: this, title: jQuery(element).data('page-' + this)});
                });
                callback(data);
            },
            initSelection: function (element, callback) {
                var val = jQuery(element).val();
                callback({id: val, title: jQuery(element).data('page-' + val)});
            },
            width: '100%',
            formatResult: function (pageData) { return '<b>' + pageData.title + '</b><br>' + pageData.url},
            formatSelection: function(pageData){ return pageData.title }
        };

        var loadSelect2 = function() {
            var element = jQuery(this);

            if (!element.hasClass('select2-loaded')) {
                element.select2(select2Options);
                element.addClass('select2-loaded');
            }
        };

        jQuery(parent).find('input.select2single').each(loadSelect2);
        select2Options.multiple = true;
        select2Options.initSelection = select2Options.initSelectionMultiple;
        jQuery(parent).find('input.select2multi').each(loadSelect2);
    }

    initializeSelect2Fields();
    jQuery('input.select2single, input.select2multi').livequery(initializeSelect2Fields);

    /**
     * Load checkbox show/hide handlers
     */
    for (var i = 0; i < chekboxShowHidesConf.length; i++) {
        var data = chekboxShowHidesConf[i];

        //Why this? Check this out: http://stackoverflow.com/questions/1552941/variables-in-anonymous-functions-can-someone-explain-the-following
        var handler = (function(d){
            var invert = d.hasOwnProperty('invert') && d.invert;
            return function(event) {
                return checkboxShowHide(jQuery(this), d.containerSelector, d.targetSelector, invert);
            }
        })(data);

        jQuery('body').delegate(data.selector, 'change', handler);
        jQuery(data.selector).livequery(handler);
    }

    /**
     * Widgets UI improvements
     */
    jQuery('.usedWidgets .Widget .expand').live( 'click', function(){

        jQuery(this).closest('.Widget').toggleClass('collapsed');

    });

    jQuery('.usedWidgetsHolder .expandAll').live('click', function(e){
        e.preventDefault();
        jQuery(this).closest('.usedWidgetsHolder').find('.Widget').removeClass('collapsed');
    });

    jQuery('.usedWidgetsHolder .collapseAll').live('click', function(e){
        e.preventDefault();
        jQuery(this).closest('.usedWidgetsHolder').find('.Widget').addClass('collapsed');
    });

    jQuery('.usedWidgetsHolder .Widget select.gridwidget-position').live('change', function(e) {
         jQuery(this).closest('.Widget').attr('data-position', jQuery(this).val());
    });

    jQuery('.usedWidgetsHolder .Widget .embedIframe.enabled').live('click', function(e) {
        e.preventDefault();
        var src = jQuery(this).closest('.embedIframe').attr('data-iframesrc');
        var html = '<iframe src="' + src + '" frameborder=0 width=500></iframe>';
        window.prompt ("Copia il codice HTML negli appunti ed incollalo nel tuo sito:", html);
    });

    jQuery('.usedWidgetsHolder .Widget .embedIframe.disabled').live('click', function(e) {
        e.preventDefault();
        alert("E' necessario salvare la pagina per poter esportare questo widget.");
    });

    //Content Widget and select 2 show/hide
    jQuery('.ContentWidget [type="radio"]').live('change', function() {
        var val = jQuery(this).closest('.ContentWidget').find('input:radio:checked').val();
        jQuery(this).closest('[data-type]').attr('data-type', val);
    });

    //Tabs in textareas
    jQuery('textarea').keypress(function (e) {
        if (e.keyCode == 9) {
        	var myValue = "\t";
        	var startPos = this.selectionStart;
        	var endPos = this.selectionEnd;
        	var scrollTop = this.scrollTop;
        	this.value = this.value.substring(0, startPos) + myValue + this.value.substring(endPos,this.value.length);
        	this.focus();
        	this.selectionStart = startPos + myValue.length;
        	this.selectionEnd = startPos + myValue.length;
        	this.scrollTop = scrollTop;

        	e.preventDefault();
        }
    });
});

function checkboxShowHide(checkbox, containerSelector, targetSelector, isInverted)
{
    var check = jQuery(checkbox);
    var container = check.closest(containerSelector);
    var target = container.find(targetSelector);

    var isChecked = !!check.attr('checked');

    if (isChecked != isInverted) {
        target.show();
    } else {
        target.hide();
    }
}