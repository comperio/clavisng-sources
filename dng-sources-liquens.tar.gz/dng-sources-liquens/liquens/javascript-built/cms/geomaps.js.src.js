
(function ($) {
    $(document).ready(function () {

        /* Azioni per apertura ricerche */
        if ($('#Form_EditForm fieldset').length === 0)
            $('#Form_SearchForm_Geomap').submit();

        $("#tab-ModelAdmin_Mappe").click(function () {
            $('#Form_SearchForm_Geomap').submit();
        });

        $("#tab-ModelAdmin_Percorsi").click(function () {
            $('#Form_SearchForm_GeomapPath').submit();
        });

        $("#tab-ModelAdmin_Punti").click(function () {
            $('#Form_SearchForm_GeomapPoint').submit();
        });

        $(document).ajaxComplete(function (event, xhr, settings) {
            
            /* *************************************************************** Codice su mappa *************************************************************** */
            /* Spostamento campi */
            var $div = $('div#Instructions.readonly:first').detach();
            $("div#Instructions.readonly").remove();
            $div.insertAfter($("div#DescriptionMap"));
            
            $div = $('div#NewPathName.text:first').detach();
            $("div#NewPathName.text").remove();
            $div.insertAfter($("div#Instructions.readonly"));
            
            $div = $('div#NewPathPoints.dropdown:first').detach();
            $("div#NewPathPoints.dropdown").remove();
            $div.insertAfter($("div#NewPathName.text"));
            
            $div = $('div#OsmapFirstInsert.osmap:first').detach();
            $("div#OsmapFirstInsert.osmap").remove();
            $div.insertAfter($("div#NewPathPoints.dropdown"));
            
            /* Eliminazione campi colonna sinistra */
            $("form#Form_SearchForm_Geomap > fieldset > div#NewPathName.field.text").remove();
            $("form#Form_SearchForm_Geomap > fieldset > div#NewPathPoints.field.dropdown").remove();
            $("form#Form_SearchForm_Geomap > fieldset > div#OsmapFirstInsert.field.osmap").remove();
            $("form#Form_SearchForm_Geomap > fieldset > div#Instructions.readonly").remove();
            
            /* Eliminazione campi area centrale */
            $("form#Form_EditForm > fieldset > div#Root_Main.tab > div#NewPathPoints.field.text").remove();
            $("form#Form_EditForm > fieldset > div#Root_Main.tab > div#OsmapFirstInsert.field.textarea").remove();
            
            /* Ridenominazione campi */
            $('input#Form_CreateForm_Geomap_action_add').val('Crea Mappa');
            $('div#TitleMap > label.left').text('Titolo');
            $('div#DescriptionMap > label.left').text('Descrizione');
            $('div#OverTile > label.left').text('Livello aggiuntivo alla mappa (1 solo livello)');
            
            /* Ridimensionamento area su creazione mappa */
            $("div#Root_Main.tab").height($("form#Form_AddForm").height() - ($("div#form_actions_right").height() * 3));
            
            $('#Form_AddForm_OverTile').attr('readonly', true).attr('class', "readonly").attr('cols', "5").attr('rows', "1").attr("style", "resize:none; line-height:1; font-size:12px; border:none; margin:0; padding:0;");
            
            /* *************************************************************** Codice sui percorsi *************************************************************** */
            /* Spostamento campi */
            var $div = $('div#InstructionsPath.readonly:first').detach();
            $("div#InstructionsPath.readonly").remove();
            $div.insertAfter($("div#TypePath"));
            
            var $div = $('div#LinkedGeomapID.dropdown:first').detach();
            $("div#LinkedGeomapID.dropdown").remove();
            $div.insertAfter($("div#InstructionsPath.readonly"));
            
            $div = $('div#OsmapFirstInsertPath.osmap:first').detach();
            $("div#OsmapFirstInsertPath.osmap").remove();
            $div.insertAfter($("div#LinkedGeomapID.dropdown"));
            
            /* Eliminazione campi area centrale */
            $("form#Form_EditForm > fieldset > div#Root_Main.tab > div#OsmapFirstInsertPath.field.textarea").remove();
            
            /* Ridenominazione campi */
            $('input#Form_CreateForm_GeomapPath_action_add').val('Crea Percorso');
            $('div#TitlePath > label.left').text('Titolo');
            $('div#DescriptionPath > label.left').text('Descrizione');            
            $('div#TypePath > label.left').text('Tipologia percorso');
            
            /* Eliminazione campi colonna sinistra */
            $("form#Form_SearchForm_GeomapPath > fieldset > div#InstructionsPath.field.readonly").remove();
            $("form#Form_SearchForm_GeomapPath > fieldset > div#LinkedGeomapID.field.dropdown").remove();
            $("form#Form_SearchForm_GeomapPath > fieldset > div#OsmapFirstInsertPath.field.osmap").remove();
            
            /* *************************************************************** Codice sui punti *************************************************************** */
            /* Spostamento campi */
            $div = $('div#OsmapSinglePoint.osmap:first').detach();
            $("div#OsmapSinglePoint.osmap").remove();
            $div.insertAfter($("div#DescriptionPoint.htmleditor"));
            
            /* Spostamento campi */
            $div = $('div#OsmapSinglePointChange.osmap:first').detach();
            $("div#OsmapSinglePointChange.osmap").remove();
            $div.insertAfter($("div#DescriptionPoint.htmleditor"));
            
            /* Ridenominazione campi */
            $('input#Form_CreateForm_GeomapPoint_action_add').val('Crea Punto');
            $('div#TitlePoint > label.left').text('Titolo');
            $('div#DescriptionPoint > label.left').text('Descrizione');
            $('div#TypePoint > label.left').text('Tipologia media');

            /* Ridimensionamento area su creazione mappa */
            $("div#Root_Main.tab").height($("form#Form_EditForm").height() - ($("div#form_actions_right").height() * 3));
        });
    });
})(jQuery);