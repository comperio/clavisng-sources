require(["jquery", "URIjs/URI"], function($, URI) {

    $(document).ready(function () {

            var updateAuthModalData = function(name, value) {
                var element = $('#authority-modal').find('[data-uri]');
                element.attr('data-' + name, value);
            };

            var reloadAuthModal = function(){
                var element = $('#authority-modal').find('[data-uri]');
                $('#authority-modal').find('.loading-holder').attr('data-isloading', 1);

                var uri = new URI(element.data('uri'));
 
                uri.setSearch({
                    "auth_page": element.attr('data-page'),
                    "auth_sort": element.attr('data-sort'),
                    "auth_prefix": element.attr('data-prefix'),
                    "auth_id": element.attr('data-id'),
                    "auth_count": element.attr('data-count'),
                    "auth_fulltext": element.attr('data-fulltext'),
                    "auth_initialtext": element.attr('data-initialtext'),
                    "modal_type": element.attr('data-modaltype'),
                    "auth_type": $("#selectorAuthList option:selected").val(),
                    "link_type": element.attr('data-linktype')
                });
 
                element.data('uri', uri.toString());
                element.trigger('refresh');
            };

            /* Sul CLICK di ALTRI SOGGETTI */
            $('body').on('click', '#authOtherSubjectFullExpander', function(event) {
                event.preventDefault(); 

                /* Aggiunge il loading... */
                $(this).closest('a').attr('data-isloading', 1);

                /* Estrapola l'uri necessario alla chiamata */
                var authModal = $('#authority-modal');
                var authUri = $(this).closestData('authlist-uri');

                /* Aggiunge l'indirizzo ed esegue il refresh */
                authModal.find('[data-uri]').data('uri', authUri).html('').trigger('refresh');
            });                        

            /* Sul CLICK di troppi THESAURO */
            $('body').on('click', '#authOtherThesauroOthersExpander', function(event) {
                event.preventDefault(); 

                /* Aggiunge il loading... */
                $(this).closest('a').attr('data-isloading', 1);

                /* Estrapola l'uri necessario alla chiamata */
                var authModal = $('#authority-modal');
                var authUri = $(this).closestData('authlist-uri');

                /* Aggiunge l'indirizzo ed esegue il refresh */
                authModal.find('[data-uri]').data('uri', authUri).html('').trigger('refresh');
            });

            /* Sul CLICK di LISTA AUTHORITY */
            $('body').on('click', '#authorityListModal', function(event) {
                event.preventDefault(); 

                /* Aggiunge il loading... */
                $(this).closest('a').attr('data-isloading', 1);

                /* Estrapola l'uri necessario alla chiamata */
                var authModal = $('#authority-modal');
                var authUri = $(this).closestData('authlist-uri');

                /* Aggiunge l'indirizzo ed esegue il refresh */
                authModal.find('[data-uri]').data('uri', authUri).html('').trigger('refresh');
            });                        

            /* Sul CLICK di LEGAMI ALTRE OPERE su NON OPERE */
            $('body').on('click', '#authorityOtherLinksOperaExpander', function(event) {
                event.preventDefault(); 

                /* Aggiunge il loading... */
                $(this).closest('a').attr('data-isloading', 1);

                /* Estrapola l'uri necessario alla chiamata */
                var authModal = $('#authority-modal');
                var authUri = $(this).closestData('authlist-uri');

                /* Aggiunge l'indirizzo ed esegue il refresh */
                authModal.find('[data-uri]').data('uri', authUri).html('').trigger('refresh');
            });      

            $('body').on('refreshed', '#authority-modal', function() {
                $(this).modal('show');

                //Trick to move the caret at the end of the input value:
                var authPrefixInput = $(this).find('input[data-action="prefix"]');
                var authOldPrefixVal = authPrefixInput.val();
                $(this).find('input[data-action="prefix"]').focus().val("").val(authOldPrefixVal);
            });

            /* Rimuove il loading alla fine, dopo aver... */
            $('body').on('shown.bs.modal', '#authority-modal', function() {
                $('#authOtherSubjectFullExpander[data-isloading]').removeAttr('data-isloading');
                $('#authorityListModal[data-isloading]').removeAttr('data-isloading');
                $('#authOtherThesauroOthersExpander[data-isloading]').removeAttr('data-isloading');
                $('#authorityOtherLinksOperaExpander[data-isloading]').removeAttr('data-isloading');
            });

            /* Paginatori */
            $('body').on('click', '#authority-modal [data-action="authprevious"]', function(e) {
                    e.preventDefault();
                    updateAuthModalData('page', parseInt($(this).closestData('page')) - 1);
                    reloadAuthModal();
            });
            $('body').on('click', '#authority-modal [data-action="authnext"]', function(e) {
                    e.preventDefault();
                    updateAuthModalData('page', parseInt($(this).closestData('page')) + 1);
                    reloadAuthModal();
            });

            $('body').on('click', '#authority-modal [data-action="sort-search"]', function() {
                    updateAuthModalData('fulltext', $('.text-input-full').val());
                    updateAuthModalData('initialtext', $('.text-input-initial').val());
                    updateAuthModalData('page', '0');
                    reloadAuthModal();
            });

            $('body').on('keypress', '#initialtextButton', function(event) {
                var keycode = (event.keyCode ? event.keyCode : event.which);
                if(keycode == '13'){
                    updateAuthModalData('fulltext', $('.text-input-full').val());
                    updateAuthModalData('initialtext', $('.text-input-initial').val());
                    updateAuthModalData('page', '0');
                    reloadAuthModal();	
                }
            });

            $('body').on('keypress', '#fulltextButton', function(event) {
                var keycode = (event.keyCode ? event.keyCode : event.which);
                if(keycode == '13'){
                    updateAuthModalData('fulltext', $('.text-input-full').val());
                    updateAuthModalData('initialtext', $('.text-input-initial').val());
                    updateAuthModalData('page', '0');
                    reloadAuthModal();	
                }
            });                        
    });
});