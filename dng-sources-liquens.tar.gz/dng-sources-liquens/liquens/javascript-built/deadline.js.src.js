require(["jquery"], function($) {
    $(document).ready(function () {
        /* Chiusura modale con salvataggio stato */
        $('body').on('click', '#dLineButtonClose', function() {
            $('.deadline-dialog').remove();
        });
    });
});