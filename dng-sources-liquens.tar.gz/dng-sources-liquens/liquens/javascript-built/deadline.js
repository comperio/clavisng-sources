require(["jquery"],function(e){e(document).ready(function(){e("body").on("click","#dLineButtonClose",function(){e(".deadline-dialog").remove()})})});
//# sourceMappingURL=deadline.js.map