/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
var require = {
    deps: [
            "modernizr",
            "jquery",
            "jquery-placeholder",
            "dng-common",
            "dng-actions",
            "dng-reservations-dom",
            "dng-shelves-dom",
            "dng-manifestation",
            "dng-rating",
            "dng-fakecover",
            "jquery-expander",
            "jquery-validation",
            "footable",
            "footable-sort",
            "footable-paginate",
            "footable-filter",
            "respondjs"
    ],
    paths: {
        "jquery": "../../bower_components/jquery/jquery",
        "jquery-migrate": "../../bower_components/jquery/jquery-migrate",
        "jquery-placeholder": "../../bower_components/jquery-placeholder/jquery.placeholder",
        "bootstrap": "../../bower_components/bootstrap/dist/js/bootstrap",
        "typeahead": "../../bower_components/typeahead.js/dist/typeahead",
        "modernizr": "modernizr",
        "respondjs": "../../bower_components/respond/src/respond",

        "dng-common": "modules/common",
        "dng-actions": "modules/actions",
        "dng-reservations": "modules/reservations",
        "dng-reservations-dom": "modules/reservations-dom",
        "dng-loans": "modules/loans",
        "dng-contacts": "modules/contacts",
        "dng-manifestation": "modules/manifestation",
        "dng-shelves": "modules/shelves",
        "dng-shelves-dom": "modules/shelves-dom",
        "dng-rating": "modules/rating",
        "dng-fakecover": "modules/fakecover",
        "dng-validation": "modules/validation",
        "dng-cdffield": "modules/cdffield",
        "dng-comments": "modules/comments",

        "jqueryui-widget": "../../bower_components/jquery-ui/ui/jquery.ui.widget",
        "jquery-expander": "../../bower_components/jquery-expander/jquery.expander",
        "jquery-validation": "../../bower_components/jquery.validation/jquery.validate",
        "covers-carousel": "../../bower_components/covers-carousel/src/jquery.covers-carousel",
        "jquery-colorbox": "../../bower_components/jquery-colorbox/jquery.colorbox",
        "URIjs": '../../bower_components/uri.js/src',

        "footable": "../../bower_components/footable/js/footable",
        "footable-sort": "../../bower_components/footable/js/footable.sort",
        "footable-filter": "../../bower_components/footable/js/footable.filter",
        "footable-paginate": "../../bower_components/footable/js/footable.paginate"
    },
    shim: {
        "jquery-migrate": ["jquery"],
        "jquery-placeholder": ["jquery"],
        "jquery-expander": ["jquery"],
        "jquery-validation": ['jquery'],
        "jquery-colorbox": ["jquery"],
        "footable": ["jquery"],
        "footable-sort": ["jquery", "footable"],
        "footable-paginate": ["jquery", "footable"],
        "footable-filter": ["jquery", "footable"],
    },
    waitSeconds: 15
};