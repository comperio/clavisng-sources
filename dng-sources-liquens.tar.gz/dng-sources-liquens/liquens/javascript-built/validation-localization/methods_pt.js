jQuery.extend(jQuery.validator.methods,{date:function(d,t){return this.optional(t)||/^\d\d?\/\d\d?\/\d\d\d?\d?$/.test(d)}});
//# sourceMappingURL=methods_pt.js.map