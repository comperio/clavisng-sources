/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
define(['jquery'], function($) {
    $(document).ready(function(){

        /**
         * Comment-cration-request semantic event handler
         * Throw a comment-created event
         */
        $('body').on('comment-creation-request', function(event, manid, data) {
            $.post('community/forum/reviews/ReplyForm', data)
                .done(function(response) {
                    $(event.target).trigger('comment-created', [manid, data]);
                });
        });
    }) ;
});