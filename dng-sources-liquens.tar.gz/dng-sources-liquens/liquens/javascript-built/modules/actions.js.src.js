/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
define(["jquery", "dng-common"], function($) {
    /**
     * A container of handlers of common dng javascript behaviours, like show/hide links
     *
     * @type {Object}
     */
    var dngActions =
    {
        /**
         * Register an handler
         *
         * @param selector The selector that selects the objects that will trigger the events
         * @param event The event(s) to trigger
         * @param handler The function that will handle the event
         * @param parentSelector The parent elements that will intercepts the event (see jQuery on/delegate docs)
         */
        registerHandler: function (selector, event, handler, parentSelector)
        {
            parentSelector = parentSelector || 'body';

            $(parentSelector).on(event, selector, this.wrappedHandler(handler));
        },

        /**
         * Wrap the handler to allow the "enabled-in" and disable-in check
         * @param handler
         * @returns {Function}
         */
        wrappedHandler: function(handler)
        {
            return function() {
                if ($(this).data('enabled-in') && $(this).closest($(this).data('enabled-in')).length == 0)
                    return;
                if ($(this).data('disabled-in') && $(this).closest($(this).data('disabled-in')).length != 0)
                    return;
                return handler.apply(this, arguments);
            };
        },

        /**
         * Retrieve a "target" element linked by this element through data attributes.
         * How it works:
         * If element has no dng-target data attribute, returns the element itself
         * If it has a dng-target, use its value as a selector to find the target element
         * If, in addition, there is a dng-container attribute, target will be searched
         * in elements that match the dng-container attribute
         *
         * @param element a DOM element
         * @param defaultTarget a DOM element returned if there are no data-target attribute. Optional.
         * @returns {*}
         */
        target: function(element, defaultTarget) {
            var target = defaultTarget || $(element);

            if (target.data('dng-target')) {
                var containerSelector = target.data('dng-container') || 'body';
                var targetSelector = target.data('dng-target');

                target = $(element).closest(containerSelector).find(targetSelector);
            }

            return target;
        }
    };

    /**
     * This class holds a collection of "updaters".
     * An updater update an html element in the dom from a given data source.
     *
     * An updater is a generic callback that accept three argument:
     * data, element, options
     * data is an arbitrary datasource, and element is an html element of the dom
     * options is an optional array of parameters for the updater.
     *
     * @constructor
     */
    var UpdatersCollection = function()
    {
        var updaters = {};

        /**
         * Register an updater to the collection
         *
         * @param name
         * @param callback
         */
        this.registerUpdater = function(name, callback)
        {
            updaters[name] = callback;
        };

        /**
         * Retrieve an updater from its name
         *
         * @param name
         * @return {*}
         */
        this.getUpdater = function(name)
        {
            return updaters[name];
        };
    };

    var dngUpdaters = new UpdatersCollection();

    /**
     * Actions definitions
     */
    $(document).ready(function() {
        //Show/Hide action handler
        dngActions.registerHandler('[data-dng-action="show-hide"]', 'click', function (event) {
            event.preventDefault();
            var eventElement = $(this);

            var target = dngActions.target(eventElement);
            var alternativeText = eventElement.data('dng-alt');

            //If data-dng-notoggle attribute is setted, we do not use toggle method
            //on target elements, but we force an hide or show method.
            //To do this we have to store the current state
            if (eventElement.data('dng-notoggle')){
                var currState = 'hidden';
                if (eventElement.attr('data-dng-state')) {
                    currState = eventElement.attr('data-dng-state');
                }

                if (currState === 'hidden') {
                    target.show();
                    eventElement.attr('data-dng-state', 'showed');
                } else {
                    target.hide();
                    target.trigger('data-dng-toggled');
                    eventElement.attr('data-dng-state', 'hidden');
                }
            } else {
                target.toggle();
            }

            //Toggle link text
            if (alternativeText) {
                var currText = eventElement.text();
                eventElement.text(alternativeText).data('dng-alt', currText);
            }

            target.trigger('dngShowHide');
        });

        //Show/Hide action handler
        dngActions.registerHandler('[data-dng-action="ajax-injecter"]', 'change', function (event) {
            //event.preventDefault();
            var eventElement = $(this);
            var container = eventElement.closest(eventElement.data('dng-container'));
            var target = container.find(eventElement.data('dng-target'));
            var dataSourceUrl = eventElement.data('dng-datasource');
            dataSourceUrl = dataSourceUrl.replace('{value}', eventElement.val());
            var updater = dngUpdaters.getUpdater(eventElement.data('dng-updater'));

            updater({'': 'loading...'}, target, {addEmptyElement: false, emptyOnLoad: true});
            target.attr('disabled','disabled');

            jQuery.ajax({
                url: dataSourceUrl,
                dataType: 'json',
                success: function ( data ) {
                    updater(data, target);
                    target.removeAttr('disabled');
                    target.trigger('dngActionUpdated');
                }
            });
        });

        dngActions.registerHandler('[data-dng-action="show-more"]', 'click', function (event) {
            event.preventDefault();
            var showMoreLink = $(this);
            var target = dngActions.target(showMoreLink);
            var page = showMoreLink.data('page');
            var seed = showMoreLink.data('seed');
            var ajaxGet = showMoreLink.data('get');
            var insertMethod = showMoreLink.data('insert-method') || 'append';

            showMoreLink.addClass('loading');

            $.get(ajaxGet, {page: page, seed: seed})
                .done(function ( html ) {
                    target[insertMethod](html);
                    showMoreLink.removeClass('loading');
                    showMoreLink.data('page', parseInt(page)+ 1);

                    if (target.find('span.no-more').length) {
                        showMoreLink.hide();
                    }
                });
        });

        dngActions.registerHandler('[data-dng-action="modal"]', 'click', function (event)
        {
            event.preventDefault();
            var el = $(this);
            var openedModal = $('.modal[aria-hidden="false"]');

            var modal = dngActions.target(el, el.next('.modal').length ? el.next('.modal') : undefined);

            if (openedModal.length > 0) {
                modal.data('prev-modal', openedModal);
                openedModal.modal("hide");
            }

            modal.data('showed-by', el);
            modal.modal('show');
            //Trigger refresh event if modal body has a data-uri attribute
            modal.find(".modal-body[data-uri]").trigger("refresh");
        });

        dngActions.registerHandler('[data-dng-action="loading"]', 'click', function (event)
        {
            var target = dngActions.target(this);
            var mode = $(this).data('mode');

            target.setLoading(mode);

            if ($(this).data('unload-on') && !$(this).data('unload-handler-attached')) {
                $(this).on($(this).data('unload-on'), function(){
                    target.unsetLoading(mode);
                });
                $(this).data('unload-handler-attached', true);
            }
        });

        dngActions.registerHandler('[data-dng-action="autoselect"]', 'click', function (event)
        {
            event.preventDefault();
            dngActions.target(this).focus().select();
        });

        //Register updaters
        dngUpdaters.registerUpdater('updateSelectElement', function(data, element, options)
        {
            if (typeof options === 'undefined'){
                options = {
                    emptyOnLoad: true,
                    addEmptyElement: true
                };
            }
            element = $(element);
            if (typeof options.emptyOnLoad !== 'undefined' && options.emptyOnLoad)
                element.empty();

            if (typeof options.addEmptyElement !== 'undefined' && options.addEmptyElement) {
                element.append('<option value="">---</option>');
            }

            if (typeof options.firstElements !== 'undefined') {
                for(var index in options.firstElements) {
                    element.append('<option value="'+index+'">'+options.firstElements[index]+'</option>');
                }
            }

            for(var index in data) {
                element.append('<option value="'+index+'">'+data[index]+'</option>');
            }
        });
    });

    dngActions.updaters = dngUpdaters;

    return dngActions;
});