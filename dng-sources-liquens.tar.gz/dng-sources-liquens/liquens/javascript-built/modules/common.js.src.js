/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
define(["jquery", "jquery-placeholder", "bootstrap", "modules/jquery-plugins", "footable", "covers-carousel"],
	function ($) {

		var dng = {
			/**
			 * Display a feedback message under the navigation bar.
			 *
			 * @param message
			 * @param type (success, alert, info, danger, error)
			 */
			feedbackMessage: function(message, type, disappearDelay) {
				disappearDelay = disappearDelay || (type == 'danger' || type == 'warning') ? 0 : 4000;

				var args = {};

				if (message) {
					args.message = message;
					args.type = type;
				}

				$.get('data/html/message', args).done(function(html) {
					var animationTime = 500;

					if($.trim(html)) {
						var feedback = $('#feedback');
						var newAlert = $.parseHTMLNode(html).hide();
						var existingAlerts = feedback.find('.alert');

						if (existingAlerts.length > 0) {
							// conclude immediatly delayed animations
							existingAlerts.stop(false, false);
							existingAlerts.remove();
						}

						feedback.append(newAlert);
						newAlert.slideDown(animationTime).css('display', 'inline-block');

						if (disappearDelay > 0)
							newAlert.delay(disappearDelay).slideUp(animationTime);
					}
				});
			},

			persistentFeedbackMessage: function(message, type) {
				return this.feedbackMessage(message, type, 0);
			},

			scrollAndOpenPanel: function(panelSelector) {
				var panel = $(panelSelector);
				if (panel.length) {
					if (panel.hasClass('collapse')) panel.collapse('show');
					var heading = panel.closest('.panel').find('.panel-heading');
					if (heading.length)
						heading.scrollTo();
				}
			}
		};

		$(document).ready(function () {
			// IE <= 8 Fix for checkboxes inside labels (see http://stackoverflow.com/questions/10964966/detect-ie-version-in-javascript#10965073)
			if (window.attachEvent && !window.addEventListener) {
				$('body').on('click', 'label', function(e) {
					var checkbox = $(this).find('input[type="checkbox"]');
					if (checkbox.length) {
						checkbox.prop('checked', !checkbox.prop('checked'));
						checkbox.trigger('change');
					}
				});

				// Put input-checked class on checkboxes and radios. This is used in css
				// to solve the missing :checked selector in IE <= 8
				$('input:checked').addClass('input-checked');

				$('body').on('change', 'input[type="radio"],input[type="checkbox"]', function() {
					var $this = $(this);
					$this.closest('form').find('input[name="' + $this.attr('name') + '"]').removeClass('input-checked');
					$this[$this.prop('checked') ? 'addClass' : 'removeClass']('input-checked');
				});
			}

			// Semantic events handlers
			$('body').on('loginmodal-requested', function() {
				$('#loginModal').modal('show');
			});

			// Dom-specific event handlers
			$('.user-unlogged .needs-login').on('click', function(e) {
				$(this).trigger('loginmodal-requested');
				e.stopImmediatePropagation();
				e.preventDefault();
			});

			$('body').on('shown.bs.tab', 'a[data-toggle="tab"]', function(event) {
				if (!Modernizr.history) return;
				var tabname = $(event.target).data('target').substr(1);
				window.history.replaceState({}, '', window.location.pathname + "#" + tabname);
			});

			/**
			 * Carousels
			 */
			$(".covers-carousel").coversCarousel();

			/**
			 * Refresh behaviour
			 */
			$('body').on('refresh', '[data-uri]', function() {
				var $this = $(this);
				var replace = $(this).data('replace') == undefined ? true : $(this).data('replace');

				//If a new refresh event is triggered for the element the old one should be ignored
				//To do that I track an id of the current refresh event, and then I check later if the id
				//is the last one
				var newRefreshId = ($this.data('currentRefreshId') || 0) + 1;
				$this.data('currentRefreshId', newRefreshId);

				$.get($this.data('uri')).done(function(response) {
					if ($this.data('currentRefreshId') != newRefreshId)
						return;
					var updatedElement = $this;
					if (replace) {
						updatedElement = $.parseHTMLNode(response);
						$this.replaceWith(updatedElement);
					} else {
						$this.html(response);
					}
					updatedElement.trigger('refreshed');
				});
			});

			//Item Notes
			$("body").on("mouseenter", ".item-notes", function() {
				if ($(this).data('popover'))
					return;

				var content = $(this).find("ul");

				$(this).popover({
					trigger: Modernizr.touch ? "click" : "hover",
					content: content.prop("outerHTML"),
					placement: "top",
					html: "true"
				});
				$(this).popover("show");
			});

			$('body').on('hidden.dng-api.modal', '.modal', function(){
				if ($(this).data('prev-modal')) {
					$(this).data('prev-modal').modal('show');
				}
			});

			$('body').on('hidden.dng-api.modal', '.modal', function() {
				if ($(this).data('showed-by')) {
					$(this).data('showed-by').trigger('modal-hidden', [$(this)]);
				}
			});

			$('body').on('click', '.modal .confirm-modal', function() {
				var showedBy = $(this).closest('.modal').data('showed-by');

				if (showedBy)
					showedBy.trigger('modal-confirmed', [$(this).closest('.modal')]);
			});

			//Bootstrap dropdown
			$('.dropdown-toggle').dropdown();

			//Bootstrap tooltips
			$('[data-toggle="tooltip"]').tooltip({
				trigger: Modernizr.touch ? "click" : "hover"
			});

			//Tooltip on actions that require log in
			$('.user-unlogged .needs-login').tooltip({
				trigger:  Modernizr.touch ? "click" : "hover",
				title: $('body').data('needs-login-msg')
			});

			// Bind toggle to offcanvas
			$('body').on('click', '[data-toggle="offcanvas"]', function() {
				$('.row-offcanvas').toggleClass('active');
			});

			//Open tab by hash tag
			var urlHash =  window.location.hash.substr(1);

			if (urlHash) {
				$('[data-target="#' + urlHash + '"],[href="#' + urlHash + '"]').tab('show');
				var panel = dng.scrollAndOpenPanel('#' + urlHash);
			}

			//Placeholders for ie
			$('input[placeholder]').placeholder();

			// Foo tables
			$('.footable').footable();
		});

		return dng;
	});