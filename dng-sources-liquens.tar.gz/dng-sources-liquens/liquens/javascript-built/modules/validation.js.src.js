/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

define(["jquery", "jquery-validation"], function ($) {

    $.validator.addMethod("equalToByName", function(value, element, name) {
        var value2 = jQuery(element).closest('form').find('*[name=' + name + ']').val();
        return this.optional(element) || value == value2;
    }, "Values must be equal");
    
    $.validator.addMethod("alphanumeric", function(value, element){
        return this.optional(element) || /^[a-zA-Z0-9_\-]*$/.test(value);
    }, "Value must be alphanumeric");
    
    $.validator.addMethod("italianDate", function(value, element){
        return this.optional(element) || /^(([1-9])|(0[1-9])|([1-2]\d)|(3[0-1]))\/((0[1-9])|(1[0-2])|([1-9]))\/(\d\d\d\d)$/.test(value);
    }, "Date must be a valid date of the format dd/mm/yyyy");
    
    $.validator.addMethod("conditionalValidation", function(value, element, options) {
    
        var value2 = jQuery(element).closest('form').find('*[name=' + options.referringField + ']').val();
        var valid = true;
    
        //If there exists a rule set for that value...
        if (typeof options.rulesMap[value2] != 'undefined'){
            var rules = options.rulesMap[value2];
    
            //If it is not ana array I transform it
            if (typeof rules != 'Array'){
                var ary = {};
                ary[rules] = true;
                rules = ary;
            }
    
            for (var rulename in rules){
                var ruleoptions = rules[rulename];
                if (typeof $.validator.methods[rulename] != 'undefined'){
                    //the meaning of this must remain the same
                    if (!$.validator.methods[rulename].call(this, value, element, ruleoptions))
                        valid = false;
                }
            }
            return valid;
        }
    
        return valid;
    }, "Invalid data");
});