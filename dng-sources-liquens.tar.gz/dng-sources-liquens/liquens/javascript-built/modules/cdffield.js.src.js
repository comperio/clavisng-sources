/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
define(["jquery", "dng-common", "dng-actions"], function($, dng, actions){
    $(document).ready(function(){
        $("body").on("change", ".cdf_field, .cdf_subfield, .cdf_position, cdf_value", cdfFieldChange);
    });

    var cdfLevels = ['field', 'subfield', 'position', 'value'];

    function cdfFieldChange()
    {
        var isEmpty = $(this).val() == '';

        nextFields($(this)).each(function(index){
            var label = (index === 0 && !isEmpty) ? 'Loading...' : '---';
            $(this).empty();
            $(this).attr("disabled", "disabled");
            if ($(this).prop('tagName') == 'SELECT')
                $(this).append($('<option value="">' + label + '</option>'));
            $(this).closest('.cdfInput').addClass('loading');
        });

        if (!isEmpty) {
            var values = valuesChain($(this));
            var updater = actions.updaters.getUpdater('updateSelectElement');
            var nextCdfField = nextField($(this));

            jQuery.ajax({
                url: 'data/json/cdf/' + values.join('/'),
                dataType: 'json',
                success: function ( data ) {
                    var firstElements = {};

                    //if there is only an entry which key is empty, consider it as a text field
                    var count = 0;
                    for (var k in data) {
                        if (data.hasOwnProperty(k)) {
                           data[k]+= ' (' + k + ')';
                           ++count;
                        }
                    }

                    if (count == 1 && data.hasOwnProperty('')) {
                        if (nextCdfField.attr('type') !== 'text') {
                            nextCdfField = toggleValueElement(nextCdfField);
                        }
                     } else {
                        if (nextCdfField.attr('type') === 'text') {
                            nextCdfField = toggleValueElement(nextCdfField);
                        }
                        updater(data, nextCdfField, {addEmptyElement: false, emptyOnLoad: true, firstElements: firstElements});
                    }

                    nextCdfField.closest('.cdfInput').removeClass('loading');

                    nextCdfField.removeAttr('disabled');
                    nextCdfField.trigger("change");

                    if (count === 1 && !data.hasOwnProperty('')) {
                        nextCdfField.addClass('oneChoice');
                    } else {
                        nextCdfField.removeClass('oneChoice');
                    }
                }
            });
        }
    }

    function requestCdfMap(changedElement, field, subfield, position, value)
    {
        var args = [];

        if (typeof field !== 'undefined')
            args.push(field);

        if (typeof subfield !== 'undefined') {
            args.push(subfield);
            element.append('<option value="">---</option>');
        }

        if (typeof position !== 'undefined')
            args.push(position);

        if (typeof value !== 'undefined')
            args.push(value);

        var updater = actions.updaters.getUpdater('updateSelectElement');
        jQuery.ajax({
            url: 'data/json/cdf/' + args.join(),
            dataType: 'json',
            success: function ( data ) {
                var firstElements = {};
                firstElements[fieldname] = '---';
                updater(data, subfieldsDropdown, {addEmptyElement: false, emptyOnLoad: true, firstElements: firstElements});
                subfieldsDropdown.removeAttr('disabled');
            }
        });
    }

    function emptyAndDisable(element)
    {
        element.empty().attr("disabled", "disabled");
    }

    function container(element)
    {
        return $(element).closest('.cdfFields');
    }

    function nextFields(element)
    {
        var elements = [];
        for(var i = 1 + $.inArray($(element).attr('cdf_level'), cdfLevels); i < cdfLevels.length; i++) {
            var nextElement = container(element).find('*[cdf_level=' + cdfLevels[i] + ']:not(.disabled)');

            elements.push(nextElement);
        }

        return $(elements);
    }

    function prevFields(element)
    {
        var elements = [];
        //var currIndex = cdfLevels.indexOf($(element).attr('cdf_level'));
        var currIndex = $.inArray($(element).attr('cdf_level'), cdfLevels);

        for(var i = 0; i <= currIndex; i++) {
            var nextElement = container(element).find('*[cdf_level=' + cdfLevels[i] + ']:not(.disabled)');

            elements.push(nextElement);
        }

        return $(elements);
    }

    function nextField(element, n)
    {
        if (typeof n === 'undefined') {
            n = 1;
        }

        return nextFields(element)[n - 1];
    }

    function valuesChain(element)
    {
        var values = [];

        prevFields(element).each(function(){
            values.push($(this).val());
        });

        return values;
    }

    /**
     * Replace a select with a text input field, and put the old select
     * in 'select' metadata
     *
     * @param selectElement
     * @return {*|jQuery|HTMLElement}
     */
    function toggleValueElement(activeElement)
    {
        var otherElement = $(activeElement).closest('.cdf_subfield_wrapper').find('.disabled');
        otherElement.removeAttr('disabled').removeClass('disabled');
        activeElement.addClass('disabled').attr('disabled', 'disabled');

        return otherElement;
    }
});