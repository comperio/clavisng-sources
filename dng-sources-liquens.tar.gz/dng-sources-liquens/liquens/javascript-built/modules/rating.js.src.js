/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */
define(["jquery", "dng-common"], function($)
{
    var lqRating = {
        /**
         * Returns the url to perform rating/unrating actions
         *
         * @param type
         * @param ratedType
         * @param ratedId
         * @param value
         *
         * @return string
         */
        getActionUrl: function(type, ratedType, ratedId, value)
        {
            if (value === null)
                return 'rating/unrate/' + type + '/' + ratedType + '/' + ratedId;
            else
                return 'rating/rate/' + type + '/'
                    + ratedType + '/' + ratedId + '/' + value;
        },

        /**
         * Retrieves the manifestation id from the dom
         *
         * @return string
         */
        getManId: function(link){
            return $(link).data('manid');
        }
    };

    $(document).ready(function() {
        // Dom events to semantic events
        $('body').on('change', 'input[name="rating"]', function() {
            var manId = $(this).closestData('manid'); console.log($(this).val());
            $(this).trigger('rating-update-requested', [manId, $(this).val() == '' ? null : $(this).val()]);
            $(this).closest('[data-score]').attr('data-score', $(this).val());
        });

        $('body').on('rating-update-requested', function(event, manid, score) {
            var url = lqRating.getActionUrl('star', 'Manifestation', manid, score);

            $.ajax(url).done(function() {
                $(event.target).trigger('rating-updated', [manid, score]);
            });
        });

        $('body').on('rating-updated', function(event, manid, score) {
            $('[data-manid="' + manid + '"] .title-rates .avg-rate').trigger('refresh');
        });

        $('body').on('comment-created', function(event, manid) {
            $('[data-manid="' + manid + '"] .title-rates .comments').trigger('refresh');
            $('[data-manid="' + manid + '"] .comments-count').increase();
        });

        // Fix for ie <= 8 and label position (ie 8 wants label to appear after inputs)
        if (window.attachEvent && !window.addEventListener) $('body').on('click', '#rating-form label', function() {
            var input = $(this).closest('form').find('#' + $(this).prop('for'));
            input.prop('checked', !input.prop('checked'));
            input.trigger('change');
        });
    });
});