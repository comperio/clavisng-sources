/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

/**
 * This module defines event handlers for semantiv events related to shelves and saved searches
 */
define(["jquery", "dng-common"], function($, dng) {

    $(document).ready(function()
    {
        /**
         * Adding or removing an item from a shelf
         * Trigger a shelf-updated event when done
         */
        $('body').on('shelf-update-request', function(event, shelfid, manifestationid, state)
        {
            var actionUrl = state ? 'shelf/add/' : 'shelf/remove/';

            actionUrl = actionUrl + manifestationid + '/' + shelfid;

            $.get(actionUrl).always(function(){
                $(event.target).trigger('shelf-updated', [shelfid, manifestationid, state]);
            });
        });

        /**
         * Shelf creation
         * Trigger a shelves-updated and a shelf-created event
         */
        $('body').on('shelf-edit-request', function(event, id, name, description, visibility)
        {
            $.post('shelf/edit/' + id, {name: name, description: description, visibility: visibility})
                .done(function(data){
                    $(event.target).trigger('shelves-updated', [{id: data.ShelfID}]);
                    if (parseInt(id) == 0) {
                        $(event.target).trigger('shelf-created', data.ShelfID);
                    }
                });
        });

        /**
         * Visibility changing for shelves
         * Trigger a shelves-updated event
         */
        $('body').on('shelf-change-visibility-requested', function(event, shelfid, visibility){
            $.get('shelf/changevisibility/' + shelfid + '/' + visibility).done(function(){
                $(event.target).trigger('shelves-updated', [{id: shelfid}]);
            }) ;
        });

        /**
         * Empty a shelf
         * Trigger a shelves-updated event
         */
        $('body').on('shelf-empty-requested', function(event, shelfid){
            $.post('shelf/empty/' + shelfid)
                .done(function(){ $(event.target).trigger('shelves-updated', [{id: shelfid}]); });
        });

        /**
         * Shelf or saved search deletion.
         * Trigger a shelves-updated event
         */
        $('body').on('shelf-delete-requested', function(event, shelfid){
            $.post('shelf/delete/'+ shelfid)
                .done(function() { $(event.target).trigger('shelves-updated', [{id: shelfid}]); });
        });

        $('body').on('search-delete-requested', function(event, shelfid){
            $.post('shelf/deletes/'+ shelfid)
                .done(function() { $(event.target).trigger('searches-updated', [{id: shelfid}]); });
        });

        //Saved searches

        /**
         * Search saving
         * Trigger a searches-updated event
         */
        $('body').on('save-search-request', function(event, args)
        {
            $.post('shelf/savesearch', args)
                .done(function(data){
                    $('body').trigger('searches-updated');
                });
        });

        /**
         * Feedback message for searches-updated event
         */
        $('body').on('searches-updated', function(){
            dng.feedbackMessage(false, false, 10000);
        });

        /**
         * Request a contact edit/add dialog
         * Trigger a shelf-dialog-loaded event
         */
        $('body').on('shelf-dialog-requested', function(event, shelfId) {
            $.get('shelf/shelf-dialog/' + shelfId)
                .done(function(response) {
                    $.parseHTMLNode(response).modal('show');
                    $(event.target).trigger('shelf-dialog-loaded');
                });
        });

        /**
         * Request a contact edit/add dialog
         * Trigger a search-dialog-loaded
         */
        $('body').on('search-dialog-requested', function(event, data) {
            $.get('shelf/search-dialog', data)
                .done(function(response) {
                    $.parseHTMLNode(response).modal('show');
                    $(event.target).trigger('search-dialog-loaded');
                });
        });
        
        /**
         * Click su link per replicare lo scaffale pubblico di un utente
         */
        $('body').on('click', '.shelfReplicate', function() {
            var ID = parseInt($(this).attr('id'));
            $.ajax({
                url: 'userpublicshelf/replicate/',
                data: { shelfID: ID },
                dataType: 'json',
                success: function(response) {}
            });
            location.reload();
        });
        
        /**
         * Click su link per replicare la ricerca pubblica di un utente
         */
        $('body').on('click', '.searchReplicate', function() {
            var ID = parseInt($(this).attr('id'));
            $.ajax({
                url: 'userpublicsearch/replicate/',
                data: { searchID: ID },
                dataType: 'json',
                success: function(response) {}
            });
            location.reload();
        });
    });

});