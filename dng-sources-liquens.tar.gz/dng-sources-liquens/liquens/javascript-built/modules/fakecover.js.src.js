/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

define(["jquery"], function($) {
    /**
     *
     * @param coverLink The img element of the original cover
     * @param wrapperClass This must be the class of a html element that contains
     *   both the orginal and the fake cover.
     */
   function substituteCover(coverLink, wrapperClass) {

       if (typeof(wrapperClass) == 'undefined')
           wrapperClass = 'cover-wrapper';

       var coverImg = $(coverLink).find('img');

       var spanHeight = $(wrapperClass).height();

       $("<img/>") // Make in memory copy of image to avoid css issues
           .bind('load error', function()
           {
               //Not available cover has 1x1 dimensions
               if ((1 == this.width && 1 == this.height) ||
                   !this.width || !this.height ){
                   var fakecover = $(coverImg).closest('.' + wrapperClass).find('.fake-cover')[0];
                   $(coverLink).empty().addClass('fake-covered').append(fakecover);
                   $(fakecover).show();
               }
               //If it is a normal cover I adjust with to take into account the border width
               else {
                   $(coverLink).addClass('cover-loaded');
                   var overlay = $(coverLink).find('.adjust-size');
                   var element = $(overlay);
                   element.show();

                   $(coverLink).siblings('.fake-cover').remove();
               }
               $(coverLink).trigger("completedFakeCoversLoading");
           })
           .attr("src", $(coverImg).attr("src"));
   }

    $(document).ready(function(){

       $('.cover').each(function(index, coverLink){
            substituteCover(coverLink);
       });
       

       /*$('.adjust-size').each(function(index, element){
           element = $(element);
           element.show();
           element.width(element.width() - element.outerWidth() + element.innerWidth());
           element.height(element.height() - element.outerHeight() + element.innerHeight());
       });*/
    });
});

