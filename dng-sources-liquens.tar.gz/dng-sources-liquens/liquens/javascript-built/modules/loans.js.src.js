/**
 * This file is part of DNG
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @author Nicolò Martini <nicmartnic@gmail.com>
 */

define(["jquery", "dng-common"], function($, dng) {
    $(document).ready(function(){

        /**
         * Renew a loan
         * Trigger a loans-active-updated event
         */
        $('body').on('loan-renew-requested', function(event, itemId){
            $.post('mydiscovery/renewLoan', {id: itemId}).done(function(){
                $(event.target).trigger('loans-active-updated', [{id: itemId}]);
            });
        });

        /**
         * Renew an extra loan
         * Trigger a loans-active-updated event
         */
        $('body').on('loan-renewextra-requested', function(event, itemId){
            $.post('mydiscovery/renewExtra', {id: itemId}).done(function(){
                $(event.target).trigger('loans-active-updated', [{id: itemId}]);
            });
        });
    });
});