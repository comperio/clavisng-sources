<?php
/**
 * LastSeenPortlet class file
 *
 * @author Dario Rigolin <dario@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @copyright Copyright &copy; 2011 Comperio srl
 * @version 2.7
 * @package Widgets
 * @since 2.0
 */

Prado::using('Application.Portlets.ClavisPortlet');

class LastSeenPortlet extends ClavisPortlet
{
	public function onLoad($param)
	{
		parent::onLoad($param);

		$this->populate();
	}
	
	public function populate()
	{
		$user = $this->getApplication()->getUser();
		$userId = $user->getId();
		
		////$this->LibraryLabel->setCssClass($user->getActualLibraryId() == $user->getDefaultLibraryId() ? 'librarylabel' : 'librarylabel_evidenced');
		$librarianNameLabel = $user->getCompleteName(40);
		$librarianProfileLabel = $user->getProfileLabel();
		
		$extendedLibrarianNameLabel = $librarianNameLabel
										. ($librarianProfileLabel == '' ? '' : '&nbsp;[' . $librarianProfileLabel . ']');
		
		$librarianNavigateUrl = $this->getService()->constructUrl(	'Library.LibrarianViewPage',
																	array('id' => $userId));

		$libraryLabel = $user->getActualLibraryLabel();

		$libraryNavigateUrl = $this->getService()->constructUrl(	'Library.LibraryViewPage',
																	array('id' => $user->getActualLibraryId()));
		
		$this->LibrarianSessionWidget->setText($librarianNameLabel);
		$this->LibrarianSessionWidget->setNavigateUrl(null); //$librarianNavigateUrl);
		
		$OLText = Prado::localize("operatore") . ":&nbsp;<a href='$librarianNavigateUrl'>$extendedLibrarianNameLabel</a>"
					. ($user->getIsSuperAdmin() ? '<br />***' . ClavisLibrarian::SUPERADMIN_LABEL . '***' : '')
					. "<br /><br />" . Prado::localize("biblioteca") . ":&nbsp;<a href='$libraryNavigateUrl'>$libraryLabel</a>";
		
		if (!is_null($userShelfId = $this->getUser()->getActualShelfId()))
		{
			$OLText .= "<br /><br />" . Prado::localize("Scaffale preferito: '{scaff}' (id={id})",
								array(	'id' => $userShelfId,
										'scaff' => ShelfPeer::getShelfName($userShelfId) ));
		}
		
		if ($this->getApplication()->getMode() == 'Debug')
		{
			$OLText .= "<br /><br /><br />DB: " . Clavis::getDBString();
			
			if (LLibraryPeer::isEnabled())
				$OLText .= "<br /><br />" . Prado::localize("Circolazione A BACINI");
		}
		
		$this->LibrarianSessionWidget->setOLText($OLText);		
	}
	
	public function Search($sender, $param)
	{

	}

	public function onRedoAcl($sender, $param)
	{
		$user = Prado::getApplication()->getUser();
		$userId = $user->getID();
		$librarian = LibrarianPeer::retrieveByPK($userId);

		$newAcl = $librarian->getAuthPages();

		$user->setAuthPages($newAcl);
		$user->saveToString();
	}

	public function teleport($sender, $param)
	{
		$this->getPage()->returnPage();
	}

}