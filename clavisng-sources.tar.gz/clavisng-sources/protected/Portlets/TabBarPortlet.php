<?php
/**
 * TabBarPortlet class
 *
 * @author Dario Rigolin <dario@comperio.it>
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @copyright Copyright &copy; 2011 Comperio srl
 * @version 2.7
 * @package Widgets
 * @since 2.0
 */

Prado::using('Application.Portlets.ClavisPortlet');

class TabBarPortlet extends ClavisPortlet
{
	public function onLoad($param)
	{
		parent::onLoad($param);
		
		$actualModule = $this->getPage()->getClavisModule();
		$modules = $this->getUser()->getAllowedModules();
		if (count($modules) > 0)
		{
			$data = array();
			foreach ($modules as $key => $module)
			{
				$tab = $module;
				if ($key == $actualModule)
					$tab['cssclass'] = 'currenttab';
				$data[] = $tab;
			}

			$this->TabMenu->setDataSource($data);
			$this->TabMenu->DataBind();
		}
	}

	public function logoutClick($sender, $param)
	{
		$currentSession = $this->getUser()->getLibrarianSession();
		if(!is_null($currentSession)) {
			$currentSession->setEndDate('now');
			$currentSession->save();
		}
		//logout
		$this->getApplication()->getModule('auth')->logout();
		$this->getResponse()->redirect($this->getService()->getDefaultPageUrl());
	}
}
