<?php

/**
 * SMSTrendModule - SMSTrend Prado Module
 *
 * A module for sending messages through SMSTrend SMS gateway.
 *
 * Example of use:
 * => in your application.xml:
 * ===
 * <module id="sms" class="SMSTrendModule"
 * 		AuthUser="foo" AuthPassword="TheGreatSecret"
 * 		Sender="ADearSender" />
 * <!-- sender can be a 11 alphanumeric char string (like "abcdef12345" or a
 * 16 numeric char string (like "+123456789012345") -->
 * ===
 * => in your PHP code:
 * ===
 * 		$m = $this->Application->getModule('sms');
 * 		$m->setReceiver('+393494080985');
 * 		/* or $m->setReceiver(array('+393494080985','+393477232652'));
 * 		$m->setSender('ADearSender');	// overrides the one in application.xml
 * 		$m->setMessage('Hello! You should know that I\'m watching you. Better you watch'.
 * 			' your back. Bad thing if you call the police. Be warned. Bye.');
 * 		$m->sendMessage();
 * ===
 *
 * TODO: more error checking, especially in receiver field.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2008 Ciro Mattia Gonano
 * @version 2.7
 * @license MIT (http://www.opensource.org/licenses/mit-license.html)
 *
 * Copyright (c) 2008 Ciro Mattia Gonano
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
class SMSTrendModule extends SMSDummyModule {

    const SMSTREND_URL = 'api.trendoo.net';
    const SMSTREND_DATETIMEFMT = '%Y%m%d%H%M%S';
    const SMSTREND_SEPARATOR = '|';
    const SMSTREND_NEWLINE = ';';

    private $_authuser = '';
    private $_authpassword = '';
    private $_sender = '';
    private $_receiver;
    private $_dateforsend = null;
    private $_message;

    private function post($queryurl, Array $fields = array()) {
        $fields['login'] = $this->getAuthUser();
        $fields['password'] = $this->getAuthPassword();
        $postdata = http_build_query($fields);
        $opts = array('http' =>
            array(
                'method' => 'POST',
                'header' => 'Content-type: application/x-www-form-urlencoded',
                'content' => $postdata
            )
        );
        $context = stream_context_create($opts);
        $response = file_get_contents('http://' . self::SMSTREND_URL . $queryurl, false, $context);
        return $this->parse_response($response);
    }

    private function parse_response($response) {
        if (strlen($response) >= 2) {
            $ret = array(
                'isok' => false,
                'phrases' => array());
            $code = substr($response, 0, 2);
            if ('OK' == $code) {
                $ret['isok'] = true;
                $tokens = explode(self::SMSTREND_NEWLINE, substr($response, 3));
                foreach ($tokens as $tok)
                    if (trim($tok))
                        $ret['phrases'][] = explode(self::SMSTREND_SEPARATOR, $tok);
            } else if ('KO' == $code) {
                $tokens = explode(self::SMSTREND_SEPARATOR, substr($response, 3));
                $ret['isok'] = false;
                $ret['errcode'] = intval($tokens[0]);
                $ret['errmsg'] = $tokens[1];
            } else {
                Prado::log($code . '---' . Prado::varDump($tokens));
                $ret['isok'] = false;
                $ret['errcode'] = -1;
                $ret['errmsg'] = 'Error in SMSTrendModule, check log!!';
            }
        }
        return $ret;
    }

    /**
     * Check auth correctness.
     *
     * @return boolean
     */
    public function checkAuth() {
        $url = '/Trend/CREDITS';
        $response = $this->post($url);
        return $response['isok'];
    }

    /**
     * Send a message through SMS.
     *
     * @return mixed The RequestID if sending was successful, false elsewhere
     */
    public function sendMessage($requestID = null)
    {
	$result = array("status" => "OK", "errors" => array(), "data" => array());
        try
        {
            $receiver = $this->getReceiver();
            $msgIds = explode("|", $requestID);
            if(is_array($msgIds) && count($msgIds) == 3)
            {
                $nId = $msgIds[2];
                $n = NotificationQuery::create()->findOneByNotificationId($nId);
                if($n instanceof Notification)
                {
                    $notes=array("backend"=>"trendoo", "smsid" => $requestID, "notificationid"=>$nId);
                    $n->setNotes(  serialize( $notes ));
                    $n->save();

                    /* This is commented because receiver should not be an array... ?!?
                    if (is_array($receiver))
                        $receiver = implode(',', $receiver);
                    $receiver = preg_replace('/[^+\d,]/', '', $receiver);
                    */
                    $url = '/Trend/SENDSMS';
                    $data = array(
                        'message_type' => 'GP',
                        'sender' => $this->getSender(),
                        'order_id' => $requestID,
                        'recipient' => $receiver,
                        'message' => $this->getMessage());
                    /*
                     * strftime/strtotime trick is here to allow passing date in any format understood
                     * by strtotime, while passing it in the format specified by SMSTrend API.
                     * Think about it, before changing :)
                     */
                    $dateforsend = $this->getDateForSend();
                    if ($dateforsend) {
                        if (!is_int($dateforsend))
                            $dateforsend = strtotime($dateforsend);
                        $data['scheduled_delivery_time'] = strftime(self::SMSTREND_DATETIMEFMT, $dateforsend);
                    }
                    $response = $this->post($url, $data);
                    if ( ! $response['isok'] ) 
                    {
                        $result["status"] = "KO";
                        Prado::log( __METHOD__ . " ERROR:");
                        Prado::log(Prado::varDump($response));
                    }
                }
                else
                {
                    $emsg = __METHOD__ . " LINE " .__LINE__. " ERROR: invalid request ID ".$requestID." I cannot save message id to notification.";
                    Prado::log($emsg);
                    $result['status']='KO';
                    $result['errors'][]=$emsg;
                }
            }
            else
            {
                $emsg = __METHOD__ . " LINE " .__LINE__. " ERROR: invalid request ID ".$requestID." I cannot save message id to notification.";
                Prado::log($emsg);
                $result['status']='KO';
                $result['errors'][]=$emsg;
            }
        } catch (Exception $ex) {
            $exmsg = $ex->getMessage();
            Prado::log( __METHOD__ . " ERR: {$exmsg}" );
            $result[ "status" ] = "KO";
            $result[ "errors" ][] = "Exception {$exmsg}";
            return $result;
        }
        return $result;	
    }

    /**
     * Checks message status, given Request ID.
     *
     * @param string $requestID The Request ID.
     * @return mixed An array with status parameters
     */
    public function checkStatus() 
    {
        $ret = FALSE;
        try
        {
            $n = NotificationQuery::create()
                ->filterByNotificationChannel(NotificationPeer::CHANNEL_SMS)
                ->filterByNotificationState(NotificationPeer::STATUS_PENDING)
                ->find();
            foreach ($n as $notification)
            {
                $notes = unserialize($notification->getNotes());
                if (is_array($notes) && array_key_exists('smsid',$notes)) 
                {
                    if(  !array_key_exists( 'backend', $notes ) || $notes['backend']!='trendoo')
                    {
                        continue;
                    }
                    $keys = array('to', 'status', 'ack_date');
                    $url = '/Trend/SMSSTATUS';
                    $data = array(
                        'order_id' => $notes['smsid']);
                    $response = $this->post($url, $data);
                    if ($response['isok']) 
                    {
                        $ret = array();
                        foreach ($response['phrases'] as $phrase) 
                        {
                            $reply = array_combine($keys, $phrase);
                            /*
                              SCHEDULED // posticipato, non ancora inviato
                              SENT // inviato, non attende delivery
                              DLVRD // l'SMS è stato correttamente ricevuto
                              ERROR // errore nella consegna dell'SMS (Es. numero non esistente)
                              TIMEOUT // l'operatore non ha fornito informazioni sull'SMS entro 48 ore
                              TOOM4NUM // troppi SMS per lo stesso destinatario nelle ultime 24 ore
                              TOOM4USER // troppi SMS inviati dall'utente nelle ultime 24 ore
                              UNKNPFX // prefisso SMS non valido o sconosciuto
                              UNKNRCPT // numero di telefono del destinatario non valido o sconosciuto
                              WAIT4DLVR // messaggio inviato, in attesa di delivery
                              WAITING // in attesa, non ancora inviato
                              UNKNOWN
                             */
                            switch ($reply['status']) 
                            {
                                case 'SCHEDULED':
                                case 'WAITING':
                                    //$notification->setNotificationState( NotificationPeer::STATUS_PENDING );
                                    break;
                                case 'SENT':
                                case 'WAIT4DLVR':
                                    //$notification->setNotificationState( NotificationPeer::STATUS_SENT );
                                    break;
                                case 'DLVRD':
                                    $notification->setNotificationState( NotificationPeer::STATUS_DELIVERED );
                                    $acpt = $reply['ack_date'];
                                    $acptDt = DateTime::createFromFormat('YmdHis', $acpt);
                                    $notification->setAcknowledgeDate( $acptDt );
                                    $notification->save();
                                    break;
                                case 'ERROR':
                                case 'TOOM4NUM':
                                case 'TOOM4USER':
                                case 'TIMEOUT':
                                    $notification->setNotificationState( NotificationPeer::STATUS_ERROR );
                                    $notification->save();
                                    break;
                                case 'UNKNPFX': 
                                case 'UNKNRCPT':
                                    /* Wrong number. Reply:
                                    array
                                    (
                                        [isok] => true
                                        [phrases] => array
                                        (
                                            [0] => array
                                            (
                                                [0] => '%2B391112233456'
                                                [1] => 'UNKNPFX'
                                                [2] => ''
                                            )
                                        )
                                    )
                                    */

                                    
                                    //Try to set contact as wrong
                                    $to = urldecode($reply['to']);
                                    Contact::setWrongMobileNumber($notification->getObjectId(), $to);
									
				    $notification->setNotificationState( NotificationPeer::STATUS_ERROR );
                                    $notification->save();
                                    break;
                                case 'UNKNOWN':
                                    //$notification->setNotificationState( NotificationPeer::STATUS_UNKNOWN );
                                    break;
                            }
                        }

                        //Prado::log(Prado::varDump($response));
                        
                    }
                    else 
                    {
                        Prado::log(Prado::varDump($response));
                    }
                }//if notes...
            }//foreach
            $ret = TRUE;
        } catch (Exception $ex) {
            Prado::log(__METHOD__ . " EXCEPTION " . $ex->getMessage());
        }
        return $ret;
    }

    public function getHistory($date_from, $date_to) {
        if (intval($date_from) != $date_from)
            $date_from = strtotime($date_from);
        if (intval($date_to) != $date_to)
            $date_to = strtotime($date_to);
        $data = array(
            'from' => strftime(self::SMSTREND_DATETIMEFMT, $date_from),
            'to' => strftime(self::SMSTREND_DATETIMEFMT, $date_to)
        );
        $response = $this->post('/Trend/SMSHISTORY', $data);
        if ($response['isok']) {
            $ret = array();
            foreach ($response['phrases'] as $phrase) {
                $ret[] = array(
                    'order_id' => intval($phrase[0]),
                    'create_time' => self::smsDateToTimestamp($phrase[1]),
                    'sms_type' => urldecode($phrase[2]),
                    'sender' => urldecode($phrase[3]),
                    'recipients_count' => intval($phrase[4]),
                    'scheduled_send' => self::smsDateToTimestamp($phrase[5])
                );
            }
            return $ret;
        }
        return array();
    }

    public static function smsDateToTimestamp($smstrend_date) {
        $res = strptime($smstrend_date, self::SMSTREND_DATETIMEFMT);
        if ($res != false) {
            return mktime($res['tm_hour'], $res['tm_min'], $res['tm_sec'], $res['tm_mon'] + 1, $res['tm_mday'], $res['tm_year'] + 1900);
        } else {
            return null;
        }
    }

    public function subAccountAmount() {
        $data = array(
            'subaccount' => $this->getAuthUser()
        );
        $response = $this->post('/Trend/CREDITS', $data);
        if ($response['isok']) {
            return $response;
        }
        return false;
    }


    /**
     * Sets the sender.
     *
     * @param string $value The sender, 11 alphanumeric chars or 16 numeric/+ chars.
     * /
    public function setSender($value) {
        $this->_sender = (preg_match('!\+?\d+!', $value)) ?
                substr($value, 0, 16) :
                substr($value, 0, 11);
    }*/



    /**
     * Returns the number of messages sent for the current message body
     *
     * @return int
     */
    public function getMsgNo() {
        $doublechars = array("€", "[", "]", "{", "}", "|", "\\", "^", "~");
        $smslen = strlen($this->getMessage());
        foreach ($doublechars as $c)
            $smslen += substr_count($this->getMessage(), $c);
        return ($smslen < 161) ? 1 : ceil($smslen / 153);
    }

}
