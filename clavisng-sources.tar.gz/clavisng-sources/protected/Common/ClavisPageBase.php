<?php
/**
 * ClavisPageBase class
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Dario Rigolin <dario@comperio.it>
 * @author Marco Brancalion <marco@comperio.it>
 * @author Ciro Mattia Gonano
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 */

/**
 * ClavisPageBase Class
 *
 * @author Dario Rigolin <dario@comperio.it>
 * @author Marco Brancalion <marco@comperio.it>
 * @author Ciro Mattia Gonano
 * @version 2.7
 * @package Core
 * @since 2.6
 */
class ClavisPageBase extends TPage
{
	const PageHistoryMaxSize = 10;

	public $_module = 'CORE';
	public $_isPopup = false;
	private $_enqueuedMessageBody = '';
	private $_enqueuedMessageType = null;

	private $_errorTypeMap = array(	ClavisMessage::ERROR	=> 5,
									ClavisMessage::WARNING	=> 4,
									ClavisMessage::INFO		=> 3,
									ClavisMessage::LOADING	=> 2,
									ClavisMessage::CONFIRM	=> 1 );

	public function onPreInit($param)
	{
		parent::onPreInit($param);

		$this->setTheme('Default');
		$globalization = $this->getApplication()->getGlobalization();
		$culture = $this->getApplication()->getSession()->itemAt('Culture');
		if (!$culture)
			$culture = 'it_IT';
		$globalization->setCulture($culture);
		setlocale(LC_TIME,$culture);
		$globalization->setCharset('UTF-8');
	}

	public function onLoad($param)
	{
		parent::onLoad($param);

		$this->checkAuth();
		$this->setTitle( $this->getPagePath() );
		/* set page history, but only if we aren't in postback */
		if (!$this->getIsPostBack() && !$this->getIsCallback()) {
			$this->setPageHistory();
		}
	}

	public function checkAuth($addedCheck = true, $force = null)
	{
		$page = $this->getPagePath();
		$isGuest = $this->getUser()->getIsGuest();

		if (!$isGuest && !$this->getUser()->getIsAdmin())
		{
			if (ClavisParamQuery::getParam('CLAVISPARAM','Maintenance') == 'true')
			{
				$currentSession = $this->getUser()->getLibrarianSession();
				if (!is_null($currentSession)) {
					$currentSession->setEndDate('now');
					$currentSession->save();
				}
				//logout
				$this->getApplication()->getModule('auth')->logout();
				$this->getResponse()->redirect($this->getService()->getDefaultPageUrl());
			}
			$allowed = TPropertyValue::ensureBoolean($this->getUser()->checkAllowedPage($page));
			if ($force !== true && (($allowed && $addedCheck) == false) || $force === false)
				$this->gotoPage('Error.NoAuth', array('module' => $this->_module));
		}
		//update session
		$currentSession = $this->getUser()->getLibrarianSession();
		if (!is_null($currentSession))
		{
			$currentSession->setLastActionDate('now');
			$currentSession->save();
		}

        if (extension_loaded('newrelic')) {
            $librarian = "{$this->getUser()->getCompleteName()} ({$this->getUser()->getId()})";
            $library = "{$this->getUser()->getActualLibraryLabel()} ({$this->getUser()->getActualLibraryId()})";
            newrelic_capture_params();
            newrelic_set_appname ("ClavisNG - " . $this->getApplication()->getID());
            newrelic_name_transaction($page);
            newrelic_set_user_attributes($librarian, $library, 'ClavisNG');
            newrelic_add_custom_parameter('Librarian', $librarian );
            newrelic_add_custom_parameter('Library', $library);
            if ($currentSession instanceof LibrarianSession)
                newrelic_add_custom_parameter('SessionId', $currentSession->getSessionIdString());
        }
	}

	/**
	 * Returns whether the page is a popup
	 *
	 * @return bool True if page is a popup, false elsewhere (false if not overriden).
	 */
	public function isPopup()
	{
		return $this->_isPopup;
	}

	/**
	 * Returns whether the page permits unlinking
	 *
	 * @return bool True if page permits unlinking, false elsewhere (false if not overriden).
	 */
	public function isUnlink()
	{
		return false;
	}

	/**
	 * Returns whether the page permits delete
	 *
	 * @return bool True if page permits deletion, false elsewhere (false if not overriden).
	 */
	public function isDelete()
	{
		return false;
	}

	/**
	 * Updates the pages history.
	 */
	protected function setPageHistory() 
	{
		$session = $this->getSession();
		$history = $session->itemAt('PageHistory');
		if (!$history) 
		{
			$session->add('PageHistory', array($this->getRequest()->getRequestUri()));
		} 
		else 
		{
			array_unshift($history,$this->getRequest()->getRequestUri());
			while (count($history) > self::PageHistoryMaxSize)
				array_pop($history);
			$session->add('PageHistory',$history);
		}
	}

	/**
	 * Redirects application to any previous page.
	 *
	 * @param integer $steps the number of steps to get back (defaults to 1).
	 */
	public function getBack($steps=1) 
	{
		$history = $this->getSession()->itemAt('PageHistory');
		if (!$history || count($history) < 2) 
		{
			$backurl = $this->getService()->constructUrl($this->getService()->getDefaultPage());
		} 
		else 
		{
			/* first element is always the page we're currently on */
			array_shift($history);
			do {
				$backurl = array_shift($history);
				if ($backurl===null) {
					$backurl = $this->getService()->constructUrl($this->getService()->getDefaultPage());
					$steps = 0;
				}
			} while (--$steps);
		}
		$this->getSession()->add('PageHistory',$history);
		$this->getResponse()->redirect($backurl);
	}

	public function gotoPage($pagePath, $getParameters = null)
	{
		$url = $this->getService()->constructUrl($pagePath, $getParameters, null, false);
		$this->getResponse()->redirect($url);
	}

	public function gotoPageWithReturn($pagePath, $getParameters = null)
	{
		$this->setReturnPageUrl($this->getRequest()->getRequestUri());
		$this->gotoPage($pagePath, $getParameters);
	}

	public function returnPage()
	{
		$urlString = $this->getReturnPageUrl();
		$this->resetReturnPage();
		if (!is_null($urlString))
			$this->getResponse()->redirect($urlString);
	}

	public function resetReturnPage()
	{
		$this->getApplication()->getSession()->add('PageReturn', null);
	}

	public function isReturnPageEnabled()
	{
		if ($this->getReturnPageUrl() == null)
			return false;
		else
			return true;
	}

	public function getReturnPageUrl()
	{
		$url = trim($this->getApplication()->getSession()->itemAt('PageReturn'));
		if ($url != '')
			return $url;
		else
			return null;
	}

	public function setReturnPageUrl($urlString = null)
	{
		if (is_null($urlString))
			$url = $this->getRequest()->getRequestUri();
		
		$this->getApplication()->getSession()->add('PageReturn', $urlString, null);
	}

	/**
	 * It reloads the same actual pages, with the same get parameters.
	 *
	 */
	public function reloadPage($addedParameters = array())
	{
		$this->getResponse()->redirect($this->getUrlPath() . $this->convertUrlParams($this->getUrlParams($addedParameters)));
	}

	/**
	 * It reloads the same actual pages, without the same get parameters.
	 */
	public function reloadPageWithoutParams()
	{
		$urlString = $this->getPagePath();
		$exploded = explode('&', $urlString);
		if (count($exploded) > 0)
			$this->getResponse()->redirect($this->getService()->constructUrl($exploded[0], null, false));
		else
			$this->getResponse()->reload();
	}

	public function getUrlParams($addedParameter = array())
	{
		$url = $this->getRequest()->getRequestUri();
		$exploded = explode('&', $url);
		if (isset($exploded[0]))
			unset($exploded[0]);

		$params = array();
		foreach ($exploded as $param)
		{
			$explodedParameter = explode('=', $param);
			if (count($explodedParameter) == 2)
			{
				$key = trim($explodedParameter[0]);
				$value = trim($explodedParameter[1]);

				if (($key != '') && ($value != ''))
					$params[$key] = $value;
			}
		}

		// passed added parameters
		foreach ($addedParameter as $index => $row)
			$params[$index] = $row;

		return $params;
	}

	public function getUrlPath()
	{
		$url = $this->getRequest()->getRequestUri();
		$exploded = explode('&', $url);
		if (isset($exploded[0]))
			return $exploded[0];
		else
			return null;
	}

	public function convertUrlParams($params = array())
	{
		$output = '';
		foreach ($params as $param => $value)
			$output .= '&' . $param . '='. $value;

		return $output;
	}

	public function reportError($errorCode)
	{
		$this->gotoPage('ErrorReport',array('id'=>$errorCode));
	}

	/**
	 * Returns the Clavis module code related to the page
	 * every Page extending the Clavis page needs to put the
	 * code into $_module public variable.
	 *
	 * @return unknown
	 * @throws Exception
	 */
	public function getClavisModule() 
	{
		if (is_null($this->_module))
			throw new Exception('Module is null!');
		return $this->_module;
	}

	/**
	 * @author Marco Brancalion <mbrancalion@e-portaltech.it>
	 *
	 * This is called when a button is pressed inside a repeatable
	 * control in the page.
	 * It discriminates if the CommandParameter is "add" o "subtract",
	 * in order to add or delete an item in the control, and calls the
	 * fitting method.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onItemEvent($sender, $param)
	{
		$command = $param->getCommandParameter();
		switch ($command)
		{
			case "add":
				$this->addItem($sender);
				break;
			case "subtract":
				$this->subtractItem($sender, $param->Item->ItemIndex);
			default:
				break;
		}
	}

	/**
	 * @author Marco Brancalion <mbrancalion@e-portaltech.it>
	 *
	 * This function uses the repeatable $comp passed as parameter for
	 * creating an datasource array by scanning all the values
	 * of the component in its item.
	 *
	 * The $exclude is an integer value which represents an eventual
	 * item number to delete from the resulting datasource.
	 * If it's not passed, no item gets deleted.
	 *
	 * @param TControl $comp
	 * @param int $exclude
	 * @return array
	 */
	function rebuildDataSource($comp, $exclude = -1)
	{
		$index = 0;
		$litem = 0;
		$dataSource = array();
		foreach($comp->Items as $item)
		{
			if (($item->ItemType==='Item' || $item->ItemType==='AlternatingItem') && ($item->ItemIndex != $exclude))
			{
				$element = $item->Row;

				if ($element instanceof TTextBox || $element instanceof TAutoComplete)
				$value = $element->getSafeText();
				elseif ($element instanceof TUnimarcField)
				$value = $element->getValue();
				elseif ($element instanceof TDropDownList)
				$value = $element->getSelectedValue();

				$dataSource[] = array('value' => $value);
				$index++;
				$litem = $item;
			}
		}
		return $dataSource;
	}

	/**
	 * @author Marco Brancalion <mbrancalion@e-portaltech.it>
	 *
	 * This method is used to add a new empty item to a repeatable
	 * control.
	 *
	 * @param TControl $comp
	 */
	public function addItem($comp)
	{
		if ($comp)
		{
			$dataSource = $this->rebuildDataSource($comp);
			$dataSource[] = array('value' => null);
			$comp->setDataSource($dataSource);
			$comp->dataBind();
		}
	}

	/**
	 * @author Marco Brancalion <mbrancalion@e-portaltech.it>
	 *
	 * This method is used to subtract an item, described as a
	 * positional integer by the parameter $itemindex (starts from 0)
	 * from the repeatable control $comp.
	 *
	 * @param TControl $comp
	 * @param int $itemIndex
	 */
	public function subtractItem($comp, $itemIndex)
	{
		if ($comp)
		{
			$dataSource = $this->rebuildDataSource($comp, $itemIndex);
			$comp->setDataSource($dataSource);
			$comp->dataBind();
		}
	}

	/**
	 * @author Marco Brancalion <mbrancalion@e-portaltech.it>
	 *
	 * This callback is called each time a single item of a	repeatable
	 * control is executing a databind.
	 * Its purpose is to set back into the nested control, in the item, its
	 * right value (taken from the datasource), after a general page databind
	 * has been executed.
	 * It's particularly useful in case the nested control is a TDropDownList
	 * where a non-default value has already been selected.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onListDataBound($sender, $param)
	{
		$item = $param->Item;
		if ($item->ItemType==='Item' || $item->ItemType==='AlternatingItem')
		{
			$element = $item->Row;

			if ($element instanceof TTextBox || $element instanceof TAutoComplete)
			$element->setText($item->DataItem['value']);
			elseif ($element instanceof TUnimarcField)
			$element->setValue($item->DataItem['value']);
			elseif ($element instanceof TDropDownList)
			$element->setSelectedValue($item->DataItem['value']);
		}
	}

	public function getAutoCompleteFromLookup($word, $class)
	{
		$criteria = new Criteria();
		$criteria->add(LookupValuePeer::VALUE_CLASS, $class);
		$criteria->add(LookupValuePeer::VALUE_LABEL, "$word%", Criteria::LIKE);
		$criteria->add(LookupValuePeer::VALUE_LANGUAGE, $this->getApplication()->getGlobalization()->getCulture());
		$values = LookupValuePeer::doSelect($criteria);

		$dataSource = array();
		foreach($values as $value)
			$dataSource[$value->getValueKey()] = $value->getValueLabel();

		return $dataSource;
	}

	public function globalRefresh() {
		Prado::log('Warning: in the current page ['.$this->getPagePath().'] the method '.__FUNCTION__.' is not implemented !');
	}

	public function globalEditCancel() {
		Prado::log('Warning: in the current page ['.$this->getPagePath().'] the method '.__FUNCTION__.' is not implemented !');
	}

	public function writeMessage($text = '', $type = null)
	{
		ClavisMessage::writeMessage($text, $type);
	}

	public function cleanMessages()
	{
		ClavisMessage::cleanMessages();
	}

	public function setFocus($controlId = null)
	{
		if (is_null($controlId))
			return;
		if ($this->getIsCallback())
			$this->getAdapter()->getCallbackClientHandler()->callClientFunction('Prado.Element.focus', array($controlId));
		else
			parent::setFocus($controlId);
	}

	public function isDestinationPageAllowed($page, $clavisLibrarian = null)
	{
		if (is_null($clavisLibrarian))
			$clavisLibrarian = Prado::getApplication()->getUser();

		if ($clavisLibrarian->getIsAdmin())
			return true;

		return TPropertyValue::ensureBoolean($clavisLibrarian->checkAllowedPage($page));
	}

	public function enqueueMessage($newMessageBody = '', $newMessageType = null)
	{
		if ($newMessageBody == '')
			return false;

		$this->_enqueuedMessageBody .= ($this->_enqueuedMessageBody != ''
											? '&nbsp;&nbsp;&nbsp;&nbsp;<br /><br />'
											: '') . $newMessageBody;

		if (is_null($this->_enqueuedMessageType))
		{
			$this->_enqueuedMessageType = $newMessageType;
		}
		else
		{
			if (array_key_exists($newMessageType, $this->_errorTypeMap) 
					&& array_key_exists($this->_enqueuedMessageType, $this->_errorTypeMap))
			{
				if ($this->_errorTypeMap[$newMessageType] > $this->_errorTypeMap[$this->_enqueuedMessageType])
					$this->_enqueuedMessageType = $newMessageType;
				else
					$this->_enqueuedMessageType = $this->_enqueuedMessageType;
			}
		}
	}

	public function collectMessage()
	{
		return array($this->_enqueuedMessageBody, $this->_enqueuedMessageType);
	}

	public function cleanMessageQueue()
	{
		$this->_enqueuedMessageBody = '';
		$this->_enqueuedMessageType = null;
	}

	public function flushMessage()
	{
		list ($messageBody, $messageType) = $this->collectMessage();
		
		if ($messageBody != '')
		{
			$this->writeMessage($messageBody, $messageType);
			$this->cleanMessageQueue();
		}
	}

	public function flushDelayedMessage()
	{
		list ($messageBody, $messageType) = $this->collectMessage();
		
		if ($messageBody != '')
		{
			$this->writeDelayedMessage($messageBody, $messageType);
			$this->cleanMessageQueue();
		}
	}

	public function writeDelayedMessage($body = null, $type = null)
	{
		$body = trim($body);
		
		if ($body == '')
			return false;
		
		if (is_null($type))
			$type = ClavisMessage::ERROR;
		
		$tag = 'DelayedMessage';
		
		if ($this->_isPopup)
			$tag .= 'Popup';
		
		$this->getApplication()->getSession()->add(	$tag, 
													array($body, $type));
	}

	public function appendDelayedMessage($body = null, $type = null)
	{
		$body = trim($body);
		if ($body == '')
			return false;
		if (is_null($type))
			$type = ClavisMessage::ERROR;
		$tag = 'DelayedMessage';
		if ($this->_isPopup)
			$tag .= 'Popup';
		list ($oldBody, $oldType) = $this->getApplication()->getSession()->itemAt($tag);
		$oldBody .= ($oldBody != '' ? '&nbsp;&nbsp;&nbsp;&nbsp;<br /><br />' : '') . $body;
		$oldType = is_null($oldType)
			? $type : ($this->_errorTypeMap[$type] > $this->_errorTypeMap[$oldType] ? $type : $oldType);
		$this->getApplication()->getSession()->add($tag, array($oldBody, $oldType));
	}

	public function createWriter()
	{
		return $this->getPage()->getResponse()->getAdapter()->createNewHtmlWriter('THtmlWriter', $this->getPage()->getResponse());
	}

}
