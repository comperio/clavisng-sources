<?php
/**
 * ClavisRequestManager class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Core
 */

/**
 * ClavisRequestManager Class
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.7
 * @package Core
 * @since 2.5.2
 */
class ClavisRequestManager extends TModule implements IRequestManager
{
	const red_flag = 20;
	const yellow_flag = 10;
	const no_flag = 0;
	const IDATA_SEPARATOR = "#";
	const IDCOMBO_SEPARATOR = "-";
	const OOCSTRING = "OOC";
	const NULLSTRING = "*NULL*";
	const _itemFilterQuery = "itemFilterQuery";
	const _itemFilterParams = "itemFilterParam";
	const _requestFilterQuery = "requestFilterQuery";
	const _requestFilterParams = "requestFilterParam";
	private $_connection;  //propel connection

	const NEVERREQUESTCAT_PATRONNOTENABLED = 'PATRONNOTENABLED';
	const NEVERREQUESTCAT_PATRONNOTENABLEDLOSTREQUESTS = 'PATRONNOTENABLEDLOSTREQUESTS';	// request decay before patron is readmitted
	const NEVERREQUESTCAT_PATRONNOTENABLEDSAFEREQUESTS = 'PATRONNOTENABLEDSAFEREQUESTS';	// request decay after patron is readmitted
	const NEVERREQUESTCAT_PATRONMAXLOANS = 'PATRONMAXLOANS';	// max loans reached by patron
	const NEVERREQUESTCAT_NOITEMS = 'NOITEMS';
	const NEVERREQUESTCAT_NOITEMSDISTANT = 'NOITEMSDISTANT';		// there are items in other basins, but not within the basin specified in the request
	const NEVERREQUESTCAT_MANIFESTATIONAVAILDATE = 'NOITEMSMANIFESTATIONAVAILDATE';		// no items for minimum date availability of the manifestation
	const NEVERREQUESTCAT_PATRONAGE = 'PATRONAGE';		// no items for age limit of che patron, for a manifestation with an age limit
	const NEVERREQUESTCAT_GENERIC = 'GENERIC';		// old-style behaviour: a bunch of generic all-around reasons
	
	public function init($param)
	{
		$this->_connection = Propel::getConnection();
	}

	private static function getLLibraryActive()
	{
		return LLibraryPeer::isEnabled();
	}

	private static function getRequestTypeActive()
	{
		return ItemRequestPeer::isRequestType();
	}

	/**
	 * calculateRequestDistances()
	 * 
	 * It outputs an array with possible distances (referred to basins)
	 * for perfecting a request of an object (manifestation) with a
	 * particular delivery library in mind.
	 * 
	 * If there are not distances, an empty array will be given.
	 * 
	 * @param Manifestation $manifestation
	 * @param int $deliveryLibraryId
	 * 
	 * @return array 
	 */
	public function calculateRequestDistances(	Manifestation $manifestation,
												$deliveryLibraryId)
	{
		if (!($manifestation instanceof Manifestation))
			return array();

		$manifestationId = $manifestation->getManifestationId();

		$output = array();

		$queryString = "SELECT item_id,
		 					(SELECT distance FROM l_library l
		 					 	WHERE home_library_id = l.from_library_id AND to_library_id={$deliveryLibraryId}) AS distance
						FROM item i
						WHERE manifestation_id={$manifestationId}
							AND i.item_status IN ('" . implode(ItemStatus::getItemStatusManageable(), "','") . "')
							AND ((i.issue_id IS NULL OR i.issue_id=0)
								OR (i.issue_id IS NOT NULL AND (i.issue_status IN ('" . implode(ItemPeer::getIssueStatusArrived(), "','") . "'))))
							AND ((i.loan_class IN ('" . implode(ItemPeer::getLoanClassesLocallyAvailable(true), "','") . "')
							 		AND i.home_library_id={$deliveryLibraryId})
								OR (i.loan_class NOT IN ('" . implode(ItemPeer::getLoanClassesLocallyAvailable(true), "','") . "')))
						GROUP BY distance
						ORDER BY distance";

		$connection = Propel::getConnection();
		$stmt = $connection->prepare($queryString);
		$stmt->execute();

		while ($row = $stmt->fetch(PDO::FETCH_ASSOC))
		{
			$distance = $row['distance'];
			if (!is_null($distance))
				$output[$distance] = ItemRequestPeer::getCompleteMaxDistance($distance);
		}

		if (array_key_exists(0, $output))
		{
			$output[1] = ItemRequestPeer::getCompleteMaxDistance(1);
			asort($output);
		}

		return $output;
	}

	/**
	 * calculateMinRequestDistance()
	 * 
	 * It outputs an  integer that is the min distance
	 * that has been found for perfecting a request of an 
	 * object (manifestation or an issue) with a particular 
	 * delivery library in mind.
	 * 
	 * If there are not valid distances, a null value is returned.
	 * 
	 * @param Manifestation|Issue $propelObject
	 * @param int $deliveryLibraryId
	 * 
	 * @return int or null
	 */
	public function calculateMinRequestDistance(	$propelObject,
													$deliveryLibraryId)
	{
		if (intval($deliveryLibraryId) == 0)
			return null;

		if ($propelObject instanceof Manifestation)
		{
			$propelObjectQueryString = "AND i.manifestation_id=" . $propelObject->getManifestationId();
		}
		elseif ($propelObject instanceof Issue)
		{	$propelObjectQueryString = "AND i.manifestation_id=" . $propelObject->getManifestationId()
					. " AND i.issue_id=" . $propelObject->getIssueId();
		}
		else
		{
			return null; // invalid object passed as a parameter
		}

		$output = null;

		$queryString = "SELECT 
							MIN(distance) as minDistance 
						FROM 
							l_library l JOIN item i ON l.from_library_id = i.home_library_id 
						WHERE 
							l.to_library_id={$deliveryLibraryId} "
				. $propelObjectQueryString
				. "	AND i.item_status IN ('" . implode(ItemStatus::getItemStatusManageable(), "','") . "')
							AND ((i.issue_id IS NULL OR i.issue_id=0)
								OR (i.issue_id IS NOT NULL AND (i.issue_status IN ('" . implode(ItemPeer::getIssueStatusArrived(), "','") . "'))))
							AND ( (i.loan_class != 'A' AND i.home_library_id={$deliveryLibraryId})
								OR (i.loan_class NOT IN ('A','C','D','F')))	";

		$connection = Propel::getConnection();
		$stmt = $connection->prepare($queryString);
		$stmt->execute();

		while ($row = $stmt->fetch(PDO::FETCH_ASSOC))
		{
			$minDistance = $row['minDistance'];
			//$maxDistance = $row['maxDistance'];
		}

		if (!is_null($minDistance))
		{
			if ($minDistance == 0)
			{
				$output = 1;
			}
			else
			{
				$output = $minDistance;
			}
		}

		return $output;
	}

	/**
	 * Explicit reservation of an item
	 *
	 * @param Item $item
	 * @param Patron $patron
	 * @param Library $deliveryLibrary
	 * @param ClavisLibrarian $clavisLibrarian
	 * @param string $description
	 * @param int $externalLibraryId
	 *
	 * @return boolean
	 */
	public function reserveItem(	$item,
									$patron,
									$deliveryLibrary,
									$clavisLibrarian = null,
									$description = null,

									$externalLibraryId = null,
									$requestType = null)
	{
		if (!($item instanceof Item))
			return false;

		if (!is_null($patron)
				&& !($patron instanceof Patron))
			return false;

		if ((!$deliveryLibrary instanceof Library))
			return false;

		if (!is_numeric($clavisLibrarian))
		{
			if (is_null($clavisLibrarian)
					|| !($clavisLibrarian instanceof ClavisLibrarian))
				return false;
		}

		if ($description != null)
		{
			if (!is_string($description))
				return false;
		}
		
		$externalLibrary = null;
		$externalLibraryId = intval($externalLibraryId);

		if ($externalLibraryId > 0)
			$externalLibrary = LibraryQuery::create()->findPk($externalLibraryId);

		if (!(is_null($externalLibrary)
				xor ( is_null($patron))))
			return false;

		if (!is_null($requestType)
				&& !array_key_exists($requestType, ItemRequestPeer::getRequestTypes()))
				$requestType = null;
		try
		{  // force check if item has already been requested (not manifestation)
			if (self::isItemReservable(	$item,
										$patron,
										$deliveryLibrary->getLibraryId(),
										true) == ClavisLoanManager::OK)
			{
				$lm = $this->getApplication()->getModule("loan");

				$itemRequest = new ItemRequest();
				$itemRequest->setRequestStatus(ItemRequestPeer::STATUS_PENDING); //  'A' 'Pendente'
				$itemRequest->setItemId($item->getItemId());
				$itemRequest->setManifestationId($item->getManifestationId());
				$itemRequest->setPatron($patron);
				$itemRequest->setExternalLibraryId($externalLibraryId);
				$itemRequest->setRequestDate(time());
				$expireDate = $lm->CalculateExpireDate($itemRequest, $item, $patron);
				$itemRequest->setDeliveryLibraryId($deliveryLibrary->getLibraryId());

				if ($expireDate != -1)
				{
					$itemRequest->setExpireDate($expireDate);
				}
				else
				{
					throw new Exception();
				}

				if ($description != '')
					$itemRequest->setRequestNote($description);

				$itemRequest->setIssueId($item->getIssueId());
				$itemRequest->setLibrarianId(null);
				$itemRequest->setMaxDistance(null);
				$itemRequest->setRequestType($requestType);
				
				$itemRequest->save();

				// edit patron last_seen for statistics
				if ($patron instanceof Patron)
					$patron->UpdateLastSeen(true);

				return true;
			}

			return false;
		}
		catch (Exception $e)
		{
			$e = $e;
			//throw $e;
			return false;
		}
	}

	/**
	 * reserveManifestation()
	 * 
	 * Reservation of a manifestation
	 *
	 * @param Manifestation $manifestation
	 * @param Patron $patron
	 * @param Library $deliveryLibrary
	 * @param ClavisLibrarian $clavisLibrarian
	 * @param string $description

	 * @param integer $issue_id
	 * @param integer $externalLibraryId
	 * @param integer $maxDistance
	 */
	public function reserveManifestation(	$manifestation,
											$patron,
											$deliveryLibrary,
											$clavisLibrarian = null,
											$description = null,

											$issue_id = null,
											$externalLibraryId = null,
											$maxDistance = null,
											$requestType = null)
	{
		if (is_null($manifestation)
				|| !($manifestation instanceof Manifestation))
			return false;

		if (!is_null($patron)
				&& !($patron instanceof Patron))
			return false;

		if (!($deliveryLibrary instanceof Library))
			return false;

		if ($clavisLibrarian != null)
		{
			if (!$clavisLibrarian instanceof ClavisLibrarian)
				return false;
		}

		if ($description != null)
		{
			if (!is_string($description))
				return false;
		}
		
		if (!is_null($issue_id))
		{
			$issue_id = intval($issue_id);
		
			if (!($issue_id > 0))
				return false;
		}

		$externalLibrary = null;
		$externalLibraryId = intval($externalLibraryId);

		if ($externalLibraryId > 0)
			$externalLibrary = LibraryQuery::create()->findPK($externalLibraryId);
		
		if (!(is_null($externalLibrary)
				xor ( is_null($patron))))
			return false;
		
		if (!is_null($requestType)
				&& !array_key_exists($requestType, ItemRequestPeer::getRequestTypes()))
			$requestType = null;

		try
		{
			$returnCode = ClavisLoanManager::ERROR;
			if ($patron instanceof Patron)
			{
				$returnCode = self::isManifestationReservable(	$manifestation,
																$issue_id,
																$patron,
																$deliveryLibrary->getLibraryId());
			}
			elseif ($externalLibrary instanceof Library)
			{
				$returnCode = self::isManifestationReservable(	$manifestation,
																$issue_id,
																$externalLibrary,
																$deliveryLibrary->getLibraryId());
			}

			if (($returnCode == ClavisLoanManager::OK)
					|| ($returnCode == ClavisLoanManager::RSV_NOTAVAIL))
			{
				/**
				 * Modified in 08-09-2009:
				 * for allowing to create requests even if there are not
				 * items for immediate loan
				 */
				$item_request = new ItemRequest();
				$item_request->setRequestStatus(ItemRequestPeer::STATUS_PENDING);   // pending, 'A'
				$item_request->setManifestationId($manifestation->getManifestationId());

				if (!is_null($patron))
				{
					$patronId = $patron->getPatronId();
				}
				else
				{
					$patronId = null;
				}
				
				$item_request->setPatronId($patronId);
				$item_request->setExternalLibraryId($externalLibraryId);

				$item_request->setRequestDate(time());
				$expireDate = ClavisLoanManager::CalculateExpireDate(	$item_request,
																		null,
																		$patron);
				
				$item_request->setDeliveryLibraryId($deliveryLibrary->getLibraryId());

				$item_request->setLibrarianId(null);

				if ($expireDate != -1)
				{
					$item_request->setExpireDate($expireDate);
				}
				else
				{
					throw new Exception('');
				}

				if ($description != '')
					$item_request->setRequestNote($description);

				if (!is_null($issue_id))
					$item_request->setIssueId($issue_id);

				$item_request->setMaxDistance($maxDistance);
				$item_request->setRequestType($requestType);

				$item_request->save();

				//edit patron last_seen for statistics
				if (!is_null($patron))
					$patron->UpdateLastSeen(true);
			}

			return $returnCode;
		}
		catch (Exception $e)
		{
			$e = $e;
			//throw $e;
			return ClavisLoanManager::ERROR;
		}
	}

	/**
	 * It verifies if an item is reservable for a loan
	 *
	 * @param Item $item
	 * @param Patron/Library $destination
	 * @param integer $libraryId
	 * @param boolean $itemCheckForceFlag (itemId check)
	 *
	 * @return int (enumerated) :
	 * 		   ClavisLoanManager::OK : true
	 *         ClavisLoanManager::ERROR : generic error
	 *
	 * 		   ClavisLoanManager::RSV_NOTAVAIL : $item not available for loan
	 * 		   ClavisLoanManager::RSV_PATRONHASITEM : $item->patron_id == $patron->patron_id
	 * 		   ClavisLoanManager::RSV_PATRONREQITEM : $item already requested from $patron
	 * 		   ClavisLoanManager::RSV_PATRONMAXREQ : $patron has reached maximum requests
	 *
	 */
	public static function isItemReservable(	$item,
												$destination = null, 
												$libraryId = null, 
												$itemCheckForceFlag = true )
	{
		if (!($item instanceof Item))
			return ClavisLoanManager::ERROR;

		$lm = Prado::getApplication()->getModule('loan');
		$extra = false;
		
		if ($destination != null)
		{
			if ($destination instanceof Patron)
			{
				$destinationId = $destination->getPatronId();
		
				if ($destination->getPatronStatus() != PatronPeer::STATUS_ENABLED)
					return ClavisLoanManager::RSV_PATRONDISABLED;
			}
			elseif ($destination instanceof Library)
			{
				$destinationId = $destination->getLibraryId();
				$extra = true;
			}
			else
			{
				return ClavisLoanManager::ERROR;
			}
		}

		if (!self::isItemAvailableClass(	$item,
											$libraryId)) // in requestmanager, for request mode
			return ClavisLoanManager::RSV_NOTAVAIL;

		if (!is_null($destination))
		{
			if (!$extra)
			{
				// we check if item is already on loan to patron/library
				if ($lm->IsItemLoaned($item, $destination))
					return ClavisLoanManager::RSV_PATRONHASITEM;

				// we check if it has already been request by user
				$criteria = new Criteria();
				$criteria->add(ItemRequestPeer::PATRON_ID, $destinationId);

				if ($itemCheckForceFlag)
				{
					$criteria->addAnd(ItemRequestPeer::ITEM_ID, $item->getItemId());
				}
				else
				{
					if (intval($item->getManifestationId()) > 0)
					{
						$criteria->addAnd(ItemRequestPeer::MANIFESTATION_ID, $item->getManifestationId());
					}
					else
					{
						$criteria->addAnd(ItemRequestPeer::MANIFESTATION_ID, -1);   // this can never happen
					}
				}

				$criteria->addAnd(ItemRequestPeer::REQUEST_STATUS, ItemRequestPeer::STATUS_PENDING);

				$count_request = ItemRequestPeer::doCount($criteria);

				if ($count_request > 0)
					return ClavisLoanManager::RSV_PATRONREQITEM;

                $criteria->clear();


                
				/*
				 * We verify the number of pending request.
				 * This is the real method core (only for patrons)
				 */

				$criteria = new Criteria();

				$criteria->add(ItemRequestPeer::PATRON_ID, $destinationId);
				$criteria->addAnd(ItemRequestPeer::REQUEST_STATUS, ItemRequestPeer::STATUS_PENDING);

				$requestCount = ItemRequestPeer::doCount($criteria);

				if ($requestCount >= ClavisParamPeer::getParam('MAXLOANRESERVATIONS_' . $destination->getLoanClass(), '0'))
					return ClavisLoanManager::RSV_PATRONMAXREQ;

				$criteria->clear();
				$criteria->add(LoanPeer::LOAN_STATUS, ItemPeer::getLoanStatusActive(), Criteria::IN);
				$loanCount = $destination->countLoans($criteria);
				unset($criteria);

				if (($requestCount + $loanCount) > ClavisParamPeer::getParam('MAXOPERATIONS_' . $destination->getLoanClass(), '0'))
					return ClavisLoanManager::RSV_PATRONMAXREQ;
			}
		}

		return ClavisLoanManager::OK;
	}

	public function isManifestationReservable(	Manifestation $manifestation,
												$issueId = null,
												$destination = null,
												$deliveryLibraryId = null)
	{
		// We check if patron is allowed to request
		if ($destination instanceof Patron)
		{
			if ($destination->getPatronStatus() != PatronPeer::STATUS_ENABLED)
				return ClavisLoanManager::RSV_PATRONDISABLED;
			
			if ($manifestation->getRating() > 0 &&
					($manifestation->getRating() - $destination->getPatronAge()) > 0)
				return ClavisLoanManager::RSV_RATING;

			$q = ItemRequestQuery::create()
									->filterByPatron($destination)
									->filterByRequestStatus(ItemRequestPeer::getActiveStatus())
									->filterByManifestation($manifestation);

			if ($issueId > 0)
				$q->filterByIssueId($issueId);

			if ($q->count() > 0)
				return ClavisLoanManager::RSV_PATRONREQMANIF;

			// check for active loans on the same title
			if (!$issueId)
			{
				$q = LoanQuery::create()
						->filterByPatron($destination)
						->filterByManifestation($manifestation)
						->filterByLoanStatus(ItemPeer::getLoanStatusActive(), Criteria::IN);
				
				if ($q->count() > 0)
					return ClavisLoanManager::RSV_PATRONHASITEM;
			}

			// we check the number of the requests that the patron has
			$requestCount = ItemRequestQuery::create()
								->filterByPatron($destination)
								->filterByRequestStatus(ItemRequestPeer::STATUS_PENDING)
								->count();
			
			if ($requestCount >= ClavisParamPeer::getParam('MAXLOANRESERVATIONS_' . $destination->getLoanClass(), '0'))
				return ClavisLoanManager::RSV_PATRONMAXREQ;

			$loanCount = LoanQuery::create()
							->filterByPatron($destination)
							->filterByLoanStatus(ItemPeer::getLoanStatusActive(), Criteria::IN)
							->count();
			
			if (($requestCount + $loanCount) > ClavisParamPeer::getParam('MAXOPERATIONS_' . $destination->getLoanClass(), '0'))
				return ClavisLoanManager::RSV_PATRONMAXREQ;
		}

		if (intval($deliveryLibraryId) > 0)
		{
			$deliveryLibrary = LibraryQuery::create()->findPk($deliveryLibraryId);
			
			if (!($deliveryLibrary instanceof Library))
				return ClavisLoanManager::ERROR;
		}

		$q = ItemQuery::create()
				->filterByManifestation($manifestation);
		
		if (intval($issueId) > 0)
			$q->filterByIssueId($issueId);

		if (intval($deliveryLibraryId) > 0)
		{
			$q->condition('local1', 'Item.LoanClass IN ?', ItemPeer::getLoanClassesLocallyAvailable(true))
					->condition('local2', 'Item.ActualLibraryId = ?', $deliveryLibraryId)
					->combine(array('local1', 'local2'), 'and', 'local')
					->condition('global', 'Item.LoanClass IN ?', ItemPeer::getLoanClassesAvailable(true))
					->where(array('local', 'global'), 'or');
		}
		else
		{
			$q->filterByLoanClass(array_merge(	ItemPeer::getLoanClassesAvailable(true),
												ItemPeer::getLoanClassesLocallyAvailable(true)));
		}
		
		if ($q->count() < 1)
			return ClavisLoanManager::RSV_NOTAVAIL;

		return ClavisLoanManager::OK;
	}

	public function isIssueReservable(	$issue,
										$destination = null,
										$libraryId = null)
	{
		if (!($issue instanceof Issue))
			return ClavisLoanManager::ERROR;

		if (!is_null($destination))
		{
			if (!($destination instanceof Patron)
					&& !($destination instanceof Library))
				return ClavisLoanManager::ERROR;
		}

		foreach ($issue->getItems() as $item)
		{
			if (self::isItemReservable($item, $destination, $libraryId) == ClavisLoanManager::OK)
				return true;
		}

		return false;
	}

	/**
	 * getManifestationRequests()
	 * 
	 * We get requests with the new NewCirc system, filtered for
	 * manifestation
	 * 
	 * @param int $manifestationId 
	 * 
	 * @return array
	 */
	public function getManifestationRequests($manifestationId)
	{
		/**
		 * We should search all requests (so, the true in parameters for local 
		 * matching) 
		 */
		$actualLibraryId = $this->getUser()->getActualLibraryId();
		$output = array();

		$queryString = "SELECT request_id,
							MIN(request_date) AS request_date,
							manifestation_id,
							item_id,
							issue_id,
							(SELECT SUBSTRING(title,1,40) FROM manifestation WHERE manifestation_id = r.manifestation_id) AS title,
							(SELECT COUNT(*) FROM item i  FORCE INDEX  (item_request_speedup) WHERE (i.manifestation_id = r.manifestation_id)) AS tcount,
							(SELECT COUNT(*) FROM item i  FORCE INDEX  (item_request_speedup) WHERE (i.manifestation_id = r.manifestation_id)
									AND ((r.item_id IS NOT NULL AND i.item_id = r.item_id) OR r.item_id IS NULL)) AS t1count,
							(SELECT COUNT(*) FROM item i  FORCE INDEX  (item_request_speedup) 
								WHERE (i.manifestation_id = r.manifestation_id) 
										AND i.actual_library_id={$actualLibraryId} " .
							" AND (SELECT library_status FROM library WHERE library_id = r.delivery_library_id) = '" . LibraryPeer::STATUS_ACTIVE . "' " .
							" AND i.loan_status IN ('" . implode(ItemPeer::getLoanStatusAvailable(), "','") . "')
										AND (i.loan_class IN ('" . implode(ItemPeer::getLoanClassesAvailable(true), "','") . "')
											OR (i.loan_class IN ('" . implode(ItemPeer::getLoanClassesLocallyAvailable(true), "','") . "')
										AND r.delivery_library_id={$actualLibraryId}))) AS icount,
							COUNT(*) AS queue

						FROM item_request r 
						
						WHERE r.request_status IN ('" . implode(ItemRequestPeer::getActiveStatus(), "','") . "')
							AND manifestation_id={$manifestationId}
						GROUP BY manifestation_id
						HAVING icount > 0
						ORDER BY manifestation_id, MIN(request_date) ASC";

		$connection = Propel::getConnection();
		$stmt = $connection->prepare($queryString);
		$stmt->execute();

		while ($row = $stmt->fetch(PDO::FETCH_ASSOC))
		{		
			$output[] = array(	'requestId' => $row['request_id'],
								'requestDate' => $row['request_date'],
								'manifestationId' => $row['manifestation_id'],
								'itemId' => $row['issue_id'],
								'title' => $row['title'],
								'tcount' => $row ['tcount'],
								't1count' => $row ['t1count'],
								'icount' => $row ['icount'],
								'queue' => $row['queue'] );
		}
		
		return $output;
	}

	/**
	 * getManifestationRequests()
	 * 
	 * We get requests with the new NewCirc system, filtered for
	 * manifestation
	 * 
	 * 
	 * @return array
	 */
	public function getRequests(	$actualLibraryId = null,
									$currentIndexPage = null,
									$pageSize = null,
									$filters = array(),
									$itemIdParam = 0)
	{
		if (intval($actualLibraryId) == 0)
			$actualLibraryId = $this->getUser()->getActualLibraryId();

		$connection = Propel::getConnection();
		
		$queryStringArray = self::calculateRequestsQueryString(	$actualLibraryId,
																$currentIndexPage,
																$pageSize,
																$filters,
																$itemIdParam);

		$stmt = $connection->prepare($queryStringArray['querystring']);
		$stmt->execute($queryStringArray['params']);

		$output = array();
		while ($row = $stmt->fetch(PDO::FETCH_ASSOC))
			$output[] = self::calculateOutputRequestColumn($row);

		return $output;
	}

	public function countRequests(	$actualLibraryId = null,
									$filters = array(),
									$itemIdParam = 0,
									$manifestationIdParam = 0,
									$newLoanFlag = false)
	{
		if (intval($actualLibraryId) == 0)
			$actualLibraryId = $this->getUser()->getActualLibraryId();

		$queryStringArray = self::calculateRequestsCountString(	$actualLibraryId,
																$filters,
																$itemIdParam,
																$manifestationIdParam,
																$newLoanFlag);

		$connection = Propel::getConnection();
		$stmt = $connection->prepare($queryStringArray['querystring']);
		$stmt->execute($queryStringArray['params']);

		return $stmt->rowCount();
	}

	/**
	 * getManifestationRequests()
	 * 
	 * We get requests with the new NewCirc system, filtered for
	 * manifestation and for INVERTED MODE (never satisfiable)
	 * 
	 * @return array
	 */
	public function getNeverRequests(	$actualLibraryId = null,
										$currentIndexPage = null,
										$pageSize = null,
										$filters = array())
	{
		if (intval($actualLibraryId) == 0)
			$actualLibraryId = $this->getUser()->getActualLibraryId();

		$queryStringArray = self::calculateNeverRequestsQueryString(	$actualLibraryId,
																		$currentIndexPage,
																		$pageSize,
																		$filters);

		$connection = Propel::getConnection();
		$stmt = $connection->prepare($queryStringArray['querystring']);
		$stmt->execute($queryStringArray['params']);

		$output = array();
		while ($row = $stmt->fetch(PDO::FETCH_ASSOC))
			$output[] = self::calculateNeverOutputRequestColumn($row);

		return $output;
	}

	public function countNeverRequests($actualLibraryId = null, $filters = array())
	{
		if (intval($actualLibraryId) == 0)
			$actualLibraryId = $this->getUser()->getActualLibraryId();

		$queryStringArray = self::calculateNeverRequestsCountString(	$actualLibraryId,
																		$filters);

		$connection = Propel::getConnection();
		$stmt = $connection->prepare($queryStringArray['querystring']);
		$stmt->execute($queryStringArray['params']);

		$output = array();
		$row = $stmt->fetch(PDO::FETCH_ASSOC);
		$output = $row['count'];

		return $output;
	}

	public function getRequestsDetailed(	$requestId,
											$actualLibraryId = null)
	{
		if (intval($actualLibraryId) == 0)
			$actualLibraryId = $this->getUser()->getActualLibraryId();

		$queryString = self::calculateRequestsQueryStringDetailed(	$requestId,
																	$actualLibraryId);

		$connection = Propel::getConnection();
		$stmt = $connection->prepare($queryString);
		$stmt->execute();

		$output = array();
		while ($row = $stmt->fetch(PDO::FETCH_ASSOC))
			$output[] = self::calculateOutputRequestColumnDetailed($row);

		return $output;
	}

	public function getRequestItemIds(	$requestIdParam,
										$actualLibraryId = null)
	{
		if (intval($actualLibraryId) == 0)
			$actualLibraryId = $this->getUser()->getActualLibraryId();

		$requestIdsArray = array();
		
		if (is_array($requestIdParam)
				&& (count($requestIdParam) > 0))
		{
			$requestIdsArray = $requestIdParam;
		}
		elseif (is_numeric($requestIdParam)
				&& ($requestIdParam > 0))
		{
			$requestIdsArray[] = $requestIdParam;
		}
		else
		{
			return array();
		}

		$queryString = self::calculateRequestItemIdsQueryString(	$requestIdsArray,
																	$actualLibraryId);

		$connection = Propel::getConnection();
		$stmt = $connection->prepare($queryString);
		$stmt->execute();

		$output = array();
		
		while ($row = $stmt->fetch(PDO::FETCH_ASSOC))
			$output[$row['request_id']] = $row['item_id'];

		return $output;
	}

	public function getRequestMyCandidateItemIds(	$deliveryLibraryId,
													$maxDistance,
													$requestManifestationId,
													$requestItemId,
													$requestIssueId)
	{
		$myLibraryId = $this->getUser()->getActualLibraryId();
		$output = array();
		
		if (LLibraryPeer::isEnabled())	// if basin
		{
			$okFlag = array_key_exists(	$deliveryLibraryId, 
										array_flip(LLibraryPeer::getLibraryIdsToDeliveryLibrary(	$myLibraryId,
																									$maxDistance)));
		}
		else	// not basin
		{
			$okFlag = true;
		}
		
		if ($okFlag)
		{
			$queryString = "SELECT item_id as itemId
									FROM item i FORCE INDEX (item_request_speedup)
									WHERE (i.manifestation_id = {$requestManifestationId}) " .
					" AND i.actual_library_id = {$myLibraryId}" .
					" AND (SELECT library_status FROM library WHERE library_id = {$deliveryLibraryId}) = '" . LibraryPeer::STATUS_ACTIVE . "' " .
					" AND i.loan_status IN ('" . implode(ItemPeer::getLoanStatusAvailable(), "','") . "')
										AND ((i.issue_id IS NOT NULL AND i.issue_status = '" . ItemPeer::ISSUESTATUS_ARRIVED . "')
											OR i.issue_id IS NULL)
										AND (i.LOAN_CLASS IN ('" . implode(ItemPeer::getLoanClassesAvailable(true), "','") . "')
											OR (i.actual_library_id = {$deliveryLibraryId} AND i.LOAN_CLASS IN ('" . implode(ItemPeer::getLoanClassesLocallyAvailable(true), "','") . "'))) ";

			if (!is_null($requestItemId))
				$queryString .= " AND (i.item_id = " . $requestItemId . ")";

			if (!is_null($requestIssueId))
				$queryString .= " AND (i.issue_id = " . $requestIssueId . ")";

			$connection = Propel::getConnection();
			$stmt = $connection->prepare($queryString);
			$stmt->execute();

			while ($row = $stmt->fetch(PDO::FETCH_ASSOC))
				$output[] = $row['itemId'];
		}

		return $output;
	}

	public function countRequestAllCandidateItems(	$deliveryLibraryId,
													$maxDistance,
													$requestManifestationId,
													$requestItemId,
													$requestIssueId)
	{
		if (LLibraryPeer::isEnabled()) // if basin
		{
			$ids = LLibraryPeer::getLibraryIdsFromDeliveryLibrary(	$deliveryLibraryId,
																	$maxDistance,
																	$this->getUser()->getActualLibraryId());
			
			$libIdFilter = count($ids) > 0 ?
					' AND i.actual_library_id IN (' . implode($ids, ',') . ') ' : ' ';
		}
		else // not basin
		{
			$libIdFilter = " AND i.actual_library_id != {$this->getUser()->getActualLibraryId()} ";
		}

		$queryString = "SELECT COUNT(*)
								FROM item i FORCE INDEX (item_request_speedup)
								WHERE (i.manifestation_id = {$requestManifestationId}) " .
				" AND (SELECT library_status FROM library WHERE library_id = {$deliveryLibraryId}) = '" . LibraryPeer::STATUS_ACTIVE . "' " .
				$libIdFilter .
				" AND i.loan_status IN ('" . implode(ItemPeer::getLoanStatusAvailable(), "','") . "')
									AND ((i.issue_id IS NOT NULL AND i.issue_status = '" . ItemPeer::ISSUESTATUS_ARRIVED . "')
										OR i.issue_id IS NULL)
									AND (i.LOAN_CLASS IN ('" . implode(ItemPeer::getLoanClassesAvailable(true), "','") . "')
										OR (i.actual_library_id = {$deliveryLibraryId} AND i.LOAN_CLASS IN ('" . implode(ItemPeer::getLoanClassesLocallyAvailable(true), "','") . "'))) ";

		if (!is_null($requestItemId))
			$queryString .= " AND (i.item_id = " . $requestItemId . ")";

		if (!is_null($requestIssueId))
			$queryString .= " AND (i.issue_id = " . $requestIssueId . ")";

		$connection = Propel::getConnection();
		$stmt = $connection->prepare($queryString);
		$stmt->execute();
		$result = $stmt->fetchAll(PDO::FETCH_COLUMN);

		return $result[0];
	}

	private function calculateOutputRequestColumn($row)
	{
		list ($manifestationId, $itemId, $issueId) = self::decodeIdCombo($row['idcombo']);
		list($request_date, $request_id) = explode(self::IDATA_SEPARATOR, $row['requestIdCombo']);

		$output = array(	'requestId' => $request_id,
							'requestDate' => $request_date,
							'manifestationId' => $manifestationId,
							'itemId' => $itemId,
							'issueId' => $issueId,
							'title' => $row['title'],
							'tcount' => $row ['tcount'],
							'icount' => $row ['icount'],
							'mcount' => $row ['mcount'], // n. of managed
							'idata' => self::decodeIData($row['idata']), // item data blob
							'queue' => $row['queue'] );

		return $output;
	}

	private function calculateNeverOutputRequestColumn($row)
	{
		$output = array(	'requestId' => $row['request_id'],
							'requestDate' => $row['request_date'],
							'manifestationId' => $row['manifestation_id'],
							'itemId' => $row['item_id'],
							'issueId' => $row['issue_id'],
							'title' => $row['title'],
							// for compatibility
							'tcount' => 0,
							'icount' => 0,
							'mcount' => 0,
							'idata' => array(),
							'queue' => 0 );

		return $output;
	}

	private function calculateOutputRequestColumnDetailed($row)
	{
		// select request_id,patron_id,external_library_id,delivery_library_id,request_date,expire_date,request_note
		$output = array(	'requestId' => $row['request_id'],
							'manifestationId' => $row['manifestation_id'],
							'itemId' => $row['item_id'],
							'issueId' => $row['issue_id'],
							'maxDistance' => $row['max_distance'],
							'patronId' => $row['patron_id'],
							'externalLibraryId' => $row['external_library_id'],
							'requestDate' => $row['request_date'],
							'expireDate' => $row['expire_date'],
							'requestNote' => $row['request_note'],
							'requestStatus' => $row['request_status'],
							'librarianId' => $row['librarian_id'] );

		return $output;
	}

	private function decodeIData($param = array())
	{
		$output = array();

		$data = explode(self::IDATA_SEPARATOR, $param);
		
		if (count($data) > 0)  // see idata row in self::getRequests()
		{
			foreach ($data as $row)
			{
				if ($row === self::NULLSTRING)
					$row = null;

				$output[] = $row;
			}
		}

		return $output;
	}

	private function decodeIdCombo($param = '')
	{
		$manifestationId = 0;
		$itemId = null;
		$issueId = null;

		if ($param != "")
		{
			$fields = explode(self::IDCOMBO_SEPARATOR, $param);
		
			if (count($fields) > 1)
			{
				if ($fields[0] == self::OOCSTRING)
				{
					$itemId = $fields[1];
				}
				else
				{
					if (array_key_exists(0, $fields))
						$manifestationId = $fields[0];

					if (array_key_exists(1, $fields))
					{
						$itemId = $fields[1];
			
						if ($itemId == 0)
							$itemId = null;
					}

					if (array_key_exists(2, $fields))
					{
						$issueId = $fields[2];
						
						if ($issueId == 0)
							$issueId = null;
					}
				}
			}
			else
			{
				$manifestationId = intval($param);
			}
		}

		return array(	$manifestationId,
						$itemId,
						$issueId );
	}

	private static function calculateBasinQuery()
	{
		/// calculate subquery for basins
		$basinSubQueryArray = array("r.max_distance IS NULL OR r.external_library_id > 0");
		$distanceHash = Prado::getApplication()->getUser()->getDistanceHash();
		$previousBasin = "";

		for ($distance = 0; $distance <= LLibraryPeer::getMaxLLibraryDistance(); $distance++)
		{
			if (array_key_exists($distance, $distanceHash))
			{
				$counterBasin = $distanceHash[$distance];
				
				if ($previousBasin != "")
					$counterBasin .= "," . $previousBasin;

				$basinSubQueryArray[] = "(r.delivery_library_id IN (" . $counterBasin . ") AND r.max_distance = " . $distance . ")";
				$previousBasin = $counterBasin;
			}
		}

		$basinSubQuery = implode(' OR ', $basinSubQueryArray);

		if ($basinSubQuery != "")
			$basinSubQuery = " AND (" . $basinSubQuery . ") ";

		return $basinSubQuery;
	}
	
	private function calculateNeverBasinQuery()
	{
		$distanceHash = LibraryPeer::getInvertedDistanceBlob(Prado::getApplication()->getUser()->getActualLibraryId());
		$maxDistance = LLibraryPeer::getMaxLLibraryDistance();
		
		$basinSubQuery = "r.max_distance IS NULL OR (i.actual_library_id IN (" . $distanceHash . ") AND r.max_distance <= " . $maxDistance . ")";

		return $basinSubQuery;
	}
	
	private static function calculateDistantNeverBasinQuery()
	{
		$basinSubQueryArray = array("r.max_distance IS NULL");

		$distanceHash = LibraryPeer::getInvertedDistanceHash(Prado::getApplication()->getUser()->getActualLibraryId());
		$previousBasin = "";

		for ($distance = 0; $distance <= LLibraryPeer::getMaxLLibraryDistance(); $distance++)
		{
			if (array_key_exists($distance, $distanceHash))
			{
				$counterBasin = $distanceHash[$distance];
				if ($previousBasin != "")
					$counterBasin .= "," . $previousBasin;

				$basinSubQueryArray[] = "(i.actual_library_id IN (" . $counterBasin . ") AND r.max_distance = " . $distance . ")";

				$previousBasin = $counterBasin;
			}
		}

		$basinSubQuery = implode(' OR ', $basinSubQueryArray);
//		if ($basinSubQuery != "")
//			$basinSubQuery = " AND (" . $basinSubQuery . ") ";

		return $basinSubQuery;
	}
	
	public static function calculateFilterQuery($filters = array())
	{
		$itemFilterQuery = "";
		$itemFilterParams = array();
		$requestFilterQuery = "";
		$requestFilterParams = array();

		if (is_array($filters))
		{
			// Never request category filtering
			if (array_key_exists('neverRequestCategory', $filters)
					&& ($NRCategory = $filters['neverRequestCategory']))
			{
				if (array_key_exists('actualLibraryId', $filters))
				{
					$actualLibraryId = $filters['actualLibraryId'];
				}
				else
				{
					$actualLibraryId = null;
				}

				switch ($NRCategory)
				{
					/**
					* TODO mbrancalion, creare un case per ogni categoria di ricerca di nonsoddisfacimento
					*/	
					
					case self::NEVERREQUESTCAT_MANIFESTATIONAVAILDATE:
						$requestFilterQuery = self::calculateNRLoanableSince();
						break;

					case self::NEVERREQUESTCAT_PATRONNOTENABLED:
						$requestFilterQuery = self::calculateNRPatronNotEnabled();
						break;
					
					case self::NEVERREQUESTCAT_PATRONNOTENABLEDLOSTREQUESTS:
						$requestFilterQuery = self::calculateNRPatronRevokedBefore();
						break;

					case self::NEVERREQUESTCAT_PATRONNOTENABLEDSAFEREQUESTS:
						$requestFilterQuery = self::calculateNRPatronRevokedAfter();
						break;

					case self::NEVERREQUESTCAT_PATRONAGE:
						$requestFilterQuery = self::calculateNRPatronAge();
						$requestFilterParams[':NRJoinCase'] = " JOIN patron p ON r.patron_id = p.patron_id LEFT JOIN manifestation m ON r.manifestation_id = m.manifestation_id";
						break;
					
					case self::NEVERREQUESTCAT_PATRONMAXLOANS:
						$requestFilterQuery = self::calculateNRPatronMaxLoans($actualLibraryId);
						$requestFilterParams[':NRJoinCase'] = " JOIN patron p ON r.patron_id = p.patron_id LEFT JOIN manifestation m ON r.manifestation_id = m.manifestation_id";
						break;

					case self::NEVERREQUESTCAT_NOITEMS:
						$requestFilterQuery = self::calculateNRNoItems($actualLibraryId);
						$requestFilterParams[':NRJoinCase'] = " LEFT JOIN manifestation m ON r.manifestation_id = m.manifestation_id LEFT JOIN item i ON r.item_id = i.item_id"; // LEFT JOIN issue iss ON r.issue_id = iss.issue_id";
						break;
					
					case self::NEVERREQUESTCAT_NOITEMSDISTANT:
						$requestFilterQuery = self::calculateNRNoItemsDistant($actualLibraryId);
						$requestFilterParams[':NRJoinCase'] = " LEFT JOIN manifestation m ON r.manifestation_id = m.manifestation_id LEFT JOIN item i ON r.item_id = i.item_id";
						break;
					
					case self::NEVERREQUESTCAT_GENERIC:
					default:	// it seems for now a correct choice ...
						$requestFilterQuery = self::calculateNRGeneric($actualLibraryId);
						$requestFilterParams[':NRJoinCase'] = " JOIN patron p ON r.patron_id = p.patron_id LEFT JOIN manifestation m ON r.manifestation_id = m.manifestation_id LEFT JOIN item i on r.item_id = i.item_id";
						break;
				}
			}	// end of NRRequestCategory part
			
			// item part
			if (array_key_exists('section', $filters))
			{
				$sectionFilter = $filters['section'];
				if ($sectionFilter != "")
				{
					if ($sectionFilter == '**IS*NULL**')
					{
						$itemFilterQuery .= " AND i.section IS NULL ";
					}
					else
					{
						$itemFilterQuery .= " AND i.section = :sectionFilter";
						$itemFilterParams[':sectionFilter'] = $sectionFilter;
					}
				}
			}

			if (array_key_exists('collocation', $filters))
			{
				$collocationFilter = $filters['collocation'];
				
				if ($collocationFilter != "")
				{
					$itemFilterQuery .= " AND i.collocation LIKE :collocationFilter";
					$itemFilterParams[':collocationFilter'] = $collocationFilter . "%";
				}
			}

			if (array_key_exists('actualLibraryId', $filters))
			{
				$filter = $filters['actualLibraryId'];
				
				if ($filter != "")
				{
					$itemFilterQuery .= " AND i.actual_library_id = :actualLibraryIdFilter";
					$itemFilterParams[':actualLibraryIdFilter'] = $filter;
				}
			}

			// request part

			if (array_key_exists('requestDateFrom', $filters))
			{
				$requestDateFromFilter = $filters['requestDateFrom'];
				
				if ($requestDateFromFilter != "")
				{
					$requestFilterQuery .= " AND unix_timestamp(date(r.request_date)) >= :requestDateFromFilter";
					$requestFilterParams[':requestDateFromFilter'] = $requestDateFromFilter;
				}
			}

			if (array_key_exists('requestDateTo', $filters))
			{
				$requestDateToFilter = $filters['requestDateTo'];
				
				if ($requestDateToFilter != "")
				{
					$requestFilterQuery .= " AND unix_timestamp(date(r.request_date)) <= :requestDateToFilter";
					$requestFilterParams[':requestDateToFilter'] = $requestDateToFilter;
				}
			}

			if (array_key_exists('manifestationIdParam', $filters))
			{
				$manifestationIdParamFilter = $filters['manifestationIdParam'];
				
				if ($manifestationIdParamFilter != "" || ($manifestationIdParamFilter == 0))
				{
					if (array_key_exists('itemIdParam', $filters))
					{
						$itemIdParamFilter = $filters['itemIdParam'];
				
						if ($itemIdParamFilter != "" || is_null($itemIdParamFilter))
						{
							if (intval($itemIdParamFilter > 0))
							{
								$requestFilterQuery .= " AND (r.item_id = :objectParamFilter) ";
								$requestFilterParams[':objectParamFilter'] = $itemIdParamFilter;
							}
							else
							{
								$requestFilterQuery .= " AND (r.manifestation_id = :objectParamFilter) ";
								$requestFilterParams[':objectParamFilter'] = $manifestationIdParamFilter;
							}
						}
					}
				}
			}

			if (array_key_exists('patron', $filters))
			{
				$patronFilter = $filters['patron'];
				if ($patronFilter != "")
				{
					$requestFilterQuery .= " AND (r.manifestation_id IN"
										. " (SELECT DISTINCT rr.manifestation_id FROM item_request rr"
										. " WHERE rr.request_status = '" . ItemRequestPeer::STATUS_PENDING . "'"
										. " AND rr.patron_id = " . $patronFilter
										. " AND rr.manifestation_id > 0)"
										. " OR r.item_id IN"
										. " (SELECT DISTINCT rr.item_id FROM item_request rr"
										. " WHERE rr.request_status = '" . ItemRequestPeer::STATUS_PENDING . "'"
										. " AND rr.patron_id = " . $patronFilter
										. " AND rr.manifestation_id = 0 AND rr.item_id > 0))";
					//$requestFilterParams[':patronFilter'] = $patronFilter;
				}
			}

			if (array_key_exists('deliveryLibraryId', $filters))
			{
				$deliveryLibraryIdFilter = $filters['deliveryLibraryId'];
				
				if ($deliveryLibraryIdFilter != "")
				{
					$requestFilterQuery .= " AND r.delivery_library_id = :deliveryLibraryIdFilter";
					$requestFilterParams[':deliveryLibraryIdFilter'] = $deliveryLibraryIdFilter;
				}
			}
			
			if (self::getLLibraryActive()
					&& array_key_exists('maxDistance', $filters))
			{
				$maxDistance = $filters['maxDistance'];
				
				if ($maxDistance != "")
				{
					$requestFilterQuery .= " AND (r.max_distance <= :maxDistanceFilter OR r.max_distance IS NULL) ";
					$requestFilterParams[':maxDistanceFilter'] = $maxDistance;
				}
			}
			
			if (self::getRequestTypeActive()
					&& array_key_exists('requestType', $filters))
			{
				$requestType = $filters['requestType'];
				
				if ($requestType != "")
				{
					if ($requestType === ItemRequestPeer::REQUESTTYPE_NULLVALUESTRING)
					{
						$requestFilterQuery .= " AND r.request_type IS NULL ";
					}
					else
					{
						$requestFilterQuery .= " AND r.request_type = :requestTypeFilter ";
						$requestFilterParams[':requestTypeFilter'] = $requestType;
					}
				}
			}

			if (array_key_exists('excludeRequestIds', $filters))
			{
				$excludeRequestIds = $filters['excludeRequestIds'];
				
				if (count($excludeRequestIds) > 0)
				{
					$excludeRequestIds = implode(",", $excludeRequestIds);
					$requestFilterQuery .= " AND r.request_id NOT IN ($excludeRequestIds)";
					//$requestFilterParams[':excludeRequestIds'] = $excludeRequestIds;
				}
			}
		}	// end of: if $filters is not an array: probably an error

		return array(	self::_itemFilterQuery => $itemFilterQuery,
						self::_itemFilterParams => $itemFilterParams,
						self::_requestFilterQuery => $requestFilterQuery,
						self::_requestFilterParams => $requestFilterParams );
	}

	private static function	calculateNRLoanableSince()
	{
		// loanable_since part (inverted)
		return " ((SELECT IF(mm.loanable_since IS NULL, NULL, IF(mm.loanable_since < NOW(), NULL, TRUE)) FROM manifestation mm WHERE "
				. "mm.manifestation_id = r.manifestation_id AND r.manifestation_id > 0) IS NOT NULL) ";
	}
	
	private static function calculateNRPatronNotEnabled()
	{
		return " (SELECT COUNT(*) "
				. "FROM patron p "
				. "WHERE (r.patron_id = p.patron_id) "
				. "AND (r.patron_id IS NOT NULL AND p.patron_status IN ('" . implode("','", PatronPeer::getPermanentNonActivePatronStatus()) . "')) "
				. " > 0) ";
	}

	private static function calculateNRPatronRevokedBefore()
	{
		return " (SELECT COUNT(*) "
				. "FROM patron p "
				. "WHERE (r.patron_id = p.patron_id) "
				. "AND (r.patron_id IS NOT NULL "
				. "AND p.patron_status = '" . PatronPeer::STATUS_AUTOMATICREVOKED . "' "
				. "AND p.custom2 IS NOT NULL AND p.custom2 != '' AND r.expire_date <= p.custom2) "
				. " > 0) ";
	}

	private static function calculateNRPatronRevokedAfter()
	{
		return " (SELECT COUNT(*) "
				. "FROM patron p "
				. "WHERE (r.patron_id = p.patron_id) "
				. "AND (r.patron_id IS NOT NULL "
				. "AND p.patron_status = '" . PatronPeer::STATUS_AUTOMATICREVOKED . "' "
				. "AND p.custom2 IS NOT NULL AND p.custom2 != '' AND r.expire_date > p.custom2) "
				. " > 0) ";
	}
	
	private static function calculateNRPatronAge()
	{
		return " (m.rating IS NOT NULL AND p.birth_date IS NOT NULL AND m.rating > (DATEDIFF(now( ), p.birth_date ) / 365.25) ) ";
	}

	private static function calculateNRPatronMaxLoans($actualLibraryId)
	{
		// case of patron that has reached loans limit
		$maxExtraLoans = ClavisParamPeer::getParam('MAXEXTRALOANS', 0);
		$availableClasses = "'" . implode(array_merge(	ItemPeer::getLoanClassesAvailable(null, null, true), 
														ItemPeer::getLoanClassesLocallyAvailable(null, true)), "','") . "'";
		
		$activeRequestStatus = "'" . implode(ItemRequestPeer::getActiveStatus(), "','") . "'";
		
		return " (r.external_library_id is null AND"
					. " ("
									. "(	
											SELECT count(*)
											FROM item i2 
											WHERE i2.patron_id = r.patron_id
												AND i2.item_media = COALESCE(
																				(
																					SELECT i1.item_media FROM item i1 
																					WHERE (i1.manifestation_id = r.manifestation_id AND r.manifestation_id > 0) 
																					AND i1.actual_library_id = {$actualLibraryId}
																					AND i1.loan_class IN ({$availableClasses})
																					LIMIT 1
																				),
																				(
																					SELECT i1.item_media FROM item i1 
																					WHERE (r.manifestation_id = 0 AND i1.manifestation_id = 0 AND i1.item_id = r.item_id) 
																					AND i1.actual_library_id = {$actualLibraryId}
																					AND i1.loan_class IN ({$availableClasses})
																					LIMIT 1
																				)
																			)
										)
										>= {$maxExtraLoans}
										+  (
												SELECT cp.param_value FROM clavis_param cp
												WHERE cp.param_class = concat('MAXLOANSALLOWED_', p.loan_class) 
													AND cp.param_name = COALESCE(
																					(
																						SELECT i1.item_media FROM item i1 
																						WHERE (i1.manifestation_id = r.manifestation_id AND r.manifestation_id > 0)
																						AND i1.actual_library_id = {$actualLibraryId} 
																						AND i1.loan_class IN ({$availableClasses})
																						LIMIT 1
																					),
																					(
																						SELECT i1.item_media FROM item i1 
																						WHERE (r.manifestation_id = 0 AND i1.manifestation_id = 0 AND i1.item_id = r.item_id) 
																						AND i1.actual_library_id = {$actualLibraryId}
																						AND i1.loan_class IN ({$availableClasses})
																						LIMIT 1
																					)
																				)
											)
										)"

						. " OR 
										(
											(
												SELECT count(*)
												FROM item i2 
												WHERE i2.patron_id = r.patron_id
											)
											>= {$maxExtraLoans} 
											+ (
												IF  (p.max_loans IS NOT NULL AND p.max_loans > 0,
														p.max_loans,
														(
															SELECT cp.param_value FROM clavis_param cp 
															WHERE cp.param_class =  concat('MAXLOANSALLOWED_', p. loan_class) 
															AND cp.param_name =  '0' 
															LIMIT 1
														)
											  )
										)"
				
								/// MAXOPERATIONS part
						. " OR	
										(
												(
													SELECT count(*)
													FROM item i2 
													WHERE i2.patron_id = r.patron_id
												)
												+(
													SELECT count(*)
													FROM item_request ir2 
													WHERE ir2.patron_id = r.patron_id AND request_status IN ({$activeRequestStatus})
												 )
												>= {$maxExtraLoans} 
												+ (
													SELECT cp.param_value FROM clavis_param cp 
													WHERE cp.param_class = concat('MAXOPERATIONS_', p.loan_class)
													AND cp.param_name = '0'
													LIMIT 1
												   )
									    )
					  )
				)";
	}
	
	private static function calculateNRNoItems($actualLibraryId)
	{
		$basinSubQuery = self::getLLibraryActive() ? self::calculateNeverBasinQuery() : "";
		
		$condArray = array(	"(r.manifestation_id > 0 AND i.manifestation_id = r.manifestation_id AND r.issue_id IS NULL AND r.item_id IS NULL )",
							"(r.manifestation_id > 0 AND i.manifestation_id = r.manifestation_id AND r.issue_id IS NOT NULL AND r.issue_id = i.issue_id AND r.item_id IS NULL)",
							"(r.manifestation_id > 0 AND i.manifestation_id = r.manifestation_id AND r.item_id IS NOT NULL AND r.item_id = i.item_id)",
							"(r.manifestation_id = 0 AND r.item_id = i.item_id)" );
		
		$itemStatusString = implode(ItemStatus::getItemStatusManageable(), "','");
		$loanClassesAvailableString = implode(ItemPeer::getLoanClassesAvailable(null, null, true), "','");
		$loanClassesLocallyAvailable = implode(ItemPeer::getLoanClassesLocallyAvailable(null, true), "','");
		$query = "r.delivery_library_id = {$actualLibraryId} AND (";
		foreach ($condArray as $condition)
		{
			$query .= " 
					(SELECT COUNT(*) "
					. "FROM item i " //FORCE INDEX  (item_request_speedup) "
					. "WHERE ( " . $condition . ")"

						. " AND ("

								. ($basinSubQuery != "" 
										? " ($basinSubQuery) AND "
										: "")


								. " i.item_status IN ('" . $itemStatusString . "') "

								. " AND ((r.issue_id IS NOT NULL AND i.issue_status = '" . ItemPeer::ISSUESTATUS_ARRIVED . "') OR r.issue_id IS NULL)"	

								. " AND (i.LOAN_CLASS IN ('" . $loanClassesAvailableString . "') "
										. " OR (i.home_library_id = {$actualLibraryId} AND i.LOAN_CLASS IN ('" . $loanClassesLocallyAvailable . "'))) "

							. " ))+";

		}

		$query = substr($query, 0, strlen($query)-1) . ") = 0 ";
		
		return $query;
	}
	
	private static function calculateNRNoItemsDistant($actualLibraryId)
	{
		$basinSubQuery = self::getLLibraryActive() ? self::calculateDistantNeverBasinQuery() : "";
		
		$condArray = array(	"(r.manifestation_id > 0 AND i.manifestation_id = r.manifestation_id AND r.issue_id IS NULL AND r.item_id IS NULL )",
							"(r.manifestation_id > 0 AND i.manifestation_id = r.manifestation_id AND r.issue_id IS NOT NULL AND r.issue_id = i.issue_id AND r.item_id IS NULL)",
							"(r.manifestation_id > 0 AND i.manifestation_id = r.manifestation_id AND r.item_id IS NOT NULL AND r.item_id = i.item_id)",
							"(r.manifestation_id = 0 AND r.item_id = i.item_id)" );
		
		$itemStatusString = implode(ItemStatus::getItemStatusManageable(), "','");
		$loanClassesAvailableString = implode(ItemPeer::getLoanClassesAvailable(null, null, true), "','");
		$loanClassesLocallyAvailable = implode(ItemPeer::getLoanClassesLocallyAvailable(null, true), "','");
		$query = "r.delivery_library_id = {$actualLibraryId} AND (";
		foreach ($condArray as $condition)
		{
			$query .= " 
					(SELECT COUNT(*) "
					. "FROM item i "
					. "WHERE ( " . $condition . ")"

						. " AND ("

								. ($basinSubQuery != "" 
										? " ($basinSubQuery) AND "
										: "")


								. " i.item_status IN ('" . $itemStatusString . "') "

								. " AND ((r.issue_id IS NOT NULL AND i.issue_status = '" . ItemPeer::ISSUESTATUS_ARRIVED . "') OR r.issue_id IS NULL)"	

								. " AND (i.LOAN_CLASS IN ('" . $loanClassesAvailableString . "') "
										. " OR (i.home_library_id = {$actualLibraryId} AND i.LOAN_CLASS IN ('" . $loanClassesLocallyAvailable . "'))) "

							. " ))+";

		}

		$innerQuery = substr($query, 0, strlen($query)-1) . ") = 0 ";
		
		$query = "SELECT r.request_id FROM item_request r "
			. "LEFT JOIN manifestation m ON r.manifestation_id = m.manifestation_id LEFT JOIN item i ON r.item_id = i.item_id"
			. " WHERE r.request_status ='" . ItemRequestPeer::STATUS_PENDING 
			. "' AND (" . $innerQuery . ")";

		$connection = Propel::getConnection();
		$stmt = $connection->prepare($query);
		$stmt->execute(); //$queryStringArray['params']);

		$innerIndexes = array();
		while ($row = $stmt->fetch(PDO::FETCH_ASSOC))
			$innerIndexes[] = (int) $row['request_id'];
		
		$condArray = array(	"(r.manifestation_id > 0 AND i.manifestation_id = r.manifestation_id AND r.issue_id IS NULL AND r.item_id IS NULL )",
							"(r.manifestation_id > 0 AND i.manifestation_id = r.manifestation_id AND r.issue_id IS NOT NULL AND r.issue_id = i.issue_id AND r.item_id IS NULL)",
							"(r.manifestation_id > 0 AND i.manifestation_id = r.manifestation_id AND r.item_id IS NOT NULL AND r.item_id = i.item_id)",
							"(r.manifestation_id = 0 AND r.item_id = i.item_id)" );
		
		//$itemStatusString = implode(ItemStatus::getItemStatusManageable(), "','");
		//$loanClassesAvailableString = implode(ItemPeer::getLoanClassesAvailable(), "','");
		//$loanClassesLocallyAvailable = implode(ItemPeer::getLoanClassesLocallyAvailable(), "','");
		$addedIndexesString = implode($innerIndexes, ",");
		
		$query = "r.delivery_library_id = {$actualLibraryId} AND (";
		foreach ($condArray as $condition)
		{
			$query .= " 
					(SELECT COUNT(*) "
					. "FROM item i " //FORCE INDEX  (item_request_speedup) "
					. "WHERE ( " . $condition . ")"

						. " AND ("


								. " i.item_status IN ('" . $itemStatusString . "') "

								. " AND ((r.issue_id IS NOT NULL AND i.issue_status = '" . ItemPeer::ISSUESTATUS_ARRIVED . "') OR r.issue_id IS NULL)"	

								. " AND (i.LOAN_CLASS IN ('" . $loanClassesAvailableString . "') "
										. " OR (i.home_library_id = {$actualLibraryId} AND i.LOAN_CLASS IN ('" . $loanClassesLocallyAvailable . "'))) "

							. " ))+";

		}

		$query = substr($query, 0, strlen($query)-1) . ") > 0 ";

		if ($addedIndexesString != "")
			$query .= " AND r.request_id IN ({$addedIndexesString})";
			
		return $query;
	}
	
	private static function calculateNRGeneric($actualLibraryId)
	{
		///////  test     $basinSubQuery = self::getLLibraryActive() ? self::calculateNeverBasinQuery() : "";
		$maxExtraLoans = ClavisParamPeer::getParam('MAXEXTRALOANS', 0);
		
		// generic part
		$queryString = " ("
							. self::calculateNRNoItems($actualLibraryId)
							
							// NEW  mbrancaliontemp, patron availability part
							. " OR ((r.patron_id IS NOT NULL AND p.patron_status != '" . PatronPeer::STATUS_ENABLED . "'))"

							// loanable_since part (inverted)	
							. " OR (IF(m.loanable_since IS NULL, NULL, IF(m.loanable_since > NOW() AND r.manifestation_id > 0, TRUE, NULL )) IS NOT NULL)"

							. " OR (m.rating IS NOT NULL AND p.birth_date IS NOT NULL AND m.rating > (DATEDIFF(now( ), p.birth_date ) / 365.25)) "
								
						// case tessera piena generic	
							. " OR " . self::calculateNRPatronMaxLoans($actualLibraryId) 
								
						// delivery library must be active
							. " OR ((SELECT library_status FROM library WHERE library_id = r.delivery_library_id) != '" . LibraryPeer::STATUS_ACTIVE . "')
											
						 )";

		return $queryString;
	}
	
	private function calculateRequestsQueryString(	$actualLibraryId,
													$currentIndexPage,
													$pageSize,
													$filters = array(),
													$itemIdParam = 0)
	{
		$maxExtraLoans = ClavisParamPeer::getParam('MAXEXTRALOANS', 0);
		$itemMatchFlag = false;
		$manifestationIdParam = 0;
		$issueIdParam = null;

		if (intval($itemIdParam) > 0)
		{
			$item = ItemQuery::create()	->findPk($itemIdParam);
			
			if ($item instanceof Item)
			{
				$manifestationIdParam = $item->getManifestationId();
				$issueIdParam = $item->getIssueId();
				$itemMatchFlag = true;
			}
		}

		$myLibrarianId = $this->getUser()->getId();
		$basinSubQuery = self::getLLibraryActive() ? self::calculateBasinQuery() : "";

		$itemFilterQuery = "";
		$requestFilterQuery = "";
		$filterQuery = self::calculateFilterQuery($filters);

		if (array_key_exists(self::_itemFilterQuery, $filterQuery))
			$itemFilterQuery = $filterQuery[self::_itemFilterQuery];

		if (array_key_exists(self::_requestFilterQuery, $filterQuery))
			$requestFilterQuery = $filterQuery[self::_requestFilterQuery];

		if (array_key_exists(self::_itemFilterParams, $filterQuery))
			$itemFilterParams = $filterQuery[self::_itemFilterParams];

		if (array_key_exists(self::_requestFilterParams, $filterQuery))
			$requestFilterParams = $filterQuery[self::_requestFilterParams];

		$queryString = "SELECT " .
//				"MINrequest_id) AS request_id," .
//				"MIN(request_date) AS request_date," .

				"MIN(concat_ws( '" . self::IDATA_SEPARATOR . "', request_date, request_id)) AS requestIdCombo," .
				"IF(r.manifestation_id = 0, concat_ws( '" . self::IDCOMBO_SEPARATOR . "', '" . self::OOCSTRING . "', item_id), concat_ws( '" .
				self::IDCOMBO_SEPARATOR . "', IFNULL(r.manifestation_id, 0), IFNULL(item_id, 0), IFNULL(issue_id, 0))) as idcombo," .
				"(SELECT CONCAT_WS('" . self::IDATA_SEPARATOR . "', " .
				"IFNULL(item_id,'" . self::NULLSTRING . "'), " .
				"IFNULL(issue_id,'" . self::NULLSTRING . "'), " .
				"IFNULL(inventory_serie_id,'" . self::NULLSTRING . "'), " .
				"IFNULL(inventory_number,'" . self::NULLSTRING . "'), " .
				"IFNULL(section,'" . self::NULLSTRING . "'), " .
				"IFNULL(collocation,'" . self::NULLSTRING . "'), " .
				"IFNULL(specification,'" . self::NULLSTRING . "'), " .
				"IFNULL(sequence1,'" . self::NULLSTRING . "'), " .
				"IFNULL(sequence2,'" . self::NULLSTRING . "'), " .
				"IF(last_seen = date(now()),true,false), home_library_id ) " .
				"FROM item i " .
				"FORCE INDEX  (item_request_speedup) " .
				"WHERE (i.manifestation_id = r.manifestation_id) AND i.actual_library_id='{$actualLibraryId}' " .
				"AND i.loan_status IN ('" . implode(ItemPeer::getLoanStatusAvailable(), "','") . "') " .
				"AND ((r.issue_id IS NOT NULL " .
				"AND i.issue_status = '" . ItemPeer::ISSUESTATUS_ARRIVED . "') " .
				"OR r.issue_id IS NULL) " .
				"AND (i.LOAN_CLASS IN ('" . implode(ItemPeer::getLoanClassesAvailable(true), "','") . "') " .
				"OR (r.delivery_library_id = i.home_library_id AND i.LOAN_CLASS IN ('" . implode(ItemPeer::getLoanClassesLocallyAvailable(true), "','") . "'))) " .
				"AND ((r.item_id IS NOT NULL AND i.item_id = r.item_id) " .
				"OR (r.item_id IS NULL AND r.issue_id IS NOT NULL AND i.issue_id = r.issue_id) " .
				"OR (r.item_id IS NULL AND (i.issue_id IS NULL OR i.issue_id=0))) " .
				"LIMIT 1) AS idata, " . //	item_id	//	issue_id//	inv_ser	//	inv_num	//	sec	//	coll // spec // seq1 // seq2

				"IF(r.manifestation_id = 0, " .
				"(SELECT SUBSTRING(title,1,80) FROM item WHERE item_id = r.item_id), " .
				"SUBSTRING(m.title,1,80)) AS title," .
				"(SELECT COUNT(*) FROM item i WHERE (i.manifestation_id = r.manifestation_id)) AS tcount," .
				"(SELECT COUNT(*) " .
				"FROM item i FORCE INDEX  (item_request_speedup) " .
				"WHERE (i.manifestation_id = r.manifestation_id) " .
				"AND i.actual_library_id= {$actualLibraryId} " .
				"AND i.loan_status IN ('" . implode(ItemPeer::getLoanStatusAvailable(), "','") . "') " .
				"AND ((r.issue_id IS NOT NULL AND i.issue_status = '" . ItemPeer::ISSUESTATUS_ARRIVED . "') " .
				"OR r.issue_id IS NULL) " .
				"AND (i.LOAN_CLASS IN ('" . implode(ItemPeer::getLoanClassesAvailable(true), "','") . "') " .
				"OR (r.delivery_library_id = i.home_library_id AND i.LOAN_CLASS IN ('" . implode(ItemPeer::getLoanClassesLocallyAvailable(true), "','") . "'))) " .
				"AND ((r.item_id IS NOT NULL AND i.item_id = r.item_id) " .
				"OR (r.item_id IS NULL AND r.issue_id IS NOT NULL AND i.issue_id = r.issue_id) " .
				"OR (r.item_id IS NULL AND (i.issue_id IS NULL OR i.issue_id=0))) " .
				") AS icount, " .
						
				"(SELECT COUNT(*) FROM item_request r2 " .
				"WHERE ((r2.manifestation_id = r.manifestation_id AND r2.manifestation_id > 0) " .
				" OR (r2.item_id = r.item_id AND r.manifestation_id = 0 AND r2.manifestation_id = 0))" .
				" AND r2.request_status = '" . ItemRequestPeer::STATUS_WORKING . "' AND r2.librarian_id = '{$myLibrarianId}' " .
				") AS mcount, " .
				"COUNT(*) AS queue " .
				//// END SELECT subqueries
				"FROM item_request r LEFT JOIN patron p ON p.patron_id = r.patron_id LEFT JOIN manifestation m ON m.manifestation_id = r.manifestation_id " .
				/// ** WHERE PART **

				"WHERE r.request_status ='" . ItemRequestPeer::STATUS_PENDING . "' " .
				// loanable_since part		
				" AND (m.loanable_since IS NULL OR (m.loanable_since IS NOT NULL AND m.loanable_since < now() )) " .
				" AND (SELECT library_status FROM library WHERE library_id = r.delivery_library_id) = '" . LibraryPeer::STATUS_ACTIVE . "' " .
				$basinSubQuery . //// basin part

				$requestFilterQuery .
				" AND (r.patron_id IS NULL OR (p.patron_status = '" . PatronPeer::STATUS_ENABLED . "')" .
				" AND (m.rating IS NULL OR p.birth_date IS NULL OR m.rating <= (DATEDIFF( now( ) , p.birth_date ) / 365.25)  )" .
				") " .
				($itemMatchFlag ? " AND (r.manifestation_id = {$manifestationIdParam}) "
						. ($manifestationIdParam == 0 ? "AND (r.item_id = {$itemIdParam}) " : " ")
						. (!is_null($issueIdParam) ? "AND (r.issue_id = {$issueIdParam}) " : " ") : " ") .
				" AND (SELECT COUNT(*) " .
					"FROM item i FORCE INDEX (item_request_speedup) " .
					"WHERE" . 

					" (i.manifestation_id = r.manifestation_id) " .
					$itemFilterQuery .
					" AND i.actual_library_id= {$actualLibraryId} " .
					" AND i.loan_status IN ('" . implode(ItemPeer::getLoanStatusAvailable(), "','") . "') " .
					"AND ((r.issue_id IS NOT NULL AND i.issue_status = '" . ItemPeer::ISSUESTATUS_ARRIVED . "') " .
					"OR r.issue_id IS NULL) " .
					"AND (i.LOAN_CLASS IN ('" . implode(ItemPeer::getLoanClassesAvailable(true), "','") . "') " .
					"OR (r.delivery_library_id = i.home_library_id AND i.LOAN_CLASS IN ('" . implode(ItemPeer::getLoanClassesLocallyAvailable(true), "','") . "'))) " .
					"AND ((r.item_id IS NOT NULL AND i.item_id = r.item_id) " .
					"OR (r.item_id IS NULL AND r.issue_id IS NOT NULL AND i.issue_id = r.issue_id) " .
					"OR (r.item_id IS NULL AND (i.issue_id IS NULL OR i.issue_id=0))) " .
					") > 0 " .
						
				"AND ((SELECT COUNT(*) " .
					"FROM item i " .
					"FORCE INDEX  (item_request_speedup) " .
					"WHERE" . 

					" (i.manifestation_id = r.manifestation_id) " .

					" AND i.actual_library_id=r.delivery_library_id " .
					" AND i.loan_status IN ('" . implode(ItemPeer::getLoanStatusAvailable(), "','") . "') " .
					"AND ((r.issue_id IS NOT NULL AND i.issue_status = '" . ItemPeer::ISSUESTATUS_ARRIVED . "') " .
					"OR r.issue_id IS NULL) " .
					"AND (i.loan_class IN ('" . implode(ItemPeer::getLoanClassesAvailable(true), "','") . "') " .
					"OR (r.delivery_library_id = i.home_library_id AND i.LOAN_CLASS IN ('" . implode(ItemPeer::getLoanClassesLocallyAvailable(true), "','") . "'))) " .
					"AND ((r.item_id IS NOT NULL AND i.item_id = r.item_id) " .
					"OR (r.item_id IS NULL AND r.issue_id IS NOT NULL AND i.issue_id = r.issue_id) " .
					"OR (r.item_id IS NULL AND (i.issue_id IS NULL OR i.issue_id=0))) " .
					") = 0 " .
				" OR r.delivery_library_id = {$actualLibraryId}) " .
				" AND (  r.external_library_id > 0 OR
				   (
					   (SELECT count(*)
						   FROM item i2 
						   WHERE i2.patron_id = r.patron_id
						   AND i2.item_media = (
							   SELECT i1.item_media 
							   FROM item i1 
							   WHERE (i1.manifestation_id = r.manifestation_id) AND (r.manifestation_id > 0 OR
							         (r.manifestation_id = 0 AND i1.item_id = r.item_id)) AND
							          i1.actual_library_id = {$actualLibraryId} AND
							          i1.loan_class IN ('" . implode(array_merge(ItemPeer::getLoanClassesAvailable(true), ItemPeer::getLoanClassesLocallyAvailable(true)), "','")  . "')
							   LIMIT 1
							   )
					   ) < {$maxExtraLoans} + (SELECT cp.param_value FROM clavis_param cp WHERE cp.param_class = concat('MAXLOANSALLOWED_',p.loan_class) AND cp.param_name = (
							   SELECT i1.item_media 
							   FROM item i1 
							   WHERE (i1.manifestation_id = r.manifestation_id AND (r.manifestation_id > 0 OR
							       (r.manifestation_id = 0 AND i1.item_id = r.item_id))) AND
							        i1.actual_library_id = {$actualLibraryId} AND
							        i1.loan_class IN ('" . implode(array_merge(ItemPeer::getLoanClassesAvailable(true), ItemPeer::getLoanClassesLocallyAvailable(true)), "','")  . "')
							   LIMIT 1
							   )
					   ) OR (p.max_loans IS NOT NULL AND p.max_loans > 0))
					   AND
					   (
                           (SELECT count(*)
                               FROM item i2
                               WHERE i2.patron_id = r.patron_id

                           ) < {$maxExtraLoans} + IF((p.max_loans IS NOT NULL AND p.max_loans > 0),p.max_loans,(SELECT cp.param_value FROM clavis_param cp WHERE cp.param_class =  concat('MAXLOANSALLOWED_',p.loan_class) AND cp.param_name =  '0') )
				       )
                       AND
                       (
                           (SELECT count(*)
                               FROM item i2
                               WHERE i2.patron_id = r.patron_id
                           ) +
                           (SELECT count(*)
                               FROM item_request ir2
                               WHERE ir2.patron_id = r.patron_id AND request_status IN ('A','D')
                           ) < {$maxExtraLoans} + (SELECT cp.param_value FROM clavis_param cp WHERE cp.param_class =  concat('MAXOPERATIONS_',p.loan_class) AND cp.param_name =  '0')
                       )
				   )
				" .
				// ** GROUP PART **		
				"GROUP BY IF( r.manifestation_id = 0, " .
				"concat_ws( '" . self::IDCOMBO_SEPARATOR . "', '" . self::OOCSTRING . "', item_id), concat_ws('" . self::IDCOMBO_SEPARATOR . "', r.manifestation_id, issue_id)) " .
				"HAVING (icount-mcount) > 0 ORDER BY r.manifestation_id, requestIdCombo ASC " .
				(intval($pageSize) > 0 ?
						" LIMIT {$pageSize} OFFSET " . ($pageSize * $currentIndexPage) :
						'');

		return array(	'querystring' => $queryString,
						'params' => array_merge($itemFilterParams, $requestFilterParams) );
	}

	private function calculateRequestsCountString(	$actualLibraryId,
													$filters = array(),
													$itemIdParam = 0,
													$manifestationIdParam = 0,
													$newLoanFlag = false)
	{
		$maxExtraLoans = ClavisParamPeer::getParam('MAXEXTRALOANS', 0);
		$itemMatchFlag = false;
		$manifestationMatchFlag = false;

		if (intval($itemIdParam) > 0)
		{
			$item = ItemQuery::create()	->findPk($itemIdParam);

			if ($item instanceof Item)
			{
				$itemMatchFlag = true;
				$manifestationIdParam = $item->getManifestationId();
				$issueIdParam = $item->getIssueId();
			}
		}
		else
		{
			if (intval($manifestationIdParam) > 0)
				$manifestationMatchFlag = true;
		}
		
		$basinSubQuery = self::getLLibraryActive()
							? self::calculateBasinQuery()
							: "";
		
		$fakeReturnSubQuery = ($newLoanFlag && (intval($itemIdParam) > 0)
									? " OR (i.item_id = {$itemIdParam})"
									: "");
							
		$alsoWorkingSubQuery = ($newLoanFlag
									? " OR ( r.request_status='" . ItemRequestPeer::STATUS_WORKING . "' " .  
										" AND ( SELECT COUNT(*) FROM librarian_session ls WHERE ls.librarian_id = r.librarian_id AND ls.current_library_id = {$actualLibraryId} AND ls.end_date IS NULL ) > 0)"
									: "");

		$itemFilterQuery = "";
		$requestFilterQuery = "";
		$filterQuery = self::calculateFilterQuery($filters);

		if (array_key_exists(self::_itemFilterQuery, $filterQuery))
			$itemFilterQuery = $filterQuery[self::_itemFilterQuery];

		if (array_key_exists(self::_requestFilterQuery, $filterQuery))
			$requestFilterQuery = $filterQuery[self::_requestFilterQuery];

		if (array_key_exists(self::_itemFilterParams, $filterQuery))
			$itemFilterParams = $filterQuery[self::_itemFilterParams];

		if (array_key_exists(self::_requestFilterParams, $filterQuery))
			$requestFilterParams = $filterQuery[self::_requestFilterParams];

		$myLibrarianId = $this->getUser()->getId();

		$queryString = "
			SELECT " .
//				"MIN(request_id) AS request_id," .
//				"MIN(request_date) AS request_date," .

				"(SELECT COUNT(*)
				 	FROM item i
				 	 FORCE INDEX (item_request_speedup) WHERE (i.manifestation_id = r.manifestation_id)
				  		AND (i.actual_library_id='{$actualLibraryId}' " . $fakeReturnSubQuery . ")" .
				" AND (i.loan_status IN ('" . implode(ItemPeer::getLoanStatusAvailable(), "','") . "')" . $fakeReturnSubQuery . ")
						AND ((r.issue_id IS NOT NULL AND i.issue_status='" . ItemPeer::ISSUESTATUS_ARRIVED . "')
						 	OR r.issue_id IS NULL)
						AND (i.loan_class IN ('" . implode(ItemPeer::getLoanClassesAvailable(true), "','") . "')
						 	OR (r.delivery_library_id = i.home_library_id AND i.loan_class IN ('" . implode(ItemPeer::getLoanClassesLocallyAvailable(true), "','") . "')))
						AND ((r.item_id IS NOT NULL AND i.item_id = r.item_id)
							OR (r.item_id IS NULL AND r.issue_id IS NOT NULL AND i.issue_id = r.issue_id)
							OR (r.item_id IS NULL AND (i.issue_id IS NULL OR i.issue_id=0)))
				) AS icount,
				(SELECT COUNT(*)
					FROM item_request r2
					WHERE ((r2.manifestation_id = r.manifestation_id AND r2.manifestation_id > 0)
						 OR (r2.item_id = r.item_id AND r.manifestation_id = 0 AND r2.manifestation_id = 0))
			 			AND r2.request_status = '" . ItemRequestPeer::STATUS_WORKING . "' AND r2.librarian_id = '{$myLibrarianId}' " .
				") AS mcount " .
				"FROM item_request r LEFT JOIN patron p ON p.patron_id = r.patron_id LEFT JOIN manifestation m ON m.manifestation_id = r.manifestation_id " .
				/// ** WHERE PART **
				"WHERE " .
				" (r.request_status='" . ItemRequestPeer::STATUS_PENDING . "' " . $alsoWorkingSubQuery . ")" .
				// loanable_since part		
				" AND (m.loanable_since IS NULL OR (m.loanable_since IS NOT NULL AND m.loanable_since < now() ))  " .
				" AND (SELECT library_status FROM library WHERE library_id = r.delivery_library_id) = '" . LibraryPeer::STATUS_ACTIVE . "' " .
				$basinSubQuery . //// basin part

				$requestFilterQuery .
				" AND (r.patron_id IS NULL OR p.patron_status = '" . PatronPeer::STATUS_ENABLED . "')" .
				" AND (m.rating IS NULL OR p.birth_date IS NULL OR m.rating <= (DATEDIFF( now( ) , p.birth_date ) / 365.25 )) " .
				($itemMatchFlag ? " AND (r.manifestation_id = {$manifestationIdParam}) "
						. ($manifestationIdParam == 0 ? "AND (r.item_id = {$itemIdParam}) " : " ")
						. (!is_null($issueIdParam) ? "AND (r.issue_id = {$issueIdParam}) " : " ") : " ") .
				($manifestationMatchFlag ? " AND (r.manifestation_id = {$manifestationIdParam}) " : "") .
				" AND (SELECT COUNT(*)
				 	FROM item i
				 	 FORCE INDEX (item_request_speedup) " .
				"WHERE " .
				" (i.manifestation_id = r.manifestation_id) " .
				$itemFilterQuery .
				" AND (i.actual_library_id='{$actualLibraryId}'" . $fakeReturnSubQuery . ")" .
				" AND (i.loan_status IN ('" . implode(ItemPeer::getLoanStatusAvailable(), "','") . "')" . $fakeReturnSubQuery . ")
						AND ((r.issue_id IS NOT NULL AND i.issue_status='" . ItemPeer::ISSUESTATUS_ARRIVED . "')
						 	OR r.issue_id IS NULL)
						AND (i.loan_class IN ('" . implode(ItemPeer::getLoanClassesAvailable(true), "','") . "')
						 	OR (r.delivery_library_id = i.home_library_id AND i.loan_class IN ('" . implode(ItemPeer::getLoanClassesLocallyAvailable(true), "','") . "')))
						AND ((r.item_id IS NOT NULL AND i.item_id = r.item_id)
							OR (r.item_id IS NULL AND r.issue_id IS NOT NULL AND i.issue_id = r.issue_id)
							OR (r.item_id IS NULL AND (i.issue_id IS NULL OR i.issue_id=0)))) > 0 " .
				"AND ((SELECT COUNT(*)
				 			FROM item i
				 			 FORCE INDEX (item_request_speedup) " .
				"WHERE " .
				" (i.manifestation_id = r.manifestation_id) " .
				" AND i.actual_library_id=r.delivery_library_id
								AND (i.loan_status IN ('" . implode(ItemPeer::getLoanStatusAvailable(), "','") . "')" . $fakeReturnSubQuery . ")
								AND ((r.issue_id IS NOT NULL AND i.issue_status = '" . ItemPeer::ISSUESTATUS_ARRIVED . "')
									OR (r.issue_id IS NULL OR r.issue_id=0))
								AND (i.loan_class IN ('" . implode(ItemPeer::getLoanClassesAvailable(true), "','") . "')
									OR (r.delivery_library_id = i.home_library_id AND i.loan_class IN ('" . implode(ItemPeer::getLoanClassesLocallyAvailable(true), "','") . "')))
								AND ((r.item_id IS NOT NULL AND i.item_id = r.item_id)
									OR (r.item_id IS NULL AND r.issue_id IS NOT NULL AND i.issue_id = r.issue_id)
									OR (r.item_id IS NULL AND (i.issue_id IS NULL OR i.issue_id=0)))
						) = 0 OR r.delivery_library_id = {$actualLibraryId}) " .
				" AND ( r.external_library_id > 0 OR (
						((SELECT count(*) 
							FROM item i2 
							WHERE i2.patron_id = r.patron_id 
							AND i2.item_media = (
								SELECT i1.item_media 
								FROM item i1 
								WHERE (i1.manifestation_id = r.manifestation_id) AND
								      (r.manifestation_id > 0 OR (r.manifestation_id = 0 AND i1.item_id = r.item_id)) AND
							          i1.actual_library_id = {$actualLibraryId} AND
							          i1.loan_class IN ('" . implode(array_merge(ItemPeer::getLoanClassesAvailable(true), ItemPeer::getLoanClassesLocallyAvailable(true)), "','")  . "')
								LIMIT 1
								)
						) <  {$maxExtraLoans} + (SELECT cp.param_value FROM clavis_param cp WHERE cp.param_class =  concat('MAXLOANSALLOWED_',p.loan_class) AND cp.param_name = (
								SELECT i1.item_media 
								FROM item i1 
								WHERE (i1.manifestation_id = r.manifestation_id) AND
								      (r.manifestation_id > 0 OR (r.manifestation_id = 0 AND i1.item_id = r.item_id)) AND
							          i1.actual_library_id = {$actualLibraryId} AND
							          i1.loan_class IN ('" . implode(array_merge(ItemPeer::getLoanClassesAvailable(true), ItemPeer::getLoanClassesLocallyAvailable(true)), "','")  . "')
								LIMIT 1
								)
						) OR (p.max_loans IS NOT NULL AND p.max_loans > 0))
						AND
						(SELECT count(*) 
							FROM item i2 
							WHERE i2.patron_id = r.patron_id 

						) <  {$maxExtraLoans} + IF((p.max_loans IS NOT NULL AND p.max_loans > 0),p.max_loans,(SELECT cp.param_value FROM clavis_param cp WHERE cp.param_class =  concat('MAXLOANSALLOWED_',p.loan_class) AND cp.param_name =  '0') )
						AND
                       (
                           (SELECT count(*)
                               FROM item i2
                               WHERE i2.patron_id = r.patron_id
                           ) +
                           (SELECT count(*)
                               FROM item_request ir2
                               WHERE ir2.patron_id = r.patron_id AND request_status IN ('A','D')
                           ) < {$maxExtraLoans} + (SELECT cp.param_value FROM clavis_param cp WHERE cp.param_class =  concat('MAXOPERATIONS_',p.loan_class) AND cp.param_name =  '0')
                       )

					)) " .			

				" GROUP BY IF( r.manifestation_id = 0, concat_ws('" . self::IDCOMBO_SEPARATOR . "', '" . self::OOCSTRING . "', item_id), concat_ws('" . self::IDCOMBO_SEPARATOR . "', r.manifestation_id, issue_id))
				HAVING (icount - mcount) > 0";

		return array(	'querystring' => $queryString,
						'params' => array_merge($itemFilterParams, $requestFilterParams) );
	}
	
	private function calculateNeverRequestsQueryString(	$actualLibraryId,
														$currentIndexPage,
														$pageSize,
														$filters)
	{
		$filters['actualLibraryId'] = $actualLibraryId;
		
		$requestFilterQuery = "";
		$requestFilterParams = array();
		$joinQuery = "";

		$filterQuery = self::calculateFilterQuery($filters);

		if (array_key_exists(self::_requestFilterQuery, $filterQuery))
			$requestFilterQuery = $filterQuery[self::_requestFilterQuery];

		if (array_key_exists(self::_requestFilterParams, $filterQuery))
			$requestFilterParams = $filterQuery[self::_requestFilterParams];
		
		/**
		 * We need here a logic block that puts some added joins, if needed
		 */
		if (array_key_exists(':NRJoinCase', $requestFilterParams))
		{
			$joinQuery = $requestFilterParams[':NRJoinCase'];
			//unset ($requestFilterParams[':NRJoinCase']);
		}	
		
		$query = "SELECT "
					. "r.request_id, r.request_date, r.manifestation_id, r.item_id, r.issue_id, "
					. "IF(r.manifestation_id = 0, "
					. "(SELECT SUBSTRING(title,1,80) FROM item WHERE item_id = r.item_id), "
					. ($joinQuery != ""
							? "SUBSTRING(m.title, 1, 80)"
							: "(SELECT SUBSTRING(title, 1, 80) FROM manifestation WHERE manifestation_id = r.manifestation_id)")
					. ") AS title "
					. "FROM item_request r"
				
					. $joinQuery

					. " WHERE r.request_status ='" . ItemRequestPeer::STATUS_PENDING . "' 
						
							AND (" . $requestFilterQuery . ")"

					// ** pagination part **		
					. " ORDER BY r.manifestation_id ASC " . (intval($pageSize) > 0
																	? " LIMIT {$pageSize} OFFSET " . ($pageSize * $currentIndexPage)
																	: "");
																
		return array(	'querystring' => $query,
						'params' => $requestFilterParams );
	}
	
	private function calculateNeverRequestsCountString(	$actualLibraryId,
														$filters)
	{
		$filters['actualLibraryId'] = $actualLibraryId;
		
		$requestFilterQuery = "";
		$requestFilterParams = array();
		$joinQuery = "";
		
		$filterQuery = self::calculateFilterQuery($filters);

		if (array_key_exists(self::_requestFilterQuery, $filterQuery))
			$requestFilterQuery = $filterQuery[self::_requestFilterQuery];

		if (array_key_exists(self::_requestFilterParams, $filterQuery))
			$requestFilterParams = $filterQuery[self::_requestFilterParams];

		/**
		 * We need here a logic block that puts some added joins, if needed
		 */
		if (array_key_exists(':NRJoinCase', $requestFilterParams))
		{
			$joinQuery = $requestFilterParams[':NRJoinCase'];
			//unset ($requestFilterParams[':NRJoinCase']);
		}	
		
		$query = "SELECT COUNT(*) as count "
					. "FROM item_request r "
				
					. $joinQuery
		
					. " WHERE r.request_status ='" . ItemRequestPeer::STATUS_PENDING . "' 

							AND (" . $requestFilterQuery . ")";
									//AND r.delivery_library_id = {$actualLibraryId} 
					
		return array(	'querystring' => $query,
						'params' => $requestFilterParams );
	}
	
	private function calculateRequestsQueryStringDetailed(	$requestId,
															$actualLibraryId)
	{
		$maxExtraLoans = ClavisParamPeer::getParam('MAXEXTRALOANS', 0);
		$requestManifestationId = 0;
		$requestIssueId = null;
		$requestItemId = null;
		$request = ItemRequestQuery::create()->findPk($requestId);

		if ($request instanceof ItemRequest)
		{
			if (($candidateRequestManifestationId = $request->getManifestationId()) > 0)
				$requestManifestationId = $candidateRequestManifestationId;

			if (($candidateRequestIssueId = $request->getIssueId()) != null)
				$requestIssueId = $candidateRequestIssueId;

			if (($candidateRequestItemId = $request->getItemId()) != null)
				$requestItemId = $candidateRequestItemId;
		}

		$basinSubQuery = self::getLLibraryActive()
									? self::calculateBasinQuery()
									: "";

		$queryString = "SELECT request_id,manifestation_id,item_id,issue_id,max_distance,r.patron_id,external_library_id,delivery_library_id,request_date,expire_date,request_note,request_status,librarian_id
	
			FROM item_request r LEFT JOIN patron p ON p.patron_id = r.patron_id " .
				// WHERE part
				"WHERE r.request_status IN ('" . implode(ItemRequestPeer::getActiveStatus(), "','") . "') " .
				// loanable_since part		
				" AND (SELECT IF(mm.loanable_since IS NULL, NULL, IF(mm.loanable_since < now(), NULL, TRUE)) FROM manifestation mm WHERE mm.manifestation_id = r.manifestation_id) IS NULL " .
				" AND (SELECT library_status FROM library WHERE library_id = r.delivery_library_id) = '" . LibraryPeer::STATUS_ACTIVE . "' " .
				$basinSubQuery . //// basin part

				" AND (r.patron_id IS NULL OR p.patron_status = '" . PatronPeer::STATUS_ENABLED . "')" .
				" AND (SELECT COUNT(*)
				 	FROM item i
				 	 FORCE INDEX  (item_request_speedup) WHERE (i.manifestation_id = r.manifestation_id)
				  		AND i.actual_library_id='{$actualLibraryId}'
						AND i.loan_status IN ('" . implode(ItemPeer::getLoanStatusAvailable(), "','") . "')
						AND ((r.issue_id IS NOT NULL AND i.issue_status='" . ItemPeer::ISSUESTATUS_ARRIVED . "')
						 	OR r.issue_id IS NULL)
						AND (i.loan_class IN ('" . implode(ItemPeer::getLoanClassesAvailable(true), "','") . "')
						 	OR (r.delivery_library_id = i.home_library_id AND i.loan_class IN ('" . implode(ItemPeer::getLoanClassesLocallyAvailable(true), "','") . "')))
						AND ((r.item_id IS NOT NULL AND i.item_id = r.item_id)
							OR (r.item_id IS NULL AND r.issue_id IS NOT NULL AND i.issue_id = r.issue_id)
							OR (r.item_id IS NULL AND (i.issue_id IS NULL OR i.issue_id=0)))) > 0
				
				AND ((SELECT COUNT(*)
				 			FROM item i
				 			 FORCE INDEX  (item_request_speedup) WHERE (i.manifestation_id = r.manifestation_id)
								AND i.actual_library_id=r.delivery_library_id
								AND i.loan_status IN ('" . implode(ItemPeer::getLoanStatusAvailable(), "','") . "')
								AND ((r.issue_id IS NOT NULL AND i.issue_status = '" . ItemPeer::ISSUESTATUS_ARRIVED . "')
											OR (r.issue_id IS NULL OR r.issue_id=0))
										AND (i.loan_class IN ('" . implode(ItemPeer::getLoanClassesAvailable(true), "','") . "')
									OR (r.delivery_library_id = i.home_library_id AND i.loan_class IN ('" . implode(ItemPeer::getLoanClassesLocallyAvailable(true), "','") . "')))
								AND ((r.item_id IS NOT NULL AND i.item_id = r.item_id)
									OR (r.item_id IS NULL AND r.issue_id IS NOT NULL AND i.issue_id = r.issue_id)
									OR (r.item_id IS NULL AND (i.issue_id IS NULL OR i.issue_id=0)))
						) = 0 OR r.delivery_library_id = {$actualLibraryId}) " .
				($requestManifestationId == 0 ? (is_null($requestItemId) ? "" : " AND r.item_id = " . $requestItemId) : " AND r.manifestation_id = {$requestManifestationId}") .
				(is_null($requestIssueId) ? " AND r.issue_id IS NULL" : " AND r.issue_id = {$requestIssueId}") .
				" AND ( r.external_library_id > 0 OR (
				   ((SELECT count(*) 
					   FROM item i2 
					   WHERE i2.patron_id = r.patron_id 
					   AND i2.item_media = (
						   SELECT i1.item_media 
						   FROM item i1 
						   WHERE (i1.manifestation_id = r.manifestation_id) AND
						         (r.manifestation_id > 0 OR (r.manifestation_id = 0 AND i1.item_id = r.item_id)) AND
							     i1.actual_library_id = {$actualLibraryId} AND
							     i1.loan_class IN ('" . implode(array_merge(ItemPeer::getLoanClassesAvailable(true), ItemPeer::getLoanClassesLocallyAvailable(true)), "','")  . "')

						   LIMIT 1
						   )
				   ) <  {$maxExtraLoans} + (SELECT cp.param_value FROM clavis_param cp WHERE cp.param_class =  concat('MAXLOANSALLOWED_',p.loan_class) AND cp.param_name = (
						   SELECT i1.item_media 
						   FROM item i1 
						   WHERE (i1.manifestation_id = r.manifestation_id) AND
                                 (r.manifestation_id > 0 OR (r.manifestation_id = 0 AND i1.item_id = r.item_id)) AND
							     i1.actual_library_id = {$actualLibraryId} AND
							     i1.loan_class IN ('" . implode(array_merge(ItemPeer::getLoanClassesAvailable(true), ItemPeer::getLoanClassesLocallyAvailable(true)), "','")  . "')

						   LIMIT 1
						   )
				   ) OR (p.max_loans IS NOT NULL AND p.max_loans > 0))
				   AND
				   (SELECT count(*) 
					   FROM item i2 
					   WHERE i2.patron_id = r.patron_id 

				   ) <  {$maxExtraLoans} + IF((p.max_loans IS NOT NULL AND p.max_loans > 0),p.max_loans,(SELECT cp.param_value FROM clavis_param cp WHERE cp.param_class = concat('MAXLOANSALLOWED_',p.loan_class) AND cp.param_name =  '0') )
			   )) " .
				" ORDER BY request_date, request_id ASC";

		return $queryString;
	}

	private function calculateRequestItemIdsQueryString(	$requestIdsArray,
															$actualLibraryId)
	{
		$libraryStatusActive = LibraryPeer::STATUS_ACTIVE;
		$queryString = "SELECT i.item_id, r.request_id
 						FROM item i FORCE INDEX  (item_request_speedup) JOIN item_request r
 						  WHERE (i.manifestation_id = r.manifestation_id)
 							AND i.actual_library_id={$actualLibraryId}
								
							AND (SELECT library_status FROM library WHERE library_id = r.delivery_library_id) = '{$libraryStatusActive}' 

 							AND i.loan_status IN ('" . implode(ItemPeer::getLoanStatusAvailable(), "','") . "')
							AND ((r.issue_id IS NOT NULL AND i.issue_status = '" . ItemPeer::ISSUESTATUS_ARRIVED . "')
							 	OR (r.issue_id IS NULL))
							AND (i.LOAN_CLASS IN ('" . implode(ItemPeer::getLoanClassesAvailable(true), "','") .
							"') OR (r.delivery_library_id = {$actualLibraryId} AND i.LOAN_CLASS IN ('" . implode(ItemPeer::getLoanClassesLocallyAvailable(true), "','") . "')" .
							")) AND (( r.item_id IS NOT NULL AND i.item_id = r.item_id  ) " .
							"OR ( r.item_id IS NULL AND r.issue_id IS NOT NULL AND i.issue_id = r.issue_id) " .
							"OR (r.item_id IS NULL AND r.issue_id IS NULL))" .
							" AND r.request_id IN ('" . implode($requestIdsArray, "','") . "')";

		return $queryString;
	}

	public function manageRequest(	$itemRequestId,
									$clavisLibrarian)
	{
		if (is_null($clavisLibrarian)
				|| !($clavisLibrarian instanceof ClavisLibrarian))
			return ClavisLoanManager::ERROR;

		$itemRequest = null;
		$itemRequestId = intval($itemRequestId);
		
		if ($itemRequestId > 0)
			$itemRequest = ItemRequestQuery::create()->findPK($itemRequestId);
		
		if (!($itemRequest instanceof ItemRequest))
			return ClavisLoanManager::ERROR;

		$itemId = intval($itemRequest->getItemId());
		$patron = $itemRequest->getPatron();
		$externalLibrary = $itemRequest->getExternalLibrary();

		if ($patron instanceof Patron)
		{
			$patronCheckReturn = ClavisLoanManager::IsPatronAllowedToLoan(	$patron,
																				$itemId); // item check was disabled lately.... trying to use it again
			
			if ($patronCheckReturn == ClavisLoanManager::LOAN_PATRONNOTENABLED)
				return $patronCheckReturn;
			/*
			 * the returnvalue LOAN_REACHEDMAX (per patron) now gets ignored, in the managerequest phase
			 */
		}
		elseif ($externalLibrary instanceof Library)
		{
			if (ClavisLoanManager::isExternalLibraryAllowedToLoan($externalLibrary->getLibraryId()) != ClavisLoanManager::OK)
				return ClavisLoanManager::LOAN_EXTERNALLIBRARYNOTENABLED;
		}

		$requestStatus = $itemRequest->getRequestStatus();

		if ($requestStatus == ItemRequestPeer::STATUS_WORKING)
			return ClavisLoanManager::RSV_ALREADYMANAGED;

		if ($requestStatus == ItemRequestPeer::STATUS_DONE
									|| $requestStatus == ItemRequestPeer::STATUS_EXPIRED
									|| $requestStatus == ItemRequestPeer::STATUS_CANCELED)
			return ClavisLoanManager::RSV_ALREADYCLOSED;

		try
		{
			$librarianId = intval($clavisLibrarian->getID());
			
			if ($librarianId == 0)
				return ClavisLoanManager::ERROR;

			$updatedNum = ItemRequestQuery::create()
									->filterByRequestId($itemRequestId)
									->filterByLibrarianId(null, Criteria::ISNULL)
									->filterByRequestStatus(ItemRequestPeer::STATUS_PENDING)
									->update(array(	'RequestStatus' => ItemRequestPeer::STATUS_WORKING,
													'LibrarianId' => $librarianId ), null, true);

			if ($updatedNum > 0)
			{
				ChangelogPeer::logAction(	$itemRequest,
											ChangelogPeer::LOG_UPDATE,
											$clavisLibrarian,
											"É stata presa in gestione la prenotazione con id: {$itemRequest->getRequestId()}");

				return ClavisLoanManager::OK;
			}
			else
			{
				return ClavisLoanManager::ERROR;
			}
		}
		catch (Exception $e)
		{
			$e = $e;
			//throw $e;
			return ClavisLoanManager::ERROR;
		}
	}

	public function unManageRequest(	$itemRequestId,
										$clavisLibrarian,
										$changelogText = '',
										$force = false)
	{
		$return = null;
		$itemRequest = null;
		$itemRequestId = intval($itemRequestId);

		if ($itemRequestId > 0)
			$itemRequest = ItemRequestQuery::create()->findPK($itemRequestId);
		
		if (!($itemRequest instanceof ItemRequest))
			return ClavisLoanManager::ERROR;

		if (is_null($clavisLibrarian)
				|| !($clavisLibrarian instanceof ClavisLibrarian))
			return ClavisLoanManager::ERROR;

		if ($itemRequest->getRequestStatus() != ItemRequestPeer::STATUS_WORKING)
			return ClavisLoanManager::RSV_NOTMANAGED;

		try
		{
			$librarianId = $clavisLibrarian->getId();
			
			if ($librarianId === $itemRequest->getLibrarianId()
					|| $force)
			{
				$updatedNum = ItemRequestQuery::create()
											->filterByRequestId($itemRequestId)
											->update(array(	'RequestStatus' => ItemRequestPeer::STATUS_PENDING,
															'LibrarianId' => null ), null, true);

				if ($updatedNum > 0)
				{
					if ($changelogText == '')
						$changelogText = "Cessazione di gestione della prenotazione con id: {$itemRequest->getRequestId()}";
						
					ChangelogPeer::logAction(	$itemRequest,
												ChangelogPeer::LOG_UPDATE,
												$clavisLibrarian,
												$changelogText);
					
					$return = ClavisLoanManager::OK;
				}
				else
				{
					return ClavisLoanManager::ERROR;
				}
			}
			else
			{
				$return = ClavisLoanManager::RSV_UNMANAGENOTSAMEOPERATOR;
			}

			return $return;
		}
		catch (Exception $e)
		{
			$e = $e;
			//throw $e;
			return ClavisLoanManager::ERROR;
		}
	}

	/**
	 * Frees lengthy managed reservations.
	 *
	 * @param type $clavisLibrarian
	 * @return type 
	 */
	public function resetManagedReservations($clavisLibrarian = null)
	{
		if (is_null($clavisLibrarian))
			$clavisLibrarian = $this->getUser();

		if (!$clavisLibrarian instanceof ClavisLibrarian)
			return false;

		try
		{
			$expiretime = time() - intval(ClavisParamQuery::getParam('CLAVISPARAM', 'ReservationResetValue'));
			
			$queryResult = ItemRequestQuery::create()
											->filterByRequestStatus(array(ItemRequestPeer::STATUS_WORKING))
											->filterByDateUpdated($expiretime, Criteria::LESS_THAN)
											->update(array(	'RequestStatus' => ItemRequestPeer::STATUS_PENDING,
															'LibrarianId' => null,
															'DateUpdated' => time(),
															'ModifiedBy' => $clavisLibrarian->getId() ));
			if ($queryResult > 0)
			{
				ChangelogPeer::logAction(	'ItemRequest',
											ChangelogPeer::LOG_UPDATE,
											$clavisLibrarian,
											"{$queryResult} prenotazioni 'in gestione' reimpostate in stato 'pendente'");
											
				return true;
			}
			else
			{
				return false; // no resets
			}
		}
		catch (Exception $e)
		{
			$e = $e;
			// throw $e;
			return false;
		}
	}

	/**
	 * Set expired reservations to expired status.
	 *
	 * @param ClavisLibrarian $clavisLibrarian
	 * @return boolean
	 */
	public function resetExpiredReservations($clavisLibrarian = null)
	{
		if (is_null($clavisLibrarian))
			$clavisLibrarian = $this->getUser();

		if (!$clavisLibrarian instanceof ClavisLibrarian)
			return false;

		try
		{
			$queryResult = ItemRequestQuery::create()
					->filterByRequestStatus(ItemRequestPeer::getActiveStatus())
					->filterByExpireDate(time(), Criteria::LESS_THAN)
					->update(array(	'RequestStatus' => ItemRequestPeer::STATUS_EXPIRED,
									'LibrarianId' => null,
									'DateUpdated' => time(),
									'ModifiedBy' => $clavisLibrarian->getId() ));
			
			if ($queryResult > 0)
			{
				ChangelogPeer::logAction(	'ItemRequest',
											ChangelogPeer::LOG_UPDATE,
											$clavisLibrarian,
											"Aggiornate {$queryResult} prenotazioni scadute", 1);
											
				return true;
			}
			else
			{
				return false; // no expired
			}
		}
		catch (Exception $e)
		{
			$e = $e;
			// throw $e;
			return false;
		}
	}
	/*
	 * This class almost replicates a similar one in the loanmanager, but we use ours 
	 * in order to find out if an item is available for requests, but also by taking in 
	 * account that temp states, like 30-60-90, in short will be over....
	 * So we don't calculate them as "non availability classes".
	 * 
	 */

	public static function isItemAvailableClass(	$item,
													$localLibraryId = null)
	{
		$output = in_array($item->getLoanClass(), ItemPeer::getLoanClassesAvailable(true)); // request mode
		$localLibraryId = intval($localLibraryId);
		
		if ($localLibraryId > 0)
			$output = ($output
							|| (($item->getHomeLibraryId() == $localLibraryId)
									&& in_array($item->getLoanClass(), ItemPeer::getLoanClassesLocallyAvailable(true)))); // request mode

		return $output;
	}

	/**
	 * Sets the item_request as nulled, with an optional note which
	 * gets appended to the usual changelog
	 * 
	 * @param ItemRequest $itemRequest
	 * @param ClavisLibrarian $clavisLibrarian
	 * @param string $note
	 * @return bool
	 */
	public function doNullRequest(	ItemRequest $itemRequest,
									ClavisLibrarian $clavisLibrarian,
									$note = '')
	{
		if (!$itemRequest instanceof ItemRequest)
			throw new Exception('Missing or wrong ItemRequest');

		if (!$clavisLibrarian instanceof ClavisLibrarian)
			throw new Exception('Missing or wrong ClavisLibrarian');

		try
		{
			$oldNote = trim($itemRequest->getRequestNote());
			
			if ($oldNote)
				$oldNote = ' / ' . $oldNote;
			
			$itemRequest->setRequestStatus(ItemRequestPeer::STATUS_CANCELED); // 'Annullata'
			$itemRequest->setLibrarianId(null);
			
			if ($note)
				$itemRequest->setRequestNote(Prado::localize('Nota annullamento: "{note}"',
																array('note' => $note)) . $oldNote);

			$itemRequest->save();

			if ($note)
				$note = ' - Nota: ' . $note;

			ChangelogPeer::logAction(	$itemRequest,
										ChangelogPeer::LOG_UPDATE,
										$clavisLibrarian,
										'Annullamento della prenotazione con id=' . $itemRequest->getRequestId() . $note);

			return true;
		}
		catch (Exception $e)
		{
			//throw $e;
			return false;
		}
	}

	/**
	 * @param ItemRequest $itemRequest
	 * @param ClavisLibrarian $clavisLibrarian
	 * @return bool
	 */
	public function doRenewRequest(	ItemRequest $itemRequest,
									ClavisLibrarian $clavisLibrarian)

	{
		$ok = false;
		
		if (!in_array($itemRequest->getRequestStatus(), ItemRequestPeer::getNonActiveStatus()))
			return false;

		if (!$itemRequest instanceof ItemRequest)
			throw new Exception('Missing or wrong ItemRequest');

		if (!$clavisLibrarian instanceof ClavisLibrarian)
			$clavisLibrarian = $this->getUser();
			
		$itemRequest->setRequestStatus(ItemRequestPeer::STATUS_PENDING); // set again as pending
		$itemRequest->setItemId(null);
		$itemRequest->setLibrarianId(null);

		try
		{
			$itemRequest->save();

			ChangelogPeer::logAction(	$itemRequest,
										ChangelogPeer::LOG_UPDATE,
										$clavisLibrarian,
										'Rinnovo amministrativo della prenotazione già soddisfatta con id=' . $itemRequest->getRequestId());
			
			$ok = true;
		}
		catch (Exception $e)
		{
			//throw $e;
		}
		
		return $ok;
	}
	
	public function isRequested(	$item,
									$patron = null)
	{
		if (!$item instanceof Item)
			return false;

		if (!is_null($patron)
				&& !($patron instanceof Patron))
			return false;

		$query = ItemRequestQuery::create()->filterByRequestStatus(ItemRequestPeer::STATUS_PENDING); // only pending ones

		$manifestationId = intval($item->getManifestationId());
		$issueId = intval($item->getIssueId());
		
		if ($manifestationId > 0)
		{
			$query->filterByManifestationId($manifestationId);

			if ($issueId > 0)
				$query->filterByIssueId($issueId);
		}
		else
		{
			$query->filterByItem($item);
		}

		if (!is_null($patron))
			$query->filterByPatron($patron);

		return ($query->count() > 0);
	}

	public static function getFlagUrl($value)
	{
		switch ($value)
		{
			case self::no_flag:
				return 'themes/Default/punto_trasparente.png';
		
				break;

			case self::yellow_flag:
				return 'themes/Default/icons/flag_yellow.png';
				
				break;

			case self::red_flag:
				return 'themes/Default/icons/flag_red.png';
				
				break;

			default:
				return 'themes/Default/punto_trasparente.png';
		}
	}
	
	public static function getNeverRequestCategories($withNull = false)
	{
		if ($withNull)
		{
			$output = array(null => '---');
		}
		else
		{
			$output = array();
		}

		$output += array(	//self::NEVERREQUESTCAT_GENERIC => Prado::localize('tutte le prenotazioni non soddisfacibili'),
							self::NEVERREQUESTCAT_PATRONNOTENABLED => Prado::localize('prenotazioni per utente permanentemente non abilitato'),
							self::NEVERREQUESTCAT_PATRONNOTENABLEDLOSTREQUESTS => Prado::localize('utente temporaneamente non abilitato con prenotazioni che scadono prima della riabilitazione'),
							self::NEVERREQUESTCAT_PATRONNOTENABLEDSAFEREQUESTS => Prado::localize('utente temporaneamente non abilitato con prenotazioni che scadono dopo la riabilitazione'),	// request decay after patron is readmitted
							self::NEVERREQUESTCAT_PATRONMAXLOANS => Prado::localize('prenotazioni per utente che ha raggiunto il numero massimo di prestiti'),	// max loans reached by patron
							self::NEVERREQUESTCAT_NOITEMS => Prado::localize('nessun esemplare del sistema soddisfa la prenotazione'),
							self::NEVERREQUESTCAT_NOITEMSDISTANT => Prado::localize('esemplari di altri bacini soddisfano la prenotazione, ma non l\'attuale'),		// there are items in other basins, but not within the basin specified in the request
							self::NEVERREQUESTCAT_MANIFESTATIONAVAILDATE => Prado::localize('prenotazione su notizia non ancora prestabile'),		// no items for minimum date availability of the manifestation
							self::NEVERREQUESTCAT_PATRONAGE => Prado::localize('prenotazione su notizia non disponibile per limite di età degli utenti') );		// no items for minimum patron age's availability of the manifestation
		
		// if we don't have basins
		if (!self::getLLibraryActive())
			unset ($output[self::NEVERREQUESTCAT_NOITEMSDISTANT]);
		
		return $output;
	}
	
}
