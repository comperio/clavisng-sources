<?php

/**
 * SMSInfobipModule class.
 * A module for sending messages through Infobip SMS gateway.
 *
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author    Cristian Chiarello <cristian@comperio.it>
 * @link      http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license   http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version   $Id$
 */
require_once 'vendor/autoload.php';

use infobip\api\client\SendMultipleTextualSmsAdvanced;
use infobip\api\configuration\BasicAuthConfiguration;
use infobip\api\model\Destination;
use infobip\api\model\sms\mt\send\Message;
use infobip\api\model\sms\mt\send\textual\SMSAdvancedTextualRequest;
use infobip\api\client\GetAccountBalance;

class SMSInfobipModule extends SMSDummyModule
{

    /**
     * Send message. checkStatus function is not neccessary because setting notify url a web service is called just sms
     * si sent.
     * @see protected/Services/ClavisRestApi.php
     *
     * @param type $requestID
     * @return array with status and essors if any
     */
    public function sendMessage($requestID = null)
    {
	    $result = array('status' => 'OK', 'errors' => array(), 'data' => array(), 'code' => -1);
	    $notification = null;

        try {
            $msgIds = explode("|", $requestID);
            if (is_array($msgIds) && count($msgIds) == 3) {
                $nId = $msgIds[2];
                $notification = NotificationQuery::create()->findOneByNotificationId($nId);
                if ($notification instanceof Notification) {
                    $notes = array("backend" => "infobip", "smsid" => $requestID, "notificationid" => $nId, "to" => $this->getReceiver());
                    $notification->setNotes(serialize($notes));
                    $notification->save();
                } else {
                    Prado::log(__METHOD__ . " LINE " . __LINE__ . " ERROR: invalid request ID " . $requestID . " I cannot save message id to notification.");
                    $notification = null;
                }
            } else {
                Prado::log(__METHOD__ . " LINE " . __LINE__ . " ERROR: invalid request ID " . $requestID . " I cannot save message id to notification.");
            }

        } catch (Exception $ex) {
            Prado::log(__METHOD__ . " ERR: {$ex->getMessage()}");
            $notification = null;
        }

        try {
            $dst = $this->getReceiver();
            $authConf = new BasicAuthConfiguration($this->getAuthUser(), $this->getAuthPassword());
            $client = new GetAccountBalance($authConf);
            // Executing request
            $response = $client->execute();
            $balance = $response->getBalance();
            //Prado::log(__METHOD__ . 'accountBalance = ' . $balance . ' ' . $response->getCurrency());

            if ($balance <= 0) {
                $result["status"] = "KO";
                $result["errors"][] = "No more credits";
                return $result;
            }

            // Initializing SendMultipleTextualSmsAdvanced client with appropriate configuration
            $client = new SendMultipleTextualSmsAdvanced($authConf);
            // // Creating request body
            $destination = new Destination();
            $destination->setTo($dst);
            $destination->setMessageId($requestID);

            $message = new Message();
            $message->setFrom($this->getSender());
            $message->setDestinations([$destination]);
            $message->setText($this->getMessage());

            //$notifyUrl = "http://clavistest.comperio.it/infobip/infobip.php";
            $baseUrl = ClavisParamPeer::getParam('CLAVISPARAM', 'BaseUrl');
            //$baseUrl = "http://clavistest.comperio.it/minimo";
            $notifyUrl = $baseUrl . "/index.php/api/v1/Webhook/Infobip/1";
            //Prado::log(__METHOD__ . " notify url {$notifyUrl}");
            $message->setNotifyUrl($notifyUrl);
            $message->setNotifyContentType("application/json");
            $message->setCallbackData('APPID:' . $this->getApplication()->getID());

            $requestBody = new SMSAdvancedTextualRequest();
            $requestBody->setMessages([$message]);

            // // Executing request
            $response = $client->execute($requestBody);
            //Prado::log(Prado::varDump( $response));
            $sentMessageInfo = $response->getMessages()[0];
            $to = $sentMessageInfo->getTo();
            $status = $sentMessageInfo->getStatus();
            $statId = $status->getId();
            $statGid = $status->getGroupId();
            $statDesc = $status->getDescription();
            /*
             * For status list and codes please see https://dev.infobip.com/v1/docs/response-codes
	     * WARN: some statuses thow exceptions. TODO: manage cases on exception
             */
            if ($statGid != 7 && $statGid != 1) {
                $result["status"] = "KO";
                if ($statGid == 5) {
                    if (!is_null($notification)) {
                        //Try to set contact as wrong
                        Contact::setWrongMobileNumber($notification->getObjectId(), $to);
                    }
                    $result["errors"][] = $statDesc;

                } else {
                    $result["errors"][] = " something goes wrong, please see system log.";
                    Prado::log(__METHOD__ . " wrong status sending sms. See https://dev.infobip.com/docs/response-codes. Status dump reported below.");
                    Prado::log(Prado::varDump($status));
                }
            }
        } catch (\RuntimeException $ex) {
            $exmsg = $ex->getMessage();
            $excode = $ex->getCode();
            Prado::log(__METHOD__ . " ERR: {$exmsg}");
            $result["code"] = $excode;
            $result["message"] = $exmsg;
            $result["status"] = "KO";
            $result["errors"][] = "Exception {$exmsg}";
            return $result;

        } catch (Exception $ex) {
            $exmsg = $ex->getMessage();
            Prado::log(__METHOD__ . " ERR: {$exmsg}");

            $result["status"] = "KO";
            $result["errors"][] = "Exception {$exmsg}";
            return $result;
        }

        return $result;
    }

    public function getMsgNo()
    {
        $doublechars = array("€", "[", "]", "{", "}", "|", "\\", "^", "~");
        $smslen = strlen($this->getMessage());
        foreach ($doublechars as $c) {
            $smslen += substr_count($this->getMessage(), $c);
        }
        return ($smslen < 161) ? 1 : ceil($smslen / 153);
    }

}
