<?php
/**
 * Apply rules to a resource
 *
 * DEPRECATED
 * To use this module please add something like
 * <module id="rulemanager" class="RuleManager" ComputeLibraryTime="false" ComputeResourceTime="false" UseRegex="false" DefaultPolicy="deny" />
 * to application.xml
 * 
 * @author Cristian Chiarello <ciarez@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2009-2015 Comperio srl
 * @license http://www.comperio.it/license/
 */
class RuleManager extends TModule
{
	public $patron_id;
	public $resource_id;
	
	public $patron;
	public $resource;
	public $group;
	public $devip;
	public $devmac;


	public $creditFreeWeek;
	public $creditFreeDay;
	public $creditFreeAvailable;
	public $credit;
	public $creditAmount;
	public $creditUsed;
	public $creditTotal;
	public $limitAge;
	public $limitSessionGap;
	public $limitCheckCloseTime;
	public $limitCheckCloseTimeVal;
	public $limitTime;
	public $limitTotal;
	public $usedTimeWeek;//From Monday to yesterday, minutes
	public $usedTimeDay;//today, minutes
	public $usedTime;//From monday to now, minutes
	public $usedTimeWeekSec;//From Monday to yesterday, seconds
	public $usedTimeDaySec;//today, seconds
	public $usedTimeSec;//From monday to now, seconds
	public $timeToEnd; //time to lib to close
	public $availableTime;
	public $limits;
	public $credits;
	public $creditUsedByDay;
	
	public $matchingRules;
	public $computeLibraryTime; //If true, compute patron used time on specific library
	public $computeResourceTime; //If true, compute patron used time on specific resource
	public $useRegex; //if true search rules with regex instead of substring
	public $libraryId;
	public $defaultPolicy;
	
	const COMPUTE_TIME_GLOBAL = 0;
	const COMPUTE_TIME_LIBRARY = 1;
	const COMPUTE_TIME_RESOURCE = 2;
	const COMPUTE_TIME_LIBRARY_RESOURCE = 3;
				
	public function setLibraryId( $libId )
	{
		$this->libraryId = $libId;
	}
	
	public function setUseRegex( $usere )
	{
		if( $usere == 'true')
		{
			$this->useRegex = TRUE;
		}
		else
		{
			$this->useRegex = FALSE;
		}
	}
	
	
	public function getUseRegex(  )
	{
		if(isset($this->useRegex))
		{
			return $this->useRegex;
		}
		else
		{
			return FALSE;
		}
	}
	
	
	public function setDefaultPolicy( $dp )
	{
		$this->defaultPolicy = $dp;
	}
	
	public function getDefaultPolicy(  )
	{
		if(isset($this->defaultPolicy))
		{
			return $this->defaultPolicy;
		}
		else
		{
			return 'deny';
		}
	}
	
	
	public function setComputeLibraryTime( $clt )
	{
		if( $clt == 'true')
		{
			$this->computeLibraryTime = TRUE;
		}
		else
		{
			$this->computeLibraryTime = FALSE;
		}
	}
	
	public function setComputeResourceTime( $clt )
	{
		if( $clt == 'true')
		{
			$this->computeResourceTime = TRUE;
		}
		else
		{
			$this->computeResourceTime = FALSE;
		}
	}
	
	/**
	 * Init vars used for search used time and rules. Values come from RPC request perform from
	 * radius clavis module
	 * clavis session manager (userful or pc)
	 * 
	 * @param Patron $patron user that perform the login
	 * @param Resource $resource resource patron want to connect to
	 * @param String $group logical group of devices ID. hotspot on mikrotik, configurable string on csm
	 * @param String $devip IP of the calling user device
	 * @param String $devmac MAC address of the calling user device
	 */
	public function initVars( $patron, $resource, $group=NULL, $devip=NULL, $devmac=NULL)
	{
		Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
			" ENTER --------------------------------------------",
			TLogger::DEBUG, 'NM_RULEMANAGER');
		$this->creditFreeWeek = 0;
		$this->creditFreeDay = 0;
		$this->creditFreeAvailable = 0;
		$this->credit = 0;
		$this->creditAmount = 0;
		$this->creditUsed = 0;
		$this->creditTotal = 0;
		$this->limitTime = 0;
		$this->limitAge = 0;
		$this->limitSessionGap = 0;
		$this->limitCheckCloseTime = TRUE;
		$this->limitCheckCloseTimeVal = 0;
		$this->limitTotal = 0;
		$this->usedTimeWeek = 0;
		$this->usedTimeDay = 0;
		$this->usedTime = 0;
		$this->usedTimeWeekSec = 0;
		$this->usedTimeDaySec = 0;
		$this->usedTimeSec = 0;
		$this->timeToEnd = -1;
		$this->availableTime  = 0;
		$this->limits = array();
		$this->credits = array();
		$this->creditUsedByDay = NULL;
		$this->matchingRules = 0;
		$this->group = $group;
		$this->devip = $devip;
		$this->devmac = $devmac;
		
		
		if( !is_null( $patron ) )
		{
			$this->patron = $patron;
			$this->patron_id = $patron->getPatronId();
		}


		if( !is_null( $resource ) )
		{
			$this->resource = $resource;
			$this->resource_id = $resource->getResourceId();
			$this->libraryId = $resource->getLibraryId();
		}

		if( !is_null( $devip ) )
		{
			Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
				" Framedipaddress (sub resource id) is set. Resource ip " . $this->resource->getName() . " - calling ip " . $this->devip, 
				TLogger::DEBUG, 'NM_RULEMANAGER');
		}
		else
		{
			Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
				" Any rule pattern is set.", 
				TLogger::DEBUG, 'NM_RULEMANAGER');
			if( !is_null( $resource ) )
			{
				$this->devip = $this->resource->getName();
				Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
					" Resource found, take resource IP as pattern (resource ip and calling ip are the same: " . $this->devip.")", 
					TLogger::DEBUG, 'NM_RULEMANAGER');
			}
			else
			{
				throw new Exception( __METHOD__ . ' Resource object is NULL' );
			}
		}
		Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
			" EXIT --------------------------------------------",
			TLogger::DEBUG, 'NM_RULEMANAGER');
	}
	
	public function __toString()
	{
		return "patron id:{$this->patron_id}"
		. " resource id: {$this->resource_id} "
		. "creditFreeWeek: {$this->creditFreeWeek}"
		. " creditFreeDay: {$this->creditFreeDay} "
		. "credit: {$this->credit} "
		. "usedTimeWeek: {$this->usedTimeWeek} "
		. "usedTimeDay: {$this->usedTimeDay} "
		. "usedTime: {$this->usedTime}";
	}
	
	public function getInfo()
	{		
		return $this->patron->getOpacUsername() . " - " . $this->resource->getName();
	}
	
	
	
	//->filterByResourceOwner(array($resname, '.'), Criteria::CONTAINS_SOME);
	public function loadRules()
	{
		Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
			" ENTER --------------------------------------------",
			TLogger::DEBUG, 'NM_RULEMANAGER');
		
		$libid = $this->resource->getLibraryId();
		$resname = $this->resource->getName();
		Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
			" Get lib id  {$libid} from registered resource {$resname}.", 
			TLogger::DEBUG, 'NM_RULEMANAGER');
		$rulesResultSet = ResourceRuleQuery::create()
		->filterByLibraryId($libid)
		->filterByType(ResourceRule::TYPE_DISABLED, Criteria::NOT_EQUAL)
		->filterByResourceGroup(NULL, Criteria::ISNULL)
		->_or()
		->filterByResourceGroup('')
		->_or()
		->filterByResourceGroup($this->group)
		->_and()
		->filterByPatronId($this->patron_id)
		->_or()
		->where(" patron_id IS NULL ")
		->_and()
		->where(" ((validity_start IS NULL AND validity_end IS NULL) OR (NOW() BETWEEN validity_start AND validity_end)) ")
		->_and()
		->where(" resource_owner IN ('.','{$resname}') ")
		->orderBy("patron_id", Criteria::DESC)
		->orderBy("used", Criteria::DESC)
		->orderBy( 'priority' );
		
		
		//Prado::log(__METHOD__   ."  Q *** " . $rulesResultSet->toString(), TLogger::DEBUG, 'NM_RULEMANAGER');
		
		
		$nRules = $rulesResultSet->count();
		Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
			" Found {$nRules} rules for this library. Parsing...",
			TLogger::DEBUG, 'NM_RULEMANAGER');
		/*
		Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
			" (use regex on device ip is " . (($this->useRegex == TRUE) ? "true" : "false") . ")",
			TLogger::DEBUG, 'NM_RULEMANAGER');*/
		
		$rules = $rulesResultSet->find();
		
		$pattern = $this->devip;
		
		foreach ($rules as $rule)
		{
			$rid = $rule->getResourceRuleId();
			
			// Get the IP pattern to match against from rule
			// DEPRECATED incoerent with time used computing
			$rp = $rule->getResourcePattern();
			
			if((!is_null($rp)) && $rp != '')
			{
				$patternMatch = FALSE;
				
				if($this->useRegex === TRUE)
				{
					$rp = '/'.$rp.'/i';
					$pm = preg_match($rp,$pattern);
					$patternMatch =  ( $pm === 1 ) ? TRUE : FALSE;
					/*
					Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
						"  rule {$rid} REGEX pattern is {$rp}",
						TLogger::DEBUG, 'NM_RULEMANAGER');*/
				}
				else
				{
					$patternMatch = ( strpos($pattern,$rp) !== FALSE ) ? TRUE : FALSE;
					/*
					Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
						"  rule {$rid} SUBSTR pattern is {$rp}",
						TLogger::DEBUG, 'NM_RULEMANAGER');*/
				}
					
				//if(strpos($pattern,$rp) !== FALSE)
				if( $patternMatch === TRUE )
				{
					Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
						"  rule {$rid} LOADED because {$rp} match with calling ip {$pattern} (" . (($this->useRegex == TRUE) ? "REGEX" : "SUBSTR") . ")", 
						TLogger::DEBUG, 'NM_RULEMANAGER');
				}
				else
				{
					Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
						"  rule {$rid} IGNORED because {$rp} does not match with calling ip  {$pattern} (" . (($this->useRegex == TRUE) ? "REGEX" : "SUBSTR") . ")",
						TLogger::DEBUG, 'NM_RULEMANAGER');
					continue;
				}
			}
					
			$rtype = $rule->getType();
			if( strpos($rtype,'LIMIT') !== FALSE )
			{
				Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
					"  rule {$rid} is limit",
					TLogger::DEBUG, 'NM_RULEMANAGER');
				$this->limits[] = $rule;
			}
			
			if( strpos($rtype,'CREDIT') !== FALSE )
			{
				Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
					"  rule {$rid} is credit",
					TLogger::DEBUG, 'NM_RULEMANAGER');
				$credamount = round( floatval( $rule->getAmount() ) );
				$credused = round( floatval( $rule->getUsed() ) );
				if( $credamount >  $credused )
				{
					$this->credits[] = $rule;
				}
				else
				{
					Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
						" rule {$rid} exausted: IGNORE IT", 
						TLogger::DEBUG, 'NM_RULEMANAGER');
				}
			}
			$this->matchingRules++;
			
			Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
				"  actual loaded rules {$this->matchingRules}",
				TLogger::DEBUG, 'NM_RULEMANAGER');
			
		}
		
		
		Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
				" Limits for {$pattern}.", 
				TLogger::DEBUG,"LLDebug");
		Prado::log(Prado::varDump( $this->limits), 
				TLogger::DEBUG,"LLDebug");
		
		Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
				" Credits for {$pattern}.", 
				TLogger::DEBUG,"LLDebug");
		Prado::log(Prado::varDump( $this->credits), 
				TLogger::DEBUG,"LLDebug");
		Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
			" EXIT --------------------------------------------",
			TLogger::DEBUG, 'NM_RULEMANAGER');
	}
	
	
	
	
	/**
	 * Compute credits
	 * NOTE: free credit (without "pay" credit) can be a limit.
	 */
	public function getCredits()
	{
		Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
			" ENTER --------------------------------------------",
			TLogger::DEBUG, 'NM_RULEMANAGER');
		
		if(count($this->credits) <= 0)
		{
			Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
				" no credits found for {$this->devip}.",
				TLogger::DEBUG, 'NM_RULEMANAGER');
			return;
		}
		
		Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
			" Search credits for {$this->getInfo()}",
			TLogger::DEBUG, 'NM_RULEMANAGER');
		
		foreach($this->credits as $rule)
		{
			$type = $rule->getType();
			$pid = $rule->getPatronId();
			$rid = $rule->getResourceRuleId();
			
			$amount = round($rule->getAmount());
			$amount = $amount * 60;
			
			switch ($type) {
				case ResourceRule::TYPE_CREDIT_FREE_WEEK:
					$this->creditFreeWeek += $amount;
					break;
			
				case ResourceRule::TYPE_CREDIT_FREE_DAY:
					$this->creditFreeDay += $amount;
					break;
			
				case ResourceRule::TYPE_CREDIT:
					$used = round($rule->getUsed());
					$used = $used * 60;
					$this->creditAmount += $amount;
					$this->creditUsed += $used;
					$this->credit += ($amount - $used);
					Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
							" CREDIT {$amount} - {$used} = {$this->credit} ",
							TLogger::DEBUG, 'NM_RULEMANAGER');
					break;
			}
		}		

		if($this->creditFreeDay == 0)
		{
			Prado::log(__METHOD__ . "[" . __LINE__ . "] " . 
				" RESET creditFreeWeek because creditFreeDay = 0",
				TLogger::DEBUG, 'NM_RULEMANAGER');
			$this->creditFreeWeek = 0;
		}

		$this->creditTotal = $this->creditFreeWeek + $this->creditFreeDay + $this->credit;
		
		Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
			" CREDITS amount after parsing credit rules FREE: week {$this->creditFreeWeek} day {$this->creditFreeDay} PAY: {$this->credit} TOT {$this->creditTotal}",
			TLogger::DEBUG, 'NM_RULEMANAGER');
		
		
		
		

		/*
		 * This need a user brain debug... :)
		 * If week free credits is less than day free credits, reset week free credits
		 */
		if($this->creditFreeWeek > 0 && $this->creditFreeWeek < $this->creditFreeDay)
		{
			Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
				" WARNING! free credit free day is bigger than credit free week for {$this->getInfo()}, reset week free credits",
				TLogger::DEBUG, 'NM_RULEMANAGER');
				
			$this->creditFreeWeek = 0;
		}


		
		
		$freeCreditUsedWeek = 0;
		$freeCreditAvailableWeek = 0;
		
		foreach( $this->creditUsedByDay as $utd )
		{
			if($utd >= $this->creditFreeDay)
			{
				$freeCreditUsedWeek += $this->creditFreeDay;
			}
			else
			{
				$freeCreditUsedWeek += $utd;
			}
		}
		
		if( $this->creditFreeWeek > $freeCreditUsedWeek )
		{
			$freeCreditAvailableWeek = $this->creditFreeWeek - $freeCreditUsedWeek;
			Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
				"  freeCreditAvailableWeek {$freeCreditAvailableWeek} = this->creditFreeWeek {$this->creditFreeWeek} - freeCreditUsedWeek {$freeCreditUsedWeek}", 
				TLogger::DEBUG, 'NM_RULEMANAGER');
		}
		else
		{
			Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
				" no free week credits found, so freeCreditAvailableWeek = {$freeCreditAvailableWeek}", 
				TLogger::DEBUG, 'NM_RULEMANAGER');
		}
		
		
		$freeCreditUsedDay = 0;
		$freeCreditAvailableDay = 0;
		
		Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
			"   creditUsedByDay array is: ". Prado::varDump( $this->creditUsedByDay ), 
			TLogger::DEBUG,
			"LLDebug");
		
		$dow = date('w', time());
		
		Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
			"  Getting the day of week: {$dow}",
			TLogger::DEBUG, 'NM_RULEMANAGER');
					
		if(  array_key_exists( $dow, $this->creditUsedByDay ))
		{
			if( $this->creditUsedByDay[$dow] > $this->creditFreeDay )
			{
				$freeCreditUsedDay += $this->creditFreeDay;
			}
			else
			{
				$freeCreditUsedDay += $this->creditUsedByDay[$dow];
			}
			
			Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
				"  freeCreditUsedDay = {$freeCreditUsedDay}",
				TLogger::DEBUG, 'NM_RULEMANAGER');
			
		}
		else
		{
			Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
				"  index {$dow} not found in this->creditUsedByDay[] so freeCreditUsedDay = {$freeCreditUsedDay}",
				TLogger::DEBUG, 'NM_RULEMANAGER');
		}
		
		
		if( $this->creditFreeDay > $freeCreditUsedDay )
		{
			$freeCreditAvailableDay = $this->creditFreeDay - $freeCreditUsedDay;
			Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
				" freeCreditAvailableDay {$freeCreditAvailableDay} = this->creditFreeDay {$this->creditFreeDay} - freeCreditUsedDay {$freeCreditUsedDay}", 
				TLogger::DEBUG, 'NM_RULEMANAGER');
		}
		else
		{
			Prado::log(__METHOD__ .	"  freeCreditAvailableDay = {$freeCreditAvailableDay}  because  freeCreditUsedDay {$freeCreditUsedDay} > this->creditFreeDay {$this->creditFreeDay}", 
				TLogger::DEBUG, 'NM_RULEMANAGER');
		}
		

		//If I have both week and day free credit rule... 
		if($this->creditFreeWeek > 0 && $this->creditFreeDay > 0)
		{
			Prado::log(__METHOD__ . "[" . __LINE__ . "] " . 
					" free week and free day credits detected",
					TLogger::DEBUG, 'NM_RULEMANAGER');
			
			//take the minor of the computed time
			if($freeCreditAvailableWeek < $freeCreditAvailableDay)
			{
				Prado::log(__METHOD__ . "[" . __LINE__ . "] " . 
					" freeCreditAvailableWeek < freeCreditAvailableDay",
					TLogger::DEBUG, 'NM_RULEMANAGER');
				$this->creditFreeAvailable = $freeCreditAvailableWeek;
			}
			else
			{
				Prado::log(__METHOD__ . "[" . __LINE__ . "] " . 
					" freeCreditAvailableWeek >= freeCreditAvailableDay",
					TLogger::DEBUG, 'NM_RULEMANAGER');
				$this->creditFreeAvailable = $freeCreditAvailableDay;
			}
		}
		else //Only one of free credits available
		{
			if($freeCreditAvailableWeek > 0)
			{
				Prado::log(__METHOD__ . "[" . __LINE__ . "] " . 
					" freeTimeAvailableWeek  only",
					TLogger::DEBUG, 'NM_RULEMANAGER');
				$this->creditFreeAvailable = $freeCreditAvailableWeek;
			}

			if($freeCreditAvailableDay > 0)
			{
				Prado::log(__METHOD__ . "[" . __LINE__ . "] " . 
					"  freeTimeAvailableDay only",
					TLogger::DEBUG, 'NM_RULEMANAGER');
				$this->creditFreeAvailable = $freeCreditAvailableDay;
			}
		}			
		Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
			" EXIT --------------------------------------------",
			TLogger::DEBUG, 'NM_RULEMANAGER');
	}
	
	
	
	
	
	
	
	
	
	public function getLimits()
	{
		Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
			" ENTER --------------------------------------------",
			TLogger::DEBUG, 'NM_RULEMANAGER');
		
		if(count($this->limits) <= 0)
		{
			Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
				" no limits found for {$this->devip}.",
				TLogger::DEBUG, 'NM_RULEMANAGER');
			return;
		}
		
		Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
			" Search limits for {$this->getInfo()}",
			TLogger::DEBUG, 'NM_RULEMANAGER');
		
		foreach($this->limits as $rule)
		{
			$type = $rule->getType();
			$rid = $rule->getResourceRuleId();
			Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
				" rule {$rid} Limit type is {$type}",
				TLogger::DEBUG, 'NM_RULEMANAGER');
			$pid = $rule->getPatronId();
			$amount = round($rule->getAmount());
			$amount = $amount * 60;
			switch ($type) {
				case 'LIMIT_TIME':
					$this->limitTime += $amount;
					break;

				case 'LIMIT_AGE':
					$this->limitAge = round($rule->getAmount());
					break;

				case 'LIMIT_SESSION_GAP':
					$this->limitSessionGap = $amount;
					break;
					
				case 'LIMIT_CHECK_CLOSE_TIME':
					/*
					* If check close time limit is set, ignore 1,0,-1 values. Else negative value reduce time and
					* positive values increase the time
					*/
					if($amount != 0)
					{
						if( $amount > 60 || $amount  < -60)
						{
							$this->limitCheckCloseTimeVal = $amount;
							Prado::log(__METHOD__ . "[" . __LINE__ . "] " . 
									" check close time with diff {$amount}",
									TLogger::DEBUG, 'NM_RULEMANAGER');
						}
						else
						{
							Prado::log(__METHOD__ . "[" . __LINE__ . "] " . 
									" check close time with no diff",
									TLogger::DEBUG, 'NM_RULEMANAGER');
						}
					}
					else
					{
						$this->limitCheckCloseTime = FALSE;
					}
					break;

			}
		}
		Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
			" EXIT --------------------------------------------",
			TLogger::DEBUG, 'NM_RULEMANAGER');
	}
	
	

	
	public function getTimeToEnd($dtrefobj)
	{
		
		//################ TEST ONLY ################
		$testmode = FALSE;
		if($testmode )
		{
			Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
				" WARNING: test mode active.", 
				TLogger::DEBUG, 'NM_RULEMANAGER');
			$tmdt = new DateTime();
			
			$ltt = LibraryTimetableQuery::create()
				->filterByLibraryId($this->resource->getLibraryId())
				->filterByTimetableDay($tmdt)
				->filterByTimetableNote("TEST")
				->findOne();
			if( ! ($ltt instanceof LibraryTimetable))
			{
				$ltt = new LibraryTimetable();
				$ltt->setTimetableNote("TEST");
				$ltt->setTimetableDay($tmdt->format("Y-m-d"));
				$ltt->setTime1Start("09:00:00");
			}
			
			$tmdt->add(new DateInterval('PT30M'));
			$ltt->setTime1End($tmdt->getTimestamp());
			$ltt->save();
		}
		//################ TEST ONLY ################
		
		
		
		/*
		 * Check if I have a close time
		 */
		$closedt = NULL;
		$sdref = $dtrefobj->format("Y-m-d");
		Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
				" search timetable for ({$sdref}).", 
				TLogger::DEBUG, 'NM_RULEMANAGER');
		$ltt = LibraryTimetableQuery::create()
			->filterByLibraryId($this->resource->getLibraryId())
			->filterByTimetableDay($sdref)
			->findOne();

		if( $ltt instanceof LibraryTimetable)
		{
			
			$te[0] = $ltt->getTime1End(NULL);
			$te[1] = $ltt->getTime2End(NULL);
			$te[2] = $ltt->getTime3End(NULL);
			
			
			for( $i=0; $i < 3; $i++)
			{
				if(  ( ! is_null($te[$i]) ) && ( $te[$i] > $dtrefobj ) )
				{
					$closedt = $te[$i];
					Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
							" Close time found: {$closedt->format("H:i:s")}", 
							TLogger::DEBUG, 'NM_RULEMANAGER');
					break;
				}
			}
		}
		else
		{
			Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
				" no timetable found...", 
				TLogger::DEBUG, 'NM_RULEMANAGER');
		}

						
		
		
		/*
		 * If a close time exists, check how many minutes I have to close time
		 * Then subtract advance minutes and retiurn the value.
		 */
		if($closedt != NULL)
		{
			$dts = $closedt->format('Y-m-d H:i:s');
			Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
				" close time  {$dts}.", 
				TLogger::DEBUG, 'NM_RULEMANAGER');
			
			
			if($closedt > $now)
			{
				$interval = $closedt->diff($dtrefobj);
				Prado::log(Prado::varDump($interval),TLogger::DEBUG,"LLDebug");
				//Prado::log(Prado::varDump($interval),TLogger::DEBUG, 'NM_RULEMANAGER');
				$minToEnd = $interval->i + ($interval->h * 60);
				Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
					" {$minToEnd} time left.", 
					TLogger::DEBUG, 'NM_RULEMANAGER');
				
				$secToEnd = $minToEnd * 60;
				$secToEnd = round($secToEnd);
				$this->timeToEnd = $secToEnd + $diff;
			}
			else
			{
				Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
				" WARNING: close time past", 
				TLogger::DEBUG, 'NM_RULEMANAGER');
			}
		}
		
	}
	
	
	
	
	
	/*
	 * Compute patron age (years)
	 */
	public function getPatronAge()
	{
		$now = new DateTime();
		$born = $this->patron->getBirthDate(NULL);
		
		$diff = $now->diff($born);
		return $diff->y;
	}


	
	public function getSessionsGap()
	{
		$now = new DateTime();
		$todaydate = $now->format("Y-m-d");
		
		
		$lastsess = ResourceSessionQuery::create()
			->filterByPatronId($this->patron_id)
			->filterByResourceId($this->resource_id)
			->filterByFramedipaddress($this->devip)
			->where(" acctstoptime IS NOT NULL AND DATE(acctstoptime) = '{$todaydate}'")
			->orderBy( 'resource_session_id', Criteria::DESC )
			->findOne();
		
		if($lastsess instanceof ResourceSession)
		{
			$lastSessionEnd = $lastsess->getAcctstoptime(NULL);
			$diff = $now->diff($lastSessionEnd);
			$gap = $diff->s + $diff->i * 60 + ($diff->h * 3600);
			if($gap > 0)
			{				
				Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
					" last session found for {$this->patron->getOpacUsername()} id: {$lastsess->getResourceSessionId()} GAP: {$gap} sec)", 
					TLogger::DEBUG, 'NM_RULEMANAGER');
				return $gap;
			}
			else
			{
				Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
					" GAP <=0 detected: now {$now->format("Y-m-d H:i:s")} lastsessionend {$lastSessionEnd->format("Y-m-d H:i:s")} GAP {$gap} sec", 
					TLogger::DEBUG, 'NM_RULEMANAGER');
				return FALSE;
			}
		}
		else
		{
			Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
				" nessuna sessione trovata. GAP = FALSE", 
				TLogger::DEBUG, 'NM_RULEMANAGER');
			return FALSE;
		}
	}
	
	
	/**
	 * Return array of times used by day of week of a patron
	 * See RuleManager module configuration property
	 * @param type $dtref
	 * @throws Exception
	 */
	public function getUsedTime( $dtref )
	{
		Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
			" ENTER --------------------------------------------",
			TLogger::DEBUG, 'NM_RULEMANAGER');
		
		$prefs = NULL;
		$nmp = ClavisParamQuery::create()
		->filterByParamName(ClavisRadUtil::CP_CUUT_LIBPREFS)
		->filterByLibraryId($this->getUser()->getActualLibraryId())
		->filterByParamClass(ClavisRadUtil::CP_CLASS)
		->findOne();
		if( $nmp instanceof ClavisParam )
		{
			Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
				" LIB preferences found",
				TLogger::DEBUG, 'NM_RULEMANAGER');
			$prefs = json_decode($nmp->getParamValue(),TRUE);
		}
		else
		{
			$nmp = ClavisParamQuery::create()
			->filterByParamName(ClavisRadUtil::CP_CUUT_SYSPREFS)
			->filterByLibraryId(0)
			->filterByParamClass(ClavisRadUtil::CP_CLASS)
			->findOne();
			if( $nmp instanceof ClavisParam )
			{
				Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
					" SYS preferences found",
					TLogger::DEBUG, 'NM_RULEMANAGER');
				$prefs = json_decode($nmp->getParamValue(),TRUE);
			}
		}
		
		if(is_null($prefs))
		{
			Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
				" no preferences parameter found, use conf from module (deprecated)",
				TLogger::DEBUG, 'NM_RULEMANAGER');
			
			$computeTimePolicy = self::COMPUTE_TIME_GLOBAL;
				
			if( $this->computeLibraryTime && $this->libraryId != NULL)
			{
				$computeTimePolicy = self::COMPUTE_TIME_LIBRARY;
			}
	
			if( $this->computeResourceTime && $this->resource != NULL)
			{
				$computeTimePolicy = self::COMPUTE_TIME_RESOURCE;
			}
	
			if( $this->computeLibraryTime && $this->libraryId != NULL && $this->computeResourceTime && $this->resource != NULL)
			{
				$computeTimePolicy = self::COMPUTE_TIME_LIBRARY_RESOURCE;
			}
		

			if( $this->patron instanceof Patron )
			{
	
				switch ( $computeTimePolicy )
				{
					case self::COMPUTE_TIME_GLOBAL:
						Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
							" Get used session for all libraries and all resources",
							TLogger::DEBUG, 'NM_RULEMANAGER');
						$this->creditUsedByDay = $this->patron->getSessionTime($dtref, NULL, NULL);
						break;
	
					case self::COMPUTE_TIME_LIBRARY:
						Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
							" Get used session for library {$this->libraryId} and all resources",
							TLogger::DEBUG, 'NM_RULEMANAGER');
						$this->creditUsedByDay = $this->patron->getSessionTime($dtref, $this->libraryId, NULL);
						break;
	
					case self::COMPUTE_TIME_RESOURCE:
						Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
							" Get used session for all libraries and resource {$this->resource_id}",
							TLogger::DEBUG, 'NM_RULEMANAGER');
						$this->creditUsedByDay = $this->patron->getSessionTime($dtref, NULL, $this->resource_id);
						break;
	
					case self::COMPUTE_TIME_LIBRARY_RESOURCE:
						Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
							" Get used session for library {$this->libraryId} and resource {$this->resource_id}",
							TLogger::DEBUG, 'NM_RULEMANAGER');
						$this->creditUsedByDay = $this->patron->getSessionTime($dtref, $this->libraryId, $this->resource_id);
						break;
	
					default:
						Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
							" Get used session for all libraries and all resources (WARN: default is taken)",
							TLogger::DEBUG, 'NM_RULEMANAGER');
						$this->creditUsedByDay = $this->patron->getSessionTime($dtref, NULL, NULL);
						break;
				}

			}
			else
			{
				Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
					" BUG! Patron not found",
					TLogger::DEBUG, 'NM_RULEMANAGER');
				Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
					Prado::varDump( $this->patron ),
					TLogger::DEBUG, 'NM_RULEMANAGER');
				throw new Exception(__METHOD__ . "[" . __LINE__ . "] " .
					'Unable to get patron used time patron->getSessionTime');
			}
		}
		else 
		{
			// Get index of the "day of week" (0 = Sunday)
			$dow = date('w', $dtref);
			$dayend = strtotime("Today 23:59:59", $dtref);
			$today = strtotime("Today", $dtref);
			$this->creditUsedByDay = array();
			
			if( $dow != 1 )
			{
				$monday = strtotime("Last Monday", $dtref);
			}
			else
			{
				$monday = $today;
			}
			
			$rsq = ResourceSessionQuery::create()
			->withColumn("SUM(acctsessiontime)","t")
			->withColumn("DAYOFWEEK(acctstoptime)","d")
			->filterByPatronId($this->patron->getPatronId());
			
			if($prefs["ctlib"] == 1)
			{
				Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
					" filter by library id added",
					TLogger::DEBUG, 'NM_RULEMANAGER');
				$rsq->filterByLibraryId($this->libraryId);
			}
			
			if($prefs["ctres"] == 1)
			{
				Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
					" filter by resource id added",
					TLogger::DEBUG, 'NM_RULEMANAGER');
				$rsq->filterByResourceId($this->resource_id);
			}
			
			if($prefs["ctgrp"] == 1)
			{
				Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
					" filter by group (calledstationid) added",
					TLogger::DEBUG, 'NM_RULEMANAGER');
				$rsq->filterByCalledStationId($this->group);
			}
			
			$rsq->filterByAcctstoptime(array('min'=>$monday,'max'=>$dayend))
			->groupBy('d')
			->orderBy('d');
			
			Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
				" " . $rsq->toString(),
				TLogger::DEBUG,
				"LLDebug");
			$rsc = $rsq->find();
			
			foreach($rsc as $rs)
			{
				$phpDow = $rs->getD() - 1;
				if( array_key_exists( $phpDow, $this->creditUsedByDay ) )
				{
					$this->creditUsedByDay[$phpDow] += $rs->getT();
				}
				else
				{
					$this->creditUsedByDay[$phpDow] = $rs->getT();
				}
			}
			
		}
		
		if( !is_array($this->creditUsedByDay) )
		{
			throw new Exception(__METHOD__ . "[" . __LINE__ . "] " .
				' Error computing user used time. See patron->getSessionTime');
		}
		
		
		Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
			" EXIT --------------------------------------------",
			TLogger::DEBUG, 'NM_RULEMANAGER');
	}
	
	
	
	
	
	/**
	 * Rules main logic
	 * @param type $dtref
	 * @return array
	 */
	public function parseRule( $dtref )
	{
		Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
			" ENTER --------------------------------------------",
			TLogger::DEBUG, 'NM_RULEMANAGER');
		
		$retVal = array("status"=>"ack","errors"=>array(),"data"=>array());
		
		try
		{
			
			$this->loadRules();
			
			if( is_null($dtref) )
			{
				$dtref = time();
			}
			else
			{
				$dt = date("d-m-Y H:i:s", $dtref);
				Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
					" Using user defined reference time {$dt}",
					TLogger::DEBUG, 'NM_RULEMANAGER');
			}
			
			
			$this->getUsedTime($dtref);
			
			Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
				" time used by patron {$this->patron->getOpacUsername()}: " . Prado::varDump($this->creditUsedByDay),
				TLogger::DEBUG, 'NM_RULEMANAGER');
			
			$this->getLimits();
			

			
			if($this->matchingRules == 0)
			{
				if(isset($this->defaultPolicy))
				{
					Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
						" No rule, apply default policy ".$this->defaultPolicy, 
						TLogger::DEBUG, 'NM_RULEMANAGER');
					if($this->defaultPolicy != 'allow')
					{
						$retVal["status"] = "nak";
						$retVal["errors"]["NO_MATCHING_RULES"] = "Nessuna regola impostata: applico la politica predefinita (negare)";
						return array("status"=>"nak","errors"=>array('NO_MATCHING_RULES'=>'No rule for this resource and default policy is deny'),"data"=>array());
					}
					return $retVal;
				}
					
				
			}
			
			
			
			if($this->limitAge != 0)
			{
				$pAge = $this->getPatronAge();
				
				$applyLimit = FALSE;
				if($this->limitAge > 0)
				{
					$applyLimit = ($pAge < $this->limitAge);
				}
				else
				{
					$positiveAge = abs($this->limitAge);
					$applyLimit = ($pAge > $positiveAge);
				}
				
				if($applyLimit)
				{
					$retVal["status"] = "nak";
					$retVal["errors"]["AGE_LIMIT"] = "Spiacente, non hai l'eta' per usare questa postazione";
					Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
						" AGE_LIMIT for {$this->getInfo()}",
						TLogger::DEBUG, 'NM_RULEMANAGER');
					return $retVal;
				}
			}
			
			


			
			$this->getCredits();
			$this->availableTime = $this->creditFreeAvailable + $this->credit;
			
			
			
			if(  $this->availableTime > 0 && $this->limitCheckCloseTime ) 
			{
				$dtrefobj = new DateTime();
				$dtrefobj->setTimestamp($dtref);
				Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
					" check library close time (datetime reference is {$dtrefobj->format( "Y-m-d H:i:s")})",
					TLogger::DEBUG, 'NM_RULEMANAGER');
				
				/*
				* 2016-06-21
				* Positive value into rule mean postponement so cut down reference time.
				*/
				if($this->limitCheckCloseTimeVal > 60)
				{
					$di = new DateInterval("PT".$this->limitCheckCloseTimeVal."S");
					$dtrefobj->sub($di);
					Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
						" ant. datetime reference to {$dtrefobj->format( "Y-m-d H:i:s")}",
						TLogger::DEBUG, 'NM_RULEMANAGER');
				}
				
				/*
				* 2016-06-21
				* Negative value into rule mean advance so increase reference time.
				*/
				if($this->limitCheckCloseTimeVal < -60)
				{
					$diff = abs($this->limitCheckCloseTimeVal);
					$di = new DateInterval("PT" . $diff . "S");
					$dtrefobj->add($di);
					Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
						" post. datetime reference to {$dtrefobj->format( "Y-m-d H:i:s")}", 
						TLogger::DEBUG, 'NM_RULEMANAGER');
				}
				$this->getTimeToEnd($dtrefobj);
				Prado::log(__METHOD__ .	" time to end is {$this->timeToEnd} (with diff {$this->limitCheckCloseTimeVal} included)",
						TLogger::DEBUG, 'NM_RULEMANAGER');
				if($this->timeToEnd > 0)
				{
					Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
						" compare time to end with available time",
						TLogger::DEBUG, 'NM_RULEMANAGER');
					if($this->availableTime > $this->timeToEnd)
					{
						Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
							" get time to end because is less than available time",
							TLogger::DEBUG, 'NM_RULEMANAGER');
						$this->availableTime = $this->timeToEnd;
					}
				}
				else
				{
					$this->availableTime = 0;
					$retVal["status"] = "nak";
					$retVal["errors"]["LIBRARY_NOT_OPEN"] = "Biblioteca chiusa";
					Prado::log(__METHOD__ . "[" . __LINE__ . "] " . 
						" library {$this->resource->getLibraryId()} close", 
						TLogger::INFO);
					PatronActionPeer::writePatronAction(  $this->patron->getPatronId(),
												$this->resource->getLibraryId(),
												PatronActionPeer::ACCESS_FAILED, 
												"biblioteca chiusa");
					return $retVal;
				}
			}
			else
			{
				Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
					" IGNORE library close time", 
					TLogger::DEBUG, 'NM_RULEMANAGER');
			}
			
			
			/*
			 * If a time limit is given, assign the lowest
			 */
			if( $this->limitTime > 0 && $this->availableTime > 0)
			{
				
				Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
						"  a time limit is set. Amount: {$this->limitTime}",
						TLogger::DEBUG, 'NM_RULEMANAGER');
				
				//Limit is local to library and resource
				$creditUsedByDayLibRes = $this->patron->getSessionTime($dtref, $this->libraryId, $this->resource_id, $this->devip);
				
				//Get the relative time 
				$dow = date('w', time());
				$relativeLimit = 0;
				$limitTimeSec = $this->limitTime;
				
				if(  array_key_exists( $dow, $creditUsedByDayLibRes ) )
				{
					
					$todayUsed = $creditUsedByDayLibRes[$dow];
					
					if( $todayUsed < $limitTimeSec )
					{
						$relativeLimit = $limitTimeSec - $todayUsed;
					}
					
					Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
						"  the relative limit is {$relativeLimit}",
						TLogger::DEBUG, 'NM_RULEMANAGER');
				}
				else
				{
					Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
						"  No time used for day of week {$dow} so set full time limit from rule {$this->limitTime}"
						. " Lib is {$this->libraryId}.Credit used array is " . Prado::varDump( $creditUsedByDayLibRes ),
						TLogger::DEBUG, 'NM_RULEMANAGER');
					$relativeLimit = $limitTimeSec;
				}
				
				
				if( $relativeLimit <= 0 )
				{
					$msg = "Spiacente, qui hai raggiunto il tempo massimo a tua disposizione";
					$retVal["status"] = "nak";
					$retVal["errors"]["TIME_LIMIT_REACHED"] = $msg;
					Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
						" TIME_LIMIT reached for {$this->getInfo()}",
						TLogger::DEBUG, 'NM_RULEMANAGER');
					return $retVal;
				}
				
				
				if( $relativeLimit < $this->availableTime )
				{
					$this->availableTime = $relativeLimit;
				}
			}
			
			
			if($this->limitSessionGap > 0 && $this->availableTime > 0)
			{
				$gap = $this->getSessionsGap();
				if( $gap !== FALSE)
				{
					if( $gap < $this->limitSessionGap )
					{

						$retVal["status"] = "nak";
						$diff = $this->limitSessionGap - $gap;
						if( $diff > 60 )
						{
							$diff = round( $diff/60 );
							$retVal["errors"]["SESSION_GAP_LIMIT"] = "Spiacente, devi attendere ancora {$diff} minuti prima di rientrare";
						}
						else
						{
							$retVal["errors"]["SESSION_GAP_LIMIT"] = "Spiacente, devi attendere ancora {$diff} secondi prima di rientrare";
						}
						Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
							" SESSION_GAP_LIMIT for {$this->getInfo()}, gap {$gap} limit {$this->limitSessionGap}, diff {$diff}",
							TLogger::DEBUG, 'NM_RULEMANAGER');
						return $retVal;
					}
					else
					{
						Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
							" Gap ok, limit is {$this->limitSessionGap} and elapsed {$gap}",
							TLogger::DEBUG, 'NM_RULEMANAGER');
					}
				}
				else
				{
					Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
						" Gap is FALSE. May have not session for today or elapsed time is ok.",
						TLogger::DEBUG, 'NM_RULEMANAGER');
				}
			}
			
			
			
			if($this->availableTime > 0)
			{
				$retVal["data"]["credits"] = $this->availableTime;
				Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
					" -------********------ CREDIT FOR THIS SESSION IS {$this->availableTime} ---*****---",
					TLogger::DEBUG, 'NM_RULEMANAGER');
			}
			else
			{
				$retVal["data"]["credits"] = 0;
				$retVal["status"] = "nak";
				$retVal["errors"]["NO_MORE_CREDITS"] = "Spiacente, tempo esaurito";
				Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
					" NO_MORE_CREDITS for {$this->getInfo()}",
					TLogger::DEBUG, 'NM_RULEMANAGER');
			}
			
			Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
				" EXIT --------------------------------------------\n\n",
				TLogger::DEBUG, 'NM_RULEMANAGER');
			
			return $retVal;
			
		} catch (Exception $ex) {
			$retVal["status"] = "nak";
			$retVal["errors"]["EXCEPTION"] = "Errore interno processando le regole di navigazione. Vedi log di clavis";
			Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
				" " . $ex->getMessage(),
				TLogger::DEBUG, 'NM_RULEMANAGER');
			return $retVal;
		}
	}
	
	
	
	
	
	
	
	public function updateCredits($resourcesessionobj, $sessiontime, $dtref = NULL)
	{
		$con = Propel::getConnection();
		$con->beginTransaction();
		
		$retVal = array("status"=>"ack","errors"=>array(),"data"=>array());
		
		
		
		try
		{ 	
			if( is_null($dtref) )
			{
				$dtref = time();
			}
			else
			{
				$dt = date("d-m-Y H:i:s", $dtref);
				Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
					" Using user defined reference time {$dt}",
					TLogger::DEBUG, 'NM_RULEMANAGER');
			}
			
			$this->loadRules();
			
			if($sessiontime > 0)
			{
				//First, convert session time to minutes
				//$sessiontimeMin = round($sessiontime/60);
				
				$this->getUsedTime($dtref);
				$this->getCredits();

				$paycredit = 0;

				/*
				 * If There is free credit,  remove free credit available from sessiontime
				 */
				if($this->creditFreeAvailable >  0 ) 
				{
					if($this->creditFreeAvailable < $sessiontime) 
					{
						$paycredit = $sessiontime - $this->creditFreeAvailable;
					}
					//else I have used only free time so paycredits remain 0
					
					Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
						" free credits found ({$this->creditFreeAvailable}), pay credit is {$paycredit}/{$this->credit} (session used {$sessiontime})", 
						TLogger::DEBUG, 'NM_RULEMANAGER');
				}
				else
				{
					$paycredit = $sessiontime;
					Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
						" no more free credits found, pay credit is {$paycredit}/{$this->credit} (session used {$sessiontime})", 
						TLogger::DEBUG, 'NM_RULEMANAGER');
				}

				if($paycredit > 0)
				{
					$creditrim = $paycredit;
					if( count($this->credits) > 0 )
					{
						foreach($this->credits as $credit)
						{
							$creditid = $credit->getResourceRuleId();
							
							$ctype = $credit->getType();
							if($ctype != ResourceRule::TYPE_CREDIT)
							{
								continue;
							}
							
							$creditSec = $credit->getAmount() * 60;
							$creditSec = round($creditSec);
							
							$creditUsedSec = $credit->getUsed() * 60;
							$creditUsedSec = round($creditUsedSec);
							
							$availablecredit = $creditSec - $creditUsedSec;
							
							Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
									" available credit from rule id {$creditid}: {$availablecredit}, needed credit is {$creditrim}", 
									TLogger::DEBUG, 'NM_RULEMANAGER');
									
							if($availablecredit >= $creditrim)
							{
								$u = ($creditUsedSec + $creditrim) / 60;
								$u = round($u);
								$credit->setUsed($u);
								$credit->save();
								
								Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
									" update credit (used {$u}) to rule id {$creditid}", 
									TLogger::DEBUG, 'NM_RULEMANAGER');
								break;
							}
							else
							{
								Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
									" Credit available is too low, {$availablecredit}  from rule id {$creditid}", 
									TLogger::DEBUG, 'NM_RULEMANAGER');
								
								$u = ($creditUsedSec + $availablecredit) / 60;
								$u = round($u);
								$credit->setUsed( $u );
								$credit->save();
								
								Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
									" take all credit from rule id {$creditid}", 
									TLogger::DEBUG, 'NM_RULEMANAGER');
									
								$creditrim -= $availablecredit;
								
								if($creditrim <= 0)
								{
									Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
										" no more credit is needed, exit from rules loop", 
										TLogger::DEBUG, 'NM_RULEMANAGER');
									break;
								}
								else
								{
									Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
										" update credit to take remain credit ({$creditrim}) from next rule ", 
										TLogger::DEBUG, 'NM_RULEMANAGER');
								}
							}
						}
					}
					else
					{
						Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
									" No credit rule found.", 
									TLogger::DEBUG, 'NM_RULEMANAGER');
					}
				}
			}//amount > 0
			
			if(  ! is_null( $resourcesessionobj ) )
			{
				$rsid = $resourcesessionobj->getResourceSessionId();
				Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
							" set acctstoptime to session id ".$rsid , 
							TLogger::DEBUG, 'NM_RULEMANAGER');
				$resourcesessionobj->setAcctstoptime ( time() );
				//$secTot = round($sessiontimeMin * 60);
				$resourcesessionobj->setAcctsessiontime( $sessiontime );
				$resourcesessionobj->save();
			}
			$con->commit();
			
			return $retVal;
			
		}
		catch (Exception $ex) 
		{
			$con->rollBack();
			Prado::log(__METHOD__ . " EXCP " . $ex->getMessage());
			$retVal["status"] = "nak";
			$retVal["errors"]["EXCEPTION"] = "Errore sul server clavis aggiornando i crediti. Consultare i log di clavis";
			return $retVal;
		}

	}
		
}
