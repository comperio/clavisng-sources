<?php
/**
 * Apply rules to a resource
 *
 * To use this module please add something like
 * <module id="rulemanager" class="RuleManager" ComputeLibraryTime="false" ComputeResourceTime="false" UseRegex="false" DefaultPolicy="deny" />
 * to application.xml
 * 
 * @author Cristian Chiarello <ciarez@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2009-2015 Comperio srl
 * @license http://www.comperio.it/license/
 */
class RuleManager extends TModule
{
	public $patron_id;
	public $resource_id;
	
	public $patron;
	public $resource;


	public $creditFreeWeek;
	public $creditFreeDay;
	public $creditFreeAvailable;
	public $credit;
	public $creditAmount;
	public $creditUsed;
	public $creditTotal;
	public $limitAge;
	public $limitSessionGap;
	public $limitDisabled;
	public $limitCheckCloseTime;
	public $limitCheckCloseTimeVal;
	public $limitTime;
	public $limitTotal;
	public $usedTimeWeek;//From Monday to yesterday, minutes
	public $usedTimeDay;//today, minutes
	public $usedTime;//From monday to now, minutes
	public $usedTimeWeekSec;//From Monday to yesterday, seconds
	public $usedTimeDaySec;//today, seconds
	public $usedTimeSec;//From monday to now, seconds
	public $timeToEnd; //time to lib to close
	public $availableTime;
	public $limits;
	public $credits;
	public $creditUsedByDay;
	public $subresid;
	public $matchingRules;
	public $computeLibraryTime; //If true, compute patron used time on specific library
	public $computeResourceTime; //If true, compute patron used time on specific resource
	public $useRegex; //if true search rules with regex instead of substring
	public $libraryId;
	public $defaultPolicy;
	
	const COMPUTE_TIME_GLOBAL = 0;
	const COMPUTE_TIME_LIBRARY = 1;
	const COMPUTE_TIME_RESOURCE = 2;
	const COMPUTE_TIME_LIBRARY_RESOURCE = 3;
				
	public function setLibraryId( $libId )
	{
		$this->libraryId = $libId;
	}
	
	public function setUseRegex( $usere )
	{
		if( $usere == 'true')
		{
			$this->useRegex = TRUE;
		}
		else
		{
			$this->useRegex = FALSE;
		}
	}
	
	
	public function getUseRegex(  )
	{
		if(isset($this->useRegex))
		{
			return $this->useRegex;
		}
		else
		{
			return FALSE;
		}
	}
	
	
	public function setDefaultPolicy( $dp )
	{
		$this->defaultPolicy = $dp;
	}
	
	public function getDefaultPolicy(  )
	{
		if(isset($this->defaultPolicy))
		{
			return $this->defaultPolicy;
		}
		else
		{
			return 'deny';
		}
	}
	
	
	public function setComputeLibraryTime( $clt )
	{
		if( $clt == 'true')
		{
			$this->computeLibraryTime = TRUE;
		}
		else
		{
			$this->computeLibraryTime = FALSE;
		}
	}
	
	public function setComputeResourceTime( $clt )
	{
		if( $clt == 'true')
		{
			$this->computeResourceTime = TRUE;
		}
		else
		{
			$this->computeResourceTime = FALSE;
		}
	}
	
	/*
	 * Init vars used for search used time and rules
	 * framedipaddress is the identifier of subresource (on mikrotik is the ip of connected device,
	 * on userful is the station id, on a pc resource name and framedipaddress can be the same)
	 */
	public function initVars( $patron, $resource, $framedipaddress)
	{
		
		$this->creditFreeWeek = 0;
		$this->creditFreeDay = 0;
		$this->creditFreeAvailable = 0;
		$this->credit = 0;
		$this->creditAmount = 0;
		$this->creditUsed = 0;
		$this->creditTotal = 0;
		$this->limitTime = 0;
		$this->limitAge = 0;
		$this->limitSessionGap = 0;
		$this->limitDisabled = FALSE;
		$this->limitCheckCloseTime = TRUE;
		$this->limitCheckCloseTimeVal = 0;
		$this->limitTotal = 0;
		$this->usedTimeWeek = 0;
		$this->usedTimeDay = 0;
		$this->usedTime = 0;
		$this->usedTimeWeekSec = 0;
		$this->usedTimeDaySec = 0;
		$this->usedTimeSec = 0;
		$this->timeToEnd = -1;
		$this->availableTime  = 0;
		$this->limits = array();
		$this->credits = array();
		$this->creditUsedByDay = NULL;
		$this->matchingRules = 0;
		$this->subresid = '';
		
		
		if( !is_null( $patron ) )
		{
			$this->patron = $patron;
			$this->patron_id = $patron->getPatronId();
		}


		if( !is_null( $resource ) )
		{
			$this->resource = $resource;
			$this->resource_id = $resource->getResourceId();
			$this->libraryId = $resource->getLibraryId();
		}

		if( !is_null( $framedipaddress))
		{
			$this->subresid = $framedipaddress;
			Prado::log(__METHOD__   ." " . __LINE__ .
				" Framedipaddress (sub resource id) is set. Resource ip " . $this->resource->getName() . " - calling ip " . $this->subresid, 
				TLogger::DEBUG);
		}
		else
		{
			Prado::log(__METHOD__   ." " . __LINE__ .
				" Any rule pattern is set.", 
				TLogger::DEBUG);
			if( !is_null( $resource ) )
			{
				$this->subresid = $this->resource->getName();
				Prado::log(__METHOD__   ." " . __LINE__ .
					" Resource found, take resource IP as pattern (resource ip and calling ip are the same: " . $this->subresid.")", 
					TLogger::DEBUG);
			}
			else
			{
				throw new Exception( __METHOD__ . ' Resource object is NULL' );
			}
		}


		
	}
	
	public function __toString()
	{
		return "patron id:{$this->patron_id}"
		. " resource id: {$this->resource_id} "
		. "creditFreeWeek: {$this->creditFreeWeek}"
		. " creditFreeDay: {$this->creditFreeDay} "
		. "credit: {$this->credit} "
		. "usedTimeWeek: {$this->usedTimeWeek} "
		. "usedTimeDay: {$this->usedTimeDay} "
		. "usedTime: {$this->usedTime}";
	}
	
	public function getInfo()
	{		
		return $this->patron->getOpacUsername() . " - " . $this->resource->getName();
	}
	
	
	
	
	public function loadRules()
	{
		Prado::log(__METHOD__   ." -------------------------------------------------", TLogger::DEBUG);
		
		$libid = $this->resource->getLibraryId();
		$resname = $this->resource->getName();
		Prado::log(__METHOD__   ." " . __LINE__ .
				" Get lib id  {$libid} from registered resource {$resname}.", 
				TLogger::DEBUG);
		$rulesResultSet = ResourceRuleQuery::create()
			->filterByLibraryId($libid)
			->filterByResourceOwner($resname)
			->filterByPatronId($this->patron_id)
			->_or()
			->where(" patron_id IS NULL")
			->_and()
			->where(" ((validity_start IS NULL AND validity_end IS NULL) OR (NOW() BETWEEN validity_start AND validity_end)) ")
			->orderBy("patron_id", Criteria::DESC)
			->orderBy("used", Criteria::DESC)
			->orderBy( 'priority' );
		
		$nRules = $rulesResultSet->count();
		Prado::log(__METHOD__   ." " . __LINE__ .
				"  Found {$nRules} rules for this library.", 
				TLogger::DEBUG);
		
		$rules = $rulesResultSet->find();
		
		$pattern = $this->subresid;
		
		foreach ($rules as $rule)
		{
			//Prado::log(Prado::varDump( $rule ), 
			//	TLogger::DEBUG);
			
			// Get the pattern to match against from rule
			$rp = $rule->getResourcePattern();
			
			$patternMatch = FALSE;
			
			Prado::log(__METHOD__   .
				" use regex is " . $this->useRegex, 
				TLogger::DEBUG);
			
			if($this->useRegex === TRUE)
			{
				$rp = '/'.$rp.'/i';
				$pm = preg_match($rp,$pattern);
				$patternMatch =  ( $pm === 1 ) ? TRUE : FALSE;
				Prado::log(__METHOD__   ." " . __LINE__ .
					" REGEX rule pattern is {$rp}", 
					TLogger::DEBUG);
			}
			else
			{
				$patternMatch = ( strpos($pattern,$rp) !== FALSE ) ? TRUE : FALSE;
				Prado::log(__METHOD__   ." " . __LINE__ .
					" SUBSTR rule pattern is {$rp}", 
					TLogger::DEBUG);
			}
					
			//if(strpos($pattern,$rp) !== FALSE)
			if( $patternMatch === TRUE )
			{
				Prado::log(__METHOD__   ." " . __LINE__ .
					" ok, match with calling  {$pattern}", 
					TLogger::DEBUG);
					
				$rtype = $rule->getType();
				if( strpos($rtype,'LIMIT') !== FALSE )
				{
					Prado::log(__METHOD__   ." " . __LINE__ .
					" rule is limit", 
					TLogger::DEBUG);
					$this->limits[] = $rule;
				}
				
				if( strpos($rtype,'CREDIT') !== FALSE )
				{
					Prado::log(__METHOD__   ." " . __LINE__ .
					" rule is credit", 
					TLogger::DEBUG);
					$credamount = round( floatval( $rule->getAmount() ) );
					$credused = round( floatval( $rule->getUsed() ) );
					if( $credamount >  $credused )
					{
						$this->credits[] = $rule;
					}
					else
					{
						Prado::log(__METHOD__   .
							" rule {$rule->getResourceRuleId()} exausted: IGNORE IT", 
							TLogger::DEBUG);
					}
				}
				$this->matchingRules++;
			}
			else
			{
				Prado::log(__METHOD__   ." " . __LINE__ .
					" no, {$rp}  is not for calling ip  {$pattern}", 
					TLogger::DEBUG);
			}
			Prado::log(__METHOD__   ." " . __LINE__ .
				"  Found {$this->matchingRules} rules matching with pattern {$rp}.", 
				TLogger::DEBUG);
		}
		
		
		Prado::log(__METHOD__   ." " . __LINE__ .
				" Limits for {$pattern}.", 
				TLogger::DEBUG,"LLDebug");
		Prado::log(Prado::varDump( $this->limits), 
				TLogger::DEBUG,"LLDebug");
		
		Prado::log(__METHOD__   ." " . __LINE__ .
				" Credits for {$pattern}.", 
				TLogger::DEBUG,"LLDebug");
		Prado::log(Prado::varDump( $this->credits), 
				TLogger::DEBUG,"LLDebug");
		
	}
	
	
	
	
	/**
	 * Compute credits
	 * NOTE: free credit (without "pay" credit) can be a limit.
	 */
	public function getCredits()
	{
		Prado::log(__METHOD__   ." -------------------------------------------------", TLogger::DEBUG);
		
		if(count($this->credits) <= 0)
		{
			Prado::log(__METHOD__   ." " . __LINE__ .
				" no credits found for {$this->subresid}.", 
				TLogger::DEBUG);
			return;
		}
		
		Prado::log(__METHOD__   ." " . __LINE__ . 
			" Search credits for {$this->getInfo()}",
			TLogger::DEBUG);
		
		foreach($this->credits as $rule)
		{
			$type = $rule->getType();
			$pid = $rule->getPatronId();
			
			$amount = round($rule->getAmount());
			$amount = $amount * 60;
			
			switch ($type) {
				case ResourceRule::TYPE_CREDIT_FREE_WEEK:
					$this->creditFreeWeek += $amount;
					break;
			
				case ResourceRule::TYPE_CREDIT_FREE_DAY:
					$this->creditFreeDay += $amount;
					break;
			
				case ResourceRule::TYPE_CREDIT:
					$used = round($rule->getUsed());
					$used = $used * 60;
					$this->creditAmount += $amount;
					$this->creditUsed += $used;
					$this->credit += ($amount - $used);
					Prado::log(__METHOD__   .
							" CREDIT {$amount} - {$used} = {$this->credit} ",
							TLogger::DEBUG);
					break;
			}
		}		

		if($this->creditFreeDay == 0)
		{
			Prado::log(__METHOD__   ." " . __LINE__ . 
				" RESET creditFreeWeek because creditFreeDay = 0",
				TLogger::DEBUG);
			$this->creditFreeWeek = 0;
		}

		$this->creditTotal = $this->creditFreeWeek + $this->creditFreeDay + $this->credit;
		
		Prado::log(__METHOD__   ." " . __LINE__ . 
			" CREDITS amount after parsing credit rules FREE: week {$this->creditFreeWeek} day {$this->creditFreeDay} PAY: {$this->credit} TOT {$this->creditTotal}",
			TLogger::DEBUG);
		
		
		
		

		/*
		 * This need a user brain debug... :)
		 * If week free credits is less than day free credits, reset week free credits
		 */
		if($this->creditFreeWeek > 0 && $this->creditFreeWeek < $this->creditFreeDay)
		{
			Prado::log(__METHOD__ . " WARNING! free credit free day is bigger than credit free week for {$this->getInfo()}, reset week free credits");
			$this->creditFreeWeek = 0;
		}


		
		
		$freeCreditUsedWeek = 0;
		$freeCreditAvailableWeek = 0;
		
		foreach( $this->creditUsedByDay as $utd )
		{
			if($utd >= $this->creditFreeDay)
			{
				$freeCreditUsedWeek += $this->creditFreeDay;
			}
			else
			{
				$freeCreditUsedWeek += $utd;
			}
		}
		
		if( $this->creditFreeWeek > $freeCreditUsedWeek )
		{
			$freeCreditAvailableWeek = $this->creditFreeWeek - $freeCreditUsedWeek;
			Prado::log(__METHOD__   ." " . __LINE__ .
				"  freeCreditAvailableWeek {$freeCreditAvailableWeek} = this->creditFreeWeek {$this->creditFreeWeek} - freeCreditUsedWeek {$freeCreditUsedWeek}", 
				TLogger::DEBUG);
		}
		else
		{
			Prado::log(__METHOD__   ." " . __LINE__ .
				" no free week credits found, so freeCreditAvailableWeek = {$freeCreditAvailableWeek}", 
				TLogger::DEBUG);
		}
		
		
		$freeCreditUsedDay = 0;
		$freeCreditAvailableDay = 0;
		
		Prado::log(__METHOD__ . "   creditUsedByDay array is: ".
			Prado::varDump( $this->creditUsedByDay ), 
			TLogger::DEBUG,
			"LLDebug");
		
		$dow = date('w', time());
		
		Prado::log(__METHOD__   ." " . __LINE__ .
				"  Getting the day of week: {$dow}",
				TLogger::DEBUG);
					
		if(  array_key_exists( $dow, $this->creditUsedByDay ))
		{
			if( $this->creditUsedByDay[$dow] > $this->creditFreeDay )
			{
				$freeCreditUsedDay += $this->creditFreeDay;
			}
			else
			{
				$freeCreditUsedDay += $this->creditUsedByDay[$dow];
			}
			
			Prado::log(__METHOD__   ." " . __LINE__ .
				"  freeCreditUsedDay = {$freeCreditUsedDay}",
				TLogger::DEBUG);
			
		}
		else
		{
			Prado::log(__METHOD__   ." " . __LINE__ .
				"  index {$dow} not found in this->creditUsedByDay[] so freeCreditUsedDay = {$freeCreditUsedDay}",
				TLogger::DEBUG);
		}
		
		
		if( $this->creditFreeDay > $freeCreditUsedDay )
		{
			$freeCreditAvailableDay = $this->creditFreeDay - $freeCreditUsedDay;
			Prado::log(__METHOD__   ." " . __LINE__ .
				"  freeCreditAvailableDay {$freeCreditAvailableDay} = this->creditFreeDay {$this->creditFreeDay} - freeCreditUsedDay {$freeCreditUsedDay}", 
				TLogger::DEBUG);
		}
		else
		{
			Prado::log(__METHOD__   ." " . __LINE__ .
				"  freeCreditAvailableDay = {$freeCreditAvailableDay}  because  freeCreditUsedDay {$freeCreditUsedDay} > this->creditFreeDay {$this->creditFreeDay}", 
				TLogger::DEBUG);
		}
		

		//If I have both week and day free credit rule... 
		if($this->creditFreeWeek > 0 && $this->creditFreeDay > 0)
		{
			Prado::log(__METHOD__   ." " . __LINE__ . 
					" free week and free day credits detected",
					TLogger::DEBUG);
			
			//take the minor of the computed time
			if($freeCreditAvailableWeek < $freeCreditAvailableDay)
			{
				Prado::log(__METHOD__   ." " . __LINE__ . 
					" freeCreditAvailableWeek < freeCreditAvailableDay",
					TLogger::DEBUG);
				$this->creditFreeAvailable = $freeCreditAvailableWeek;
			}
			else
			{
				Prado::log(__METHOD__   ." " . __LINE__ . 
					" freeCreditAvailableWeek >= freeCreditAvailableDay",
					TLogger::DEBUG);
				$this->creditFreeAvailable = $freeCreditAvailableDay;
			}
		}
		else //Only one of free credits available
		{
			if($freeCreditAvailableWeek > 0)
			{
				Prado::log(__METHOD__   ." " . __LINE__ . 
					" freeTimeAvailableWeek  only",
					TLogger::DEBUG);
				$this->creditFreeAvailable = $freeCreditAvailableWeek;
			}

			if($freeCreditAvailableDay > 0)
			{
				Prado::log(__METHOD__   ." " . __LINE__ . 
					"  freeTimeAvailableDay only",
					TLogger::DEBUG);
				$this->creditFreeAvailable = $freeCreditAvailableDay;
			}
		}			
		
		
		

		
	}
	
	
	
	
	
	
	
	
	
	public function getLimits()
	{
		Prado::log(__METHOD__   ." -------------------------------------------------", TLogger::DEBUG);
		
		if(count($this->limits) <= 0)
		{
			Prado::log(__METHOD__   ." " . __LINE__ .
				" no limits found for {$this->subresid}.", 
				TLogger::DEBUG);
			return;
		}
		
		Prado::log(__METHOD__   ." " . __LINE__ . 
			" Search limits for {$this->getInfo()}",
			TLogger::DEBUG);
		
		foreach($this->limits as $rule)
		{
			$type = $rule->getType();
			Prado::log(__METHOD__   ." " . __LINE__ . 
					" Limit type is {$type}",
					TLogger::DEBUG);
			$pid = $rule->getPatronId();
			$amount = round($rule->getAmount());
			$amount = $amount * 60;
			switch ($type) {
				case 'LIMIT_TIME':
					$this->limitTime += $amount;
					break;

				case 'LIMIT_AGE':
					$this->limitAge = round($rule->getAmount());
					break;

				case 'LIMIT_SESSION_GAP':
					$this->limitSessionGap = $amount;
					break;

				case 'LIMIT_DISABLED':
					if($amount != 0)
					{
						$this->limitDisabled = TRUE;
					}
					else
					{
						$this->limitDisabled = FALSE;
					}
					break;
					
				case 'LIMIT_CHECK_CLOSE_TIME':
					/*
					* If check close time limit is set, ignore 1,0,-1 values. Else negative value reduce time and
					* positive values increase the time
					*/
					if($amount != 0)
					{
						if( $amount > 60 || $amount  < -60)
						{
							$this->limitCheckCloseTimeVal = $amount;
							Prado::log(__METHOD__   ." " . __LINE__ . 
									" check close time with diff {$amount}",
									TLogger::DEBUG);
						}
						else
						{
							Prado::log(__METHOD__   ." " . __LINE__ . 
									" check close time with no diff",
									TLogger::DEBUG);
						}
					}
					else
					{
						$this->limitCheckCloseTime = FALSE;
					}
					break;

			}
		}		
	}
	
	

	
	public function getTimeToEnd($dtrefobj)
	{
		
		//################ TEST ONLY ################
		$testmode = FALSE;
		if($testmode )
		{
			Prado::log(__METHOD__   ." " . __LINE__ .
				" WARNING: test mode active.", 
				TLogger::DEBUG);
			$tmdt = new DateTime();
			
			$ltt = LibraryTimetableQuery::create()
				->filterByLibraryId($this->resource->getLibraryId())
				->filterByTimetableDay($tmdt)
				->filterByTimetableNote("TEST")
				->findOne();
			if( ! ($ltt instanceof LibraryTimetable))
			{
				$ltt = new LibraryTimetable();
				$ltt->setTimetableNote("TEST");
				$ltt->setTimetableDay($tmdt->format("Y-m-d"));
				$ltt->setTime1Start("09:00:00");
			}
			
			$tmdt->add(new DateInterval('PT30M'));
			$ltt->setTime1End($tmdt->getTimestamp());
			$ltt->save();
		}
		//################ TEST ONLY ################
		
		
		
		/*
		 * Check if I have a close time
		 */
		$closedt = NULL;
		$sdref = $dtrefobj->format("Y-m-d");
		Prado::log(__METHOD__   ." " . __LINE__ .
				" search timetable for ({$sdref}).", 
				TLogger::DEBUG);
		$ltt = LibraryTimetableQuery::create()
			->filterByLibraryId($this->resource->getLibraryId())
			->filterByTimetableDay($sdref)
			->findOne();

		if( $ltt instanceof LibraryTimetable)
		{
			
			$te[0] = $ltt->getTime1End(NULL);
			$te[1] = $ltt->getTime2End(NULL);
			$te[2] = $ltt->getTime3End(NULL);
			
			
			for( $i=0; $i < 3; $i++)
			{
				if(  ( ! is_null($te[$i]) ) && ( $te[$i] > $dtrefobj ) )
				{
					$closedt = $te[$i];
					Prado::log(__METHOD__   ." " . __LINE__ .
							" Close time found: {$closedt->format("H:i:s")}", 
							TLogger::DEBUG);
					break;
				}
			}
		}
		else
		{
			Prado::log(__METHOD__   ." " . __LINE__ .
				" no timetable found...", 
				TLogger::DEBUG);
		}

						
		
		
		/*
		 * If a close time exists, check how many minutes I have to close time
		 * Then subtract advance minutes and retiurn the value.
		 */
		if($closedt != NULL)
		{
			$dts = $closedt->format('Y-m-d H:i:s');
			Prado::log(__METHOD__   ." " . __LINE__ .
				" close time  {$dts}.", 
				TLogger::DEBUG);
			
			
			if($closedt > $now)
			{
				$interval = $closedt->diff($dtrefobj);
				Prado::log(Prado::varDump($interval),TLogger::DEBUG,"LLDebug");
				//Prado::log(Prado::varDump($interval),TLogger::DEBUG);
				$minToEnd = $interval->i + ($interval->h * 60);
				Prado::log(__METHOD__   ." " . __LINE__ .
					" {$minToEnd} time left.", 
					TLogger::DEBUG);
				
				$secToEnd = $minToEnd * 60;
				$secToEnd = round($secToEnd);
				$this->timeToEnd = $secToEnd + $diff;
			}
			else
			{
				Prado::log(__METHOD__   ." " . __LINE__ .
				" WARNING: close time past", 
				TLogger::DEBUG);
			}
		}
		
	}
	
	
	
	
	
	/*
	 * Compute patron age (years)
	 */
	public function getPatronAge()
	{
		$now = new DateTime();
		$born = $this->patron->getBirthDate(NULL);
		
		$diff = $now->diff($born);
		return $diff->y;
	}


	
	public function getSessionsGap()
	{
		$now = new DateTime();
		$todaydate = $now->format("Y-m-d");
		
		
		$lastsess = ResourceSessionQuery::create()
			->filterByPatronId($this->patron_id)
			->filterByResourceId($this->resource_id)
			->filterByFramedipaddress($this->subresid)
			->where(" acctstoptime IS NOT NULL AND DATE(acctstoptime) = '{$todaydate}'")
			->orderBy( 'resource_session_id', Criteria::DESC )
			->findOne();
		
		if($lastsess instanceof ResourceSession)
		{
			$lastSessionEnd = $lastsess->getAcctstoptime(NULL);
			$diff = $now->diff($lastSessionEnd);
			$gap = $diff->s + $diff->i * 60 + ($diff->h * 3600);
			if($gap > 0)
			{				
				Prado::log(__METHOD__   ." " . __LINE__ .
					" last session found for {$this->patron->getOpacUsername()} id: {$lastsess->getResourceSessionId()} GAP: {$gap} sec)", 
					TLogger::DEBUG);
				return $gap;
			}
			else
			{
				Prado::log(__METHOD__   ." " . __LINE__ .
					" GAP <=0 detected: now {$now->format("Y-m-d H:i:s")} lastsessionend {$lastSessionEnd->format("Y-m-d H:i:s")} GAP {$gap} sec", 
					TLogger::DEBUG);
				return FALSE;
			}
		}
		else
		{
			Prado::log(__METHOD__   ." " . __LINE__ .
				" nessuna sessione trovata. GAP = FALSE", 
				TLogger::DEBUG);
			return FALSE;
		}
	}
	
	
	/**
	 * Return array of times used by day of week of a patron
	 * See RuleManager module configuration property
	 * @param type $dtref
	 * @throws Exception
	 */
	public function getUsedTime( $dtref )
	{
		Prado::log(__METHOD__   ." -------------------------------------------------", TLogger::DEBUG);
		
		$computeTimePolicy = self::COMPUTE_TIME_GLOBAL;
			
		if( $this->computeLibraryTime && $this->libraryId != NULL)
		{
			$computeTimePolicy = self::COMPUTE_TIME_LIBRARY;
		}

		if( $this->computeResourceTime && $this->resource != NULL)
		{
			$computeTimePolicy = self::COMPUTE_TIME_RESOURCE;
		}

		if( $this->computeLibraryTime && $this->libraryId != NULL && $this->computeResourceTime && $this->resource != NULL)
		{
			$computeTimePolicy = self::COMPUTE_TIME_LIBRARY_RESOURCE;
		}



		if( $this->patron instanceof Patron )
		{

			switch ( $computeTimePolicy )
			{
				case self::COMPUTE_TIME_GLOBAL:
					Prado::log(__METHOD__   ." " . __LINE__ ." Get used session for all libraries and all resources", TLogger::DEBUG);
					$this->creditUsedByDay = $this->patron->getSessionTime($dtref, NULL, NULL);
					break;

				case self::COMPUTE_TIME_LIBRARY:
					Prado::log(__METHOD__   ." " . __LINE__ ." Get used session for library {$this->libraryId} and all resources", TLogger::DEBUG);
					$this->creditUsedByDay = $this->patron->getSessionTime($dtref, $this->libraryId, NULL);
					break;

				case self::COMPUTE_TIME_RESOURCE:
					Prado::log(__METHOD__   ." " . __LINE__ ." Get used session for all libraries and resource {$this->resource_id}", TLogger::DEBUG);
					$this->creditUsedByDay = $this->patron->getSessionTime($dtref, NULL, $this->resource_id);
					break;

				case self::COMPUTE_TIME_LIBRARY_RESOURCE:
					Prado::log(__METHOD__   ." " . __LINE__ ." Get used session for library {$this->libraryId} and resource {$this->resource_id}", TLogger::DEBUG);
					$this->creditUsedByDay = $this->patron->getSessionTime($dtref, $this->libraryId, $this->resource_id);
					break;

				default:
					Prado::log(__METHOD__   ." " . __LINE__ ." Get used session for all libraries and all resources (WARN: default is taken)", TLogger::DEBUG);
					$this->creditUsedByDay = $this->patron->getSessionTime($dtref, NULL, NULL);
					break;
			}


			if( !is_array($this->creditUsedByDay) )
			{
				throw new Exception(__METHOD__ . ' Error computing user used time. See patron->getSessionTime');
			}
		}
		else
		{
			Prado::log(__METHOD__   ." " . __LINE__ ." BUG! Patron is", TLogger::DEBUG);
			Prado::log(__METHOD__   ." " . __LINE__ . Prado::varDump( $this->patron ), TLogger::DEBUG);
			throw new Exception(__METHOD__ . 'Unable to get patron used time patron->getSessionTime');
		}
		
	}
	
	
	
	
	
	/**
	 * Rules main logic
	 * @param type $dtref
	 * @return array
	 */
	public function parseRule( $dtref )
	{
		Prado::log(__METHOD__   ." -------------------------------------------------", TLogger::DEBUG);
		
		$retVal = array("status"=>"ack","errors"=>array(),"data"=>array());
		
		try
		{
			
			$this->loadRules();
			
			if( is_null($dtref) )
			{
				$dtref = time();
			}
			else
			{
				$dt = date("d-m-Y H:i:s", $dtref);
				Prado::log(__METHOD__   ." " . __LINE__ ." Using user defined reference time {$dt}", TLogger::DEBUG);
			}
			
			
			$this->getUsedTime($dtref);
			
			Prado::log(__METHOD__ . " " . Prado::varDump( $this->creditUsedByDay ), TLogger::DEBUG);
			
			$this->getLimits();
			

			
			if($this->matchingRules == 0)
			{
				if(isset($this->defaultPolicy))
				{
					Prado::log(__METHOD__ . " No rule, apply default policy ".$this->defaultPolicy, TLogger::DEBUG);
					if($this->defaultPolicy != 'allow')
					{
						$retVal["status"] = "nak";
						$retVal["errors"]["NO_MATCHING_RULES"] = "Nessuna regola impostata: applico la politica predefinita (negare)";
						return array("status"=>"nak","errors"=>array('NO_MATCHING_RULES'=>'No rule for this resource and default policy is deny'),"data"=>array());
					}
					return $retVal;
				}
					
				
			}
			
			
			if($this->limitDisabled === TRUE)
			{
				$retVal["status"] = "nak";
				$retVal["errors"]["DISABLED_BY_RULE"] = "Spiacente, questa postazione non e' abilitata";
				Prado::log(__METHOD__ . " DISABLED_BY_RULE for {$this->getInfo()}");
				return $retVal;
			}
			
			if($this->limitAge != 0)
			{
				$pAge = $this->getPatronAge();
				
				$applyLimit = FALSE;
				if($this->limitAge > 0)
				{
					$applyLimit = ($pAge < $this->limitAge);
				}
				else
				{
					$positiveAge = abs($this->limitAge);
					$applyLimit = ($pAge > $positiveAge);
				}
				
				if($applyLimit)
				{
					$retVal["status"] = "nak";
					$retVal["errors"]["AGE_LIMIT"] = "Spiacente, non hai l'eta' per usare questa postazione";
					Prado::log(__METHOD__ . " AGE_LIMIT for {$this->getInfo()}");
					return $retVal;
				}
			}
			
			


			
			$this->getCredits();
			$this->availableTime = $this->creditFreeAvailable + $this->credit;
			
			
			
			if(  $this->availableTime > 0 && $this->limitCheckCloseTime ) 
			{
				$dtrefobj = new DateTime();
				$dtrefobj->setTimestamp($dtref);
				Prado::log(__METHOD__ . " check library close time (datetime reference is {$dtrefobj->format( "Y-m-d H:i:s")})", TLogger::DEBUG);
				
				/*
				* 2016-06-21
				* Positive value into rule mean postponement so cut down reference time.
				*/
				if($this->limitCheckCloseTimeVal > 60)
				{
					$di = new DateInterval("PT".$this->limitCheckCloseTimeVal."S");
					$dtrefobj->sub($di);
					Prado::log(__METHOD__ . " ant. datetime reference to {$dtrefobj->format( "Y-m-d H:i:s")}", TLogger::DEBUG);
				}
				
				/*
				* 2016-06-21
				* Negative value into rule mean advance so increase reference time.
				*/
				if($this->limitCheckCloseTimeVal < -60)
				{
					$diff = abs($this->limitCheckCloseTimeVal);
					$di = new DateInterval("PT" . $diff . "S");
					$dtrefobj->add($di);
					Prado::log(__METHOD__ . " post. datetime reference to {$dtrefobj->format( "Y-m-d H:i:s")}", TLogger::DEBUG);
				}
				$this->getTimeToEnd($dtrefobj);
				Prado::log(__METHOD__   ." " . __LINE__ . 
						" time to end is {$this->timeToEnd} (with diff {$this->limitCheckCloseTimeVal} included)",
						TLogger::DEBUG);
				if($this->timeToEnd > 0)
				{
					Prado::log(__METHOD__ . " compare time to end with available time", TLogger::DEBUG);
					if($this->availableTime > $this->timeToEnd)
					{
						Prado::log(__METHOD__ . " get time to end because is less than available time", TLogger::DEBUG);
						$this->availableTime = $this->timeToEnd;
					}
				}
				else
				{
					$this->availableTime = 0;
					$retVal["status"] = "nak";
					$retVal["errors"]["LIBRARY_NOT_OPEN"] = "Biblioteca chiusa";
					Prado::log(__METHOD__ . " " . __LINE__ . " library {$this->resource->getLibraryId()} close", TLogger::INFO, 'NETMANAGER_AUTH');
					PatronActionPeer::writePatronAction(  $this->patron->getPatronId(),
												$this->resource->getLibraryId(),
												PatronActionPeer::ACCESS_FAILED, 
												"biblioteca chiusa");
					return $retVal;
				}
			}
			else
			{
				Prado::log(__METHOD__ . " IGNORE library close time");
			}
			
			
			/*
			 * If a time limit is given, assign the lowest
			 */
			if( $this->limitTime > 0 && $this->availableTime > 0)
			{
				
				Prado::log(__METHOD__   ." " . __LINE__ .
						"  a time limit is set. Amount: {$this->limitTime}",
						TLogger::DEBUG);
				
				//Limit is local to library and resource
				$creditUsedByDayLibRes = $this->patron->getSessionTime($dtref, $this->libraryId, $this->resource_id, $this->subresid);
				
				//Get the relative time 
				$dow = date('w', time());
				$relativeLimit = 0;
				$limitTimeSec = $this->limitTime;
				
				if(  array_key_exists( $dow, $creditUsedByDayLibRes ) )
				{
					
					$todayUsed = $creditUsedByDayLibRes[$dow];
					
					if( $todayUsed < $limitTimeSec )
					{
						$relativeLimit = $limitTimeSec - $todayUsed;
					}
					
					Prado::log(__METHOD__   ." " . __LINE__ .
						"  the relative limit is {$relativeLimit}",
						TLogger::DEBUG);
				}
				else
				{
					Prado::log(__METHOD__   ." " . __LINE__ .
						"  No time used for day of week {$dow} so set full time limit from rule {$this->limitTime}"
						. " Lib is {$this->libraryId}.Credit used array is " . Prado::varDump( $creditUsedByDayLibRes ),
						TLogger::DEBUG);
					$relativeLimit = $limitTimeSec;
				}
				
				
				if( $relativeLimit <= 0 )
				{
					$msg = "Spiacente, qui hai raggiunto il tempo massimo a tua disposizione";
					$retVal["status"] = "nak";
					$retVal["errors"]["TIME_LIMIT_REACHED"] = $msg;
					Prado::log(__METHOD__ . " TIME_LIMIT reached for {$this->getInfo()}");
					return $retVal;
				}
				
				
				if( $relativeLimit < $this->availableTime )
				{
					$this->availableTime = $relativeLimit;
				}
			}
			
			
			if($this->limitSessionGap > 0 && $this->availableTime > 0)
			{
				$gap = $this->getSessionsGap();
				if( $gap !== FALSE)
				{
					if( $gap < $this->limitSessionGap )
					{

						$retVal["status"] = "nak";
						$diff = $this->limitSessionGap - $gap;
						if( $diff > 60 )
						{
							$diff = round( $diff/60 );
							$retVal["errors"]["SESSION_GAP_LIMIT"] = "Spiacente, devi attendere ancora {$diff} minuti prima di rientrare";
						}
						else
						{
							$retVal["errors"]["SESSION_GAP_LIMIT"] = "Spiacente, devi attendere ancora {$diff} secondi prima di rientrare";
						}
						Prado::log(__METHOD__ . " SESSION_GAP_LIMIT for {$this->getInfo()}, gap {$gap} limit {$this->limitSessionGap}, diff {$diff}", TLogger::DEBUG);
						return $retVal;
					}
					else
					{
						Prado::log(__METHOD__   ." " . __LINE__ ." Gap ok, limit is {$this->limitSessionGap} and elapsed {$gap}", TLogger::DEBUG);
					}
				}
				else
				{
					Prado::log(__METHOD__   ." " . __LINE__ ." Gap is FALSE. May have not session for today or elapsed time is ok.", TLogger::DEBUG);
				}
			}
			
			
			
			if($this->availableTime > 0)
			{
				$retVal["data"]["credits"] = $this->availableTime;
				Prado::log(__METHOD__   ." " . __LINE__ .
					" -------********------ CREDIT FOR THIS SESSION IS {$this->availableTime} ---*****---",
					TLogger::DEBUG);
			}
			else
			{
				$retVal["data"]["credits"] = 0;
				$retVal["status"] = "nak";
				$retVal["errors"]["NO_MORE_CREDITS"] = "Spiacente, tempo esaurito";
				Prado::log(__METHOD__ . " NO_MORE_CREDITS for {$this->getInfo()}");
			}
			
			return $retVal;
			
		} catch (Exception $ex) {
			$retVal["status"] = "nak";
			$retVal["errors"]["EXCEPTION"] = "Errore interno processando le regole di navigazione. Vedi log di clavis";
			Prado::log(__METHOD__ . " " . $ex->getMessage());
			return $retVal;
		}
	}
	
	
	
	
	
	
	
	public function updateCredits($resourcesessionobj, $sessiontime, $dtref = NULL)
	{
		$con = Propel::getConnection();
		$con->beginTransaction();
		
		$retVal = array("status"=>"ack","errors"=>array(),"data"=>array());
		
		
		
		try
		{ 	
			if( is_null($dtref) )
			{
				$dtref = time();
			}
			else
			{
				$dt = date("d-m-Y H:i:s", $dtref);
				Prado::log(__METHOD__   ." " . __LINE__ ." Using user defined reference time {$dt}", TLogger::DEBUG);
			}
			
			$this->loadRules();
			
			if($sessiontime > 0)
			{
				//First, convert session time to minutes
				//$sessiontimeMin = round($sessiontime/60);
				
				$this->getUsedTime($dtref);
				$this->getCredits();

				$paycredit = 0;

				/*
				 * If There is free credit,  remove free credit available from sessiontime
				 */
				if($this->creditFreeAvailable >  0 ) 
				{
					if($this->creditFreeAvailable < $sessiontime) 
					{
						$paycredit = $sessiontime - $this->creditFreeAvailable;
					}
					//else I have used only free time so paycredits remain 0
					
					Prado::log(__METHOD__   ." " . __LINE__ .
						" free credits found ({$this->creditFreeAvailable}), pay credit is {$paycredit}/{$this->credit} (session used {$sessiontime})", 
						TLogger::DEBUG);
				}
				else
				{
					$paycredit = $sessiontime;
					Prado::log(__METHOD__   ." " . __LINE__ .
						" no more free credits found, pay credit is {$paycredit}/{$this->credit} (session used {$sessiontime})", 
						TLogger::DEBUG);
				}

				if($paycredit > 0)
				{
					$creditrim = $paycredit;
					if( count($this->credits) > 0 )
					{
						foreach($this->credits as $credit)
						{
							$creditid = $credit->getResourceRuleId();
							
							$ctype = $credit->getType();
							if($ctype != ResourceRule::TYPE_CREDIT)
							{
								continue;
							}
							
							$creditSec = $credit->getAmount() * 60;
							$creditSec = round($creditSec);
							
							$creditUsedSec = $credit->getUsed() * 60;
							$creditUsedSec = round($creditUsedSec);
							
							$availablecredit = $creditSec - $creditUsedSec;
							
							Prado::log(__METHOD__   ." " . __LINE__ .
									" available credit from rule id {$creditid}: {$availablecredit}, needed credit is {$creditrim}", 
									TLogger::DEBUG);
									
							if($availablecredit >= $creditrim)
							{
								$u = ($creditUsedSec + $creditrim) / 60;
								$u = round($u);
								$credit->setUsed($u);
								$credit->save();
								
								Prado::log(__METHOD__   ." " . __LINE__ .
									" update credit (used {$u}) to rule id {$creditid}", 
									TLogger::DEBUG);
								break;
							}
							else
							{
								Prado::log(__METHOD__   ." " . __LINE__ .
									" Credit available is too low, {$availablecredit}  from rule id {$creditid}", 
									TLogger::DEBUG);
								
								$u = ($creditUsedSec + $availablecredit) / 60;
								$u = round($u);
								$credit->setUsed( $u );
								$credit->save();
								
								Prado::log(__METHOD__   ." " . __LINE__ .
									" take all credit from rule id {$creditid}", 
									TLogger::DEBUG);
									
								$creditrim -= $availablecredit;
								
								if($creditrim <= 0)
								{
									Prado::log(__METHOD__   ." " . __LINE__ .
										" no more credit is needed, exit from rules loop", 
										TLogger::DEBUG);
									break;
								}
								else
								{
									Prado::log(__METHOD__   ." " . __LINE__ .
										" update credit to take remain credit ({$creditrim}) from next rule ", 
										TLogger::DEBUG);
								}
							}
						}
					}
					else
					{
						Prado::log(__METHOD__   ." " . __LINE__ .
									" No credit rule found.", 
									TLogger::DEBUG);
					}
				}
			}//amount > 0
			
			if(  ! is_null( $resourcesessionobj ) )
			{
				$rsid = $resourcesessionobj->getResourceSessionId();
				Prado::log(__METHOD__   ." " . __LINE__ .
							" set acctstoptime to session id ".$rsid , 
							TLogger::DEBUG);
				$resourcesessionobj->setAcctstoptime ( time() );
				//$secTot = round($sessiontimeMin * 60);
				$resourcesessionobj->setAcctsessiontime( $sessiontime );
				$resourcesessionobj->save();
			}
			$con->commit();
			
			return $retVal;
			
		}
		catch (Exception $ex) 
		{
			$con->rollBack();
			Prado::log(__METHOD__ . " EXCP " . $ex->getMessage());
			$retVal["status"] = "nak";
			$retVal["errors"]["EXCEPTION"] = "Errore sul server clavis aggiornando i crediti. Consultare i log di clavis";
			return $retVal;
		}

	}
		
}