<?php
/**
 * NotificationManager class file
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @link      http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license   http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version   2.7
 */

/**
 * NotificationManager Class
 *
 * @author    Ciro Mattia Gonano
 * @link      http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2008 ePortal Technologies
 * @copyright Copyright &copy; 2009 Comperio srl
 * @version   2.7
 * @package   Core
 * @since     2.4
 */
class NotificationManager extends TModule
{
    const ERR_NOINITCHAN = 1;
    const ERR_MISSINGRCPT = 2;
    const ERR_NOTIMPLEMENTED = 3;
    const ERR_GENERIC = 4;
    const ERR_NOCREDIT = 5;
    const ERR_ADDRESSEMPTY = 6;

    const EMAIL_AUTO = 0;
    const EMAIL_MANUAL = 1;

    /**
     * JasperReport is a particular type of SnailMailReport
     *
     * @param JasperPrintBox $jrpbox            The JasperPrintBox component
     * @param string         $object_id         The P_OBJECT_ID parameter
     * @param array          $other_params      Optional parameters (defaults to array())
     * @param array          $notification_data Notification data - if it's not valorized, doesn't add notification.
     * @return true
     */
    public function DoJasperReport(JasperPrintBox $jrpbox, $object_id,
                                   $other_params = array(), $notification_data = array())
    {
        if ($notification_data) {
            // only add notification
            $n = NotificationPeer::addNewNotification(NotificationPeer::CHANNEL_SNAILMAIL,
                $notification_data['sender_library_id'],
                $notification_data['receiver_class'],
                $notification_data['receiver_id'],
                $notification_data['description'],
                $notification_data['notes']);
        } else {
            $jrpbox->setObjectId($object_id);
            if ($other_params)
                foreach ($other_params as $param_name => $param_value)
                    $jrpbox->addOptionalParam($param_name, $param_value);
            $jrpbox->printReport();
        }
        return true;
    }


    /**
     * Performs a report by email.
     *
     * @param string $templatebody
     * @param array  $arrAlias
     * @param array  $mailData
     * @param int    $mailMode
     * @param array  $notificationData
     * @return bool
     * @throws Exception
     */
    public function DoEmailReport($templatebody,
                                  Array $arrAlias = array(),
                                  Array $mailData = array(),
                                  $mailMode = self::EMAIL_AUTO,
                                  Array $notificationData = array())
    {
        $body = DocumentTemplatePeer::templateTransform($templatebody, $arrAlias);
        $notificationData['description'] .= "\n$body";

        if (!$mailData) {
            header('Content-Type: Content-Type: text/plain; charset="UTF-8"');
            header('Content-Length: ' . strlen($body));
            header('Content-disposition: inline; filename=mailbody.txt');

            echo $body;
            exit();
        } else {
            if (count($mailData['to']) < 1)
                throw new Exception('No receivers specified', self::ERR_MISSINGRCPT);

            if ($mailMode == self::EMAIL_MANUAL)    // Send email via Browser default client email
            {
                $mailstring = "mailto:{$mailData['to'][0]}?subject=" . $mailData['subject'] . "&body=" . urlencode($body);
                $mailstring = str_replace('+', ' ', $mailstring);

                //Thunderbird patch (translate accented chars)
                $acc_search = array("%F2", "%E0", "%F9", "%E8", "%E9", "%EC");
                $acc_replace = array("o%27", "a%27", "u%27", "e%27", "e%27", "i%27");
                $mailstring = str_replace($acc_search, $acc_replace, $mailstring);

                $notificationData['email_mode'] = 'MANUAL';

                if (!isset($notificationData['notification_class']))
                    $notificationData['notification_class'] = 'H'; // Generic notification

                if (!isset($notificationData['loan_id']))
                    $notificationData['loan_id'] = null;

                $n = NotificationPeer::addNewNotification(NotificationPeer::CHANNEL_EMAIL,
                    $notificationData['sender_library_id'],
                    $notificationData['receiver_class'],
                    $notificationData['receiver_id'],
                    $notificationData['description'],
                    $notificationData['notes'],
                    $notificationData['notification_class'],
                    $notificationData['loan_id']);

                $n->setNotificationState(NotificationPeer::STATUS_DELIVERED);
                $n->setInternalStatus("MANUAL");
                $n->save();

                header("Location: $mailstring");

            } elseif ($mailMode == self::EMAIL_AUTO) {
                $notificationData['email_mode'] = 'AUTO';

                if (!isset($notificationData['notification_class']))
                    $notificationData['notification_class'] = 'H'; // Generic notification

                if (!isset($notificationData['loan_id']))
                    $notificationData['loan_id'] = null;

                $n = NotificationPeer::addNewNotification(NotificationPeer::CHANNEL_EMAIL,
                    $notificationData['sender_library_id'],
                    $notificationData['receiver_class'], $notificationData['receiver_id'],
                    $notificationData['description'], $notificationData['notes'],
                    $notificationData['notification_class'],
                    $notificationData['loan_id']);

                /** @var $mailer SMTPMail */
                $mailer = $this->getApplication()->getModule('mail');

                $mailer->setHeaders([
                    "X-Mailgun-Variables" => "{\"notification_id\":" . $n->getNotificationId() . "}",
                    "X-Mailgun-Tag" => (isset($notificationData['notification_class'])) ? $notificationData['notification_class'] : "noclass"
                ]);

                $mailer->setFrom("\"{$mailData['from']['name']}\" <{$mailData['from']['email']}>");
                $mailer->setSubject($mailData['subject'] . "\n");
                $mailer->setBody($body);
                $implodedEmailAddresses = '';

                foreach ($mailData['to'] as $address) {
                    if ($mailer->validateEmailAddress($address))
                        $implodedEmailAddresses .= $address . ',';
                }

                $implodedEmailAddresses = rtrim($implodedEmailAddresses, ',');

                if ($implodedEmailAddresses == '') {
                    throw new Exception('Delivery addresses are empty.', self::ERR_ADDRESSEMPTY);
                } else {
                    $mailer->setTo($implodedEmailAddresses);

                    try {
                        $mailer->send();
                    } catch (Exception $e) {
                        $n->delete();
                        throw $e;
                    }
                }
            }
        }

        return true;
    }

    /**
     * By mbrancalion
     * This method is a wrapper for sending loan renews by email.
     * Moved and centralized here from ClavisAlienLoanList, ClavisLoanList, ClavisItemList, ClavisItemActions
     * (all widgets that call this).
     *
     * @param string $templateName
     * @param Loan   $loan
     * @param string $oldDueDate
     * @param string $newRenewDate
     * @param string $description
     * @return boolean|string
     */
    public function sendEmailRenew($templateName = '',
                                   $loan = null,
                                   $oldDueDate = null,
                                   $newRenewDate = null,
                                   $description = null)
    {
        /* @var $patron Patron */
        /* @var $externalLibrary Library */

        /* @var $myLibrary Library */
        /* @var $loan Loan */

        $templateName = trim($templateName);
        if ($templateName == '')
            return false;

        $success = false;
        $patronData = '---';

        $patron = $loan->getPatron();
        if ($patron instanceof Patron)
            $patronData = $patron->getCompleteName();

        $item = $loan->getItem();

        if (!($item instanceof Item))
            return '';

        $library = $item->getOwnerLibrary();

        if ($library instanceof Library) {
            $libraryEmailString = trim($library->getEmail());
            if ($libraryEmailString == '')
                return self::INVALIDEMAIL;

            $libraryEmail = array($libraryEmailString);
        } else {
            return self::INVALIDEMAIL;
        }

        $libraryString = $item->getOwnerLibraryLabel(false, true, false, false);   // strip tags, no addendum

        if (is_null($oldDueDate))
            $oldDueDate = Clavis::dateFormat($loan->getDueDate('U'));

        if (is_null($newRenewDate)) {
            $loanManager = $this->getApplication()->getModule('loan');
            $newRenewDate = Clavis::dateFormat($loanManager->CalculateRenewDate($item, $patron));
        }

        $title = $item->getTrimmedTitle(60);
        $inventory = $item->getCompleteInventoryNumber();
        $collocation = $item->getCollocationCombo();

        $myLibrary = $this->getUser()->getActualLibrary();
        $myLibraryId = $this->getUser()->getActualLibraryId();
        $myConsortiumString = $myLibrary->getConsortiaString();

        if ($description != '')
            $description = Prado::localize("con la seguente motivazione") . ":\n" . $description . "\n";

        $class = get_class($library);
        $receiverId = $library->getLibraryId();

        $template = DocumentTemplatePeer::getTemplate($templateName,
            $this->getApplication()->getGlobalization()->getCulture(),
            $myLibraryId);

        if (!$template instanceof DocumentTemplate)
            return false;

        $arr_alias = array('EXTERNALLIBRARY' => $libraryString,
            'TITLE' => $title,
            'INVENTORY' => $inventory,
            'COLLOCATION' => $collocation,
            'PATRON' => $patronData,

            'OLDRENEW' => $oldDueDate,
            'NEWRENEW' => $newRenewDate,
            'MOTIVATION' => $description,
            'LIBRARY' => $myLibrary->getLabel(),
            'LIBRARY_CODE' => $myLibrary->getLibraryCode(),

            'LIBRARY_DESCRIPTION' => $myLibrary->getDescription(),
            'LIBRARY_CITY' => $myLibrary->getCity(),
            'LIBRARY_ADDRESS' => $myLibrary->getAddress(),
            'LIBRARY_PHONE' => $myLibrary->getPhone(),
            'LIBRARY_FAX' => $myLibrary->getFax(),

            'LIBRARY_EMAIL' => $myLibrary->getEmail());

        $mailData = array();
        $mailData['to'] = $libraryEmail;
        $mailData['bcc'] = array();
        $mailData['cc'] = array();
        $mailData['body'] = '';
        $mailData['subject'] = "[$myConsortiumString]: " . $template->getTemplateTitle();

        $mailData['from'] = array('name' => $myLibrary->getLabel(),
            'email' => $myLibrary->getEmail());

        $notificationData = array('sender_library_id' => $myLibraryId,
            'receiver_class' => $class,
            'receiver_id' => $receiverId,
            'description' => Prado::localize("Richiesta proroga a biblioteca esterna"),
            'notes' => array());

        try {
            $ret = $this->DoEmailReport($template->getTemplateBody(),
                $arr_alias,
                $mailData,
                self::EMAIL_AUTO,
                $notificationData);

            if ($ret === true)
                $success = implode(',', $libraryEmail);
        } catch (Exception $e) {
            $e = $e;
            //throw ($e);
            $success = false;
        }

        return $success;
    }


    /**
     * Performs a report by SMS.
     *
     * @param string $template
     * @param string $sender
     * @param string $receiver
     * @param array  $arrParams
     * @param array  $notificationData
     * @throws Exception
     */
    public function DoSmsReport($template,
                                $sender,
                                $receiver,
                                Array $arrParams = array(),
                                Array $notificationData = array())
    {
        if (!$receiver)
            throw new Exception('Receiver not specified', self::ERR_MISSINGRCPT);

        if (!array_key_exists('sender_library_id', $notificationData))
            throw new Exception('Missing sender library', self::ERR_GENERIC);

        // Fix in case of SMS NUM = 0... return
        if (isset($arrParams['NUM'])
            && ($arrParams['NUM'] == 0)) {
            Prado::log("SMS con NUM == 0... SKIP Sending");

            return;
        }

        $body = DocumentTemplatePeer::templateTransform($template, $arrParams);

        /* ACCOUNTING IS ALWAYS DONE UPON A SINGLE LIBRARY
         * check if sender library has money */
        $lsender = LibraryQuery::create()->findPk($notificationData['sender_library_id']);

        if (!$lsender instanceof Library)
            throw new Exception('Missing sender library', self::ERR_GENERIC);

        /* @var $smsmod SMSTrendModule */
        $m = $this->getApplication()->getModule('sms');
        if (!isset($m))
            throw new Exception(Prado::localize('Modulo invio SMS non attivo'));

        // check auth for sms module
        if (!$m->checkAuth())
            throw new Exception(Prado::localize('Modulo invio SMS: errore di autenticazione'));

        if ($sender != null)
            $m->setSender($sender);

        $m->setReceiver($receiver);
        $m->setMessage($body);
        $msgno = $m->getMsgNo();
        $smscredit = $lsender->getActualSMS();

        if ($smscredit < $msgno)
            throw new Exception(Prado::localize('Modulo invio SMS: credito insufficiente'), self::ERR_NOCREDIT);

        if (isset($notificationData['description']))
            $notificationData['description'] .= "\n{$body}";

        if (!isset($notificationData['notification_class']))
            $notificationData['notification_class'] = 'H';

        $n = NotificationPeer::addNewNotification(NotificationPeer::CHANNEL_SMS,
            $notificationData['sender_library_id'],
            $notificationData['receiver_class'],
            $notificationData['receiver_id'],
            $notificationData['description'],

            $notificationData['notes'],
            $notificationData['notification_class']);

        $msgid = $this->getApplication()->getID() . "|" . $notificationData['sender_library_id'] . "|" . $n->getId();
        $result = $m->sendMessage($msgid);
        if (is_array($result)) //some old backend return true/false
        {
            if ($result["status"] == "OK") {
                // se l'invio ha avuto successo scalo gli sms inviati dal credito totale.
                $lsender->setActualSMS($smscredit - $msgno);
                $lsender->save();
            }

            if ($result["status"] == "KO") {
                try {
                    $n->setNotificationState(NotificationPeer::STATUS_ERROR);
                    $n->save();
                } catch (Exception $ex) {
                    Prado::log(__METHOD__ . " Error saving notification id {$n->getNotificationId()}");
                }

                $exmsg = " sms backend fail";

                if (count($result["errors"]) > 0)
                    $exmsg .= " (" . implode(" - ", $result["errors"]) . ")";

                throw new Exception($exmsg, self::ERR_GENERIC);
            }
        }
    }


    /**
     * Perform a notification through a user subscribed comperio-bot
     * that's linked to the current clavis instance.
     *
     * @param       $template
     * @param array $notificationData
     * @param array $msgData
     * @param array $arrParams
     * @return array
     * @throws Exception
     */
    public function DoChatBotReport($template, Array $notificationData, array $msgData, array $arrParams = array())
    {
        if (!$notificationData['receiver_id'])
            throw new RuntimeException('Receiver not specified', self::ERR_MISSINGRCPT);

        if (!array_key_exists('sender_library_id', $notificationData))
            throw new RuntimeException('Missing sender library', self::ERR_GENERIC);

        $lsender = LibraryPeer::retrieveByPK($notificationData['sender_library_id']);
        if (!$lsender instanceof Library)
            throw new RuntimeException('Missing sender library', self::ERR_GENERIC);


        $body = DocumentTemplatePeer::templateTransform($template, $arrParams);
        $msgData['text'] = $body;

        $n = NotificationPeer::addNewNotification(NotificationPeer::CHANNEL_CHATBOT,
            $notificationData['sender_library_id'],
            $notificationData['receiver_class'],
            $notificationData['receiver_id'],
            $notificationData['description']
        );

        // se occorre la conferma di lettura, passo l'id della  notifica al metodo
        // ChatBotModule->send(), altrimenti -1 se non voglio ricevute.
        $nid = $msgData['receipt'] ? $n->getId() : -1;
        $result = null;

        $chatbotmodule = $this->getApplication()->getModule('chatbot');

        if (!isset($chatbotmodule)) {
            throw new Exception(Prado::localize('Modulo ChatBOT non attivo'));
        }
        $result = $chatbotmodule->send($msgData, $nid);

        if (!isset($result)) {
            throw new Exception(Prado::localize('Invio notifica tramite BOT fallito'), self::ERR_GENERIC);
        }

        if ($result->status === 'KO') {
            try {
                $n->setNotificationState(NotificationPeer::STATUS_ERROR);
                $n->save();
                return $result;
            } catch (Exception $ex) {
                Prado::log(__METHOD__ . " Error saving notification id {$n->getNotificationId()}");
            }
        }
        return $result;
    }

    public function DoPushReport($template, Array $notificationData, array $arrParams = array())
    {
        if (!$notificationData['receiver_id'])
            throw new RuntimeException('Receiver not specified', self::ERR_MISSINGRCPT);

        if (!array_key_exists('sender_library_id', $notificationData))
            throw new RuntimeException('Missing sender library', self::ERR_GENERIC);

        $lsender = LibraryPeer::retrieveByPK($notificationData['sender_library_id']);
        if (!$lsender instanceof Library)
            throw new RuntimeException('Missing sender library', self::ERR_GENERIC);


        $body = DocumentTemplatePeer::templateTransform($template, $arrParams);
        $notificationData['description'] = $body;

        $n = NotificationPeer::addNewNotification(NotificationPeer::CHANNEL_APP,
            $notificationData['sender_library_id'],
            $notificationData['receiver_class'],
            $notificationData['receiver_id'],
            $notificationData['description']
        );

        $result = null;
        $pushbotmodule = $this->getApplication()->getModule('pushbot');

        if (!isset($pushbotmodule)) {
            throw new Exception(Prado::localize('Modulo notifiche push non attivo'));
        }

        $result = $pushbotmodule->send($notificationData['opac_username'], $notificationData['description']);
        if (isset($result)) {
            throw new Exception(Prado::localize('Invio notifica push fallita'), self::ERR_GENERIC);
            try {
                $n->setNotificationState(NotificationPeer::STATUS_ERROR);
                $n->save();
                return $result;
            } catch (Exception $ex) {
                Prado::log(__METHOD__ . " Error saving notification id {$n->getNotificationId()}");
            }
        }
        return $result;
    }

    public function DoPhoneReport()
    {
        throw new Exception('Phone report not implemented, yet.', self::ERR_NOTIMPLEMENTED);
    }

    public function DoMobileReport()
    {
        throw new Exception('Phone report not implemented, yet.', self::ERR_NOTIMPLEMENTED);
    }

    /**
     * Checks pending notifications for deliver acknowledgements.
     */
    public function autoCheckDelivery()
    {
        /*$c = new Criteria();
        // expire all PENDING older than 30 days setting them to UNKNOWN
        $c->add(NotificationPeer::DATE_CREATED,time()-2592000,Criteria::LESS_THAN);
        $c->add(NotificationPeer::NOTIFICATION_STATE,NotificationPeer::STATUS_PENDING);
        foreach (NotificationPeer::doSelect($c) as $n) {
            $n->setNotificationState(NotificationPeer::STATUS_UNKNOWN);
            $n->setDateUpdated(time());
            $n->save();
            $n->clearAllReferences(true);
        }
        $c->clear();*/

        $conn = Propel::getConnection();

        $autoexpire = NotificationQuery::create()
            ->filterByDateCreated(array('max' => time() - 2592000))
            ->filterByNotificationState(NotificationPeer::STATUS_PENDING)
            ->update(array('NotificationState' => NotificationPeer::STATUS_UNKNOWN), $conn, true);

        $non_auto_acking = array(
            NotificationPeer::CHANNEL_SNAILMAIL,
            NotificationPeer::CHANNEL_PHONE,
            NotificationPeer::CHANNEL_FAX,
            NotificationPeer::CHANNEL_MOBILE,
            NotificationPeer::CHANNEL_PORTAL,
            NotificationPeer::CHANNEL_IM
        );
        $auto_acking = array(
            NotificationPeer::CHANNEL_SMS,
            NotificationPeer::CHANNEL_EMAIL,
        );

        // firstly, check delivery for non auto ack-ing channels
        $acked_manual = NotificationQuery::create()
            ->filterByNotificationState(NotificationPeer::STATUS_PENDING)
            ->filterByNotificationChannel($non_auto_acking)
            ->update(array('NotificationState' => NotificationPeer::STATUS_SENT), $conn, true);

        /*$c->add(NotificationPeer::NOTIFICATION_STATE,NotificationPeer::STATUS_PENDING);
        $c->add(NotificationPeer::NOTIFICATION_CHANNEL,
            array(
                NotificationPeer::CHANNEL_SNAILMAIL,
                NotificationPeer::CHANNEL_PHONE,
                NotificationPeer::CHANNEL_EMAIL,
                NotificationPeer::CHANNEL_FAX,
                NotificationPeer::CHANNEL_MOBILE,
                NotificationPeer::CHANNEL_PORTAL,
                NotificationPeer::CHANNEL_IM),
            Criteria::IN);
        $notifications = NotificationPeer::doSelect($c);
        foreach ($notifications as $n) {
            switch ($n->getNotificationChannel()) {
                case NotificationPeer::CHANNEL_SNAILMAIL:
                case NotificationPeer::CHANNEL_PHONE:
                case NotificationPeer::CHANNEL_EMAIL:
                case NotificationPeer::CHANNEL_FAX:
                case NotificationPeer::CHANNEL_MOBILE:
                case NotificationPeer::CHANNEL_PORTAL:
                case NotificationPeer::CHANNEL_IM:
                    $n->setNotificationState(NotificationPeer::STATUS_SENT);
                    $n->save();
                    break;
            }
        }
        $c->clear();

        // secondly, check for auto ack-ing channels
        $c->add(NotificationPeer::NOTIFICATION_STATE,
            array(NotificationPeer::STATUS_PENDING,NotificationPeer::STATUS_SENT),
            Criteria::IN);
        $c->add(NotificationPeer::NOTIFICATION_CHANNEL,
            array(NotificationPeer::CHANNEL_SMS),Criteria::IN);
        $notifications = NotificationPeer::doSelect($c);*/


        $smsmodule = Prado::getApplication()->getModule('sms');
        $smsmodule->checkStatus();
        /*
        // secondly, check for auto ack-ing channels
        $notifications = NotificationQuery::create()
            ->filterByNotificationState(NotificationPeer::STATUS_PENDING)
            ->filterByNotificationChannel($auto_acking)
            ->find($conn);

        foreach ($notifications as $n) {
            switch ($n->getNotificationChannel()) {
                case NotificationPeer::CHANNEL_SMS:
                    $notes = unserialize($n->getNotes());
                    if ($notes && array_key_exists('smsid', $notes)) {
                        $response = $smsmodule->checkStatus($notes['smsid']);
                        // check only first one
                        if (count($response) < 1) {
                            // no response, so SMS isn't in order.
                            $response = array(
                                'notif_status' => NotificationPeer::STATUS_UNKNOWN,
                                'status' => ''
                            );
                        } else {
                            $response = $response[0];
                        }
                        $prevstatus = $n->getNotificationState();
                        $n->setNotificationState($response['notif_status']);
                        $n->setInternalStatus($response['status']);
                        $ack_date = ($response['notif_status'] == NotificationPeer::STATUS_DELIVERED) ?
                            strtotime($response['ack_date']) : null;
                        if ($prevstatus == NotificationPeer::STATUS_PENDING &&
                            in_array($response['notif_status'],
                                array(NotificationPeer::STATUS_SENT, NotificationPeer::STATUS_DELIVERED))
                        )
                            $n->setDeliveryDate(($ack_date) ? $ack_date : time());
                        $n->setAcknowledgeDate($ack_date);
                        $n->save();
                    }
                    break;
                default:
                    break;
            }
        }
        */


    }

    /**
     * Returns all notifications belonging to a specific patron.
     *
     * @param int    $patron_id
     * @param string $channel
     * @param bool   $toconfirm
     * @return Array
     */
    public function getPatronNotifications($patron_id,
                                           $channel = null,
                                           $toconfirm = false)
    {
        $nots = NotificationQuery::create()
            ->filterByObjectClass('patron')
            ->filterByObjectId($patron_id);

        if ($channel)
            $nots->filterByNotificationChannel($channel);

        if ($toconfirm)
            $nots->filterByNotificationState(array(NotificationPeer::STATUS_PENDING, NotificationPeer::STATUS_SENT));

        return $nots->find();
    }

    /**
     * Returns all notifications made to an external library.
     *
     * @param int    $library_id
     * @param string $channel
     * @param bool   $toconfirm
     * @return Array
     */
    public function getExternalLibraryNotifications($library_id,
                                                    $channel = null,
                                                    $toconfirm = false)
    {
        $nots = NotificationQuery::create()
            ->filterByObjectClass('library')
            ->filterByObjectId($library_id);

        if ($channel)
            $nots->filterByNotificationChannel($channel);

        if ($toconfirm)
            $nots->filterByNotificationState(array(NotificationPeer::STATUS_PENDING, NotificationPeer::STATUS_SENT));

        return $nots->find();
    }
}

/**
 * NotificationEmail Class
 *
 * @author    Ciro Mattia Gonano <ciro@comperio.it>
 * @link      http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2008 ePortal Technologies
 * @copyright Copyright &copy; 2009 Comperio srl
 * @version   2.7
 * @package   Core
 * @since     2.6
 */
class NotificationEmail
{

    /**
     * @param string         $sender Either 'librarian', 'preferredLibrary', 'library' or 'system'
     * @param Librarian      $librarian
     * @param Library        $library
     * @param Patron|Library $destination
     * @return array
     */
    public static function getEmailSender($sender = 'librarian', Librarian $librarian = null, Library $library = null, $destination = null)
    {
        $mailSender = array(
            'name' => '',
            'email' => ''
        );
        $fallback = ClavisParamQuery::getParam('CLAVISPARAM', 'AdminEmail');
        /* select sender */
        switch ($sender) {

            case 'librarian':
                if (!$librarian instanceof Librarian) {
                    $sender = 'preferredLibrary';
                    continue;
                }
                $address = trim($librarian->getEmail());
                if (!$address && $library instanceof Library)
                    $address = $library->getEmail();
                if (!$address)
                    $address = $fallback;
                $mailSender = array(
                    'name' => $librarian->getCompleteName(),
                    'email' => $address);
                break;

            case 'preferredlibrary':
                $prefLibrary = ($destination instanceof Patron)
                    ? $destination->getPreferredLibrary()
                    : $library;
                if ($prefLibrary instanceof Library) {
                    $address = trim($prefLibrary->getEmail());
                    if (!$address)
                        $address = $library->getEmail();
                    if (!$address)
                        $address = $fallback;
                    $mailSender = array(
                        'name' => $prefLibrary->getLabel(),
                        'email' => $address);
                } else if ($library instanceof Library) {
                    $address = $library->getEmail();
                    if (!$address)
                        $address = $fallback;
                    $mailSender = array(
                        'name' => $library->getLabel(),
                        'email' => $address);
                }
                break;

            case 'library':
                if (!$library instanceof Library) {
                    $sender = 'system';
                    continue;
                }
                $address = $library->getEmail();
                if (!$address)
                    $address = $fallback;
                $mailSender = array(
                    'name' => $library->getLabel(),
                    'email' => $address);
                break;

            case 'system':
            default:
                $mailSender = array(
                    'name' => $library instanceof Library
                        ? $library->getConsortiaString()
                        : ClavisParamQuery::getParam('CLAVISPARAM', 'SiteOwner'),
                    'email' => ClavisParamQuery::getParam('CLAVISPARAM', 'AdminEmail'));
                break;
        }
        return $mailSender;
    }

    /**
     * @param Librarian      $librarian
     * @param Library        $library
     * @param string         $solicit_mode
     * @param bool           $notify_all_loans
     * @param Patron|Library $destination
     * @param array          $loan_ids
     * @return array
     * @throws Exception
     */
    public static function getAliasArray(Librarian $librarian,
                                         Library $library,
                                         $solicit_mode = 'solicit',
                                         $notify_all_loans = false,
                                         $destination = null,

                                         Array $loan_ids = array())
    {
        if (!($destination instanceof Patron)
            && !($destination instanceof Library))
            throw new Exception('Wrong destination: neither Patron nor Library');

        $address = array('street' => '',
            'zip' => '',
            'city' => '',
            'province' => '',
            'town' => '');

        if ($destination instanceof Patron) {
            $arrayName = $destination->getName();
            $arrayLastname = $destination->getLastname();
            $arrayCardcode = $destination->getCardCode();
            $arrayBarcode = $destination->getBarcode();
            $arrayNickname = $destination->getOpacUsername();
            $arrayPassword = $destination->getBirthDate('Y-m-d');

            $address_db = AddressQuery::create()
                ->filterByPatron($destination)
                ->orderByAddressPref('DESC')
                ->orderByAddressType('DESC')
                ->limit(1)
                ->findOne();

            if ($address_db instanceof Address) {
                $street_type = LookupValuePeer::getLookupValue('STREET', $address_db->getStreetType());
                $village = trim($address_db->getVillage());
                $address['street'] = $street_type . ' ' . $address_db->getStreet() . ', ' . $address_db->getStreetNum();
                $address['zip'] = $address_db->getZip();

                if ($address['zip'] != '')
                    $address['zip'] .= ' ';

                $address['city'] = $address_db->getCity();
                $address['province'] = $address_db->getProvince();
                $address['town'] = $address['zip'] . $village . ($village != '' ? ' - ' : '')
                    . "{$address['city']} ({$address['province']})";
            }
        } elseif ($destination instanceof Library) {
            $arrayName = $destination->getLabel(true, true, true);
            $arrayLastname = '';
            $arrayCardcode = '';
            $arrayBarcode = '';
            $arrayNickname = '';
            $arrayPassword = '';

            $address['street'] = $destination->getAddress();
            $address['zip'] = '';
            $address['city'] = $destination->getCity();
            $address['province'] = $destination->getProvince();
            $address['town'] = $address['city'] . ' (' . $address['province'] . ')';
        }

        $consortia = $library->getConsortia();

        /* Patron variables */
        $arr_alias = array('NAME' => $arrayName,
            'LASTNAME' => $arrayLastname,
            'CARDCODE' => $arrayCardcode,
            'BARCODE' => $arrayBarcode,
            'NICKNAME' => $arrayNickname,
            'PASSWORD' => $arrayPassword,
            'ADDR_R1' => $address['street'],
            'ADDR_R2' => $address['town'],
            'ADDR_ZIP' => $address['zip'],
            'ADDR_CITY' => $address['city'],
            'ADDR_PROVINCE' => $address['province'],
            'LIBRARY' => $library->getLabel(),
            'LIBRARY_DESCRIPTION' => $library->getDescription(),
            'LIBRARY_CITY' => $library->getCity(),
            'ADDR_LIBRARY' => $library->getAddress(),
            'PHONE_LIBRARY' => $library->getPhone(),
            'FAX_LIBRARY' => $library->getFax(),
            'EMAIL_LIBRARY' => $library->getEmail(),
            'OP_NAME' => $librarian->getName(),
            'OP_LASTNAME' => $librarian->getLastname(),
            'CONSORTIA' => $consortia instanceof Consortia ? $consortia->getLabel() : '',
            'NOWDATE' => Clavis::dateFormat(time(), 'shortdate'),
            'OPAC_URL' => ClavisParamQuery::getParam('CLAVISPARAM', 'OPACUrl'));

        $loanQuery = LoanQuery::create();

        if ($destination instanceof Patron) {
            $loanQuery->filterByPatron($destination);
        } elseif ($destination instanceof Library) {
            $loanQuery->filterByLibraryRelatedByExternalLibraryId($destination);
        }

        switch ($solicit_mode) {
            case 'revoke':
            case 'solicit':
                $loanQuery->filterByLoanStatus(ItemPeer::getLoanStatusCurrent());

                if ($notify_all_loans) {
                    $loanQuery->filterByDueDate(time(), Criteria::LESS_THAN);
                } else {
                    $loanQuery->filterByLoanId($loan_ids);
                }

                break;

            case 'readyforloan':
            case 'readyforloanextra':
                $loanQuery->filterByLoanStatus(ItemPeer::LOANSTATUS_READYFORLOAN)
                    ->filterByLibraryRelatedByToLibrary($library);

                if (!$notify_all_loans)
                    $loanQuery->filterByLoanId($loan_ids);

                break;

            case 'expiring':
                $loanQuery->filterByLoanStatus(ItemPeer::getLoanStatusCurrent());

                if ($notify_all_loans) {
                    $loanQuery->filterByDueDate(time(), Criteria::GREATER_EQUAL);
                } else {
                    $loanQuery->filterByLoanId($loan_ids);
                }

                break;
        }

        $loans = $loanQuery->find();

        $loan_array = $newLoanIds = array();

        foreach ($loans as $l) {
            /* @var $l Loan */
            $item = $l->getItem();

            if (!$item instanceof Item) {
                Prado::log(__CLASS__ . ':' . __LINE__ . " - null item in loan {$l->getLoanId()}");
                continue;
            }

            $title = $item->getTitle();

            $loan_array[] = array('TITLE' => mb_convert_encoding($title, 'UTF-8', mb_detect_encoding($title)),
                'TITLETRIMMED' => mb_substr(mb_convert_encoding($title, 'UTF-8', mb_detect_encoding($title)), 0, 80, 'utf8'),
                'INVENTORY' => $item->getInventoryCollocationCombo(),
                'INVSERIE' => $item->getInventorySerieId(),
                'BARCODE' => $item->getBarcode(),
                'HOME_LIBRARY' => $item->getHomeLibraryLabel(),
                'ACTUAL_LIBRARY' => $item->getActualLibraryLabel(),
                'LOANDATE' => Clavis::dateFormat($l->getLoanDateBegin('U'), 'shortdate'),
                'EXPIRED' => Clavis::dateFormat($l->getDueDate('U'), 'shortdate'),
                'COLLOCATION' => $item->getCollocationCombo());

            $newLoanIds[] = $l->getLoanId();
        }

        $arr_alias['LOAN_IDS'] = $newLoanIds;
        $arr_alias['LOOP_ITEMS'] = $loan_array;

        return $arr_alias;
    }
}


/**
 * NotificationSMS Class
 *
 * @author    Ciro Mattia Gonano <ciro@comperio.it>
 * @link      http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2008 ePortal Technologies
 * @copyright Copyright &copy; 2009 Comperio srl
 * @version   2.7
 * @package   Core
 * @since     2.6
 */
class NotificationSMS
{
    /**
     * @param string  $sender
     * @param Library $library
     * @return mixed|string
     */
    public static function getSMSSender($sender = 'libraryphone', Library $library = null)
    {
        if (!$library instanceof Library)
            return substr(ClavisParamQuery::getParam('CLAVISPARAM', 'SiteOwner'), 0, 11);

        switch ($sender) {
            case 'libraryphone':
                $sender = preg_replace('/[^+\d,]/', '', $library->getPhone());
                if ($sender)
                    break;    // if sender is '', don't break for fallbacking on label
            case 'librarylabel':
                $sender = trim($library->getShortlabel());
                if (!$sender)
                    $sender = $library->getLabel();    // remind that this WILL be trimmed to 11 chars.
                break;
            case 'system':
            default:
                //$sender = $library->getConsortiaString(11); // remind that this WILL be trimmed to 11 chars.
                $sender = Prado::getApplication()->getModule('sms')->getSender();
                $sender = substr($sender, 0, 11);
                break;
        }
        return $sender;
    }

    /**
     * @param Librarian $librarian
     * @param Library   $library
     * @param string    $solicit_mode
     * @param null      $destination
     * @param array     $loan_ids
     * @return array
     * @throws Exception
     */
    public static function getAliasArray(Librarian $librarian,
                                         Library $library,
                                         $solicit_mode = 'solicit',
                                         $destination = null,
                                         Array $loan_ids = array())
    {
        if (!($destination instanceof Patron)
            && !($destination instanceof Library))
            throw new Exception('Wrong destination: neither Patron nor Library');

        $numQuery = LoanQuery::create()
            ->filterByLoanId($loan_ids);

        if ($destination instanceof Patron) {
            $numQuery->filterByPatron($destination);
        } elseif ($destination instanceof Library) {
            $numQuery->filterByLibraryRelatedByExternalLibraryId($destination);
        }

        switch ($solicit_mode) {
            case 'solicit':
                $numQuery->filterByLoanStatus(ItemPeer::getLoanStatusCurrent())
                    ->filterByDueDate(time(), Criteria::LESS_THAN);

                $mynumQuery = clone $numQuery;
                $mynumQuery->filterByItemHomeLibraryId($library->getLibraryId());
                break;

            case 'readyforloan':
            case 'readyforloanextra':
                $numQuery->filterByLoanStatus(ItemPeer::LOANSTATUS_READYFORLOAN)
                    ->filterByLibraryRelatedByToLibrary($library);
                break;

            case 'expiring':
                $numQuery->filterByLoanStatus(ItemPeer::getLoanStatusCurrent())
                    ->filterByDueDate(time(), Criteria::GREATER_EQUAL);

                $mynumQuery = clone $numQuery;
                $mynumQuery->filterByItemHomeLibraryId($library->getLibraryId());
                break;
        }

        $itemcount = $numQuery->count();
        $myitemcount = (isset($mynumQuery)) ? $mynumQuery->count() : $itemcount;
        $loan_ids = $numQuery->select('Loan.LoanId')->find()->toArray();

        $shortLabel = $library->getShortlabel();

        return array('NUM' => $itemcount,
            'MYNUM' => $myitemcount,
            'LOAN_IDS' => $loan_ids,
            'SHORT_LABEL' => $shortLabel);
    }
}

/**
 * NotificationHelper Class
 *
 * @author    Ciro Mattia Gonano <ciro@comperio.it>
 * @link      http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2008 ePortal Technologies
 * @copyright Copyright &copy; 2009 Comperio srl
 * @version   2.7
 * @package   Core
 * @since     2.6
 */
class NotificationHelper
{
    /**
     * @param string         $mode     Either 'solicit', 'readyforloan' or 'expiring'
     * @param Patron|Library $destination
     * @param Librarian      $sender_librarian
     * @param Library        $sender_library
     * @param mixed          $loan_ids Can be an array of loan ids or 'all' to notify all loans.
     * @return bool
     */
    public static function sendNotificationEmail($mode,
                                                 $destination,
                                                 Librarian $sender_librarian,
                                                 Library $sender_library,
                                                 $loan_ids)
    {
        switch ($mode) {
            case 'revoke':
                $tpl_class = "AUTOREVOKE_MAIL";
                $notifDescr = Prado::localize('Notifica revoca automatica');
                $notifClass = 'G';
                break;

            case 'solicit':
                $tpl_class = 'SOLICIT_MAIL';
                $notifDescr = Prado::localize('Notifica sollecito ritardo');
                $notifClass = 'A';
                break;

            case 'readyforloan':
                $tpl_class = 'NOTIFYREADY_MAIL';
                $notifDescr = Prado::localize('Notifica pronto al prestito');
                $notifClass = 'F';
                break;

            case 'readyforloanextra':
                $tpl_class = 'NOTIFYREADYEXTRA_MAIL';
                $notifDescr = Prado::localize('Notifica pronto al prestito extra');
                $notifClass = 'Z';
                break;

            case 'expiring':
                $tpl_class = 'EXPIRINGLOAN_MAIL';
                $notifDescr = Prado::localize('Notifica di scadenza imminente');
                $notifClass = 'E';
                break;
            default:
                $notifClass = 'H';
                break;
        }

        // ready-to-loan automatic notification
        $recipient = $destination->getEmail();

        if (!$recipient)
            return false;

        $tpl = DocumentTemplatePeer::getTemplate($tpl_class,
            Prado::getApplication()->getGlobalization()->getCulture(),
            $sender_library->getLibraryId(),
            true);

        if (!$tpl instanceof DocumentTemplate)
            return false;

        try {
            $sent_from = ClavisParamQuery::getParam('CLAVISPARAM', 'MailSentFrom');

            if (!is_array($recipient))
                $recipient = array($recipient);

            $notificationData = array('sender_library_id' => $sender_library->getLibraryId(),
                'description' => $notifDescr,
                'notes' => array(),
                'receiver_class' => get_class($destination),
                'receiver_id' => $destination->getId(),
                'notification_class' => $notifClass);

            if ('all' == $loan_ids) {
                $arr_alias = NotificationEmail::getAliasArray($sender_librarian,
                    $sender_library,
                    $mode,
                    true,
                    $destination);
            } else {
                $arr_alias = NotificationEmail::getAliasArray($sender_librarian,
                    $sender_library,
                    $mode,
                    false,
                    $destination,

                    $loan_ids);
            }

            $sender = NotificationEmail::getEmailSender($sent_from,
                $sender_librarian,
                $sender_library,
                $destination);

            $mailData = array('to' => $recipient,
                'from' => $sender,
                'cc' => '',
                'bcc' => '',
                'body' => '',

                'subject' => $tpl->getTemplateSubject());

            return Prado::getApplication()->getModule('notification')->DoEmailReport($tpl->getTemplateBody(),
                $arr_alias,
                $mailData,
                NotificationManager::EMAIL_AUTO,
                $notificationData);
        } catch (Exception $e) {
            return false;
        }
    }

}