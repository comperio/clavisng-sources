<?php
/**
 * JRPHPModule class file
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 */

/**
 * JRPHPModule Class
 *
 * Handle all JasperReport integration actions.
 * 
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Core
 * @since 2.4
 */
class JRPHPModule extends TModule
{
	private $_javaBridgeURL;
	private $_active = false;

	private $_reportPath;
	private $_spoolPath;

	private $_reportParams;
	private $_javaParam;

	private $_jrxmlFile;
	private $_jasperFile;
	private $_report;


	public function init($config)
	{
		parent::init($config);
		define('JAVA_HOSTS', $this->_javaBridgeURL);
		// check if JavaBridge is available, is not, gracefully fail
		$url = explode(':',JAVA_HOSTS);
		$fp = @fsockopen($url[0],$url[1]);
		if ($fp === false) {
			$this->setActive(false);
			return;
		} else {
			fclose($fp);
			$this->setActive(true);
			require_once('Java.inc');
		}
	}

	public function setActive($value)
	{
		$this->_active = TPropertyValue::ensureBoolean($value);
	}

	public function getActive()
	{
		return $this->_active;
	}

	private function getConnection()
	{
		try
		{
			$classLoader = Java('java.lang.Class');
			$classLoader->forName('com.mysql.jdbc.Driver');
			$driverManager = new JavaClass('java.sql.DriverManager');
			// retrieve DB conf from Propel
			$dbconf = Propel::getConfiguration();
			preg_match('/(\w+):host=([\w\d\.]+);port=(\d+);dbname=(.+)/',
						$dbconf['datasources']['clavis']['connection']['dsn'],
						$connection_data);
			$connString = "jdbc:{$connection_data[1]}://{$connection_data[2]}:{$connection_data[3]}/{$connection_data[4]}";
			$connUser = $dbconf['datasources']['clavis']['connection']['user'];
			$connPassword = $dbconf['datasources']['clavis']['connection']['password'];
			return $driverManager->getConnection("{$connString}?user={$connUser}&password={$connPassword}");
		} catch (Exception $e) {
			Prado::log($e);
			return false;
		}
	}

	public function setJavaBridgeURL($value)
	{
		$this->_javaBridgeURL = $value;
	}

	public function getJaveBridgeURL()
	{
		return $this->_javaBridgeURL;
	}

	public function setSpoolerPath($value)
	{
		$this->_spoolPath = $value;
	}

	public function getSpoolerPath()
	{
		return $this->_spoolPath;
	}

	public function setReportPath($value)
	{
		$this->_reportPath = $value;
	}

	public function getReportPath()
	{
		return $this->_reportPath;
	}

	public static function convertValue($value, $className)
	{
		// if we are a string, just use the normal conversion
		// methods from the java extension...
		try
		{
			if ($className == 'java.lang.String')
			{
				$temp = new Java('java.lang.String', $value);
				return $temp;
			}
			else if ($className == 'java.lang.Boolean' ||
					$className == 'java.lang.Integer' ||
					$className == 'java.lang.Long' ||
					$className == 'java.lang.Short' ||
					$className == 'java.lang.Double' ||
					$className == 'java.math.BigDecimal')
			{
				$temp = new Java($className, $value);
				return $temp;
			}
			else if ($className == 'java.sql.Timestamp' ||
					$className == 'java.sql.Time')
			{
				$temp = new Java($className);
				$javaObject = $temp->valueOf($value);
				return $javaObject;
			}
		} catch (Exception $err) {
			Prado::log("Unable to convert - value {$value} could not be converted to {$className}");
			return false;
		}
		Prado::log("Unable to convert value, class name {$className} not recognised");
		return false;
	}

	/**
	 * Returns a list of all supported export formats.
	 *
	 * @return Array The list of supported export formats.
	 */
	public function getExportFormatList()
	{
		$flist = array(
			'pdf'	=> 'PDF',
			'odt'	=> 'OpenOffice ODT',
			'html'	=> 'HTML',
			'ods'	=> 'OpenOffice ODS',
			'xls'	=> 'Microsoft Excel',
			'csv'	=> 'CSV',
		);
		return $flist;
	}
	
	/**
	 * Returns a list of  supported export formats from report by P_OUT_FMT parameter.
	 *
	 * @return Array The list of supported export formats. False if P_OUT_FMT param is not set.
	 */
	public function getAvailableExportFormatList()
	{
		//If report have P_OUT_FMT param
		if(isset($this->_reportParams['P_OUT_FMT']))
		{
			$outf = array();
			$flist = $this->getExportFormatList();
			//Remove double quotes from P_OUT_FMT value
			$pval = str_replace("\"", "", $this->_reportParams['P_OUT_FMT']['DefaultValue']);
			$fmts = explode(',', $pval);
			foreach($fmts as $f)
			{
				if(isset($flist[$f]))
				{
					$outf[$f] = $flist[$f];
				}
			}
			return $outf;
		}
		
		return FALSE;
	}

	private function getExporter($format)
	{
		switch($format)
		{
			case 'pdf':
				$exporter = new Java('net.sf.jasperreports.engine.export.JRPdfExporter');
				break;
			case 'html':
				$exporter = new Java('net.sf.jasperreports.engine.export.JRHtmlExporter');
				break;
			case 'odt':
				$exporter = new Java('net.sf.jasperreports.engine.export.oasis.JROdtExporter');
				break;
			case 'ods':
				$exporter = new Java('net.sf.jasperreports.engine.export.oasis.JROdsExporter');
				break;
			case 'xls':
				$exporter = new Java('net.sf.jasperreports.engine.export.JRXlsExporter');
				break;
			case 'csv':
				$exporter = new Java('net.sf.jasperreports.engine.export.JRCsvMetadataExporter');
				break;
			default:
				$exporter = null;
		}

		return $exporter;
	}

	private function getMimeType($format)
	{
		switch($format)
		{
			case 'pdf':
				$mime = ' application/pdf';
				break;
			case 'html':
				$mime = ' text/html';
				break;
			case 'odt':
				$mime = ' application/vnd.oasis.opendocument.text';
				break;
			case 'ods':
				$mime = ' application/vnd.oasis.opendocument.spreadsheet';
				break;
			case 'xls':
				$mime = ' application/ms-excel';
				break;
			case 'csv':
				$mime = ' text/csv';
				break;
			default:
				$mime = null;
		}
		return $mime;
	}

	/**
	 *
	 * @param DocumentTemplate $doc
	 */
	public function setReportTemplate(DocumentTemplate $doc)
	{
		$reportName = $doc->getTemplateSubject();
		$jrxmlFileName = realpath(Prado::getPathOfNamespace($this->_reportPath))."/{$reportName}.jrxml";
		$this->_jrxmlFile = $jrxmlFileName;
		if (!file_exists($jrxmlFileName))
			throw new Exception("Template file '{$jrxmlFileName}' is missing");
		// source XML to get all subreports.
		// note that we have to parse XML for the param too, since at the moment
		// the report is not loaded.
		$jrxml = simplexml_load_file($jrxmlFileName,'SimpleXmlElement',LIBXML_NOCDATA);
		$jrxml->registerXPathNamespace('jr','http://jasperreports.sourceforge.net/jasperreports');
		foreach ($jrxml->parameter as $param) {
			if ($param['name'] == 'SUBREPORT_DIR')
				$subreport_dir = dirname($jrxmlFileName).'/'. str_replace('"','', $param->defaultValueExpression);
		}
		$subreports = $jrxml->xpath('//jr:subreport');
		foreach ($subreports as $srEl) {
			$this->compileReport(
				str_replace('.jasper','.jrxml',
					str_replace('$P{SUBREPORT_DIR} + ',$subreport_dir,
						str_replace('"','',$srEl->subreportExpression))));
		}
		$this->compileReport($jrxmlFileName);
		$this->compileParams($doc);
		return true;
	}

	public function getReportParameters()
	{
		if (!$this->_reportParams)
			throw new Exception('Template has not been initialized, yet');
		return $this->_reportParams;
	}

	public function getReportParam($name)
	{
		return $this->_javaParam->get($name);
	}

	public function setReportParam($name,$value)
	{
		$this->_javaParam->put($name, $value);
	}

	public function renderReport($format = 'pdf',$outputFile = null)
	{
		if (!$this->getActive())
			return false;

		$connection = $this->getConnection();
		$this->loadGlobalParameters();
		try
		{
			$tmpFileName=  uniqid("/tmp/jr_") . "." . $format;
			$JRExporterParameter = new JavaClass ('net.sf.jasperreports.engine.JRExporterParameter');
			//$outputStream = new Java('java.io.ByteArrayOutputStream');
			$outputStream = new Java('java.io.FileOutputStream',$tmpFileName);
			$fillManager = new JavaClass('net.sf.jasperreports.engine.JasperFillManager');
			$exportManager = new JavaClass('net.sf.jasperreports.engine.JasperExportManager');
			$jasperPrint = $fillManager->fillReport($this->_jasperFile, $this->_javaParam, $connection);
			if (!java_values($connection->isClosed()))
				$connection->close();

			//$swapFile = new Java('net.sf.jasperreports.engine.util.JRSwapFile',"/tmp",2048,1024);
			//$virtualizer = new Java('net.sf.jasperreports.engine.fill.JRSwapFileVirtualizer',50,$swapFile,false);

			Prado::log(__METHOD__ . " " . __LINE__);
			$exporter = $this->getExporter($format,$outputFile);
			if($exporter != null) {
                $exporter->setParameter($JRExporterParameter->JASPER_PRINT, $jasperPrint);

                $exporter->setParameter($JRExporterParameter->OUTPUT_STREAM, $outputStream);
                $exporter->exportReport();

                $outputStream->close();
                self::sendFileToBrowser($tmpFileName, $mime, "report.{$format}");

                /*
                Prado::log(__METHOD__ . " " . __LINE__);

                $byteArray = $outputStream->toByteArray();

                Prado::log(__METHOD__ . " " . __LINE__);

                $rData = java_values($byteArray);

                Prado::log(__METHOD__ . " " . __LINE__);

                self::sendDataToBrowser($rData,$this->getMimeType($format),"report.{$format}");

                Prado::log(__METHOD__ . " " . __LINE__);*/
            } else {
                Prado::log("Errore Exporter Formato[{$format}] File[{$outputFile}]",TLogger::ALERT);
                return false;
            }
		} catch (JavaException $e) {
			Prado::log("Eccezione in renderReport: \n" .$e->getCause());
			if (!java_values($connection->isClosed()))
				$connection->close();
			return false;
		}
		return true;
	}

	/**
	 *
	 * @param string $jrxmlFile
	 * @return bool
	 */
	private function compileReport($jrxmlFile)
	{
		if (!$this->getActive())
			return false;

		$compiled = dirname($jrxmlFile).'/'.basename($jrxmlFile,'.jrxml').'.jasper';
		$this->_jasperFile = $compiled;
		if (!file_exists($compiled))
		{
			$compileManager = new JavaClass('net.sf.jasperreports.engine.JasperCompileManager');
			$compileManager->compileReportToFile($jrxmlFile);
			$this->_report = $compileManager->compileReport($jrxmlFile);
		}
		return true;
	}

	private function compileParams(DocumentTemplate $doc) {
		if (!$this->getActive())
			throw new Exception('JRPHPModule is not active');

		$compiledParams = $doc->getTemplateBody();
		if (!$compiledParams) {
			if (!$this->_report) {
				if (!$this->_jasperFile)
					throw new Exception ('Jasperfile not set');
				$loader = new JavaClass('net.sf.jasperreports.engine.util.JRLoader');
				$this->_report = $loader->loadObject($this->_jasperFile);
			}
			$params  = $this->_report->getParameters();
			foreach($params as $p)
			{
				$properties = array();
				if (java_values($p->hasProperties())) {
					$map = java_values($p->getPropertiesMap());
					foreach (java_values($map->getPropertyNames()) as $property) {
						$properties[$property] = java_values($map->getProperty($property));
					}
				}
				if (substr($p->getName() ,0,2) == 'P_') {
					$this->_reportParams[java_values($p->getName())] = array(
						'Label'			=> java_values($p->getDescription()),
						'IsForPrompt'	=> java_values($p->isForPrompting()),
						'Class'			=> java_values($p->getValueClassName()),
						'DefaultValue'	=> java_values($p->getDefaultValueExpression()->getText()),
						'Properties'	=> $properties,
					);
				}
			}
			if (count($this->_reportParams) == 0)
				$this->_reportParams['FAKEPARAM'] = array(
						'Label' => 'Fake parameter',
						'IsForPrompt' => false,
						'Class' => null,
						'DefaultValue' => false,
						'Properties' => array(),
					);
			$doc->setTemplateBody(serialize($this->_reportParams));
			$doc->save();
		} else {
			$this->_reportParams = unserialize($doc->getTemplateBody());
		}
		$this->_javaParam =  new Java('java.util.HashMap');
	}

	private function loadGlobalParameters() {
		$user = $this->getApplication()->getUser();
		$this->setReportParam('P_USER_ID', $user->getId());

        $culture = $this->getApplication()->getGlobalization()->getCulture();
        $reportLocale = new Java('java.util.Locale',substr($culture,0,2),substr($culture,3,2));
        $this->setReportParam('REPORT_LOCALE', $reportLocale);
		$this->setReportParam('P_BASE_URL', ClavisParamQuery::getParam('CLAVISPARAM','BaseUrl'));

		if ($user instanceof ClavisLibrarian) {
			$this->setReportParam('P_LIBRARY_LIBRARIAN_ID', $user->getId());
			$this->setReportParam('P_LIBRARY_LIBRARIAN', $user->getCompleteName());
			$library = $user->getActualLibrary();
			$this->setReportParam('P_LIBRARY_ID', $library->getLibraryId());
			$this->setReportParam('P_LIBRARY_LABEL', $library->getLabel());
			$this->setReportParam('P_LIBRARY_DESCRIPTION', $library->getDescription());
			$this->setReportParam('P_LIBRARY_PHONE', $library->getPhone());
			$this->setReportParam('P_LIBRARY_EMAIL', $library->getEmail());
			$this->setReportParam('P_LIBRARY_CITY', $library->getCity());
			$this->setReportParam('P_LIBRARY_ADDRESS', $library->getAddress());
			$c = $library->getConsortia();
			$this->setReportParam('P_LIBRARY_CONSORTIA',
				($c instanceof Consortia) ? $c->getLabel() : '---');
		}
	}

	public static function sendDataToBrowser($data,$mime,$filename = "report")
	{
		$resp = Prado::getApplication()->getResponse();
		$resp->clear();
		$resp->setCacheControl('nocache');
		$resp->writeFile($filename, $data, $mime);
		die();
		//Prado::getApplication()->completeRequest();
	}
	
	public static function sendFileToBrowser($fileNameSrv,$mime,$fileNameCli = "report")
	{
		$resp = Prado::getApplication()->getResponse();
		$resp->clear();
		$resp->setCacheControl('nocache');
		$resp->writeFile($fileNameSrv, NULL, $mime, NULL, TRUE, $fileNameCli);
		$jFile = new Java('java.io.File',$fileNameSrv);
		if( $jFile->exists() )
		{
			$jFile->delete();
		}
		die();
		//Prado::getApplication()->completeRequest();
	}
}
