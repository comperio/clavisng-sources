<?php
/**
 * SMSDummyModule - SMSTrend Prado Module
 *
 * A module for test SMS framework. Does not send real SMS.
 * All requests are reported as correctly fulfilled.
 *
 *
 * Example of use:
 * => in your application.xml:
 * ===
 * <module id="sms" class="SMSDummyModule"
 * 		AuthUser="foo" AuthPassword="TheGreatSecret"
 *		Sender="ADearSender" />
 * <!-- sender can be a 11 alphanumeric char string (like "abcdef12345" or a
 * 16 numeric char string (like "+123456789012345") -->
 * ===
 * => in your PHP code:
 * ===
 * 		$m = $this->Application->getModule('sms');
 *		$m->setReceiver('+393494080985');
 * 		/* or $m->setReceiver(array('+393494080985','+393477232652'));
 *		$m->setSender('ADearSender');	// overrides the one in application.xml
 *		$m->setMessage('Hello! You should know that I\'m watching you. Better you watch'.
 * 			' your back. Bad thing if you call the police. Be warned. Bye.');
 *		$m->sendMessage();
 * ===
 *
 * TODO: more error checking, especially in receiver field.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2008 Ciro Mattia Gonano
 * @version 2.7
 * @license MIT (http://www.opensource.org/licenses/mit-license.html)
 * @package Modules.SMS
 */
class SMSDummyModule extends TModule
{
	private $_authuser = '';
	private $_authpassword = '';
	private $_sender = '';
	private $_receiver = '';
	private $_dateforsend = null;
	private $_message = '';

	/**
	 * Check auth correctness.
	 *
	 * @return boolean
	 */
	public function checkAuth() {
		return true;
	}

	/**
	 * Send a message through SMS.
	 *
	 * @return mixed The RequestID if sending was successful, false elsewhere
	 */
	public function sendMessage($requestID=null) {
		return mt_rand(1, 999);
	}

	/**
         * Checks message status for all pending SMS
         *
         * @return boolean
         */
	public function checkStatus() {
		return TRUE;
	}

	/**
	 * Sets the username to use for authentication.
	 *
	 * @param string $value The username to use for authentication.
	 */
	public function setAuthUser($value) {
		$this->_authuser = $value;
	}
	/**
	 * Returns the username to use for authentication.
	 *
	 * @return string The username to use for authentication.
	 */
	public function getAuthUser() {
		return $this->_authuser;
	}

	/**
	 * Sets the password to use for authentication.
	 *
	 * @param string $value The password to use for authentication.
	 */
	public function setAuthPassword($value) {
		$this->_authpassword = $value;
	}
	/**
	 * Returns the password to use for authentication.
	 *
	 * @return string The password to use for authentication.
	 */
	public function getAuthPassword() {
		return $this->_authpassword;
	}

	/**
	 * Sets the sender.
	 *
	 * @param string $value The sender, 11 alphanumeric chars or 16 numeric/+ chars.
	 */
	public function setSender($value) {
		$this->_sender = (preg_match('!\+?\d+!',$value))?
			substr($value,0,16):
			substr($value,0,11);
	}
	/**
	 * Returns the sender.
	 *
	 * @return string The sender.
	 */
	public function getSender() {
		return $this->_sender;
	}

	/**
	 * Sets the receiver(s).
	 * Can be a single number, or an array.
	 *
	 * @param mixed $value The receivers, a single string or an array.
	 */
	public function setReceiver($value) {
		$prefix = "";
		if($value[0] == "+")
		{
			$prefix = "+";
		}
		$mobile = Contact::getNormalizedMobileNumber($value);
		if(strlen($mobile) <= 11)
		    $prefix = "39"; // Add italy prefix

		$this->_receiver = $prefix . Contact::getNormalizedMobileNumber($value);

		//Prado::log("SMS:{$this->_receiver}");
	}
	
	/**
	 * Returns the receiver(s)
	 *
	 * @return mixed The receivers.
	 */
	public function getReceiver() {
                return $this->_receiver;
	}

	/**
	 * Sets the date for sending a posticipated message.
	 *
	 * @param string $value The date for sending (format has to be understandable by strtotime())
	 */
	public function setDateForSend($value) {
		$this->_dateforsend = $value;
	}
	/**
	 * Returns the date for sending a posticipated message.
	 *
	 * @return string The date for posticipate sending.
	 */
	public function getDateForSend() {
		return $this->_dateforsend;
	}

	/**
	 * Sets the message body.
	 *
	 * @param string $value The message body.
	 */
	public function setMessage($value) {
		$this->_message = $value;
	}
	/**
	 * Returns the message body.
	 *
	 * @return string The message body.
	 */
	public function getMessage() {
		return $this->_message;
	}

	/**
	 * Returns the number of messages sent for the current message body
	 *
	 * @return int
	 */
	public function getMsgNo() {
		$smslen = strlen($this->getMessage());
		return ($smslen < 161) ? 1 : ceil($smslen / 153);
	}
    /**
     * Returns notifications list using provider log.
     *
     * @return array
     */
    public function getHistory($date_from, $date_to) {
        return array();
    }
}
