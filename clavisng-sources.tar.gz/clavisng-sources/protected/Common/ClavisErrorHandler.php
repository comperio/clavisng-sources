<?php
/**
 * ClavisErrorHandler class
 *
 * @author Dario Rigolin <dario@comperio.it>
 * @author Ciro Mattia Gonano
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @copyright Copyright &copy; 2011 Comperio srl
 * @version 2.7
 * @package Core
 * @since 2.4
 */

class ClavisErrorHandler extends TErrorHandler
{
	private function getExactTrace($exception)
	{
		$trace=$exception->getTrace();
		$result=null;
		// if PHP exception, we want to show the 2nd stack level context
		// because the 1st stack level is of little use (it's in error handler)
		if($exception instanceof TPhpErrorException)
			$result=isset($trace[0]['file'])?$trace[0]:$trace[1];
		else if($exception instanceof TInvalidOperationException)
		{
			// in case of getter or setter error, find out the exact file and row
			if(($result=$this->getPropertyAccessTrace($trace,'__get'))===null)
				$result=$this->getPropertyAccessTrace($trace,'__set');
		}
		if($result!==null && strpos($result['file'],': eval()\'d code')!==false)
			return null;

		return $result;
	}

	private function getPropertyAccessTrace($trace,$pattern)
	{
		$result=null;
		foreach($trace as $t)
		{
			if(isset($t['function']) && $t['function']===$pattern)
				$result=$t;
			else
				break;
		}
		return $result;
	}

	private function getSourceCode($lines,$errorLine)
	{
		$beginLine=$errorLine-self::SOURCE_LINES>=0?$errorLine-self::SOURCE_LINES:0;
		$endLine=$errorLine+self::SOURCE_LINES<=count($lines)?$errorLine+self::SOURCE_LINES:count($lines);

		$source='';
		for($i=$beginLine;$i<$endLine;++$i)
		{
			if($i===$errorLine-1)
			{
				$line=htmlspecialchars(sprintf("%04d: %s",$i+1,str_replace("\t",'    ',$lines[$i])));
				$source.="<div class=\"error\">".$line."</div>";
			}
			else
				$source.=htmlspecialchars(sprintf("%04d: %s",$i+1,str_replace("\t",'    ',$lines[$i])));
		}
		return $source;
	}

	private function addLink($message)
	{
		$baseUrl='http://www.pradosoft.com/docs/classdoc';
		return preg_replace('/\b(T[A-Z]\w+)\b/',"<a href=\"$baseUrl/\${1}\" target=\"_blank\">\${1}</a>",$message);
	}

	/**
	 * Handles PHP user errors and exceptions.
	 * This is the event handler responding to the <b>Error</b> event
	 * raised in {@link TApplication}.
	 * The method mainly uses appropriate template to display the error/exception.
	 * It terminates the application immediately after the error is displayed.
	 * @param mixed sender of the event
	 * @param mixed event parameter (if the event is raised by TApplication, it refers to the exception instance)
	 */
	public function handleError($sender,$param)
	{
		static $handling=false;
		// We need to restore error and exception handlers,
		// because within error and exception handlers, new errors and exceptions
		// cannot be handled properly by PHP
		restore_error_handler();
		restore_exception_handler();
		// ensure that we do not enter infinite loop of error handling
		if($handling)
			$this->handleRecursiveError($param);
		else
		{
			$handling=true;
			if(($response=$this->getResponse())!==null)
				$response->clear();
			if($param instanceof THttpException)
				$this->handleExternalError($param->getStatusCode(),$param);
			else if($this->getApplication()->getMode()===TApplicationMode::Debug)
				$this->displayException($param);
			else
				$this->handleExternalError(500,$param);
		}
	}

	/**
	 * Displays error to the client user.
	 * THttpException and errors happened when the application is in <b>Debug</b>
	 * mode will be displayed to the client user.
	 * @param integer response status code
	 * @param Exception exception instance
	 */
	protected function handleExternalError($statusCode,$exception)
	{
		if(! $exception instanceof THttpException)
			error_log($exception->__toString());

		// if we're debugging display error instead of managing errorpage.
		if ($this->getApplication()->getMode()===TApplicationMode::Debug) {
			$content = $this->getErrorTemplate($statusCode,$exception);
			header("HTTP/1.0 $statusCode ".$exception->getMessage(), true, TPropertyValue::ensureInteger($statusCode));
			$tokens = array(
				'%%StatusCode%%' => "$statusCode",
				'%%ErrorMessage%%' => htmlspecialchars($exception->getMessage()),
				'%%ServerAdmin%%' => isset($_SERVER['SERVER_ADMIN'])?$_SERVER['SERVER_ADMIN']:'',
				'%%Version%%' => $_SERVER['SERVER_SOFTWARE'].' <a href="http://www.pradosoft.com/">PRADO</a>/'.Prado::getVersion(),
				'%%Time%%' => @strftime('%Y-%m-%d %H:%M',time())
			);
			echo strtr($content,$tokens);
			return;
		}
		
		switch ($statusCode) {
			case 400:
				// "Page state is corrupted." error, try reloading page.
				/*$this->getPage()->writeDelayedMessage(
					Prado::localize("Lo stato della pagina è stato ripristinato in seguito ad un errore; ".
						"EVENTUALI OPERAZIONI ORDINATE *NON* SONO STATE EFFETTUATE.\n".
						"Questo si verifica solitamente quando la pagina è aperta da troppo tempo senza azioni.\n".
						"Se dovesse accadere troppo spesso, provare a cancellare i cookie e riaprire il browser."),
					ClavisMessage::ERROR);*/
				$this->getResponse()->reload();
				break;
			
			case 404:
				$session = $this->getApplication()->getSession();
				$session['lastClavisError'] = $this->getService()->getRequestedPagePath();
				$this->getResponse()->redirect($this->getService()->constructUrl('Error.PageNotFound'));
				break;

			default:
				$user = $this->getUser();
				if (!$user instanceof ClavisLibrarian) {
					$this->displayException($exception);
					return;
				}

				$errorMessage = $exception->getMessage();
				if($exception instanceof TTemplateException)
				{
					$fileName=$exception->getTemplateFile();
					$lines=empty($fileName)?explode("\n",$exception->getTemplateSource()):@file($fileName);
					$source=$this->getSourceCode($lines,$exception->getLineNumber());
					if($fileName==='')
						$fileName='---embedded template---';
					$errorLine=$exception->getLineNumber();
				}
				else
				{
					if(($trace=$this->getExactTrace($exception))!==null)
					{
						$fileName=$trace['file'];
						$errorLine=$trace['line'];
					}
					else
					{
						$fileName=$exception->getFile();
						$errorLine=$exception->getLine();
					}
					$source=$this->getSourceCode(@file($fileName),$errorLine);
				}

				$library = $user->getActualLibrary();
				$request = $this->getApplication()->getRequest();

				$errorData = array(
					'Time'			=> @strftime('%Y-%m-%d %H:%M',time()),
					'ClavisVersion'	=> 'Release: '.Clavis::getVersion().' #'.Clavis::getRevision(),
					'Consortia'		=> $user->getActualConsortiaLabel(),
					'Library'		=> ($library instanceof Library) ? $library->getLabel() : 'unknown',
					'LibraryMail'	=> ($library instanceof Library) ? $library->getEmail() : 'unknown',
					'Librarian'		=> $user->getCompleteName(),
					'LibrarianMail'	=> $user->getEmail(),
					'Server'		=> $request->getServerName(),
					'RequestUri'	=> $request->getRequestUri(),
					'StatusCode'	=> "$statusCode",
					'ErrorType'		=> get_class($exception),
					'ErrorMessage'	=> $this->addLink(htmlspecialchars($exception->getMessage())),
					'SourceFile'	=> htmlspecialchars($fileName).' ('.$errorLine.')',
					'SourceCode'	=> $source,
					'StackTrace'	=> htmlspecialchars($exception->getTraceAsString()),
				);

				Prado::log($exception->getMessage(), TLogger::ERROR, 'ClavisNG');
				self::mailError($errorData);
				$session = $this->getApplication()->getSession();
				$session['lastClavisError'] = serialize($errorData);
				Prado::getApplication()->getResponse()->redirect($this->getService()->constructUrl('Error.ErrorPage'));
				break;
		}
	}

	protected static function mailError($errorData)
	{
		$to = ClavisParamQuery::getParam('CLAVISPARAM','ReportEmail');
		if (!$to)
			$to = 'dev@comperio.it';
		
		$mailer = Prado::getApplication()->getModule('mail');
		$backtrace = html_entity_decode($errorData['StackTrace']);
$body = <<< EOF
NOTIFICA AUTOMATICA ECCEZIONE CLAVISNG:

Data:			{$errorData['Time']}
ClavisNG ver.:	{$errorData['ClavisVersion']}
Sistema:			{$errorData['Consortia']}
Server:			{$errorData['Server']}
Biblioteca:		{$errorData['Library']} ({$errorData['LibraryMail']})
Operatore:		{$errorData['Librarian']} ({$errorData['LibrarianMail']})
Codice status:	{$errorData['StatusCode']}
ErrorType:		{$errorData['ErrorType']}

ErrorMessage:	{$errorData['ErrorMessage']}

URI richiesta:	{$errorData['RequestUri']}

File sorgente:	{$errorData['SourceFile']}

Backtrace:
{$backtrace}
EOF;

		$mailer->setFrom("\"{$errorData['Library']}\" <{$errorData['LibraryMail']}>");
		$mailer->setSubject('[CLAVISNG AUTOREPORT] '."{$errorData['Consortia']}: {$errorData['ErrorType']}\n");
		$mailer->setBody($body);
		$mailer->setTo($to);
		$mailer->send();
	}
}

