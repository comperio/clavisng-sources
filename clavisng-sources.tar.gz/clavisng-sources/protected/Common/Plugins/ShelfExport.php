<?php
/**
 * ShelfExport class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @author Dario Rigolin <dario@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.8.9
 * @package ShelfPlugins
 */

/**
 * Get the NumberFormat class.
 */
Prado::using('System.I18N.core.NumberFormat');

/**
 * ShelfExport Class
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @author Dario Rigolin <dario@comperio.it>
 * @version 2.8.9
 * @package ShelfPlugins
 * @since 2.2
 */
class ShelfExport extends ClavisPlugin
{
	const DELIMITER = ',';
	const ENCLOSURE = '"';
	const ISBD_SEPARATOR = ". - ";
	
//	public static $USABLE_SHELFTYPES = array(	ShelfPeer::TYPE_PATRON,
//												ShelfPeer::TYPE_LOAN,
//												ShelfPeer::TYPE_LIBRARY,
//												ShelfPeer::TYPE_ITEM,
//												ShelfPeer::TYPE_MANIFESTATION,
//												ShelfPeer::TYPE_AUTHORITY,
//												ShelfPeer::TYPE_LIBRARIAN);

	public static function getTargetShelfTypes()
	{
		return array(	ShelfPeer::TYPE_PATRON,
						ShelfPeer::TYPE_LOAN,
						ShelfPeer::TYPE_LIBRARY,
						ShelfPeer::TYPE_ITEM,
						ShelfPeer::TYPE_MANIFESTATION,
						ShelfPeer::TYPE_AUTHORITY,
						ShelfPeer::TYPE_LIBRARIAN );
	}
	
	public static function getEditMode()
	{
		return ShelfPeer::EDITTYPE_NONEDIT;
	}
	
	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsCallBack())
		{
			$shelf = $this->getShelf();
			
			if ($shelf instanceof Shelf)
			{
				$itemType = $shelf->getShelfItemtype();
			}
			else
			{
				$itemType = ShelfPeer::NOTYPE;
			}

			if (is_null($this->getItemType()))
			{
				$this->setItemType($itemType);
				$this->populateItemTypePanel($itemType);
			}
		}
	}

	private function setItemType($param)
	{
		$this->setControlState('ItemType', $param, null);
	}

	private function getItemType()
	{
		return $this->getControlState('ItemType', null);
	}

	private function setHeaders($param)
	{
		$this->setControlState('Headers', $param, array());
	}

	private function getHeaders()
	{
		return $this->getControlState('Headers', array());
	}

	private function setSelected($param)
	{
		$this->setControlState('Selected', $param, array());
	}

	private function getSelected()
	{
		return $this->getControlState('Selected', array());
	}

	public function isDataSourceNeeded()
	{
		return true;
	}

	public function IsPopup()
	{
		return true;
	}

	private function populateItemTypePanel($itemType)
	{
		$itemTypeString = LookupValuePeer::getLookupValue('SHELFITEMTYPE', $itemType);
		$objectChoicePanelVisible = false;
		$this->ExportButton->setVisible(true);
		$this->ItemTypePanel->setVisible(true);

		$headers = array();
		$selected = array();
		$sortChoiceArray = array();
		
		switch ($itemType)
		{
			case ShelfPeer::TYPE_PATRON:
				$headers = array(	1 => Prado::localize('COGNOME'),
									2 => Prado::localize('NOME'),
									3 => Prado::localize('CODICE FISCALE'),
									4 => Prado::localize('INDIRIZZO'),
									5 => Prado::localize('CAP'),
									6 => Prado::localize('CITTA'),
									7 => Prado::localize('PROVINCIA'),
									8 => Prado::localize('NAZIONE'),
									9 => Prado::localize('NAZIONALITÁ'),
									10 => Prado::localize('TELEFONO'),
									11 => Prado::localize('EMAIL'),
									12 => Prado::localize('BIBLIOTECA DI REGISTRAZIONE'),
									13 => Prado::localize('BARCODE'),
									14 => Prado::localize('DATA DI NASCITA'),
									15 => Prado::localize('SESSO'),
									16 => Prado::localize('TITOLO DI STUDIO'),
									17 => Prado::localize('PROFESSIONE'),
									18 => Prado::localize('BIBLIOTECA PREFERITA'),
									19 => Prado::localize('TESSERA'),
									20 => Prado::localize('SCADENZA TESSERA'),
									21 => Prado::localize('DATA DI REGISTRAZIONE'),
									22 => Prado::localize('ULTIMA OPERAZIONE'),
									23 => Prado::localize('CLASSE UTENTE'),
									24 => LookupValuePeer::getLookupValue('CUSTOMLABEL','PatronCustom1'),
									25 => LookupValuePeer::getLookupValue('CUSTOMLABEL','PatronCustom2'),
									26 => LookupValuePeer::getLookupValue('CUSTOMLABEL','PatronCustom3'),
									27 => Prado::localize('ULTERIORI SPECIFICAZIONI UTENTE') );

				$selected = array_fill(1, 27, true);
				
				/*
				 * Here we have an array which describes the logic for sorting
				 * results. In the future, we could import these types of things
				 * (as well ase the fields to export) from customized settings,
				 * for examples as system parameters stored in the DB and editable
				 * by administrator in the proper pages (in list form or directly
				 * in a exitable text forms with html fields (to validate)).
				 */
				$sortChoiceArray = array(	serialize(array(	array(	"join" => "Address",
																		"field" => "Address.City",
																		"direction" =>ModelCriteria::ASC) )) => Prado::localize("città") );
								
				break;

			case ShelfPeer::TYPE_LOAN:
				$headers = array(	1 => Prado::localize('TITOLO'),
									2 => Prado::localize('CLASSE'),
									3 => Prado::localize('INVENTARIO'),
									4 => Prado::localize('COLLOCAZIONE'),
									5 => Prado::localize('STATO DEL PRESTITO'),
									6 => Prado::localize('BIBLIOTECA DI APPARTENENZA'),
									7 => Prado::localize('BIBLIOTECA DI PARTENZA'),
									8 => Prado::localize('BIBLIOTECA DI DESTINAZIONE'),
									9 => Prado::localize('UTENTE'),
									10 => Prado::localize('NUM.BARCODE UTENTE'),
									11 => Prado::localize('NUM.TESSERA UTENTE'),
									12 => Prado::localize('DATA NASCITA UTENTE'),
									13 => LookupValuePeer::getLookupValue('CUSTOMLABEL','PatronCustom3'),
									14 => Prado::localize('CONTATTI UTENTE'),
									15 => Prado::localize('DATA INIZIO PRESTITO'),
									16 => Prado::localize('DATA FINE PRESTITO'),
									17 => Prado::localize('NUMERO RINNOVI'),
									18 => Prado::localize('NOTIFICHE'),
                                    19 => Prado::localize('BIBLIOTECA DI RESTITUZIONE'));
				
				$selected = array_fill(1, 19, true);
				
				break;

			case ShelfPeer::TYPE_LIBRARY:
				$headers = array(	1 => Prado::localize('DENOMINAZIONE'),
									2 => Prado::localize('INDIRIZZO'),
									3 => Prado::localize('TELEFONO'),
									4 => Prado::localize('EMAIL') );

				$selected = array_fill(1, 4, true);
				
				break;

			case ShelfPeer::TYPE_LIBRARIAN:
				$headers = array(	1 => Prado::localize('NOME'),
									2 => Prado::localize('COGNOME'),
									3 => Prado::localize('DATA DI NASCITA'),
									4 => Prado::localize('BIBLIOTECA DI DEFAULT'),
									5 => Prado::localize('TELEFONO'),
									6 => Prado::localize('EMAIL'),
									7 => Prado::localize('USERNAME'),
									8 => Prado::localize('UTENTE COLLEGATO'),
									9 => Prado::localize('LIVELLO DI CATALOGAZIONE'),
									10 => Prado::localize('STATO DI ATTIVAZIONE'),
									11 => Prado::localize('DATA SCADENZA PASSWORD'),
									12 => Prado::localize('DATA SCADENZA ACCOUNT'),
									13 => Prado::localize('PROFILO DEL BIBLIOTECARIO (NOTE)'),		// ->getLibrarianNote()
									14 => Prado::localize('PROFILI IN CLAVIS') );

				$selected = array_fill(1, 14, true);
				
				break;
			
			case ShelfPeer::TYPE_ITEM:
				$headers = array(	1 => Prado::localize('BARCODE'),  //
									2 => Prado::localize('TITOLO'),
									3 => Prado::localize('RECORD_ID'),
									4 => Prado::localize('AUTORE'),
									5 => Prado::localize('ISBN/ISSN'),
									6 => Prado::localize('ISBD'),
									7 => Prado::localize('DATA 1'),
									8 => Prado::localize('RFID'),  //rfid_code
									9 => Prado::localize('MEDIA'),  //item_media
									10 => Prado::localize('INVENTARIO'),
									11 => Prado::localize('SEZIONE'),  //
									12 => Prado::localize('COLLOCAZIONE'),
									13 => Prado::localize('DATA INV.'), //inventory_date
									14 => Prado::localize('SORGENTE'),
									15 => Prado::localize('VALORE'),
									16 => Prado::localize('CL. PRESTABILITÁ'),	//loan_class
									17 => Prado::localize('STATO DEL PRESTITO'),
									18 => Prado::localize('STATO'),
									19 => Prado::localize('MAI PRESTATO DAL'),
									20 => Prado::localize('DATA PREVISTA DI RITORNO'),
									21 => Prado::localize('STATO FISICO'),  //physical_status 
									22 => Prado::localize('COMPRATO DA'),  //owner_library_id
									23 => Prado::localize('GESTITO DA'),	//home_library_id
									24 => Prado::localize('SI TROVA IN'),  //actual_library_id
									25 => Prado::localize('VIS.DA OPAC'),		//opac_visible
									26 => Prado::localize('N.PRESTITI'),	////  -> calcolo prestiti storici (+ forse quello in corso: righe di loan)
									27 => LookupValuePeer::getLookupValue('CUSTOMLABEL','ItemCustom1'),	//custom_1
									28 => LookupValuePeer::getLookupValue('CUSTOMLABEL','ItemCustom2'),	//custom_2
									29 => LookupValuePeer::getLookupValue('CUSTOMLABEL','ItemCustom3'),	//custom_3
									30 => Prado::localize('NOTE ESEMPLARE'),
									31 => Prado::localize('DATA DI SCARTO'),
									32 => Prado::localize('PROVVEDIMENTO'),
									33 => Prado::localize('SORGENTE'),

                                    34 => Prado::localize('LUOGO DI EDIZIONE'),
                                    35 => Prado::localize('EDITORE'),
                                    36 => Prado::localize('LOCALIZZAZIONI ESEMPLARI'),
                                    );
				
				$selected = array_fill(1, 33, true);
				
				$sortChoiceArray = array(	serialize(array(	array(	"field" => "item.owner_library_id",
																		"direction" =>ModelCriteria::ASC ),
					
																array(	"field" => "item.inventory_serie_id",
																		"direction" => ModelCriteria::ASC ),

																array(	"field" => "item.inventory_number",
																		"direction" =>ModelCriteria::ASC ) )) => Prado::localize("inventario aggregato"),
					
											serialize(array(	array(	"field" => "item.home_library_id",
																		"direction" =>ModelCriteria::ASC ),
					
																array(	"field" => "item.section",
																		"direction" => ModelCriteria::ASC ),

																array(	"field" => "item.collocation",
																		"direction" => ModelCriteria::ASC ),

																array(	"field" => "item.specification",
																		"direction" =>ModelCriteria::ASC ) )) => Prado::localize("collocazione aggregata") );
				
				break;

			case ShelfPeer::TYPE_MANIFESTATION:
				$headers = array(	1 => Prado::localize('TITOLO'),
									2 => Prado::localize('RECORD_ID'),
									3 => Prado::localize('AUTORE'),
									4 => Prado::localize('ANNO'),
									5 => Prado::localize('ISBD'),
									6 => Prado::localize('ESEMPLARI'),
									7 => Prado::localize('DISPONIBILITA'),
									8 => Prado::localize('SORGENTE'),
                                    9 => Prado::localize('ISBN/ISSN'),
                                    10 => Prado::localize('EAN'),
									11 => Prado::localize('ABSTRACT'),
									12 => Prado::localize('DESTINATARI'));
									

				$selected = array_fill(1, 12, true);
				
				break;

			case ShelfPeer::TYPE_AUTHORITY:
				$headers = array(	1 => Prado::localize('INTESTAZIONE'),
									2 => Prado::localize('RECORD_ID'),
									3 => Prado::localize('TIPO AUTHORITY'),
									4 => Prado::localize('TIPO RECORD'),
									5 => Prado::localize('STATO INT.') );
				
				$selected = array_fill(1, 5, true);
				
				break;

			case ShelfPeer::NOTYPE:
			case null:
			case '':
			default:
				$this->ExportButton->setVisible(false);
				$this->getPage()->writeMessage(Prado::localize("Gli oggetti contenuti nello scaffale non sono di tipo omogeneo: scegliere un tipo di oggetti da esportare"),
												ClavisMessage::WARNING);
				
				$objectChoicePanelVisible = true;
		}

		/*
		 * Here we test if we have a defined shelfitem type ($headers is set, see
		 * switch() statement above)
		 */
		if (!$objectChoicePanelVisible
				|| (count($headers) > 0))
		{
			/**
			 * Here we draw the available headers for the right shelfitem type.
			 *
			 *And next we inject the sorting dropdownlist with the available
			 * sorting choices, or rather we hide it.
			 */
			$this->HeadersPanel->setVisible(true);
			
			if (count($this->HeadersList->getItems()) == 0)
			{
				$this->setSelected($selected);
				$this->setHeaders($headers);
				$this->initHeaders();
			}

			// sorting part
			$this->ExportChoicePanel->setVisible(true);
	
			if (count($sortChoiceArray) > 0)
			{
				$this->SortChoiceDropDownList->setDatasource($sortChoiceArray);
				$this->SortChoiceDropDownList->databind();
				$this->SortChoicePanel->setVisible(true);
			}
			else
			{
				$this->SortChoicePanel->setVisible(false);
			}
		}
		else	// a itemtype choice is necessary
		{
			$this->HeadersPanel->setVisible(false);
			$this->ExportChoicePanel->setVisible(false);
			$this->SortChoicePanel->setVisible(false);
		}

		$this->setItemType($itemType);
		
		$this->ItemTypeMessage1->setText(Prado::localize("Tipo di elementi da esportare:"));
		$this->ItemTypeMessage2->setText(Prado::localize($itemTypeString));
		$this->ObjectChoicePanel->setVisible($objectChoicePanelVisible);

		if ($objectChoicePanelVisible
				&& (count($this->ObjectFilter->getDataSource()) == 0))
		{
			$fallbackTypes = true;
			$shelf = $this->getShelf();
			
			if ($shelf instanceof Shelf)
			{
				$datasourceShelfTypes = $shelf->getShelfItemTypes();
				
				if (count($datasourceShelfTypes) > 0)
					$fallbackTypes = false;
			}

			if ($fallbackTypes)
				$datasourceShelfTypes = $this->getTargetShelfTypes();
			
			$datasource = LookupValuePeer::getLookupClassValues(	'SHELFITEMTYPE',
																	false,	// no  blank
																	null,
																	$datasourceShelfTypes,	// set of values
																	true );	// ordered

			$this->ObjectFilter->setDataSource($datasource);
			$this->ObjectFilter->dataBind();
		}
	}

	public function onObjectChoice($sender, $param)
	{
		$objectType = $this->ObjectFilter->getSelectedValue();

		// paranoid
		if (!in_array($objectType, $this->getTargetShelfTypes()))
		{
			$this->getPage()->writeMessage(Prado::localize("Tipo di oggetti non esportabile"),
											ClavisMessage::ERROR);
			
			return false;
		}

		$this->setItemType($objectType);
		$this->populateItemTypePanel($objectType);
	}
	
	public function onMasterChecked($sender, $param)
	{
		switch ($sender->getID())
		{
			case "MasterCheckYes":
				$selectedAll = true;
				break;

			case "MasterCheckNo":
			default:
				$selectedAll = false;
				break;
		}
		
		$this->initHeaders($selectedAll);
	}
	
	/**
	 * @param boolean $selectedAll -> is used when selecting/deselecting all the checkboxes
	 */
	private function initHeaders($selectedAll = null)
	{
		$selected = $this->getSelected();
		$this->HeadersList->getItems()->clear();
		
		foreach ($this->getHeaders() as $value => $text)
		{
			$item = new TListItem();
			$item->setText($text);
			$item->setValue($value);

			if (is_bool($selectedAll))
			{
				$item->setSelected($selectedAll);
				$selected[$value] = $selectedAll;
			}
			elseif (array_key_exists($value, $selected))
			{
				$item->setSelected($selected[$value]);
			}

			$this->HeadersList->getItems()->add($item);
		}
		
		if (is_bool($selectedAll))
			$this->setSelected($selected);
		
		if ($this->getPage()->getIsCallback())
			$this->HeadersPanel->render($this->getPage()->createWriter());
	}

	private function readSelectedHeaders()
	{
		$resultArray = array();
		$items = $this->HeadersList->getItems();

		foreach ($items as $index => $item)
		{
			if ($item->getSelected())
				$resultArray[$item->getValue()] = $item->getText();
		}

		return $resultArray;
	}

	public function onExport($sender, $param)
	{
		if ($this->SortChoicePanel->getVisible())
		{
			///
		}

		$selectedHeaders = $this->readSelectedHeaders();
		if (count($selectedHeaders) == 0)    // there are no selected fields to export to csv
		{
			$this->getPage()->writeMessage(Prado::localize("Non è stato selezionato alcun campo per esportare gli oggetti"),
											ClavisMessage::ERROR);
			
			return false;
		}

		/**
		 * the types of shelfitems in the shelf (i.e. "item")
		 * It has to be set with a valid value
		 */
		$itemType = $this->getItemType();
		$objectIds = array();
		
		foreach ($this->getCheckedItemsIds() as $rowShelfItemArray)
		{
			if ($rowShelfItemArray[2] == $itemType)
				$objectIds[] = $rowShelfItemArray[1];
		}
		
		/**
		 * Here we want to retrieve (in an unhydrated way) all the
		 * objects (real elements, pointed by itemshelves).
		 * 
		 * If we want, for a particular shelftype we can put a particular
		 * ordering policy.
		 */
		switch ($itemType)
		{
			case ShelfPeer::TYPE_PATRON:
				$query = PatronQuery::create()
							->filterByPatronId($objectIds);
//							->useAddressQuery()
//								->orderByCity(CRITERIA::ASC)
//							->endUse();
							//->join("Address");
								
				break;
			
			case ShelfPeer::TYPE_LOAN:
				$query = LoanQuery::create()
							->filterByLoanId($objectIds);
				
				break;
			
			
			case ShelfPeer::TYPE_LIBRARY:
				$query = LibraryQuery::create()
							->filterByLibraryId($objectIds);
				
				break;
			
			case ShelfPeer::TYPE_ITEM:
				$query = ItemQuery::create()
							->filterByItemId($objectIds);
//							->orderByHomeLibraryId()
//							->orderBySection()
//							->orderByCollocation()
//							->orderBySpecification();
				
				break;
			
			case ShelfPeer::TYPE_MANIFESTATION:
				$query = ManifestationQuery::create()
							->filterByManifestationId($objectIds);
				
				break;
			
			case ShelfPeer::TYPE_AUTHORITY:
				$query = AuthorityQuery::create()
							->filterByAuthorityId($objectIds);
				
				break;
					
			case ShelfPeer::TYPE_LIBRARIAN:
				$query = LibrarianQuery::create()
							->filterByLibrarianId($objectIds);
				
				break;
			
			default:
				$this->getPage()->writeMessage(Prado::localize("Impossibile esportare"),
												ClavisMessage::ERROR);

				return false;
		}
		
		if ($query->count() == 0)    // no objects to export were found
		{
			$this->getPage()->writeMessage(Prado::localize("Nessun oggetto da esportare"),
											ClavisMessage::ERROR);
			
			return false;
		}

		// beginning of the real exporting section
		ini_set("memory_limit", "700M");
		set_time_limit(0);

		$joinQueries = array();
		$sortQueries = array();
		
		// sorting
		$sortString = $this->SortChoiceDropDownList->getSelectedValue();
		
		if ($sortString != "")
		{
			$sortArray = @unserialize($sortString);
			
			if (count($sortArray) > 0)
			{
				foreach ($sortArray as $sortRow)
				{
					if (array_key_exists("join", $sortRow))
						$joinQueries[] = $sortRow["join"];
					
					if (array_key_exists("field", $sortRow))
					{
						if (array_key_exists("direction", $sortRow))
						{
							$direction = $sortRow["direction"];
						}
						else
						{
							$direction = ModelCriteria::ASC;
						}
						
						$sortQueries[] = array(	$sortRow["field"],
												$direction );
					}
				}
			}
		}

		foreach ($joinQueries as $queryRow)
			$query->join($queryRow, Criteria::LEFT_JOIN);
		
		if (count($joinQueries) > 0)
			$query->distinct();
			   
		foreach ($sortQueries as $sortRow)
			$query->orderBy($sortRow[0], $sortRow[1]);

		$objects = $query->setFormatter(ModelCriteria::FORMAT_ON_DEMAND)->find();

		$encoding = ($this->FormatForExcel->getChecked()
							? 'Windows-1252'
							: 'UTF-8');

		$countDone = 0;
		$loopDatasource = array();

		foreach ($objects as $object)
		{
			$loopElement = array();

			/**
			 * We want to exctract all the data fields from the object,
			 * according to the type of object, and put in the $loopElement
			 */
			switch ($itemType)
			{
				case ShelfPeer::TYPE_PATRON:
					if (array_key_exists(1, $selectedHeaders))
						$loopElement[] = $object->getLastName();

					if (array_key_exists(2, $selectedHeaders))
						$loopElement[] = $object->getName();

					if (array_key_exists(3, $selectedHeaders))
						$loopElement[] = $object->getNationalId();
										
					$addressArray = $object->getPreferredAddressArray();
					if (array_key_exists(4, $selectedHeaders))
						$loopElement[] = $addressArray['street'];

					if (array_key_exists(5, $selectedHeaders))
						$loopElement[] = $addressArray['zip'];

					if (array_key_exists(6, $selectedHeaders))
						$loopElement[] = $addressArray['onlycity'];  // OLD ... = $sortingElement 

					if (array_key_exists(7, $selectedHeaders))
						$loopElement[] = $addressArray['province'];

					if (array_key_exists(8, $selectedHeaders))
						$loopElement[] = $object->getBirthCountry();							

					if (array_key_exists(9, $selectedHeaders))
						$loopElement[] = $object->getCitizenship();							

					if (array_key_exists(10, $selectedHeaders))
						$loopElement[] = $object->getPhone2String();

					if (array_key_exists(11, $selectedHeaders))
						$loopElement[] = $object->getEmail2String();

					if (array_key_exists(12, $selectedHeaders))
					{
						$lib = $object->getRegistrationLibrary();
						$loopElement[] = ($lib instanceof Library) ? $lib->getLabel() : '---';
					}

					if (array_key_exists(13, $selectedHeaders))
						$loopElement[] = $object->getBarcode();

					if (array_key_exists(14, $selectedHeaders))
						$loopElement[] = $object->getBirthDate('Y-m-d');

					if (array_key_exists(15, $selectedHeaders))
						$loopElement[] = $object->getGender();

					if (array_key_exists(16, $selectedHeaders))
						$loopElement[] = LookupValuePeer::getLookupValue('STUDTYPE',$object->getStatisticStudy());

					if (array_key_exists(17, $selectedHeaders))
						$loopElement[] = LookupValuePeer::getLookupValue('WORKTYPE',$object->getStatisticWork());

					if (array_key_exists(18, $selectedHeaders))
					{
						$prefLib = $object->getPreferredLibrary();
						$loopElement[] = ($prefLib instanceof Library) ? $prefLib->getLabel() : '---';
					}

					if (array_key_exists(19, $selectedHeaders))		// tessera
						$loopElement[] = $object->getCardCode();

					if (array_key_exists(20, $selectedHeaders))
						$loopElement[] = $object->getCardExpire('Y-m-d');

					if (array_key_exists(21, $selectedHeaders))	// data registrazione
						$loopElement[] = $object->getDateCreated('Y-m-d');

					if (array_key_exists(22, $selectedHeaders))
						$loopElement[] = $object->getLastSeen('Y-m-d');

					if (array_key_exists(23, $selectedHeaders))
						$loopElement[] = LookupValuePeer::getLookupValue('PATRONLOANCLASS', $object->getLoanClass());

					if (array_key_exists(24, $selectedHeaders))
						$loopElement[] = $object->getCustom1String();

					if (array_key_exists(25, $selectedHeaders))
						$loopElement[] = $object->getCustom2String();

					if (array_key_exists(26, $selectedHeaders))
						$loopElement[] = $object->getCustom3String();

					if (array_key_exists(27, $selectedHeaders))
					{
						$properties = array();
						/* @var $property PatronProperty */
						foreach ($object->getPatronPropertys() as $property)     
						{
							$propertyLabel = LookupValuePeer::getLookupValue("PATRONPROPERTY", $property->getPropertyClass());
							$propertyValue = $property->getPropertyValue();

							$properties[] = "($propertyLabel = $propertyValue)";
						}

						$loopElement[] = implode("\n", $properties);
					}

					$object->clearAllReferences(true);
					
					break;  // end of patron case

				case ShelfPeer::TYPE_LOAN:
				    /** @var Loan $object */

					$item = $object->getItem();

					$collocationCombo = '';
					$title = '';
					$class = '';
					$patronName = '';
					$patronBirthDate = '';
					$patronBarcode = '';
					$patronCardcode = '';
					$homeLibraryLabel = ' ';
					$homeLibraryCode = ' ';
					$loanDateBegin = '';
					$loanDueDate = '';
					$renewCount = 0;
					$solicitCount = 0;

					if ($item instanceof Item)
					{
						$collocationCombo = $item->getCollocationCombo();
						$homeLibrary = $item->getHomeLibrary();
						
						if ($homeLibrary instanceof Library)
						{
							$homeLibraryLabel = $item->getHomeLibraryLabel();
							$homeLibraryCode = $homeLibrary->getLibraryCode();
						}

						$class = $item->getManifestationDewey();
					}

					$title = $object->getTrimmedTitle(80);
					$patron = $object->getPatron();
					
					if ($patron instanceof Patron)
					{
						$patronName = $patron->getCompleteName();
						$patronBarcode = $patron->getBarcode();
						$patronCardcode = $patron->getCardCode();
						$patronBirthDate = Clavis::dateFormat($patron->getBirthDate('U'));
						$patronContact = implode(' / ', $patron->getPreferredContacts(true));
						
						$patronCustom3 = $patron->getCustom3();
						//var_dump($patronCustom3, $patron->getPatronId());die;
					}
					else
					{
						$externalLibrary = $object->getExternalLibrary();
						
						if ($externalLibrary instanceof Library)
						{
							$patronName = $externalLibrary->getLabel(true, true, true);
							$patronContact = Prado::localize('email') . ': ' . $externalLibrary->getEmail();
						}
						else
						{
							$patronName = '(' . Prado::localize("non esiste l'utente") . ')';
							$patronContact = '';
						}
					}

					if (($class == '')
							|| is_null($class))
					{
						$class = $object->getClassCode();

						if (($class == '')
								|| is_null($class))
						{
							$manifestation = $object->getManifestation();
							
							if ($manifestation instanceof Manifestation)
								$class = $manifestation->getClass();
						}
					}
					
					if (is_null($class))
						$class = '';

					$loanDateBegin = Clavis::dateFormat($object->getLoanDateBegin('U'));
					$loanDateBeginRaw = $object->getLoanDateBegin('U');
					$loanStatus = $object->getLoanStatusString();

					if (in_array($object->getLoanStatus(), ItemPeer::getLoanStatusActive()))
					{
						$loanDateEnd = Clavis::dateFormat($object->getDueDate('U'));
					}
					else
					{
						$loanDateEnd = Clavis::dateFormat($object->getLoanDateEnd('U'));
					}

					$fromLibraryLabel = $object->getFromLibraryLabel();
					$toLibraryLabel = $object->getToLibraryLabel();

					if ($object->getLibraryRelatedByEndLibrary() instanceof Library)
    				{
						$endLibraryLabel = $object->getLibraryRelatedByEndLibrary()->getLabel();
					}
					else
					{
						$endLibraryLabel = "";
					}

					$invNumber = $object->getInvNumber();
					$renewCount = $object->getRenewCount();
					
					if (($renewCount == '') 
							|| is_null($renewCount))
						$renewCount = 0;

					$solicitCount = $object->getNotifyCount();
					
					if (($solicitCount == '') 
							|| is_null($solicitCount))
						$solicitCount = 0;

					if (array_key_exists(1, $selectedHeaders))
						$loopElement[] = mb_convert_encoding(	$title,
																$encoding,
																mb_detect_encoding($title));

					if (array_key_exists(2, $selectedHeaders))
						$loopElement[] = $class;

					if (array_key_exists(3, $selectedHeaders))
						$loopElement[] = $invNumber;

					if (array_key_exists(4, $selectedHeaders))
						$loopElement[] = $collocationCombo;

					if (array_key_exists(5, $selectedHeaders))
						$loopElement[] = $loanStatus;

					if (array_key_exists(6, $selectedHeaders))
						$loopElement[] = $homeLibraryLabel;

					if (array_key_exists(7, $selectedHeaders))
						$loopElement[] = $fromLibraryLabel;

					if (array_key_exists(8, $selectedHeaders))
						$loopElement[] = $toLibraryLabel;

					if (array_key_exists(9, $selectedHeaders))
					{		
						$loopElement[] = mb_convert_encoding(	$patronName,
																$encoding,
																mb_detect_encoding($patronName));
					}
					
					if (array_key_exists(10, $selectedHeaders))
						$loopElement[] = $patronBarcode;

					if (array_key_exists(11, $selectedHeaders))
						$loopElement[] = $patronCardcode;

					if (array_key_exists(12, $selectedHeaders))
						$loopElement[] = $patronBirthDate;

					if (array_key_exists(13, $selectedHeaders))
						$loopElement[] = $patronCustom3;
					
					if (array_key_exists(14, $selectedHeaders))
						$loopElement[] = $patronContact;

					if (array_key_exists(15, $selectedHeaders))
						$loopElement[] = $loanDateBegin;

					if (array_key_exists(16, $selectedHeaders))
						$loopElement[] = $loanDateEnd;

					if (array_key_exists(17, $selectedHeaders))
						$loopElement[] = $renewCount;

					if (array_key_exists(18, $selectedHeaders))
						$loopElement[] = $solicitCount;

					if (array_key_exists(19, $selectedHeaders))
                        $loopElement[] = $endLibraryLabel;

					$object->clearAllReferences(true);
                                        
					if ($item instanceof Item)
						$item->clearAllReferences(true);
										
					if ($patron instanceof Patron)
						$patron->clearAllReferences(true);
					
					break;

				case ShelfPeer::TYPE_LIBRARY:
					$description = $object->getDescription();
					$address = $object->getAddress();
					$phone = $object->getPhone();
					$email = $object->getEmail();

					if (array_key_exists(1, $selectedHeaders))
						$loopElement[] = mb_convert_encoding(	$description,
																$encoding,
																mb_detect_encoding($description));

					if (array_key_exists(2, $selectedHeaders))
						$loopElement[] = mb_convert_encoding(	$address,
																$encoding,
																mb_detect_encoding($address));

					if (array_key_exists(3, $selectedHeaders))
						$loopElement[] = $phone;

					if (array_key_exists(4, $selectedHeaders))
						$loopElement[] = $email;

					$object->clearAllReferences(true);
						
					break;

				case ShelfPeer::TYPE_ITEM:
					/* @var $object Item */
					$loanStatus = $object->getLoanStatus();
					$manifestation = $object->getManifestation();
					$itemId = $object->getId();

					$author = "";
					$title = "";
					$isbnIssn = "";
					$isbd = "";
					$editionDate = "";
                    $editionPlace = "";
                    $publisher = "";
                    $itemCount = "";

					if ($manifestation instanceof Manifestation)
					{
						$author = $manifestation->getAuthor();
						$tm = $manifestation->getTurboMarc();
						$title = $tm->getFullTitle();
						$isbd = "{$author}, {$title}" . self::ISBD_SEPARATOR; //\n";
						$v = $tm->getEditions();
						
						if ($v)
							$isbd .= implode(' / ', $v) . self::ISBD_SEPARATOR; //\n";
						
						$v = $tm->getPublications();
						
						if ($v)
							$isbd .= implode(' / ', $v) . self::ISBD_SEPARATOR; //\n";
						
						$v = $tm->getPhysicalDescs();
						
						if ($v)
							$isbd .= implode(' / ', $v) . self::ISBD_SEPARATOR; //\n";
						
						foreach ($manifestation->getAreas() as $area)
							$isbd .= Prado::localize(ManifestationPeer::getAreaName($area['field'])) . ": {$area['value']}"  . self::ISBD_SEPARATOR; //\n";
							
						$editionDate = $manifestation->getEditionDate();
                        $publisher = $manifestation->getPublisher();
                        if(isset($tm->d210) && isset($tm->d210->sa)) {
                            $editionPlace = (string)$tm->d210->sa;
                        }
                        if($publisher == "" && isset($tm->d210) && isset($tm->d210->sc)) {
                            $publisher = (string)$tm->d210->sc;
                        }


						$isbnIssn = $manifestation->getIsbnissn();
					}
					else // out of catalog
					{
						$title = $object->getTitle();
					}
					
					$loanClassString = $object->getLoanClassString();
					$loanStatusString = $object->getLoanStatusString($loanStatus);
					$itemStatusString = $object->getItemStatusString();
					$dueDateString = Clavis::dateFormat($object->getDueDate('U'));
					$lastSeenString = Clavis::dateFormat($object->getLastSeen('U'));
					$collocationCombo = $object->getCollocationCombo($this->getUser()->getActualLibraryId());
					$inventoryNumber = $object->getCompleteInventoryNumber();
					$inventoryDate = Clavis::dateFormat($object->getInventoryDate('U'));
					
					if (trim($inventoryDate) != '')
						$inventoryDate = "(" . $inventoryDate . ")";
					
					if (((string) $inventoryNumber != '')
							&& ($inventoryDate != ''))
						$inventoryNumber .= " ";
					
					$inventoryCombo = $inventoryNumber . $inventoryDate;

					$source = LookupValuePeer::getLookupValue('ITEMSOURCE', $object->getItemSource());

					if (is_null($collocationCombo)
							|| ($collocationCombo == ''))
						$collocationCombo = '---';
					
					if (is_null($inventoryCombo)
							|| ($inventoryCombo == ''))
						$inventoryCombo = '---';
					
					if (is_null($source)
							|| ($source == ''))
						$source = '---';

					$barcode = $object->getBarcode();
					$rfid = $object->getRfidCode();
					$itemMedia = LookupValuePeer::getLookupValue('ITEMMEDIATYPE', $object->getItemMedia());
					$section = LibraryValuePeer::getLibraryValue(	'ITEMSECTION',
																	$object->getSection(),
																	$object->getHomeLibraryId());

					$inventoryDate = Clavis::dateFormat($object->getInventoryDate('U'));
					$physicalStatusString = $object->getPhysicalStatusString();
					$opacVisibleString = (intval($object->getOpacVisible()) > 0
												? Prado::localize("sì")
												: Prado::localize("no"));

					$loansNumber = count($object->getLoans());
					$custom1 = $object->getCustomField1String();
					$custom2 = $object->getCustomField2String();
					$custom3 = $object->getCustomField3String();

					$notesString = '';
					
					foreach ($object->getItemNotes() as $note) 
					{
						$noteContent = trim($note->getNote());
						$noteTypeLabel	= LookupValuePeer::getLookupValue('UNI3XX', $note->getNoteType())
											. ' (' . $note->getNoteType() . ')';

						if ($noteContent != '')
							$notesString .= $noteContent . " [" . $noteTypeLabel . "]\n";
					}
					
					$notesString = rtrim($notesString);

					$ownerLibrary = $object->getOwnerLibrary();
					$ownerLibraryString = '';
					
					if ($ownerLibrary instanceof Library)
						$ownerLibraryString = $ownerLibrary->getLabel();

					$homeLibrary = $object->getHomeLibrary();
					$homeLibraryString = '';
					
					if ($homeLibrary instanceof Library)
						$homeLibraryString = $object->getHomeLibraryLabel();

					$actualLibrary = $object->getActualLibrary();
					$actualLibraryString = '';
					
					if ($actualLibrary instanceof Library)
						$actualLibraryString = $actualLibrary->getLabel();

					$loanAlert = $object->getLoanAlert();
					$alertNote = (($loanAlert === 'I')
										|| ($loanAlert === 'B'))
									? $object->getLoanAlertNote()
									: '';

					$formatter = new NumberFormat($this->getApplication()->getGlobalization()->getCulture());
					$currencyValue = $formatter->format($object->getCurrencyValue(), 'c', $object->getCurrency(), "{$encoding}//TRANSLIT");
					$dateDiscarded = Clavis::dateFormat($object->getDateDiscarded('U'));
					$discardNote = $object->getDiscardNote();
					
					if (array_key_exists(1, $selectedHeaders))
						$loopElement[] = $barcode;

					if (array_key_exists(2, $selectedHeaders))
					{		
						$loopElement[] = mb_convert_encoding(	$title,
																$encoding,
																mb_detect_encoding($title));
					}
					
					if (array_key_exists(3, $selectedHeaders))
						$loopElement[] = $itemId;

					if (array_key_exists(4, $selectedHeaders))
						$loopElement[] = $author;

					if (array_key_exists(5, $selectedHeaders))
					{		
						$loopElement[] = mb_convert_encoding(	$isbnIssn,
																$encoding,
																mb_detect_encoding($isbnIssn));
					}
					
					if (array_key_exists(6, $selectedHeaders))
					{		
						$loopElement[] = mb_convert_encoding(	$isbd,
																$encoding,
																mb_detect_encoding($isbd));
					}
					
					if (array_key_exists(7, $selectedHeaders))
						$loopElement[] = $editionDate;

					if (array_key_exists(8, $selectedHeaders))
						$loopElement[] = $rfid;

					if (array_key_exists(9, $selectedHeaders))
						$loopElement[] = $itemMedia;

					if (array_key_exists(10, $selectedHeaders))
						$loopElement[] = $inventoryCombo;

					if (array_key_exists(11, $selectedHeaders))
						$loopElement[] = $section;

					if (array_key_exists(12, $selectedHeaders))
						$loopElement[] = $collocationCombo;

					if (array_key_exists(13, $selectedHeaders))
						$loopElement[] = $inventoryDate;

					if (array_key_exists(14, $selectedHeaders))
						$loopElement[] = $source;

					if (array_key_exists(15, $selectedHeaders))
						$loopElement[] = $currencyValue;

					if (array_key_exists(16, $selectedHeaders))
						$loopElement[] = $loanClassString;

					if (array_key_exists(17, $selectedHeaders))
						$loopElement[] = $loanStatusString;
					
					if (array_key_exists(18, $selectedHeaders))
						$loopElement[] = $itemStatusString;

					if (array_key_exists(19, $selectedHeaders))
						$loopElement[] = $lastSeenString;

					if (array_key_exists(20, $selectedHeaders))
						$loopElement[] = $dueDateString;
					
					if (array_key_exists(21, $selectedHeaders))
						$loopElement[] = $physicalStatusString;

					if (array_key_exists(22, $selectedHeaders))
						$loopElement[] = $ownerLibraryString;

					if (array_key_exists(23, $selectedHeaders))
						$loopElement[] = $homeLibraryString;

					if (array_key_exists(24, $selectedHeaders))
						$loopElement[] = $actualLibraryString;

					if (array_key_exists(25, $selectedHeaders))
					{		
						$detectedEncoding = mb_detect_encoding($opacVisibleString);

						if ($encoding != $detectedEncoding)
						{	
							$opacVisibleString =  mb_convert_encoding($opacVisibleString,
																	$encoding,
																	$detectedEncoding);
						}
						
						$loopElement[] = $opacVisibleString;
					}

					if (array_key_exists(26, $selectedHeaders))
						$loopElement[] = $loansNumber;

					if (array_key_exists(27, $selectedHeaders))
						$loopElement[] = $custom1;

					if (array_key_exists(28, $selectedHeaders))
						$loopElement[] = $custom2;

					if (array_key_exists(29, $selectedHeaders))
						$loopElement[] = $custom3;

					if (array_key_exists(30, $selectedHeaders))
						$loopElement[] = mb_convert_encoding($notesString, $encoding, mb_detect_encoding($notesString));

					if (array_key_exists(31, $selectedHeaders))
						$loopElement[] = $dateDiscarded;

					if (array_key_exists(32, $selectedHeaders))
						$loopElement[] = $discardNote;
					
                    if ($manifestation instanceof Manifestation)
					{
                        $source = $manifestation->getBidSource();
                        $manifestationId = $manifestation->getManifestationId();
                    
						if (array_key_exists(33, $selectedHeaders))
                            $loopElement[] = mb_convert_encoding($source, $encoding, mb_detect_encoding($source));
                    }

                    if (array_key_exists(34, $selectedHeaders))
                        $loopElement[] = $editionPlace;

                    if (array_key_exists(35, $selectedHeaders)) {
                        $loopElement[] = $publisher;
                    }

                    if (array_key_exists(36, $selectedHeaders)) {

                        if($manifestationId > 0) {
                            $shelfId = $this->getShelf()->getShelfId();
                            $itemCount = ItemQuery::create()
                                ->where("Item.ItemId NOT IN (SELECT object_id FROM shelf_item WHERE shelf_id = {$shelfId})")
                                ->filterByManifestationId($manifestationId)
                                ->filterByItemStatus(ItemStatus::ITEMSTATUS_DISCARDED,Criteria::NOT_EQUAL)
                                ->filterByItemId($itemId, Criteria::NOT_EQUAL)
                                ->count();
                        }

                        $loopElement[] = $itemCount;
                    }
                                        
					$object->clearAllReferences(true);
					
                    if ($manifestation instanceof Manifestation)
                        $manifestation->clearAllReferences(true);
					
					break;

				case ShelfPeer::TYPE_MANIFESTATION:
				    /** @var Manifestation $object */
					$manifestationId = $object->getManifestationId();

					$isbd = " ";
					$author = $object->getAuthor();
					$tm = $object->reloadTurboMarc();

					$title = $tm->getFullTitle();
					$isbd = "{$author}, {$title}" . self::ISBD_SEPARATOR; //\n";

					$v = $tm->getEditions();
					
					if ($v)
						$isbd .= implode(' - ', $v) . self::ISBD_SEPARATOR; //\n";
					
					$v = $tm->getPublications();
					
					if ($v)
						$isbd .= implode(' - ', $v) . self::ISBD_SEPARATOR; //\n";
					
					$v = $tm->getPhysicalDescs();
					
					if ($v)
						$isbd .= implode(' - ', $v);
					
					foreach ($object->getAreas() as $area)
						$isbd .= Prado::localize(ManifestationPeer::getAreaName($area['field'])) . ": {$area['value']}" . self::ISBD_SEPARATOR;

					$y = $object->getYear();
					
					if (array_key_exists('date', $y))
					{
						$year = $y['date'];
					}
					else
					{
						$year = '';
					}

					$isbn = $object->getIsbnissn();
					$ean  = $object->getEan();
					
					$itemStats = $this->getApplication()->getModule('loan')->extractItemStats($object);
					
					$abstract = $tm->getAbstract();
					
					$targetsLabel = '';
					
					if ($target = trim($object->getTarget()))
					{
						$cur = 17;
						$targets = array();

						foreach (explode('-', $target) as $t)
						{
							if (!trim($t))
								continue;

							$code = UnimarcCodesQuery::create()
											->findPk([$this->getApplication()->getGlobalization()->getCulture(), 100, 'a', $cur, $t, 'U']);

							if ($code instanceof UnimarcCodes)
								$targets[] = $code->getLabel();

							++$cur;
						}

						if (count($targets) > 0)
							$targetsLabel .= implode('; ', $targets);
					}
					
					if (array_key_exists(1, $selectedHeaders))
						$loopElement[] = mb_convert_encoding($title,$encoding,mb_detect_encoding($title));

					if (array_key_exists(2, $selectedHeaders))
						$loopElement[] = $manifestationId;

					if (array_key_exists(3, $selectedHeaders))
						$loopElement[] = mb_convert_encoding($author,$encoding,mb_detect_encoding($author));

					if (array_key_exists(4, $selectedHeaders))
						$loopElement[] = $year;

					if (array_key_exists(5, $selectedHeaders))
						$loopElement[] = mb_convert_encoding($isbd,$encoding,mb_detect_encoding($isbd));

					if (array_key_exists(6, $selectedHeaders))
						$loopElement[] = $itemStats['Items'];

					if (array_key_exists(7, $selectedHeaders))
						$loopElement[] = str_replace('&nbsp;', '', $itemStats['AvailItems']);
                                        
					$source = $object->getBidSource();                                                                                        
                    
					if (array_key_exists(8, $selectedHeaders))
						$loopElement[] = mb_convert_encoding($source,$encoding,mb_detect_encoding($source));

                    if (array_key_exists(9, $selectedHeaders))
                        $loopElement[] = $isbn;

                    if (array_key_exists(10, $selectedHeaders))
                        $loopElement[] = $ean;

                    if (array_key_exists(11, $selectedHeaders))
                        $loopElement[] = $abstract;

                    if (array_key_exists(12, $selectedHeaders))
                        $loopElement[] = $targetsLabel;
					
                    $object->clearAllReferences(true);
					
					break;

				case ShelfPeer::TYPE_AUTHORITY:
					if (array_key_exists(1, $selectedHeaders))
					{
						$loopElement[] = mb_convert_encoding(	$object->getFullText(),
																$encoding,
																mb_detect_encoding($object->getFullText()));
					}
					
					if (array_key_exists(2, $selectedHeaders))
						$loopElement[] = $object->getAuthorityId();
					
					if (array_key_exists(3, $selectedHeaders))
						$loopElement[] = LookupValuePeer::getLookupValue('AUTHTYPE', $object->getAuthorityType());
					
					if (array_key_exists(4, $selectedHeaders))
						$loopElement[] = LookupValuePeer::getLookupValue('AUTHRECTYPE', $object->getAuthorityType());
					
					if (array_key_exists(5, $selectedHeaders))
						$loopElement[] = LookupValuePeer::getLookupValue('AUTHINTSTA', $object->getAuthorityStatus());
					
					$object->clearAllReferences(true);
					
					break;
					
				case ShelfPeer::TYPE_LIBRARIAN:
					if (array_key_exists(1, $selectedHeaders))
						$loopElement[] = $object->getName();

					if (array_key_exists(2, $selectedHeaders))
						$loopElement[] = $object->getLastname();
					
					if (array_key_exists(3, $selectedHeaders))
						$loopElement[] = $object->getBirthdate('Y-m-d');

					$defaultLibraryLabel = "---";
					$defaultLibraryId = $object->getDefaultLibraryId();
		
					if ((!is_null($defaultLibraryId))
							&& (is_numeric($defaultLibraryId)))
					{
						$defaultLibrary = LibraryQuery::create()->findPk($defaultLibraryId);

						if ($defaultLibrary instanceof Library)
							$defaultLibraryLabel = $defaultLibrary->getLabel();
					}
		
					if (array_key_exists(4, $selectedHeaders))
						$loopElement[] = $defaultLibraryLabel;
					
					if (array_key_exists(5, $selectedHeaders))
						$loopElement[] = $object->getPhone();
					
					if (array_key_exists(6, $selectedHeaders))
						$loopElement[] = $object->getEmail();

					if (array_key_exists(7, $selectedHeaders))
						$loopElement[] = $object->getUsername();

					$p = $object->getPatron();
		
					if ($p instanceof Patron)
					{
						$patronName = $p->getCompleteName();
					}
					else
					{
						$patronName = '---';
					}

					if (array_key_exists(8, $selectedHeaders))
						$loopElement[] = $patronName;

					$catLevel = $object->getCatLevel();
		
					if (!$catLevel)
						$catLevel = '0';

					if (array_key_exists(9, $selectedHeaders))
						$loopElement[] = LookupValuePeer::getLookupValue('CATLEVEL', $catLevel);

					$activationStatusRaw = $object->getActivationStatus();
					
					if ($activationStatusRaw == 1)
					{
						$activationStatus = Prado::localize("si");
					}
					else
					{
						$activationStatus = Prado::localize("no");
					}
						
					if (array_key_exists(10, $selectedHeaders))
						$loopElement[] = $activationStatus;
					
					if (array_key_exists(11, $selectedHeaders))
						$loopElement[] = $object->getSecretExpire('Y-m-d');
					
					if (array_key_exists(12, $selectedHeaders))
						$loopElement[] = $object->getLibrarianExpire('Y-m-d');

					if (array_key_exists(13, $selectedHeaders))
						$loopElement[] = $object->getLibrarianNote();
					
					$profileArray = [];

					foreach ($object->getProfiles() as $profile)
						$profileArray[] = $profile->getAppProfile()->getName();
		
					if (array_key_exists(14, $selectedHeaders))
						$loopElement[] = implode(', ', $profileArray);
					
					$object->clearAllReferences(true);
						
					break;
			}

			if (count($loopElement) > 0)
			{
				$countDone++;
				$loopDatasource[$countDone] = $loopElement;
			}
			
		}   // end of cycle on objects

		$now = getdate();
		$dateSubfix = $now['year'] . "-" . $now['mon'] . "-" . $now['mday'];
	
		// here we put out the document file
		header('Content-Type: text/csv; charset=' . $encoding);
		header('Content-Disposition: inline; filename=shelf' . '_' . $dateSubfix . '.csv');
		$fp = fopen('php://output', 'w');
		
		if ($this->HeadersViewFlag->getChecked())
			fputcsv($fp, $selectedHeaders, self::DELIMITER, self::ENCLOSURE);
		
		foreach ($loopDatasource as $row)
			fputcsv($fp, $row, self::DELIMITER, self::ENCLOSURE);
		
		fclose($fp);
		die();
	}
	
}
