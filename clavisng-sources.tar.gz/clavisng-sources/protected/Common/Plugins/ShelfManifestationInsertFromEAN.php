<?php
/**
 * ShelfManifestationInsertFromEAN class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.8.7
 * @package ShelfPlugins
 */

/**
 * ShelfManifestationInsertFromEAN Class
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.8.7
 * @package ShelfPlugins
 * @since 2.8.7
 */

class ShelfManifestationInsertFromEAN extends ClavisPlugin
{
	public static function getTargetShelfTypes()
	{
		return array(ShelfPeer::TYPE_MANIFESTATION);
	}
	
	public static function getEditMode()
	{
		return ShelfPeer::EDITTYPE_EDIT;
	}
	
	public static function getFillMode()
	{
		return true;
	}
	
	public function onInit($param)
	{
		parent::onInit($param);

		if (count($this->Shelf->getDataSource()) == 0)
		{
			$datasource = ShelfPeer::getVisibleShelvesArray(Prado::getApplication()->getUser(), $this->getTargetShelfTypes());
			$this->Shelf->setDataSource($datasource);
			$this->Shelf->dataBind();

			$shelfId = intval($this->getShelfId());
			$shelf = null;
			
			if ($shelfId > 0)
				$shelf = ShelfQuery::create()
							->findPk($shelfId);
			
			if ($shelf instanceof Shelf)
			{
				if ($shelf->isVisible($this->getUser()))
				{
					try
					{
						$this->Shelf->setSelectedValue($shelfId);
					}
					catch (Exception $e)
					{
						Prado::log(Prado::localize('Lo scaffale della pagina non è selezionabile') . ': '.Prado::varDump($e->getCode()));
					}
				}
			}
		}
	}

	public function setIsItemValid($valid = false)
	{
		$this->getApplication()->getSession()->add('IsItemValid', $valid, false);
	}

	public function getIsItemValid()
	{
		return $this->getApplication()->getSession()->itemAt('IsItemValid', false);
	}

	public function addManifestationToShelf($items, $param)
	{
		$this->ManifestationView->setManifestation(null);
		$message = '';

		$shelf = ShelfQuery::create()
			->findPk($this->Shelf->getSelectedValue());
		
		$addCount = 0;

		if ($shelf instanceof Shelf)
		{
			foreach ($items as $item)
			{
				$ok = ShelfPeer::addItemToShelf(	$shelf, 
													ShelfPeer::TYPE_MANIFESTATION, 
													$item->getItemId() );
				
				if ($ok) 
					$addCount++;
			}
			
			$this->getPage()->shelfListRefresh($param);
			$this->getPage()->writeMessage(Prado::localize("Aggiunte a scaffale {count} notizie",
																array('count' => $addCount ),
											ClavisMessage::CONFIRM));
		}
		else
		{
			$this->getPage()->writeMessage(Prado::localize("Lo scaffale non è valido"),
											ClavisMessage::ERROR);

			$message = Prado::localize('lo scaffale non è valido');
		}

		$this->setIsItemValid(true);

		$this->ManifestationView->populate();
		$this->ManifestationView->render($param->getNewWriter());

		$this->Message->setText($message);
		$this->Message->render($param->getNewWriter());
	}

	public function onEANCallBack($sender, $param)
	{
		$this->ManifestationView->setManifestation(null);
		$message = '';
		$ok = false;

		$shelf = ShelfQuery::create()
					->findPk($this->Shelf->getSelectedValue());
		
		if ($shelf instanceof Shelf)
		{
			$EANInput = trim($this->EAN->getSafeText());
			$this->EAN->setText('');

			if ($EANInput !== '')
			{
				///$items = ItemPeer::retrieveByDataInput($itemInput);
				
				
				$EANInput = Clavis::normalizeStdNum($EANInput);

				$response = Prado::getApplication()->getModule('search')->search("+(fldin_txt_numbers:{$EANInput})", 0, 50);
				$idArray = array();

				if ($response)
				{
					foreach ($response['response']['docs'] as $key => $result)
						$idArray[] = $result['Id'];
				}

				$manifestations = ManifestationQuery::create()->findByManifestationId($idArray);
				$manifestationCopy = $manifestations;
				
				if (!is_null($manifestations)
						&& (count($manifestations) > 0))
				{
					$ok = true;
					$manifestation = is_array($manifestations)
								? array_shift($manifestations)
								: $manifestations->shift();
					
					/* @var $manifestation Manifestation */
					
					if (count($manifestationCopy) == 1)
					{
						$this->drawDuplicateManifestationEANPanel(false, $param);
					}
					else  // nel caso di trovati duplicati
					{
					/**	
						$encodedUrl = ItemPeer::encodeItems2Url($itemsCopy);
						$this->DuplicateItemId->setText($encodedUrl);
						$this->DuplicateItemHyperLink->dataBind();
						$this->drawDuplicateItemBarcodePanel(true, $param);
					 */
					}
					
					$ok = ShelfPeer::addItemToShelf(	$shelf,
														ShelfPeer::TYPE_MANIFESTATION,
														$manifestation->getManifestationId() );
					
					$this->ManifestationView->setManifestation($manifestation);
					
					if ($ok)
					{
						$this->getPage()->shelfListRefresh($param);
						$this->getPage()->writeMessage(Prado::localize("Notizia '{title}' [codice = {ean}] inserita nello scaffale",
																			array(	'ean' => $EANInput,
																					'title' => $manifestation->getTrimmedTitle(40, '/') )),
															ClavisMessage::CONFIRM);
						
						$this->setIsItemValid(true);
					}
					else
					{
						// dummy
					}
				}
				else
				{
					$this->getPage()->writeMessage(Prado::localize("codice non valido"),
														ClavisMessage::ERROR);
				}
			}
		}
		else
		{
			$this->getPage()->writeMessage(Prado::localize("Lo scaffale non è valido"),
												ClavisMessage::ERROR);
			
			$message = Prado::localize('lo scaffale non è valido');
		}

		$this->ManifestationView->populate();
		$this->ManifestationView->render($param->getNewWriter());

		$this->Message->setText($message);
		$this->Message->render($param->getNewWriter());
	}

	public function isDataSourceNeeded()
	{
		return false;
	}

	public function drawDuplicateManifestationEANPanel($newState = false, $param = null)
	{
		$currentState = $this->DuplicateManifestationEANPanel->getCssClass() == "panel_on"
								? true
								: false;

		if ($currentState != $newState)
		{
			$newCssClass = $newState
								? 'panel_on'
								: 'panel_off';

			$this->DuplicateManifestationEANPanel->setCssClass($newCssClass);

			if (!is_null($param))
				$this->DuplicateManifestationEANPlaceHolder->render($param->getNewWriter());
		}
	}

}