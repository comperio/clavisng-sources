<?php
/**
 * ShelfContentSetOperations class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.8.9
 * @package ShelfPlugins
 */

/**
 * ShelfContentSetOperations Class
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.8.9
 * @package ShelfPlugins
 * @since 2.8.9
 */

class ShelfContentSetOperations extends ClavisPlugin
{
	const SETOPERATION_UNION = "unione";
	const SETOPERATION_INTERSECTION = "intersezione";
	const SETOPERATION_MINUS = "differenza";
	const SETOPERATION_MINUSSYMETRIC = "differenza simmetrica";
	
	public static function getTargetShelfTypes()
	{
		return [];
	}
	
	public static function getEditMode()
	{
		return ShelfPeer::EDITTYPE_EDIT;
	}

	public static function getFillMode()
	{
		return true;
	}
	
	public function onInit($param)
	{
		parent::onInit($param);

		if (!$this->getPage()->getIsCallBack())
		{
			$operations = array(	self::SETOPERATION_UNION => Prado::localize(self::SETOPERATION_UNION),
									self::SETOPERATION_INTERSECTION => Prado::localize(self::SETOPERATION_INTERSECTION),
									self::SETOPERATION_MINUS => Prado::localize(self::SETOPERATION_MINUS),
									self::SETOPERATION_MINUSSYMETRIC => Prado::localize(self::SETOPERATION_MINUSSYMETRIC) );
			
			$this->SetOperation->setDataSource($operations);
			$this->SetOperation->dataBind();
			
			if (count($this->ObjectFilter->getDataSource()) == 0)
			{
				$datasource = LookupValuePeer::getLookupClassValues('SHELFITEMTYPE', true, null, null, true);
				$this->ObjectFilter->setDataSource($datasource);
				$this->ObjectFilter->dataBind();
			}

			if ($this->SetOperationMessage->getText() == "")
				$this->setSetOperationMessage();
		}
	}
	
	private function setSetOperationMessage($type = self::SETOPERATION_UNION)
	{
		$messages = array(	self::SETOPERATION_UNION => Prado::localize("Gli elementi degli scaffali sorgenti verranno fusi, eliminando i doppioni"),
							self::SETOPERATION_INTERSECTION => Prado::localize("Verranno processati solo gli elementi in comune fra entrambi gli scaffali sorgenti"),
							self::SETOPERATION_MINUS => Prado::localize("Verranno processati solo gli elementi dello scaffale 1 che non sono presenti nello scaffale 2"),
							self::SETOPERATION_MINUSSYMETRIC => Prado::localize("Verranno processati solo gli elementi che sono presenti o solo nello scaffale 1 o solo nello scaffale 2") );
		
		if (isset($messages[$type]))
			$this->SetOperationMessage->setText($messages[$type]);
	}
	
	private function extractShelfElements($shelfId, $objectFilter)
	{
		$result = [];
		
		if ((int) $shelfId > 0)
		{
			$query = ShelfItemQuery::create()
						->filterByShelfId($shelfId);
			
			if ($objectFilter != "0")
				$query->filterByObjectClass($objectFilter);
				
			foreach ($query->find() as $shelfItem)
				$result[] = (string) $shelfItem->getObjectId() . "-" . $shelfItem->getObjectClass();
		}
		
		return $result;
	}
	
	public function onAction($sender, $param)
	{
		ini_set("memory_limit", "700M");
		set_time_limit(0);
		
		$shelfSrc1 = null;
		$shelfSrc1Id = (int) $this->ShelfSrc1Id->getValue();
		
		if ($shelfSrc1Id == 0)
		{
				$this->getPage()->writeMessage(Prado::localize("Selezionare lo scaffale sorgente 1"),
													ClavisMessage::WARNING);

				return false;
		}
		else
		{
			$shelfSrc1 = ShelfQuery::create()->findPk($shelfSrc1Id);

			if (!($shelfSrc1 instanceof Shelf))
			{
				$this->getPage()->writeMessage(Prado::localize("Lo scaffale sorgente 1 selezionato, con id={shelfId}, non esiste",
																	array('shelfId' => $shelfSrc1Id)),
													ClavisMessage::ERROR);

				return false;
			}
		}
			

		$shelfSrc2 = null;
		$shelfSrc2Id = (int) $this->ShelfSrc2Id->getValue();
		
		if ($shelfSrc2Id == 0)
		{
				$this->getPage()->writeMessage(Prado::localize("Selezionare lo scaffale sorgente 2"),
													ClavisMessage::WARNING);

				return false;
		}
		else
		{
			$shelfSrc2 = ShelfQuery::create()->findPk($shelfSrc2Id);

			if (!($shelfSrc2 instanceof Shelf))
			{
				$this->getPage()->writeMessage(Prado::localize("Lo scaffale sorgente 2 selezionato, con id={shelfId}, non esiste",
																	array('shelfId' => $shelfSrc2Id)),
													ClavisMessage::ERROR);

				return false;
			}
		}
		
		if ($shelfSrc1Id == $shelfSrc2Id)
		{
			$this->getPage()->writeMessage(Prado::localize("Lo scaffale sorgente 1 e sorgente 2 coincidono, è necessario modificare le scelte"),
												ClavisMessage::WARNING);
			
			return false;
		}
		
		$shelfDst = $this->getShelf();
		$shelfDstId = $shelfDst->getShelfId();

		if ($shelfSrc1Id == $shelfDstId)
		{
			$this->getPage()->writeMessage(Prado::localize("Lo scaffale sorgente 1 e lo scaffale destinazione coincidono, è necessario modificare lo scaffale sorgente 1"),
												ClavisMessage::ERROR);
			
			return false;
		}

		if ($shelfSrc2Id == $shelfDstId)
		{
			$this->getPage()->writeMessage(Prado::localize("Lo scaffale sorgente 2 e lo scaffale destinazione coincidono, è necessario modificare lo scaffale sorgente 2"),
												ClavisMessage::ERROR);
			
			return false;
		}
		
		//// we can go on with processing ...
		$this->getPage()->cleanMessageQueue();

		$objectFilter = $this->ObjectFilter->getSelectedValue();

		if (is_null($objectFilter))
			$objectFilter = "0";

		$shelfSrc1Elements = $this->extractShelfElements($shelfSrc1Id, $objectFilter);
		$shelfSrc2Elements = $this->extractShelfElements($shelfSrc2Id, $objectFilter);
		$dstElements = [];

		$countDone = 0;
		$countFailed = 0;
		$countDuplicated = 0;

		switch ($this->SetOperation->getSelectedValue())
		{
			case self::SETOPERATION_UNION:
				$dstElements = array_unique(array_merge(	$shelfSrc1Elements,
															$shelfSrc2Elements));
				
				break;
			
			case self::SETOPERATION_INTERSECTION:
				$dstElements = array_intersect(	$shelfSrc1Elements,
												$shelfSrc2Elements);
				
				break;
			
			case self::SETOPERATION_MINUS:
				$dstElements = array_diff(	$shelfSrc1Elements, 
											$shelfSrc2Elements);
				
				break;

			case self::SETOPERATION_MINUSSYMETRIC:
				$dstElements = array_merge(	array_diff(	$shelfSrc1Elements, 
														$shelfSrc2Elements), 
						
											array_diff(	$shelfSrc2Elements, 
														$shelfSrc1Elements));
				
				break;
		}
		
		$actionDone = $this->SetOperation->getSelectedValue();
		
		foreach ($dstElements as $el)
		{
			list ($objectId, $objectClass) = explode("-", $el);
			
			$newShelfItem = new ShelfItem();
			$newShelfItem->setShelfId($shelfDstId);
			$newShelfItem->setObjectId($objectId);
			$newShelfItem->setObjectClass($objectClass);
			
			try
			{
				$newShelfItem->save();
				$countDone++;
			}
			catch (Exception $ex)
			{
				if (strpos($ex->getMessage(), 'Duplicate entry') > 0)
				{
					$countDuplicated++;
				}
				else
				{
					$countFailed++;
				}
			}
			
			unset ($newShelfItem);
		}
		
		if (($countDone == 0)
				&& ($countFailed == 0)
				&& ($countDuplicated == 0))
		{	
			$this->getPage()->enqueueMessage(Prado::localize('Nessuna operazione effettuata'),
												ClavisMessage::INFO);
		}
		else
		{
			if ($countDone > 0)
			{	
				$this->getPage()->enqueueMessage(Prado::localize("Scaffale '{shelfName}' (id={shelfId}): {count} elementi aggiunti con l'azione '{action}'",
																	array(	'shelfName' => str_replace(array('"', '\''), '', $shelfDst->getShelfName()),
																			'shelfId' => $shelfDstId,
																			'count' => $countDone,
																			'action' => $actionDone )),
													ClavisMessage::CONFIRM);
				
				ChangelogPeer::logAction(	$shelfDst,
											ChangelogPeer::LOG_UPDATE,
											$this->getUser(),
											"Scaffale modificato: applicata azione '$actionDone' dagli scaffali '" 
												. str_replace(array('"', '\''), '', $shelfSrc1->getShelfName()) . "' (id=$shelfSrc1Id) e  '" 
												. str_replace(array('"', '\''), '', $shelfSrc2->getShelfName()) . "' (id=$shelfSrc2Id)");
			}

			if ($countFailed > 0)
			{
				$this->getPage()->enqueueMessage(Prado::localize("{count} elementi non processati con l'azione '{action}' a causa di errori",
																	array(	'count' => $countFailed,
																			'action' => $actionDone )),
													ClavisMessage::ERROR);
			}
			
			if ($countDuplicated > 0)
			{
				$this->getPage()->enqueueMessage(Prado::localize("{count} elementi non processati con l'azione '{action}' perchè già esistenti nello scaffale di destinazione",
																	array(	'count' => $countDuplicated,
																			'action' => $actionDone )),
													ClavisMessage::INFO);
			}
		}

		if ($countDone > 0)			// close popup, exit here
		{	
			$this->getPage()->flushDelayedMessage();
			$this->onClose();
		}
		else						// stay open
		{
			$this->getPage()->flushMessage();
			///// no action done    $this->getPage()->shelfListRefresh($param);
		}
	}

	public function onChangeSetOperationMessage($sender, $param)
	{
		$this->setSetOperationMessage($this->SetOperation->getSelectedValue());
	}
	
	/*
	private function OLDextractShelfElements($shelf, $objectFilter)
	{
		$result = [];
		
		if ($shelf instanceof Shelf)
		{
			$shelf->forceReloadShelf();
			$criteria = new Criteria();
			
			if ($objectFilter != "0")
				$criteria->add(ShelfItemPeer::OBJECT_CLASS, $objectFilter, Criteria::EQUAL);

			$criteria->addJoin(ShelfItemPeer::SHELF_ID, ShelfPeer::SHELF_ID);
			$shelfItems = $shelf->getShelfItems($criteria);

			foreach ($shelfItems as $shelfItem)
				$result[] = (string) $shelfItem->getObjectId() . "-" . $shelfItem->getObjectClass();
		}
		
		return $result;
	}
	 */
	
}