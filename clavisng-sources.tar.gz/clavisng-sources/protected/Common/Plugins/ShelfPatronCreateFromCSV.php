<?php
/**
 * ShelfPatronCreateFromCSV class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.8.9
 * @package ShelfPlugins
 */

/**
 * ShelfPatronCreateFromCSV Class
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.8.9
 * @package ShelfPlugins
 * @since 2.8.9
 */

class ShelfPatronCreateFromCSV extends ClavisPlugin
{
	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsCallBack())
		{
			//
		}
	}

	public function isDataSourceNeeded()
	{
		return false;
	}

	protected function onFileUploaded($sender, $param)
	{
		if ($sender->getHasFile())
   		{
			$tmpdir = realpath(Prado::getPathOfNamespace('Storage.temp'));
			
			if (!is_dir($tmpdir))
				mkdir($tmpdir, '0777', true);
			
			$uploadedFile = $tmpdir . $this->FileChooseField->getFileName();
			$this->setViewState('uploadedFile', $uploadedFile);
			$this->FileChooseField->saveAs($uploadedFile);
   		}
	}
	
	public function onImport($sender, $param)
	{
		ini_set("memory_limit", "700M");
		set_time_limit(0);
		
		$toShelf = $this->getShelf();
		$uploadedFile = $this->getViewState('uploadedFile');

		if ($uploadedFile == '')
		{
			$this->getPage()->writeMessage(Prado::localize('Errore sulla scelta del file di importazione'),
												ClavisMessage::ERROR);
			
			return false;
		}

		if ($this->NationalIdCheck->getChecked())
		{
			$nationalIdSearchFlag = true;
		}
		elseif ($this->ComboNameCheck->getChecked())
		{
			$nationalIdSearchFlag = false;
		}

		$countDone = 0;
		$countSkipped = 0;
		$countFailed = 0;
		$countOpacUsernameDuplicate = 0;
		$toShelfIds = [];
		$countAddedShelf = 0;
		
		foreach (ClavisBase::parseCsv($uploadedFile) as $rowArray)
		{
			if (!is_array($rowArray) 
					|| (count($rowArray) == 0))
				continue;

			// national id (codice fiscale) case
			if ($nationalIdSearchFlag)
			{
				$nationalId = trim($rowArray['national_id']);
				
				if ($nationalId != "")
				{
					$existingPatron = PatronQuery::create()
										->filterByNationalId($nationalId)
										->findOne();
					
					if ($existingPatron instanceof Patron)
					{
						$countSkipped++;
						continue;	// breaks cycle
					}
				}
			}
			// combonames case
			else
			{
				$lastname = trim($rowArray['lastname']);
				$name = trim($rowArray['name']);
				$birthdate = trim($rowArray['birth_date']);

				if (($lastname != '')
						&& ($name != '')
						&& ($birthdate != ''))
				{
					$existingPatron = PatronQuery::create()
										->filterByLastname($lastname)
										->filterByName($name)
										->filterByBirthDate($birthdate)
										->findOne();
					
					if ($existingPatron instanceof Patron)
					{
						$countSkipped++;
						continue;	// breaks cycle
					}
				}
			}
			
			// we can go on creating a new patron
			
			list ($newPatronId, $patronExceptionCode) = $this->createPatron($rowArray);
			
			if ($newPatronId > 0)
			{
				$countDone++;			
				$toShelfIds[] = $newPatronId;
			}	
			else
			{
				if ($patronExceptionCode == LibrarianPeer::EXCP_USERNAME_DUP)
				{
					$countOpacUsernameDuplicate++;
				}
				else
				{
					$countFailed++;
				}
			}
		}
		
		if (count($toShelfIds) > 0)
		{	
			$countAddedShelf = ShelfPeer::addItemToShelf(	$this->getShelf(),
															ShelfPeer::TYPE_PATRON,
															$toShelfIds);
		}
		
		$this->getPage()->cleanMessageQueue();
		
		if (($countDone == 0)
				&& ($countSkipped == 0)
				&& ($countFailed == 0)
				&& ($countOpacUsernameDuplicate == 0))
		{
			$this->getPage()->enqueueMessage(Prado::localize("Nessuna azione eseguita"),
																ClavisMessage::INFO);
		}
		else
		{
			if ($countDone > 0)
			{	
				$this->getPage()->enqueueMessage(Prado::localize("{count} utenti creati da CSV'",
																		array('count' => $countDone)),
													ClavisMessage::CONFIRM);
				
				if ($countAddedShelf > 0)
				{
					$this->getPage()->enqueueMessage(Prado::localize("{count} utenti aggiunti nello scaffale '{shelfName}' (id: {shelfId})",
																		array(	'count' => $countAddedShelf,
																				'shelfId' => $toShelf->getShelfId(),
																				'shelfName' => $toShelf->getShelfName() )),
														ClavisMessage::CONFIRM);
				}
			}
			
			if ($countSkipped > 0)
			{	
				$this->getPage()->enqueueMessage(Prado::localize("{count} utenti non creati perchè già esistenti nel database, trovati per {cause}",
																	array(	'count' => $countSkipped,
																			'cause' => $nationalIdSearchFlag
																							? "codice fiscale"
																							: "nome/cognome/data di nascita" )),
													ClavisMessage::INFO);
			}
			
			if ($countFailed > 0)
			{	
				$this->getPage()->enqueueMessage(Prado::localize("{count} utenti non creati a causa di errori",
																	array('count' => $countFailed)),
													ClavisMessage::WARNING);
			}
			
			if ($countOpacUsernameDuplicate > 0)
			{	
				$this->getPage()->enqueueMessage(Prado::localize("{count} utenti non creati a causa di opac_username già esistente",
																	array('count' => $countOpacUsernameDuplicate)),
													ClavisMessage::WARNING);
			}
		}

		if ($countDone > 0)
		{
			$this->getPage()->flushDelayedMessage();
			$this->onClose();
		}
		else
		{
			$this->getPage()->flushMessage();
		}
	}

	private function createPatron($rowArray = [])
	{
		$newPatronId = 0;
		$patronException = new Exception();
		
		$newPatron = new Patron();

		try
		{
			$newPatron->setLastname(trim($rowArray['lastname']));
			$newPatron->setName(trim($rowArray['name']));
			$newPatron->setBirthDate(trim($rowArray['birth_date']));
			$newPatron->setNationalId(trim($rowArray['national_id']));

			$newPatron->setRegistrationLibraryId((int) trim($rowArray['registration_library_id']));
			$newPatron->setPreferredLibraryId((int) trim($rowArray['preferred_library_id']));

			$newPatron->setGender(trim($rowArray['gender']));
			$newPatron->setTitle(trim($rowArray['title']));
			$newPatron->setCivilStatus(trim($rowArray['civil_status']));

			$newPatron->setDocumentType(trim($rowArray['document_type']));
			$newPatron->setDocumentNumber(trim($rowArray['document_number']));
			$newPatron->setDocumentEmitter(trim($rowArray['document_emitter']));
			$newPatron->setDocumentExpiry(trim($rowArray['document_expiry']));
			$newPatron->setCitizenship(trim($rowArray['citizenship']));

			$newPatron->setLoanClass(trim($rowArray['loan_class']));
			$newPatron->setPatronStatus(trim($rowArray['patron_status']) != ""
												? trim($rowArray['patron_status'])
												: PatronPeer::STATUS_INCOMPLETE);

			$newPatron->setBirthCity(trim($rowArray['birth_city']));
			$newPatron->setBirthProvince(trim($rowArray['birth_province']));
			$newPatron->setBirthCountry(trim($rowArray['birth_country']));

			$newPatron->setPatronNote(trim($rowArray['patron_note']));
			$newPatron->setCardCode(trim($rowArray['card_code']));
			$newPatron->setBarcode(trim($rowArray['barcode']));
			$newPatron->setRfidCode(trim($rowArray['rfid_code']));
			$newPatron->setCardExpire(trim($rowArray['card_expire']));
			$newPatron->setMaxLoans(trim($rowArray['max_loans']));
			$newPatron->setSurfEnable(trim($rowArray['surf_enable']));
			$newPatron->setOpacUsername(trim($rowArray['opac_username']));	////////////
			$newPatron->setOpacSecret(trim($rowArray['opac_secret']));
			$newPatron->setOpacSecretExpire(trim($rowArray['opac_secret_expire']));
			$newPatron->setVoiceEnable(trim($rowArray['voice_enable']));
			$newPatron->setOpacEnable(trim($rowArray['opac_enable']));
			$newPatron->setPrivacyApprove(trim($rowArray['privacy_approve']));
			$newPatron->setAreasOfInterest(trim($rowArray['areas_of_interest']));
			$newPatron->setBiography(trim($rowArray['biography']));
			$newPatron->setAccessNote(trim($rowArray['access_note']));
			$newPatron->setAccessAlert(trim($rowArray['access_alert']));
			$newPatron->setStatisticStudy(trim($rowArray['statistic_study']));
			$newPatron->setStatisticWork(trim($rowArray['statistic_work']));
			$newPatron->setLastSeen(trim($rowArray['last_seen']));
			$newPatron->setCustom1(trim($rowArray['custom1']));
			$newPatron->setCustom2(trim($rowArray['custom2']));
			$newPatron->setCustom3(trim($rowArray['custom3']));
			$newPatron->setCheckIn(trim($rowArray['check_in']));
			$newPatron->setCheckOut(trim($rowArray['check_out']));
			$newPatron->setCheckLibrary(trim($rowArray['check_library']));			

			$newPatron->save();
			$newPatronId = $newPatron->getPatronId();
		}
		catch (Exception $patronException)
		{
			//
		}

		if ($newPatronId > 0)
		{
			$newAddress = new Address();

			try
			{
				$newAddress->setPatronId($newPatronId);
				$newAddress->setAddressType('R');
				$newAddress->setStreetType('V1');
				$newAddress->setStreet(trim($rowArray['street']));
				$newAddress->setStreetNum(trim($rowArray['street_num']));
				$newAddress->setVillage(trim($rowArray['village']));
				$newAddress->setCity(trim($rowArray['city']));
				$newAddress->setZip(trim($rowArray['zip']));
				$newAddress->setProvince(trim($rowArray['province']));
				$newAddress->setCountry(trim($rowArray['country']));
				
				$newAddress->save();
			}
			catch (Exception $ex)
			{
				//
			}

			if ($rowArray['telefono_cellulare'] != "")
			{	
				$newContact = new Contact();

				try
				{
					$newContact->setPatronId($newPatronId);
					$newContact->setContactType(ContactPeer::TYPE_MOBILE);
					$newContact->setContactValue($rowArray['telefono_cellulare']);

					$newContact->save();
				}
				catch (Exception $ex)
				{
					//
				}
			}

			if ($rowArray['telefono_fisso'] != "")
			{	
				$newContact = new Contact();

				try
				{
					$newContact->setPatronId($newPatronId);
					$newContact->setContactType(ContactPeer::TYPE_PHONE);
					$newContact->setContactValue($rowArray['telefono_fisso']);
				
					$newContact->save();
				}
				catch (Exception $ex)
				{
					//
				}
			}

			if ($rowArray['indirizzo_email'] != "")
			{	
				$newContact = new Contact();

				try
				{
					$newContact->setPatronId($newPatronId);
					$newContact->setContactType(ContactPeer::TYPE_EMAIL);
					$newContact->setContactValue($rowArray['indirizzo_email']);
					
					$newContact->save();
				}
				catch (Exception $ex)
				{
					//
				}
			}
		}
		
		return array($newPatronId, $patronException->getCode());
	}
	
	public function IsPopup()
	{
		return true;
	}
	
}