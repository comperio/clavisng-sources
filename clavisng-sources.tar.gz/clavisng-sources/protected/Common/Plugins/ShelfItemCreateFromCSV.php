<?php
/**
 * ShelfItemCreateFromCSV class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2019 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2019 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.9.10
 * @package ShelfPlugins
 */

/**
 * ShelfItemCreateFromCSV Class
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.9.10
 * @package ShelfPlugins
 * @since 2.9.10
 */

class ShelfItemCreateFromCSV extends ClavisPlugin
{
	public static function getTargetShelfTypes()
	{
		return array(ShelfPeer::TYPE_ITEM);
	}
	
	public static function getEditMode()
	{
		return ShelfPeer::EDITTYPE_EDIT;
	}
	
	public static function getFillMode()
	{
		return true;
	}
	
	/*
	 * We expect the CSV input file to have all the following rows
	 */
	public static function getRequiredFields()
	{
		// requested data fields in the CSV file for importing
		return array("ean","title","library_id","inventory_serie_id","inventory_number"); //,"collocation","barcode","item_status","loan_class","item_media");
	}
	
	public function IsPopup()
	{
		return true;
	}

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsCallBack())
		{
			//$this->SkipCreationCheck->setChecked(true);
		}
	}

	public function isDataSourceNeeded()
	{
		return false;
	}

	protected function onFileUploaded($sender, $param)
	{
		if ($sender->getHasFile())
   		{
			$tmpdir = realpath(Prado::getPathOfNamespace('Storage.temp'));
			
			if (!is_dir($tmpdir))
				mkdir($tmpdir, '0777', true);
			
			$uploadedFile = $tmpdir . $this->FileChooseField->getFileName();
			$this->setViewState('uploadedFile', $uploadedFile);
			$this->FileChooseField->saveAs($uploadedFile);
   		}
	}
	
	public function onImport($sender, $param)
	{
		ini_set("memory_limit", "700M");
		set_time_limit(0);
		
		$toShelf = $this->getShelf();
		$uploadedFile = $this->getViewState('uploadedFile');

		if ($uploadedFile == '')
		{
			$this->getPage()->writeMessage(Prado::localize('Errore sulla scelta del file di importazione'),
												ClavisMessage::ERROR);
			
			return false;
		}

		if ($this->SkipCreationCheck->getChecked())
		{
			$forceCreateOOCFlag = false;
		}
		elseif ($this->CreateOOCCheck->getChecked())
		{
			$forceCreateOOCFlag = true;
		}
		else	// fallback supersayan
		{
			$forceCreateOOCFlag = false;
		}

		$countDone = 0;
		$skippedEan = [];
		$countFailed = 0;
		$countCreatedOOC = 0;
		$toShelfIds = [];
		$countAddedShelf = 0;
		$csvOkFlag = true;
		
		$parsedCsv = ClavisBase::parseCsv($uploadedFile, ',', $this->getRequiredFields());

		if (isset($parsedCsv[0])
				&& ($parsedCsv[0] == ClavisBase::getParseCsvMissingLabel()))
		{
			$csvOkFlag = false;
			array_shift($parsedCsv);
		}
		else		
		{	
			foreach ($parsedCsv as $rowArray)
			{
				if (!is_array($rowArray) 
						|| (count($rowArray) == 0))
					continue;

				$manifestationId = 0;
				$ean = trim($rowArray['ean']);

				if ($ean != "")
				{
					$manifestation = ManifestationQuery::create()
													->filterByEan($ean)
													->findOne();
				}

				if (!$manifestation instanceof Manifestation)
				{
					if (!$forceCreateOOCFlag)
					{
						$skippedEan[] = $ean == '' ? 'no-ean' : $ean;

						continue;
					}
					else
					{
						$countCreatedOOC++;
					}
				}

				// we can go on creating a new item

				list ($newItemId, $itemExceptionCode) = $this->createItem($manifestation, $rowArray);

				if ($newItemId > 0)
				{
					$countDone++;			
					$toShelfIds[] = $newItemId;
				}	
				else
				{
					$countFailed++;
				}
			}
		}
		
		if (count($toShelfIds) > 0)
		{	
			$countAddedShelf = ShelfPeer::addItemToShelf(	$this->getShelf(),
															ShelfPeer::TYPE_ITEM,
															$toShelfIds);
		}
		
		$this->getPage()->cleanMessageQueue();
		
		if (!$csvOkFlag)
		{
			$this->getPage()->enqueueMessage(Prado::localize("Il file CSV per l'importazione non è stato formattato in maniera corretta. 
																I campi richiesti mancanti sono: {fields}",
																	array('fields' => implode(',', $parsedCsv))),
													ClavisMessage::ERROR);
		}
		
		if (($countDone == 0)
				&& (count($skippedEan) == 0)
				&& ($countFailed == 0)
				&& ($countCreatedOOC == 0))
		{
			$this->getPage()->enqueueMessage(Prado::localize("Nessuna azione eseguita"),
																ClavisMessage::INFO);
		}
		else
		{
			if ($countDone > 0)
			{	
				$this->getPage()->enqueueMessage(Prado::localize("{count} esemplari creati da CSV'",
																		array('count' => $countDone)),
													ClavisMessage::CONFIRM);
				
				if ($countAddedShelf > 0)
				{
					$this->getPage()->enqueueMessage(Prado::localize("{count} esemplari aggiunti nello scaffale '{shelfName}' (id: {shelfId})",
																		array(	'count' => $countAddedShelf,
																				'shelfId' => $toShelf->getShelfId(),
																				'shelfName' => $toShelf->getShelfName() )),
														ClavisMessage::CONFIRM);
				}
			}
			
			if (count($skippedEan) > 0)
			{	
				$this->getPage()->enqueueMessage(Prado::localize("{count} esemplari non creati perchè le notizie cercate con questi codici EAN non sono state trovate: {eanList}",
																	array(	'count' => count($skippedEan),
																			'eanList' => implode(',', $skippedEan) )),
													ClavisMessage::WARNING);
			}
			
			if ($countCreatedOOC > 0)
			{	
				$this->getPage()->enqueueMessage(Prado::localize("{count} esemplari creati come 'fuori catalogo' perchè le notizie cercate per codice EAN non sono state trovate",
																	array(	'count' => $countCreatedOOC)),
													ClavisMessage::CONFIRM);
			}
				
			if ($countFailed > 0)
			{	
				$this->getPage()->enqueueMessage(Prado::localize("{count} esemplari non creati a causa di errori",
																	array('count' => $countFailed)),
													ClavisMessage::ERROR);
			}
		}

		if ($countDone > 0)
		{
			$this->getPage()->flushDelayedMessage();
			$this->onClose();
		}
		else
		{
			$this->getPage()->flushMessage();
		}
	}

	private function createItem($manifestation = null, $rowArray = [])
	{
		$myLibraryId = $this->getUser()->getActualLibraryId();
		
		$newItemId = 0;
		$itemException = new Exception();
		
		$newItem = new Item();

		try
		{
			$libraryId = (int) $rowArray['library_id'];

			$newItem->setHomeLibraryId($libraryId);
			$newItem->setOwnerLibraryId($libraryId);
			$newItem->setActualLibraryId($libraryId);
			
			if ($libraryId == 0)
				$libraryId = $this->getUser()->getActualLibraryId();
			
			if ($manifestation instanceof Manifestation)
			{
				$newManifestationId = $manifestation->getManifestationId();
				$newTitle = $manifestation->getCompleteTitle();
				$manifestationDewey = $manifestation->getClass();
			}
			else
			{
				// we have an OOC (out of catatalog item)
				$newManifestationId = 0;
				$newTitle = $rowArray['title'];
				$manifestationDewey = null;
			}
						
			if ((string) $newTitle == '')
				$newTitle = '(' . Prado::localize('senza titolo') . ')';
			
			$newItem->setTitle($newTitle);
			$newItem->setManifestationDewey($manifestationDewey);
			$newItem->setManifestationId($newManifestationId);
			
			$inventorySerieId = (string) $rowArray['inventory_serie_id'];
			$inventorySerie = InventorySerieQuery::create()->findPk(array($inventorySerieId, $libraryId));

			if (!($inventorySerie instanceof InventorySerie)
					|| ($inventorySerieId == ''))
				$inventorySerieId = $this->createInventorySeries($inventorySerieId, $libraryId);
					
			$newItem->setInventorySerieId($inventorySerieId);		
					
			$inventoryNumber = $this->manageInventoryNumber(	$rowArray['inventory_number'], 
																$inventorySerieId, 
																$libraryId);
			
			$newItem->setInventoryNumber($inventoryNumber);

			$newItem->setCollocation(isset($rowArray['collocation']) ? $rowArray['collocation'] : '');
			$newItem->setBarcode(isset($rowArray['barcode']) ? $rowArray['barcode'] : '');
			
/////////////////////////
			$newItemStatus = (isset($rowArray['item_status']) ? $rowArray['item_status'] : '');
			$newLoanClass = (isset($rowArray['loan_class']) ? $rowArray['loan_class'] : '');
			
			if ((string) $newItemStatus == '')
				$newItemStatus = ItemStatusBase::ITEMSTATUS_ONSHELF;
			
			if ((string) $newLoanClass == '')
				$newLoanClass = ItemPeer::LOANCLASS_AVAILABLE;
			
			$newItem->setItemStatus($newItemStatus);
			$newItem->setLoanClass($newLoanClass);
			$newItem->setLoanStatus(ItemPeer::LOANSTATUS_AVAILABLE);
			
			$itemMedia = (isset($rowArray['item_media']) ? (string) $rowArray['item_media'] : '');
			
			if (($itemMedia == '')
					|| is_null($itemMedia))
				$itemMedia = 'F';
			
			$newItem->setItemMedia($itemMedia);
			
			$newItem->save();
			$newItemId = $newItem->getItemId();
		}
		catch (Exception $itemException)
		{
			//
		}
		
		return array($newItemId, $itemException->getCode());
	}
	
	// taken from importBmw.php script
	function createInventorySeries($newInventorySerieId = null, $libraryId = null)
	{
		$invSer = null;

		try
		{
			$invSer = new InventorySerie();

			$invSer->setInventorySerieId($newInventorySerieId)
							->setLibraryId($libraryId)
							->setDescription('new created by plugin')
							->setClosed(0)
							->setReadonly(0)
							->setInventoryCounter(0)
							->save();
		}
		catch (Exception $e)
		{
			////
		}
		
		return $invSer->getInventorySerieId();
	}
	
	function manageInventoryNumber($inventoryNumber, $inventorySerieId = null, $libraryId = 0)
	{
		if ((int) $inventorySerieId > 0)
		{	
			$invSerFound = InventorySerieQuery::create()->findPk(array($inventorySerieId, $libraryId));

			if ($invSerFound instanceof InventorySerie)
			{
				$existingInventoryNumber = $invSerFound->getInventoryCounter();
				
				if ($inventoryNumber <= $existingInventoryNumber)
					$inventoryNumber = $existingInventoryNumber + 1;

				$invSerFound->setInventoryCounter($inventoryNumber);
				
				$invSerFound->save();
			}
			else
			{
				///
			}
		}

		return $inventoryNumber;
	}
}