<?php

/**
 * ShelfContentMove class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2014 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package ShelfPlugins
 */

/**
 * ShelfContentMove Class
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.7
 * @package ShelfPlugins
 * @since 2.4
 */
class ShelfContentMove extends ClavisPlugin
{
	public function onInit($param)
	{
		parent::onInit($param);
	
		if (count($this->ObjectFilter->getDataSource()) == 0)
		{
			$datasource = LookupValuePeer::getLookupClassValues('SHELFITEMTYPE', true, null, null, true);
			$this->ObjectFilter->setDataSource($datasource);
			$this->ObjectFilter->dataBind();
		}
	}

	public function onResetShelf($sender, $param)
	{
		$this->doResetShelf($param);
	}

	private function doResetShelf($param = null)
	{
		$this->ShelfName->setText("");
		$this->ShelfId->setValue('');
		
		$this->renderShelfPanel($param);
	}
	
	public function onResetLimit($sender, $param)
	{
		$this->LimitFilter->setText('');
	}
	
	public function renderShelfPanel($param = null)
	{
		if (is_null($param))
		{
			$writer = $this->createWriter();
		}
		else
		{
			$writer = $param->getNewWriter();
		}

		$this->ShelfPanel->render($writer);
	}
	
	public function onMove($sender, $param)
	{
		$this->getPage()->cleanMessageQueue();
		
		ini_set("memory_limit", "700M");
		set_time_limit(0);
		
		$destShelfId = intval($this->ShelfId->getValue());
		$destShelf = ShelfQuery::create()->findPk($destShelfId);
		
		if ($destShelf instanceof Shelf)
			$destShelfName = $destShelf->getShelfName();
		else
		{
			$destShelfId = 0;
			$destShelfName = "(" . Prado::localize("scaffale senza nome") . ")";
		}		
		
		$shelfItems = $this->getCheckedItems();
		$initialCount = count($shelfItems);
		
		$limit = intval($this->LimitFilter->getSafeText());
		
		if ($limit > 0)
			$shelfItems = array_slice($shelfItems, 0, $limit);
		
		$countDone = 0;
		$countFailed = 0;
		///$duplicatedString = '';
		///$deletionErrorCount = 0;

		if ((count($shelfItems) > 0)
				&& ($destShelfId > 0))
		{
			$objectFilter = $this->ObjectFilter->getSelectedValue();
			
			if ($objectFilter == "0")
				$objectFilter = null;
//				
//			if (is_null($objectFilter))
//				$objectFilter = "0";

//			foreach ($shelfItems as $shelfItem)
//			{
//				if (!is_null($shelfItem))
//				{
//					$objectClass = $shelfItem->getObjectClass();
//					if (($objectFilter == $objectClass)
//							|| ($objectFilter == "0"))
//					{
//						$done = ShelfPeer::addItemToShelf(	$destShelfId,
//															$objectClass,
//															$shelfItem->getObjectId());
//						if ($done)
//						{
//							$countDone += $done;
//							
//							try
//							{
//								$shelfItem->delete();
//							}
//							catch (Exception $ex)
//							{
//								$deletionErrorCount++;
//							}
//						}
//						else
//							$countFailed++;
//					}
//				}
//			}
			
			$countDone = $this->moveItems($shelfItems, $destShelfId, $objectFilter);
			$countFailed = count($shelfItems) - $countDone;
		}

//		$errorCode = ClavisMessage::ERROR;
//		
//		if (($countDone == 0)
//				&& ($countFailed == 0)
//				&& ($duplicatedString == ''))
//			$errorCode = ClavisMessage::INFO;
//		else
//		{
//			if (($countFailed > 0)
//					|| ($duplicatedString != '') 
//					|| ($deletionErrorCount > 0))
//				$errorCode = ClavisMessage::WARNING;
//			else
//				$errorCode = ClavisMessage::CONFIRM;
//		}

		if (($countDone == 0)
				&& ($countFailed == 0))
		{
			$this->getPage()->enqueueMessage(Prado::localize('Nessuna azione eseguita'),
												ClavisMessage::INFO);
		}
		
//		if (strlen($duplicatedString) > 0)
//			$duplicatedString = rtrim($duplicatedString, ', ');

		if ($countDone > 0)
		{	
			$this->getPage()->enqueueMessage(Prado::localize("{count} oggetti spostati nello scaffale '{shelfName}' (id={shelfId})",
																array(	'count' => $countDone,
																		'shelfName' => $destShelfName,
																		'shelfId' => $destShelfId )),
												ClavisMessage::CONFIRM);
		}
		
		if ($countFailed > 0)
		{
			$this->getPage()->enqueueMessage(Prado::localize("{count} oggetti NON spostati nello scaffale '{shelfName}' (id={shelfId})",
																array(	'count' => $countFailed,
																		'shelfName' => $destShelfName,
																		'shelfId' => $destShelfId )),
												ClavisMessage::ERROR);
		}
		
//		if ($deletionErrorCount > 0)
//		{	
//			if ($messageText != '')
//				$messageText .= '&nbsp;&nbsp;&nbsp;&nbsp;<br /><br />';
//			
//			$messageText .= $deletionErrorCount == 1
//										? Prado::localize('un oggetto NON cancellato dallo scaffale di origine')
//										: Prado::localize('{count} oggetti NON cancellati dallo scaffale di origine',
//															array('count' => $deletionErrorCount));
//		}
		
//		if ($duplicatedString != '')
//			$messageText .= ($messageText != '' ? '&nbsp;&nbsp;&nbsp;&nbsp;<br /><br />' : '')
//								. Prado::localize('Oggetti non spostati perché già presenti nello scaffale, con id: ({duplicatedString})',
//													array('duplicatedString' => $duplicatedString));

		if ($initialCount > $countDone)
		{
			$this->getPage()->flushMessage();
			
			if ($countDone > 0)
				$this->getPage()->shelfListRefresh($param);
		}
		else
		{
			$this->getPage()->flushDelayedMessage();
			$this->onClose();
		}
	}

}