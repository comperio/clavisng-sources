<?php
/**
 * ShelfConvertToPurchaseProposal class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package ShelfPlugins
 */

/**
 * ShelfConvertToPurchaseProposal Class
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.7
 * @package ShelfPlugins
 * @since 2.4
 */
class ShelfConvertToPurchaseProposal extends ClavisPlugin
{
	public static function getTargetShelfTypes()
	{
		return array(	ShelfPeer::TYPE_ITEM,
						ShelfPeer::TYPE_MANIFESTATION );
	}
	
	public static function getEditMode()
	{
		return ShelfPeer::EDITTYPE_EDIT;
	}
	
	public function onAction($sender, $param)
	{
		$shelfItems = $this->getCheckedItems();

		$countModified = 0;
		$countDeleted = 0;
		$countFailed = 0;

		if ((count($shelfItems) > 0))
		{
			ini_set("memory_limit", "700M");
			set_time_limit(0);
		
			foreach ($shelfItems as $shelfItem)
			{
				if ($shelfItem instanceof ShelfItem)
				{
					try
					{
						switch ($shelfItem->getObjectClass())
						{
							case ShelfPeer::TYPE_MANIFESTATION_BUY:
							// do nothing
						
							break;
							
							case ShelfPeer::TYPE_MANIFESTATION:
								$new = $shelfItem->copy();
								$new->setObjectClass(ShelfPeer::TYPE_MANIFESTATION_BUY);
								$shelfItem->delete();
								$new->save();
								$countModified++;
							
								break;

							case ShelfPeer::TYPE_ITEM:
								$manifestation = null;
								$item = ItemQuery::create()
											->findPk($shelfItem->getObjectId());
								
								if ($item instanceof Item)
								{
									$manifestationId = intval($item->getManifestationId());
									if ($manifestationId > 0)
										$manifestation = ManifestationQuery::create()
															->findPk($manifestationId);
								}
									
								if ($manifestation instanceof Manifestation)
								{
									$new = $shelfItem->copy();
									$new->setObjectClass(ShelfPeer::TYPE_MANIFESTATION_BUY);
									$new->setObjectId($manifestation->getManifestationId());
									$shelfItem->delete();
									$new->save();
									$countModified++;
								}
								else  // invalid manifestation linked to this item
								{
									$shelfItem->delete();
									$countDeleted++;
								}
								
								break;

							default:

								$shelfItem->delete();
								$countDeleted++;

								break;
						}
					}
					catch (PropelException $exception)
					{
						$countFailed++;
					}
				}
			}
		}

		$messageText = "";

		if ($countModified > 0)
		{
			$messageText .= ($countModified == 1)
										? Prado::localize("1 oggetto notizia modificato in proposta d'acquisto")
										: Prado::localize("{count} oggetti notizie modificati in proposte d'acquisto",
																array('count' => $countModified));
			
			$errorCode = ClavisMessage::CONFIRM;
		}
		
		if ($countDeleted > 0)
		{
			if ($messageText)
				$messageText .= ($messageText != '' ? '&nbsp;&nbsp;&nbsp;&nbsp;<br /><br />' : '');
			
			$messageText .= ($countDeleted == 1)
										? Prado::localize("1 oggetto [non notizia] rimosso")
										: Prado::localize("{count} oggetti [non notizie] rimossi",
																array('count' => $countDeleted));
			
			$errorCode = ClavisMessage::INFO;					
		}
		
		if ($countFailed > 0)
		{
			if ($messageText)
				$messageText .= ($messageText != '' ? '&nbsp;&nbsp;&nbsp;&nbsp;<br /><br />' : '');
			
			$messageText .= ($countFailed == 1)
										? Prado::localize("1 oggetto con errore")
										: Prado::localize("{count} oggetti con errore",
																array('count'=>$countFailed));
			
			$errorCode =  ClavisMessage::WARNING;
		}
		
		if ($messageText == "")
		{
			$messageText = Prado::localize("Nessuna azione è stata eseguita");
			$errorCode = ClavisMessage::INFO;
		}
			
		if (($countModified * $countDeleted) > 0)
			$this->getPage()->shelfListRefresh($param);

		$this->getPage()->writeDelayedMessage($messageText, $errorCode);
		$this->onClose();
	}

}