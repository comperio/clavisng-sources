<?php
/**
 * ShelfManifestationUnlink class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.8.7
 * @package ShelfPlugins
 */

/**
 * ShelfManifestationUnlink Class
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.8.7
 * @package ShelfPlugins
 * @since 2.8.7
 */

class ShelfManifestationUnlink extends ClavisPlugin
{
	const MANIFESTATIONS_LIMIT = 10000;
	const ANALYZE_LIMIT = 500;
	
	private $_clavisLibrarian;
	private $_datasourceSessionName;

	public static function getTargetShelfTypes()
	{
		return array(ShelfPeer::TYPE_MANIFESTATION);
	}
	
	public static function getEditMode()
	{
		return ShelfPeer::EDITTYPE_EDIT;
	}
	
	private function initVars()
	{
		$this->_clavisLibrarian = $this->getUser();
		
		$uniqueId = $this->getUniqueID();
		$this->_datasourceSessionName = "SavedDatasourceSessionName" . $uniqueId;
	}

	public function onInit($param)
	{
		parent::onInit($param);
		$this->initVars();

		// first cycle
		if (!$this->getPage()->getIsCallBack()
				&& (!$this->getIsAnalyzed()))
		{
			$this->setSavedDataSource([]);		// for resetting, at first enter in the plugin
			
			$this->setLinkTypeValues(LookupValuePeer::getLookupClassValues(	'LINKTYPE',
																			true,
																			'---' ));
			
			$this->setRelatorCodeValues(LookupValuePeer::getLookupClassValues(	'RELATORCODE',
																				true,
																				'---' ));

			$this->LinkType->setDataSource($this->getLinkTypeValues());
			$this->LinkType->dataBind();
			 
			$this->RelatorCode->setDataSource($this->getRelatorCodeValues());
			$this->RelatorCode->dataBind();
			
			$this->setMasterChecked(false);
			
			// check if too many manifestations checked
			$checkedManifestationCount = 0;
			
			foreach ($this->getCheckedItems() as $shelfItem)
			{
				if (($shelfItem instanceof ShelfItem)
						&& ($shelfItem->getObjectClass() == ShelfPeer::TYPE_MANIFESTATION))	// only manifestations
					$checkedManifestationCount++;
			}

			if ($checkedManifestationCount >= self::MANIFESTATIONS_LIMIT)
			{
				$this->AnalyzePanel->setStyle("display: none;");	// too many manifestations
				$this->TooManyManifestationPanel->setStyle("display: block;");
			}
			else
			{	
				$this->AnalyzePanel->setStyle("display: block;");	// show analyze part in the beginning
				$this->TooManyManifestationPanel->setStyle("display: none;");
			}
			
//			$this->UnlinkButton->setStyle("display: none");	// hide the main action button
//			$this->ShelfPanel->setStyle("display: none");
			$this->ActionPanel->setStyle("display: none");
			$this->ModifyButton->setEnabled(false);
		}
	}

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsCallBack())
		{
			if ($this->getIsAnalyzed())
			{		
				// reset
				$this->writeAnalyzedDataSource();
				$this->drawLinkTypesList(null, true);
				$this->ActionPanel->setStyle('display: none');
				$this->ModifyButton->setEnabled(false);

				if (!$this->getIsAnalyzed())
					$this->setIsAnalyzed(true);
			}
			else
			{
				$calculatedAllLinkTypes = $this->calculateAllLinkTypes();
				$this->drawLinkTypesList($calculatedAllLinkTypes, true);
				$this->setStoredLinkTypes($calculatedAllLinkTypes);
			}
		}
	}

	public function onPreRender($param)
	{
		parent::onPreRender($param);
		
		// first cycle
		if (!$this->getPage()->getIsCallBack())
		{
			$this->getPage()->setFocus("anchor_analyze");
		}
	}
	
	public function getSavedDataSource()
	{
		return $this->getControlState($this->_datasourceSessionName, []);
	}

	public function setSavedDataSource($ds)
	{
		$this->setControlState($this->_datasourceSessionName, $ds, []);
	}
	
	public function getAnalyzeLimit()
	{
		return (int) self::ANALYZE_LIMIT;
	}
	
	public function getManifestationsLimit()
	{
		return self::MANIFESTATIONS_LIMIT;
	}
	
	public function setIsAnalyzed($param)
	{
		$this->setControlState('IsAnalyzed', ($param ? 1 : 0), 0);
	}
	
	public function getIsAnalyzed()
	{
		return ($this->getControlState('IsAnalyzed', 0) == 1 ? true : false);
	}
	
	public function setIsItemValid($valid = false)
	{
		$this->getApplication()->getSession()->add('IsItemValid', $valid, false);
	}

	public function getIsItemValid()
	{
		return $this->getApplication()->getSession()->itemAt('IsItemValid', false);
	}

	private function setStoredLinkTypes($param)
	{
		$this->setControlState('StoredLinkTypes', $param, array());
	}

	private function getStoredLinkTypes()
	{
		return $this->getControlState('StoredLinkTypes', array());
	}

	private function setLinkTypeValues($param)
	{
		$this->setControlState('LinkTypesValues', $param, array());
	}

	private function getLinkTypeValues()
	{
		return $this->getControlState('LinkTypesValues', array());
	}
	
	private function setRelatorCodeValues($param)
	{
		$this->setControlState('RelatorCodeValues', $param, array());
	}

	private function getRelatorCodeValues()
	{
		return $this->getControlState('RelatorCodeValues', array());
	}
	
	public function IsPopup()
	{
		return true;
	}
				
	private function drawLinkTypesList($linkTypes = array(), $resetFlag = false)
	{
		$selected = $this->readLinkTypesSelected();
		
//		if ($resetFlag)
//		{
		$this->LinkTypesList->getItems()->clear();
//		}
		
		if (count($linkTypes) > 0)
		{
			$this->LinkTypesPanel->setVisible(true);

			foreach ($linkTypes as $value => $text)
			{
				$item = new TListItem();
				$item->setText($text);
				$item->setValue($value);

				if ($resetFlag)
				{
					$item->setSelected(false);
				}
				else
				{
					$item->setSelected(array_key_exists($value, $selected));
				}
				
				$this->LinkTypesList->getItems()->add($item);
			}
		}
		else
		{
			$this->LinkTypesPanel->setVisible(false);
		}
		
		if ($this->getPage()->getIsCallback())
				//&& $resetFlag)
			$this->renderLinkTypesPanel($param);
	}
	
	private function readLinkTypesSelected()
	{
		$resultArray = array();
		$items = $this->LinkTypesList->getItems();

		foreach ($items as $index => $item)
		{
			if ($item->getSelected())
				$resultArray[$item->getValue()] = $item->getText();
		}

		return $resultArray;
	}
	
	public function onAnalyze($sender, $param)
	{
		$this->setMasterChecked(false);		// maybe it's better to reset checks when recalculating
		$this->doAnalyze();
	}
	
	private function doAnalyze($ignoreFilters = false)
	{
		ini_set("memory_limit", "700M");
		set_time_limit(0);

		$forceAllCheck = $this->getMasterChecked();

		$dataSource = [];
		$manifestationIds = [];
		$linkTypesResulted = [];

		foreach ($this->getCheckedItems() as $shelfItem)
		{
			if (($shelfItem instanceof ShelfItem)
					&& ($shelfItem->getObjectClass() == ShelfPeer::TYPE_MANIFESTATION))	// only manifestations
			{
				$manifestation = null;
				$manifestationId = $shelfItem->getObjectId();

				if ($manifestationId > 0)
					$manifestation = ManifestationQuery::create()->findPk($manifestationId);

				if (($manifestation instanceof Manifestation)
						&& ($this->_clavisLibrarian->getEditPermission($manifestation)))
					$manifestationIds[] = $manifestationId;
			}
		}

		$manifestationIdString = implode(",", $manifestationIds);
		
		if ($manifestationIdString != "")
		{
			$linkTypesSelected = ($ignoreFilters 
									? []
									: $this->readLinkTypesSelected());
			
			$linkTypesSelected = $this->readLinkTypesSelected();

			$linkTypesQuery = (count($linkTypesSelected) > 0 
									? ' AND link_type IN (' . implode(',', array_keys($linkTypesSelected)) . ') '
									: '');
			
			$connection = Propel::getConnection();
            $connection->exec("SET SESSION group_concat_max_len = 1000000");

//          $statement = $connection->prepare("SELECT concat_ws('%%', lam.authority_id, a.full_text, a.authority_type, lam.link_type, lam.relator_code, group_concat(lam.manifestation_id))
			$statement = $connection->prepare("SELECT lam.authority_id, a.full_text, a.authority_type, lam.link_type, lam.relator_code, group_concat(lam.manifestation_id)
													FROM l_authority_manifestation lam
													INNER JOIN authority a ON lam.authority_id = a.authority_id
													WHERE manifestation_id IN ($manifestationIdString) $linkTypesQuery
													GROUP BY lam.authority_id, lam.link_type, lam.relator_code
													ORDER BY lam.link_type, lam.relator_code, a.full_text"
													. ($this->getAnalyzeLimit() > 0 ? " LIMIT " . $this->getAnalyzeLimit() : ""));
			
			$statement->execute();

			while ($row = $statement->fetch(PDO::FETCH_NUM))
			{
				if (array_key_exists(0, $row))
				{		
					//list ($authorityId, $authorityTitle, $authorityType, $linkType, $relatorCode, $manifestationsRaw) = explode("%%", $row[0]);
					$authorityId = $row[0];
					$authorityTitle = $row[1];
					$authorityType = $row[2];
					$linkType = $row[3];
					$relatorCode = $row[4];
					$manifestationsRaw = $row[5];
					
					$manifestationIdsResult = explode(",", $manifestationsRaw);
					
					$keyIdArray = array(	'authorityId' => $authorityId, 
											'manifestationsIds' => $manifestationIdsResult, 
											'linkType' => $linkType, 
											'relatorCode' => $relatorCode );

					$manNavigateUrl = "";
					
					foreach ($manifestationIdsResult as $manId)
					{
						$manUrl = ManifestationPeer::getNavigateUrl($manId);
						$manTitle = ManifestationPeer::getTitle($manId);
						
						$manNavigateUrl .= "<a target='_blank' href='$manUrl'>$manTitle</a><br /><br />";
					}
					
					//$authorityTitle = mb_substr($authorityTitle, 0 ,40 ,'UTF-8');
					$linkTypeString = LookupValuePeer::getLookupValue('LINKTYPE', $linkType);

					///if (!$ignoreFilters)
					$linkTypesResulted[$linkType] = $linkTypeString;
					
					$relatorCodeString = LookupValuePeer::getLookupValue('RELATORCODE', $relatorCode);

					
					$dataSource[] = array(	'title' => $authorityTitle,
											'titleUrl' => AuthorityPeer::getNavigateUrl($authorityId),
											'authorityType' => $authorityType,
											'linkTypeRelatorCode' => $linkTypeString . ($relatorCodeString != '' ? ' / ' . $relatorCodeString : ''),
	//. " ->" . $manifestationsRaw,
											//'manCount' => "[" . count($manifestationIdsResult) . "&nbsp;" . Prado::localize("notizie") . "]",
											'manCount' => count($manifestationIdsResult),
											'olText' => $manNavigateUrl,
											'value' => serialize($keyIdArray),
											'checked' => $forceAllCheck,
											'authorityId' => $authorityId );	// temp mbrancalion, probabilmente da levare
				}
			}	
		}

		$this->setSavedDataSource($dataSource);		// store the datasource, for masterchecking without recalculating
		$this->writeAnalyzedDataSource($dataSource);
		
		$this->onMasterChecked(null, null);		// autoselects all found rows
		
		/** maybe we don't want to treat filter checks here anymore
		if (!$ignoreFilters)
		{
			// type filters part
			if (count($linkTypesResulted) == 0)
			{
				$this->drawLinkTypesList($this->getStoredLinkTypes(), true);
			}
			else
			{
				$this->drawLinkTypesList($linkTypesResulted);
				$this->setStoredLinkTypes($linkTypesResulted);
			}
		}
		 */
		
		$this->getPage()->setFocus($this->FocusEnd->getClientID());
		$this->getPage()->setFocus($this->FocusStart->getClientID());

		$this->setIsAnalyzed(true);
		
		return $linkTypesResulted;
	}
	
	private function writeAnalyzedDataSource($dataSource = array())
	{
		$this->FoundLinks->setDataSource($dataSource);
		$this->FoundLinks->dataBind();

		// population of dropdownlists for editing authorities
		/*
		if (count($dataSource) > 0)
		{
			 $this->LinkType->setDataSource($this->getLinkTypeValues());
			 $this->LinkType->dataBind();
			 
			 $this->RelatorCode->setDataSource($this->getRelatorCodeValues());
			 $this->RelatorCode->dataBind();
		}
		 * 
		 */
		
		$this->FoundNumber->setText(count($dataSource));
		
		if ($this->getPage()->getIsCallback())
		{
			$this->ActionPanel->setStyle("display: " . (count($dataSource) > 0 ? "inline" : "none"));
			$this->ActionPanel->render($this->createWriter());
			
			$this->ModifyButton->setEnabled(($this->LinkType->getSelectedValue() != '0')
												|| ($this->RelatorCode->getSelectedValue() != '0') ? true : false);

			
			if ($this->getPage()->getIsCallback())
			{
				$this->ModifyButton->render($this->createWriter());
			
				$this->FoundPanel->render($this->createWriter());
			}
		}
//		elseif ($this->getPage()->getIsPostback())
//		{
//			$this->ActionPanel->setVisible(count($dataSource) > 0 ? true : false);
//		}
	}
	
	private function readLinkList()
	{
		$lAuthoritieManifestationArray = array();
		
		foreach ($this->FoundLinks->getItems() as $row)
		{
			if ($row->Cells[0]->Checked->getChecked())
			{
				$valueRaw = $row->Cells[0]->Value->getValue();

				if ($valueRaw != "")
					$lAuthoritieManifestationArray[] = array(	unserialize($valueRaw),
																$row->Cells[0]->TitleString->getValue() );
			}
		}	
			
		return $lAuthoritieManifestationArray;
	}
	
	private function calculateAllLinkTypes()
	{
		$manifestationIds = array();
		$linkTypesToDisplay = array();

		foreach ($this->getCheckedItems() as $shelfItem)
		{
			if (($shelfItem instanceof ShelfItem)
					&& ($shelfItem->getObjectClass() == ShelfPeer::TYPE_MANIFESTATION))	// only manifestations
			{
				$manifestation = null;
				$manifestationId = $shelfItem->getObjectId();

				if ($manifestationId > 0)
					$manifestation = ManifestationQuery::create()->findPk($manifestationId);

				if (($manifestation instanceof Manifestation)
						&& ($this->_clavisLibrarian->getEditPermission($manifestation)))
					$manifestationIds[] = $manifestationId;
			}
		}

		$manifestationIdString = implode(",", $manifestationIds);
		
		if ($manifestationIdString != "")
		{
			$linkTypesSelected = ($skipFiltersFlag 
										? []
										: $this->readLinkTypesSelected());

			$linkTypesQuery = (count($linkTypesSelected) > 0 
									? ' AND link_type IN (' . implode(',', array_keys($linkTypesSelected)) . ') '
									: '');
								
			$connection = Propel::getConnection();

			$statement = $connection->prepare("SELECT `link_type` FROM `l_authority_manifestation` lam 
												INNER JOIN authority a ON lam.authority_id = a.authority_id 
												WHERE `manifestation_id` IN ($manifestationIdString) GROUP BY `link_type` ORDER BY `link_type`");

			$statement->execute();
			
			while ($row = $statement->fetch(PDO::FETCH_NUM))
			{
				if (array_key_exists(0, $row))
				{		
					$linkType = $row[0];
					$linkTypeString = LookupValuePeer::getLookupValue('LINKTYPE', $linkType);
					$linkTypesToDisplay[$linkType] = $linkTypeString;
				}
			}	
		}

		return $linkTypesToDisplay;
	}
	
	public function onUnlink($sender, $param)
	{
		ini_set("memory_limit", "700M");
		set_time_limit(0);
		$this->getPage()->cleanMessageQueue();

		$lAuthorityManifestationArray = $this->readLinkList();

		if (count($lAuthorityManifestationArray) > 0)
		{
			$lAM = array();
			$destShelfId = intval($this->ShelfId->getValue());

			foreach ($lAuthorityManifestationArray as $linkRaw)
			{
				$linkArray = $linkRaw[0];

				foreach($linkArray['manifestationsIds'] as $manId)
				{
					$paramLAM = array(	$linkArray['authorityId'],
										$manId,
										$linkArray['linkType'],
										$linkArray['relatorCode'] );
					
					$lAM[] = array(	'lAM' => LAuthorityManifestationQuery::create()
												->findPk($paramLAM),
						
									'paramString' => implode(',', $paramLAM),
									'title' => $linkRaw[1] );
				}
			}

			$arrayDone = array();
			$countFailed = 0;
			$toMoveManArray = array();
			
			foreach ($lAM as $lAuthorityManifestationCombo)
			{
				$lAuthorityManifestation = $lAuthorityManifestationCombo['lAM'];
			
				if ($lAuthorityManifestation instanceof LAuthorityManifestation)
				{
					$returnCode = $this->doUnlink($lAuthorityManifestation);

					switch ($returnCode)
					{
						case true:
							$arrayDone[$lAuthorityManifestationCombo['title']] = true;
							
							break;

						case false:
						default:
							$countFailed++;

							break;
					}
					
					// move to shelf in any case
					$toMoveManArray[] = $lAuthorityManifestation->getManifestationId();
					
					unset ($lAuthorityManifestation);
				}
				else
				{
					$this->getPage()->enqueueMessage(Prado::localize("Il legame authority-notizia con chiave={id} non esiste",
																		array('id' => $lAuthorityManifestationCombo['paramString'])),
														ClavisMessage::ERROR);
				}
			}

			if ((count($arrayDone) == 0)
					&& ($countFailed == 0))
			{
				$this->getPage()->enqueueMessage(Prado::localize("Nessuna azione eseguita"),
													ClavisMessage::INFO);
			}
			else
			{
				if (count($arrayDone) > 0)
				{
					/*
					 * Formerly we chose to successfully remove all the manifestations
					 * in the shelf when all linked authorities from that manifestation are removed.
					 * 
					 * Now we're moving manifestations away from the shelf whenever we wanted to
					 * remove a manifestation_authority link even if this action resulted as failed.
					 * The result of the intended action is not important: we're moving the shelfitem away. 
					 */
					//$toMoveManIdArray = array();
					//foreach (array_diff(array_unique($allManArray), array_unique($toKeepManArray)) as $toMoveManId)
					//$toMoveManIdArray[] = ShelfItemPeer::calculatePackedPK($this->getShelfId(), $toMoveManId, ShelfPeer::TYPE_MANIFESTATION);
					
					//$returnMoveValue = $this->moveItems($toMoveManIdArray, $destShelfId);

					// if a destination shelf is chosen, we'll move shelfitems
					if ($destShelfId > 0)
					{
						$returnMoveValue = $this->moveItems($this->convertManIdToShelfObject($toMoveManArray), $destShelfId,null);
					
						if ($returnMoveValue > 0)
							$this->getPage()->enqueueMessage(Prado::localize("Spostate {count} notizie dello scaffale '{shelfName}' (id={shelfId}) allo scaffale '{destShelfName}' (id={destShelfId})",
																				array(	'count' => $returnMoveValue,

																						'shelfName' => $this->getShelf()->getShelfName(),
																						'shelfId' => $this->getShelf()->getShelfId(),

																						'destShelfName' => ShelfPeer::getShelfName($destShelfId),
																						'destShelfId' => $destShelfId )),
																ClavisMessage::CONFIRM);
					}
					
					$this->getPage()->enqueueMessage(Prado::localize("Un totale di {count} authority sono state scollegate da notizie dello scaffale '{shelfName}' (id={shelfId}). Le voci di authority sono le seguenti: {rawDataAll}",
																		array(	'count' => count($arrayDone),
																				'shelfName' => $this->getShelf()->getShelfName(),
																				'shelfId' => $this->getShelf()->getShelfId(),
																				'rawDataAll' => "«" . implode("», «", array_keys($arrayDone)) . "»" )),
														ClavisMessage::CONFIRM);
				}	

				if ($countFailed > 0)
				{
					$this->getPage()->enqueueMessage(Prado::localize("{count} authority non sono state scollegate da notizie a causa di errori",
																		array('count' => $countFailed)),
														ClavisMessage::ERROR);
				}
				
				$this->getPage()->enqueueMessage(Prado::localize("Viene rieseguita l'analisi dei legami"),
													ClavisMessage::CONFIRM);
				
				$this->doAnalyze(true);	// we want to skip redrawing linkTypes here
				
				///// reset of linktypes for new calculation
				$calculatedAllLinkTypes = $this->calculateAllLinkTypes();
				$this->drawLinkTypesList($calculatedAllLinkTypes);   //, true);
				$this->setStoredLinkTypes($calculatedAllLinkTypes);
			}
		}
		else
		{
			$this->getPage()->enqueueMessage(Prado::localize("Non sono state selezionate authority da scollegare"),
												ClavisMessage::INFO);
		}
		
		$this->getPage()->flushMessage();
	}
	
	public function OnModifyChanged($sender, $param)
	{
		$this->ModifyButton->setEnabled(($this->LinkType->getSelectedValue() != '0')
											|| ($this->RelatorCode->getSelectedValue() != '0') ? true : false);
		
		if ($this->getPage()->getIsCallback())
			$this->ModifyButton->render($this->createWriter());
	}
	
	public function onModify($sender, $param)
	{
		$linkType = $this->LinkType->getSelectedValue();
		$relatorCode = $this->RelatorCode->getSelectedValue();

		if ($linkType == '0')
			$linkType = null;
		
		if ($relatorCode == '0')
			$relatorCode = null;

		if (is_null($linkType)
				&& is_null($relatorCode))
		{
			$this->ModifyButton->setEnabled(false);
			$this->ModifyButton->render($this->createWriter());
			
			return false;
		}
			
		ini_set("memory_limit", "700M");
		set_time_limit(0);
		$this->getPage()->cleanMessageQueue();

		$lAuthorityManifestationArray = $this->readLinkList();

		if (count($lAuthorityManifestationArray) > 0)
		{
			$lAM = array();

			foreach ($lAuthorityManifestationArray as $linkRaw)
			{
				$linkArray = $linkRaw[0];

				foreach($linkArray['manifestationsIds'] as $manId)
				{
					$paramLAM = array(	$linkArray['authorityId'],
										$manId,
										$linkArray['linkType'],
										$linkArray['relatorCode'] );
					
					$lAM[] = array(	'lAM' => LAuthorityManifestationQuery::create()->findPk($paramLAM),
									'paramString' => implode(',', $paramLAM),
									'title' => $linkRaw[1] );
				}
			}

			$arrayDone = array();
			$countFailed = 0;
			$toMoveManArray = array();						//// DA VALUTARE
			
			foreach ($lAM as $lAuthorityManifestationCombo)
			{
				$lAuthorityManifestation = $lAuthorityManifestationCombo['lAM'];
			
				if ($lAuthorityManifestation instanceof LAuthorityManifestation)
				{
					$returnCode = $this->doModify(	$lAuthorityManifestation,
													$linkType,
													$relatorCode);

					switch ($returnCode)
					{
						case true:
							$arrayDone[$lAuthorityManifestationCombo['title']] = true;
							
							break;

						case false:
						default:
							$countFailed++;

							break;
					}
					
					// move to shelf in any case
					$toMoveManArray[] = $lAuthorityManifestation->getManifestationId();    // DA VALUTARE SE TENERLA
					
					unset ($lAuthorityManifestation);
				}
				else
				{
					$this->getPage()->enqueueMessage(Prado::localize("Il legame authority-notizia con chiave={id} non esiste",
																		array('id' => $lAuthorityManifestationCombo['paramString'])),
														ClavisMessage::ERROR);
				}
			}

			if ((count($arrayDone) == 0)
					&& ($countFailed == 0))
			{
				$this->getPage()->enqueueMessage(Prado::localize("Nessuna azione eseguita"),
													ClavisMessage::INFO);
			}
			else
			{
				if (count($arrayDone) > 0)
				{
					/*
					 * Formerly we chose to successfully remove all the manifestations
					 * in the shelf when all linked authorities from that manifestation are removed.
					 * 
					 * Now we're moving manifestations away from the shelf whenever we wanted to
					 * remove a manifestation_authority link even if this action resulted as failed.
					 * The result of the intended action is not important: we're moving the shelfitem away. 
					 */
					//$toMoveManIdArray = array();
					//foreach (array_diff(array_unique($allManArray), array_unique($toKeepManArray)) as $toMoveManId)
					//$toMoveManIdArray[] = ShelfItemPeer::calculatePackedPK($this->getShelfId(), $toMoveManId, ShelfPeer::TYPE_MANIFESTATION);
					
					//$returnMoveValue = $this->moveItems($toMoveManIdArray, $destShelfId);
					
					$this->getPage()->enqueueMessage(Prado::localize("Un totale di {count} authority sono state modificate, da notizie dello scaffale '{shelfName}' (id={shelfId}). Le voci di authority sono le seguenti: {rawDataAll}",
																		array(	'count' => count($arrayDone),
																				'shelfName' => $this->getShelf()->getShelfName(),
																				'shelfId' => $this->getShelf()->getShelfId(),
																				'rawDataAll' => "«" . implode("», «", array_keys($arrayDone)) . "»" )),
														ClavisMessage::CONFIRM);
				}	

				if ($countFailed > 0)
				{
					$this->getPage()->enqueueMessage(Prado::localize("{count} authority non sono state modificate a causa di errori",
																		array('count' => $countFailed)),
														ClavisMessage::ERROR);
				}
				
				$this->getPage()->enqueueMessage(Prado::localize("Viene rieseguita l'analisi dei legami"),
													ClavisMessage::CONFIRM);
				
				$this->doAnalyze(true);	// we want to skip redrawing linkTypes here
				
				///// reset of linktypes for new calculation
				$calculatedAllLinkTypes = $this->calculateAllLinkTypes();
				$this->drawLinkTypesList($calculatedAllLinkTypes);   //, true);
				$this->setStoredLinkTypes($calculatedAllLinkTypes);
			}
		}
		else
		{
			$this->getPage()->enqueueMessage(Prado::localize("Non sono state selezionate authority da modificare"),
												ClavisMessage::INFO);
		}
		
		$this->getPage()->flushMessage();
	}
	
	private function convertManIdToShelfObject($manIds = array())
	{
		$shelfObjects = array();
		$manIds = array_unique($manIds);
		
		foreach ($manIds as $manifestationId)
			$shelfObjects[] = ShelfItemPeer::calculatePackedPK($this->getShelfId(), $manifestationId, ShelfPeer::TYPE_MANIFESTATION);
		
		return $shelfObjects;
	}
			
	public function setMasterChecked($flag = false)
	{
		if ($flag === "true")
		{
			$flag = true;
		}
		elseif ($flag === "false")
		{
			$flag = false;
		}
		
		$this->setViewState("masterChecked", $flag, false);
	}

	public function getMasterChecked()
	{
		return $this->getViewState("masterChecked", false);
	}
	
	public function onMasterChecked($sender, $param)
	{
		if (is_null($sender))
		{
			$currentState = true;
		}
		else
		{	
			$currentState = $sender->getChecked();
		}
			
		$this->setMasterChecked($currentState);

		// $this->doAnalyze();  maybe it's better not to reanalyze for nothing.........
		$dataSource = $this->getSavedDataSource();
	
		if (!empty($dataSource))
		{
			$newDataSource = [];
			
			foreach ($dataSource as $row)
			{
				$row['checked'] = $currentState;
				$newDataSource[] = $row;
			}

			$this->FoundLinks->setDataSource($newDataSource);
			$this->FoundLinks->dataBind();
		}
	}
	
	private function doUnlink($link)
	{
		/* @var $link LAuthorityManifestation */
		$ok = false;
		
		try
		{
			$link->delete();
			
			ChangelogPeer::logAction(	$link->getManifestation(), 
										ChangelogPeer::LOG_MODIFY, 
										$this->getUser(), 
										'Cancellato nuovo legame fra notizia (id = ' . $link->getManifestationId() 
											. ') e authority (id = ' . $link->getAuthorityId() . ') tramite plugin.');

			ChangelogPeer::logAction(	$link->getAuthority(), 
										ChangelogPeer::LOG_MODIFY, 
										$this->getUser(), 
										'Cancellato nuovo legame fra notizia (id = ' . $link->getManifestationId() 
											. ') e authority (id = ' . $link->getAuthorityId() . ') tramite plugin.');
			
			$ok = true;
		}		
		catch (Exception $e)
		{
			$ok = false;
		}
		
		return $ok;
	}
	
	private function doModify($link, $linkType, $relatorCode)
	{
		/* @var $link LAuthorityManifestation */
		$ok = false;
		
		try
		{
			$modTarget1 = '';
			$modTarget2 = '';
			$modTargetConn = '';
			
			if (!is_null($linkType))
				$modTarget1 = "tipo authority";
			
			if (!is_null($relatorCode))
				$modTarget2 = "relator code";
			
			$newLink = $link->copy(true);
			$newLink->setLinkType($linkType);
			$newLink->setRelatorCode($relatorCode);
			
			$link->delete();
			$newLink->save();

			if (($modTarget1 != '')
					&& ($modTarget2 != ''))
				$modTargetConn = " e ";
			
			$modTarget = Prado::localize($modTarget1 . $modTargetConn . $modTarget2);
			
			ChangelogPeer::logAction(	$newLink->getManifestation(), 
										ChangelogPeer::LOG_MODIFY, 
										$this->getUser(), 
										'Modificato ' . $modTarget . ' nel legame fra notizia (id = ' . $newLink->getManifestationId() 
											. ') e authority (id = ' . $newLink->getAuthorityId() . ') tramite plugin.');

			ChangelogPeer::logAction(	$newLink->getAuthority(), 
										ChangelogPeer::LOG_MODIFY, 
										$this->getUser(), 
										'Modificato ' . $modTarget . ' nel legame fra notizia (id = ' . $newLink->getManifestationId() 
											. ') e authority (id = ' . $newLink->getAuthorityId() . ') tramite plugin.');
			
			$ok = true;
		}		
		catch (Exception $e)
		{
			$ok = false;
		}
		
		return $ok;
	}
	
	public function onResetShelf($sender, $param)
	{
		$this->doResetShelf($param);
	}

	private function doResetShelf($param = null)
	{
		$this->ShelfName->setText(Prado::localize('nessun scaffale'));
		$this->ShelfId->setValue('');
		
		$this->renderShelfPanel($param);
	}
	
	public function renderShelfPanel($param = null)
	{
		if (is_null($param))
		{
			$writer = $this->createWriter();
		}
		else
		{
			$writer = $param->getNewWriter();
		}

		$this->ShelfPanel->render($writer);
	}

	public function renderLinkTypesPanel($param = null)
	{
		if (is_null($param))
		{
			$writer = $this->createWriter();
		}
		else
		{
			$writer = $param->getNewWriter();
		}

		$this->LinkTypesPanel->render($writer);
	}
	
	public function onCheckDestShelfType($sender, $param)
	{
		$valid = false;
		$shelfId = intval($this->ShelfId->getValue());
		
		if ($shelfId > 0)
		{
			$destShelf = ShelfQuery::create()->findPk($shelfId);

			if ($destShelf instanceof Shelf)
			{
				switch ($destShelf->getShelfItemtype())
				{
					case ShelfPeer::TYPE_MANIFESTATION:
					case ShelfPeer::TYPE_MANIFESTATION_BUY:
					case ShelfPeer::NOTYPE:
					case null:
						$valid = true;
						break;
					
					default:
						$valid = false;
				}
			}
		}
		
		$param->isValid = $valid;
	}
	
	public function onUpdateShelfChosen($sender, $param)
	{
		$destShelfId = intval($this->ShelfId->getValue());
		
		if ($destShelfId > 0)
		{	
		$this->getPage()->writeMessage(Prado::localize("Scaffale di destinazione delle notizie spostate: '{shelfName}' (id={shelfId})",
															array(	'shelfName' => ShelfPeer::getShelfName($destShelfId),
																	'shelfId' => $destShelfId )),
											ClavisMessage::INFO);
		}
		else
		{
			$this->getPage()->writeMessage(Prado::localize("Errore nella scelta dello scaffale"),
												ClavisMessage::ERROR);
		}
	}
	
}