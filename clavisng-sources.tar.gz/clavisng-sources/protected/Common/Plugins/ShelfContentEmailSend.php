<?php
/**
 * ShelfContentEmailSend class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package ShelfPlugins
 */

/**
 * ShelfContentEmailSend Class
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.7
 * @package ShelfPlugins
 * @since 2.4
 */

class ShelfContentEmailSend extends ClavisPlugin
{
	const EMAIL_GROUP_BY = 20;

	public static function getTargetShelfTypes()
	{
		return array(	ShelfPeer::TYPE_PATRON,
						ShelfPeer::TYPE_LIBRARIAN,
						ShelfPeer::TYPE_LIBRARY );
	}
	
	public static function getEditMode()
	{
		return ShelfPeer::EDITTYPE_NONEDIT;
	}
	
	public function onInit($param)
	{
		parent::onInit($param);

		$objectFilterDataSource = $this->ObjectFilter->getDataSource();
		
		if (is_null($objectFilterDataSource) 
				|| (count($objectFilterDataSource) == 0))
		{
			$datasource = LookupValuePeer::getLookupClassValues('EMAILOBJECTTYPE', true);
			$this->ObjectFilter->setDataSource($datasource);
			$this->ObjectFilter->dataBind();
		}
	}

	public function setIsItemValid($valid = false)
	{
		$this->getApplication()->getSession()->add('IsItemValid', $valid, false);
	}

	public function getIsItemValid()
	{
		return $this->getApplication()->getSession()->itemAt('IsItemValid', false);
	}

	public function clearLibraryFields()
	{
		$this->Library->setText('');
		$this->LibraryId->setValue(null);
	}

	public function IsPopup()
	{
		return true;
	}

	public function onSendEmail($sender, $param)
	{
		ini_set("memory_limit", "700M");
		set_time_limit(0);
					
		$countNonExist = 0;				// counter for shelfitem object that don't exist anymore
		$countDeletedShelfItems = 0;	// counter for shelfitem object that have been deleted

		$shelfItems = $this->getCheckedItems();
		$body = trim($this->Body->getSafeText());

		$destShelfId = intval($this->ShelfId->getValue());
		$destShelf = ShelfQuery::create()
						->findPk($destShelfId);
		
		if (is_null($destShelf))
			$destShelfId = 0;

		if ((count($shelfItems) > 0) 
				&& ($body != ''))
		{
			$objectFilter = $this->ObjectFilter->getSelectedValue();

			if (is_null($objectFilter))
				$objectFilter = "0";

			$addresses = array();
			$recipients = array();

			foreach ($shelfItems as $shelfItemIndex => $shelfItem)
			{
				if (is_null($shelfItem))
					continue;   // in the shelfitems loop
				
				$realObject = $shelfItem->getObject();
				
				if (is_null($realObject))
				{
					$countNonExist++;

					try
					{
						$shelfItem->delete();
						unset ($shelfItems[$shelfItemIndex]);
						$countDeletedShelfItems++;
					}
					catch (PropelException $exception)
					{
						//Prado::log($exception);
					}
					
					continue;	// in the shelfitems loop
				}
			
				$packedShelfItem = $shelfItem->getPackedPK();
				$objectClass = $shelfItem->getObjectClass();

				if (($objectFilter == $objectClass)
						|| ($objectFilter == "0"))
				{
					$email = null;
				
					switch ($objectClass)
					{
						case 'patron':
							foreach ($realObject->getEmail() as $email)
							{
								$email = trim($email);
					
								if ($email != '')
								{
									$addresses[] = $email;
								
									if ($destShelfId > 0)
										$recipients[$email] = $packedShelfItem;
								}
							}
							
							break;

						case 'librarian':
							$email = trim($realObject->getEmail());
							
							if ($email != '')
							{
								$addresses[] = $email;
							
								if ($destShelfId > 0)
									$recipients[$email] = $packedShelfItem;
							}
							
							break;

						case 'library':
							$email = trim($realObject->getEmail());
							
							if ($email != '')
							{
								$addresses[] = $email;
								if ($destShelfId > 0)
									$recipients[$email] = $packedShelfItem;
							}
							
							break;
					} // end of switch on $objectClass
				}  // end of filtering logic by a user selected class
				
				unset ($realObject);
			}  // end of main loop of shelfitems

			$addressesArray = array_chunk(array_unique($addresses), self::EMAIL_GROUP_BY);
			
			if (count($addressesArray) > 0)
			{
				$mailModule = $this->getApplication()->getModule("mail");
				$date = Clavis::dateFormat(time(),'shortdate mediumtime');
				$countDone = 0;
				$countFailed = 0;

				$shelfItemsMoved = 0;
				$shelfItemsFailed = 0;

				$userLibrarian = $this->getUser();
				$librarianName = $userLibrarian->getCompleteName();
				$actualLibrary = $userLibrarian->getActualLibrary();
				$librarianLibraryLabel = $actualLibrary->getLabel();

				/* select from by parameter */
				switch (ClavisParamQuery::getParam('CLAVISPARAM','MailSentFrom'))
				{
					case 'librarian':
						$librarianEmail = trim($userLibrarian->getEmail());
						
						if (!$librarianEmail)
							$librarianEmail = $actualLibrary->getEmail();
						
						if (!$librarianEmail)
							$librarianEmail = ClavisParamQuery::getParam('CLAVISPARAM','AdminEmail');
						
						$from = '"'.$userLibrarian->getCompleteName().'" <'.$librarianEmail.'>';
						
						break;
						
					case 'preferredlibrary':
						if ($realObject instanceof Patron)
						{
							$prefLibrary = $realObject->getPreferredLibrary();
						
							if ($prefLibrary instanceof Library)
							{
								$email = trim($prefLibrary->getEmail());
							
								if (!$email)
									$email = $actualLibrary->getEmail();
								
								if (!$email)
									$email = ClavisParamQuery::getParam('CLAVISPARAM','AdminEmail');
								
								$from = '"'.$prefLibrary->getLabel().'" <'.$email.'>';
							}
							else
							{
								$libraryEmail = $actualLibrary->getEmail();
								
								if (!$libraryEmail)
									$libraryEmail = ClavisParamQuery::getParam('CLAVISPARAM','AdminEmail');
								
								$from = '"'.$actualLibrary->getLabel().'" <'.$libraryEmail.'>';
							}
						}
						else
						{
							$libraryEmail = $actualLibrary->getEmail();
							
							if (!$libraryEmail)
								$libraryEmail = ClavisParamQuery::getParam('CLAVISPARAM','AdminEmail');
							
							$from = '"'.$actualLibrary->getLabel().'" <'.$libraryEmail.'>';
						}
						
						break;
						
					case 'library':
						$libraryEmail = $actualLibrary->getEmail();
						
						if (!$libraryEmail)
							$libraryEmail = ClavisParamQuery::getParam('CLAVISPARAM','AdminEmail');
						
						$from = '"'.htmlentities($actualLibrary->getLabel()).'" <'.$libraryEmail.'>';
						
						break;
						
					case 'system':
					default:
						$from = ClavisParamQuery::getParam('CLAVISPARAM','AdminEmail');
						
						break;
				}

				$subject = trim($this->Title->getSafeText());
				
				if ($subject == '')
					$subject = Prado::localize("Messaggio dall'operatore {librarianName} [{librarianLibraryLabel}] in data {date}",
														array(	'librarianName' => $librarianName,
																'librarianLibraryLabel' => $librarianLibraryLabel,
																'date' => $date));

				foreach ($addressesArray as $chunk)   // ciclo per spedire email a tronconi di destinatari
				{
					$implodedEmailAddresses = '';
					$implodedEmailAddressesCount = 0;
				
					foreach ($chunk as $address)
					{
						if ($mailModule->validateEmailAddress($address))
						{
							if ($destShelfId > 0 && array_key_exists($address, $recipients))
							{
								if ($this->moveToShelf($destShelfId, $recipients[$address]))
								{
									$shelfItemsMoved++;
								}
								else
								{
									$shelfItemsFailed++;
								}
							}

							$implodedEmailAddresses .= $address . ',';
							$implodedEmailAddressesCount++;
						}
					}

					if ($implodedEmailAddressesCount > 0)
					{
						$implodedEmailAddresses = rtrim($implodedEmailAddresses, ',');

						$mailModule->setSubject($subject);

						//$mailModule->setTo($from);
						$mailModule->setBcc($implodedEmailAddresses);
						$mailModule->setBody($body);
						$mailModule->setFrom($from);

						try
						{
							$mailModule->send();
							$countDone += $implodedEmailAddressesCount;
						} 
						catch (Exception $e) 
						{
							Prado::log($e);
						
							$countFailed += $implodedEmailAddressesCount;
						}
					}
				}

//				if ($shelfItemsMoved > 0)
//					ShelfPeer::checkShelfItemTypes($this->getShelf(), true);
					
				if ($countDone > 0)
					$this->getPage()->enqueueMessage((1 == $countDone)
															? Prado::localize('1 email spedita')
															: Prado::localize('{count} email spedite',
																				array('count' => $countDone)),
														ClavisMessage::CONFIRM);

				if ($countFailed > 0)
					$this->getPage()->enqueueMessage((1 == $countFailed)
															? Prado::localize('1 email non spedita')
															: Prado::localize('{count} email non spedite',
																				array('count' => $countFailed)),
														ClavisMessage::ERROR);

				if ($destShelfId > 0)
					$this->getPage()->enqueueMessage(Prado::localize("e {shelfItemsMoved} elementi spostati allo scaffale '{shelfName}'",
																		array(	'shelfItemsMoved' => $shelfItemsMoved,
																				'shelfName' => $destShelf->getShelfCompleteName())),
														ClavisMessage::CONFIRM);

				if (($countDone == 0)
						&& ($countFailed == 0))
					$this->getPage()->enqueueMessage(Prado::localize('Nessuna operazione effettuata'),
														ClavisMessage::INFO);

				$this->getPage()->flushDelayedMessage();
				$this->onClose();
			}
			else
			{
				$this->getPage()->enqueueMessage(Prado::localize('Nessun indirizzo email valido'),
													ClavisMessage::ERROR);
			}
		}

		if ($body == '')
		{	
			$this->getPage()->enqueueMessage(Prado::localize("Corpo dell'email vuoto"),
												ClavisMessage::ERROR);
		}
		
		if (count($shelfItems) == 0)
		{	
			$this->getPage()->enqueueMessage(Prado::localize("Nessun elemento selezionato"),
												ClavisMessage::ERROR);
		}
		
		if ($countNonExist > 0)
		{	
			$this->getPage()->enqueueMessage(($countNonExist == 1)
													? Prado::localize("É stato rilevato un oggetto non più esistente")
													: Prado::localize("Sono stati rilevati {num} oggetti non più esistenti",
																		array('num' => $countNonExist)),
												ClavisMessage::WARNING);
		}
		
		if ($countDeletedShelfItems > 0)
		{
			$this->getPage()->enqueueMessage(($countDeletedShelfItems == 1)
													? Prado::localize("É stato rimosso dallo scaffale un riferimento ad un oggetto non più esistente")
													: Prado::localize("Sono stati rimossi dallo scaffale {num} riferimenti ad oggetti non più esistenti",
																		array('num' => $countDeletedShelfItems)),
												ClavisMessage::WARNING);
		}
		
		$this->getPage()->flushMessage();
		
		return false;
	}

	private function moveToShelf($destShelfId = null, $packedShelfItem = null)
	{
		$destShelfId = intval($destShelfId);
		
		if (is_null($destShelfId)
				|| is_null($packedShelfItem))
			return false;

		$orig = ShelfItemPeer::retrieveByPackedPK($packedShelfItem);
		
		if (is_null($orig))
			return false;

		$objectId = intval($orig->getObjectId());
		$objectClass = trim($orig->getObjectClass());
		
		if (($objectId == 0)
				|| ($objectClass == ''))
			return false;

		$ret = ShelfPeer::addItemToShelf($destShelfId, $objectClass, $objectId);
		
		if ($ret)
			$orig->delete();
		
		$orig->clearAllReferences(true);
		unset($orig);
		
		return $ret;
	}

}