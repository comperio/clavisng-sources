<?php
/**
 * ShelfContentToPatron class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package ShelfPlugins
 */

/**
 * ShelfContentToPatron Class
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package ShelfPlugins
 * @since 2.5.2
 */
class ShelfContentToPatron extends ClavisPlugin
{
	public function setIsItemValid($valid = false)
	{
		$this->getApplication()->getSession()->add('IsItemValid', $valid, false);
	}

	public function getIsItemValid()
	{
		return $this->getApplication()->getSession()->itemAt('IsItemValid', false);
	}

	public function clearLibraryFields()
	{
		$this->Library->setText('');
		$this->LibraryId->setValue(null);
	}

	public function IsPopup()
	{
		return true;
	}

	public function onAction($sender, $param)
	{
		ini_set('memory_limit', '768M');
		set_time_limit(0);

		$shelfItems = $this->getCheckedItems();

		$shelfId = intval($this->ShelfId->getValue());
		$shelf = ShelfQuery::create()
					->findPk($shelfId);
		
		if (count($shelfItems > 0)
				&& $shelf instanceof Shelf)
		{
			$patronIds = $this->extractPatronIdsFromShelf(	$shelfItems,
															$this->DateFrom->getTimeStamp(),
															$this->DateTo->getTimeStamp() );

			$countDone = ShelfPeer::addItemToShelf(	$shelf,
													ShelfPeer::TYPE_PATRON,
													$patronIds );
			
			$countFailed = (count($patronIds) - $countDone);

			if ($countDone > 0)
			{
				$this->getPage()->enqueueMessage(Prado::localize("N. {count} utenti inseriti nello scaffale '{shelfName}' (id={shelfId})",
																				array(	'count' => $countDone,
																						'shelfName' => $shelf->getShelfName(),
																						'shelfId' => $shelf->getShelfId() )),
													ClavisMessage::CONFIRM);
			}

			if ($countFailed > 0)
			{
				$this->getPage()->enqueueMessage(Prado::localize('N. {count} utenti tralasciati',
																				array('count' => $countFailed)),
													ClavisMessage::WARNING);
			}

			if (($countDone == 0)
					&& ($countFailed == 0))
				$this->getPage()->enqueueMessage(Prado::localize("Nessuna operazione è stata effettuata"),
													ClavisMessage::INFO);
			
			$this->getPage()->flushDelayedMessage();
			$this->onClose();
		}
		else
		{
			$this->getPage()->writeMessage(Prado::localize('Lo scaffale non è valido o non è stato selezionato alcun elemento.'),
												ClavisMessage::ERROR);
		
			return false;
		}
	}
	
	public function extractPatronIdsFromShelf(	$shelfItems,
												$dateFrom = null,
												$dateTo = null)
	{
		$patron_ids = array();
		
		foreach ($shelfItems as $si)
		{
			$q = null;
			$id = $si->getObjectId();

			switch ($si->getObjectClass())
			{
				case ShelfPeer::TYPE_LOAN:
					$q = LoanQuery::create()->filterByLoanId($id);
			
					break;
				
				case ShelfPeer::TYPE_ITEM:
					$q = LoanQuery::create()->filterByItemId($id);
				
					break;
				
				case ShelfPeer::TYPE_MANIFESTATION:
					$q = LoanQuery::create()->filterByManifestationId($id);
				
					break;
				
				case ShelfPeer::TYPE_ITEM_REQUEST:
					$q = ItemRequestQuery::create()->filterByRequestId($id);
				
					break;
			}
			
			if (is_null($q))
				continue;
			
			if ($dateFrom)
				$q->filterByLoanDateBegin($dateFrom,Criteria::GREATER_EQUAL);
			
			if ($dateTo)
				$q->filterByLoanDateEnd($dateTo,Criteria::LESS_EQUAL);
			
			$patron_ids = array_merge(	$patron_ids,
										$q->select('PatronId')
											->distinct()
											->find()
											->toArray() );
		}
		
		return array_unique($patron_ids);
	}
	
}