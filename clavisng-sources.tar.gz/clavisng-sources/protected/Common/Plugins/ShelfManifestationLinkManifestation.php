<?php
/**
 * ShelfManifestationLinkManifestation class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.8.9
 * @package ShelfPlugins
 */

/**
 * ShelfManifestationLinkManifestation Class
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.8.9
 * @package ShelfPlugins
 * @since 2.8.9
 */

class ShelfManifestationLinkManifestation extends ClavisPlugin
{
	private $_clavisLibrarian;

	public static function getTargetShelfTypes()
	{
		return array(ShelfPeer::TYPE_MANIFESTATION);
	}
	
	public static function getEditMode()
	{
		return ShelfPeer::EDITTYPE_EDIT;
	}
	
	private function initVars()
	{
		$this->_clavisLibrarian = $this->getUser();
	}

	public function onInit($param)
	{
		parent::onInit($param);
		$this->initVars();

		if (!$this->getPage()->getIsCallBack())
		{
//			$this->ManLevel->setDataSource(LookupValueQuery::create()
//									->filterByValueLanguage($this->getApplication()->getGlobalization()->getCulture())
//									->filterByValueClass('CATLEVEL')
//									->filterByValueKey($this->getUser()->getLibrarian()->getCatLevel(),Criteria::LESS_EQUAL)
//									->find());
//			
//			$this->ManLevel->dataBind();
			
			////////$this->populateLinkDropDown();
			
			$this->ManLinkType->populate();
			$this->doAnalyze();
		}
	}

	public function setIsItemValid($valid = false)
	{
		$this->getApplication()->getSession()->add('IsItemValid', $valid, false);
	}

	public function getIsItemValid()
	{
		return $this->getApplication()->getSession()->itemAt('IsItemValid', false);
	}

	private function setAnalyzedDataSource($param)
	{
		$this->setControlState('AnalyzedDataSource', $param, array());
	}

	private function getAnalyzedDataSource()
	{
		return $this->getControlState('AnalyzedDataSource', array());
	}
	
	public function IsPopup()
	{
		return true;
	}
		
	private function doAnalyze()
	{
		$dataSource = array();

		foreach ($this->getCheckedItems() as $shelfItem)
		{
			if (($shelfItem instanceof ShelfItem)
					&& ($shelfItem->getObjectClass() == ShelfPeer::TYPE_MANIFESTATION))	// only manifestations
			{
				$manifestation = null;
				$manifestationId = $shelfItem->getObjectId();

				if ($manifestationId > 0)
					$manifestation = ManifestationQuery::create()->findPk($manifestationId);

				if (($manifestation instanceof Manifestation)
						&& ($this->_clavisLibrarian->getEditPermission($manifestation)))
				{
					$serie = $manifestation->getSerie();
					
					if ($serie != "")
						$serie = "<br >" . $serie;
						
					$dataSource[] = array(	'manifestationTitle' => $manifestation->getCompleteTitle(' - '),
											'manifestationUrl' => ManifestationPeer::getNavigateUrl($manifestationId),
											'manifestationId' => $manifestationId,
											'manifestationSerie' => $serie );
				}
			}
		}

		$this->ManifestationList->setDataSource($dataSource);
		$this->ManifestationList->dataBind();
		$this->setAnalyzedDataSource($dataSource);
		
		//$this->getPage()->setFocus("anchor_analyze");
		////////////////////////$this->getPage()->setFocus($this->FocusEnd->getClientID());
		///////////////////////$this->getPage()->setFocus($this->FocusStart->getClientID());

	}
	
	public function onChosenLinkManifestation($sender, $param)
	{
		/// da vedere cosa fare
	}
	
	public function onNewManLink($sender, $param)
	{
		if (!$this->getIsValid())
			return;
		
		$manDownId = intval($this->RecordResultValue->getValue());

		if ($this->_manifestation->getManifestationId() == $manDownId)
		{
			$this->writeMessage(Prado::localize('Impossibile legare una notizia con sé stessa'), 
									ClavisMessage::ERROR);

			return;
		}

		$lman = new LManifestation();
		$lman->setManifestationIdUp($this->_manifestation->getManifestationId());
		$lman->setManifestationIdDown($manDownId);
		$lman->setLinkNote($this->ManLinkNote->getSafeText());
		$lman->setLinkType($this->ManLinkType->getSelectedValue());
		$lman->setLinkSequence($this->ManLinkSequence->getText());
		
		if ($issue_id = intval($this->IssueResultValue->getValue()))
		{
			$lman->setIssueId($issue_id);
			$log_add = ' / issue_id = ' . $issue_id;
		}
		else
		{
			$log_add = '';
		}
		
		try
		{
			$lman->save();
		}
		catch (PropelException $pe)
		{
			$this->writeMessage(Prado::localize('Impossibile legare le due notizie: esiste già un legame'), 
									ClavisMessage::ERROR);
			
			return;
		}

		$manId1 = $this->_manifestation->getManifestationId();
		$manifestationTitle1 = $this->_manifestation->getTrimmedTitle(80, '');
						
		$manifestationRelated = ($lman->getManifestationIdUp() == $manId1
									? $lman->getManifestationRelatedByManifestationIdDown()
									: $lman->getManifestationRelatedByManifestationIdUp());

		$manid2 = $manifestationRelated->getManifestationId();
		$manifestationTitle2 = $manifestationRelated->getTrimmedTitle(80, '');
				
		ChangelogPeer::logAction(	$this->_manifestation, 
									ChangelogPeer::LOG_CREATE, 
									$this->getUser(), 
									'Creato nuovo legame fra la notizia (id = ' . $manid1 . $log_add . ', titolo = \'' . $manifestationTitle1 . '\')'
										. ' e la notizia (id = ' . $manid2 . ', titolo = \'' . $manifestationTitle2 . '\')');
		
		$this->writeMessage(Prado::localize("Creato nuovo legame fra la notizia (id = {manid1}{logadd}, titolo = '{manifestationTitle1}') e la notizia (id = {manid2}, titolo = '{manifestationTitle2}')",
												array(	'manid1' => $manid,
														'logadd' => $log_add,
														'manifestationTitle1' => $manifestationTitle,
														'manid2' => $manid2,
														'manifestationTitle2' => $manifestationTitle2 )),
								ClavisMessage::CONFIRM);
				
		// if linktype is 461 or 463, save manifestations to recalculate hierarchical level
		if (($lman->getLinkType() == 461) 
				|| ($lman->getLinkType() == 463))
		{
			$lman->getManifestationRelatedByManifestationIdDown()->save();
			$this->_manifestation->save();
		}
		else
		{
			$mann = $lman->getManifestationRelatedByManifestationIdDown();
			
			if ($mann instanceof Manifestation)
				$mann->invalidateCache();

			$mann = $lman->getManifestationRelatedByManifestationIdUp();
			
			if ($mann instanceof Manifestation)
				$mann->invalidateCache();
		}

		$this->ManLinkType->setSelectedIndex(-1);
		$this->ManLinkNote->setText('');
		$this->ManLinkSequence->setText('');
		$this->RecordResultValue->setValue('');
		$this->RecordResultLabel->setText('');
		$this->IssueResultValue->setValue('');
		$this->IssueResultLabel->setText('');
		$this->LinkedIssueSelect->setCssClass('panel_off');

		$this->bindManGrid();
	}
	
	private function readManifestationList()
	{
		$lManifestationArray = array();
		
		foreach ($this->ManifestationList->getItems() as $row)
		{
//			if ($row->Cells[0]->Checked->getChecked())
//			{
//				$valueRaw = $row->Cells[0]->Value->getValue();
//
//				if ($valueRaw != "")
//					$lAuthoritieManifestationArray[] = array(	unserialize($valueRaw),
//																$row->Cells[0]->TitleString->getValue() );
//			}
		
			$manifestationId = $row->Cells[1]->ManifestationId->getValue();
			$linkSequence = trim($row->Cells[1]->LinkSequence->getSafeText());
			
			$lManifestationArray[$manifestationId] = $linkSequence;
			
		}	
			
		return $lManifestationArray;
	}
	
	public function onAssign($sender, $param)
	{
		ini_set("memory_limit", "700M");
		set_time_limit(0);

		$manifestationsGrid = $this->readManifestationList();    ///////$this->getAnalyzedDataSource();	 probabilmente da tirare via i metodi //////////

		if (count($manifestationsGrid) == 0)
		{
			$this->getPage()->writeMessage(Prado::localize("La lista delle notizie da usare è vuota."),
												ClavisMessage::INFO);
			
			return false;
		}
		
		$linkManifestation = null;
		$linkManifestationId = intval($this->RecordResultValue->getValue());
		
		if ($linkManifestationId > 0)
			$linkManifestation = ManifestationQuery::create()->findPk($linkManifestationId);
		
		if (!($linkManifestation instanceof Manifestation))
		{
			$this->getPage()->writeMessage(Prado::localize("La notizia con id={id} non esiste",
																array('id' => $linkManifestationId)),
												ClavisMessage::INFO);

			return false;
		}

		$this->getPage()->cleanMessageQueue();
		
		$linkType = $this->ManLinkType->getSelectedValue();

		$done = [];
		$failed = [];
		$notAuthorized = [];

		/// begin of manifestationList cycle
		foreach ($manifestationsGrid as $manifestationId => $linkSequence)
		{
			$manifestation = ManifestationQuery::create()->findPk($manifestationId);

			if (!$this->_clavisLibrarian->getEditPermission($manifestation))
			{
				$notAuthorized[] = $manifestationId;
			}
			else
			{
				$returnCode = $this->doNewManLink(	$manifestationId, 
													$linkManifestationId,
													$linkType,
													$linkSequence);

				switch ($returnCode)
				{
					case true:

						$done[] = $manifestationId;
						
						ChangelogPeer::logAction(	"Manifestation",
													ChangelogPeer::LOG_UPDATE,
													$this->_clavisLibrarian,
													"Collegata la notizia con id=" . $linkManifestationId,
													$manifestationId);

						break;

					case false:
					default:
						$failed[] = $manifestationId;

						break;
				}

			}

		}
		/// end of cycle upon the shelf objects

		if (empty($done)
				&& empty($failed)
				&& empty($notAuthorized))
		{
			$this->getPage()->enqueueMessage(Prado::localize("Nessuna azione eseguita"),
												ClavisMessage::INFO);
			$this->getPage()->flushMessage();
		}
		else
		{
			if (count($done) > 0)
			{
				$manifestationsIdsDoneString = implode(', ', $done);
				
				$this->getPage()->enqueueMessage(Prado::localize("La notizia selezionata ('{authTitle}', id={authId}) è stata collegata a {count} notizie dello scaffale '{shelfName}', id={shelfId}, le quali hanno id={manifestationIds}",
																	array(	'authTitle' => $linkManifestation->getCompleteTitle(' - '),
																			'authId' => $linkManifestationId,
																			'count' => count($done),
																			'shelfName' => $this->getShelf()->getShelfName(),
																			'shelfId' => $this->getShelf()->getShelfId(),
																			'manifestationIds' => $manifestationsIdsDoneString )),
													ClavisMessage::CONFIRM);
				
				ChangelogPeer::logAction(	"Manifestation",
											ChangelogPeer::LOG_UPDATE,
											$this->_clavisLibrarian,
											"La notizia è stata collegata alle notizie con id=$manifestationsIdsDoneString",
											$linkManifestationId);
			}	

			if (count($notAuthorized) > 0)
			{
				$manifestationsIdsNotAuthorizedString = implode(', ', $notAuthorized);
				
				$this->getPage()->enqueueMessage(Prado::localize("Le notizie non sono state collegate ad authority per mancanza di autorizzazione, con id={ids}",
																	array('ids' => $manifestationsIdsNotAuthorizedString)),
													ClavisMessage::WARNING);
				
				ChangelogPeer::logAction(	"Manifestation",
											ChangelogPeer::LOG_UPDATE,
											$this->_clavisLibrarian,
											"La notizia non è stata collegata, per mancanza di autorizzazione, alle notizie con id=$manifestationsIdsNotAuthorizedString",
											$linkManifestationId);
			}

			if (count($failed) > 0)
			{
				$manifestationsIdsFailedString = implode(', ', $failed);
				
				$this->getPage()->enqueueMessage(Prado::localize("Le notizie non sono state collegate ad authority a causa di errori, con id={ids}",
																	array('ids' => $manifestationsIdsFailedString)),
													ClavisMessage::ERROR);
				
				ChangelogPeer::logAction(	"Manifestation",
											ChangelogPeer::LOG_UPDATE,
											$this->_clavisLibrarian,
											"La notizia non è stata collegata, a causa di errori, alle notizie con id=$manifestationsIdsFailedString",
											$linkManifestationId);				
			}

			$this->getPage()->flushDelayedMessage();
			$this->onClose();
		}
	}
	
	public function doNewManLink(	$manifestationId, 
									$linkManifestationId,
									$linkType = null,
									$linkSequence = "")
	{
		if ($manifestationId == $linkManifestationId)
		{
//			$this->writeMessage(Prado::localize('Impossibile legare una notizia con sé stessa'), 
//									ClavisMessage::ERROR);

			return false;
		}

		$lman = new LManifestation();
		$lman->setManifestationIdUp($manifestationId);
		$lman->setManifestationIdDown($linkManifestationId);
		//$lman->setLinkNote($this->ManLinkNote->getSafeText());
		$lman->setLinkType($linkType);
		$lman->setLinkSequence($linkSequence);
		
		try
		{
			$lman->save();
		}
		catch (PropelException $pe)
		{
//			$this->writeMessage(Prado::localize('Impossibile legare le due notizie: esiste già un legame'), 
//									ClavisMessage::ERROR);
			
			return false;
		}

//		$manId1 = $manifestationId;
//		$manifestationTitle1 = $this->_manifestation->getTrimmedTitle(80, '');
//						
//		$manifestationRelated = ($lman->getManifestationIdUp() == $manId1
//									? $lman->getManifestationRelatedByManifestationIdDown()
//									: $lman->getManifestationRelatedByManifestationIdUp());
//
//		$manid2 = $manifestationRelated->getManifestationId();
//		$manifestationTitle2 = $manifestationRelated->getTrimmedTitle(80, '');
//				
//		ChangelogPeer::logAction(	$this->_manifestation, 
//									ChangelogPeer::LOG_CREATE, 
//									$this->getUser(), 
//									'Creato nuovo legame fra la notizia (id = ' . $manid1 . $log_add . ', titolo = \'' . $manifestationTitle1 . '\')'
//										. ' e la notizia (id = ' . $manid2 . ', titolo = \'' . $manifestationTitle2 . '\')');
//		
//		$this->writeMessage(Prado::localize("Creato nuovo legame fra la notizia (id = {manid1}{logadd}, titolo = '{manifestationTitle1}') e la notizia (id = {manid2}, titolo = '{manifestationTitle2}')",
//												array(	'manid1' => $manid,
//														'logadd' => $log_add,
//														'manifestationTitle1' => $manifestationTitle,
//														'manid2' => $manid2,
//														'manifestationTitle2' => $manifestationTitle2 )),
//								ClavisMessage::CONFIRM);
				
		// if linktype is 461 or 463, save manifestations to recalculate hierarchical level
		if (($linkType == 461) 
				|| ($linkType == 463))
		{
			$lman->getManifestationRelatedByManifestationIdDown()->save();
			ManifestationQuery::create()->findPk($manifestationId)->save();
		}
		else
		{
			$mann = $lman->getManifestationRelatedByManifestationIdDown();
			
			if ($mann instanceof Manifestation)
				$mann->invalidateCache();

			$mann = $lman->getManifestationRelatedByManifestationIdUp();
			
			if ($mann instanceof Manifestation)
				$mann->invalidateCache();
		}

		return true;
	}
	
}