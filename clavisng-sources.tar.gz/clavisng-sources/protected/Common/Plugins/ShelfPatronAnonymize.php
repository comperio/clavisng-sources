<?php
/**
 * ShelfPatronAnonymize class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.8.9
 * @package ShelfPlugins
 */

/**
 * ShelfPatronAnonymize Class
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.8.9
 * @package ShelfPlugins
 * @since 2.1
 */

class ShelfPatronAnonymize extends ClavisPlugin
{
	private $_clavisLibrarian;
	private $_actualLibraryId;
	
	private $_patronAnonymizeYearLimit;
	private $_patronAnonymizeTimestampLimit;
	

	private function initVars()
	{
		$this->_clavisLibrarian = $this->getUser();
		$this->_actualLibraryId = $this->_clavisLibrarian->getActualLibraryId();
		
		$this->_patronAnonymizeYearLimit = ClavisParamQuery::getParam('CLAVISPARAM', 'PatronAnonymizeYearLimit');
		$this->_patronAnonymizeTimestampLimit = time() - ClavisLoanManager::YEARS_1 * $this->_patronAnonymizeYearLimit;
	}

	public static function getTargetShelfTypes()
	{
		return array(ShelfPeer::TYPE_PATRON);
	}
	
	public static function getEditMode()
	{
		return ShelfPeer::EDITTYPE_EDIT;
	}
	
	public function onInit($param)
	{
		parent::onInit($param);
		$this->initVars();

		//$isAdmin = $this->getUser()->getIsAdmin();
		
		if (!$this->getPage()->getIsCallBack())
		{
			$this->PatronAnonymizeYearLimit->setText($this->_patronAnonymizeYearLimit);
			
			////$this->doRecalculateCandidatePatrons();
			$this->CandidatePatronsCount->setText(Prado::localize("premere il pulsante [ricalcola]"));
			$this->ActionButton->setEnabled(false);
			
		}
	}

	private function doRecalculateCandidatePatrons()
	{
		list ($candidatePatronIds, $refusedPatronIds) = $this->findCandidatePatrons($this->_patronAnonymizeTimestampLimit);
		$this->setCandidatePatronIds($candidatePatronIds);
		$this->setRefusedPatronIds($refusedPatronIds);

		$this->CandidatePatronsCount->setText(count($candidatePatronIds) . '/' . $this->countCheckedItems());
		$this->ActionButton->setEnabled(count($candidatePatronIds) > 0);
	}
	
	public function onRecalculate($sender, $param)
	{
		$this->doRecalculateCandidatePatrons();
	}
	
	public function setCandidatePatronIds($param = [])
	{
		$this->getApplication()->getSession()->add('CandidatePatrons', $param, []);
	}

	public function getCandidatePatronIds()
	{
		return $this->getApplication()->getSession()->itemAt('CandidatePatrons', []);
	}
	
	public function setRefusedPatronIds($param = [])
	{
		$this->getApplication()->getSession()->add('RefusedPatrons', $param, []);
	}

	public function getRefusedPatronIds()
	{
		return $this->getApplication()->getSession()->itemAt('RefusedPatrons', []);
	}
	
	private function findCandidatePatrons($timestampLimit = null)
	{
		ini_set("memory_limit", "700M");
		set_time_limit(0);
		
		$candidatePatronIds = [];
		$refusedPatronIds = [];
		
		foreach ($this->getCheckedItems() as $shelfItem)
		{
			if ($shelfItem->getObjectClass() != ShelfPeer::TYPE_PATRON)
				continue;

			$patron = null;
			$patronId = $shelfItem->getObjectId();

			if ($patronId > 0)
				$patron = PatronQuery::create()->findPk($patronId);

			if (!($patron instanceof Patron))
				continue;
									
			// we have a Patron
			if (	$patron->hasActiveLoans()
					|| $patron->hasRecentLoans($timestampLimit)
							
					|| $patron->hasActiveRequests()
					|| $patron->hasRecentItemRequests($timestampLimit)		
					
					|| $patron->hasRecentResourceSession($timestampLimit)
					
					|| !$this->_clavisLibrarian->getEditPermission($patron))
			{
				$refusedPatronIds[] = $patronId;
			}	
			else
			{
				$candidatePatronIds[] = array(	$patronId,
												$shelfItem );
			}
		}

		return array($candidatePatronIds, $refusedPatronIds);
	}
	
	public function onAction($sender, $param)
	{
		ini_set("memory_limit", "700M");
		set_time_limit(0);
		$this->getPage()->cleanMessageQueue();

		$patronsDone = 0;
		$patronsFailed = 0;
		
		$addressDeleted = 0;
		$contactDeleted = 0;
		$patronPropertyDeleted = 0;
		$changelogDeleted = 0;
		
		$itemActionModified = 0;
		$itemRequestModified = 0;
		$loanModified = 0;
		$resourceSessionModified = 0;
		$patronActionModified = 0;
		
		foreach ($this->getCandidatePatronIds() as $candidate)
		{
			list ($patronId, $shelfItem) = $candidate;
			
			try
			{
				$patron = PatronQuery::create()->findPk($patronId);

				$addressDeleted = AddressQuery::create()
									->filterByPatronId($patronId)
									->delete();

				$contactDeleted = ContactQuery::create()
									->filterByPatronId($patronId)
									->delete();

				$patronPropertyDeleted = PatronPropertyQuery::create()
											->filterByPatronId($patronId)
											->delete();

				$changelogDeleted = ChangelogQuery::create()
										->filterByObjectClass('Patron')
										->filterByObjectId($patronId)
										->delete();
				
				$itemActionModified = ItemActionQuery::create()
											->filterByPatronId($patronId)
											->update(array('PatronId' => null));

				$itemRequestModified = ItemRequestQuery::create()
											->filterByPatronId($patronId)
											->update(array('PatronId' => null));

				$loanModified = LoanQuery::create()
										->filterByPatronId($patronId)
										->update(array('PatronId' => null));

				$resourceSessionModified = ResourceSessionQuery::create()
												->filterByPatronId($patronId)
												->update(array('PatronId' => null));

				$patronActionModified = PatronActionQuery::create()
												->filterByPatronId($patronId)
												->update(array('PatronId' => null));

				$patron->delete();

				ShelfItemPeer::doDelete($shelfItem);
				
				$patronsDone++;
			}
			catch (Exception $ex)
			{
				$patronsFailed++;
			}
		}	// main cycle on patrons

		$refreshFlag = false;
		
		// if no action has succeeded
		if (($patronsDone + $patronsFailed) == 0)
		{
			$this->getPage()->enqueueMessage(Prado::localize('Nessuna azione di anonimizzazione utenti eseguita'),
												ClavisMessage::INFO);
		}
		else	// some actions or errors occurred
		{
			if ($patronsDone > 0)
			{	
				$this->getPage()->enqueueMessage(Prado::localize("Numero degli utenti anonimizzati: {patronsDone}",
																	array('patronsDone' => $patronsDone)),
													ClavisMessage::CONFIRM);
				
				$refreshFlag = true;
				
				ChangelogPeer::logAction(	$this->getShelf(), 
											ChangelogPeer::LOG_UPDATE, 
											$this->getUser(), 
											"Sono stati anonimizzati $patronsDone utenti in precedenza su questo scaffale");
			}

			if ($patronsFailed > 0)
			{
				$this->getPage()->enqueueMessage(Prado::localize("Numero degli utenti non anomimizzati a causa di un errore: {patronsFailed}",
																	array('patronsFailed' => $patronsFailed)),
													ClavisMessage::ERROR);
			}
		}
		
		if (($patronsDone > 0)
				&& ($patronsFailed == 0))		// no errors and everything is ok
		{
			// close plugin, bye
			$this->getPage()->flushDelayedMessage();
			$this->onClose();
		}
		else
		{
			// plugin stays open
			$this->getPage()->flushMessage();
			
			if ($refreshFlag)
				$this->getPage()->shelfListRefresh($param);
			
			$this->ActionButton->setEnabled(false);
		}
	}

	public function IsPopup()
	{
		return true;
	}
	
}