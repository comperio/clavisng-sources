<?php
/**
 * ShelfItemInsertFromCSV class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package ShelfPlugins
 */

/**
 * ShelfItemInsertFromCSV Class
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.7
 * @package ShelfPlugins
 * @since 2.2
 */

class ShelfItemInsertFromCSV extends ClavisPlugin
{
	public static function getTargetShelfTypes()
	{
		return array(ShelfPeer::TYPE_ITEM);
	}
	
	public static function getEditMode()
	{
		return ShelfPeer::EDITTYPE_EDIT;
	}
	
	public static function getFillMode()
	{
		return true;
	}
	
	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsCallBack())
		{
			//
		}
	}

	public function isDataSourceNeeded()
	{
		return false;
	}

	public function onImport($sender, $param)
	{
		ini_set("memory_limit", "700M");
		set_time_limit(0);
		
		$toShelf = $this->getShelf();
		$uploadedFile = $this->getViewState('uploadedFile');

		if ($uploadedFile == '')
		{
			$this->getPage()->writeMessage(Prado::localize('Errore sulla scelta del file di origine'),
												ClavisMessage::ERROR);
			
			return false;
		}

		$filed = fopen($uploadedFile, 'r');
		
		$candidateBarcodes = array();
		$candidateInventories = array();
		
		while ($rowArray = fgetcsv($filed))
		{
			if (!is_array($rowArray) 
					|| (count($rowArray) == 0))
				continue;

			foreach ($rowArray as $rowElement)
			{
				if ($rowElement != '')
				{
					if (preg_match("/([A-Za-z0-9]+)-([0-9]+)/i", $rowElement)) //, $regs))	
					{
						$candidateInventories[] = Propel::getConnection()->quote($rowElement);
					}
					else		
					{
						$candidateBarcodes[] = Propel::getConnection()->quote($rowElement);
					}
				}
			}
		}

		$logicalCondition = Criteria::LOGICAL_OR;
		
		if (count($candidateBarcodes) > 0)
		{
			$condBarcodes = "item.barcode IN (" . implode(",", $candidateBarcodes) . ")";
		}
		else	// dummy
		{
			$condBarcodes = "item.item_id > 0";
			$logicalCondition = Criteria::LOGICAL_AND;
		}
		
		if (count($candidateInventories) > 0)
		{
			$condInventories = "concat(item.inventory_serie_id, '-', item.inventory_number) IN (" . implode(",", $candidateInventories) . ")";
		}
		else	// dummy
		{
			$condInventories = "item.item_id > 0";
			$logicalCondition = Criteria::LOGICAL_AND;
		}
		
		$resultArray = ItemQuery::create()
						->select(array('item_id'))
				
						->condition("cond1", $condBarcodes)
						->condition("cond2", $condInventories)
						->where(array("cond1", "cond2"), $logicalCondition)
				
						->find()->toArray();

		if (count($resultArray) == 0)
		{
			$this->getPage()->writeMessage(Prado::localize('Il file risulta vuoto: nessun esemplare da importare'),
											ClavisMessage::WARNING);
		
			return false;
		}

		$duplicatedString = '';

		$countDone = ShelfPeer::addItemToShelf(	$toShelf,
												ShelfPeer::TYPE_ITEM,
												$resultArray);
		
		$countFailed = count($resultArray) - $countDone;
		$this->getPage()->cleanMessageQueue();
		
		if (($countDone == 0)
				&& ($countFailed == 0)
				&& ($duplicatedString == ''))
		{
			$this->getPage()->enqueueMessage(Prado::localize("Nessuna azione eseguita"),
																ClavisMessage::INFO);
		}
		else
		{
			if (strlen($duplicatedString) > 0)
				$duplicatedString = rtrim($duplicatedString, ', ');

			if ($countDone > 0)
				$messageText = $this->getPage()->enqueueMessage(Prado::localize('{count} elementi inseriti',
																					array('count' => $countDone)),
																	ClavisMessage::CONFIRM);

			if ($countFailed > 0)
				$messageText = $this->getPage()->enqueueMessage(Prado::localize('{count} elementi NON inseriti per errore sconosciuto',
																					array('count' => $countFailed)),
																	ClavisMessage::ERROR);

			if ($duplicatedString != '')
				$messageText = $this->getPage()->enqueueMessage(Prado::localize('Esemplari non inseriti perché già presenti nello scaffale, con id: ({duplicatedString})',
																					array('duplicatedString' => $duplicatedString)),
																	ClavisMessage::WARNING);
		}

		if ($countDone > 0)
		{
			$this->getPage()->flushDelayedMessage();
			$this->onClose();
		}
		else
		{
			$this->getPage()->flushMessage();
		}
	}

	protected function onFileUploaded($sender, $param)
	{
		if ($sender->getHasFile())
   		{
			$tmpdir = realpath(Prado::getPathOfNamespace('Storage.temp'));
			
			if (!is_dir($tmpdir))
				mkdir($tmpdir, '0777', true);
			
			$uploadedFile = $tmpdir . $this->FileChooseField->getFileName();
			$this->setViewState('uploadedFile', $uploadedFile);
			$this->FileChooseField->saveAs($uploadedFile);
   		}
	}

	public function IsPopup()
	{
		return true;
	}

}