<?php
/**
 * ShelfChangeItems class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.8.9
 * @package ShelfPlugins
 */

/**
 * ShelfChangeItems Class
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.8.9
 * @package ShelfPlugins
 * @since 2.1
 */

class ShelfChangeItems extends ClavisPlugin
{
	const DONTUPDATE = '--%%impossibIlescriverEunastringacosiACaso%%--';

	private $_clavisLibrarian;
	private $_actualLibraryId;

	public static function getTargetShelfTypes()
	{
		return array(ShelfPeer::TYPE_ITEM);
	}
	
	public static function getEditMode()
	{
		return ShelfPeer::EDITTYPE_EDIT;
	}
	
	private function initVars()
	{
		$this->_clavisLibrarian = $this->getUser();
		$this->_actualLibraryId = $this->_clavisLibrarian->getActualLibraryId();
	}

	public function onInit($param)
	{
		parent::onInit($param);
		$this->initVars();

		$isAdmin = $this->getUser()->getIsAdmin();
		
		if (!$this->getPage()->getIsCallBack())
		{
			$this->Section->setDBClass('ITEMSECTION');
			$this->Section->setLibraryId($this->_actualLibraryId);
			$this->Section->setHasBlank("true");
			$this->Section->setSorted(true);
			$this->Section->populateList();

			$this->ItemStatus->populate();
			$this->PhysicalStatus->populate();
			$this->LoanClass->populate();
			$this->MediaType->populate();
			$this->ItemIcon->populate();
			$this->ItemSource->populate();
			
			$this->ItemOrderStatus->populate();
						
			$invSerieDataSource = ($isAdmin
										? InventorySeriePeer::getAllLibrariesInventorySeries()
										: InventorySeriePeer::getInventorySeries($this->_actualLibraryId));
			
			$this->InvSerie->setDataSource($invSerieDataSource);
			$this->InvSerie->dataBind();
			
			if (LookupValuePeer::classExists('ITEMCUST1'))
			{
				$this->CustomDropDownList1->setVisible(true);
				$this->CustomDropDownList1->setDataSource(LookupValuePeer::getLookupClassValues('ITEMCUST1', true));
				$this->CustomDropDownList1->dataBind();
				$this->CustomTextBox1->setVisible(false);
			}
			else
			{
				$this->CustomDropDownList1->setVisible(false);
				$this->CustomTextBox1->setVisible(true);
			}
			
			if (LookupValuePeer::classExists('ITEMCUST2'))
			{
				$this->CustomDropDownList2->setVisible(true);
				$this->CustomDropDownList2->setDataSource(LookupValuePeer::getLookupClassValues('ITEMCUST2', true));
				$this->CustomDropDownList2->dataBind();
				$this->CustomTextBox2->setVisible(false);
			}
			else
			{
				$this->CustomDropDownList2->setVisible(false);
				$this->CustomTextBox2->setVisible(true);
			}

			if (LookupValuePeer::classExists('ITEMCUST3'))
			{
				$this->CustomDropDownList3->setVisible(true);
				$this->CustomDropDownList3->setDataSource(LookupValuePeer::getLookupClassValues('ITEMCUST3', true));
				$this->CustomDropDownList3->dataBind();
				$this->CustomTextBox3->setVisible(false);
			}
			else
			{
				$this->CustomDropDownList3->setVisible(false);
				$this->CustomTextBox3->setVisible(true);
			}
		}
	}

	public function setIsItemValid($valid = false)
	{
		$this->getApplication()->getSession()->add('IsItemValid', $valid, false);
	}

	public function getIsItemValid()
	{
		return $this->getApplication()->getSession()->itemAt('IsItemValid', false);
	}

	public function onAssign($sender, $param)
	{
		ini_set("memory_limit", "700M");
		set_time_limit(0);
		$this->getPage()->cleanMessageQueue();

		$shelfItems = $this->getCheckedItems();

		if ($this->OpacVisibilityCheck->getChecked())
		{
			$opacVisibility = ($this->OpacVisibility->getSelectedValue() == 'true');
		}
		else
		{
			$opacVisibility = self::DONTUPDATE;
		}

		if ($this->MediaTypeCheck->getChecked())
		{
			if ($this->MediaType->getSelectedIndex() != 0)
			{
				$mediaType = $this->MediaType->getSelectedValue();
			}
			else
			{
				$mediaType = null;
			}
		}
		else
		{
			$mediaType = self::DONTUPDATE;
		}

		if ($this->ItemIconCheck->getChecked())
		{
			if ($this->ItemIcon->getSelectedIndex() != 0)
			{
				$itemIcon = $this->ItemIcon->getSelectedValue();
			}
			else
			{
				$itemIcon = null;
			}
		}
		else
		{
			$itemIcon = self::DONTUPDATE;
		}

		if ($this->ItemStatusCheck->getChecked())
		{
			if ($this->ItemStatus->getSelectedIndex() != 0)
			{
				$itemStatus = $this->ItemStatus->getSelectedValue();
			}
			else
			{
				$itemStatus = null;
			}
		}
		else
		{
			$itemStatus = self::DONTUPDATE;
		}

		if ($this->ItemSourceCheck->getChecked())
		{
			if ($this->ItemSource->getSelectedIndex() != 0)
			{
				$itemSource = $this->ItemSource->getSelectedValue();
			}
			else
			{
				$itemSource = null;
			}
		}
		else
		{
			$itemSource = self::DONTUPDATE;
		}

		if ($this->ReprintCheck->getChecked())
		{
			$reprint = trim($this->Reprint->getSafeText());
		}
		else
		{
			$reprint = self::DONTUPDATE;
		}

		if ($this->VolumeTextCheck->getChecked())
		{
			$volumeText = trim($this->VolumeText->getSafeText());
		}
		else
		{
			$volumeText = self::DONTUPDATE;
		}

		if ($this->VolumeNumberCheck->getChecked())
		{
			$volumeNumber = trim($this->VolumeNumber->getSafeText());
		}
		else
		{
			$volumeNumber = self::DONTUPDATE;
		}

		if ($this->MediapackageSizeCheck->getChecked())
		{
			$mediapackageSize = trim($this->MediapackageSize->getSafeText());
		}
		else
		{
			$mediapackageSize = self::DONTUPDATE;
		}
		
		if ($this->ItemOrderStatusCheck->getChecked())
		{
			$itemOrderStatus = $this->ItemOrderStatus->getSelectedValue();
		}
		else
		{
			$itemOrderStatus = self::DONTUPDATE;
		}
		
		if ($this->ItemOrderCheck->getChecked())
		{
			$itemOrder = trim($this->ItemOrderId->getValue());
		}
		else
		{
			$itemOrder = self::DONTUPDATE;
		}
		
		if ($this->ItemInvoiceCheck->getChecked())
		{
			$itemInvoice = trim($this->ItemInvoiceId->getValue());
		}
		else
		{
			$itemInvoice = self::DONTUPDATE;
		}
		
		if ($this->ItemSupplierCheck->getChecked())
		{
			$itemSupplier = trim($this->ItemSupplierId->getValue());
		}
		else
		{
			$itemSupplier = self::DONTUPDATE;
		}
		
		if ($this->BudgetCheck->getChecked())
		{
			$budget = trim($this->BudgetId->getValue());
		}
		else
		{
			$budget = self::DONTUPDATE;
		}
		
		if ($this->PhysicalStatusCheck->getChecked())
		{
			if ($this->PhysicalStatus->getSelectedIndex() != 0)
			{
				$physicalStatus = $this->PhysicalStatus->getSelectedValue();
			}
			else
			{
				$physicalStatus = null;
			}
		}
		else
		{
			$physicalStatus = self::DONTUPDATE;
		}
		
		if ($this->LoanClassCheck->getChecked())
		{
			if ($this->LoanClass->getSelectedIndex() != 0)
			{
				$loanClass = $this->LoanClass->getSelectedValue();
			}
			else
			{
				$loanClass = null;
			}
		}
		else
		{
			$loanClass = self::DONTUPDATE;
		}

		if ($this->InvSerieCheck->getChecked())
		{
			if ($this->InvSerie->getSelectedIndex() != 0)
			{
				$inventorySerie = $this->InvSerie->getSelectedValue();
			}
			else
			{
				$inventorySerie = null;
			}
		}
		else
		{
			$inventorySerie = self::DONTUPDATE;
		}

		if ($this->SectionCheck->getChecked())
		{
			if ($this->Section->getSelectedIndex() != 0)
			{
				$section = $this->Section->getSelectedValue();
			}
			else
			{
				$section = null;
			}
		}
		else
		{
			$section = self::DONTUPDATE;
		}
		
		if ($this->CollocationCheck->getChecked())
		{
			$collocation = trim($this->Collocation->getSafeText());
		}
		else
		{
			$collocation = self::DONTUPDATE;
		}

		if ($this->SpecificationCheck->getChecked())
		{
			$specification = trim($this->Specification->getSafeText());
		}
		else
		{
			$specification = self::DONTUPDATE;
		}

		if ($this->Sequence1Check->getChecked())
		{
			$sequence1 = trim($this->Sequence1->getSafeText());
		}
		else
		{
			$sequence1 = self::DONTUPDATE;
		}

		if ($this->Sequence2Check->getChecked())
		{
			$sequence2 = trim($this->Sequence2->getSafeText());
		}
		else
		{
			$sequence2 = self::DONTUPDATE;
		}

		if ($this->LoanAlertNoteCheck->getChecked())
		{
			$loanAlertNote = trim($this->LoanAlertNote->getSafeText());
		}
		else
		{
			$loanAlertNote = self::DONTUPDATE;
		}

		// itemcustoms part
		$itemCustom1 = ($this->CustomCheck1->getChecked()
							? ($this->CustomTextBox1->getVisible()
									? trim($this->CustomTextBox1->getSafeText())
									: ($this->CustomDropDownList1->getSelectedIndex() > 0
											? $this->CustomDropDownList1->getSelectedValue()
											: ''))
							: self::DONTUPDATE);

		$itemCustom2 = ($this->CustomCheck2->getChecked()
							? ($this->CustomTextBox2->getVisible()
									? trim($this->CustomTextBox2->getSafeText())
									: ($this->CustomDropDownList2->getSelectedIndex() > 0
											? $this->CustomDropDownList2->getSelectedValue()
											: ''))
							: self::DONTUPDATE);
		
		$itemCustom3 = ($this->CustomCheck3->getChecked()
							? ($this->CustomTextBox3->getVisible()
									? trim($this->CustomTextBox3->getSafeText())
									: ($this->CustomDropDownList3->getSelectedIndex() > 0
											? $this->CustomDropDownList3->getSelectedValue()
											: ''))
							: self::DONTUPDATE);

		$skipLibraryCheck = $this->ForceAllCheck->getChecked();
		$skipDiscarded = $this->SkipDiscardedCheck->getChecked();
		
		$countDone = 0;
		$countFailed = [];
		$countNotAuthorized = [];
		$countAlreadyDiscarded = [];
		$countNotHome = [];
		$countNotOwner = [];
		$missingItems = [];
		
		if (count($shelfItems) > 0)
		{
			foreach ($shelfItems as $shelfItem)
			{
				if (!is_null($shelfItem))
				{
					if ($shelfItem->getObjectClass() == ShelfPeer::TYPE_ITEM)
					{
						$item = null;
						$itemId = $shelfItem->getObjectId();
						
						if ($itemId > 0)
						{	
							$item = ItemQuery::create()
										->findPk($itemId);
						}
						
						if ($item instanceof Item)
						{
							if ($skipDiscarded
									&& ($item->getItemStatus() == ItemPeer::getItemStatusDiscarded()))
							{
								$countAlreadyDiscarded[] = $itemId;
							}
							else
							{
								if ($this->_clavisLibrarian->getEditPermission($item))		// we are allowed to modify that item
								{
									// first step
									if ($skipLibraryCheck
											|| ($item->getHomeLibraryId() == $this->_actualLibraryId))
									{
										$returnCodeHomeDoFlag = $this->updateItemDataWithHomePermission(	$item, 
																											$section, 
																											$collocation, 
																											$specification, 
																											$sequence1, 

																											$sequence2, 
																											$itemStatus,
																											$physicalStatus,
																											$loanClass, 
																											$opacVisibility, 

																											$mediaType,
																											$itemIcon,
																											$loanAlertNote,
																											$itemCustom1,
																											$itemCustom2,

																											$itemCustom3,
																											$itemSource,
																											$reprint,
																											$volumeText,
																											$volumeNumber,

																											$mediapackageSize,
																											$itemOrderStatus,
																											$itemOrder,
																											$itemInvoice,
																											$itemSupplier,

																											$budget);
									}
									else
									{
										$countNotHome[] = $itemId;
										$returnCodeHomeDoFlag = false;
									}

									// second step
									if ($skipLibraryCheck
											|| ($item->getOwnerLibraryId() == $this->_actualLibraryId))
									{
										$returnCodeOwnerDoFlag = $this->updateItemDataWithOwnerPermission(	$item, 
																											$inventorySerie);
									}
									else
									{
										$countNotOwner[] = $itemId;
										$returnCodeOwnerDoFlag = false;
									}

									if (($returnCodeHomeDoFlag)
											|| $returnCodeOwnerDoFlag)
									{
										try
										{
											$item->save();
											$countDone++;

											ChangelogPeer::logAction(	$item, 
																		ChangelogPeer::LOG_UPDATE, 
																		$this->_clavisLibrarian,
																		'Plugin su Shelf [' . $this->getShelfId() . ']: cambio dati per esemplare con id=' . $item->getItemId());
										}
										catch (PropelException $exception)
										{
											$countFailed[] = $itemId;

											//Prado::log('Plugin ShelfChangeItems, errore: ' . $exception->getCause()->getMessage());
										}
									}
								}	// end of 'we are authorized in modify that item'
								else
								{
									$countNotAuthorized[] = $itemId;
								}
							}
							
							unset ($item);
						}		// if a real item exists
						else	// if no item exists for that item_id
						{
							$missingItems[] = $itemId;
						}
					}	// if the cycled object is an item type
				}
				
				unset ($shelfItem);
			}
			
			if (count($missingItems) > 0)
			{
				$this->getPage()->enqueueMessage(Prado::localize("Attenzione: ci sono esemplari non validi o non più esistenti, con id: {itemids}",
																	array('itemids' =>  implode(',', $missingItems) )),
													ClavisMessage::WARNING);
			}
		}

		$refreshFlag = false;
		
		// if no action has succeeded
		if (	$countDone 
				+ count($countFailed)
				+ count($countNotAuthorized)
				+ count($countAlreadyDiscarded)
				+ count($countNotHome)
				
				+ count($countNotOwner) == 0)
		{
			$this->getPage()->enqueueMessage(Prado::localize('Nessuna azione eseguita'),
												ClavisMessage::INFO);
		}
		else	// some actions or errors occurred
		{
			if ($countDone > 0)
			{	
				$this->getPage()->enqueueMessage(Prado::localize("N. {count} esemplari modificati con successo",
																	array('count' => $countDone)),
													ClavisMessage::CONFIRM);
				
				$refreshFlag = true;
			}

			if (count($countNotHome) > 0)
			{
				$this->getPage()->enqueueMessage(Prado::localize("Alcuni esemplari non sono stati modificati perché non gestiti della biblioteca attuale, e i loro id sono: {itemids}",
																	array('itemids' => implode(',', $countNotHome))),
													ClavisMessage::WARNING);
			}

			if (count($countNotOwner) > 0)
			{
				$this->getPage()->enqueueMessage(Prado::localize("Alcuni esemplari non sono stati modificati nella serie inventariale perché non gestiti della biblioteca attuale, e i loro id sono: {itemids}",
																	array('itemids' => implode(',', $countNotOwner))),
													ClavisMessage::WARNING);
			}

			if (count($countNotAuthorized) > 0)
			{
				$this->getPage()->enqueueMessage(Prado::localize("Alcuni esemplari non sono stati modificati per mancanza di autorizzazione, e i loro id sono: {itemids}",
																	array('itemids' => implode(',', $countNotAuthorized))),
													ClavisMessage::ERROR);
			}

			if (count($countAlreadyDiscarded) > 0)
			{
				$this->getPage()->enqueueMessage(Prado::localize("Alcuni esemplari non sono stati modificati perchè sono già in stato di 'scartato, e i loro id sono: {itemids}",
																	array('itemids' => implode(',', $countAlreadyDiscarded))),
													ClavisMessage::WARNING);				
			}
			
			if (count($countFailed) > 0)
			{
				$errorCode = ClavisMessage::ERROR;
				$this->getPage()->enqueueMessage(Prado::localize("Alcuni esemplari non sono stati modificati a causa di un errore, e i loro id sono: {itemids}",
																	array('itemids' => implode(',', $countFailed))),
													ClavisMessage::ERROR);
			}
		}
		
		if (	($countDone > 0)
				&& (count($countFailed) == 0)
				&& (count($countNotAuthorized) == 0)
				&& (count($countAlreadyDiscarded) == 0)
				&& (count($countNotHome) == 0)
				&& (count($countNotOwner) == 0))
		{
			// close popup
			$this->getPage()->flushDelayedMessage();
			$this->onClose();
		}
		else
		{
			// stay open
			$this->getPage()->flushMessage();
			
			if ($refreshFlag)
				$this->getPage()->shelfListRefresh($param);
		}
	}

	public function IsPopup()
	{
		return true;
	}

	private function updateItemDataWithHomePermission(	&$item, 
														$section, 
														$collocation, 
														$specification, 
														$sequence1, 

														$sequence2, 
														$itemStatus,
														$physicalStatus,
														$loanClass, 
														$opacVisibility,

														$mediaType,
														$itemIcon,
														$loanAlertNote,
														$itemCustom1,
														$itemCustom2,
			
														$itemCustom3,
														$itemSource,
														$reprint,
														$volumeText,
														$volumeNumber,

														$mediapackageSize,
														$itemOrderStatus,
														$itemOrder,
														$itemInvoice,
														$itemSupplier,

														$budget)
	{
		/* @var $item Item */
		$actionDoneFlag = false;

		if ($section !== self::DONTUPDATE)
		{
			$item->setSection($section);
			$actionDoneFlag = true;
		}

		if ($collocation !== self::DONTUPDATE)
		{
			$item->setCollocation($collocation);
			$actionDoneFlag = true;
		}

		if ($specification !== self::DONTUPDATE)
		{
			$item->setSpecification($specification);
			$actionDoneFlag = true;
		}

		if ($sequence1 !== self::DONTUPDATE)
		{
			$item->setSequence1($sequence1);
			$actionDoneFlag = true;
		}

		if ($sequence2 !== self::DONTUPDATE)
		{
			$item->setSequence2($sequence2);
			$actionDoneFlag = true;
		}

		$forceLoanClassUnavailable = false;
		
		if ($itemStatus !== self::DONTUPDATE)
		{
			$item->setItemStatus($itemStatus);
			$actionDoneFlag = true;
			
			if ($itemStatus == ItemPeer::getItemStatusDiscarded())
				$forceLoanClassUnavailable = true;
		}

		if ($forceLoanClassUnavailable)
		{
			$item->setLoanClass(ItemPeer::LOANCLASS_UNAVAILABLE);
			$actionDoneFlag = true;
		}
		elseif ($loanClass !== self::DONTUPDATE)
		{
			$item->setLoanClass($loanClass);
			$actionDoneFlag = true;
		}
		
		if ($physicalStatus !== self::DONTUPDATE)
		{
			$item->setPhysicalStatus($physicalStatus);
			$actionDoneFlag = true;
		}

		if ($opacVisibility !== self::DONTUPDATE)
		{
			$item->setOpacVisible($opacVisibility);
			$actionDoneFlag = true;
		}

		if ($mediaType !== self::DONTUPDATE)
		{
			$item->setItemMedia($mediaType);
			$actionDoneFlag = true;
		}

		if ($itemIcon !== self::DONTUPDATE)
		{
			$item->setItemIcon($itemIcon);
			$actionDoneFlag = true;
		}

		if ($loanAlertNote !== self::DONTUPDATE)
		{
			$item->setLoanAlertNote($loanAlertNote);
			$actionDoneFlag = true;
		}

		if ($itemCustom1 !== self::DONTUPDATE)
		{
			$item->setCustomField1($itemCustom1);
			$actionDoneFlag = true;
		}

		if ($itemCustom2 !== self::DONTUPDATE)
		{
			$item->setCustomField2($itemCustom2);
			$actionDoneFlag = true;
		}

		if ($itemCustom3 !== self::DONTUPDATE)
		{
			$item->setCustomField3($itemCustom3);
			$actionDoneFlag = true;
		}

		if ($itemSource !== self::DONTUPDATE)
		{
			$item->setItemSource($itemSource);
			$actionDoneFlag = true;
		}

		if ($reprint !== self::DONTUPDATE)
		{
			$item->setReprint($reprint);
			$actionDoneFlag = true;
		}

		if ($volumeText !== self::DONTUPDATE)
		{
			$item->setVolumeText($volumeText);
			$actionDoneFlag = true;
		}

		if ($volumeNumber !== self::DONTUPDATE)
		{
			$item->setVolumeNumber($volumeNumber);
			$actionDoneFlag = true;
		}

		if ($mediapackageSize !== self::DONTUPDATE)
		{
			$item->setMediapackageSize($mediapackageSize);
			$actionDoneFlag = true;
		}

		if ($itemOrderStatus !== self::DONTUPDATE)
		{
			$item->setItemOrderStatus($itemOrderStatus);
			$actionDoneFlag = true;
		}

		if ($itemOrder !== self::DONTUPDATE)
		{
			$item->setOrderId($itemOrder);
			$actionDoneFlag = true;
		}

		if ($itemInvoice !== self::DONTUPDATE)
		{
			$item->setInvoiceId($itemInvoice);
			$actionDoneFlag = true;
		}

		if ($itemSupplier !== self::DONTUPDATE)
		{
			$item->setSupplierId($itemSupplier);
			$actionDoneFlag = true;
		}

		if ($budget !== self::DONTUPDATE)
		{
			$item->setBudgetId($budget);
			$actionDoneFlag = true;
		}
		
		return $actionDoneFlag;
	}

	private function updateItemDataWithOwnerPermission(	&$item, 
														$inventorySerieId)
	{
		/* @var $item Item */
		
		$actionDoneFlag = false;

		if ($inventorySerieId !== self::DONTUPDATE)
		{
			$item->setInventorySerieId($inventorySerieId);
			$actionDoneFlag = true;
		}

		return $actionDoneFlag;
	}
		
	public function onOrderChanged($sender, $param)
 	{
 		$order = null;
 		$id = intval($this->ItemOrderId->getValue());
 		if ($id > 0)
 			$order = PurchaseOrderQuery::create()->findPK($id);
 		if ($order instanceof PurchaseOrder)
 		{
			$this->ItemOrder->setText($order->getOrderId().' ('.$order->getOrderDate('Y/m/d').')');
			$this->ItemOrder->setNavigateUrl($this->getService()->constructUrl(	'Acquisition.OrderViewPage',
																				array('id' => $order->getOrderId())));
			
			$this->ItemOrder->setEnabled(true);
 			$this->setOrderChoiceDone(true, $param);
 		}
		else
		{
			$this->doResetOrder($param);
		}
 	}
	
	public function onResetOrder($sender, $param)
	{
		$this->doResetOrder($param);
	}

	private function doResetOrder($param = null)
	{
		$this->ItemOrder->setText(Prado::localize('nessun ordine'));
		$this->ItemOrder->setNavigateUrl('');
		$this->ItemOrderId->setValue('');
		$this->setOrderChoiceDone(false, $param);
	}
	
 	public function setOrderChoiceDone($flag, $param = null)
 	{
		$this->OrderResetButton->setVisible($flag);

		if ($this->getPage()->getIsCallback())
			$this->renderOrderPanel($param);
 	}
	
	public function renderOrderPanel($param = null)
	{
		if (is_null($param))
			$writer = $this->createWriter();
		else
			$writer = $param->getNewWriter();

		$this->OrderPanel->render($writer);
	}

	public function onInvoiceChanged($sender, $param)
 	{
		$invoice = InvoiceQuery::create()->findPK(intval($this->ItemInvoiceId->getValue()));
 		if ($invoice instanceof Invoice)
 		{
 			$this->ItemInvoice->setText($invoice->getInvoiceCompleteLabel());
			$this->ItemInvoice->setNavigateUrl($this->getService()->constructUrl(	'Acquisition.InvoiceViewPage',
																					array('id' => $invoice->getInvoiceId())));
			$this->ItemInvoice->setEnabled(true);
 			$this->setInvoiceChoiceDone(true, $param);
			//$this->_invoiceClosedFlag = ($invoice->getInvoiceStatus() != InvoicePeer::INVOICESTATUS_OPEN);
			//$this->setPurchaseEditEnabledStatus();
 		}
		else
		{
			$this->doResetInvoice($param);
		}
 	}
	
	public function onResetInvoice($sender, $param)
	{
		$this->doResetInvoice($param);
	}

	private function doResetInvoice($param = null)
	{
		$this->ItemInvoice->setText(Prado::localize('nessuna fattura'));
		$this->ItemInvoice->setNavigateUrl('');
		$this->ItemInvoiceId->setValue('');
		$this->setInvoiceChoiceDone(false, $param);
	}
	
 	public function setInvoiceChoiceDone($flag, $param = null)
 	{
		$this->InvoiceResetButton->setVisible($flag);

		if ($this->getPage()->getIsCallback())
			$this->renderInvoicePanel($param);
 	}
	
	public function renderInvoicePanel($param = null)
	{
		if (is_null($param))
			$writer = $this->createWriter();
		else
			$writer = $param->getNewWriter();

		$this->InvoicePanel->render($writer);
	}
	
	public function onSupplierChanged($sender, $param)
 	{
 		$supplier = null;
 		$id = intval($this->ItemSupplierId->getValue());
 		if ($id > 0)
 			$supplier = SupplierQuery::create()->findPK($id);
 		if ($supplier instanceof Supplier)
		{
			/*
			$discount = $supplier->getDiscount();
		
			if (!is_null($discount))
				$this->calculateItemValueServerSide($discount);
			*/
			
 			$this->ItemSupplier->setText($supplier->getSupplierName());
			$this->ItemSupplier->setNavigateUrl($this->getService()->constructUrl(	'Acquisition.SupplierInsertPage',
																					array('supplierId' => $supplier->getSupplierId())));
			$this->ItemSupplier->setText($supplier->getSupplierName());
			$this->ItemSupplier->setEnabled(true);
			
 			$this->setSupplierChoiceDone(true, $param);
 		}
		else
		{
			$this->doResetSupplier($param);
		}
 	}
	
	public function onResetSupplier($sender, $param)
	{
		$this->doResetSupplier($param);
	}

	private function doResetSupplier($param = null)
	{
		$this->ItemSupplier->setText(Prado::localize('nessun fornitore'));
		$this->ItemSupplier->setNavigateUrl('');
		$this->ItemSupplierId->setValue('');
		$this->setSupplierChoiceDone(false, $param);
	}
	
 	public function setSupplierChoiceDone($flag, $param = null)
 	{
		$this->SupplierResetButton->setVisible($flag);

		if ($this->getPage()->getIsCallback())
			$this->renderSupplierPanel($param);
 	}

	public function renderSupplierPanel($param = null)
	{
		if (is_null($param))
			$writer = $this->createWriter();
		else
			$writer = $param->getNewWriter();

		$this->SupplierPanel->render($writer);
	}	
	
	public function onBudgetChanged($sender, $param)
 	{
 		$budget = null;
 		$id = intval($this->BudgetId->getValue());
 		if ($id > 0)
 			$budget = BudgetQuery::create()->findPK($id);
 		if ($budget instanceof Budget)
 		{
			$this->BudgetLink->setText($budget->getCompleteBudgetTitle());
			$this->BudgetLink->setNavigateUrl($this->getService()->constructUrl(	'Acquisition.BudgetViewPage',
																					array('id' => $budget->getBudgetId())));
			
			$this->BudgetLink->setEnabled(true);
			$this->setBudgetChoiceDone(true, $param);
 		}
		else
		{
			$this->doResetBudget($param);
		}
 	}
	
	public function onResetBudget($sender, $param)
	{
		$this->doResetBudget($param);
	}

	private function doResetBudget($param = null)
	{
		$this->BudgetLink->setText(Prado::localize('nessun budget'));
		$this->BudgetLink->setNavigateUrl('');
		$this->BudgetId->setValue('');
		$this->setBudgetChoiceDone(false, $param);
	}
	
 	public function setBudgetChoiceDone($flag, $param = null)
 	{
		$this->BudgetResetButton->setVisible($flag);

		if ($this->getPage()->getIsCallback())
			$this->renderBudgetPanel($param);
 	}
	
	public function renderBudgetPanel($param = null)
	{
		if (is_null($param))
			$writer = $this->createWriter();
		else
			$writer = $param->getNewWriter();

		$this->BudgetPanel->render($writer);
	}
	
}