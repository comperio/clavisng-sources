<?php
/**
 * ShelfChangeItemsDiscard class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package ShelfPlugins
 */

/**
 * ShelfChangeItemsDiscard Class
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.7
 * @package ShelfPlugins
 * @since 2.1
 */

class ShelfChangeItemsDiscard extends ClavisPlugin
{
	private $_clavisLibrarian;

	public static function getTargetShelfTypes()
	{
		return array(ShelfPeer::TYPE_ITEM);
	}
	
	public static function getEditMode()
	{
		return ShelfPeer::EDITTYPE_EDIT;
	}
	
	private function initVars()
	{
		$this->_clavisLibrarian = $this->getUser();
	}

	public function onInit($param)
	{
		parent::onInit($param);
		
		$this->initVars();
	}

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsCallBack())
		{
			$this->LibrariesFilter->setDatasource(	LibraryPeer::getLibrariesHash(	array(LibraryPeer::BLANKVALUE,
																						LibraryPeer::EXCLUDEMYLIBRARY),
														
																						array(	'---',
																								'<' . Prado::localize('tutte tranne la mia') . '>')));
			$this->LibrariesFilter->dataBind();
		}
	}

	public function setLibrariesFilterValue($param = null)
	{
		$this->getApplication()->getSession()->add('LibrariesFilter', $param);
	}

	public function getLibrariesFilterValue()
	{
		return $this->getApplication()->getSession()->itemAt('LibrariesFilter');
	}

	public function onAssign($sender, $param)
	{
		ini_set("memory_limit", "700M");
		set_time_limit(0);
		
		$shelfItems = $this->getCheckedItems();
		$libraryFilter = intval($this->LibrariesFilter->getSelectedValue());

		if ($libraryFilter < 1)
			$libraryFilter = null;

		$countDone = 0;
		$countFailed = 0;
		$countNotAuthorized = 0;

		if (count($shelfItems) > 0)
		{
			foreach ($shelfItems as $shelfItem)
			{
				if ($shelfItem instanceof ShelfItem)
				{
					if ($shelfItem->getObjectClass() == ShelfPeer::TYPE_ITEM)
					{
						$item = null;
						$itemId = $shelfItem->getObjectId();
						if ($itemId > 0)
							$item = ItemQuery::create()
											->findPk($itemId);
						
						if ($item instanceof Item)
						{
							if (!$this->_clavisLibrarian->getEditPermission($item))
								$countNotAuthorized++;
							else
							{
								$allowed = is_null($libraryFilter)
													? true
													: ($item->getOwnerLibraryId() == $libraryFilter);
								
								if ($allowed)
								{
									try
									{
										$timestamp = $this->DiscardDate->getTimeStamp();
										if (!$timestamp)
											$timestamp = time();
									
										$item->setDateDiscarded($timestamp);
										$item->setDiscardNote($this->DiscardNote->getText());
										$item->setLoanClass(ItemPeer::LOANCLASS_UNAVAILABLE);
										$item->setItemStatus(ItemStatus::ITEMSTATUS_DISCARDED);
										
										$item->save();
										$countDone++;
										
										ChangelogPeer::logAction(	$item,
																	ChangelogPeer::LOG_UPDATE,
																	$this->_clavisLibrarian,
																	'Plugin su scaffale con id: ' . $this->getShelfId() . ', esemplare con id:'
																		. $item->getItemId() . ' messo in stato di '
																		. LookupValuePeer::getLookupValue('ITEMSTATUS', ItemStatus::ITEMSTATUS_DISCARDED));
									}
									catch (PropelException $exception)
									{
										$errorMessage = $exception->getCause()->getMessage();
										Prado::log('Plugin ShelfChangeItemsDiscarded, errore: ' . $errorMessage);
										$countFailed++;
									}
								}
							}
						}
						else
						{
							$this->getPage()->writeDelayedMessage(Prado::localize("Errore"),
																	ClavisMessage::ERROR);
						}
					}
				}
			}
		}

		$this->getPage()->writeDelayedMessage((1 == $countDone)
													? Prado::localize('1 esemplare messo in stato di scartato')
													: Prado::localize('{count} esemplari messi in stato di scartato',
																		array('count' => $countDone)),
												($countDone > 0
													? ClavisMessage::INFO
													: ClavisMessage::WARNING));

		if ($countFailed > 0)
			$this->getPage()->writeDelayedMessage((1 == $countFailed)
														? Prado::localize('1 esemplare non modificato')
														: Prado::localize('{count} esemplari non modificati',
																			array('count' => $countFailed)),
													ClavisMessage::ERROR);

		if ($countNotAuthorized > 0)
			$this->getPage()->writeDelayedMessage((1 == $countNotAuthorized)
														? Prado::localize('1 esemplare non modificato perché non si possiede l\'autorizzazione necessaria.')
														: Prado::localize('{count} esemplari non modificati perché non si possiede l\'autorizzazione necessaria.',
																			array('count' => $countNotAuthorized)),
													ClavisMessage::ERROR);

		$this->onClose();
	}


	public function IsPopup()
	{
		return true;
	}
}