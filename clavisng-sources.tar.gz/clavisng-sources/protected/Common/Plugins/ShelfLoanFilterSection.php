<?php
/**
 * ShelfContentFilterLoan class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package ShelfPlugins
 */

/**
 * ShelfContentFilterLoan Class
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.7
 * @package ShelfPlugins
 * @since 2.1
 */
class ShelfLoanFilterSection extends ClavisPlugin
{
	private $_clavisLibrarian;

	private function initVars()
	{
		$this->_clavisLibrarian = $this->getUser();
	}

	public function onInit($param)
	{
		parent::onInit($param);
		$this->initVars();

		if (!$this->getPage()->getIsCallBack())
		{
			$this->Section->setDBClass("ITEMSECTION");
			$this->Section->setLibraryId($this->getUser()->getActualLibraryId());
			$this->Section->setHasBlank("true");
			$this->Section->setSorted(true);
			$this->Section->populateList();

			$this->ActionChoice->setDataSource(array(	'1' => Prado::localize('tieni'),
														'2' => Prado::localize('cancella')) );
		}
	}

	public function setIsItemValid($valid = false)
	{
		$this->getApplication()->getSession()->add('IsItemValid', $valid, false);
	}

	public function getIsItemValid()
	{
		return $this->getApplication()->getSession()->itemAt('IsItemValid', false);
	}

	public function onAction($sender, $param)
	{
		$shelfItems = $this->getCheckedItems();

		if ($this->Section->getSelectedIndex() <= 0)
		{
			$this->getPage()->writeMessage(Prado::localize("Nessuna sezione selezionata"),
												ClavisMessage::WARNING);
			
			return false;
		}

		$section = $this->Section->getSelectedValue();
		$actionChoice = $this->ActionChoice->getSelectedValue();   // 1 -> tieni,  2 -> cancella

		$countDone = 0;
		$countFailed = 0;

		if (count($shelfItems) > 0)
		{
			foreach ($shelfItems as $shelfItem)
			{
				if (!is_null($shelfItem))
				{
					if ($shelfItem->getObjectClass() == ShelfPeer::TYPE_LOAN)
					{
						$loan = null;
						$loanId = $shelfItem->getObjectId();
						if ($loanId > 0)
							$loan = LoanQuery::create()
										->findPk($loanId);
						if ($loan instanceof Loan)
						{
							$item = $loan->getItem();
							if ($item instanceof Item)
							{
								$itemSection = $item->getSection();

								if ((($itemSection == $section) && ($actionChoice == '2'))
										|| (($itemSection != $section) && ($actionChoice == '1')))
								{
									try
									{
										ShelfItemPeer::doDelete($shelfItem);
										$countDone++;
									}
									catch (PropelException $exception)
									{
										$countFailed++;
										///throw ($exception);
									}
								}
							}
							else
							{
								$this->getPage()->writeMessage(Prado::localize("Errore sui dati dell'esemplare "),
																	ClavisMessage::ERROR);
								return false;
							}

						}
						else
						{
							$this->getPage()->writeMessage(Prado::localize("Errore sui dati del prestito "),
																ClavisMessage::ERROR);
							return false;
						}
					}
				}
			}
		}

		$errorCode = ClavisMessage::ERROR;
		if (($countDone == 0)
				&& ($countFailed == 0))
			$errorCode = ClavisMessage::INFO;
		else
		{
			if (($countFailed > 0))
				$errorCode = ClavisMessage::WARNING;
			else
				$errorCode = ClavisMessage::CONFIRM;
		}

		$messageText = Prado::localize("Non è stata eseguita nessuna azione");

		if ($countDone > 0)
			$messageText = ($countDone == 1)
				? Prado::localize('1 elemento filtrato')
				: Prado::localize('{count} elementi filtrati',
					array('count'=>$countDone));

		if ($countFailed > 0)
			$messageText .= ($messageText != '' ? '&nbsp;&nbsp;&nbsp;&nbsp;<br /><br />' : '') .
				($countFailed == 1)
					? Prado::localize('1 elemento NON filtrato per errore sconosciuto')
					: Prado::localize('{count} elementi NON filtrati per errore sconosciuto',
						array('count'=>$countFailed));

		if ($countDone > 0)
			$this->getPage()->shelfListRefresh($param);

		$this->getPage()->writeDelayedMessage($messageText, $errorCode);
		$this->onClose();
	}


	public function IsPopup()
	{
		return true;
	}
	
}