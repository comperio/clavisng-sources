<?php
/**
 * ShelfManifestationLink class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.8.7
 * @package ShelfPlugins
 */

/**
 * ShelfManifestationLink Class
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.8.7
 * @package ShelfPlugins
 * @since 2.8.7
 */

class ShelfManifestationLink extends ClavisPlugin
{
	private $_clavisLibrarian;

	private function initVars()
	{
		$this->_clavisLibrarian = $this->getUser();
	}

	public function onInit($param)
	{
		parent::onInit($param);
		
		$this->initVars();

		if ( !$this->getPage()->getIsCallBack())
		{
//			$this->ManLevel->setDataSource(LookupValueQuery::create()
//									->filterByValueLanguage($this->getApplication()->getGlobalization()->getCulture())
//									->filterByValueClass('CATLEVEL')
//									->filterByValueKey($this->getUser()->getLibrarian()->getCatLevel(),Criteria::LESS_EQUAL)
//									->find());
//			
//			$this->ManLevel->dataBind();
			
			$this->populateLinkDropDown();
		}
	}

	public function setIsItemValid($valid = false)
	{
		$this->getApplication()->getSession()->add('IsItemValid', $valid, false);
	}

	public function getIsItemValid()
	{
		return $this->getApplication()->getSession()->itemAt('IsItemValid', false);
	}

	public function IsPopup()
	{
		return true;
	}

	public function onSuggestAuthority($sender, $param)
	{
		$prefix = $param->getToken();

		$this->AuthLinkChooser->setParam(urlencode($prefix));
		$this->authLinkTypeChanged($sender, $param);

		$authList = ('true' == ClavisParamQuery::getParam('CLAVISPARAM', 'AllTermsAsSubjects'))
									? AuthorityPeer::doSuggest($prefix, 10) 
									: AuthorityPeer::doSuggest($prefix, 10, $this->_authLinkTypesAllowed);

		$authData = array();

		/* @var $auth Authority */
		foreach ($authList as $auth)
		{	
			$authData[] = array(	'id' => $auth->getAuthorityId(),
									'text' => $auth->getFullTextSpec() );
		}
		
		$sender->setDataSource($authData);
		$sender->dataBind();
	}

	public function onSuggestSelectAuthority($sender, $param)
	{
		$id = $sender->Suggestions->DataKeys[$param->selectedIndex];
		$a = AuthorityQuery::create()->findPk($id);
		$a = $a->getAcceptedAuthority();
		
		if ($a instanceof Authority)
		{
			// the str_replace is needed for authorities can have &lt; instead of <,
			// in sort_text.
			$sender->setText(trim(str_replace('&lt;', '<', $a->getFullText())));
			$this->AuthorityID->setValue($a->getAuthorityId());
			$this->setAutoLinkType($sender, $param, $a);
		}
		else
		{
			$sender->setText('');
			$this->AuthorityID->setValue(null);
		}
	}
	
	public function setAutoLinkType($sender, $param, $a = null)
	{
		$this->populateLinkDropDown($a);
		/* correctly update params for Create */
		$this->AuthLinkChooser->setParam($this->NewAuthLink->getText());
		$this->authLinkTypeChanged($sender, $param);
	}

	public function authLinkTypeChanged($sender, $param)
	{
		switch ($this->LinkType->getSelectedValue())
		{
			case '616':
				$val = AuthorityPeer::TYPE_TRADEMARK;
				break;
			
			case '620':
				$val = AuthorityPeer::TYPE_PUBPLACE;
				break;
			
			case '676':
				$val = AuthorityPeer::TYPE_CLASS;
				break;
			
			case '500':
				$val = AuthorityPeer::TYPE_WORK;
				break;
			
			case '921':
				$val = AuthorityPeer::TYPE_PRINTERSDEVICE;
				break;
			
			case '700': 
			case '702': 
			case '701':
				$val = AuthorityPeer::TYPE_PERSONALNAME;
				break;
			
			default:
				$val = AuthorityPeer::TYPE_SUBJECT;
				break;
		}

	
		////$this->NewAuthPanel->render($param->getNewWriter());
		//$this->AuthLinkChooser->setObjectType($val);
		//$this->AuthLinkChooser->render($param->getNewWriter());
 

	}
	
	private function calculateLinkDropDown($a = null)
	{
		if (!$a instanceof Authority)
			$a = AuthorityQuery::create()->findPk(intval($this->AuthorityID->getValue()));

		$select = null;
		
		if ((!$a instanceof Authority) 
				|| ($a->getAuthorityRectype() == AuthorityPeer::RECTYPE_NODE))
		{
			$this->AuthorityID->setValue('');
			$this->NewAuthLink->setText('');
			$fldlist = array(700, 702, 701, 610, 609, 619, 620, 676, 500, 921);
		}
		else
		{
			switch ($a->getAuthorityType())
			{
				case AuthorityPeer::TYPE_TRADEMARK:
					$fldlist = array(616, 619);
					$select = '616';
					break;
				
				case AuthorityPeer::TYPE_PUBPLACE:
					$fldlist = array(620, 619);
					$select = '620';
					break;
				
				case AuthorityPeer::TYPE_CLASS:
					$fldlist = array(676, 619);
					$select = '676';
					break;
				
				case AuthorityPeer::TYPE_WORK:
					$fldlist = array(500, 619);
					$select = '500';
					break;
				
				case AuthorityPeer::TYPE_PRINTERSDEVICE:
					$fldlist = array(921, 619);
					$select = '921';
					break;
				
				case AuthorityPeer::TYPE_PERSONALNAME:
				case AuthorityPeer::TYPE_CORPORATEBODYNAME:
				case AuthorityPeer::TYPE_FAMILYNAME:
					$fldlist = array(700, 702, 701, 610, 609, 619);
					
					/**
					if ($this->getRecordHasMainAuthor())
						$fldlist = array_diff($fldlist, array(700));
					
					if ($this->getRecordHasAltAuthors())
						$fldlist = array_diff($fldlist, array(701));
					
					 * 
					 */
					
					break;
					
				default:
					$fldlist = array(610, 609, 619);
					break;
			}
		}
		
		$options = LookupValuePeer::getLookupClassValues('LINKTYPE');
		$ds = array();
		
		foreach ($fldlist as $fld)
			$ds[$fld] = $options[$fld];
		
		return array($ds, $select);
	}
	
	public function populateLinkDropDown($a = null)
	{
		list($ds, $select) = $this->calculateLinkDropDown($a);

		$this->LinkType->setDataSource($ds);
		$this->LinkType->dataBind();

		if (!$select)
		{
			$this->LinkType->setSelectedIndex(0);
		}
		else
		{
			$this->LinkType->setSelectedValue($select);
		}
	}
	
	public function onAssign($sender, $param)
	{
		ini_set("memory_limit", "700M");
		set_time_limit(0);
		$this->getPage()->cleanMessageQueue();

		$shelfItems = $this->getCheckedItems();

		$authority = null;
		$authorityId = intval($this->AuthorityID->getValue());
		
		if ($authorityId > 0)
			$authority = AuthorityQuery::create()->findPk($authorityId);
		
		if ($authority instanceof Authority)
		{
			$linkType = $this->LinkType->getSelectedValue();
			$relatorCode = $this->RelatorCode->getSelectedValue();
			$linkNote = trim($this->LinkNote->getSafeText());
			
			$countDone = 0;
			$countFailed = 0;
			$countNotAuthorized = 0;

			/// begin of cycle upon the shelf objects
			if (count($shelfItems) > 0)
			{
				foreach ($shelfItems as $shelfItem)
				{
					if (($shelfItem instanceof ShelfItem)
							&& ($shelfItem->getObjectClass() == ShelfPeer::TYPE_MANIFESTATION))	// only manifestations
					{
						$manifestation = null;
						$manifestationId = $shelfItem->getObjectId();

						if ($manifestationId > 0)
							$manifestation = ManifestationQuery::create()->findPk($manifestationId);

						if ($manifestation instanceof Manifestation)
						{
							if (!$this->_clavisLibrarian->getEditPermission($manifestation))
							{
								$countNotAuthorized++;
							}
							else
							{
								$returnCode = $this->doNewLink(	$manifestation, 
																$authority,
																$linkType,
																$relatorCode,
																$linkNote );
								
								switch ($returnCode)
								{
									case true:
										
										$countDone++;
//										ChangelogPeer::logAction(	$manifestation,
//																	ChangelogPeer::LOG_UPDATE,
//																	$this->_clavisLibrarian,
//																	"Cambio dati da plugin alla notizia con id=" . $manifestation->getManifestationId());

										break;
								
									case false:
									default:
										$countFailed++;
										
										break;
								}
							
							}
						}
						else
						{
							$this->getPage()->enqueueMessage(Prado::localize("La notizia con id={id} non esiste",
																				array('id' => $manifestationId)),
																ClavisMessage::ERROR);
						}
					}

					////$shelfItem->clearAllReferences(true);	 do we need it? .......
					unset ($shelfItem);
				}
			}
			/// end of cycle upon the shelf objects

			if (($countDone == 0)
					&& ($countFailed == 0)
					&& ($countNotAuthorized == 0))
			{
				$this->getPage()->enqueueMessage(Prado::localize("Nessuna azione eseguita"),
													ClavisMessage::INFO);

				$this->getPage()->flushMessage();
			}
			else
			{
				if ($countDone > 0)
				{
					$this->getPage()->enqueueMessage(Prado::localize("L'authority selezionata ('{authTitle}', id={authId}) è stata collegata a {count} notizie dello scaffale '{shelfName}', id={shelfId}",
																		array(	'authTitle' => $authority->getCompleteText(),
																				'authId' => $authorityId,
																				'count' => $countDone,
																				'shelfName' => $this->getShelf()->getShelfName(),
																				'shelfId' => $this->getShelf()->getShelfId() )),
														ClavisMessage::CONFIRM);
				}	

				if ($countNotAuthorized > 0)
				{
					$this->getPage()->enqueueMessage(Prado::localize("{count} notizie non sono state collegate ad authority per mancanza di autorizzazione",
																		array('count' => $countNotAuthorized)),
														ClavisMessage::WARNING);
				}
				
				if ($countFailed > 0)
				{
					$this->getPage()->enqueueMessage(Prado::localize("{count} notizie non sono state collegate ad authority a causa di errori",
																		array('count' => $countFailed)),
														ClavisMessage::ERROR);
				}

				$this->getPage()->flushDelayedMessage();
				$this->onClose();
			}
		}
		else
		{
			$this->getPage()->enqueueMessage(Prado::localize("L'authority con id={id} non esiste",
																array('id' => $authorityId)),
												ClavisMessage::INFO);

			$this->getPage()->flushMessage();
		}
	}
	
	/**
	 * This method has been directly taken from the Catalog/EditRecord.php page.
	 * 
	 * @param Manifestation $manifestation
	 * @param Authority $authority
	 * @param string $linkType
	 * @param string $relatorCode
	 * @param string $linkNote
	 */
	private function doNewLink(	$manifestation,
								$authority,
								$linkType,
								$relatorCode,
								$linkNote)
	{
		/* @var $manifestation Manifestation */
		/* @var $authority Authority */
		
		$ok = false;
		
		$manifestationId = $manifestation->getManifestationId();
		$authorityId = $authority->getAuthorityId();
		
		try
		{
			$link = new LAuthorityManifestation();
			$link->setManifestationId($manifestationId);
			$link->setAuthorityId($authorityId);
			$link->setRelatorCode($relatorCode);

			if ($linkType == '610')
			{
				$type = $authority->getAuthorityType();

				if ($type == AuthorityPeer::TYPE_SUBJECT)
					$type = $authority->getAuthorityRelatedByParentId()->getAuthorityType();

				switch ($type)
				{
					case AuthorityPeer::TYPE_PERSONALNAME:
						$linkType = '600';
						break;

					case AuthorityPeer::TYPE_CORPORATEBODYNAME:
						$linkType = '601';
						break;

					case AuthorityPeer::TYPE_FAMILYNAME:
						$linkType = '602';
						break;

					case AuthorityPeer::TYPE_WORK:
						$linkType = '605';
						break;

					case AuthorityPeer::TYPE_PLACE:
						$linkType = '607';
						break;
					//	case AuthorityPeer::TYPE_FORM:
					//		$linkType = '608';
					//		break;

					case AuthorityPeer::TYPE_TRADEMARK:
						$linkType = '616';
						break;

					case AuthorityPeer::TYPE_PUBPLACE:
						$linkType = '620';
						break;

					case AuthorityPeer::TYPE_PRINTERSDEVICE:
						$linkType = '921';
						break;

					case AuthorityPeer::TYPE_ARGUMENT:
						$linkType = '610';
						break;

					default:
						$linkType = '606';
						break;
				}
			}

			$link->setLinkType($linkType);
			$link->setLinkNote($linkNote);

			$linkCheck = LAuthorityManifestationPeer::retrieveByPK(	$link->getAuthorityId(), 
																	$link->getManifestationId(), 
																	$link->getLinkType(), 
																	$link->getRelatorCode());

			if ($linkCheck instanceof LAuthorityManifestation)
				$linkCheck->delete();

			$link->save();

			$manifestationTitle = $manifestation->getTrimmedTitle(80, '');

			ChangelogPeer::logAction(	$manifestation, 
										ChangelogPeer::LOG_CREATE, 
										$this->getUser(), 
										'Creato nuovo legame fra notizia (id = ' . $manifestationId . ', titolo = ' . $manifestationTitle 
											. ') e authority (id = ' . $authorityId . ')');

	//		$this->writeMessage(Prado::localize("Creato nuovo legame fra la notizia (id = {manid}, titolo = '{manifestationTitle}') e l'authority (id = {authid})",
	//												array(	'manid' => $manid,
	//														'manifestationTitle' => $manifestationTitle,
	//														'authid' => $linkAuthID )),
	//								ClavisMessage::CONFIRM);
			
			$ok = true;
		}
		catch (Exception $e)
		{
			$ok = false;
		}
		
		return $ok;
	}
	
}