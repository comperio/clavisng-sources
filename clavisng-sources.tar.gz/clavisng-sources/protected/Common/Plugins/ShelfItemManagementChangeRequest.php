<?php
/**
 * ShelfItemManagementChangeRequest class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2014 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package ShelfPlugins
 */

/**
 * ShelfItemManagementChangeRequest Class
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.7
 * @package ShelfPlugins
 * @since 2.4
 */

class ShelfItemManagementChangeRequest extends ClavisPlugin
{
	/*
	 * Set DEBUGMODE as 'true' for not sending real emails, for tests
	 * Please reset it to false before committing.
	 */
	 // 
	const DEBUGMODE = false; 
	
	const EMAILTEMPLATECLASS = 'PLUGIN_SHELFITEMMANAGEMENTCHANGEREQUEST_EMAIL';
	const EMAILSUBJECT_FALLBACK = 'Richiesta cambio gestione dalla biblioteca \'$FROM\'';
	const EMAILBODY_FALLBACK = 'La biblioteca \'$FROM\' ti chiede il cambio gestione degli esemplari nello scaffale \'$SHELFLINK\'.

Cordiali saluti
Il responsabile della biblioteca';

	const NEWSHELFNAME = '$BIBORIGINE: richiesta cambio gestione';
	const RETURNDAYSDELTA = "30"; // days
	
	public static function getTargetShelfTypes()
	{
		return array(ShelfPeer::TYPE_ITEM);
	}
	
	public static function getEditMode()
	{
		return ShelfPeer::EDITTYPE_EDIT;
	}
	
	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsCallBack())
		{
			$shelfLibraryId = $this->getShelf()->getLibraryId();
			$shelfLibraryLabel = LibraryPeer::getLibraryLabel($shelfLibraryId);
			
			if ($this->NewShelfName->getText() == '')
			{	
				$this->NewShelfName->setText(str_replace(	"\$BIBORIGINE",
															$shelfLibraryLabel,
															Prado::localize(self::NEWSHELFNAME)));
			}
			
			if (($this->EmailSubject->getText() == '')
					||($this->EmailBody->getText() == ''))
			{	
				$emailTemplate = DocumentTemplatePeer::getTemplate(	self::EMAILTEMPLATECLASS,
																		Prado::getApplication()->getGlobalization()->getCulture(),
																		$shelfLibraryId,
																		true);

				$emailSubject = $emailTemplate->getTemplateSubject();
				if (!$emailSubject)
					$emailSubject = self::EMAILSUBJECT_FALLBACK;

				$emailBody = $emailTemplate->getTemplateBody();
				if (!$emailBody)
					$emailBody = self::EMAILBODY_FALLBACK;

				$emailSubject = str_replace(	"\$FROM",
												$shelfLibraryLabel,
												$emailSubject);

				$emailBody = str_replace(	"\$FROM",
											$shelfLibraryLabel,
											$emailBody);

				if ($this->EmailSubject->getText() == '')
					$this->EmailSubject->setText($emailSubject);

				if ($this->EmailBody->getText() == '')
					$this->EmailBody->setText($emailBody);
			}
			
			// calculation of how many libraries are involved
			
			if ($this->LibraryList->getItems()->count() == 0)
			{	
				$connection = Propel::getConnection();
				$statement = $connection->prepare('SELECT COUNT(i.item_id) as item_count, i.home_library_id as library_id 
													FROM shelf_item si INNER JOIN item i on si.object_id = i.item_id 
													WHERE shelf_id=:v1 and object_class=:v2 
													GROUP BY i.home_library_id');

				$statement->execute(array(	':v1' => $this->getShelfId(),
											':v2' => ShelfPeer::TYPE_ITEM ));

				$resultGrid = array();
				while ($row = $statement->fetch(PDO::FETCH_ASSOC))
				{
					$libraryId = intval($row['library_id']);
					if ($libraryId > 0)
						$library = LibraryQuery::create()->findPk($libraryId);

					if (!($library instanceof Library))
						continue;

					$libraryLabel = LibraryPeer::getLibraryLabel($libraryId, "---");
					$itemCount = $row['item_count'];

					//$resultGrid[] = array($libraryLabel . "<br />(" . $itemCount . ")");
					$listItem = new TListItem();
					$listItem->setText($libraryLabel . "&nbsp;(" . $itemCount . ")");
					$listItem->setValue($libraryId);
					$listItem->setSelected(true);

					$this->LibraryList->getItems()->add($listItem);
				}
			}
			
			// first calculation of return date
			if ((string) $this->ReturnDate->getSafeText() == "")
				$this->ReturnDate->setTimeStamp($this->calculateReturnDate(self::RETURNDAYSDELTA));
			
		}	// end of if ! callback
	}
	
	private function calculateReturnDate($delta = null)
	{
		if (is_null($delta))
			$delta = self::RETURNDAYSDELTA;
		
		return time() + ClavisLoanManager::DAYS_1 * $delta;
	}
	
	public function setIsItemValid($valid = false)
	{
		$this->getApplication()->getSession()->add('IsItemValid', $valid, false);
	}

	public function getIsItemValid()
	{
		return $this->getApplication()->getSession()->itemAt('IsItemValid', false);
	}
	
	public function onAction($sender, $param)
	{
		ini_set("memory_limit", "700M");
		set_time_limit(0);
		$this->getPage()->cleanMessageQueue();
		
		if (self::DEBUGMODE)
			$this->getPage()->enqueueMessage('DEBUG mode: ',
												ClavisMessage::CONFIRM);
		
		$clavisLibrarian = $this->getUser();
		$myLibrary = $this->getUser()->getActualLibrary();

		$newShelfName = $this->NewShelfName->getSafeText();
		if (!$newShelfName)
		{
			$newShelfName = str_replace(	"\$BIBORIGINE",
											$shelfLibraryLabel,
											Prado::localize(self::NEWSHELFNAME));
			$this->NewShelfName->setText();
		}
		
		$emailSubject = $this->EmailSubject->getSafeText();
		if (!$emailSubject)
			$emailSubject = self::EMAILTEMPLATECLASS_FALLBACK;

		$emailBody = $this->EmailBody->getSafeText();
		if (!$emailBody)
			$emailBody = self::EMAILTEMPLATECLASS_FALLBACK;
		
		// read library checks part
		$checkedLibraryArray = array();
		$items = $this->LibraryList->getItems();

		foreach ($items as $listItem)
		{
			if ($listItem->getSelected())
				$checkedLibraryArray[$listItem->getValue()] = true;
		}

		if (((string) $this->ReturnDate->getSafeText() == "")
				|| is_null($this->ReturnDate->getTimeStamp()))
			$this->ReturnDate->setTimeStamp($this->calculateReturnDate(self::RETURNDAYSDELTA));

		$returnDate = $this->ReturnDate->getSafeText();
		
		$countDone = 0;
		$countFailed = 0;

		$newShelvesArray = array();	// hash come: destLibraryId => newShelfId
		$myShelf = $this->getShelf();
		$shelfItems = $this->getCheckedItems();
		
		// main cycle of element in shelf
		foreach ($shelfItems as $shelfItem)
		{
			if (!is_null($shelfItem)
					&& $shelfItem->getObjectClass() == ShelfPeer::TYPE_ITEM)
			{
				$itemId = $shelfItem->getObjectId();
				$item = ItemQuery::create()->findPk($itemId);
				if ($item instanceof Item)
				{
					$homeLibraryId = $item->getHomeLibraryId();
					if (array_key_exists($homeLibraryId, $checkedLibraryArray))
					{
						$ok = true;
					
						//filtering for checklisted libraries
						if (!array_key_exists($homeLibraryId, $newShelvesArray))
						{
							try
							{
								//$homeLibraryLabel = $item->getHomeLibraryLabel(false, true);

								$shelf = ShelfPeer::createShelf(	$newShelfName,
																	Prado::localize('Creato da plugin gestione richieste'),
																	$clavisLibrarian,
																	$homeLibraryId,
																	ShelfPeer::VISIBILITY_LIBRARYOPS);

								$newShelvesArray[$homeLibraryId] = array(	'shelfId' => $shelf->getShelfId(),
																			'shelfName' => $newShelfName);
							}
							catch (Exception $exception)
							{
								if ($exception->getCode() == ShelfPeer::SHELF_NAMEEXISTS)
								{
									$shelf = ShelfQuery::create()
												->filterByShelfName($newShelfName)
												->filterByLibraryId($homeLibraryId)
												->findOne();

									if ($shelf instanceof Shelf)
									{
										$newShelvesArray[$homeLibraryId] = array(	'shelfId' => $shelf->getShelfId(),
																					'shelfName' => $newShelfName);
									}
									else
									{
										$countFailed++;
										$ok = false;
									}
								}
								else
								{
									$countFailed++;
									$ok = false;
								}
							}
						}
						else
						{
							$shelf = ShelfQuery::create()->findPk($newShelvesArray[$homeLibraryId]['shelfId']);
							if (!($shelf instanceof Shelf))
							{
								$countFailed++;
								$ok = false;
							}
						}
					
						if ($ok)
						{
							try
							{
								ShelfPeer::addItemToShelf(		$shelf,
																ShelfPeer::TYPE_ITEM,
																$itemId);

								$countDone++;
							}
							catch (Exception $ex)
							{
								$countFailed++;
							}

						}
					}	// end of filtering for checklisted libraries
				}
				else
				{
					$this->getPage()->enqueueMessage(Prado::localize(	"Errore sull'esemplare con id = {itemId}",
																			array('itemId' => $shelfItem->getObjectId())),
														ClavisMessage::ERROR);
				}
			}
		}
		// end of main cycle of elements in shelf
		
		/**
		 * Email broadcast section and tasks creation (together)
		 */
		$mail = $this->Application->getModule('mail');
		
		$senderEmail = trim($myLibrary->getEmail());
		if (!$senderEmail)
			$senderEmail = $myLibrary->getEmail();
		
		if (!$senderEmail)
			$senderEmail = ClavisParamQuery::getParam('CLAVISPARAM','AdminEmail');
		
		$mail->setFrom($senderEmail);

		$emailDone = 0;
		$emailFailed = 0;
		$tasksCreated = 0;
		$tasksFailed = 0;
		
		foreach ($newShelvesArray as $toLibraryId => $newShelf)
		{	
			$toLibrary = LibraryQuery::create()
						->findPk($toLibraryId);
			if (!($toLibrary instanceof Library))
			{
				$emailFailed++;
				continue;
			}
			
			$destEmail = trim($toLibrary->getEmail());
			if (!$destEmail)
				$destEmail = $toLibrary->getEmail();
		
			if (!$destEmail)
			{
				$emailFailed++;
				continue;
			}
			
			$mail->setTo($destEmail);
			$mail->setCc($senderEmail);
			
			$mail->setSubject($emailSubject);
	
			// calculation of new shelf url address:
			$newShelfUrl = ClavisParamQuery::getParam('CLAVISPARAM','BaseUrl') . "index.php?page=Communication.ShelfViewPage&id=" . $newShelf['shelfId'];
            $newTaskShelfUrl = "<a href=\"{$newShelfUrl}\">ID {$newShelf['shelfId']}</a>";

			$emailRealBody = str_replace(	array("\$SHELFNAME", "\$SHELFURL","\$RETURNDATE"),
										array($newShelf['shelfName'], $newShelfUrl, $returnDate),
										$emailBody);
            $taskRealBody = str_replace(	array("\$SHELFNAME", "\$SHELFURL","\$RETURNDATE"),
                array($newShelf['shelfName'], $newTaskShelfUrl, $returnDate),
                $emailBody);
			
			$mail->setBody($emailRealBody);

			try
			{
				if (!self::DEBUGMODE)
					$mail->send();
				$emailDone++;
			}
			catch (Exception $ex)
			{
				$emailFailed++;
			}
			
			/**
			 * Task part
			 */
			if ($this->createNewTask(	$toLibraryId,
										$emailSubject,
										$taskRealBody,
										$returnDate))	// creation ok
				$tasksCreated++;
			else
				$tasksFailed++;
					
			
			
		}	// end of libraries/shelf cycle
		// end of email section and tasks creation
		
		/*
		 * Clavismessaging part
		 */
		if ($countDone == 1)
			$this->getPage()->enqueueMessage(Prado::localize('1 esemplare aggiunto a scaffale'),
												ClavisMessage::CONFIRM);
		
		if ($countDone > 1)
			$this->getPage()->enqueueMessage($countDone . " " . Prado::localize('esemplari aggiunti a scaffale'),
												ClavisMessage::CONFIRM);
		
		$this->getPage()->enqueueMessage(count($newShelvesArray) . " " . Prado::localize('scaffali creati o riusati'),
											ClavisMessage::CONFIRM);
		
		if ($countFailed == 1)
			$this->getPage()->enqueueMessage(Prado::localize('1 errore su aggiunta a scaffale'),
												ClavisMessage::ERROR);
		
		if ($countFailed > 1)
			$this->getPage()->enqueueMessage($countFailed . " " . Prado::localize('errori su aggiunta a scaffale'),
												ClavisMessage::ERROR);

		$this->getPage()->enqueueMessage($emailDone . " " . Prado::localize('email spedite a biblioteca'),
												ClavisMessage::CONFIRM);
		
		if ($emailFailed > 0)
			$this->getPage()->enqueueMessage($emailFailed . " " . Prado::localize('errori su spedizione email'),
												ClavisMessage::ERROR);
		
		if ($tasksCreated > 0)
			$this->getPage()->enqueueMessage($tasksCreated . " " . Prado::localize('nuovi tasks creati'),
												ClavisMessage::CONFIRM);

		if ($tasksFailed > 0)
			$this->getPage()->enqueueMessage($tasksFailed . " " . Prado::localize('creazioni di tasks fallite'),
												ClavisMessage::ERROR);
		
		// end of clavismessaging part
		
		/**
		 * Final part
		 */
		$this->getPage()->flushDelayedMessage();
		$this->onClose();
	}

	private function createNewTask(	$libraryId,
									$title,
									$note,
									$returnDate)
	{
		if (intval($libraryId) == 0)
			return false;
		
		$newTask = new LibrarianTask();
			
		$newTask->setTaskStatus(LibrarianTaskPeer::STATUS_PENDING);
		$newTask->setDonePercent(0);
		
		$newTask->setLibraryId($libraryId);
		$newTask->setDueDate($returnDate);
		$newTask->setTaskTitle($title);
		$newTask->setTaskNote($note);
				
		$newTask->save();
		$newTaskId = $newTask->getTaskId();

		ChangelogPeer::logAction(	$newTask,
									ChangelogPeer::LOG_CREATE,
									$this->getUser(), 'creazione task con id=' . $newTaskId);
		
		return true;	// new task created
	}
	
	public function IsPopup()
	{
		return true;
	}

}