<?php
/**
 * ShelfContentJRPrint class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package ShelfPlugins
 */

/**
 * ShelfContentJRPrint Class
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package ShelfPlugins
 * @since 2.5.0
 */

class ShelfContentJRPrint extends ClavisPlugin
{
	private $_available_templates = array(	ShelfPeer::TYPE_MANIFESTATION => array('JR_MANIFESTATIONLIST'),
											ShelfPeer::TYPE_MANIFESTATION_BUY => array('JR_MANIFESTATIONLIST'	),
											ShelfPeer::TYPE_ITEM => array(	'JR_ITEMLABEL',
																			'JR_ITEMLIST' ),
											
											ShelfPeer::TYPE_PATRON => array(	'JR_PATRONCARD',
																				'JR_PATRONLIST',
																				'JR_PATRONADDRESS' ),
		
											ShelfPeer::TYPE_LOAN => array('JR_LOANREPORT'),
											ShelfPeer::TYPE_LIBRARY => array('JR_LIBRARYLIST'),
											ShelfPeer::TYPE_ITEM_REQUEST => array(),
											ShelfPeer::NOTYPE => array() );

	public function onInit($param)
	{
		parent::onInit($param);

		if (count($this->TemplateClassList->getDataSource()) < 1)
		{
			$shelf = ShelfQuery::create()
						->findPk($this->getShelfId());

			if ($shelf instanceof Shelf)
			{
				$type = $shelf->getShelfItemtype();
				$tplDs = (!array_key_exists($type, $this->_available_templates))
								? array()
								: $this->_available_templates[$type];
				
				if (count($tplDs) < 1)
				{
					$this->NoPrintPanel->setVisible(true);
					$this->PrintPanel->setVisible(false);
				}
				else
				{
					$this->NoPrintPanel->setVisible(false);
					$this->PrintPanel->setVisible(true);
                                        
                                        $tplDsLabel = array();
                                        foreach($tplDs as $k)
                                        {
                                            $lvo = BaseLookupValueQuery::create()
                                                    ->findOneByValueKey($k);
                                            if($lvo instanceof BaseLookupValue)
                                            {
                                                $tplDsLabel[$k] = $lvo->getValueLabel ();
                                            }
                                            else
                                            {
                                                $tplDsLabel[$k] = $k;
                                                Prado::log("WARNING: lookup_value table not have $k class entry");
                                            }
                                        }
                                        
					$this->TemplateClassList->setDataSource($tplDsLabel);
					$this->JRPBox->setReportClass($tplDs[0]);
					$this->JRPBox->populate();
				}
			}
		}
	}

	public function onPrintJRP($sender, $param)
	{
		$shelfId = intval($this->getShelfId());
		$tplClass = $this->TemplateClassList->getSelectedValue();
		$itemShelvesIds = $this->getCheckedObjectsIds();
		$ids = implode(',',$itemShelvesIds);
		$this->JRPBox->setObjectId($ids);
		$this->JRPBox->addOptionalParam(	'P_SUBTITLE',
											Prado::localize('scaffale: ') . $this->getShelf()->getShelfName());
		
		$this->JRPBox->printReport();
	}

	public function onTemplateClassChoice($sender, $param)
	{
		//$tplClass = $this->TemplateClassList->getSelectedItem()->getText();
		$tplClass = $this->TemplateClassList->getSelectedValue();
		$this->JRPBox->setReportClass($tplClass);
		$this->JRPBox->populate();
	}
	
}