<?php
/**
 * ShelfContentDelete class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package ShelfPlugins
 */

/**
 * ShelfContentDelete Class
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.7
 * @package ShelfPlugins
 * @since 2.1
 */

class ShelfContentDelete extends ClavisPlugin
{
	public function onInit($param)
	{
		parent::onInit($param);

		if (count($this->ObjectFilter->getDataSource()) == 0)
		{
			$datasource = LookupValuePeer::getLookupClassValues('SHELFITEMTYPE', true, null, null, true);
			$this->ObjectFilter->setDataSource($datasource);
			$this->ObjectFilter->dataBind();
		}
	}

	public function onDelete($sender, $param)
	{
		/* @var $shelfItem ShelfItem */
		/* @var $criteria Criteria */

		$shelfItemIds = $this->getCheckedItemsIds();

		$countDone = 0;
		$countFailedFlag = false;

		if (count($shelfItemIds) > 0)
		{
			set_time_limit(0);   // unlimited

			$objectFilter = $this->ObjectFilter->getSelectedValue();
			$dateFilter = $this->DateFilter->getSafeText() != ''
				? $this->DateFilter->getTimeStamp()
				: null;
			$numberFilter = intval($this->NumberFilter->getSafeText());
			$candidates = array();
			$candidatesDates = array();
			foreach ($shelfItemIds as $listed) {
                if (count($listed) > 0)    // if shelf element is valid (3 values)
                {
                    list ($shelfId, $objectId, $objectClass) = $listed;

                    if (($objectFilter == $objectClass) || ($objectFilter == "0")) {
                        $shelfItem = ShelfItemPeer::retrieveByPK($shelfId, $objectId, $objectClass);

                        if ($shelfItem instanceof ShelfItem) {
                            $dateCreated = $shelfItem->getDateCreated('U');
                            unset($shelfItem);
                        } else {
                            continue;
                        }

                        // apply any filtering, if it's the case
                        if (!is_null($dateFilter)
                            && ($dateCreated >= $dateFilter))
                            continue;

                        $candidatesDates[] = $dateCreated;
                        $candidates[] = $listed;    // $listed is a ShelfItem id
                    }
                }
            }

			// apply operation on candidates
			if (count($candidates) > 0)
			{
				if ($numberFilter > 0)
				{
					if (array_multisort($candidatesDates, SORT_DESC, $candidates))
						$candidates = array_slice($candidates, -count($candidates) + $numberFilter);
				}
				try
				{
				    $countDone = 0;
				    foreach ($candidates as $siPk) {

                        $countDone += ShelfItemPeer::doDelete($siPk, null, true);    // the third parameter is for reindexing
                    }

				}
				catch (PropelException $exception)
				{
					$countFailedFlag = true;
					//throw ($exception);
				}
			}
		}

		$this->getPage()->writeDelayedMessage(Prado::localize("Elementi rimossi dallo scaffale ") . ": " . $countDone,
												($countDone > 0
													? ClavisMessage::INFO
													: ClavisMessage::WARNING));

		if ($countFailedFlag)
			$this->getPage()->writeDelayedMessage(Prado::localize("Errori sulla rimozione di elementi dallo scaffale"),
													ClavisMessage::ERROR);

		$this->onClose();
	}

}
