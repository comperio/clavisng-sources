<?php
/**
 * ShelfContentIndex class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.8.7
 * @package ShelfPlugins
 */

/**
 * ShelfContentIndex Class
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.8.7
 * @package ShelfPlugins
 * @since 2.8.7
 */

class ShelfContentIndex extends ClavisPlugin
{
	const LIMIT_SHELFITEMS = 100;
	private $_clavisLibrarian;

	public static function getTargetShelfTypes()
	{
		return array(	ShelfPeer::TYPE_MANIFESTATION,
						ShelfPeer::TYPE_AUTHORITY );
	}
	
	public static function getEditMode()
	{
		return ShelfPeer::EDITTYPE_NONEDIT;
	}
	
	private function initVars()
	{
		$this->_clavisLibrarian = $this->getUser();
	}

	public function onInit($param)
	{
		parent::onInit($param);
		
		$this->initVars();
	}

	public function onAction($sender, $param)
	{
		ini_set("memory_limit", "700M");
		set_time_limit(0);
		$this->getPage()->cleanMessageQueue();

		$shelfItemIds = $this->getCheckedItemsIds();	/// ATTENTION: this time we want exploded values, not the whole shelfitem objects ...
		$countDone = 0;
		$countFailed = 0;
		$countNotAuthorized = 0;
		$overLimitShelfItems = false;

		// putting dirty case
		if (($this->getShelf()->getShelfItemtype() == ShelfPeer::TYPE_MANIFESTATION)
				&& (count($shelfItemIds) > self::LIMIT_SHELFITEMS))
		{
			$overLimitShelfItems = true;
			$objectIds = [];
			
			foreach ($shelfItemIds as $shelfItemId)
				$objectIds[] = $shelfItemId[1];	// unpacked -> object_id
			
			$countObjectIds = count($objectIds);
			
			if ($countObjectIds > 0)
			{
				try
				{
					TurbomarcCachePeer::invalidate($objectIds);
					$countDone = $countObjectIds;
				}
				catch (Exception $exc)
				{
					$countFailed = $countObjectIds;
				}
			}
		}
		else	// normal case, using doIndex() methods in objects
		{	
			foreach ($shelfItemIds as $shelfItemId)
			{
				//$element = ShelfItemPeer::retrieveByPackedPK($shelfItemId);
				$shelfItem = ShelfItemPeer::retrieveByPK($shelfItemId[0], $shelfItemId[1], $shelfItemId[2]);

				if ($shelfItem instanceof ShelfItem)
				{
					$element = $shelfItem->getObject();
					
					if (!is_null($element))
					{
						if (!$this->_clavisLibrarian->getEditPermission($element))
						{
							$countNotAuthorized++;
						}
						else
						{
							try
							{
								$element->doIndex();	// both Manifestation and Authority objects have that method
								$countDone++;

								ChangelogPeer::logAction(	$element,
															ChangelogPeer::LOG_UPDATE,
															$this->_clavisLibrarian,
															'Indicizzazione da plugin');
							} 
							catch (Exception $exc)
							{
								$countFailed++;
							}
						}
					}
					else
					{
						$this->getPage()->enqueueMessage(Prado::localize("Errore interno di reperimento dell'oggetto nell'ememento scaffale con id={id}",
																				array('id' => implode('-', $shelfItemId))),
																ClavisMessage::ERROR);
					}
				}
				else
				{
					$this->getPage()->enqueueMessage(Prado::localize("Errore interno di reperimento dell'elemento dello scaffale con id={id}",
																			array('id' => implode('-', $shelfItemId))),
															ClavisMessage::ERROR);
				}
			}	// end of cycling on shelfitems, if limit was not reached
		}
		
		// messages part
		
		$canCloseFlag = false;
		
		if ($countDone + $countFailed + $countNotAuthorized == 0)
		{
			$this->getPage()->enqueueMessage(Prado::localize("Nessuna azione eseguita"),
												ClavisMessage::INFO);
		}
		else
		{
			if ($countFailed > 0)
			{
				$this->getPage()->enqueueMessage(Prado::localize("{count} elementi non indicizzati a causa di errori",
																		array('count' => $countFailed)),
														ClavisMessage::ERROR);
			}	

			if ($countNotAuthorized > 0)
			{
				$this->getPage()->enqueueMessage(Prado::localize("{count} elementi non indicizzati per mancanza di permessi",
																		array('count' => $countNotAuthorized)),
													ClavisMessage::ERROR);
			}

			if ($countDone > 0)
			{
				$this->getPage()->enqueueMessage(Prado::localize("{count} elementi indicizzati",
																		array('count' => $countDone)),
														ClavisMessage::CONFIRM);
				
				if ($overLimitShelfItems)
				{
					$this->getPage()->enqueueMessage(Prado::localize("L'operazione e' avvenuta invalidando la turbomarc_cache perchè gli elementi superano il limite di {limit}",
																		array('limit' => self::LIMIT_SHELFITEMS)),
														ClavisMessage::CONFIRM);
				}

				if ($countFailed + $countNotAuthorized == 0)
					$canCloseFlag = true;
			}	
		}

		if ($canCloseFlag)
		{
			$this->getPage()->flushDelayedMessage();
		
			$this->onClose();
		}
		else	// plugins stays open
		{
			$this->getPage()->flushMessage();
		}
	}

	public function IsPopup()
	{
		return true;
	}
	
}