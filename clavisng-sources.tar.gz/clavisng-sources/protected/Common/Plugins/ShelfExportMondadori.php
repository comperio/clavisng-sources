<?php
/**
 * ShelfExport class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Cristian Chiarello <cristian.chiarello@comperio.it>
 * @author Marco Brancalion <marco@comperio.it>
 * @author Dario Rigolin <dario@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.8.9
 * @package ShelfPlugins
 *
 * See contrib/oneshot_scripts/mondadori_plugin_*.sql to manage this plugin
 * All data come from turbomarc except last column (from db because some field not in TM) 
 */

/**
 * Get the NumberFormat class.
 */
Prado::using('System.I18N.core.NumberFormat');

/**
 * ShelfExport Class
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @author Dario Rigolin <dario@comperio.it>
 * @version 2.8.9
 * @package ShelfPlugins
 * @since 2.2
 */
class ShelfExportMondadori extends ClavisPlugin
{
	const DELIMITER = ',';
	const ENCLOSURE = '"';
	//See https://webcomperio.atlassian.net/browse/CNG-1342
	const ISBD_SEPARATOR = ". - ";
	const L1_SEPARATOR = ". - ";
	const L2_SEPARATOR = " ";
	protected $evalLabels = [];

	public static function getTargetShelfTypes()
	{
		return array( ShelfPeer::TYPE_MANIFESTATION );
	}
	
	public static function getEditMode()
	{
		return ShelfPeer::EDITTYPE_NONEDIT;
	}
	
	public function onLoad($param)
	{
		parent::onLoad($param);
		
		if (!$this->getPage()->getIsCallBack())
		{
			$itemType = '';
			$shelf = $this->getShelf();
			
			if ($shelf instanceof Shelf)
			{
				$itemType = $shelf->getShelfItemtype();
			}

			if (is_null($this->getItemType()))
			{
				$this->setItemType($itemType);
			}
			
			if($itemType != ShelfPeer::TYPE_MANIFESTATION)
			{
				$this->getPage()->writeMessage(Prado::localize("Tipo di oggetti non esportabile"),
					ClavisMessage::ERROR);
				$this->ExportMondadoriPanel->setVisible(false);
			}
		}
	}

	private function setItemType($param)
	{
		$this->setControlState('ItemType', $param, null);
	}

	private function getItemType()
	{
		return $this->getControlState('ItemType', null);
	}

	

	public function isDataSourceNeeded()
	{
		return true;
	}

	public function IsPopup()
	{
		return true;
	}

	// START ISBD See protected/Lib/TurboMarc.php
	
	protected function getTitle($field, $escape = true)
	{
		$titlefields = [];
		$findH = false;
		foreach ($field->children() as $sf)
		{
			$v = trim((string)$sf);
			if ($escape)
			{
				$v = str_replace(array(" ; ", " : ", " / "), array(" \\; ", " \\: ", " \\/ "), $v);
			}
				
			switch ($sf->getName())
			{
				case 'sa':
					if (count($titlefields) == 0) 
					{
						$titlefields[] = $v;
					} else {
						$titlefields[] = " ; $v";
					}
					break;
				case 'sc':
					$titlefields[] = " .  $v";
					break;
				case 'sd':
					$titlefields[] = " = $v";
					break;
				case 'se':
					$titlefields[] = " : $v";
					break;
				case 'sh':
					$findH = true;
					$titlefields[] = (($escape) ? "^. $v" : ". $v");
					break;
				case 'si':
					if ($escape)
					{
						$titlefields[] = ($findH) ? "^, $v" : "^. $v";
					}
					else
					{
						$titlefields[] = ($findH) ? ", $v" : ". $v";
					}
					break;
					//Missing on TurboMarc.php. Use space, see CNG-1329?focusedCommentId=36020
				case 'sv':
					$titlefields[] = " " . $v;
					break;
			}//switch
		}//foreach
		
		return implode('' , $titlefields);
	}
	
	protected function getAuthor($field, $escape = true)
	{
		$authorfields = [];
		foreach ($field->children() as $sf)
		{
			$v = trim((string)$sf);
			if ($escape)
			{
				$v = str_replace(array(" ; ", " : ", " / "), array(" \\; ", " \\: ", " \\/ "), $v);
			}
				
			switch ($sf->getName()) 
			{
				case 'sf':
					if(count($authorfields) == 0)
					{
						$authorfields[] = $v;
					}
					else
					{
						$authorfields[] = ". $v";
					}
					break;
				case 'sg':
					$authorfields[] = " ; $v";
					break;
			}
		}

		return implode('', $authorfields);
	}
	// END ISBD
	
	/**
	 * Return string with every child (lev2) of every child (lev1) of $node
	 * 
	 * @param unknown $node
	 * @param boolean $filterl2 filter lev 2 name. Something like 'sa'.
	 * @return string
	 */
	protected function get2LevelNodes($node, $filterl2=false)
	{
		$l1=[];
		$l2sep=self::L2_SEPARATOR;
		$sseps = ['sa' => ' ; ','sc' =>' : '];
		if($filterl2 !== false && array_key_exists($filterl2,$sseps)) $l2sep=$sseps[$filterl2];
		foreach($node as $p)
		{
			$l2=[];
			foreach($p as $c)
			{
				if($filterl2)
				{
					if($c->getName() == $filterl2) $l2[] = trim((string)$c);
				}
				else
				{
					$l2[] = trim((string)$c);
				}
			}
			$l1[] = implode($l2sep, $l2);
		}
		return implode(self::L1_SEPARATOR, $l1);
	}
	

	protected function getFormattedRow($tm)
	{
		$csvrow = array_fill(0,30,'');
		
		try
		{
			//id
			$csvrow[0] = trim((string)$tm->c001);
			
			
			if(isset($tm->d200))
			{
				//Titolo proprio
				$tp='';
				foreach($tm->d200->children() as $f)
				{
					if($f->getName() == 'sa') $tp = trim((string)$f);
					break;
				}
				$csvrow[1] = $tp;
				
				//Titolo completo
				$csvrow[2] = $this->getTitle($tm->d200);
				//Formulazione di responsabilità
				$csvrow[3] = $this->getAuthor($tm->d200);
				
				//Titolo e formulazione di responsabilità
				$csvrow[4] = $tm->getFullTitle();
			}
			
			
			//Responsabilità principali
			$fs=[];
			$fs[] =  $this->get2LevelNodes($tm->d700, 'sa');
			$fs[] =  $this->get2LevelNodes($tm->d710, 'sa');
			$fs[] =  $this->get2LevelNodes($tm->d720, 'sa');
			
			$csvrow[5] = implode(' ', $fs);
			
			
			//Responsabilità alternative
			$fs=[];
			$fs[] =  $this->get2LevelNodes($tm->d701, 'sa');
			$fs[] =  $this->get2LevelNodes($tm->d711, 'sa');
			$fs[] =  $this->get2LevelNodes($tm->d721, 'sa');
			
			$csvrow[6] = implode(' ', $fs);
			
			
			//Responsabilità
			$fs=[];
			for($i=700; $i<800; $i++)
			{
				$fname='d'.$i;
				$v = trim($this->get2LevelNodes($tm->$fname, 'sa'));
				if($v != '') $fs[] = $v;
			}
			$csvrow[7] = implode(self::ISBD_SEPARATOR, $fs);
			
			
			//Data di pubblicazione
			$csvrow[8] = $this->get2LevelNodes($tm->d210, 'sd');
			
			
			//Data inizio
			$csvrow[9] = (isset($tm->d100->sa)) ? substr($tm->d100->sa, 9, 4) : '';
			
			
			//Data fine
			$csvrow[10] = (isset($tm->d100->sa)) ? substr($tm->d100->sa, 13, 4) : '';
			
			
			//ISBD
			$isbd = [];
			//200
			$isbd[] = $tm->getFullTitle();
			//205
			$f=$tm->getEditions();
			if(count($f) > 0) $isbd[] = implode(self::ISBD_SEPARATOR,$f);
			//210
			$f=$tm->getPublications();
			if(count($f) > 0) $isbd[] = implode(self::ISBD_SEPARATOR,$f);
			//215
			$f=$tm->getPhysicalDescs();
			if(count($f) > 0) $isbd[] = implode(self::ISBD_SEPARATOR,$f);
			//225
			$f=$tm->getSeries();
			if(count($f) > 0) $isbd[] = implode(self::ISBD_SEPARATOR,$f);
			
			$csvrow[11] = implode(self::ISBD_SEPARATOR, $isbd);
			
			
			//ISBD completa
			$fs=[];
			$f = $this->get2LevelNodes($tm->d010, 'sa');
			if($f != '') $fs[] = $f;
			$f =  $this->get2LevelNodes($tm->d073, 'sa');
			if($f != '') $fs[] = $f;
			$toskip=[309, 316, 317, 318, 319, 330, 397, 398, 399];
			for($i=300; $i<400; $i++)
			{
				if(in_array($i,$toskip)) continue;
				$fname='d'.$i;
				$v = trim($this->get2LevelNodes($tm->$fname, 'sa'));
				if($v != '') $fs[] = $v;  
			}
			
			$csvrow[12] = $csvrow[11] . self::ISBD_SEPARATOR .  implode(self::ISBD_SEPARATOR, $fs);
			
			
			//ISBN
			$csvrow[13] = $this->get2LevelNodes($tm->d010, 'sa');
			

			//EAN
			$csvrow[14] = $this->get2LevelNodes($tm->d073, 'sa');
			

			//Edizione
			$fs=[];
			$f=$this->get2LevelNodes($tm->d205, 'sa');
			if($f != '') $fs[] = $f;
			$f=$this->get2LevelNodes($tm->d205, 'sf');
			if($f != '') $fs[] = $f;
			$csvrow[15] = implode(' / ', $fs);
			
			
			//Luogo di edizione
			$csvrow[16] = $this->get2LevelNodes($tm->d210, 'sa');
			
			
			//Editore
			$csvrow[17] = $this->get2LevelNodes($tm->d210, 'sc');
			
			
			//Descrizione fisica
			$csvrow[18] = implode(self::ISBD_SEPARATOR, $tm->getPhysicalDescs(false));
			
			
			//Collana
			$csvrow[19] = implode(self::ISBD_SEPARATOR, $tm->getSeries(false));
			
			
			//Note
			$fs=[];
			for($i=300; $i<400; $i++)
			{
				$fname='d'.$i;
				$v = trim($this->get2LevelNodes($tm->$fname));
				if($v != '') $fs[] = $v;  
			}
			$csvrow[20] = implode(self::ISBD_SEPARATOR, $fs);
			
			
			//Note relative al titolo e alla indicazione di responsabilità
			$csvrow[21] = $this->get2LevelNodes($tm->d304, 'sa');
			
			
			//Note relative all’edizione
			$csvrow[22] = $this->get2LevelNodes($tm->d305, 'sa');
			
			
			//Note sul contenuto
			$csvrow[23] = $this->get2LevelNodes($tm->d327, 'sa');
			
			
			//Legame Fa parte di
			$csvrow[24] = $this->get2LevelNodes($tm->d461, 'st');
			
			
			//Legame Traduzione di 
			$csvrow[25] = $this->get2LevelNodes($tm->d454, 'st');
			
			
			//Semantica
			$fs=[];
			for($i=600; $i<700; $i++)
			{
				$fname='d'.$i;
				$v = trim($this->get2LevelNodes($tm->$fname,'sa'));
				if($v != '') $fs[] = $v;
			}
			$csvrow[26] = implode(self::ISBD_SEPARATOR, $fs);
			
			
			//Parole chiave
			$csvrow[27] = $this->get2LevelNodes($tm->d619, 'sa');
			
			
			//Titoli uniformi
			$fs=[];
			$f=$this->get2LevelNodes($tm->d500, 'sa');
			if($f != '') $fs[] = $f;
			$f=$this->get2LevelNodes($tm->d501, 'sa');
			if($f != '') $fs[] = $f;
			$csvrow[28] = implode(self::ISBD_SEPARATOR, $fs);
			
			
			//Titoli in relazione
			$fs=[];
			for($i=500; $i<600; $i++)
			{
				$fname='d'.$i;
				$v = trim($this->get2LevelNodes($tm->$fname, 'sa'));
				if($v != '') $fs[] = $v;  
			}
			$csvrow[29] = implode(self::ISBD_SEPARATOR, $fs);
			

		}catch(Exception $ex){
			$csvrow[0] = "Err. manif. id {$manif->getManifestationId()}";
		}
		return $csvrow;
	}
	
	public function onExport($sender, $param)
	{
		if(count($this->evalLabels) == 0)
		{
			$evalUC = UnimarcCodesQuery::create()
			->filterByLanguage(Prado::getApplication()->getGlobalization()->getCulture())
			->filterByFieldNumber(109)
			->filterBySubfieldTag('a')
			->filterByPos(22)
			->find();
			
			foreach($evalUC as $uc)
			{
				$this->evalLabels[trim($uc->getCodeValue())] = $uc->getLabel();
			}
		}
		
		$itemType = $this->getItemType();
		$objectIds = array();
		
		foreach ($this->getCheckedItemsIds() as $rowShelfItemArray)
		{
			if ($rowShelfItemArray[2] == $itemType)
				$objectIds[] = $rowShelfItemArray[1];
		}
		
		
		if ($itemType == ShelfPeer::TYPE_MANIFESTATION)
		{
			$query = ManifestationQuery::create()
						->filterByManifestationId($objectIds);
		}
		else
		{
				$this->getPage()->writeMessage(Prado::localize("Impossibile esportare"),
												ClavisMessage::ERROR);

				return false;
		}
		
		if ($query->count() == 0)    // no objects to export were found
		{
			$this->getPage()->writeMessage(Prado::localize("Nessun oggetto da esportare"),
											ClavisMessage::ERROR);
			
			return false;
		}

		// beginning of the real exporting section
		ini_set("memory_limit", "700M");
		set_time_limit(0);

		$mans = $query->setFormatter(ModelCriteria::FORMAT_ON_DEMAND)->find();

		$encoding = ($this->FormatForExcel->getChecked()
							? 'Windows-1252'
							: 'UTF-8');
		
		$now = getdate();
		$dateSubfix = $now['year'] . "-" . $now['mon'] . "-" . $now['mday'];
	
		// here we put out the document file
		header('Content-Type: text/csv; charset=' . $encoding);
		header('Content-Disposition: inline; filename=shelf' . '_' . $dateSubfix . '.csv');
		$fp = fopen('php://output', 'w');
		
		if ($this->HeadersViewFlag->getChecked())
		{
			$csvheader = [
				'Id',
				'Titolo proprio',
				'Titolo completo',
				'Formulazione di responsabilità',
				'Titolo e formulazione di responsabilità',
				'Responsabilità principali',
				'Responsabilità alternative',
				'Responsabilità',
				'Data di pubblicazione',
				'Data inizio',
				'Data fine',
				'ISBD',
				'ISBD completa',
				'ISBN',
				'EAN',
				'Edizione',
				'Luogo di edizione',
				'Editore',
				'Descrizione fisica',
				'Collana',
				'Note',
				'Note relative al titolo e alla indicazione di responsabilità',
				'Note relative all’edizione',
				'Note sul contenuto',
				'Legame Fa parte di',
				'Legame Traduzione di',
				'Semantica',
				'Parole chiave',
				'Titoli uniformi',
				'Titoli in relazione',
				'Biblioteca di gestione,Collocazione,Note all’esemplare,Nota interna,Visibilità opac'
			];
			fputcsv($fp, $csvheader, self::DELIMITER, self::ENCLOSURE);
		}
		
		
		foreach ($mans as $man)
		{
			//2021-03-23 WARN: this is needed to get var updated. Else, never change.
			$man->reloadTurboMarc();
			$tm = $man->getFullTurboMarc(false,false,false);
			$fr = $this->getFormattedRow($tm);
			$fdata=[];
			foreach($man->getItems() as $mitem)
			{
				$idata=[];
				$idata[]=$mitem->getOwnerLibrary()->getLabel();
				$idata[]=$mitem->getCollocation();
				$notes=[];
				$inotes=[];
				foreach($mitem->getItemNotes() as $mitemnote)
				{
					if( $mitemnote->getNoteType() == ItemNotePeer::NOTETYPE_INTERNAL)
					{
						$inotes[] = $mitemnote->getNote();
					}else{
						$notes[] = $mitemnote->getNote();
					}
				}
				$idata[]=implode(' ', $notes);
				$idata[]=implode(' ', $inotes);
				$idata[] = $mitem->getOpacVisible() ? 'SI' : 'NO';
				$fdata[]=implode(',', $idata);
			}
			$fr[30] = implode('|', $fdata); 
			fputcsv($fp, $fr, self::DELIMITER, self::ENCLOSURE);
		}
		
		
		
		fclose($fp);
		die();
	}
	
}