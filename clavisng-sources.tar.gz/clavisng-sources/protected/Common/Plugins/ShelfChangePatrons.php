<?php
/**
 * ShelfChangePatrons class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.8.9
 * @package ShelfPlugins
 */

/**
 * ShelfChangePatrons Class
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.8.9
 * @package ShelfPlugins
 * @since 2.1
 */

class ShelfChangePatrons extends ClavisPlugin
{
	const DONTUPDATE = '--%%impossibIlescriverEunastringacosiACaso%%--';

	private $_clavisLibrarian;
	private $_actualLibraryId;

	private function initVars()
	{
		$this->_clavisLibrarian = $this->getUser();
		//$this->_actualLibraryId = $this->_clavisLibrarian->getActualLibraryId();
	}

	public function onInit($param)
	{
		parent::onInit($param);
		$this->initVars();

		//$isAdmin = $this->getUser()->getIsAdmin();
		
		if (!$this->getPage()->getIsCallBack())
		{
			$this->PatronStatus->populate();
			$this->PatronClass->populate();
						
			$libraries = LibraryPeer::getLibrariesHashWithBlank(null, true);	// only internal ones
			$this->FavLibrary->setDataSource($libraries);
			$this->FavLibrary->dataBind();
			
			$this->Work->populate();
			$this->StudyLevel->populate();
		}
	}

	public function onAssign($sender, $param)
	{
		ini_set("memory_limit", "700M");
		set_time_limit(0);
		$this->getPage()->cleanMessageQueue();

		$shelfItems = $this->getCheckedItems();

		if ($this->PatronStatusCheck->getChecked())
		{
			$patronStatus = $this->PatronStatus->getSelectedValue();
		}
		else
		{
			$patronStatus = self::DONTUPDATE;
		}
		
		if ($this->PatronClassCheck->getChecked())
		{
			$patronClass = $this->PatronClass->getSelectedValue();
		}
		else
		{
			$patronClass = self::DONTUPDATE;
		}		
		
		if ($this->AccessNoteCheck->getChecked())
		{
			$accessNote = trim($this->AccessNote->getSafeText());
		}
		else
		{
			$accessNote = self::DONTUPDATE;
		}

		if ($this->GenderCheck->getChecked())
		{
			$gender = $this->Gender->getSelectedValue();
		}
		else
		{
			$gender = self::DONTUPDATE;
		}		
		
		if ($this->FavLibraryCheck->getChecked())
		{
			if ($this->FavLibrary->getSelectedIndex() != 0)
			{
				$favLibrary = $this->FavLibrary->getSelectedValue();
			}
			else
			{
				$favLibrary = null;
			}
		}
		else
		{
			$favLibrary = self::DONTUPDATE;
		}		
		
		if ($this->WorkCheck->getChecked())
		{
			if ($this->Work->getSelectedIndex() != 0)
			{
				$work = $this->Work->getSelectedValue();
			}
			else
			{
				$work = null;
			}
		}
		else
		{
			$work = self::DONTUPDATE;
		}		

		if ($this->StudyLevelCheck->getChecked())
		{
			if ($this->StudyLevel->getSelectedIndex() != 0)
			{
				$studyLevel = $this->StudyLevel->getSelectedValue();
			}
			else
			{
				$studyLevel = null;
			}
		}
		else
		{
			$studyLevel = self::DONTUPDATE;
		}		
		
		if ($this->ActiveOpacCheck->getChecked())
		{
			$activeOpac = $this->ActiveOpac->getChecked();
		}
		else
		{
			$activeOpac = self::DONTUPDATE;
		}		

		if ($this->PrivacyApproveCheck->getChecked())
		{
			$privacyApprove = $this->PrivacyApprove->getChecked();
		}
		else
		{
			$privacyApprove = self::DONTUPDATE;
		}		
		
		if ($this->ExpirePasswordCheck->getChecked())
		{
			if (($this->ExpirePassword->getDate() != "")
					&& !is_null($this->ExpirePassword->getDate()))
			{
				$expirePassword = $this->ExpirePassword->getDate();
			}
			else
			{
				$expirePassword = null;
			}
		}
		else
		{
			$expirePassword = self::DONTUPDATE;
		}		
		
		if ($this->BirthCountryCheck->getChecked())
		{
			$birthCountry = trim($this->BirthCountry->getSafeText());
		}
		else
		{
			$birthCountry = self::DONTUPDATE;
		}

		if ($this->CitizenShipCheck->getChecked())
		{
			$citizenShip = trim($this->CitizenShip->getSafeText());
		}
		else
		{
			$citizenShip = self::DONTUPDATE;
		}
		
		$countDone = 0;
		$countFailed = 0;
		$countNotAuthorized = 0;
		$missingPatrons = array();
		
		if (count($shelfItems) > 0)
		{
			foreach ($shelfItems as $shelfItem)
			{
				if (!is_null($shelfItem))
				{
					if ($shelfItem->getObjectClass() == ShelfPeer::TYPE_PATRON)
					{
						$patron = null;
						$patronId = $shelfItem->getObjectId();
						
						if ($patronId > 0)
							$patron = PatronQuery::create()->findPk($patronId);
						
						if ($patron instanceof Patron)
						{
							//if ($this->_clavisLibrarian->getEditPermission($patron))		// we are allowed to modify that patron
							if (true)		// for now we won't check for permissions
							{
								$returnCode = $this->updateData(	$patron,
																	$patronStatus,
																	$patronClass,
																	$accessNote,
																	$gender,
										
																	$favLibrary,
																	$work,
																	$studyLevel,
																	$activeOpac,
																	$privacyApprove,

																	$expirePassword,
																	$birthCountry,
																	$citizenShip);

								if ($returnCode)
								{
									try
									{
										$patron->save();
										$countDone++;

										ChangelogPeer::logAction(	$patron, 
																	ChangelogPeer::LOG_UPDATE, 
																	$this->_clavisLibrarian,
																	'Plugin su Shelf [' . $this->getShelfId() . ']: cambio dati per utente con id=' . $patron->getPatronId());
									}
									catch (PropelException $exception)
									{
										$countFailed++;

										//Prado::log('Plugin ShelfChangeItems, errore: ' . $exception->getCause()->getMessage());
									}
								}
							}	// end of 'we are authorized in modify that patron'
							else
							{
								$countNotAuthorized++;
							}
							
							unset ($patron);
						}		// if a real patron exists
						else	// if no patron exists for that patron_id
						{
							$missingPatrons[] = $patronId;
						}
					}	// if the cycled object is a patron type
				}
				
				unset ($shelfItem);
			}
			
			if (count($missingPatrons) > 0)
			{
				$this->getPage()->enqueueMessage(Prado::localize("Attenzione: ci sono riferimenti a utenti non validi o non più esistenti, con id: {patronids}",
																	array('patronids' =>  implode(',', $missingPatrons) )),
													ClavisMessage::WARNING);
			}
		}

		$refreshFlag = false;
		
		// if no action has succeeded
		if ($countDone 
				+ $countFailed 
				+ $countNotAuthorized == 0)
		{
			$this->getPage()->enqueueMessage(Prado::localize('Nessuna azione eseguita'),
												ClavisMessage::INFO);
		}
		else	// some actions or errors occurred
		{
			if ($countDone > 0)
			{	
				$this->getPage()->enqueueMessage(Prado::localize("N. {count} utenti modificati con successo",
																	array('count' => $countDone)),
													ClavisMessage::CONFIRM);
				
				$refreshFlag = true;
			}

			if ($countNotAuthorized > 0)
			{
				$this->getPage()->enqueueMessage(Prado::localize("N. {count} utenti non modificati per mancanza di autorizzazione",
																	array('count' => $countNotAuthorized)),
													ClavisMessage::ERROR);
			}

			if ($countFailed > 0)
			{
				$errorCode = ClavisMessage::ERROR;
				$this->getPage()->enqueueMessage(Prado::localize("N. {count} utenti non modificati a causa di un errore",
																	array('count' => $countFailed)),
													ClavisMessage::ERROR);
			}
		}
		
		if (($countDone > 0)
				&& ($countFailed == 0)
				&& ($countNotAuthorized == 0))
		{
			// close popup
			$this->getPage()->flushDelayedMessage();
			$this->onClose();
		}
		else
		{
			// stay open
			$this->getPage()->flushMessage();
			
			if ($refreshFlag)
				$this->getPage()->shelfListRefresh($param);
		}
	}

	public function IsPopup()
	{
		return true;
	}

	private function updateData(	&$patron,
									$patronStatus,
									$patronClass,
									$accessNote,
									$gender,
			
									$favLibrary,
									$work,
									$studyLevel,
									$activeOpac,
									$privacyApprove,

									$expirePassword,
									$birthCountry,
									$citizenShip)
	{
		/* @var $patron Patron */
		$actionDoneFlag = false;

		if ($patronStatus !== self::DONTUPDATE)
		{
			$patron->setPatronStatus($patronStatus);
			$actionDoneFlag = true;
		}

		if ($patronClass !== self::DONTUPDATE)
		{
			$patron->setLoanClass($patronClass);
			$actionDoneFlag = true;
		}
		
		if ($accessNote !== self::DONTUPDATE)
		{
			$patron->setAccessNote($accessNote);
			$actionDoneFlag = true;
		}

		if ($gender !== self::DONTUPDATE)
		{
			$patron->setGender($gender);
			$actionDoneFlag = true;
		}
		
		if ($favLibrary !== self::DONTUPDATE)
		{
			$patron->setPreferredLibraryId($favLibrary);
			$actionDoneFlag = true;
		}

		if ($work !== self::DONTUPDATE)
		{
			$patron->setStatisticWork($work);
			$actionDoneFlag = true;
		}

		if ($studyLevel !== self::DONTUPDATE)
		{
			$patron->setStatisticStudy($studyLevel);
			$actionDoneFlag = true;
		}

		if ($activeOpac !== self::DONTUPDATE)
		{
			$patron->setOpacEnable($activeOpac);
			$actionDoneFlag = true;
		}

		if ($privacyApprove !== self::DONTUPDATE)
		{
			$patron->setPrivacyApprove($privacyApprove);
			$actionDoneFlag = true;
		}
		
		if ($expirePassword !== self::DONTUPDATE)
		{
			$patron->setOpacSecretExpire($expirePassword);
			$actionDoneFlag = true;
		}
		
		if ($birthCountry !== self::DONTUPDATE)
		{
			$patron->setBirthCountry($birthCountry);
			$actionDoneFlag = true;
		}

		if ($citizenShip !== self::DONTUPDATE)
		{
			$patron->setCitizenship($citizenShip);
			$actionDoneFlag = true;
		}
		
		return $actionDoneFlag;
	}
	
}