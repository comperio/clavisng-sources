<?php
/**
 * ShelfContentExtractISO2709 class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package ShelfPlugins
 */

/**
 * ShelfContentExtractISO2709 Class
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.7
 * @package ShelfPlugins
 * @since 2.2
 */

class ShelfContentExtractISO2709 extends ClavisPlugin
{
	public function setIsItemValid($valid = false)
	{
		$this->getApplication()->getSession()->add('IsItemValid', $valid, false);
	}

	public function getIsItemValid()
	{
		return $this->getApplication()->getSession()->itemAt('IsItemValid', false);
	}

	public function clearLibraryFields()
	{
		$this->Library->setText('');
		$this->LibraryId->setValue(null);
	}

	public function IsPopup()
	{
		return true;
	}

	public function onResetDates_dismissed($sender, $param)
	{
		$this->DateFrom->setText('');
 		$this->DateTo->setText('');

 		$this->getPage()->setFocus("FocusAnchor");
	}

	private function export($content)
	{
		if (!trim($content))
			throw new Exception('Content is null');


		$resp = Prado::getApplication()->getResponse();
		$resp->clear();
		$resp->setCacheControl('nocache');
		$resp->writeFile('extractISO2709_'.date('Y-m-d_H-i-s').'.txt', $content, 'application/txt');
        error_log("CONTENTE[$content]");
		
		die();

		Prado::getApplication()->completeRequest();
	}

    public function sebina4Map($tm)
    {
        return $tm;
    }

    public function convertUNI($tm )
    {
        switch($this->MarcFormat->getSelectedValue())
        {
            case "SEB4":
                foreach(array('d901','d907','d909','d951','d953') as $fld)
                    unset($tm->$fld);

                for($i=0; $i < $tm->d950->count(); $i++)
                {
                    $bibname = trim((string)$tm->d950[$i]->sy);
                    $invser  = (string)$tm->d950[$i]->sb;
                    $invnum  = (string)$tm->d950[$i]->sc;
                    $sez     = (string)$tm->d950[$i]->sd;
                    $coll    = (string)$tm->d950[$i]->sf;
                    $spec    = (string)$tm->d950[$i]->sg;
                    $seq1    = (string)$tm->d950[$i]->sh;
                    $seq2    = (string)$tm->d950[$i]->si;

                    unset($tm->d950[$i]);
                    $tm->d950[$i]->sa = $bibname;
                    //CQS         306.76      PIE         !

                    $tm->d950[$i]->sd = sprintf("%2s%-10s%-12s%-12s%-20s",substr($invser,0,2),$sez,$coll,$spec,$seq1.$seq2);
                    //CQ   0000470005
                    $tm->d950[$i]->se = sprintf("%-5s%09d",$invser,$invnum)."5";

                }
				
                break;
            default:
                
				break;

        }
		
        return $tm;
    }

	public function onExtract($sender, $param)
	{
		$shelfItems = $this->getCheckedItems();

		if ((count($shelfItems) > 0))
		{
			$countDone = 0;
			$countFailed = 0;
			$content = '';

			foreach ($shelfItems as $shelfItem)
			{
				$ok = false;
				if (!is_null($shelfItem))
				{
					if ($shelfItem->getObjectClass() == ShelfPeer::TYPE_MANIFESTATION)
					{
						$manifestationId = $shelfItem->getObjectId();
						$manifestation = ManifestationQuery::create()
											->findPk($manifestationId);
						
						if ($manifestation instanceof Manifestation)
						{
							$tm = $manifestation->cacheTurboMarc(true,false);
							if ($tm instanceof TurboMarc)
							{
                                $tm = $this->convertUNI($tm);
								$content .= $tm->getISO2709() . "\n";
								$ok = true;
							}
						}
					}
				}

				if ($ok)
					$countDone++;
				else
					$countFailed++;
			}

			$this->export($content);

			if ($countDone > 0)
				$this->getPage()->enqueueMessage((1 == $countDone)
														? Prado::localize('1 notizia esportata')
														: Prado::localize('{count} notizie esportate',
																			array('count' => $countDone)),
													ClavisMessage::CONFIRM);

			if ($countFailed > 0)
				$this->getPage()->enqueueMessage((1 == $countFailed)
														? Prado::localize('1 notizia non esportata')
														: Prado::localize('{count} notizie non esportate',
																			array('count' => $countFailed)),
													ClavisMessage::ERROR);

			if (($countDone == 0)
					&& ($countFailed == 0))
				$this->getPage()->enqueueMessage(Prado::localize('Non è stata effettuata alcuna operazione'),
													ClavisMessage::INFO);

			$this->getPage()->flushDelayedMessage();
			$this->onClose();
		}
		else
		{
			$this->getPage()->writeMessage(Prado::localize('Non è stato selezionato nessun elemento'),
											ClavisMessage::ERROR);
			
			return false;
		}
	}

}