<?php
/**
 * ShelfChangeIssues class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.8.9
 * @package ShelfPlugins
 */

/**
 * ShelfChangeIssues Class
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.8.9
 * @package ShelfPlugins
 * @since 2.1
 */

class ShelfChangeIssues extends ClavisPlugin
{
	const DONTUPDATE = '--%%impossibIlescriverEunastringacosiACaso%%--';

	private $_clavisLibrarian;
	private $_actualLibraryId;

	private function initVars()
	{
		$this->_clavisLibrarian = $this->getUser();
		$this->_actualLibraryId = $this->_clavisLibrarian->getActualLibraryId();
	}

	public function onInit($param)
	{
		parent::onInit($param);
		$this->initVars();

		$isAdmin = $this->getUser()->getIsAdmin();
		
		if (!$this->getPage()->getIsCallBack())
		{
			$this->IssueStatus->populate();
		}
	}

	public function setIsItemValid($valid = false)
	{
		$this->getApplication()->getSession()->add('IsItemValid', $valid, false);
	}

	public function getIsItemValid()
	{
		return $this->getApplication()->getSession()->itemAt('IsItemValid', false);
	}

	public function onAssign($sender, $param)
	{
		ini_set("memory_limit", "700M");
		set_time_limit(0);
		$this->getPage()->cleanMessageQueue();

		$shelfItems = $this->getCheckedItems();
		
		if ($this->IssueStatusCheck->getChecked())
		{
			$issueStatus = $this->IssueStatus->getSelectedValue();
		}
		else
		{
			$issueStatus = self::DONTUPDATE;
		}
		
		if ($this->IssueYearCheck->getChecked())
		{
			$issueYear = trim($this->IssueYear->getSafeText());
		}
		else
		{
			$issueYear = self::DONTUPDATE;
		}

		if ($this->SubscriptionIdCheck->getChecked())
		{
			$subscriptionId = trim($this->SubscriptionId->getSafeText());
		}
		else
		{
			$subscriptionId = self::DONTUPDATE;
		}

		if ($this->ItemIssueArrivalDateCheck->getChecked())
		{
			$itemIssueArrivalDate = $this->ItemIssueArrivalDate->getTimestamp();
		}
		else
		{
			$itemIssueArrivalDate = self::DONTUPDATE;
		}

		if ($this->ItemIssueArrivalDateExpectedCheck->getChecked())
		{
			$itemIssueArrivalDateExpected = $this->ItemIssueArrivalDateExpected->getTimestamp();
		}
		else
		{
			$itemIssueArrivalDateExpected = self::DONTUPDATE;
		}
		
		$skipLibraryCheck = $this->ForceAllCheck->getChecked();
		$skipDiscarded = $this->SkipDiscardedCheck->getChecked();
		
		$countDone = 0;
		$countFailed = 0;
		$countNotAuthorized = 0;
		$countAlreadyDiscarded = 0;
		$countNotHome = 0;
		$countNotIssueItem = 0;
		$missingItems = array();
		
		if (count($shelfItems) > 0)
		{
			foreach ($shelfItems as $shelfItem)
			{
				if (!is_null($shelfItem))
				{
					if ($shelfItem->getObjectClass() == ShelfPeer::TYPE_ITEM)
					{
						$item = null;
						$itemId = $shelfItem->getObjectId();
						
						if ($itemId > 0)
						{	
							$item = ItemQuery::create()
										->findPk($itemId);
						}
						
						if ($item instanceof Item)
						{
							if (false) //criterio per vedere se NON ha issue collegati)
							{
								$countNotIssueItem++;
							}
							elseif ($skipDiscarded
									&& ($item->getItemStatus() == ItemPeer::getItemStatusDiscarded()))
							{
								$countAlreadyDiscarded++;
							}
							else
							{
								if ($this->_clavisLibrarian->getEditPermission($item))		// we are allowed to modify that item
								{
									// first step
									if ($skipLibraryCheck
											|| ($item->getHomeLibraryId() == $this->_actualLibraryId))
									{
										$returnCodeHomeDoFlag = $this->updateItemDataWithHomePermission(	$item,
																											$issueStatus,
																											$issueYear,
																											$subscriptionId,
																											$itemIssueArrivalDate,
												
																											$itemIssueArrivalDateExpected);
									}
									else
									{
										$countNotHome++;
										$returnCodeHomeDoFlag = false;
									}

									if ($returnCodeHomeDoFlag)
									{
										try
										{
											$item->save();
											$countDone++;

											ChangelogPeer::logAction(	$item, 
																		ChangelogPeer::LOG_UPDATE, 
																		$this->_clavisLibrarian,
																		'Plugin su Shelf [' . $this->getShelfId() . ']: cambio dati per esemplare di fascicoli con id=' . $item->getItemId());
										}
										catch (PropelException $exception)
										{
											$countFailed++;

											//Prado::log('Plugin ShelfChangeItems, errore: ' . $exception->getCause()->getMessage());
										}
									}
								}	// end of 'we are authorized in modify that item'
								else
								{
									$countNotAuthorized++;
								}
							}
							
							unset ($item);
						}		// if a real item exists
						else	// if no item exists for that item_id
						{
							$missingItems[] = $itemId;
						}
					}	// if the cycled object is an item type
				}
				
				unset ($shelfItem);
			}
			
			if (count($missingItems) > 0)
			{
				$this->getPage()->enqueueMessage(Prado::localize("Attenzione: ci sono esemplari non validi o non più esistenti, con id: {itemids}",
																	array('itemids' =>  implode(',', $missingItems) )),
													ClavisMessage::WARNING);
			}
		}

		$refreshFlag = false;
		
		// if no action has succeeded
		if ($countDone 
				+ $countFailed 
				+ $countNotAuthorized 
				+ $countAlreadyDiscarded 
				+ $countNotHome 
				
				+ $countNotIssueItem == 0)
		{
			$this->getPage()->enqueueMessage(Prado::localize('Nessuna azione eseguita'),
												ClavisMessage::INFO);
		}
		else	// some actions or errors occurred
		{
			if ($countDone > 0)
			{	
				$this->getPage()->enqueueMessage(Prado::localize("N. {count} esemplari modificati con successo",
																	array('count' => $countDone)),
													ClavisMessage::CONFIRM);
				
				$refreshFlag = true;
			}

			if ($countNotHome > 0)
			{
				$this->getPage()->enqueueMessage(Prado::localize("N. {count} esemplari non modificati perché non gestiti della biblioteca attuale",
																	array('count' => $countNotHome)),
													ClavisMessage::WARNING);
			}

			if ($countNotIssueItem > 0)
			{
				$this->getPage()->enqueueMessage(Prado::localize("N. {count} esemplari non modificati non hanno fascicoli collegati",
																	array('count' => $countNotIssueItem)),
													ClavisMessage::WARNING);
			}

			if ($countNotAuthorized > 0)
			{
				$this->getPage()->enqueueMessage(Prado::localize("N. {count} esemplari non modificati per mancanza di autorizzazione",
																	array('count' => $countNotAuthorized)),
													ClavisMessage::ERROR);
			}

			if ($countAlreadyDiscarded > 0)
			{
				$this->getPage()->enqueueMessage(Prado::localize("N. {count} esemplari non modificati perchè sono già in stato di 'scartato",
																	array('count' => $countAlreadyDiscarded)),
													ClavisMessage::WARNING);				
			}
			
			if ($countFailed > 0)
			{
				$errorCode = ClavisMessage::ERROR;
				$this->getPage()->enqueueMessage(Prado::localize("N. {count} esemplari non modificati a causa di un errore",
																	array('count' => $countFailed)),
													ClavisMessage::ERROR);
			}
		}
		
		if (($countDone > 0)
				&& ($countFailed == 0)
				&& ($countNotAuthorized == 0)
				&& ($countAlreadyDiscarded == 0)
				&& ($countNotHome == 0)
				&& ($countNotIssueItem == 0))
		{
			// close popup
			$this->getPage()->flushDelayedMessage();
			$this->onClose();
		}
		else
		{
			// stay open
			$this->getPage()->flushMessage();
			
			if ($refreshFlag)
				$this->getPage()->shelfListRefresh($param);
		}
	}

	public function IsPopup()
	{
		return true;
	}

	private function updateItemDataWithHomePermission(	&$item, 
														$issueStatus,
														$issueYear,
														$subscriptionId,
														$itemIssueArrivalDate,

														$itemIssueArrivalDateExpected)
	{
		/* @var $item Item */
		$actionDoneFlag = false;

		if ($issueStatus !== self::DONTUPDATE)
		{
			$item->setIssueStatus($issueStatus);
			$actionDoneFlag = true;
		}

		if ($issueYear !== self::DONTUPDATE)
		{
			$item->setIssueYear($issueYear);
			$actionDoneFlag = true;
		}
		
		if ($subscriptionId !== self::DONTUPDATE)
		{
			$item->setSubscriptionId($subscriptionId);
			$actionDoneFlag = true;
		}

		if ($itemIssueArrivalDate !== self::DONTUPDATE)
		{
			$item->setIssueArrivalDate($itemIssueArrivalDate);
			$actionDoneFlag = true;
		}

		if ($itemIssueArrivalDateExpected !== self::DONTUPDATE)
		{
			$item->setIssueArrivalDateExpected($itemIssueArrivalDateExpected);
			$actionDoneFlag = true;
		}

		return $actionDoneFlag;
	}
	
}