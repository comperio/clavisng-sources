<?php
/**
 * ShelfItemMoveParent class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.9.0
 * @package ShelfPlugins
 */

/**
 * ShelfItemMoveParent Class
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.9.0
 * @package ShelfPlugins
 * @since 2.9.0
 */

class ShelfItemMoveParent extends ClavisPlugin
{
	private $_clavisLibrarian;

	private function initVars()
	{
		$this->_clavisLibrarian = $this->getUser();
	}

	public function onInit($param)
	{
		parent::onInit($param);
		$this->initVars();

		if (!$this->getPage()->getIsCallBack())
		{
			$this->doAnalyze();
		}
	}

	public function setIsItemValid($valid = false)
	{
		$this->getApplication()->getSession()->add('IsItemValid', $valid, false);
	}

	public function getIsItemValid()
	{
		return $this->getApplication()->getSession()->itemAt('IsItemValid', false);
	}

	private function setAnalyzedDataSource($param)
	{
		$this->setControlState('AnalyzedDataSource', $param, array());
	}

	private function getAnalyzedDataSource()
	{
		return $this->getControlState('AnalyzedDataSource', array());
	}
	
	public function IsPopup()
	{
		return true;
	}
		
	private function doAnalyze()
	{
		$dataSource = array();

		foreach ($this->getCheckedItems() as $shelfItem)
		{
			if (($shelfItem instanceof ShelfItem)
					&& ($shelfItem->getObjectClass() == ShelfPeer::TYPE_MANIFESTATION))	// only manifestations
			{
				$manifestation = null;
				$manifestationId = $shelfItem->getObjectId();

				if ($manifestationId > 0)
					$manifestation = ManifestationQuery::create()->findPk($manifestationId);

				if (($manifestation instanceof Manifestation)
						&& ($this->_clavisLibrarian->getEditPermission($manifestation))
						&& ($manifestation->getBibLevel() == ManifestationPeer::LVL_MONOGRAPHIC)
						&& ($manifestation->countItems() > 0))
				{
					////// logica per capire se c'e' una notizia superiore collegata alla presente
					
					$upperCandidates = LManifestationQuery::create()
											->condition('up1', 'LManifestation.ManifestationIdUp = ?', $manifestationId)
											->condition('up2', 'LManifestation.LinkType = ?', 461)
											->combine(array('up1', 'up2'), 'and', 'up')
											->condition('down1', 'LManifestation.ManifestationIdDown = ?', $manifestationId)
											->condition('down2', 'LManifestation.LinkType = ?', 463)
											->combine(array('down1', 'down2'), 'and', 'down')
											->where(array('down', 'up'), 'or')
											->find();

					if ($upperCandidates->count() > 0)
					{
						$parentManifestation = ($upperCandidates[0]->getLinkType() == 461)
														? $upperCandidates[0]->getManifestationRelatedByManifestationIdDown()
														: $upperCandidates[0]->getManifestationRelatedByManifestationIdUp();

						if ($parentManifestation instanceof Manifestation)
						{
							$dataSource[] = array(	'manifestationTitle' => $manifestation->getCompleteTitle(' - ')
																				. "&nbsp;(" . $manifestation->countItems() . " " . Prado::localize("esemplari") . ")",
													'manifestationUrl' => ManifestationPeer::getNavigateUrl($manifestationId),
													'manifestationId' => $manifestationId,
								
													'parentManifestationTitle' => $parentManifestation->getCompleteTitle(' - '),
													'parentManifestationUrl' => ManifestationPeer::getNavigateUrl($parentManifestation->getManifestationId()),
													'parentManifestationId' => $parentManifestation->getManifestationId(),
								
													'packedShelfItem' => $shelfItem->getPackedPK() );
						}	
					}
				}
			}
		}

		$this->ManifestationList->setDataSource($dataSource);
		$this->ManifestationList->dataBind();
		$this->setAnalyzedDataSource($dataSource);
		$this->AssignButton->setEnabled(count($dataSource) > 0);
	}
	
	public function onAction($sender, $param)
	{
		ini_set("memory_limit", "700M");
		set_time_limit(0);

		$manifestationsGrid = $this->getAnalyzedDataSource();

		if (count($manifestationsGrid) == 0)
		{
			$this->getPage()->writeMessage(Prado::localize("La lista delle notizie da usare è vuota."),
												ClavisMessage::INFO);
			
			return false;
		}
		
		$this->getPage()->cleanMessageQueue();

		$done = [];
		$notExisting = [];
		$failed = [];
		$notAuthorized = [];
		$deletedShelfItems = 0;

		/// begin of cycle where valid manifestations get processed
		foreach ($manifestationsGrid as $manifestationRow)
		{
			$manifestationId = $manifestationRow['manifestationId'];
			$parentManifestationId = $manifestationRow['parentManifestationId'];
			$manifestation = ManifestationQuery::create()->findPk($manifestationId);
			$parentManifestation = ManifestationQuery::create()->findPk($parentManifestationId);
			
			if (!($manifestation instanceof Manifestation))
			{
				$notExisting[] = $manifestationId;
				
				continue;
			}
			
			if (!($parentManifestation instanceof Manifestation))
			{
				$notExisting[] = $parentManifestationId;
				
				continue;
			}
			
			if (!$this->_clavisLibrarian->getEditPermission($manifestation))
			{
				$notAuthorized[] = $manifestationId;
				
				continue;
			}

			if (!$this->_clavisLibrarian->getEditPermission($parentManifestation))
			{
				$notAuthorized[] = $parentManifestationId;
				
				continue;
			}

			$parentManifestationTitle = $manifestationRow['parentManifestationTitle'];
			
			$returnValue = $this->doProcess(	$manifestationId, 
												$parentManifestationId,
												$parentManifestationTitle);
			
			if (is_int($returnValue)
					&& ($returnValue > 0))
			{
				$done[] = Prado::localize("{count} esemplari dalla notizia con id={manid} alla superiore con id={parentmanid}, titolo {parenttitle}",
												array(	'count' => $returnValue,
														'manid' => $manifestationId,
														'parentmanid' => $parentManifestationId,
														'parenttitle' => $parentManifestationTitle ));
				
				if (ShelfItemPeer::deleteByPackedPK($manifestationRow['packedShelfItem']))
					$deletedShelfItems++;
			}
			elseif (($returnValue == false)
						|| ($returnValue == 0))
			{
				$failed[] = $manifestationRow;
			}
		}
		/// end of cycle upon the processing

		if (empty($done)
				&& empty($notExisting)
				&& empty($failed)
				&& empty($notAuthorized))
		{
			$this->getPage()->enqueueMessage(Prado::localize("Nessuna azione eseguita"),
												ClavisMessage::INFO);
			
			$this->getPage()->flushMessage();
		}
		else
		{
			if (count($done) > 0)
			{
				$this->getPage()->enqueueMessage(Prado::localize("Esemplari passati a notizia superiore: {donestring}",
																	array('donestring' => implode(' /// ', $done))),
													ClavisMessage::CONFIRM);
				
				if ($deletedShelfItems > 0)
				{
					$this->getPage()->enqueueMessage(Prado::localize("{del} elementi dello scaffale sono stati cancellati.",
																		array('del' => $deletedShelfItems)),
														ClavisMessage::CONFIRM);
				}
			}	

			if (count($notAuthorized) > 0)
			{
				$this->getPage()->enqueueMessage(Prado::localize("Esemplari non passati a notizia superiore per mancanza di autorizzazione delle notizie con id={ids}",
																	array('ids' => implode(', ', $notAuthorized))),
													ClavisMessage::WARNING);
			}

			if (count($notExisting) > 0)
			{
				$this->getPage()->enqueueMessage(Prado::localize("Esemplari non passati a notizia superiore perchè non esistono le notizie con id={ids}",
																	array('ids' => implode(', ', $notExisting))),
													ClavisMessage::ERROR);
			}
			
			if (count($failed) > 0)
			{
				$this->getPage()->enqueueMessage(Prado::localize("Esemplari non passati a notizia superiore a causa di errori, per notizie con id={ids}",
																	array('ids' => implode(', ', $failed))),
													ClavisMessage::ERROR);
			}

			if (count($done) > 0)
			{
				$this->getPage()->flushDelayedMessage();
				$this->onClose();
			}
			else
			{
				$this->getPage()->flushMessage();
			}
		}
	}
	
	public function doProcess(	$manifestationId, 
								$parentManifestationId,
								$parentManifestationTitle)
	{
		if ($manifestationId == $parentManifestationId)
		{
			return false;
		}

		$items = ItemQuery::create()
						->filterByManifestationId($manifestationId)
						->find();

		$itemCount = 0;		
		
		foreach ($items as $item)
		{
			/* @var $item Item */

			try
			{
				$item->setManifestationId($parentManifestationId);
				$item->setTitle($parentManifestationTitle);

				$item->save();
				$itemCount++;
				
				ChangelogPeer::logAction(	$item, 
											ChangelogPeer::LOG_UPDATE, 
											$this->getUser(), 
											"Esemplare spostato da notizia con id=$manifestationId a notizia con id=$parentManifestationId");
			}
			catch (PropelException $pe)
			{
				//return false;
			}
		}
		
		try
		{
			$parentManifestation = ManifestationQuery::create()->findPk($parentManifestationId);
			$parentManifestation->doIndex();  //invalidateCache();
			
			ManifestationQuery::create()->findPk($manifestationId)->delete();
			
			LManifestationQuery::create()
						->condition('up', 'LManifestation.ManifestationIdUp = ?', $manifestationId)
						->condition('down', 'LManifestation.ManifestationIdDown = ?', $manifestationId)
						->where(array('down', 'up'), 'or')
						->delete();
			
			ChangelogPeer::logAction(	"Manifestation", 
										ChangelogPeer::LOG_UPDATE, 
										$this->getUser(), 
										"Spostati $itemCount esemplari da notizia con id=$manifestationId",
										$parentManifestationId);
		}
		catch (PropelException $pe)
		{
			//return false;
		}
		
		/// deve restituire un intero col numero degli esemplari spostati (per singola notizia, da sommare dopo)
		return $itemCount;
	}

}