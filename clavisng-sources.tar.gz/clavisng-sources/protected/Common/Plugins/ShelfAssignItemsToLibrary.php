<?php
/**
 * ShelfAssignItemsToLibrary class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package ShelfPlugins
 */

/**
 * ShelfAssignItemsToLibrary Class
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.8.9
 * @package ShelfPlugins
 * @since 2.4
 */

class ShelfAssignItemsToLibrary extends ClavisPlugin
{
	public static function getTargetShelfTypes()
	{
		return array(ShelfPeer::TYPE_ITEM);
	}
	
	public static function getEditMode()
	{
		return ShelfPeer::EDITTYPE_EDIT;
	}

	public function setIsItemValid($valid = false)
	{
		$this->getApplication()->getSession()->add('IsItemValid', $valid, false);
	}

	public function getIsItemValid()
	{
		return $this->getApplication()->getSession()->itemAt('IsItemValid', false);
	}

	public function onAssign($sender, $param)
	{
		$clavisLibrarian = $this->getUser();
		/** @var ClavisLoanManager $loanmanager */
		$loanmanager = $this->getApplication()->getModule('loan');

		if ($this->RevertToOwner->getChecked())
		{
			$reassignToOwner = true;
		} 
		else 
		{
			$reassignToOwner = false;
			$toLibraryId = intval($this->LibraryId->getValue());
		
			if (!($toLibraryId > 0))
			{
				$this->clearLibraryFields();
				$this->getPage()->writeMessage(Prado::localize('Biblioteca selezionata per la gestione esemplari non valida'), 
												ClavisMessage::ERROR);
			
				return false;
			}
			
			$toLibrary = LibraryQuery::create()->findPk($toLibraryId);
			$toLibraryString = $toLibrary->getTrimmedDescription(50);
		}
		
		$shelfItems = $this->getCheckedItems();
		$countDone = 0;
		$countFailed = 0;
		$countLoaned = 0;
		$countNotAuthorized = 0;
		$countAlreadyOut = 0;

		foreach ($shelfItems as $shelfItem)
		{
			if (!is_null($shelfItem) 
					&& ($shelfItem->getObjectClass() == ShelfPeer::TYPE_ITEM))
			{
				$item = ItemQuery::create()->findPk($shelfItem->getObjectId());
				
				if ($item instanceof Item)
				{
					if (!$reassignToOwner
							&& !is_null($item->getPrevHomeLibraryId()))
					{
						$countAlreadyOut++;
					}
					elseif (!$clavisLibrarian->getEditPermission($item))
					{
						$countNotAuthorized++;
					}
					else
					{
						try
						{
							if ($reassignToOwner)
							{
								$toLibraryId = $item->getPrevHomeLibraryId();
								
								if (is_null($toLibraryId)) // old code compatibility
									$toLibraryId = $item->getOwnerLibraryId();
							}
							
							$returnCode = $loanmanager->DoReassignItemToLibrary(	$toLibraryId,
																					$item,
																					$clavisLibrarian,
																					true);	// plugin mode
							
							switch ($returnCode)
							{
								case ClavisLoanManager::OK:
									$countDone++;
							
									break;
								
								case ClavisLoanManager::ERROR:
									$countFailed++;
									
									break;
								
								default:
									
									break;
							}
						}
						catch (PropelException $exception)
						{
							$countFailed++;
							//throw $exception;
						}
					}
				}
				else
				{
					$this->getPage()->enqueueMessage(Prado::localize("Errore sull'esemplare con id = {itemId}",
																		array('itemId' => $shelfItem->getObjectId())),
														ClavisMessage::ERROR);
				}
			}
		}
		
		$toLibraryString = $reassignToOwner
								? Prado::localize("di gestione precedente")
								: "\"$toLibraryString\"";

		if ($countDone > 0)
			$this->getPage()->enqueueMessage(Prado::localize('N. {count} esemplari in gestione alla biblioteca {libraryName}',
																array(	'count' => $countDone,
																		'libraryName' => $toLibraryString )),
												ClavisMessage::INFO);

		if ($countAlreadyOut > 0)
			$this->getPage()->enqueueMessage(Prado::localize('N. {count} esemplari NON in gestione alla biblioteca {libraryName} perchè già in gestione ad altre biblioteche',
																array(	'count' => $countAlreadyOut,
																		'libraryName' => $toLibraryString)),
												ClavisMessage::WARNING);

		if ($countFailed > 0)
			$this->getPage()->enqueueMessage(Prado::localize('N. {count} esemplari NON in gestione alla biblioteca {libraryName} a causa di errori',
																array(	'count' => $countFailed,
																		'libraryName' => $toLibraryString )),
												ClavisMessage::WARNING);

		if ($countLoaned > 0)
			$this->getPage()->enqueueMessage(Prado::localize('N. {count} esemplari NON in gestione alla biblioteca {libraryName} perché attualmente in stato di prestito',
																array(	'count' => $countLoaned, 
																		'libraryName' => $toLibraryString)), 
												ClavisMessage::WARNING);

		if ($countNotAuthorized > 0)
			$this->getPage()->enqueueMessage(Prado::localize('N. {count} esemplari NON in gestione alla biblioteca {libraryName} per mancanza di autorizzazione alla modifica',
																array(	'count' => $countNotAuthorized,
																		'libraryName' => $toLibraryString)),
												ClavisMessage::WARNING);

		if ($countDone + $countAlreadyOut + $countFailed + $countLoaned + $countNotAuthorized == 0)
		{
			$this->getPage()->enqueueMessage(Prado::localize("Nessuna operazione eseguita"),
												ClavisMessage::INFO);
		}
		
		if ($countDone > 0)
		{
			$this->getPage()->flushDelayedMessage();
			$this->onClose();
		}
		else
		{
			////////$this->getPage()->shelfListRefresh($param);
			$this->getPage()->flushMessage();
		}
	}

	public function onResetLibrary($sender, $param)
	{
		$this->doResetLibrary($param);
	}

	private function doResetLibrary($param = null)
	{
		$this->Library->setText("");
		$this->LibraryId->setValue('');
		
		$this->renderLibraryPanel($param);
	}
	
	private function renderLibraryPanel($param = null)
	{
		$this->LibraryPanel->render(is_null($param)
										? $this->createWriter()
										: $param->getNewWriter());
	}

	public function clearLibraryFields()
	{
		$this->Library->setText('');
		$this->LibraryId->setValue(null);
	}

	public function IsPopup()
	{
		return true;
	}

}