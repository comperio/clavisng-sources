<?php
/**
 * ShelfPatronChangeClass class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.8.9
 * @package ShelfPlugins
 */

/**
 * ShelfPatronChangeClass Class
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.8.9
 * @package ShelfPlugins
 * @since 2.1
 */

class ShelfPatronChangeClass extends ClavisPlugin
{
	const DONTUPDATE = '--%%impossibIlescriverEunastringacosiACaso%%--';

	private $_clavisLibrarian;
	///public $customs_type = array('text', 'text', 'text');

	public static function getTargetShelfTypes()
	{
		return array(ShelfPeer::TYPE_PATRON);
	}
	
	public static function getEditMode()
	{
		return ShelfPeer::EDITTYPE_EDIT;
	}
	
	private function initVars()
	{
		$this->_clavisLibrarian = $this->getUser();
		//$this->_actualLibraryId = $this->_clavisLibrarian->getActualLibraryId();
	}

	public function onInit($param)
	{
		parent::onInit($param);
		$this->initVars();

		//$isAdmin = $this->getUser()->getIsAdmin();
		
		if (!$this->getPage()->getIsCallBack())
		{
			$classListValues = $this->getClassShelves();
			$this->ClassList->setDataSource($classListValues);
			$this->ClassList->dataBind();
		}
	}

	private function getClassShelves()
	{
		$retValue = array('---');
		
		$shelves = ShelfQuery::create()
					->filterByShelfName("classe %", Criteria::LIKE)
					->filterByShelfDescription("%-%", Criteria::LIKE)
					->filterByLibraryId($this->getUser()->getActualLibraryId())
//					->clearSelectColumns()
//					->addSelectColumn(ShelfPeer::SHELF_DESCRIPTION)
					->addAscendingOrderByColumn(ShelfPeer::SHELF_DESCRIPTION)
					->find();
		
		foreach ($shelves as $shelf)
		{
			$exploded = explode('-', $shelf->getShelfDescription());

			if (isset($exploded[0]) && $exploded[0])
				$retValue[$shelf->getShelfId()] = $exploded[0] . " (" . $shelf->getShelfName() . ")";
		}

		return $retValue;
	}
	
	public function onAction($sender, $param)
	{
		ini_set("memory_limit", "700M");
		set_time_limit(0);
		$this->getPage()->cleanMessageQueue();

		$shelfItems = $this->getCheckedItems();
		
		if ($this->ClassList->getSelectedIndex() != 0)
		{
			$classChosen = $this->ClassList->getSelectedItem();
			$newShelfId = $classChosen->getValue();
			$newClassText = $classChosen->getText();
			
			$exploded = explode('-', ShelfQuery::create()->findPk($newShelfId)->getShelfDescription());
			$newClass = $exploded[0];
		}
		else
		{
			$this->getPage()->writeMessage(Prado::localize('É necessario scegliere una classe di destinazione'),
												ClavisMessage::INFO);
			
			return;
		}
		
		$patronsDone = [];
		$patronsFailed = [];
		$patronsNotAuthorized = [];
		$patronsMissing = [];
		
		if (count($shelfItems) > 0)
		{
			foreach ($shelfItems as $shelfItem)
			{
				if (!is_null($shelfItem))
				{
					if ($shelfItem->getObjectClass() == ShelfPeer::TYPE_PATRON)
					{
						$patron = null;
						$patronId = $shelfItem->getObjectId();
						
						if ($patronId > 0)
							$patron = PatronQuery::create()->findPk($patronId);
						
						if ($patron instanceof Patron)
						{
							if ($this->_clavisLibrarian->getEditPermission($patron))		// we are allowed to modify that patron
							//if (true)		// for now we won't check for permissions
							{
								try
								{
									$patron->setCustom3($newClass);
									$patron->save();
									$patronsDone[] = $patronId;

									$newShelfItem = new ShelfItem();
									$newShelfItem->setShelfId($newShelfId);
									$newShelfItem->setObjectId($shelfItem->getObjectId());
									$newShelfItem->setObjectClass($shelfItem->getObjectClass());
									$newShelfItem->save();
									$shelfItem->delete();
									
									ChangelogPeer::logAction(	$patron, 
																ChangelogPeer::LOG_UPDATE, 
																$this->_clavisLibrarian,
																'Plugin su scaffale [' . $this->getShelfId() . ']: cambio classe a \'' . $newClassText . '\' con id scaffale=' . $newShelfId); 
								}
								catch (PropelException $exception)
								{
									$patronsFailed[] = $patronId;
									//Prado::log('Plugin ShelfChangeItems, errore: ' . $exception->getCause()->getMessage());
								}
								
							}	// end of 'we are authorized in modify that patron'
							else
							{
								$patronsNotAuthorized[] = $patronId;
							}
							
							unset ($patron);
						}		// if a real patron exists
						else	// if no patron exists for that patron_id
						{
							$patronsMissing[] = $patronId;
						}
					}	// if the cycled object is a patron type
				}
				
				//unset ($shelfItem);
			}
			
			if (count($patronsMissing) > 0)
			{
				$this->getPage()->enqueueMessage(Prado::localize("Attenzione: ci sono riferimenti a utenti non validi o non più esistenti, con id: {patronids}",
																	array('patronids' =>  implode(',', $patronsMissing))),
													ClavisMessage::WARNING);
			}
		}

		$refreshFlag = false;
		
		// if no action has succeeded
		if (count($patronsDone) 
				+ count($patronsFailed) 
				+ count($patronsNotAuthorized) == 0)
		{
			$this->getPage()->enqueueMessage(Prado::localize('Nessuna azione di spostamento di classe eseguita'),
												ClavisMessage::INFO);
		}
		else	// some actions or errors occurred
		{
			if (count($patronsDone) > 0)
			{	
				$this->getPage()->enqueueMessage(Prado::localize("Id degli utenti spostati nella classe '{classe}': {patronsDone}",
																	array(	'patronsDone' => implode(',', $patronsDone) . ", totale: " .count($patronsDone),
																			'classe' => $newClassText )),
													ClavisMessage::CONFIRM);
				
				$refreshFlag = true;
			}

			if (count($patronsNotAuthorized) > 0)
			{
				$this->getPage()->enqueueMessage(Prado::localize("Id degli utenti non spostati nella classe '{classe}' per mancanza di autorizzazione: {patronsNotAuthorized}",
																	array(	'patronsNotAuthorized' => implode(',', $patronsNotAuthorized) . ", totale: " .count($patronsNotAuthorized),
																			'classe' => $newClassText )),
													ClavisMessage::ERROR);
			}

			if (count($patronsFailed) > 0)
			{
				$this->getPage()->enqueueMessage(Prado::localize("Id degli utenti non spostati a causa di un errore: {patronsFailed}",
																	array('patronsFailed' => implode(',', $patronsFailed) . ", totale: " .count($patronsFailed))),
													ClavisMessage::ERROR);
			}
		}
		
		if ((count($patronsDone) > 0)
				&& (count($patronsFailed) == 0)
				&& (count($patronsNotAuthorized) == 0))
		{
			// close popup
			$this->getPage()->flushDelayedMessage();
			$this->onClose();
		}
		else
		{
			// stay open
			$this->getPage()->flushMessage();
			
			if ($refreshFlag)
				$this->getPage()->shelfListRefresh($param);
		}
	}

	public function IsPopup()
	{
		return true;
	}
	
}