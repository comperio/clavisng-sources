<?php
/**
 * ShelfDeleteIssues class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.8.7
 * @package ShelfPlugins
 */

/**
 * ShelfDeleteIssues Class
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.8.7
 * @package ShelfPlugins
 * @since 2.8.7
 */

class ShelfDeleteIssues extends ClavisPlugin
{
	const EXIT_OK = 111;
	const EXIT_FAILED = 222;
	const EXIT_STILLITEMLOANS = 333;
	const EXIT_NOTAUTHORIZED = 444;
	
	private $_clavisLibrarian;

	private function initVars()
	{
		$this->_clavisLibrarian = $this->getUser();
	}

	public function onInit($param)
	{
		parent::onInit($param);
		
		$this->initVars();
	}

	public function onAction($sender, $param)
	{
		$captchaSuccess = $this->CaptchaSuccessFlag->getValue();
		
		if ($captchaSuccess != 1)
		{
			$this->writeMessage(Prado::localize('Errore di autenticazione col captcha'),
									ClavisMessage::ERROR);
			
			return false;
		}
		
		ini_set("memory_limit", "700M");
		set_time_limit(0);
		
		$this->getPage()->cleanMessageQueue();
		
		$shelfItems = $this->getCheckedItems();

		$countDone = 0;
		$countFailed = 0;
		$countInLoan = 0;
		$countNotAuthorized = 0;

		if (count($shelfItems) > 0)
		{
			foreach ($shelfItems as $shelfItem)
			{
				if ($shelfItem instanceof ShelfItem)
				{
					if ($shelfItem->getObjectClass() == ShelfPeer::TYPE_ISSUE)
					{
						$issue = null;
						$issueId = intval($shelfItem->getObjectId());
						
						if ($issueId > 0)
							$issue = IssueQuery::create()->findPk($issueId);
						
						if ($issue instanceof Issue)
						{
							$exitValue = $this->doAction($issue);
										
							switch ($exitValue)
							{
								case self::EXIT_OK:
									$countDone++;
									$shelfItem->delete();

									break;

								case self::EXIT_STILLITEMLOANS:
									$countInLoan++;
									
									break;
								
								case self::EXIT_NOTAUTHORIZED;
									$countNotAuthorized++;
									
									break;

								case self::EXIT_FAILED:
								default:
									$countFailed++;
							}

							ChangelogPeer::logAction(	'issue',
														ChangelogPeer::LOG_UPDATE,
														$this->_clavisLibrarian,
														'Plugin su scaffale con id= ' . $this->getShelfId() . ': fascicolo con id:'
															. $issueId . ' cancellato',
														$issueId);
						}
						else
						{
							$this->getPage()->enqueueMessage(Prado::localize("Errore interno di reperimento del fascicolo con id={id}",
																					array('id' => $issueId)),
																	ClavisMessage::ERROR);
						}
					}
				}
			}
		}

		$this->getPage()->enqueueMessage(Prado::localize("{count} fascicoli cancellati, con tutti gli oggetti e informazioni ad essi collegati",
																array('count' => $countDone)),
											ClavisMessage::CONFIRM);

		if ($countFailed > 0)
		{
			$this->getPage()->enqueueMessage(Prado::localize("{count} fascicoli non cancellati a causa di errori",
																	array('count' => $countFailed)),
												ClavisMessage::ERROR);
		}	
			
		if ($countNotAuthorized > 0)
		{
			$this->getPage()->enqueueMessage(Prado::localize("{count} fascicoli non cancellati per mancanza di permessi",
																	array('count' => $countNotAuthorized)),
												ClavisMessage::ERROR);
		}

		if ($countInLoan > 0)
		{
			$this->getPage()->enqueueMessage(Prado::localize("{count} fascicoli non cancellati perchè con esemplari in stato di prestito",
																	array('count' => $countInLoan)),
												ClavisMessage::WARNING);
		}
		
		$this->getPage()->flushDelayedMessage();
		
		$this->onClose();
	}

	private function doAction(&$issue)
	{
		/* @var $issue Issue */
		/* @var $item Item */
		$exitValue = self::EXIT_FAILED;
		
		try
		{
			$myLibraryIds = Prado::getApplication()->getUser()->getLibraryIds();
			$issueId = $issue->getIssueId();
			$items = $issue->getItems();
			
			$loanedItemIds = array();
			$notAuthorizedItemIds = array();
			$freeItemIds = array();
			
			foreach ($items as $item)
			{
				$itemId = $item->getItemId();

				if (!in_array($item->getHomeLibraryId(), $myLibraryIds)
							|| !Prado::getApplication()->getUser()->getEditPermission($item))	// if the item's home is not one of the user's libraries or we don't have permissions
				{	
					$notAuthorizedItemIds[] = $itemId;
				}
				elseif (!is_null($item->getPatronId())
						|| !is_null($item->getExternalLibraryId()))		// if it's actually in loan
				{
					$loanedItemIds[] = $itemId;
				}	
				else
				{
					$freeItemIds[] = $itemId;	// items where we can operate
				}
			}

			$loanExist = (count($loanedItemIds) > 0);
			$notAuthorizedExist = (count($notAuthorizedItemIds) > 0);
			$allItemsId = array_merge($freeItemIds, $loanedItemIds);
			
			ItemActionQuery::create()
						->filterByItemId($freeItemIds)
						->delete();

			ChangelogQuery::create()
						->filterByObjectClass('Item')
						->filterByObjectId($freeItemIds)
						->delete();

			LoanQuery::create()
						->filterByItemId($freeItemIds)
						->filterByLoanStatus(ItemPeer::getLoanStatusClosed())
						->update(array('ItemId' => 0));

			ItemRequestQuery::create()
							->filterByItemId($allItemsId)
							->update(array('ItemId' => null));

			ShelfItemQuery::create()
							->filterByObjectClass('item')
							->filterByObjectId($allItemsId)
							->delete();

			ItemNoteQuery::create()
							->filterByItemId($allItemsId)
							->delete();

			LAuthorityItemQuery::create()
							->filterByItemId($allItemsId)
							->delete();

			AttachmentQuery::create()
						->filterByObjectType('Item')
						->filterByObjectId($allItemsId)
						->delete();
			
			ItemQuery::create()
						->findPks($freeItemIds)
						->delete();
				
			if (!$loanExist
					&& !$notAuthorizedExist)	// we can manage the issue
			{	
				ChangelogQuery::create()
						->filterByObjectClass('Issue')
						->filterByObjectId($issueId)
						->delete();
				
				AttachmentQuery::create()
						->filterByObjectType('Issue')
						->filterByObjectId($issueId)
						->delete();
							
				$issue->delete();
				
				$exitValue = self::EXIT_OK;
			}
			else
			{
				if ($notAuthorizedExist)
				{
					$exitValue = self::EXIT_NOTAUTHORIZED;
				}
				elseif ($loanExist)
				{
					$exitValue = self::EXIT_STILLITEMLOANS;
				}
			}
		}
		catch (PropelException $exception)
		{
			//$errorMessage = $exception->getCause()->getMessage();
			//var_dump($errorMessage);die;
		}
									
		return $exitValue;
	}
	
	public function IsPopup()
	{
		return true;
	}
	
}