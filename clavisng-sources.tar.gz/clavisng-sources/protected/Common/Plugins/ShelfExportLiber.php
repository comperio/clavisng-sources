<?php
/**
 * ShelfExport class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @author Dario Rigolin <dario@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.8.9
 * @package ShelfPlugins
 *
 * see contrib/oneshot_scripts/liber_plugin_*.sql to manage this plugin
 */

/**
 * Get the NumberFormat class.
 */
Prado::using('System.I18N.core.NumberFormat');

/**
 * ShelfExport Class
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @author Dario Rigolin <dario@comperio.it>
 * @version 2.8.9
 * @package ShelfPlugins
 * @since 2.2
 */
class ShelfExportLiber extends ClavisPlugin
{
	const DELIMITER = ',';
	const ENCLOSURE = '"';
	//See https://webcomperio.atlassian.net/browse/CNG-1329?focusedCommentId=36024
	const ISBD_SEPARATOR = ". - ";
	protected $evalLabels = [];

	public static function getTargetShelfTypes()
	{
		return array( ShelfPeer::TYPE_MANIFESTATION );
	}
	
	public static function getEditMode()
	{
		return ShelfPeer::EDITTYPE_NONEDIT;
	}
	
	public function onLoad($param)
	{
		parent::onLoad($param);
		
		if (!$this->getPage()->getIsCallBack())
		{
			$itemType = '';
			$shelf = $this->getShelf();
			
			if ($shelf instanceof Shelf)
			{
				$itemType = $shelf->getShelfItemtype();
			}

			if (is_null($this->getItemType()))
			{
				$this->setItemType($itemType);
			}
			
			if($itemType != ShelfPeer::TYPE_MANIFESTATION)
			{
				$this->getPage()->writeMessage(Prado::localize("Tipo di oggetti non esportabile"),
					ClavisMessage::ERROR);
				$this->thiExportLiberPanel->setVisible(false);
			}
		}
	}

	private function setItemType($param)
	{
		$this->setControlState('ItemType', $param, null);
	}

	private function getItemType()
	{
		return $this->getControlState('ItemType', null);
	}

	

	public function isDataSourceNeeded()
	{
		return true;
	}

	public function IsPopup()
	{
		return true;
	}

	// START ISBD See protected/Lib/TurboMarc.php
	
	protected function getTitle($field, $escape = true)
	{
		$titlefields = [];
		$findH = false;
		foreach ($field->children() as $sf)
		{
			$v = trim((string)$sf);
			if ($escape)
			{
				$v = str_replace(array(" ; ", " : ", " / "), array(" \\; ", " \\: ", " \\/ "), $v);
			}
				
			switch ($sf->getName())
			{
				case 'sa':
					if (count($titlefields) == 0) 
					{
						$titlefields[] = $v;
					} else {
						$titlefields[] = " ; $v";
					}
					break;
				case 'sc':
					$titlefields[] = $v;
					break;
				case 'sd':
					$titlefields[] = " = $v";
					break;
				case 'se':
					$titlefields[] = " : $v";
					break;
				case 'sh':
					$findH = true;
					$titlefields[] = (($escape) ? "^. $v" : ". $v");
					break;
				case 'si':
					if ($escape)
					{
						$titlefields[] = ($findH) ? "^, $v" : "^. $v";
					}
					else
					{
						$titlefields[] = ($findH) ? ", $v" : ". $v";
					}
					break;
					//Missing on TurboMarc.php. Use space, see CNG-1329?focusedCommentId=36020
				case 'sv':
					$titlefields[] = " " . $v;
					break;
			}//switch
		}//foreach
		
		return implode('' , $titlefields);
	}
	
	protected function getAuthor($field, $escape = true)
	{
		$authorfields = [];
		foreach ($field->children() as $sf)
		{
			$v = trim((string)$sf);
			if ($escape)
			{
				$v = str_replace(array(" ; ", " : ", " / "), array(" \\; ", " \\: ", " \\/ "), $v);
			}
				
			switch ($sf->getName()) 
			{
				case 'sf':
					$authorfields[] = "$v";
					break;
				case 'sg':
					$authorfields[] = " ; $v";
					break;
			}
		}

		return implode('', $authorfields);
	}
	
	
	
		
	/**
	 *
	 * @param boolean $ind
	 * @param boolena $escape Escape isbd syntax
	 * @return string
	 */
	protected function getPublication($field, $escape = true)
	{
		$pubfields = [];
		foreach ($field->children() as $sf) 
		{
			$v = trim((string)$sf);
			if ($escape)
			{
				$v = str_replace(array(", ", " ; ", " : "), array("\\, ", " \\; ", " \\: "), $v);
			}
				
			switch ($sf->getName()) 
			{
				case 'sc':
					$pubfields[] = $v;
					break;
				case 'sd':
					$pubfields[] = ', '. $v;
					break;
			}
		}
		return implode('', $pubfields);
	}
	
	// END ISBD
	
	
	protected function getRivistaRow($tm)
	{
		$csvrow = array_fill(0,6,'');
		try
		{
			$csvrow[0] = (isset($tm->d109->sa)) ? substr($tm->d109->sa, 32, 3) : '';
			
			$f1 = [];
			if(isset($tm->d700->sa)) $f1[] = trim((string)$tm->d700->sa);
			if(isset($tm->d710->sa)) $f1[] = trim((string)$tm->d710->sa);
			$csvrow[1] = implode(self::ISBD_SEPARATOR, $f1);
			
			$csvrow[2] =(isset($tm->d333->sa)) ? trim((string)$tm->d333->sa) : '';
			
			if(isset($tm->d200))
			{
				$csvrow[3] = $this->getTitle($tm->d200);
			}
			
			$apub = [];
			foreach ($tm->d210 as $pubfield)
			{
				$apub[] = $this->getPublication($pubfield);
			}
			$csvrow[4] = implode(self::ISBD_SEPARATOR, $apub);
			
			$csvrow[5] =(isset($tm->d330->sa)) ? trim((string)$tm->d330->sa) : '';
		}catch(Exception $ex){
			$csvrow[0] = "Err. manif. id {$manif->getManifestationId()}";
		}
		return $csvrow;
	}

	protected function getFascicoloRow($tm)
	{
		$csvrow = array_fill(0,11,'');
		
		try
		{
			$csvrow[0] = (isset($tm->d109->sa)) ? substr($tm->d109->sa, 32, 3) : '';
			
			
			if(isset($tm->d200))
			{
				$csvrow[1] = $this->getTitle($tm->d200);
				$csvrow[2] = $this->getAuthor($tm->d200);
			}
			
			$apub = [];
			foreach ($tm->d210 as $pubfield)
			{
				$apub[] = $this->getPublication($pubfield);
			}
			$csvrow[3] = implode(self::ISBD_SEPARATOR, $apub);
			
			$apd = $tm->getPhysicalDescs(); //this return 0-n d215.
			$csvrow[4] = implode(self::ISBD_SEPARATOR,$apd);
			
			
			if(isset($tm->d225))
			{
				$f5=[];
				foreach($tm->d225->children() as $sf)
				{
					if(in_array($sf->getTag(),['a','d','e','i']))
					{
						$fv = trim((string)$sf);
						if($fv != '') $f5[]=$fv;
					}
				}
				$csvrow[5] = implode(self::ISBD_SEPARATOR, $f5);
			}
	
			
			$csvrow[6] = (isset($tm->d010->sa)) ? trim((string)$tm->d010->sa) : '';
	
			$csvrow[7] = (isset($tm->d010->sd)) ? html_entity_decode(trim((string)$tm->d010->sd), ENT_COMPAT, 'UTF-8') : '';
			
			$csvrow[8] = (isset($tm->d330->sa)) ? trim((string)$tm->d330->sa) : '';
			
			if(isset($tm->d109->sa))
			{
				$csvrow[9] = trim(substr((string)$tm->d109->sa, 18, 2)) .'-'.trim(substr((string)$tm->d109->sa, 20, 2));			
				$csvrow[10] = $this->evalLabels[substr((string)$tm->d109->sa, 22, 1)];
			}
		}catch(Exception $ex){
			$csvrow[0] = "Err. manif. id {$manif->getManifestationId()}";
		}
		return $csvrow;
	}
	
	public function onExport($sender, $param)
	{
		if(count($this->evalLabels) == 0)
		{
			$evalUC = UnimarcCodesQuery::create()
			->filterByLanguage(Prado::getApplication()->getGlobalization()->getCulture())
			->filterByFieldNumber(109)
			->filterBySubfieldTag('a')
			->filterByPos(22)
			->find();
			
			foreach($evalUC as $uc)
			{
				$this->evalLabels[trim($uc->getCodeValue())] = $uc->getLabel();
			}
		}
		
		$itemType = $this->getItemType();
		$objectIds = array();
		
		foreach ($this->getCheckedItemsIds() as $rowShelfItemArray)
		{
			if ($rowShelfItemArray[2] == $itemType)
				$objectIds[] = $rowShelfItemArray[1];
		}
		
		
		if ($itemType == ShelfPeer::TYPE_MANIFESTATION)
		{
			$query = ManifestationQuery::create()
						->filterByManifestationId($objectIds);
		}
		else
		{
				$this->getPage()->writeMessage(Prado::localize("Impossibile esportare"),
												ClavisMessage::ERROR);

				return false;
		}
		
		if ($query->count() == 0)    // no objects to export were found
		{
			$this->getPage()->writeMessage(Prado::localize("Nessun oggetto da esportare"),
											ClavisMessage::ERROR);
			
			return false;
		}

		// beginning of the real exporting section
		ini_set("memory_limit", "700M");
		set_time_limit(0);

		$mans = $query->setFormatter(ModelCriteria::FORMAT_ON_DEMAND)->find();

		$encoding = ($this->FormatForExcel->getChecked()
							? 'Windows-1252'
							: 'UTF-8');
		
		$now = getdate();
		$dateSubfix = $now['year'] . "-" . $now['mon'] . "-" . $now['mday'];
	
		// here we put out the document file
		header('Content-Type: text/csv; charset=' . $encoding);
		header('Content-Disposition: inline; filename=shelf' . '_' . $dateSubfix . '.csv');
		$fp = fopen('php://output', 'w');
		
		switch($this->Template->getSelectedValue())
		{
			case '0': 
				if ($this->HeadersViewFlag->getChecked())
				{
					$csvheader = [
						'ordinamento bibliografico',
						'titolo',
						'autore',
						'pubblicazione',
						'descrizione fisica',
						'collana',
						'ISBN',
						'prezzo',
						'abstract',
						'età',
						'valutazione'
					];
					fputcsv($fp, $csvheader, self::DELIMITER, self::ENCLOSURE);
				}
				
				
				foreach ($mans as $man)
				{
					//2021-03-23 WARN: this is needed to get var updated. Else, never change.
					$man->reloadTurboMarc();
					$tm = $man->getFullTurboMarc(false,false,false);
					fputcsv($fp, $this->getFascicoloRow($tm), self::DELIMITER, self::ENCLOSURE);
				}
				break;
				
			case '1':
				if ($this->HeadersViewFlag->getChecked())
				{
					$csvheader = [
						'ordinamento bibliografico',
						'autore',
						'nota d\'uso',
						'titolo',
						'pubblicazione',
						'abstract'
					];
					
					fputcsv($fp, $csvheader, self::DELIMITER, self::ENCLOSURE);
				}
				
				
				foreach ($mans as $man)
				{
					//2021-03-23 WARN: this is needed to get var updated. Else, never change.
					$man->reloadTurboMarc();
					$tm = $man->getFullTurboMarc(false,false,false);
					fputcsv($fp, $this->getRivistaRow($tm), self::DELIMITER, self::ENCLOSURE);
				}
				break;
		}
		
		
		
		fclose($fp);
		die();
	}
	
}