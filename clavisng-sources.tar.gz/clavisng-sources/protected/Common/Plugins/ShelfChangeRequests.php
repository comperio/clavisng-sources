<?php
/**
 * ShelfChangeItems class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package ShelfPlugins
 */

/**
 * ShelfChangeItems Class
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.7
 * @package ShelfPlugins
 * @since 2.1
 */

class ShelfChangeRequests extends ClavisPlugin
{
	const BULKACTIONS_DELIVERYLIBRARY = 'DELIVERYLIBRARYENUM';
	const BULKACTIONS_EXPIREDATE = 'EXPIREDATEENUM';
	const BULKACTIONS_MAXDISTANCE = 'MAXDISTANCEENUM';
	const BULKACTIONS_REQUESTTYPE = 'REQUESTTYPEENUM';
	const BULKACTIONS_MANIFESTATION = 'MANIFESTATIONENUM';
	const BULKACTIONS_NOITEM = 'NOITEMENUM';

	private $_clavisLibrarian;
	public $_llibraryActive;
	public $_requestTypeActive;

	private function initVars()
	{
		$this->_clavisLibrarian = $this->getUser();
		$this->_llibraryActive = LLibraryPeer::isEnabled();
		$this->_requestTypeActive = ItemRequestPeer::isRequestType();
	}

	public function onInit($param)
	{
		parent::onInit($param);
		$this->initVars();

		/**
		 * Here we populates the controls in the plugin, the first time it gets invoked.
		 */
		if (!$this->getPage()->getIsCallBack())
		{
			$this->BulkActionsList->setDataSource($this->getBulkActions(true));
			$this->BulkActionsList->dataBind();
			
			$this->ActionButton->setEnabled(false);
			$this->hideActionPanels();
			$this->CurrentBulkAction->setValue('');
		}
	}

	private function hideActionPanels()
	{
		$this->DeliveryLibraryPanel->setCssClass('panel_off');
		$this->ExpireDatePanel->setCssClass('panel_off');
		$this->MaxDistancePanel->setCssClass('panel_off');
		$this->RequestTypePanel->setCssClass('panel_off');
		$this->ManifestationPanel->setCssClass('panel_off');
		$this->NoItemPanel->setCssClass('panel_off');
	}
	
	private function getBulkActions($withNull = true)
	{
		if ($withNull)
		{
			$output = array(null => '---');
		}
		else
		{
			$output = array();
		}

		$output += array(	self::BULKACTIONS_DELIVERYLIBRARY => Prado::localize('cambia la biblioteca di destinazione'),
							self::BULKACTIONS_EXPIREDATE => Prado::localize('cambia la data di scadenza'),
							self::BULKACTIONS_MAXDISTANCE => Prado::localize('cambia la massima distanza (circolazione a bacini)'), 
							self::BULKACTIONS_REQUESTTYPE => Prado::localize('cambia il tipo della prenotazione'),
							self::BULKACTIONS_MANIFESTATION => Prado::localize('cambia la notizia collegata'),
							self::BULKACTIONS_NOITEM => Prado::localize('mantieni solo la prenotazione per notizia') );
		
		//if we don't have basins
		if (!$this->_llibraryActive)
			unset ($output[self::BULKACTIONS_MAXDISTANCE]);

		//if we don't have request types
		if (!$this->_requestTypeActive)
			unset ($output[self::BULKACTIONS_REQUESTTYPE]);
		
		return $output;
	}
	
	/**
	 * Here we analyze the ways to modify the variable parts of the plugin panels,
	 * in order to perform the various actions that are required by the operator.
	 */
	public function onChangeBulkActions($sender, $param)
	{
		$index = $sender->getSelectedIndex();
		$value = $sender->getSelectedValue();
		$this->hideActionPanels();
		
		if ($index > 0)	// if choice of an action is not null
		{
			$this->ActionButton->setEnabled(true);
			$this->CurrentBulkAction->setValue($value);
			
			switch ($value)
			{
				case self::BULKACTIONS_DELIVERYLIBRARY:
					$this->DeliveryLibraryPanel->setCssClass('panel_on');
					
					$this->DeliveryLibraries->setDataSource(LibraryPeer::getLibrariesHash(null, null, true, true));
					$this->DeliveryLibraries->dataBind();
					$this->DeliveryLibraries->setSelectedValue($this->getUser()->getActualLibraryId());
					break;
				
				case self::BULKACTIONS_EXPIREDATE:
					$this->ExpireDatePanel->setCssClass('panel_on');
					break;
				
				case self::BULKACTIONS_MAXDISTANCE:
					$this->MaxDistancePanel->setCssClass('panel_on');
					
					$distances = LLibraryPeer::calculateRequestDistances(true, Prado::localize('valore nullo'));
					$this->MaxDistance->setDataSource($distances);
					$this->MaxDistance->dataBind();
					break;
				
				case self::BULKACTIONS_REQUESTTYPE:
					$this->RequestTypePanel->setCssClass('panel_on');
					
					$this->RequestType->setDataSource(ItemRequestPeer::getRequestTypes(true, Prado::localize('valore nullo')));
					$this->RequestType->dataBind();
					break;
				
				case self::BULKACTIONS_MANIFESTATION:
					$this->ManifestationPanel->setCssClass('panel_on');
					break;
				
				case self::BULKACTIONS_NOITEM:
					$this->NoItemPanel->setCssClass('panel_on');
					break;
				
				default:
					$this->ActionButton->setEnabled(false);
					$this->CurrentBulkAction->setValue('');
			}
		}
		else
		{
			$this->ActionButton->setEnabled(false);
		}
	}

	public function onChange($sender, $param)
	{
		ini_set("memory_limit", "700M");
		set_time_limit(0);
		$this->getPage()->cleanMessageQueue();
		
		$shelfItemsIds = array();
		
		foreach ($this->getCheckedItems() as $shelfItem)
		{
			if ($shelfItem->getObjectClass() == ShelfPeer::TYPE_ITEM_REQUEST)
				$shelfItemsIds[] = $shelfItem->getObjectId();
		}

		if (count($shelfItemsIds) == 0)
		{
			$this->getPage()->enqueueMessage(Prado::localize("Nessun elemento selezionato è una prenotazione valida"),
												ClavisMessage::WARNING);

			return;
		}
		
		switch ($this->CurrentBulkAction->getValue())
		{
			case self::BULKACTIONS_DELIVERYLIBRARY:
				$bulkFunction = "doChangeDeliveryLibrary";
				break;

			case self::BULKACTIONS_EXPIREDATE:
				$bulkFunction = "doChangeExpireDate";
				break;

			case self::BULKACTIONS_MAXDISTANCE:
				$bulkFunction = "doChangeMaxDistance";
				break;

			case self::BULKACTIONS_REQUESTTYPE:
				$bulkFunction = "doChangeRequestType";
				break;

			case self::BULKACTIONS_MANIFESTATION:
				$bulkFunction = "doChangeManifestation";
				break;

			case self::BULKACTIONS_NOITEM:
				$bulkFunction = "doChangeNoItem";
				break;

			default:
				$this->getPage()->enqueueMessage(Prado::localize('Nessuna azione'),
													ClavisMessage::INFO);
				
				return;
		}

		$totalToDo = count($shelfItemsIds);
		$countDone = 0;
		$countFailed = 0;

		try
		{
			$bulkParameter = '';
			$returnCode = $this->$bulkFunction(	$shelfItemsIds, 
												$affectedIds, 
												$bulkParameter);

			$countDone = count($affectedIds);
			
			if ($countDone > 0)
			{
				ChangelogPeer::logActionBulk(	$affectedIds,
												'ItemRequest',
												ChangelogPeer::LOG_UPDATE,
												$this->_clavisLibrarian,
												'Plugin sullo scaffale con id=' . $this->getShelfId() . ', cambio dati prenotazione con id=('
													. implode(',', $affectedIds) . ')'
													. ', applicata funzione ' . $bulkFunction . '()'
													. ($bulkParameter != '' ? ' con parametro=' . $bulkParameter : '') );
			}
			else
			{
				$countFailed = $totalToDo;
			}
		}
		catch (PropelException $e)
		{
			$countFailed = $totalToDo - $countDone;
		}

		/**
		 * Messages following + eventual closing
		 */

		if ($countFailed + $countDone == 0)
		{
			$this->getPage()->enqueueMessage(Prado::localize('Nessuna azione eseguita'),
												ClavisMessage::INFO);
		}
		
		if ($countFailed > 0)
		{
			$this->getPage()->enqueueMessage(Prado::localize('N.{count} prenotazioni non modificate',
																array('count' => $countFailed)),
												ClavisMessage::ERROR);
		}
		
		if ($countDone > 0)
		{
			$this->getPage()->enqueueMessage(Prado::localize('N.{count} prenotazioni modificate',
																array('count' => $countDone)),
												ClavisMessage::CONFIRM);

			////$this->getPage()->shelfListRefresh($param);
		}
		
		if (($countDone > 0)
				&& ($countFailed == 0))		// close popup
		{
			$this->getPage()->flushDelayedMessage();
			$this->onClose();
		}
		else	// stay open
		{
			$this->getPage()->flushMessage();
		}
	}
	
	/**
	 * Methods will follow here below for performing the change action, according
	 * to the choice made using the dropdownlist
	 */
	
	private function doChangeDeliveryLibrary(	$requestIds, 
												&$affectedIds = 0,
												&$bulkParameter = "")
	{
		$newLibraryId = $this->DeliveryLibraries->getSelectedValue();
		$bulkParameter = $newLibraryId;
		$time = date('Y-m-d H:i:s');

		try
		{
						
			$requestIdsString = implode(',', $requestIds);
			$userId = $this->getUser()->getId();
			$query = "UPDATE `item_request` SET `delivery_library_id`=$newLibraryId, `date_updated`='$time', `modified_by`=$userId WHERE `request_id` IN ($requestIdsString);";

			$ex = Propel::getConnection()->prepare($query);
			$ex->execute();
			$ex->closeCursor();
			
			$exAffected = Propel::getConnection()->prepare("SELECT `request_id` from `item_request` WHERE `date_updated`='$time' AND `modified_by`=$userId AND `request_id` IN ($requestIdsString)");
			$exAffected->execute();
			$affectedIds = $exAffected->fetchAll(PDO::FETCH_COLUMN, 0);

			$returnCode = true;
		}
		catch (PropelException $e)
		{
			$countDone = 0;
			$returnCode = false;
		}
		
		return $returnCode;
	}
	
	private function doChangeExpireDate(	$requestIds, 
											&$affectedIds = 0,
											&$bulkParameter = "")
	{
		$newExpireDate = null;
		$newExpireDateText = ($this->ExpireDate->getSafeText() != '' 
										? $this->ExpireDate->getText() 
										: null );
		
		$dt = PropelDateTime::newInstance($newExpireDateText, null, 'DateTime');
        
		if ($dt !== null)
			$newExpireDate = $dt ? $dt->format('Y-m-d H:i:s') : null;
		
		$bulkParameter = $newExpireDate;
		$time = date('Y-m-d H:i:s');

		try
		{
			$requestIdsString = implode(',', $requestIds);
			$userId = $this->getUser()->getId();
			$query = "UPDATE `item_request` SET `expire_date`='$newExpireDate', `date_updated`='$time', `modified_by`=$userId WHERE `request_id` IN ($requestIdsString);";

			$ex = Propel::getConnection()->prepare($query);
			$ex->execute();
			$ex->closeCursor();
			
			$exAffected = Propel::getConnection()->prepare("SELECT `request_id` from `item_request` WHERE `date_updated`='$time' AND `modified_by`=$userId AND `request_id` IN ($requestIdsString)");
			$exAffected->execute();
			$affectedIds = $exAffected->fetchAll(PDO::FETCH_COLUMN, 0);

			$returnCode = true;
		}
		catch (PropelException $e)
		{
			$countDone = 0;
			$returnCode = false;
		}
		
		return $returnCode;
	}
	
	private function doChangeMaxDistance(	$requestIds, 
											&$affectedIds = 0,
											&$bulkParameter = "")
	{
		$newMaxDistance = $this->MaxDistance->getSelectedValue();
		if ($newMaxDistance == -1)
		{
			$newMaxDistance = 'NULL';
			$newMaxDistanceMessageLabel = "'" . Prado::localize('nullo') . "'";
		}
		else
		{
			$newMaxDistanceMessageLabel = ItemRequestPeer::getCompleteMaxDistance($newMaxDistance);
		}
		
		$bulkParameter = $newMaxDistanceMessageLabel;
		$time = date('Y-m-d H:i:s');

		try
		{
			$requestIdsString = implode(',', $requestIds);
			$userId = $this->getUser()->getId();
			$query = "UPDATE `item_request` SET `max_distance`=$newMaxDistance, `date_updated`='$time', `modified_by`=$userId WHERE `request_id` IN ($requestIdsString) AND `item_id` IS NULL;";

			$ex = Propel::getConnection()->prepare($query);
			$ex->execute();
			$ex->closeCursor();
			
			$exAffected = Propel::getConnection()->prepare("SELECT `request_id` from `item_request` WHERE `date_updated`='$time' AND `modified_by`=$userId AND `request_id` IN ($requestIdsString)");
			$exAffected->execute();
			$affectedIds = $exAffected->fetchAll(PDO::FETCH_COLUMN, 0);

			$returnCode = true;
		}
		catch (PropelException $e)
		{
			$countDone = 0;
			$returnCode = false;
		}
		
		return $returnCode;
	}
	
	private function doChangeRequestType(	$requestIds, 
											&$affectedIds = 0,
											&$bulkParameter = "")
	{
				$index = $this->RequestType->getSelectedIndex();		

		if ($index == 0)
		{
			$newRequestType = 'NULL';
			$newRequestTypeMessageLabel = "'" . Prado::localize('nullo') . "'";
		}
		else
		{
			$newRequestType = "'" . $this->RequestType->getSelectedValue() . "'";
			$newRequestTypeMessageLabel = ItemRequestPeer::getRequestTypeString($newRequestType);
		}

		$bulkParameter = $newRequestTypeMessageLabel;
		$time = date('Y-m-d H:i:s');

		try
		{
			$requestIdsString = implode(',', $requestIds);
			$userId = $this->getUser()->getId();
			$query = "UPDATE `item_request` SET `request_type`=$newRequestType, `date_updated`='$time', `modified_by`=$userId WHERE `request_id` IN ($requestIdsString);";

			$ex = Propel::getConnection()->prepare($query);
			$ex->execute();
			$ex->closeCursor();
			
			$exAffected = Propel::getConnection()->prepare("SELECT `request_id` from `item_request` WHERE `date_updated`='$time' AND `modified_by`=$userId AND `request_id` IN ($requestIdsString)");
			$exAffected->execute();
			$affectedIds = $exAffected->fetchAll(PDO::FETCH_COLUMN, 0);

			$returnCode = true;
		}
		catch (PropelException $e)
		{
			$countDone = 0;
			$returnCode = false;
		}
		
		return $returnCode;
	}
	
	private function doChangeManifestation(	$requestIds, 
											&$affectedIds = 0,
											&$bulkParameter = "")			// serve come esempio, forse da incorporare da un'altra parte
	{
		$manifestation = null;
		$manifestationId = intval($this->RecordChooser->getManifestationId());

		if ($manifestationId > 0)
			$manifestation = ManifestationQuery::create()->findPK($manifestationId);
		
		if (!($manifestation instanceof Manifestation))
		{
			$this->writeMessage(Prado::localize("Non è stata scelta alcuna notizia valida"),
									ClavisMessage::ERROR);
		
			$returnCode = false;
		}
		else
		{
			$bulkParameter = $manifestationId;
			$time = date('Y-m-d H:i:s');

			try
			{
				$requestIdsString = implode(',', $requestIds);
				$userId = $this->getUser()->getId();
				$query = "UPDATE `item_request` SET `manifestation_id`=$manifestationId, `date_updated`='$time', `modified_by`=$userId WHERE `request_id` IN ($requestIdsString);";

				$ex = Propel::getConnection()->prepare($query);
				$ex->execute();
				$ex->closeCursor();

				$exAffected = Propel::getConnection()->prepare("SELECT `request_id` from `item_request` WHERE `date_updated`='$time' AND `modified_by`=$userId AND `request_id` IN ($requestIdsString)");
				$exAffected->execute();
				$affectedIds = $exAffected->fetchAll(PDO::FETCH_COLUMN, 0);

				$returnCode = true;
			}
			catch (PropelException $e)
			{
				$countDone = 0;
				$returnCode = false;
			}
		}
		
		return $returnCode;
	}
	
	private function doChangeNoItem(	$requestIds, 
										&$affectedIds = 0,
										&$bulkParameter = "")
	{
		$time = date('Y-m-d H:i:s');

		try
		{
			$requestIdsString = implode(',', $requestIds);
			$userId = $this->getUser()->getId();
			$query = "UPDATE `item_request` SET `item_id`=NULL, `date_updated`='$time', `modified_by`=$userId WHERE `request_id` IN ($requestIdsString) AND `item_id` IS NOT NULL;";

			$ex = Propel::getConnection()->prepare($query);
			$ex->execute();
			$ex->closeCursor();

			$exAffected = Propel::getConnection()->prepare("SELECT `request_id` from `item_request` WHERE `date_updated`='$time' AND `modified_by`=$userId AND `request_id` IN ($requestIdsString)");
			$exAffected->execute();
			$affectedIds = $exAffected->fetchAll(PDO::FETCH_COLUMN, 0);

			$returnCode = true;
		}
		catch (PropelException $e)
		{
			$countDone = 0;
			$returnCode = false;
		}
		
		return $returnCode;
	}

	public function IsPopup()
	{
		return true;
	}
	
}