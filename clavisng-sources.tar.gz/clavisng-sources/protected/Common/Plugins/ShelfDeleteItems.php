<?php
/**
 * ShelfDeleteItems class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.8.7
 * @package ShelfPlugins
 */

/**
 * ShelfDeleteItems Class
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.8.7
 * @package ShelfPlugins
 * @since 2.8.7
 */

class ShelfDeleteItems extends ClavisPlugin
{
	private $_clavisLibrarian;

	private function initVars()
	{
		$this->_clavisLibrarian = $this->getUser();
	}

	public function onInit($param)
	{
		parent::onInit($param);
		
		$this->initVars();
	}

	public function onAction($sender, $param)
	{
		$captchaSuccess = $this->CaptchaSuccessFlag->getValue();
		
		if ($captchaSuccess != 1)
		{
			$this->writeMessage(Prado::localize('Errore di autenticazione col captcha'),
									ClavisMessage::ERROR);
			
			return false;
		}
		
		ini_set("memory_limit", "700M");
		set_time_limit(0);
		
		$this->getPage()->cleanMessageQueue();
		
		$shelfItems = $this->getCheckedItems();

		$countDone = 0;
		$countFailed = 0;
		$countInLoan = 0;
		$countNotAuthorized = 0;

		if (count($shelfItems) > 0)
		{
			foreach ($shelfItems as $shelfItem)
			{
				if ($shelfItem instanceof ShelfItem)
				{
					if ($shelfItem->getObjectClass() == ShelfPeer::TYPE_ITEM)
					{
						$item = null;
						$itemId = intval($shelfItem->getObjectId());
						
						if ($itemId > 0)
							$item = ItemQuery::create()->findPk($itemId);
						
						if ($item instanceof Item)
						{
							if (!$this->_clavisLibrarian->getEditPermission($item))
							{
								$countNotAuthorized++;
							}
							elseif (!is_null($item->getPatronId())
										|| !is_null($item->getExternalLibraryId()))
							{
								// item is in loan
								$countInLoan++;
							}
							else
							{
								$exitValue = $this->doAction($item);

								if ($exitValue)
								{
									$countDone++;
									$shelfItem->delete();
								}
								else
								{
									$countFailed++;
								}

								ChangelogPeer::logAction(	'item',
															ChangelogPeer::LOG_UPDATE,
															$this->_clavisLibrarian,
															'Plugin su scaffale con id= ' . $this->getShelfId() . ': esemplare con id:'
																. $itemId . ' cancellato',
															$itemId);
							}
						}
						else
						{
							$this->getPage()->enqueueMessage(Prado::localize("Errore interno di reperimento dell'esemplare con id={id}",
																					array('id' => $itemId)),
																	ClavisMessage::ERROR);
						}
					}
				}
			}
		}

		$this->getPage()->enqueueMessage(Prado::localize("{count} esemplari cancellati, con tutti gli oggetti e informazioni ad essi collegati",
																	array('count' => $countDone)),
												ClavisMessage::CONFIRM);

		if ($countFailed > 0)
		{
			$this->getPage()->enqueueMessage(Prado::localize("{count} esemplari non cancellati a causa di errori",
																		array('count' => $countFailed)),
													ClavisMessage::ERROR);
		}	
			
		if ($countNotAuthorized > 0)
		{
			$this->getPage()->enqueueMessage(Prado::localize("{count} esemplari non cancellati per mancanza di permessi",
																	array('count' => $countNotAuthorized)),
												ClavisMessage::ERROR);
		}

		if ($countInLoan > 0)
		{
			$this->getPage()->enqueueMessage(Prado::localize("{count} esemplari non cancellati perchè in stato di prestito",
																	array('count' => $countInLoan)),
												ClavisMessage::WARNING);
		}
		
		$this->getPage()->flushDelayedMessage();
		
		$this->onClose();
	}

	private function doAction(&$item)
	{
		/* @var $item Item */
		$exitValue = false;
		
		try
		{
			$itemId = $item->getItemId();
			
			ItemActionQuery::create()
							->filterByItemId($itemId)
							->delete();
			
			ChangelogQuery::create()
						->filterByObjectClass('Item')
						->filterByObjectId($itemId)
						->delete();
			
			LoanQuery::create()
						->filterByItemId($itemId)
						->filterByLoanStatus(ItemPeer::getLoanStatusClosed())
						->update(array('ItemId' => 0));
			
			ItemRequestQuery::create()
							->filterByItemId($itemId)
							->update(array('ItemId' => null));
			
			ShelfItemQuery::create()
							->filterByObjectClass('item')
							->filterByObjectId($itemId)
							->delete();
			
			ItemNoteQuery::create()
							->filterByItemId($itemId)
							->delete();
			
			LAuthorityItemQuery::create()
							->filterByItemId($itemId)
							->delete();
			
			AttachmentQuery::create()
						->filterByObjectType('Item')
						->filterByObjectId($itemId)
						->delete();
			
			$item->delete();
			
			$exitValue = true;
		}
		catch (PropelException $exception)
		{
			//$errorMessage = $exception->getCause()->getMessage();
			//var_dump($errorMessage);die;
		}
									
		return $exitValue;
	}

	public function IsPopup()
	{
		return true;
	}
	
}