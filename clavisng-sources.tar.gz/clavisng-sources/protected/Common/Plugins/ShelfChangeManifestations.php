<?php
/**
 * ShelfChangeManifestations class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package ShelfPlugins
 */

/**
 * ShelfChangeManifestations Class
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.7
 * @package ShelfPlugins
 * @since 2.1
 */

class ShelfChangeManifestations extends ClavisPlugin
{
	const DONTUPDATE = '--%%impossibIlescriverEunastringacosiACaso%%--';

	private $_clavisLibrarian;

	private function initVars()
	{
		$this->_clavisLibrarian = $this->getUser();
	}

	public function onInit($param)
	{
		parent::onInit($param);
		
		$this->initVars();

		if ( !$this->getPage()->getIsCallBack())
		{
			$this->ManStatus->populate();
			$this->BibLevel->populate();
			$this->BibObjFirst->populate();
			$this->AgeControl->populate();
			$this->Country->populate();
			
			$this->ManLevel->setDataSource(LookupValueQuery::create()
									->filterByValueLanguage($this->getApplication()->getGlobalization()->getCulture())
									->filterByValueClass('CATLEVEL')
									->filterByValueKey($this->getUser()->getLibrarian()->getCatLevel(),Criteria::LESS_EQUAL)
									->find());
			
			$this->ManLevel->dataBind();
		}
	}

	public function setIsItemValid($valid = false)
	{
		$this->getApplication()->getSession()->add('IsItemValid', $valid, false);
	}

	public function getIsItemValid()
	{
		return $this->getApplication()->getSession()->itemAt('IsItemValid', false);
	}

	public function onChangeObjFirst($sender, $param)
	{
		$firstValue = $sender->getSelectedValue();
		if ($firstValue) 
		{
			$this->BibObj->setCssClass('panel_on_inline');
			$this->BibObj->setDBClass('OGGBIBL_'.$firstValue);
			$this->BibObj->populate();
			$this->BibObj->setSelectedIndex(0);
		}
		else 
		{
			$this->BibObj->setCssClass('panel_off');
		}
	}

	public function onRepF101DataBound($sender, $param)
	{
		$item = $param->Item;
    	$itemIndex = $item->ItemIndex;

    	$langCode = $item->DataItem['LangCode'];
    	$item->F101Value->populate();
    	$item->F101Value->setSelectedValue($langCode);
	}

	public function onAddLanguage($sender, $param)
	{
		$newDatasource = array();
		foreach ($this->RepF101->Items as $item)
		{
			$tag   = $item->F101Tag->getSelectedValue() ;
			$value = $item->F101Value->getSelectedValue() ;
			$newDatasource[]=array('LangCode' => $value, 'LangTag' => $tag);
		}
		
		$newDatasource[]=array('LangCode' => 'ita', 'LangTag' => 'a');
		$this->RepF101->setDataSource($newDatasource);
		$this->RepF101->dataBind();
	}
	
	public function onDeleteLanguage($sender, $param) 
	{
		$index = $param->getCommandParameter();
		$newDatasource = array();
		foreach ($this->RepF101->Items as $item)
		{
			if ($item->ItemIndex == $index)
				continue;
		
			$tag   = $item->F101Tag->getSelectedValue();
			$value = $item->F101Value->getSelectedValue();
			$newDatasource[]=array('LangCode' => $value, 'LangTag' => $tag);
		}
		
		$this->RepF101->setDataSource($newDatasource);
		$this->RepF101->dataBind();
	}
	
	public function onAssign($sender, $param)
	{
		ini_set("memory_limit", "700M");
		set_time_limit(0);

		$shelfItems = $this->getCheckedItems();

		/// begin reading fields
		if ($this->ManStatusCheck->getChecked())
		{
			$manStatus = ($this->ManStatus->getSelectedValue() == ManifestationPeer::STATUS_IMPORT)
								? ManifestationPeer::STATUS_INCOMPLETE
								: $this->ManStatus->getSelectedValue();
		}
		else
		{
			$manStatus = self::DONTUPDATE;
		}

		if ($this->ManLevelCheck->getChecked())
		{
			$manLevel = $this->ManLevel->getSelectedValue();
		}
		else
		{
			$manLevel = self::DONTUPDATE;
		}
		
		if ($this->BibLevelCheck->getChecked())
		{
			$bibLevel = $this->BibLevel->getSelectedValue();
		}
		else
		{
			$bibLevel = self::DONTUPDATE;
		}
		
		if ($this->BibObjCheck->getChecked())
		{
			$bibObjFirst = $this->BibObjFirst->getSelectedValue();
			$bibObj = $this->BibObj->getSelectedValue();
		}
		else
		{
			$bibObjFirst = self::DONTUPDATE;
			$bibObj = self::DONTUPDATE;
		}
		
		if ($this->DateCheck->getChecked())
		{
			$date[0] = $this->DateType->getValue();
			$date[1] = trim($this->F100aDate1->getSafeText());
			$date[2] = trim($this->F100aDate2->getSafeText());
		}
		else
		{
			$date = self::DONTUPDATE;
		}
		
		if ($this->TranslateLanguageCheck->getChecked())
		{
			$tradLanguage = $this->F101Ind1->getSelectedValue();
		}
		else
		{
			$tradLanguage = self::DONTUPDATE;
		}
		
		if ($this->LanguagesCheck->getChecked())
		{
			$languages = array();
			foreach ($this->RepF101->Items as $item) 
			{
				$tag = $item->F101Tag->getSelectedValue();
				$value = $item->F101Value->getSelectedValue();
				$languages[$tag] = $value;
			}
		}
		else
		{
			$languages = self::DONTUPDATE;
		}		

		if ($this->CountryCheck->getChecked())
		{
			$country = $this->Country->getSelectedValue();
		}
		else
		{
			$country = self::DONTUPDATE;
		}
		
		$targets = [];
		
		if ($this->Targets0Check->getChecked())
			$targets[0] = $this->F100a17->getValue();

		if ($this->Targets1Check->getChecked())
			$targets[1] = $this->F100a18->getValue();

		if ($this->Targets2Check->getChecked())
			$targets[2] = $this->F100a19->getValue();

		if (count($targets) == 0)
			$targets = self::DONTUPDATE;
		
		if ($this->PublicationCheck->getChecked())
		{
			$publication = $this->F100a20->getValue();
		}
		else
		{
			$publication = self::DONTUPDATE;
		}
		
		if ($this->AgeControlCheck->getChecked())
		{
			$ageControl = $this->AgeControl->getSelectedValue();
		}
		else
		{
			$ageControl = self::DONTUPDATE;
		}		
		
		if ($this->LoanableSinceCheck->getChecked())
		{
			$loanableSince = $this->LoanableSince->getTimeStamp();
		}
		else
		{
			$loanableSince = self::DONTUPDATE;
		}
		/// end of fields reading

		$countDone = 0;
		$countFailed = 0;
		$countNotAuthorized = 0;

		/// begin of cycle upon the shelf objects
		if (count($shelfItems) > 0)
		{
			foreach ($shelfItems as $shelfItem)
			{
				if (($shelfItem instanceof ShelfItem)
						&& ($shelfItem->getObjectClass() == ShelfPeer::TYPE_MANIFESTATION))	// only manifestations
				{
					$manifestation = null;
					$manifestationId = $shelfItem->getObjectId();
					if ($manifestationId > 0)
						$manifestation = ManifestationQuery::create()
											->findPk($manifestationId);
					
					if ($manifestation instanceof Manifestation)
					{
						if (!$this->_clavisLibrarian->getEditPermission($manifestation))
							$countNotAuthorized++;
						else
						{
							$returnCode = $this->updateData($manifestation, 
															$manStatus,
									
															$manLevel,
															$bibLevel,
															$bibObjFirst,
									
															$bibObj,
															$date,
															$tradLanguage,
									
															$languages,
															$country,
															$targets,
									
															$publication,
															$ageControl,
															$loanableSince );
								
							if ($returnCode === self::DONTUPDATE)
							{
								// nothing done
							}
							elseif ($returnCode === true)
							{
								$countDone++;
								ChangelogPeer::logAction(	$manifestation,
															ChangelogPeer::LOG_UPDATE,
															$this->_clavisLibrarian,
															"Cambio dati da plugin alla notizia con id=" . $manifestation->getManifestationId());
							}
							elseif ($returnCode === false)
								$countFailed++;
							else
								$countFailed++;
						}
					}
					else
					{
						$this->getPage()->writeMessage(Prado::localize("Errore sulla notizia"),
														ClavisMessage::ERROR);
						return false;
					}
				}
				
				$shelfItem->clearAllReferences(true);	
				unset ($shelfItem);
			}
		}
		/// end of cycle upon the shelf objects

		$errorCode = ClavisMessage::ERROR;
		if (($countDone == 0)
				&& ($countFailed == 0)
				&& ($countNotAuthorized == 0))
			$errorCode = ClavisMessage::INFO;
		else
		{
			if (($countFailed > 0)
					|| ($countNotAuthorized > 0))
				$errorCode = ClavisMessage::WARNING;
			else
				$errorCode = ClavisMessage::CONFIRM;
		}

		$messageText = Prado::localize('Nessuna azione eseguita');

		if ($countDone > 0)
			$messageText = (1 == $countDone)
								? Prado::localize('1 notizia modificata')
								: Prado::localize('{count} notizie modificate',
													array('count'=>$countDone));

		if ($countNotAuthorized > 0)
			$messageText .= ($messageText != '' ? '&nbsp;&nbsp;&nbsp;&nbsp;<br /><br />' : '') .
				(1 == $countNotAuthorized)
					? Prado::localize('1 notizia NON modificata per mancanza di autorizzazione')
					: Prado::localize('{count} notizie NON modificate per mancanza di autorizzazione',
										array('count'=>$countNotAuthorized));

		if ($countFailed > 0)
			$messageText .= ($messageText != '' ? '&nbsp;&nbsp;&nbsp;&nbsp;<br /><br />' : '') .
				(1 == $countFailed)
					? Prado::localize('1 notizia NON modificata per errore sconosciuto')
					: Prado::localize('{count} notizie NON modificate per errore sconosciuto',
										array('count'=>$countFailed));

		if ($countDone > 0)
			$this->getPage()->shelfListRefresh($param);

		$this->getPage()->writeDelayedMessage($messageText, $errorCode);
		$this->onClose();
	}


	public function IsPopup()
	{
		return true;
	}

	public function updateData($manifestation, 
								$manStatus,

								$manLevel,
								$bibLevel,
								$bibObjFirst,

								$bibObj,
								$date,
								$tradLanguage,

								$languages,
								$country,
								$targets,

								$publication,
								$ageControl,
								$loanableSince )
	{
		try
		{
			//$turboMarc = null;
			$editionLanguage = '';
			$actionDoneFlag = false;

			if ($manStatus != self::DONTUPDATE)
			{
				$manifestation->setManifestationStatus($manStatus);
				$actionDoneFlag = true;
			}

			if ( $manLevel != self::DONTUPDATE)
			{
				$manifestation->setCatalogationLevel($manLevel);
				$actionDoneFlag = true;
			}
			
			if ( $bibLevel != self::DONTUPDATE)
			{
				$manifestation->setBibLevel($bibLevel);
				$actionDoneFlag = true;
			}			
			
			if ( $bibObjFirst != self::DONTUPDATE)
			{
				$manifestation->setBibTypeFirst($bibObjFirst);
				$actionDoneFlag = true;
			}

			if ( $bibObj != self::DONTUPDATE)
			{
				$manifestation->setBibType($bibObj);
				$actionDoneFlag = true;
			}
			
			if ( $date != self::DONTUPDATE)
			{
				$turboMarc = $manifestation->getTurboMarc();

				$f100 = (array_key_exists('d100', $turboMarc))
								? $turboMarc->d100
								: $turboMarc->addField('100');
				
				$f100->setCDF('a', 8, $date[0]);
				$f100->setCDF('a', 9, $date[1]);
				$f100->setCDF('a', 13, $date[2]);
				
				$manifestation->setUnimarc($turboMarc->asXML());
				$actionDoneFlag = true;
			}

			if ( $tradLanguage != self::DONTUPDATE)
			{
				$turboMarc = $manifestation->getTurboMarc();

				$f101 = (array_key_exists('d101', $turboMarc))
								? $turboMarc->d101
								: $turboMarc->addField('101');
				
				$f101['i1'] = $tradLanguage;
				
				$manifestation->setUnimarc($turboMarc->asXML());
				$actionDoneFlag = true;
			}
			
			if ( $languages != self::DONTUPDATE)
			{
				$turboMarc = $manifestation->getTurboMarc();

				$f101 = (array_key_exists('d101', $turboMarc))
								? $turboMarc->d101 : $turboMarc->addField('101');
				
				foreach ($languages as $tag => $value)
				{
					if ($editionLanguage == '')
						$editionLanguage = $value;
		
					$f101->addSubField($tag, $value);
				}
				
				$manifestation->setUnimarc($turboMarc->asXML());
				$actionDoneFlag = true;
			}
			
			if ( $country != self::DONTUPDATE)
			{
				$turboMarc = $manifestation->getTurboMarc();

				$f102 = (array_key_exists('d102', $turboMarc))
								? $turboMarc->d102
								: $turboMarc->addField('102');
				
				$f102->addSubField('a', substr($country, 0, 2));
				
				$manifestation->setUnimarc($turboMarc->asXML());
				$actionDoneFlag = true;
			}
			
			if ($targets != self::DONTUPDATE)
			{
				$turboMarc = $manifestation->getTurboMarc();

				$f100 = (array_key_exists('d100', $turboMarc))
								? $turboMarc->d100
								: $turboMarc->addField('100');
				
				if (isset($targets[0]))
					$f100->setCDF('a', 17, $targets[0]);
				
				if (isset($targets[1]))
					$f100->setCDF('a', 18, $targets[1]);
				
				if (isset($targets[2]))
					$f100->setCDF('a', 19, $targets[2]);
				
				$manifestation->setUnimarc($turboMarc->asXML());
				$actionDoneFlag = true;
			}
			
			if ( $publication != self::DONTUPDATE)
			{
				$turboMarc = $manifestation->getTurboMarc();

				$f100 = (array_key_exists('d100', $turboMarc))
								? $turboMarc->d100
								: $turboMarc->addField('100');
				
				$f100->setCDF('a', 20, $publication);
				
				$manifestation->setUnimarc($turboMarc->asXML());
				$actionDoneFlag = true;
			}
			
			if ( $ageControl != self::DONTUPDATE)
			{
				$manifestation->setRating($ageControl);
				$actionDoneFlag = true;
			}			
			
			if ( $loanableSince != self::DONTUPDATE)
			{
				$manifestation->setLoanableSince($loanableSince);
				$actionDoneFlag = true;
			}			
			
			if ($editionLanguage != '')
				$manifestation->setEditionLanguage($editionLanguage);
			
			if ($actionDoneFlag)
			{
				$manifestation->save();
				return true;
			}

			return self::DONTUPDATE;
		}
		catch (PropelException $exception)
		{
			$errorMessage = $exception->getCause()->getMessage();
			Prado::log('Plugin ShelfChangeManifestations, errore: ' . $errorMessage);

			return false;
		}
	}

}