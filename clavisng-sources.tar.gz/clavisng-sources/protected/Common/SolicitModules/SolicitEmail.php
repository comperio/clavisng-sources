<?php

/**
 * SolicitEmail
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2010 Comperio srl
 */
class SolicitEmail extends BaseSolicit {

	protected $channel = NotificationPeer::CHANNEL_EMAIL;
	protected $userLibrarian;
	/* @var $actualLibrary Library */
	protected $actualLibrary;

	public function onLoad($param) {
		parent::onLoad($param);
		$this->userLibrarian = $this->getUser();
		$this->actualLibrary = $this->userLibrarian->getActualLibrary();
	}
	
	public function activate() {
		switch ($this->getSolicitMode()) {
			case 'solicit':
				$tpl_class = array('SOLICIT_MAIL','SOLICIT_MAIL_EXTRA');
				break;
			case 'readyforloan':
				$tpl_class = 'NOTIFYREADY_MAIL';
				break;
			case 'expiring':
				$tpl_class = 'EXPIRINGLOAN_MAIL';
				break;
		}
		
		$ds = array();
		$templates_global = DocumentTemplatePeer::getTemplates(
			$tpl_class,$this->getApplication()->getGlobalization()->getCulture());
		foreach ($templates_global as $tpl)
			$ds[] = array('TemplateId' => $tpl->getDocumentTemplateId(),
				'TemplateTitle' => $tpl->getTemplateTitle());
		/** @var $templates_global DocumentTemplate */
		$templates_mine = DocumentTemplatePeer::getTemplates(
			$tpl_class,$this->getApplication()->getGlobalization()->getCulture(),
			$this->userLibrarian->getActualLibraryId(),false);
		foreach ($templates_mine as $tpl)
			$ds[] = array('TemplateId' => $tpl->getDocumentTemplateId(),
				'TemplateTitle' => '[*] '.$tpl->getTemplateTitle());
		if (!$ds) {
			$this->NoTemplatesWarning->setVisible(true);
			$this->PreviewPanel->setVisible(false);
			return;
		}
		$this->TplEmail->setDatasource($ds);
		$this->TplEmail->setEnabled(count($ds)>0);
		$this->TplEmail->dataBind();
		$this->TplEmail->setSelectedIndex(0);
		if ($this->EmailSender->getSelectedIndex() == -1)
			$this->EmailSender->setSelectedValue(ClavisParamQuery::getParam('CLAVISPARAM','MailSentFrom'));
		$this->ManualEmail->setVisible(count($this->getDestinations())==1);
		// hack for not doing preview on checkbox change callback
		if ($this->getPage()->getCallbackEventTarget() instanceof TControl &&
				!in_array($this->getPage()->getCallbackEventTarget()->getID(),array('NotifyAllLoans')))
			$this->doPreview();
		$this->_active = true;
	}

	public function updatePreview($sender,$param)
	{
		$this->doPreview();
	}

	protected function doPreview() {
		$tpl = DocumentTemplatePeer::retrieveByPK($this->TplEmail->getSelectedValue());
		if ($tpl instanceof DocumentTemplate) {
			$librarian = $this->userLibrarian->getLibrarian();
			$d = $this->getDestinations();
			if (count($d)>0) {
				$arr_alias = NotificationEmail::getAliasArray($librarian,
					$this->actualLibrary, $this->getSolicitMode(), $this->NotifyAllLoans->getChecked(),
					$d[0], $this->getLoanIds());
				$body = DocumentTemplatePeer::templateTransform($tpl->getTemplateBody(), $arr_alias);
				$sender = NotificationEmail::getEmailSender($this->EmailSender->getSelectedValue(),
					$librarian, $this->actualLibrary, $d[0]);
			} else {
				$body = $tpl->getTemplateBody();
				$sender = NotificationEmail::getEmailSender($this->EmailSender->getSelectedValue(),
					$librarian, $this->actualLibrary, $d[0]);
			}
			$this->EmailSenderPreview->setText("\"{$sender['name']}\" <{$sender['email']}>");
			$this->EmailSubjectPreview->setText($tpl->getTemplateSubject());
			$this->EmailPreview->setText($body);
		} else {

		}
	}

	public function notify($notifClass = 'H')
	{
		$tpl = DocumentTemplatePeer::retrieveByPK($this->TplEmail->getSelectedValue());
		if (! $tpl instanceof DocumentTemplate)
			throw new Exception('No template found');

		$notificationData = array(
			'sender_library_id'	=> $this->actualLibrary->getLibraryId(),
			'description'	=> $this->getDescription().Prado::localize(' [via email]'),
			'notes'			=> array(),
            'notification_class' => $notifClass,
            'template_id' => $tpl->getDocumentTemplateId()
		);
		
		$status = array(
			'sent'		=> array(),
			'failed'	=> array(),
		);

		$librarian = $this->userLibrarian->getLibrarian();
		foreach ($this->getDestinations() as $d)
		{
			$sender = NotificationEmail::getEmailSender($this->EmailSender->getSelectedValue(),
				$librarian, $this->actualLibrary, $d);
			$arr_alias = NotificationEmail::getAliasArray($librarian, $this->actualLibrary, $this->getSolicitMode(),
				$this->NotifyAllLoans->getChecked(), $d, $this->getLoanIds());
			$recipient = $d->getEmail();
			if (!is_array($recipient))
				$recipient = array($recipient);
			
			if ($d instanceof Patron) {
				$notificationData['receiver_class'] = 'Patron';
				$notificationData['receiver_id'] = $d->getPatronId();
			} else if ($d instanceof Library) {
				$notificationData['receiver_class'] = 'Library';
				$notificationData['receiver_id'] = $d->getLibraryId();
			}
				
			$mailData = array(
				'to'	=> $recipient,
				'from'	=> $sender,
				'cc'	=> '',
				'bcc'	=> '',
				'body'	=> '',
				'subject'	=> $tpl->getTemplateSubject()
			);
			try
			{
				$mailMode = ($this->ManualEmail->getChecked()) ?
					NotificationManager::EMAIL_MANUAL:
					NotificationManager::EMAIL_AUTO;
				
				$ret = $this->_notificationman->DoEmailReport(
					$tpl->getTemplateBody(),
					$arr_alias,
					$mailData,
					$mailMode,
					$notificationData);
				
				if ($ret)
					$status['sent'][] = array(
						'destination'	=> $d,
						'loan_ids'		=> $arr_alias['LOAN_IDS']);
				else
					$status['failed'][] = array(
					'destination'	=> $d,
					'errormsg'		=> Prado::localize('Errore nella spedizione della email'));
			}
			catch (Exception $e)
			{
				if ($e->getCode() == NotificationManager::ERR_ADDRESSEMPTY)
					$m = Prado::localize('Errore: nessun indirizzo mail valido');
				else
					$m = Prado::localize('Errore: ').$e->getMessage();
				$status['failed'][] = array(
					'destination'	=> $d,
					'errormsg'		=> $m);
			}
		}
		return $status;
	}
}