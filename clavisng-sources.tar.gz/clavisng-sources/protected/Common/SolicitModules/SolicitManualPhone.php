<?php

/**
 * SolicitManualPhone
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2010 Comperio srl
 */
class SolicitManualPhone extends BaseSolicit {

	protected $channel = NotificationPeer::CHANNEL_PHONE;

	public function activate() {
		$notifyList = array();
		foreach ($this->getDestinations() as $d)
		{
			if (!$d instanceof Patron && !$d instanceof Library)
				throw new Exception('Wrong destination: neither Patron nor Library');

			if ($d instanceof Patron) {
				$contactcrit = new Criteria();
				$contactcrit->add(ContactPeer::PATRON_ID,$d->getPatronId());
				$contactcrit->add(ContactPeer::CONTACT_TYPE,ContactPeer::TYPE_PHONE);
				$contactcrit->addDescendingOrderByColumn(ContactPeer::CONTACT_PREF);
				$contactcrit->clearSelectColumns()->addSelectColumn(ContactPeer::CONTACT_VALUE);
				$stmt = ContactPeer::doSelectStmt($contactcrit);
				$contacts = $stmt->fetchAll(PDO::FETCH_COLUMN);
				$contacts = (count($contacts) < 1) ?
					Prado::localize('<strong><em style="color:red;">Nessun contatto telefonico!</em></strong>') :
					implode(', ',$contacts);
				$notifyList[] = array(
					'name'		=> $d->getCompleteName(),
					'contact'	=> $contacts
				);
			} else if ($d instanceof Library) {
				$contact = trim($d->getPhone());
				$notifyList[] = array(
					'name'		=> '[L] '.$d->getLabel(),
					'contact'	=> (!$contact) ?
						Prado::localize('<strong><em style="color:red;">Nessun contatto telefonico!</em></strong>') :
						$contact
				);
			}
		}
		$this->PatronContactsGrid->setDataSource($notifyList);
		$this->PatronContactsGrid->dataBind();
		$this->_active = true;
    }

	public function deactivate() {
		$this->_active = false;
	}

	public function notify()
	{
		$this->setDescription($this->getDescription().' [MANUALE]');
		$this->addNotification();
		$status = array('failed' => array(),'sent'=>array());
		foreach ($this->getDestinations() as $d)
			$status['sent'][] = array(
				'destination'	=> $d,
				'loan_ids'		=> $this->getLoanIds());
		return $status;
	}
}