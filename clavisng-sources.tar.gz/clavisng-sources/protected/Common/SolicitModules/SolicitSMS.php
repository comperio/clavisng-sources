<?php

/**
 * SolicitSMS
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2010 Comperio srl
 */
class SolicitSMS extends BaseSolicit {

	protected $channel = NotificationPeer::CHANNEL_SMS;
	public $smscredit = 0;
	protected $userLibrarian;
	protected $actualLibrary;

	public function onLoad($param) {
		parent::onLoad($param);
		$this->userLibrarian = $this->getUser();
		$this->actualLibrary = $this->userLibrarian->getActualLibrary();
		$this->smscredit = $this->actualLibrary->getActualSMS();
    }

	public function activate() {
	    if ($this->smscredit > 0) {
            switch ($this->getSolicitMode()) {
                case 'solicit':
                    $tpl_class = 'SOLICIT_SMS';
                    break;
                case 'readyforloan':
                    $tpl_class = 'NOTIFYREADY_SMS';
                    break;
				case 'expiring':
					$tpl_class = 'EXPIRINGLOAN_SMS';
					break;
            }

            $ds = array();
            $templates_global = DocumentTemplatePeer::getTemplates(	$tpl_class,
																	$this->getApplication()->getGlobalization()->getCulture());
            
			foreach ($templates_global as $tpl)
                $ds[] = array(	'TemplateId' => $tpl->getDocumentTemplateId(),
								'TemplateTitle' => $tpl->getTemplateTitle() );
			
            /** @var $templates_global DocumentTemplate */
            $templates_mine = DocumentTemplatePeer::getTemplates(	$tpl_class,
																	$this->getApplication()->getGlobalization()->getCulture(),
																	$this->userLibrarian->getActualLibraryId(),
																	false);
			
            foreach ($templates_mine as $tpl)
                $ds[] = array(	'TemplateId' => $tpl->getDocumentTemplateId(),
								'TemplateTitle' => '[*] '.$tpl->getTemplateTitle());
			
			if (!$ds) {
				$this->NoTemplatesWarning->setVisible(true);
				$this->PreviewPanel->setVisible(false);
				return;
			}
			
            $this->TplSMS->setDatasource($ds);
            $this->TplSMS->setEnabled(count($ds)>0);
            $this->TplSMS->dataBind();
            $this->TplSMS->setSelectedIndex(0);
            if ($this->SMSSender->getSelectedIndex() == -1)
                $this->SMSSender->setSelectedValue(ClavisParamQuery::getParam('CLAVISPARAM','SMSSentFrom'));
            $this->doPreview();
            $this->_active = true;
        } else {
            $this->_active = false;
        }
	}

	public function updatePreview($sender,$param)
	{
		$this->doPreview();
	}

	protected function doPreview() {
		$tpl = DocumentTemplatePeer::retrieveByPK($this->TplSMS->getSelectedValue());
		$d = $this->getDestinations();
		if (count($d)>0) {
			$arr_alias = NotificationSMS::getAliasArray($this->getUser()->getLibrarian(), $this->actualLibrary,
				$this->getSolicitMode(), $d[0], $this->getLoanIds());
			$body = DocumentTemplatePeer::templateTransform($tpl->getTemplateBody(), $arr_alias);
			$sender = NotificationSMS::getSMSSender($this->SMSSender->getSelectedValue(), $this->actualLibrary);
		} else {
			$body = $tpl->getTemplateBody();
			$sender = NotificationSMS::getSMSSender($this->SMSSender->getSelectedValue(), $this->actualLibrary);
		}
		$this->SenderPreview->setText($sender);
		$this->SMSPreview->setText($body);
	}

	public function notify($notifClass = 'H')
	{
		$tpl = DocumentTemplatePeer::retrieveByPK($this->TplSMS->getSelectedValue());
		if ($tpl instanceof DocumentTemplate)
			$tpl = $tpl->getTemplateBody();

		$notificationData = array(
			'sender_library_id'	=> $this->actualLibrary->getLibraryId(),
			'description'	=> $this->getDescription().Prado::localize(' [via SMS]'),
            'notification_class' => $notifClass,
			'notes'			=> array()
		);
		$status = array(
			'sent'		=> array(),
			'failed'	=> array()
		);
		foreach ($this->getDestinations() as $d) {
			if ($d instanceof Patron) {
				$contactcrit = new Criteria();
				$contactcrit->add(ContactPeer::CONTACT_TYPE,ContactPeer::TYPE_MOBILE);
				$contactcrit->addDescendingOrderByColumn(ContactPeer::CONTACT_PREF);
				$contacts = $d->getContacts($contactcrit);
				if (count($contacts) < 1) {
					// patron doesn't have a mobile contact, so skip and fail.
					$status['failed'][] = array(
						'destination'	=> $d,
						'errormsg'		=> Prado::localize("L'utente '{patron}' non ha un contatto".
							" di tipo cellulare.",array('patron' => $d->getCompleteName())),
					);
					continue;
				}
				$contact = $contacts[0]->getContactValue();
				$notificationData['receiver_class'] = 'Patron';
				$notificationData['receiver_id'] = $d->getPatronId();
			} else if ($d instanceof Library) {
				$contact = trim($d->getPhone());
				if (!$contact) {
					// library doesn't have a mobile contact, so skip and fail.
					$status['failed'][] = array(
						'destination'	=> $d,
						'errormsg'		=> Prado::localize("La biblioteca '{library}' non ha un contatto telefonico.",
							array('library' => $d->getLabel())),
					);
					continue;
				}
				$notificationData['receiver_class'] = 'Library';
				$notificationData['receiver_id'] = $d->getLibraryId();
			}
			$sender = NotificationSMS::getSMSSender($this->SMSSender->getSelectedValue(), $this->actualLibrary);
			$arrAlias = NotificationSMS::getAliasArray($this->getUser()->getLibrarian(), $this->actualLibrary,
				$this->getSolicitMode(), $d, $this->getLoanIds());

			try {
				$this->_notificationman->DoSmsReport(
					$tpl,
					$sender,
					$contact,
					$arrAlias,
					$notificationData);
				$status['sent'][] = array(
					'destination' => $d,
					'loan_ids'	=> $arrAlias['LOAN_IDS']);
			} catch (Exception $e) {
				if ($e->getCode() == NotificationManager::ERR_NOCREDIT)
					$m = Prado::localize('Errore: credito non sufficiente');
				else
					$m = Prado::localize('Errore: ').$e->getMessage();
				$status['failed'][] = array(
					'destination'	=> $d,
					'errormsg'		=> $m);
			}
		}
		return $status;
	}
}
