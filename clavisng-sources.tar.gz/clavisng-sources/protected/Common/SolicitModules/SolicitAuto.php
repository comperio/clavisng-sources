<?php

/**
 * SolicitAuto
 *
 * $conf = [
 *      'PATRON' => [
 *          'A' => [ // 1° sollecito
 *              'channels' => ['PREF','SMS','EMAIL','BOT','APP','VOICE','PDF'],
 *              'timeout' => '1d',
 *              'retry' => 2,
 *              'templates' => ['SMS'=>123,'EMAIL'=>24...],
 *              'report_on' => 'all|error|none'
 *          ],
 *          'B' => [
 *          ]
 *      ],
 *      'LIBRARIAN' => [
 *      ],
 *      'REPORT' => 'daily|weekly|none',
 *      'REPORT_TO' => 'library|system|file|none'
 * ]
 *
 * Handle an automatic notifications
 *
 * @author Rigolin Dario <dario.rogolin@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2017 Comperio srl
 */
class SolicitAuto extends BaseSolicit {

	protected $channel = NotificationPeer::CHANNEL_AUTO;

	public function activate() {
		$notifyList = array();
		$solicMode = $this->getSolictMode();
		foreach ($this->getDestinations() as $d) {
        }
        $this->SolicitMessageReport->setText(Prado::localize("Il sistema di notifica automatico ha preso in carico la richiesta.
         Un report via email sarà inviato con i risultati della notifica"));
		$this->_active = true;
    }

	public function deactivate() {
		$this->_active = false;
	}

	public function notify()
	{
		$status = array('failed' => array(),'sent'=>array());

        $mode = $this->getSolicitMode();

        $loanids = $this->getLoanIds();

        foreach ($loanids as $lid) {

        }

		foreach ($this->getDestinations() as $d) {



		    /*
            $n = new Notification();
            $n->setNotificationState(self::STATUS_PENDING);
            $n->setSenderLibraryId($sender_library_id);
            $n->setObjectClass($receiver_class);
            $n->setObjectId(intval($receiver_id));
            $n->setNotificationChannel(NotificationPeer::CHANNEL_AUTO);
            $n->setNotificationClass('');
            $n->setDeliveryDate(time());
            if ($description)
                $n->setMessage($description);
            if ($notes)
                $n->setNotes(serialize($notes));
            $n->save();
            */
            $status['failed'][] = array(
                'destination' => $d,
                'loan_ids' => $this->getLoanIds());

        }

		return $status;
	}
}