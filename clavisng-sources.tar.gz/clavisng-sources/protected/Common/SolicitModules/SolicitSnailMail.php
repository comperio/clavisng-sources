<?php

/**
 * SolicitSnailMail
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2010 Comperio srl
 */
class SolicitSnailMail extends BaseSolicit {

	protected $channel = NotificationPeer::CHANNEL_SNAILMAIL;

	public function activate() {
		switch ($this->getSolicitMode()) {
			case 'solicit':
				$this->JRPBox->setReportClass('JR_LOAN_SOLICIT');
				break;
			case 'readyforloan':
				$this->JRPBox->setReportClass('JR_LOAN_NOTIFY');
				break;
			case 'expiring':
				$this->JRPBox->setReportClass('JR_LOAN_EXPIRING');
				break;
			default:
				throw new Exception('Cannot init module');
		}
		$this->JRPBox->populate();
		if (count($this->JRPBox->ReportList->getDataSource()) < 1) {
			$this->NoTemplatesWarning->setVisible(true);
			$this->DoNotifyButton->setEnabled(false);
			return;
		}
		$this->DoNotifyButton->setEnabled(true);
		$this->_active = true;
	}

	public function getDocument()
	{
		$patrons = array();
		$libraries = array();
		foreach ($this->getDestinations() as $d) {
			if ($d instanceof Patron)
				$patrons[] = $d->getPatronId();
			if ($d instanceof Library)
				$libraries[] = $d->getLibraryId();
		}
		$patrons = implode(',',$patrons);
		$items = LoanQuery::create()
			->filterByLoanId($this->getLoanIds())
			->select(array('ItemId'))
			->distinct()
			->find()->toArray();
		/*$c = new Criteria();
		$c->add(LoanPeer::LOAN_ID,$this->getLoanIds(),Criteria::IN);
		$c->clearSelectColumns()->addSelectColumn(LoanPeer::ITEM_ID);
		$c->setDistinct();
		$items = LoanPeer::doSelectStmt($c)->fetchAll(PDO::FETCH_COLUMN,0);*/
		$opt_params['P_ITEM_ID'] = implode(',',$items);
		$this->_notificationman->DoJasperReport($this->JRPBox,$patrons,$opt_params);
	}

	public function notify() {
		switch ($this->getSolicitMode()) {
			case 'solicit':
				$description = $this->getDescription().' [via posta ordinaria]';
				break;
			case 'expiring':
				$description = $this->getDescription().' [via posta ordinaria]';
				break;
			case 'readyforloan':
				$description = $this->getDescription().' [via posta ordinaria]';
				break;
			default:
				$description = $this->getDescription().'';
				break;
		}
		$status = array(
			'sent'		=> array(),
			'failed'	=> array()
		);
		foreach ($this->getDestinations() as $d) {
			NotificationPeer::addNewNotification($this->channel,
				$this->getUser()->getActualLibraryId(),
				get_class($d),
				$d->getId(),
				$description);
			$status['sent'][] = array(
				'destination' => $d,
				'loan_ids'	=> $this->getLoanIds());
		}
		return $status;
	}
}