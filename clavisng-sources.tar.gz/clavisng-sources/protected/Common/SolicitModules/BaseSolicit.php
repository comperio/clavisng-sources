<?php

abstract class BaseSolicit extends TTemplateControl
{
	protected $_notificationman;
	protected $channel = null;
	protected $_active = false;
	protected $_solicitmode;
	protected $_available_modes = array(
		'solicit',
		'readyforloan',
		'expiring'
	);
	protected $_destinations = array();
	protected $_loans = array();
	protected $_desc_suffix = '';

	// Child classes must implement the following methods.
	abstract protected function activate();
	abstract protected function notify();


	public function onInit($param) {
		$this->_notificationman = $this->getApplication()->getModule('notification');
	}

	public function isActive() {
		return $this->_active;
	}

	public function setSolicitMode($value) {
		$this->_solicitmode = TPropertyValue::ensureEnum($value,$this->_available_modes,'solicit');
	}

	public function getSolicitMode() {
		return $this->_solicitmode;
	}

	public function getDirectNotify() {
		return true;
	}

	public function setDestinations($value) {
		$this->setControlState('Destinations',$value,array());
	}
	public function getDestinations() {
		return $this->getControlState('Destinations',array());
	}

	public function setLoanIds($value) {
		$this->setControlState('LoanIds',$value,array());
	}
	public function getLoanIds() {
		return $this->getControlState('LoanIds',array());
	}

	public function setDescription($value) {
		$this->setControlState('Description',$value,array());
	}
	public function getDescription() {
		return $this->getControlState('Description',array());
	}

	public function addNotification() {
		$desc = $this->getDescription() ?
			Prado::localize($this->getDescription()) : '';
		foreach ($this->getDestinations() as $d) {
			NotificationPeer::addNewNotification($this->channel,
				$this->getUser()->getActualLibraryId(),
				get_class($d),
				$d->getId(),
				$desc);
		}
		return true;
	}
}