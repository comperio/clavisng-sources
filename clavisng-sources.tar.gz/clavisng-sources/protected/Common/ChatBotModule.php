<?php

/**
 * ChatBotModule class.
 *
 * A module for sending notification trough some supported messaging platforms that
 * consent bot communication.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author    Mauro Seno <mauro.seno@comperio.it>
 * @link      http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license   http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 */

class ChatBotModule extends TModule
{

    /** @var string $ApiKey from clavis-application.xml */
    private $ApiKey;

    /** @var string $BaseUrl from clavis-application.xml */
    private $WebHook;

    /** @var string $Nofier from clavis-application.xml */
    private $Notifier;

    /**
     * Return the chat bot endpoint.
     *
     * @return string
     */
    public function getWebHook()
    {
        return $this->WebHook;
    }

    /**
     * @param string $ApiKey
     */
    public function setApiKey($ApiKey)
    {
        $this->ApiKey = $ApiKey;
    }

    /**
     * @param string $WebHook
     */
    public function setWebHook($WebHook)
    {
        $this->WebHook = $WebHook;
    }

    /**
     * Return the api key through which query the bot
     *
     * @return string
     */
    public function getApiKey()
    {
        return $this->ApiKey;
    }

    /**
     * @return string
     */
    public function getNotifier()
    {
        return $this->Notifier;
    }

    /**
     * @param string $Notifier
     */
    public function setNotifier($Notifier)
    {
        $this->Notifier = $Notifier;
    }

    /**
     * @param $msgData
     * @return array
     */
    public function send($msgData, $notification_id)
    {
        $data = array(
            'mid' => $msgData['mongo_id'], // --- mongo id
            'nid' => $notification_id,     // --- receipt's notification id
            'msg' => $msgData['text'],      // --- the actual message to send
            'botconf' => $this->getApiKey()
        );

        $url = $this->getNotifier() . $this->getApiKey() . '/';
        $postdata = http_build_query($data);

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $r = curl_exec($ch);

        if (curl_errno($ch) !== 0) {
            throw new \RuntimeException(curl_error($ch), curl_errno($ch));
        }

        return json_decode($r);
    }
}