<?php
/**
 * ClavisManageRequestsList file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Widgets
 */

/**
 * ClavisManageRequestsList class
 *
 * New version for the newcirc system.
 * 
 * This component visualizes a datagrid whose lines are requests
 * for a loan, and which the current logged operator can, in
 * any way, fullfill.
 * It's filtered upon some parameters (inserted by some dropdown lists),
 * or filtered by some other parameters (i.e. patron_id) which are set
 * externally by the "setObject()" method (note: the column which
 * matched the typo of object passed is turned off in the grid).
 * 
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.7
 * @package Widgets
 * @since 2.1
 */
class ClavisManageRequestsList extends TTemplateControl
{
	private $_datasource = null;
	private $_checked;
	public  $_onlySelectedSessionName;
	private $_localItems;
	/** @param ClavisLoanManager $_loanmanager */
	protected $_loanmanager;
	/** @var  ClavisRequestManager $_requestManager */
	protected $_requestManager;
	private $_freeze;
	private $_foundNumberSessionName;
	private $_storedDataSourceSessionName;
	private $_storedDataSourceSessionNameOff;
	private $_pageIndexSessionName;
	private $_illCheckedSessionName;
	private $_localItemsSessionName;
	private $_globalCriteriaSessionName;
	public $_llibraryActive;
	public $_requestTypeActive;

	public function initVars()
	{
		$uniqueId = $this->getUniqueID() . $this->getUniqueName();
		$this->_foundNumberSessionName = 'FoundNumberSessionName' . $uniqueId;
		$this->_storedDataSourceSessionName = 'StoredDataSourceSessionName' . $uniqueId;
		$this->_storedDataSourceSessionNameOff = 'StoredDataSourceSessionNameOff' . $uniqueId;
		$this->_pageIndexSessionName = 'PageIndexSessionName' . $uniqueId;
		$this->_illCheckedSessionName = 'IllCheckedSessionName' . $uniqueId;
		$this->_localItemsSessionName = 'LocalItemsSessionName' . $uniqueId;
		$this->_globalCriteriaSessionName = 'GlobalCriteriaSessionName' . $uniqueId;
		//$this->_onlySelectedSessionName = "OnlySelectedSessionName" . $uniqueId;
		
		$this->_loanmanager = $this->getApplication()->getModule('loan');
		$this->_requestManager = $this->getApplication()->getModule('request');

		$this->_llibraryActive = LLibraryPeer::isEnabled();
		$this->_requestTypeActive = ItemRequestPeer::isRequestType();
	}

	/**
	 * Here we load the clavis loan manager module, we get the
	 * saved (into session variables) datasource (as a hash), and
	 * we populate the grid in case the page is loaded the first
	 * time.
	 *
	 * @param TEventParameter $param
	 */
	public function onInit($param)
	{
		parent::onInit($param);
		$this->initVars();

		$this->_checked = $this->getChecked();
		$this->MaxDistanceColumn->setVisible($this->_llibraryActive);
		
		if (!$this->getPage()->getIsPostBack()
				&& !$this->getPage()->getIsCallback())
		{
			$this->NoSearchPanel->setVisible(false);
			$this->PopulatedFlag->setValue("false");

			//////$this->doCleanFilter(false); // don't populate
			
			// this was moved here from onLoad() on 8-mar-2017
			$this->initFilterFields();
		}

		if ($this->getInvertMode())
		{
			$this->ItemColumn->setVisible(false);
			$this->ManageableColumn->setVisible(false);
			$this->QueueColumn->setVisible(false);
		}
	}

	public function onLoad($param)
	{
		parent::onLoad($param);

		$populated = ($this->PopulatedFlag->getValue() == "true");
				
		if (!$this->getPage()->getIsPostBack()
				&& !$this->getPage()->getIsCallback())
		{
			/// here we had the initFilterFields() function
		}

		if ($this->getAutopopulate())
		{
			$this->populate();
		}
		else
		{
			$this->NoSearchPanel->setVisible(!$populated);
		}
	}

	private function initFilterFields()
	{
		if ($this->getViewFiltersFlag())
		{
			// populate Section
			$this->SectionFilter->setLibraryId($this->getUser()->getActualLibraryId());
			$this->SectionFilter->setAddedValues(array('**IS*NULL**' => '(' . Prado::localize('valore nullo') . ')'));
			$this->SectionFilter->populateList();

			$this->DeliveryLibraryFilter->setDataSource(LibraryPeer::getLibrariesHashWithBlank(null, true));
			$this->DeliveryLibraryFilter->dataBind();

			if ($this->_llibraryActive)
			{	
				$this->MaxDistanceListFilter->setDataSource(LLibraryPeer::calculateRequestDistances(true));	// with blank
				$this->MaxDistanceListFilter->dataBind();
			}

			if ($this->_requestTypeActive)
			{	
				$requestTypes = ItemRequestPeer::getRequestTypes(true);	// with blank
				$nullValue = array(ItemRequestPeer::REQUESTTYPE_NULLVALUESTRING => Prado::localize('normale'));
				$requestTypes = array_merge(array_slice($requestTypes, 0, 1), $nullValue, array_slice($requestTypes, 1, null, true));

				$this->RequestTypeListFilter->setDataSource($requestTypes);
				$this->RequestTypeListFilter->dataBind();
				//$this->RequestTypeListFilter->setSelectedValue(ItemRequestPeer::REQUESTTYPE_NULLVALUESTRING);
			}
		}

		$this->doCleanFilter(false);	// don't populate
	}
	
	public function setUniqueName($value = "")
	{
		$this->setControlState("UniqueName", $value, "");
	}

	public function getUniqueName()
	{
		return $this->getControlState("UniqueName", "");
	}

	public function setAutopopulate($param = "true")
	{
		if (strtolower($param) === "false")
		{
			$param = false;
		}
		else
		{
			$param = true;
		}

		$this->setControlState("autopopulate", $param, true);
	}

	public function getAutopopulate()
	{
		return $this->getControlState("autopopulate", true);
	}

	private function resetGlobalCriteria()
	{
		$this->setGlobalCriteria(null);
	}

	private function setGlobalCriteria($criteria = null)
	{
		return SerializableCriteria::refreshCriteria($this->getViewState($this->_globalCriteriaSessionName, null));
	}

	public function getGlobalCriteria()
	{
		$this->_globalCriteria = $this->getApplication()->getSession()->itemAt($this->_globalCriteriaSessionName, null);

		if ($this->_globalCriteria instanceof Criteria)
			$this->_globalCriteria = SerializableCriteria::refreshCriteria($this->_globalCriteria);
		
		return $this->_globalCriteria;
	}
	
	public function setFreeze($freeze)
	{
		$this->_freeze = $freeze;
		$this->setViewState("freeze", $freeze, null);
	}

	public function getFreeze()
	{
		if (is_null($this->_freeze))
			$this->_freeze = $this->getViewState("freeze", null);
		
		return $this->_freeze;
	}

	public function resetChecked($state = false, $updateGridFlag = true)
	{
		$toExcludeRequestIds = array();
		
		foreach ($this->Grid->getItems() as $item)
		{
			if ($item->CheckColumn->Checked->getVisible())
			{
				if ($updateGridFlag)
					$item->CheckColumn->Checked->setChecked($state);
			}
			else
			{
				if ($updateGridFlag)
					$item->CheckColumn->Checked->setChecked(false);

				if ($state)
				{
					$requestId = intval($item->CheckColumn->CheckRequestId->getValue());
		
					if ($requestId > 0)
						$toExcludeRequestIds[$requestId] = true;
				}
			}
		}

		$newStates = array('all' => $state) + $toExcludeRequestIds;
		$this->setChecked($newStates);
		
		$this->updateSelectedPanel();
	}

	public function setChecked($checked = null)
	{
		$this->_checked = $checked;
		$this->getApplication()->getSession()->add($this->_illCheckedSessionName, $checked);
	}

	public function getChecked()
	{
		$this->_checked = $this->getApplication()->getSession()->itemAt($this->_illCheckedSessionName);

		if (is_null($this->_checked))
		{
			$this->resetChecked(false, false); // don't update grid
			$this->_checked = $this->getApplication()->getSession()->itemAt($this->_illCheckedSessionName);
		}

		return $this->_checked;
	}

	public function resetLocalItems()
	{
		$this->_localItems = array();
		$this->setLocalItems($this->_localItems);
	}

	public function setLocalItems($localItems)
	{
		if ($localItems == null)
		{
			$localItems = $this->_localItems;
		}
		else
		{
			$this->_localItems = $localItems;
		}
		
		$this->getApplication()->getSession()->add($this->_localItemsSessionName, $localItems);
	}

	public function getLocalItems()
	{
		if (is_null($this->_localItems))
			$this->_localItems = $this->getApplication()->getSession()->itemAt($this->_localItemsSessionName);

		return $this->_localItems;
	}

	/**
	 * Method which resets the datasource (also saves into session
	 * variable), the checked status, and re-populates everything.
	 *
	 */
	public function resetDataSource($populateFlag = true)
	{
		$this->doResetGrid();
		$this->doResetDataSource();

		if ($populateFlag)
			$this->populate();
	}

	private function doResetDataSource()
	{
		$this->resetChecked();
		
		$this->resetGlobalCriteria();
		///////$this->resetOnlySelected();
//		$this->_datasource = array();
//		$this->getApplication()->getSession()->add($this->_datasourceSessionName, $this->_datasource);
		$this->resetSelectedPanel();
		//$this->resetSorting();
		
		$this->resetLocalItems();  ///
	}

//	public function resetOnlySelected($value = false)
//	{
//		$this->setOnlySelected($value);
//		$this->OnlySelectedCheck->setChecked(false);
//		$this->TeleportCheck->setChecked(false);
//	}
//
//	public function setOnlySelected($flag = false)
//	{
//		if ($flag === 'false')
//			$flag = false;
//		
//		if ($flag === 'true')
//			$flag = true;
//
//		$this->getApplication()->getSession()->add($this->_onlySelectedSessionName, $flag, false);
//	}
//
//	public function getOnlySelected()
//	{
//		$flag = $this->getApplication()->getSession()->itemAt($this->_onlySelectedSessionName);
//		return $flag;
//	}
	
	public function resetSelectedPanel()
	{
		$this->SelectedPanel->setCssClass('panel_off');
		$this->SelectedNumber->setText(0);
	}
	
	private function doResetGrid()
	{
		$this->PopulatedFlag->setValue("false");
		$this->NoSearchPanel->setVisible(!$this->getAutopopulate());
		$this->Grid->setVirtualItemCount(0);
		$this->Grid->setDataSource(array());
		$this->Grid->dataBind();
		$this->Grid->setCurrentPage(0);
		$this->FoundNumber->setText(0);
	}

	public function resetFoundNumber()
	{
		$this->setFoundNumber(0);
	}

	public function setFoundNumber($param = 0)
	{
		$this->getApplication()->getSession()->add($this->_foundNumberSessionName, $param);
	}

	public function getFoundNumber()
	{
		return $this->getApplication()->getSession()->itemAt($this->_foundNumberSessionName);
	}

	public function setStoredDataSource($param = array())
	{
		$this->_datasource = $param;
		$this->getApplication()->getSession()->add($this->_storedDataSourceSessionName, $this->_datasource);
	}

	public function getStoredDataSource()
	{
		$this->_datasource = $this->getApplication()->getSession()->itemAt($this->_storedDataSourceSessionName);
		
		return $this->_datasource;
	}

	public function setNeverRequestCategory($cat)
	{
		$this->setViewState('neverRequestCategory', $cat, null);
	}

	public function getNeverRequestCategory()
	{
		return $this->getViewState('neverRequestCategory', null);
	}
	
	public function setRequestDateFrom($date)
	{
		$this->setViewState('requestDateFrom', $date, null);
	}

	public function getRequestDateFrom()
	{
		return $this->getViewState('requestDateFrom', null);
	}

	public function setRequestDateTo($date)
	{
		$this->setViewState('requestDateTo', $date, null);
	}

	public function getRequestDateTo()
	{
		return $this->getViewState('requestDateTo', null);
	}

	public function setLoanStatusFlag($flag = false)
	{
		if ($flag != true)
		{
			$flag = "false";
		}
		else
		{
			$flag = "true";
		}

		$this->setViewState('loanStatusFlag', $flag, "false");
	}

	public function getLoanStatusFlag()
	{
		return $this->getViewState('loanStatusFlag', "false");
	}

	public function setLoanableSinceFlag($flag = false)
	{
		if ($flag != true)
		{
			$flag = "false";
		}
		else
		{
			$flag = "true";
		}

		$this->setViewState('loanableSinceFlag', $flag, "false");
	}

	public function getLoanableSinceFlag()
	{
		return $this->getViewState('loanableSinceFlag', "false");
	}

	public function setViewFiltersFlag($flag = null)
	{
		if (strtolower($flag) == "false")
		{
			$flag = "false";
		}
		else
		{
			$flag = "true";
		}

 		$this->setViewState('viewFiltersFlag', $flag);
 	}

	public function getViewFiltersFlag()
	{
		$flag = $this->getViewState('viewFiltersFlag');

		if (strtolower($flag) == "false")
		{
			$flag = false;
		}
		else
		{
			$flag = true;
		}

		return $flag;
	}

	public function setInvertMode($flag = null)
	{
		if (strtolower($flag) == "true")
		{
			$flag = "true";
		}
		else
		{
			$flag = "false";
		}

		$this->setViewState('invertMode', $flag, "false");
	}

	public function getInvertMode()
	{
		$flag = $this->getViewState('invertMode', "false");

		if (strtolower($flag) == "true")
		{
			$flag = true;
		}
		else
		{
			$flag = false;
		}

		return $flag;
	}

	public function getMasterChecked()
	{
		$checked = $this->getChecked();
		
		return $checked['all'];
	}

	private function calculateParamsFromBarcode($barcode = "")
	{
		$manifestationId = "";
		$itemId = "";

		$query = ItemQuery::create();

		$invArray = explode("-", $barcode);
		if (count($invArray) == 2)
		{
			list($invSerie, $invNumber) = $invArray;

			$query->filterByInventorySerieId($invSerie);
			$query->filterByInventoryNumber($invNumber);
		}
		else
		{
			$query->filterByBarcode($barcode);
		}

		$item = $query->findOne();
		
		if ($item instanceof Item)
		{
			if ($item->isOoc())
			{
				$manifestationId = 0;
				$itemId = $item->getItemId();
			}
			else
			{
				$manifestationId = $item->getManifestationId();
				$itemId = null;
			}
		}

		return array($manifestationId, $itemId);
	}	
	
	public function getCheckedItemIds(	$force = false,
										$reset = false,
										$jasperMode = false)
	{
		$checked = $this->getChecked();
		$masterChecked = $checked['all'];
		unset($checked['all']);
		$checkedIds = array_keys($checked);
		$requestIds = array();
		$itemIds = array();
		$output = array();
		$itemFilters = array();

		if (!$masterChecked)
		{
			$requestIds = array();
			$localItems = $this->getLocalItems();
			foreach ($checkedIds as $requestId)
			{
				if (array_key_exists($requestId, $localItems))
				{
					$itemId = $localItems[$requestId];
				}
				else
				{
					$itemId = null;
				}
				
				$requestIds[$requestId] = $itemId;
			}
		}
		else // the strange case of inverse mastercheck  ...
		{
			if ($this->getInvertMode())
			{
				/*  OLD FILTERS
				$requestDateFrom = $this->getRequestDateFrom();
				$requestDateTo = $this->getRequestDateTo();
				$loanStatusFlag = $this->getLoanStatusFlag();
				$loanableSinceFlag = $this->getLoanableSinceFlag();

				$itemFilters = array_merge($itemFilters, array(	'requestDateFrom' => $requestDateFrom,
																'requestDateTo' => $requestDateTo,
																'loanStatusFlag' => $loanStatusFlag,
																'loanableSinceFlag' => $loanableSinceFlag ));
				 */

				$itemFilters = array('neverRequestCategory' => $this->getNeverRequestCategory());

				$requestsRaw = $this->_requestManager->getNeverRequests(	null, 
																			null, 
																			null, 
																			$itemFilters); // not paginated
			}
			else //		normal pending requests case
			{
				if ($this->getViewFiltersFlag())
				{
					$sectionFilter = "";
					
					if ($this->SectionFilter->getSelectedIndex() > 0)
						$sectionFilter = $this->SectionFilter->getSelectedValue();

					$collocationFilter = "";
					
					if (($candCollocationFilter = $this->CollocationFilter->getSafeText()) != "")
						$collocationFilter = $candCollocationFilter;

					$manifestationIdParamFilter = "";
					$itemIdParamFilter = "";

					$barcodeInvFilter = trim($this->BarcodeInvFilter->getSafeText());

					if ($barcodeInvFilter != "")
						list ($manifestationIdParamFilter, $itemIdParamFilter) = $this->calculateParamsFromBarcode($barcodeInvFilter);

					$patronFilter = "";
					$patronId = intval($this->PatronHiddenValue->getValue());
					
					if ($patronId > 0)
						$patronFilter = $patronId;

					$deliveryLibraryId = "";
					
					if ($this->DeliveryLibraryFilter->getSelectedIndex() > 0)
						$deliveryLibraryId = $this->DeliveryLibraryFilter->getSelectedValue();
					
					$maxDistance = "";
					
					if ($this->_llibraryActive
							&& ($this->MaxDistanceListFilter->getSelectedIndex() > 0))
						$maxDistance = $this->MaxDistanceListFilter->getSelectedValue();

					$requestType = "";
					
					if ($this->_requestTypeActive
							&& ($this->RequestTypeListFilter->getSelectedIndex() > 0))
						$requestType = $this->RequestTypeListFilter->getSelectedValue();

					$itemFilters = array(	'section' => $sectionFilter,
											'collocation' => $collocationFilter,
											'manifestationIdParam' => $manifestationIdParamFilter,
											'itemIdParam' => $itemIdParamFilter,
											'patron' => $patronFilter,
											'deliveryLibraryId' => $deliveryLibraryId,
											'maxDistance' => $maxDistance,
											'requestType' => $requestType );
				}
				else
				{
					$itemFilters = array();
				}

				$requestsRaw = $this->_requestManager->getRequests(	null,
																	null,
																	null,
																	$itemFilters); // not paginated
			}

			foreach ($requestsRaw as $row)
			{
				$requestId = $row['requestId'];
				
				if (in_array($requestId, $checkedIds))  // skip if negative checked
					continue;

				if (array_key_exists(0, $row['idata']))
				{
					$candidateItem = $row['idata'][0];
				}
				else
				{
					$candidateItem = null;
				}
				
				$requestIds[$requestId] = $candidateItem;
			}
		}

		if ($jasperMode)
		{
			if ((count($requestIds) == 0)
					&& ($force))
			{
				$this->resetChecked(true);
				$output = $this->getCheckedItemIds(false, false, true); // called with jasper mode true
			}
			else
			{
				$output = array(	'requestIds' => array_keys($requestIds), 
									'itemIds' => array_values($requestIds) );
			}

			if ($reset)
				$this->resetChecked(false);
		}
		else //		normal mode, not jasper
		{
			if ((count($requestIds) == 0) && ($force))
			{
				$this->resetChecked(true);
				$recursiveOutput = $this->getCheckedItemIds();
				$requestIds = $recursiveOutput['requestIds'];
				$itemIds = $recursiveOutput['itemIds'];
			}

			if ($reset)
				$this->resetChecked(false);

			$output = $requestIds;
		}

		return $output;
	}

	public function countCheckedIds(	$force = false,
										$reset = false)
	{
		$checked = $this->getChecked();
		$masterChecked = $checked['all'];
		unset($checked['all']);
		$checkedIds = array_keys($checked);
		$requestIds = array();
		$itemIds = array();
		$output = array();
		$itemFilters = array();
					
		if (!$masterChecked)	// normal case, not masterchecked
		{
			$requestIds = array();
			$localItems = $this->getLocalItems();
			
			foreach ($checkedIds as $requestId)
			{
				if (array_key_exists($requestId, $localItems))
				{
					$itemId = $localItems[$requestId];
				}
				else
				{
					$itemId = null;
				}
				
				$requestIds[$requestId] = $itemId;
			}
		}
		else	// the strange case of inverse mastercheck  ...
		{
			if ($this->getInvertMode())
			{
				/* OLD FILTERS
				$requestDateFrom = $this->getRequestDateFrom();
				$requestDateTo = $this->getRequestDateTo();
				$loanStatusFlag = $this->getLoanStatusFlag();
				$loanableSinceFlag = $this->getLoanableSinceFlag();

				$itemFilters = array_merge(	$itemFilters,
											array(	'requestDateFrom' => $requestDateFrom,
													'requestDateTo' => $requestDateTo,
													'loanStatusFlag' => $loanStatusFlag,
													'loanableSinceFlag' => $loanableSinceFlag ));
				*/							
				
				$itemFilters = array('neverRequestCategory' => $this->getNeverRequestCategory());
				
				$requestsRaw = $this->_requestManager->getNeverRequests(null,
																		null,
																		null,
																		$itemFilters);	// not paginated
			}
			else
			{	// normal pending requests case
				if ($this->getViewFiltersFlag())
				{
					$sectionFilter = "";
					if ($this->SectionFilter->getSelectedIndex() > 0)
						$sectionFilter = $this->SectionFilter->getSelectedValue();

					$collocationFilter = "";
					if (($candCollocationFilter = $this->CollocationFilter->getSafeText()) != "")
						$collocationFilter = $candCollocationFilter;

					$manifestationIdParamFilter = "";
					$itemIdParamFilter = "";

					$barcodeInvFilter = trim($this->BarcodeInvFilter->getSafeText());

					if ($barcodeInvFilter != "")
						list ($manifestationIdParamFilter, $itemIdParamFilter) = $this->calculateParamsFromBarcode($barcodeInvFilter);
						
					$patronFilter = "";

					$patronId = intval($this->PatronHiddenValue->getValue());
					if ($patronId > 0)
						$patronFilter = $patronId;
			
					$deliveryLibraryId = "";

					if ($this->DeliveryLibraryFilter->getSelectedIndex() > 0)
						$deliveryLibraryId = $this->DeliveryLibraryFilter->getSelectedValue();

					$maxDistance = "";
					
					if ($this->_llibraryActive
							&& ($this->MaxDistanceListFilter->getSelectedIndex() > 0))
						$maxDistance = $this->MaxDistanceListFilter->getSelectedValue();

					$requestType = "";
					
					if ($this->_requestTypeActive
							&& ($this->RequestTypeListFilter->getSelectedIndex() > 0))
						$requestType = $this->RequestTypeListFilter->getSelectedValue();
					
					$itemFilters = array(	'section' => $sectionFilter,
											'collocation' => $collocationFilter,
											'manifestationIdParam' => $manifestationIdParamFilter,
											'itemIdParam' => $itemIdParamFilter,
											'patron' => $patronFilter,
											'deliveryLibraryId' => $deliveryLibraryId,
											'maxDistance' => $maxDistance,
											'requestType' => $requestType );
				}
				else
				{
					$itemFilters = array();
				}
		
				$requestsRaw = $this->_requestManager->getRequests(	null,
																	null,
																	null,
																	$itemFilters);	// not paginated
			}
			
			foreach ($requestsRaw as $row)
			{
				$requestId = $row['requestId'];
				if (in_array($requestId, $checkedIds))		// skip if negative checked
					continue;
				
				if (array_key_exists(0, $row['idata']))
				{
					$candidateItem = $row['idata'][0];
				}
				else
				{
					$candidateItem = null;
				}
				
				$requestIds[$requestId] = $candidateItem;
			}
		}	// end of inverse masterchecked case

		if ((count($requestIds) == 0)
				&& ($force))
		{
			$this->resetChecked(true);
			$recursiveOutput = $this->getCheckedItemIds();
			$requestIds = $recursiveOutput['requestIds'];
			$itemIds = $recursiveOutput['itemIds'];
		}

		if ($reset)
			$this->resetChecked(false);

		return count($requestIds);
	}
	
	public function setMasterChecked($newChecked = false, $param = null)
	{
		$checked = $this->getChecked();
		$masterChecked = $checked['all'];
		unset($checked['all']);
		$checkedIds = array_keys($checked);
		$requestIds = array();
		$itemIds = array();
		$output = array();
		$itemFilters = array();

		if (!$masterChecked)
		{
//			$requestIds = array();
//			$localItems = $this->getLocalItems();
//			foreach ($checkedIds as $requestId)
//			{
//				if (array_key_exists($requestId, $localItems))
//				{
//					$itemId = $localItems[$requestId];
//				}
//				else
//				{
//					$itemId = null;
//				}
//
//				$requestIds[$requestId] = $itemId;
//			}
			
			$requestCount = count($checkedIds);
		}
		else // the strange case of inverse mastercheck  ...
		{
			if ($this->getInvertMode())
			{
				$requestDateFrom = $this->getRequestDateFrom();
				$requestDateTo = $this->getRequestDateTo();
				$loanStatusFlag = $this->getLoanStatusFlag();
				$loanableSinceFlag = $this->getLoanableSinceFlag();

				$itemFilters = array_merge($itemFilters, array(	'requestDateFrom' => $requestDateFrom,
																'requestDateTo' => $requestDateTo,
																'loanStatusFlag' => $loanStatusFlag,
																'loanableSinceFlag' => $loanableSinceFlag,
																'excludeRequestIds' => $checkedIds ));

				$requestCount = $this->_requestManager->countNeverRequests(null, $itemFilters); // not paginated
			}
			else //		normal pending requests case
			{
				if ($this->getViewFiltersFlag())
				{
					$sectionFilter = "";
					
					if ($this->SectionFilter->getSelectedIndex() > 0)
						$sectionFilter = $this->SectionFilter->getSelectedValue();

					$collocationFilter = "";
					
					if (($candCollocationFilter = $this->CollocationFilter->getSafeText()) != "")
						$collocationFilter = $candCollocationFilter;

					$manifestationIdParamFilter = "";
					$itemIdParamFilter = "";

					$barcodeInvFilter = trim($this->BarcodeInvFilter->getSafeText());

					if ($barcodeInvFilter != "")
						list ($manifestationIdParamFilter, $itemIdParamFilter) = $this->calculateParamsFromBarcode($barcodeInvFilter);

					$patronFilter = "";
					$patronId = intval($this->PatronHiddenValue->getValue());
					
					if ($patronId > 0)
						$patronFilter = $patronId;

					$deliveryLibraryId = "";
					
					if ($this->DeliveryLibraryFilter->getSelectedIndex() > 0)
						$deliveryLibraryId = $this->DeliveryLibraryFilter->getSelectedValue();

					$maxDistance = "";
					
					if ($this->_llibraryActive
							&& ($this->MaxDistanceListFilter->getSelectedIndex() > 0))
						$maxDistance = $this->MaxDistanceListFilter->getSelectedValue();

					$requestType = "";
					
					if ($this->_requestTypeActive
							&& ($this->RequestTypeListFilter->getSelectedIndex() > 0))
						$requestType = $this->RequestTypeListFilter->getSelectedValue();
					
					$itemFilters = array(	'section' => $sectionFilter,
											'collocation' => $collocationFilter,
											'manifestationIdParam' => $manifestationIdParamFilter,
											'itemIdParam' => $itemIdParamFilter,
											'patron' => $patronFilter,
											'deliveryLibraryId' => $deliveryLibraryId,
											'maxDistance' => $maxDistance,
											'requestType' => $requestType,
											'excludeRequestIds' => $checkedIds );
				}
				else
				{
					$itemFilters = array();
				}

				$requestCount = $this->_requestManager->countRequests(	null,
																		$itemFilters); // not paginated
			}
		}

		if (($requestCount == 0)
				&& ($force))
		{
			$this->resetChecked(true);
			$requestCount = $this->countCheckedItemIds();
		}

		if ($reset)
			$this->resetChecked(false);

		return $requestCount;
	}
	
//	public function setMasterChecked($newChecked = false, $param = null)
//	{
//		$this->resetChecked($newChecked);
//		$gridItems = $this->Grid->getItems();
//		$header = $this->Grid->getHeader();
//
//		foreach ($gridItems as $item)
//			$item->CheckColumn->Checked->setChecked($newChecked);
//
//		$header->CheckColumn->MasterCheck->setChecked($newChecked);
//	}

	private function calculateIData($iData = null)
	{
		if (!is_array($iData)
				|| count($iData) == 0)
			return array(); //	not valid

		$iDataItemId = (int) $iData[0];
		$iDataIssueId = (int) $iData[1];

		if (intval($iDataIssueId) > 0) // issue case
		{
			$iDataNavigateUrl = IssuePeer::getNavigateUrl() . $iDataIssueId;
		}
		else // item case
		{
			$iDataNavigateUrl = ItemPeer::getNavigateUrl() . $iDataItemId;
		}

		$collocationString = '';
		$section = trim($iData[4]);

		$collocation = trim($iData[5]);
		$specification = trim($iData[6]);
		$seq1 = trim($iData[7]);
		$seq2 = trim($iData[8]);

		$collocationString = trim(implode(' ', array(	$section,
														$collocation,
														$specification,
														$seq1,
														$seq2 )));
		
		$inventory_serie_id = trim($iData[2]);
		$inventory_number = $iData[3];
		
		if (!is_numeric($inventory_number))
			$inventory_number = null;

		if (($inventory_serie_id != '') && !is_null($inventory_number))
		{
			$inventory = $inventory_serie_id . "-" . $inventory_number;
		}
		else
		{
			$inventory = $inventory_serie_id . $inventory_number;
		}

		if ($iData[9]
				|| ($iData[10] != $this->getUser()->getActualLibraryId())) // Returned today
		{
			$collocationString = '<span style="font-weight: bold; color: red;">(!)</span> ' . $collocationString;
		}

		$iDataText = $collocationString . '<br/><span style="margin-top:2px;">(' . Prado::localize('inv: ') . $inventory . ')</span>';

		return array(	$iDataItemId,
						$iDataText,
						$iDataNavigateUrl );
	}

	public function populate()
	{
		if ($this->getFreeze())
			return;

		if (!$this->getPage()->getIsPostBack()
				&& !$this->getPage()->getIsCallback())
		{
			$this->resetPagination();
			$this->resetDataSource(false); // don't populate
		}

		if ($this->getViewFiltersFlag())
		{
			$sectionFilter = "";
			
			if ($this->SectionFilter->getSelectedIndex() > 0)
				$sectionFilter = $this->SectionFilter->getSelectedValue();

			$collocationFilter = "";
			
			if (($candCollocationFilter = $this->CollocationFilter->getSafeText()) != "")
				$collocationFilter = $candCollocationFilter;

			$manifestationIdParamFilter = "";
			$itemIdParamFilter = "";

			$barcodeInvFilter = trim($this->BarcodeInvFilter->getSafeText());
			
			if ($barcodeInvFilter != "")
				list ($manifestationIdParamFilter, $itemIdParamFilter) = $this->calculateParamsFromBarcode($barcodeInvFilter);

			$patronFilter = "";
			$patronId = intval($this->PatronHiddenValue->getValue());
			
			if ($patronId > 0)
				$patronFilter = $patronId;

			$deliveryLibraryId = "";
			
			if ($this->DeliveryLibraryFilter->getSelectedIndex() > 0)
				$deliveryLibraryId = $this->DeliveryLibraryFilter->getSelectedValue();

			$maxDistance = "";
					
			if ($this->_llibraryActive
					&& ($this->MaxDistanceListFilter->getSelectedIndex() > 0))
				$maxDistance = $this->MaxDistanceListFilter->getSelectedValue();

			$requestType = "";
			
			if ($this->_requestTypeActive
					&& ($this->RequestTypeListFilter->getSelectedIndex() > 0))
				$requestType = $this->RequestTypeListFilter->getSelectedValue();

			$itemFilters = array(	'section' => $sectionFilter,
									'collocation' => $collocationFilter,
									'manifestationIdParam' => $manifestationIdParamFilter,
									'itemIdParam' => $itemIdParamFilter,
									'patron' => $patronFilter,
									'deliveryLibraryId' => $deliveryLibraryId,
									'maxDistance' => $maxDistance,
									'requestType' => $requestType );
		}	// end of 'if ViewFiltersFlag is true'
		else
		{
			$itemFilters = array();
		}

		if ($this->getInvertMode())
		{
			/** mbrancaliontemp, OLDMODE
			$requestDateFrom = $this->getRequestDateFrom();
			$requestDateTo = $this->getRequestDateTo();
			$loanStatusFlag = $this->getLoanStatusFlag();
			$loanableSinceFlag = $this->getLoanableSinceFlag();

			$itemFilters = array_merge($itemFilters, array(	'requestDateFrom' => $requestDateFrom,
															'requestDateTo' => $requestDateTo,
															'loanStatusFlag' => $loanStatusFlag,
															'loanableSinceFlag' => $loanableSinceFlag ));
			 */
			
			$itemFilters = array('neverRequestCategory' => $this->getNeverRequestCategory());
		}

		$currentIndexPage = $this->Grid->getCurrentPage();
		$pageSize = $this->Grid->getPageSize();

		if ($this->getInvertMode())
		{
			$requestsRaw = $this->_requestManager->getNeverRequests(	null,
																		$currentIndexPage,
																		$pageSize, // for pagination
																		$itemFilters);

			$recCount = $this->_requestManager->countNeverRequests(	null,
																	$itemFilters);
		}
		else
		{
			$requestsRaw = $this->_requestManager->getRequests(	null,
																$currentIndexPage,
																$pageSize, // for pagination
																$itemFilters);

			$recCount = $this->_requestManager->countRequests(null, $itemFilters);
		}

		$checkedList = $this->getChecked();
		$masterCheck = $checkedList['all'];
		$localItems = $this->getLocalItems();	// candidate items
		
		$datasource = array();
		
		//	legenda idata: item_id, issue_id, inv_ser, inv_num, section, collocation, specification, sequence1, sequence2

		foreach ($requestsRaw as $index => $row)
		{
			$requestId = $row['requestId'];

			$request = null;

			if (intval($requestId) > 0)
				$request = ItemRequestQuery::create()->findPK($requestId);
			
			if (!($request instanceof ItemRequest))
				continue;

			$maxDistance = $this->_llibraryActive ? $request->getMaxDistance() : null;
			
			$requestType = null;
			$requestTypeString = '';
			
			if ($this->_requestTypeActive)
			{
				$requestType = $request->getRequestType();
				
				if (!is_null($requestType))
					$requestTypeString = '<br /><b>[' . ItemRequestPeer::getRequestTypeString($requestType) . ']</b>';
			}
			
			$expireDate = $request->getExpireDate();
			$requestDate = $row['requestDate'];

			if (array_key_exists($requestId, $checkedList))
			{
				$checked = $checkedList[$requestId];
			}
			else
			{
				$checked = false;
			}

			if ($masterCheck)
				$checked = !$checked;

			$titleText = $request->getTitle();

			$manifestationId = $row['manifestationId'];
			$itemId = $row['itemId'];
			$issueId = $row['issueId'];

			if (!is_null($issueId))
			{
				// request is on ISSUE
				$titleNavigateUrl = IssuePeer::getNavigateUrl() . $issueId;
				$requestTypeImage = "requesttype_issue.png";
				$requestTypeText = Prado::localize("prenotazione per fascicolo");
			}
			elseif (!is_null($itemId))
			{
				// request is on ITEM
				$titleNavigateUrl = ItemPeer::getNavigateUrl() . $itemId;
				$requestTypeImage = "requesttype_item.png";
				$requestTypeText = Prado::localize("prenotazione per esemplare");
			}
			elseif ($manifestationId > 0)
			{
				// request is on MANIFESTATION
				$titleNavigateUrl = ManifestationPeer::getNavigateUrl() . $manifestationId;
				$requestTypeImage = "";
				$requestTypeText = "";
			}
			else
			{
				// fallback (should not happen)
				$titleNavigateUrl = "";
				$requestTypeImage = "";
				$requestTypeText = "";
			}

			$iCount = (int) $row['icount'];
			$mCount = (int) $row['mcount'];
			$queue = (int) $row['queue'];
			$iCountQueue = "{$iCount}/{$queue}";
			$sCount = min(array($iCount - $mCount, $queue)); // number of effectively satisfiable requests

			$iDataItemId = 0;
			$iDataText = "";
			$iDataNavigateUrl = "";

			if (count($row['idata']) > 0)
				list($iDataItemId, $iDataText, $iDataNavigateUrl) = $this->calculateIData($row['idata']);

			if ($iDataItemId > 0)
				$localItems[$requestId] = $iDataItemId;

			$destinationText = Prado::localize('indefinito'); // priming
			$destinationNavigateUrl = "";
			$patron = $request->getPatron();
			$externalLibrary = $request->getExternalLibrary();
			$deliveryLibraryText = "";

			/**
			 * this should be the number of items that other libraris in the system
			 * can actually use for this request that i can process, on my behalf.
			 * 
			 * If it's == 0, my library is the only library that can process that request.
			 */
			$alienItemsCount = 0;

			if ($patron instanceof Patron)
			{
				$destinationText = $patron->getCompleteName();

				$loanCount = LoanQuery::create()
									->filterByPatron($patron)
									->filterByLoanStatus(ItemPeer::getLoanStatusActive())
									->count();

				if ($loanCount > 0)
					$destinationText .= "&nbsp;(<b>$loanCount</b>)";

				$destinationNavigateUrl = $patron->getNavigateUrl(true);

				$deliveryLibrary = $request->getDeliveryLibrary();
				if ($deliveryLibrary instanceof Library)
				{
					$deliveryLibraryText = "<br />->&nbsp;" . $deliveryLibrary->getLabel(null, null, null, 20);

					$alienItemsCount = $this->_requestManager->countRequestAllCandidateItems(	$deliveryLibrary->getLibraryId(),
																								$maxDistance,
																								$manifestationId,
																								$itemId,
																								$issueId);
				}
			}
			elseif ($externalLibrary instanceof Library)
			{
				$destinationText = $externalLibrary->getLabel(true, false, true, 30);
				$destinationNavigateUrl = $externalLibrary->getNavigateUrl(true);
			}

			$flagCode = ($alienItemsCount > 0
									? ClavisRequestManager::no_flag
									: ClavisRequestManager::red_flag );

			$creatorUrl = $creatorName = '';
			$creatorId = $request->getCreatedBy();
			
			if ($creatorId == 1)
			{
				$creatorName = Prado::localize('da Opac');
				$creatorUrl = '';
			}
			else
			{
				$librarian = $request->getLibrarianRelatedByCreatedBy();
				
				if ($librarian instanceof Librarian)
				{
					$creatorUrl = $librarian->getUrlPage();
					$creatorName = $librarian->getUrlName();
				}
			}

			$dataRow['destinationText'] = $destinationText;
			$dataRow['destinationNavigateUrl'] = $destinationNavigateUrl;

			if (is_null($maxDistance))
				$maxDistance = LlibraryPeer::NULLDISTANCE;

			$requestStatus = $request->getRequestStatus();

			$datasource[] = array(	'row' => $index,
									'requestId' => $requestId,
									'requestDate' => $requestDate,
									'expireDate' => $expireDate,
									'checked' => $checked,
				
									'titleText' => $titleText,
									'titleNavigateUrl' => $titleNavigateUrl,
									'iCount' => $iCount,
									'sCount' => $sCount,
									'queue' => $queue,

									'iCountQueue' => $iCountQueue,
									'iDataItemId' => $iDataItemId,
									'iDataText' => $iDataText,
									'iDataNavigateUrl' => $iDataNavigateUrl,
									'destinationText' => $destinationText,

									'destinationNavigateUrl' => $destinationNavigateUrl,
									'deliveryLibraryText' => $deliveryLibraryText,
									'creatorId' => $creatorId,
									'creatorUrl' => $creatorUrl,
									'creatorName' => $creatorName,
				
									'maxDistance' => $maxDistance,
									'requestType' => $requestType,
									'requestTypeString' => $requestTypeString,
									'requestNote' => $request->getRequestNote(),
									'alienItemsCount' => $alienItemsCount,
									'flagCode' => $flagCode,
				
									'requestTypeImage' => $requestTypeImage,
									'requestTypeText' => $requestTypeText,
									'requestStatus' => $requestStatus );
		}

		$this->Grid->setVirtualItemCount($recCount);
		$this->Grid->setDataSource($datasource);
		$this->Grid->dataBind();
		$this->setStoredDataSource($datasource);

		$this->FoundNumber->setText($recCount);
		$this->NoSearchPanel->setVisible(false);
		$this->PopulatedFlag->setValue("true");
		$this->setLocalItems($localItems);
	}

	public function onChangePage($sender, $param)
	{
		$newIndex = $param->NewPageIndex;
		$this->Grid->setCurrentPage($newIndex);

		$this->populate();
	}

	public function getPopupFlag()
	{
		return $this->getPage()->isPopup();
	}

	public function resetPagination()
	{
		$this->Grid->setCurrentPage(0);
	}

	public function onAddToShelf($sender, $param)
	{
		$errorShelfFlag = false;
		$shelfId = $this->ShelfResultValue->getValue();
		$this->ShelfResultValue->setValue(null);
		
		if (is_numeric($shelfId)
				&& !is_null($shelfId))
		{
			$shelf = ShelfQuery::create()->findPK($shelfId);
			
			if ($shelf instanceof Shelf)
			{
				$idsRaw = $this->getCheckedItemIds();
				$ids = array_keys($idsRaw);
				
				$countDone = $shelf->addItemToShelf('item_request', $ids);
				$countFailed = count($ids) - $countDone;
				
				if ($countDone > 0)
				{
					$this->getPage()->writeMessage($countDone == 1
															? Prado::localize("1 prenotazione nello scaffale '{shelfname}' con id: {shelfid}",
																					array(	'shelfname' => $shelf->getShelfName(),
																							'shelfid' => $shelf->getId() ))
							
															: Prado::localize("{count} prenotazioni aggiunte nello scaffale '{shelfname}' con id: {shelfid}",
																				array(	'count' => $countDone,
																						'shelfname' => $shelf->getShelfName(),
																						'shelfid' => $shelf->getId() )),
														ClavisMessage::INFO);
				}

				if ($countFailed > 0)
					$this->getPage()->writeMessage($countFailed == 1 
															? Prado::localize("1 prenotazione NON aggiunta nello scaffale '{shelfname}' con id: {shelfid}",
																					array(	'shelfname' => $shelf->getShelfName(),
																							'shelfid' => $shelf->getId() ))
							
															: Prado::localize("{count} prenotazioni NON aggiunte nello scaffale '{shelfname}' con id: {shelfid}",
																				array(	'count' => $countDone,
																						'shelfname' => $shelf->getShelfName(),
																						'shelfid' => $shelf->getId() )),
														ClavisMessage::ERROR);
			}
			else
			{
				$errorShelfFlag = true;
			}
		}
		else
		{
			$errorShelfFlag = true;
		}

		if ($errorShelfFlag)
		{
			$this->getPage()->writeMessage(Prado::localize("Lo scaffale '{shelfname}' con id: {shelfid} non esiste",
																				array(	'shelfname' => $shelf->getShelfName(),
																						'shelfid' => $shelf->getId() )),
												ClavisMessage::ERROR);
		}
		else
		{	
			if ($this->TeleportCheck->getChecked())
				$this->getPage()->gotoPageWithReturn('Communication.ShelfViewPage', array('id' => $shelfId));
		}
	}
	
	/**
	 * It changes the status (on/off) of the checkbox of one chosen
	 * row item of datagrid.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onFlipChecked($sender, $param)
	{
		$index = $sender->Parent->Parent->ItemIndex;
		$dataSource = $this->getStoredDataSource();

		$newStatus = $sender->getChecked();
		$checked = $this->getChecked();

		if (array_key_exists($index, $dataSource))
		{
			$row = $dataSource[$index];
		}
		else 
		{
			return false;
		}

		if (array_key_exists('requestId', $row))
		{
			$requestId = $row['requestId'];
		}
		else 
		{
			return false;
		}

		if (array_key_exists('all', $checked))
		{
			$checkedAll = $checked['all'];
		}
		else
		{
			return false;
		}

		if ($newStatus != $checkedAll)
		{
			$checked[$requestId] = true;
		}
		else
		{
			unset($checked[$requestId]);
		}

		$this->setChecked($checked);
		$this->updateSelectedPanel($param);
	}

	public function forceChecked($index)
	{
		$dataSource = $this->getStoredDataSource();
		$checked = $this->getChecked();

		if (array_key_exists($index, $dataSource))
		{
			$row = $dataSource[$index];
		}
		else 
		{
			return false;
		}

		$this->resetChecked(false);

		if (array_key_exists('requestId', $row))
		{
			$requestId = $row['requestId'];
		}
		else 
		{
			return false;
		}

		$checked[$requestId] = true;
		$this->setChecked($checked);
		
		$this->updateSelectedPanel($param);
	}

//	public function onMasterChecked($sender, $param)
//	{
//		$newStatus = $sender->getChecked();
//		$this->resetChecked($newStatus);
//
//		$gridItems = $this->Grid->getItems();
//
//		foreach ($gridItems as $item)
//			$item->CheckColumn->Checked->setChecked($item->CheckColumn->Checked->getVisible()
//																					? $newStatus
//																					: false );
//	}
	
	public function onMasterChecked($sender, $param)
	{
		$newStatus = $sender->getChecked();
		$this->resetChecked($newStatus);
		$gridItems = $this->Grid->getItems();
		
		foreach($gridItems as $item)
		{	
			$item->CheckColumn->Checked->setChecked(	$item->CheckColumn->Checked->getVisible()
														? $newStatus
														: false );
		}
		
		$this->updateSelectedPanel($param);
	}

	public function updateSelectedPanel($param = null)
	{
		$this->SelectedNumber->setText(intval($this->countCheckedIds()));
	
		if ($this->getPage()->getIsCallback())
		{
			if (!is_null($param))
			{
				$writer = $param->getNewWriter();
			}
			else
			{
				$writer = $this->getPage()->createWriter();
			}
			
			$this->SelectedPanel->render($writer);
		}
	}
	
	public function onNewLoan($sender, $param)
	{
		$parameter = $param->getCommandParameter();
		$itemId = $parameter['itemId'];
		$requestId = $parameter['requestId'];

		if (($itemId > 0)
				&& ($requestId > 0))
			$this->getPage()->gotoPageWithReturn(	"Circulation.NewLoan",
													array(	'itemId'=> $itemId,
															'requestId' => $requestId));
	}

	public function onPopupLoan($sender, $param)
	{
		$this->getPage()->cleanMessageQueue();

		$parameter = $param->getCommandParameter();
		$itemId = intval($parameter['itemId']);
		$itemRequestId = intval($parameter['requestId']);

		if (($itemId > 0)
				&& ($itemRequestId > 0))
		{
			$toRefreshFlag = false;

			$item = ItemQuery::create()->findPk($itemId);
			$newDueDate = $this->_loanmanager->CalculateDueDate($item);
			
			$itemRequest = ItemRequestQuery::create()->findPk($itemRequestId);
			$destination = $itemRequest->getLoanDestinationObject();
			
			if ($destination instanceof Patron)
			{
				$destinationName = $destination->getCompleteName();
			}
			elseif ($destination instanceof Library)
			{
				$destinationName = $destination->getLabel(true, true, true);
			}
			else
			{
				$destinationName = '(' . Prado::localize('errore sul nome del destinatario') . ')';
			}

			$clavisLibrarian = $this->getUser();
			$deliveryLibrary = $itemRequest->getDeliveryLibrary();
			$reqval = $this->_loanmanager->DoManageRequest($itemRequest, $clavisLibrarian);
			
			switch ($reqval)
			{
				case ClavisLoanManager::OK :
					$retval = $this->_loanmanager->DoLoanItem(	$item,
																$destination,
																$clavisLibrarian,
																$deliveryLibrary,
																$itemRequest,
							
																$newDueDate);
					
					switch ($retval)
					{
						case ClavisLoanManager::RSV_ALREADYMANAGED:
							$this->getPage()->enqueueMessage(Prado::localize("L'esemplare '{title}' [barcode: {barcode}] è già in gestione ad un altro operatore, per cui non è possibile prestarlo",
																					array(	'title' => $item->getTrimmedTitle(40),
																							'barcode' => $item->getBarcode() )),
																ClavisMessage::ERROR);

							$toRefreshFlag = true;
							break;

						case ClavisLoanManager::LOAN_ILLREQUESTED :
							$this->getPage()->enqueueMessage(Prado::localize("Prenotazione soddisfatta ed esemplare '{itemTitle}' [barcode: {itemBarcode}] messo in 'pronto al transito' per '{name}'",
																					array(	'itemTitle' => $item->getTrimmedTitle(40),
																							'itemBarcode' => $item->getBarcode(),
																							'name' => $destinationName )),  // Inserita richiesta di interprestito
																ClavisMessage::CONFIRM);

							$toRefreshFlag = true;
							break;

						case ClavisLoanManager::LOAN_READYTOLOAN :
							$labelText = Prado::localize("Prenotazione soddisfatta ed esemplare '{itemTitle}' [barcode: {itemBarcode}] messo in 'pronto al prestito' per '{name}'",
																array(	'itemTitle' => $item->getTrimmedTitle(40),
																		'itemBarcode' => $item->getBarcode(),
																		'name' => $destinationName ));  // Inserita richiesta di interprestito
																		//
							// ready-to-loan automatic notification
							if ((ClavisParamQuery::getParam('CLAVISPARAM','AutoEmailLoanReady') == 'true')
									&& ($destination instanceof Patron) )
							{
								$ret = NotificationHelper::sendNotificationEmail(	'readyforloan',
																					$destination,
																					$clavisLibrarian->getLibrarian(),
																					$deliveryLibrary,
																					array($item->getCurrentLoanId()));
								
								if ($ret)
								{
									$item->setNotifyCount($item->getNotifyCount() + 1);
									$item->save();
									$loan = $item->getLoanRelatedByCurrentLoanId();
									$loan->setNotifyCount($loan->getNotifyCount() + 1);
									$loan->save();
								
									$labelText .= Prado::localize(' - notificato automaticamente via email');
								}
							}
							
							$this->getPage()->enqueueMessage($labelText,
																ClavisMessage::CONFIRM);
							
							$toRefreshFlag = true;
							break;

						case ClavisLoanManager::LOAN_RESERVED :
							$this->getPage()->enqueueMessage(Prado::localize("Inserita prenotazione"),
																ClavisMessage::INFO);
							
							$toRefreshFlag = true;
							break;

						case ClavisLoanManager::LOAN_LOANED :
							$this->getPage()->enqueueMessage(Prado::localize("Prenotazione soddisfatta, esemplare '{itemTitle}' [barcode: {itemBarcode}] prestato a '{name}'",
																					array(	'itemTitle' => $item->getTrimmedTitle(40),
																							'itemBarcode' => $item->getBarcode(),
																							'name' => $destinationName )),
																ClavisMessage::CONFIRM);

							$toRefreshFlag = true;
							break;

						case ClavisLoanManager::LOAN_LOANALREADYEXISTS :
							$this->getPage()->enqueueMessage(Prado::localize("Errore: il prestito è già in corso"),
																ClavisMessage::ERROR);
							
							break;

						case ClavisLoanManager::ERROR :
						default:
							$this->getPage()->enqueueMessage(Prado::localize("Prestito fallito"),
																ClavisMessage::ERROR);
					}

					break;

				case ClavisLoanManager::RSV_ALREADYMANAGED:
					$this->getPage()->enqueueMessage(Prado::localize("La prenotazione con id: {id} è già in gestione",
																			array('id' => $itemRequestId)),
														ClavisMessage::ERROR);
					
					break;

				case ClavisLoanManager::RSV_ALREADYCLOSED:
					$this->getPage()->enqueueMessage(Prado::localize("La prenotazione con id: {id} è già soddisfatta o chiusa o annullata",
																			array('id' => $itemRequestId)),
														ClavisMessage::ERROR);
					
					break;

				case ClavisLoanManager::LOAN_PATRONNOTENABLED:
					$this->getPage()->enqueueMessage(Prado::localize("La prenotazione con id: {id} non è soddisfacibile perché l'utente non è ammesso al prestito",
																			array('id' => $itemRequestId)),
														ClavisMessage::ERROR);
					
					break;

				case ClavisLoanManager::LOAN_EXTERNALLIBRARYNOTENABLED:
					$this->getPage()->enqueueMessage(Prado::localize("La prenotazione con id: {id} non è soddisfacibile perché la biblioteca esterna, destinataria del prestito extrasistema, non è ammessa al prestito",
																			array('id' => $itemRequestId)),
														ClavisMessage::ERROR);
					
					break;

				case ClavisLoanManager::ERROR:
				default:
					$this->getPage()->enqueueMessage(Prado::localize("Errore sconosciuto sulla presa in gestione della prenotazione con id: {id}",
																			array('id' => $itemRequestId)),
														ClavisMessage::ERROR);
					
					break;
			}

			if ($toRefreshFlag)
			{
				$this->getPage()->flushDelayedMessage();

				$this->getApplication()->getSession()->add('ZebraItemRequestId', $itemRequestId);
				$this->getApplication()->getSession()->add('UpdateItemId', $itemId);
			}
			else
			{
				$this->getPage()->flushMessage();
			}

			$this->getPage()->getClientScript()->registerEndScript(__CLASS__ . '_js', 'onReturn(\'\',\'\',true);');
		}
		else
		{
			Prado::log('errore in '.__CLASS__);
		}
	}

	public function globalRefresh()
	{
		$this->populate();
	}

	public function onChooseRecord($sender, $param)
	{
		$manifestationId = intval($sender->getValue());
		$manifestation = ManifestationQuery::create()->findPK($manifestationId);
		
		if (!($manifestation instanceof Manifestation))
		{
			$this->getPage()->writeMessage(Prado::localize("Errore interno nella scelta della notizia con id={id}, perché probabilmente non più esistente",
																array('id' => $manifestationId)), 
											ClavisMessage::ERROR);
			
			return false;
		}

		$index = $sender->Parent->Parent->ItemIndex;
		$dataSource = $this->parseDataSource($this->getStoredDataSource());
		$row = $dataSource[$index];
		$requestId = intval($row['requestId']);
		$request = ItemRequestQuery::create()
						->findPK($requestId);
		
		if (!($request instanceof ItemRequest))
		{
			$this->getPage()->writeMessage(Prado::localize("Errore interno sulla prenotazione con id={id}, perché probabilmente non più esistente",
																array('id' => $requestId)), 
												ClavisMessage::ERROR);
			
			return false;
		}

		if ($request->getRequestStatus() != ItemRequestPeer::STATUS_PENDING)
		{
			$this->getPage()->writeMessage(Prado::localize("Non è possibile spostare l'oggetto della prenotazione sulla prenotazione con id={id} in quanto non è in stato 'pendente'",
																array('id' => $requestId)),
												ClavisMessage::ERROR);
			
			return false;
		}	
			
		$oldManifestationId = $request->getManifestationId();
		$oldItemId = $request->getItemId();
		$request->setManifestationId($manifestationId);
		$request->setItem(null);   // request only on manifestation
		$request->save();

		$this->globalRefresh();
		$title = $request->getTrimmedTitle(40);

		$this->getPage()->writeMessage(Prado::localize("Modificata la prenotazione con id: {requestId}. L'oggetto della prenotazione è stato spostato dalla notizia con id: {oldManifestationId} a id: {manifestationId}, titolo: '{title}'",
															array(	'requestId' => $requestId,
																	'oldManifestationId' => $oldManifestationId,
																	'manifestationId' => $manifestationId,
																	'title' => $title ))
											. ($oldItemId > 0
														? ". " . Prado::localize("É stata conservata la sola prenotazione per notizia.")
														: ""),
										ClavisMessage::CONFIRM);

		ChangelogPeer::logAction(	$request,
									ChangelogPeer::LOG_UPDATE,
									$this->getUser(), "Modificata la prenotazione con id: $requestId. L'oggetto della prenotazione è stato spostato dalla notizia con id: $oldManifestationId a id: $manifestationId, titolo: '$title'"
										. ($oldItemId > 0 ? ". " . "É stata conservata la sola prenotazione per notizia." : ""));
	}

	public function onManageCandidateItem($sender, $param)
	{
		$index = $sender->Parent->Parent->ItemIndex;
		$this->forceChecked($index);
		$this->getPage()->doManageRequests($param);
		$this->resetChecked(false);
	}

	public function onSubmit($sender, $param)
	{
		$this->globalRefresh();
	}

	public function onCleanFilter($sender, $param)
	{
		$this->doResetDataSource();
		$this->doCleanFilter(true);
	}

	public function doCleanFilter($globalRefreshFlag = true)
	{
		$this->SectionFilter->setSelectedIndex(-1);
		$this->CollocationFilter->setText('');
		$this->BarcodeInvFilter->setText('');

		$this->onResetPatron(null, null);

		$this->DeliveryLibraryFilter->setSelectedIndex(-1);
		
		if ($this->_llibraryActive)
			$this->MaxDistanceListFilter->setSelectedIndex(-1);

		if ($this->_requestTypeActive)
			$this->RequestTypeListFilter->setSelectedValue(ItemRequestPeer::REQUESTTYPE_NULLVALUESTRING);
			
		if ($globalRefreshFlag)
			$this->globalRefresh();
	}

	private function parseDataSource($ds = array())
	{
		$copy = array();
		foreach ($ds as $index => $row)
		{
			if ($index >= 0)
				$copy[] = $row;
		}

		return $copy;
	}	
	
	public function setFilters(	$requestDateFrom = null,
								$requestDateTo = null,
								$loanStatusFlag = false,
								$loanableSinceFlag = false,
								$resetPagination = true )
	{
		if ($requestDateFrom == '')
			$requestDateFrom = null;

		if ($requestDateTo == '')
			$requestDateTo = null;

		if (!TPropertyValue::ensureBoolean($loanStatusFlag))
			$loanStatusFlag = false;

		if (!TPropertyValue::ensureBoolean($loanableSinceFlag))
			$loanableSinceFlag = false;

		$this->setRequestDateFrom($requestDateFrom);
		$this->setRequestDateTo($requestDateTo);
		$this->setLoanStatusFlag($loanStatusFlag);
		$this->setLoanableSinceFlag($loanableSinceFlag);

		if ($resetPagination)
			$this->resetPagination();
	}

	public function onSelectActualLibrary($sender, $param)
	{
		$actualLibraryId = intval($this->getUser()->getActualLibraryId());

		if ($actualLibraryId > 0)
		{
			try
			{
				$this->DeliveryLibraryFilter->setSelectedValue($actualLibraryId);
			}
			catch (Exception $e)
			{
				// don't select
			}
		}
	}

	public function doPatronIdChanged($patronId, $param = null)
	{
 		$patron = null;
 		$patronId = intval($patronId);

		if ($patronId > 0)
 			$patron = PatronQuery::create()	->findPK($patronId);
 		
		if ($patron instanceof Patron)
 		{
 			$completeName = $patron->getCompleteName();
 			$barcode = trim($patron->getBarcode());
 			if ($barcode != '')
 				$barcode = ' (' . $barcode . ')';

 			$this->PatronLabel->setText($completeName . $barcode);
			$this->PatronHiddenValue->setValue($patronId);
			$this->setPatronChoiceDone(true, $param);
		}
	}

	/**
	 * It updates the page in case a new patron is choosen.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onPatronIdChanged($sender, $param)
	{
		$this->doPatronIdChanged($this->PatronHiddenValue->getValue(), $param);
	}

	/**
	 * It resets (also visually) the choice of patron.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onResetPatron($sender, $param)
	{
		$this->PatronHiddenLabel->setValue('');
		$this->PatronHiddenValue->setValue('');
		$this->PatronLabel->setText('');
		$this->setPatronChoiceDone(false, $param);
	}

	public function setPatronChoiceDone($flag, $param)
	{
		$this->PatronLabel->setVisible($flag);
		$this->PatronChoiceButton->setVisible(!$flag);
		$this->PatronResetButton->setVisible($flag);

		if ($this->getPage()->getIsCallback())
		{
			if (is_null($param))
			{
				$writer = $this->getPage()->createWriter();
			}
			else
			{
				$writer = $param->getNewWriter();
			}
			
			$this->PatronPanel->render($writer);
		}
	}
	
}