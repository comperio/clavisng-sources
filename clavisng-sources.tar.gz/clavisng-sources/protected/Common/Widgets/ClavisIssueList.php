<?php
/**
 * ClavisIssueList class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Ciro Mattia Gonano
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Modules.Authentication
 */

/**
 * ClavisIssueList Class
 *
 * @author Ciro Mattia Gonano
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.7
 * @package Widgets
 * @since 2.1
 */
class ClavisIssueList extends TTemplateControl 
{
	public	$_masterChecked;
	private $_checked = array('all' => false);
	private $_checkedSessionName;
	private $_datasource;
	private $_datasourceSessionName;

	private $_globalCriteria;
	private $_globalCriteriaSessionName;

	/**
	 *
	 * @var Manifestation
	 */
	protected $_manifestation;
	protected $_library;

	private function initVars()
	{
		$uniqueId = $this->getUniqueID();
		$this->_checkedSessionName = 'CheckedSessionName' . $uniqueId;
		$this->_datasourceSessionName = 'DataSourceSessionName' . $uniqueId;
		$this->_checked = $this->getChecked();
		$this->_masterChecked = $this->_checked['all'];
		$this->_globalCriteriaSessionName = 'GlobalCriteriaSessionName' . $uniqueId;
	}
	
	public function onInit($param)
	{
		parent::onInit($param);
		$this->initVars();
	}

	public function onLoad($param)
	{
		parent::onLoad($param);
		
		if (!$this->getPage()->getIsPostBack()
				&& !$this->getPage()->getIsCallBack())	// if first page cycle
		{
			$this->resetFilters();
			$this->resetDataSource();
		}
	}

	/**
	 * Setter method of object manifestation.
	 *
	 * @param Manifestation $manifestation
	 */
	public function setManifestation($manifestation)
	{
		$this->_manifestation = $manifestation;
		$this->setControlState('manifestation', $manifestation, null);
		$this->ManifestationFilterPanel->setVisible(false);
	}

	/**
	 * Setter method of object manifestation.
	 *
	 * @param Manifestation $manifestation
	 */
	public function setManifestationInternal($manifestation)
	{
		$this->_manifestation = $manifestation;
		$this->setControlState('manifestation', $manifestation, null);
	}

	/**
	 * Getter method of object manifestation.
	 *
	 * @return Manifestation
	 *
	 */
	public function getManifestation()
	{
		$this->_manifestation = $this->getControlState('manifestation', null);
		
		return $this->_manifestation;
	}

	public function setLibrary($library)
	{
		$this->_library = $library;
		$this->setControlState('library', $library, null);
	}

	public function getLibrary()
	{
		$this->_library = $this->getControlState('library', null);
		
		return $this->_library;
	}

	public function getIssueCount()
	{
		return $this->getControlState('issue_count', 0);
	}

	private function setIssueCount($issueCount)
	{
		$this->setControlState('issue_count', $issueCount, 0);
	}

	public function getMultiCheckEnabled()
	{
		return $this->getControlState('multi_check_enabled', false);
	}

	public function setMultiCheckEnabled($multiCheckEnabled)
	{
		$this->setControlState('multi_check_enabled', $multiCheckEnabled, false);
	}

	public function globalRefresh()
	{
		$this->populate();
	}

	public function populate()
	{
		$this->getManifestation();
		$this->populateYearFilter();
		$this->populateIssueGrid();
	}

	private function populateYearFilter(THtmlWriter $writer = null)
	{
		$selectedIndex = $this->YearFilter->getSelectedIndex();

		$q = IssueQuery::create()
				->setFormatter('PropelSimpleArrayFormatter')
				->select('IssueYear')
				->groupByIssueYear();
		
		if ($this->_manifestation instanceof Manifestation) 
		{
			$this->ManifestationFilterText->setText($this->_manifestation->getTitle());
			$this->ManifestationFilter->setValue($this->_manifestation->getManifestationId());
			$q->filterByManifestation($this->_manifestation);
		} 
		elseif (intval($this->ManifestationFilter->getValue()) > 0) 
		{
			$q->filterByManifestationId($this->ManifestationFilter->getValue());
		}

		$ids = $q->find()->toArray();
		rsort($ids,SORT_NUMERIC);

		if (count($ids) > 0)
			$ids = array_combine($ids, $ids);
		
		$year_ds = array(0 => '---') + $ids;
		
		$this->YearFilter->setDataSource($year_ds);
		$this->YearFilter->dataBind();
		
		$this->YearFilter->setSelectedIndex($selectedIndex);

		if ($this->getPage()->getIsCallback())
		{
			if ($writer instanceof THtmlWriter)
			{
				$this->YearFilter->render($writer);
			}
			else
			{
				$this->YearFilter->render($this->getPage()->createWriter());
			}
		}
	}

	public function resetSorting() 
	{
		$this->IssueGrid->resetSorting('default', null, false);
	}
	
	public function calculateSortingCriteria(IssueQuery &$query)
	{
		$sortingExpression = $this->IssueGrid->getSortingExpression();
		$sortingDirection = $this->IssueGrid->getSortingDirection();

		switch ($sortingExpression)
		{
			case 'title':  // Manifestation
				$query->useItemQuery()
						->orderByTitle($sortingDirection)
						->endUse();

				break;

			case 'number':
				$query->orderByIssueNumber($sortingDirection);

				break;

			case 'date':
				$query->orderByIssueDate($sortingDirection);

				break;

			case 'year':
			case 'startNumber':
				$query->orderByIssueYear($sortingDirection);

				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
				{
					$query->orderByStartNumber($sortingDirection);
				}
				else
				{
					$query->orderByEndNumber($sortingDirection)
								->orderByStartNumber($sortingDirection);
				}
				
				break;

			default:
				$sortingDirection = ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
													? TClavisDataGrid::SORTDIRECTION_DESC
													: TClavisDataGrid::SORTDIRECTION_ASC;
				
				if (!($this->_manifestation instanceof Manifestation))
					$query->orderByManifestationId($sortingDirection);
				
				$query->orderByIssueDate($sortingDirection)
							->orderByIssueYear($sortingDirection)
							->orderByEndNumber($sortingDirection)
							->orderByStartNumber($sortingDirection);
		}
	
		return $query;
	}
	
	private function populateIssueGrid()
	{
		$clavisLibrarian = $this->getUser();

		$pageSize = $this->IssueGrid->getPageSize();
		$currentIndexPage = $this->IssueGrid->getCurrentPage();

		$this->CheckCol->setVisible($this->getMultiCheckEnabled());
		$this->getChecked();

		$q = IssueQuery::create();

		if ($this->_manifestation instanceof Manifestation)
		{
			$this->TitleCol->setVisible(false);
			$q->filterByManifestation($this->_manifestation);
			
			if ($this->getPage()->isPopup())
			{
				$this->ManifestationTitle->setText($this->_manifestation->getCompleteTitle());
				$this->ManTitlePanel->setVisible(true);
			}
			else
			{
				$this->ManTitlePanel->setVisible(false);
			}
		}
		else
		{
			$this->TitleCol->setVisible(true);
			$this->ManTitlePanel->setVisible(false);
		}

		if ($this->YearFilter->getSelectedIndex() > 0)
			$q->filterByIssueYear($this->YearFilter->getSelectedValue());

		if ($this->TypeFilter->getSelectedIndex() > 0)
			$q->filterByIssueType($this->TypeFilter->getSelectedValue());

		if ($this->LibraryFilter->getChecked() == true)
		{
			$q->useItemQuery()
					->filterByHomeLibraryId($this->getUser()->getActualLibraryId())
					->endUse();
			
			$this->ItemsCount->setVisible(false);
		}
		else
		{
			$this->ItemsCount->setVisible(true);
		}
		
		$this->IssueGrid->resetSorting(	'startNumber',
										TClavisDataGrid::SORTDIRECTION_DESC,
										false);
		
		if ($this->getMultiCheckEnabled())
			$this->setGlobalCriteria(array(	'type' => 'normal',
											'body' => clone($q) ));

		$recCount = $q->count();
		$this->IssueGrid->setVirtualItemCount($recCount);
		$this->setIssueCount($recCount);
		$this->RecCounter->setText($recCount);

		$this->calculateSortingCriteria($q);
		
		if ($pageSize > 0)
			$q->limit($pageSize)
				->offset($currentIndexPage * $pageSize);

        $issues = $q->find();
        $data = array();

		/* @var $issue  Issue */
		foreach ($issues as $issue)
		{
			$p = array();
			
			$p['IssueNumber'] = $issue->getIssueNumber();
			$p['IssueCombo'] = $issue->getIssueCombo();
			$p['IssueNumbers'] = $issue->getStartNumber();

			if ($p['IssueNumbers'] != $issue->getEndNumber())
				$p['IssueNumbers'] .= '/'.$issue->getEndNumber();

			$p['IssueYear'] = $issue->getIssueYear();
			
			switch ($issue->getIssueType())
			{
				case IssuePeer::TYPE_SUPPLEMENT:
					$p['IssueNumber'] .= Prado::localize(' (supp.)');

					break;
			
				case IssuePeer::TYPE_WITHSUPPLEMENT:
					$p['IssueNumber'] .= Prado::localize(' (con supp.)');

					break;
			}
			
			$p['IssueDate'] = $issue->getIssueDate('U');
			$p['ManifestationTitle'] = '';

			if (! $this->_manifestation instanceof Manifestation)
			{
				$manifestation = ManifestationQuery::create()->findPk($issue->getManifestationId());

				if ($manifestation instanceof Manifestation)
					$p['ManifestationTitle'] = $manifestation->getTitle();
			}
			
			$p['IssueNote'] = $issue->getIssueNote();
			$p['CanEdit'] = $clavisLibrarian->getEditPermission($issue);

			$checkedIssue = false;
			$issueId = $issue->getIssueId();

			$checkedItem = (is_array($this->_checked) && array_key_exists($issueId, $this->_checked)) 
								? $this->_checked[$issueId] 
								: false;

			if ($this->_masterChecked)
				$checkedItem = !$checkedItem;

			$p['Checked'] = $checkedItem;
			
			$myItems = 0;
			$othersItems = 0;
			$c = new Criteria();

			$c->add(ItemPeer::ISSUE_ID, $issue->getIssueId());
			$c->add(	ItemPeer::HOME_LIBRARY_ID,
						$this->getUser()->getActualLibraryId());
			
			$c->addAnd(	ItemPeer::ITEM_STATUS,
						ItemPeer::getItemStatusVisible(),
						Criteria::IN);
			
			$myItems = ItemPeer::doCount($c);

			$c->clear();
			$c->add(ItemPeer::ISSUE_ID, $issue->getIssueId());
			$c->add(ItemPeer::HOME_LIBRARY_ID, $this->getUser()->getActualLibraryId(), Criteria::NOT_EQUAL);
			$c->addAnd(ItemPeer::ITEM_STATUS, ItemPeer::getItemStatusVisible(), Criteria::IN);
			$othersItems = ItemPeer::doCount($c);

			$p['ItemsCount'] = $myItems . '/' . $othersItems;
			$p['CanDelete'] = (($myItems + $othersItems) == 0);
			$p['Id'] = $issue->getIssueId();

			$data[] = $p;
		}
		
		$this->IssueGrid->setDataSource($data);
		$this->IssueGrid->dataBind();
		$this->setDataSource($data);
	}

	public function setManFilter($sender, $param)
	{
		$m = ManifestationQuery::create()->findPk($this->ManifestationFilter->getValue());
		
		if ($m instanceof Manifestation)
		{
			$this->setManifestationInternal($m);
			$this->populateYearFilter($param->getNewWriter());
		}
	}

	public function clearManFilter($sender, $param)
	{
		$this->ManifestationFilter->setValue('');
		$this->ManifestationFilterText->setText('');
		$this->setManifestationInternal(null);
		$this->searchIssue();
	}

	private function searchIssue() 
	{
		$this->resetChecked();
		$this->IssueGrid->setCurrentPage(0);
		$this->populate();
	}

	public function onSearchIssue($sender, $param)
	{
		$this->searchIssue();
	}
	
	public function onCancel()
	{
		$this->searchCancel(null, null);
	}

	public function searchCancel($sender, $param)
	{
		$this->resetFilters();
		$this->IssueGrid->setCurrentPage(0);
		
		$this->populate();
	}

	public function changePage($sender,$param) 
	{
		$this->IssueGrid->setCurrentPage($param->NewPageIndex);
		$this->globalRefresh();
	}

	public function getPopupFlag()
	{
		return $this->getPage()->IsPopup();
	}

	public function getUnlinkFlag()
	{
		return $this->getPage()->IsUnlink();
	}

	public function onEditIssue($sender, $param)
	{
		$issueId = $param->getCommandParameter();
		
		if ($issueId != null)
			$this->getPage()->gotoPageWithReturn('Catalog.IssueInsertPage', array('issueId' => $issueId));
	}

	public function setDatasource($datasource = null)
	{
		if ($datasource == null)
		{
			$datasource = $this->_datasource;
		}
		else
		{
			$this->_datasource = $datasource;
		}
		
		$this->getApplication()->getSession()->add(	$this->_datasourceSessionName,
													$datasource);
	}

	public function getDatasource()
	{
		$this->_datasource = $this->getApplication()->getSession()->itemAt($this->_datasourceSessionName);
		
		return $this->_datasource;
	}

	public function resetDataSource()
	{
		$this->resetChecked();
		$this->setDatasource(array());
				
		$this->populate();
	}

	private function resetFilters()
	{
		$this->ManifestationFilter->setValue(null);
		$this->ManifestationFilterText->setText("");
		
		$this->YearFilter->setSelectedIndex(0);	// was 1, for selecting latest year
		$this->TypeFilter->setSelectedIndex(0);
		
		$this->doResetInventoryDateFilter();
		
		$this->LibraryFilter->setChecked(false);
	}
	
	public function onResetInventoryDateFilter($sender, $param)
	{
		$this->doResetInventoryDateFilter($param);
	}
	
	private function doResetInventoryDateFilter($param = null)
	{
		$this->FilterDateTo->setText("");
 		$this->FilterDateFrom->setText("");

 		if ($this->getPage()->getIsCallBack())
 		{
 			if (is_null($param))
 			{
				$writer = $this->getPage()->createWriter();
			}
 			else
 			{
				$writer = $param->getNewWriter();
			}

 			$this->InventoryDateFilterPanel->render($writer);
 		}
	}
		
	public function onFlipChecked($sender, $param)
	{
		$checked = $this->getChecked();
		$index = $sender->Parent->Parent->ItemIndex;
		$newStatus = $sender->getChecked();
		$dataSource = $this->getDatasource();
		$row = $dataSource[$index];
		$issueId = $row['Id'];

		if ($newStatus != $checked['all'])
		{
			$checked[$issueId] = true;
		}
		else
		{
			unset($checked[$issueId]);
		}

		$this->setChecked($checked);
		$this->updateEmptyFlag($param);
	}

	public function onMasterChecked($sender, $param)
	{
		$this->setMasterChecked($sender->getChecked(), $param);
	}

	public function setMasterChecked($newChecked = false, $param = null)
	{
		$this->resetChecked($newChecked);
		$gridItems = $this->IssueGrid->getItems();
		$header = $this->IssueGrid->getHeader();
		
		foreach ($gridItems as $item)
			$item->CheckCol->CheckedBox->setChecked($newChecked);
		
		$header->CheckCol->MasterCheck->setChecked($newChecked);
		$this->updateEmptyFlag($param);
	}

	public function updateEmptyFlag($param = null)
	{
		$count = intval($this->countCheckedId());
		$this->SelectedNumber->setText($count);
		
		if (!is_null($param))
		{
			$this->SelectedPanel->render($param->getNewWriter());
		}
		else
		{
			$this->SelectedPanel->setCssClass(intval($this->SelectedNumber->getText()) > 0 
													? 'panel_on' 
													: 'panel_off');
		}
	}

	public function getCheckedId($force = false)
	{
		$checked = $this->getChecked();

		$this->_masterChecked = $checked['all'];
		unset($checked['all']);
		$checkedIds = array_keys($checked);
		$outputIds = array();

		if (!$this->_masterChecked) 
		{
			$outputIds = $checkedIds;
		} 
		else 
		{	// lo strano caso del mastercheck inverso
			$criteriaArray = $this->getGlobalCriteria();
		
			if (!is_null($criteriaArray)
					&& ($criteriaArray['type'] == 'normal'))
			{
				$criteria = $criteriaArray['body'];
				$issues = IssuePeer::doSelect($criteria);
				
				foreach ($issues as $issue)
					$outputIds[] = $issue->getIssueId();
				
				$outputIds = array_diff($outputIds, $checkedIds);
			}
		}
		
		return $outputIds;
	}

	public function countCheckedId($force = false)
	{
		$checked = $this->getChecked();
		$this->_masterChecked = $checked['all'];
		unset($checked['all']);

		$checkedIds = array_keys($checked);
		$countCheckedIds = count($checkedIds);
		
		if (!$this->_masterChecked)
		{
			$output = $countCheckedIds;
		} 
		else 
		{	// lo strano caso del mastercheck inverso
			$criteriaArray = $this->getGlobalCriteria();
	
			if (!is_null($criteriaArray)
					&& ($criteriaArray['type'] == 'normal'))
			{
				$criteria = $criteriaArray['body'];
				$countIssues = IssuePeer::doCount($criteria);
				$output = $countIssues - $countCheckedIds;
			}
		}
		
		return $output;
	}

	public function resetChecked($state = false)
	{
		$this->setChecked(array('all' => $state));
	}

	public function setChecked($checked = null)
	{
		$this->_checked = $checked;
		$this->getApplication()->getSession()->add(	$this->_checkedSessionName,
													$checked);
	}

	public function getChecked()
	{
		$this->_checked = $this->getApplication()->getSession()->itemAt($this->_checkedSessionName);
		
		return $this->_checked;
	}

	public function getMasterChecked()
	{
		$checked = $this->getChecked();
		
		return $checked['all'];
	}

	public function setGlobalCriteria($criteria = null)
	{
		$this->getApplication()->getSession()->add(	$this->_globalCriteriaSessionName,
													$criteria,
													null);
	}

	public function getGlobalCriteria()
	{
		$this->_globalCriteria = SerializableCriteria::refreshCriteria($this->getApplication()->getSession()->itemAt(	$this->_globalCriteriaSessionName,
																														null) );
		
		return $this->_globalCriteria;
	}

	public function onNewItem($sender, $param)
	{
		$this->getPage()->gotoPage(	'Catalog.ItemInsertPage',
									array('issueId' => $param->getCommandParameter()));
	}

	public function onDelete($sender, $param)
	{
		$id = $param->CommandParameter;
		$countDeleted = IssuePeer::doDelete($id);
		
		if ($countDeleted != 0)
		{
			$this->getPage()->writeMessage(Prado::localize('Fascicolo rimosso con successo (id = ') . $id,
											ClavisMessage::INFO);
			
			$this->populate();
		}
		else
		{
			$this->getPage()->writeMessage(Prado::localize('Errore nella rimozione fascicolo con id = ') . $id,
											ClavisMessage::ERROR);
			
			return;
		}
	}

	public function onAddToShelf($sender, $param)
	{
		//ini_set("memory_limit", "700M");
		//set_time_limit(0);
		$this->getPage()->cleanMessageQueue();
		
		$shelfId = intval($this->ShelfResultValue->getValue());
		$shelf = ShelfQuery::create()->findPK($shelfId);
		$this->ShelfResultValue->setValue('');
		
		if ($shelf instanceof Shelf)
		{
			$checkedId = $this->getCheckedId();
			$this->resetChecked();
			
			$ok = intval($shelf->addItemToShelf('issue', $checkedId));
			$failed = count($checkedId) - $ok;
			$shelf->save();
			
			$this->getPage()->enqueueMessage(Prado::localize("{ok} fascicoli aggiunti/aggiornati nello scaffale {shelf}",
																	array(	'ok' => $ok, 
																			'shelf' => $shelf->getShelfCompleteName() )),
												ClavisMessage::CONFIRM);
			
			if ($failed > 0)
			{
				$this->getPage()->enqueueMessage(Prado::localize("{failed} fascicoli non aggiunti allo scaffale {shelf} in conseguenza di errori",
																		array(	'failed' => $failed, 
																				'shelf' => $shelf->getShelfCompleteName() )),
													ClavisMessage::ERROR);
			}
		}
		else
		{
			$this->getPage()->enqueueMessage(Prado::localize("Lo scaffale scelto non risulta valido."), 
												ClavisMessage::ERROR);
		}
		
		$this->getPage()->globalRefresh();
		$this->getPage()->flushMessage();
	}
	
}