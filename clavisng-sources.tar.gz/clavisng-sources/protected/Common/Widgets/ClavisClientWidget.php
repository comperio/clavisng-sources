<?php

/**
 * ClavisClientWidget class
 *
 * @author Dario Rigolin <dario@comperio.it>
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2011 Comperio srl
 * @version 2.7
 * @package Widgets
 * @since 2.3
 */
class ClavisClientWidget extends TTemplateControl
{
	public $cchost = '127.0.0.1';
	public $ccport = '8080';
	
	private $tags = array();
	private $patrons = array();
	private $items = array();
	private $afiUpdate = array();
	private $itemId;
	private $printQueue = array();
	private $labelPrintQueue = array();

	public function onLoad($param) {
		parent::onLoad($param);
		if ($host = ClavisParamQuery::getParam('CLAVISPARAM','ClavisClientHost'))
			$this->cchost = $host;
		if ($port = ClavisParamQuery::getParam('CLAVISPARAM','ClavisClientPort'))
			$this->ccport = $port;
		
		if ($this->getPage()->getIsCallback()) {
			//$this->tags = $this->processTags($this->RFIDState->getValue());
		}
	}

	/**
	 * Registers the javascript code and publishes in the
	 * Prado assets directory.
	 *
	 * @param TEventParameter $param
	 */
	public function onPreRender($param)
	{
		parent::onPreRender($param);

		$scripts = $this->getPage()->getClientScript();
		if (!$scripts->isScriptFileRegistered('JSXMLSocket'))
			$scripts->registerScriptFile('JSXMLSocket',
				$this->publishFilePath(Prado::getPathOfNamespace('Application.Javascript').'/jsxmlsocket.js'));

		if (!$scripts->isScriptFileRegistered('JQuery'))
			$scripts->registerScriptFile('JQuery',
				$this->publishFilePath($this->getApplication()->getMode() == 'Debug'
					? Prado::getPathOfNamespace('Application.Javascript').'/jquery-1.8.3.js'
					: Prado::getPathOfNamespace('Application.Javascript').'/jquery-1.8.3.min.js'));
	}
	
	public function getItemId() {
		switch ($this->getUsage()) {
			case "patron":
				return $this->getPage()->getPatron()->getBarcode();
				break;
			case "item":
				return $this->getPage()->getItem()->getBarcode();
				break;
			case "Shelf":
				break;
			case "banco":
				return "";

				break;
		}
	}

	public function getUsage() {
		return $this->getViewState("usage", "banco");
	}

	public function setUsage($value) {
		$this->setViewState("usage", $value);
	}

	public function StateChange($sender, $param) {
		if ($this->getUsage() == "Reserve") {
			$this->getPage()->onImmediateLoan($sender, $param);
			$this->searchItems();
			$this->updateAFI();
		} else if ($this->getUsage() == "ReadyForLoan") {

            $this->getPage()->onLoan($sender, $param);

            $this->searchItems();
            $this->updateAFI();
        } else if ($this->getUsage() == "ILLIn") {
			if ($param->CallbackParameter->sourcePage == "ReadyForLoan") {
				$this->getPage()->onReadyForLoan($sender, $param);
			} else if ($param->CallbackParameter->sourcePage == "ToShelf") {
				$this->searchItems();
				//$this->updateAFI();
				foreach($this->items as $item)
				{
					$this->getPage()->PutToShelfBarcodeTextbox->setText($item->getBarcode());
					$this->getPage()->onPutToShelf($sender, $param);
				}

			}
			$this->searchItems();
			$this->updateAFI();
		} else if ($this->getUsage() == "ILLOut") {
			$this->getPage()->onTransit($sender, $param);
			$this->searchItems();
			$this->updateAFI();
		} else if ($this->getUsage() == "banco") {

			$this->searchPatron();
			$this->searchItems();

			$this->updateAFI();


			$this->getPage()->cleanPatron();
			$this->getPage()->cleanItems(NewLoan::INPUT_SOURCE_RFID);
			

			if (count($this->patrons) > 1) {
				$this->getPage()->writeMessage(Prado::localize("Più di una tessera utente"), ClavisMessage::WARNING);
			} elseif (count($this->patrons) == 1) {
				$this->getPage()->insertPatron($this->patrons[0], NewLoan::INPUT_SOURCE_RFID);
			}
			
			/* $var $item Item */

			$this->MsgStatus->setText(count($this->items));

			foreach ($this->items as $item) {
				// lost check
				$returnMessage = $this->getApplication()->getModule('loan')->putLostToAvailableItem($item->getItemId());
				if (count($returnMessage) > 0)
					$this->getPage()->writeMessage($returnMessage[0], $returnMessage[1]);
				$this->getPage()->addItem($item, NewLoan::INPUT_SOURCE_RFID);
			}


			$this->getPage()->globalRefresh($param);
			$this->getPage()->drawPanels();  ////
		} else if($this->getUsage() == "Shelf") {
			
			$this->searchItems();
			//$this->updateAFI();
			if(count($this->items) > 0)
				$this->NamingContainer->addItemsToShelf($this->items,$param);
		}
	}

	public function searchPatron() {
		$pat1 = explode(",", $this->RFIDPatrons->getValue());
		foreach ($pat1 as $pat) {
			if (trim($pat) != "") {
				list($eid, $barcode) = explode("|", $pat);

				// $this->Msg1->setText( $this->Msg1->getText() . "$pat [$eid  $barcode]");

				$c = new Criteria();
				$c->add(PatronPeer::BARCODE, $barcode);
				$patron = PatronPeer::doSelectOne($c);
				if ($patron != null) {
					$this->patrons[] = $patron;
					if ($patron->getRfidCode() != $eid) {
						$patron->setRfidCode($eid);
						$patron->save();
					}
				}
			}
		}
	}

	public function searchItems() {
		$ite1 = explode(",", $this->RFIDItems->getValue());
		foreach ($ite1 as $ite) {
			if (trim($ite) != "") {
				list($eid, $barcode) = explode("|", $ite);

				// $this->Msg1->setText( $this->Msg1->getText() . "$pat [$eid  $barcode]");

				$c = new Criteria();
				$c->add(ItemPeer::BARCODE, $barcode);
				$item = ItemPeer::doSelectOne($c);
				if ($item instanceof Item) {
					if ($item->getRfidCode() != $eid) {
						$item->setRfidCode($eid);
						$item->save();
						//$this->Msg1->setText( "SAVE item $barcode $eid");
					}
					$this->items[] = $item;
				}
			}
		}
	}

	public function updateAFI() {
		$scriptMgr = $this->getPage()->getClientScript();

		$checkOutXML = "<request command=\"checkout\" reader=\"0\" offline=\"false\" >";
		$checkInXML = "<request command=\"checkin\" reader=\"0\" offline=\"false\" >";

		foreach ($this->items as $item) {
			$eid = $item->getRfidCode();
			/* @var $item Item */
			if (($item->getCurrentLoanId() != null) &&
                ($item->getCurrentLoan()->getLoanType() != ItemPeer::LOANTYPE_CONSULTATION ||
                    $item->getLoanStatus() != ItemPeer::LOANSTATUS_READYFORLOAN
                )
            ) {
				$checkOutXML .= "<tag eid=\"" . $eid . "\" patronid=\"1892321\" itemid=\"AB7777\" />";
			} else {
				$checkInXML .= "<tag eid=\"" . $eid . "\" patronid=\"1892321\" itemid=\"AB7777\"  />";
			}
		}
		$checkOutXML .= "</request>";
		$checkInXML .= "</request>";

		$scriptMgr->registerEndScript("checkOut", "clavisClientSend('$checkOutXML');");
		$scriptMgr->registerEndScript("checkIn", "clavisClientSend('$checkInXML');");
	}
	
	public function printLoanLabel($template,$loan_id)
	{
		$loan = LoanQuery::create()->findPk($loan_id);
		if (!$loan instanceof Loan)
			return;
		$vars = '';
		foreach ($this->getVarsForLoan($loan) as $k => $v)
			$vars .= " {$k}=\"".htmlspecialchars(mb_convert_encoding($v, 'ASCII', 'UTF-8'),ENT_QUOTES,'UTF-8',false).'"';
		foreach ($this->getVarsForItem($loan->getItem()) as $k => $v)
			$vars .= " {$k}=\"".htmlspecialchars(mb_convert_encoding($v, 'ASCII', 'UTF-8'),ENT_QUOTES,'UTF-8',false).'"';

        if($loan->getPatron() instanceof Patron)
            foreach ($this->getVarsForPatron($loan->getPatron()) as $k => $v)
                $vars .= " {$k}=\"".htmlspecialchars(mb_convert_encoding($v, 'ASCII', 'UTF-8'),ENT_QUOTES,'UTF-8',false).'"';

		if (!array_key_exists($template, $this->printQueue))
			$this->printQueue[$template] = array();
		$this->printQueue[$template][] = $vars;
	}

	public function printItemRequestLabel($template,$itemrequest_id)
	{
		$ir = ItemRequestQuery::create()->findPk($itemrequest_id);
		if (!$ir instanceof Loan)
			return;
		$vars = '';
		foreach ($this->getVarsForPatron($ir->getPatron()) as $k => $v)
			$vars .= " {$k}=\"".htmlspecialchars(mb_convert_encoding($v, 'ASCII', 'UTF-8'),ENT_QUOTES,'UTF-8',false).'"';
		foreach ($this->getVarsForItem($ir->getItem()) as $k => $v)
			$vars .= " {$k}=\"".htmlspecialchars(mb_convert_encoding($v, 'ASCII', 'UTF-8'),ENT_QUOTES,'UTF-8',false).'"';

		if (!array_key_exists($template, $this->printQueue))
			$this->printQueue[$template] = array();
		$this->printQueue[$template][] = $vars;
	}

	public function printItemLabel($template,$loan_id)
	{
		$loan = LoanQuery::create()->findPk($loan_id);
		if (!$loan instanceof Loan)
			return;
		$vars = '';
		foreach ($this->getVarsForLoan($loan) as $k => $v)
			$vars .= " {$k}=\"".htmlspecialchars(mb_convert_encoding($v, 'ASCII', 'UTF-8'),ENT_QUOTES,'UTF-8',false).'"';
		foreach ($this->getVarsForItem($loan->getItem()) as $k => $v)
			$vars .= " {$k}=\"".htmlspecialchars(mb_convert_encoding($v, 'ASCII', 'UTF-8'),ENT_QUOTES,'UTF-8',false).'"';

		if($loan->getPatron() instanceof Patron)
			foreach ($this->getVarsForPatron($loan->getPatron()) as $k => $v)
				$vars .= " {$k}=\"".htmlspecialchars(mb_convert_encoding($v, 'ASCII', 'UTF-8'),ENT_QUOTES,'UTF-8',false).'"';

		if (!array_key_exists($template, $this->labelprintQueue))
			$this->labelPrintQueue[$template] = array();
		$this->labelPrintQueue[$template][] = $vars;
	}
	
	public function getJSPrintQueue() {
		$ret = '';
		foreach ($this->printQueue as $tpl => $vars)
			foreach ($vars as $var)
				$ret .= "\n\tsendPrintRequest('receipt','{$tpl}','{$var}');";
		foreach ($this->labelPrintQueue as $tpl => $vars)
			foreach ($vars as $var)
				$ret .= "\n\tsendPrintRequest('label','{$tpl}','{$var}');";
		return $ret;
	}

	/**
	 * Compiles placeholders for Loan object.
	 *
	 * @param Loan $loan The loan's id
	 * @return array The loan object
	 * @throws Exception if supplied ID is not valid
	 */
	protected function getVarsForLoan(Loan $loan) {
		$lib = $loan->getLibraryRelatedByToLibrary();
		return array(
			'LOAN_START'	=> $loan->getLoanDateBegin('%d/%m/%Y'),
			'LOAN_END'		=> $loan->getLoanDateEnd('%d/%m/%Y'),
			'LOAN_DUE'		=> $loan->getDueDate('%d/%m/%Y'),
			'LOAN_LIBRARY'	=> $lib->getLabel(),
			'LOAN_PHONE'	=> strval($lib->getPhone()));
	}

	/**
	 * Compiles placeholders for Item object.
	 *
	 * @param Item $itemId The item's id
	 * @return array The item object
	 * @throws Exception if supplied ID is not valid
	 */
	protected function getVarsForItem(Item $item) {
		$manifestation = $item->getManifestation();
		$vars = array();
		$vars['TITLE'] = str_replace('"','\'',$item->getTitle());
		if ($manifestation instanceof Manifestation) {
			$vars['AUTHOR'] = $manifestation->getAuthor();
			$vars['SERIE'] = implode('; ',$manifestation->getTurboMarc()->getSeries());
		} else {
			$vars['AUTHOR'] = '';
			$vars['SERIE'] = '';
		}
		$vars['LIBRARY'] = LibraryPeer::getLibraryLabel($item->getOwnerLibraryId());
		$vars['INVSERIE'] = $item->getInventorySerieId();
		$vars['INVNUMBER'] = $item->getInventoryNumber();
		$vars['INVENTORY'] = $item->getInventorySerieId().'-'.$item->getInventoryNumber();
		$vars['SECTION'] = $item->getSection();
		$vars['COLLOCATION'] = $item->getCollocation();
		$vars['SPECIFICATION'] = $item->getSpecification();
		$vars['SEQUENCEONE'] = $item->getSequence1();
		$vars['SEQUENCETWO'] = $item->getSequence2();
		$vars['SPECSEQ'] = trim($vars['SPECIFICATION'].' - '.$vars['SEQUENCEONE'],' -');
		$vars['BARCODE'] = $item->getBarcode();
		return $vars;
	}

	/**
	 * Compiles placeholders for Patron object.
	 *
	 * @param Patron $patronId The patron's id
	 * @return array The patron object
	 * @throws Exception if supplied ID is not valid
	 */
	protected function getVarsForPatron(Patron $patron)
	{
		$vars['USER_NAME'] = $patron->getCompleteName();
		$vars['USER_BARCODE'] = $patron->getBarcode();
		$vars['USER_CARDCODE'] = $patron->getCardCode();
		$user_mail = $patron->getEmail();
		$vars['USER_MAIL'] = (count($user_mail)>0)?$user_mail[0]:'';
		$user_phone = $patron->getPhone();
		$vars['USER_PHONE'] = (count($user_phone)>0)?$user_phone[0]:'';
		return $vars;
	}
}
