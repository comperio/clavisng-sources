<?php
/**
 * ClavisInventorySerieList class file
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 */

/**
 * ClavisInventorySerieList Class
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2008 ePortal Technologies
 * @copyright Copyright &copy; 2017 Comperio srl
 * @version 2.7
 * @package Widgets
 * @since 2.1
 */
class ClavisInventorySerieList extends TTemplateControl
{
	/**
	 * It populates the datagrid.
	 *
	 * @param TEventParameter $param
	 */
	public function onLoad($param)
	{
		parent::onLoad($param);
		
		if (!$this->getPage()->getIsPostBack() 
				&& !$this->getPage()->getIsCallBack())
		{

			$libraries = LibraryPeer::getLibrariesHashWithBlank(false, true);
			$this->LibraryFilter->setDataSource($libraries);
			$this->LibraryFilter->dataBind();

			$this->populate();
		}
	}

	/**
	 * Cleans the search textboxes and re-populates.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onClearSearch()
	{
		$this->searchCancel(null, null);
	}

	public function searchCancel($sender, $param)
	{
		$this->LibraryFilter->setSelectedIndex(-1);
		
		$this->populate();
	}
	
	public function populate()
	{
		$this->populateInvSerieGridGrid();
	}

	private function populateInvSerieGridGrid()
	{
		$pageSize = $this->InvSerieGrid->getPageSize();
		$currentIndexPage = $this->InvSerieGrid->getCurrentPage();

		$criteria = new Criteria();
		$libraryFilter = $this->LibraryFilter->getSelectedValue();

		if ($libraryFilter)
			$criteria->addAnd(InventorySeriePeer::LIBRARY_ID, $libraryFilter);

		$recCount = InventorySeriePeer::doCount($criteria);
		$this->InvSerieGrid->setVirtualItemCount($recCount);
		$this->RecCounter->setText(Prado::localize("Record totali: {recCount}", array('recCount' => $recCount)));

		$criteria->addAscendingOrderByColumn(InventorySeriePeer::CLOSED);
		$criteria->addAscendingOrderByColumn(InventorySeriePeer::READONLY);
		$criteria->addAscendingOrderByColumn(InventorySeriePeer::LIBRARY_ID);
		$criteria->addAscendingOrderByColumn(InventorySeriePeer::CLOSED);
		$criteria->addAscendingOrderByColumn(InventorySeriePeer::READONLY);
		$criteria->setLimit($pageSize);
		$criteria->setOffset($currentIndexPage * $pageSize);

		$invSeries = InventorySeriePeer::doSelect($criteria);

		$data = array();
		
		/* @var $invSerie  InventorySerie */
		foreach ($invSeries as $invSerie)
		{
			$p = array();
			$p['Key'] = serialize($invSerie->getPrimaryKey());
			$p['InvSerieId'] = $invSerie->getInventorySerieId();
			$p['InventoryCounter'] = $invSerie->getInventoryCounter();
			$library = LibraryQuery::create()->findPk($invSerie->getLibraryId());
			
			if ($library instanceof Library)
			{
				$p['Library'] = $library->getLabel();
			}
			else
			{
				$p['Library'] = '';
			}
			
			$p['Description'] = $invSerie->getDescription();
			$p['LibraryId'] = $invSerie->getLibraryId();
			$p['CanEdit'] = $this->getUser()->getEditPermission($invSerie);
			
			$currLibCrit = new Criteria();
			
			if ($libraryFilter
					&& ($libraryFilter == $this->getUser()->getActualLibraryId()))
				$currLibCrit->addAnd(ItemPeer::OWNER_LIBRARY_ID, $libraryFilter);
			
			$p['CanDelete'] = $p['CanEdit'] 
								&& ('' == $invSerie->getInventorySerieId() 
										|| $invSerie->countItems($currLibCrit) < 1);
			$data[] = $p;
		}
		
		$this->InvSerieGrid->setDataSource($data);
		$this->InvSerieGrid->dataBind();
	}

	public function onSearchInvSerie($sender, $param)
	{
		$this->InvSerieGrid->CurrentPageIndex = 0;
		$this->setViewState("CurrentPage", 0);
		$this->populate();

		$this->getPage()->globalRefresh();
	}

	public function onDelete($sender, $param)
	{
		$pk = unserialize($param->getCommandParameter());
		$is = InventorySerieQuery::create()->findPk($pk);
		if ($is instanceof InventorySerie)
		{
			try
			{
				$is->delete();
				$this->getPage()->writeMessage(Prado::localize("Serie cancellata correttamente."), ClavisMessage::CONFIRM);
			}
			catch (Exception $e)
			{
				$this->getPage()->writeMessage(Prado::localize("La serie non è stata cancellata a causa dell'errore: {error}", 
																	array('error' => $e->getMessage())), 
													ClavisMessage::ERROR);
			}
		}
		
		$this->getPage()->globalRefresh();
	}

	public function onCancel()
	{
		$this->searchCancel(null, null);
	}

	public function changePage($sender, $param)
	{
		$this->InvSerieGrid->setCurrentPage($param->NewPageIndex);

		$this->getPage()->globalRefresh();
	}

	public function getPopupFlag()
	{
		return $this->getPage()->IsPopup();
	}

	public function getUnlinkFlag()
	{
		return $this->getPage()->IsUnlink();
	}

	public function globalRefresh()
	{
		$this->populate();
	}
	
}