<?php
/**
 * ClavisAddressList
 *
 * @author Max Pigozzi <mpigozzi@e-portaltech.it>
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.e-portaltech.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @license http://www.e-portaltech.it/license/
 *
 */
class ClavisAddressList extends TTemplateControl
{
	private $_datasource;
	private $_datasourceSessionName;
	private $_globalCriteriaSessionName;
	private $_checked;
	private $_checkedSessionName;

	private function initVars()
	{
		$uniqueId = $this->getUniqueID();
		$this->_datasourceSessionName = "DatasourceSessionName" . $uniqueId;
		$this->_globalCriteriaSessionName = "GlobalCriteriaSessionName" . $uniqueId;
		$this->_checkedSessionName = "CheckedSessionName" . $uniqueId;
	}

	public function onInit($param)
	{
		parent::onInit($param);
		$this->initVars();
	}

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallBack())
		{
			$populateFlag = false;
			$this->resetDataSource($populateFlag);
		}

		$this->_checked = $this->getChecked();
	}

	public function setAddressType($val)
	{
		$this->setViewState('AddressType', $val, '');
	}

	public function getAddressType()
	{
		return TPropertyValue::ensureString($this->getViewState('AddressType', ''));
	}

	public function setAddrStreetType($val)
	{
		$this->setViewState('AddrStreetType', $val, '');
	}

	public function getAddrStreetType()
	{
		return TPropertyValue::ensureString($this->getViewState('AddrStreetType', ''));
	}

	public function setAddrStreet($val)
	{
		$this->setViewState('AddrStreet', $val, '');
	}

	public function getAddrStreet()
	{
		return TPropertyValue::ensureString($this->getViewState('AddrStreet', ''));
	}

	public function setAddrStreetNumber($val)
	{
		$this->setViewState('AddrStreetNumber', $val, '');
	}

	public function getAddrStreetNumber()
	{
		return TPropertyValue::ensureString($this->getViewState('AddrStreetNumber', ''));
	}

	public function setAddrVillage($val)
	{
		$this->setViewState('AddrVillage', $val, '');
	}

	public function getAddrVillage()
	{
		return TPropertyValue::ensureString($this->getViewState('AddrVillage', ''));
	}

	public function setAddrZip($val)
	{
		$this->setViewState('AddrZip', $val, '');
	}

	public function getAddrZip()
	{
		return TPropertyValue::ensureString($this->getViewState('AddrZip', ''));
	}

	public function setAddrCity($val)
	{
		$this->setViewState('AddrCity', $val, '');
	}

	public function getAddrCity()
	{
		return TPropertyValue::ensureString($this->getViewState('AddrCity', ''));
	}

	public function setAddrProvince($val)
	{
		$this->setViewState('AddrProvince', $val, '');
	}

	public function getAddrProvince()
	{
		return TPropertyValue::ensureString($this->getViewState('AddrProvince', ''));
	}

	public function setAddrCountry($val)
	{
		$this->setViewState('AddrCountry', $val, '');
	}

	public function getAddrCountry()
	{
		return TPropertyValue::ensureString($this->getViewState('AddrCountry', ''));
	}

	public function setAddrNote($val)
	{
		$this->setViewState('AddrNote', $val, '');
	}

	public function getAddrNote()
	{
		return TPropertyValue::ensureString($this->getViewState('AddrNote', ''));
	}

	public function setAddrPref($val)
	{
		$this->setViewState('AddrPref', $val, false);
	}

	public function getAddrPref()
	{
		return TPropertyValue::ensureBoolean($this->getViewState('AddrPref', false));
	}

	public function setPatronId($val)
	{
		$this->setViewState('PatronId', $val, 0);
	}

	public function getPatronId()
	{
		return intval($this->getViewState('PatronId', 0));
	}

	public function setEnablePagination($enablePagination = 'true')
	{
		$this->setViewState("EnablePagination", $enablePagination, 'true');
	}

	public function getEnablePagination()
	{
		$flag = $this->getViewState("EnablePagination", 'true');
		switch ($flag)
		{
			case 'true':
				$enablePagination = true;
				break;

			case 'false':
				$enablePagination = false;
				break;

			default:
				$enablePagination = true;
		}
		return $enablePagination;
	}

	private function resetGlobalCriteria()
	{
		$this->setGlobalCriteria(null);
	}

	public function setGlobalCriteria($criteria = null)
	{
		$this->getApplication()->getSession()->add($this->_globalCriteriaSessionName, $criteria, null);
	}

	public function getGlobalCriteria()
	{
		return SerializableCriteria::refreshCriteria(
						$this->getApplication()->getSession()->itemAt($this->_globalCriteriaSessionName, null));
	}

	public function resetDataSource($populateFlag = true, $resetPagination = true)
	{
		if ($resetPagination)
			$this->resetPagination();

		$this->resetCheckedItems();
		$this->resetGlobalCriteria();
		$this->setDataSource(array());
		$this->resetSorting(true);

		if ($populateFlag)
			$this->populate();
	}

	public function getDatasource()
	{
		$this->_datasource = $this->getApplication()->getSession()->itemAt($this->_datasourceSessionName, null);
		return $this->_datasource;
	}

	public function setDataSource($ds)
	{
		$this->_datasource = $ds;
		$this->getApplication()->getSession()->add($this->_datasourceSessionName, $this->_datasource, null);
	}

	public function searchAddress($sender, $param)
	{
		$this->Grid->setCurrentPage(0);
		$this->resetDataSource();
	}

	public function setFilters($addressType = '', $addrStreetType = '', $addrStreet = '', $addrStreetNumber = '', $addrVillage = '', $addrZip = '', $addrCity = '', $addrProvince = '', $addrCountry = '', $addrNote = '', $addrPref = false, $patronId = 0)
	{
		$this->setAddressType($addressType);
		$this->setAddrStreetType($addrStreetType);
		$this->setAddrStreet($addrStreet);
		$this->setAddrStreetNumber($addrStreetNumber);
		$this->setAddrVillage($addrVillage);
		$this->setAddrZip($addrZip);
		$this->setAddrCity($addrCity);
		$this->setAddrProvince($addrProvince);
		$this->setAddrCountry($addrCountry);
		$this->setAddrNote($addrNote);
		$this->setAddrPref($addrPref);
		$this->setPatronId($patronId);
	}

	public function calculateSortingCriteria(&$sortingCriteria = null)
	{
		$sortingExpression = $this->Grid->getSortingExpression();
		$sortingDirection = $this->Grid->getSortingDirection();

		if (is_null($sortingCriteria) || !($sortingCriteria instanceof Criteria))
			$sortingCriteria = new Criteria();

		switch ($sortingExpression)
		{
			case 'AddressType':
				$sortingCriteria->clearOrderByColumns();
				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
					$sortingCriteria->addAscendingOrderByColumn(AddressPeer::ADDRESS_TYPE);
				elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
					$sortingCriteria->addDescendingOrderByColumn(AddressPeer::ADDRESS_TYPE);

				break;

			case 'Zip':
				$sortingCriteria->clearOrderByColumns();
				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
					$sortingCriteria->addAscendingOrderByColumn(AddressPeer::ZIP);
				elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
					$sortingCriteria->addDescendingOrderByColumn(AddressPeer::ZIP);

				break;

			case 'Address':
				$sortingCriteria->clearOrderByColumns();
				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
				{
					$sortingCriteria->addAscendingOrderByColumn(AddressPeer::STREET);
					$sortingCriteria->addAscendingOrderByColumn(AddressPeer::STREET_NUM);
				}
				elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
				{
					$sortingCriteria->addDescendingOrderByColumn(AddressPeer::STREET);
					$sortingCriteria->addDescendingOrderByColumn(AddressPeer::STREET_NUM);
				}

				break;

			case 'City':
				$sortingCriteria->clearOrderByColumns();
				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
					$sortingCriteria->addAscendingOrderByColumn(AddressPeer::CITY);
				elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
					$sortingCriteria->addDescendingOrderByColumn(AddressPeer::CITY);

				break;

			case 'Province':
				$sortingCriteria->clearOrderByColumns();
				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
				{
					$sortingCriteria->addAscendingOrderByColumn(AddressPeer::PROVINCE);
				}
				elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
				{
					$sortingCriteria->addDescendingOrderByColumn(AddressPeer::PROVINCE);
				}
				break;

			case 'Country':
				$sortingCriteria->clearOrderByColumns();
				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
					$sortingCriteria->addAscendingOrderByColumn(AddressPeer::COUNTRY);
				elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
					$sortingCriteria->addDescendingOrderByColumn(AddressPeer::COUNTRY);

				break;

			case 'Patron':
				$sortingCriteria->clearOrderByColumns();
				$sortingCriteria->addJoin(AddressPeer::PATRON_ID, PatronPeer::PATRON_ID, 'INNER JOIN');
				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
				{
					$sortingCriteria->addAscendingOrderByColumn(PatronPeer::LASTNAME);
					$sortingCriteria->addAscendingOrderByColumn(PatronPeer::NAME);
				}
				elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
				{
					$sortingCriteria->addDescendingOrderByColumn(PatronPeer::LASTNAME);
					$sortingCriteria->addDescendingOrderByColumn(PatronPeer::NAME);
				}

				break;

			case null:
				break;

			default:
				$sortingExpression = null;

				break;
		}
	}

	private function resetSorting($force = false)
	{
		$this->Grid->resetSorting('City', TClavisDataGrid::SORTDIRECTION_ASC, $force);
	}

	public function populate()
	{
		/** @var $c Criteria */
		$clavisLibrarian = $this->getUser();
		$pageSize = $this->Grid->getPageSize();
		$currentPage = $this->Grid->getCurrentPage();
		$addressItems = array();
		$criteria = new Criteria();

		$addressType = $this->getAddressType();
		if ($addressType != "")
			$criteria->addAnd(AddressPeer::ADDRESS_TYPE, $addressType);

		$streetType = $this->getAddrStreetType();
		if ($streetType != '')
			$criteria->addAnd(AddressPeer::STREET_TYPE, $streetType);

		$street = $this->getAddrStreet();
		if ($street != '')
			$criteria->addAnd(AddressPeer::STREET, $street . "%", Criteria::LIKE);

		$streetNum = $this->getAddrStreetNumber();
		if ($streetNum != '')
			$criteria->addAnd(AddressPeer::STREET_NUM, $streetNum);

		$village = $this->getAddrVillage();
		if ($village != '')
			$criteria->addAnd(AddressPeer::VILLAGE, $village . "%", Criteria::LIKE);

		$zip = $this->getAddrZip();
		if ($zip != '')
			$criteria->addAnd(AddressPeer::ZIP, $zip);

		$prefer = $this->getAddrPref();

		if ($prefer == true)
			$criteria->addAnd(AddressPeer::ADDRESS_PREF, "1");

		$city = $this->getAddrCity();
		if ($city != '')
			$criteria->addAnd(AddressPeer::CITY, $city . "%", Criteria::LIKE);

		$province = $this->getAddrProvince();
		if ($province != '')
			$criteria->addAnd(AddressPeer::PROVINCE, $province . "%", Criteria::LIKE);

		$country = $this->getAddrCountry();
		if ($country != '')
			$criteria->addAnd(AddressPeer::COUNTRY, $country . "%", Criteria::LIKE);

		$note = $this->getAddrNote();
		if ($note != '')
			$criteria->addAnd(AddressPeer::ADDRESS_NOTE, "%" . $note . "%", Criteria::LIKE);

		$patronId = $this->getPatronId();
		if ($patronId > 0)
			$criteria->addAnd(AddressPeer::PATRON_ID, $patronId);

		//$this->Grid->resetSorting('Address', null, false);
		$this->resetSorting();
		$this->calculateSortingCriteria($criteria);
		$this->setGlobalCriteria(clone($criteria));

		if (count($criteria->getMap()) > 0)
		{
			$recCount = AddressPeer::doCount($criteria);

			$criteria->setLimit($pageSize);
			$criteria->setOffset($currentPage * $pageSize);
			$addresses = AddressPeer::doSelect($criteria);
		}
		else
		{
			$addresses = array();
			$recCount = 0;
		}

		$data = array();
		foreach ($addresses as $index => $address)
		{
			/* @var $address Address */

			$row = array();
			$addressId = $address->getAddressId();

			$addressType = LookupValuePeer::getLookupValue("ADDRESSTYPE", $address->getAddressType());
			if ($address->getAddressPref() == "1")
				$addressType .= " <span style = 'font-size: x-small; color: green;'>[" . Prado::localize('pref') . "]</span>";
			$row['AddressType'] = $addressType;

			$row['Zip'] = $address->getZip();

			$addressString = '';
			$street = TPropertyValue::ensureString($address->getStreet());
			if ($street != '')
			{
				$streetType = TPropertyValue::ensureString($address->getStreetType());
				if ($streetType != '')
					$addressString .= LookupValuePeer::getLookupValue("STREET", $streetType) . ' ';

				$addressString .= $street;

				$streetNum = TPropertyValue::ensureString($address->getStreetNum());
				if ($streetNum != '')
					$addressString .= ', ' . $streetNum;
			}
			$row['Address'] = $addressString;

			$cityString = '';
			$city = TPropertyValue::ensureString($address->getCity());
			if ($city != '')
				$cityString .= $city;

			$village = TPropertyValue::ensureString($address->getVillage());
			if ($village != '')
			{
				$village = Prado::localize('fraz: ') . $village;
				if ($cityString != '')
					$cityString .= ' (' . $village . ')';
				else
					$cityString = $village;
			}
			$row['City'] = $cityString;

			$row['Province'] = $address->getProvince();

			$row['Country'] = $address->getCountry();

			$patron = $address->getPatron();
			if (!is_null($patron))
			{
				$patronCompleteName = $patron->getCompleteName();
				$patronNavigateUrl = "index.php?page=" . $patron->getShelfUrl() . $patron->getPatronId();

				$canView = $clavisLibrarian->getViewPermission($patron);
				$canEdit = $clavisLibrarian->getEditPermission($patron);
			}
			else
			{
				$patronCompleteName = '';
				$patronNavigateUrl = '';

				$canView = false;
				$canEdit = false;
			}
			$row['PatronCompleteName'] = $patronCompleteName;
			$row['PatronNavigateUrl'] = $patronNavigateUrl;

			$row['Notes'] = TPropertyValue::ensureString($address->getAddressNote());

			$row['CanView'] = $canView;
			$row['CanEdit'] = $canEdit;

			$row['AddressId'] = $addressId;

			if (isset($this->_checked[$addressId]))
				$checked = $this->_checked[$addressId];
			else
				$checked = false;
			if ($this->_checked['all'])
				$checked = !$checked;
			$row['checked'] = $checked;

			$data[] = $row;
		}

		$this->setChecked($this->_checked);
		$this->Grid->setVirtualItemCount($recCount);
		$this->Grid->setDataSource($data);
		$this->Grid->dataBind();
		$this->FoundNumber->setText($recCount);
		$this->setDataSource($data);
	}

	public function changePage($sender, $param)
	{
		$this->Grid->setCurrentPage($param->NewPageIndex);
		$this->populate();
	}

	public function getPopupFlag()
	{
		return $this->getPage()->IsPopup();
	}

	public function globalRefresh()
	{
		$this->resetSorting();
		$this->populate();
	}

	public function cleanSearch()
	{
		$this->onCleanSearch(null, null);
	}

	public function onCleanSearch($sender, $param)
	{
		$this->clearFilters();
		$this->resetDataSource();
	}

	private function resetPagination()
	{
		$this->Grid->setCurrentPage(0);
	}

	public function resetCheckedItems($state = false)
	{
		$this->setChecked(array('all' => $state));
	}

	public function setChecked($checked = null)
	{
		$this->_checked = $checked;
		$this->getApplication()->getSession()->add($this->_checkedSessionName, $checked);
	}

	public function getChecked()
	{
		$this->_checked = $this->getApplication()->getSession()->itemAt($this->_checkedSessionName);
		return $this->_checked;
	}

	public function onFlipChecked($sender, $param)
	{
		$checked = $this->getChecked();
		$newStatus = $sender->getChecked();

		$index = $sender->Parent->Parent->ItemIndex;
		$dataSource = $this->getDatasource();

		$row = $dataSource[$index];
		$itemId = $row['AddressId'];

		if ($newStatus != $checked['all'])
			$checked[$itemId] = true;
		else
			unset($checked[$itemId]);

		$this->setChecked($checked);
	}

	public function onMasterChecked($sender, $param)
	{
		$newStatus = $sender->getChecked();
		$this->resetCheckedItems($newStatus);

		$gridItems = $this->Grid->getItems();
		foreach ($gridItems as $item)
			$item->CheckColumn->Checked->setChecked($newStatus);
	}

	public function setMasterChecked($newChecked = false, $param = null)
	{
		$this->resetCheckedItems($newChecked);
		$gridItems = $this->Grid->getItems();
		$header = $this->Grid->getHeader();

		foreach ($gridItems as $item)
			$item->CheckColumn->Checked->setChecked($newChecked);

		$header->CheckColumn->MasterCheck->setChecked($newChecked);
	}

	public function getCheckedItemIds($force = false, $reset = false)
	{
		$checked = $this->getChecked();
		$masterChecked = $checked['all'];
		unset($checked['all']);
		$checkedIds = array_keys($checked);
		$output = array();

		if (!$masterChecked)
			$output = $checkedIds;
		else		 // caso del mastercheck inverso
		{
			$criteria = $this->getGlobalCriteria();
			if (!is_null($criteria) && ($criteria instanceof Criteria))
			{
				$criteria->add(AddressPeer::ADDRESS_ID, $checkedIds, Criteria::NOT_IN);
				$stmt = AddressPeer::doSelectStmt($criteria);

				while ($row = $stmt->fetch(PDO::FETCH_NUM))
					$output[] = $row[0];
			}
		}

		if ((count($output) == 0) && ($force == true))
		{
			$this->resetCheckedItems(true);
			$output = $this->getCheckedItems();
			if ($reset)
				$this->resetCheckedItems(false);
		}

		return $output;
	}
	
}