<?php
/**
 *
 * @author Marco Brancalion <mbrancalion@e-portaltech.it>
 * @link http://www.e-portaltech.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @license http://www.e-portaltech.it/license/
 *
 */
class ClavisAuthorityChooser extends TTemplateControl
{
	private $_authority = null;
	private $_authoritySessionName;
	///private $_referrer;
	///private $_referrerSessionName;

	/**
	 * Object Authority which we are treating.
	 *
	 * @var Authority
	 */
	public function onInit($param)
	{
		parent::onInit($param);

		$uniqueId = $this->getUniqueID();
		$this->_authoritySessionName = "AuthoritySessionName" . $uniqueId;
		///$this->_referrerSessionName = "ReferrerSessionName" . $uniqueId;

		if (!$this->getPage()->getIsPostBack() and ! $this->getPage()->getIsCallback())
		{
			$this->resetAuthority();
			///////////$this->resetReferrer();
		}
	}

	/**
	 * In the onLoad, during first execution of the page we
	 * get the actual authority and populate the list.
	 *
	 * @param TEventParameter $param
	 */
	public function onLoad($param)
	{
		parent::onLoad($param);
		if (!$this->getPage()->getIsPostBack())
		{
			$this->getAuthority();
			$this->populate();
		}
	}

	public function resetAuthority($authority = null)
	{
		$this->setAuthority($authority);
	}

	/**
	 * Setter method of object authority.
	 *
	 * @param Authority $authority
	 */
	public function setAuthority($authority)
	{
		$this->_authority = $authority;
		$this->getApplication()->getSession()->add($this->_authoritySessionName, $this->_authority, null);
	}

	/**
	 * Getter method of object authority.
	 *
	 * @return Authority
	 *
	 */
	public function getAuthority()
	{
		$this->_authority = $this->getApplication()->getSession()->itemAt($this->_authoritySessionName, null);
		return $this->_authority;
	}
	/*
	  public function resetReferrer($component = null)
	  {
	  $this->setReferrer($component);
	  }

	  public function setReferrer($component)
	  {
	  $this->_referrer = $component;
	  $this->getApplication()->getSession()->add($this->_referrerSessionName, $this->_referrer, null);
	  }

	  public function getReferrer()
	  {
	  $this->_referrer = $this->getApplication()->getSession()->itemAt($this->_referrerSessionName, null);
	  return $this->_referrer;
	  }
	 */

	/**
	 * Population of main data of the authority.
	 *
	 */
	public function populate()
	{
		
	}

	public function onChooseAuthority($sender, $param)
	{
		$authorityId = intval($this->AuthorityResultValue->getValue());

		if ($authorityId > 0)
		{
			$this->setAuthority(AuthorityQuery::create()->findPk($authorityId));
			$this->AuthorityView->update($authorityId);
		}
		else
		{
			$this->getPage()->writeMessage(Prado::localize('Errore nella scelta dell\'authority'),
												ClavisMessage::ERROR);
		}
	}
	
}