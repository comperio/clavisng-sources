<?php
/**
 * HelpButton
 *
 * This extends a Prado TImageButton with the capabilities to open an iframe,
 * and passes the two Id's of the controls (ex. TTextBox) where the
 * iframe will write a "label" and a "value".
 * (NB: this controls must generate an html "<input ..>" tag, so a TLabel
 * has not to be used.....)
 *
 * @author Ciro Mattia Gonano
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2008 ePortal Technologies
 * @copyright Copyright &copy; 2009-2013 Comperio srl
 * @version 2.7
 * @package Controls
 * @since 2.6
 */

class HelpButton extends TActiveImageButton
{
    private $clavismanual_url = 'https://comperio-help.scrollhelp.site/cng/';

    /**
     * Registers the javascript code and publishes in the
     * Prado assets directory.
     *
     * @param TEventParameter $param
     */
    public function onPreRender($param)
    {
        parent::onPreRender($param);

        $scripts = $this->getPage()->getClientScript();
        $scripts->registerPradoScript('prado');
        if (!$scripts->isScriptFileRegistered('ButtonFunctions.js'))
            $scripts->registerScriptFile('ButtonFunctions.js',
                $this->publishFilePath(Prado::getPathOfNamespace('Application.Javascript')) . '/ButtonFunctions.js');
        $this->setImageUrl($this->getPage()->getTheme()->getBaseUrl() . '/icons/help.png');
        $this->setText(Prado::localize('Aiuto in linea per questa pagina'));
        $this->setTooltip(Prado::localize('Aiuto in linea per questa pagina'));
        $this->setStyle('border:0;margin:0;padding:3px;background-color:transparent;');
    }

    /**
     * Sets the url of the iframe which has to be open.
     *
     * @param string $value
     */
    public function setHelpPage($value)
    {
        $this->setControlState('HelpPage', $value, $this->getPage()->getPagePath());
    }

    /**
     * Gets the url of the iframe.
     *
     * @return string
     */
    public function getHelpPage()
    {
        return $this->getControlState('HelpPage', $this->getPage()->getPagePath());
    }

    public function getManualUrl()
    {
        $clavisPage = explode(".", strtolower($this->getHelpPage()), 2);
        $section = array_shift($clavisPage) ?? '';

        switch ($section) {
            case 'catalog':
                $wikiPage = 'Catalogo.1777860670';
                break;
            case 'circulation':
                $wikiPage = 'Circolazione.1777860769';
                break;
            case 'communication':
                $wikiPage = 'Comunicazione.1777860771';
                break;
            case 'acquisition':
                $wikiPage = 'Acquisizioni.1777860748';
                break;
            case 'reports':
                $wikiPage = 'Stampe.1777860669';
                break;
            case 'library':
                $wikiPage = 'Biblioteche.1777860660';
                break;
            case 'administration':
                $wikiPage = 'Amministrazione.1777860747';
                break;
            default:
                $wikiPage = 'Per-iniziare.1777860731';
                break;
        }

        return $this->clavismanual_url . $wikiPage . '.html';
    }

    /**
     * Extends the Prado method which attaches an attribute
     * to a control, so to add the "onclick" attribute which
     * will point to the javascript function which opens the
     * iframe (with parameters).
     *
     * @param THtmlWriter $writer
     * @throws TInvalidDataValueException
     */
    protected function addAttributesToRender($writer)
    {
        /* page */
        $paramString = 'openHelp(\'' . $this->getManualUrl() . '\'); return false;';
        $writer->addAttribute('onclick', $paramString);
        parent::addAttributesToRender($writer);
    }

    /**
     * Searches for control identified by argument within the current naming container;
     * if it is not found, fallbacks on searching it in the entire page.
     * If there are ambiguities, returns null.
     *
     * @param string $id The external control's ID.
     * @return TControl The control if found, null elsewhere.
     */
    protected function getExternalControl($id)
    {
        $control = $this->findControl($id);
        if (!$control) {
            $control = $this->getPage()->findControlsByID($id);
            $control = (is_array($control) && count($control) == 1) ? $control[0] : null;
        }
        return $control;
    }

}