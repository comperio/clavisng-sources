<?php
/**
 * ClavisResourceSessionList class file
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 */

/**
 * ClavisResourceSessionList Class
 * 
 * 
 *
 * @author Cristian Chiarello <cristian@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2008 ePortal Technologies
 * @copyright Copyright &copy; 2009 Comperio srl
 * @version 2.7
 */

class ClavisResourceSessionList extends TTemplateControl
{
	/**
	 * It populates the datagrid.
	 *
	 * @param TEventParameter $param
	 */
	public function onLoad($param)
	{
		parent::onLoad($param);

		//if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallBack()) {
		$this->globalRefresh();
		//}
	}


	public function changePage($sender,$param) {
		$this->ResourceSessionGrid->setCurrentPage($param->NewPageIndex);

		$this->globalRefresh();
	}

	public function getPopupFlag()
	{
		return $this->getPage()->IsPopup();
	}

	public function getUnlinkFlag()
	{
		return $this->getPage()->IsUnlink();
	}

	public function globalRefresh()
	{
		$this->populate();
		//if($this->getPage()->getIsCallback())
		//	$this->GridActivePanel->render($param->getNewWriter());
	}
	

	/*
	 * Set if you want to filter by patron id
	 */
	public function setFilterByPatron( $owned )
	{
		//Prado::log(__METHOD__ . " setFilterByPatron");
		$this->setControlState('filterbypatron', $owned);
	}
	
	public function getFilterByPatron()
	{
		$fbo = $this->getControlState( 'filterbypatron' );
		
		if(is_null($fbo) || $fbo == '')
			$fbo = NULL;
		return $fbo;
	}
	
	/*
	 * Set if you want to filter by library id
	 */
	public function setFilterByLibrary( $lib )
	{
		//Prado::log(__METHOD__ . " setFilterByPatron");
		$this->setControlState('filterbylibrary', $lib);
	}
	
	public function getFilterByLibrary()
	{
		$fbl = $this->getControlState( 'filterbylibrary' );
		
		if(is_null($fbl) || $fbl == '')
			$fbl = NULL;
		return $fbl;
	}
	
	/*
	 * Set if you want to enable action link
	 */
	public function setActionEnabled( $state )
	{
		//Prado::log(__METHOD__ . " setFilterByPatron");
		$this->setControlState('actionenabled', $state);
	}
	
	public function getActionEnabled()
	{
		$fbl=TRUE;
		$fbl = $this->getControlState( 'actionenabled' );
		
		if(is_null($fbl) || $fbl == '' || $fbl=='false')
			$fbl = FALSE;
		return $fbl;
	}
	
	
	
	/*
	 * Set if you want hide closed session
	 */
	public function setHideClosed( $status )
	{
		$this->setControlState( 'hideclosed', $status );
	}
	
	public function getHideClosed()
	{
		$sc = $this->getControlState( 'hideclosed' );
		
		if(!is_null($sc) && ($sc == 'true' || $sc == 'false'))
		{
			return $sc;
		}
		else
		{
			return NULL;
		}
	}
	
	
	/*
	 * Set if you want hide active session
	 */
	public function setHideActive( $status )
	{
		$this->setControlState( 'hideactive', $status );
	}
	
	public function getHideActive()
	{
		$sc = $this->getControlState( 'hideactive' );

		if(!is_null($sc) && ($sc == 'true' || $sc == 'false'))
		{
			return $sc;
		}
		else
		{
			return NULL;
		}
		
	}
	
	
	public function populate()
	{
		$pageSize = $this->ResourceSessionGrid->getPageSize();
		$currentIndexPage = $this->ResourceSessionGrid->getCurrentPage();

		$libid = $this->getUser()->getActualLibraryId();
		//Prado::log(__METHOD__ . " libID is $libid");
		$ul = $this->getUser()->getLibraries();
		//Prado::log(Prado::varDump($ul));
		if(array_key_exists( $libid, $ul ))
		{
			$this->setActionEnabled(TRUE);
			//Prado::log(__METHOD__ . " enable action");
		}

		
		/*
		 * Get a collection of ResourceSession records
		 */
		$resultset = ResourceSessionQuery::create()
			->orderBy( 'Acctstarttime', Criteria::DESC );
//			->limit( $pageSize )
//			->offset( $currentIndexPage * $pageSize);

		

		$fbo = $this->getFilterByPatron();
		if(!is_null( $fbo ))
		{
			$resultset->filterByPatronId($fbo);
		}
		
		$fbl = $this->getFilterByLibrary();
		if(!is_null( $fbl ))
		{
			$resultset->filterByLibraryId($fbl);
		}
		
		
		$hc = $this->getHideClosed();
		if(  ! is_null( $hc ) && $hc == true )
		{
			$resultset->where(' acctstoptime IS NULL');
		}
		
		
		$ha = $this->getHideActive();
		if(  ! is_null( $ha ) && $ha == true )
		{
			$resultset->where(' acctstoptime IS NOT NULL');
		}
		
		$nmru = ClavisParamQuery::create()
		->filterByParamName(ClavisRadUtil::CP_SESSION_VIEW_AGE)
		->filterByLibraryId($this->getUser()->getActualLibraryId())
		->filterByParamClass(ClavisRadUtil::CP_CLASS)
		->findOne();
		if( $nmru instanceof ClavisParam)
		{
			$sva = $nmru->getParamValue();
			$resultset->where("timestampdiff(DAY,acctstarttime,NOW()) <= {$sva}");
		}
			
		
		$recCount = $resultset->count();
		$this->ResourceSessionGrid->setVirtualItemCount($recCount);
		$this->RecCounter->setText(Prado::localize("Record totali: {recCount}", array('recCount' => $recCount)));

		
					
		//Prado::log(__METHOD__ . " q = " . $resultset->toString());
		
		

		$records = $resultset
		->limit( $pageSize )
		->offset( $currentIndexPage * $pageSize)
		->find();

		$datasource = array();
		$lastClosedSidPerPatron = array();
		foreach ($records as $record)
		{
			if( $record instanceof ResourceSession)
			{
				$recordid = $record->getResourceSessionId();

				$name = $record->getNasname();
				if( is_null( $name ))
					$name = '---';
				
				$framedipaddress = $record->getFramedipaddress();
				if( is_null( $framedipaddress ) || $framedipaddress == '')
					$framedipaddress = $name;

				$shortname = $record->getShortname();
				if( is_null( $shortname ))
					$shortname = '---';
				
				$acctstarttime = $record->getAcctstarttime(NULL);
				if( is_null( $acctstarttime ))
					$sAcctstarttime = '---';
				else
					$sAcctstarttime = $acctstarttime->format( 'd/m/Y H:i:s');
				
				$patronid = $record->getPatronId();
				$showStopSession = $this->getActionEnabled();
				$acctstoptime = $record->getAcctstoptime(NULL);
				if( is_null( $acctstoptime ))
				{
					$sAcctstoptime = '---';
					$showStopSession = TRUE;
				}
				else
				{
					$sAcctstoptime = $acctstoptime->format( 'd/m/Y H:i:s');
					$showStopSession = FALSE;
					if(!array_key_exists($patronid, $lastClosedSidPerPatron))
					{
					    $lastClosedSidPerPatron[$patronid] = $record->getResourceSessionId();
					}
				}
				
				$sessiontime = 0;
				if( is_null( $acctstoptime ))
				{
					$status = 'APERTA';
					$now = new DateTime();
					$diff = $now->diff($acctstarttime);
					$sessiontime = $diff->i + ($diff->h*60);
				}
				else
				{
					$status = 'CHIUSA';
					$sessiontime = round($record->getAcctsessiontime() / 60);
				}
				
				$acctsessiontime = $record->getAcctsessiontime();
				if( ! is_null($acctsessiontime) && $acctsessiontime > 60 )
				{
					$sessiontime = round($acctsessiontime / 60);
				}
				
				$connectinfostop = round($record->getConnectinfoStop() / 60);
				if( is_null( $connectinfostop ))
					$connectinfostop = '---';
				
				
				$type = $record->getType();
				if( is_null( $type ))
					$type = '---';


				$community = $record->getCommunity();
				if( is_null( $community ))
					$community = '---';

				$username = $record->getUsername();
				$comboname = '';
				if( is_null( $username ))
				{
					$comboname = '---';
				}
				else
				{
    				$fullname = '';
    				$spatron = PatronQuery::create()
    				        ->findOneByOpacUsername($username);
    				if($spatron instanceof Patron)
    				{
    				    $fullname =  $spatron->getLastname() . " " . $spatron->getName();
    				}
    				$comboname = $username . " - " . $fullname;
				}
				
				
				$resourceid = $record->getResourceId();


				$datasource[] = array(
										'id' => $recordid,
										'name' => $name,
										'framedipaddress' => $framedipaddress,
										'shortname' => $shortname,
										'status' => $status,
										'type' => $type,
										'community' => $community,
										'username' => $comboname,
										'acctstarttime' => $sAcctstarttime,
										'acctstoptime' => $sAcctstoptime,
										'connectinfostop' => $connectinfostop,
										'sessiontime' => $sessiontime,
										'patronId' => $patronid,
										'resourceId' => $resourceid,
										'showStopSession' => 	$showStopSession,
				                        'showAddCredit' => ($lastClosedSidPerPatron[$patronid] == $record->getResourceSessionId())
				);
			}//if
		}//foreach 
		
		
		$this->ResourceSessionGrid->setDataSource($datasource);
		$this->ResourceSessionGrid->dataBind();
	}

	
	
	
	
	public function addTime($sender, $param)
	{
		$pk = $param->getCallbackParameter();
		//Prado::log("Stop session id {$pk}");
		$rs = ResourceSessionQuery::create()
			->findPk($pk);
		if($rs instanceof ResourceSession)
		{
			$rsType = $rs->getType();

			try {
				$totime = $rs->getConnectinfoStop();
				if( !is_null( $totime ))
				{
					$iTottime = intval($totime);
					$iTottime += 600;
					$rs->setConnectinfoStop($iTottime);

					/*
					 * Mikrotik, save record only if resource accept my request
					 */
					if($rsType == Resource::TYPE_MIKROTIK)
					{
						$client= ClavisRadUtil::getClient($this->getUser()->getActualLibraryId());
						$res = $client->radiusChtimeout( $rs->toArray(), $iTottime);
						if( isset( $res['result'] ) && isset( $res['result']['status'] ) && $res['result']['status'] == 'ack' )
						{
							$this->getPage()->writeMessage(Prado::localize("Tempo aggiornato."),ClavisMessage::CONFIRM);
							Prado::log(__METHOD__ . " time updated for {$rs->getUsername()}");
							$rs->save();
						}
						else
						{
							if( isset( $res['result']['errors'] ))
							{
								$errs = $res['result']['errors'];
								$laste = '';
								foreach($errs as $k => $v)
								{
									$laste = $k . " :" . $v;
									Prado::log("ERROR: ".$laste);
								}
							}
							$this->getPage()->writeMessage(Prado::localize("Aggiornamento tempo fallito su radius/mikotik."),ClavisMessage::WARNING);
						}
					}
					else
					{
						$rs->save();
						$this->getPage()->writeMessage(Prado::localize("Aggiunto tempo per utente '{name}'",
															array('name' => $rs->getUsername())),
															ClavisMessage::CONFIRM);
					}
				}
			} catch (Exception $e) {
				$this->getPage()->writeMessage(Prado::localize("Non posso aggiungere tempo alla sessione: {error}",
					array('error' => $e->getMessage())),ClavisMessage::ERROR);
			}
			
		}
		else
		{
			$this->getPage()->writeMessage(Prado::localize("Errore interno: sessione non trovata"),ClavisMessage::ERROR);
		}
		$this->populate();
		$this->GridActivePanel->render($param->getNewWriter());
	}
	
	public function subTime($sender, $param)
	{
		$pk = $param->getCallbackParameter();
		//Prado::log("Stop session id {$pk}");
		$rs = ResourceSessionQuery::create()
			->findPk($pk);
		if($rs instanceof ResourceSession)
		{
			$rsType = $rs->getType();

			try {
				$totime = $rs->getConnectinfoStop();
				if( !is_null( $totime ))
				{
					$iTottime = intval($totime);
					if($iTottime >= 660)
					{
						$iTottime -= 600;
						$rs->setConnectinfoStop($iTottime);
						
						
						/*
						* Mikrotik, save record only if resource accept my request
						*/
						if($rsType == Resource::TYPE_MIKROTIK)
						{
							$client= ClavisRadUtil::getClient($this->getUser()->getActualLibraryId());
							$res = $client->radiusChtimeout( $rs->toArray(), $iTottime);
							if( isset( $res['result'] ) && isset( $res['result']['status'] ) && $res['result']['status'] == 'ack' )
							{
								$this->getPage()->writeMessage(Prado::localize("Tempo aggiornato."),ClavisMessage::CONFIRM);
								Prado::log(__METHOD__ . " time updated for {$rs->getUsername()}");
								$rs->save();
							}
							else
							{
								if( isset( $res['result']['errors'] ))
								{
									$errs = $res['result']['errors'];
									$laste = '';
									foreach($errs as $k => $v)
									{
										$laste = $k . " :" . $v;
										Prado::log("ERROR: ".$laste);
									}									
								}
								$this->getPage()->writeMessage(Prado::localize("Aggiornamento tempo fallito su radius/mikotik."),ClavisMessage::WARNING);
							}
						}
						else
						{
							$rs->save();
							$this->getPage()->writeMessage(Prado::localize("Tolto tempo per utente '{name}'",
															array('name' => $rs->getUsername())),
															ClavisMessage::CONFIRM);
						}
						
					}
				}

			} catch (Exception $e) {
				$this->getPage()->writeMessage(Prado::localize("Non posso togliere tempo alla sessione: {error}",
					array('error' => $e->getMessage())),ClavisMessage::ERROR);
			}

		}
		else
		{
			$this->getPage()->writeMessage(Prado::localize("Errore interno: sessione non trovata"),ClavisMessage::ERROR);
		}
		$this->populate();
		$this->GridActivePanel->render($param->getNewWriter());
	}
	
	
	public function stopSession($sender, $param)
	{
		$pk = $param->getCallbackParameter();
		//Prado::log("Stop session id {$pk}");
		$rs = ResourceSessionQuery::create()
			->findPk($pk);
		if($rs instanceof ResourceSession)
		{
			try {
				
				$acctstoptime = $rs->getAcctstoptime(NULL);
				if(! is_null($acctstoptime))
				{
					$this->getPage()->writeMessage(Prado::localize("Sessione già chiusa"),ClavisMessage::ERROR);
				}
				else
				{
					$rsType = $rs->getType();
					if($rsType == Resource::TYPE_MIKROTIK)
					{
						$client= ClavisRadUtil::getClient($this->getUser()->getActualLibraryId());
						$res = $client->radiusDisconnect( $rs->toArray() );
						if( isset( $res['result'] ) && isset( $res['result']['status'] ) && $res['result']['status'] == 'ack' )
						{
							$this->getPage()->writeMessage(Prado::localize("Sessione terminata."),ClavisMessage::CONFIRM);
						}
						else
						{
							if( isset( $res['result']['errors'] ) && count($res['result']['errors']) > 0)
							{
								$errs = json_encode($res['result']['errors']);
								Prado::log(__METHOD__ . " radiusDisconnect FAIL for {$rs->getUsername()} {$rs->getAcctuniqueid()}: ".$laste, TLogger::DEBUG);
							}
							//$this->getPage()->writeMessage(Prado::localize("Disconnessione rifiutata dal radius/mikotik. Chiusura in locale"),ClavisMessage::WARNING);
							$rs->close();
							$this->getPage()->writeMessage(Prado::localize("Sessione terminata per utente '{name}'",
															array('name' => $rs->getUsername())),
															ClavisMessage::CONFIRM);
						}
					}
					else
					{
						$rs->close();
					}
				}
				
			} catch (Exception $e) {
				$this->getPage()->writeMessage(Prado::localize("Non posso fermare la sessione: {error}",
					array('error' => $e->getMessage())),ClavisMessage::ERROR);
			}
		}
		else
		{
			$this->getPage()->writeMessage(Prado::localize("Errore interno: sessione non trovata"),ClavisMessage::ERROR);
		}
		$this->populate();
		$this->GridActivePanel->render($param->getNewWriter());
		$mypage = $this->getPage();
		if( method_exists( $mypage, 'sessionsRefresh' ) )
			$mypage->sessionsRefresh($param->getNewWriter());
	}

	
	public function deleteSession($sender, $param)
	{
	    $pk = $param->getCallbackParameter();
	    try 
	    {
            $session = ResourceSessionQuery::create()
                ->findOneByPrimaryKey($pk);
            if($session instanceof ResourceSession)
            {
                $jsession = json_encode($session->toArray());
                $session->delete();
                ChangelogPeer::logAction( $session,
                    ChangelogPeer::LOG_DELETE,
                    $this->getUser(),
                    "Eliminata sessione {$jsession}");
            }
        } catch (Exception $e) {
            $this->getPage()->writeMessage(Prado::localize("Non posso eliminare la sessione: {error}",
                array('error' => $e->getMessage())),ClavisMessage::ERROR);
        }
        
        $this->populate();
        $this->GridActivePanel->render($param->getNewWriter());
        $mypage = $this->getPage();
        if( method_exists( $mypage, 'sessionsRefresh' ) )
            $mypage->sessionsRefresh($param->getNewWriter());
	}
	
	public function addUserCredit($sender, $param)
	{
	    
	    $cp = $param->getCallbackParameter();
	    
	    $sessionid = $cp[0];
	    $credits = $cp[1];
	    Prado::log(__METHOD__ . " sessionid {$sessionid} credits {$credits}");
	    
	    $rs = ResourceSessionQuery::create()->findPk($sessionid);
	    if($rs instanceof ResourceSession)
	    {
	       $rule = new ResourceRule();
	       $rule->setPriority(1);
	       $rule->setResourceOwner('.');	    
	       $rule->setPatronId($rs->getPatronId());
	       $rule->setType(ResourceRule::TYPE_CREDIT);
	       $rule->setResourcePattern('.');
	       $rule->setAmount($credits);
    	   $rule->setUsed(0);
	       $de = new DateTime();
	       $rule->setValidityStart($de);
	       $de->setTime(23, 59, 59);
	       $rule->setValidityEnd($de);
	       $rule->setLibraryId($this->getUser()->getActualLibraryId());
	       $rule->setNote('');
	    
    	    try
    	    {
    	        $rule->save();
    	        
    	        ChangelogPeer::logAction(	$rule,
    	            ChangelogPeer::LOG_CREATE,
    	            $this->getUser(),
    	            "Creata regola con id: {$rule->getResourceRuleId()} (fast link)");
    	            
    	        $this->getPage()->writeMessage(Prado::localize("Tempo aggiunto"), ClavisMessage::CONFIRM );
    	    }
    	    catch (Exception $ex)
    	    {
    	        Prado::log(__METHOD__ . " EXCEPTION: " . $ex->getMessage());
    	        $this->getPage()->writeMessage(Prado::localize("Errore interno"),
    	            ClavisMessage::ERROR);
    	    }
	    }
	}
	
}
