<?php
/**
 * Created by PhpStorm.
 * User: dario
 * Date: 14/01/2014
 * Time: 16:18
 */

class DBActiveDropDownListColumn extends TActiveDropDownListColumn
{
    public function setDBClass($value)
    {
        $this->setViewState("DBCLASS",$value);
    }
    public function getDBClass()
    {
        return $this->getViewState("DBCLASS");
    }

    public function setDBClassValue($value)
    {
        $this->setViewState("DBCLASSVALUE",$value);
    }
    public function getDBClassValue()
    {
        return $this->getViewState("DBCLASSVALUE");
    }

    public function initializeCell($cell,$columnIndex,$itemType)
    {
        if($itemType == TListItemType::EditItem)
        {
            $this->setListDataSource(LookupValuePeer::getLookupClassValues($this->getDBClass()));
        } else  if($itemType == TListItemType::AlternatingItem
            || $itemType == TListItemType::Item
            || $itemType == TListItemType::SelectedItem) {

            $cell->attachEventHandler('OnDataBinding',array($this,'dataBindColumn'));

        }
        parent::initializeCell($cell,$columnIndex,$itemType);
    }

    /**
     * Databinds a cell in the column.
     * This method is invoked when datagrid performs databinding.
     * It populates the content of the cell with the relevant data from data source.
     */
    public function dataBindColumn($sender,$param)
    {

        $item=$sender->getNamingContainer();
        $data=$item->getData();

        $value = $data[$this->getDBClassValue()];
        $text = LookupValuePeer::getLookupValue($this->getDBClass(),$value);

        if($sender instanceof TTableCell)
            $sender->setText($text);
        else if($sender instanceof TDropDownList)
            $sender->setSelectedValue($value);
    }
}