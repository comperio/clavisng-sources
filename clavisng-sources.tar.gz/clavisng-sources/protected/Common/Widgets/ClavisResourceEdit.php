<?php
/**
 * ResourceEditPage
 *
 * @author Cristian Chiarello <ciarez@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2016 Comperio srl
 */
class ClavisResourceEdit extends TTemplateControl
{
	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallback())
		{
			$this->populate();
		}
	}

	public function checkAuth($addedCheck = true, $force = null)
	{
		$allow = true;
		$resource = $this->getResource();

		if (!is_null($resource) && ($resource instanceof Resource))
			$allow = $this->getUser()->getEditPermission($resource);
		parent::checkAuth($allow);
	}

	public function setResource($value)
	{
		$this->setViewState("resourceViewstate", $value, null);
	}

	public function getResource()
	{
		return $this->getViewState("resourceViewstate", null);
	}

	public function getIsNew()
	{
		$resource = $this->getResource();
		if (!is_null($resource) && ($resource instanceof Resource))
			return $resource->isNew();
		else
			return false;
	}

	public function regRemoteRes($resource)
	{
		try
		{
			$client = ClavisRadUtil::getClient();
			$res = $client->setNas($resource->toArray());
			//Prado::log(Prado::varDump($res));
			if (isset($res['result']) && isset($res['result']['status']) && $res['result']['status'] == 'ack')
			{
				if (isset($res['result']['data']['extid']))
				{
					$extid = $res['result']['data']['extid'];
					return $extid;
				}
				else
				{
					Prado::log(__METHOD__ . ' no id given from remote');
					return 0;
				}
			}
		}
		catch (Exception $ex)
		{
			Prado::log(__METHOD__ . ' error calling rpc ' . $ex->getMessage());
			return 0;
		}
	}

	public function onSave($sender, $param)
	{
		/** @var $resource Resource */
		$resource = $this->getResource();
		if (is_null($resource) || !($resource instanceof Resource))
		{
			$this->getPage()->writeMessage(Prado::localize("Errore interno, controllare i log di clavis"), ClavisMessage::ERROR);
			Prado::log(__METHOD__ . " " . __LINE__ . " ERROR resource is not set!");
			return false;
		}

		try
		{
			$isNew = $resource->isNew();
			$desc = ClavisRadUtil::getResourceDesc($this);
			$resource->setDescription($desc);

			$resource->setName($this->Name->getSafeText());
			$resource->setShortname($this->Shortname->getSafeText());
			$port = $this->Ports->getSafeText();
			if ($port != '')
				$resource->setPorts($port);
			else
				$resource->setPorts(NULL);
			$resource->setSecret($this->Secret->getSafeText());
			$resource->setType($this->Type->getSelectedValue());
			$resource->setAdminUsr($this->AdminUsr->getSafeText());
			$resource->setAdminPwd($this->AdminPwd->getSafeText());
			$resource->setNote($this->Note->getSafeText());

			$libid = $this->getUser()->getActualLibraryId();
			$resource->setLibraryId($libid);


			$rType = $resource->getType();
			if ($rType == 'mikrotik')
			{
				$extid = $this->regRemoteRes($resource);
				if ($extid > 0)
				{
					$resource->setResourceExternalId($extid);
					$wuf = $this->WellcomeUrlFormat->getSelectedValue();
					if($wuf != "")
					{
						if($wuf == 'IP' || $wuf == 'DNS')
						{
							$resource->setWellcomeUrl($wuf . $this->WellcomeUrl->getSafeText() );
						}
						else
						{
							$resource->setWellcomeUrl( $this->WellcomeUrl->getSafeText() );
						}
					}
					else
					{
						$resource->setWellcomeUrl( NULL );
					}
					$affectedCount = $resource->save();
				}
				else
				{
					$this->getPage()->writeMessage(Prado::localize("Errore nella registrazione della risorsa sul server radius"), ClavisMessage::ERROR);
					return false;
				}
			}
			else
			{
				$affectedCount = $resource->save();
			}
			$this->setResource($resource);
		}
		catch (Exception $ex)
		{
			Prado::log(__METHOD__ . ' ' . $ex->getMessage());
			$this->getPage()->writeMessage(Prado::localize("Errore, risorsa con id: {id} e nome '{label}' non salvata", array('id' => $resource->getResourceId(), 'label' => $resource->getShortname())), ClavisMessage::ERROR);
			return false;
		}


		if ($isNew)
		{
			ChangelogPeer::logAction($resource, ChangelogPeer::LOG_CREATE, $this->getUser(), "Creata risorsa con id: {$resource->getResourceId()}");
			$this->getPage()->writeMessage(Prado::localize("Creata risorsa con id: {id} e nome '{label}'", array('id' => $resource->getResourceId(), 'label' => $resource->getShortname())), ClavisMessage::CONFIRM);
		}
		else
		{
			ChangelogPeer::logAction($resource, ChangelogPeer::LOG_UPDATE, $this->getUser(), "Modificata risorsa con id: " . $resource->getResourceId());
			$this->getPage()->writeMessage(Prado::localize("Modificata risorsa con id: {id} e nome '{label}'", array('id' => $resource->getResourceId(), 'label' => $resource->getShortname())), ClavisMessage::CONFIRM);
		}

		$this->onCancel($sender, $param);

		//$this->Page->ResourceRuleList->populate();
		/*
		  $reslist = $this->Page->findControlsByID("ResourceList");
		  if($reslist[0] instanceof ClavisResourceList)
		  {
		  $reslist[0]->populate();
		  } */
		$p = $this->getPage();
		if (method_exists($p, 'populate'))
		{
			$p->populate();
		}
	}

	public function populate()
	{
		$resource = null;
		$id = intval($this->getResPK());

		if (!is_null($id) && $id > 0)
		{

			$resource = ResourceQuery::create()->findOneByResourceId($id);

			if (!($resource instanceof Resource))
			{
				$this->getPage()->writeMessage(Prado::localize('La risorsa con id = {id} non esiste', array('id' => $id)), ClavisMessage::ERROR);
				$resource = new Resource();
				$resource->isNew(TRUE);
			}
			$this->Name->Text = $resource->getName();
			$this->Shortname->Text = $resource->getShortname();
			$this->Ports->Text = $resource->getPorts();
			$this->Secret->Text = $resource->getSecret();
			$this->AdminUsr->Text = $resource->getAdminUsr();
			$this->AdminPwd->Text = $resource->getAdminPwd();
			$this->Type->setSelectedValue($resource->getType());
			$this->Note->setText($resource->getNote());
			$wu = $resource->getWellcomeUrl();
			if(!is_null($wu))
			{
				if( strpos($wu, "IP") === 0 )
				{
					$this->WellcomeUrlFormat->setText("IP");
					$this->WellcomeUrl->setText(substr($wu, 2));
				}
				elseif( strpos($wu, "DNS") === 0 )
				{
					$this->WellcomeUrlFormat->setText("DNS");
					$this->WellcomeUrl->setText(substr($wu, 3));
				}
				else
				{
					if($wu != "")
					{
						$this->WellcomeUrlFormat->setSelectedValue("CUSTOM");
						$this->WellcomeUrl->setText($wu);
					}
				}
			}
			
			
		}
		else //If not edit, create a new one
		{
			$resource = new Resource();
			$resource->isNew(TRUE);
		}

		//Prado::log("Resource type {$resource->getType()}");
		if($resource->getType() == Resource::TYPE_MIKROTIK)
		{
			$this->WellcomeUrlPanel->setVisible(TRUE);
		}
		else
		{
			$this->WellcomeUrlPanel->setVisible(FALSE);
		}
		
		$this->setResource($resource);
	}

	public function onCancel($sender, $param)
	{
		$this->ResEditPanel->setVIsible(FALSE);
		$this->Name->Text = "";
		$this->Shortname->Text = "";
		$this->Ports->Text = "";
		$this->Secret->Text = "";
		$this->AdminUsr->Text = "";
		$this->AdminPwd->Text = "";
		$this->Note->Text = "";
		$this->setResPK(NULL);
		$this->setResource(NULL);
	}

	public function setVisible($param)
	{
		$this->ResEditPanel->setVIsible($param);
	}

	public function setMode($mode)
	{
		$this->setControlState('mode', $mode);
	}

	public function getMode()
	{
		return $this->getControlState('mode');
	}

	public function setResPK($pk)
	{
		$this->setControlState('pk', $pk);
	}

	public function getResPK()
	{
		return $this->getControlState('pk');
	}
	
	public function typeChanged( $sender, $param )
	{
		//Prado::log("Changed");
		$item = $sender->getSelectedItem();
		if($item->getValue() == Resource::TYPE_MIKROTIK)
		{
			$this->WellcomeUrlPanel->setVisible(TRUE);
		}
		else
		{
			$this->WellcomeUrlPanel->setVisible(FALSE);
		}
	}
	
}