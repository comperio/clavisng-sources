<?php

/**
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.e-portaltech.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @license http://www.e-portaltech.it/license/
 *
 *
 * This component visualizes the item requests which are stored in the
 * databases, for incoming extraloan.
 *
 */
class ClavisExtraItemRequestList extends TTemplateControl
{
	private $_loanmanager;
	private $_illFoundDatasourceSessionName;
	private $_externalLibrariesSessionName;
	private $_nodeLibrary;
	/**
	 * Per la logica di checkaggio
	 *
	 */
	public $_masterChecked;
	private $_checked = array('all' => false);
	private $_checkedSessionName;
	private $_globalCriteriaSessionName;

	private function initVars()
	{
		$uniqueId = $this->getUniqueID();
		$this->_illFoundDatasourceSessionName = "IllFoundDataSourceSessionName" . $uniqueId;
		$this->_externalLibrariesSessionName = "ExternalLibrariesSessionName" . $uniqueId;

		$this->_loanmanager = $this->getApplication()->getModule("loan");

		$this->_nodeLibrary = $this->_loanmanager->getExtraSystemNodeLibrary();

		$this->_checkedSessionName = "CheckedSessionName" . $uniqueId;
		$this->_globalCriteriaSessionName = "GlobalCriteriaSessionName" . $uniqueId;
		$this->_checked = $this->getChecked();
		$this->_masterChecked = $this->_checked['all'];
	}

	public function onInit($param)
	{
		parent::onInit($param);
		$this->initVars();
		///$this->attachEventHandler('OnActualLibraryChanged', array($this, 'OnActualLibraryChanged'));

		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallback())
		{
			$this->setExternalLibraries(LibraryPeer::getLibraries(	true, // solo le attive
																	false));  // esterne
		}
	}

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallback())
		{
//			$this->FromLibraryExtra->setDataSource(LibraryPeer::getLibrariesHashWithBlank(	true, // solo le attive
//																							false));  // esterne
//			$this->FromLibraryExtra->dataBind();

			$this->DeliveryLibrary->setDataSource(LibraryPeer::getLibrariesHashWithBlank(	false, // tutte (anche inattive
																							true));  // interne
			$this->DeliveryLibrary->dataBind();

			$this->cleanFilters();

			if (!($this->_nodeLibrary instanceof Library))
				$this->DeliveryLibrary->setSelectedValue($this->getUser()->getActualLibraryId());

			$this->resetDataSource(false);
		}

		if (!$this->getPage()->getIsCallback() && $this->getAutoPopulate())
			$this->globalRefresh();
		
		$this->ActiveRequestPanel->setCssClass($this->getViewLibraryId() > 0 ? 'panel_off' : 'panel_on');
		$this->ActionsColumn->setVisible($this->getViewLibraryId() == 0);
	}

	public function OnActualLibraryChanged($sender, $param)
	{
		$this->DeliveryLibrary->setSelectedValue($this->getUser()->getActualLibraryId());
	}

	public function onCancel($sender, $param)
	{
		$this->cleanFilters();
		$this->globalRefresh();
	}

	public function cleanFilters()
	{
		$this->ActiveRequest->setChecked(true);
		//$this->FromLibraryExtra->setSelectedIndex(0);
		$this->FromLibraryExtraLabel->setText('');
		$this->FromLibraryExtraId->setText('');
		$this->doFromLibraryExtraClean();
		$this->DeliveryLibrary->setSelectedIndex(0);
		$this->onResetRequestDate(null, null);

		$this->BarcodeFilter->setText('');
		$this->TitleFilter->setText('');
	}

	public function resetDataSource($populateFlag = true)
	{
		$this->resetChecked();
		$this->resetGlobalCriteria();
		$this->setDataSource(array());
		$this->cleanFilters();

		if ($populateFlag)
			$this->globalRefresh();
	}

	public function onSearch($sender, $param)
	{
		$this->globalRefresh();
	}

	public function getDataSource()
	{
		return $this->getApplication()->getSession()->itemAt($this->_illFoundDatasourceSessionName);
	}

	public function setDataSource($val)
	{
		$this->getApplication()->getSession()->add($this->_illFoundDatasourceSessionName, $val);
	}

	public function getExternalLibraries()
	{
		$lib = $this->getApplication()->getSession()->itemAt($this->_externalLibrariesSessionName);
		
		if (is_null($lib) || !is_array($lib))
			$lib = array();

		return $lib;
	}

	public function setExternalLibraries($value = array())
	{
		if (!is_array($value))
			$value = array();

		$this->getApplication()->getSession()->add($this->_externalLibrariesSessionName, $value);
	}

	public function setObject($obj)
	{
		$this->_object = $obj;
		$this->setViewState("object", $obj, null);
	}

	public function getObject()
	{
		$this->_object = $this->getViewState("object", null);
		
		return $this->_object;
	}

	public function setAutoPopulate($flag = true)
	{
		$this->setViewState("automaticPopulate", $flag, true);
	}

	public function getAutoPopulate()
	{
		return $this->getViewState("automaticPopulate", true);
	}

	public function setViewLibraryId($value = null)
	{
		$this->setViewState('viewLibraryId', $value);
	}

	public function getViewLibraryId()
	{
		return (int) $this->getViewState('viewLibraryId');
	}
	
	public function reloadStoredObject()
	{
		$obj = $this->getObject();
		
		if (!is_null($obj) && !$obj->isNew())
		{
			$objId = $obj->getId();
			$peerClass = $obj->getPeer();
			$newObj = $peerClass->retrieveByPK($objId);
			$this->setObject($newObj);
		}
	}

	public function populate()
	{
		$myLibraryId = $this->getUser()->getActualLibraryId();
		$pageSize = $this->Grid->getPageSize();
		$currentIndexPage = $this->Grid->getCurrentPage();

		$criteria = new Criteria();
		$criteria->addJoin(ItemRequestPeer::ITEM_ID, ItemPeer::ITEM_ID, Criteria::INNER_JOIN);

		/// criterions for extrasystem item requests (out of catalog): direction IN
		if ($this->_nodeLibrary instanceof Library)
		{
			if ($myLibraryId != $this->_nodeLibrary->getLibraryId())
				$criteria->add(ItemRequestPeer::REQUEST_ID, 0);   /// mai

			$nodeLibraryExists = true;
		}
		else
		{
			$criteria->add(ItemRequestPeer::DELIVERY_LIBRARY_ID, $myLibraryId);

			$nodeLibraryExists = false;
		}

		/// biblioteca di provenienza
		//$fromLibraryFilter = intval($this->FromLibraryExtra->getSelectedValue());
		$fromLibraryFilter = (int) $this->FromLibraryExtraId->getText();

		if ($fromLibraryFilter > 0)
		{
			$criteria->add(ItemPeer::OWNER_LIBRARY_ID, $fromLibraryFilter);
		}
		else
		{
			$criteria->add(ItemPeer::OWNER_LIBRARY_ID, $this->getExternalLibraries(), Criteria::IN);
		}

		/// biblioteca di destinazione
		$toLibraryFilter = intval($this->DeliveryLibrary->getSelectedValue());

		if ($this->getViewLibraryId() > 0)
		{	
			$criteria->add(ItemPeer::ACTUAL_LIBRARY_ID, $this->getViewLibraryId());
		}
		else
		{
			if ($toLibraryFilter > 0)
				$criteria->add(ItemRequestPeer::DELIVERY_LIBRARY_ID, $toLibraryFilter);
		}

		//delivery_library
		if ($this->ActiveRequest->getChecked())
		{
			$criteria->add(ItemRequestPeer::REQUEST_STATUS, ItemRequestPeer::STATUS_PENDING);
			$criteria->addAscendingOrderByColumn(ItemRequestPeer::REQUEST_DATE);
		}
		else
		{
			$criteria->addDescendingOrderByColumn(ItemRequestPeer::REQUEST_DATE);
		}

		$requestDateFrom = $this->RequestDateFrom->getSafeText() != '' ? $this->RequestDateFrom->getTimeStamp() : null;
		$requestDateTo = $this->RequestDateTo->getSafeText() != '' ? $this->RequestDateTo->getTimeStamp() : null;

		if (!is_null($requestDateFrom) 
				&& ($requestDateFrom > 0)) 
			$criteria->addAnd(ItemRequestPeer::REQUEST_DATE, $requestDateFrom, Criteria::GREATER_EQUAL);

		if (!is_null($requestDateTo) 
				&& ($requestDateTo > 0)) 
			$criteria->addAnd(ItemRequestPeer::REQUEST_DATE, $requestDateTo + 86399, Criteria::LESS_EQUAL);

		$barcode = trim($this->BarcodeFilter->getSafeText());

		if ($barcode != '')
			$criteria->add(ItemPeer::BARCODE, $barcode);

		$title = trim($this->TitleFilter->getSafeText());

		if ($title != '')
			$criteria->add(ItemPeer::TITLE, $title . "%", Criteria::LIKE);

		// we don't want 'document delivery' or 'consultation only' requests

		$crit1 = $criteria->getNewCriterion(ItemRequestPeer::REQUEST_TYPE, ItemRequestPeer::ITEMREQUESTTYPE_LOAN);
		$crit2 = $criteria->getNewCriterion(ItemRequestPeer::REQUEST_TYPE, null, Criteria::ISNULL);
		$crit1->addOr($crit2);

        $criteria->addAnd($crit1);

		$this->setGlobalCriteria(clone $criteria);

		$recCount = ItemRequestPeer::doCount($criteria);
		$this->RecCounter->setText($recCount);

		$criteria->setLimit($pageSize);
		$criteria->setOffset($currentIndexPage * $pageSize);
		$data = array();
		$itemRequests = array();

		if ($recCount > 0)
			$itemRequests = ItemRequestPeer::doSelect($criteria);

		foreach ($itemRequests as $itemRequest)
		{
			/** @var $itemRequest ItemRequest */
			$row = array();

			$row['RequestStatus'] = $itemRequest->getRequestStatus();
			$row['RequestStatusString'] = $itemRequest->getRequestStatusString();

			$wantedUrl = '';
			$wantedText = '';
			$wantedImageUrl = '';
			$wantedPopupUrl = '';
			$ownerLibraryUrl = '';
			$ownerLibraryString = '';
			$arrivable = false;
			$itemInventoryNumber = '';

			$item = $itemRequest->getItem();
			
			if ($item instanceof Item)
			{
				$wantedTitle = $item->getCompleteTitle();
				if (!$wantedTitle)
					$wantedTitle = Prado::localize('(nessun titolo)');

				$wantedId = $item->getId();
				if ($wantedId > 0 && $wantedTitle != '')
				{
					$wantedUrl = $item->getNavigateUrl() . $wantedId;
					$wantedText = $wantedTitle;
				}

				$ownerLibrary = $item->getOwnerLibrary();
				if ($ownerLibrary instanceof Library)
				{
					$ownerLibraryUrl = $ownerLibrary->getNavigateUrl() . $ownerLibrary->getLibraryId();
					$ownerLibraryString = $ownerLibrary->getLabel(true);
					if ($item->getActualLibraryId() != $item->getOwnerLibraryId())
					{
						$actualLibrary = $item->getActualLibrary();
						if ($actualLibrary instanceof Library)
						{
							$actualLibraryString = $actualLibrary->getLabel(true);
							$ownerLibraryString .= " (" . Prado::localize('ora presente in') . ' ' . $actualLibraryString . ")";
						}
					}
				}

				/// arrivabile solo se e' all'esterno
				if (!$this->_loanmanager->IsLoanStatusActive($item))
				// || (($itemRequest->getDeliveryLibraryId() != $myLibraryId) && !$nodeLibraryExists))
				// && ($itemRequest->getDeliveryLibraryId() == $myLibraryId) )
					$arrivable = true;

				$itemInventoryNumber = Prado::localize("inv: {inv}", array('inv' => $item->getCompleteInventoryNumber()));
			}

			$row['inv_number'] = $itemInventoryNumber;
			$row['Arrivable'] = $arrivable;
			$row['OwnerLibraryUrl'] = $ownerLibraryUrl;
			$row['OwnerLibraryString'] = $ownerLibraryString;

			$row['WantedUrl'] = $wantedUrl;
			$row['WantedText'] = $wantedText;
			$row['WantedImageUrl'] = $wantedImageUrl;
			$row['WantedPopupUrl'] = $wantedPopupUrl;

			$toolTip = '';
			$patron = $itemRequest->getPatron();
			
			if ($patron instanceof Patron)
			{
				$patronCompleteName = $patron->getCompleteName();
				$navigateUrl = "index.php?page=Circulation.PatronViewPage&id=" . $patron->getId();
			}
			else
			{
				$externalLibraryId = intval($itemRequest->getExternalLibraryId());
				$externalLibrary = LibraryPeer::retrieveByPK($externalLibraryId);
			
				if ($externalLibrary instanceof Library)
				{
					$patronCompleteName = $externalLibrary->getLabel(true, false, true, 30);
					$navigateUrl = "index.php?page=Library.LibraryViewPage&id=" . $externalLibrary->getLibraryId();
					$toolTip = $externalLibrary->getDescription() . ' (' . $externalLibrary->getConsortiaString() . ')';
				}
				else
				{
					$patronCompleteName = "(" . Prado::localize("senza nome") . ")";
					$navigateUrl = '';
				}
			}
			
			$row['PatronCompleteName'] = $patronCompleteName;
			$row['PatronNavigateUrl'] = $navigateUrl;
			$row['PatronNavigateUrlToolTip'] = $toolTip;

			$requestDate = Clavis::dateFormat($itemRequest->getRequestDate('U'), 'shortdate shorttime');
			$row['RequestDate'] = $requestDate;

			$expireDate = Clavis::dateFormat($itemRequest->getExpireDate('U'));
			$row['ExpireDate'] = $expireDate;

			$requestNote = $itemRequest->getRequestNote();
			$row['RequestNote'] = $requestNote;

			$requestId = $itemRequest->getId();
			$row['Id'] = $requestId;

			$row['DeliveryLibraryId'] = $itemRequest->getDeliveryLibraryId();
			$row['DeliveryLibraryString'] = $itemRequest->getDeliveryLibraryString();

			if (array_key_exists($requestId, $this->_checked))	   //(isset($this->_checked[$loanId]))
			{
				$checked = $this->_checked[$requestId];
			}
			else
			{
				$checked = false;
			}

			if ($this->_checked['all'])
				$checked = !$checked;

			$row['Checked'] = $checked;

			$data[] = $row;
		}

		$this->Grid->VirtualItemCount = $recCount;
		$this->Grid->setDataSource($data);
		$this->Grid->dataBind();

		$this->setDataSource($data);
	}

	public function onChangePage($sender, $param)
	{
		$this->Grid->setCurrentPage($param->NewPageIndex);
		$this->globalRefresh();
	}

	/**
	 * It returns whether the page permits that in this component
	 * we can have the functions that components inside popups have.
	 *
	 * @return boolean
	 */
	public function getPopupFlag()
	{
		return $this->getPage()->isPopup();
	}

	/**
	 * It returns whether the page permits that in this component
	 * we can have the unlink function.
	 *
	 * @return boolean
	 */
	public function getUnlinkFlag()
	{
		return $this->getPage()->isUnlink();
	}

	/**
	 * It returns whether the page permits that in this component
	 * we can have the delete function.
	 *
	 * @return boolean
	 */
	public function getDeleteFlag()
	{
		return $this->getPage()->isDelete();
	}

	/**
	 * This method, called for unlinking, calls the relative
	 * method of the parent page.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onUnlink($sender, $param)
	{
		$id = $param->CommandParameter;
		$this->GetPage()->Unlink($id);
	}

	public function resetPagination()
	{
		$this->Grid->setCurrentPage(0);
	}

	public function onActiveRequestChanged($sender, $param)
	{
		$this->resetPagination();
		$this->globalRefresh();
	}

	public function globalRefresh()
	{
		$this->getPage()->refreshExtraRequestsIn();
	}

	public function onArrived($sender, $param)
	{
		/** @var $itemRequest ItemRequest */
		$itemRequest = null;
		$requestId = intval($param->CommandParameter);

		if ($requestId > 0)
			$itemRequest = ItemRequestQuery::create()->findPK($requestId);

		if (!($itemRequest instanceof ItemRequest))
		{
			$this->getPage()->writeMessage(Prado::localize("Errore nel passaggio dei parametri, oppure la prenotazione con id: {id} non esiste più. Contattare il Centro Servizi.", array('id' => $requestId)),
											ClavisMessage::ERROR);
			
			return false;
		}

		$deliveryLibraryId = $itemRequest->getDeliveryLibraryId();
		$myLibraryId = $this->getUser()->getActualLibraryId();
		$interLoan = ($deliveryLibraryId != $myLibraryId);   // in the case of node library
		$item = $itemRequest->getItem();
		$ownerLibrary = $item->getOwnerLibrary();
		
		if (!($ownerLibrary instanceof Library))
		{
			$this->getPage()->writeMessage(Prado::localize("Incongruenza: l'esemplare non ha una biblioteca proprietaria valida"), ClavisMessage::ERROR);
			return false;
		}
		
		$consortiaString = $ownerLibrary->getConsortiaString();
		$update = false;
		
		switch ($this->_loanmanager->doAcceptFromExtra($item, $itemRequest, $this->getUser()))
		{
			case ClavisLoanManager::OK:

				if ($interLoan)
				{
					$this->getPage()->writeMessage(Prado::localize("L'esemplare '{title}', record id: {id}, è entrato dal sistema '{alienConsortia}' ed è stato messo nello stato di pronto al transito verso la biblioteca '{delivery}'", 
																		array(	'title' => $item->getTrimmedTitle(30),
																				'id' => $item->getItemId(),
																				'alienConsortia' => $consortiaString,
																				'delivery' => $itemRequest->getDeliveryLibraryString())),
													ClavisMessage::CONFIRM);
				}
				else
				{
					$this->getPage()->writeMessage(Prado::localize("L'esemplare '{title}', record id: {id}, è entrato dal sistema '{alienConsortia}' ed è stato messo nello stato di pronto al prestito all'utente '{patron}'", 
																		array(	'title' => $item->getTrimmedTitle(30),
																				'id' => $item->getItemId(),
																				'alienConsortia' => $consortiaString,
																				'patron' => $itemRequest->getPatronCompleteName())), 
													ClavisMessage::CONFIRM);
				}

				$update = true;
				
				break;

			case ClavisLoanManager::RSV_ALREADYCLOSED:
				$this->getPage()->writeMessage(Prado::localize("Errore: la prenotazione è già stata soddisfatta"), 
												ClavisMessage::ERROR);

				$update = true;
				
				break;

			case ClavisLoanManager::ERROR:
			default:
				$this->getPage()->writeMessage(Prado::localize("Errore generico su prenotazioni extra-sistema"), 
													ClavisMessage::ERROR);
		}

		if ($update)
			$this->getPage()->globalRefreshIn();
	}

	public function onResetRequestDate($sender, $param)
	{
		$this->RequestDateFrom->setText('');
		$this->RequestDateTo->setText('');

		if (!is_null($param))
			$this->RequestDatePanel->render($param->getNewWriter());
	}

	public function getMasterChecked()
	{
		$checked = $this->getChecked();
		
		return $checked['all'];
	}

	public function onMasterChecked($sender, $param)
	{
		$this->setMasterChecked($sender->getChecked(), $param);
	}

	public function setMasterChecked($newChecked = false, $param = null)
	{
		$this->resetChecked($newChecked);
		$gridItems = $this->Grid->getItems();
		$header = $this->Grid->getHeader();

		foreach ($gridItems as $item)
			$item->CheckColumn->CheckedBox->setChecked($newChecked);

		$header->CheckColumn->MasterCheck->setChecked($newChecked);
	}

	public function resetChecked($state = false)
	{
		$resetValue = array('all' => $state);
		$this->setChecked($resetValue);
		return $resetValue;
	}

	public function setChecked($checked = null)
	{
		$this->_checked = $checked;
		$this->getApplication()->getSession()->add($this->_checkedSessionName, $checked);
	}

	public function getChecked()
	{
		$this->_checked = $this->getApplication()->getSession()->itemAt($this->_checkedSessionName);
		
		if (is_null($this->_checked))
			$this->_checked = $this->resetChecked();

		return $this->_checked;
	}

	private function resetGlobalCriteria()
	{
		$this->setGlobalCriteria(null);
	}

	private function setGlobalCriteria($criteria = null)
	{
		$this->getApplication()->getSession()->add($this->_globalCriteriaSessionName, $criteria, null);
	}

	public function getGlobalCriteria()
	{
		$crit = $this->getApplication()->getSession()->itemAt($this->_globalCriteriaSessionName, null);

		if ($crit instanceof Criteria)
			$crit = SerializableCriteria::refreshCriteria($crit);

		return $crit;
	}

	public function onFlipChecked($sender, $param)
	{
		$newChecked = $sender->getChecked();
		$index = $sender->Parent->Parent->ItemIndex;
		$dataSource = $this->getDatasource();
		$checked = $this->getChecked();
		$row = $dataSource[$index];
		$id = $row['Id'];
		
		if ($newChecked != $checked['all'])
		{
			$checked[$id] = true;
		}
		else
		{
			unset($checked[$id]);
		}

		$this->setChecked($checked);
	}

	public function getCheckedItemIds($force = false, $reset = false)
	{
		$checked = $this->getChecked();
		$masterChecked = $checked['all'];
		unset($checked['all']);
		$checkedIds = array_keys($checked);

		$output = array();
		
		if (!$masterChecked)
		{
			$output = $checkedIds;
		}
		else		 // caso del mastercheck inverso
		{
			$criteria = $this->getGlobalCriteria();
			$ids = array();

			if (!is_null($criteria))
			{
				if ($criteria instanceof Criteria)
				{
					if (count($checked) > 0)
						$criteria->add(ItemRequestPeer::REQUEST_ID, $checkedIds, Criteria::NOT_IN);

					$criteria->clearSelectColumns();
					$criteria->addSelectColumn(ItemRequestPeer::REQUEST_ID);
					$pdo = ItemRequestPeer::doSelectStmt($criteria);
					
					while ($id = $pdo->fetchColumn())
						$ids[] = $id;
				}
				elseif (is_array($criteria) && (count($criteria) > 0))
				{
					$ids = $criteria;
				}
			}
			
			$output = $ids;
		}

		if ((count($output) == 0) 
				&& ($force == true))
		{
			$this->setMasterChecked(true);
			$output = $this->getCheckedItemIds();

			if ($reset)
				$this->setMasterChecked(false);
		}

		return $output;
	}

	public function countCheckedItemIds($force = false, $reset = false)
	{
		$checked = $this->getChecked();
		$masterChecked = $checked['all'];
		unset($checked['all']);
		$checkedIds = array_keys($checked);
		$output = 0;

		if (!$masterChecked)
		{
			$output = count($checkedIds);
		}
		else		 // caso del mastercheck inverso
		{
			$criteria = $this->getGlobalCriteria();

			if (!is_null($criteria))
			{
				if ($criteria instanceof Criteria)
				{
					if (count($checkedIds) > 0)
						$criteria->add(ItemRequestPeer::REQUEST_ID, $checkedIds, Criteria::NOT_IN);
			
					$output = ItemRequestPeer::doCount($criteria);
				}
				elseif (is_array($criteria))
				{
					$output = count($criteria);
				}
			}
		}

		if (($output == 0) 
				&& ($force == true))
		{
			$this->setMasterChecked(true);
			$output = $this->countCheckedItemIds();

			if ($reset)
				$this->setMasterChecked(false);
		}

		return $output;
	}

	public function getSortingExpression()
	{
		return $this->Grid->getSortingExpression();
	}

	public function getSortingDirection()
	{
		return $this->Grid->getSortingDirection();
	}
	
	public function onFromLibraryExtraClean($sender, $param)
	{
		$this->doFromLibraryExtraClean(true, $param);
	}

	private function doFromLibraryExtraClean()
	{
		//$this->ExternalLibraryId->setText(0);
		$this->FromLibraryExtraHiddenValue->setValue(null);
		$this->FromLibraryExtraHiddenLabel->setValue(null);
		$this->FromLibraryExtraLabel->setText('');
		$this->FromLibraryExtraId->setText('');
	}
	
	public function suggestFromLibraryExtra($sender, $param)
	{
		$token = $param->getCallBackParameter();
		$sender->setDataSource($this->getFromLibraryExtraSuggestionsFor($token));
		$sender->dataBind(false);
	}

	public function suggestFromLibraryExtraCallBack($sender, $param)
	{
		$resultFlag = false;
		$fieldText = $this->FromLibraryExtraLabel->getSafeText();
		$match = array();

		if (preg_match("/\[id:\ ([^\]]+)\]$/", $fieldText, $match))
		{
			$libraryId = $match[1];
		}
		else
		{
			$libraryId = $fieldText;
		}

		$libraryId = intval($libraryId);
		$library = LibraryQuery::create()->findPK($libraryId);

		if (!is_null($library))
		{
			$this->FromLibraryExtraLabel->setText($library->getLabel() . ' (' . $libraryId . ')');
			$this->FromLibraryExtraId->setText($library->getLibraryId());
		}
		else
		{
			//////$this->FromLibraryExtraLabel->setText('');
			$this->FromLibraryExtraId->setText('');
		}
	}

	private function getFromLibraryExtraSuggestionsFor($token)
	{
		$list = array();
		$criteria = new Criteria();

		$token = trim($token);
		
		if ($token != "")
		{
			$criteria->add(LibraryPeer::LABEL, "%" . $token . "%", Criteria::LIKE);
			$criteria->add(LibraryPeer::LIBRARY_INTERNAL, 1, Criteria::NOT_EQUAL);

			$criteria->setLimit(10);
			$criteria->addAscendingOrderByColumn(LibraryPeer::LABEL);
			$libraries = LibraryPeer::doSelect($criteria);

			foreach ($libraries as $library)
				$list[] = $library->getLabel() . " (" . $library->getConsortiaString(20) . ") [id: " . $library->getLibraryId() . "]";
		}

		return $list;
	}
	
	public function onFromLibraryExtraListChanged($sender, $param = null)
	{
		$library = null;
		
		$libraryId = (int) $this->FromLibraryExtraHiddenValue->getValue();
		if ($libraryId > 0)
			$library = LibraryQuery::create()->findPK($libraryId);
		
		if ($library instanceof Library)
		{
			$label = $library->getLabel() . ' (' . $libraryId . ')';
		}
		else
		{
			$label = '';			
		}
		
		$this->FromLibraryExtraLabel->setText($label);
		$this->FromLibraryExtraId->setText($libraryId);
	}
	
}