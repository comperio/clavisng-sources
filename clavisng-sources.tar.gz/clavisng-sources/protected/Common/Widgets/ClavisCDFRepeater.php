<?php
/**
 * ClavisCDFRepeater
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2009 ePortal Technologies
 */
class ClavisCDFRepeater extends TTemplateControl
{
	const MODE_VIEW = 'View';
	const MODE_EDIT = 'Edit';
	const LANGUAGE_DEFAULT = 'it_IT';
	const CDFSTATUS_ORIGINAL = 1;
	const CDFSTATUS_NEW = 2;
	const CDFSTATUS_UPDATED = 3;
	/** @var Manifestation */
	private $_manifestation;
	private $_fieldlist;

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (method_exists($this->getPage(), 'getManifestation'))
			$this->_manifestation = $this->getPage()->getManifestation();
		else
			throw new Exception('Page ' . $this->getPage()->getPagePath() . ' lacks a getManifestation() method.');

		$this->NewCDFDuplicateMessage->setVisible(false);

		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallback())
		{
			$fldlst = UnimarcLabelsQuery::create()
					->filterByLanguage($this->getApplication()->getGlobalization()->getCulture())
					->filterByFieldNumber($this->getFieldStart(), Criteria::GREATER_EQUAL)
					->filterByFieldNumber($this->getFieldEnd(), Criteria::LESS_EQUAL)
					->orderByFieldNumber()
					->find();
			if (count($fldlst) == 0)
				$fldlst = UnimarcLabelsQuery::create()
						->filterByLanguage(self::LANGUAGE_DEFAULT)
						->filterByFieldNumber($this->getFieldStart(), Criteria::GREATER_EQUAL)
						->filterByFieldNumber($this->getFieldEnd(), Criteria::LESS_EQUAL)
						->orderByFieldNumber()
						->find();
			$ds = array();
			foreach ($fldlst as $fld)
				if (!array_key_exists($fld->getFieldNumber(), $ds))
					$ds[$fld->getFieldNumber()] = array('fno'	 => $fld->getFieldNumber(),
						'flabel' => $fld->getLabel() . ' (' . $fld->getFieldNumber() . ')');
			$this->NewCDFList->setDataSource($ds);
			$this->NewCDFList->dataBind();
			$this->populate();
		} else if (!$this->getPage()->getIsCallback())
		{
			$this->_fieldlist = $this->getCDFList();
			$uidx = $this->UpdateCDFIdx->getValue();
			if ($uidx !== '')
			{
				$this->_fieldlist[$uidx] = unserialize($this->UpdateCDFField->getValue());
				if ($this->_fieldlist[$uidx]['status'] == self::CDFSTATUS_ORIGINAL)
					$this->_fieldlist[$uidx]['status'] = self::CDFSTATUS_UPDATED;
				$this->UpdateCDFIdx->setValue(null);
				$this->UpdateCDFField->setValue(null);
			}
			$this->bindData();
		}
	}

	public function bindData()
	{
		$this->CDFRepeater->setDataSource($this->_fieldlist);
		$this->CDFRepeater->dataBind();
		$this->setCDFList($this->_fieldlist);
	}

	public function itemDataBound($sender, $param)
	{
		$item = $param->Item;
		if ($item->ItemType === 'Item' || $item->ItemType === 'AlternatingItem')
		{
			$item->CDFVis->populate();
		}
	}

	public function populate()
	{
		$this->_fieldlist = ($this->_manifestation instanceof Manifestation) ?
				$this->_fieldlist = $this->_manifestation->getCDFs() :
				array();
		$cnt = count($this->_fieldlist);
		for ($i = 0; $i < $cnt; ++$i)
		{
			$this->_fieldlist[$i]['key'] = $i;
			$this->_fieldlist[$i]['status'] = self::CDFSTATUS_ORIGINAL;
		}
		$this->bindData();
	}

	public function setManifestation(Manifestation $manifestation)
	{
		$this->_manifestation = $manifestation;
	}

	/**
	 * Sets the visualization mode.
	 * Allowed values are 'View' and 'Edit'
	 *
	 * @param string $value The wanted mode
	 */
	public function setMode($value)
	{
		$this->setControlState('Mode', TPropertyValue::ensureEnum($value, array(self::MODE_EDIT, self::MODE_VIEW)), self::MODE_VIEW);
	}

	public function getMode()
	{
		return $this->getControlState('Mode', self::MODE_VIEW);
	}

	public function setFieldStart($value)
	{
		$this->setControlState('FieldStart', intval($value), 103);
	}

	public function getFieldStart()
	{
		return $this->getControlState('FieldStart', 103);
	}

	public function setFieldEnd($value)
	{
		$this->setControlState('FieldEnd', intval($value), 199);
	}

	public function getFieldEnd()
	{
		return $this->getControlState('FieldEnd', 199);
	}

	public function getNonRepeatable($fnum)
	{
		if (!TurboMarcMappings::$cdflist[$fnum]['rep']) // search for it in already defined fields
			foreach ($this->_fieldlist as $idx => $f)
				if ($f['fieldnum'] == $fnum)
					return $idx;
		return null;
	}

	public function addCDF($sender, $param)
	{
		$fnum = $this->NewCDFList->getSelectedValue();
		$idx = $this->getNonRepeatable($fnum);
		if ($idx !== null)
		{
			$this->NewCDFDuplicateMessage->setVisible(true);
		}
		else
		{
			$newkey = (count($this->CDFRepeater->getDataKeys()->toArray()) > 0 ) ?
					max($this->CDFRepeater->getDataKeys()->toArray()) + 1 : 0;
			$f = array(
				'key'		 => $newkey,
				'fieldnum'	 => $fnum,
				'fieldlabel' => UnimarcLabelsPeer::getFieldLabel($fnum),
				'subfields'	 => array(),
				'status'	 => self::CDFSTATUS_NEW);
			$this->_fieldlist[] = $f;
		}
		$this->bindData();
	}

	public function setCDFList(Array $fieldlist)
	{
		$this->setControlState('flist', $fieldlist, array());
	}

	public function getCDFList()
	{
		return $this->getControlState('flist', array());
	}

	public function itemAction($sender, $param)
	{
		unset($this->_fieldlist[$this->CDFRepeater->DataKeys[$param->Item->ItemIndex]]);
		$this->bindData();
	}
	
}