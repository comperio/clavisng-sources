<?php

/**
 * ClavisUnimarcfield class
 * 
 * This is a custom control which extends several types of controls (TextBox, or
 * DropDownList, or Autocomplete ...) depending upon the Field, Tag, and Pos
 * properties: a query from a database table (or similar) will decide the type
 * of the Prado component which will be used as the core control, according
 * to the given properties.
 * An override of the core control is always possible when the type of the control
 * will be specified in the "DesignMode" property.
 *
 * In a further life phase, this control will populate itself by reading some
 * parameters (i.e. UnimarcClass) and extracting data from the database or
 * some class, created at the application start.
 * 
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2009 Comperio srl
 * @version 2.7
 * @package Controls
 * @since 2.3
 */

class ClavisUnimarcField extends TCompositeControl implements IValidatable
{
	const MAXDROPDOWNVALUES = 5000;
	const TTEXTBOX = 'TextBox';
	const TDROPDOWNLIST = 'DropDownList';
	const TAUTOCOMPLETE = 'AutoComplete';
	const TLABEL = 'Label';

	private $_control;
	private $result_set = array();
	private $_design_built = false;

	/**
	 * Returns the value to be validated.
	 * This methid is required by IValidatable interface.
	 * @return mixed the value of the property to be validated.
	 */
	public function getValidationPropertyValue()
	{
		return $this->_control->getValidationPropertyValue();
	}

	/**
	 * Returns true if this control validated successfully.
	 * Defaults to true.
	 * @return bool wether this control validated successfully.
	 */
	public function getIsValid()
	{
		return $this->_control->getIsValid();
	}

	/**
	 * Sets wether the control is valid or not.
	 * @param $value
	 * @return bool|void
	 */
	public function setIsValid($value)
	{
		$this->_control->setIsValid($value);
	}

	function doDesignBuild()
	{
		if ($this->getPos() === '') {
			//non CDF-MV
			$dm = self::TTEXTBOX;
		} else {
			//CDF-MV
			$set = UnimarcCodesQuery::create()
					->filterByUnimarcType($this->getNamespace())
					->filterByLanguage($this->getApplication()->getGlobalization()->getCulture())
					->filterByFieldNumber($this->getField())
					->filterBySubfieldTag($this->getTag())
					->filterByPos($this->getPos())
					->find();
			$cnt = count($set);
			if ($cnt < 1) {
				throw new Exception("No corresponding UnimarcCode: field [{$this->getField()}] tag [{$this->getTag()}] pos [{$this->getPos()}]");
			} else if ($cnt == 1 && $set[0]->getCodeValue() == '') {
				$dm = self::TTEXTBOX;
				if (($ml = $set[0]->getFieldLength()) > 0)
					$this->setMaxLength($ml);
			} else {
				foreach ($set as $row)
					$this->result_set[$row->getCodeValue()] = $row->getLabel();
				/* if resultset is too big, make an autocomplete instead of
				 * a dropdown. */
				$dm = ($cnt > self::MAXDROPDOWNVALUES) ? self::TAUTOCOMPLETE : self::TDROPDOWNLIST;
			}
		}
		$this->setDesignMode($dm);
	}

	/**
	 * 'Namespace' property getter
	 *
	 * @return unknown
	 */
	public function getNamespace()
	{
		return $this->getControlState('namespace','U');
	}

	/**
	 * 'Namespace' property setter
	 *
	 * @param unknown_type $value
	 */
	public function setNamespace($value)
	{
		$this->setControlState('namespace',$value,'U');
	}

	/**
	 * 'Field' property getter
	 *
	 * @return unknown
	 */
	public function getField()
	{
		return $this->getControlState('field');
	}

	/**
	 * 'Field' property setter
	 *
	 * @param unknown_type $value
	 */
	public function setField($value)
	{
		$this->setControlState('field',$value);
	}

	/**
	 * 'Tag' property getter
	 *
	 * @return unknown
	 */
	public function getTag()
	{
		return $this->getControlState('tag','');
	}

	/**
	 * 'Tag' property setter
	 *
	 * @param unknown_type $value
	 */
	public function setTag($value)
	{
		$this->setControlState('tag',$value,'');
	}

	/**
	 * 'Pos' property getter
	 *
	 * @return unknown
	 */
	public function getPos()
	{
		return $this->getControlState('pos','');
	}

	/**
	 * 'Pos' property setter
	 *
	 * @param unknown_type $value
	 */
	public function setPos($value)
	{
		$this->setControlState('pos',$value,'');
	}

	/**
	 *
	 *
	 * @return boolean
	 */
	public function getHasBlank()
	{
		return $this->getControlState('HasBlank',true);
	}

	/**
	 *
	 *
	 * @param
	 */
	public function setHasBlank($value)
	{
		$this->setControlState('HasBlank',TPropertyValue::ensureBoolean($value),true);
	}

	/**
	 * 'Value' property getter
	 *
	 * @return unknown
	 */
	public function getValue()
	{
		if ($this->_control instanceof TTextBox) {
			$value = $this->_control->getSafeText();
		} else if ($this->_control instanceof TDropDownList) {
			$value = $this->_control->getSelectedValue();
		} else if ($this->_control instanceof TAutoComplete) {
			$value = $this->_control->getSafeText();
		} else if ($this->_control instanceof TLabel) {
			$value = $this->_control->getText();
		}
		return $value;
	}

	/**
	 * 'Value' property getter
	 *
	 * @param unknown_type $value
	 */
	public function setValue($value)
	{
		if ($this->_control instanceof TTextBox) {
			$this->_control->setText($value);
		} else if ($this->_control instanceof TDropDownList) {
			$this->_control->setSelectedValue($value);
		} else if ($this->_control instanceof TAutoComplete) {
			$this->_control->setText($value);
		} else if ($this->_control instanceof TLabel) {
			if ($this->result_set > 1) {
				$this->_control->setText($this->result_set[$value]);
			} else {
				$this->_control->setText($value);
			}
		}
	}

	/**
	 * 'DesignMode' property getter
	 *
	 * @return unknown
	 */
	public function getDesignMode()
	{
		if (!$this->_design_built) {
			$this->doDesignBuild();
			$this->_design_built = true;
		}
		return $this->getControlState('DesignMode',null);
	}

	/**
	 * 'DesignMode' property setter
	 *
	 * @param integer $value
	 */
	public function setDesignMode($value)
	{
		/* set DesignMode only if it has not been already set.
		 * This allows to force a specified design mode by the user. */
		if ($this->getControlState('DesignMode',null) == null)
			$this->setControlState('DesignMode',$value);
	}


	/**
	 * Enter description here...
	 *
	 * @param integer $value
	 */
	public function setColumns($value)
	{
		$this->setControlState('columns',$value,'');

		if ($this->_control instanceof TTextBox)
			$this->_control->setColumns($value);

	}

	public function setStyle($param = null)
	{
		$param = trim($param);
		$this->setControlState('customStyle', $param, '');
	}
	
	public function getStyle()
	{
		return $this->getControlState('customStyle', '');
	}
	
	/**
	 * Enter description here...
	 *
	 * @param integer $value
	 */
	public function setMaxLength($value)
	{
		$this->setControlState('maxlength',$value,'');

		if ($this->_control instanceof TTextBox)
			$this->_control->setMaxLength($value);
	}

	/**
	 * Enter description here...
	 *
	 * @return integer
	 */
	public function getMaxLength()
	{
		$maxlen = $this->getControlState('maxlength', '');
		return $maxlen;
	}

	/**
	 * override parent createChildControls()
	 *
	 */
	public function createChildControls()
	{
		switch ($this->getDesignMode())
		{
			case self::TDROPDOWNLIST:
				$this->_control = new TDropDownList();
				if ($this->getHasBlank())
					$arr = array(' ' => '---') + $this->result_set;
				else
					$arr = $this->result_set;
				$this->_control->setDataSource($arr);
				$this->_control->dataBind();
				$this->getControls()->add($this->_control);
				break;

			case self::TAUTOCOMPLETE:
				$this->_control = new TAutoComplete();
				//TODO: DATABIND
				$this->getControls()->add($this->_control);
				break;

			case self::TTEXTBOX:
				$this->_control = new TTextBox();
				$this->getControls()->add($this->_control);

				//$this->_control->setText($this->getValue());
				if ($ml = $this->getMaxLength()) {
					$this->_control->setMaxLength($ml);
					$this->_control->setColumns(floor($ml + ($ml / 2 )));
				}
				$this->_control->setColumns($this->getControlState('columns',''));

				break;
			case self::TLABEL:
			default:
				$this->_control = new TLabel();
				$this->getControls()->add($this->_control);
				break;
		}

		if (($style = $this->getStyle()) != '')
			$this->_control->setStyle($style);
	}

	/**
	 * Current object getter, for subproperties set/get
	 *
	 * @return unknown
	 */
	public function getControl()
	{
		$this->ensureChildControls();
		return $this->_control;
	}
}
