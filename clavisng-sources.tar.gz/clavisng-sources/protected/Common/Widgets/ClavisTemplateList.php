<?php
/**
 * ClavisTemplateList class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Ciro Mattia Gonano
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 ePortal Technologies
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Pages.Administration
 */

/**
 * ClavisTemplateList Class
 *
 * This page IS NOT a duplicate of the same found in Library module.
 * This one allows to edit every template, including system's ones.
 *
 * @author Ciro Mattia Gonano
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.8.6
 * @package Pages.Administration
 * @since 2.4.1
 */
class ClavisTemplateList extends TTemplateControl
{
	private $_supported_media = array(	DocumentTemplatePeer::MEDIA_EMAIL,
										DocumentTemplatePeer::MEDIA_SMS );
	
	private $_ModeSessionName;
	private $_MediaSessionName;
	private $_LanguageSessionName;
	
	public function __construct()
	{
		parent::__construct();
		
		$uniqueId = $this->getUniqueID();
		$this->_ModeSessionName = 'ModeSessionName' . $uniqueId;
		$this->_MediaSessionName = 'MediaSessionName' . $uniqueId;
		$this->_LanguageSessionName = 'LanguageSessionName' . $uniqueId;
	}

	public function onInit($param)
	{
		parent::onInit($param);
		$this->attachEventHandler('OnActualLibraryChanged', array($this, 'OnActualLibraryChanged'));
	}

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsPostBack()
				&& !$this->getPage()->getIsCallback())
		{
			$this->populate();
		}
	}

	public function OnActualLibraryChanged($sender, $param)
	{
		$this->populate();
	}

	public function getMedia()
	{
		return $this->getControlState($this->_MediaSessionName, null);
	}

	public function setMedia($value)
	{
		$this->setControlState($this->_MediaSessionName, TPropertyValue::ensureEnum($value, $this->_supported_media), null);
	}

	public function getLanguage()
	{
		return $this->getControlState($this->_LanguageSessionName, $this->getApplication()->getGlobalization()->getCulture());
	}

	public function setLanguage($value)
	{
		$this->setControlState($this->_LanguageSessionName, $value, $this->getApplication()->getGlobalization()->getCulture());
	}

	public function getMode()
	{
		return $this->getControlState($this->_ModeSessionName, 'library');
	}

	public function setMode($value)
	{
		$this->setControlState($this->_ModeSessionName, TPropertyValue::ensureEnum($value, array('library', 'admin')), 'library');
	}

	public function populate()
	{
		$c = new Criteria();
		$c->add(DocumentTemplatePeer::TEMPLATE_LANG, $this->getLanguage());
		$media = $this->getMedia();
		
		if ($media)
		{
			$c->add(DocumentTemplatePeer::TEMPLATE_MEDIA, $media);
		}
		else
		{
			// Jasper template have to be managed by another module
			$c->add(DocumentTemplatePeer::TEMPLATE_MEDIA, DocumentTemplatePeer::MEDIA_JASPER, Criteria::NOT_EQUAL);
		}

		$c->addAscendingOrderByColumn(DocumentTemplatePeer::TEMPLATE_CLASS);
		$c->addDescendingOrderByColumn(DocumentTemplatePeer::LIBRARY_ID);
		$c->addAscendingOrderByColumn(DocumentTemplatePeer::TEMPLATE_TITLE);

		switch ($this->getMode())
		{
			case 'admin':
				$c->add(DocumentTemplatePeer::LIBRARY_ID, null);
				break;

			case 'library':
			default:
				$crit1 = $c->getNewCriterion(DocumentTemplatePeer::LIBRARY_ID, $this->getUser()->getActualLibraryId());
				$crit1->addOr($c->getNewCriterion(DocumentTemplatePeer::LIBRARY_ID, null));
				$c->add($crit1);
				break;
		}

		$tpls = DocumentTemplatePeer::doSelect($c);
		$this->TplList->setDataSource($tpls);
		$this->TplList->dataBind();
	}

	public function getPopupFlag()
	{
		return $this->getPage()->IsPopup();
	}

	/*
	public function onItemDataBound($sender, $param)	// deprecated
	{
		$item = $param->Item;
		
		if ($item->ItemType === 'EditItem' OR true)
		{
//			var_dump($item->Data);
			var_dump($this->_ModeSessionName);
		}
	}
	 */

	public function cancelItem($sender, $param)
	{
		$this->TplList->SelectedItemIndex = -1;
		$this->TplList->EditItemIndex = -1;
		
		//$this->populate();
		$this->getPage()->globalRefresh();
	}

	public function editItem($sender, $param)
	{
		$this->TplList->SelectedItemIndex = -1;
		$tpl = DocumentTemplatePeer::retrieveByPK($this->TplList->DataKeys[$param->Item->ItemIndex]);
		if (($this->getMode() != 'admin') 
				&& ($tpl->getLibraryId() < 1))
		{
			$newtpl = $tpl->copy();
			$newtpl->setLibraryId($this->getUser()->getActualLibraryId());
			$newtpl->setTemplateLang($this->getLanguage());
			$newtpl->setCreatedBy($this->getUser()->getID());
			$newtpl->setModifiedBy($this->getUser()->getID());
			$newtpl->setDateCreated(time());
			$newtpl->setDateUpdated(time());
			$newtpl->save();
			$this->TplList->EditItemIndex = -1;
		}
		else
		{
			$this->TplList->EditItemIndex = $param->Item->ItemIndex;
		}
		
		//////$this->populate();
		$this->getPage()->globalRefresh();
	}

	public function deleteItem($sender, $param)
	{
		$item = $param->Item;
		try
		{
			$tpl = DocumentTemplateQuery::create()->findPk($this->TplList->DataKeys[$item->ItemIndex]);
			$tpl->delete();
			$this->TplList->EditItemIndex = -1;
			$this->TplList->SelectedItemIndex = -1;
			$this->getPage()->writeMessage(Prado::localize('Modello eliminato.'), ClavisMessage::CONFIRM);
		}
		catch (Exception $e)
		{
			$this->getPage()->writeMessage(Prado::localize('Impossibile eliminare il modello: {msg}', array('msg' => $e->getMessage())), ClavisMessage::CONFIRM);
		}
		
		//////$this->populate();
		$this->getPage()->globalRefresh();
	}

	public function selectItem($sender, $param)
	{
		$this->TplList->EditItemIndex = -1;
		
		//////////$this->populate();
		$this->getPage()->globalRefresh();
	}

	public function updateItem($sender, $param)
	{
		$item = $param->Item;
		try
		{
			$tpl = DocumentTemplateQuery::create()->findPk($this->TplList->DataKeys[$item->ItemIndex]);

			if (!$tpl instanceof DocumentTemplate)
				throw new Exception('Error in retrieving template');
			$tpl->setTemplateTitle($item->TemplateTitle->getText());
			$tpl->setTemplateSubject($item->TemplateSubject->getText());
			$tpl->setTemplateBody($item->TemplateBody->getText());
			$tpl->setDateUpdated(time());
			$tpl->setModifiedBy($this->getUser()->getID());
			$tpl->save();
			$this->TplList->EditItemIndex = -1;
			$this->TplList->SelectedItemIndex = $item->ItemIndex;
			$this->getPage()->writeMessage(Prado::localize('Modello correttamente aggiornato.'), ClavisMessage::CONFIRM);
		}
		catch (Exception $e)
		{
			$this->getPage()->writeMessage(Prado::localize('Impossibile completare l\'aggiornamento: {msg}', array('msg' => $e->getMessage())), ClavisMessage::ERROR);
		}
		
		//////////////$this->populate();
		$this->getPage()->globalRefresh();
	}
	
}