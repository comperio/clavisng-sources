<?php

class ClavisPopupNotificationOptions extends TTemplateControl
{

	private $_readOnly;

	// -----------------------------------------------------------------------------------------------------------------
	// Prado's events reactions
	// -----------------------------------------------------------------------------------------------------------------
	public function onLoad($params)
	{
		parent::onLoad($params);
		$this->onEnablePopupNotification($this, null);
	}

	// -----------------------------------------------------------------------------------------------------------------
	// Component's property management
	// -----------------------------------------------------------------------------------------------------------------
	public function getReadOnly()
	{
		return $this->_readOnly;
	}

	public function setReadOnly($value)
	{
		$this->_readOnly = TPropertyValue::ensureBoolean($value);
	}

	// -----------------------------------------------------------------------------------------------------------------
	// Component own methods
	// -----------------------------------------------------------------------------------------------------------------
	public function init($librarian)
	{
		$this->setNotificationPopupOptions($librarian);
	}

	/**
	 */
	public function saveLibrarianNotificationPreferences($librarian)
	{
		if ($librarian instanceof Librarian) {
			$prefs = unserialize($librarian->getPreferences());
			$notificationPrefs = $this->getNotificationPopupOptions();
			$prefs['popupNotification'] = $notificationPrefs;

			$librarian->savePreferences($prefs);
			$librarian->save();
		}
	}

	/**
	 */
	public function onEnablePopupNotification($sender, $param)
	{
		$checked = $this->EnablePopupNotification->getChecked();
		$isReadOnly = $this->getReadOnly();
		$isEnabled = $checked && !$isReadOnly;

		$this->EnablePopupNotification->setEnabled(!$isReadOnly);
		$this->SoundOnErrorNotification->setEnabled($isEnabled);
		$this->SoundOnWarningNotification->setEnabled($isEnabled);
		$this->ShowPersistentNotifications->setEnabled($isEnabled);
		$this->StickyNotification->setEnabled(!$this->ShowPersistentNotifications->getChecked() && $isEnabled);
		$this->BottomRightNotification->setEnabled($isEnabled);
		$this->TimeNotificationSeconds->setEnabled($isEnabled);

		// see https://github.com/pradosoft/prado/issues/644#issuecomment-297924087
		if ($param) {
			$this->CheckBoxContainer->render($param->getNewWriter());
		}
	}

	/**
	 * @param $sender
	 * @param $params
	 */
	public function onShowPersistentNotifications($sender, $params)
	{
		if ($this->ShowPersistentNotifications->getChecked()) {
			$this->hideOnShowPersistentNotifications->setStyle('display: none;');
		} else {
			$this->hideOnShowPersistentNotifications->setStyle('display: inline;');
		}
	}

	/**
	 * @param \Librarian $librarian
	 * @return array
	 */
	private function getNotificationPreferences(Librarian $librarian)
	{
		$prefs = unserialize($librarian->getPreferences());

		return (is_array($prefs['popupNotification']))
			? $prefs['popupNotification']
			: ClavisNotificationEvent::getUserDefaultNotificationOption(true);
	}

	/**
	 * @param \Librarian $librarian
	 */
	private function setNotificationPopupOptions(Librarian $librarian)
	{
		if ($librarian instanceof Librarian) {
			$boolPrefs = $this->getNotificationPreferences($librarian);

			$this->EnablePopupNotification->setChecked($boolPrefs['enabled']);
			$this->SoundOnErrorNotification->setChecked($boolPrefs['soundOnError']);
			$this->SoundOnWarningNotification->setChecked($boolPrefs['soundOnWarning']);
			$this->ShowPersistentNotifications->setChecked($boolPrefs['size']);
			$this->StickyNotification->setChecked($boolPrefs['delay']);
			$this->BottomRightNotification->setChecked($boolPrefs['position']);

			$this->TimeNotificationSeconds->setText((int)($boolPrefs['delay_time'] / 1000));
		}
	}

	/**
	 * @return mixed
	 */
	private function getNotificationPopupOptions()
	{
		$boolPrefs['enabled'] = $this->EnablePopupNotification->getChecked();
		$boolPrefs['soundOnError'] = $this->SoundOnErrorNotification->getChecked();
		$boolPrefs['soundOnWarning'] = $this->SoundOnWarningNotification->getChecked();
		$boolPrefs['size'] = $this->ShowPersistentNotifications->getChecked();
		$boolPrefs['delay'] = $this->StickyNotification->getChecked();
		$boolPrefs['position'] = $this->BottomRightNotification->getChecked();

		$boolPrefs['delay_time'] = $this->TimeNotificationSeconds->getText() * 1000;

		return $boolPrefs;
	}
}