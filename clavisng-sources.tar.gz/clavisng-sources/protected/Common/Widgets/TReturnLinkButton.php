<?php
/**
 * TReturnLinkButton
 *
 * This extends a Prado TLinkButton, which is put in an iframe,
 * with the capabilities to pass the 2 standard parameters
 * (label and value) back to the opener page.
 * The parameter Update (default true) permits the postback
 * commit of opener page.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2008 ePortal Technologies
 * @copyright Copyright &copy; 2009-2013 Comperio srl
 * @version 2.7
 * @package Controls
 * @since 2.0
 */

class TReturnLinkButton extends TLinkButton
{
	/**
	 * Registers the javascript code and publishes in the
	 * Prado assets directory.
	 *
	 * @param TEventParameter $param
	 */
	public function onPreRender($param)
	{
		parent::onPreRender($param);

		$scripts = $this->getPage()->getClientScript();
		$scripts->registerPradoScript('prado');
		$scripts->registerPradoScript('effects');
		if (!$scripts->isScriptFileRegistered('ButtonFunctions.js'))
			$scripts->registerScriptFile('ButtonFunctions.js',
				$this->publishFilePath(Prado::getPathOfNamespace('Application.Javascript')).'/ButtonFunctions.js');
	}


	/**
	 * Sets the label string to return to opener page.
	 *
	 * @param string $label
	 */
	public function setReturnLabel($label)
	{
		$this->setControlState('ReturnLabel', $label, '');
	}

	/**
	 * Returns the label.
	 *
	 * @return string
	 */
	public function getReturnLabel()
	{
		return $this->getControlState('ReturnLabel', '');
	}

	/**
	 * Sets the value to return to opener page.
	 *
	 * @param mixed $value
	 */
	public function setReturnValue($value)
	{
		$this->setControlState('ReturnValue', $value, '');
	}

	/**
	 * Returns the value.
	 *
	 * @return mixed
	 */
	public function getReturnValue()
	{
		return $this->getControlState('ReturnValue', '');
	}

	/**
	 * Sets the label string to return to opener page.
	 *
	 * @param string $label
	 */
	public function setReturnLabel2($label)
	{
		$this->setControlState('ReturnLabel2', $label, '');
	}

	/**
	 * Returns the label.
	 *
	 * @return string
	 */
	public function getReturnLabel2()
	{
		return $this->getControlState('ReturnLabel2', '');
	}

	/**
	 * Sets the value to return to opener page.
	 *
	 * @param mixed $value
	 */
	public function setReturnValue2($value)
	{
		$this->setControlState('ReturnValue2', $value, '');
	}

	/**
	 * Returns the value.
	 *
	 * @return mixed
	 */
	public function getReturnValue2()
	{
		return $this->getControlState('ReturnValue2', '');
	}


	/**
	 * It specifies, when the button is pressed, whether the opener page has to have a postback commit or not.
	 * Default is true.
	 *
	 * @param string $boolString
	 */
	public function setUpdate($flag = 'true')
	{
		if ((is_numeric($flag) && ($flag == 1)) || (is_bool($flag) && ($flag == true)))
			$flag = 'true';
		elseif ((is_numeric($flag) && ($flag != 1)) || (is_bool($flag) && ($flag == false)))
			$flag = 'false';

		$this->setControlState('Update', strtolower($flag), 'true');
	}

	public function getUpdate()
	{
		return $this->getControlState('Update', "true");
	}

/**
	 * Specify a callback function to call on popup closing.
	 *
	 * @param string $function The callback function, defaults to ''.
	 */
	public function setCallbackFunction($function) {
		$this->setControlState('CallbackFunction', $function, '');
	}

	/**
	 * Returns the callback function to call on popup closing.
	 *
	 * @return string The callback function, defaults to ''.
	 */
	public function getCallbackFunction() {
		return $this->getControlState('CallbackFunction','');
	}

	/**
	 * Extends the Prado method which attaches an attribute
	 * to a control, so to add the "onclick" attribute which
	 * will point to the javascript function which returns the
	 * parametes "label" and "value" to the opener page.
	 *
	 * @param THtmlWriter $writer
	 */
	protected function addAttributesToRender($writer)
	{
		$paramString = 'onReturn(';

		$label = trim(str_replace("'", "\'",$this->getReturnLabel()));
		// in order not to break js we need to remove any of these chars
		$label = str_replace (array("\r\n", "\n", "\r"), ' ', $label);
		$paramString .= "'{$label}',";

		$value = $this->getReturnValue();
		$paramString .= "'{$value}',";

		$paramString .= $this->getUpdate().',';

		$label2 = trim(str_replace("'", "\'",$this->getReturnLabel2()));
		// in order not to break js we need to remove any of these chars
		$label2 = str_replace (array("\r\n", "\n", "\r"), ' ', $label2);

		$paramString .= "'{$label2}',";

		$value2 = $this->getReturnValue2();
		$paramString .= "'{$value2}'";

		$paramString .= '); return false;';

		$writer->addAttribute('onclick', $paramString);
		parent::addAttributesToRender($writer);
	}
}
