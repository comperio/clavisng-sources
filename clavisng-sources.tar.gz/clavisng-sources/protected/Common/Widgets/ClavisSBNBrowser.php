<?php
/**
 * ClavisSBNBrowser class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Widgets
 */

/**
 * ClavisSBNBrowser Class
 *
 * Widget to browser through SBN index.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Widgets
 * @since 2.5.1
 */
class ClavisSBNBrowser extends TTemplateControl
{
	/* @var ClavisSBN */
	public $_sbnMod;
	private $lookup_bl;

	public function onLoad($param)
	{
		parent::onLoad($param);
		$this->_sbnMod = $this->getApplication()->getModule('sbn');
		if (!$this->_sbnMod instanceof TModule ||
			!$this->_sbnMod->getEnabled())
		{
			//$this->SBNNotEnabled->setVisible(true);
			//$this->SBNEnabled->setVisible(false);
			return;
		}

		/* preload lookups for biblevel */
		$this->lookup_bl = LookupValuePeer::getLookupClassValues('LIVBIBL');

		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallback()) {
			$this->populate();
			$this->dataBind();
		}
	}

	public function completePager($sender,$param) {
		$pager = $param->Pager->getControls();
		$pager->add(' / ' . $this->ResultGrid->getPageCount());

		$label = new TLabel();
		$label->setID('PageRowsLabel');
		$label->setText(Prado::localize('num.righe').' ');
		$label->setCssClass("viewlabel4small");
		$pager->insertAt(0,$label);

		$pageSizeSelect = new TDropDownList();
		$pageSizeSelect->setID('PageRows');
		$pageSizeSelect->setAutoPostBack(true);
		foreach(array(10, 20, 50, 100) as $value) {
			$element = new TListItem();
			$element->setText($value);
			$element->setValue($value);
			$pageSizeSelect->getItems()->add($element);
		}
        $pageSizeSelect->setSelectedValue(100);

		if (($pageSize = $this->ResultGrid->getPageSize()) > 0)
			$pageSizeSelect->setSelectedValue($pageSize);
		$pager->insertAt(1,$pageSizeSelect);
		$pageSizeSelect->attachEventHandler('OnSelectedIndexChanged', array($this, 'onChangePageSize'));
		$pager->insertAt(2,' | ');
	}

	public function reset() {
		$this->updateSelectionPanel();
	}

	public function onSelectDocMaterial($sender, $param)
	{
		// reset options
		$this->AntiqueFingerprint_1->setText('');
		$this->AntiqueFingerprint_2->setText('');
		$this->AntiqueFingerprint_3->setText('');
		$this->AntiqueFingerprint_4->setText('');
		$this->Fingerprint->setVisible(false);
		$this->AntiqueOptionsPanel->setVisible(false);
		$this->T123->setVisible(false);
		$this->CartographicOptionsPanel->setVisible(false);
		$this->GraphicOptionsPanel->setVisible(false);

		switch ($this->DocMaterial->getSelectedValue())
		{
			case SBNTypes::DOCTYPE_ANTICO:
				$this->Fingerprint->setVisible(true);
				$this->AntiqueOptionsPanel->setVisible(true);
				break;

			case SBNTypes::DOCTYPE_CARTOGRAFICO:
				$this->T123->setVisible(true);
				$this->CartographicOptionsPanel->setVisible(true);
				break;

			case SBNTypes::DOCTYPE_GRAFICO:
				$this->GraphicOptionsPanel->setVisible(true);
				break;

			default:
				break;
		}
		$this->SearchPanel->dataBind();
	}

	public function cleanSearch($sender, $param) {
		$this->SearchAuth->setDataSource(array(
			array(
				'AuthText'	=> '',
				'AuthType'	=> 'AU',
				'AuthRelatorCode'	=> '',
				'AuthResp'	=> '')));
		$this->SearchAuth->dataBind();
		$this->LinkId->setText('');
		$this->Bid->setText('');
		$this->Title->setText('');
		$this->Numbers->setText('');
		$this->ResultId->setValue(null);
		$this->DocMaterial->setSelectedIndex(-1);
		$this->Nature->setSelectedIndex(-1);
		$this->LinkSubtype->setSelectedIndex(-1);
		$this->T100_9_from->setText('');
		$this->T100_9_to->setText('');
		$this->T100_13_from->setText('');
		$this->T100_13_to->setText('');
		$this->T005RangeFrom->setText('');
		$this->T005RangeTo->setText('');
		$this->Language->getSelectedIndex(-1);
		$this->Country->setSelectedIndex(-1);
		$this->Sorting->setSelectedIndex(0);
		$this->reloadSearch();
	}

	public function doSearch($sender, $param) {
		$this->ResultGrid->setCurrentPageIndex(0);
		$this->ResultId->setValue(null);
		$this->reloadSearch();
	}

	public function onChangePage($sender, $param) {
		$this->ResultGrid->setCurrentPageIndex($param->NewPageIndex);
		$this->reloadSearch();
	}

	public function onChangePageSize($sender, $param) {
		$start = $this->ResultGrid->getCurrentPageIndex() * $this->ResultGrid->getPageSize();
		if (($newPageSize = intval($sender->getSelectedValue())) > 0) {
			$this->ResultGrid->setPageSize($newPageSize);
			$this->ResultGrid->setCurrentPageIndex(0);
			$this->ResultId->setValue(null);
			$this->reloadSearch();
		}
	}

	public function onChangeSorting($sender, $param) {
		$this->setViewState('Sorting', $sender->getSelectedValue());
		$this->reloadSearch();
	}

	public function reloadSearch()
	{
		$this->SbnErrorPanel->setVisible(false);
		$searchAuths = array();
		foreach ($this->SearchAuth->getItems() as $i)
			if (trim($i->AuthText->getText()))
				$searchAuths[] = array(
					'AuthText'	=> $i->AuthText->getText(),
					'AuthType'	=> $i->AuthType->getSelectedValue(),
					'AuthRelatorCode'	=> $i->AuthRelatorCode->getSelectedIndex() > 0 ? $i->AuthRelatorCode->getSelectedValue() : '',
					'AuthResp'	=> $i->AuthResp->getSelectedIndex() > 0 ? $i->AuthResp->getSelectedValue() : '');
		if (empty($searchAuths)) {
			$this->SearchAuth->setDataSource(array(
				array(
					'AuthText'	=> '',
					'AuthType'	=> 'AU',
					'AuthRelatorCode'	=> '',
					'AuthResp'	=> '')));
			$this->SearchAuth->dataBind();
		}

		$req = $this->_sbnMod->getNewRequest();
		if ($this->ResultId->getValue() != null)
			$req->setSearchId($this->ResultId->getValue());
		if ($this->DocMaterial->getSelectedIndex() > 0)
			$req->searchTitleOptions['tipoMateriale'] = $this->DocMaterial->getSelectedValue();
		if ($this->Nature->getSelectedIndex() > 0)
			$req->searchTitleOptions['naturaSbn'] = $this->Nature->getSelectedValue();
		if (isset($req->searchTitleOptions['naturaSbn']) && 'D' == $req->searchTitleOptions['naturaSbn'] &&
				$this->LinkSubtype->getSelectedIndex() > 0)
			$req->searchTitleOptions['sottoTipoLegame'] = $this->LinkSubtype->getSelectedValue();
		$dates = array(
			'from_9' => $this->T100_9_from->getText(),
			'to_9' => $this->T100_9_to->getText(),
			'from_13' => $this->T100_13_from->getText(),
			'to_13' => $this->T100_13_to->getText(),
		);
		if (!$dates['to_9']) {
			$dates['to_9'] = $dates['from_9'];
			$this->T100_9_to->setText($dates['from_9']);
		}
		if (!$dates['to_13']) {
			$dates['to_13'] = $dates['from_13'];
			$this->T100_13_to->setText($dates['from_13']);
		}
		$tmparr = array();
		if ($dates['from_9'])
			$tmparr['a_100_9'] = $dates['from_9'];
		if ($dates['from_13'])
			$tmparr['a_100_13'] = $dates['from_13'];
		if (!empty($tmparr))
			$req->searchTitleOptions['T100_Da'] = $tmparr;
		$tmparr = array();
		if ($dates['to_9'])
			$tmparr['a_100_9'] = $dates['to_9'];
		if ($dates['to_13'])
			$tmparr['a_100_13'] = $dates['to_13'];
		if (!empty($tmparr))
			$req->searchTitleOptions['T100_A'] = $tmparr;
		$tmparr = array();
		if ($df=$this->T005RangeFrom->getText())
			$tmparr['dataDa'] = date_create($df)->format('Y-m-d');
		if ($df=$this->T005RangeTo->getText())
			$tmparr['dataA'] = date_create($df)->format('Y-m-d');
		if (!empty($tmparr)) {
			if (!isset($tmparr['dataA'])) {
				$tmparr['dataA'] = date('Y-m-d');
				$this->T005RangeTo->setTimeStamp(time());
			}
			if (!isset($tmparr['dataDa'])) {
				$tmparr['dataDa'] = $tmparr['dataA'];
				$this->T005RangeFrom->setTimeStamp(strtotime($tmparr['dataA']));
			}
			$req->searchTitleOptions['T005_Range'] = $tmparr;
		}
		if ($this->Language->getSelectedIndex() > 0)
			$req->searchTitleOptions['T101'] = array('a_101' => strtoupper($this->Language->getSelectedValue()));
		if ($this->Country->getSelectedIndex() > 0)
			$req->searchTitleOptions['T102'] = array('a_102' => strtoupper($this->Country->getSelectedValue()));

		if (isset($req->searchTitleOptions['tipoMateriale']))
			switch ($req->searchTitleOptions['tipoMateriale']) {

				case SBNTypes::DOCTYPE_ANTICO:	// DocAntico
					$req->searchTitleOptions['T140'] = array();
					if ($this->Antique140_1->getValue() != ' ')
						$req->searchTitleOptions['T140'][] = array('a_140_9' => $this->Antique140_1->getValue());
					if ($this->Antique140_2->getValue() != ' ')
						$req->searchTitleOptions['T140'][] = array('a_140_9' => $this->Antique140_2->getValue());
					if ($this->Antique140_3->getValue() != ' ')
						$req->searchTitleOptions['T140'][] = array('a_140_9' => $this->Antique140_3->getValue());
					if ($this->Antique140_4->getValue() != ' ')
						$req->searchTitleOptions['T140'][] = array('a_140_9' => $this->Antique140_4->getValue());
					if (count($req->searchTitleOptions['T140']) < 1)
						unset($req->searchTitleOptions['T140']);
					break;

				case SBNTypes::DOCTYPE_CARTOGRAFICO:
					$req->searchTitleOptions['T120'] = array();
					if ($this->F120_0->getValue() != ' ')
						$req->searchTitleOptions['T120']['a_120_0'] = $this->F120_0->getValue();
					if ($this->F120_9->getValue() != ' ')
						$req->searchTitleOptions['T120']['a_120_9'] = $this->F120_9->getValue();
					if (!count($req->searchTitleOptions['T120']))
						unset($req->searchTitleOptions['T120']);
					break;

				case SBNTypes::DOCTYPE_GRAFICO:
					$req->searchTitleOptions['T116'] = array();
					if ($this->F116_0->getValue() != ' ')
						$req->searchTitleOptions['T116']['a_116_0'] = $this->F116_0->getValue();
					if ($this->F116_1->getValue() != ' ')
						$req->searchTitleOptions['T116']['a_116_1'] = $this->F116_1->getValue();
					if ($this->F116_3->getValue() != ' ')
						$req->searchTitleOptions['T116']['a_116_3'] = $this->F116_3->getValue();
					if ($this->F116_4->getValue() != ' ')
						$req->searchTitleOptions['T116']['a_116_4'] = array('a_116_4' => $this->F116_4->getValue());
					if ($this->F116_6->getValue() != ' ')
						$req->searchTitleOptions['T116']['a_116_6'] = array('a_116_4' => $this->F116_6->getValue());
					if ($this->F116_8->getValue() != ' ')
						$req->searchTitleOptions['T116']['a_116_8'] = array('a_116_4' => $this->F116_8->getValue());
					if ($this->F116_10->getValue() != ' ')
						$req->searchTitleOptions['T116']['a_116_10'] = array('a_116_10' => $this->F116_10->getValue());
					if ($this->F116_12->getValue() != ' ')
						$req->searchTitleOptions['T116']['a_116_12'] = array('a_116_10' => $this->F116_12->getValue());
					if ($this->F116_14->getValue() != ' ')
						$req->searchTitleOptions['T116']['a_116_14'] = array('a_116_10' => $this->F116_14->getValue());
					if ($this->F116_16->getValue() != ' ')
						$req->searchTitleOptions['T116']['a_116_16'] = $this->F116_16->getValue();
					if (!count($req->searchTitleOptions['T116']))
						unset($req->searchTitleOptions['T116']);
					break;

				default:
					break;
			}

		foreach ($searchAuths as $auth) {
			$elementoAutLegato = array(
				'tipoAuthority'			=> $auth['AuthType'],
				'canaliCercaDatiAut'	=> array(
					'searchValue'	=> $auth['AuthText'],
					'searchType'	=> SBNTypes::SEARCHOP_LIKE
				),
			);
			if ($auth['AuthRelatorCode'])
				$elementoAutLegato['relatorCode'] = $auth['AuthRelatorCode'];
			if ($auth['AuthResp'])
				$elementoAutLegato['tipoRespons'] = $auth['AuthResp'];
			$req->searchTitleOptions['elementoAutLegato'] = $elementoAutLegato;
		}

		$req->setSearchSortType($this->Sorting->getSelectedValue());
		$req->setSearchLimit($this->ResultGrid->getPageSize());
		$req->setSearchOffset($this->ResultGrid->getCurrentPageIndex() + 1);
		$this->MissingMainFieldError->setVisible(false);

		if ($this->AntiqueFingerprint_1->getText() != '' ||
				$this->AntiqueFingerprint_2->getText() != '' ||
				$this->AntiqueFingerprint_3->getText() != '')
		{
			$req->searchTitleOptions['T012'] = array();
			if ($this->AntiqueFingerprint_1->getText() != '')
				$req->searchTitleOptions['T012']['a_012_1'] = $this->AntiqueFingerprint_1->getText();
			if ($this->AntiqueFingerprint_2->getText() != '')
				$req->searchTitleOptions['T012']['a_012_2'] = $this->AntiqueFingerprint_2->getText();
			if ($this->AntiqueFingerprint_3->getText() != '')
				$req->searchTitleOptions['T012']['a_012_3'] = $this->AntiqueFingerprint_3->getText();
			if ($this->AntiqueFingerprint_4->getText() != '')
				$req->searchTitleOptions['T012']['nota'] = $this->AntiqueFingerprint_4->getText();
			$ret = $req->searchTitle(null);
		} else if ($this->F123_d->getText()) {
			$req->searchTitleOptions['T123'] = array();
			if ($this->F123_0->getValue() != ' ')
				$req->searchTitleOptions['T123']['id1'] = $this->F123_0->getValue();
			if ($this->F123_a->getValue() != ' ')
				$req->searchTitleOptions['T123']['a_123'] = $this->F123_a->getValue();
			if ($this->F123_b->getValue() != '')
				$req->searchTitleOptions['T123']['b_123'] = $this->F123_b->getValue();
			if ($this->F123_c->getValue() != '')
				$req->searchTitleOptions['T123']['c_123'] = $this->F123_c->getValue();
			if ($this->F123_d->getText() != '')
				$req->searchTitleOptions['T123']['d_123'] = $this->F123_d->getText();
			if ($this->F123_e->getText() != '')
				$req->searchTitleOptions['T123']['e_123'] = $this->F123_e->getText();
			if ($this->F123_f->getText() != '')
				$req->searchTitleOptions['T123']['f_123'] = $this->F123_f->getText();
			if ($this->F123_g->getText() != '')
				$req->searchTitleOptions['T123']['g_123'] = $this->F123_g->getText();
			$ret = $req->searchTitle(null);
		} else if ($v = $this->Bid->getText()) {
			$ret = $req->searchTitleByBid($v);
		} else if ($v = $this->Numbers->getText()) {
			$ret = $req->searchTitleByStdNum($v,$this->StdNumType->getSelectedValue());
		} else if ($v = $this->Title->getText()) {
			$ret = ($this->TitleSearchMode->getSelectedValue() == 'LIKE') ?
				$req->searchTitleLike($v) : $req->searchTitleEqual($v);
		} else if ($v = $this->LinkId->getText()) {
			$ret = $req->searchTitleByLinkedId($v,SBNTypes::OBJCLASS_AUT, $this->LinkType->getSelectedValue());
		} else {
			//$ret = $req->searchTitle(null);
			$this->MissingMainFieldError->setVisible(true);
			$this->ResultNumLabel->setVisible(false);
			return;
		}

		$resultSet = array();
		if ($ret && '0000' == $ret->SbnMessage->SbnResponse->SbnResult->esito) {
			$hits = (string)$ret->SbnMessage->SbnResponse->SbnOutput['totRighe'];
			$tmCollection = SBNConverter::SBN2Turbomarc($ret);
			foreach ($tmCollection->children() as $r)
				if ($rec = $this->parseTurbomarc($r))
					$resultSet[] = $rec;
			$this->ResultId->setValue((string)$ret->SbnMessage->SbnResponse->SbnOutput['idLista']);
			$this->ResultGrid->setVirtualItemCount($hits);
			$this->ResultGrid->setDataSource($resultSet);
			$this->ResultGrid->dataBind();
			$this->getSession()->add('NewRecordLastResults',array(
				'SBN'	=> $sourceResults = array(
					'DriverClass'	=> 'SBNDriver',
					'SourceID'		=> 'SBN',
					'Count'			=> $hits,
					'Results'		=> $resultSet
				)));
			$this->getSession()->add('ActiveSource','SBN');
		} else if ($ret && '3001' == $ret->SbnMessage->SbnResponse->SbnResult->esito) {
			// no results found
			$hits = 0;
			$this->ResultGrid->setVirtualItemCount($hits);
			$this->ResultGrid->setDataSource(array());
			$this->ResultGrid->dataBind();
			if (!$this->getPage()->IsPopup())
				$this->CreateMan->setVisible(true);
		} else if (isset($ret->SbnMessage->SbnResponse->SbnResult->esito)) {
			$hits = -1;
			$this->SbnErrorPanel->setVisible(true);
			$this->SbnErrorMessage->setText((string)$ret->SbnMessage->SbnResponse->SbnResult->testoEsito);
			$this->ResultGrid->setDataSource(array());
			$this->ResultGrid->dataBind();
		} else {
			$hits = -1;
			$this->SbnErrorPanel->setVisible(true);
			$this->SbnErrorMessage->setText(Prado::localize("Impossibile stabilire una connessione con l'indice SBN,
				si prega di riprovare in un secondo momento."));
			$this->ResultGrid->setDataSource(array());
			$this->ResultGrid->dataBind();
		}
		if ($hits >= 0) {
			$this->ResultNumLabel->Parameters->results = $hits;
			$this->ResultNumLabel->setVisible(true);
		} else {
			$this->ResultNumLabel->setVisible(false);
		}
	}

	private function parseTurbomarc(TurboMarc $tm) {
		$ret = array('Id' => 0, 'ClavisId' => 0, 'Turbomarc' => $tm->asXML(), 'InCatalog' => false);
		$l = $tm->getLeader();
		// the following is to avoid errors with SBN - TEMP!!!
		if (! $l instanceof TurboMarcLeader)
			return null;

		$our_record_id = ManifestationPeer::bidExists((string)$tm->d035->s9,(string)$tm->d035->sa);
		if ($our_record_id) {
			$ret['ClavisId'] = $ret['Id'] = $our_record_id;
			$ret['InCatalog'] = true;
		}
		$ret['Bid'] = (string)$tm->d035->sa;
		$ret['BidSource'] = (string)$tm->d035->s9;
		$ret['BibLevelCode'] = $l->biblevel;
		$ret['BibLevelLabel'] = (array_key_exists($ret['BibLevelCode'], $this->lookup_bl)) ?
			$this->lookup_bl[$ret['BibLevelCode']] : '---';
		$ret['Title'] = $tm->getFullTitle();
		$ret['Author'] = $tm->getAuthor();
		$ret['EAN'] = $tm->getEAN();
		$ret['Editions'] = implode(' - ',$tm->getEditions());
		$ret['Publications'] = implode(' - ',$tm->getPublications());
		$ret['Series'] = implode(' - ',$tm->getSeries());
		$ret['Dewey'] = $tm->getDewey();
		$ret['Subjects'] = implode(', ',$tm->getSubjects());
		$ret['PartOf'] = isset($tm->d461) ? "{$tm->d461->st} [{$tm->d461->s1}]" : '';
		return $ret;
	}

	public function populate()
	{
		$this->ResultId->setValue(null);
		$this->reloadSearch();
	}

	public function resultAction($sender,$param)
	{
		$item = $param->getItem();
        $this->getSession()->add("ImmediateImport",false);

		switch ($param->getCommandName()) {
            case 'importimmediate':
                $this->getSession()->add("ImmediateImport",true);
			case 'import':
				$data = $param->getCommandParameter();
				$data = array(
					'bid'	=> $data['Bid'],
					'link'	=> '',
					'bid_source'	=> 'SBN',
					'title'	=> $data['Title']);
				$this->getSession()->add('NewRecordSearch',$data);
				$this->getResponse()->redirect($this->getService()->constructUrl('Catalog.NewRecord'));
				break;
			case 'linkshow':
				$data = $item->getData();
				$data = array(
					'bid'	=> $data['Bid'],
					'link'	=> '',
					'bid_source'	=> 'SBN',
					'title'	=> $data['Title']);
				break;
		}
	}

	public function onSearchAuthCommand($sender, $param) {
		$data = array();
		$curitem = $param->getItem();
		switch ($param->getCommandName()) {
			case 'add':
				$newpart = array(
					'AuthText'	=> '',
					'AuthType'	=> 'AU',
					'AuthRelatorCode'	=> '',
					'AuthResp'	=> '');
				$items = $this->SearchAuth->getItems();
				foreach ($items as $item) {
					$data[] = array(
						'AuthText'	=> $item->AuthText->getText(),
						'AuthType'	=> $item->AuthType->getSelectedValue(),
						'AuthRelatorCode'	=> $item->AuthRelatorCode->getSelectedValue(),
						'AuthResp'	=> $item->AuthResp->getSelectedValue());
					if ($item == $curitem)
						$data[] = $newpart;
				}
				break;
			case 'del':
				$items = $this->SearchAuth->getItems();
				foreach ($items as $item) {
					if ($item != $curitem)
						$data[] = array(
							'AuthText'	=> $item->AuthText->getText(),
							'AuthType'	=> $item->AuthType->getSelectedValue(),
							'AuthRelatorCode'	=> $item->AuthRelatorCode->getSelectedValue(),
							'AuthResp'	=> $item->AuthResp->getSelectedValue());
				}
				// always ensure we have at least one entry
				while (count($data) < 1)
					$data[] = array(
						'AuthText'	=> '',
						'AuthType'	=> 'AU',
						'AuthRelatorCode'	=> '',
						'AuthResp'	=> '');
				break;
			default:
				break;
		}
		$this->SearchAuth->setDataSource($data);
		$this->SearchAuth->dataBind();
	}

	public function searchAuthDatabind($sender,$param) {
		$item = $param->Item;
		if ($item->ItemType==='Item' || $item->ItemType==='AlternatingItem') {
			$item->AuthRelatorCode->populate();
			$item->AuthRelatorCode->setSelectedValue($item->DataItem['AuthRelatorCode']);
		}
	}

	public function doCreateManif($sender, $param)
	{
		try {
			$man = new Manifestation();
			$man->setManifestationStatus(ManifestationPeer::STATUS_COMPLETE);
			$cat_level = '05';
			if ($this->getUser() instanceof ClavisLibrarian)
				$cat_level = $this->getUser()->getLibrarian()->getCatLevel();
			$man->setCatalogationLevel($cat_level);
			$tm = TurboMarc::createRecord();
			$tm->setLeader(' 1234nam0 2201234   450 ');
			$f101 = $tm->addField('101');
			$f101->addSubField('a','ita');
			$tm->setTitle(Prado::localize('Nuova notizia'));
			$man->setUnimarc($tm->asXML());
			$man->syncTitle();
			$man->save();
			ChangelogPeer::logAction($man, ChangelogPeer::LOG_CREATE, $this->getUser(), 'Nuova notizia creata');
			$this->getPage()->writeMessage(Prado::localize('Notizia creata, procedere alla catalogazione...'),
				ClavisMessage::CONFIRM);
			Prado::log("Create {$man->getManifestationId()}");
			$this->getPage()->gotoPage('Catalog.EditRecord',array('manifestationId' => $man->getManifestationId()));
		} catch (Exception $e) {
			Prado::log('Exception: '.$e->getMessage());
			$this->getPage()->writeMessage(Prado::localize('Errore durante la creazione di una nuova notizia: ').
				$e->getMessage(), ClavisMessage::ERROR);
		}
	}
}
