<?php
/**
 * ClavisItemStockSelect class file.
 *
 * This component is used to centralize the filters available to
 * extract a set of items.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 ePortal Technologies
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Widgets
 */

/**
 * ClavisItemStockSelect Class
 *
 * @author Dario Rigolin <dario@comperio.it>
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Widgets
 * @since 2.5.0
 */
class ClavisItemStockSelect extends TTemplateControl
{
	const MAX_TITLE_LEN = 80;

	private $_item = null;
	private $_issue = null;

	public function onLoad($param) {
		parent::onLoad($param);
		if (!$this->getPage()->getIsPostBack()) {
			$this->cleanFilters();
			$shelves = ShelfQuery::create()
				->findByLibraryId($this->getUser()->getActualLibraryId())
				->toArray();
			$this->ShelfList->setDataSource(array_merge(array('' => '---'),$shelves));
			$this->ShelfList->dataBind();
		}
	}

	private function cleanFilters()
	{
		$this->populateSerieSection();

		$this->onResetDateFilter(null, null);
		$this->onResetLibrarian(null, null);
		$this->InvNumberFrom->setText('');
		$this->SectionFilter->setSelectedIndex(-1);
		$this->CollocationFilterFrom->setText('');
		$this->CollocationFilterTo->setText('');
		$this->SpecificationFrom->setText('');
		$this->SpecificationTo->setText('');
		$this->SequenceFrom->setText('');
		$this->SequenceTo->setText('');
		$this->EditingDate->setText('');
		$this->EditingDateSelector->setSelectedIndex(0);
	}

	public function populateSerieSection() {
		$lid = $this->getUser()->getActualLibraryId();
		$inv_series = InventorySerieQuery::create()
			->orderByClosed()
			->orderByReadonly()
			->orderByInventorySerieId()
			->findByLibraryId($lid);
		$ds = array(0 => '---');
		foreach ($inv_series as $i)
		{
			$ds[$i->getInventorySerieId()] = $i->getDescription() . ' (' .
				$i->getInventorySerieId() . ')';
		}
		$this->InventorySerieId->setDataSource($ds);
		$this->InventorySerieId->dataBind();
		$this->SectionFilter->setLibraryId($lid);
		$this->SectionFilter->populateList();
	}

	protected function populateIssuePanel()
	{
		$issue = $this->getIssue();
		if ($issue instanceof Issue)
		{
			$this->RecordView->setManifestation($issue->getManifestation());
			$this->YearFrom->setParam1($issue->getManifestationId());
			$this->YearFrom->setParam2($this->getUser()->getActualLibraryId());
			$this->YearFrom->populate();

			$this->YearTo->setParam1($issue->getManifestationId());
			$this->YearTo->setParam2($this->getUser()->getActualLibraryId());
			$this->YearTo->populate();

			$this->IssueNumberFrom->setParam1($issue->getManifestationId());
			$this->IssueNumberFrom->setParam2($this->getUser()->getActualLibraryId());
			$this->IssueNumberFrom->populate();

			$this->IssueNumberTo->setParam1($issue->getManifestationId());
			$this->IssueNumberTo->setParam2($this->getUser()->getActualLibraryId());
			$this->IssueNumberTo->populate();
		}
	}

	public function onResetDateFilter($sender, $param)
	{
		$this->DateFrom->setText('');
 		$this->DateTo->setText('');
		if (!is_null($param))
 			$this->DateFilterPanel->render($param->getNewWriter());
	}

	public function onResetInvNum($sender, $param)
	{
		$this->InvNumberFrom->setText('1');
 		$this->InvNumberTo->setText('');
 		 if (!is_null($param))
 			$this->InvNumberFilterPanel->render($param->getNewWriter());
	}

 	public function onLibrarianIdChanged($sender, $param)
 	{
 		$librarian = LibrarianPeer::retrieveByPK($this->HiddenValue->getValue());
 		if ($librarian instanceof Librarian) {
			$this->LibrarianLabel->setText($librarian->getCompleteName());
 			$this->setLibrarianChoiceDone(true, $param);
 		}
 	}

	public function onResetLibrarian($sender, $param)
	{
		$this->HiddenLabel->setValue('');
		$this->HiddenValue->setValue('');
 		$this->LibrarianLabel->setText('');
		$this->setLibrarianChoiceDone(false, $param);
	}

 	public function setLibrarianChoiceDone($flag, $param)
 	{
		$this->LibrarianLabel->setVisible($flag);
		$this->LibrarianChoiceButton->setVisible(!$flag);
		$this->LibrarianResetButton->setVisible($flag);
		if (!is_null($param) && $this->getIsCallback())
			$this->LibrarianPanel->render($param->getNewWriter());
 	}

	public function getItemIds()
	{
		$q = ItemQuery::create();

		$fromBarcode = trim($this->BarcodeFrom->getSafeText());
		$toBarcode = trim($this->BarcodeTo->getSafeText());

		$fromInventory = intval($this->InvNumberFrom->getSafeText());
		$toInventory = intval($this->InvNumberTo->getSafeText());
		$inventoryList = trim($this->InvNumberList->getSafeText());

		$section = ($this->SectionFilter->getSelectedIndex() > 0)
			? $this->SectionFilter->getSelectedValue() : null;
		$fromCollocation = trim($this->CollocationFilterFrom->getSafeText());
		$toCollocation = trim($this->CollocationFilterTo->getSafeText());

		$fromDate = intval($this->DateFrom->getTimeStamp());
		$toDate = intval($this->DateTo->getTimeStamp());

		$shelfId = intval($this->ShelfList->getSelectedValue());
		
		$selectedInventorySerieId = $this->InventorySerieId->getSelectedValue();
		
		/*
		 * Check added to avoid search with inventory serie only; this permit search by inventory number only.
		 */
		if( ($selectedInventorySerieId != '0') && $fromInventory == 0 && $inventoryList == '' )
		{
			$this->getPage()->writeMessage(Prado::localize('Indicare un intervallo o lista di valori per la serie inventariale selezionata'),
					ClavisMessage::ERROR);
			return false;
		}
		
		if ($fromBarcode) {
			$q->filterByHomeLibraryId($this->getUser()->getActualLibraryId());

			if (!$toBarcode) {
				$q->filterByBarcode($fromBarcode);
			} else {
				$q->filterByBarcode($fromBarcode,Criteria::GREATER_EQUAL)
					->filterByBarcode($toBarcode,Criteria::LESS_EQUAL);
			}
		} else if ($fromInventory || $inventoryList) {

            $q->filterByOwnerLibraryId($this->getUser()->getActualLibraryId());

			$inventorySerie = InventorySeriePeer::retrieveByPK($selectedInventorySerieId,
				$this->getUser()->getActualLibraryId());
			if (! $inventorySerie instanceof InventorySerie) {
				$this->getPage()->writeMessage(Prado::localize('Serie inventariale non valida'),
						ClavisMessage::ERROR);
				return false;
			}
			$q->filterByInventorySerieId($inventorySerie->getInventorySerieId());
			if ($inventoryList) {
				$q->filterByInventoryNumber(explode(',',$inventoryList),Criteria::IN);
			} else {
				if ($fromInventory <= 0) {
					$this->getPage()->writeMessage(Prado::localize('Inserire un numero di inventario di partenza'),
							ClavisMessage::ERROR);
					return false;
				}
				if (!$toInventory) {
					$q->filterByInventoryNumber($fromInventory, Criteria::GREATER_EQUAL);
				} else {
					if ($fromInventory > $toInventory) {
						$this->getPage()->writeMessage(Prado::localize('Il numero di inventario di arrivo deve essere '.
								'più alto di quello di partenza'),ClavisMessage::ERROR);
						return false;
					}
					$q->filterByInventoryNumber($fromInventory, Criteria::GREATER_EQUAL)
						->filterByInventoryNumber($toInventory, Criteria::LESS_EQUAL);
				}
			}

		} else if ($section || $fromCollocation) {

            $q->filterByHomeLibraryId($this->getUser()->getActualLibraryId());

			if ($section)
				$q->filterBySection($section);

			$specFrom = trim($this->SpecificationFrom->getSafeText());
			$specTo = trim($this->SpecificationTo->getSafeText());
			$seqFrom = trim($this->SequenceFrom->getSafeText());
			$seqTo = trim($this->SequenceTo->getSafeText());

			if (!$toCollocation)
				$q->filterByCollocation($fromCollocation.'%', Criteria::LIKE);
			else
				$q->filterByCollocation($fromCollocation, Criteria::GREATER_EQUAL)
					->filterByCollocation($toCollocation, Criteria::LESS_EQUAL);
			if ($specFrom)
				if (!$specTo)
					$q->filterBySpecification($specFrom.'%', Criteria::LIKE);
				else
					$q->filterBySpecification($specFrom, Criteria::GREATER_EQUAL)
						->filterBySpecification($specTo, Criteria::LESS_EQUAL);
			if ($seqFrom)
				if (!$specTo)
					$q->filterBySequence1($seqFrom.'%', Criteria::LIKE);
				else
					$q->filterBySequence1($seqFrom, Criteria::GREATER_EQUAL)
						->filterBySequence1($seqTo, Criteria::LESS_EQUAL);

		} else if ($fromDate || $toDate) {

			$dateFrom = intval($this->DateFrom->getTimeStamp());
			$dateTo = intval($this->DateTo->getTimeStamp());
			if ($dateFrom)
				$q->filterByInventoryDate($dateFrom, Criteria::GREATER_EQUAL);
			if ($dateTo)
				$q->filterByInventoryDate($dateTo + 86399, Criteria::LESS_EQUAL);
			if (!$this->DateIncludeWholeConsortia->getChecked())
				$q->filterByOwnerLibraryId($this->getUser()->getActualLibraryId());

		} else if ($shelfId) {

			$item_ids = ShelfItemQuery::create()
				->filterByShelfId($shelfId)
				->filterByObjectClass(ShelfPeer::TYPE_ITEM)
				->select('ObjectId')->find()->toArray();
			$manifestation_ids = ShelfItemQuery::create()
				->filterByShelfId($shelfId)
				->filterByObjectClass(ShelfPeer::TYPE_MANIFESTATION)
				->select('ObjectId')->find()->toArray();
			if ($item_ids && $manifestation_ids)
				$q->condition('itemid','Item.ItemId IN ?',$item_ids)
					->condition('manifestationid','Item.ManifestationId IN ?',$manifestation_ids)
					->where(array('itemid','manifestationid'),'or');
			else if ($item_ids)
				$q->filterByItemId($item_ids);
			else if ($manifestation_ids) {
				$q->filterByManifestationId($manifestation_ids);
                $q->filterByHomeLibraryId($this->getUser()->getActualLibraryId());
            }
		}

		// refining filters
		$date = intval($this->EditingDate->getTimestamp());
		if ($date) {
			switch ($this->EditingDateSelector->getSelectedValue()) {
				case 'before':
					$q->filterByDateUpdated($date,Criteria::LESS_EQUAL);
					break;
				case 'after':
					$q->filterByDateUpdated($date,Criteria::GREATER_EQUAL);
					break;
				case 'day':
					$q->filterByDateUpdated(date('Y-m-d',$date),Criteria::GREATER_EQUAL)
						->filterByDateUpdated(date('Y-m-d',$date + 86400),Criteria::LESS_THAN);
			}
		}

		$librarianId = intval($this->HiddenValue->getValue());
		if ($librarianId > 0)
			$q->filterByModifiedBy($librarianId);

        $q->setLimit(intval($this->MaxLabelCount->Text));

		$items = $q->select('Item.ItemId')->find()->toArray();

		return $items;
	}
}
