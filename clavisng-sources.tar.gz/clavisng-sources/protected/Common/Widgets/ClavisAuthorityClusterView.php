<?php
/**
 * ClavisAuthorityClusterView class
 *
 * @author Dario Rigolin <dario.rigolin@comperio.it>
 * @link https://www.comperio.it/
 * @copyright Copyright &copy; 2019 Comperio srl
 * @version 2.9
 * @package Widgets
 * @since 2.9
 */

class ClavisAuthorityClusterView extends TTemplateControl {

    /** @var ClavisSBN */
    private $_sbnMod;

    public function onLoad($param) {
        parent::onLoad($param);

        $this->_sbnMod = $this->getApplication()->getModule('sbn');
       /* $auths = $this->getControlState("auths");
        if($auths != null) {
            $this->setControlState("auths", $auths);
            $this->AuthorityList->setDataSource($auths);
            $this->AuthorityList->dataBind();
        }*/
       //$this->ensureChildControls();
    }

    public function setKeyValue($value) {
        $this->setControlState("KeyValue", $value);
    }

    public function getKeyValue() {
        return $this->getControlState("KeyValue",'');
    }

    public function setKeyCount($value) {
        $this->setControlState("KeyCount", $value);
    }

    public function getKeyCount() {
        return $this->getControlState("KeyCount",0);
    }

    public function setFilterQuery($query) {
        $this->setControlState("FilterQuery", $query);
    }

    public function getFilterQuery() {
        return $this->getControlState("FilterQuery", "");
    }



    public function doExpandDetail($sender, $param) {
        $this->setControlState("auths",[]);
        $this->setControlState('CorrectForm',null);
        $this->setControlState('Duplicates',[]);
        $this->updateMergeStatus();

        /** @var SolrSearch $solr */
        $solr = $this->getApplication()->getModule("search");
        $filterQuery = $this->getFilterQuery();
        $result = $solr->searchAuthority("{$filterQuery} \"" . $this->getKeyValue() ."\"" ,
            0,
            $this->getKeyCount(),
            "sorts_fulltext ASC",
            []);

        $auths = [];


        foreach($result['response']['docs'] as $doc) {
            $tm = simplexml_load_string($doc['turbo_marc']);
            if(isset($tm->d035)) {
                $bid = (string)$tm->d035->s9 .":" . (string)$tm->d035->sa;
            } else {
                $bid = "";
            }
            $aid= intval($doc['Id']);

            $mancount = Propel::getConnection()->query("SELECT count(distinct manifestation_id) FROM l_authority_manifestation WHERE authority_id={$aid} ")->fetchColumn();
            $authcount = Propel::getConnection()->query("SELECT count(*) FROM l_authority WHERE authority_id_up={$aid} OR authority_id_down={$aid}")->fetchColumn();
            $subjcount = Propel::getConnection()->query("SELECT count(distinct subject_id) FROM l_subject WHERE authority_id={$aid}")->fetchColumn();

            $auths[] = [
                "fulltext" => htmlentities($doc['fldis_str_fulltext'][0]),
                "id" => $doc['Id'],
                "type" => LookupValuePeer::getLookupValue("AUTHTYPE",$doc['fldis_str_auth_type'][0]),
                "rec"  =>  LookupValuePeer::getLookupValue("AUTHRECTYPE",$doc['facets_authrectype'][0]),
                "bid" => $bid,
                "mancount" => $mancount,
                "authcount" => $authcount,
                "subjcount" => $subjcount,
                "mergekey" => $this->getKeyValue()
            ];
        }
        $this->setViewState("openkey",$this->getKeyValue());
        $this->setControlState("auths",$auths);
        $this->AuthorityList->setDataSource($auths);
        $this->AuthorityList->dataBind();

        $this->ClusterDetail->setVisible(true);
        $this->ExpandBtn->setVisible(false);
        $this->CloseBtn->setVisible(true);
    }

    public function onCloseDetail($sender, $param) {

        $this->ClusterDetail->setVisible(false);
        $this->ExpandBtn->setVisible(true);
        $this->CloseBtn->setVisible(false);

        $this->AuthorityList->setDataSource([]);
        $this->AuthorityList->dataBind();

        $this->setControlState("auths",[]);
        $this->setControlState('CorrectForm',null);
        $this->setControlState('Duplicates',[]);

        $this->updateMergeStatus();
    }

    public function onSelectCorrect($sender, $param) {
        $data = $sender->getValue();
        $duplicates = $this->getControlState("Duplicates");
        if(in_array($data,$duplicates)) {
            $sender->setChecked(false);
            $this->setControlState('CorrectForm',null);
        } else
            $this->setControlState('CorrectForm',$data);

        $this->updateMergeStatus();
    }

    public function onCheckDuplicate($sender, $param) {
        $correctid = $this->getControlState('CorrectForm');
        $duplicates = $this->getControlState("Duplicates");
        $value = $sender->getValue();
        if($value == $correctid) {
            $sender->setChecked(false);
        } else {

            if (is_null($duplicates)) $duplicates = [];
            if ($sender->getChecked()) {
                array_push($duplicates, $value);
            } else {
                $duplicates = array_diff($duplicates, [$value]);
            }
            $this->setControlState('Duplicates', $duplicates);
        }
        $this->updateMergeStatus();
    }

    private function updateMergeStatus()
    {
        $duplicates = $this->getControlState("Duplicates");
        $correctid = $this->getControlState('CorrectForm');

        $this->DDD->Text = "Corretta: {$correctid} - Duplicate: " . join(", ",$duplicates);
    }

    public function onMerge($sender, $param) {
        $this->replace(false);

        $this->doExpandDetail($sender,$param);
    }

    public function onMakeVariant($sender, $param) {
        $this->replace(true);

        $this->doExpandDetail($sender,$param);
    }

    /**
     * @return Authority
     */
    private function getTargetAuthority() {
        $correctid = $this->getControlState('CorrectForm');
        return AuthorityQuery::create()->findPk($correctid);
    }

    private function replace($variantize=false) {

        $successNumber = $failNumber = 0;
        $okString = $failedString = '';

        $currentLibrarian = $this->getUser();
        $targetAuthority = $this->getTargetAuthority();

        if (! $targetAuthority instanceof Authority) {
            $this->getPage()->writeMessage(Prado::localize('Non è stata scelta alcuna authority su cui schiacciare'),
                ClavisMessage::ERROR);
            return false;
        }

        $sourceAuthorityIds = $this->getControlState("Duplicates");;
        $totalNumber = count($sourceAuthorityIds);

        if ($sbnEnabled = $this->_sbnMod->getEnabled()) {
            $targetBid = $targetAuthority->getBidSource() == 'SBN'
                ? $targetAuthority->getBid() : null;
        }

        foreach ($sourceAuthorityIds as $sourceAuthorityId) {
            $sourceAuthority = AuthorityQuery::create()->findPk($sourceAuthorityId);
            if ($sourceAuthority instanceof Authority) {
                if ($sbnEnabled && $sourceAuthority->getBidSource() == 'SBN' && !$targetBid) {
                    // refuse to replace SBN authority with a non-SBN one
                    $rowString = Prado::localize('<br />[{id}] è legato a SBN, impossibile schiacciare ({text})',
                        array('id' => $sourceAuthorityId,
                            'text' => $sourceAuthority->getFullText()));
                    $result = false;
                } else if ($sbnEnabled && $sourceAuthority->getBidSource() == 'SBN' && $targetBid) {
                    if ($variantize) {
                        $tm = $sourceAuthority->getTurboMarc();
                        $l = $tm->getLeader();
                        $l->type = AuthorityPeer::RECTYPE_VARIANT;
                        $tm->setLeader($l);
                        $sbnMarc = SBNConverter::Turbomarc2SBN($tm);
                        $type = SBNConverter::ClavisType2SBNType($sourceAuthority->getAuthorityType());
                        if (!isset($tm->d099->sb))
                            $tm->d099->addSubField('d',SBNConverter::ClavisType2SBNType($type));
                        if (AuthorityPeer::TYPE_CLASS == $type) {
                            // 'D'+cod_edizione+simbolo per il sistema Dewey e cod_sistema+simbolo per altri sistemi
                            if (isset($tm->d676)) {
                                $bid = 'D'.$tm->d676->sv.$tm->d676->sa;
                            } else if (isset($tm->d686)) {
                                $bid = $tm->d686->s2.$tm->d686->sa;
                            }
                        }
                        $l = $sbnMarc->addChild('LegamiElementoAut')->addChild('ArrivoLegame')
                            ->addChild('LegameElementoAut');
                        $l->addAttribute('tipoAuthority',SBNConverter::ClavisType2SBNType($targetAuthority->getAuthorityType()));
                        $l->addAttribute('tipoLegame','4XX');
                        $l->addChild('idArrivo',$targetAuthority->getBid());
                        $node = $this->_sbnMod->getNodePrefix();
                        $node .= SBNConverter::ClavisType2SBNIdPrefix($type);
                        $cntparam = ClavisParamQuery::create()->filterByParamClass('SBNCOUNTER')->filterByParamName($node)->findOneOrCreate();
                        $counter = intval($cntparam->getParamValue()) + 1;
                        $sourceBid = $node.str_pad($counter,10-strlen($node),0,STR_PAD_LEFT);
                        $req = $this->_sbnMod->getNewRequest();
                        $req->create(SBNTypes::CREATECONTROL_CONFIRM, SBNTypes::OBJCLASS_AUT,$sbnMarc, $sourceBid);
                    } else {
                        $sourceBid = $sourceAuthority->getBid();
                    }
                    $req = $this->_sbnMod->getNewRequest();
                    $sbn_response = $req->merge($sourceBid, $targetBid,SBNTypes::OBJCLASS_AUT, SBNTypes::OBJCLASS_AUT);
                    switch ($sbn_response->SbnMessage->SbnResponse->SbnResult->esito) {
                        case '0000':	// correctly merged
                            $rowString = Prado::localize('<br />[{id}] correttamente fuso in SBN ({text})',
                                array('id' => $sourceAuthorityId,
                                    'text' => $sourceAuthority->getFullText()));
                            $result = $sourceAuthority->replaceWith($targetAuthority, $currentLibrarian);
                            break;
                        default:
                            $rowString = Prado::localize('<br />[{id}] errore SBN: {sbnErrorMessage}, impossibile schiacciare ({text})',
                                array('id' => $sourceAuthorityId,
                                    'sbnErrorMessage' => (string)$sbn_response->SbnMessage->SbnResponse->SbnResult->testoEsito,
                                    'text' => $sourceAuthority->getFullText()));
                            $result = false;
                    }
                } else {
                    $result = ($variantize) ?
                        $sourceAuthority->variantizeWith($targetAuthority, $currentLibrarian) :
                        $sourceAuthority->replaceWith($targetAuthority, $currentLibrarian) ;
                    $rowString = Prado::localize('<br />[{id}] ({text})',
                        array('id' => $sourceAuthorityId,
                            'text' => $sourceAuthority->getFullText()));
                    if ($result !== false)
                        $successNumber++;
                    else
                        $failNumber++;
                }
                if ($result) {
                    $successNumber++;
                    $okString .= $rowString;
                } else {
                    $failNumber++;
                    $failedString .= $rowString;
                }
            }
        }

        $targetAuthority->save();

        if ($successNumber > 0)
            $this->getPage()->writeMessage($successNumber == 1 ?
                Prado::localize('1 elemento processato su {total}: <br/>{message}',array('total'=>$totalNumber, 'message' => $okString)) :
                Prado::localize('{count} elementi processati su {total}',
                    array('count' => $successNumber, 'total' => $totalNumber, 'message' => $okString)),
                ClavisMessage::INFO);

        if ($failNumber > 0)
            $this->getPage()->writeMessage($failNumber == 1 ?
                Prado::localize('1 elemento NON processato su {total}: <br/>{message}',
                    array('total'=>$totalNumber, 'message' => $failedString)) :
                Prado::localize('{count} elementi NON processati su {total}: <br/>{message}',
                    array('count' => $successNumber, 'total' => $totalNumber, 'message' => $failedString)),
                ClavisMessage::ERROR);

        if ($successNumber == 0 && $failNumber == 0)
            $this->getPage()->writeMessage(Prado::localize('Nessun elemento processato'),ClavisMessage::WARNING);
    }
}