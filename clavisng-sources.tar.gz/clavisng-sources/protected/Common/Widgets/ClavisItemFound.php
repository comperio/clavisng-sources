<?php
/**
 * ClavisItemFound class file
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 */

/**
 * ClavisItemFound class
 *
 * It views the items found by barcode blipping (for now).
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.7
 * @package Widgets
 * @since 2.2
 */
class ClavisItemFound extends TTemplateControl
{
	private $_datasource = null;

	private $_checked;
	private $_dueDate;
	private $_itemRequestId;
	private $_deliveryLibraryId;

	/** @param ClavisLoanManager $_loanmanager */
	protected $_loanmanager;
	protected $_requestmanager;
	private $_datasourceSessionName;
	private $_checkedSessionName;
	private $_dueDateSessionName;
	private $_itemRequestIdSessionName;
	private $_deliveryLibraryIdSessionName;

	private function initVars()
	{
		$uniqueId = $this->getUniqueID();
		$this->_datasourceSessionName = 'DatasourceSessionName' . $uniqueId;
		$this->_checkedSessionName = 'CheckedSessionName' . $uniqueId;
		$this->_dueDateSessionName = 'DueDateSessionName' . $uniqueId;
		$this->_itemRequestIdSessionName = 'ItemRequestIdSessionName' . $uniqueId;
		$this->_deliveryLibraryIdSessionName = 'DeliveryLibraryIdSessionName' . $uniqueId;

		$this->_loanmanager = $this->getApplication()->getModule('loan');
		$this->_requestmanager = $this->getApplication()->getModule('request');
	}

	public function onInit($param)
	{
		parent::onInit($param);
		$this->initVars();

		$this->getChecked();
		$this->getDueDate();
		$this->getItemRequestId();
		$this->getDatasource();
	}

	public function onLoad($param)
	{
		parent::onLoad($param);

		$this->_deliveryLibraryId = $this->getDeliveryLibraryId();
	}

	/**
	 * Resetting of checked hash.
	 *
	 */
	public function resetChecked()
	{
		$this->_checked = array();
		$this->setChecked($this->_checked);
	}

	/**
	 * Setter method of checked.
	 *
	 * @param array $checked
	 */
	public function setChecked($checked = null)
	{
		if ($checked == null)
		{
			$checked = $this->_checked;
		}
		else
		{
			$this->_checked = $checked;
		}
		
		$this->getApplication()->getSession()->add($this->_checkedSessionName, $checked);
	}

	/**
	 * Getter method of checked.
	 *
	 * @return array
	 *
	 */
	public function getChecked()
	{
		if (is_null($this->_checked))
			$this->_checked = $this->getApplication()->getSession()->itemAt($this->_checkedSessionName);
		
		return $this->_checked;
	}

	public function resetDueDate()
	{
		$this->_dueDate = array();
		$this->setDueDate($this->_dueDate);
	}

	public function setDueDate($dueDate = null)
	{
		if (is_null($dueDate))
		{
			$dueDate = $this->_dueDate;
		}
		else
		{
			$this->_dueDate = $dueDate;
		}
		
		$this->getApplication()->getSession()->add($this->_dueDateSessionName, $dueDate);
	}

	public function getDueDate()
	{
		if (is_null($this->_dueDate))
			$this->_dueDate = $this->getApplication()->getSession()->itemAt($this->_dueDateSessionName);
		
		return $this->_dueDate;
	}

	public function resetItemRequestId()
	{
		$this->_itemRequestId = array();
		$this->setItemRequestId($this->_itemRequestId);
	}

	public function setItemRequestId($itemRequestId = null)
	{
		if ($itemRequestId == null)
		{
			$itemRequestId = $this->_itemRequestId;
		}
		else
		{
			$this->_itemRequestId = $itemRequestId;
		}
		
		$this->getApplication()->getSession()->add($this->_itemRequestIdSessionName, $itemRequestId);
	}

	public function getItemRequestId()
	{
		if (is_null($this->_itemRequestId))
			$this->_itemRequestId = $this->getApplication()->getSession()->itemAt($this->_itemRequestIdSessionName);
		
		return $this->_itemRequestId;
	}

	/**
	 * Resetting to null of datasource, and population.
	 *
	 */
	public function resetDataSource()
	{
		$this->resetChecked();
		$this->resetDueDate();
		$this->resetItemRequestId();
		$this->setDeliveryLibraryId(null);
		$this->_datasource = array();
		$this->setDatasource($this->_datasource);
		$this->populate();
	}

	public function setDatasource($datasource)
	{
		$this->_datasource = $datasource;
		$this->getApplication()->getSession()->add($this->_datasourceSessionName, $this->_datasource);
	}

	/**
	 * It returns the private datasource (array).
	 *
	 * @return array.
	 */
	public function getDatasource()
	{
		$this->_datasource = $this->getApplication()->getSession()->itemAt($this->_datasourceSessionName);

		if (is_null($this->_datasource))
			$this->_datasource = array();

		return $this->_datasource;
	}

 	public function setDeliveryLibraryId($id)
 	{
 		$this->_deliveryLibraryId = $id;
 		$this->getApplication()->getSession()->add($this->_deliveryLibraryIdSessionName, $id);
 	}

 	public function getDeliveryLibraryId()
 	{
 		if (($id = $this->_deliveryLibraryId) == null)
 		{
 			$id = $this->getApplication()->getSession()->itemAt($this->_deliveryLibraryIdSessionName);
 			$this->_deliveryLibraryId = $id;
 		}
		
		return $id;
 	}

	/**
	 * Returns whether an item id is present into the datasource.
	 *
	 * @param int $itemId
	 * @return boolean
	 */
	private function searchIdIntoDatasource($itemId)
	{
		$dataSource = $this->getDatasource();

		if (count($dataSource) > 0)
		{
			foreach($dataSource as $index => $row)
			{
				if ($row['id'] == $itemId)
					return $index;
			}
		}

		return -1;
	}

	/**
	 * It adds an item to datasource, by item.
	 * There's an optional id of the matching item_request.
	 * And and optional flag whether auto-check the new added
	 * item (default = true).
	 *
	 * It returns true if this action succeeds, false if not.
	 *
	 * @param Item $item
	 * @param int $itemRequestId
	 * @param boolean $checkFlag
	 * @return boolean
	 */
	public function addToDatasource(	$item, 
										$itemRequestId = null, 
										$checkFlag = true )
	{
		/* @var $item Item */

		if ($item instanceof Item)
		{
			$datasource = $this->getDatasource();

			$itemId = $item->getId();
			$exists = $this->searchIdIntoDatasource($itemId);

			$loanStatus = $item->getLoanStatus();
			$available = ($this->_loanmanager->IsItemAvailableClass($item) == ClavisLoanManager::OK);

			$dueDate = null;
			if ($loanStatus == ItemPeer::LOANSTATUS_READYFORLOAN)
			{
				$dueDate = $this->_loanmanager->CalculateDueDate($item);
			}
			else
			{
				$dueDate = $item->getDueDate('U');
			}
		
			if (is_null($dueDate) || in_array($loanStatus, ItemPeer::getLoanStatusAvailable()))
				$dueDate = $this->_loanmanager->CalculateDueDate($item);

			if (is_null($dueDate))
			{
				$exceedDate = false;
			}
			else
			{	
				$exceedDate = ($this->_loanmanager->isLoanLate($dueDate) == ClavisLoanManager::LOAN_ISLATE)
									&& $this->_loanmanager->IsLoanStatusActive($item);
			}

			$isSolicitable = ($this->_loanmanager->IsLoanSolicitable($item, $this->getUser()) == ClavisLoanManager::OK);

			$manifestationId = $item->getManifestationId();
			$manifestation = $item->getManifestation();
			
			$issueId = intval($item->getIssueId());
			$issue = $item->getIssue();
			
			if ($issue instanceof Issue)
			{
				$objectType = ItemRequestPeer::OBJECTTYPE_ISSUE;
				$objectId = $issueId;
			}
			elseif ($manifestation instanceof Manifestation)
			{
				$objectType = ItemRequestPeer::OBJECTTYPE_MANIFESTATION;
				$objectId = $manifestationId;
			}
			else
			{
				$objectType = ItemRequestPeer::OBJECTTYPE_ITEM;
				$objectId = $itemId;
			}
				
			$fromLibraryIdFilter = $this->getUser()->getActualLibraryId();

			$requestCount = $this->_requestmanager->countRequests(	$fromLibraryIdFilter,
																	null,
																	$itemId);

			
			list ($patronCompleteName, $patronNavigateUrl) = $item->getPatronUrlArray();

			// show destination only if we have one
			$this->DestinationColumn->setVisible($patronNavigateUrl != '');
			
			$row = array(	'id' => $itemId,
							'manifestationId' => $manifestationId,
							'issueId' => $issueId,
							'objectType' => $objectType,
							'checked' => $checkFlag,
			
							'title' => $this->getTitle($item),
							'dueDate' => $dueDate,
							'loanStatus' => $loanStatus,
							'loanStatusString' => $item->getLoanStatusString(),
							'available' => $available,

							'alertNote' => $item->getLoanAlertNote(),
							'actualLibraryId' => $item->getActualLibraryId(),
							'actualLibraryDescription' => $item->getActualLibraryDescription(),
							'patronId' => $item->getPatronId(),
							'patronCompleteName' => $patronCompleteName,
			
							'patronNavigateUrl' => $patronNavigateUrl,
							'isLoanRenewable' => (($this->_loanmanager->isLoanRenewable($item, $this->getUser(), $item->getPatron()) == ClavisLoanManager::OK) 
															? true
															: false),
							'isAskRenew' => $item->isAskRenew(),
							'isLoanPossible' => (($this->_loanmanager->isLoanAllowed($item, $item->getLoanDestinationObject(), $fromLibraryIdFilter) == true)
													&& ($this->_loanmanager->isItemAvailable($item, $fromLibraryIdFilter, $item->getLoanDestinationObject()) == ClavisLoanManager::OK) ),
							'illRequestFlag' => $this->calculateFutureIll($item),	///($item->getActualLibraryId() !== $this->getDeliveryLibraryId()),

							'loanAlertNote' => $item->getLoanAlertNote(),
							'isItemLoaned' => $this->_loanmanager->isItemLoaned($item),
							'exceedDate' => $exceedDate,
							'isSolicitable' => $isSolicitable,
							'requestCount' => $requestCount, 
                            
							'mediapackage_size' => $item->getMediapackageSize() );

			$this->_checked[$itemId] = $checkFlag;
			$this->_itemRequestId[$itemId] = $itemRequestId;
			$this->_dueDate[$itemId] = $dueDate;

			$this->setChecked();
			$this->setDueDate();
			$this->setItemRequestId();

			if ($exists > -1)
			{
				$datasource[$exists] = $row;
			}
			else
			{
				$datasource[] = $row;
			}
			
			$this->setDatasource($datasource);
			
			return true;
		}
	}

	private function calculateFutureIll(&$item = null)
	{
		$output = false;
		if ($item instanceof Item)
		{		
			$myLibraryId = $this->getUser()->getActualLibraryId();
			
			if ($item->isExternal())
			{
				$output = $item->isOutOfHome($myLibraryId);
				if ($output === false)
					$output = $item->isOutOfOwner($myLibraryId);
			}
			else  // it belongs to my consortia
			{
				$output = $item->isOutOfHome($myLibraryId);
			}
		}
		
		return $output;
	}
	
	/**
	 * Updating of datagrid from private datasource.
	 *
	 */
	public function updateDatasource()
	{
		$datasource = $this->getDatasource();
		foreach($datasource as $index => $row)
		{
			$itemId = $row['id'];
			$item = ItemQuery::create()->findPK($itemId);

			if (array_key_exists($itemId, $this->_checked))
			{
				$checked = $this->_checked[$itemId];
			}
			else
			{
				$this->_checked[$itemId] = false;
				$checked = false;
			}
			
			$row['checked'] = $checked;

			$dueDate = null;
			if (array_key_exists($itemId, $this->_dueDate))
			{
				$dueDate = $this->_dueDate[$itemId];
			}
			else
			{
				$newDueDate = $this->_loanmanager->CalculateDueDate($item);
				$this->_dueDate[$itemId] = $newDueDate;
				$checked = $newDueDate;
			}
			
			$row['dueDate'] = $dueDate;

			if (is_null($dueDate))
			{
				$exceedDate = false;
			}
			else
			{
				$exceedDate = ($this->_loanmanager->isLoanLate($dueDate) == ClavisLoanManager::LOAN_ISLATE)
										&& $this->_loanmanager->IsLoanStatusActive($item);
			}
			
			$manifestationId = $item->getManifestationId();
			$manifestation = $item->getManifestation();
			
			$issueId = intval($item->getIssueId());
			$issue = $item->getIssue();
			if ($issue instanceof Issue)
			{
				$objectType = ItemRequestPeer::OBJECTTYPE_ISSUE;
				$objectId = $issueId;
			}
			elseif ($manifestation instanceof Manifestation)
			{
				$objectType = ItemRequestPeer::OBJECTTYPE_MANIFESTATION;
				$objectId = $manifestationId;
			}
			else
			{
				$objectType = ItemRequestPeer::OBJECTTYPE_ITEM;
				$objectId = $itemId;
			}
			
			$fromLibraryIdFilter = $this->getUser()->getActualLibraryId();

			$requestCount = $this->_requestmanager->countRequests(	$fromLibraryIdFilter,
																	null,
																	$itemId);

			$row['loanStatus'] = $item->getLoanStatus();
			$row['loanStatusString'] = $item->getLoanStatusString();
			$row['available'] = ($this->_loanmanager->IsItemAvailableClass($item) == ClavisLoanManager::OK);
			$row['actualLibraryId'] = $item->getActualLibraryId();
			$row['actualLibraryDescription'] = $item->getActualLibraryDescription();
			$row['patronId'] = $item->getPatronId();
			$row['patronCompleteName'] = $item->getPatronCompleteName();
			$row['isLoanRenewable'] = (($this->_loanmanager->isLoanRenewable($item, $this->getUser(), $item->getPatron()) == ClavisLoanManager::OK) ? true : false);
			$row['isAskRenew'] = ($item->isAskRenew());
			$row['illRequestFlag'] = $this->calculateFutureIll($item);	///($item->getActualLibraryId() != $this->getDeliveryLibraryId());
			$row['isItemLoaned'] = $this->_loanmanager->isItemLoaned($item);
			$row['exceedDate'] = $exceedDate;
			$row['isSolicitable'] = ($this->_loanmanager->IsLoanSolicitable($item, $this->getUser()) == ClavisLoanManager::OK);
			$row['manifestationId'] = $manifestationId;
			$row['issueId'] = $issueId;
			$row['requestCount'] = $requestCount;

			$datasource[$index] = $row;
		}
		
		$this->setChecked();
		$this->setDueDate();
		$this->setDatasource($datasource);
		$this->ItemGrid->setDataSource($datasource);
		$this->ItemGrid->dataBind();
	}

	public function deleteItemIds($itemId)
	{
		if ($itemId > 0)
		{
			$datasource = $this->getDatasource();
			$index = $this->searchIdIntoDatasource($itemId);
			if ($index > -1)
			{
				$checked = $this->getChecked();
				$itemRequestId = $this->getItemRequestId();
				$dueDate = $this->getDueDate();

				if (array_key_exists($itemId, $checked) && array_key_exists($itemId, $itemRequestId) && array_key_exists($itemId, $dueDate))
				{
					unset($datasource[$index]);
					unset($checked[$itemId]);
					unset($itemRequestId[$itemId]);
					unset($dueDate[$itemId]);

					$this->setDatasource($datasource);
					$this->setChecked($checked);
					$this->setItemRequestId($itemRequestId);
					$this->setDueDate($dueDate);
				}
			}
		}
	}

	public function getCheckedItemIds()
	{
		$datasource = $this->getDatasource();
		$checked = $this->getChecked();

		$output = array();
		foreach ($datasource as $index => $row)
		{
			$itemId = $row['id'];
			if ($itemId > 0)
				if (array_key_exists($itemId, $checked))
					if ($checked[$itemId])
					{
						$row['checked'] = true;
						$itemRequestId = $this->_itemRequestId[$itemId];
						$dueDate = $this->_dueDate[$itemId];
						$output[] = array(	'itemId' => $itemId,
											'dueDate' => $dueDate,
											'itemRequestId' => $itemRequestId );
					}
		}
		$this->setChecked($checked);
		$this->setItemRequestId($this->_itemRequestId);
		$this->setDueDate($this->_dueDate);
		$this->setDatasource($datasource);

		return $output;
	}

	public function setItemIds($addedDatasource)
	{
		if (count($addedDatasource) == 0)
			return false;

		$datasource = $this->getDatasource();
		foreach ($addedDatasource as $index => $row)
		{
			$itemId = $row['itemId'];
			$dueDate = $row['dueDate'];
			$itemRequestId = $row['itemRequestId'];
			$checked = false;	// mah ......

			if ($itemId > 0)
			{
				$item = ItemQuery::create()->findPK($itemId);
				if ($item instanceof Item)
				{
					$loanStatus = $item->getLoanStatus();
					$available = ($this->_loanmanager->IsItemAvailableClass($item) == ClavisLoanManager::OK);

					if (is_null($dueDate))
					{
						if ($loanStatus == ItemPeer::ITEMLOANSTATUS_READYFORLOAN)
							$dueDate = $this->_loanmanager->CalculateDueDate($item);
						else
						{
							$dueDate = Clavis::dateFormat($item->getDueDate('U'),'shortdate shorttime');
							if (is_null($dueDate) || in_array($loanStatus, ItemPeer::getLoanStatusAvailable()))
								$dueDate = $this->_loanmanager->CalculateDueDate($item);
						}
					}
					
					if (is_null($dueDate))
						$exceedDate = false;
					else
						$exceedDate = ($this->_loanmanager->isLoanLate($dueDate) == ClavisLoanManager::LOAN_ISLATE)
										&& $this->_loanmanager->IsLoanStatusActive($item);

					$manifestationId = $item->getManifestationId();
					$manifestation = $item->getManifestation();
					
					$issueId = intval($item->getIssueId());
					$issue = $item->getIssue();
					if ($issue instanceof Issue)
					{
						$objectType = ItemRequestPeer::OBJECTTYPE_ISSUE;
						$objectId = $issueId;
					}					
					elseif ($manifestation instanceof Manifestation)
					{
						$objectType = ItemRequestPeer::OBJECTTYPE_MANIFESTATION;
						$objectId = $manifestationId;
					}
					else
					{
						$objectType = ItemRequestPeer::OBJECTTYPE_ITEM;
						$objectId = $itemId;
					}

					$fromLibraryIdFilter = $this->getUser()->getActualLibraryId();

					$requestCount = $this->_requestmanager->countRequests(	$fromLibraryIdFilter,
																			null,
																			$itemId);
					
					$row = array(	'id' => $itemId,
									'checked' => true,
									'title' => $this->getTitle($item),
									'dueDate' => $dueDate,
									'loanStatus' => $loanStatus,
									'loanStatusString' => $item->getLoanStatusString(),
									'available' => $available,
									'alertNote' => $item->getLoanAlertNote(),
									'actualLibraryId' => $item->getActualLibraryId(),
									'actualLibraryDescription' => $item->getActualLibraryDescription(),
									'patronId' => $item->getPatronId(),
									'patronCompleteName' => $item->getPatronCompleteName(),
									'isLoanRenewable' => (($this->_loanmanager->isLoanRenewable($item, $this->getUser(), $item->getPatron()) == ClavisLoanManager::OK)
																	? true
																	: false),
									'isAskRenew' => $item->isAskRenew(),
									'isLoanPossible' => (($this->_loanmanager->isLoanAllowed($item, $item->getPatron(), $fromLibraryIdFilter) == true)
															&& ($this->_loanmanager->isItemAvailable($item, $item->getPatron()) == ClavisLoanManager::OK) ),

									'illRequestFlag' => $this->calculateFutureIll($item),
									'isItemLoaned' => $this->_loanmanager->isItemLoaned($item),
									'exceedDate' => $exceedDate,
									'isSolicitable' => ($this->_loanmanager->IsLoanSolicitable($item, $this->getUser()) == ClavisLoanManager::OK),
									'manifestationId' => $manifestationId,
									'issueId' => $issueId,
									'requestCount' => $requestCount); 

					$this->_checked[$itemId] = false;
					$this->_itemRequestId[$itemId] = $itemRequestId;
					$this->_dueDate[$itemId] = $dueDate;

					$datasource[] = $row;
				}
			}
		}
		
		$this->setChecked($this->_checked);
		$this->setItemRequestId($this->_itemRequestId);
		$this->setDueDate($this->_dueDate);
		$this->setDatasource($datasource);
	}

	/**
	 * It changes the status (on/off) of the checkbox of one chosen
	 * row item of datagrid.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onFlipChecked($sender, $param)
	{
		$index = $sender->Parent->Parent->ItemIndex;

		$currentIndexPage = $this->ItemGrid->getCurrentPage();
		$pageSize = $this->ItemGrid->getPageSize();
		$datasource = $this->getDatasource();
		$partialDatasource = array_slice($datasource, $currentIndexPage * $pageSize, $pageSize);

		$row = $partialDatasource[$index];
		$itemId = $row['id'];
		$checked = $this->_checked[$itemId];
		$checked = !$checked;
		$this->_checked[$itemId] = $checked;
		$this->setChecked();
	}

	/**
	 * It performs population of datagrid.
	 * It returns true whether there are rows, false if datagrid
	 * if empty.
	 *
	 * @return boolean
	 */
	public function populate()
	{
		$currentIndexPage = $this->ItemGrid->getCurrentPage();
		$pageSize = $this->ItemGrid->getPageSize();

		$datasource = $this->getDatasource();
		$this->ItemGrid->VirtualItemCount = count($datasource);

		$partialDatasource = array_slice(	$datasource, 
											$currentIndexPage * $pageSize, 
											$pageSize, 
											true );
		
		$checkedArray = $this->getChecked();
		$dueDateArray = $this->getDueDate();

		$newPartialDatasource = array();
		foreach ($partialDatasource as $index => $row)
		{
			$id = $row['id'];

			if (array_key_exists($id, $checkedArray))
				$checked = $checkedArray[$id];
			else
				$checked = true;

			$dueDate = 0;
			if (array_key_exists($id, $dueDateArray))
			{
				$dueDate = $dueDateArray[$id];
			}
			else
			{
				if ($id > 0)
				{
					$item = ItemQuery::create()->findPK($id);
					if (!is_null($item) && ($item instanceof Item))
					{
						$dueDate = $this->_loanmanager->CalculateDueDate($item);
						$dueDateArray[$id] = $dueDate;
					}
				}
			}

			$newPartialDatasource[$index] = $row;
			$newPartialDatasource[$index]['checked'] = $checked;
			$newPartialDatasource[$index]['dueDate'] = $dueDate;
		}

		$this->ItemGrid->setDataSource($newPartialDatasource);
		$this->ItemGrid->dataBind();
		$count = count($datasource);
		$this->FoundNumber->setText($count);
		$this->HiddenFoundNumber->setValue($count);

		$this->setChecked();
		$this->setDueDate();

		return (count($newPartialDatasource) > 0);
	}

	/**
	 * It manages page change of datagrid.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function changePage($sender,$param)
	{
		$this->ItemGrid->setCurrentPage($param->NewPageIndex);
		$this->populate();
	}

	/**
	 * Are we into a popup ? ...
	 *
	 * @return boolean
	 */
	public function getPopupFlag()
	{
		return $this->getPage()->IsPopup();
	}

	public function onChangeDueDate1Day($sender, $param)
	{
		$sender->Parent->DueDate->setTimeStamp(time());
		$this->onChangeDueDate($sender, $param);
	}

	public function onChangeDueDate($sender, $param)
	{
		$index = $sender->Parent->Parent->ItemIndex;
		$dueDate = $sender->Parent->DueDate->getTimeStamp();

		if ($dueDate < time())
		{
			$this->getPage()->writeMessage(Prado::localize("ERRORE: data di rientro meno recente di quella corrente"), ClavisMessage::ERROR);
			return false;
		}

		$dataSource = $this->getDatasource();
		if (!array_key_exists($index,$dataSource)) 
		{
			$this->getPage()->writeMessage(Prado::localize('ERRORE: si prega di ricaricare la pagina e riprovare'), ClavisMessage::ERROR);
			return false;
		}
		
		$row = $dataSource[$index];
		$itemId = $row['id'];
		$this->_dueDate[$itemId] = $dueDate;
		$this->setDueDate();

		$item = ItemQuery::create()->findPK($itemId);
		if (is_null($item) || !($item instanceof Item))
		{
			$this->getPage()->writeMessage(Prado::localize("Errore: non c'è nessun esemplare con id = {itemId}",
															array('itemId' => $itemId)),
												ClavisMessage::ERROR);
			return false;
		}
		
		$this->getPage()->writeMessage(Prado::localize("Data di restituzione dell'esemplare '{title} [barcode: {barcode}] cambiata al {newDate}'",
														array(	'title' => $item->getTrimmedTitle(40, '/'),
																'barcode' => $item->getBarcode(),
																'newDate' => Clavis::dateFormat($dueDate))),
										ClavisMessage::INFO);

		$item->setDueDate($dueDate);
		$item->save();

		$currentLoanId = intval($item->getCurrentLoanId());
		if ($currentLoanId > 0)
		{
			$loan = LoanQuery::create()->findPK($currentLoanId);
			if (!is_null($loan))
			{
				$loan->setDueDate($dueDate);
				$loan->save();
			}
		}

		$this->getPage()->panelsRefresh($param);
	}

	public function globalRefresh()
	{
		$this->populate();
	}

	public function resetPagination()
	{
		$this->ItemGrid->setCurrentPage(0);
	}

	private function getTitle($item = null)
	{
		if (!$item instanceof Item)
			return '---';

		$itemtit = $item->getCompleteTitle();
		if (!$itemtit)
			$itemtit = Prado::localize('(nessun titolo)');

		$output = $itemtit . $item->getExternalString();

		if (in_array($item->getLoanClass(), ItemPeer::getLoanClassesConsultation()))
			$output = '[<b>' . $item->getLoanClassString($item->getLoanClass()) . '</b>]&nbsp;' . $output;

		return $output;
	}

	public function onColorize($sender, $param)
	{
		$item = $param->Item;

    	$loanStatus = $item->DataItem['loanStatus'];
		$available = $item->DataItem['available'];

    	if (!is_null($loanStatus) && $available)
		{
			if (in_array($loanStatus, ItemPeer::getLoanStatusAvailable()))
				$item->setCssClass('evidenced_lightred');

			if ($loanStatus == ItemPeer::LOANSTATUS_READYFORLOAN)
				$item->setCssClass('evidenced_green');
		}
	}
	
}
