<?php

/**
 * TClavisTimePicker class
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2011 Comperio SRL
 * @version 2.7
 * @package Controls
 * @since 2.4.3
 */

class TClavisTimePicker extends TTemplateControl
{
	const MIN_MINUTESLICE = 5;
	const TIME_INVALID = "**timeInvalid**";
	
	public function onInit($param)
	{
		parent::onInit($param);
		
		$color = $this->getColor();
		
		if ($color !== '')
			$this->Panel->setStyle("padding: 2px 1px 4px 3px;
									margin: 0px;
									background-color: $color;
									width: 6em");
	}

	/*
	 * setters && getters
	 */
	public function setColor($param)
	{
		$this->setControlState('Color', $param, null);
	}
	
	public function getColor()
	{
		return $this->getControlState('Color', "");
	}
	
	public function setTime($param)
	{
		$this->writeTime($param);
		$this->setControlState('Time', $param, null);
	}
	
	public function getTime()
	{
		return $this->getControlState('Time', null);
	}
	
	private function timePad($value)
	{
		return str_pad($value, 2, "00", STR_PAD_LEFT);
	}

	public function getHourSet($mode = "24h")
	{
		if (($mode != "24h") 
				&& ($mode != "12h"))
			$mode = "24h";

		if ($mode == "24h")
		{	
			return array(	-1 => '--',
							6 => '06',
							7 => '07',
							8 => '08',
							9 => '09',
							10 => '10',
							11 => '11',
							12 => '12',
							13 => '13',
							14 => '14',
							15 => '15',
							16 => '16',
							17 => '17',
							18 => '18',
							19 => '19',
							20 => '20',
							21 => '21',
							22 => '22',
							23 => '23' );
		}
		else
		{
			return array(	-1 => '--',
							6 => '06am',
							7 => '07am',
							8 => '08am',
							9 => '09am',
							10 => '10am',
							11 => '11am',
							12 => '12am',
							13 => '1pm',
							14 => '2pm',
							15 => '3pm',
							16 => '4pm',
							17 => '5pm',
							18 => '6pm',
							19 => '7pm',
							20 => '8pm',
							21 => '9pm',
							22 => '10pm',
							23 => '11pm' );
		}
	}

	public function getMinuteSet($minSlice = null)
	{
		$minSlice = intval($minSlice);
		if ($minSlice == 0)
			$minSlice = self::MIN_MINUTESLICE;

		$minutes = array(-1 => '-');
		for ($c = 0; $c < 60; $c += $minSlice)
			$minutes[$c] = $this->timePad($c);

		return $minutes;
	}

	public function writeTime($time = "00:00")
	{
		$arr = explode(":", $time);
		
		if (count($arr) == 3)  // in the case we also get seconds ...
			array_pop($arr);
		
		if (count($arr) != 2)
			return false;
		
		$arr[0] = intval($arr[0]);
		$arr[1] = (string)($arr[1] - ($arr[1] % 5));

		try
		{
			$this->Hour->setSelectedValue($arr[0]);
			$this->Minute->setSelectedValue($arr[1]);

			return true;
		}
		catch (Exception $e)
		{
			return false;
		}
	}

	public function readTime()
	{
		$hourValue = $this->Hour->getSelectedValue();
		
		if (intval($hourValue) < 0)
		{
			$hour = "";
		}
		else
		{
			$hour = $hourValue;
		}

		$minuteValue = $this->Minute->getSelectedValue();
		
		if (intval($minuteValue) < 0)
		{
			if ($hour == "")
			{
				return "";
			}
			else
			{
				$minute = "00";
			}
		}
		else
		{
			if ($hour == "")
			{
				return self::TIME_INVALID;
			}
			else
			{
				$minute = $minuteValue;
			}
		}
		
		return $this->timePad($hour) . ":" . $this->timePad($minute);
	}

	public function resetTime()
	{
		$this->Hour->setSelectedIndex(-1);
		$this->Minute->setSelectedIndex(-1);
	}
	
}