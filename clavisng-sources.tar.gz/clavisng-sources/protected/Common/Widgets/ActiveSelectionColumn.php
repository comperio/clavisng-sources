<?php
/**
 * Created by PhpStorm.
 * User: dario
 * Date: 14/01/2014
 * Time: 16:18
 */

class ActiveSelectionColumn extends TActiveBoundColumn
{
    protected function initializeHeaderCell($cell,$columnIndex)
    {
        $checkBox = Prado::createComponent('System.Web.UI.WebControls.TActiveCheckBox');
        $cell->getControls()->add($checkBox);
    }

    public function initializeCell($cell,$columnIndex,$itemType)
    {
        if($itemType == TListItemType::AlternatingItem
            || $itemType == TListItemType::Item)
        {
            $kf = $this->getOwner()->getDataKeyField();
            $ids = $this->getOwner()->getDataKeys()->itemAt($this->getOwner()->getDataKeys()->getCount()-1);
            //$cell->setText("K {$kf} " . $ids);
            $checkBox = Prado::createComponent('System.Web.UI.WebControls.TActiveCheckBox');
            $checkBox->attachEventHandler('OnCheckedChanged',array($this,'RowCheck'));
            $checkBox->setViewState("RowID",$ids);
            $checkBox->getClientSide()->setOnLoading("submitEvent();");
            $checkBox->getClientSide()->setOnComplete("hideEvent();");

            $cell->getControls()->add($checkBox);
        } else if($itemType == TListItemType::Header) {
           // $cell->setText("Head");
            $checkBox = Prado::createComponent('System.Web.UI.WebControls.TActiveCheckBox');

            $checkBox->attachEventHandler('OnCheckedChanged',array($this,'MasterCheck'));
            $checkBox->getClientSide()->setOnLoading("submitEvent();");
            $checkBox->getClientSide()->setOnComplete("hideEvent();");
            $cell->getControls()->add($checkBox);
        }
    }

    public function MasterCheck($sender,$param)
    {
        $this->getOwner()->setViewState("MasterCheck",!$this->getOwner()->getViewState("MasterCheck",false));
        $this->getOwner()->setViewState("RowsChecked",array());
        foreach($this->getOwner()->getItems() as $item)
        {
            $check = $item->getCells()->itemAt(0)->getControls()->itemAt(0);
            $check->setChecked($this->getOwner()->getViewState("MasterCheck",false));
        }

    }

    public function RowCheck($sender,$param)
    {
        $rowid = $sender->getViewState("RowID");
        $rowlist = $this->getOwner()->getViewState("RowsChecked",array());
        if($sender->getChecked() || $this->getOwner()->getViewState("MasterCheck",false))
        {
            $rowlist[]=$rowid;
        } else {
            $rowlist = array_diff($rowlist,array($rowid));
        }
        $this->getOwner()->setViewState("RowsChecked",$rowlist);
    }

}