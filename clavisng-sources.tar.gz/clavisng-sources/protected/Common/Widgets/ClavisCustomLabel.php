<?php
class ClavisCustomLabel extends TTemplateControl {
	
	protected $bg = FALSE;
	protected $doctemp = FALSE;
	protected $deftemplate = ['',210,297,0,0,0,0,0,0,0,0,[],FALSE];
	
	public function onLoad($param) {
		parent::onLoad($param);

		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallback()){
			$this->populate();
			//$this->setControlState('atemplate', ['',210,297,0,0,0,0,0,0,0,0,[],FALSE]);
		}
	}
	
	
	public function onPreRender($param)	{
		parent::onPreRender($param);
		
		$cs = $this->getPage()->getClientScript();
		
		Clavis::registerStyleSheet($cs, Prado::getPathOfNamespace('Application.Common.Components.JQueryRte'), [
			'jquery.rte.css'
		], 'css',false);
			
		// make sure that prototype.js is loaded before bootstrap.
		$cs->registerPradoScript('prado');

		Clavis::registerClientScript($cs, Prado::getPathOfNamespace('Application.Javascript'), [
				'jquery-1.8.3.min.js'
			], '',false);
		
		Clavis::registerClientScript($cs, Prado::getPathOfNamespace('Application.Common.Components.JQueryRte'), [
			'jquery.rte.js',
			'jquery.rte.mytb.js'
		], 'js',false);
	}

	protected function getBaseCriteria() {
		return DocumentTemplateQuery::create()
		->filterByTemplateClass('CUSTOMLABEL')
		->filterByTemplateMedia(DocumentTemplatePeer::MEDIA_LABEL)
		->filterByTemplateLang($this->getApplication()->getGlobalization()->getCulture())
		->filterByLibraryId($this->getUser()->getActualLibraryId())
		->_or()
		->filterByLibraryId(NULL, Criteria::ISNULL);
	}
	
	
	public function populate() {
		$seltname = '';
		$seltindex = 0;
		/*$selt = $this->getControlState('atemplate');
		if(is_array($selt)) {
			$seltname = $selt[0];
		}*/
		
		$doctempcr = $this->getBaseCriteria();
		//Prado::log($doctempcr->toString());
		$doctempstmt = $doctempcr->orderByLibraryId()->orderByTemplateTitle()->find();
		
		$dataSource = array();
		if (count($doctempstmt) >= 1) {
			$dataSource['0'] = '---';
		} 
		foreach ($doctempstmt as $doctemp) {
			if($seltname == $doctemp->getTemplateTitle()) {
				$seltindex = $doctemp->getDocumentTemplateId();
			}
			$listlabel = $doctemp->getTemplateTitle();
			if($doctemp->getLibraryId() == NULL) {
				$listlabel = "* " . $doctemp->getTemplateTitle();
			}
			$dataSource[$doctemp->getDocumentTemplateId()] = $listlabel;
		}
		$this->LabelTemplateList->setDataSource($dataSource);
		$this->LabelTemplateList->dataBind();

		$selid = $this->getControlState('dtid');
		if($selid !== FALSE){
			$this->LabelTemplateList->setSelectedValue($selid);
		}
		/*$this->LabelTemplateList->setSelectedValue($seltindex);
		$this->populateLabelTemplateParams(NULL,NULL);*/
		//Prado::log(Prado::varDump($this->getUser()->getLibrarian()->getRoles()));
		$userroles = $this->getUser()->getLibrarian()->getRoles();
		if(in_array('admin', $userroles) || in_array('director', $userroles)) {
			$this->SysMenu->setVisible(TRUE);
		}else{
			$this->SysMenu->setVisible(FALSE);
		}
		$this->populateLabelTemplateParams();
	}
	


	/*
	 * Called when user select a template
	 */
	public function selTemplateChanged($sender,$param) {
		$doctempid = intval($this->LabelTemplateList->getSelectedValue());
		if ($doctempid > 0) {
			$this->setControlState('dtid', $doctempid);
		}else{
			$this->setControlState('dtid', FALSE);
		}
		$this->populateLabelTemplateParams();
	}
	
	/*
	 * Populate template parameters
	 */
	public function populateLabelTemplateParams() {
		try {
			
			//Set a default empty template parameter
			$aTemplate= $this->deftemplate;
			
			//if no template id is specified try to get prev selected id
			$doctempid = $this->getControlState('dtid', FALSE);
			
			//Prado::log(__METHOD__ . " doctempid {$doctempid}");
			if ($doctempid !== FALSE) {
				$this->doctemp = DocumentTemplateQuery::create()->findOneByDocumentTemplateId($doctempid);
				if ($this->doctemp instanceof DocumentTemplate) {
					$aTemplate = json_decode($this->doctemp->getTemplateBody(), TRUE);
					if($this->doctemp->getLibraryId() == NULL) {
						$this->SysLabel->setChecked(TRUE);
					}else{
						$this->SysLabel->setChecked(FALSE);
					}
					$this->setControlState('dtid', $doctempid);
					
					$this->bg = $this->getBgAttach();
				}
			}
			$this->updateBgControls();
			$this->LabelTemplateName->setText($aTemplate[0]);
			$this->LabelTemplateLeftMargin->setText($aTemplate[3]);
			$this->LabelTemplateTopMargin->setText($aTemplate[4]);
			$this->LabelTemplateLblWidth->setText($aTemplate[5]);
			$this->LabelTemplateLblHeight->setText($aTemplate[6]);
			$this->LabelTemplateRows->setText($aTemplate[7]);
			$this->LabelTemplateCols->setText($aTemplate[8]);
			$this->LabelTemplateHSpace->setText($aTemplate[9]);
			$this->LabelTemplateVSpace->setText($aTemplate[10]);
			$this->LabelTemplateRotate->setChecked($aTemplate[12]);
			
			//needed to print function
			$this->setControlState('atemplate', $aTemplate);
			//Send base64 coded image to client because image path is not available to web server
			$this->getPage()->getCallbackClient()->callClientFunction('updateClientData', array(json_encode($aTemplate[11]), $this->getBgFile(TRUE,$aTemplate[12])));
		}catch(Exception $e){
			Prado::log($e->getStackTrace());
		}
	}
	
	public function updateBgControls() {
		if( $this->bg === FALSE) {
			$this->LabelTemplateLblBgFileName->setText('');
			$this->LabelTemplateBgPanel->setVisible(FALSE);
			if( ($dtid = $this->getControlState('dtid', FALSE) === FALSE) ) {
				//Avoid hide, may be a TActiveFileUpload bug
				//$this->LabelTemplateLblBgFu->setVisible(FALSE);
			}else{
				$this->LabelTemplateLblBgFu->setVisible(TRUE);
			}
		}else{
			$this->LabelTemplateLblBgFileName->setText($this->bg->getFileName());
			$this->LabelTemplateBgPanel->setVisible(TRUE);
			//Avoid hide, may be a TActiveFileUpload bug
			//$this->LabelTemplateLblBgFu->setVisible(FALSE);
		}
	}
	
	
	public function getBgAttach() {
		$retval = FALSE;
		$dtid = $this->getControlState('dtid', FALSE);
		if($dtid !== FALSE) {
			$a = AttachmentQuery::create()
			->filterByObjectId($dtid)
			->filterByObjectType('DocumentTemplate')
			->findOne();
			if($a instanceof Attachment)
			{
				$retval = $a;
			}
		}
		return $retval;
	}
	
	public function getBgFile($base64=FALSE, $rot=FALSE) {
		$retval = '';
		if($this->bg === FALSE){
			$this->bg = $this->getBgAttach();
		}
		if($this->bg instanceof Attachment)
		{
			$imgbin = FALSE;
			if($rot){
				$source = imagecreatefrompng($this->bg->getRealFilePath());
				$rotate = imagerotate($source, 90, 0);
				ob_start();
				imagepng( $rotate );
				$imgbin = ob_get_contents();
				ob_end_clean();
				imagedestroy($source);
				imagedestroy($rotate);
			}else{
				$imgbin = $this->bg->retrieveFile();
			}
			if($imgbin) {
				if($base64) {
					$retval = base64_encode($imgbin);
				}else{
					$retval = $imgbin;
				}
			}			
		}
		return $retval;
	}
	
	public function getBgFileName() {
		$retval = FALSE;
		if($this->bg === FALSE){
			$this->bg = $this->getBgAttach();
		}
		if($this->bg instanceof Attachment)
		{
			$retval = $this->bg->getRealFilePath();
		}
		return $retval;
	}
	
	public function bgUploaded($sender,$param) {
		if($sender->HasFile)
		{
			if( exif_imagetype($sender->LocalName) != IMAGETYPE_PNG ) {
				$this->raiseWriteMessageEvent(Prado::localize('Il file caricato non è di tipo png'),ClavisMessage::ERROR);
				return;
			}
			//Prado::log("uploaded file: Name: {$sender->FileName} {$sender->LocalName} Size: {$sender->FileSize} Type: {$sender->FileType}");
			$dtid = $this->getControlState('dtid');
			if($dtid === FALSE) {
				$this->raiseWriteMessageEvent(Prado::localize('Modello non ancora salvato'),ClavisMessage::ERROR);
			}else{
				try{
					
					$imginfo = getimagesize($sender->LocalName);
					if($imginfo !== FALSE){
						//Prado::log(Prado::varDump($imginfo));
						$wmm = $imginfo[0] / 3.8;
						$hmm = $imginfo[1] / 3.8;
						$at = $this->getControlState('atemplate', FALSE);
						if( $at !== FALSE ){
							if( $wmm > $at[5] || $hmm > $at[6]){
								$this->raiseWriteMessageEvent(Prado::localize('Immagine troppo grande'),ClavisMessage::ERROR);
								return;
							}
						}
					}
					
					$this->bg = $this->getBgAttach();
					if(! $this->bg instanceof Attachment) {
						$this->bg = new Attachment();
						$this->bg->setAttachmentType(AttachmentPeer::TYPE_IMAGE)
						->setFileSize($sender->FileSize)
						->setObjectType('DocumentTemplate')
						->setObjectId($dtid)
						->setFileLabel($sender->FileName)
						->setFileDescription('Label background');
					}
					
					$this->bg->storeFile($sender->LocalName, $sender->FileName);
					$this->populateLabelTemplateParams();
					$this->raiseWriteMessageEvent(Prado::localize('File caricato.'));
					
				}catch(Exception $ex){
					$this->raiseWriteMessageEvent(Prado::localize('Errore inviato al log di clavis. Contattare assistenza comperio.'),ClavisMessage::ERROR);
					Prado::log(__METHOD__ . " Attachment->storeFile exception on upload label background. Trace: ".$ex->getTraceAsString());
				}
				
			}
		}else{
			$this->raiseWriteMessageEvent(Prado::localize('Errore nel caricamento del file'),ClavisMessage::ERROR);
		}
	}
	
	public function deleteBg($sender,$param) {
		$a = $this->getBgAttach();
		if($a instanceof Attachment){
			try{
				$a->delete();
				unset ($a);
				$this->bg = FALSE;
				$this->populateLabelTemplateParams();
				$this->raiseWriteMessageEvent(Prado::localize('File cancellato.'));
			}catch(Exception $ex){
				$this->raiseWriteMessageEvent(Prado::localize('Errore inviato al log di clavis. Contattare assistenza comperio.'),ClavisMessage::ERROR);
				Prado::log(__METHOD__ . " Attachment->delete exception on delete label background. Trace: ".$ex->getTraceAsString());
			}
		}
	}
		
	public function save($sender,$param) {
		$title = $this->LabelTemplateName->getSafeText();
		if( $title == '' ) {
			//TODO WARN
			return;
		}
		
		$aTemplate[0] = $title;
		$aTemplate[1] = 210;
		$aTemplate[2] = 297;
		$aTemplate[3] = $this->LabelTemplateLeftMargin->getSafeText();
		$aTemplate[4] = $this->LabelTemplateTopMargin->getSafeText();
		$aTemplate[5] = $this->LabelTemplateLblWidth->getSafeText();
		$aTemplate[6] = $this->LabelTemplateLblHeight->getSafeText();
		$aTemplate[7] = $this->LabelTemplateRows->getSafeText();
		$aTemplate[8] = $this->LabelTemplateCols->getSafeText();
		$aTemplate[9] = $this->LabelTemplateHSpace->getSafeText();
		$aTemplate[10] = $this->LabelTemplateVSpace->getSafeText();
		
		if( is_array($param->CallbackParameter->labelfields) ) {
			$aTemplate[11] = $param->CallbackParameter->labelfields;
		}else{
			$aTemplate[11] = [];
		}
		$aTemplate[12] = $this->LabelTemplateRotate->getChecked();
		$this->setControlState('atemplate', $aTemplate);

		$logaction = ChangelogPeer::LOG_UPDATE;
		$doctemp = $this->getBaseCriteria()
			->filterByTemplateTitle($title)
			->findOne();
		if (!($doctemp instanceof DocumentTemplate)) {
			$doctemp = new DocumentTemplate();
			$doctemp->setTemplateTitle($title);
			$logaction = ChangelogPeer::LOG_CREATE;
		}
		
		$doctemp->setTemplateClass('CUSTOMLABEL');
		$doctemp->setTemplateMedia(DocumentTemplatePeer::MEDIA_LABEL);
		$doctemp->setTemplateLang($this->getApplication()->getGlobalization()->getCulture());
		if($this->SysLabel->getChecked()) {
			$doctemp->setLibraryId(NULL);
		}else{
			$doctemp->setLibraryId($this->getUser()->getActualLibraryId());
		}
		$doctemp->setTemplateBody(json_encode($aTemplate));
		
		$doctemp->save();
		$this->raiseWriteMessageEvent(Prado::localize('Salvato'));
		$this->setControlState('dtid',$doctemp->getDocumentTemplateId());
		$this->populate();
		
		ChangelogPeer::logAction($this->getUser()->getLibrarian(),$logaction,
			$this->getUser(),
			"Modello {$title} " . (($logaction == ChangelogPeer::LOG_UPDATE) ? 'aggiornato' : 'creato') . " (".implode('-',array_splice($aTemplate,0,11)).")");
	}
	
	
	
	public function delete($sender,$param) {
		$name = $this->LabelTemplateName->getSafeText();
		$doctemp = $this->getBaseCriteria()
		->filterByTemplateTitle($name)
		->findOne();
		if ($doctemp instanceof DocumentTemplate) {
			$tbody = $doctemp->getTemplateBody();
			$doctemp->delete();
			$this->raiseWriteMessageEvent(Prado::localize('Eliminato'));
			$this->deleteBg(NULL,NULL);
			$this->populate();
			ChangelogPeer::logAction($this->getUser()->getLibrarian(),ChangelogPeer::LOG_DELETE,
				$this->getUser(),
				"Modello {$name} eliminato"  . " (".implode('-',array_splice(json_decode($tbody),0,11)).")");
		}
	}

	
	public function applyDirectiveToClavisField($dir, $field) {
		$res = $field;
		if( is_numeric($dir) ) {
			$res = mb_substr($field, 0, intval($dir));
		}else{
			if( $dir != '') {
				$res = str_replace(str_split($dir), "<br>", $field);
			}
		}
		return $res;
	}
	
	/*To get log write to file use
	*Prado::log(__METHOD__ . " what I want to log");
	*...
	*Prado::getApplication()->getModule('log')->collectLogs(null);
	*See Util.TLogRouter.php OnEndRequest event handler
	*else will not work
	*/
	public function print($itemidlist) {
		
		$sheet = $this->getControlState('atemplate', ['',210,297,0,0,0,0,0,0,0,0,[],FALSE]);
		$sheetName=$sheet[0];
		$paperWidth=$sheet[1];
		$paperHeight=$sheet[2];
		$marginLeft=$sheet[3];
		$marginTop=$sheet[4];
		$labelWidth=$sheet[5];
		$labelHeight=$sheet[6];
		$numRows=$sheet[7];
		$numColumns=$sheet[8];
		$horizontalSpace=$sheet[9];
		$verticalSpace=$sheet[10];
		$labelFields=$sheet[11];
		$rotated=$sheet[12];
		$dbg = FALSE;
		
		if($sheetName == ''){
			$this->raiseWriteMessageEvent(Prado::localize('Selezionare un modello'), ClavisMessage::WARNING);
			return FALSE;
		}
		
		//if sheet name have 'debug' word, add border to label and store html inside /tmp
		if(strpos($sheetName,'debug') !== FALSE) $dbg = TRUE;
		
		//Get number of items to print
		$nItems = ItemQuery::create()->filterByItemId($itemidlist)->count();
		
		//For aliases see Common/Components/JQueryRte/js/jquery.rte.mytb.js
		$criteria = ItemQuery::create()
			->withColumn('item.title','titolo')
			->withColumn('item.section','sez')
			->withColumn('item.collocation','coll')
			->withColumn('item.specification','spec')
			->withColumn('item.barcode','bar')
			->withColumn('item.inventory_serie_id','sinv')
			->withColumn('item.inventory_number','ninv')
			->withColumn('item.item_icon','icona')
			->withColumn('item.owner_library_id','olid')
			->withColumn("CONCAT_WS(' ',collocation,specification,sequence1,sequence2)", 'collcomb')
			->withColumn("CONCAT_WS('-',inventory_serie_id,inventory_number)", 'invcomb')
			->filterByItemId($itemidlist);
		$ob = $this->OrderBy->getSelectedValue();
		if($ob != '---'){
			$orderfields = explode(',',$ob);
			foreach($orderfields as $of){
				$criteria->orderBy($of, $this->DirOrderBy->getSelectedValue());
			}
		}
		$items = $criteria->find();
		
		$labelPerPage=$numRows*$numColumns;
		
		//get  full printed pages
		$pages = intval($nItems/$labelPerPage);
		//and potential last partial printed page
		if( ($nItems%$labelPerPage) > 0 ) $pages++;
		
		
		//WARNING: constructor margin may not work when body contains div with absolute position
		$mpdf = null;
		if( $numRows == 1 && $numColumns == 1 )
		{
			$mpdf = new \Mpdf\Mpdf(['format' => [$labelWidth, $labelHeight]]);
		}else{
			$mpdf = new \Mpdf\Mpdf();
		}
		
		//wrap mpdf logging to prado
		$mpdf->setLogger(new class extends \Psr\Log\AbstractLogger {
			public function log($level, $message, array $context = array())
			{
				switch ($level){
					case Psr\Log\LogLevel::ERROR:
						Prado::log("MPDF: " . $message, TLogger::ERROR);
						break;
					case Psr\Log\LogLevel::WARNING:
						Prado::log("MPDF: " . $message, TLogger::WARNING);
						break;
				}
			}
		});
		
		$lblbg = $this->getBgFile(TRUE, $rotated);
		//html code for debug
		$html = "<html><body>";
		$mpdf->WriteHTML("<html><body>");
		$ipages=0;
		while($ipages<$pages) {
			//$body = "<body>";
			$body = "";
			for($i=0;$i<$numRows;$i++) {
				$posix=0;
				//Y offset of label. Top margin is added here as workaround for constructor margin
				$posiy=($i*($labelHeight+$verticalSpace)) + $marginTop;
				for($j=0;$j<$numColumns;$j++) {
					if( ($item = $items->shift()) != FALSE ) {
						$dbentry = $item->toArray();
						//X offset of label. Left margin is added here as workaround for constructor margin
						$posix=($j*($labelWidth+$horizontalSpace)) +  $marginLeft;
						//Build the label
						$label = '<div style="position: absolute;';
						if($dbg) $label .= " border: 1px solid black;";
						if( $lblbg != ''){
							$label .= " background: url('data:image/png;base64,".$lblbg."');";
						}
						if($rotated) {
							$label .= " rotate: 90;";
							$label .= " height: {$labelWidth}mm;";
							$label .= " width: {$labelHeight}mm;";
						}else{
							$label .= " width: {$labelWidth}mm;";
							$label .= " height: {$labelHeight}mm;";
						}
						$label .= " left: {$posix}mm;";
						$label .= " top: {$posiy}mm";
						$label .= '">';

						//$actualLibraryName = Prado::getApplication()->getUser()->getActualLibrary()->getLabel();
						
						//Parse all placeholder to create label content
						foreach($labelFields as $labelRow)
						{
							preg_match_all('/{(.*?)}/', $labelRow, $placeholders);
							
							$search = array();
							$replace = array();
							$directive = '';
							
							foreach($placeholders[1] as $placeholder) {								
								//every placeholder can have a directive like TITLE:12
								$phfields = explode(':', $placeholder);
								
								//fieldname is always the first element 
								$fieldname = $phfields[0];
								$fielddata = NULL;
								
								if(array_key_exists($fieldname, $dbentry)) {
									$fielddata = $dbentry[$fieldname];
								}elseif( $fieldname == 'bibn' || $fieldname == 'bibd' ){
									$lib = LibraryQuery::create()->findOneByLibraryId($dbentry['olid']);
									if($lib instanceof Library) {
										if( $fieldname == 'bibn' ) {
											$fielddata = $lib->getLabel();
										}elseif( $fieldname == 'bibd' ) {
											$fielddata = $lib->getDescription();
										}
									}
									
								}
								
								
								
								$search[] = '{'.$placeholder.'}';
								
								if( is_null($fielddata) || trim($fielddata) == '') {
									$replace[] = '';
								}else{
									
									if(count($phfields) > 1) {
										$fielddata = $this->applyDirectiveToClavisField($phfields[1], $fielddata);
									}
									
									if( $fieldname == 'bar' )	{
										$replace[] = '<barcode code="' . trim($fielddata) . '" type="C128A" size=".5" height="1cm" />';
									}elseif( $fieldname == 'icona' ) {
										$replace[] = '<img src="'. $this->getPage()->getTheme()->getBaseUrl() . '/itemicons/'. $item->getItemiconFile() .'" />';
									}else{
										$replace[] = $fielddata;
									}
								}
								
							}
							$realData = str_replace($search, $replace, $labelRow);
							
							$label .= $realData;
						}
						$label .= '</div>';
						//Add label to body
						$body .= $label . "\n";
					}
				}
			}
			//$body .= "</body>";
			//html code for debug 
			if($dbg) $html .= $body;
			
			$mpdf->WriteHTML($body);
			$ipages++;
			//add a page if needed.
			if($ipages<$pages)	$mpdf->addPage();
		}
		//Write html code to file if debug
		if($dbg) {
			$html .= "</body></html>";
			$fname = "/tmp/" . $sheetName . ".html";
			Prado::log("Writing {$fname}");
			file_put_contents($fname, $html);
		}
		$mpdf->WriteHTML("</body></html>");

		$pdfname = $sheetName . '_' . date('YmdHis') . '.pdf';
		
		//$mpdf->Output($pdfname,"D");
		
		$tmpdir = Prado::getPathOfNamespace('Storage.temp');
		$tmpFileName=  "{$tmpdir}/{$pdfname}";
		$mpdf->Output($tmpFileName,"F");
		$resp = Prado::getApplication()->getResponse();
		$resp->clear();
		$resp->setCacheControl('nocache');
		$resp->writeFile($tmpFileName, NULL, 'pdf', NULL, TRUE, $pdfname);
		unlink($tmpFileName);
		die();
	}
	
	public function raiseWriteMessageEvent($msg, $type=ClavisMessage::INFO) {
		$this->broadcastEvent(
			'OnClavisWriteMessage',
			$this,
			new TBroadcastEventParameter('ClavisWriteMessage', ['msg' => $msg, 'type' => $type])
			);
	}
}
