<?php
/**
 * ClavisPatronAccessKeyList class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Widgets
 */

/**
 * ClavisPatronAccessKeyList Class
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Widgets
 * @since 2.6.1
 */
class ClavisPatronAccessKeyList extends TTemplateControl {

	public function onLoad($param) {
		parent::onLoad($param);
		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallBack()) {
			$this->populate();
		}
	}

	public function populate() {
		$pageSize = $this->AccessKeyGrid->getPageSize();
		$currentIndexPage = $this->AccessKeyGrid->getCurrentPage();
		$q = LibraryValueQuery::create()
			->filterByValueClass('ACCESSKEY')
			->filterByValueLibraryId($this->getUser()->getActualLibraryId())
			->orderByValueKey();
		$recCount = $q->count();
		$this->AccessKeyGrid->setVirtualItemCount($recCount);
		$this->RecCounter->setText("Record totali: $recCount");
        $q->limit($pageSize)->offset($currentIndexPage * $pageSize);
        $sects = $q->find();
		$this->AccessKeyGrid->setDataSource($sects);
		$this->AccessKeyGrid->dataBind();
	}

	public function onCancel() {
		$this->searchCancel(null, null);
	}

	public function changePage($sender,$param) {
		$this->AccessKeyGrid->SelectedItemIndex = -1;
		$this->AccessKeyGrid->EditItemIndex = -1;
		$this->AccessKeyGrid->setCurrentPage($param->NewPageIndex);
		$this->getPage()->globalRefresh();
	}

	public function getPopupFlag() {
		return $this->getPage()->IsPopup();
	}
	public function getUnlinkFlag() {
		return $this->getPage()->IsUnlink();
	}
	public function globalRefresh() {
		$this->populate();
	}

	protected function updateAccessKey($key,$newkey,$newlabel) {
		$newkey = trim($newkey);
		$ak = LibraryValuePeer::retrieveByPK($key,'ACCESSKEY',$this->getUser()->getActualLibraryId());
		if ($ak !== null) {
			if ($key!=$newkey) {
				/* check for duplicates */
				$dupsec = LibraryValuePeer::retrieveByPK($newkey,'ACCESSKEY',
					$this->getUser()->getActualLibraryId());
				LibraryValuePeer::getLibraryValue('ACCESSKEY',$newkey,$this->getUser()->getActualLibraryId());
				if ($dupsec !== null && $dupsec->getValueKey() == $newkey) {
					$this->getPage()->writeMessage(Prado::localize('La chiave specificata è già assegnata ad un\'altro accesso.'),
						ClavisMessage::ERROR);
				} else {
					$conn = Propel::getConnection();
					try {
						$conn->beginTransaction();
						$ak->updateKey($newkey);
						$ak = LibraryValuePeer::retrieveByPK($newkey,'ACCESSKEY',$this->getUser()->getActualLibraryId());
						$conn->commit();
						ChangelogPeer::logAction($ak, ChangelogPeer::LOG_UPDATE, $this->getUser(),
							"Aggiornato accesso [{$ak->getValueKey()} - {$ak->getValueLabel()}] della biblioteca ".
							$ak->getValueLibraryId());
						$this->getPage()->writeMessage(Prado::localize('Aggiornato accesso [{srccode} - '.
							'{srclabel}]',array(
							'srccode'	=> $ak->getValueKey(),
							'srclabel'	=> $ak->getValueLabel())),ClavisMessage::INFO);
					} catch (Exception $e) {
						$conn->rollBack();
					}
				}
			}
			$ak->setValueLabel($newlabel);
			$ak->save();
		} else {
			$this->getPage()->writeMessage(Prado::localize('Si è verificato un errore interno.
					Si prega di contattare il fornitore del software per comunicare l\'accaduto.'),
				ClavisMessage::ERROR);
			Prado::log("AccessKey not found / key [{$key}], newkey [{$newkey}], newlabel [{$newlabel}].");
		}
	}

	public function itemCreated($sender,$param) {
		$item = $param->Item;
		if ($item->ItemType==='EditItem') {}
		if ($item->ItemType==='Item' || $item->ItemType==='AlternatingItem' || $item->ItemType==='EditItem') {
			// add an alert dialog to delete buttons
			$item->DeleteColumn->Button->Attributes->onclick='if(!confirm(\''.
				Prado::localize('Sei sicuro di voler eliminare questo accesso?').'\')) return false;';
		}
	}

	public function editItem($sender,$param) {
		$this->AccessKeyGrid->EditItemIndex = $param->Item->ItemIndex;
		$this->populate();
	}

	public function saveItem($sender,$param) {
		$item = $param->Item;
		$this->updateAccessKey(
			$this->AccessKeyGrid->DataKeys[$item->ItemIndex],
			$item->KeyColumn->TextBox->getText(),
			$item->LabelColumn->TextBox->getText()
		);
		$this->AccessKeyGrid->EditItemIndex=-1;
		$this->populate();
	}

	public function cancelItem($sender,$param) {
		$this->AccessKeyGrid->EditItemIndex = -1;
		$this->populate();
	}

	public function deleteItem($sender,$param) {
		$item = $param->Item;
		$this->AccessKeyGrid->SelectedItemIndex = $item->ItemIndex;
		$ak = LibraryValuePeer::retrieveByPK(
			$this->AccessKeyGrid->DataKeys[$item->ItemIndex],
			'ACCESSKEY',
			$this->getUser()->getActualLibraryId());
		if ($ak instanceof LibraryValue) {
			$ak->delete();
			ChangelogPeer::logAction($ak, ChangelogPeer::LOG_DELETE, $this->getUser(),
				"Eliminato accesso [{$ak->getValueKey()} - {$ak->getValueLabel()}] della biblioteca ".
				$ak->getValueLibraryId());
			$this->getPage()->writeMessage(Prado::localize('Eliminato accesso [{srccode} - '.
				'{srclabel}]',array(
					'srccode'	=> $ak->getValueKey(),
					'srclabel'	=> $ak->getValueLabel())),ClavisMessage::INFO);
		}
		$this->populate();
	}

	public function showNewAccessKeyPanel($sender,$param) {
		$this->NewAccessKeyPanel->setVisible(true);
		$this->populate();
	}

	public function hideNewAccessKeyPanel($sender,$param) {
		$this->NewAccessKeyPanel->setVisible(false);
		$this->populate();
	}

	public function validateUniqueKey($sender,$param) {
		$dupsec = LibraryValuePeer::retrieveByPK($param->Value,'ACCESSKEY',
			$this->getUser()->getActualLibraryId());
		if ($dupsec !== null && $dupsec instanceof LibraryValue)
			$param->IsValid = false;
	}

	public function addAccessKey($sender,$param) {
		if (!$this->getPage()->getIsValid())
			return;
		$sec = new LibraryValue();
		$sec->setValueClass('ACCESSKEY');
		$sec->setValueLibraryId($this->getUser()->getActualLibraryId());
		$sec->setValueKey(trim($this->NewKey->getText()));
		$sec->setValueLabel(trim($this->NewLabel->getText()));
		$sec->save();
		$this->getPage()->writeMessage(Prado::localize('Accesso "{value}" creato correttamente.',
			array('value' => $this->NewLabel->getText())),ClavisMessage::INFO);
		$this->hideNewAccessKeyPanel($sender,$param);
	}

}
