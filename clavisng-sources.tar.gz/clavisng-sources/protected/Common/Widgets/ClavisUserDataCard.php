<?php

/**
 * ClavisUserDataCard class
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @version 2.8.8
 * @package Widgets
 * @since 2.0
 */

class ClavisUserDataCard extends TActiveLabel
{
    const AGE_LIMIT = 18;

	private $_bufferSessionName;
	protected $_loanmanager;
	
	private function initVars()
	{
		$uniqueId = $this->getUniqueID();
		$this->_bufferSessionName = 'BufferSessionName' . $uniqueId;

		$this->_loanmanager = $this->getApplication()->getModule('loan');
	}

	public function onInit($param)
	{
		parent::onInit($param);
		$this->initVars();

		if (!$this->getPage()->getIsPostBack())
			$this->setBuffer(null);
	}

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (($buffer = $this->getBuffer()) != null)
			$this->setText($buffer);
	}

	public function setBuffer($buffer = null)
	{
		$this->getApplication()->getSession()->add($this->_bufferSessionName, $buffer);
	}

	public function getBuffer()
	{
		$buffer = $this->getApplication()->getSession()->itemAt($this->_bufferSessionName);
		return $buffer;
	}

	public function populate($patronId = null)
	{
		$patron = null;
		$patron = PatronQuery::create()->findPk($patronId);

		if ((!is_null($patron)) 
				&& ($patron instanceof Patron))
		{
			$buffer = '<fieldset class="formfieldset userdatacard">
						<legend class="formlegend">' . Prado::localize('Dati utente') . '</legend>
						<table style="text-align: left;" cellpadding="2"><tbody>';

			$barcode = $patron->getBarcode();
			$duplicateBarcodeFlag = PatronPeer::isBarcodeDuplicate($barcode);

			if ($duplicateBarcodeFlag)
			{
				$buffer .= '<tr><td colspan="2" class="mediumsgnaps" style="color: red;"> '
								. Prado::localize('ATTENZIONE: BARCODE DUPLICATO').'&nbsp;&nbsp;'
								. '<a href="'.$this->getService()->constructUrl('Circulation.PatronList', array('barcode'=>$barcode))
								. '">'.Prado::localize('risolvi').'</a></td></tr>';
				
				$this->getPage()->setReturnPageUrl();
			}

			$buffer .= '<tr><td style="vertical-align: top;">';
			$photoId = $patron->getPhotoFileId();

			$buffer .= '<img src="'
							. ($photoId ? $this->getRequest()->constructUrl('file',$photoId) : 'themes/Default/anonymous.jpg' )
							. '" style="max-height: 140px;"/></td><td style="vertical-align: top;">';

			switch ($this->_loanmanager->IsPatronAllowedToLoan($patron))
			{
				case ClavisLoanManager::LOAN_PATRONNOTENABLED:
					$buffer .= '<p class="bordered"><b>'.Prado::localize("L'utente non è abilitato al prestito").'</b></p>';
					
					break;
				
				case ClavisLoanManager::LOAN_REACHEDMAX:
					$buffer .= '<p class="bordered"><b>'.Prado::localize("L'utente ha superato il numero massimo di prestiti").'</b></p>';
					
					break;
			}
			
			$card_expire = $patron->getCardExpire('U');
			$document_expiry = $patron->getDocumentExpiry('U');

			if (($card_expire > -3600) && (time() > $card_expire))
				$buffer .= '<p class="bordered"><b>'.Prado::localize("Attenzione: carta scaduta").'</b></p>';

			if (($document_expiry > -3600) && (time() > $document_expiry))
				$buffer .= '<p class="bordered"><b>'.Prado::localize("Attenzione: documento d'identità scaduto").'</b></p>';

			if (ClavisParamQuery::getParam('CLAVISPARAM','PatronAccessControl') == 'true'
					&& ($patron->getCheckIn() == null || $patron->getCheckOut() != null
						|| $patron->getCheckIn('U') < mktime(0,0,0)))
				$buffer .= '<p class="bordered"><b>'.Prado::localize("Attenzione: l'utente non ha effettuato l'accesso in biblioteca").'</b></p>';

			if (($alert = $patron->getAccessNote()) != '')
				$buffer .= "<b>" . Prado::localize("Nota"). "</b>: " . "{$alert}<br /><hr /><br />";

			$patronCompleteName = $patron->getCompleteName();
			$birthDate = Clavis::dateFormat($patron->getBirthDate('U'),'shortdate');
			$birthCity = $patron->getBirthCity();
			$birthProvince = $patron->getBirthProvince();
			$contacts = $patron->getContacts();

            if ($this->getApplication()->getModule("fee") instanceof TModule)
			{
                if ($this->getApplication()->getModule("fee")->patronHasFee($patron) )
                    $buffer .= '<p class="bordered"><b>' . Prado::localize("L'utente ha riammissioni") . '</b></p>';
			}
			
            if($patron->hasLateLoans())
                $buffer .= '<p class="bordered"><b>' . Prado::localize("L'utente ha prestiti in ritardo") . '</b></p>';

            if($patron->hasPendingWallets())
                $buffer .= '<p class="bordered"><b>' . Prado::localize("L'utente ha pagamenti in sospeso") . '</b></p>';

            if ($patron->getPatronAge() < self::AGE_LIMIT)
                $buffer .= '<p class="bordered"><b>' . Prado::localize("L'utente è un minore di 18 anni") . '</b></p>';

			$buffer .= "<a href=\"index.php?page=Circulation.PatronViewPage&id={$patronId}\">{$patronCompleteName}</a><br />".
				Prado::localize('barcode: {barcode}',array('barcode'=>$barcode)).'<br />';

			$genderBorn = (strtolower($patron->getGender()) == 'f'
								? "nata"
								: "nato");
				
			if ($birthDate && $birthCity && $birthProvince)
			{
				$buffer .= Prado::localize("$genderBorn il {birthdate} a {birthcity} ({birthprovince})",
												array(	'birthdate' => $birthDate, 
														'birthcity' => $birthCity, 
														'birthprovince' => $birthProvince ));
			}
			elseif ($birthDate && $birthCity)
			{
				$buffer .= Prado::localize("$genderBorn il {birthdate} a {birthcity}",
												array(	'birthdate' => $birthDate, 
														'birthcity' => $birthCity ));
			}
			elseif ($birthCity && $birthProvince)
			{	
				$buffer .= Prado::localize("$genderBorn a {birthcity} ({birthprovince})",
												array(	'birthcity' => $birthCity, 
														'birthprovince' => $birthProvince ));
			}
			elseif ($birthDate)
			{
				$buffer .= Prado::localize("$genderBorn il {birthdate}",
												array('birthdate' => $birthDate));
			} 

			foreach ($contacts as $contact)
			{
				$buffer .= '<br />';
				$type = $contact->getContactTypeString();
				$data = $contact->getContactValue();
				$typeNum = $contact->getContactType();
				
				if (($type != '') 
						&& ($data != '')) 
				{
					$buffer .= ($typeNum == 'E') ?
										$type . ": <a href='mailto:" . $data . "'>" . $data . "</a>":
										$type . ": " . $data;
				}
			}

			$circStatus = $patron->getCirculationStatus();
			$buffer .= "</td></tr></tbody></table><table><tbody>";

			$buffer .= "<tr><td></td><td>". Prado::localize("In corso") . "</td><td>" . Prado::localize("Rimanenti") . "</td><td>" . Prado::localize("Totali") . "</td></tr>";
			$buffer .= "<tr><td>". Prado::localize("Operazioni") . "</td><td align=\"right\">{$circStatus['Operations']}</td><td align=\"right\">{$circStatus['AvailOperations']}</td><td align=\"right\">{$circStatus['MaxOperations']}</td></tr>";
			$buffer .= "<tr><td>" . Prado::localize("Prestiti") . "</td><td align=\"right\">{$circStatus['Loans']}</td><td align=\"right\">{$circStatus['AvailLoans']}</td><td align=\"right\">{$circStatus['MaxLoans']}</td></tr>";
			$buffer .= "<tr><td>". Prado::localize("Prenotazioni") ."</td><td align=\"right\">{$circStatus['Reservations']}</td><td align=\"right\">{$circStatus['AvailReservations']}</td><td align=\"right\">{$circStatus['MaxReservations']}</td></tr>";

			if ($circStatus['PatronMaxLoans'] > 0)
			{
				$buffer .= "<tr><td>" . Prado::localize("Max documenti") . "</td><td align=\"right\">{$circStatus['PatronMaxLoans']}</td><td></td><td></td></tr>";
			}
			else
			{
				foreach($circStatus['ItemMedia'] as $im => $iv)
                {
					if($iv['Loan'] > 0)
						$buffer .= "<tr><td>{$im}</td><td align=\"right\">{$iv['Loan']}</td><td align=\"right\">{$iv['AvailLoan']}</td><td align=\"right\">{$iv['MaxLoan']}</td></tr>";
                }
			}
            
			$buffer .= "</tbody></table></fieldset>";

			$this->setBuffer($buffer);
			$this->setText($buffer);
		}
		else
		{
			$this->setText("");
			$this->setBuffer("");
			
			return false;
		}

		return true;
	}		// end of populate()

}