<?php


/**
 * ClavisConsortiaList
 *
 * @author Max Pigozzi <mpigozzi@e-portaltech.it>
 * @link http://www.e-portaltech.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @license http://www.e-portaltech.it/license/
 *
 */


class ClavisConsortiaList extends TTemplateControl {

	public function onLoad($param) 	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallBack())
			$this->populateConsortiaGrid();
	}

	public function searchConsortia($sender, $param) {
		$this->ConsortiaGrid->setCurrentPage(0);
		$this->populate();
	}

	public function populate() {
		$this->populateConsortiaGrid();
	}

	private function populateConsortiaGrid() {
		$pageSize = $this->ConsortiaGrid->PageSize;
		$currentPage = $this->ConsortiaGrid->getCurrentPage();

		$c = new Criteria();
		$c->addAscendingOrderByColumn(ConsortiaPeer::CONSORTIA_ID);

		$filter = trim($this->DescriptionFilter->getText());
		if ($filter != '')
			$c->add(ConsortiaPeer::DESCRIPTION, '%' . $filter . '%', Criteria::LIKE);

		$this->ConsortiaGrid->setVirtualItemCount(ConsortiaPeer::doCount($c));

		$c->setLimit($pageSize);
		$c->setOffset($currentPage * $pageSize);

		$consortia = ConsortiaPeer::doSelect($c);

		$data = array();
		foreach ($consortia as $consortium)     {
			$p = array();
			$p['Id'] = $consortium->getConsortiaId();
			$p['Description'] = $consortium->getDescription();

			$data[] = $p;
		}

		//$this->ConsortiaGrid->setCurrentPageIndex($currentPage);
		$this->ConsortiaGrid->setDataSource($data);
		$this->ConsortiaGrid->dataBind();
	}

	public function changePage($sender,$param)
	{
		$this->ConsortiaGrid->setCurrentPage($param->NewPageIndex);
		$this->populateConsortiaGrid();
	}

	public function getPopupFlag()
	{
		return $this->getPage()->IsPopup();
	}

	public function onCleanSearch($sender, $param)
	{
		$this->DescriptionFilter->setText('');
		$this->populate();
	}
}

?>