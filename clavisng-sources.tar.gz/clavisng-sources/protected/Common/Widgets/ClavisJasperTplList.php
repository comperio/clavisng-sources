<?php

/**
 * ClavisJasperTplList
 *
 * This widgets can manage Jasper templates.
 * It relies on JasperModule and needs read-write on template dorectory.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2010 Comperio srl
 * @version 2.7
 * @package Widgets
 * @since 2.2
 */

class ClavisJasperTplList extends TTemplateControl {

	private $_jasperModule;
	private $_directoryWritable;
	private $_librarian;

	public function onLoad($param)
	{
		parent::onLoad($param);
		$this->_jasperModule = $this->getApplication()->getModule('JReport');
		$this->_directoryWritable = is_writable($this->_jasperModule->getReportPath());

		if (!$this->getPage()->getIsPostBack())
		{
			$this->populate();
		}

		if (is_null($this->getObjectId()) || (is_null($this->getObjectClass())) )
			$this->DoInsertTpl->setEnabled(false);
		else
			$this->DoInsertTpl->setEnabled(true);
	}

	//getter/setter
	public function setObjectId($value)
	{
		$this->setControlState('object_id', $value, null);
	}

	public function getObjectId()
	{
		return $this->getControlState('object_id',null);
	}

	public function setReadOnly($value)
	{
		$this->setControlState('ReadOnly',$value,'true');
	}

	public function getReadOnly()
	{
		return $this->_directoryWritable && $this->getControlState('ReadOnly','true');
	}

	public function setLibrarian($librarian)
	{
		$this->_librarian = $librarian;
		$this->setControlState('librarian', $librarian, null);
	}

	public function getLibrarian()
	{
		if(is_null($this->_librarian))
			$this->_librarian = $this->getControlState('librarian', null);
		return $this->_librarian;
	}

	public function populate()
	{
		if ($this->getReadOnly() == 'true') {
			$this->TplPanel->setVisible(false);
		} else if ($this->getReadOnly() == 'false') {
			$this->TplPanel->setVisible(true);
		}
		$this->populateTplGrid();
	}

	private function populateTplGrid()
	{
		$pageSize = $this->TplGrid->getPageSize();
		$currentIndexPage = $this->TplGrid->getCurrentPage();

		$criteria = new Criteria();
		$criteria->add(DocumentTemplatePeer::TEMPLATE_MEDIA,DocumentTemplatePeer::MEDIA_JASPER);

		$this->RecCounter->setText($recCount);
		$this->RecCounterPanel->setVisible($recCount > 0);
		$this->TplGrid->VirtualItemCount = $recCount;

		$tpls = DocumentTemplatePeer::doSelect($criteria);

		$this->TplGrid->setDataSource($tpls);
		$this->TplGrid->dataBind();
	}

	public function onChangePage($sender,$param)
	{
		$this->TplGrid->setCurrentPage($param->NewPageIndex);
		$this->populate();
	}

	public function globalRefresh()
	{
		$this->getPage()->globalRefresh();
	}

	public function getPopupFlag()
	{
		return $this->getPage()->IsPopup();
	}

	public function getUnlinkFlag()
	{
		return $this->getPage()->IsUnlink();
	}

	public function globalEditCancel()
	{
	}


	protected function onFileChoosen($sender, $param)
	{
		if ($sender->getHasFile()) {
   			$original_parts = pathinfo($sender->getFileName());
			$original_name = $original_parts['basename'];

   			$this->setCurrentLocalFilename($sender->getLocalName());
   			$this->setCurrentOriginalFilename($original_name);
   			$this->setCurrentMimeType($sender->getFileType());
   		} else {
   			$this->setCurrentLocalFilename(null);
   			$this->setCurrentOriginalFilename(null);
   			$this->setCurrentMimeType(null);
   		}
	}

	protected function onInsertTpl($sender, $param)
	{
		if (is_null($this->getObjectClass()) || (is_null($this->getObjectId()))) {
			$this->getPage()->writeMessage(Prado::localize('Errore nell\'inserimento dell\'allegato.
				Contattare un amministratore.'),ClavisMessage::ERROR);
			Prado::log("ClavisFileAttachment::onInsertAttachment() : non è definito l'object di riferimento");
			return;
		}

		if (is_null($this->getCurrentLocalFilename())) {
			$this->getPage()->writeMessage(Prado::localize('Scegliere un file da allegare.'),ClavisMessage::ERROR);
			return;
		} else {
			$tplFilename = $this->getCurrentLocalFilename();
			$label = trim($this->AttachLabel->getSafeText());
			if ($label == '')
				$label = null;

			$description = trim($this->AttachDescription->getSafeText());
			if ($description == '')
				$description = null;

			$newTpl = new DocumentTemplate();
			$newTpl->setTemplateMedia(DocumentTemplatePeer::MEDIA_JASPER);
			$newTpl->setTemplateDescription($this->NewTplDescription->getSafeText());
			$newTpl->setTemplateTitle($this->NewTplTitle->getSafeText());
			//$newTpl->setTemplateSubject($filepath);
			$newTpl->setTemplateClass('JR_SOMETHING');
			$newTpl->setTemplateLang('it_IT');
			$newTpl->setLibraryId(123);

			/*if (!is_null($last_entry)) {

				ChangelogPeer::logAction($this->getObjectClass(), ChangelogPeer::LOG_UPDATE, $this->getUser(),
					"aggiunto allegato (\"".$last_entry[0]->getFilename()."\" - id:".$last_entry[0]->getAttachmentId().")",
					$this->getObjectId());

				$this->clearCurrentEntry();
				$this->populate();
				$this->AttachPanel->setUserOpen(false);
			} else {
				$this->getPage()->writeMessage(Prado::localize('Errore nell\'inserimento dell\'allegato. Si prega di contattare il Centro Servizi.'),
					ClavisMessage::ERROR);
				Prado::log("ClavisFileAttachment::onInsertAttachment() : errore di inserimento usando ClavisStorageManager");
				return;
			}*/
		}
	}

	protected function onDeleteAttachment($sender, $param)
	{
		$attachment = AttachmentQuery::create()->findPK($param->CommandParameter);
		if ($attachment instanceof Attachment) {
			if ($attachment->delete()) {
				$this->getPage()->writeMessage(Prado::localize('Allegato rimosso correttamente'),ClavisMessage::INFO);
				ChangelogPeer::logAction($this->getObjectClass(), ChangelogPeer::LOG_UPDATE, $this->getUser(),
					"rimosso allegato ( id:".$attachmentId.")", $this->getObjectId());
			} else {
				$this->getPage()->writeMessage(Prado::localize("Errore nella rimozione dell'allegato"),ClavisMessage::ERROR);
			}
			$this->populate();
		}
	}

	protected function onUpdateAttachment($sender, $param) {
		$attachmentId = $param->CommandParameter;
		if ($attachmentId < 1) {
			$this->getPage()->writeMessage(Prado::localize('L\'ID allegato non è valido.'),ClavisMessage::ERROR);
			return;
		}
		$a = AttachmentPeer::retrieveByPK($attachmentId);
		$this->AttachPanel->setVisible(false);
		$this->EditAttachPanel->setVisible(true);
		$this->EditAttachmentType->populateList();
		$this->EditAttachID->setValue($attachmentId);
		$this->EditAttachName->setText($a->getFileName());
		$this->EditAttachmentType->setSelectedValue($a->getAttachmentType());
		$this->EditAttachLabel->setText($a->getFileLabel());
		$this->EditAttachDescription->setText($a->getFileDescription());
	}

	protected function onUpdateAttachCancel($sender,$param) {
		$this->AttachPanel->setVisible(true);
		$this->EditAttachPanel->setVisible(false);
		$this->EditAttachID->setValue(null);
		$this->populate();
	}

	protected function onUpdateAttachConfirm($sender,$param) {
		$a = AttachmentPeer::retrieveByPK($this->EditAttachID->getValue());
		if ($a instanceof Attachment) {
			try {
				$a->setAttachmentType($this->EditAttachmentType->getSelectedValue());

				$label = trim($this->EditAttachLabel->getSafeText());
				if ($label == '')
					$label = null;
				$a->setFileLabel($label);

				$description = trim($this->EditAttachDescription->getSafeText());
				if ($description == '')
					$description = null;
				$a->setFileDescription($description);
				$a->save();
				ChangelogPeer::logAction($a, ChangelogPeer::LOG_UPDATE, $this->getUser(),
					"aggiornate proprietà allegato ( id:".$a->getAttachmentId().")");
				$this->getPage()->writeMessage(Prado::localize('Allegato modificato con successo'),ClavisMessage::INFO);
			} catch (Exception $e) {
				$this->getPage()->writeMessage(Prado::localize("Impossibile completare l'aggiornamento.").
					"<br />{$e}",ClavisMessage::ERROR);
			}
		} else {
			$this->getPage()->writeMessage(Prado::localize('Allegato non valido: ID '),$this->EditAttachID->getValue());
		}
		$this->AttachPanel->setVisible(true);
		$this->EditAttachPanel->setVisible(false);
		$this->EditAttachID->setValue(null);
		$this->populate();
	}

	protected function clearCurrentEntry()
	{
		$this->setCurrentLocalFilename(null);
		$this->setCurrentOriginalFilename(null);
		$this->setCurrentMimeType(null);
		$this->AttachDescription->setText('');
		$this->AttachmentType->setSelectedValue(AttachmentPeer::TYPE_COVER);
	}

	public function setCurrentLocalFilename($filename)
	{
		$this->setControlState('current_local_filename', $filename);
	}

	public function getCurrentLocalFilename()
	{
		return $this->getControlState('current_local_filename', null);
	}

	public function setCurrentOriginalFilename($filename)
	{
		$this->setControlState('current_original_filename', $filename);
	}

	public function getCurrentOriginalFilename()
	{
		return $this->getControlState('current_original_filename', null);
	}

	public function setCurrentMimeType($mimeType)
	{
		$this->setControlState('current_mime_type', $mimeType);
	}

	public function getCurrentMimeType()
	{
		return $this->getControlState('current_mime_type', null);
	}
}
?>