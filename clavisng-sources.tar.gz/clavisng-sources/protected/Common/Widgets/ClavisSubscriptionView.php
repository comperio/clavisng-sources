<?php

/**
 * ClavisSubscriptionView
 *
 * @author Max Pigozzi <mpigozzi@e-portaltech.it>
 * @link http://www.e-portaltech.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @license http://www.e-portaltech.it/license/
 *
 */
class ClavisSubscriptionView extends TTemplateControl
{
	/**
	 * @var Subscription
	 */
	private $_subscription = null;

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsPostBack())
		{
			$this->getSubscription();
			$this->populate();
		}
	}

	public function populate()
	{
		if ($this->_subscription === null)
			return;

		//TODO
		$manifestation = ManifestationPeer::retrieveByPK($this->_subscription->getManifestationId());
		if (!is_null($manifestation))
		{
			$this->Title->setText($manifestation->getTitle());
			$this->Title->setNavigateUrl($this->getService()->constructUrl('Catalog.Record', array('manifestationId' => $manifestation->getManifestationId())));
		}

		$library = LibraryQuery::create()->findPk($this->_subscription->getLibraryId());
		if (!is_null($library))
			$this->Library->setText($library->getLabel());

		$this->SubscriptionStatus->setText(LookupValuePeer::getLookupValue('SUBSCRIPTIONSTATUS', $this->_subscription->getSubscriptionStatus()));
		$this->SubscriptionType->setText(LookupValuePeer::getLookupValue('SUBSCRIPTIONTYPE', $this->_subscription->getSubscriptionType()));

		$supplier = SupplierQuery::create()->findPk($this->_subscription->getSupplierId());
		if (!is_null($supplier))
			$this->Supplier->setText($supplier->getSupplierName());

		$budget = BudgetQuery::create()->findPk($this->_subscription->getBudgetId());
		if (!is_null($budget))
			$this->Budget->setText($budget->getBudgetTitle());

		$this->Volume->setText($this->_subscription->getVolume());
		$this->Year->setText($this->_subscription->getYear());
		$this->Frequence->setText(UnimarcCodesPeer::getValueLabel('110', 'a', 1, $this->_subscription->getFrequence()));
		$this->Tolerance->setText($this->_subscription->getTolerance());

		$this->StartDate->setValue($this->_subscription->getStartDate('U'));
		$this->EndDate->setValue($this->_subscription->getEndDate('U'));

		$this->Management->setText(LookupValuePeer::getLookupValue('SUBSCRIPTIONMANAGEMENT', $this->_subscription->getManagement()));

		$payment = null;
		$payment = unserialize($this->_subscription->getPayment());
		if (is_array($payment))
		{
			if (array_key_exists('PayType', $payment))
				$this->PayType->setText($payment['PayType']);

			if (array_key_exists('PayData', $payment))
				$this->PayData->setText($payment['PayData']);

			if (array_key_exists('PayCc', $payment))
				$this->PayCc->setText($payment['PayCc']);

			if (array_key_exists('PayPrice', $payment))
				$this->PayPrice->setText($payment['PayPrice']);

			$this->PaySuspended->setChecked(
					(array_key_exists('PaySuspended', $payment) && $payment['PaySuspended'] == 'Y'));
		}

		$this->Note->setText($this->_subscription->getNotes());
	}

	public function setSubscription($subscription)
	{
		$this->_subscription = $subscription;
		$this->setControlState("subscription", $subscription, null);
	}

	public function getSubscription()
	{
		if (is_null($this->_subscription))
		{
			$this->_subscription = $this->getControlState("subscription", null);
		}

		return $this->_subscription;
	}
}
