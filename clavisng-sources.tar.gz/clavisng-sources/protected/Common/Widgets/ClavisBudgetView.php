<?php
/**
 * ClavisBudgetView
 *
 * @author Max Pigozzi <mpigozzi@e-portaltech.it>
 * @link http://www.e-portaltech.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @version 2.7
 * @package Widgets
 * @since 2.2
 */
class ClavisBudgetView extends TTemplateControl
{
	/**
	 * @var Budget
	 */
	private $_budget = null;
	public $_systemCurrency;

	private function initVars()
	{
		$this->_systemCurrency = ClavisParamQuery::getParam('CLAVISPARAM', 'SystemCurrency');
	}

	public function onInit($param)
	{
		parent::onInit($param);
		$this->initVars();

		if (!$this->getPage()->getIsPostBack())
			$this->setBudget(null);
	}

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsPostBack())
		{
			$this->getBudget();
			$this->populate();

			if ($this->_budget instanceof Budget)
			{
				$this->ItemList->setBudgetId($this->_budget->getBudgetId());
				$this->populateItemList();
			}
		}
	}

	public function populateItemList()
	{
		$this->ItemList->populate();
	}

	public function populate()
	{
		$budget = $this->getBudget();
		if (!($budget instanceof Budget))
			return;

		$this->BudgetTitle->setText($budget->getBudgetTitle());
		$this->StartValidity->setValue($budget->getStartValidity('U'));
		$this->EndValidity->setValue($budget->getEndValidity('U'));
		$this->BudgetYear->setText($budget->getBudgetYear());
		$this->LibraryId->setValue($budget->getLibraryId());
		$this->Library->setText($budget->getLibrary()->getLabel());
		$this->Total->setText(ClavisBase::numberFormat($budget->getTotalAmount(), '#.00'));

		$invoicedCombo = $budget->getInvoicedCombo();

		if (array_key_exists("TotalAllocated", $invoicedCombo))
			$totalAllocated = $invoicedCombo["TotalAllocated"];
		else
			$totalAllocated = 0;

		if (array_key_exists("TotalInvoiced", $invoicedCombo))
			$totalInvoiced = $invoicedCombo["TotalInvoiced"];
		else
			$totalInvoiced = 0;

		if (array_key_exists("RestAllocated", $invoicedCombo))
			$restAllocated = $invoicedCombo["RestAllocated"];
		else
			$restAllocated = 0;

		if (array_key_exists("RestInvoiced", $invoicedCombo))
			$restInvoiced = $invoicedCombo["RestInvoiced"];
		else
			$restInvoiced = 0;

		$this->TotalAllocated->setText(ClavisBase::numberFormat($totalAllocated, '#.00'));
		$this->TotalInvoiced->setText(ClavisBase::numberFormat($totalInvoiced, '#.00'));
		$this->RestAllocated->setText(ClavisBase::numberFormat($restAllocated, '#.00'));
		$this->RestInvoiced->setText(ClavisBase::numberFormat($restInvoiced, '#.00'));
	}

	/**
	 * setters & getters
	 */
	public function setBudget($budget = null)
	{
		$this->_budget = $budget;
		$this->setControlState("budget", $budget, null);
	}

	public function getBudget()
	{
		$this->_budget = $this->getControlState("budget", null);
		return $this->_budget;
	}
	
}