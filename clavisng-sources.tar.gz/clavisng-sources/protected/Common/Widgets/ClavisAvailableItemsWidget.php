<?php
/**
 * ClavisAvailableItemsWidget file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Widgets
 */

/**
 * ClavisAvailableItemsWidget class
 *
 * This component visualizes a small horizontal panel divided into blocks.
 * Every block has an indication of available items, divided for basin areas,
 * related to a manifestation that is passed as an url parameter.
 * 
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.7
 * @package Widgets
 * @since 2.1
 */

class ClavisAvailableItemsWidget extends TTemplateControl
{
	protected $_loanmanager;
	protected $_requestManager;
	private $_manifestationIdSessionName;
	private $_issueIdSessionName;
	public $_llibraryActive;

	const VIEWMODE_GRAPHIC = "GraphicMode";
	const VIEWMODE_TEXT = "TextMode";
	
	public function initVars()
	{
		$uniqueId = $this->getUniqueID() . $this->getUniqueName();
		$this->_manifestationIdSessionName = 'ManifestationIdSessionName' . $uniqueId;
		$this->_issueIdSessionName = 'IssueIdSessionName' . $uniqueId;

		$this->_loanmanager = $this->getApplication()->getModule('loan');
		$this->_requestManager = $this->getApplication()->getModule('request');
		
		$this->_llibraryActive = LLibraryPeer::isEnabled();
	}

	/**
	 * Here we load the clavis loan manager module, we get the
	 * saved (into session variables) datasource (as a hash), and
	 * we populate the grid in case the page is loaded the first
	 * time.
	 *
	 * @param TEventParameter $param
	 */
	public function onInit($param)
	{
		parent::onInit($param);
		$this->initVars();

		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallback())
		{
			$this->globalReset();
		}
		
		$this->LegendaLabel->setVisible($this->getViewLegenda());
	}
	
	/**
	 * Setters/getters/resetters
	 */
	public function setUniqueName($param = "")
	{
		$this->setControlState("UniqueName", $param, "");
	}

	public function getUniqueName()
	{
		return $this->getControlState("UniqueName", "");
	}

	private function resetManifestationId($param = 0)
	{
		$this->setManifestationId($param);
	}
	
	public function setManifestationId($param = 0)
	{
		$param = intval($param);
		$this->setControlState($this->_manifestationIdSessionName, $param, 0);
	}

	public function getManifestationId()
	{
		return $this->getControlState($this->_manifestationIdSessionName, 0);
	}
	
	private function getManifestation()
	{
		$manifestation = null;
		$manifestationId = intval($this->getManifestationId());
		if ($manifestationId > 0)
			$manifestation = ManifestationQuery::create()
								->findPk($manifestationId);
		
		return $manifestation;
	}
	
	private function resetIssueId($param = 0)
	{
		$this->setIssueId($param);
	}
	
	public function setIssueId($param = 0)
	{
		$param = intval($param);
		$this->setControlState($this->_issueIdSessionName, $param, 0);
	}

	public function getIssueId()
	{
		return $this->getControlState($this->_issueIdSessionName, 0);
	}
	
	private function getIssue()
	{
		$issue = null;
		$issueId = intval($this->getIssueId());
		if ($issueId > 0)
			$issue = IssueQuery::create()
						->findPk($issueId);
		
		return $issue;
	}
	
	public function setViewLegenda($param = true)
	{
		if (strtolower($param) === "false")
			$param = false;
		else
			$param = true;

		$this->setControlState("ViewLegenda", $param, true);
	}

	public function getViewLegenda()
	{
		return $this->getControlState("ViewLegenda", true);
	}
	
	public function setViewMode($param = self::VIEWMODE_GRAPHIC)
	{
		if (is_null($param) || !(is_string($param)))
			$param = self::VIEWMODE_GRAPHIC;
		
		if (strtolower($param) == "text")
			$param = self::VIEWMODE_TEXT;
		
		$this->setControlState("ViewMode", $param, self::VIEWMODE_GRAPHIC);
	}

	public function getViewMode()
	{
		return $this->getControlState("ViewMode", self::VIEWMODE_GRAPHIC);
	}
	
	public function populate()
	{
		$manifestation = $this->getManifestation();
		if (!($manifestation instanceof Manifestation))
			return false;

		$issue = $this->getIssue();
		if ($issue instanceof Issue)
			$issueId = $issue->getIssueId();
		else
			$issueId = null;

		$availableItemsRaw = $this->_loanmanager->countAvailableItemsByBasin(	$manifestation->getManifestationId(),
																				$issueId);

		if ($this->getViewMode() == self::VIEWMODE_GRAPHIC)
		{
			$this->GraphicPanel->setVisible(true);
			$this->TextPanel->setVisible(false);
			
			$dataSource = array();
			foreach ($availableItemsRaw as $distance => $itemCountArray)
			{
				$row = array();

				$row['distance'] = $distance;
				$row['completeMaxDistance'] = ItemRequestPeer::getCompleteMaxDistance($distance, null, false);	// only label, if exists
				$row['availableItemCount'] = $itemCountArray[0];
				$row['allItemCount'] = $itemCountArray[1];

				$row['comboItemCount'] = "$itemCountArray[0]/$itemCountArray[1]";

				$dataSource[] = $row;
			}
			
			$this->GraphicList->setDataSource($dataSource);
			$this->GraphicList->dataBind();
		}
		elseif ($this->getViewMode() == self::VIEWMODE_TEXT)
		{
			$this->GraphicPanel->setCssClass(false);
			$this->TextPanel->setVisible(true);
			
			$textData = "";
			foreach ($availableItemsRaw as $distance => $itemCountArray)
			{
				$textData .= Prado::localize("dist") . " " . ItemRequestPeer::getCompleteMaxDistance($distance, null, false);	// only label, if exists
				$textData .= ": [$itemCountArray[0]/$itemCountArray[1]] - ";
			}

			$this->TextData->setText(rtrim($textData, " - "));
		}
		else	// fallback
		{
			$this->GraphicPanel->setVisible(false);
			$this->TextPanel->setVisible(false);	
		}
	}

	public function getPopupFlag()
	{
		return $this->getPage()->isPopup();
	}

	public function globalRefresh()
	{
		$this->populate();
	}

	public function globalReset()
	{
		$this->resetManifestationId();
		$this->resetIssueId();
	}
	
}
