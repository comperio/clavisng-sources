<?php
/**
 * ClavisRecordList class file.
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Ciro Mattia Gonano
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.8.9
 * @package Widgets
 */

/**
 * ClavisRecordList class
 * Widget to display a list of records and a search form.
 *
 * @author Ciro Mattia Gonano
 * @package Widgets
 * @since 2.8.9
 */
class ClavisRecordList extends TTemplateControl
{
	public $_masterCheck;
	private $_uniqueId;
	private $_llibraryActive = false;
	private $_checked = array();
	private $_searchFields = array(
		//'ean'=>array('key'=>'ean','field'=>'fldin_txt_numbers','facets'=>false,'label'=>'EAN/ISBN/ISSN'),
		'aut'			 => array('key' => 'aut', 'field' => 'fldin_txt_author', 'facets' => false, 'label' => 'Autore'),
		'title'			 => array('key' => 'title', 'field' => 'fldin_txt_title', 'facets' => true, 'label' => 'Titolo'),
		'ft'			 => array('key' => 'ft', 'field' => 'fulltext', 'facets' => false, 'label' => 'Tutto testo'),
		'date'			 => array('key' => 'date', 'field' => 'fldin_str_date', 'facets' => true, 'label' => 'Anno (esatto)'),
		'owner'			 => array('key' => 'owner', 'field' => 'fldin_txt_owner', 'facets' => true, 'label' => 'Possessore'),
		'printer'		 => array('key' => 'printer', 'field' => 'fldin_txt_printer', 'facets' => true, 'label' => 'Tipografo'),
		'subject'		 => array('key' => 'subject', 'field' => 'fldin_txt_subject', 'facets' => true, 'label' => 'Soggetto/Parola chiave', 'phrase' => true),
		'class'			 => array('key' => 'class', 'field' => 'fldin_txt_class', 'facets' => true, 'label' => 'Classe'),
		'classcode'		 => array('key' => 'classcode', 'field' => 'facets_class', 'facets' => true, 'label' => 'Codice Classe'),
		'publisher'		 => array('key' => 'publisher', 'field' => 'fldin_txt_publisherall', 'facets' => true, 'label' => 'Editore'),
		'id_marca'		 => array('key' => 'id_marca', 'field' => 'mrc_d921_s3', 'facets' => true, 'label' => 'Marca tipografica'),
		'place'			 => array('key' => 'place', 'field' => array('mrc_d620_sa','mrc_d630_sd','mrc_d210_sa'), 'facets' => true, 'label' => 'Luogo'),
		'serie'			 => array('key' => 'serie', 'field' => 'mrc_d225_sa', 'facets' => true, 'label' => 'Collana'),
		'collocation'	 => array('key' => 'collocation', 'field' => 'fldis_str_collocation', 'facets' => true, 'label' => 'Segnatura', 'phrase' => true),
		'bid'			 => array('key' => 'bid', 'field' => 'fldin_str_bid', 'facets' => false, 'label' => 'BID', 'phrase' => true),
        'dataclass'	     => array('key' => 'dataclass', 'field' => 'mrc_l_9', 'facets' => true, 'label' => 'Trattamento del dato'),
		'ftnote'		 => array('key' => 'ftnote', 'field' => 'fldin_txt_fulltextattach', 'facets' => false, 'label' => 'Allegato fulltext'),);
	private $_selectFields = array(0				 => array('key' => 0, 'field' => null, 'type' => null, 'label' => '---'),
		'hierlevel'		 => array('key' => 'hierlevel', 'field' => 'mrc_l_8', 'type' => 'map', 'label' => 'Livello gerarchico', 'map' => 'HIERLEVEL'),
		'language'		 => array('key' => 'language', 'field' => 'facets_lang', 'type' => 'special', 'label' => 'Lingua'),
		'man_status'	 => array('key' => 'man_status', 'field' => 'mrc_d901_sf', 'type' => 'map', 'label' => 'Stato notizia', 'map' => 'MANSTATUS'),
		'country'		 => array('key' => 'country', 'field' => 'facets_country', 'type' => 'map', 'label' => 'Paese', 'map' => 'COUNTRIES'),
		'author-role'	 => array('key' => 'author-role', 'field' => array('mrc_d700_s4', 'mrc_d701_s4', 'mrc_d702_s4', 'mrc_d710_s4', 'mrc_d711_s4', 'mrc_d712_s4', 'mrc_d720_s4'), 'type' => 'map', 'label' => 'Ruolo (relator code)', 'map' => 'RELATORCODE'),
		'target'		 => array('key' => 'target', 'field' => 'd100_sa_17', 'type' => 'cdf', 'label' => 'Target di lettura'),
		'contents'		 => array('key' => 'contents', 'field' => 'd105_sa_4', 'type' => 'cdf', 'label' => 'Contenuti'),
		'genre'			 => array('key' => 'genre', 'field' => 'd105_sa_11', 'type' => 'cdf', 'label' => 'Genere letterario'),
		'docform'		 => array('key' => 'docform', 'field' => 'd106_sa_0', 'type' => 'cdf', 'label' => 'Forma del documento'),
		'classedition'	 => array('key' => 'classedition', 'field' => 'mrc_d676_sv', 'type' => 'map', 'label' => 'Edizione dewey', 'map' => 'CLASSEDITION'),
		'liber_genref'	 => array('key' => 'liber_genref', 'field' => 'd109_sa_0', 'type' => 'cdf', 'label' => '[Liber] Genere (fiction)'),
		'liber_genrenf'	 => array('key' => 'liber_genrenf', 'field' => 'd109_sa_9', 'type' => 'cdf', 'label' => '[Liber] Genere (non fiction)'),
		'liber_rating'	 => array('key' => 'liber_rating', 'field' => 'd109_sa_22', 'type' => 'cdf', 'label' => '[Liber] Valutazione'),

     //   'liber_agefrom'	 => array('key' => 'liber_agefrom', 'field' => 'd109_sa_18', 'type' => 'cdf', 'label' => '[Liber] fasce di età: da'),
     //   'liber_ageto'	 => array('key' => 'liber_ageto', 'field' => 'd109_sa_20', 'type' => 'cdf', 'label' => '[Liber] fasce di età: a'),

        'liber_target'	 => array('key' => 'liber_target', 'field' => 'd109_sa_23', 'type' => 'cdf', 'label' => '[Liber] codice di target'),
        'liber_country'	 => array('key' => 'liber_country', 'field' => 'd109_sa_24', 'type' => 'cdf', 'label' => '[Liber] paese di origine'),
        'liber_carch'	 => array('key' => 'liber_carch', 'field' => 'd109_sa_26', 'type' => 'cdf', 'label' => '[Liber] codice d\'archivio'),
        'liber_reader'	 => array('key' => 'liber_reader', 'field' => 'd109_sa_27', 'type' => 'cdf', 'label' => '[Liber] Sigla lettore'),
        'liber_codtar'	 => array('key' => 'liber_codtar', 'field' => 'd109_sa_30', 'type' => 'cdf', 'label' => '[Liber] Codice tariffa'),
        'liber_orbib'	 => array('key' => 'liber_orbib', 'field' => 'd109_sa_32', 'type' => 'cdf', 'label' => '[Liber] Orientamento bibliografico'),
        'liber_outcat'	 => array('key' => 'liber_outcat', 'field' => 'd109_sa_35', 'type' => 'cdf', 'label' => '[Liber] Fuori catalogo'),
        'liber_genoth'	 => array('key' => 'liber_genoth', 'field' => 'd109_sa_36', 'type' => 'cdf', 'label' => '[Liber] Altri generi'),
		'music'			 => array('key' => 'music', 'field' => 'd125_sb_0', 'type' => 'cdf', 'label' => 'Registrazioni sonore e musica'),
		'videocolor'	 => array('key' => 'videocolor', 'field' => 'd115_sa_4', 'type' => 'cdf', 'label' => 'Video (colore)'),
		'videosound'	 => array('key' => 'videosound', 'field' => 'd115_sa_5', 'type' => 'cdf', 'label' => 'Video (sonoro)'),);

	private $_linkFields = array();
	private $_linkFieldsOverride = array('700' => array(700, 710, 720), '701' => array(701, 711), '702' => array(702, 712),);
	private $sortOptions = array('score' => 'rilevanza', 'titleasc' => 'titolo (crescente)', 'titledesc' => 'titolo (decrescente)', 'authasc' => 'autore (crescente)', 'authdesc' => 'autore (decrescente)', 'dateasc' => 'data (crescente)', 'datedesc' => 'data (decrescente)', 'classasc' => 'classe (crescente)', 'classdesc' => 'classe (decrescente)',);
	private $_query = '';


	public function onInit($param)
	{
		parent::onInit($param);
		$this->attachEventHandler('OnActualLibraryChanged', array($this, 'OnActualLibraryChanged'));
	}

	public function onLoad($param)
	{
		parent::onLoad($param);

		$this->_uniqueId = $this->getUniqueID();
		$this->_llibraryActive = LLibraryPeer::isEnabled();

		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallback())
		{
			$this->callPopulate();
		}

		if($this->getMultiSelect())
		{
			$this->ResultGrid->Columns[0]->Visible = TRUE;
		}
	}

	public function OnActualLibraryChanged($sender, $param)
	{
		$this->callPopulate();

		if ($this->getMultiSelect()) {
			$this->ResultGrid->Columns[0]->Visible = true;
		}
	}

	private function callPopulate()
	{
		$ck = $this->getRequest()->getCookies()->findCookieByName('AdvCatalogSearchOpen');
		if ($ck && $ck->getValue() == 'true')
			$this->toggleAdvancedSearch(null, null);

		$this->populateSerieSection();
		$libraries = LibraryPeer::getLibrariesHashWithBlank(null, true);
		$this->HomeLibraryFilter->setDatasource($libraries);
		$this->HomeLibraryFilter->dataBind();
		$this->ActualLibraryFilter->setDatasource($libraries);
		$this->ActualLibraryFilter->dataBind();
		$this->populateMaxDistance();
		$this->buildPrivateLists();

		$this->_query = $this->buildQuery();
		if ($this->_query == '') {
			$this->reset();
			// precompile ZeroItems
			$this->HideZeroItems->setChecked(ClavisParamQuery::getParam('CLAVISPARAM', 'HideZeroItem') == 'true');
		} else if ($this->_query != $this->getLastQuery()) {
			// new query
			$this->reset();
		}
		$this->populate();
		$this->getPage()->setFocus($this->Title);
	}

	public function setMultiSelect($value)
	{
		$this->setControlState('MultiSelect', $value, false);
	}

	public function getMultiSelect()
	{
		return $this->getControlState('MultiSelect', false);
	}

	private function buildPrivateLists()
	{
		$linktypes = LookupValuePeer::getLookupClassValues('LINKTYPE');
		foreach ($linktypes as $k => $v)
			$this->_linkFields[$k] = array($k);
		foreach ($this->_linkFieldsOverride as $k => $v)
			$this->_linkFields[$k] = $v;
	}

	public function populateSerieSection()
	{
		$lid = $this->getUser()->getActualLibraryId();
		$inv_series = InventorySerieQuery::create()->orderByClosed()->orderByReadonly()->orderByInventorySerieId()->findByLibraryId($lid);
		$ds = array(0 => '---');
		foreach ($inv_series as $i)
		{
			$ds[$i->getInventorySerieId()] = $i->getDescription() . ' (' . $i->getInventorySerieId() . ')';
		}
		$this->InventorySerieIdFilter->setDataSource($ds);
		$this->InventorySerieIdFilter->dataBind();
		$this->SectionFilter->setLibraryId($lid);
		$this->SectionFilter->populateList();
	}

	public function populateBibType($sender, $param)
	{
		if ($sender->getSelectedIndex() == 0)
		{
			$this->BibType->setDataSource(array());
			$this->BibType->dataBind();
			$this->BibType->setEnabled(false);
			$this->BibType->setSelectedIndex(0);
			return;
		}
		$firstValue = $sender->getSelectedValue();
		$this->BibType->setEnabled(true);
		$this->BibType->setDBClass('OGGBIBL_' . $firstValue);
		$this->BibType->populateList();
		$this->BibType->setSelectedIndex(0);
	}

	public function populateFilterList($sender, $param)
	{
		if ($sender->getSelectedIndex() == 0)
		{
			$sender->Parent->Filter->setDataSource(array());
			$sender->Parent->Filter->dataBind();
			$sender->Parent->Filter->setEnabled(false);
			$sender->Parent->Filter->setSelectedIndex(0);
			return;
		}
		$key = $sender->getSelectedValue();
		$ds = array();
		if ($this->_selectFields[$key]['type'] == 'special')
			switch ($key)
			{
				case 'language':
					$sql = 'SELECT DISTINCT ' . ManifestationPeer::EDITION_LANGUAGE . ' FROM ' . ManifestationPeer::TABLE_NAME;
					$conn = Propel::getConnection();
					$stmt = $conn->query($sql);
					$languages = $stmt->fetchAll(PDO::FETCH_COLUMN, 0);
					$languages = LookupValueQuery::create()->filterByValueLanguage($this->getApplication()->getGlobalization()->getCulture())->filterByValueClass('LANGUAGES')->filterByValueKey($languages, Criteria::IN)->orderByValueLabel()->find();
					foreach ($languages as $value)
					{
						$ds[$value->getValueKey()] = $value->getTrimmedValueLabel(20);
					}
					break;
			}
		else
			switch ($this->_selectFields[$key]['type'])
			{
				case 'cdf':
					list($fld, $sf, $pos) = explode('_', $this->_selectFields[$key]['field']);
					$options = UnimarcCodesQuery::create()->filterByFieldNumber(substr($fld, 1))->filterByLanguage($this->getApplication()->getGlobalization()->getCulture())->filterBySubfieldTag(substr($sf, 1))->filterByPos($pos)->find();
					foreach ($options as $opt)
					/* @var $opt UnimarcCodes */
						$ds[$opt->getCodeValue()] = $opt->getLabel();
					break;
				case 'map':
					$ds = LookupValuePeer::getLookupClassValues($this->_selectFields[$key]['map']);
					break;
			}
		$sender->Parent->Filter->setDataSource($ds);
		$sender->Parent->Filter->dataBind();
		$sender->Parent->Filter->setEnabled(true);
	}

	private function populateMaxDistance()
	{
		if ($this->_llibraryActive)
		{
			$this->MaxDistancePanel->setVisible(true);
			$this->MaxDistanceFilter->setDatasource(LLibraryPeer::calculateLLibraryDistanceHash());
			$this->MaxDistanceFilter->dataBind();
		}
		else
		{
			$this->MaxDistancePanel->setVisible(false);
		}
	}

	public function toggleAdvancedSearch($sender, $param)
	{
		if (strpos($this->AdvancedSearchPanel->getCssClass(), 'panel_off') !== false)
		{
			$this->AdvancedSearchPanel->setCssClass('panel_on');
			$this->ToggleAdvSearchButton->setText(Prado::localize('meno opzioni'));
			$ck = new THttpCookie('AdvCatalogSearchOpen', 'true');
			$this->getResponse()->getCookies()->add($ck);
		}
		else
		{
			$this->AdvancedSearchPanel->setCssClass('panel_off');
			$this->ToggleAdvSearchButton->setText(Prado::localize('più opzioni'));
			$ck = new THttpCookie('AdvCatalogSearchOpen', 'false');
			$this->getResponse()->getCookies()->add($ck);
		}
	}

	public function searchComposeDatabind($sender, $param)
	{
		$item = $param->Item;
		if ($item->ItemType === 'Item' || $item->ItemType === 'AlternatingItem')
		{
			if ($item->ItemIndex < 1)
				$item->Operator->setVisible(false);
			$item->Field->setDataSource($this->_searchFields);
			$item->Field->dataBind();
			$item->Operator->setSelectedValue($item->DataItem['Operator']);
			$item->Field->setSelectedValue($item->DataItem['Field']);
			$item->SearchValue->setText($item->DataItem['SearchValue']);
		}
	}

	public function onSearchComposeCommand($sender, $param)
	{
		$data = array();
		$curitem = $param->getItem();
		switch ($param->getCommandName())
		{
			case 'add':
				$newpart = array('Operator' => '', 'Field' => 'fldin_txt_title', 'SearchValue' => '');
				$items = $this->SearchCompose->getItems();
				foreach ($items as $item)
				{
					$data[] = array('Operator' => $item->Operator->getSelectedValue(), 'Field' => $item->Field->getSelectedValue(), 'SearchValue' => $item->SearchValue->getText());
					if ($item == $curitem)
						$data[] = $newpart;
				}
				break;
			case 'del':
				$items = $this->SearchCompose->getItems();
				foreach ($items as $item)
				{
					if ($item != $curitem)
						$data[] = array('Operator' => $item->Operator->getSelectedValue(), 'Field' => $item->Field->getSelectedValue(), 'SearchValue' => $item->SearchValue->getText());
				}
				// always ensure we have at least one entry
				while (count($data) < 3)
					$data[] = array('Operator' => '', 'Field' => '', 'SearchValue' => '');
				break;
			default:
				break;
		}
		$this->SearchCompose->setDataSource($data);
		$this->SearchCompose->dataBind();
	}

	public function searchFilterDatabind($sender, $param)
	{
		$item = $param->Item;
		if ($item->ItemType === 'Item' || $item->ItemType === 'AlternatingItem')
		{
			$item->Field->setDataSource($this->_selectFields);
			$item->Field->dataBind();
			if ($item->DataItem['Field'])
			{
				$item->Field->setSelectedValue($item->DataItem['Field']);
				$this->populateFilterList($item->Field, null);
				$item->Filter->setSelectedValue($item->DataItem['Filter']);
			}
		}
	}

	public function onSearchFilterCommand($sender, $param)
	{
		$data = array();
		$curitem = $param->getItem();
		switch ($param->getCommandName())
		{
			case 'add':
				$newpart = array('Field' => '', 'Filter' => '');
				$items = $this->SearchFilter->getItems();
				foreach ($items as $item)
				{
					$data[] = array('Field' => $item->Field->getSelectedValue(), 'Filter' => $item->Filter->getSelectedValue());
					if ($item == $curitem)
						$data[] = $newpart;
				}
				break;
			case 'del':
				$items = $this->SearchFilter->getItems();
				foreach ($items as $item)
				{
					if ($item != $curitem)
						$data[] = array('Field' => $item->Field->getSelectedValue(), 'Filter' => $item->Filter->getSelectedValue());
				}
				// always ensure we have at least 3 entries
				while (count($data) < 2)
					$data[] = array('Field' => 0, 'Filter' => '');
				break;
			default:
				break;
		}
		$this->SearchFilter->setDataSource($data);
		$this->SearchFilter->dataBind();
	}

	public function searchAuthDatabind($sender, $param)
	{
		$item = $param->Item;
		if ($item->ItemType === 'Item' || $item->ItemType === 'AlternatingItem')
		{
			$item->AuthLink->populate();
			$item->AuthLink->setSelectedValue($item->DataItem['AuthLink']);
			$item->AuthorityText->setText($item->DataItem['AuthText']);

			$item->AuthRelCode->populate();
			$item->AuthRelCode->setSelectedValue($item->DataItem['AuthRelCode']);
		}
	}

	public function onSuggestAuthority($sender, $param)
	{
		$prefix = $param->getToken();
		$authList = AuthorityPeer::doSuggest($prefix, 10);
		$authData = array();
		foreach ($authList as $auth)
		{
			$authData[] = array(
				'id'	 => $auth->getAuthorityId(),
				'text'	 => $auth->getFullTextSpec());
		}
		$sender->setDataSource($authData);
		$sender->dataBind();
	}

	public function onSuggestAuthorityCallback($sender, $param)
	{
		$id = $sender->Suggestions->DataKeys[$param->selectedIndex];
		$authorityUp = AuthorityPeer::retrieveByPK($id);
		$authorityUp = $authorityUp->getAcceptedAuthority();
		foreach ($this->SearchAuth->getItems() as $item)
		{
			if ($item->AuthorityText->getUniqueID() == $sender->getUniqueID())
			{
				if ($authorityUp instanceof Authority)
				{
					$item->AuthorityID->setValue($authorityUp->getAuthorityId());
					$item->AuthorityText->setText($authorityUp->getFullText());
				}
				else
				{
					$item->AuthorityID->setValue(null);
					$item->AuthorityText->setText('');
				}
			}
		}
	}

	public function onSearchAuthCommand($sender, $param)
	{
		$data = array();
		$curitem = $param->getItem();
		switch ($param->getCommandName())
		{
			case 'add':
				$newpart = array('AuthRelCode' => '', 'AuthLink' => '700', 'AuthText' => '', 'AuthId' => '');
				$items = $this->SearchAuth->getItems();
				foreach ($items as $item)
				{
					$data[] = array('AuthRelCode' => $item->AuthRelCode->getSelectedValue(), 'AuthLink' => $item->AuthLink->getSelectedValue(), 'AuthText' => $item->AuthorityText->getText(), 'AuthId' => $item->AuthorityID->getValue());
					if ($item == $curitem)
						$data[] = $newpart;
				}
				break;
			case 'del':
				$items = $this->SearchAuth->getItems();
				foreach ($items as $item)
				{
					if ($item != $curitem)
						$data[] = array('AuthRelCode' => $item->AuthRelCode->getSelectedValue(), 'AuthLink' => $item->AuthLink->getSelectedValue(), 'AuthText' => $item->AuthorityText->getText(), 'AuthId' => $item->AuthorityID->getValue());
				}
				// always ensure we have at least one entry
				while (count($data) < 1)
					$data[] = array('AuthRelCode' => '', 'AuthLink' => '700', 'AuthText' => '', 'AuthId' => '');
				break;
			default:
				break;
		}
		$this->SearchAuth->setDataSource($data);
		$this->SearchAuth->dataBind();
	}

	public function reset()
	{
		$this->resetChecked();
		$this->resetLastQuery();
		$this->updateSelectionPanel();
	}

	public function cleanSearch($sender, $param)
	{
		$this->resetChecked();
		$this->resetLastQuery();
		$this->getResponse()->redirect($this->getService()->constructUrl($this->getPage()->getPagePath()));
	}

	public function reloadSearch()
	{
		if ($this->getMultiSelect())
			$params['param'] = 'multiSelect';
		$params['start'] = $this->ResultGrid->getCurrentPageIndex() * $this->ResultGrid->getPageSize();
		//$params['rows'] = $this->ResultGrid->getPageSize();
		$params['sort'] = $this->getViewState('Sorting', 'score');
		$url = $this->getService()->constructUrl($this->getPage()->getPagePath(), $params);

		////$this->getPage()->reloadPage();///////////////////

		$goto = $url . '&' . implode('&', $this->buildQueryParams());
		$this->getResponse()->redirect($goto);
	}

	public function doSearch($sender, $param)
	{
		$this->ResultGrid->setCurrentPageIndex(0);
		$this->reloadSearch();
	}

	public function onChangePage($sender, $param)
	{
		$this->ResultGrid->setCurrentPageIndex($param->NewPageIndex);
		$this->reloadSearch();   ///// da investigare
	}

	public function onChangePageSize($sender, $param)
	{
		$start = $this->ResultGrid->getCurrentPageIndex() * $this->ResultGrid->getPageSize();
		if (($newPageSize = intval($sender->getSelectedValue())) > 0)
		{
			$this->ResultGrid->setPageSize($newPageSize);
			$ck = new THttpCookie('CatalogSearchPageSize', $newPageSize);
			$this->getResponse()->getCookies()->add($ck);
			$this->ResultGrid->setCurrentPageIndex(floor($start / $newPageSize));
			$this->reloadSearch();
		}
	}

	public function onChangeSorting($sender, $param)
	{
		$selected = $sender->getSelectedValue();
		$this->setViewState('Sorting', $selected);

		$this->getApplication()->getSession()->add('ClavisCatalogSearchDefaultSort', $selected);

		$this->reloadSearch();
	}

	public function onSelectMyLibrary($sender, $param)
	{
		$newLibrary = $this->getUser()->getActualLibraryId();
		if ($newLibrary >= 0)
		{
			$this->HomeLibraryFilter->setSelectedValue($newLibrary);
			$this->HomeLibraryFilter->dataBind();
		}
	}

	public function onSelectAllLibrary($sender, $param)
	{
		$newLibrary = 0;
		$this->HomeLibraryFilter->setSelectedValue($newLibrary);
		$this->HomeLibraryFilter->dataBind();
	}

	public function populate()
	{
		///////// commented by mbrancalion, vediamo ...  $this->getMasterCheck();
		// set from GET
		$req = $this->getRequest();

		$sort = $this->getApplication()->getSession()->itemAt('ClavisCatalogSearchDefaultSort');
		if (!$sort)
			$sort = $req->itemAt('sort');
		if (!$sort)
			$sort = '';

		$start = $req->itemAt('start');
		if (!$start)
			$start = 0;

		$rows = $req->itemAt('rows');
		if (!$rows)
			$rows = 10;

		if (array_key_exists('CatalogSearchPageSize', $_COOKIE))
			$rows = intval($_COOKIE['CatalogSearchPageSize']);

		$this->ResultGrid->setPageSize($rows);
		$ck = new THttpCookie('CatalogSearchPageSize', $rows);
		$this->getResponse()->getCookies()->add($ck);
		$currentPage = floor($start / $rows);

		if (!$this->_query)
			$this->_query = $this->getLastQuery();
		$this->ResultGrid->setCurrentPageIndex($currentPage);
		$this->ResultGrid->setPageSize($rows);
		$this->setViewState('Sorting', $sort);

		/* preload lookups for biblevel */
		$lookup_bl = LookupValuePeer::getLookupClassValues('LIVBIBL');
		$search = $this->getApplication()->getModule('search');
		/* @var $loanManager ClavisLoanManager */
		$loanManager = $this->getApplication()->getModule('loan');
		$response = false;
		try
		{
			$response = ($this->_query) ? $search->search($this->_query, $start, $rows, $sort) : null;
			if ($response && $response['response']['numFound'] > 0)
			{
				$this->updateLastQuery($this->_query, $response['response']['numFound']);

				$this->ResultNumLabel->Parameters->results = $response['response']['numFound'];
				$this->ResultNumLabel->setVisible(true);
			}
			else
			{
				$this->ResultNumLabel->setVisible(false);
			}
		}
		catch (Exception $e)
		{

		}
		// search extraserver
		try
		{
			$extra = ($this->_query) ? $search->searchExtra($this->_query) : null;
			if ($extra && $extra['response']['numFound'] > 0)
			{
				$this->ExtraFoundPanel->setVisible(true);
				if ($this->getPage()->isPopup())
				{
					$this->ExtraFoundNote->setText(Prado::localize('<em>(trovate altre {count} notizie in sistemi esterni, ' . 'usa la pagina <strong>Ricerca Catalogo</strong> per visualizzarle)</em>', array('count' => $extra['response']['numFound'])));
				}
				else
				{
					$this->ExtraFoundLink->setText(Prado::localize('(trovate altre {count} notizie in sistemi esterni)', array('count' => $extra['response']['numFound'])));
					$this->ExtraFoundLink->setNavigateUrl($this->getService()->constructUrl('Catalog.ExtraSearch', array('query' => $this->_query)));
				}
			}
			else
			{
				$this->ExtraFoundPanel->setVisible(false);
			}
		}
		catch (Exception $e)
		{
			$this->ExtraFoundPanel->setVisible(false);
		}
		if ($response)
		{
			$ds = array();
			foreach ($response['response']['docs'] as $key => $result)
			{
				$m = ManifestationQuery::create()->findPk($result['Id']);
				if (!$m instanceof Manifestation)
				{
					// manifestation is non-existent, try to deindex it and log.
					Prado::log("Found non-existing manifestation [{$result['Id']}], " . "will try to deindex and remove any cache.");
					$search->deIndex($result['Id']);
					ChangelogPeer::logAction('Manifestation', ChangelogPeer::LOG_WARNING, $this->getUser(), 'Deindexing non-existent manifestation', $result['Id']);
					continue;
				}
				$tm = TurboMarc::createRecord($result['turbo_marc']);
				$result['BibLevelCode'] = $m->getBibLevel();
				$result['BibLevelLabel'] = (array_key_exists($result['BibLevelCode'], $lookup_bl)) ? $lookup_bl[$result['BibLevelCode']] : '---';
				$result['BibTypeCode'] = strtolower($m->getBibType());
				$result['BibTypeLabel'] = $m->getBibTypeLabel();
				if (($year = $m->getEditionDate()) === 0) $year = '';

				$result['Year'] = $year;
				$result['Publisher'] = $m->getPublisher();
				$prefix = ('0' == $tm->d200['i1'] && isset($tm->d461)) ? preg_replace('!\s+!', ' ', $tm->d461->st) . '. ' : '';
				$result['Title'] = $prefix . trim($tm->getFullTitle());
				$result['Author'] = trim($tm->getAuthor());
				$result['EAN'] = trim($tm->getEAN());
				$result['Editions'] = implode(' - ', $tm->getEditions());
				$result['Publications'] = implode(' - ', $tm->getPublications());
				$result['Series'] = implode(' - ', $tm->getSeries());
				$result['PhysicalDescription'] = implode(' - ', $tm->getPhysicalDescs());

				$sj = explode('-',$tm->d461->sj); // tokenize string with - as delimiter
				$last_sj = array_pop($sj); // remove if present the issue type part (normale, con supplemento, supplemento)
				$sj_string = count($sj) === 0 ? $last_sj :  implode("", $sj); //get the issue year/volume indication only

				$part_of = trim(isset($tm->d461) ? "{$tm->d461->st} - {$sj_string}" : '', '- ');
				$part_of .= (isset($tm->d461) && isset($tm->d461->sv) ? " ; {$tm->d461->sv}" : '');
				$result['PartOf'] = $part_of;

				$itemStats = $loanManager->extractItemStats($m);
				$result['Items'] = $itemStats['Items'];
				$result['ItemsDetail'] = $itemStats['ItemsDetail'];
				$result['AvailItems'] = $itemStats['AvailItems'];
				$result['AvailDetail'] = $itemStats['AvailDetail'];
				$result['MyCollocation'] = $itemStats['MyColl'];
				$ds[] = $result;
			}
			$this->ResultGrid->setVirtualItemCount($response['response']['numFound']);
			$this->ResultGrid->setDataSource($ds);
			$this->ResultGrid->dataBind();
		} else if ($this->_query)
		{
			$this->SearchUnavailable->setVisible(true);
			$this->ResultNumLabel->setVisible(false);
			$this->ResultGrid->setVisible(false);
			$this->dataBind();
		}

		$this->QueryString->Parameters->query = htmlentities($this->_query);
		$this->updateSelectionPanel();
	}

	public function completePager($sender, $param)
	{
		$pager = $param->Pager->getControls();

		$label = new TActiveLabel();
		$label->setID('PageRowsLabel');
		$label->setText(Prado::localize('num.righe') . ' ');
		$label->setCssClass("viewlabel4small");
		$pager->insertAt(0, $label);

		$pageSizeSelect = new TActiveDropDownList();
		$pageSizeSelect->setID('PageRows');
		$pageSizeSelect->setAutoPostBack(true);
		foreach (array(10, 20, 50, 100) as $value)
		{
			$element = new TListItem();
			$element->setValue($value);
			$element->setText($value);
			$pageSizeSelect->getItems()->add($element);
		}
		$pageSize = $this->ResultGrid->getPageSize();
		if ($pageSize > 0)
			$pageSizeSelect->setSelectedValue($pageSize);
		$pager->insertAt(1, $pageSizeSelect);
		$pageSizeSelect->attachEventHandler('OnSelectedIndexChanged', array($this, 'onChangePageSize'));
		$pager->insertAt(2, ' | ');

		$label = new TActiveLabel();
		$label->setID('SearchSortLabel');
		$label->setText(Prado::localize('ordina per') . ' ');
		$pager->insertAt(3, $label);

		$sortSelect = new TActiveDropDownList();
		$sortSelect->setID('SearchSort');
		$sortSelect->setAutoPostBack(true);
		foreach ($this->sortOptions as $value => $label)
		{
			$element = new TListItem();
			$element->setText(Prado::localize($label));
			$element->setValue($value);
			$sortSelect->getItems()->add($element);
		}

		$pager->insertAt(4, $sortSelect);

		$selectedSortValue = $this->getViewState('Sorting');
		if (($selectedSortValue != null) || ($selectedSortValue != ""))
			$sortSelect->setSelectedValue($selectedSortValue);
		else
			$sortSelect->setSelectedIndex(0);

		$sortSelect->attachEventHandler('OnSelectedIndexChanged', array($this, 'onChangeSorting'));

		$pager->insertAt(5, ' | ');
		$pager->add(' / ' . $this->ResultGrid->getPageCount());
	}

	public function buildQueryParams()
	{
		$id = intval($this->IdFilter->getSafeText());
		if ($id)
			return array("simpleid={$id}");
		$bid = $this->BidFilter->getSafeText();
		if ($bid)
			return array("simplebid={$bid}");

		$params = $item = array();
		$daterange = array('*', '*');

		if ($v = urlencode(trim($this->Title->getText())))
		{
			if ($this->TitleSearchMode->getSelectedValue() == 'start')
				$v = "^{$v}";
			$params[] = "simpletitle={$v}";
		}
		if ($v = urlencode(trim($this->FullText->getText())))
			$params[] = "simpleft={$v}";

        if ($v = urlencode($this->DataClass->getSelectedValue())) {
            $params[] = "dataclass={$v}";
        }

		if ($v = urlencode(trim($this->Numbers->getText())))
			$params[] = 'ean=' . Clavis::normalizeStdNum($v);
		if ($v = trim($this->HomeLibraryFilter->getSelectedValue()))
			$item[] = "\$sa {$v}";
		$v = intval($this->MaxDistanceFilter->getSelectedValue());
		if ($this->_llibraryActive && $v >= 0)
			$params[] = "llibdst={$v}";

		foreach ($this->SearchCompose->getItems() as $i)
		{
			$fld = $i->Field->getSelectedValue();
			if (!array_key_exists($fld, $this->_searchFields))
				continue;
			// replace & in search
			$v = urlencode(trim($i->SearchValue->getText()));
			if ($v == '')
				continue;
			$op = $i->Operator->getSelectedValue();
			$params[] = "{$fld}={$op}|{$v}";
		}
		if ($v = intval(trim($this->YearFromFilter->getText())))
			$params[] = "yf={$v}";
		if ($v = intval(trim($this->YearToFilter->getText())))
			$params[] = "yt={$v}";
		if ($v = $this->LoanableSinceFrom->getTimestamp())
			$params[] = "lsf={$v}";
		if ($v = $this->LoanableSinceTo->getTimestamp())
			$params[] = "lst={$v}";
		if ($v = trim($this->BibTypeFirst->getSelectedValue()))
			$params[] = "btf={$v}";
		if ($v = trim($this->BibType->getSelectedValue()))
			$params[] = "bt={$v}";
		$params[] = "hzi=" . ($this->HideZeroItems->getChecked() ? '1' : '0');

		foreach ($this->SearchFilter->getItems() as $i)
		{
			$fld = $i->Field->getSelectedValue();
			if (!array_key_exists($fld, $this->_selectFields))
				continue;
			if ($i->Filter->getSelectedIndex() < 0)
				continue;
			$v = trim($i->Filter->getSelectedValue());
			$params[] = "{$fld}={$v}";
		}

		$bibLevelFilter = $this->BibLevelFilter->getSelectedValue();
		if($bibLevelFilter != '0')
		{
			$params[] = "biblevel={$bibLevelFilter}";
		}

		foreach ($this->SearchAuth->getItems() as $i)
		{
			$fld = $i->AuthLink->getSelectedValue();
			$id = intval(trim($i->AuthorityID->getValue()));
			$rcode = $i->AuthRelCode->getSelectedValue();

			if (!$id)
				continue;
			$params[] = "{$fld}={$id}_{$rcode}";
		}

		// ITEM FILTER
		$field = 'sf_d950';
		if ($v = trim($this->Barcode->getText()))
			$item[] = "\$sr $v";
		if ($v = trim($this->InventorySerieIdFilter->getSelectedValue()))
			$item[] = "\$sb $v";
		if ($v = trim($this->InventoryFilter->getText()))
			$item[] = "\$sc $v";
		if ($v = trim($this->SectionFilter->getSelectedValue()))
			$item[] = "\$sd $v";
		if ($v = trim($this->CollocationFilter->getText()))
			$item[] = "\$sf $v";
		if ($v = trim($this->ItemMediaTypeFilter->getSelectedValue()))
			$item[] = "\$ss $v";
		if ($v = trim($this->LoanClassFilter->getSelectedValue()))
			$item[] = "\$sp $v";
		if ($v = trim($this->ItemStatusFilter->getSelectedValue()))
		{
			$item[] = "\$sj $v";
			if (!in_array($v, ItemStatus::getItemStatusVisible()))
				$field = 'sf_d951';
		}
		if ($v = trim($this->IssueStatusFilter->getSelectedValue()))
			$item[] = "\$sx $v";
		if ($v = trim($this->ItemSourceFilter->getSelectedValue()))
			$item[] = "\$su $v";
		if ($v = trim($this->ActualLibraryFilter->getSelectedValue()))
			$item[] = "\$sn $v";

		if ($item)
		{
			$params[] = (count($item) > 1) ? ($field . '="' . implode(' ', $item) . '"~100 AND "' . implode('" AND "', $item) . '"') : ("{$field}=\"{$item[0]}\"");
		}
		return $params;
	}

	public function buildQuery()
	{
		$searchCompose = $searchFilter = $searchAuths = $queryComponents = array();
		$cdf = $item = array();
		$q = '';
		$daterange = $loansince = array('*', '*');
		$bibtype = array(null, null);

		$queryString = $this->getRequest()->getQueryString();
		$pairs = explode('&', $queryString);

		foreach ($pairs as $pair)
		{
			$op = null;
			if (strpos($pair, '=') === false)
				continue;
			list($k, $v) = array_map('urldecode', explode('=', $pair));
			if (strpos($v, '|') !== false)
				list($op, $v) = explode('|', $v, 2);
			$op = ($op) ? ' ' . strtoupper($op) . ' ' : ' AND ';

			switch ($k)
			{
				case 'llibdst':
					$llib = LLibraryQuery::create()->filterByFromLibraryId($this->getUser()->getActualLibraryId());
					$totlibs = $llib->count();
					$dstlibs = $llib->filterByDistance(intval($v), Criteria::LESS_EQUAL)->select('ToLibraryId')->find()->toArray();
					if (count($dstlibs) < 1)
					{
						$this->getPage()->writeMessage(Prado::localize('Non esistono biblioteche a distanza {libdst}.', array('libdst' => intval($v))), ClavisMessage::WARNING);
					}
					else if (count($dstlibs) != $totlibs)
					{
						$q .= $op . '(mrc_d950_sa:' . implode(' OR mrc_d950_sa:', $dstlibs) . ') ';
					}
					$this->MaxDistanceFilter->setText($v);
					break;
				case 'sf_d950':
				case 'sf_d951':
					// item
					$q .= "{$op}{$k}:({$v})";
					$items = explode(' AND ', trim($v));
					if (count($items) > 1)
						array_shift($items);
					foreach ($items as $item)
					{
						list($sfld, $value) = explode(' ', trim($item, '"$'), 2);
						switch ($sfld)
						{
							case 'sr':
								$this->Barcode->setText($value);
								break;
							case 'sb':
								$this->InventorySerieIdFilter->setSelectedValue($value);
								break;
							case 'sc':
								$this->InventoryFilter->setText($value);
								break;
							case 'sd':
								$this->SectionFilter->setSelectedValue($value);
								$q .= ' AND fldis_str_section:(' . str_replace(' ', '\\ ', $value) . '*)';
								break;
							case 'sf':
								$this->CollocationFilter->setText($value);
								$q .= ' AND fldis_str_collocation:(' . str_replace(' ', '\\ ', $value) . '*)';
								break;
							case 'ss':
								$this->ItemMediaTypeFilter->setSelectedValue($value);
								break;
							case 'sp':
								$this->LoanClassFilter->setSelectedValue($value);
								break;
							case 'sj':
								$this->ItemStatusFilter->setSelectedValue($value);
								break;
							case 'sx':
								$this->IssueStatusFilter->setSelectedValue($value);
								break;
							case 'su':
								$this->ItemSourceFilter->setSelectedValue($value);
								break;
							case 'sn':
								$this->ActualLibraryFilter->setSelectedValue($value);
								break;
							case 'sa':
								$this->HomeLibraryFilter->setSelectedValue($value);
								break;
						}
					}
					break;
				case 'hzi':
					if (1 == $v)
					{
						$this->HideZeroItems->setChecked(true);
						$q .= ' AND mrc_d950_sj:[* TO *]';
					}
					else
					{
						$this->HideZeroItems->setChecked(false);
					}
					break;
				case 'simpleid':
					$this->IdFilter->setText($v);
					$q .= "{$op}(id:{$v})";
					break;
				case 'simplebid':
					$this->BidFilter->setText($v);
					$q .= "{$op}(fldin_str_bid:{$v})";
					break;
				case 'simpletitle':
					// title field
					// validate " char, it has to be even
					if (substr_count($v, '"') % 2 == 1)
						$v .= '"';
					if (substr($v, 0, 1) == '^')
					{
						$v = substr($v, 1);
						$q .= $op . '(sorts_title:["' . mb_strtoupper($this->escapeLucene($v), 'UTF-8') . '" TO "' . mb_strtoupper($this->escapeLucene($v), 'UTF-8') . '􀃿"])'; // U+1000FF
						$this->TitleSearchMode->setSelectedValue('start');
						$this->Title->setText($v);
					}
					else
					{
						$q .= "{$op}(fldin_txt_title:({$this->escapeLucene($v)}))";
						$this->Title->setText($v);
					}
					break;
				case 'simpleft':
					// validate " char, it has to be even
					if (substr_count($v, '"') % 2 == 1)
						$v .= '"';
					$q .= "{$op}(fulltext:({$this->escapeLucene($v)}))";
					$this->FullText->setText($v);
					break;
                case 'dataclass':
                    if($v == " ")
                        $q .= "{$op} -mrc_l_9:[* TO *]";
                    else
                        $q .= "{$op}(mrc_l_9:({$this->escapeLucene($v)}))";

                    $this->DataClass->setSelectedValue($v);
                    break;
				case 'ean':
					$q .= "{$op}(fldin_txt_numbers:({$this->escapeLucene($v)}))";
					$this->Numbers->setText($v);
					break;
				case 'btf':
					$bibtype[0] = $v;
					break;
				case 'bt':
					$bibtype[1] = $v;
					break;
				case 'yf':
					$daterange[0] = $v;
					$this->YearFromFilter->setText($v);
					break;
				case 'yt':
					$daterange[1] = $v;
					$this->YearToFilter->setText($v);
					break;
				case 'lsf':
					$loansince[0] = date('Y-m-d+00\:00\:00', $v);
					$this->LoanableSinceFrom->setTimestamp($v);
					break;
				case 'lst':
					$loansince[1] = date('Y-m-d+00\:00\:00', $v);
					$this->LoanableSinceTo->setTimestamp($v);
					break;
				case 'biblevel':
					$this->BibLevelFilter->setSelectedValue($v);
					$q .= "{$op}(mrc_l_7:({$this->escapeLucene($v)}))";
					break;
				default:
					if (array_key_exists($k, $this->_searchFields))
					{
						// compose
						$srchval = (array_key_exists('phrase', $this->_searchFields[$k]) && $this->_searchFields[$k]['phrase']) ? '"' . addslashes($v) . '"' : "({$this->escapeLucene($v)})";

						if (is_array($this->_searchFields[$k]['field']))
						{
							$subquery = array();
							foreach ($this->_searchFields[$k]['field'] as $searchFld)
								$subquery[] = "{$searchFld}:$srchval";
							$queryComponents[] = "{$op}(" . implode(' OR ', $subquery) . ')';
						}
						else
						{
							$queryComponents[] = "{$op}{$this->_searchFields[$k]['field']}:{$srchval}";
						}

						$searchCompose[] = array('Operator' => trim(strtolower($op)), 'Field' => $k, 'SearchValue' => $v);
					}
					else if (array_key_exists($k, $this->_selectFields))
					{
						// select
						if ($this->_selectFields[$k]['type'] == 'cdf')
						{
							$cdf[] = $this->_selectFields[$k]['field'] . "_{$v}";
						}
						else if (is_array($this->_selectFields[$k]['field']))
						{
							$queryComponents[] = ' AND (' . implode(":({$v}) OR ", $this->_selectFields[$k]['field']) . ":({$v}))";
						}
						else
						{
							$queryComponents[] = " AND {$this->_selectFields[$k]['field']}:({$v})";
						}
						$searchFilter[] = array('Field' => $k, 'Filter' => $v);
					}
					else if (array_key_exists($k, $this->_linkFields))
					{
						// auth link
						list($aid, $relc) = explode("_", $v);
						$a = AuthorityQuery::create()->findOneByAuthorityId($aid);
						if ($a instanceof Authority)
						{
							$subquery = array();
							if ($relc == "0")
								foreach ($this->_linkFields[$k] as $searchFld)
									$subquery[] = "mrc_d{$searchFld}_s3:({$this->escapeLucene($aid)})";
							else
								$subquery[] = "mrc_raut{$relc}:(\"{$this->escapeLucene($a->getFullText())}\")";

							$queryComponents[] = " AND (" . implode(' OR ', $subquery) . ')';
							$searchAuths[] = array('AuthRelCode' => $relc, 'AuthLink' => $k, 'AuthText' => $a->getFullText(), 'AuthId' => $a->getAuthorityId());
						}
					}
					break;
			}
		}
		$compCnt = count($queryComponents);
		if ($compCnt)
		{
			$ftoken = trim(array_shift($queryComponents));
			if (substr($ftoken, 0, 4) == 'AND ')
				$ftoken = substr($ftoken, 4);
			else if (substr($ftoken, 0, 3) == 'OR ')
				$ftoken = substr($ftoken, 3);
			else if (substr($q, 0, 4) == 'NOT ')
				$ftoken = substr($ftoken, 4);
			$q .= ' +' . str_repeat('(', $compCnt) . $ftoken . ')' . (count($queryComponents) ? implode(')', $queryComponents) . ')' : '');
		}
		if ($bibtype[0])
		{
			$this->BibTypeFirst->setSelectedValue($bibtype[0]);
			$this->populateBibType($this->BibTypeFirst, null);
			if ($bibtype[1])
			{
				$this->BibType->setSelectedValue($bibtype[1]);
				$q .= " AND (mrc_d901_sa:({$bibtype[1]}))";
			}
			else
			{
				$q .= " AND (mrc_d901_sc:({$bibtype[0]}))";
			}
		}
		if ($daterange[0] != '*' || $daterange[1] != '*')
			$q .= " AND fldin_str_date:[{$daterange[0]} TO {$daterange[1]}]";
		if ($loansince[0] != '*' || $loansince[1] != '*')
			$q .= " AND sorts_loansince:[{$loansince[0]} TO {$loansince[1]}]";
		if ($cdf)
			$q .= ' AND mrc_cdf:(' . implode(' AND ', $cdf) . ')';

		$q = trim($q);
		if (substr($q, 0, 4) == 'AND ')
			$q = substr($q, 4);
		else if (substr($q, 0, 3) == 'OR ')
			$q = substr($q, 3);
		else if (substr($q, 0, 4) == 'NOT ')
			$q = substr($q, 4);

		while (count($searchCompose) < 3)
			$searchCompose[] = array('Operator' => 'and', 'Field' => '', 'SearchValue' => '');
		$this->SearchCompose->setDataSource($searchCompose);
		$this->SearchCompose->dataBind();

		while (count($searchFilter) < 2)
			$searchFilter[] = array('Field' => 0, 'Filter' => '');
		$this->SearchFilter->setDataSource($searchFilter);
		$this->SearchFilter->dataBind();

		while (count($searchAuths) < 1)
			$searchAuths[] = array('AuthRelCode' => '', 'AuthLink' => '700', 'AuthText' => '', 'AuthId' => '');
		$this->SearchAuth->setDataSource($searchAuths);
		$this->SearchAuth->dataBind();

		$this->SearchPanel->dataBind();
		return trim($q);
	}

	public function onMultiAuthSelect($sender, $param)
	{
		$items = $this->SearchCompose->getItems();
		foreach ($items as $item)
		{
			if ($item->SearchValue->getText() == 'multi')
			{
				$auths = AuthorityQuery::create()->findByAuthorityId(unserialize($item->SearchAuthId->getValue()));
				$op = $item->Operator->getSelectedValue();
				$field = $item->Field->getSelectedValue();
				foreach ($auths as $auth)
					$data[] = array('Operator' => $op, 'Field' => $field, 'SearchValue' => '"' . $auth->getFullText() . '"');
			}
			else if ($item->Field->getSelectedValue() == 'class')
			{
				$data[] = array('Operator' => $item->Operator->getSelectedValue(), 'Field' => $item->Field->getSelectedValue(), 'SearchValue' => array_shift(explode(' ', $item->SearchValue->getText())));
			}
			else
			{
				$data[] = array('Operator'		 => $item->Operator->getSelectedValue(), 'Field'			 => $item->Field->getSelectedValue(), 'SearchValue'	 => intval($item->SearchAuthId->getValue() > 0) ? '"' . $item->SearchValue->getText() . '"' : $item->SearchValue->getText());
			}
		}
		$this->SearchCompose->setDataSource($data);
		$this->SearchCompose->dataBind();
	}

	/** @return string */
	public function getLastQuery()
	{
		return strval($this->getApplication()->getSession()->itemAt('LastQuery' . $this->_uniqueId));
	}

	/** @return int */
	public function getLastResultCount()
	{
		return intval($this->getApplication()->getSession()->itemAt('LastResultCount' . $this->_uniqueId));
	}

	public function updateLastQuery($query, $resultCount)
	{
		$this->getApplication()->getSession()->add('LastQuery' . $this->_uniqueId, $query);
		$this->getApplication()->getSession()->add('LastResultCount' . $this->_uniqueId, $resultCount);
	}

	public function resetLastQuery()
	{
		$this->getApplication()->getSession()->remove('LastQuery' . $this->_uniqueId);
		$this->getApplication()->getSession()->remove('LastResultCount' . $this->_uniqueId);
	}

	public function updateSelectionPanel($param = null)
	{
		if(!$this->getMultiSelect())
		{
			$this->SelectionPanel->setVisible(false);
			return;
		}
		$checkCount = $this->countCheckedIds();
		$results = $this->getLastResultCount();
		if ($results < 1)
		{
			$this->SelectionPanel->setVisible(false);
		}
		else
		{
			switch ($checkCount)
			{
				case '0':
					$this->SelectedNumber->setText(Prado::localize('nessuna selezione'));
					break;
				case '1':
					$this->SelectedNumber->setText(Prado::localize('1 selezionato:'));
					break;
				default:
					$this->SelectedNumber->setText(Prado::localize('{count} selezionati:', array('count' => $checkCount)));
					break;
			}
			$this->AddToShelfLink->setVisible(!$this->getPage()->IsPopup() && $checkCount > 0);
			$this->MultiSelectButton->setVisible($this->getPage()->IsPopup() && $checkCount > 0);
			$this->SelectionPanel->setVisible(true);
		}
		if (!is_null($param))
		{
			$this->SelectionPanel->render($param->getNewWriter());
		}
	}

	public function saveChecked($checked)
	{
		$this->getApplication()->getSession()->add('Checks' . $this->_uniqueId, $checked);
	}

	public function resetChecked($state = false)
	{
		if ($state === true)
			$this->saveChecked(array('MasterCheck'));
		else
			$this->saveChecked(array());
	}

	public function getChecked()
	{
		$checked = $this->getApplication()->getSession()->itemAt('Checks' . $this->_uniqueId);

		if (!is_array($checked))
			$checked = array();

		return $checked;
	}

	public function getIsChecked($id)
	{
		$checked = $this->getChecked();
		$masterCheck = $this->getMasterCheck($checked);

		return (!$masterCheck && in_array($id, $checked) || $masterCheck && !in_array($id, $checked));
	}

	public function getMasterCheck($checked = array())
	{
		if (!is_array($checked) || is_null($checked))
			$checked = $this->getChecked();

		if (array_search('MasterCheck', $checked) !== false)
			$this->_masterCheck = true;
		else
			$this->_masterCheck = false;

		return $this->_masterCheck;
	}

	public function onMasterCheck($sender, $param)
	{
		$newStatus = $sender->getChecked();
		$this->resetChecked($newStatus);

		foreach ($this->ResultGrid->getItems() as $item)
			$item->CheckColumn->CheckedBox->setChecked($newStatus);

		$this->updateSelectionPanel($param);
	}

	public function onItemCheck($sender, $param)
	{
		$checked = $this->getChecked();
		$masterCheck = $this->getMasterCheck($checked);
		$id = $sender->getCustomData();
		$newStatus = $sender->getChecked();

		if ($masterCheck)
			$newStatus = !$newStatus;

		$k = array_search($id, $checked);

		if (($k === false) && $newStatus)
			$checked[] = $id;

		if (($k !== false) && !$newStatus && array_key_exists($k, $checked))
			unset($checked[$k]);

		$checked = array_flip(array_flip($checked)); // it's like array_unique, nothing more ......  (mbrancalion)
		$this->saveChecked($checked);
		$this->updateSelectionPanel($param);
	}

	public function getCheckedIds()
	{
		$checked = $this->getChecked();
		$masterCheck = $this->getMasterCheck($checked);

		if ($masterCheck)
		{
			$ret = array();
			$this->_query = $this->getLastQuery();

			$response = $this->getApplication()->getModule('search')->search($this->_query, 0, $this->getLastResultCount());

			foreach ($response['response']['docs'] as $key => $result)
				$ret[] = $result['Id'];

			return array_diff($ret, $checked);
		}
		else
		{
			return (!is_array($checked)) ? array() : $checked;
		}
	}

	public function countCheckedIds()
	{
		$checked = $this->getChecked();
		$masterCheck = $this->getMasterCheck($checked);

		return $masterCheck ? $this->getLastResultCount() - count($checked) + 1 : count($checked);
	}

	public function onAddToShelf($sender, $param)
	{
		$shelfId = intval($this->ShelfResultValue->getValue());
		$this->ShelfResultValue->setValue('');
		$shelf = ShelfQuery::create()->findPk($shelfId);

		if ($shelf instanceof Shelf)
		{
			$checkedId = $this->getCheckedIds();
			$counter = $shelf->addItemToShelf(ShelfPeer::TYPE_MANIFESTATION, $checkedId);
			
			$this->getPage()->writeMessage(Prado::localize("{counter} notizie aggiunte nello scaffale con id:{shelfId}", 
																array(	'counter' => $counter,
																		'shelfId' => $shelfId )),
												ClavisMessage::CONFIRM);
		}

		if ($this->ShelfTeleport->getValue() == 'true')
			$this->getPage()->gotoPageWithReturn('Communication.ShelfViewPage', array('id' => $shelfId));
	}

	public function onMultiSelect($sender, $param)
	{
		$idlist = $this->getCheckedIds();
		$ret = ($idlist) ? serialize($idlist) : null;
		$this->getPage()->getClientScript()->registerEndScript(__CLASS__ . '_js', 'onReturn(\'multi\',\'' . $ret . '\',true);');
	}

	private function escapeLucene($value)
	{
		$value = preg_replace('/(\+|-|&&|\|\||!|\(|\)|\{|}|\[|]|~|:|\\\)/', '\\\$1', $value);
		if (strpos($value, '?') !== false)
			$value = "({$value}) OR (" . str_replace('?', '', $value) . ')';
		return $value;
	}
	/* old Ciro's code
	  public function OLDresetChecked()
	  {
	  $this->getApplication()->getSession()->remove('MasterCheck' . $this->_uniqueId);
	  $this->getApplication()->getSession()->remove('Checks' . $this->_uniqueId);
	  }

	  public function OLDgetChecked()
	  {
	  if (!$this->_checked)
	  $this->_checked = $this->getApplication()->getSession()->itemAt('Checks' . $this->_uniqueId);
	  if (!is_array($this->_checked))
	  $this->_checked = array();
	  return $this->_checked;
	  }

	  public function OLDgetMasterCheck()
	  {
	  if ($this->_masterCheck === null)
	  $this->_masterCheck = $this->getApplication()->getSession()->itemAt('MasterCheck' . $this->_uniqueId);
	  return $this->_masterCheck;
	  }

	  public function OLDonMasterCheck($sender, $param)
	  {
	  $this->resetChecked();
	  $this->_masterCheck = $sender->getChecked();
	  $this->_checked = array();
	  $this->getApplication()->getSession()->add('MasterCheck' . $this->_uniqueId, $this->_masterCheck);
	  $this->saveChecked();
	  foreach ($this->ResultGrid->getItems() as $item)
	  $item->CheckColumn->CheckedBox->setChecked($this->_masterCheck);
	  $this->updateSelectionPanel($param);
	  return $this->_masterCheck;
	  }
	 */

}
