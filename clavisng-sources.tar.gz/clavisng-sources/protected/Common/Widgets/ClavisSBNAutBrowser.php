<?php
/**
 * ClavisSBNAutBrowser class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Widgets
 */

/**
 * ClavisSBNAutBrowser Class
 *
 * Widget to browser through SBN index.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Widgets
 * @since 2.5.1
 */
class ClavisSBNAutBrowser extends TTemplateControl
{
	/* @var ClavisSBN */
	public $_sbnMod;
	public $_has_browser_sibling = false;

	public function onLoad($param)
	{
		parent::onLoad($param);
		
		$this->_sbnMod = $this->getApplication()->getModule('sbn');
		if (!$this->_sbnMod instanceof TModule ||
				!$this->_sbnMod->getEnabled())
		{
			//$this->SBNNotEnabled->setVisible(true);
			//$this->SBNEnabled->setVisible(false);
			return;
		}

		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallback())
		{
			$this->populate();
			$this->dataBind();
		}
		
		$browser_siblings = $this->getPage()->findControlsByType('ClavisSBNBrowser');
		
		if (count($browser_siblings) > 0 && $browser_siblings[0]->getVisible())
			$this->_has_browser_sibling = true;
	}

	public function completePager($sender, $param)
	{
		$pager = $param->Pager->getControls();
		//$pager->add(' / ' . $this->ResultGrid->getPageCount());

		$label = new TLabel();
		$label->setID('PageRowsLabel');
		$label->setText(Prado::localize('num.righe') . ' ');
		$label->setCssClass("viewlabel4small");
		$pager->insertAt(0, $label);

		$pageSizeSelect = new TDropDownList();
		$pageSizeSelect->setID('PageRows');
		$pageSizeSelect->setAutoPostBack(true);
		foreach (array(10, 20, 50, 100) as $value)
		{
			$element = new TListItem();
			$element->setText($value);
			$element->setValue($value);
			$pageSizeSelect->getItems()->add($element);
		}
		
		if (($pageSize = $this->ResultGrid->getPageSize()) > 0)
			$pageSizeSelect->setSelectedValue($pageSize);
		
		$pager->insertAt(1, $pageSizeSelect);
		$pageSizeSelect->attachEventHandler('OnSelectedIndexChanged', array($this, 'onChangePageSize'));
		$pager->insertAt(2, ' | ');
	}

	public function reset()
	{
		$this->updateSelectionPanel();
	}

	public function cleanAutSearch($sender, $param)
	{
		$this->AuthType->setSelectedIndex(0);
		$this->Bid->setText('');
		$this->String->setText('');
		$this->ISADN->setText('');
		$this->ResultId->setValue(null);
		$this->RelatorCode->setSelectedIndex(-1);
		$this->NameForm->setSelectedIndex(-1);
		$this->CodLevelFrom->setSelectedIndex(-1);
		$this->CodLevelTo->setSelectedIndex(-1);
		$this->T005RangeFrom->setText('');
		$this->T005RangeTo->setText('');
		$this->Sorting->setSelectedIndex(0);
		$this->reloadSearch();
	}

	public function doSearch($sender, $param)
	{
		$this->ResultGrid->setCurrentPageIndex(0);
		$this->ResultId->setValue(null);
		$this->reloadSearch();
	}

	public function onChangePage($sender, $param)
	{
		$this->ResultGrid->setCurrentPageIndex($param->NewPageIndex);
		$this->reloadSearch();
	}

	public function onChangePageSize($sender, $param)
	{
		$start = $this->ResultGrid->getCurrentPageIndex() * $this->ResultGrid->getPageSize();
		if (($newPageSize = intval($sender->getSelectedValue())) > 0)
		{
			$this->ResultGrid->setPageSize($newPageSize);
			$this->ResultGrid->setCurrentPageIndex(0);
			$this->ResultId->setValue(null);
			$this->reloadSearch();
		}
	}

	public function onChangeSorting($sender, $param)
	{
		$this->setViewState('Sorting', $sender->getSelectedValue());
		$this->reloadSearch();
	}

	public function reloadSearch()
	{
		$this->SbnErrorPanel->setVisible(false);
		$authType = $this->AuthType->getSelectedValue();
		$req = $this->_sbnMod->getNewRequest();
		if ($this->ResultId->getValue() != null)
			$req->setSearchId($this->ResultId->getValue());
		$req->searchAutOptions['tipoAuthority'] = $authType;
		if ($this->RelatorCode->getSelectedIndex() > 0)
			$req->searchAutOptions['relatorCode'] = $this->RelatorCode->getSelectedValue();
		if ($this->NameForm->getSelectedIndex() > 0)
			$req->searchAutOptions['formaNome'] = $this->NameForm->getSelectedValue();
		if ($this->CodLevelFrom->getSelectedIndex() > 0)
			$req->searchAutOptions['LivelloAut_Da'] = $this->CodLevelFrom->getSelectedValue();
		if ($this->CodLevelTo->getSelectedIndex() > 0)
			$req->searchAutOptions['LivelloAut_Da'] = $this->CodLevelTo->getSelectedValue();
		$tmparr = array();
		if ($df = $this->T005RangeFrom->getText())
			$tmparr['dataDa'] = date_create($df)->format('Y-m-d');
		if ($df = $this->T005RangeTo->getText())
			$tmparr['dataA'] = date_create($df)->format('Y-m-d');
		if (!empty($tmparr))
		{
			if (!isset($tmparr['dataA']))
			{
				$tmparr['dataA'] = date('Y-m-d');
				$this->T005RangeTo->setTimeStamp(time());
			}
			if (!isset($tmparr['dataDa']))
			{
				$tmparr['dataDa'] = $tmparr['dataA'];
				$this->T005RangeFrom->setTimeStamp(strtotime($tmparr['dataA']));
			}
			$req->searchAutOptions['T005_Range'] = $tmparr;
		}

		$req->setSearchSortType($this->Sorting->getSelectedValue());
		$req->setSearchLimit($this->ResultGrid->getPageSize());
		$req->setSearchOffset($this->ResultGrid->getCurrentPageIndex() + 1);
		$this->MissingMainFieldError->setVisible(false);

		if ($v = $this->Bid->getText())
		{
			$ret = $req->searchAuthorityByBid($v, $authType);
		}
		else if ($v = $this->ISADN->getText())
		{
			$ret = $req->searchAuthorityByIsadn($v);
		}
		else if ($v = $this->String->getText())
		{
			if (SBNTypes::AUTTYPE_MARCA == $authType)
				$ret = $req->searchPrintersDevice($v);
			else
				$ret = ($this->StringMode->getSelectedValue() == 'LIKE') ?
						$req->searchAuthorityLike($v) : $req->searchAuthorityEqual($v);
		} else
		{
			$this->MissingMainFieldError->setVisible(true);
			$this->ResultNumLabel->setVisible(false);
			return;
		}

		$hits = 0;
		$resultSet = array();
		if ($ret && '0000' == $ret->SbnMessage->SbnResponse->SbnResult->esito)
		{
			$hits = (string) $ret->SbnMessage->SbnResponse->SbnOutput['totRighe'];
			$tmCollection = SBNConverter::SBN2Turbomarc($ret);
			foreach ($tmCollection->children() as $r)
				if ($rec = $this->parseTurbomarc($r))
					$resultSet[] = $rec;
			$this->ResultId->setValue((string) $ret->SbnMessage->SbnResponse->SbnOutput['idLista']);
			$this->ResultGrid->setVirtualItemCount($hits);
			$this->ResultGrid->setDataSource($resultSet);
			$this->ResultGrid->dataBind();
		} else if ($ret && '3001' == $ret->SbnMessage->SbnResponse->SbnResult->esito)
		{
			$hits = 0;
			$this->ResultGrid->setVirtualItemCount($hits);
			$this->ResultGrid->setDataSource(array());
			$this->ResultGrid->dataBind();
			if (!$this->getPage()->IsPopup())
				$this->CreateAut->setVisible(true);
		} else if (isset($ret->SbnMessage->SbnResponse->SbnResult->esito))
		{
			$hits = -1;
			$this->SbnErrorPanel->setVisible(true);
			$this->SbnErrorMessage->setText((string) $ret->SbnMessage->SbnResponse->SbnResult->testoEsito);
			$this->ResultGrid->setDataSource(array());
			$this->ResultGrid->dataBind();
		}
		else
		{
			$hits = -1;
			$this->SbnErrorPanel->setVisible(true);
			$this->SbnErrorMessage->setText(Prado::localize("Impossibile stabilire una connessione con l'indice SBN,
							si prega di riprovare in un secondo momento."));
			$this->ResultGrid->setDataSource(array());
			$this->ResultGrid->dataBind();
		}
		if ($hits >= 0)
		{
			$this->ResultNumLabel->Parameters->results = $hits;
			$this->ResultNumLabel->setVisible(true);
		}
		else
		{
			$this->ResultNumLabel->setVisible(false);
		}
	}

	private function parseTurbomarc(TurboMarc $tm)
	{
		$ret = array('Id' => 0, 'ClavisId' => 0, 'Turbomarc' => $tm->asXML(), 'InCatalog' => false);
		$l = $tm->getLeader();
		$our_auth_id = AuthorityPeer::bidExists((string) $tm->d035->s9, (string) $tm->d035->sa);
		if ($our_auth_id)
		{
			$ret['ClavisId'] = $ret['Id'] = $our_auth_id;
			$ret['InCatalog'] = true;
		}
		$ret['Bid'] = (string) $tm->d035->sa;
		$ret['BidSource'] = (string) $tm->d035->s9;
		$ret['AuthType'] = (string) $tm->d099->sd;
		if (AuthorityPeer::RECTYPE_VARIANT == $l->type)
			$ret['AuthType'] .= ' [v]';
		$ret['Author'] = $tm->getAuthor();

		switch ((string) $tm->d099->sd)
		{
			case SBNTypes::AUTTYPE_AUTORE:
				if (isset($tm->d200))
				{ // AutPersonaleType
					$ret['Text'] = $tm->getAuthor(200);
				}
				else if (isset($tm->d210))
				{ // EnteType
					$ret['Text'] = $tm->getAuthor(210);
				}
				break;
			case SBNTypes::AUTTYPE_TITOLO_UNIFORME:
			case SBNTypes::AUTTYPE_TITOLO_UNIFORME_MUSICA:
				$ret['Text'] = (string) $tm->d230->sa;
				break;
			case SBNTypes::AUTTYPE_SOGGETTO:
				$ret['Text'] = "[{$tm->d250->s2}] " . (string) $tm->d250->sa;
				foreach ($tm->d250->sx as $subd)
					$ret['Text'] .= ' - ' . $subd;
				break;
			case SBNTypes::AUTTYPE_DESCRITTORE:
				$ret['Text'] = "[{$tm->d931->s2}] {$tm->d931->sa}";
				break;
			case SBNTypes::AUTTYPE_LUOGO:
				$ret['Text'] = (string) $tm->d260->sd;
				break;
			case SBNTypes::AUTTYPE_CLASSE:
				$ret['Text'] = (isset($tm->d676)) ?
						"[{$tm->d676->sv}] {$tm->d676->sa} {$tm->d676->sc}" :
						"[{$tm->d686->s2}] {$tm->d686->sa} {$tm->d686->sc}";
				break;
			case SBNTypes::AUTTYPE_MARCA:
				$ret['Text'] = (string) $tm->d921->sa;
				break;
			case SBNTypes::AUTTYPE_REPERTORIO:
				$ret['Text'] = "[{$tm->d930->s2}] {$tm->d930->sa}";
				break;
			default:
				$ret['Text'] = Prado::localize('Tipo authority non riconosciuto: {authtype}', array('authtype' => (string) $tm->d099->sd));
		}
		$ret['Text'] = htmlentities($ret['Text'], ENT_QUOTES, 'UTF-8');
		return $ret;
	}

	public function populate()
	{
		$this->ResultId->setValue(null);
		$this->reloadSearch();
	}

	public function resultAction($sender, $param)
	{
		$data = $param->getCommandParameter();
		switch ($param->getCommandName())
		{
			case 'import':
				$data = $param->getCommandParameter();
				try
				{
					$tm = TurboMarc::createRecord($data['Turbomarc']);
					$a = AuthorityPeer::createFromTurbomarc($tm);
					$a->doIndex();
					ChangelogPeer::logAction($a, ChangelogPeer::LOG_CREATE, $this->getUser(), 'Nuova authority importata');

					$msg = Prado::localize('Authority importata correttamente.');
					$type = ClavisMessage::CONFIRM;
					$this->getPage()->writeMessage($msg, $type);
					$this->getPage()->gotoPage('Catalog.AuthorityViewPage', array('id' => $a->getAuthorityId()));
				}
				catch (PropelException $e)
				{
					// duplicate!
					$this->getPage()->writeMessage(Prado::localize('Errore durante l\'importazione della authority: ' .
									'il *ID esiste già nella base dati'), ClavisMessage::ERROR);
				}
				catch (Exception $e)
				{
					Prado::log('Exception: ' . $e->getMessage());
					$this->getPage()->writeMessage(Prado::localize('Errore durante l\'importazione della authority: ') .
							$e->getMessage(), ClavisMessage::ERROR);
				}
				return;
			case 'linkSearch':
				$browser_siblings = $this->getPage()->findControlsByType('ClavisSBNBrowser');
				if (count($browser_siblings) > 0)
				{
					$data = $param->getCommandParameter();
					$browser_siblings[0]->LinkId->setText($data['Bid']);
					$browser_siblings[0]->LinkClass->setSelectedValue(SBNTypes::OBJCLASS_AUT);
					$browser_siblings[0]->LinkType->setSelectedValue($data['AuthType']);
					$browser_siblings[0]->reloadSearch();
					$this->getParent()->getParent()->setActiveView($browser_siblings[0]->getParent());
					$this->getParent()->getParent()->dataBind();
				}
				return;
		}
	}

	public function doInsertAuthority($sender, $param)
	{
		$title = $this->String->getText();
		$authType = SBNConverter::SBNType2ClavisType($this->AuthType->getSelectedValue());
		$this->getPage()->gotoPage('Catalog.AuthorityEditPage', array('Title' => $title, 'authType' => $authType));
	}
	
}