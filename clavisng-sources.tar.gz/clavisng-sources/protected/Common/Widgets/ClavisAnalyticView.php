<?php

/**
 * ClavisAnalyticView
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2009 Comperio srl
 */
class ClavisAnalyticView extends TTemplateControl
{
	private $_manifestation;

	public function onLoad($param)
	{
		parent::onLoad($param);
		if (!$this->getPage()->getIsPostBack())
		{
			$this->populate();
		}
	}

	public function searchIssue($sender, $param)
	{
		$this->populate();
	}

	public function populate()
	{
		$c = new Criteria();
		$c->addDescendingOrderByColumn(IssuePeer::ISSUE_DATE);
		$yearFilter = $this->VolumeFilter->getSelectedValue();
		if ($yearFilter)
			$c->add(IssuePeer::ISSUE_YEAR, $yearFilter);
		if ($this->LibraryFilter->getChecked() == true)
		{
			$c->addJoin(ItemPeer::ISSUE_ID, IssuePeer::ISSUE_ID, Criteria::JOIN);
			$c->add(ItemPeer::HOME_LIBRARY_ID, $this->getUser()->getActualLibraryId());
		}

		$m = $this->getManifestation();
		$i = $m->getIssues($c);
		$this->IssueRepeater->setDataSource($i);
		$this->IssueRepeater->dataBind();

		$c->clear();
		$c->add(IssuePeer::MANIFESTATION_ID, $m->getManifestationId());
		$c->clearSelectColumns()->addSelectColumn(IssuePeer::ISSUE_YEAR);
		$c->setDistinct();
		$c->addDescendingOrderByColumn(IssuePeer::ISSUE_YEAR);
		$stmt = IssuePeer::doSelectStmt($c);
		$volume_ds = array(0 => '---');
		while ($row = $stmt->fetch(PDO::FETCH_NUM))
			$volume_ds[$row[0]] = $row[0];
		$this->VolumeFilter->setDataSource($volume_ds);
		$this->VolumeFilter->dataBind();
	}

	public function setManifestation(Manifestation $manifestation)
	{
		$this->_manifestation = $manifestation;
		$this->setControlState('Manifestation', $this->_manifestation, null);
	}

	/**
	 *
	 * @return Manifestation The manifestation
	 */
	public function getManifestation()
	{
		if (!$this->_manifestation instanceof Manifestation)
			$this->_manifestation = $this->getControlState('Manifestation', null);
		return $this->_manifestation;
	}

	public function dataBindIssueRepeater($sender, $param)
	{
		$item = $param->Item;
		if ($item->ItemType === 'Item' || $item->ItemType === 'AlternatingItem')
		{
			$item->AnalyticRepeater->setDataSource($item->DataItem->getAnalytics());
			$item->AnalyticRepeater->dataBind();
		}
	}

	public function issueItemCreated($sender, $param)
	{
		static $itemIndex = 0;
		$item = $param->Item;
		if ($item->ItemType === 'Item' || $item->ItemType === 'AlternatingItem')
		{
			$itemIndex++;
		}
	}

	public function analyticItemCreated($sender, $param)
	{
		static $itemIndex = 0;
		$item = $param->Item;
		if ($item->ItemType === 'Item' || $item->ItemType === 'AlternatingItem')
		{
			$itemIndex++;
		}
	}
}