<?php
/**
 * ClavisConsistencyNoteList class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Widgets
 */

/**
 * ClavisConsistencyNoteList Class
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Widgets
 * @since 2.5.0
 */
class ClavisConsistencyNoteList extends TTemplateControl
{
	const MODE_ADMIN = 'admin';
	const MODE_MANIFESTATION = 'manifestation';

	public function onLoad($param)
	{
		parent::onLoad($param);
		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallBack())
		{
			$this->populate();
		}
	}

	public function getMode()
	{
		return $this->getControlState('Mode', self::MODE_ADMIN);
	}

	public function setMode($value)
	{
		$this->setControlState('Mode', $value);
	}

	public function getManifestationId()
	{
		return $this->getControlState('ManifestationId', null);
	}

	public function setManifestationId($value)
	{
		$this->setControlState('ManifestationId', $value);
	}

	/**
	 * Cleans the search textboxes and re-populates.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onClearSearch()
	{
		$this->searchCancel(null, null);
	}

	public function populate()
	{
		$pageSize = $this->ConsistencyNoteGrid->getPageSize();
		$currentIndexPage = $this->ConsistencyNoteGrid->getCurrentPage();
		$q = ConsistencyNoteQuery::create()
				->filterByLibraryId($this->getUser()->getActualLibraryId());
		if ($this->getMode() == self::MODE_MANIFESTATION)
		{
			if (!$mid = $this->getManifestationId())
				return;
			$q->filterByManifestationId($mid);
		}
		$recCount = $q->count();
		$this->ConsistencyNoteGrid->setVirtualItemCount($recCount);
		$this->RecCounter->setText("Record totali: $recCount");
		$q->limit($pageSize)->offset($currentIndexPage * $pageSize);
		$ds = $q->joinManifestation()->find();
		$this->ConsistencyNoteGrid->setDataSource($ds);
		$this->ConsistencyNoteGrid->dataBind();
	}

	public function onCancel()
	{
		$this->searchCancel(null, null);
	}

	public function changePage($sender, $param)
	{
		$this->ConsistencyNoteGrid->setSelectedItemIndex(-1);
		$this->ConsistencyNoteGrid->setEditItemIndex(-1);
		$this->ConsistencyNoteGrid->setCurrentPage($param->NewPageIndex);
		$this->getPage()->globalRefresh();
	}

	public function getPopupFlag()
	{
		return $this->getPage()->IsPopup();
	}

	public function getUnlinkFlag()
	{
		return $this->getPage()->IsUnlink();
	}

	public function globalRefresh()
	{
		$this->populate();
	}

	public function deleteItem($sender, $param)
	{
		$item = $param->Item;
		$note = ConsistencyNoteQuery::create()->findPk($this->ConsistencyNoteGrid->DataKeys[$item->ItemIndex]);
		if ($note instanceof ConsistencyNote)
		{
			ChangelogPeer::logAction($note, ChangelogPeer::LOG_DELETE, $this->getUser(), 'Eliminata nota di consistenza');
			$note->delete();
		}

		$this->ConsistencyNoteGrid->SelectedItemIndex = -1;
		$this->ConsistencyNoteGrid->EditItemIndex = -1;
		$this->populate();
	}

	public function itemCreated($sender, $param)
	{
		$item = $param->Item;
		if ($item->ItemType === 'EditItem')
		{
			
		}
		if ($item->ItemType === 'Item' || $item->ItemType === 'AlternatingItem' || $item->ItemType === 'EditItem')
		{
			$item->DeleteColumn->Button->Attributes->onclick = 'if(!confirm(\'' . Prado::localize("Sei sicuro?") . '\')) return false;';
		}
	}

	public function editItem($sender, $param)
	{
		$this->ConsistencyNoteGrid->EditItemIndex = $param->Item->ItemIndex;
		$this->populate();
	}

	public function saveItem($sender, $param)
	{
		$item = $param->Item;
		$n = ConsistencyNoteQuery::create()->findPk($this->ConsistencyNoteGrid->DataKeys[$item->ItemIndex]);
		if ($n instanceof ConsistencyNote)
		{
			$n->setCollocation($item->CollocationColumn->TextBox->getText());
			$n->setTextNote($item->TextNoteColumn->TextBox->getText());
			$n->setClosed($item->ClosedColumn->CheckBox->getChecked());
			$n->save();
			ChangelogPeer::logAction($n, ChangelogPeer::LOG_UPDATE, $this->getUser(), "Aggiornata nota di consistenza [{$n->getConsistencyNoteId()}] della biblioteca " . $n->getLibraryId());
			$this->getPage()->writeMessage(Prado::localize('Nota di consistenza aggiornata.'), ClavisMessage::INFO);
		}
		$this->ConsistencyNoteGrid->EditItemIndex = -1;
		$this->populate();
	}

	public function cancelItem($sender, $param)
	{
		$this->ConsistencyNoteGrid->EditItemIndex = -1;
		$this->populate();
	}

	public function showNewNotePanel($sender, $param)
	{
		$this->NewNotePanel->setVisible(true);
		if ($this->getMode() == self::MODE_MANIFESTATION && $mid = $this->getManifestationId())
		{
			$m = ManifestationQuery::create()->findPk($mid);
			$this->RecordResultLabel->setText($m->getTitle());
			$this->RecordResultValue->setValue($mid);
			$this->ManLinkChooser->setEnabled(false);
		}
		$this->getPage()->setFocus('NewNotePanel');
		$this->populate();
	}

	public function hideNewNotePanel($sender, $param)
	{
		$this->NewNotePanel->setVisible(false);
		$this->populate();
	}

	public function validateSerial($sender, $param)
	{
		$m = ManifestationQuery::create()->findPk($param->Value);
		$param->IsValid = ($m instanceof Manifestation && $m->getBibLevel() == ManifestationPeer::LVL_SERIAL);
	}

	public function addNote($sender, $param)
	{
		if (!$this->getPage()->getIsValid())
			return;
		$n = new ConsistencyNote();
		$n->setLibraryId($this->getUser()->getActualLibraryId());
		$n->setManifestationId($this->RecordResultValue->getValue());
		$n->setCollocation($this->NewNoteCollocation->getText());
		$n->setTextNote($this->NewNoteText->getText());
		$n->setClosed($this->NewNoteClosed->getChecked());
		$n->save();
		$this->getPage()->writeMessage('Nota di consistenza creata correttamente.', ClavisMessage::INFO);
		$this->hideNewNotePanel($sender, $param);
	}
	
}