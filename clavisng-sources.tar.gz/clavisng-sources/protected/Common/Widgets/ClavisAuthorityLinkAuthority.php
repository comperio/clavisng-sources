<?php
/**
 * ClavisAuthorityLinkAuthority file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Ciro Mattia Gonano
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Widgets
 */

/**
 * ClavisAuthorityLinkAuthority Class
 *
 * @author Ciro Mattia Gonano
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.7
 * @package Widgets
 * @since 2.4.3
 */
class ClavisAuthorityLinkAuthority extends TTemplateControl
{
	/* @var Authority */
	public $authority;
	public $authType;
	public $authRecType;
	public $baseLinkTypeClass;

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!isset($this->authority) 
				|| is_null($this->authority))
			$this->authority = $this->getAuthority();

		if ($this->authority instanceof Authority)
			$this->SubjectLink->setAuthority($this->authority);
	}

	public function getAuthority()
	{
		return $this->getControlState('authority', null);
	}

	public function setAuthority(Authority $value)
	{
		$this->authority = $value;
		$this->authType = $this->authority->getAuthorityType();
		$this->authRecType = $this->authority->getAuthorityRecType();
		$this->setControlState('authority', $this->authority);
	}

	public function populate()
	{
		if (!$this->authority)
			return;

		$pageSize = $this->AuthGrid->getPageSize();
		$currentIndexPage = $this->AuthGrid->getCurrentPage();
		$linkList = array();
		$filters = array();

		if ($this->TypeFilter->isSelected())
			$filters['AuthorityType'] = $this->TypeFilter->getSelectedValue();

		if ($this->LinkTypeFilter->isSelected())
			$filters['LinkType'] = $this->LinkTypeFilter->getSelectedValue();

		if ($this->RelatorCodeFilter->isSelected())
			$filters['RelatorCodeType'] = $this->RelatorCodeFilter->getSelectedValue();

		if (trim($this->FilterFullText->getText()) != '')
			$filters['FullText'] = trim($this->FilterFullText->getText());

		$linkedAuthorities = $this->authority->getAuthoritiesLinkList(	true, 
																		false, 
																		$currentIndexPage + 1, 
																		$pageSize, 
																		$filters);
		
		$totRows = $linkedAuthorities['TotRows'];
		unset($linkedAuthorities['TotRows']);
		
		foreach ($linkedAuthorities as $linkLabel => $links)
			$linkList = array_merge($linkList, $links);

		//$lAuthListsCount = count($linkList);
		//$ds = array_slice($linkList,$pageSize*$currentIndexPage,$pageSize);
		$this->AuthGrid->setDataSource($linkList);
		$this->AuthGrid->VirtualItemCount = $totRows;
		$this->AuthGrid->dataBind();
		$this->AuthCounter->setText($totRows);

		$this->NewLinkPanel->setVisible(!$this->getReadOnly());
	}

	public function setReadOnly($value)
	{
		return $this->setControlState('ReadOnly', TPropertyValue::ensureBoolean($value), false);
	}

	public function getReadOnly()
	{
		return $this->getControlState('ReadOnly', false);
	}

	public function onFilterList($sender, $param)
	{
		$this->populate();

		if (is_null($param))
		{
			$writer = $this->getPage()->getResponse()->getAdapter()->createNewHtmlWriter('THtmlWriter', $this->getPage()->getResponse());
		}
		else
		{
			$writer = $param->getNewWriter();
		}

		$this->GridPanel->render($writer);
	}

	public function onSuggestAuthority($sender, $param)
	{
		$prefix = $param->getToken();
		$authList = AuthorityPeer::doSuggest($prefix, 10);
		$authData = array();
		
		foreach ($authList as $auth)
		    if($auth instanceof Authority)
			    $authData[] = array(	'id' => $auth->getAuthorityId(),
									'text' => $auth->getFullTextSpec() );

		$sender->setDataSource($authData);
		$sender->dataBind();
	}

	public function onSuggestAuthorityCallBack($sender, $param)
	{
		$id = $sender->Suggestions->DataKeys[$param->selectedIndex];
		$authorityUp = AuthorityPeer::retrieveByPK($id);

		if ($authorityUp instanceof Authority)
		{
			$accepted = $authorityUp->getAcceptedAuthority();

			if (!$accepted)
				$accepted = $authorityUp;

			if ($this->populateDropDowns($accepted))
			{
				$this->AuthorityID->setValue($accepted->getAuthorityId());
				$this->NewAuthLink->setText($accepted->getFullText());
			}

			return;
		}

		$this->cleanNewAuthority();
	}

	public function onSelectFromPopup($sender, $param)
	{
		$a = AuthorityPeer::retrieveByPK(intval($this->AuthorityID->getValue()));

		if ($a instanceof Authority)
		{
			$this->populateDropDowns($a);
		}
		else
		{
			$this->cleanNewAuthority();
		}
	}

	private function cleanNewAuthority()
	{
		$this->LinkType->setDataSource(array());
		$this->LinkType->dataBind();
		$this->RelatorCode->setDataSource(array());
		$this->RelatorCode->dataBind();
		$this->LinkType->setEnabled(false);
		$this->RelatorCode->setEnabled(false);
		$this->AuthorityID->setValue(null);
		$this->NewAuthLink->setText('');
		$this->LinkSequence->setText('');
		$this->LinkNote->setText('');
	}

	private function checkAuthorityLinkLegality(Authority $target)
	{
		switch ($this->authRecType)
		{
			case AuthorityPeer::RECTYPE_NODE:
				if ($target->getAuthorityRectype() == AuthorityPeer::RECTYPE_VARIANT)
					return Prado::localize("Impossibile legare un'etichetta di nodo con un termine variante.");
				
				if ($target->getAuthorityType() != $this->authType)
					return Prado::localize("Il legame con etichette di nodo dev'essere tra authority dello stesso tipo.");
				
				break;
				
			case AuthorityPeer::RECTYPE_VARIANT: // not accepted
				if ($target->getAuthorityRectype() == AuthorityPeer::RECTYPE_NODE)
					return Prado::localize("Impossibile legare un'etichetta di nodo con un termine variante.");
				
				if ($target->getAuthorityRectype() == AuthorityPeer::RECTYPE_VARIANT)
					return Prado::localize("Impossibile legare due termini non accettati.");
				
				if ($target->getAuthorityType() != $this->authType)
					return Prado::localize("Il legame tra termine non accettato e accettato dev'essere tra authority dello stesso tipo.");
				
				break;
		}
		
		return true;
	}

	public function populateDropDowns(Authority $a) //, $myAuthority = null)
	{
		$res = $this->checkAuthorityLinkLegality($a);
		
		if ($res !== true)
		{
			$this->NewAuthMessage->setText($res);
			$this->cleanNewAuthority();
			
			return false;
		}
		
		$this->populateLinkType($a); //, $myAuthority);
		
		return true;
	}

	private function calculateLinkTypeRelatorCode($authority, $myAuthority, $stripAuthorsFlag = true)
	{
		$myType = $myAuthority->getAuthorityType();
				
		if ((AuthorityPeer::RECTYPE_VARIANT == $myAuthority->getAuthorityRecType()) 
				|| (AuthorityPeer::RECTYPE_VARIANT == $authority->getAuthorityRectype()))
		{
			$linkTypeDS = LookupValuePeer::getLookupClassValues('AUTHLINKTYPEMUTUAL');
			$meVariant = $myAuthority->getAuthorityRecType() == AuthorityPeer::RECTYPE_VARIANT;
			
			foreach ($linkTypeDS as $k => $v)
			{
				$key = strval($k);
			
				if ($meVariant xor $key[0] < $key[1])
					unset($linkTypeDS[$k]);
			}
			
			$relatorCodeDS = array(0 => '---');
			
			$values = LookupValueQuery::create()
							->filterByValueClass('AUTHRELATORCODEMUTUAL')
							->filterByValueLanguage($this->getApplication()->getGlobalization()->getCulture())
							->orderByValueLabel()
							->find();
			
			foreach ($values as $value)
				$relatorCodeDS[$value->getValueKey()] = $value->getValueLabel();
			
		}
		elseif (($myType == AuthorityPeer::TYPE_WORK) 
				&& ($authority->getAuthorityType() == AuthorityPeer::TYPE_WORK))
		{
			$linkTypeDS = array(	'KL' => LookupValuePeer::getLookupValue('AUTHLINKTYPE', 'KL'),
									'PK' => LookupValuePeer::getLookupValue('AUTHLINKTYPE', 'PK'),
									'KP' => LookupValuePeer::getLookupValue('AUTHLINKTYPE', 'KP'),
									'0X1' => LookupValuePeer::getLookupValue('AUTHLINKTYPE', '0X1'),
									'1X0' => LookupValuePeer::getLookupValue('AUTHLINKTYPE', '1X0'),
									'2X3' => LookupValuePeer::getLookupValue('AUTHLINKTYPE', '2X3'),
									'3X2' => LookupValuePeer::getLookupValue('AUTHLINKTYPE', '3X2'),
									'4X5' => LookupValuePeer::getLookupValue('AUTHLINKTYPE', '4X5'),
									'5X4' => LookupValuePeer::getLookupValue('AUTHLINKTYPE', '5X4'),
									'6X7' => LookupValuePeer::getLookupValue('AUTHLINKTYPE', '6X7'),
									'7X6' => LookupValuePeer::getLookupValue('AUTHLINKTYPE', '7X6'),
									'8X8' => LookupValuePeer::getLookupValue('AUTHLINKTYPE', '8X8'),
									'AXA' => LookupValuePeer::getLookupValue('AUTHLINKTYPE', 'AXA'),
									'CXC' => LookupValuePeer::getLookupValue('AUTHLINKTYPE', 'CXC'),
									'EXF' => LookupValuePeer::getLookupValue('AUTHLINKTYPE', 'EXF'),
									'FXE' => LookupValuePeer::getLookupValue('AUTHLINKTYPE', 'FXE'),
									'GXH' => LookupValuePeer::getLookupValue('AUTHLINKTYPE', 'GXH'),
									'HXG' => LookupValuePeer::getLookupValue('AUTHLINKTYPE', 'HXG'),
									'IXJ' => LookupValuePeer::getLookupValue('AUTHLINKTYPE', 'IXJ'),
									'JXI' => LookupValuePeer::getLookupValue('AUTHLINKTYPE', 'JXI'),
									'KXL' => LookupValuePeer::getLookupValue('AUTHLINKTYPE', 'KXL'),
									'LXK' => LookupValuePeer::getLookupValue('AUTHLINKTYPE', 'LXK') );
		}
		elseif ($authority->getAuthorityType() == AuthorityPeer::TYPE_CLASS)
		{
			$linkTypeDS = array(	'KL' => LookupValuePeer::getLookupValue('AUTHLINKTYPE', 'KL'),
									'11' => LookupValuePeer::getLookupValue('AUTHLINKTYPE', '11'),
									'23' => LookupValuePeer::getLookupValue('AUTHLINKTYPE', '23'),
									'32' => LookupValuePeer::getLookupValue('AUTHLINKTYPE', '32') );
		}
		else
		{
			$linkTypeDS = LookupValuePeer::getLookupClassValues('AUTHLINKTYPE');
			
			foreach ($linkTypeDS as $k => $v)
			{
				if (!in_array($k, LAuthorityPeer::$linkByTypes[$myType]))
					unset($linkTypeDS[$k]);
			}
			
			if ($myAuthority->getAuthorityRectype() == AuthorityPeer::RECTYPE_TOPTERM)
				unset($linkTypeDS['23']);
			
			if ($authority->getAuthorityRectype() == AuthorityPeer::RECTYPE_TOPTERM)
				unset($linkTypeDS['32']);
		}

		if(in_array($authority->getAuthorityType(),['S','A','G','T','L','M','H']))
        {
            unset($linkTypeDS['AB']);
            unset($linkTypeDS['BA']);
            unset($linkTypeDS['CD']);
            unset($linkTypeDS['DC']);
            unset($linkTypeDS['EF']);
            unset($linkTypeDS['FE']);
        }
		
		if (((AuthorityPeer::TYPE_WORK == $myType)
					&& $authority->hasWorkRelatorCode())
				|| ((AuthorityPeer::TYPE_WORK == $authority->getAuthorityType()) 
						&& $myAuthority->hasWorkRelatorCode()))
		{
			if ($stripAuthorsFlag)
				$linkTypeDS = $this->filterAuthorsForWork($linkTypeDS);
			
			$relatorCodeDS = array(0 => '---');
			
			$values = LookupValueQuery::create()
						->filterByValueClass('RELATORCODE')
						->filterByValueLanguage($this->getApplication()->getGlobalization()->getCulture())
						->orderByValueLabel()
						->find();
			
			foreach ($values as $value)
				$relatorCodeDS[$value->getValueKey()] = $value->getValueLabel();
		}
		
		return array($linkTypeDS, $relatorCodeDS);
	}
	
	private function calculateSequenceNote($authorityId, $myAuthorityId)
	{
		$output = null;
		
		$lAuthority = LAuthorityQuery::create()
							->filterByAuthorityIdDown($myAuthorityId)
							->filterByAuthorityIdUp($authorityId)
							->findOne();
		
		if ($lAuthority instanceof LAuthority)
			$output = array($lAuthority->getLinkSequence(), $lAuthority->getLinkNote());
		
		return $output;
	}
	
	private function populateLinkType(Authority $authority) //, $myAuthority = null)
	{
		$linkTypeDS = $relatorCodeDS = array();
		$this->LinkType->setEnabled(true);
		$this->LinkType->clearSelection();
		
		if (count($this->LinkType->Items) > 0)
			$this->LinkType->Items->clear();

//		if (!($myAuthority instanceof Authority))
//			$myAuthority = $this->authority;
		
		list($linkTypeDS, $relatorCodeDS) = $this->calculateLinkTypeRelatorCode($authority, $this->authority);

		if (!$linkTypeDS)
		{
			$this->LinkType->setEnabled(false);
			$this->AddLinkButton->setEnabled(false);
		}
		else
		{
			$this->LinkType->setDataSource($linkTypeDS);
			$this->LinkType->dataBind();
		
			if (count($linkTypeDS) < 2)
			{
				$this->LinkType->setSelectedIndex(0);
				$this->LinkType->setEnabled(false);
			}
			
			$this->AddLinkButton->setEnabled(true);
		}
		
		// populate relator code
		$this->RelatorCode->setEnabled(false);
		$this->RelatorCode->clearSelection();
		
		if (count($this->RelatorCode->Items) > 0)
			$this->RelatorCode->Items->clear();
		
		if ($relatorCodeDS)
		{
			$this->RelatorCode->setEnabled(true);
			$this->RelatorCode->setDataSource($relatorCodeDS);
			$this->RelatorCode->dataBind();
		}
	}

	public function filterAuthorsForWork($dataSource)
	{
		if ($this->getWorkHasMainAuthor())
			unset($dataSource['AB']);
		
		if ($this->getWorkHasAltAuthors())
			unset($dataSource['CD']);
		
		return $dataSource;
	}

	private function getWorkHasMainAuthor()
	{
		$auth_up = AuthorityQuery::create()
						->filterByAuthorityType(array(AuthorityPeer::TYPE_PERSONALNAME, AuthorityPeer::TYPE_CORPORATEBODYNAME))
						->useLAuthorityRelatedByAuthorityIdDownQuery()
						->filterByAuthorityRelatedByAuthorityIdUp($this->authority)
						->filterByLinkType(array('AB', 'BA'))
						->endUse()
						->count();
		
		$auth_down = AuthorityQuery::create()
						->filterByAuthorityType(array(AuthorityPeer::TYPE_PERSONALNAME, AuthorityPeer::TYPE_CORPORATEBODYNAME))
						->useLAuthorityRelatedByAuthorityIdUpQuery()
						->filterByAuthorityRelatedByAuthorityIdDown($this->authority)
						->filterByLinkType(array('AB', 'BA'))
						->endUse()
						->count();

		return (($auth_up + $auth_down) > 0);
	}

	private function getWorkHasAltAuthors()
	{
		$auth_up = AuthorityQuery::create()
						->filterByAuthorityType(array(AuthorityPeer::TYPE_PERSONALNAME, AuthorityPeer::TYPE_CORPORATEBODYNAME))
						->useLAuthorityRelatedByAuthorityIdDownQuery()
						->filterByAuthorityRelatedByAuthorityIdUp($this->authority)
						->filterByLinkType(array('CD', 'DC'))
						->endUse()
						->count();
		
		$auth_down = AuthorityQuery::create()
						->filterByAuthorityType(array(AuthorityPeer::TYPE_PERSONALNAME, AuthorityPeer::TYPE_CORPORATEBODYNAME))
						->useLAuthorityRelatedByAuthorityIdUpQuery()
						->filterByAuthorityRelatedByAuthorityIdDown($this->authority)
						->filterByLinkType(array('CD', 'DC'))
						->endUse()
						->count();
		
		return (($auth_up + $auth_down) > 1);
	}

	public function itemCreated($sender, $param)
	{
		$item = $param->Item;
		
//		if (!$this->getReadOnly() 
//				&& in_array($item->ItemType, array('Item', 'AlternatingItem', 'EditItem')))
//			$item->DeleteColumn->Button->Attributes->onclick = 'if(!confirm(\'' . Prado::localize("Sei sicuro di voler cancellare questo legame?") . '\')) return false;';
	}

	public function onDeleteLink($sender, $param)
	{
		$ok = false;
		$id = $param->getCommandParameter();
		//$id = $this->AuthGrid->DataKeys[$param->Item->ItemIndex];
		$link = LAuthorityQuery::create()->findPk(explode('|', $id));
		
		if ($link instanceof LAuthority)
		{
			try
			{
				$linkedAuth = ($link->getAuthorityIdDown() == $this->authority->getAuthorityId()) 
												? $link->getAuthorityRelatedByAuthorityIdUp() 
												: $link->getAuthorityRelatedByAuthorityIdDown();

				$linkedAuthId = $linkedAuth->getAuthorityId();

				if (isset($this->Parent->SBNActions))
				{
					
					// update to SBN BEFORE deleting link
					if (($linkedAuth->getBidSource() == 'SBN')
							&& $linkedAuth->getBid())
						$this->SBNActions->updateLinkToSBN('Delete', $link);
				}

				ChangelogPeer::logAction(	$this->authority, 
											ChangelogPeer::LOG_UPDATE, 
											$this->getUser(), 
											'rimosso legame con authority con id=' . $linkedAuthId,
											$this->authority->getAuthorityId());
				
				$this->getPage()->writeMessage(Prado::localize("Rimosso legame con l'authority con id={id}",
																	array('id' => $linkedAuthId)), 
													ClavisMessage::INFO);
				
				$link->delete();
				$ok = true;
			}
			catch (PropelException $ex)
			{
				$this->getPage()->writeMessage(Prado::localize("Errore alla cancellazione del legame con l'authority con id={id}",
																	array('id' => $linkedAuthId)), 
													ClavisMessage::ERROR);
			}
		}
		else
		{
			$this->getPage()->writeMessage(Prado::localize("Errore interno di passaggio parametri durante la cancellazione del legame con authority. Riportare i dettagli al fornitore del software"), 
												ClavisMessage::ERROR);
		}
		
		if ($ok)
		{
			$this->authority->reload(true);
			$this->populate();
		}
	}

	public function onNewLink($sender, $param)
	{
		$ok = false;
		$linkedId = intval($this->AuthorityID->getValue());
		
		if ($linkedId > 0)
		{
			try
			{
				$link = new LAuthority();
				$link->setAuthorityIdDown($this->authority->getAuthorityId());
				$link->setAuthorityIdUp($linkedId);
				$link->setLinkNote($this->LinkNote->getSafeText());
				$link->setLinkType($this->LinkType->getSelectedValue());
				$link->setRelatorCode($this->RelatorCode->getSelectedValue());
				$link->setLinkSequence(str_pad($this->LinkSequence->getSafeText(), 16, " ", STR_PAD_LEFT));
		
				$link->save();
				
				if (isset($this->Parent->SBNActions))
				{
					$linkedAuth = $link->getAuthorityRelatedByAuthorityIdUp();
				
					// update to SBN BEFORE deleting link
					if (($linkedAuth->getBidSource() == 'SBN') 
							&& $linkedAuth->getBid())
						$this->Parent->SBNActions->updateLinkToSBN('Create', $link);
				}
				
				ChangelogPeer::logAction(	$this->authority, 
											ChangelogPeer::LOG_UPDATE, 
											$this->getUser(), 
											'nuovo legame con authority con id=' . $link->getAuthorityIdUp(),
											$this->authority->getAuthorityId());
				
				$this->getPage()->writeMessage(Prado::localize("Creato nuovo legame con l'authority con id={id}",
																	array('id' => $link->getAuthorityIdUp())), 
													ClavisMessage::CONFIRM);
				
				$ok = true;
			}
			catch (PropelException $e)
			{
				$this->getPage()->writeMessage(Prado::localize("Impossibile creare il legame già esistente"), 
													ClavisMessage::ERROR);
			}
		}
		else
		{
			$this->getPage()->writeMessage(Prado::localize("Nessuna azione di legame ad authority eseguita"),
											ClavisMessage::INFO);
		}
		
		if ($ok)
		{
			$this->cleanNewAuthority();
			$this->authority->clearLAuthoritysRelatedByAuthorityIdDown();
			$this->authority->clearLAuthoritysRelatedByAuthorityIdUp();
			
			//$this->populate();
			$this->onFilterList($sender, $param);
		}
	}

	public function onChangePage($sender, $param)
	{
		$sender->setCurrentPage($param->NewPageIndex);
		$this->populate();
	}

	public function onAuthLinkCommand($sender, $param)
	{
		$item = $param->getItem();
		$sbnactions = $this->getPage()->findControlsByType('ClavisSBNActions');
		
		if (count($sbnactions) < 1)
			return;
		
		switch ($param->getCommandName())
		{
			case 'sbnLinkCreate':
				list($adown_id, $aup_id, $lt, $rc) = explode('|', $this->AuthGrid->DataKeys[$param->Item->ItemIndex]);
				$link = LAuthorityPeer::retrieveByPK($adown_id, $aup_id, $lt, $rc);
				
				if ($link instanceof LAuthority)
				{
					$a_other = ($adown_id == $this->authority->getAuthorityId()) 
										? $link->getAuthorityRelatedByAuthorityIdUp() 
										: $link->getAuthorityRelatedByAuthorityIdDown();
					
					if (($this->authority->getAuthorityRectype() == AuthorityPeer::RECTYPE_VARIANT)
							|| ($a_other->getAuthorityRectype() == AuthorityPeer::RECTYPE_VARIANT) 
							|| ($a_other->getBidSource() == 'SBN') 
							&& $a_other->getBid())
						$sbnactions[0]->updateLinkToSBN('Create', $link);

					$this->populate(); // populate case for case, and not in any case (by mbrancalion, 2014-07-29)
				}
				
				break;
				
			case 'sbnLinkDelete':
				list($adown_id, $aup_id, $lt, $rc) = explode('|', $this->AuthGrid->DataKeys[$param->Item->ItemIndex]);
				$link = LAuthorityPeer::retrieveByPK($adown_id, $aup_id, $lt, $rc);
				
				if ($link instanceof LAuthority)
				{
					$a_other = ($adown_id == $this->authority->getAuthorityId()) 
											? $link->getAuthorityRelatedByAuthorityIdUp() 
											: $link->getAuthorityRelatedByAuthorityIdDown();
					
					if (($a_other->getBidSource() == 'SBN') 
							&& $a_other->getBid())
						$sbnactions[0]->updateLinkToSBN('Delete', $link);

					$this->populate();
				}
				
				break;
		}
	}
	
	public function bindAuthGrid()
	{
		$pageSize = $this->AuthGrid->getPageSize();
		$currentIndexPage = $this->AuthGrid->getCurrentPage();
		$linkList = array();
		
		$linkedAuthorities = $this->authority->getAuthoritiesLinkList(	true, 
																		false, 
																		$currentIndexPage + 1, 
																		$pageSize);
		
		$totRows = $linkedAuthorities['TotRows'];
		unset($linkedAuthorities['TotRows']);
		
		foreach ($linkedAuthorities as $linkLabel => $links)
			$linkList = array_merge($linkList, $links);

		$this->AuthGrid->setDataSource($linkList);
		$this->AuthGrid->VirtualItemCount = $totRows;
		$this->AuthGrid->dataBind();
		$this->AuthCounter->setText($totRows);
		
		return;
		
		
//		$this->SBNAuthSyncColumn->setVisible($this->_sbnMod->getEnabled());
//		$manId = $this->_manifestation->getManifestationId();
//		
//		$lAuthLists = LAuthorityManifestationQuery::create()
//						->filterByManifestationId($manId)
//						->joinAuthority()
//						->orderByLinkType()
//						->setFormatter(ModelCriteria::FORMAT_ON_DEMAND)
//						->find();
//		
//		$authGridDS = array();
//		
//		/* @var $lAuth LAuthorityManifestation */
//		foreach ($lAuthLists as $lAuth)
//		{
//			$a = $lAuth->getAuthority();
//			if ($a instanceof Authority)
//			{
//				$row['FullText'] = str_replace('<', '&lt;', $a->getFullText());
//				$a->clearAllReferences(true);
//			}
//			else
//			{
//				$row['FullText'] = 'nessuna authority';
//			}
//			
//			$row['AuthId'] = $lAuth->getAuthorityId();
//			$row['LinkType'] = LookupValuePeer::getLookupValue('LINKTYPE', $lAuth->getLinkType());
//			$row['LinkTypeIndex'] = $lAuth->getLinkType();
//			$row['RelatorCodeValue'] = $lAuth->getRelatorCode();
//			$row['RelatorCode'] = LookupValuePeer::getLookupValue('RELATORCODE', $row['RelatorCodeValue']);
//			$row['LinkNote'] = $lAuth->getLinkNote();
//			$row['LinkClass'] = get_class($lAuth);
//			$row['DataKey'] = $row['AuthId'] . '-' . $manId . '-' . $lAuth->getLinkType() . '-' . $row['RelatorCodeValue'];
//			$authGridDS[] = $row;
//			$lAuth->clearAllReferences(true);
//			
//			unset($lAuth);
//		}
//		
//		$this->AuthGrid->setDataSource($authGridDS);
//		$this->AuthGrid->dataBind();
	}
	
	public function onAuthLinkEdit($sender, $param)
	{
		$item = $param->Item;
		$this->AuthGrid->EditItemIndex = $item->ItemIndex;
		$this->bindAuthGrid();
	}

	public function onAuthLinkUpdate($sender, $param)
	{
		$item = $param->Item;

		list($authid, $linkedAuthId, $oldLinkType, $oldRelatorCode) = explode('|', $this->AuthGrid->DataKeys[$item->ItemIndex]);
		$oldLink = LAuthorityQuery::create()
						->findPk(array((int)$authid, (int)$linkedAuthId, $oldLinkType, $oldRelatorCode));

		if ($oldLink instanceof LAuthority)
		{
			$newLinkType = $item->LinkTypeColumn->LinkTypeDropdownList->getSelectedValue();
			$linkTypeChangedFlag = ($newLinkType != $oldLinkType);

			$newRelatorCode = $item->RelatorCodeColumn->RelatorCodeDropdownList->getSelectedValue();
			$relatorCodeChangedFlag = ($newRelatorCode != $oldRelatorCode);
			
			$newNote = trim($item->NoteColumn->NoteTextBox->getSafeText());
			$oldNote = $oldLink->getLinkNote();
			$noteChangedFlag = ($newNote != $oldNote);
			
			$newSeq = trim($item->SeqColumn->SeqTextBox->getSafeText());
			$oldSeq = $oldLink->getLinkSequence();
 			$seqChangedFlag = ($newSeq != $oldSeq);
			
			if ($relatorCodeChangedFlag
					|| $linkTypeChangedFlag
					|| $noteChangedFlag
					|| $seqChangedFlag)
			{
				$newLink = new LAuthority();
				
				$newLink->setAuthorityIdDown($authid);
				$newLink->setAuthorityIdUp($linkedAuthId);
				
				$newLink->setLinkType($linkTypeChangedFlag ? $newLinkType : $oldLinkType);
				$newLink->setRelatorCode($relatorCodeChangedFlag ?$newRelatorCode : $oldRelatorCode);

				$newLink->setLinkSequence($seqChangedFlag ? $newSeq : $oldSeq);				
				$newLink->setLinkNote($noteChangedFlag ? $newNote : $oldNote);	
				
				try
				{
					$oldLink->delete();
					$newLink->save();

					$linkedAuth = $oldLink->getAuthorityRelatedByAuthorityIdDown();

					if (($linkedAuth->getBidSource() == 'SBN')
							&& $linkedAuth->getBid())
						$this->SBNActions->updateLinkToSBN('Update', $newLink);

					$authId = $newLink->getAuthorityIdUp();
					$linkedAuthId = $newLink->getAuthorityIdDown();

					ChangelogPeer::logAction(	$this->authority, 
												ChangelogPeer::LOG_UPDATE, 
												$this->getUser(), 
												'Modificato legame fra authority (id = ' . $authId . ')'
													. ' e authority (id = ' . $linkedAuthId . ')',
												$authId);

					$this->getPage()->writeMessage(Prado::localize("Modificato legame fra authority (id = {id}) e authority (id = {lId})",
															array(	'id' => $authId,
																	'lId' => $linkedAuthId )),
														ClavisMessage::CONFIRM);
				}
				catch (Exception $e)
				{
					$this->getPage()->writeMessage(Prado::localize('Modifica legame authority-authority fallito:') . " " . $e, 
														ClavisMessage::ERROR);
					
				}
			}
			else
			{
				$this->getPage()->writeMessage(Prado::localize("Nessun dato modificato"),
													ClavisMessage::INFO);
			}	
		}
		else
		{
			$this->getPage()->writeMessage(Prado::localize("Errore su tentativo di modifica dell'authority collegata: non esiste più il record corrispondente alla chiave '{key}'. Riportare al fornitore del software",
																array('key' => $this->AuthGrid->DataKeys[$item->ItemIndex])),
												ClavisMessage::ERROR);
		}
		
		$this->AuthGrid->EditItemIndex = -1;
		$this->bindAuthGrid();
	}

	public function onAuthLinkCancel($sender, $param)
	{
		$this->AuthGrid->EditItemIndex = -1;
		$this->bindAuthGrid();
	}
	
	public function onAuthItemDataBound($sender, $param)
	{
		$item = $param->Item;
		
		if ($item->ItemType == 'EditItem')
		{
			$authority = AuthorityQuery::create()->findPk($item->DataItem['AuthorityId']);
			list($linkTypes, $relatorCodes) = $this->calculateLinkTypeRelatorCode($authority, $this->authority, false);
			list($sequence, $note) = $this->calculateSequenceNote($item->DataItem['AuthorityId'], $this->authority->getAuthorityId());

			$item->Cells[1]->LinkTypeDropdownList->setDataSource($linkTypes);
			$item->Cells[1]->LinkTypeDropdownList->dataBind();
			$item->Cells[1]->LinkTypeDropdownList->setSelectedValue($item->DataItem['LinkType']);
			
			if (count($relatorCodes) > 0)
			{
				$item->Cells[2]->RelatorCodeDropdownList->setEnabled(true);
				$item->Cells[2]->RelatorCodeDropdownList->setDataSource($relatorCodes);
				$item->Cells[2]->RelatorCodeDropdownList->dataBind();
				$item->Cells[2]->RelatorCodeDropdownList->setSelectedValue($item->DataItem['RelatorCodeIndex']);
			}
			else
			{
				$item->Cells[2]->RelatorCodeDropdownList->setEnabled(false);
			}
			
			$item->Cells[3]->SeqTextBox->setText($sequence);
			$item->Cells[4]->NoteTextBox->setText($note);
		}
	}
	
	public function onCleanList($sender, $param)
	{
		$this->TypeFilter->setSelectedIndex(-1);
		$this->SubtypeFilter->setSelectedIndex(-1);
		$this->LinkTypeFilter->setSelectedIndex(-1);
		$this->RelatorCodeFilter->setSelectedIndex(-1);
		$this->FilterFullText->setText("");
		
		$this->onFilterList($sender, $param);
	}
	
	public function onNewAuth($sender, $param)
	{
		//$this->populateLinkDropDown(null);
		$authority = null;
		$authorityId = intval($this->AuthorityID->getValue());
		
		if ($authorityId > 0)
			$authority = AuthorityQuery::create()->findPk($authorityId);
		
		if ($authority instanceof Authority)
			$this->populateDropDowns($authority);
		
		/* correctly update params for Create */
		$this->NewAuthOnTheFly->setParam($this->NewAuthLink->getText());
		$this->authLinkTypeChanged($sender, $param);
	}

	public function authLinkTypeChanged($sender, $param)
	{
		switch ($this->LinkType->getSelectedValue())
		{
			case '616':
				$val = AuthorityPeer::TYPE_TRADEMARK;
				break;
			
			case '620':
				$val = AuthorityPeer::TYPE_PUBPLACE;
				break;
			
			case '676':
				$val = AuthorityPeer::TYPE_CLASS;
				break;
			
			case '500':
				$val = AuthorityPeer::TYPE_WORK;
				break;
			
			case '921':
				$val = AuthorityPeer::TYPE_PRINTERSDEVICE;
				break;
			
			case '700': 
			case '702': 
			case '701':
				$val = AuthorityPeer::TYPE_PERSONALNAME;
				break;
			
			default:
				$val = AuthorityPeer::TYPE_SUBJECT;
				break;
		}
		
		$this->NewAuthPanel->render($param->getNewWriter());
		$this->NewAuthOnTheFly->setObjectType($val);
		$this->NewAuthOnTheFly->render($param->getNewWriter());
	}
	
	public function onGotoStackedAuthority($sender, $param)
	{
		/** @var $this->authority Authority */
		
		$authorityId = $this->authority->getAuthorityId();

		if (($authorityId > 0))
		{
			$this->getParent()->getParent()->getParent()->onSave($sender, $param);

			$newAuthorityId = $this->doCreateNewAuthority(trim($this->NewAuthLink->getSafeText()));
			
			if ($newAuthorityId > 0)
			{	
				if (ClavisBase::isEmptyObjectStack())
					ClavisBase::pushEditObjectStack(	Clavisbase::EDITOBJECTSSTACK_TYPEAUTHORITY,
														$authorityId,
														$this->authority->getCompleteText());

				ClavisBase::pushEditObjectStack(	Clavisbase::EDITOBJECTSSTACK_TYPEAUTHORITY,
													$newAuthorityId,
													AuthorityQuery::create()->findPk($newAuthorityId)->getCompleteText());
				
				$this->getPage()->enqueueMessage(Prado::localize("Modifica dell'authority con id={id} messa in attesa",
																	array('id' => $authorityId)),
												ClavisMessage::INFO);

				$this->getPage()->flushDelayedMessage();
				
				$this->getPage()->gotoPage(	'Catalog.AuthorityEditPage',
											array(	'id' => $newAuthorityId));
			}
			else
			{
				$this->getPage()->writeMessage(Prado::localize('Nuova authority non creata'), 
												ClavisMessage::ERROR);

				return false;
			}
		}
	}
	
	private function doCreateNewAuthority($newTitle = "")
	{
		$newAuthorityId = null;
		
		try
		{
			$newAuthority = new Authority();
			$newAuthority->setAuthorityStatus(null);
			
			$newAuthority->setAuthorityCodLevel(05);
			$tm = TurboMarc::createRecord();

			$f101 = $tm->addField('101');
			$f101->addSubField('a', 'ita');
			///$tm->setTitle(Prado::localize($newTitle));
			$newAuthority->setUnimarc($tm->asXML());
			
			if ($newTitle == "")
				$newTitle = "Nuova authority";
						
			$newAuthority->setSortText($newTitle);

			$newAuthority->save();
			
			ChangelogPeer::logAction(	$newAuthority, 
										ChangelogPeer::LOG_CREATE, 
										$this->getUser(), 
										'Nuova authority creata');
			
			$url = Prado::getApplication()->getService()->constructUrl(	'Catalog.AuthorityViewPage',
																		array('id' => $newAuthority->getAuthorityId()));
			
			$newAuthData = "'<a href='" . $url . "'>" . $newAuthority->getCompleteText() . "</a>'";
			
			$this->getPage()->enqueueMessage(Prado::localize('Authority creata: {newauth}. Procedere alla catalogazione ...',
																array('newauth' => $newAuthData)),
												ClavisMessage::CONFIRM);
			
			$newAuthorityId = $newAuthority->getAuthorityId();
		}
		catch (Exception $e)
		{
			Prado::log('Exception: ' . $e->getMessage());
			
			$this->getPage()->writeMessage(Prado::localize('Errore durante la creazione di una nuova authority: ') . $e->getMessage(),
											ClavisMessage::ERROR);
		}

		return $newAuthorityId;
	}
	
}