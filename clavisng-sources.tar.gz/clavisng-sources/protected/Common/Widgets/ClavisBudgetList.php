<?php
/**
 * ClavisBudgetList
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @copyright Copyright &copy; 2010 Comperio srl
 * @version 2.7
 * @package Widgets
 * @since 2.2
 */
class ClavisBudgetList extends TTemplateControl
{
	protected $_library;

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsPostBack())
		{
			$libraries = LibraryPeer::getLibrariesHashWithBlank(true, true); // only active and only internal

			$this->LibraryFilter->setDataSource($libraries);
			$this->LibraryFilter->setSelectedValue($this->getUser()->getActualLibraryId());
			$this->LibraryFilter->dataBind();
			$this->populateBudgetGrid();
		}
	}

	public function searchBudget($sender, $param)
	{
		$this->BudgetGrid->setCurrentPage(0);
		$this->resetSorting();

		$this->populate();
	}

	public function calculateSortingCriteria(&$sortingCriteria = null)
	{
		$sortingExpression = $this->BudgetGrid->getSortingExpression();
		$sortingDirection = $this->BudgetGrid->getSortingDirection();

		if (!$sortingCriteria instanceof Criteria)
			$sortingCriteria = new Criteria();

		switch ($sortingExpression)
		{
			case 'title':
				$sortingCriteria->clearOrderByColumns();
				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
					$sortingCriteria->addAscendingOrderByColumn(BudgetPeer::BUDGET_TITLE);
				else
					$sortingCriteria->addDescendingOrderByColumn(BudgetPeer::BUDGET_TITLE);
				break;

			case 'year':
				$sortingCriteria->clearOrderByColumns();
				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
					$sortingCriteria->addAscendingOrderByColumn(BudgetPeer::BUDGET_YEAR);
				else
					$sortingCriteria->addDescendingOrderByColumn(BudgetPeer::BUDGET_YEAR);
				break;

			case 'startValidity':
				$sortingCriteria->clearOrderByColumns();
				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
					$sortingCriteria->addAscendingOrderByColumn(BudgetPeer::START_VALIDITY);
				else
					$sortingCriteria->addDescendingOrderByColumn(BudgetPeer::START_VALIDITY);
				break;

			case 'endValidity':
				$sortingCriteria->clearOrderByColumns();
				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
					$sortingCriteria->addAscendingOrderByColumn(BudgetPeer::END_VALIDITY);
				else
					$sortingCriteria->addDescendingOrderByColumn(BudgetPeer::END_VALIDITY);
				break;

			default:
				$sortingCriteria->clearOrderByColumns();
				$sortingDirection = !$sortingDirection;
				$sortingCriteria->addDescendingOrderByColumn(BudgetPeer::DATE_CREATED);
				break;
		}
	}

	public function populate()
	{
		$this->populateBudgetGrid();
	}

	private function populateBudgetGrid()
	{
		$pageSize = $this->BudgetGrid->getPageSize();
		$currentIndexPage = $this->BudgetGrid->getCurrentPage();

		$filterLib = $this->LibraryFilter->getSelectedValue();
		if ($this->getLibrary() instanceof Library)
		{
			$this->LibraryColumn->setVisible(false);
			$filterLib = $this->_library->getLibraryId();
		}

		$c = new Criteria();

		if ($filterLib > 0)
			$c->add(BudgetPeer::LIBRARY_ID, $filterLib);

		if ($this->BudgetNameFilter->getText() != '')
			$c->add(BudgetPeer::BUDGET_TITLE, $this->BudgetNameFilter->getSafeText());

		$recCount = BudgetPeer::doCount($c);
		$this->BudgetGrid->setVirtualItemCount($recCount);
		$this->FoundNumber->setText($recCount);

		$c->setLimit($pageSize);
		$c->setOffset($currentIndexPage * $pageSize);

		$this->calculateSortingCriteria($c);
		$budgets = BudgetPeer::doSelect($c);

		$dataSource = array();
		foreach ($budgets as $budget)
		{
			/** @var $budget Budget */
			$row = array();

			$row['BudgetId'] = $budget->getBudgetId();
			$row['BudgetTitle'] = $budget->getBudgetTitle();
			$row['LibraryLabel'] = $budget->getLibraryLabel();
			$row['LibraryId'] = intval($budget->getLibraryId());
			$row['BudgetYear'] = $budget->getBudgetYear();
			$row['StartValidity'] = $budget->getStartValidity('U');
			$row['EndValidity'] = $budget->getEndValidity('U');
			$row['TotalAmount'] = $budget->getTotalAmount();

			$invoicedCombo = $budget->getInvoicedCombo();

			if (array_key_exists("RestAllocated", $invoicedCombo))
				$restAllocated = $invoicedCombo["RestAllocated"];
			else
				$restAllocated = 0;

			if (array_key_exists("RestInvoiced", $invoicedCombo))
				$restInvoiced = $invoicedCombo["RestInvoiced"];
			else
				$restInvoiced = 0;

			$row['RestAllocated'] = $restAllocated;
			$row['RestInvoiced'] = $restInvoiced;

			$dataSource[] = $row;
		}

		$this->BudgetGrid->setDataSource($dataSource);
		$this->BudgetGrid->dataBind();
	}

	public function changePage($sender, $param)
	{
		$this->BudgetGrid->setCurrentPage($param->NewPageIndex);
		$this->populate();
	}

	public function getPopupFlag()
	{
		return $this->getPage()->IsPopup();
	}

	public function setLibrary(Library $library)
	{
		$this->_library = $library;
		$this->setControlState('library', $library, null);
	}

	public function getLibrary()
	{
		if (!$this->_library instanceof Library)
			$this->_library = $this->getControlState('library', null);
		return $this->_library;
	}

	public function resetSorting()
	{
		$this->BudgetGrid->resetSorting('', null, false);
	}

	public function onColorize($sender, $param)
	{
		$item = $param->Item;

		if ($item->ItemType == 'Item' || $item->ItemType == 'AlternatingItem')
		{
			$restAllocated = $item->DataItem['RestAllocated'];
			$restInvoiced = $item->DataItem['RestInvoiced'];

			if (($restAllocated <= 0) || ($restInvoiced <= 0))
				$item->setCssClass('evidenced_lightred');
		}
	}
	
}