<?php
/**
 * ClavisCoordinatedPurchaseList class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 ePortal Technologies
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Widgets
 */

/**
 * ClavisCoordinatedPurchaseList Class
 *
 * This component visualizes a datagrid with coordinate purchases of item
 * through orders of manifestations.
 * Its purpose is to see what other librarians (in other biblios)
 * are ordering, and the numbers.
 * And here we can modify, for a proposed manifestation, the number of items we want
 * to order.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.7
 * @package Widgets
 * @since 2.5.0
 */
class ClavisCoordinatedPurchaseList extends TTemplateControl
{
	private $_checked;
	protected $_loanmanager;
	private $_datasource;
	private $_datasourceSessionName;
	private $_checkedSessionName;
	private $_globalCriteriaSessionName;
	
	private function initVars()
	{
		$uniqueId = $this->getUniqueID();
		$this->_datasourceSessionName = "datasourceSessionName" . $uniqueId;
		$this->_checkedSessionName = "CheckedSessionName" . $uniqueId;
		$this->_globalCriteriaSessionName = "GlobalCriteriaSessionName" . $uniqueId;

		$this->_loanmanager = $this->getApplication()->getModule('loan');
		$this->_datasource = $this->getDatasource();
	}

	public function onInit($param)
	{
		parent::onInit($param);
		$this->initVars();
	}

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallBack())
			$this->resetDatasource(false);	// don't populate, the first page cycle
	}

 	public function setShelfId($param = null)
 	{
 		$this->setViewState('ShelfIdParameter', $param, null);
 	}

 	public function getShelfId()
 	{
 		return $this->getViewState('ShelfIdParameter', null);
 	}

 	public function setWithRequest($param = false)
 	{
 		$this->setViewState('WithRequestParameter', $param, false);
 	}

 	public function getWithRequest()
 	{
 		$value = $this->getViewState('WithRequestParameter', false);
		if (is_string($value))
			$value = ($value === 'true') ? true : false;
		return $value;
 	}

 	public function setVirgin($param = false)
 	{
 		$this->setViewState('VirginParameter', $param, false);
 	}

 	public function getVirgin()
 	{
 		$value = $this->getViewState('VirginParameter', false);
		if (is_string($value))
			$value = ($value === 'true') ? true : false;
		return $value;
 	}

	public function setDoubleCounterViewMode($mode = true)
	{
		$this->setViewState("doubleCounterView", $mode, true);
	}

	public function getDoubleCounterViewMode()
	{
		$value = $this->getViewState('doubleCounterView', true);
		if (is_string($value))
			$value = ($value === 'true') ? true : false;
		return $value;
	}

	public function resetCheckedItems($state = false)
	{
		$this->setChecked(array('all' => $state));
	}

	public function setChecked($checked = null)
	{
		$this->_checked = $checked;
		$this->getApplication()->getSession()->add($this->_checkedSessionName, $checked);
	}

	public function getChecked()
	{
		$this->_checked = $this->getApplication()->getSession()->itemAt($this->_checkedSessionName);
		return $this->_checked;
	}

	public function setGlobalCriteria($criteria = null)
	{
		$this->setViewState($this->_globalCriteriaSessionName, $criteria, null);
	}

	public function getGlobalCriteria()
	{
		return SerializableCriteria::refreshCriteria(
			$this->getViewState($this->_globalCriteriaSessionName, null));
	}

	/**
	 * Method which resets the datasource (also saves into session
	 * variable), the checked status, and re-populates everything.
	 *
	 * @param $populate
	 */
	public function resetDataSource($populate = true)
	{
		$this->resetCheckedItems();
		$this->initDatasource();
		$this->resetSorting();
		$this->resetPagination();

		if ($populate)
			$this->populate();
	}

	public function resetSorting()
	{
		$this->Grid->resetSorting('', null, false);
	}

	public function getDatasource()
	{
		$this->_datasource = $this->getApplication()->getSession()->itemAt($this->_datasourceSessionName);
		return $this->_datasource;
	}

	public function setDatasource($value = null)
	{
		$this->_datasource = $value;
		$this->getApplication()->getSession()->add($this->_datasourceSessionName, $this->_datasource);
	}

	public function initDatasource()
	{
		$this->setDatasource(array());
	}

	public function getItemsWithDueDate($force = false, $reset = false)
	{
		$checked = $this->getChecked();
		$dueDate = $this->getDueDate();

		$masterChecked = $checked['all'];
		unset($checked['all']);
		$checkedIds = array_keys($checked);
		$output = array();
		$outputItemId = array();

		if (!$masterChecked)
			$outputItemId = $checkedIds;
		else         // caso del mastercheck inverso
		{
			$criteria = $this->getGlobalCriteria();
			if (!is_null($criteria) && ($criteria instanceof Criteria))
			{
				$criteria->add(ItemPeer::ITEM_ID, $checkedIds, Criteria::NOT_IN);
				$items = ItemPeer::doSelect($criteria);

				foreach ($items as $item)
					$outputItemId[] = $item->getItemId();
			}
		}

		$output = array();
		if (isset($criteria))
			$criteria->clear();
		else
			$criteria = new Criteria();
		$criteria->add(ItemPeer::ITEM_ID, $outputItemId, Criteria::IN);

		$this->calculateSortingCriteria($criteria);
		$itemsArray = ItemPeer::doSelect($criteria);
		foreach ($itemsArray as $item)
		{
			$itemId = $item->getItemId();
			if (array_key_exists($itemId, $dueDate))
				$dueDateOutput = $dueDate[$itemId];
			else
				$dueDateOutput = $this->_loanmanager->CalculateDueDate($item);

			$output[] = array(	'item' => $item,
								'dueDate' => $dueDateOutput );
		}

		if ((count($output) == 0) && ($force == true))
		{
			$this->resetCheckedItems(true);
			$output = $this->getItemsWithDueDate();
			if ($reset)
				$this->resetCheckedItems(false);
		}

		return $output;
	}

	public function getCheckedItemsItemId($force = false, $reset = false)
	{
		$checked = $this->getChecked();
		//$dueDate = $this->getDueDate();

		$masterChecked = $checked['all'];
		unset($checked['all']);
		$checkedIds = array_keys($checked);
		$outputItemId = array();

		if (!$masterChecked)
		{
			$outputItemId = $checkedIds;
		}
		else         // caso del mastercheck inverso
		{
			$criteria = $this->getGlobalCriteria();
			if (!is_null($criteria) && ($criteria instanceof Criteria))
			{
				$criteria->add(ItemPeer::ITEM_ID, $checkedIds, Criteria::NOT_IN);
				$items = ItemPeer::doSelect($criteria);

				foreach ($items as $item)
					$outputItemId[] = $item->getItemId();
			}
		}

		if ((count($outputItemId) == 0) && ($force == true))
		{
			$this->resetCheckedItems(true);
			$outputItemId = $this->getCheckedItemsItemId();
			if ($reset)
				$this->resetCheckedItems(false);
		}

		return $outputItemId;
	}

	/**
	 * Retrieves the ITEM ID for the selected items.
	 *
	 * @param <type> $force
	 * @param <type> $reset
	 * @return <type>
	 */
	public function getCheckedItemsLoanId($force = false, $reset = false)
	{
		$checked = $this->getChecked();
		$masterChecked = $checked['all'];
		unset($checked['all']);
		$checkedIds = array_keys($checked);

		$output = array();
		$criteria = new Criteria();
		if (!$masterChecked) 
		{
			$criteria->add(ItemPeer::ITEM_ID, $checkedIds, Criteria::IN);
		}
		else      // caso del mastercheck inverso
		{
			$globalCriteria = $this->getGlobalCriteria();
			if ($globalCriteria instanceof Criteria)
			{
				$criteria = $globalCriteria;
				$criteria->add(ItemPeer::ITEM_ID, $checkedIds, Criteria::NOT_IN);
			}
			else if (is_array($globalCriteria) && (count($globalCriteria) > 0))
				$criteria->add(ItemPeer::ITEM_ID, $globalCriteria, Criteria::IN);
		}

		$criteria->clearSelectColumns()->addSelectColumn(ItemPeer::CURRENT_LOAN_ID);
		$output = ItemPeer::doSelectStmt($criteria)->fetchAll(PDO::FETCH_COLUMN,0);

		if ((count($output) == 0) && ($force == true))
		{
			$this->resetCheckedItems(true);
			$output = $this->getCheckedItemsLoanId();
			if ($reset)
				$this->resetCheckedItems(false);
		}

		return $output;
	}

	public function countCheckedItems($force = false, $reset = false)
	{
		$checked = $this->getChecked();
		$masterChecked = $checked['all'];
		unset($checked['all']);
		$checkedIds = array_keys($checked);
		$output = 0;

		if (!$masterChecked) 
		{
			$output = count($checkedIds);
		}
		else       // caso del mastercheck inverso
		{
			$globalCriteria = $this->getGlobalCriteria();
			if ($globalCriteria instanceof Criteria)
			{
				if (count($checkedIds) > 0)
					$globalCriteria->add(ItemPeer::ITEM_ID, $checkedIds, Criteria::NOT_IN);
				$output = ItemPeer::doCount($globalCriteria);

			} 
			else if (is_array($globalCriteria)) 
			{
				$output = count($globalCriteria);
			}
		}

		if (($output == 0) && ($force == true))
		{
			$this->setMasterChecked(true);
			$output = $this->countCheckedItems();

			if ($reset)
				$this->setMasterClass(false);
		}

		return $output;
	}

	public function getSortingExpression()
	{
		return $this->Grid->getSortingExpression();
	}

	public function getSortingDirection()
	{
		return $this->Grid->getSortingDirection();
	}

	public function calculateSortingCriteria(&$sortingCriteria = null)
	{
		$sortingExpression = $this->getSortingExpression();
		$sortingDirection = $this->getSortingDirection();

		if (is_null($sortingCriteria) || !($sortingCriteria instanceof Criteria))
			$sortingCriteria = new Criteria();

		switch ($sortingExpression)
		{
			case 'title':
				$sortingCriteria->clearOrderByColumns();
				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
					$sortingCriteria->addAscendingOrderByColumn(ItemPeer::TITLE);
				elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
					$sortingCriteria->addDescendingOrderByColumn(ItemPeer::TITLE);
				break;

			case 'PatronColumn':
				$sortingCriteria->clearOrderByColumns();
				if (!$this->getExtraSystem())
				{
					$sortingCriteria->addJoin(ItemPeer::PATRON_ID, PatronPeer::PATRON_ID, 'LEFT JOIN');
					if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
					{
						$sortingCriteria->addAscendingOrderByColumn(PatronPeer::LASTNAME);
						$sortingCriteria->addAscendingOrderByColumn(PatronPeer::NAME);
					}
					elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
					{
						$sortingCriteria->addDescendingOrderByColumn(PatronPeer::LASTNAME);
						$sortingCriteria->addDescendingOrderByColumn(PatronPeer::NAME);
					}
				}
				else
				{
					$sortingCriteria->addJoin(ItemPeer::EXTERNAL_LIBRARY_ID, LibraryPeer::LIBRARY_ID, 'LEFT JOIN');
					if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
						$sortingCriteria->addAscendingOrderByColumn(LibraryPeer::LABEL);
					elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
						$sortingCriteria->addDescendingOrderByColumn(LibraryPeer::LABEL);
				}

				break;

			case 'libraryId':

				$loanStatuses = $this->getLoanStatusMode();

				if ($this->_loanmanager->IsOutStatus($loanStatuses))
				{
					$sortingCriteria->clearOrderByColumns();
					$sortingCriteria->addJoin(ItemPeer::DELIVERY_LIBRARY_ID, LibraryPeer::LIBRARY_ID);
					if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
						$sortingCriteria->addAscendingOrderByColumn(LibraryPeer::LABEL);
					elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
						$sortingCriteria->addDescendingOrderByColumn(LibraryPeer::LABEL);
				}

				elseif (in_array(ItemPeer::LOANSTATUS_TOSHELF, $loanStatuses))
				{
					$sortingCriteria->clearOrderByColumns();

					$sortingCriteria->addJoin(LibraryPeer::LIBRARY_ID, ItemPeer::ACTUAL_LIBRARY_ID);
					$sortingCriteria->setDistinct();
					if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
						$sortingCriteria->addAscendingOrderByColumn(LibraryPeer::LABEL);
					elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
						$sortingCriteria->addDescendingOrderByColumn(LibraryPeer::LABEL);
				}

				elseif ($this->_loanmanager->IsInStatus($loanStatuses))
				{
					$sortingCriteria->clearOrderByColumns();

					$sortingCriteria->addJoin(LoanPeer::LOAN_ID, ItemPeer::CURRENT_LOAN_ID);
					$sortingCriteria->addJoin(LoanPeer::FROM_LIBRARY, LibraryPeer::LIBRARY_ID);
					$sortingCriteria->setDistinct();
					if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
						$sortingCriteria->addAscendingOrderByColumn(LibraryPeer::LABEL);
					elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
						$sortingCriteria->addDescendingOrderByColumn(LibraryPeer::LABEL);
				}

				break;

			case 'illTimeStamp':
				$sortingCriteria->clearOrderByColumns();
				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
					$sortingCriteria->addAscendingOrderByColumn(ItemPeer::ILL_TIMESTAMP);
				elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
					$sortingCriteria->addDescendingOrderByColumn(ItemPeer::ILL_TIMESTAMP);
				break;

			case 'lastSeen':  // ultimo movimento
				$sortingCriteria->clearOrderByColumns();
				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
					$sortingCriteria->addAscendingOrderByColumn(ItemPeer::LAST_SEEN);
				elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
					$sortingCriteria->addDescendingOrderByColumn(ItemPeer::LAST_SEEN);
				break;

			case 'collocationCombo':
				$sortingCriteria->clearOrderByColumns();
				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
				{
					$sortingCriteria->addAscendingOrderByColumn(ItemPeer::SECTION);
					$sortingCriteria->addAscendingOrderByColumn(ItemPeer::COLLOCATION);
					$sortingCriteria->addAscendingOrderByColumn(ItemPeer::SPECIFICATION);
					$sortingCriteria->addAscendingOrderByColumn(ItemPeer::SEQUENCE1);
					$sortingCriteria->addAscendingOrderByColumn(ItemPeer::SEQUENCE2);
				}
				elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
				{
					$sortingCriteria->addDescendingOrderByColumn(ItemPeer::SECTION);
					$sortingCriteria->addDescendingOrderByColumn(ItemPeer::COLLOCATION);
					$sortingCriteria->addDescendingOrderByColumn(ItemPeer::SPECIFICATION);
					$sortingCriteria->addDescendingOrderByColumn(ItemPeer::SEQUENCE1);
					$sortingCriteria->addDescendingOrderByColumn(ItemPeer::SEQUENCE2);
				}

				break;

			case null:
				break;

			default:
				$sortingExpression = null;
				break;
		}
	}

	public function populate($selectManifestationId = null, $selectOrderIdParam = null)
	{
		/* @var $item Item */

		$myLibraryId = $this->getUser()->getActualLibraryId();    // actual library
		
		if (!is_null($selectManifestationId) && !is_null($selectOrderIdParam))
		{	
			$selectManifestationId = intval($selectManifestationId);
			$selectOrderIdParam = intval($selectOrderIdParam);
		}
		
		$shelfId = intval($this->getShelfId());
		$shelf = null;
		if ($shelfId > 0)
			$shelf = ShelfQuery::create()->findPk($shelfId);

		if ($shelf instanceof Shelf)
		{
			$pageSize = $this->Grid->getPageSize();
			$currentIndexPage = $this->Grid->getCurrentPage();

			$criteria = new Criteria();
			$criteria->add(ShelfItemPeer::OBJECT_CLASS, ShelfPeer::TYPE_MANIFESTATION_BUY);

			if ($this->getWithRequest())
			{
				$criteria->addJoin(ShelfItemPeer::OBJECT_ID, ItemRequestPeer::MANIFESTATION_ID, Criteria::INNER_JOIN);
				$criteria->add(ItemRequestPeer::REQUEST_STATUS, ItemRequestPeer::STATUS_PENDING);
				$criteria->setDistinct();
			}

			if ($this->getVirgin())
			{
				$criteria->addJoin(ShelfItemPeer::OBJECT_ID, ManifestationPeer::MANIFESTATION_ID, Criteria::LEFT_JOIN);
				$criteria->addJoin(ManifestationPeer::MANIFESTATION_ID, ItemPeer::MANIFESTATION_ID, Criteria::LEFT_JOIN);
				$criteria->add(ItemPeer::MANIFESTATION_ID, null, Criteria::ISNULL);
			}

			$itemShelves = $shelf->extractItemShelves($currentIndexPage, $pageSize, $criteria);
			$recCount = $shelf->countItemShelves($criteria);

			$this->Grid->setVirtualItemCount($recCount);
			$this->FoundNumber->setText($recCount);

			$data = array();

			$criteria->clear();
			$criteria->add(PurchaseOrderPeer::ORDER_STATUS, PurchaseOrderPeer::STATUS_OPEN);
			$criteria->add(PurchaseOrderPeer::LIBRARY_ID, $this->getUser()->getLibraryIds(), Criteria::IN);		// my libraries
			$ordersArray = PurchaseOrderPeer::orders2array($criteria);   // <-------  generale, per tutte le righe

			$ordersIds = array_keys($ordersArray);
			if (array_key_exists(0, $ordersIds))
				$firstOrderId = $ordersIds[0];  // gets the id of first element (purchase_order.order_id)
			else
				$firstOrderId = 0;
			
			$criteria->clear();
			$criteria->add(ItemRequestPeer::REQUEST_STATUS, ItemRequestPeer::STATUS_PENDING);

			$priceManager = $this->getApplication()->getModule('price');
			foreach ($itemShelves as $itemShelf)    // cycle for calculation of grid rows
			{
				$ownedItemsMineNumber = 0;
				$ownedItemsAlienNumber = 0;
				$ownedRequested = 0;

				$ownedItemsMineText = "";
				$ownedItemsAlienText = "";

				$orderedItemsMineText = "";
				$orderedItemsMineNumber = 0;
				$orderedItemsAlienNumber = 0;

				$orderedItemsMineArray = array();
				$orderedItemsAlienArray = array();
				$orderedItemsAlienText = "";

				$ordersArraySubfix = array();
				foreach ($ordersArray as $index => $element)
					$ordersArraySubfix[$index] = 0;

				$row = array();
				$shelfItemPK = $itemShelf->getPackedPK();

				$row['shelfItemPK'] = $shelfItemPK;
				if (isset($this->_checked[$shelfItemPK]))
					$checked = $this->_checked[$shelfItemPK];
				else
					$checked = false;
				if ($this->_checked['all'])
					$checked = !$checked;
				$row['checked'] = $checked;

				$id = $itemShelf->getObjectId();

				$selectOrderId = $firstOrderId;
				if (($selectManifestationId > 0) && ($selectOrderIdParam > 0))
					if ($id == $selectManifestationId)
						$selectOrderId = $selectOrderIdParam;
				$row['SelectedOrderId'] = $selectOrderId;

				$row['Id'] = $id;

				$ean = "";
				$manifestationOL = "";
				$seeUrl = '';
				$descriptionLabel = '--';
				$descriptionText = '';
				$manifestation = ManifestationQuery::create()->findPk($id);
				
				if ($manifestation instanceof Manifestation)
				{
					if ($selectManifestationId > 0)
						$manifestation->reload(true);  // deep

					$ean = $manifestation->getEan();
					$ownedRequested = $manifestation->countItemRequests($criteria);

					$descriptionLabel = "";
					$descriptionText = $manifestation->getShelfDescriptionText();
					$seeUrl = $manifestation->getNavigateUrl($id);

					foreach ($manifestation->getItems() as $item)
					{
						$isMine = ($item->getOwnerLibraryId() == $myLibraryId);
						$itemStatus = $item->getItemStatus();
						$itemOrderStatus = $item->getItemOrderStatus();

						if (in_array($itemStatus, ItemPeer::getItemStatusManageable()))  // <------ owned
						{
							if ($isMine)
							{
								$ownedItemsMineNumber++;
								$ownedItemsMineText .= $item->getCompleteInventoryNumber()
														. " (" . $item->getCollocationCombo() . ")"
														. "<br />";
							}
							else
							{
								$ownedItemsAlienNumber++;
								$ownedItemsAlienText .= $item->getOwnerLibraryLabel()
														. ", " . $item->getCompleteInventoryNumber()
														. " (" . $item->getCollocationCombo() . ")"
														. "<br />";
							}
						}
						elseif ($itemOrderStatus == ItemStatus::ITEMORDERSTATUS_INORDER)    // <------- if in order
						{
							if ($isMine)    /// appendo ordini
							{
								$orderedItemsMineNumber++;

								$orderTitle = $item->getOrderTitle();
								if (!array_key_exists($orderTitle, $orderedItemsMineArray))
									$orderedItemsMineArray[$orderTitle] = 1;
								else
									$orderedItemsMineArray[$orderTitle]++;

								$orderId = intval($item->getOrderId());
								if (($orderId > 0) && array_key_exists($orderId, $ordersArray))
									$ordersArraySubfix[$orderId]++;
							}
							else			// appendo nome biblioteca
							{
								$orderedItemsAlienNumber++;
								$orderTitle = $item->getOrderTitle();
								$libraryLabel = $item->getOwnerLibraryLabel();

								if (array_key_exists($libraryLabel, $orderedItemsAlienArray))
									$chain = $orderedItemsAlienArray[$libraryLabel];
								else
									$chain = array();

								if (!array_key_exists($orderTitle, $chain))
									$chain[$orderTitle] = 1;
								else
									$chain[$orderTitle]++;

								$orderedItemsAlienArray[$libraryLabel] = $chain;
							}
						}
					}

					if (($author = trim($manifestation->getAuthor())) != "")
							$manifestationOL = $author;

					$tm = $manifestation->getTurboMarc();
					$title = htmlentities($tm->getFullTitle(), ENT_COMPAT, 'UTF-8');
					if (trim($title) != "")
						$manifestationOL .= ($manifestationOL != "" ? "<br />" : "") . $title;

					$editions = $tm->getEditions();
					if (count($editions) > 0)
					{
						$editionText = htmlentities(implode('<br />', $editions), ENT_COMPAT, 'UTF-8');
						if (trim($editionText) != "")
							$manifestationOL .= ($manifestationOL != "" ? "<br />" : "") . $editionText;
					}

					$publications = $tm->getPublications();
					if (count($publications) > 0)
					{
						$publicationText = htmlentities(implode('<br />', $publications), ENT_COMPAT, 'UTF-8');
						if (trim($publicationText) != "")
							$manifestationOL .= ($manifestationOL != "" ? "<br />" : "") . $publicationText;
					}

					$desc = $tm->getPhysicalDescs();
					if (count($desc) > 0)
					{
						$descText = htmlentities(implode('<br />', $desc), ENT_COMPAT, 'UTF-8');
						if (trim($descText) != "")
							$manifestationOL .= ($manifestationOL != "" ? "<br />" : "") . $descText;
					}

					$areaText = "";
					foreach ($manifestation->getAreas() as $area)
						$areaText .= Prado::localize(ManifestationPeer::getAreaName($area['field'])) . ": {$area['value']}<br />";
					$areaText = rtrim($areaText, "<br />");
					if (trim($areaText) != "")
						$manifestationOL .= ($manifestationOL != "" ? "<br />" : "") . $areaText;

					$abstract = trim($manifestation->getAbstract());
					if ($abstract != "")
						$manifestationOL .= ($manifestationOL != "" ? "<br />" : "") . $abstract;
				}

				$row['ManifestationOL'] = ($manifestationOL != "" ? $manifestationOL : Prado::localize("dati mancanti"));

				$row['ownedItems'] = "$ownedItemsMineNumber/$ownedItemsAlienNumber/$ownedRequested";

				$ownedItemsMineText = rtrim($ownedItemsMineText, "<br />");
				if ($ownedItemsMineText != "")
					$ownedItemsMineText = Prado::localize("Numero di inventario/collocazione dei miei esemplari:<br /><br />")
											. $ownedItemsMineText;

				$ownedItemsAlienText = rtrim($ownedItemsAlienText, "<br />");
				if ($ownedItemsAlienText != "")
				{
					if ($ownedItemsMineText != "")
						$ownedItemsAlienTextPrefix = "<br /><br /><hr><br />";
					else
						$ownedItemsAlienTextPrefix = "";

					$ownedItemsAlienText = $ownedItemsAlienTextPrefix . Prado::localize("Biblioteca proprietaria, numero di inventario/collocazione degli esemplari non miei:<br /><br />")
											. $ownedItemsAlienText;
				}

				$row['ownedItemsText'] = $ownedItemsMineText . $ownedItemsAlienText;

				$row['orderedItems'] = "$orderedItemsMineNumber/$orderedItemsAlienNumber";

				if (count($orderedItemsMineArray) > 0)
				{
					$orderedItemsMineText = Prado::localize("Già ordinato dalla mia biblioteca negli ordini [quantità]:<br /><br />");

					foreach ($orderedItemsMineArray as $ord => $num)
						$orderedItemsMineText .= $ord . " [" . $num . "]<br />";

					$orderedItemsMineText = rtrim($orderedItemsMineText, '<br />');
				}

				if (count($orderedItemsAlienArray) > 0)
				{
					if ($orderedItemsMineText != "")
						$orderedItemsAlienTextPrefix = "<br /><br /><hr><br />";
					else
						$orderedItemsAlienTextPrefix = "";

					$orderedItemsAlienText = $orderedItemsAlienTextPrefix . Prado::localize("Ordinato da: biblioteca [quantità], ...<br /><br />");

					ksort($orderedItemsAlienArray);
					foreach ($orderedItemsAlienArray as $libraryLabel => $inner)
					{
						if (count($inner) > 0)
							$orderedItemsAlienText .= "$libraryLabel: ";

						$orderedItemsAlienText .= " [" . array_sum($inner) . "]<br />";
					}
					$orderedItemsAlienText = rtrim($orderedItemsAlienText, "<br />");
				}

				$row['orderedItemsText'] = $orderedItemsMineText . $orderedItemsAlienText;

				$ordersFormattedArray = array();
				foreach ($ordersArray as $index => $element)
					$ordersFormattedArray[$index] = $ordersArray[$index] . ($ordersArraySubfix[$index] > 0
																				? " [$ordersArraySubfix[$index]]"
																				: "");
				$row['orders'] = $ordersFormattedArray;

				$row['DescriptionText'] = $descriptionText;
				$row['DescriptionLabel'] = $descriptionLabel;
				$row['SeeUrl'] = $seeUrl;

				//$listPrice = $priceManager->getListPrice($ean);
				$listPrice = '';
				if ($manifestation instanceof Manifestation)
					$listPrice = $priceManager->getManifestationListPrice($manifestation);
				
				$row['Price'] = $listPrice;

				$priceDiscountArray = array();
				$priceDiscountFormatted = "";
				foreach ($ordersIds as $index => $rowId)
				{
					$discount = $priceManager->getSupplierDiscount($rowId);			// getDiscount($ean, $rowId);
					$priceDiscountArray[$rowId] = $discount;
					
					$discountedPrice = $listPrice - $discount;
					if ($discountedPrice < 0)
						$discountedPrice = 0;
					
					$priceDiscountFormatted .= "<span id='" . $id . "-" . $rowId . "' class='" 
												. ($rowId == $selectOrderId ? 'panel_on' : 'panel_off')
												. "'>"
												. ClavisBase::getCurrencySymbol() . " " . ClavisBase::numberFormat($discountedPrice, '#.00')
												. "<br />(" . ClavisBase::getCurrencySymbol() . " " . ClavisBase::numberFormat($discount, '#.00') . ")"
												. "</span>";
				}
				
				$row['PriceDiscountFormatted'] = $priceDiscountFormatted;
				$row['PriceDiscountArray'] = $priceDiscountArray;
//Prado::log('priceDiscountFormatted: '. Prado::varDump($priceDiscountFormatted));
//Prado::log('priceDiscountArray: '. Prado::varDump($priceDiscountArray));
				
				$row['SystemCurrency'] = ClavisParamQuery::getParam('CLAVISPARAM','SystemCurrency');

				$data[] = $row;
			}

			$this->setChecked($this->_checked);
			$this->setDatasource($data);
			$this->Grid->setDataSource($data);
			$this->Grid->dataBind();
		}
		else
		{
			$this->resetCheckedItems();
			$this->initDatasource();
			$this->resetSorting();
			$this->resetPagination();
			$this->Grid->setDataSource(array());
			$this->Grid->dataBind();
		}
	}

	public function setFilters($shelfId = null, $withRequest = false, $virgin = false )
	{
		$shelfId = intval($shelfId);
		if ($shelfId == 0)
			$shelfId = -1;
		$this->setShelfId($shelfId);

		$this->setWithRequest($withRequest);
		$this->setVirgin($virgin);

		$this->resetPagination();
	}

	public function resetPagination()
	{
		$this->Grid->SetCurrentPage(0);
	}

	/**
	 * Are we inside a popup?
	 *
	 * @return boolean
	 */
	public function getPopupFlag()
	{
		return $this->getPage()->IsPopup();
	}

	/**
	 * It changes the status (on/off) of the checkbox of one chosen
	 * row item of datagrid.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onFlipChecked($sender, $param)
	{
		$checked = $this->getChecked();
		$newStatus = $sender->getChecked();

		$index = $sender->Parent->Parent->ItemIndex;
		$dataSource = $this->getDatasource();

		$row = $dataSource[$index];
		$itemId = $row['id'];

		if ($newStatus != $checked['all'])
			$checked[$itemId] = true;
		else
			unset($checked[$itemId]);

		$this->setChecked($checked);
	}

	public function onMasterChecked($sender, $param)
	{
		$newStatus = $sender->getChecked();
		$this->resetCheckedItems($newStatus);

		$gridItems = $this->Grid->getItems();
		foreach($gridItems as $item)
			$item->CheckColumn->Checked->setChecked($newStatus);
	}

	public function setMasterChecked($newChecked = false, $param = null)
	{
		$this->resetCheckedItems($newChecked);
		$gridItems = $this->Grid->getItems();
		$header = $this->Grid->getHeader();

		foreach($gridItems as $item)
			$item->CheckColumn->Checked->setChecked($newChecked);

		$header->CheckColumn->MasterCheck->setChecked($newChecked);
	}

	public function globalRefresh($resetSorting = true, $manifestationId = null, $orderId = null)
	{
		if ($resetSorting)
			$this->resetSorting();

		$this->populate($manifestationId, $orderId);
	}

	public function onModifyOrder($sender, $param)
	{
		$done = false;

		$order = null;
		$orderId = intval($sender->Parent->OpenOrders->getSelectedValue());
		if ($orderId > 0)
			$order = PurchaseOrderQuery::create()->findPk($orderId);

		if (!($order instanceof PurchaseOrder))
		{
			$this->getPage()->writeMessage(Prado::localize('Ordine non valido'), ClavisMessage::ERROR);
			return false;
		}

		$itemIndex = $sender->Parent->Parent->getItemIndex();
		$ds = $this->getDatasource();
		$row = $ds[$itemIndex];

		$manifestation = null;
		$manifestationId = intval($row['Id']);
		if ($manifestationId > 0)
			$manifestation = ManifestationQuery::create()->findPk($manifestationId);

		$price = floatval($row['Price']);
		
		$discountArray = $row['PriceDiscountArray'];
		if (array_key_exists($orderId, $discountArray))
			$discount = $discountArray[$orderId];
		else
			$discount = 0;

		if (!($manifestation instanceof Manifestation))
		{
			$this->getPage()->writeMessage(Prado::localize('Titolo non valido'), ClavisMessage::ERROR);
			return false;
		}

		$myLibraryId = $this->getUser()->getActualLibraryId();

		switch ($sender->getID())    // action
		{
			case 'AddButton':

				/**
				 * It returns the item_id of the newly created item, or 'null' in the case of failure
				 */
				$returnValue = $order->addItemToOrder(	$manifestationId,
														$myLibraryId,
														$price,
														$discount);

				if (intval($returnValue) == 0)    // <---- if failed
				{
					$this->getPage()->writeMessage(Prado::localize("Errore nell'aggiungere il titolo all'ordine '{title}'",
													array('title' => $manifestation->getTitle())), ClavisMessage::ERROR);
					return false;
				}

				ChangelogPeer::logAction($order, ChangelogPeer::LOG_UPDATE, $this->getUser(), "Proposte d'acquisto - aggiunto item id: " . $returnValue);
				
				$this->getPage()->writeMessage(Prado::localize("Titolo '{title}' aggiunto all'ordine '{order}'",
																array(	'title' => $manifestation->getTitle(),
																		'order' => $order->getOrderTitle()) ),
												ClavisMessage::CONFIRM);

				$done = true;
				break;

			case 'SubtractButton':

				/**
				 * It returns the item_id of the just removed orderd item, or 'null' in the case of failure
				 */
				$returnValue = $order->deleteLastItemFromOrder(	$manifestationId,
																$myLibraryId );

				if (intval($returnValue) == 0)    // <---- failed
				{
					$this->getPage()->writeMessage(Prado::localize("Errore nel cancellare il titolo '{title}' dall'ordine '{order}'",
																	array(	'title' => $manifestation->getTitle(),
																			'order' => $order->getOrderTitle())),
													ClavisMessage::ERROR);
					return false;
				}

				ChangelogPeer::logAction($order, ChangelogPeer::LOG_UPDATE, $this->getUser(), "Proposte d'acquisto - rimosso item id: " . $returnValue);
				
				$this->getPage()->writeMessage(Prado::localize("Titolo '{title}' rimosso dall'ordine '{order}'",
																array(	'title' => $manifestation->getTitle(),
																		'order' => $order->getOrderTitle())),
												ClavisMessage::WARNING);

				$done = true;
				break;
		}

		if ($done)
			$this->getPage()->globalRedraw($manifestationId, $orderId);
	}

	public function onChangeDiscount($sender, $param)
	{
		$itemIndex = $sender->Parent->Parent->getItemIndex();
		$ds = $this->getDatasource();
		$row = $ds[$itemIndex];
		
		$manifestationId = intval($row['Id']);
		$orderId = intval($sender->getSelectedValue());
		
		$this->globalRefresh(false, $manifestationId, $orderId);
	}
	
	public function onGotoOrder($sender, $param)
	{
		$order = null;
		$orderId = intval($sender->Parent->OpenOrders->getSelectedValue());
		if ($orderId > 0)
			$order = PurchaseOrderQuery::create()->findPk($orderId);

		if ($order instanceof PurchaseOrder)
		{
			$this->getPage()->gotoPageWithReturn("Acquisition.OrderViewPage", array('id' => $orderId));
			return false;
		}
	}
	
}
