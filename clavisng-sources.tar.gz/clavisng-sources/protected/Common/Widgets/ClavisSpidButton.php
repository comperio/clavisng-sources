<?php

class ClavisSpidButton extends TTemplateControl
{

    public $EnableTest;

    /**
     * https://registry.spid.gov.it/assets/data/idp.json
     */


    /**
     * @param $param
     * @throws THttpException
     */
    public function onPreRender($param)
    {
        parent::onPreRender($param);

        if ($this->getPage()->getClientSupportsJavaScript()) {
            $cs = $this->getPage()->getClientScript();
            $componentBasePath = Clavis::getComponentBasePath('ClavisSpidButton');

            ClavisBase::registerJQuery($cs);
            Clavis::registerStyleSheet($cs, $componentBasePath, ['spid-sp-access-button.min.css']);
            Clavis::registerClientScript($cs, $componentBasePath, ['spid-sp-access-button.min.js', 'spid-button-init.js']);
        }
    }

    public function getImagePath($filename): string
    {
        $componentBasePath = Clavis::getComponentBasePath('ClavisSpidButton');
        $assetUrl = Prado::getApplication()->getAssetManager()->publishFilePath($componentBasePath, false);
        return $assetUrl . "/img/$filename";
    }

    public function addTestIdp()
    {
        $testidp = '';

        if ($this->EnableTest) {
            $imagePath = $this->getImagePath('spid-idp-dummy.svg');
            $testidp = <<<END
<li class="spid-idp-button-link" data-idp="testenv">
            <a href="spid/login?idp=testenv"><span class="spid-sr-only">Test Env</span>
                <img src="$imagePath"
                     onerror="this.src='.$imagePath .'; this.onerror=null;"
                     alt="testenv ID"/>
            </a>
        </li>
END;
        }
        return $testidp;
    }

    public function getEnableTest()
    {
        return $this->EnableTest;
    }

    public function setEnableTest($value)
    {
        $value = TPropertyVAlue::ensureBoolean($value);
        $this->EnableTest = $value;
    }


    public function onLoadComplete($param)
    {
        $this->initSpidButton();
    }

    private function initSpidButtonSmart()
    {
        $ssoDir = realpath(Prado::getPathOfNamespace('SPID'));
        $conf_file = $ssoDir . '/settings.php';
        $settings = file_exists($conf_file) ? include $conf_file : false;
        $cid = $this->getClientID();

        $sp = new Italia\Spid\Sp($settings, null, $autoconfiguration = false);
        $mapping = Clavis::jsEncode($sp->getIdpList());
        $supported = Clavis::jsEncode(array_keys($sp->getIdpList()));

        $this->getPage()->getClientScript()->registerEndScript(
            'Comperio.ClavisSpidButton' . $cid,
            "Comperio.ClavisSpidButton.initsmart($mapping, $supported);"
        );
    }

    private function initSpidButton()
    {
        $cid = $this->getClientID();
        $this->getPage()->getClientScript()->registerEndScript(
            'Comperio.ClavisSpidButton' . $cid,
            "Comperio.ClavisSpidButton.init();"
        );
    }
}