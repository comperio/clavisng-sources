<?php
/**
 * ClavisNotification class
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 * For Commercial Licenses and support please contact Comperio.
 * @author    Dario Rigolin <dario@comperio.it>
 * @author    Marco Brancalion <marco@comperio.it>
 * @author    Ciro Mattia Gonano
 * @link      http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2019 Comperio srl
 * @license   http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version   2.10
 */

/**
 * ClavisNotification Class
 * @author  Mauro Seno <mauro.seno@comperio.it>
 * @version 2.10
 * @package Core
 * @since   2.10
 */
class ClavisNotification extends TTemplateControl
{
	/**
	 * ----- **** TODO
	 * 1) Estendere TBroadCastEventParameter a TBroadcastNotificationEventParameter dove:
	 *  - Controllo che i livelli siano quelli che si aspetta il componente js
	 *  - Posso passare tipologie di notifica differenti (grandi piccole con suono stiky) e controllare la
	 *  correttezza dei parametri passati, eventualmente facendo fallback su un default.
	 * 2) Fare componente javascript dove passare l'array di notifiche e da js fare il dispatch di tutte quante
	 * togliendomi la necessita' di fare molti registerEndScript con rand(0,9999)
	 * 3) Dopo aver fatto 2) verificare se da ancora errore js sulle promise nella console.
	 */

	private $_notificationQueue = null;

	/**
	 * @param $p
	 * @param $param
	 * @throws \THttpException
	 */
	public function onPreRender($param)
	{
		parent::onPreRender($param);

		if ($this->getPage()->getClientSupportsJavaScript()) {
			$cs = $this->getPage()->getClientScript();

			Clavis::registerJQuery($cs);

			Clavis::registerStyleSheet($cs, Clavis::getComponentBasePath('FontAwesome'), [
				'font-awesome.min.css'
			]);

			Clavis::registerStyleSheet($cs, Clavis::getComponentBasePath('ClavisNotification'), [
				'lobibox.min.css',
				'clavis-notification.css'
			]);

			Clavis::registerClientScript($cs, Prado::getPathOfNamespace('Application.Javascript'), [
				'clavis-local-storage.js',
			], '', true);

			Clavis::registerClientScript($cs, Clavis::getComponentBasePath('ClavisNotification'), [
				'notifications.js',
				'clavis-notification.js'
			], 'js', true);
		}

		$this->notify();
	}

	public function onInit($param)
	{
		parent::onInit($param);
		$this->attachEventHandler("onEnqueueNotification", array($this, 'onEnqueueNotification'));
		$this->attachEventHandler("onClearNotificationQueue", array($this, 'onClearNotificationQueue'));

		$this->_notificationQueue = [];

	}

	public function onEnqueueNotification($sender, $params)
	{
		$p = $params->getParameter();
		$this->_notificationQueue[] = $p;
	}

	public function onClearNotificationQueue($sender, $params)
	{
		$this->_notificationQueue = [];
	}

	public function notify()
	{
		$cid = $this->getClientID();
		$jsonParams = json_encode($this->_notificationQueue, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP );
		$jsonParams = str_replace("\u0022","\\\\\"", $jsonParams);

		$this->getPage()->getClientScript()->registerEndScript(
			"Comperio.ClavisNotification" . $cid,
			"Comperio.ClavisNotification.notify('$jsonParams')"
		);
	}
}