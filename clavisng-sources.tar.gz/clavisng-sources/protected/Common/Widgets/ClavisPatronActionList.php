<?php

/**
 * ClavisPatronActionList class
 * 
 * This component visualizes the patron actions which are stored in the
 * databases, related to a patron, into a datagrid.
 *
 * @author Marco Brancalion <mbrancalion@e-portaltech.it>
 * @author Cristian Chiarello <ciarez@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @copyright Copyright &copy; 2009-2015 Comperio srl
 * @version 2.8.2
 * @package Widgets
 * @since 2.8.2
 */
class ClavisPatronActionList extends TTemplateControl
{
	private $_object;
	private $_datasourceSessionName;
	private $_globalCriteriaSessionName;

	private function initVars()
	{
		$uniqueId = $this->getUniqueID();
		$this->_datasourceSessionName = "DatasourceSessionName" . $uniqueId;
		$this->_globalCriteriaSessionName = "GlobalCriteriaSessionName" . $uniqueId;
	}

	public function onInit($param)
	{
		parent::onInit($param);
		$this->initVars();

		$this->NoSearchPanel->setVisible(false);

		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallback())
			$this->resetObject();
	}

	public function onLoad($param)
	{
		parent::onLoad($param);

		$this->getObject();

		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallBack())
		{
			$this->doCancel($this->getAutomaticPopulate(), $param);
		}
	}

	public function setAutomaticPopulate($flag = true)
	{
		if ($flag === "true")
			$flag = true;
		elseif ($flag === "false")
			$flag = false;

		$this->setViewState("automaticPopulate", $flag, true);
	}

	public function getAutomaticPopulate()
	{
		return $this->getViewState("automaticPopulate", true);
	}

	public function getLibrarianId()
	{
		return $this->getViewState("LibrarianId", null);
	}

	public function setLibrarianId($value)
	{
		$this->setViewState("LibrarianId", $value, null);
	}

	public function getLibraryId()
	{
		return $this->getViewState("LibraryId", null);
	}

	public function setLibraryId($value)
	{
		$this->setViewState("LibraryId", $value, null);
	}

	public function setGlobalCriteria($criteria = null)
	{
		$this->setViewState($this->_globalCriteriaSessionName, $criteria, null);
	}

	public function getGlobalCriteria()
	{
		return SerializableCriteria::refreshCriteria(
						$this->getViewState($this->_globalCriteriaSessionName, null));
	}

	public function getDatasource()
	{
		return $this->getApplication()->getSession()->itemAt($this->_datasourceSessionName, null);
	}

	public function setDataSource($value)
	{
		$this->getApplication()->getSession()->add($this->_datasourceSessionName, $value, null);
	}

	public function resetObject()
	{
		$this->setObject(null);
	}

	public function setObject($obj)
	{
		$this->_object = $obj;
		$this->setViewState("object", $obj, null);
	}

	public function getObject()
	{
		$this->_object = $this->getViewState("object", null);
		return $this->_object;
	}

	public function getSortingExpression()
	{
		return $this->Grid->getSortingExpression();
	}

	public function getSortingDirection()
	{
		return $this->Grid->getSortingDirection();
	}

	public function calculateSortingCriteria(&$sortingCriteria = null)
	{
		$sortingExpression = $this->getSortingExpression();
		$sortingDirection = $this->getSortingDirection();

		if (is_null($sortingCriteria) || !($sortingCriteria instanceof Criteria))
			$sortingCriteria = new Criteria();

		switch ($sortingExpression)
		{
			case 'ActionDate':
				$sortingCriteria->clearOrderByColumns();
				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
					$sortingCriteria->addAscendingOrderByColumn(PatronActionPeer::ACTION_DATE);
				elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
					$sortingCriteria->addDescendingOrderByColumn(PatronActionPeer::ACTION_DATE);
				break;

			case null:
				break;

			default:
				$sortingExpression = null;
				break;
		}
	}

	public function populate()
	{
		$this->NoSearchPanel->setVisible(false);

		$pageSize = $this->Grid->getPageSize();
		$currentIndexPage = $this->Grid->getCurrentPage();
		$criteria = new Criteria();

		// begin reading filters
		$actionType = $this->ActionTypeFilter->getSelectedValue();
		if ($actionType != "" && $actionType != "0")
			$criteria->addAnd(PatronActionPeer::ACTION_TYPE, $actionType);

		$dateFrom = $this->DateFrom->getSafeText() != '' ? $this->DateFrom->getTimeStamp() : null;
		$dateTo = $this->DateTo->getSafeText() != '' ? $this->DateTo->getTimeStamp() : null;

		if (!is_null($dateFrom) && ($dateFrom > 0))
			$criteria->addAnd(PatronActionPeer::ACTION_DATE, $dateFrom, Criteria::GREATER_EQUAL);
		if (!is_null($dateTo) && ($dateTo > 0))
			$criteria->addAnd(PatronActionPeer::ACTION_DATE, $dateTo + 86399, Criteria::LESS_EQUAL);
		// end of filters

		$this->Grid->resetSorting('ActionDate', TClavisDataGrid::SORTDIRECTION_DESC, false);

		$this->calculateSortingCriteria($criteria);
		$this->setGlobalCriteria(clone $criteria);

		if ($this->_object instanceof Patron)
		{
			$criteria->addAnd(PatronActionPeer::PATRON_ID, $this->_object->getPatronId());
			$this->PatronColumn->setVisible(FALSE);
		}
		else
		{
			$this->PatronColumn->setVisible(TRUE);
		}

		$recCount = PatronActionPeer::doCount($criteria);

		$criteria->setLimit($pageSize);
		$criteria->setOffset($currentIndexPage * $pageSize);
		$patronActions = PatronActionPeer::doSelect($criteria);

		$data = array();
		foreach ($patronActions as $patronAction)
		{
			$row = array();

			$libraryId = $patronAction->getLibraryId();
			if ($libraryId)
				$library = LibraryPeer::retrieveByPK($libraryId);
			else
				$library = null;

			if ($library instanceof Library)
			{
				$libraryDescription = $library->getDescription();
				$libraryLabel = $library->getLabel();
			}
			else
			{
				$libraryDescription = '';
				$libraryLabel = '';
			}

			$row['LibraryDescription'] = $libraryDescription;
			$row['LibraryLabel'] = $libraryLabel;
			$row['LibraryId'] = $libraryId;



			$librarianId = $patronAction->getModifiedBy();
			if ($librarianId)
				$librarian = LibrarianPeer::retrieveByPK($librarianId);
			else
				$librarian = null;

			if (!is_null($librarian))
				$libraryCompleteName = $librarian->getCompleteName();
			else
				$libraryCompleteName = '';

			$row['LibrarianCompleteName'] = $libraryCompleteName;
			$row['LibrarianId'] = $librarianId;

			$toolTip = '';
			$patron = $patronAction->getPatron();
			if ($patron instanceof Patron)
			{
				$patronCompleteName = $patron->getCompleteName();
				$navigateUrl = $patron->getNavigateUrl() . $patron->getId();
			}
			else
			{
				$externalLibraryId = intval($patronAction->getExternalLibraryId());
				$externalLibrary = LibraryPeer::retrieveByPK($externalLibraryId);
				if (!is_null($externalLibrary))
				{
					$patronCompleteName = $externalLibrary->getLabel(true, false, true, 30);

					$navigateUrl = $externalLibrary->getNavigateUrl() . $externalLibrary->getLibraryId();
					$toolTip = $externalLibrary->getTrimmedDescription(100) . ' (' .
							Prado::localize('consorzio') . ": " . $externalLibrary->getConsortiaString(100) . ')';
				}
				else
				{
					$patronCompleteName = '---';
					$navigateUrl = '';
				}
			}

			$row['patronCompleteName'] = $patronCompleteName;
			$row['patronNavigateUrl'] = $navigateUrl;
			$row['patronNavigateUrlToolTip'] = $toolTip;

			$row['ActionLabel'] = $patronAction->getPatronActionLabel();
			$row['ActionDate'] = $patronAction->getActionDate('U');
			$row['ActionNote'] = $patronAction->getActionNote();
			$row['Id'] = $patronAction->getActionId();
			$data[] = $row;
		}

		$this->writeResults($data, $recCount);
	}

	private function writeResults($data = array(), $recCount = 0)
	{
		$this->RecCounter->setText($recCount);
		$this->Grid->setVirtualItemCount($recCount);
		$this->Grid->setDataSource($data);
		$this->Grid->dataBind();
		$this->setDataSource($data);
	}

	/**
	 * It manages the change of page in the datagrid.
	 * It uses the viewstate to store the current page.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function changePage($sender, $param)
	{
		$this->Grid->setCurrentPage($param->NewPageIndex);
		$this->populate();
		//$this->getPage()->globalRefresh();
	}

	public function globalRefresh()
	{
		$this->populate();
	}

	/**
	 * It returns whether the page permits that in this component
	 * we can have the functions that components inside popups have.
	 *
	 * @return boolean
	 */
	public function getPopupFlag()
	{
		return $this->getPage()->isPopup();
	}

	/**
	 * It returns whether the page permits that in this component
	 * we can have the unlink function.
	 *
	 * @return boolean
	 */
	public function getUnlinkFlag()
	{
		return $this->getPage()->isUnlink();
	}

	/**
	 * It returns whether the page permits that in this component
	 * we can have the delete function.
	 *
	 * @return boolean
	 */
	public function getDeleteFlag()
	{
		return $this->getPage()->isDelete();
	}

	/**
	 * This method, called for unlinking, calls the relative
	 * method of the parent page.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onUnlink($sender, $param)
	{
		$id = $param->CommandParameter;
		$this->getPage()->Unlink($id);
	}

	public function onSearch($sender, $param)
	{
		$this->Grid->SetCurrentPage(0);

		$this->populate();
	}

	public function onCancel($sender, $param)
	{
		$this->doCancel(false, $param);  //(true, $param);
	}

	private function doCancel($doRefresh = true, $param)
	{
		$this->Grid->setCurrentPage(0);

		$this->ActionTypeFilter->setSelectedIndex(-1);

		$this->onResetDate(null, null);

		if ($doRefresh)
			$this->populate();
		else
		{
			$this->writeResults();
			$this->NoSearchPanel->setVisible(true);
		}
	}

	public function onResetDate($sender, $param)
	{
		$this->DateFrom->setText('');
		$this->DateTo->setText('');

		if ($this->getPage()->getIsCallback() && !is_null($param))
			$this->DatePanel->render($param->getNewWriter());
	}
}