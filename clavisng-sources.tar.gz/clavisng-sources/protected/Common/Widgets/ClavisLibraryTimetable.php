<?php

/**
 * ClavisLibraryTimetable class
 * 
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2011 Comperio srl
 * @version 2.7
 * @package Widgets
 * @since 2.4.3
 */

class ClavisLibraryTimetable extends TTemplateControl
{
	public $_dayLength;
	public $_dateFormat;
	public $_shortDateFormat;
	public $_weekStart;
	public $_weekEnd;
	public $_today;
	public $_weekMode;
	public $_weekModeSessionName;

	public function initVars()
	{
		$uniqueId = $this->getUniqueID();
		$this->_weekModeSessionName = "WeekModeSessionName" . $uniqueId;
		
		$this->_dayLength = 3600*24;
		$this->_dateFormat = "EEE dd-MM-yyyy";
		$this->_shortDateFormat = "dd-MM-yyyy";
		$this->_today = strtotime('today');
		$this->_weekStart = strtotime('last Monday');
		$this->_weekEnd = strtotime('next Sunday');
		
		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallback())
		{
			$this->_weekMode = ($this->getViewMode() == "ReadOnly");
			$this->setWeekMode($this->_weekMode);
		}
		else
		{
			$this->_weekMode = $this->getWeekMode();
		}
	}

	public function onInit($param)
	{
		parent::onInit($param);
		$this->initVars();
	}

	public function onLoad($param)
	{
		parent::onLoad($param);

		$this->drawWeekPanel($this->_weekMode);
		
		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallBack())
		{
			$this->DayPicker->setData($this->_today);
			$this->writeDaysInterval($this->_today);
			
			$this->populate();
		}
		
		if ($this->getViewMode() == "ReadOnly")
		{
			$this->OpenNowLabel->setVisible(true);
			$libraryOpen = LibraryTimetablePeer::isLibraryOpen($this->getLibraryId());
			
			if ($libraryOpen == LibraryPeer::OPEN)  // if open
			{
				$this->OpenNowLabel->setText(Prado::localize("ORA APERTA"));
				$this->OpenNowLabel->setStyle("font-weight: bold; color: green");
			}
			elseif($libraryOpen == LibraryPeer::PAUSE)
			{
				$this->OpenNowLabel->setText(Prado::localize("OGGI APERTA, MA NON ORA"));
				$this->OpenNowLabel->setStyle("font-weight: bold; color: orange");
			}
			elseif($libraryOpen == LibraryPeer::CLOSED)
			{
				$this->OpenNowLabel->setText(Prado::localize("CHIUSA"));
				$this->OpenNowLabel->setStyle("font-weight: bold; color: red");
			}
			elseif($libraryOpen == LibraryPeer::NOTSETOPEN)
			{
				$this->OpenNowLabel->setText(Prado::localize("LA GIORNATA DI OGGI NON É INSERITA"));
				$this->OpenNowLabel->setStyle("font-weight: bold; color: red");
			}
			else
			{
				$this->OpenNowLabel->setText("");
				$this->OpenNowLabel->setVisible(false);
			}
		}
		else
			$this->OpenNowLabel->setVisible(false);
	}

	private function drawWeekPanel($param)
	{
		if ($param)  // we are in week mode
		{
			$this->DeltaTimeCheckWeek->setChecked(true);

			$this->BackButton->setAlternateText(Prado::localize('indietro di una settimana'));
			$this->BackButton->setToolTip(Prado::localize('indietro di una settimana'));
			$this->ForwardButton->setAlternateText(Prado::localize('avanti di una settimana'));
			$this->ForwardButton->setToolTip(Prado::localize('avanti di una settimana'));
			$this->LegendaFromLabel->setText(Prado::localize('settimana da'));
		}
		else		// we are in month view mode
		{
			$this->DeltaTimeCheckMonth->setChecked(true);
			$this->BackButton->setAlternateText(Prado::localize('indietro di quattro settimane'));
			$this->BackButton->setToolTip(Prado::localize('indietro di quattro settimane'));
			$this->ForwardButton->setAlternateText(Prado::localize('avanti di quattro settimane'));
			$this->ForwardButton->setToolTip(Prado::localize('avanti di quattro settimane'));
			$this->LegendaFromLabel->setText(Prado::localize('mese da'));
		}
	}
	
	public function setViewMode($param = null)
	{
		$this->setControlState("ViewMode", $param, "Normal");
	}

	public function getViewMode()
	{
		return $this->getControlState("ViewMode", "Normal");
	}

	public function setWeekMode($param = null)
	{
		$this->getApplication()->getSession()->add($this->_weekModeSessionName, $param, null);
		$this->_weekMode = $param;
	}

	public function getWeekMode()
	{
		$weekMode = $this->getApplication()->getSession()->itemAt($this->_weekModeSessionName, null);
		$this->_weekMode = $weekMode;
		return $weekMode;
	}
	
	public function setLibraryId($param = null)
	{
		$this->setControlState("LibraryId", $param, null);
	}

	public function getLibraryId()
	{
		return $this->getControlState("LibraryId", null);
	}

	public function populate()
	{
		/* @var $row LibraryTimetable */
		$criteria = new Criteria();

		$libraryId = $this->getLibraryId();
		$criteria->addAnd(LibraryTimetablePeer::LIBRARY_ID, $libraryId);

		$weekStart = intval($this->HiddenWeekStart->getValue());
		if ($weekStart == 0)
			$weekStart = $this->_weekStart;

		$weekEnd = intval($this->HiddenWeekEnd->getValue());
		if ($weekEnd == 0)
			$weekEnd = $this->_weekEnd;
		
		$criteria->addAnd(LibraryTimetablePeer::TIMETABLE_DAY, $weekStart, Criteria::GREATER_EQUAL);

		if ($this->_weekMode)
		{
			$criteria->addAnd(LibraryTimetablePeer::TIMETABLE_DAY, $weekEnd, Criteria::LESS_EQUAL);
			$criteria->setLimit(7);
		}
		else
		{
			$criteria->addAnd(LibraryTimetablePeer::TIMETABLE_DAY, $weekStart + 27 * $this->_dayLength, Criteria::LESS_EQUAL);
		}

		$criteria->addAscendingOrderByColumn(LibraryTimetablePeer::TIMETABLE_DAY);
		$timetable = LibraryTimetablePeer::doSelect($criteria);
		$recCount = LibraryTimetablePeer::doCount($criteria);
		
		$data = array();
		foreach ($timetable as $row)
		{
			$column = array();

			$column['Day'] = $row->getTimetableDay('U');
			$column['Open'] = $row->getTimetableOpen();
			$column['Holiday'] = $row->getTimetableHoliday();
			$column['DayCssClass'] = ($column['Holiday'] ? 'bordered' : "");
			$times = $row->convertTimes2String(Prado::localize('dalle'), Prado::localize('alle'));
			$note = trim($row->getTimetableNote());
			$column['Times'] = ($times != "" ? $times : '---')
								. ($note != "" ? "<br />($note)" : "");

			$data[] = $column;
		}

		$this->EmptyLabel->setVisible(intval($recCount) == 0);
		$this->Grid->setDataSource($data);
		$this->Grid->dataBind();
	}

	public function changePage($sender,$param)
	{
		$this->Grid->setCurrentPage($param->NewPageIndex);
		$this->populate();
	}

	public function globalRefresh()
	{
		$this->populate();
	}
	
	public function resetPagination()
	{
		$this->Grid->setCurrentPage(0);
	}

	public function getPopupFlag()
	{
		return $this->getPage()->IsPopup();
	}

	public function getUnlinkFlag()
	{
		return $this->getPage()->IsUnlink();
	}

	public function onColorize($sender, $param)
	{
		$item = $param->Item;
    	if ((($item->ItemType == 'Item') || ($item->ItemType == 'AlternatingItem'))
					&& array_key_exists('Holiday', $item->DataItem) && ($item->DataItem['Holiday']))
			$item->setCssClass('evidenced_light');
	}

	public function onDayPickerChanged($sender, $param)
	{
		$caller = $sender->getId();

		$day = ($this->DayPicker->getSafeText() != ''
				? $this->DayPicker->getTimeStamp()
				: null);

		if (intval($day) == 0)
		{
			$this->getPage()->writeMessage(Prado::localize("Data non valida: resettata ad oggi"), ClavisMessage::WARNING);
			$this->DayPicker->setData($this->_today);
			$day = $this->_today;
		}

		if ($caller == "BackButton")
			$day -= $this->_dayLength * ($this->_weekMode ? 7 : 28);
		else if ($caller == "ForwardButton")
			$day += $this->_dayLength * ($this->_weekMode ? 7 : 28);
		
		$this->DayPicker->setData($day);

		$this->writeDaysInterval($day);
		$this->globalRefresh();
		
		if ($this->getPage()->getIsCallback())
		{
			$this->WeekLegendaPanel->render($param->getNewWriter());
			$this->GridPanel->render($param->getNewWriter());
		}
	}
	
	private function writeDaysInterval($day)
	{
		$wDay = date('N', $day) - 1;
		$startDay = $day - $this->_dayLength * $wDay;
		$endDay = $startDay + $this->_dayLength * (($this->_weekMode ? 7 : 28) - 1);

		$this->HiddenWeekStart->setValue($startDay);
		$this->HiddenWeekEnd->setValue($endDay);
	}
	
	public function onSwitchDeltaTime($sender, $param)
	{
		$this->setWeekMode(!$this->_weekMode);
		$this->drawWeekPanel($this->_weekMode);
		$this->onDayPickerChanged($sender, $param);
	}
	
}