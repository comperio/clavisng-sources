<?php
/**
 * ClavisRequestsList file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Widgets
 */

/**
 * ClavisRequestsList class
 * 
 * This component visualizes the requests related to an item or a patron or whatever,
 * into a custom datagrid.
 * 
 * NB: this is a new version, that is made to use the new queries ("newcirc" branch)
 * for retrieving data.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @version 2.7
 * @package Widgets
 * @since 2.1
 */
class ClavisRequestsList extends TTemplateControl
{
	private $_object;
	private $_DatasourceSessionName;
	private $_requestManager;

	private function initVars()
	{
		$uniqueId = $this->getUniqueID();
		$this->_DatasourceSessionName = "DataSourceSessionName" . $uniqueId;
		$this->_requestManager = $this->getApplication()->getModule('request');
	}

	public function onInit($param)
	{
		parent::onInit($param);
		$this->initVars();
	}

	/**
	 * It populates our datagrid during the very first cycle
	 * of the parent page.
	 *
	 * @param TEventParameter $param
	 */
	public function onLoad($param)
	{
		parent::onLoad($param);

		$this->getObject();

		if (!$this->getPage()->getIsPostBack())
			$this->ActiveRequest->setChecked(true);

		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallback())
			$this->resetDataSource();
	}

	public function resetDataSource()	 // da sistemare
	{
		//$this->resetChecked();
		//$this->resetBarcodes();
		//$this->_datasource = array();
		$this->setDataSource(array());
		$this->populate();
	}

	public function getDataSource()
	{
		return $this->getApplication()->getSession()->itemAt($this->_DatasourceSessionName);
	}

	public function setDataSource($val)
	{
		$this->getApplication()->getSession()->add($this->_DatasourceSessionName, $val);
	}

	public function setObject($obj)
	{
		$this->_object = $obj;
		$this->setViewState("object", $obj, null);
	}

	public function getObject()
	{
		$this->_object = $this->getViewState("object", null);
		return $this->_object;
	}

	public function reloadStoredObject()
	{
		$obj = $this->getObject();
		if (!is_null($obj) && !$obj->isNew())
		{
			$objId = $obj->getId();
			$peerClass = $obj->getPeer();
			$newObj = $peerClass->retrieveByPK($objId);
			$this->setObject($newObj);
		}
	}

	public function populate($object = null)
	{
		if (!is_null($object))
		{
			$this->_object = $object;
			$this->setObject($this->_object);
		}
		else
		{
			$this->reloadStoredObject();
		}

		if (is_null($this->_object))
			return false;

		$loanableItemsByAllFlag = false;
		$loanableItemsByManifestationFlag = false;
		$activeRequest = $this->ActiveRequest->getChecked(); ////////

		switch (get_class($this->_object))
		{
			case 'Patron':
				$this->DestinationColumn->setVisible(false);
				break;

			case 'Item':
				$this->TitleColumn->setVisible(false);
				$manifestation = $this->_object->getManifestation();
				if ($manifestation instanceof Manifestation)
				{
					$loanableItemsByManifestationFlag = $manifestation->isLoanableByMyLibrary($this->GetUser()->getActualLibraryId());
					$loanableItemsByAllFlag = $manifestation->isLoanableByAll();
				}
				break;

			case 'Manifestation':
				$this->TitleColumn->setVisible(false);
				////////$this->IconTitleColumn->setVisible(true);

				$manifestation = $this->_object;
				if ($manifestation instanceof Manifestation)
				{
					$loanableItemsByManifestationFlag = $manifestation->isLoanableByMyLibrary();
					$loanableItemsByAllFlag = $manifestation->isLoanableByAll();
				}

				$requestsArray = $this->_requestManager->getManifestationRequests($manifestation->getManifestationId());
				break;

			default:
				return;
		}

		$recCount = count($requestsArray);
		$this->RecCounter->setText($recCount);
		$data = array();

		$pageSize = $this->Grid->getPageSize();
		$currentIndexPage = $this->Grid->getCurrentPage();

		foreach ($requestsArray as $index => $row)
		{
			$dataRow = array();

			$dataRow['RequestId'] = $row['requestId'];
			$dataRow['RequestDate'] = $row['requestDate'];

			$data[] = $dataRow;
		}

		$this->Grid->setVirtualItemCount($recCount);
		$this->Grid->setDataSource($data);
		$this->Grid->dataBind();

		$this->setDataSource($data);
	}

	public function onChangePage($sender, $param)
	{
		$this->Grid->setCurrentPage($param->NewPageIndex);
		$this->globalRefresh();
	}

	/**
	 * It returns whether the page permits that in this component
	 * we can have the functions that components inside popups have.
	 *
	 * @return boolean
	 */
	public function getPopupFlag()
	{
		return $this->getPage()->isPopup();
	}

	/**
	 * It returns whether the page permits that in this component
	 * we can have the unlink function.
	 *
	 * @return boolean
	 */
	public function getUnlinkFlag()
	{
		return $this->getPage()->isUnlink();
	}

	/**
	 * It returns whether the page permits that in this component
	 * we can have the delete function.
	 *
	 * @return boolean
	 */
	public function getDeleteFlag()
	{
		return $this->getPage()->isDelete();
	}

	/**
	 * This method, called for unlinking, calls the relative
	 * method of the parent page.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onUnlink($sender, $param)
	{
		$id = $param->CommandParameter;
		//
		$this->GetPage()->Unlink($id);
	}

	public function resetPagination()
	{
		$this->Grid->setCurrentPage(0);
	}

	public function onActiveRequestChanged($sender, $param)
	{
		$this->resetPagination();
		$this->populate();
	}

	public function globalRefresh()
	{
		$this->populate();
	}
	
}