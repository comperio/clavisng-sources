<?php
/**
 * ClavisPatronView class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Max Pigozzi
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Widgets
 */

/**
 * ClavisPatronView Class
 *
 * This component supports a read-only view of the Patron entity.
 * It can be used in two modes:
 *    1) Form View (as in Insert page, for viewing the exact fields edited in the same position);
 *    2) 2-cols View (to view the record in a more elegant and compact 2 columns view)
 *
 * Parameters are:
 * int ViewMode (0: form view (default), 1: 2-cols view)
 *
 * Functions are:
 * boolean populateView(int $id) (populate the read-only view)
 * 
 * @author Max Pigozzi
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.7
 * @package Widgets
 * @since 2.0
 */
class ClavisPatronView extends TTemplateControl {

	private $_patron;
	private $_viewmode;

	public function onLoad($param) 
	{
		parent::onLoad($param);

        if (!$this->getPage()->getIsPostBack()
				&& !$this->getPage()->getIsCallback())
		{
			$this->populate();
		}
	}

	public function populate($id = null)
	{
		$this->populateView($id);
	}

	public function populateView($id = null)
	{
		$this->getPage()->cleanMessageQueue();
		
		if (!$id)
			$id = $this->getPatronId();

		$id = intval($id);
		
		if ($id > 0)
		{
			$this->_patron = PatronQuery::create()->findPk($id);
			
			if (!($this->_patron instanceof Patron))
			{
				$this->getPage()->enqueueMessage(Prado::localize("Errore interno nel passaggio di parametri alla visualizzazione dati utente. Riportare al fornitore del software"),
												ClavisMessage::ERROR);
		
				$this->getPage()->flushMessage();
				
				return;
			}		

			$patronId = $this->_patron->getPatronId();
			$this->setPatronId($patronId);

			$this->Title->setText(LookupValuePeer::getLookupValue('TITLE', $this->_patron->getTitle()));
			$this->Lastname->setText($this->_patron->getLastname());
			$this->Firstname->setText($this->_patron->getName());

			$this->Sex->setText(LookupValuePeer::getLookupValue('SEX', $this->_patron->getGender()));
			$this->CivilState->setText(LookupValuePeer::getLookupValue('CIVILSTATE', $this->_patron->getCivilStatus()));

			if ($bd=$this->_patron->getBirthDate('U'))
				$this->BirthDate->setValue($bd);
			
			$this->BirthCity->setText($this->_patron->getBirthCity());
			$this->BirthProvince->setText($this->_patron->getBirthProvince());
			$patronBirthCountry  = $this->_patron->getBirthCountry();
			if( !LookupValueQuery::countryExists( $patronBirthCountry ))
			{
				$this->BirthCountryMsg->setText("(" . Prado::localize("non ISO") . ")");
				$this->BirthCountryMsg->setVisible(TRUE);
			}
			$this->BirthCountry->setText($patronBirthCountry);

			$patronCitizenship = $this->_patron->getCitizenship();
			if( !LookupValueQuery::citizenshipExists( $patronCitizenship ))
			{
				$this->CitizenshipMsg->setText("(" . Prado::localize("non ISO") . ")");
				$this->CitizenshipMsg->setVisible(TRUE);
			}
			$this->Citizenship->setText($patronCitizenship);

			$this->Barcode->setText($this->_patron->getBarcode());
			$this->Rfidcode->setText($this->_patron->getRfidCode());
			$this->Voicepin->setText($this->_patron->getVoicePin());

			$this->ActiveOpac->setChecked($this->_patron->getOpacEnable() ? true : false);
			$this->ActiveSurf->setChecked($this->_patron->getSurfEnable() ? true: false);
			$this->ActiveVoice->setChecked($this->_patron->getVoiceEnable() ? true: false);
			$this->PrivacyApprove->setChecked($this->_patron->getPrivacyApprove());

			$docexp = $this->_patron->getDocumentExpiry('U');
			
			if ($docexp > 1)
				$this->DocExpireDate->setValue($docexp);
			
			$this->DocType->setText(LookupValuePeer::getLookupValue('IDDOCS', $this->_patron->getDocumentType()));

			$this->DocNumber->setText($this->_patron->getDocumentNumber());
			$this->DocReleasedBy->setText($this->_patron->getDocumentEmitter());

			$this->NationalCode->setText($this->_patron->getNationalId());
			$this->PatronNote->setText($this->_patron->getPatronNote());

			$this->PatronState->setText(LookupValuePeer::getLookupValue('PATRONSTATE', $this->_patron->getPatronStatus()));
			$this->CardCode->setText($this->_patron->getCardCode());
			
			$crdexp = $this->_patron->getCardExpire('U');
			
			if ($crdexp > 1)
				$this->CardExpire->setValue($crdexp);
			
			$libraryR = LibraryPeer::retrieveByPK($this->_patron->getRegistrationLibraryId());
			
			if ($libraryR instanceof Library)
				$this->RegLibrary->setText($libraryR->getLabel());
			
			$libraryP = LibraryPeer::retrieveByPK($this->_patron->getPreferredLibraryId());
			
			if ($libraryP instanceof Library)
				$this->FavLibrary->setText($libraryP->getLabel());

			$this->PatronClass->setText(LookupValuePeer::getLookupValue('PATRONLOANCLASS', $this->_patron->getLoanClass()));
			
			/*
			 * Linked librarian part, with check for multiple entries
			 */
			$linkedLibrarians = LibrarianQuery::create()->findByPatronId($patronId);
			
			if (count($linkedLibrarians) == 0)
			{
					$this->LinkedLibrarianPanel->setVisible(false);
					$this->LinkedLibrarian->setText('');
					$this->LinkedLibrarian->setNavigateUrl('');
			}
			elseif (count($linkedLibrarians) >= 1)
			{	
				/* @var $librarian librarian */
				$librarian = $linkedLibrarians[0];
				$librarianName = $librarian->getCompleteName();

				if (trim($librarianName) == '')
					$librarianName = "(" . Prado::localize("senza nome") . ")";

				$this->LinkedLibrarianPanel->setVisible(true);
				$this->LinkedLibrarian->setText($librarianName);
				$this->LinkedLibrarian->setNavigateUrl($this->getService()->constructUrl('Library.LibrarianViewPage',
																			array('id' => $librarian->getLibrarianId())));
					
				if (count($linkedLibrarians) > 1) // more than 1 linked librarian (it should not happen)
				{
					$this->getPage()->enqueueMessage(Prado::localize("Attenzione: al corrente profilo utente (id: {id}) sono collegati più operatori. Si prega di segnalare al Centro Servizi per le modifiche da apportare",
																		array('id' => $patronId)),
								ClavisMessage::WARNING);
				}
			}

			if (ClavisParamQuery::getParam('CLAVISPARAM','PatronAccessControl') == 'true')
			{
				$this->CheckIn->setValue($this->_patron->getCheckIn('U'));
				$this->CheckOut->setValue($this->_patron->getCheckOut('U'));
				$l = $this->_patron->getLibraryRelatedByCheckLibrary();
			
				if ($l instanceof Library)
				{
					$this->CheckLibrary->setText($l->getLabel());
					$this->CheckLibrary->setNavigateUrl($this->getService()->constructUrl(	'Library.LibraryViewPage',
																							array('id' => $l->getLibraryId())));
				}
			}

			$this->AccessNote->setText($this->_patron->getAccessNote());
			$this->AccessAlert->setText(LookupValuePeer::getLookupValue('PATRONALERT', $this->_patron->getAccessAlert()));
			$this->MaxLoans->setText($this->_patron->getMaxLoans());
			$this->Nickname->setText($this->_patron->getOpacUsername());
			$this->ExpirePassword->setValue($this->_patron->getOpacSecretExpire("U"));

			$this->StudyLevel->setText(LookupValuePeer::getLookupValue('STUDTYPE', $this->_patron->getStatisticStudy()));
			$this->Work->setText(LookupValuePeer::getLookupValue('WORKTYPE', $this->_patron->getStatisticWork()));

			$this->Custom1->setText($this->_patron->getCustom1String());
			$this->Custom2->setText($this->_patron->getCustom2String());
			$this->Custom3->setText($this->_patron->getCustom3String());

			$this->Biography->setText($this->_patron->getBiography());

			$addressData = $this->_patron->getAddresss();
			$this->AddressList->setDataSource($addressData);
			$this->AddressList->dataBind();

			$contactData = $this->_patron->getContacts();
			$this->ContactList->setDataSource($contactData);
			$this->ContactList->dataBind();

			//$this->Photo->setImageURL('?file=' . $this->_patron->getPhotoFileId());
			$this->Photo->setImageURL($this->getRequest()->constructUrl('file', $this->_patron->getPhotoFileId()));
			
			$this->populateProperties();
		}
		
		$this->getPage()->flushMessage();
	}

	public function populateProperties()
	{
		if (!$this->_patron instanceof Patron)
			return;
		
		$properties = array();
		/* @var $property PatronProperty */
		foreach ($this->_patron->getPatronPropertys() as $property)     
		{
			$p = array();
			$p['PropertyLabel'] = LookupValuePeer::getLookupValue("PATRONPROPERTY", $property->getPropertyClass());
			$p['PropertyValue'] = $property->getPropertyValue();
			$p['id'] = $property->getId();

			$properties[] = $p;
		}

		$this->PropertyGrid->setDataSource($properties);
		$this->PropertyGrid->dataBind();
	}

	public function addressRepeaterDataBound($sender, $param)
	{
		$item = $param->Item;
	}

	public function contactRepeaterDataBound($sender, $param)
	{
		$item = $param->Item;
	}

	public function setPatronId($id)
	{
		$this->setControlState('PatronId',$id,null);
	}

	public function getPatronId()
	{
		return $this->getControlState('PatronId',null);
	}

	public function setViewMode($viewmode)
	{
		$this->_viewmode = $viewmode;
		$this->setControlState('ViewMode',$viewmode,0);
	}

	public function getViewMode()
	{
		if (is_null($this->_viewmode))
			$this->_viewmode = $this->getControlState('ViewMode',0);

		return $this->_viewmode;
	}

}
