<?php
/**
 * ClavisIssueView
 *
 * @author Max Pigozzi <mpigozzi@e-portaltech.it>
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2009 Comperio srl
 * @version 2.7
 * @package Widgets
 * @since 2.1
 */
class ClavisIssueView extends TTemplateControl
{
	/**
	 * @var Issue
	 */
	private $_issue = null;

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsPostBack())
		{
			$this->getIssue();
			$this->populate();
		}
	}

	public function populate()
	{
		if ($this->_issue === null)
			return;

		$manifestation = ManifestationQuery::create()->findPk($this->_issue->getManifestationId());

		$this->ManifestationView->setManifestation($manifestation);
		$this->IssueNumber->setText($this->_issue->getIssueNumber());
		$this->IssueYear->setText($this->_issue->getIssueYear());
		$this->IssueVolume->setText($this->_issue->getIssueVolume());
		$this->IssueType->setText(LookupValuePeer::getLookupValue('ISSUETYPE', $this->_issue->getIssueType()));
		$this->IssueDate->setValue($this->_issue->getIssueDate('U'));
		$this->StartNumber->setText($this->_issue->getStartNumber());
		$this->EndNumber->setText($this->_issue->getEndNumber());
	}

	public function setIssue($issue)
	{
		$this->_issue = $issue;
		$this->setControlState("issue", $issue, null);
	}

	public function getIssue()
	{
		if (is_null($this->_issue))
			$this->_issue = $this->getControlState('issue', null);

		return $this->_issue;
	}

	public function getIssueId()
	{
		$i = $this->getIssue();

		return ($i instanceof Issue) ? $i->getIssueId() : 0;
	}
	
}