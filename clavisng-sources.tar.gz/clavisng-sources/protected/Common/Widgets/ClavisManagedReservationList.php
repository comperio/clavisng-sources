<?php
/**
 * ClavisManagedReservationList component class Module Circulation
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2017 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.8.8
 */

/**
 * ClavisManagedReservationList component class Module Circulation
 *
 * This component visualizes a datagrid whose lines are item_requests
 * that were took in management (because in any way they could be
 * fullfilled) for a loan by the current logged operator.
 * It's not filtered by the controls in the page.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.8.8
 * @package Widgets
 * @since 2.0
 */
class ClavisManagedReservationList extends TTemplateControl 
{
	private $_datasource = null;
	private $_librarian;
	private $_librarianId;
	private $_checked;
	private $_illFoundDatasourceSessionName;
	private $_checkedSessionName;
	private $_itemIdSessionName;
	private $_globalcriteriaSessionName;
	private $_librarianSessionName;
	private $_fromLibraryId;
	private $_toLibraryId;
	private $_patronId;
	private $_renewCount;
	private $_outDateFrom;
	private $_outDateTo;
	private $_statuslist;
	private $_section;
	private $_collocation;
	private $_barcodeFilterSessionName;
	private $_bibObjFilterSessionName;
	
	public $_llibraryActive;
	public $_requestTypeActive;
	
	protected $_loanmanager;
	protected $_requestmanager;
	
	private function initVars() 
	{
		$uniqueId = $this->getUniqueID() . "respend";
		$this->_checkedSessionName = "CheckedSessionName" . $uniqueId;
		$this->_itemIdSessionName = "ItemIdSessionName" . $uniqueId;
		$this->_librarianSessionName = "LibrarianSessionName" . $uniqueId;

		$this->_globalcriteriaSessionName = "GlobalCriteriaSessionName" . $uniqueId;
		$this->_illFoundDatasourceSessionName = "IllFoundDatasource" . $uniqueId;
		$this->_datasource = $this->getApplication()->getSession()->itemAt($this->_illFoundDatasourceSessionName);
		$this->_checked = $this->getChecked();

		$this->_barcodeFilterSessionName = "BarcodeFilterSessionName" . $uniqueId;
		$this->_bibObjFilterSessionName = "BibObjFilterSessionName" . $uniqueId;

		$this->_loanmanager = $this->getApplication()->getModule("loan");
		$this->_requestmanager = $this->getApplication()->getModule("request");

		$this->_llibraryActive = (ClavisParamPeer::getParam('LLIBRARY_ACTIVE') == 1);
		$this->_requestTypeActive = ItemRequestPeer::isRequestType();
	}

	public function onInit($param) 
	{
		parent::onInit($param);
		$this->initVars();
		$this->attachEventHandler('OnActualLibraryChanged', array($this, 'OnActualLibraryChanged'));


		$this->MaxDistanceColumn->setVisible($this->_llibraryActive);
	}

	public function onLoad($param) 
	{
		parent::onLoad($param);

		if ($this->getAutopopulate()) {
			$this->populate();
		}
	}

	public function OnActualLibraryChanged($sender, $param)
	{
		if ($this->getAutopopulate()) {
			$this->populate();
		}
	}

	public function setGlobalCriteria($criteria = null) 
	{
		$this->setViewState($this->_globalcriteriaSessionName, $criteria, null);
	}

	public function getGlobalCriteria() 
	{
		return SerializableCriteria::refreshCriteria($this->getViewState($this->_globalcriteriaSessionName, null));
	}

	public function resetChecked($state = false) 
	{
		$this->setChecked(array('all' => $state));
	}

	public function setChecked($checked = null) 
	{
		$this->_checked = $checked;
		$this->getApplication()->getSession()->add($this->_checkedSessionName, $checked);
	}

	public function getChecked() 
	{
		$this->_checked = $this->getApplication()->getSession()->itemAt($this->_checkedSessionName);
	
		if (is_null($this->_checked))
		{
			$this->resetChecked(false);
			$this->_checked = $this->getApplication()->getSession()->itemAt($this->_checkedSessionName);
		}
		
		return $this->_checked;
	}

	public function setAutopopulate($param = "true")
	{
		if (strtolower($param) === "false")
			$param = false;
		else
			$param = true;

		$this->setControlState("autopopulate", $param, true);
	}

	public function getAutopopulate()
	{
		return $this->getControlState("autopopulate", true);
	}
	
	public function resetItemIdColl() 
	{
		$this->setItemIdColl(array());
	}

	private function setItemIdColl($value) 
	{
		$this->getApplication()->getSession()->add($this->_itemIdSessionName, $value);
	}

	private function getItemIdColl() 
	{
		$output = $this->getApplication()->getSession()->itemAt($this->_itemIdSessionName);
		if (is_null($output) || !(is_array($output)))
			$output = array();

		return $output;
	}

	public function searchItemIdColl($value = 0) 
	{
		return is_numeric(array_search($value, $this->getItemIdColl()));
	}

	public function existsBarcode($barcode = '') 
	{
		return false;
	}

	public function resetLibrarian() 
	{
		$this->setLibrarian(null);
	}

	public function setLibrarian($librarian = null) 
	{
		$this->_librarian = $librarian;
		$this->getApplication()->getSession()->add($this->_librarianSessionName, $librarian);
	}

	public function getLibrarian() 
	{
		$this->_librarian = $this->getApplication()->getSession()->itemAt($this->_librarianSessionName);
	
		if (is_null($this->_librarian) || !($this->_librarian instanceof Librarian))
			$this->_librarian = $this->getUser()->getLibrarian();
	
		return $this->_librarian;
	}

	public function getDataSource() 
	{
		$this->_datasource = $this->getApplication()->getSession()->itemAt($this->_illFoundDatasourceSessionName);
		
		return $this->_datasource;
	}

	public function setDataSource($datasource = array()) 
	{
		$this->_datasource = $datasource;
		$this->getApplication()->getSession()->add($this->_illFoundDatasourceSessionName, $datasource);
	}

	public function resetDataSource($populateFlag = true) 
	{
		$this->resetChecked();
		$this->resetItemIdColl();
		$this->setDataSource(array());
		
		if ($populateFlag)
		{
			$this->populate();

			if ($this->getPage()->getIsCallBack()) 
				$this->GridPanel->render($this->getPage()->createWriter());
		}
	}

	public function getCheckedItems(	$force = false, 
										$reset = false, 
										$jasperMode = false) 
	{
		$checked = $this->getChecked();
		$masterChecked = $checked['all'];
		unset($checked['all']);
		$checkedIds = array_keys($checked);
		$requestIds = array();

		if (!$masterChecked)
		{
			$requestIds = $checkedIds;
		}
		else 
		{	// the strange case of inverse mastercheck ...
			$criteria = $this->getGlobalCriteria();
			if (!is_null($criteria) && ($criteria instanceof Criteria)) 
			{
				$criteria->add(ItemRequestPeer::REQUEST_ID, $checkedIds, Criteria::NOT_IN);
				$requests = ItemRequestPeer::doSelect($criteria);
				
				foreach ($requests as $request)
					$requestIds[] = $request->getRequestId();
			}
			elseif (!is_null($criteria) && (is_array($criteria)))
			{
				$requestIds = array_fill_keys(array_diff($criteria, $checkedIds), true);
			}
		}

		$results = array();
		
		if ($jasperMode)
			$itemIdPool = array();

		foreach ($requestIds as $requestId) 
		{
			if ($requestId > 0) 
			{
				$request = ItemRequestQuery::create()->findPK($requestId);
				
				if ($request instanceof ItemRequest) 
				{
					$manifestationId = $request->getManifestationId();
					$itemId = $request->getItemId();
					$issueId = $request->getIssueId();
					$maxDistance = $request->getMaxDistance();
					$deliveryLibraryId = $request->getDeliveryLibraryId();
					
					$myItemIds = $this->_requestmanager->getRequestMyCandidateItemIds(	$deliveryLibraryId, 
																						$maxDistance, 
																						$manifestationId, 
																						$itemId, 
																						$issueId);

					if (!$jasperMode) 
					{   // normal
						$results[] = array(	'id' => $request->getRequestId(),
											'request' => $request,
											'title' => mb_substr($request->getTitle(), 0, 130, 'utf8'),
											'requestDate' => $request->getRequestDate('U'),
											'expireDate' => $request->getExpireDate('U'),
                                            'requestNote' => $request->getRequestNote(),
											'deliveryLibraryLabel' => $request->getDeliveryLibraryLabel(),
											'localItemIds' => $myItemIds);
					} 
					else 
					{ // jasper mode
						$results[] = $request->getRequestId();
						$itemIdPool = array_merge($itemIdPool, $myItemIds);
					}
				}
			}
		}

		if (!$jasperMode) 
		{   // normal
			if ((count($results) == 0) && $force) 
			{
				$this->resetChecked(true);
				$results = $this->getCheckedItems();
				
				if ($reset)
					$this->resetChecked(false);
			}

			$output = $results;
		}
		else 
		{  // jasper mode
			$itemIdPool = array_unique($itemIdPool);

			if ((count($results) == 0) && ($force == true)) 
			{
				$this->resetChecked(true);
				$resultsCombo = $this->getCheckedItems(false, false, true);
				$results = $resultsCombo['requestId'];
				$itemIdPool = $resultsCombo['itemId'];
				if ($reset)
					$this->resetChecked(false);
			}

			$output = array(	'requestId' => $results, 
								'itemId' => $itemIdPool );
		}

		return $output;
	}

	public function getCheckedItemIds(	$force = false, 
										$reset = false) 
	{
		$checked = $this->getChecked();
		
		if (array_key_exists('all', $checked))
		{
			$masterChecked = $checked['all'];
		}
		else
		{
			$masterChecked = false;
		}
		
		unset($checked['all']);
		$checkedIds = array_keys($checked);
		$requestIds = array();

		if (!$masterChecked)
		{
			$requestIds = $checkedIds;
		}
		else 
		{	// caso del mastercheck inverso
			$criteria = $this->getGlobalCriteria();
			
			if (!is_null($criteria) && ($criteria instanceof Criteria)) 
			{
				$criteria->add(ItemRequestPeer::REQUEST_ID, $checkedIds, Criteria::NOT_IN);
				$requests = ItemRequestPeer::doSelect($criteria);
			
				foreach ($requests as $request)
					$requestIds[] = $request->getRequestId();
			}
			elseif (!is_null($criteria) && (is_array($criteria)))
			{
				$requestIds = array_fill_keys(array_diff($criteria, $checkedIds), true);
			}
		}

		if ((count($requestIds) == 0) && $force) 
		{
			$this->resetChecked(true);
			$requestIds = $this->getCheckedItems();
		}

		if ($reset)
			$this->resetChecked(false);
					
		return $requestIds;
	}
	
	public function setMasterChecked($newChecked = false, $param = null) 
	{
		$this->resetChecked($newChecked);
		$gridItems = $this->Grid->getItems();
		$header = $this->Grid->getHeader();

		foreach ($gridItems as $item)
			$item->CheckColumn->Checked->setChecked($newChecked);

		$header->CheckColumn->MasterCheck->setChecked($newChecked);
	}

	public function calculateSortingCriteria(&$sortingCriteria = null) 
	{
		$sortingExpression = $this->Grid->getSortingExpression();
		$sortingDirection = $this->Grid->getSortingDirection();

		if (is_null($sortingCriteria) 
				|| !($sortingCriteria instanceof Criteria))
			$sortingCriteria = new Criteria();

		switch ($sortingExpression) 
		{
			case 'requestDate':
				$sortingCriteria->clearOrderByColumns();
				
				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
				{
					$sortingCriteria->addAscendingOrderByColumn(ItemRequestPeer::REQUEST_DATE);
				}
				elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
				{
					$sortingCriteria->addDescendingOrderByColumn(ItemRequestPeer::REQUEST_DATE);
				}
				
				break;

			case 'collocation':
				$sortingCriteria->clearOrderByColumns();
				
				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC) 
				{
					$sortingCriteria->addJoin(ItemRequestPeer::MANIFESTATION_ID, ItemPeer::MANIFESTATION_ID);
					$sortingCriteria->addAnd(ItemPeer::ACTUAL_LIBRARY_ID, $this->getUser()->getActualLibraryId());
					$sortingCriteria->addAscendingOrderByColumn(ItemPeer::SECTION);
					$sortingCriteria->addAscendingOrderByColumn(ItemPeer::COLLOCATION);
					$sortingCriteria->addAscendingOrderByColumn(ItemPeer::SPECIFICATION);
					$sortingCriteria->addAscendingOrderByColumn(ItemPeer::SEQUENCE1);
					$sortingCriteria->addAscendingOrderByColumn(ItemPeer::SEQUENCE2);
					$sortingCriteria->setDistinct();
				} 
				elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC) 
				{
					$sortingCriteria->addJoin(ItemRequestPeer::MANIFESTATION_ID, ItemPeer::MANIFESTATION_ID);
					$sortingCriteria->addAnd(ItemPeer::ACTUAL_LIBRARY_ID, $this->getUser()->getActualLibraryId());
					$sortingCriteria->addDescendingOrderByColumn(ItemPeer::SECTION);
					$sortingCriteria->addDescendingOrderByColumn(ItemPeer::COLLOCATION);
					$sortingCriteria->addDescendingOrderByColumn(ItemPeer::SPECIFICATION);
					$sortingCriteria->addDescendingOrderByColumn(ItemPeer::SEQUENCE1);
					$sortingCriteria->addDescendingOrderByColumn(ItemPeer::SEQUENCE2);
					$sortingCriteria->setDistinct();
				}
				
				break;

			case null:
				break;

			default:
				$sortingExpression = null;
		}
	}

	/**
	 * It populates the grid, and takes the four necessary filter
	 * parameters from given saved data, and eventual other filters
	 * (i.e. patron, which was passed through the "setObject()").
	 *
	 */
	public function populate() 
	{
		/* @var $request ItemRequest */

		// if first page cycle
		if (!$this->getPage()->getIsPostBack() 
				&& !$this->getPage()->getIsCallback()) 
		{
			$this->resetDataSource(false);
			$this->resetPagination();
		}
		
		$filteredFlag = false;
		$loanableItemsByAllFlag = false;
		$loanableItemsByManifestationFlag = false;
		$pageSize = $this->Grid->getPageSize();
		$currentIndexPage = $this->Grid->getCurrentPage();

		$criteria = new Criteria();
		$myLibraryId = $this->getUser()->getActualLibraryId();

		$actualLibrarianId = intval($this->getLibrarianIdFilter());
		
		if ($actualLibrarianId == 0) 
		{
			$actualLibrarian = $this->getLibrarian();
			$actualLibrarianId = $actualLibrarian->getLibrarianId();
		}

		$criteria->add(ItemRequestPeer::LIBRARIAN_ID, $actualLibrarianId);
		$criteria->add(ItemRequestPeer::LIBRARY_ID, $this->getUser()->getActualLibraryId());
		$criteria->add(ItemRequestPeer::REQUEST_STATUS, ItemRequestPeer::STATUS_WORKING);

		$criterion = $criteria->getNewCriterion(ItemRequestPeer::REQUEST_TYPE, array_keys(ItemRequestPeer::getRequestTypes(false, null, true)), Criteria::IN);
		$criterion2 = $criteria->getNewCriterion(ItemRequestPeer::REQUEST_TYPE, null, Criteria::ISNULL);
		$criterion->addOr($criterion2);
		$criteria->add($criterion);

		$barcodeFilter = trim($this->getBarcodeFilter());
		
		if ($barcodeFilter != '') 
		{
			$itemsFromBarcode = ItemPeer::retrieveByDataInput($barcodeFilter);
			
			if (is_null($itemsFromBarcode))
				$itemsFromBarcode = array();

			$manifestationIdsFromBarcode = array();
			$itemIdsFromBarcode = array();
			
			foreach ($itemsFromBarcode as $itemRow) 
			{
				$manId = intval($itemRow->getManifestationId());
				if ($manId > 0)
				{
					$manifestationIdsFromBarcode[] = $manId;
				}
				else
				{
					$itemIdsFromBarcode[] = $itemRow->getItemId();
				}
			}

			if (count($manifestationIdsFromBarcode) > 0)
				$criteria->addAnd(ItemRequestPeer::MANIFESTATION_ID, $manifestationIdsFromBarcode, Criteria::IN);

			if (count($itemIdsFromBarcode) > 0)
				$criteria->addAnd(ItemRequestPeer::ITEM_ID, $itemIdsFromBarcode, Criteria::IN);

			$filteredFlag = true;
		}
		else 
		{
			/* We are not using filters anymore........
			 * But ... who knows, in the future ? .....
			 * 
			$toLibraryIdFilter = $this->getToLibraryId();
			$patronIdFilter = $this->getPatronId();

			$renewCountFilter = $this->getRenewCount();
			if (is_null($renewCountFilter) || ($renewCountFilter == ""))
				$renewCountFilter = -0.5;
			else
				$renewCountFilter = floatval($renewCountFilter);

			$outDateFromFilter = $this->getOutDateFrom();
			$outDateToFilter = $this->getOutDateTo();

			$statusFilter = $this->getStatusList();
			$notManageableFlag = $this->getNotManageableFlag();

			$sectionFilter = $this->getSection();
			$collocationFilter = $this->getCollocation();
			$bibObjFilter = $this->getBibObjFilter();

			if ($renewCountFilter >= 0) 
			{
				$renewCountFilter = intval($renewCountFilter);
				$criteria->setDistinct();
				if ($renewCountFilter == 0.5) 
				{
					$criteria->setDistinct();
					$criteria->addAnd(ItemPeer::RENEWAL_COUNT, 0, Criteria::GREATER_THAN);
				} 
				else 
				{
					$criteria->setDistinct();
					$criteria->addAnd(ItemPeer::RENEWAL_COUNT, $renewCountFilter);
				}
			} 
			else 
			{
				if ($renewCountFilter <= -1) 
				{
					$criteria->setDistinct();
					$criteria->addAnd(ItemPeer::RENEWAL_COUNT, -1, Criteria::LESS_THAN);
				}
			}

			if (!is_null($toLibraryIdFilter)) 
			{
				$criteria->add(ItemRequestPeer::DELIVERY_LIBRARY_ID, $toLibraryIdFilter);
				$filteredFlag = true;
			}

			if (!is_null($patronIdFilter)) 
			{
				$criteria->addAnd(ItemRequestPeer::PATRON_ID, $patronIdFilter);
				$filteredFlag = true;
			}

			if (!is_null($outDateFromFilter) && ($outDateFromFilter > 0)) 
			{
				$criteria->addAnd(ItemRequestPeer::REQUEST_DATE, $outDateFromFilter, Criteria::GREATER_EQUAL);
				$filteredFlag = true;
			}

			if (!is_null($outDateToFilter) && ($outDateToFilter > 0)) 
			{
				$criteria->addAnd(ItemRequestPeer::REQUEST_DATE, $outDateToFilter + 86399, Criteria::LESS_EQUAL);
				$filteredFlag = true;
			}

			if (!is_null($statusFilter)) 
			{
				if (is_array($statusFilter) && (count($statusFilter) > 0)) 
				{
					$criteria->add(ItemRequestPeer::REQUEST_STATUS, $statusFilter, Criteria::IN);
					$filteredFlag = true;
				}
			}

			if (!is_null($sectionFilter)) 
			{
				$criteria->addJoin(ItemRequestPeer::MANIFESTATION_ID, ItemPeer::MANIFESTATION_ID);
				$criteria->addAnd(ItemPeer::SECTION, $sectionFilter . '%', Criteria::LIKE);
				$criteria->addAnd(ItemPeer::ACTUAL_LIBRARY_ID, $myLibraryId);
				$criteria->setDistinct();
				$filteredFlag = true;
			}

			if (!is_null($collocationFilter)) 
			{
				$criteria->addJoin(ItemRequestPeer::MANIFESTATION_ID, ItemPeer::MANIFESTATION_ID);
				$criteria->addAnd(ItemPeer::ACTUAL_LIBRARY_ID, $myLibraryId);
				$criteria->addAnd(ItemPeer::COLLOCATION, $collocationFilter . '%', Criteria::LIKE);
				$criteria->setDistinct();
				$filteredFlag = true;
			}

			if (!is_null($bibObjFilter)) 
			{
				$criteria->addJoin(ItemRequestPeer::MANIFESTATION_ID, ManifestationPeer::MANIFESTATION_ID);
				$criteria->addAnd(ManifestationPeer::BIB_TYPE_FIRST, $bibObjFilter);
				$filteredFlag = true;
			}
			 */
		}

		$requestsCount = ItemRequestPeer::doCount($criteria);

		$this->Grid->resetSorting('requestDate', null, false);
		$this->calculateSortingCriteria($criteria);
		$this->setGlobalCriteria(clone $criteria);

		if ($pageSize > 0) 
		{
			$this->Grid->setVirtualItemCount($requestsCount);
			$criteria->setLimit($pageSize);
			$criteria->setOffset($currentIndexPage * $pageSize);
		}

		$requests = ItemRequestPeer::doSelect($criteria);

		$checkedList = $this->getChecked();
		
		if (array_key_exists('all', $checkedList))
		{
			$masterCheck = $checkedList['all'];
		}
		else
		{
			$masterCheck = false;
		}

		$datasource = array();
		$itemIdList = array();
					
		foreach ($requests as $request) 
		{
			$requestId = $request->getId();

			$manifestation = $request->getManifestation();
			$manifestationId = intval($request->getManifestationId());
			$item = $request->getItem();
			$itemId = $request->getItemId();
			$issueId = $request->getIssueId();
			$maxDistance = $request->getMaxDistance();
			
			if (isset($checkedList[$requestId]))
			{
				$checked = $checkedList[$requestId];
			}
			else
			{
				$checked = false;
			}
			
			if ($masterCheck)
				$checked = !$checked;

			$patronId = $request->getPatronId();
			$patron = $request->getPatron();
			$externalLibrary = $request->getExternalLibrary();
			
			$deliveryLibraryId = $request->getDeliveryLibraryId();
			$actualLibraryId = null;
			//$wantedUrl = '';
			$wantedText = '';
			$wantedImageUrl = '';

			$myItemIds = $this->_requestmanager->getRequestMyCandidateItemIds(	$deliveryLibraryId, 
																				$maxDistance, 
																				$manifestationId, 
																				$itemId, 
																				$issueId);
			
			$localItemsNumber = count($myItemIds);
			$localItemsCollocationArray = array();
			$localItemsCollocationRepArray = array();
			$minUsageCount = 200042;	// chosen by random imagination ...
			$leastUsedItemId = null;
			
			foreach ($myItemIds as $rowItemId) 
			{
				$item = ItemQuery::create()
							->findPK($rowItemId);
				$usageCount = $item->getUsageCount();
				$itemIdList[] = $rowItemId;

				$localItemsCollocationArray[$rowItemId] = $item->getHyperLinkCollocationCombo(	$this->getPage()->getForm()->getClientId(),
																								$myLibraryId, 
																								true);
				
				$localItemsCollocationRepArray[$rowItemId] = $item->getCollocationCombo(null, true);

				if (($this->_loanmanager->IsItemAvailable($item, $request->getDeliveryLibraryId()) == ClavisLoanManager::OK) 
						&& ($usageCount != null) 
						&& ($usageCount < $minUsageCount)) 
				{
					$minUsageCount = $usageCount;
					$leastUsedItemId = $itemId;
				}	// not available
				elseif (is_null($leastUsedItemId))
				{
					$leastUsedItemId = $itemId;
				}
			}

			$localItemsCollocationString = '';
			$localItemsCollocationReportString = '';

			foreach ($localItemsCollocationArray as $id => $string)
				$localItemsCollocationString .= '<br />' . trim($string);

			foreach ($localItemsCollocationRepArray as $id => $string)
				$localItemsCollocationReportString .= $string . "\n";

			$localItemsString = $localItemsNumber;
			$localItemsString .= $localItemsCollocationString;		
			
			$wantedText = '';
			$wantedImageUrl = '';
			$wantedPopupUrl = '';

			$itemLibraryId = null;
			$itemLibraryLabel = null;

			if ($item instanceof Item) 
			{
				$itemLibraryId = $item->getHomeLibraryId();
				$itemLibraryLabel = $item->getHomeLibraryLabel();

				$wantedTitle = $item->getTrimmedTitle(70);
				$wantedId = $itemId;
				if ($wantedTitle != '') 
					$wantedText = $wantedTitle;
			} 
			else 
			{
				$manifestation = $request->getManifestation();
				
				if ($manifestation instanceof Manifestation) 
				{
					if ($issueId > 0) 
					{
						$issue = IssueQuery::create()->findPK($issueId);
						
						if (!is_null($issue))
							$titleQueue = ' (' . Prado::localize('fasc') . ': ' . $issue->getIssueCombo(false) . ')';
					}
					else
					{
						$titleQueue = '';
					}

					$wantedTitle = $manifestation->getTrimmedTitle(130) . $titleQueue;
					$wantedId = $manifestation->getManifestationId();
					
					if ($wantedTitle != '') 
					{
						if ($loanableItemsByManifestationFlag) 
						{
							$wantedImageUrl = "themes/Default/icons/nav_plain_green-16.png";
						} 
						elseif ($loanableItemsByAllFlag) 
						{
							$wantedImageUrl = "themes/Default/icons/nav_plain_yellow-16.png";
						} 
						else 
						{
							$wantedImageUrl = "themes/Default/icons/nav_plain_red-16.png";
							$wantedText = $wantedTitle;
						}
					}

					$wantedPopupUrl = "Circulation.ItemRequestListPopup&id=" . $wantedId . "&requestId=" . $request->getId();
				}
			}

			$requestType = null;
			$requestTypeString = '';
			
			if ($this->_requestTypeActive)
			{
				$requestType = $request->getRequestType();
				
				if (!is_null($requestType))
					$requestTypeString = '<br /><b>[' . ItemRequestPeer::getRequestTypeString($requestType) . ']</b>';
			}
			
			$destinationText = Prado::localize("indefinito");	// priming
			$destinationNavigateUrl = "";
			$deliveryLibraryText = "";
			$externalLibraryToolTip = "";
			$canLoan = false;
			
			/**
			 * this should be the number of items that other libraris in the system
			 * can actually use for this request that i can process, on my behalf.
			 * 
			 * If it's == 0, my library is the only library that can process that request.
			 */
			$alienItemsCount = 0;
			
			if ($patron instanceof Patron)
			{
				$destinationText = $patron->getCompleteName();
				
				$loanCount = LoanQuery::create()
								->filterByPatron($patron)
								->filterByLoanStatus(ItemPeer::getLoanStatusActive())
								->count();

				if ($loanCount > 0)
					$destinationText .= "&nbsp;(<b>$loanCount</b>)";
				
				$destinationNavigateUrl = $patron->getNavigateUrl(true);
				$deliveryLibrary = $request->getDeliveryLibrary();
				
				if ($deliveryLibrary instanceof Library)
				{
					$deliveryLibraryText = "<br />->&nbsp;" .$deliveryLibrary->getLabel(null, null, null, 20);
				
					$alienItemsCount = $this->_requestmanager->countRequestAllCandidateItems(	$deliveryLibrary->getLibraryId(),
																								$maxDistance,
																								$manifestationId,
																								$itemId,
																								$issueId);
				}
				
				$canLoan = ($this->_loanmanager->IsPatronAllowedToLoan($patron, $itemId) == ClavisLoanManager::OK);
			}
			elseif ($externalLibrary instanceof Library)
			{
				$destinationText = $externalLibrary->getLabel(true, false, true, 30);
				$destinationNavigateUrl = $externalLibrary->getNavigateUrl(true);
				
				$externalLibraryToolTip = $externalLibrary->getTrimmedDescription(100) . ' (' .
						Prado::localize('consorzio') . ": " . $externalLibrary->getConsortiaString(100) . ')';
					
				$canLoan = ($this->_loanmanager->isExternalLibraryAllowedToLoan($externalLibrary->getLibraryId()) == ClavisLoanManager::OK);
			}

			$flagCode = ($alienItemsCount > 0
							? ClavisRequestManager::no_flag
							: ClavisRequestManager::red_flag );
			
			$title = $shortTitle = '';
			
			if (is_null($manifestation)) 
			{
				if (!is_null($item)) 
				{
					$title = $item->getTrimmedTitle(140);
					$shortTitle = $item->getTitle();
				}
			} 
			else 
			{
				$title = $manifestation->getTrimmedTitle(140);
				$shortTitle = $manifestation->getTitle();
			}

			// imported peer-peer from ClavisManageRequestsList
			if (!is_null($issueId))
			{
				// request is on ISSUE
				$titleNavigateUrl = IssuePeer::getNavigateUrl() . $issueId;
				$requestTypeImage = "requesttype_issue.png";
				$requestTypeText = Prado::localize("prenotazione per fascicolo");
			}
			elseif (!is_null($itemId))
			{
				// request is on ITEM
				$titleNavigateUrl = ItemPeer::getNavigateUrl() . $itemId;
				$requestTypeImage = "requesttype_item.png";
				$requestTypeText = Prado::localize("prenotazione per esemplare");
			}
			elseif ($manifestationId > 0)
			{
				// request is on MANIFESTATION
				$titleNavigateUrl = ManifestationPeer::getNavigateUrl() . $manifestationId;
				$requestTypeImage = "";
				$requestTypeText = "";
			}
			else
			{
				// fallback (should not happen)
				$titleNavigateUrl = "";
				$requestTypeImage = "";
				$requestTypeText = "";
			}
			
			$datasource[] = array(	'TitleNavigateUrl' => $titleNavigateUrl,
									'WantedText' => $wantedText,
									'WantedImageUrl' => $wantedImageUrl,
									'WantedPopupUrl' => $wantedPopupUrl,
									'ItemLibraryId' => $itemLibraryId,
									'ItemLibraryLabel' => $itemLibraryLabel,
									'checked' => $checked,
									'manifestationId' => $manifestationId,
									'requestId' => $requestId,
									'title' => $title,
									'shortTitle' => $shortTitle,
				
									'localItemsNumber' => $localItemsNumber,
									'localItemsString' => $localItemsString,
									'alienItemsString' => $alienItemsCount,
									
									'flagCode' => $flagCode,
				
									'actualLibraryId' => $actualLibraryId,
									'actualLibraryLabel' => LibraryPeer::getLibraryLabel($actualLibraryId, '---'),
									'deliveryLibraryId' => $deliveryLibraryId,
									'deliveryLibraryText' => $deliveryLibraryText,
									'patronId' => $patronId,
									'destinationText' => $destinationText,
									'destinationNavigateUrl' => $destinationNavigateUrl,
				
									'externalLibraryToolTip' => $externalLibraryToolTip,
									'requestDate' => $request->getRequestDate('U'),
									'expireDate' => $request->getExpireDate('U'),
                                    'requestNote' => $request->getRequestNote(),
									'requestStatus' => $request->getRequestStatus(),
									'canLoan' => $canLoan,
									'leastUsedItemId' => $leastUsedItemId,
									'maxDistance' => (is_null($maxDistance) ? LLibraryPeer::NULLDISTANCE : $maxDistance),
									'requestTypeImage' => $requestTypeImage,
									'requestTypeText' => $requestTypeText,
									'requestType' => $requestType,
									'requestTypeString' => $requestTypeString );
		}

		$this->setDataSource($datasource);
		$this->Grid->setDataSource($datasource);
		$this->Grid->dataBind();
		
		$this->FoundNumber->setText($requestsCount);
		$this->FilteredFlagPanel->setVisible($filteredFlag);
		
		$this->setItemIdColl($itemIdList);
	}

	/**
	 * Method which implements the page change in the grid.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function changePage($sender, $param) 
	{
		$this->Grid->setCurrentPage($param->NewPageIndex);
		$this->populate();
	}

	/**
	 * Are we inside a popup?
	 *
	 * @return boolean
	 */
	public function getPopupFlag() 
	{
		return $this->getPage()->isPopup();
	}

	/**
	 * Resets the datagrid's pagination (first page).
	 *
	 */
	public function resetPagination() 
	{
		$this->Grid->setCurrentPage(0);
	}

	/**
	 * It changes the status (on/off) of the checkbox of one chosen
	 * row item of datagrid.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onFlipChecked($sender, $param) 
	{
		$index = $sender->Parent->Parent->ItemIndex;
		$dataSource = $this->getDatasource();

		$newStatus = $sender->getChecked();
		$checked = $this->getChecked();

		$row = $dataSource[$index];
		$requestId = $row['requestId'];

		if ($newStatus != $checked['all'])
		{
			$checked[$requestId] = true;
		}
		else
		{
			unset($checked[$requestId]);
		}

		$this->setChecked($checked);
	}

	public function doMasterChecked($newStatus, $resetMasterCheck = false) 
	{
		$gridItems = $this->Grid->getItems();
		
		foreach ($gridItems as $item)
			$item->CheckColumn->Checked->setChecked($newStatus);

		if ($resetMasterCheck)
			$this->Grid->Header->CheckColumn->MasterCheck->setChecked($newStatus);
	}

	public function onMasterChecked($sender, $param) 
	{
		$newStatus = $sender->getChecked();
		$this->resetChecked($newStatus);
		$this->doMasterChecked($newStatus);
	}

	public function onNewLoan($sender, $param) 
	{
		$parameter = $param->getCommandParameter();
		$itemId = $parameter['itemId'];
		$requestId = $parameter['requestId'];

		if (($itemId > 0) 
				&& ($requestId > 0))
			$this->getPage()->gotoPageWithReturn(	"Circulation.NewLoan", 
													array(	'itemId' => $itemId, 
															'requestId' => $requestId ));
	}

	public function onPopupLoan($sender, $param) 
	{
		$parameter = $param->getCommandParameter();
		$itemId = intval($parameter['itemId']);
		$itemRequestId = intval($parameter['requestId']);

		if (($itemId > 0) 
				&& ($itemRequestId > 0)) 
		{
			$toRefreshFlag = false;

			$newDueDate = $this->_loanmanager->CalculateDueDate(ItemQuery::create()->findPK($itemId));
			$item = ItemQuery::create()->findPK($itemId);
			$itemRequest = ItemRequestQuery::create()->findPK($itemRequestId);
			$patron = $itemRequest->getPatron();
			$clavisLibrarian = $this->getUser();
			$deliveryLibrary = $itemRequest->getDeliveryLibrary();

			$reqval = $this->_loanmanager->DoManageRequest($itemRequest, $clavisLibrarian);
			
			switch ($reqval)
			{
				case ClavisLoanManager::OK :
					$retval = $this->_loanmanager->DoLoanItem($item, $patron, $clavisLibrarian, $deliveryLibrary, $itemRequest, $newDueDate);
					
					switch ($retval) 
					{
						case ClavisLoanManager::LOAN_ILLREQUESTED :
							$messageBody = Prado::localize("Prenotazione soddisfatta ed esemplare '{itemTitle}' [barcode: {itemBarcode}] messo in 'pronto al transito' per l'utente {patronName}", 
																array(	'itemTitle' => $item->getTrimmedTitle(40), 
																		'itemBarcode' => $item->getBarcode(), 
																		'patronName' => $patron->getCompleteName() ));  // a request for interloan has been inserted
							$messageType = ClavisMessage::CONFIRM;
							$toRefreshFlag = true;
							
							break;

						case ClavisLoanManager::LOAN_RESERVED :
							$messageBody = Prado::localize("Inserita prenotazione");
							$messageType = ClavisMessage::INFO;
							$toRefreshFlag = true;
							break;

						case ClavisLoanManager::LOAN_LOANED :
							$messageBody = Prado::localize("Prestito eseguito correttamente");
							$messageType = ClavisMessage::CONFIRM;
							$toRefreshFlag = true;
							
							break;

						case ClavisLoanManager::LOAN_LOANALREADYEXISTS :

							$messageBody = Prado::localize("Errore: il prestito è già in corso");
							$messageType = ClavisMessage::ERROR;
							
							break;

						case ClavisLoanManager::ERROR :
						default:

							$messageBody = Prado::localize("Prestito fallito");
							$messageType = ClavisMessage::ERROR;
					}

					break;

				case ClavisLoanManager::RSV_ALREADYMANAGED:
					$messageBody = Prado::localize("La prenotazione con id: {id} è già in gestione", 
														array('id' => $itemRequestId));
					
					$messageType = ClavisMessage::ERROR;
					
					break;

				case ClavisLoanManager::RSV_ALREADYCLOSED:
					$messageBody = Prado::localize("La prenotazione con id: {id} è già soddisfatta o chiusa o annullata", 
														array('id' => $itemRequestId));
					
					$messageType = ClavisMessage::ERROR;
					
					break;

				case ClavisLoanManager::LOAN_PATRONNOTENABLED:
					$this->getPage()->enqueueMessage(Prado::localize("La prenotazione con id: {id} non è soddisfacibile perché l'utente non è ammesso al prestito", 
																		array('id' => $itemRequestId)), 
														ClavisMessage::ERROR);
					
					break;

				case ClavisLoanManager::LOAN_EXTERNALLIBRARYNOTENABLED:
					$this->getPage()->enqueueMessage(Prado::localize("La prenotazione con id: {id} non è soddisfacibile perché la biblioteca esterna, destinataria del prestito extrasistema, non è ammessa al prestito", 
																		array('id' => $itemRequestId)), 
														ClavisMessage::ERROR);
					
					break;

				case ClavisLoanManager::ERROR:
				default:
					$messageBody = Prado::localize("Errore sconosciuto sulla presa in gestione della prenotazione con id: {id}", 
														array('id' => $itemRequestId));
					
					$messageType = ClavisMessage::ERROR;
			}

			$scriptMgr = $this->getPage()->getClientScript();

			if ($toRefreshFlag) 
			{
				$this->getPage()->writeDelayedMessage($messageBody, $messageType);
				$this->getApplication()->getSession()->add('UpdateItemRequests', true);
				$scriptMgr->registerEndScript('parentSubmit', 'parent.onSubmit();');
			}
			else
			{
				$this->getPage()->writeMessage($messageBody, $messageType);
			}

			$scriptMgr->registerEndScript('popupClose', 'onClose();');
		}
	}

	public function globalRefresh() 
	{
		$this->populate();
	}

	/**
	 * It sets the parameters for filtering results.
	 *
	 * @param int $librarianId
	 * @param int $fromLibraryId
	 * @param int $toLibraryId
	 * @param int $patronId
	 * @param int $renewCount
	 * @param date $outDateFrom
	 * @param date $outDateTo
	 * @param string $statusList
	 * @param string $section
	 * @param string $collocation
	 * @param string $barcode
	 * $param string $bibObj
	 */
	public function setFilters(	$librarianId = null, 
								$fromLibraryId, 
								$toLibraryId, 
								$patronId = null, 
								$renewCount = null, 

								$outDateFrom = null, 
								$outDateTo = null, 
								$statusList = null, 
								$section = null, 
								$collocation = null, 

								$barcode = "", 
								$bibObj = null, 
								$notManageableFlag = false ) 
	{
		if ($fromLibraryId == 0)
			$fromLibraryId = null;

		if ($toLibraryId == 0)
			$toLibraryId = null;

		if ($patronId == 0)
			$patronId = null;
		
		if ($renewCount == 0)
			$renewCount = null;
		
		if ($outDateFrom == '')
			$outDateFrom = null;
		
		if ($outDateTo == '')
			$outDateTo = null;

		if (is_array($statusList) && (count($statusList) == 0))
			$statusList = null;

		if (!TPropertyValue::ensureBoolean($notManageableFlag))
			$notManageableFlag = false;

		if ($section == '')
			$section = null;

		if ($collocation == '')
			$collocation = null;

		$this->setLibrarianIdFilter($librarianId);
		$this->setFromLibraryId($fromLibraryId);
		$this->setToLibraryId($toLibraryId);

		$this->setPatronId($patronId);
		$this->setRenewCount($renewCount);
		$this->setOutDateFrom($outDateFrom);
		$this->setOutDateTo($outDateTo);

		$this->setStatusList($statusList);
		$this->setNotManageableFlag($notManageableFlag);

		$this->setSection($section);
		$this->setCollocation($collocation);

		$this->setBarcodeFilter($barcode);
		$this->setBibObjFilter($bibObj);

		$this->resetPagination();
	}

	/**
	 * It sets the property $_toLibraryId
	 *
	 * @param int $lib
	 */
	public function setToLibraryId($lib) 
	{
		$this->_toLibraryId = $lib;
		$this->setViewState('toLibraryId', $this->_toLibraryId, null);
	}

	/**
	 * It returns the property $_toLibraryId
	 *
	 * @return int
	 */
	public function getToLibraryId() 
	{
		if (($lib = $this->_toLibraryId) == null) 
		{
			$lib = $this->getViewState('toLibraryId', null);
			$this->_toLibraryId = $lib;
		}
		
		return $lib;
	}

	public function setFromLibraryId($lib) 
	{
		$this->_fromLibraryId = $lib;
		$this->setViewState('fromLibraryId', $this->_fromLibraryId, null);
	}

	public function getFromLibraryId() 
	{
		if (($lib = $this->_fromLibraryId) == null) 
		{
			$lib = $this->getViewState('fromLibraryId', null);
			$this->_fromLibraryId = $lib;
		}
		
		return $lib;
	}

	/**
	 * It sets the property $_patronId
	 *
	 * @param int $id
	 */
	public function setPatronId($id) 
	{
		$this->_patronId = $id;
		$this->setViewState('patronId', $this->_patronId, null);
	}

	/**
	 * It returns the property $_patronId
	 *
	 * @return int
	 */
	public function getPatronId() 
	{
		if (($id = $this->_patronId) == null) 
		{
			$id = $this->getViewState('patronId', null);
			$this->_patronId = $id;
		}
		
		return $id;
	}

	/**
	 * It sets the property $_renewCount
	 *
	 * @param int $count
	 */
	public function setRenewCount($count) 
	{
		$this->_renewCount = $count;
		$this->setViewState('renewCount', $this->_renewCount, null);
	}

	/**
	 * It returns the property $_renewCount
	 *
	 * @return int
	 */
	public function getRenewCount() 
	{
		if (($count = $this->_renewCount) == null) 
		{
			$count = $this->getViewState('renewCount', null);
			$this->_renewCount = $count;
		}
		
		return $count;
	}

	/**
	 * It sets the property $_outDateFrom
	 *
	 * @param int $timestamp
	 */
	public function setOutDateFrom($date) 
	{
		$this->_outDateFrom = $date;
		$this->setViewState('outDateFrom', $this->_outDateFrom, null);
	}

	/**
	 * It returns the property $_outDateFrom
	 *
	 * @return int
	 */
	public function getOutDateFrom() 
	{
		if (($date = $this->_outDateFrom) == null) 
		{
			$date = $this->getViewState('outDateFrom', null);
			$this->_outDateFrom = $date;
		}
		
		return $date;
	}

	/**
	 * It sets the property $_outDateTo
	 *
	 * @param int $timestamp
	 */
	public function setOutDateTo($date) 
	{
		$this->_outDateTo = $date;
		$this->setViewState('outDateTo', $this->_outDateTo, null);
	}

	/**
	 * It returns the property $_outDateTo
	 *
	 * @return int
	 */
	public function getOutDateTo() 
	{
		if (($date = $this->_outDateTo) == null) 
		{
			$date = $this->getViewState('outDateTo', null);
			$this->_outDateTo = $date;
		}
		
		return $date;
	}

	public function setStatusList($list = null) 
	{
		$this->_statuslist = $list;
		$this->setViewState('statusList', $this->_statuslist, null);
	}

	public function getStatusList() 
	{
		$this->_statuslist = $this->getViewState('statusList', null);
		
		return $this->_statuslist;
	}

	public function setNotManageableFlag($flag = false) 
	{
		$this->setViewState('notManageableFlag', $flag, false);
	}

	public function getNotManageableFlag() 
	{
		return $this->getViewState('notManageableFlag', false);
	}

	public function setSection($section = null) 
	{
		$this->_section = $section;
		$this->setViewState('section', $this->_section, null);
	}

	public function getSection() 
	{
		$this->_section = $this->getViewState('section', null);
		
		return $this->_section;
	}

	public function setCollocation($collocation = null) 
	{
		$this->_collocation = $collocation;
		$this->setViewState('collocation', $this->_collocation, null);
	}

	public function getCollocation() 
	{
		$this->_collocation = $this->getViewState('collocation', null);
		
		return $this->_collocation;
	}

	public function resetBarcodeFilter($barcode = '') 
	{
		$this->setBarcodeFilter($barcode);
	}

	public function setBarcodeFilter($barcode = '') 
	{
		$this->setViewState($this->_barcodeFilterSessionName, $barcode, '');
	}

	public function getBarcodeFilter() 
	{
		return $this->getViewState($this->_barcodeFilterSessionName, '');
	}

	public function resetBibObjFilter($param = null) 
	{
		$this->setBibObjFilter($param);
	}

	public function setBibObjFilter($param = null) 
	{
		$this->setViewState($this->_bibObjFilterSessionName, $param, null);
	}

	public function getBibObjFilter() 
	{
		return $this->getViewState($this->_bibObjFilterSessionName, null);
	}

	public function setLibrarianIdFilter($id = null) 
	{
		$this->setViewState("librarianIdFilter", $id, null);
	}

	public function getLibrarianIdFilter() 
	{
		$this->_librarianId = $this->getViewState("librarianIdFilter", null);
		
		return $this->_librarianId;
	}

	public function getSortingExpression() 
	{
		return $this->Grid->getSortingExpression();
	}

	public function getSortingDirection() 
	{
		return $this->Grid->getSortingDirection();
	}

}