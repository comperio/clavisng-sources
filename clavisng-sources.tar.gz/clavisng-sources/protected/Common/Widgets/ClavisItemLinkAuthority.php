<?php
/**
 * ClavisItemLinkAuthority
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2009 Comperio srl
 */
class ClavisItemLinkAuthority extends TTemplateControl
{
	public function getItemId()
	{
		return $this->getControlState('ItemId', null);
	}

	public function setItemId($itemId)
	{
		$this->setControlState('ItemId', $itemId, null);
	}

	public function populate()
	{
		$c = new Criteria();
		$c->add(LAuthorityItemPeer::ITEM_ID, $this->getItemId());
		$this->Grid->setLinkClass('LAuthorityItem');
		$this->Grid->setLinkCriteria($c);
		$this->Grid->setCanErase(!$this->getReadOnly());
		$this->Grid->populate();
	}

	public function calculateSortingCriteria(&$sortingCriteria = null)
	{
		$sortingExpression = $this->Grid->getSortingExpression();
		$sortingDirection = $this->Grid->getSortingDirection();

		if (is_null($sortingCriteria) || !($sortingCriteria instanceof Criteria))
			$sortingCriteria = new Criteria();

		switch ($sortingExpression)
		{

			case 'title':
				$sortingCriteria->clearOrderByColumns();
				$sortingCriteria->addJoin(LAuthorityManifestationPeer::MANIFESTATION_ID, ManifestationPeer::MANIFESTATION_ID);

				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
				{
					$sortingCriteria->addAscendingOrderByColumn(ManifestationPeer::TITLE);
					$sortingCriteria->addAscendingOrderByColumn(ManifestationPeer::PUBLISHER);
				}
				elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
				{
					$sortingCriteria->addDescendingOrderByColumn(ManifestationPeer::TITLE);
					$sortingCriteria->addDescendingOrderByColumn(ManifestationPeer::PUBLISHER);
				}
				break;

			case 'year':
				$sortingCriteria->clearOrderByColumns();
				$sortingCriteria->addJoin(LAuthorityManifestationPeer::MANIFESTATION_ID, ManifestationPeer::MANIFESTATION_ID);

				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
				{
					$sortingCriteria->addAscendingOrderByColumn(ManifestationPeer::EDITION_DATE);
				}
				elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
				{
					$sortingCriteria->addDescendingOrderByColumn(ManifestationPeer::EDITION_DATE);
				}
				break;

			case null:
				break;

			default:
				$sortingExpression = null;
				break;
		}
	}

	public function setReadOnly($value)
	{
		return $this->setControlState('ReadOnly', TPropertyValue::ensureBoolean($value), false);
	}

	public function getReadOnly()
	{
		return $this->getControlState('ReadOnly', false);
	}

	public function onDeleteLink($sender, $param)
	{
		$id = $this->Grid->DataKeys[$param->Item->ItemIndex];
		$keys = explode('|', $id);
		LAuthorityManifestationPeer::doDelete($keys);

		/* reindex manifestation */
		$deletableManifestation = ManifestationPeer::retrieveByPK($keys[1]);
		if ($deletableManifestation instanceof Manifestation)
			$deletableManifestation->invalidateCache();

		$this->populate();
	}

	public function onChangePage($sender, $param)
	{
		$sender->setCurrentPage($param->NewPageIndex);
		$this->populate();
	}
	
}