<?php
/**
 * ClavisTurbomarcView class file
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 */

/**
 * ClavisTurbomarcView class
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Widgets
 * @since 2.6
 */
class ClavisTurbomarcView extends TTemplateControl
{
	public $sbn_enabled = false;

	/* @var Manifestation|Authority */
	private $_object = null;

	public function onLoad($param)
	{
		parent::onLoad($param);
		$control = $this;
		do
			if (method_exists($control = $control->getParent(), 'getManifestation'))
				$this->_object = $control->getManifestation();
			else if (method_exists($control, 'getAuthority'))
				$this->_object = $control->getAuthority();
		while (!$control instanceof TPage);
		$_sbnMod = $this->getApplication()->getModule('sbn');
		$this->sbn_enabled = $_sbnMod instanceof TModule && $_sbnMod->getEnabled();
		$this->enableButtons();
	}

	private function enableButtons()
	{
		$this->DisplayTurbomarc->setVisible(false);
		$this->DisplayFullTurbomarc->setVisible(false);
		$this->DisplaySolrDoc->setVisible(false);
		$this->DisplaySBNMarc->setVisible(false);
		$this->DisplayRemoteSBNMarc->setVisible(false);
		if ($this->_object)
		{
			$this->DisplayTurbomarc->setVisible(method_exists($this->_object, 'getTurboMarc'));
			$this->DisplayFullTurbomarc->setVisible(method_exists($this->_object, 'getFullTurboMarc'));
			if ($this->_object instanceof Manifestation || $this->_object instanceof Authority)
			{
				$this->DisplaySolrDoc->setVisible(true);
				$this->DisplaySBNMarc->setVisible($this->sbn_enabled);
				$this->DisplayRemoteSBNMarc->setVisible($this->sbn_enabled);
			}
		}
	}

	public function sendMARCXML($sender, $param)
	{
		$resp = $this->getResponse();
		$resp->clear();
		$resp->setCacheControl('nocache');
		$resp->writeFile('marcxml.xml', $this->_object->getFullTurboMarc()->asXML(), 'text/xml');
	}

	public function sendISO2709($sender, $param)
	{
		$resp = $this->getResponse();
		$resp->clear();
		$resp->setCacheControl('nocache');
		$resp->writeFile('iso2709.txt', $this->_object->getFullTurboMarc()->getISO2709(), 'text/txt');
	}

	public function sendTurboMarc($sender, $param)
	{
		$resp = $this->getResponse();
		$resp->clear();
		$resp->setCacheControl('nocache');
		$resp->writeFile('turbomarc.xml', $this->_object->getTurboMarc()->asXML(), 'text/xml');
	}

	public function displayTurboMarc($sender, $param)
	{
		$dom = new DOMDocument();
		$dom->preserveWhiteSpace = false;
		$dom->formatOutput = true;
		$dom->loadXML($this->_object->getTurboMarc()->asXML());
		$this->TurboMarcDisplay->setText($dom->saveXML());
		$this->TurboMarcDisplayLabel->setText(Prado::localize('TurboMarc'));
		$this->TurboMarcDisplay2->setText('');
		$this->TurboMarcDisplayLabel2->setText('');
	}

	public function displayFullTurboMarc($sender, $param)
	{
		$dom = new DOMDocument();
		$dom->preserveWhiteSpace = false;
		$dom->formatOutput = true;
		$dom->loadXML(TurboMarcUtility::sortFields($this->_object->getFullTurboMarc(true, false), true));
		$this->TurboMarcDisplay->setText($dom->saveXML());
		$this->TurboMarcDisplayLabel->setText(Prado::localize('TurboMarc completo (full)'));
		$this->TurboMarcDisplay2->setText('');
		$this->TurboMarcDisplayLabel2->setText('');
	}

	public function displaySolrDoc($sender, $param)
	{
		$search = $this->getApplication()->getModule('search');
		$tm = $this->_object->getFullTurboMarc(true, false);
		$dbName = $search->getDatabaseName();
		if ($this->_object instanceof Manifestation)
			$doc = TurboMarc2Solr::getSolrDoc($tm, $this->_object->getId(), $dbName, $search->getRecordCollection());
		else if ($this->_object instanceof Authority)
			$doc = Authority2Solr::getSolrDoc($tm, $this->_object->getId(), $dbName, $search->getAuthorityCollection());
		$dom = new DOMDocument();
		$dom->preserveWhiteSpace = false;
		$dom->formatOutput = true;
		$dom->loadXML($doc);
		$this->TurboMarcDisplay->setText($dom->saveXML());
		$this->TurboMarcDisplayLabel->setText(Prado::localize('SolrDoc'));
		$this->TurboMarcDisplay2->setText('');
		$this->TurboMarcDisplayLabel2->setText('');
	}

	public function displaySBNMarc($sender, $param)
	{
		$tm = TurboMarcUtility::sortFields($this->_object->getFullTurboMarc(false, false));
		$dom = new DOMDocument();
		$dom->preserveWhiteSpace = false;
		$dom->formatOutput = true;
		$dom->loadXML(SBNConverter::Turbomarc2SBN($tm, true));
		$this->TurboMarcDisplay->setText($dom->saveXML());
		$this->TurboMarcDisplayLabel->setText(Prado::localize('SBNMarc'));

		// for debugging purposes
		$dom = new DOMDocument();
		$dom->preserveWhiteSpace = false;
		$dom->formatOutput = true;
		$dom->loadXML($tm->asXML());
		$this->TurboMarcDisplay2->setText($dom->saveXML());
		$this->TurboMarcDisplayLabel2->setText(Prado::localize('Source Turbomarc'));
	}

	public function displaySBNMarcIndex($sender, $param)
	{
		/* @var $request SBNRequest */
		$request = $this->getApplication()->getModule('sbn')->getNewRequest();
		switch (get_class($this->_object))
		{
			case 'Manifestation':
				$sbn_response = $request->searchTitleByBid($this->_object->getBid());
				break;
			case 'Authority':
				$sbn_response = $request->searchAuthorityByBid($this->_object->getBid(), SBNConverter::ClavisType2SBNType($this->_object->getAuthorityType()));
				break;
		}
		$dom = new DOMDocument();
		$dom->preserveWhiteSpace = false;
		$dom->formatOutput = true;
		$dom->loadXML($sbn_response->SbnMessage->SbnResponse->SbnOutput->asXML());
		$this->TurboMarcDisplay->setText($dom->saveXML());
		$this->TurboMarcDisplayLabel->setText(Prado::localize('SBNMarc indice'));

		// for debugging purposes
		$dom = new DOMDocument();
		$dom->preserveWhiteSpace = false;
		$dom->formatOutput = true;
		if ($sbn_response && '0000' == (string) $sbn_response->SbnMessage->SbnResponse->SbnResult->esito)
		{
			$xml = TurboMarcUtility::sortFields(SBNConverter::SBN2Turbomarc($sbn_response, true), true);
			$dom->loadXML($xml);
			$this->TurboMarcDisplay2->setText($dom->saveXML());
		}
		$this->TurboMarcDisplayLabel2->setText(Prado::localize('Turbomarc converted'));
	}
	
}