<?php

/**
 * ClavisConsistencyList class
 * 
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2009 Comperio srl
 * @version 2.7
 * @package Widgets
 * @since 2.3
 */
class ClavisConsistencyList extends TTemplateControl
{
	const ICON_DELIVERED = 'check-16.png';
	const ICON_NOT_DELIVERED = 'delete-16.png';
	private $_manifestation;
	private $_issue;
	private $_item_request;
	private $_purchase_order;
	private $_invoice;
	private $_filter = null;
	public $_item;
	public $_masterChecked;
	private $_checked = array('all' => false);
	private $_checkedSessionName;
	private $_datasource;
	private $_datasourceSessionName;
	private $_globalCriteria;

	public function onInit($param)
	{
		parent::onInit($param);
		$this->attachEventHandler('OnActualLibraryChanged', array($this, 'OnActualLibraryChanged'));

		$uniqueId = $this->getUniqueID();
		$this->_datasourceSessionName = 'DataSourceSessionName' . $uniqueId;
		$this->_checkedSessionName = 'CheckedSessionName' . $uniqueId;
		$this->_checked = $this->getCheckedItems();
	}

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallBack())
		{
			$this->resetDataSource();
		}
	}

	public function OnActualLibraryChanged($sender, $param)
	{
		$this->resetDataSource();
	}

	public function setGlobalCriteria($criteria = null)
	{
		$this->setViewState('GlobalCriteria', $criteria, null);
	}

	public function getGlobalCriteria()
	{
		return SerializableCriteria::refreshCriteria(
						$this->getViewState('GlobalCriteria', null));
		return $this->_globalCriteria;
	}

	public function setExternalCriteria($criteria = null)
	{
		$this->setControlState('ExternalCriteria', $criteria, null);
	}

	public function getExternalCriteria()
	{
		$output = $this->getControlState('ExternalCriteria', null);
		if (is_null($output))
			return $output;
		return clone($output);
	}

	public function resetExternalCriteria()
	{
		$this->setExternalCriteria(new Criteria());
	}

	public function resetDataSource()
	{
		$this->ConsistencyGrid->resetPagination();
		$this->resetCheckedItems();

		$this->_datasource = array();
		$this->getApplication()->getSession()->add($this->_datasourceSessionName, $this->_datasource);

		$this->resetSorting();

		$this->populate();
	}

	public function setDatasource($datasource = null)
	{
		$this->_datasource = $datasource;
		$this->getApplication()->getSession()->add($this->_datasourceSessionName, $datasource);
	}

	public function getDatasource()
	{
		$this->_datasource = $this->getApplication()->getSession()->itemAt($this->_datasourceSessionName);
		return $this->_datasource;
	}

	public function onFlipChecked($sender, $param)
	{
		$checked = $this->getCheckedItems();

		$index = $sender->Parent->Parent->ItemIndex;
		$newStatus = $sender->getChecked();
		$dataSource = $this->getDatasource();

		$row = $dataSource[$index];
		$patronId = $row['Id'];

		if ($newStatus != $checked['all'])
			$checked[$patronId] = true;
		else
			unset($checked[$patronId]);

		$this->setCheckedItems($checked);
	}

	public function onMasterChecked($sender, $param)
	{
		$newStatus = $sender->getChecked();
		$this->resetCheckedItems($newStatus);

		$gridItems = $this->ConsistencyGrid->getItems();
		foreach ($gridItems as $item)
			$item->CheckColumn->CheckedBox->setChecked($newStatus);

		//$this->populate();
	}

	public function resetCheckedItems($state = false)
	{
		$this->setCheckedItems(array('all' => $state));
	}

	public function setCheckedItems($checked = null)
	{
		$this->_checked = $checked;
		$this->getApplication()->getSession()->add($this->_checkedSessionName, $checked);
	}

	public function getCheckedItems()
	{
		$this->_checked = $this->getApplication()->getSession()->itemAt($this->_checkedSessionName);
		return $this->_checked;
	}

	public function getCheckedId()
	{
		$checked = $this->getCheckedItems();

		$this->_masterChecked = $checked['all'];
		unset($checked['all']);
		$checkedIds = array_keys($checked);

		$output = array();

		if (!$this->_masterChecked)
		{
			$output = $checkedIds;
		}
		else		 // lo strano caso del mastercheck inverso
		{
			$items = null;
			$criteria = $this->getGlobalCriteria();

			if (!is_null($criteria) && ($criteria instanceof Criteria))
			{
				$criteria->add(ItemPeer::ITEM_ID, $checkedIds, Criteria::NOT_IN);
				$items = ItemPeer::doSelect($criteria);
				foreach ($items as $item)
					$output[] = $item->getItemId();
			}
			else if (!is_null($criteria) && (is_array($criteria)))
			{
				$output = array_fill_keys(array_diff($criteria, $checkedIds), true);
			}
		}
		return $output;
	}

	/**
	 * Setter method of object manifestation.
	 *
	 * @param Manifestation $manifestation
	 */
	public function setManifestation($manifestation)
	{
		$this->_manifestation = $manifestation;
		$this->setControlState('manifestation', $manifestation, null);
	}

	/**
	 * Getter method of object manifestation.
	 *
	 * @return Manifestation
	 *
	 */
	public function getManifestation()
	{
		if (is_null($this->_manifestation))
			$this->_manifestation = $this->getControlState('manifestation', null);
		return $this->_manifestation;
	}

	public function resetGivenItemIds()
	{
		$this->setGivenItemIds(array());
	}

	public function setGivenItemIds($ids)
	{
		$this->setControlState('GivenItemIds', $ids, array());
	}

	public function getGivenItemIds()
	{
		return TPropertyValue::ensureArray($this->getControlState('GivenItemIds', array()));
	}

	/**
	 * Setter method of filter.
	 *
	 * @param string $filter
	 */
	public function setFilter($filter = null)
	{
		$this->_filter = $filter;
		$this->setViewState('filter', $filter, null);
	}

	/**
	 * Getter method of filter.
	 *
	 * @return string
	 *
	 */
	public function getFilter()
	{
		//if(is_null($this->_manifestation))
		$this->_filter = $this->getViewState('filter', null);
		return $this->_filter;
	}

	public function resetExternalRecCount()
	{
		$this->setExternalRecCount(0);
	}

	public function setExternalRecCount($count)
	{
		$this->setControlState('ExternalRecCount', $count, 0);
	}

	public function getExternalRecCount()
	{
		return TPropertyValue::ensureInteger($this->getControlState('ExternalRecCount', 0));
	}

	public function calculateSortingCriteria(&$sortingCriteria = null)
	{
		$sortingExpression = $this->ConsistencyGrid->getSortingExpression();
		$sortingDirection = $this->ConsistencyGrid->getSortingDirection();

		if (is_null($sortingCriteria) || !($sortingCriteria instanceof Criteria))
			$sortingCriteria = new Criteria();

		switch ($sortingExpression)
		{
			default:
				$sortingExpression = null;
				break;
		}
	}

	public function populate()
	{
		/* @var $criteria Criteria */

		$pageSize = $this->ConsistencyGrid->getPageSize();
		$currentPage = $this->ConsistencyGrid->getCurrentPage();

		$criteria = new Criteria();

		$actualLibraryId = $this->getUser()->getActualLibraryId();
		switch ($this->getFilter())
		{
			case 'mine':
				$criteria->add(ItemPeer::HOME_LIBRARY_ID, $actualLibraryId);
				$this->ThisLibrary->setVisible(false);
				break;

			case 'other':
				$criteria->add(ItemPeer::HOME_LIBRARY_ID, $actualLibraryId, Criteria::NOT_EQUAL);
				break;

			default:
				break;
		}

		$checked = $this->getCheckedItems();
		$this->_masterChecked = $checked['all'];
		$manifestation = $this->getManifestation();
		if (!$manifestation instanceof Manifestation)
			return false;

		$recCount = $manifestation->countConsistencyNotes($criteria);
		$this->RecCounter->setText($recCount);

		$criteria->setLimit($pageSize);
		$criteria->setOffset($pageSize * $currentPage);

		$cn = $manifestation->getConsistencyNotes($criteria);

		$this->ConsistencyGrid->setVirtualItemCount($recCount);
		$this->ConsistencyGrid->setDataSource($cn);
		$this->setDatasource($cn);
		$this->ConsistencyGrid->dataBind();

		return $recCount;
	}

	public function globalRefresh()
	{
		$this->resetSorting();
		$this->ConsistencyGrid->resetPagination();
		$this->populate();
	}

	public function resetSorting()
	{
		$this->ConsistencyGrid->resetSorting('', null, false);
	}

	/**
	 * It manages the change of page in the datagrid.
	 * It uses the viewstate to store the current page.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onChangePage($sender, $param)
	{
		$this->ConsistencyGrid->setCurrentPage($param->NewPageIndex);
		$this->getPage()->globalRefresh();
	}

	public function getPopupFlag()
	{
		return $this->getPage()->isPopup();
	}

	public function getUnlinkFlag()
	{
		return $this->getPage()->isUnlink();
	}

	public function getDeleteFlag()
	{
		return $this->getPage()->isDelete();
	}

	public function onUnlink($sender, $param)
	{
		$id = $param->CommandParameter;
		//
		$this->getPage()->Unlink($id);
	}

	public function resetPagination()
	{
		$this->ConsistencyGrid->resetPagination();
	}

	public function getPageSize()
	{
		return $this->ConsistencyGrid->getPageSize();
	}

	public function setPageSize($size)
	{
		$this->ConsistencyGrid->setPageSize($size);
	}

	public function getCurrentPage()
	{
		return $this->ConsistencyGrid->getCurrentPage();
	}

	public function setCurrentPage($page)
	{
		$this->ConsistencyGrid->setCurrentPage($page);
	}
}