<?php
/**
 * ClavisNotificationList class
 *
 * @author Ciro Mattia Gonano
 * @author Marco Brancalion <marco@comperio.it>
 * @link https://www.comperio.it/
 * @copyright Copyright &copy; 2006-2017 ePortal Technologies
 * @copyright Copyright &copy; 2008 Comperio srl
 * @license https://www.comperio.it/license/
 * @version 2.8.5
 * @package Widgets
 * @since 2.4
 */

class ClavisNotificationList extends TTemplateControl
{
	private $_librarian;

	public function onLoad($param)
	{
		parent::onLoad($param);

		// first page cycle
		if (!$this->getPage()->getIsPostBack())
		{
			$this->SenderLibraryFilter->setDataSource(LibraryPeer::getLibrariesHashWithBlank(true, true));	// only active and internal ones
			$this->SenderLibraryFilter->dataBind();
			$this->SenderLibraryFilter->setSelectedValue($this->getUser()->getActualLibraryId());
			
			$this->StatusFilter->setSelectedValue(NotificationPeer::STATUS_PENDING);
		
			$this->populate();
		}
	}

	public function setLibrarian($librarian)
	{
		$this->_librarian = $librarian;
		$this->setControlState('librarian', $librarian, null);
	}

	public function getLibrarian()
	{
		if (is_null($this->_librarian))
			$this->_librarian = $this->getControlState('librarian', null);
		
		return $this->_librarian;
	}

	public function setFilterVisible($value)
	{
		$bVal = ($value == 'true' ? true : false);
		$this->setControlState('filter_visible', $bVal);
	}

	public function getFilterVisible()
	{
		$val = ($this->getControlState('filter_visible', true) == true ? 'true' : 'false');

		return $val;
	}

	public function setObjectClass($value)
	{
		$this->setControlState('object_class', $value, null);
	}

	public function getObjectClass()
	{
		return $this->getControlState('object_class',null);
	}

	public function setObjectId($value)
	{
		$this->setControlState('object_id', $value, null);
	}

	public function getObjectId()
	{
		return $this->getControlState('object_id',null);
	}

	public function setFromLatest($value)
	{
		$this->setControlState('from_latest', $value);
	}

	public function getFromLatest()
	{
		return $this->getControlState('from_latest', 'false');
	}

	public function setViewOnly($value)
	{
		$this->setControlState('view_only', $value);
	}

	public function getViewOnly()
	{
		return $this->getControlState('view_only', 'false');
	}

	public function populate()
	{
		$pageSize = $this->NotificationGrid->getPageSize();
		$currentIndexPage = $this->NotificationGrid->getCurrentPage();

		$criteria = new Criteria();

		if ($this->getFilterVisible() == 'true')
		{
			$this->NotificationFilterPanel->setVisible(true);
			$objectTypeFilter = $this->ObjectTypeFilter->getSelectedValue();
			
			if ($objectTypeFilter)
			{
				$criteria->addAnd(NotificationPeer::OBJECT_CLASS, $objectTypeFilter);

				if ($this->ObjectLabel->getText() != '')
				{
					$objectId = $this->ObjectID->getValue();
				
					if ($objectId > 0)
						$criteria->addAnd(NotificationPeer::OBJECT_ID, $objectId);
				}
			}

			$notificationClassFilter = $this->NotificationClassFilter->getSelectedValue();

			if ($notificationClassFilter)
			{
				$criteria->addAnd(NotificationPeer::NOTIFICATION_CLASS, $notificationClassFilter);
				$this->ClassColumn->setVisible(false);
			}
			else
			{
				$this->ClassColumn->setVisible(true);
			}

			$channelTypeFilter = $this->ChannelFilter->getSelectedValue();
			
			if ($channelTypeFilter)
		    {
				$criteria->addAnd(NotificationPeer::NOTIFICATION_CHANNEL, $channelTypeFilter);
				$this->ChannelColumn->setVisible(false);
			}
			else
			{
				$this->ChannelColumn->setVisible(true);
			}

			$statusFilter = $this->StatusFilter->getSelectedValue();

			if ($statusFilter)
		    {
				$criteria->addAnd(NotificationPeer::NOTIFICATION_STATE, $statusFilter);
				$this->StatusColumn->setVisible(false);
			}
			else
			{
				$this->StatusColumn->setVisible(true);
			}

			$dateCreatedFrom = $this->DateCreatedFromFilter->getTimestamp();
			
			if ($dateCreatedFrom != null)
				$criteria->addAnd(NotificationPeer::DATE_CREATED, $dateCreatedFrom, Criteria::GREATER_EQUAL);

			$dateCreatedEnd = $this->DateCreatedToFilter->getTimestamp();

			if ($dateCreatedEnd != null)
				$criteria->addAnd(NotificationPeer::DATE_CREATED, $dateCreatedEnd + 86399, Criteria::LESS_EQUAL);

			$deliveryDateFrom = $this->DeliveryDateFromFilter->getTimestamp();
			
			if ($deliveryDateFrom != null)
				$criteria->addAnd(NotificationPeer::DELIVERY_DATE, $deliveryDateFrom, Criteria::GREATER_EQUAL);

			$deliveryDateEnd = $this->DeliveryDateToFilter->getTimestamp();

			if ($deliveryDateEnd != null)
				$criteria->addAnd(NotificationPeer::DELIVERY_DATE, $deliveryDateEnd + 86399, Criteria::LESS_EQUAL);

			$senderLibraryFilter = intval($this->SenderLibraryFilter->getSelectedValue());

			if ($senderLibraryFilter > 0)
		    {
				$criteria->addAnd(NotificationPeer::SENDER_LIBRARY_ID, $senderLibraryFilter);
				$this->SenderLibraryColumn->setVisible(false);
			}
			else
			{
				$this->SenderLibraryColumn->setVisible(true);
			}
		} 
		else 
		{
			$this->NotificationFilterPanel->setVisible(false);

			if (!is_null($objectClass = $this->getObjectClass()))
			{
				$criteria->addAnd(NotificationPeer::OBJECT_CLASS, $objectClass);
				//$this->ObjectTypeCol->setVisible(false);
			}

			if (!is_null($objectId = $this->getObjectId()))
			{
				$criteria->addAnd(NotificationPeer::OBJECT_ID, $objectId);
				$this->ObjectDestinationCol->setVisible(false);
			}
		}

		$this->getLibrarian();
		
		if ($this->_librarian != null)
			$criteria->add(NotificationPeer::CREATED_BY, $this->getLibrarian()->getLibrarianId());

		$recCount = NotificationPeer::doCount($criteria);
		
		$this->FoundNumber->setText($recCount);
	    //$this->RecCounterPanel->setVisible($recCount > 0);
		$this->NotificationGrid->VirtualItemCount = $recCount;

		if ($this->getFromLatest() == 'false')
		{
			$this->NotificationGrid->resetSorting('dateCreated', TClavisDataGrid::SORTDIRECTION_ASC, false);
		} 
		else 
		{
			$this->NotificationGrid->resetSorting('dateCreated', TClavisDataGrid::SORTDIRECTION_DESC, false);
		}

		$this->calculateSortingCriteria($criteria);

		$criteria->setLimit($pageSize);
		$criteria->setOffset($currentIndexPage * $pageSize);

		$notifications = NotificationPeer::doSelect($criteria);

		/* @var $notification Notification */
		$data = array();
		
		foreach ($notifications as $notification)
		{
			$p = array();
		
			$p['NotificationState'] = LookupValuePeer::getLookupValue('NOTIFICATIONSTATE', $notification->getNotificationState());
			
			$notificationClassRaw = $notification->getNotificationClass();
			
			if (is_null($notificationClassRaw))
			{
				$notificationClass = Prado::localize("nessuna classe");
			}
			else
			{
				$notificationClass = LookupValuePeer::getLookupValue('NOTIFICATIONCLASS', $notificationClassRaw);
			}
			
			$p['NotificationClass'] = $notificationClass;
			
			$p['NotificationChannel'] = LookupValuePeer::getLookupValue('NOTIFICATIONCHANNEL', $notification->getNotificationChannel());

			$objectClassValue = LookupValuePeer::getLookupValue('NOTIFICATIONOBJECTTYPE', $notification->getObjectClass());
			$p['ObjectClass'] = $objectClassValue;
			$p['ObjectId'] = 0;
			$p['ObjectName'] = '---';
			$p['NavigateUrl'] = '';

			$objectId = $notification->getObjectId();

			if (intval($objectId) > 0) 
			{
				$p['ObjectId'] = $objectId;

				switch (strtolower($notification->getObjectClass()))
				{
					case 'library':
						$library = LibraryQuery::create()->findPk($objectId);
				
						if ($library instanceof Library)
						{
							$p['ObjectName'] = $library->getLabel();
							$p['NavigateUrl'] = LibraryPeer::getNavigateUrl($objectId);
						}
						else
						{
							$p['ObjectName'] = "(id =" . $objectId . ")";
							$p['NavigateUrl'] = '';
						}
						
						break;

					case 'librarian':
						$librarian = LibrarianQuery::create()->findPk($objectId);
						
						if ($librarian instanceof Librarian)
						{
							$p['ObjectName'] = $librarian->getCompleteName();
							$p['NavigateUrl'] = LibrarianPeer::getNavigateUrl($objectId);
						}
						else
						{
							$p['ObjectName'] = "(id =" . $objectId . ")";
							$p['NavigateUrl'] = '';
						}
						
						break;

					case 'patron':
						$patron = PatronQuery::create()->findPk($objectId);
						
						if ($patron instanceof Patron)
						{
							$p['ObjectName'] = $patron->getCompleteName();
							$p['NavigateUrl'] = PatronPeer::getNavigateUrl($objectId);
						}
						else
						{
							$p['ObjectName'] = "(id =" . $objectId . ")";
							$p['NavigateUrl'] = '';
						}
						
						break;

					case 'supplier': //fornitore
						$supplier = SupplierQuery::create()->findPk($objectId);
						
						if ($supplier instanceof Supplier)
						{
							$p['ObjectName'] = $supplier->getSupplierName();
							$p['NavigateUrl'] = SupplierPeer::getNavigateUrl($objectId);
						}
						else
						{
							$p['ObjectName'] = "(id =" . $objectId . ")";
							$p['NavigateUrl'] = '';
						}
						
						break;

					default:
						$p['ObjectName'] = Prado::localize("ERRORE");
						$p['NavigateUrl'] = '#';
						
						break;
				}
			}

			$p['AcknowledgeDate'] = $notification->getAcknowledgeDate('U');
			$p['DeliveryDate'] = $notification->getDeliveryDate('U');
			$p['DateCreated'] = $notification->getDateCreated('U');
			$p['CreatedBy'] = $notification->getCreatedByNameString();
			
			if (!$p['CreatedBy'])
				$p['CreatedBy'] = '---';

			$p['SenderLibraryLabel'] = "(id =" . $senderLibraryId . ")";
			$p['SenderLibraryUrl'] = '#';
			
			$senderLibraryId = intval($notification->getSenderLibraryId());
			
			if ($senderLibraryId > 0)
			{
				$senderLibrary = LibraryQuery::create()->findPk($senderLibraryId);
				
				if ($senderLibrary instanceof Library)
				{
					$p['SenderLibraryLabel'] = $senderLibrary->getLabel();
					$p['SenderLibraryUrl'] = LibraryPeer::getNavigateUrl($senderLibraryId);
				}
			}	
			
			$p['Id'] = $notification->getNotificationId();

			$data[] = $p;
		}

		$this->NotificationGrid->setDataSource($data);
		$this->NotificationGrid->dataBind();

		// compile SMS account, too
		if ($this->getObjectClass() == 'library')
		{
			$l = LibraryQuery::create()->findPk($this->getObjectId());
		
			if ($l instanceof Library)
				$this->SMSAccount->setText('<strong>' . Prado::localize('SMS rimanenti: {count}',
																			array('count' => $l->getActualSMS()))
														. '</strong>');
		}
	}

	public function calculateSortingCriteria(&$sortingCriteria = null)
	{
		$sortingExpression = $this->NotificationGrid->getSortingExpression();
		$sortingDirection = $this->NotificationGrid->getSortingDirection();

		if (is_null($sortingCriteria) 
				|| !($sortingCriteria instanceof Criteria))
			$sortingCriteria = new Criteria();

		switch ($sortingExpression)
		{
			case 'dateCreated':
				$sortingCriteria->clearOrderByColumns();

				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
				{
					$sortingCriteria->addAscendingOrderByColumn(NotificationPeer::DATE_CREATED);
				}
				elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
				{
					$sortingCriteria->addDescendingOrderByColumn(NotificationPeer::DATE_CREATED);
				}
				
				break;

			case 'deliveryDate':
				$sortingCriteria->clearOrderByColumns();

				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
				{
					$sortingCriteria->addAscendingOrderByColumn(NotificationPeer::DELIVERY_DATE);
				}
				elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
				{
					$sortingCriteria->addDescendingOrderByColumn(NotificationPeer::DELIVERY_DATE);
				}
				
				break;

			case 'acknowledgeDate':
				$sortingCriteria->clearOrderByColumns();

				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
				{
					$sortingCriteria->addAscendingOrderByColumn(NotificationPeer::ACKNOWLEDGE_DATE);
				}
				elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
				{
					$sortingCriteria->addDescendingOrderByColumn(NotificationPeer::ACKNOWLEDGE_DATE);
				}

				break;

			case 'PatronColumn': // LibrarianName
				$sortingCriteria->clearOrderByColumns();
				$sortingCriteria->addJoin(ItemPeer::PATRON_ID, PatronPeer::PATRON_ID, 'LEFT JOIN');
				
				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
				{
					$sortingCriteria->addAscendingOrderByColumn(PatronPeer::LASTNAME);
					$sortingCriteria->addAscendingOrderByColumn(PatronPeer::NAME);
				} 
				elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
				{
					$sortingCriteria->addDescendingOrderByColumn(PatronPeer::LASTNAME);
					$sortingCriteria->addDescendingOrderByColumn(PatronPeer::NAME);
				}
				
				break;

			case 'class':
				$sortingCriteria->clearOrderByColumns();
				
				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
				{
					$sortingCriteria->addAscendingOrderByColumn(NotificationPeer::NOTIFICATION_CLASS);
				}
				elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
				{
					$sortingCriteria->addDescendingOrderByColumn(NotificationPeer::NOTIFICATION_CLASS);
				}

				break;
				
			case 'channel':
				$sortingCriteria->clearOrderByColumns();
				
				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
				{
					$sortingCriteria->addAscendingOrderByColumn(NotificationPeer::NOTIFICATION_CHANNEL);
				}
				elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
				{
					$sortingCriteria->addDescendingOrderByColumn(NotificationPeer::NOTIFICATION_CHANNEL);
				}

				break;

			case 'state': // stato della notifica
				$sortingCriteria->clearOrderByColumns();
				
				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
				{
					$sortingCriteria->addAscendingOrderByColumn(NotificationPeer::NOTIFICATION_STATE);   //LookupValuePeer::VALUE_LABEL);
				}
				elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
				{
					$sortingCriteria->addDescendingOrderByColumn(NotificationPeer::NOTIFICATION_STATE);
				}

				break;

			case 'objectName':
				$sortingCriteria->clearOrderByColumns();

				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
				{
					$sortingCriteria->addAscendingOrderByColumn(NotificationPeer::OBJECT_ID);
				}
				elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
				{
					$sortingCriteria->addDescendingOrderByColumn(NotificationPeer::OBJECT_ID);
				}
				
				break;

			default:
				$sortingCriteria->clearOrderByColumns()->addDescendingOrderByColumn(NotificationPeer::DATE_CREATED);
				
				break;
		}
	}

	public function onSearch($sender, $param)
	{
		$this->NotificationGrid->CurrentPageIndex = 0;
		$this->setViewState("CurrentPage", 0);
	
		//// $this->populate();    for now, we don't see the need for populating twice ...
		$this->globalRefresh();
	}

	public function onCancel()
	{
		$this->onSearchCancel(null, null);
	}

	public function onSearchCancel($sender, $param)
	{
		$this->ChannelFilter->setSelectedIndex(0);
		$this->onResetDateCreatedFilter(null, null);
		$this->onResetDeliveryDateFilter(null, null);
		$this->StatusFilter->setSelectedValue(NotificationPeer::STATUS_PENDING);
		$this->ObjectTypeFilter->setSelectedIndex(0);
		$this->ObjectLabel->setText('');
		$this->ObjectID->setValue(null);
		$this->SenderLibraryFilter->setSelectedValue($this->getUser()->getActualLibraryId());
		$this->NotificationClassFilter->setSelectedIndex(0);
		
		$this->populate();
	}

	public function onResetDateCreatedFilter($sender, $param)
	{
		$this->DateCreatedFromFilter->setText('');
 		$this->DateCreatedToFilter->setText('');

 		if ($this->getPage()->getIsCallback()
				&& ($param instanceof TCallbackEventParameter))
 			$this->DateCreatedPanel->render($param->getNewWriter());
	}

	public function onResetDeliveryDateFilter($sender, $param)
	{
		$this->DeliveryDateFromFilter->setText('');
 		$this->DeliveryDateToFilter->setText('');

 		if ($this->getPage()->getIsCallback()
				&& ($param instanceof TCallbackEventParameter))
 			$this->DeliveryDatePanel->render($param->getNewWriter());
	}
	
	public function onChangePage($sender,$param)
	{
		$this->NotificationGrid->setCurrentPage($param->NewPageIndex);
		
		$this->populate();
	}

	public function globalRefresh()
	{
		$this->getPage()->globalRefresh();
	}

	public function getPopupFlag()
	{
		return $this->getPage()->IsPopup();
	}

	public function getUnlinkFlag()
	{
		return $this->getPage()->IsUnlink();
	}

	public function globalEditCancel()
	{
	}

	public function checkNotifications($sender,$param)
	{
		$notman = $this->getApplication()->getModule('notification');
		$notman->autoCheckDelivery();

		$this->populate();
	}

	public function OnObjectChangeType($sender, $param)
	{
		$type = $sender->getSelectedValue();

		if ($type == '0')
		{
			$this->ObjectID->setValue(null);
			$this->ObjectLabel->setText('');
			$this->ObjectLabel->setEnabled(false);
		}
		else
		{
			$this->ObjectLabel->setEnabled(true);
			$this->ObjectLabel->setText("");
			$this->ObjectID->setValue(null);
		}
	}

	public function onSuggestObject($sender, $param)
	{
		$token = $param->getToken(); //the partial word to match
		$ObjectType = $this->ObjectTypeFilter->getSelectedValue();
		$ds = array();
		//Prado::log($ObjectType);

		switch($ObjectType)
		{
			case 'patron':
				$candidates = PatronPeer::doSuggest($token);
		
				/* @var $c Patron */
				foreach ($candidates as $c)
				{	
					$ds[] = array(	'id' => $c->getPatronId(),
									'text' => $c->getCompleteName() );
				}
				
				break;

			case 'librarian':
				$candidates = LibrarianPeer::doSuggest($token);
				
				/* @var $c Librarian */
				foreach ($candidates as $c)
				{
					$ds[] = array(	'id' => $c->getLibrarianId(),
									'text' => $c->getCompleteName() );
				}
				
				break;

			case 'library':
				$candidates = LibraryPeer::doSuggest($token);
				
				/* @var $c Library */
				foreach ($candidates as $c)
				{
					$ds[] = array(	'id' => $c->getLibraryId(),
									'text' => $c->getLabel() . ' (' . $c->getLibraryId() . ')');
				}
				
				break;

			case 'supplier':
				$candidates = SupplierPeer::doSuggest($token);
				
				/* @var $c Supplier */
				foreach ($candidates as $c)
				{
					$ds[] = array(	'id' => $c->getSupplierId(),
									'text' => $c->getContactName() );
				}
				
				break;
		}

		$sender->setDataSource($ds); //set suggestions
		$sender->dataBind();
	}

	public function onSuggestObjectCallBack($sender, $param)
	{
		$id = $sender->Suggestions->DataKeys[$param->selectedIndex];
		$this->ObjectID->setValue($id);
		
		$ObjectType = $this->ObjectTypeFilter->getSelectedValue();
		
		switch($ObjectType)
		{
			case 'patron':
				$object = PatronQuery::create()->findPk($id);
				
				if ($object instanceof Patron)
					$text = $object->getCompleteName();
				
				break;

			case 'librarian':
				$object = LibrarianQuery::create()->findPk($id);
				
				if ($object instanceof Librarian)
					$text = $object->getCompleteName();
				
				break;

			case 'library':
				$object = LibraryQuery::create()->findPk($id);
				
				if ($object instanceof Library)
					$text = $object->getLabel() . ' (' . $object->getLibraryId() . ')';
				
				break;

			case 'supplier':
				$object = SupplierQuery::create()->findPk($id);
				
				if ($object instanceof Supplier)
					$text = $object->getContactName();
				
				break;
				
			default:
				$text = "";
		}
		
		$this->ObjectLabel->setText($text);
	}

}