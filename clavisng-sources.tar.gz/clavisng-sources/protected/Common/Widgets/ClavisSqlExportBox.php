<?php

/**
 * ClavisSqlExportBox class file
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 * For Commercial Licenses and support please contact Comperio.
 * @author    Mauro Seno <mauro.seno@comperio.it>
 * @link      http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2018 Comperio srl
 * @license   http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version   2.8
 * @package   Widgets
 */

class ClavisSqlExportBox extends TTemplateControl
{
	const DELIMITER = ',';
	const ENCLOSURE = '"';

	// Here we store the $_SESSION's index where the current document's template id is located.
	private $squidIndex;

	public static function sendContentForDownload($content, $mime, $fileNameCli = "clavisexport")
	{
		/** @var \THttpResponse $resp */
		if ('' === $content) {
			return false;
		}

		$resp = Prado::getApplication()->getResponse();
		$resp->clear();
		$resp->setCacheControl('nocache');
		$resp->writeFile(null, $content, $mime, null, true, $fileNameCli);
	}

	public function onInit($param)
	{
		parent::onInit($param);

		$this->initVars();
		$this->buildComponents($this->QueryParametersPanel);
	}

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallback()) {
			unset($_SESSION[$this->squidIndex]);
			$this->populate();
		}
	}

	/**
	 * Fetch the query templates for the current library and populate the "QueryList" drop down list
	 */
	public function populate()
	{
		$queries = $this->getQueryTemplates();

		$dataSource = array();
		$dataSource['0'] = '---';

		if (count($queries) === 0) {
			$this->QValidator->setVisible(false);
		} else {
			$this->QValidator->setVisible(true);
			$this->QValidator->setValidationGroup($this->getValidationGroup());

			foreach ($queries as $query) {
				/* @var $query DocumentTemplate */
				$dataSource[$query->getDocumentTemplateId()] = $query->getTemplateTitle();
			}
		}

		$this->QueryList->setDataSource($dataSource);
		$this->QueryList->dataBind();
		$this->QueryList->setSelectedIndex(0);
	}

	public function getValidationGroup()
	{
		return $this->getControlState('ValidationGroup', 'QExportBox');
	}

	/**
	 * Click on the "Export" button event handler.
	 * 1) Grab the user value from the parameters.
	 * 2) Get the data from the real SQL query.
	 * 3) Call the export method.
	 * @return bool
	 * @throws \PropelException
	 */
	public function onSqlQueryExport()
	{
		$p = array();
		$query_index = array_key_exists($this->squidIndex, $_SESSION) ? (int)$_SESSION[$this->squidIndex] : -1;

		if ($query_index > 0) {
			list($query, $params, $dt) = $this->parseQuery($query_index);

			// Valorizzo i parametri con l'input fornito dall'utente.
			if ($this->hasQueryParameters($dt->getTemplateBody())) {
				foreach ($params as $param) {
					$n = $param['name'];
					$name = $this->fromParamNameToPradoObjectID($n);
					$cntrl = $this->getPage()->findControlsByID($name);
					$p[$n] = $cntrl[0]->getText();
				}
			}

			if ($this->hasFixedParameterWithName($dt->getTemplateBody(), 'actual_librarian_id')) {
				$userId = Prado::getApplication()->getUser()->getID();
				$p[':actual_librarian_id'] = LibrarianPeer::retrieveByPK($userId)->getId();
			}

			if ($this->hasFixedParameterWithName($dt->getTemplateBody(), 'actual_library_id')) {
				$p[':actual_library_id'] = Prado::getApplication()->getUser()->getActualLibraryId();
			}

			$c = Propel::getConnection();
			$stmt = $c->prepare($query);
			$stmt->execute($p);
			$data = $stmt->fetchAll(PDO::FETCH_ASSOC);

			$this->exportData($data, $dt->getTemplateTitle());
			return true;
		}
		return false;
	}

	public function onNewQueryChoosen($sender, $param)
	{
		$this->populateSqlParams();

		if ($this->getPage()->getIsCallback()) {
			$this->QueryParametersPanel->render($this->getPage()->createWriter());
		}
		return true;
	}

	/**
	 * Build the GUI to give the user the possibility to set a value for the parameters specified in the template's query.
	 * @return bool
	 * @throws \TInvalidDataValueException
	 */
	public function populateSqlParams()
	{
		$queryID = intval($this->QueryList->getSelectedValue());

		if ($queryID < 1) {
			$this->QueryParametersPanel->setCssClass('panel_off');
			$this->QueryDescription->setText('');
			unset($_SESSION[$this->squidIndex]);
			return false;
		}

		list($query, $params, $dt) = $this->parseQuery($queryID);
		if ($dt instanceof DocumentTemplate) {
			$_SESSION[$this->squidIndex] = $queryID;
			$this->QueryDescription->setText($dt->getTemplateDescription());
			$this->buildComponents($this->QueryParametersPanel, $params);

			$panelClass = $this->hasQueryParameters($dt->getTemplateBody()) ? 'panel_on' : 'panel_off';
			$this->QueryParametersPanel->setCssClass($panelClass);
			return true;
		}
		return false;
	}

	public function setValidationGroup($value)
	{
		$this->setControlState('ValidationGroup', $value, 'QExportBox');
	}

	private function initVars()
	{
		$this->squidIndex = $this->getUniqueID() . '_currentQueryID';
	}

	/**
	 * Build a component inside the $parent  control for every $params item.
	 * At this very moment, only items of type label - input box are supported.
	 * @param       $parent
	 * @param array $params
	 * @throws \TInvalidDataValueException
	 */
	private function buildComponents($parent, $params = array())
	{
		$parent->Controls->clear();

		if (null !== $_SESSION[$this->squidIndex] && (int)$_SESSION[$this->squidIndex] > 0) {
			list($query, $params, $dt) = $this->parseQuery($_SESSION[$this->squidIndex]);
		}

		foreach ($params as $param) {
			$name = $this->fromParamNameToPradoObjectID($param['name']);
			$container = new TActivePanel();
			$container->setID('panel_' . $name);

			if (mb_strlen($param['label']) > 0) {
				$ctrl1 = new TLabel();
				$ctrl1->setID('label_' . $name);
				$ctrl1->setText(Prado::localize($param['label']));
				$ctrl1->setForControl($name);
				$ctrl1->setCssClass('formlabel');
				$ctrl1->setStyle('display:block;');
				$container->addParsedObject($ctrl1);
			}

			$ctrl2 = new TTextBox();
			$ctrl2->setID($name);
			$ctrl2->setReadOnly(false);
			$ctrl2->setColumns(10);
			$ctrl2->setText($param['default_value'] ?? '');
			$ctrl2->setStyle('margin-bottom:10px;');
			$container->addParsedObject($ctrl2);

			$parent->addParsedObject($container);
		}
	}

	/**
	 * Given the document_template's "template_body" field, this method parses the data returning the query parameters
	 * and the sql statement part.
	 * The template body field is composed as follow, i.e.:
	 * :year_start|data inizio|2018-08-01 (:variable_name,|label|default value)
	 * :year_end|data fine|2018-08-08
	 * (a blank line in the database field)
	 * SELECT * FROM `patron` WHERE `date_created`  BETWEEN :year_start AND :year_start (the parametrized query to execute)
	 * @param $query
	 * @return array
	 */
	private function parseQuery($query_id)
	{
		$p = array();
		$q = '';

		$dtp = DocumentTemplatePeer::retrieveByPK($query_id);
		$query = $dtp->getTemplateBody();

		$lines = explode(PHP_EOL, $query);
		foreach ($lines as $line) {
			$line = str_replace(array("\r", "\n"), ' ', $line);
			if (trim(substr($line, 0, 1)) === ':') {
				$params = explode('|', $line);
				$p[] = array('name' => $params[0], 'label' => $params[1], 'default_value' => $params[2]);
			} else if (trim(substr($line, 0, 2)) === '--') {
				//commenti
			} else {
				$q .= $line;
			}
		}
		return [$q, $p, $dtp];
	}

	/**
	 * This methods returns a list of document template record matching those conditions:
	 * 1) Must be of type "D" (Clavis Query from DB)
	 * 2) Must be assigned to the current library or none.
	 * 3) They must have the current localization.
	 * @return mixed
	 */
	private function getQueryTemplates()
	{
		$tpls = DocumentTemplateQuery::create()
			->filterByTemplateMedia(DocumentTemplatePeer::MEDIA_DB)
			->filterByTemplateLang($this->getApplication()->getGlobalization()->getCulture())
			->condition('libraryNull', 'DocumentTemplate.LibraryId IS NULL')
			->condition('libraryMine', 'DocumentTemplate.LibraryId = ?', $this->getUser()->getActualLibraryId())
			->orWhere(array('libraryNull', 'libraryMine'))
			->orderByTemplateClass(Criteria::ASC)
			->orderByLibraryId(Criteria::ASC)
			->orderByTemplateTitle(Criteria::ASC)
			->find();

		return $tpls;
	}

	/**
	 * Returns true if the $query string has any parameters in it, i.e. has a word starting with the : char.
	 * @param $query
	 * @return bool
	 */
	private function hasQueryParameters($query)
	{
		$match = preg_match('/\:\w+/', $query);
		return (1 === $match);
	}

	/**
	 * Return true if the $query string has a fixed parameter to substitute with the given name
	 * We can choose between:
	 *      :librarian_id for the current operator
	 *      :actual_library_id for the current library
	 * @param $query
	 * @return bool
	 */
	private function hasFixedParameterWithName($query, $name)
	{
		$match = preg_match("/\:$name/", $query);
		return (1 === $match);
	}

	/**
	 * A prado component name cant' start with a : as the param names.
	 * So this method takes care of removing any space or : from the input string.
	 * Returns the sanitized parameters.
	 * @param $n
	 * @return mixed
	 */
	private function fromParamNameToPradoObjectID($n)
	{
		return str_replace(array(' ', ':'), '', $n);
	}

	/**
	 * Transforms an array of data into a CSV string thanks to the mighty fputscv method.
	 * In doing so, it handles automagically the delimiter and enclosure options.
	 * @param array $data
	 * @param bool  $headers
	 * @param       $forExcel
	 * @return string
	 */
	private function array_to_csv_string(array $data, bool $headers, $forExcel = false)
	{
		// Generate CSV data from array
		// don't create a file, attempt to use memory instead
		$fh = fopen('php://temp', 'rw');

		// write out the headers
		if ($headers) {
			fputcsv($fh, array_keys(current($data)));
		}

		// write out the data
		foreach ($data as $row) {
			fputcsv($fh, $row, self::DELIMITER, self::ENCLOSURE);
		}

		rewind($fh);

		// $csv is an UTF-8 encoded string.
		$csv = utf8_encode(stream_get_contents($fh));
		fclose($fh);

		if ($forExcel) {
			$csv = mb_convert_encoding($csv, 'WINDOWS-1252', 'UTF-8');
		}

		return $csv;
	}

	/**
	 * Export the given $data to a file named after the $title parameter.
	 * @param array  $data
	 * @param string $title
	 * @return bool
	 */
	private function exportData(array $data, string $title)
	{
		$now = getdate();
		$dateSubfix = $now['year'] . '-' . $now['mon'] . '-' . $now['mday'];

		$csv = $this->array_to_csv_string($data, $this->HeadersViewFlag->getChecked(), $this->FormatForExcel->getChecked());

		if ('' === $csv) {
			$this->getPage()->writeMessage(Prado::localize("Nessun oggetto da esportare"), ClavisMessage::ERROR);
			return false;
		}

		self::sendContentForDownload($csv, 'text/csv', $title . '-' . $dateSubfix . '.csv');
		return true;
	}
}
