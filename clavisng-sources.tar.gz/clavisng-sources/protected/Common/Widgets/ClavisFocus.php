<?php

/**
 * ClavisFocus component
 *
 * @author Marco Brancalion <mbrancalion@e-portaltech.it>
 * @link http://www.e-portaltech.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @license http://www.e-portaltech.it/license/
 *
 *
 */


class ClavisFocus extends TControl
{
	public function onLoad($param)
	{
		parent::onLoad($param);

		$componentId = $this->getFocusComponent();
		if (!is_null($componentId))
		{
			$this->getPage()->setFocus($componentId);
			$this->setFocusComponent(null);
		}
	}

	public function setFocusComponent($focusComponent = null)
	{
		if (is_null($focusComponent))
			$value = null;
		else
			$value = $focusComponent->getClientId();
		$this->getApplication()->getSession()->add('FocusComponentId', $value);
	}

	public function getFocusComponent()
	{
		$component = $this->getApplication()->getSession()->itemAt('FocusComponentId', null);
		return $component;
	}
	
}
