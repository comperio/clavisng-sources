<?php
/**
 * ClavisAuthorityView class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Ciro Mattia Gonano
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.8.6
 * @package Widgets
 */

/**
 * ClavisAuthorityView Class
 *
 * @author Ciro Mattia Gonano
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.8.6
 * @package Widgets
 * @since 2.3
 */
class ClavisAuthorityView extends TTemplateControl
{
	/**
	 * @var Authority
	 */
	/** @var Authority $authority */
	public $authority;
	public $turbomarc;

	/** @var ClavisSBN */
	private $_sbnMod;
	public $subjPartTypeMap = array(	'L' => 'Luogo',
										'T' => 'Tempo',
										'A' => 'Argomento',
										'F' => 'Forma' );

	/**
	 * In the onLoad, during first execution of the page we
	 * get the actual authority and populate the list.
	 *
	 * @param TEventParameter $param
	 */
	public function onLoad($param)
	{
		parent::onLoad($param);

		$this->ShelfList->setEmbeddedViewMode(false);
		$this->_sbnMod = $this->getApplication()->getModule('sbn');

		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallback())
		{
			$this->populate();
		}
		else
		{
			$this->loadAuthority();
		}

		$this->SBNPanel->setVisible(($this->getDisplayMode() == 'Complete')
										&& $this->_sbnMod->getEnabled()
										&& ($this->authority instanceof Authority)
										&& !$this->authority->isNew());

		$this->LinkTabs->setVisible($this->getDisplayMode() == 'Complete');
	}

	public function loadAuthority()
	{
		$this->authority = $this->getControlState('authority');
	}

	public function saveAuthority()
	{
		$this->setControlState('authority', $this->authority);
	}

	public function setAuthorityId($value)
	{
		$this->setControlState('authorityId', intval($value), null);
	}

	public function getAuthorityId()
	{
		return $this->getControlState('authorityId', null);
	}

	public function getAuthority()
	{
		if (!$this->authority instanceof Authority)
			$this->loadAuthority();

		return $this->authority;
	}

	public function setDisplayMode($value)
	{
		$this->setControlState('DisplayMode', TPropertyValue::ensureEnum($value, array('Complete', 'Compact'), 'Complete'));
	}

	public function getDisplayMode()
	{
		return $this->getControlState('DisplayMode', 'Complete');
	}

	public function populate()
	{
		$authId = $this->getAuthorityId();

		if (!$this->authority)
		{
			if ($authId)
			{
				$this->authority = AuthorityQuery::create()->findPk($authId);
				/* if (!$this->authority instanceof Authority)
				  $this->writeMessage(Prado::localize('L\'authority [{id}] non esiste o non è valida.',
				  array('id'=>$id)),ClavisMessage::ERROR); */
			}
		}

		if (!$this->authority instanceof Authority)
		{
			$this->AuthViewer->setVisible(false);

			return;
		}

		$this->AuthViewer->setVisible(true);

		$this->turbomarc = $this->authority->getTurboMarc();

		$this->AuthTarget->setText(LookupValuePeer::getLookupValue('WORKTARGET',(string) $this->turbomarc->d109->sc));
		$this->AuthType->setText(LookupValuePeer::getLookupValue('WORKFORM',(string)$this->turbomarc->d230->sw));
		$this->AuthRecType->setText(LookupValuePeer::getLookupValue('AUTHRECTYPE', $this->authority->getAuthorityRectype()));
		$this->AuthCodLev->setText(LookupValuePeer::getLookupValue('AUTHCODLEV', $this->authority->getAuthorityCodlevel()));
		$this->AuthIntSta->setText(LookupValuePeer::getLookupValue('AUTHINTSTA', $this->authority->getAuthorityStatus()));

        if (isset($this->turbomarc->d123))
        {
            $this->LongWest->setText((string)$this->turbomarc->d123->sq);
            $this->LongEst->setText((string)$this->turbomarc->d123->sr);
            $this->LatNorth->setText((string)$this->turbomarc->d123->ss);
            $this->LatSouth->setText((string)$this->turbomarc->d123->st);
        }


        $this->AuthDates->setText(join(" - ", array((string) $this->turbomarc->d109->sa, (string) $this->turbomarc->d109->sb)));
		$this->AuthLang->setText(LookupValuePeer::getLookupValue('LANGUAGES', (string) $this->turbomarc->d101->sa));

		$countries = array();

		foreach ($this->turbomarc->d102 as $c)
			$countries[] = LookupValuePeer::getLookupValue('COUNTRIES', (string) $c->sa);

		$this->AuthCountry->setText(join(" - ", $countries));
		$isbd = htmlentities($this->authority->getFullText(), ENT_COMPAT, 'UTF-8');

		switch ($this->authority->getAuthorityType())
		{
			case AuthorityPeer::TYPE_PRINTERSDEVICE:
				// little hack to force Quote to be displayed under ISBD
				if (isset($this->turbomarc->d921->se))
					$isbd .= Prado::localize('<br/><em>Motto: {watchword}</em>', array('watchword' => (string) $this->turbomarc->d921->se));

				break;

			case AuthorityPeer::TYPE_CLASS:
				$this->panelClass->setVisible(true);
				$this->classClassCode->setText($this->authority->getClassCode());

				if (isset($this->turbomarc->d676))
				{
					$ctype = '676';
					$fld = $this->turbomarc->d676;
				}
				elseif (isset($this->turbomarc->d680))
				{
					$ctype = '680';
					$fld = $this->turbomarc->d680;
				}
				elseif (isset($this->turbomarc->d686))
				{
					$ctype = isset($this->turbomarc->d686->s2) ? (string) $this->turbomarc->d686->s2 : '686';
					$fld = $this->turbomarc->d686;
				}
				else
				{
					$fld = null;
					$ctype = self::DEFAULT_CLASS;
				}

				$this->classClassType->setText(LookupValuePeer::getLookupValue('CLASSTYPE', $ctype));
				$this->classClassEdition->setText(($fld && isset($fld->sv)) ? LookupValuePeer::getLookupValue('CLASSEDITION', (string) $fld->sv) : '---');
				$this->classClassString->setText($this->authority->getFullText());
				$this->classClassItemCode->setText(($fld && isset($fld->si)) ? (string) $fld->si : $this->authority->getClassCode());

				break;

			case AuthorityPeer::TYPE_SUBJECT:
				$this->panelSubject->setVisible(true);
				$c = new Criteria();
				$c->addAscendingOrderByColumn(LSubjectPeer::POSITION);
				$parts = $this->authority->getLSubjectsRelatedBySubjectId($c);

				// shift parent
				$parts->shift();
				$this->subjSubjectType->setText(LookupValuePeer::getLookupValue('SUBJECTTYPE', $this->authority->getSubjectClass()));
				$parent = AuthorityQuery::create()->findPk($this->authority->getParentId());

				if ($parent instanceof Authority)
				{
					$this->subjParentAuthLink->setText($parent->getFullText());
					$this->subjParentAuthLink->setNavigateUrl('?page=Catalog.AuthorityViewPage&id=' . $parent->getAuthorityId());
				}
				else
				{
					$this->getPage()->writeMessage(Prado::localize("ATTENZIONE: il soggetto non ha primo elemento"),
														ClavisMessage::WARNING);
				}

				$this->SubjectParts->setDataSource($parts);
				$this->SubjectParts->dataBind();

				break;

			case AuthorityPeer::TYPE_WORK:
				$this->TabThes->setCaption(Prado::localize("dettagli"));
				$ds5xx = array();

				for ($field = 500; $field < 600; ++$field)
				{
					$tag = "d$field";
					if (isset($this->turbomarc->$tag))
					{
						foreach ($this->turbomarc->$tag as $fld)
							$ds5xx[] = array(	'field' => $field,
												'value' => (string) $fld->sa );
					}
				}

				if ($ds5xx)
				{
					$this->panelTitles->setVisible(true);
					$this->Titles->setDataSource($ds5xx);
					$this->Titles->dataBind();
				}

				break;

			default:
				break;
		}

		$this->ShelfList->setObjectParameters('authority', $this->authority->getAuthorityId(), false);
		///////////////////
		$this->ShelfList->populate();
		
		$this->Notes->setDataSource($this->authority->getNotes());
		$this->ISBD->setText($isbd);

		if ($this->authority->getAuthoritySubtype())
		{
			$this->SubtypePanel->setVisible(true);
			$this->Subtype->setText(LookupValuePeer::getLookupValue('AUTHSUBTYPE', $this->authority->getAuthoritySubtype()));
		}
		else
		{
			$this->SubtypePanel->setVisible(false);
		}

		if ($this->authority->getAuthorityType() == AuthorityPeer::TYPE_WORK)
		{
			$linkList = $this->authority->getAuthoritiesLinkList(true, false);
		}
		else
		{
			$linkList = $this->authority->getAuthoritiesLinkList(true, true);
		}

		$authorityLink = '';
		$viewBaseLink = $this->getPage()->isPopup()
								? '#'
								: $this->getService()->constructUrl('Catalog.AuthorityViewPage', array('id' => ''));

		foreach ($linkList as $linkLabel => $links)
		{
			$authorityLink .= "<p class=\"authoritylinklisthdr\">{$linkLabel}</p>" . '<ul class="authoritylinklist">';

			foreach ($links as $termId => $term)
			{
				$appendrc = ($term['RelatorCode'])
									? " <em>({$term['RelatorCode']})</em>"
									: '';

				$authorityLink .= "<li><a href=\"{$viewBaseLink}{$term['AuthorityId']}"
										. '" title="' . Prado::localize('Cerca questa authority') . "\">{$term['FullText']}</a>{$appendrc}</li>";
			}

			$authorityLink .= '</ul>';
		}

		$this->Thesaurus->setText($authorityLink);
		$this->AttachList->setObjectClass('Authority');
		$this->AttachList->setObjectId($this->authority->getAuthorityId());
		$this->AuthLink->setAuthority($this->authority);
		$this->AuthLink->populate();
		$this->AuthLinkedData->setAuthority($this->authority);
		$this->AuthLinkedData->populate();
		$this->DocLink->setAuthority($this->authority);
		$this->ItemLink->setAuthority($this->authority);
		$this->ItemLink->populate();
		$this->dataBind();
		$this->saveAuthority();
	}

	public function OnSubjectPartsItemDataBound($sender, $param)
	{
		$item = $param->Item;

		if (($item->ItemType === 'Item')
				|| ($item->ItemType === 'AlternatingItem'))
		{
			$partType = Prado::localize($this->subjPartTypeMap[$item->DataItem->getType()]);
			$item->SubjPartType->setText($partType);
		}

		$item->SubjPartText->setText($item->DataItem['PartText']);
	}

	public function globalRefresh()
	{
		//$this->populateGrids();
		$this->populate();
	}

	public function onChangePage($sender, $param)
	{
		$sender->setCurrentPage($param->NewPageIndex);
		$this->globalRefresh();
	}

	public function checkSBNLink($sender, $param)
	{
		if (!$this->_sbnMod->getEnabled()
				|| ($this->authority->getBidSource() != 'SBN'))
		{
			$param->IsValid = true;
		}
		elseif ($this->authority->getLastSbnSync('U'))
		{
			$param->IsValid = false;
		}
	}

}
