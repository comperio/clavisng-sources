<?php
/**
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2009 Comperio srl
 * @version 2.7
 * @package Widgets
 * @since 2.3
 */
class IssueCreationWizard extends TTemplateControl
{
	private $_period = array(
		'a'	 => 1,
		'b'	 => 3,
		'c'	 => 7,
		'd'	 => 15,
		'e'	 => 15,
		'f'	 => 30,
		'g'	 => 60,
		'h'	 => 90,
		'i'	 => 120,
		'j'	 => 180,
		'k'	 => 365,
		'l'	 => 730,
		'm'	 => 1095,
		'n'	 => 2,
		'o'	 => 10,
		'p'	 => 0,
		'u'	 => 0,
		'y'	 => 0,
		'z'	 => 0);

	public function onLoad($param)
	{
		parent::onLoad($param);
		
		$m = $this->getManifestation();
		if ($m instanceof Manifestation)
			$this->setManifestation($m);
	}

	public function setManifestation(Manifestation $manifestation)
	{
		$this->ManifestationView->setManifestation($manifestation);
		$this->ManifestationView->populate();
		$this->setControlState('Manifestation', $manifestation);
	}

	public function getManifestation()
	{
		return $this->getControlState('Manifestation');
	}

	public function onNextStep($sender, $param)
	{
		switch ($param->getCurrentStepIndex())
		{
			case 0:
				switch ($this->CreationType->getSelectedValue())
				{
					case 'issue':
						$this->IssueCreationWizard->setActiveStepIndex(1);
						break;
					case 'year':
						$this->IssueCreationWizard->setActiveStepIndex(2);
						break;
					case 'yeardup':
						$this->populateDupVolumeList();
						$this->IssueCreationWizard->setActiveStepIndex(3);
						break;
				}
				break;
			case 1:
				throw new Exception('This should not happen');
				break;
			case 2:
				$this->setControlState('Frequence', $this->Frequence->getValue());
				$this->previewGenerationSchema();
				$this->IssueCreationWizard->setActiveStepIndex(4);
				break;
			case 3:
				$this->previewGenerationSchema();
				$this->IssueCreationWizard->setActiveStepIndex(4);
				break;
			default:
				break;
		}
	}

	public function onCompleteWizard($sender, $param)
	{
		switch ($this->CreationType->getSelectedValue())
		{
			case 'issue': // fascicolo singolo
				try
				{
					$issue = new Issue();
					$issue->setManifestation($this->getManifestation());
					$issue->setIssueNumber($this->getIssueNumber($this->SingleNumModel->getSelectedValue(), $this->SingleStartNumber->getSafeText(), $this->SingleEndNumber->getSafeText(), $this->SingleIssueYear->getSafeText(), $this->SingleIssueVolume->getSafeText(), $this->SingleIssueDate->getTimestamp()));
					//$issue->setIssueNumber($this->SingleIssueNumber->getSafeText());
					$issue->setIssueYear($this->SingleIssueYear->getSafeText());
					$issue->setIssueVolume($this->SingleIssueVolume->getSafeText());
					$issue->setIssueType($this->SingleIssueType->getSelectedValue());
					$issue->setIssueDate($this->SingleIssueDate->getTimestamp());
					$issue->setStartNumber($this->SingleStartNumber->getSafeText());
					$issue->setEndNumber($this->SingleEndNumber->getSafeText());
					$issue->setIssueNote($this->SingleIssueNote->getSafeText());
					$issue->save();
					ChangelogPeer::logAction($issue, ChangelogPeer::LOG_CREATE, $this->getUser());
					$this->getPage()->writeMessage(Prado::localize('Fascicolo creato con successo'), ClavisMessage::INFO);
				}
				catch (Exception $e)
				{
					$this->getPage()->writeMessage(Prado::localize('Errore nella creazione del fascicolo: ') .
							$e->getMessage(), ClavisMessage::ERROR);
				}
				break;
			case 'year': // creazione annata
				$f = $this->getControlState('Frequence');
				$startDate = $this->FirstIssueDate->getTimeStamp();
				$endDate = $this->EndDate->getTimeStamp();
				$issueNum = intval($this->StartNumber->getSafeText());
				$rollover = intval($this->Rollover->getSafeText());
				$dates = IssuePeer::getIssueVolumeDates($f, $startDate, $endDate);
				$num = count($dates);
				if (!$num && $this->_period[$f] > 0)
				{
					$days = ($endDate - $startDate) / 86400;
					$num = ceil($days / $this->_period[$f]);
					for ($i = 0; $i < $num; ++$i)
						$dates[] = $startDate + ($i * 86400 * $this->_period[$f]);
				}
				$m = $this->getManifestation();
				$year = $this->Year->getSafeText();
				$volume = $this->Volume->getSafeText();
				if (intval($volume) == $volume && $volume != '')
					$volume = intval($volume);
				/* create all related issues */
				for ($i = 0; $i < $num; ++$i)
				{
					try
					{
						$issue = new Issue();
						$issue->setManifestation($m);
						$issue->setIssueNumber($this->getIssueNumber($this->NumModel->getSelectedValue(), $issueNum, $issueNum, $year, $volume, $dates[$i]));
						$issue->setIssueYear($year);
						$issue->setIssueVolume($volume);
						$issue->setIssueType(IssuePeer::TYPE_NORMAL);
						$issue->setIssueDate($dates[$i]);
						$issue->setStartNumber($issueNum);
						$issue->setEndNumber($issueNum);
						$issue->save();
						ChangelogPeer::logAction($issue, ChangelogPeer::LOG_CREATE, $this->getUser());
						$this->getPage()->appendDelayedMessage(Prado::localize('Fascicolo {issuenum} creato con successo', array('issuenum' => $issueNum)), ClavisMessage::INFO);
					}
					catch (Exception $e)
					{
						$this->getPage()->appendDelayedMessage(Prado::localize('Errore nella creazione del fascicolo {issuenum}: ', array('issuenum' => $issueNum)) . $e->getMessage(), ClavisMessage::ERROR);
					}
					if ($issueNum == $rollover)
					{
						$issueNum = 1;
						if (is_int($volume))
							++$volume;
					} else
					{
						++$issueNum;
					}
				}
				break;
			case 'yeardup': // duplicazione annata
				$newYear = intval($this->DupYear->getSafeText());
				$volume = intval($this->DupVolume->getSafeText());
				if (intval($volume) == $volume && $volume != '')
					$volume = intval($volume);
				$m = $this->getManifestation();
				if (!$m instanceof Manifestation)
					return;
				$c = new Criteria();
				$c->add(IssuePeer::ISSUE_YEAR, $this->YearToDup->getSelectedValue());
				$c->add(IssuePeer::ISSUE_DATE, null, Criteria::ISNOTNULL);
				$c->addAscendingOrderByColumn(IssuePeer::ISSUE_DATE);
				$c->addAscendingOrderByColumn(IssuePeer::START_NUMBER);
				$issues = $m->getIssues($c);
				if (count($issues) > 0)
				{
					$numModel = $this->DupNumModel->getSelectedValue();
					$deltaTime = ($newYear - $issues[0]->getIssueDate('Y')) * 31536000; // 1year in seconds
					$deltaNum = intval($this->DupStartNumber->getText()) - $issues[0]->getStartNumber();
					/** @var $i Issue */
					foreach ($issues as $i)
					{
						try
						{
							$issueDate = $i->getIssueDate('U') + $deltaTime;
							$issueStart = $i->getStartNumber() + $deltaNum;
							$issueEnd = $i->getEndNumber() + $deltaNum;
							$issue = new Issue();
							$issue->setManifestation($m);
							$issue->setIssueNumber($this->getIssueNumber($numModel, $issueStart, $issueEnd, $newYear, $volume, $issueDate));
							$issue->setIssueYear($newYear);
							$issue->setIssueVolume($volume);
							$issue->setIssueType(IssuePeer::TYPE_NORMAL);
							$issue->setIssueDate($issueDate);
							$issue->setStartNumber($issueStart);
							$issue->setEndNumber($issueEnd);
							$issue->save();
							ChangelogPeer::logAction($issue, ChangelogPeer::LOG_CREATE, $this->getUser());
							$this->getPage()->appendDelayedMessage(Prado::localize('Fascicolo {issuenum} creato con successo', array('issuenum' => $issueStart)), ClavisMessage::INFO);
						}
						catch (Exception $e)
						{
							$this->getPage()->appendDelayedMessage(Prado::localize('Errore nella creazione del fascicolo {issuenum}: ', array('issuenum' => $issueStart)) . $e->getMessage(), ClavisMessage::ERROR);
						}
					}
				}
				break;
		}
		$this->getPage()->flushDelayedMessage();
		$this->getPage()->getClientScript()->registerEndScript(__CLASS__ . '_js', 'onReturn(\'reload\',\'reload\',true);');
	}

	public function changedNumModel($sender, $param)
	{
		if ($this->NumModel->getSelectedValue() == "4")
		{
			$this->NumModelOtherPanel->setCssClass('panel_on');
			$this->NumModelOtherPanel->render($param->getNewWriter());
		}
	}

	public function createIssueYear($sender, $param)
	{
		
	}

	public function populateDupVolumeList()
	{
		$c = new Criteria();
		$c->add(IssuePeer::MANIFESTATION_ID, $this->getManifestation()->getManifestationId());
		$c->clearSelectColumns()->addSelectColumn(IssuePeer::ISSUE_YEAR);
		$c->setDistinct();
		$c->addDescendingOrderByColumn(IssuePeer::ISSUE_YEAR);
		$stmt = IssuePeer::doSelectStmt($c);
		$volume_ds = array();
		while ($row = $stmt->fetch(PDO::FETCH_NUM))
			$volume_ds[$row[0]] = $row[0];
		$this->YearToDup->setDataSource($volume_ds);
		$this->YearToDup->dataBind();
	}

	protected function previewGenerationSchema()
	{
		$ds = array();
		switch ($this->CreationType->getSelectedValue())
		{
			case 'yeardup':
				$newYear = intval($this->DupYear->getSafeText());
				$volume = intval($this->DupVolume->getSafeText());
				if (intval($volume) == $volume && $volume != '')
					$volume = intval($volume);

				$m = $this->getManifestation();
				if (!$m instanceof Manifestation)
					return;
				$c = new Criteria();
				$c->add(IssuePeer::ISSUE_YEAR, $this->YearToDup->getSelectedValue());
				$c->add(IssuePeer::ISSUE_DATE, null, Criteria::ISNOTNULL);
				$c->addAscendingOrderByColumn(IssuePeer::ISSUE_DATE);
				$c->addAscendingOrderByColumn(IssuePeer::START_NUMBER);
				$issues = $m->getIssues($c);
				if (count($issues) > 0)
				{
					$numModel = $this->DupNumModel->getSelectedValue();
					$deltaTime = ($newYear - $issues[0]->getIssueDate('Y')) * 31536000; // 1year in seconds
					$deltaNum = intval($this->DupStartNumber->getText()) - $issues[0]->getStartNumber();
					/** @var $i Issue */
					foreach ($issues as $i)
					{
						$issueDate = $i->getIssueDate('U') + $deltaTime;
						$issueStart = $i->getStartNumber() + $deltaNum;
						$issueEnd = $i->getEndNumber() + $deltaNum;
						$issueNum = ($issueStart != $issueEnd) ? "{$issueStart}/{$issueEnd}" : $issueStart;
						$ds[] = array(
							'Description'	 => $this->getIssueNumber($numModel, $issueStart, $issueEnd, $newYear, $volume, $issueDate),
							'Date'			 => $issueDate,
							'Number'		 => $issueNum,
						);
					}
				}
				break;
			case 'year':
				$f = $this->getControlState('Frequence');
				if (!$f || !array_key_exists($f, $this->_period))
				{
					
				}
				$startDate = $this->FirstIssueDate->getTimeStamp();
				$endDate = $this->EndDate->getTimeStamp();
				$issueNum = intval($this->StartNumber->getSafeText());
				$rollover = intval($this->Rollover->getSafeText());
				$numModel = $this->NumModel->getSelectedValue();

				$dates = IssuePeer::getIssueVolumeDates($f, $startDate, $endDate);
				$num = count($dates);
				if (!$num && $this->_period[$f] > 0)
				{
					$days = ($endDate - $startDate) / 86400;
					$num = ceil($days / $this->_period[$f]);
					for ($i = 0; $i < $num; ++$i)
						$dates[] = $startDate + ($i * 86400 * $this->_period[$f]);
				}
				$year = $this->Year->getSafeText();
				$volume = $this->Volume->getSafeText();
				if (intval($volume) == $volume && $volume != '')
					$volume = intval($volume);
				/* preview all related issues */
				for ($i = 0; $i < $num; ++$i)
				{
					$ds[] = array(
						'Description'	 => $this->getIssueNumber($numModel, $issueNum, $issueNum, $year, $volume, $dates[$i]),
						'Date'			 => $dates[$i],
						'Number'		 => $issueNum,
					);
					if ($issueNum == $rollover)
					{
						$issueNum = 1;
						if (is_int($volume))
							++$volume;
					} else
					{
						++$issueNum;
					}
				}
				break;
		}
		$this->IssueGenerationPreview->setDataSource($ds);
		$this->IssueGenerationPreview->dataBind();
	}

	private function getIssueNumber($numModel, $startNumber, $endNumber, $year, $volume, $issueDate)
	{
		$pre = $post = '';
		switch ($numModel)
		{
			case 'nmy':
				$month = Clavis::dateFormat($issueDate, 'MMMM');
				$post = " ({$month} {$year})";
				break;
			case 'n':
				break;
			case 'yn':
				$pre = "{$year}, ";
				break;
			case 'yn2':
				$pre = "({$year}), ";
				break;
			case 'ny':
				$post = " ({$year})";
				break;
			case 'vn':
				$pre = "{$volume}, ";
				break;
			case 'vn2': //A. 2015, N. 100 (gen. 2015)
				$month = Clavis::dateFormat($issueDate, 'MMM');
				$pre = "A. {$year}, N. ";
				$post = " ({$month}. {$year})";
				break;
            case 'vn3': //A. 1, n. 100 (gen. 2015)
                $month = Clavis::dateFormat($issueDate, 'MMM');
                $pre = "A. {$volume}, n. ";
                $post = " ({$month}. {$year})";
                break;
			case 'vyn':
			default:
				$pre = "{$volume} ({$year}), ";
				break;
		}
		$num = ($startNumber == $endNumber) ? $startNumber : "{$startNumber}/{$endNumber}";
		
		return $pre . $num . $post;
	}
	
}