<?php

/**
 * @author    Ciro Mattia Gonano <ciro@comperio.it>
 * @link      http://www.comperio.it/
 * @copyright Copyright &copy; 2009 Comperio srl
 * @version   2.7
 * @package   Widgets
 * @since     2.3
 */
class IssueCreationWizard extends TTemplateControl
{
	/**
	 * @param $param
	 */
	public function onLoad($param)
	{
		parent::onLoad($param);

		$m = $this->getManifestation();
		if ($m instanceof Manifestation)
			$this->setManifestation($m);

		$title = '<b>' . $m->getCompleteTitle() . '</b><br />' . $m->getAuthor();
		$this->Title->setText($title);
		$this->Title->setNavigateUrl('index.php?page=Catalog.Record&manifestationId=' . $m->getManifestationId());
	}

	public function getManifestation()
	{
		return $this->getControlState('Manifestation');
	}

	/**
	 * @param \Manifestation $manifestation
	 */
	public function setManifestation(Manifestation $manifestation)
	{
		$this->setControlState('Manifestation', $manifestation);
	}

	/**
	 * @param $sender
	 * @param $param
	 * @throws \Exception
	 */
	public function onNextStep($sender, $param)
	{
		// reset the current year in order to get the issues calendar being reinitialized
		// when hitting the back button, change a creation parameter and then go forward to
		// see the changes.
		if ($this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallBack()) {
			$this->IssuesCalendar->setViewState('currentYear', '');
		}

		switch ($param->getCurrentStepIndex()) {
			case 0:
				switch ($this->CreationType->getSelectedValue()) {
					case 'year':
						$this->IssueCreationWizard->setActiveStepIndex(1);
						break;
					case 'yeardup':
						$this->populateDupVolumeList();
						$this->IssueCreationWizard->setActiveStepIndex(2);
						break;
					case 'issue':
						$this->IssueCreationWizard->setActiveStepIndex(3);
						break;
				}
				break;

			case 1:
				$this->setControlState('Frequence', $this->Frequence->getValue());
				$this->initIssuesCalendar();
				$this->IssueCreationWizard->setActiveStepIndex(4);
				break;
			case 2:
				$this->initIssuesCalendar();
				$this->IssueCreationWizard->setActiveStepIndex(4);
				break;
			default:
				break;
		}
	}

	/**
	 * @throws \PropelException
	 */
	public function populateDupVolumeList()
	{
		$c = new Criteria();
		$c->add(IssuePeer::MANIFESTATION_ID, $this->getManifestation()->getManifestationId());
		$c->clearSelectColumns()->addSelectColumn(IssuePeer::ISSUE_YEAR);
		$c->setDistinct();
		$c->addDescendingOrderByColumn(IssuePeer::ISSUE_YEAR);
		$stmt = IssuePeer::doSelectStmt($c);
		$volume_ds = [];
		while ($row = $stmt->fetch(PDO::FETCH_NUM))
			$volume_ds[$row[0]] = $row[0];

		$this->YearToDup->setDataSource($volume_ds);
		$this->YearToDup->dataBind();

//		$issues = $this->getYearToDupIssues();
//		$iDescr = [];
//		foreach ($issues as $issue) {
//			$iDescr[]['issueDescription'] = $issue->getIssueNumber();
//		}
//		$model = IssueCalendarPopup::inferModelFromIssuesDescription($iDescr);

	}

	/**
	 * @param $sender
	 * @param $param
	 * @throws \THttpException
	 */
	public function onCompleteWizard($sender, $param)
	{

		if ($this->CreationType->getSelectedValue() === 'issue') {
			$exit_status = $this->createSingleIssue();
			if ($exit_status) {
				$this->getPage()->flushDelayedMessage();
				$this->getPage()->getClientScript()->registerEndScript(__CLASS__ . '_js', 'onReturn(\'reload\',\'reload\',true);');
			}
		}

		$m = $this->getManifestation();
		$ds = $this->IssuesCalendar->getViewStateDataSource();

		foreach ($ds['data'] as $timestamp => $is) {
			try {
				$ts = $is['issueTimestamp'];
				$issue = new Issue();
				$issue->setManifestation($m);
				$issue->setIssueNumber($is['issueDescription']);
				$issue->setIssueYear($is['issueYear']);
				$issue->setIssueVolume($is['issueVolume']);
				$issue->setIssueType(IssuePeer::TYPE_NORMAL);
				$issue->setIssueDate((int)$ts / 1000);

				if ($this->CreationType->getSelectedValue() === 'year') {
					$issue->setStartNumber($is['issueNum']);
					$issue->setEndNumber($is['issueNum']);
				} else {
					$issue->setStartNumber($is['issueStart']);
					$issue->setEndNumber($is['issueEnd']);
				}

				$issue->save();

				ChangelogPeer::logAction($issue, ChangelogPeer::LOG_CREATE, $this->getUser());
				$this->getPage()->appendDelayedMessage(Prado::localize('Fascicolo {issuenum} creato con successo', ['issuenum' => $is['issueNum']]), ClavisMessage::INFO);
			} catch (Exception $e) {
				$this->getPage()->appendDelayedMessage(Prado::localize('Errore nella creazione del fascicolo {issuenum}: ', ['issuenum' => $is['issueNum']]) . $e->getMessage(), ClavisMessage::ERROR);
			}
		}

		$this->getPage()->flushDelayedMessage();
		$this->getPage()->getClientScript()->registerEndScript(__CLASS__ . '_js', 'onReturn(\'reload\',\'reload\',true);');

	}

	/**
	 * @param $sender
	 * @param $param
	 */
	public function changedNumModel($sender, $param)
	{
		if ($this->NumModel->getSelectedValue() == "4") {
			$this->NumModelOtherPanel->setCssClass('panel_on');
			$this->NumModelOtherPanel->render($param->getNewWriter());
		}
	}


	private function getYearToDupIssues()
	{
		$m = $this->getManifestation();
		if (!$m instanceof Manifestation)
			return [];

		$c = new Criteria();
		$c->add(IssuePeer::ISSUE_YEAR, $this->YearToDup->getSelectedValue());
		$c->add(IssuePeer::ISSUE_DATE, null, Criteria::ISNOTNULL);
		$c->add(IssuePeer::ISSUE_TYPE, IssuePeer::TYPE_SUPPLEMENT, Criteria::NOT_EQUAL);

		$c->addAscendingOrderByColumn(IssuePeer::ISSUE_DATE);
		$c->addAscendingOrderByColumn(IssuePeer::START_NUMBER);
		$issues = $m->getIssues($c);

		return $issues;
	}

	/**
	 * @throws \PropelException
	 * @throws \Exception
	 */
	protected function initIssuesCalendar()
	{
		switch ($this->CreationType->getSelectedValue()) {

			case 'yeardup':
				$newYear = (int)$this->DupYear->getSafeText();
				$volume = (string)$this->DupVolume->getSafeText();
				$rollover = (int)$this->DupRollover->getSafeText();

				if ((string)$volume == $volume && $volume != '')
					$volume = (string)$volume;

				$issues = $this->getYearToDupIssues();
				if (count($issues) > 0) {

					$numModel = $this->DupNumModel->getSelectedValue();
					$issueYear = $issues[0]->getIssueDate('Y');
					$yDiff = $newYear - $issueYear;
					$deltaNum = (int)$this->DupStartNumber->getText() - $issues[0]->getStartNumber();

					/** @var $i Issue */
					foreach ($issues as $index => $i) {
						$originIssueDate = (string)$i->getIssueDate('Y-m-d');
						$currentTimezoneDate = date('Y-m-d', strtotime("{$yDiff} years", strtotime($originIssueDate)));
						$issueDate = $this->getGMTTimestamp(strtotime($currentTimezoneDate));

						$issueStart = (int)$i->getStartNumber() + $deltaNum;
						$issueEnd = (int)$i->getEndNumber() + $deltaNum;
						$issueNum = (string)($issueStart != $issueEnd) ? "{$issueStart}/{$issueEnd}" : $issueStart;
						$issueVolume = $volume; // (string)$i->getIssueVolume();
						$issueType = $i->getIssueType();
						$issueNote = $i->getIssueNote();

						if ($index === 0) {
							$displayYear = date('Y', $issueDate);
						}

						$issuesToShow[$issueDate * 1000] = [
							'issueStart' => $issueStart,
							'issueEnd' => $issueEnd,
							'issueNum' => $issueNum,
							'issueVolume' => $issueVolume,
							'issueDescription' => $i::buildIssueNumber(
								$numModel,
								$issueNum,
								$issueStart,
								$issueEnd,
								$newYear,
								$issueVolume,
								$issueDate
							),
							'issueYear' => $newYear,
							'issueType' => $issueType,
							'issueNote' => $issueNote,
							'issueTimestamp' => $issueDate * 1000,
							'issueId' => -1,
							'issuePermissions' => 7 // read, modify, delete
						];
					}
				}

				$ClavisIssuesCalendarParams = [
					'mode' => 'init',
					// 20191206: starting from today the "always renumber" is defaulted to false.
					// So, when we create a new year, the fist time the calendar is displayed,
					// we must manually initialize the issue's numbering.
					'forceRenumber' => true,
					'data' => $issuesToShow,
					'rollover' => $rollover,
					'model' => $numModel,
					'year' => $newYear,
					'displayYear' => $displayYear,
					'volume' => $volume,
					'manifestationId' => $this->getManifestation()->getManifestationId()
				];
				break;

			case 'year':
				$f = $this->getControlState('Frequence');

				$startDate = $this->FirstIssueDate->getTimestamp();
				$endDate = $this->EndDate->getTimestamp();

				$issueNum = (string)$this->StartNumber->getSafeText();
				$rollover = (int)$this->Rollover->getSafeText();
				$numModel = $this->NumModel->getSelectedValue();

				$year = $this->Year->getSafeText();
				$volume = (string)$this->Volume->getSafeText();
				$issuesToShow = [];

				$dates = IssuePeer::getIssueVolumeDates($f, $startDate, $endDate);

				foreach ($dates as $index => $date) {
					$data = [];
					$d = $this->getGMTTimestamp($date);

					if ($index === 0) {
						$displayYear = date('Y', $date);
						$data = [
							'issueStart' => $issueNum,
							'issueEnd' => $issueNum,
							'issueNum' => $issueNum,
							'issueVolume' => $volume,
							'issueDescription' => Issue::buildIssueNumber(
								$this->NumModel->getSelectedValue(),
								$issueNum,
								$issueNum,
								$issueNum,
								$year,
								$volume,
								$date
							),
							'issueYear' => $year,
							'issueType' => IssuePeer::TYPE_NORMAL,
							'issueNote' => '',
							'issueTimestamp' => $d * 1000,
							'issueId' => -1,
							'issuePermissions' => 7 // read, modify, delete
						];
					}
					$issuesToShow[$d * 1000] = $data;
				}

				$ClavisIssuesCalendarParams = [
					'mode' => 'init',
					// 20191206: starting from today the "always renumber" is defaulted to false.
					// So, when we create a new year, the fist time the calendar is displayed,
					// we must manually initialize the issue's numbering.
					'forceRenumber' => true,
					'data' => $issuesToShow,
					'rollover' => $rollover,
					'model' => $numModel,
					'year' => $year,
					'displayYear' => $displayYear,
					'volume' => $volume,
					'manifestationId' => $this->getManifestation()->getManifestationId()
				];

				break;
		}
		$this->IssuesCalendar->init($ClavisIssuesCalendarParams);
	}


	/**
	 * @param $timestamp
	 * @return false|int
	 */
	protected function getGMTTimestamp($timestamp)
	{
		$t = date('Y-m-d', $timestamp);
		$ts = strtotime(gmdate($t . '\T00:00:00\Z'));
		return $ts;
	}

	/**
	 * @return bool
	 */
	private function createSingleIssue()
	{
		try {

			$issueNumber = Issue::buildIssueNumber(
				$this->SingleNumModel->getSelectedValue(),
				$this->SingleStartNumber->getSafeText(),
				$this->SingleEndNumber->getSafeText(),
				$this->SingleIssueYear->getSafeText(),
				$this->SingleIssueVolume->getSafeText(),
				$this->SingleIssueDate->getTimestamp()
			);

			$issue = new Issue();
			$issue->setManifestation($this->getManifestation());
			$issue->setIssueNumber($issueNumber);
			$issue->setIssueYear($this->SingleIssueYear->getSafeText());
			$issue->setIssueVolume($this->SingleIssueVolume->getSafeText());
			$issue->setIssueType($this->SingleIssueType->getSelectedValue());
			$issue->setIssueDate($this->SingleIssueDate->getTimestamp());
			$issue->setStartNumber($this->SingleStartNumber->getSafeText());
			$issue->setEndNumber($this->SingleEndNumber->getSafeText());
			$issue->setIssueNote($this->SingleIssueNote->getSafeText());
			$issue->save();
			ChangelogPeer::logAction($issue, ChangelogPeer::LOG_CREATE, $this->getUser());
			$this->getPage()->writeMessage(Prado::localize('Fascicolo creato con successo'), ClavisMessage::INFO);
		} catch (Exception $e) {
			$this->getPage()->writeMessage(Prado::localize('Errore nella creazione del fascicolo: ') . $e->getMessage(), ClavisMessage::ERROR);
			return false;
		}

		return true;
	}
}
