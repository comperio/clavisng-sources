<?php
/**
 * JasperPrintBox class file
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Dario Rigolin <dario@comperio.it>
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 */

/**
 * JasperPrintBox Class
 *
 * Renders a box with parameters to print something out of a set of templates.
 *
 * @author Dario Rigolin <dario@comperio.it>
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Widgets
 * @since 2.4
 */
class JasperPrintBox extends TTemplateControl {

	public function onLoad($param) {
		parent::onLoad($param);

		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallback())
			$this->populate();
		else
			$this->populateReportParams();
	}

	public function populate() {
		$reportClass = $this->getReportClass();
		if (!$reportClass)
			return;
		$jrmod = $this->getApplication()->getModule('JReport');
		/* @var $jrmod JRPHPModule */
		if ($jrmod instanceof JRPHPModule && $jrmod->getActive()) {
			$formats = $jrmod->getExportFormatList();
			$this->ReportTypeList->setDataSource($formats);
			$this->ReportTypeList->dataBind();
			if ($this->ReportTypeList->getSelectedIndex() < 0)
				$this->ReportTypeList->setSelectedIndex(0);
			$reports = DocumentTemplatePeer::getAllTemplates($reportClass,
					$this->getApplication()->getGlobalization()->getCulture(),
					$this->getUser()->getActualLibraryId());
			$dataSource = array();
			if (count($reports) >= 1) {
				$dataSource['0'] = '---';
				$this->JValidator->setVisible(true);
				$this->JValidator->setValidationGroup($this->getValidationGroup());
			} else {
				$this->JValidator->setVisible(false);
			}
			foreach ($reports as $r) {
				/* @var $r DocumentTemplate */
				$dataSource[$r->getDocumentTemplateId()] = $r->getTemplateTitle();
			}
			$this->ReportList->setDataSource($dataSource);
			$this->ReportList->dataBind();
			// always force first element selection
			if ($this->ReportList->getSelectedIndex() < 0)
				$this->ReportList->setSelectedIndex(0);
			$this->populateReportParams();
		} else {
			if ($this->getApplication()->getMode() != 'Debug')
				$this->getPage()->writeMessage(
					Prado::localize('Il modulo JRPHP o JavaBridge non sono disponibili. Non sarà possibile generare report.'),
					ClavisMessage::ERROR);
			$this->JasperPrintBoxPanel->setVisible(false);
			return;
		}
	}

	private function populateReportParams() {
		$reportId = intval($this->ReportList->getSelectedValue());
		if ($reportId < 1) {
			$this->ReportParameters->setCssClass('panel_off');
		} else {
			$report = DocumentTemplatePeer::retrieveByPK($reportId);
			if ($report instanceof DocumentTemplate) {
				$jrmod = $this->getApplication()->getModule('JReport');
				/* @var $jrmod JRPHPModule */
				if ($jrmod->setReportTemplate($report)) {
					$parameters = $jrmod->getReportParameters();
					$this->ReportParameters->getControls()->clear();
					$panelOn = false;
					foreach ($parameters as $k => $p) {
						if (!$p['IsForPrompt'])
							continue;
						if (array_key_exists('AdmittableValues',$p['Properties'])) {
							// put a dropdown
							// AdmittableValues follow the syntax:
							// key1$value1|key2$value2|...
							$ds = array();
							foreach (explode('|',$p['Properties']['AdmittableValues']) as $option) {
								list($key,$val) = explode('$',$option);
								$ds[$key] = $val;
							}
							$values = explode(',',str_replace("\n",",",$p['Properties']['AdmittableValues']));
							$ctrl1 = new TLabel();
							$ctrl1->setText(Prado::localize($p['Label']));
							$ctrl1->setForControl("JRPARAM_{$k}");
							$this->ReportParameters->addParsedObject($ctrl1);
							$ctrl = new TDropDownList();
							$ctrl->setDataSource($ds);
							$ctrl->dataBind();
							$ctrl->setID("JRPARAM_{$k}");
							$this->ReportParameters->addParsedObject($ctrl);
						} else if (array_key_exists('LookupClass',$p['Properties'])) {
							// put a dropdown getting values from LookupValue table
							$values = LookupValuePeer::getLookupClassValues($p['Properties']['LookupClass']);
							$ctrl1 = new TLabel();
							$ctrl1->setText(Prado::localize($p['Label']));
							$ctrl1->setForControl("JRPARAM_{$k}");
							$this->ReportParameters->addParsedObject($ctrl1);
							$ctrl = new TDropDownList();
							$ctrl->setDataSource($values);
							$ctrl->dataBind();
							$ctrl->setID("JRPARAM_{$k}");
							$this->ReportParameters->addParsedObject($ctrl);
						} else if (array_key_exists('ShelfSelect',$p['Properties'])) {
							$ctrl1 = new TLabel();
							$ctrl1->setText(Prado::localize($p['Label']));
							$ctrl1->setForControl("JRPARAM_{$k}");
							$this->ReportParameters->addParsedObject($ctrl1);
							$ctrl4 = new TTextBox();
							$ctrl4->setID("JRPARAM_{$k}_NAME");
							$ctrl4->setReadOnly(true);
							$ctrl4->setColumns(30);
							$ctrl2 = new THiddenField();
							$ctrl2->setID("JRPARAM_{$k}");
							$this->ReportParameters->addParsedObject($ctrl2);
							$ctrl3 = new TPopupImageButton();
							$ctrl3->setText(Prado::localize('lega'));
							$ctrl3->setPopupPage('Communication.ShelfListPopup');
							$ctrl3->setReturnLabel("JRPARAM_{$k}_NAME");
							$ctrl3->setReturnValue("JRPARAM_{$k}");
							$ctrl3->setAutoSubmit(false);
							$ctrl3->setImageURL('themes/Default/icons/scroll.png');
							$ctrl3->setToolTip(Prado::localize('scegli scaffale da lista'));
							$ctrl3->setCssClass('formImageButton');
							$ctrl3->setIsDefaultButton(false);
							$ctrl3->dataBind();
							$this->ReportParameters->addParsedObject($ctrl3);
						} else if (array_key_exists('ClavisQuery',$p['Properties'])) {
							// put a dropdown getting values from results of a query
							// parse query:
							$regex = '!\s*SELECT\s+`?(?<field1>\w+)`?\s*,\s*`?(?<field2>\w+)`?\s+FROM\s+`?(?<table>\w+)`?\s+WHERE\s+(?<conditions>.*)';
							if (preg_match($regex, $p['Properties']['ClavisQuery'], $matches) === false)
								throw new Exception('Malformed query: '.$p['Properties']['ClavisQuery']);
							$deniedStrings = array('IF ','ERASE ','ALTER ','- ');
							foreach($deniedStrings as $str)
								if (stripos($matches['conditions'], $str) !== false)
									throw new Exception('SQL injection suspect: '.$p['Properties']['ClavisQuery']);
							$query = "SELECT {$matches['field1']}, {$matches['field2']} FROM {$matches['table']} ".
								'WHERE '.addslashes($matches['conditions']);
							$conn = Propel::getConnection();
							$stmt = $conn->prepare($query);
							$stmt->execute();
							$ds = array();
							while ($row = $stmt->fetch())
								$ds[$row[0]] = $row[1];
							$ctrl1 = new TLabel();
							$ctrl1->setText(Prado::localize($p['Label']));
							$ctrl1->setForControl("JRPARAM_{$k}");
							$this->ReportParameters->addParsedObject($ctrl1);
							$ctrl = new TDropDownList();
							$ctrl->setDataSource($ds);
							$ctrl->dataBind();
							$ctrl->setID("JRPARAM_{$k}");
							$this->ReportParameters->addParsedObject($ctrl);
						} else {
							switch ($p['Class']) {
								case 'java.lang.Boolean': // put a checkbox
									$ctrl = new TCheckBox();
									$ctrl->setID("JRPARAM_{$k}");
									$ctrl->setText(' ' . Prado::localize($p['Label']));
									$ctrl->setChecked($p['DefaultValue'] == 'true');
									$ctrl->setStyle('display:block;');
									$ctrl->setAutoPostBack(false);
									$this->ReportParameters->addParsedObject($ctrl);
									break;
								case 'java.lang.Integer': // put a textbox
									$ctrl1 = new TLabel();
									$ctrl1->setText(Prado::localize($p['Label']).
										Prado::localize(' <em>(numero)</em> '));
									$ctrl1->setForControl("JRPARAM_{$k}");
									$this->ReportParameters->addParsedObject($ctrl1);
									$ctrl = new TTextBox();
									$ctrl->setText($p['DefaultValue']);
									$ctrl->setID("JRPARAM_{$k}");
									$this->ReportParameters->addParsedObject($ctrl);
									break;
								case 'java.lang.String': // put a textbox with validation
									$ctrl1 = new TLabel();
									$ctrl1->setText(Prado::localize($p['Label']).
										Prado::localize(' <em>(stringa)</em> '));
									$ctrl1->setForControl("JRPARAM_{$k}");
									$this->ReportParameters->addParsedObject($ctrl1);
									$ctrl = new TTextBox();
									$ctrl->setText(substr($p['DefaultValue'],1,  strlen($p['DefaultValue'])-2));
									$ctrl->setID("JRPARAM_{$k}");
									$this->ReportParameters->addParsedObject($ctrl);
									break;
								default:
									break;
							}
						}
						$panelOn = true;
					}
					$this->ReportParameters->setCssClass($panelOn ? 'panel_on' : 'panel_off');
					return true;
				}
			}
		}
		return false;
	}

	public function onJRPrint($sender, $param) {
		$this->printReport();
	}

	public function printReport() {
		$repId = $this->ReportList->getSelectedValue();
		$report = DocumentTemplatePeer::retrieveByPK($repId);
		if ($report instanceof DocumentTemplate) {
			/* @var $jrmod JRPHPModule */
			$jrmod = $this->getApplication()->getModule('JReport');
			try {
				if ($jrmod->setReportTemplate($report)) {
					$this->loadReportParams($jrmod);
                                        $rType = $this->ReportTypeList->getSelectedValue();
                                        $jrmod->setReportParam('P_REPORT_TYPE',$rType);
                                        if($rType == 'csv')
                                            $jrmod->setReportParam('IS_IGNORE_PAGINATION',TRUE);
					$jrmod->renderReport($rType);
				} else {
					$this->getPage()->writeMessage(Prado::localize('Errore sul server di stampa.'), ClavisMessage::WARNING);
				}
			} catch (Exception $e) {
				$this->getPage()->writeMessage(Prado::localize('Errore Jasper / Messaggio: {error}',
					array('error' => $e)), ClavisMessage::WARNING);
			}
		} else {
			if (is_null($repId)
					|| ($repId == ""))
				$this->getPage()->writeMessage(Prado::localize('Selezionare un template di stampa valido'),
												ClavisMessage::WARNING);
			else
				$this->getPage()->writeMessage(Prado::localize('Selezionare un template di stampa valido ({repID})',
													                array('repID' => $repId)),
												ClavisMessage::WARNING);
		}
	}

	public function setMode($value) {
		$this->setControlState('Mode', TPropertyValue::ensureEnum($value,
				array('Standalone', 'Widget')), 'Standalone');
	}

	public function getMode() {
		return $this->getControlState('Mode', 'Standalone');
	}

	public function setReportClass($value) {
		$this->setControlState('ReportClass', $value, null);
	}

	public function getReportClass() {
		return $this->getControlState('ReportClass', null);
	}

	public function setSelectedReportId($value) {
		// TBD
	}

	public function getSelectedReportId() {
		return $this->ReportList->getSelectedValue();
	}

	public function getSelectedReportName() {
		$repId = $this->getSelectedReportId();
		$report = DocumentTemplatePeer::retrieveByPK($repId);
		return ($report instanceof DocumentTemplate) ?
			$report->getTemplateTitle() : '';
	}

	public function getSelectedPrompt()
	{
		$ret = array();

		$repId = $this->ReportList->getSelectedValue();
		$report = DocumentTemplatePeer::retrieveByPK($repId);
		if ($report instanceof DocumentTemplate) {
			/* @var $jrmod JRPHPModule */
			$jrmod = $this->getApplication()->getModule('JReport');
			try {
				if ($jrmod->setReportTemplate($report)) {
					$parameters = $this->getApplication()->getModule('JReport')->getReportParameters();
					foreach ($parameters as $k => $p) {
						if (!$p['IsForPrompt'])
							continue;
						$ctrl = $this->findControl("JRPARAM_{$k}");
						if (!$ctrl instanceof TControl) {
							Prado::log("No control for $k");
							continue;
						}
						if (array_key_exists('AdmittableValues', $p['Properties'])) {
							// dropdown
							$ret[$k] = $ctrl->getSelectedValue();
						} else {
							switch ($p['Class']) {
								case 'java.lang.Boolean': // checkbox
									if ($ctrl->getChecked())
										$ret[$k] = $p['Label'];
									break;
								case 'java.lang.Integer': // textbox
									$value = $ctrl->getSafeText();
									if (intval($value) == $value)
										$ret[$k] = intval($value);
									break;
								case 'java.lang.String': // textbox
									$ret[$k] = $ctrl->getSafeText();
									break;
								default:
									break;
							}
						}
					}
				}
			} catch (Exception $e) {
				// do nothing
			}
		}
		return $ret;
	}

	public function setObjectId($objectId) {
		$this->setControlState('ObjectId', $objectId);
	}

	public function getObjectId() {
		return $this->getControlState('ObjectId', null);
	}

	public function setValidationGroup($value) {
		$this->setControlState('ValidationGroup', $value, 'JPrintBox');
	}

	public function getValidationGroup() {
		return $this->getControlState('ValidationGroup','JPrintBox');
	}

	public function addOptionalParam($param_name, $param_value) {
		$p = $this->getControlState('OptParams', array());
		$p[$param_name] = $param_value;
		$this->setControlState('OptParams', $p);
	}

	public function getOptionalParams() {
		return $this->getControlState('OptParams', array());
	}

	private function loadReportParams(JRPHPModule $jrmod) {
		$parameters = $jrmod->getReportParameters();
		foreach ($parameters as $k => $p) {
			if (!$p['IsForPrompt'])
				continue;
			$ctrl = $this->findControl("JRPARAM_{$k}");
			if (!$ctrl instanceof TControl) {
				Prado::log("No control for $k");
				continue;
			}
			if (array_key_exists('AdmittableValues', $p['Properties'])) {
				// dropdown
				$jrmod->setReportParam($k, $ctrl->getSelectedValue());
			} else {
				switch ($p['Class']) {
					case 'java.lang.Boolean': // checkbox
						$jrmod->setReportParam($k, $ctrl->getChecked() ? true : false);
						break;
					case 'java.lang.Integer': // textbox
						$value = $ctrl->getSafeText();
						if (intval($value) == $value)
							$jrmod->setReportParam($k, intval($value));
						break;
					case 'java.lang.String': // textbox
						$jrmod->setReportParam($k, $ctrl->getSafeText());
						break;
					default:
						break;
				}
			}
		}
		// add optional defined parameters
		foreach ($this->getOptionalParams() as $pname => $pvalue)
			$jrmod->setReportParam($pname, $pvalue);
		$oid = $this->getObjectId();
		$oid = (is_array($oid)) ? implode(',', $oid) : (string) $oid;
		$jrmod->setReportParam('P_OBJECT_ID', $oid);
	}

	public function onPopulateReportParams($sender, $param) {
		$this->populateReportParams($sender->getSelectedValue());
		//If report have P_OUT_FMT param, take available output formats.
		$jrmod = $this->getApplication()->getModule('JReport');
		if ($jrmod instanceof JRPHPModule && $jrmod->getActive()) {
			$formats = $jrmod->getAvailableExportFormatList();
			if( $formats === FALSE )
			{
				$formats = $jrmod->getExportFormatList();
			}
			$this->ReportTypeList->setDataSource($formats);
			$this->ReportTypeList->dataBind();
		}
		if ($this->getPage()->getIsCallback()) {
			$this->ReportParameters->render(($param instanceof TCallbackEventParameter) ?
				$param->getNewWriter() : $this->getPage()->createWriter());
		}

	}

}
