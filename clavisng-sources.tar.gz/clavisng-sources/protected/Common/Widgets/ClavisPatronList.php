<?php
/**
 * ClavisPatronList class file.
 * This file contains all the required classes for SBN dialogue v4.
 * Based upon SBNConnector by Comperio srl.
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 * For Commercial Licenses and support please contact Comperio.
 * @author    Dario Rigolin <dario@comperio.it>
 * @author    Marco Brancalion <marco@comperio.it>
 * @author    Ciro Mattia Gonano
 * @link      http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license   http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version   2.8.9
 * @package   Widgets
 */

/**
 * ClavisPatronList Class
 * @author  Dario Rigolin <dario@comperio.it>
 * @author  Marco Brancalion <marco@comperio.it>
 * @author  Ciro Mattia Gonano
 * @version 2.8.9
 * @package Widgets
 * @property \TClavisActiveDataGrid UserGrid
 * @since   2.0
 */
class ClavisPatronList extends TTemplateControl
{
	public $customs_type = array('text', 'text', 'text');
	public $_onlySelectedSessionName;
	public $_masterChecked;

	private $_checked = array('all' => false);
	private $_checkedSessionName;
	private $_datasourceSessionName;
	private $_globalCriteriaSessionName;
	private $_filtersSessionName;
	private $_newPatronFiltersSessionName;
	private $_viewFiltersSessionName;
	private $_mainFiltersSessionName;
	private $_datasource;

	// -----------------------------------------------------------------------------------------------------------------
	// Prado page-related event handling functions
	// -----------------------------------------------------------------------------------------------------------------

	/**
	 * @param $param
	 * @throws \TInvalidOperationException
	 */
	public function onInit($param)
	{
		parent::onInit($param);

		$this->initVars();
		$this->createQueryBuilder();
		$this->attachEventHandler('OnActualLibraryChanged', array($this, 'OnActualLibraryChanged'));
	}

	/**
	 * @param $param
	 * @throws \PropelException
	 * @throws \TInvalidDataValueException
	 * @throws \TInvalidOperationException
	 */
	public function onLoad($param)
	{
		parent::onLoad($param);
		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallBack()) {

			// show/hide the patron's creation date on the ClavisPatronList.
			// ---------------------------------------------------------------------------------------------------------
			if ($this->getViewDateCreated()) {
				$this->DateCreated->setVisible(true);
				$this->UserGrid->resetSorting('dateCreated', null, false);
			} else {
				$this->DateCreated->setVisible(false);
				$this->UserGrid->resetSorting('patronName', null, false);
			}

			$this->UserGrid->resetPagination();
			$this->resetDataSource(false);
		}

		// reinitialize the querybuilder component with the previous data in case of postback
		// -------------------------------------------------------------------------------------------------------------
		if ($this->getShowFilterPanel()) {
			if ($this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallBack()) {
				if (is_array($options = $this->QueryBuilder->getOptions())) {
					$this->initQueryBuilder($options);
				}
			}
			$this->FilterPanel->setStyle('display:block;');
		}
		$this->doRenderPrintPanel();
	}

	/**
	 * @param $sender
	 * @param $param
	 */
	public function OnActualLibraryChanged($sender, $param)
	{
		// patron filters don't have library specific settings for now.
		// Uncomment the line below when this need arises.
		//$this->initQueryBuilder();
	}

	/**
	 * @param null $options
	 */
	public function initQueryBuilder($options = null): void
	{
		if ($this->getShowFilterPanel()) {
			$filters = ((null === $options) || (!array_key_exists('filters', $options)))
				? $this->getFiltersDefinition()
				: $options['filters'];


			$initRules = ((null === $options) || (!array_key_exists('rules', $options)))
				? null // $this->getDefaultRule()
				: $options['rules'];

			$rules = TPropertyValue::ensureBoolean($this->Request['newPatron'])
				? $this->getInsertNewPatronCheckRules()
				: $initRules;

			if ($this->Request['newPatron']) {
				$this->QueryBuilder->setAllow('setdefault');
			}

			$this->QueryBuilder->init($options, $filters, $rules);
		}
	}

	/**
	 * @param \Criteria $criteria
	 */
	public function searchByCriteria(Criteria $criteria): void
	{
		$this->searchPatron($this, $criteria);
	}

	// -----------------------------------------------------------------------------------------------------------------
	// Query builder related functions
	// -----------------------------------------------------------------------------------------------------------------

	/**
	 * @return array
	 */
	public function getDefaultRule(): array
	{
		return [
			'condition' => 'AND',
			'rules' => [
				[
					'id' => 'barcode',
					'operator' => 'begins_with',
					'value' => '',
					'validation' => ['allow_empty_value' => true]

				],
				[
					'id' => 'lastname',
					'operator' => 'begins_with',
					'value' => '',
					'validation' => ['allow_empty_value' => true],
				],
				[
					'id' => 'name',
					'operator' => 'begins_with',
					'value' => '',
					'validation' => ['allow_empty_value' => true],
				],

				// set two empty rules so the user can fill them without clicking on the add rule button...
				['empty' => true], ['empty' => true]
			]
		];
	}

	/**
	 * @param $sender
	 * @param $param
	 * @return array
	 * @throws \PropelException
	 */
	public function onSetDefaultRule($sender, $param): array
	{
		if (TPropertyValue::ensureBoolean($this->Request['newPatron'])) {
			$rules = $this->getInsertNewPatronCheckRules();
		} else {
			$rules = $this->getDefaultRule();
		}
		return $rules;
	}

	/**
	 * @param $label
	 * @param $value
	 */
	public function setPopupCustomReturn($label, $value): void
	{
		if (!$this->getPage()->isPopup()) {
			return;
		}

		$this->setControlState('PopupCustomReturnLabel', $label, null);
		$this->setControlState('PopupCustomReturnValue', $value, null);
	}

	/**
	 * @return mixed
	 */
	public function getPopupCustomReturnValue()
	{
		return $this->getControlState('PopupCustomReturnValue', null);
	}

	/**
	 * @return mixed
	 */
	public function getPopupCustomReturnLabel()
	{
		return $this->getControlState('PopupCustomReturnLabel', null);
	}

	/**
	 * @param bool $value
	 */
	public function setViewDateCreated($value = false): void
	{
		$this->setControlState('ViewDateCreated', $value, false);
	}

	/**
	 * @return bool|null
	 */
	public function getViewDateCreated(): bool
	{
		return TPropertyValue::ensureBoolean($this->getControlState('ViewDateCreated'));
	}

	/**
	 * @param bool $value
	 */
	public function setShowFilterPanel($value = false)
	{
		$this->setControlState('ShowFilterPanel', $value, false);

	}

	/**
	 * @return bool
	 */
	public function getShowFilterPanel()
	{
		return TPropertyValue::ensureBoolean($this->getControlState('ShowFilterPanel'));
	}

	// -----------------------------------------------------------------------------------------------------------------
	// Patron list popup handlers
	// -----------------------------------------------------------------------------------------------------------------

	/**
	 * @param null $criteria
	 */
	public function setGlobalCriteria($criteria = null)
	{
		$this->getApplication()->getSession()->add($this->_globalCriteriaSessionName, $criteria, null);
	}

	/**
	 * @return array|mixed|null
	 */
	public function getGlobalCriteria()
	{
		$crit = $this->getApplication()->getSession()->itemAt($this->_globalCriteriaSessionName, null);

		if (is_array($crit) && array_key_exists('body', $crit)) {
			$crit['body'] = SerializableCriteria::refreshCriteria($crit['body']);
		} else {
			$crit = SerializableCriteria::refreshCriteria($crit);
		}

		return $crit;
	}

	/**
	 *
	 */
	public function resetGlobalCriteria()
	{
		$this->setGlobalCriteria(null);
	}

	// -----------------------------------------------------------------------------------------------------------------
	// Component parameter ViewDateCreated handling
	// -----------------------------------------------------------------------------------------------------------------

	/**
	 * @param null $criteria
	 */
	public function setExternalCriteria($criteria = null)
	{
		$this->setControlState('ExternalCriteria', $criteria, null);
	}

	/**
	 * @return mixed
	 */
	public function getExternalCriteria()
	{
		$output = $this->getControlState('ExternalCriteria', null);
		$output = SerializableCriteria::refreshCriteria($output);

		if (is_object($output))
			return clone $output;

		return $output;
	}


	// -----------------------------------------------------------------------------------------------------------------
	// Component parameter ShowFilterPanel handling
	// -----------------------------------------------------------------------------------------------------------------

	/**
	 *
	 */
	public function resetExternalCriteria(): void
	{
		$this->setExternalCriteria(new Criteria());
	}

	/**
	 * @param $sender
	 * @param $param
	 * @throws \PropelException
	 * @throws \TInvalidOperationException
	 */
	public function onPrintJRP($sender, $param)
	{
		if (!$this->getPage()->getIsValid())
			return false;

		$ds = $this->getCheckedId();   // all + reset
		$ids = implode(',', $ds);
		$this->JRPBox->setObjectId($ids);
		$this->JRPBox->printReport();
	}

	// -----------------------------------------------------------------------------------------------------------------
	// Store query criteria to session
	// -----------------------------------------------------------------------------------------------------------------

	/**
	 * @param $sender
	 * @param $param
	 * @throws \PropelException
	 */
	public function onPrintValidate($sender, $param): void
	{
		$param->isValid = (count($this->getCheckedId()) > 0);
	}

	/**
	 * @param bool $flag
	 */
	public function setOnlySelected($flag = false): void
	{
		$this->getApplication()->getSession()->add(
			$this->_onlySelectedSessionName,
			TPropertyValue::ensureBoolean($flag),
			false
		);
	}

	/**
	 * @return mixed|null
	 */
	public function getOnlySelected()
	{
		$flag = $this->getApplication()->getSession()->itemAt($this->_onlySelectedSessionName);
		return $flag;
	}

	// -----------------------------------------------------------------------------------------------------------------
	// Query the patron tables by propel criteria
	// -----------------------------------------------------------------------------------------------------------------

	/**
	 * @param $sender
	 * @param $param
	 * @throws \PropelException
	 * @throws \TInvalidDataValueException
	 * @throws \TInvalidOperationException
	 */
	public function onOnlySelected($sender, $param)
	{
		$checked = $sender->getChecked();
		$this->setOnlySelected($checked);
		$this->UserGrid->resetPagination();

		$this->populate();
	}

	/**
	 * @param $sender
	 * @param $param
	 */
	public function onFlipChecked($sender, $param)
	{
		$checked = $this->getCheckedItems();

		$index = $sender->Parent->Parent->ItemIndex;
		$newStatus = $sender->getChecked();
		$dataSource = $this->getDatasource();
		$row = $dataSource[$index];
		$patronId = $row['id'];

		if ($newStatus != $checked['all']) {
			$checked[$patronId] = true;
		} else {
			unset($checked[$patronId]);
		}

		$this->setCheckedItems($checked);
		$this->updateEmptyFlag($param);
	}

	/**
	 * @param $sender
	 * @param $param
	 */
	public function onMasterChecked($sender, $param)
	{
		$newStatus = $sender->getChecked();
		$this->resetCheckedItems($newStatus);
		$gridItems = $this->UserGrid->getItems();

		foreach ($gridItems as $item)
			$item->CheckColumn->CheckedBox->setChecked($newStatus);

		$this->updateEmptyFlag($param);
	}

	// -----------------------------------------------------------------------------------------------------------------
	// Jasper reports handlers / print panel handler
	// -----------------------------------------------------------------------------------------------------------------

	/**
	 * @param null $checked
	 */
	public function setCheckedItems($checked = null)
	{
		if ($checked == null) {
			$checked = $this->_checked;
		} else {
			$this->_checked = $checked;
		}

		$this->getApplication()->getSession()->add($this->_checkedSessionName, $checked);
	}

	/**
	 * @return array|mixed|null
	 */
	public function getCheckedItems()
	{
		$this->_checked = $this->getApplication()->getSession()->itemAt($this->_checkedSessionName);
		return $this->_checked;
	}

	// -----------------------------------------------------------------------------------------------------------------
	// Selection handler methods
	// -----------------------------------------------------------------------------------------------------------------

	/**
	 * @param bool $force
	 * @return array
	 * @throws \PropelException
	 */
	public function getCheckedId($force = false)
	{
		$checked = $this->getCheckedItems();
		$this->_masterChecked = $checked['all'];
		unset($checked['all']);
		$checkedIds = array_keys($checked);
		$output = array();

		if (!$this->_masterChecked) {
			$output = $checkedIds;
		} else         // caso del mastercheck inverso
		{
			$criteriaArray = $this->getGlobalCriteria();

			if (!is_null($criteriaArray)
				&& ($criteriaArray['type'] == 'givenIds')) {
				$patronIds = clone($criteriaArray['body']);
				$output = array_diff($patronIds, $checkedIds);
			} else if (!is_null($criteriaArray)
				&& ($criteriaArray['type'] == 'normal')) {
				$criteria = clone($criteriaArray['body']);

				if (count($checkedIds) > 0)
					$criteria->add(PatronPeer::PATRON_ID, $checkedIds, Criteria::NOT_IN);

				$output = array();
				$pdo = PatronPeer::doSelectStmt($criteria);

				while ($patronId = $pdo->fetchColumn(0))
					$output[] = $patronId;
			}
		}

		if ((count($output) == 0)
			&& ($force == true)) {
			$this->setMasterChecked(true);
			$output = $this->getCheckedId();
		}

		return $output;  // ids
	}

	/**
	 * @param bool $force
	 * @return array|int
	 */
	public function countCheckedId($force = false)
	{
		$checked = $this->getCheckedItems();
		$this->_masterChecked = $checked['all'];
		unset($checked['all']);
		$checkedIds = array_keys($checked);
		$output = array();

		if (!$this->_masterChecked) {
			$output = count($checkedIds);
		} else         // caso del mastercheck inverso
		{
			$criteriaArray = $this->getGlobalCriteria();

			if ($criteriaArray !== null && ($criteriaArray['type'] === 'givenIds')) {
				$patronIds = clone($criteriaArray['body']);
				$outputIds = array_diff($patronIds, $checkedIds);
				$output = count($outputIds);
			} else if ($criteriaArray !== null && ($criteriaArray['type'] === 'normal')) {
				$criteria = clone($criteriaArray['body']);
				$criteria->add(PatronPeer::PATRON_ID, $checkedIds, Criteria::NOT_IN);
				$patronsCount = PatronPeer::doCount($criteria);
				$output = $patronsCount;
			}
		}

		if (($output == 0)
			&& ($force == true)) {
			$this->setMasterChecked(true);
			$output = $this->countCheckedId();
		}

		return $output;  // numero ids
	}

	/**
	 * @return mixed
	 */
	public function getMasterChecked()
	{
		$checked = $this->getCheckedItems();
		return $checked['all'];
	}

	// -----------------------------------------------------------------------------------------------------------------
	// Checked patrons handlers
	// -----------------------------------------------------------------------------------------------------------------

	/**
	 * @param bool $newChecked
	 * @param null $param
	 */
	public function setMasterChecked($newChecked = false, $param = null)
	{
		$this->resetCheckedItems($newChecked);

		$gridItems = $this->UserGrid->getItems();
		$header = $this->UserGrid->getHeader();

		foreach ($gridItems as $item)
			$item->CheckColumn->CheckedBox->setChecked($newChecked);
		if ($header)
			$header->CheckColumn->MasterCheck->setChecked($newChecked);
	}

	/**
	 * @param null $param
	 */
	public function updateEmptyFlag($param = null)
	{
		$this->SelectedNumber->setText(intval($this->countCheckedId()));

		if (!is_null($param))
			$this->SelectedPanel->render($param->getNewWriter());
	}

	/**
	 * @return mixed|null
	 */
	public function getDatasource()
	{
		if ($this->_datasource === null)
			$this->_datasource = $this->getApplication()->getSession()->itemAt($this->_datasourceSessionName);

		return $this->_datasource;
	}

	/**
	 * @param null $datasource
	 */
	public function setDatasource($datasource = null)
	{
		$this->_datasource = $datasource;
//		if ($datasource == null) {
//			$datasource = $this->_datasource;
//		} else {
//		$this->_datasource = $datasource;
//		}
		$this->getApplication()->getSession()->add($this->_datasourceSessionName, $datasource);
	}

	/**
	 * @param bool $populateFlag
	 * @throws \PropelException
	 * @throws \TInvalidDataValueException
	 * @throws \TInvalidOperationException
	 */
	public function resetDataSource($populateFlag = true)
	{
		$this->resetCheckedItems();
		$this->resetOnlySelected();
		$this->resetGlobalCriteria();
		$this->resetPagination();

		$this->_datasource = array();
		$this->getApplication()->getSession()->add($this->_datasourceSessionName, $this->_datasource);

		if ($populateFlag) {
			$this->populate();
		}
	}

	/**
	 * @param bool $state
	 */
	public function resetCheckedItems($state = false)
	{
		$this->setCheckedItems(array('all' => $state));
	}

	/**
	 * @param bool $value
	 */
	public function resetOnlySelected($value = false)
	{
		$this->setOnlySelected($value);

		$this->OnlySelectedCheck->setChecked($value);
		$this->SelectedNumber->setText('0');
	}

	/**
	 *
	 */
	public function resetPagination()
	{
		$this->UserGrid->setCurrentPage(0);
	}

	/**
	 * Synonym of searchCancel().
	 * @param TControl        $sender
	 * @param TEventParameter $param
	 * @return void
	 * @throws \PropelException
	 * @throws \TInvalidDataValueException
	 * @throws \TInvalidOperationException
	 */
	public function onCancel($sender, $param)
	{
		$this->resetDataSource(false);
	}

	// -----------------------------------------------------------------------------------------------------------------
	// Save current loaded data to session
	// -----------------------------------------------------------------------------------------------------------------

	/**
	 * @param $sender
	 * @param $param
	 */
	public function onChangePage($sender, $param)
	{
		$sender->setCurrentPage($param->NewPageIndex);
		$this->globalRefresh();
	}

	/**
	 * @param $sender
	 * @param $param
	 */
	public function searchPatron($sender, $param): void
	{
		try {
			if ($param instanceof Criteria) {
				// -------------------------------- Search by criteria
				$criteria = $param;
			} else {
				// -------------------------------- Search with the query builder help
				$rules = $param['rules'];
				$transformationRules = $this->getTransformationRules();
				$joinRules = $this->getJoinRules();

				/** @var \PatronQuery $patronQuery */
				$patronQuery = PatronQuery::create()->setDistinct();
				$criteria = QueryBuilderToPropelDB::create()->translate($rules, $transformationRules, $patronQuery, $joinRules);
				$this->addNewPatronFilters($rules);
			}

			$this->setExternalCriteria($criteria);
			$this->resetDataSource(); // calls populate!

			if (is_array($param) && is_callable($param['callback'])) {
				call_user_func($param['callback']);
			}
		} catch (Exception $e) {
			$this->getPage()->writeMessage(Prado::localize('Riscontrato problema con questa ricerca. [' . $e->getMessage() . ']'), ClavisMessage::ERROR);

			if (is_array($param) && is_callable($param['callback'])) {
				call_user_func($param['callback']);
			}
		}

		if ($this->getPage()->getIsCallback()) {
			$this->UserGrid->render($this->getPage()->createWriter());
		}
	}

	// -----------------------------------------------------------------------------------------------------------------
	// Various reset methods
	// -----------------------------------------------------------------------------------------------------------------

	/**
	 * @param null $givenIds
	 * @throws \PropelException
	 * @throws \TInvalidDataValueException
	 * @throws \TInvalidOperationException
	 */
	public function populate($givenIds = null)
	{
		$classFilter = null;
		if ($this->getOnlySelected()) {
			$givenIds = $this->getCheckedId();
		}

		if ($givenIds !== null && is_array($givenIds)) {
			$patrons = PatronPeer::retrieveByPKs($givenIds);
			$recCount = count($patrons);
			$this->setGlobalCriteria(array('type' => 'givenIds', 'body' => $givenIds));
		} else {
			$externalCriteria = $this->getExternalCriteria();
			if (($externalCriteria !== null) && ($externalCriteria->size() > 0)) { // && ($externalCriteria->size() > 0)
				$criteria = $externalCriteria;

				$this->NoFiltersPanel->setVisible(false);
				$recCount = PatronPeer::doCount($criteria);

				$this->calculateSortingCriteria($criteria);
				$this->setGlobalCriteria(array('type' => 'normal', 'body' => clone $criteria));

				$pageSize = $this->UserGrid->getPageSize();
				$currentIndexPage = $this->UserGrid->getCurrentPage();

				$criteria->setLimit($pageSize);
				$criteria->setOffset($currentIndexPage * $pageSize);
				$patrons = PatronPeer::doSelect($criteria);
			} else {
				// No criteria were selected...
				$this->NoFiltersPanel->setVisible(true);
				$recCount = 0;
				$patrons = array();
			}
		}

		$this->UserGrid->setVirtualItemCount($recCount);
		$this->EmptySet->setVisible($recCount === 0);
		$data = array();

		/* @var $patron Patron */
		$checked = $this->getCheckedItems();
		$this->_masterChecked = $checked['all'];

		foreach ($patrons as $patron) {
			$patronId = $patron->getPatronId();

			$p = array();
			$checkedItem = $checked[$patronId] ?? false;
			if ($this->_masterChecked)
				$checkedItem = !$checkedItem;

			$p['PatronStatusString'] = $patron->getPatronStatusString();
			$p['Checked'] = $checkedItem;

			$p['ReverseCompleteName'] = ($name = trim($patron->getReverseCompleteName())) !== ''
				? $name
				: Prado::localize('(nome e cognome mancanti)');

			if ($classFilter !== null) {
				$p['ReverseCompleteName'] .= '&nbsp;('
					. LookupValuePeer::getLookupValue(
						'PATRONLOANCLASS',
						$patron->getLoanClass())
					. ')';
			}

			$p['SuggestLabel'] = $patron->getLastname()
				. ' '
				. $patron->getName()
				. ' ('
				. $patron->getBarcode()
				. ')<span class="informal">'
				. Clavis::dateFormat($patron->getBirthDate('U'))
				. '</span>';

			$pl = $patron->getPreferredLibrary();
			$p['PreferredLibraryId'] = $patron->getPreferredLibraryId();
			$p['PreferredLibraryLabel'] = ($pl instanceof Library)
				? $pl->getLabel()
				: '---';

			$p['BirthDate'] = $patron->getBirthDate('U');

			$birthCity = trim($patron->getBirthCity());
			$birthProvince = trim($patron->getBirthProvince());
			$birthPlace = $birthCity;

			if ($birthProvince !== '') {
				$birthPlace .= ($birthPlace != ''
						? ' '
						: '')
					. "({$birthProvince})";
			}

			$birthCountry = trim($patron->getBirthCountry());
			$citizenShip = trim($patron->getCitizenShip());
			$nation = $birthCountry
				. ((($birthCountry !== '') && ($citizenShip !== '')) ? '/' : '')
				. $citizenShip;
			$birthPlace .= ($birthPlace !== '' ? ' ' : '') . "({$nation})";

			$p['BirthPlace'] = ($birthPlace !== '' ? $birthPlace : '---');
			$p['id'] = $patron->getPatronId();
			$p['Barcode'] = $patron->getBarcode();

			if (!$p['Barcode']) {
				$p['Barcode'] = '---';
			}

			$p['PatronStateIconPath'] = $patron->getPatronStateIconPath();
			$p['DateCreated'] = $patron->getDateCreated('U');

			$data[] = $p;
		}

		$this->UserGrid->setDataSource($data);
		$this->UserGrid->dataBind();

		$this->setDatasource($data);

		$this->doRenderPrintPanel();
		$this->onPatronSearchDone($this, null);
	}

	/**
	 * @param null $sortingCriteria
	 */
	public function calculateSortingCriteria(&$sortingCriteria = null)
	{
		$sortingExpression = $this->UserGrid->getSortingExpression();
		$sortingDirection = $this->UserGrid->getSortingDirection();

		if (($sortingCriteria === null) || !($sortingCriteria instanceof Criteria))
			$sortingCriteria = new Criteria();

		switch ($sortingExpression) {
			case 'patronName':
				$sortingCriteria->clearOrderByColumns();

				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC) {
					$sortingCriteria->addAscendingOrderByColumn(PatronPeer::LASTNAME);
					$sortingCriteria->addAscendingOrderByColumn(PatronPeer::NAME);
				} else if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC) {
					$sortingCriteria->addDescendingOrderByColumn(PatronPeer::LASTNAME);
					$sortingCriteria->addDescendingOrderByColumn(PatronPeer::NAME);
				}

				break;

			case 'dateCreated':
				$sortingCriteria->clearOrderByColumns();

				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC) {
					$sortingCriteria->addAscendingOrderByColumn(PatronPeer::DATE_CREATED);
				} else if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC) {
					$sortingCriteria->addDescendingOrderByColumn(PatronPeer::DATE_CREATED);
				}

				break;

			case 'birthDate':
				$sortingCriteria->clearOrderByColumns();

				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC) {
					$sortingCriteria->addAscendingOrderByColumn(PatronPeer::BIRTH_DATE);
				} else if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC) {
					$sortingCriteria->addDescendingOrderByColumn(PatronPeer::BIRTH_DATE);
				}

				break;
			case 'barCode':
				$sortingCriteria->clearOrderByColumns();

				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC) {
					$sortingCriteria->addAscendingOrderByColumn(PatronPeer::BARCODE);
				} else if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC) {
					$sortingCriteria->addDescendingOrderByColumn(PatronPeer::BARCODE);
				}

				break;

			case null:
				break;

			default:
				$sortingExpression = null;
				break;
		}
	}

	/**
	 * @param $sender
	 * @param $params
	 */
	public function onCallback($sender, $params)
	{
		$p = $params->getCallbackParameter();
		switch ($p->event) {
			case 'onSuggest':
				//dropdown-menu inner
				$out = '<ul class="ul-autocompleter" role="listbox" aria-expanded="true" style="overflow: auto;">';
				$suggestion = $this->buildSuggestionFor($p->suggest->token, $p->suggest->type, $p->suggest->subtype);

				$counter = 0;
				foreach ($suggestion as $id => $description) {
					++$counter;
					if ($counter <= 10) {
						$out .= '<li><a role="option"> <span data-lid="' . $id . '" class="text">' . trim($description) . '</span></a></li>';
					} else {
						$out .= '<li><a role="option"> <span data-lid="-1" class="text">' . 'Altri elementi trovati...' . '</span></a></li>';
						break;
					}
				}

				$out .= '</ul>';
				echo $out;
				die();
				break;
		}
	}

	/**
	 * @return array
	 */
	public function getInsertNewPatronCheckRules(): array
	{
		return [
			'flags' => [
				'no_add_rule' => true,
				'no_add_group' => true,
			],

			'condition' => 'AND',
			'rules' => [
				[
					'id' => 'lastname',
					'operator' => 'begins_with',
					'value' => '',
					'flags' => ['filter_readonly' => true]
				],

				[
					'id' => 'name',
					'operator' => 'begins_with',
					'value' => '',
					'flags' => ['filter_readonly' => true]
				],

				[
					'id' => 'national_id',
					'operator' => 'begins_with',
					'value' => '',
					'flags' => ['filter_readonly' => true]
				],

				[
					'id' => 'birth_date',
					'operator' => 'equal',
					'value' => '',
					'filter_readonly' => true,
					'flags' => ['filter_readonly' => true]
				],
			]
		];
	}

	/**
	 *
	 */
	public function resetNewPatronFilters()
	{
		$this->setNewPatronFilters('');
	}

	/**
	 * @param string $value
	 */
	public function setNewPatronFilters($value = '')
	{
		$this->getApplication()->getSession()->add($this->_newPatronFiltersSessionName, $value);
	}

	// -----------------------------------------------------------------------------------------------------------------
	// Patron search methods
	// -----------------------------------------------------------------------------------------------------------------

	/**
	 * @return mixed|null
	 */
	public function getNewPatronFilters()
	{
		return $this->getApplication()->getSession()->itemAt($this->_newPatronFiltersSessionName);
	}

	/**
	 * Return true if this component is used inside a popup window.
	 */
	public function getPopupFlag()
	{
		return $this->getPage()->IsPopup();
	}

	/**
	 * This function is called externally, and performs a re-population of the inner UserGrid component.
	 */
	public function globalRefresh()
	{
		$this->populate();
	}

	/**
	 * @return mixed
	 */
	public function getUnlinkFlag()
	{
		return $this->getPage()->IsUnlink();
	}


	// -----------------------------------------------------------------------------------------------------------------
	// Autocompleter field related methods
	// -----------------------------------------------------------------------------------------------------------------

	private function initVars()
	{
		$uniqueId = $this->getUniqueID();
		$this->_datasourceSessionName = 'DataSourceSessionName' . $uniqueId;
		$this->_checkedSessionName = 'CheckedSessionName' . $uniqueId;
		$this->_checked = $this->getCheckedItems();
		$this->_globalCriteriaSessionName = 'GlobalCriteriaSessionName' . $uniqueId;
		$this->_onlySelectedSessionName = 'OnlySelectedSessionName' . $uniqueId;
		$this->_filtersSessionName = 'FiltersSessionName' . $uniqueId;
		$this->_newPatronFiltersSessionName = 'NewPatronFiltersSessionName' . $uniqueId;
		$this->_viewFiltersSessionName = 'ViewFiltersSessionName' . $uniqueId;
		$this->_mainFiltersSessionName = 'MainFiltersSessionName' . $uniqueId;
	}

	private function createQueryBuilder()
	{
		if ($this->getShowFilterPanel()) {
			$queryBuilder = Prado::createComponent('QueryBuilder');
			$queryBuilder->setAllow('choice,customrules');
			$queryBuilder->setQBClass('QBPatron');

			$queryBuilder->attachEventHandler('onQBSearch', [$this, 'searchPatron']);
			$queryBuilder->attachEventHandler('onCallback', [$this, 'onCallback']);
			$queryBuilder->attachEventHandler('onSetDefaultRule', [$this, 'onSetDefaultRule']);

			$this->FilterRollingField->Controls[] = $queryBuilder;
			$this->registerObject('QueryBuilder', $queryBuilder);
		}
	}

	/**
	 * @return array
	 */
	private function getFiltersDefinition(): array
	{
		$select_operators = ['equal', 'not_equal', 'not_null_and_not_empty', 'null_or_empty'];
		$ac_operators = ['equal', 'not_equal', 'not_null_and_not_empty', 'null_or_empty'];
		$numbers_operators = array_merge($select_operators, ['less', 'less_or_equal', 'greater', 'greater_or_equal', 'between', 'not_between']);
		$strings_operators = array_merge($select_operators, $numbers_operators, ['begins_with', 'not_begins_with', 'contains', 'not_contains', 'ends_with', 'not_ends_with']);
		$date_operators = ['equal', 'not_equal', 'is_not_null', 'is_null','less', 'less_or_equal', 'greater', 'greater_or_equal', 'between', 'not_between' ];

		$filters = [
            ['id' => 'patron_id',
                'field' => 'patron.patron_id',
                'label' => 'Patron ID',
                'type' => 'integer',
                'input' => 'text',
                'validation' => ['allow_empty_value' => true],
                'operators' => $numbers_operators],

            ['id' => 'privacy_approve',
                'field' => 'patron.privacy_approve',
                'label' => 'Informativa privacy',
                'type' => 'string',
                'validation' => ['allow_empty_value' => true],
                'operators' => $strings_operators],

			['id' => 'barcode',
				'field' => 'patron.barcode',
				'label' => 'Codice a barre',
				'type' => 'string',
				'operators' => $strings_operators,
				'validation' => ['allow_empty_value' => true],
				'value_separator' => ','],

			['id' => 'card_number',
				'field' => 'patron.card_code',
				'label' => 'Numero tessera',
				'type' => 'string',
				'validation' => ['allow_empty_value' => true],
				'operators' => $strings_operators],

			['id' => 'lastname',
				'field' => 'patron.lastname',
				'label' => 'Cognome',
				'type' => 'string',
				'validation' => ['allow_empty_value' => true],
				'operators' => $strings_operators],

			['id' => 'name',
				'field' => 'patron.name',
				'label' => 'Nome',
				'type' => 'string',
				'validation' => ['allow_empty_value' => true],
				'operators' => $strings_operators],

			['id' => 'national_id',
				'field' => 'patron.national_id',
				'label' => 'Codice fiscale',
				'type' => 'string',
				'input' => 'text',
				'validation' => ['allow_empty_value' => true],
				'operators' => $strings_operators],

			['id' => 'document_number',
				'field' => 'patron.document_number',
				'label' => 'Numero documento',
				'type' => 'string',
				'input' => 'text',
				'validation' => ['allow_empty_value' => true],
				'operators' => $strings_operators],

			['id' => 'birth_date',
				'field' => 'patron.birth_date',
				'label' => 'Data nascita',
				'type' => 'date',
				'input' => 'text',
				'placeholder' => 'GG-MM-AAAA',
				'validation' => ['format' => 'DD-MM-YYYY', 'allow_empty_value' => true],
				'operators' => $date_operators],

			['id' => 'gender',
				'field' => 'patron.gender',
				'field_class' => 'SEX',
				'label' => 'Genere',
				'type' => 'string',
				'input' => 'select',
				'values' => [],
				'validation' => ['allow_empty_value' => true],
				'operators' => $select_operators],


			['id' => 'patron_status',
				'field' => 'patron.patron_status',
				'field_class' => 'PATRONSTATE',
				'label' => 'Stato',
				'type' => 'string',
				'input' => 'select',
				'values' => [],
				'validation' => ['allow_empty_value' => true],
				'operators' => $select_operators],

			['id' => 'civil_status',
				'field' => 'patron.civil_status',
				'field_class' => 'CIVILSTATE',
				'label' => 'Stato civile',
				'type' => 'string',
				'input' => 'select',
				'values' => [],
				'validation' => ['allow_empty_value' => true],
				'operators' => $strings_operators],

			['id' => 'address',
				'field' => 'address.street',
				'label' => 'Indirizzo',
				'type' => 'string',
				'validation' => ['allow_empty_value' => true],
				'operators' => $strings_operators],

			['id' => 'zip',
				'field' => 'address.zip',
				'label' => 'CAP',
				'type' => 'string',
				'validation' => ['allow_empty_value' => true],
				'operators' => $strings_operators],
			['id' => 'city',
				'field' => 'address.city',
				'label' => 'Comune',
				'type' => 'string',
				'validation' => ['allow_empty_value' => true],
				'operators' => $strings_operators],

			['id' => 'village',
				'field' => 'address.village',
				'label' => 'Frazione',
				'type' => 'string',
				'validation' => ['allow_empty_value' => true],
				'operators' => $strings_operators],

			['id' => 'province',
				'field' => 'address.province',
				'label' => 'Provincia',
				'type' => 'string',
				'validation' => ['allow_empty_value' => true],
				'operators' => $strings_operators],

			['id' => 'country',
				'field' => 'address.country',
				'label' => 'Nazione',
				'type' => 'string',
				'values' => [],
				'validation' => ['allow_empty_value' => true],
				'operators' => $strings_operators],

			['id' => 'citizenship',
				'field' => 'patron.citizenship',
				'label' => 'Nazionalità',
				'type' => 'string',
				'values' => [],
				'validation' => ['allow_empty_value' => true],
				'operators' => $strings_operators],

			['id' => 'privacy_approve',
				'field' => 'patron.privacy_approve',
				'label' => 'Sottoscrizione informativa privacy',
				'type' => 'string',
				'input' => 'select',
				'operators' => ['equal'],
				'values' => [ // we must choose values > 0 as keys to get the thing working. (it's an hash not an array)
					1 => 'Sottoscritta',
					2 => 'Non sottoscritta'
				],
				'validation' => ['allow_empty_value' => true],
				'value' => '1'
			],


			['id' => 'shelf_id',
				'field' => 'shelf_item.shelf_id',
				'label' => 'Scaffale',
				'type' => 'string',
				'input' => 'autocomplete',
				'values' => '',
				'validation' => ['allow_empty_value' => true],
				'operators' => ['equal', 'not_equal'],
				'SuggestionType' => 'shelves',
				'SuggestionSubType' => 'patron'],

			['id' => 'registration_library_id',
				'field' => 'patron.registration_library_id',
				'label' => 'Biblioteca registrazione',
				'type' => 'string',
				'input' => 'autocomplete',
				'values' => '',
				'validation' => ['allow_empty_value' => true],
				'operators' => $ac_operators,
				'SuggestionType' => 'libraries',
				'SuggestionSubType' => 'all'],

			['id' => 'preferred_library_id',
				'field' => 'patron.preferred_library_id',
				'label' => 'Biblioteca preferita',
				'type' => 'string',
				'input' => 'autocomplete',
				'values' => '',
				'validation' => ['allow_empty_value' => true],
				'operators' => $ac_operators,
				'SuggestionType' => 'libraries',
				'SuggestionSubType' => 'all'],

			['id' => 'loan_class',
				'field' => 'patron.loan_class',
				'field_class' => 'PATRONLOANCLASS',
				'label' => 'Classe utente',
				'type' => 'string',
				'input' => 'select',
				'values' => [],
				'validation' => ['allow_empty_value' => true],
				'operators' => $select_operators],

			['id' => 'contact_type',
				'field' => 'contact.contact_type',
				'field_class' => 'CONTACTTYPE',
				'label' => 'Contatto: tipo',
				'type' => 'string',
				'input' => 'select',
				'validation' => ['allow_empty_value' => true],
				'operators' => $select_operators],

			['id' => 'contact_value',
				'field' => 'contact.contact_value',
				'label' => 'Contatto: valore',
				'type' => 'string',
				'validation' => ['allow_empty_value' => true],
				'operators' => $strings_operators],

			['id' => 'preferred_contact',
				'field' => 'contact.contact_pref',
				'field_class' => 'CONTACTTYPE',
				'label' => 'Contatto preferito',
				'type' => 'string',
				'input' => 'select',
				'value' => '1',
				'validation' => ['allow_empty_value' => true],
				'operators' => $select_operators],

			['id' => 'date_created',
				'field' => 'patron.date_created',
				'label' => 'Data  registrazione',
				'type' => 'date',
				'input' => 'text',
				'allow_empty_value' => true,
				'placeholder' => 'GG-MM-AAAA',
				'validation' => ['format' => 'DD-MM-YYYY', 'allow_empty_value' => true],
				'operators' => $date_operators],

            ['id' => 'date_updated',
                'field' => 'patron.date_updated',
                'label' => 'Data ultima modifica',
                'type' => 'date',
                'input' => 'text',
                'allow_empty_value' => true,
                'placeholder' => 'GG-MM-AAAA',
                'validation' => ['format' => 'DD-MM-YYYY', 'allow_empty_value' => true],
                'operators' => $date_operators],

			['id' => 'last_seen',
				'field' => 'patron.last_seen',
				'label' => 'Data ultima operazione',
				'type' => 'date',
				'input' => 'text',
				'allow_empty_value' => true,
				'placeholder' => 'GG-MM-AAAA',
				'validation' => ['format' => 'DD-MM-YYYY', 'allow_empty_value' => true],
				'operators' => $date_operators],

			['id' => 'card_expire',
				'field' => 'patron.card_expire',
				'label' => 'Data scadenza tessera',
				'type' => 'date',
				'input' => 'text',
				'placeholder' => 'GG-MM-AAAA',
				'validation' => ['format' => 'DD-MM-YYYY', 'allow_empty_value' => true],
				'allow_empty_value' => true,
				'operators' => $date_operators],

			['id' => 'document_expiry',
				'field' => 'patron.document_expiry',
				'label' => 'Data scadenza documento',
				'type' => 'date',
				'input' => 'text',
				'placeholder' => 'GG-MM-AAAA',
				'validation' => ['format' => 'DD-MM-YYYY', 'allow_empty_value' => true],
				'allow_empty_value' => true,
				'operators' => $date_operators],

			['id' => 'loan_start_date',
				'field' => 'item_action.action_date',
				'label' => 'Data inizio prestito',
				'type' => 'date',
				'input' => 'text',
				'placeholder' => 'GG-MM-AAAA',
				'validation' => ['format' => 'DD-MM-YYYY', 'allow_empty_value' => true],
				'allow_empty_value' => true,
				'operators' => $date_operators],

			['id' => 'loan_end_date',
				'field' => 'item_action.action_date',
				'label' => 'Data rientro prestito',
				'type' => 'date',
				'input' => 'text',
				'placeholder' => 'GG-MM-AAAA',
				'validation' => ['format' => 'DD-MM-YYYY', 'allow_empty_value' => true],
				'allow_empty_value' => true,
				'operators' => $date_operators],

			['id' => 'statistic_study',
				'field' => 'patron.statistic_study',
				'field_class' => 'STUDTYPE',
				'label' => 'Titolo studio',
				'input' => 'select',
				'type' => 'string',
				'validation' => ['allow_empty_value' => true],
				'operators' => $select_operators],

			['id' => 'statistic_work',
				'field' => 'patron.statistic_work',
				'field_class' => 'WORKTYPE',
				'label' => 'Professione',
				'input' => 'select',
				'type' => 'string',
				'validation' => ['allow_empty_value' => true],
				'operators' => $select_operators],

			['id' => 'opac_username',
				'field' => 'patron.opac_username',
				'label' => 'Username',
				'type' => 'string',
				'input' => 'text',
				'validation' => ['allow_empty_value' => true],
				'operators' => $strings_operators],

			['id' => 'patron_note',
				'field' => 'patron.patron_note',
				'label' => 'Nota utente',
				'type' => 'string',
				'input' => 'text',
				'validation' => ['allow_empty_value' => true],
				'operators' => $strings_operators],

			['id' => 'count_loans',
				'field' => 'numLoans',
				'label' => 'Prestiti in corso',
				'type' => 'string',
				'input' => 'text',
				'validation' => ['allow_empty_value' => true],
				'operators' => $numbers_operators],

            ['id' => 'count_allloans',
                'field' => 'numAllLoans',
                'label' => 'Prestiti totali',
                'type' => 'string',
                'input' => 'text',
                'validation' => ['allow_empty_value' => true],
                'operators' => $numbers_operators]
		];

		$filters = array_merge($filters, $this->getCustomFields($strings_operators));
		$filters = array_merge($filters, $this->getPatronProperties($strings_operators));
		return $filters;
	}

	// -----------------------------------------------------------------------------------------------------------------
	// New patron from current search utility methods
	// -----------------------------------------------------------------------------------------------------------------

	/**
	 * @return array
	 */
	private function getCustomFields($operators)
	{
		$getCustomField = function ($num) {
			return [
				'label' => LookupValuePeer::getLookupValue('CUSTOMLABEL', 'PatronCustom' . $num),
				'input' => LookupValuePeer::classExists('PATRONCUST' . $num) ? 'select' : '',
				'values' => LookupValuePeer::getLookupClassValues('PATRONCUST' . $num, false)
			];
		};

		for ($i = 1; $i <= 3; $i++) {
			$data = $getCustomField($i);

			$a[] = [
				'id' => 'custom' . $i,
				'field' => 'patron.custom' . $i,
				'label' => $data['label'],
				'type' => 'string',
				'input' => $data['input'],
				'values' => $data['values'],
				'validation' => ['allow_empty_value' => true],
				'operators' => $operators
			];
		}
		return $a;
	}

	private function getPatronProperties($operators)
	{
		$patron_properties = LookupValuePeer::getLookupClassValues('PATRONPROPERTY');
		foreach ($patron_properties as $class => $value) {
			$a[] = [
				'id' => 'patron_property_' . $class,
				'field' => 'patron_property.property_value',
				'label' => $value,
				'type' => 'string',
				'input' => '',
				'validation' => ['allow_empty_value' => true],
				'operators' => $operators
			];
		}
		return $a;
	}

	/**
	 * @return array
	 */
	private function getTransformationRules(): array
	{
		foreach (LookupValuePeer::getLookupClassValues('PATRONPROPERTY') as $class => $value) {
			$patron_property_classes['patron_property_' . $class] = [

				'transform_type' => 'inject_rules',
				'transform_param' => [
					'inject_rules' => [
						'condition' => Criteria::LOGICAL_AND,
						'rules' => [
							['field' => 'patron_property.property_class', 'operator' => 'equal', 'value' => $class],
							['field' => 'patron_property.property_value', 'operator' => '?', 'value' => '?']
						]
					]
				]
			];
		}

		$transformation_rules = [
			'preferred_contact' => [
				'field_name' => [
					'default' => 'contact.contact_pref',
				],

				'transform_type' => 'inject_rules',
				'transform_param' => [
					'inject_rules' => [
						'condition' => Criteria::LOGICAL_AND,
						'rules' => [
							['field' => 'contact.contact_type', 'operator' => '?', 'value' => '?'],
							['field' => 'contact.contact_pref', 'operator' => 'equal', 'value' => '1']
						]
					]
				]
			],

			'privacy_approve' => [
				'field_name' => [
					'default' => 'patron.privacy_approve',
				],
				'transform_type' => 'operator_value_map',
				'transform_param' => [
					'operator_value_map' => [
						// privacy sottoscritta => equal '1'
						// privacy non sottoscritta  => not_equal '1'
						'value_map' => [1 => 1, 2 => '1'],
						'operator_map' => [1 => 'equal', 2 => 'not_equal']
					]
				]
			],

			'loan_start_date' => [
				'transform_type' => 'inject_rules',
				'transform_param' => [
					'inject_rules' => [
						'condition' => Criteria::LOGICAL_AND,
						'rules' => [
							['field' => ItemActionPeer::ACTION_DATE, 'operator' => '?', 'value' => '?'],
							['field' => ItemActionPeer::ACTION_TYPE, 'operator' => 'equal', 'value' => ItemActionPeer::TYPE_LOAN]

						],
						'distinct' => true
					]
				]
			],

			'loan_end_date' => [
				'transform_type' => 'inject_rules',
				'transform_param' => [
					'inject_rules' => [
						'condition' => Criteria::LOGICAL_AND,
						'rules' => [
							['field' => ItemActionPeer::ACTION_DATE, 'operator' => '?', 'value' => '?'],
							['field' => ItemActionPeer::ACTION_TYPE, 'operator' => 'equal', 'value' => ItemActionPeer::TYPE_RETURN]
						],
						'distinct' => true
					]
				]
			],

			'count_loans'=> [
				'transform_type' => 'openloans',
				'transform_param' => [
					'openloans' => [

						'having' => ['field' => 'numLoans', 'operator' => '?', 'value' => '?']
					]
				]
			],

            'count_allloans'=> [
                'transform_type' => 'allloans',
                'transform_param' => [
                    'allloans' => [
                        'having' => ['field' => 'numAllLoans', 'operator' => '?', 'value' => '?']
                    ]
                ]
            ],
		];
		return array_merge($patron_property_classes, $transformation_rules);
	}

	/**
	 * @return array
	 */
	private function getJoinRules(): array
	{
		$joinRules['patron'] = [
			'isInJoin' => true,
			'from' => PatronPeer::PATRON_ID,
			'to' => PatronPeer::PATRON_ID,
			'type' => Criteria::INNER_JOIN
		];

		$joinRules['shelf_item'] = [
			'isInJoin' => false,
			'from' => PatronPeer::PATRON_ID,
			'to' => ShelfItemPeer::OBJECT_ID,
			'type' => Criteria::INNER_JOIN
		];

		$joinRules['contact'] = [
			'isInJoin' => false,
			'from' => PatronPeer::PATRON_ID,
			'to' => ContactPeer::PATRON_ID,
			'type' => Criteria::INNER_JOIN
		];

		$joinRules['address'] = [
			'isInJoin' => false,
			'from' => PatronPeer::PATRON_ID,
			'to' => AddressPeer::PATRON_ID,
			'type' => Criteria::INNER_JOIN
		];

		$joinRules['patron_property'] = [
			'isInJoin' => false,
			'from' => PatronPeer::PATRON_ID,
			'to' => PatronPropertyPeer::PATRON_ID,
			'type' => Criteria::INNER_JOIN,
			'allow_multiple_join' => true
		];

		$joinRules['item_action'] = [
			'isInJoin' => false,
			'from' => PatronPeer::PATRON_ID,
			'to' => ItemActionPeer::PATRON_ID,
			'type' => Criteria::INNER_JOIN
		];

		$joinRules['loan'] = [
			'isInJoin' => false,
			'from' => PatronPeer::PATRON_ID,
			'to' => LoanPeer::PATRON_ID,
			'type' => Criteria::LEFT_JOIN
		];

		return $joinRules;
	}

	/**
	 * @param      $search
	 * @param      $type
	 * @param null $subtype
	 * @return array
	 */
	private function buildSuggestionFor($search, $type, $subtype = null)
	{
		switch ($type) {
			case 'libraries':
				return $this->getDataLibraries($search, $subtype);
				break;
			case 'shelves':
				return $this->getDataShelves($search, $subtype);
				break;
		}
	}

	/**
	 * @param string $search
	 * @param string $subtype
	 * @return array
	 */
	private function getDataShelves($search = '', $subtype = 'patron'): array
	{
		$shelfQuery = ShelfQuery::create();
		$shelfQuery
			->filterByShelfItemtype($subtype)
			->filterByShelfName("%$search%", Criteria::LIKE);

		$output = [];
		/** @var \Shelf $shelf */
		foreach ($shelfQuery->find() as $shelf) {
			$output[$shelf->getShelfId()] = htmlspecialchars($shelf->getShelfName());
		}
		return $output;
	}

	// -----------------------------------------------------------------------------------------------------------------
	// External and utility functions
	// -----------------------------------------------------------------------------------------------------------------

	/**
	 * @param string $search
	 * @param string $subtype // internal, external, all
	 * @return array
	 */
	private function getDataLibraries($search = '', $subtype = '')
	{
		$libQuery = LibraryQuery::create();

		if ($subtype === 'internal') {
			$libQuery->filterByLibraryInternal(true);
		}

		if ($subtype === 'external') {
			$libQuery->filterByLibraryInternal(false);
		}

		$libQuery->filterByLabel("%$search%", Criteria::LIKE)
			->orderByLabel(Criteria::ASC)
			->orderByLibraryId()
			->limit(11);

		$output = [];
		/** @var \Library $library */
		foreach ($libQuery->find() as $library) {
			$output[$library->getLibraryId()] = htmlspecialchars($library->getLabel());
		}
		return $output;
	}

	/**
	 * @param $rules
	 */
	private function addNewPatronFilters($rules)
	{
		$this->setNewPatronFilters(array_map(function ($rule) {
			return ['id' => $rule->id, 'value' => filter_var($rule->value, FILTER_SANITIZE_STRING)];
		}, $rules->rules));
	}

	/**
	 * @param $sender
	 * @param $params
	 * @throws \TInvalidDataValueException
	 * @throws \TInvalidOperationException
	 */
	private function onPatronSearchDone($sender, $params)
	{
		$this->raiseEvent('onPatronSearchDone', $sender, $params);
	}

	/**
	 *
	 */
	private function doRenderPrintPanel()
	{
		$this->PrintPanel->setStyle('display:' . (count($this->getDataSource()) > 0 ? 'block' : 'none'));
	}
}
