<?php
/**
 * ClavisPatronList class file.
 *
 * This file contains all the required classes for SBN dialogue v4.
 * Based upon SBNConnector by Comperio srl.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Dario Rigolin <dario@comperio.it>
 * @author Marco Brancalion <marco@comperio.it>
 * @author Ciro Mattia Gonano
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.8.9
 * @package Widgets
 */

/**
 * ClavisPatronList Class
 *
 * @author Dario Rigolin <dario@comperio.it>
 * @author Marco Brancalion <marco@comperio.it>
 * @author Ciro Mattia Gonano
 * @version 2.8.9
 * @package Widgets
 * @since 2.0
 */
class ClavisPatronList extends TTemplateControl
{
	private $_checked = array('all' => false);
	private $_checkedSessionName;
	private $_datasource;
	private $_datasourceSessionName;
	public $_masterChecked;
	private $_globalCriteriaSessionName;
	public $_onlySelectedSessionName;
	private $_filters = array();
	private $_filtersSessionName;
	private $_newPatronFiltersSessionName;
	private $_viewFiltersSessionName;
	private $_mainFiltersSessionName;
	public $customs_type = array('text', 'text', 'text');

	private function initVars()
	{
		$uniqueId = $this->getUniqueID();
		$this->_datasourceSessionName = 'DataSourceSessionName' . $uniqueId;
		$this->_checkedSessionName = 'CheckedSessionName' . $uniqueId;
		$this->_checked = $this->getCheckedItems();
		$this->_globalCriteriaSessionName = 'GlobalCriteriaSessionName' . $uniqueId;
		$this->_onlySelectedSessionName = 'OnlySelectedSessionName' . $uniqueId;
		$this->_filtersSessionName = 'FiltersSessionName' . $uniqueId;
		$this->_newPatronFiltersSessionName = 'NewPatronFiltersSessionName' . $uniqueId;
		$this->_viewFiltersSessionName = 'ViewFiltersSessionName' . $uniqueId;
		$this->_mainFiltersSessionName = 'MainFiltersSessionName' . $uniqueId;
	}

	public function onInit($param)
	{
		parent::onInit($param);
		$this->initVars();

		$this->setViewFilters(true);
	}

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (LookupValuePeer::classExists('PATRONCUST1'))
			$this->customs_type[0] = 'list';
		
		if (LookupValuePeer::classExists('PATRONCUST2'))
			$this->customs_type[1] = 'list';
		
		if (LookupValuePeer::classExists('PATRONCUST3'))
			$this->customs_type[2] = 'list';

		if (!$this->getPage()->getIsPostBack() 
				&& !$this->getPage()->getIsCallBack())
		{
			$this->drawCustomPanels(true);

			foreach ($this->getFilters() as $controlName => $controlContent)
			{
				$control = $this->findControl($controlName);
				
				/**
				 * Theorically, here we're checking if this control
				 * exists within the page
				 */
				if (!is_null($control))
				{
					$controlId = $control->getID();
					switch (get_class($control))
					{
						case 'TTextBox':
							$this->$controlId->setText($controlContent);
				
							break;

						case 'TDropDownList':
						case 'TDBDropDownList':
							$this->$controlId->setSelectedValue($controlContent);
							
							break;
					}
				}
			}

			$this->UserGrid->resetPagination();

			$systemLibraries = LibraryPeer::getLibrariesHashWithBlank(false, true);
			$this->RegLibraryFilter->setDataSource($systemLibraries);
			$this->RegLibraryFilter->dataBind();

			$this->LibraryFilter->setDataSource($systemLibraries);
			$this->LibraryFilter->dataBind();

			$this->ContactBooleanFilter->setDataSource(array(	1 => Prado::localize('con'),
																0 => Prado::localize('senza') ));
			$this->ContactBooleanFilter->dataBind();
			$this->ContactBooleanFilter->setSelectedValue(1);

			$this->ContactValuePanel->setCssClass('panel_off');

			$this->AllCustomCheck->setChecked(false);
			$this->drawCustomPanels(false);

			$this->resetNewPatronFilters();
			$this->resetDataSource();
		}

		$this->FilterPanel->setCssClass($this->getViewFilters() ? 'panel_on' : 'panel_off');
		$this->doRenderPrintPanel();
	}

	private function doRenderPrintPanel()
	{
		$this->PrintPanel->setStyle('display:' . (count($this->getDataSource()) > 0 ? 'block' : 'none'));
	}

	public function setPopupCustomReturn($label, $value)
	{
		if (!$this->getPage()->isPopup())
			return;

		$this->setControlState('PopupCustomReturnLabel', $label, null);
		$this->setControlState('PopupCustomReturnValue', $value, null);
	}

	public function getPopupCustomReturnValue()
	{
		return $this->getControlState('PopupCustomReturnValue', null);
	}

	public function getPopupCustomReturnLabel()
	{
		return $this->getControlState('PopupCustomReturnLabel', null);
	}

	public function resetFilters()
	{
		$this->_filters = array();
		$this->setFilters($this->_filters);
	}

	public function setFilters($value = array())
	{
		if (!is_array($value))
			$value = array();
		
		$this->_filters = $value;
		$this->getApplication()->getSession()->add($this->_filtersSessionName, $this->_filters);
	}

	public function getFilters()
	{
		$this->_filters = $this->getApplication()->getSession()->itemAt($this->_filtersSessionName);
		
		if (is_null($this->_filters))
			$this->_filters = array();

		return $this->_filters;
	}

	public function setViewFilters($filter = true)
	{
		$this->getApplication()->getSession()->add($this->_viewFiltersSessionName, $filter);
	}

	public function getViewFilters()
	{
		$filter = $this->getApplication()->getSession()->itemAt($this->_viewFiltersSessionName);
		
		if (is_null($filter))
			$filter = true;
		
		return $filter;
	}

	public function setMainFilters($value = false)
	{
		$this->getApplication()->getSession()->add($this->_mainFiltersSessionName, $value, false);
	}

	public function getMainFilters()
	{
		return $this->getApplication()->getSession()->itemAt($this->_mainFiltersSessionName, false);
	}

	public function resetNewPatronFilters()
	{
		$this->setNewPatronFilters("");
	}

	public function setNewPatronFilters($value = "")
	{
		$this->getApplication()->getSession()->add($this->_newPatronFiltersSessionName, $value);
	}

	public function getNewPatronFilters()
	{
		return $this->getApplication()->getSession()->itemAt($this->_newPatronFiltersSessionName);
	}

	private function addNewPatronFilters($key = "", $value = "")
	{
		if ((trim($value) == "") 
				|| (trim($key) == ""))
			return false;

		$data = $this->getNewPatronFilters();
		
		if ($data == null) 
			$data = [];
		
		$data[$key] = $value;

		$this->setNewPatronFilters($data);
	}

	public function setViewDateCreated($value = false)
	{
		$this->setControlState("ViewDateCreated", $value, false);
	}

	public function getViewDateCreated()
	{
		$result = $this->getControlState("ViewDateCreated");
		
		if (is_null($result))
			$result = false;
		
		return $result;
	}

	public function resetDataSource($populateFlag = true)
	{
		$this->resetCheckedItems();
		$this->resetOnlySelected();
		$this->resetGlobalCriteria();
		$this->resetPagination();

		$this->_datasource = array();
		$this->getApplication()->getSession()->add($this->_datasourceSessionName, $this->_datasource);

		if ($populateFlag)
			$this->populate();
	}

	public function setDatasource($datasource = null)
	{
		if ($datasource == null)
		{
			$datasource = $this->_datasource;
		}
		else
		{
			$this->_datasource = $datasource;
		}
		
		$this->getApplication()->getSession()->add($this->_datasourceSessionName, $datasource);
	}

	public function getDatasource()
	{
		if (is_null($this->_datasource))
			$this->_datasource = $this->getApplication()->getSession()->itemAt($this->_datasourceSessionName);
		
		return $this->_datasource;
	}

	public function resetGlobalCriteria()
	{
		$this->setGlobalCriteria(null);
	}

	public function setGlobalCriteria($criteria = null)
	{
		$this->getApplication()->getSession()->add($this->_globalCriteriaSessionName, $criteria, null);
	}

	public function getGlobalCriteria()
	{
		$crit = $this->getApplication()->getSession()->itemAt($this->_globalCriteriaSessionName, null);
		
		if (is_array($crit) && array_key_exists('body', $crit))
		{
			$crit['body'] = SerializableCriteria::refreshCriteria($crit['body']);
		}
		else
		{
			$crit = SerializableCriteria::refreshCriteria($crit);
		}

		return $crit;
	}

	public function resetOnlySelected($value = false)
	{
		$this->setOnlySelected($value);

		$this->OnlySelectedCheck->setChecked($value);
		$this->SelectedNumber->setText('0');
	}

	public function setOnlySelected($flag = false)
	{
		if ($flag === 'false')
			$flag = false;
		
		if ($flag === 'true')
			$flag = true;

		$this->getApplication()->getSession()->add($this->_onlySelectedSessionName, $flag, false);
	}

	public function getOnlySelected()
	{
		$flag = $this->getApplication()->getSession()->itemAt($this->_onlySelectedSessionName);
		
		return $flag;
	}

	public function searchPatron($sender, $param)
	{
		$this->resetDataSource();
	}

	public function calculateSortingCriteria(&$sortingCriteria = null)
	{
		$sortingExpression = $this->UserGrid->getSortingExpression();
		$sortingDirection = $this->UserGrid->getSortingDirection();

		if (is_null($sortingCriteria) 
				|| !($sortingCriteria instanceof Criteria))
			$sortingCriteria = new Criteria();

		switch ($sortingExpression)
		{
			case 'patronName':
				$sortingCriteria->clearOrderByColumns();
				
				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
				{
					$sortingCriteria->addAscendingOrderByColumn(PatronPeer::LASTNAME);
					$sortingCriteria->addAscendingOrderByColumn(PatronPeer::NAME);
				}
				elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
				{
					$sortingCriteria->addDescendingOrderByColumn(PatronPeer::LASTNAME);
					$sortingCriteria->addDescendingOrderByColumn(PatronPeer::NAME);
				}
				
				break;

			case 'dateCreated':
				$sortingCriteria->clearOrderByColumns();
				
				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
				{
					$sortingCriteria->addAscendingOrderByColumn(PatronPeer::DATE_CREATED);
				}
				elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
				{
					$sortingCriteria->addDescendingOrderByColumn(PatronPeer::DATE_CREATED);
				}
				
				break;

			case 'birthDate':
				$sortingCriteria->clearOrderByColumns();
				
				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
				{
					$sortingCriteria->addAscendingOrderByColumn(PatronPeer::BIRTH_DATE);
				}
				elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
				{
					$sortingCriteria->addDescendingOrderByColumn(PatronPeer::BIRTH_DATE);
				}
				
				break;

			/*
			  case 'cardCode':
			  $sortingCriteria->clearOrderByColumns();
			  if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
			  $sortingCriteria->addAscendingOrderByColumn(PatronPeer::CARD_CODE);
			  elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
			  $sortingCriteria->addDescendingOrderByColumn(PatronPeer::CARD_CODE);
			  break;
			 */
			case 'barCode':
				$sortingCriteria->clearOrderByColumns();
				
				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
				{
					$sortingCriteria->addAscendingOrderByColumn(PatronPeer::BARCODE);
				}
				elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
				{
					$sortingCriteria->addDescendingOrderByColumn(PatronPeer::BARCODE);
				}
				
				break;

			case null:
				break;

			default:
				$sortingExpression = null;
				break;
		}
	}

	/**
	 * This is a wrapper for populatePatronGrid()
	 */
	public function populate()
	{
		$this->populatePatronGrid();
	}

	public function populatePatronGrid($givenIds = null)
	{
		$pageSize = $this->UserGrid->getPageSize();
		$currentIndexPage = $this->UserGrid->getCurrentPage();
		$viewDateCreated = $CFFilterFlag = false;
		$classFilter = null;

		if ($this->getOnlySelected())
			$givenIds = $this->getCheckedId();

		if (!is_null($givenIds) 
				&& is_array($givenIds))
		{
			$patrons = PatronPeer::retrieveByPKs($givenIds);
			$recCount = count($patrons);

			$this->setGlobalCriteria(array(	'type' => 'givenIds', 
											'body' => $givenIds ));
		}
		else   // normal case, searching by filters
		{
			$c = new Criteria();

			$libraryId = $this->LibraryFilter->getSelectedValue();
			
			if ($libraryId != 0)
				$c->add(PatronPeer::PREFERRED_LIBRARY_ID, $libraryId);

			$regLibraryId = $this->RegLibraryFilter->getSelectedValue();
			
			if ($regLibraryId != 0)
				$c->add(PatronPeer::REGISTRATION_LIBRARY_ID, $regLibraryId);

			$lastNameFilter = trim(str_replace('"', '', $this->LastnameFilter->getSafeText()));
			
			if ($lastNameFilter != "")
			{
				$c->add(PatronPeer::LASTNAME, $lastNameFilter . '%', Criteria::LIKE);
				$this->addNewPatronFilters("LastName", $lastNameFilter);
			}

			$nameFilter = trim(str_replace('"', '', $this->NameFilter->getSafeText()));
			
			if ($nameFilter != "")
			{
				$c->add(PatronPeer::NAME, $nameFilter . '%', Criteria::LIKE);
				$this->addNewPatronFilters("Name", $nameFilter);
			}

			$barcodeFilter = trim($this->BarcodeFilter->getSafeText());
			
			if ($barcodeFilter != "")
				$c->add(PatronPeer::BARCODE, $barcodeFilter);

			$cardcodeFilter = trim($this->CardcodeFilter->getSafeText());
			
			if ($cardcodeFilter != "")
				$c->add(PatronPeer::CARD_CODE, $cardcodeFilter);

			$CFFilter = trim($this->CFFilter->getSafeText());
			
			if ($CFFilter != "")
			{
				$c->add(PatronPeer::NATIONAL_ID, $CFFilter);
				$this->addNewPatronFilters("NationalId", $CFFilter);
				$CFFilterFlag = true;
			}
			else
			{
				$CFFilterFlag = false;
			}

			$patronStatus = TPropertyValue::ensureString($this->PatronStatusFilter->getSelectedValue());
			
			if ($patronStatus == '0')
				$patronStatus = '';

			if ($patronStatus != '')
				$c->add(PatronPeer::PATRON_STATUS, $patronStatus);

			$sex = $this->SexFilter->getSelectedIndex() > 0 ? $this->SexFilter->getSelectedValue() : null;
			
			if (!is_null($sex))
				$c->addAnd(PatronPeer::GENDER, $sex);

			$classFilter = $this->ClassFilter->getSelectedIndex() > 0 ? $this->ClassFilter->getSelectedValue() : null;
			
			if (!is_null($classFilter))
				$c->addAnd(PatronPeer::LOAN_CLASS, $classFilter);

			$ageFrom = $this->AgeFromFilter->getTimeStamp();
			
			if (!is_null($ageFrom))
			{
				$ageFromCriterion = $c->getNewCriterion(PatronPeer::BIRTH_DATE, $ageFrom, Criteria::GREATER_EQUAL);
				$c->addAnd($ageFromCriterion);

				$this->addNewPatronFilters("BirthDate", $ageFrom);
			}

			$ageTo = $this->AgeToFilter->getTimeStamp();
			
			if (!is_null($ageTo))
			{
				$ageToCriterion = $c->getNewCriterion(PatronPeer::BIRTH_DATE, $ageTo + 86399, Criteria::LESS_EQUAL);
				$c->addAnd($ageToCriterion);
			}

			$creationFrom = $this->CreationFromFilter->getTimeStamp();
			
			if (!is_null($creationFrom))
			{
				$creationFromCriterion = $c->getNewCriterion(PatronPeer::DATE_CREATED, $creationFrom, Criteria::GREATER_EQUAL);
				$c->addAnd($creationFromCriterion);
			}

			$creationTo = $this->CreationToFilter->getTimeStamp();
			
			if (!is_null($creationTo))
			{
				$creationToCriterion = $c->getNewCriterion(PatronPeer::DATE_CREATED, $creationTo + 86399, Criteria::LESS_EQUAL);
				$c->addAnd($creationToCriterion);
			}

			$lastSeenFrom = $this->LastSeenFromFilter->getTimeStamp();
			
			if (!is_null($lastSeenFrom))
			{
				$lastSeenFromCriterion = $c->getNewCriterion(PatronPeer::LAST_SEEN, $lastSeenFrom, Criteria::GREATER_EQUAL);
				$c->addAnd($lastSeenFromCriterion);
			}

			$lastSeenTo = $this->LastSeenToFilter->getTimeStamp();
			
			if (!is_null($lastSeenTo))
			{
				$lastSeenToCriterion = $c->getNewCriterion(PatronPeer::LAST_SEEN, $lastSeenTo + 86399, Criteria::LESS_EQUAL);
				$c->addAnd($lastSeenToCriterion);
			}

			$cardExpireFrom = $this->CardExpireFromFilter->getTimeStamp();
			
			if (!is_null($cardExpireFrom))
			{
				$cardExpireFromCriterion = $c->getNewCriterion(PatronPeer::CARD_EXPIRE, $cardExpireFrom, Criteria::GREATER_EQUAL);
				$c->addAnd($cardExpireFromCriterion);
			}

			$cardExpireTo = $this->CardExpireToFilter->getTimeStamp();
			
			if (!is_null($cardExpireTo))
			{
				$cardExpireToCriterion = $c->getNewCriterion(PatronPeer::CARD_EXPIRE, $cardExpireTo + 86399, Criteria::LESS_EQUAL);
				$c->addAnd($cardExpireToCriterion);
			}

			$documentExpiryFrom = $this->DocumentExpiryFromFilter->getTimeStamp();
			
			if (!is_null($documentExpiryFrom))
			{
				$documentExpiryFromCriterion = $c->getNewCriterion(PatronPeer::DOCUMENT_EXPIRY, $documentExpiryFrom, Criteria::GREATER_EQUAL);
				$c->addAnd($documentExpiryFromCriterion);
			}

			$documentExpiryTo = $this->DocumentExpiryToFilter->getTimeStamp();
			
			if (!is_null($documentExpiryTo))
			{
				$documentExpiryToCriterion = $c->getNewCriterion(PatronPeer::DOCUMENT_EXPIRY, $documentExpiryTo + 86399, Criteria::LESS_EQUAL);
				$c->addAnd($documentExpiryToCriterion);
			}

			/*
			 * filtering in custom fields
			 */
			if ($this->AllCustomCheck->getChecked())
			{  // we're searching in one the the custom fields ......
				$customAllFilter = trim($this->CustomAllFilter->getSafeText());
			
				if ($customAllFilter != '')
				{
					$criterion1 = $c->getNewCriterion(PatronPeer::CUSTOM1, '%' . $customAllFilter . '%', Criteria::LIKE);
					$criterion2 = $c->getNewCriterion(PatronPeer::CUSTOM2, '%' . $customAllFilter . '%', Criteria::LIKE);
					$criterion3 = $c->getNewCriterion(PatronPeer::CUSTOM3, '%' . $customAllFilter . '%', Criteria::LIKE);

					$criterion1->addOr($criterion2);
					$criterion1->addOr($criterion3);
					$c->addAnd($criterion1);
				}
			}
			else
			{  // we're searching "each filter each customX field"
				if ($this->customs_type[0] == 'list' && $this->CustomList1->getSelectedIndex() > 0)
				{
					$c->add(PatronPeer::CUSTOM1, $this->CustomList1->getSelectedValue());
				}
				elseif ($this->customs_type[0] == 'text' && trim($this->Custom2->getSafeText()))
				{
					$c->add(PatronPeer::CUSTOM1, '%' . trim($this->Custom2->getSafeText()) . '%', Criteria::LIKE);
				}

				if ($this->customs_type[1] == 'list' && $this->CustomList2->getSelectedIndex() > 0)
				{
					$c->add(PatronPeer::CUSTOM2, $this->CustomList2->getSelectedValue());
				}
				elseif ($this->customs_type[1] == 'text' && trim($this->Custom2->getSafeText()))
				{
					$c->add(PatronPeer::CUSTOM2, '%' . trim($this->Custom2->getSafeText()) . '%', Criteria::LIKE);
				}

				if ($this->customs_type[2] == 'list' && $this->CustomList3->getSelectedIndex() > 0)
				{
					$c->add(PatronPeer::CUSTOM3, $this->CustomList3->getSelectedValue());
				}
				elseif ($this->customs_type[2] == 'text' && trim($this->Custom3->getSafeText()))
				{
					$c->add(PatronPeer::CUSTOM3, '%' . trim($this->Custom3->getSafeText()) . '%', Criteria::LIKE);
				}
			}

			switch ($this->PrivacyApproveFilter->getSelectedValue())
			{
				case 1:
					$c->addAnd(PatronPeer::PRIVACY_APPROVE, 1);

					break;

				case 2:
					$criterionPrivacy1 = $c->getNewCriterion(PatronPeer::PRIVACY_APPROVE, 1, Criteria::NOT_EQUAL);
					$criterionPrivacy2 = $c->getNewCriterion(PatronPeer::PRIVACY_APPROVE, "", Criteria::LIKE);
					$criterionPrivacy3 = $c->getNewCriterion(PatronPeer::PRIVACY_APPROVE, null, Criteria::ISNULL);

					$criterionPrivacy1->addOr($criterionPrivacy2);
					$criterionPrivacy1->addOr($criterionPrivacy3);
					$c->addAnd($criterionPrivacy1);

					break;

				default:
					break;
			}
		
			$loanCriterion = null;
			$returnCriterion = null;
			/*
			 *  filtering in loan begin date
			 */
			$loanFromFilter = $this->LoanFromFilter->getTimeStamp();
			$loanToFilter = $this->LoanToFilter->getTimeStamp();
			
			if (!is_null($loanFromFilter) 
					|| !is_null($loanToFilter))
			{
				$c->setDistinct();
				$c->addJoin(PatronPeer::PATRON_ID, ItemActionPeer::PATRON_ID, Criteria::INNER_JOIN);
				$loanCriterion = $c->getNewCriterion(ItemActionPeer::ACTION_TYPE, ItemActionPeer::TYPE_LOAN);

				if (!is_null($loanFromFilter))
				{
					$loanFromCriterion = $c->getNewCriterion(ItemActionPeer::ACTION_DATE, $loanFromFilter, Criteria::GREATER_EQUAL);
					$loanCriterion->addAnd($loanFromCriterion);
				}

				if (!is_null($loanToFilter))
				{
					$loanToCriterion = $c->getNewCriterion(ItemActionPeer::ACTION_DATE, $loanToFilter + 86399, Criteria::LESS_EQUAL);
					$loanCriterion->addAnd($loanToCriterion);
				}
			}

			/*
			 *  filtering in return date
			 */
			$returnFromFilter = $this->ReturnFromFilter->getTimeStamp();
			$returnToFilter = $this->ReturnToFilter->getTimeStamp();
			
			if (!is_null($returnFromFilter) || !is_null($returnToFilter))
			{
				$c->setDistinct();
				$c->addJoin(PatronPeer::PATRON_ID, ItemActionPeer::PATRON_ID, Criteria::INNER_JOIN);
				$returnCriterion = $c->getNewCriterion(ItemActionPeer::ACTION_TYPE, ItemActionPeer::TYPE_RETURN);

				if (!is_null($returnFromFilter))
				{
					$returnFromCriterion = $c->getNewCriterion(ItemActionPeer::ACTION_DATE, $returnFromFilter, Criteria::GREATER_EQUAL);
					$returnCriterion->addAnd($returnFromCriterion);
				}

				if (!is_null($returnToFilter))
				{
					$returnToCriterion = $c->getNewCriterion(ItemActionPeer::ACTION_DATE, $returnToFilter + 86399, Criteria::LESS_EQUAL);
					$returnCriterion->addAnd($returnToCriterion);
				}
			}

			if (!is_null($loanCriterion) && !is_null($returnCriterion))
			{
				$loanCriterion->addOr($returnCriterion);
				$c->addAnd($loanCriterion);
			}
			elseif (!is_null($loanCriterion))
			{
				$c->addAnd($loanCriterion);
			}
			elseif (!is_null($returnCriterion))
			{
				$c->addAnd($returnCriterion);
			}

			$contactFilter = TPropertyValue::ensureString($this->ContactFilter->getSelectedValue());
			
			if (!is_null($contactFilter) && ($contactFilter != '') && ($contactFilter != '0'))
			{
				$preferredContact = $this->PreferredCheck->getChecked();
				switch ($this->ContactBooleanFilter->getSelectedValue())
				{
					case 0:
						$contactBoolean = false;
						break;

					case 1:
					default:
						$contactBoolean = true;
				}

				$c->addJoin(PatronPeer::PATRON_ID, ContactPeer::PATRON_ID, Criteria::INNER_JOIN);
				$c->setDistinct();

				$value = trim($this->ContactValue->getSafeText());

				if ($contactBoolean)   // with a specified contact, maybe a given value
				{
					$c->addAnd(ContactPeer::CONTACT_TYPE, $contactFilter);

					if ($preferredContact)
						$c->addAnd(ContactPeer::CONTACT_PREF, "1");

					if ($value != "")
						$c->addAnd(ContactPeer::CONTACT_VALUE, "%" . $value . "%", Criteria::LIKE);
				}
				else		// we must exclude a contacty type (and maybe a value)
				{
					if ($preferredContact)
						$contactPrefQuery = " AND contact.CONTACT_PREF = '1' ";
					else
						$contactPrefQuery = "";

					if ($value != "")
						$contactValueQuery = " AND contact.CONTACT_VALUE NOT LIKE '%" . $value . "%' ";
					else
						$contactValueQuery = "";

					$c->addAnd(ContactPeer::CONTACT_TYPE, "contact.patron_id not in (SELECT DISTINCT  contact.patron_id FROM `contact` INNER JOIN patron ON (contact.PATRON_ID=patron.PATRON_ID) WHERE contact.CONTACT_TYPE = '$contactFilter' "
							. $contactPrefQuery . " " . $contactValueQuery . ")", Criteria::CUSTOM);
				}
			}

			/*
			 * Address filtering
			 */
			$streetFilter = trim($this->StreetFilter->getSafeText());
			$zipFilter = trim($this->ZipFilter->getSafeText());
			$cityFilter = trim($this->CityFilter->getSafeText());
			$provinceFilter = trim($this->ProvinceFilter->getSafeText());

			if (($streetFilter != "") || ($zipFilter != "") || ($cityFilter != "") || ($provinceFilter != ""))
			{	
				$c->addJoin(PatronPeer::PATRON_ID, AddressPeer::PATRON_ID, Criteria::INNER_JOIN);
				$c->setDistinct();
			}

			if ($streetFilter != "")
				$c->add(AddressPeer::STREET, "%" . $streetFilter . "%", Criteria::LIKE);

			if ($zipFilter != "")
				$c->add(AddressPeer::ZIP, $zipFilter);

			if ($cityFilter != "")
				$c->add(AddressPeer::CITY, "%" . $cityFilter . "%", Criteria::LIKE);

			if ($provinceFilter != "")
				$c->add(AddressPeer::PROVINCE, "%" . $provinceFilter . "%", Criteria::LIKE);

			/**
			 * Nation filter
			 */
			$nationFlag = false;
			$birthCountryFilter = trim($this->BirthCountryFilter->getSafeText());

			if ($birthCountryFilter != "")
			{
				$c->add(PatronPeer::BIRTH_COUNTRY, "%" . $birthCountryFilter . "%", Criteria::LIKE);
				$nationFlag = true;
			}

			$citizenShipFilter = trim($this->CitizenShipFilter->getSafeText());
			
			if ($citizenShipFilter != "")
			{
				$c->add(PatronPeer::CITIZENSHIP, "%" . $citizenShipFilter . "%", Criteria::LIKE);
				$nationFlag = true;
			}

			/**
			 * Attribute filters
			 */
			$attrTypeFilter = $this->AttrTypeFilter->getSelectedIndex() > 0 ? $this->AttrTypeFilter->getSelectedValue() : null;

			$attrValueFilter = trim($this->AttrValueFilter->getSafeText());
			// think about: if we want no attribute? search for non existent ? .... TOTHINKABOUT

			if (!is_null($attrTypeFilter) && ($attrValueFilter != ""))
			{
				$c->addJoin(PatronPropertyPeer::PATRON_ID, PatronPeer::PATRON_ID, Criteria::INNER_JOIN);
				$c->addAnd(PatronPropertyPeer::PROPERTY_CLASS, $attrTypeFilter);
				$c->addAnd(PatronPropertyPeer::PROPERTY_VALUE, $attrValueFilter . '%', Criteria::LIKE);
			}

			/**
			 * Username
			 */
			$usernameFilter = trim($this->PatronUsername->getText());
			if ($usernameFilter)
				$c->add(PatronPeer::OPAC_USERNAME, $usernameFilter, Criteria::LIKE);

			/**
			 * Statistic fields filtering
			 */
			$studyLevelFilter = $this->StudyLevelFilter->getSelectedIndex() > 0 ? $this->StudyLevelFilter->getSelectedValue() : null;
			
			if (!is_null($studyLevelFilter))
				$c->addAnd(PatronPeer::STATISTIC_STUDY, $studyLevelFilter);

			$workFilter = $this->WorkFilter->getSelectedIndex() > 0 ? $this->WorkFilter->getSelectedValue() : null;
			
			if (!is_null($workFilter))
				$c->addAnd(PatronPeer::STATISTIC_WORK, $workFilter);

			if ($this->getViewDateCreated())
			{
				$this->DateCreated->setVisible(true);
				$this->UserGrid->resetSorting('dateCreated', null, false);
			}
			else
			{
				$this->DateCreated->setVisible(false);
				$this->UserGrid->resetSorting('patronName', null, false);
			}

			$this->calculateSortingCriteria($c);
			$this->setGlobalCriteria(array('type' => 'normal', 'body' => clone($c)));

			if (count($c->getMap()) == 0)   // if no filtering is active, we don't want ALL of the patrons
			{
				$this->NoFiltersPanel->setVisible(true);
				$this->FilterRollingField->show();
				$this->LowerCleanButton->setVisible(false);

				$recCount = 0;
				$patrons = array();
			}
			else
			{
				$this->NoFiltersPanel->setVisible(false);
				$recCount = PatronPeer::doCount($c);
				
				if ($recCount > 0)
				{
					$this->FilterRollingField->hide();
					$this->LowerCleanButton->setVisible(true);
				}
				else
				{
					$this->FilterRollingField->show();
					$this->LowerCleanButton->setVisible(false);
				}

				$c->setLimit($pageSize);
				$c->setOffset($currentIndexPage * $pageSize);

				$patrons = PatronPeer::doSelect($c);
			}
		}   // end of normal filtering by filters controls

		$this->UserGrid->setVirtualItemCount($recCount);
		$data = array();

		/* @var $patron Patron */
		$checked = $this->getCheckedItems();
		$this->_masterChecked = $checked['all'];

		foreach ($patrons as $patron)
		{
			$patronId = $patron->getPatronId();
			$p = array();

			if (isset($checked[$patronId]))
				$checkedItem = $checked[$patronId];
			else
				$checkedItem = false;
			if ($this->_masterChecked)
				$checkedItem = !$checkedItem;

			$p['PatronStatusString'] = $patron->getPatronStatusString();
			$p['Checked'] = $checkedItem;

			$p['ReverseCompleteName'] = ($name = trim($patron->getReverseCompleteName())) != '' ? $name : Prado::localize('(nome e cognome mancanti)');

			if ($CFFilterFlag)
			{
				$CF = trim($patron->getNationalId());
				if ($CF != "")
					$p['ReverseCompleteName'] .= "&nbsp;[CF:" . $CF . ']';
			}

			if (!is_null($classFilter))
				$p['ReverseCompleteName'] .= "&nbsp;(" . LookupValuePeer::getLookupValue('PATRONLOANCLASS', $patron->getLoanClass()) . ')';

			$p['SuggestLabel'] = $patron->getLastname() . ' ' . $patron->getName() . ' (' . $patron->getBarcode() .
					')<span class="informal">' . Clavis::dateFormat($patron->getBirthDate('U')) . '</span>';
			$pl = $patron->getPreferredLibrary();
			$p['PreferredLibraryId'] = $patron->getPreferredLibraryId();
			$p['PreferredLibraryLabel'] = ($pl instanceof Library) ?
					$pl->getLabel() : '---';

			$p['BirthDate'] = $patron->getBirthDate('U');

			$birthCity = trim($patron->getBirthCity());
			$birthProvince = trim($patron->getBirthProvince());
			$birthPlace = $birthCity;
			
			if ($birthProvince != "")
				$birthPlace .= ($birthPlace != "" ? " " : "") . "({$birthProvince})";

			if (isset($nationFlag) && $nationFlag)
			{
				$birthCountry = trim($patron->getBirthCountry());
				$citizenShip = trim($patron->getCitizenShip());
				$nation = $birthCountry . ( (($birthCountry != "") && ($citizenShip != "")) ? "/" : "") . $citizenShip;
				$birthPlace .= ($birthPlace != "" ? " " : "") . "({$nation})";
			}

			$p['BirthPlace'] = ($birthPlace != "" ? $birthPlace : "---");

			$p['id'] = $patron->getPatronId();
			$p['Barcode'] = $patron->getBarcode();
			
			if (!$p['Barcode'])
				$p['Barcode'] = '---';
			
			$p['PatronStateIconPath'] = $patron->getPatronStateIconPath();
			$p['DateCreated'] = $patron->getDateCreated('U');

			$data[] = $p;
		}

		$this->UserGrid->setDataSource($data);
		$this->UserGrid->dataBind();

		$this->setDatasource($data);
		
		if (!$this->getOnlySelected())
			$this->FoundNumber->setText($recCount);

		$this->resetFilters();
		$this->doRenderPrintPanel();
	}

	/**
	 * Synonyme of searchCancel().
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onCancel($sender, $param)
	{
		$this->searchCancel($sender, $param);
	}

	/**
	 * It cancels the search-by-textboxes mode, and resets
	 * the pagination of the grid.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function searchCancel($sender, $param)
	{
		$this->clearFilters();
		$this->searchPatron($sender, $param);
	}

	public function resetPagination()
	{
		$this->UserGrid->setCurrentPage(0);
	}

	public function clearFilters()
	{
		$this->UserGrid->setCurrentPage(0);
		$this->BarcodeFilter->setText('');
		$this->CardcodeFilter->setText('');
		$this->CFFilter->setText('');
		$this->LastnameFilter->setText('');
		$this->NameFilter->setText('');
		$this->RegLibraryFilter->setSelectedIndex(-1);
		$this->LibraryFilter->setSelectedIndex(-1);
		$this->PatronStatusFilter->setSelectedIndex(-1);
		$this->StudyLevelFilter->setSelectedIndex(-1);
		$this->WorkFilter->setSelectedIndex(-1);

		$this->StreetFilter->setText('');
		$this->ZipFilter->setText('');
		$this->CityFilter->setText('');
		$this->ProvinceFilter->setText('');
		$this->BirthCountryFilter->setText('');
		$this->CitizenShipFilter->setText('');

		$this->SexFilter->setSelectedIndex(0);
		$this->ClassFilter->setSelectedIndex(0);

		$this->onResetAgeFilter(null, null);
		$this->onResetCreationFilter(null, null);
		$this->onResetLoanFilter(null, null);
		$this->onResetReturnFilter(null, null);
		$this->onResetLastSeenFilter(null, null);
		$this->onResetCardExpireFilter(null, null);
		$this->onResetDocumentExpiryFilter(null, null);
		$this->resetContactFilter();

		$this->CustomList1->setSelectedIndex(-1);
		$this->Custom1->setText('');
		$this->CustomList2->setSelectedIndex(-1);
		$this->Custom2->setText('');
		$this->CustomList3->setSelectedIndex(-1);
		$this->Custom3->setText('');
		$this->CustomAllFilter->setText('');
		$this->AllCustomCheck->setChecked(false);  //true);
		$this->drawCustomPanels(false);  // true

		$this->AttrTypeFilter->setSelectedIndex(-1);
		$this->AttrValueFilter->setText('');
		$this->PatronUsername->setText('');

		$this->PrivacyApproveFilter->setSelectedIndex(0);
		
		$this->resetNewPatronFilters();

		$this->resetFilters();
	}

	public function resetContactFilter()
	{
		$this->ContactFilter->setSelectedIndex(0);
		$this->PreferredCheck->setChecked(false);
		$this->ContactBooleanFilter->setSelectedValue(1);
		$this->ContactValue->setText('');
	}

	/**
	 * It resets (also visually) the date choice.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onResetAgeFilter($sender, $param)
	{
		$this->AgeFromFilter->setText('');
		$this->AgeToFilter->setText('');

		if ($this->getPage()->getIsCallBack())
		{
			if (is_null($param))
			{
				$writer = $this->getPage()->createWriter();
			}
			else
			{
				$writer = $param->getNewWriter();
			}

			$this->AgeFilterPanel->render($writer);
		}
	}

	public function onResetCreationFilter($sender, $param)
	{
		$this->CreationFromFilter->setText('');
		$this->CreationToFilter->setText('');

		if ($this->getPage()->getIsCallBack())
		{
			if (is_null($param))
			{
				$writer = $this->getPage()->createWriter();
			}
			else
			{
				$writer = $param->getNewWriter();
			}

			$this->CreationFilterPanel->render($writer);
		}
	}

	public function onResetLoanFilter($sender, $param)
	{
		$this->LoanFromFilter->setText('');
		$this->LoanToFilter->setText('');

		if ($this->getPage()->getIsCallBack())
		{
			if (is_null($param))
			{
				$writer = $this->getPage()->createWriter();
			}
			else
			{
				$writer = $param->getNewWriter();
			}

			$this->LoanFilterPanel->render($writer);
		}
	}

	public function onResetReturnFilter($sender, $param)
	{
		$this->ReturnFromFilter->setText('');
		$this->ReturnToFilter->setText('');

		if ($this->getPage()->getIsCallBack())
		{
			if (is_null($param))
			{
				$writer = $this->getPage()->createWriter();
			}
			else
			{
				$writer = $param->getNewWriter();
			}

			$this->ReturnFilterPanel->render($writer);
		}
	}

	public function onResetLastSeenFilter($sender, $param)
	{
		$this->LastSeenFromFilter->setText('');
		$this->LastSeenToFilter->setText('');

		if ($this->getPage()->getIsCallBack())
		{
			if (is_null($param))
			{
				$writer = $this->getPage()->createWriter();
			}
			else
			{
				$writer = $param->getNewWriter();
			}

			$this->LastSeenFilterPanel->render($writer);
		}
	}

	public function onResetCardExpireFilter($sender, $param)
	{
		$this->CardExpireFromFilter->setText('');
		$this->CardExpireToFilter->setText('');

		if ($this->getPage()->getIsCallBack())
		{
			if (is_null($param))
			{
				$writer = $this->getPage()->createWriter();
			}
			else
			{
				$writer = $param->getNewWriter();
			}

			$this->CardExpireFilterPanel->render($writer);
		}
	}

	public function onResetDocumentExpiryFilter($sender, $param)
	{
		$this->DocumentExpiryFromFilter->setText('');
		$this->DocumentExpiryToFilter->setText('');

		if ($this->getPage()->getIsCallBack())
		{
			if (is_null($param))
			{
				$writer = $this->getPage()->createWriter();
			}
			else
			{
				$writer = $param->getNewWriter();
			}

			$this->DocumentExpiryFilterPanel->render($writer);
		}
	}

	public function getPopupFlag()
	{
		return $this->getPage()->IsPopup();
	}

	public function getUnlinkFlag()
	{
		return $this->getPage()->IsUnlink();
	}

	public function globalRefresh()
	{
		$this->populate();
	}

	public function onChangePage($sender, $param)
	{
		$sender->setCurrentPage($param->NewPageIndex);
		$this->globalRefresh();
	}

	public function onFlipChecked($sender, $param)
	{
		$checked = $this->getCheckedItems();

		$index = $sender->Parent->Parent->ItemIndex;
		$newStatus = $sender->getChecked();
		$dataSource = $this->getDatasource();
		$row = $dataSource[$index];
		$patronId = $row['id'];

		if ($newStatus != $checked['all'])
		{
			$checked[$patronId] = true;
		}
		else
		{
			unset($checked[$patronId]);
		}

		$this->setCheckedItems($checked);
		$this->updateEmptyFlag($param);
	}

	public function onMasterChecked($sender, $param)
	{
		$newStatus = $sender->getChecked();
		$this->resetCheckedItems($newStatus);

		$gridItems = $this->UserGrid->getItems();
		
		foreach ($gridItems as $item)
			$item->CheckColumn->CheckedBox->setChecked($newStatus);

		$this->updateEmptyFlag($param);
	}

	public function resetCheckedItems($state = false)
	{
		$this->setCheckedItems(array('all' => $state));
	}

	public function setCheckedItems($checked = null)
	{
		if ($checked == null)
		{
			$checked = $this->_checked;
		}
		else
		{
			$this->_checked = $checked;
		}
		
		$this->getApplication()->getSession()->add($this->_checkedSessionName, $checked);
	}

	public function getCheckedItems()
	{
		$this->_checked = $this->getApplication()->getSession()->itemAt($this->_checkedSessionName);
		return $this->_checked;
	}

	public function getCheckedId($force = false)
	{
		$checked = $this->getCheckedItems();
		$this->_masterChecked = $checked['all'];
		unset($checked['all']);
		$checkedIds = array_keys($checked);
		$output = array();

		if (!$this->_masterChecked)
		{
			$output = $checkedIds;
		}
		else		 // caso del mastercheck inverso
		{
			$criteriaArray = $this->getGlobalCriteria();

			if (!is_null($criteriaArray) 
					&& ($criteriaArray['type'] == 'givenIds'))
			{
				$patronIds = clone($criteriaArray['body']);
				$output = array_diff($patronIds, $checkedIds);
			}
			elseif (!is_null($criteriaArray) 
					&& ($criteriaArray['type'] == 'normal'))
			{
				$criteria = clone($criteriaArray['body']);
				
				if (count($checkedIds) > 0)
					$criteria->add(PatronPeer::PATRON_ID, $checkedIds, Criteria::NOT_IN);

				$output = array();
				$pdo = PatronPeer::doSelectStmt($criteria);
				
				while ($patronId = $pdo->fetchColumn(0))
					$output[] = $patronId;
			}
		}

		if ((count($output) == 0) 
				&& ($force == true))
		{
			$this->setMasterChecked(true);
			$output = $this->getCheckedId();
		}

		return $output;  // ids
	}

	public function setMasterChecked($newChecked = false, $param = null)
	{
		$this->resetCheckedItems($newChecked);
		$gridItems = $this->UserGrid->getItems();
		$header = $this->UserGrid->getHeader();

		foreach ($gridItems as $item)
			$item->CheckColumn->CheckedBox->setChecked($newChecked);

		$header->CheckColumn->MasterCheck->setChecked($newChecked);
	}

	public function countCheckedId($force = false)
	{
		$checked = $this->getCheckedItems();
		$this->_masterChecked = $checked['all'];
		unset($checked['all']);
		$checkedIds = array_keys($checked);
		$output = array();

		if (!$this->_masterChecked)
		{
			$output = count($checkedIds);
		}
		else		 // caso del mastercheck inverso
		{
			$criteriaArray = $this->getGlobalCriteria();

			if (!is_null($criteriaArray) 
					&& ($criteriaArray['type'] == 'givenIds'))
			{
				$patronIds = clone($criteriaArray['body']);
				$outputIds = array_diff($patronIds, $checkedIds);
				$output = count($outputIds);
			}
			elseif (!is_null($criteriaArray) 
					&& ($criteriaArray['type'] == 'normal'))
			{
				$criteria = clone($criteriaArray['body']);
				$criteria->add(PatronPeer::PATRON_ID, $checkedIds, Criteria::NOT_IN);
				$patronsCount = PatronPeer::doCount($criteria);
				$output = $patronsCount;
			}
		}

		return $output;  // numero ids
	}

	public function getMasterChecked()
	{
		$checked = $this->getCheckedItems();
		
		return $checked['all'];
	}

	public function onOnlySelected($sender, $param)
	{
		$checked = $sender->getChecked();
		$this->setOnlySelected($checked);
		$this->UserGrid->resetPagination();

		$this->populate();
	}

	public function updateEmptyFlag($param = null)
	{
		$this->SelectedNumber->setText(intval($this->countCheckedId()));
		
		if (!is_null($param))
			$this->SelectedPanel->render($param->getNewWriter());
	}

	public function onPrintJRP($sender, $param)
	{
		if (!$this->getPage()->getIsValid())
			return false;

		$this->doRenderPrintPanel();
		$ds = $this->getCheckedId();   // all + reset

		$ids = implode(',', $ds);
		$this->JRPBox->setObjectId($ids);
		$this->JRPBox->printReport();
	}

	public function onPrintValidate($sender, $param)
	{
		$param->isValid = (count($this->getCheckedId()) > 0);
	}

	public function OnContactFilterChanged($sender, $param)
	{
		$oldState = TPropertyValue::ensureBoolean($this->ContactValuePanel->getCssClass() == 'panel_on');
		$newState = ($this->ContactFilter->getSelectedIndex() > 0);

		if ($newState != $oldState)
		{
			$this->ContactValuePanel->setCssClass($newState ? 'panel_on' : 'panel_off');

			if ($this->getPage()->getIsCallback())
				$this->ContactValuePanel->render($param->getNewWriter());
		}
	}

	public function onCheckedCustom($sender, $param)
	{
		$this->drawCustomPanels($this->AllCustomCheck->getChecked(), $param);
	}

	private function drawCustomPanels($value = true, $param = null)
	{
		$this->SingleCustomPanel->setVisible(!$value);
		$this->AllCustomPanel->setVisible($value);

		if (!is_null($param) 
				&& $this->getPage()->getIsCallBack())
		{
			$this->CustomPanel->render($param->getNewWriter());
		}
	}
	
}