<?php

/**
 * ClavisPhotoUploader
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2011 Comperio srl
 * @license http://www.comperio.it/license/
 */
class ClavisPhotoUploader extends TTemplateControl
{
	public function onLoad($param)
	{
		parent::onLoad($param);
		
		// search for current photo for user
		$photoQuery = AttachmentQuery::create()
						->filterByObjectType($this->getUserClass())
						->filterByObjectId($this->getUserId())
						->filterByAttachmentType(AttachmentPeer::TYPE_PHOTO);
		
		$cnt = $photoQuery->count();
		$photos = $photoQuery->find();
		
		if ($cnt > 1)
		{
			// delete all but last one
			for ($i = $cnt - 2; $i >= 0; --$i)
				$photos[$i]->delete();
			
			$this->setCurrentPhotoId($photos[$cnt-1]->getAttachmentId());
		} 
		elseif ($cnt == 1)
		{
			$this->setCurrentPhotoId($photos[0]->getAttachmentId());
		} 
		else
		{
			$this->setCurrentPhotoId(null);
		}
		
		unset($photos);
		$this->populate();
	}

	public function setUserId($id)
	{
		$this->setControlState('UserId', $id, null);
	}

	public function getUserId()
	{
		return $this->getControlState('UserId', null);
	}

	public function setUserClass($id)
	{
		$this->setControlState('UserClass', $id, null);
	}

	public function getUserClass()
	{
		return $this->getControlState('UserClass', null);
	}

	public function setCurrentPhotoId($id)
	{
		$this->setControlState('CurrentPhotoId', $id, null);
	}

	public function getCurrentPhotoId()
	{
		return $this->getControlState('CurrentPhotoId', null);
	}

	public function setAnonImageUrl($value)
	{
		$this->setControlState('AnonImageUrl', $value, 'themes/Default/anonymous.jpg');
	}

	public function getAnonImageUrl()
	{
		return $this->getControlState('AnonImageUrl', 'themes/Default/anonymous.jpg');
	}

	public function onFileUploaded($sender, $param)
	{
		if ($sender->getHasFile())
		{
			if ($sender->getFileType() != 'image/jpeg')
			{
				$this->getPage()->writeMessage(Prado::localize('Tipo di file non compatibile'),
													ClavisMessage::WARNING);
			
				return;
			}
			
			$attach = AttachmentQuery::create()->findOneByAttachmentId($this->getCurrentPhotoId());
			if (!$attach instanceof Attachment)
			{
				$attach = new Attachment();
				$attach->setAttachmentType(AttachmentPeer::TYPE_PHOTO);
				$attach->setObjectType($this->getUserClass());
				$attach->setObjectId($this->getUserId());
			}
			
			//resample
			Clavis::resampleImageJpg(450, 450, $sender->getLocalName(), $sender->getLocalName(), 0);
			$original_parts = pathinfo($sender->getFileName());
			$original_name = $original_parts['basename'];
			
			try
			{
				$attach->setMimeType($sender->getFileType());
				$attach->setFileName($original_name);
				$attach->storeFile($sender->getLocalName(), $original_name);
				
				$this->setCurrentPhotoId($attach->getAttachmentId());
				$this->populate();
			}
			catch (Exception $e)
			{
				throw $e;
			}
		}
	}

	public function onDeleteClick($sender, $param)
	{
		$photo = AttachmentQuery::create()->findOneByAttachmentId($this->getCurrentPhotoId());
		if ($photo instanceof Attachment)
			$photo->delete();

		$this->setCurrentPhotoId(null);
		$this->populate();
	}

	public function onLoadFile($sender, $param)
	{

	}

	public function populate()
	{
		$phid = $this->getCurrentPhotoId();

		if ($phid > 0)
		{
			$this->PhotoPreview->setImageURL($this->getRequest()->constructUrl('file', $phid));
			$this->PhotoPreview->setVisible(true);
			$this->Delete->setVisible(true);
		}
		else
		{
			$this->PhotoPreview->setVisible(false);
			$this->Delete->setVisible(false);
		}
	}

	public function onAttachEvent($sender, $param)
	{
		$this->ErrorLabel->setVisible(false);
		$sizeX = $this->ImageSizeX->getValue();
		$sizeY = $this->ImageSizeY->getValue();
		$imgData = $this->ImageData->getValue();
		
		if (($sizeX == 'NaN')
				|| ($sizeY == 'NaN'))
		{
			$this->ErrorLabel->setVisible(true);
		
			return;
		}
		
		$img = imagecreatetruecolor($sizeX,$sizeY);
		$pxs = explode(',',$imgData);
		
		for ($x=0; $x < $sizeX; $x++)
		{
			for ($y=0; $y < $sizeY; $y++)
			{
				$pix = hexdec($pxs[($x * $sizeY) + $y] );
				$red   = ($pix & 0xFF0000) >> 16;
				$green = ($pix & 0x00FF00) >> 8;
				$blue  = ($pix & 0x0000FF);
				$col = imagecolorallocate($img, $red, $green, $blue);
				imagesetpixel($img,$x,$y,$col);
			}
		}
		
		$tmpFileName = tempnam('/tmp', 'claviswebcam');
		imagejpeg($img, $tmpFileName);

		$attach = AttachmentQuery::create()->findOneByAttachmentId($this->getCurrentPhotoId());
		if (!$attach instanceof Attachment)
		{
			$attach = new Attachment();
			$attach->setAttachmentType(AttachmentPeer::TYPE_PHOTO)
						->setObjectType($this->getUserClass())
						->setObjectId($this->getUserId());
		}
		
		//resample
		Clavis::resampleImageJpg(450, 450, $tmpFileName, $tmpFileName, 0);
		$original_parts = pathinfo($tmpFileName);
		$original_name = $original_parts['basename'];
		
		try
		{
			$attach->setMimeType('image/jpg');
			$attach->setFileName($original_name);
			$attach->storeFile($tmpFileName,$original_name);
			
			$this->setCurrentPhotoId($attach->getAttachmentId());
			$this->populate();
		}
		catch (Exception $e)
		{
			throw $e;
		}
	}
	
}
