<?php
/**
 * ClavisSBNSync class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Widgets
 */

/**
 * ClavisSBNSync Class
 *
 * Widget to show diff between a Clavis record and the corresponding SBN item.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Widgets
 * @since 2.5.1
 */
class ClavisSBNSync extends TTemplateControl
{
	const FIELDS_EQUAL = 0;
	const FIELDS_DIFF = 1;
	const FIELDS_LOCALONLY = 2;
	const FIELDS_SBNONLY = 3;
	/* @var ClavisSBN */
	public $_sbnMod;
	private $_objectId;
	private $_objectClass;
	/* @var Manifestation|Authority */
	private $_object;

	public function onLoad($param)
	{
		parent::onLoad($param);
		$this->_sbnMod = $this->getApplication()->getModule('sbn');
		if (!$this->_sbnMod instanceof TModule ||
				!$this->_sbnMod->getEnabled())
		{
			$this->SBNNotEnabled->setVisible(true);
			$this->SBNEnabled->setVisible(false);
			return;
		}

		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallback())
		{
			$this->populate();
			$this->dataBind();
		}
	}

	public function setObjectId($value)
	{
		$this->_objectId = intval($value);
	}

	public function getObjectId()
	{
		return $this->_objectId;
	}

	public function setObjectClass($value)
	{
		$this->_objectClass = $value;
	}

	public function getObjectClass()
	{
		return $this->_objectClass;
	}

	public function getObject()
	{
		if (!$this->_object)
			switch ($this->_objectClass)
			{
				case 'Manifestation':
					$this->_object = ManifestationQuery::create()->findPk($this->_objectId);
					break;
				case 'Authority':
					$this->_object = AuthorityQuery::create()->findPk($this->_objectId);
					break;
			}
		return $this->_object;
	}

	public function populate()
	{
		$req = $this->_sbnMod->getNewRequest();
		$object = $this->getObject();
		switch (get_class($object))
		{
			case 'Manifestation':
				$ret = $req->searchTitleByBid($object->getBid());
				$myTurbomarc = TurboMarc::createRecord($object->cacheTurboMarc())->sortFields();
				break;
			case 'Authority':
				$ret = $req->searchAuthorityByBid($object->getBid(), SBNConverter::ClavisType2SBNType($object->getAuthorityType()));
				$myTurbomarc = TurboMarc::createRecord($object->cacheTurboMarc())->sortFields();
				break;
			default:
				$this->MainPanel->setVisible(false);
				$this->ObjectError->setVisible(true);
				return;
		}
		if ($ret && '0000' == $ret->SbnMessage->SbnResponse->SbnResult->esito)
		{
			$sbndoc = SBNConverter::SBN2Turbomarc($ret, true);
		}
		else
		{
			$this->MainPanel->setVisible(false);
			$this->BidError->setVisible(true);
			return;
		}
		$sbnTurbomarc = TurboMarcUtility::sortFields($sbndoc);
		list($newtm, $ret) = SBNConverter::getTurbomarcSBNDiff($myTurbomarc, $sbnTurbomarc);
		//Clavis::sortTableArray($ret,'fnum',SORT_ASC);
		$this->setControlState('NewTM', $newtm->asXML());
		$this->DiffGrid->setDataSource($ret);
		$this->DiffGrid->dataBind();

		$dom = new DOMDocument();
		$dom->preserveWhiteSpace = false;
		$dom->formatOutput = true;
		$dom->loadXML($this->getControlState('NewTM', ''));
	}

	public function onItemDataBound($sender, $param)
	{
		$item = $param->Item;
		if ($item->ItemType === 'Item' || $item->ItemType === 'AlternatingItem')
		{
			switch ($item->Data['status'])
			{
				case TurboMarcUtility::FIELDS_EQUAL:
					$alt = Prado::localize('campo uguale');
					$item->setCssClass('evidenced_green');
					$item->StatusCol->StatusImage->setImageUrl('themes/Default/icons/yes.png');
					$item->StatusCol->StatusImage->setAlternateText($alt);
					break;
				case TurboMarcUtility::FIELDS_DIFF:
					$alt = Prado::localize('campo diverso');
					$item->setCssClass('evidenced_red');
					$item->StatusCol->StatusImage->setImageUrl('themes/Default/icons/replace2.png');
					$item->StatusCol->StatusImage->setAlternateText($alt);
					break;
				case TurboMarcUtility::FIELDS_TM1ONLY:
					$alt = Prado::localize('campo solo in locale');
					$item->setCssClass('evidenced_blue');
					$item->StatusCol->StatusImage->setImageUrl('themes/Default/icons/yes.png');
					$item->StatusCol->StatusImage->setAlternateText($alt);
					break;
				case TurboMarcUtility::FIELDS_TM2ONLY:
					$alt = Prado::localize('campo solo in SBN');
					$item->setCssClass('evidenced_light');
					$item->StatusCol->StatusImage->setImageUrl('themes/Default/icons/add2.png');
					$item->StatusCol->StatusImage->setAlternateText($alt);
					break;
			}
		}
	}

	public function updateObject($sender, $param)
	{
		$newtm = TurboMarc::createRecord($this->getControlState('NewTM', null));
		$object = $this->getObject();
		if (!$newtm instanceof TurboMarc)
		{
			$req = $this->_sbnMod->getNewRequest();
			$ret = ($object instanceof Manifestation) ? $req->searchTitleByBid($object->getBid()) : $req->searchAuthorityByBid($object->getBid(), SBNConverter::ClavisType2SBNType($object->getAuthorityType()));
			if ($ret && '0000' == $ret->SbnMessage->SbnResponse->SbnResult->esito)
			{
				$newtm = SBNConverter::SBN2Turbomarc($ret);
				if (isset($newtm->r))
					$newtm = $newtm->r;
			} else
			{
				throw new Exception('This should not happen');
			}
		}
		$object->updateFromTurbomarc($newtm, false, $links, false);
		if ($object->getLastSbnSync())
			$object->setLastSbnSync(time());
		$object->save();
		// send update to SBN

		$req = $this->_sbnMod->getNewRequest();
		if ($object instanceof Manifestation)
		{
			$update = array(
				'objClass'	 => SBNTypes::OBJCLASS_DOC,
				'objType'	 => (string) $newtm->d099->sb,
				'bid'		 => $object->getBid()
			);
		}
		else if ($object instanceof Authority)
		{
			$update = array(
				'objClass'	 => SBNTypes::OBJCLASS_AUT,
				'objType'	 => (string) $newtm->d099->sd,
				'bid'		 => $object->getBid()
			);
		}
		$req->sendUpdated(array($update));
		$this->getPage()->writeMessage(Prado::localize('Oggetto correttamente aggiornato da SBN'), ClavisMessage::CONFIRM);
		$this->getPage()->getClientScript()->registerEndScript(__CLASS__ . '_js', 'onReturn(\'true\',\'\',true);');
	}
	
}