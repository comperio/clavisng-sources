<?php
/**
 * ClavisFileAttachment class file.
 *
 * Component for managing file attachments.
 * It features support for:
 * 	- upload a file attachment
 *  - add a comment
 *  - list
 *  - view (issuing the command)
 *  - delete
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 ePortal Technologies
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Widgets
 */

/**
 * ClavisFileAttachment Class
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.7
 * @package Widgets
 * @since 2.2
 */
class ClavisFileAttachment extends TTemplateControl
{
	private $_librarian;

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsPostBack() 
				&& !$this->getPage()->getIsCallback())
		{
			$this->populate();
			$this->AttachmentType->setSelectedValue(AttachmentPeer::TYPE_GENERIC);
		}

		if (is_null($this->getObjectId()) 
				|| (is_null($this->getObjectClass())) )
		{
			$this->DoInsertAttachment->setEnabled(false);
		}
		else
		{
			$this->DoInsertAttachment->setEnabled(true);
		}
	}

	//getters/setters
	public function setObjectId($value)
	{
		$this->setControlState('object_id', $value, null);
	}

	public function getObjectId()
	{
		return $this->getControlState('object_id',null);
	}

	public function setObjectClass($value)
	{
		$this->setControlState('object_class', $value, null);
	}

	public function getObjectClass()
	{
		return $this->getControlState('object_class',null);
	}

	public function setReadOnly($value)
	{
		$this->setControlState('read_only',$value,'false');
	}

	public function getReadOnly()
	{
		return $this->getControlState('read_only','false');
	}

	public function setLibrarian($librarian)
	{
		$this->_librarian = $librarian;
		$this->setControlState('librarian', $librarian, null);
	}

	public function getLibrarian()
	{
		if (is_null($this->_librarian))
			$this->_librarian = $this->getControlState('librarian', null);
		
		return $this->_librarian;
	}

	public function populate()
	{
		if($this->getReadOnly() == 'true')
		{
			$this->AttachPanel->setVisible(false);
		}
		elseif ($this->getReadOnly() == 'false')
		{
			$this->AttachPanel->setVisible(true);
		}
		
		$this->populateAttachmentGrid();
	}

	private function populateAttachmentGrid()
	{
		$pageSize = $this->AttachmentGrid->getPageSize();
		$currentIndexPage = $this->AttachmentGrid->getCurrentPage();

		$oid = $this->getObjectId();
		$otype = $this->getObjectClass();

		$attachquery = AttachmentQuery::create()
							->filterByObjectId($oid)
							->filterByObjectType($otype);

		$recCount = $attachquery->count();
		$this->RecCounter->setText($recCount);
		$this->RecCounterPanel->setVisible($recCount > 0);
		$this->AttachmentGrid->setVirtualItemCount($recCount);

		$attachments = $attachquery->limit($pageSize)
										->offset($currentIndexPage)
										->orderByDateUpdated(ModelCriteria::DESC)
										->find();
		
		$req = $this->getApplication()->getRequest();
		$data = array();
		
		foreach ($attachments as $attachment)
		{
			/* @var $attachment Attachment */
			$p = array();
			
			$p['AttachName'] = $attachment->getFileName();
			$p['AttachUrl'] = $req->constructUrl('file', $attachment->getAttachmentId());
			$p['AttachType'] = LookupValuePeer::getLookupValue('ATTACHTYPE', $attachment->getAttachmentType());
			$p['AttachLicense'] = LookupValuePeer::getLookupValue('ATTACHLICENSE', $attachment->getLicense());
			$p['AttachSize'] = $attachment->getFileSize();
			$p['FileType'] = $attachment->getMimeType();
			$p['ObjectId'] = $oid;
			$p['ObjectType'] = $otype;
			$p['InsertDate'] = $attachment->getDateUpdated();
			$operator = $attachment->getLibrarianRelatedByModifiedBy();
			$p['InsertedBy'] = ($operator instanceof Librarian) ? $operator->getCompleteName() : "[" . Prado::localize("non definito") . "]";
			$p['AttachLabel'] = $attachment->getFileLabel();
			$p['AttachDescription'] = str_replace(array("\r", "\n"), '', $attachment->getFileDescription());
			$p['Id'] = $attachment->getAttachmentId();
			
			$data[] = $p;
		}
		
		$this->AttachmentGrid->setDataSource($data);
		$this->AttachmentGrid->dataBind();
	}

	public function searchNotification($sender, $param)
	{
		$this->AttachmentGrid->setCurrentPageIndex(0);
		$this->setViewState('CurrentPage', 0);
		
		$this->populate();
		$this->globalRefresh();
	}

	public function onCancel()
	{
		$this->searchCancel(null, null);
	}

	public function searchCancel($sender, $param)
	{

	}

	public function onChangePage($sender,$param)
	{
		$this->AttachmentGrid->setCurrentPage($param->NewPageIndex);
		
		$this->populate();
	}

	public function globalRefresh()
	{
		$this->getPage()->globalRefresh();
	}

	public function getPopupFlag()
	{
		return $this->getPage()->IsPopup();
	}

	public function getUnlinkFlag()
	{
		return $this->getPage()->IsUnlink();
	}

	public function globalEditCancel()
	{
		
	}

	public function OnObjectChangeType($sender, $param)
	{
		if ($this->getPage()->getIsPostBack())
		{
			$this->ObjectLabel->setText('');
			$this->getSession()->add('object_id', null);
		}
	}

	public function validateChosenFile()
	{
		if (!$this->FileUploader->getHasFile())
		{
			$this->getPage()->writeMessage(Prado::localize('Scegliere un file da allegare'),
												ClavisMessage::ERROR);
		
			return false;
		}
		
		if ($this->FileUploader->getErrorCode() == UPLOAD_ERR_INI_SIZE)
		{
			$this->getPage()->writeMessage(Prado::localize('Errore nella selezione del file da allegare: il file è troppo grande'),
												ClavisMessage::ERROR);
			
			return false;
		}
		
		return true;
	}

	protected function onInsertAttachment($sender, $param)
	{
		if (is_null($this->getObjectClass()) || (is_null($this->getObjectId())))
		{
			$this->getPage()->writeMessage(Prado::localize("Errore nell'inserimento dell'allegato. Riportare al fornitore del software"),
												ClavisMessage::ERROR);
			
			// maybe we don't need this    Prado::log("ClavisFileAttachment::onInsertAttachment() : non è definito l'object di riferimento");
			
			return;
		}

		if (!$this->validateChosenFile())
			return;

		$localFilename = $this->FileUploader->getLocalName();
		$attachmentType = $this->AttachmentType->getSelectedValue();
		
		if ($attachmentType == AttachmentPeer::TYPE_COVER)
			Clavis::resampleImageJpg(450, 450, $localFilename, $localFilename , 0);

		$fullpathname = pathinfo($this->FileUploader->getFileName());

		try
		{
			$a = new Attachment();
		
			$a->setAttachmentType($attachmentType)
					->setFileSize($this->FileUploader->getFileSize())
					->setObjectType($this->getObjectClass())
					->setObjectId($this->getObjectId())
					->setFileLabel(trim($this->AttachLabel->getSafeText()))
					->setFileDescription(trim($this->AttachDescription->getSafeText()))
					->setLicense($this->AttachmentLicense->getSelectedValue())
					->storeFile($localFilename, $fullpathname['basename']);
			
			ChangelogPeer::logAction(	$this->getObjectClass(),
										ChangelogPeer::LOG_UPDATE,
										$this->getUser(),
										"aggiunto allegato ({$a->getFileName()} - id: {$a->getAttachmentId()})",
										$this->getObjectId());
										
			$this->clearCurrentEntry();
			$this->populate();
			
		}
		catch (Exception $e)
		{
			$this->getPage()->writeMessage(Prado::localize("Errore nell'inserimento dell'allegato. Riportare al fornitore del software"),
												ClavisMessage::ERROR);
			
			throw $e;
			Prado::log(__CLASS__.'::'.__FUNCTION__.' errore di inserimento');
		}
	}

	protected function onDeleteAttachment($sender, $param)
	{
		$attachmentId = $param->CommandParameter;
		$a = AttachmentQuery::create()->findOneByAttachmentId($attachmentId);
		
		if ($a instanceof Attachment)
		{
			try
			{
				$a->delete();
				
				$this->getPage()->writeMessage(Prado::localize("Allegato rimosso correttamente"),
													ClavisMessage::INFO);
				
				ChangelogPeer::logAction(	$this->getObjectClass(), 
											ChangelogPeer::LOG_UPDATE, 
											$this->getUser(),
											"rimosso allegato (id: {$attachmentId})", 
											$this->getObjectId());
			}
			catch (Exception $e)
			{
				$this->getPage()->writeMessage(Prado::localize("Errore nella rimozione dell'allegato"),
													ClavisMessage::ERROR);
			}
			
			$this->populate();
		}
	}

	protected function onUpdateAttachment($sender, $param)
	{
		$attachmentId = $param->CommandParameter;
		$a = AttachmentQuery::create()->findOneByAttachmentId($attachmentId);
	
		if (!$a instanceof Attachment)
		{
			$this->getPage()->writeMessage(Prado::localize("L'ID dell'allegato non è valido. Riportare al fornitore del software"),
												ClavisMessage::ERROR);
			
			return;
		}
		
		$this->AttachPanel->setVisible(false);
		$this->EditAttachPanel->setVisible(true);

		$this->EditAttachID->setValue($attachmentId);
		$this->EditAttachName->setText($a->getFileName());
		
		$this->EditAttachmentType->populateList();
		$this->EditAttachmentType->setSelectedValue($a->getAttachmentType());
		$this->EditAttachmentLicense->populateList();
		$this->EditAttachmentLicense->setSelectedValue($a->getLicense());
		
		$this->EditAttachLabel->setText($a->getFileLabel());
		$this->EditAttachDescription->setText($a->getFileDescription());
	}

	protected function onUpdateAttachCancel($sender,$param)
	{
		$this->AttachPanel->setVisible(true);
		$this->EditAttachPanel->setVisible(false);
		$this->EditAttachID->setValue(null);
		$this->populate();
	}

	protected function onUpdateAttachConfirm($sender,$param)
	{
		$att = AttachmentQuery::create()->findOneByAttachmentId($this->EditAttachID->getValue());
	
		if ($att instanceof Attachment)
		{
			try
			{
				$localFilename = $att->getRealFilePath(true);
				$filename = $att->getFileName();

				if ($attachmentType == AttachmentPeer::TYPE_COVER)
					Clavis::resampleImageJpg(450, 450, $localFilename, $localFilename, 0);

				$results = $att->setAttachmentType($this->EditAttachmentType->getSelectedValue())
							->setLicense($this->EditAttachmentLicense->getSelectedValue())
							->setFileLabel(trim($this->EditAttachLabel->getSafeText()))
							->setFileDescription(trim($this->EditAttachDescription->getSafeText()))
							//->storeFile($localFilename, $filename);
							->save();
											
				if ($results > 0)
				{
					$this->getPage()->writeMessage(Prado::localize("Allegato modificato con successo"), 
														ClavisMessage::CONFIRM);
					
					ChangelogPeer::logAction(	$att->getObjectType(),
												ChangelogPeer::LOG_UPDATE, 
												$this->getUser(),
												"modificato allegato (id: {$att->getAttachmentId()}, '{$att->getFileName()}')",
												$att->getObjectId());
				}
				else
				{
					$this->getPage()->writeMessage(Prado::localize("Allegato non modificato"), 
														ClavisMessage::WARNING);
				}
			}
			catch (Exception $e)
			{
				$this->getPage()->writeMessage(Prado::localize("Impossibile completare l'aggiornamento dell'allegato, errore") . ": {$e}",
													ClavisMessage::ERROR);
			}
		}
		else
		{
			$this->getPage()->writeMessage(Prado::localize("Allegato non valido, id={id}",
																array('id' => $this->EditAttachID->getValue())),
												ClavisMessage::ERROR);
		}
		
		$this->AttachPanel->setVisible(true);
		$this->EditAttachPanel->setVisible(false);
		$this->EditAttachID->setValue(null);
		$this->populate();
	}
	
	protected function OLDonUpdateAttachConfirm($sender,$param)		// to delete, one future day
	{
		$a = AttachmentQuery::create()->findOneByAttachmentId($this->EditAttachID->getValue());
	
		if ($a instanceof Attachment)
		{
			try
			{
				$a->setAttachmentType($this->EditAttachmentType->getSelectedValue());
				$a->setFileLabel(trim($this->EditAttachLabel->getSafeText()));
				$a->setFileDescription(trim($this->EditAttachDescription->getSafeText()));
				$rett = $a->save();
		
				ChangelogPeer::logAction(	$a,
											ChangelogPeer::LOG_UPDATE, 
											$this->getUser(),
											"aggiornate proprietà allegato (id: {$a->getAttachmentId()})");
											
				$this->getPage()->writeMessage(Prado::localize("Allegato modificato con successo"), ClavisMessage::CONFIRM);
			}
			catch (Exception $e)
			{
				$this->getPage()->writeMessage(Prado::localize("Impossibile completare l'aggiornamento") . ": {$e}",
													ClavisMessage::ERROR);
			}
		}
		else
		{
			$this->getPage()->writeMessage(Prado::localize("Allegato non valido, id={id}",
																array('id' => $this->EditAttachID->getValue())),
												ClavisMessage::ERROR);
		}
		
		$this->AttachPanel->setVisible(true);
		$this->EditAttachPanel->setVisible(false);
		$this->EditAttachID->setValue(null);
		$this->populate();
	}

	protected function clearCurrentEntry()
	{
		$this->AttachDescription->setText('');
	}
	
}