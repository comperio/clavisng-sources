<?php
/**
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2010 comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 */

/**
 * ClavisQueryList Class
 *
 * Fork from ClavisTemplateList manage CRUD of queries list can be executed by cron.
 *
 * @author Cristian Chiarello <ciarez@comperio.it>
 * @author Ciro Mattia Gonano
 * @author Marco Brancalion <marco@comperio.it>
 */
class ClavisQueryList extends TTemplateControl
{
	private $_supported_media = array(	DocumentTemplatePeer::MEDIA_EMAIL,
										DocumentTemplatePeer::MEDIA_SMS );
	
	private $_ModeSessionName;
	private $_MediaSessionName;
	private $_LanguageSessionName;
	
	private function initVars()
	{
		$uniqueId = $this->getUniqueID();
		$this->_ModeSessionName = 'ModeSessionName' . $uniqueId;
		$this->_MediaSessionName = 'MediaSessionName' . $uniqueId;
		$this->_LanguageSessionName = 'LanguageSessionName' . $uniqueId;
	}

	public function onInit($param)
	{
		parent::onInit($param);
		$this->initVars();
	}
	
	public function onLoad($param)
	{
		parent::onLoad($param);
/*
		if ( $this->getPage()->getIsPostBack() )
		{
			Prado::log(__METHOD__ . " POSTBACK");
		}
		if( $this->getPage()->getIsCallback() )
		{
			Prado::log(__METHOD__ . " CALLBACK");
		}*/
		
		if (!$this->getPage()->getIsPostBack()
				&& !$this->getPage()->getIsCallback())
		{
			$this->loadDDLData();
		}
		
		//Prado::log("aaaa");
		if( $this->QueryList->getViewState('mode') != 'edit' )
		{
			$gridData = $this->QueryList->getViewState('data');
			if($gridData)
			{
				$this->QueryList->setDataSource($gridData);
			}
			else
			{
				$this->QueryList->setDataSource(array());
			}
			$this->QueryList->dataBind();
		}
	}
	
	public function loadDDLData()
	{
		$mks = array();
		$dbmks = KpiQueryQuery::create()
		->select(KpiQueryPeer::MASTER_KEY)
		->filterByMasterKey(  NULL, Criteria::ISNOTNULL)
		->distinct()->find()->toArray();
		if(  is_array( $dbmks ) && count($dbmks) > 0)
		{
			//Prado::log(Prado::varDump( $mks));
			//array_unshift($mks, '---');
			$mks['---'] = '---';
			foreach($dbmks as $dbmk)
			{
				$mks[$dbmk] = $dbmk;
			}
		}
		else
		{
			//Prado::log(Prado::varDump( $mks));
			$mks = array('---' => '---');
		}
		$this->MK->setDataSource($mks);
		$this->MK->dataBind();
		$this->MK->setControlState('data',$mks);

		$sks = array();
		$dbsks = KpiQueryQuery::create()
		->select(  KpiQueryPeer::SLAVE_KEY)
		->filterBySlaveKey(  NULL, Criteria::ISNOTNULL)
		->distinct()->find()->toArray();
		if(  is_array( $dbsks ) && count($dbsks) > 0)
		{
			//Prado::log(Prado::varDump( $sks));
			//array_unshift($sks, '---');
			$sks['---'] = '---';
			foreach($dbsks as $dbsk)
			{
				$sks[$dbsk] = $dbsk;
			}
		}
		else
		{
			//Prado::log(Prado::varDump( $sks));
			$sks = array('---');
		}
		$this->SK->setDataSource($sks);
		$this->SK->dataBind();
		$this->SK->setControlState('data',$sks);
	}

	public function getMedia()
	{
		return $this->getControlState($this->_MediaSessionName, null);
	}

	public function setMedia($value)
	{
		$this->setControlState($this->_MediaSessionName, TPropertyValue::ensureEnum($value, $this->_supported_media), null);
	}

	public function getLanguage()
	{
		return $this->getControlState($this->_LanguageSessionName, $this->getApplication()->getGlobalization()->getCulture());
	}

	public function setLanguage($value)
	{
		$this->setControlState($this->_LanguageSessionName, $value, $this->getApplication()->getGlobalization()->getCulture());
	}

	public function getMode()
	{
		return $this->getControlState($this->_ModeSessionName, 'search');
	}

	public function setMode($value)
	{
		$this->setControlState($this->_ModeSessionName, $value, 'search');
	}

	public function populate()
	{
		$d = $this->QueryList->getViewState('data');
		$this->QueryList->setDataSource($d);
		$this->QueryList->dataBind();
	}

	public function getPopupFlag()
	{
		return $this->getPage()->IsPopup();
	}



	public function isInsert()
	{
		return ($this->getMode() == 'insert');
	}
	
	public function toggleMode($sender, $param)
	{
		if($this->getMode() == 'search')
		{
			$this->setMode('insert');
			$x = $this->MK->getDataSource();
			Prado::log(Prado::varDump($x));
			$this->NewMKDDL->setDataSource($this->MK->getControlState('data'));
			$this->NewMKDDL->dataBind();
			$this->NewSKDDL->setDataSource($this->SK->getControlState('data'));
			$this->NewSKDDL->dataBind();
			$this->QueryPanel->setVisible(FALSE);
			$this->NewQueryPanel->setVisible(TRUE);
		}
		else
		{
			$this->setMode('search');
			$this->QueryPanel->setVisible(TRUE);
			$this->NewQueryPanel->setVisible(FALSE);
		}
	}
	
	
	public function cancelItem($sender, $param)
	{
		$this->QueryList->SelectedItemIndex = -1;
		$this->QueryList->EditItemIndex = -1;
		$this->populate();
		$this->QueryList->setViewState('mode',NULL);
	}

	public function editItem($sender, $param)
	{
		$this->QueryList->SelectedItemIndex = -1;
		$this->QueryList->EditItemIndex = $param->Item->ItemIndex;
		$this->QueryList->setViewState('mode','edit');
		
		$this->populate();
	}

	public function deleteItem($sender, $param)
	{
		$item = $param->Item;
		try
		{
			$kpiq = KpiQueryQuery::create()->findPk($this->QueryList->DataKeys[$item->ItemIndex]);
			$kpiq->delete();
			$this->QueryList->EditItemIndex = -1;
			$this->QueryList->SelectedItemIndex = -1;
			$this->getPage()->writeMessage(Prado::localize('Query eliminata.'), ClavisMessage::CONFIRM);
			$this->searchQuery(NULL, NULL);
		}
		catch (Exception $e)
		{
			$this->getPage()->writeMessage(Prado::localize('Impossibile eliminare la query: {msg}', array('msg' => $e->getMessage())), ClavisMessage::CONFIRM);
		}
	}

	public function selectItem($sender, $param)
	{
		//Prado::log(__METHOD__);
		$this->QueryList->EditItemIndex = -1;
		
		$this->populate();
	}

	public function updateItem($sender, $param)
	{
		$item = $param->Item;
		try
		{
			$cronexp = $item->EditCronSpecs->getSafeText();
			if( ! Cron\CronExpression::isValidExpression( $cronexp))
			{
				$this->getPage()->writeMessage(Prado::localize('Espressione cron non valida'), ClavisMessage::ERROR);
				return;
			}
			$kq = KpiQueryQuery::create()->findOneByQueryId($this->QueryList->DataKeys[$item->ItemIndex]);
			if( !($kq instanceof KpiQuery))
				throw new Exception("Error retrieving query");
			$mktxt = $item->EditMKDDL->getSelectedValue();
			$sktxt = $item->EditSKDDL->getSelectedValue();
			$editmk = $item->EditMK->getSafeText();
			$editsk = $item->EditSK->getSafeText();

			if($editmk == "")
			{
				if($mktxt == "---")
				{
					$editmk = NULL;
				}
				else
				{
					$editmk = $mktxt;
				}
			}

			if($editsk == "")
			{
				if($sktxt == "---")
				{
					$editsk = NULL;
				}
				else
				{
					$editsk = $sktxt;
				}
			}

			$kq->setMasterKey($editmk);
			$kq->setSlaveKey($editsk);
			$kq->setCronExp($cronexp);
			$kq->setDescription($item->EditDesc->getSafeText());
			$kq->setSql($item->EditSql->getSafeText());
			$kq->save();
			$this->getPage()->writeMessage(Prado::localize('Query aggiornata.'), ClavisMessage::CONFIRM);
			$this->QueryList->EditItemIndex = -1;
			$this->QueryList->SelectedItemIndex = -1;
			$this->searchQuery(NULL, NULL);
			$this->loadDDLData();
			$this->QueryList->setViewState('mode',NULL);
		}
		catch (Exception $e)
		{
			$this->getPage()->writeMessage(Prado::localize('Errore modifica query: {msg}', array('msg' => $e->getMessage())), ClavisMessage::ERROR);
		}
		
		
	}
	
	public function saveKpiQuery($sender, $param)
	{
		try
		{
			$cronexp = $this->NewCronSpecs->getSafeText();
			if( ! Cron\CronExpression::isValidExpression( $cronexp))
			{
				$this->getPage()->writeMessage(Prado::localize('Espressione cron non valida'), ClavisMessage::ERROR);
				return;
			}
			$kq = new KpiQuery();
			$mktxt = $this->NewMKDDL->getSelectedItem()->getText();
			$sktxt = $this->NewSKDDL->getSelectedItem()->getText();
			$newmk = $this->NewMK->getSafeText();
			$newsk = $this->NewSK->getSafeText();

			if($newmk == "")
			{
				if($mktxt == "---")
				{
					$newmk = NULL;
				}
				else
				{
					$newmk = $mktxt;
				}
			}

			if($newsk == "")
			{
				if($sktxt == "---")
				{
					$newsk = NULL;
				}
				else
				{
					$newsk = $sktxt;
				}
			}

			$kq->setMasterKey($newmk);
			$kq->setSlaveKey($newsk);
			$kq->setCronExp($cronexp);
			$kq->setDescription($this->NewDesc->getSafeText());
			$kq->setSql($this->NewSql->getSafeText());
			$kq->save();
			$this->getPage()->writeMessage(Prado::localize('Query inserita.'), ClavisMessage::CONFIRM);
			$this->searchQuery(NULL, NULL);
			$this->toggleMode(NULL, NULL);
			$this->loadDDLData();
		}
		catch (Exception $e)
		{
			$this->getPage()->writeMessage(Prado::localize('Errore inserimento query: {msg}', array('msg' => $e->getMessage())), ClavisMessage::ERROR);
		}
	}
	
	public function searchQuery($sender, $param)
	{
		$mktxt = $this->MK->getSelectedItem()->getText();
		$sktxt = $this->SK->getSelectedItem()->getText();
		$criterion = KpiQueryQuery::create();

		if($mktxt != '---' && $mktxt != '' )
		{
			$criterion->filterByMasterKey( $mktxt );
		}

		if($sktxt != '---' && $sktxt != '' )
		{
			$criterion->filterBySlaveKey( $sktxt );
		}

		//Prado::log(__METHOD__ . $criterion->toString());
		$queries = $criterion->find();

		$this->QueryList->setViewState('data', $queries);
		$this->QueryList->setDataSource($queries);
		$this->QueryList->dataBind();
	}
	
	public function searchCancel($sender, $param)
	{
		if( $this->isInsert() )
		{
			$this->toggleMode(NULL, NULL);
		}
		else
		{
			$this->QueryList->setViewState('data', array());	
			$this->QueryList->EditItemIndex = -1;
			$this->QueryList->SelectedItemIndex = -1;
			$this->populate();
		}
		
	}
	
	
	
	public function onItemDataBound($sender, $param)	
	{
		$item = $param->Item;
		
		if ($item->ItemType === 'EditItem')
		{
			$item->EditMKDDL->setDataSource($this->MK->getControlState('data'));
			$item->EditMKDDL->dataBind();
			$item->EditSKDDL->setDataSource($this->SK->getControlState('data'));
			$item->EditSKDDL->dataBind();
			//Prado::log(Prado::varDump($item->Data));
			//Prado::log($item->Data->getMasterKey());
			$mk = $item->Data->getMasterKey();
			$sk = $item->Data->getSlaveKey();
			
			if( ! is_null( $mk ))
			{
				$item->EditMKDDL->setSelectedValue($mk);
				$item->EditMK->setStyle('display: none');
			}
			
			if( ! is_null( $sk ))
			{
				$item->EditSKDDL->setSelectedValue($sk);
				$item->EditSK->setStyle('display: none');
			}
		}
	}
	
}