<?php
/**
 * ClavisLoanList class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 ePortal Technologies
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.8.8
 * @package Pages.Catalog
 */

/**
 * ClavisLoanList Class
 *
 * This component visualizes a datagrid with actual loaned items,
 * filtered upon some parameters (inserted by some dropdown lists),
 * or filtered by some other parameters (i.e. patron_id) which are set
 * externally by the "setObject()" method (note: the column which
 * matched the type of object passed is turned off in the grid).
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.8.8
 * @package Widgets
 * @since 2.0
 */
class ClavisLoanList extends TTemplateControl 
{
	const INVALIDEMAIL = '**NOeMail**';

	private $_datasource;
	private $_datasourceSessionName;
	
	public $_llibraryActive;

	/** @param ClavisLoanManager $_loanmanager */
	protected $_loanmanager;
	private $_fromLibraryId;
	private $_toLibraryId;
	private $_endLibraryId;
	private $_homeLibraryId;
	private $_loanStatus;
	private $_solicitable;
	private $_withItemRequest;
	private $_withExpired;
	private $_patronId;
	private $_renewCount;
	private $_solicitCount;
	private $_outDateFrom;
	private $_outDateTo;
	private $_inDateFrom;
	private $_inDateTo;
	private $_dueDateFrom;
	private $_dueDateTo;
	private $_contactFilter;
	private $_preferredContact;
	private $_contactBoolean;
	private $_object;
	private $_activeFilter;
	private $_closeLoanTitle;
	
	/**
	 * For checking logic
	 *
	 */
	public $_masterChecked;
	private $_checked = array('all' => false);
	private $_checkedSessionName;
	private $_globalCriteriaSessionName;
	public $_onlySelectedSessionName;

	private function initVars() 
	{
		$this->_llibraryActive = LLibraryPeer::isEnabled();
		$this->_loanmanager = $this->getApplication()->getModule('loan');
		$this->_datasource = $this->getApplication()->getSession()->itemAt('loanFoundDatasource');

		$uniqueId = $this->getUniqueID();
		$this->_checkedSessionName = 'CheckedSessionName' . $uniqueId;
		$this->_globalCriteriaSessionName = 'GlobalCriteriaSessionName' . $uniqueId;
		$this->_onlySelectedSessionName = 'OnlySelectedSessionName' . $uniqueId;
		$this->_checked = $this->getChecked();
		$this->_masterChecked = $this->_checked['all'];
		$this->_datasourceSessionName = 'DatasourceSessionName' . $uniqueId;
	}

	public function onInit($param) 
	{
		parent::onInit($param);
		$this->initVars();
	}

	public function onLoad($param) 
	{
		parent::onLoad($param);

		$this->NoSearchPanel->setCssClass('panel_off');

		if (!$this->getPage()->getIsPostBack() 
				&& !$this->getPage()->getIsCallback()) 
		{
			$populated = ($this->PopulatedFlag->getValue() == "true");

			if (!$populated && $this->getPopulable() 
					&& $this->getAutomaticPopulate()) 
			{
				$this->resetDataSource(false);
				$this->populate();
			} 
			else 
			{
				if (!$this->getAutomaticPopulate())
					$this->NoSearchPanel->setCssClass('panel_on_inline');
			}
			
			if ($this->getPopupFlag())
				$this->ActionColumn->setVisible(false);
		}
	}

	public function initialReload($givenIds = array()) 
	{
		$this->resetDataSource(false);

		if ($this->getPopulable() && $this->getAutomaticPopulate())
			$this->populate($givenIds);
	}

	public function resetChecked($state = false) 
	{
		$this->setChecked(array('all' => $state));
	}

	public function setChecked($checked = null) 
	{
		$this->_checked = $checked;
		$this->getApplication()->getSession()->add($this->_checkedSessionName, $checked);
	}

	public function getChecked() 
	{
		$this->_checked = $this->getApplication()->getSession()->itemAt($this->_checkedSessionName);
		return $this->_checked;
	}

	private function resetGlobalCriteria() 
	{
		$this->setGlobalCriteria(null);
	}

	private function setGlobalCriteria($criteria = null)
	{
		$this->getApplication()->getSession()->add($this->_globalCriteriaSessionName, $criteria, null);
	}

	public function getGlobalCriteria() 
	{
		$crit = $this->getApplication()->getSession()->itemAt($this->_globalCriteriaSessionName, null);

		if ($crit instanceof Criteria)
			$crit = SerializableCriteria::refreshCriteria($crit);

		return $crit;
	}

	public function resetOnlySelected($value = false) 
	{
		$this->setOnlySelected($value);
		$this->OnlySelectedCheck->setChecked(false);
		$this->TeleportCheck->setChecked(false);
	}

	public function setOnlySelected($flag = false) 
	{
		if ($flag === 'false')
			$flag = false;
		
		if ($flag === 'true')
			$flag = true;

		$this->getApplication()->getSession()->add($this->_onlySelectedSessionName, $flag, false);
	}

	public function getOnlySelected() 
	{
		$flag = $this->getApplication()->getSession()->itemAt($this->_onlySelectedSessionName);
		
		return $flag;
	}

	public function getCheckedItems($force = false, $reset = false) 
	{
		$checked = $this->getChecked();
		$masterChecked = $checked['all'];
		unset($checked['all']);
		$checkedIds = array_keys($checked);

		$output = array();
		if (!$masterChecked) 
		{
			$output = $checkedIds;
		} 
		else 
		{	  // caso del mastercheck inverso
			$criteria = $this->getGlobalCriteria();
			$loanIds = array();

			if (!is_null($criteria)) 
			{
				if ($criteria instanceof Criteria) 
				{
					if (count($checked) > 0)
						$criteria->add(LoanPeer::LOAN_ID, $checkedIds, Criteria::NOT_IN);

					$criteria->clearSelectColumns();
					$criteria->addSelectColumn(LoanPeer::LOAN_ID);
					$pdo = LoanPeer::doSelectStmt($criteria);
					
					while ($loanId = $pdo->fetchColumn())
						$loanIds[] = $loanId;
				}
				elseif (is_array($criteria) && (count($criteria) > 0)) 
				{
					$loanIds = $criteria;
				}
			}

			$output = $loanIds;
		}

		if ((count($output) == 0) && ($force == true)) 
		{
			$this->setMasterChecked(true);
			$output = $this->getCheckedItems();

			if ($reset)
				$this->setMasterChecked(false);
		}

		return $output;
	}

	public function countCheckedItems($force = false, $reset = false) 
	{
		$checked = $this->getChecked();
		$masterChecked = $checked['all'];
		unset($checked['all']);
		$checkedIds = array_keys($checked);
		$output = 0;

		if (!$masterChecked) 
		{
			$output = count($checkedIds);
		} 
		else 
		{	   // caso del mastercheck inverso
			$criteria = $this->getGlobalCriteria();

			if (!is_null($criteria)) 
			{
				if ($criteria instanceof Criteria) 
				{
					if (count($checkedIds) > 0)
						$criteria->add(LoanPeer::LOAN_ID, $checkedIds, Criteria::NOT_IN);
					$output = LoanPeer::doCount($criteria);
				}
				elseif (is_array($criteria)) 
				{
					$output = count($criteria);
				}
			}
		}

		if (($output == 0) && ($force == true)) 
		{
			$this->setMasterChecked(true);
			$output = $this->countCheckedItems();

			if ($reset)
				$this->setMasterClass(false);
		}

		return $output;
	}

	public function getMasterChecked() 
	{
		$checked = $this->getChecked();
		
		return $checked['all'];
	}

	public function onOnlySelected($sender, $param) 
	{
		$checked = $sender->getChecked();
		$this->setOnlySelected($checked);

		$this->LoanGrid->resetPagination();
		$this->populate();
	}

	public function onFlipChecked($sender, $param) 
	{
		$newChecked = $sender->getChecked();
		$index = $sender->Parent->Parent->ItemIndex;
		$dataSource = $this->getDatasource();
		$checked = $this->getChecked();

		$row = $dataSource[$index];
		$loanId = $row['id'];

		if ($newChecked != $checked['all'])
		{
			$checked[$loanId] = true;
		}
		else
		{
			unset($checked[$loanId]);
		}

		$this->setChecked($checked);
		$this->updateEmptyFlag($param);
	}

	public function onMasterChecked($sender, $param) 
	{
		$this->setMasterChecked($sender->getChecked(), $param);
	}

	public function setMasterChecked($newChecked = false, $param = null) 
	{
		$this->resetChecked($newChecked);
		$gridItems = $this->LoanGrid->getItems();
		$header = $this->LoanGrid->getHeader();

		foreach ($gridItems as $item)
			$item->CheckColumn->CheckedBox->setChecked($newChecked);

		$header->CheckColumn->MasterCheck->setChecked($newChecked);
		$this->updateEmptyFlag($param);
	}

	public function updateEmptyFlag($param = null) 
	{
		$count = intval($this->countCheckedItems());
		$this->SelectedNumber->setText($count);

		if (!is_null($param))
		{
			if ($this->getPage()->getIsCallback())
				$this->SelectedPanel->render($param->getNewWriter());
		}
		else
		{
			$this->SelectedPanel->setCssClass(intval($this->SelectedNumber->getText()) > 0 
													? 'panel_on' 
													: 'panel_off');
		}
	}

	public function resetSelectedPanel() 
	{
		$this->SelectedPanel->setCssClass('panel_off');
		$this->SelectedNumber->setText(0);
	}

	public function setPopulable($value = true) 
	{
		$this->setViewState('Populable', $value, true);
	}

	public function getPopulable() 
	{
		$populable = $this->getViewState('Populable', true);
		
		return $populable;
	}

	public function setRenewMode($param) 
	{
		$this->setViewState("renewMode", $param, false);
	}

	public function getRenewMode() 
	{
		return $this->getViewState("renewMode", false);
	}

	public function setObject($obj) 
	{
		$this->_object = $obj;
		$this->setViewState('object', $obj, (object) null);
	}

	public function getObject() 
	{
		if (is_null($this->_object))
			$this->_object = $this->getViewState('object', (object) null);
	
		return $this->_object;
	}

	public function setToLibraryId($lib) 
	{
		$this->_toLibraryId = $lib;
		$this->setViewState('toLibraryId', $this->_toLibraryId, null);
	}

	public function getToLibraryId() 
	{
		if (($lib = $this->_toLibraryId) == null) 
		{
			$lib = $this->getViewState('toLibraryId', null);
			$this->_toLibraryId = $lib;
		}
		
		return $lib;
	}

	public function setFromLibraryId($lib) 
	{
		$this->_fromLibraryId = $lib;
		$this->setViewState('fromLibraryId', $this->_fromLibraryId, null);
	}

	public function getFromLibraryId() 
	{
		if (($lib = $this->_fromLibraryId) == null) 
		{
			$lib = $this->getViewState('fromLibraryId', null);
			$this->_fromLibraryId = $lib;
		}
		
		return $lib;
	}

	public function setEndLibraryId($lib) 
	{
		$this->_endLibraryId = $lib;
		$this->setViewState('endLibraryId', $this->_endLibraryId, null);
	}

	public function getEndLibraryId() 
	{
		if (($lib = $this->_endLibraryId) == null) 
		{
			$lib = $this->getViewState('endLibraryId', null);
			$this->_endLibraryId = $lib;
		}
		
		return $lib;
	}

	public function setHomeLibraryId($lib) 
	{
		$this->_homeLibraryId = $lib;
		$this->setViewState('homeLibraryId', $this->_homeLibraryId, null);
	}

	public function getHomeLibraryId() 
	{
		if (($lib = $this->_homeLibraryId) == null) 
		{
			$lib = $this->getViewState('homeLibraryId', null);
			$this->_homeLibraryId = $lib;
		}
		
		return $lib;
	}

	public function setSearchTitleClosedLoanList($title)
	{
		$this->_closeLoanTitle = $title;
		$this->setViewState('closeLoanTitle', $this->_closeLoanTitle, null);
	}

	public function getSearchTitleClosedLoanList()
	{
		$closeLoanTitle = $this->getViewState('closeLoanTitle', null);
		$this->_closeLoanTitle = $closeLoanTitle;
		return $closeLoanTitle;
	}

	public function setLoanStatus($loanStatus) 
	{
		$this->_loanStatus = $loanStatus;
		$this->setViewState('loanStatus', $this->_loanStatus, null);
	}

	public function getLoanStatus() 
	{
		$loanStatus = $this->getViewState('loanStatus', null);
		$this->_loanStatus = $loanStatus;

		return $loanStatus;
	}
        
	public function setSolicitable($value = false) 
	{
		$this->_solicitable = $value;
		$this->setViewState('solicitable', $this->_solicitable, false);
	}

	public function getSolicitable() 
	{
		$this->_solicitable = $this->getViewState('solicitable', false);
	
		return $this->_solicitable;
	}

	public function setWithItemRequest($value) 
	{
		$this->_withItemRequest = $value;
		$this->setViewState('withItemRequest', $this->_withItemRequest, null);
	}

	public function getWithItemRequest() 
	{
		$withItemRequest = $this->getViewState('withItemRequest', null);
		
		return $withItemRequest;
	}

	public function setWithExpired($value) 
	{
		$this->_withExpired = $value;
		$this->setViewState('withExpired', $this->_withExpired, false);
	}

	public function getWithExpired() 
	{
		$this->_withExpired = $this->getViewState('withExpired', false);
		
		return $this->_withExpired;
	}

	public function setPatronId($id) 
	{
		$this->_patronId = $id;
		$this->setViewState('patronId', $this->_patronId, null);
	}

	public function getPatronId() 
	{
		if (($id = $this->_patronId) == null) 
		{
			$id = $this->getViewState('patronId', null);
			$this->_patronId = $id;
		}
		
		return $id;
	}

	public function setRenewCount($count) 
	{
		$this->_renewCount = $count;
		$this->setViewState('renewCount', $this->_renewCount, null);
	}

	public function getRenewCount() 
	{
		if (($count = $this->_renewCount) == null) 
		{
			$count = $this->getViewState('renewCount', null);
			$this->_renewCount = $count;
		}
		
		return $count;
	}

	public function setSolicitCount($count) 
	{
		$this->_solicitCount = $count;
		$this->setViewState('solicitCount', $this->_solicitCount, null);
	}

	public function getSolicitCount() 
	{
		if (($count = $this->_solicitCount) == null) 
		{
			$count = $this->getViewState('solicitCount', null);
			$this->_solicitCount = $count;
		}
		
		return $count;
	}

	public function setOutDateFrom($date) 
	{
		$this->_outDateFrom = $date;
		$this->setViewState('outDateFrom', $this->_outDateFrom, null);
	}

	public function getOutDateFrom() 
	{
		if (($date = $this->_outDateFrom) == null) 
		{
			$date = $this->getViewState('outDateFrom', null);
			$this->_outDateFrom = $date;
		}
		
		return $date;
	}

	public function setOutDateTo($date) 
	{
		$this->_outDateTo = $date;
		$this->setViewState('outDateTo', $this->_outDateTo, null);
	}

	public function getOutDateTo() 
	{
		if (($date = $this->_outDateTo) == null)
		{
			$date = $this->getViewState('outDateTo', null);
			$this->_outDateTo = $date;
		}
		
		return $date;
	}

	public function setInDateFrom($date) 
	{
		$this->_inDateFrom = $date;
		$this->setViewState('inDateFrom', $this->_inDateFrom, null);
	}

	public function getInDateFrom() 
	{
		if (($date = $this->_inDateFrom) == null) 
		{
			$date = $this->getViewState('inDateFrom', null);
			$this->_inDateFrom = $date;
		}
		
		return $date;
	}

	public function setInDateTo($date) 
	{
		$this->_inDateTo = $date;
		$this->setViewState('inDateTo', $this->_inDateTo, null);
	}

	public function getInDateTo() 
	{
		if (($date = $this->_inDateTo) == null) 
		{
			$date = $this->getViewState('inDateTo', null);
			$this->_inDateTo = $date;
		}
		
		return $date;
	}

	public function setDueDateFrom($date) 
	{
		$this->_dueDateFrom = $date;
		$this->setViewState('dueDateFrom', $this->_dueDateFrom, null);
	}

	public function getDueDateFrom() 
	{
		if (($date = $this->_dueDateFrom) == null) 
		{
			$date = $this->getViewState('dueDateFrom', null);
			$this->_dueDateFrom = $date;
		}
		
		return $date;
	}

	public function setDueDateTo($date) 
	{
		$this->_dueDateTo = $date;
		$this->setViewState('dueDateTo', $this->_dueDateTo, null);
	}

	public function getDueDateTo() 
	{
		if (($date = $this->_dueDateTo) == null) 
		{
			$date = $this->getViewState('dueDateTo', null);
			$this->_dueDateTo = $date;
		}
		
		return $date;
	}

	public function setActiveFilter($activeFilter = null) 
	{
		$this->_activeFilter = $activeFilter;
		$this->setViewState("activeFilter", $activeFilter, null);
	}

	public function getActiveFilter() 
	{
		if (is_null($this->_activeFilter))
			$this->_activeFilter = $this->getViewState("activeFilter", null);
	
		return $this->_activeFilter;
	}

	public function setAutomaticPopulate($flag = true) 
	{
		$this->setViewState("automaticPopulate", $flag, true);
	}

	public function getAutomaticPopulate() 
	{
		return $this->getViewState("automaticPopulate", true);
	}

	public function setContactFilter($contact) 
	{
		$this->_contactFilter = $contact;
		$this->setViewState('contactFilter', $this->_contactFilter, null);
	}

	public function getContactFilter() 
	{
		$this->_contactFilter = $this->getViewState('contactFilter', null);
		return $this->_contactFilter;
	}

	public function setPreferredContact($flag) 
	{
		$this->_preferredContact = $flag;
		$this->setViewState('preferredContact', $this->_preferredContact, false);
	}

	public function getPreferredContact() 
	{
		$this->_preferredContact = $this->getViewState('preferredContact', false);
		return $this->_preferredContact;
	}

	public function setContactBoolean($value) 
	{
		$this->_contactBoolean = $value;
		$this->setViewState('contactBoolean', $this->_contactBoolean, true);
	}

	public function getContactBoolean() 
	{
		$this->_contactBoolean = $this->getViewState('contactBoolean', true);
		
		return $this->_contactBoolean;
	}

	public function setOocMode($value = null) 
	{
		$this->setViewState('oocMode', $value, null);
	}

	public function getOocMode() 
	{
		return $this->getViewState('oocMode');
	}

	public function setItemMedia($value = "") 
	{
		$this->setViewState('ItemMedia', $value, "");
	}

	public function getItemMedia()
	{
		return $this->getViewState('ItemMedia', "");
	}

	/**
	 * It returns whether an item, represented by the id passed
	 * as the parameter, is present in the loans datasource.
	 *
	 * @param int $itemId
	 * @return boolean
	 */
	private function searchIdIntoDatasource($itemId) 
	{
		$dataSource = $this->getDatasource();
		
		foreach ($dataSource as $row) 
		{
			if ($row['id'] == $itemId)
				return true;
		}
		
		return false;
	}

	/**
	 * It sets the four filters (used in the LoanViewPage) altogether.
	 *
	 * @param int $fromLibraryId
	 * @param int $toLibraryId
	 * @param int $endLibraryId
	 * @param int $homeLibraryId
	 * @param string $loanStatus
	 */
	public function setFilters(	$fromLibraryId, 
								$toLibraryId, 
								$endLibraryId, 
								$homeLibraryId, 
								$loanStatus, 
			
								$solicitable = false, 
								$withItemRequest = false, 
								$withExpired = false, 
								$patronId = null, 
								$renewCount = null, 
			
								$solicitCount = null, 
								$outDateFrom = null, 
								$outDateTo = null, 
								$dueDateFrom = null, 
								$dueDateTo = null, 
			
								$inDateFrom = null, 
								$inDateTo = null, 
								$contact = null, 
								$preferredContact = false, 
								$contactBoolean = true, 
			
								$itemMedia = "0", 
								$oocMode = false) 
	{
		if ($fromLibraryId == LibraryPeer::BLANKVALUE)
			$fromLibraryId = null;
		
		if ($toLibraryId == LibraryPeer::BLANKVALUE)
			$toLibraryId = null;
		
		if ($endLibraryId == LibraryPeer::BLANKVALUE)
			$endLibraryId = null;
		
		if ($homeLibraryId == LibraryPeer::BLANKVALUE)
			$homeLibraryId = null;

		if ($loanStatus === '0')
			$loanStatus = null;
		
		if ($solicitable == null)
			$solicitable = false;

		if ($withItemRequest == null)
			$withItemRequest = false;
		
		if ($withExpired == null)
			$withExpired = false;
		
		if ($patronId == 0)
			$patronId = null;

		if (is_null($renewCount))
			$renewCount = -1;

		if (is_null($solicitCount))
			$solicitCount = -1;

		if ($outDateFrom == '')
			$outDateFrom = null;
		
		if ($outDateTo == '')
			$outDateTo = null;
		
		if ($inDateFrom == '')
			$inDateFrom = null;
		
		if ($inDateTo == '')
			$inDateTo = null;
		
		if ($dueDateFrom == '')
			$dueDateFrom = null;
		
		if ($dueDateTo == '')
			$dueDateTo = null;
		
		if ($itemMedia == "0")
			$itemMedia = null;

		$this->setFromLibraryId($fromLibraryId);
		$this->setToLibraryId($toLibraryId);
		$this->setEndLibraryId($endLibraryId);
		$this->setHomeLibraryId($homeLibraryId);

		$this->setLoanStatus($loanStatus);
		$this->setSolicitable($solicitable);
		$this->setWithItemRequest($withItemRequest);
		$this->setWithExpired($withExpired);
		$this->setPatronId($patronId);
		$this->setRenewCount($renewCount);
		$this->setSolicitCount($solicitCount);

		$this->setOutDateFrom($outDateFrom);
		$this->setOutDateTo($outDateTo);
		$this->setInDateFrom($inDateFrom);
		$this->setInDateTo($inDateTo);
		$this->setDueDateFrom($dueDateFrom);
		$this->setDueDateTo($dueDateTo);

		$this->setContactFilter($contact);
		$this->setPreferredContact($preferredContact);
		$this->setContactBoolean($contactBoolean);
		$this->setItemMedia($itemMedia);
		$this->setOocMode($oocMode);

		$this->resetPagination();
	}

	public function resetDataSource($populateFlag = true) 
	{
		$this->resetGlobalCriteria();
		$this->resetChecked();
		$this->resetOnlySelected();
		$this->_datasource = array();
		$this->getApplication()->getSession()->add($this->_datasourceSessionName, $this->_datasource);

		$this->resetSelectedPanel();
		$this->resetSorting();

		if ($populateFlag) 
		{
			$this->populate();
		} 
		else 
		{
			$this->writeResults();
			$this->NoSearchPanel->setCssClass('panel_on_inline');
		}
	}

	public function resetSorting() 
	{
		$this->LoanGrid->resetSorting('', null, false);
	}

	public function getDatasource() 
	{
		$this->_datasource = $this->getApplication()->getSession()->itemAt($this->_datasourceSessionName, null);

		return $this->_datasource;
	}

	public function setDataSource($ds) {
		$this->_datasource = $ds;
		$this->getApplication()->getSession()->add($this->_datasourceSessionName, $this->_datasource, null);
	}

	public function getSortingExpression() 
	{
		return $this->LoanGrid->getSortingExpression();
	}

	public function getSortingDirection() 
	{
		return $this->LoanGrid->getSortingDirection();
	}

	public function calculateSortingCriteria(&$sortingCriteria = null) 
	{
		$sortingExpression = $this->getSortingExpression();
		$sortingDirection = $this->getSortingDirection();

		if (is_null($sortingCriteria) 
				|| !($sortingCriteria instanceof Criteria))
			$sortingCriteria = new Criteria();

		switch ($sortingExpression) 
		{
			case 'title':  // ShelfName
				$sortingCriteria->clearOrderByColumns();
				
				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
				{
					$sortingCriteria->addAscendingOrderByColumn(ItemPeer::TITLE);
				}
				elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
				{
					$sortingCriteria->addDescendingOrderByColumn(ItemPeer::TITLE);
				}
				
				break;

			case 'PatronColumn': // LibrarianName
				$sortingCriteria->clearOrderByColumns();
				$sortingCriteria->addJoin(ItemPeer::PATRON_ID, PatronPeer::PATRON_ID, Criteria::LEFT_JOIN);
				
				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC) 
				{
					$sortingCriteria->addAscendingOrderByColumn(PatronPeer::LASTNAME);
					$sortingCriteria->addAscendingOrderByColumn(PatronPeer::NAME);
				} 
				elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC) 
				{
					$sortingCriteria->addDescendingOrderByColumn(PatronPeer::LASTNAME);
					$sortingCriteria->addDescendingOrderByColumn(PatronPeer::NAME);
				}

				break;

			case 'libraryId': // biblioteca

				$loanStatuses = $this->getLoanStatusMode();

				if ($this->_loanmanager->IsOutStatus($loanStatuses)) 
				{
					$sortingCriteria->clearOrderByColumns();

					if (!$this->checkAlreadyJoined($sortingCriteria, ItemPeer::TABLE_NAME, LibraryPeer::TABLE_NAME))
						$sortingCriteria->addJoin(ItemPeer::DELIVERY_LIBRARY_ID, LibraryPeer::LIBRARY_ID);
										
					if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
					{
						$sortingCriteria->addAscendingOrderByColumn(LibraryPeer::LABEL);
					}
					elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
					{
						$sortingCriteria->addDescendingOrderByColumn(LibraryPeer::LABEL);
					}
				}

				elseif (in_array(ItemPeer::LOANSTATUS_TOSHELF, $loanStatuses)) 
				{
					$sortingCriteria->clearOrderByColumns();

					if (!$this->checkAlreadyJoined($sortingCriteria, LibraryPeer::TABLE_NAME, ItemPeer::TABLE_NAME))
						$sortingCriteria->addJoin(LibraryPeer::LIBRARY_ID, ItemPeer::ACTUAL_LIBRARY_ID);
					
					$sortingCriteria->setDistinct();
					
					if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
					{
						$sortingCriteria->addAscendingOrderByColumn(LibraryPeer::LABEL);
					}
					elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
					{
						$sortingCriteria->addDescendingOrderByColumn(LibraryPeer::LABEL);
					}
				}

				elseif ($this->_loanmanager->IsInStatus($loanStatuses)) 
				{
					$sortingCriteria->clearOrderByColumns();

					if (!$this->checkAlreadyJoined($sortingCriteria, ItemPeer::TABLE_NAME, LoanPeer::TABLE_NAME))
						$sortingCriteria->addJoin(ItemPeer::CURRENT_LOAN_ID, LoanPeer::LOAN_ID);
					
					$sortingCriteria->addJoin(LibraryPeer::LIBRARY_ID,LoanPeer::FROM_LIBRARY);
					$sortingCriteria->setDistinct();
					
					if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
					{
						$sortingCriteria->addAscendingOrderByColumn(LibraryPeer::LABEL);
					}
					elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
					{
						$sortingCriteria->addDescendingOrderByColumn(LibraryPeer::LABEL);
					}
				}

				break;

			case 'loanDateBegin':
				$sortingCriteria->clearOrderByColumns();
				
				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
				{
					$sortingCriteria->addAscendingOrderByColumn(LoanPeer::LOAN_DATE_BEGIN);
				}
				elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
				{
					$sortingCriteria->addDescendingOrderByColumn(LoanPeer::LOAN_DATE_BEGIN);
				}
				
				break;

			case 'loanDateEnd':
				$sortingCriteria->clearOrderByColumns();
				
				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
				{
					$sortingCriteria->addAscendingOrderByColumn(LoanPeer::LOAN_DATE_END);
				}
				elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
				{
					$sortingCriteria->addDescendingOrderByColumn(LoanPeer::LOAN_DATE_END);
				}
				
				break;

			case 'dueDate':
				$sortingCriteria->clearOrderByColumns();
				
				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
				{
					$sortingCriteria->addAscendingOrderByColumn(LoanPeer::DUE_DATE);
				}
				elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
				{
					$sortingCriteria->addDescendingOrderByColumn(LoanPeer::DUE_DATE);
				}
				
				break;

			case 'lastSeenDate':
				$sortingCriteria->clearOrderByColumns();
				
				if (!$this->checkAlreadyJoined($sortingCriteria, LoanPeer::TABLE_NAME, ItemPeer::TABLE_NAME))
					$sortingCriteria->addJoin(LoanPeer::ITEM_ID, ItemPeer::ITEM_ID);

				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
				{
					$sortingCriteria->addAscendingOrderByColumn(ItemPeer::LAST_SEEN);
				}
				elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
				{
					$sortingCriteria->addDescendingOrderByColumn(ItemPeer::LAST_SEEN);
				}
				
				break;

			case 'collocationCombo':
				$sortingCriteria->clearOrderByColumns();

				if (!$this->checkAlreadyJoined($sortingCriteria, LoanPeer::TABLE_NAME, ItemPeer::TABLE_NAME))
					$sortingCriteria->addJoin(LoanPeer::ITEM_ID, ItemPeer::ITEM_ID);
				
				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC) 
				{
					$sortingCriteria->addAscendingOrderByColumn(ItemPeer::SECTION);
					$sortingCriteria->addAscendingOrderByColumn(ItemPeer::COLLOCATION);
					$sortingCriteria->addAscendingOrderByColumn(ItemPeer::SPECIFICATION);
					$sortingCriteria->addAscendingOrderByColumn(ItemPeer::SEQUENCE1);
					$sortingCriteria->addAscendingOrderByColumn(ItemPeer::SEQUENCE2);
				} 
				elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC) 
				{
					$sortingCriteria->addDescendingOrderByColumn(ItemPeer::SECTION);
					$sortingCriteria->addDescendingOrderByColumn(ItemPeer::COLLOCATION);
					$sortingCriteria->addDescendingOrderByColumn(ItemPeer::SPECIFICATION);
					$sortingCriteria->addDescendingOrderByColumn(ItemPeer::SEQUENCE1);
					$sortingCriteria->addDescendingOrderByColumn(ItemPeer::SEQUENCE2);
				}
				break;

			case null:
				break;

			default:
				$sortingExpression = null;
				break;
		}
	}

	/**
	 * We're checking if a join for the given tables already exists
	 * 
	 * @param Criteria $criteria
	 * @param string $leftTableName
	 * @param string $rightTableName
	 * 
	 * @return boolean
	 */
	private function checkAlreadyJoined($criteria, $leftTableName, $rightTableName)
	{
		$joined = false;

		if (($leftTableName != "")
				&& ($rightTableName != "")
				&& ($criteria instanceof Criteria))
			foreach ($criteria->getJoins() as $joinObject)
			{
				if (($joinObject->getLeftTableName() == $leftTableName)
						&& ($joinObject->getRightTableName() == $rightTableName))
				{
					$joined = true;
					break;
				}	
			}

			return $joined;
	}
	
	/**
	 * It populates the grid, and takes the necessary filter
	 * parameters from given saved data, and eventual other filters
	 * (i.e. patron, which was passed through the "setObject()").
	 *
	 */
	public function populate($givenIds = null) 
	{
		/* @var $loan Loan */
		/* @var $criteria Criteria */

		$actualLibraryId = $this->getUser()->getActualLibraryId();
		$pageSize = $this->LoanGrid->getPageSize();
		$currentIndexPage = $this->LoanGrid->getCurrentPage();

		if ($this->getOnlySelected())
			$givenIds = $this->getCheckedItems();

		$activeFilter = $this->getActiveFilter();
		
		if (!is_null($givenIds) 
				&& (count($givenIds) > 0)) 
		{
			$isFiltered = false;

			$this->setGlobalCriteria($givenIds);
			$recCount = count($givenIds);
			$givenIds = array_slice($givenIds, $pageSize * $currentIndexPage, $pageSize);
			
			$loans = LoanQuery::create()->findPks($givenIds);
		} 
		else   // normal case
		{
			$isFiltered = true;

			$fromLibraryId = $this->getFromLibraryId();
			$toLibraryId = $this->getToLibraryId();
			$endLibraryId = $this->getEndLibraryId();
			$homeLibraryId = $this->getHomeLibraryId();
			$loanStatusFilter = $this->getLoanStatus();
			$solicitable = $this->getSolicitable();
			$closedLoanTitle = $this->getSearchTitleClosedLoanList();

			$withItemRequest = $this->getWithItemRequest();
			$withExpired = $this->getWithExpired();
			$patronId = $this->getPatronId();
			$renewCount = floatval($this->getRenewCount());
			
			if (is_null($renewCount))
				$renewCount = "-0.5";

			$solicitCount = $this->getSolicitCount();
			
			if (is_null($solicitCount))
			{
				$solicitCount = -1;
			}
			elseif ($solicitCount > 2)
			{
				$solicitCount = 3;
			}

			$outDateFrom = $this->getOutDateFrom();
			$outDateTo = $this->getOutDateTo();
			$inDateFrom = $this->getInDateFrom();
			$inDateTo = $this->getInDateTo();
			$dueDateFrom = $this->getDueDateFrom();
			$dueDateTo = $this->getDueDateTo();

			$contactFilter = $this->getContactFilter();
			$preferredContact = $this->getPreferredContact();
			$contactBoolean = $this->getContactBoolean();

			$criteria = new Criteria();
			$criteria->add(LoanPeer::LOAN_ID, 0, Criteria::GREATER_THAN);   // generic condition

			if ($this->_llibraryActive)
			{
				$basinDistance = LLibraryPeer::getMaxLLibraryBasin();
				$distanceHash = LibraryPeer::getDistanceHash($actualLibraryId);
				$inBasinIds = implode(',', array_slice($distanceHash, 0, $basinDistance + 1 , true));
				$outBasinIds = implode(',', array_slice($distanceHash, $basinDistance + 1, count($distanceHash) - 1, true));
			}
			else
			{
				//$basinDistance = null;
				//$distanceHash = array();
				$inBasinIds = "";
				$outBasinIds = "";
			}	

			$inBasinIds = explode(',', $inBasinIds);
			$outBasinIds = explode(',', $outBasinIds);
			
			if (!is_null($fromLibraryId)) 
			{
				if ($fromLibraryId == LibraryPeer::EXCLUDEMYLIBRARY)
				{
					$criteria->addAnd(LoanPeer::FROM_LIBRARY, $actualLibraryId, Criteria::NOT_EQUAL);
				}
				elseif ($this->_llibraryActive
							&& ($fromLibraryId == LibraryPeer::INBASIN))
				{
					$criteria->addAnd(LoanPeer::FROM_LIBRARY, $inBasinIds, Criteria::IN);	
				}
				elseif ($this->_llibraryActive
							&& ($fromLibraryId == LibraryPeer::OUTBASIN))
				{
					$criteria->addAnd(LoanPeer::FROM_LIBRARY, $outBasinIds, Criteria::IN);	
				}
				else
				{
					$criteria->addAnd(LoanPeer::FROM_LIBRARY, $fromLibraryId);
				}
			}

			if (!is_null($toLibraryId)) 
			{
//				if ($toLibraryId == LibraryPeer::EXCLUDEMYLIBRARY)
//					$criteria->addAnd(LoanPeer::TO_LIBRARY, $actualLibraryId, Criteria::NOT_EQUAL);
//				else
//					$criteria->addAnd(LoanPeer::TO_LIBRARY, $toLibraryId);
				
				if ($toLibraryId == LibraryPeer::EXCLUDEMYLIBRARY)
				{
					$criteria->addAnd(LoanPeer::TO_LIBRARY, $actualLibraryId, Criteria::NOT_EQUAL);
				}
				elseif ($this->_llibraryActive
							&& ($toLibraryId == LibraryPeer::INBASIN))
				{
					$criteria->addAnd(LoanPeer::TO_LIBRARY, $inBasinIds, Criteria::IN);	
				}
				elseif ($this->_llibraryActive
							&& ($toLibraryId == LibraryPeer::OUTBASIN))
				{
					$criteria->addAnd(LoanPeer::TO_LIBRARY, $outBasinIds, Criteria::IN);	
				}
				else
				{
					$criteria->addAnd(LoanPeer::TO_LIBRARY, $toLibraryId);
				}
			}

			if (!is_null($endLibraryId)) 
			{
				if ($endLibraryId == LibraryPeer::EXCLUDEMYLIBRARY)
				{
					$criteria->addAnd(LoanPeer::END_LIBRARY, $actualLibraryId, Criteria::NOT_EQUAL);
				}
				elseif ($this->_llibraryActive
							&& ($endLibraryId == LibraryPeer::INBASIN))
				{
					$criteria->addAnd(LoanPeer::END_LIBRARY, $inBasinIds, Criteria::IN);	
				}
				elseif ($this->_llibraryActive
							&& ($endLibraryId == LibraryPeer::OUTBASIN))
				{
					$criteria->addAnd(LoanPeer::END_LIBRARY, $outBasinIds, Criteria::IN);	
				}
				else
				{
					$criteria->addAnd(LoanPeer::END_LIBRARY, $endLibraryId);
				}
			}

			if (!is_null($homeLibraryId)) 
			{
				$criteria->addJoin(LoanPeer::ITEM_ID, ItemPeer::ITEM_ID, Criteria::LEFT_JOIN);
				
//				if ($homeLibraryId == LibraryPeer::EXCLUDEMYLIBRARY)
//					$criteria->addAnd(ItemPeer::HOME_LIBRARY_ID, $actualLibraryId, Criteria::NOT_EQUAL);
//				else
//					$criteria->addAnd(ItemPeer::HOME_LIBRARY_ID, $homeLibraryId);
				
				if ($homeLibraryId == LibraryPeer::EXCLUDEMYLIBRARY)
				{
					$criteria->addAnd(ItemPeer::HOME_LIBRARY_ID, $actualLibraryId, Criteria::NOT_EQUAL);
				}
				elseif ($this->_llibraryActive
							&& ($homeLibraryId == LibraryPeer::INBASIN))
				{
					$criteria->addAnd(ItemPeer::HOME_LIBRARY_ID, $inBasinIds, Criteria::IN);	
				}
				elseif ($this->_llibraryActive
							&& ($homeLibraryId == LibraryPeer::OUTBASIN))
				{
					$criteria->addAnd(ItemPeer::HOME_LIBRARY_ID, $outBasinIds, Criteria::IN);	
				}
				else
				{
					$criteria->addAnd(ItemPeer::HOME_LIBRARY_ID, $homeLibraryId);
				}
			}

			if (!is_null($loanStatusFilter)) 
			{
				if (($loanStatusFilter == ItemPeer::LOANSTATUS_TOSHELF)
					|| ($loanStatusFilter == ItemPeer::LOANSTATUS_AVAILABLE)
					|| ($loanStatusFilter == ItemPeer::LOANSTATUS_AVAILABLEEXTRA )) 
				{
					$criteria->addJoin(LoanPeer::ITEM_ID, ItemPeer::ITEM_ID,Criteria::LEFT_JOIN);
					$criteria->addAnd(ItemPeer::LOAN_STATUS, $loanStatusFilter);
					$criteria->addGroupByColumn(LoanPeer::ITEM_ID);
				}
				else
				{
					$criteria->addAnd(LoanPeer::LOAN_STATUS, $loanStatusFilter);
				}
			}

			if (!is_null($closedLoanTitle))
			{
				$criteria->addAnd(LoanPeer::TITLE, "%" . $closedLoanTitle . "%", Criteria::LIKE);
			}
                        
			if (!is_null($patronId))
				$criteria->addAnd(LoanPeer::PATRON_ID, $patronId);

			$object = $this->getObject();
			
			if (!is_null($object))
			{
				switch (get_class($this->_object)) 
				{
					case 'Patron':
						$this->PatronColumn->setVisible(false);
						$criteria->addAnd(LoanPeer::PATRON_ID, $object->getId());

						break;

					case 'Item':
						$this->ItemColumn->setVisible(false);
						$criteria->addAnd(LoanPeer::ITEM_ID, $object->getId());
						
						break;
				}
			}
			else
			{
				$criteria->add(LoanPeer::LOAN_TYPE, ItemPeer::LOANTYPE_EXTRASYSTEM, Criteria::NOT_EQUAL);
			}

			if (!is_null($activeFilter) && !$solicitable) 
			{
				switch ($activeFilter) 
				{
					case 'Active':
						$criteria->addAnd(LoanPeer::LOAN_STATUS, ItemPeer::getLoanStatusActive(), Criteria::IN);
						// turn off "data di rientro"
						$this->LoanDateEndColumn->setVisible(false);
						
						break;
					
					case 'Inactive':
						$criteria->addAnd(LoanPeer::LOAN_STATUS, ItemPeer::getLoanStatusInactive(), Criteria::IN);
						////$this->DueDateColumn->setVisible(false);
						// turn off "ultimo movimento"
						$this->LastSeenColumn->setVisible(false);
						
						break;
				}
			}

			if (($this->PatronColumn->getVisible() == true) && ($this->ItemColumn->getVisible() == true)) 
			{ // if we are not in patronview or itemview pages
				if ($solicitable) 
				{
					$criteria->addAnd(LoanPeer::DUE_DATE, date('Y-m-d'), Criteria::LESS_THAN);
					$criteria->addAnd(LoanPeer::LOAN_STATUS, ItemPeer::getLoanStatusActive(), Criteria::IN);
				}

				if (!$withExpired)
					$criteria->addAnd(LoanPeer::LOAN_STATUS, ItemPeer::getLoanStatusActive(), Criteria::IN);

				if ($withItemRequest) 
				{
					$criteria->addJoin(LoanPeer::MANIFESTATION_ID, ItemRequestPeer::MANIFESTATION_ID, Criteria::LEFT_JOIN);
					$criteria->add(ItemRequestPeer::REQUEST_STATUS, ItemRequestPeer::STATUS_PENDING);
					$criteria->setDistinct();
				}

				if (-1 == $solicitCount)
				{

				}
				elseif (($solicitCount >= 0)
							&& ($solicitCount < 3))
				{
					$criteria->addAnd(LoanPeer::NOTIFY_COUNT, $solicitCount);
				}
				elseif ($solicitCount >= 3)
				{
					$criteria->addAnd(LoanPeer::NOTIFY_COUNT, $solicitCount, Criteria::GREATER_EQUAL);
				}

				if (0 == $renewCount)
				{
					$crit1 = $criteria->getNewCriterion(LoanPeer::RENEW_COUNT,0,Criteria::EQUAL);
					$crit2 = $criteria->getNewCriterion(LoanPeer::RENEW_COUNT,null,Criteria::ISNULL);
					$crit1->addOr($crit2);
					$criteria->add($crit1);
				} 
				elseif ($renewCount == 0.5)
				{
					$criteria->addAnd(LoanPeer::RENEW_COUNT, 0, Criteria::GREATER_THAN);
				} 
				elseif ($renewCount > 0) 
				{
					$criteria->addAnd(LoanPeer::RENEW_COUNT, $renewCount);
				} 
				elseif ($renewCount <= -1) 
				{
					$criteria->addAnd(LoanPeer::RENEW_COUNT, -1, Criteria::LESS_THAN);
				}

				if (!is_null($outDateFrom) 
						&& ($outDateFrom > 0)) 
					$criteria->addAnd(LoanPeer::LOAN_DATE_BEGIN, $outDateFrom, Criteria::GREATER_EQUAL);

				if (!is_null($outDateTo) 
						&& ($outDateTo > 0))
					$criteria->addAnd(LoanPeer::LOAN_DATE_BEGIN, $outDateTo + 86399, Criteria::LESS_EQUAL);

				if (!is_null($inDateFrom) 
						&& ($inDateFrom > 0))
					$criteria->addAnd(LoanPeer::LOAN_DATE_END, $inDateFrom, Criteria::GREATER_EQUAL);

				if (!is_null($inDateTo) 
						&& ($inDateTo > 0))
					$criteria->addAnd(LoanPeer::LOAN_DATE_END, $inDateTo + 86399, Criteria::LESS_EQUAL);

				if (!is_null($dueDateFrom) 
						&& ($dueDateFrom > 0))
					$criteria->addAnd(LoanPeer::DUE_DATE, $dueDateFrom, Criteria::GREATER_EQUAL);

				if (!is_null($dueDateTo) 
						&& ($dueDateTo > 0))
					$criteria->addAnd(LoanPeer::DUE_DATE, $dueDateTo + 86399, Criteria::LESS_EQUAL);

				if (!is_null($contactFilter) 
						&& ($contactFilter != '0')) 
				{
					$criteria->addJoin(LoanPeer::PATRON_ID, ContactPeer::PATRON_ID, Criteria::LEFT_JOIN);
					$criteria->setDistinct();

					if ($contactBoolean) 
					{
						$criteria->addAnd(ContactPeer::CONTACT_TYPE, $contactFilter);
						
						if ($preferredContact)
							$criteria->addAnd(ContactPeer::CONTACT_PREF, "1");
					}
					else 
					{
						if ($preferredContact)
						{
							$contactPrefQuery = " AND contact.CONTACT_PREF = '1' ";
						}
						else
						{
							$contactPrefQuery = "";
						}

						$criteria->addAnd(ContactPeer::CONTACT_TYPE, ContactPeer::PATRON_ID . ' NOT IN (SELECT DISTINCT ' .
											ContactPeer::PATRON_ID . ' FROM ' . ContactPeer::TABLE_NAME . ' INNER JOIN ' .
											LoanPeer::TABLE_NAME . ' ON (' . ContactPeer::PATRON_ID . '=' . LoanPeer::PATRON_ID .
											') WHERE ' . ContactPeer::CONTACT_TYPE . " = '{$contactFilter}' {$contactPrefQuery})", Criteria::CUSTOM);
					}
				}

				$itemMedia = trim($this->getItemMedia());
				
				if (!is_null($itemMedia) 
						&& ($itemMedia != ""))
					$criteria->addAnd(LoanPeer::ITEM_MEDIA, $itemMedia);
			}
			
			if ($this->getOocMode() === true)
			{
				$criteria->add(LoanPeer::MANIFESTATION_ID, 0, Criteria::EQUAL);
			}
			elseif ($this->getOocMode() === false)
			{
				$criteria->add(LoanPeer::MANIFESTATION_ID, 0, Criteria::GREATER_THAN);
			}

			$recCount = LoanPeer::doCount($criteria);

			if ($solicitable)
			{
				$this->LoanGrid->resetSorting('dueDate', null, false);
			}
			else
			{
				$this->LoanGrid->resetSorting('loanDateBegin', TClavisDataGrid::SORTDIRECTION_DESC, false);
			}

			$this->calculateSortingCriteria($criteria);
			$this->setGlobalCriteria(clone $criteria);

			if ($pageSize > 0) 
			{
				$criteria->setLimit($pageSize);
				$criteria->setOffset($currentIndexPage * $pageSize);
			}

			$loans = LoanPeer::doSelect($criteria);
		}  // end of normal case

		$clavisLibrarian = Prado::getApplication()->getUser();
		$datasource = array();

		foreach ($loans as $loan) 
		{
			$loanId = $loan->getId();
			$fromLibraryId = $loan->getFromLibrary();
			$toLibraryId = $loan->getToLibrary();
			$endLibraryId = $loan->getEndLibrary();

            if ($loan->getPatron() instanceof Patron)
			{
				$loanClass = $loan->getPatron()->getLoanClass();
			}
            elseif ($loan->getExternalLibraryId() > 0)
			{
				$loanClass = "X";
			}
            else
			{
				$loanClass = "";
			}

            $expiringFrom = time() + ClavisParamPeer::getParam('ALERTDAYS_' . $loanClass, 0);

			$patronCompleteName = "";
			$navigateUrl = "";
			$canLoan = false;

			if (in_array($loan->getLoanStatus(), ItemPeer::getLoanStatusClosed()))
			{
				$obsoleteMode = true;  // prestito storico, o concluso o annullato
			}
			else
			{
				$obsoleteMode = false;
			}

			$itemId = intval($loan->getItemId());
			$item = $loan->getItem();
			
			if ($item instanceof Item) 
			{
				$homeLibraryId = $item->getHomeLibraryId();
				$ownerLibrary = $item->getOwnerLibrary();
			} 
			else 
			{
				$homeLibraryId = $loan->getItemHomeLibraryId();
				$ownerLibrary = $loan->getItemOwnerLibrary();
			}

			$toolTip = '';
			$patronId = intval($loan->getPatronId());
			$externalLibraryId = intval($loan->getExternalLibraryId());

			if ($obsoleteMode) 
			{
				$canLoan = false;
				$patronCompleteName = $loan->getDestinationName();

				if ($patronId > 0)
				{
					$navigateUrl = PatronPeer::getNavigateUrl($patronId);
				}
				elseif ($externalLibraryId > 0)
				{
					$navigateUrl = LibraryPeer::getNavigateUrl($externalLibraryId);
				}
				else
				{
					$navigateUrl = "";
				}
			}
			else 
			{
				$patron = null;

				if ($patronId > 0)
					$patron = PatronQuery::create()->findPK($patronId);

				if ($patron instanceof Patron)
				{
					$patronCompleteName = $patron->getCompleteName();
					$navigateUrl = $patron->getNavigateUrl(true);  // complete with id
				
					if (intval($itemId) > 0)
					{
						$canLoan = ($this->_loanmanager->IsPatronAllowedToLoan($patron, $itemId) == ClavisLoanManager::OK);
					}
					else
					{
						$canLoan = false;
					}
				}
				else 
				{
					$externalLibrary = null;

					if ($externalLibraryId > 0)
						$externalLibrary = LibraryQuery::create()->findPK($externalLibraryId);
					
					if ($externalLibrary instanceof Library) 
					{
						$patronCompleteName = "<span style='color: red'>[" . Prado::localize("extra-sistema") . "]</span>&nbsp;"
												. $externalLibrary->getLabel() . ' (' . $externalLibrary->getConsortiaId() . ')';

						$navigateUrl = $externalLibrary->getNavigateUrl(true);  // complete with id
						$toolTip = $externalLibrary->getTrimmedDescription(100) . ' ('
										. Prado::localize('consorzio') . ": " . $externalLibrary->getConsortiaString(100) . ')';

						$canLoan = ($this->_loanmanager->isExternalLibraryAllowedToLoan($externalLibraryId) == ClavisLoanManager::OK);
					} 
					else 
					{
						$patronCompleteName = "(" . Prado::localize("senza nome") . ")";
						$navigateUrl = '';
						$canLoan = false;
					}
				}
			}

			$dueDate = $loan->getDueDate('U');

			if ($activeFilter == 'Inactive') 
			{
				$exceedDate = false;
			}
			else 
			{
				$exceedDate = ($this->_loanmanager->isLoanLate($loan) == ClavisLoanManager::LOAN_ISLATE);
			}
			
			$isSolicitable = ($this->_loanmanager->IsLoanSolicitable($loan, $clavisLibrarian) == ClavisLoanManager::OK);
			$isExpiring = $dueDate < $expiringFrom && !$exceedDate;
			$loanStatus = $loan->getLoanStatus();

			if (!isset($loanStatusFilter))
				$loanStatusFilter = $this->getLoanStatus();

			if ($isFiltered && ($item instanceof Item) && (($loanStatusFilter == ItemPeer::LOANSTATUS_TOSHELF)
				|| ($loanStatusFilter == ItemPeer::LOANSTATUS_AVAILABLE)
				|| ($loanStatusFilter == ItemPeer::LOANSTATUS_AVAILABLEEXTRA ))) 
			{
				$itemLoanStatus = $item->getLoanStatus();
				
				if ($loanStatus != $itemLoanStatus)
					$loanStatus = $itemLoanStatus;
			}

			if (isset($this->_checked[$loanId]))
			{
				$checked = $this->_checked[$loanId];
			}
			else
			{
				$checked = false;
			}

			if (isset($this->_checked['all'])
					&& ($this->_checked['all']))
				$checked = !$checked;

			$loanStatusString = $loan->getLoanStatusString($loanStatus);
			if ($ownerLibrary instanceof Library && $ownerLibrary->getLibraryInternal() != '1')
				$loanStatusString .= "<br /><span style='color: red'>[" . Prado::localize("da extra-sistema") . "]</span>";

			$renewDate = ($this->getRenewMode() && $item instanceof Item) 
							? $this->_loanmanager->CalculateRenewDate($item) 
							: null;
			
			$title = $loan->getTrimmedTitle(80);
			
			if (is_null($title) 
					|| ($title == '')) 
			{
				if ($item instanceof Item)
					$title = $item->getTrimmedTitle(80);
			}

			if ($item instanceof Item) 
			{
				$askRenewFlag = $item->isAskRenew($actualLibraryId);
				$collocationCombo = $item->getCollocationCombo();
				$lastSeenDate = $item->getLastSeen('U');
				$isLoanRenewable = (($this->_loanmanager->IsLoanRenewable($item, $clavisLibrarian, $loan->getPatron())) == ClavisLoanManager::OK 
															? true 
															: false);
				
				$isItemLoaned = $this->_loanmanager->IsItemLoaned($item);
				$isItemAvailable = ($this->_loanmanager->IsItemAvailable($item) == ClavisLoanManager::OK);
			} 
			else 
			{
				$askRenewFlag = false;
				$collocationCombo = $loan->getCollocation();
				$lastSeenDate = '';
				$isLoanRenewable = false;
				$isItemLoaned = false;
				$isItemAvailable = false;
			}

			$newRow = array('collocationCombo' => $collocationCombo,
							'Checked' => $checked,
							'id' => $loanId,
							'title' => $title,
							'inv_number' => $loan->getInvNumber(),
							'loanStatus' => $loanStatus,
							'loanStatusString' => $loanStatusString,
							'consultationFlag' => in_array($loanStatus, ItemPeer::getLoanStatusConsultation()),
							'fromLibraryId' => $fromLibraryId,
							'fromLibraryString' => LibraryPeer::getLibraryLabel($fromLibraryId, '---'),
							'toLibraryId' => $toLibraryId,
							'toLibraryString' => LibraryPeer::getLibraryLabel($toLibraryId, '---'),
							'endLibraryId' => $endLibraryId,
							'endLibraryString' => LibraryPeer::getLibraryLabel($endLibraryId, '---'),
							'homeLibraryId' => $homeLibraryId,
							'homeLibraryString' => LibraryPeer::getLibraryLabel($homeLibraryId, '---'),
							'patronCompleteName' => $patronCompleteName,
							'patronNavigateUrl' => $navigateUrl,
							'patronNavigateUrlToolTip' => $toolTip,
							'lastSeenDate' => $lastSeenDate,
							'loanDateBegin' => $loan->getLoanDateBegin('U'),
							'loanDateEnd' => $loan->getLoanDateEnd('U'),
							'itemId' => $itemId,
							'dueDate' => $dueDate,
							'exceedDate' => ($exceedDate && $this->_loanmanager->IsLoanStatusActive($loan) && ($dueDate != '')),
							'isExpiring' => $isExpiring,
							'isSolicitable' => $isSolicitable,
							'solicitCount' => intval($loan->getNotifyCount()),
							'renewCount' => $loan->getRenewCountLabel(),
							'isLoanRenewable' => $isLoanRenewable,
							'askRenewFlag' => $askRenewFlag,
							'isItemLoaned' => $isItemLoaned,
							'isItemAvailable' => $isItemAvailable,
							'isReadyToLoan' => ($loan->getLoanStatus() == ItemPeer::LOANSTATUS_READYFORLOAN) && $canLoan,
							'renewDate' => $renewDate);

			$datasource[] = $newRow;
		}

		$this->_datasource = $datasource;
		$this->writeResults($datasource, $recCount, $pageSize);

		$this->NoSearchPanel->setCssClass('panel_off');
	}

	protected function writeResults($data = array(), $recCount = 0, $pageSize = 0) 
	{
		$this->PopulatedFlag->setValue('true');

		if ($pageSize > 0)
			$this->LoanGrid->VirtualItemCount = $recCount;

		$this->setDataSource($this->_datasource);
		$this->LoanGrid->setDataSource($this->_datasource);
		$this->LoanGrid->dataBind();

		if (!$this->getOnlySelected())
			$this->FoundNumber->setText($recCount);
	}

	public function onChangePage($sender, $param) 
	{
		$this->LoanGrid->setCurrentPage($param->NewPageIndex);
		$this->populate();
	}

	public function globalRefresh() 
	{
		$this->resetSorting();
		$this->populate();
	}

	/**
	 * Are we inside a popup?
	 *
	 * @return boolean
	 */
	public function getPopupFlag() 
	{
		return $this->getPage()->IsPopup();
	}

	/**
	 * Resets the datagrid's pagination (first page).
	 *
	 */
	public function resetPagination() 
	{
		$this->LoanGrid->setCurrentPage(0);
	}

	public function onUnloan($sender, $param) 
	{
		$itemId = $param->CommandParameter;
		if ($itemId > 0) 
		{
			$item = ItemQuery::create()->findPK($itemId);
			if ($item instanceof Item && $this->_loanmanager->IsItemLoaned($item))
			{
				$isLate = ($this->_loanmanager->isLoanLate($item) == ClavisLoanManager::LOAN_ISLATE);
				$dueDate = $item->getDueDate('%x');
				$clavisLibrarian = $this->getUser();
				//$patron = $item->getPatron();

				$returnValue = $this->_loanmanager->DoReturnItem($item, $item->getPatron(), $clavisLibrarian);
				$messageText = '';
				$messageType = ClavisMessage::ERROR;
				$updatePageFlag = false;

				if (($returnValue == ClavisLoanManager::OK) 
						|| ($returnValue == ClavisLoanManager::RETN_PATRONREQUEST)) 
				{
					$updatePageFlag = true;
					$messageText = Prado::localize('Rientro eseguito correttamente per l\'esemplare ({itemid}) \'{title}\'',
														array(	'itemid' => $item->getitemId(),
																'title' => $item->getTrimmedTitle(40) ));
					
					$messageType = ClavisMessage::CONFIRM;

					if ($returnValue == ClavisLoanManager::RETN_PATRONREQUEST) 
					{
						$messageText .= ',<br />' . Prado::localize('ed esistono prenotazioni.');
						$messageType = ClavisMessage::WARNING;
					}

					if ($isLate) 
					{
						$messageText .= ',<br />' . Prado::localize('<b>** consegnato in ritardo</b> (scaduto il {dueDate}) <b>**</b>', 
																		array('dueDate' => $dueDate));
						$messageType = ClavisMessage::WARNING;
					}

					if ($item->getLoanStatus() == ItemPeer::LOANSTATUS_READYFORTRANSITTOHOME)
						$messageText .= '<br />' . Prado::localize('L\'esemplare è stato messo in \'pronto al transito di rientro\'.');
				}

				elseif ($returnValue == ClavisLoanManager::ERROR) 
				{
					$messageText = Prado::localize('Rientro fallito');
					$messageType = ClavisMessage::ERROR;
				} 
				else 
				{
					$messageText = Prado::localize('Valore di ritorno sconosciuto');
					$messageType = ClavisMessage::ERROR;
				}

				$this->getPage()->writeMessage($messageText, $messageType);

				if ($updatePageFlag)
                {
                    $this->broadcastEvent("OnLoanUpdated",$this, new TBroadcastEventParameter());
                    $this->globalRefresh();
                }

			}
		}
	}

	public function onRenewItem($sender, $param) 
	{
		$this->getPage()->cleanMessageQueue();

		$item = null;
		$itemId = intval($param->CommandParameter);
		
		if ($itemId > 0)
			$item = ItemQuery::create()->findPK($itemId);

		if ($item instanceof Item) 
		{
			$oldDueDate = Clavis::dateFormat($item->getDueDate('U'));
			$clavisLibrarian = $this->getUser();
			$destinationObject = $this->_loanmanager->getLoanDestinationObject($item);
		
			if (!is_null($destinationObject)) 
			{
				$renewDate = Clavis::dateFormat($this->_loanmanager->CalculateRenewDate(	$item,
																							$destinationObject));

				if ($this->_loanmanager->DoRenewLoan(	$item,
														$destinationObject,
														$clavisLibrarian,
														Prado::localize('rinnovo standard')))
				{
					$item->reload();
					
					$this->getPage()->enqueueMessage(Prado::localize("Proroga fino al {date} eseguita correttamente per il prestito sull'esemplare '{title}', inv: {inv}, barcode: {barcode}",
																		array(	'date' => Clavis::dateFormat($item->getDueDate('U')),		//$item->getDueDate('%x'),
																				'title' => $item->getTrimmedTitle(60),
																				'inv' => $item->getCompleteInventoryNumber(),
																				'barcode' => $item->getBarcode())),
														ClavisMessage::INFO);

					if ($item->isExternal()
							&& intval(ClavisParamPeer::getParam('EXTRARENEW_CONFIRMEMAIL')) == 1) 
					{
						$library = $item->getOwnerLibraryLabel();
						$loan = $item->getCurrentLoan();

						$notificationManager = $this->getApplication()->getModule('notification');
						$resultAddress = $notificationManager->sendEmailRenew(	'EXTRA_RENEW_CONFIRM', 
																				$loan, 
																				$oldDueDate, 
																				$renewDate);
						
						if ($resultAddress == self::INVALIDEMAIL)
						{	
							$this->getPage()->enqueueMessage(Prado::localize("La biblioteca esterna [{library}] non ha un indirizzo email valido",
																				array('library' => $library)), 
																ClavisMessage::WARNING);
						}
						elseif ($resultAddress != '')
						{	
							$this->getPage()->enqueueMessage(Prado::localize("É stata spedita una email informativa alla biblioteca '{library}', all'indirizzo '{email}'", 
																				array(	'library' => $library, 
																						'email' => $resultAddress)), 
																ClavisMessage::INFO);
						}
						else
						{	
							$this->getPage()->enqueueMessage(Prado::localize("É fallita la richiesta di proroga per l'esemplare '{title}' [inv: {inv}]",
																				array(	'title' => $item->getTrimmedTitle(60), 
																						'inv' => $item->getCompleteInventoryNumber())), 
																ClavisMessage::ERROR);
						}
					}

					$this->populate();
				}
				else
				{
					$this->getPage()->enqueueMessage(Prado::localize("Proroga fallita sull'esemplare '{title}', inv: {inv}, barcode: {barcode}", 
																		array(	'title' => $item->getTrimmedTitle(60),
																				'inv' => $item->getCompleteInventoryNumber(),
																				'barcode' => $item->getBarcode())), 
														ClavisMessage::ERROR);
				}
			}
			else
			{
				$this->getPage()->enqueueMessage(Prado::localize("Incongruenza sulla proroga dell'esemplare con id: {id}.<br />Riportare al fornitore del software, grazie", 
																	array('id' => $item->getItemId())), 
													ClavisMessage::ERROR);
			}
		}
		else
		{
			$this->getPage()->enqueueMessage(Prado::localize("Errore dell'applicazione: nel rinnovo extra è stato passato il parametro 'itemId={itemId}' ma l'esemplare non sembra esistere.<br />Riportare al fornitore del software, grazie",
																array('itemId' => $itemId)),
												ClavisMessage::ERROR);
		}

		$this->getPage()->flushMessage();
	}

	public function onSuspendRenew($sender, $param) 
	{
		$this->getPage()->cleanMessageQueue();

		$clavisLibrarian = $this->getUser();
		$ok = false;

		$item = (object) null;
		$itemId = intval($param->CommandParameter);
		
		if ($itemId > 0)
			$item = ItemQuery::create()->findPK($itemId);
		
		if ($item instanceof Item)
		{
			$itemtit = $item->getCompleteTitle();
		
			if (!$itemtit)
				$itemtit = Prado::localize('(nessun titolo)');

			if ($this->_loanmanager->IsItemLoaned($item)) 
			{
				switch ($this->_loanmanager->doDisableRenew($itemId, $clavisLibrarian)) 
				{
					case ClavisLoanManager::OK:
						$this->getPage()->enqueueMessage(Prado::localize("L'esemplare con titolo '{title}' [barcode: {barcode}, inv: {inv}] è stato sospeso dalle proroghe.",
																			array(	'title' => $itemtit,
																					'inv' => $item->getCompleteInventoryNumber(),
																					'barcode' => $item->getBarcode())), 
															ClavisMessage::INFO);
						$ok = true;
			
						break;

					case ClavisLoanManager::ERROR:
						$this->getPage()->enqueueMessage(Prado::localize("L'operazione di sospensione di proroga è fallita"), 
															ClavisMessage::ERROR);
						break;

					default:
						$this->getPage()->enqueueMessage(Prado::localize("Errore sconosciuto durante la sospensione di proroga"), 
															ClavisMessage::ERROR);
						break;
				}
			} 
			else 
			{
				$this->getPage()->enqueueMessage(Prado::localize("L'esemplare con id = {id} e barcode = '{barcode}' NON E' IN PRESTITO !", 
																	array(	'id' => $item->getId(),
																			'barcode' => $item->getBarcode())), 
													ClavisMessage::ERROR);
			}
		}
		else
		{	
			$this->getPage()->enqueueMessage(Prado::localize("Errore nel passaggio dei parametri.<br />Riportare al fornitore del software, grazie",
																array(	'id' => $item->getId(),
																		'barcode' => $item->getBarcode())), 
												ClavisMessage::ERROR);
		}
		
		if ($ok)
			$this->populate();

		$this->getPage()->flushMessage();
	}

	/// probably no more used by anyone. Moved to the NotificationManager (by mbrancalion)	
	private function sendEmailRenew(	$templateName = '', 
										$loan = null, 
										$oldDueDate = null, 
										$newRenewDate = null, 
										$description = null) 
	{
		/* @var $patron Patron */
		/* @var $externalLibrary Library */

		/* @var $myLibrary Library */
		/* @var $loan Loan */

		$templateName = trim($templateName);
		if ($templateName == '')
			return false;

		$success = false;

		$patronData = '---';
		$patron = $loan->getPatron();
		if ($patron instanceof Patron)
			$patronData = $patron->getCompleteName();

		$item = $loan->getItem();
		if (!($item instanceof Item))
			return '';

		$library = $item->getOwnerLibrary();
		if ($library instanceof Library)
		{
			$libraryEmailString = trim($library->getEmail());
			if ($libraryEmailString == '')
				return self::INVALIDEMAIL;

			$libraryEmail = array($libraryEmailString);
		}
		else
		{
			return self::INVALIDEMAIL;
		}

		$libraryString = $item->getOwnerLibraryLabel(false, true, false, false);   // strip tags, no addendum

		if (is_null($oldDueDate))
			$oldDueDate = Clavis::dateFormat($loan->getDueDate('U'));

		if (is_null($newRenewDate))
			$newRenewDate = Clavis::dateFormat($this->_loanmanager->CalculateRenewDate($item, $patron));

		$title = $item->getTrimmedTitle(60);
		$inventory = $item->getCompleteInventoryNumber();
		$collocation = $item->getCollocationCombo();

		$myLibrary = $this->getUser()->getActualLibrary();
		$myLibraryId = $this->getUser()->getActualLibraryId();
		$myConsortiumString = $myLibrary->getConsortiaString();

		$notificationManager = $this->getApplication()->getModule('notification');

		if ($description != '')
			$description = Prado::localize("con la seguente motivazione") . ":\n" . $description . "\n";

		$class = get_class($library);
		$receiverId = $library->getLibraryId();

		$template = DocumentTemplatePeer::getTemplate(	$templateName,
														$this->getApplication()->getGlobalization()->getCulture(),
														$myLibraryId);
		if (!$template instanceof DocumentTemplate)
			return false;

		$arr_alias = array(	'EXTERNALLIBRARY' => $libraryString,
							'TITLE' => $title,
							'INVENTORY' => $inventory,
							'COLLOCATION' => $collocation,
							'PATRON' => $patronData,
							'OLDRENEW' => $oldDueDate,
							'NEWRENEW' => $newRenewDate,
							'MOTIVATION' => $description,
							'LIBRARY' => $myLibrary->getLabel(),
							'LIBRARY_CODE' => $myLibrary->getLibraryCode(),
							'LIBRARY_DESCRIPTION' => $myLibrary->getDescription(),
							'LIBRARY_CITY' => $myLibrary->getCity(),
							'LIBRARY_ADDRESS' => $myLibrary->getAddress(),
							'LIBRARY_PHONE' => $myLibrary->getPhone(),
							'LIBRARY_FAX' => $myLibrary->getFax(),
							'LIBRARY_EMAIL' => $myLibrary->getEmail() );

		$mailData = array();
		$mailData['to'] = $libraryEmail;
		$mailData['bcc'] = array();
		$mailData['cc'] = array();
		$mailData['body'] = '';
		$mailData['subject'] = "[$myConsortiumString]: " . $template->getTemplateTitle();

		$mailData['from'] = array(	'name' => $myLibrary->getLabel(),
									'email' => $myLibrary->getEmail() );

		$notificationData = array(	'sender_library_id' => $myLibraryId,
									'receiver_class' => $class,
									'receiver_id' => $receiverId,
									'description' => Prado::localize("Richiesta proroga a biblioteca esterna"),
									'notes' => array() );

		try 
		{
			$ret = $notificationManager->DoEmailReport(	$template->getTemplateBody(),
														$arr_alias,
														$mailData,
														NotificationManager::EMAIL_AUTO,
														$notificationData);

			if ($ret === true)
				$success = implode(',', $libraryEmail);
		} 
		catch (Exception $e) 
		{
			$e = $e;
			//throw ($e)
			$success = false;
		}

		return $success;
	}

	public function onAskRenewItem($sender, $param) 
	{
		$loanId = $param->CommandParameter;
		$loan = null;
		
		if ($loanId > 0)
			$loan = LoanQuery::create()->findPK($loanId);

		if ($loan instanceof Loan) 
		{
			$item = $loan->getItem();
		
			if (!($item instanceof Item)) 
			{
				$message = array(Prado::localize("Incongruenza sul database durante la richiesta di proroga, relativamente al prestito con loan_id = {loanId}.<br />Riportare al fornitore del software, grazie",
												array('loanId' => $loan->getLoanId())),
									ClavisMessage::ERROR);

				return false;
			}

			$patron = $loan->getPatron();
			$library = $item->getOwnerLibraryLabel();

			$oldDueDate = $loan->getDueDate('%x');
			$newRenewDate = strftime('%x', $this->_loanmanager->CalculateRenewDate($item, $patron));

			$notificationManager = $this->getApplication()->getModule('notification');
			$resultAddress = $notificationManager->sendEmailRenew('EXTRA_RENEW_ASK', $loan, $oldDueDate, $newRenewDate);
			if ($resultAddress == self::INVALIDEMAIL)
			{
				$message = array(Prado::localize("La biblioteca richiedente [{library}] non ha un indirizzo email valido",
													array('library' => $library)),
									ClavisMessage::ERROR);
			}
			elseif ($resultAddress != '') 
			{
				$message = array(Prado::localize("E' stata correttamente richiesta la proroga dell'esemplare '{title}' [inv: {inv}, coll: {coll}] alla biblioteca '{library}', all'indirizzo '{email}'",
													array(	'date' => $newRenewDate,
															'title' => $item->getTrimmedTitle(60),
															'inv' => $item->getCompleteInventoryNumber(),
															'coll' => $item->getCollocationCombo(),
															'library' => $library,
															'email' => $resultAddress)),
									ClavisMessage::INFO);

				$this->populate();
			}
			else
			{
				$message = array(Prado::localize("E' fallita la richiesta di proroga per l'esemplare '{title}' [inv: {inv}]",
													array(	'title' => $item->getTrimmedTitle(60),
															'inv' => $item->getCompleteInventoryNumber())),
									ClavisMessage::ERROR);
			}
			
			$this->getPage()->writeMessage($message[0], $message[1]);
		}
		else
		{
			$this->getPage()->writeMessage(Prado::localize("Errore nel passaggio dei parametri.<br />Riportare al fornitore del software, grazie"),
											ClavisMessage::ERROR);
		}
	}

	public function onReadyToLoan2Loan($sender, $param) 
	{
		$this->getPage()->cleanMessageQueue();

		$patron = (object) null;
		$externalLibrary = (object) null;
		$object = $this->getObject();
		
		if (get_class($object) == 'Patron')
		{
			$patron = $object;
		}
		elseif (get_class($object) == 'Library')
		{
			$externalLibrary = $object;
		}

		$itemId = intval($param->CommandParameter);
		$item = null;
		
		if ($itemId > 0)
			$item = ItemQuery::create()->findPK($itemId);

		if ($item instanceof Item) 
		{
			$clavisLibrarian = $this->getUser();
			$allOk = true;

			if ($patron instanceof Patron) 
			{
				switch ($this->_loanmanager->IsPatronAllowedToLoan($patron, $itemId)) 
				{
					case ClavisLoanManager::LOAN_REACHEDMAX:

						$this->getPage()->enqueueMessage(Prado::localize("L'utente '{name}' ha superato il numero di prestiti consentiti", 
																			array('name' => $patron->getCompleteName())), 
															ClavisMessage::ERROR);
						$allOk = false;
		
						break;

					case ClavisLoanManager::LOAN_PATRONNOTENABLED:

						$this->getPage()->enqueueMessage(Prado::localize("L'utente '{name}' non è abilitato al prestito", 
																			array('name' => $patron->getCompleteName())), 
															ClavisMessage::ERROR);
						$allOk = false;
						
						break;
				}
			} 
			elseif ($externalLibrary instanceof Library) 
			{
				if ($this->_loanmanager->isExternalLibraryAllowedToLoan($externalLibrary->getLibraryId()) != ClavisLoanManager::OK) 
				{
					$this->getPage()->enqueueMessage(Prado::localize("La biblioteca '{bibl}' non è abilitata al prestito", 
																		array('bibl' => $externalLibrary->getLabel(true, true, true))), 
														ClavisMessage::ERROR);
					$allOk = false;
				}
			}

			if ($allOk) 
			{
				$result = $this->_loanmanager->DoReadyToLoan2LoanItem($item, $clavisLibrarian);
				$barcode = $item->getBarcode();
				$itemDataString = $item->getTrimmedTitle(40) . ($barcode == '' 
																	? '' 
																	: ' (' . Prado::localize('barcode') . ': ' . $barcode) . ')';

				if ($result == ClavisLoanManager::OK)
				{
					$this->getPage()->enqueueMessage(Prado::localize("Prestito effettuato sull'esemplare '{title}' che era in stato di pronto al prestito", 
																		array('title' => $itemDataString)), 
														ClavisMessage::INFO);

					$this->populate();
				}
				elseif ($result == ClavisLoanManager::LOAN_PATRONNOTENABLED)
				{
					$patron = $item->getPatron();
					$patronData = ($patron instanceof Patron
									? $patron->getReverseCompleteName()
									: "(" . Prado::localize('utente inesistente') . ")" );
				
					$this->getPage()->enqueueMessage(Prado::localize("Prestito fallito sull'esemplare '{title}' che è in stato di pronto al prestito "
																		. "perchè l'utente '{patron}' non è abilitato al prestito", 
																		array(	'title' => $itemDataString,
																				'patron' => $patronData)), 
														ClavisMessage::ERROR);
				}
				else	// fallback
				{
					$this->getPage()->enqueueMessage(Prado::localize("Prestito fallito sull'esemplare '{title}' che è in stato di pronto al prestito", 
																		array('title' => $itemDataString)), 
														ClavisMessage::ERROR);
				}
			}
		}

		$this->getPage()->flushMessage();
	}

	public function onAddToShelf($sender, $param) 
	{
		$shelfId = $this->ShelfResultValue->getValue();
		
		if (is_numeric($shelfId) && !is_null($shelfId)) 
		{
			$shelf = ShelfQuery::create()->findPK($shelfId);
		
			if (!is_null($shelf) 
					&& ($shelf instanceof Shelf)) 
			{
				$checkedLoanIds = $this->getCheckedItems();
				$countDone = $shelf->addItemToShelf('loan', $checkedLoanIds);
				$countFailed = count($checkedLoanIds) - $countDone;
				
				if ($countDone > 0) 
				{
					$this->getPage()->writeMessage($countDone == 1 
															? Prado::localize('1 elemento processato') 
															: Prado::localize('{count} elementi processati', 
																				array('count' => $countDone)), 
													ClavisMessage::INFO);
				}

				if ($countFailed > 0)
				{
					$this->getPage()->writeMessage($countFailed == 1 
															? Prado::localize('1 elemento non processato') 
															: Prado::localize('{count} elementi non processati', 
																				array('count' => $countFailed)), 
													ClavisMessage::ERROR);
				}
			}
		}

		if ($this->TeleportCheck->getChecked())
			$this->getPage()->gotoPageWithReturn('Communication.ShelfViewPage', array('id' => $shelfId));
	}

	public function onSuspendConsultation($sender, $param) 
	{
		$itemId = $param->CommandParameter;
		$item = null;
		
		if ($itemId > 0)
			$item = ItemQuery::create()->findPK($itemId);

		if (!is_null($item) 
				&& ($item instanceof Item)) 
		{
			$clavisLibrarian = $this->getUser();
			$patron = $item->getPatron();
			
			if (!is_null($patron)) 
			{
				$patronName = $patron->getCompleteName();
				$patronCode = $patron->getBarcode();
			} 
			else 
			{
				$patronName = '<' . Prado::localize('utente senza nome') . '>';
				$patronCode = '<' . Prado::localize('numero tessera mancante') . '>';
			}

			if ($this->_loanmanager->doFreezeConsultation($itemId, $clavisLibrarian) == ClavisLoanManager::OK) 
			{
				$message = array(Prado::localize("Messa in deposito eseguita correttamente sull'esemplare '{title}' [barcode: {barcode}, inv: {inventory}] in consultazione all'utente <b>{patronname}</b> [barcode '{patronCode}']",
													array(	'title' => $item->getTrimmedTitle(60),
															'barcode' => $item->getBarcode(),
															'inventory' => $item->getCompleteInventoryNumber(),
															'patronname' => $patronName,
															'patronCode' => $patronCode)),
									ClavisMessage::INFO);

				$this->populate();
			}
			else
			{	$message = array(Prado::localize("Messa in deposito fallita sull'esemplare '{title}'", 
													array('title' => $item->getTrimmedTitle(60))),
									ClavisMessage::ERROR);
			}
			
			$this->getPage()->writeMessage($message[0], $message[1]);
		}
	}

	public function onResumeConsultation($sender, $param) 
	{
		$itemId = $param->CommandParameter;
		$item = null;
		
		if ($itemId > 0)
			$item = ItemQuery::create()->findPK($itemId);

		if (!is_null($item) && ($item instanceof Item)) 
		{
			$clavisLibrarian = $this->getUser();
			$patron = $item->getPatron();
		
			if (!is_null($patron)) 
			{
				$patronName = $patron->getCompleteName();
				$patronCode = $patron->getBarcode();
			} 
			else 
			{
				$patronName = '<' . Prado::localize('utente senza nome') . '>';
				$patronCode = '<' . Prado::localize('barcode utente mancante') . '>';
			}

			if ($this->_loanmanager->doResumeConsultation($itemId, $clavisLibrarian) == ClavisLoanManager::OK) 
			{
				$message = array(Prado::localize("Ripresa della consultazione eseguita correttamente sull'esemplare '{title}' [barcode: {barcode}, inv: {inventory}] in consultazione all'utente <b>{patronname}</b> [barcode '{patronCode}']",
													array(	'title' => $item->getTrimmedTitle(60),
															'barcode' => $item->getBarcode(),
															'inventory' => $item->getCompleteInventoryNumber(),
															'patronname' => $patronName,
															'patronCode' => $patronCode)),
									ClavisMessage::INFO);

				$this->populate();
			}
			else
			{	$message = array(Prado::localize("Ripresa di consultazione fallita sull'esemplare '{title}'", 
													array('title' => $item->getTrimmedTitle(60))),
									ClavisMessage::ERROR);
			}
			
			$this->getPage()->writeMessage($message[0], $message[1]);
		}
	}

}