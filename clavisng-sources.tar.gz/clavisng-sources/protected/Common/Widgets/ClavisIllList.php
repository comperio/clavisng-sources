<?php
/**
 * ClavisIllList class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info
 * @comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @author Ciro Mattia Gonano
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.8.9
 * @package Widgets
 */

/**
 * ClavisIllList Class
 *
 * This component visualizes a datagrid with actual items which are
 * requested for interbibliotecary loan,
 * filtered upon some parameters (inserted by some dropdown lists),
 * or filtered by some other parameters (i.e. patron_id) which are set
 * externally by the "setObject()" method (note: the column which
 * matched the typo of object passed is turned off in the grid).
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @author Ciro Mattia Gonano
 * @version 2.8.9
 * @package Widgets
 * @since 2.1
 */
class ClavisIllList extends TTemplateControl
{
	private $_datasource = null;
	private $_checked;
	private $_dueDate;

	/* @var $_loanmanager ClavisLoanManager */
	protected $_loanmanager;
	protected $_requestmanager;
	private $_barcode;
	private $_paramLibraryId;
	private $_patronId;
	private $_outDateFrom;
	private $_outDateTo;
	private $_lastSeenDateFrom;
	private $_lastSeenDateTo;
	private $_solicitCount;
	private $_contactFilter;
	private $_preferredContact;
	private $_contactBoolean;
	private $_object;
	private $_activeFilter;
	private $_loanStatusMode;
	private $_illFoundDatasourceSessionName;
	private $_illCheckedSessionName;
	private $_dueDateSessionName;
	private $_globalCriteriaSessionName;

	const DAYTIMESTAMP = 86400;

	private function initVars()
	{
		$uniqueId = $this->getUniqueID();
		$this->_illFoundDatasourceSessionName = 'IllFoundDataSourceSessionName' . $uniqueId;
		$this->_illCheckedSessionName = 'IllCheckedSessionName' . $uniqueId;
		$this->_dueDateSessionName = 'DueDateSessionName' . $uniqueId;
		$this->_globalCriteriaSessionName = 'GlobalCriteriaSessionName' . $uniqueId;

		$this->_loanmanager = $this->getApplication()->getModule('loan');
		
		if ($this->getManageRequests())
			$this->_requestmanager = $this->getApplication()->getModule('request');
		
		$this->_datasource = $this->getDatasource();
	}

	public function onInit($param)
	{
		parent::onInit($param);
		$this->initVars();
	}

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallBack())
		{
			$this->resetPagination();
			//$this->setGlobalCriteria();
		}

		$this->_checked = $this->getChecked();
		$this->_dueDate = $this->getDueDate();
	}

	public function setLoanStatusMode($mode)
	{
		$this->_loanStatusMode = $mode;
		$this->setViewState("loanStatusMode", $mode, null);
	}

	public function getLoanStatusMode()
	{
		if (is_null($this->_loanStatusMode))
			$this->_loanStatusMode = $this->getViewState("loanStatusMode", null);
		
		return $this->_loanStatusMode;
	}

	public function setDoubleCounterViewMode($mode = true)
	{
		$this->setViewState("doubleCounterView", $mode, true);
	}

	public function getDoubleCounterViewMode()
	{
		$value = $this->getViewState('doubleCounterView', true);
		
		if (is_string($value))
			$value = ($value === 'true') ? true : false;
		
		return $value;
	}

	public function setManageRequests($mode = false)
	{
		$this->setViewState("manageRequests", $mode, false);
	}

	public function getManageRequests()
	{
		$value = $this->getViewState("manageRequests", false);
		
		if (is_string($value))
			$value = ($value === 'true') ? true : false;
		
		return $value;
	}
	
	public function setObject($obj)
	{
		$this->_object = $obj;
		$this->setViewState("object", $obj, null);
	}

	public function getObject()
	{
		if (is_null($this->_object))
			$this->_object = $this->getViewState("object", null);
		
		return $this->_object;
	}

	public function setParamLibraryId($lib)
	{
		$this->_paramLibraryId = $lib;
		$this->setViewState('paramLibraryId', $this->_paramLibraryId, null);
	}

	public function getParamLibraryId()
	{
		if (($lib = $this->_paramLibraryId) == null)
		{
			$lib = $this->getViewState('paramLibraryId', null);
			$this->_paramLibraryId = $lib;
		}
		
		return $lib;
	}

	public function setLoanStatus($loanStatus)
	{
		$this->_loanStatus = $loanStatus;
		$this->setViewState('loanStatus', $this->_loanStatus, null);
	}

	public function getLoanStatus()
	{
		if (($loanStatus = $this->_loanStatus) == null)
		{
			$loanStatus = $this->getViewState('loanStatus', null);
			$this->_loanStatus = $loanStatus;
		}
		
		return $loanStatus;
	}

	public function setBarcode($barcode)
	{
		$this->_barcode = $barcode;
		$this->setViewState('barcode', $this->_barcode, null);
	}

	public function getBarcode()
	{
		$this->_barcode = $this->getViewState('barcode', null);
		
		return $this->_barcode;
	}

	public function setPatronId($id)
	{
		$this->_patronId = $id;
		$this->setViewState('patronId', $this->_patronId, null);
	}

	public function getPatronId()
	{
		if (($id = $this->_patronId) == null)
		{
			$id = $this->getViewState('patronId', null);
			$this->_patronId = $id;
		}
		
		return $id;
	}

	public function setOutDateFrom($date)
	{
		$this->_outDateFrom = $date;
		$this->setViewState('outDateFrom', $this->_outDateFrom, null);
	}

	public function getOutDateFrom()
	{
		if (($date = $this->_outDateFrom) == null)
		{
			$date = $this->getViewState('outDateFrom', null);
			$this->_outDateFrom = $date;
		}
		
		return $date;
	}

	public function setOutDateTo($date)
	{
		$this->_outDateTo = $date;
		$this->setViewState('outDateTo', $this->_outDateTo, null);
	}

	public function getOutDateTo()
	{
		if (($date = $this->_outDateTo) == null)
		{
			$date = $this->getViewState('outDateTo', null);
			$this->_outDateTo = $date;
		}
		
		return $date;
	}

	public function setLastSeenDateFrom($date)
	{
		$this->_lastSeenDateFrom = $date;
		$this->setViewState('lastSeenDateFrom', $this->_lastSeenDateFrom, null);
	}

	public function getLastSeenDateFrom()
	{
		if (($date = $this->_lastSeenDateFrom) == null)
		{
			$date = $this->getViewState('lastSeenDateFrom', null);
			$this->_lastSeenDateFrom = $date;
		}
		
		return $date;
	}

	public function setLastSeenDateTo($date)
	{
		$this->_lastSeenDateTo = $date;
		$this->setViewState('lastSeenDateTo', $this->_lastSeenDateTo, null);
	}

	public function getLastSeenDateTo()
	{
		if (($date = $this->_lastSeenDateTo) == null)
		{
			$date = $this->getViewState('lastSeenDateTo', null);
			$this->_lastSeenDateTo = $date;
		}
		
		return $date;
	}

	public function setSolicitCount($count) 
	{
		$this->_solicitCount = $count;
		$this->setViewState('solicitCount', $this->_solicitCount, null);
	}

	public function getSolicitCount() 
	{
		if (($count = $this->_solicitCount) == null) 
		{
			$count = $this->getViewState('solicitCount', null);
			$this->_solicitCount = $count;
		}
		
		return $count;
	}
	
	public function setExtraSystem($value = null)
	{
		if ($value === "true")
		{
			$value = true;
		}
		elseif ($value === "false")
		{
			$value = false;
		}

		$this->setControlState('extraSystem', $value, null);
	}

	public function getExtraSystem()
	{
		return $this->getControlState('extraSystem', null);
	}

	public function setActiveFilter($activeFilter = null)
	{
		$this->_activeFilter = $activeFilter;
		$this->setViewState("activeFilter", $activeFilter, null);
	}

	public function getActiveFilter()
	{
		if (is_null($this->_activeFilter))
			$this->_activeFilter = $this->getViewState("activeFilter", null);
		
		return $this->_activeFilter;
	}
	
	public function resetCheckedItems($state = false)
	{
		$this->setChecked(array('all' => $state));
	}

	public function setChecked($checked = null)
	{
		$this->_checked = $checked;
		$this->getApplication()->getSession()->add($this->_illCheckedSessionName, $checked);
	}

	public function getChecked()
	{
		$this->_checked = $this->getApplication()->getSession()->itemAt($this->_illCheckedSessionName);
		
		return $this->_checked;
	}

	public function resetDueDate()
	{
		$this->_dueDate = array();
		$this->setDueDate($this->_dueDate);
	}

	public function setDueDate($dueDate = null)
	{
		if (is_null($dueDate))
		{
			$dueDate = $this->_dueDate;
		}
		else
		{
			$this->_dueDate = $dueDate;
		}
		
		$this->getApplication()->getSession()->add($this->_dueDateSessionName, $dueDate);
	}

	public function getDueDate()
	{
		$this->_dueDate = $this->getApplication()->getSession()->itemAt($this->_dueDateSessionName);
		
		return $this->_dueDate;
	}

	public function setGlobalCriteria($criteria = null)
	{
		$this->setViewState($this->_globalCriteriaSessionName, $criteria, null);
	}

	public function getGlobalCriteria()
	{
		return SerializableCriteria::refreshCriteria($this->getViewState($this->_globalCriteriaSessionName, null));
	}

	/**
	 * Method which resets the datasource (also saves into session
	 * variable), the checked status, and re-populates everything.
	 *
	 */
	public function resetDataSource()
	{
		$this->resetCheckedItems();
		$this->resetDueDate();

		$this->_datasource = array();
		$this->FoundNumber->setText("");
		$this->SelectedNumber->setText("");
		$this->getApplication()->getSession()->add($this->_illFoundDatasourceSessionName, $this->_datasource);

		$this->resetSorting();
		$this->populate();
	}

	public function resetSorting()
	{
		$this->Grid->resetSorting('', null, false);
	}

	public function setContactFilter($contact)
	{
		$this->_contactFilter = $contact;
		$this->setViewState('contactFilter', $this->_contactFilter, null);
	}

	public function getContactFilter()
	{
		$this->_contactFilter = $this->getViewState('contactFilter', null);
		
		return $this->_contactFilter;
	}

	public function setPreferredContact($flag)
	{
		$this->_preferredContact = $flag;
		$this->setViewState('preferredContact', $this->_preferredContact, false);
	}

	public function getPreferredContact()
	{
		$this->_preferredContact = $this->getViewState('preferredContact', false);
		
		return $this->_preferredContact;
	}

	public function setContactBoolean($value)
	{
		$this->_contactBoolean = $value;
		$this->setViewState('contactBoolean', $this->_contactBoolean, true);
	}

	public function getContactBoolean()
	{
		$this->_contactBoolean = $this->getViewState('contactBoolean', true);
		
		return $this->_contactBoolean;
	}

	/**
	 * It returns whether an item, represented by the id passed
	 * as the parameter, is present in the loans datasource.
	 *
	 * @param int $itemId
	 * @return boolean
	 */
	private function searchIdIntoDatasource($itemId)
	{
		$dataSource = $this->getDatasource();
		
		foreach ($dataSource as $row)
		{
			if ($row['id'] == $itemId)
				return true;
		}
		
		return false;
	}

	public function searchCodesIntoDatasource($code = '')
	{
		$code = trim($code);
		
		if ($code == '')
			return array();

		$items = array();
		$criteria = $this->getGlobalCriteria();
		
		if (!is_null($criteria) 
				&& ($criteria instanceof Criteria))
			$items = ItemPeer::retrieveByDataInput($code, $criteria);

		$dueDateArray = $this->getDueDate();
		$result = array();
		
		foreach ($items as $item) 
		{
			$itemId = $item->getItemId();
		
			if (isset($dueDateArray[$itemId]))
			{
				$dueDate = $dueDateArray[$itemId];
			}
			else
			{
				$dueDate = $this->_loanmanager->CalculateDueDate($item);
			}

			$result[] = array(	'item' => $item,
								'dueDate' => $dueDate );
		}
		
		return $result;
	}

	/**
	 * It sets the filters altogether
	 *
	 * @param string $barcode
	 * @param int $paramLibraryId
	 * @param int $patronId
	 * @param int $outDateFrom
	 * @param int $outDateTo
	 * @param int $lastSeenDateFrom
	 * @param int $lastSeenDateTo
	 * @param boolean $extraSystem
	 */
	public function setFilters(	$barcode = null,
								$paramLibraryId,
								$patronId = null,
								$outDateFrom = null,
								$outDateTo = null,

								$lastSeenDateFrom = null,
								$lastSeenDateTo = null,
								$extraSystem = null,
								$contact = null,
								$preferredContact = false,

								$contactBoolean = true,
								$solicitCount = null)//,
								//$transitFilter = true,	// 13
								//$returnFilter = true)	// 14
	{
		if (trim($barcode) == '')
			$barcode = null;

		if ($paramLibraryId == 0)
			$paramLibraryId = null;

		if ($patronId == 0)
			$patronId = null;

		if ($outDateFrom == '')
			$outDateFrom = null;
		
		if ($outDateTo == '')
			$outDateTo = null;

		if ($lastSeenDateFrom == '')
			$lastSeenDateFrom = null;
		
		if ($lastSeenDateTo == '')
			$lastSeenDateTo = null;

		if (is_null($solicitCount))
			$solicitCount = -1;
				
		$this->setBarcode($barcode);
		$this->setparamLibraryId($paramLibraryId);
		$this->setPatronId($patronId);
		$this->setOutDateFrom($outDateFrom);
		$this->setOutDateTo($outDateTo);
		$this->setLastSeenDateFrom($lastSeenDateFrom);
		$this->setLastSeenDateTo($lastSeenDateTo);
		
		$this->setSolicitCount($solicitCount);

		if (is_string($extraSystem))
		{
			$value = strtolower($extraSystem);
		
			if ($value === 'true')
			{
				$extraSystem = true;
			}
			elseif ($value === 'false')
			{
				$extraSystem = false;
			}
		}

		$this->setExtraSystem($extraSystem);
		$this->setContactFilter($contact);
		$this->setPreferredContact($preferredContact);
		$this->setContactBoolean($contactBoolean);

//		$this->setTransitFilter($transitFilter);
//		$this->setReturnFilter($returnFilter);
		
		$this->resetPagination();
	}

	public function getDatasource()
	{
		if (is_null($this->_datasource))
			$this->_datasource = $this->getApplication()->getSession()->itemAt($this->_illFoundDatasourceSessionName);
		
		return $this->_datasource;
	}

	public function getItemsWithDueDate($force = false, $reset = false)
	{
		$checked = $this->getChecked();
		$dueDate = $this->getDueDate();

		$masterChecked = $checked['all'];
		unset($checked['all']);
		$checkedIds = array_keys($checked);
		$output = array();
		$outputItemId = array();

		if (!$masterChecked)
		{
			$outputItemId = $checkedIds;
		}
		else
		{ // caso del mastercheck inverso
			$criteria = $this->getGlobalCriteria();
			
			if (!is_null($criteria)
					&& ($criteria instanceof Criteria))
			{
				$criteria->clearSelectColumns()->addSelectColumn(ItemPeer::ITEM_ID);
				$stmt = ItemPeer::doSelectStmt($criteria);
				$items = $stmt->fetchAll(PDO::FETCH_COLUMN);
				$outputItemId = array_diff($items,$checkedIds);
			}
		}

		$output = array();
		
		if (isset($criteria))
		{
			$criteria->clear();
		}
		else
		{
			$criteria = new Criteria();
		}
		
		$criteria->add(ItemPeer::ITEM_ID, $outputItemId, Criteria::IN);

		$this->calculateSortingCriteria($criteria);
		$itemsArray = ItemPeer::doSelect($criteria);
		
		foreach ($itemsArray as $item)
		{
			$itemId = $item->getItemId();
			if (array_key_exists($itemId, $dueDate))
			{
				$dueDateOutput = $dueDate[$itemId];
			}
			else
			{
				$dueDateOutput = $this->_loanmanager->CalculateDueDate($item);
			}

			$output[] = array(	'item' => $item,
								'dueDate' => $dueDateOutput );
		}

		if ((count($output) == 0)
				&& ($force == true))
		{
			$this->resetCheckedItems(true);
			$output = $this->getItemsWithDueDate();
		
			if ($reset)
				$this->resetCheckedItems(false);
		}

		return $output;
	}

	public function getCheckedItemsItemId(	$force = false,
											$reset = false)
	{
		$checked = $this->getChecked();
		$dueDate = $this->getDueDate();

		$masterChecked = $checked['all'];
		unset($checked['all']);
		$checkedIds = array_keys($checked);
		$outputItemId = array();

		if (!$masterChecked)
		{
			$outputItemId = $checkedIds;
		}
		else
		{ // caso del mastercheck inverso
			$criteria = $this->getGlobalCriteria();
			
			if (!is_null($criteria)
					&& ($criteria instanceof Criteria))
			{
				$criteria->add(ItemPeer::ITEM_ID, $checkedIds, Criteria::NOT_IN);
				$items = ItemPeer::doSelect($criteria);

				foreach ($items as $item)
					$outputItemId[] = $item->getItemId();
			}
		}

		if ((count($outputItemId) == 0)
				&& ($force == true))
		{
			$this->resetCheckedItems(true);
			$outputItemId = $this->getCheckedItemsItemId();
		
			if ($reset)
				$this->resetCheckedItems(false);
		}

		return $outputItemId;
	}

	/**
	 * Retrieves the ITEM ID for the selected items.
	 *
	 * @param bool $force
	 * @param bool $reset
	 * @return
	 */
	public function getCheckedItemsLoanId(	$force = false,
											$reset = false)
	{
		$checked = $this->getChecked();
		$masterChecked = $checked['all'];
		unset($checked['all']);
		$checkedIds = array_keys($checked);

		$output = array();
		$criteria = new Criteria();
		
		if (!$masterChecked)
		{
			$criteria->add(ItemPeer::ITEM_ID, $checkedIds, Criteria::IN);
		}
		else
		{ // caso del mastercheck inverso
			$globalCriteria = $this->getGlobalCriteria();
		
			if ($globalCriteria instanceof Criteria)
			{
				$criteria = $globalCriteria;
				$criteria->add(ItemPeer::ITEM_ID, $checkedIds, Criteria::NOT_IN);
			}
			elseif (is_array($globalCriteria)
						&& (count($globalCriteria) > 0))
			{
				$criteria->add(ItemPeer::ITEM_ID, $globalCriteria, Criteria::IN);
			}
		}

		$criteria->clearSelectColumns()->addSelectColumn(ItemPeer::CURRENT_LOAN_ID);
		$output = ItemPeer::doSelectStmt($criteria)->fetchAll(PDO::FETCH_COLUMN, 0);

		if ((count($output) == 0) 
				&& ($force == true))
		{
			$this->resetCheckedItems(true);
			$output = $this->getCheckedItemsLoanId();
			
			if ($reset)
				$this->resetCheckedItems(false);
		}

		return $output;
	}

	public function countCheckedItems(	$force = false,
										$reset = false)
	{
		$checked = $this->getChecked();
		$masterChecked = $checked['all'];
		unset($checked['all']);
		$checkedIds = array_keys($checked);
		$output = 0;

		if (!$masterChecked)
		{
			$output = count($checkedIds);
		}
		else
		{ // caso del mastercheck inverso
			$globalCriteria = $this->getGlobalCriteria();
			
			if ($globalCriteria instanceof Criteria)
			{
				if (count($checkedIds) > 0)
					$globalCriteria->add(ItemPeer::ITEM_ID, $checkedIds, Criteria::NOT_IN);
			
				$output = ItemPeer::doCount($globalCriteria);
			}
			elseif (is_array($globalCriteria))
			{
				$output = count($globalCriteria);
			}
		}

		if (($output == 0)
				&& ($force == true))
		{
			$this->setMasterChecked(true);
			$output = $this->countCheckedItems();

			if ($reset)
				$this->setMasterClass(false);
		}

		return $output;
	}

	public function getSortingExpression()
	{
		return $this->Grid->getSortingExpression();
	}

	public function getSortingDirection()
	{
		return $this->Grid->getSortingDirection();
	}

	public function calculateSortingCriteria(&$sortingCriteria = null)
	{
		$sortingExpression = $this->getSortingExpression();
		$sortingDirection = $this->getSortingDirection();

		if (is_null($sortingCriteria)
				|| !($sortingCriteria instanceof Criteria))
			$sortingCriteria = new Criteria();

		switch ($sortingExpression)
		{
			case 'title':  // ShelfName
				$sortingCriteria->clearOrderByColumns();
				
				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
				{
					$sortingCriteria->addAscendingOrderByColumn(ItemPeer::TITLE);
				}
				elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
				{
					$sortingCriteria->addDescendingOrderByColumn(ItemPeer::TITLE);
				}
		
				break;

			case 'PatronColumn': // LibrarianName
				$sortingCriteria->clearOrderByColumns();
				
				if (!$this->getExtraSystem())
				{
					$sortingCriteria->addJoin(ItemPeer::PATRON_ID, PatronPeer::PATRON_ID, 'LEFT JOIN');
				
					if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
					{
						$sortingCriteria->addAscendingOrderByColumn(PatronPeer::LASTNAME);
						$sortingCriteria->addAscendingOrderByColumn(PatronPeer::NAME);
					}
					elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
					{
						$sortingCriteria->addDescendingOrderByColumn(PatronPeer::LASTNAME);
						$sortingCriteria->addDescendingOrderByColumn(PatronPeer::NAME);
					}
				}
				else
				{   // caso extra
					$sortingCriteria->addJoin(ItemPeer::EXTERNAL_LIBRARY_ID, LibraryPeer::LIBRARY_ID, 'LEFT JOIN');
				
					if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
					{
						$sortingCriteria->addAscendingOrderByColumn(LibraryPeer::LABEL);
					}
					elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
					{
						$sortingCriteria->addDescendingOrderByColumn(LibraryPeer::LABEL);
					}
				}

				break;

			case 'libraryId': // biblioteca

				$loanStatuses = $this->getLoanStatusMode();

				if ($this->_loanmanager->IsOutStatus($loanStatuses))
				{
					$sortingCriteria->clearOrderByColumns();
					$sortingCriteria->addJoin(ItemPeer::DELIVERY_LIBRARY_ID, LibraryPeer::LIBRARY_ID);
				
					if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
					{
						$sortingCriteria->addAscendingOrderByColumn(LibraryPeer::LABEL);
					}
					elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
					{
						$sortingCriteria->addDescendingOrderByColumn(LibraryPeer::LABEL);
					}
				}
				elseif (in_array(ItemPeer::LOANSTATUS_TOSHELF, $loanStatuses))
				{
					$sortingCriteria->clearOrderByColumns();
					$sortingCriteria->addJoin(ItemPeer::ACTUAL_LIBRARY_ID, LibraryPeer::LIBRARY_ID);
					$sortingCriteria->setDistinct();

					if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
					{
						$sortingCriteria->addAscendingOrderByColumn(LibraryPeer::LABEL);
					}
					elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
					{
						$sortingCriteria->addDescendingOrderByColumn(LibraryPeer::LABEL);
					}
				}
				elseif ($this->_loanmanager->IsInStatus($loanStatuses))
				{
					$sortingCriteria->clearOrderByColumns();
					$sortingCriteria->addJoin(ItemPeer::CURRENT_LOAN_ID,LoanPeer::LOAN_ID);
					$sortingCriteria->addJoin(LoanPeer::FROM_LIBRARY, LibraryPeer::LIBRARY_ID);
					$sortingCriteria->setDistinct();

					if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
					{
						$sortingCriteria->addAscendingOrderByColumn(LibraryPeer::LABEL);
					}
					elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
					{
						$sortingCriteria->addDescendingOrderByColumn(LibraryPeer::LABEL);
					}
				}

				break;

			case 'illTimeStamp':
				$sortingCriteria->clearOrderByColumns();

				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
				{
					$sortingCriteria->addAscendingOrderByColumn(ItemPeer::ILL_TIMESTAMP);
				}
				elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
				{
					$sortingCriteria->addDescendingOrderByColumn(ItemPeer::ILL_TIMESTAMP);
				}

				break;

			case 'lastSeen':  // ultimo movimento
				$sortingCriteria->clearOrderByColumns();

				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
				{
					$sortingCriteria->addAscendingOrderByColumn(ItemPeer::LAST_SEEN);
				}
				elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
				{
					$sortingCriteria->addDescendingOrderByColumn(ItemPeer::LAST_SEEN);
				}

				break;

			case 'collocationCombo':
				$sortingCriteria->clearOrderByColumns();

				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
				{
					$sortingCriteria->addAscendingOrderByColumn(ItemPeer::SECTION);
					$sortingCriteria->addAscendingOrderByColumn(ItemPeer::COLLOCATION);
					$sortingCriteria->addAscendingOrderByColumn(ItemPeer::SPECIFICATION);
					$sortingCriteria->addAscendingOrderByColumn(ItemPeer::SEQUENCE1);
					$sortingCriteria->addAscendingOrderByColumn(ItemPeer::SEQUENCE2);
				}
				elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
				{
					$sortingCriteria->addDescendingOrderByColumn(ItemPeer::SECTION);
					$sortingCriteria->addDescendingOrderByColumn(ItemPeer::COLLOCATION);
					$sortingCriteria->addDescendingOrderByColumn(ItemPeer::SPECIFICATION);
					$sortingCriteria->addDescendingOrderByColumn(ItemPeer::SEQUENCE1);
					$sortingCriteria->addDescendingOrderByColumn(ItemPeer::SEQUENCE2);
				}

				break;

			case 'notify_count':    // notification count
				$sortingCriteria->clearOrderByColumns();
				
				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
				{
					$sortingCriteria->addAscendingOrderByColumn(ItemPeer::NOTIFY_COUNT);
				}
				elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
				{
					$sortingCriteria->addDescendingOrderByColumn(ItemPeer::NOTIFY_COUNT);
				}
				
				break;

			case null:
				break;

			default:
				$sortingExpression = null;
				
				break;
		}
	}

	/**
	 * It populates the grid, and takes the four necessary filter
	 * parameters from given saved data, and eventual other filters
	 * (i.e. patron, which was passed through the "setObject()").
	 *
	 */
	public function populate()
	{
		/* @var $item Item */

		$this->getPage()->cleanMessageQueue();
		
		$barcode = $this->getBarcode();
		$paramLibraryId = intval($this->getParamLibraryId());
		$loanStatuses = $this->getLoanStatusMode();
		$patronId = $this->getPatronId();
		$outDateFrom = $this->getOutDateFrom();
		$outDateTo = $this->getOutDateTo();

		$lastSeenDateFrom = $this->getLastSeenDateFrom();
		$lastSeenDateTo = $this->getLastSeenDateTo();
		$extraSystem = $this->getExtraSystem();

		$solicitCount = $this->getSolicitCount();
		
		if (is_null($solicitCount))
		{
			$solicitCount = -1;
		}
		elseif ($solicitCount > 2)
		{
			$solicitCount = 3;
		}
		
		$contactFilter = $this->getContactFilter();
		$preferredContact = $this->getPreferredContact();
		$contactBoolean = $this->getContactBoolean();

		$actualLibraryId = $this->getUser()->getActualLibraryId();
		$actualLibrarianId = $this->getUser()->getId();

		$criteria = new Criteria();
		$direction = null;
		$dueDateFlag = false;
		$returnHomeFlag = false;
		$patronHeaderUpdate = true;

		if (count($loanStatuses) > 0) 
		{
			$criteria->addAnd(ItemPeer::LOAN_STATUS, $loanStatuses, Criteria::IN);

			if ($this->_loanmanager->IsOutStatus($loanStatuses)) 
			{
				$this->LastSeenColumn->setVisible(true);

				if ($paramLibraryId > 0)
					$criteria->addAnd(ItemPeer::DELIVERY_LIBRARY_ID, $paramLibraryId);

				/**
				 * Method TClavisDataGrid::resetSorting() is used when we want to order
				 * by a some specific way which has a corrispondent in the SortExpression
				 * property in the template.
				 * I.e.: in this template we have a column describing a library, and its
				 * SortExpression (in the template) is "libraryId".
				 *
				 * The second parameter is the sort direction.
				 *
				 * The optional third (defaulted to true) means: this ordering
				 * is authoritative: it is effectively used.
				 * When passed as false, and another SortingExpression is already set in the
				 * grid, then this instruction gets ignored.
				 */
				$this->Grid->resetSorting('lastSeen', null, false);	// #1094
				$criteria->add(ItemPeer::ACTUAL_LIBRARY_ID, $actualLibraryId);

				/**
				 * This is needed when we want to change dinamically a column label,
				 * php-side, but don't want to change the sorting image (little direction
				 * arrow...)
				 */
				$this->Grid->substituteHeaderText($this->LibraryColumn, Prado::localize("biblioteca d'arrivo"));
				$direction = 'out';

				if (count(array_intersect(array(ItemPeer::LOANSTATUS_READYFORTRANSITTOHOME), $loanStatuses)) > 0) 
				{
					$this->Grid->substituteHeaderText($this->PatronColumn, Prado::localize("destinato a"));
					$patronHeaderUpdate = false;
					$returnHomeFlag = true;
				}
			} 
			elseif ($this->_loanmanager->IsInStatus($loanStatuses)) 
			{
				$this->LastSeenColumn->setVisible(true);
			
				if ($paramLibraryId > 0)
				{
					if (in_array(ItemPeer::LOANSTATUS_READYFORLOAN, $loanStatuses)) 
					{
						$criteria->addJoin(LoanPeer::LOAN_ID, ItemPeer::CURRENT_LOAN_ID);

						$criterion_A = $criteria->getNewCriterion(LoanPeer::LOAN_TYPE, ItemPeer::LOANTYPE_EXTRASYSTEM);
						$criterion_A2 = $criteria->getNewCriterion(ItemPeer::OWNER_LIBRARY_ID, $paramLibraryId);
						$criterion_A->addAnd($criterion_A2);

						$criterion_B = $criteria->getNewCriterion(LoanPeer::LOAN_TYPE, ItemPeer::LOANTYPE_EXTRASYSTEM, Criteria::NOT_EQUAL);
						$criterion_B2 = $criteria->getNewCriterion(LoanPeer::FROM_LIBRARY, $paramLibraryId);
						$criterion_B->addAnd($criterion_B2);

						$criterion_A->addOr($criterion_B);
						$criteria->add($criterion_A);
					}
					else
					{
						$criteria->addAnd(ItemPeer::ACTUAL_LIBRARY_ID, $paramLibraryId);
					}
				}

				$this->Grid->resetSorting('lastSeen', null, false);

				$criteria->addAnd(ItemPeer::DELIVERY_LIBRARY_ID, $actualLibraryId);
				$direction = 'in';
				$this->Grid->substituteHeaderText($this->LibraryColumn, Prado::localize("biblioteca di partenza"));

				if (in_array(ItemPeer::LOANSTATUS_TOSHELF, $loanStatuses))
					$this->PatronColumn->setVisible(false);

				if (in_array(ItemPeer::LOANSTATUS_READYFORLOAN, $loanStatuses))
					$dueDateFlag = true;
			}
		} 
		else 
		{
			$this->Grid->resetSorting('illTimeStamp', null, false);
			
			if ($paramLibraryId > 0)
				$criteria->addAnd(ItemPeer::DELIVERY_LIBRARY_ID, $paramLibraryId);
		}

		if ($patronHeaderUpdate)
		{
			if ($this->Page->getPagePath() == 'Circulation.AlienLoanPage')
			{
				$this->Grid->substituteHeaderText($this->PatronColumn, Prado::localize('biblioteca esterna destinataria'));
			}
			else
			{	
				$this->Grid->substituteHeaderText($this->PatronColumn, Prado::localize('utente'));
			}
		}

		$this->DueDateColumn->setVisible($dueDateFlag);
		$activeFilter = $this->getActiveFilter();

		if (!is_null($activeFilter)) 
		{
			switch ($activeFilter) 
			{
				case 'Active':
					$criteria->addAnd(ItemPeer::LOAN_STATUS, ItemPeer::getLoanStatusActive(), Criteria::IN);
					
					break;
				
				case 'Inactive':
					$criteria->addAnd(ItemPeer::LOAN_STATUS, ItemPeer::getLoanStatusInactive(), Criteria::IN);
				
					break;
			}
		}

		$currentIndexPage = $this->Grid->getCurrentPage();
		$pageSize = $this->Grid->getPageSize();

		if ($outDateFrom !== null)
			$criteria->addAnd(ItemPeer::ILL_TIMESTAMP, $outDateFrom, Criteria::GREATER_EQUAL);
		
		if ($outDateTo)
			$criteria->addAnd(ItemPeer::ILL_TIMESTAMP, $outDateTo + 86399, Criteria::LESS_EQUAL);

		if ($lastSeenDateFrom !== null)
			$criteria->addAnd(ItemPeer::LAST_SEEN, $lastSeenDateFrom, Criteria::GREATER_EQUAL);
		
		if ($lastSeenDateTo)
			$criteria->addAnd(ItemPeer::LAST_SEEN, $lastSeenDateTo + 86399, Criteria::LESS_EQUAL);

		if ($barcode != '') 
		{
			$barcodeItems = ItemPeer::retrieveByDataInput($barcode);
		
			if (!is_null($barcodeItems)
					&& (count($barcodeItems) > 0)) 
			{
				$barcodeItemIds = array();
				
				foreach ($barcodeItems as $it)
					$barcodeItemIds[] = $it->getItemId();
				
				$criteria->addAnd(ItemPeer::ITEM_ID, $barcodeItemIds, Criteria::IN);
			}
			else
			{
				$criteria->addAnd(ItemPeer::ITEM_ID, -1);
				
				$this->getPage()->enqueueMessage(Prado::localize("La ricerca per barcode/inventario non ha trovato esemplari"),
													ClavisMessage::INFO);
			}
		}

		if ($extraSystem === true) 
		{
			$criteria->addAnd(ItemPeer::PATRON_ID, null, Criteria::ISNULL);
			$criteria->addAnd(ItemPeer::EXTERNAL_LIBRARY_ID, null, Criteria::ISNOTNULL);
		} 
		else 
		{   // caso normale, non extra
			if ($extraSystem === false)
				$criteria->addAnd(ItemPeer::EXTERNAL_LIBRARY_ID, null, Criteria::ISNULL);

			if (!is_null($patronId))
				$criteria->addAnd(ItemPeer::PATRON_ID, $patronId);

			$object = $this->getObject();
			
			if (!is_null($object)) 
			{
				switch (get_class($this->_object)) 
				{
					case 'Patron':
						$this->PatronColumn->setVisible(false);
						$criteria->addAnd(ItemPeer::PATRON_ID, $object->getId());
				
						break;
				}
			}
		}

		if (-1 == $solicitCount)
		{
			// dummy
		}
		elseif (($solicitCount >= 0)
					&& ($solicitCount < 3))
		{
			$criteria->addAnd(ItemPeer::NOTIFY_COUNT, $solicitCount);
		}
		elseif ($solicitCount >= 3)
		{
			$criteria->addAnd(ItemPeer::NOTIFY_COUNT, $solicitCount, Criteria::GREATER_EQUAL);
		}
				
		if ($contactFilter) 
		{
			$criteria->addJoin(ItemPeer::PATRON_ID, ContactPeer::PATRON_ID, Criteria::LEFT_JOIN);
			$criteria->setDistinct();
			
			if ($contactBoolean) 
			{
				$criteria->addAnd(ContactPeer::CONTACT_TYPE, $contactFilter);

				if ($preferredContact)
					$criteria->addAnd(ContactPeer::CONTACT_PREF, '1');
			}
			else 
			{
				if ($preferredContact)
				{
					$contactPrefQuery = ' AND ' . ContactPeer::CONTACT_PREF . ' = \'1\' ';
				}
				else
				{
					$contactPrefQuery = '';
				}

				$criteria->addAnd(ContactPeer::CONTACT_TYPE, ContactPeer::PATRON_ID . ' NOT IN (SELECT DISTINCT ' .
					ContactPeer::PATRON_ID . ' FROM ' . ContactPeer::TABLE_NAME . ' INNER JOIN ' .
					ItemPeer::TABLE_NAME . ' ON (' . ContactPeer::PATRON_ID . '=' . ItemPeer::PATRON_ID .
					') WHERE ' . ContactPeer::CONTACT_TYPE . " = '{$contactFilter}' {$contactPrefQuery})", Criteria::CUSTOM);
			}
		}

		$this->calculateSortingCriteria($criteria);
		$this->setGlobalCriteria(clone($criteria));

		$loanCount = ItemPeer::doCount($criteria);
		$criteria->setLimit($pageSize);
		$criteria->setOffset($currentIndexPage * $pageSize);

		$items = ItemPeer::doSelectJoinManifestation($criteria);

		$this->_checked = $this->getChecked();
		$masterChecked = $this->_checked['all'];

		$todayTimestamp = mktime(1, 0, 0);
		$waitingDelta = $this->_loanmanager->CalculateWaitingDelta($actualLibraryId, $actualLibrarianId);
		
		if (is_null($waitingDelta)) 
		{
			$waitingDelta = 0;
			$this->getPage()->enqueueMessage(Prado::localize('Attenzione: nel database non esiste il parametro di sistema che definisce il valore massimo dei giorni di giacenza dei pronti al prestito. Riportare al fornitore del software.'),
												ClavisMessage::ERROR);
		}

		$datasource = array();
		
		foreach ($items as $item) 
		{
			$itemExternal = $item->isExternal();
			$itemId = $item->getId();
			$loan = $item->getCurrentLoan();
			$lastSeen = $item->getLastSeen('U');

			if (isset($this->_checked[$itemId]))
			{
				$checked = $this->_checked[$itemId];
			}
			else
			{
				$checked = false;
			}

			if ($masterChecked)
				$checked = !$checked;

			$dueDate = null;
			$waitingNumber = null;
			$exceedWaiting = false;
			
			if ($dueDateFlag)
			{
				if (isset($this->_dueDate[$itemId])) 
				{
					$dueDate = $this->_dueDate[$itemId];
				} 
				else 
				{
					$dueDate = $this->_loanmanager->CalculateDueDate($item);
					$this->_dueDate[$itemId] = $dueDate;
				}
				
				$waitingNumber = 0;
				
				if ($lastSeen) 
				{
					$waitingNumber = floor(($todayTimestamp - $lastSeen) / self::DAYTIMESTAMP);
					$exceedWaiting = ($waitingNumber > $waitingDelta);
				}
			}
			
			$itemLoanStatus = $item->getLoanStatus();

			if ($direction === 'out')
			{
				$libraryId = $item->getDeliveryLibraryId();
			}
			elseif ($direction === 'in')
			{
				if ($itemExternal)
				{
					$libraryId = $item->getOwnerLibraryId();
				}
				else
				{
					if (($loan instanceof Loan)
							&& in_array($loan->getLoanStatus(), ItemPeer::getLoanStatusActive()))
					{
						$libraryId = $loan->getFromLibrary();
					}
					else
					{
						$libraryId = $item->getActualLibraryId();
					}
				}
			}
			else
			{
				$libraryId = 0;
			}

			$toolTip = '';
			$patronInactiveFlag = "";
			
			if ($itemLoanStatus == ItemPeer::LOANSTATUS_READYFORTRANSITTOHOME) 
			{
				$patronId = 0;
				$patronCompleteName = Prado::localize('in rientro');
				$navigateUrl = '';
			} 
			else 
			{
				$canLoan = false;
				$patron = $item->getPatron();
				
				if ($patron instanceof Patron) 
				{
					$patronCompleteName = $patron->getCompleteName();
					
					if ($patron->isNonActive())
						$patronInactiveFlag = true;

					$navigateUrl = "index.php?page=Circulation.PatronViewPage&id=" . $patron->getPatronId();
					$canLoan = ($this->_loanmanager->IsPatronAllowedToLoan($patron, $itemId) == ClavisLoanManager::OK);
				} 
				else 
				{
					$externalLibraryId = $item->getExternalLibraryId();
					$externalLibrary = LibraryQuery::create()->findPk($externalLibraryId);

					if ($externalLibrary instanceof Library) 
					{
						$patronCompleteName = $externalLibrary->getLabel(true, false, true, 30);
						$navigateUrl = "index.php?page=Library.LibraryViewPage&id=" . $externalLibrary->getLibraryId();
						$toolTip = $externalLibrary->getTrimmedDescription(100) . ' (' . Prado::localize('consorzio') . ": " . $externalLibrary->getConsortiaString(100) . ')';
						$canLoan = ($this->_loanmanager->isExternalLibraryAllowedToLoan($externalLibraryId) == ClavisLoanManager::OK);
					} 
					else 
					{
						$patronCompleteName = "(" . Prado::localize("senza nome") . ")";
						$navigateUrl = '';
					}
				}
			}
			
			$title = trim($item->getTitle(true));
			
			if (!$title)
				$title = Prado::localize('(senza titolo)');
			
			$collCombo = trim($item->getCollocationCombo($actualLibraryId));
			
			if (!$collCombo)
				$collCombo = '---';
			
			$manageRequestParam = "";
			
			if ($this->getManageRequests()
					&& ($itemLoanStatus == ItemPeer::LOANSTATUS_READYFORTRANSITTOHOME))
			{
				$isRequestedFlag = $this->_requestmanager->countRequests(	$actualLibraryId,
																			null,
																			$itemId,
																			null,
																			true) > 0;
				
				if ($isRequestedFlag)
					$manageRequestParam = serialize(array(0, 1, $itemId));
			}

			$datasource[] = array(	'checked' => $checked,
									'id' => $itemId,
									'title' => $title,
									'loanStatus' => $itemLoanStatus,
									'loanStatusString' => $item->getLoanStatusString(),
				
									'libraryId' => $libraryId,
									'libraryLabel' => LibraryPeer::getLibraryLabel($libraryId, '---'),
									'patronId' => $patronId,
									'patronCompleteName' => $patronCompleteName,
									'patronNavigateUrl' => $navigateUrl,
				
									'patronNavigateUrlToolTip' => $toolTip,
									'patronInactiveFlag' => $patronInactiveFlag,
									'illTimestamp' => $item->getIllTimestamp('U'),
									'lastSeen' => $lastSeen,
									'waiting' => $waitingNumber,
				
									'inventoryNumber' => $item->getCompleteInventoryNumber(),
									'dueDate' => $dueDate,
									'exceedWaiting' => $exceedWaiting,
									'collocationCombo' => $collCombo,
									'barcode' => $item->getBarcode(),
				
									'notify_count' => $item->getNotifyCount(),
									'manageRequestParam' => $manageRequestParam );
		}

		$this->setChecked($this->_checked);
		$this->setDueDate($this->_dueDate);

		$this->_datasource = $datasource;
		$this->getApplication()->getSession()->add($this->_illFoundDatasourceSessionName, $this->_datasource);
		$this->Grid->setVirtualItemCount($loanCount);
		$this->Grid->setDataSource($this->_datasource);
		$this->Grid->dataBind();
		$this->FoundNumber->setText($loanCount);
		
		$this->getPage()->flushMessage();
	}

	public function onDataBound($sender, $param)
	{
		$item = $param->Item;

		if (($item->getItemType() == "Item") 
				|| ($item->getItemType() == "AlternatingItem"))
		{
			if ($item->DataItem['manageRequestParam'] != "")
				$item->setCssClass('evidenced_red');
		}					
	}
	
	public function changePage($sender, $param)
	{
		$this->Grid->SetCurrentPage($param->NewPageIndex);
		$this->populate();
	}

	/**
	 * Are we inside a popup?
	 *
	 * @return boolean
	 */
	public function getPopupFlag()
	{
		return $this->getPage()->IsPopup();
	}

	/**
	 * Resets the datagrid's pagination (first page).
	 *
	 */
	public function resetPagination()
	{
		$this->Grid->SetCurrentPage(0);
	}

	/**
	 * It changes the status (on/off) of the checkbox of one chosen
	 * row item of datagrid.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onFlipChecked($sender, $param)
	{
		$checked = $this->getChecked();
		$newStatus = $sender->getChecked();

		$index = $sender->Parent->Parent->ItemIndex;
		$dataSource = $this->getDatasource();

		$row = $dataSource[$index];
		$itemId = $row['id'];

		if ($newStatus != $checked['all'])
		{
			$checked[$itemId] = true;
		}
		else
		{
			unset($checked[$itemId]);
		}

		$this->setChecked($checked);
		$this->updateEmptyFlag($param);
	}

	public function onMasterChecked($sender, $param)
	{
		$newStatus = $sender->getChecked();
		$this->resetCheckedItems($newStatus);
		$gridItems = $this->Grid->getItems();
		
		foreach ($gridItems as $item)
			$item->CheckColumn->Checked->setChecked($newStatus);
		
		$this->updateEmptyFlag($param);
	}

	public function updateEmptyFlag($param = null)
	{
		$count = intval($this->countCheckedItems());
		$this->SelectedNumber->setText($count);

		if ($this->getPage()->getIsCallback())
		{	
			$this->SelectedPanel->render(is_null($param)
											? $this->getPage()->createWriter()
											: $param->getNewWriter());
		}
	}
	
	public function onChangeDueDate($sender, $param)
	{
		$index = $sender->Parent->Parent->ItemIndex;
		$dueDate = $sender->Parent->DueDate->getTimeStamp();

		if ($dueDate < time()) 
		{
			$this->getPage()->writeMessage(Prado::localize("ERRORE: data di rientro minore di quella corrente"),
												ClavisMessage::ERROR);
			
			return false; // da sistemare
		}
		
		$dataSource = $this->getDatasource();
		$row = $dataSource[$index];
		$itemId = $row['id'];
		$this->_dueDate[$itemId] = $dueDate;
		$this->setDueDate();
		$item = ItemQuery::create()->findPk($itemId);
		
		if (!($item instanceof Item)) 
		{
			$this->getPage()->writeMessage(Prado::localize("Errore: non c'è nessun esemplare con id = {itemId}",
																array('itemId' => $itemId)),
												ClavisMessage::ERROR);
			
			return false;
		}
		
		$this->getPage()->writeMessage(Prado::localize("Data di restituzione dell'esemplare '{title} [barcode: {barcode}] cambiata al {newDate}'",
																array(	'title' => $item->getTrimmedTitle(40, '/'),
																		'barcode' => $item->getBarcode(),
																		'newDate' => strftime('%x', $dueDate) )),
											ClavisMessage::INFO);

		$item->setDueDate($dueDate);
		$item->save();

		$currentLoanId = intval($item->getCurrentLoanId());
		
		if ($currentLoanId > 0) 
		{
			$loan = LoanQuery::create()->findPk($currentLoanId);
		
			if ($loan instanceof Loan) 
			{
				$loan->setDueDate($dueDate);
				$loan->save();
			}
		}
	}

	public function globalRefresh()
	{
		$this->resetSorting();
		$this->populate();
	}

	public function setMasterChecked($newChecked = false, $param = null)
	{
		$this->resetCheckedItems($newChecked);
		$gridItems = $this->Grid->getItems();
		$header = $this->Grid->getHeader();

		foreach ($gridItems as $item)
			$item->CheckColumn->Checked->setChecked($newChecked);

		$header->CheckColumn->MasterCheck->setChecked($newChecked);
	}

}