<?php
/**
 * ClavisAuthorityList class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Ciro Mattia Gonano
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.8.8
 * @package Widgets
 */

/**
 * ClavisAuthorityList Class
 *
 * @author Ciro Mattia Gonano
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.8.8
 * @package Widgets
 * @since 2.1
 */
class ClavisAuthorityList extends TTemplateControl
{
	private $_search;
	public  $_masterChecked;
	private $_checked = array('all' => false);
	private $_checkedSessionName;
	private $_datasource;
	private $_datasourceSessionName;
	private $_globalCriteriaSessionName;
	public  $_onlySelectedSessionName;
	private $_givenIdsCriteria;
	public  $_givenIdsCriteriaSessionName;

	private function initVars()
	{
		$uniqueId = $this->getUniqueID();
		$this->_checkedSessionName = 'CheckedSessionName' . $uniqueId;
		$this->_datasourceSessionName = 'DatasourceSessionName' . $uniqueId;
		$this->_globalCriteriaSessionName = 'GlobalCriteriaSessionName' . $uniqueId;
		$this->_onlySelectedSessionName = 'OnlySelectedSessionName' . $uniqueId;
	}

	public function onInit($param)
	{
		parent::onInit($param);
		$this->initVars();

		$this->_checked = $this->getChecked();
		$this->_masterChecked = $this->_checked['all'];
	}

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsPostBack()
				&& !$this->getPage()->getIsCallBack())
		{
			if ($this->getSearch())
				$this->SortTextFilter->setText($this->getSearch());

			$this->AuthorityGrid->resetPagination();

			if ($this->FoundNumber->getText() === '')
			{
				$populateFlag = true;
			}
			else
			{
				$populateFlag = false;
			}

			$this->resetDataSource($populateFlag);
			$this->getPage()->setFocus($this->SortTextFilter->getClientID());
		}
	}

	public function setSearch($search)
	{
		$this->_search = strip_tags($search);
	}

	public function getSearch()
	{
		return $this->_search;
	}

	public function setCanErase($param)
	{
		$param = TPropertyValue::ensureBoolean($param);
		$this->setViewState('CanErase', $param, false);
	}

	public function getCanErase()
	{
		return $this->getViewState("CanErase", false);
	}

	public function setEnableFilters($value = true)
	{
		$value = TPropertyValue::ensureBoolean($value);
		$this->setControlState('EnableFilters', $value, true);
	}

	public function getEnableFilters()
	{
		return $this->getControlState('EnableFilters', true);
	}

	public function setForcedType($value)
	{
		$this->setControlState('ForcedType',$value);
	}

	public function getForcedType()
	{
		return $this->getControlState('ForcedType',null);
	}

	/**
	 * Determines the control on subjects on authority retrieval:
	 * 'include': includes subjects on search (i.e. normal behaviour)
	 * 'exclude': excludes subjects from search
	 * 'only': search only among subjects.
	 *
	 * @param string $value The subject control type ('include','exclude','only')
	 */
	public function setSubjectControl($value)
	{
		$this->setControlState(	'SubjectControl',
								TPropertyValue::ensureEnum(	$value,
															array('only','include','exclude')),
								'include');
	}

	public function getSubjectControl()
	{
		return $this->getControlState('SubjectControl','include');
	}

	public function setEnablePagination($enablePagination = 'true')
	{
		$this->setViewState("EnablePagination", $enablePagination, 'true');
	}

	public function getEnablePagination()
	{
		$flag = $this->getViewState("EnablePagination", 'true');
		switch ($flag)
		{
			case 'true':
				$enablePagination = true;
				
				break;

			case 'false':
				$enablePagination = false;
				
				break;

			default:
				$enablePagination = true;
		}

		return $enablePagination;
	}

	public function resetGivenIdsCriteria($criteria = null)
	{
		$this->setGivenIdsCriteria($criteria);
	}

	public function setGivenIdsCriteria($criteria = null)
	{
		$this->getApplication()->getSession()->add($this->_givenIdsCriteriaSessionName, $criteria, null);
	}

	public function getGivenIdsCriteria()
	{
		$this->_givenIdsCriteria = $this->getApplication()->getSession()->itemAt($this->_givenIdsCriteriaSessionName, null);
		
		return $this->_givenIdsCriteria;
	}

	public function setMultiSelect($value)
	{
		$this->setControlState('MultiSelect',$value,false);
	}
	
	public function getMultiSelect()
	{
		return $this->getControlState('MultiSelect',false);
	}

	/**
	 *
	 * @param string $value The Link class, WITHOUT ending Peer.
	 */
	public function setLinkClass($value)
	{
		$this->setControlState('LinkClass',$value,null);
	}
	
	public function getLinkClass()
	{
		return $this->getControlState('LinkClass',null);
	}

	public function setLinkCriteria(Criteria $value)
	{
		$this->setControlState('LinkCriteria',$value,null);
	}
	
	public function getLinkCriteria()
	{
		return $this->getControlState('LinkCriteria',null);
	}

	public function resetChecked($state = false)
	{
		$this->setChecked(array('all' => $state));
	}

	public function setChecked($checked = null)
	{
		$this->_checked = $checked;
		$this->getApplication()->getSession()->add($this->_checkedSessionName, $checked);
	}

	public function getChecked()
	{
		$this->_checked = $this->getApplication()->getSession()->itemAt($this->_checkedSessionName);
	
		return $this->_checked;
	}

	public function setGlobalCriteria($criteria = null)
	{
		$this->getApplication()->getSession()->add($this->_globalCriteriaSessionName, $criteria, null);
	}

	public function getGlobalCriteria()
	{
		return SerializableCriteria::refreshCriteria($this->getApplication()->getSession()->itemAt($this->_globalCriteriaSessionName, null));
	}

	public function resetOnlySelected($value = false)
	{
		$this->setOnlySelected($value);
		$this->OnlySelectedCheck->setChecked($value);
		$this->SelectedNumber->setText('0');
	}

	public function setOnlySelected($flag = false)
	{
		if ($flag === 'false')
			$flag = false;

		if ($flag === 'true')
			$flag = true;

		$this->getApplication()->getSession()->add($this->_onlySelectedSessionName, $flag, false);
	}

	public function getOnlySelected()
	{
		$flag = $this->getApplication()->getSession()->itemAt($this->_onlySelectedSessionName);

		return $flag;
	}

	public function resetDataSource($populateFlag = true)
	{
		$this->resetChecked();
		$this->resetOnlySelected();
		$this->resetGivenIdsCriteria();
		$this->setDataSource(array());
		$this->resetSorting();

		if ($populateFlag)
			$this->populate();
	}

	public function getDatasource()
	{
		$this->_datasource = $this->getApplication()->getSession()->itemAt($this->_datasourceSessionName, null);

		return $this->_datasource;
	}

	public function setDataSource($ds)
	{
		$this->_datasource = $ds;
		$this->getApplication()->getSession()->add($this->_datasourceSessionName, $this->_datasource, null);
	}

	public function getCheckedIds($force = false)
	{
		$results = array();
		$checked = $this->getChecked();
		$masterChecked = $checked['all'];
		unset($checked['all']);
		$checkedIds = array_keys($checked);

		$output = array();

		if (!$masterChecked)
		{
			$output = $checkedIds;
		}
		else	// caso del mastercheck inverso
		{
			$criteria = $this->getGlobalCriteria();
			
			if (!is_null($criteria))
			{
				if ($criteria instanceof Criteria)
				{
					$criteria->add(AuthorityPeer::AUTHORITY_ID, $checkedIds, Criteria::NOT_IN);
					$authorities = AuthorityPeer::doSelect($criteria);

					foreach ($authorities as $authority)
						$output[] = $authority->getAuthorityId();
				}
				elseif (is_array($criteria)
							&& (count($criteria) > 0))		// we are getting criteria made for solr
				{
					if (array_key_exists('query', $criteria)
							&& array_key_exists('params', $criteria))
					{
						$solr = $this->getApplication()->getModule("search");
						
						$auths = $solr->searchAuthority(	implode(" AND ", $criteria['query']),
															0,
															5000,
															'',
															$criteria['params']);

						if (isset($auths['response']))
						{
							$allIds = array();
							
							foreach ($auths['response']['docs'] as $doc)
								$allIds[] = $doc['Id'];
							
							$output = array_diff($allIds, $checkedIds);
						}
					}
				}
			}
		}

		if ((count($output) == 0)
				&& ($force == true))
		{
			$this->setMasterChecked(true);
			$output = $this->getCheckedIds();
		}

		return $output;
	}

	public function countCheckedIds($force = false)
	{
		$results = array();
		$checked = $this->getChecked();
		$masterChecked = $checked['all'];
		unset($checked['all']);
		$checkedIds = array_keys($checked);
		$output = 0;

		if (!$masterChecked)
		{
			$output = count($checkedIds);
		}
		else	// caso del mastercheck inverso
		{
			$criteria = $this->getGlobalCriteria();
			
			if (!is_null($criteria))
			{
				if ($criteria instanceof Criteria)
				{
					$criteria->add(AuthorityPeer::AUTHORITY_ID, $checkedIds, Criteria::NOT_IN);
					$output = AuthorityPeer::doCount($criteria);
				}
				elseif (is_array($criteria)
							&& (count($criteria) > 0))		// we are getting criteria made for solr
				{
					if (array_key_exists('query', $criteria)
							&& array_key_exists('params', $criteria))
					{
						$solr = $this->getApplication()->getModule("search");
						
						$auths = $solr->searchAuthority(	implode(" AND ", $criteria['query']),
															0,
															5000,
															'',
															$criteria['params']);

						if (isset($auths['response']))
						{
							$allIds = array();
							
							foreach ($auths['response']['docs'] as $doc)
								$allIds[] = $doc['Id'];
							
							$output = count(array_diff($allIds, $checkedIds));
						}
					}
				}
			}
		}
		
		return $output;
	}

	public function getMasterChecked()
	{
		$checked = $this->getChecked();
		
		return $checked['all'];
	}

	public function onOnlySelected($sender, $param)
	{
		$checked = $sender->getChecked();
		$this->setOnlySelected($checked);

		$this->AuthorityGrid->resetPagination();
		$this->populate();
	}

	public function onFlipChecked($sender, $param)
	{
		$newChecked = $sender->getChecked();
		$index = $sender->Parent->Parent->ItemIndex;
		$dataSource = $this->getDatasource();
		$checked = $this->getChecked();

		$row = $dataSource[$index];
		$id = $row['AuthorityID'];

		if ($newChecked != $checked['all'])
		{
			$checked[$id] = true;
		}
		else
		{
			unset($checked[$id]);
		}

		$this->setChecked($checked);
		$this->updateEmptyFlag($param);
	}

	public function onMasterChecked($sender, $param)
	{
		$this->setMasterChecked($sender->getChecked(), $param);
	}

	public function setMasterChecked($newChecked = false, $param = null)
	{
		$this->resetChecked($newChecked);
		$this->resetGivenIdsCriteria();

		$gridItems = $this->AuthorityGrid->getItems();
		$header = $this->AuthorityGrid->getHeader();

		foreach($gridItems as $item)
			$item->CheckColumn->CheckedBox->setChecked($newChecked);

		$header->CheckColumn->MasterCheck->setChecked($newChecked);
		$this->updateEmptyFlag($param);
	}

	public function updateEmptyFlag($param = null)
	{
		$count = intval($this->countCheckedIds());
		$this->SelectedNumber->setText($count);
		$this->SelectReplacement->setEnabled($count==1);

		if ($this->getPage()->getIsCallback()
				&& !is_null($param))
			$this->SelectedPanel->render($param->getNewWriter());
	}

	public function searchAuthority($sender, $param)
	{
		$this->setControlState('searchList', false);
		$this->AuthorityGrid->setCurrentPage(0);
		$this->resetDataSource();
	}

	public function searchList($sender, $param)
	{
		$this->clearFilters();
		$this->setControlState('searchList', true);
		$this->AuthorityGrid->setCurrentPage(0);
		$this->resetDataSource();
	}

	public function calculateSortingCriteria(AuthorityQuery &$query = null)
	{
		$sortingExpression = $this->AuthorityGrid->getSortingExpression();
		$sortingDirection = $this->AuthorityGrid->getSortingDirection();

		switch ($sortingExpression)
		{
			case 'Title':
				$query->addAscendingOrderByColumn('REPLACE('.AuthorityPeer::SORT_TEXT.',\'*\',\'\') ');
				
				break;

			case 'AuthorityType':
				$query->orderByAuthorityType($sortingDirection);
				
				break;

			case 'TypeSpec':
				$query->orderByAuthoritySubtype($sortingDirection);
				$query->orderByClassCode($sortingDirection);
				$query->orderBySubjectClass($sortingDirection);
				
				break;

			case null:
				break;

			default:
				$sortingExpression = null;
		}

		return $query;
	}

	public function populate($givenIds = null) 
	{
		if ($v = $this->getForcedType()) 
		{
			$this->TypeFilter->setSelectedValue($v);
			$this->TypeFilter->setEnabled(false);
		}
		
		switch ($this->getSubjectControl()) 
		{
			case 'only':
				$it = $this->TypeFilter->getItems()->findItemByValue(AuthorityPeer::TYPE_SUBJECT);
				if (!is_null($it))
					$it->setEnabled(true);

				$this->TypeFilter->setSelectedValue(AuthorityPeer::TYPE_SUBJECT);
				$this->SubtypeFilter->setSelectedIndex(0);
				$this->TypeFilter->setEnabled(false);
				$this->SubtypeFilter->setEnabled(false);
				
				break;
				
			case 'exclude':
				$it = $this->TypeFilter->getItems()->findItemByValue(AuthorityPeer::TYPE_SUBJECT);
				if (!is_null($it))
					$it->setEnabled(false);

				$this->TypeFilter->setEnabled(true);
				
				break;
				
			default:
				$it = $this->TypeFilter->getItems()->findItemByValue(AuthorityPeer::TYPE_SUBJECT);
				if (!is_null($it))
					$it->setEnabled(true);

				$this->TypeFilter->setEnabled(true);
		}

		$this->populateAuthorityGrid($givenIds);
	}


    public function populateAuthorityGrid($givenIds = null)
    {
        /** @var SolrSearch $solr */
        $solr = $this->getApplication()->getModule("search");

        $pageSize = $this->AuthorityGrid->getPageSize();
        $currentPage = $this->AuthorityGrid->getCurrentPage();

        if ($this->getOnlySelected())
            $givenIds = $this->getCheckedIds();

        $givenIdsFlag = count($givenIds) > 0;
        if ($givenIdsFlag)
        {
            $recCount = count($givenIds);
            $givenIds = array_slice($givenIds, $pageSize * $currentPage, $pageSize);
            $authorities = array();
			
            foreach ($givenIds as $cicleId)
				$authorities[] = AuthorityQuery::create()->findPk($cicleId);
        }
		else
		{
			if (($c = $this->getLinkCriteria()) instanceof Criteria)
			{
				$authorities = array();
				$recCount = 0;

				/* retrieves the Peer class to use from LinkClass parameter.
				 * If false, throw Exception (we cannot have a LinkCriteria without
				 * knowing which LinkClass is involved). */
				$lclass = $this->getLinkClass() . 'Peer';

				if (!class_exists($lclass))
					throw new Exception("Cannot specify LinkCriteria without a LinkClass");

				if ($lclass == 'LAuthority')
					throw new Exception("Please, use ClavisAuthorityLinkAuthority.");
				
				if ($this->getControlState('searchList', false))
					$c->orderByDateCreated(Criteria::DESC);
				
				$c->setLimit($pageSize);
				$c->setOffset($currentPage * $pageSize);

				$recCount = $lclass::doCount($c);
				$authorities = $lclass::doSelectJoinAuthority($c);
			}
			else
			{
				$query = array();

				if ($this->SortTextFilter->getText() != '')
				{
					$text = $this->SortTextFilter->getText();

					if(substr($text,0,1) == "^")
					{
					    $text = SolrSearch::escapeString(substr(trim($text),1));
						$query[] = "sorts_fulltext:({$text}*)";
					}
					else
					{
					    $text = SolrSearch::escapeString($text);
						$query[] = "(mrc_d299_sa:({$text}) OR fldin_txt_titles:({$text}))";
					}
				}

				if ($this->FullTextFilter->getText() != '')
				{
					$text = $this->FullTextFilter->getText();
                    $text = SolrSearch::escapeString($text);
					$query[] = "fulltext:({$text})";
				}

				if ($this->AuthID->getText() != '')
				{
					$text = $this->AuthID->getText();
                    $text = SolrSearch::escapeString($text);
					$query[] = "( mrc_c001:({$text}) OR mrc_d099_sa:({$text}) )";
				}

				if ($this->TypeFilter->getSelectedIndex() > 0)
					$query[] = "mrc_d901_sm:(" . $this->TypeFilter->getSelectedValue() . ")";

				if ($this->SubtypeFilter->getSelectedIndex() > 0)
					$query[] = "mrc_d901_sq:(" . $this->SubtypeFilter->getSelectedValue() . ")";

				if ($s = $this->SubjFilter->getSelectedIndex() > 0)
					$query[] = "mrc_d901_ss:(" . $this->SubjFilter->getSelectedValue() . ")";

				if ($s = $this->ClassFilter->getSelectedIndex() > 0)
					$query[] = "mrc_d901_ss:(" . $this->ClassFilter->getSelectedValue() . ")";

				if ($this->AuthIntSta->getSelectedIndex() > 0)
					$query[] = "mrc_d901_sf:(" . $this->AuthIntSta->getSelectedValue() . ")";

				if ($this->AuthRecType->getSelectedIndex() > 0)
					$query[] = "mrc_d901_sn:(" . $this->AuthRecType->getSelectedValue() . ")";


				$params = array("facet"=>"true","facet.field"=>"facets_authrectype");

				$sortingExpression = $this->AuthorityGrid->getSortingExpression();
				$sortingDirection = strtolower($this->AuthorityGrid->getSortingDirection());

				if ($this->getControlState('searchList', false))
					$sortingExpression = "LastInsertsMode";
						
				$solrsort = "";
				switch ($sortingExpression)
				{
					/**
					 * By mbrancalion:
					 * we want the last inserted authorities only
					 */
					case "LastInsertsMode":
						$solrsort = "authdatecreateddesc";
						
						break;
					
					case "AuthorityType":
						$solrsort = "authtype{$sortingDirection}" ;

						break;

					case "Title":
						$solrsort = "authtext{$sortingDirection}" ;

						break;
				}

				$this->setGlobalCriteria(array(	'query' => $query,
												'params' => $params ));
				
				$auths = $solr->searchAuthority(	implode(" AND ", $query),
													$currentPage * $pageSize,
													$pageSize,
													$solrsort,
													$params);
								
				$authorities = array();
				$recCount = 0;

				if (isset($auths['response']))
				{
					$recCount = $auths['response']['numFound'];

					foreach ($auths['response']['docs'] as $doc)
					{
						$foundAuthority = AuthorityQuery::create()->findPk($doc['Id']);

						if ($foundAuthority instanceof Authority)
							$authorities[] = $foundAuthority;
					}
				}
			}
		}
		
        $data = $this->getGridData($authorities);
        $this->AuthorityGrid->setVirtualItemCount($recCount);
        $this->AuthorityGrid->setDataSource($data);
        $this->AuthorityGrid->dataBind();
        $this->FoundNumber->setText($recCount);
        $this->setDataSource($data);
    }

	private function getGridData($authorities)
	{
		$data = array();
		
		foreach ($authorities as $index => $obj)
		{
			$authority = ($obj instanceof Authority)
								? $obj
								: $obj->getAuthority();

			/* @var $authority Authority */

			$p = array();
			$authorityId = $authority->getAuthorityId();
			$checked = isset($this->_checked[$authorityId])
							? $this->_checked[$authorityId]
							: false;
			
			if ($this->_checked['all'])
				$checked = !$checked;

			$authType = $authority->getAuthorityType();
			$authRecType = $authority->getAuthorityRecType();
			$p['Checked'] = $checked;
			$p['AuthorityID'] = $authorityId;

			$typeSpec = '';
			
			if ($authType == AuthorityPeer::TYPE_CLASS)
				$typeSpec = Prado::localize(	'Codice: <em>{classcode}</em>',
												array('classcode' => LookupValuePeer::getLookupValue('CLASSTYPE', $authority->getSubjectClass())));
			
			elseif ($authType == AuthorityPeer::TYPE_SUBJECT)
				$typeSpec = Prado::localize(	'Soggett.: <em>{subjectclass}</em>',
												array('subjectclass'=>LookupValuePeer::getLookupValue('SUBJECTTYPE', $authority->getSubjectClass())));
			
			if ($authority->getAuthoritySubtype())
				$typeSpec = LookupValuePeer::getLookupValue(	'AUTHSUBTYPE',
																$authority->getAuthoritySubtype()) . '<br/>' . $typeSpec;

			$p['AuthorityType'] = $authority->getAuthorityTypeLabel();
			$p['TypeSpec'] = $typeSpec;

			$authLink = array();
			$comboKeys = array();

			if (!($obj instanceof Authority))
			{
				// this is a list based on links, so retrieve link properties.
				$lclass = $this->getLinkClass();
				$linkType = $relatorCode = '';
			
				if (method_exists($lclass,'getLinkType'))
					$linkType = intval($obj->getLinkType());
				
				if ($linkType > 0)
					$authLink[] = trim(LookupValuePeer::getLookupValue('LINKTYPE', $linkType));
				
				if (method_exists($lclass,'getRelatorCode'))
					$relatorCode = $obj->getRelatorCode();
				
				if ($relatorCode > 0)
					$authLink[] = trim(LookupValuePeer::getLookupValue('RELATORCODE', $relatorCode));
				
				$comboKeys = array(	$authorityId,
									$obj->getItemId(),
									$linkType,
									$relatorCode);
			}
			
			$comboKeysSerialized = serialize($comboKeys);
			$authLinkString = $authLink
									? ' ('.implode('/',$authLink).')'
									: '';

			$p['FullText'] = htmlentities(	$authority->getFullText() . $authLinkString,
											ENT_COMPAT,
											'UTF-8');
			
			$p['Notes'] = '';
			
			foreach ($authority->getNotes() as $note)
			{
				$p['Notes'] .= '<em>'.LookupValuePeer::getLookupValue('UNI3XXAUTH',$note['NoteNumber'])
					.':</em> '.htmlentities(strip_tags($note['NoteValue'])).'<br />';
			}
			
			$p['AuthorityRecType'] = LookupValuePeer::getLookupValue('AUTHRECTYPE',$authRecType);

			$accepted = $authority->getAcceptedAuthority();
			
			if (!is_null($accepted))
			{
				$p['LinkAuthorityID'] = $accepted->getAuthorityId();
				$p['LinkFullText'] = $accepted->getFullText() . $authLinkString;
			}
			else
			{
				$p['LinkAuthorityID'] = 0;
				$p['LinkFullText'] = '---';
			}

			$linkList = $authority->getAuthoritiesLinkList(true,true);
			$p['AuthorityLink'] = '';

//			$viewBaseLink = $this->getService()->constructUrl(
//				$this->getPage()->isPopup()?'Catalog.AuthorityListPopup':'Catalog.AuthorityList',
//				array('search'=>''));

			if ($this->getPage()->isPopup())
			{
				$viewBaseLink = $this->getService()->constructUrl(	'Catalog.AuthorityListPopup',
																	array('id' => ''));
			}
            else
			{
				$viewBaseLink = $this->getService()->constructUrl(	'Catalog.AuthorityViewPage',
																	array('id' => ''));
			}

            foreach ($linkList as $linkLabel => $links)
			{
				$p['AuthorityLink'] .= "<p class=\"authoritylinklisthdr\">{$linkLabel}</p>" . '<ul class="authoritylinklist">';
				
				foreach ($links as $id => $term)
				{	
					$p['AuthorityLink'] .= "<li><a href=\"{$viewBaseLink}{$term['AuthorityId']}"
											. '" title="' . Prado::localize('Cerca questa authority')
											. "\">{$term['FullText']}</a></li>";
				}
				
				$p['AuthorityLink'] .= '</ul>';
			}
			
			$p['ManifestationLinkCount'] = $authority->countLAuthorityManifestations();
			$p['ComboKeysSerialized'] = $comboKeysSerialized;
			
			$data[] = $p;
		}
		
		return $data;
	}

	public function changePage($sender,$param)
	{
		$this->AuthorityGrid->setCurrentPage($param->NewPageIndex);
	
		$this->populate();
	}

	public function getPopupFlag()
	{
		return $this->getPage()->IsPopup();
	}

	public function globalRefresh()
	{
		$this->resetSorting();
		$this->populate();
	}

	public function onCleanSearch($sender, $param)
	{
		$this->clearFilters();
		$this->resetPagination();
		$this->resetDataSource();
	}

	private function resetPagination()
	{
		$this->AuthorityGrid->setCurrentPage(0);
	}

	public function clearFilters()
	{
		$this->TypeFilter->setSelectedIndex(0);
		$this->SubtypeFilter->setSelectedIndex(0);
		$this->SubjFilter->setSelectedIndex(0);
		$this->ClassFilter->setSelectedIndex(0);
		$this->SortTextFilter->setText('');
		$this->AuthIntSta->setSelectedIndex(0);
		$this->AuthRecType->setSelectedIndex(0);
		$this->AuthID->setText('');
		$this->FullTextFilter->setText('');
	}

	public function resetSorting()
	{
		$this->AuthorityGrid->resetSorting('', null, false);
	}

	public function onSelectReplacement($sender, $param)
	{
		$checkedId = $this->getCheckedIds();
		$this->getPage()->gotoPage(	'Catalog.AuthorityReplace',
									array(	'target' => $checkedId[0],
											'q' => $this->SortTextFilter->getText() ));
	}

	public function onEraseAuthorityLink($sender, $param)
	{
		$authorityId = $linkType = $relatorCode = null;
		$comboKeys = unserialize($param->getCommandParameter());

		if (method_exists($this->getPage(), 'eraseAuthorityLink'))
		{
			$this->getPage()->eraseAuthorityLink($comboKeys);
		}
		else
		{	
			$this->getPage()->writeMessage(Prado::localize("Non esiste il metodo 'eraseAuthorityLink()' nella pagina in corso. Contattare il fornitore del software."),
												ClavisMessage::ERROR);
		}
	}

	public function populateSubType($sender, $param)
	{
		$type = $sender->getSelectedValue();
		
		if ($type && AuthorityPeer::TYPE_ARGUMENT==$type)
		{
			$this->SubtypeFilter->setEnabled(true);
		}
		else
		{
			$this->SubtypeFilter->setSelectedIndex(0);
			$this->SubtypeFilter->setEnabled(false);
		}
	}

}