<?php

/**
 * ClavisItemActionList class
 * 
 * This component visualizes the item actions which are stored in the
 * databases, related to an item or a patron, into a datagrid.
 *
 * @author Marco Brancalion <mbrancalion@e-portaltech.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @version 2.7
 * @package Widgets
 * @since 2.3
 */
class ClavisItemActionList extends TTemplateControl
{
	private $_object;
	private $_datasourceSessionName;
	private $_globalCriteriaSessionName;

	private function initVars()
	{
		$uniqueId = $this->getUniqueID();
		$this->_datasourceSessionName = "DatasourceSessionName" . $uniqueId;
		$this->_globalCriteriaSessionName = "GlobalCriteriaSessionName" . $uniqueId;
	}

	public function onInit($param)
	{
		parent::onInit($param);
		$this->initVars();

		$this->NoSearchPanel->setVisible(false);

		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallback())
			$this->resetObject();
	}

	public function onLoad($param)
	{
		parent::onLoad($param);

		$this->getObject();
		
		$this->PatronPanel->setVisible(!$this->_object instanceof Patron);
		$this->LibrarianPanel->setVisible(intval($this->getLibrarianId()) == 0);

		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallBack())
		{
			$this->setPatronChoiceDone(false, null);
			$this->setLibrarianChoiceDone(false, null);

			$libraries = LibraryPeer::getLibrariesHash(array(LibraryPeer::BLANKVALUE, LibraryPeer::EXCLUDEMYLIBRARY), array('---', '<' . Prado::localize('tutte tranne la mia') . '>'), null, true);

			$this->FromLibraryFilter->setDataSource($libraries);
			$this->FromLibraryFilter->dataBind();
			$this->ToLibraryFilter->setDataSource($libraries);
			$this->ToLibraryFilter->dataBind();

			$this->doCancel($this->getAutomaticPopulate(), $param);
		}
	}

	public function setAutomaticPopulate($flag = true)
	{
		if ($flag === "true")
			$flag = true;
		elseif ($flag === "false")
			$flag = false;

		$this->setViewState("automaticPopulate", $flag, true);
	}

	public function getAutomaticPopulate()
	{
		return $this->getViewState("automaticPopulate", true);
	}

	public function getLibrarianId()
	{
		return $this->getViewState("LibrarianId", null);
	}

	public function setLibrarianId($value)
	{
		$this->setViewState("LibrarianId", $value, null);
	}

	public function getLibraryId()
	{
		return $this->getViewState("LibraryId", null);
	}

	public function setLibraryId($value)
	{
		$this->setViewState("LibraryId", $value, null);
	}

	public function setGlobalCriteria($criteria = null)
	{
		$this->setViewState($this->_globalCriteriaSessionName, $criteria, null);
	}

	public function getGlobalCriteria()
	{
		return SerializableCriteria::refreshCriteria(
						$this->getViewState($this->_globalCriteriaSessionName, null));
	}

	public function getDatasource()
	{
		return $this->getApplication()->getSession()->itemAt($this->_datasourceSessionName, null);
	}

	public function setDataSource($value)
	{
		$this->getApplication()->getSession()->add($this->_datasourceSessionName, $value, null);
	}

	public function resetObject()
	{
		$this->setObject(null);
	}

	public function setObject($obj)
	{
		$this->_object = $obj;
		$this->setViewState("object", $obj, null);
	}

	public function getObject()
	{
		$this->_object = $this->getViewState("object", null);
		return $this->_object;
	}

	public function getSortingExpression()
	{
		return $this->Grid->getSortingExpression();
	}

	public function getSortingDirection()
	{
		return $this->Grid->getSortingDirection();
	}

	public function calculateSortingCriteria(&$sortingCriteria = null)
	{
		$sortingExpression = $this->getSortingExpression();
		$sortingDirection = $this->getSortingDirection();

		if (is_null($sortingCriteria)
				|| !($sortingCriteria instanceof Criteria))
			$sortingCriteria = new Criteria();

		switch ($sortingExpression)
		{
			case 'ActionDate':
				$sortingCriteria->clearOrderByColumns();
				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
				{
					$sortingCriteria->addAscendingOrderByColumn(ItemActionPeer::ACTION_DATE);
					$sortingCriteria->addAscendingOrderByColumn(ItemActionPeer::ITEM_ACTION_ID);
				}
				elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
				{
					$sortingCriteria->addDescendingOrderByColumn(ItemActionPeer::ACTION_DATE);
					$sortingCriteria->addDescendingOrderByColumn(ItemActionPeer::ITEM_ACTION_ID);
				}
				break;

			case null:
				break;

			default:
				$sortingExpression = null;
				break;
		}
	}

	public function populate()
	{
		$this->NoSearchPanel->setVisible(false);

		$pageSize = $this->Grid->getPageSize();
		$currentIndexPage = $this->Grid->getCurrentPage();
		$criteria = new Criteria();

		// begin reading filters
		$actionType = $this->ActionTypeFilter->getSelectedValue();
		if ($actionType != "" && $actionType != "0")
			$criteria->addAnd(ItemActionPeer::ACTION_TYPE, $actionType);

		$patronId = intval($this->HiddenPatronValue->getValue());
		if ($patronId > 0)
			$criteria->addAnd(ItemActionPeer::PATRON_ID, $patronId);

		$librarianId = intval($this->HiddenLibrarianValue->getValue());
		if ($librarianId > 0)
			$criteria->addAnd(ItemActionPeer::LIBRARIAN_ID, $librarianId);

		$fromLibraryId = $this->FromLibraryFilter->getSelectedValue();
		if ($fromLibraryId == LibraryPeer::BLANKVALUE)
			$fromLibraryId = null;
		if (!is_null($fromLibraryId))
		{
			if ($fromLibraryId == LibraryPeer::EXCLUDEMYLIBRARY)
				$criteria->addAnd(ItemActionPeer::FROM_LIBRARY_ID, $this->getUser()->getActualLibraryId(), Criteria::NOT_EQUAL);
			else
				$criteria->addAnd(ItemActionPeer::FROM_LIBRARY_ID, $fromLibraryId);
		}

		$toLibraryId = $this->ToLibraryFilter->getSelectedValue();
		if ($toLibraryId == LibraryPeer::BLANKVALUE)
			$toLibraryId = null;
		if ($this->ToLibraryFilter->getSelectedIndex() > 0)
		{
			$toLibraryId = $this->ToLibraryFilter->getSelectedValue();
			if ($toLibraryId == LibraryPeer::EXCLUDEMYLIBRARY)
				$criteria->addAnd(ItemActionPeer::TO_LIBRARY_ID, $this->getUser()->getActualLibraryId(), Criteria::NOT_EQUAL);
			else
				$criteria->addAnd(ItemActionPeer::TO_LIBRARY_ID, $toLibraryId);
		}

		$librarianId = intval($this->getLibrarianId());
		if ($librarianId > 0)
			$criteria->addAnd(ItemActionPeer::LIBRARIAN_ID, $librarianId);

		$libraryId = intval($this->getLibraryId());
		if ($libraryId > 0)
			$criteria->addAnd(ItemActionPeer::LIBRARY_ID, $libraryId);

		$dateFrom = $this->DateFrom->getSafeText() != '' ? $this->DateFrom->getTimeStamp() : null;
		$dateTo = $this->DateTo->getSafeText() != '' ? $this->DateTo->getTimeStamp() : null;

		if (!is_null($dateFrom) && ($dateFrom > 0))
			$criteria->addAnd(ItemActionPeer::ACTION_DATE, $dateFrom, Criteria::GREATER_EQUAL);
		if (!is_null($dateTo) && ($dateTo > 0))
			$criteria->addAnd(ItemActionPeer::ACTION_DATE, $dateTo + 86399, Criteria::LESS_EQUAL);
		// end of filters

		$this->Grid->resetSorting('ActionDate', TClavisDataGrid::SORTDIRECTION_DESC, false);

		$this->calculateSortingCriteria($criteria);
		$this->setGlobalCriteria(clone $criteria);

		if (is_null(($this->_object)))
		{
			$recCount = ItemActionPeer::doCount($criteria);

			$criteria->setLimit($pageSize);
			$criteria->setOffset($currentIndexPage * $pageSize);
			$itemActions = ItemActionPeer::doSelect($criteria);
		}
		else
		{
			$recCount = $this->_object->countItemActions($criteria);

			$criteria->setLimit($pageSize);
			$criteria->setOffset($currentIndexPage * $pageSize);
			$itemActions = $this->_object->getItemActions($criteria);
		}

		$data = array();
		foreach ($itemActions as $itemAction)
		{
			$row = array();

			$libraryId = $itemAction->getLibraryId();
			if ($libraryId)
				$library = LibraryPeer::retrieveByPK($libraryId);
			else
				$library = null;

			if ($library instanceof Library)
			{
				$libraryDescription = $library->getDescription();
				$libraryLabel = $library->getLabel();
			}
			else
			{
				$libraryDescription = '';
				$libraryLabel = '';
			}

			$row['LibraryDescription'] = $libraryDescription;
			$row['LibraryLabel'] = $libraryLabel;
			$row['LibraryId'] = $libraryId;

			$fromLibraryId = $itemAction->getFromLibraryId();
			if ($fromLibraryId)
				$fromLibrary = LibraryPeer::retrieveByPK($fromLibraryId);
			else
				$fromLibrary = null;

			if ($fromLibrary instanceof Library)
			{
				$fromLibraryDescription = $fromLibrary->getDescription();
				$fromLibraryLabel = $fromLibrary->getLabel();
			}
			else
			{
				$fromLibraryDescription = '---';
				$fromLibraryLabel = '---';
			}

			$row['FromLibraryDescription'] = $fromLibraryDescription;
			$row['FromLibraryLabel'] = $fromLibraryLabel;
			$row['FromLibraryId'] = $fromLibraryId;

			$toLibraryId = $itemAction->getToLibraryId();
			if ($toLibraryId)
				$toLibrary = LibraryPeer::retrieveByPK($toLibraryId);
			else
				$toLibrary = null;

			if ($toLibrary instanceof Library)
			{
				$toLibraryDescription = $toLibrary->getDescription();
				$toLibraryLabel = $toLibrary->getLabel();
			}
			else
			{
				$toLibraryDescription = '---';
				$toLibraryLabel = '---';
			}

			$row['ToLibraryDescription'] = $toLibraryDescription;
			$row['ToLibraryLabel'] = $toLibraryLabel;
			$row['ToLibraryId'] = $toLibraryId;

			$librarianId = $itemAction->getLibrarianId();
			if ($librarianId)
				$librarian = LibrarianPeer::retrieveByPK($librarianId);
			else
				$librarian = null;

			if (!is_null($librarian))
				$libraryCompleteName = $librarian->getCompleteName();
			else
				$libraryCompleteName = '';

			$row['LibrarianCompleteName'] = $libraryCompleteName;
			$row['LibrarianId'] = $librarianId;

			$toolTip = '';
			$patron = $itemAction->getPatron();
			if ($patron instanceof Patron)
			{
				$patronCompleteName = $patron->getCompleteName();
				$navigateUrl = $patron->getNavigateUrl() . $patron->getId();
			}
			else
			{
				$externalLibraryId = intval($itemAction->getExternalLibraryId());
				$externalLibrary = LibraryPeer::retrieveByPK($externalLibraryId);
				if (!is_null($externalLibrary))
				{
					$patronCompleteName = $externalLibrary->getLabel(true, false, true, 30);

					$navigateUrl = $externalLibrary->getNavigateUrl() . $externalLibrary->getLibraryId();
					$toolTip = $externalLibrary->getTrimmedDescription(100) . ' (' .
							Prado::localize('consorzio') . ": " . $externalLibrary->getConsortiaString(100) . ')';
				}
				else
				{
					$patronCompleteName = '---';
					$navigateUrl = '';
				}
			}

			$row['patronCompleteName'] = $patronCompleteName;
			$row['patronNavigateUrl'] = $navigateUrl;
			$row['patronNavigateUrlToolTip'] = $toolTip;

			$item = $itemAction->getItem();
			if (!is_null($item))
			{
				$itemCompleteTitle = $item->getCompleteTitle();
				if (!$itemCompleteTitle)
					$itemCompleteTitle = Prado::localize('(nessun titolo)');
				$itemId = $item->getId();
			}
			else
			{
				$itemCompleteTitle = '';
				$itemId = 0;
			}

			$row['ItemCompleteTitle'] = $itemCompleteTitle;
			$row['ItemId'] = $itemId;
			$row['ActionLabel'] = $itemAction->getItemActionLabel();
			$row['ActionDate'] = $itemAction->getActionDate('U');
			$row['ActionNote'] = $itemAction->getActionNote();
			$row['Id'] = $itemAction->getItemActionId();
			$data[] = $row;
		}

		$this->writeResults($data, $recCount);

		switch (get_class($this->_object))
		{
			case 'Patron':
				$this->PatronColumn->setVisible(false);
				break;
			case 'Item':
				$this->ItemColumn->setVisible(false);
				break;

			default:
				break;
		}
	}

	private function writeResults($data = array(), $recCount = 0)
	{
		$this->RecCounter->setText($recCount);
		$this->Grid->setVirtualItemCount($recCount);
		$this->Grid->setDataSource($data);
		$this->Grid->dataBind();
		$this->setDataSource($data);
	}

	/**
	 * It manages the change of page in the datagrid.
	 * It uses the viewstate to store the current page.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function changePage($sender, $param)
	{
		$this->Grid->setCurrentPage($param->NewPageIndex);
		$this->populate();
		//$this->getPage()->globalRefresh();
	}

	public function globalRefresh()
	{
		$this->populate();
	}

	/**
	 * It returns whether the page permits that in this component
	 * we can have the functions that components inside popups have.
	 *
	 * @return boolean
	 */
	public function getPopupFlag()
	{
		return $this->getPage()->isPopup();
	}

	/**
	 * It returns whether the page permits that in this component
	 * we can have the unlink function.
	 *
	 * @return boolean
	 */
	public function getUnlinkFlag()
	{
		return $this->getPage()->isUnlink();
	}

	/**
	 * It returns whether the page permits that in this component
	 * we can have the delete function.
	 *
	 * @return boolean
	 */
	public function getDeleteFlag()
	{
		return $this->getPage()->isDelete();
	}

	/**
	 * This method, called for unlinking, calls the relative
	 * method of the parent page.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onUnlink($sender, $param)
	{
		$id = $param->CommandParameter;
		$this->getPage()->Unlink($id);
	}

	public function onPatronChanged($sender, $param)
	{
		$patron = null;
		$id = intval($this->HiddenPatronValue->getValue());
		if ($id > 0)
			$patron = PatronPeer::retrieveByPK($id);
		if ($patron instanceof Patron)
		{
			$completeName = $patron->getCompleteName();
			$barcode = trim($patron->getBarcode());
			if ($barcode != '')
				$barcode = ' (' . $barcode . ')';

			$this->PatronLabel->setText($completeName . $barcode);
			$this->setPatronChoiceDone(true, $param);
		}
	}

	public function onLibrarianChanged($sender, $param)
	{
		$librarian = null;
		$id = intval($this->HiddenLibrarianValue->getValue());
		if ($id > 0)
			$librarian = LibrarianPeer::retrieveByPK($id);
		if ($librarian instanceof Librarian)
		{
			$completeName = $librarian->getCompleteName();
			$this->LibrarianLabel->setText($completeName);
			$this->setLibrarianChoiceDone(true, $param);
		}
	}

	public function onResetPatron($sender, $param)
	{
		$this->HiddenPatronLabel->setValue('');
		$this->HiddenPatronValue->setValue('');
		$this->PatronLabel->setText('');
		$this->setPatronChoiceDone(false, $param);
	}

	public function onResetLibrarian($sender, $param)
	{
		$this->HiddenLibrarianLabel->setValue('');
		$this->HiddenLibrarianValue->setValue('');
		$this->LibrarianLabel->setText('');
		$this->setLibrarianChoiceDone(false, $param);
	}

	public function setPatronChoiceDone($flag, $param)
	{
		$this->PatronTitleLabel->setVisible($flag);
		$this->PatronLabel->setVisible($flag);
		$this->PatronChoiceButton->setVisible(!$flag);
		$this->PatronResetButton->setVisible($flag);

		if ($this->getPage()->getIsCallback() && !is_null($param))
			$this->PatronPanel->render($param->getNewWriter());
	}

	public function setLibrarianChoiceDone($flag, $param)
	{
		$this->LibrarianTitleLabel->setVisible($flag);
		$this->LibrarianLabel->setVisible($flag);
		$this->LibrarianChoiceButton->setVisible(!$flag);
		$this->LibrarianResetButton->setVisible($flag);

		if ($this->getPage()->getIsCallback() && !is_null($param))
			$this->LibrarianPanel->render($param->getNewWriter());
	}

	public function onSearch($sender, $param)
	{
		$this->Grid->SetCurrentPage(0);

		$this->populate();
	}

	public function onCancel($sender, $param)
	{
		$this->doCancel(false, $param);  //(true, $param);
	}

	private function doCancel($doRefresh = true, $param)
	{
		$this->Grid->setCurrentPage(0);

		$this->ActionTypeFilter->setSelectedIndex(-1);
		$this->FromLibraryFilter->setSelectedIndex(-1);
		$this->ToLibraryFilter->setSelectedIndex(-1);

		$this->onResetPatron(null, null);
		$this->onResetLibrarian(null, null);
		$this->onResetDate(null, null);

		if ($doRefresh)
			$this->populate();
		else
		{
			$this->writeResults();
			$this->NoSearchPanel->setVisible(true);
		}
	}

	public function onResetDate($sender, $param)
	{
		$this->DateFrom->setText('');
		$this->DateTo->setText('');

		if ($this->getPage()->getIsCallback() && !is_null($param))
			$this->DatePanel->render($param->getNewWriter());
	}
}