<?php
/**
 * ClavisAuthorityLinkItem class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Widgets
 */

/**
 * ClavisAuthorityLinkItem Class
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Widgets
 * @since 2.1
 */
class ClavisAuthorityLinkItem extends TTemplateControl
{
	public $authority;

	public function getAuthority()
	{
		return $this->authority;
	}

	public function setAuthority(Authority $value)
	{
		$this->authority = $value;
	}

	public function populate()
	{
		$c = new Criteria();

		$this->calculateSortingCriteria($c);

		$lManAuthListsCount = $this->authority->countLAuthorityManifestations($c);

		$pageSize = $this->RecordGrid->getPageSize();
		$currentIndexPage = $this->RecordGrid->getCurrentPage();

		$c->setLimit($pageSize);
		$c->setOffset($currentIndexPage * $pageSize);
		$lManAuthLists = $this->authority->getLAuthorityManifestationsJoinManifestation($c);

		$manGridDS = array();
		/* @var $lManAuth LAuthorityManifestation */
		foreach ($lManAuthLists as $lManAuth)
		{
			$m = $lManAuth->getManifestation();
			if (!$m instanceof Manifestation)
			{
				// report and skip
				Prado::log("Warning: dangling link from auth [{$lManAuth->getAuthorityId()}] and man [{$lManAuth->getManifestationId()}]");
				continue;
			}
			$row['Title'] = $m->getCompleteTitle();
			$row['Year'] = $m->getEditionDate();
			$row['ManId'] = $lManAuth->getManifestationId();
			$row['lAuthManId'] = $lManAuth->getAuthorityId() . '|' . $lManAuth->getManifestationId() .
					'|' . $lManAuth->getLinkType() . '|' . $lManAuth->getRelatorCode();
			$manGridDS[] = $row;
		}
		$this->RecordGrid->setDataSource($manGridDS);
		$this->RecordGrid->setVirtualItemCount($lManAuthListsCount);
		$this->RecordGrid->dataBind();
		$this->Counter->setText($lManAuthListsCount);
	}

	public function calculateSortingCriteria(&$sortingCriteria = null)
	{
		$sortingExpression = $this->RecordGrid->getSortingExpression();
		$sortingDirection = $this->RecordGrid->getSortingDirection();

		if (is_null($sortingCriteria) || !($sortingCriteria instanceof Criteria))
			$sortingCriteria = new Criteria();

		switch ($sortingExpression)
		{

			case 'title':
				$sortingCriteria->clearOrderByColumns();
				$sortingCriteria->addJoin(LAuthorityManifestationPeer::MANIFESTATION_ID, ManifestationPeer::MANIFESTATION_ID);

				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
				{
					$sortingCriteria->addAscendingOrderByColumn(ManifestationPeer::TITLE);
					$sortingCriteria->addAscendingOrderByColumn(ManifestationPeer::PUBLISHER);
				}
				elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
				{
					$sortingCriteria->addDescendingOrderByColumn(ManifestationPeer::TITLE);
					$sortingCriteria->addDescendingOrderByColumn(ManifestationPeer::PUBLISHER);
				}
				break;

			case 'year':
				$sortingCriteria->clearOrderByColumns();
				$sortingCriteria->addJoin(LAuthorityManifestationPeer::MANIFESTATION_ID, ManifestationPeer::MANIFESTATION_ID);

				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
				{
					$sortingCriteria->addAscendingOrderByColumn(ManifestationPeer::EDITION_DATE);
				}
				elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
				{
					$sortingCriteria->addDescendingOrderByColumn(ManifestationPeer::EDITION_DATE);
				}
				break;

			case null:
				break;

			default:
				$sortingExpression = null;
				break;
		}
	}

	public function setReadOnly($value)
	{
		return $this->setControlState('ReadOnly', TPropertyValue::ensureBoolean($value), false);
	}

	public function getReadOnly()
	{
		return $this->getControlState('ReadOnly', false);
	}

	public function onDeleteLink($sender, $param)
	{
		$id = $this->RecordGrid->DataKeys[$param->Item->ItemIndex];
		$keys = explode('|', $id);
		LAuthorityManifestationPeer::doDelete($keys);

		/* reindex manifestation */
		$deletableManifestation = ManifestationPeer::retrieveByPK($keys[1]);
		if ($deletableManifestation instanceof Manifestation)
			$deletableManifestation->invalidateCache();

		$this->populate();
	}

	public function onChangePage($sender, $param)
	{
		$sender->setCurrentPage($param->NewPageIndex);
		$this->populate();
	}
	
}