<?php
/**
 * ClavisInventorySerieList class file
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 */

/**
 * ClavisResourceList Class
 *
 * @author Cristian Chiarello <cristian@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2008 ePortal Technologies
 * @copyright Copyright &copy; 2009 Comperio srl
 * @version 2.7
 */

class ClavisResourceList extends TTemplateControl
{
	
	/**
	 * It populates the datagrid.
	 *
	 * @param TEventParameter $param
	 */
	public function onLoad($param)
	{
		parent::onLoad($param);
		
		$resip = $this->getRequest()->itemAt('resip');
		if(!is_null( $resip ) && $resip != '')
		{
			$this->setResourceIP($resip);
		}
		
		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallBack()) 
		{

			$this->populate();
		}
	}
	
	
	
	public function setResourceIP( $rip )
	{
		$this->setControlState('resourceip', $rip);
	}
	
	public function getResourceIP()
	{
		return $this->getControlState( 'resourceip' );
	}

	

	public function changePage($sender,$param) {
		$this->ResourceGrid->setCurrentPage($param->NewPageIndex);

		$this->getPage()->globalRefresh();
	}

	public function getPopupFlag()
	{
		return $this->getPage()->IsPopup();
	}

	public function getUnlinkFlag()
	{
		return $this->getPage()->IsUnlink();
	}

	public function globalRefresh()
	{
		$this->populate();
	}
	

	
	public function populate()
	{

		$pageSize = $this->ResourceGrid->getPageSize();
		$currentIndexPage = $this->ResourceGrid->getCurrentPage();

		$libid = $this->getUser()->getActualLibraryId();
		$rc = ResourceQuery::create()
			->filterByLibraryId($libid)
			->limit( $pageSize )
			->offset( $currentIndexPage * $pageSize);
		
		$resip = $this->getResourceIP();
		if(!is_null( $resip ))
			$rc->filterByName($resip);

		$resources = $rc->find();
		$recCount = $rc->count();
		
		$this->ResourceGrid->setVirtualItemCount($recCount);

		$this->RecCounter->setText(Prado::localize("Record totali: {recCount}", array('recCount' => $recCount)));

		$datasource = array();
		foreach ($resources as $resource)
		{
			$resourceId = $resource->getResourceId();

			
			$resourceExternalId = $resource->getResourceExternalId();
			if( is_null( $resourceExternalId ))
				$resourceExternalId = '---';

			$resourceClass = LookupValuePeer::getLookupValue('RESOURCE_CLASS', $resource->getResourceClass());
			if( is_null( $resourceClass ) || $resourceClass == '')
				$resourceClass = '---';
			
			$resourceStatus = LookupValuePeer::getLookupValue('RESOURCE_STATUS', $resource->getResourceStatus());
			if( is_null( $resourceStatus ) || $resourceStatus == '')
				$resourceStatus = '---';
			
			
			$libraryId = $resource->getLibraryId();
			
			$libraryLabel='---';
			$lib = LibraryQuery::create()
				->findOneByLibraryId($libraryId);
			if( $lib instanceof Library) $libraryLabel = $lib->getLabel ( );
			

			$name = $resource->getName();
			if( is_null( $name ))
				$name = '---';
			
			$shortname = $resource->getShortname();
			if( is_null( $shortname ))
				$shortname = '---';
			
			$type_key = $resource->getType();
			if( is_null( $type_key ))
			{
				$type = '---';
			}
			else
			{
				$type = LookupValuePeer::getLookupValue('RESOURCE_TYPE', $type_key);
			}
			
			$ports = $resource->getPorts();
			if( is_null( $ports ))
				$ports = '---';
			
			$secret = $resource->getSecret();
			if( is_null( $secret ))
				$secret = '---';
			
			$server = $resource->getServer();
			if( is_null( $server ))
				$server = '---';
			
			$community = $resource->getCommunity();
			if( is_null( $community ))
				$community = '---';
			
			$description = $resource->getDescription();
			if( is_null( $description ))
				$description = '---';
			
			$note = $resource->getNote();
			if( is_null( $note ))
				$note = '---';
			
			$admUsr = $resource->getAdminUsr();
			$admPwd = $resource->getAdminPwd();
			$admUrl = '';
			if( $type=='mikrotik' && !is_null( $admUsr ) && $admUsr != '')
			{
				$admUrl = 'http://'.$admUsr;
				/*
				if(!is_null( $admPwd ) && $admUsr!='')
				{
					$admUrl .= ':'.$admPwd;
				}
				*/
				$admUrl .= '@'.$name;
			}
			
			
			


			$datasource[] = array(
									'id' => $resourceId,
									'libraryId' => $libraryId,
									'libraryLabel' => $libraryLabel,
									'resourceExternalId' => $resourceExternalId,
									'name' => $name,
									'shortname' => $shortname,
									'class' => $resourceClass,
									'status' => $resourceStatus,
									'type' => $type,
									'ports' => $ports,
									'secret' => $secret,
									'server' => $server,
									'community' => $community,
									'description' => $description,
									'adminURL' => $admUrl,
									'note' => $note,
									'canEdit' => $this->getUser()->getEditPermission($resource)	);
		}
		
		
		$this->ResourceGrid->setDataSource($datasource);
		$this->ResourceGrid->dataBind();
	}

	
	
	public function delRemoteRes($resource)
	{
		try
		{
			$client= ClavisRadUtil::getClient();
			$rid = $resource->getResourceExternalId();
			$res = $client->delNas(array('id'=> $rid));
			//Prado::log(Prado::varDump($res));
			if( isset( $res['result'] ) && isset( $res['result']['status'] ) && $res['result']['status'] == 'ack' )
			{
				$deleted  = 0;
				if( isset( $res['result']['data']['deleted'] ) )
				{
					$deleted = $res['result']['data']['deleted'];
				}
				
				
				if($deleted <= 0)
				{
					Prado::log(__METHOD__ . ' unable to delete remote resource');
					return FALSE;
				}
				else
				{
					return TRUE;
				}
			}
			else
			{
				return FALSE;
			}
		} catch (Exception $ex) {
			Prado::log(__METHOD__ . ' error calling rpc ' . $ex->getMessage());
			return FALSE;
		}
		
	}
	
	
	
	public function onDelete($sender, $param)
	{
		$con = Propel::getConnection();
		$con->beginTransaction();
		
		try
		{
			$pk = $param->getCommandParameter();
			//Prado::log($pk);
			
			
			
			$r = ResourceQuery::create()->findPk($pk);
			if ($r instanceof Resource)
			{
				
				$rrq = ResourceRuleQuery::create()
				->filterByResourceOwner($r->getName())
				->delete();
				
				$type=$r->getType();

				
				if($type=='mikrotik')
				{
					if(!$this->delRemoteRes( $r))
					{
						$this->getPage()->writeMessage(Prado::localize("La risorsa non è stata perchè il server radius non risponde"),ClavisMessage::ERROR);
						return;
					}

				}
				$r->delete();
				
				$con->commit();
				
				$this->getPage()->writeMessage(Prado::localize("Risorsa cancellata correttamente."),ClavisMessage::CONFIRM);
				$p = $this->getPage();
				if( method_exists( $p, 'populate' ))
				{
					$p->populate();
				}
			}
			$this->populate();
		
		} catch (Exception $ex) {
			$con->rollBack();
			$this->getPage()->writeMessage(Prado::localize("Errore nella cancellazione della risorsa."),ClavisMessage::ERROR);
			Prado::log(__METHOD__ . " EXCEPTION " . $ex->getMessage());
		}
	}


}
