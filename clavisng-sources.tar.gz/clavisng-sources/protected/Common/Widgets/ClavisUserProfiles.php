<?php
/**
 * ClavisUserProfiles class file
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.8.9
 */

/**
 * ClavisUserProfiles Class
 *
 * This component visualizes librarian's profiles.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2008 ePortal Technologies
 * @copyright Copyright &copy; 2012 Comperio srl
 * @version 2.8.9
 * @package Widgets
 * @since 2.0
 */
class ClavisUserProfiles extends TTemplateControl
{
	/** @var Librarian */
	private $_librarian = null;
	public $minActualProfile = 0;

	public function onLoad($param)
	{
		parent::onLoad($param);

		$this->getLibrarian();
		
		//$this->minActualProfile = min($this->getUser()->getProfileIds());
		$this->minActualProfile = $this->getUser()->getMinProfileId();
		
		if ($this->minActualProfile == 1)
			$this->minActualProfile = 0;

		if (!$this->getPage()->getIsPostBack() 
				&& !$this->getPage()->getIsCallBack())
		{
			$this->populate();
			$this->dataBind();
		}
	}

	public function setLibrarian($librarian)
	{
		$this->_librarian = $librarian;
		$this->setViewState("librarian", $librarian, null);
	}

	public function getLibrarian()
	{
		$this->_librarian = $this->getViewState("librarian", null);

		return $this->_librarian;
	}

	/**
	 * We populate the dataList with data we get from the
	 * databases according to the current Librarian.
	 *
	 * NOTE: it sets into the dataSource of the dataList a field
	 * "query", which adds a further "where" clause in the sql
	 * statement which is used to calculate the dataSource of the
	 * dropDownList, so that it includes in the selectable profiles
	 * (the ones which are not assigned to the librarian yet) also
	 * the actual one we're modifying.
	 *
	 */
	public function populate()
	{
		$minActualProfile = $this->getUser()->getMinProfileId();
		
		if ($minActualProfile == 1)
			$minActualProfile = 0;
		
		$ds = array();
		$profiles = $this->_librarian->getProfiles();

		if (count($profiles) > 0)
		{
			$profilesControl = $this->getUser()->getProfilesControl();
		
			foreach ($profiles as $row)
			{
				$name = $row->getAppProfile()->getName();
				$profileId = $row->getProfileId();

				$ds[] = array(	'isNew' => false,
								'name' => $name,
								'profileId' => $profileId,
								"query" => "or ap.profile_id = " . $profileId,
								"minProfileQuery" => " and ap.profile_id >= " . $minActualProfile,
					
								'readOnly' => array_search($profileId, $profilesControl) === false );
			}
		}

		$this->Profiles->setDataSource($ds);
		$this->Profiles->dataBind();
	}

	/**
	 * This is called each time a row has to be dataBound.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	private function calculateNewProfiles($currentRowProfileId = null)
	{
		$c = new Criteria();
			
		$totalAllowedProfileIds = $this->getUser()->getProfilesControl();
		$alreadyProfileIds = $this->getPage()->getLibrarian()->getProfileIds();
		$allowedNewProfileIds = array_diff($totalAllowedProfileIds, $alreadyProfileIds);

		if (intval($currentRowProfileId) > 0)
			$allowedNewProfileIds[] = $currentRowProfileId;

		$c->add(AppProfilePeer::PROFILE_ID, $allowedNewProfileIds, Criteria::IN);

		return AppProfilePeer::doSelect($c);
	}
	
	public function onDataBound($sender, $param)
	{
		$item = $param->Item;
		
		// we want this only when editing (or create) a new linked profile
		if ($item->ItemType == 'EditItem')
		{
			$availableProfiles = $this->calculateNewProfiles($item->DataItem['profileId']);

			if (empty($availableProfiles))
			{
//				$this->Profiles->SelectedItemIndex = -1;          da verificare se questa parte serve, mbrancalion
//				$this->Profiles->EditItemIndex = -1;
//				$this->Profiles->dataBind();
			}
			else
			{
				$item->NewProfile->setDataSource($availableProfiles);
				$item->NewProfile->dataBind();

				if (intval($item->DataItem['profileId']) > 0)
					$item->NewProfile->SetSelectedValue($item->DataItem['profileId']);
			}
		}
	}	

	/**
	 * It puts the dataList into edit mode, in a line.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function editGrid($sender, $param)
	{
		$sender->SelectedItemIndex = -1;
		$sender->EditItemIndex = $param->Item->ItemIndex;
		$this->getPage()->globalCancel($this);
		$this->getPage()->globalRefresh();
	}

	private function reloadLibrarian()
	{
		$this->_librarian->reload(true);
		
		$this->setLibrarian($this->_librarian);
	}
	
	/**
	 * It updates the profile being edited in the database.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function updateProfile($sender, $param)
	{
		$isNew = $param->CommandParameter;
		$item = $param->Item;
		$itemIndex = $param->Item->ItemIndex;

		$profiles = $this->_librarian->getProfiles();
		
		if ($isNew)
		{
			$sortOrder = count($profiles) + 1;
		}
		else
		{
			$oldProfile = $profiles[$itemIndex];
			$sortOrder = $oldProfile->getSortOrder();
			$oldProfile->delete();
		}

		$profile = new LLibrarianProfile();
		$profileId = $item->NewProfile->SelectedValue;
		$librarianId = $this->_librarian->getLibrarianId();

		$profile->setProfileId($profileId);
		$profile->setLibrarianId($librarianId);
		$profile->setSortOrder($sortOrder);
		$profile->save();
		
		if ($this->getUser()->getId() == $librarianId)
			$this->getUser()->reloadUser();

		$this->Profiles->SelectedItemIndex = -1;
		$this->Profiles->EditItemIndex = -1;

		$profileLabel = AppProfilePeer::getProfileLabel($profileId);
		
		$this->getPage()->writeMessage(Prado::localize("Aggiunto profilo '{prof}' all'operatore '{name}' (id = {id})",
															array(	'prof' => $profileLabel,
																	'name' => $this->_librarian->getCompleteName(),
																	'id' => $librarianId )),
										ClavisMessage::CONFIRM);

		ChangelogPeer::logAction(	$this->_librarian, 
									ChangelogPeer::LOG_UPDATE, 
									$this->getUser(),
									"Aggiunto profilo '{$profileLabel}'");
									
		$this->reloadLibrarian();
									
		$this->getPage()->globalRefresh();
	}

	/**
	 * It adds a row in the dataList, corrisponding to a new
	 * profile.
	 * It populates the dropDownList by using some sql which
	 * excluded from the selectable profiles the ones which
	 * are already set for the given librarian.
	 *
	 */
	public function onAddProfile()
	{
		$profilesAvailableCount = $this->calculateNewProfiles();
		
		if (count($profilesAvailableCount) > 0)
		{
			$this->Page->globalRefresh();
			$this->getPage()->setFocus("anchor_newProfile");
			$dataSource = $this->Profiles->getDataSource();

			$dataSource[] = array(	'isNew' => true,
									'name' => null,
									'profileId' => null,
									"query" => "",
									"minProfileQuery" => " and ap.profile_id > " . $this->minActualProfile );

			$this->Profiles->setDataSource($dataSource);
			$this->Profiles->dataBind();

			$count = $this->Profiles->getItemCount();
			$this->Profiles->setSelectedItemIndex(-1);
			$this->Profiles->setEditItemIndex($count - 1 );
			
			$this->Profiles->dataBind();
		}
		else
		{
			$this->populate();
		}
	}

	/**
	 * It deletes a profile, and shifts all the sort_order
	 * values of further profiles in order to fill the gap.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function deleteProfile($sender, $param)
	{
		$item = $param->Item;
		$itemIndex = $param->Item->ItemIndex;

		$profiles = $this->_librarian->getProfiles();
		$deadProfile = $profiles[$itemIndex];
		$deadProfile->delete();

		for ($index = $itemIndex + 1; $index < count($profiles); $index++)
		{
			$newProfile = $profiles[$index];
			$newProfile->setSortOrder($newProfile->getSortOrder() - 1);
			$newProfile->save();
		}

		$profileLabel = AppProfilePeer::getProfileLabel($deadProfile->getProfileId());

		$this->getPage()->writeMessage(Prado::localize("Profilo '{prof}' rimosso dall'operatore '{name}' (id = {id})",
															array(	'prof' => $profileLabel,
																	'name' => $this->_librarian->getCompleteName(),
																	'id' => $this->_librarian->getLibrarianId() )),
										ClavisMessage::INFO);

		ChangelogPeer::logAction(	$this->_librarian, 
									ChangelogPeer::LOG_UPDATE, 
									$this->getUser(), 
									"Rimozione profilo '{$profileLabel}'" );
									
		$this->reloadLibrarian();
		
		$this->getPage()->globalRefresh();
	}

	/**
	 * It cancels the operation we're performing and
	 * returns in non-editing mode.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onCancel($sender, $param)
	{
		$this->Profiles->SelectedItemIndex = -1;
		$this->Profiles->EditItemIndex = -1;
		$this->Page->globalRefresh();
	}

	public function getPermission()
	{
		return $this->getPage()->getProfilePermission();
	}

}