<?php
/**
 * ClavisAddressListAnag class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Widgets
 */

/**
 * ClavisAddressListAnag
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.7
 * @package Widgets
 * @since 2.4
 */
class ClavisAddressListAnag extends TTemplateControl
{
	private $_datasource;
	private $_datasourceSessionName;
	private $_globalCriteriaSessionName;
	private $_globalCriteria;
	private $_checked;
	private $_checkedSessionName;

	private function initVars()
	{
		$uniqueId = $this->getUniqueID();
		$this->_datasourceSessionName = "DatasourceSessionName" . $uniqueId;
		$this->_globalCriteriaSessionName = "GlobalCriteriaSessionName" . $uniqueId;
		$this->_checkedSessionName = "CheckedSessionName" . $uniqueId;
	}

	public function onInit($param)
	{
		parent::onInit($param);
		$this->initVars();
	}

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallBack())
		{
//			if ($this->FoundNumber->getText() === '')
//				$populateFlag = true;
//			else
			$populateFlag = false;

			$this->resetDataSource($populateFlag);
		}

		$this->_checked = $this->getChecked();
	}

	public function setBirthCity($val)
	{
		$this->setViewState('BirthCity', $val, '');
	}

	public function getBirthCity()
	{
		return TPropertyValue::ensureString($this->getViewState('BirthCity', ''));
	}

	public function setBirthProvince($val)
	{
		$this->setViewState('BirthProvince', $val, '');
	}

	public function getBirthProvince()
	{
		return TPropertyValue::ensureString($this->getViewState('BirthProvince', ''));
	}

	public function setBirthCountry($val)
	{
		$this->setViewState('BirthCountry', $val, '');
	}

	public function getBirthCountry()
	{
		return TPropertyValue::ensureString($this->getViewState('BirthCountry', ''));
	}

	public function setCitizenship($val)
	{
		$this->setViewState('BirthCitizenship', $val, '');
	}

	public function getCitizenship()
	{
		return TPropertyValue::ensureString($this->getViewState('BirthCitizenship', ''));
	}

	public function setPatronNote($val)
	{
		$this->setViewState('PatronNote', $val, '');
	}

	public function getPatronNote()
	{
		return TPropertyValue::ensureString($this->getViewState('PatronNote', ''));
	}

	public function setEnablePagination($enablePagination = 'true')
	{
		$this->setViewState("EnablePagination", $enablePagination, 'true');
	}

	public function getEnablePagination()
	{
		$flag = $this->getViewState("EnablePagination", 'true');
		switch ($flag)
		{
			case 'true':
				$enablePagination = true;
				break;

			case 'false':
				$enablePagination = false;
				break;

			default:
				$enablePagination = true;
		}
		return $enablePagination;
	}

	private function resetGlobalCriteria()
	{
		$this->setGlobalCriteria(null);
	}

	public function setGlobalCriteria($criteria = null)
	{
		$this->getApplication()->getSession()->add($this->_globalCriteriaSessionName, $criteria, null);
	}

	public function getGlobalCriteria()
	{
		return SerializableCriteria::refreshCriteria(
						$this->getApplication()->getSession()->itemAt($this->_globalCriteriaSessionName, null));
		return $this->_globalCriteria;
	}

	public function resetDataSource($populateFlag = true, $resetPagination = true)
	{
		if ($resetPagination)
			$this->resetPagination();

		$this->resetCheckedItems();
		$this->resetGlobalCriteria();
		$this->setDataSource(array());
		$this->resetSorting(true);

		if ($populateFlag)
			$this->populate();
	}

	public function getDatasource()
	{
		$this->_datasource = $this->getApplication()->getSession()->itemAt($this->_datasourceSessionName, null);
		return $this->_datasource;
	}

	public function setDataSource($ds)
	{
		$this->_datasource = $ds;
		$this->getApplication()->getSession()->add($this->_datasourceSessionName, $this->_datasource, null);
	}

	public function searchAddress($sender, $param)
	{
		$this->Grid->setCurrentPage(0);
		$this->resetDataSource();
	}

	public function setFilters($birthCity = '', $birthProvince = '', $birthCountry = '', $citizenship = '', $patronNote = '')
	{
		$this->setBirthCity($birthCity);
		$this->setBirthProvince($birthProvince);
		$this->setBirthCountry($birthCountry);
		$this->setCitizenship($citizenship);
		$this->setPatronNote($patronNote);
	}

	public function calculateSortingCriteria(&$sortingCriteria = null)
	{
		$sortingExpression = $this->Grid->getSortingExpression();
		$sortingDirection = $this->Grid->getSortingDirection();

		if (is_null($sortingCriteria) || !($sortingCriteria instanceof Criteria))
			$sortingCriteria = new Criteria();

		switch ($sortingExpression)
		{
			case 'City':
				$sortingCriteria->clearOrderByColumns();
				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
					$sortingCriteria->addAscendingOrderByColumn(PatronPeer::BIRTH_CITY);
				elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
					$sortingCriteria->addDescendingOrderByColumn(PatronPeer::BIRTH_CITY);
				break;

			case 'Province':
				$sortingCriteria->clearOrderByColumns();
				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
					$sortingCriteria->addAscendingOrderByColumn(PatronPeer::BIRTH_PROVINCE);
				elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
					$sortingCriteria->addDescendingOrderByColumn(PatronPeer::BIRTH_PROVINCE);
				break;

			case 'Country':
				$sortingCriteria->clearOrderByColumns();
				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
					$sortingCriteria->addAscendingOrderByColumn(PatronPeer::BIRTH_COUNTRY);
				elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
					$sortingCriteria->addDescendingOrderByColumn(PatronPeer::BIRTH_COUNTRY);
				break;

			case 'Citizenship':
				$sortingCriteria->clearOrderByColumns();
				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
					$sortingCriteria->addAscendingOrderByColumn(PatronPeer::CITIZENSHIP);
				elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
					$sortingCriteria->addDescendingOrderByColumn(PatronPeer::CITIZENSHIP);
				break;

			case null:
				break;

			default:
				$sortingExpression = null;
				break;
		}
	}

	private function resetSorting($force = false)
	{
		$this->Grid->resetSorting('City', TClavisDataGrid::SORTDIRECTION_ASC, $force);
	}

	public function populate()
	{
		$clavisLibrarian = $this->getUser();
		$pageSize = $this->Grid->getPageSize();
		$currentPage = $this->Grid->getCurrentPage();
		$addressItems = array();
		$criteria = new Criteria();

		$city = $this->getBirthCity();
		if ($city != '')
			$criteria->addAnd(PatronPeer::BIRTH_CITY, $city . "%", Criteria::LIKE);

		$province = $this->getBirthProvince();
		if ($province != '')
			$criteria->addAnd(PatronPeer::BIRTH_PROVINCE, $province . "%", Criteria::LIKE);

		$country = $this->getBirthCountry();
		if ($country != '')
			$criteria->addAnd(PatronPeer::BIRTH_COUNTRY, $country . "%", Criteria::LIKE);

		$citizenship = $this->getCitizenship();
		if ($citizenship != '')
			$criteria->addAnd(PatronPeer::CITIZENSHIP, $citizenship . "%", Criteria::LIKE);

		$note = $this->getPatronNote();
		if ($note != '')
			$criteria->addAnd(PatronPeer::PATRON_NOTE, "%" . $note . "%", Criteria::LIKE);

		$this->resetSorting();
		$this->calculateSortingCriteria($criteria);
		$this->setGlobalCriteria(clone($criteria));

		if (count($criteria->getMap()) > 0)
		{
			$recCount = PatronPeer::doCount($criteria);

			$criteria->setLimit($pageSize);
			$criteria->setOffset($currentPage * $pageSize);
			$patrons = PatronPeer::doSelect($criteria);
		}
		else
		{
			$patrons = array();
			$recCount = 0;
		}

		$data = array();
		foreach ($patrons as $index => $patron)
		{
			/* @var $patron Patron */

			$row = array();
			$patronId = $patron->getPatronId();

			$cityString = '';
			$city = $patron->getBirthCity();
			if ($city != '')
				$cityString .= $city;
			$row['City'] = $cityString;
			$row['Province'] = $patron->getBirthProvince();
			$row['Country'] = $patron->getBirthCountry();
			$row['Citizenship'] = $patron->getCitizenship();
			$patronCompleteName = $patron->getCompleteName();
			$patronNavigateUrl = $patron->getNavigateUrl() . $patronId;

			$canView = $clavisLibrarian->getViewPermission($patron);
			$canEdit = $clavisLibrarian->getEditPermission($patron);

			$row['PatronCompleteName'] = $patronCompleteName;
			$row['PatronNavigateUrl'] = $patronNavigateUrl;

			$row['Notes'] = $patron->getPatronNote();

			$row['CanView'] = $canView;
			$row['CanEdit'] = $canEdit;

			$row['PatronId'] = $patronId;

			$patronName = trim($patron->getReverseCompleteName());
			if ($patronName != '')
				$patronName = "<a href='" . $patron->getNavigateUrl() . $patronId . "' target='parent'>" . $patronName . "</a>";
			$patronName .= '&nbsp;(' . Prado::localize("id") . ':&nbsp;' . $patronId . ')';
			$row['PatronNameID'] = $patronName;

			if (isset($this->_checked[$patronId]))
				$checked = $this->_checked[$patronId];
			else
				$checked = false;
			if ($this->_checked['all'])
				$checked = !$checked;
			$row['checked'] = $checked;

			$data[] = $row;
		}

		$this->setChecked($this->_checked);
		$this->Grid->setVirtualItemCount($recCount);
		$this->Grid->setDataSource($data);
		$this->Grid->dataBind();
		$this->FoundNumber->setText($recCount);
		$this->setDataSource($data);
	}

	public function changePage($sender, $param)
	{
		$this->Grid->setCurrentPage($param->NewPageIndex);
		$this->populate();
	}

	public function getPopupFlag()
	{
		return $this->getPage()->IsPopup();
	}

	public function globalRefresh()
	{
		$this->resetSorting();
		$this->populate();
	}

	public function cleanSearch()
	{
		$this->onCleanSearch(null, null);
	}

	public function onCleanSearch($sender, $param)
	{
		$this->clearFilters();
		$this->resetDataSource();
	}

	private function resetPagination()
	{
		$this->Grid->setCurrentPage(0);
	}

	public function resetCheckedItems($state = false)
	{
		$this->setChecked(array('all' => $state));
	}

	public function setChecked($checked = null)
	{
		$this->_checked = $checked;
		$this->getApplication()->getSession()->add($this->_checkedSessionName, $checked);
	}

	public function getChecked()
	{
		$this->_checked = $this->getApplication()->getSession()->itemAt($this->_checkedSessionName);
		return $this->_checked;
	}

	public function onFlipChecked($sender, $param)
	{
		$checked = $this->getChecked();
		$newStatus = $sender->getChecked();

		$index = $sender->Parent->Parent->ItemIndex;
		$dataSource = $this->getDatasource();

		$row = $dataSource[$index];
		$itemId = $row['PatronId'];

		if ($newStatus != $checked['all'])
			$checked[$itemId] = true;
		else
			unset($checked[$itemId]);

		$this->setChecked($checked);
	}

	public function onMasterChecked($sender, $param)
	{
		$newStatus = $sender->getChecked();
		$this->resetCheckedItems($newStatus);

		$gridItems = $this->Grid->getItems();
		foreach ($gridItems as $item)
			$item->CheckColumn->Checked->setChecked($newStatus);
	}

	public function setMasterChecked($newChecked = false, $param = null)
	{
		$this->resetCheckedItems($newChecked);
		$gridItems = $this->Grid->getItems();
		$header = $this->Grid->getHeader();

		foreach ($gridItems as $item)
			$item->CheckColumn->Checked->setChecked($newChecked);

		$header->CheckColumn->MasterCheck->setChecked($newChecked);
	}

	public function getCheckedItemIds($force = false, $reset = false)
	{
		$checked = $this->getChecked();
		$masterChecked = $checked['all'];
		unset($checked['all']);
		$checkedIds = array_keys($checked);
		$output = array();

		if (!$masterChecked)
			$output = $checkedIds;
		else		 // caso del mastercheck inverso
		{
			$criteria = $this->getGlobalCriteria();
			if (!is_null($criteria) && ($criteria instanceof Criteria))
			{
				$criteria->add(PatronPeer::PATRON_ID, $checkedIds, Criteria::NOT_IN);
				$stmt = PatronPeer::doSelectStmt($criteria);

				while ($row = $stmt->fetch(PDO::FETCH_NUM))
					$output[] = $row[0];
			}
		}

		if ((count($output) == 0) && ($force == true))
		{
			$this->resetCheckedItems(true);
			$output = $this->getCheckedItems();
			if ($reset)
				$this->resetCheckedItems(false);
		}

		return $output;
	}
	
}