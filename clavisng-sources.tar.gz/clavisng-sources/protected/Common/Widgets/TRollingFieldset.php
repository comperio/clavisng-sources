<?php
/**
 * TRollingFieldset
 *
 * @author Massimiliano Pigozzi <mpigozzi@e-portaltech.it>
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.e-portaltech.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @license http://www.e-portaltech.it/license/
 *
 *
 * This is a custom control which creates a wrapping fieldset, with rolling capabilities.
 * It uses Javascript to wrap at run-time and cookies to store the last status
 * the user could instantiate this component with some properties:
 *    
 *    - Open : initial status ("true"/"false")
 *    - Style : css style of the whole control
 *    - CssClass : css class of the whole control
 *    - Legend : legend of the fieldset displayed
 *    - FieldStyle : css style of the title
 *    - FieldCssClass : css class of the title
 *    - ContentStyle : css style of the content div
 *    - ContentCssClass : css class of the content div
 * 
 * 	Now we can use the functions show() and hide()
 *
 */
class TRollingFieldset extends TWebControl
{
	protected $_openstate;
	private $_CSS;
	private $_iconBaseUrl;

	public function onInit($param)
	{
		parent::onInit($param);
		$this->_iconBaseUrl = $this->getPage()->getTheme()->getBaseUrl() . '/icons/';
		$this->_openstate = true;
	}

	/**
	 * @return string the legend of the rolling fieldset.
	 */
	public function getLegend()
	{
		return $this->getControlState('Legend', '');
	}

	/**
	 * Sets the label content of the rolling fieldset.
	 * @param string the legend text to be set
	 */
	public function setLegend($value)
	{
		$this->setControlState('Legend', $value, '');
	}

	/**
	 * @return string the CSS style of the legend.
	 */
	public function getLegendStyle()
	{
		return $this->getControlState('LegendStyle', '');
	}

	/**
	 * Sets the string the CSS style of the legend.
	 * @param string the CSS style of the legend
	 */
	public function setLegendStyle($value)
	{
		$this->setControlState('LegendStyle', $value, '');
	}

	/**
	 * @return string the CSS class of the legend.
	 */
	public function getLegendCssClass()
	{
		return $this->getControlState('LegendCssClass', '');
	}

	/**
	 * Sets the string the CSS class of the legend.
	 * @param string the CSS style of the legend
	 */
	public function setLegendCssClass($value)
	{
		$this->setControlState('LegendCssClass', $value, '');
	}

	/**
	 * @return string the CSS style of the content div.
	 */
	public function getContentStyle()
	{
		return $this->getControlState('ContentStyle', '');
	}

	/**
	 * Sets the string the CSS style of the content div.
	 * @param string the CSS style of the content div
	 */
	public function setContentStyle($value)
	{
		$this->setControlState('ContentStyle', $value, '');
	}

	/**
	 * @return string the CSS class of the content div.
	 */
	public function getContentCssClass()
	{
		return $this->getControlState('ContentCssClass', '');
	}

	/**
	 * Sets the string the CSS class of the content div.
	 * @param string the CSS style of the content div
	 */
	public function setContentCssClass($value)
	{
		$this->setControlState('ContentCssClass', $value, '');
	}

	/**
	 * Sets the string the CSS class of the whole fieldset.
	 * @param string the CSS style of the whole fieldset
	 */
	public function getCssClass()
	{
		return $this->getControlState('CssClass', '');
	}

	/**
	 * Sets the string the CSS class of the whole fieldset.
	 * @param string the CSS style of the whole fieldset
	 */
	public function setCssClass($value)
	{
		$this->setControlState('CssClass', $value, '');
	}

	/**
	 * Sets the rendering template of the whole fieldset.
	 * @param string the style to be set
	 */
	public function setStyle($value)
	{
		$this->_CSS = $value;
		$this->setControlState('CSS', $value);
	}

	/**
	 * Sets the rendering template of the whole fieldset.
	 * @param string the style to be set
	 */
	public function getStyle()
	{
		return $this->getControlState('CSS');
	}

	/**
	 * @return string the rendering template of the wrapping window as string
	 */
	public function getStyleAsString()
	{
		//return $this->getControlState('Style',0);
		return $this->_CSS;
	}

	/**
	 * @return boolean whether the rolling fieldset is open or closed
	 */
	public function getOpen()
	{
		$key = $this->getKey();

		if ($_COOKIE[$key] == 'show')
			return "true";
		else if ($_COOKIE[$key] == 'hide')
			return "false";
	}

	/**
	 * Sets the value indicating whether the control has to be opened (wrapped) or closed (unwrapped)
	 * @param boolean open/close of the control
	 */
	public function setOpen($value)
	{
		if (strtoupper($value) == "TRUE")
			$this->_openstate = true;
		elseif (strtoupper($value) == "FALSE")
			$this->_openstate = false;
	}

	/**
	 * manage the cookie creation
	 *
	 * @param string $key : the cookie name
	 * @param boolean $value : true or false 
	 */
	protected function manage_ShowCookie($key, $value)
	{

		if (!isset($_COOKIE[$key]))   ///NB se faccio cosi' non riesco a settare il valore in postback! 	
		{
			if ($value)
				setcookie($key, 'show', time() + 60 * 60 * 24 * 30);
			else
				setcookie($key, 'hide', time() + 60 * 60 * 24 * 30);
		}
	}
	//NEW RENDER (v3x)
	/* V3 renderer interface */

	/**
	 * Renders the begin tag
	 *
	 * @param THtmlWriter $writer
	 */
	function renderBeginTag($writer)
	{
		//SET COOKIE
		$key = $this->getKey();
		$this->manage_ShowCookie($key, $this->_openstate);

		$content = $this->writeHeader() . "\n";
		$content .= "<fieldset id=\"" . $this->getClientID() . "\" style=\"" . $this->getStyleAsString() . "\" class=\"" . $this->getCssClass() . "\" >\n";
		$content .= "	<legend style=\"" . $this->getLegendStyle() . "\" class=\"" . $this->getLegendCssClass() . "\">" . $this->getLegend()
				. " <img id=\"" . $this->getClientID() . "_icon\" align=\"absmiddle\" src=\""
				. $this->_iconBaseUrl . "/navigate_open.png\" onclick=\"openClose('" . $this->getClientID() . "_div',this, '"
				. $this->_iconBaseUrl . "/navigate');\" > </legend>\n";
		$content .= "	<div id=\"" . $this->getClientID() . "_div\" style=\"" . $this->getContentStyle() . "\" class=\"" . $this->getContentCssClass() . "\" >\n";

		$writer->write($content);

		parent::renderBeginTag($writer);
	}
	/* V3 renderer interface */

	/**
	 * Renders the close tag, plus the end script
	 *
	 * @param THtmlWriter $writer
	 */
	function renderEndTag($writer)
	{
		$content = '';
		parent::renderEndTag($writer);

		$content .= "\n</div></fieldset>\n" . $this->writeTail();
		$content .= "\n";
		$writer->write($content);
	}

	/**
	 * register the javascripts
	 *
	 * @param unknown_type $param
	 */
	public function onPreRender($param)
	{
		parent::onPreRender($param);

		$scripts = $this->getPage()->getClientScript();
		$scripts->registerPradoScript('prado');
		$scripts->registerPradoScript('effects');
		if (!$scripts->isScriptFileRegistered('TRollingWindow.js'))
			$scripts->registerScriptFile('TRollingWindow.js', $this->publishFilePath(Prado::getPathOfNamespace('Application.Javascript')) . '/RollingFunctions.js');
	}

	/**
	 * Unused
	 *
	 * @return unknown
	 */
	protected function writeHeader()
	{

		$head = '';
		$path = '';  //to be completed...

		return $head;
	}

	/**
	 * Add a autorun script for the first state of the control
	 *
	 * @return unknown
	 */
	protected function writeTail()
	{

		$tail = '';
		//
		$tail = "<script>\n";
		$tail .= "  checkVisible('" . $this->getClientID() . "_div',$('" . $this->getClientID() . "_icon'), '" . $this->_iconBaseUrl . "/navigate');\n";
		$tail .= "</script>\n";

		return $tail;
	}

	/**
	 * Set programmatically the open state of the rolling window
	 *
	 * @param boolean $value
	 */
	function setUserOpen($value)
	{
		if (is_bool($value))
		{
			$key = $this->getKey();
			if ($value == true)
			{
				setcookie($key, 'show', time() + 60 * 60 * 24 * 30);
			}
			else
			{
				setcookie($key, 'hide', time() + 60 * 60 * 24 * 30);
			}
		}
	}

	public function getKey()
	{
		return 'UI_' . $this->getClientID() . '_div';
	}

	public function show()
	{
		setcookie($this->getKey(), 'show');
	}

	public function hide()
	{
		setcookie($this->getKey(), 'hide');
	}
}