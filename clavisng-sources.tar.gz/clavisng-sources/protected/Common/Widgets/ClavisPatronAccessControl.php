<?php
/**
 * ClavisPatronAccessControl class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Widgets
 */

/**
 * ClavisPatronAccessControl Class
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Widgets
 * @since 2.6.1
 */
class ClavisPatronAccessControl extends TTemplateControl {

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsPostBack())
		{
			$this->populate();
			$this->getPage()->setFocus($this->CheckIn->getClientID());
		}
	}

	public function populate()
	{
		$ds = array();

		$pageSize = $this->CheckInGrid->getPageSize();
		$currentIndexPage = $this->CheckInGrid->getCurrentPage();
		$q = PatronActionQuery::create()
			->filterByActionType(PatronActionPeer::ACTION_CHECKIN)
			->filterByActionDate(date('Y-m-d'), Criteria::GREATER_EQUAL)
			->orderByActionDate(Criteria::DESC);
		$count = $q->count();
		$checkIns = $q->limit($pageSize)
			->offset($currentIndexPage * $pageSize)
			->find();
		/* @var $ch PatronAction */
		foreach ($checkIns as $ch) {
			$note = '';
			if ($key = $ch->getActionKey()) {
				$literalKey = LibraryValuePeer::getLibraryValue('ACCESSKEY', $key);
				if (!$literalKey)
					$literalKey = $key;
				$note .= Prado::localize("{key}<br/>", array('key' => $literalKey));
			}
			$p = $ch->getPatron();
			if (!$p instanceof Patron)
				continue;
			if ($p->getPatronStatus() != PatronPeer::STATUS_ENABLED)
				$note .= '<img src="themes/Default/icons/warning.png" title="'.
					$p->getPatronStatusString().'"/> '.$p->getPatronStatusString();
			$ds[] = array(
				'CheckIn'	=> $ch->getActionDate('U'),
				'Barcode'	=> $p->getBarcode(),
				'Name'		=> $p->getCompleteName(),
				'PatronId'	=> $p->getPatronId(),
				'Note'		=> $note
			);
		}
		$this->CheckInGrid->setDataSource($ds);
		$this->CheckInGrid->setVirtualItemCount($count);
		$this->CheckInGrid->dataBind();

		$ds = array();
		$pageSize = $this->CheckOutGrid->getPageSize();
		$currentIndexPage = $this->CheckOutGrid->getCurrentPage();
		$q = PatronActionQuery::create()
			->filterByActionType(PatronActionPeer::ACTION_CHECKOUT)
			->filterByActionDate(date('Y-m-d'), Criteria::GREATER_EQUAL)
			->orderByActionDate(Criteria::DESC);
		$count = $q->count();
		$checkOuts = $q->limit($pageSize)
			->offset($currentIndexPage * $pageSize)
			->find();
		/* @var $ch PatronAction */
		foreach ($checkOuts as $ch) {
			$note = '';
			if ($key = $ch->getActionKey()) {
				$literalKey = LibraryValuePeer::getLibraryValue('ACCESSKEY', $key);
				if (!$literalKey)
					$literalKey = $key;
				$note .= Prado::localize("{key}<br/>", array('key' => $literalKey));
			}
			$p = $ch->getPatron();
			if (!$p instanceof Patron)
				continue;
			if ($p->getPatronStatus() != PatronPeer::STATUS_ENABLED)
				$note .= '<img src="themes/Default/icons/warning.png" title="'.
					$p->getPatronStatusString().'"/> '.$p->getPatronStatusString();
			$ds[] = array(
				'CheckOut'	=> $ch->getActionDate('U'),
				'Barcode'	=> $p->getBarcode(),
				'Name'		=> $p->getCompleteName(),
				'PatronId'	=> $p->getPatronId(),
				'Note'		=> $note
			);
		}
		$this->CheckOutGrid->setDataSource($ds);
		$this->CheckOutGrid->setVirtualItemCount($count);
		$this->CheckOutGrid->dataBind();

		$ds = array();
		$pageSize = $this->PresenceGrid->getPageSize();
		$currentIndexPage = $this->PresenceGrid->getCurrentPage();
		$q = PatronQuery::create()
			->filterByCheckOut(null)
			->filterByCheckIn(date('Y-m-d'), Criteria::GREATER_EQUAL)
			->filterByCheckIn(null, Criteria::NOT_EQUAL)
			->orderByCheckIn(Criteria::DESC);
		$count = $q->count();
		$presence = $q->limit($pageSize)
			->offset($currentIndexPage * $pageSize)
			->find();
		/* @var $p Patron */
		foreach ($presence as $p) {
			$note = '';
			if ($p->getPatronStatus() != PatronPeer::STATUS_ENABLED)
				$note = '<img src="themes/Default/icons/warning.png" title="'.
					$p->getPatronStatusString().'"/> '.$p->getPatronStatusString();
			$ds[] = array(
				'CheckIn'	=> $p->getCheckIn('U'),
				'Barcode'	=> $p->getBarcode(),
				'Name'		=> $p->getCompleteName(),
				'PatronId'	=> $p->getPatronId(),
				'Note'		=> $note
			);
		}
		$this->PresenceGrid->setDataSource($ds);
		$this->PresenceGrid->setVirtualItemCount($count);
		$this->PresenceGrid->dataBind();
	}

	public function onChangeCheckInPage($sender, $param)
	{
		$this->CheckInGrid->setCurrentPage($param->NewPageIndex);
		$this->populate();
	}

	public function onChangeCheckOutPage($sender, $param)
	{
		$this->CheckOutGrid->setCurrentPage($param->NewPageIndex);
		$this->populate();
	}

	public function onChangePresencePage($sender, $param)
	{
		$this->PresenceGrid->setCurrentPage($param->NewPageIndex);
		$this->populate();
	}

	/*
	 * Return true if at least one action exists and last action's type is $type
	 * Used into check IN/OUT event
	 */
	public function checkLastPatronActionType($patronid, $type)
	{
	    $lastaction = PatronActionQuery::create()
	    ->filterByPatronId($patronid)
	    ->orderByActionDate(Criteria::DESC)
	    ->findOne();
	    
	    return($lastaction instanceof PatronAction && $type == $lastaction->getActionType());
	}
	
	public function registerCheckIn($sender, $param)
	{
		if (!$this->CheckIn->getIsValid())
			return;
		$p = PatronPeer::getPatronByBarcode($this->CheckIn->getText());
		$access_key = ($this->AccessKey->getSelectedIndex() > 0)
			? $this->AccessKey->getSelectedValue() : null;
		if ($p instanceof Patron) {
		    if ($this->checkLastPatronActionType($p->getPatronId(), PatronActionPeer::ACTION_CHECKIN)) {
				$this->getPage()->writeMessage(Prado::localize('Ingresso già registrato senza uscita, effettuare prima il check-out.'),
					ClavisMessage::ERROR);
			} else {
				$log = PatronActionPeer::patronCheckIn($p,
					$this->getUser()->getActualLibraryId(),
					new DateTime($this->CheckInTime->getText()),
					$access_key);
				if ($log instanceof PatronAction)
					$this->getPage()->writeMessage(Prado::localize('Ingresso registrato correttamente.'), ClavisMessage::CONFIRM);
			}
		} else {
			$this->getPage()->writeMessage(Prado::localize('Barcode non riconosciuto.'), ClavisMessage::ERROR);
		}
		$this->CheckIn->setText('');
		$this->CheckInTime->setText('');
		$this->populate();
	}

	public function registerCheckOut($sender, $param)
	{
		if (!$this->CheckOut->getIsValid())
			return;
		$p = PatronPeer::getPatronByBarcode($this->CheckOut->getText());
		$access_key = ($this->AccessKey->getSelectedIndex() > 0)
			? $this->AccessKey->getSelectedValue() : null;
		if ($p instanceof Patron) {
		    if ($this->checkLastPatronActionType($p->getPatronId(), PatronActionPeer::ACTION_CHECKOUT)) {
				$this->getPage()->writeMessage(Prado::localize('Uscita già registrata senza nuovo ingresso, effettuare prima il check-in.'),
					ClavisMessage::ERROR);
			} else {
				$log = PatronActionPeer::patronCheckOut($p,
					$this->getUser()->getActualLibraryId(),
					new DateTime($this->CheckOutTime->getText()),
					$access_key);
				if ($log instanceof PatronAction)
					$this->getPage()->writeMessage(Prado::localize('Uscita registrata correttamente.'), ClavisMessage::CONFIRM);
			}
		} else {
			$this->getPage()->writeMessage(Prado::localize('Barcode non riconosciuto.'), ClavisMessage::ERROR);
		}
		$this->CheckOut->setText('');
		$this->CheckOutTime->setText('');
		$this->populate();
	}

	public function validateCheckIn($sender, $param)
	{
		$valid = true;
		$p = PatronPeer::getPatronByBarcode($this->CheckIn->getText());
		if (!$p instanceof Patron) {
			$this->InCustomValidation->setErrorMessage(Prado::localize('Barcode non riconosciuto'));
			$valid = false;
		} else if($this->checkLastPatronActionType($p->getPatronId(), PatronActionPeer::ACTION_CHECKIN)) {
			$this->InCustomValidation->setErrorMessage(
				Prado::localize('Ingresso già registrato senza uscita, effettuare prima il check-out.'));
			$valid = false;
		}
		if (!is_null($param))
			$param->IsValid = $valid;
		return $valid;
	}

	public function validateCheckOut($sender, $param)
	{
		$valid = true;
		$p = PatronPeer::getPatronByBarcode($this->CheckOut->getText());
		if (!$p instanceof Patron) {
			$this->OutCustomValidation->setErrorMessage(Prado::localize('Barcode non riconosciuto'));
			$valid = false;
		} else if ($this->checkLastPatronActionType($p->getPatronId(), PatronActionPeer::ACTION_CHECKOUT)) {
			$this->OutCustomValidation->setErrorMessage(
				Prado::localize('Uscita già registrata senza nuovo ingresso, effettuare prima il check-in.'));
			$valid = false;
		} else if ($this->CheckOutTime->getText()
				&& $this->CheckOutTime->getText() < $p->getCheckIn('H:i')) {
			$this->OutCustomValidation->setErrorMessage(
				Prado::localize('L\'orario di uscita è precedente a quello dell\'ultimo ingresso.'));
			$valid = false;
		}
		if (!is_null($param))
			$param->IsValid = $valid;
		return $valid;
	}

	public function autoCheckout($sender, $param)
	{
		$count = PatronActionPeer::expireYesterdayChecks();
		$this->getPage()->writeMessage(Prado::localize('Uscita forzata per {count} utenti.', array('count' => $count)), ClavisMessage::CONFIRM);
		$this->populate();
	}

	public function onPrintJRPAccessControl($sender, $param)
	{
		$this->JRPBox->printReport();
	}

}
