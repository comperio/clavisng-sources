<?php
/**
 * ClavisLibraryList class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Widgets
 */

/**
 * ClavisLibraryList Class
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @author Ciro Mattia Gonano
 * @version 2.8.7
 * @package Widgets
 * @since 2.0
 */
class ClavisLibraryList extends TTemplateControl
{
	private $_librarian;

	public  $_masterChecked;
	private $_checked = array('all' => false);
	private $_checkedSessionName;
	private $_datasource;
	private $_datasourceSessionName;
	private $_globalCriteriaSessionName;
	public  $_onlySelectedSessionName;

	private function initVars()
	{
		$uniqueId = $this->getUniqueID();
		$this->_checkedSessionName = 'CheckedSessionName' . $uniqueId;
		$this->_datasourceSessionName = 'DatasourceSessionName' . $uniqueId;
		$this->_globalCriteriaSessionName = 'GlobalCriteriaSessionName' . $uniqueId;
		$this->_onlySelectedSessionName = 'OnlySelectedSessionName' . $uniqueId;
	}

	public function onInit($param)
	{
		parent::onInit($param);
		$this->initVars();

		$this->_checked = $this->getChecked();
		$this->_masterChecked = $this->_checked['all'];
	}

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsPostBack())
		{
			$this->resetDataSource();
			$this->getPage()->setFocus($this->LabelFilter->getClientID());
		}
	}

	public function getViewOpen()
	{
		return $this->getViewState('ViewOpen', false);
	}

	public function setViewOpen($view = false)
	{
//		if (($view === 'true') || ($view === true))
//		{
//			$flag = true;
//		}
//		elseif (($view === 'false') || ($view === false))
//		{
//			$flag = false;
//		}
//		else
//		{
//			$flag = false;
//		}

		switch ($view)
		{
			case 'true':
			case true:
				$flag = true;
				break;
			
			case 'false':
			case false:
			default:
				$flag = false;
		}
		
		$this->setViewState('ViewOpen', $flag, false);
	}
	
	public function setLibrarian($librarian)
	{
		$this->_librarian = $librarian;
		$this->setViewState("librarian", $librarian, null);
	}

	public function getLibrarian()
	{
		if (is_null($this->_librarian))
			$this->_librarian = $this->getViewState("librarian", null);
		
		return $this->_librarian;
	}

	public function setEnablePagination($enablePagination = 'true')
	{
		$this->setViewState('EnablePagination', $enablePagination, 'true');
	}

	public function getEnablePagination()
	{
		$flag = $this->getViewState('EnablePagination', 'true');
		
		switch ($flag)
		{
			case 'false':
				$enablePagination = false;
				break;
		
			case 'true':
			default:
				$enablePagination = true;
		}
		
		return $enablePagination;
	}

	public function setOnlyExternal($param = 'false')
	{
		$this->setViewState('OnlyExternal', $param, 'false');
	}

	public function getOnlyExternal()
	{
		$flag = $this->getViewState('OnlyExternal', 'false');
		
		switch ($flag)
		{
			case 'true':
				$value = true;
				break;
		
			case 'false':
			default:
				$value = false;
		}
		
		return $value;
	}

	public function resetChecked($state = false)
	{
		$this->setChecked(array('all' => $state));
	}
	
	public function setChecked($checked = null)
	{
		$this->_checked = $checked;
		$this->getApplication()->getSession()->add($this->_checkedSessionName, $checked);
	}

	public function getChecked()
	{
		$this->_checked = $this->getApplication()->getSession()->itemAt($this->_checkedSessionName);
		
		return $this->_checked;
	}

	public function setGlobalCriteria($criteria = null)
	{
		$this->getApplication()->getSession()->add($this->_globalCriteriaSessionName, $criteria, null);
	}

	public function getGlobalCriteria()
	{
		return SerializableCriteria::refreshCriteria($this->getApplication()->getSession()->itemAt($this->_globalCriteriaSessionName, null));
	}

	public function setMultiSelect($value)
	{
		$this->setControlState('MultiSelect', $value, false);
	}
	
	public function getMultiSelect()
	{
		return $this->getControlState('MultiSelect', false);
	}

	public function setExternalIds($value)
	{
		$this->setControlState('ExternalIds', $value, array());
	}
	
	public function getExternalIds()
	{
		return $this->getControlState('ExternalIds', array());
	}
	
	public function resetOnlySelected($value = false)
	{
		$this->setOnlySelected($value);
	}

	public function setOnlySelected($flag = false)
	{
		if ($flag === 'false')
			$flag = false;
		
		if ($flag === 'true')
			$flag = true;

		$this->getApplication()->getSession()->add($this->_onlySelectedSessionName, $flag, false);
	}

	public function getOnlySelected()
	{
		$flag = $this->getApplication()->getSession()->itemAt($this->_onlySelectedSessionName);
		
		return $flag;
	}

	public function resetDataSource()
	{
		$this->resetChecked();
		$this->resetOnlySelected();
		$this->_datasource = array();
		$this->getApplication()->getSession()->add($this->_datasourceSessionName, $this->_datasource);
		$this->populate();
	}

	public function getDatasource()
	{
		$this->_datasource = $this->getApplication()->getSession()->itemAt($this->_datasourceSessionName, null);
		
		return $this->_datasource;
	}

	public function setDataSource($ds)
	{
		$this->_datasource = $ds;
		$this->getApplication()->getSession()->add($this->_datasourceSessionName, $this->_datasource, null);
	}

	public function getCheckedIds($force = false)
	{
		$checked = $this->getChecked();
		$masterChecked = $checked['all'];
		unset($checked['all']);
		$checkedIds = array_keys($checked);
		$output = array();

		if (!$masterChecked)
		{
			$output = $checkedIds;
		}
		else         // this is a case of inverse mastercheck
		{
			$criteriaArray = $this->getGlobalCriteria();

			if (!is_null($criteriaArray)
					&& ($criteriaArray['type'] == 'givenIds')) 
			{
				$libraryIds = $criteriaArray['body'];
				$output = array_diff($libraryIds, $checkedIds);
			}
			elseif (!is_null($criteriaArray)
					&& ($criteriaArray['type'] == 'normal'))
			{
				$criteria = $criteriaArray['body'];
				
//				list ($labelFilter, $activeFilter, $externalFilter, $openFilter) = $criteria;
//				$libraryIds = LibraryQuery::create()->select('LibraryId');
//				if ($labelFilter)
//					$libraryIds->filterByDescription("%{$labelFilter}%");
//				if ($activeFilter)
//					$libraryIds->filterByLibraryStatus($activeFilter);
//				if ($externalFilter)
//					$libraryIds->filterByLibraryInternal(1, 1 == $externalFilter ? Criteria::EQUAL : Criteria::NOT_EQUAL);
//				if ('1' == $openFilter)
//					$libraryIds->useLibraryTimetableQuery()
//							->filterByTimetableDay(date('Y-m-d'))
//							->filterByTimetableOpen(true)
//						->endUse();
//				if ('-1' == $openFilter)
//					$libraryIds->useLibraryTimetableQuery()
//							->filterByTimetableDay(date('Y-m-d'))
//							->filterByTimetableOpen(false)
//						->endUse();
//				$output = array_diff($libraryIds->find()->toArray(), $checkedIds);
				
				list (	$labelFilter,
						$libraryCodeFilter,
						$illCodeFilter,
						$sbnCodeFilter,
						$activeFilter,
						
						$externalFilter,
						$selectedIds,
						$openFilter) = $criteria;
				
				$libraryIds = LibraryPeer::extractLibraryIds(	$labelFilter,
																$libraryCodeFilter,
																$illCodeFilter,
																$sbnCodeFilter,
																$activeFilter, 
																
																$externalFilter, 
																$selectedIds,
																$checkedIds,
																$openFilter);
			
				$output = $libraryIds;
			}
		}

		if ((count($output) == 0)
				&& ($force == true))
		{
			$this->setMasterChecked(true);
			$output = $this->getCheckedIds();
		}

		return $output;
	}

	public function getCheckedItems($force = false)
	{
		$checked = $this->getChecked();
		$masterChecked = $checked['all'];
		unset($checked['all']);
		$checkedIds = array_keys($checked);
		$output = array();

		if (!$masterChecked)
		{	
			$output = LibraryQuery::create()
						->findPks($checkedIds);
		}
		else         // this is the case of inverse mastercheck
		{
			$libraries = array();
			$criteriaArray = $this->getGlobalCriteria();

			if (!is_null($criteriaArray)
					&& ($criteriaArray['type'] == 'givenIds'))
			{
				$libraryIds = $criteriaArray['body'];
				$outputIds = array_diff($libraryIds, $checkedIds);

				$libraries = LibraryQuery::create()
								->findPks($outputIds);
			}
			elseif (!is_null($criteriaArray)
					&& ($criteriaArray['type'] == 'librarian'))
			{
				$criteria = $criteriaArray['body'];
				list (	$librarian, 
						$labelFilter, 
						$libraryCodeFilter,
						$illCodeFilter,
						$sbnCodeFilter,
						
						$activeFilter, 
						$externalFilter, 
						$except) = $criteria;

				$libraries = $librarian->extractLLibraryLibrarian(	null,
																	null, 
																	$labelFilter,
																	$libraryCodeFilter,
																	$illCodeFilter,
																	
																	$sbnCodeFilter,
																	$activeFilter, 
																	$externalFilter, 
																	$except, 
																	$checkedIds);
			}
			elseif (!is_null($criteriaArray)
					&& ($criteriaArray['type'] == 'normal'))
			{
				$criteria = $criteriaArray['body'];
				
				list (	$labelFilter, 
						$libraryCodeFilter,
						$illCodeFilter,
						$sbnCodeFilter,
						$activeFilter, 
						
						$externalFilter,
						$selectedIds,
						$openFilter) = $criteria;
				
				$libraries = LibraryPeer::extractLibraries(	null, 
															null, 
															$labelFilter,
															$libraryCodeFilter,
															$illCodeFilter,
						
															$sbnCodeFilter,
															$activeFilter, 
															$externalFilter, 
															$selectedIds,
															$checkedIds,	// to exclude

															$openFilter);
			}
			
			$output = $libraries;
		}

		if ((count($output) == 0)
				&& ($force == true))
		{
			$this->setMasterChecked(true);
			$output = $this->getCheckedItems();
		}

		return $output;
	}

	public function countCheckedItems($force = false)
	{
		$checked = $this->getChecked();
		$masterChecked = $checked['all'];
		unset($checked['all']);
		$checkedIds = array_keys($checked);
		$output = array();

		if (!$masterChecked)
		{
			$output = count($checkedIds);
		}
		else         // inverse mastercheck
		{
			$criteriaArray = $this->getGlobalCriteria();

			if (!is_null($criteriaArray)
					&& ($criteriaArray['type'] == 'givenIds'))
			{
				$libraryIds = $criteriaArray['body'];
				$outputIds = array_diff($libraryIds, $checkedIds);
				$librariesCount = count($outputIds);
			}
			elseif (!is_null($criteriaArray)
					&& ($criteriaArray['type'] == 'librarian'))
			{
				$criteria = $criteriaArray['body'];
				list (	$librarian, 
						$labelFilter, 
						$libraryCodeFilter,
						$illCodeFilter,
						$sbnCodeFilter,
						
						$except) = $criteria;
				$librariesCount = $librarian->countLLibraryLibrarian(	$labelFilter,
																		$libraryCodeFilter,
																		$illCodeFilter,
																		$sbnCodeFilter,
																		null,
						
																		null,
																		$except, 
																		$checkedIds);
			}
			elseif (!is_null($criteriaArray)
					&& ($criteriaArray['type'] == 'normal'))
			{
				$criteria = $criteriaArray['body'];

				list (	$labelFilter, 
						$libraryCodeFilter,
						$illCodeFilter,
						$sbnCodeFilter,
						$activeFilter, 
						
						$externalFilter,
						$selectedIds,
						$openFilter) = $criteria;
				
				$librariesCount = LibraryPeer::countLibraries(		$labelFilter, 
																	$libraryCodeFilter,
																	$illCodeFilter,
																	$sbnCodeFilter,
																	$activeFilter,
																	
																	$externalFilter,
																	$selectedIds,
																	$checkedIds,	// to exclude
																	$openFilter);
			}

			$output = $librariesCount;
		}

		return $output;
	}

	public function getMasterChecked()
	{
		$checked = $this->getChecked();
		
		return $checked['all'];
	}

	public function onOnlySelected($sender, $param)
	{
		$checked = $sender->getChecked();
		$this->setOnlySelected($checked);

		$this->LibraryGrid->resetPagination();
		$this->clearFilters();
		$this->populate();
	}

	public function populate()
	{
		$this->populateLibraryGrid();
	}

	private function populateLibraryGrid()
	{
		/* @var $library Library */

		$pageSize = ($this->getEnablePagination()
						? $this->LibraryGrid->getPageSize()
						: 0);
		
		$currentIndexPage = $this->LibraryGrid->getCurrentPage();

		if ($this->getOnlyExternal())
		{
			$this->ExternalFilter->setSelectedValue('0');
			$externalFilter = '0';
		}

		$labelFilter = $this->LabelFilter->getSafeText();
		$libraryCodeFilter = $this->LibraryCodeFilter->getSafeText();
		$illCodeFilter = $this->IllCodeFilter->getSafeText();
		$sbnCodeFilter = $this->SbnCodeFilter->getSafeText();
		
		$externalFilter = $this->ExternalFilter->getSelectedValue();

		if (($this->ExternalFilter->getSelectedIndex() < 1) 
				|| ($externalFilter == '---'))
			$externalFilter = null;

		$activeFilter = $this->ActiveFilter->getSelectedValue();
		
		if (($this->ActiveFilter->getSelectedIndex() < 1) 
				|| ($activeFilter == '---'))
			$activeFilter = null;

		$openFilter = $this->OpenFilter->getSelectedValue();
		
		if (($this->OpenFilter->getSelectedIndex() < 1) 
				|| ($activeFilter == '---'))
			$openFilter = null;

		$librarian = $this->getLibrarian();
		$except = $this->getPopupFlag();
		
		$selectedIds = $this->getExternalIds();

//		if (count($externalIds) > 0)
//		{
//			$libraries = LibraryQuery::create()
//							->setLimit($pageSize)
//							->setOffset($currentIndexPage * $pageSize)
//							->findPks($externalIds);
//			
//			$recCount = count($externalIds);
//			
//			$this->setGlobalCriteria(array(	'type' => 'givenIds',
//											'body' => $externalIds));
//		}
		
		if (!is_null($givenIds = $this->getCheckedItems())
				&& $this->getOnlySelected())
		{
			$libraries = $givenIds;
			$recCount = count($libraries);
			$onlyIds = array();

			foreach ($libraries as $lib)
				$onlyIds[] = $lib->getLibraryId();

			$this->setGlobalCriteria(array(	'type' => 'givenIds',
											'body' => $onlyIds ));
		}		
		elseif ($librarian instanceof Librarian)
		{
			$libraries = $librarian->extractLLibraryLibrarian(	$currentIndexPage, 
																$pageSize, 
																$labelFilter, 
																$libraryCodeFilter,
																$illCodeFilter,
					
																$sbnCodeFilter,
																$activeFilter, 
																$externalFilter, 
																$except);
			
			$recCount = $librarian->countLLibraryLibrarian(	$labelFilter, 
															$libraryCodeFilter,
															$illCodeFilter,
															$sbnCodeFilter,
															$activeFilter, 
															
															$externalFilter, 
															$except);

			$this->setGlobalCriteria(array(	'type' => 'librarian', 
											'body' => array(	$librarian,
																$labelFilter,
																$libraryCodeFilter,
																$illCodeFilter,
																$sbnCodeFilter,
												
																$activeFilter,
																$externalFilter,
																$except )));
		}
		else
		{
			$libraries = LibraryPeer::extractLibraries(	$currentIndexPage, 
														$pageSize, 
														$labelFilter, 
														$libraryCodeFilter,
														$illCodeFilter,
					
														$sbnCodeFilter,
														$activeFilter, 
														$externalFilter,
														$selectedIds,
														null,

														$openFilter);
			
			$recCount = LibraryPeer::countLibraries(	$labelFilter, 
														$libraryCodeFilter,
														$illCodeFilter,
														$sbnCodeFilter,
														$activeFilter, 
														
														$externalFilter,
														$selectedIds,
														null,
														$openFilter);
			
			$this->setGlobalCriteria(array(	'type' => 'normal',
											'body' => array(	$labelFilter, 
																$libraryCodeFilter,
																$illCodeFilter,
																$sbnCodeFilter,
																$activeFilter, 
																
																$externalFilter,
																$selectedIds,
																$openFilter )));
		}

		$this->LibraryGrid->setVirtualItemCount($recCount);

		if (!$this->getOnlySelected())
			$this->FoundNumber->setText($recCount);

		$data = array();
		foreach ($libraries as $library)
		{
			/* @var $library Library */
			$p = array();

			if (!($library instanceof Library))
				Prado::fatalError(Prado::varDump($libraries));
			
			$libraryId = $library->getLibraryId();
			$p['Id'] = $libraryId;

			if (isset($this->_checked[$libraryId]))
			{
				$checked = $this->_checked[$libraryId];
			}
			else
			{
				$checked = false;
			}

			if ($this->_checked['all'])
				$checked = !$checked;

			$p['Checked'] = $checked;
			$p['Description'] = $library->getDescription();
			
			// check if description is empty, if so fallback to label and then to a
			// warning label.
			if (!$p['Description'])
				$p['Description'] = $library->getLabel();
			
			if (!$p['Description'])
				$p['Description'] = Prado::localize('nessuna etichetta o descrizione, ID: {libid}',
														array('id' => $library->getLibraryId()));
			
			$p['Label'] = $library->getLabel(true, true);

			if (!$p['Label'])
				$p['Label'] = Prado::localize('nessuna etichetta, ID: {libid}',
												array('id' => $library->getLibraryId()));

			$p['ShortLabel'] = $library->getShortlabel();
			$p['LibraryCode'] = trim($library->getLibraryCode());
			$p['IllCode'] = trim($library->getIllCode());
			$p['SbnCode'] = trim($library->getSbnCode());
			
			$comboArray = array(	$p['LibraryCode'],
									$p['IllCode'],
									$p['SbnCode'],
									$p['ShortLabel'] );

			foreach ($comboArray as $index => $element)
			{
				if (!$element)
					unset ($comboArray[$index]);
			}
			
			$p['ComboCode'] = implode('<br />', $comboArray);
			
			$p['Phone'] = $library->getPhone();
			$p['LibraryClass'] = LookupValuePeer::getLookupValue('LIBCLASS', $library->getLibraryClass());
			$p['LibraryType'] = $library->getLibraryTypeString();
			$p['Active'] = $library->getLibraryStatus() == LibraryPeer::STATUS_ACTIVE;
			$p['Email'] = $library->getEmail();
			$p['City'] = $library->getCity();
			$p['CanEdit'] = $this->getUser()->getEditPermission($library);
			
			if ($this->getViewOpen())
			{
				switch ($library->isLibraryOpen()) 
				{
					case LibraryPeer::CLOSED:
						$openImageUrl = "themes/Default/icons/library_closed.png";
						$openImageToolTip = Prado::localize("la biblioteca è chiusa oggi");
						break;

					case LibraryPeer::PAUSE:
						$openImageUrl = "themes/Default/icons/library_pause.png";
						$openImageToolTip = Prado::localize("la biblioteca è aperta oggi, ma non in questo momento");
						break;
					
					case LibraryPeer::OPEN:
						$openImageUrl = "themes/Default/icons/library_open.png";
						$openImageToolTip = Prado::localize("la biblioteca è aperta, in questo momento");
						break;

					case LibraryPeer::NOTSETOPEN:
					default:
						$openImageUrl = "";
						$openImageToolTip = "";
						break;
				}
			}
			else
			{
				$openImageUrl = "";
				$openImageToolTip = "";
			}

			$p['OpenImageUrl'] = $openImageUrl;
			$p['OpenImageToolTip'] = $openImageToolTip;
			
			$data[] = $p;
		}

		$this->LibraryGrid->setEnablePagination($this->getEnablePagination());
		$this->LibraryGrid->setDataSource($data);
		$this->setDataSource($data);
		$this->LibraryGrid->dataBind();
	}

	public function searchLibrary($sender, $param)
	{
		$this->LibraryGrid->resetPagination();
		$this->globalRefresh();
	}

	public function onCancel()
	{
		$this->searchCancel(null, null);
		$this->getPage()->setFocus($this->LabelFilter->getClientID());
	}

	public function searchCancel($sender, $param)
	{
		$this->clearFilters();
		$this->searchLibrary(null, null);
	}

	public function clearFilters()
	{
		$this->LabelFilter->setText('');
		$this->LibraryCodeFilter->setText('');
		$this->IllCodeFilter->setText('');
		$this->SbnCodeFilter->setText('');
		$this->ActiveFilter->setSelectedIndex(-1);
		$this->ExternalFilter->setSelectedIndex(-1);
		$this->OpenFilter->setSelectedIndex(-1);
	}

	public function onChangePage($sender,$param)
	{
		$this->LibraryGrid->setCurrentPage($param->NewPageIndex);
		$this->populate();
	}

	public function globalRefresh()
	{
		$this->getPage()->globalRefresh();
	}

	public function getPopupFlag()
	{
		return $this->getPage()->IsPopup();
	}

	public function getUnlinkFlag()
	{
		return $this->getPage()->IsUnlink();
	}

	public function onFlipChecked($sender, $param)
	{
		$newChecked = $sender->getChecked();
		$index = $sender->Parent->Parent->ItemIndex;
		$dataSource = $this->getDatasource();
		$checked = $this->getChecked();
		$row = $dataSource[$index];
		$libraryId = $row['Id'];

		if ($newChecked != $checked['all'])
		{
			$checked[$libraryId] = true;
		}
		else
		{
			unset($checked[$libraryId]);
		}

		$this->setChecked($checked);
		$this->updateEmptyFlag($param);
	}

	public function onMasterChecked($sender, $param)
	{
		$this->setMasterChecked($sender->getChecked(), $param);
	}

	public function setMasterChecked($newChecked = false, $param = null)
	{
		$this->resetChecked($newChecked);

		$gridItems = $this->LibraryGrid->getItems();
		$header = $this->LibraryGrid->getHeader();

		foreach($gridItems as $item)
			$item->CheckColumn->CheckedBox->setChecked($newChecked);

		$header->CheckColumn->MasterCheck->setChecked($newChecked);
		$this->updateEmptyFlag($param);
	}

	public function updateEmptyFlag($param = null)
	{
		$count = intval($this->countCheckedItems());
		$this->SelectedNumber->setText($count);

		if ($this->getPage()->getIsCallback())
		{	
			$this->SelectedPanel->render(is_null($param)
											? $this->getPage()->createWriter()
											: $param->getNewWriter());
		}
	}

	public function onMultiSelect($sender, $param)
	{
		$idlist = $this->getCheckedIds();
		$ret = ($idlist) ? serialize($idlist) : null;
		$this->getPage()->getClientScript()->registerEndScript(__CLASS__.'_js','onReturn(\'multi\',\''.$ret.'\',true);');
	}
	
}