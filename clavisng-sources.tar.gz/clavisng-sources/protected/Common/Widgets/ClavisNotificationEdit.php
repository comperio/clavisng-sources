<?php

/**
 * @author    Ciro Mattia Gonano <ciro@comperio.it>
 * @link      http://www.comperio.it/
 * @copyright Copyright &copy; 2010 Comperio srl
 */
class ClavisNotificationEdit extends TTemplateControl
{
    public $userLibrarian;
    public $actualLibrary;
    public $smscredit;

    public $hasChatBot;
    public $hasSMS;
    public $hasPushBot;

    private $allowed_tpl_classes = array('WELCOME_MAIL');
    private $_destination;
    private $botContacts;


    public function onLoad($param)
    {
        parent::onLoad($param);

        $d = $this->getDestination();

        $this->userLibrarian = $this->getUser();
        $this->actualLibrary = $this->userLibrarian->getActualLibrary();
        $this->smscredit = $this->actualLibrary->getActualSMS();

        $contactcrit = new Criteria();
        $contactcrit->add(ContactPeer::CONTACT_TYPE, ContactPeer::TYPE_CHATBOT);
        $this->botContacts = $d->getContacts($contactcrit);

        $this->hasChatBot = (\count($this->botContacts) > 0) && (!is_null(Prado::getApplication()->getModule('chatbot')));
        $this->hasPushBot = !is_null(Prado::getApplication()->getModule('pushbot'));
        $this->hasSMS = !is_null(Prado::getApplication()->getModule('sms'));


        switch (get_class($d)) {
            case 'Patron':
                $this->Recipient->setParameter('destination_class', Prado::localize('utente'));
                $this->Recipient->setParameter('destination_name', $d->getCompleteName());
                break;
            case 'Library':
                $this->Recipient->setParameter('destination_class', Prado::localize('biblioteca'));
                $this->Recipient->setParameter('destination_name', $d->getLabel());
                break;
            default:
                break;
        }
        if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallback()) {
            $this->drawPanel();
        }
    }

    public function getDestination()
    {
        if (!$this->_destination) {
            switch ($this->getControlState('DestinationClass')) {
                case 'Patron':
                    $this->_destination = PatronPeer::retrieveByPK($this->getControlState('DestinationId'));
                    break;
                case 'Library':
                    $this->_destination = LibraryPeer::retrieveByPK($this->getControlState('DestinationId'));
                    break;
                default:
                    $this->_destination = null;
                    break;
            }
        }
        return $this->_destination;
    }

    public function setDestination($value)
    {
        if ($value instanceof Patron ||
            $value instanceof Library) {
            $this->_destination = $value;
            $this->setControlState('DestinationClass', get_class($value));
            $this->setControlState('DestinationId', $value->getId());
        }
    }

    public function drawPanelCallback($sender, $param)
    {
        $this->drawPanel();
    }

    public function drawPanel()
    {
        $this->MailPanelActive($this->MailCheck->getChecked());
        $this->SMSPanelActive($this->SMSCheck->getChecked());
        $this->BotPanelActive($this->BotCheck->getChecked());
        $this->PushPanelActive($this->PushCheck->getChecked());
    }

    public function activate()
    {

        // hack for not doing preview on checkbox change callback
        if ($this->getPage()->getCallbackEventTarget() instanceof TControl &&
            !in_array($this->getPage()->getCallbackEventTarget()->getID(), array('NotifyAllLoans')))
            $this->_active = true;
    }

    protected function MailPanelActive($value)
    {
        if ($value) {
            $ds = array(array('TemplateId' => 0, 'TemplateTitle' => '---'));
            $templates_global = DocumentTemplatePeer::getTemplates(
                $this->allowed_tpl_classes, $this->getApplication()->getGlobalization()->getCulture());
            foreach ($templates_global as $tpl)
                $ds[] = array('TemplateId' => $tpl->getDocumentTemplateId(),
                    'TemplateTitle' => $tpl->getTemplateTitle());
            /** @var $templates_global DocumentTemplate */
            $templates_mine = DocumentTemplatePeer::getTemplates(
                $this->allowed_tpl_classes, $this->getApplication()->getGlobalization()->getCulture(), $this->actualLibrary->getLibraryId(), false);
            foreach ($templates_mine as $tpl)
                $ds[] = array('TemplateId' => $tpl->getDocumentTemplateId(),
                    'TemplateTitle' => '[*] ' . $tpl->getTemplateTitle());

            $this->TplEmail->setDatasource($ds);
            $this->TplEmail->setEnabled(count($ds) > 0);
            $this->TplEmail->dataBind();
            $this->TplEmail->setSelectedIndex(0);

            $sender_ds = array();
            $librarianEmail = trim($this->userLibrarian->getEmail());
            if (!$librarianEmail)
                $librarianEmail = trim($this->actualLibrary->getEmail());
            if (!$librarianEmail)
                $librarianEmail = trim(ClavisParamQuery::getParam('CLAVISPARAM', 'AdminEmail'));
            $sender_ds[] = array(
                'name' => $this->userLibrarian->getCompleteName(),
                'email' => $librarianEmail
            );

            $libraryEmail = trim($this->actualLibrary->getEmail());
            if (!$libraryEmail)
                $libraryEmail = trim(ClavisParamQuery::getParam('CLAVISPARAM', 'AdminEmail'));
            $sender_ds[] = array(
                'name' => $this->actualLibrary->getLabel(),
                'email' => $libraryEmail);

            $sender_ds[] = array(
                'name' => $this->actualLibrary->getConsortiaString(),
                'email' => trim(ClavisParamQuery::getParam('CLAVISPARAM', 'AdminEmail')));

            foreach ($sender_ds as $k => $v)
                if (!$v['email'])
                    unset($sender_ds[$k]);
                else
                    $sender_ds[$k]['full'] = "{$v['name']} <{$v['email']}>";

            $this->EmailSender->setDataSource($sender_ds);
            $this->EmailSender->dataBind();
            $this->MailPanel->setCssClass('panel_on');
            $this->doPreview();
        } else {
            $this->EmailSender->setDataSource(array());
            $this->MailPanel->setCssClass('panel_off');
        }
    }

    protected function SMSPanelActive($value)
    {
        if ($value) {
            $sender_ds = array();
            $sender_ds[] = preg_replace('/[^+\d]/', '', $this->actualLibrary->getPhone());
            $liblabel = trim($this->actualLibrary->getShortlabel());
            if (!$liblabel)
                $liblabel = substr($this->actualLibrary->getLabel(), 0, 11);
            $sender_ds[] = $liblabel;
            $sender_ds[] = $this->actualLibrary->getConsortiaString(11);
            foreach ($sender_ds as $k => $v)
                if (!$v)
                    unset($v);
            $this->SMSSender->setDataSource($sender_ds);
            $this->SMSSender->dataBind();
            $this->SMSPanel->setCssClass('panel_on');
        } else {
            $this->SMSSender->setDataSource(array());
            $this->SMSSender->dataBind();
            $this->SMSPanel->setCssClass('panel_off');
        }
    }

    protected function BotPanelActive($value)
    {
        $this->BotPanel->setCssClass($value ? 'panel_on' : 'panel_off');
    }

    protected function PushPanelActive($value)
    {
        $this->PushPanel->setCssClass($value ? 'panel_on' : 'panel_off');
    }

    public function updatePreview($sender, $param)
    {
        $this->doPreview();
    }

    protected function doPreview()
    {
        if ($this->TplEmail->getSelectedIndex() > 0 &&
            ($tpl = DocumentTemplatePeer::retrieveByPK($this->TplEmail->getSelectedValue())) instanceof DocumentTemplate) {
            $librarian = $this->userLibrarian->getLibrarian();
            $d = $this->getDestination();
            $arr_alias = NotificationEmail::getAliasArray($librarian, $this->actualLibrary, 'solicit', false, $d, array());
            $body = DocumentTemplatePeer::templateTransform($tpl->getTemplateBody(), $arr_alias);
            $sender = NotificationEmail::getEmailSender($this->EmailSender->getSelectedValue(), $librarian, $this->actualLibrary, $d);
            $this->EmailSubject->setText($tpl->getTemplateSubject());
            $this->EmailBody->setText($body);
        } else {
            $this->EmailSubject->setText('');
            $this->EmailBody->setText('');
        }
    }

    public function sendNotification()
    {
        $nm = $this->getApplication()->getModule('notification');
        $notificationData = array(
            'sender_library_id' => $this->getUser()->getActualLibraryId(),
            'description' => Prado::localize('Messaggio diretto'),
        );
        $d = $this->getDestination();

        /**
         *
         * -------------------------------------------------------------------------------------------------------------
         * SMS NOTIFICATION
         * -------------------------------------------------------------------------------------------------------------
         *
         */
        if ($this->SMSCheck->getChecked()) {
            try {
                $smsBody = trim($this->SMSBody->getText());
                if (!$smsBody) {
                    $this->getPage()->writeMessage(Prado::localize("Il messaggio è vuoto"), ClavisMessage::ERROR);
                    return;
                }
                if ($d instanceof Patron) {
                    $contactcrit = new Criteria();
                    $contactcrit->add(ContactPeer::CONTACT_TYPE, ContactPeer::TYPE_MOBILE);
                    $contactcrit->addDescendingOrderByColumn(ContactPeer::CONTACT_PREF);
                    $contacts = $d->getContacts($contactcrit);
                    if (count($contacts) < 1) {
                        // patron doesn't have a mobile contact, so skip and fail.
                        $this->getPage()->writeMessage(Prado::localize("L'utente non ha un contatto" .
                            " di tipo cellulare."), ClavisMessage::ERROR);
                        return;
                    }
                    $contact = $contacts[0]->getContactValue();
                    $notificationData['receiver_class'] = 'Patron';
                    $notificationData['receiver_id'] = $d->getPatronId();
                } else if ($d instanceof Library) {
                    $contact = trim($d->getPhone());
                    if (!$contact) {
                        $this->getPage()->writeMessage(Prado::localize("La biblioteca non ha un contatto telefonico."), ClavisMessage::ERROR);
                        return;
                    }
                    $notificationData['receiver_class'] = 'Library';
                    $notificationData['receiver_id'] = $d->getLibraryId();
                }
                $sender = $this->SMSSender->getSelectedItem()->getText();
                $notificationData['notes'] = array("CorpoMessaggio: [{$this->SMSBody->getSafeText()}");
                $nm->DoSmsReport(
                    $smsBody, $sender, $contact, array(), $notificationData);
                $this->getPage()->writeMessage(Prado::localize('SMS inviato correttamente'), ClavisMessage::CONFIRM);
            } catch (Exception $e) {
                if ($e->getCode() == NotificationManager::ERR_NOCREDIT)
                    $this->getPage()->writeMessage(Prado::localize('Errore: credito non sufficiente'), ClavisMessage::ERROR);
                else
                    $this->getPage()->writeMessage(Prado::localize('Errore: ') . $e->getMessage(), ClavisMessage::ERROR);
            }

        } /**
         *
         * -------------------------------------------------------------------------------------------------------------
         * MAIL NOTIFICATION
         * -------------------------------------------------------------------------------------------------------------
         *
         */
        else if ($this->MailCheck->getChecked()) {
            try {
                $mailBody = trim($this->EmailBody->getText());
                if (!$mailBody) {
                    $this->getPage()->writeMessage(Prado::localize("La e-mail è vuota"), ClavisMessage::ERROR);
                    return;
                }
                if ($d instanceof Patron) {
                    $notificationData['receiver_class'] = 'Patron';
                    $notificationData['receiver_id'] = $d->getPatronId();
                } else if ($d instanceof Library) {
                    $notificationData['receiver_class'] = 'Library';
                    $notificationData['receiver_id'] = $d->getLibraryId();
                }
                $mailpattern = '!(.*) <(\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}\b)>!i';
                preg_match($mailpattern, $this->EmailSender->getSelectedValue(), $matches);
                $sender = array(
                    'name' => $matches[1],
                    'email' => $matches[2]
                );
                $recipient = $d->getEmail();
                if (!is_array($recipient))
                    $recipient = array($recipient);

                $notificationData['notes'] = array("CorpoMail: [{$mailBody}");

                $mailData = array(
                    'to' => $recipient,
                    'from' => $sender,
                    'cc' => '',
                    'bcc' => '',
                    'body' => '',
                    'subject' => "{$this->EmailSubject->getSafeText()}"
                );
                $ret = $nm->DoEmailReport(
                    $mailBody, array(), $mailData, NotificationManager::EMAIL_AUTO, $notificationData);
                if ($ret)
                    $this->getPage()->writeMessage(Prado::localize('E-mail inviata correttamente'), ClavisMessage::CONFIRM);
                else
                    throw new Exception(Prado::localize('Errore nella spedizione della e-mail'));
            } catch (Exception $e) {
                if ($e->getCode() == NotificationManager::ERR_ADDRESSEMPTY)
                    $this->getPage()->writeMessage(Prado::localize('Errore: nessun indirizzo mail valido'), ClavisMessage::ERROR);
                else
                    $this->getPage()->writeMessage(Prado::localize('Errore: ') . $e->getMessage(), ClavisMessage::ERROR);
            }
        } /**
         *
         * -------------------------------------------------------------------------------------------------------------
         * BOT NOTIFICATION
         * -------------------------------------------------------------------------------------------------------------
         *
         */
        else if ($this->BotCheck->getChecked()) {
            $this->performBotNofication($notificationData, $d, $nm, $this->BotRequestReceipt->getChecked());
        } /**
         *
         * -------------------------------------------------------------------------------------------------------------
         * PUSH NOTIFICATION
         * -------------------------------------------------------------------------------------------------------------
         *
         */
        else if ($this->PushCheck->getChecked()) {
            $this->performPushNotification($notificationData, $d, $nm);
        } /**
         *
         * -------------------------------------------------------------------------------------------------------------
         * INVALID CHANNEL
         * -------------------------------------------------------------------------------------------------------------
         *
         */
        else {
            $this->getPage()->writeMessage(Prado::localize('Errore: canale non valido.'), ClavisMessage::ERROR);
        }
    }

    /**
     * @param $notificationData
     * @param $d
     */
    private function performBotNofication(&$notificationData, Patron $d, $nm, $withReceipt = false)
    {
        try {
            //Controllo se ho compilato correttamente il campo con il testo della notifica da inviare.
            // ---------------------------------------------------------------------------------------------------------
            $text = trim($this->BotMessage->getText());
            if (!$text) {
                $this->getPage()->writeMessage(Prado::localize('Il testo della notifica è vuoto'), ClavisMessage::ERROR);
                return;
            }
            $notificationData['description'] = $text;

            // Controllo se ho un Patron valido a cui inviare la notifica.
            // ---------------------------------------------------------------------------------------------------------
            if ($d instanceof Patron) {
                $notificationData['receiver_class'] = 'Patron';
                $notificationData['receiver_id'] = $d->getPatronId();
            } else {
                throw new Exception(Prado::localize('Patron non valido'));
            }

            // Controllo se questo patron ha uno o più contatti bot validi.
            // ---------------------------------------------------------------------------------------------------------
            $validContacts = array_filter((array)$this->botContacts, function (Contact $contact) {
                return $contact->getContactType() !== ContactPeer::TYPE_WRONG;
            });

            // Notifico tutti i canali chatbot validi associati al patron indicato.
            // ---------------------------------------------------------------------------------------------------------
            foreach ($validContacts as $contact) {
                $msgData = array();
                $msgData['mongo_id'] = $contact->getContactValue();
                $msgData['receipt'] = $withReceipt;

                $ret = $nm->DoChatBotReport($text, $notificationData, $msgData);
                if ($ret->status === 'OK') {
                    $this->getPage()->writeMessage(Prado::localize('Notifica inviata correttamente'), ClavisMessage::CONFIRM);
                } else {
                    throw new Exception(Prado::localize('Errore nell\'invio della notifica tramite chat bot'));
                }
            }
        } catch (Exception $e) {
            $this->getPage()->writeMessage(Prado::localize('Errore: ') . $e->getMessage(), ClavisMessage::ERROR);
        }
    }

    /**
     * @param array  $notificationData
     * @param Patron $d
     */
    private function performPushNotification(array &$notificationData, Patron $d, NotificationManager $nm)
    {
        try {
            //Controllo se ho compilato correttamente il campo con il testo della notifica da inviare.
            // ---------------------------------------------------------------------------------------------------------
            $text = trim($this->PushMessage->getText());
            if (!$text) {
                $this->getPage()->writeMessage(Prado::localize('Il testo della notifica è vuoto'), ClavisMessage::ERROR);
                return;
            }
            $notificationData['description'] = $text;

            // Controllo se ho un Patron valido a cui inviare la notifica.
            // ---------------------------------------------------------------------------------------------------------
            if ($d instanceof Patron) {
                $notificationData['receiver_class'] = 'Patron';
                $notificationData['receiver_id'] = $d->getPatronId();
                $notificationData['opac_username'] = $d->getOpacUsername();
            } else {
                throw new Exception(Prado::localize('Patron non valido'));
            }

            $ret = $nm->DoPushReport($text, $notificationData);
            if (isset($ret)) {
                throw new Exception(Prado::localize('Errore nell\'invio della notifica push'));
            } else {
                $this->getPage()->writeMessage(Prado::localize('Notifica inviata correttamente'), ClavisMessage::CONFIRM);
            }
        } catch (Exception $e) {
            $this->getPage()->writeMessage(Prado::localize('Errore: ') . $e->getMessage(), ClavisMessage::ERROR);
        }
    }
}