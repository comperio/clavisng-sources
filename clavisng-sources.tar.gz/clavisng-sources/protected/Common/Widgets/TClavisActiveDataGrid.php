<?php
Prado::using("System.Web.UI.WebControls.TDataGrid");

/**
 * TClavisActiveDataGrid
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @author Ciro Mattia Gonano
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @copyright Copyright &copy; 2011 Comperio srl
 * @package Controls
 * Enhances TDataGrid adding pagination, sorting, and other kind stuff.
 */

class TClavisActiveDataGrid extends TActiveDataGrid
{
	const SORTDIRECTION_ASC = 'ASC';
	const SORTDIRECTION_DESC = 'DESC';

	private $_listId = array();
	private $_listIdSessionName;
    private $_queryObj;

	public function grabColumns()
	{
		$sortExpressions = array();
		foreach ($this->getColumns() as $index => $column)
		{
			if (($sortExp = $column->getSortExpression()) != '')
				$sortExpressions[$sortExp] = array(	'column' => $index,
													'text' => $column->getHeaderText(),
													'expression' => $column->getSortExpression() );
		}

		$this->setSortExpressions($sortExpressions);
	}

	public function onInit($param)
	{
		parent::onInit($param);

		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallBack())
		{
			$this->grabColumns();

			if (array_key_exists('TClavisDataGridPageSize', $_COOKIE))
				$this->setPageSize($_COOKIE['TClavisDataGridPageSize']);
		}

		$autoGenerateColumns = false;
		if ($this->getAutoGenerateColumns() == 'true')
			$autoGenerateColumns = true;
		$this->setAutoGenerateColumns($autoGenerateColumns);

		$gridWidth = $this->getGridWidth();
		$this->setWidth(is_null($gridWidth) 
							? "100%"
							: $gridWidth );
		
		$this->setGridLines("Vertical");
		$this->setCellPadding(3);
		//$this->setCellSpacing(4);

		$enablePagination = $this->getEnablePagination();

		$this->setAllowPaging($enablePagination);
		$this->setAllowCustomPaging($enablePagination);

		if ($enablePagination)
		{
			$pagerStyle = $this->getPagerStyle();

			$pagerStyle->setMode("Numeric");
			$pagerStyle->setHorizontalAlign("Right");
			$pagerStyle->setButtonType("LinkButton");
			$pagerStyle->setNextPageText("»");
			$pagerStyle->setPrevPageText("«");
			$pagerStyle->setPosition($this->getPagerPosition());
		}

		$this->getItemStyle()->setCssClass("dgItem");
		$this->getAlternatingItemStyle()->setCssClass("dgAltItem");
		$this->getHeaderStyle()->setCssClass("dgHeaderItem");
		$this->getStyle()->setCssClass("dgStyle");

		$this->attachEventHandler('OnPageIndexChanged', array($this, 'onChangePageIndex'));
	}

	public function pushSelection($selection = array())
	{
		$actualSelections = $this->getControlState("Selections", array());
		$actualSelections[] = $selection;
		
		$this->setControlState("Selections", $actualSelections, array());
	}

	public function popSelections()
	{
		$selections = $this->getControlState("Selections", array());
		$this->setControlState("Selections", array());	// clear
		
		return $selections;
	}
	
	public function onPreRender($param)
	{
		parent::onPreRender($param);
		
		foreach ($this->popSelections() as $selection)
		{
			list($component, $value) = $selection;
			$component->SelectedValue = $value;
		}
	}
	
	public function resetListId()
	{
		$this->_listId = array();
		$this->setListId($this->_listId);
	}

	public function setListId($listId = null)
	{
		if ($listId == null)
			$listId = $this->_listId;
		else
			$this->_listId = $listId;
		$this->getApplication()->getSession()->add($this->_listIdSessionName, $listId);
	}

	public function getListId()
	{
		$this->_listId = $this->getApplication()->getSession()->itemAt($this->_listIdSessionName);
		return $this->_listId;
	}

	public function setPageSize($size = 10)
	{
		setcookie('TClavisDataGridPageSize', $size);
		$this->setControlState('PageSize', $size, 10);
	}

	public function getPageSize()
	{
		$size = $this->getControlState('PageSize', 10);

		if (($size > 0) && ($size < 1000))
			return intval($size);
		else
			return 10;
	}

	public function setPagerPosition($value)
	{
		$this->setViewState('PagerPosition', $value, 'Bottom');
	}

	public function getPagerPosition()
	{
		return $this->getViewState('PagerPosition', 'Bottom');
	}

	public function setLastSortExpression($exp = '')
	{
		$this->setViewState('LastSortExpression', $exp, '');
	}

	public function getLastSortExpression()
	{
		return $this->getViewState('LastSortExpression', '');
	}

	public function setSortExpressions($exps = array())
	{
		$this->setViewState('SortExpressions', $exps, array());
	}

	public function getSortExpressions()
	{
		return $this->getViewState('SortExpressions', array());
	}

	public function setGridWidth($value)
	{
		$this->setViewState('GridWidth', $value, null);
	}

	public function getGridWidth()
	{
		return $this->getViewState('GridWidth', null);
	}

	public function onChangePageSize($sender, $param)
	{
		$newPageSize = intval($sender->getSelectedValue());
		if ($newPageSize > 0)
		{
			$this->setPageSize($newPageSize);
			$this->resetPagination();
			$this->doPopulate();
		}
	}

	/**
	 * The following piece of code finds the next populate method, for
	 * recostructing the datagrid data after the change in the
	 * number of lines
	 */
	public function doPopulate()
	{
		if (isset($this->_queryObj))
		{	
			$this->setVirtualItemCount($this->_queryObj->count());

			// Sort rules...

			$ds =   $this->_queryObj->limit($this->getPageSize())
				->offset($this->getPageSize() * $this->getCurrentPageIndex())
				->find()
				->toArray();

			$this->setDataSource($ds);

			$this->dataBind();
		}
		else	// classic mode
		{
			$actual = $this;
			do
				if (method_exists($actual = $actual->getParent(), 'populate'))
					return $actual->populate();
			while (!($actual instanceof TPage));
		}
	}

	public function setAutoGenerateColumns($value)
	{
		$this->setViewState('AutoGenerateColumns', $value, 'false');
	}

	public function getAutoGenerateColumns()
	{
		return $this->getViewState('AutoGenerateColumns', 'false');
	}

	public function setShowRowCount($value = 'true')
	{
		$this->setViewState('ShowRowCount', $value, 'true');
	}

	public function getShowRowCount()
	{
		return $this->getViewState('ShowRowCount', 'true');
	}
	
	public function onPagerCreated($param)
	{
		if ($this->getEnablePagination())
		{
			$pager = $param->Pager->Controls;

			$pager->add(' / ' . $this->getPageCount() . '<br />');

			$label = new TLabel();
			$label->setID('PageRowsLabelCount');
			$label->setText(($this->getShowRowCount() == 'true'
								? Prado::localize("totale") .": ". $this->getVirtualItemCount()
								: ""));
			$label->setCssClass("viewlabel4");
			$label->setStyle("float:left; width:inherit;font-weight: bold;");
			$pager->add($label);

			$label = new TLabel();
			$label->setID('PageRowsLabel');
			$label->setText(Prado::localize('num.righe') . ': ');
			$label->setCssClass("viewlabel4small");
			$pager->add($label);
			
			$drop = new TDropDownList();
			$drop->setID('PageRows');
			$drop->setAutoPostBack(true);

			foreach(array(10, 20, 50, 100) as $value)
			{
				$element = new TListItem();
				$element->setText($value);
				$element->setValue($value);
				$drop->getItems()->add($element);
			}

			if (($pageSize = $this->getPageSize()) > 0)
				$drop->setSelectedValue($pageSize);

			$pager->add($drop);
			$drop->attachEventHandler('OnSelectedIndexChanged', array($this, 'onChangePageSize'));
		}

		parent::onPagerCreated($param);
	}

	public function resetPagination()
	{
		$this->setCurrentPage(0);
		$this->setCurrentPageIndex(0);
	}

	public function getCurrentPage()
	{
		if (!$this->getEnablePagination())
			return 0;
		$currentPage = $this->getViewState('CurrentPage', 0);
		return intval($currentPage);
	}

	public function setCurrentPage($page)
	{
		$this->setViewState('CurrentPage', $page, 0);
		$this->setCurrentPageIndex($page);
	}


	public function getOldPage()
	{
		$oldPage = $this->getViewState('OldPage', null);
		return $oldPage;
	}

	public function setOldPage($page)
	{
		$this->setViewState('OldPage', $page, null);
	}

	public function getEnablePagination()
	{
		$enablePagination = $this->getViewState('EnablePagination', true);
		$this->setAllowPaging($enablePagination);
		$this->setAllowCustomPaging($enablePagination);

		return $enablePagination;
	}

	public function setEnablePagination($enablePagination)
	{
		$flag = null;
		if (($enablePagination === 'true') || ($enablePagination === true) )
			$flag = true;
		elseif (($enablePagination === 'false') || ($enablePagination === false))
			$flag = false;

		$this->setViewState('EnablePagination', $flag, true);
		$this->setAllowPaging($enablePagination);
		$this->setAllowCustomPaging($enablePagination);
	}

	public function getEnableGlobalRefresh()
	{
		return $this->getViewState('EnableGlobalRefresh', true);
	}

	public function setEnableGlobalRefresh($globalRefreshFlag)
	{
		$this->setViewState('EnableGlobalRefresh', $globalRefreshFlag, true);
	}

	public function globalRefresh()
	{
		if ($this->getEnableGlobalRefresh())
			$this->getPage()->globalRefresh();
		else
			$this->doPopulate();
	}

	/** For sorting
	 */
	public function setSortingFields($arr)
	{
		$this->setViewState("SortingFields", $arr, array());
	}

	public function getSortingFields()
	{
		return $this->getViewState("SortingFields", array());
	}

	public function setSortingExpression($exp)
	{
		$this->setViewState("SortingExpression", $exp, '');
	}

	public function getSortingExpression()
	{
		return $this->getViewState("SortingExpression", '');
	}

	public function setSortingDirection($exp)
	{
		$this->setViewState("SortingDirection", $exp, self::SORTDIRECTION_ASC);
	}

	public function getSortingDirection()
	{
		return $this->getViewState("SortingDirection", self::SORTDIRECTION_ASC);
	}

	/**
	 * We reset the sorting method
	 *
	 * @param string $exp
	 * @param enum $direction
	 * @param boolean $overwriteMode
	 * The last parameter is used when we want to 'try' to set an order clause,
	 * but it doesn't get considered in the case the SortingExpression is already
	 * been set.
	 */
	public function resetSorting($exp = null, $direction = self::SORTDIRECTION_ASC, $overwriteMode = true)
	{
		if (!$overwriteMode)
		{
			if ($this->getSortingExpression() != '')
				return false;
		}

		if ($direction != self::SORTDIRECTION_ASC && $direction != self::SORTDIRECTION_DESC)
			$direction = self::SORTDIRECTION_ASC;
		$this->setSortingDirection($direction);
		$this->setSortingExpression($exp);
		$this->setLastSortExpression($exp);

		$sortExpressions = $this->getSortExpressions();

		foreach ($sortExpressions as $sExp)
		{
			$column = $sExp['column'];
			$text = $sExp['text'];
			$expression = $sExp['expression'];

			if ($expression == $exp)
				$text .= $this->getSortingImage();

			$this->Columns[$column]->setHeaderText($text);
		}
	}

	public function OnSortCommand($param)
	{
		parent::onSortCommand($param);

		if (is_null($this->getSortingExpression()))
		{
			$this->resetPagination();
			$this->setSortingDirection(self::SORTDIRECTION_ASC);
			$this->setSortingExpression($param->getSortExpression());
		}
        elseif ($this->getSortingExpression() !== $param->getSortExpression())
        {
        	$this->resetPagination();
            $this->setSortingExpression($param->getSortExpression());
            $this->setSortingDirection(self::SORTDIRECTION_ASC);
        }
        else
        {
            if ($this->getSortingDirection() == self::SORTDIRECTION_ASC)
                $this->setSortingDirection(self::SORTDIRECTION_DESC);
            else
                $this->setSortingDirection(self::SORTDIRECTION_ASC);
        }

		$newSortExpression = $param->getSortExpression();
		$sortExpressions = $this->getSortExpressions();
		$lastSortExpression = $this->getLastSortExpression();

		if ($lastSortExpression != '')
		{
			if (array_key_exists($lastSortExpression, $sortExpressions))
			{
				$element = $sortExpressions[$lastSortExpression];
				$this->Columns[$element['column']]->setHeaderText($element['text']);
			}
		}

		$newElement = $sortExpressions[$newSortExpression];
		$text = $newElement['text'];

		if ($text == '')
		{
			$this->grabColumns();
			$sortExpressions = $this->getSortExpressions();
			$newElement = $sortExpressions[$newSortExpression];
			$text = $newElement['text'];
		}

		$this->Columns[$newElement['column']]->setHeaderText($newElement['text'] . $this->getSortingImage());
		$this->setLastSortExpression($newSortExpression);

		$this->doPopulate();
	}

	public function getSortingImage()
	{
		if ($this->getSortingDirection() == self::SORTDIRECTION_ASC)
			$image = '<img src="themes/Default/icons/sort_asc.png" alt="' . Prado::localize('ordinamento ascendente') . '" title="' . Prado::localize('ordinamento ascendente') . '" class="formImageButton" />';
		elseif ($this->getSortingDirection() == self::SORTDIRECTION_DESC)
			$image = '<img src="themes/Default/icons/sort_desc.png" alt="' . Prado::localize('ordinamento discendente') . '" title="' . Prado::localize('ordinamento discendente') . '" class="formImageButton" />';
		else
			$image = '';

		return $image;
	}

	/**
	 * This is callable when we want to change dinamically a column label,
	 * php-side, but don't want to change the sorting image (little direction
	 * arrow...)
	 */
	public function substituteHeaderText($component, $text)
	{
		$origText = $component->getHeaderText();
		$text = preg_replace(	'/^([^<]*)(<img.*\/>)?/u',
								$text . '$2',
								$origText );

		$component->setHeaderText($text);
	}


    public function setQuery($query)
    {
        $this->_queryObj = $query;
    }

    public function onChangePageIndex($sender, $param)
    {
        $this->setCurrentPage($param->NewPageIndex);
        $this->doPopulate();
    }
	
}