<?php
/**
 * ClavisCDFVisualizer
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2009 ePortal Technologies
 * @version 2.7
 * @package Widgets
 * @since 2.4.0
 */
class ClavisCDFVisualizer extends TTemplateControl
{
	public function onLoad($param)
	{
		parent::onLoad($param);
		
		$this->populate();
	}

	public function populate()
	{
		$field = $this->getField();
		if ($field === null)
			return;
		$flist = array();

		if (!isset(TurboMarcMappings::$cdflist[$field['fieldnum']]))
			return false;

		foreach (TurboMarcMappings::$cdflist[$field['fieldnum']] as $tag => $positions)
		{
			if (array_key_exists($tag, $field['subfields']))
				foreach ($positions as $p => $l)
				{
					$value = substr($field['subfields'][$tag], $p, $l);
					/* if no value is set, skip it */
					if ('' == trim($value))
						continue;
					$flist[] = array(
						'grouplabel' => UnimarcCodesPeer::getGroupLabel($field['fieldnum'], $tag, $p),
						'value'		 => UnimarcCodesPeer::getValueLabel($field['fieldnum'], $tag, $p, $value)
					);
				}
		}
		$this->FieldRepeater->setEnableViewState($this->getEnableViewState());
		$this->FieldRepeater->setDataSource($flist);
		$this->dataBind();
		$this->setField($field);
	}

	public function setField($field)
	{
		$this->setControlState('field', $field, null);
	}

	public function getField()
	{
		return $this->getControlState('field', null);
	}
	
}