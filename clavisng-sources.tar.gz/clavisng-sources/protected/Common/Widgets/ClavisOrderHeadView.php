<?php
/**
 * ClavisOrderHeadView class
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @copyright Copyright &copy; 2010 Comperio srl
 * @version 2.7
 * @package Widgets
 * @since 2.1
 */
class ClavisOrderHeadView extends TTemplateControl
{
	/** @var PurchaseOrder */
	private $_order = null;

	public function TOREMOVEonLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsPostBack())
		{
			$this->getOrder();
			////$this->ItemOrderList->setPurchaseOrder($this->_order);
			$this->populate();
		}
	}

	public function populate()
	{
		if ($this->_order === null)
			return;

		$this->OrderTitle->setText($this->_order->getOrderTitle());

		$this->OrderType->setText(LookupValuePeer::getLookupValue('PURCHASEORDERTYPE', $this->_order->getOrderType()));

		$this->OrderStatus->setText(LookupValuePeer::getLookupValue('PURCHASEORDERSTATUS', $this->_order->getOrderStatus()));

		$library = LibraryQuery::create()
				->findPk($this->_order->getLibraryId());
		if ($library instanceof Library)
			$this->Library->setText($library->getLabel());
		else
			$this->Library->setText("--");

		$supplier = null;
		$supplierId = intval($this->_order->getSupplierId());
		if ($supplierId > 0)
			$supplier = SupplierQuery::create()
					->findPk($supplierId);
		if ($supplier instanceof Supplier)
		{
			$this->Supplier->setText($supplier->getSupplierName());
			$this->Supplier->setNavigateUrl($supplier->getNavigateUrl() . $supplierId);
		}
		else
		{
			$this->Supplier->setText("--");
			$this->Supplier->setNavigateUrl("");
		}

		$this->OrderDate->setValue($this->_order->getOrderDate('U'));

		$this->DeliveryDate->setValue($this->_order->getDeliveryDate('U'));

		$this->OrderDiscount->setText(ClavisBase::numberFormat($this->_order->getOrderDiscount(), '#.00%'));

		$this->OrderNote->setText($this->_order->getOrdernote());

		$accountId = $this->_order->getAccountId();
		if ($accountId != "")
			$this->AccountId->setText($accountId);
		else
			$this->AccountId->setText("--");
	}

	/**
	 * @param PurchaseOrder $order
	 */
	public function setOrder(PurchaseOrder $order)
	{
		$this->_order = $order;
		$this->setControlState('purchase_order', $order, null);
	}

	/**
	 * @return PurchaseOrder
	 */
	public function getOrder()
	{
		if (is_null($this->_order))
		{
			$this->_order = $this->getControlState('purchase_order', null);
		}
		return $this->_order;
	}

	/**
	 * @return int
	 */
	public function getOrderId()
	{
		$this->getOrder();
		return ($this->_order instanceof PurchaseOrder) ? $this->_order->getOrderId() : '';
	}
	
}