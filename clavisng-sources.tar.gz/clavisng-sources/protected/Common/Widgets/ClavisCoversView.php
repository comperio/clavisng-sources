<?php
/**
 * ClavisCoversView class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author    Mauro Seno <mauro.seno@comperio.it>
 * @link      http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 ePortal Technologies
 * @license   http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version   2.9
 * @package   Widgets
 */

class ClavisCoversView extends TTemplateControl
{
    private $_ean;
    private $_eanData;
    private $_uniqueId;
    private $_carouselMode;
    private $_loadLocal;
    private $_manifestation;

    /**
     * @param $param
     */
    public function onLoad($param)
    {
        parent::onLoad($param);
        $this->_uniqueId = $this->getUniqueID();
    }

    /**
     * @param $param
     */
    public function onPreRender($param)
    {
        parent::onPreRender($param);

        if ($this->hasCovers() && $this->hasOnlyLocalCover()) {
            $this->CoverUploader->setVisible($this->getHasAccessRight());
        }

        if (!$this->hasCovers()) {
            $this->CoversShelf->setVisible(false);
            $this->CoverUploader->setVisible($this->getHasAccessRight());
        }

        if (!$this->hasIndexes()) {
            $this->IndexesShelf->setVisible(false);
        }

        if (!$this->hasMetadata()) {
            $this->MetadataShelf->setVisible(false);
        }

        $this->ClavisCoverViewContainer->setStyle('');
        if ($this->getCarouselMode()) {
            $this->MetadataShelf->setVisible(false);
            $this->ClavisCoverViewContainer->setStyle('float: right');
        }
    }

    /**
     *
     */
    public function populate(): void
    {
        if ($this->getManifestation() instanceof Manifestation) {
            $this->_eanData = ClavisCovers::cacheGet($this->getEan());
        }

        if (!$this->_eanData) {
            $this->_eanData = ClavisCovers::getRemoteInfo($this->getEan());
            ClavisCovers::cacheAdd($this->getEAN(), $this->_eanData);
        }

        $this->populateCoversData($this->_eanData);
        $this->populateIndexesData($this->_eanData);
        $this->populateMetadataData($this->_eanData);

        $this->setControlState('currentEanData', $this->_eanData);
    }

    /**
     * @return mixed|null
     */
    public function getEAN()
    {
        $ean = $this->getControlState('currentEAN');
        return  $ean;
    }

    /**
     * @param $ean
     */
    public function setEAN($ean): void
    {
        if (null !== $ean) {
            $this->_ean = $ean;
            $this->setControlState('currentEAN', $ean);
        }
    }

    /**
     * @return bool
     */
    public function getCarouselMode(): bool
    {
        return $this->getViewState('carouselMode');
    }

    /**
     * @param mixed $carouselMode
     */
    public function setCarouselMode($carouselMode): void
    {
        $this->_carouselMode = TPropertyValue::ensureBoolean($carouselMode);
        $this->setViewState('carouselMode', $this->_carouselMode);
    }

    /**
     * @return mixed
     */
    public function getLoadLocal()
    {
        return $this->_loadLocal;
    }

    /**
     * @param $loadLocal
     */
    public function setLoadLocal($loadLocal): void
    {
        $this->_loadLocal = TPropertyValue::ensureBoolean($loadLocal);
    }

    /**
     * @return mixed
     */
    public function getManifestation()
    {
        return $this->_manifestation;
    }

    /**
     * @param \Manifestation $manifestation
     *
     * @throws \PropelException
     */
    public function setManifestation(Manifestation $manifestation): void
    {
        if ($manifestation instanceof Manifestation) {
            $this->_manifestation = $manifestation;

            $ean = $this->getEANFromManifestation($this->_manifestation->getManifestationId());
            $this->setEAN($ean);
            $this->populate();
        }
    }

    /**
     * @param $sender
     * @param $param
     */
    public function onImageTypeChanged($sender, $param): void
    {
        if ($sender->getId() === 'ImageTypeCover') {
            $this->LoadFile->setText(Prado::localize('carica copertina'));
        }

        if ($sender->getId() === 'ImageTypeIndex') {
            $this->LoadFile->setText(Prado::localize('carica indice'));
        }
    }

    /**
     * @param $sender
     * @param $param
     */
    public function onLoadFile($sender, $param): void
    {
        $ean = $this->getEAN();
        $newImageData = $this->getViewState('newImageData');
        $fileContent = file_get_contents($newImageData['localFilePath']);

        $response = ClavisCovers::uploadNewItem(
            $ean,
            $newImageData['type'],
            'CLAVIS_LIBRARIAN',
            $fileContent
        );

        if ($this->getStatusFromClavisCoversAPIResponse($response) === 'OK') {
            $this->ClavisNewCoverResponseStatus->Text = Prado::localize("Grazie per aver caricato una nuova copertina! Ora e' in attesa di approvazione da parte di Comperio e e sara' disponibile a breve");
        } else {
            $this->ClavisNewCoverResponseStatus->Text = Prado::localize("Ops! Il caricamento della copertina non e' andato a buon fine. Per favore riprova piu' tardi.");
        }
    }

    /**
     * @param $sender
     * @param $param
     */
    public function onFileUploaded($sender, $param): void
    {
        if ($sender instanceof TActiveFileUpload && $sender->getHasFile() && $sender->getIsValid()) {
            $this->FileUploaderResult->Text = Prado::localize('File {filename} letto correttamente', ['filename' => $sender->FileName]);

            $newImageData['filename'] = $sender->getFileName();
            $newImageData['localFilePath'] = $this->copyFileIntoTmp($sender->getLocalName(), 'clavis_user_cover_');
            $newImageData['filetype'] = $sender->getFileType();
            $newImageData['type'] = $this->ImageTypeCover->getChecked() ? 'C' : '';
            $newImageData['type'] = $this->ImageTypeIndex->getChecked() ? 'I' : $newImageData['type'];

            $this->setViewState('newImageData', $newImageData);

            $this->FileUploaderImagePreview->ImageUrl = $this->publishFilePath($newImageData['localFilePath']);
            $this->LoadFile->Enabled = true;
        } else {
            $this->LoadFile->Enabled = false;
        }
    }

    /**
     * @param $sender
     * @param $param
     */
    public function onCoversShelfCommand($sender, $param): void
    {
        switch ($param->getCommandName()) {
            case 'OnSignalWrongCover':
                $this->onSignalWrongCover($sender, $param->getCommandParameter());
                break;
        }
    }

    /**
     * @return bool
     */
    public function getHasAccessRight(): bool
    {
        $option = (bool)ClavisParamQuery::getParam('CLAVISPARAM', 'LIBRARIAN_SENDS_COVERS');
        $adminMode = $this->getCarouselMode() === false;
        $right =  $option &&  $adminMode;
        return $right;
    }

    /**
     * @param        $src
     * @param string $prefix
     *
     * @return bool|string
     */
    private function copyFileIntoTmp($src, $prefix = 'TMP_')
    {
        $temp = tempnam(sys_get_temp_dir(), $prefix);
        if (copy($src, $temp)) {
            return $temp;
        }
        return '';
    }

    /**
     * @param $sender
     * @param $param
     *
     * @return bool
     */
    private function onSignalWrongCover($sender, $param): bool
    {
        $response = ClavisCovers::markItemAsInvalid($this->getEAN(), $param);
        if ($this->getStatusFromClavisCoversAPIResponse($response) === 'OK') {
            $this->ClavisWrongCoverResponseStatus->Text = Prado::localize("Grazie per aver effettuato questa segnalazione! Verra' processata a breve dagli operatori di Comperio.");
        } else {
            $this->ClavisWrongCoverResponseStatus->Text = Prado::localize("Ops! Sembra ci sia qualche problema nell'invio di questa segnalazione. Per favore riprova piu' tardi.");
        }
        return true;
    }


    /**
     * @param $response
     *
     * @return string
     */
    private function getStatusFromClavisCoversAPIResponse($response): string
    {
        if ($response['code'] === 200) {
            $r = json_decode($response['body'], true);
            return (string)$r['REPLY']['STATUS'];
        }
        return 'KO';
    }

    /**
     * @return bool
     */
    private function hasCovers(): bool
    {
        $this->_eanData = $this->getControlState('currentEanData');
        return count($this->_eanData['covers']['C']) > 0;
    }

    /**
     * @return bool
     */
    private function hasALocalCover(): bool
    {
        $c = AttachmentQuery::create()
            ->filterByAttachmentType(AttachmentPeer::TYPE_COVER)
            ->filterByObjectType('Manifestation')
            ->filterByObjectId($this->getManifestation()->getManifestationId())
            ->count();

        return $c > 0;
    }

    private function hasOnlyLocalCover(): bool
    {
        $this->_eanData = $this->getControlState('currentEanData');
        $c = array_filter($this->_eanData['covers']['C'], function($el) { return $el['coverid'] === 'local';});
        $onlyLocal = count($c) === count($this->_eanData['covers']['C']);
        return $onlyLocal;
    }

    private function hasOnlyRemoteCover(): bool
    {
        $this->_eanData = $this->getControlState('currentEanData');
        $c = array_filter($this->_eanData['covers']['C'], function($el) { return $el['coverid'] !== 'local';});
        $onlyRemote = count($c) === count($this->_eanData['covers']['C']);
        return $onlyRemote;
    }

    /**
     * @return bool
     */
    private function hasIndexes(): bool
    {
        $this->_eanData = $this->getControlState('currentEanData');
        return count($this->_eanData['covers']['I']) > 0;
    }

    /**
     * @return bool
     */
    private function hasMetadata(): bool
    {
        $this->_eanData = $this->getControlState('currentEanData');
        $md = $this->extractAbstractFromMetadata($this->_eanData);
        return $md[0]['value'] !== '';
    }

    /**
     * @param $covers
     */
    private function populateCoversData(&$covers): void
    {
        $data = $covers['covers']['C'] ?? [];
        $localData = [];

        // Se devo caricare anche gli allegati locali di tipo "copertina"....
        if ($this->getLoadLocal()) {
            $local_url = $this->getPage()->getRequest()->constructUrl(
                'file',
                'lcover',
                array('id' => $this->getManifestation()->getManifestationId())
            );

            $localData[] = [
                'coverid' => 'local',
                'ean' => $this->getEAN(),
                'lastupdate' => null,
                'poststamp' => $local_url,
                'sequence' => count($data) + 1,
                'size' => null,
                'uri' => $local_url
            ];
        }

        // in carousel mode, show onlly the local cover, and if a
        // remote cover is present, tell the user about it.
        if ($this->getCarouselMode() && $this->hasALocalCover()) {
            $data = $localData;
        }

        $covers['covers']['C'] = $data;
        $this->CoversShelf->setDataSource($data);
        $this->CoversShelf->dataBind();
    }

    /**
     * @param $covers
     */
    private function populateIndexesData($covers): void
    {
        $data = $covers['covers']['I'] ?? [];
        $this->IndexesShelf->setDataSource($data);
        $this->IndexesShelf->dataBind();
    }

    /**
     * @param $covers
     */
    private function populateMetadataData($covers): void
    {
        $md = $this->extractAbstractFromMetadata($covers);
        $this->MetadataShelf->setDataSource($md);
        $this->MetadataShelf->dataBind();
    }

    /**
     * @param $covers
     *
     * @return array
     */
    private function extractAbstractFromMetadata($covers): array
    {
        $md = [];
        $metadata = $covers['metadata'] ?? [];

        array_walk($metadata, function ($value, $key) use (&$md) {
            if ($key === 'abstract' && '' !== trim($value)) {
                $md[] = ['key' => $key, 'value' => $value];
            }
        });

        return $md;
    }

    /**
     * @param $mId
     *
     * @return null|string|string[]
     * @throws \PropelException
     */
    private function getEANFromManifestation($mId)
    {
        $m = ManifestationQuery::create()->findOneByManifestationId($mId);
        $ean = $m->getEan();

        if (!$ean) {
            $isbn = $m->getIsbnissn();

            if ($isbn) {
                $ean = Clavis::IsbnToEan13($isbn);
            }
        }
        return $ean;
    }
}