<?php
/**
 * ClavisInvoiceView class file
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 */

/**
 * ClavisInvoiceView
 *
 * @author Max Pigozzi
 * @link http://www.comperio.it
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @version 2.7
 * @package Widgets
 * @since 2.2
 */
class ClavisInvoiceView extends TTemplateControl
{
	const DELIVERY_DEFAULT_INTERVAL = 2592000;  //30gg in seconds
	private $_invoice = null;
	public $_systemCurrency;

	public function onLoad($param)
	{
		parent::onLoad($param);
		$this->_systemCurrency = ClavisParamQuery::getParam('CLAVISPARAM', 'SystemCurrency');
		if (!$this->getPage()->getIsPostBack())
		{
			$this->getInvoice();
			$this->populate();
		}
	}

	/**
	 * setter & getters
	 */
	public function setInvoice($invoice)
	{
		$this->_invoice = $invoice;
		$this->setControlState("invoice", $invoice, null);
	}

	public function getInvoice()
	{
		if (is_null($this->_invoice))
			$this->_invoice = $this->getControlState("invoice", null);

		return $this->_invoice;
	}

	public function setInventoryAmountValue($value)
	{
		$this->setControlState("InventoryAmountValue", $value, null);
	}

	public function getInventoryAmountValue()
	{
		return $this->getControlState("InventoryAmountValue", null);
	}

	public function populate()
	{
		if (is_null($this->_invoice))
			return;

		$this->InvoiceNumber->setText($this->_invoice->getInvoiceNumber());
		$this->InvoiceDate->setValue($this->_invoice->getInvoiceDate('U'));
		$this->InvoiceStatus->setText($this->_invoice->getInvoiceStatusString());

		$this->InventoryAmount->setCurrency($this->_systemCurrency);
		$this->ExtraCost->setCurrency($this->_systemCurrency);
		$this->TotalAmount->setCurrency($this->_systemCurrency);

		/*
		 * deprecated: new behaviour: sum of total amount
		 * is taken from the sum of inventorycost of items related
		 */
		//$this->TotalAmount->setValue($this->_invoice->getTotalAmount());

		$inventoryAmount = $this->invoice->getInventoryAmountValue();
		if ($inventoryAmount > 0)
			$this->InventoryAmount->setValue($inventoryAmount);

		$extraCost = $this->_invoice->getCurrierPrice();
		$this->ExtraCost->setValue($extraCost);

		$this->TotalAmount->setValue($inventoryAmount + $extraCost);

		$supplier = $this->_invoice->getSupplier();
		if ($supplier instanceof Supplier)
			$this->Supplier->setText($supplier->getSupplierName());

		$this->SupplierId->setValue($this->_invoice->getSupplierId());

		$this->Library->setText($this->_invoice->getLibraryLabel());
	}
	
}