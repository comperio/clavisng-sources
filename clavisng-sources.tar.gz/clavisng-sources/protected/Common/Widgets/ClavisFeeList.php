<?php

/**
 * Created by PhpStorm.
 * User: dario
 * Date: 9/01/2014
 * Time: 17:08
 */
class ClavisFeeList extends TTemplateControl
{
    /** @var  $patron Patron */
    private $patron;

    public function onInit($param)
    {
	    parent::onInit($param);
	    $this->attachEventHandler('OnActualLibraryChanged', array($this, 'OnActualLibraryChanged'));
	    $this->attachEventHandler("OnLoanUpdated",array($this,'onLoanUpdated'));
    }

	public function onLoad($param)
    {
        parent::onLoad($param);

		$this->patron = PatronQuery::create()->findOneByPatronId($this->getPatronId());
        
		if (!$this->getPage()->getIsPostBack()
				&& !$this->getPage()->getIsCallBack())
		{
			$this->reloadData();
		}
    }

	public function OnActualLibraryChanged($sender, $param)
	{
		$this->reloadData();
	}

    public function getPatronId()
    {
        return $this->getControlState("patronid",null);
    }

    public function onLoanUpdated($sender,$param)
    {
        $this->reloadData();
    }

    public function reloadData()
    {
        if($this->getApplication()->getModule('fee') == null) return;

        $data = $this->getApplication()->getModule('fee')->getPatronFeeDetail($this->patron);
        $this->lb1->Text = $data;

        $data = $this->getApplication()->getModule('fee')->getPatronFeeDetail($this->patron, false);
        $this->FeeRepeater->DataSource = $data['Loans'];
        $this->FeeRepeater->dataBind();

        $this->FeeSummaryRepeater->setControlState("Total",$data['Total']);
        $this->FeeSummaryRepeater->DataSource = $data['Summary'];
        $this->FeeSummaryRepeater->dataBind();

        if(count($data['Loans']) == 0)
        {
            $this->FeeRefreshButton->setVisible(false);
            $this->FeeSaveButton->setVisible(false);

        } else {
            $this->FeeRefreshButton->setVisible(true);
            $this->FeeSaveButton->setVisible(true);
        }

        $this->populateFeeGrid();
    }

    public function populateFeeGrid()
    {
        $query = $this->buildFeeFilterQuery();
        $this->FeeGrid->setVirtualItemCount($query->count());

        $query = $this->buildFeeFilterQuery(true);
        $ppo = $query->find()->toArray();
        $this->FeeGrid->DataSource = $query->find()->toArray();
        $this->FeeGrid->dataBind();
    }

    public function setPatronId($patronid)
    {
        $this->setControlState("patronid", $patronid, null);
    }

    /**
     * Refresh Fees calculation using user provided addendum
     * @param $sender
     * @param $param
     */
    public function updateFees($sender, $param)
    {
        $dataKeys = $this->FeeRepeater->getDataKeys();
        $count=0;
        foreach ($this->FeeRepeater->Items as $item) {
            $loanid = $dataKeys->itemAt($count++);

            $lateDays = $item->LateDays->getText();
            $graceDays = TPropertyValue::ensureInteger($item->GraceDays->getText());
            $graceNote = $item->GraceNote->getSafeText();
            //if($graceDays == 0) continue;

            $lf = LoanFeeQuery::create()->findOneByLoanId($loanid);
            //Update FeeData
            $lf->setGraceDays($graceDays);
            $lf->setGraceNote($graceNote);
            $lf->save();

        }
        $this->reloadData();

    }

    public function saveFees($sender, $param)
    {
        if($this->getApplication()->getModule('fee') == null) return;

        $data = $this->getApplication()->getModule('fee')->getPatronFeeDetail($this->patron, false);
        if(count($data['Loans']) == 0)  return;

        if($data['Total'] > 0.0)
        {
            $wallet = new PatronWallet();
            $wallet->setPatron($this->patron);
            $wallet->setLibraryId($this->getUser()->getActualLibraryId());
            $wallet->setWalletType("F");   // Fees
            $wallet->setWalletStatus("A"); // Open
            $wallet->setWalletAction("D"); //Deposit
            $wallet->setAmount($data['Total']);
            $wallet->save();
        } else {
            $wallet = null;
        }

        $dataKeys = $this->FeeRepeater->getDataKeys();
        $count=0;
        foreach ($this->FeeRepeater->Items as $item) {
            $loanid = $dataKeys->itemAt($count++);

            $lf = LoanFeeQuery::create()->findOneByLoanId($loanid);
            $lf->setFeeStatus("C"); //Closed

            $lf->setPatronWallet($wallet);
            $lf->save();
        }
        $this->reloadData();
        $this->broadcastEvent("OnFeeUpdated",$this,new TBroadcastEventParameter());
    }


    private function buildFeeFilterQuery($applyPaging = false)
    {
        $feeFilter = LoanFeeQuery::create()
            ->joinLoan()
            ->filterByFeeStatus(array("C","D") ) // Closed & Deleted
            ->filterByPatronId($this->getPatronId())
            ->withColumn("(SELECT username FROM librarian WHERE librarian_id=LoanFee.ModifiedBy)","LibrarianName")
            ->_if($applyPaging)
                ->withColumn("Loan.Title","LoanTitle")
                ->withColumn("Loan.ItemId","ItemId")
                ->withColumn("(SELECT label FROM library l WHERE l.library_id=loan_fee.library_id LIMIT 1)","LibraryLabel")
                ->withColumn("DATEDIFF(loan_date_end,due_date)","ReturnDelay")
                ->limit($this->FeeGrid->getPageSize())
                ->offset($this->FeeGrid->getCurrentPageIndex() * $this->FeeGrid->getPageSize())
            ->_endif()
            ->orderBy('Loan.LoanDateEnd')
            ;

        return $feeFilter;
    }

    public function onFeeGridPageIndexChange($sender, $param)
    {
        $this->FeeGrid->setCurrentPage($param->NewPageIndex);
        $this->populateFeeGrid();
    }

    public function onChangePageSize($sender, $param)
    {
        $newPageSize = intval($sender->getSelectedValue());
        if ($newPageSize > 0)
        {
            $this->setPageSize($newPageSize);
            $this->resetPagination();
            $this->populateFeeGrid();
        }
    }
}