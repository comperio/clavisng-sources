<?php
Prado::using("System.Web.UI.WebControls.THyperLink");

/**
 * ClavisEncodingHyperLink
 *
 * @author Marco Brancalion <mbrancalion@e-portaltech.it>
 * @link http://www.e-portaltech.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @license http://www.e-portaltech.it/license/
 */
class ClavisEncodingHyperLink extends THyperLink
{
	/**
	 * @return boolean whether the rendered text should be HTML-encoded. Defaults to false.
	 */
	public function getEncode()
	{
		return $this->getViewState('Encode', false);
	}

	/**
	 * @param boolean  whether the rendered text should be HTML-encoded.
	 */
	public function setEncode($value)
	{
		$this->setViewState('Encode', TPropertyValue::ensureBoolean($value), false);
	}

	public function renderContents($writer)
	{
		if (($text = $this->getText()) !== '')
		{
			if ($this->getEncode())
				$writer->write(THttpUtility::htmlEncode($text));
			else
				$writer->write($text);
		}
		else
			parent::renderContents($writer);
	}
	
}