<?php
/**
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2010 Comperio srl
 * @license http://www.comperio.it/license/
 */
class ClavisIssueEdit extends TTemplateControl
{
	/* @var Issue */
	public $issue;

	public function onLoad($param)
	{
		parent::onLoad($param);
		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallback())
		{
			$this->populate();
		}
	}

	public function setIssueId($value)
	{
		$this->setControlState('issueId', intval($value), null);
	}

	public function getIssueId()
	{
		return $this->getControlState('issueId', null);
	}

	public function setIssue(Issue $value)
	{
		$this->issue = $value;
		$this->setIssueId($this->issue->getIssueId());
	}

	public function getIssue()
	{
		if (!$this->issue instanceof Issue)
			$this->issue = IssuePeer::retrieveByPK($this->getIssueId());
		return $this->issue;
	}

	public function onSave($sender, $param)
	{
		$issue = $this->getIssue();
		$issue->setIssueNumber($this->IssueNumber->getSafeText());
		$issue->setIssueYear($this->IssueYear->getSafeText());
		$issue->setIssueVolume($this->IssueVolume->getSafeText());
		$issue->setIssueType($this->IssueType->getSelectedValue());
		$issue->setIssueDate($this->IssueDate->getTimestamp());
		$issue->setStartNumber($this->StartNumber->getSafeText());
		$issue->setEndNumber($this->EndNumber->getSafeText());
		$issue->setIssueNote($this->IssueNote->getSafeText());

		$wasnew = $issue->isNew();

		$issue->save();

		$this->setIssue($issue);

		if ($wasNew)
		{
			ChangelogPeer::logAction($issue, ChangelogPeer::LOG_CREATE, $this->getUser);
			$this->getPage()->writeDelayedMessage(Prado::localize('Fascicolo inserito con successo'), ClavisMessage::CONFIRM);
		}
		else
		{
			ChangelogPeer::logAction($issue, ChangelogPeer::LOG_UPDATE, $this->getUser);
			$this->getPage()->writeDelayedMessage(Prado::localize('Fascicolo modificato con successo'), ClavisMessage::CONFIRM);
		}
	}

	public function populate()
	{
		if ($this->_issue === null)
			return;

		$manifestation = ManifestationPeer::retrieveByPK($this->_issue->getManifestationId());
		$this->ManifestationView->setManifestation($manifestation);

		$this->IssueNumber->setText($this->_issue->getIssueNumber());
		$this->IssueYear->setText($this->_issue->getIssueYear());
		$this->IssueVolume->setText($this->_issue->getIssueVolume());
		$this->IssueType->setSelectedValue($this->_issue->getIssueType());
		$this->IssueDate->setTimestamp($this->_issue->getIssueDate('U'));
		$this->StartNumber->setText($this->_issue->getStartNumber());
		$this->EndNumber->setText($this->_issue->getEndNumber());
		$this->IssueNote->setText($this->_issue->getIssueNote());

		$this->AttachList->setObjectClass('Issue');
		$this->AttachList->setObjectId($this->_issue->getIssueId());
	}
	
}