<?php
/**
 * TPopupLinkButton class
 * 
 * Extends a Prado TLinkButton with the capabilities to open an iframe,
 * and passes the two Id's of the controls (ex. TTextBox) where the
 * iframe will write a "label" and a "value".
 * (NB: this controls must generate an html "<input ..>" tag, so a TLabel
 * has not to be used.....)
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @author Ciro Mattia Gonano
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2008 ePortal Technologies
 * @copyright Copyright &copy; 2009 Comperio srl
 * @version 2.7
 * @package Controls
 * @since 2.0
 */

class TPopupLinkButton extends TActiveLinkButton
{
	/**
	 * Registers the javascript code and publishes in the
	 * Prado assets directory.
	 *
	 * @param TEventParameter $param
	 */
	public function onPreRender($param)
	{
		parent::onPreRender($param);

		$scripts = $this->getPage()->getClientScript();
		$scripts->registerPradoScript('prado');

		if (!$scripts->isScriptFileRegistered('ButtonFunctions.js'))
			$scripts->registerScriptFile(	'ButtonFunctions.js',
											$this->publishFilePath(Prado::getPathOfNamespace('Application.Javascript')) . '/ButtonFunctions.js');
	}

	/**
	 * Sets the url of the iframe which has to be open.
	 *
	 * @param string $value
	 */
	public function setPopupPage($value)
	{
		//TODO  fare un controllo se il file esiste

		//$url = "index.php?page=" . $value;
		$this->setControlState('PopupPage', $value, '');
	}

	/**
	 * Gets the url of the iframe.
	 *
	 * @return string
	 */
	public function getPopupPage()
	{
		return $this->getControlState('PopupPage', '');
	}

	/**
	 * Sets the Prado Id of the control where a (string) label
	 * will be returned by the iframe.
	 *
	 * @param string $label
	 */
	public function setReturnLabel($label)
	{
		$this->setControlState('ReturnLabel', $label, '');
	}

	/**
	 * Returns the Prado Id of the label.
	 *
	 * @return string
	 */
	public function getReturnLabel()
	{
		return $this->getControlState('ReturnLabel', '');
	}

	/**
	 * Sets the Prado Id of the control where a (mixed) value
	 * will be returned by the iframe.
	 *
	 * @param string $value
	 */
	public function setReturnValue($value)
	{
		$this->setControlState('ReturnValue', $value, '');
	}

	/**
	 * Returns the Prado Id of the value.
	 *
	 * @return string
	 */
	public function getReturnValue()
	{
		return $this->getControlState('ReturnValue', '');
	}

	/**
	 * Sets the Prado Id of the control where a (string) label
	 * will be returned by the iframe.
	 *
	 * @param string $label
	 */
	public function setReturnLabel2($label)
	{
		$this->setControlState('ReturnLabel2', $label, '');
	}

	/**
	 * Returns the Prado Id of the label.
	 *
	 * @return string
	 */
	public function getReturnLabel2()
	{
		return $this->getControlState('ReturnLabel2', '');
	}

	/**
	 * Sets the Prado Id of the control where a (mixed) value
	 * will be returned by the iframe.
	 *
	 * @param string $value
	 */
	public function setReturnValue2($value)
	{
		$this->setControlState('ReturnValue2', $value, '');
	}

	/**
	 * Returns the Prado Id of the value.
	 *
	 * @return string
	 */
	public function getReturnValue2()
	{
		return $this->getControlState('ReturnValue2', '');
	}

	/**
	 * Sets the popup's return auto submit mode.
	 * By default it's false.
	 *
	 * @param string $value
	 */
	public function setAutoSubmit($value)
	{
		$this->setControlState('AutoSubmit', TPropertyValue::ensureBoolean($value), false);
	}

	/**
	 * Gets the popup's return auto submit mode.
	 * By default it's false.
	 *
	 * @return string
	 */
	public function getAutoSubmit()
	{
		return $this->getControlState('AutoSubmit', false);
	}

	/**
	 * Sets the optional confirm message to be shown before opening the popup
	 *
	 * @param string $value
	 */
	public function setConfirmMessage($value)
	{
		$this->setControlState('ConfirmMessage', $value, false);
	}

	/**
	 * Gets the optional confirm message to be shown before opening the popup
	 *
	 * @return string
	 */
	public function getConfirmMessage()
	{
		return $this->getControlState('ConfirmMessage', '');
	}

	/**
	 * Specify a callback function to call on popup closing.
	 *
	 * @param string $function The callback function, defaults to ''.
	 */
	public function setCallbackFunction($function)
	{
		$this->setControlState('CallbackFunction', $function, '');
	}

	/**
	 * Returns the callback function to call on popup closing.
	 *
	 * @return string The callback function, defaults to ''.
	 */
	public function getCallbackFunction()
	{
		return $this->getControlState('CallbackFunction','');
	}

	/**
	 * Sets an optional parameter to pass to the popup page.
	 *
	 * @param mixed $value The parameter to pass.
	 */
	public function setParam($value)
	{
		$this->setControlState('Param', $value, null);
	}

	/**
	 * Returns the optional parameter passed to the component.
	 *
	 * @return string The specified parameter, defaults to null.
	 */
	public function getParam()
	{
		return $this->getControlState('Param', null);
	}

	/**
	 * Sets an optional object type to pass to the popup page.
	 *
	 * @param mixed $value The object type to pass.
	 */
	public function setObjectType($type)
	{
		$this->setControlState('ObjectType', $type, null);
	}

	/**
	 * Returns the optional object type passed to the component.
	 *
	 * @return string The specified object type, defaults to null.
	 */
	public function getObjectType()
	{
		return $this->getControlState('ObjectType', null);
	}

	/**
	 * Extends the Prado method which attaches an attribute
	 * to a control, so to add the "onclick" attribute which
	 * will point to the javascript function which opens the
	 * iframe (with parameters).
	 *
	 * @see protected/Javascript/ButtonFunctions.js
	 * @param THtmlWriter $writer
	 */
	protected function addAttributesToRender($writer)
	{
		/* function openIframe(page, labelId, valueId, formId, callbackFunction, confirmMessage, label2Id, value2Id, param, objectType) */

		/* page */
		$paramString = "openIframe('{$this->getPopupPage()}'";

		/* labelId */
		if (($label = $this->getReturnLabel()) !== '')
		{
			if ($control = $this->getExternalControl($label))
			{
				$paramString .= ",'{$control->getClientID()}'";
			}
			else
			{
				throw new TInvalidDataValueException('ReturnLabel_associatedcontrol_invalid',$label);
			}
		}
		else
		{
			$paramString .= ',null';
		}

		/* valueId */
		if (($value = $this->getReturnValue()) !== '')
		{
			if ($control = $this->getExternalControl($value))
			{
				$paramString .= ",'{$control->getClientID()}'";
			}
			else
			{
				throw new TInvalidDataValueException('ReturnValue_associatedcontrol_invalid',$value);
			}
		}
		else
		{
			$paramString .= ',null';
		}

		/* formId */
		$paramString .= ($this->getAutoSubmit() == true)
							? ",'{$this->getPage()->getForm()->getClientId()}'"
							: ',null';

		/* callbackFunction */
		$callback = $this->getCallbackFunction();
		$paramString .= $callback
							? ",'{$callback}'"
							: ',null';

		/* confirmMessage */
		$confirmMessage = $this->getConfirmMessage();
		$paramString .= $confirmMessage
							? ",'".str_replace('\'','\\\'',$confirmMessage)."'"
							: ',null';

		/* label2Id */
		if (($label2 = $this->getReturnLabel2()) !== '')
		{
			if ($control = $this->getExternalControl($label2))
			{
				$paramString .= ",'{$control->getClientID()}'";
			}
			else
			{
				throw new TInvalidDataValueException('ReturnLabel_associatedcontrol_invalid',$label);
			}
		}
		else
		{
			$paramString .= ',null';
		}

		/* value2Id */
		if (($value2 = $this->getReturnValue2()) !== '')
		{
			if ($control = $this->getExternalControl($value2))
			{
				$paramString .= ",'{$control->getClientID()}'";
			}
			else
			{
				throw new TInvalidDataValueException('ReturnValue_associatedcontrol_invalid',$value);
			}
		}
		else
		{
			$paramString .= ',null';
		}

		/* param */
		$param = $this->getParam();
		
		if ($param)
		{
			if (is_array($param) 
					|| is_object($param))
			{
				$paramString .= ",'".str_replace('\'','\\\'',serialize($param))."'";
			}
			else
			{
				$paramString .= ",'".str_replace('\'','\\\'',$param)."'";
			}
		} 
		else
		{
			$paramString .= ',null';
		}

		/* objectType */
		$objType = $this->getObjectType();
		
		$paramString .= $objType
							? ",'{$objType}'"
							: ',null';
							
		$paramString .= '); return false;';
		$writer->addAttribute('onclick', $paramString);

		parent::addAttributesToRender($writer);
	}

	/**
	 * Searches for control identified by argument within the current naming container;
	 * if it is not found, fallbacks on searching it in the entire page.
	 * If there are ambiguities, returns null.
	 *
	 * @param string $id The external control's ID.
	 * @return TControl The control if found, null elsewhere.
	 */
	protected function getExternalControl($id)
	{
		$control = $this->findControl($id);
	
		if (!$control)
		{
			$control = $this->getPage()->findControlsByID($id);
			$control = (is_array($control) && count($control) == 1) ? $control[0] : null;
		}
		
		return $control;
	}
	
}