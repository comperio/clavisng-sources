<?php
/**
 * ClavisControlPanel class file
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 */
Prado::using('Application.Console.*');

/**
 * ClavisControlPanel Class
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2008 ePortal Technologies
 * @copyright Copyright &copy; 2009 Comperio srl
 * @version 2.7
 * @package Widgets
 * @since 2.5.0
 */
class ClavisControlPanel extends TTemplateControl
{
	public function onLoad($param)
	{
		parent::onLoad($param);
		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallback())
		{
			$this->populate();
		}
	}

	protected function populate()
	{
		
	}

	private function getActionName($action)
	{
		return str_replace(' ', '', ucwords(str_replace('_', ' ', strtolower($action))));
	}

	protected function performAction($actionName, $params = array())
	{
		$actionName = $this->getActionName($actionName);
		try
		{
			Prado::using('Application.Console.' . $actionName);
			$actionClass = 'ClavisAction' . $actionName;
			$action = new $actionClass;
		}
		catch (Exception $e)
		{
			$this->getPage()->writeMessage(
					Prado::localize("Azione non riconosciuta"), ClavisMessage::ERROR);
			return;
		}
		ob_start();
		//register action class and run
		if ($action->isValidAction($params))
		{
			if (!$action->performAction($params))
			{
				$this->getPage()->writeMessage(Prado::localize("Esecuzione fallita!"), ClavisMessage::ERROR);
				return;
			}
		}
		else
		{
			$this->getPage()->writeMessage(Prado::localize("Parametri errati"), ClavisMessage::ERROR);
			return;
		}
		$out = ob_get_clean();
		$this->Output->setText($out);
		$this->getPage()->writeMessage(Prado::localize("Azione '{action}' completata", array('action' => $actionName)), ClavisMessage::CONFIRM);
		return;
	}

	public function doCleanup($sender, $param)
	{
		$this->performAction('cleanup', array('cleanup'));
	}

	public function doParseQuery($sender, $param)
	{
		$this->performAction('parse_query', array('parse_query'));
	}

	public function doUpdate($sender, $param)
	{
		$basePath = Clavis::getBasePath();
		if (file_exists($basePath . '/.svn'))
		{
			chdir($basePath);
			$out = exec("2>&1 svn update --non-interactive", $output, $retval);
		}
		else if (file_exists($basePath . '/.git'))
		{
			chdir($basePath);
			$out = exec("2>&1 git pull", $output, $retval);
		}
		$this->Output->setText(implode("\n", $output));
		if ($retval != 0)
			$this->getPage()->writeMessage(Prado::localize("[{retval}] Errore nell'aggiornamento, controllare i log", array('retval' => $retval)), ClavisMessage::ERROR);
		else
			$this->getPage()->writeMessage(Prado::localize("Aggiornamento completato"), ClavisMessage::CONFIRM);
	}

	public function doI18N($sender, $param)
	{
		$this->performAction('i18n', array('i18n', 'en_US'));
	}

	public function doTestAction($sender, $param)
	{
		$this->performAction('cache_tmarc', array('cache_tmarc', 'full', 'a79'));
		/* Prado::using('Application.Services.SOAP.*');
		  $soap = new LoanFunctions();
		  //$soap->addReservation(16954, 'P57305', 2, 86);
		  $soap->addReservation(16954, 'P57305', 2, 89); */
	}
	
}