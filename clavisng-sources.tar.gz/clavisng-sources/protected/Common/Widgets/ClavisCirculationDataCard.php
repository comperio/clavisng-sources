<?php

/**
 * ClavisCirculationDataCard class
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @version 2.8.9
 * @package Widgets
 * @since 2.0
 */

class ClavisCirculationDataCard extends TActiveLabel
{
	const DIRECTION_LOAN = 1;
	const DIRECTION_RETURN = 0;

	private $_bufferSessionName;
	private $_patronIdSessionName;
	private $_formIdSessionName;
	
    /** @var  $_loanmanager ClavisLoanManager */
	private $_loanmanager;
	
	private function initVars()
	{
		$uniqueId = $this->getUniqueID();
		$this->_bufferSessionName = 'BufferSessionName' . $uniqueId;
		$this->_formIdSessionName = 'FormIdSessionName' . $uniqueId;
		$this->_patronIdSessionName = 'PatronIdSessionName' . $uniqueId;
		$this->_loanmanager = $this->getApplication()->getModule('loan');
	}

	public function onInit($param)
	{
		parent::onInit($param);
		$this->initVars();

		if (!$this->getPage()->getIsPostBack() )
		{
			$this->setPatronId(null);
			$this->setBuffer(null);
		}
	}

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (($buffer = $this->getBuffer()) != null)
			$this->setText($buffer);
	}

	public function onPreRender($param)
	{
		parent::onPreRender($param);

		$scripts = $this->getPage()->getClientScript();
		$scripts->registerPradoScript('prado');
		$scripts->registerPradoScript('effects');
		
		if (!$scripts->isScriptFileRegistered('ButtonFunctions.js'))
			$scripts->registerScriptFile(	'ButtonFunctions.js',
											$this->publishFilePath(Prado::getPathOfNamespace('Application.Javascript')) . '/ButtonFunctions.js');
	}

	public function setBuffer($buffer = null)
	{
		$this->getApplication()->getSession()->add($this->_bufferSessionName, $buffer);
	}

	public function getBuffer()
	{
		$buffer = $this->getApplication()->getSession()->itemAt($this->_bufferSessionName);
		
		return $buffer;
	}

	public function setPatronId($patronId = null)
	{
		$this->getApplication()->getSession()->add($this->_patronIdSessionName, $patronId);
	}

	public function getPatronId()
	{
		return $this->getApplication()->getSession()->itemAt($this->_patronIdSessionName);
	}

	public function populate($patronId = null, $messageItemId = null, $direction = self::DIRECTION_LOAN)
	{
		$myLibraryId = $this->getUser()->getActualLibraryId();
		
		if (($direction != self::DIRECTION_LOAN) 
				&& ($direction != self::DIRECTION_RETURN))
			$direction = self::DIRECTION_LOAN;

		$patron = null;
		
		if (is_null($patronId))
			$patronId = $this->getPatronId();
		
		if ($patronId > 0)
			$patron = PatronQuery::create()->findPK($patronId);

		if ($patron instanceof Patron)
		{
			$this->setPatronId($patronId);
			$bufferTemplate = '

			<div id="loantabs">
                <ul>
                    <li><a href="#" onclick="selecttab(this)" rel="url1" class="selected">%%ONLOANTAB%%</a></li>
                    <li><a href="#" onclick="selecttab(this)" rel="url2">%%READYFORLOANTAB%%</a></li>
                    <li><a href="#" onclick="selecttab(this)" rel="url3">%%INTRANSITTAB%%</a></li>
                    <li><a href="#" onclick="selecttab(this)" rel="url4">%%RESERVATIONTAB%%</a></li>
                </ul>
            </div>
            <div id="loancontainer">
                <div id="url1" class="innertabselected"><br/>%%ONLOAN%%</div>
                <div id="url2" class="innertab"><br/>%%READYFORLOAN%%</div>
                <div id="url3" class="innertab"><br/>%%INTRANSIT%%</div>
                <div id="url4" class="innertab"><br/>%%RESERVATION%%</div>
            </div>
			';

            $buffer = "";
			
			/**
			 * header
			 */
			$bufferHeader = '<fieldset class="formfieldset circulationdatacard">
							<legend class="formlegend">' . Prado::localize('Circolazione utente') . '</legend>';

			$formId = $this->getPage()->getForm()->getClientId();

			/**
			 * on loan list
			 */
			$loans = LoanQuery::create()
						->filterByPatron($patron)
						->filterByLoanStatus(ItemPeer::getLoanStatusCurrent())
						->orderByDueDate();
			
			$loan_count = $loans->count();
			$allRenewableLoanIds = array();
			$myRenewableLoanIds = array();

            $bufferTemplate = str_replace("%%ONLOANTAB%%",Prado::localize('In corso ({count})', array('count' => $loan_count)), $bufferTemplate);
			$buffer = '<table width="100%"><tbody>';

			/* @var $loan Loan */
			foreach ($loans->find() as $loan)
			{
				$item = $loan->getItem();
				
				if (!$item instanceof Item)
					continue;

				$buffer .= '<tr><td width="70%" valign="top">';

				$manifestation = $item->getManifestation();
				
				$tit = (!($manifestation instanceof Manifestation))
					? $item->getTrimmedTitle(100, false)
					: $manifestation->getTrimmedTitle(100,false);

				$buffer .= "<em><strong>{$tit}</strong></em> [&nbsp;<a href=\""
								.$this->getService()->constructUrl('Catalog.ItemViewPage', array('id'=>$item->getItemId()))
								.'">'.Prado::localize('vedi').'</a>';

				if ($this->getApplication()->getUser()->getEditPermission($item))
				{
					$buffer .= ' | <a target="_self" href="javascript:void(0)" onclick="openIframe(\'Catalog.ItemEditPopup\',null,null,\''.
						$formId.'\',null,null,null,null,\'' . $item->getItemId().'\',\'Item\'); return false;">'.
						Prado::localize('modifica').'</a> ] ';
				}
				
				$collocationCombo = $item->getCollocationCombo();
				
				if ($collocationCombo != "")
					$collocationCombo = "-" . $collocationCombo;
				
                $buffer .= $item->getBarcode() . $collocationCombo . '<br/>';

                $buffer .= Prado::localize("[Di: {homeLib}] [Prestante: {actualLib}]",
                        array('homeLib' => ($item->isExternal())?$item->getOwnerLibraryLabel():$item->getHomeLibraryLabel(),'actualLib' => $item->getActualLibraryLabel() ));

				$buffer .= '</td><td>';

				if ($item->getCheckOut('U'))
				{
					$buffer .= Prado::localize('Prestato il {date}', array('date' => Clavis::dateFormat($item->getCheckOut('U'))));
				}
				
				if ($this->_loanmanager->isLoanLate($loan) == ClavisLoanManager::LOAN_ISLATE)
				{
					$buffer .= "<br/>". Prado::localize('<span class="label label-danger">SCADUTO</span> il {duedate}',array('duedate'=>Clavis::dateFormat($loan->getDueDate('U'))));
				}
                else
				{
					$buffer .= "<br/>". Prado::localize('Scade il <b>{duedate}</b> ',array('duedate'=>Clavis::dateFormat($loan->getDueDate('U'))));
				}

				$buffer .= '<br/> '.Prado::localize('Notifiche: {notify} - Proroghe: {renewal}',
														array(	'notify' => $item->getNotifyCount(), 
																'renewal' => $item->getRenewalCountLabel() )) . '<br/>';
				
				$buffer .= '(<a href="'.$this->getService()->constructUrl(	'Circulation.NewLoan',
																			array(	'itemId' => $item->getItemId(),
																					'patronId' => $patronId )) . '">' . Prado::localize('rientra') . '</a>)';

				if ($this->_loanmanager->IsLoanSolicitable($item, $this->getUser()) == ClavisLoanManager::OK)
				{
					$buffer .= '(<a href="'.$this->getService()->constructUrl(	'Circulation.ManageSolicit',
																				array('itemId' => $item->getItemId())) . '">'.Prado::localize('sollecita') . '</a>)';
				}
				
				//$buffer .= '<br />'.Prado::localize('Data di restituzione: {duedate}',
				//	array('duedate' => Clavis::dateFormat($item->getDueDate('U')))) . '&nbsp;';

				if ($this->_loanmanager->IsLoanRenewable($item, $this->getUser(), $this->_loanmanager->getLoanDestinationObject($loan))	== ClavisLoanManager::OK )
				{
					$isAskRenew = $item->isAskRenew($myLibraryId);
					
					$buffer .= '(<a target="_self" href="javascript:void(0)" onclick="openIframe(\'Circulation.RenewItemPopup\',null,null,\''
									. $formId . '\',null,null,null,null,\'' . $item->getItemId() . '\',\'Item\'); return false;">'
									. Prado::localize('proroga') . '</a>)&nbsp;';

					if ($isAskRenew)
					{
						$buffer .= '(<a target="_self" href="javascript:void(0)" onclick="openIframe(\'Circulation.SuspendRenewPopup\',null,null,\''
										. $formId . '\',null,null,null,null,\'' . $item->getItemId() . '\',\'Item\'); return false;">'
										. Prado::localize('sospendi-proroga') . '</a>)&nbsp;';
					}
					
					if ($item->getActualLibraryId() == $myLibraryId)
					{
						$myRenewableLoanIds[] = $loan->getLoanId();
					}

					$allRenewableLoanIds[] = $loan->getLoanId();

					if ($isAskRenew)
					{
						$buffer .= '(<a target="_self" href="javascript:void(0)" onclick="openIframe(\'Circulation.AskRenewPopup\',null,null,\''
										. $formId . '\',null,null,null,null,\'' . $item->getItemId() . '\',\'Item\'); return false;">'
										. Prado::localize('richiedi-proroga') . '</a>)&nbsp;';
					}
				}
				
				$buffer .= "</td></tr>";
			}
			
			$buffer .= '</tbody></table>';

//            if (count($myRenewableLoanIds) > 0)
//			{
//				$buffer .= '<a target="_self" href="javascript:void(0)" onclick="openIframe(\'Circulation.RenewItemPopup\',null,null,\''
//								. $formId . '\',null,null,null,null,\'' . serialize($myRenewableLoanIds) . '\',\'Array\'); return false;">'
//								. Prado::localize('proroga solo i prestiti effettuati da questa biblioteca') . ' (' . count($myRenewableLoanIds) . ')</a>&nbsp;&nbsp;&nbsp;&nbsp;';
//			}
//
//            if (count($allRenewableLoanIds) > 0)
//			{
//				$buffer .= '<a target="_self" href="javascript:void(0)" onclick="openIframe(\'Circulation.RenewItemPopup\',null,null,\''
//								. $formId . '\',null,null,null,null,\'' . serialize($allRenewableLoanIds) . '\',\'Array\'); return false;">'
//								. Prado::localize('proroga tutti i prestiti') . ' (' . count($allRenewableLoanIds) . ')</a><br /><br />';
//			}

			if (count($myRenewableLoanIds) > 0)
			{
				$myCount = count($myRenewableLoanIds);
				$myRenewableLoanIds[-1] = 0;

				$buffer .= '<a target="_self" href="javascript:void(0)" onclick="openIframe(\'Circulation.RenewItemPopup\',null,null,\''
								. $formId . '\',null,null,null,null,\'' . serialize($myRenewableLoanIds) . '\',\'Array\'); return false;">'
								. Prado::localize('proroga solo i prestiti effettuati da questa biblioteca') . ' (' . $myCount . ')</a>&nbsp;&nbsp;&nbsp;&nbsp;';
			}

            if (count($allRenewableLoanIds) > 0)
			{
				$allCount = count($allRenewableLoanIds);
				$allRenewableLoanIds[-1] = 1;

				$buffer .= '<a target="_self" href="javascript:void(0)" onclick="openIframe(\'Circulation.RenewItemPopup\',null, null,\'' 
								. $formId . '\',null,null,null,null,\'' . serialize($allRenewableLoanIds) . '\',\'Array\'); return false;">'
								. Prado::localize('proroga tutti i prestiti') . ' (' . $allCount . ')</a>';
			}

            $bufferTemplate = str_replace("%%ONLOAN%%", $buffer, $bufferTemplate);

            /**
			 * READY FOR LOAN
			 */
			$loans = LoanQuery::create()
						->filterByPatron($patron)
						->filterByLoanStatus(ItemPeer::LOANSTATUS_READYFORLOAN);
			
			$loan_count = $loans->count();
			$readyItemIds = array();

            $bufferTemplate = str_replace("%%READYFORLOANTAB%%", Prado::localize('Pronti ({count})', array('count' => $loan_count)), $bufferTemplate);
            $buffer = '<table width="100%"><tbody>';

            foreach ($loans->find() as $loan)
			{
				$item = $loan->getItem();

				if (!$item instanceof Item)
					continue;

				$buffer .= '<tr><td width="70%">';

				$manifestation = $item->getManifestation();

				$tit = (!($manifestation instanceof Manifestation)
								? $item->getTrimmedTitle(100, false)
								: $manifestation->getTrimmedTitle(100, false));
				
				$buffer .= "<em><strong>{$tit}</strong></em>&nbsp;(<a href=\""
								. $this->getService()->constructUrl('Catalog.ItemViewPage', array('id'=>$item->getItemId()))
								. '">' . Prado::localize('vedi') . '</a>)&nbsp;';

				if ($this->getApplication()->getUser()->getEditPermission($item))
				{
					$buffer .= '(<a target="_self" href="javascript:void(0)" onclick="openIframe(\'Catalog.ItemEditPopup\',null,null,\''
									. $formId . '\',null,null,null,null,\'' . $item->getItemId().'\',\'Item\'); return false;">'
									. Prado::localize('modifica') . '</a>)&nbsp;';
				}
				
                $buffer .= $item->getBarcode();

                $buffer .= "<br/>" . Prado::localize("[Di: {homeLib}] [Si trova a: {actualLib}]",
														array(	'homeLib' => $item->isExternal() 
																				? $item->getOwnerLibraryLabel() 
																				: $item->getHomeLibraryLabel(),
															
																'actualLib' => $item->getActualLibraryId() != $this->getUser()->getActualLibraryId()
																				? '<span class="label label-default" style="text-transform: uppercase;">' . $item->getActualLibraryLabel() . "</span>"
																				: $item->getActualLibraryLabel() ));

                $buffer .= '</td><td>';

                $buffer .= Prado::localize("Notifiche") .":" . $item->getNotifyCount() . "<br/>";
				
                $buffer .= Prado::localize("Ultimo movimento il {lastseen}",
												array("lastseen" => Clavis::dateFormat($item->getLastSeen('U')))) . "<br/>";
                
				$waitingDays = floor((time() - $item->getLastSeen('U'))/86400 );
                $limitWait = $this->_loanmanager->CalculateWaitingDelta($item->getActualLibraryId(), $this->getUser()->getActualLibraryId());

                $buffer .= Prado::localize("In attesa da {days} giorni",
											array("days" => ($waitingDays > $limitWait)
																? "<span class=\"badge\">{$waitingDays}</span>"
																: $waitingDays ) ) ."<br/>";

				if (($this->_loanmanager->IsItemAvailable($item, $myLibraryId, $patron) == ClavisLoanManager::OK)
						&&  ($this->_loanmanager->IsPatronAllowedToLoan($patron,$item->getItemId()) == ClavisLoanManager::OK)
						&&  ($item->getActualLibraryId() == $this->getUser()->getActualLibraryId()))
                {
					$buffer .= '(<a href="' . $this->getService()->constructUrl(	'Circulation.NewLoan',
																					array(	'itemId' => $item->getItemId(),
																							'patronId' => $patronId ))
									. '">' . Prado::localize('presta') . '</a>)&nbsp;';

                    $buffer .= '(<a href="'.$this->getService()->constructUrl(	'Circulation.ManageSolicit',
																				array('loanId' => $item->getCurrentLoanId()))
									. '">' . Prado::localize('notifica') . '</a>)&nbsp;';

					$readyItemIds[] = $item->getItemId();
				}

                $buffer .= '</td></tr>';
			}

			$buffer .= '</tbody></table>';

			if (count($readyItemIds) > 0)
			{
				$buffer .= '<a href="'.$this->getService()->constructUrl(	'Circulation.NewLoan',
																			array(	'itemId' => $readyItemIds, 
																					'patronId' => $patronId ), true, false)
								. '">' . Prado::localize('presta tutti i disponibili in biblioteca') . ' (' . count($readyItemIds) . ')</a><br/><br/>';
			}

            $bufferTemplate = str_replace("%%READYFORLOAN%%", $buffer, $bufferTemplate);

			/**
			 * OTHER LOAN TYPES
			 */
			$loans = LoanQuery::create()
						->filterByPatron($patron)
						->filterByLoanStatus(ItemPeer::getLoanStatusActiveNotCurrent())
						->orderByLoanStatus();
			
			$loan_count = $loans->count();

	        $bufferTemplate = str_replace(	"%%INTRANSITTAB%%",
											Prado::localize('In transito ({count})', 
																array('count' => $loan_count)),
					
											$bufferTemplate);

            $buffer = "<table width=\"100%\"><tbody>";
			
			foreach ($loans->find() as $loan)
			{
				$item = $loan->getItem();
			
				if (!($item instanceof Item))
					continue;

				$buffer .= '<tr><td width="70%" valign="top">';

				$manifestation = $item->getManifestation();
				
				$tit = (!($manifestation instanceof Manifestation)
								? $item->getTrimmedTitle(100, false)
								: $manifestation->getTrimmedTitle(100, false));

				$buffer .= "<em><strong>{$tit}</strong></em>&nbsp;(<a href=\""
								. $this->getService()->constructUrl('Catalog.ItemViewPage', array('id' => $item->getItemId())) . '">'
								. Prado::localize('vedi') . '</a>)&nbsp;';

				if ($this->getApplication()->getUser()->getEditPermission($item))
				{
					$buffer .= '(<a target="_self" href="javascript:void(0)" onclick="openIframe(\'Catalog.ItemEditPopup\',null,null,\''
									. $formId . '\',null,null,null,null,\'' . $item->getItemId().'\',\'Item\'); return false;">'
									. Prado::localize('modifica') . '</a>)';
				}
				
                $buffer .= "<br/>".Prado::localize("[Di: {homeLib}] [Diretto a: {toLib}]",
														array(	'homeLib' => $item->isExternal()
																				? $item->getOwnerLibraryLabel()
																				: $item->getHomeLibraryLabel(),
															
																'toLib' => $item->getDeliveryLibraryId() != $this->getUser()->getActualLibraryId()
																				?'<span class="label label-default" style="text-transform: uppercase;">' . $item->getDeliveryLibraryLabel() . "</span>"
																				:$item->getDeliveryLibraryLabel() ));

                $buffer .= '</td><td>';

                $buffer .= '<span class="label label-primary" style="text-transform: uppercase;">' . $loan->getLoanStatusString() 
								. "</span><br>" . Prado::localize("Barcode") . ": {$item->getBarcode()}<br/>";
								
                $waitingDays = floor((time() - $item->getLastSeen('U'))/86400 );
				
                $buffer .= Prado::localize("In transito da {days} giorni",
												array("days" => $waitingDays));
				
				$buffer .= "</td></tr>";
			}
			
			$buffer .= '</tbody></table>';
            $bufferTemplate = str_replace("%%INTRANSIT%%", $buffer, $bufferTemplate);

			/**
			 * prenotazioni
			 */
			$itemRequests = ItemRequestQuery::create()
								->filterByPatron($patron)
								->filterByRequestStatus(ItemRequestPeer::getActiveStatus());
			
			$itemRequest_count = $itemRequests->count();

            $bufferTemplate = str_replace(	"%%RESERVATIONTAB%%",
											Prado::localize('Prenotazioni ({count})', 
																array('count' => $itemRequest_count)),
											
											$bufferTemplate);

			$buffer = '<table width="100%"><tbody>';
			
			/* @var $itemRequest ItemRequest */
			foreach ($itemRequests->find() as $itemRequest)
			{
				$title = $itemRequest->getTrimmedTitle(100, false);
				$buffer .= '<tr><td width="70%" valign="top">';

				if ($itemRequest->isRequestedByItem())
				{
					$requestedItem = $itemRequest->getItem();
                    $buffer .= '<em><strong>' . trim($title) . '</strong></em>&nbsp;';

					if ($requestedItem instanceof Item)
					{
						$buffer .= Prado::localize('[barcode: {code}]', 
													array('code'=>$requestedItem->getBarcode())) 
										. '<br />';

						$ownerLibrary = $requestedItem->getOwnerLibrary();
						
						if ($ownerLibrary instanceof Library)
						{
							$buffer .= Prado::localize("[comprato da {ownerLib}",
															array('ownerLib' => $ownerLibrary->getLabel(true, false, true, 30)));
							
							if ($requestedItem->getOwnerLibraryId() != $requestedItem->getHomeLibraryId())
							{
								$homeLibrary = $requestedItem->getHomeLibrary();
							
								if ($homeLibrary instanceof Library)
								{
									$buffer .= ", " . Prado::localize("gestito da {homeLib}",
																			array('homeLib' => $homeLibrary->getLabel(true, false, true, 30)));
								}
							}
							
							$buffer .= "]<br/>";
						}

						$buffer .= '(<a href="'.$this->getService()->constructUrl(	'Catalog.ItemViewPage',
																					array('id' => $requestedItem->getItemId()))
										
										. '">' . Prado::localize('vedi') . '</a>)&nbsp;';
					}
				}
				else
				{
                    $buffer .= '<em><strong>' . trim($title) . '</strong></em>&nbsp;';
					$buffer .= Prado::localize('(notizia n. {manid})',
													array('manid' => $itemRequest->getManifestationId()))
							
									.'<br/>';

					$buffer .= '(<a href="'.$this->getService()->constructUrl(	'Catalog.Record',
																				array('manifestationId' => $itemRequest->getManifestationId()))
							
									. '">' . Prado::localize('vedi') . '</a>)';
				}
				
				$buffer .= '</td><td>';
                
				if (floor(($itemRequest->getExpireDate("U") - time())/86400 ) <= 30 )
				{
					$buffer .= '<span class="label label-danger" style="text-transform: uppercase;">'
									. Prado::localize("In scadenza") . '</span> <span class="badge">'
									. $itemRequest->getQueuePosition().'</span><br/>';
				}
                else
                {
					$buffer .= '<span class="label label-primary" style="text-transform: uppercase;">' 
									. $itemRequest->getRequestStatusString() . '</span> <span class="badge">'
									. $itemRequest->getQueuePosition().'</span><br/>';
				}

				$buffer .= Prado::localize('Richiesto il {requestdate}',
												array('requestdate' => Clavis::dateFormat($itemRequest->getRequestDate('U')))) 
						
							. '<br/>';

                $buffer .= Prado::localize('Scade il {requestdate}',
												array('requestdate' => Clavis::dateFormat($itemRequest->getExpireDate('U')))) 
						
							. '<br/>';


                $buffer .= '(<a target="_self" href="javascript:void(0)" onclick="openIframe(\'Circulation.ViewReservationPopup\',null,null,\''
								. $formId . '\',null,null,null,null,\'' . $itemRequest->getRequestId() . '\',\'Item\'); return false;">' . Prado::localize('vedi') . '</a>)';
				
				$buffer .= '(<a target="_self" href="javascript:void(0)" onclick="openIframe(\'Circulation.DeleteReservationPopup\',null,null,\''
								. $formId . '\',null,null,null,null,\'' . $itemRequest->getRequestId() . '\',\'Item\'); return false;">' . Prado::localize('cancella') . '</a>)&nbsp;';
				
				$buffer .= "</td></td>";
			}
			
			$buffer .= '</tbody></table>';

            $bufferTemplate = str_replace("%%RESERVATION%%", $buffer, $bufferTemplate);

			$this->setBuffer($bufferHeader . $bufferTemplate ."</fieldset>");
			$this->setText($bufferHeader . $bufferTemplate ."</fieldset>");
		}
		else
		{
			$this->setPatronId(null);
			$this->setText('');
			$this->setBuffer('');
			return false;
		}
		
		return true;
	}		// end of populate()
	
}