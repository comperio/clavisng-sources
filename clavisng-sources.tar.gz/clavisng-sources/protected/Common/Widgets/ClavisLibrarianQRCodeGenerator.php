<?php

/**
 * ClavisLibrarianOTPGenerator class file.
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2018 Comperio srl
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 * For Commercial Licenses and support please contact Comperio.
 * @author    Mauro Seno <mauro.seno@comperio.it>
 * @link      http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2018 Comperio srl
 * @license   http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version   2.8.9
 * @package   Widgets
 */

/**
 * ClavisLibrarianOTPGenerator Class
 * @author  Mauro Seno <mauro.seno@comperio.it>
 * @version 2.8.9
 * @package Widgets
 * @since   2.8.9
 */
class ClavisLibrarianQRCodeGenerator extends TTemplateControl
{
	/* @var Librarian */
	private $_currentUser;

	/**
	 * @param $param
	 */
	public function onInit($param)
	{
		parent::onInit($param);
		$this->initVars();
	}

	/**
	 * @param $param
	 */
	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallback()) {

			$this->InsertLibrarianPassword->setText($this->getQRText());
			$this->QRCode->setTooltip($this->getQRTooltip());

			$this->QRTitle->setText($this->getTitle());
			$this->QRDescription->setText($this->getDescription());

			if (is_callable($this->getEnabled())) {
				$this->InsertLibrarianPassword->setVisible(call_user_func($this->getEnabled()));
			}

			// park the widget's close status into the view state.
			$this->setViewState('ToggleQRCodeStatus', false);
		}
	}


	public function setTitle($title)
	{
		$this->setViewState('QRTitle', $title, '');
	}

	public function getTitle()
	{
		return $this->getViewState('QRTitle', '');
	}

	public function setDescription($description)
	{
		$this->setViewState('QRDescription', $description, '');
	}

	public function getDescription()
	{
		return $this->getViewState('QRDescription', '');
	}

	/**
	 * @param $callback
	 */
	public function setEnabled($callback)
	{
		$this->setViewState('QREnabled', $callback, '');
	}

	/**
	 * @return bool|mixed
	 */
	public function getEnabled()
	{
		return $this->getViewState('QREnabled');
	}

	/**
	 * @return mixed
	 */
	public function getQRText()
	{
		return $this->getViewState('QRText', '');
	}

	/**
	 * @param $text
	 */
	public function setQRText($text)
	{
		$this->setViewState('QRText', $text, '');
	}

	/**
	 * @return mixed
	 */
	public function getQRTooltip()
	{
		return $this->getViewState('QRTooltip');
	}

	/**
	 * @param $text
	 */
	public function setQRTooltip($text)
	{
		$this->setViewState('QRTooltip', $text, '');
	}

	/**
	 * @param $sender
	 * @param $param
	 */
	public function toggleInsertLibrarianPassword($sender, $param): void
	{
		$opened = $this->getViewState('ToggleQRCodeStatus', false);

		if ($opened) {
			$this->QRCode->ImageUrl = '';
			$this->LibrarianPassword->Text = '';
			$this->GetLibrarianOTP->setCssClass('panel_off');
		} else {
			$this->GetLibrarianOTP->setCssClass('panel_on');
		}

		$this->QRCode->setCssClass('panel_off');
		$this->setViewState('ToggleQRCodeStatus', !$opened);
	}

	/**
	 * @param $param
	 * @throws \TInvalidDataValueException
	 * @throws \TInvalidOperationException
	 */
	public function onShowQRCode($param)
	{
		$this->raiseEvent('OnShowQRCode', $this, $param);
	}

	/**
	 *
	 */
	public function passwordChanged()
	{
		$this->VerifyStatus->Text = '';
	}

	/**
	 * @param $url
	 */
	public function setQRCodeUrl($url)
	{
		$this->QRCode->ImageUrl = $url;
	}

	/**
	 * @param $text
	 */
	public function setQRCodeErrorText($text)
	{
		$this->VerifyStatus->setText($text);
	}

	/**
	 * @param $value
	 */
	public function toggleShowQRCode($value)
	{
		if ($value) {
			$this->GetLibrarianOTP->setCssClass('panel_off');
			$this->QRCode->setCssClass('panel_on');
		} else {
			$this->GetLibrarianOTP->setCssClass('panel_on');
			$this->QRCode->setCssClass('panel_off');
		}
	}

	private function initVars()
	{
		$loggedInUserId = Prado::getApplication()->getUser()->getID();
		$this->_currentUser = LibrarianPeer::retrieveByPK($loggedInUserId);
	}
}