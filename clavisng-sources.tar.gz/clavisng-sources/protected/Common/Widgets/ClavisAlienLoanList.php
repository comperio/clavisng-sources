<?php

/**
 * ClavisAlienLoanList
 *
 * This component visualizes a datagrid with items that are involved
 * into loans from or to other consortia.
 * It will be a smaller version of ClavisLoanList.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @version 2.7
 * @package Widgets
 * @since 2.3
 */

class ClavisAlienLoanList extends TTemplateControl
{
	const INVALIDEMAIL = '**NOeMail**';

	private $_datasource;
	private $_datasourceSessionName;
	protected $_loanmanager;
	private $_fromLibraryId;
	private $_toLibraryId;
	private $_outDateFrom;
	private $_outDateTo;
	private $_object;
	private $_activeFilter;
	
	/**
	 * For check's logic
	 *
	 */
	public  $_masterChecked;
	private $_checked = array('all' => false);
	private $_checkedSessionName;
	private $_globalCriteriaSessionName;
	private $_globalCriteria;
	public  $_onlySelectedSessionName;
	
	private $_nodeLibrary;

	private function initVars()
	{
		$this->_loanmanager = $this->getApplication()->getModule("loan");
		$this->_datasource = $this->getApplication()->getSession()->itemAt('loanFoundDatasource');
		$this->_nodeLibrary = intval($this->_loanmanager->getExtraSystemNodeLibraryId());
		
		$uniqueId = $this->getUniqueID();
		$this->_checkedSessionName = "CheckedSessionName" . $uniqueId;
		$this->_globalCriteriaSessionName = "GlobalCriteriaSessionName" . $uniqueId;
		$this->_onlySelectedSessionName = "OnlySelectedSessionName" . $uniqueId;
		$this->_checked = $this->getChecked();
		$this->_masterChecked = $this->_checked['all'];
		$this->_datasourceSessionName = "DatasourceSessionName" . $uniqueId;
	}

	public function onInit($param)
	{
		parent::onInit($param);
		$this->initVars();
	}

	/**
	 * A population is performed here, in the case we load the
	 * page the first time.
	 *
	 * @param TEventParam $param
	 */
	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallback())
			$this->initialReload();
	}

	public function initialReload()
	{
		$this->resetDataSource();

		if ($this->getPopulable() && $this->getAutomaticPopulate())
			$this->populate();
	}

	public function resetChecked($state = false)
	{
		$this->setChecked(array('all' => $state));
	}

	public function setChecked($checked = null)
	{
		$this->_checked = $checked;
		$this->getApplication()->getSession()->add($this->_checkedSessionName, $checked);
	}

	public function getChecked()
	{
		$this->_checked = $this->getApplication()->getSession()->itemAt($this->_checkedSessionName);
		return $this->_checked;
	}

	private function resetGlobalCriteria()
	{
		$this->setGlobalCriteria(null);
	}

	private function setGlobalCriteria($criteria = null)
	{
		$this->getApplication()->getSession()->add($this->_globalCriteriaSessionName, $criteria, null);
	}

	public function getGlobalCriteria()
	{
		$this->_globalCriteria = $this->getApplication()->getSession()->itemAt($this->_globalCriteriaSessionName, null);

		if ($this->_globalCriteria instanceof Criteria)
			$this->_globalCriteria = SerializableCriteria::refreshCriteria($this->_globalCriteria);
		
		return $this->_globalCriteria;
	}

	public function resetOnlySelected($value = false)
	{
		$this->setOnlySelected($value);
		$this->OnlySelectedCheck->setChecked(false);
		$this->TeleportCheck->setChecked(false);
	}

	public function setOnlySelected($flag = false)
	{
		if ($flag === 'false')
			$flag = false;
		
		if ($flag === 'true')
			$flag = true;

		$this->getApplication()->getSession()->add($this->_onlySelectedSessionName, $flag, false);
	}

	public function getOnlySelected()
	{
		$flag = $this->getApplication()->getSession()->itemAt($this->_onlySelectedSessionName);
		
		return $flag;
	}

	public function getCheckedItems2ItemIds($force = false, $reset = false)
	{
		$itemIds = array();
		$loanIds = $this->getCheckedItems($force, $reset);

		foreach($loanIds as $loanId)
		{
			$loan = LoanQuery::create()->findPK($loanId);

			if (!is_null($loan))
			{
				$item = $loan->getItem();
				if (!is_null($item))
					$itemIds[] = $item->getItemId();
			}
		}

		return $itemIds;
	}

	public function getCheckedItems($force = false, $reset = false)
	{
		$checked = $this->getChecked();
		$masterChecked = $checked['all'];
		unset($checked['all']);
		$checkedIds = array_keys($checked);
		$output = array();

		if (!$masterChecked)
			$output = $checkedIds;
		else         // caso del mastercheck inverso
		{
			$criteria = $this->getGlobalCriteria();
			$loanIds = array();

			if (!is_null($criteria) && ($criteria instanceof Criteria))
			{
				if (count($checked) > 0)
					$criteria->add(LoanPeer::LOAN_ID, $checkedIds, Criteria::NOT_IN);

				$criteria->clearSelectColumns();
				$criteria->addSelectColumn(LoanPeer::LOAN_ID);
				$pdo = LoanPeer::doSelectStmt($criteria);
				while ($loanId = $pdo->fetchColumn())
					$loanIds[] = $loanId;
			}
			
			$output = $loanIds;
		}

		if ((count($output) == 0) && ($force == true))
		{
			$this->setMasterChecked(true);
			$output = $this->getCheckedItems();

			if ($reset)
				$this->setMasterChecked(false);
		}

		return $output;   // array di loan ids ...
	}

	public function countCheckedItems($force = false, $reset = false)
	{
		$checked = $this->getChecked();
		$masterChecked = $checked['all'];
		unset($checked['all']);
		$checkedIds = array_keys($checked);
		$output = 0;

		if (!$masterChecked)
			$output = count($checkedIds);
		else         // caso del mastercheck inverso
		{
			$criteria = $this->getGlobalCriteria();
			if (!is_null($criteria) && ($criteria instanceof Criteria))
			{
				if (count($checkedIds) > 0)
				$criteria->add(LoanPeer::LOAN_ID, $checkedIds, Criteria::NOT_IN);
				$output = LoanPeer::doCount($criteria);
			}
		}

		if (($output == 0) && ($force == true))
		{
			$this->setMasterChecked(true);
			$output = $this->countCheckedItems();

			if ($reset)
				$this->setMasterChecked(false);
		}

		return $output;
	}

	public function getMasterChecked()
	{
		$checked = $this->getChecked();
		
		return $checked['all'];
	}

	public function onOnlySelected($sender, $param)
	{
		$checked = $sender->getChecked();
		$this->setOnlySelected($checked);

		$this->LoanGrid->resetPagination();
		$this->populate();
	}

	public function onFlipChecked($sender, $param)
	{
		$newChecked = $sender->getChecked();
		$index = $sender->Parent->Parent->ItemIndex;
		$dataSource = $this->getDatasource();
		$checked = $this->getChecked();

		$row = $dataSource[$index];
		$loanId = $row['id'];

		if ($newChecked != $checked['all'])
		{
			$checked[$loanId] = true;
		}
		else
		{
			unset($checked[$loanId]);
		}

		$this->setChecked($checked);
		$this->updateEmptyFlag($param);
	}

	public function onMasterChecked($sender, $param)
	{
		$this->setMasterChecked($sender->getChecked(), $param);
	}

	public function setMasterChecked($newChecked = false, $param = null)
	{
		$this->resetChecked($newChecked);
		$gridItems = $this->LoanGrid->getItems();
		$header = $this->LoanGrid->getHeader();

		foreach ($gridItems as $item)
			$item->CheckColumn->CheckedBox->setChecked($newChecked);

		$header->CheckColumn->MasterCheck->setChecked($newChecked);
		$this->updateEmptyFlag($param);
	}

	public function updateEmptyFlag($param = null)
	{
		$count = intval($this->countCheckedItems());
		$this->SelectedNumber->setText($count);

		if (!is_null($param))
		{
			$this->SelectedPanel->render($param->getNewWriter());
		}
		else
		{
			$this->SelectedPanel->setCssClass(intval($this->SelectedNumber->getText()) > 0 ? 'panel_on' : 'panel_off');
		}
	}

	public function resetSelectedPanel()
	{
		$this->SelectedPanel->setCssClass('panel_off');
		$this->SelectedNumber->setText(0);
	}

	public function setPopulable($value = true)
	{
		$this->setViewState('Populable', $value, true);
	}

	public function getPopulable()
	{
		$populable = $this->getViewState('Populable', true);
		return $populable;
	}

	public function setObject($obj)
	{
		$this->_object = $obj;
		$this->setViewState("object", $obj, null);
	}

	public function getObject()
	{
		if (is_null($this->_object))
		{
			$this->_object = $this->getViewState("object", null);
		}
		
		return $this->_object;
	}

	public function setToLibraryId($lib)
	{
		$this->_toLibraryId = $lib;
		$this->setViewState('toLibraryId', $this->_toLibraryId, null);
	}

	public function getToLibraryId()
	{
		if (($lib = $this->_toLibraryId) == null)
		{
			$lib = $this->getViewState('toLibraryId', null);
			$this->_toLibraryId = $lib;
		}
		return $lib;
	}

	public function setFromLibraryId($lib)
	{
		$this->_fromLibraryId = $lib;
		$this->setViewState('fromLibraryId', $this->_fromLibraryId, null);
	}

	public function getFromLibraryId()
	{
		if (($lib = $this->_fromLibraryId) == null)
		{
			$lib = $this->getViewState('fromLibraryId', null);
			$this->_fromLibraryId = $lib;
		}
		
		return $lib;
	}

	public function setOutDateFrom($date)
	{
		$this->_outDateFrom = $date;
		$this->setViewState('outDateFrom', $this->_outDateFrom, null);
	}

	public function getOutDateFrom()
	{
		if (($date= $this->_outDateFrom) == null)
		{
			$date = $this->getViewState('outDateFrom', null);
			$this->_outDateFrom = $date;
		}
		return $date;
	}

	public function setOutDateTo($date)
	{
		$this->_outDateTo = $date;
		$this->setViewState('outDateTo', $this->_outDateTo, null);
	}

	public function getOutDateTo()
	{
		if (($date= $this->_outDateTo) == null)
		{
			$date = $this->getViewState('outDateTo', null);
			$this->_outDateTo = $date;
		}
		return $date;
	}

	public function setActiveFilter($activeFilter = null)
	{
		$this->_activeFilter = $activeFilter;
		$this->setViewState("activeFilter", $activeFilter, null);
	}

	public function getActiveFilter()
	{
		if(is_null($this->_activeFilter))
			$this->_activeFilter = $this->getViewState("activeFilter", null);
		return $this->_activeFilter;
	}

	public function setDirection($par = null)
	{
		$this->setViewState("direction", $par, null);
	}

	public function getDirection()
	{
		return $this->getViewState("direction", null);
	}

	public function setAutomaticPopulate($flag = true)
	{
		$this->setViewState("automaticPopulate", $flag, true);
	}

	public function getAutomaticPopulate()
	{
		return $this->getViewState("automaticPopulate", true);
	}

	/**
	 * It returns whether an item, represented by the id passed
	 * as the parameter, is present in the loans datasource.
	 *
	 * @param int $itemId
	 * @return boolean
	 */
	public function searchIdIntoDatasource($itemId)
	{
		$dataSource = $this->getDatasource();
		foreach($dataSource as $row)
		{
			if ($row['itemId'] == $itemId)
			return true;
		}

		return false;
	}

	/**
	 * It sets the four filters (used in the LoanViewPage) altogether.
	 *
	 */
	public function setFilters($fromLibraryId, $toLibraryId, $outDateFrom = null, $outDateTo = null)
	{
		if ($fromLibraryId == LibraryPeer::BLANKVALUE)
			$fromLibraryId = null;
		if ($toLibraryId == LibraryPeer::BLANKVALUE)
			$toLibraryId = null;

		if ($outDateFrom == '')
			$outDateFrom = null;
		if ($outDateTo == '')
			$outDateTo = null;

		$this->setFromLibraryId($fromLibraryId);
		$this->setToLibraryId($toLibraryId);
		$this->setOutDateFrom($outDateFrom);
		$this->setOutDateTo($outDateTo);

		$this->resetPagination();
	}

	public function resetDataSource()
	{
		$this->resetGlobalCriteria();
		$this->resetChecked();
		$this->resetOnlySelected();
		$this->_datasource = array();
		$this->getApplication()->getSession()->add($this->_datasourceSessionName, $this->_datasource);

		$this->resetSelectedPanel();
		$this->resetSorting();
		$this->populate();
	}

	public function resetSorting()
	{
		$this->LoanGrid->resetSorting('', null, false);
	}

	public function getDatasource()
	{
		$this->_datasource = $this->getApplication()->getSession()->itemAt($this->_datasourceSessionName, null);
		return $this->_datasource;
	}

	public function setDataSource($ds)
	{
		$this->_datasource = $ds;
		$this->getApplication()->getSession()->add($this->_datasourceSessionName, $this->_datasource, null);
	}

	public function getSortingExpression()
	{
		return $this->LoanGrid->getSortingExpression();
	}

	public function getSortingDirection()
	{
		return $this->LoanGrid->getSortingDirection();
	}

	public function calculateSortingCriteria(&$sortingCriteria = null)
	{
		$sortingExpression = $this->LoanGrid->getSortingExpression();
		$sortingDirection = $this->LoanGrid->getSortingDirection();

		if (!($sortingCriteria instanceof Criteria))
			$sortingCriteria = new Criteria();

		switch ($sortingExpression)
		{
			case 'title':  // ShelfName
				$sortingCriteria->clearOrderByColumns();
				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
					$sortingCriteria->addAscendingOrderByColumn(ItemPeer::TITLE);
				elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
					$sortingCriteria->addDescendingOrderByColumn(ItemPeer::TITLE);
			break;

			case 'libraryId': // biblioteca
				$loanStatuses = $this->getLoanStatusMode();

				if ($this->_loanmanager->IsOutStatus($loanStatuses))
				{
					$sortingCriteria->clearOrderByColumns();
					//$libraryId = $item->getDeliveryLibraryId();

					$sortingCriteria->addJoin(ItemPeer::DELIVERY_LIBRARY_ID, LibraryPeer::LIBRARY_ID);
					if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
						$sortingCriteria->addAscendingOrderByColumn(LibraryPeer::LABEL);
					elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
						$sortingCriteria->addDescendingOrderByColumn(LibraryPeer::LABEL);
				}

				elseif (in_array(ItemPeer::LOANSTATUS_TOSHELF, $loanStatuses))
				{
					$sortingCriteria->clearOrderByColumns();

					$sortingCriteria->addJoin(LibraryPeer::LIBRARY_ID, ItemPeer::ACTUAL_LIBRARY_ID);
					$sortingCriteria->setDistinct();
					if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
						$sortingCriteria->addAscendingOrderByColumn(LibraryPeer::LABEL);
					elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
						$sortingCriteria->addDescendingOrderByColumn(LibraryPeer::LABEL);
				}

				elseif ($this->_loanmanager->IsInStatus($loanStatuses))
				{
					$sortingCriteria->clearOrderByColumns();

					$sortingCriteria->addJoin(LoanPeer::LOAN_ID, ItemPeer::CURRENT_LOAN_ID);
					$sortingCriteria->addJoin(LoanPeer::FROM_LIBRARY, LibraryPeer::LIBRARY_ID);
					$sortingCriteria->setDistinct();
					if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
						$sortingCriteria->addAscendingOrderByColumn(LibraryPeer::LABEL);
					elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
						$sortingCriteria->addDescendingOrderByColumn(LibraryPeer::LABEL);
				}

			break;

			case 'loanDateBegin':
				$sortingCriteria->clearOrderByColumns();
				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
					$sortingCriteria->addAscendingOrderByColumn(LoanPeer::LOAN_DATE_BEGIN);
				elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
					$sortingCriteria->addDescendingOrderByColumn(LoanPeer::LOAN_DATE_BEGIN);
			break;

			case 'loanDateEnd':
				$sortingCriteria->clearOrderByColumns();
				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
					$sortingCriteria->addAscendingOrderByColumn(LoanPeer::LOAN_DATE_END);
				elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
					$sortingCriteria->addDescendingOrderByColumn(LoanPeer::LOAN_DATE_END);
			break;

			case 'dueDate':
				$sortingCriteria->clearOrderByColumns();
				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
					$sortingCriteria->addAscendingOrderByColumn(LoanPeer::DUE_DATE);
				elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
					$sortingCriteria->addDescendingOrderByColumn(LoanPeer::DUE_DATE);
			break;

			case null:
			break;

			default:
				$sortingExpression = null;
			break;
		}
	}

	/**
	 * It populates the grid, and takes the four necessary filter
	 * parameters from given saved data, and eventual other filters
	 * (i.e. patron, which was passed through the "setObject()").
	 *
	 */
	public function populate($givenIds = null)
	{
		/* @var $loan Loan */

		$actualLibraryId = $this->getUser()->getActualLibraryId();
		$pageSize = $this->LoanGrid->getPageSize();
		$currentIndexPage = $this->LoanGrid->getCurrentPage();
		$direction = $this->getDirection();
		$askRenewFlag = false;
		$this->PatronColumn->setVisible($direction == 'in');

		if ($this->getOnlySelected())
			$givenIds = $this->getCheckedItems();

		if (!is_null($givenIds) && (count($givenIds) > 0))
		{
			$recCount = count($givenIds);
			$givenIds = array_slice($givenIds, $pageSize * $currentIndexPage, $pageSize);

			$loans = LoanQuery::create()->findPKs($givenIds);
		}
		else
		{
			$fromLibraryId = $this->getFromLibraryId();
			$toLibraryId = $this->getToLibraryId();

			$outDateFrom = $this->getOutDateFrom();
			$outDateTo = $this->getOutDateTo();

			$criteria = new Criteria();
			$criteria->add(LoanPeer::LOAN_TYPE, ItemPeer::LOANTYPE_EXTRASYSTEM);   // only extra-system loans
			$criteria->addAnd(LoanPeer::FROM_LIBRARY, $actualLibraryId);

			if (!is_null($fromLibraryId))
			{
				if ($fromLibraryId == LibraryPeer::EXCLUDEMYLIBRARY)
					$criteria->addAnd(LoanPeer::FROM_LIBRARY, $actualLibraryId, Criteria::NOT_EQUAL);
				else
					$criteria->addAnd(LoanPeer::FROM_LIBRARY, $fromLibraryId);
			}

			if ($direction == 'out')
			{
				if (!is_null($toLibraryId))
					$criteria->addAnd(LoanPeer::EXTERNAL_LIBRARY_ID, $toLibraryId);
				else
					$criteria->addAnd(LoanPeer::EXTERNAL_LIBRARY_ID, null, Criteria::ISNOTNULL);
			}
			elseif ($direction == 'in')
				$criteria->addAnd(LoanPeer::EXTERNAL_LIBRARY_ID, null, Criteria::ISNULL);

			$object = $this->getObject();
			if (!is_null($object))
			{
				switch (get_class($object))
				{
					case 'Patron':
						$this->PatronColumn->setVisible(false);
						$criteria->addAnd(LoanPeer::PATRON_ID, $object->getId());
						break;

					case 'Item':
						$this->ItemColumn->setVisible(false);
						$criteria->addAnd(LoanPeer::ITEM_ID, $object->getId());
						break;
				}
			}

			$activeFilter = $this->getActiveFilter();
			if (!is_null($activeFilter))
			{
				switch ($activeFilter)
				{
					case 'Active':
						$criteria->addAnd(LoanPeer::LOAN_STATUS, ItemPeer::getLoanStatusCurrent(), Criteria::IN);
						break;
					case 'Inactive':
						$criteria->addAnd(LoanPeer::LOAN_STATUS, ItemPeer::getLoanStatusInactive(), Criteria::IN);
						$this->DueDateColumn->setVisible(false);
						break;
				}
			}

			if (!is_null($outDateFrom) && ($outDateFrom > 0))
				$criteria->addAnd(LoanPeer::LOAN_DATE_BEGIN, $outDateFrom, Criteria::GREATER_EQUAL);

			if (!is_null($outDateTo) && ($outDateTo > 0))
				$criteria->addAnd(LoanPeer::LOAN_DATE_BEGIN, $outDateTo + 86399, Criteria::LESS_EQUAL);

			$recCount = LoanPeer::doCount($criteria);
			$this->LoanGrid->resetSorting('loanDateBegin', TClavisDataGrid::SORTDIRECTION_DESC, false);

			$this->calculateSortingCriteria($criteria);
			$this->setGlobalCriteria(clone $criteria);

			if ($pageSize > 0)
			{
				$criteria->setLimit($pageSize);
				$criteria->setOffset($currentIndexPage * $pageSize);
			}

			$loans = LoanPeer::doSelect($criteria);
		}

		$clavisLibrarian = Prado::getApplication()->getUser();

		$datasource = array();
		foreach ($loans as $loan)
		{
			$loanId = $loan->getId();

			$fromLibraryId = intval($loan->getFromLibrary());
			$toLibraryId = intval($loan->getToLibrary());

			if (in_array($loan->getLoanStatus(), ItemPeer::getLoanStatusClosed()))
			{
				$item = null;
				$itemId = null;
			}
			else
			{
				$item = $loan->getItem();
				$itemId = intval($loan->getItemId());
			}

			$ownerLibrary = (object) null;
			if ($item instanceof Item)
				$ownerLibrary = $item->getOwnerLibrary();
			else
				$ownerLibrary = $loan->getItemOwnerLibrary();

			if ($ownerLibrary instanceof Library)
			{
				$ownerLibraryString = $ownerLibrary->getLabel(true, false); //, true);
				$ownerLibraryId = $ownerLibrary->getLibraryId();
			}
			else
			{
				$ownerLibraryString = '';
				$ownerLibraryId = 0;
			}

			$fromLibraryString = $toLibraryString = $patronCompleteName = $navigateUrl = '' ;

			if ($fromLibraryId > 0)
			{
				$fromLibrary = LibraryQuery::create()->findPK($fromLibraryId);
				if ($fromLibrary instanceof Library)
					$fromLibraryString = $fromLibrary->getLabel(true);
			}

			if ($toLibraryId > 0)
			{
				$toLibrary = LibraryQuery::create()->findPK($toLibraryId);
				if ($toLibrary instanceof Library)
					$toLibraryString = $toLibrary->getLabel(true);
			}

			if ($direction == 'out')
			{
				$toLibraryId = $loan->getExternalLibraryId();
				$toLibraryString = $loan->getExternalLibraryString();

				if ($this->_nodeLibrary instanceof Library && $fromLibraryId != $this->_nodeLibrary->getLibraryId())
					$toLibraryString .= " " . Prado::localize("via") . " " . $this->_nodeLibrary->getLabel();
			}
			elseif ($direction == 'in')
			{
				$askRenewFlag = true;

				$toLibraryId = $loan->getToLibrary();
				$toLibraryString = $loan->getToLibraryLabel();

				$patron = $loan->getPatron();
				if ($patron instanceof Patron)
				{
					$patronCompleteName = $patron->getCompleteName();
					$navigateUrl = "index.php?page=" . $patron->getShelfUrl() . $patron->getPatronId();
				}
			}

			$patronId = $loan->getPatronId();

			if ($this->getActiveFilter() == 'Inactive')
			{
				$dueDate = '';
				$exceedDate = false;
			}
			else
			{
				$dueDate = Clavis::dateFormat($loan->getDueDate('U'));
				$exceedDate = ($this->_loanmanager->isLoanLate($loan) == ClavisLoanManager::LOAN_ISLATE);
			}

			$isSolicitable = ($this->_loanmanager->IsLoanSolicitable($loan, $clavisLibrarian) == ClavisLoanManager::OK);

			//$loanStatus = $loan->getLoanStatus();

			if (isset($this->_checked[$loanId]))
				$checked = $this->_checked[$loanId];
			else
				$checked = false;

			if ($this->_checked['all'])
				$checked = !$checked;

			$title = $loan->getTitle(true);   // force from item
			if ($title == '')
				$title = '(' . Prado::localize('nessun titolo') . ')';

			if ($item instanceof Item)
				$itemInventoryNumber = Prado::localize("inv: {inv}",
																	array('inv' => $item->getCompleteInventoryNumber()) );
			else
				$itemInventoryNumber = '';

			$datasource[] = array(	'Checked' => $checked,
									'id' => $loanId,
									'title' => $title,
									'inv_number' => $itemInventoryNumber, //$loan->getInvNumber(),

									'fromLibraryId' => $fromLibraryId,
									'fromLibraryString' => $fromLibraryString,
									'toLibraryId' => $toLibraryId,
									'toLibraryString' => $toLibraryString,
									'ownerLibraryId' => $ownerLibraryId,
									'ownerLibraryString' => $ownerLibraryString,

									'patronId' => $patronId,
									'patronCompleteName' => PatronPeer::getCompleteName($patronId),
									'loanDateBegin' => Clavis::dateFormat($loan->getLoanDateBegin('U')),
									'loanDateEnd' => Clavis::dateFormat($loan->getLoanDateEnd('U')),

									'dueDate' => $dueDate,
									'exceedDate' => ($exceedDate && $this->_loanmanager->IsLoanStatusActive($loan) && ($dueDate != '')),
									'isSolicitable' => $isSolicitable,
									'itemId' => $itemId,
									'askRenewFlag' => $askRenewFlag && ($item->getActualLibraryId() == $actualLibraryId),
									'isLoanRenewable' => (($this->_loanmanager->IsLoanRenewable($item,
																													$clavisLibrarian,
																													$loan->getPatron())) == ClavisLoanManager::OK
																																		? true
																																		: false),
									'isItemLoaned' => $this->_loanmanager->IsItemLoaned($item),
									'isItemAvailable' => ($this->_loanmanager->IsItemAvailable($item) == ClavisLoanManager::OK),
									'isReadyToLoan' => ($loan->getLoanStatus() == ItemPeer::LOANSTATUS_READYFORLOAN),
									'patronCompleteName' => $patronCompleteName,
									'patronNavigateUrl' => $navigateUrl,
									'renewCount' => $loan->getRenewCountLabel(),
									'solicitCount' => intval($loan->getNotifyCount()) );
		}

		$this->_datasource = $datasource;
		$this->setDataSource($this->_datasource);

		if ($pageSize > 0)
			$this->LoanGrid->setVirtualItemCount($recCount);

		$this->LoanGrid->setDataSource($this->_datasource);
		$this->LoanGrid->dataBind();

		if (!$this->getOnlySelected())
			$this->FoundNumber->setText($recCount);
	}

	public function onChangePage($sender, $param)
	{
		$this->LoanGrid->setCurrentPage($param->NewPageIndex);
		$this->populate();
	}

	public function globalRefresh()
	{
		$this->resetSorting();
		$this->populate();
	}

	public function globalRefreshPageIn($param)
	{
		$this->getPage()->globalRefreshIn($param);
	}

	public function globalRefreshPageOut($param)
	{
		$this->getPage()->globalRefreshOut($param);
	}

	/**
	 * Are we inside a popup?
	 *
	 * @return boolean
	 */
	public function getPopupFlag()
	{
		return $this->getPage()->IsPopup();
	}

	/**
	 * Resets the datagrid's pagination (first page).
	 *
	 */
	public function resetPagination()
	{
		$this->LoanGrid->setCurrentPage(0);
	}

	public function onUnloan($sender, $param)
	{
		$this->getPage()->cleanMessageQueue();

		if ($this->doUnloan(intval($param->CommandParameter)));
		{
			if ($this->getDirection() == 'in')
			{
				$this->globalRefreshPageIn($param);
			}
			elseif ($this->getDirection() == 'out')
			{
				$this->globalRefreshPageOut($param);
			}
		}

		$this->getPage()->flushMessage();
	}

	public function doUnloan($itemId = null, $clavisLibrarian = null)
	{
		$itemId = intval($itemId);
		if ($itemId == 0)
		{
			$this->getPage()->enqueueMessage(Prado::localize("Errore sul passaggio di parametri per il prestito extra-sistema"),
												ClavisMessage::ERROR);
			return false;
		}

		$item = ItemQuery::create()->findPK($itemId);
		if (!($item instanceof Item))
		{
			$this->getPage()->enqueueMessage(Prado::localize("Errore di congruenza del database: l'esemplare con id: {id} non esiste.",
																array('id' => $itemId)),
												ClavisMessage::ERROR);
			return false;
		}

		if (!$this->_loanmanager->IsItemLoaned($item))
		{
			$this->getPage()->enqueueMessage(Prado::localize("Errore di congruenza del database: l'esemplare con id: {id} non è più in prestito. Si tratta di un prestito erroneamente terminato (appeso). Segnalare al fornitore del software indicando l'esatto id dell'esemplare, per lo sblocco.",
																			array('id' => $itemId)),
															ClavisMessage::ERROR);
			return false;
		}

		if (!($clavisLibrarian instanceof ClavisLibrarian))
			$clavisLibrarian = $this->getUser();

		if ($this->getDirection() == 'out')
			$returnValue = $this->_loanmanager->doReturnItemExtra($item->getItemId(), $clavisLibrarian);
		elseif ($this->getDirection() == 'in')
			$returnValue = $this->_loanmanager->DoReturnItem($item, null, $clavisLibrarian);
		else
			return false;

		$messageText = '';
		$messageType = ClavisMessage::ERROR;
		$updatePageFlag = false;

		if (($returnValue == ClavisLoanManager::OK) || ($returnValue == ClavisLoanManager::RETN_PATRONREQUEST))
		{
			$updatePageFlag = true;
			$messageText = Prado::localize("Rientro eseguito correttamente dell'esemplare '{title}' [barcode: {barcode}, id: {id}]",
								array('title' => $item->getTrimmedTitle(40),
										'barcode' => $item->getBarcode(),
										'id' => $item->getItemId()));
			$messageType = ClavisMessage::CONFIRM;

			if ($returnValue == ClavisLoanManager::RETN_PATRONREQUEST)
			{
				$messageText .= ',<br />' . Prado::localize('ed esistono prenotazioni.');
				$messageType = ClavisMessage::WARNING;
			}

			if ($item->getLoanStatus() == ItemPeer::LOANSTATUS_READYFORTRANSITTOHOME)
				$messageText .= '<br />' . Prado::localize('L\'esemplare è stato messo in \'pronto al transito di rientro\'.');

			if ($item->getLoanStatus() == ItemPeer::LOANSTATUS_INTRANSITTOEXTRA)
				$messageText .= '<br />' . Prado::localize('L\'esemplare è stato messo in \'pronto al transito di rientro extrasistema\'.');
		}

		elseif ($returnValue == ClavisLoanManager::ERROR)
		{
			$messageText = Prado::localize('Rientro fallito');
			$messageType = ClavisMessage::ERROR;
		}
		else
		{
			$messageText = Prado::localize('Valore di ritorno sconosciuto');
			$messageType = ClavisMessage::ERROR;
		}

		$this->getPage()->enqueueMessage($messageText, $messageType);
		return $updatePageFlag;
	}

	public function onRenewItem($sender, $param)
	{
		$this->getPage()->cleanMessageQueue();

		$item = null;
		$itemId = intval($param->CommandParameter);
		if ($itemId > 0)
			$item = ItemQuery::create()->findPK($itemId);

		if ($item instanceof Item)
		{
			$clavisLibrarian = $this->getUser();
			$oldDueDate = Clavis::dateFormat($item->getDueDate('U'));

			$direction = $this->getDirection();
			if ($direction == 'in')
			{
				$patron = $item->getPatron();
				$renewDate = Clavis::dateFormat($this->_loanmanager->CalculateRenewDate($item, $patron));
				if ($this->_loanmanager->DoRenewLoan($item, $patron, $clavisLibrarian, Prado::localize('rinnovo extra in')))
				{
					$this->getPage()->enqueueMessage(Prado::localize("Proroga fino al {date} eseguita correttamente per il prestito sull'esemplare '{title}' [inv: {inv}]",
																		array(	'date' => $renewDate,
																				'title' => $item->getTrimmedTitle(60),
																				'inv' => $item->getCompleteInventoryNumber() )),
														ClavisMessage::INFO);

					if ($item->isExternal()
							&& intval(ClavisParamPeer::getParam('EXTRARENEW_CONFIRMEMAIL')) == 1)
					{
						$library = $item->getOwnerLibraryLabel();
						$loan = $item->getCurrentLoan();

						$notificationManager = $this->getApplication()->getModule('notification');
						$resultAddress = $notificationManager->sendEmailRenew(	'EXTRA_RENEW_CONFIRM',
																				$loan,
																				$oldDueDate,
																				$renewDate);
						
						if ($resultAddress == self::INVALIDEMAIL)
							$this->getPage()->enqueueMessage(Prado::localize("La biblioteca esterna [{library}] non ha un indirizzo email valido",
																				array('library' => $library ) ),
																ClavisMessage::WARNING);
						elseif ($resultAddress != '')
						{
							$this->getPage()->enqueueMessage(Prado::localize("É stata spedita una email informativa alla biblioteca '{library}', all'indirizzo '{email}'",
																					array(	'library' => $library,
																							'email' => $resultAddress )),
																ClavisMessage::INFO);
						}
						else
						{	
							$this->getPage()->enqueueMessage(Prado::localize("É fallita la richiesta di proroga per l'esemplare '{title}' [inv: {inv}]",
																				array(	'title' => $item->getTrimmedTitle(60),
																						'inv' => $item->getCompleteInventoryNumber() )),
																ClavisMessage::ERROR);
						}
					}

					$this->populate();
				}
				else
					$this->getPage()->enqueueMessage(Prado::localize("Proroga fallita sull'esemplare '{title}'",
																array('title' => $item->getTrimmedTitle(60))),
														ClavisMessage::ERROR);
			}
			elseif ($direction == 'out')
			{
				$externalLibrary = $item->getExternalLibrary();
				$renewDate = Clavis::dateFormat($this->_loanmanager->CalculateRenewDate($item, $externalLibrary));

				if ($this->_loanmanager->DoRenewLoan(	$item,
														$externalLibrary,
														$clavisLibrarian,
														Prado::localize('rinnovo extra out')))
				{
					$this->getPage()->enqueueMessage(Prado::localize("Proroga fino al {date} eseguita correttamente per il prestito sull'esemplare '{title}' [inv: {inv}]",
																array(	'date' => $renewDate,
																		'title' => $item->getTrimmedTitle(60),
																		'inv' => $item->getCompleteInventoryNumber() )),
														ClavisMessage::INFO);

					$this->populate();
				}
				else
				{
					$this->getPage()->enqueueMessage(Prado::localize("Proroga fallita sull'esemplare '{title}'",
																array('title' => $item->getTrimmedTitle(60))),
														ClavisMessage::ERROR);
				}
			}
			else
			{	
				$this->getPage()->enqueueMessage(Prado::localize("Errore dell'applicazione: nel rinnovo extra non è stato passato il parametro 'direction'.<br />Riportare al fornitore del software, grazie"),
													ClavisMessage::ERROR);
			}
		}
		else
		{
			$this->getPage()->enqueueMessage(Prado::localize("Errore dell'applicazione: nel rinnovo extra è stato passato il parametro 'itemId={itemId}' ma l'esemplare non sembra esistere.<br />Riportare al fornitore del software, grazie",
																array('itemId' => $itemId)),
												ClavisMessage::ERROR);
		}
		
		$this->getPage()->flushMessage();
	}

	public function onReadyToLoan2Loan($sender, $param)
	{
		$this->getPage()->cleanMessageQueue();
				
		$itemId = $param->CommandParameter;
		$item = null;
		if ($itemId > 0)
			$item = ItemQuery::create()->findPK($itemId);

		if (!is_null($item) && ($item instanceof Item))
		{
			$clavisLibrarian = $this->getUser();
			$result = $this->_loanmanager->DoReadyToLoan2LoanItem($item, $clavisLibrarian);
			$barcode = $item->getBarcode();
			$itemDataString = $item->getTrimmedTitle(40) 
								. ($barcode == '' 
										? '' 
										: ' (' . Prado::localize('barcode') . ': ' . $barcode) . ')';

			if ($result == ClavisLoanManager::OK)
			{
				$this->getPage()->enqueueMessage(Prado::localize("Prestito effettuato sull'esemplare '{title}' che era in stato di pronto al prestito",
																	array('title' => $itemDataString)),
													ClavisMessage::INFO);
				$this->populate();
			}
			elseif ($result == ClavisLoanManager::LOAN_PATRONNOTENABLED)
			{
				$patron = $item->getPatron();
				$patronData = ($patron instanceof Patron
								? $patron->getReverseCompleteName()
								: "(" . Prado::localize('utente inesistente') . ")" );

				$this->getPage()->enqueueMessage(Prado::localize("Prestito fallito sull'esemplare '{title}' che è in stato di pronto al prestito "
																	. "perchè l'utente '{patron}' non è abilitato al prestito", 
																	array(	'title' => $itemDataString,
																			'patron' => $patronData)), 
													ClavisMessage::ERROR);
			}			
			else	// fallback
			{	
				$this->getPage()->enqueueMessage(Prado::localize("Prestito fallito sull'esemplare '{title}' che è in stato di pronto al prestito",
																	array('title' => $itemDataString)),
													ClavisMessage::ERROR);
			}
			
			$this->getPage()->flushMessage();
		}
	}

	public function onAddToShelf($sender, $param)
	{
		$shelfId = $this->ShelfResultValue->getValue();
		
		if (is_numeric($shelfId)
				&& !is_null($shelfId))
		{
			$shelf = ShelfQuery::create()->findPK($shelfId);
			
			if (!is_null($shelf) && ($shelf instanceof Shelf))
			{
				$checkedLoanIds = $this->getCheckedItems();
				$countDone = $shelf->addItemToShelf('loan', $checkedLoanIds);
				$countFailed = count($checkedLoanIds) - $countDone;
				
				if ($countDone > 0)
				{
					$this->getPage()->writeMessage($countDone == 1 ?
														Prado::localize('1 elemento processato') :
														Prado::localize('{count} elementi processati',
													array('count' => $countDone)),
												ClavisMessage::INFO);
				}

				if ($countFailed > 0)
					$this->getPage()->writeMessage($countFailed == 1 ?
														Prado::localize('1 elemento non processato') :
														Prado::localize('{count} elementi non processati',
													array('count' => $countFailed)),
												ClavisMessage::ERROR);
			}
		}

		if ($this->TeleportCheck->getChecked())
			$this->getPage()->gotoPageWithReturn('Communication.ShelfViewPage', array('id' => $shelfId));
	}

	public function searchCodesIntoDatasource($code = '')
	{
		$code = trim($code);
		if ($code == '')
			return array();

		$items = ItemPeer::retrieveByDataInput($code);
		$result = array();

		foreach($items as $item)
			$result[] = $item->getItemId();
		return $result;   // array of itemIds ......
	}

	public function onAskRenewItem($sender, $param)
	{
		$loanId = $param->CommandParameter;
		$loan = null;
		if ($loanId > 0)
			$loan = LoanQuery::create()->findPK($loanId);

		if ($loan instanceof Loan)
		{
			$item = $loan->getItem();
			if (!($item instanceof Item))
			{
				$message = array(Prado::localize("Incongruenza sul database durante la richiesta di proroga, relativamente al prestito con loan_id = {loanId}.<br />Riportare al fornitore del software, grazie",
														array('loanId' => $loan->getLoanId() )),
									ClavisMessage::ERROR);

				return false;
			}

			$patron = $loan->getPatron();
			$library = $item->getOwnerLibraryLabel();

			$oldDueDate = Clavis::dateFormat($loan->getDueDate('U'));
			$newRenewDate = Clavis::dateFormat($this->_loanmanager->CalculateRenewDate($item, $patron));

			$notificationManager = $this->getApplication()->getModule('notification');
			$resultAddress = $notificationManager->sendEmailRenew('EXTRA_RENEW_ASK', $loan, $oldDueDate, $newRenewDate);
			if ($resultAddress == self::INVALIDEMAIL)
				$message = array(Prado::localize("La biblioteca richiedente [{library}] non ha un indirizzo email valido",
															array('library' => $library ) ),
										ClavisMessage::ERROR);
			elseif ($resultAddress != '')
			{
				$message = array(Prado::localize("É stata correttamente richiesta la proroga dell'esemplare '{title}' [inv: {inv}, coll: {coll}] alla biblioteca '{library}', all'indirizzo '{email}'",
															array('date' => $newRenewDate,
																	'title' => $item->getTrimmedTitle(60),
																	'inv' => $item->getCompleteInventoryNumber(),
																	'coll' => $item->getCollocationCombo(),
																	'library' => $library,
																	'email' => $resultAddress )),
										ClavisMessage::INFO);

				$this->populate();
			}
			else
				$message = array(Prado::localize("É fallita la richiesta di proroga per l'esemplare '{title}' [inv: {inv}]",
															array('title' => $item->getTrimmedTitle(60),
																	'inv' => $item->getCompleteInventoryNumber() )),
										ClavisMessage::ERROR);

			$this->getPage()->writeMessage($message[0], $message[1]);
		}
		else
			$this->getPage()->writeMessage(Prado::localize("Errore nel passaggio dei parametri.<br />Riportare al fornitore del software, grazie"),
												ClavisMessage::ERROR);
	}

	/// probably no more used by anyone. Moved to the NotificationManager (by mbrancalion)
	private function sendEmailRenew(	$templateName = '',
										$loan = null,
										$oldDueDate = null,
										$newRenewDate = null,
										$description = null)
	{
		/* @var $patron Patron */
		/* @var $externalLibrary Library */

		/* @var $myLibrary Library */
		/* @var $loan Loan */

		$templateName = trim($templateName);
		if ($templateName == '')
			return false;

		$success = false;

		$patronData = '---';
		$patron = $loan->getPatron();
		if ($patron instanceof Patron)
			$patronData = $patron->getCompleteName();

		$item = $loan->getItem();
		if(!($item instanceof Item))
			return '';

		$library = $item->getOwnerLibrary();
		if ($library instanceof Library)
		{
			$libraryEmailString = trim($library->getEmail());
			if ($libraryEmailString == '')
				return self::INVALIDEMAIL;

			$libraryEmail = array($libraryEmailString);
		}
		else
		{
			return self::INVALIDEMAIL;
		}

		$libraryString = $item->getOwnerLibraryLabel(false, true, false, false);   // strip tags, no addendum

		if (is_null($oldDueDate))
			$oldDueDate = Clavis::dateFormat($loan->getDueDate('U'));

		if (is_null($newRenewDate))
			$newRenewDate = Clavis::dateFormat($this->_loanmanager->CalculateRenewDate($item, $patron));

		$title = $item->getTrimmedTitle(60);
		$inventory = $item->getCompleteInventoryNumber();
		$collocation = $item->getCollocationCombo();

		$myLibrary = $this->getUser()->getActualLibrary();
		$myLibraryId = $this->getUser()->getActualLibraryId();
		$myConsortiumString = $myLibrary->getConsortiaString();

		$notificationManager = $this->getApplication()->getModule('notification');

		if ($description != '')
			$description = Prado::localize("con la seguente motivazione") . ":\n" . $description . "\n";

		$class = get_class($library);
		$receiverId = $library->getLibraryId();

		$template = DocumentTemplatePeer::getTemplate(	$templateName,
														$this->getApplication()->getGlobalization()->getCulture(),
														$myLibraryId);
		if (!$template instanceof DocumentTemplate)
			return false;

		$arr_alias = array(	'EXTERNALLIBRARY' => $libraryString,
							'TITLE'	=> $title,
							'INVENTORY' => $inventory,
							'COLLOCATION' => $collocation,
							'PATRON' => $patronData,
							'OLDRENEW' => $oldDueDate,
							'NEWRENEW' => $newRenewDate,
							'MOTIVATION' => $description,
							'LIBRARY' => $myLibrary->getLabel(),
							'LIBRARY_CODE' => $myLibrary->getLibraryCode(),
							'LIBRARY_DESCRIPTION' => $myLibrary->getDescription(),
							'LIBRARY_CITY' => $myLibrary->getCity(),
							'LIBRARY_ADDRESS' => $myLibrary->getAddress(),
							'LIBRARY_PHONE' => $myLibrary->getPhone(),
							'LIBRARY_FAX' => $myLibrary->getFax(),
							'LIBRARY_EMAIL' => $myLibrary->getEmail() );

		$mailData = array();
		$mailData['to'] = $libraryEmail;
		$mailData['bcc'] = array();
		$mailData['cc'] = array();
		$mailData['body'] = '';
		$mailData['subject'] = "[$myConsortiumString]: " . $template->getTemplateTitle();

		$mailData['from'] = array(	'name' => $myLibrary->getLabel(),
									'email' => $myLibrary->getEmail() );

		$notificationData = array(	'sender_library_id' => $myLibraryId,
									'receiver_class' => $class,
									'receiver_id' => $receiverId,
									'description' => Prado::localize("Richiesta proroga a biblioteca esterna"),
									'notes' => array() );

		try
		{
			$ret = $notificationManager->DoEmailReport(	$template->getTemplateBody(),
														$arr_alias,
														$mailData,
														NotificationManager::EMAIL_AUTO,
														$notificationData);

			if ($ret === true)
				$success = implode(',', $libraryEmail);
		}
		catch (Exception $e)
		{
			$e = $e;
			//throw ($e);
			$success = false;
		}

		return $success;
	}

	public function onSuspendRenew($sender, $param)
	{
		$this->getPage()->cleanMessageQueue();

		$clavisLibrarian = $this->getUser();
		$ok = false;

		$item = (object) null;
		$itemId = intval($param->CommandParameter);
		if ($itemId > 0)
			$item = ItemQuery::create()->findPK($itemId);
		if ($item instanceof Item)
		{
			$itemtit = $item->getCompleteTitle();
			if (!$itemtit)
				$itemtit = Prado::localize('(nessun titolo)');

			if ($this->_loanmanager->IsItemLoaned($item))
			{
				switch ($this->_loanmanager->doDisableRenew($itemId, $clavisLibrarian))
				{
					case ClavisLoanManager::OK:
						$this->getPage()->enqueueMessage(Prado::localize("L'esemplare con titolo '{title}' [barcode: {barcode}, inv: {inv}] è stato sospeso dalle proroghe.",
																			array(	'title' => $itemtit,
																					'inv' => $item->getCompleteInventoryNumber(),
																					'barcode' => $item->getBarcode())),
															ClavisMessage::INFO);
						$ok = true;
					break;

					case ClavisLoanManager::ERROR:
						$this->getPage()->enqueueMessage(Prado::localize("L'operazione di sospensione di proroga è fallita"),
															ClavisMessage::ERROR);
					break;

					default:
						$this->getPage()->enqueueMessage(Prado::localize("Errore sconosciuto durante la sospensione di proroga"),
															ClavisMessage::ERROR);
					break;
				}
			}
			else
			{
				$this->getPage()->enqueueMessage(Prado::localize("L'esemplare con id = {id} e barcode = '{barcode}' NON E' IN PRESTITO !",
																	array(	'id' => $item->getId(),
																			'barcode' => $item->getBarcode())),
													ClavisMessage::ERROR);
			}
		}
		else
			$this->getPage()->enqueueMessage(Prado::localize("Errore nel passaggio dei parametri.<br />Riportare al fornitore del software, grazie"),
												ClavisMessage::ERROR);

		if ($ok)
			$this->populate();

		$this->getPage()->flushMessage();
	}

}
