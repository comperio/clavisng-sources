<?php
/**
 * ClavisShelfList class file
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 */

/**
 * ClavisShelfList Class
 *
 * This component visualizes the shelves which are stored in the
 * databases into a datagrid.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2008 ePortal Technologies
 * @copyright Copyright &copy; 2012 Comperio srl
 * @version 2.7
 * @package Widgets
 * @since 2.0
 */
class ClavisShelfList extends TTemplateControl
{

	/**
	 * It populates our datagrid during the very first cycle
	 * of the parent page.
	 *
	 * @param TEventParameter $param
	 */
	public function onLoad($param)
	{
		parent::onLoad($param);

		// first page cycle
		if (!$this->getPage()->getIsPostBack() 
				&& !$this->getPage()->getIsCallback())
		{
			$libraries = LibraryPeer::getLibrariesHashWithBlank(null, true);

			$this->LibrarySearch->setDatasource($libraries);
			$this->LibrarySearch->databind();
			$myLibrary = $this->getUser()->getActualLibraryId();
			
			if (array_key_exists($myLibrary, $libraries))
				$this->LibrarySearch->setSelectedValue($myLibrary);

			$this->globalRefresh();
			$this->getPage()->setFocus($this->ShelfSearch->getClientID());
		} // end of first page cycle
	}

	/**
	 * It cleans the search textboxes and re-populates.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onClearSearch()
	{
		$this->searchCancel(null, null);
	}

	public function getBaseQuery()
	{
		$q = ShelfQuery::create();
		$sortingExpression = $this->ShelfGrid->getSortingExpression();
		$sortingDirection = $this->ShelfGrid->getSortingDirection();

		switch ($sortingExpression)
		{
			case 'ShelfName':
				$q->orderByShelfName($sortingDirection);
				break;

			case 'LibrarianName':
				$q->useLibrarianRelatedByLibrarianIdQuery()
						->orderByLastname($sortingDirection)
						->orderByName($sortingDirection)
						->endUse();
				break;
		}

		return $q;
	}

	/**
	 * It populates the datagrid.
	 *
	 * It gets the actual objectType and objectId we're using, and
	 * operates with the subclassed method we've implemented into Propel
	 * in order to perform a paginated calibrated search.
	 *
	 * Please note the parameter 'except', which is to be passed by the
	 * parent page, which gets the object to extract the shelves where
	 * it's present or rather where it's NOT present.
	 *
	 * Further in the method, we have a switch on the $shelfStatus variable,
	 * which permits or not the visualization of a particular shelf according
	 * to its saved status and to the role of the actual logged librarian
	 * who is browsing the page.
	 *
	 */
	public function populate()
	{
		$pageSize = intval($this->ShelfGrid->getPageSize());
		$currentIndexPage = intval($this->ShelfGrid->getCurrentPage());
		$searchString = $this->ShelfSearch->getSafeText();
		$libraryIdFilter = intval($this->LibrarySearch->getSelectedValue());

		if ($this->getObjectType())
		{
			$typeFilter = $this->getObjectType();
			$this->TypeSearch->setSelectedValue($typeFilter);
			$this->TypeSearch->setEnabled(false);
		}
		else
		{
			$typeFilter = $this->TypeSearch->getSelectedValue();
		}
		
		if (($typeFilter == '0')
				|| is_null($typeFilter))
			$typeFilter = '';

		$statusFilter = $this->StatusSearch->getSelectedValue();
		
		if (($statusFilter == '0')
				|| is_null($statusFilter))
			$statusFilter = '';

		$except = $this->getExcept();
		$objectId = $this->getObjectId();
		$objectType = $this->getObjectType();
		$myUser = $this->getUser();

		$getObjectTypes = array(	ShelfPeer::TYPE_PATRON,
									ShelfPeer::TYPE_ITEM,
									ShelfPeer::TYPE_ISSUE,
									ShelfPeer::TYPE_MANIFESTATION,
									ShelfPeer::TYPE_MANIFESTATION_BUY);

		$shelves = array();
		$recCount = 0;

		$baseQuery = $this->getBaseQuery();
		if ($statusFilter)
			$baseQuery->filterByShelfStatus($statusFilter);

///		was moved inside an else branch, below
//		if ($typeFilter)
//			$baseQuery->condition('itemtype_null','Shelf.ShelfItemtype IS NULL')
//							->condition('itemtype','Shelf.ShelfItemtype = ?', $typeFilter)
//							->where(array('itemtype_null','itemtype'), 'or');

		if ($libraryIdFilter)
			$baseQuery->filterByLibraryId($libraryIdFilter);

		if ($searchString)
			$baseQuery->filterByShelfName($searchString . '%');

		if ($objectId 
				&& in_array($objectType, $getObjectTypes))
		{
			switch ($this->getObjectType())
			{
				case ShelfPeer::TYPE_PATRON:
					$object = PatronQuery::create()->findPk($objectId);
				
					break;

				case ShelfPeer::TYPE_ITEM:
					$object = ItemQuery::create()->findPk($objectId);
					
					break;

				case ShelfPeer::TYPE_ISSUE:
					$object = IssueQuery::create()->findPk($objectId);
					
					break;
				
				case ShelfPeer::TYPE_MANIFESTATION:
				case ShelfPeer::TYPE_MANIFESTATION_BUY:
					$object = ManifestationQuery::create()->findPk($objectId);
					
					break;
				
				default:
					$object = null;
			}

			if (!is_null($object))
			{
				$shelves = $object->getShelvesIn(	$myUser,
													$baseQuery,
													$pageSize,
													$currentIndexPage * $pageSize,
													$except);
								
				$recCount = $object->getShelvesIn(	$myUser,
													$baseQuery,
													'count',
													$currentIndexPage * $pageSize,
													$except);
			}
			else
			{
				$shelves = [];
				$recCount = 0;
			}
		}
		else
		{
			/// was moved here from above the if statement
			if ($typeFilter)
			{	
				$baseQuery->condition('itemtype_null','Shelf.ShelfItemtype IS NULL')
								->condition('itemtype','Shelf.ShelfItemtype = ?', $typeFilter)
								->where(array('itemtype_null','itemtype'), 'or');
			}

			$recCount = ShelfPeer::getVisibleShelves(	$myUser,
														null,
														'count',
														null,
														$baseQuery);

			$shelves = ShelfPeer::getVisibleShelves(	$myUser,
														null,
														$pageSize,
														$currentIndexPage * $pageSize,
														$baseQuery);
		}

		if ($pageSize > 0)
			$this->ShelfGrid->setVirtualItemCount($recCount);

		$data = array();
		
		foreach ($shelves as $shelf)
		{
			$she = array();

			$shelfName = $shelf->getEnsuredShelfName();
			$she['ShelfName'] = $shelfName;

			$shelfDescription = $shelf->getShelfDescription();
			$she['ShelfDescription'] = $shelfDescription;

			$shelfStatusString = $shelf->getShelfStatusString();
			$she['ShelfStatusString'] = $shelfStatusString;

			$librarianString = '';
			$librarianId = 0;
			$librarian = null;
			$librarian = $shelf->getLibrarianRelatedByLibrarianId();

			if ($librarian instanceof Librarian)
			{
				$librarianString = $librarian->getCompleteName();
				$librarianId = $librarian->getLibrarianId();
			}

			$she['LibrarianString'] = $librarianString;
			$she['LibrarianId'] = $librarianId;

			$libraryId = $shelf->getEnsuredLibraryId();
			$libraryString = $shelf->getEnsuredLibraryLabel();
			$she['LibraryString'] = $libraryString;
			$she['LibraryId'] = $libraryId;

			$she['Id'] = $shelf->getShelfId();

			$shelfItemsNumber = intval($shelf->countItemShelves());
			if ($shelfItemsNumber > 0)
			{
				$content = $shelf->getShelfItemtypeString();

				if ($content != '')
					$shelfItemsNumber = (string) $shelfItemsNumber . " ($content)";
			}

			$she['ShelfItemsNumber'] = $shelfItemsNumber;
			$she['CanEdit'] = $shelf->isEditable($myUser);
			$data[] = $she;
		}

		$this->ShelfGrid->setDataSource($data);
		$this->ShelfGrid->dataBind();
		$this->FoundPanel->setVisible($recCount > 0);
		$this->FoundNumber->setText($recCount);
	}

	/**
	 * It resets the pagination of the grid in case of a search
	 * by text.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onSearchShelf($sender, $param)
	{
		$this->ShelfGrid->setCurrentPage(0);
		$this->getPage()->globalRefresh();
	}

	/**
	 * Synonyme of searchCancel().
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onCancel($sender, $param)
	{
		$this->searchCancel($sender, $param);
	}

	/**
	 * It cancels the search-by-text mode, and resets
	 * the pagination of the grid.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function searchCancel($sender, $param)
	{
		$this->ShelfGrid->setCurrentPage(0);
		$this->ShelfSearch->setText('');
		$this->LibrarySearch->setSelectedIndex(0);
		$this->TypeSearch->setSelectedIndex(0);
		$this->StatusSearch->setSelectedIndex(0);

		$this->onSearchShelf(null, null);
	}

	/**
	 * It manages the change of page in the datagrid.
	 * It uses the viewstate to store the current page.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function changePage($sender, $param)
	{
		$this->ShelfGrid->setCurrentPage($param->NewPageIndex);
		$this->populate();
	}

	/**
	 * It returns whether the page permits that in this component
	 * we can have the functions that components inside popups have.
	 *
	 * @return boolean
	 */
	public function getPopupFlag()
	{
		return $this->getPage()->isPopup();
	}

	/**
	 * It returns whether the page permits that in this component
	 * we can have the unlink function.
	 *
	 * @return boolean
	 */
	public function getUnlinkFlag()
	{
		return $this->getPage()->isUnlink();
	}

	/**
	 * It returns whether the page permits that in this component
	 * we can have the delete function.
	 *
	 * @return boolean
	 */
	public function getDeleteFlag()
	{
		return $this->getPage()->isDelete();
	}

	/**
	 * This method, called for unlinking, calls the relative
	 * method of the parent page.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onUnlink($sender, $param)
	{
		$id = $param->CommandParameter;

        $numDeleted = ShelfItemQuery::create()
						->filterByShelfId($id)
						->filterByObjectClass($this->getObjectType())
						->filterByObjectId($this->getObjectId())
						->delete();

		$this->getPage()->globalRefresh();
	}

	/**
	 * This method, called for deleting, calls the relative
	 * method of the parent page.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onDelete($sender, $param)
	{
		$id = $param->CommandParameter;
		$this->getPage()->deleteShelf($id);
	}

	public function setObjectType($parName)
	{
		$this->setViewState("ObjectType", $parName, null);
	}

	public function getObjectType()
	{
		return $this->getViewState("ObjectType", null);
	}

	public function setObjectId($parValue)
	{
		$this->setViewState("ObjectId", $parValue, null);
	}

	public function getObjectId()
	{
		return $this->getViewState("ObjectId", null);
	}

	public function setExcept($except)
	{
		$this->setViewState("Except", $except, null);
	}

	public function getExcept()
	{
		return $this->getViewState("Except", null);
	}

	/**
	 * It receives, in a multiple way, from the parent page
	 * the parameters which describe what kind of object we're
	 * treating and its id, and if we have to show the shelves he's
	 * associated to or it's not associated to.
	 *
	 * @param string $objectType
	 * @param int $objectId
	 * @param boolean $except
	 */
	public function setObjectParameters($objectType, $objectId, $except = false)
	{
		$this->setObjectType($objectType);
		$this->setObjectId($objectId);
		$this->setExcept($except);
	}

	public function globalRefresh()
	{
		$this->ShelfGrid->resetSorting('ShelfName', null, false);

		$this->populate();
	}

	private function resetPagination()
	{
		$this->ShelfGrid->resetPagination();
	}

	public function onLinkReturn($sender, $param)
	{
		$item = $param->CommandParameter;
		$gotoShelf = $this->GotoShelf->getChecked() ? 'true' : 'false';
	
		//$this->getPage()->getClientScript()->registerEndScript(__CLASS__ . '_js', 'onReturn(\'' . $item['ShelfName'] . '\',\'' . $item['Id'] . '\', \'true\', \'fake\', \'' . $gotoShelf . '\');');
		$this->getPage()->getClientScript()->registerEndScript(__CLASS__ . '_js', "onReturn('" . addSlashes($item['ShelfName']) . "','{$item['Id']}', true, 'fake', '{$gotoShelf}');");
	}

}