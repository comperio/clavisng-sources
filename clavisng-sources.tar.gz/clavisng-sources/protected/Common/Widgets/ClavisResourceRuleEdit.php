<?php
/**
 * ResourceRuleEditPage
 *
 * @author Cristian Chiarello <ciarez@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2016 Comperio srl
 */
class ClavisResourceRuleEdit extends TTemplateControl
{
	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallback())
		{
			$this->populate();
		}
	}

	public function checkAuth($addedCheck = true, $force = null)
	{
		$allow = true;
		$rule = $this->getResourceRule();

		if (!is_null($rule) && ($rule instanceof ResourceRule))
			$allow = $this->getUser()->getEditPermission($rule);
		
		parent::checkAuth($allow);
	}

	public function setResourceRule($value)
	{
		$this->setViewState("resourceRuleViewstate", $value, null);
	}

	public function getResourceRule()
	{
		return $this->getViewState("resourceRuleViewstate", null);
	}

	public function getIsNew()
	{
		$rule = $this->getResourceRule();
		if (!is_null($rule) && ($rule instanceof ResourceRule))
			return $rule->isNew();
		else
			return false;
	}

	public function onSave($sender, $param)
	{
		try
		{
			$rule = $this->getResourceRule();
			if (is_null($rule) || !($rule instanceof ResourceRule))
			{
				$this->getPage()->writeMessage(Prado::localize("Errore nel passaggio dei parametri. Ricaricare la pagina e riprovare"), ClavisMessage::ERROR);
				return false;
			}

			$isNew = $rule->isNew();

			$rule->setType($this->Type->getSelectedValue());
			//$rule->setPriority($this->Priority->getSafeText());
			$rule->setPriority(1);
			//$rule->setResourceId($this->Resource->getSelectedValue());
			$rule->setResourcePattern($this->ResourcePattern->getSafeText());

			$ro = $this->ResourceOwner->getSelectedValue();
			if (!is_null($ro) && $ro != '')
			{
				$rule->setResourceOwner($ro);
			}
			else
			{
				$this->getPage()->writeMessage(Prado::localize("Specificare una risorsa"), ClavisMessage::ERROR);
			}

			/*
			  $autocomplete = $this->AutoComplete->getSafeText();
			  if($autocomplete == '')
			  {
			  $this->setViewState('PatronId', NULL);
			  $rule->setPatronId(NULL);
			  }
			  else
			  {
			  $pid = $this->getViewState('PatronId');
			  if(!is_null($pid) && $pid != '')
			  $rule->setPatronId($pid);
			  }
			 */

			$rule->setAmount($this->Amount->getSafeText());
			if ($isNew)
				$rule->setUsed(0);
			//else $rule->setUsed ( $this->Used->getSafeText() );
			$rule->setValidityStart($this->ValidityStart->getTimeStamp());
			$rule->setValidityEnd($this->ValidityEnd->getTimeStamp());

			$rule->setLibraryId($this->getUser()->getActualLibraryId());
			$rule->setNote($this->Note->getSafeText());

			/*
			  $affectedCount = $rule->save();
			  $this->setResourceRule( $rule );

			  if ( $affectedCount == 0 )
			  {
			  $this->getPage()->writeMessage( Prado::localize( "Errore, regola con id: {id} non salvata", array( 'id' => $rule->getResourceRuleId() ) ), ClavisMessage::ERROR );
			  return false;
			  }
			 */

			$rule->save();

			if ($isNew)
			{
				ChangelogPeer::logAction($rule, ChangelogPeer::LOG_CREATE, $this->getUser(), "Creata regola con id: {$rule->getResourceRuleId()}");
				$this->getPage()->writeMessage(Prado::localize("Creata regola con id: {id} ", array('id' => $rule->getResourceRuleId())), ClavisMessage::CONFIRM);
			}
			else
			{
				ChangelogPeer::logAction($rule, ChangelogPeer::LOG_UPDATE, $this->getUser(), "Modificata regola con id: " . $rule->getResourceRuleId());
				$this->getPage()->writeMessage(Prado::localize("Modificata regola con id: {id} ", array('id' => $rule->getResourceRuleId())), ClavisMessage::CONFIRM);
			}

			$this->onCancel($sender, $param);

			//$this->Page->ResourceRuleList->populate();
			/*
			  $resrulelist = $this->Page->findControlsByID("ResourceRuleList");
			  if($resrulelist[0] instanceof ClavisResourceRuleList)
			  {
			  $resrulelist[0]->populate();
			  } */

			$p = $this->getPage();
			if (method_exists($p, 'populate'))
			{
				$p->populate();
			}
		}
		catch (Exception $exc)
		{
			Prado::log(__METHOD__ . " EXCEPTION " . $exc->getTraceAsString());
		}
	}

	public function populate()
	{
		/*
		 * Get the types list
		 */
		//$this->Type->DataSource = ResourceRule::getRuleTypes( Resource::TYPE_GENERIC ) ;
		//$this->Type->dataBind();


		/*
		 * Get all resources of this library
		 */
		$libid = $this->getUser()->getActualLibraryId();
		//Prado::log("Search all resource with libid ".$libid);

		$resourceColl = ResourceQuery::create()
				->filterByLibraryId($libid)
				->find();

		$rnames = array('' => '---');
		foreach ($resourceColl as $r)
		{
			//$rnames[$r->getResourceId()] = $r->getName();
			$ip = $r->getName();
			$rnames[$ip] = $ip;
		}

		$this->ResourceOwner->DataSource = $rnames;
		$this->ResourceOwner->dataBind();

		/*
		  $rmmod = $this->getApplication()->getModule("rulemanager");
		  if($rmmod instanceof RuleManager)
		  {
		  if($rmmod->getUseRegex())
		  {
		  $this->ResourcePatternLabel->setText($this->ResourcePatternLabel->getText().' (regex)');
		  }
		  else
		  {
		  $this->ResourcePatternLabel->setText($this->ResourcePatternLabel->getText().' (substr)');
		  }
		  } */

		/*
		 * Create or get ResourceRule
		 */
		$rule = null;
		$id = intval($this->getRulePK());

		//If I have a parameter, I want to edit...
		if (!is_null($id) && $id > 0)
		{
			$rule = ResourceRuleQuery::create()->findOneByResourceRuleId($id);
			//Not found, show an error and create a new one
			if (!($rule instanceof ResourceRule))
			{
				$this->getPage()->writeMessage(Prado::localize('La risorsa con id = {id} non esiste', array('id' => $id)), ClavisMessage::ERROR);
				$rule = new ResourceRule();
				$rule->setNew(TRUE);
				//$this->gotoPage( 'Library.ResourceManager' );
			}
			else
			{
				/*
				  $pid = $rule->getPatronId();
				  if( !is_null( $pid ))
				  {
				  $patron = PatronQuery::create()->findOneByPatronId($pid);
				  if ( is_null( $patron ) || !($patron instanceof Patron) )
				  {
				  //$this->ResultLabel->setText('---');
				  }
				  else
				  {
				  $pData = $patron->getName().' '.$patron->getLastname();
				  $this->AutoComplete->setText($pData);
				  //$this->PatronId->setText($patron->getPatronId());
				  $this->setViewState('PatronId', $patron->getPatronId());
				  }
				  }
				 */

				$this->Type->setSelectedValue($rule->getType());
				$this->Amount->setText($rule->getAmount());
				//$this->Used->setText($rule->getUsed());
				//$this->Priority->setText($rule->getPriority());
				//$this->Resource->setSelectedValue($rule->getResourceId());
				$this->ResourcePattern->setText($rule->getResourcePattern());
				$this->ResourceOwner->setSelectedValue($rule->getResourceOwner());
				$this->ValidityStart->setTimeStamp($rule->getValidityStart('U'));
				$this->ValidityEnd->setTimeStamp($rule->getValidityEnd('U'));
				$this->Note->setText($rule->getNote());
			}
		}
		else //If not edit, create a new one
		{
			$rule = new ResourceRule();
			$rule->setNew(TRUE);

			$resip = $this->getRequest()->itemAt('resip');
			if (!is_null($resip) && $resip != '')
			{
				Prado::log(__METHOD__ . ' new rule of ' . $resip);
				$this->ResourceOwner->setSelectedValue($resip);
				$rule->setResourceOwner($resip);
			}
		}

		$this->setResourceRule($rule);
	}

	public function onCancel($sender, $param)
	{
		$this->ResourceRuleEditPanel->setVIsible(FALSE);
		$this->Type->setSelectedValue("");
		$this->Amount->setText("");
		$this->ResourcePattern->setText("");
		$this->ResourceOwner->setSelectedValue("");
		$this->ValidityStart->setText("");
		$this->ValidityEnd->setText("");
		$this->Note->setText("");
		$this->setResourceRule(NULL);
		$this->setRulePK(NULL);
	}
	/*
	  public function suggestNames($sender,$param) {
	  // Get the token
	  $token='%'.$param->getToken().'%';
	  //Prado::log("TOKEN ".$token);

	  $patrons = PatronQuery::create()
	  ->filterByPreferredLibraryId($this->getUser()->getActualLibraryId())
	  ->where(" (barcode LIKE '".$token."' OR name LIKE '".$token."' OR lastname LIKE '".$token."') ")
	  ->find();

	  $data = array();
	  foreach($patrons as $patron)
	  {

	  $data[] =array('id'=>$patron->getPatronId(),'name'=>$patron->getName() . ' ' .$patron->getLastname()) ;
	  }

	  // Sender is the Suggestions repeater
	  $sender->DataSource=$data;
	  $sender->dataBind();
	  }


	  public function suggestionSelected1($sender,$param) {
	  $id=$sender->Suggestions->DataKeys[ $param->selectedIndex ];
	  //$this->Selection1->Text='Selected ID: '.$id;
	  //Prado::log("ID ".$id);
	  $this->setViewState('PatronId', $id);
	  }
	 */

	public function resourceOwnerChanged($sender, $param)
	{
		//Prado::log(__METHOD__ . " changing resource types...");
		$r = ResourceQuery::create()->filterByName($this->ResourceOwner->getSelectedValue());
		if ($r instanceof Resource)
		{
			$this->Type->DataSource = ResourceRule::getRuleTypes($r->getType());
			$this->Type->dataBind();
		}
	}

	public function setVisible($param)
	{
		$this->ResourceRuleEditPanel->setVIsible($param);
	}

	public function setMode($mode)
	{
		$this->setControlState('mode', $mode);
	}

	public function getMode()
	{
		return $this->getControlState('mode');
	}

	public function setRulePK($pk)
	{
		$this->setControlState('pk', $pk);
	}

	public function getRulePK()
	{
		return $this->getControlState('pk');
	}
	
}