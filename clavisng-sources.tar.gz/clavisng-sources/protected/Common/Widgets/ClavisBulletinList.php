<?php

/**
 * ClavisBulletinList class
 * 
 * @author Marco Brancalion <mbrancalion@e-portaltech.it>
 * @author Max Pigozzi <mpigozzi@e-portaltech.it>
 * @link http://www.e-portaltech.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @version 2.7
 * @package Widgets
 * @since 2.1
 */

class ClavisBulletinList extends TTemplateControl
{
	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallBack())
		{
			$expiredCount = BulletinPeer::selfExpireOldBulletins(time() - ClavisParamQuery::getParam('CLAVISPARAM','ExpireOldBulletinLimit'));
			if ($expiredCount > 0)
			{
				ChangelogPeer::logAction('Bulletin', ChangelogPeer::LOG_DELETE, $this->getUser(),
						"Cancellati {$expiredCount} messaggi interni obsoleti");
						
				$this->getPage()->writeMessage($expiredCount . " " . Prado::localize("messaggi interni obsoleti cancellati"),
												ClavisMessage::CONFIRM);
			}

			$this->populate();
		}
	}

	public function setEditMode($editMode)
	{
		$this->setControlState("EditMode", $editMode, false);
	}

	public function getEditMode()
	{
		return $this->getControlState("EditMode", false);
	}

	public function calculateSortingCriteria(&$sortingCriteria = null)
	{
		$sortingExpression = $this->Grid->getSortingExpression();
		$sortingDirection = $this->Grid->getSortingDirection();
		if (is_null($sortingCriteria) || !($sortingCriteria instanceof Criteria))
			$sortingCriteria = new Criteria();

		switch ($sortingExpression)
		{
			case 'publishStartDate':
				$sortingCriteria->clearOrderByColumns();
				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
					$sortingCriteria->addAscendingOrderByColumn(BulletinPeer::PUBLISH_START_DATE);
				else
					$sortingCriteria->addDescendingOrderByColumn(BulletinPeer::PUBLISH_START_DATE);
				break;

			case 'publishEndDate':
				$sortingCriteria->clearOrderByColumns();
				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
					$sortingCriteria->addAscendingOrderByColumn(BulletinPeer::PUBLISH_END_DATE);
				else
					$sortingCriteria->addDescendingOrderByColumn(BulletinPeer::PUBLISH_END_DATE);
				break;

			case '':
			case null:
			default:
				break;
		}
	}

	public function populate()
	{
		$pageSize = $this->Grid->getPageSize();
		$currentIndexPage = $this->Grid->getCurrentPage();
		$clavisLibrarian = $this->getUser();
		$currentTime = time();
		$criteria = new Criteria();

		if (!$this->getEditMode())
		{
			$criterionVisible = $criteria->getNewCriterion(BulletinPeer::SCOPE, BulletinPeer::SCOPE_ALL);
			$criterionLocalVisible = $criteria->getNewCriterion(BulletinPeer::SCOPE, BulletinPeer::SCOPE_OWNLIBRARY);
			$criterionLibrary = $criteria->getNewCriterion(BulletinPeer::LIBRARY_ID, $this->getUser()->getActualLibraryId());
			$criterionLocalVisible->addAnd($criterionLibrary);

			$criterionVisible->addOr($criterionLocalVisible);

			$criteria->add($criterionVisible);

			$criteria->add(BulletinPeer::PUBLISH_START_DATE, $currentTime, Criteria::LESS_EQUAL);
			$criteria->add(BulletinPeer::PUBLISH_END_DATE, $currentTime, Criteria::GREATER_EQUAL);
		}

		$recCount = BulletinPeer::doCount($criteria);
		$this->Grid->setVirtualItemCount($recCount);

		$this->calculateSortingCriteria($criteria);

		$criteria->setLimit($pageSize);
		$criteria->setOffset($currentIndexPage * $pageSize);

		if ($this->Grid->getSortingExpression() == '')
		{
			$criteria->addDescendingOrderByColumn(BulletinPeer::STICKY);
			$criteria->addDescendingOrderByColumn(BulletinPeer::DATE_CREATED);
			$criteria->addDescendingOrderByColumn(BulletinPeer::DATE_UPDATED);
		}

		$bulletins = BulletinPeer::doSelect($criteria);
		$data = array();

		/* @var $bulletin Bulletin */
		foreach ($bulletins as $bulletin)
		{
			$row = array();
			$sticky = $bulletin->getSticky();
			$row['Sticky'] = $sticky;
			$stickyString = ($bulletin->getSticky() == 1 ? '<span style = "color: red;"><b>[' . Prado::localize('permanente') . ']</b></span> ' : '');

			$row['ProtectedMessage'] = $bulletin->getProtectedMessage();
			$protectedMessageString = ($bulletin->getProtectedMessage() == 1
										? '<span style = "color: blue;"><b>[' . Prado::localize('protetto') . ']</b></span> '
										: '');

			$title = trim($bulletin->getTitle());
			if (is_null($title) || ($title == ''))
				$title = '(' . Prado::localize('senza titolo') . ')';
			$row['Title'] = $title;

			$row['LibraryId'] = $bulletin->getLibraryId();
			$library = $bulletin->getLibrary();
			if (!is_null($library))
				$row['LibraryLabel'] = $library->getLabel();
			else
				$row['LibraryLabel'] = '';

			$createdByName = $bulletin->getCreatedByNameString();
			$createdBy = $bulletin->getCreatedBy();
			$createdByLibrary = '';
			
			$dateUpdated = Clavis::dateFormat($bulletin->getDateUpdated('U'));
			if (!is_null($dateUpdated) && ($dateUpdated != ''))
				$dateUpdated = ' &nbsp;(' . $dateUpdated . ')';
			else
				$dateUpdated = '';

			$row['TitleBody'] = '<br /><div class="viewlabel2short"'
									. ($sticky
										? ' style="border-color: red"'
										: '')
									
									. '> ** ' . $stickyString
									. '<b>' . Prado::localize('Titolo') . '</b>: ' . $title
									. $dateUpdated
									.' <b>'. Prado::localize('Creato da') . '</b>: '.$createdByName. ' ('.$row['LibraryLabel'].') '
									. $protectedMessageString
									. '**</div><br />'
									. $bulletin->getBody();

			$scope = $bulletin->getScope();
			$row['Scope'] = LookupValuePeer::getLookupValue('BULLETINSCOPE', $scope);

			$publishStartDateTS = $bulletin->getPublishStartDate('U');
			$publishEndDateTS = $bulletin->getPublishEndDate('U');
			$row['EarlyDateFlag'] = ($publishStartDateTS > $currentTime) && (intval($publishStartDateTS))
										? true : false;
			$row['LateDateFlag'] = ($publishEndDateTS + 86399 < $currentTime) && (intval($publishEndDateTS))
										? true : false;

			$row['PublishStartDate'] = $bulletin->getPublishStartDate('U');
			$row['PublishEndDate'] = $bulletin->getPublishEndDate('U');

			$row['LibrarianId'] = $bulletin->getLibrarianId();
			$row['LibrarianCompleteName'] = $bulletin->getLibrarianRelatedByLibrarianId()->getCompleteName();

			$row['Id'] = $bulletin->getBulletinId();
			$row['CanEdit'] = $clavisLibrarian->getEditPermission($bulletin);

			$data[] = $row;
		}

		$this->Grid->setDataSource($data);
		$this->Grid->dataBind();

		$this->RecCounter->setText($recCount);
	}

	public function onChangePage($sender,$param)
	{
		$this->Grid->setCurrentPage($param->NewPageIndex);
		$this->populate();
	}

	public function resetPagination()
	{
		$this->Grid->setCurrentPage(0);
	}

	public function getPopupFlag()
	{
		return $this->getPage()->IsPopup();
	}

	public function getUnlinkFlag()
	{
		return $this->getPage()->IsUnlink();
	}

	public function onDelete($sender, $param)
	{
		$bulletinId = intval($param->CommandParameter);
		if ($bulletinId > 0)
		{
			$bulletin = BulletinQuery::create()
							->findPk($bulletinId);
			
			$bulletinUserId = $bulletin->getLibrarianId();
			$librarian = LibrarianQuery::create()
							->findPk($bulletinUserId);
			
			if ($librarian instanceof Librarian )
				$librarianName = $librarian->getName() . ' ' . $librarian->getLastname();
			else
				$librarianName = '(' . Prado::localize('senza nome') . ')';

			if (BulletinPeer::doDelete($bulletinId) > 0)
			{
				$this->getPage()->writeMessage(Prado::localize('Messaggio cancellato'),
												ClavisMessage::CONFIRM);
				
				ChangelogPeer::logAction(	$bulletin,
											ChangelogPeer::LOG_UPDATE,
											$this->getUser(),
											"cancellato messaggio interno con id = {$bulletinId}, inserito dall\'operatore {$librarianName}");
			}
			else
			{
				$this->getPage()->writeMessage(Prado::localize('Errore sulla cancellazione del messaggio'),
												ClavisMessage::ERROR);
			}
		}

		$this->populate();
	}

	public function onGridBound($sender, $param)
	{
		$item = $param->Item;

		if ($item->DataItem['LateDateFlag'])
			$item->setCssClass('itembackgroundlightred');
	}
}