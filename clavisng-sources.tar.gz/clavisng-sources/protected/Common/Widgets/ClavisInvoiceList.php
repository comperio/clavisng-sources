<?php
/**
 * ClavisInvoiceList class file
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 */

/**
 * ClavisInvoiceList
 *
 * @author Max Pigozzi
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @copyright Copyright &copy; 2010 Comperio srl
 * @version 2.7
 * @package Widgets
 * @since 2.2
 */

class ClavisInvoiceList extends TTemplateControl 
{
	protected $_library;

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallBack()) 
		{
			$filters = $this->getFilters();

			$this->LibraryFilter->setDataSource(LibraryPeer::getLibrariesHash(	array(LibraryPeer::BLANKVALUE), 
																				array('---'),
																				null,
																				true ) );
			$this->LibraryFilter->dataBind();
			
			if (array_key_exists('InvoiceStatus', $filters))
			{
				$invoiceStatusFilter = $filters['InvoiceStatus'];

				if (!is_null($invoiceStatusFilter) && ($invoiceStatusFilter != ""))
					$this->InvoiceStatus->setSelectedValue($invoiceStatusFilter);
			}		
					
			if ($this->getAutoPopulate())
				$this->populate();
			
			$this->InvoiceGrid->resetPagination();
		}
	}

	public function populate()
	{
		$this->populateInvoiceGrid();
	}

	public function setAutoPopulate($flag = true)
	{
		if ($flag === "true")
			$flag = true;
		elseif ($flag === "false")
			$flag = false;
		
		$this->setViewState("AutoPopulate", $flag, true);
	}

	public function getAutoPopulate()
	{
		return $this->getViewState("AutoPopulate", true);
	}
	
	public function setFilters($filter = array())
	{
		$this->setControlState('Filters', $filter, array());
	}

	public function getFilters()
	{
		return $this->getControlState('Filters', array());
	}
	
	private function populateInvoiceGrid()
	{
		$pageSize = $this->InvoiceGrid->getPageSize();
		$currentIndexPage = $this->InvoiceGrid->getCurrentPage();

		$filterLib = $this->LibraryFilter->getSelectedValue();
		if ($this->getLibrary() instanceof Library) 
		{
			$this->LibraryColumn->setVisible(false);
			$filterLib = $this->_library->getLibraryId();
		}

		$criteria = new Criteria();

		if ($filterLib > 0)
			$criteria->add(InvoicePeer::LIBRARY_ID, $filterLib);

		$invoiceFilter = $this->InvoiceFilter->getSafeText();
		if ($invoiceFilter != '')
			$criteria->addAnd(InvoicePeer::INVOICE_NUMBER, $invoiceFilter);

		if ($this->InvoiceStatus->getSelectedIndex() > 0)
			$criteria->addAnd(InvoicePeer::INVOICE_STATUS, $this->InvoiceStatus->getSelectedValue());
			
		$dateFilter = $this->DateFilter->getTimestamp();
		if ($dateFilter != '')
	    	$criteria->addAnd(InvoicePeer::INVOICE_DATE, $dateFilter, Criteria::GREATER_EQUAL);

		$supplierId = $this->SupplierId->getValue();
		if ($supplierId != '')
			$criteria->addAnd(InvoicePeer::SUPPLIER_ID, $supplierId);

		$recCount = InvoicePeer::doCount($criteria);
		$this->InvoiceGrid->setVirtualItemCount($recCount);

		$this->FoundNumber->setText($recCount);

        $criteria->setLimit($pageSize);
		$criteria->setOffset($currentIndexPage * $pageSize);

		$this->calculateSortingCriteria($criteria);

        $invoices = InvoicePeer::doSelect($criteria);

		$this->InvoiceGrid->setDataSource($invoices);
		$this->InvoiceGrid->dataBind();
	}

	public function search()
	{
		$this->searchInvoice(null, null);
	}
	
	public function searchInvoice($sender, $param) 
	{
		$this->InvoiceGrid->CurrentPageIndex = 0;
		$this->populateInvoiceGrid();
	}

	public function onCancel()
	{
		$this->searchCancel(null, null);
	}

	public function searchCancel($sender, $param)
	{
		$this->LibraryFilter->setSelectedValue(-1);
		$this->InvoiceStatus->setSelectedValue(-1);
		$this->InvoiceFilter->setText('');
		$this->DateFilter->setText('');
		$this->clearSupplierFilter();
		$this->searchInvoice(null, null);
	}

	private function clearSupplierFilter()
	{
		$this->SupplierFilter->setText('');
		$this->SupplierId->setValue('');	
	}
	
	public function onClearSupplierFilter($sender, $param)
	{
		$this->clearSupplierFilter();
	}
			
	public function changePage($sender,$param) 
	{
		$this->InvoiceGrid->setCurrentPage($param->NewPageIndex);
		$this->getPage()->globalRefresh();
	}

	public function getPopupFlag()
	{
		return $this->getPage()->IsPopup();
	}

	public function getUnlinkFlag()
	{
		return $this->getPage()->IsUnlink();
	}

	public function setLibrary(Library $library) 
	{
		$this->_library = $library;
		$this->setControlState('library', $library, null);
	}
	
	public function getLibrary() 
	{
		if (! $this->_library instanceof Library)
			$this->_library = $this->getControlState('library',null);
		return $this->_library;
	}

	public function resetSorting() 
	{
		$this->InvoiceGrid->resetSorting('default', null, false);
	}

	public function calculateSortingCriteria(&$sortingCriteria = null)
	{
		$sortingExpression = $this->InvoiceGrid->getSortingExpression();
		$sortingDirection = $this->InvoiceGrid->getSortingDirection();

		if (! $sortingCriteria instanceof Criteria)
			$sortingCriteria = new Criteria();

		switch ($sortingExpression)
		{
			case 'number':
				$sortingCriteria->clearOrderByColumns();
				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
					$sortingCriteria->addAscendingOrderByColumn(InvoicePeer::INVOICE_NUMBER);
				else
					$sortingCriteria->addDescendingOrderByColumn(InvoicePeer::INVOICE_NUMBER);
				break;

			case 'date':
				$sortingCriteria->clearOrderByColumns();
				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
					$sortingCriteria->addAscendingOrderByColumn(InvoicePeer::INVOICE_DATE);
				else
					$sortingCriteria->addDescendingOrderByColumn(InvoicePeer::INVOICE_DATE);
				break;

//			case 'amount':
//				$sortingCriteria->clearOrderByColumns();
//				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
//					$sortingCriteria->addAscendingOrderByColumn(InvoicePeer::TOTAL_AMOUNT);
//				else
//					$sortingCriteria->addDescendingOrderByColumn(InvoicePeer::TOTAL_AMOUNT);
//				break;

			case 'status':
				$sortingCriteria->clearOrderByColumns();
				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
					$sortingCriteria->addAscendingOrderByColumn(InvoicePeer::INVOICE_STATUS);
				else
					$sortingCriteria->addDescendingOrderByColumn(InvoicePeer::INVOICE_STATUS);
				break;
				
			default:
				$sortingCriteria->clearOrderByColumns();
				$sortingCriteria->addDescendingOrderByColumn(InvoicePeer::DATE_CREATED);
				break;
		}
	}

}
