<?php

/**
 * ClavisItemView
 *
 * Component which shows the data of a single item.
 * 
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @version 2.7
 * @package Widgets
 * @since 2.1
 */
class ClavisItemView extends TTemplateControl
{
	/**
	 * Object Item which we are treating.
	 *
	 * @var Item
	 */
	private $_item = null;

	/**
	 * In the onLoad, during first execution of the page we
	 * get the actual item and populate the list.
	 *
	 * @param TEventParameter $param
	 */
	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsPostBack())
		{
			$this->getItem();
			$this->populate();
		}
	}

	public function setItem($item)
	{
		$this->_item = $item;
		$this->setControlState("Item", $item, null);
	}

	public function getItem()
	{
		if (is_null($this->_item))
			$this->_item = $this->getControlState("Item", null);
		return $this->_item;
	}

	public function getItemiconLabel()
	{
		$item = $this->getItem();
		if ($item instanceof Item)
			return $item->getItemiconLabel();
		else
			return '';
	}

	public function getItemiconFile()
	{
		$item = $this->getItem();
		if ($item instanceof Item)
			return $item->getItemiconFile();
		else
			return '';
	}

	public function setInvisibleIfNull($boolean)
	{
		$this->setControlState("InvisibleIfNull", $boolean, false);
	}

	public function getInvisibleIfNull()
	{
		$boolean = $this->getControlState("InvisibleIfNull", false);
		if ($boolean === true)
			return true;
		else
			return false;
	}

	public function setShowTitle($boolean = false)
	{
		if ($boolean === 'true')
			$boolean = true;
		else
			$boolean = false;

		$this->setControlState("ShowTitle", $boolean, false);
	}

	public function getShowTitle()
	{
		$boolean = $this->getControlState("ShowTitle", false);
		if ($boolean === true)
			return true;
		else
			return false;
	}

	public function populate()
	{
		$this->getItem();

		if (!($this->_item instanceof Item))
		{
			$this->ItemViewPanel->setCssClass("panel_off");
			return;
		}

		$this->ItemViewPanel->setCssClass("panel_on");

		if (intval($this->_item->getManifestationId()) == 0 && $this->getShowTitle())
		{
			$this->ManifestationNoPanel->setVisible(true);
			$this->ItemTitle->setText($this->_item->getTitle());
		}
		else
		{
			$this->ManifestationNoPanel->setVisible(false);
		}

		$ret = $this->_item->getOpacVisible();
		$this->OpacVisible->setChecked($ret);

		//collocazione
		$this->Section->setText(LibraryValuePeer::getLibraryValue('ITEMSECTION', $this->_item->getSection(), $this->_item->getHomeLibraryId()));

		$shortCollocation = $this->_item->getCollocationCombo(null, null, false);
		$this->Collocation->setText($shortCollocation);

		$this->Barcode->setText($this->_item->getBarcode());
		$this->Rfid->setText($this->_item->getRfidCode());

		//inventariazione
		$inventorySerieId = $this->_item->getInventorySerieId();
		$this->InventorySerieDescription->setText($inventorySerieId);

		$this->InventoryNumber->setText($this->_item->getInventoryNumber());
		$this->InventoryDate->setValue($this->_item->getInventoryDate('U'));

		//stati
		$this->ItemMedia->setText(LookupValuePeer::getLookupValue('ITEMMEDIATYPE', $this->_item->getItemMedia()));

		$this->ItemStatus->setText($this->_item->getItemStatusString());
		$this->ItemOrderStatus->setText($this->_item->getItemOrderStatusString());

		$dateDiscarded = $this->_item->getDateDiscarded('U');
		if ($dateDiscarded)
		{
			$this->DateDiscardedPanel->setVisible(true);
			$this->DateDiscarded->setValue($dateDiscarded);
			$this->DiscardNote->setText($this->_item->getDiscardNote());
		}
		else
		{
			$this->DateDiscardedPanel->setVisible(false);
		}

		$this->PhysicalStatus->setText($this->_item->getPhysicalStatusString());

		//  values and currency

		$itemCurrency = TPropertyValue::ensureString($this->_item->getEnsuredCurrency());
		$this->ItemCurrency->setText(LookupValuePeer::getLookupValue('CURRENCY', $itemCurrency));

		//$this->ItemCost->setText(ClavisBase::numberFormat($this->_item->getCurrencyValue(), '#.00'));
		$this->ItemCost->setValue($this->_item->getCurrencyValue());
		$this->ItemCost->setCurrency($itemCurrency);

		$itemDiscount = $this->_item->getDiscountValue();
		if (is_null($itemDiscount))
			$itemDiscount = "";
		else
			$itemDiscount = ClavisBase::numberFormat($this->_item->getDiscountValue(), '#.00%');
		$this->ItemDiscount->setText($itemDiscount);

		//$this->ItemValue->setText(ClavisBase::numberFormat($this->_item->getInventoryValue(), '#.00'));
		$this->ItemValue->setValue($this->_item->getInventoryValue());
		$this->ItemValue->setCurrency($itemCurrency);

		$this->ItemSource->setText(LookupValuePeer::getLookupValue('ITEMSOURCE', $this->_item->getItemSource()));

		$supplier = $this->_item->getSupplier();
		if ($supplier instanceof Supplier)
		{
			$this->ItemSupplier->setEnabled(true);
			$this->ItemSupplier->setNavigateUrl($this->getService()->constructUrl('Acquisition.SupplierPage', array('id' => $supplier->getSupplierId())));
			$this->ItemSupplier->setText($supplier->getSupplierName());
		}
		else
		{
			$this->ItemSupplier->setEnabled(false);
			$this->ItemSupplier->setText(Prado::localize('nessun fornitore'));
		}

		$budget = $this->_item->getBudget();
		if ($budget instanceof Budget)
		{
			$this->BudgetLink->setEnabled(true);
			$this->BudgetLink->setNavigateUrl($this->getService()->constructUrl('Acquisition.BudgetViewPage', array('id' => $budget->getBudgetId())));
			$this->BudgetLink->setText($budget->getCompleteBudgetTitle());
		}
		else
		{
			$this->BudgetLink->setEnabled(false);
			$this->BudgetLink->setText(Prado::localize('nessun budget'));
		}

		//documenti di acquisto
		$order = $this->_item->getPurchaseOrder();
		if ($order instanceof PurchaseOrder)
		{
			$this->ItemOrder->setEnabled(true);
			$this->ItemOrder->setNavigateUrl($this->getService()->constructUrl('Acquisition.OrderViewPage', array('id' => $order->getOrderId())));
			$this->ItemOrder->setText($order->getOrderId() . ' (' . $order->getOrderDate('Y/m/d') . ')');
		}
		else
		{
			$this->ItemOrder->setEnabled(false);
			$this->ItemOrder->setText(Prado::localize('nessun ordine'));
		}

		$invoice = $this->_item->getInvoice();
		if ($invoice instanceof Invoice)
		{
			$this->ItemInvoice->setEnabled(true);
			$this->ItemInvoice->setNavigateUrl($this->getService()->constructUrl('Acquisition.InvoiceViewPage', array('id' => $invoice->getInvoiceId())));
			$this->ItemInvoice->setText($invoice->getInvoiceCompleteLabel());
		}
		else
		{
			$this->ItemInvoice->setEnabled(false);
			$this->ItemInvoice->setText(Prado::localize('nessuna fattura'));
		}

		//dati fisici
		$this->ItemWidth->setText($this->_item->getWidth());
		$this->ItemHeight->setText($this->_item->getHeight());
		$this->ItemWeight->setText(ClavisBase::numberFormat($this->_item->getWeight(), '#.00'));

		$this->ItemVolumeText->setText($this->_item->getVolumeText());
		$this->ItemVolumeNumber->setText($this->_item->getVolumeNumber());

		$this->Mediapackage_size->setText($this->_item->getMediapackageSize());

		$checkin = $this->_item->getCheckIn('U');
		if ($checkin)
		{
			$this->CheckIn->setValue($checkin);
			$this->CheckIn->setEnabled(true);
		}
		else
		{
			$this->CheckIn->setEnabled(false);
		}

		$this->UsageCount->setText($this->_item->getUsageCount());

		//biblioteche
		$ownerLibraryId = intval($this->_item->getOwnerLibraryId());
		if ($ownerLibraryId > 0)
		{
			$ownerLibrary = $this->_item->getOwnerLibrary();
			if (!is_null($ownerLibrary))
				$ownerLibraryLabel = $ownerLibrary->getLabel(true, true); // . $ownerLibrary->getExternalString();
			else
				$ownerLibraryLabel = '';

			$ownerLibraryUrl = LibraryPeer::getNavigateUrl($ownerLibraryId);
			if ($ownerLibraryUrl != '')
			{
				$this->OwnerLibrary->setEnabled(true);
				$this->OwnerLibrary->setNavigateUrl($ownerLibraryUrl);
				$this->OwnerLibrary->setText($ownerLibraryLabel);
			}
			else
			{
				$this->OwnerLibrary->setEnabled(false);
				$this->OwnerLibrary->setText(Prado::localize("[<em>dato mancante</em>]"));
			}
		}
		else
		{
			$this->OwnerLibrary->setEnabled(false);
			$this->OwnerLibrary->setText(Prado::localize("[<em>dato mancante</em>]"));
		}


		$homeLibraryId = intval($this->_item->getHomeLibraryId());
		if ($homeLibraryId > 0)
		{
			$homeLibrary = LibraryPeer::retrieveByPK($homeLibraryId);
			if (!is_null($homeLibrary))
				$homeLibraryLabel = $homeLibrary->getLabel(true, true); // . $homeLibrary->getExternalString();
			else
				$homeLibraryLabel = '';
			$homeLibraryUrl = LibraryPeer::getNavigateUrl($homeLibraryId);

			if ($homeLibraryUrl != '')
			{
				$this->HomeLibrary->setEnabled(true);
				$this->HomeLibrary->setNavigateUrl($homeLibraryUrl);
				$this->HomeLibrary->setText($homeLibraryLabel);
			}
			else
			{
				$this->HomeLibrary->setEnabled(false);
				$this->HomeLibrary->setText(Prado::localize("[<em>dato mancante</em>]"));
			}
		}
		else
		{
			$this->HomeLibrary->setEnabled(false);
			$this->HomeLibrary->setText(Prado::localize("[<em>dato mancante</em>]"));
		}

		$actualLibraryId = intval($this->_item->getActualLibraryId());
		if ($actualLibraryId > 0)
		{
			$actualLibrary = LibraryPeer::retrieveByPK($actualLibraryId);
			if (!is_null($actualLibrary))
				$actualLibraryLabel = $actualLibrary->getLabel(true, true); // . $actualLibrary->getExternalString();
			else
				$actualLibraryLabel = '';
			$actualLibraryUrl = LibraryPeer::getNavigateUrl($actualLibraryId);
			if ($actualLibraryUrl != '')
			{
				$this->ActualLibrary->setEnabled(true);
				$this->ActualLibrary->setNavigateUrl($actualLibraryUrl);
				$this->ActualLibrary->setText($actualLibraryLabel);
			}
			else
			{
				$this->ActualLibrary->setEnabled(false);
				$this->ActualLibrary->setText(Prado::localize("[<em>dato mancante</em>]"));
			}
		}
		else
		{
			$this->ActualLibrary->setEnabled(false);
			$this->ActualLibrary->setText(Prado::localize("[<em>dato mancante</em>]"));
		}

		//gestione fascicoli
		$issue = $this->_item->getIssue();
		if (!is_null($issue))
		{
			$this->IssuePanel->setVisible(true);
			$issueDescription = $issue->getIssueCombo();
			$this->ItemIssue->setText($issueDescription);
			$this->ItemIssue->setNavigateUrl("index.php?page=Catalog.IssueViewPage&id=" . $issue->getIssueId());
			$this->ItemIssueInvNumber->setText($this->_item->getIssueInventoryNumber());
			$this->ItemIssueArrivalDateExpected->setValue($this->_item->getIssueArrivalDateExpected('U'));
			$this->ItemIssueArrivalDate->setValue($this->_item->getIssueArrivalDate('U'));
			$this->ItemIssueStatus->setText(LookupValuePeer::getLookupValue('ISSUESTATUS', $this->_item->getIssueStatus()));
			if (($cn = $this->_item->getConsistencyNote()) instanceof ConsistencyNote)
				$this->ConsistencyNote->setText($cn->getTextNote());
			$this->ItemSubscription->setText($this->_item->getSubscriptionId());
		}
		else
		{
			$this->IssuePanel->setVisible(false);
		}

		//campi custom
		$this->ItemCustomfield1->setText($this->_item->getCustomField1String());
		$this->ItemCustomfield2->setText($this->_item->getCustomField2String());
		$this->ItemCustomfield3->setText($this->_item->getCustomField3String());

		$this->Reprint->setText($this->_item->getReprint());

		//classe di prestabilità
		$loanClass = $this->_item->getLoanClass();
		$loanClassString = $this->_item->getLoanClassString();
		$this->LoanClassString->setText($loanClassString);

		//stato di prestito
		$loanStatusString = $this->_item->getLoanStatusString();

		//gestione item in ordine
		if ($loanClass == ItemPeer::LOANCLASS_UNAVAILABLE)
			$this->LoanStatusString->setText('(' . $loanStatusString . ')');
		else
			$this->LoanStatusString->setText($loanStatusString);

		$this->LoanAlertNote->setText($this->_item->getLoanAlertNote());
		$this->LoanAlert->setText(LookupValuePeer::getLookupValue("ITEMLOANALERT", $this->_item->getLoanAlert()));

		//$loanStatus = $this->_item->getLoanStatus();
		$patron = $this->_item->getPatron();
		if ($patron instanceof Patron)
		{
			$patronCompleteName = $patron->getCompleteName();
			$patronId = $this->_item->getPatronId();
			$patronUrl = "index.php?page=Circulation.PatronViewPage&id=" . $patronId;
			$this->PatronLink->NavigateUrl = $patronUrl;
			$this->PatronLink->Text = $patronCompleteName;

			$this->DueDateLink->setValue($this->_item->getDueDate('U'));

			$checkout = $this->_item->getCheckOut('U');
			if ($checkout)
			{
				$this->CheckOut->setValue($checkout);
				$this->CheckOut->setEnabled(true);
			}
			else
			{
				$this->CheckOut->setEnabled(false);
			}

			$this->SolicitCounter->setText($this->_item->getNotifyCount());
			$this->RenewCounter->setText($this->_item->getRenewalCountLabel());

			$this->PatronPanel->setVisible(true);
		}
		else
		{
			$externalLibrary = null;
			$externalLibraryId = intval($this->_item->getExternalLibraryId());
			if ($externalLibraryId > 0)
				$externalLibrary = LibraryPeer::retrieveByPK($externalLibraryId);
			if ($externalLibrary instanceof Library)
			{
				$this->PatronLink->setNavigateUrl($externalLibrary->getNavigateUrl() . $externalLibraryId);
				$this->PatronLink->setText($externalLibrary->getLabel(true));

				$this->DueDateLink->setValue($this->_item->getDueDate('U'));

				$checkout = $this->_item->getCheckOut('U');
				if ($checkout)
				{
					$this->CheckOut->setValue($checkout);
					$this->CheckOut->setEnabled(true);
				}
				else
				{
					$this->CheckOut->setEnabled(false);
				}

				$this->SolicitCounter->setText($this->_item->getNotifyCount());
				$this->RenewCounter->setText($this->_item->getRenewalCountLabel());

				$this->PatronPanel->setVisible(true);
			}
			else
			{
				$this->PatronPanel->setVisible(false);
			}
		}

		$this->dataBind();
	}
}