<?php
/**
 * ClavisObjectUpdateData
 *
 * It's sort of a stripe banner that shows the librarian name+lastname
 * and date of first creation and update of the object which gets passed
 * as a parameter.
 
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @version 2.8.9
 * @package Widgets
 * @since 2.0
 */
class ClavisObjectUpdateData extends TTemplateControl
{
	private $_object;
	private $_class;

	/**
	 * It populates the update data of the object.
	 *
	 * @param TEventParameter $param
	 */
	public function onLoad($param)
	{
		parent::onLoad($param);

		$this->getObject();

		if (!$this->getPage()->getIsPostBack() 
				&& !$this->getPage()->getIsCallback())
			$this->populate();
	}

	public function setInvisibleIfNull($boolean)
	{
		$this->setControlState('InvisibleIfNull', TPropertyValue::ensureBoolean($boolean), false);
	}

	public function getInvisibleIfNull()
	{
		$boolean = TPropertyValue::ensureBoolean($this->getControlState('InvisibleIfNull', false));
	}

	/**
	 * Population of fields.
	 *
	 */
	public function populate()
	{
		$object = $this->getObject();

		if (is_null($object) 
				|| ($object->isNew()))
		{
			$this->ObjectUpdateDataPanel->setCssClass('panel_off');
			$this->clearFields();
			$this->Popuplink->setPopupPage($this->getPopupUrl());
			
			return;
		}
		else
		{
			$this->ObjectUpdateDataPanel->setCssClass('panel_on');
		}

		if (!$object->isNew())
		{
			$this->RecordID->setText($object->getId());
			$this->CreatedBy->setText($object->getCreatedByNameString());
			
			if ($time = $object->getDateCreated('U'))
				$this->DateCreated->setValue($time);
			
			$this->ModifiedBy->setText($object->getModifiedByNameString());
			
			if ($time = $object->getDateUpdated('U'))
				$this->DateUpdated->setValue($time);
		}

		$this->Popuplink->setPopupPage($this->getPopupUrl());
	}

	public function clearFields()
	{
		$this->RecordID->setText('');
		$this->CreatedBy->setText('');
		$this->DateCreated->setValue(null);
		$this->ModifiedBy->setText('');
		$this->DateUpdated->setValue(null);
	}

	public function setObject($object)
	{
		$this->_object = $object;
		$this->setControlState('object', $object, null);
	}

	public function getObject()
	{
		$this->_object = $this->getControlState('object', null);
		
		return $this->_object;
	}

	public function getPopupUrl()
	{
		$object_class = '';
		$object_id = -1;
		$user_class = '';
		$user_id = '';

		$this->getObject();
		$this->getClass();

		$popup_url = 'MyHomePage.ChangelogPopup';

		if ($this->_object != null) 
		{
			if (is_object($this->_object)) 
			{
				$object_class = get_class($this->_object);

				if (in_array('getId',get_class_methods($this->_object)))
					$object_id = $this->_object->getId();
			}

			if ($object_class != '') 
			{
				$popup_url .= '&objectClass='.$object_class;

				if ($object_id != -1)
					$popup_url .= '&objectId='.$object_id;
			}
		}
		elseif ($this->_class != null)
		{
			$popup_url .= '&objectClass='.$this->_class;
		}

		return $popup_url;
	}

	public function setClass($class)
	{
		$this->_class = $class;
		$this->setControlState('class', $class, null);
	}

	public function getClass()
	{
		if (is_null($this->_class))
			$this->_class = $this->getControlState('class', null);
		
		return $this->_class;
	}
}
