<?php

/**
 * This components visualizes the items inside a shelf,
 * into a grid.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @version 2.7
 * @package Widgets
 * @since 2.0
 */
class ClavisShelfItemList extends TTemplateControl
{
	private $_shelf;
	public $_masterChecked;
	private $_checked = array('all' => false);
	private $_checkedSessionName;
	private $_datasource;
	private $_datasourceSessionName;
	public $_onlySelectedSessionName;

	private function initVars()
	{
		$uniqueId = $this->getUniqueID();
		$this->_checkedSessionName = "CheckedSessionName" . $uniqueId;
		$this->_datasourceSessionName = "DatasourceSessionName" . $uniqueId;
		$this->_onlySelectedSessionName = "OnlySelectedSessionName" . $uniqueId;

		$this->_checked = $this->getChecked();
		$this->_masterChecked = $this->_checked['all'];
	}

	public function onInit($param)
	{
		parent::onInit($param);
		$this->initVars();
	}

	public function onLoad($param)
	{
		parent::onLoad($param);

		$this->getShelf();

		if (!$this->getPage()->getIsPostBack())
			$this->resetDataSource();
	}

	public function setShelf($shelf)
	{
		$this->_shelf = $shelf;
		$this->setViewState("shelf", $shelf, null);
	}

	public function getShelf()
	{
		$this->_shelf = $this->getViewState("shelf", null);
		
		return $this->_shelf;
	}

	public function resetChecked($state = false)
	{
		$this->setChecked(array('all' => $state));
	}

	public function setChecked($checked = null)
	{
		$this->_checked = $checked;
		$this->getApplication()->getSession()->add($this->_checkedSessionName, $checked);
	}

	public function getChecked()
	{
		$this->_checked = $this->getApplication()->getSession()->itemAt($this->_checkedSessionName);
		
		return $this->_checked;
	}

	public function resetOnlySelected($value = false)
	{
		$this->setOnlySelected($value);
	}

	public function setOnlySelected($flag = false)
	{
		if ($flag === 'false')
			$flag = false;
		
		if ($flag === 'true')
			$flag = true;

		$this->getApplication()->getSession()->add($this->_onlySelectedSessionName, $flag, false);
	}

	public function getOnlySelected()
	{
		$flag = $this->getApplication()->getSession()->itemAt($this->_onlySelectedSessionName);
		
		return $flag;
	}

	public function resetUpdateEmptyFlagFunctionName()
	{
		$this->setUpdateEmptyFlagFunctionName('');
	}

	public function setUpdateEmptyFlagFunctionName($name = '')
	{
		$this->setViewState('UpdateEmptyFlagFunctionName', $name, '');
	}

	public function getUpdateEmptyFlagFunctionName()
	{
		return $this->getViewState('UpdateEmptyFlagFunctionName', '');
	}

	public function resetDataSource()
	{
		$this->DeletedPanel->setCssClass("panel_off");
		$this->resetChecked();
		$this->resetOnlySelected();
		$this->_datasource = array();
		$this->getApplication()->getSession()->add($this->_datasourceSessionName, $this->_datasource);
		$this->populate();
	}

	public function getDatasource()
	{
		if (is_null($this->_datasource))
			$this->_datasource = $this->getApplication()->getSession()->itemAt($this->_datasourceSessionName);
		
		return $this->_datasource;
	}

	/**
	 * Cleans the search textboxes and re-populates.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onClearSearch()
	{
		$this->searchCancel(null, null);
	}

	public function removeItems($param = array())
	{
		$removedCount = 0;

		foreach ($param as $packed)
		{
			try
			{
				if (ShelfItemPeer::deleteByPackedPK($packed))
				{
					$removedCount++;

					if (array_key_exists($packed, $this->_checked))
						unset ($this->_checked[$packed]);
				}
			}
			catch (Exception $ex)
			{
				// dummy
			}
		}
		
		// we need this for updating the list displayed to user
		$this->globalRefresh();
		
		return $removedCount;
	}

	public function moveItems($shelfItemsPacked = array(), $destShelfId = null, $objectClassFilter = null)
	{
		$destShelfId = intval($destShelfId);
		$movedCount = 0;

		if ($destShelfId > 0)
		{
			foreach ($shelfItemsPacked as $shelfItemPacked)
			{
				// convert a real shelf_item into packed version
				if ($shelfItemPacked instanceof ShelfItem)
					$shelfItemPacked = $shelfItemPacked->getPackedPK();

				list ($oldShelfId, $oldObjectId, $oldObjectClass) = ShelfItemPeer::explodePackedPK($shelfItemPacked);
		
				if (!isset($objectClassFilter)
						|| (isset($objectClassFilter)
								&& ($oldObjectClass == $objectClassFilter)))
				{	
					try
					{
						if (ShelfPeer::addItemToShelf($destShelfId, $oldObjectClass, $oldObjectId) > 0)
						{
							if (ShelfItemPeer::deleteByPackedPK($shelfItemPacked))
							{
								$movedCount++;

								if (array_key_exists($shelfItemPacked, $this->_checked))
									unset ($this->_checked[$shelfItemPacked]);
							}
						}
					}
					catch (Exception $ex)
					{
						//var_dump($ex->getMessage());die;
					}
				}
			}

			if ($movedCount > 0)
				$this->globalRefresh();
		}
		
		return $movedCount;
	}

	public function getCheckedItems($force = false)
	{
		$results = array();
		$checked = $this->getChecked();
		$masterChecked = $checked['all'];
		unset($checked['all']);
		$checkedIds = array_keys($checked);
		$output = array();

		if (!$masterChecked)
		{
			foreach ($checkedIds as $packedId)
				$output[] = ShelfItemPeer::retrieveByPackedPK($packedId);
		}
		else		 // caso del mastercheck inverso
		{
			$this->_shelf = $this->getShelf();
			$shelfId = $this->_shelf->getShelfId();
			$searchString = $this->ShelfItemSearch->getSafeText();

			$queryWhereString = "";
			if (count($checkedIds) > 0)
			{
				$queryWhereArray = array();
				foreach ($checkedIds as $packedField)
				{
					list($shelfId, $objectId, $objectClass) = ShelfItemPeer::explodePackedPK($packedField);
					$queryWhereArray[] = "(" . ShelfItemPeer::SHELF_ID . " != $shelfId OR " . ShelfItemPeer::OBJECT_ID . " != $objectId OR " . ShelfItemPeer::OBJECT_CLASS . " != '$objectClass')";
				}

				$queryWhereString = implode(' AND ', $queryWhereArray);
			}

			$searchSubQuery = $searchString != '' ? "(" . ShelfPeer::SHELF_DESCRIPTION . " LIKE '%" . $searchString . "%') AND " : "";
			$subQuery = $searchSubQuery . $queryWhereString;
			$baseWhere = "WHERE (" . ShelfPeer::SHELF_ID . " = $shelfId)";
			if ($subQuery != '')
				$subQuery = " AND " . $subQuery;

			$query = "SELECT * FROM " . ShelfItemPeer::TABLE_NAME . " JOIN " . ShelfPeer::TABLE_NAME . " ON " . ShelfPeer::SHELF_ID . " = " . ShelfItemPeer::SHELF_ID . " " . $baseWhere . $subQuery . ";";

			$connection = Propel::getConnection();
			$pdo = $connection->prepare($query);
			$pdo->execute();

			$output = ShelfItemPeer::populateObjects($pdo);
		}

		if ((count($output) == 0) 
				&& ($force == true))
		{
			$this->setMasterChecked(true);
			$output = $this->getCheckedItems();
		}

		return $output;
	}

	public function getCheckedItemsIds($force = false)
	{
		$results = array();
		$checked = $this->getChecked();
		$masterChecked = $checked['all'];
		unset($checked['all']);
		$checkedIds = array_keys($checked);
		$output = array();

		if (!$masterChecked)
		{
			foreach ($checkedIds as $packedField)
				$output[] = ShelfItemPeer::explodePackedPK($packedField);
		}
		else		 // caso del mastercheck inverso
		{
			$this->_shelf = $this->getShelf();
			$shelfId = $this->_shelf->getShelfId();
			$searchString = $this->ShelfItemSearch->getSafeText();
			$queryWhereString = "";
			
			if (count($checkedIds) > 0)
			{
				$queryWhereArray = array();
				foreach ($checkedIds as $packedField)
				{
					list($shelfId, $objectId, $objectClass) = ShelfItemPeer::explodePackedPK($packedField);
					$queryWhereArray[] = "(" . ShelfItemPeer::SHELF_ID . " != $shelfId OR " . ShelfItemPeer::OBJECT_ID . " != $objectId OR " . ShelfItemPeer::OBJECT_CLASS . " != '$objectClass')";
				}

				$queryWhereString = implode(' AND ', $queryWhereArray);
			}

			$searchSubQuery = ($searchString != '' ? "(" . ShelfPeer::SHELF_DESCRIPTION . " LIKE '%" . $searchString . "%') AND " : "");
			$subQuery = $searchSubQuery . $queryWhereString;
			$baseWhere = "WHERE (" . ShelfPeer::SHELF_ID . " = $shelfId)";

			if ($subQuery != '')
				$subQuery = " AND " . $subQuery;

			$query = "SELECT * FROM " . ShelfItemPeer::TABLE_NAME . " JOIN " . ShelfPeer::TABLE_NAME . " ON " . ShelfPeer::SHELF_ID . " = " . ShelfItemPeer::SHELF_ID . " " . $baseWhere . $subQuery . ";";

			$connection = Propel::getConnection();
			$pdo = $connection->prepare($query);
			$pdo->execute();

			while ($fetch = $pdo->fetch())
				$output[] = array((int) $fetch['shelf_id'], (int) $fetch['object_id'], (string) $fetch['object_class']);
		}

		if ((count($output) == 0) && ($force == true))
		{
			$this->setMasterChecked(true);
			$output = $this->getCheckedItemsIds();
		}

		return $output;
	}

	public function getCheckedObjectsIds($force = false)
	{
		$checkedItems = $this->getCheckedItems($force);
		$ids = array();
		foreach ($checkedItems as $shelfItem)
		{
			$id = $shelfItem->getObjectId();
			
			if (!($id > 0))
				continue;
			
			$ids[] = $id;
		}
		return $ids;
	}

	public function countCheckedItems($force = false)
	{
		$results = array();
		$checked = $this->getChecked();
		
		if (is_null($checked))
			return 0;

		$masterChecked = $checked['all'];
		unset($checked['all']);
		$checkedIds = array_keys($checked);
		$count = 0;

		if (!$masterChecked)
		{
			$count = count($checkedIds);
		}
		else		 // caso del mastercheck inverso
		{
			$this->_shelf = $this->getShelf();
			$shelfId = $this->_shelf->getShelfId();
			$searchString = $this->ShelfItemSearch->getSafeText();
			$queryWhereString = "";

			if (count($checkedIds) > 0)
			{
				$queryWhereArray = array();
				foreach ($checkedIds as $packedField)
				{
					list($shelfId, $objectId, $objectClass) = ShelfItemPeer::explodePackedPK($packedField);
					$queryWhereArray[] = " NOT(" . ShelfItemPeer::SHELF_ID . " = $shelfId AND " . ShelfItemPeer::OBJECT_ID . " = $objectId AND " . ShelfItemPeer::OBJECT_CLASS . " = '$objectClass')";
				}

				$queryWhereString = implode(' AND ', $queryWhereArray);
			}
			
			$searchSubQuery = $searchString != '' ? "(" . ShelfPeer::SHELF_DESCRIPTION . " LIKE '%" . $searchString . "%') AND " : "";
			$subQuery = $searchSubQuery . $queryWhereString;
			$baseWhere = "WHERE (" . ShelfPeer::SHELF_ID . " = $shelfId)";
			
			if ($subQuery != '')
				$subQuery = " AND " . $subQuery;

			$query = "SELECT COUNT(*) FROM " . ShelfItemPeer::TABLE_NAME . " JOIN " . ShelfPeer::TABLE_NAME . " ON " . ShelfPeer::SHELF_ID . " = " . ShelfItemPeer::SHELF_ID . " " . $baseWhere . $subQuery . ";";
			$connection = Propel::getConnection();
			$pdo = $connection->prepare($query);
			$pdo->execute();
			$count = intval($pdo->fetchColumn(0));
		}

		if (($count == 0) 
				&& ($force == true))
		{
			$this->setMasterChecked(true);
			$count = $this->countCheckedItems();
		}
		
		return $count;
	}

	public function getMasterChecked()
	{
		$checked = $this->getChecked();
		
		return $checked['all'];
	}

	public function onOnlySelected($sender, $param)
	{
		$checked = $sender->getChecked();
		$this->setOnlySelected($checked);

		$this->ShelfItemGrid->resetPagination();
		$this->populate();
	}

	public function populate($givenItemShelf = null)
	{
		$this->getPage()->cleanMessageQueue();
		$nullObjects = [];

		$pageSize = $this->ShelfItemGrid->getPageSize();
		$currentIndexPage = $this->ShelfItemGrid->getCurrentPage();
		$searchString = $this->ShelfItemSearch->getSafeText();

		$itemShelves = array();
		$recCount = 0;

		if ($this->getOnlySelected())
			$givenItemShelf = $this->getCheckedItems();

		if (!is_null($givenItemShelf))
		{
			$itemShelves = $givenItemShelf;
			$recCount = count($itemShelves);
		}
		else
		{
			$crit = null;

			if ($searchString !== '')
			{
				$crit = new Criteria();
				$crit->add(ShelfPeer::SHELF_NAME, $searchString . "%", Criteria::LIKE);
			}

			$itemShelves = $this->_shelf->extractItemShelves($currentIndexPage, $pageSize, $crit);   //$searchString);
			$recCount = $this->_shelf->countItemShelves($crit);  //$searchString);
		}

		//$this->ShelfItemGrid->setVirtualItemCount($recCount);
		$data = array();

		if (count($itemShelves) > 0)
		{
			$formId = $this->getPage()->getForm()->getClientId();
				
			foreach ($itemShelves as $itemShelf)
			{
				$row = array();
				$shelfItemPK = $itemShelf->getPackedPK();

				if (isset($this->_checked[$shelfItemPK]))
				{
					$checked = $this->_checked[$shelfItemPK];
				}
				else
				{
					$checked = false;
				}

				if ($this->_checked['all'])
					$checked = !$checked;

				$row['Checked'] = $checked;
				$row['Name'] = $itemShelf->getName();
				$row['ObjectClass'] = $itemShelf->getTypeName();
				$row['ObjectId'] = $itemShelf->getObjectId();

				//$description = $itemShelf->getDescription();
				//$myUser = $this->getUser();
				//$myRoles = $this->getUser()->getRoles();

				$id = $itemShelf->getObjectId();
				$row['Id'] = $id;

				$object = null;
				$peerClass = null;
				$peerClass = $itemShelf->getObjectPeerClass();

				$description = '';
				$seeUrl = '';
				$object = null;

				if (!is_null($peerClass))
					$object = $peerClass->retrieveByPk($id);

				$descriptionLabel = '';
				$descriptionText = '';

				if (!is_null($object))
				{
					$descriptionLabel = $object->getShelfDescriptionLabel();
					$descriptionText = $object->getShelfDescriptionText();
					$shelfUrl = $object->getShelfUrl();

					// we want a descriptive popup in the case the object is a request
					if (get_class($object)== "ItemRequest")
					{
						$popupCode = '(<a target="_self" href="javascript:void(0)" onclick="openIframe(\'Circulation.ViewReservationPopup\',null,null,\''
										. $formId . '\',null,null,null,null,\'' . $id . '\',\'Item\'); return false;">' . Prado::localize('vedi') . '</a>)';

						$descriptionLabel .= "&nbsp;" . $popupCode;
					}

					if ($shelfUrl !== '')
					{
						$shelfObjectId = $id;
						if (method_exists($object, 'getShelfObjectId'))
						{
							$objectId = intval($object->getShelfObjectId());
							if ($objectId > 0)
								$shelfObjectId = $objectId;
						}

						$seeUrl = 'index.php?page=' . $shelfUrl . $shelfObjectId;
					}
				}
				else
				{
					$itemShelf->delete();
					$recCount--;
					$nullObjects[] = array(	'type' => $row['ObjectClass'],
											'id' => $row['ObjectId'] );

					continue;
				}

				$row['DescriptionText'] = $descriptionText;
				$row['DescriptionLabel'] = $descriptionLabel;
				$row['SeeUrl'] = $seeUrl;
				$row['shelfItemPK'] = $shelfItemPK;

				$data[] = $row;
			}
		}

		$this->ShelfItemGrid->setVirtualItemCount($recCount);	// moved here
		$this->setChecked($this->_checked);
		$this->_datasource = $data;
		$this->getApplication()->getSession()->add($this->_datasourceSessionName, $this->_datasource);

		$this->ShelfItemGrid->setDataSource($data);
		$this->ShelfItemGrid->dataBind();

		if (!$this->getOnlySelected())
			$this->FoundNumber->setText($recCount);

//		if (count($nullObjects) > 0)
//		{
//			$this->getPage()->flushDelayedMessage();
//			$this->getPage()->reloadPage();
//		}
		if (count($nullObjects) > 0)
		{
			$this->DeletedPanel->setCssClass("panel_on_inline");
			
			$this->DeletedWidget->setText(Prado::localize("{count} rimossi",
																array('count' => count($nullObjects))));
			
			$this->DeletedWidget->setNavigateUrl(null);
			
			$OLArray = [];
			
			foreach ($nullObjects as $nullObjectRow)
			{
				$OLArray[] = Prado::localize("tipo elemento: {type}, id: {id}",
												array(	'type' => $nullObjectRow['type'],
														'id' => $nullObjectRow['id'] ));
			}
			
			$this->DeletedWidget->setOLText(implode('<br />', $OLArray));
		}
		else
		{
			$this->DeletedPanel->setCssClass("panel_off");
		}
	}

	/**
	 * Resets pagination in case of search by text string.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onSearchItemShelf($sender, $param)
	{
		$this->ShelfItemGrid->resetPagination();
		$this->getPage()->globalRefresh();
	}

	/**
	 * Synonyme of searchCancel().
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onCancel($sender, $param)
	{
		$this->searchCancel($sender, $param);
	}

	/**
	 * It resets pagination and textbox fields in case
	 * of cancelling of search operation.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function searchCancel($sender, $param)
	{
		$this->ShelfItemGrid->resetPagination();

		$this->clearFilters();
		$this->onSearchItemShelf(null, null);
	}

	public function clearFilters()
	{
		$this->ShelfItemSearch->Text = '';
	}

	/**
	 * It manages the change of page in the datagrid.
	 * It uses the viewstate to store the current page.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function changePage($sender, $param)
	{
		$this->ShelfItemGrid->setCurrentPage($param->NewPageIndex);
		$this->populate();
	}

	/**
	 * Returns whether the page permits that in this component
	 * we can have the functions that components inside popups have.
	 *
	 * @return boolean
	 */
	public function getPopupFlag()
	{
		$pageIsPopup = $this->getPage()->IsPopup();
		$this->ActionsColumn->setVisible($pageIsPopup);

		return $pageIsPopup;
	}

	/**
	 * Returns whether the page permits that in this component
	 * we can have the unlink function.
	 *
	 * @return boolean
	 */
	public function getUnlinkFlag()
	{
		return $this->getPage()->IsUnlink();
	}

	/**
	 * It takes the parameters passed both by the component's
	 * callback and calls the relative method in the page which
	 * unlinks an object (gives its type and its id).
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onUnlink($sender, $param)
	{
		$valueArray = $param->CommandParameter;
		$objectId = $valueArray['objectId'];
		$objectClass = $valueArray['objectClass'];
		$this->GetPage()->unlinkShelfItem($objectId, $objectClass);
	}

	public function onFlipChecked($sender, $param)
	{
		$newChecked = $sender->getChecked();
		$index = $sender->Parent->Parent->ItemIndex;
		$dataSource = $this->getDatasource();
		$checked = $this->getChecked();

		$row = $dataSource[$index];
		$shelfItemPK = $row['shelfItemPK'];

		if ($newChecked != $checked['all'])
		{
			$checked[$shelfItemPK] = true;
		}
		else
		{
			unset($checked[$shelfItemPK]);
		}

		$this->setChecked($checked);
		$this->updateEmptyFlag($param);
	}

	public function onMasterChecked($sender, $param)
	{
		$this->setMasterChecked($sender->getChecked(), $param);
	}

	public function setMasterChecked($newChecked = false, $param = null)
	{
		$this->resetChecked($newChecked);

		$gridItems = $this->ShelfItemGrid->getItems();
		$header = $this->ShelfItemGrid->getHeader();

		foreach ($gridItems as $item)
			$item->CheckColumn->CheckedBox->setChecked($newChecked);

		if (!is_null($header))
			$header->CheckColumn->MasterCheck->setChecked($newChecked);
		
		$this->updateEmptyFlag($param);
	}

	public function updateEmptyFlag($param = null)
	{
		$this->SelectedNumber->setText(intval($this->countCheckedItems()));
		if ($this->getPage()->getIsCallBack())
		{
			if (is_null($param))
			{
				$this->SelectedPanel->render($this->getPage()->createWriter());
			}
			else
			{
				$this->SelectedPanel->render($param->getNewWriter());
			}
		}

		$functionName = TPropertyValue::ensureString($this->getUpdateEmptyFlagFunctionName());
		
		if ($functionName != '')
			$this->getPage()->$functionName();
	}

	public function globalRefresh()
	{
		$this->populate();
		$this->updateEmptyFlag();
	}
	
}