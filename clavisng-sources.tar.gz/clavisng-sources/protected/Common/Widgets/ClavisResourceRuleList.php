<?php

/**
 * ClavisInventorySerieList class file
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 */

/**
 * ClavisResourceRuleList Class
 *
 * @author Cristian Chiarello <cristian@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2015 Comperio srl
 * @package Widgets
 */

class ClavisResourceRuleList extends TTemplateControl
{

	public function onLoad($param)
	{
		parent::onLoad($param);
		//First time page is loaded
		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallBack()) {

			$this->populate();
		}
	}
	
	
	
	
	public function setResourceIP( $rip )
	{
		$this->setControlState('resourceip', $rip);
	}
	
	public function getResourceIP()
	{
		$rip = $this->getControlState( 'resourceip' );
		if(is_null($rip) || $rip == '')
			$rip = NULL;
		return $rip;
	}
	
	
	
	
	/*
	 * Set if you want to filter by patron id
	 */
	public function setFilterByPatron( $owned )
	{
		$this->setControlState('filterbyowner', $owned);
	}
	
	public function getFilterByPatron()
	{
		$fbo = $this->getControlState( 'filterbyowner' );
		if(is_null($fbo) || $fbo == '')
			$fbo = NULL;
		return $fbo;
	}
	
	
	
	/*
	 * Set it if you want to filter by rule type
	 */
	public function setFilterByType( $status )
	{
		$this->setControlState('filterbytype', $status);
	}
	
	public function getFilterByType()
	{
		$fbt = $this->getControlState( 'filterbytype' );
		if(is_null($fbt) || $fbt == '')
			$fbt = NULL;
		return $fbt;
	}
	
	
	/*
	 * Set it to true if you want to show expired rules
	 */
	public function setShowExpired( $status )
	{
		$this->setControlState('showexpired', $status);
	}
	
	public function getShowExpired()
	{
		$showexp = $this->getControlState( 'showexpired' );
		if(is_null($showexp) || $showexp !== TRUE || $showexp !== FALSE)
			$showexp = NULL;
		return $showexp;
	}
	
	

	

	public function changePage($sender,$param) {
		$this->ResourceRuleGrid->setCurrentPage($param->NewPageIndex);

		$this->populate();
	}

	public function getPopupFlag()
	{
		return $this->getPage()->IsPopup();
	}

	public function getUnlinkFlag()
	{
		return $this->getPage()->IsUnlink();
	}

	public function globalRefresh()
	{
		$this->populate();
	}
	
	
	
	public function populate()
	{

		$pageSize = $this->ResourceRuleGrid->getPageSize();
		$currentIndexPage = $this->ResourceRuleGrid->getCurrentPage();
				
		$libid = $this->getUser()->getActualLibraryId();
		$rc = ResourceRuleQuery::create()->filterByLibraryId($libid);
		
			
		$resip = $this->getResourceIP();
		if(!is_null( $resip ))
			$rc->filterByResourceOwner($resip);
		
		
		$fbt = $this->getFilterByType();
		if( !is_null( $fbt ) && array_key_exists($fbt, ResourceRule::getRuleTypes( Resource::TYPE_GENERIC)) )
		{
			$rc->filterByType($fbt);
		}
		
		
		$fbo = $this->getFilterByPatron();
		if(!is_null( $fbo ))
		{
			$rc->filterByPatronId($fbo);
		}
		else
		{
			$rc->where(' patron_id IS NULL');
		}
		
		$showexp = $this->getShowExpired();
		if( is_null( $showexp ) || (!is_null( $showexp ) && $showexp==FALSE))
		{
			$rc->where(' ((validity_start IS NULL AND validity_end IS NULL) OR (NOW() BETWEEN validity_start AND validity_end)) ');
		}
		
		$recCount = $rc->count();
		$rc->orderByResourcePattern()
            ->limit( $pageSize )
			->offset( $currentIndexPage * $pageSize);
		
		//Prado::log(__METHOD__ . " query is " . $rc->toString());

		$rules = $rc->find();
		
		$datasource = array();

		foreach ($rules as $rule)
		{
			
			
			$ruleId = $rule->getResourceRuleId();

			
			/*
			$libraryId = $resource->getLibraryId();
			
			$libraryLabel='---';
			$lib = LibraryQuery::create()
				->findOneByLibraryId($libraryId);
			if( $lib instanceof Library) $libraryLabel = $lib->getLabel ( );*/
			

			$type_key = $rule->getType();
			if( is_null( $type_key ))
			{
				$type = '---';
			}
			elseif ( $type_key == ResourceRule::TYPE_CREDIT )
			{
				$type = 'Crediti a scalare';
			}
			else
			{
				$type = LookupValuePeer::getLookupValue('RESOURCE_RULE_TYPE', $type_key);
			}
			
			$priority = $rule->getPriority();
			if( is_null( $priority ))
				$priority = '---';
			
			$ip = $rule->getResourceOwner();
			$resOwn = '---';
			if( $ip == '.' )
			{
				$resOwn = 'tutte';
			}
			else
			{
				$resource = ResourceQuery::create()
						->filterByName($ip)
						->findOne();
				if( $resource instanceof Resource)
				{
					$resOwn = $resource->getShortName();
				}
			}
			
			$resid = $rule->getResourcePattern();
			if( is_null( $resid ))
				$resid = '---';
			
			$resname = '---';
			$resource = ResourceQuery::create()->findOneByResourceId($resid);
			if( $resource instanceof Resource) $resname = $resource->getName ( );
				
			
			
			$patronid = $rule->getPatronId();
			if( is_null( $patronid ))
				$patronid = '---';
			
			
			$username='---';
			$patron = PatronQuery::create()
				->findOneByPatronId($patronid);
			if( $patron instanceof Patron) $username = $patron->getOpacUsername();
			
			
			$fUsed = round($rule->getUsed(), 2);
			if( is_null( $fUsed ))
			{
				$used = '---';
			}
			else
			{
				$used = $fUsed;
			}
			
			
			$amount = '';
			$fAmount = round($rule->getAmount(),2);
			if( is_null( $fAmount ))
			{
				$amount = '---';
			}
			else
			{
				if( $type_key == 'CREDIT' )
				{
					$rim = $fAmount - $fUsed;
					//not show exhausted credit
					if( $rim == 0 )
					{
						continue;
					}
					else
					{
						$amount = $fAmount . " ({$rim} ".Prado::localize("rimanenti").")";
					}
				}
				else
				{
					$amount = $fAmount;
				}
			}
					
			$valStart = $rule->getValidityStart();
			
			$valEnd = $rule->getValidityEnd();
			
			$note = $rule->getNote();
			if( is_null( $note ))
				$note = '---';
			

			$canEdit = TRUE;
			$canEdit = $this->getUser()->getEditPermission( $rule ); //Correct?
			
			if(	$type_key == ResourceRule::TYPE_CREDIT )
			{
				$canEdit = FALSE;
			}
			

			$datasource[] = array(
				'id' => $ruleId,
				'type' => $type,
				'priority' => $priority,
				'resourceOwner' => $resOwn,
				'resourcePattern' => $resid,
				'resourceName' => $resname,
				'patronId' => $patronid,
				'username' => $username,
				'amount' => $amount,
				'used' => $used,
				'validityStart' => $valStart,
				'validityEnd' => $valEnd,
				'note' => $note,
				'canEdit' => $canEdit
			);
		}

		$this->ResourceRuleGrid->setVirtualItemCount($recCount);
		$this->RecCounter->setText(Prado::localize("Record totali: {recCount}", array('recCount' => $recCount)));

		$this->ResourceRuleGrid->setDataSource($datasource);
		$this->ResourceRuleGrid->dataBind();
		
	}

	public function onDelete($sender, $param) {
		//$pk = unserialize($param->getCommandParameter());
		$pk = $param->getCommandParameter();
		//Prado::log($pk);
		$rr = ResourceRuleQuery::create()->findPk($pk);
		if ($rr instanceof ResourceRule)
		{
			try {
				$rr->delete();
				$this->getPage()->writeMessage(Prado::localize("Regola cancellata correttamente."),ClavisMessage::CONFIRM);
			} catch (Exception $e) {
				$this->getPage()->writeMessage(Prado::localize("La regola non è stata cancellata a causa dell'errore: {error}",
					array('error' => $e->getMessage())),ClavisMessage::ERROR);
			}
		}
		$this->populate();
	}

	
}
