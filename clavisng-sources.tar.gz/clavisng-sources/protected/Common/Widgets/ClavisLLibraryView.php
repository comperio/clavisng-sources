<?php

/**
 * ClavisLLibraryView
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.e-portaltech.it/
 * @copyright Copyright &copy; 2012 Comperio SRL
 * @version 2.7
 * @package Widgets
 * @since 2.1
 */

class ClavisLLibraryView extends TTemplateControl 
{ 
	public function onInit($param)
	{
		parent::onInit($param);

		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallback())
		{
			$this->DistanceFilter->setDataSource(LLibraryPeer::calculateLLibraryDistanceHash());
			$this->DistanceFilter->dataBind();
			
			$this->ToLibraryFilter->setDataSource($allLibraries = LibraryPeer::getLibrariesHashWithBlank(	null, 
																											null, 
																											true ));
			$this->ToLibraryFilter->dataBind();
		}
	}

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallback())
		{
			if ($this->getAutomaticPopulate())
				$this->populate();
			else
				$this->NoResultPanel->setCssClass("panel_off");
		}
	}

	public function setAutomaticPopulate($flag = true)
	{
		if ($flag === "true")
			$flag = true;
		elseif ($flag === "false")
			$flag = false;
		
		$this->setViewState("automaticPopulate", $flag, true);
	}

	public function getAutomaticPopulate()
	{
		return $this->getViewState("automaticPopulate", true);
	}
	
	public function setFromLibraryId($id = null)
	{
		$id = intval($id);
		$this->setControlState("FromLibraryId", $id, null);
	}

	public function getFromLibraryId()
	{
		return $this->getControlState("FromLibraryId", null);
	}

	public function populate()
	{
		$fromLibraryId = intval($this->getFromLibraryId());
		if (is_null($fromLibraryId))
			return false;

		if ($this->DistanceFilter->getSelectedIndex() > 0)
			$distanceFilter = $this->DistanceFilter->getSelectedValue();
		else
			$distanceFilter = null;

		if ($this->ToLibraryFilter->getSelectedIndex() > 0)
			$toLibraryIdFilter = $this->ToLibraryFilter->getSelectedValue();
		else
			$toLibraryIdFilter = null;

		$data = array();
		foreach (LibraryPeer::getDistanceHash(	$fromLibraryId,
												$distanceFilter,
												$toLibraryIdFilter ) as $distance => $rowString)
		{
			$actualLibraryId = intval($this->getFromLibraryId());
			$myLibraryId = $this->getUser()->getActualLibraryId();
			$row = array();
			$librariesCombo = "";

			foreach (explode(',', $rowString) as $libraryIdCycle)
			{
				if (intval($libraryIdCycle) > 0)
				{
					if ($actualLibraryId == $libraryIdCycle)
					{
						$librariesCombo .= '<span>[' . Prado::localize("biblioteca attuale") . ']</span>&nbsp;/&nbsp;';
					}
					else
					{
						$libraryLabel = LibraryQuery::create()
											->select(array('Label'))
											->filterByLibraryId($libraryIdCycle)
											->findOne();

						if ($libraryLabel == '')
							$libraryLabel = "(" . Prado::localize("senza nome") . ")";

						$librariesCombo .= 	'<a ' . ($libraryIdCycle == $myLibraryId ? ' class="evidenced_light"' : '') . ' href="index.php?page=Library.LibraryViewPage&id=' . $libraryIdCycle . '">'
												
												. $libraryLabel 
												
												. '</a>&nbsp;/&nbsp;';
												//. ($libraryIdCycle == $myLibraryId ? '</span>' : '');
					}
				}
			}
			
			if ($librariesCombo != "")
				$librariesCombo = rtrim($librariesCombo, '&nbsp;/&nbsp;');
			$row['LibrariesCombo'] = $librariesCombo;
		
			$row['Distance'] = ItemRequestPeer::getCompleteMaxDistance($distance);
			$data[] = $row;
		}	
		
		if (count($data) == 0)
			$this->NoResultPanel->setCssClass('panel_on');		// no results
		else
			$this->NoResultPanel->setCssClass('panel_off');		// we have results

		$this->writeResults($data);
	}
	
	private function writeResults($data = array())
	{
		$this->Grid->setDataSource($data);
		$this->Grid->dataBind();
	}
	
	public function onSearch($sender, $param) 
	{
		$this->Grid->SetCurrentPage(0);
		$this->populate();
	}

	public function onCancel()
	{
		$this->searchCancel(null, null);
	}

	public function searchCancel($sender, $param)
	{
		$this->DistanceFilter->setSelectedIndex(-1);
		$this->ToLibraryFilter->setSelectedIndex(-1);
		
		$this->populate();
	}

	public function getPopupFlag()
	{
		return $this->getPage()->IsPopup();
	}

	public function getUnlinkFlag()
	{
		return $this->getPage()->IsUnlink();
	}

	public function onColorize($sender, $param)
	{
		$item = $param->Item;
    	$itemIndex = $item->ItemIndex;

		if (($item->getItemType() != "Item") && ($item->getItemType() != "AlternatingItem"))
			return false;
		
		$distance = $item->DataItem['Distance'];
    	if ($distance == 1)
    		$item->setCssClass('bordered');
	}
	
}
