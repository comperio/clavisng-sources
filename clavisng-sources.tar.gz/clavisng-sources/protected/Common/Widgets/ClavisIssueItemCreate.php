<?php
/**
 * ClavisIssueItemCreate
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2009 Comperio srl
 * @version 2.7
 * @package Widgets
 * @since 2.2
 */
class ClavisIssueItemCreate extends TTemplateControl
{
	/**
	 * @var Manifestation
	 */
	private $_manifestation = null;

	public function onLoad($param)
	{
		parent::onLoad($param);
		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallback())
		{
			$this->getManifestation();
			$this->populate();
			$this->IssueStatus->setSelectedValue(ItemPeer::ISSUESTATUS_EXPECTED);
			$this->LoanClass->setSelectedValue(ItemPeer::LOANCLASS_UNAVAILABLE);
			$this->ItemStatus->setSelectedValue(ItemStatus::ITEMSTATUS_INORDER);
		}
	}

	public function populate()
	{
		if (!$this->_manifestation)
			return;
		$this->populateConsistencyList();
		$this->populateVolumeList();
		$this->populateSerieSection();
		if ($volume = $this->getVolume())
		{
			$this->IssueVolume->setSelectedValue($volume);
			$this->IssueVolume->setEnabled(false);
		}
	}

	public function populateConsistencyList()
	{
		$notes = ConsistencyNoteQuery::create()
				->filterByManifestation($this->_manifestation)
				->filterByLibraryId($this->getUser()->getActualLibraryId())
				->find();
		$ds = array('' => '---');
		foreach ($notes as $cn)
			$ds[$cn->getConsistencyNoteId()] = $cn->getCollocation() . ' / ' . $cn->getTextNote();
		$this->ConsistencyList->setDataSource($ds);
		$this->ConsistencyList->dataBind();
	}

	public function populateVolumeList()
	{
		if (!$this->_manifestation instanceof Manifestation)
		{
			throw new Exception('Manifestation not set.');
		}
		$issueyears = IssueQuery::create()
				->filterByManifestation($this->_manifestation)
				->select('IssueYear')
				->distinct()
				->orderByIssueYear(Criteria::DESC)
				->setFormatter('PropelSimpleArrayFormatter')
				->find();
		$volume_ds = array(0 => '---');
		foreach ($issueyears as $year)
			$volume_ds[$year] = $year;

		$this->IssueVolume->setDataSource($volume_ds);
		$this->IssueVolume->dataBind();
	}

	public function populateSerieSection()
	{
		$lid = $this->getUser()->getActualLibraryId();
		$inv_series = InventorySerieQuery::create()
				->orderByClosed()
				->orderByReadonly()
				->orderByInventorySerieId()
				->findByLibraryId($lid);
		$ds = array(0 => '---');
		foreach ($inv_series as $i)
		{
			$ds[$i->getInventorySerieId()] = $i->getDescription() . ' (' .
					$i->getInventorySerieId() . ')';
		}
		$this->InventorySerieId->setDataSource($ds);
		$this->InventorySerieId->dataBind();
		$this->Section->setLibraryId($lid);
		$this->Section->populateList();
	}

	/**
	 * @param Manifestation $manifestation
	 */
	public function setManifestation(Manifestation $manifestation)
	{
		$this->_manifestation = $manifestation;
		$this->setControlState('Manifestation', $manifestation, null);
	}

	/**
	 * @return Manifestation
	 */
	public function getManifestation()
	{
		if (is_null($this->_manifestation))
		{
			$this->_manifestation = $this->getControlState('Manifestation', null);
		}
		return $this->_manifestation;
	}

	/**
	 * @param Manifestation $manifestation
	 */
	public function setVolume($volume)
	{
		$this->setControlState('Volume', $volume, null);
	}

	/**
	 * @return Manifestation
	 */
	public function getVolume()
	{
		return $this->getControlState('Volume', null);
	}

	/**
	 * @param Subscription $subscription
	 */
	public function setSubscription(Subscription $subscription)
	{
		$this->setControlState('Subscription', $subscription, null);
		$this->setManifestation($subscription->getManifestation());
		$this->setVolume($subscription->getVolume());
	}

	/**
	 * @return Subscription
	 */
	public function getSubscription()
	{
		$sub = $this->getControlState('Subscription', null);
		if ($sub instanceof Subscription)
		{
			$this->setManifestation($sub->getManifestation());
			$this->setVolume($sub->getVolume());
		}
		return $sub;
	}

	public function checkInventoryUnique($sender, $param)
	{
		$invnum = $param->getValue();
		$param->IsValid = ItemPeer::checkInventoryUnique($invnum, $this->InventorySerieId->getSelectedValue());
	}

	public function onGenerateItems($sender, $param)
	{
		if (!$this->getPage()->getIsValid())
			return false;

		$this->getManifestation();
		$lid = $this->getUser()->getActualLibraryId();
		$volume = $this->IssueVolume->getSelectedValue();
		$invSerie = $this->InventorySerieId->getSelectedValue();
		$invNumber = $this->InventoryNumber->getSafeText();
		$section = $this->Section->getSelectedValue();
		$collocation = $this->Collocation->getSafeText();
		$seq1 = $this->Sequence1->getSafeText();
		$seq2 = $this->Sequence2->getSafeText();
		$spec = $this->Specification->getSafeText();
		$issueStatus = $this->IssueStatus->getSelectedValue();
		$loanClass = $this->LoanClass->getSelectedValue();
		$itemStatus = $this->ItemStatus->getSelectedValue();
		$itemMedia = $this->ItemMedia->getSelectedValue();

		if (ItemPeer::isInventoryDuplicated($invSerie, $invNumber, $lid))
		{
			if ($this->getPage()->IsPopup())
				$this->getPage()->appendDelayedMessage(Prado::localize('Il numero di inventario è già assegnato'), ClavisMessage::ERROR);
			else
				$this->getPage()->enqueueMessage(Prado::localize('Il numero di inventario è già assegnato'), ClavisMessage::ERROR);
			$this->populateSerieSection();
			return;
		}
		try
		{
			$retValue = $this->generateItemsFromVolume($this->_manifestation, $volume, $invSerie, $invNumber, time(), $collocation, $section, $seq1, $seq2, $spec, $issueStatus, $loanClass, $itemStatus, $itemMedia);
			ChangelogPeer::logAction($this->_manifestation, ChangelogPeer::LOG_UPDATE, $this->getUser(), "Creati {$retValue} esemplari da fascicoli dell'annata {$volume} - biblioteca {$lid}");
			if ($this->getPage()->IsPopup())
				$this->getPage()->appendDelayedMessage(Prado::localize('Sono stati creati {new_items} esemplari da fascicoli ' .
								'della notizia con id: {manifestation_id} e volume {volume_id}', array('new_items'			 => $retValue, 'manifestation_id'	 => $this->_manifestation->getManifestationId(),
							'volume_id'			 => $volume)), ClavisMessage::INFO);
			else
				$this->getPage()->enqueueMessage(Prado::localize('Sono stati creati {new_items} esemplari da fascicoli ' .
								'della notizia con id: {manifestation_id} e volume {volume_id}', array('new_items'			 => $retValue, 'manifestation_id'	 => $this->_manifestation->getManifestationId(),
							'volume_id'			 => $volume)), ClavisMessage::INFO);
		}
		catch (Exception $e)
		{
			if ($this->getPage()->IsPopup())
				$this->getPage()->appendDelayedMessage(Prado::localize('Errore nella creazione degli esemplari dai fascicoli: {error}', array('error' => $e->getMessage())), ClavisMessage::ERROR);
			else
				$this->getPage()->enqueueMessage(Prado::localize('Errore nella creazione degli esemplari dai fascicoli: {error}', array('error' => $e->getMessage())), ClavisMessage::ERROR);
		}
		$this->getPage()->flushDelayedMessage();
		$this->getPage()->getClientScript()->registerEndScript(__CLASS__ . '_js', 'onReturn(\'reload\',\'reload\',true);');
	}

	protected function onGetInventoryCounterCallback($sender, $param)
	{
		$inventorySerieId = $this->InventorySerieId->getSelectedValue();
		$homeLibraryId = $this->getUser()->getActualLibraryId();
		$invCounter = InventorySeriePeer::calculateNextInventoryCounter($inventorySerieId, $homeLibraryId);
		if ($invCounter != false)
		{
			$this->InventoryNumber->setText($invCounter);
		}
		else
		{
			if ($this->getPage()->IsPopup())
				$this->getPage()->appendDelayedMessage(Prado::localize('Errore nell\'assegnazione automatica del contatore di inventario'), ClavisMessage::ERROR);
			else
				$this->getPage()->enqueueMessage(Prado::localize('Errore nell\'assegnazione automatica del contatore di inventario'), ClavisMessage::ERROR);
		}
	}

	/**
	 * Generates a bunch of items for issues based upon an issue volume.
	 *
	 * @param Manifestation $manifestation The manifestation.
	 * @param string $volume The issue volume
	 * @param int $inventorySerieId The ID for the inventory serie
	 * @param int $inventoryNumber The inventory number. All items will be assigned that number
	 * @param string|DateTime $inventoryDate The inventory date; can be either a string or a DateTime
	 * @param string $collocation
	 * @param string $section
	 * @param string $sequence1
	 * @param string $sequence2
	 * @param string $specification
	 * @param string $issueStatus
	 * @param string $loanClass
	 * @param string $itemStatus
	 * @param string $itemMedia
	 * @return int The number of created items.
	 * @throws Exception if something goes wrong
	 */
	public function generateItemsFromVolume($manifestation, $volume, $inventorySerieId, $inventoryNumber, $inventoryDate, $collocation, $section, $sequence1, $sequence2, $specification, $issueStatus, $loanClass, $itemStatus, $itemMedia)
	{
		$lid = $this->getUser()->getActualLibraryId();
		$subscription = $this->getSubscription();
		$_connection = Propel::getConnection();
		try
		{
			$countCreated = 0;
			$_connection->beginTransaction();

			$manifestation_id = $manifestation->getManifestationId();
			$manifestationTitle = $manifestation->getTitle();
			$manifestationDewey = $manifestation->getClass();
			$subscription = $this->getSubscription();
			$criteria = new Criteria();
			$criteria->add(IssuePeer::MANIFESTATION_ID, $manifestation_id);
			$criteria->add(IssuePeer::ISSUE_YEAR, $volume);
			$issues = IssuePeer::doSelect($criteria);
			$consistency = $this->ConsistencyList->getSelectedValue();

			foreach ($issues as $issue)
			{
				/* @var $issue Issue */
				$item = new Item();
				$item->setManifestationId($manifestation_id);
				$item->setTitle("{$manifestationTitle} (fasc: {$issue->getIssueCombo(false)})");
				$item->setManifestationDewey($manifestationDewey);

				if ($consistency)
					$item->setConsistencyNoteId($consistency);

				$item->setIssueId($issue->getIssueId());
				$item->setIssueArrivalDateExpected($issue->getIssueDate());
				$item->setIssueYear($issue->getIssueYear());
				$item->setIssueNumber($issue->getStartNumber());
				$item->setIssueDescription($issue->getIssueNumber());
				$item->setIssueStatus(ItemPeer::ISSUESTATUS_EXPECTED);
				$item->setItemStatus(ItemStatus::ITEMSTATUS_INORDER);
				$item->setLoanClass(ItemPeer::LOANCLASS_AVAILABLE);
				$item->setLoanStatus(ItemPeer::LOANSTATUS_AVAILABLE);
				$item->setOpacVisible(true);
				$item->setItemSource('B'); // Abbonamento
				$item->setOwnerLibraryId($lid);
				$item->setHomeLibraryId($lid);
				$item->setActualLibraryId($lid);
				$item->setIssueStatus($issueStatus);
				$item->setLoanClass($loanClass);
				$item->setItemStatus($itemStatus);
				$item->setItemMedia($itemMedia);

				if ($subscription instanceof Subscription)
					$item->setSubscriptionId($subscription->getSubscriptionId());

				$item->setInventorySerieId($inventorySerieId);
				$item->setInventoryDate($inventoryDate);
				$item->setInventoryNumber($inventoryNumber);
				$item->setCollocation($collocation);
				if ($section)
					$item->setSection($section);
				$item->setSpecification($specification);
				$item->setSequence1($sequence1);
				$item->setSequence2($sequence2);

				$item->save();

				ChangelogPeer::logAction($item, ChangelogPeer::LOG_CREATE, $this->getUser());
				++$countCreated;
			}
			$_connection->commit();
			return $countCreated;
		}
		catch (PropelException $e)
		{
			$_connection->rollback();
			throw new Exception('Item generation from issues failed: ' . $e->getMessage());
		}
	}
	
}