<?php
/**
 * ClavisSBNActionsItem class file
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 */

/**
 * ClavisSBNActionsItem class
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Widgets
 * @since 2.6
 */
class ClavisSBNActionsItem extends TTemplateControl
{
	/* @var ClavisSBN */
	public $_sbnMod;
	/* @var Item */
	private $_item;

	public function onLoad($param)
	{
		parent::onLoad($param);
		$this->_sbnMod = $this->getApplication()->getModule('sbn');
		if (!$this->_sbnMod instanceof TModule || !$this->_sbnMod->getEnabled())
		{
			$this->SBNNotEnabled->setVisible(true);
			$this->SBNEnabled->setVisible(false);
			return;
		}
		$this->_item = $this->getPage()->getItem();
		$this->populate();
	}

	public function getItem()
	{
		return $this->_item;
	}

	public function getViewMode()
	{
		return $this->getControlState('ViewMode', 'Fieldset');
	}

	public function setViewMode($value)
	{
		$this->setControlState('ViewMode', TPropertyValue::ensureEnum($value, array('Fieldset', 'Inline')));
	}

	public function populate()
	{
		if (!$this->_sbnMod->getEnabled() ||
				!$this->_item instanceof Item ||
				$this->_item->isNew() ||
				!$this->_item->getManifestation() instanceof Manifestation)
		{
			return false;
		}

		switch ($this->getViewMode())
		{
			case 'Inline':
				$this->InlineView->setVisible(true);
				$this->FieldsetView->setVisible(false);
				break;
			case 'Fieldset':
			default:
				$this->InlineView->setVisible(false);
				$this->FieldsetView->setVisible(true);
				break;
		}
		$lst = $this->getSbnStatus();
		switch ($lst)
		{
			case 'unlocalizable':
				// fieldset
				$this->LocalizationData->setVisible(false);
				$this->NewLocalization->setVisible(false);
				$this->NoLocalization->setVisible(true);
				// inline
				$this->SBNBid->setText(Prado::localize('<em>nessuno</em>'));
				$this->SBNLocStatusImg->setImageUrl('themes/Default/icons/nav_plain_red-16.png');
				$this->SBNLocStatus->setText(Prado::localize('esemplare non localizzabile (notizia non collegata all\'indice)'));
				$this->SBNActionLocalize->setVisible(false);
				$this->SBNActionUnlocalize->setVisible(false);
				break;
			case 'localizable':
				// fieldset
				$this->LocalizationData->setVisible(false);
				$this->NewLocalization->setVisible(true);
				//inline
				$this->SBNLocStatus->setText(Prado::localize('esemplare non localizzato per possesso'));
				$this->SBNLocStatusImg->setImageUrl('themes/Default/icons/nav_plain_yellow-16.png');
				$this->SBNActionLocalize->setVisible($this->getUser()->getIsAdmin() ||
						$this->getUser()->isInRole('cataloguer'));
				$this->SBNActionUnlocalize->setVisible(false);
				break;
			default: // date
				// fieldset
				$this->LocalizationData->setVisible(true);
				$this->NewLocalization->setVisible(false);
				$this->LastSbnSyncTime->setValue($lst);
				// inline
				$this->SBNLocStatus->setText(Prado::localize('esemplare localizzato per possesso - <em>ultimo aggiornamento: {date}</em>', array('date' => date('Y-m-d H:i:s', $lst))));
				$this->SBNLocStatusImg->setImageUrl('themes/Default/icons/nav_plain_green-16.png');
				$this->SBNActionLocalize->setVisible(false);
				$this->SBNActionUnlocalize->setVisible($this->getUser()->getIsAdmin()
														|| $this->getUser()->isInRole('cataloguer'));
		}
	}

	/**
	 * Returns SBN status.
	 * Return value can be 'localizable', 'unlocalizable' or a date.
	 *  * 'localizable': the item is localizable.
	 *  * 'unlocalizable': the item is not localizable.
	 *  * date: the manifestation is linked and localized.
	 * @param bool $deep
	 * @return mixed|string
	 */
	public function getSbnStatus($deep = false)
	{
		$lst = $this->_item->getLastSbnSync('U');
		
		if ($lst)
			return $lst;
		
		if (($this->_item->getManifestationId() < 0) 
				|| !($this->_item->getHomeLibrary() instanceof Library)
				|| !$this->_item->getHomeLibrary()->getSbnCode())
			return 'unlocalizable';
		$m = $this->_item->getManifestation();
		$bid = $m->getBid();
		if ($m->getBidSource() == 'SBN' && $bid)
		{
			if (!$deep)
				return 'localizable';
			$sbn_response = $this->_sbnMod->getNewRequest()->searchTitleByBid($bid);
			if ('0000' == $sbn_response->SbnMessage->SbnResponse->SbnResult->esito)
			{
				// check if manifestation is already localized, if so, update LastSbnSync
				return 'localizable';
			}
		}
		return 'unlocalizable';
	}

	public function onSBNLocalize($sender, $param)
	{
		if (!in_array($this->getSbnStatus(true), array('localizable')))
		{
			$this->getPage()->writeMessage(Prado::localize('L\'esemplare non è localizzabile.'), ClavisMessage::ERROR);
			$this->populate();
			return;
		}

		$m = $this->_item->getManifestation();
		$bid = $m->getBid();
		$l = $this->_item->getHomeLibrary();
		$item = array(
			'libName'	 => $l->getLabel(),
//			'libAnagraphicCode'	=> $l->getIllCode(),
			'libSBNCode' => $this->_sbnMod->getLibraryCode($l));
		if (($v = trim($this->NewLocFund->getText())) != '')
			$item['musicObject'] = $v;
		if (($v = trim($this->NewLocCons->getText())) != '')
			$item['consistency'] = $v;
		if (($v = trim($this->NewLocSign->getText())) != '')
			$item['collocation'] = $v;
		if (($v = trim($this->NewLocSignOld->getText())) != '')
			$item['collocationAntique'] = $v;
		if (($v = trim($this->NewLocNotes->getText())) != '')
			$item['notes'] = $v;
		if ($this->NewLocElectr->getSelectedIndex() > 0)
			$item['electronicFormat'] = $this->NewLocElectr->getSelectedValue();
		if ($this->NewLocDigit->getSelectedIndex() > 0)
			$item['mutilo'] = $this->NewLocMutilo->getSelectedValue();
		if (($v = trim($this->NewLocUri->getText())) != '')
			$item['uri'] = $v;
		if ($this->NewLocDigit->getSelectedIndex() > 0)
			$item['digitalizationType'] = $this->NewLocDigit->getSelectedValue();
		$elements = array(
			array(
				'class'	 => SBNTypes::OBJCLASS_DOC,
				'type'	 => SBNConverter::ClavisType2SBNType($m->getBibType()),
				'bid'	 => $bid,
				'items'	 => array($item),
			)
		);
		$req = $this->_sbnMod->getNewRequest();

		if ($m->getLastSbnSync() != null)
			$loctype = SBNTypes::LOCTYPE_ALL;
		else
			$loctype = SBNTypes::LOCTYPE_OWN;

		$sbn_response = $req->localize($elements, SBNTypes::LOCACTION_LOCALIZE, $loctype);
		if ($sbn_response && '7017' == $sbn_response->SbnMessage->SbnResponse->SbnResult->esito)
			$sbn_response = $req->localize($elements, SBNTypes::LOCACTION_FIX, $loctype);
		if ($sbn_response && '0000' == $sbn_response->SbnMessage->SbnResponse->SbnResult->esito)
		{
			ItemQuery::create()
					->filterByManifestation($m)
					->filterByLibraryRelatedByHomeLibraryId($l)
					->update(array('LastSbnSync' => time()));
			$this->_item->reload();
			$this->getPage()->writeMessage(Prado::localize('Esemplare correttamente localizzato per possesso in SBN.'), ClavisMessage::CONFIRM);
		}
		else
		{
			$this->getPage()->writeMessage(Prado::localize('Errore nell\'eseguire l\'operazione: {sbnmessage}', array('sbnmessage' => $sbn_response->SbnMessage->SbnResponse->SbnResult->testoEsito)), ClavisMessage::ERROR);
		}
		$this->populate();
	}

	public function onSBNUnlocalize($sender, $param)
	{
		if (in_array($this->getSbnStatus(true), array('unlocalizable', 'localizable')))
		{
			$this->getPage()->writeMessage(Prado::localize('Il titolo non è localizzato.'), ClavisMessage::ERROR);
			$this->populate();
			return;
		}

		$m = $this->_item->getManifestation();
		$bid = $m->getBid();
		$l = $this->_item->getHomeLibrary();
		$elements = array(
			array(
				'class'	 => SBNTypes::OBJCLASS_DOC,
				'type'	 => SBNConverter::ClavisType2SBNType($m->getBibType()),
				'bid'	 => $bid,
				'items'	 => array(array(
//					'libAnagraphicCode'	=> $l->getIllCode(),
						'libSBNCode' => $this->_sbnMod->getLibraryCode($l),
					))
			)
		);
		$req = $this->_sbnMod->getNewRequest();

		if ($m->getLastSbnSync('U') != null)
			$sbn_response = $req->localize($elements, SBNTypes::LOCACTION_UNLOCALIZE, SBNTypes::LOCTYPE_OWN);
		else
			$sbn_response = $req->localize($elements, SBNTypes::LOCACTION_UNLOCALIZE, SBNTypes::LOCTYPE_ALL);

		switch ($sbn_response->SbnMessage->SbnResponse->SbnResult->esito)
		{
			case '0000':
			case '3013':
				ItemQuery::create()
						->filterByManifestation($m)
						->filterByLibraryRelatedByHomeLibraryId($l)
						->update(array('LastSbnSync' => null));
				$this->_item->reload();
				$this->getPage()->writeMessage(Prado::localize('Esemplare correttamente delocalizzato per possesso da SBN.'), ClavisMessage::CONFIRM);
			default:
				$this->getPage()->writeMessage(Prado::localize('Errore nell\'eseguire l\'operazione: {sbnmessage}', array('sbnmessage' => $sbn_response->SbnMessage->SbnResponse->SbnResult->testoEsito)), ClavisMessage::ERROR);
		}
		$this->populate();
	}
}