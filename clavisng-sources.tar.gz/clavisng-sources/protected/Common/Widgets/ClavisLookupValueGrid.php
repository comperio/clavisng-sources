<?php

/**
 * ClavisLookupValuesGrid class
 *
 * @author Ciro Mattia Gonano
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2011 Comperio srl
 * @version 2.7
 * @package Widgets
 * @since 2.4
 */

class ClavisLookupValueGrid extends TTemplateControl
{
	private $_classes;

	public $_allowedValueClasses = array(	'ADDRESSTYPE',
											'AUTHORITYLINKEDDATA',
											'CLASSEDITION',
											'CLASSTYPE',
											'CUSTOMLABEL',
											'IDDOCS',
											'IM',
											'ITEMSOURCE',
											'LIBRARIANROLE',
											'ITEMCUST1',
											'ITEMCUST2',
											'ITEMCUST3',
											'LIBRARYPROPERTY',
											'PATRONCUST1',
											'PATRONCUST2',
											'PATRONCUST3',
											'PATRONLOANCLASS',
											'PATRONPROPERTY',
											'PRINTERSDEVICEINDEX',
											'STREET',
											'STUDTYPE',
											'SUBJECTTYPE',
											'SUPPLIERPAYMETHOD',
											'TITLE',
											'WORKTYPE' );

	public function onLoad($param)
	{
		parent::onLoad($param);

		$this->_classes = array('' => '---');
		$list = LookupValuePeer::getLookupClassValues('ADMINEDITLABEL');
		
		foreach($this->_allowedValueClasses as $key)
			$this->_classes[$key] = "[{$key}] {$list[$key]}";

		if (!$this->getPage()->getIsPostBack()
				&& !$this->getPage()->getIsCallBack())
		{
			$languages = ClavisParamPeer::getClassParams('APPLANG');
			$this->LanguageFilter->setDataSource($languages);
			$this->LanguageFilter->dataBind();
			$this->LanguageFilter->setSelectedIndex(0);
			$this->ClassFilter->setDataSource($this->_classes);
			$this->ClassFilter->dataBind();
			$this->NewLookupClassList->setDataSource($this->_classes);
			$this->NewLookupClassList->dataBind();
			
			$this->populate();
		}
	}

	public function populate($searchFilter = array())
	{
		$pageSize = $this->LVGrid->getPageSize();
		$currentIndexPage = $this->LVGrid->getCurrentPage();

		$lang = $this->LanguageFilter->getSelectedValue();
		
		$class = ($this->ClassFilter->getSelectedIndex() < 1)
									? $this->_allowedValueClasses
									: $this->ClassFilter->getSelectedValue();

		$ds = LookupValueQuery::create()
				->filterByValueLanguage($lang)
				->filterByValueClass($class)
				->orderByValueClass()
				->orderBySortableRank()
				->orderByValueKey();

		$ds2 = clone $ds;
		$recCount = $ds2->count();

		if ($pageSize > 0)
			$ds->limit($pageSize)->offset($currentIndexPage * $pageSize);

		$datasource = $ds->find();

		$this->FoundNumber->setText($recCount);
		$this->LVGrid->setVirtualItemCount($recCount);
		$this->LVGrid->setDataSource($datasource);
		$this->LVGrid->dataBind();
	}

	public function onSearch($sender, $param)
	{
		$this->populate();
	}

	public function changePage($sender,$param)
	{
		$this->LVGrid->setCurrentPage($param->NewPageIndex);
		$this->populate();
	}

	public function getPopupFlag()
	{
		return $this->getPage()->IsPopup();
	}

 	public function editLV($sender,$param)
	{
		$this->populate();
		
		$this->LVGrid->setEditItemIndex($param->Item->getItemIndex());
		$this->LVGrid->dataBind();
	}

	public function saveLV($sender,$param)
	{
		$item = $param->getItem();

		$language =  $this->LanguageFilter->getSelectedValue();
		$class = $item->ClassCol->EditValueClassLabel->getText();
		$key = $item->KeyCol->EditValueKeyLabel->getText();

		$lv = LookupValueQuery::create()->findPk(array($key,$language,$class));

		if ($lv instanceof LookupValue)
		{
			try
			{
				$lv->setValueLabel(trim($item->ValueCol->EditValueLabelText->getSafeText()));
				$lv->save();
				
				$this->getPage()->writeMessage(Prado::localize("Aggiornato parametro di sistema"),
													ClavisMessage::CONFIRM);
			}
			catch (Exception $e)
			{

			}
		}
		
		$this->LVGrid->setEditItemIndex(-1);
		
		$this->populate();
	}

	public function cancelLVEdit($sender,$param)
	{
		$this->LVGrid->setEditItemIndex(-1);
		
		$this->populate();
	}

	public function deleteLv($sender, $param)
	{
		$key = explode('|',$param->getCommandParameter());
		$lv = LookupValueQuery::create()->findPk($key);
		
		if ($lv instanceof LookupValue)
		{
			try
			{
				$lv->delete();
			
				ChangelogPeer::logAction(	$lv,
											ChangelogPeer::LOG_DELETE,
											$this->getUser(),
											"Eliminato parametro di sistema, classe='{$key[0]}', lingua= '{$key[1]}', chiave='{$key[2]}', valore='{$lv->getValueLabel()}'");
				
				$this->getPage()->writeMessage(Prado::localize("Cancellato parametro di sistema, classe='{class}', lingua='{lang}', chiave='{key}'",
																	array(	'class' => $key[0],
																			'lang' => $key[1],
																			'key' => $key[2])),
													ClavisMessage::CONFIRM);
			}
			catch (Exception $e)
			{
				$this->getPage()->writeMessage(Prado::localize("Errore sulla cancellazione del parametro di sistema"),
													ClavisMessage::ERROR);
			}
		}
		
		$this->populate();
	}

	public function showAddPanel($sender, $param)
	{
		$this->AddLookupValue->setVisible(true);
		
		$this->getPage()->setFocus($this->NewLookupClassList);
	}

	public function createNewLV($sender, $param)
	{
		$class = $this->NewLookupClassList->getSelectedValue();
		$lang = $this->getApplication()->getGlobalization()->getCulture();
		$key = $this->NewLookupKey->getText();
		$value = $this->NewLookupValue->getText();
		
		$lv = LookupValueQuery::create()
					->filterByPrimaryKey(array(	$key,
												$lang,
												$class) )
					->findOneOrCreate();
		
		if (!$lv->isNew())
		{
			$this->getPage()->writeMessage(Prado::localize("Il parametro specificato è già esistente."),
												ClavisMessage::ERROR);
		}
		else
		{
			try
			{
				$lv->setValueLabel($value);
				$lv->save();
			
				ChangelogPeer::logAction(	$lv, 
											ChangelogPeer::LOG_CREATE,
											$this->getUser(),
											"Creato nuovo parametro di sistema, classe='{$class}', lingua= '{$lang}', chiave='{$key}', valore='{$value}'");
				
				$this->getPage()->writeMessage(Prado::localize("Creato nuovo parametro di sistema, classe='{class}', chiave='{key}', valore='{value}'",
																	array(	'class' => $class,
																			'key' => $key,
																			'value' => $value )),
													ClavisMessage::CONFIRM);
			}
			catch (Exception $e)
			{
				$this->getPage()->writeMessage(Prado::localize("Errore nella creazione del parametro: {error}",
																	array('error' => $e)),
													ClavisMessage::ERROR);
			}
		}
		
		$this->AddLookupValue->setVisible(false);
		
		$this->populate();
	}

	public function itemAction($sender,$param)
	{
		$action = $param->getCommandName();
	
		switch ($action)
		{
			case 'moveUp':
				$key = explode('|',$param->getCommandParameter());
				$lv = LookupValueQuery::create()->findPk($key);
		
				if ($lv instanceof LookupValue)
					$lv->moveUp();
				
				break;
			case 'moveDown':
				$key = explode('|',$param->getCommandParameter());
				$lv = LookupValueQuery::create()->findPk($key);
				
				if ($lv instanceof LookupValue)
					$lv->moveDown();
				
				break;
			default:
				break;
		}
		
		$this->populate();
	}
	
}
