<?php
/**
 * ClavisEditObjectStackDisplay class
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2017 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.8.7
 */

/**
 * ClavisEditObjectStackDisplay Class
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.8.7
 * @package Widgets
 * @since 2.8.7
 */
class ClavisEditObjectStackDisplay extends TTemplateControl
{
	const CHARLIMIT= 500;
	
	public function onPreRender($param)
	{
		parent::onPreRender($param);

		$this->updateDisplay(null, $param);
	}

	public function updateDisplay($sender, $param)
	{
		/***	OLD widget
		$this->EditObjectStackOL->setNavigateUrl(ClavisBase::readEditObjectStackLast2HyperLink());
		$this->EditObjectStackOL->setText(ClavisBase::readEditObjectStackLast2Text());
				
		$this->EditObjectStackOL->setOLText(ClavisBase::readEditObjectStack2Text());
		 */

		$legendaText = ClavisBase::readEditObjectStack2Text() 
							. '<br /><br /><br /><a href="" onClick="if(!confirm(\''.Prado::localize('Sei sicuro?').'\')) return false; ClearEditObjectStack(); return false;" class="formLinkButton">'
							. Prado::localize("concludi attività e torna all'inizio") . '</a>';

		$this->EditObjectStackLegenda->setOLText($legendaText);
		
		// breadcrumb part
		$editObjectStackBreadCrumb = ClavisBase::readEditObjectStack2BreadCrumb();
		
		if (strlen($editObjectStackBreadCrumb) > self::CHARLIMIT)
			$editObjectStackBreadCrumb = "...&nbsp;" . mb_substr($editObjectStackBreadCrumb, -self::CHARLIMIT);

		$this->EditObjectStackBreadCrumb->setText($editObjectStackBreadCrumb);		
	}

	public function gotoEditObject($sender, $param)
	{
		$gotoArray = ClavisBase::readEditObjectStackLast2HyperLinkArray();
		
		if (count($gotoArray) > 0)
			$this->getPage()->gotoPage(	$gotoArray['url'], 
										array($gotoArray['id'][0] => $gotoArray['id'][1]));
	}
	
	public function onClearEditStack($sender, $param)
	{
		$message = Prado::localize("Le operazioni di catalogazione completa sono concluse e sono stati creati i seguenti oggetti: ")
						. implode(", ", ClavisBase::readEditObjectStack2HyperLinkArray());

		
		// actual deletion of stack
		$returnElement = ClavisBase::clearEditObjectStack();
	
		if (ClavisBase::isValidElementObjectStack($returnElement))
		{
			$this->getPage()->writeDelayedMessage($message,
													ClavisMessage::INFO);

			if ($returnElement[0] == ClavisBase::EDITOBJECTSSTACK_TYPEMANIFESTATION)	// manifestation
				{
					$this->getPage()->gotoPage(	'Catalog.EditRecord', 
												array(	'manifestationId' => $returnElement[1],
														'selectTab' => 'TabAuthority' ));
				}
				elseif ($returnElement[0] == ClavisBase::EDITOBJECTSSTACK_TYPEAUTHORITY)	// authority
				{
					$this->getPage()->gotoPage(	'Catalog.AuthorityEditPage', 
												array(	'id' => $returnElement[1],
														'selectTab' => 'TabAuthLink' ));
				}
		}
		else
		{
			$this->getPage()->writeMessage($message,
												ClavisMessage::INFO);
			
			$this->updateDisplay($sender, $param);
		}
	}
	
}