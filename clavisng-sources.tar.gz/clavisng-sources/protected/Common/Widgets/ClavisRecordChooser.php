<?php
/**
 * ClavisRecordChooser class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @author Ciro Mattia Gonano
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2016 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.8.3
 * @package Widgets
 */

/**
 * ClavisRecordChooser
 * 
 * Widget that allows to choose a single manifestation, and after that
 * it shows its data..
 * ClavisPatronView Class
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @author Ciro Mattia Gonano
 * @version 2.8.3
 * @package Widgets
 * @since 2.0
 */
class ClavisRecordChooser extends TTemplateControl
{
	private $_manifestation = null;
	private $_manifestationSessionName;
	private $_issue = null;
	private $_referrer;
	private $_referrerSessionName;

	private function initVars()
	{
		$uniqueId = $this->getUniqueID();

		$this->_manifestationSessionName = "RecordChooserManifestationSessionName" . $uniqueId;
		$this->_referrerSessionName = "ReferrerSessionName" . $uniqueId;
	}

	public function onInit($param)
	{
		parent::onInit($param);
		$this->initVars();

		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallback())
		{
			$this->resetManifestation();
		}
	}

	/**
	 * In the onLoad, during first execution of the page we
	 * get the actual manifestation and populate the list.
	 *
	 * @param TEventParameter $param
	 */
	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsPostBack())
		{
			$this->getManifestation();
			$this->populate();
		}
	}

	public function resetManifestation($manifestation = null)
	{
		$this->setManifestation($manifestation);
	}

	public function setManifestation($manifestation)
	{
		$this->_manifestation = $manifestation;
		$this->getApplication()->getSession()->add($this->_manifestationSessionName, $this->_manifestation, null);
	}

	public function getManifestation()
	{
		$this->_manifestation = $this->getApplication()->getSession()->itemAt($this->_manifestationSessionName, null);

		return $this->_manifestation;
	}

	public function getManifestationId()
	{
		$manifestation = $this->getManifestation();

		if ($manifestation instanceof Manifestation)
		{
			return $manifestation->getManifestationId();
		}
		else
		{
			return 0;
		}
	}

	public function getIssueId()
	{
		if (!$this->getShowIssues())
			return 0;

		if (!$this->_issue)
			$this->getIssue();

		return ($this->_issue instanceof Issue) ? $this->_issue->getIssueId() : 0;
	}

	public function getIssue()
	{
		if (!$this->getShowIssues())
			return null;

		$this->_issue = IssueQuery::create()->findPk(intval($this->IssueResultValue->getValue()));

		return $this->_issue;
	}

	public function resetReferrer($component = null)
	{
		$this->setReferrer($component);
	}

	public function setReferrer($component)
	{
		$this->_referrer = $component;
		$this->getApplication()->getSession()->add($this->_referrerSessionName, $this->_referrer, null);
	}

	public function getReferrer()
	{
		$this->_referrer = $this->getApplication()->getSession()->itemAt($this->_referrerSessionName, null);

		return $this->_referrer;
	}

	public function setShowIssues($value)
	{
		$this->setControlState('ShowIssues', $value, false);
	}

	public function getShowIssues()
	{
		return $this->getControlState('ShowIssues', false);
	}

	/**
	 * Population of main data of the manifestation.
	 *
	 */
	public function populate()
	{
		
	}

	public function onChooseRecord($sender, $param)
	{
		$manifestationId = intval($this->RecordResultValue->getValue());
		$m = ManifestationQuery::create()->findPk($manifestationId);

		if ($m instanceof Manifestation)
		{
			$this->setManifestation($m);
			$this->ManifestationView->update($manifestationId);

			if ($this->getShowIssues() && ($m->getBibLevel() == ManifestationPeer::LVL_SERIAL))  // serial - enable issue select
			{
				$this->IssueResultValue->setValue(0);
				$this->IssueResultLabel->setText('');

				$this->IssueLinkChooser->setParam($manifestationId);
				$this->LinkedIssueSelect->setCssClass('panel_on');
			}
			else
			{
				$this->LinkedIssueSelect->setCssClass('panel_off');
			}
		}
		else
		{
			$this->getPage()->writeMessage(Prado::localize('Errore nella scelta della notizia'), ClavisMessage::ERROR);

			$this->LinkedIssueSelect->setCssClass('panel_off');

			if ($this->getPage()->getIsCallback())
				$this->LinkedIssueSelect->render($param->getNewWriter());
		}
	}

	public function clean()
	{
		$this->resetManifestation();
		$this->ManifestationView->clean();
	}
	
}