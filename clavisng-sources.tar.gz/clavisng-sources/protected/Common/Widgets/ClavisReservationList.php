<?php
/**
 * ClavisReservationList file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Widgets
 */

/**
 * ClavisReservationList class
 *
 * This component visualizes a datagrid whose lines are requests
 * for a loan, and which the current logged operator can, in
 * any way, fullfill.
 * It's filtered upon some parameters (inserted by some dropdown lists),
 * or filtered by some other parameters (i.e. patron_id) which are set
 * externally by the "setObject()" method (note: the column which
 * matched the type of object passed is turned off in the grid).
 * 
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.7
 * @package Widgets
 * @since 2.1
 */

class ClavisReservationList extends TTemplateControl
{
	private $_datasource = null;
	private $_checked;
	private $_localItems;

	/** @param ClavisLoanManager $_loanmanager */
	protected $_loanmanager;

	private $_fromLibraryId;
	private $_toLibraryId;
	private $_patronId;
	private $_freeze;
	private $_renewCount;
	private $_outDateFrom;
	private $_outDateTo;
	private $_statuslist;
	private $_section;
	private $_collocation;

	private $_object;
	private $_activeFilter;

	private $_requestStatusMode;
	private $_expandId;

	private $_foundNumberSessionName;
	private $_storedDataSourceSessionName;
	private $_storedDataSourceSessionNameOff;
	private $_pageIndexSessionName;
	private $_illCheckedSessionName;
	private $_localItemsSessionName;
	private $_barcodesSessionName;
	private $_globalcriteriaSessionName;
	private $_barcodeFilterSessionName;
	private $_bibObjFilterSessionName;
	private $_managed;
	public $_llibraryActive;
	public $_requestTypeActive;

	public function initVars()
	{
		$uniqueId = $this->getUniqueID() . $this->getUniqueName();
		$this->_foundNumberSessionName = 'FoundNumberSessionName' . $uniqueId;
		$this->_storedDataSourceSessionName = 'StoredDataSourceSessionName' . $uniqueId;
		$this->_storedDataSourceSessionNameOff = 'StoredDataSourceSessionNameOff' . $uniqueId;
		$this->_pageIndexSessionName = 'PageIndexSessionName' . $uniqueId;
		$this->_illCheckedSessionName = 'IllCheckedSessionName' . $uniqueId;
		$this->_localItemsSessionName = 'LocalItemsSessionName' . $uniqueId;
		$this->_barcodesSessionName = 'BarcodesSessionName' . $uniqueId;
		$this->_globalcriteriaSessionName = 'GlobalCriteriaSessionName' . $uniqueId;
		$this->_barcodeFilterSessionName = 'BarcodeFilterSessionName' . $uniqueId;
		$this->_bibObjFilterSessionName = 'BibObjFilterSessionName' . $uniqueId;

		$this->_loanmanager = $this->getApplication()->getModule('loan');
		
		$this->_llibraryActive = LLibraryPeer::isEnabled();
		$this->_requestTypeActive = ItemRequestPeer::isRequestType();
	}

	/**
	 * Here we load the clavis loan manager module, we get the
	 * saved (into session variables) datasource (as a hash), and
	 * we populate the grid in case the page is loaded the first
	 * time.
	 *
	 * @param TEventParameter $param
	 */
	public function onInit($param)
	{
		parent::onInit($param);
		$this->initVars();

		$this->_checked = $this->getChecked();
		$this->_localItems = $this->getLocalItems();
		
		$this->MaxDistanceColumn->setVisible($this->_llibraryActive);
		
		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallback())
		{
			$this->NoSearchPanel->setVisible(false);
			$this->PopulatedFlag->setValue("false");
		}
	}

	public function onLoad($param)
	{
		parent::onLoad($param);

		$populated = ($this->PopulatedFlag->getValue() == "true");
		
		if (!$this->getPage()->getIsPostBack()
				&& !$this->getPage()->getIsCallback())
		{
		
			if (!$populated && $this->getAutopopulate())
			{
				$this->resetPagination();
				$this->resetDataSource();
			}
		}

		$this->NoSearchPanel->setVisible(!$this->getAutopopulate()
											&& !$populated);
	}
	
	public function setUniqueName($value = "")
	{
		$this->setControlState("UniqueName", $value, "");
	}

	public function getUniqueName()
	{
		return $this->getControlState("UniqueName", "");
	}

	public function resetBarcodeFilter($barcode = '')
	{
		$this->setBarcodeFilter($barcode);
	}

	public function setBarcodeFilter($barcode = '')
	{
		$this->setViewState($this->_barcodeFilterSessionName, $barcode, '');
	}

	public function getBarcodeFilter()
	{
		return $this->getViewState($this->_barcodeFilterSessionName, '');
	}

	public function resetBibObjFilter($param = null)
	{
		$this->setBibObjFilter($param);
	}

	public function setBibObjFilter($param = null)
	{
		$this->setViewState($this->_bibObjFilterSessionName, $param, null);
	}

	public function getBibObjFilter()
	{
		return $this->getViewState($this->_bibObjFilterSessionName, null);
	}

	public function setAutopopulate($param = "true")
	{
		if (strtolower($param) === "false")
		{
			$param = false;
		}
		else
		{
			$param = true;
		}

		$this->setControlState("autopopulate", $param, true);
	}

	public function getAutopopulate()
	{
		return $this->getControlState("autopopulate", true);
	}

	public function setGlobalCriteria($criteria = null)
	{
		$this->setViewState($this->_globalcriteriaSessionName, $criteria, null);
	}

	/**
	 * @return Criteria
	 */
	public function getGlobalCriteria()
	{
		return SerializableCriteria::refreshCriteria($this->getViewState($this->_globalcriteriaSessionName, null));
	}

	public function setRequestStatusMode($mode)
	{
		$this->_requestStatusMode = $mode;
		$this->setViewState("requestStatusMode", $mode, null);
	}

	public function getRequestStatusMode()
	{
		if (is_null($this->_requestStatusMode))
			$this->_requestStatusMode = $this->getViewState("requestStatusMode", null);

		return $this->_requestStatusMode;
	}

	public function setExpandId($requestId)
	{
		$this->_expandId = $requestId;
		$this->setViewState("expandId", $requestId, null);
	}

	public function getExpandId()
	{
		if (is_null($this->_expandId))
			$this->_expandId = $this->getViewState("expandId", null);
		
		return $this->_expandId;
	}

	public function setObject($obj)
	{
		$this->_object = $obj;
		$this->setViewState("object", $obj, null);
	}

	public function getObject()
	{
		$this->_object = $this->getViewState("object", null);
		
		return $this->_object;
	}

	public function setFreeze($freeze)
	{
		$this->_freeze = $freeze;
		$this->setViewState("freeze", $freeze, null);
	}

	public function getFreeze()
	{
		if (is_null($this->_freeze))
			$this->_freeze = $this->getViewState("freeze", null);
		
		return $this->_freeze;
	}

 	public function setToLibraryId($lib)
 	{
 		$this->_toLibraryId = $lib;
 		$this->setViewState('toLibraryId', $this->_toLibraryId, null);
 	}

 	public function getToLibraryId()
 	{
 		if (($lib = $this->_toLibraryId) == null)
 		{
 			$lib = $this->getViewState('toLibraryId', null);
 			$this->_toLibraryId = $lib;
 		}
		
		return $lib;
 	}

 	public function setMaxDistance($param)
 	{
 		$this->setViewState('maxDistance', $param, null);
 	}

 	public function getMaxDistance()
 	{
		return $this->getViewState('maxDistance', null);
 	}

 	public function setRequestType($param)
 	{
 		$this->setViewState('requestType', $param, null);
 	}

 	public function getRequestType()
 	{
		return $this->getViewState('requestType', null);
 	}

  	public function setFromLibraryId($lib)
 	{
 		$this->_fromLibraryId = $lib;
 		$this->setViewState('fromLibraryId', $this->_fromLibraryId, null);
 	}

 	public function getFromLibraryId()
 	{
 		if (($libId = $this->_fromLibraryId) == null)
 		{
 			$libId = $this->getViewState('fromLibraryId', null);
 			$this->_fromLibraryId = $libId;
 		}

		if (is_null($libId) && $this->getPopupFlag())
			$libId = Prado::getApplication()->getUser()->getActualLibraryId();

		return $libId;
 	}

 	public function setLoanStatus($loanStatus)
 	{
 		$this->_loanStatus = $loanStatus;
 		$this->setViewState('loanStatus', $this->_loanStatus, null);
 	}

 	public function getLoanStatus()
 	{
 		if (($loanStatus = $this->_loanStatus) == null)
 		{
 			$loanStatus = $this->getViewState('loanStatus', null);
 			$this->_loanStatus = $loanStatus;
 		}

		return $loanStatus;
 	}

 	public function setPatronId($id)
 	{
 		$this->_patronId = $id;
 		$this->setViewState('patronId', $this->_patronId, null);
 	}

 	public function getPatronId()
 	{
 		if (($id = $this->_patronId) == null)
 		{
 			$id = $this->getViewState('patronId', null);
 			$this->_patronId = $id;
 		}
		
		return $id;
 	}

 	public function setRenewCount($count)
 	{
 		$this->_renewCount = $count;
 		$this->setViewState('renewCount', $this->_renewCount, null);
 	}

 	public function getRenewCount()
 	{
 		if (($count= $this->_renewCount) == null)
 		{
 			$count = $this->getViewState('renewCount', null);
 			$this->_renewCount = $count;
 		}
		
		return $count;
 	}

 	public function setOutDateFrom($date)
 	{
 		$this->_outDateFrom = $date;
 		$this->setViewState('outDateFrom', $this->_outDateFrom, null);
 	}

 	public function getOutDateFrom()
 	{
 		if (($date= $this->_outDateFrom) == null)
 		{
 			$date = $this->getViewState('outDateFrom', null);
 			$this->_outDateFrom = $date;
 		}
		
		return $date;
 	}

 	public function setOutDateTo($date)
 	{
 		$this->_outDateTo = $date;
 		$this->setViewState('outDateTo', $this->_outDateTo, null);
 	}

 	public function getOutDateTo()
 	{
 		if (($date= $this->_outDateTo) == null)
 		{
 			$date = $this->getViewState('outDateTo', null);
 			$this->_outDateTo = $date;
 		}
		
		return $date;
 	}

 	public function setStatusList($list = null)
 	{
 		$this->_statuslist = $list;
 		$this->setViewState('statusList', $this->_statuslist, null);
 	}

 	public function getStatusList()
 	{
 		$this->_statuslist = $this->getViewState('statusList', null);
 		
		return $this->_statuslist;
 	}

 	public function setNotManageableFlag($flag = false)
 	{
 		$this->setViewState('notManageableFlag', $flag, false);
 	}

 	public function getNotManageableFlag()
 	{
 		return $this->getViewState('notManageableFlag', false);
 	}

	public function setOocMode($flag = false)
 	{
 		$this->setViewState('oocMode', $flag, false);
 	}

 	public function getOocMode()
 	{
 		return $this->getViewState('oocMode', false);
 	}

 	public function setSection($section = null)
 	{
 		$this->_section = $section;
 		$this->setViewState('section', $this->_section, null);
 	}

 	public function getSection()
 	{
 		$this->_section = $this->getViewState('section', null);
 		
		return $this->_section;
 	}

 	public function setCollocation($collocation = null)
 	{
 		$this->_collocation = $collocation;
 		$this->setViewState('collocation', $this->_collocation, null);
 	}

 	public function getCollocation()
 	{
 		$this->_collocation = $this->getViewState('collocation', null);
 		
		return $this->_collocation;
 	}

	public function setActiveFilter($activeFilter = null)
	{
		$this->_activeFilter = $activeFilter;
		$this->setViewState("activeFilter", $activeFilter, null);
	}

	public function getActiveFilter()
	{
		if (is_null($this->_activeFilter))
			$this->_activeFilter = $this->getViewState("activeFilter", null);
		
		return $this->_activeFilter;
	}

	public function setManaged($managed = null)
	{
		$managed = strtolower($managed);
		switch ($managed)
		{
			case 'null':
				$this->_managed = null;
				break;
			
			case 'true':
				$this->_managed = true;
				break;
			
			case 'false':
				$this->_managed = false;
				break;
			
			default:
				$this->_managed = null;
		}

		$this->setControlState("managed", $this->_managed, null);
	}

	public function getManaged()
	{
		$this->_managed = $this->getControlState("managed", null);
		
		return $this->_managed;
	}

	public function setShrink($param = 'true')
	{
		switch (strtolower($param))
		{
			case 'false':
				$output = false;
				break;

			case 'true':
			case 'null':
			default:
				$output = true;
		}

		$this->setControlState("ShrinkFlag", $output, true);
	}

	/**
	 * We use to call this in order to check if this widget is
	 * intended to be part of normal requests page (true), because
	 * we need to shrink results and not ricalculate its results,
	 * or rather if it's intended to be part of the search page
	 * (and accessories) where we don't want to store datasource
	 * or shrink.
	 * 
	 * @return boolean
	 */
	public function getShrink()
	{
		return $this->getControlState("ShrinkFlag", true);
	}

	public function setShowPatronLoanNumber($param = 'false')
	{
		switch (strtolower($param))
		{
			case 'true':
				$output = true;
				break;

			case 'false':
			case 'null':
			default:
				$output = false;
		}

		$this->setControlState("ShowPatronLoanNumber", $output, false);
	}

	public function getShowPatronLoanNumber()
	{
		return $this->getControlState("ShowPatronLoanNumber", false);
	}

	public function resetChecked($state = false)
	{
		$this->setChecked(array('all' => $state));

		foreach ($this->Grid->getItems() as $item)
			$item->CheckColumn->Checked->setChecked($state);
	}

	public function setChecked($checked = null)
	{
		$this->_checked = $checked;
		$this->getApplication()->getSession()->add($this->_illCheckedSessionName, $checked);
	}

	public function getChecked()
	{
		$this->_checked = $this->getApplication()->getSession()->itemAt($this->_illCheckedSessionName);

		return $this->_checked;
	}

	public function resetLocalItems()
	{
		$this->_localItems = array();
		$this->setLocalItems($this->_localItems);
	}

	public function setLocalItems($localItems)
	{
		if ($localItems == null)
		{
			$localItems = $this->_localItems;
		}
		else
		{
			$this->_localItems = $localItems;
		}

		$this->getApplication()->getSession()->add($this->_localItemsSessionName, $localItems);
	}

	public function getLocalItems()
	{
		if(is_null($this->_localItems))
			$this->_localItems = $this->getApplication()->getSession()->itemAt($this->_localItemsSessionName);

		return $this->_localItems;
	}

	public function addBarcode($barcode)
	{
		if ($barcode != '')
		{
			$barcodes = $this->getBarcodes();
			$barcodes[] = $barcode;

			$this->setBarcodes($barcodes);
		}
	}

	public function deleteBarcode($barcode = '')
	{
		if ($barcode != '')
		{
			$barcodes = $this->getBarcodes();
			$key = array_search($barcode, $barcodes);
			if ($key != false)
			{
				unset($barcodes[$key]);
				$this->setBarcodes($barcodes);
			}
		}
	}

	public function existsBarcode($barcode = '')
	{
		$output = false;
		if ($barcode != '')
		{
			$barcodes = $this->getBarcodes();
			$output = in_array($barcode, $barcodes);
		}
		
		return $output;
	}

	public function getBarcodes()
	{
		$output = $this->getApplication()->getSession()->itemAt($this->_barcodesSessionName);
		
		return $output;
	}

	public function setBarcodes($barcodes)
	{
		$this->getApplication()->getSession()->add($this->_barcodesSessionName, $barcodes);
	}

	public function resetBarcodes()
	{
		$this->setBarcodes(array());
	}

	/**
	 * Method which resets the datasource (also saves into session
	 * variable), the checked status, and re-populates everything.
	 *
	 */
	public function resetDataSource($barcodeFilter = '')
	{
		$this->doResetDataSource($barcodeFilter);
		
		if ($this->getAutopopulate())
			$this->populate();
	}

	private function doResetDataSource($barcodeFilter = '')
	{
		$this->doResetGrid();
		
		$this->resetChecked();
		$this->resetLocalItems();
		$this->resetBarcodes();
		$this->resetFoundNumber();
		$this->resetStoredDataSource();
		$this->resetStoredDataSourceOff();
		$this->resetStoredPageIndex();
	}
	
	private function doResetGrid()
	{
		$this->PopulatedFlag->setValue("false");
		
		$this->NoSearchPanel->setVisible(!$this->getAutopopulate());
		
		$this->Grid->setVirtualItemCount(0);
		$this->Grid->setDataSource(array());
		$this->Grid->dataBind();
		
		$this->Grid->setCurrentPage(0);
		$this->FoundNumber->setText(0);
	}
	
	/**
	 * It returns whether an item, represented by the id passed
	 * as the parameter, is present in the loans datasource.
	 *
	 * @param int $itemId
	 * @return boolean
	 */
	private function searchIdIntoDatasource($itemId)
	{
		$dataSource = $this->parseDataSource($this->getStoredDataSource());
		foreach($dataSource as $row)
		{
			if ($row['id'] == $itemId)
				return true;
		}
		
		return false;
	}

	/**
	 * It sets the parameters for filtering results.
	 *
	 * @param int $fromLibraryId
	 * @param int $toLibraryId
	 * @param int $patronId
	 * @param int $renewCount
	 * @param date $outDateFrom
	 * @param date $outDateTo
	 * @param string $statusList
	 * @param string $section
	 * @param string $collocation
	 * @param string $barcode
	 * $param string $bibObj
	 */
	public function setFilters(	$fromLibraryId,
								$toLibraryId,
								$patronId = null,
								$renewCount = null,
								$outDateFrom = null,

								$outDateTo = null,
								$statusList = null,
								$section = null,
								$collocation = null,
								$barcode = "",

								$bibObj = null,
								$notManageableFlag = false,
								$oocMode = false,
								$resetPagination = true,
								$maxDistance = null,
			
								$requestType = null)	// 16
	{
		if ($fromLibraryId == 0)
			$fromLibraryId = null;

		if ($toLibraryId == 0)
			$toLibraryId = null;

		if ($patronId == 0)
			$patronId = null;

		if ($outDateFrom == '')
			$outDateFrom = null;
		if ($outDateTo == '')
			$outDateTo = null;

		if (is_array($statusList) && (count($statusList) == 0))
			$statusList = null;

		if (!TPropertyValue::ensureBoolean($notManageableFlag))
			$notManageableFlag = false;

		if ($section == '')
			$section = null;

		if ($collocation == '')
			$collocation = null;

		$this->setFromLibraryId($fromLibraryId);
		$this->setToLibraryId($toLibraryId);

		$this->setPatronId($patronId);
		$this->setRenewCount($renewCount);
		$this->setOutDateFrom($outDateFrom);
		$this->setOutDateTo($outDateTo);

		$this->setStatusList($statusList);
		$this->setNotManageableFlag($notManageableFlag);

		$this->setSection($section);
		$this->setCollocation($collocation);

		$this->setBarcodeFilter($barcode);
		$this->setBibObjFilter($bibObj);
		$this->setOocMode($oocMode);
		
		$this->setMaxDistance($maxDistance);
		$this->setRequestType($requestType);

		if ($resetPagination)
			$this->resetPagination();
	}

	public function resetFoundNumber()
	{
		$this->setFoundNumber(0);
	}
	
	public function setFoundNumber($param = 0)
	{
		$this->getApplication()->getSession()->add($this->_foundNumberSessionName, $param);
	}

	public function getFoundNumber()
	{
		return $this->getApplication()->getSession()->itemAt($this->_foundNumberSessionName);
	}

	public function resetStoredPageIndex()
	{
		$this->setStoredPageIndex(null);
	}
	
	public function setStoredPageIndex($param = null)
	{
		$this->getApplication()->getSession()->add($this->_pageIndexSessionName, $param, null);
	}

	public function getStoredPageIndex()
	{
		return $this->getApplication()->getSession()->itemAt($this->_pageIndexSessionName, null);
	}
	
	public function resetStoredDataSource()
	{
		$this->setStoredDataSource(array());
	}
	
	public function setStoredDataSource($param = array())
	{
		$this->_datasource = $param;
		$this->getApplication()->getSession()->add($this->_storedDataSourceSessionName, $this->_datasource);
	}

	public function getStoredDataSource()
	{
		$this->_datasource = $this->getApplication()->getSession()->itemAt($this->_storedDataSourceSessionName);
		
		return $this->_datasource;
	}

	public function resetStoredDataSourceOff()
	{
		$this->setStoredDataSourceOff(array());
	}
	
	public function setStoredDataSourceOff($param = array())
	{
		$this->getApplication()->getSession()->add($this->_storedDataSourceSessionNameOff, $param);
	}

	public function getStoredDataSourceOff()
	{
		return $this->getApplication()->getSession()->itemAt($this->_storedDataSourceSessionNameOff);
	}
	
	public function getMasterChecked()
	{
		$checked = $this->getChecked();
		
		return $checked['all'];
	}

	public function getCheckedItems(	$force = false,
										$reset = false,
										$jasperMode = false )
	{
		$checked = $this->getChecked();
		$masterChecked = $checked['all'];
		unset($checked['all']);
		$checkedIds = array_keys($checked);

		$userLibraryId = $this->getUser()->getActualLibraryId();
		$requestIds = array();
		if (!$masterChecked)
		{
			$requestIds = $checkedIds;
		}
		else	// inverse masterckecking
		{
			$criteria = $this->getGlobalCriteria();
			if ($criteria instanceof Criteria)
			{
				$fromLibraryIdFilter = $this->getFromLibraryId();

				$criteria->add(ItemRequestPeer::REQUEST_ID , $checkedIds, Criteria::NOT_IN);
				$requests = ItemRequestPeer::doSelect($criteria);
				if ($this->getShrink())
					$requestsCount = $this->shrinkItemRequest($requests, $userLibraryId);

				$requestIds = array();
				foreach ($requests as $request)
					 $requestIds[] = $request->getId();
			}

			elseif (is_array($criteria))
			{
				$requestIds = array_fill_keys(array_diff($criteria, $checkedIds), true);
			}
		}

		$results = array();
		if ($jasperMode)
		{
			$itemIdPool = array();
			$fromLibraryIdFilter = $this->getFromLibraryId();
			$criteriaLocal = $this->calculateReservationCriteria($fromLibraryIdFilter);
		}

		foreach ($requestIds as $requestId)
		{
			if ($requestId > 0)
			{
				$request = ItemRequestPeer::retrieveByPK($requestId);
				if ($request instanceof ItemRequest)
				{
					if (!$jasperMode)
						$results[] = array(	'id' => $request->getRequestId(),
											'request' => $request,
											'title' => substr($request->getTitle(), 0, 130),
											'requestDate' => $request->getRequestDate('U'),
											'expireDate' => $request->getExpireDate('U'),
											'deliveryLibraryLabel' => $request->getDeliveryLibraryLabel() );
					else   // modalita' Jasper, dove mi deve restituire anche un pool di item_id, e un semplice array di request_id
					{
						$results[] = $request->getRequestId();

						/// logica per estrarre un pool di myitems
						if ($this->getOocMode())       /// fuori catalogo
							$myItems = $this->getMyItems(	$fromLibraryIdFilter,
															'OocMode',
															$request->getItemId(),
															$criteriaLocal,
															$request->getIssueId());
						else		//normali
							$myItems = $this->getMyItems(	$fromLibraryIdFilter,
															'Manifestation',
															$request->getManifestationId(),
															$criteriaLocal,
									$request->getIssueId());

						foreach ($myItems as $cycleItem)
						{
							if ($cycleItem instanceof Item)
								$itemIdPool[] = $cycleItem->getItemId();
						}

						if (count($itemIdPool) == 0)
							$itemIdPool[] = 0;

						unset($myItems);
					}
				}
			}
		}

		if (!$jasperMode)  // normal
		{
			if ((count($results) == 0) && ($force))
			{
				$this->resetChecked(true);
				$results = $this->getCheckedItems();
				if ($reset)
					$this->resetChecked(false);
			}

			$output = $results;
		}
		else   // modo jasper
		{
			$itemIdPool = array_unique($itemIdPool);

			if ((count($results) == 0) && ($force == true))
			{
				$this->resetChecked(true);
				$resultsCombo = $this->getCheckedItems(false, false, true);
				$results = $resultsCombo['requestId'];
				$itemIdPool = $resultsCombo['itemId'];
				
				if ($reset)
					$this->resetChecked(false);
			}

			$output = array('requestId' => $results, 
							'itemId' => $itemIdPool);
		}

		return $output;
	}

	public function setMasterChecked($newChecked = false, $param = null)
	{
		$this->resetChecked($newChecked);
		$gridItems = $this->Grid->getItems();
		$header = $this->Grid->getHeader();

		foreach($gridItems as $item)
			$item->CheckColumn->Checked->setChecked($newChecked);

		$header->CheckColumn->MasterCheck->setChecked($newChecked);
	}

	private function calculateReservationCriteria($fromLibraryIdFilter, $mine = true)
	{
		$criteria = $this->_loanmanager->CalculateReservationCriteria(	$fromLibraryIdFilter,
																		$mine,
																		$this->getManaged(),
																		null,
																		null,

																		$this->getOocMode() ? 'OocMode' : 'Regular');
		
		return clone($criteria);
	}

	private function getMyItems(	$fromLibraryIdFilter = null,
									$mode = 'Manifestation',
									$objectId = null,
									$criteriaLocal = null,
									$issue_id = null )
	{
		if (!($criteriaLocal instanceof Criteria))
			$criteriaLocal = $this->calculateReservationCriteria($fromLibraryIdFilter);

			$myItems = $this->_loanmanager->GetRequestedObjects($fromLibraryIdFilter,
																$mode,
																$objectId,
																$this->getManaged(),
																clone($criteriaLocal),

																$issue_id );
			
		return $myItems;
	}

	public function addRows($requestIds = array())
	{
		$num = 0;
		
		foreach ($requestIds as $requestId)
		{
			if ($this->addRow($requestId))
				$num++;
		}
		
		return $num;
	}
	
	public function addRow($requestId = null)
	{
		$added = false;
		$requestId = intval($requestId);
		
		if ($requestId == 0)
			return false;

		$ds = $this->getStoredDataSource();
		$dsOff = $this->getStoredDataSourceOff();
		
		foreach ($dsOff as $index => $row)
		{
			if ($row['requestId'] == $requestId)
			{
				$added = true;
				unset ($dsOff[$index]);
				$ds[$index] = $row;
				break;
			}
		}
		
		ksort($ds);
		$this->setStoredDataSource($ds);
		$this->setStoredDataSourceOff($dsOff);
		
		if ($added)
			$this->setFoundNumber($this->getFoundNumber() + 1);
		
		return $added;
	}

	public function deleteRows($requestIds = array())
	{
		$num = 0;
		
		foreach ($requestIds as $requestId)
		{
			if ($this->deleteRow($requestId))
				$num++;
		}
		
		return $num;
	}
	
	public function deleteRow($requestId = null)
	{
		$deleted = false;
		$requestId = intval($requestId);
		if ($requestId == 0)
			return false;

		$ds = $this->getStoredDataSource();
		$dsOff = $this->getStoredDataSourceOff();
		
		foreach ($ds as $index => $row)
		{
			if ($row['requestId'] == $requestId)
			{
				$deleted = true;
				unset ($ds[$index]);
				$dsOff[$index] = $row;
				break;
			}
		}
		
		ksort($dsOff);
		$this->setStoredDataSource($ds);
		$this->setStoredDataSourceOff($dsOff);
		
		if ($deleted)
			$this->setFoundNumber($this->getFoundNumber() - 1);
		
		return $deleted;
	}
	
	private function parseDataSource($ds = array())
	{
		$copy = array();
		foreach ($ds as $index => $row)
		{
			if ($index >= 0)
				$copy[] = $row; 
		}
		
		return $copy;
	}
	
	public function populate()
	{
		/** @var $item Item */
		/** @var $request ItemRequest */
		/** @var $librarian Librarian */
		/** @var $patron Patron */
		/** @var $criteria Criteria */

		if ($this->getFreeze())
			return;

		$this->ErrorLabel->setText(Prado::localize("LISTA VUOTA  - nessuna prenotazione soddisfacibile"));
		
		/// cached values, new system
		$storedDataSource = $this->getStoredDataSource();
		// if cache is not empty and we are in the normal requests page
		if ($this->getShrink()
				&& (count($storedDataSource) > 0))
		{
			$datasource = $this->parseDataSource($storedDataSource);
			$successCount = intval($this->getFoundNumber());
			$storedIndexPage = $this->getStoredPageIndex();
		}
		else    // normal populate, with recalculation (no cached results)
		{
			if (count($this->getStoredDataSourceOff()) > 0)
				$this->doResetDataSource();
			
			$this->resetStoredPageIndex();
			$storedIndexPage = null;
			
			$userLibraryId = $this->getUser()->getActualLibraryId();
			$this->LocalItemsColumn->setVisible(!is_null($this->getManaged()));
			$this->AlienItemsColumn->setVisible(!is_null($this->getManaged()));
			$this->StatusColumn->setVisible(is_null($this->getManaged()));
			$fromLibraryIdFilter = $this->getFromLibraryId();

			if (is_null($this->getManaged()))
			{
				$criteria = new Criteria();
				
				if ($this->getOocMode()) 
				{
					$criteria->add(ItemPeer::MANIFESTATION_ID, 0);	// before it searched for null ...
					$criteria->addJoin(ItemPeer::ITEM_ID,ItemRequestPeer::ITEM_ID);
				}
				else	// non oocmode
				{
					$criteria->addAnd(ItemRequestPeer::MANIFESTATION_ID, 0, Criteria::GREATER_THAN);
				}
			}
			else
			{
				if ($this->getOocMode())     // solo i fuori catalogo
				{
					$criteriaOoc = new Criteria();
					$criteriaOoc->addAnd(ItemRequestPeer::MANIFESTATION_ID, 0);
					$criteria = $this->_loanmanager->CalculateReservationCriteria(	$fromLibraryIdFilter,
																					true,
																					$this->getManaged(),
							
																					null,
																					$criteriaOoc,
																					'OocMode' );
				}
				else        // esclusi i fuori catalogo
				{
					$criteriaRegular = new Criteria();
					$criteriaRegular->addAnd(ItemRequestPeer::MANIFESTATION_ID, 0, Criteria::GREATER_THAN);
					$criteria = $this->_loanmanager->CalculateReservationCriteria(	$fromLibraryIdFilter,
																					true,
																					$this->getManaged(),

																					null,
																					$criteriaRegular,
																					'Regular' );
				}

				if (!($criteria instanceof Criteria))
					return;
			}
			
			$barcodeFilter = trim($this->getBarcodeFilter());
			if ($barcodeFilter != '')
			{
				$itemsFromBarcode = ItemPeer::retrieveByDataInput($barcodeFilter);
				if (is_null($itemsFromBarcode))
					$itemsFromBarcode = array();

				$manifestationIdsFromBarcode = array();
				$itemIdsFromBarcode = array();
				$issueIdsFromBarcode = array();
				foreach ($itemsFromBarcode as $itemRow)
				{
					$rowIssueId = intval($itemRow->getIssueId());
					$rowManifestationId = intval($itemRow->getManifestationId());
					$rowItemId = intval($itemRow->getItemId());
					if ($rowIssueId > 0)
					{
						$issueIdsFromBarcode = $rowIssueId;
					}
					elseif ($rowManifestationId > 0)
					{
						$manifestationIdsFromBarcode[] = $rowManifestationId;
					}
					else
					{
						$itemIdsFromBarcode[] = $rowItemId;
					}
				}

				if (count($issueIdsFromBarcode) > 0)
					$criteria->addAnd(ItemRequestPeer::ISSUE_ID, $issueIdsFromBarcode, Criteria::IN);
				
				if (count($manifestationIdsFromBarcode) > 0)
					$criteria->addAnd(ItemRequestPeer::MANIFESTATION_ID, $manifestationIdsFromBarcode, Criteria::IN);
				
				if (count($itemIdsFromBarcode) > 0)
					$criteria->addAnd(ItemRequestPeer::ITEM_ID, $itemIdsFromBarcode, Criteria::IN);
			}
			else
			{
				$toLibraryIdFilter = $this->getToLibraryId();
				$patronIdFilter = $this->getPatronId();
				$maxDistance = $this->getMaxDistance();
				$requestType = $this->getRequestType();

				$renewCountFilter = $this->getRenewCount();
				if (is_null($renewCountFilter)
						|| ($renewCountFilter == ""))
				{
					$renewCountFilter = -0.5;
				}
				else
				{
					$renewCountFilter = floatval($renewCountFilter);
				}

				$outDateFromFilter = $this->getOutDateFrom();
				$outDateToFilter = $this->getOutDateTo();

				$statusFilter = $this->getStatusList();
				$notManageableFlag = $this->getNotManageableFlag();

				$sectionFilter = $this->getSection();
				$collocationFilter = $this->getCollocation();
				$bibObjFilter = $this->getBibObjFilter();

				if ($renewCountFilter >= 0)
				{
					if ($renewCountFilter == 0.5)
					{
						$criteria->addAnd(ItemPeer::RENEWAL_COUNT, 0, Criteria::GREATER_THAN);
					}
					else
					{
						$criteria->addAnd(ItemPeer::RENEWAL_COUNT, $renewCountFilter);
					}
				}
				else
				{
					if ($renewCountFilter <= -1)
						$criteria->addAnd(ItemPeer::RENEWAL_COUNT, -1, Criteria::LESS_THAN);
				}

				if (!is_null($patronIdFilter))
					$criteria->addAnd(ItemRequestPeer::PATRON_ID, $patronIdFilter);
				
				if ($this->_llibraryActive &&
						(!is_null($maxDistance)))
				{	
					$maxDistCrit = $criteria->getNewCriterion(ItemRequestPeer::MAX_DISTANCE, $maxDistance, Criteria::LESS_EQUAL);
					$maxDistCrit2 = $criteria->getNewCriterion(ItemRequestPeer::MAX_DISTANCE, null, Criteria::ISNULL);
					$maxDistCrit->addOr($maxDistCrit2);
					$criteria->addAnd($maxDistCrit);
				}

				if ($this->_requestTypeActive &&
						(!is_null($requestType)))
				{	
					if ($requestType === ItemRequestPeer::REQUESTTYPE_NULLVALUESTRING)
					{
						$criteria->addAnd(ItemRequestPeer::REQUEST_TYPE, null, Criteria::ISNULL);
					}
					else
					{
						$criteria->addAnd(ItemRequestPeer::REQUEST_TYPE, $requestType, Criteria::EQUAL);
					}
				}

				if (!is_null($outDateFromFilter) && ($outDateFromFilter > 0))
					$criteria->addAnd(ItemRequestPeer::REQUEST_DATE, $outDateFromFilter, Criteria::GREATER_EQUAL);

				if (!is_null($outDateToFilter) && ($outDateToFilter > 0))
					$criteria->addAnd(ItemRequestPeer::REQUEST_DATE, $outDateToFilter + 86399, Criteria::LESS_EQUAL);

				if ($notManageableFlag)
				{
					$this->ErrorLabel->setText(Prado::localize("LISTA VUOTA  - nessuna prenotazione insoddisfacibile"));

					$connection = Propel::getConnection();
					$query = "SELECT ir.request_id FROM item_request ir, item i , library ly ";
					$query .= "WHERE ir.request_status = '" . ItemRequestPeer::STATUS_PENDING . "' ";

					if (!is_null($toLibraryIdFilter))
						$query .= " AND ir.DELIVERY_LIBRARY_ID = " . $toLibraryIdFilter . " ";

					$query .= " AND ly.library_internal = '1' ";

					$query .= " AND ((ir.manifestation_id > 0 AND ir.manifestation_id = i.manifestation_id AND i.owner_library_id = ly.library_id) OR (ir.manifestation_id = 0 AND ir.item_id = i.item_id AND i.owner_library_id = ly.library_id)) ";

					$query .= "GROUP BY ir.request_id ";
					$manageableString = "'" . join("','",(ItemPeer::getItemStatusManageable())) . "'";
					$query .= "HAVING sum(i.item_status IN (" . $manageableString . ")) = 0 OR sum(i.item_status IN (" . $manageableString . ")) IS NULL";

					$pdo = $connection->prepare($query);
					$pdo->execute();
					$requestIds = $pdo->fetchAll(PDO::FETCH_COLUMN);

					$criteria->addAnd(ItemRequestPeer::REQUEST_ID, $requestIds, Criteria::IN);
				}
				else
				{
					if (!is_null($toLibraryIdFilter) && !($this->getManaged()))
						$criteria->add(ItemRequestPeer::DELIVERY_LIBRARY_ID, $toLibraryIdFilter);
				}

				if (!is_null($statusFilter))
				{
					if (is_array($statusFilter) && (count($statusFilter) > 0))
						$criteria->addAnd(ItemRequestPeer::REQUEST_STATUS , $statusFilter, Criteria::IN);
				}

				if (!is_null($sectionFilter))
					$criteria->addAnd(ItemPeer::SECTION, $sectionFilter . '%', Criteria::LIKE);

				if (!is_null($collocationFilter))
					$criteria->addAnd(ItemPeer::COLLOCATION, $collocationFilter . '%', Criteria::LIKE);

				if (!is_null($bibObjFilter))
				{
					$criteria->addJoin(ItemRequestPeer::MANIFESTATION_ID, ManifestationPeer::MANIFESTATION_ID, Criteria::INNER_JOIN);
					$criteria->addAnd(ManifestationPeer::BIB_TYPE_FIRST, $bibObjFilter);
				}
			}

			//$loanableItemsByLibraryFlag = false;
			$loanableItemsByAllFlag = false;
			$loanableItemsByManifestationFlag = false;
			$object = $this->getObject();

			if (!is_null($object))
			{
				switch (get_class($object))
				{
					case 'Patron':
						$this->PatronColumn->setVisible(false);
						$criteria->addAnd(ItemRequestPeer::PATRON_ID, $object->getId());
						break;

					case 'Item':
						$this->ItemColumn->setVisible(false);
						$criteria->addAnd(ItemRequestPeer::ITEM_ID, $object->getId());

						if ($object->isOoc())
						{
							$loanableItemsByManifestationFlag = $object->isLoanableByMyLibrary($userLibraryId);
							$loanableItemsByAllFlag = $object->isLoanableByAll();
						}
						else
						{
							$manifestation = $object->getManifestation();
							$loanableItemsByManifestationFlag = $manifestation->isLoanableByMyLibrary($userLibraryId);
							$loanableItemsByAllFlag = $manifestation->isLoanableByAll();
						}
						break;

					case 'Manifestation':
						$this->ItemColumn->setVisible(false);

						$criteria->addAnd(ItemRequestPeer::MANIFESTATION_ID, $object->getId());
						$manifestation = $object;
						$loanableItemsByManifestationFlag = $manifestation->isLoanableByMyLibrary();
						$loanableItemsByAllFlag = $manifestation->isLoanableByAll();
						break;

					case 'Issue':
						$this->ItemColumn->setVisible(false);

						$criteria->addAnd(ItemRequestPeer::ISSUE_ID, $object->getId());
						$issue = $object;
						$loanableItemsByManifestationFlag = $issue->isLoanableByMyLibrary();
						$loanableItemsByAllFlag = $issue->isLoanableByAll();
						break;
				
					case 'ItemRequest':
						break;
				}
			}

			if (!is_null($this->getManaged()))
				$criteria->addAscendingOrderByColumn(ItemRequestPeer::MANIFESTATION_ID);
			
			$criteria->addAscendingOrderByColumn(ItemRequestPeer::REQUEST_DATE);

			$this->setGlobalCriteria(clone $criteria);
			$totalCount = ItemRequestPeer::doCount($criteria);

			$currentIndexPage = $this->Grid->getCurrentPage();
			$pageSize = $this->Grid->getPageSize();

			if (!$this->getShrink()
					&& ($pageSize > 0)
					&& !is_null($currentIndexPage)
					&& ($currentIndexPage >= 0) )
				{
					$criteria->setLimit($pageSize);
					$criteria->setOffset($currentIndexPage * $pageSize);
				}

				$requests = ItemRequestPeer::doSelect($criteria);

			if ($this->getShrink())
			{
				$successCount = $this->shrinkItemRequest(	$requests,
															$userLibraryId,
															$pageSize,
															$currentIndexPage );
			}
			else
			{
				$successCount = $totalCount;
			}

			$this->setFoundNumber($successCount);
			$this->setStoredPageIndex($this->Grid->getCurrentPage());

			$checkedList = $this->getChecked();
			$masterCheck = $checkedList['all'];
			$this->resetBarcodes();
			$datasource = array();

			$criteriaLocal = $this->calculateReservationCriteria($fromLibraryIdFilter);
			$criteriaNonLocal = $this->calculateReservationCriteria($fromLibraryIdFilter, false);
			$critLoan = new Criteria();
			$showPatronLoanNumber = $this->getShowPatronLoanNumber();

			/** 
			 * main item_request cycle
			 */
			foreach ($requests as $request)
			{
				/** @var $request ItemRequest */
				$requestId = $request->getId();
				$manifestation = $request->getManifestation();
				$manifestationId = intval($request->getManifestationId());
				$item = $request->getItem();
				$itemId = intval($request->getItemId());
				$issue_id = intval($request->getIssueId());
				$issue = $request->getIssue();

				$deliveryLibraryId = $request->getDeliveryLibraryId();
				$deliveryLibraryLabel = $request->getDeliveryLibraryLabel(true);

				//$itemRequestFlag = false;
				$wantedUrl = '';
				$wantedText = '';
				$wantedImageUrl = '';
				//$renewCount = 0;

				if (!is_null($this->getManaged()))
				{
					if ($issue instanceof Issue)
					{
						$objType = 'Issue';
						$objId = $issue_id;
					}
					else
					{
						$objType = 'Manifestation';
						$objId = $manifestationId;
					}

					$criteriaDelivery = $this->_loanmanager->CalculateReservationCriteria(	$deliveryLibraryId,
																							true,
																							$this->getManaged());

					if ($this->getOocMode())
					{
						$myItems = $this->getMyItems(	$fromLibraryIdFilter,
														'OocMode',
														$itemId,
														$criteriaLocal,
														$issue_id);
					}
					else
					{
						$myItems = $this->getMyItems(	$fromLibraryIdFilter,
														$objType,
														$objId,
														$criteriaLocal,
														$issue_id);
					}

					$localItemsNumber = count($myItems);
					$alienItemsNumber = $this->_loanmanager->CountRequestedObjects(	$fromLibraryIdFilter,
																					$objType,
																					$objId,
																					$this->getManaged(),
																					clone($criteriaNonLocal),
							
																					$issue_id );
					
					$localItemsCollocationArray = array();
					$localItemsCollocationRepArray = array();
					$minUsageCount = 200042;
					$itemToLoan = null;
					$outer = false;
					$foundHomed = false;

					foreach ($myItems as $itemCycle)
					{
						$cicleItemId = $itemCycle->getItemId();
						$usageCount = $itemCycle->getUsageCount();

						// the true on the next 2 calls are there because we want inventory number
						$localItemsCollocationArray[$itemCycle->getItemId()] = $itemCycle->getHyperLinkCollocationCombo(	$formId = $this->getPage()->getForm()->getClientId(),
																															$fromLibraryIdFilter,
																															true);

						$localItemsCollocationRepArray[$itemCycle->getItemId()]  = $itemCycle->getCollocationCombo(	null,
																													true);
						$this->addBarcode($itemCycle->getBarcode());

						if ($this->_loanmanager->IsItemAvailable(	$itemCycle,
																	$request->getDeliveryLibraryId() ))
						{
							if ($cicleItemId == $itemId)
							{
								/* preferred item found, wins over everything else */
								$itemToLoan = $cicleItemId;
								break;
							}
							
							if (($itemCycle->getHomeLibraryId() == $deliveryLibraryId) &&
									(!$foundHomed || !$itemToLoan || ($usageCount < $minUsageCount))) {
								/* item homed in delivery library found, wins over everything else */
								$minUsageCount = $usageCount;
								$itemToLoan = $cicleItemId;
								$foundHomed = true;
							}
							elseif (!$foundHomed &&
									(!$outer || ($outer && $itemCycle->getHomeLibraryId()!=$userLibraryId)) &&
									(!$itemToLoan || ($usageCount < $minUsageCount)))
							{
								$minUsageCount = $usageCount;
								$itemToLoan = $cicleItemId;
							
								if ($itemCycle->getHomeLibraryId() != $userLibraryId)
									$outer = true;
							}
						}
					}

					$localItemsCollocationString = '';
					$localItemsCollocationReportString = '';

					foreach ($localItemsCollocationArray as $id => $string)
						$localItemsCollocationString .= '<br />-&nbsp;' . trim($string); // . '</li>';

					foreach ($localItemsCollocationRepArray as $id => $string)
						$localItemsCollocationReportString .= $string."\n";

					$localItemsString = $localItemsNumber;
					$localItemsString .= $localItemsCollocationString;
					$alienItemsString = $alienItemsNumber;
				}

				$patronId = $request->getPatronId();
				if (!is_null($this->getManaged()))
				{
					$flagCode = ClavisRequestManager::no_flag;
					if ($alienItemsNumber < 1)
					{
						$flagCode = ClavisRequestManager::yellow_flag;
						if ($localItemsNumber < 2)
							$flagCode = ClavisRequestManager::red_flag;
					}
				}

				$wantedUrl = '';
				$wantedText = '';
				$wantedImageUrl = '';
				$wantedPopupUrl = '';
				$itemLibraryId = null;
				$itemLibraryLabel = null;

				if ($item instanceof Item)
				{
					$itemLibraryId = $item->getHomeLibraryId();
					$itemLibraryLabel = $item->getHomeLibraryLabel(true);

					$wantedTitle = $item->getTrimmedTitle(70);
					$wantedId = $item->getId();
					if ($wantedId > 0 && $wantedTitle != '')
					{
						if (get_class($object) == "Manifestation")
						{
							if ($item->isLoanableByMyLibrary())
							{
								$wantedUrl = "index.php?page=Catalog.ItemViewPage&id=" . $wantedId;
								$wantedImageUrl = "themes/Default/icons/nav_plain_green-16.png";
							}
							else
							{
								$wantedUrl = "index.php?page=Catalog.ItemViewPage&id=" . $wantedId;
								$wantedImageUrl = "themes/Default/icons/nav_plain_red-16.png";
							}

							$wantedPopupUrl = "Circulation.ItemRequestListPopup&id=" . $item->getManifestationId() . "&requestId=" . $request->getId();
						}
						else
						{
							$wantedUrl = "index.php?page=Catalog.ItemViewPage&id=" . $wantedId;
							$wantedText = $wantedTitle;
						}
					}
				}	
				else
				{
					if ($manifestation instanceof Manifestation)
					{
						$titleQueue = '';

						if ($issue instanceof Issue)
							$titleQueue =  ' (' . Prado::localize('fasc') . ': ' . $issue->getIssueCombo(false) . ')';
						
						$wantedTitle = $manifestation->getTrimmedTitle(130) . $titleQueue;

						$wantedId = $manifestation->getId();
						if ($wantedId > 0 && $wantedTitle != '')
						{
							if ($loanableItemsByManifestationFlag)
							{
								$wantedUrl = "index.php?page=Catalog.Record&manifestationId=" . $wantedId;
								$wantedImageUrl = "themes/Default/icons/nav_plain_green-16.png";
							}
							elseif ($loanableItemsByAllFlag)
							{
								$wantedUrl = "index.php?page=Catalog.Record&manifestationId=" . $wantedId;
								$wantedImageUrl = "themes/Default/icons/nav_plain_yellow-16.png";
							}
							else
							{
								$wantedUrl = "index.php?page=Catalog.Record&manifestationId=" . $wantedId;
								$wantedImageUrl = "themes/Default/icons/nav_plain_red-16.png";
								$wantedText = $wantedTitle;
							}
						}
						
						$wantedPopupUrl = "Circulation.ItemRequestListPopup&id=" . $manifestationId . "&requestId=" . $request->getId();
					}
				}

				$managerId = 0;
				$managerName = '';
				$statusString = '';

				$itemRequestStatus = $request->getRequestStatus();

				if (is_null($this->getManaged()))
				{
					if (!is_null($itemRequestStatus))
						$statusString = LookupValuePeer::getLookupValue('ITEMREQUESTSTATUS', $itemRequestStatus);

					if ($itemRequestStatus == ItemRequestPeer::STATUS_WORKING)
					{
						$librarian = $request->getLibrarian();
						
						if ($librarian instanceof Librarian)
						{
							$managerId = $librarian->getLibrarianId();
							$managerName = $librarian->getCompleteName();
						}
					}
				}
				
				$itemRequestStatusActive = (in_array($itemRequestStatus, ItemRequestPeer::getActiveStatus()));

				$creatorUrl = $creatorName = '';
				$creatorId = $request->getCreatedBy();
				
				if ($creatorId == 1)
				{
					$creatorName = Prado::localize('da Opac');
					$creatorUrl = '';
				}
				else
				{
					$librarian = $request->getLibrarianRelatedByCreatedBy();
					
					if ($librarian instanceof Librarian)
					{
						$creatorUrl = $librarian->getUrlPage();
						$creatorName = $librarian->getUrlName();
					}
				}

				if (!is_null($this->getManaged()))
				{
					$deliveryLibraryNumber = $this->_loanmanager->CountRequestedObjects($deliveryLibraryId,
																						$objType,
																						$objId,
																						$this->getManaged(),
																						clone($criteriaDelivery) );
				}
				else
				{
					$deliveryLibraryNumber = 0;
					$localItemsString = $alienItemsString = $flagCode = $itemToLoan = null;
				}

				if (array_key_exists($requestId, $checkedList))
				{
					$checked = $checkedList[$requestId];
				}
				else
				{
					$checked = false;
				}

				if ($masterCheck)
					$checked = !$checked;

				$title = $shortTitle = '';
				
				if ($manifestation instanceof Manifestation)
				{
					$title = $manifestation->getTrimmedTitle(140);
					$shortTitle = $manifestation->getTitle();
				}
				else
				{
					if ($item instanceof Item)
					{
						$title = $item->getTrimmedTitle(140);
						$shortTitle = $item->getTitle();
					}
				}

				$toolTip = '';
				$canLoan = false;
				$patron = $request->getPatron();
				
				if ($patron instanceof Patron)
				{
					$navigateUrl = $patron->getNavigateUrl() . $patronId;
					$patronCompleteName = $patron->getCompleteName();

					if ($showPatronLoanNumber)
					{
						$critLoan->clear();
						$critLoan->add(LoanPeer::PATRON_ID, $patronId);
						$critLoan->add(LoanPeer::LOAN_STATUS, ItemPeer::getLoanStatusActive(), Criteria::IN);
						$loanCount = LoanPeer::doCount($critLoan);
						
						if ($loanCount > 0)
							$patronCompleteName .= "&nbsp;(<b>$loanCount</b>)";
					}

					$canLoan = ($this->_loanmanager->IsPatronAllowedToLoan($patron, $itemId) == ClavisLoanManager::OK);
				}
				else
				{
					$externalLibraryId = intval($request->getExternalLibraryId());
					$externalLibrary = LibraryQuery::create()->findPk($externalLibraryId);
					
					if ($externalLibrary instanceof Library)
					{
						$patronCompleteName = $externalLibrary->getLabel(true, false, true, 30);
						$navigateUrl = "index.php?page=Library.LibraryViewPage&id=" . $externalLibrary->getLibraryId();
						
						$toolTip = $externalLibrary->getTrimmedDescription(100)
										. ' (' . Prado::localize('consorzio') . ": "
										. $externalLibrary->getConsortiaString(100) . ')';

						$canLoan = ($this->_loanmanager->isExternalLibraryAllowedToLoan($externalLibraryId) == ClavisLoanManager::OK);
					}
					else
					{
						$patronCompleteName = "(" . Prado::localize("senza nome") . ")";
						$navigateUrl = '';
					}
				}

				$maxDistanceOutput = $this->_llibraryActive ? $request->getMaxDistance() : null;
				$requestTypeOutput = $this->_requestTypeActive ? $request->getRequestType() : "";
				
				$requestType = $request->getRequestType();

				if ($this->_requestTypeActive
						&& !is_null($requestType))
				{
					$requestTypeString = '<br /><b>[' . ItemRequestPeer::getRequestTypeString($requestType) . ']</b>';
				}
				else
				{
					$requestTypeString = '';
				}
				
				$datasource[] = array(	'WantedUrl' => $wantedUrl,
										'WantedText' => $wantedText,
										'WantedImageUrl' => $wantedImageUrl,
										'WantedPopupUrl' => $wantedPopupUrl,
										'ItemLibraryId' => $itemLibraryId,
					
										'ItemLibraryLabel' => $itemLibraryLabel,
										'checked' => $checked,
										'manifestationId' => $manifestationId,
										'requestId' => $requestId,
										'title' => $title,
					
										'shortTitle' => $shortTitle,
										'localItemsString' => $localItemsString,
										'alienItemsString' => $alienItemsString,
										'flagCode' => $flagCode,
										'deliveryLibraryId' => $deliveryLibraryId,
					
										'deliveryLibraryLabel' => $deliveryLibraryLabel,
										'deliveryLibraryNumber' => $deliveryLibraryNumber,
										'patronId' => $patronId,
										'patronCompleteName' => $patronCompleteName,
										'patronNavigateUrl' => $navigateUrl,
					
										'patronNavigateUrlToolTip' => $toolTip,
										'requestDate' => $request->getRequestDate('U'),
										'expireDate' => $request->getExpireDate('U'),
										'requestStatus' => $itemRequestStatus,
										'statusString' => $statusString,
					
										'requestStatusActive' => $itemRequestStatusActive,
										'canLoan' => $canLoan,
										'itemToLoan' => $itemToLoan,
										'managerId' => $managerId,
										'managerName' => $managerName,

										'creatorId' => $creatorId,
										'creatorUrl' => $creatorUrl,
										'creatorName' => $creatorName,
										'viewObjectLink' => !$this->ItemColumn->getVisible(),
										'maxDistance' => $maxDistanceOutput,
					
										'requestTypeString' => $requestTypeString );
			}		// end of requests foreach cycle

			$this->setStoredDataSource($datasource);
		}

		$this->setLocalItems($this->_localItems);

		$this->PopulatedFlag->setValue("true");
		$this->NoSearchPanel->setVisible(false);
		
		$this->Grid->setVirtualItemCount($successCount);
		$this->Grid->setDataSource($datasource);
		$this->Grid->dataBind();
		
		if (!is_null($storedIndexPage))
			$this->Grid->setCurrentPage($storedIndexPage);
		
		$this->FoundNumber->setText($successCount);
		
		/**
		 * This part (alert about changes into database, not matched by the
		 * onscreen search, has been required to be hidden
		 * 
		$reloadEnabled = (count($this->getStoredDataSourceOff()) > 0);
		$this->ReloadAlertPanel->setCssClass($reloadEnabled ? 'panel_on_inline' : 'panel_off');
		$this->ReloadAlertPanel2->setCssClass($reloadEnabled ? 'panel_on_inline' : 'panel_off');
		if ($this->getPage()->getIsCallback())
		{
			$this->ReloadAlertPanel->render($this->getPage()->createWriter());
			$this->ReloadAlertPanel2->render($this->getPage()->createWriter());
		}
		 */
	}

	public function onColorize($sender, $param)
	{
		$item = $param->Item;

		if (($item->getItemType() != "Item") && ($item->getItemType() != "AlternatingItem"))
			return false;
					
    	$flagCode = $item->DataItem['flagCode'];
    	if (!is_null($flagCode) && ($flagCode != ClavisRequestManager::no_flag))
    		$item->setCssClass('evidenced_light');
	}

	public function onChangePage($sender,$param)
	{
		$newIndex = $param->NewPageIndex;
		$this->Grid->setCurrentPage($newIndex);
		$this->setStoredPageIndex($newIndex);
		$this->populate();
	}

	public function getPopupFlag()
	{
		return $this->getPage()->isPopup();
	}

	public function resetPagination()
	{
		$this->Grid->setCurrentPage(0);
	}

	/**
	 * It changes the status (on/off) of the checkbox of one chosen
	 * row item of datagrid.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onFlipChecked($sender, $param)
	{
		$index = $sender->Parent->Parent->ItemIndex;
		$dataSource = $this->parseDataSource($this->getStoredDataSource());

		$newStatus = $sender->getChecked();
		$checked = $this->getChecked();

		if (array_key_exists($index, $dataSource))
		{
			$row = $dataSource[$index];
		}
		else 
		{
			return false;
		}

		if (array_key_exists('requestId', $row))
		{
			$requestId = $row['requestId'];
		}
		else 
		{
			return false;
		}

		if (array_key_exists('all', $checked))
		{
			$checkedAll = $checked['all'];
		}
		else
		{
			return false;
		}

		if ($newStatus != $checkedAll)
		{
			$checked[$requestId] = true;
		}
		else
		{
			unset($checked[$requestId]);
		}

		$this->setChecked($checked);
	}

	public function onMasterChecked($sender, $param)
	{
		$newStatus = $sender->getChecked();
		$this->resetChecked($newStatus);
		$gridItems = $this->Grid->getItems();
		
		foreach($gridItems as $item)
			$item->CheckColumn->Checked->setChecked($newStatus);
	}

	public function onNewLoan($sender, $param)
	{
		$parameter = $param->getCommandParameter();
		$itemId = $parameter['itemId'];
		$requestId = $parameter['requestId'];

		if (($itemId > 0) && ($requestId > 0))
			$this->getPage()->gotoPageWithReturn(	"Circulation.NewLoan",
													array(	'itemId'=> $itemId,
															'requestId' => $requestId) );
	}

	public function onPopupLoan($sender, $param)
	{
		$this->getPage()->cleanMessageQueue();

		$parameter = $param->getCommandParameter();
		$itemId = intval($parameter['itemId']);
		$itemRequestId = intval($parameter['requestId']);

		if (($itemId > 0) && ($itemRequestId > 0))
		{
			$toRefreshFlag = false;

			$item = ItemPeer::retrieveByPK($itemId);
			$newDueDate = $this->_loanmanager->CalculateDueDate($item);
			
			$itemRequest = ItemRequestQuery::create()->findPk($itemRequestId);
			$destination = $itemRequest->getLoanDestinationObject();

			if ($destination instanceof Patron)
			{
				$destinationName = $destination->getCompleteName();
			}
			elseif ($destination instanceof Library)
			{
				$destinationName = $destination->getLabel(true, true, true);
			}
			else
			{
				$destinationName = '(' . Prado::localize('errore sul nome del destinatario') . ')';
			}

			$clavisLibrarian = $this->getUser();
			$deliveryLibrary = $itemRequest->getDeliveryLibrary();

			$reqval = $this->_loanmanager->DoManageRequest(	$itemRequest,
															$clavisLibrarian);
			switch ($reqval)
			{
				case ClavisLoanManager::OK :
					$retval = $this->_loanmanager->DoLoanItem(	$item,
																$destination,
																$clavisLibrarian,
																$deliveryLibrary,
																$itemRequest,
																$newDueDate);
					switch ($retval)
					{
						case ClavisLoanManager::RSV_ALREADYMANAGED:
							$this->getPage()->enqueueMessage(Prado::localize("L'esemplare '{title}' [barcode: {barcode}] è già in gestione ad un altro operatore, per cui non è possibile prestarlo",
																					array(	'title' => $item->getTrimmedTitle(40),
																							'barcode' => $item->getBarcode())),
																ClavisMessage::ERROR);
							
							$toRefreshFlag = true;
							break;

						case ClavisLoanManager::LOAN_ILLREQUESTED :
							$this->getPage()->enqueueMessage(Prado::localize("Prenotazione soddisfatta ed esemplare '{itemTitle}' [barcode: {itemBarcode}] messo in 'pronto al transito' per '{name}'",
																					array(	'itemTitle' => $item->getTrimmedTitle(40),
																							'itemBarcode' => $item->getBarcode(),
																							'name' => $destinationName)),  // Inserita richiesta di interprestito
																ClavisMessage::CONFIRM);
							
							$toRefreshFlag = true;
							break;

						case ClavisLoanManager::LOAN_READYTOLOAN :
							$labelText = Prado::localize("Prenotazione soddisfatta ed esemplare '{itemTitle}' [barcode: {itemBarcode}] messo in 'pronto al prestito' per '{name}'",
																					array(	'itemTitle' => $item->getTrimmedTitle(40),
																							'itemBarcode' => $item->getBarcode(),
																							'name' => $destinationName));  // Inserita richiesta di interprestito
							// ready-to-loan automatic notification
							if ((ClavisParamQuery::getParam('CLAVISPARAM','AutoEmailLoanReady') == 'true')
									&& ($destination instanceof Patron) )
							{
								$ret = NotificationHelper::sendNotificationEmail(	'readyforloan',
																					$destination,
																					$clavisLibrarian->getLibrarian(),
																					$deliveryLibrary,
																					array($item->getCurrentLoanId()));
								
								if ($ret)
								{
									$item->setNotifyCount($item->getNotifyCount() + 1);
									$item->save();
									$loan = $item->getLoanRelatedByCurrentLoanId();
									$loan->setNotifyCount($loan->getNotifyCount() + 1);
									$loan->save();
									
									$labelText .= Prado::localize(' - notificato automaticamente via email');
								}
							}
							
							$this->getPage()->enqueueMessage($labelText,
																ClavisMessage::CONFIRM);
							
							$toRefreshFlag = true;
							break;

						case ClavisLoanManager::LOAN_RESERVED :
							$this->getPage()->enqueueMessage(Prado::localize("Inserita prenotazione"),
																ClavisMessage::INFO);
							
							$toRefreshFlag = true;
							break;

						case ClavisLoanManager::LOAN_LOANED :
							$this->getPage()->enqueueMessage(Prado::localize("Prenotazione soddisfatta, esemplare '{itemTitle}' [barcode: {itemBarcode}] prestato a '{name}'",
																					array(	'itemTitle' => $item->getTrimmedTitle(40),
																							'itemBarcode' => $item->getBarcode(),
																							'name' => $destinationName)),
																ClavisMessage::CONFIRM);
							
							$toRefreshFlag = true;
							break;

						case ClavisLoanManager::LOAN_LOANALREADYEXISTS :
							$this->getPage()->enqueueMessage(Prado::localize("Errore: il prestito è già in corso"),
																ClavisMessage::ERROR);
							
							break;

						case ClavisLoanManager::ERROR :
						default:
							$this->getPage()->enqueueMessage(Prado::localize("Prestito fallito"),
																ClavisMessage::ERROR);
							
							break;
					}

					break;

				case ClavisLoanManager::RSV_ALREADYMANAGED:
					$this->getPage()->enqueueMessage(Prado::localize("La prenotazione con id: {id} è già in gestione",
																			array('id' => $itemRequestId)),
														ClavisMessage::ERROR);
					
					break;

				case ClavisLoanManager::RSV_ALREADYCLOSED:
					$this->getPage()->enqueueMessage(Prado::localize("La prenotazione con id: {id} è già soddisfatta o chiusa o annullata",
																			array('id' => $itemRequestId)),
														ClavisMessage::ERROR);
					
					break;

				case ClavisLoanManager::LOAN_PATRONNOTENABLED:
					$this->getPage()->enqueueMessage(Prado::localize("La prenotazione con id: {id} non è soddisfacibile perché l'utente non è ammesso al prestito",
																			array('id' => $itemRequestId)),
														ClavisMessage::ERROR);
					
					break;

				case ClavisLoanManager::LOAN_EXTERNALLIBRARYNOTENABLED:
					$this->getPage()->enqueueMessage(Prado::localize("La prenotazione con id: {id} non è soddisfacibile perché la biblioteca esterna, destinataria del prestito extrasistema, non è ammessa al prestito",
																			array('id' => $itemRequestId)),
														ClavisMessage::ERROR);
					
					break;

				case ClavisLoanManager::ERROR:
				default:
					$this->getPage()->enqueueMessage(Prado::localize("Errore sconosciuto sulla presa in gestione della prenotazione con id: {id}",
																			array('id' => $itemRequestId)),
														ClavisMessage::ERROR);
			}

			if ($toRefreshFlag)
			{
				$this->getPage()->flushDelayedMessage();

				$this->getApplication()->getSession()->add('ZebraItemRequestId', $itemRequestId);
				$this->getApplication()->getSession()->add('UpdateItemId', $itemId);
			}
			else
			{
				$this->getPage()->flushMessage();
			}

			$this->getPage()->getClientScript()->registerEndScript(__CLASS__.'_js','onReturn(\'\',\'\',true);');
		}
		else
		{
			Prado::log('errore in '.__CLASS__);
		}
	}

	public function globalRefresh()
	{
		$this->populate();
	}


	/**
	 * It takes away itemrequests according to:
	 * - the requesting library can accomplish the request by means of
	 * 	am item they have in there
	 * - requests, for the same manifestation, which exceed the number of 6
	 * 	(in order by request_date)
	 *
	 * The results get paginated according to the given parameters
	 *
	 * @param array $requests, by reference
	 * @param int $userLibraryId
	 * @param int $pageSize (opt., old)
	 * @param int $currentPage (opt., old)
	 *
	 * @return array  The results, in an array if request_ids
	 */
	public function shrinkItemRequest(&$requests = array(),
										$userLibraryId = null,
										$pageSize = null,
										$currentPage = null)
	{
		/** @var $request ItemRequest */
		/** @var $item Item */
		if (count($requests) == 0)
			return 0;
		
		$userLibraryId = intval($userLibraryId);
		$pageSize = intval($pageSize);

		$comparisonId = null;
		$counter = 0;
		$shrinkedRequests = array();
		foreach ($requests as $request)
		{
			$cycleCheck = false;
			$okIncrement = false;
			$currentManifestationId	= intval($request->getManifestationId());

			if ($currentManifestationId > 0)
			{
				/// classic case (not ooc)
				if (is_null($comparisonId) || ($currentManifestationId != $comparisonId))
				{
					$comparisonId = $currentManifestationId;
					$counter = 1;
				}
				else
				{
					$cycleCheck = true;
				}
			}
			else
			{
				/// ooc (out of catalog)
				$currentItemId = intval($request->getItemId());
				if (is_null($comparisonId) || ($currentItemId != $comparisonId))
				{
					$comparisonId = $currentItemId;
					$counter = 1;
				}
				else
				{
					$cycleCheck = true;
				}
			}

			if ($cycleCheck)
			{
				if ($counter > 5)     /// a number of max 6 requests is shown ...
					continue;

				$okIncrement = true;
			}

			/**
			 * check: if the manifestation, related to the request, has a limit
			 * of loanability due to the patron's age or to the block of the
			 * manifestation itself until a certain date.
			 */
			$manifestation = $request->getManifestation();
			$patron = $request->getPatron();

			if ($manifestation instanceof Manifestation)
			{
				if (!$item->checkLoanableSince() ||
						(($patron instanceof Patron) && (!$this->_loanmanager->IsRatingAllowed($manifestation, $patron)
															|| $this->_loanmanager->IsPatronAllowedToLoan($patron) != ClavisLoanManager::OK)))
					continue;
			}

			if ($userLibraryId > 0)
			{
				/**
				 *  check: in the case the request was made by item, and the system's parameter
				 * 'ReservationOnitemonlyForce' is set to true, it checks if the actual library
				 * of the item is my actual library, and only in this case it is shown.
				 */
				$item = $request->getItem();
				if ($item instanceof Item)
				{
					if (($item->getActualLibraryId() != $userLibraryId || !(in_array($item->getLoanStatus(), ItemPeer::getLoanStatusAvailable())))
							&& (ClavisParamPeer::getParam('CLAVISPARAM','ReservationOnitemonlyForce') == "true" || $item->isExternal()))
						continue;
				}

				unset ($item);

				/** check: if there are other items, which can satisfy this request, in the
				 * delivery library that was choosen (and in this case, the delivery library
				 * is not my library, than skip loan ... because an interlibrary loan
				 * can be avoided when a local loan can do the same ...
				 */
				$deliveryLibraryId = intval($request->getDeliveryLibraryId());

				$criteriaDelivery = $this->_loanmanager->CalculateReservationCriteria(	$deliveryLibraryId,
																						true,
																						false,
																						true);  // ignore consultations

				$deliveryLibraryNumber = $this->_loanmanager->CountRequestedObjects(	$deliveryLibraryId,
																						'Manifestation',
																						$currentManifestationId,
																						false,
																						clone($criteriaDelivery));

				if (($deliveryLibraryNumber > 0) && ($deliveryLibraryId != $userLibraryId))
					continue;
			}

			$shrinkedRequests[] = $request;
			unset ($request);
			if ($okIncrement)
				$counter++;
		}

		$total = count($shrinkedRequests);

		if (($pageSize > 0) && !is_null($currentPage) && ($currentPage >= 0))
			$requests = array_slice($shrinkedRequests, $pageSize * $currentPage, $pageSize);
		else
			$requests = $shrinkedRequests;

		return count($shrinkedRequests);
	}

	public function onChooseRecord($sender, $param)
	{
		$manifestationId = intval($sender->getValue());
		
		if ($manifestationId > 0)
		{
			$manifestation = ManifestationQuery::create()->findPk($manifestationId);

			if (!($manifestation instanceof Manifestation))
			{
				$this->getPage()->writeMessage(Prado::localize('Errore nella scelta della notizia'),
													ClavisMessage::ERROR);
				
				return false;
			}
		}

		$index = $sender->Parent->Parent->ItemIndex;
		$dataSource = $this->parseDataSource($this->getStoredDataSource());
		$row = $dataSource[$index];
		
		$requestId = intval($row['requestId']);
		$request = ItemRequestQuery::create()->findPk($requestId);

		if (!($request instanceof ItemRequest))
		{
			$this->getPage()->writeMessage(Prado::localize('Errore nella scelta della notizia'),
												ClavisMessage::ERROR);

			return false;
		}

		$request->setManifestationId($manifestationId);
		$request->setItem(null);   // request only on manifestation
		$request->save();

		$this->globalRefresh();
		$this->getPage()->writeMessage(Prado::localize("Modificata la prenotazione con id: {requestId}. Ora l'oggetto della prenotazione è la notizia con id: {manifestationId}, titolo: '{title}'.",
															array(	'requestId' => $requestId,
																	'manifestationId' => $manifestationId,
																	'title' => $request->getTrimmedTitle(40) )),
											ClavisMessage::CONFIRM);
	}

}