<?php

/**
 * ClavisTaskList
 *
 * @author Max Pigozzi <mpigozzi@e-portaltech.it>
 * @link http://www.e-portaltech.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @license http://www.e-portaltech.it/license/
 *
 */

class ClavisTaskList extends TTemplateControl
{
	public function onInit($param)
	{
		parent::onInit($param);

		// first execution
		if (!$this->getPage()->getIsPostBack()
				&& !$this->getPage()->getIsCallback())
		{
			$this->cancelSearchFields();
			
			$this->LibraryFilter->setDataSource(LibraryPeer::getLibrariesHashWithBlank(null, null, true, 35));
			$this->LibraryFilter->dataBind();
		}
	}

	public function populate($newTaskMode = false)
	{
		$this->populateActiveTaskGrid($newTaskMode);
	}

	private function populateActiveTaskGrid($newTaskMode = false)
	{
		$pageSize = intval($this->TaskActiveGrid->getPageSize());
		$currentIndexPage = intval($this->TaskActiveGrid->getCurrentPage());

		/**
		 * If we are here for grid repopulation after a request
		 * for creating a new task, a new task is created also
		 * in the database.
		 */
		if ($newTaskMode)
		{
			$newTask = new LibrarianTask();
			
			$newTask->setTaskStatus(LibrarianTaskPeer::STATUS_PENDING);
			$newTask->setDonePercent(0);
			$newTask->setAssignedLibrarianId($this->getUser()->getId());
			$newTask->setLibraryId($this->getUser()->getActualLibraryId());		
			
			$newTask->save();
			$newTaskId = $newTask->getTaskId();

			ChangelogPeer::logAction(	$newTask,
										ChangelogPeer::LOG_CREATE,
										$this->getUser(), 'creazione task con id=' . $newTaskId);

			$this->getPage()->writeMessage(Prado::localize("Task creato con id=") . $newTaskId,
												ClavisMessage::CONFIRM);
		}	
		
		$c = new Criteria();

        $library_filter_id = $this->LibraryFilter->getSelectedValue();
		if (($library_filter_id != '')
				&& ($library_filter_id != '0'))
	       	$c->addAnd(LibrarianTaskPeer::LIBRARY_ID, $library_filter_id);

        $librarian_name_filter = $this->LibrarianNameFilter->getSafeText();
        $librarian_lastname_filter = $this->LibrarianLastnameFilter->getSafeText();
        $librarian_filter_ids= array();

        $cc = new Criteria();

        if ($librarian_name_filter != '')
        	$cc->addAnd(LibrarianPeer::NAME, $librarian_name_filter);

        if ($librarian_lastname_filter != '')
        	$cc->addAnd(LibrarianPeer::LASTNAME , $librarian_lastname_filter);

		if (($librarian_name_filter != '')
				|| ($librarian_lastname_filter != ''))
		{
       		 $librarians = LibrarianPeer::doSelect($cc);
      	
			 foreach ($librarians as $librarian)
      		 	$librarian_filter_ids[] = $librarian->getLibrarianId();
      	}

    	if (count($librarian_filter_ids) > 0)
        	$c->addAnd(LibrarianTaskPeer::ASSIGNED_LIBRARIAN_ID, $librarian_filter_ids, Criteria::IN);

    	$status_filter = $this->StatusFilter->getSelectedValue();

        if (($status_filter == '0')
				|| (TPropertyValue::ensureString($status_filter) == ""))
		{
			if (!$this->ClosedFilter->getChecked())
			{	
				$c->addAnd(	LibrarianTaskPeer::TASK_STATUS,
							array(	LibrarianTaskPeer::STATUS_PENDING,
									LibrarianTaskPeer::STATUS_WORKING ),
							Criteria::IN);
			}
			else
			{
        		//$c->addAnd(LibrarianTaskPeer::TASK_STATUS, LibrarianTaskPeer::STATUS_DONE); //solo conclusi
				$c->addAnd(	LibrarianTaskPeer::TASK_STATUS,
							array(	LibrarianTaskPeer::STATUS_PENDING,
									LibrarianTaskPeer::STATUS_WORKING,
									LibrarianTaskPeer::STATUS_DONE ),
							Criteria::IN);
			}
		}
		else
		{
			$c->addAnd(LibrarianTaskPeer::TASK_STATUS, $status_filter);
        }
		
        if ($this->ExpiredFilter->getChecked())
		{
 	       	$c->addAnd(LibrarianTaskPeer::DUE_DATE, time(), Criteria::LESS_THAN);
        	$c->addAnd(LibrarianTaskPeer::END_DATE, null, Criteria::EQUAL);
        }

        $recCount = LibrarianTaskPeer::doCount($c);

		$c->setLimit($pageSize);
		$c->setOffset($currentIndexPage * $pageSize);

		// ordering
		if ($newTaskMode)
			$c->addDescendingOrderByColumn(LibrarianTaskPeer::DATE_CREATED);
		else
			$c->addDescendingOrderByColumn(LibrarianTaskPeer::DUE_DATE);

        $tasks = LibrarianTaskPeer::doSelect($c);
		$this->RecCounter->setText($recCount);

		$data = array();
		foreach ($tasks as $task)
		{
			$p = array();

			$dueDateTs = $task->getDueDate('U');
			$endDateTs = $task->getEndDate('U');
			if (is_null($dueDateTs))
				$expired = false;
			else
				$expired = (($dueDateTs < time())
								&& (is_null($endDateTs)));

			$p['id'] = $task->getTaskId();
			$p['TaskTitle'] = $task->getTaskTitle();
			
			$taskStatus = strtoupper($task->getTaskStatus());
			$p['TaskStatus'] = $taskStatus;

			$p['TaskStatusLabel'] = LookupValuePeer::getLookupValue('TASKSTATUS', $taskStatus);

			$p['DonePercent'] = $task->getDonePercent();

			$p['TaskNote'] = $task->getTaskNote();
			$assigned_librarian = LibrarianQuery::create()
									->findPk($task->getAssignedLibrarianId());
					
			if ($assigned_librarian instanceof Librarian)
				$p['AssignedLibrarian'] = $assigned_librarian->getCompleteName();
			else
				$p['AssignedLibrarian'] = '';

			$assigned_library = LibraryQuery::create()
									->findPk($task->getLibraryId());

			if ($assigned_library instanceof Library)
				$p['AssignedLibrary'] = $assigned_library->getLabel();
			else
				$p['AssignedLibrary'] = '';

			$p['DueDate'] = $task->getDueDate();
			$p['expired'] = $expired;
			
			$startDate = $task->getStartDate();
			
			if ($taskStatus != LibrarianTaskPeer::STATUS_PENDING)
				$p['StartDate'] = null;
			else
				$p['StartDate'] = $startDate;

			$p['StartDateStyle'] = ((($taskStatus == LibrarianTaskPeer::STATUS_WORKING)
										|| ($taskStatus == LibrarianTaskPeer::STATUS_DONE))
										&& !is_null($startDate)
									? "position:relative; display: inline;"
									: "display: none");

			$p['StartDateClass'] = (($taskStatus == LibrarianTaskPeer::STATUS_WORKING)
										&& !is_null($startDate)
									? "bordergreen"
									: "");
			
			if ($taskStatus != LibrarianTaskPeer::STATUS_DONE)
				$p['EndDate'] = null;
			else
				$p['EndDate'] = $endDateTs;
			$p['EndDateClass'] = (($taskStatus == LibrarianTaskPeer::STATUS_DONE)
										|| ($taskStatus == LibrarianTaskPeer::STATUS_PENDING)
										|| !is_null($endDateTs)
									? "panel_on_inline"
									: "panel_off");

			$data[] = $p;
		}

		$this->TaskActiveGrid->CurrentPageIndex = $currentIndexPage;
		$this->TaskActiveGrid->PageSize = $pageSize;
        $this->TaskActiveGrid->VirtualItemCount = $recCount;
		$this->TaskActiveGrid->setDataSource($data);
		$this->TaskActiveGrid->dataBind();
		
		if ($newTaskMode)
			return $newTaskId;
		else
			return null;
	}

	public function onSearchTask($sender, $param)
	{
		$this->TaskActiveGrid->setCurrentPageIndex(0);
		$this->getPage()->globalRefresh();
	}

	public function onCancel()
	{
		$this->searchCancel(null, null);
	}

	private function cancelSearchFields($param = null)
	{
		$this->LibraryFilter->setSelectedIndex(0);
		$this->LibrarianNameFilter->setText('');
		$this->LibrarianLastnameFilter->setText('');
		$this->StatusFilter->setSelectedIndex(0);
		
		if ($this->getPage()->getIsCallback())
		{
			if (is_null($param))
				$this->TaskSearchFilters->render($this->getPage()->createWriter());
			else
				$this->TaskSearchFilters->render($param->getNewWriter());
		}
	}
	
	public function onSearchCancel($sender, $param)
	{
		$this->cancelSearchFields($param);
		$this->globalRefresh();
	}

	public function getPopupFlag()
	{
		return $this->getPage()->IsPopup();
	}

	public function getUnlinkFlag()
	{
		return $this->getPage()->IsUnlink();
	}

	public function globalRefresh()
	{
		$this->TaskActiveGrid->setCurrentPage(0);
		$this->populate();
	}

	/**
	 * When we press the edit button in a row, we get to here
	 *  
	 */
	public function onEditTask($sender, $param)
	{
		$item = $sender->Parent->Parent;
		$taskId = $param->CommandParameter;

		$task = LibrarianTaskQuery::create()
					->filterByTaskId($taskId)
					->findOneOrCreate();
		
		if ($task instanceof LibrarianTask)
		{
			if ($task->getTaskStatus() == LibrarianTaskPeer::STATUS_DONE)
			{
				$this->getPage()->writeMessage(Prado::localize("Non è possibile modificare i dati di un task già chiuso"),
													ClavisMessage::WARNING);
				
				return false;
			}
		}
			
		$this->TaskActiveGrid->EditItemIndex = $item->ItemIndex;
		
		$this->populate();
	}

	public function onCancelTask($sender, $param)
	{
		$this->TaskActiveGrid->setEditItemIndex(-1);
		
		$this->populate();
	}

	public function onItemCommand($sender, $param)
	{

	}

	public function getListedLibraries()
	{
		return LibraryPeer::getLibrariesHashWithBlank(null, null, true, 35);
	}
	
	/**
	 * When the row (item) of the active datagrid has to be drawn,
	 * we pass through this part before leaving.
	 * 
	 */
	public function onItemCreated($sender, $param)
	{
		$item = $param->Item;
		
		if (($item->ItemType != 'EditItem')
				&& ($item->ItemType != 'Item')
				&& ($item->ItemType != 'AlternatingItem'))
			return false;

		$taskId = $this->TaskActiveGrid->DataKeys[$item->ItemIndex];
		$task = LibrarianTaskQuery::create()->findPk($taskId);
		if ($task instanceof LibrarianTask)
			$taskStatus = strtoupper($task->getTaskStatus());
		else
			$taskStatus = null;
		
		if ($item->ItemType == 'EditItem')	// edit mode only
		{
			// now made by using $this->getListedLibraries()
			$item->LibraryIdColumn->DropDownList->setDataSource(LibraryPeer::getLibrariesHashWithBlank(null, null, true, 35));
			$item->LibraryIdColumn->DropDownList->setStyle("width: 12em");

			$item->TaskStatusColumn->DropDownList->setDataSource(LookupValuePeer::getLookupClassValues('TASKSTATUS'));
			
			$item->DonePercentColumn->DropDownList->setStyle("width: 5em");
			
			$item->TaskNoteColumn->TextBox->setTextMode("MultiLine");
			$item->TaskNoteColumn->TextBox->setRows(10);

			if (!is_null($taskStatus))	// if task exists
			{
				$item->DueDateColumn->DueDateField->setTimeStamp($task->getDueDate('U'));
				///$item->StartDateColumn->StartDateField->setTimeStamp($task->getStartDate('U'));
				//$item->EndDateColumn->EndDateField->setTimeStamp($task->getEndDate('U'));
				
				/**
				 * The method pushSelection($component, $value) in the TClavisActiveDataGrid
				 * component is necessary whenever we want to select, in the onItemCreated()
				 * method in our actual situation, a particular value in a dropdown in the
				 * datagrid. The selection is actually performed inside the TClavisActiveDataGrid
				 * itself in the onPreRender() stage.
				 */
				$this->TaskActiveGrid->pushSelection(array(	$item->LibraryIdColumn->DropDownList,
															$task->getLibraryId()));
				
				$this->TaskActiveGrid->pushSelection(array(	$item->TaskStatusColumn->DropDownList,
															$taskStatus));
				
				$this->TaskActiveGrid->pushSelection(array(	$item->DonePercentColumn->DropDownList,
															$task->getDonePercent()));
				
				$assigned_librarian = LibrarianQuery::create()
									->findPk($task->getAssignedLibrarianId());
					
				if ($assigned_librarian instanceof Librarian)
				{
					$assignedLibraryCompleteName = $assigned_librarian->getCompleteName();
					$assignedLibraryId = $assigned_librarian->getLibrarianId();
				}
				else
				{
					$assignedLibraryCompleteName = '';
					$assignedLibraryId = 0;
				}
				
				$item->AssignedLibrarianIdColumn->AssignedLibrarian->setText($assignedLibraryCompleteName);
				$item->AssignedLibrarianIdColumn->AssignedLibrarianId->setValue($assignedLibraryId);
				
			}	// end of if task exists
			
			$item->StartDateColumn->ManageTaskButton->setStyle('display: none');
			$item->StartDateColumn->LeaveTaskButton->setStyle('display: none');
			$item->EndDateColumn->CloseTaskButton->setStyle('display: none');
			$item->EndDateColumn->ReopenTaskButton->setStyle('display: none');
		}	// end of edit mode
		elseif (($item->ItemType == 'Item')
					|| ($item->ItemType == 'AlternatingItem'))	// normal view mode only
		{
			if (!is_null($taskStatus))	// if task exists
			{
				$canEditTask = $this->getApplication()->getUser()->getEditPermission($task);
				
				$item->StartDateColumn->ManageTaskButton->setStyle($canEditTask
																		&& ($taskStatus == LibrarianTaskPeer::STATUS_PENDING)	// pendente (vergine)
																	? 'display: inline'
																	: 'display: none');
				
				$item->StartDateColumn->LeaveTaskButton->setStyle($canEditTask
																		&& ($taskStatus == LibrarianTaskPeer::STATUS_WORKING)	// in lavorazione
																	? 'display: inline'
																	: 'display: none');
				
				$item->EndDateColumn->CloseTaskButton->setStyle($canEditTask
																		&& ($taskStatus == LibrarianTaskPeer::STATUS_WORKING)	// in lavorazione
																	? 'display: inline'
																	: 'display: none');

				$item->EndDateColumn->ReopenTaskButton->setStyle($canEditTask
																		&& ($taskStatus == LibrarianTaskPeer::STATUS_DONE)	// chiuso
																	? 'display: inline'
																	: 'display: none');

				
				$item->ActiveActionColumn->EditButton->setVisible(	$canEditTask
																		&& ($taskStatus != LibrarianTaskPeer::STATUS_DONE));

				$item->ActiveActionColumn->DeleteButton->setVisible($canEditTask);
			}
		}	// end of normal view
	}
	
	/**
	 * When we want to save a modification in a row, we are getting to here...
	 */
	public function onUpdateTask($sender, $param)
	{
		$item = $sender->Parent->Parent;
		$taskId = $param->CommandParameter;

		$task = LibrarianTaskQuery::create()
					->filterByTaskId($taskId)
					->findOneOrCreate();
		
		if ($task instanceof LibrarianTask)
		{
			if ($task->getTaskStatus() == LibrarianTaskPeer::STATUS_DONE)
			{
				$this->getPage()->writeMessage(Prado::localize("Non è possibile modificare i dati di un task già chiuso"),
													ClavisMessage::WARNING);
				
				return false;
			}
				
			$task->setTaskNote($this->TaskNoteColumn->getDataField());
			$task->setTaskTitle($item->TaskTitleColumn->Controls[0]->getSafeText());
			$task->setTaskNote($item->TaskNoteColumn->Controls[0]->getSafeText());

			$task->setLibraryId($item->LibraryIdColumn->Controls[0]->getSelectedValue());

			$task->setDueDate($item->DueDateColumn->DueDateField->getTimeStamp());
			///$task->setStartDate($item->StartDateColumn->StartDateField->getTimeStamp());
			///$task->setEndDate($item->EndDateColumn->EndDateField->getTimeStamp());

			$task->setTaskStatus($item->TaskStatusColumn->Controls[0]->getSelectedValue());

			$task->setDonePercent($item->DonePercentColumn->Controls[0]->getSelectedValue());

			$task->setAssignedLibrarianId($item->AssignedLibrarianIdColumn->AssignedLibrarianId->getValue());

//			if (($task->getTaskStatus() != LibrarianTaskPeer::STATUS_DONE)
//					&& ($task->getTaskStatus() != LibrarianTaskPeer::STATUS_WORKING))
//				$task->setTaskStatus(LibrarianTaskPeer::STATUS_WORKING);
			
			$isNew = $task->isNew();
			$task->save();

			if ($isNew)
			{
				ChangelogPeer::logAction(	$task,
											ChangelogPeer::LOG_CREATE,
											$this->getUser(),
											'inserimento task con id=' . $task->getTaskId());
				
				$this->getPage()->writeMessage(Prado::localize("Task inserito con successo, con id=") . $task->getTaskId(),
													ClavisMessage::CONFIRM);
			}
			else
			{
				ChangelogPeer::logAction(	$task,
											ChangelogPeer::LOG_UPDATE,
											$this->getUser(),
											'modifica task' . $task->getTaskId());
				
				$this->getPage()->writeMessage(Prado::localize("Task modificato con successo, con id=") . $task->getTaskId(),
													ClavisMessage::INFO);
			}
			
			$task->save();
			$task->reload();
		}

		$item->Parent->EditItemIndex = -1;
		
		$this->populate();
	}
	
	public function onManageTask($sender, $param)
	{
		$taskId = intval($this->TaskActiveGrid->DataKeys[$sender->Parent->Parent->ItemIndex]);
		if ($taskId == 0)
			return false;
			
		$task = LibrarianTaskQuery::create()
					->findPk($taskId);
			
		if (!($task instanceof LibrarianTask))
			return false;

		$task->setTaskStatus(LibrarianTaskPeer::STATUS_WORKING);
		$task->setStartDate(time());
		$task->setEndDate(null);

//		$task->setAssignedLibrarianId($this->getUser()->getId());	// touched by actual librarian
//		$task->setLibraryId($this->getUser()->getActualLibraryId());

//		if ($taskId == 0)
//		{
//			$task->setTaskTitle($this->Title->getSafeText());
//			$task->setTaskNote($this->Note->getSafeText());
//			$task->setDueDate($this->DueDate->getTimeStamp());
//		}

//		$task->setDonePercent($this->DonePercent->getSelectedValue());
		$task->setDonePercent(0);
		$task->save();

		ChangelogPeer::logAction(	$task,
									ChangelogPeer::LOG_UPDATE,
									$this->getUser(),
									'preso in gestione task con id=' . $task->getTaskId());
		
		$this->getPage()->writeMessage(Prado::localize("Task preso in gestione con successo task con id=") . $task->getTaskId(),
											ClavisMessage::CONFIRM);

		$this->populate();
	}
	
	public function onCloseTask($sender, $param)
	{
		$taskId = intval($this->TaskActiveGrid->DataKeys[$sender->Parent->Parent->ItemIndex]);
		if ($taskId == 0)
			return false;
			
		$task = LibrarianTaskQuery::create()
					->findPk($taskId);
			
		if (!($task instanceof LibrarianTask))
			return false;

		$task->setDonePercent(100);

		$task->setTaskStatus(LibrarianTaskPeer::STATUS_DONE);
		$task->setEndDate(time());
		$task->save();

		ChangelogPeer::logAction(	$task,
									ChangelogPeer::LOG_UPDATE,
									$this->getUser(),
									'chiusura task con id='. $task->getTaskId());
		
		$this->getPage()->writeMessage(Prado::localize("Task chiuso, con id=") . $task->getTaskId(),
											ClavisMessage::CONFIRM);

		$this->populate();
	}
	
	public function onLeaveTask($sender, $param)		//// da implementare
	{
		$taskId = intval($this->TaskActiveGrid->DataKeys[$sender->Parent->Parent->ItemIndex]);
		if ($taskId == 0)
			return false;
			
		$task = LibrarianTaskQuery::create()
					->findPk($taskId);
			
		if (!($task instanceof LibrarianTask))
			return false;

		/* @var $task Task  */
	
		$task->setTaskStatus(LibrarianTaskPeer::STATUS_PENDING); //In gestione
		//$task->setStartDate(time());
		$task->setEndDate(null);

		//$task->setDonePercent($this->DonePercent->getSelectedValue());
		$task->save();

		ChangelogPeer::logAction(	$task,
									ChangelogPeer::LOG_UPDATE,
									$this->getUser(),
									'sospeso task con id=' . $task->getTaskId());
		
		$this->getPage()->writeMessage(Prado::localize("Task sospeso, con id=") . $task->getTaskId(),
											ClavisMessage::INFO);

		$this->populate();	
	}
	
	public function onReopenTask($sender, $param)		//// da implementare
	{
		$taskId = intval($this->TaskActiveGrid->DataKeys[$sender->Parent->Parent->ItemIndex]);
		if ($taskId == 0)
			return false;
			
		$task = LibrarianTaskQuery::create()
					->findPk($taskId);
			
		if (!($task instanceof LibrarianTask))
			return false;

		/* @var $task Task  */
	
		$task->setTaskStatus(LibrarianTaskPeer::STATUS_WORKING); //In gestione
		//$task->setStartDate(time());
		$task->setEndDate(null);

//		$task->setAssignedLibrarianId($this->getUser()->getId());
//		$task->setLibraryId($this->getUser()->getActualLibraryId());

//		if ($taskId == 0)
//		{
//			$task->setTaskTitle($this->Title->getSafeText());
//			$task->setTaskNote($this->Note->getSafeText());
//			$task->setDueDate($this->DueDate->getTimeStamp());
//		}

		//$task->setDonePercent($this->DonePercent->getSelectedValue());
		$task->setDonePercent(0);
		$task->save();

		ChangelogPeer::logAction(	$task,
									ChangelogPeer::LOG_UPDATE,
									$this->getUser(),
									'riaperto il task con id='. $task->getTaskId());
		
		$this->getPage()->writeMessage(Prado::localize("Task riaperto, con id=". $task->getTaskId()),
											ClavisMessage::INFO);

		$this->populate();		
	}
	
	public function onDeleteTask($sender, $param)
	{
		$item = $sender->Parent->Parent;
		$taskId = $param->CommandParameter;

		$task = LibrarianTaskQuery::create()
					->filterByTaskId($taskId)
					->findOneOrCreate();		
		
		if (!($task instanceof LibrarianTask))
			return false;

		$deletedTaskId = $task->getTaskId();
		$task->delete();

		ChangelogPeer::logAction(	$task,
									ChangelogPeer::LOG_DELETE,
									$this->getUser(),
									'cancellazione task con id=' . $deletedTaskId);
		
		$this->getPage()->writeMessage(Prado::localize("Task eliminato con id=") . $deletedTaskId,
										ClavisMessage::INFO);
		
		$this->populate();
	}
	
	public function onCreateNewTask($sender, $param)
	{
		/**
		 * Reset grid pagination and search fields
		 * and puts edit mode in the first line
		 */
		$this->cancelSearchFields($param);
		$this->TaskActiveGrid->setCurrentPageIndex(0);
		$this->TaskActiveGrid->setEditItemIndex(0);
		
		$this->populate(true);
	}
	
	public function onResetAssignedLibrarian($sender, $param)
	{
		$item = $sender->Parent->Parent;
		
		$item->AssignedLibrarian->setText("");
		$item->AssignedLibrarianId->setValue('');
	}
	
}