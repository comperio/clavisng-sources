<?php
/**
 * ClavisImportSourceGrid class
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2011 Comperio srl
 * @version 2.7
 * @package Widgets
 * @since 2.5
 */
Prado::using('Application.Common.ImportDrivers.*');

class ClavisImportSourceGrid extends TTemplateControl
{
	private $_searchfields = array(
		'bid'		 => 'BID',
		'title'		 => 'Titolo',
		'author'	 => 'Autore',
		'ean'		 => 'EAN',
		'date'		 => 'Data',
		'publisher'	 => 'Editore',
		'biblevel'	 => 'Livello bibliografico'
	);
	public $available_drivers = array();

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallBack())
			$this->populate();
	}

	public function populate()
	{
		$sources = ImportSourceQuery::create()->findList();
		$this->SourceGrid->setDataSource($sources);

		$ds = LookupValueQuery::create()
				->filterByValueLanguage($this->getApplication()->getGlobalization()->getCulture())
				->filterByValueClass('CATLEVEL')
				->find();
		$this->DefaultCatlevel->setDataSource($ds);
		$this->DefaultCatlevel->dataBind();

		$this->available_drivers = array_merge(
				ClavisParamPeer::getClassParams('IMPORT_DRIVER', $this->getUser()->getActualLibraryId()), ClavisParamPeer::getClassParams('IMPORT_DRIVER', 0));
		if ($sbn = $this->getApplication()->getModule('sbn')->getEnabled())
			$this->available_drivers['SBNDriver'] = 'SBN';
		$this->ImportDriver->setDataSource($this->available_drivers);

		$conversions = array();
		foreach (get_class_methods('TurbomarcConversion') as $method)
			$conversions[$method] = $this->splitWordsFromCamelCase($method);

		$this->TurbomarcConversion->setDataSource($conversions);

		$this->SearchFields->setDataSource($this->_searchfields);

		$this->dataBind();
	}

	private function splitWordsFromCamelCase($camelCaseString) {
		$re = '/(?<=[a-z])(?=[A-Z])/x';
		$a = preg_split($re, $camelCaseString);
		return implode(' ', $a);
	}

	public function itemAction($sender, $param)
	{
		$action = $param->getCommandName();
		$source = ImportSourceQuery::create()->findPk($param->getCommandParameter());
		if ($source instanceof ImportSource)
		{
			switch ($action)
			{
				case 'moveUp':
					$source->moveUp();
					$this->populate();
					break;
				case 'moveDown':
					$source->moveDown();
					$this->populate();
					break;
				case 'edit':
					$this->editSource($source);
					break;
				case 'delete':
					try
					{
						$source->delete();
						ChangelogPeer::logAction($source, ChangelogPeer::LOG_DELETE, $this->getUser(), "Eliminata sorgente di import {$source->getName()}");
						$this->getPage()->writeMessage(Prado::localize("Eliminata sorgente di import {name}", array('name' => $source->getName())), ClavisMessage::CONFIRM);
					}
					catch (Exception $e)
					{
						$this->getPage()->writeMessage(Prado::localize("Errore sulla cancellazione della sorgente"), ClavisMessage::ERROR);
					}
					$this->populate();
					break;
				case 'toggleEnabled':
					$source->setEnabled(!$source->getEnabled());
					$source->save();
					$this->populate();
					break;
				case 'toggleSelected':
					$source->setSelected(!$source->getSelected());
					$source->save();
					$this->populate();
					break;
				default:
					break;
			}
		}
	}

	public function addSource($sender, $param)
	{
		$this->editSource();
		$this->populate();
	}

	public function toggleCatlevelPanel($sender, $param)
	{
		if ($sender->getChecked())
			$this->CatlevelPanel->setCssClass('panel_on');
		else
			$this->CatlevelPanel->setCssClass('panel_off');
	}

	public function cleanSourcePanel()
	{
		$this->Name->setText('');
		$this->Label->setText('');
		$this->ImportDriver->setSelectedIndex(-1);
		$this->Address->setText('');
		$this->Enabled->setChecked(false);
		$this->Selected->setChecked(false);
		$this->Timeout->setText('');
		$this->Encoding->setText('');
		$this->Syntax->setText('');
		$this->SearchFields->setText('');
		$this->Format->setText('');
		$this->Options->setDataSource(array());
	}

	public function editSource($source = null)
	{
		$this->SourceEditPanel->setVisible(true);
		if ($source instanceof ImportSource)
		{
			$this->Name->setText($source->getName());
			$this->Name->setReadOnly(true);
			$this->Label->setText($source->getLabel());
			$this->ImportDriver->setSelectedValue($source->getDriver());
			$this->Address->setText($source->getAddress());
			$this->Enabled->setChecked($source->getEnabled());
			$this->Selected->setChecked($source->getSelected());
			$this->Timeout->setText($source->getTimeout());
			$this->Encoding->setText($source->getEncoding());
			$this->Syntax->setText($source->getSyntax());
			$this->SearchFields->setSelectedValues($source->getSearchFields());
			$this->TurbomarcConversion->setSelectedValues($source->getTurbomarcConversion());
			$this->Format->setText($source->getFormat());
			$cl = $source->getDefaultCatlevel();
			if ($cl > 0)
			{
				$this->EnableCatlevel->setChecked(true);
				$this->DefaultCatlevel->setSelectedValue($cl);
			}
			else
			{
				$this->EnableCatlevel->setChecked(false);
			}
			$this->toggleCatlevelPanel($this->EnableCatlevel, null);
		}
		else
		{
			$this->cleanSourcePanel();
			$this->Name->setText('NEWSOURCE');
			$this->Name->setReadOnly(false);
			$this->ImportDriver->setSelectedIndex(0);
		}
		$this->updateOptions();
		return;
	}

	public function onSave($sender, $param)
	{
		if ($this->getPage()->getIsValid())
		{
			$s = ImportSourceQuery::create()
					->filterByName($this->Name->getText())
					->findOneOrCreate();
			try
			{
				$s->setName($this->Name->getText());
				$s->setLabel($this->Label->getText());
				$s->setDriver($this->ImportDriver->getSelectedValue());
				$s->setAddress($this->Address->getText());
				$s->setEnabled($this->Enabled->getChecked());
				$s->setSelected($this->Selected->getChecked());
				$s->setTimeout($this->Timeout->getText());
				$s->setEncoding($this->Encoding->getText());
				$s->setSyntax($this->Syntax->getText());
				$s->setSearchFields($this->SearchFields->getSelectedValues());
				$s->setTurbomarcConversion($this->TurbomarcConversion->getSelectedValues());
				$s->setFormat($this->Format->getText());
				$opts = array();
				foreach ($this->Options->getItems() as $row)
					$opts[$row->OptionKey->getText()] = $row->OptionValue->getText();
				$s->setOptions($opts);

				if ($this->EnableCatlevel->getChecked())
				{
					$s->setDefaultCatlevel($this->DefaultCatlevel->getSelectedValue());
				}
				else
				{
					$s->setDefaultCatlevel(null);
				}

				$new = $s->isNew();
				$s->save();
				$this->getPage()->writeMessage($new ?
								Prado::localize("Nuova sorgente inserita correttamente") :
								Prado::localize("Sorgente aggiornata correttamente"), ClavisMessage::CONFIRM);
				$this->cleanSourcePanel();
				$this->SourceEditPanel->setVisible(false);
			}
			catch (Exception $e)
			{
				$this->getPage()->writeMessage(
						Prado::localize("Errore nell'inserimento o aggiornamento della sorgente: {error}", array('error' => $e->getMessage())), ClavisMessage::ERROR);
			}
		}
		$this->populate();
	}

	public function onCancel($sender, $param)
	{
		$this->cleanSourcePanel();
		$this->SourceEditPanel->setVisible(false);
		$this->populate();
	}

	public function onDriverSelected($sender, $param)
	{
		$this->updateOptions();
	}

	public function updateOptions()
	{
		$options = array();
		if ($this->ImportDriver->getSelectedIndex() >= 0)
		{
			$driverName = $this->ImportDriver->getSelectedValue();
			try
			{
				if (!class_exists($driverName))
					throw new Exception('No driver available');
				$driver = new $driverName;
				$params = $driver->getOptionalParameters();
				$source = ImportSourceQuery::create()->findPk($this->Name->getText());
				$srcopts = ($source instanceof ImportSource) ? $source->getOptions() : array();
				foreach ($params as $name => $type)
					$options[] = array(
						'key'	 => $name,
						'value'	 => array_key_exists($name, $srcopts) ? $srcopts[$name] : '');
			}
			catch (Exception $e)
			{

			}
		}
		$this->Options->setDataSource($options);
		$this->Options->dataBind();
	}

}
