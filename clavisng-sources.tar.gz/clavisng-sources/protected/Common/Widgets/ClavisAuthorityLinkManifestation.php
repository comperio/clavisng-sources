<?php
/**
 * ClavisAuthorityLinkManifestation class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Ciro Mattia Gonano
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.8.6
 * @package Widgets
 */

/**
 * ClavisAuthorityLinkManifestation Class
 * 
 * @author Ciro Mattia Gonano
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.8.6
 * @package Widgets
 * @since 2.3
 */
class ClavisAuthorityLinkManifestation extends TTemplateControl
{
	public $authority;

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsPostBack() 
				&& !$this->getPage()->getIsCallback())
		{
			$this->populate();
		}
		else
		{
			$this->getAuthority();
		}
	}

	public function populate()
	{
		if (!($this->authority instanceof Authority))
			return;

		$c = new Criteria();
		$this->calculateSortingCriteria($c);

		$lManAuthListsCount = $this->authority->countLAuthorityManifestations($c);

		$pageSize = $this->RecordGrid->getPageSize();
		$currentIndexPage = $this->RecordGrid->getCurrentPage();

		$c->setLimit($pageSize);
		$c->setOffset($currentIndexPage * $pageSize);
		$lManAuthLists = $this->authority->getLAuthorityManifestationsJoinManifestation($c);

		$manGridDS = array();
		
		/* @var $lManAuth LAuthorityManifestation */
		foreach ($lManAuthLists as $lManAuth)
		{
			$m = $lManAuth->getManifestation();
		
			if (!$m instanceof Manifestation)
			{
				// report and skip
				Prado::log("Warning: dangling link from auth [{$lManAuth->getAuthorityId()}] and man [{{$lManAuth->getManifestationId()}]");
			
				continue;
			}
			
			$row['LinkType'] = LookupValuePeer::getLookupValue('LINKTYPE', $lManAuth->getLinkType());
			$row['LinkTypeIndex'] = $lManAuth->getLinkType();
			$row['LinkClass'] = get_class($lManAuth);
			$row['Title'] = $m->getCompleteTitle();
			$row['Year'] = $m->getEditionDate();
			$row['ManId'] = $lManAuth->getManifestationId();
			$row['lAuthManId'] = $lManAuth->getAuthorityId() . '|' . $lManAuth->getManifestationId()
										. '|' . $lManAuth->getLinkType() . '|' . $lManAuth->getRelatorCode();
			
			$manGridDS[] = $row;
		}
		
		$this->RecordGrid->setDataSource($manGridDS);
		$this->RecordGrid->setVirtualItemCount($lManAuthListsCount);
		$this->RecordGrid->dataBind();
		$this->Counter->setText($lManAuthListsCount);
	}

	public function getAuthority()
	{
		$this->authority = $this->getViewState('authorityL', null);
		
		return $this->authority;
	}

	public function setAuthority($value = null)
	{
		$this->authority = $value;
		$this->setViewState('authorityL', $value, null);
	}

	public function calculateSortingCriteria(&$sortingCriteria = null)
	{
		$sortingExpression = $this->RecordGrid->getSortingExpression();
		$sortingDirection = $this->RecordGrid->getSortingDirection();

		if (is_null($sortingCriteria) 
				|| !($sortingCriteria instanceof Criteria))
			$sortingCriteria = new Criteria();

		switch ($sortingExpression)
		{
			case 'title':
				$sortingCriteria->clearOrderByColumns();
				
				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
				{
					$sortingCriteria->addAscendingOrderByColumn(ManifestationPeer::SORT_TEXT);
					$sortingCriteria->addAscendingOrderByColumn(ManifestationPeer::PUBLISHER);
				}
				elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
				{
					$sortingCriteria->addDescendingOrderByColumn(ManifestationPeer::SORT_TEXT);
					$sortingCriteria->addDescendingOrderByColumn(ManifestationPeer::PUBLISHER);
				}
				
				break;

			case 'linktype':
				$sortingCriteria->clearOrderByColumns();
				
				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
				{
					$sortingCriteria->addAscendingOrderByColumn(LAuthorityManifestationPeer::LINK_TYPE);
				}
				elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
				{
					$sortingCriteria->addDescendingOrderByColumn(LAuthorityManifestationPeer::LINK_TYPE);
				}
				
				break;

			case 'year':
				$sortingCriteria->clearOrderByColumns();
				
				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
				{
					$sortingCriteria->addAscendingOrderByColumn(ManifestationPeer::EDITION_DATE);
				}
				elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
				{
					$sortingCriteria->addDescendingOrderByColumn(ManifestationPeer::EDITION_DATE);
				}
				
				break;

			case null:
				break;

			default:
				$sortingExpression = null;
				break;
		}
	}

	public function itemCreated($sender, $param)
	{
		$item = $param->Item;
		
//		if (!$this->getReadOnly()
//				&& in_array($item->ItemType, array('Item', 'AlternatingItem', 'EditItem')))
//			$item->DeleteColumn->Button->Attributes->onclick = 'if(!confirm(\'' . Prado::localize('Sei sicuro di voler cancellare questo legame?') . '\')) return false;';
	}

	public function setReadOnly($value)
	{
		return $this->setControlState('ReadOnly', TPropertyValue::ensureBoolean($value), false);
	}

	public function getReadOnly()
	{
		return $this->getControlState('ReadOnly', false);
	}

	public function onDeleteLink($sender, $param)
	{
		$ok = false;
		$id = $param->getCommandParameter();
		$keys = explode('|', $id);
		
		try
		{
			LAuthorityManifestationPeer::doDelete($keys);
			
			ChangelogPeer::logAction(	$this->authority, 
										ChangelogPeer::LOG_UPDATE, 
										$this->getUser(), 
										'Eliminato legame fra authority (id = ' . $keys[0] . ')' 
											. ' e notizia (id = ' . $keys[1] . ')',
										$keys[0]);

			$this->getPage()->writeMessage(Prado::localize("Eliminato legame fra l'authority (id = {authid}) e la notizia (id = {manid}))",
																array(	'authid' => $keys[0],
																		'manid' => $keys[1] )),
												ClavisMessage::CONFIRM);

			/* reindex manifestation */
			$deletableManifestation = ManifestationQuery::create()->findPk($keys[1]);

			if ($deletableManifestation instanceof Manifestation)
				$deletableManifestation->invalidateCache();

			$this->authority->clearLAuthorityManifestations();
		}
		catch (Exception $e)
		{
			$this->writeMessage(Prado::localize('Cancellazione notizia collegata fallita: ') . " " . $e, 
									ClavisMessage::ERROR);
		}
		
		if ($ok)
		{
			$this->populate();
		}
	}

	public function onChangePage($sender, $param)
	{
		$this->RecordGrid->setCurrentPage($param->NewPageIndex);
		$this->populate();
	}

	public function linkCommand($sender, $param)
	{
		$item = $param->getItem();
		$sbnactions = $this->getPage()->findControlsByType('ClavisSBNActions');
		
		if (count($sbnactions) < 1)
			return;
		
		switch ($param->getCommandName())
		{
			case 'sbnLinkCreate':
				list($aid, $mid, $lt, $rc) = explode('|', $this->RecordGrid->DataKeys[$param->Item->ItemIndex]);
				$link = LAuthorityManifestationQuery::create()->findPk(array($aid, $mid, $lt, $rc));
				if ($link instanceof LAuthorityManifestation 
						&& (($m = $link->getManifestation()) instanceof Manifestation))
				{
					if (($m->getBidSource() == 'SBN') 
							&& $m->getBid())
						$sbnactions[0]->updateLinkToSBN('Create', $link);
				}
				
				break;
				
			case 'sbnLinkDelete':
				list($aid, $mid, $lt, $rc) = explode('|', $this->RecordGrid->DataKeys[$param->Item->ItemIndex]);
				$link = LAuthorityManifestationQuery::create()->findPk(array($aid, $mid, $lt, $rc));
				
				if ($link instanceof LAuthorityManifestation 
						&& (($m = $link->getManifestation()) instanceof Manifestation))
				{
					if (($m->getBidSource() == 'SBN') 
							&& $m->getBid())
						$sbnactions[0]->updateLinkToSBN('Delete', $link);
				}
				
				break;
		}
		
		$this->populate();
	}
	
	public function onLinkEdit($sender, $param)
	{
		$this->RecordGrid->EditItemIndex = $param->Item->ItemIndex;
		//$this->bindManGrid();
		$this->populate();
	}

	public function onLinkUpdate($sender, $param)
	{
		$ok = false;
		$item = $param->Item;
		$primaryKeys = explode('|', $this->RecordGrid->DataKeys[$item->ItemIndex]);
		$oldLink = LAuthorityManifestationQuery::create()->findPK($primaryKeys);
	
		if ($oldLink instanceof LAuthorityManifestation)
		{

			try
			{
				$newLink = $oldLink->copy(true);
				$newLink->setLinkType($item->LinkTypeColumn->ManLinkTypeDropdownList->getSelectedValue());

				$oldLink->delete();
				$newLink->save();
				
				$authId = $primaryKeys[0];
				$manId = $primaryKeys[1];
				$manifestation = ManifestationQuery::create()->findPk($manId);
				
				if ($manifestation instanceof Manifestation)
				{
					$manifestationTitle = $manifestation->getTrimmedTitle(80, '');
				}
				else
				{
					$manifestationTitle = '(' . Prado::localize('non esiste') . ')';
				}
						
				ChangelogPeer::logAction(	$this->authority, 
											ChangelogPeer::LOG_UPDATE, 
											$this->getUser(), 
											'Modificato legame fra authority (id = ' . $authId. ')'
												. ' e notizia (id = ' . $manId . ', titolo = \'' . $manifestationTitle	. '\')',
											$authId);
				
				$this->getPage()->writeMessage(Prado::localize("Modificato legame fra l'authority (id = {authId}) e la notizia (id = {manId}, titolo = '{manifestationTitle}')",
																	array(	'authId' => $authId,
																			'manId' => $manId,
																			'manifestationTitle' => $manifestationTitle )),
													ClavisMessage::CONFIRM);
				
				$ok = true;
			}
			catch (Exception $e)
			{
				$this->getPage()->writeMessage(Prado::localize('Impossibile aggiornare il legame fra authority e notizia: ') . " " . $e, 
													ClavisMessage::ERROR);
			}
		}
		else
		{
			$this->getPage()->writeMessage(Prado::localize("Errore su tentativo di modifica della notizia collegata: non esiste più il record corrispondente alla chiave '{key}'. Riportare al fornitore del software",
																array('key' => $this->AuthGrid->DataKeys[$item->ItemIndex])),
												ClavisMessage::ERROR);
		}
		
		if ($ok)
		{
			$this->RecordGrid->EditItemIndex = -1;
			$this->populate();
		}
	}

	public function onLinkCancel($sender, $param)
	{
		$this->RecordGrid->EditItemIndex = -1;
		
		//$this->bindManGrid();
		$this->populate();
	}
	
	public function onManItemDataBound($sender, $param)
	{
		$item = $param->Item;
		
		if ($item->ItemType == 'EditItem')
		{
			list($linkTypes, $defaultSelected) = $this->calculateLinkDropDown($item->DataItem['ManId']);
			
			$item->Cells[1]->ManLinkTypeDropdownList->setDataSource($linkTypes);
			$item->Cells[1]->ManLinkTypeDropdownList->dataBind();
			
			$selected = $item->DataItem['LinkTypeIndex'];
			
			if (is_null($selected))
				$selected = $defaultSelected;
			
			$item->Cells[1]->ManLinkTypeDropdownList->setSelectedValue($selected);
		}
	}
	
	private function calculateLinkDropDown($manId = null)
	{
		$a = $this->authority;
		
		if (!$a instanceof Authority)
			$a = AuthorityQuery::create()->findPk(intval($this->AuthorityID->getValue()));

		$select = null;
		
		if ((!$a instanceof Authority) 
				|| ($a->getAuthorityRectype() == AuthorityPeer::RECTYPE_NODE))
		{
			$this->AuthorityID->setValue('');
			$this->NewAuthLink->setText('');
			$fldlist = array(700, 702, 701, 610, 609, 619, 620, 676, 500, 921);
		}
		else
		{
			switch ($a->getAuthorityType())
			{
				case AuthorityPeer::TYPE_TRADEMARK:
					$fldlist = array(616, 619);
					$select = '616';
					break;
				
				case AuthorityPeer::TYPE_PUBPLACE:
					$fldlist = array(620, 619);
					$select = '620';
					break;
				
				case AuthorityPeer::TYPE_CLASS:
					$fldlist = array(676, 619);
					$select = '676';
					break;
				
				case AuthorityPeer::TYPE_WORK:
					$fldlist = array(500, 619);
					$select = '500';
					break;
				
				case AuthorityPeer::TYPE_PRINTERSDEVICE:
					$fldlist = array(921, 619);
					$select = '921';
					break;
				
				case AuthorityPeer::TYPE_PERSONALNAME:
				case AuthorityPeer::TYPE_CORPORATEBODYNAME:
				case AuthorityPeer::TYPE_FAMILYNAME:
					$fldlist = array(700, 702, 701, 610, 609, 619);
					
					/**
					 * We don't want this anymore
					if (!is_null($manId))
					{	
						if ($this->getRecordHasMainAuthor($manId))
							$fldlist = array_diff($fldlist, array(700));

						if ($this->getRecordHasAltAuthors($manId))
							$fldlist = array_diff($fldlist, array(701));
					}
					 * 
					 */
					
					break;
					
				default:
					$fldlist = array(610, 609, 619);
					break;
			}
		}
		
		$options = LookupValuePeer::getLookupClassValues('LINKTYPE');
		$ds = array();
		
		foreach ($fldlist as $fld)
			$ds[$fld] = $options[$fld];
		
		return array($ds, $select);
	}
	
	// maybe deprecated here
	public function getRecordHasMainAuthor($mid)
	{
		if ($mid < 1)
			return false;
		
		$c = LAuthorityManifestationQuery::create()
				->filterByManifestationId($mid)
				->filterByLinkType(array(700, 710))
				->count();
		
		return ($c > 0);
	}

	// maybe deprecated here
	public function getRecordHasAltAuthors($mid)
	{
		if ($mid < 1)
			return false;
		
		$c = new Criteria();
		$c->add(LAuthorityManifestationPeer::MANIFESTATION_ID, $mid);
		$c->add(LAuthorityManifestationPeer::LINK_TYPE, array(701, 711), Criteria::IN);
		
		return LAuthorityManifestationPeer::doCount($c) > 1;
	}
	
}