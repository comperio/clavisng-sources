<?php
/**
 * ClavisExtraSearch class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 ePortal Technologies
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Widgets
 */

/**
 * ClavisExtraSearch Class
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Widgets
 * @since 2.5.0
 */
class ClavisExtraSearch extends TTemplateControl
{
	private $_query;

	public function onLoad($param) {
		parent::onLoad($param);

		$this->_query = $this->getRequest()->itemAt('query');

		if (!$this->_query) {
			$this->getPage()->writeMessage(Prado::localize('Criteri di ricerca EXTRA SISTEMA errati.'),ClavisMessage::ERROR);
			$this->getPage()->getBack();
			return;
		}
		if ($this->getPage()->getIsPostBack()) {
			list($libcode,$inventory,$collocation,$barcode,$title) =
				explode('|',urldecode($this->ItemHiddenValue->getValue()),5);
			$patron = PatronPeer::retrieveByPK($this->ReserveHiddenValue->getValue());
			if ($patron instanceof Patron) {
				$erm = $this->getApplication()->getModule('extrarequest');
				$erm->setSendMail($this->SendMailCheck->getChecked());
				try {
					$ret = $erm->doReserve($patron,$libcode,$inventory,$collocation,$barcode,$title);
					$this->RequestPatronLink->setText($patron->getCompleteName());
					$this->RequestPatronLink->setNavigateUrl(
							$this->getService()->constructUrl('Circulation.PatronViewPage',array('id'=>$patron->getPatronId())));
					$this->RequestPatronPanel->setVisible(true);
					$this->getPage()->writeMessage(Prado::localize('La prenotazione è stata correttamente registrata.'),ClavisMessage::INFO);
				} catch (Exception $e) {
					$params = array();
					$messageType = ClavisMessage::ERROR;
					switch ($e->getCode()) {
						case IExternalReservation::ERR_ITEMCREATION:
							$error = Prado::localize('Errore nella creazione dell\'esemplare');
							break;
						case IExternalReservation::ERR_MAILERROR:
							$error = Prado::localize('Errore nella spedizione della mail (la prenotazione è stata correttamente registrata) [{errmsg}]',
								array('errmsg' => $e->getMessage()));
							$this->RequestPatronLink->setText($patron->getCompleteName());
							$this->RequestPatronLink->setNavigateUrl(
								$this->getService()->constructUrl('Circulation.PatronViewPage',array('id'=>$patron->getPatronId())));
							$this->RequestPatronPanel->setVisible(true);
							$messageType = ClavisMessage::WARNING;
							break;
						case IExternalReservation::ERR_REQUESTEXISTSFORPATRON:
							$error = Prado::localize('Errore nella prenotazione: esiste già una prenotazione attiva per lo stesso utente');
							break;
						case IExternalReservation::ERR_REQUESTCREATION:
							$error = Prado::localize('Errore nella creazione della prenotazione: {errmsg}',
								array('errmsg' => $e->getMessage()));
							break;
						case IExternalReservation::ERR_UNKNOWNLIBRARY:
							$error = Prado::localize('Errore: biblioteca {library_id} non riconosciuta',
								array('library_id' => $libcode));
							break;
					}
					$this->getPage()->writeMessage($error,$messageType);
					Prado::log($e->getMessage());
				}
			}
		}
		$this->populate();
	}

	public function populate()
	{
		/* @var $search SolrSearch */
		$search = $this->getApplication()->getModule('search');
		$extra = ($this->_query) ? $search->searchExtra($this->_query,0,30) : null;
		if ($extra && $extra['response']['numFound'] > 0) {
			$this->FoundNumber->setText($extra['response']['numFound']);
			$ds = array();
			foreach ($extra['response']['docs'] as $key => $result) {
				$tm = TurboMarc::createRecord($result['turbo_marc']);
				$fulltitle = $tm->getFullTitle();
				for ($i=500; $i<600; ++$i) {
					$xmlTag = "d{$i}";
					foreach($tm->$xmlTag as $extratitle)
						$fulltitle .= ' '.(string)$extratitle->sa;
				}
				foreach ($tm->d950 as $item) {
					$l = LibraryQuery::create()->findPk((string)$item->sa);
					$ds[] = array(
						'itemstring'	=> implode('|',array(
							(string)$item->sa,
							(string)$item->sb.'-'.(string)$item->sc,
							(string)$item->sf,
							(string)$item->sr,
							$fulltitle)),
						'title'			=> $fulltitle,
						'library_id'	=> ($l instanceof Library) ? $l->getLibraryId() : null,
						'libcode'		=> ($l instanceof Library) ? $l->getLabel() : 'nessuna',
						'inventory'		=> (string)$item->sb.'-'.(string)$item->sc,
						'collocation'	=> (string)$item->sf,
						'barcode'		=> (string)$item->sr
					);
				}
			}
		}
		$this->ResultGrid->setDataSource($ds);
		$this->ResultGrid->dataBind();
	}
}
