<?php
/**
 * ClavisItemFoundBlock class file
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 */

/**
 * ClavisItemFoundBlock Class
 *
 * It creates views of the items found in the NewLoan page, in a loanable state.
 * 
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.7
 * @package Widgets
 * @since 2.2
 */
class ClavisItemFoundBlock extends TTemplateControl
{
	private $_datasource = null;

	private $_checked;
	private $_dueDate;
	private $_itemRequestId;
	private $_deliveryLibraryId;

	/** @param ClavisLoanManager $_loanmanager */
	protected $_loanmanager;
	
	private $_datasourceSessionName;
	private $_checkedSessionName;
	private $_dueDateSessionName;
	private $_itemRequestIdSessionName;
	private $_deliveryLibraryIdSessionName;

	private function initVars()
	{
		$uniqueId = $this->getUniqueID();
		$this->_datasourceSessionName = 'DatasourceSessionName' . $uniqueId;
		$this->_checkedSessionName = 'CheckedSessionName' . $uniqueId;
		$this->_dueDateSessionName = 'DueDateSessionName' . $uniqueId;
		$this->_itemRequestIdSessionName = 'ItemRequestIdSessionName' . $uniqueId;
		$this->_deliveryLibraryIdSessionName = 'DeliveryLibraryIdSessionName' . $uniqueId;
		$this->_loanmanager = $this->getApplication()->getModule('loan');
	}

	public function onInit($param)
	{
		parent::onInit($param);
		$this->initVars();

		$this->getChecked();
		$this->getDueDate();
		$this->getItemRequestId();
		$this->getDatasource();
	}

	public function onLoad($param)
	{
		parent::onLoad($param);

		$this->_deliveryLibraryId = $this->getDeliveryLibraryId();
	}

	public function setAvailableType($type = true)
	{
		$this->setViewState('AvailableType', $type, true);
	}

	public function getAvailableType()
	{
		return $this->getViewState('AvailableType', true);
	}

	public function resetChecked()
	{
		$this->_checked = array();
		$this->setChecked($this->_checked);
	}

	public function setChecked($checked = null)
	{
		if ($checked == null)
		{
			$checked = $this->_checked;
		}
		else
		{
			$this->_checked = $checked;
		}
		
		$this->getApplication()->getSession()->add($this->_checkedSessionName, $checked);
	}

	public function getChecked()
	{
		if (is_null($this->_checked))
			$this->_checked = $this->getApplication()->getSession()->itemAt($this->_checkedSessionName);
		
		return $this->_checked;
	}

	public function resetDueDate()
	{
		$this->_dueDate = array();
		$this->setDueDate($this->_dueDate);
	}

	public function setDueDate($dueDate = null)
	{
		if ($dueDate == null)
		{
			$dueDate = $this->_dueDate;
		}
		else
		{
			$this->_dueDate = $dueDate;
		}
		
		$this->getApplication()->getSession()->add($this->_dueDateSessionName, $dueDate);
	}

	public function getDueDate()
	{
		if (is_null($this->_dueDate))
			$this->_dueDate = $this->getApplication()->getSession()->itemAt($this->_dueDateSessionName);
		
		return $this->_dueDate;
	}

	public function resetItemRequestId()
	{
		$this->_itemRequestId = array();
		$this->setItemRequestId($this->_itemRequestId);
	}

	public function setItemRequestId($itemRequestId = null)
	{
		if ($itemRequestId == null)
		{
			$itemRequestId = $this->_itemRequestId;
		}
		else
		{
			$this->_itemRequestId = $itemRequestId;
		}
		
		$this->getApplication()->getSession()->add($this->_itemRequestIdSessionName, $itemRequestId);
	}

	public function getItemRequestId()
	{
		if (is_null($this->_itemRequestId))
			$this->_itemRequestId = $this->getApplication()->getSession()->itemAt($this->_itemRequestIdSessionName);
		
		return $this->_dueDate;
	}

	/**
	 * Reset the datasource to null, and populate.
	 *
	 */
	public function resetDataSource()
	{
		$this->resetChecked();
		$this->resetDueDate();
		$this->resetItemRequestId();
		$this->setDeliveryLibraryId(null);
		$this->_datasource = array();
		$this->setDatasource($this->_datasource);

		$this->populate();
	}

	public function setDatasource($datasource)
	{
		$this->_datasource = $datasource;
		$this->getApplication()->getSession()->add($this->_datasourceSessionName, $this->_datasource);
	}

	/**
	 * It returns the private datasource (array).
	 *
	 * @return array.
	 */
	public function getDatasource()
	{
		$this->_datasource = $this->getApplication()->getSession()->itemAt($this->_datasourceSessionName);

		if (is_null($this->_datasource))
			$this->_datasource = array();

		return $this->_datasource;
	}

 	public function setDeliveryLibraryId($id)
 	{
 		$this->_deliveryLibraryId = $id;
 		$this->getApplication()->getSession()->add($this->_deliveryLibraryIdSessionName, $id);
 	}

 	public function getDeliveryLibraryId()
 	{
 		if (($id = $this->_deliveryLibraryId) == null)
 		{
 			$id = $this->getApplication()->getSession()->itemAt($this->_deliveryLibraryIdSessionName);
 			$this->_deliveryLibraryId = $id;
 		}
		
		return $id;
 	}

	/**
	 * Returns whether an item id is present into the datasource.
	 *
	 * @param int $itemId
	 * @return boolean
	 */
	private function searchIdIntoDatasource($itemId)
	{
		$dataSource = $this->getDatasource();

		if (count($dataSource) > 0)
		{
			foreach($dataSource as $index => $row)
			{
				if ($row['id'] == $itemId)
				return $index;
			}
		}
		
		return -1;
	}

	/**
	 * It adds an item to datasource, by item.
	 * There's an optional id of the matching item_request.
	 * And and optional flag whether auto-check the new added
	 * item (default = true).
	 *
	 * It returns true if this action succeeds, false if not.
	 *
	 * @param string $barcode
	 * @return boolean
	 */
	public function addToDatasource($item, $itemRequestId = null, $checkFlag = true)
	{
		/* @var $item Item */
		if ($item instanceof Item)
		{
			$datasource = $this->getDatasource();
			$itemId = $item->getId();
			
			$exists = $this->searchIdIntoDatasource($itemId);
			if ($exists != -1)
				unset($datasource[$exists]);

			$loanStatus = $item->getLoanStatus();
			$available = ($this->_loanmanager->IsItemAvailableClass($item) == ClavisLoanManager::OK);

			$patronId = null;
			$patronString = "";
			if ($loanStatus == ItemPeer::LOANSTATUS_READYFORLOAN)
			{
				$dueDate = $this->_loanmanager->CalculateDueDate($item);

				if ($item->getActualLibraryId() == $this->getUser()->getActualLibraryId())
				{	
					$patronId = $item->getPatronId();
					$patronString = $item->getPatronCompleteName() . "&nbsp;(" . $item->getPatronBarcode() . ")";
				}
				
				$loanStatusString = '&nbsp;[' . $item->getLoanStatusString() . ']&nbsp;';
			}
			else
			{
				$dueDate = $item->getDueDate('U');
				if (is_null($dueDate) || in_array($item->getLoanStatus(), ItemPeer::getLoanStatusAvailable()))
					$dueDate = $this->_loanmanager->CalculateDueDate($item);
				
				$loanStatusString = '';
			}
			
			$manifestationId = $item->getManifestationId();
			$manifestation = $item->getManifestation();
			if ($manifestation instanceof Manifestation)
			{
				$objectType = 'Manifestation';
			}
			else
			{
				$objectType = 'Item';
			}

			$fromLibraryIdFilter = $this->getUser()->getActualLibraryId();

			$actualLibraryId = intval($item->getActualLibraryId());
			$actualLibraryLabel = trim($item->getActualLibraryLabel());
			if (($actualLibraryLabel == '') || ($fromLibraryIdFilter == $actualLibraryId))
				$actualLibraryId = 0;
	
			$row = array(	'id' => $itemId,
							'manifestationId' => $manifestationId,
							'objectType' => $objectType,
							'checked' => $checkFlag,
							'data' => $this->getTitle($item),

							'canEdit' => $this->getUser()->getEditPermission($item),
							'actualLibraryId' => $actualLibraryId,
							'actualLibraryLabel' => $actualLibraryLabel,
							'loanAlertNote' => $item->getLoanAlertNote(),
							'loanStatus' => $loanStatus,

							'loanStatusString' => $loanStatusString,
							'patronId' => $patronId,
							'patronString' => $patronString,
							'available' => $available,
							'mediapackage_size' => $item->getMediapackageSize() );

			$this->_checked[$itemId] = $checkFlag;
			$this->_itemRequestId[$itemId] = $itemRequestId;
			$this->_dueDate[$itemId] = $dueDate;

			$this->setChecked();
			$this->setDueDate();
			$this->setItemRequestId();
			$datasource[] = $row;
			$this->setDatasource($datasource);

			$this->ItemList->setDataSource($datasource);
			$this->ItemList->dataBind();
			
			return true;
		}
		
		return false;
	}

	/**
	 * Updating of datagrid from private datasource.
	 *
	 */
	public function updateDatasource()
	{
		$fromLibraryIdFilter = $this->getUser()->getActualLibraryId();

		$newDatasource = array();
		foreach ($this->getDatasource() as $index => $row)
		{
			$newRow = array();
			$itemId = $row['id'];
			$manifestationId = $row['manifestationId'];
			$item = ItemPeer::retrieveByPK($itemId);

			if (array_key_exists($itemId, $this->_checked))
			{
				$checked = $this->_checked[$itemId];
			}
			else
			{
				$this->_checked[$itemId] = false;
				$checked = false;
			}
			
			$newRow['checked'] = $checked;

			if (array_key_exists($itemId, $this->_dueDate))
			{
				$dueDate = $this->_dueDate[$itemId];
			}
			else
			{
				$newDueDate = $this->_loanmanager->CalculateDueDate($item);
				$this->_dueDate[$itemId] = $newDueDate;
				$checked = $newDueDate;
			}

			if (intval($manifestationId) > 0)
			{
				$manifestation = ManifestationPeer::retrieveByPK($manifestationId);
			}
			else
			{
				$manifestation = null;
			}

			if ($manifestation instanceof Manifestation)
			{
				//$oocParameter = 'Regular';
				$objectType = 'Manifestation';
				//$objectId = $manifestationId;
			}
			else
			{
				//$oocParameter = 'OocMode';
				$objectType = 'Item';
				//$objectId = $itemId;
			}

			$newRow['data'] = $this->getTitle($item);
			$newRow['id'] = $itemId;
			$newRow['manifestationId'] = $manifestationId;
			$newRow['objectType'] = $objectType;

			$actualLibraryId = intval($item->getActualLibraryId());
			$actualLibraryLabel = trim($item->getActualLibraryLabel());
			
			if (($actualLibraryLabel == '') || ($fromLibraryIdFilter == $actualLibraryId))
				$actualLibraryId = 0;

			$newRow['actualLibraryId'] = $actualLibraryId;
			$newRow['actualLibraryLabel'] = $actualLibraryLabel;

			$newRow['loanAlertNote'] = $item->getLoanAlertNote();

			$loanStatus = '';
			$loanStatusString = '';
			$available = false;

			$patronId = null;
			$patronString = "";
				
			if ($item instanceof Item)
			{
				$loanStatus = $item->getLoanStatus();

				if ($loanStatus == ItemPeer::LOANSTATUS_READYFORLOAN)
				{
					$loanStatusString = '&nbsp;[' . $item->getLoanStatusString() . ']&nbsp;';
						
					if ($item->getActualLibraryId() == $this->getUser()->getActualLibraryId())
					{
						$patronId = $item->getPatronId();
						$patronString = $item->getPatronCompleteName() . "&nbsp;(" . $item->getPatronBarcode() . ")";
					}
				}

				$available = ($this->_loanmanager->IsItemAvailableClass($item) == ClavisLoanManager::OK);
			}

			$newRow['loanStatus'] = $loanStatus;
			$newRow['loanStatusString'] = $loanStatusString;
			$newRow['patronId'] = $patronId;
			$newRow['patronString'] = $patronString;
			$newRow['available'] = $available;

			$newDatasource[$index] = $newRow;

		}
		
		$this->setChecked();
		$this->setDueDate();
		$this->setDatasource($newDatasource);

		$this->ItemList->setDataSource($newDatasource);
		$this->ItemList->dataBind();
	}

	public function deleteItemIds($itemId)
	{
		if ($itemId > 0)
		{
			$datasource = $this->getDatasource();
			$index = $this->searchIdIntoDatasource($itemId);
			if ($index > -1)
			{
				$checked = $this->getChecked();
				$itemRequestId = $this->getItemRequestId();
				$dueDate = $this->getDueDate();

				if (array_key_exists($itemId, $checked) 
						&& array_key_exists($itemId, $itemRequestId) 
						&& array_key_exists($itemId, $dueDate))
				{
					unset($datasource[$index]);
					unset($checked[$itemId]);
					unset($itemRequestId[$itemId]);
					unset($dueDate[$itemId]);

					$this->setDatasource($datasource);
					$this->setChecked($checked);
					$this->setItemRequestId($itemRequestId);
					$this->setDueDate($dueDate);

					$this->ItemList->databind();
				}
			}
		}
	}

	public function getCheckedItemIds()
	{
		$datasource = $this->getDatasource();
		$checked = $this->getChecked();

		$output = array();
		foreach ($datasource as $index => $row)
		{
			$itemId = $row['id'];
			if ($itemId > 0)
			{	
				if (array_key_exists($itemId, $checked))
				{
					if ($checked[$itemId])
					{
						$row['checked'] = true;
						$itemRequestId = $this->_itemRequestId[$itemId];
						$dueDate = $this->_dueDate[$itemId];
						$output[] = array(	'itemId' => $itemId, 
											'dueDate' => $dueDate, 
											'itemRequestId' => $itemRequestId );
					}
				}
			}
		}
		
		$this->setChecked($checked);
		$this->setItemRequestId($this->_itemRequestId);
		$this->setDueDate($this->_dueDate);
		$this->setDatasource($datasource);

		return $output;
	}

	public function setItemIds($addedDatasource)
	{
		if (count($addedDatasource) == 0)
			return false;

		$datasource = $this->getDatasource();

		foreach ($addedDatasource as $row)
		{
			$itemId = $row['itemId'];
			$manifestationId = $row['manifestationId'];
			$dueDate = $row['dueDate'];
			$itemRequestId = $row['itemRequestId'];
			$loanStatus = $row['loanStatus'];
			$checked = false;

			if ($itemId > 0)
			{
				$item = ItemQuery::create()->findPk($itemId);
				if ($item instanceof Item)
				{
					if (is_null($dueDate))
					{
						if ($loanStatus == ItemPeer::LOANSTATUS_READYFORLOAN)
						{
							$dueDate = $this->_loanmanager->CalculateDueDate($item);
						}
						else
						{
							$dueDate = Clavis::dateFormat($item->getDueDate('U'),'shortdate shorttime');
							if (is_null($dueDate) || in_array($loanStatus, ItemPeer::getLoanStatusAvailable()))
								$dueDate = $this->_loanmanager->CalculateDueDate($item);
						}
					}

					$row = array(	'id' => $itemId,
									'manifestationId' => $manifestationId,
									'checked' => true,
									'data' => $this->getTitle($item) );

					$this->_checked[$itemId] = false;
					$this->_itemRequestId[$itemId] = $itemRequestId;
					$this->_dueDate[$itemId] = $dueDate;

					$datasource[] = $row;
				}
			}
		}
		
		$this->setChecked($this->_checked);
		$this->setItemRequestId($this->_itemRequestId);
		$this->setDueDate($this->_dueDate);
		$this->setDatasource($datasource);
	}

	private function getTitle($item = null)
	{
		if (!($item instanceof Item))
			return '---';

		$itemtit = $item->getCompleteTitle();
		
		if (!$itemtit)
			$itemtit = Prado::localize('(nessun titolo)');

		$output = $itemtit . $item->getExternalString();

		if (in_array($item->getLoanClass(), ItemPeer::getLoanClassesConsultation()))
			$output = '[<b>' . $item->getLoanClassString() . '</b>]&nbsp;' . $output;

		$output .= '<br />' . Prado::localize("gestito da: {homeLib}",
										array('homeLib' => $item->getHomeLibraryLabel(true, true)));
		
		return $output;
	}

	/**
	 * It changes the status (on/off) of the checkbox of one chosen
	 * row item of datagrid.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onFlipChecked($sender, $param)
	{
		$index = $sender->Parent->ItemIndex;
		$datasource = $this->getDatasource();

		$row = $datasource[$index];
		$itemId = $row['id'];
		$checked = $this->_checked[$itemId];
		$checked = !$checked;
		$this->_checked[$itemId] = $checked;
		$this->setChecked();
	}

	/**
	 * It performs population of datagrid.
	 * It returns true whether there are rows, false if datagrid
	 * if empty.
	 *
	 * @return boolean
	 */
	public function populate()
	{
		$datasource = $this->getDatasource();

		$checkedArray = $this->getChecked();
		$dueDateArray = $this->getDueDate();

		$newPartialDatasource = array();
		$count = count($datasource);

		foreach ($datasource as $index => $row)
		{
			$id = $row['id'];
			$item = ItemQuery::create()->findPk($id);

			$manifestation = $item->getManifestation();
			if ($manifestation instanceof Manifestation)
			{
				$objectType = 'Manifestation';
			}
			else
			{
				$objectType = 'Item';
			}
			
			if (array_key_exists($id, $checkedArray))
			{
				$checked = $checkedArray[$id];
			}
			else
			{
				$checked = true;
			}

			$dueDate = 0;

			if (array_key_exists($id, $dueDateArray))
			{
				$dueDate = $dueDateArray[$id];
			}
			else
			{
				$dueDate = $this->_loanmanager->CalculateDueDate($item);
				$dueDateArray[$id] = $dueDate;
			}

			$newPartialDatasource[$index] = $row;
			$newPartialDatasource[$index]['checked'] = $checked;
			$newPartialDatasource[$index]['dueDate'] = $dueDate;
		}

		$this->ItemList->setDataSource($newPartialDatasource);
		$this->ItemList->dataBind();
		$this->FoundNumber->setText($count);
		$this->HiddenFoundNumber->setValue($count);

		$this->setChecked($checkedArray);
		$this->setDueDate($dueDateArray);

		return (count($newPartialDatasource) > 0);
	}

	/**
	 * Are we into a popup ? ...
	 *
	 * @return boolean
	 */
	public function getPopupFlag()
	{
		return $this->getPage()->IsPopup();
	}

	public function getDatasourceIds()
	{
		$datasource = $this->getDatasource();
		$this->resetDataSource();
		$return = array();
		
		foreach ($datasource as $row)
			$return[] = $row['id'];

		return $return;
	}

	public function onColorize($sender, $param)
	{
		$item = $param->Item;
    	$loanStatus = $item->DataItem['loanStatus'];
		$available = $item->DataItem['available'];

		if (!is_null($loanStatus) && $available)
		{
			if (in_array($loanStatus, ItemPeer::getLoanStatusAvailable()))
				$item->setCssClass('evidenced_lightred');

			if ($loanStatus == ItemPeer::LOANSTATUS_READYFORLOAN)
				$item->setCssClass('evidenced_green');
		}
	}
	
}
