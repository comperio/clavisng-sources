<?php

/**
 * ClavisInventorySerieView class
 *
 * @author Max Pigozzi <mpigozzi@e-portaltech.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @version 2.7
 * @package Widgets
 * @since 2.0
 */
class ClavisInventorySerieView extends TTemplateControl
{
	/**
	 * Object Inventory serie which we are treating.
	 *
	 * @var InventorySerie
	 */
	private $_inventorySerie = null;

	public function onLoad($param)
	{
		parent::onLoad($param);
		if (!$this->getPage()->getIsPostBack())
		{
			$this->getInventorySerie();
			$this->populate();
		}
	}

	public function setInventorySerie($inventorySerie)
	{
		$this->_inventorySerie = $inventorySerie;
		$this->setControlState("inventory_serie", $inventorySerie, null);
	}

	public function getInventorySerie()
	{
		if (is_null($this->_inventorySerie))
			$this->_inventorySerie = $this->getControlState("inventory_serie", null);
		return $this->_inventorySerie;
	}

	public function populate()
	{
		if (is_null($this->_inventorySerie) || ($this->_inventorySerie->isNew()) || (!($this->_inventorySerie instanceof InventorySerie)))
			return;

		$this->InventorySerieID->setText($this->_inventorySerie->getInventorySerieId());
		$library = $this->_inventorySerie->getLibrary();
		if (!is_null($library))
			$this->LibraryLabel->setText($library->getLabel());

		$this->Description->setText($this->_inventorySerie->getDescription());
		$this->ClosedSerie->setChecked($this->_inventorySerie->getClosed());
		$this->ReadOnlySerie->setChecked($this->_inventorySerie->getReadonly());
		$this->InvCounter->setText($this->_inventorySerie->getInventoryCounter());
	}
	
}