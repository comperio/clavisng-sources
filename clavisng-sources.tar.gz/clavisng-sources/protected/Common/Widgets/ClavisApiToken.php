<?php

/**
 * ClavisApiToken class file.
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 * For Commercial Licenses and support please contact Comperio.
 * @author    Mauro Seno <mauro.seno@comperio.it>
 * @link      http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2019 Comperio srl
 * @license   http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version   2.9.1
 */

/**
 * ClavisApiToken Class
 * @author  Mauro Seno <mauro.seno@comperio.it>
 * @version 2.9.1
 * @since   2.9.1
 */
class ClavisApiToken
{
	public const LIBRARIAN_BOT = 'LIBRARIAN_BOT';

	private $_librarian;
	private $_domain;

	/**
	 * ClavisApiToken constructor.
	 * @param \Librarian $librarian
	 * @param string     $domain
	 */
	public function __construct(Librarian $librarian, string $domain)
	{
		$this->_librarian = $librarian;
		$this->_domain = $domain;
	}

	/**
	 * @param string $password
	 * @return string|null
	 */
	public function generate(string $password): ?string
	{
		$crypt = Prado::getapplication()->getmodule('crypt');
		if ($crypt->LibrarianVerify($password, $this->getLibrarian()->getSecret())) {
			switch ($this->_domain) {
				case self::LIBRARIAN_BOT:
					$token = $this->getTokenLibrarianBot();
					break;
				default:
					throw new RuntimeException('ClavisApiToken domain not valid: ' . $this->_domain);
					break;
			}
			return $token;
		}
		return null;
	}

	/**
	 * @return \Librarian
	 */
	private function getLibrarian(): Librarian
	{
		return $this->_librarian;
	}

	/**
	 * @return string
	 * @throws \PropelException
	 */
	private function getTokenLibrarianBot(): string
	{
		$params = [
			'api_url' => $this->getBotApiEndpoint(),
			'librarian_id' => $this->getLibrarian()->getLibrarianId(),
			'consortia_id' => LibraryQuery::create()->findOneByLibraryId(
				$this->getLibrarian()->getDefaultLibraryId()
			)->getConsortiaId()
		];

		$token = ClavisToken::create()->build($params);
		return $token;
	}

	/**
	 * @param string         $token
	 * @param \DateTime|null $expires
	 * @return bool
	 * @throws \PropelException
	 */
	public function save(string $token, DateTime $expires = null)
	{
		$atq = ApiTokenQuery::create()
			->filterByLibrarianId($this->getLibrarian()->getLibrarianId())
			->filterByDomain($this->_domain)
			->findOneOrCreate();

		if ($atq instanceof ApiToken) {
			$savedToken = $atq->getToken();
			if ($savedToken === '') {
				// brand new record
				$atq->setToken($token);
			} else {
				// update an existing record
				$atq->setLibraryId(null);
				$atq->setToken($token);
				$atq->setUsageCount(0);
				$atq->setExpires($expires);
				$atq->setLastUsed(null);
			}
			$atq->save();
			return true;
		}
		return false;
	}

	/**
	 * @return string
	 */
	private function getRestApiEndPoint(): string
	{
		$req = Prado::getApplication()->getRequest();
		return $req->getBaseUrl() . $req->constructUrl('Services.ClavisRestApi', null);
	}

	private function getBotApiEndpoint()
	{
		//must be in the form: clavis-url/index.php/botapi/v1/"
		$req = Prado::getApplication()->getRequest();
		return $req->getAbsoluteApplicationUrl() . '/botapi/v1/';
	}
}