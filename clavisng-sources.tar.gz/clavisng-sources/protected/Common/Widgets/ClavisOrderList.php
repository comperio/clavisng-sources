<?php

/**
 * ClavisOrderList
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @copyright Copyright &copy; 2010 Comperio srl
 * @version 2.7
 * @package Widgets
 * @since 2.2
 */

class ClavisOrderList extends TTemplateControl
{
    protected $budget;

    public function onLoad($param)
    {
        parent::onLoad($param);

		if ((!$this->getPage()->getIsPostBack()) && (!$this->getPage()->getIsCallBack())) 
		{
			$this->resetFilters();
			
            $librariesWithBlank = LibraryPeer::getLibrariesHashWithBlank(false, true);
            $this->LibraryFilter->setDataSource($librariesWithBlank);
            $this->LibraryFilter->dataBind();
            $this->OrderGrid->resetPagination();
			
			if ($this->getAutomaticPopulate())
				$this->populateOrderGrid();
        }
    }

	/**
	 *	Setters and getters 
	 */
	
	public function setAutomaticPopulate($flag = true)
	{
		if ($flag === "true")
			$flag = true;
		elseif ($flag === "false")
			$flag = false;
		
		$this->setViewState("automaticPopulate", $flag, true);
	}

	public function getAutomaticPopulate()
	{
		return $this->getViewState("automaticPopulate", true);
	}
	
    public function setBudget($budget = null)
    {
		$this->budget = $budget;
		$this->setControlState('budget', $budget, null);
    }

    public function getBudget()
    {
		$this->budget = $this->getControlState('budget', null);
		return $this->budget;
    }
	
	public function setFilterVisible($value = true)
	{
		if (is_string($value))
			$value = ($value == 'true' ? true : false);
		
		$this->setControlState('filter_visible', $value, true);
	}

	public function getFilterVisible()
	{
		return $this->getControlState('filter_visible', true);
	}
	
    public function setSupplierFilterId($param)
    {
        $this->setControlState('SupplierFilter', $param, null);
    }

    public function getSupplierFilterId()
    {
        return $this->getControlState('SupplierFilter', null);
    }
	
	private function getSupplierFilter()
	{
		$id = intval($this->getSupplierFilterId());
		if ($id > 0)
		{
			$supplier = SupplierQuery::create()
					->findPk($id);
			
			if ($supplier instanceof Supplier)
				return $supplier->getSupplierName();
			else
				return null;
		}
		else
			return null;
	}
	
	private function resetFilters()
	{
		$this->OrderFilter->setText('');
		$this->LibraryFilter->setSelectedValue(0);
		$this->SupplierFilter->setText('');
		$this->OrderStatusFilter->setSelectedValue(-1);
	}
	
    public function populate()
    {
        $this->populateOrderGrid();
    }

    private function populateOrderGrid()
    {
        $pageSize = $this->OrderGrid->getPageSize();
        $currentIndexPage = $this->OrderGrid->getCurrentPage();

        $criteria = new Criteria();

        $orderId = trim($this->OrderIDFilter->getSafeText());
        if ($orderId != '')
            $criteria->addAnd(PurchaseOrderPeer::ORDER_ID, $orderId);

		$orderFilter = $this->OrderFilter->getSafeText();
        if ($orderFilter != '')
            $criteria->addAnd(PurchaseOrderPeer::ORDER_TITLE, "%$orderFilter%", Criteria::LIKE);

        $libraryFilter = $this->LibraryFilter->getSelectedValue();
        if ($libraryFilter > 0)
            $criteria->addAnd(PurchaseOrderPeer::LIBRARY_ID, $libraryFilter);

		$this->SupplierColumn->setVisible(true);
		$supplierFilter = trim($this->SupplierFilter->getSafeText());
		if	(!is_null($supplierFilter) && ($supplierFilter != '')) 
		{
            $c = new Criteria();
            $c->addAnd(SupplierPeer::SUPPLIER_NAME, "%$supplierFilter%", Criteria::LIKE);
            $suppliers = SupplierPeer::doSelect($c);

            $suppliersId = array();
            foreach ($suppliers as $supplier)
                $suppliersId[] = $supplier->getSupplierId();

            $criteria->addAnd(PurchaseOrderPeer::SUPPLIER_ID, $suppliersId, Criteria::IN);
        }
		else
		{
			$supplierFilterId = intval($this->getSupplierFilterId());
			if ($supplierFilterId > 0)
			{
				$criteria->addAnd(PurchaseOrderPeer::SUPPLIER_ID, $supplierFilterId);
				$this->SupplierColumn->setVisible(false);
			}
		}

        if ($this->ExpiredFilter->getChecked())
            $criteria->addAnd(PurchaseOrderPeer::DELIVERY_DATE, time(), Criteria::LESS_THAN);

        $orderStatusFilter = $this->OrderStatusFilter->getSelectedValue();
        if ($orderStatusFilter != '0' && $orderStatusFilter != '')
            $criteria->addAnd(PurchaseOrderPeer::ORDER_STATUS, $orderStatusFilter);

        $recCount = PurchaseOrderPeer::doCount($criteria);
        $this->OrderGrid->setVirtualItemCount($recCount);

        $this->RecCounter->setText($recCount);

        $criteria->setLimit($pageSize);
        $criteria->setOffset($currentIndexPage * $pageSize);

        $this->calculateSortingCriteria($criteria);

        $orders = PurchaseOrderPeer::doSelect($criteria);

        $this->OrderGrid->setDataSource($orders);
        $this->OrderGrid->dataBind();
    }

    public function searchOrder($sender, $param)
    {
		$this->OrderGrid->CurrentPageIndex = 0;
		$this->populate();
		//$this->getPage()->globalRefresh();
    }

    public function onCancel()
    {
        $this->searchCancel(null, null);
    }

    public function searchCancel($sender, $param)
    {
		$this->resetFilters();
		
        $this->searchOrder(null, null);
    }

    public function changePage($sender, $param)
    {
        $this->OrderGrid->setCurrentPage($param->NewPageIndex);
        $this->getPage()->globalRefresh();
    }

    public function getPopupFlag()
    {
        return $this->getPage()->IsPopup();
    }

    public function getUnlinkFlag()
    {
        return $this->getPage()->IsUnlink();
    }

    public function calculateSortingCriteria(&$sortingCriteria = null)
    {
        $sortingExpression = $this->OrderGrid->getSortingExpression();
        $sortingDirection = $this->OrderGrid->getSortingDirection();

        if (! $sortingCriteria instanceof Criteria)
            $sortingCriteria = new Criteria();

        switch ($sortingExpression)
        {
            case 'id':
                $sortingCriteria->clearOrderByColumns();
                if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
                    $sortingCriteria->addAscendingOrderByColumn(PurchaseOrderPeer::ORDER_ID);
                else
                    $sortingCriteria->addDescendingOrderByColumn(PurchaseOrderPeer::ORDER_ID);
                break;
            case 'orderDate':
                $sortingCriteria->clearOrderByColumns();
                if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
                    $sortingCriteria->addAscendingOrderByColumn(PurchaseOrderPeer::ORDER_DATE);
                else
                    $sortingCriteria->addDescendingOrderByColumn(PurchaseOrderPeer::ORDER_DATE);
                break;
            case 'deliveryDate':
                $sortingCriteria->clearOrderByColumns();
                if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
                    $sortingCriteria->addAscendingOrderByColumn(PurchaseOrderPeer::DELIVERY_DATE);
                else
                    $sortingCriteria->addDescendingOrderByColumn(PurchaseOrderPeer::DELIVERY_DATE);
                break;

            default:
                $sortingCriteria->clearOrderByColumns();
                $sortingDirection = !$sortingDirection;
                $sortingCriteria->addDescendingOrderByColumn(PurchaseOrderPeer::DATE_CREATED);
                break;
        }
    }

}
