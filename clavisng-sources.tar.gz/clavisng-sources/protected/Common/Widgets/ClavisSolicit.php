<?php
/**
 * ClavisSolicit class file
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Widgets
 */
Prado::using('Application.Common.SolicitModules.*');

/**
 * ClavisSolicit class
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Widgets
 * @since 2.1
 */
class ClavisSolicit extends TTemplateControl
{
	const NULL_CHANNEL = 'NULL_CHANNEL';
	private $_notificationModule;
	private $_activeChannel = '';

	public function onLoad($param)
	{
		parent::onLoad($param);

		$this->_notificationModule = $this->getApplication()->getModule('notification');
		$ds = $this->ChanList->getDataSource();
		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallback())
			$this->initChannels();
		$this->drawChanPanel();
	}

	public function initChannels()
	{
		$contactChannels = array(
			NotificationPeer::CHANNEL_EMAIL,
			NotificationPeer::CHANNEL_SNAILMAIL,
			NotificationPeer::CHANNEL_SMS,
			NotificationPeer::CHANNEL_MOBILE,
			NotificationPeer::CHANNEL_PHONE,
            NotificationPeer::CHANNEL_AUTO
		);
		$control = $this;
		do
		{
			$control = $control->getParent();
			if (method_exists($control, 'getContactChannels'))
			{
				$contactChannels = $control->getContactChannels();
				break;
			}
		}
		while (!$control instanceof TPage);

		// manage 0 channels available
		if (!count($contactChannels))
		{
			$channelsToEnable = array(	array(	'value' => self::NULL_CHANNEL,
												'label' => Prado::localize('Nessun canale disponibile per la notifica') ) );
			
			$this->ChanList->setDataSource($channelsToEnable);
			$this->ChanList->setEnabled(false);
			$this->ChanList->dataBind();
			$this->ChanPanel->setCssClass('panel_off');
			return;
		}

		$channelsToEnable = array(array('value' => self::NULL_CHANNEL, 'label' => '---'));

     //   $channelsToEnable[] = array('value' => 'SolicitAuto', 'label' => 'Automatico');

		if ('true' == ClavisParamQuery::getParam('CLAVISPARAM', 'EnableChannelEmail') && in_array(NotificationPeer::CHANNEL_EMAIL, $contactChannels))
			$channelsToEnable[] = array('value' => 'SolicitEmail', 'label' => 'E-Mail');

		if ('true' == ClavisParamQuery::getParam('CLAVISPARAM', 'EnableChannelSnailmail') && in_array(NotificationPeer::CHANNEL_SNAILMAIL, $contactChannels))
			$channelsToEnable[] = array('value' => 'SolicitSnailMail', 'label' => 'Posta ordinaria');

		if ('true' == ClavisParamQuery::getParam('CLAVISPARAM', 'EnableChannelSMS') && in_array(NotificationPeer::CHANNEL_SMS, $contactChannels))
			$channelsToEnable[] = array('value' => 'SolicitSMS', 'label' => 'SMS');

		if ('true' == ClavisParamQuery::getParam('CLAVISPARAM', 'EnableChannelPhone') && in_array(NotificationPeer::CHANNEL_PHONE, $contactChannels))
			$channelsToEnable[] = array('value' => 'SolicitManualPhone', 'label' => 'Telefono (MANUALE)');

		if ('true' == ClavisParamQuery::getParam('CLAVISPARAM', 'EnableChannelPhone') && in_array(NotificationPeer::CHANNEL_MOBILE, $contactChannels))
			$channelsToEnable[] = array('value' => 'SolicitManualMobile', 'label' => 'Cellulare (MANUALE)');

		$this->ChanList->setDataSource($channelsToEnable);
		$this->ChanList->dataBind();
		$this->ChanPanel->setCssClass('panel_off');
	}

	protected function activateChannel($chan = null)
	{
		$this->ChanParams->getControls()->clear();
		if ($chan == self::NULL_CHANNEL || !class_exists($chan))
			return;
		$this->_activeChannel = new $chan;
		$this->_activeChannel->setID($chan);
		$this->ChanParams->addParsedObject($this->_activeChannel);
		$this->_activeChannel->setSolicitMode($this->getSolicitMode());
		// recursively get destinations and loanids from Parents
		$control = $this;
		do
		{
			$control = $control->getParent();
			if (method_exists($control, 'getDestinations'))
			{
				$this->_activeChannel->setDestinations($control->getDestinations());
				$this->_activeChannel->setLoanIds($control->getLoanIds());
				break;
			}
		}
		while (!$control instanceof TPage);
	}

	protected function drawChanPanel($reset = false)
	{
		$this->activateChannel($this->ChanList->getSelectedValue());
		if ($reset && $this->_activeChannel instanceof BaseSolicit)
			$this->_activeChannel->activate();
		if (!$this->_activeChannel instanceof BaseSolicit)
		{
			$this->ChanPanel->setCssClass('panel_off');
		}
		else
		{
			try
			{
				$this->ChanPanel->setCssClass('panel_on');
			}
			catch (Exception $e)
			{
				$this->ChanPanel->setCssClass('panel_off');
			}
		}
	}

	public function chanSelect($sender, $param)
	{
		$this->drawChanPanel(true);
		if ($this->getPage()->getIsCallback())
		{
			$this->ChanPanel->render(($param instanceof TCallbackEventParameter) ?
							$param->getNewWriter() : $this->getPage()->createWriter());
		}
		
		if ($this->_activeChannel instanceof BaseSolicit)
			$this->NotificationButton->setEnabled($this->_activeChannel->isActive());
	}

	public function setSolicitMode($value)
	{
		$this->setControlState('SolicitMode', $value, 'solicit');
	}

	public function getSolicitMode()
	{
		return $this->getControlState('SolicitMode', 'solicit');
	}

	public function DoNotify($sender, $param)
	{
		$userLibrarian = $this->getUser();

		// actual notification
		$this->_activeChannel->setDescription($this->SolicitDescription->getSafeText());

		$lm = $this->getApplication()->getModule('loan');

		switch ($this->getSolicitMode())
		{
			case 'solicit':
				$itemActionType = ItemActionPeer::TYPE_SOLICIT;
                $status = $this->_activeChannel->notify('A');
				break;
			case 'readyforloan':
				$itemActionType = ItemActionPeer::TYPE_NOTIFY;
                $status = $this->_activeChannel->notify('F');
				break;
			default:
				$itemActionType = ItemActionPeer::TYPE_NOTIFY;
                $status = $this->_activeChannel->notify();
				break;
		}

		// update notified items
		foreach ($status['sent'] as $sent)
		{
			$loans = LoanQuery::create()
					->filterByLoanId($sent['loan_ids']);

			$d = $sent['destination'];
			if ($d instanceof Patron)
				$loans->filterByPatronId($d->getPatronId());
			elseif ($d instanceof Library)
			{
				$loans->filterByExternalLibraryId($d->getLibraryId());
			}
			else
			{
				continue;
			}
			
			foreach ($loans->find() as $loan)
			{
				$iaction = $lm->DoSolicitLoan($loan, $d, $userLibrarian, '[' . $this->ChanList->getSelectedItem()->getText() . '] ' .
						$this->_activeChannel->getDescription(), $itemActionType);

                if($iaction instanceof ItemAction)
                {
                    $iaction->setLoan($loan);
                    if(isset($sent['notification_id']))
                        $iaction->setNotificationId($sent['notification_id']);

                    $iaction->save();
                }


			}
		}

		// set message type upon return status
		if (count($status['sent']) && count($status['failed']))
		{
			$messageType = ClavisMessage::WARNING;
		}
		elseif (count($status['failed']))
		{
			$messageType = ClavisMessage::ERROR;
		}
		else
		{
			$messageType = ClavisMessage::CONFIRM;
		}

		$msg = '';
		switch ($this->getSolicitMode())
		{
			case 'solicit':
				if ($status['sent'])
					$msg .= Prado::localize("{count} solleciti sono stati correttamente inviati<br />\n", array('count' => count($status['sent'])));
				if ($status['failed'])
				{
					$msg .= Prado::localize("{count} solleciti NON sono stati inviati - seguono i messaggi d'errore:<br />\n", array('count' => count($status['failed'])));
					foreach ($status['failed'] as $f)
						$msg .= "{$f['errormsg']}\n";
				}
				
				break;
				
			case 'readyforloan':
				if ($status['sent'])
					$msg .= Prado::localize("{count} notifiche sono state correttamente inviate<br />\n", array('count' => count($status['sent'])));
				if ($status['failed'])
				{
					$msg .= Prado::localize("{count} notifiche NON sono state inviate - seguono i messaggi d'errore:<br />\n", array('count' => count($status['failed'])));
					foreach ($status['failed'] as $f)
						$msg .= "{$f['errormsg']}<br />\n";
				}
				
				break;
				
			case 'warning':
				if ($status['sent'])
					$msg .= Prado::localize("{count} avvisi sono stati correttamente inviati<br />\n", array('count' => count($status['sent'])));
				if ($status['failed'])
				{
					$msg .= Prado::localize("{count} avvisi NON sono stati inviati - seguono i messaggi d'errore:<br />\n", array('count' => count($status['failed'])));
					foreach ($status['failed'] as $f)
						$msg .= "{$f['errormsg']}<br />\n";
				}
				
				break;
				
			default:
				break;
		}
		$this->getPage()->writeDelayedMessage($msg, $messageType);
		$this->getPage()->reloadPage();
	}
	
}