<?php
/**
 * ClavisItemList class file
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 */

/**
 * ClavisItemList class
 *
 * This component visualizes the items which are stored in the
 * databases, related to a manifestation, into a datagrid.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @author Ciro Mattia Gonano
 * @version 2.7
 * @package Widgets
 * @since 2.2
 */
class ClavisItemList extends TTemplateControl
{
	const INVALIDEMAIL = '**NOeMail**';
	private $_checked = array('all' => false);
	private $_checkedSessionName;
	private $_datasource;
	private $_datasourceSessionName;
	public $_item;
	protected $_loanmanager;
	protected $_requestManager;
	protected $_sbnMod;
	public $_masterChecked;
	public $manifestation;
	public $authority;
	public $llibEnabled = false;
	const ICON_DELIVERED = 'check-16.png';
	const ICON_NOT_DELIVERED = 'delete-16.png';

	private function initVars()
	{
		$uniqueId = $this->getUniqueID();
		$this->_datasourceSessionName = 'DataSourceSessionName' . $uniqueId;
		$this->_checkedSessionName = 'CheckedSessionName' . $uniqueId;
		$this->_checked = $this->getCheckedItems();
		$this->_loanmanager = $this->getApplication()->getModule('loan');
		$this->_requestManager = $this->getApplication()->getModule('request');
		$this->_sbnMod = $this->getApplication()->getModule('sbn');
	}

	public function onInit($param)
	{
		parent::onInit($param);
		$this->initVars();

		$this->CurrencyAmountPanel->setVisible(false);
		$this->attachEventHandler('OnActualLibraryChanged', array($this, 'OnActualLibraryChanged'));
	}

	/**
	 * @param $sender
	 * @param $param
	 * @throws \PropelException
	 */
	public function OnActualLibraryChanged($sender, $param)
	{
		if ($this->getAutomaticPopulate())
			$this->populate();
	}

	public function onLoad($param)
	{
		parent::onLoad($param);

		$this->llibEnabled = LLibraryPeer::isEnabled();

		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallBack())
		{
			$this->resetDataSource(false);	// don't populate

			if ($this->getAutomaticPopulate())
				$this->populate();
		}
	}

	public function setAutomaticPopulate($flag = true)
	{
		if ($flag === "true")
		{
			$flag = true;
		}
		elseif ($flag === "false")
		{
			$flag = false;
		}

		$this->setViewState("automaticPopulate", $flag, true);
	}

	public function getAutomaticPopulate()
	{
		return $this->getViewState("automaticPopulate", true);
	}

	public function setPopupEnableView($val = null)
	{
		$this->setViewState('PopupEnableView', $val, null);
	}

	public function getPopupEnableView()
	{
		$val = $this->getViewState('PopupEnableView', null);

		if (!is_null($val))
		{
			if (TPropertyValue::ensureBoolean($val) == true)
			{
				$val = true;
			}
			else
			{
				$val = false;
			}
		}

		return $val;
	}

	// -----------------------------------------------------------------------------------------------------------------
	// Load criteria from state
	// -----------------------------------------------------------------------------------------------------------------

	public function setGlobalCriteria($criteria = null)
	{
		$this->setViewState('GlobalCriteria', $criteria, null);
	}

	public function getGlobalCriteria()
	{
		return SerializableCriteria::refreshCriteria($this->getViewState('GlobalCriteria', null));
	}

	public function setExternalCriteria($criteria = null)
	{
		$this->setControlState('ExternalCriteria', $criteria, null);
	}

	public function getExternalCriteria()
	{
		$output = $this->getControlState('ExternalCriteria', null);
		$output = SerializableCriteria::refreshCriteria($output);

		if (is_object($output))
			return clone($output);

		return $output;
	}

	public function resetExternalCriteria()
	{
		$this->setExternalCriteria(new Criteria());
	}

	// -----------------------------------------------------------------------------------------------------------------

	public function resetDataSource($populateFlag = true)
	{
		$this->RecCounterPanel->setVisible(false);

		$this->ItemGrid->resetPagination();
		$this->resetCheckedItems();
		$this->_datasource = array();
		$this->getApplication()->getSession()->add($this->_datasourceSessionName, $this->_datasource);
		$this->resetSorting();

		$this->InventoryAmountValue->setValue(null);

		if ($populateFlag)
			$this->populate();
	}

	public function setDatasource($datasource = null)
	{
		$this->_datasource = $datasource;
		$this->getApplication()->getSession()->add($this->_datasourceSessionName, $datasource);
	}

	public function getDatasource()
	{
		$this->_datasource = $this->getApplication()->getSession()->itemAt($this->_datasourceSessionName);

		return $this->_datasource;
	}

	public function onFlipChecked($sender, $param)
	{
		$checked = $this->getCheckedItems();

		$index = $sender->Parent->Parent->ItemIndex;
		$newStatus = $sender->getChecked();
		$dataSource = $this->getDatasource();

		if (array_key_exists($index, $dataSource))
			$row = $dataSource[$index];

		$itemId = $row['Id'];

		if ($newStatus != $checked['all'])
		{
			$checked[$itemId] = true;
		}
		else
		{
			unset($checked[$itemId]);
		}

		$this->setCheckedItems($checked);
	}

	public function onMasterChecked($sender, $param)
	{
		$newStatus = $sender->getChecked();
		$this->resetCheckedItems($newStatus);

		foreach ($this->ItemGrid->getItems() as $item)
			$item->CheckColumn->CheckedBox->setChecked($newStatus);
	}

	public function setMasterChecked($newChecked = false, $param = null)
	{
		$this->resetCheckedItems($newChecked);
		$gridItems = $this->ItemGrid->getItems();
		$header = $this->ItemGrid->getHeader();

		foreach ($gridItems as $item)
			$item->CheckColumn->CheckedBox->setChecked($newChecked);

		if (count($gridItems) > 0)
			$header->CheckColumn->MasterCheck->setChecked($newChecked);
	}

	public function resetCheckedItems($state = false)
	{
		$this->setCheckedItems(array('all' => $state));
	}

	public function setCheckedItems($checked = null)
	{
		$this->_checked = $checked;
		$this->getApplication()->getSession()->add($this->_checkedSessionName, $checked);
	}

	public function getCheckedItems()
	{
		$this->_checked = $this->getApplication()->getSession()->itemAt($this->_checkedSessionName);

		return $this->_checked;
	}

	public function getCheckedId($force = false, $reset = false)
	{
		$checked = $this->getCheckedItems();
		$this->_masterChecked = $checked['all'];
		unset($checked['all']);
		$checkedIds = array_keys($checked);
		$output = array();

		if (!$this->_masterChecked)
		{
			$output = $checkedIds;
		}
		else
		{ // caso del mastercheck inverso
			$items = null;
			$criteria = $this->getGlobalCriteria();

			if ($criteria instanceof Criteria)
			{
				$criteria->add(ItemPeer::ITEM_ID, $checkedIds, Criteria::NOT_IN);
				$criteria->clearSelectColumns()->addSelectColumn(ItemPeer::ITEM_ID);
				$criteria->addAsColumn('label', 'IFNULL((SELECT label FROM library WHERE library.LIBRARY_ID=item.HOME_LIBRARY_ID LIMIT 1),\'\')');

				if ($this->llibEnabled)
					$criteria->addAsColumn('distance', 'IFNULL((SELECT distance FROM l_library WHERE FROM_LIBRARY_ID=item.HOME_LIBRARY_ID AND TO_LIBRARY_ID=' . $this->getUser()->getActualLibraryId() . ' LIMIT 1),\'-1\')');

				$stmt = ItemPeer::doSelectStmt($criteria);
				$output = $stmt->fetchAll(PDO::FETCH_COLUMN,0);
			}
			elseif (!is_null($criteria) && is_array($criteria))
			{
				$output = array_fill_keys(array_diff($criteria, $checkedIds), true);
			}
		}

		if ((count($output) == 0)
				&& ($force == true))
		{
			$this->setMasterChecked(true);
			$output = $this->getCheckedId();

			if ($reset)
				$this->setMasterChecked(false);
		}

		return $output;
	}

	public function setManifestation($manifestation)
	{
		$this->manifestation = $manifestation;
		$this->setControlState('manifestation', $manifestation, null);
	}

	public function getManifestation()
	{
		if (is_null($this->manifestation))
			$this->manifestation = $this->getControlState('manifestation', null);

		return $this->manifestation;
	}

	public function setAuthority($authority)
	{
		$this->authority = $authority;
		$this->setControlState('authority', $authority, null);
	}

	public function getAuthority()
	{
		if (is_null($this->authority))
			$this->authority = $this->getControlState('authority', null);

		return $this->authority;
	}

	public function getIssuePanelVisibility()
	{
		$m = $this->getManifestation();

		return ($m instanceof Manifestation && $m->getBibLevel() == ManifestationPeer::LVL_SERIAL);
	}

	public function setIssue($issue)
	{
		$this->setControlState('issue', $issue, null);
	}

	public function getIssue()
	{
		return $this->getControlState('issue', null);
	}

	public function setItemRequest($itemRequest)
	{
		$this->setControlState('item_request', $itemRequest, null);
	}

	public function getItemRequest()
	{
		return $this->getControlState('item_request', null);
	}

	public function setPurchaseOrder($purchase_order)
	{
		$this->setControlState('purchase_order', $purchase_order, null);
	}

	public function getPurchaseOrder()
	{
		return $this->getControlState('purchase_order', null);
	}

	public function setInvoice($invoice)
	{
		$this->setControlState('invoice', $invoice, null);
	}

	public function getInvoice()
	{
		return $this->getControlState('invoice', null);
	}

	public function setFilter($filter = null)
	{
		$this->setControlState('filter', $filter, null);
	}

	public function getFilter()
	{
		return $this->getControlState('filter', null);
	}

	public function setHomeLibraryId($param = null)
	{
		$this->setControlState('homeLibraryId', $param, null);
	}

	public function getHomeLibraryId()
	{
		return $this->getControlState('homeLibraryId', null);
	}

	public function setViewLibraryId($param = null)
	{
		$this->setControlState('viewLibraryId', $param, null);
	}

	public function getViewLibraryId()
	{
		return $this->getControlState('viewLibraryId', null);
	}

	public function setBudgetId($param = null)
	{
		$this->setControlState('budgetIdFilter', $param, null);
	}

	public function getBudgetId()
	{
		return $this->getControlState('budgetIdFilter', null);
	}

	public function getBudget()
	{
		$budget = null;
		$budgetId = intval($this->getBudgetId());

		if ($budgetId > 0)
			$budget = BudgetQuery::create()->findPk($budgetId);

		return $budget;
	}

	public function setDisablePopulate($value)
	{
		$this->setControlState('disable_populate', $value, false);
	}

	public function getDisablePopulate()
	{
		return $this->getControlState('disable_populate', false);
	}

	public function setVisualizationStyle($value)
	{
		$this->setControlState('visstyle', $value, 'default');
	}

	public function getVisualizationStyle()
	{
		return $this->getControlState('visstyle', 'default');
	}

	public function resetGivenItemIds()
	{
		$this->setGivenItemIds(array());
	}

	public function setGivenItemIds($ids)
	{
		$this->setControlState('GivenItemIds', TPropertyValue::ensureArray($ids), array());
	}

	public function getGivenItemIds()
	{
		return $this->getControlState('GivenItemIds', array());
	}

	public function resetExternalRecCount()
	{
		$this->setExternalRecCount(0);
	}

	public function setExternalRecCount($count)
	{
		$this->setControlState(intval('ExternalRecCount'), $count, 0);
	}

	public function getExternalRecCount()
	{
		return $this->getControlState('ExternalRecCount', 0);
	}

	public function calculateSortingCriteria(&$sortingCriteria = null)
	{
		$sortingExpression = $this->ItemGrid->getSortingExpression();
		$sortingDirection = $this->ItemGrid->getSortingDirection();

		if (!$sortingCriteria instanceof Criteria)
			$sortingCriteria = new Criteria();

		switch ($sortingExpression)
		{
			case 'issuedesc':
				$sortingCriteria->clearOrderByColumns();

				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
				{
					$sortingCriteria->addAscendingOrderByColumn(IssuePeer::ISSUE_NUMBER);
				}
				else
				{
					$sortingCriteria->addDescendingOrderByColumn(IssuePeer::ISSUE_NUMBER);
				}

				break;

			case 'title':
				$sortingCriteria->clearOrderByColumns();

				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
				{
					$sortingCriteria->addAscendingOrderByColumn(ItemPeer::TITLE);
				}
				elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
				{
					$sortingCriteria->addDescendingOrderByColumn(ItemPeer::TITLE);
				}

				break;

			case 'collocation':
				$sortingCriteria->clearOrderByColumns();

				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
				{
					$sortingCriteria->addAscendingOrderByColumn(ItemPeer::SECTION);
					$sortingCriteria->addAscendingOrderByColumn(ItemPeer::COLLOCATION);
					$sortingCriteria->addAscendingOrderByColumn(ItemPeer::SPECIFICATION);
					$sortingCriteria->addAscendingOrderByColumn(ItemPeer::SEQUENCE1);
					$sortingCriteria->addAscendingOrderByColumn(ItemPeer::SEQUENCE2);
					$sortingCriteria->addAscendingOrderByColumn(ItemPeer::INVENTORY_SERIE_ID);
					$sortingCriteria->addAscendingOrderByColumn(ItemPeer::INVENTORY_NUMBER);
				}
				elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
				{
					$sortingCriteria->addDescendingOrderByColumn(ItemPeer::SECTION);
					$sortingCriteria->addDescendingOrderByColumn(ItemPeer::COLLOCATION);
					$sortingCriteria->addDescendingOrderByColumn(ItemPeer::SPECIFICATION);
					$sortingCriteria->addDescendingOrderByColumn(ItemPeer::SEQUENCE1);
					$sortingCriteria->addDescendingOrderByColumn(ItemPeer::SEQUENCE2);
					$sortingCriteria->addDescendingOrderByColumn(ItemPeer::INVENTORY_SERIE_ID);
					$sortingCriteria->addDescendingOrderByColumn(ItemPeer::INVENTORY_NUMBER);
				}

				break;

			case 'issuevolume':
				$sortingCriteria->clearOrderByColumns();

				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
				{
					$sortingCriteria->addAscendingOrderByColumn(IssuePeer::ISSUE_VOLUME);
				}
				elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
				{
					$sortingCriteria->addDescendingOrderByColumn(IssuePeer::ISSUE_VOLUME);
				}

				break;

			case 'issuenumber':
				$sortingCriteria->clearOrderByColumns();

				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
				{
					$sortingCriteria->addAscendingOrderByColumn(ItemPeer::ISSUE_NUMBER);
				}
				elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
				{
					$sortingCriteria->addDescendingOrderByColumn(ItemPeer::ISSUE_NUMBER);
				}

				break;

			case 'issuedate':
				$sortingCriteria->clearOrderByColumns();

				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
				{
					$sortingCriteria->addAscendingOrderByColumn(ItemPeer::ISSUE_ARRIVAL_DATE);
				}
				elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
				{
					$sortingCriteria->addDescendingOrderByColumn(ItemPeer::ISSUE_ARRIVAL_DATE);
				}

				break;

			case 'issuedateexpected':
				$sortingCriteria->clearOrderByColumns();

				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
				{
					$sortingCriteria->addAscendingOrderByColumn(ItemPeer::ISSUE_ARRIVAL_DATE_EXPECTED);
				}
				elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
				{
					$sortingCriteria->addDescendingOrderByColumn(ItemPeer::ISSUE_ARRIVAL_DATE_EXPECTED);
				}

				break;

			case 'libname':
				if ($this->manifestation instanceof Manifestation &&
					$this->manifestation->getBibLevel() == ManifestationPeer::LVL_SERIAL)
				{
					$sortingCriteria->addDescendingOrderByColumn(IssuePeer::ISSUE_YEAR);
					$sortingCriteria->addDescendingOrderByColumn(IssuePeer::ISSUE_VOLUME);
					$sortingCriteria->addDescendingOrderByColumn(IssuePeer::ISSUE_NUMBER);
				}

				$sortingCriteria->clearSelectColumns()
									->addSelectColumn('item.*')
									->addAsColumn('label', 'IFNULL((SELECT label FROM library WHERE library.LIBRARY_ID=item.HOME_LIBRARY_ID LIMIT 1),\'\')');

				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
				{
					$sortingCriteria->addAscendingOrderByColumn('label');
				}
				elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
				{
					$sortingCriteria->addDescendingOrderByColumn('label');
				}

				$sortingCriteria->addAscendingOrderByColumn(ItemPeer::INVENTORY_SERIE_ID);
				$sortingCriteria->addAscendingOrderByColumn(ItemPeer::INVENTORY_NUMBER);
				$sortingCriteria->addAscendingOrderByColumn(ItemPeer::LOAN_STATUS);

				break;

			case 'libdistance':
			case 'defaultSorting':
				if ($this->manifestation instanceof Manifestation &&
						$this->manifestation->getBibLevel() == ManifestationPeer::LVL_SERIAL)
				{
					$sortingCriteria->addDescendingOrderByColumn(IssuePeer::ISSUE_YEAR);
					$sortingCriteria->addDescendingOrderByColumn(IssuePeer::ISSUE_VOLUME);
					$sortingCriteria->addDescendingOrderByColumn(IssuePeer::ISSUE_NUMBER);
				}

				if ($this->llibEnabled)
				{
					$sortingCriteria->clearSelectColumns()
										->addSelectColumn('item.*')
										->addAsColumn('distance', 'IFNULL((SELECT distance FROM l_library WHERE FROM_LIBRARY_ID=item.HOME_LIBRARY_ID AND TO_LIBRARY_ID=' . $this->getUser()->getActualLibraryId() . ' LIMIT 1),\'-1\')');

					if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
					{
						$sortingCriteria->addAscendingOrderByColumn('distance');
					}
					elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
					{
						$sortingCriteria->addDescendingOrderByColumn('distance');
					}
				}

				$sortingCriteria->addAscendingOrderByColumn(ItemPeer::HOME_LIBRARY_ID);
				$sortingCriteria->addAscendingOrderByColumn(ItemPeer::INVENTORY_SERIE_ID);
				$sortingCriteria->addAscendingOrderByColumn(ItemPeer::INVENTORY_NUMBER);
				$sortingCriteria->addAscendingOrderByColumn(ItemPeer::LOAN_STATUS);

				break;

			case 'itemId':
				$sortingCriteria->clearOrderByColumns();

				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
				{
					$sortingCriteria->addAscendingOrderByColumn(ItemPeer::ITEM_ID);
				}
				elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
				{
					$sortingCriteria->addDescendingOrderByColumn(ItemPeer::ITEM_ID);
				}

				break;

			case null:
				break;

			default:
				break;
		}
	}

	/**
	 * @return int|mixed|void
	 * @throws \PropelException
	 */
	public function populate()
	{
		if ($this->getDisablePopulate() == true)
			return;

		$items = null;
		$item_request = null;
		$manifestation = null;
		$authority = null;
		$issue = null;
		$actualLibraryId = -1;
		$recCount = 0;
		$checked = null;
		$pageSize = $this->ItemGrid->getPageSize();
		$currentPage = $this->ItemGrid->getCurrentPage();

		/** @var Criteria $criteria */
		$criteria = new Criteria();
		$externalCriteria = $this->getExternalCriteria();

		if ($externalCriteria !== null && ($externalCriteria->size() > 0))
			$criteria = $externalCriteria;

		$actualLibraryId = $this->getUser()->getActualLibraryId();
		$checked = $this->getCheckedItems();
		$this->_masterChecked = $checked['all'];
		$manifestation = $this->getManifestation();
		$authority = $this->getAuthority();
		$this->ManifestationTitleCol->setVisible(!$manifestation instanceof Manifestation);
		$item_request = $this->getItemRequest();

		if ($this->llibEnabled)
		{
			$llibDistances = LLibraryQuery::create()
								->filterByToLibraryId($actualLibraryId)
								->find()->toKeyValue('FromLibraryId', 'Distance');
		}
		else
		{
			$llibDistances = array();
		}

		// column selection based upon the visualization type
		$style = 'default';

		if ($authority instanceof Authority)
		{
			$criteria->addJoin(ItemPeer::ITEM_ID,LAuthorityItemPeer::ITEM_ID, Criteria::INNER_JOIN);
			$criteria->addAnd(LAuthorityItemPeer::AUTHORITY_ID, $authority->getAuthorityId());
		}

		if ($manifestation instanceof Manifestation)
		{
			$criteria->addAnd(ItemPeer::MANIFESTATION_ID, $manifestation->getManifestationId());

			if ($manifestation->getBibLevel() == ManifestationPeer::LVL_SERIAL)
			{
				$criteria->addJoin(ItemPeer::ISSUE_ID, IssuePeer::ISSUE_ID);
				$style = 'issue';
			}
		}

		if (($issue = $this->getIssue()) instanceof Issue)
		{
			$criteria->addAnd(ItemPeer::ISSUE_ID, $issue->getIssueId());
			$criteria->addJoin(ItemPeer::ISSUE_ID, IssuePeer::ISSUE_ID);
			$style = 'issue';
		}

		// invoice case
		if (($invoice = $this->getInvoice()) instanceof Invoice)
		{
			$criteria->addAnd(ItemPeer::INVOICE_ID, $invoice->getInvoiceId());
			$style = 'invoice';

			$currencies = $invoice->getCurrencies();
			$this->drawCurrencies(	$currencies[InvoicePeer::CURRENCY_AMOUNT_VALUE],
									$currencies[InvoicePeer::INVENTORY_AMOUNT_VALUE]);
		}

		// budget case
		if (($budget = $this->getBudget()) instanceof Budget)
		{
			$criteria->addAnd(ItemPeer::BUDGET_ID, $budget->getBudgetId());
			$style = 'budget';

			$currencies = $budget->getCurrencies();
			$this->drawCurrencies(	$currencies[InvoicePeer::CURRENCY_AMOUNT_VALUE],
									$currencies[InvoicePeer::INVENTORY_AMOUNT_VALUE]);
		}

		// order case
		if (($order = $this->getPurchaseOrder()) instanceof PurchaseOrder)
		{
			$criteria->addAnd(ItemPeer::ORDER_ID, $order->getOrderId());
			$style = 'order';

            /** @var $order PurchaseOrder */
			$currencies = $order->getCurrencies();
			$this->drawCurrencies(	$currencies[InvoicePeer::CURRENCY_AMOUNT_VALUE],
									$currencies[InvoicePeer::INVENTORY_AMOUNT_VALUE]);
		}

		$this->setColumnVisibility($style);
		$extraGoHome = false;

		switch ($this->getFilter())
		{
			case 'mine':
				$criteria->add(ItemPeer::HOME_LIBRARY_ID, $actualLibraryId);
				$this->ThisLibrary->setVisible(false);

				break;

			case 'other':
				$criteria->add(ItemPeer::HOME_LIBRARY_ID, $actualLibraryId, Criteria::NOT_EQUAL);
				$this->ThisLibrary->setVisible(true);

				if ($this->llibEnabled)
					$this->LibDistance->setVisible(true);

				break;

			case 'guest':
				$this->ActionsCol->setVisible(false);
				$homeLibraryId = (int)$this->getHomeLibraryId();

				if ($homeLibraryId > 0)
					$criteria->add(ItemPeer::HOME_LIBRARY_ID, $homeLibraryId);

				break;

			case 'extraGoHome':
				$criteria->add(ItemPeer::ACTUAL_LIBRARY_ID, $actualLibraryId);
				$criteria->add(ItemPeer::LOAN_STATUS, ItemPeer::LOANSTATUS_INTRANSITTOEXTRA);

				$viewLibraryId = (int) $this->getViewLibraryId();

				if ($viewLibraryId > 0)
				{
					$criteria->add(ItemPeer::OWNER_LIBRARY_ID, $viewLibraryId);
					$this->ActionsCol->setVisible(false);
				}

				$this->ThisLibrary->setVisible(true);
				$extraGoHome = true;

				break;

			case 'budgetFilter':
				$budgetIdParam = intval($this->getBudgetId());

				if ($budgetIdParam > 0)
					$criteria->add(ItemPeer::BUDGET_ID, $budgetIdParam);

				break;

			case 'none':
			case '':
			default:
				$this->ThisLibrary->setVisible(true);

				if ($this->llibEnabled)
					$this->LibDistance->setVisible(true);

				$this->ActionsCol->setVisible(true);

				break;
		}

		if ($style === 'issue')
		{
			if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallback())
			{
				// populate year dropdown
				$yearcriteria = clone $criteria;
				$yearcriteria->clearSelectColumns()->addSelectColumn(IssuePeer::ISSUE_YEAR);
				$yearcriteria->setDistinct();
				$yearcriteria->addDescendingOrderByColumn(IssuePeer::ISSUE_YEAR);
				$stmt = IssuePeer::doSelectStmt($yearcriteria);
				$volume_ds = array(0	=> '---');

				while ($row = $stmt->fetch(PDO::FETCH_NUM))
					$volume_ds[$row[0]] = $row[0];

				$this->IssueYearFilter->setDataSource($volume_ds);
				$this->IssueYearFilter->dataBind();
			}

			// check filter for issues
			if ($this->IssueStatusFilter->getSelectedIndex() > 0)
				$criteria->add(ItemPeer::ISSUE_STATUS, $this->IssueStatusFilter->getSelectedValue());

			if ($this->IssueYearFilter->getSelectedIndex() > 0)
				$criteria->add(IssuePeer::ISSUE_YEAR, $this->IssueYearFilter->getSelectedValue());
		}

		$givenItemIds = $this->getGivenItemIds();
		$externalRecCount = $this->getExternalRecCount();

		if (count($givenItemIds) > 0)
		{
//			$this->setGlobalCriteria($givenItemIds);
			$recCount = ($externalRecCount > 0) ? $externalRecCount : count($givenItemIds);
			$givenItemIds = array_slice(	$givenItemIds,
											$currentPage * $pageSize,
											$pageSize);

			$items = ItemQuery::create()->findPks($givenItemIds);
			$this->NoFiltersPanel->setVisible(count($items) === 0);
		}
		else	// normal population by a DB query
		{
			$recCount = 0;
			$items = array();

			if ($criteria instanceof Criteria && ($criteria->size() !== 0))
			{
				$sql = $criteria->toString();
				$pos = strpos($sql, 'WHERE');

				if ($pos > 0)
				{
					$where_clause = mb_substr($sql, $pos + mb_strlen('WHERE'));
					$hasItemStatus = (int)mb_stripos($where_clause, ItemPeer::ITEM_STATUS) > 0;
					$hasDateDiscarded = (int)mb_stripos($where_clause, ItemPeer::DATE_DISCARDED) > 0;
				}

				// criteria for items where item_status is discarded, sort of...
				if (!$hasItemStatus && !$hasDateDiscarded)
					$criteria->addAnd(ItemPeer::ITEM_STATUS, ItemPeer::getItemStatusVisible(), Criteria::IN);

				$recCount = $manifestation instanceof Manifestation
								? $manifestation->countItems($criteria)
								: ItemPeer::doCount($criteria);

				if (in_array($style, array('order', 'invoice', 'budget')))
				{
					$this->ItemGrid->resetSorting('itemId', TClavisDataGrid::SORTDIRECTION_DESC, false);
				}
				else
				{
					$this->ItemGrid->resetSorting('defaultSorting', null, false);
				}

				$this->calculateSortingCriteria($criteria);
				$this->setGlobalCriteria(clone $criteria);

				$criteria->setLimit($pageSize);
				$criteria->setOffset($currentPage * $pageSize);
				$this->NoFiltersPanel->setVisible($criteria->size() === 0);

				$items = ($manifestation instanceof Manifestation)
								? $manifestation->getItems($criteria)
								: ItemPeer::doSelect($criteria);
			}
		}

		$this->RecCounter->setText(number_format($recCount, '0',',','.'));
		$sbnEnabled = $this->_sbnMod->getEnabled();
		$this->SBNStatusCol->setVisible($sbnEnabled);
		$data = array();

		/* @var $item Item */
		foreach ($items as $item)
		{
			$manifestation = $item->getManifestation();
			$itemRow = array();
			$itemId = $item->getId();

			$checkedItem = (is_array($checked) && array_key_exists($itemId, $checked))
									? $checked[$itemId]
									: false;

			if ($this->_masterChecked)
				$checkedItem = !$checkedItem;

			$itemRow['Checked'] = $checkedItem;

			$itemRow['Itemicon'] = $item->getItemIcon();
			$itemRow['ItemiconFile'] = $item->getItemiconFile();
			$itemRow['ItemiconLabel'] = $item->getItemiconLabel();

			if ($itemRow['ItemiconLabel'] !== '')
			{
				$addedItemiconStyle = "width: 20px; height: 20px;padding: 4px 0px 6px 0px;";
			}
			else
			{
				$addedItemiconStyle = '';
			}

			$itemRow['AddedItemiconStyle'] = $addedItemiconStyle;
			$itemRow['Id'] = $itemId;
			$itemOrderStatus = $item->getItemOrderStatusString();
			$itemRow['ItemOrderStatus'] = $itemOrderStatus;
			$itemRow['IssueStatus'] = LookupValuePeer::getLookupValue('ISSUESTATUS', $item->getIssueStatus());
			$itemRow['SBNStatus'] = Prado::localize('Modulo SBN non abilitato.');
			$itemRow['SBNStatusImg'] = 'nav_plain_red-16.png';

			if ($sbnEnabled)
			{
				$lst = $item->getLastSbnSync(null);

				if ($lst instanceof DateTime)
				{
					$itemRow['SBNStatus'] = Prado::localize('Esemplare localizzato per possesso.\nData dell\'ultima sincronizzazione: {date}',
																array('date' => $lst->format('Y-m-d H:i:s')));

					$itemRow['SBNStatusImg'] = 'nav_plain_green-16.png';
				}
				else
				{
					$itemRow['SBNStatus'] = Prado::localize('Esemplare non ancora localizzato per possesso.');
					$itemRow['SBNStatusImg'] = 'nav_plain_red-16.png';
				}
			}

			$loanStatus = $item->getLoanStatus();
			$dueDate = $item->getDueDate('U');
			$itemRow['DueDate'] = $dueDate;

			$loanClass = $item->getLoanClassString(null, true);
			$loanStatusString = $item->getLoanStatusString(null, true, true);	// "external" in a new line
			$itemStatus = $item->getItemStatusString();
			$itemRow['LoanStatusString'] = $loanStatusString;
			$itemRow['LoanStatus'] = $loanStatus;
			$itemRow['LoanClassStatusCombo'] = "[<i>$loanClass</i>]<br />$loanStatusString<br />$itemStatus";
			$collocationCombo = $item->getCollocationCombo($actualLibraryId);
			$reprint = trim($item->getReprint());

			if ($reprint)
			{
				$collocationCombo .= '<br /><em>'
										. Prado::localize('(rist. {reprint})',
															array('reprint' => $reprint))
										. '</em>';
			}

			$inventoryNumber = (trim($item->getInventoryNumber())
										? $item->getCompleteInventoryNumber()
										: Prado::localize('barcode') . ': ' . $item->getBarcode());

			$itemRow['Collocation'] = $collocationCombo;
			$itemRow['InventoryNumber'] = $inventoryNumber;
			$itemRow['InvColl'] = $inventoryNumber . ' / ' . $collocationCombo;
			$itemRow['Barcode'] = $item->getBarcode();

			if ($extraGoHome)
			{
				$library = $item->getOwnerLibrary();
				$this->ThisLibrary->setHeaderText(Prado::localize("biblioteca proprietaria"));
			}
			else
			{
				$library = $item->getHomeLibrary();
			}

			if ($library instanceof Library)
			{
				$libraryString = trim($library->getLabel(true, true));

				if (!$libraryString)
					$libraryString = '---';

				$libraryId = (int)$library->getId();
			}
			else
			{
				$libraryString = '<em>' . Prado::localize('biblioteca sconosciuta') . '</em>';
				$libraryId = 0;
			}

			$itemRow['LibraryString'] = $libraryString;
			$itemRow['LibraryId'] = $libraryId;

			if ($this->llibEnabled)
			{
				$libDistance = LLibraryPeer::NULLDISTANCE;

				if (array_key_exists($libraryId, $llibDistances))
					$libDistance = $llibDistances[$libraryId];
			}
			else
			{
				$libDistance = null;
			}

			$itemRow['LibraryDistance'] = $libDistance;

			$loanAlert = $item->getLoanAlert();
			$itemRow['AlertNote'] = (($loanAlert === 'I')
											|| ($loanAlert === 'B'))
										? $item->getLoanAlertNote()
										: '';

			$itemRow['LoanEnabled'] = (($this->getIssue() instanceof Issue ? false : true)
											&& ($this->_loanmanager->IsItemAvailable($item, $actualLibraryId) == ClavisLoanManager::OK));

			$itemRow['ReserveEnabled'] = $this->_requestManager->isItemReservable(	$item,
																					null,
																					$actualLibraryId) == ClavisLoanManager::OK
																						? true
																						: false;

			$itemRow['ActiveLoanEnabled'] = $this->_loanmanager->IsLoanStatusActive($item);
			$exceedDate = ($this->_loanmanager->isLoanLate($item) == ClavisLoanManager::LOAN_ISLATE);

			$itemRow['exceedDate'] = ($exceedDate
										&& $this->_loanmanager->IsLoanStatusActive($item)
										&& (intval($dueDate) > 0));

			$itemRow['isRenewable'] = ($this->_loanmanager->isLoanRenewable(	$item,
																				$this->getUser(),
																				$item->getPatron()) == ClavisLoanManager::OK
																						? true
																						: false);

			$askRenewFlag = $item->isAskRenew($actualLibraryId);
			$itemRow['askRenewFlag'] = $askRenewFlag;

			$itemRow['RequestId'] = ($item_request != null)
										? $item_request->getId()
										: '';

			$itemRow['EditEnabled'] = $this->getUser()->getEditPermission($item);
			$itemRow['InOrder'] = ($item->getItemOrderStatus() == ItemStatus::ITEMSTATUS_INORDER);
			$title = $item->getCompleteTitle();

			if (!$title)
				$title = Prado::localize('(nessun titolo)');

			$itemRow['ManifestationTitle'] = $title;
			$quickId = 0;

			if ($manifestation instanceof Manifestation)
			{
				$ean = trim(TPropertyValue::ensureString($manifestation->getEAN()));

				if ($ean == '')
					$ean = Clavis::IsbnToEan13($manifestation->getIsbnissn());

				$quickId = (int)$manifestation->getQuickId();
			}
			else
			{
				$ean = '';
			}

			$itemRow['EditTitleQuickId'] = $quickId;

			$itemRow['ItemNotes'] = $item->getExtendedItemNoteText(array(	ItemNotePeer::NOTETYPE_INTERNAL,
																			ItemNotePeer::NOTETYPE_SUPPLIER ));

			$itemRow['EAN'] = $ean;

			$itemRow['ItemCurrency'] = $item->getEnsuredCurrency();
			$itemRow['CurrencyValue'] = $item->getCurrencyValue();
			$itemRow['InventoryValue'] = $item->getInventoryValue();

			$itemRow['CurrencyVisible'] = ($item->getItemOrderStatus() != ItemStatus::ITEMSTATUS_ORDERNULL);

			$itemRow['OrderId'] = $item->getOrderId();
			$itemRow['InvoiceId'] = $item->getInvoiceId();

			// issues management
			$issue = $item->getIssue();

			if ($issue instanceof Issue)
			{
				$itemRow['IssueId'] = $issue->getIssueId();
				$itemRow['IssueEditEnabled'] = $this->getUser()->getEditPermission($issue);
				$itemRow['IssueVolume'] = $issue->getIssueVolume();
				$itemRow['IssueDescription'] = $issue->getIssueNumber();

				$itemRow['IssueNumber'] = ($issue->getStartNumber() == $issue->getEndNumber())
												? $issue->getStartNumber()
												: $issue->getStartNumber() . '/' . $issue->getEndNumber();

				switch ($issue->getIssueType())
				{
					case IssuePeer::TYPE_SUPPLEMENT:
						$itemRow['IssueDescription'] .= Prado::localize(' (supp.)');

						break;

					case IssuePeer::TYPE_WITHSUPPLEMENT:
						$itemRow['IssueDescription'] .= Prado::localize(' (con supp.)');

						break;
				}
			}
			else
			{
				$itemRow['IssueId'] = '';
				$itemRow['IssueEditEnabled'] = '';
				$itemRow['IssueVolume'] = '';
				$itemRow['IssueDescription'] = '';
				$itemRow['IssueNumber'] = '';
			}

			$itemRow['IssueArrivalDateExpected'] = $item->getIssueArrivalDateExpected('U');
			$itemRow['IssueArrivalDate'] = $item->getIssueArrivalDate('U');
			$itemRow['IssueStatusCode'] = $item->getIssueStatus();
			$itemRow['IssueStatus'] = LookupValuePeer::getLookupValue('ISSUESTATUS', $item->getIssueStatus());

			switch ($item->getIssueStatus())
			{
				case ItemPeer::ISSUESTATUS_ARRIVED:
				case ItemPeer::ISSUESTATUS_LAST:
					$itemRow['IssueStatusImg'] = 'nav_plain_green-16.png';

					break;

				case ItemPeer::ISSUESTATUS_MISSING:
					$itemRow['IssueStatusImg'] = 'nav_plain_red-16.png';

					break;

				default:
					$itemRow['IssueStatusImg'] = 'nav_plain_yellow-16.png';
			}

			$itemRow['IsHere'] = $item->getActualLibraryId() == $actualLibraryId;

			$budgetEnabled = false;
			$budgetNavigateUrl = "";
			$budgetText = '--';

			if ($this->BudgetColumn->getVisible())
			{
				$budget = $item->getBudget();
				if ($budget instanceof Budget)
				{
					$budgetEnabled = true;
					$budgetNavigateUrl = $this->getService()->constructUrl(BudgetPeer::getViewPage(),
																			array('id' => $budget->getBudgetId()));

					$budgetText = $budget->getCompleteBudgetTitle();
				}
			}

			$itemRow['BudgetEnabled'] = $budgetEnabled;
			$itemRow['BudgetNavigateUrl'] = $budgetNavigateUrl;
			$itemRow['BudgetText'] = $budgetText;

			$data[] = $itemRow;
		}

		$this->ItemGrid->setVirtualItemCount($recCount);
		$this->ItemGrid->setDataSource($data);

		$this->setDatasource($data);
		$this->ItemGrid->dataBind();

		$this->RecCounterPanel->setVisible(count($data) > 0);
		$this->NoResultPanel->setVisible(count($data) == 0);

		return $recCount;
	}

	public function getCounter()
	{
		$count = 0;
		if ($this->RecCounterPanel->getVisible()) {
			$count = filter_var($this->RecCounter->getText(), FILTER_SANITIZE_NUMBER_INT);
		}

		return $count;
	}

	private function drawCurrencies($currencyAmount = 0, $inventoryAmount = 0)
	{
		if ($currencyAmount != 0.0)
		{
			$this->CurrencyAmount->setValue($currencyAmount);
			$this->InventoryAmount->setValue($inventoryAmount);
			$this->CurrencyAmountPanel->setVisible(true);
			$this->InventoryAmountValue->setValue($inventoryAmount);
		}
		else
		{
			$this->CurrencyAmountPanel->setVisible(false);
			$this->InventoryAmountValue->setValue(null);
		}
	}

	public function getInventoryAmountValue()
	{
		return $this->InventoryAmountValue->getValue();
	}

	public function setColumnVisibility($style)
	{
		$this->CheckColumn->setVisible(in_array($style, array('default', 'issue', 'order', 'invoice', 'budget')));
		$this->ManifestationTitleCol->setVisible(!$this->manifestation instanceof Manifestation);
		$this->LoanStatusCol->setVisible(in_array($style, array('default', 'issue')));
		$this->CollocationCol->setVisible($style == 'default');
		$this->InventoryCol->setVisible($style == 'default');
		$this->IssueVolumeCol->setVisible($style == 'issue');
		$this->IssueDescCol->setVisible($style == 'issue');
		$this->IssueNumberCol->setVisible($style == 'issue');
		$this->IssueStatusCol->setVisible($style == 'issue');
		$this->InvCollocationCol->setVisible($style == 'issue');
		$this->IssueArrivalDateExpectedCol->setVisible($style == 'issue');
		$this->IssueArrivalDateCol->setVisible($style == 'issue');
		//$this->CheckCol->setVisible(in_array($style, array('order', 'invoice', 'budget')));
		$this->EANCol->setVisible(in_array($style, array('order', 'invoice', 'budget')));
		$this->ItemOrderStatusCol->setVisible(in_array($style, array('order', 'invoice', 'budget')));
		$this->CurrencyValueCol->setVisible(in_array($style, array('order', 'invoice', 'budget')));
		$this->ItemIdCol->setVisible(in_array($style, array('order', 'invoice', 'budget')));
		//$this->InvoiceActionsCol->setVisible($style == 'invoice' && $this->getShowInvoiceCol());
		$this->BudgetColumn->setVisible(in_array($style, array('order', 'invoice', 'budget')));
	}

	public function filterIssue($sender, $param)
	{
		$this->populate();
	}

	public function globalRefresh()
	{
		$this->resetSorting();
		$this->ItemGrid->resetPagination();

		if ($this->getExternalRecCount() > 0)
		{
			$this->getPage()->onExternalChangePage();
		}
		else
		{
			$this->populate();
		}
	}

	public function resetSorting()
	{
		$this->ItemGrid->resetSorting('', null, false);
	}

	/**
	 * It manages the change of page in the datagrid.
	 * It uses the viewstate to store the current page.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onChangePage($sender, $param)
	{
		$this->ItemGrid->setCurrentPage($param->NewPageIndex);

		if ($this->getExternalRecCount() > 0)
		{
			$this->getPage()->onExternalChangepage();
		}
		else
		{
			$this->populate();
		}
	}

	/**
	 * It returns whether the page permits that in this component
	 * we can have the functions that components inside popups have.
	 *
	 * @return boolean
	 */
	public function getPopupFlag()
	{
		return $this->getPage()->isPopup();
	}

	/**
	 * It returns whether the page permits that in this component
	 * we can have the unlink function.
	 *
	 * @return boolean
	 */
	public function getUnlinkFlag()
	{
		return $this->getPage()->isUnlink();
	}

	/**
	 * It returns whether the page permits that in this component
	 * we can have the delete function.
	 *
	 * @return boolean
	 */
	public function getDeleteFlag()
	{
		return $this->getPage()->isDelete();
	}

	/**
	 * This method, called for unlinking, calls the relative
	 * method of the parent page.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onUnlink($sender, $param)
	{
		$id = $param->CommandParameter;
		$this->getPage()->Unlink($id);
	}

	/**
	 * This method unlinks the current invoice for an item.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onItemInvoiceUnlink($sender, $param)
	{
		$itemId = $param->CommandParameter;
		$item = ItemPeer::retrieveByPK($itemId);

		if ($item instanceof Item)
		{
			try
			{
				$item->setInvoiceId(null);
				$item->save();
				$this->getPage()->writeMessage(Prado::localize('Esemplare slegato da fattura'),
													ClavisMessage::INFO);
			}
			catch (Exception $e)
			{
				$e = $e;
				$this->getPage()->writeMessage(Prado::localize('Impossibile slegare questo esemplare dalla fattura.'),
													ClavisMessage::ERROR);
			}

			$this->getPage()->globalRefresh();
		}
	}

	/**
	 * This method, called for returning from a loan, calls the
	 * relative method of the parent page.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onResetLoan($sender, $param)
	{
		$id = $param->CommandParameter;
		$this->getPage()->resetLoan($id);
	}

	public function onRenewLoan($sender, $param)
	{
		$this->getPage()->cleanMessageQueue();

		$item = null;
		$itemId = intval($param->CommandParameter);

		if ($itemId > 0)
			$item = ItemQuery::create()->findPk($itemId);

		if ($item instanceof Item)
		{
			$oldDueDate = Clavis::dateFormat($item->getDueDate('U'));
			$clavisLibrarian = $this->getUser();
			$destinationObject = $this->_loanmanager->getLoanDestinationObject($item);

			if (!is_null($destinationObject))
			{
				$renewDate = Clavis::dateFormat($this->_loanmanager->CalculateRenewDate($item, $destinationObject));

				if ($this->_loanmanager->DoRenewLoan(	$item,
														$destinationObject,
														$clavisLibrarian,
														Prado::localize('rinnovo standard')))
				{
					$item->reload();

					$this->getPage()->enqueueMessage(Prado::localize("Proroga fino al {date} eseguita correttamente per il prestito sull'esemplare '{title}', inv: {inv}, barcode: {barcode}",
																		array(	'date' => Clavis::dateFormat($item->getDueDate('U')),
																				'title' => $item->getTrimmedTitle(60),
																				'inv' => $item->getCompleteInventoryNumber(),
																				'barcode' => $item->getBarcode())),
														ClavisMessage::INFO);

					if ($item->isExternal()
							&& intval(ClavisParamPeer::getParam('EXTRARENEW_CONFIRMEMAIL')) == 1)
					{
						$library = $item->getOwnerLibraryLabel();
						$loan = $item->getCurrentLoan();

						$notificationManager = $this->getApplication()->getModule('notification');
						$resultAddress = $notificationManager->sendEmailRenew(	'EXTRA_RENEW_CONFIRM',
																				$loan,
																				$oldDueDate,
																				$renewDate);

						if ($resultAddress == self::INVALIDEMAIL)
						{
							$this->getPage()->enqueueMessage(Prado::localize("La biblioteca esterna [{library}] non ha un indirizzo email valido",
																				array('library' => $library)),
																ClavisMessage::WARNING);
						}
						elseif ($resultAddress != '')
						{
							$this->getPage()->enqueueMessage(Prado::localize("É stata spedita una email informativa alla biblioteca '{library}', all'indirizzo '{email}'",
																				array(	'library' => $library,
																						'email' => $resultAddress)),
																ClavisMessage::INFO);
						}
						else
						{
							$this->getPage()->enqueueMessage(Prado::localize("É fallita la richiesta di proroga per l'esemplare '{title}' [inv: {inv}]",
																				array(	'title' => $item->getTrimmedTitle(60),
																						'inv' => $item->getCompleteInventoryNumber())),
																ClavisMessage::ERROR);
						}
					}

					$this->getPage()->globalRefresh();
				}
				else
				{
					$this->getPage()->enqueueMessage(Prado::localize("Proroga fallita sull'esemplare '{title}', inv: {inv}, barcode: {barcode}",
																		array(	'title' => $item->getTrimmedTitle(60),
																				'inv' => $item->getCompleteInventoryNumber(),
																				'barcode' => $item->getBarcode())),
														ClavisMessage::ERROR);
				}
			}
			else
			{
				$this->getPage()->enqueueMessage(Prado::localize("Incongruenza sulla proroga dell'esemplare con id: {id}.<br />Riportare al fornitore del software",
																	array('id' => $item->getItemId())),
													ClavisMessage::ERROR);
			}
		}
		else
		{
			$this->getPage()->enqueueMessage(Prado::localize("Errore dell'applicazione: nel rinnovo extra è stato passato il parametro 'itemId={itemId}' ma l'esemplare non sembra esistere.<br />Riportare al fornitore del software",
																array('itemId' => $itemId)),
												ClavisMessage::ERROR);
		}

		$this->getPage()->flushMessage();
	}

	public function onSuspendRenew($sender, $param)
	{
		$this->getPage()->cleanMessageQueue();

		$clavisLibrarian = $this->getUser();
		$ok = false;

		$item = (object) null;
		$itemId = intval($param->CommandParameter);

		if ($itemId > 0)
			$item = ItemQuery::create()->findPk($itemId);

		if ($item instanceof Item)
		{
			$itemtit = $item->getCompleteTitle();

			if (!$itemtit)
				$itemtit = Prado::localize('(nessun titolo)');

			if ($this->_loanmanager->IsItemLoaned($item))
			{
				switch ($this->_loanmanager->doDisableRenew($itemId, $clavisLibrarian))
				{
					case ClavisLoanManager::OK:
						$this->getPage()->enqueueMessage(Prado::localize("L'esemplare con titolo '{title}' [barcode: {barcode}, inv: {inv}] è stato sospeso dalle proroghe.",
																			array(	'title' => $itemtit,
																					'inv' => $item->getCompleteInventoryNumber(),
																					'barcode' => $item->getBarcode() )),
															ClavisMessage::INFO);

						$ok = true;

						break;

					case ClavisLoanManager::ERROR:
						$this->getPage()->enqueueMessage(Prado::localize("L'operazione di sospensione di proroga è fallita"),
															ClavisMessage::ERROR);

						break;

					default:
						$this->getPage()->enqueueMessage(Prado::localize("Errore sconosciuto durante la sospensione di proroga"),
															ClavisMessage::ERROR);
				}
			}
			else
			{
				$this->getPage()->enqueueMessage(Prado::localize("L'esemplare con id = {id} e barcode = '{barcode}' NON É IN PRESTITO !",
																		array(	'id' => $item->getId(),
																				'barcode' => $item->getBarcode() )),
													ClavisMessage::ERROR);
			}
		}
		else
		{
			$this->getPage()->enqueueMessage(Prado::localize("Errore nel passaggio dei parametri.<br />Riportare al fornitore del software",
																	array(	'id' => $item->getId(),
																			'barcode' => $item->getBarcode() )),
												ClavisMessage::ERROR);
		}

		if ($ok)
			$this->getPage()->globalRefresh();

		$this->getPage()->flushMessage();
	}

	/// probably no more used by anyone. Moved to the NotificationManager (by mbrancalion)
	private function sendEmailRenew(	$templateName = '',
										$loan = null,
										$oldDueDate = null,
										$newRenewDate = null,
										$description = null)
	{
		/* @var $patron Patron */
		/* @var $externalLibrary Library */

		/* @var $myLibrary Library */
		/* @var $loan Loan */

		$templateName = trim($templateName);
		if ($templateName == '')
			return false;

		$success = false;

		$patronData = '---';
		$patron = $loan->getPatron();

		if ($patron instanceof Patron)
			$patronData = $patron->getCompleteName();

		$item = $loan->getItem();

		if (!($item instanceof Item))
			return '';

		$library = $item->getOwnerLibrary();

		if ($library instanceof Library)
		{
			$libraryEmailString = trim($library->getEmail());

			if ($libraryEmailString == '')
				return self::INVALIDEMAIL;

			$libraryEmail = array($libraryEmailString);
		}
		else
		{
			return self::INVALIDEMAIL;
		}

		$libraryString = $item->getOwnerLibraryLabel(false, true, false, false); // strip tags, no addendum

		if (is_null($oldDueDate))
			$oldDueDate = Clavis::dateFormat($loan->getDueDate('U'));

		if (is_null($newRenewDate))
			$newRenewDate = Clavis::dateFormat($this->_loanmanager->CalculateRenewDate($item, $patron));

		$title = $item->getTrimmedTitle(60);
		$inventory = $item->getCompleteInventoryNumber();
		$collocation = $item->getCollocationCombo();

		$myLibrary = $this->getUser()->getActualLibrary();
		$myLibraryId = $this->getUser()->getActualLibraryId();
		$myConsortiumString = $myLibrary->getConsortiaString();

		$notificationManager = $this->getApplication()->getModule('notification');

		if ($description != '')
			$description = Prado::localize("con la seguente motivazione") . ":\n" . $description . "\n";

		$class = get_class($library);
		$receiverId = $library->getLibraryId();

		$template = DocumentTemplatePeer::getTemplate(	$templateName,
														$this->getApplication()->getGlobalization()->getCulture(),
														$myLibraryId);

		if (!$template instanceof DocumentTemplate)
			return false;

		$arr_alias = array(	'EXTERNALLIBRARY' => $libraryString,
							'TITLE' => $title,
							'INVENTORY' => $inventory,
							'COLLOCATION' => $collocation,
							'PATRON' => $patronData,
							'OLDRENEW' => $oldDueDate,
							'NEWRENEW' => $newRenewDate,
							'MOTIVATION' => $description,
							'LIBRARY' => $myLibrary->getLabel(),
							'LIBRARY_CODE' => $myLibrary->getLibraryCode(),
							'LIBRARY_DESCRIPTION' => $myLibrary->getDescription(),
							'LIBRARY_CITY' => $myLibrary->getCity(),
							'LIBRARY_ADDRESS' => $myLibrary->getAddress(),
							'LIBRARY_PHONE' => $myLibrary->getPhone(),
							'LIBRARY_FAX' => $myLibrary->getFax(),
							'LIBRARY_EMAIL' => $myLibrary->getEmail() );

		$mailData = array();
		$mailData['to'] = $libraryEmail;
		$mailData['bcc'] = array();
		$mailData['cc'] = array();
		$mailData['body'] = '';
		$mailData['subject'] = "[$myConsortiumString]: " . $template->getTemplateTitle();

		$mailData['from'] = array(	'name' => $myLibrary->getLabel(),
									'email' => $myLibrary->getEmail() );

		$notificationData = array(	'sender_library_id' => $myLibraryId,
									'receiver_class' => $class,
									'receiver_id' => $receiverId,
									'description' => Prado::localize("Richiesta proroga a biblioteca esterna"),
									'notes' => array() );

		try
		{
			$ret = $notificationManager->DoEmailReport(	$template->getTemplateBody(),
														$arr_alias,
														$mailData,
														NotificationManager::EMAIL_AUTO,
														$notificationData);

			if ($ret === true)
				$success = implode(',', $libraryEmail);
		}
		catch (Exception $e)
		{
			$e = $e;
			//throw ($e);
			$success = false;
		}

		return $success;
	}

	public function onAskRenewItem($sender, $param)
	{
		$itemId = $param->CommandParameter;
		$item = null;

		if ($itemId > 0)
			$item = ItemQuery::create()->findPk($itemId);

		if ($item instanceof Item)
		{
			$loan = $item->getCurrentLoan();

			if (!($loan instanceof Loan))
			{
				$message = array(Prado::localize("Incongruenza sul database durante la richiesta di proroga, relativamente al current_loan_id dell'esemplare con id = {itemId}.<br />Riportare al fornitore del software",
														array('itemId' => $itemId)),
									ClavisMessage::ERROR);

				return false;
			}

			$patron = $loan->getPatron();
			$library = $item->getOwnerLibraryLabel();

			$oldDueDate = Clavis::dateFormat($loan->getDueDate('U'));
			$newRenewDate = Clavis::dateFormat($this->_loanmanager->CalculateRenewDate($item, $patron));

			$notificationManager = $this->getApplication()->getModule('notification');
			$resultAddress = $notificationManager->sendEmailRenew('EXTRA_RENEW_ASK', $loan, $oldDueDate, $newRenewDate);

			if ($resultAddress == self::INVALIDEMAIL)
			{
				$message = array(Prado::localize("La biblioteca richiedente [{library}] non ha un indirizzo email valido",
													array('library' => $library)),
									ClavisMessage::ERROR);
			}

			elseif ($resultAddress != '')
			{
				$message = array(Prado::localize("É stata correttamente richiesta la proroga dell'esemplare '{title}' [inv: {inv}, coll: {coll}] alla biblioteca '{library}', all'indirizzo '{email}'",
														array(	'date' => $newRenewDate,
																'title' => $item->getTrimmedTitle(60),
																'inv' => $item->getCompleteInventoryNumber(),
																'coll' => $item->getCollocationCombo(),
																'library' => $library,
																'email' => $resultAddress )),
									ClavisMessage::INFO);

				$this->getPage()->globalRefresh();
			}
			else
			{
				$message = array(Prado::localize("É fallita la richiesta di proroga per l'esemplare '{title}' [inv: {inv}]",
														array(	'title' => $item->getTrimmedTitle(60),
																'inv' => $item->getCompleteInventoryNumber() )),
									ClavisMessage::ERROR);
			}

			$this->getPage()->writeMessage($message[0], $message[1]);
		}
		else
		{
			$this->getPage()->writeMessage(Prado::localize("Errore nel passaggio dei parametri durante la richiesta di proroga.<br />Riportare al fornitore del software"),
												ClavisMessage::ERROR);
		}
	}

	public function resetPagination()
	{
		$this->ItemGrid->resetPagination();
	}

	public function getPageSize()
	{
		return $this->ItemGrid->getPageSize();
	}

	public function setPageSize($size)
	{
		$this->ItemGrid->setPageSize($size);
	}

	public function getCurrentPage()
	{
		return $this->ItemGrid->getCurrentPage();
	}

	public function setCurrentPage($page)
	{
		$this->ItemGrid->setCurrentPage($page);
	}

	public function setArrived($sender, $param)
	{
		$index = $sender->Parent->Parent->ItemIndex;
		$dataSource = $this->getDatasource();
		$row = $dataSource[$index];
		$item = ItemQuery::create()->findPk($row['Id']);

		if ($item instanceof Item)
		{
			$item->setIssueStatus(ItemPeer::ISSUESTATUS_ARRIVED);
			$item->setItemStatus(ItemStatus::ITEMSTATUS_ONSHELF);
			$item->setIssueArrivalDate(time());
			$item->save();
			$item->reload();
		}

		$this->getPage()->globalRefresh();
	}

	public function onGoHome($sender, $param)
	{
		$this->getPage()->cleanMessageQueue();

		$itemId = $param->CommandParameter;
		$item = null;

		if ($itemId > 0)
			$item = ItemQuery::create()->findPk($itemId);

		if ($item instanceof Item)
		{
			$clavisLibrarian = $this->getUser();

			switch ($this->_loanmanager->doExtraGoHome($item, $clavisLibrarian))
			{
				case ClavisLoanManager::OK:

					$ownerLibrary = $item->getOwnerLibrary();
					if ($ownerLibrary instanceof Library)
					{
						$consortiaString = $ownerLibrary->getConsortiaString(30);
					}
					else
					{
						$consortiaString = $value = '---';
					}

					$this->getPage()->enqueueMessage(Prado::localize("L'esemplare '{title}', record id: {id}, è ritornato al suo sistema '{alienConsortia}'",
																		array(	'title' => $item->getTrimmedTitle(30),
																				'id' => $item->getItemId(),
																				'alienConsortia' => $consortiaString )),
														ClavisMessage::CONFIRM);

					if (method_exists($this->getPage(), 'globalRefreshIn'))
					{
						$this->getPage()->globalRefreshIn();
					}
					elseif (method_exists($this->getPage(), 'globalRefresh'))
					{
						$this->getPage()->enqueueMessage(Prado::localize("Attenzione, l'esemplare esterno con id={id} probabilmente è stato collegato ad una notizia",
																					array('id' => $itemId)),
																ClavisMessage::WARNING);

						$this->getPage()->globalRefresh();
					}

					break;

				case ClavisLoanManager::ERROR:
				default:
					$this->getPage()->enqueueMessage(Prado::localize("Errore sul rientro di un esemplare extra-sistema al suo consorzio.<br />Riportare al fornitore del software"),
														ClavisMessage::ERROR);
			}
		}

		$this->getPage()->flushMessage();
	}

	public function getSortingExpression()
	{
		return $this->ItemGrid->getSortingExpression();
	}

	public function getSortingDirection()
	{
		return $this->ItemGrid->getSortingDirection();
	}

}
