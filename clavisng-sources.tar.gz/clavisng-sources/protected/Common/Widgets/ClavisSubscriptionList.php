<?php

/**
 * ClavisSubscriptionList
 *
 * @author Max Pigozzi <mpigozzi@e-portaltech.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @copyright Copyright &copy; 2011 Comperio srl
 * @version 2.7
 * @package Widgets
 * @since 2.0
 */

class ClavisSubscriptionList extends TTemplateControl {

	/** @var Manifestation */
	protected $_manifestation;
	protected $_library;

	public function onLoad($param)
	{
		parent::onLoad($param);

		if ((!$this->getPage()->getIsPostBack()) and (!$this->getPage()->getIsCallBack())) {

			$this->LibraryFilter->setDataSource(LibraryPeer::getLibrariesHashWithBlank());
			$this->LibraryFilter->dataBind();
			$this->SubscriptionGrid->resetPagination();
			$this->populate();
		}
		$yearLabels = array('0'=>'---');
		for ($i=date('Y'); $i>1969; --$i)
			$yearLabels[$i] = $i;
		
		$this->VolumeFilter->setDataSource($yearLabels);
		$this->VolumeFilter->dataBind();
	}

	//GETTER/SETTER

	/**
	 * Setter method of object manifestation.
	 *
	 * @param Manifestation $manifestation
	 */
	public function setManifestation($manifestation)
	{
		$this->_manifestation = $manifestation;
		$this->setControlState("manifestation", $manifestation, null);
	}

	/**
	 * Getter method of object manifestation.
	 *
	 * @return Manifestation
	 *
	 */
	public function getManifestation()
	{
		$this->_manifestation = $this->getControlState("manifestation", null);
		return $this->_manifestation;
	}

	/**
	 * Setter method of object library.
	 *
	 * @param Library $library
	 */
	public function setLibrary($library)
	{
		$this->_library = $library;
		$this->setControlState("library", $library, null);
	}

	/**
	 * Getter method of object library.
	 *
	 * @return Library
	 *
	 */
	public function getLibrary()
	{
		$this->_library = $this->getControlState("library", null);
		return $this->_library;
	}



	public function populate()
	{
		$this->populateSubscriptionGrid();
	}

	private function populateSubscriptionGrid()
	{
		$clavisLibrarian = $this->getUser();

		$pageSize = $this->SubscriptionGrid->getPageSize();
		$currentIndexPage = $this->SubscriptionGrid->getCurrentPage();

		$this->getManifestation();

		$this->getLibrary();


		//$this->setViewState("OldPageSize", $pageSize);
		//$currentIndexPage = $this->getViewState("CurrentPage", 0);
		$titleFilter = '';
		$libraryFilterId = 0;

		$criteria = new Criteria();

		if (!is_null($this->_manifestation)) {
			$criteria->add(SubscriptionPeer::MANIFESTATION_ID, $this->_manifestation->getManifestationId());
			$this->titleFilterPanel->setVisible(false);
			$this->TitleCol->setVisible(true);
		} else {
			$this->TitleCol->setVisible(true);
			$titleFilter = $this->TitleFilter->getSafeText();
		}

		if (!is_null($this->_library)) {
			$criteria->add(SubscriptionPeer::LIBRARY_ID, $this->_library->getLibraryId());
			$this->libraryFilterPanel->setVisible(false);
		} else {
			$this->LibraryCol->setVisible(true);
			$libraryFilterId = $this->LibraryFilter->getSelectedValue();
		}

		if ($titleFilter != '') {
			$criteria->addJoin(ManifestationPeer::MANIFESTATION_ID, SubscriptionPeer::MANIFESTATION_ID);
			$criteria->add(ManifestationPeer::TITLE, "%".$titleFilter."%", Criteria::LIKE);
		}

		if ($libraryFilterId != 0) {
			$criteria->add(SubscriptionPeer::LIBRARY_ID, $libraryFilterId);
		}

		$volumeFilter = $this->VolumeFilter->getSelectedValue();
		if($volumeFilter != 0) {
			$criteria->add(SubscriptionPeer::VOLUME, $volumeFilter);
		}

		$startFilter = $this->StartFilter->getTimestamp();
		if (!is_null($startFilter))
	    	$criteria->add(SubscriptionPeer::START_DATE, $startFilter, Criteria::GREATER_EQUAL);

		$endFilter = $this->EndFilter->getTimestamp();
		if (!is_null($endFilter))
	    	$criteria->add(SubscriptionPeer::END_DATE, $endFilter + 86399, Criteria::LESS_EQUAL);


		$recCount = SubscriptionPeer::doCount($criteria);

		$criteria->addDescendingOrderByColumn(SubscriptionPeer::VOLUME);

		$this->SubscriptionGrid->setVirtualItemCount($recCount);
		//$this->setIssueCount($recCount);
		///$this->InvoiceGrid->setCounterText($recCount);

		$this->RecCounter->Text = "Record totali: $recCount";

        $criteria->setLimit($pageSize);
		$criteria->setOffset($currentIndexPage * $pageSize);

		/*
		if (is_null($this->_manifestation))
			$criteria->addAscendingOrderByColumn(IssuePeer::MANIFESTATION_ID);

		$criteria->addDescendingOrderByColumn(IssuePeer::ISSUE_YEAR);
		$criteria->addDescendingOrderByColumn(IssuePeer::END_NUMBER);
		$criteria->addDescendingOrderByColumn(IssuePeer::START_NUMBER);
		*/
        $subscriptions = SubscriptionPeer::doSelect($criteria);

        $data = array();

		/* @var $subscription Subscription */
		foreach ($subscriptions as $subscription)
		{
			$p = array();

			$p['ManifestationId'] = '';
			$p['ManifestationTitle'] = '';
			$p['ManifestationURL'] = '';
			//if (is_null($this->_manifestation)) {
				$manifestationId = $subscription->getManifestationId();
				$p['ManifestationId'] = $manifestationId;
				$manifestation = ManifestationPeer::retrieveByPK($manifestationId);
				if (!is_null($manifestation)) {
					$p['ManifestationTitle'] = $manifestation->getTitle();
					$p['ManifestationURL'] = "index.php?page=Catalog.Record&manifestationId=".$manifestationId;
				}
			//}

			$p['LibraryId'] = '';
			$p['Library'] = '';
			$p['LibraryURL'] = '';
			if (is_null($this->_library)) {
				$libraryId = $subscription->getLibraryId();
				$p['LibraryId'] = $libraryId ;
				$library = LibraryPeer::retrieveByPK($libraryId);
				if (!is_null($library)) {
					$p['Library'] = $library->getLabel();
					$p['LibraryURL'] = "index.php?page=Library.LibraryViewPage&id=".$libraryId;
				}
			}

			$supplierId = $subscription->getSupplierId();
			$p['SupplierId'] = $supplierId;
			$p['Supplier'] = '';
			$p['SupplierURL'] = '';
			$supplier = SupplierPeer::retrieveByPK($supplierId);
			if (!is_null($supplier)) {
				$p['Supplier'] = $supplier->getSupplierName();
				$p['SupplierURL'] = "index.php?page=Acquisition.SupplierPage&supplierId=".$supplierId;
			}

			$budgetId = $subscription->getBudgetId();
			$p['BudgetId'] = $budgetId;
			$p['Budget'] = '';
			$p['BudgetURL'] = '';
			$budget = BudgetPeer::retrieveByPK($budgetId);
			if (!is_null($budget)) {
				$p['Budget'] = $budget->getBudgetTitle();
				$p['BudgetURL'] = "index.php?page=Acquisition.BudgetInsertPage&id=".$budgetId;;
			}

			$p['Year'] = $subscription->getYear();
			$p['Volume'] = $subscription->getVolume();
			$p['Frequence'] = LookupValuePeer::getLookupValue('SUBSCRIPTIONFREQUENCE', $subscription->getFrequence());
			$p['Tolerance'] = $subscription->getTolerance();
			$p['Status'] = LookupValuePeer::getLookupValue('SUBSCRIPTIONSTATUS', $subscription->getSubscriptionStatus());
			$p['Type'] = LookupValuePeer::getLookupValue('SUBSCRIPTIONTYPE', $subscription->getSubscriptionType());
			$p['StartDate'] = $subscription->getStartDate();
			$p['EndDate'] = $subscription->getEndDate();
			$p['Management'] = LookupValuePeer::getLookupValue('SUBSCRIPTIONMANAGEMENT', $subscription->getManagement());

			$p['SubscriptionCombo'] = $subscription->getSubscriptionCombo();

			$p['CanEdit'] = $clavisLibrarian->getEditPermission($subscription);

			$p['Id'] = $subscription->getSubscriptionId();

			$data[] = $p;
		}

		$this->SubscriptionGrid->setDataSource($data);
		$this->SubscriptionGrid->dataBind();
	}

	public function searchSubscription($sender, $param) {
		$this->SubscriptionGrid->CurrentPageIndex = 0;
		$this->setViewState("CurrentPage", 0);
		$this->populate();

		$this->getPage()->globalRefresh();
	}

	public function onCancel()
	{
		$this->searchCancel(null, null);
	}

	public function searchCancel($sender, $param)
	{
		$this->TitleFilter->setText('');;
		$this->StartFilter->setText('');
		$this->EndFilter->setText('');

		$this->searchSubscription(null, null);
	}

	public function changePage($sender,$param) {
		$this->setViewState("CurrentPage",$param->NewPageIndex);

		$this->SubscriptionGrid->setCurrentPage($param->NewPageIndex);
		$this->populate();
	}

	public function getPopupFlag()
	{
		return $this->getPage()->IsPopup();
	}

	public function getUnlinkFlag()
	{
		return $this->getPage()->IsUnlink();
	}


}
