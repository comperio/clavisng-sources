<?php
/**
 * ClavisAuthorityLinkedData file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.8.6
 * @package Widgets
 */

/**
 * ClavisAuthorityLinkedData Class
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.8.6
 * @package Widgets
 * @since 2.8.6
 */
class ClavisAuthorityLinkedData extends TTemplateControl
{
	/* @var Authority */
	public $authority;

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!isset($this->authority) 
				|| is_null($this->authority))
			$this->authority = $this->getAuthority();
		
		// first page cycle
		if (!$this->getPage()->getIsPostBack()
				&& !$this->getPage()->getIsCallback())
		{
			$this->populate();
		}
	}

	public function getAuthority()
	{
		return $this->getControlState('authority', null);
	}

	public function setAuthority(Authority $value)
	{
		$this->authority = $value;
		$this->setControlState('authority', $this->authority);
	}

	public function setLinkedData($ld)
    {
        $this->setControlState('linkedata',$ld);
    }
    public function getLinkedData()
    {
        return $this->getControlState('linkedata',null);
    }

	public function populate()
	{
		if (!($this->authority instanceof Authority))
			return;

		$linkedData = $this->readLinkedData();

		if (count($linkedData) > 0)
		{	
			///$this->GridPanel->setVisible(true);
			$this->GridPanel->setStyle("margin-top: 1em; display: inline");
			$this->LinkedDataGrid->setDataSource($linkedData);
			$this->LinkedDataGrid->dataBind();
		}
		else
		{
			///$this->GridPanel->setVisible(false);
			$this->GridPanel->setStyle("margin-top: 1em; display: none");
		}
		
		if ($this->getPage()->getIsCallback())
		{
			$writer1 = $this->getPage()->getResponse()->getAdapter()->createNewHtmlWriter('THtmlWriter', $this->getPage()->getResponse());
			$this->GridPanel->render($writer1);
		}

		if (!$this->getReadOnly())
		{	
			$existingDatasets = array();

			foreach ($linkedData as $ld)
				$existingDatasets[] = $ld['LinkedDataDataset'];

			$dataSets = LookupValuePeer::getLookupClassValues(	'AUTHORITYLINKEDDATA', 
																true,	// with blank
																null,
																null,
																true,	// sorted

																null,
																$existingDatasets,			// excluded values
																true);						// force to not use cache

			$this->DatasetList->setDataSource($dataSets);
			$this->DatasetList->dataBind();

			if (count($dataSets) > 0)
			{
				$this->AddLinkedDataButton->setEnabled(true);
				$this->AddLinkedDataButton->setToolTip(Prado::localize("salva i valori come linked data nell'authority"));
			}
			else
			{
				$this->AddLinkedDataButton->setEnabled(false);
				$this->AddLinkedDataButton->setToolTip(Prado::localize("tutti i tipi di linked data sono già stati inseriti"));
			}

			if ($this->getPage()->getIsCallback())
			{
				$writer2 = $this->getPage()->getResponse()->getAdapter()->createNewHtmlWriter('THtmlWriter', $this->getPage()->getResponse());
				$this->NewLinkedDataPanel->render($writer2);
			}
		}
	}
	
	private function readLinkedData()
	{
		$ldArray = $this->getLinkedData();

        if(is_array($ldArray))  return $ldArray;
		else $ldArray = [];
		
		if ($this->authority instanceof Authority)
		{
			$tm = $this->authority->getTurboMarc();

			if ($tm instanceof TurboMarc)
			{
				if (!empty($tm->d859))
				{
					$dataKey = 0;
					
					foreach ($tm->d859 as $field)
					{
						$dataset = (string) $field->sa;
						$datasetCombo = $dataset;
						$name = (string) $field->sl;
						$url = (string) $field->su;

						if ($name != '')
							$datasetCombo .= "&nbsp($name)";

						$ldArray[] = array(	'LinkedDataDataset' => $dataset,
											'LinkedDataDatasetCombo' => $datasetCombo,
											'LinkedDataName' => $name,
											'LinkedDataUrl' => $url,
											'DataKey' => $dataKey++ );
					}
				}
			}
		}
        $this->setLinkedData($ldArray);
		return $ldArray;
	}

	public function setReadOnly($value)
	{
		return $this->setControlState('ReadOnly', TPropertyValue::ensureBoolean($value), false);
	}

	public function getReadOnly()
	{
		return $this->getControlState('ReadOnly', false);
	}

	public function updateTurboMarc($tm)
    {
        $ldArray = $this->getLinkedData();
        if(is_array($ldArray))
            foreach ($ldArray as $ld) {
                $f859 = $tm->addField("859");
                $f859->addSubField("a", $ld['LinkedDataDataset']);
                $f859->addSubField("l", $ld['LinkedDataName']);
                $f859->addSubField("u", $ld['LinkedDataUrl']);
            }
    }

	public function onNewLinkedData($sender, $param)
	{
		$dataset = $this->DatasetList->getSelectedValue();
		
		if ($dataset != "0")	// if we have chosen a valid dataset value
		{
			$datasetText = trim($this->DatasetText->getSafeText());
			$urlText = trim($this->UrlText->getSafeText());
			
			if ($urlText == '')
			{
				$this->getPage()->writeMessage(Prado::localize("L'url di un linked data non può essere vuoto"), 
												ClavisMessage::WARNING);
				
				return false;
			}
			
			if ($this->writeLinkedData(	$dataset,
										$datasetText,
										$urlText))
			{
				$this->getPage()->writeMessage(Prado::localize("Nuovo linked data inserito: {ds} -> {url}",
																	array(	'ds' => $dataset . ($datasetText == '' ? '' : '&nbsp;(' . $datasetText . ')'),
																			'url' => $urlText )), 
												ClavisMessage::CONFIRM);
				
				ChangelogPeer::logAction(	$this->authority, 
											ChangelogPeer::LOG_UPDATE, 
											$this->getUser(), 
											'Inserita nuovo linked data: ' . $dataset . ($datasetText == '' ? '' : '&nbsp;(' . $datasetText . ')')
												. ' -> ' . $urlText,
											$this->authority->getAuthorityId());
								
				$this->DatasetList->setSelectedIndex(-1);
				$this->DatasetText->setText('');
				$this->UrlText->setText('');
				
				$this->populate();
			}
			else
			{
				$this->getPage()->writeMessage(Prado::localize("Errore al salvataggio del linked data"), 
												ClavisMessage::ERROR);
				
				return false;
			}
		}
	}
	
	private function writeLinkedData(	$dataset,
										$datasetText,
										$urlText)
	{

		$ldArray = $this->getLinkedData();

		$dataKey = count($ldArray);

        $ldArray[] = array(
            'LinkedDataDataset' => $dataset,
            'LinkedDataDatasetCombo' => $dataset,
            'LinkedDataName' => $datasetText,
            'LinkedDataUrl' => $urlText,
            'DataKey' => $dataKey );

        $this->setLinkedData($ldArray);
        return true;
	}
	
	public function onDeleteLinkedData($sender, $param)
	{
		try
		{
			$dataKey = $param->getCommandParameter();

			$ld = $this->getLinkedData();

            $datasetCombo = $ld[$dataKey]['LinkedDataDatasetCombo'];
            $url = $ld[$dataKey]['LinkedDataDataUrl'];
			unset($ld[$dataKey]);

			$this->setLinkedData($ld);

			$this->getPage()->writeMessage(Prado::localize("Cancellato linked data: {dsc} -> {url}",
																array(	
																		'dsc' => $datasetCombo . "[$dataKey]",
																		'url' => $url )), 
											ClavisMessage::CONFIRM);

			ChangelogPeer::logAction(	$this->authority, 
										ChangelogPeer::LOG_UPDATE, 
										$this->getUser(), 
										'Cancellato linked data: ' . $datasetCombo . ' -> ' . $url,
										$this->authority->getAuthorityId());
			
			$this->populate();
		}
		catch (Exception $e)
		{
			// Prado::log($e);
		}
	}

}