<?php
/**
 * ClavisItemSectionList class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Widgets
 */

/**
 * ClavisItemSectionList Class
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Widgets
 * @since 2.3
 */
class ClavisItemSectionList extends TTemplateControl
{

	public function onInit($param)
	{
		parent::onInit($param);
		$this->attachEventHandler('OnActualLibraryChanged', array($this, 'OnActualLibraryChanged'));
	}

	public function onLoad($param)
	{
		parent::onLoad($param);
		
		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallBack())
		{
			$this->populate();
		}
	}

	public function OnActualLibraryChanged($sender, $param)
	{
		$this->populate();
	}

	/**
	 * Cleans the search textboxes and re-populates.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onClearSearch()
	{
		$this->searchCancel(null, null);
	}

	public function populate()
	{
		$this->populateItemSectionGrid();
	}

	private function populateItemSectionGrid()
	{
		$pageSize = $this->ItemSectionGrid->getPageSize();
		$currentIndexPage = $this->ItemSectionGrid->getCurrentPage();
		$q = LibraryValueQuery::create()
				->filterByValueClass('ITEMSECTION')
				->filterByValueLibraryId($this->getUser()->getActualLibraryId())
				->orderByValueKey();
		$recCount = $q->count();
		$this->ItemSectionGrid->setVirtualItemCount($recCount);
		$this->RecCounter->setText("Record totali: $recCount");
		$q->limit($pageSize)->offset($currentIndexPage * $pageSize);
		$sects = $q->find();
		$this->ItemSectionGrid->setDataSource($sects);
		$this->ItemSectionGrid->dataBind();
	}

	public function onCancel()
	{
		$this->searchCancel(null, null);
	}

	public function changePage($sender, $param)
	{
		$this->ItemSectionGrid->SelectedItemIndex = -1;
		$this->ItemSectionGrid->EditItemIndex = -1;
		$this->ItemSectionGrid->setCurrentPage($param->NewPageIndex);
		$this->getPage()->globalRefresh();
	}

	public function getPopupFlag()
	{
		return $this->getPage()->IsPopup();
	}

	public function getUnlinkFlag()
	{
		return $this->getPage()->IsUnlink();
	}

	public function globalRefresh()
	{
		$this->populate();
	}

	protected function updateSection($key, $newkey, $newlabel)
	{
		$newkey = trim($newkey);
		$section = LibraryValuePeer::retrieveByPK($key, 'ITEMSECTION', $this->getUser()->getActualLibraryId());
		if ($section !== null)
		{
			if ($key != $newkey)
			{
				/* check for duplicates */
				$dupsec = LibraryValuePeer::retrieveByPK($newkey, 'ITEMSECTION', $this->getUser()->getActualLibraryId());
				LibraryValuePeer::getLibraryValue('ITEMSECTION', $newkey, $this->getUser()->getActualLibraryId());
				if ($dupsec !== null && $dupsec->getValueKey() == $newkey)
				{
					$this->getPage()->writeMessage(Prado::localize('La chiave specificata è già assegnata ad un\'altra sezione.'), ClavisMessage::ERROR);
				}
				else
				{
					$conn = Propel::getConnection();
					try
					{
						$conn->beginTransaction();
						$updatedItems = 0;
						$items = ItemQuery::create()
								->filterBySection($key)
								->filterByHomeLibraryId($this->getUser()->getActualLibraryId())
								->setFormatter(ModelCriteria::FORMAT_ON_DEMAND)
								->find();
						foreach ($items as $i)
						{
							$i->setSection($newkey);
							if ($i->save())
								++$updatedItems;
							$i->clearAllReferences(true);
						}
						$section->updateKey($newkey);
						$section = LibraryValuePeer::retrieveByPK($newkey, 'ITEMSECTION', $this->getUser()->getActualLibraryId());
						$conn->commit();
						
						ChangelogPeer::logAction(	$section, 
													ChangelogPeer::LOG_UPDATE, 
													$this->getUser(), 
													"Aggiornata sezione [{$section->getValueKey()} - {$section->getValueLabel()}] della biblioteca "
														. $section->getValueLibraryId() . "; aggiornati {$updatedItems} esemplari.");
						
						$this->getPage()->writeMessage(Prado::localize('Aggiornata sezione [{srccode} - '
																			. '{srclabel}]; sono stati aggiornati {items} esemplari.', 
																		array(	'srccode' => $section->getValueKey(),
																				'srclabel' => $section->getValueLabel(),
																				'items' => $updatedItems )), 
															ClavisMessage::INFO);
					}
					catch (Exception $e)
					{
						$conn->rollBack();
					}
				}
			}
			$section->setValueLabel($newlabel);
			$section->save();
		}
		else
		{
			$this->getPage()->writeMessage(Prado::localize('Si è verificato un errore interno.
					Si prega di contattare il fornitore del software per comunicare l\'accaduto.'), ClavisMessage::ERROR);
			Prado::log("ItemSection not found / key [{$key}], newkey [{$newkey}], newlabel [{$newlabel}].");
		}
	}

	public function deleteSection($sender, $param)
	{
		$src = $this->SrcSection->getValue();
		$items = ItemQuery::create()
				->filterBySection($src)
				->filterByHomeLibraryId($this->getUser()->getActualLibraryId())
				->find();
		foreach ($items as $i)
		{
			$i->setSection(null);
			$i->save();
		}
		$sect = LibraryValuePeer::retrieveByPK($src, 'ITEMSECTION', $this->getUser()->getActualLibraryId());
		ChangelogPeer::logAction($sect, ChangelogPeer::LOG_DELETE, $this->getUser(), 'Eliminata sezione [' .
				$sect->getValueKey() . ' - ' . $sect->getValueLabel() . '] della biblioteca ' .
				$sect->getValueLibraryId() . '; aggiornati ' . count($items) . ' esemplari.');
		$sect->delete();
		$this->getPage()->writeMessage(Prado::localize('Eliminata sezione [{srccode} - ' .
						'{srclabel}]; sono stati aggiornati {items} esemplari.', array(
					'srccode'	 => $sect->getValueKey(),
					'srclabel'	 => $sect->getValueLabel(),
					'items'		 => count($items))), ClavisMessage::INFO);
		$this->ShrinkSectionPanel->setVisible(false);
		$this->ItemSectionGrid->SelectedItemIndex = -1;
		$this->ItemSectionGrid->EditItemIndex = -1;
		$this->populate();
	}

	public function shrinkSection($sender, $param)
	{
		$src = $this->SrcSection->getValue();
		$dst = $this->DstSection->getSelectedValue();
		$items = ItemQuery::create()
				->filterBySection($src)
				->filterByHomeLibraryId($this->getUser()->getActualLibraryId())
				->find();
		foreach ($items as $i)
		{
			$i->setSection($dst);
			$i->save();
		}
		$sect = LibraryValuePeer::retrieveByPK($src, 'ITEMSECTION', $this->getUser()->getActualLibraryId());
		ChangelogPeer::logAction($sect, ChangelogPeer::LOG_DELETE, $this->getUser(), 'Sezione [' .
				$sect->getValueKey() . ' - ' . $sect->getValueLabel() . '] della biblioteca ' .
				$sect->getValueLibraryId() . ' schiacciata su sezione [' . $dst .
				']; aggiornati ' . count($items) . ' esemplari.');
		$sect->delete();
		$this->getPage()->writeMessage(Prado::localize('Sezione [{srccode} - ' .
						'{srclabel}] schiacciata su [{dstcode}]; ' .
						'sono stati aggiornati {items} esemplari.', array(
					'srccode'	 => $sect->getValueKey(),
					'srclabel'	 => $sect->getValueLabel(),
					'dstcode'	 => $dst,
					'items'		 => count($items))), ClavisMessage::INFO);
		$this->ShrinkSectionPanel->setVisible(false);
		$this->ItemSectionGrid->SelectedItemIndex = -1;
		$this->ItemSectionGrid->EditItemIndex = -1;
		$this->populate();
	}

	public function itemCreated($sender, $param)
	{
		$item = $param->Item;
		if ($item->ItemType === 'EditItem')
		{
			
		}
		if ($item->ItemType === 'Item' || $item->ItemType === 'AlternatingItem' || $item->ItemType === 'EditItem')
		{
			// add an aleart dialog to delete buttons
			/* $item->DeleteColumn->Button->Attributes->onclick='if(!confirm(\''.
			  Prado::localize('Sei sicuro di voler eliminare questa sezione?').'\')) return false;'; */
		}
	}

	public function editItem($sender, $param)
	{
		$this->ItemSectionGrid->EditItemIndex = $param->Item->ItemIndex;
		$this->populate();
	}

	public function saveItem($sender, $param)
	{
		$item = $param->Item;
		$this->updateSection(
				$this->ItemSectionGrid->DataKeys[$item->ItemIndex], $item->KeyColumn->TextBox->getText(), $item->LabelColumn->TextBox->getText()
		);
		$this->ItemSectionGrid->EditItemIndex = -1;
		$this->populate();
	}

	public function cancelItem($sender, $param)
	{
		$this->ItemSectionGrid->EditItemIndex = -1;
		$this->populate();
	}

	public function deleteItem($sender, $param)
	{
		$item = $param->Item;
		$this->ShrinkSectionPanel->setVisible(true);
		$this->ItemSectionGrid->SelectedItemIndex = $item->ItemIndex;
		$sect = LibraryValuePeer::retrieveByPK(
						$this->ItemSectionGrid->DataKeys[$item->ItemIndex], 'ITEMSECTION', $this->getUser()->getActualLibraryId());
		$this->SrcSection->setValue($sect->getValueKey());
		$this->SrcSectionLabel->setText('[' . $sect->getValueKey() . '] ' . $sect->getValueLabel());
		$ds = LibraryValueQuery::create()
						->filterByValueClass('ITEMSECTION')
						->filterByValueLibraryId($this->getUser()->getActualLibraryId())
						->orderByValueKey()->find();
		$this->DstSection->setDataSource($ds);
		$this->DstSection->dataBind();
		$this->populate();
		$this->SecDelete->Attributes->onclick = 'if(!confirm(\'' .
				Prado::localize('Sei sicuro di voler eliminare questa sezione?\n
					Gli esemplari contenuti rimarranno senza sezione.\n
					<b>Questa operazione non può essere annullata!</b>') . '\')) return false;';
	}

	public function showNewSectionPanel($sender, $param)
	{
		$this->NewSectionPanel->setVisible(true);
		$this->populate();
	}

	public function hideNewSectionPanel($sender, $param)
	{
		$this->NewSectionPanel->setVisible(false);
		$this->populate();
	}

	public function hideShrinkSectionPanel($sender, $param)
	{
		$this->ShrinkSectionPanel->setVisible(false);
		$this->ItemSectionGrid->SelectedItemIndex = -1;
		$this->ItemSectionGrid->EditItemIndex = -1;
		$this->populate();
	}

	public function validateUniqueKey($sender, $param)
	{
		$dupsec = LibraryValuePeer::retrieveByPK($param->Value, 'ITEMSECTION', $this->getUser()->getActualLibraryId());
		if ($dupsec !== null && $dupsec instanceof LibraryValue)
			$param->IsValid = false;
	}

	public function addSection($sender, $param)
	{
		if (!$this->getPage()->getIsValid())
			return;
		
		$sec = new LibraryValue();
		$sec->setValueClass('ITEMSECTION');
		$sec->setValueLibraryId($this->getUser()->getActualLibraryId());
		$sec->setValueKey(trim($this->NewSecKey->getText()));
		$sec->setValueLabel(trim($this->NewSecLabel->getText()));
		$sec->save();
		
		ChangelogPeer::logAction(	$sec, 
									ChangelogPeer::LOG_CREATE, 
									$this->getUser(), 
									"Aggiornata sezione [{$sec->getValueKey()} - {$sec->getValueLabel()}] della biblioteca "
										. $sec->getValueLibraryId());
														
		$this->getPage()->writeMessage(Prado::localize('Sezione "{section}" creata correttamente', 
															array('section' => $this->NewSecLabel->getText())), 
										ClavisMessage::CONFIRM);
		
		$this->hideNewSectionPanel($sender, $param);
	}
	
}