<?php

/**
 * Class ClavisItemQueryBuilder
 * @property QueryBuilder QueryBuilder
 */
class ClavisItemQueryBuilder extends TTemplateControl
{

    /**
     * @param $param
     * @throws TInvalidOperationException
     */
    public function onInit($param)
    {
        parent::onInit($param);
        $this->attachEventHandler('OnActualLibraryChanged', array($this, 'OnActualLibraryChanged'));
    }


    /**
     * @param $param
     * @throws THttpException
     */
    public function onLoad($param)
    {
        parent::onLoad($param);

        if ($this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallBack()) {
            $o = $this->QueryBuilder->getOptions();

            if (is_array($o)) {
                $this->QueryBuilder->setFilters($o['filters']);
                $this->QueryBuilder->setRules($o['rules']);
                $this->QueryBuilder->goToNormalMode();
            }
        }
    }

    /**
     * @param                          $sender
     * @param TCallbackEventParameter $params
     */
    public function onCallback($sender, $params)
    {
        $p = $params->getCallbackParameter();

        switch ($p->event) {
            case 'onSuggest':
                //dropdown-menu inner
                $out = '<ul class="ul-autocompleter" role="listbox" aria-expanded="true" style="overflow: auto;">';
                $suggestion = $this->buildSuggestionFor($p->suggest->token, $p->suggest->type, $p->suggest->subtype);

                $counter = 0;
                foreach ($suggestion as $id => $description) {
                    ++$counter;
                    if ($counter <= 10) {
                        $out .= '<li><a role="option"> <span data-lid="' . $id . '" class="text">' . trim($description) . '</span></a></li>';
                    } else {
                        $out .= '<li><a role="option"> <span data-lid="-1" class="text">' . 'Altri elementi trovati...' . '</span></a></li>';
                        break;
                    }
                }

                $out .= '</ul>';
                echo $out;
                die();
                break;

            case 'onSuggestionSelected':
                // Non utilizzo questi dati (ad esempio salvandoli su variabili di stato per ripristianre
                // la ricerca corrente)  poiche' in postback, dopo una richiesta di paginazione ad esempio, non ho piu'
                // gli id univoci per gli elementi dom su cui ho scritto il testo da cercare e quello su cui mostro i risultati.
                // Questi vengono rigenerati da jQuery-ui e non e' detto siano gli stessi di quando ho effettuato la ricerca.
                $token = $p->item->suggestionToken;
                $element_id = $p->item->elementId;
                $id = $p->item->suggestionId;
                $value = $p->item->suggestionValue;
                break;
        }
    }

    /**
     * @param null $options
     * @throws PropelException
     * @throws THttpException
     * @throws TInvalidDataValueException
     * @throws TInvalidOperationException
     */
    public function init($options = null, $rules = null)
    {
        if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallBack()) {
            $this->QueryBuilder->init($options, $this->getFiltersDefinition(), $rules);
        }
    }

    public function setAllow($allow = '')
    {
        $this->QueryBuilder->setAllow($allow);
    }

    /**
     * @return array
     */
    private function getFiltersDefinition()
    {
        $select_operators = ['equal', 'not_equal', 'not_null_and_not_empty', 'null_or_empty'];
        $autocomplete_operators = ['equal', 'not_equal', 'not_null_and_not_empty', 'null_or_empty'];
        $numbers_operators = array_merge($select_operators, ['less', 'less_or_equal', 'greater', 'greater_or_equal', 'between', 'not_between']);
        $strings_operators = array_merge($select_operators, $numbers_operators, ['begins_with', 'not_begins_with', 'contains', 'not_contains', 'ends_with', 'not_ends_with']);
        $date_operators = $numbers_operators;

        $filters = [
            ['id' => 'id_esemplare',
                'field' => 'item.item_id',
                'label' => 'ID esemplare',
                'type' => 'integer',
                'operators' => $numbers_operators,
                'validation' => ['allow_empty_value' => true],
                'value_separator' => ','],

            ['id' => 'barcode',
                'field' => 'item.barcode',
                'label' => 'Barcode',
                'type' => 'string',
                'validation' => ['allow_empty_value' => true],
                'operators' => $strings_operators],

            ['id' => 'rfid_code',
                'field' => 'item.rfid_code',
                'label' => 'Codice RFID',
                'type' => 'string',
                'validation' => ['allow_empty_value' => true],
                'operators' => $strings_operators],

            ['id' => 'title',
                'field' => 'item.title',
                'label' => 'Titolo',
                'type' => 'string',
                'validation' => ['allow_empty_value' => true],
                'operators' => $strings_operators],

            ['id' => 'id_notizia',
                'field' => 'item.manifestation_id',
                'label' => 'ID Notizia',
                'type' => 'integer',
                'validation' => ['allow_empty_value' => true],
                'operators' => $numbers_operators],

            ['id' => 'inventory_date',
                'field' => 'item.inventory_date',
                'label' => 'Data inventariazione',
                'type' => 'date',
                'input' => 'text',
                'placeholder' => 'GG-MM-AAAA',
                'validation' => ['format' => 'DD-MM-YYYY', 'allow_empty_value' => true],
                'operators' => $date_operators],

            ['id' => 'inventory_series',
                'field' => 'item.inventory_serie_id',
                'label' => 'Serie inventariale',
                'type' => 'string',
                'input' => 'select',
                'values' => $this->getDataSerieInventariali(),
                'validation' => ['allow_empty_value' => true],
                'operators' => $select_operators],

            ['id' => 'inventory',
                'field' => 'item.inventory_number',
                'label' => 'Inventario',
                'type' => 'integer',
                'validation' => ['allow_empty_value' => true],
                'operators' => $numbers_operators],

            ['id' => 'section',
                'field' => 'item.section',
                'label' => 'Sezione',
                'type' => 'string',
                'input' => 'select',
                'values' => $this->getDataItemSections(),
                'validation' => ['allow_empty_value' => true],
                'operators' => $select_operators],

            ['id' => 'collocation',
                'field' => 'item.collocation',
                'label' => 'Collocazione',
                'type' => 'string',
                'validation' => ['allow_empty_value' => true],
                'operators' => array_merge($strings_operators, ['between', 'not_between'])
            ],

            ['id' => 'specification',
                'field' => 'item.specification',
                'label' => 'Specificazione',
                'type' => 'string',
                'validation' => ['allow_empty_value' => true],
                'operators' => $strings_operators],

            ['id' => 'sequence1',
                'field' => 'item.sequence1',
                'label' => 'Sequenza 1',
                'type' => 'string',
                'validation' => ['allow_empty_value' => true],
                'operators' => $strings_operators],

            ['id' => 'sequence2',
                'field' => 'item.sequence2',
                'label' => 'Sequenza 2',
                'type' => 'string',
                'validation' => ['allow_empty_value' => true],
                'operators' => $strings_operators],

            ['id' => 'consistency_note',
                'field' => 'consistency_note.text_note',
                'label' => 'Nota di consistenza',
                'type' => 'string',
                'input' => 'text',
                'validation' => ['allow_empty_value' => true]
            ],

            ['id' => 'media',
                'field' => 'item.item_media',
                'field_class' => 'ITEMMEDIATYPE',
                'label' => 'Media',
                'type' => 'string',
                'input' => 'select',
                'values' => [],
                'validation' => ['allow_empty_value' => true],
                'operators' => $select_operators],

            ['id' => 'source',
                'field' => 'item.item_source',
                'field_class' => 'ITEMSOURCE',
                'label' => 'Provenienza',
                'type' => 'string',
                'input' => 'select',
                'values' => [],
                'validation' => ['allow_empty_value' => true],
                'operators' => $select_operators],

            ['id' => 'provider',
                'field' => 'item.supplier_id',
                'label' => 'Fornitore',
                'type' => 'string',
                'input' => 'select',
                'values' => (array)SupplierPeer::findAll2DataSource(),
                'validation' => ['allow_empty_value' => true],
                'operators' => $select_operators],

            ['id' => 'item_status',
                'field' => 'item.item_status',
                'field_class' => 'ITEMSTATUS',
                'label' => "Stato esemplare",
                'type' => 'string',
                'input' => 'select',
                'validation' => ['allow_empty_value' => true],
                'operators' => $select_operators],

            ['id' => 'order_status',
                'field' => 'item.item_order_status',
                'field_class' => 'ITEMORDERSTATUS',
                'label' => "Status ordine",
                'type' => 'string',
                'input' => 'select',
                'values' => [],
                'validation' => ['allow_empty_value' => true],
                'operators' => $select_operators],

            ['id' => 'physical_status_item',
                'field' => 'item.physical_status',
                'field_class' => 'ITEMPHYSICALSTATUS',
                'label' => "Stato fisico esemplare",
                'type' => 'string',
                'input' => 'select',
                'values' => [],
                'validation' => ['allow_empty_value' => true],
                'operators' => $select_operators],

            ['id' => 'physical_status_issue',
                'field' => 'item.issue_status',
                'field_class' => 'ISSUESTATUS',
                'label' => 'Stato fisico fascicolo',
                'type' => 'string',
                'input' => 'select',
                'values' => [],
                'validation' => ['allow_empty_value' => true],
                'operators' => $select_operators],

            ['id' => 'loan_class',
                'field' => 'item.loan_class',
                'field_class' => 'LOANCLASS',
                'label' => 'Classe prestabilità',
                'type' => 'string',
                'input' => 'select',
                'values' => [],
                'validation' => ['allow_empty_value' => true],
                'operators' => $select_operators],

            ['id' => 'loan_status',
                'field' => 'item.loan_status',
                'field_class' => 'LOANSTATUS',
                'label' => 'Stato del prestito',
                'type' => 'string',
                'input' => 'select',
                'values' => [],
                'validation' => ['allow_empty_value' => true],
                'operators' => $select_operators],

            ['id' => 'shelf_id',
                'field' => 'shelf_item.shelf_id',
                'label' => 'Scaffale',
                'type' => 'string',
                'input' => 'autocomplete',
                'values' => '',
                'validation' => ['allow_empty_value' => true],
                'operators' => ['equal', 'not_equal'],
                'SuggestionType' => 'shelves',
                'SuggestionSubType' => 'item'],

            ['id' => 'owner_library',
                'field' => 'item.owner_library_id',
                'label' => 'Biblioteca proprietaria',
                'type' => 'string',
                'input' => 'autocomplete',
                'values' => '',
                'operators' => $autocomplete_operators,
                'validation' => ['allow_empty_value' => true],
                'SuggestionType' => 'libraries',
                'SuggestionSubType' => 'all'],

            ['id' => 'home_library',
                'field' => 'item.home_library_id',
                'label' => 'Biblioteca gestione',
                'type' => 'string',
                'input' => 'autocomplete',
                'values' => '',
                'validation' => ['allow_empty_value' => true],
                'operators' => $autocomplete_operators,
                'SuggestionType' => 'libraries',
                'SuggestionSubType' => 'internal'],

            ['id' => 'prev_home_library',
                'field' => 'item.prev_home_library_id',
                'label' => 'Biblioteca gestione precedente',
                'type' => 'string',
                'input' => 'autocomplete',
                'values' => '',
                'validation' => ['allow_empty_value' => true],
                'operators' => $autocomplete_operators,
                'SuggestionType' => 'libraries',
                'SuggestionSubType' => 'internal'],

            ['id' => 'actual_library',
                'field' => 'item.actual_library_id',
                'label' => 'Biblioteca corrente',
                'type' => 'string',
                'input' => 'autocomplete',
                'values' => '',
                'validation' => ['allow_empty_value' => true],
                'operators' => $autocomplete_operators,
                'SuggestionType' => 'libraries',
                'SuggestionSubType' => 'internal'],

            ['id' => 'delivery_library',
                'field' => 'item.delivery_library_id',
                'label' => 'Biblioteca destinazione',
                'type' => 'string',
                'input' => 'autocomplete',
                'values' => '',
                'validation' => ['allow_empty_value' => true],
                'operators' => $autocomplete_operators,
                'SuggestionType' => 'libraries',
                'SuggestionSubType' => 'all'],

            ['id' => 'external_library',
                'field' => 'item.external_library_id',
                'label' => 'Biblioteca esterna (prestito)',
                'type' => 'string',
                'input' => 'autocomplete',
                'values' => '',
                'validation' => ['allow_empty_value' => true],
                'operators' => $autocomplete_operators,
                'SuggestionType' => 'libraries',
                'SuggestionSubType' => 'external'],

            ['id' => 'editing_date',
                'field' => 'item.date_updated',
                'label' => 'Data modifica',
                'type' => 'date',
                'input' => 'text',
                'placeholder' => 'GG-MM-AAAA',
                'validation' => ['format' => 'DD-MM-YYYY', 'allow_empty_value' => true],
                'operators' => $date_operators],

            ['id' => 'date_discarded',
                'field' => 'item.date_discarded',
                'label' => 'Data scarto',
                'type' => 'date',
                'input' => 'text',
                'placeholder' => 'GG-MM-AAAA',
                'validation' => ['format' => 'DD-MM-YYYY', 'allow_empty_value' => true],
                'operators' => $date_operators],

            ['id' => 'last_seen_date',
                'field' => 'item.last_seen',
                'label' => 'Data ultimo prestito',
                'type' => 'date',
                'input' => 'text',
                'placeholder' => 'GG-MM-AAAA',
                'validation' => ['format' => 'DD-MM-YYYY', 'allow_empty_value' => true],
                'operators' => $date_operators],

            ['id' => 'no_manifestation',
                'field' => 'item.manifestation_id',
                'label' => 'Catalogo',
                'type' => 'string',
                'input' => 'select',
                'operators' => ['equal'],
                'values' => $this->getDataNoManifestation(),
                'validation' => ['allow_empty_value' => true],
                'value' => '1'],

            ['id' => 'opac_visible',
                'field' => 'item.opac_visible',
                'label' => 'Visibile da OPAC',
                'type' => 'string',
                'input' => 'select',
                'operators' => ['equal'],
                'values' => $this->getDataOPACVisible(),
                'validation' => ['allow_empty_value' => true],
                'value' => '1'],

            ['id' => 'item_note_text',
                'field' => 'item_note.note',
                'label' => 'Nota: testo',
                'type' => 'string',
                'input' => 'text',
                'validation' => ['allow_empty_value' => true]

            ],

            ['id' => 'item_note_type',
                'field' => 'item_note.note_type',
                'field_class' => 'UNI3XXITEM',
                'label' => 'Nota: tipo',
                'type' => 'string',
                'input' => 'select',
                'validation' => ['allow_empty_value' => true],
                'operators' => $select_operators,
            ],
        ];

        $filters = array_merge($filters, $this->getCustomFieldsArray($strings_operators));

        return $filters;
    }


    public function searchByCriteria(Criteria $criteria): void
    {
        $this->searchItems($this, $criteria);
    }

    /**
     * @param $sender
     * @param $param
     */
    public function searchItems($sender, $param)
    {
        $this->cleanSearch();

        try {
            if ($param instanceof Criteria) {
                // -------------------------------- Search by criteria
                $criteria = $param;
            } else {
                // -------------------------------- Search by rules
                $rules = $param['rules'];
                $transformationRules = $this->getTransformationRules();
                $joinRules = $this->getJoinRules();

                $itemQuery = ItemQuery::create();
                $criteria = QueryBuilderToPropelDB::create()->translate($rules, $transformationRules, $itemQuery, $joinRules);
            }

            $sql = ($criteria instanceof Criteria) ? $criteria->toString() : '';
            error_log(sprintf("%s: ItemQuery: (%s)", __METHOD__, print_r($sql, true)));


            $this->ItemList->setExternalCriteria($criteria);
            $this->ItemList->populate();

            if (is_array($param) && is_callable($param['callback'])) {
                call_user_func($param['callback']);
            }

        } catch (Exception $e) {
            $this->getPage()->writeMessage(Prado::localize('Riscontrato problema con questa ricerca. [' . $e->getMessage() . ']'), ClavisMessage::ERROR);
            if (is_array($param) && is_callable($param['callback'])) {
                call_user_func($param['callback']);
            }
        }

        if ($this->getPage()->getIsCallback()) {
            $this->ListPanel->render($this->getPage()->createWriter());
        }
    }


    private function getTransformationRules()
    {
        $fieldMap = [
            'no_manifestation' => [
                'field_name' => [
                    'default' => 'item.manifestation_id',
                ],
                'transform_type' => 'operator_value_map',
                'transform_param' => [
                    'operator_value_map' => [
                        'value_map' => [1 => -1, 2 => 0, 3 => 0],
                        'operator_map' => [1 => 'all', 2 => 'greater', 3 => 'less_or_equal']
                    ]
                ]
            ],
            'opac_visible' => [
                'field_name' => [
                    'default' => 'item.opac_visible',
                ],
                'transform_type' => 'operator_value_map',
                'transform_param' => [
                    'operator_value_map' => [
                        'value_map' => [1 => -1, 2 => 1, 3 => 1],
                        'operator_map' => [1 => 'all', 2 => 'equal', 3 => 'null_or_empty_or_zero']
                    ]
                ]
            ]
        ];

        return $fieldMap;
    }

    /**
     * @return array
     */
    public function getDefaultRule()
    {
        return [
            'condition' => 'AND', // -> combine or
            'rules' => [
                [
                    'id' => 'no_manifestation',
                    'operator' => 'equal',
                    'value' => 1
                ],
                [
                    'id' => 'item_status',
                    'operator' => 'not_equal',
                    'value' => ItemStatus::ITEMSTATUS_DISCARDED
                ],

                // set two empty rules so the user can fill them without clicking on the add rule button...
                ['empty' => true], ['empty' => true]
            ]
        ];
    }

    /**
     * @param $sender
     * @param $param
     * @return array
     */
    public function onSetDefaultRule($sender, $param)
    {
        return $this->getDefaultRule();
    }


    /**
     * @param $sender
     * @param $param
     * @throws PropelException
     * @throws THttpException
     * @throws TInvalidDataValueException
     * @throws TInvalidOperationException
     */
    public function OnActualLibraryChanged($sender, $param)
    {
        // reload the filters definition in order to update library-specific data. (i.e. inventory series)
        $o = $this->QueryBuilder->getOptions();
        if (is_array($o)) {
            $this->QueryBuilder->init($o, $this->getFiltersDefinition());
        }
    }

    /**
     * @param $sender
     * @param $param
     * @throws PropelException
     */
    public function onAddToShelf($sender, $param)
    {
        $this->getPage()->cleanMessageQueue();

        $shelfId = (int)$this->ShelfResultValue->getValue();
        $shelf = ShelfQuery::create()->findPK($shelfId);
        $this->ShelfResultValue->setValue('');

        if ($shelf instanceof Shelf) {
            $checkedId = $this->ItemList->getCheckedId();

            $this->ItemList->resetCheckedItems();
            $ok = (int)$shelf->addItemToShelf(ShelfPeer::TYPE_ITEM, $checkedId);
            $failed = count($checkedId) - $ok;
            $shelf->save();

            $this->getPage()->enqueueMessage(Prado::localize("{ok} esemplari aggiunti/aggiornati nello scaffale {shelf}",
                array('ok' => $ok,
                    'shelf' => $shelf->getShelfCompleteName())),
                ClavisMessage::CONFIRM);

            if ($failed > 0) {
                $this->getPage()->enqueueMessage(Prado::localize("{failed} esemplari non aggiunti allo scaffale {shelf} in conseguenza di errori",
                    array('failed' => $failed,
                        'shelf' => $shelf->getShelfCompleteName())),
                    ClavisMessage::ERROR);
            }
        } else {
            $this->getPage()->enqueueMessage(Prado::localize("Lo scaffale scelto non risulta valido."),
                ClavisMessage::ERROR);
        }

        $this->getPage()->globalRefresh();
        $this->getPage()->flushMessage();
    }


    /**
     * @param $givenItemIds
     */
    public function setGivenItemIds($givenItemIds)
    {
        $this->ItemList->setGivenItemIds($givenItemIds);

    }


    /**
     * @param      $search
     * @param      $type
     * @param null $subtype
     * @return array
     */
    private function buildSuggestionFor($search, $type, $subtype = null)
    {
        switch ($type) {
            case 'libraries':
                return $this->getDataLibraries($search, $subtype);
                break;
            case 'shelves':
                return $this->getDataShelves($search, $subtype);
                break;
        }
    }

    /**
     *
     */
    private function cleanSearch()
    {
        $this->ItemList->resetExternalCriteria();
        $this->ItemList->resetPagination();
        $this->ItemList->populate();
    }

    /**
     *
     */
    public function populate()
    {
        $this->ItemList->populate();
    }

    /**
     * @return mixed
     */
    private function getDataSerieInventariali()
    {
        $lid = $this->getUser()->getActualLibraryId();

        $inv_series = InventorySerieQuery::create()
            ->orderByClosed()
            ->orderByReadonly()
            ->orderByInventorySerieId()
            ->findByLibraryId($lid);

        foreach ($inv_series as $i) {
            $ds[$i->getInventorySerieId()] = $i->getDescription() . ' (' . $i->getInventorySerieId() . ')';
        }

        return $ds;
    }

    /**
     * @return mixed
     */
    private function getDataItemSections()
    {
        $sects = LibraryValueQuery::create()
            ->filterByValueClass('ITEMSECTION')
            ->filterByValueLibraryId($this->getUser()->getActualLibraryId())
            ->orderByValueKey()
            ->find();

        $ds = [];
        foreach ($sects as $i) {
            $ds[$i->getValueKey()] = $i->getValueLabel();
        }

        return $ds;
    }


    /**
     * @param string $search
     * @param string $subtype
     * @return array
     */
    private function getDataShelves($search = '', $subtype = 'item'): array
    {
        $shelfQuery = ShelfQuery::create();
        $shelfQuery
            ->filterByShelfItemtype($subtype)
            ->filterByShelfName("%$search%", Criteria::LIKE);

        $output = [];
        /** @var Shelf $shelf */
        foreach ($shelfQuery->find() as $shelf) {
            $output[$shelf->getShelfId()] = htmlspecialchars($shelf->getShelfName());
        }
        return $output;
    }

    /**
     * @param string $search
     * @param string $subtype // internal, external, all
     * @return array
     */
    private function getDataLibraries($search = '', $subtype = '')
    {
        $libQuery = LibraryQuery::create();

        if ($subtype === 'internal') {
            $libQuery->filterByLibraryInternal(true);
        }

        if ($subtype === 'external') {
            $libQuery->filterByLibraryInternal(false);
        }

        $libQuery->filterByLabel("%$search%", Criteria::LIKE)
            ->orderByLabel(Criteria::ASC)
            ->orderByLibraryId()
            ->limit(11);

        $output = [];
        /** @var Library $library */
        foreach ($libQuery->find() as $library) {
            $output[$library->getLibraryId()] = htmlspecialchars($library->getLabel());
        }

        return $output;
    }

    /**
     * @return array
     */
    private function getDataNoManifestation()
    {
        // the keys of this array MUST start from 1
        return [
            1 => 'Tutti gli esemplari',
            2 => 'Solo a catalogo',
            3 => 'Solo i fuori catalogo'
        ];
    }


    /**
     * @return array
     */
    private function getItemNoteTypes()
    {
        // the keys of this array MUST start from 1
        return [
            1 => 'Tutti gli esemplari',
            2 => 'Solo a catalogo',
            3 => 'Solo i fuori catalogo'
        ];
    }

    /**
     * @return array
     */
    private function getDataOPACVisible()
    {
        // the keys of this array MUST start from 1
        return [
            1 => '---',
            2 => 'Solo visibili da OPAC',
            3 => 'Solo NON visibili da OPAC'
        ];
    }

    /**
     * @return array
     */
    private function getCustomFieldsArray($operators)
    {
        for ($i = 1; $i <= 3; $i++) {
            $data = $this->getCustomField($i);

            $a[] = [
                'id' => 'custom' . $i,
                'field' => 'item.custom_field' . $i,
                'label' => $data['label'],
                'type' => 'string',
                'input' => $data['input'],
                'values' => $data['values'],
                'validation' => ['allow_empty_value' => true],
                'operators' => $operators
            ];
        }
        return $a;
    }

    /**
     * @param $num
     * @return array
     */
    private function getCustomField($num)
    {
        return [
            'label' => LookupValuePeer::getLookupValue('CUSTOMLABEL', 'ItemCustom' . $num),
            'input' => LookupValuePeer::classExists('ITEMCUST' . $num) ? 'select' : '',
            'values' => LookupValuePeer::getLookupClassValues('ITEMCUST' . $num, false)
        ];
    }

    /**
     * @return array
     */
    private function getJoinRules(): array
    {
        $joinRules['shelf_item'] = [
            'isInJoin' => false,
            'from' => ItemPeer::ITEM_ID,
            'to' => ShelfItemPeer::OBJECT_ID,
            'type' => Criteria::JOIN,
            'setDistinct' => true
        ];

        $joinRules['item_note'] = [
            'isInJoin' => false,
            'from' => ItemPeer::ITEM_ID,
            'to' => ItemNotePeer::ITEM_ID,
            'type' => Criteria::JOIN
        ];

        $joinRules['consistency_note'] = [
            'isInJoin' => false,
            'from' => ItemPeer::MANIFESTATION_ID,
            'to' => ConsistencyNotePeer::MANIFESTATION_ID,
            'type' => Criteria::LEFT_JOIN
        ];

        return $joinRules;
    }
}
