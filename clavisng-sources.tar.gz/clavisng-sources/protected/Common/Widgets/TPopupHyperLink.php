<?php
/**
 * TPopupHyperLink Class
 *
 * This extends a Prado TLinkButton with the capabilities to open an iframe,
 * and passes the two Id's of the controls (ex. TTextBox) where the
 * iframe will write a "label" and a "value".
 * (NB: this controls must generate an html "<input ..>" tag, so a TLabel
 * has not to be used.....)
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2008 ePortal Technologies
 * @copyright Copyright &copy; 2009-2013 Comperio srl
 * @version 2.7
 * @package Controls
 * @since 2.0
 */

class TPopupHyperLink extends THyperLink
{
	/**
	 * Constructor
	 */
	public function __construct()
	{
		if ($this->getNavigateUrl() == '')
			$this->setNavigateUrl('#');

		parent::__construct();
	}

	/**
	 * Registers the javascript code and publishes in the
	 * Prado assets directory.
	 *
	 * @param TEventParameter $param
	 */
	public function onPreRender($param)
	{
		parent::onPreRender($param);

		$scripts = $this->getPage()->getClientScript();
		$scripts->registerPradoScript('prado');
		$scripts->registerPradoScript('effects');
		if (!$scripts->isScriptFileRegistered('ButtonFunctions.js'))
			$scripts->registerScriptFile('ButtonFunctions.js',
				$this->publishFilePath(Prado::getPathOfNamespace('Application.Javascript')).'/ButtonFunctions.js');
	}

	/**
	 * Sets the url of the iframe which has to be open.
	 *
	 * @param string $value
	 */
	public function setPopupPage($value)
	{
		//TODO  fare un controllo se il file esiste

		//$url = "index.php?page=" . $value;
		$this->setControlState('PopupPage', $value, '');
	}

	/**
	 * Gets the url of the iframe.
	 *
	 * @return string
	 */
	public function getPopupPage()
	{
		return $this->getControlState('PopupPage', '');
	}

	/**
	 * Sets the Prado Id of the control where a (string) label
	 * will be returned by the iframe.
	 *
	 * @param string $label
	 */
	public function setReturnLabel($label)
	{
		$this->setControlState('ReturnLabel', $label, '');
	}

	/**
	 * Returns the Prado Id of the label.
	 *
	 * @return string
	 */
	public function getReturnLabel()
	{
		return $this->getControlState('ReturnLabel', '');
	}

	/**
	 * Sets the Prado Id of the control where a (mixed) value
	 * will be returned by the iframe.
	 *
	 * @param string $value
	 */
	public function setReturnValue($value)
	{
		$this->setControlState('ReturnValue', $value, '');
	}

	/**
	 * Returns the Prado Id of the value.
	 *
	 * @return string
	 */
	public function getReturnValue()
	{
		return $this->getControlState('ReturnValue', '');
	}

			/**
	 * Sets the Prado Id of the control where a (string) label
	 * will be returned by the iframe.
	 *
	 * @param string $label
	 */
	public function setReturnLabel2($label)
	{
		$this->setControlState('ReturnLabel2', $label, '');
	}

	/**
	 * Returns the Prado Id of the label.
	 *
	 * @return string
	 */
	public function getReturnLabel2()
	{
		return $this->getControlState('ReturnLabel2', '');
	}

	/**
	 * Sets the Prado Id of the control where a (mixed) value
	 * will be returned by the iframe.
	 *
	 * @param string $value
	 */
	public function setReturnValue2($value)
	{
		$this->setControlState('ReturnValue2', $value, '');
	}

	/**
	 * Returns the Prado Id of the value.
	 *
	 * @return string
	 */
	public function getReturnValue2()
	{
		return $this->getControlState('ReturnValue2', '');
	}

	/**
	 * Sets the popup's return auto submit mode.
	 * By default it's false.
	 *
	 * @param string $value
	 */
	public function setAutoSubmit($value)
	{
		$this->setControlState('AutoSubmit', $value, '');
	}

	/**
	 * Gets the popup's return auto submit mode.
	 * By default it's false.
	 *
	 * @return string
	 */
	public function getAutoSubmit()
	{
		return $this->getControlState('AutoSubmit', '');
	}

	/**
	 * Sets the optional confirm message to be shown before opening the popup
	 *
	 * @param string $value
	 */
	public function setConfirmMessage($value)
	{
		$this->setControlState('ConfirmMessage', $value, '');
	}

	/**
	 * Gets the optional confirm message to be shown before opening the popup
	 *
	 * @return string
	 */
	public function getConfirmMessage()
	{
		return $this->getControlState('ConfirmMessage', '');
	}

	/**
	 * Specify a callback function to call on popup closing.
	 *
	 * @param string $function The callback function, defaults to ''.
	 */
	public function setCallbackFunction($function) {
		$this->setControlState('CallbackFunction', $function, '');
	}

	/**
	 * Returns the callback function to call on popup closing.
	 *
	 * @return string The callback function, defaults to ''.
	 */
	public function getCallbackFunction() {
		return $this->getControlState('CallbackFunction','');
	}

	/**
	 * Extends the Prado method which attaches an attribute
	 * to a control, so to add the "onclick" attribute which
	 * will point to the javascript function which opens the
	 * iframe (with parameters).
	 *
	 * @param THtmlWriter $writer
	 */
	protected function addAttributesToRender($writer)
	{
		if(($label = $this->getReturnLabel()) !== '')
		{
			if($control = $this->findControl($label))
				$labelId = $control->getClientID();
			else
				throw new TInvalidDataValueException('ReturnLabel_associatedcontrol_invalid',$label);
		} else
			$labelId = 'null';

		if(($value = $this->getReturnValue()) !== '')
		{
			if($control = $this->findControl($value))
				$valueId = $control->getClientID();
			else
				throw new TInvalidDataValueException('ReturnValue_associatedcontrol_invalid',$value);
		} else
			$valueId = 'null';

		if (($label2 = $this->getReturnLabel2()) !== '') {
			if ($control = $this->findControl($label2))
				$label2Id = $control->getClientID();
			else
				throw new TInvalidDataValueException('ReturnLabel_associatedcontrol_invalid',$label2);
		} else {
			$label2Id = 'null';
		}
		if (($value2 = $this->getReturnValue2()) !== '') {
			if ($control = $this->findControl($value2))
				$value2Id = $control->getClientID();
			else
				throw new TInvalidDataValueException('ReturnValue_associatedcontrol_invalid',$value2);
		} else {
			$value2Id = 'null';
		}

		$page = $this->getPopupPage();

		//if ($this->getAutoSubmit() == "true")
			$formId = $this->getPage()->getForm()->getClientId();
		//else
		//	$formId = null;

		$paramString = '';
		$confirmMessage = str_replace('\'','\\\'',$this->getConfirmMessage());
		$callback = $this->getCallbackFunction();


		if(($label2 != '')&&($value2 != '')) {
			if ($confirmMessage == '') {
				$paramString = "openIframeEx('" . $page . "', '" . $labelId . "', '" . $valueId . "', '" .
					$label2Id . "', '" . $value2Id . "', '". $formId . "','{$callback}'); return false;";
			} else {
				$paramString = "openIframeMsgEx('" . $page . "', '" . $labelId . "', '" . $valueId . "', '" .
					$label2Id . "', '" . $value2Id . "', '". $formId . "', '{$callback}','" .$confirmMessage. "'); return false;";
			}
	    } else {
			if ($confirmMessage == '') {
				$paramString = "openIframe('" . $page . "', '" . $labelId . "', '" . $valueId . "', '" .
					$formId . "','{$callback}'); return false;";
			} else {
				$paramString = "openIframeMsg('" . $page . "', '" . $labelId . "', '" . $valueId . "', '" .
					$formId . "', '{$callback}', '" .$confirmMessage. "'); return false;";
			}
		}

		$writer->addAttribute('onclick', $paramString);
		parent::addAttributesToRender($writer);
	}
}

?>