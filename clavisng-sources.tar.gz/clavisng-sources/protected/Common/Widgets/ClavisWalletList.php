<?php
/**
 * ClavisWalletList class file
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Dario Rigolin <dario@comperio.it>
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2016 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 */

/**
 * ClavisWalletList
 *
 * It visualizes the patron wallet widget (portafoglio).
 *
 * @author Dario Rigolin <dario@comperio.it>
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @copyright Copyright &copy; 2016 Comperio srl
 * @version 2.7
 * @package Widgets
 * @since 2.0
 */

class ClavisWalletList extends TTemplateControl
{
    public function onLoad($param)
    {
        parent::onLoad($param);
		
        if (!$this->Page->getIsPostBack()
				&& !$this->Page->getIsCallBack())
        {
			$this->cleanFilters();
			$this->DataGrid->setQuery($this->buildQuery());

            if($this->getViewMode() == "patron")
                $this->WalletPrint->setReportClass("JR_WALLET");
            else
                $this->WalletPrint->setReportClass("JR_WALLET_REPORT");

            $this->reloadData();
        }
		
        $this->attachEventHandler("OnFeeUpdated",array($this,'onFeeUpdated'));
    }

	public function onPreRender($param)
	{
		parent::onPreRender($param);
		
		if (!$this->getPage()->getIsPostBack()
				&& !$this->getPage()->getIsCallback())
		{
			$this->WalletAction->setSelectedValue(PatronWallet::ACTION_DEPOSIT);
			$this->WalletStatus->setSelectedValue(PatronWallet::STATUS_CLOSED);
			$this->WalletType->setSelectedValue(PatronWallet::TYPE_PRINT);
			
			if ($this->getViewMode() == 'patron')
			{
				$libraries = LibraryPeer::getLibrariesHashWithBlank(null, null, true);
				$this->LibraryFilter->setDataSource($libraries);
				$this->LibraryFilter->dataBind();
			}
		}
	}
	
    public function reloadData()
    {
		$this->DataGrid->setQuery($this->buildQuery());
        $this->DataGrid->doPopulate();
		
		if ($this->getViewMode() == "patron")
			$this->WalletSummaryPopulate();
    }

    public function setObjectId($objid)
    {
        $this->setControlState("objectid",$objid);
    }

    public function getObjectId()
    {
        return $this->getControlState("objectid");
    }

    public function getViewMode()
    {
        return $this->getControlState("ViewMode","patron");
    }

    public function setViewMode($mode)
    {
        $this->setControlState("ViewMode",$mode,"patron");
    }

    public function onAddWalletItem($sender, $param)
    {
        $wallet = new PatronWallet();
        $wallet->setPatronId($this->getObjectId());
        $wallet->setLibraryId($this->User->getActualLibraryId());
        $wallet->setWalletNote($this->WalletNote->SafeText);
        $wallet->setAmount($this->WalletAmount->SafeText);
        $wallet->setWalletStatus($this->WalletStatus->SelectedValue);
        $wallet->setWalletType($this->WalletType->SelectedValue);
        $wallet->setWalletAction($this->WalletAction->SelectedValue);
	if($this->WalletStatus->getSelectedValue() == "B")
	{
                $wallet->createReceiptId();
	}
        $wallet->save();

        $this->WalletNote->setText("");
//        $this->WalletStatus->setSelectedIndex(0);
//        $this->WalletType->setSelectedIndex(0);
//        $this->WalletAction->setSelectedIndex(0);
        $this->WalletAmount->setText("");

        $this->reloadData();
    }

    public function onFeeUpdated($sender,$param)
    {
        $this->reloadData();
    }

    public function getObject()
    {
        if($this->getViewMode() == "patron")
            $object = PatronQuery::create()->findOneByPatronId($this->getObjectId());
        else
            $object = LibraryQuery::create()->findOneByLibraryId($this->getObjectId());

        return $object;
    }

    public function onItemCreated($sender,$param)
    {

    }
    
    public function onItemDataBound($sender,$param)
    {        
        if( ($param->Item->ItemType == 'Item' || $param->Item->ItemType == 'AlternatingItem') && $param->Item->Data['WalletStatus'] == 'B')
        {
            //Prado::log(Prado::varDump($param->Item->ActionColumn->Controls[0],1));
            //Prado::log(Prado::varDump($param->Item,2));
            $param->Item->ActionColumn->Controls[0]->Visible= FALSE;
            //Prado::log($param->Item->ActionColumn->Controls[0]->Text);
            //Prado::log($param->Item->ItemType . "    ----    " . $param->Item->Data['WalletStatus']);
        }
    }

    public function onEditItem($sender,$param)
    {
        $this->DataGrid->EditItemIndex = $param->Item->ItemIndex;
        $this->reloadData();
    }

    public function onCancelItem($sender,$param)
    {
        $this->DataGrid->EditItemIndex = -1;
        $this->reloadData();
    }

    public function onItemCommand($sender, $param)
    {
        //Prado::log("On item command");
    }

    public function onUpdateItem($sender,$param)
    {
        $item = $param->Item;
        $walletId = $this->DataGrid->DataKeys[$item->ItemIndex];
        $wallet = PatronWalletQuery::create()->findOneByWalletId($walletId);
        if($wallet instanceof PatronWallet)
        {
            if($item->WalletStatusCol->DropDownList->getSelectedValue() == "B" && $wallet->getReceiptId() == null)
                $wallet->createReceiptId();


            $wallet->setWalletNote($item->WalletNoteCol->TextBox->Text);
            $wallet->setAmount($item->WalletAmountCol->TextBox->Text);
            $wallet->setWalletAction($item->WalletActionCol->DropDownList->getSelectedValue());
            $wallet->setWalletStatus($item->WalletStatusCol->DropDownList->getSelectedValue());

            $wallet->save();
            $wallet->reload();
        }
        $this->DataGrid->EditItemIndex=-1;

        $this->reloadData();
        $this->broadcastEvent("OnFeeUpdated",$this,new TBroadcastEventParameter());
    }

    public function walletPrintReceipt($sender, $param)
    {
        if($this->getViewMode() == "patron")
        {
            $this->WalletPrint->addOptionalParam("P_MASTER_CKECK", ($this->DataGrid->getViewState("MasterCheck", false)) ? "1" : "0");
            $idList = join(",",$this->DataGrid->getViewState("RowsChecked", array()));
            $this->WalletPrint->addOptionalParam("P_WALLETIDS", ($idList=="") ? "0" : $idList);
        }

        $this->WalletPrint->printReport();
    }

	public function onResetDate($sender, $param)
	{
		$this->DateFrom->setText('');
 		$this->DateTo->setText('');

 		if ($this->getPage()->getIsCallback())
		{
			if (is_null($param))
				$writer = $this->getPage()->createWriter();
			else
				$writer = $param->getNewWriter();
			
			$this->DatePanel->render($writer);
		}
	}
	
    public function onWalletSearch($sender, $param)
    {
		$this->DataGrid->setQuery($this->buildQuery());
        $this->DataGrid->doPopulate();
    }

	public function onWalletCancel($sender, $param)
	{
		$this->cleanFilters($param);
		
		$this->DataGrid->setQuery($this->buildQuery());
		$this->DataGrid->doPopulate();
	}
	
	private function cleanFilters($param = null)
	{
		$this->TypeFilter->setSelectedValue(-1);
		$this->ActionTypeFilter->setSelectedValue(-1);
		$this->StatusFilter->setSelectedValue(-1);
		$this->LibraryFilter->setSelectedValue($this->getUser()->getActualLibraryId());
		$this->onResetDate(null, null);
		
		if ($this->getPage()->getIsCallback())
		{
			if (is_null($param))
				$writer = $this->getPage()->createWriter();
			else
				$writer = $param->getNewWriter();
			
			$this->FilterPanel->render($writer);
		}
	}
	
    public function buildQuery()
    {
		$object = $this->getObject();
		$wallets = PatronWalletQuery::create()

		->_if($this->getViewMode() == "patron")
			->filterByPatron($object)
			->filterByLibraryId($this->getUser()->getActualLibraryId())
		->_elseif($this->getViewMode() == "library")
			->filterByLibrary($object)
		->_endif()

		->_if($this->TypeFilter->getSelectedIndex() >= 1)
			->filterByWalletType($this->TypeFilter->getSelectedValue())
		->_endif()
				
		->_if($this->ActionTypeFilter->getSelectedIndex() >= 1)
			 ->filterByWalletAction($this->ActionTypeFilter->getSelectedValue())
		->_endif()

		->_if($this->StatusFilter->getSelectedIndex() >= 1)
			->filterByWalletStatus($this->StatusFilter->getSelectedValue())
		->_endif()
				
		->_if($this->LibraryFilter->getSelectedIndex() >= 1)
			->filterByLibraryId($this->LibraryFilter->getSelectedValue())
		->_endif()				
				
		->withColumn("(SELECT label FROM library WHERE library_id = patron_wallet.library_id)","LibraryLabel")
		->withColumn("(SELECT concat_ws(', ',lastname, name) FROM patron WHERE patron_id = patron_wallet.patron_id)","PatronLabel")
		->withColumn("(SELECT username FROM librarian WHERE librarian_id=PatronWallet.ModifiedBy)","LibrarianName")
		
		->orderByDateCreated(Criteria::DESC);

        return $wallets;
    }

	private function WalletSummaryPopulate()
	{
		$summaryData = array();
		
//		$summaryData[] = array(	'walletType' => "TIPOOOO",
//								'total' => 12000);

		$query = "SELECT `wallet_type`,
							SUM(IF(`wallet_status` IN ('" . PatronWallet::STATUS_OPEN . "', '" . PatronWallet::STATUS_CLOSED . "'), `amount`, 0.0)) AS total_amount, 
							SUM(IF(`wallet_status` = '" . PatronWallet::STATUS_OPEN . "', `amount`, 0.0)) as open_amount
					FROM `patron_wallet`
					WHERE `patron_id` = " . $this->getObjectId() . " AND
							`library_id` = " . $this->getUser()->getActualLibraryId() . "
					GROUP BY `wallet_type`";

		foreach (Propel::getConnection()->query($query) as $row)
		{
			$summaryData[] = array(	'wallet_type' => LookupValuePeer::getLookupValue('WALLETTYPE', $row['wallet_type']),
									'total_amount' => $row['total_amount'],
									'open_amount' => $row['open_amount'] );
		}
		
		$this->WalletSummaryList->setDataSource($summaryData);
		$this->WalletSummaryList->dataBind();
	}
	
}
