<?php
/**
 * ClavisLibraryView
 *
 * @author Max Pigozzi <mpigozzi@e-portaltech.it>
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @author Marco Brancalion <marco@comperio.it>
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @copyright Copyright &copy; 2010 Comperio srl
 */

class ClavisLibraryView extends TTemplateControl
{
	private $_library;

	public function populate($libraryId = null)
	{
		/** @var $library Library */

		$library = null;
		$libraryId = intval($libraryId);
		
		if ($libraryId > 0)
			$library = LibraryQuery::create()->findPk($libraryId);
		
		if ($library instanceof Library)
		{
			$this->setLibrary($library);
			
			$this->Name->setText($library->getLabel());
			$this->Librarycode->setText($library->getLibraryCode());
			$this->IllCode->setText($library->getIllCode());
			$this->SbnCode->setText($library->getSbnCode());
			$this->Shortlabel->setText($library->getShortlabel());

			$consortia = ConsortiaQuery::create()->findPk($library->getConsortiaId());

			if ($consortia instanceof Consortia)
				$this->Consortium->setText($consortia->getDescription());

			$this->Description->setText($library->getDescription());
			$this->Libraryclass->setText(LookupValuePeer::getLookupValue('LIBCLASS', $library->getLibraryClass()));
			$this->Librarytype->setText($library->getLibraryTypeString());
			$this->Librarystatus->setText(LookupValuePeer::getLookupValue('LIBSTATUS', $library->getLibraryStatus()));

			/*
			if ($this->getExtendedView())
			{
			*/
			
			$this->Address->setText($library->getAddress());
			$this->Country->setText($library->getCountry());
			$this->Province->setText($library->getProvince());
			$this->City->setText($library->getCity());
			$this->Phone->setText($library->getPhone());
			$this->Fax->setText($library->getFax());

			$emailText = trim(TPropertyValue::ensureString($library->getEmail()));
			$this->Email->setText($emailText);
			$this->Email->setNavigateUrl($emailText != '' 
											? 'mailto:' . $emailText
											: $emailText);

			$this->Website->setText($library->getWebsite());

			$this->Billingaddress->setText($library->getBillingAddress());
			//}

			if ($this->getUser()->getIsSuperAdmin())
			{
				if (LibraryPeer::isContractExpire($libraryId))
				{
					$this->ContractExpireDate->setValue(LibraryPeer::getContractExpireDate($libraryId));
					$this->ContractExpireTolerance->setText(LibraryPeer::getContractExpireTolerance($libraryId));
					
					if (intval(LibraryPeer::getContractDaysLeft($libraryId)) > 0)
					{
						$this->ContractExpireDateLabel->setStyle("width: 12em; border: 4px solid yellow;");
						$this->ContractExpireDateLabel->setTooltip(LibraryPeer::getContractLeftStringSubfix(false));
					}
					elseif (intval(LibraryPeer::getContractDaysExpired($libraryId)) > 0)
					{
						$this->ContractExpireDateLabel->setStyle("width: 12em; border: 4px solid red;");
						$this->ContractExpireDateLabel->setTooltip(LibraryPeer::getContractExpiredStringSubfix(false));
						$this->ContractExpireTolerance->setStyle("width: 4em; border: 4px solid red;");
					}
					elseif (intval(LibraryPeer::getContractDaysBlocked($libraryId)) > 0)
					{
						$this->ContractExpireDateLabel->setStyle("width: 12em; border: 4px solid red;");
						$this->ContractExpireDateLabel->setTooltip(LibraryPeer::getContractBlockedStringSubfix(false));
						$this->ContractExpireTolerance->setStyle("width: 4em; border: 4px solid red;");
					}
					else
					{
						$this->ContractExpireDateLabel->setStyle("width: 12em; border: 4px solid green;");
					}
				}		
			}

			$this->setLibraryId($libraryId);
			$this->setLibrary($library);
			$this->formview->setCssClass('panel_on');
			$this->formview2->setCssClass('panel_on');
			$this->Populated->setValue(true);

			$this->Timetable->setLibraryId($libraryId);
			
			$this->populateProperties();
		}
		else
		{
			$this->formview->setCssClass('panel_off');
			$this->formview2->setCssClass('panel_off');
			$this->Populated->setValue(false);
		}
	}

	public function populateProperties()
	{
		if (!$this->_library instanceof Library)
			return;
				
		$properties = array();

		foreach ($this->_library->getLibraryPropertys() as $property)     
		{
			$p = array();
			$p['PropertyLabel'] = LookupValuePeer::getLookupValue("LIBRARYPROPERTY", $property->getPropertyClass());
			$p['PropertyValue'] = $property->getPropertyValue();
			$p['id'] = $property->getLibraryPropertyId();

			$properties[] = $p;
		}

		$this->PropertyGrid->setDataSource($properties);
		$this->PropertyGrid->dataBind();
	}
	
	public function setLibrary($library)
	{
		$this->_library = $library;
		$this->setViewState('Library', $library, null);
	}

	public function getLibrary()
	{
		$this->_library = $this->getViewState('Library', null);
		
		return $this->_library;
	}

	public function setLibraryId($libraryId)
	{
		$this->setViewState('LibraryId', $libraryId, null);
	}

	public function getLibraryId()
	{
		return $this->getViewState('LibraryId', null);
	}

	public function setExtendedView($value)
	{
		$this->setControlState("ExtendedView", TPropertyValue::ensureBoolean($value), false);
	}

	public function getExtendedView()
	{
		return $this->getControlState("ExtendedView",false);
	}

}