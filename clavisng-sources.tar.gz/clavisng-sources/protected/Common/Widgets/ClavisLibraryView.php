<?php
/**
 * ClavisLibraryView
 *
 * @author Max Pigozzi
 * @author Ciro Mattia Gonano
 * @author Marco Brancalion <marco@comperio.it>
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @copyright Copyright &copy; 2010 Comperio srl
 */

class ClavisLibraryView extends TTemplateControl
{
	private $_library;

	public function populate($libraryId = null)
	{
		/** @var $library Library */

		$library = null;
		$libraryId = intval($libraryId);
		
		if ($libraryId > 0)
			$library = LibraryQuery::create()->findPk($libraryId);
		
		if ($library instanceof Library)
		{
			$this->setLibrary($library);
			
			$this->Name->setText($library->getLabel());
			$this->Librarycode->setText($library->getLibraryCode());
			$this->IllCode->setText($library->getIllCode());
			$this->SbnCode->setText($library->getSbnCode());
			$this->Shortlabel->setText($library->getShortlabel());

			$consortia = ConsortiaQuery::create()->findPk($library->getConsortiaId());

			if ($consortia instanceof Consortia)
				$this->Consortium->setText($consortia->getDescription());

			$this->Description->setText($library->getDescription());
			$this->Libraryclass->setText(LookupValuePeer::getLookupValue('LIBCLASS', $library->getLibraryClass()));
			$this->Librarytype->setText($library->getLibraryTypeString());
			$this->Librarystatus->setText(LookupValuePeer::getLookupValue('LIBSTATUS', $library->getLibraryStatus()));

			$this->Address->setText($library->getAddress());
			$this->Country->setText($library->getCountry());
			$this->Province->setText($library->getProvince());
			$this->City->setText($library->getCity());
			$this->Phone->setText($library->getPhone());
			$this->Fax->setText($library->getFax());

			$emailText = trim(TPropertyValue::ensureString($library->getEmail()));
			$this->Email->setText($emailText);
			$this->Email->setNavigateUrl($emailText != '' 
											? 'mailto:' . $emailText
											: $emailText);

			$this->Website->setText($library->getWebsite());
			$this->Billingaddress->setText($library->getBillingAddress());

			$parentLibrary = null;
			$parentLibraryId = (int) $library->getParentLibraryId();
			$this->ParentLibraryPanel->setVisible(false);
			
			if ($parentLibraryId > 0)
			{
				$parentLibrary = LibraryQuery::create()->findPk($parentLibraryId);
				
				if ($parentLibrary instanceof Library)
				{
					$this->ParentLibraryPanel->setVisible(true);
					
					$this->ParentLibraryLabel->setEnabled(true);
					$this->ParentLibraryLabel->setNavigateUrl($this->getService()->constructUrl('Library.LibraryViewPage', array('id' => $parentLibraryId)));
					$this->ParentLibraryLabel->setText($parentLibrary->getLabel());
				}
			}
			
			/*
			$childrenLibraryCombo = $library->getChildrenLibraryCombo();

			if ($childrenLibraryCombo != "")
			{
				$this->ChildrenLibraryPanel->setVisible(true);
				$this->ChildrenLibraryCombo->setText($childrenLibraryCombo);
			}
			else
			{
				$this->ChildrenLibraryPanel->setVisible(false);
			}
			*/
			
			/*
			$childrenLibrary = $library->getChildrenLibrary();

			if (count($childrenLibrary) > 0)
			{
				$this->ChildrenLibraryPanel->setVisible(true);
				$this->PopupChildrenLibrary->setParam(array(	'libraryIds' => serialize($childrenLibrary),
															'showActions' => 'false' ));
			}
			else
			{
				$this->ChildrenLibraryPanel->setVisible(false);
			}
			 */
			
			if ($this->getUser()->getIsSuperAdmin())
			{
				if (LibraryPeer::isContractExpire($libraryId))
				{
					$this->ContractExpireDate->setValue(LibraryPeer::getContractExpireDate($libraryId));
					$this->ContractExpireTolerance->setText(LibraryPeer::getContractExpireTolerance($libraryId));
					
					if (intval(LibraryPeer::getContractDaysLeft($libraryId)) > 0)
					{
						$this->ContractExpireDateLabel->setStyle("width: 12em; border: 4px solid yellow;");
						$this->ContractExpireDateLabel->setTooltip(LibraryPeer::getContractLeftStringSubfix(false));
					}
					elseif (intval(LibraryPeer::getContractDaysExpired($libraryId)) > 0)
					{
						$this->ContractExpireDateLabel->setStyle("width: 12em; border: 4px solid red;");
						$this->ContractExpireDateLabel->setTooltip(LibraryPeer::getContractExpiredStringSubfix(false));
						$this->ContractExpireTolerance->setStyle("width: 4em; border: 4px solid red;");
					}
					elseif (intval(LibraryPeer::getContractDaysBlocked($libraryId)) > 0)
					{
						$this->ContractExpireDateLabel->setStyle("width: 12em; border: 4px solid red;");
						$this->ContractExpireDateLabel->setTooltip(LibraryPeer::getContractBlockedStringSubfix(false));
						$this->ContractExpireTolerance->setStyle("width: 4em; border: 4px solid red;");
					}
					else
					{
						$this->ContractExpireDateLabel->setStyle("width: 12em; border: 4px solid green;");
					}
				}		
			}

			$this->setLibraryId($libraryId);
			$this->setLibrary($library);
			$this->formview->setCssClass('panel_on');
			$this->formview2->setCssClass('panel_on');
			$this->Populated->setValue(true);

			$this->Timetable->setLibraryId($libraryId);
			
			$this->populateProperties();
		}
		else
		{
			$this->formview->setCssClass('panel_off');
			$this->formview2->setCssClass('panel_off');
			$this->Populated->setValue(false);
		}
	}

	public function populateProperties()
	{
		if (!$this->_library instanceof Library)
			return;
				
		$properties = [];

		foreach ($this->_library->getLibraryPropertys() as $property)     
		{
			$propertyLabel = LookupValuePeer::getLookupValue("LIBRARYPROPERTY", $property->getPropertyClass());
			$propertyValue = $property->getPropertyValue();
			$propertyId = $property->getLibraryPropertyId();
			
			$cycleProperty = array(	'PropertyLabel' => $propertyLabel,
									'PropertyValue' => $propertyValue,
									'id' => $propertyId );
			
			$properties[] = $cycleProperty;
		}

		$this->PropertyGrid->setDataSource($properties);
		$this->PropertyGrid->dataBind();
	}
	
	public function setLibrary($library)
	{
		$this->_library = $library;
		$this->setViewState('Library', $library, null);
	}

	public function getLibrary()
	{
		$this->_library = $this->getViewState('Library', null);
		
		return $this->_library;
	}

	public function setLibraryId($libraryId)
	{
		$this->setViewState('LibraryId', $libraryId, null);
	}

	public function getLibraryId()
	{
		return $this->getViewState('LibraryId', null);
	}

	public function setExtendedView($value)
	{
		$this->setControlState("ExtendedView", TPropertyValue::ensureBoolean($value), false);
	}

	public function getExtendedView()
	{
		return $this->getControlState("ExtendedView",false);
	}

}