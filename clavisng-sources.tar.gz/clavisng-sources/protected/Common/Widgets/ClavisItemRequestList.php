<?php
/**
 * ClavisItemRequestList class file
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.8.9
 */

/**
 * ClavisItemRequestList class
 *
 * This component visualizes the item requests which are stored in the
 * databases, related to an item or a patron, into a datagrid.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.8.9
 * @package Widgets
 * @since 2.1
 */
class ClavisItemRequestList extends TTemplateControl
{
	private $_object;
	private $_DatasourceSessionName;
	private $_illCheckedSessionName;
	private $_globalCriteriaSessionName;
	private $_checked;
	public  $_onlySelectedSessionName;
	public $_wantedToolTips;

	private function initVars()
	{
		$uniqueId = $this->getUniqueID();
		$this->_DatasourceSessionName = "DataSourceSessionName" . $uniqueId;
		$this->_illCheckedSessionName = 'IllCheckedSessionName' . $uniqueId;
		$this->_globalCriteriaSessionName = 'GlobalCriteriaSessionName' . $uniqueId;
		$this->_wantedToolTips = array( 'green' => Prado::localize('la prenotazione può essere soddisfatta da esemplari nella biblioteca attuale'),
										'yellow' => Prado::localize('la prenotazione può essere soddisfatta da esemplari presenti nel sistema, ma non dalla biblioteca attuale'),
										'red' => Prado::localize('nessun esemplare nel sistema può attualmente soddisfare la prenotazione') );
	}

	public function onInit($param)
	{
		parent::onInit($param);
		$this->initVars();
		
		$this->_checked = $this->getChecked();
		
		/*
		if (!$this->getPage()->getIsPostBack()
				&& !$this->getPage()->getIsCallback())
		{
			$this->NoSearchPanel->setVisible(false);
			$this->PopulatedFlag->setValue("false");
		}
		 */
	}

	/**
	 * It populates our datagrid during the very first cycle
	 * of the parent page.
	 *
	 * @param TEventParameter $param
	 */
	public function onLoad($param)
	{
		parent::onLoad($param);

		$this->getObject();
		///$populated = ($this->PopulatedFlag->getValue() == "true");

		if (!$this->getPage()->getIsPostBack())
			$this->ActiveRequest->setChecked(true);

		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallback())
			$this->resetDataSource();
		
		//////$this->NoSearchPanel->setVisible(!$populated);
	}

	public function resetDataSource()  // da sistemare
	{
		//$this->resetChecked();
		//$this->resetBarcodes();
		//$this->_datasource = array();
		
//		$this->PopulatedFlag->setValue("false");
//		$this->NoSearchPanel->setVisible(!$this->getAutopopulate());
		
		$this->setDataSource(array());
		
		//$this->setChecked(array());
		$this->resetChecked();
		
		$this->populate();
	}

	public function setGlobalCriteria($criteria = null)
	{
		$this->setViewState($this->_globalCriteriaSessionName, $criteria, null);
	}

	public function getGlobalCriteria()
	{
		return SerializableCriteria::refreshCriteria($this->getViewState($this->_globalCriteriaSessionName, null));
	}
	
	public function getDataSource()
	{
		return $this->getApplication()->getSession()->itemAt($this->_DatasourceSessionName);
	}

	public function setDataSource($val)
	{
		$this->getApplication()->getSession()->add($this->_DatasourceSessionName, $val);
	}

	public function setObject($obj)
	{
		$this->_object = $obj;
		$this->setViewState("object", $obj, null);
	}

	public function getObject()
	{
		$this->_object = $this->getViewState("object", null);
		return $this->_object;
	}

	public function reloadStoredObject()
	{
		$obj = $this->getObject();
		
		if (!is_null($obj) 
				&& !$obj->isNew())
		{
			$objId = $obj->getId();
			$peerClass = $obj->getPeer();
			$newObj = $peerClass->retrieveByPK($objId);
			$this->setObject($newObj);
		}
	}

	public function populate($object = null)
	{
		if (!is_null($object))
		{
			$this->_object = $object;
			$this->setObject($this->_object);
		}
		else
		{
			$this->reloadStoredObject();
		}

		if (is_null($this->_object))
			return false;

		$loanableItemsByAllFlag = false;
		$loanableItemsByManifestationFlag = false;

		switch (get_class($this->_object))		// the page where i'm in
		{
			case 'Patron':
				$this->PatronColumn->setVisible(false);
				
				break;

			case 'Item':
				$this->TitleColumn->setVisible(false);
				$manifestation = $this->_object->getManifestation();
				
				if ($manifestation instanceof Manifestation)
				{
					$loanableItemsByManifestationFlag = $manifestation->isLoanableByMyLibrary($this->GetUser()->getActualLibraryId());
					$loanableItemsByAllFlag = $manifestation->isLoanableByAll();
				}
				
				break;

			case 'Manifestation':
				$this->TitleColumn->setVisible(false);
				$this->IconTitleColumn->setVisible(true);
				$manifestation = $this->_object;
				
				if (!is_null($manifestation)
						&& ($manifestation instanceof Manifestation ))
				{
					$loanableItemsByManifestationFlag = $manifestation->isLoanableByMyLibrary();
					$loanableItemsByAllFlag = $manifestation->isLoanableByAll();
				}
				
				break;
		}

		$pageSize = $this->Grid->getPageSize();
		$currentIndexPage = $this->Grid->getCurrentPage();
		$activeRequest = $this->ActiveRequest->getChecked();

		$criteria = new Criteria();

		if ($activeRequest)
		{
			$criteria->add(ItemRequestPeer::REQUEST_STATUS, array(ItemRequestPeer::STATUS_PENDING, ItemRequestPeer::STATUS_WORKING), Criteria::IN);
			$criteria->addAscendingOrderByColumn(ItemRequestPeer::REQUEST_DATE);
		}
		else
		{
			$criteria->addDescendingOrderByColumn(ItemRequestPeer::REQUEST_DATE);
		}

		$this->setGlobalCriteria($criteria);
		
		$recCount = $this->_object->countItemRequests($criteria);
		$this->RecCounter->setText($recCount);

		$criteria->setLimit($pageSize);
		$criteria->setOffset($currentIndexPage * $pageSize);
		$data = array();
		$itemRequests = array();

		if ($recCount > 0)
			$itemRequests = $this->_object->getItemRequests($criteria);

		foreach ($itemRequests as $itemRequest)
		{
			$row = array();

			$row['RequestStatus'] = $itemRequest->getRequestStatus();
			$row['RequestStatusString'] = $itemRequest->getRequestStatusString()
											. ((ItemRequestPeer::isRequestType()	&& !is_null($itemRequest->getRequestType()))
												? '&nbsp;<b>[' . ItemRequestPeer::getRequestTypeString($itemRequest->getRequestType()) . ']</b>'
												: '');

			$wantedUrl = '';
			$wantedText = '';
			$wantedImageUrl = '';
			$wantedPopupUrl = '';
			$wantedToolTip = '';
			$wantedId = 0;

			$itemRequestFlag = false;
			$item = $itemRequest->getItem();
			
			/** This is the case when we have a pending request on an item
			 * or when the request is done and in this way we have here an
			 * indication about the item that was used for satisfying the
			 * request.
			 */
			if ($item instanceof Item)
			{
				$itemRequestFlag = true;
				$wantedTitle = trim($item->getCompleteTitle());
				if (!$wantedTitle)
					$wantedTitle = Prado::localize('(nessun titolo)');
				
				$wantedId = intval($item->getId());

				if ((get_class($this->_object) == "Manifestation")
						//&& ($itemRequest->getRequestStatus() != ItemRequestPeer::STATUS_PENDING))
						&& in_array($itemRequest->getRequestStatus(), ItemRequestPeer::getActiveStatus()))
				{
					if ($item->isLoanableByMyLibrary())
					{
						$wantedUrl = "index.php?page=Catalog.ItemViewPage&id=" . $wantedId;
						$wantedImageUrl = "themes/Default/icons/nav_plain_green-16.png";
						$wantedToolTip = $this->_wantedToolTips['green'];
					}
					else
					{
						$wantedUrl = "index.php?page=Catalog.ItemViewPage&id=" . $wantedId;
						$wantedImageUrl = "themes/Default/icons/nav_plain_red-16.png";
						$wantedToolTip = $this->_wantedToolTips['red'];
					}

					$wantedPopupUrl = "Circulation.ItemRequestListPopup&id=" . $item->getManifestationId() . "&requestId=" . $itemRequest->getId();
				}
				else
				{
					$wantedUrl = "index.php?page=Catalog.ItemViewPage&id=" . $wantedId;
					$wantedText = $wantedTitle . $item->getExternalString();
				}
			}
			else	// request on MANIFESTATION and still active (not closed nor nulled)
			{
				$manifestation = $itemRequest->getManifestation();
				
				if ($manifestation instanceof Manifestation)
				{
					$wantedTitle = $manifestation->getCompleteTitle();
					$wantedId = intval($manifestation->getId());
					if (in_array($itemRequest->getRequestStatus(), ItemRequestPeer::getActiveStatus()))
					{
						if ($loanableItemsByManifestationFlag)
						{
							$wantedUrl = "index.php?page=Catalog.Record&manifestationId=" . $wantedId;
							$wantedImageUrl = "themes/Default/icons/nav_plain_green-16.png";
							$wantedToolTip = $this->_wantedToolTips['green'];
						}
						elseif ($loanableItemsByAllFlag)
						{
							$wantedUrl = "index.php?page=Catalog.Record&manifestationId=" . $wantedId;
							$wantedImageUrl = "themes/Default/icons/nav_plain_yellow-16.png";
							$wantedToolTip = $this->_wantedToolTips['yellow'];
						}
						else
						{
							$wantedUrl = "index.php?page=Catalog.Record&manifestationId=" . $wantedId;
							$wantedImageUrl = "themes/Default/icons/nav_plain_red-16.png";
							$wantedText = $wantedTitle;
							$wantedToolTip = $this->_wantedToolTips['red'];
						}
					}

					$wantedPopupUrl = "Circulation.ItemRequestListPopup&id=" . $wantedId . "&requestId=" . $itemRequest->getId();
				}
			}
			
			$row['WantedId'] = $wantedId;
			$row['WantedUrl'] = $wantedUrl;
			$row['WantedText'] = $wantedText;
			$row['WantedImageUrl'] = $wantedImageUrl;
			$row['WantedToolTip'] = $wantedToolTip;
			$row['ItemRequestFlag'] = $itemRequestFlag;
			$row['WantedPopupUrl'] = $wantedPopupUrl;

			$toolTip = '';
			$patron = $itemRequest->getPatron();
			
			if ($patron instanceof Patron)
			{
				$patronCompleteName = $patron->getCompleteName();
				$navigateUrl = "index.php?page=Circulation.PatronViewPage&id=" . $patron->getId();
			}
			else
			{
				$externalLibraryId = intval($itemRequest->getExternalLibraryId());
				$externalLibrary = LibraryPeer::retrieveByPK($externalLibraryId);
				
				if (!is_null($externalLibrary))
				{
					$patronCompleteName = $externalLibrary->getLabel(true, false, true, 30);
					$navigateUrl = "index.php?page=Library.LibraryViewPage&id=" . $externalLibrary->getLibraryId();
					$toolTip = $externalLibrary->getDescription() . ' (' . $externalLibrary->getConsortiaString() . ')';
				}
				else
				{
					$patronCompleteName = "(" . Prado::localize("senza nome") . ")";
					$navigateUrl = '';
				}
			}

			$row['PatronCompleteName'] = $patronCompleteName;
			$row['PatronNavigateUrl'] = $navigateUrl;
			$row['PatronNavigateUrlToolTip'] = $toolTip;
			$row['RequestDate'] = $itemRequest->getRequestDate('U');
			$row['ExpireDate'] = $itemRequest->getExpireDate('U');
			$row['RequestNote'] = $itemRequest->getRequestNote();
			$row['Id'] = $itemRequest->getId();

			$row['DeliveryLibraryId'] = $itemRequest->getDeliveryLibraryId();
			$row['DeliveryLibraryString'] = $itemRequest->getDeliveryLibraryString();

			$position = $itemRequest->getQueuePosition();
			if ($position == 0)
				$position = '---';
			$row['QueuePosition'] = $position;

			$data[] = $row;
		}

		$this->Grid->VirtualItemCount = $recCount;
		$this->Grid->setDataSource($data);
		$this->Grid->dataBind();

		$this->setDataSource($data);
		////$this->NoSearchPanel->setVisible(false);
	}

	public function onChangePage($sender, $param)
	{
		$this->Grid->setCurrentPage($param->NewPageIndex);
		$this->globalRefresh();
	}

	/**
	 * It returns whether the page permits that in this component
	 * we can have the functions that components inside popups have.
	 *
	 * @return boolean
	 */
	public function getPopupFlag()
	{
		return $this->getPage()->isPopup();
	}

	/**
	 * It returns whether the page permits that in this component
	 * we can have the unlink function.
	 *
	 * @return boolean
	 */
	public function getUnlinkFlag()
	{
		return $this->getPage()->isUnlink();
	}

	/**
	 * It returns whether the page permits that in this component
	 * we can have the delete function.
	 *
	 * @return boolean
	 */
	public function getDeleteFlag()
	{
		return $this->getPage()->isDelete();
	}

	/**
	 * This method, called for unlinking, calls the relative
	 * method of the parent page.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onUnlink($sender, $param)
	{
		$id = $param->CommandParameter;
		$this->GetPage()->Unlink($id);
	}

	public function resetPagination()
	{
		$this->Grid->setCurrentPage(0);
	}

	public function onActiveRequestChanged($sender, $param)
	{
		$this->resetPagination();
		$this->populate();
	}

	public function globalRefresh()
	{
		$this->populate();
	}
			
	public function resetSelectedPanel()
	{
		$this->SelectedPanel->setCssClass('panel_off');
		$this->SelectedNumber->setText(0);
	}
	
	public function resetChecked($state = false, $updateGridFlag = true)
	{
		$toExcludeRequestIds = array();
		
		foreach ($this->Grid->getItems() as $item)
		{
			if ($item->CheckColumn->Checked->getVisible())
			{
				if ($updateGridFlag)
					$item->CheckColumn->Checked->setChecked($state);
			}
			else
			{
				if ($updateGridFlag)
					$item->CheckColumn->Checked->setChecked(false);

				if ($state)
				{
					$requestId = intval($item->CheckColumn->CheckRequestId->getValue());
		
					if ($requestId > 0)
						$toExcludeRequestIds[$requestId] = true;
				}
			}
		}

		$newStates = array('all' => $state) + $toExcludeRequestIds;
		$this->setChecked($newStates);
		
		$this->updateSelectedPanel();
	}

	public function setChecked($checked = null)
	{
		$this->_checked = $checked;
		$this->getApplication()->getSession()->add($this->_illCheckedSessionName, $checked);
	}

	public function getChecked()
	{
		$this->_checked = $this->getApplication()->getSession()->itemAt($this->_illCheckedSessionName);

		if (is_null($this->_checked))
		{
			$this->resetChecked(false, false); // don't update grid
			$this->_checked = $this->getApplication()->getSession()->itemAt($this->_illCheckedSessionName);
		}

		return $this->_checked;
	}
	
	public function getCheckedItemIds(	$force = false,
										$reset = false,
										$jasperMode = false)
	{
		$checked = $this->getChecked();
		$masterChecked = $checked['all'];
		unset($checked['all']);
		$checkedIds = array_keys($checked);
		$requestIds = array();
		$itemIds = array();
		$output = array();
		$itemFilters = array();

		if (!$masterChecked)
		{
			$requestIds = $checked;
		}
		else // the strange case of inverse mastercheck  ...
		{
			$criteria = $this->getGlobalCriteria();
			$criteria->add(ItemRequestPeer::REQUEST_ID, array_keys($checked), Criteria::NOT_IN);

			if ($activeRequest)
				$criteria->add(ItemRequestPeer::REQUEST_STATUS, array(ItemRequestPeer::STATUS_PENDING, ItemRequestPeer::STATUS_WORKING), Criteria::IN);

			$criteria->clearSelectColumns()->addSelectColumn(ItemRequestPeer::REQUEST_ID);
			$requests = $this->_object->getItemRequests($criteria);
			
			/* @var $request ItemRequest */
			foreach ($requests as $request)
				$requestIds[$request->getRequestId()] = true;
		}

		if ((count($requestIds) == 0) 
				&& ($force))
		{
			$this->resetChecked(true);
			$requestIds= $this->getCheckedItemIds();
		}

		if ($reset)
			$this->resetChecked(false);

		return $requestIds;
	}

	public function countCheckedIds(	$force = false,
										$reset = false)
	{
		$checked = $this->getChecked();
		$masterChecked = $checked['all'];
		unset($checked['all']);
		$checkedIds = array_keys($checked);
		$requestIds = array();
		$itemIds = array();
		$output = array();
		$itemFilters = array();
					
		if (!$masterChecked)	// normal case, not masterchecked
		{
			$requestCount = count($checked);
		}
		else	// the strange case of inverse mastercheck  ...
		{
			$criteria = $this->getGlobalCriteria();
			$criteria->add(ItemRequestPeer::REQUEST_ID, array_keys($checked), Criteria::NOT_IN);
			
			if ($activeRequest)
				$criteria->add(ItemRequestPeer::REQUEST_STATUS, array(ItemRequestPeer::STATUS_PENDING, ItemRequestPeer::STATUS_WORKING), Criteria::IN);

			$requestCount = $this->_object->countItemRequests($criteria);
		}	// end of inverse masterchecked case

		if (($requestCount == 0)
				&& $force)
		{
			$this->resetChecked(true);
			$requestCount = $this->countCheckedItemIds();
		}

		if ($reset)
			$this->resetChecked(false);

		return $requestCount;
	}
	
	public function setMasterChecked($newChecked = false, $param = null)
	{
		$checked = $this->getChecked();
		$masterChecked = $checked['all'];
		unset($checked['all']);
		$checkedIds = array_keys($checked);
		$requestIds = array();
		$itemIds = array();
		$output = array();
		$itemFilters = array();

		if (!$masterChecked)
		{
			$requestCount = count($checkedIds);
		}
		else // the strange case of inverse mastercheck  ...
		{
			if ($this->getInvertMode())
			{
				$requestDateFrom = $this->getRequestDateFrom();
				$requestDateTo = $this->getRequestDateTo();
				$loanStatusFlag = $this->getLoanStatusFlag();
				$loanableSinceFlag = $this->getLoanableSinceFlag();

				$itemFilters = array_merge($itemFilters, array(	'requestDateFrom' => $requestDateFrom,
																'requestDateTo' => $requestDateTo,
																'loanStatusFlag' => $loanStatusFlag,
																'loanableSinceFlag' => $loanableSinceFlag,
																'excludeRequestIds' => $checkedIds ));

				$requestCount = $this->_requestManager->countNeverRequests(null, $itemFilters); // not paginated
			}
			else //		normal pending requests case
			{
				if ($this->getViewFiltersFlag())
				{
					$sectionFilter = "";
					
					if ($this->SectionFilter->getSelectedIndex() > 0)
						$sectionFilter = $this->SectionFilter->getSelectedValue();

					$collocationFilter = "";
					
					if (($candCollocationFilter = $this->CollocationFilter->getSafeText()) != "")
						$collocationFilter = $candCollocationFilter;

					$manifestationIdParamFilter = "";
					$itemIdParamFilter = "";

					$barcodeInvFilter = trim($this->BarcodeInvFilter->getSafeText());

					if ($barcodeInvFilter != "")
						list ($manifestationIdParamFilter, $itemIdParamFilter) = $this->calculateParamsFromBarcode($barcodeInvFilter);

					$patronFilter = "";
					$patronId = intval($this->PatronHiddenValue->getValue());
					
					if ($patronId > 0)
						$patronFilter = $patronId;

					$deliveryLibraryId = "";
					
					if ($this->DeliveryLibraryFilter->getSelectedIndex() > 0)
						$deliveryLibraryId = $this->DeliveryLibraryFilter->getSelectedValue();

					$maxDistance = "";
					
					if ($this->_llibraryActive
							&& ($this->MaxDistanceListFilter->getSelectedIndex() > 0))
						$maxDistance = $this->MaxDistanceListFilter->getSelectedValue();

					$requestType = "";
					
					if ($this->_requestTypeActive
							&& ($this->RequestTypeListFilter->getSelectedIndex() > 0))
						$requestType = $this->RequestTypeListFilter->getSelectedValue();
					
					$itemFilters = array(	'section' => $sectionFilter,
											'collocation' => $collocationFilter,
											'manifestationIdParam' => $manifestationIdParamFilter,
											'itemIdParam' => $itemIdParamFilter,
											'patron' => $patronFilter,
											'deliveryLibraryId' => $deliveryLibraryId,
											'maxDistance' => $maxDistance,
											'requestType' => $requestType,
											'excludeRequestIds' => $checkedIds );
				}
				else
				{
					$itemFilters = array();
				}

				$requestCount = $this->_requestManager->countRequests(	null,
																		$itemFilters); // not paginated
			}
		}

		if (($requestCount == 0)
				&& ($force))
		{
			$this->resetChecked(true);
			$requestCount = $this->countCheckedItemIds();
		}

		if ($reset)
			$this->resetChecked(false);

		return $requestCount;
	}
	
	public function onAddToShelf($sender, $param)
	{
		$errorShelfFlag = false;
		$shelfId = $this->ShelfResultValue->getValue();
		$this->ShelfResultValue->setValue(null);
		
		if (is_numeric($shelfId)
				&& !is_null($shelfId))
		{
			$shelf = ShelfQuery::create()->findPK($shelfId);
			
			if ($shelf instanceof Shelf)
			{
				$idsRaw = $this->getCheckedItemIds();
				$ids = array_keys($idsRaw);

				$countDone = $shelf->addItemToShelf('item_request', $ids);
				$countFailed = count($ids) - $countDone;
				
				if ($countDone > 0)
				{
					$this->getPage()->writeMessage($countDone == 1
															? Prado::localize("1 prenotazione nello scaffale '{shelfname}' con id: {shelfid}",
																					array(	'shelfname' => $shelf->getShelfName(),
																							'shelfid' => $shelf->getId() ))
							
															: Prado::localize("{count} prenotazioni aggiunte nello scaffale '{shelfname}' con id: {shelfid}",
																				array(	'count' => $countDone,
																						'shelfname' => $shelf->getShelfName(),
																						'shelfid' => $shelf->getId() )),
														ClavisMessage::INFO);
				}

				if ($countFailed > 0)
					$this->getPage()->writeMessage($countFailed == 1 
															? Prado::localize("1 prenotazione NON aggiunta nello scaffale '{shelfname}' con id: {shelfid}",
																					array(	'shelfname' => $shelf->getShelfName(),
																							'shelfid' => $shelf->getId() ))
							
															: Prado::localize("{count} prenotazioni NON aggiunte nello scaffale '{shelfname}' con id: {shelfid}",
																				array(	'count' => $countDone,
																						'shelfname' => $shelf->getShelfName(),
																						'shelfid' => $shelf->getId() )),
														ClavisMessage::ERROR);
			}
			else
			{
				$errorShelfFlag = true;
			}
		}
		else
		{
			$errorShelfFlag = true;
		}

		if ($errorShelfFlag)
		{
			$this->getPage()->writeMessage(Prado::localize("Lo scaffale '{shelfname}' con id: {shelfid} non esiste",
																				array(	'shelfname' => $shelf->getShelfName(),
																						'shelfid' => $shelf->getId() )),
												ClavisMessage::ERROR);
		}
		else
		{	
			if ($this->TeleportCheck->getChecked())
				$this->getPage()->gotoPageWithReturn('Communication.ShelfViewPage', array('id' => $shelfId));
		}
	}
	
	/**
	 * It changes the status (on/off) of the checkbox of one chosen
	 * row item of datagrid.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onFlipChecked($sender, $param)
	{
		$index = $sender->Parent->Parent->ItemIndex;
		$dataSource = $this->getDataSource();

		$newStatus = $sender->getChecked();
		$checked = $this->getChecked();

		if (array_key_exists($index, $dataSource))
		{
			$row = $dataSource[$index];
		}
		else 
		{
			return false;
		}

		if (array_key_exists('Id', $row))
		{
			$requestId = $row['Id'];
		}
		else 
		{
			return false;
		}

		if (array_key_exists('all', $checked))
		{
			$checkedAll = $checked['all'];
		}
		else
		{
			return false;
		}

		if ($newStatus != $checkedAll)
		{
			$checked[$requestId] = true;
		}
		else
		{
			unset($checked[$requestId]);
		}

		$this->setChecked($checked);
		$this->updateSelectedPanel($param);
	}

	public function forceChecked($index)
	{
		$dataSource = $this->getDataSource();
		$checked = $this->getChecked();

		if (array_key_exists($index, $dataSource))
		{
			$row = $dataSource[$index];
		}
		else 
		{
			return false;
		}

		$this->resetChecked(false);

		if (array_key_exists('Id', $row))
		{
			$requestId = $row['Id'];
		}
		else 
		{
			return false;
		}

		$checked[$requestId] = true;
		$this->setChecked($checked);
		
		$this->updateSelectedPanel($param);
	}
	
	public function getMasterChecked()
	{
		$checked = $this->getChecked();
		
		return $checked['all'];
	}
	
	public function onMasterChecked($sender, $param)
	{
		$newStatus = $sender->getChecked();
		$this->resetChecked($newStatus);
		$gridItems = $this->Grid->getItems();
		
		foreach($gridItems as $item)
		{	
			$item->CheckColumn->Checked->setChecked(	$item->CheckColumn->Checked->getVisible()
																? $newStatus
																: false );
		}

		$this->updateSelectedPanel($param);
	}

	public function updateSelectedPanel($param = null)
	{
		$this->SelectedNumber->setText(intval($this->countCheckedIds()));

		if ($this->getPage()->getIsCallback())
		{
			if (!is_null($param))
			{
				$writer = $param->getNewWriter();
			}
			else
			{
				$writer = $this->getPage()->createWriter();
			}
			
			$this->SelectedPanel->render($writer);
		}
	}
	
}