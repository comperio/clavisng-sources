<?php
/**
 * ClavisChangelogList class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Widgets
 */

/**
 * ClavisChangelogList
 *
 * @author Max Pigozzi
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @version 2.8.3
 * @package Widgets
 * @since 2.1
 */

class ClavisChangelogList extends TTemplateControl 
{ 
	const LIBRARY_NULL = 424242;
	const LIMIT_CSV = 100000;
	
	private $_userClass;
	private $_userId;
	private $_objectClass;
	private $_objectId;
	private $_globalCriteriaSessionName;
	private $_viewFiltersSessionName;
	private $_eventTypeSessionName;
	private $_eventType;

	private function initVars()
	{
		$uniqueId = $this->getUniqueID();
		$this->_globalCriteriaSessionName = 'GlobalCriteriaSessionName'.$uniqueId;
		$this->_viewFiltersSessionName = 'ViewFiltersSessionName' . $uniqueId;
		$this->_eventTypeSessionName = 'EventTypeSessionName' . $uniqueId;
	}

	public function onInit($param)
	{
		parent::onInit($param);
		$this->initVars();

		$this->NoSearchPanel->setVisible(false);
		
		// first page cycle
		if (!$this->getPage()->getIsPostBack() 
				&& !$this->getPage()->getIsCallback())
		{
			$this->ObjectClassFilter->setDataSource(LookupValuePeer::getLookupClassValues(	'OBJECTCLASS',
																							true,
																							'---',
																							null,
																							true,
																							25));
			
			$this->ObjectClassFilter->dataBind();
			
			$this->Library->setDataSource(LibraryPeer::getLibrariesHash(	array(	LibraryPeer::BLANKVALUE, 
																					self::LIBRARY_NULL ),
					
																			array(	'---', 
																					'(' . Prado::localize('non presente') . ')' )));
			
			$this->Library->dataBind();
			
			//$this->LimitSearchFilter->setText(self::LIMIT_SEARCH);
		}
	}

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsPostBack() 
				&& !$this->getPage()->getIsCallback())
		{
			if ($this->getAutomaticPopulate())
			{
//                                if ($this->getObjectClassFilter() != '') { 
//                                    $this->ObjectClassFilter->setSelectedIndex() = $this->getObjectClassFilter();
//                                    
//                                }
				$this->populate();
			}
			else
			{
				$this->writeResults();
				$this->NoSearchPanel->setVisible(true);
			}
		}
		
		$this->FilterPanel->setCssClass($this->getViewFilters() ? 'panel_on' : 'panel_off');
	}

	public function getLimitCsv()
	{
		return (int) self::LIMIT_CSV;
	}
	
	public function setAutomaticPopulate($flag = true)
	{
		if ($flag === "true")
		{
			$flag = true;
		}
		elseif ($flag === "false")
		{
			$flag = false;
		}
		
		$this->setViewState("automaticPopulate", $flag, true);
	}

	public function getAutomaticPopulate()
	{
		return $this->getViewState("automaticPopulate", true);
	}
	
	public function setGlobalCriteria($criteria = null)
	{
		$this->setViewState($this->_globalCriteriaSessionName, $criteria, null);
	}

	public function getGlobalCriteria()
	{
		return SerializableCriteria::refreshCriteria($this->getViewState($this->_globalCriteriaSessionName, null));
	}

	public function setUserId($user_id)
	{
		$user_id = intval($user_id);
		$this->_userId = $user_id;
		$this->setControlState("user_id", $user_id, null);
	}

	public function getUserId()
	{
		if (is_null($this->_userId))
			$this->_userId = $this->getControlState("user_id", null);
		
		return $this->_userId;
	}

	public function setUserClass($user_class)
	{
		$user_class = TPropertyValue::ensureString($user_class);
		$this->_userClass = $user_class;
		$this->setControlState("user_class", $user_class, null);
	}

	public function getUserClass()
	{
		if (is_null($this->_userClass))
			$this->_userClass = $this->getControlState("user_class", null);
		
		return $this->_userClass;
	}

	public function setObjectId($object_id)
	{
		$object_id = intval($object_id);
		$this->_objectId = $object_id;
		$this->setControlState("object_id", $object_id, null);
	}

	public function getObjectId()
	{
		if (is_null($this->_objectId))
			$this->_objectId = $this->getControlState("object_id", null);
		
		return $this->_objectId;
	}

	public function setObjectClass($object_class)
	{
		$object_class = TPropertyValue::ensureString($object_class);
		$this->_objectClass = $object_class;
		$this->setControlState("object_class", $object_class, null);
	}

	public function getObjectClass()
	{
		if (is_null($this->_objectClass))
			$this->_objectClass = $this->getControlState("object_class", null);
		
		return $this->_objectClass;
	}
        
	public function setEventType($event_type)
	{
		$event_type = TPropertyValue::ensureString($event_type);
		$this->_eventType = $event_type;
		$this->setControlState($this->_eventTypeSessionName, $event_type, null);
	}

	public function getEventType()
	{
		if (is_null($this->_eventType))
			$this->_eventType = $this->getControlState($this->_eventTypeSessionName, null);

		return $this->_eventType;
	}

	public function setViewFilters($filter = true)
	{
		$this->getApplication()->getSession()->add($this->_viewFiltersSessionName, $filter);
	}

	public function getViewFilters()
	{
		$filter = $this->getApplication()->getSession()->itemAt($this->_viewFiltersSessionName);
		if (is_null($filter))
			$filter = true;
		return $filter;
	}

	public function getSortingExpression()
	{
		return $this->ChangelogGrid->getSortingExpression();
	}

	public function getSortingDirection()
	{
		return $this->ChangelogGrid->getSortingDirection();
	}

	public function calculateSortingCriteria(&$sortingCriteria = null)
	{
		$sortingExpression = $this->getSortingExpression();
		$sortingDirection = $this->getSortingDirection();

		if (is_null($sortingCriteria) 
				|| !($sortingCriteria instanceof Criteria))
			$sortingCriteria = new Criteria();

		switch ($sortingExpression)
		{
			case 'EventDate':
				$sortingCriteria->clearOrderByColumns();
				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
				{
					$sortingCriteria->addAscendingOrderByColumn(ChangelogPeer::EVENT_DATE);
				}
				elseif ($sortingDirection == TClavisDataGrid::SORTDIRECTION_DESC)
				{
					$sortingCriteria->addDescendingOrderByColumn(ChangelogPeer::EVENT_DATE);
				}
				
				break;

			case null:
				
				break;

			default:
				$sortingExpression = null;
				
				break;
		}
	}

	public function populate()
	{
		$this->NoSearchPanel->setVisible(false);
		$this->ObjClass->setVisible(true);
		$this->ObjId->setVisible(true);
		$this->UsClass->setVisible(true);
		$this->UsName->setVisible(true);

		$pageSize = $this->ChangelogGrid->getPageSize();
		$currentIndexPage = $this->ChangelogGrid->getCurrentPage();
		$criteria = new Criteria();
        
		$eventTypeSelectedValue = $this->EventTypeFilter->getSelectedValue();
		
		if (($eventTypeSelectedValue != "0")
				&& ($eventTypeSelectedValue != ""))
		{
			$eventType = $eventTypeSelectedValue;
		} 
		else 
		{
			$eventType = $this->getEventType();
		}
		
		$eventType = TPropertyValue::ensureString($eventType);
		
		if ($eventType != "") 
		{
                    $criteria->addAnd(ChangelogPeer::EVENT_TYPE, $eventType);
                    $this->EventTypeFilter->setSelectedValue($eventType);
		}
                
		if ($this->ObjectClassFilter->getSelectedIndex() > 0) {
                    $objectClass = $this->ObjectClassFilter->getSelectedValue();
		} 
		else 
		{
			$objectClass = $this->getObjectClass();
                    
			if (!is_null($objectClass))
				$this->ObjClass->setVisible(false);
			
		}
		$objectClass = TPropertyValue::ensureString($objectClass);
		
		if ($objectClass != "") 
		{
			$criteria->addAnd(ChangelogPeer::OBJECT_CLASS, $objectClass);
			$this->ObjectClassFilter->setSelectedValue($objectClass);
		}
                
		$objectId = trim($this->ObjectIdFilter->getSafeText());
		
		if ($objectId == "")
		{
			$objectId = $this->getObjectId();
		
			if (!is_null($objectId))
				$this->ObjId->setVisible(false);
		}

		$objectId = TPropertyValue::ensureString($objectId);
		
		if ($objectId != "")
			$criteria->addAnd(ChangelogPeer::OBJECT_ID, $objectId);
		
		$description = trim($this->DescriptionFilter->getSafeText());
		
		if ($description != "")
			$criteria->addAnd(ChangelogPeer::EVENT_DESCRIPTION, '%' . $description . '%', Criteria::LIKE);
                
		$userClass = trim($this->getUserClass());

		if ($userClass != '')
		{
			$criteria->addAnd(ChangelogPeer::USER_CLASS, $userClass);
			$this->UsClass->setVisible(false);
		}
			
		$userId = intval($this->getUserId());

		if ($userId > 0)
		{
			$criteria->addAnd(ChangelogPeer::USER_ID, $userId);
			$this->UsName->setVisible(false);
		}

		$dateFrom = $this->DateFrom->getSafeText() != '' ? $this->DateFrom->getTimeStamp() : null;
		$dateTo = $this->DateTo->getSafeText() != '' ? $this->DateTo->getTimeStamp() : null;

		if (!is_null($dateFrom) 
				&& ($dateFrom > 0))
			$criteria->addAnd(ChangelogPeer::EVENT_DATE, $dateFrom, Criteria::GREATER_EQUAL);
		
		if (!is_null($dateTo) 
				&& ($dateTo > 0))
			$criteria->addAnd(ChangelogPeer::EVENT_DATE, $dateTo + 86399, Criteria::LESS_EQUAL);

		if ($this->Library->getSelectedIndex() > 0)
		{
			$libraryId = $this->Library->getSelectedValue();
			
			if ($libraryId == self::LIBRARY_NULL)
			{
				$criteria->addAnd(ChangelogPeer::LIBRARY_ID, null, Criteria::ISNULL);
			}
			else
			{
				$criteria->addAnd(ChangelogPeer::LIBRARY_ID, $libraryId);
			}
		}
		
		/**
		$limitSearch = (int) $this->LimitSearchFilter->getText();
		
		if ($limitSearch > 0)
			$criteria->setLimit($limitSearch);
		 */

		$this->ChangelogGrid->resetSorting('EventDate', TClavisDataGrid::SORTDIRECTION_DESC, false);

		$this->calculateSortingCriteria($criteria);
		$this->setGlobalCriteria(clone $criteria);

		$recCount = ChangelogPeer::doCount($criteria);
		
		$criteria->setLimit($pageSize);
		$criteria->setOffset($currentIndexPage * $pageSize);
		$entries = ChangelogPeer::doSelect($criteria);
		$data = array();
		
		foreach ($entries as $entry)
			$data[] = $this->calculateDataSourceItem($entry);

		$this->writeResults($data, $recCount); //, $limitSearch);
	}

	private function writeResults($data = array(), $recCount = 0) //, $limitSearch = 0)
	{
		/*
		if (($limitSearch > 0)
				&& ($recCount >= $limitSearch))
			$recCount .= " (" . Prado::localize("limite raggiunto") . ")";
		 */

		$this->RecCounter->setText($recCount);
		$this->ChangelogGrid->setVirtualItemCount($recCount);
		$this->ChangelogGrid->setDataSource($data);
		$this->ChangelogGrid->dataBind();
	}
	
	private function calculateDataSourceItem($entry)
	{
		if (is_null($entry) 
				|| !($entry instanceof Changelog))
			return array();

		$p = array();
		$p['id'] = $entry->getEventId();
		$p['EventDate'] = $entry->getEventDate('U');
		
		$description = $entry->getEventDescription();
		$description = rtrim(chunk_split($description, 200, '<br />'), '<br />');

		$p['EventDescription'] = $description;
		$p['EventType'] = LookupValuePeer::getLookupValue('LOGACTION',  $entry->getEventType());

		$p['ObjectId'] = $entry->getObjectId();
		$p['ObjectClass'] = LookupValuePeer::getLookupValue('OBJECTCLASS', $entry->getObjectClass());

		$objectClass = $entry->getObjectClass();
		
		if ((strtolower($objectClass) != 'null')
				&& !is_null($objectClass)
				&& ($objectClass != ''))
		{
			$peerClass = $objectClass . 'Peer';
			$p['ObjectUrl'] = method_exists($peerClass, "getNavigateUrl")
									? $peerClass::getNavigateUrl() . $entry->getObjectId()
									: '';
		}
		else
		{
			$p['ObjectUrl'] = '';
		}

		$user_id = $entry->getUserId();
		$p['UserId'] = $user_id;
		$user_class = $entry->getUserClass();
		
		if ($user_class == "ClavisLibrarian")
		{
			$librarian = LibrarianQuery::create()->findPk($user_id);
			
			if ($librarian instanceof Librarian)
			{	
				$username = $librarian->getCompleteName();
				$userUrl = $librarian->getNavigateUrl() . $user_id;
			}
			else
			{
				$username = Prado::localize('Operatore sconosciuto');
				$userUrl = "";
			}
			
			$p['UserName'] = $username;
			$p['UserClass'] = Prado::localize('operatore');
			$p['UserUrl'] = $userUrl;
		}
		elseif ($user_class == "Patron")
		{
			$patron = PatronQuery::create()->findPk($user_id);
			
			if ($patron instanceof Patron)
			{
				$username = $patron->getCompleteName();
				$userUrl = $patron->getNavigateUrl(true);
			}
			else
			{
				$username = Prado::localize('Utente sconosciuto');
				$userUrl = "";
			}
			
			$p['UserName'] = $username;
			$p['UserClass'] = Prado::localize('utente');
			$p['UserUrl'] = $userUrl;
		}
		else
		{
			$p['UserName'] = Prado::localize('oggetto con id: {user_id}',
												array('user_id' => $user_id));
			
			$p['UserClass'] = $user_class;
			$p['UserUrl'] = "";
		}

		$sessionId = $entry->getSessionId();
		$ipAddress = '---';
		
		if ($user_class == "ClavisLibrarian") 
		{
			$currentLibrarianSession = LibrarianSessionPeer::retrieveByPK($sessionId);

			if ($currentLibrarianSession) 
				$ipAddress = $currentLibrarianSession->getPublicIp();
		} 
		elseif ($user_class == "Patron") 
		{
			$ipAddress = "???"; //TBD ???
		}

		$p['IpAddress'] = $ipAddress;

		$libraryLabel = "(" . Prado::localize("non presente") . ")";
		$libraryId = intval($entry->getLibraryId());
		
		if ($libraryId > 0)
		{
			$library = LibraryQuery::create()->findpk($libraryId);
			
			if ($library instanceof Library)
				$libraryLabel = $library->getLabel();
		}
		
		$p['LibraryId'] = $libraryId;
		$p['LibraryLabel'] = $libraryLabel;
		
		return $p;
	}

	public function getDataSource($limit = 0)
	{
		$savedGlobalCriteria = $this->getGlobalCriteria();
		
		if ($limit > 0)
			$savedGlobalCriteria->setLimit($limit);
			
		$entries = ChangelogPeer::doSelect($savedGlobalCriteria);
		$data = array();
		
		foreach ($entries as $entry)
			$data[] = $this->calculateDataSourceItem($entry);

		return $data;
	}

	public function getEventIds()
	{
		$globalCriteria = $this->getGlobalCriteria();
		
		if (is_null($globalCriteria))
			return array();
		
		$crit = clone($globalCriteria);
		$crit->clearSelectColumns()->addSelectColumn(ChangelogPeer::EVENT_ID);
		$entries = ChangelogPeer::doSelectStmt($crit);
		
		return $entries->fetchAll(PDO::FETCH_COLUMN,0);
	}

	public function onSearch($sender, $param) {

		$this->ChangelogGrid->SetCurrentPage(0);
		$this->populate();
	}

	public function onCancel()
	{
		$this->searchCancel(null, null);
	}

	public function searchCancel($sender, $param)
	{
		$this->Library->setSelectedIndex(-1);
		$this->ChangelogGrid->setCurrentPage(0);
		$this->EventTypeFilter->setSelectedIndex(-1);
		$this->setEventType(null);
		$this->DescriptionFilter->setText("");
		$this->ObjectClassFilter->setSelectedIndex(-1);
		$this->ObjectIdFilter->setText("");

		$this->onResetDate(null, null);

		$this->writeResults();
		$this->NoSearchPanel->setVisible(true);
	}

	public function onChangePage($sender,$param)
	{
		$this->ChangelogGrid->setCurrentPage($param->NewPageIndex);
		$this->populate();
	}

	public function getPopupFlag()
	{
		return $this->getPage()->IsPopup();
	}

	public function getUnlinkFlag()
	{
		return $this->getPage()->IsUnlink();
	}

	public function onResetDate($sender, $param)
	{
		$this->DateFrom->setText('');
 		$this->DateTo->setText('');

 		if ($this->getPage()->getIsCallback() && !is_null($param))
 			$this->DatePanel->render($param->getNewWriter());
	}
	
	public function onExportCsv($sender, $param)
	{
		ini_set('memory_limit', '768M');
		set_time_limit(0);
		
		$rawDataSource = $this->getDataSource($this->getLimitCsv());	// limiting parameter on global search already done
		
		if (count($rawDataSource) == 0)
		{
			$this->getPage()->writeMessage(Prado::localize('non ci sono dati da esportare in CSV'),
												ClavisMessage::ERROR);
			
			return false;
		}

		$csvHeaders = array(	//'id',
								'EventDate', 
								'EventDescription', 
								'EventType', 
								
								'ObjectId', 
								'ObjectClass', 
								//'ObjectUrl', 
								
								'UserId', 
								'UserName', 
								'UserClass', 
								//'UserUrl', 
								//'IpAddress', 
								
								'LibraryId', 
								'LibraryLabel' );
		
		$csvDataSource = [];

		foreach ($rawDataSource as $rawRow)
		{
			$loopElement = array(	date('Y-m-d H:i:s', $rawRow['EventDate']),
									$rawRow['EventDescription'],
									$rawRow['EventType'],
				
									$rawRow['ObjectId'],
									$rawRow['ObjectClass'],
				
									$rawRow['UserId'],
									$rawRow['UserName'],
									$rawRow['UserClass'],
				
									$rawRow['LibraryId'],
									$rawRow['LibraryLabel'] );

			$csvDataSource[] = $loopElement;
		}
		
		// csv generation
		$csvDelimiter = ',';
		$csvEnclosure = '"';
		
		$now = getdate();
		$dateSubfix = $now['year'] . "-" . $now['mon'] . "-" . $now['mday'];
				
		header('Content-Type: text/csv; charset=' . 'UTF-8');
		header('Content-Disposition: attachment; filename=changelogList' . '_' . $dateSubfix . '.csv');
		
		
		
//		$fp = fopen('php://output', 'w');
//		fputs($fp, $bom =(chr(0xEF) . chr(0xBB) . chr(0xBF)));
//		
//		fputcsv($fp, $csvHeaders, $csvDelimiter, $csvEnclosure);

//
//		foreach (array_chunk($csvDataSource, 500) as $csvDataSourceChunk)
//		{
		
		/// limit is 100.000
		ob_end_clean();

		$fp = fopen('php://output', 'w');
		fputs($fp, $bom =(chr(0xEF) . chr(0xBB) . chr(0xBF)));
		fputcsv($fp, $csvHeaders, $csvDelimiter, $csvEnclosure);

		foreach ($csvDataSource as $csvRow)
			fputcsv($fp, $csvRow, $csvDelimiter, $csvEnclosure);

		fclose($fp);
		//}		

		die();
	}
	
}