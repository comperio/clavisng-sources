<?php
/**
 * ClavisItemNoteList class file.
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 ePortal Technologies
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Widgets
 */

/**
 * ClavisItemNoteList Class
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.7
 * @package Widgets
 * @since 2.3
 */
class ClavisItemNoteList extends TTemplateControl
{
	private $_item = null;

	/**
	 * A population is performed here, in the case we load the
	 * page the first time.
	 *
	 * @param TEventParam $param
	 */
	public function onLoad($param)
	{
		parent::onLoad($param);

		$this->populate($this->getItem());
		$this->ActionsColumn->setVisible(!$this->getReadOnly());
	}

	public function setItem($item)
	{
		if (!$item instanceof Item)
			return false;

		$this->_item = $item;
		$this->setViewState('item', $item, null);
	}

	public function getItem()
	{
		$this->_item = $this->getViewState('item', null);
		return $this->_item;
	}

	public function setReadOnly($param)
	{
		$param = TPropertyValue::ensureBoolean($param);
		$this->setViewState('ReadOnly', $param, false);
	}

	public function getReadOnly()
	{
		return $this->getViewState('ReadOnly', false);
	}

	public function getItemId()
	{
		$item = $this->getItem();
		return ($item instanceof Item) ? $item->getItemId() : '';
	}

	public function onChangePageNotes($sender, $param)
	{
		$this->Notes->setCurrentPage($param->NewPageIndex);
		$this->globalRefresh();
	}

	/**
	 * Resets the datagrid's pagination (first page).

	 */
	public function resetPagination()
	{
		$this->Notes->SetCurrentPage(0);
	}

	public function globalRefresh()
	{
		$this->populate();
	}

	public function populate()
	{
		$item = $this->getItem();
		if ($item instanceof Item) 
		{
			$pageSize = $this->Notes->getPageSize();
			$currentIndexPage = $this->Notes->getCurrentPage();
			
			$noteQuery = ItemNoteQuery::create()->filterByItem($item);
			
			$total = $noteQuery->count();
			
			if ($pageSize > 0) 
			{
				$this->Notes->setVirtualItemCount($total);
				$noteQuery->limit($pageSize)->offset($currentIndexPage * $pageSize);
			}

			$this->Notes->setDataSource($noteQuery->find());
			$this->Notes->dataBind();
			$this->NotesTotal->setText($total);
		}
	}

	public function onEraseNote($sender, $param)
	{
		$note = ItemNoteQuery::create()->findPk($param->CommandParameter);
		
		try 
		{
			$note->delete();
			$this->populate();
			$this->getPage()->writeMessage(Prado::localize('Cancellata nota con id: {noteId}',
															array('noteId' => $note->getNoteId())), 
											ClavisMessage::CONFIRM);
		} 
		catch (Exception $e) 
		{
			$this->getPage()->writeMessage(Prado::localize('Errore sulla cancellazione della nota con id: {noteId}: {errmsg}',
															array(	'noteId' => $note->getNoteId(),
																	'errmsg' => $e->getMessage())), 
											ClavisMessage::ERROR);
		}
	}
}
