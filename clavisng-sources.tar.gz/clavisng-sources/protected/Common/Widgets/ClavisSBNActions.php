<?php
/**
 * ClavisSBNActions class file
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 */

/**
 * ClavisSBNActions class
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Widgets
 * @since 2.6
 */
class ClavisSBNActions extends TTemplateControl
{
	/* @var ClavisSBN */
	public $_sbnMod;
	/* @var Authority|Manifestation */
	private $_object;

	public function onLoad($param)
	{
		parent::onLoad($param);
		$this->_sbnMod = $this->getApplication()->getModule('sbn');
		if (!$this->_sbnMod instanceof TModule || !$this->_sbnMod->getEnabled())
		{
			$this->SBNNotEnabled->setVisible(true);
			$this->SBNEnabled->setVisible(false);
			return;
		}
		$this->getObject();
		if ($this->_object)
			$this->populate();
	}

	/**
	 * @return Authority|Manifestation
	 * @throws Exception
	 */
	public function getObject() {
		if (!$this->_object) {
			$control = $this;
			do
				if (method_exists($control = $control->getParent(),'getManifestation'))
					$this->_object = $control->getManifestation();
				else if (method_exists($control,'getAuthority'))
					$this->_object = $control->getAuthority();
			while (!$control instanceof TPage);
//			if (!$this->_object instanceof Manifestation
//					&& !$this->_object instanceof Authority)
//				throw new Exception('method not found');
		}
		return $this->_object;
	}

	public function isObjectPrintersDevice() {
		return $this->_object instanceof Authority && $this->_object->getAuthorityType() == AuthorityPeer::TYPE_PRINTERSDEVICE;
	}

	public function getViewMode() {
		return $this->getControlState('ViewMode','Fieldset');
	}

	public function setViewMode($value) {
		$this->setControlState('ViewMode',TPropertyValue::ensureEnum($value,array('Fieldset','Inline')));
	}

	public function completePager($sender,$param) {
		$pager = $param->Pager->getControls();
		//$pager->add(' / ' . $this->ResultGrid->getPageCount());

		$label = new TLabel();
		$label->setID('PageRowsLabel');
		$label->setText(Prado::localize('righe per pagina').' ');
		$pager->insertAt(0,$label);

		$pageSizeSelect = new TDropDownList();
		$pageSizeSelect->setID('PageRows');
		$pageSizeSelect->setAutoPostBack(true);
		foreach(array(10, 20, 50, 100) as $value) {
			$element = new TListItem();
			$element->setText($value);
			$element->setValue($value);
			$pageSizeSelect->getItems()->add($element);
		}
		if (($pageSize = $this->ResultGrid->getPageSize()) > 0)
			$pageSizeSelect->setSelectedValue($pageSize);

		$pager->insertAt(1,$pageSizeSelect);
		$pageSizeSelect->attachEventHandler('OnSelectedIndexChanged', array($this, 'onChangePageSize'));
		$pager->insertAt(2,' | ');
	}

	protected function getSBNDetail($bid, $object=null) {
		if (null == $object)
			$object = $this->_object;
		try {
			if ($object instanceof Manifestation)
				$detail = $this->_sbnMod->getNewRequest()->searchTitleByBid((string)$bid);
			else if ($object instanceof Authority)
				$detail = $this->_sbnMod->getNewRequest()->searchAuthorityByBid((string)$bid,SBNConverter::ClavisType2SBNType($object->getAuthorityType()));
			return $detail;
		} catch (Exception $e) {
			return null;
		}
	}

	public function populate()
	{
		if (!$this->_sbnMod->getEnabled() || !$this->_object || $this->_object->isNew()) {
			return;
		}

		$newBid = $this->NewSBNBID->getValue();
		if ($this->getPage()->getIsPostBack() && $newBid)
			try {
				$this->_object->setBidSource('SBN');
				$this->_object->setBid($newBid);
				$confirmmsg = Prado::localize('Oggetto correttamente collegato a indice SBN.');
				$updateSbnSync = false;
				if ($this->NewSBNLabel->getValue() == 'create' && $this->isLocalizable()) {
					list($sbnClass,$sbnType) = $this->getObjectSbnClassType();
					// since the localization is "manage", we always use default library code for the node.
					$elements = array(
						array(
							'class'	=> $sbnClass,
							'type'	=> $sbnType,
							'bid'	=> $newBid,
							'items'	=> array(array(
								'libSBNCode'		=> $this->_sbnMod->getLibraryCode(),
							))
						)
					);
					$req = $this->_sbnMod->getNewRequest();
					$sbn_response = $req->localize($elements,SBNTypes::LOCACTION_LOCALIZE,SBNTypes::LOCTYPE_MANAGE);
					$confirmmsg = Prado::localize('Oggetto correttamente collegato e localizzato in indice SBN.');
					$updateSbnSync = true;
				}
				// perform a sync on new linking
				$sbndoc = SBNConverter::SBN2Turbomarc($this->getSBNDetail((string)$newBid),true);
				$myTurbomarc = TurboMarc::createRecord($this->_object->cacheTurboMarc())->sortFields();
				$sbnTurbomarc = TurboMarcUtility::sortFields($sbndoc);
				list($newtm,$ret) = SBNConverter::getTurbomarcSBNDiff($myTurbomarc,$sbnTurbomarc);
			//	file_put_contents("/tmp/create_sbn_mydoc.xml",$myTurbomarc->asXML());
			//	file_put_contents("/tmp/create_sbn_sbndoc.xml",$sbnTurbomarc->asXML());
			//	file_put_contents("/tmp/create_sbn_newdoc.xml",$newtm->asXML());

                $lnkB = [];
				$this->_object->updateFromTurbomarc($newtm,false,$lnkB,false);
				if ($updateSbnSync)
					$this->_object->setLastSbnSync(SBNConverter::SBNTimestamp2DateTime((string)$newtm->d099->s5));
				$this->_object->save();
				$this->NewSBNBID->setValue(null);
				$this->getPage()->writeDelayedMessage($confirmmsg,ClavisMessage::CONFIRM);
				$this->getPage()->reloadPage();
			} catch (Exception $e) {
				throw $e;
			}

		switch ($this->getViewMode()) {
			case 'Inline':
				$this->InlineView->setVisible(true);
				$this->FieldsetView->setVisible(false);
				break;
			case 'Fieldset':
			default:
				$this->InlineView->setVisible(false);
				$this->FieldsetView->setVisible(true);
				break;
		}
		$lst = $this->getSbnStatus();
		$img = $this->getStatusIcon();
		$this->SBNLocStatusImg->setImageUrl($img['img']);
		$this->SBNLocStatusImg->setAlternateText($img['txt']);
		switch ($lst) {
			case 'notfound':
			case 'unlinked':
				// fieldset
				$this->SBNSyncButton->setVisible(false);
				$this->LocalizationData->setVisible(false);
				$this->NewLocalization->setVisible(false);
				$tm = $this->_object->cacheTurboMarc(true,false);
				if ($tm instanceof TurboMarc && '0' == $tm->d200['i1'] && !isset($tm->d461)) {
					$this->UpperLinkRequired->setVisible(true);
					$this->NoLocalization->setVisible(false);
				} else {
					$this->UpperLinkRequired->setVisible(false);
					$this->NoLocalization->setVisible(true);
				}
				$this->SBNSyncButton->setVisible(false);
				// inline
				$this->SBNActionSync->setVisible(false);
				$this->SBNBid->setText(Prado::localize('<em>nessuno</em>'));
				$this->SBNLocStatus->setText(Prado::localize('oggetto non collegato all\'indice <em>(modifica per collegare)</em>'));
				$this->SBNActionLocalize->setVisible(false);
				$this->SBNActionLocalizeCascade->setVisible(false);
				$this->SBNActionUnlocalize->setVisible(false);
				$this->SBNActionItemBulkLocalize->setVisible(false);
				break;
			case 'linked':
				// fieldset
				$this->SBNSyncButton->setVisible(true);
				$this->LocalizationData->setVisible(false);
				$this->NewLocalization->setVisible($this->isLocalizable());
				//inline
				$this->SBNBid->setText($this->_object->getBid());
				$this->SBNLocStatus->setText(Prado::localize('oggetto non localizzato per gestione'));
				$this->SBNActionSync->setVisible(!$this->getPage()->IsPopup()
					&& $this->isLocalizable()
					&& ($this->getUser()->getIsAdmin() || $this->getUser()->isInRole('cataloguer')));
				$this->SBNActionLocalize->setVisible($this->isLocalizable()
					&& ($this->getUser()->getIsAdmin() || $this->getUser()->isInRole('cataloguer')));
				$this->SBNActionLocalizeCascade->setVisible($this->isLocalizable()
					&& ($this->getUser()->getIsAdmin() || $this->getUser()->isInRole('cataloguer')));
				$this->SBNActionUnlocalize->setVisible(false);
				$this->SBNActionItemBulkLocalize->setVisible($this->_object instanceof Manifestation
					&& ($this->getUser()->getIsAdmin() || $this->getUser()->isInRole('cataloguer')));

                break;
			default:	// date
				// fieldset
				$this->SBNSyncButton->setVisible(true);
				$this->LocalizationData->setVisible(true);
				$this->NewLocalization->setVisible(false);
				$this->LastSbnSyncTime->setValue($lst);
				$this->OutOfSync->setVisible(isset($this->_object->getTurboMarc()->d099->s6));
				$this->ForceUpdate->setVisible(isset($this->_object->getTurboMarc()->d099->s6));
				// inline
				$this->SBNBid->setText($this->_object->getBid());
				$this->SBNLocStatus->setText(
					isset($this->_object->getTurboMarc()->d099->s6)
					? Prado::localize('oggetto localizzato per gestione ma non sincronizzato')
					: Prado::localize('oggetto localizzato per gestione - <em>ultimo aggiornamento: {date}</em>',
						array('date' => date('Y-m-d H:i:s',$lst))));
				$this->SBNActionSync->setVisible(!$this->getPage()->IsPopup() &&
					($this->getUser()->getIsAdmin() || $this->getUser()->isInRole('cataloguer')));
				$this->SBNActionLocalize->setVisible(false);
				$this->SBNActionLocalizeCascade->setVisible(false);
				$this->SBNActionUnlocalize->setVisible($this->getUser()->getIsAdmin() ||
					$this->getUser()->isInRole('cataloguer'));
				$this->SBNActionItemBulkLocalize->setVisible($this->_object instanceof Manifestation
					&& ($this->getUser()->getIsAdmin() || $this->getUser()->isInRole('cataloguer')));
		}

        $this->SBNActionItemBulkUnLocalize->setVisible($this->SBNActionItemBulkLocalize->getVisible());

		$this->SBNManCircEdit->setVisible(!$this->getPage()->IsPopup() && $this->_object instanceof Manifestation);
		$this->SBNSyncButton->setVisible($this->SBNSyncButton->getVisible() && !$this->getPage()->IsPopup());
		$this->SBNActionSync->setVisible($this->SBNActionSync->getVisible() && !$this->getPage()->IsPopup());
		if (!$this->isLocalizable())
			$this->InlineView->setVisible(false);
	}

	/**
	 * @return array
	 */
	public function getStatusIcon()
	{
		$lst = $this->getSbnStatus();
		switch ($lst) {
			case 'notfound':
			case 'unlinked':
				$img = array(
					'img'	=> 'themes/Default/icons/nav_plain_red-16.png',
					'txt'	=> Prado::localize('oggetto non collegato all\'indice'));
				break;
			case 'linked':
				$img = array(
					'img'	=> 'themes/Default/icons/nav_plain_yellow-16.png',
					'txt'	=> Prado::localize('oggetto non localizzato per gestione'));
				break;
			default:	// date
				if (isset($this->_object->getTurboMarc()->d099->s6)) {
					$img = array(
						'img'	=> 'themes/Default/icons/warning.png',
						'txt'	=> Prado::localize('oggetto localizzato ma non sincronizzato'));
				} else {
					$img = array(
						'img'	=> 'themes/Default/icons/nav_plain_green-16.png',
						'txt'	=> Prado::localize('oggetto localizzato per gestione - <em>ultimo aggiornamento: {date}</em>',
							array('date' => date('Y-m-d H:i:s',$lst))));
				}
		}
		return $img;
	}

	protected function getObjectSbnClassType() {
		if ($this->_object instanceof Manifestation) {
			$sbnClass = SBNTypes::OBJCLASS_DOC;
			$sbnType = SBNConverter::ClavisType2SBNType($this->_object->getBibType());
		} else if ($this->_object instanceof Authority) {
			$sbnClass = SBNTypes::OBJCLASS_AUT;
			$sbnType = SBNConverter::ClavisType2SBNType($this->_object->getAuthorityType());
		}
		return array($sbnClass,$sbnType);
	}

	/**
	 * Returns SBN status.
	 * Return value can be 'linked', 'unlinked', 'notfound' or a date.
	 *  * 'linked': the manifestation is linked to a BID but it's not localized.
	 *  * 'unlinked': the manifestation is unlinked to a BID but is linkable.
	 *  * 'notfound': the manifestation is unlinkable (i.e. has a non-existent BID)
	 *  * date: the manifestation is linked and localized.
	 * @param bool $deep
	 * @return mixed|string
	 */
	private function getSbnStatus($deep=false)
	{
		// ensure manifestation is valorized
		$this->getObject();
		$lst = $this->_object->getLastSbnSync('U');
		if ($lst)
			return $lst;
		$bid = $this->_object->getBid();
		if ($this->_object->getBidSource() == 'SBN' && $bid) {
			if (!$deep)
				return 'linked';
			$sbn_response = $this->getSBNDetail($bid);
			if ($sbn_response && '0000' == $sbn_response->SbnMessage->SbnResponse->SbnResult->esito) {
				// check if manifestation is already localized, if so, update LastSbnSync
				return 'linked';
			} else {
				return 'notfound';
			}
		}
		return 'unlinked';
	}

	private function isLocalizable()
	{
		$o = $this->getObject();
		if ($o instanceof Authority) {
			if ($o->getAuthorityType() == AuthorityPeer::TYPE_CLASS
					|| $o->getAuthorityType() == AuthorityPeer::TYPE_ARGUMENT)
				return false;
		}
		return true;
	}

	public function onSBNLocalizeCascade($sender,$param)
	{
		if (in_array($this->getSbnStatus(true),array('notfound','unlinked'))) {
			$this->getPage()->writeMessage(Prado::localize('L\'oggetto non è localizzabile.'),ClavisMessage::ERROR);
			$this->populate();
			return;
		}
		$bid = $this->_object->getBid();
		list($sbnClass,$sbnType) = $this->getObjectSbnClassType();
		try {
			$this->_localize($sbnClass, $sbnType, $bid);
			$message = Prado::localize('Oggetto correttamente localizzato per gestione in SBN.');
			$type = ClavisMessage::CONFIRM;
			// get the turbomarc and try to localize every linked bid
			$obj = $this->getObject();
			$tm = $obj->cacheTurboMarc(true,false);
			if ($obj instanceof Manifestation)
				$localizeLinkFunction = "_localizeManifestationLink";
			else if ($obj instanceof Authority)
				$localizeLinkFunction = "_localizeAuthorityLink";
			else
				throw new Exception("This should not happen");
			// get all nodes with a ssbn subfield
			$linkfields = $tm->xpath("//*[ssbn]");
			if ($linkfields)
				foreach($linkfields as $lf)
					try {
						$this->$localizeLinkFunction($lf);
						$message .= Prado::localize("<br/>\nLegame {bid} localizzato correttamente.",
							array('bid'=>(string)$lf->ssbn));
					} catch (Exception $ne) {
						$message .= Prado::localize("<br/>\nErrore nella localizzazione del legame [{bid}]: {sbnmessage}",
							array('bid'=>(string)$tm->ssbn,'sbnmessage'=>$ne->getMessage()));
						$type = ClavisMessage::WARNING;
					}
			$this->getPage()->writeMessage($message,$type);
		} catch (Exception $e) {
			$this->getPage()->writeMessage(Prado::localize('Errore nell\'eseguire l\'operazione: {sbnmessage}',
					array('sbnmessage' => $e->getMessage())),
				ClavisMessage::ERROR);
		}
		$this->populate();
	}

	public function onSBNLocalize($sender,$param)
	{
		if (in_array($this->getSbnStatus(true),array('notfound','unlinked'))) {
			$this->getPage()->writeMessage(Prado::localize('L\'oggetto non è localizzabile.'),ClavisMessage::ERROR);
			$this->populate();
			return;
		}
		$bid = $this->_object->getBid();
		list($sbnClass,$sbnType) = $this->getObjectSbnClassType();
		try {
			$this->_localize($sbnClass, $sbnType, $bid);
			$this->getPage()->writeMessage(Prado::localize('Oggetto correttamente localizzato per gestione in SBN.'),
				ClavisMessage::CONFIRM);
		} catch (Exception $e) {
			$this->getPage()->writeMessage(Prado::localize('Errore nell\'eseguire l\'operazione: {sbnmessage}',
					array('sbnmessage' => $e->getMessage())),
				ClavisMessage::ERROR);
		}
		$this->populate();
	}

	private function _localize($sbnClass, $sbnType, $bid, $object=null)
	{
		if (!$object)
			$object = $this->_object;
		// since the localization is "manage", we always use default library code for the node.
		$elements = array(
			array(
				'class'	=> $sbnClass,
				'type'	=> $sbnType,
				'bid'	=> $bid,
				'items'	=> array(array(
					'libSBNCode'		=> $this->_sbnMod->getLibraryCode(),
				))
			)
		);
		$req = $this->_sbnMod->getNewRequest();
		$sbn_response = $req->localize($elements,SBNTypes::LOCACTION_LOCALIZE,SBNTypes::LOCTYPE_MANAGE);
		if ('0000' == $sbn_response->SbnMessage->SbnResponse->SbnResult->esito) {
			$detail = SBNConverter::SBN2Turbomarc($this->getSBNDetail((string)$bid,$object));
			if (isset($detail->r))
				$detail = $detail->r;
			$tm = $object->getTurboMarc();
			unset($tm->d099);
			$tm->appendNode($detail->d099);
			$object->setUnimarc($tm->asXML());
			$object->setLastSbnSync(SBNConverter::SBNTimestamp2DateTime((string)$tm->d099->s5));
			// sync
			$detail = TurboMarcUtility::sortFields($detail);
			list($newtm,) = SBNConverter::getTurbomarcSBNDiff($object->getFullTurboMarc(false),$detail);
            $lnkB = [];
			$object->updateFromTurbomarc($newtm,false,$lnkB,false);
			$object->save();
			$object->reload();
			return;
		} else {
			throw new Exception($sbn_response->SbnMessage->SbnResponse->SbnResult->testoEsito);
		}
	}

 	private function _localizeManifestationLink($link)
	{
		$fnum = substr($link->getName(),1);
		if ($fnum >= 400 && $fnum < 500) {	// manifestation
			$lobj = ManifestationQuery::create()->findPk($link->s3);
			if($lobj == null) return false;
			$lobjClass = SBNTypes::OBJCLASS_DOC;
			$lobjType = SBNConverter::ClavisType2SBNType($lobj->getBibType());
		} else {	// authority
			$lobj = AuthorityQuery::create()->findPk($link->s3);
			if($lobj == null) return false;
			$lobjClass = SBNTypes::OBJCLASS_AUT;
			$lobjType = SBNConverter::ClavisType2SBNType($lobj->getAuthorityType());
		}
		return $this->_localize($lobjClass, $lobjType, (string)$link->ssbn, $lobj);
	}

	private function _localizeAuthorityLink($link)
	{
		$lobj = AuthorityQuery::create()->findPk($link->s3);
        if ($lobj == null) return;
		$lobjClass = SBNTypes::OBJCLASS_AUT;
		$lobjType = SBNConverter::ClavisType2SBNType($lobj->getAuthorityType());
		return $this->_localize($lobjClass, $lobjType, (string)$link->ssbn, $lobj);
	}

	public function onSBNUnlocalize($sender,$param)
	{
		if (in_array($this->getSbnStatus(true),array('notfound','unlinked','linked'))) {
			$this->getPage()->writeMessage(Prado::localize('Il titolo non è localizzato.'),ClavisMessage::ERROR);
			$this->populate();
			return;
		}
		$bid = $this->_object->getBid();
		list($sbnClass,$sbnType) = $this->getObjectSbnClassType();
		// since the localization is "manage", we always use default library code for the node.
		$elements = array(
			array(
				'class'	=> $sbnClass,
				'type'	=> $sbnType,
				'bid'	=> $bid,
				'items'	=> array(array(
					'libSBNCode'		=> $this->_sbnMod->getLibraryCode(),
				))
			)
		);
		$req = $this->_sbnMod->getNewRequest();
		$sbn_response = $req->localize($elements,SBNTypes::LOCACTION_UNLOCALIZE,SBNTypes::LOCTYPE_MANAGE);
		switch ($sbn_response->SbnMessage->SbnResponse->SbnResult->esito) {
			case '0000':
			case '3013':	// non-existent BID
				$tm = $this->_object->getTurboMarc();
				unset($tm->d099->s5);
				unset($tm->d099->s6);
				$this->_object->setUnimarc($tm->asXML());
				$this->_object->setLastSbnSync(null);
				$this->_object->save();
				$this->_object->reload();
				$this->getPage()->writeMessage(Prado::localize('Oggetto correttamente delocalizzato per gestione da SBN.'),
					ClavisMessage::CONFIRM);
				break;
			default:
				$this->getPage()->writeMessage(Prado::localize('Errore nell\'eseguire l\'operazione: {sbnmessage}',
						array('sbnmessage' => $sbn_response->SbnMessage->SbnResponse->SbnResult->testoEsito)),
					ClavisMessage::ERROR);
				break;
		}
		$this->populate();
	}

	public function onSBNDelete($sender,$param)
	{
		if (in_array($this->getSbnStatus(true),array('notfound','unlinked','linked'))) {
			$this->getPage()->writeMessage(Prado::localize('Il titolo non è localizzato.'),ClavisMessage::ERROR);
			$this->populate();
			return;
		}
		$bid = $this->_object->getBid();
		list($sbnClass,$sbnType) = $this->getObjectSbnClassType();
		$req = $this->_sbnMod->getNewRequest();
		$sbn_response = $req->delete($bid, $sbnClass, $sbnType);
		switch ($sbn_response->SbnMessage->SbnResponse->SbnResult->esito) {
			case '0000':
			case '3013':	// non-existent BID
				$tm = $this->_object->getTurboMarc();
				unset($tm->d099);
				$this->_object->setUnimarc($tm->asXML());
				$this->_object->setBid(null);
				$this->_object->setBidSource(null);
				$this->_object->setLastSbnSync(null);
				$this->_object->save();
				$this->_object->reload();
				$this->getPage()->writeMessage(Prado::localize('Oggetto correttamente cancellato da indice SBN.'),
					ClavisMessage::CONFIRM);
				break;
			default:
				$this->getPage()->writeMessage(Prado::localize('Errore nell\'eseguire l\'operazione: {sbnmessage}',
						array('sbnmessage' => $sbn_response->SbnMessage->SbnResponse->SbnResult->testoEsito)),
					ClavisMessage::ERROR);
				break;
		}
		$this->populate();
	}

	public function updateToSBN($force = false)
	{
		if ($this->isUnlinkable())
			// title has to be localized to update, so get out of here.
			return;

		$tm = TurboMarc::createRecord($this->_object->cacheTurboMarc());
		if (isset($tm->d901->se) && $tm->d901->se < '51') {
			// authority level is out-of-bounds
			$this->getPage()->writeMessage(Prado::localize('L\'oggetto ha un livello di catalogazione troppo basso per poter essere caricato in indice SBN. Alzare il livello di catalogazione e riprovare.'),
				ClavisMessage::WARNING);
			return;
		}
		if (isset($tm->d901->se) && $tm->d901->se > '90') {
			// authority level is out-of-bounds
			$this->getPage()->writeMessage(Prado::localize('L\'oggetto ha un livello di catalogazione troppo alto per poter essere caricato in indice SBN. Abbassare il livello di catalogazione e riprovare.'),
				ClavisMessage::WARNING);
			return;
		}
		if (isset($tm->d099->s6) && !$force) {
			// manifestation is out-of-sync, sync first!
			$this->getPage()->writeMessage(Prado::localize('L\'oggetto non è allineato, la modifica in indice non è possibile.'),
				ClavisMessage::WARNING);
			return;
		}
		$sbnMarc = SBNConverter::Turbomarc2SBN($tm);
		$req = $this->_sbnMod->getNewRequest();
		$sbn_response = $req->update($force ? SBNTypes::CREATECONTROL_CONFIRM : SBNTypes::CREATECONTROL_CHECK, $sbnMarc);
		$this->SbnFoundTitles->setVisible(false);
		if ($sbn_response) {
			switch ($sbn_response->SbnMessage->SbnResponse->SbnResult->esito) {
				case '0000':	// OK
					switch (get_class($this->_object)) {
						case 'Manifestation':
							$timestamp = (string)$sbn_response->SbnMessage->SbnResponse->SbnOutput->Documento->DatiDocumento->T005;
							$catlevel = (string)$sbn_response->SbnMessage->SbnResponse->SbnOutput->Documento->DatiDocumento['livelloAutDoc'];
							break;
						case 'Authority':
							try {
                                if(isset($sbn_response->SbnMessage->SbnResponse->SbnOutput->ElementoAut)) {
                                    $timestamp = (string)$sbn_response->SbnMessage->SbnResponse->SbnOutput->ElementoAut->DatiElementoAut->T005;
                                    $catlevel = (string)$sbn_response->SbnMessage->SbnResponse->SbnOutput->ElementoAut->DatiElementoAut['livelloAut'];
                                } else  if(isset($sbn_response->SbnMessage->SbnResponse->SbnOutput->Documento)) {
                                    $timestamp = (string)$sbn_response->SbnMessage->SbnResponse->SbnOutput->Documento->DatiDocumento->T005;
                                    $catlevel = (string)$sbn_response->SbnMessage->SbnResponse->SbnOutput->Documento->DatiDocumento['livelloAutDoc'];
                                }

							} catch (TPhpErrorException $e) {
								// try to get from Document as sometimes SBN can answer with a Documento structure
								// for Works
								$timestamp = (string)$sbn_response->SbnMessage->SbnResponse->SbnOutput->Documento->DatiDocumento->T005;
								$catlevel = (string)$sbn_response->SbnMessage->SbnResponse->SbnOutput->Documento->DatiDocumento['livelloAutDoc'];
							}
							break;
					}
					$tm = $this->_object->getTurboMarc();
					unset($tm->d099->s6);
					$tm->d099->s5 = $timestamp;
					$tm->d901->se = $catlevel;
					$this->_object->setUnimarc($tm->asXML());
					$this->_object->setLastSbnSync(SBNConverter::SBNTimestamp2DateTime($timestamp));
					$this->_object->save();
					$this->getPage()->writeMessage(Prado::localize('Oggetto correttamente aggiornato in indice SBN.'),
						ClavisMessage::CONFIRM);
					break;
				case '3090':	// no change requested
					$this->getPage()->writeMessage(Prado::localize('Nessuna modifica è stata richiesta.'),ClavisMessage::WARNING);
					break;
				case '3014':	// timestamp differs, mark manifestation
					unset($tm->d099->s6);
					$tm->d099->addSubField('6','outofsync');
					$this->_object->setUnimarc($tm->asXML());
					$this->_object->save();
					$this->getPage()->writeMessage(Prado::localize('L\'oggetto non è allineato all\'indice SBN,
							la modifica in indice non è possibile.'),ClavisMessage::WARNING);
					break;
				case '3004':	// similar found
					unset($tm->d099->s6);
					$tm->d099->addSubField('6','outofsync');
					$hits = (string)$sbn_response->SbnMessage->SbnResponse->SbnOutput['totRighe'];
					$tmCollection = SBNConverter::SBN2Turbomarc($sbn_response);
					foreach ($tmCollection->children() as $r)
						if ($rec = $this->parseTurbomarc($r))
							$resultSet[] = $rec;
					$this->ResultOverflow->setVisible((int)$sbn_response->SbnMessage->SbnResponse->SbnOutput['totRighe'] > (int)$sbn_response->SbnMessage->SbnResponse->SbnOutput['maxRighe']);
					$this->ResultGrid->setDataSource($resultSet);
					$this->ResultGrid->dataBind();
					$this->ResultNumLabel->Parameters->results = $hits;
					$this->SbnFoundTitles->setVisible(true);
					$this->_object->setUnimarc($tm->asXML());
					$this->_object->save();
					$this->getPage()->writeMessage(Prado::localize('Aggiornamento in indice SBN fallito: {sbnmessage}',
						array('sbnmessage' => $sbn_response->SbnMessage->SbnResponse->SbnResult->testoEsito)),ClavisMessage::WARNING);
					break;
				default:
                    $tm = $this->_object->getTurboMarc();
					unset($tm->d099->s6);
					$tm->d099->addSubField('6','outofsync');
					$this->_object->setUnimarc($tm->asXML());
					$this->_object->save();
					 file_put_contents("/tmp/force_sbn_doc.xml",$tm->asXML());
                                        file_put_contents("/tmp/force_sbn_request.xml",$sbnMarc->asXML());
                                        file_put_contents("/tmp/force_sbn_response.xml",$sbn_response->asXML());
					$this->getPage()->writeMessage(Prado::localize('(1)Errore nell\'aggiornamento in indice SBN: {sbnmessage}',
							array('sbnmessage' => $sbn_response->SbnMessage->SbnResponse->SbnResult->testoEsito)),
						ClavisMessage::WARNING);
					break;
			}
		} else {
			$this->getPage()->writeMessage(Prado::localize('Nessuna risposta da indice SBN.'),
				ClavisMessage::WARNING);
		}
		$this->populate();
	}

	/**
	 * This function has been implemented to manage nature change in documents.
	 * Since it's not currently allowed, this code is not being called from anywhere but
	 * it's still there to ease future implementations.
	 *
	 * @param SBNMarc $sbnMarc
	 * @return SBNMarc
	 */
	private function createAndMerge(SBNMarc $sbnMarc)
	{
		$node = $this->_sbnMod->getNodePrefix();
		$req = $this->_sbnMod->getNewRequest();
		list($objClass, $objType) = $this->getObjectSbnClassType();
		if ($this->_object instanceof Manifestation)
		{
			$node .= SBNConverter::ClavisType2SBNIdPrefix($this->_object->getBibType());
			$cntparam = ClavisParamQuery::create()->filterByParamClass('SBNCOUNTER')->filterByParamName($node)->findOneOrCreate();
			$counter = intval($cntparam->getParamValue()) + 1;
			$bid = $node.str_pad($counter,10-strlen($node),0,STR_PAD_LEFT);
			$old_record = $this->_sbnMod->getNewRequest()->searchTitleByBid($sbnMarc->DatiDocumento->T001, SBNTypes::OUTPUT_COMPLETELOC);
			if (!isset($old_record->SbnMessage->SbnResponse->SbnResult->esito) || '0000' != $old_record->SbnMessage->SbnResponse->SbnResult->esito) {
				$this->getPage()->writeMessage(Prado::localize('Impossibile trovare il record originale in indice SBN'),
					ClavisMessage::ERROR);
				return;
			}
			$srcBid = (string)$old_record->SbnMessage->SbnResponse->SbnOutput->Documento->DatiDocumento->T001;
			if (count($old_record->SbnMessage->SbnResponse->SbnOutput->Documento->LegamiDocumento) > 0) {
				$sbnMarc->addChild('LegamiDocumento')->addChild('idPartenza',$bid);
				foreach ($old_record->SbnMessage->SbnResponse->SbnOutput->Documento->LegamiDocumento as $l) {
					$linknode = $sbnMarc->LegamiDocumento->addChild('ArrivoLegame');

				}
			}

		}
		else if ($this->_object instanceof Authority)
		{
			$node .= SBNConverter::ClavisType2SBNIdPrefix($this->_object->getAuthorityType());
			$cntparam = ClavisParamQuery::create()->filterByParamClass('SBNCOUNTER')->filterByParamName($node)->findOneOrCreate();
			$counter = intval($cntparam->getParamValue()) + 1;
			$bid = $node.str_pad($counter,10-strlen($node),0,STR_PAD_LEFT);
			$old_record = $this->_sbnMod->getNewRequest()->searchAuthorityByBid($sbnMarc->DatiElementoAut->T001, $objType);
			if (!isset($old_record->SbnMessage->SbnResponse->SbnResult->esito) || '0000' != $old_record->SbnMessage->SbnResponse->SbnResult->esito) {
				$this->getPage()->writeMessage(Prado::localize('Impossibile trovare il record originale in indice SBN'),
					ClavisMessage::ERROR);
				return;
			}
			$srcBid = (string)$old_record->SbnMessage->SbnResponse->SbnOutput->ElementoAut->DatiElementoAut->T001;
			foreach ($old_record->SbnMessage->SbnResponse->SbnOutput->ElementoAut->LegamiElementoAut as $l)
				$sbnMarc->appendNode($l);
			if (isset($sbnMarc->LegamiElementoAut->idPartenza))
				$sbnMarc->LegamiElementoAut->idPartenza = $bid;
		}
		$sbn_response = $req->create(SBNTypes::CREATECONTROL_CONFIRM, $objClass, $sbnMarc, $bid);
		if (!$sbn_response instanceof SBNMarc) {
			$this->getPage()->writeMessage(Prado::localize('Nessuna risposta da indice SBN.'),
				ClavisMessage::ERROR);
			return;
		}
		switch ($sbn_response->SbnMessage->SbnResponse->SbnResult->esito) {
			case '0000':	// correctly created
				if (isset($cntparam))
					$cntparam->setParamValue($counter)->save();
				// then merge
				switch ($objClass) {
					case SBNTypes::OBJCLASS_DOC:
						$bid = (string)$sbn_response->SbnMessage->SbnResponse->SbnOutput->Documento->DatiDocumento->T001;
						$ts = (string)$sbn_response->SbnMessage->SbnResponse->SbnOutput->Documento->DatiDocumento->T005;
						break;
					case SBNTypes::OBJCLASS_AUT:
						$bid = (string)$sbn_response->SbnMessage->SbnResponse->SbnOutput->ElementoAut->DatiElementoAut->T001;
						$ts = (string)$sbn_response->SbnMessage->SbnResponse->SbnOutput->ElementoAut->DatiElementoAut->T005;
						break;
				}
				$sbn_response = $this->_sbnMod->getNewRequest()->merge($srcBid, $bid, $objClass, $objType);
				switch ($sbn_response->SbnMessage->SbnResponse->SbnResult->esito) {
					case '0000':	// correctly merged
						$tm = $this->_object->getTurboMarc();
						$d099 = isset($tm->d099) ? $tm->d099 : $tm->addField('099');
						$d099->addSubField('a',$bid);
						$d099->addSubField('5',$ts);
						$this->_object->setUnimarc($tm->asXML());
						$this->_object->save();
						break;
					default:	// no merge, delete the newly created
						$this->getPage()->writeMessage(Prado::localize('Errore nella fusione: {message}.',
							array('message' => (string)$sbn_response->SbnMessage->SbnResponse->SbnResult->testoEsito)),
							ClavisMessage::ERROR);
						$this->_sbnMod->getNewRequest()->delete($bid);
						break;
				}
				break;
			case '3012':	// already existing BID
			case '3126':	// already existing and deleted BID
				$cntparam->setParamValue($counter)->save();
				if (++$this->retries > self::MAX_RETRIES) {
					$this->getPage()->writeMessage(Prado::localize('Rilevato ID duplicato per troppi tentativi, si prega di riprovare più tardi.'), ClavisMessage::ERROR);
					return;
				}
				$this->createAndMerge($sbnMarc);
				break;
			default:
				$this->getPage()->writeMessage((string)$sbn_response->SbnMessage->SbnResponse->SbnResult->testoEsito,
					ClavisMessage::ERROR);
				break;
		}
		return $sbn_response;
	}

	/**
	 * @param string $action
	 * @param LAuthorityManifestation|LAuthority|LManifestation $link
	 */
	public function updateLinkToSBN($action,$link)
	{
		$_sbnLinkTranslation = array(419=>410,421=>422,441=>431,444=>434,455=>451);

		if ($this->isUnlinkable())
			// title has to be localized to update, so get out of here.
			return;

		$tm = $this->_object->cacheTurboMarc(true, false);
		$lt = $link->getLinkType();
		switch (get_class($link)) {
			case 'LAuthorityManifestation':
				$tm = $link->getManifestation()->cacheTurboMarc(true, false);
				$lid = $link->getAuthorityId();
				$rc = $link->getRelatorCode();
				if ('7'==substr($lt,0,1)) {
					switch ($link->getAuthority()->getAuthorityType()) {
						case AuthorityPeer::TYPE_FAMILYNAME:
							$lt += 10; // only 10 cause it's cascading on the following 10 (actually makes 20)
						case AuthorityPeer::TYPE_CORPORATEBODYNAME:
							$lt += 10;
					}
				}
				$worktm = clone $tm;
				for ($i=400; $i<800; ++$i) {
					$tag = "d{$i}";
					unset($worktm->$tag);
				}
				unset($worktm->d921);
				break;
			case 'LAuthority':
				$myId = (string)$tm->c001;
				if ($link->getAuthorityIdDown() == $myId) {
					$lid = $link->getAuthorityIdUp();
					$lauth = $link->getAuthorityRelatedByAuthorityIdUp();
					$inverse = false;
				} else {
					$lid = $link->getAuthorityIdDown();
					$lauth = $link->getAuthorityRelatedByAuthorityIdDown();
					$inverse = true;
				}
				if ($lt[0] > $lt[1]) {
					$lt = strrev($lt);
					$inverse = !$inverse;
				}
				switch ($lt)
				{
					case 'KL':
						if (AuthorityPeer::TYPE_CLASS == (string)$tm->d901->sm)
							$lt = 976;
						else
							$lt = $lauth->getClass();
						break;
					case 'AB':	// Main author
						$lt = 970;
						break;
					case 'CD':	// Alternative author
						$lt = 971;
						break;
					case 'EF':	// Secondary author
						$lt = 972;
						break;
					case 'GH':	// Subject
						$lt = 968;
						break;
					case 'IJ':	// Fictional subject
						$lt = 969;
						break;
					case 'MN':	// Place
						$lt = 961;
						break;
					case 'OP':	// Publishing place
						$lt = 960;
						break;
					case 'QR':	// Serie
						$lt = 962;
						break;
					case '23':	// BT (broader term) or NT (narrower term)
						$flnk = $inverse ? '965' : '966';
						break;
					case '11':	// RT (see also)
					case '45':	// USE
					case '67':	// USE+
						$lt = 490;
						break;
				}
				$rc = $link->getRelatorCode();
				$worktm = clone $tm;
				unset($worktm->d490);
				if (AuthorityPeer::TYPE_CLASS != $tm->d901->sm) {
					unset($worktm->d676);
					unset($worktm->d680);
					unset($worktm->d686);
				}
				for ($i=960; $i<980; ++$i) {
					$tag = "d{$i}";
					unset($worktm->$tag);
				}
				break;
			case 'LManifestation':
				$myId = (string)$tm->c001;
				if ($link->getManifestationIdDown() == $myId) {
					$lid = $link->getManifestationIdUp();
					$lt = TurboMarcMappings::$reverseLinkType[$lt];
				} else {
					$lid = $link->getManifestationIdDown();
				}
				if (isset($_sbnLinkTranslation[$lt])) {
					$srcfld = 'd'.$lt;
					$lt = $_sbnLinkTranslation[$lt];
					$revfld = 'd'.$lt;
					if (isset($tm->$srcfld))
						$tm = TurboMarc::createRecord(str_replace($srcfld,$revfld,$tm->asXML()));
				}
				$rc = null;
				$worktm = clone $tm;
				for ($i=400; $i<800; ++$i) {
					$tag = "d{$i}";
					unset($worktm->$tag);
				}
				unset($worktm->d921);
				break;
			default:
				$this->getPage()->writeMessage('Il caricamento di questo tipo di legame non è ancora stato implementato.', ClavisMessage::ERROR);
				return;
		}
		$linkfields = $tm->xpath("//d{$lt}[s3 = \"{$lid}\"]");
		if ($rc && $rc != '000') {
			// check against relator code
			for ($i=(count($linkfields)-1); $i>=0; --$i) {
				if (!isset($linkfields[$i]->s4) || $rc != (string)$linkfields[$i]->s4) {
					unset($linkfields[$i]);
				}
			}
		}
		if (count($linkfields) == 0) {
			return;
		}
		$tmpfld = clone $linkfields[0];
		$worktm->appendNode($tmpfld);
		$actionMap = array('Create'=>SBNTypes::LINKACTION_CREATE,
			'Update'=>SBNTypes::LINKACTION_UPDATE,
			'Delete'=>SBNTypes::LINKACTION_DELETE);
		$sbnMarc = SBNConverter::TurbomarcLink2SBN($worktm);
		$sbn_response = $this->_sbnMod->getNewRequest()->updateLink($actionMap[$action],$sbnMarc);
		if ($sbn_response)
		{
			switch ($sbn_response->SbnMessage->SbnResponse->SbnResult->esito) {
				case '0000':	// OK
					switch (get_class($this->_object)) {
						case 'Manifestation':
							$timestamp = (string)$sbn_response->SbnMessage->SbnResponse->SbnOutput->Documento->DatiDocumento->T005;
							$catlevel = (string)$sbn_response->SbnMessage->SbnResponse->SbnOutput->Documento->DatiDocumento['livelloAutDoc'];
							break;
						case 'Authority':
							$timestamp = (string)$sbn_response->SbnMessage->SbnResponse->SbnOutput->Documento->DatiDocumento->T005;
							$catlevel = (string)$sbn_response->SbnMessage->SbnResponse->SbnOutput->Documento->DatiDocumento['livelloAutDoc'];
							break;
					}
					$realtm = $this->_object->getTurboMarc();
					unset($realtm->d099->s6);
					$realtm->d099->s5 = $timestamp;
					$realtm->d901->se = $catlevel;
					$this->_object->setUnimarc($realtm->asXML());
					$this->_object->setLastSbnSync(SBNConverter::SBNTimestamp2DateTime($timestamp));
					$this->_object->save();
					$link->setSourceSync('Delete' == $action
						? LAuthorityManifestationPeer::SRCSYNC_FALSE
						: LAuthorityManifestationPeer::SRCSYNC_TRUE);
					$link->save();
					$this->getPage()->writeMessage(Prado::localize('Oggetto correttamente aggiornato in indice SBN.'),
						ClavisMessage::CONFIRM);
					break;
				case '3029':	// missing link upon deletion, it's ok anyway
					$link->setSourceSync(LAuthorityManifestationPeer::SRCSYNC_FALSE);
					$link->save();
					break;
				case '3030':	// already existing link upon creation, it's ok anyway
					$link->setSourceSync(LAuthorityManifestationPeer::SRCSYNC_TRUE);
					$link->save();
					break;
				case '3090':	// no change requested
					$this->getPage()->writeMessage(Prado::localize('Nessuna modifica è stata richiesta.'),ClavisMessage::WARNING);
					break;
				case '3014':	// timestamp differs, mark manifestation
					$realtm = $this->_object->getTurboMarc();
					unset($realtm->d099->s6);
					$realtm->d099->addSubField('6','outofsync');
					$this->_object->setUnimarc($realtm->asXML());
					$this->_object->save();
					$this->getPage()->writeMessage(Prado::localize('L\'oggetto non è allineato all\'indice SBN,
							la modifica in indice non è possibile.'),ClavisMessage::WARNING);
					break;
				default:
					// on no action, leave everything as it is
					/*unset($tm->d099->s6);
					$tm->d099->addSubField('6','outofsync');
					$this->_object->setUnimarc($tm->asXML());
					$this->_object->save();*/
					file_put_contents("/tmp/sbn_doc.xml",$worktm->asXML());
					file_put_contents("/tmp/sbn_request.xml",$sbnMarc->asXML());
					file_put_contents("/tmp/sbn_response.xml",$sbn_response->asXML());
					$this->getPage()->writeMessage(Prado::localize('(2)Errore nell\'aggiornamento in indice SBN: {sbnmessage}',
							array('sbnmessage' => $sbn_response->SbnMessage->SbnResponse->SbnResult->testoEsito)),
						ClavisMessage::WARNING);
					break;
			}
		} else {
			$this->getPage()->writeMessage(Prado::localize('SBN è momentaneamente non raggiungibile, si prega di riprovare più tardi.'), ClavisMessage::WARNING);
		}
	}

	public function isUnlinkable()
	{
		return in_array($this->getSbnStatus(true),array('notfound','unlinked','linked'));
	}

	public function onSBNItemBulkLocalize($sender,$param)
	{

		$locstatus = $this->_sbnMod->getBulkLocalizeItemStatus();
		$item_ids = $itemlist = array();
		foreach ($this->_object->getItems() as $item) {
			/* @var $item Item */
			if ($item->getLastSbnSync() != null)	// skip already localized items
				continue;
			if (!in_array($item->getItemStatus(),$locstatus))	// skip items not in SBN localizable status
				continue;
			$l = $item->getHomeLibrary();
			if (!$l->getSbnCode())	// skip items for libraries that doesn't have a SBN code.
				continue;
			$itemlist[] = array(
				'libName'			=> $l->getLabel(),
	//			'libAnagraphicCode'	=> $l->getIllCode(),
				'libSBNCode'		=> $this->_sbnMod->getLibraryCode($l));
			$item_ids[] = $item->getItemId();
			if (count($item_ids) > 100) // send max 100 items
				break;
		}
		if (count($itemlist) < 1) {
			$this->getPage()->writeMessage(Prado::localize('Nessun esemplare è localizzabile (controllare biblioteche senza codice SBN)'),
				ClavisMessage::ERROR);
		} else {
			$bid = $this->_object->getBid();
			$elements = array(
				array(
					'class'	=> SBNTypes::OBJCLASS_DOC,
					'type'	=> SBNConverter::ClavisType2SBNType($this->_object->getBibType()),
					'bid'	=> $bid,
					'items'	=> $itemlist,
				)
			);
			$req = $this->_sbnMod->getNewRequest();

            if($this->_object->getLastSbnSync('U') != null)
                $sbn_response = $req->localize($elements,SBNTypes::LOCACTION_LOCALIZE,SBNTypes::LOCTYPE_ALL);
            else
			    $sbn_response = $req->localize($elements,SBNTypes::LOCACTION_LOCALIZE,SBNTypes::LOCTYPE_OWN);

			if ('0000' == $sbn_response->SbnMessage->SbnResponse->SbnResult->esito) {
				ItemQuery::create()
					->filterByManifestation($this->_object)
					->filterByItemId($item_ids)
					->update(array('LastSbnSync' => time()));
				$this->getPage()->writeMessage(Prado::localize('{count} esemplari correttamente localizzati per possesso in SBN.',
						array('count'=>count($item_ids))),
					ClavisMessage::CONFIRM);
			} else {
				$this->getPage()->writeMessage(Prado::localize('Errore nell\'eseguire l\'operazione: {sbnmessage}',
						array('sbnmessage' => $sbn_response->SbnMessage->SbnResponse->SbnResult->testoEsito)),
					ClavisMessage::ERROR);
			}
		}
		$this->getPage()->reloadPage();
	}

    public function onSBNItemBulkUnLocalize($sender,$param)
    {

        $item_ids = $itemlist = array();
        foreach ($this->_object->getItems() as $item) {
            /* @var $item Item */
            if ($item->getLastSbnSync() == null)	// skip already unlocalized items
                continue;

            $l = $item->getHomeLibrary();
            if (!$l->getSbnCode())	// skip items for libraries that doesn't have a SBN code.
                continue;
            $itemlist[] = array(
                'libName'			=> $l->getLabel(),
                //			'libAnagraphicCode'	=> $l->getIllCode(),
                'libSBNCode'		=> $this->_sbnMod->getLibraryCode($l));
            $item_ids[] = $item->getItemId();
            if (count($item_ids) > 100) // send max 100 items
                break;
        }
        if (count($itemlist) < 1) {
            $this->getPage()->writeMessage(Prado::localize('Nessun esemplare è delocalizzabile (controllare biblioteche senza codice SBN)'),
                ClavisMessage::ERROR);
        } else {
            $bid = $this->_object->getBid();
            $elements = array(
                array(
                    'class'	=> SBNTypes::OBJCLASS_DOC,
                    'type'	=> SBNConverter::ClavisType2SBNType($this->_object->getBibType()),
                    'bid'	=> $bid,
                    'items'	=> $itemlist,
                )
            );
            $req = $this->_sbnMod->getNewRequest();

            if($this->_object->getLastSbnSync('U') != null)
                $sbn_response = $req->localize($elements,SBNTypes::LOCACTION_UNLOCALIZE,SBNTypes::LOCTYPE_OWN);
            else
                $sbn_response = $req->localize($elements,SBNTypes::LOCACTION_UNLOCALIZE,SBNTypes::LOCTYPE_ALL);

            switch($sbn_response->SbnMessage->SbnResponse->SbnResult->esito) {
                case '0000':
                case '3013':
                    ItemQuery::create()
                        ->filterByManifestation($this->_object)
                        ->update(array('LastSbnSync' => null));
                   // $this->_item->reload();
                    $this->getPage()->writeMessage(Prado::localize('Esemplari correttamente delocalizzato per possesso da SBN.'),
                        ClavisMessage::CONFIRM);
                default:
                    $this->getPage()->writeMessage(Prado::localize('Errore nell\'eseguire l\'operazione: {sbnmessage}',
                        array('sbnmessage' => $sbn_response->SbnMessage->SbnResponse->SbnResult->testoEsito)),
                        ClavisMessage::ERROR);
            }
        }
        $this->getPage()->reloadPage();
    }

	public function ImportPrintersDeviceImage($sender,$param) {
		$req = $this->_sbnMod->getNewRequest();
		$images = $req->getPrintersDeviceImages($this->_object->getBid());
		foreach ($images as $label => $img) {
			// search already imported attachments
			$tmpdir = Prado::getPathOfNamespace('Storage.temp');
			$tmpfile = tempnam($tmpdir,'printersdevice_');
			file_put_contents($tmpfile,base64_decode($img));
			$a = AttachmentQuery::create()
				->filterByObjectType('Authority')
				->filterByObjectId($this->_object->getAuthorityId())
				->filterByFileLabel($label)
				->findOneOrCreate();
			$a->setAttachmentType(AttachmentPeer::TYPE_IMAGE)
				->setFileSize(filesize($tmpfile))
				->setFileDescription($label)
				->setLicense('A')
				->storeFile($tmpfile,"sbn_{$label}.jpg");
			$this->getPage()->writeMessage(Prado::localize("Immagine [{$label}] correttamente importata."),
				ClavisMessage::CONFIRM);
		}
		if (!count($images))
			$this->getPage()->writeMessage(Prado::localize('Nessuna immagine disponibile nell\'indice SBN'),
				ClavisMessage::ERROR);
		$this->getPage()->reloadPage();
	}

	private function parseTurbomarc(TurboMarc $tm) {
		$ret = array('Id' => 0, 'Turbomarc' => $tm->asXML());
		switch (get_class($this->_object)) {
			case 'Manifestation':
				return $this->parseTurbomarcManifestation($tm);
			case 'Authority':
				return $this->parseTurbomarcAuthority($tm);
		}
	}

	private function parseTurbomarcManifestation(TurboMarc $tm) {
		$ret = array('Id' => 0, 'ClavisId' => 0, 'Turbomarc' => $tm->asXML(), 'InCatalog' => false);
		$l = $tm->getLeader();
		// the following is to avoid errors with SBN - TEMP!!!
		if (! $l instanceof TurboMarcLeader)
			return null;
		$our_record_id = ManifestationPeer::bidExists((string)$tm->d035->s9,(string)$tm->d035->sa);
		if ($our_record_id) {
			$ret['ClavisId'] = $ret['Id'] = $our_record_id;
			$ret['InCatalog'] = true;
		}
		$ret['Bid'] = (string)$tm->d099->sa;
		$ret['Text'] = '';
		if ($v = $tm->getAuthor())
			$ret['Text'] .= $v.'<br/>';
		$ret['Text'] .= '<strong>'.trim($tm->getFullTitle()).'</strong>';
		if ($tm->getEAN())
			$ret['Text'] .= '<br/>'.$tm->getEAN();
		if ($v = implode(' - ',$tm->getEditions()))
			$ret['Text'] .= '<br/>'.$v;
		if ($v = implode(' - ',$tm->getPublications()))
			$ret['Text'] .= '<br/>'.$v;
        if ($v = implode(' - ',$tm->getPhysicalDescs()))
            $ret['Text'] .= '<br/>'.$v;
        if ($v = implode(' - ',$tm->getSeries()))
			$ret['Text'] .= '<br/>'.$v;
		if (isset($tm->d461))
			$ret['Text'] .= '<br/><em>'.Prado::localize('Fa parte di: ')."</em> {$tm->d461->st} [{$tm->d461->s1}]";
		if ($v = $tm->getDewey())
			$ret['Text'] .= '<br/><em>'.Prado::localize('Classe: ').'</em>'.$v;
		if ($v = implode(' - ',$tm->getSubjects()))
			$ret['Text'] .= '<br/><em>'.Prado::localize('Soggetti: ').'</em>'.$v;
		return $ret;
	}

	private function parseTurbomarcAuthority(TurboMarc $tm) {
		$ret = array('Id' => 0, 'ClavisId' => 0, 'InCatalog' => false);
		$l = $tm->getLeader();
		$our_auth_id = AuthorityPeer::bidExists((string)$tm->d035->s9,(string)$tm->d035->sa);
		if ($our_auth_id) {
			$ret['ClavisId'] = $ret['Id'] = $our_auth_id;
			$ret['InCatalog'] = true;
		}
		$ret['Bid'] = (string)$tm->d099->sa;
		$ret['AuthType'] = (string)$tm->d099->sd;
		$ret['Text'] = '';
		if ($v = $tm->getAuthor())
			$ret['Text'] .= $v.'<br/>';

		switch ((string)$tm->d099->sd) {
			case SBNTypes::AUTTYPE_AUTORE:
				if (isset($tm->d200)) {	// AutPersonaleType
					$ret['Text'] .= $tm->getAuthor(200);
				} else if (isset($tm->d210)) {	// EnteType
					$ret['Text'] .= $tm->getAuthor(210);
				}
				break;
			case SBNTypes::AUTTYPE_TITOLO_UNIFORME:
			case SBNTypes::AUTTYPE_TITOLO_UNIFORME_MUSICA:
				$ret['Text'] .= (string)$tm->d230->sa;
				break;
			case SBNTypes::AUTTYPE_SOGGETTO:
				$ret['Text'] .= "[{$tm->d250->s2}] ".(string)$tm->d250->sa;
				if (isset($tm->d250->sx))
					$ret['Text'] .= ' - '.implode(' - ',$tm->d250->sx);
				break;
			case SBNTypes::AUTTYPE_DESCRITTORE:
				$ret['Text'] .= "[{$tm->d931->s2}] {$tm->d931->sa}";
				break;
			case SBNTypes::AUTTYPE_LUOGO:
				$ret['Text'] .= (string)$tm->d260->sd;
				break;
			case SBNTypes::AUTTYPE_CLASSE:
				$ret['Text'] .= (isset($tm->d676)) ?
					"[{$tm->d676->sv}] {$tm->d676->sa} {$tm->d676->sc}" :
					"[{$tm->d686->s2}] {$tm->d686->sa} {$tm->d686->s2}" ;
				break;
			case SBNTypes::AUTTYPE_MARCA:
				$ret['Text'] .= (string)$tm->d921->sa;
				break;
			case SBNTypes::AUTTYPE_REPERTORIO:
				$ret['Text'] .= "[{$tm->d930->s2}] {$tm->d930->sa}";
				break;
		}
		$ret['Text'] = '<strong>'.htmlentities($ret['Text'],ENT_QUOTES,'UTF-8').'</strong>';
		return $ret;
	}

	public function forceUpdateToSBN($sender, $param)
	{
		$this->updateToSBN(true);
	}

	public function resultAction($sender,$param)
	{
		switch ($param->getCommandName()) {
			case 'merge':
				$sbnMarc = SBNConverter::Turbomarc2SBN(TurboMarc::createRecord($this->_object->cacheTurboMarc()));
				// force record update to match the I. D.
				$this->_sbnMod->getNewRequest()->update(SBNTypes::CREATECONTROL_CONFIRM,$sbnMarc);
				$sourceBid = $this->_object->getBid();
				$targetBid = $param->getCommandParameter();
				list($sbnClass,$sbnType) = $this->getObjectSbnClassType();
				$sbn_response = $this->_sbnMod->getNewRequest()->merge($sourceBid,$targetBid,$sbnClass,$sbnType);
				switch ($sbn_response->SbnMessage->SbnResponse->SbnResult->esito) {
					case '0000':	// OK
						if (SBNTypes::OBJCLASS_AUT == $sbnClass) {
							$target = AuthorityPeer::getOneByBid('SBN', $targetBid);
							if ($target instanceof Authority) {
								if ($this->_object->replaceWith($target, $this->getUser())) {
									$this->getPage()->writeMessage(Prado::localize('Il record in catalogo è stato schiacciato e fuso in Indice SBN.'),ClavisMessage::CONFIRM);
									$this->getPage()->gotoPage('Catalog.AuthorityViewPage', array('id' => $target->getAuthorityId()));
								} else {
									$this->getPage()->writeMessage(Prado::localize('La fusione in indice è avvenuta con successo ma il record in catalogo NON è stato schiacciato.'),
										ClavisMessage::WARNING);
								}
							}
						} else if (SBNTypes::OBJCLASS_DOC == $sbnClass) {
							$target = ManifestationPeer::getOneByBid('SBN', $targetBid);
							if ($target instanceof Manifestation) {
								if ($this->_object->replaceWith($target, $this->getUser())) {
									$this->getPage()->writeMessage(Prado::localize('Il record in catalogo è stato schiacciato e fuso in Indice SBN.'),ClavisMessage::CONFIRM);
									$this->getPage()->gotoPage('Catalog.Record', array('manifestationId' => $target->getManifestationId()));
								} else {
									$this->getPage()->writeMessage(Prado::localize('La fusione in indice è avvenuta con successo ma il record in catalogo NON è stato schiacciato.'),
										ClavisMessage::WARNING);
								}
							}
						}
						$this->NewSBNBID->setValue($targetBid);
						$this->populate();
						$this->getPage()->writeMessage(Prado::localize('Fusione completata con successo'),
							ClavisMessage::CONFIRM);
						break;
					default:
						$this->getPage()->writeMessage(Prado::localize('Errore di fusione in indice SBN: {sbnmessage}',
								array('sbnmessage' => $sbn_response->SbnMessage->SbnResponse->SbnResult->testoEsito)),
							ClavisMessage::WARNING);
						break;
				}
				return;
		}
	}
}
