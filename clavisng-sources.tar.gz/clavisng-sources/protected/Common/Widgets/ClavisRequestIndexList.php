<?php

/**
 * ClavisRequestIndexList
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2008 Comperio srl
 * @version 2.7
 * @package Widgets
 * @since 2.3
 */

class ClavisRequestIndexList extends TTemplateControl {

	public function onLoad($param) {
		parent::onLoad($param);
		if (!$this->getPage()->getIsPostBack()) {
			$this->populate();
		}
	}

	public function populate() {
		$pageSize = $this->IndexGrid->getPageSize();
		$currentIndexPage = $this->IndexGrid->getCurrentPage();
		$data = ManifestationPeer::getRequestIndex();
		$recCount = count($data);
		$data = array_slice($data, $pageSize * $currentIndexPage, $pageSize);
		if ($pageSize > 0)
			$this->IndexGrid->setVirtualItemCount($recCount);
		$this->IndexGrid->setDataSource($data);
		$this->IndexGrid->dataBind();
		$this->RecCounter->setText(Prado::localize('Totale: {count}',array('count'=>$recCount)));
	}

	public function onChangePage($sender, $param)
	{
		$this->IndexGrid->setCurrentPage($param->NewPageIndex);
		$this->populate();
	}
}
