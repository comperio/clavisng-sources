<?php
/**
 * ClavisSBNLinkColumn class file
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 */

/**
 * TDataGridColumn class file
 */
Prado::using('System.Web.UI.WebControls.TDataGridColumn');

/**
 * ClavisSBNLinkColumn class
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Widgets
 * @since 2.6
 */
class ClavisSBNLinkColumn extends TDataGridColumn
{

	/* @var ClavisSBN */
	public $_sbnMod;
	/* @var Authority|Manifestation */
	private $_object;
	private $_managedLinkTypes = array(410,419,422,421,430,431,441,434,444,440,447,451,461,463,464);

	public function onLoad($param)
	{
		parent::onLoad($param);
		$this->_sbnMod = $this->getApplication()->getModule('sbn');
		if (!$this->_sbnMod instanceof TModule || !$this->_sbnMod->getEnabled())
		{
			$this->setVisible(false);
			return;
		}
		$this->getObject();
		if (!$this->getObject() || !$this->isObjectLinkable()) {
			$this->setVisible(false);
			return;
		}
	}

	/**
	 * @return Authority|Manifestation
	 * @throws Exception
	 */
	public function getObject() {
		if (!$this->_object) {
			$control = $this;
			do
				if (method_exists($control = $control->getParent(),'getManifestation'))
					$this->_object = $control->getManifestation();
				else if (method_exists($control,'getAuthority'))
					$this->_object = $control->getAuthority();
			while (!$control instanceof TPage);
			//			if (!$this->_object instanceof Manifestation
			//					&& !$this->_object instanceof Authority)
			//				throw new Exception('method not found');
		}
		return $this->_object;
	}

	/**
	 * Returns SBN status.
	 * Return value can be 'linked', 'unlinked', 'notfound' or a date.
	 *  * 'linked': the manifestation is linked to a BID but it's not localized.
	 *  * 'unlinked': the manifestation is unlinked to a BID but is linkable.
	 *  * 'notfound': the manifestation is unlinkable (i.e. has a non-existent BID)
	 *  * date: the manifestation is linked and localized.
	 * @return mixed|string
	 */
	private function isObjectLinkable()
	{
		// ensure object is valorized
		$this->getObject();
		$lst = $this->_object->getLastSbnSync('U');
		if ($lst)
			return true;
		return false;
	}

	/**
	 * @return string the field of the data source that provides the sync status for the column.
	 */
	public function getDataLinkClassField()
	{
		return $this->getViewState('DataLinkClassField','');
	}

	/**
	 * Sets the field of the data source that provides the sync status for the column.
	 * Defaults to 'SourceSync'.
	 * @param string the field of the data source that provides the text content of the column.
	 */
	public function setDataLinkClassField($value)
	{
		$this->setViewState('DataLinkClassField',$value,'');
	}

	/**
	 * @return string the field of the data source that provides the bid source for the column.
	 */
	public function getDataLinkKeyField()
	{
		return $this->getViewState('DataLinkKeyField','');
	}

	/**
	 * Sets the field of the data source that provides the sync status for the column.
	 * list($authid,$manid,$lt,$rc) = explode($separator,$value);
	 * @param string the field of the data source that provides the text content of the column.
	 */
	public function setDataLinkKeyField($value)
	{
		$this->setViewState('DataLinkKeyField',$value,'');
	}

	/**
	 * @return string the separator for the key field. Defaults to '-'.
	 */
	public function getDataLinkKeySeparator()
	{
		return $this->getViewState('DataLinkKeySeparator','-');
	}

	/**
	 * Sets the separator for the key field.
	 * list($authid,$manid,$lt,$rc) = explode($separator,$value);
	 * @param string the separator for the key field. Defaults to '-'.
	 */
	public function setDataLinkKeySeparator($value)
	{
		$this->setViewState('DataLinkKeySeparator',$value,'-');
	}

	protected function getLink($data)
	{
		$qstring = $this->getDataFieldValue($data,$this->getDataLinkClassField()).'Query';
		$key = explode($this->getDataLinkKeySeparator(),$this->getDataFieldValue($data,$this->getDataLinkKeyField()));
		if ('Query' == $qstring || count($key)<2)
			throw new Exception(__CLASS__.": wrong parameters.");
		/* @var $link LAuthority|LAuthorityManifestation|LManifestation */
		$link = $qstring::create()->findPk($key);
		return $link;
	}

	/**
	 * Initializes the specified cell to its initial values.
	 * This method overrides the parent implementation.
	 * It initializes the cell based on different templates
	 * (ItemTemplate, EditItemTemplate, HeaderTemplate, FooterTemplate).
	 * @param TTableCell the cell to be initialized.
	 * @param integer the index to the Columns property that the cell resides in.
	 * @param string the type of cell (Header,Footer,Item,AlternatingItem,EditItem,SelectedItem)
	 */
	public function initializeCell($cell,$columnIndex,$itemType)
	{
		parent::initializeCell($cell,$columnIndex,$itemType);
		$item = $cell->getParent();
		if ($itemType===TListItemType::Item || $itemType===TListItemType::AlternatingItem
				|| $itemType===TListItemType::SelectedItem || $itemType===TListItemType::EditItem)
		{
			$controls = $cell->getControls();
			$image = new TImage();
			$controls->add($image);
			$cell->registerObject('StatusImg',$image);
			$controls->add('&nbsp;');
			$button=Prado::createComponent('System.Web.UI.WebControls.TLinkButton');
			$button->setText(Prado::localize('crea legame'));
			$button->setCommandName('sbnLinkCreate');
			$controls->add($button);
			$cell->registerObject('LinkButton',$button);
			$controls->add('&nbsp;');
			$button=Prado::createComponent('System.Web.UI.WebControls.TLinkButton');
			$button->setText(Prado::localize('rimuovi legame'));
			$button->setCommandName('sbnLinkDelete');
			$controls->add($button);
			$cell->registerObject('UnlinkButton',$button);
			$cell->attachEventHandler('OnDataBinding',array($this,'dataBindColumn'));
		}
	}

	/**
	 * Databinds a cell in the column.
	 * This method is invoked when datagrid performs databinding.
	 * It populates the content of the cell with the relevant data from data source.
	 */
	public function dataBindColumn($sender,$param)
	{
		$item = $sender->getNamingContainer();
		$link = $this->getLink($item->getData());
		switch ($this->getSbnStatus($link)) {
			case 'notmanaged':
				$txt = Prado::localize('SBN non gestisce i legami tra documenti di tipo [{linktype}]',
					array('linktype'=>$link->getLinkType()));
				$sender->StatusImg->setImageUrl('themes/Default/icons/forbidden-16.png');
				$sender->StatusImg->setAlternateText($txt);
				$sender->StatusImg->setDescriptionUrl($txt);
				$sender->LinkButton->setVisible(false);
				$sender->UnlinkButton->setVisible(false);
				break;
			case 'unlinkable':
				$txt = Prado::localize('Gli oggetti non sono entrambi presenti in indice, legame impossibile');
				$sender->StatusImg->setImageUrl('themes/Default/icons/nav_plain_red-16.png');
				$sender->StatusImg->setAlternateText($txt);
				$sender->StatusImg->setDescriptionUrl($txt);
				$sender->LinkButton->setVisible(false);
				$sender->UnlinkButton->setVisible(false);
				break;
			case 'unlinked':
				$txt = Prado::localize('Il legame non è presente in indice');
				$sender->StatusImg->setImageUrl('themes/Default/icons/nav_plain_yellow-16.png');
				$sender->StatusImg->setAlternateText($txt);
				$sender->StatusImg->setDescriptionUrl($txt);
				$sender->LinkButton->setVisible(true);
				$sender->UnlinkButton->setVisible(false);
				break;
			case 'linked':
				$txt = Prado::localize('Il legame è presente in indice');
				$sender->StatusImg->setImageUrl('themes/Default/icons/nav_plain_green-16.png');
				$sender->StatusImg->setAlternateText($txt);
				$sender->StatusImg->setDescriptionUrl($txt);
				$sender->LinkButton->setVisible(false);
				$sender->UnlinkButton->setVisible(true);
				break;
		}
	}

	/**
	 * Returns SBN status.
	 * Return value can be 'linked', 'unlinked', 'notfound' or a date.
	 *  * 'linked': the link exists in SBN.
	 *  * 'unlinked': the link does not exist in SBN.
	 *  * 'unlinkable': the link cannot be created in SBN (i.e. one or both have no BID)
	 * @param LAuthority|LAuthorityManifestation|LManifestation $link
	 * @return mixed|string
	 */
	private function getSbnStatus($link)
	{
		$class = get_class($link);
		if ($class != 'LAuthority' && $class != 'LAuthorityManifestation' && $class != 'LManifestation')
			return 'unlinkable';
		if ('LManifestation' == $class && !in_array($link->getLinkType(),$this->_managedLinkTypes))
			return 'notmanaged';
		if ($link->getSourceSync() == LAuthorityManifestationPeer::SRCSYNC_TRUE)
			return 'linked';
		$test = false;
		// go with progressive test to improve performances, break at first falsified.
		switch ($class) {
			case 'LAuthority':
				if ('000' != $link->getRelatorCode() && trim($link->getRelatorCode())=='')
					break;
				if ($link->getAuthorityRelatedByAuthorityIdDown() instanceof Authority
						&& $link->getAuthorityRelatedByAuthorityIdDown()->getAuthorityRecType() != AuthorityPeer::RECTYPE_VARIANT
						&& ($link->getAuthorityRelatedByAuthorityIdDown()->getBidSource() != 'SBN'
							|| !$link->getAuthorityRelatedByAuthorityIdDown()->getBid()))
					break;
				if ($link->getAuthorityRelatedByAuthorityIdUp() instanceof Authority
						&& $link->getAuthorityRelatedByAuthorityIdUp()->getAuthorityRecType() != AuthorityPeer::RECTYPE_VARIANT
						&& ($link->getAuthorityRelatedByAuthorityIdUp()->getBidSource() != 'SBN'
							|| !$link->getAuthorityRelatedByAuthorityIdUp()->getBid()))
					break;
				$test = true;
				break;
			case 'LAuthorityManifestation':
				if ('000' != $link->getRelatorCode() && trim($link->getRelatorCode())=='')
					break;
				if ($link->getAuthority()->getBidSource() != 'SBN'
						|| !$link->getAuthority()->getBid())
					break;
				if ($link->getManifestation()->getBidSource() != 'SBN'
						|| !$link->getManifestation()->getBid())
					break;
				$test = true;
				break;
			case 'LManifestation':
				if ($link->getManifestationRelatedByManifestationIdDown() instanceof Manifestation
						&& ($link->getManifestationRelatedByManifestationIdDown()->getBidSource() != 'SBN'
							|| !$link->getManifestationRelatedByManifestationIdDown()->getBid()))
					break;
				if ($link->getManifestationRelatedByManifestationIdUp() instanceof Manifestation
						&& ($link->getManifestationRelatedByManifestationIdUp()->getBidSource() != 'SBN'
							|| !$link->getManifestationRelatedByManifestationIdUp()->getBid()))
					break;
				$test = true;
				break;
		}
		return $test ? 'unlinked' : 'unlinkable';
	}
}
