<?php
/**
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @link http://www.comperio.it/
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 */

/**
 * ClavisKpiList
 *
 * Kpi (key process indicators)  a type of performance measurement.
 * For example, people counter daily in/out (counters can be a resource).
 * 
 * forked from ClavisInvoiceList
 * @author Cristian Chiarello <ciarez@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @copyright Copyright &copy; 2010 Comperio srl
 * @package Widgets
 */

class ClavisKpiList extends TTemplateControl 
{
	protected $_library;

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallBack()) 
		{
			$this->resetFilters();
			
			$filters = $this->getFilters();

			if (array_key_exists('KpiStatus', $filters))
			{
				$invoiceStatusFilter = $filters['KpiStatus'];

				if (!is_null($invoiceStatusFilter) && ($invoiceStatusFilter != ""))
					$this->KpiStatus->setSelectedValue($invoiceStatusFilter);
			}		
					
			//if ($this->getAutoPopulate())
			//	$this->populate();
			
			$this->KpiGrid->resetPagination();
		}
	}
	
	public function resetFilters()
	{
		$this->LibraryFilter->setDataSource(LibraryPeer::getLibrariesHash(	array(LibraryPeer::BLANKVALUE), 
																				array('---'),
																				null,
																				true ) );
		$this->LibraryFilter->dataBind();

		$this->KpiMasterKey->setDataSource(array("0"=>"---"));
		$this->KpiMasterKey->dataBind();

		$this->KpiSlaveKey->setDataSource(array("0"=>"---"));
		$this->KpiSlaveKey->dataBind();
		
		$this->KpiGrid->setDataSource(array());
		$this->KpiGrid->dataBind();
		
	}

	public function populate()
	{
		//Prado::log(__METHOD__);
		$this->populateKpiGrid();
	}

	public function setAutoPopulate($flag = true)
	{
		if ($flag === "true")
			$flag = true;
		elseif ($flag === "false")
			$flag = false;
		
		$this->setViewState("AutoPopulate", $flag, true);
	}

	public function getAutoPopulate()
	{
		return $this->getViewState("AutoPopulate", true);
	}
	
	public function setFilters($filter = array())
	{
		$this->setControlState('Filters', $filter, array());
	}

	public function getFilters()
	{
		return $this->getControlState('Filters', array());
	}
	
	public function sortList( $param )
	{
		$this->populateKpiGrid();
	}
	
	private function populateKpiGrid()
	{
		$pageSize = $this->KpiGrid->getPageSize();
		$currentIndexPage = $this->KpiGrid->getCurrentPage();

		$filterLib = $this->LibraryFilter->getSelectedValue();
		if ($this->getLibrary() instanceof Library) 
		{
			$filterLib = $this->_library->getLibraryId();
		}

		$criteria = new Criteria();

		if ($filterLib > 0)
		{
			$criteria->add(  KpiValuePeer::LIBRARY_ID, $filterLib);
		}

		


		if ($this->KpiMasterKey->getSelectedIndex() > 0)
		{
			$criteria->addAnd(KpiValuePeer::MASTER_KEY, $this->KpiMasterKey->getSelectedValue());
		}
		
		if ($this->KpiSlaveKey->getSelectedIndex() > 0)
		{
			$criteria->addAnd(KpiValuePeer::SLAVE_KEY, $this->KpiSlaveKey->getSelectedValue());
		}
			
		$dateFilter = $this->DateFromFilter->getTimestamp();
		//$dateFilter = $this->DateFromFilter->getText();
		if ($dateFilter !== NULL)
		{
			$criteria->addAnd(KpiValuePeer::ID_DATE,  date("Y-m-d",$dateFilter) ." 00:00:00", Criteria::GREATER_EQUAL);
			$dateFilter = $this->DateToFilter->getTimestamp();
			//$dateFilter = $this->DateToFilter->getText();
			if ($dateFilter !== NULL)
			{
				$criteria->addAnd(KpiValuePeer::ID_DATE, date("Y-m-d",$dateFilter) ." 23:59:59", Criteria::LESS_EQUAL);
			}
			else
			{
				$criteria->addAnd(KpiValuePeer::ID_DATE, date("Y-m-d")." 23:59:59", Criteria::LESS_EQUAL);
			}
		}
		


		//Prado::log(__METHOD__ . " " . $criteria->toString());

		$recCount = KpiValuePeer::doCount($criteria);
		$this->KpiGrid->setVirtualItemCount($recCount);

		$this->FoundNumber->setText($recCount);

		$criteria->setLimit($pageSize);
		$criteria->setOffset($currentIndexPage * $pageSize);

		$this->calculateSortingCriteria($criteria);

		$queryResult = KpiValuePeer::doSelect($criteria);

		//Compose data for grid
		$kpis = array();
		foreach($queryResult as $kpi)
		{
			//$x = get_class($kpi);
			//Prado::log(__METHOD__ . " {$x}");
			//break;
			
			//Date
			$record = array();
			$record["IdDate"] = $kpi->getIdDate();
			
			//Try to get label of master key into lookup value. if not found, keep original value
			$mk = $kpi->getMasterKey();
			$hmk = LookupValueQuery::create()
				->select(LookupValuePeer::VALUE_LABEL)
				->filterByValueLanguage( $this->getApplication()->getGlobalization()->getCulture())
				->filterByValueKey($mk)->findOne();
			if($hmk)
			{
				$record["MasterKey"] = $hmk;
			}
			else
			{
				$record["MasterKey"] =$mk;
			}
			
			//slave key
			$record["SlaveKey"] = $kpi->getSlaveKey();
			
			//Kpi value: usually is number but it could be text
			$val = $kpi->getNumVal();
			if(!is_null($val))
			{
				$record["Value"] = $val;
			}
			else
			{
				$record["Value"] =  $kpi->getTxtVal();
			}
			
			$kpis[] = $record;
		}
		
		$this->KpiGrid->setDataSource($kpis);
		$this->KpiGrid->dataBind();
	}
	
	/*
	 * Called when user select a library
	 */
	public function libraryFilterChanged($sender,$param)
	{
		//selected library id
		$lid = $sender->getSelectedValue();
		//Prado::log(__METHOD__ . " {$lid}");
		
		//master keys human readable
		$mkhr = array("0" => "---");
		
		//Get all master keys
		$mks = KpiValueQuery::create()
			->select(KpiValuePeer::MASTER_KEY)
			->distinct()->find();
		
		foreach($mks as $mk)
		{
			//Prado::log(__METHOD__ . " {$mk}");
			$hmk = LookupValueQuery::create()
				->select(LookupValuePeer::VALUE_LABEL)
				->filterByValueLanguage( $this->getApplication()->getGlobalization()->getCulture())
				->filterByValueKey($mk)->findOne();
			//If human label found take it else keep key value (resource type)
			if($hmk)
			{
				$mkhr[$mk] = $hmk;
			}
			else
			{
				$mkhr[$mk] = $mk;
			}
		}
		
		
		$this->KpiMasterKey->setDataSource($mkhr);
		$this->KpiMasterKey->dataBind();
	}
	
	/*
	 * Called when master key selected
	 */
	public function masterKeyFilterChanged($sender,$param)
	{
		$sk = array(0 => "---");
		$lid = $this->LibraryFilter->getSelectedValue();
		$mk = $this->KpiMasterKey->getSelectedValue();
		//Prado::log(__METHOD__ . " lid {$lid} mk {$mk}");
		if($lid !== 0 && $mk !== 0)
		{
			$kpis = KpiValueQuery::create()
				->select(KpiValuePeer::SLAVE_KEY)
				->filterByLibraryId($lid)
				->filterByMasterKey($mk)
				->find();
			foreach($kpis as $kpi)
			{
				//Prado::log(__METHOD__ . " {$kpi}");
				$sk[$kpi] = $kpi;
			}
		}
		$this->KpiSlaveKey->setDataSource($sk);
		$this->KpiSlaveKey->dataBind();
	}

	public function search()
	{
		$this->searchKpi(null, null);
	}
	
	public function searchKpi($sender, $param) 
	{
		$this->KpiGrid->CurrentPageIndex = 0;
		$this->populateKpiGrid();
	}

	public function onCancel()
	{
		$this->searchCancel(null, null);
	}

	public function searchCancel($sender, $param)
	{
		$this->resetFilters();
		$this->FoundNumber->setText('');
		$this->KpiGrid->setCurrentPage(0);
	}

			
	public function changePage($sender,$param) 
	{
		$this->KpiGrid->setCurrentPage($param->NewPageIndex);
		//$this->getPage()->globalRefresh();
		$this->populateKpiGrid();
	}

	public function getPopupFlag()
	{
		return $this->getPage()->IsPopup();
	}

	public function getUnlinkFlag()
	{
		return $this->getPage()->IsUnlink();
	}

	public function setLibrary(Library $library) 
	{
		$this->_library = $library;
		$this->setControlState('library', $library, null);
	}
	
	public function getLibrary() 
	{
		if (! $this->_library instanceof Library)
			$this->_library = $this->getControlState('library',null);
		return $this->_library;
	}

	public function resetSorting() 
	{
		$this->KpiGrid->resetSorting('default', null, false);
	}

	public function calculateSortingCriteria(&$sortingCriteria = null)
	{
		$sortingExpression = $this->KpiGrid->getSortingExpression();
		$sortingDirection = $this->KpiGrid->getSortingDirection();

		if (! $sortingCriteria instanceof Criteria)
			$sortingCriteria = new Criteria();

		switch ($sortingExpression)
		{

			case 'date':
				$sortingCriteria->clearOrderByColumns();
				if ($sortingDirection == TClavisDataGrid::SORTDIRECTION_ASC)
				{
					$sortingCriteria->addAscendingOrderByColumn(KpiValuePeer::ID_DATE);
				}
				else
				{
					$sortingCriteria->addDescendingOrderByColumn(KpiValuePeer::ID_DATE);
				}
				break;


				
			default:
				$sortingCriteria->clearOrderByColumns();
				$sortingCriteria->addDescendingOrderByColumn(KpiValuePeer::ID_DATE);
				break;
		}
	}

}
