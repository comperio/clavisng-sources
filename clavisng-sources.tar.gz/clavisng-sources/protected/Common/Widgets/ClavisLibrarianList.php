<?php
/**
 * ClavisLibrarianList class file.
 *
 * It visualizes the librarians which are stored in the
 * databases into a datagrid.
 * 
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2018 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.8.9
 * @package Widgets
 */

/**
 * ClavisLibrarianList Class
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.8.9
 * @package Widgets
 * @since 2.0
 */
class ClavisLibrarianList extends TTemplateControl
{
	private $_library;
	private $_checked = array('all' => false);
	private $_checkedSessionName;
	private $_datasource;
	private $_datasourceSessionName;
	public $_masterChecked;
	private $_globalCriteria;
	private $_globalCriteriaSessionName;
	public $_onlySelectedSessionName;

	private function initVars()
	{
		$uniqueId = $this->getUniqueID();
		$this->_checkedSessionName = 'CheckedSessionName' . $uniqueId;
		$this->_datasourceSessionName = 'DatasourceSessionName' . $uniqueId;
		$this->_globalCriteriaSessionName = 'GlobalCriteriaSessionName' . $uniqueId;
		$this->_onlySelectedSessionName = 'OnlySelectedSessionName' . $uniqueId;

		$this->_checked = $this->getChecked();
		$this->_masterChecked = $this->_checked['all'];
	}

	public function onInit($param)
	{
		parent::onInit($param);
		$this->initVars();
	}

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsPostBack() and ! $this->getPage()->getIsCallBack())
		{
			$this->resetDataSource();

			$libraries = LibraryPeer::getLibrariesHashWithBlank();
			$this->LibraryFilter->setDataSource($libraries);
			$this->LibraryFilter->dataBind();
			
			$appProfilesArray = AppProfilePeer::getAllProfilesArray(true);	// with null
			$this->ProfileFilter->setDataSource($appProfilesArray);
			$this->ProfileFilter->dataBind();
										
			$this->StatusCheckBox->setChecked(false);
			
			$this->PrivacyAcceptFilterPanel->setVisible(($this->getUser()->getIsAdmin()
															|| $this->getUser()->getIsDirector())
															&& (LibrarianPeer::isPrivacyActive()));
		}
	}

	public function setGlobalCriteria($criteria = null)
	{
		$this->getApplication()->getSession()->add($this->_globalCriteriaSessionName, $criteria, null);
	}

	public function getGlobalCriteria()
	{
		$this->_globalCriteria = SerializableCriteria::refreshCriteria(
						$this->getApplication()->getSession()->itemAt($this->_globalCriteriaSessionName, null));

		return $this->_globalCriteria;
	}

	public function resetChecked($state = false)
	{
		$this->setChecked(array('all' => $state));
	}

	public function setChecked($checked = null)
	{
		$this->_checked = $checked;
		$this->getApplication()->getSession()->add($this->_checkedSessionName, $checked);
	}

	public function getChecked()
	{
		$this->_checked = $this->getApplication()->getSession()->itemAt($this->_checkedSessionName);
		return $this->_checked;
	}

	public function resetOnlySelected($value = null)
	{
		$this->setOnlySelected($value);
	}

	public function setOnlySelected($flag = false)
	{
		if ($flag === 'false')
			$flag = false;
		
		if ($flag === 'true')
			$flag = true;

		$this->getApplication()->getSession()->add($this->_onlySelectedSessionName, $flag, false);
	}

	public function getOnlySelected()
	{
		$flag = $this->getApplication()->getSession()->itemAt($this->_onlySelectedSessionName);
		return $flag;
	}

	public function resetDataSource()
	{
		$this->resetChecked();
		$this->resetOnlySelected();
		$this->_datasource = array();
		$this->getApplication()->getSession()->add($this->_datasourceSessionName, $this->_datasource);
		
		$this->populate();
	}

	public function getDatasource()
	{
		if (is_null($this->_datasource))
			$this->_datasource = $this->getApplication()->getSession()->itemAt($this->_datasourceSessionName);
		
		return $this->_datasource;
	}

	public function setLibrary($library)
	{
		$this->_library = $library;
		$this->setControlState('librarian_library', $library, null);
	}

	public function getLibrary()
	{
		if (is_null($this->_library))
			$this->_library = $this->getControlState('librarian_library', null);
		
		return $this->_library;
	}

	/**
	 * Cleans the search textboxes and re-populates.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onClearSearch()
	{
		$this->searchCancel(null, null);
	}

	/**
	 * It populates the datagrid.
	 *
	 */
	public function populate($givenLibrarianIds = null)
	{
		$pageSize = $this->LibrarianGrid->getPageSize();
		$currentIndexPage = $this->LibrarianGrid->getCurrentPageIndex();
		$library = $this->getLibrary();

		if ($this->getOnlySelected())
			$givenLibrarianIds = $this->getCheckedId();

		if (!is_null($givenLibrarianIds))
		{
			$librarians = LibrarianPeer::retrieveByPKs($givenLibrarianIds);
			$recCount = count($librarians);

			$this->setGlobalCriteria(array('type' => 'givenIds', 'body' => $givenLibrarianIds));
		}
		else
		{
			$searchName = $this->LibrarianName->getSafeText();
			$searchLastname = $this->LibrarianLastname->getSafeText();
			$searchUserLibraryId = $this->LibraryFilter->getSelectedValue();

			if ($searchUserLibraryId > 0)
				$library = LibraryPeer::retrieveByPK($searchUserLibraryId);

			$profileId = $this->ProfileFilter->getSelectedValue();
			
			if ($profileId < 1)
				$profileId = null;
			
			$activeOnly = ($this->StatusCheckBox->getChecked() ? 1 : 0);
			
			$librarianExpireFilterFrom = $this->LibrarianExpireFilterFrom->getText() != '' 
												? $this->LibrarianExpireFilterFrom->getTimeStamp() 
												: null;

			$librarianExpireFilterTo = $this->LibrarianExpireFilterTo->getText() != '' 
												? $this->LibrarianExpireFilterTo->getTimeStamp() 
												: null;

			if (LibrarianPeer::isPrivacyActive())
			{
				$privacyAcceptFilter = $this->PrivacyAcceptFilter->getSelectedValue();
			}
			else
			{
				$privacyAcceptFilter = 0;
			}
			
			$this->LibrarianExpireColumn->setVisible($librarianExpireFilterFrom || $librarianExpireFilterTo);
			
			$librarians = LibrarianPeer::extractLLibraryLibrarian(	$currentIndexPage, 
																	$pageSize, 
																	$searchName, 
																	$searchLastname, 
																	$library, 

																	$profileId,
																	$activeOnly,
																	$librarianExpireFilterFrom,
																	$librarianExpireFilterTo,
																	$privacyAcceptFilter);
			
			$recCount = LibrarianPeer::countLLibraryLibrarian(	$searchName, 
																$searchLastname, 
																$library,
																$profileId,
																$activeOnly,
																
																$librarianExpireFilterFrom,
																$librarianExpireFilterTo,
																$privacyAcceptFilter);
			
			$libraryId = null;

			if ($library instanceof Library)
				$libraryId = $library->getLibraryId();

			$this->setGlobalCriteria(array(	'type'	=> 'normal', 
											'body' => array($searchName,
											$searchLastname,
											$libraryId,
											$profileId,
												
											$activeOnly,
											$librarianExpireFilterFrom,
											$librarianExpireFilterTo,
											$privacyAcceptFilter)));
		}

		$this->LibrarianGrid->VirtualItemCount = $recCount;

		if (!$this->getOnlySelected())
			$this->FoundNumber->setText($recCount);

		$data = array();
		/* @var $librarian Librarian */
		
		foreach ($librarians as $librarian)
		{
			if (is_null($librarian) 
					|| !($librarian instanceof Librarian))
				continue;

			$sup = array();
			$librarianId = $librarian->getLibrarianId();

			if (isset($this->_checked[$librarianId]))
			{
				$checked = $this->_checked[$librarianId];
			}
			else
			{
				//$this->_checked[$shelfItemId] = false;    modifica suggerita da Dario
				$checked = false;
			}

			if ($this->_checked['all'])
				$checked = !$checked;

			$sup['Checked'] = $checked;

			$librarianName = $librarian->getName();
			$sup['LibrarianName'] = $librarianName;

			$librarianLastname = $librarian->getLastname();
			$sup['LibrarianLastname'] = $librarianLastname;

			$sup['LibrarianCompleteName'] = $librarian->getCompleteName();

			$email = $librarian->getEmail();
			$sup['Email'] = $email;

			$sup['AppProfileName'] = $librarian->getProfileLabels();
			$sup['LinkRole'] = '---';
			$sup['OpacVisible'] = false;

			if ($library instanceof Library)
			{
				$this->RoleColumn->setVisible(true);
				$this->OpacVisibleColumn->setVisible(true);
				$libraryLink = LLibraryLibrarianQuery::create()
									->filterByLibrary($library)
									->findOneByLibrarianId($librarian->getLibrarianId());

				if ($libraryLink instanceof LLibraryLibrarian)
				{
					$sup['OpacVisible'] = $libraryLink->getOpacVisible();
					$linkRole = $libraryLink->getLinkRole();
					
					if (!is_null($linkRole))
						$sup['LinkRole'] = LookupValuePeer::getLookupValue('LIBRARIANROLE', $linkRole);
				}
			} else
			{
				$this->RoleColumn->setVisible(false);
				$this->OpacVisibleColumn->setVisible(false);
			}

			$sup['Id'] = $librarianId;
			$sup['libraryId'] = $librarian->getDefaultLibraryId();
			$sup['libraryLabel'] = LibraryPeer::getLibraryLabel($sup['libraryId'], '---');
			$sup['activationStatus'] = $librarian->getActivationStatus();
			
			$sup['LibrarianExpire'] = $librarian->getLibrarianExpire(); 

			$data[] = $sup;
		}
		
		$this->_datasource = $data;
		$this->getApplication()->getSession()->add($this->_datasourceSessionName, $this->_datasource);

		$this->LibrarianGrid->setDataSource($data);
		$this->LibrarianGrid->dataBind();
	}

	public function completePager($sender, $param)
	{
		$pager = $param->Pager->getControls();
		$pager->add(' / ' . $this->LibrarianGrid->getPageCount());

		$label = new TLabel();
		$label->setID('PageRowsLabel');
		$label->setText(Prado::localize('num.righe') . ' ');
		$label->setCssClass("viewlabel4small");
		$pager->insertAt(0, $label);

		$pageSizeSelect = new TDropDownList();
		$pageSizeSelect->setID('PageRows');
		$pageSizeSelect->setAutoPostBack(true);
		
		foreach (array(10, 20, 50, 100) as $value)
		{
			$element = new TListItem();
			$element->setText($value);
			$element->setValue($value);
			$pageSizeSelect->getItems()->add($element);
		}
		
		if (($pageSize = $this->LibrarianGrid->getPageSize()) > 0)
			$pageSizeSelect->setSelectedValue($pageSize);
		
		$pager->insertAt(1, $pageSizeSelect);
		$pageSizeSelect->attachEventHandler('OnSelectedIndexChanged', array($this, 'onChangePageSize'));
	}

	public function onChangePageSize($sender, $param)
	{
		$start = $this->LibrarianGrid->getCurrentPageIndex() * $this->LibrarianGrid->getPageSize();
		
		if (($newPageSize = intval($sender->getSelectedValue())) > 0)
		{
			$this->LibrarianGrid->setPageSize($newPageSize);
			$this->LibrarianGrid->setCurrentPageIndex(floor($start / $newPageSize));
			$this->populate();
		}
	}

	public function onSearchLibrarian($sender, $param)
	{
		$this->populate();
		$this->resetPagination();
		$this->setMasterChecked(false, $param);
		$this->Page->globalRefresh();
	}

	public function onCancel()
	{
		$this->searchCancel(null, null);
	}

	public function searchCancel($sender, $param)
	{
		$this->clearFilters();
		$this->setMasterChecked(false, $param);
		$this->onSearchLibrarian(null, null);
	}

	public function clearFilters()
	{
		$this->LibrarianName->setText('');
		$this->LibrarianLastname->setText('');
		$this->LibraryFilter->setSelectedIndex(0);
		$this->ProfileFilter->setSelectedIndex(0);
		$this->StatusCheckBox->setChecked(false);
		$this->onLibrarianExpireReset(null, null);
		$this->PrivacyAcceptFilter->setSelectedIndex(0);
	}

	/**
	 * Manages the change of page in the datagrid.
	 * Uses the viewstate to store the current page.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function changePage($sender, $param)
	{
		$this->LibrarianGrid->setCurrentPageIndex($param->NewPageIndex);
		$this->populate();
	}

	/**
	 * Are we inside a popup ?
	 *
	 * @return boolean
	 */
	public function getPopupFlag()
	{
		return $this->getPage()->IsPopup();
	}

	/**
	 * Can we apply
	 *
	 * @return unknown
	 */
	public function getUnlinkFlag()
	{
		return $this->getPage()->IsUnlink();
	}

	public function onUnlink($sender, $param)
	{
		$id = $param->CommandParameter;
		$this->GetPage()->Unlink($id);
	}

	/**
	 * Resets the datagrid's pagination (first page).
	 *
	 */
	public function resetPagination()
	{
		$this->LibrarianGrid->setCurrentPageIndex(0);
	}

	public function globalRefresh()
	{
		$this->populate();
	}

	public function getMasterChecked()
	{
		$checked = $this->getChecked();
		return $checked['all'];
	}

	public function onFlipChecked($sender, $param)
	{
		$newChecked = $sender->getChecked();
		$index = $sender->Parent->Parent->ItemIndex;
		$dataSource = $this->getDatasource();
		$checked = $this->getChecked();

		$row = $dataSource[$index];
		$librarianId = $row['Id'];

		if ($newChecked != $checked['all'])
		{
			$checked[$librarianId] = true;
		}
		else
		{
			unset($checked[$librarianId]);
		}

		$this->setChecked($checked);
		$this->updateEmptyFlag($param);
	}

	public function onMasterChecked($sender, $param)
	{
		$this->setMasterChecked($sender->getChecked(), $param);
	}

	public function setMasterChecked($newChecked = false, $param = null)
	{
		$this->resetChecked($newChecked);

		$gridItems = $this->LibrarianGrid->getItems();
		$header = $this->LibrarianGrid->getHeader();

		foreach ($gridItems as $item)
			$item->CheckColumn->CheckedBox->setChecked($newChecked);

		if (!is_null($header->CheckColumn->MasterCheck))
			$header->CheckColumn->MasterCheck->setChecked($newChecked);
		
		$this->updateEmptyFlag($param);
	}

	public function onOnlySelected($sender, $param)
	{
		$checked = $sender->getChecked();
		$this->setOnlySelected($checked);
		$this->resetPagination();
		$this->clearFilters();
		$this->populate();
	}

	public function updateEmptyFlag($param = null)
	{
		$this->SelectedNumber->setText(intval($this->countCheckedId()));
		
		if (!is_null($param))
			$this->SelectedPanel->render($param->getNewWriter());
	}

	public function getCheckedId($force = false)
	{
		$checked = $this->getChecked();

		$this->_masterChecked = $checked['all'];
		unset($checked['all']);
		$checkedIds = array_keys($checked);

		$output = array();

		if (!$this->_masterChecked)
		{
			$output = $checkedIds;
		}
		else		 // case of inverted mastercheck control
		{
			$items = null;
			$criteriaArray = $this->getGlobalCriteria();

			if (!is_null($criteriaArray) 
					&& ($criteriaArray['type'] == 'givenIds'))
			{
				$librarianIds = $criteriaArray['body'];
				$output = array_diff($librarianIds, $checkedIds);
			}
			else if (!is_null($criteriaArray) 
					&& ($criteriaArray['type'] == 'normal'))
			{
				$criteria = $criteriaArray['body'];
				list ($searchName, $searchLastname, $libraryId, $profileId, $activeOnly, $librarianExpireFilterFrom, $librarianExpireFilterTo, $privacyAcceptFilter) = $criteria;

				$library = null;
				
				if ($libraryId > 0)
					$library = LibraryPeer::retrieveByPK($libraryId);
				
				$librarians = LibrarianPeer::extractLLibraryLibrarian(	null, 
																		null, 
																		$searchName, 
																		$searchLastname, 
																		$library, 

																		$profileId,	
																		$activeOnly,
																		$librarianExpireFilterFrom,
																		$librarianExpireFilterTo,
																		$privacyAcceptFilter,
																		
																		$checkedIds);

				$output = array();
				
				foreach ($librarians as $librarian)
					$output[] = $librarian->getLibrarianId();
			}
		}

		if ((count($output) == 0) 
				&& ($force == true))
		{
			$this->setMasterChecked(true);
			$output = $this->getCheckedId();
		}
		
		return $output;
	}

	public function countCheckedId($force = false)
	{
		$checked = $this->getChecked();

		$this->_masterChecked = $checked['all'];
		unset($checked['all']);
		$checkedIds = array_keys($checked);

		$output = array();

		if (!$this->_masterChecked)
		{
			$output = $checkedIds;
		}
		else		 // case of inverted mastercheck control
		{
			$items = null;
			$criteriaArray = $this->getGlobalCriteria();

			if (!is_null($criteriaArray) 
					&& ($criteriaArray['type'] == 'givenIds'))
			{
				$librarianIds = $criteriaArray['body'];
				$output = array_diff($librarianIds, $checkedIds);
			}
			elseif (!is_null($criteriaArray) 
					&& ($criteriaArray['type'] == 'normal'))
			{
				$criteria = $criteriaArray['body'];
				list ($searchName, $searchLastname, $libraryId, $profileId, $activeOnly, $librarianExpireFilterFrom, $librarianExpireFilterTo, $privacyAcceptFilter) = $criteria;

				$library = null;
				
				if ($libraryId > 0)
					$library = LibraryPeer::retrieveByPK($libraryId);
				
				$librarians = LibrarianPeer::extractLLibraryLibrarian(	null, 
																		null, 
																		$searchName, 
																		$searchLastname, 
																		$library, 
						
																		$profileId,
																		$activeOnly,
																		$librarianExpireFilterFrom,
																		$librarianExpireFilterTo,
																		$privacyAcceptFilter,
						
																		$checkedIds);

				$output = array();
				
				foreach ($librarians as $librarian)
					$output[] = $librarian->getLibrarianId();
			}
		}

		if ((count($output) == 0) 
				&& ($force == true))
		{
			$this->setMasterChecked(true);
			$output = $this->countCheckedId();
		}
		
		return count($output);
	}

	public function itemAction($sender, $param)
	{
		$action = $param->getCommandName();
		
		if (!($library = $this->getLibrary()) instanceof Library)
			return;
		
		$link = LLibraryLibrarianQuery::create()
					->filterByLibrarianId($param->getCommandParameter())
					->filterByLibrary($library)
					->findOne();
		
		if ($link instanceof LLibraryLibrarian)
		{
			switch ($action)
			{
				case 'toggleVisible':
					$link->setOpacVisible(!$link->getOpacVisible());
					$link->save();
				
					break;
		
				default:
					break;
			}
		}
		
		$this->populate();
	}
	
	public function onLibrarianExpireReset($sender, $param)
	{
		$this->LibrarianExpireFilterFrom->setText('');
 		$this->LibrarianExpireFilterTo->setText('');

		if ($this->getPage()->getIsCallback()
				&& !is_null($param))
			$this->LibrarianExpireFilterPanel->render($param->getNewWriter());
	}
	
}