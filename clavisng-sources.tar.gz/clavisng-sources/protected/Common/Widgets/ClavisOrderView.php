<?php
/**
 * ClavisOrderView class
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @copyright Copyright &copy; 2010 Comperio srl
 * @version 2.7
 * @package Widgets
 * @since 2.1
 */
class ClavisOrderView extends TTemplateControl
{
	/** @var PurchaseOrder */
	private $_order = null;

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallback()) // first cycle
		{
			$this->populate();
		}
		else  // not first cycle
		{
			
		}
	}

	public function populate()
	{
		$this->populateOrderView();
	}

	public function populateOrderView()
	{
		if ($this->_order === null)
			return;

		$this->OrderHead->setorder($this->_order);
		$this->OrderHead->populate();
	}

	/**
	 * @param PurchaseOrder $order
	 */
	public function setOrder(PurchaseOrder $order)
	{
		$this->_order = $order;
		$this->setControlState('purchase_order', $order, null);
	}

	/**
	 * @return PurchaseOrder
	 */
	public function getOrder()
	{
		if (is_null($this->_order))
		{
			$this->_order = $this->getControlState('purchase_order', null);
		}
		return $this->_order;
	}

	/**
	 * @return int
	 */
	public function getOrderId()
	{
		$this->getOrder();
		return ($this->_order instanceof PurchaseOrder) ? $this->_order->getOrderId() : '';
	}

	public function onJRPrint($sender, $param)
	{
		$this->JRPBox->printReport();
	}
	
}