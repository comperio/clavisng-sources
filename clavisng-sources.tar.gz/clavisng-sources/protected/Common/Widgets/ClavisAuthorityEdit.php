<?php
/**
 * ClavisAuthorityEdit class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Ciro Mattia Gonano
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.8.6
 * @package Widgets
 */

/**
 * ClavisAuthorityEdit Class
 * 
 * @author Ciro Mattia Gonano
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.8.6
 * @package Widgets
 * @since 2.4.1
 */
class ClavisAuthorityEdit extends TTemplateControl
{
	const DEFAULT_CLASS = 676;
	const DEFAULT_LANGUAGE = '';
	
	/** @var Authority */
	public $authority;
	
	/** @var TurboMarc */
	public $turbomarc;
	
	/** @var ClavisSBN */
	private $_sbnMod;

	public function onLoad($param)
	{
		parent::onLoad($param);
	
		$this->_sbnMod = $this->getApplication()->getModule('sbn');

		if (!$this->getPage()->getIsPostBack() 
				&& !$this->getPage()->getIsCallback())
		{
			$this->populate();
		}
		else
		{
			$this->loadAuthority();
		}
		
		$this->SBNTabView->setVisible($this->_sbnMod->getEnabled()
										&& $this->authority instanceof Authority 
										&& !$this->authority->isNew());
		
		if ($this->SBNTabView->getVisible())
		{
			$img = $this->SBNActions->getStatusIcon();
			$this->SBNTabView->setCaption("SBN <img style=\"height:12px;border:0;margin:0;padding:0;\" src=\"{$img['img']}\" alt=\"{$img['txt']}\" />");
		}
		
		// another first cycle point
		if (!$this->getPage()->getIsPostBack() 
				&& !$this->getPage()->getIsCallback())
		{
					/* tabview selection by request parameter */
			try
			{
				$selectTab = $this->getRequest()->itemAt('selectTab');
				if (is_numeric($selectTab) 
						&& $selectTab > 0)
				{
					$this->AuthEditTPanel->setActiveViewIndex($selectTab);
				}
				elseif (is_string($selectTab) 
						&& $selectTab != "")
				{
					$this->AuthEditTPanel->setActiveViewID($selectTab);
				}
			}
			catch (Exception $e)
			{
				//Prado::log($e);
			}
		}
	}

	public function loadAuthority()
	{
		$this->authority = $this->getControlState('authority');
		$this->turbomarc = $this->authority->getTurboMarc();
		$this->initTabs();
	}

	public function saveAuthority()
	{
		$this->setControlState('authority', $this->authority);
	}

	public function setAuthorityId($value)
	{
		$this->setControlState('authorityId', intval($value), null);
	}

	public function getAuthorityId()
	{
		return $this->getControlState('authorityId', null);
	}

	public function getAuthority()
	{
		return $this->authority;
	}

	public function getAuthorityType()
	{
		return ($this->authority instanceof Authority) 
					? $this->authority->getAuthorityType() 
					: null;
	}

	public function initTabs()
	{
		if (!$this->authority->isNew())
		{
			$this->AttachList->setObjectClass('Authority');
			$this->AttachList->setObjectId($this->authority->getAuthorityId());
			$this->TabDocLink->setVisible(true);
			$this->TabAuthLink->setVisible(true);
			$this->TabAuthLinkedData->setVisible(true);
			$this->TabAttachment->setVisible(true);
			$this->AuthLink->setAuthority($this->authority);
			$this->AuthLinkedData->setAuthority($this->authority);
			$this->DocLink->setAuthority($this->authority);
		}
		else
		{
			$this->TabTitles->setVisible(false);
			$this->TabDocLink->setVisible(false);
			$this->TabAuthLink->setVisible(false);
			$this->TabAuthLinkedData->setVisible(false);
			$this->TabAttachment->setVisible(false);
		}
	}

	public function populate()
	{
		$authId = $this->getAuthorityId();

		if (!$this->authority 
				&& $authId)
		{
			$this->authority = AuthorityQuery::create()->findPk($authId);
			
			if (!$this->authority instanceof Authority)
			{	
				$this->getPage()->writeMessage(Prado::localize("L'authority [{id}] non esiste o non è valida", 
																	array('id' => $authId)), 
													ClavisMessage::ERROR);
				
				$this->getPage()->gotoPage('Catalog.AuthorityList');
			}
			
			/* check if librarian can actually edit this manifestation */
			$modifyEnabled = $this->getUser()->getEditPermission($this->authority)
										&& ($this->authority->getAuthorityCodlevel() <= $this->getUser()->getLibrarian()->getCatLevel());
			
			if (!$modifyEnabled)
			{	
				if ($this->getPage()->IsPopup())
				{
					$this->getPage()->gotoPage('Error.NoAuthPlugin');
				}
				else
				{
					$this->getPage()->writeDelayedMessage(Prado::localize("Non si dispone del livello di autorizzazione richiesto per la modifica dell'authority"), 
															ClavisMessage::ERROR);
					
					$this->getPage()->gotoPage('Catalog.AuthorityViewPage', array('id' => $authId));
				}
			}
		}
		elseif ($this->authority->isNew())
		{
			if (!$this->authority->getAuthorityType())
				$this->authority->setAuthorityType(AuthorityPeer::TYPE_PERSONALNAME);
			
			$this->authority->setAuthorityRectype(AuthorityPeer::RECTYPE_ACCEPTED);
			$cat_level = '05';
			
			if ($this->getUser() instanceof ClavisLibrarian)
				$cat_level = $this->getUser()->getLibrarian()->getCatLevel();
			
			$this->authority->setAuthorityCodlevel($cat_level);
		}

		$this->turbomarc = $this->authority->getTurboMarc();
		$this->BidSource->setText($this->authority->getBidSource());
		$this->Bid->setText($this->authority->getBid());
		
		$authorityRecType = $this->authority->getAuthorityRectype();
		
		if (is_null($authorityRecType)
				|| ($authorityRecType == ''))
			$authorityRecType = AuthorityPeer::RECTYPE_ACCEPTED;
				
		$this->AuthRecType->setSelectedValue($authorityRecType);

		$this->AuthCodLev->setSelectedValue($this->authority->getAuthorityCodlevel());
		$this->AuthIntSta->setSelectedValue($this->authority->getAuthorityStatus());
		$this->ISBD->setText(htmlentities($this->authority->getFullText(), ENT_QUOTES, 'UTF-8'));
		$this->AuthorityTypeList->setSelectedValue($this->authority->getAuthorityType());
		$this->AuthoritySubtypeList->setSelectedValue($this->authority->getAuthoritySubtype());
		
		if (isset($this->turbomarc->d100))
			$this->LastEditDate->setValue($this->turbomarc->d100->getCDF('a', 0));

		if (isset($this->turbomarc->d109))
		{
			$this->Date1->setText((string) $this->turbomarc->d109->sa);
			$this->Date2->setText((string) $this->turbomarc->d109->sb);
			$this->WorkTarget->setSelectedValue((string) $this->turbomarc->d109->sc);
		}

		if(isset($this->turbomarc->d123))
        {
            $this->LongWest->setText((string)$this->turbomarc->d123->sq);
            $this->LongEst->setText((string)$this->turbomarc->d123->sr);
            $this->LatNorth->setText((string)$this->turbomarc->d123->ss);
            $this->LatSouth->setText((string)$this->turbomarc->d123->st);

        }

		$ds3xx = array();

		foreach (array('300', '305', '310', '320', '330', '340', '390', '391', '392', '393', '394', '395', '396', '830', '928', '929') as $field)
		{
			$tag = "d$field";

			if (isset($this->turbomarc->$tag))
			{
				$fieldContent = array();
				foreach ($this->turbomarc->$tag as $fld)
				{
					if ($field > 900)
					{
						$noteTxt = "";

						foreach ($fld->children() as $c)
							$noteTxt .= "<[" . substr($c->getName(), 1) . "] " . $c['l'] . ">\n:" . (string) $c . "\n";

						$ds3xx[] = array(	'NoteNumber' => $field, 
											'NoteValue' => trim($noteTxt) );
					}
					else
					{
						$ds3xx[] = array(	'NoteNumber' => $field, 
											'NoteValue' => trim((string) $fld->sa) );
					}
				}
			}
		}
		
		$this->Notes->setDataSource($ds3xx);
		$this->Notes->dataBind();

		if ($this->getAuthorityType() == AuthorityPeer::TYPE_WORK)
		{
			$this->TabTitles->setVisible(true);
			$ds5xx = array();
		
			for ($field = 500; $field < 600; ++$field)
			{
				$tag = "d$field";
			
				if (isset($this->turbomarc->$tag))
				{	
					foreach ($this->turbomarc->$tag as $fld)
						$ds5xx[] = array(	'field' => $field,
											'value' => (string) $fld->sa,
											'bid' => (string) $fld->s3 );
				}
			}
			
			$this->RepF5XX->setDataSource($ds5xx);
			$this->RepF5XX->dataBind();
		} 
		else
		{
			$this->TabTitles->setVisible(false);
		}

		switch ($this->getAuthorityType())
		{
			case AuthorityPeer::TYPE_SUBJECT:
				$this->SpecSubject->setVisible(true);
				$this->populateSubject();
				break;
		
			case AuthorityPeer::TYPE_CLASS:
				$this->SpecClass->setVisible(true);
				$this->populateClass();
				break;
			
			case AuthorityPeer::TYPE_PRINTERSDEVICE:
				$this->SpecPrnDevice->setVisible(true);
				$this->populatePrnDevice();
				break;
			
			default:
				$this->SpecDefault->setVisible(true);
				$this->populateDefault();
				break;
		}
		
		$this->initTabs();
		
		if (!$this->authority->isNew())
		{
			$this->AuthLink->populate();
			$this->DocLink->populate();
		}

		$this->dataBind();
		$this->saveAuthority();
	}

	public function populateDefault()
	{
		if (trim($this->Title->getSafeText()) === '')
			$this->Title->setText($this->authority->getCompleteText());

		if (isset($this->turbomarc->d101->sa))
			$this->Language->setSelectedValue((string)$this->turbomarc->d101->sa);

		unset($fnum);

		switch ($this->getAuthorityType())
		{
			case AuthorityPeer::TYPE_TRADEMARK:
				$fnum = 'd216';
				
			case AuthorityPeer::TYPE_FAMILYNAME:
				if (!isset($fnum))
					$fnum = 'd220';
				
			case AuthorityPeer::TYPE_PERSONALNAME:
				if (!isset($fnum))
					$fnum = 'd200';
				
				$this->NameForm->setDBClass('NAMEFORMPERSONAL');
				$this->NameForm->populate();
				if (isset($this->turbomarc->$fnum->si))
					$this->NameForm->setSelectedValue($this->turbomarc->$fnum->si);

				//if (isset($this->turbomarc->d102->sa))
				//	$this->Country->setSelectedValue((string)$this->turbomarc->d102->sa);

				$this->populateCountryList($this->turbomarc->d102);
				break;

			case AuthorityPeer::TYPE_CORPORATEBODYNAME:
				$this->NameForm->setDBClass('NAMEFORMCORPORATE');
				$this->NameForm->populate();
				if (isset($this->turbomarc->d210->si))
					$this->NameForm->setSelectedValue($this->turbomarc->d210->si);

				//if (isset($this->turbomarc->d102->sa))
				//	$this->Country->setSelectedValue((string)$this->turbomarc->d102->sa);

				$this->populateCountryList($this->turbomarc->d102);
				break;

			case AuthorityPeer::TYPE_WORK:
				$this->WorkType->setSelectedValue(isset($this->turbomarc->d230->sw) ? (string) $this->turbomarc->d230->sw : 'text');
				$this->populateCountryList($this->turbomarc->d102);
				break;
			
			case AuthorityPeer::TYPE_PUBPLACE:
				$this->Region->setText((string) $this->turbomarc->d260->sc);
				$this->populateCountryList($this->turbomarc->d102);
				break;
			
			case AuthorityPeer::TYPE_ARGUMENT:
				//$this->ArgumentSubjectCode->setSelectedValue((string)$this->turbomarc->d931->s2);
				break;
		}
	}

	public function populateSubject()
	{
		$parts = array();
		
		if (!$this->authority->isNew())
		{
			$parts = LSubjectQuery::create()
						->filterBySubjectId($this->getAuthorityId())
						->orderByPosition()
						->find();
			
			// shift parent
			$parts->shift();
			$parent = AuthorityQuery::create()->findPk($this->authority->getParentId());
			
			if (!$parent instanceof Authority 
					&& !$this->authority->isNew())
			{
				// try saving subject, which rebuilds parts and parent.
				$this->authority->save();
				$parent = AuthorityQuery::create()->findPk($this->authority->getParentId());
			}
			
			if ($parent instanceof Authority)
			{
				$this->ParentAuthID->setValue($parent->getAuthorityId());
				$this->ParentAuthLink->setText($parent->getFullText());
			}
			else
			{
				$this->getPage()->writeMessage(Prado::localize("ATTENZIONE: il soggetto non ha primo elemento"), 
													ClavisMessage::WARNING);
			}
		}
		
		$ds = array();
		
		foreach ($parts as $p)
		{
			$ds[] = array(	'PartType' => $p->getType(),
							'PartConnector' => $p->getConnector(),
							'PartText' => $p->getAuthorityRelatedByAuthorityId()->getFullText(),
							'PartId' => $p->getAuthorityId() );
		}
		
		if (count($ds) < 1)
		{
			$ds[] = array(	'PartType' => 'A',
							'PartConnector' => '- ',
							'PartText' => '',
							'PartId' => '' );
		}
		
		$this->SubjectParts->setDataSource($ds);
		$this->SubjectParts->dataBind();
		$this->SubjectType->setSelectedValue($this->authority->getSubjectClass());
	}

	public function populateClass()
	{
		$this->ClassCode->setText($this->authority->getClassCode());
		
		if (isset($this->turbomarc->d676))
		{
			$ctype = '676';
			$fld = $this->turbomarc->d676;
		}
		elseif (isset($this->turbomarc->d680))
		{
			$ctype = '680';
			$fld = $this->turbomarc->d680;
		}
		elseif (isset($this->turbomarc->d686))
		{
			$fld = $this->turbomarc->d686;
			$ctype = isset($fld->s2) ? (string) $fld->s2 : self::DEFAULT_CLASS;
		}
		else
		{
			$fld = null;
			$ctype = self::DEFAULT_CLASS;
		}
		
		$this->ClassType->populate();
		$this->ClassEdition->populate();
		$this->ClassType->setSelectedValue($ctype);
		
		if ($fld 
				&& isset($fld->sv))
			$this->ClassEdition->setSelectedValue((string) $fld->sv);
		
		if ($fld
				&& isset($fld->sc))
			$this->ClassString->setText((string) $fld->sc);
		
		$this->ClassItemCode->setText(($fld && isset($fld->si)) 
											? (string) $fld->si 
											: $this->authority->getClassCode());
	}

	public function populatePrnDevice()
	{
		$this->PrnIndex->populate();
		$fld = $this->turbomarc->d921;
		
		if (isset($fld->sc))
		{
			$index = substr((string) $fld->sc, 0, 1);
			$quot = substr((string) $fld->sc, 1);
		
			if ($this->PrnIndex->getDataSource()->itemAt($index))
				$this->PrnIndex->setSelectedValue($index);
			
			$this->PrnQuotation->setText($quot);
		}
		
		if (isset($fld->sd))
			$this->PrnNote->setText((string) $fld->sd);
		
		if (isset($fld->se))
			$this->PrnWatchword->setText((string) $fld->se);
		
		if (isset($fld->sa))
			$this->PrnDescription->setText((string) $fld->sa);
		
		if (isset($fld->sb))
		{
			$idx = 0;
			foreach ($fld->sb as $keyword)
			{
				$ctrl = "PrnKeyword{$idx}";
				++$idx;
				$this->$ctrl->setText((string) $keyword);
			}
		}
	}

	/**
	 *
	 * @return TurboMarc
	 */
	private function buildUnimarc()
	{
		// reset authority
		// first of all, remove all existing LSubjects
		foreach ($this->authority->getLSubjectsRelatedBySubjectId() as $link)
			$link->delete();
		
		$this->authority->setSubjectClass(null);
		$this->authority->setParentId(null);
		$this->authority->setClassCode(null);
		$this->authority->setAuthorityRectype($this->AuthRecType->getSelectedValue());
		$this->authority->setAuthorityCodlevel($this->AuthCodLev->getSelectedValue());
		$this->authority->setAuthorityStatus($this->AuthIntSta->getSelectedValue());
		
		if ($this->AuthoritySubtypeList->getSelectedIndex() > 0)
		{
			$this->authority->setAuthoritySubtype($this->AuthoritySubtypeList->getSelectedValue());
		}
		else
		{
			$this->authority->setAuthoritySubtype(null);
		}
		// end authority resetting

		$bid_source = $this->authority->getBidSource();
		$bid = $this->authority->getBid();

		$tm = TurboMarc::createRecord();
		$l = new TurboMarcLeader();
		$l->recLen = '01234';
		$l->recstatus = 'n';
		$l->type = $this->authority->getAuthorityRectype();
		$l->entitytype = AuthorityPeer::mapTypeClavisToUnimarc($this->authority->getAuthorityType());

		$tm->setLeader($l);

		$c001 = $tm->setControlField('001', $this->authority->getAuthorityId());
		$c005 = $tm->setControlField('005', date('Ymdhms.0'));

		$oldtm = $this->authority->getTurboMarc();
		
		if (isset($oldtm->d099))
			$tm->appendNode($oldtm->d099);
		
		if (isset($oldtm->d801))
			$tm->appendNode($oldtm->d801);

		$f100 = $tm->addField('100');
		$f100->setCDF('a', 0, $this->LastEditDate->getValue());
		$f100->setCDF('a', 8, $this->authority->getAuthorityStatus());
		$f100->setCDF('a', 13, 50); // ISO 10646

		if ($this->LangPanel->getVisible() && $this->Language->getSelectedIndex() > 0)
		{
			$lang = $this->Language->getSelectedValue();
			$this->authority->setAuthorityLang($lang);
			$tm->addField('101')->addSubField('a', $lang);
		}

		$country = $this->getCountries();
		
		if (count($country) > 0)
		{
			foreach ($country as $c)
				$tm->addField('102')->addSubField('a', $c);
		}

		$f109 = $tm->addField("109");
		$f109->addSubField("a", $this->Date1->getSafeText());
		$f109->addSubField("b", $this->Date2->getSafeText());
		$f109->addSubField("c", $this->WorkTarget->getSelectedValue());


		if((trim($this->LongWest->getSafeText()) != '' || trim($this->LongEst->getSafeText()) != '')
        || (trim($this->LatNorth->getSafeText()) != '' || trim($this->LatSouth->getSafeText()) != '') ) {
            $f123 = $tm->addField("123");
            $f123->addSubField("q", trim($this->LongWest->getSafeText()));
            $f123->addSubField("r", trim($this->LongEst->getSafeText()));
            $f123->addSubField("s", trim($this->LatNorth->getSafeText()));
            $f123->addSubField("t", trim($this->LatSouth->getSafeText()));
        }
		// notes (3XX)
		$items = $this->Notes->getItems();
		foreach ($items as $item)
		{
			$f3xxNum = $item->NoteNumber->getSelectedValue();
			$f3xxValue = html_entity_decode($item->NoteValue->getText());
			$f3xxValue = preg_replace('/(\s)+/', '$1', $f3xxValue);
			
			if (trim($item->NoteValue->getText()) != '')
			{
				if ($f3xxNum > 900)
				{
					$f3xx = $tm->addField($f3xxNum);
					$match = array();
					$tag = "";
					$label = "";

					foreach (explode("\n", $f3xxValue) as $l)
					{
						if (preg_match("/^<\\[([a-z0-9])\\] (.*)>$/", $l, $match))
						{
							$tag = $match[1];
							$label = $match[2];
						}
						elseif (preg_match("/^:(.*)$/", $l, $match))
						{
							$sf = $f3xx->addSubField($tag, trim($match[1]));
							$sf['l'] = htmlentities($label, null, 'UTF-8');
							$tag = "";
							$label = "";
						}
					}
				}
				else
				{
					$tm->addField($f3xxNum)->addSubField('a', $f3xxValue);
				}
			}
		}

		switch ($this->getAuthorityType())
		{
			case AuthorityPeer::TYPE_SUBJECT:
				if ($this->authority->isNew()) // save to have a valid ID
					$this->authority->save();
				
				$f250 = $tm->addField('250');
				$parts = array();
				$pos = 0;
				$this->authority->setSubjectClass($this->SubjectType->getSelectedValue());
				$parent = AuthorityQuery::create()->findPk(intval($this->ParentAuthID->getValue()));
				
				if ($parent instanceof Authority 
						&& ($parent->getAuthorityRectype() != AuthorityPeer::RECTYPE_NODE))
				{
					$l = new LSubject();
					$l->setSubjectId($this->authority->getAuthorityId());
					$l->setAuthorityId($parent->getAuthorityId());
					$l->setPosition($pos);
					$l->setType($parent->getAuthorityType());
					
					$l->save();
					
					$f250->addSubField('a', $parent->getFullText());
					++$pos;
				}
				
				foreach ($this->SubjectParts->getItems() as $item)
				{
					$part = AuthorityQuery::create()->findPk($item->SubjPartID->getValue());
				
					if ($part instanceof Authority 
							&& ($part->getAuthorityRectype() != AuthorityPeer::RECTYPE_NODE))
					{
						$l = new LSubject();
						$l->setSubjectId($this->authority->getAuthorityId());
						$l->setAuthorityId($part->getAuthorityId());
						$l->setPosition($pos);
						$l->setType($item->SubjPartType->getSelectedValue());
						$l->setConnector($item->SubjPartConnector->getText());
						
						$l->save();
						
						$f250->addSubField('c', $item->SubjPartConnector->getText());
						$f250->addSubField('x', $part->getFullText());
						++$pos;
					}
				}
				
				$f250->addSubField('2', $this->SubjectType->getSelectedValue());
				break;

			case AuthorityPeer::TYPE_ARGUMENT:
			case AuthorityPeer::TYPE_PLACE:
			case AuthorityPeer::TYPE_CHRONOLOGICAL:
				$f931 = $tm->addField(931);
				$f931->addSubField('a', $this->Title->getText());
				//$f931->addSubField('2',$this->ArgumentSubjectCode->getSelectedValue());
				$this->authority->setSortText((string) $f931->sa);
				break;

			case AuthorityPeer::TYPE_CLASS:
				$ctype = $this->ClassType->getSelectedValue();
				
				switch ($ctype)
				{
					case '676':
					case '680':
						$f6xx = $tm->addField($ctype);
						break;
				
					default:
						$f6xx = $tm->addField('686');
						$f6xx->addSubField('2', $ctype);
						break;
				}
				
				$this->authority->setSubjectClass($ctype);
				$f6xx->addSubField('a', $this->ClassCode->getText());
				$f6xx->addSubField('c', $this->ClassString->getText());
				$f6xx->addSubField('v', $this->ClassEdition->getSelectedValue());
				$itemCode = $this->ClassItemCode->getText();
				
				if (!trim($itemCode))
					$itemCode = $this->ClassCode->getText();
				
				$f6xx->addSubField('i', $itemCode);
				$this->authority->setClassCode($this->ClassCode->getText());
				$this->authority->setSortText($this->authority->getClassCode() . ' ' . $f6xx->sc);
				break;

			case AuthorityPeer::TYPE_PRINTERSDEVICE:
				$f921 = $tm->addField(921);
				// care, the order we set the subfields matters for SBN diff/sync
				$f921->addSubField('c', substr($this->PrnIndex->getSelectedValue(), 0, 1) . $this->PrnQuotation->getText());
				
				if (trim($this->PrnDescription->getText()))
					$f921->addSubField('a', $this->PrnDescription->getText());
				
				for ($idx = 0; $idx < 5; ++$idx)
				{
					$ctrl = "PrnKeyword{$idx}";
				
					if (trim($this->$ctrl->getSafeText()))
						$f921->addSubField('b', trim($this->$ctrl->getText()));
				}
				
				$f921->addSubField('d', $this->PrnNote->getText());
				$f921->addSubField('e', $this->PrnWatchword->getText());
				$this->authority->setSortText((string) $f921->sa);
				break;

			case AuthorityPeer::TYPE_WORK:
				foreach ($this->RepF5XX->Items as $item)
				{
					$f5xxBid = trim($item->F5XXBid->getValue());
					$f5xxNum = $item->F5XXField->getSelectedValue();
					$f5xxValue = trim(str_replace(array('\n', '\r'), array(' ', ''), $item->F5XXValue->getText()));
				
					if ($f5xxValue != '')
					{
						$f5xx = $tm->addField($f5xxNum);
						$f5xx->addSubField('a', $f5xxValue);
						$f5xx->addSubField(strtolower($bid_source), $f5xxBid);
					}
				}
				
				$this->authority->setSortText($this->Title->getText());
				$tm->addField('230');
				$tm->d230->addSubField('a', $this->Title->getText());
				$tm->d230->addSubField('w', $this->WorkType->getSelectedValue());
				
				if (isset($lang))
					$tm->d230->addSubField('m', $lang);
				
				break;

			case AuthorityPeer::TYPE_CORPORATEBODYNAME:

				$text = html_entity_decode($this->Title->getText());
				$this->authority->setSortText($text);
				
				switch ($this->NameForm->getSelectedValue())
				{
					case 'R': $i1 = '1';
						$i2 = ' ';
						break;
				
					case 'G': $i1 = '0';
						$i2 = '1';
						break;
					
					case 'E': $i1 = '0';
						$i2 = '2';
						break;
					
					default: $i1 = '1';
						$i2 = ' ';
						break;
				}
				
				$f200 = $tm->addField('210', $i1, $i2);
				$f200->addSubField('i', $this->NameForm->getSelectedValue());
				
				switch ($this->NameForm->getSelectedValue())
				{
					case 'R':
						$f200->addSubField('a', trim(strtok($text, '<')));
				
						while ($v = trim(strtok(';'), '>'))
						{
							if (substr_compare($v, '. ', -2, 2) === 0)
							{		
								$f200->addSubField('d', trim($v, '<; '));
							}
							elseif (substr_compare($v, 'fl.', 0, 3) == 0 || substr_compare($v, 'm.', 0, 2) == 0 || substr_compare($v, 'n.', 0, 2) == 0 || substr_compare($v, 'sec.', 0, 4) == 0 || substr_compare($v, 'ca.', 0, 3) == 0 || preg_match('!^\s*\d{4}!', $v) > 0)
							{
								$f200->addSubField('f', trim($v, '<; '));
							}
							else
							{
								$f200->addSubField('e', trim($v, '<; '));
							}
						}
						
						break;
					
					case 'E':
						$f200->addSubField('a', trim(strtok($text, '<')));
					
						while ($v = trim(strtok(';'), '>'))
						{
							if (substr_compare($v, 'fl.', 0, 3) == 0 || substr_compare($v, 'm.', 0, 2) == 0 || substr_compare($v, 'n.', 0, 2) == 0 || substr_compare($v, 'sec.', 0, 4) == 0 || substr_compare($v, 'ca.', 0, 3) == 0 || preg_match('!^\s*\d{4}!', $v) > 0)
							{
								$f200->addSubField('f', trim($v, '<; '));
							}
							else
							{
								$f200->addSubField('c', trim($v, '<; '));
							}
						}
						
						break;
						
					case 'G':
						$parts = explode(' : ', $text);
						
						foreach ($parts as $k => $p)
						{
							$split = explode(' <', $p, 2);
							$f200->addSubField(0 == $k ? 'a' : 'b', array_shift($split));
							
							if ($split)
							{	
								foreach (explode(' ; ', $split[0]) as $sfc)
									$f200->addSubField('c', trim($sfc, '>; '));
							}
						}
						
						break;
				}
				
				break;

			case AuthorityPeer::TYPE_TRADEMARK:
				if (!isset($fnum))
					$fnum = '216';
				
			case AuthorityPeer::TYPE_FAMILYNAME:
				if (!isset($fnum))
					$fnum = '220';
				
			case AuthorityPeer::TYPE_PERSONALNAME:
				if (!isset($fnum))
					$fnum = '200';

				$text = html_entity_decode($this->Title->getText());
				$this->authority->setSortText($text);
				
				switch ($this->NameForm->getSelectedValue())
				{
					case 'A': $i2 = '0';
						break;
					
					case 'B': $i2 = '0';
						break;
					
					case 'C': $i2 = '1';
						break;
					
					case 'D': $i2 = '1';
						break;
					
					default: $i2 = '0';
						break;
				}
				
				$f200 = $tm->addField($fnum, ' ', $i2);
				unset($fnum);
				$f200->addSubField('i', $this->NameForm->getSelectedValue());
				
				if (0 == $i2)
				{
					$f200->addSubField('a', trim(strtok($text, '<')));
				}
				else
				{
					$f200->addSubField('a', trim(strtok($text, ',')));
					$f200->addSubField('b', ', ' . trim(strtok('<')));
				}
				
				while ($v = trim(strtok(';'), '>'))
				{
					if (substr_compare($v, 'fl.', 0, 3) == 0 || substr_compare($v, 'm.', 0, 2) == 0 || substr_compare($v, 'n.', 0, 2) == 0 || substr_compare($v, 'sec.', 0, 4) == 0 || substr_compare($v, 'ca.', 0, 3) == 0 || preg_match('!^\s*\d{4}!', $v) > 0)
					{
						$f200->addSubField('f', trim($v, '<; '));
					}
					else
					{
						$f200->addSubField('c', trim($v, '<; '));
					}
				}
				
				break;

			case AuthorityPeer::TYPE_PUBPLACE:
				$text = $this->Title->getText();
				$this->authority->setSortText($text);
				$f200 = $tm->addField('260');
				
				if (count($country) > 0)
					$f200->addSubField('a', $country[0]);
				
				$f200->addSubField('c', $this->Region->getText());
				$f200->addSubField('d', $text);
				break;

			default:
				$text = $this->Title->getText();
				$this->authority->setSortText($text);
				break;
		}

		$this->AuthLinkedData->updateTurboMarc($tm);
		
		return TurboMarcUtility::sortFields($tm);
	}

	public function onSave($sender, $param)
	{
		// tweaks for big authorities
		Propel::disableInstancePooling();
		set_time_limit(0);
		ini_set('memory_limit', '512M');

		$this->loadAuthority();
		$wasNew = $this->authority->isNew();

		$tm = $this->buildUnimarc();
		$this->authority->setUnimarc($tm->asXML());


		$ret = $this->authority->save();
		
		/** Validity check
		 * 
		 * We don't want to create an authority with no real data, or as an error.
		 * For avoiding storing unuseful authorities, we will delete it from the DB.
		 */
		if ($this->authority->getSortText() == "")
		{
			$this->authority->delete();
			
			return false;
		}
		
		// call SBN update
		$this->SBNActions->updateToSBN();
		$this->authority->doIndex();

		ChangelogPeer::logAction(	$this->authority, 
									$wasNew 
										? ChangelogPeer::LOG_CREATE 
										: ChangelogPeer::LOG_UPDATE, 
									$this->getUser());

		if ($sender->getPage() instanceof AuthorityEditPopup)
		{
			$this->getApplication()->getSession()->add('NewAuthorityDelayedMessageFlag', true);
		}
		else
		{
			$url = Prado::getApplication()->getService()->constructUrl(	'Catalog.AuthorityViewPage',
																		array('id' => $this->authority->getAuthorityId()));
			
			$queue = "'<a href='" . $url . "'>" . $this->authority->getCompleteText() . "</a>'";
			
			$this->getPage()->writeMessage($wasNew
												? Prado::localize('Voce di authority inserita') . ": " . $queue
												: Prado::localize('Voce di authority salvata') . ": " . $queue, 
											ClavisMessage::CONFIRM);
		}
		
		$this->setAuthorityId($this->authority->getAuthorityId());
		
		return true;
	}

	public function globalRefresh()
	{
		$this->populate();
	}

	public function OnF5xxDataBound($sender, $param)
	{
		$item = $param->Item;
		$item->F5XXField->populateList();
		$item->F5XXField->setSelectedValue($item->DataItem['field']);
	}

	public function addTitle($sender, $param)
	{
		$items = $this->RepF5XX->getItems();
		$data = array();
		
		foreach ($items as $item)
		{
			$value = $item->F5XXValue->getText();
		
			if (trim($value) != '')
				$data[] = array(	'field' => $item->F5XXField->getSelectedValue(),
									'value' => $value,
									'bid' => $item->F5XXBid->getValue() );
		}
		
		$data[] = array(	'field' => 517, 
							'value' => '', 
							'bid' => '' );
		
		$this->RepF5XX->setDataSource($data);
		$this->RepF5XX->dataBind();
	}

	public function bindNotes($sender, $param)
	{
		$param->Item->NoteNumber->populate();
		$param->Item->NoteNumber->setSelectedValue($param->Item->DataItem['NoteNumber']);
	}

	public function addNote($sender, $param)
	{
		$items = $this->Notes->getItems();
		$data = array();
		
		foreach ($items as $item)
		{
			if (trim($item->NoteValue->getText()) != '')
			{
				$data[] = array(	'NoteNumber' => $item->NoteNumber->getSelectedValue(),
									'NoteValue' => $item->NoteValue->getText() );
			}
		}
		
		$data[] = array(	'NoteNumber' => 'a',
							'NoteValue' => '' );
		
		$this->Notes->setDataSource($data);
		$this->Notes->dataBind();
	}

	public function populateCountryList($List)
	{
		$country = array();
		
		foreach ($List as $c)
			$country[] = (string) $c->sa;
		
		$country[] = "";
		$this->CountryList->setDataSource($country);
		$this->CountryList->dataBind();
	}

	public function subjPartDatabind($sender, $param)
	{
		$item = $param->Item;

		if (($item->ItemType === 'Item')
				|| ($item->ItemType === 'AlternatingItem'))
		{
			$item->SubjPartConnector->setText($item->DataItem['PartConnector']);
			$item->SubjPartText->setText($item->DataItem['PartText']);
		}
	}

	public function onSuggestSubject($sender, $param)
	{
		$types = array(AuthorityPeer::TYPE_SUBJECT);
		$exclude = true;
		$prefix = $param->getToken();
		
		if (preg_match('!^\[(\w+)\](.*)!', $prefix, $matches) > 0)
		{
			$types = str_split($matches[1]);
			$exclude = false;
			$prefix = trim($matches[2]);
		}
		
		$authList = AuthorityPeer::doSuggest($prefix, 10, $types, $exclude);
		$authData = array();
		
		foreach ($authList as $auth)
		{
			/* @var $auth Authority */
			if (($auth instanceof Authority)
					&& ($auth->getAuthorityRectype() != AuthorityPeer::RECTYPE_NODE))
				$authData[] = array(	'id' => $auth->getAuthorityId(),
										'text' => $auth->getFullTextSpec() );
		}
		
		$sender->setDataSource($authData);
		$sender->dataBind();
	}

	public function onSuggestSubjectCallback($sender, $param)
	{
		$id = $sender->Suggestions->DataKeys[$param->selectedIndex];
		$authorityUp = AuthorityQuery::create()->findPk($id);
		$authorityUp = $authorityUp->getAcceptedAuthority();
		
		if ($authorityUp instanceof Authority 
				&& ($authorityUp->getAuthorityRectype() != AuthorityPeer::RECTYPE_NODE))
		{
			$this->ParentAuthID->setValue($authorityUp->getAuthorityId());
			$this->ParentAuthLink->setText($authorityUp->getFullText());
		}
		else
		{
			$this->ParentAuthID->setValue(null);
			$this->ParentAuthLink->setText('');
		}
	}

	public function onSuggestSubjPartCallback($sender, $param)
	{
		$id = $sender->Suggestions->DataKeys[$param->selectedIndex];
		$authorityUp = AuthorityQuery::create()->findPk($id);
		$authorityUp = $authorityUp->getAcceptedAuthority();
		
		foreach ($this->SubjectParts->getItems() as $item)
		{
			if ($item->SubjPartText->getUniqueID() == $sender->getUniqueID())
			{
				if ($authorityUp instanceof Authority 
						&& ($authorityUp->getAuthorityRectype() != AuthorityPeer::RECTYPE_NODE))
				{
					$item->SubjPartID->setValue($authorityUp->getAuthorityId());
					$item->SubjPartText->setText($authorityUp->getFullText());
				}
				else
				{
					$item->SubjPartID->setValue(null);
					$item->SubjPartText->setText('');
				}
			}
		}
	}

	public function onSubjPartCommand($sender, $param)
	{
		$data = array();
		$curitem = $param->getItem();
		
		switch ($param->getCommandName())
		{
			case 'add':
				$newpart = array(	'PartType' => 'A',
									'PartConnector' => '- ',
									'PartText' => '',
									'PartId' => '' );
				
				$items = $this->SubjectParts->getItems();
				
				foreach ($items as $item)
				{
					$data[] = array(	'PartType' => $item->SubjPartType->getSelectedValue(),
										'PartConnector' => $item->SubjPartConnector->getText(),
										'PartText' => $item->SubjPartText->getText(),
										'PartId' => $item->SubjPartID->getValue() );
					
					if ($item == $curitem)
						$data[] = $newpart;
				}
				
				break;
				
			case 'del':
				$items = $this->SubjectParts->getItems();
				
				if (count($items) < 2)
					break;
				
				foreach ($items as $item)
				{
					if ($item != $curitem)
						$data[] = array(	'PartType' => $item->SubjPartType->getSelectedValue(),
											'PartConnector' => $item->SubjPartConnector->getText(),
											'PartText' => $item->SubjPartText->getText(),
											'PartId' => $item->SubjPartID->getValue() );
				}
				
				break;
				
			default:
				break;
		}
		
		$this->SubjectParts->setDataSource($data);
		$this->SubjectParts->dataBind();
	}

	public function onSuggestSubjectConnector($sender, $param)
	{
		$prefix = $param->getToken();
		$cList = LSubjectPeer::getConnectors($prefix, 10);
		$sender->setDataSource($cList);
		$sender->dataBind();
	}

	public function onAddCountry($sender, $event)
	{
		$clist = array();
		$ilist = $this->CountryList->Items;
		
		foreach ($ilist as $item)
		{
			$c = $item->Country->getSelectedValue();
			if ($c != "0")
				$clist[] = $c;
		}
		
		$clist[] = "";
		$this->CountryList->setDataSource($clist);
		$this->CountryList->dataBind();
	}

	public function ChangeListType($sender, $param)
	{
		$this->authority->setAuthorityType($this->AuthorityTypeList->getSelectedValue());
		$this->setControlState('authority', $this->authority);
		$this->populate();
	}

	public function onNote3XXSelected($sender, $param)
	{
		$sbnNotes = array(
			"928" => "<[a] Forma della composizione musicale (Fino a tre codici) (Codice 1) (Tab FOMU, 2.13)>
:
<[a] Forma della composizione musicale (Fino a tre codici) (Codice 2) (Tab FOMU, 2.13)>
:
<[a] Forma della composizione musicale (Fino a tre codici) (Codice 3) (Tab FOMU, 2.13)>
:
<[b] Strumenti e voci che compongo l'organico sintetico (2.14.1)>
:
<[c] Strumenti e voci che compongo l'organico analitico (2.14.2)>
:",
			"929" => "<[a] Numero d'ordine (2.15)>
:
<[b] Numero d'opera (2.16)>
:
<[c] Numero di catalogo tematico (2.17)>
:
<[d] Datazione della composizione (2.18, max. car. 10)>
:
<[e] Tonalità della composizione (Tab TONO, 2.19, max 2 car.)>
:
<[f] Sezioni della composizione (2.20)>
:
<[g] Titolo di ordinamento della composizione>
:
<[h] Titolo estratto della composizione>
:
<[i] Titolo appellativo della composizione>
:"
		);

		$fld = $sender->getSelectedValue();
		
		if ($fld > 900)
		{
			$sender->getParent()->NoteValue->setText($sbnNotes[$fld]);
		}
	}

	public function onUnlinkBid($sender, $param)
	{
		if ($this->checkSBNLink($sender, $param) || true)		// maybe this IF statement is not useful
		{
			$this->authority->setBidSource(null);
			$this->authority->setBid($this->authority->getAuthorityId());
			$this->authority->setLastSbnSync(NULL);
			$tm = $this->authority->getTurboMarc();
			
			if (isset($tm->d099))
				unset($tm->d099);
			
			$this->authority->setUnimarc($tm->asXML());
			$this->authority->save();
			$this->Bid->setText('');
			$this->BidSource->setText('');
			$this->SBNActions->populate();
			$this->getPage()->writeMessage(Prado::localize('Dati sorgente correttamente eliminati.'), 
												ClavisMessage::CONFIRM);
		}
	}

	public function checkSBNLink($sender, $param)
	{
		$valid = true;
		if (!$this->_sbnMod->getEnabled() 
				|| ($this->authority->getBidSource() != 'SBN'))
		{
			$valid = true;
		}
		elseif (!$this->SBNActions->isUnlinkable())
		{
			$valid = false;
		}
		
		if (!is_null($param))
			$param->IsValid = true;
		
		return $valid;
	}

	public function countryRepeaterDataBound($sender, $param)
	{
		$item = $param->Item;
		
		if (($item->ItemType === 'Item') 
				|| ($item->ItemType === 'AlternatingItem'))
		{
			$item->Country->populateList();
			$item->Country->dataBind();
			$item->Country->SelectedValue = $item->DataItem;
		}
	}

	public function getCountries()
	{
		$clist = array();
		$ilist = $this->CountryList->Items;
		
		foreach ($ilist as $item)
		{
			$c = $item->Country->getSelectedValue();
			
			if ($c != "0")
				$clist[] = $c;
		}
		
		return $clist;
	}
	
}