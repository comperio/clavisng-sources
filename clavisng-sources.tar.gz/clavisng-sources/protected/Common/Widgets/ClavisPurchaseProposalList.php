<?php
/**
 * ClavisPurchaseProposalList class file
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 */

/**
 * ClavisPurchaseProposalList class
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Widgets
 * @since 2.3
 */
class ClavisPurchaseProposalList extends TTemplateControl {

	const PAGESIZE = 10;

	public function onLoad($param) {
		parent::onLoad($param);
		if (!$this->getPage()->getIsPostBack()) {
			$librariesWithBlank = LibraryPeer::getLibrariesHash(array(LibraryPeer::BLANKVALUE),array('---'));
			$this->LibraryFilter->setDataSource($librariesWithBlank);
			$this->LibraryFilter->dataBind();
			$this->populatePurchaseProposalList();
		}
	}

	public function setPageSize($size = 10)
	{
		setcookie('TClavisDataGridPageSize', $size);
		$this->setControlState('PageSize', $size, 10);
	}

	public function getPageSize()
	{
		$size = $this->getControlState('PageSize', 10);

		if (($size > 0) && ($size < 1000))
			return $size;
		else
			return 10;
	}

	public function populate() {
		$this->populatePurchaseProposalList();
	}

	private function resetFilters()
	{
		$this->ExpiredFilter->setChecked(true);
		$this->ResultLabel->setText('');
		$this->FakeLabel->setValue('');
		$this->PatronFilterId->setValue('');

		$this->LibraryFilter->setSelectedIndex(-1);
		$this->StatusFilter->setSelectedIndex(-1);

		$this->resetPagination();
	}

	private function resetPagination()
	{
		$this->setCurrentPage(0);
		$this->PurchaseProposalList->setCurrentPageIndex(0);
	}

	public function setCurrentPage($page)
	{
		$this->setViewState('CurrentPage', $page, 0);
	}

	public function getCurrentPage()
	{
		return $this->getViewState('CurrentPage', 0);
	}

	public function onPageChanged($sender, $param)
	{
		$newPage = $param->NewPageIndex;
		$this->PurchaseProposalList->setCurrentPageIndex($newPage);
		$this->setCurrentPage($newPage);
		$this->populate();
	}

	public function onChangePageSize($sender, $param)
	{
		$newPageSize = intval($sender->getSelectedValue());
		if ($newPageSize > 0)
		{
			$this->setPageSize($newPageSize);
			$this->resetPagination();
			//$this->globalRefresh();

			$this->populate();
		}
	}

	private function populatePurchaseProposalList() {
		$criteria = new Criteria();

		if ($this->ExpiredFilter->getChecked())
			$criteria->add(PurchaseProposalPeer::STATUS,PurchaseProposalPeer::STATUS_PENDING);

		if (intval($this->FakeLabel->getValue())) {
			$p = PatronPeer::retrieveByPK(intval($this->FakeLabel->getValue()));
			if ($p instanceof Patron)
				$this->ResultLabel->setText($p->getCompleteName());
			$this->FakeLabel->setValue('');
		}

		$patron_id = intval($this->PatronFilterId->getValue());
		$status = $this->StatusFilter->getSelectedValue();
		$library = $this->LibraryFilter->getSelectedValue();
		if ($patron_id)
			$criteria->add(PurchaseProposalPeer::PATRON_ID,$patron_id);
		if ($status) {
			$this->ExpiredFilter->setChecked(false);
			$criteria->add(PurchaseProposalPeer::STATUS,$status);
		}
		if ($library) {
			$criteria->add(PatronPeer::PREFERRED_LIBRARY_ID,$library);
		}

		$recCount = PurchaseProposalPeer::doCountJoinPatron($criteria);
		$this->RecCounter->setText($recCount);
		$this->PurchaseProposalList->setVirtualItemCount($recCount);
		$currentPage = $this->getCurrentPage();
		$pageSize = $this->getPageSize();
		$criteria->setLimit($pageSize);
		$criteria->setOffset($currentPage * $pageSize);
		$this->PurchaseProposalList->setPageSize($pageSize);

		$proposals = PurchaseProposalPeer::doSelectJoinPatron($criteria, null, Criteria::INNER_JOIN);
        $this->PurchaseProposalList->setDataSource($proposals);
		$this->PurchaseProposalList->dataBind();

	}

	public function expireCheckChange($sender,$param) {
		$this->PurchaseProposalList->SelectedItemIndex = -1;
		$this->PurchaseProposalList->EditItemIndex = -1;
		$this->populatePurchaseProposalList();
	}

	public function searchProposal($sender, $param) {

		$this->populatePurchaseProposalList();
		$this->getPage()->globalRefresh();
	}

	public function itemDataBound($sender,$param) {
		$item = $param->Item;
		if ($item->ItemType==='EditItem') {
			$item->NewStatus->populateList();
			$itemid = intval($item->DataItem->getItemId());
			if ($itemid>0) {
				$item->ItemId->setValue($itemid);
				$i = ItemPeer::retrieveByPK($itemid);
				$item->ItemResultLabel->setText($i->getTitle());
				$item->ItemId->dataBind();
				$item->ItemResultLabel->dataBind();
			}
		}
	}

	public function suggestPatron($sender,$param) {
		$token = $param->getToken();
		$sender->setDataSource(PatronPeer::doSuggest($token, 10, true,true));
		$sender->dataBind();
	}

	public function selectedPatron($sender,$param) {
		$fieldText = trim($this->ResultLabel->getSafeText());
		if ($fieldText == "")
			return;

		$match = array();
		if (preg_match("/\(([^\)]+)\)\$/", $fieldText, $match))
			$patronBarcode = $match[1];
		else
			$patronBarcode = $fieldText;

		/** @var $patrons PropelObjectCollection */
		$patrons = PatronPeer::getPatronsByBarcode($patronBarcode);

		if ($patrons->isEmpty())
		{
			$this->ResultLabel->setText('');
			return;
		}

		$patron = $patrons->shift();
		if (!$patrons->isEmpty())
		{
			// TODO: notifica di barcodes utente duplicati
			// Per adesso lo fa la ClavisUserDataCard
		}

		if ($patron instanceof Patron)
		{
                        $this->PatronFilterId->setValue($patron->getPatronId());
		}
	}

	public function onCancel() {
		$this->searchCancel(null, null);
	}

	public function searchCancel($sender, $param)
	{
		$this->resetFilters();
		$this->searchProposal(null, null);
	}

	public function cancelItem($sender,$param) {
		$this->PurchaseProposalList->SelectedItemIndex = -1;
		$this->PurchaseProposalList->EditItemIndex = -1;
		$this->populatePurchaseProposalList();
    }

	public function editItem($sender,$param) {
		$this->PurchaseProposalList->SelectedItemIndex = -1;
        $this->PurchaseProposalList->EditItemIndex = $param->Item->ItemIndex;
		$this->populatePurchaseProposalList();
	}

	public function deleteItem($sender,$param) {
		$this->PurchaseProposalList->SelectedItemIndex = -1;
        $this->PurchaseProposalList->EditItemIndex = -1;
        $this->populatePurchaseProposalList();
	}

	public function selectItem($sender,$param) {
		$this->PurchaseProposalList->EditItemIndex = -1;
		$this->populatePurchaseProposalList();
	}

	public function updateItem($sender,$param) {
		$item = $param->Item;
		try {
			$p = PurchaseProposalPeer::retrieveByPK(
				$this->PurchaseProposalList->DataKeys[$item->ItemIndex]);
			$ean = preg_replace('/[^\d]/','',trim($item->NewEAN->getText()));
			$p->setEan(intval($ean));
			$p->setRda($item->NewRDA->getSafeText());
			$p->setItemId(intval($item->ItemId->getValue()));
    	    $p->setStatus($item->NewStatus->getSelectedValue());
    	    $p->setLibrarianNotes($item->LibrarianNotes->getSafeText());
        	$p->setDateUpdated(time());
        	$p->setModifiedBy($this->getUser()->getID());
        	$p->save();
			$this->PurchaseProposalList->EditItemIndex = -1;
			$this->PurchaseProposalList->SelectedItemIndex = -1;
			$this->getPage()->writeMessage(Prado::localize('Proposta correttamente aggiornata.'),ClavisMessage::CONFIRM);
		} catch (Exception $e) {
			$this->getPage()->writeMessage(Prado::localize('Impossibile completare l\'aggiornamento: {msg}',
				array('msg'=>$e->getMessage())),ClavisMessage::CONFIRM);
		}
		$this->populatePurchaseProposalList();
	}

	public function onPatronClean($sender, $param) {
		$this->ResultLabel->setText('');
		$this->PatronFilterId->setValue(0);
		$this->getPage()->setFocus($this->ResultLabel->getClientID());
	}

	public function calculateSortingCriteria(&$sortingCriteria = null)
	{
		$sortingExpression = $this->getSortingExpression();
		$sortingDirection = $this->getSortingDirection();

		if (is_null($sortingCriteria) || !($sortingCriteria instanceof Criteria))
			$sortingCriteria = new Criteria();

		switch ($sortingExpression)
		{
			case 'title':  // ShelfName
				$sortingCriteria->clearOrderByColumns();
				if ($sortingDirection == self::SORTDIRECTION_ASC)
					$sortingCriteria->addAscendingOrderByColumn(ItemPeer::TITLE);
				elseif ($sortingDirection == self::SORTDIRECTION_DESC)
					$sortingCriteria->addDescendingOrderByColumn(ItemPeer::TITLE);
				break;

			case 'PatronColumn': // LibrarianName
				$sortingCriteria->clearOrderByColumns();
				$sortingCriteria->addJoin(ItemPeer::PATRON_ID, PatronPeer::PATRON_ID, 'LEFT JOIN');
				if ($sortingDirection == self::SORTDIRECTION_ASC)
				{
					$sortingCriteria->addAscendingOrderByColumn(PatronPeer::LASTNAME);
					$sortingCriteria->addAscendingOrderByColumn(PatronPeer::NAME);
				}
				elseif ($sortingDirection == self::SORTDIRECTION_DESC)
				{
					$sortingCriteria->addDescendingOrderByColumn(PatronPeer::LASTNAME);
					$sortingCriteria->addDescendingOrderByColumn(PatronPeer::NAME);
				}

				break;

			case 'libraryId': // biblioteca

				$loanStatuses = $this->getLoanStatusMode();

				if ($this->_loanmanager->IsOutStatus($loanStatuses))
				{
					$sortingCriteria->clearOrderByColumns();
					//$libraryId = $item->getDeliveryLibraryId();

					$sortingCriteria->addJoin(ItemPeer::DELIVERY_LIBRARY_ID, LibraryPeer::LIBRARY_ID);
					if ($sortingDirection == self::SORTDIRECTION_ASC)
						$sortingCriteria->addAscendingOrderByColumn(LibraryPeer::LABEL);
					elseif ($sortingDirection == self::SORTDIRECTION_DESC)
						$sortingCriteria->addDescendingOrderByColumn(LibraryPeer::LABEL);
				}

				elseif (in_array(ItemPeer::LOANSTATUS_TOSHELF, $loanStatuses))
				{
					$sortingCriteria->clearOrderByColumns();

					$sortingCriteria->addJoin(LibraryPeer::LIBRARY_ID, ItemPeer::ACTUAL_LIBRARY_ID);
					$sortingCriteria->setDistinct();
					if ($sortingDirection == self::SORTDIRECTION_ASC)
						$sortingCriteria->addAscendingOrderByColumn(LibraryPeer::LABEL);
					elseif ($sortingDirection == self::SORTDIRECTION_DESC)
						$sortingCriteria->addDescendingOrderByColumn(LibraryPeer::LABEL);
				}

				elseif ($this->_loanmanager->IsInStatus($loanStatuses))
				{
					$sortingCriteria->clearOrderByColumns();

					$sortingCriteria->addJoin(LoanPeer::LOAN_ID, ItemPeer::CURRENT_LOAN_ID);
					$sortingCriteria->addJoin(LoanPeer::FROM_LIBRARY, LibraryPeer::LIBRARY_ID);
					$sortingCriteria->setDistinct();
					if ($sortingDirection == self::SORTDIRECTION_ASC)
						$sortingCriteria->addAscendingOrderByColumn(LibraryPeer::LABEL);
					elseif ($sortingDirection == self::SORTDIRECTION_DESC)
						$sortingCriteria->addDescendingOrderByColumn(LibraryPeer::LABEL);
				}

				break;

			case 'illTimeStamp':
				$sortingCriteria->clearOrderByColumns();
				if ($sortingDirection == self::SORTDIRECTION_ASC)
					$sortingCriteria->addAscendingOrderByColumn(ItemPeer::ILL_TIMESTAMP);
				elseif ($sortingDirection == self::SORTDIRECTION_DESC)
					$sortingCriteria->addDescendingOrderByColumn(ItemPeer::ILL_TIMESTAMP);
				break;

			case 'lastSeen':  // ultimo movimento
				$sortingCriteria->clearOrderByColumns();
				if ($sortingDirection == self::SORTDIRECTION_ASC)
					$sortingCriteria->addAscendingOrderByColumn(ItemPeer::LAST_SEEN);
				elseif ($sortingDirection == self::SORTDIRECTION_DESC)
					$sortingCriteria->addDescendingOrderByColumn(ItemPeer::LAST_SEEN);
				break;

			case null:
				break;

			default:
				$sortingExpression = null;
				break;
		}
	}

}
