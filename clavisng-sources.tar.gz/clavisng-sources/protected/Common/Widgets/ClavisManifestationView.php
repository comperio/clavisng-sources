<?php
/**
 * ClavisManifestationView class
 * 
 * Component which shows the data of a single manifestation.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @version 2.7
 * @package Widgets
 * @since 2.0
 */
class ClavisManifestationView extends TTemplateControl
{
	/* @var Manifestation */
	private $_manifestation = null;
	private $_manifestationSessionName;

	private function initVars()
	{
		$uniqueId = $this->getUniqueID();
		$this->_manifestationSessionName = 'ClavisManifestationViewManifestationSessionName' . $uniqueId;
	}

	public function onInit($param)
	{
		parent::onInit($param);
		$this->initVars();

		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallback())
		{
			$this->resetManifestation();
		}
	}

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsPostBack())
		{
			$this->getManifestation();
			$this->populate();
		}
	}

	public function resetManifestation()
	{
		$this->setManifestation(null);
	}

	public function setManifestation($manifestation = null)
	{
		$this->_manifestation = $manifestation;
		$this->getApplication()->getSession()->add($this->_manifestationSessionName, $this->_manifestation, null);
	}

	public function getManifestation()
	{
		$this->_manifestation = $this->getApplication()->getSession()->itemAt($this->_manifestationSessionName, null);
		return $this->_manifestation;
	}

	public function setInvisibleIfNull($boolean)
	{
		$this->setControlState("InvisibleIfNull", $boolean, false);
	}

	public function getInvisibleIfNull()
	{
		$boolean = $this->getControlState("InvisibleIfNull", false);
		if ($boolean === true)
			return true;
		else
			return false;
	}

	public function populate()
	{
		$this->_manifestation = $this->getManifestation();

		if (!$this->_manifestation instanceof Manifestation)
		{
			$this->ManifestationViewPanel->setCssClass('panel_off');
		}
		else
		{
			$this->ManifestationViewPanel->setCssClass('panel_on');
			$this->BibLevel->setText($this->_manifestation->getBibLevelLabel());
			$this->BibType->setText($this->_manifestation->getBibTypeLabel());

			$title = '<b>' . $this->_manifestation->getCompleteTitle() . '</b><br />' . $this->_manifestation->getAuthor();
			$this->Title->setText($title);
			$this->Title->setNavigateUrl('index.php?page=Catalog.Record&manifestationId=' . $this->_manifestation->getManifestationId());

			$year = $this->_manifestation->getEditionDate();
			$this->Year->setText($year);

			$language = LookupValuePeer::getLookupValue('LANGUAGES', $this->_manifestation->getEditionLanguage());
			$this->Language->setText($language);

			$manId = $this->_manifestation->getManifestationId();
			$con = Propel::getConnection();
			$classesAuthorities = $con->query("
                select a.authority_id,a.full_text,l.link_note
                from authority a
                join l_authority_manifestation l on l.authority_id = a.authority_id
                where l.link_type = '676' and l.manifestation_id = {$manId}
                UNION
                select a2.authority_id, a2.full_text,l1.link_note
                from authority a2
                join l_authority l1 ON l1.authority_id_up = a2.authority_id
                join l_authority_manifestation l on l.authority_id = l1.authority_id_down
                where l.link_type = '500' and l.manifestation_id = {$manId} and l1.link_type = 'KL'
                UNION
                select a2.authority_id, a2.full_text,l1.link_note
                from authority a2
                join l_authority l1 ON l1.authority_id_down = a2.authority_id
                join l_authority_manifestation l on l.authority_id = l1.authority_id_up
                where l.link_type = '500' and l.manifestation_id = {$manId} and l1.link_type = 'LK'
            ")->fetchAll();


			$this->Classes->setDataSource($classesAuthorities);
			$this->Classes->dataBind();
		}

		if ($this->getPage()->getIsCallBack())
		{
			$this->ManifestationViewPanel->render($this->getPage()->createWriter());
		}

		return;
	}

	public function update($manifestationId = 0)
	{
		$manifestationId = intval($manifestationId);
		if ($manifestationId > 0)
		{
			$manifestation = ManifestationPeer::retrieveByPK($manifestationId);
			if ($manifestation instanceof Manifestation)
			{
				$this->setManifestation($manifestation);
				$this->populate();
			}
		}
	}

	public function clean()
	{
		$this->resetManifestation();
		$this->populate();
	}
	
}