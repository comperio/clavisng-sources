<?php
/**
 * ClavisPatronSummary class file.
 *
 * This file contains all the required classes for SBN dialogue v4.
 * Based upon SBNConnector by Comperio srl.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Widgets
 */

/**
 * ClavisPatronSummary Class
 * 
 * Very short summary of patron's data: used as an always visible summary atop a tab panel
 *
 * @author Max Pigozzi <mpigozzi@e-portaltech.it>
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.7
 * @package Widgets
 * @since 2.0
 */
class ClavisPatronSummary extends TTemplateControl
{
	private $_patron;

	public function onInit($param)
	{
		parent::onInit($param);
		
		$this->attachEventHandler("OnLoanUpdated", array($this, 'onLoanUpdated'));
		$this->attachEventHandler("OnFeeUpdated", array($this, 'onFeeUpdated'));
	}

	public function onLoanUpdated($sender, $param)
	{
		$this->populateView($this->getPatronId());
	}

	public function onFeeUpdated($sender, $param)
	{
		//Prado::log(__METHOD__);
		$this->populateView($this->getPatronId());
	}

	public function populate($id = null)
	{
		if ($this->getIsNew())
		{
			$this->newPatronView->setVisible(true);
			$this->existingPatronView->setVisible(false);
			$this->ErrorPatron->setVisible(false);
		}
		else
		{
			$this->populateView($id);
		}
	}

	public function populateView($id = null)
	{
		$ok = false;
		$id = intval($id);

		$this->AlertNote->setText("");

		if ($id > 0)
		{
			$this->_patron = PatronQuery::create()->findPk($id);
			if ($this->_patron instanceof Patron)
			{
				$this->setPatronId($id);
				$ok = true;
				$this->existingPatronView->setVisible(true);
				$this->newPatronView->setVisible(false);
				$this->ErrorPatron->setVisible(false);
				$this->Name->setText($this->_patron->getReverseCompleteName());
				$this->BirthDate->setValue($this->_patron->getBirthDate('U'));

				if ($this->getApplication()->getModule("fee") instanceof TModule)
					if ($this->getApplication()->getModule("fee")->patronHasFee($this->_patron))
					{
						$this->AlertNote->setText(Prado::localize("L'utente ha riammissioni"));
						//Prado::log(__FILE__ ." " .__LINE__);
					}

				if ($this->_patron->hasLateLoans())
				{
					$this->AlertNote->setText($this->AlertNote->getText() . " " . Prado::localize("L'utente ha prestiti in ritardo"));
					//Prado::log(__FILE__ ." " .__LINE__);
				}
				if ($this->_patron->hasPendingWallets())
				{
					$this->AlertNote->setText($this->AlertNote->getText() . " " . Prado::localize("L'utente ha pagamenti in sospeso"));
					//Prado::log(__FILE__ ." " .__LINE__);
				}
                if (!$this->_patron->getPrivacyApprove() )
                {
                    $this->AlertNote->setText($this->AlertNote->getText() . " " . Prado::localize("L'utente non ha accettato l'informativa"));
                    //Prado::log(__FILE__ ." " .__LINE__);
                }
			}
		}

		if (!$ok)
		{
			$this->existingPatronView->setVisible(false);
			$this->newPatronView->setVisible(false);
			$this->ErrorPatron->setVisible(true);
		}
	}

	public function setPatronId($patronId)
	{
		$this->setControlState("patronid", $patronId, null);
	}

	public function getPatronId()
	{
		return $this->getControlState("patronid", null);
	}

	public function setIsNew($isNew)
	{
		$isNew = TPropertyValue::ensureBoolean($isNew);
		$this->setControlState("is_new", $isNew, false);
	}

	public function getIsNew()
	{
		return $this->getControlState("is_new", false);
	}

	public function isUnlink()
	{
		return false;
	}

	public function isPopup()
	{
		return false;
	}
	
}