<?php
/**
 * ClavisItemActions class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Widgets
 */

/**
 * ClavisItemActions class
 *
 * Displays a grid with all item actions
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @version 2.7
 * @package Widgets
 * @since 2.2
 */

class ClavisItemActions extends TTemplateControl
{
	private $_item_id;
	private $_librarian_id;
	private $_patron_id;
	private $_item_request = null;
	private $_item_request_patron_id;
	protected $_loanmanager = null;
	protected $_requestManager;
	private $_extraModeSessionName;
	public $_requestTypeActive;

	private function initVars()
	{
		$uniqueId = $this->getUniqueID();
		$this->_loanmanager = Prado::getApplication()->getModule('loan');
		$this->_requestManager = Prado::getApplication()->getModule('request');
		$this->_extraModeSessionName = 'ExtraModeSessionName' . $uniqueId;
		$this->_requestTypeActive = ItemRequestPeer::isRequestType();
	}

	public function onInit($param)
	{
		parent::onInit($param);
		$this->initVars();

		// if in the first page cycle
		if (!$this->getPage()->getIsPostBack()
				&& !$this->getPage()->getIsCallback())
		{
			$actualLibraryId = $this->getUser()->getActualLibraryId();
			$libraries = LibraryPeer::getLibrariesHash(null, null, true, true);

			$this->ReserveDeliveryLibrary->setDataSource($libraries);
			$this->ReserveDeliveryLibrary->dataBind();
			$this->ReserveDeliveryLibrary->setSelectedValue($actualLibraryId);

			if ($this->_requestTypeActive)
			{	
				$this->RequestTypeList->setDataSource(ItemRequestPeer::getRequestTypes(	true, 	// with blank
																						null, 
																						null));	// all itemrequest types

				$this->RequestTypeList->dataBind();
			}

			$this->DeliveryLibrary->setDataSource($libraries);
			$this->DeliveryLibrary->dataBind();
			$this->DeliveryLibrary->setSelectedValue($actualLibraryId);

			$this->AbortType->setDataSource(LookupValuePeer::getLookupClassValues(	'ITEMACTIONTYPE',
																					null,
																					null,
																					ItemActionPeer::getAbortTypes()));
			$this->AbortType->dataBind();
			$this->AbortType->setSelectedValue(ItemActionPeer::TYPE_ABORTGENERIC);

			$this->globalReset();
		}
		$this->attachEventHandler('OnClavisClientMessage', array($this, 'OnClavisClientMessage'));
	}
	
	public function OnClavisClientMessage($sender, $param)
	{
		$cbparam = $param->getParameter();
		$ccdata = $cbparam->getCallbackParameter();
		$cmd = $ccdata->command;
		
		//ClavisClient is replying to a pollscan
		if($cmd == 'pollscan')
		{
			$tags = RfidUtil::getTagsFromJson($ccdata->jsontags);
			$ptags = $tags[RfidUtil::TAG_TYPE_PATRON];
			$nrptags = count($ptags);
			if($nrptags == 1)
			{
				$barcode = $ptags[0]->itemid;
				if($barcode != '')
				{
					//$this->ReservePatronLabel->setText($barcode);
					if ($this->PanelReserve->getVisible())   // prenotazione
					{
						$this->ReservePatronLabel->setText($barcode);
					}
					elseif ($this->PanelLoan->getVisible())     // prestito
					{
						$this->PatronLabel->setText($barcode);
					}
					else
					{
						return;
					}
					$this->suggestPatronCallBack($sender,$cbparam);
				}
			}
		}
	}

	public function onLoad($param)
	{
		parent::onLoad($param);

		$this->SendMailCheck->setVisible(false);

		$viewAlienCheck = false;
		$myLibraryId = $this->getUser()->getActualLibraryId();

		$item = (object) null;
		$itemId = intval($this->getItemId());

		if ($itemId > 0)
			$item = ItemQuery::create()->findPK($itemId);

		if ($item instanceof Item)
		{
			$this->drawSendMailCheck();

			if ($item->isExternal() && $item->isOutOfOwner())
				$viewAlienCheck = true;

			$allowed_actions = array();

			if (!is_null($this->_librarian_id) && !is_null($this->_patron_id))
			{
				$patron = null;
				$clavisLibrarian = null;
				$patron = PatronQuery::create()->findPK($this->getPatronId());
				$clavisLibrarian = LibrarianQuery::create()->findPK($this->getLibrarianId());

				$allowed_actions = $this->_loanmanager->CalculateItemActions($item, $patron, $clavisLibrarian, $myLibraryId);
			}
			else
			{
				$allowed_actions = $this->_loanmanager->CalculateItemActions($item, null, null, $myLibraryId);
			}

			foreach($allowed_actions as $action)
			{
				switch ($action)
				{
					case ItemActionPeer::TYPE_LOAN: //'A' --> "Prestito"
						$this->Loan->setVisible(true);
						break;

					case ItemActionPeer::TYPE_RETURN: //'B' --> "Rientro"
					case ItemActionPeer::TYPE_EXTRARETURN: //'L' --> "Rientro da extra sistema"
					case ItemActionPeer::TYPE_CONSULTRETURN: //'R' --> "Rientro da consultazione"
						$this->Return->setVisible(true);     //Enabled = true;

						break;

					case ItemActionPeer::TYPE_RENEWAL: //'C' --> "Rinnovo"
						$this->Renew->setVisible(true); //Enabled = true;
						$this->Renew->setPopupPage("Circulation.RenewItemPopup&objectType=Item&param=" . $itemId);

						if ($item->isAskRenew($myLibraryId))
						{
							$this->AskRenew->setVisible(true);  // abilitare pulsante per chiedere rinnovo in caso di extraprestito da fuori
							$this->AskRenew->setPopupPage("Circulation.AskRenewPopup&objectType=Item&param=" . $itemId);
						}

						break;

					case ItemActionPeer::TYPE_SOLICIT: //'D' --> "Sollecito"
						$this->Solicit->setVisible(true);  //Enabled = true;

						break;

					case ItemActionPeer::TYPE_MANAGEREQUEST: //'G' --> "Prenotazione"
						$this->Reserve->setVisible(true);  //Enabled = true; //TODO

						break;

					case ItemActionPeer::TYPE_ABORTGENERIC: //'H' --> "Annullamento generico"
						$this->Abort->setVisible(true);  //Enabled = true;

						break;

					case ItemActionPeer::TYPE_CONSULTSUSPEND: // 'P' --> "In deposito (consultazione)"
						$this->Freeze->SetVisible(true);

						break;

					case ItemActionPeer::TYPE_CONSULTRESUME: // 'Q' --> "Riprendi consultazione (da deposito)"
						$this->Resume->setVisible(true);

						break;

					case ItemActionPeer::TYPE_DISABLERENEWAL: // 'T' --> "rinnovo disabilitato"
						$this->SuspendRenewButton->SetVisible(true);

						break;

					case ItemActionPeer::TYPE_ENABLERENEWAL: // 'U' --> "rinnovo abilitato"
						$this->EnableRenewButton->setVisible(true);

						break;

					case ItemActionPeer::TYPE_INTRANSIT: // sono possibili delle messe in transito
						if ($item->getDeliveryLibraryId() == $myLibraryId)   // se destinazione del transito sono io
							$this->ForceInTransitButton->setVisible(true);

						break;

					default:
						break;
				}
			} //end foreach()
		}

		if ((($this->getPage()->getIsPostBack()))
				|| (($this->getPage()->getIsCallback())))
		{
			$updateItemRequests = Prado::getApplication()->getSession()->itemAt('UpdateItemRequests');
			$updatePage = intval(Prado::getApplication()->getSession()->itemAt('UpdatePage'));
			$updateItemId = intval(Prado::getApplication()->getSession()->itemAt('UpdateItemId'));

			if (!is_null($updateItemRequests) && ($updateItemRequests == true))
			{
				Prado::getApplication()->getSession()->remove('UpdateItemRequests');
				$this->globalRefresh();
			}

			if ($updatePage == 1)
			{
				Prado::getApplication()->getSession()->remove('UpdatePage');
				$this->getPage()->reloadPage($this->getSelectedTabParameter(6));
			}

			if ($updateItemId > 0)   // 23/08/2011, clone of the above, for new system ...
			{
				Prado::getApplication()->getSession()->remove('UpdateItemId');
				$this->getPage()->reloadPage($this->getSelectedTabParameter(6));
			}
		}

		if ($this->getOpenReservePanel())
		{
			$this->itemReserve(null, null);
		}
		elseif ($this->getOpenLoanPanel())
		{
			/** OLD
			$this->panelButtons->setVisible(false);

			if ($this->PanelReserve->getVisible() == false)
				$this->PanelLoan->setVisible(true);
		 *
		 */
			$this->itemLoan(null, null);
		}

		$this->AlienItemPanel->setVisible($viewAlienCheck);
	}

	public function globalRefresh()
	{

	}

	public function itemLoan($sender, $param)
	{
		$this->panelButtons->setVisible(false);
		$this->PanelLoan->setVisible(true);

		$itemId = $this->getItemId();

		//verify if we have requests on the manifestation
		$c = new Criteria();

		$item = ItemQuery::create()->findPK($itemId);

		$manifestationId = $item->getManifestationId();

		if ($manifestationId > 0)
		{
			$c->add(ItemRequestPeer::MANIFESTATION_ID, $manifestationId);
		}
		else	// OOC case
		{
			$c->add(ItemRequestPeer::ITEM_ID, $itemId);
		}

		$c->addAnd(ItemRequestPeer::REQUEST_STATUS, ItemRequestPeer::STATUS_PENDING);
		$c->addAscendingOrderByColumn(ItemRequestPeer::REQUEST_DATE);

		if (LLibraryPeer::isEnabled())	// basins case
		{
			$basinSubQueryArray = array("item_request.max_distance IS NULL OR item_request.external_library_id > 0");
			$distanceHash = $this->getUser()->getDistanceHash();
			$previousBasin = "";

			for ($distance = 0; $distance <= LLibraryPeer::getMaxLLibraryDistance(); $distance++)
			{
				if (array_key_exists($distance, $distanceHash))
				{
					$counterBasin = $distanceHash[$distance];

					if ($previousBasin != "")
						$counterBasin .= "," . $previousBasin;

					$basinSubQueryArray[] = "(item_request.delivery_library_id IN (" . $counterBasin . ") AND item_request.max_distance = " . $distance . ")";

					$previousBasin = $counterBasin;
				}
			}

			$basinSubQuery = implode(' OR ', $basinSubQueryArray);

			if ($basinSubQuery != "")
				$basinSubQuery = " (" . $basinSubQuery . ") ";


			$c->addAnd(ItemRequestPeer::REQUEST_ID, $basinSubQuery, Criteria::CUSTOM);
		}

		$requests = ItemRequestPeer::doSelect($c);

		if (count($requests) > 0)
			$this->setItemRequest($requests[0]);

		$patron = null;

		if ($this->_item_request instanceof ItemRequest)
		{
			$patron = $this->_item_request->getPatron();
			$deliveryId = $this->_item_request->getDeliveryLibraryId();

			if ($patron instanceof Patron)
			{
				$patronId = $patron->getPatronId();

				//patron alert
				if ((($patron->getAccessAlert() == PatronPeer::PATRONALERT_ALWAYS)
                    || ($patron->getAccessAlert() == PatronPeer::PATRONALERT_LOAN)) && trim($patron->getAccessNote()) != "")
					$this->getPage()->writeMessage($alert_from_patron = Prado::localize('ATTENZIONE').": ".$patron->getAccessNote(),
													ClavisMessage::WARNING);

				$this->getPage()->writeMessage(Prado::localize("Esiste una prenotazione del titolo per l'utente {user} [{barcode}]",
																array(	'user' => $patron->getCompleteName(),
																		'barcode' => $patron->getBarcode())),
												ClavisMessage::WARNING);

				$this->DeliveryLibrary->setSelectedValue($deliveryId);
				$this->setPatronId($patronId);

				$this->insertPatron($patronId);
				$this->onPatronIdChanged(null,null);
			}
		}

		$item = ItemQuery::create()->findPK($this->getItemId());
		$this->drawLoanButton($item, $patron, $this->DeliveryLibrary->getSelectedValue());

		//item alert
		if ((($item->getLoanAlert() == ItemPeer::ITEMLOANALERT_ALWAYS)
                || ($item->getLoanAlert() == ItemPeer::ITEMLOANALERT_LOAN)) && trim($item->getLoanAlertNote()) != ""
        )
			$this->getPage()->writeMessage(Prado::localize('ATTENZIONE: ').$item->getLoanAlertNote(),ClavisMessage::WARNING);

		$expectedDueDate = null; //$this->_loanmanager->CalculateDueDate($item, null);
		$this->ExpectedDueDate->setTimeStamp($expectedDueDate);

		if ($this->PatronLabel->getText() == '')
			$this->getPage()->setFocus($this->PatronLabel->getClientID());
	}

	public function itemDoLoan($sender, $param)
	{
		$patronId = 0;
		$patron = null;
		$item = ItemQuery::create()->findPK($this->getItemId());

		if (!($item instanceof Item))
		{
			$this->getPage()->writeMessage(Prado::localize("Errore nel passaggio dei parametri.<br />Riportare al fornitore del software, grazie"),
											ClavisMessage::ERROR);

			return;
		}

		$patronId = intval($this->CirculationData->getPatronId());

		if (!($patronId > 0))
			$patronId = $this->HiddenValue->getValue();

		$patron = PatronQuery::create()->findPK($patronId);

		$this->setItemRequest(null);

		///NEW(27/02) - per gestire prestito su rientro fuori sede) - controllo se il patron
		/// (che potrebbe essere stato cambiato dall'operatore...) ha richieste pendenti
		$c = new Criteria();
		$c->add(ItemRequestPeer::MANIFESTATION_ID , $item->getManifestationId());
		$c->addAnd(ItemRequestPeer::PATRON_ID, $patron->getPatronId());
		$c->addAnd(ItemRequestPeer::REQUEST_STATUS, ItemRequestPeer::STATUS_PENDING);
		$c->addAscendingOrderByColumn(ItemRequestPeer::REQUEST_DATE);

		$requests = ItemRequestPeer::doSelect($c);

		if (count($requests) != 0)
			$this->setItemRequest($requests[0]);

		$clavisLibrarian = $this->getUser();
		$deliveryLibrary_id = $this->DeliveryLibrary->getSelectedValue();
		$deliveryLibrary = LibraryQuery::create()->findPK($deliveryLibrary_id);
		$expectedDueDate = $this->_loanmanager->CalculateDueDate($item,$patron);

        if ($this->ExpectedDueDate->getTimeStamp() == null)
            $this->ExpectedDueDate->setTimeStamp($expectedDueDate);

        $date = getdate($this->ExpectedDueDate->getTimeStamp());

		$overridedDueDate = mktime(0, 0, 0, $date['mon'], $date['mday'] + 1, $date['year']) - 1;

		if ($overridedDueDate < time())
		{
			$this->DueDateLegend->setVisible(true);
			$messageBody = Prado::Localize("La data inserita è minore della data attuale");
			$this->DueDateLegend->setText($messageBody);
			$this->getPage()->writeMessage($messageBody, ClavisMessage::ERROR);

			$this->getPage()->setFocus($this->ExpectedDueDate->getClientID());

			return;
		}

		if ($expectedDueDate == $overridedDueDate)
		{
			$expectedDueDate = null;
		}
		else
		{
			$expectedDueDate = $overridedDueDate;
		}


		$retval = $this->_loanmanager->DoLoanItem(	$item,
													$patron,
													$clavisLibrarian,
													$deliveryLibrary,
													null,

													$expectedDueDate );

		switch ($retval)
		{
			case ClavisLoanManager::LOAN_ILLREQUESTED :
				$messageBody = Prado::localize("Inserita richiesta di interprestito");
				$messageType = ClavisMessage::CONFIRM;

				break;

			case ClavisLoanManager::LOAN_RESERVED :
				$messageBody = Prado::localize("Inserita prenotazione");
				$messageType = ClavisMessage::CONFIRM;

				break;

			case ClavisLoanManager::LOAN_LOANED :
				$messageBody = Prado::localize("Esemplare '<em>{title}</em>' [barcode: {barcode}] {status} a <strong>{patron}</strong>.",
															array('barcode' => $item->getBarcode(),
																	'title' => $item->getTrimmedTitle(40),
																	'patron' => "<a href='index.php?page=Circulation.PatronViewPage&id=" .
																						$patron->getPatronId() . "' target='parent'>" .
																						$patron->getCompleteName() . "</a>",
																	'status' => $item->getLoanStatusString())	);

				$messageType = ClavisMessage::CONFIRM;

				break;

			case ClavisLoanManager::LOAN_LOANALREADYEXISTS :

				$messageBody = Prado::localize("Errore: il prestito è già in corso");
				$messageType = ClavisMessage::ERROR;

				break;

			case ClavisLoanManager::RSV_ALREADYMANAGED:
				$messageBody = Prado::localize("L'esemplare '{title}' [barcode: {barcode}] è già in gestione ad un altro operatore, per cui non è possibile prestarlo",
									array('title' => $item->getTrimmedTitle(40), 'barcode' => $item->getBarcode()));
				$messageType = ClavisMessage::ERROR;

				break;

			case ClavisLoanManager::ERROR :
			default:

				$messageBody = Prado::localize("Prestito fallito !");
				$messageType = ClavisMessage::ERROR;
		}

		$this->getPage()->writeDelayedMessage($messageBody, $messageType);
		$this->getPage()->reloadPage($this->getSelectedTabParameter(6));
	}

	//RETURN
	public function itemReturn($sender, $param)
	{
		$this->panelButtons->setVisible(false);
		$this->panelReturn->setVisible(true);
	}

	public function itemDoReturn($sender, $param)
	{
		$this->getPage()->cleanMessageQueue();

		$clavisLibrarian = $this->getUser();
		$item = ItemQuery::create()->findPK($this->getItemId());

		//item alert
		if ((($item->getLoanAlert() == ItemPeer::ITEMLOANALERT_ALWAYS)
				|| ($item->getLoanAlert() == ItemPeer::ITEMLOANALERT_RETURN)) && trim($item->getLoanAlertNote()) != "")
			$this->getPage()->enqueueMessage(Prado::localize('ATTENZIONE') . ': ' . $item->getLoanAlertNote(),
												ClavisMessage::WARNING);

		//patron alert
		$patron = $item->getPatron();

		if ($patron instanceof Patron)
		{
			if ((($patron->getAccessAlert() == PatronPeer::PATRONALERT_ALWAYS)
					|| ($patron->getAccessAlert() == PatronPeer::PATRONALERT_RETURN) ) && trim($patron->getAccessNote()) != "")
				$this->getPage()->enqueueMessage($alert_from_patron = Prado::localize('ATTENZIONE') . ': ' . $patron->getAccessNote(),
													ClavisMessage::WARNING);
		}

		$isLate = ($this->_loanmanager->isLoanLate($item) == ClavisLoanManager::LOAN_ISLATE)
					&& (in_array($item->getLoanStatus(), ItemPeer::getLoanStatusActive()));

		$dueDate = Clavis::dateFormat($item->getDueDate('U'));

		$returnValue = $this->_loanmanager->DoReturnItem(	$item,
															$patron,
															$clavisLibrarian);

		$messageText = '';
		$messageType = ClavisMessage::ERROR;
		$updatePageFlag = false;

		if (($returnValue == ClavisLoanManager::OK)
				|| ($returnValue == ClavisLoanManager::RETN_PATRONREQUEST))
		{
			$updatePageFlag = true;
			$messageText = Prado::localize("Rientro eseguito correttamente dell'esemplare") . " (" .  $item->getitemId() . ") '" . $item->getTrimmedTitle(40) . "'";
			$messageType = ClavisMessage::CONFIRM;

			if ($returnValue == ClavisLoanManager::RETN_PATRONREQUEST)
			{
				$messageText .= ',<br />' . Prado::localize('ed esistono prenotazioni');
				$messageType = ClavisMessage::WARNING;
			}

			if ($isLate)
			{
				$messageText .= ',<br />' . Prado::localize('<b>** consegnato in ritardo</b> (scaduto il {dueDate}) <b>**</b>',
																array('dueDate' => $dueDate));
				$messageType = ClavisMessage::WARNING;
			}

			if ($item->getLoanStatus() == ItemPeer::LOANSTATUS_READYFORTRANSITTOHOME)
				$messageText .= '<br />' . Prado::localize("L'esemplare è stato messo in 'pronto al transito di rientro'.");
		}
		elseif ($returnValue == ClavisLoanManager::ERROR)
		{
			$messageText = Prado::localize('Rientro fallito !');
			$messageType = ClavisMessage::ERROR;
		}
		else
		{
			$messageText = Prado::localize("Valore di ritorno sconosciuto durante la riconsegna di un esemplare da 'azioni'.<br />Riportare al fornitore del software, grazie");
			$messageType = ClavisMessage::ERROR;
		}

		$this->getPage()->enqueueMessage($messageText, $messageType);

		if ($updatePageFlag)
		{
			$this->getPage()->flushDelayedMessage();
			$this->getPage()->reloadPage($this->getSelectedTabParameter(6));
		}
		else
		{
			$this->getPage()->flushMessage();
		}
	}

	//RENEW
	public function itemRenew($sender, $param)
	{
		$item = ItemQuery::create()->findPK($this->getItemId());
		$patron = $item->getPatron();

		if ($patron instanceof Patron)
		{
			$patronName = $patron->getCompleteName();
		}
		else
		{
			$patronName = '(' . Prado::localize('senza nome') . ')';
			$this->getPage()->writeMessage(Prado::localize("Errore: all'esemplare non è associato alcun utente !"),
												ClavisMessage::ERROR);
			return false;
		}

		$ok = false;
		$messageBody = '';

		switch ($this->_loanmanager->IsLoanRenewable($item))
		{
			case ClavisLoanManager::RENW_ALREADYREQUESTED:
				$messageBody = Prado::localize("La notizia è stata richiesta da troppi utenti e non ci sono abbastanza copie disponibili, per cui la richiesta di proroga non viene presa in considerazione");
				$messageType = ClavisMessage::WARNING;

				break;

			case ClavisLoanManager::RENW_REACHEDMAXREN:
				$messageBody = Prado::localize("Il numero massimo di proroghe possibili è già stato raggiunto");
				$messageType = ClavisMessage::ERROR;

				break;

			case ClavisLoanManager::RENW_NOTLOANED:
				$messageBody = Prado::localize("Incongruenza: l'esemplare non risulta in stato di prestito");
				$messageType = ClavisMessage::ERROR;

				break;

			case ClavisLoanManager::OK:
				$ok = true;

				break;

			case ClavisLoanManager::ERROR:
			default:
				$messageBody = Prado::localize("Errore di tipo sconosciuto");
				$messageType = ClavisMessage::ERROR;
		}

		if ($messageBody != '')
			$this->getPage()->writeMessage($messageBody, $messageType);

		if ($ok)
		{
			$this->panelButtons->setVisible(false);
			$this->panelRenew->setVisible(true);
			$this->getPage()->setFocus($this->RenewDuration->getClientID());
		}
	}

	public function itemDoRenew($sender, $param)
	{
		$item = ItemQuery::create()->findPK($this->getItemId());
		$clavisLibrarian = $this->getUser();

		$renew_duration = $this->RenewDuration->getSafeText();
		$description = $this->RenewDescription->getSafeText();
		$destinationObject = $this->_loanmanager->getLoanDestinationObject($item);

		if (is_null($destinationObject))
		{
			$this->getPage()->writeMessage(Prado::localize("Incongruenza sulla proroga dell'esemplare con id: {id}. Segnalare all'assistenza, grazie",
																array('id' => $item->getItemId())),
												ClavisMessage::ERROR);
			return;
		}

		if ($this->_loanmanager->DoRenewLoan(	$item,
												$destinationObject,
												$clavisLibrarian,
												$description,
												$renew_duration ))
		{
			$this->getPage()->writeMessage(Prado::localize("Proroga eseguita correttamente"),
												ClavisMessage::INFO);

			$this->getPage()->reloadPage($this->getSelectedTabParameter(6));
		}
		else
		{
			$this->getPage()->writeMessage(Prado::localize("Proroga fallita"),
												ClavisMessage::ERROR);
		}
	}

	public function onRenew($sender, $param)
	{
		$this->getPage()->cleanMessageQueue();
		$reloadPageFlag = false;

		$itemId = $this->getItemId();
		$item = ItemQuery::create()->findPK($itemId);

		if ($item instanceof Item)
		{
			$clavisLibrarian = $this->getUser();

			$renew_duration = $this->RenewDuration->getSafeText();
			$description = $this->RenewDescription->getSafeText();
			$destinationObject = $this->_loanmanager->getLoanDestinationObject($item);

			if (is_null($destinationObject))
			{
				$this->getPage()->enqueueMessage(Prado::localize("Incongruenza sulla proroga dell'esemplare con id: {id}.<br />Riportare al fornitore del software. Grazie",
																		array('id' => $itemId)),
													ClavisMessage::ERROR);

				return;
			}

			if ($this->_loanmanager->DoRenewLoan(	$item,
													$destinationObject,
													$clavisLibrarian,
													$description,
													$renew_duration))
			{
				$this->getPage()->enqueueMessage(Prado::localize("Proroga eseguita correttamente"),
													ClavisMessage::INFO);

				if ($item->isExternal()
							&& intval(ClavisParamPeer::getParam('EXTRARENEW_CONFIRMEMAIL')) == 1)
				{
					$library = $item->getOwnerLibraryLabel();
					$loan = $item->getCurrentLoan();

					$notificationManager = Prado::getApplication()->getModule('notification');
					$resultAddress = $notificationManager->sendEmailRenew(	'EXTRA_RENEW_CONFIRM',
																			$loan,
																			$oldDueDate,
																			$renewDate);

					if ($resultAddress == self::INVALIDEMAIL)
						$this->getPage()->enqueueMessage(Prado::localize("La biblioteca esterna [{library}] non ha un indirizzo email valido",
																			array('library' => $library)),
															ClavisMessage::WARNING);
					elseif ($resultAddress != '')
					{
						$this->getPage()->enqueueMessage(Prado::localize("É stata spedita una email informativa alla biblioteca '{library}', all'indirizzo '{email}'",
																			array(	'library' => $library,
																					'email' => $resultAddress)),
															ClavisMessage::INFO);
					}
					else
						$this->getPage()->enqueueMessage(Prado::localize("É fallita la richiesta di proroga per l'esemplare '{title}' [inv: {inv}]",
																			array(	'title' => $item->getTrimmedTitle(60),
																					'inv' => $item->getCompleteInventoryNumber())),
															ClavisMessage::ERROR);
				}

				$reloadPageFlag = true;
			}
			else
			{
				$this->getPage()->enqueueMessage(Prado::localize("Proroga fallita"),
													ClavisMessage::ERROR);
			}
		}
		else
		{
			$this->getPage()->enqueueMessage(Prado::localize("Errore dell'applicazione: nel rinnovo extra è stato passato il parametro 'itemId={itemId}' ma l'esemplare non sembra esistere.<br />Riportare al fornitore del software, grazie",
																array('itemId' => $itemId)),
												ClavisMessage::ERROR);
		}

		if ($reloadPageFlag)
		{
			$this->getPage()->flushDelayedMessage();
			$this->getPage()->reloadPage($this->getSelectedTabParameter(6));
		}
		else
		{
			$this->getPage()->flushMessage();
		}
	}

	public function itemDoImmediateSolicit($sender, $param)
	{
		$item = null;
		$itemId = intval($this->getItemId());

		if ($itemId > 0)
			$item = ItemQuery::create()->findPK($itemId);

		if ($item instanceof Item)
		{
			$this->getPage()->gotoPage('Circulation.ManageSolicit', array("itemId" => $itemId));
		}
		else
		{
			$this->getPage()->writeMessage(Prado::localize("Errore nel passaggio dei parametri. Riportare al fornitore del software, grazie"),
											ClavisMessage::ERROR);
		}
	}

	private function drawSendMailCheck()
	{
		$item = $this->getItem();

		if ($item instanceof Item)
			$this->SendMailCheck->setVisible($item->isExternal());
	}

	public function itemReserve($sender, $param)
	{
		$this->panelButtons->setVisible(false);
		$this->PanelLoan->setVisible(false);
		$this->PanelReserve->setVisible(true);
		$this->drawSendMailCheck();
		$this->getPage()->setFocus($this->ReservePatronLabel->getClientID());
	}

	public function itemDoReserve($sender, $param)
	{
		$this->getPage()->cleanMessageQueue();
		$patron_id = 0;
		$patronBarcode = 0;
		$patron = null;

		// ricaricamento
		$item = ItemQuery::create()->findPK($this->getItemId());
		$extraMode = $this->getExtraMode();

		$patron = $this->getPatron();
		$externalLibrary = $this->getExternalLibrary();
		$request_note = trim($this->RequestNote->getSafeText());

		$requestType = null;

		if ($this->_requestTypeActive)
		{
			if ($this->RequestTypeList->getSelectedIndex() > 0)
				$requestType = $this->RequestTypeList->getSelectedValue();
		}

		if (!$extraMode
				&& !($patron instanceof Patron))
		{
			$this->getPage()->enqueueMessage(Prado::localize("Errore sul passaggio parametri dell'utente"),
												ClavisMessage::ERROR);
		}
		elseif ($extraMode
				&& !($externalLibrary instanceof Library))
		{
			$this->getPage()->enqueueMessage(Prado::localize("Errore sul passaggio parametri della biblioteca esterna"),
												ClavisMessage::ERROR);
		}
		else	// everything is ok, we can insert new reservation
		{
			$clavisLibrarian = $this->getUser();
			$deliveryLibrary_id = $this->ReserveDeliveryLibrary->getSelectedValue();
			$deliveryLibrary = LibraryQuery::create()->findPK($deliveryLibrary_id);

			if ($extraMode)
			{
				if ($request_note != "")
					$request_note = Prado::localize("Prenotazione extrasistema") . " - " . $request_note;

				$externalLibraryId = $externalLibrary->getLibraryId();
			}
			else	// normal interbiblio mode
			{
				$externalLibraryId = null;
			}

			$returnValue = $this->_requestManager->reserveItem(	$item,
																$patron,
																$deliveryLibrary,
																$clavisLibrarian,
																$request_note,

																$externalLibraryId,
																$requestType);

			if ($returnValue)	// request went ok
			{
				if (!$this->getExtraMode())
				{
					$this->getPage()->enqueueMessage(Prado::localize("Esemplare prenotato: '{title}' {type}[id: {id}] per l'utente {patronName}",
																		array(	'title' => $item->getTrimmedTitle(40),
																				'type' => is_null($requestType) ? '' : '<b>[' . ItemRequestPeer::getRequestTypeString($requestType) . ']</b>&nbsp;',
																				'id' => $item->getItemId(),
																				'patronName' => $patron->getCompleteName())),
											ClavisMessage::CONFIRM);

					/// email sending logic

					if ($item->isExternal())
					{
						if ($this->SendMailCheck->getChecked())
						{	
							try
							{
								$succ = $this->sendExtraReservationMail($this->getUser()->getActualLibrary(),
																		$item->getOwnerLibrary(),
																		$item,
																		$patron->getPatronId(),
																		$requestType,

																		$request_note);

								if ($succ)
								{
									$this->getPage()->enqueueMessage(Prado::localize("Notifica email inviata."),
																		ClavisMessage::CONFIRM);
								}
							}
							catch (Exception $e)
							{
								throw new Exception('Error sending mail: ' . $e->getMessage());
							}
						}
					}
				}
				else
				{	// extramode

					/**
					 * Deactivated: it does not have any logic in it ....
					if ($this->SendMailCheck->getChecked())
					{
						$succ = $this->sendExtraReservationMail(	$deliveryLibrary,
																	$externalLibrary,
																	$item,
																	$patron->getPatronId());

						if ($succ)
						{
							$this->getPage()->enqueueMessage(Prado::localize("Notifica email inviata."),
																ClavisMessage::CONFIRM);
						}
					}
					*/

					$this->getPage()->enqueueMessage(Prado::localize("Prenotazione per la biblioteca esterna {library} [{consortia}] eseguita correttamente",
																			array(	'library' => $externalLibrary->getLabel(),
																					'consortia' => $externalLibrary->getConsortiaString(30) )),
														ClavisMessage::CONFIRM);
				}

				$manifestation = $item->getManifestation();

				if ($manifestation instanceof Manifestation)
				{
					if (!$item->checkLoanableSince())
						$this->getPage()->enqueueMessage(Prado::localize('La notizia è disponibile solo dal {date}',
																				array('date' => Clavis::dateFormat($manifestation->getLoanableSince('U')))),
															ClavisMessage::WARNING);

					if (!$this->_loanmanager->IsRatingAllowed($manifestation, $patron))
						$this->getPage()->enqueueMessage(Prado::localize("La notizia è disponibile solo per gli utenti con piu' di {rating} anni",
																				array('rating' => $manifestation->getRating())),
															ClavisMessage::WARNING);
				}
			}
			else	// request went wrong
			{
				$this->getPage()->enqueueMessage(Prado::localize("Prenotazione fallita !"),
													ClavisMessage::ERROR);
			}
		}

		$this->getPage()->flushDelayedMessage();
		$this->getPage()->reloadPage($this->getSelectedTabParameter(6));
	}

	private function OLDsendExtraReservationMail(	Library $fromLibrary,
												Library $toLibrary,
												Item $item,
												$patronBarcode)
	{
		$mailer = Prado::getApplication()->getModule('mail');
		
		$libraryLanguage = $toLibrary->getLibraryLanguage();

		if ($libraryLanguage == "")
			$libraryLanguage = Prado::getApplication()->getGlobalization()->getCulture();
		
		$tpl = DocumentTemplatePeer::getTemplate(	'EXTRA_REQUEST',
													$libraryLanguage, //// Prado::getApplication()->getGlobalization()->getCulture(),
													$fromLibrary->getLibraryId());

		$placeholders = array(	'{TITLE}' => $item->getTitle(),
								'{LIBCODE}' => $toLibrary->getLibraryCode(),
								'{INVENTORY}' => $item->getInventorySerieId() . '-' . $item->getInventoryNumber(),
								'{COLLOCATION}' => $item->getCollocationCombo(),
								'{LIBRARY}' => $fromLibrary->getLabel(),
								'{LIBRARY_CODE}' => $fromLibrary->getLibraryCode(),
								'{LIBRARY_ADDRESS}' => $fromLibrary->getAddress(),
								'{LIBRARY_PHONE}' => $fromLibrary->getPhone(),
								'{LIBRARY_EMAIL}' => $fromLibrary->getEmail(),
								'{PATRONBARCODE}' => $patronBarcode );

		$mailer->setFrom("\"{$fromLibrary->getLabel()}\" <{$fromLibrary->getEmail()}>");
		$mailer->setSubject($tpl->getTemplateSubject() . "\n");
		$mailer->setBody(str_replace(array_keys($placeholders), array_values($placeholders), $tpl->getTemplateBody()));
		$mailer->setTo($toLibrary->getEmail());

		$mailer->send();
	}

	private function sendExtraReservationMail(	Library $fromLibrary,
												Library $toLibrary,
												Item $item,
												$patronId,
												$requestType = null,
			
												$requestNote = null)
	{
		///$mailer = Prado::getApplication()->getModule('mail');
		$notificationManager = Prado::getApplication()->getModule('notification');
		$libraryLanguage = $toLibrary->getLibraryLanguage();
		
		switch ($requestType)
		{
			case ItemRequestPeer::ITEMREQUESTTYPE_LOAN:
				$templateType = 'EXTRA_REQUEST';
				
				break;
			
			case ItemRequestPeer::ITEMREQUESTTYPE_DOCUMENTDELIVERY:
				$templateType = 'EXTRA_REQUEST_DD';
				
				break;
			
			case null:
			default:
				$templateType = 'EXTRA_REQUEST';
		}
		
		$template = DocumentTemplatePeer::getTemplate(	$templateType,      // 'EXTRA_REQUEST',
														$libraryLanguage, //// Prado::getApplication()->getGlobalization()->getCulture(),
														$fromLibrary->getLibraryId());
		
		$patron = PatronQuery::create()->findPk($patronId);
		
		$arr_alias = array(	'TITLE' => $item->getTitle(),
							'LIBCODE' => $toLibrary->getLibraryCode(),
							'INVENTORY' => $item->getInventorySerieId() . '-' . $item->getInventoryNumber(),
							'COLLOCATION' => $item->getCollocationCombo(),
							'LIBRARY' => $fromLibrary->getLabel(),
							'LIBRARY_CODE' => $fromLibrary->getLibraryCode(),
							'LIBRARY_ADDRESS' => $fromLibrary->getAddress(),
							'LIBRARY_PHONE' => $fromLibrary->getPhone(),
							'LIBRARY_EMAIL' => $fromLibrary->getEmail(),
							'PATRONBARCODE' => $patron->getBarcode(),
							'REQUEST_NOTE' => $requestNote );

		/*		
		$body = str_replace(array_keys($placeholders), array_values($placeholders), $tpl->getTemplateBody());
		$mailer->setFrom("\"{$fromLibrary->getLabel()}\" <{$fromLibrary->getEmail()}>");
		$mailer->setSubject($tpl->getTemplateSubject() . "\n");
		$mailer->setBody($body);
		$mailer->setTo($toLibrary->getEmail());
		$mailer->send();
		*/
		
		$mailData = [];
		$mailData['to'] = $toLibrary->getEmail();
		$mailData['bcc'] = array();
		$mailData['cc'] = array();
		$mailData['body'] = '';
		$mailData['subject'] = "[" . $myConsortiumString = $fromLibrary->getConsortiaString() . "]: " . $template->getTemplateSubject();

		$mailData['from'] = array(	'name' => $fromLibrary->getLabel(),
									'email' => $fromLibrary->getEmail());

		$class = get_class($toLibrary);
		$notificationData = array(	'sender_library_id' => $fromLibrary->getLibraryId(),
									'receiver_class' => $class,
									'receiver_id' => $toLibrary->getLibraryId(),
									'description' => Prado::localize("Richiesta prestito extra-sistema"),
									'notification_class'=>'X',
									'notes' => array()
		);

		// don't try/catch here, let the Exception propagate to caller.
		$ret = $notificationManager->DoEmailReport(	$template->getTemplateBody(),
													$arr_alias,
													$mailData,
													NotificationManager::EMAIL_AUTO,
													$notificationData);

		return $ret;
	}

	public function itemAbort($sender, $param)
	{
		$this->panelButtons->setVisible(false);
		$this->panelAbort->setVisible(true);
		$this->ForceActualLibraryCheck->setChecked(true);

		$item = ItemQuery::create()->findPK($this->getItemId());

		if ($item->isOutOfHome($this->getUser()->getActualLibraryId())
				&& !$item->isOutOfSystem()
				&& !$item->isExternal())
		{
			$explanationString = Prado::localize("Verrà generato un transito di rientro dalla biblioteca '{actualLibraryLabel}' alla biblioteca '{homeLibraryLabel}'",
													array('actualLibraryLabel' => LibraryPeer::getLibraryLabel($this->getUser()->getActualLibraryId(), '---'), ///$item->getActualLibraryLabel(),
															'homeLibraryLabel' => $item->getHomeLibraryLabel(null, null, null, null, false)));

			$this->AbortExplanation->setText($explanationString);
			$this->AbortExplanationPanel->setCssClass('panel_on');
		}
		else
		{
			$this->AbortExplanationPanel->setCssClass('panel_off');
		}

		$this->getPage()->setFocus($this->AbortDescription->getClientID());
	}

	public function onForceActualLibraryChecked($sender, $param)
	{
		$item = ItemQuery::create()->findPK($this->getItemId());

		if ($this->ForceActualLibraryCheck->getChecked())
		{
			$virtualActualLibraryId = $this->getUser()->getActualLibraryId();
			$this->ForceAlienLibraryCheck->setChecked(false);
		}
		else
		{
			$virtualActualLibraryId = $item->getActualLibraryId();
		}

		if (($virtualActualLibraryId != $item->getHomeLibraryId()) &&
				!$item->isOutOfSystem() &&
				!$item->isExternal() )
		{
			$explanationString = Prado::localize('Verrà generato un transito di rientro dalla biblioteca \'{actualLibraryLabel}\' alla biblioteca \'{homeLibraryLabel}\'',
													array(	'actualLibraryLabel' => LibraryPeer::getLibraryLabel($virtualActualLibraryId, '---'),
															'homeLibraryLabel' => $item->getHomeLibraryLabel(null, null, null, null, false)));

			$this->AbortExplanation->setText($explanationString);
			$this->AbortExplanationPanel->setCssClass('panel_on');
		}
		else
		{
			$this->AbortExplanation->setText('');
			$this->AbortExplanationPanel->setCssClass('panel_off');
		}

		$this->renderAbortExplanationPanel($param);
	}

	public function onForceAlienLibraryChecked($sender, $param)
	{
		$item = $this->getItem();

		if ($this->ForceAlienLibraryCheck->getChecked() && ($item instanceof Item))
		{
			$this->ForceActualLibraryCheck->setChecked(false);

			if ($item instanceof Item)
			{
				$explanationString = Prado::localize("La biblioteca di gestione e la biblioteca corrente dell'esemplare verranno resettate alla biblioteca '{lab}'",
														array('lab' => $item->getOwnerLibraryLabel()));

				$this->AbortExplanation->setText($explanationString);
				$this->AbortExplanationPanel->setCssClass('panel_on');
			}
		}
		else
		{
			$this->AbortExplanation->setText('');
			$this->AbortExplanationPanel->setCssClass('panel_off');
		}

		$this->renderAbortExplanationPanel($param);
	}

	private function renderAbortExplanationPanel($param = null)
	{
		if ($this->getPage()->getIsPostBack())
		{
			if (!is_null($param))
			{
				$writer = $param->getNewWriter();
			}
			else
			{
				$writer = $this->getPage()->createWriter();
			}

			$this->AbortExplanationPanel->render($writer);
		}
	}

	public function itemDoAbort($sender, $param)
	{
		$item = ItemQuery::create()->findPK($this->getItemId());
		$clavisLibrarian = $this->getUser();

		$type = $this->AbortType->getSelectedValue();

		if ($type != "")
		{
			$typeString = ", " . Prado::localize(	"di tipo '{type}'",
													array('type' => LookupValuePeer::getLookupValue("ITEMACTIONTYPE", $type)));
		}
		else
		{
			$typeString = "";
		}

		$description = trim($this->AbortDescription->getSafeText());

		if ($description != "")
		{
			$descriptionString = " (" . Prado::localize(	"nota: {description}",
															array('description' => $description)) . ")";
		}
		else
		{
			$descriptionString = "";
		}

		if ($this->ForceActualLibraryCheck->getChecked())
		{
			$force = ClavisLoanManager::LOAN_ABORTFORCEACTUAL;
		}
		elseif ($this->ForceAlienLibraryCheck->getChecked())
		{
			$force = ClavisLoanManager::LOAN_ABORTFORCEOWNER;
		}
		else
		{
			$force = null;
		}

		$ok = false;
		$messageBody = Prado::localize("Non è stata eseguita alcuna operazione");
		$messageType = ClavisMessage::WARNING;

		$destinationObject = $item->getPatron();

		if (!($destinationObject instanceof Patron))
			$destinationObject = $item->getExternalLibrary();

		switch ($this->_loanmanager->DoAbortLoan(	$item,
													$destinationObject,
													$clavisLibrarian,
													$type,
													$description,

													$force))
		{
			case ClavisLoanManager::OK:
				$messageBody = Prado::localize("Annullamento eseguito correttamente sull'esemplare con id: {id} e titolo '{title}'",
													array(	'id' => $item->getId(),
															'title' => $item->getTrimmedTitle(40, true)) )
								. $typeString . $descriptionString;

				if ($item->getLoanStatus() == ItemPeer::LOANSTATUS_INTRANSITTOEXTRA)
					$messageBody .=  '<br />' . Prado::localize("L'esemplare è stato messo in 'pronto al transito di rientro extrasistema'");

				$messageType = ClavisMessage::INFO;
				$ok = true;

				break;

			case ClavisLoanManager::LOAN_ABORTRETURNHOME:
				$messageBody = Prado::localize("Annullamento eseguito correttamente sull'esemplare con id: {id} e titolo '{title}'",
														array(	'id' => $item->getId(),
																'title' => $item->getTrimmedTitle(40, true)))
									. $typeString . $descriptionString
									. Prado::localize("; l'esemplare è passato a 'pronto per il transito', in quanto si trova fuori sede");

				$messageType = ClavisMessage::INFO;
				$ok = true;

				break;

			case ClavisLoanManager::ERROR:
				$messageBody = Prado::localize("Annullamento fallito");
				$messageType = ClavisMessage::ERROR;

				break;

			default:
				$messageBody = Prado::localize("Errore sconosciuto durante l'annullamento");
				$messageType = ClavisMessage::ERROR;
		}

		if ($ok)
		{
			$requestCount = $this->_requestManager->countRequests(	$this->getUser()->getActualLibraryId(),
																	null,
																	$item->getItemId());

			if ($requestCount > 0)
			{
				$messageBody .= '<br /><strong>' . Prado::localize("[Esistono prenotazioni]") . '</strong>';
				$messageType = ClavisMessage::WARNING;
			}

			$this->getPage()->writeDelayedMessage($messageBody, $messageType);
			$this->getPage()->reloadPage($this->getSelectedTabParameter(6));
		}
		else
		{
			$this->getPage()->writeMessage($messageBody, $messageType);
		}
	}

	public function onFreezeConsultation($sender, $param)
	{
		$clavisLibrarian = $this->getUser();
		$ok = false;
		$messageBody = Prado::localize("Non è stata eseguita alcuna operazione !");
		$messageType = ClavisMessage::WARNING;

		$item = (object) null;
		$itemId = intval($this->getItemId());

		if ($itemId > 0)
			$item = ItemQuery::create()->findPK($itemId);

		if ($item instanceof Item)
		{
			$itemtit = $item->getCompleteTitle();

			if (!$itemtit)
				$itemtit = Prado::localize('(nessun titolo)');

			if ($this->_loanmanager->IsItemLoaned($item))
			{
				switch ($this->_loanmanager->doFreezeConsultation(	$itemId,
																	$clavisLibrarian))
				{
					case ClavisLoanManager::OK:
						$messageBody = Prado::localize("L'esemplare con titolo '{title}' [barcode: {barcode}, inv: {inv}] è stato messo in deposito",
															array(	'title' => $itemtit,
																	'inv' => $item->getCompleteInventoryNumber(),
																	'barcode' => $item->getBarcode()));

						$messageType = ClavisMessage::CONFIRM;
						$ok = true;

						break;

					case ClavisLoanManager::ERROR:
						$messageBody = Prado::localize("Operazione di deposito fallita");
						$messageType = ClavisMessage::ERROR;

						break;

					default:
						$messageBody = Prado::localize("Errore sconosciuto durante la messa in deposito");
						$messageType = ClavisMessage::ERROR;
				}
			}
			else
			{
				$messageBody = Prado::localize("L'esemplare con id = {item_id} e barcode = '{item_barcode}' NON E' IN CONSULTAZIONE !",
													array(	'item_id' => $item->getId(),
															'item_barcode' => $item->getBarcode()));

				$messageType =	ClavisMessage::ERROR;
			}
		}

		if ($ok)
		{
			$this->getPage()->writeDelayedMessage($messageBody, $messageType);
			$this->getPage()->reloadPage($this->getSelectedTabParameter(6));
		}
		else
		{
			$this->getPage()->writeMessage($messageBody, $messageType);
		}
	}

	public function onResumeConsultation($sender, $param)
	{
		$clavisLibrarian = $this->getUser();
		$ok = false;
		$messageBody = Prado::localize("Non è stata eseguita alcuna operazione !");
		$messageType = ClavisMessage::WARNING;

		$item = (object) null;
		$itemId = intval($this->getItemId());

		if ($itemId > 0)
			$item = ItemQuery::create()->findPK($itemId);

		if ($item instanceof Item)
		{
			$itemtit = $item->getCompleteTitle();

			if (!$itemtit)
				$itemtit = Prado::localize('(nessun titolo)');

			if ($this->_loanmanager->IsItemLoaned($item))
			{
				switch ($this->_loanmanager->doResumeConsultation(	$itemId,
																	$clavisLibrarian))
				{
					case ClavisLoanManager::OK:
						$messageBody = Prado::localize("L'esemplare con titolo '{title}' [barcode: {barcode}, inv: {inv}] è stato rimesso in consultazione all'utente <b>{patron}</b>",
															array(	'title' => $itemtit,
																	'inv' => $item->getCompleteInventoryNumber(),
																	'barcode' => $item->getBarcode(),
																	'patron' => $item->getPatron()->getCompleteName() ));

						$messageType = ClavisMessage::CONFIRM;
						$ok = true;

						break;

					case ClavisLoanManager::ERROR:
						$messageBody = Prado::localize("Operazione di rimessa in consultazione fallita");
						$messageType = ClavisMessage::ERROR;

						break;

					default:
						$messageBody = Prado::localize("Errore sconosciuto durante la rimessa in consultazione");
						$messageType = ClavisMessage::ERROR;
				}
			}
			else
			{
				$messageBody = Prado::localize("L'esemplare con id = {item_id} e barcode = '{item_barcode}' NON E' IN CONSULTAZIONE !",
													array(	'item_id' => $item->getId(),
															'item_barcode' => $item->getBarcode() ));

				$messageType =	ClavisMessage::ERROR;
			}

		}

		if ($ok)
		{
			$this->getPage()->writeDelayedMessage($messageBody, $messageType);
			$this->getPage()->reloadPage($this->getSelectedTabParameter(6));
		}
		else
		{
			$this->getPage()->writeMessage($messageBody, $messageType);
		}
	}

	// setters & getters
	public function setOpenReservePanel($flag)
	{
		$this->setControlState("openReserve", $flag, false);
	}

	public function getOpenReservePanel()
	{
		return $this->getControlState("openReserve", false);
	}

	public function setOpenLoanPanel($flag)
	{
		$this->setControlState("openLoan", $flag, false);
	}

	public function getOpenLoanPanel()
	{
		return $this->getControlState("openLoan", false);
	}

	public function setItemId($value)
	{
		$this->_item_id = intval($value);
		$this->setControlState("item_id", $this->_item_id, null);
	}

	public function getItemId()
	{
		if (is_null($this->_item_id))
			$this->_item_id = $this->getControlState("item_id", null);

		return $this->_item_id;
	}

	private function getItem()
	{
		$output = (object) null;
		$itemId = intval($this->getItemId());

		if ($itemId > 0)
		{
			$item = ItemQuery::create()->findPK($itemId);

			if ($item instanceof Item)
				$output = $item;
		}

		return $output;
	}

	public function setLibrarianId($value)
	{
		$this->_librarian_id = intval($value);
		$this->setControlState("librarian_id", $this->_librarian_id, null);
	}

	public function getLibrarianId()
	{
		if (is_null($this->_librarian_id))
			$this->_librarian_id = $this->getControlState("librarian_id", null);

		return $this->_librarian_id;
	}


	public function setItemRequest($value)
	{
		if ($value != null)
		{
			if (!($value instanceof ItemRequest))
				return false;
		}

		$this->_item_request = $value;
		$this->setControlState("item_request", $value, null);
	}

	public function getItemRequest()
	{
		if (is_null($this->_item_request))
			$this->_item_request = $this->getControlState("item_request", null);

		return $this->_item_request;
	}

	public function setPatronId($value)
	{
		$this->_patron_id = intval($value);
		$this->setControlState("patron_id", $this->_patron_id, null);
	}

	public function getPatronId()
	{
		if (is_null($this->_item_request_patron_id))
			$this->_patron_id = $this->getControlState("patron_id", null);

		return $this->_patron_id;
	}

	public function resetExtraMode($value = false)
	{
		$this->ExtraModeCheck->setChecked($value);
		$this->setExtraMode($value);
	}

	public function setExtraMode($value = false)
	{
		if ($value !== true)
			$value = false;
		
		Prado::getApplication()->getSession()->add($this->_extraModeSessionName, $value);
	}

	public function getExtraMode()
	{
		return Prado::getApplication()->getSession()->itemAt($this->_extraModeSessionName);
   }

	//LOAN PANEL
	public function suggestPatron($sender, $param)
	{
		$token = trim($param->getToken());

		if ($token == '')
			return;

		$sender->setDataSource(PatronPeer::doSuggest($token,10,true,true));
		$sender->dataBind();
	}

	/**
	 * Ajax callback which makes some action after the string in the
	 * autocomplete textbox has been choosen.
	 * In particular, it populates some labels with patron's data.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function suggestPatronCallBack($sender, $param)
	{
		$fieldText = '';

		if ($this->PanelReserve->getVisible())   // prenotazione
		{
			$fieldText = trim($this->ReservePatronLabel->getSafeText());
			$cLabel = 'ReservePatronLabel';
			$cDelivery = 'ReserveDeliveryLibrary';
		}
		elseif ($this->PanelLoan->getVisible())     // prestito
		{
			$fieldText = trim($this->PatronLabel->getSafeText());
			$cLabel = 'PatronLabel';
			$cDelivery = 'DeliveryLibrary';
		}
		else
		{
			return false;
		}

		$match = array();
		if (preg_match("/\(([^\)]+)\)$/", $fieldText, $match))
		{
			$patronBarcode = $match[1];
		}
		else
		{
			$patronBarcode = $fieldText;
		}

		$resultFlag = false;

		/** @var $patrons PropelObjectCollection */
		$patrons = PatronQuery::create()
							->filterByPatronStatus(PatronPeer::STATUS_DECEASED, ModelCriteria::NOT_EQUAL)
							->findByBarcode($patronBarcode);

		if (!$patrons->isEmpty())
		{
			$patron = $patrons->shift();

			if ($patron instanceof Patron)
				$patronId = $patron->getPatronId();
		}
		else
		{
			$patronId = null;
		}

		$resultFlag = $this->doPatronIdChanged($patronId);

		if ($resultFlag)
		{
			$this->$cLabel->setText('');
			$this->getPage()->setFocus($this->$cDelivery->getClientID());
		}
		else
		{
			$this->getPage()->setFocus($this->$cLabel->getClientID());
			$this->PatronLabel->setText('');

			return;
		}
	}

	public function insertPatron($patronIdParam)
	{
		$userDataPanel = '';
		$userData = '';
		$circulationData = '';
		$patronLabel = '';
		$hiddenValue = '';

		if ($this->PanelReserve->getVisible())  // prenotazione
		{
			$userDataPanel = 'ReserveUserDataPanel';
			$userData = 'ReserveUserData';
			$circulationData = 'ReserveCirculationData';
			$patronId = 'ReservePatronId';
			$patronLabel = 'ReservePatronLabel';
			$hiddenValue = 'ReserveHiddenValue';
		}
		elseif ($this->PanelLoan->getVisible())  // prestito
		{
			$userDataPanel = 'UserDataPanel';
			$userData = 'UserData';
			$circulationData = 'CirculationData';
			$patronId = 'PatronId';
			$patronLabel = 'PatronLabel';
			$hiddenValue = 'HiddenValue';
		}
		else
		{
			return false;
		}

		$returnFlag = $this->$userData->populate($patronIdParam);
		$this->$userDataPanel->setCssClass($returnFlag ? 'panel_on' : 'panel_off');
		$this->$circulationData->populate($patronIdParam);
		$this->$patronId->setText($patronIdParam);
		$this->setPatronId($patronIdParam);

		if ($returnFlag)
			$this->$hiddenValue->setValue($patronIdParam);

		return $returnFlag;
	}

	private function searchBarcode($barcode)
	{
		$list = array();
		$c = new Criteria();
		$c->add(PatronPeer::BARCODE  , $barcode);
		$patrons = PatronPeer::doSelect($c);

		for($i=0; $i < count($patrons); $i++)
		{
			$list[] = $patrons[$i]->getLastname() .' '. $patrons[$i]->getName() . " (" . $patrons[$i]->getBarcode() . ")<span class=\"informal\"> ". Clavis::dateFormat($patrons[$i]->getBirthDate('U')) . "</span>";
		}

		return $list;
	}

	public function drawLoanButton($item, $object, $deliveryLibraryId)
	{
		if ($this->_loanmanager->IsLoanAllowed(	$item,
												$object,
												$deliveryLibraryId)
				&& ($object instanceof Patron))
		{
			$this->DoLoan->setEnabled(true);
            $expectedDueDate = $this->_loanmanager->CalculateDueDate($item,$object);

            $this->ExpectedDueDate->setTimeStamp($expectedDueDate);
		}
		else
		{
			if ($object instanceof Patron)
			{
				$this->getPage()->enqueueMessage(Prado::localize("Esemplare non prestabile a questo utente"),
													ClavisMessage::ERROR);
			}
			elseif ($object instanceof Library)
			{
				$this->getPage()->enqueueMessage(Prado::localize("Esemplare non prestabile a questa biblioteca esterna"),
													ClavisMessage::ERROR);
			}

			$this->DoLoan->setEnabled(false);
		}
	}

	public function drawReserveButton($item, $patron, $deliveryLibraryId)
	{
		//$forceItemCheck = (intval($item->getIssueId()) > 0 );
        $forceItemCheck = true;
		$returnValue = $this->_requestManager->isItemReservable($item,
																$patron,
																$deliveryLibraryId,
																$forceItemCheck);
		if ($patron instanceof Patron)
		{
			switch ($returnValue)
			{
				case (ClavisLoanManager::OK):
					$this->getPage()->enqueueMessage(Prado::localize("L'esemplare è disponibile per la prenotazione"),
														ClavisMessage::INFO);

					$this->DoReserve->setEnabled(true);

					break;

				case (ClavisLoanManager::RSV_NOTAVAIL):
					$this->getPage()->enqueueMessage(Prado::localize("Esemplare non prenotabile"),
														ClavisMessage::ERROR);

					$this->DoReserve->setEnabled(false);

					break;

                case (ClavisLoanManager::RSV_PATRONDISABLED):
                    $this->getPage()->enqueueMessage(Prado::localize("Utente non abilitato"),
													    ClavisMessage::ERROR);

                    $this->DoReserve->setEnabled(false);

                    break;

				case (ClavisLoanManager::RSV_PATRONHASITEM):
					$this->getPage()->enqueueMessage(Prado::localize("La prenotazione non è possibile perché l'utente ha già in prestito l'esemplare"),
														ClavisMessage::ERROR);

					$this->DoReserve->setEnabled(false);

					break;

				case (ClavisLoanManager::RSV_PATRONMAXREQ):
					$this->getPage()->enqueueMessage(Prado::localize("La prenotazione non è possibile perché l'utente ha già raggiunto il massimo numero di prenotazioni {num}",
																		array('num' => ClavisParamPeer::getParam('MAXLOANRESERVATIONS_' . $patron->getLoanClass(), '0'))),
														ClavisMessage::ERROR);

					$this->DoReserve->setEnabled(false);

					break;

				case (ClavisLoanManager::RSV_PATRONREQITEM):
					$this->getPage()->enqueueMessage(Prado::localize("La prenotazione non è possibile perché l'utente ha già una prenotazione per questo titolo"),
														ClavisMessage::ERROR);

					$this->DoReserve->setEnabled(false);

					break;

				case (ClavisLoanManager::ERROR):
				default:
					$this->getPage()->enqueueMessage(Prado::localize("Errore: esemplare non prenotabile da questo utente"),
														ClavisMessage::ERROR);

					$this->DoReserve->setEnabled(false);
			}
		}
		else
		{
			$this->getPage()->enqueueMessage(Prado::localize("Errore nel passaggio dei parametri. Riportare al fornitore del software, grazie"),
												ClavisMessage::ERROR);

			$this->DoReserve->setEnabled(false);
		}
	}

	public function onDeliveryLibraryChanged($sender, $param)
	{
		$patron = $this->getPatron();
		$item = ItemQuery::create()->findPK($this->getItemId());
		$libraryId = $this->DeliveryLibrary->getSelectedValue();
		$this->drawLoanButton($item, $patron, $libraryId);
	}

	public function onReserveDeliveryLibraryChanged($sender, $param)
	{
		$patron = $this->getPatron();
		$item = ItemQuery::create()->findPK($this->getItemId());
		$libraryId = $this->ReserveDeliveryLibrary->getSelectedValue();
		$this->drawReserveButton($item, $patron, $libraryId);
	}

	public function getPatron()
	{
		$patron_id = 0;

		if ($this->PanelLoan->getVisible())
		{
			$patron_id = intval($this->HiddenValue->getValue());

			if ($patron_id == 0)
				$patron_id = intval($this->PatronId->getSafeText());
		}
		elseif ($this->PanelReserve->getVisible())
		{
			$patron_id = intval($this->ReserveHiddenValue->getValue());

			if ($patron_id == 0)
				$patron_id = intval($this->ReservePatronId->getSafeText());
		}

		if ($patron_id > 0)
		{
			return PatronQuery::create()->findPK($patron_id);
		}
		else
		{
			return null;
		}
	}

	private function doPatronIdChanged($patronId = null)
	{
		$patronId = intval($patronId);

		if ($patronId > 0)
		{
			$patron = PatronQuery::create()->findPK($patronId);
		}
		else
		{
			$patron = $this->getPatron();
			$this->HiddenValue->setValue('');
			$this->PatronId->setText('');
			$this->ReserveHiddenValue->setValue('');
			$this->ReservePatronId->setText('');
			$this->setPatronId(null);
		}

		if ($patron instanceof Patron)
		{
			//patron alert
			if ((($patron->getAccessAlert() == PatronPeer::PATRONALERT_ALWAYS) || ($patron->getAccessAlert() == PatronPeer::PATRONALERT_LOAN))
					&& ($patronAccessNote = trim($patron->getAccessNote()) != ""))
				$this->getPage()->enqueueMessage($alert_from_patron = Prado::localize("ATTENZIONE") . ": " . $patronAccessNote,
													ClavisMessage::WARNING);
		}
		else
		{
			$this->PatronLabel->setText('');
			$this->ReservePatronLabel->setText('');

			return false;
		}

		$this->getPage()->cleanMessageQueue();
		$patronId = $patron->getPatronId();

		if ($this->PanelReserve->getVisible())   // prenotazione
		{
			$cLabel = 'ReservePatronLabel';
			$cId = 'ReservePatronId';
			$cDraw = 'drawReserveButton';
			$cDelivery = 'ReserveDeliveryLibrary';
		}
		elseif ($this->PanelLoan->getVisible())    // prestito
		{
			$cLabel = 'PatronLabel';
			$cId = 'PatronId';
			$cDraw = 'drawLoanButton';
			$cDelivery = 'DeliveryLibrary';
		}
		else
		{
			return false;
		}

		if ($this->$cLabel->getText() == '')
			$this->getPage()->setFocus($this->$cLabel->getClientID());

		$this->$cId->setText($patronId);
		$result = $this->insertPatron($patronId);

		$item = ItemQuery::create()->findPK($this->getItemId());
		$this->$cDraw($item, $patron, $this->$cDelivery->getSelectedValue());

		$this->getPage()->flushMessage();

		return $result;
	}

	public function onPatronIdChanged($sender, $param)
	{
		$this->doPatronIdChanged();
	}

	public function globalReset()
	{
		$this->doPatronClean();
		$this->doExternalLibraryClean();
		$this->resetExtraMode();

		$this->UserData->populate(null);
		$this->CirculationData->setPatronId(null);
		$this->CirculationData->populate(null);
	}

	public function onPatronCleanReserve($sender, $param)
	{
		$this->doPatronCleanReserve($param);
	}

	private function doPatronCleanReserve($param = null)
	{
		$this->ReservePatronLabel->setText('');
		$this->DoReserve->setEnabled(false);

		$this->ReserveUserData->populate(null);
		$this->ReserveUserDataPanel->setCssClass('panel_off');

		$this->ReserveCirculationData->setPatronId('');
		$this->ReserveCirculationData->populate(null);
		$this->ReservePatronId->setText(0);

		$this->renderPanel('ReserveUserDataPanel', $param);

		$this->getPage()->setFocus($this->ReservePatronLabel->getClientID());
	}

	public function getSelectedTabParameter($param = null)
	{
		if (!is_null($param))
		{
			$av = $param;
		}
		else
		{
			$av = $this->getPage()->TabPanel->getActiveViewIndex();
		}

		return array('selectTab' => $av);
	}

	public function onCancel($sender, $param)
	{
		$this->resetExtraMode();

		$this->panelButtons->setVisible(true);
		$this->PanelLoan->setVisible(false);
		$this->panelReturn->setVisible(false);
		$this->panelRenew->setVisible(false);
		$this->PanelReserve->setVisible(false);
		$this->panelAbort->setVisible(false);

		$this->doPatronClean($param);
	}

	public function onSwitchExtraMode($sender, $param)
	{
		$this->doPatronCleanReserve($param);
		$this->doExternalLibraryClean(null, $param);
		$this->setExtraMode(!$this->getExtraMode());
		$this->drawSendMailCheck();

		if (!is_null($param)
				&& $this->getPage()->getIsCallBack())
			$this->PanelReserve->render($param->getNewWriter());
	}

	public function onPatronClean($sender, $param)
	{
		$this->doPatronClean(true, $param);
	}

	private function doPatronClean($focus = false, $param = null)
	{
		$this->PatronLabel->setText('');
		$this->ReservePatronLabel->setText('');
		$this->ReserveExternalLibraryLabel->setText('');

		$this->DoLoan->setEnabled(false);
		$this->DoReserve->setEnabled(false);

		$this->UserData->populate(null);
		$this->ReserveUserData->populate(null);
		$this->UserDataPanel->setCssClass('panel_off');
		$this->ReserveUserDataPanel->setCssClass('panel_off');
		$this->LibraryDataPanel->setCssClass('panel_off');

		$this->CirculationData->setPatronId('');
		$this->CirculationData->populate(null);

		$this->ReserveCirculationData->setPatronId('');
		$this->ReserveCirculationData->populate(null);

		$this->PatronId->setText(0);
		$this->ReservePatronId->setText(0);
		$this->ReserveExternalLibraryId->setText(0);

		$this->renderPanel('UserDataPanel', $param);
		$this->renderPanel('ReserveUserDataPanel', $param);
		$this->renderPanel('LibraryDataPanel', $param);

		if ($focus)
			$this->getPage()->setFocus($this->PatronLabel->getClientID());
	}

	private function renderPanel($panel = '', $param)
	{
		if (trim($panel) == '')
			return false;

		if ($this->getPage()->getIsCallback())
		{
			if (is_null($param))
			{
				$writer = $this->getPage()->createWriter();
			}
			else
			{
				$writer = $param->getNewWriter();
			}

			$this->$panel->render($writer);
		}
	}

	public function getExternalLibraryId()
	{
		$libraryId = intval($this->ReserveHiddenValue2->getValue());

		if ($libraryId > 0)
		{
			$library_id = $libraryId;
		}
		else
		{
			$library_id = intval($this->ReserveExternalLibraryId->getSafeText());
		}

		return intval($library_id);
	}

	public function getExternalLibrary()
	{
		$library = null;
		$libraryId = $this->getExternalLibraryId();

		if ($libraryId > 0)
			$library = LibraryQuery::create()->findPK($libraryId);

		return $library;
	}

	public function onExternalLibraryClean($sender, $param)
	{
		$this->doExternalLibraryClean(true, $param);
	}

	private function doExternalLibraryClean($focus = false, $param = null)
	{
		$this->LibraryData->populate(null);    // implementare una sorta di ClavisLibraryDataCard
		$this->LibraryDataPanel->setCssClass('panel_off');  //setVisible(false);

		if ($this->getPage()->getIsCallBack())
		{
			if (is_null($param))
			{
				$this->LibraryDataPanel->render($this->getPage()->createWriter());
			}
			else
			{
				$this->LibraryDataPanel->render($param->getNewWriter());
			}
		}

		$this->ExternalLibraryId->setText(0);
		$this->ReserveHiddenValue2->setValue('');
		$this->DoReserve->setEnabled(false);
		$this->ReserveExternalLibraryLabel->setText('');

		if ($focus)
			$this->getPage()->setFocus($this->ReserveExternalLibraryLabel->getClientID());
	}

	public function onExternalLibraryIdChanged($sender, $param)
	{
		$library = $this->getExternalLibrary();

		if (is_null($library))
			return;

		$this->insertExternalLibrary($library->getLibraryId());
	}

	public function onExternalLibraryReload($sender, $param)
	{
		$this->insertExternalLibrary(trim($this->ExternalLibraryId->getSafeText()));
	}

	public function insertExternalLibrary($libraryId, $param = null)
	{
		$libraryId = intval($libraryId);
		$returnFlag = true;
		$this->LibraryData->populate($libraryId);
		$returnFlag = ($this->LibraryData->Populated->getValue() == 'true' ? true : false);

		$this->LibraryDataPanel->setCssClass($returnFlag ? 'panel_on' : 'panel_off');
		$this->LibraryData->setVisible($returnFlag);

		if ($this->getPage()->getIsCallBack())
		{
			if (is_null($param))
			{
				$writer = $this->getPage()->createWriter();
			}
			else
			{
				$writer = $param->getNewWriter();
			}

			$this->LibraryDataPanel->render($writer);
		}

		$library = LibraryQuery::create()->findPK($libraryId);

		if (is_null($library))
		{
			$label = '';
		}
		else
		{
			$label = $library->getLabel() . ' (' . $libraryId . ')';
		}

		$this->ExternalLibraryId->setText($libraryId);
		$this->ReserveExternalLibraryLabel->setText($label);
		$this->ReserveExternalLibraryId->setText($libraryId);

		if ($returnFlag)
		{
			$item = $this->getItem();
			$verifyCode = $this->_requestManager->isItemReservable(	$item,
																	$library,
																	$this->getUser()->getActualLibraryId());

			if ($verifyCode == ClavisLoanManager::OK)
			{
				$this->DoReserve->setEnabled(true);
				$this->getPage()->setFocus($this->DoReserve->getClientID());
			}
			else
			{
				$this->DoReserve->setEnabled(false);

				switch ($verifyCode)
				{
					case ClavisLoanManager::RSV_NOTAVAIL:
						$message = Prado::localize("Esemplare non prenotabile");

						break;

					case ClavisLoanManager::RSV_PATRONREQMANIF:
						$message = Prado::localize("Esemplare già prenotato dall'utente");

						break;

					case ClavisLoanManager::RSV_PATRONMAXREQ:
						$message = Prado::localize("L'utente ha già raggiunto il numero massimo di prenotazioni consentite");

						break;

					case ClavisLoanManager::RSV_RATING:
						$this->getPage()->writeMessage(Prado::localize("Prenotazione non possibile perchè utente minore dell'età consentita dal titolo"),
															ClavisMessage::ERROR);

						break;

					default:
						$message = Prado::localize("errore");
				}

				$this->getPage()->writeMessage($message,
												ClavisMessage::ERROR);
			}

			return true;
		}
		else
		{
			$this->getPage()->setFocus($this->ReserveExternalLibraryLabel->getClientID());
			$this->DoReserve->setEnabled(false);

			return false;
		}
	}

	public function suggestLibrary($sender, $param)
	{
		$token = $param->getCallBackParameter();
		$sender->setDataSource($this->getLibrarySuggestionsFor($token));
		$sender->dataBind(false);
	}

	public function suggestLibraryCallBack($sender, $param)
	{
		$resultFlag = false;
		$fieldText = $this->ReserveExternalLibraryLabel->getSafeText();
		$match = array();

		if (preg_match("/\[id:\ ([^\]]+)\]$/", $fieldText, $match))
		{
			$libraryId = $match[1];
		}
		else
		{
			$libraryId = $fieldText;
		}

		$libraryId = intval($libraryId);
		$library = LibraryQuery::create()->findPK($libraryId);

		if (!is_null($library))
			$resultFlag = $this->insertExternalLibrary($libraryId, $param);

		if ($resultFlag)
			$this->ReserveExternalLibraryLabel->setText('');
	}

	private function getLibrarySuggestionsFor($token)
	{
		$list = array();
		$criteria = new Criteria();

		$token = trim($token);

		if ($token != "")
		{
			$criteria->add(LibraryPeer::LABEL, "%" . $token . "%", Criteria::LIKE);
			$criteria->add(LibraryPeer::LIBRARY_INTERNAL, 1, Criteria::NOT_EQUAL);

			$criteria->setLimit(10);
			$criteria->addAscendingOrderByColumn(LibraryPeer::LABEL);
			$libraries = LibraryPeer::doSelect($criteria);

			foreach ($libraries as $library)
				$list[] = $library->getLabel() . " (" . $library->getConsortiaString(20) . ") [id: " . $library->getLibraryId() . "]";
		}

		return $list;
	}

	public function onSuspendRenew($sender, $param)
	{
		$clavisLibrarian = $this->getUser();
		$ok = false;
		$messageBody = Prado::localize("Non è stata eseguita alcuna operazione !");
		$messageType = ClavisMessage::WARNING;

		$item = (object) null;
		$itemId = intval($this->getItemId());

		if ($itemId > 0)
			$item = ItemQuery::create()->findPK($itemId);

		if ($item instanceof Item)
		{
			$itemtit = $item->getCompleteTitle();

			if (!$itemtit)
				$itemtit = Prado::localize('(nessun titolo)');

			if ($this->_loanmanager->IsItemLoaned($item))
			{
				switch ($this->_loanmanager->doDisableRenew($itemId,
															$clavisLibrarian))
				{
					case ClavisLoanManager::OK:
						$messageBody = Prado::localize("L'esemplare con titolo '{title}' [barcode: {barcode}, inv: {inv}] è stato sospeso dalle proroghe.",
															array(	'title' => $itemtit,
																	'inv' => $item->getCompleteInventoryNumber(),
																	'barcode' => $item->getBarcode()));

						$messageType = ClavisMessage::INFO;
						$ok = true;

						break;

					case ClavisLoanManager::ERROR:
						$messageBody = Prado::localize("L'operazione di sospensione di proroga è fallita");
						$messageType = ClavisMessage::ERROR;

						break;

					default:
						$messageBody = Prado::localize("Errore sconosciuto durante la sospensione di proroga");
						$messageType = ClavisMessage::ERROR;
				}
			}
			else
			{
				$messageBody = Prado::localize("L'esemplare con id = {id} e barcode = '{barcode}' NON E' IN PRESTITO !",
													array(	'id' => $item->getId(),
															'barcode' => $item->getBarcode()));

				$messageType =	ClavisMessage::ERROR;
			}
		}

		if ($ok)
		{
			$this->getPage()->writeDelayedMessage($messageBody, $messageType);
			$this->getPage()->reloadPage($this->getSelectedTabParameter(6));
		}
		else
		{
			$this->getPage()->writeMessage($messageBody, $messageType);
		}
	}

	public function onResumeRenew($sender, $param)
	{
		$clavisLibrarian = $this->getUser();
		$ok = false;
		$messageBody = Prado::localize("Non è stata eseguita alcuna operazione !");
		$messageType = ClavisMessage::WARNING;

		$item = (object) null;
		$itemId = intval($this->getItemId());

		if ($itemId > 0)
			$item = ItemQuery::create()->findPK($itemId);

		if ($item instanceof Item)
		{
			$itemtit = $item->getCompleteTitle();

			if (!$itemtit)
				$itemtit = Prado::localize('(nessun titolo)');

			if ($this->_loanmanager->IsItemLoaned($item))
			{
				switch ($this->_loanmanager->doEnableRenew(	$itemId,
															$clavisLibrarian))
				{
					case ClavisLoanManager::OK:
						$messageBody = Prado::localize("L'esemplare con titolo '{title}' [barcode: {barcode}, inv: {inv}] è stato riammesso alla proroga.",
															array(	'title' => $itemtit,
																	'inv' => $item->getCompleteInventoryNumber(),
																	'barcode' => $item->getBarcode()));

						$messageType = ClavisMessage::CONFIRM;

						if ($this->_loanmanager->IsLoanRenewable($item, $clavisLibrarian) != ClavisLoanManager::OK)
						{
							$messageBody .= '<br /><br />' . Prado::localize('Tuttavia il prestito non è rinnovabile.');
							$messageType = ClavisMessage::WARNING;
						}

						$ok = true;

						break;

					case ClavisLoanManager::ERROR:
						$messageBody = Prado::localize("L'operazione di riabilitazione alla proroga è fallita");
						$messageType = ClavisMessage::ERROR;

						break;

					default:
						$messageBody = Prado::localize("Errore sconosciuto durante la riabilitazione alla proroga");
						$messageType = ClavisMessage::ERROR;
				}
			}
			else
			{
				$messageBody = Prado::localize("L'esemplare con id = {item_id} e barcode = '{item_barcode}' NON E' IN CONSULTAZIONE !",
													array(	'item_id' => $item->getId(),
															'item_barcode' => $item->getBarcode() ));

				$messageType =	ClavisMessage::ERROR;
			}

		}

		if ($ok)
		{
			$this->getPage()->writeDelayedMessage($messageBody, $messageType);
			$this->getPage()->reloadPage($this->getSelectedTabParameter(6));
		}
		else
		{
			$this->getPage()->writeMessage($messageBody, $messageType);
		}
	}

	public function onForceInTransit($sender, $param)
	{
		$this->getPage()->cleanMessageQueue();
		$ok = false;
		$clavisLibrarian = $this->getUser();

		$item = (object) null;
		$itemId = intval($this->getItemId());

		if ($itemId > 0)
			$item = ItemQuery::create()->findPK($itemId);

		if ($item instanceof Item)
		{
			$itemtit = $item->getTrimmedTitle(60);

			if (!$itemtit)
				$itemtit = Prado::localize('(nessun titolo)');

			if ($item->getDeliveryLibraryId() == $clavisLibrarian->getActualLibraryId())
			{
				if ($this->_loanmanager->IsReadyForTransit($item))
				{
					switch ($this->_loanmanager->DoReadyToMove2MovingItem(	$item,
																			$clavisLibrarian,
																			Prado::localize('messa in transito forzata') ))
					{
						case ClavisLoanManager::OK:
							$this->getPage()->enqueueMessage(Prado::localize("L'esemplare con titolo '{title}' [barcode: {barcode}, inv: {inv}] è stato messo in transito forzato",
																				array(	'title' => $itemtit,
																						'inv' => $item->getCompleteInventoryNumber(),
																						'barcode' => $item->getBarcode())),
																ClavisMessage::CONFIRM);

							$ok = true;

							break;

						case ClavisLoanManager::ERROR:
							$this->getPage()->enqueueMessage(Prado::localize("L'operazione di messa in transito forzata è fallita. Contattare il Centro Servizi."),
																ClavisMessage::ERROR);

							break;

						case ClavisLoanManager::LOAN_EXTRASYSTEMINCONGRUENCY:
							$this->getPage()->enqueueMessage(Prado::localize("Incongruenza sul database. L'esemplare non sembra oggetto di prestito interbibliotecario nè extrasistema. Contattare il Centro Servizi."),
																ClavisMessage::ERROR);

							break;

						default:
							$this->getPage()->enqueueMessage(Prado::localize("Errore sconosciuto durante la messa in transito forzata. Contattare il Centro Servizi."),
																ClavisMessage::ERROR);
					}
				}
				else
				{
					$this->getPage()->enqueueMessage(Prado::localize("L'esemplare con titolo '{title}' [id: {item_id}, barcode: '{item_barcode}'] non è in stato di pronto al transito. La messa in transito forzata non è possibile. Contattare il Centro Servizi.",
																		array(	'title' => $itemtit,
																				'item_id' => $itemId,
																				'item_barcode' => $item->getBarcode())),
														ClavisMessage::ERROR);
				}
			}
			else
			{
				$this->getPage()->enqueueMessage(Prado::localize("L'esemplare con titolo '{title}' [id: {item_id}, barcode: '{item_barcode}'] è destinato alla biblioteca {dest}, e non alla biblioteca attuale. La messa in transito forzata non è possibile.",
																	array(	'title' => $itemtit,
																			'item_id' => $itemId,
																			'item_barcode' => $item->getBarcode(),
																			'dest' => $item->getDeliveryLibraryLabel() )),
													ClavisMessage::ERROR);
			}
		}

		if ($ok)
		{
			$this->getPage()->flushDelayedMessage();
			$this->getPage()->reloadPage($this->getSelectedTabParameter(6));
		}
		else
		{
			$this->getPage()->flushMessage();
		}
	}

}
