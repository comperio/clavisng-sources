<?php
/**
 * ClavisMultiSolicit
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2008 ePortal Technologies
 * @copyright Copyright &copy; 2008-2010 Comperio srl
 * @version 2.7
 * @package Widgets
 * @since 2.1
 */
Prado::using('Application.Common.SolicitModules.*');

class ClavisMultiSolicit extends TTemplateControl
{
	protected $_loanlist_ref = null;
	public $_masterChecked;
	private $_checked = array('all' => false);
	private $_checkedSessionName;
	private $_allsolicitSessionName;
	private $_datasource;
	private $_datasourceSessionName;
	private $_globalCriteria;

	private function initVars()
	{
		$uniqueId = $this->getUniqueID();
		$this->_checkedSessionName = 'CheckedSessionName' . $uniqueId;
		$this->_allsolicitSessionName = 'AllsolicitSessionName' . $uniqueId;
		$this->_datasourceSessionName = 'DatasourceSessionName' . $uniqueId;
	}

	public function onInit($param)
	{
		parent::onInit($param);
		$this->initVars();
	}

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallback())
			$this->resetPageState(false);

		$this->_checked = $this->getChecked();
	}

	private function resetGlobalCriteria()
	{
		$this->setGlobalCriteria(null);
	}

	private function setGlobalCriteria($criteria = null)
	{
		$this->setViewState('GlobalCriteria', $criteria, null);
	}

	private function getGlobalCriteria()
	{
		return SerializableCriteria::refreshCriteria(
						$this->getViewState('GlobalCriteria', null));
	}

	public function getPopupFlag()
	{
		return $this->getPage()->isPopup();
	}

	public function getSolicitMode()
	{
		return $this->getControlState('SolicitMode', 'solicit');
	}

	public function setSolicitMode($value)
	{
		$this->setControlState('SolicitMode', TPropertyValue::ensureEnum($value, array('solicit', 'readyforloan')), 'solicit');
	}

	public function populate()
	{
		$pageSize = $this->PatronGrid->getPageSize();
		$currentIndexPage = $this->PatronGrid->getCurrentPage();

		$criteria = new Criteria();
		$criteria->addJoin(PatronPeer::PATRON_ID, LoanPeer::PATRON_ID);
		$criteria->add(LoanPeer::LOAN_ID, $this->getCheckedItems(), Criteria::IN);
		$criteria->setDistinct();

		$recCount = PatronPeer::doCount($criteria);
		$this->setGlobalCriteria(clone $criteria);

		$criteria->setLimit($pageSize);
		$criteria->setOffset($currentIndexPage * $pageSize);

		//eventuali ordinamenti
		$patrons = PatronPeer::doSelect($criteria);

		$checkedList = $this->getChecked();
		$masterCheck = $checkedList['all'];

		$contactChannels = array();

		$data = array();
		foreach ($patrons as $patron)
		{
			$p = array();

			$patronId = intval($patron->getPatronId());
			$p['PatronId'] = $patronId;

			$checked = (array_key_exists($patronId, $checkedList)) ?
					$checkedList[$patronId] : false;

			if ($masterCheck)
				$checked = !$checked;
			$p['Checked'] = $checked;

			$p['SnailmailEnabled'] = false;
			$p['EmailEnabled'] = false;
			$p['PhoneEnabled'] = false;
			$p['MobileEnabled'] = false;
			$p['SmsEnabled'] = false;
			$p['SnailmailChecked'] = false;
			$p['EmailChecked'] = false;
			$p['PhoneChecked'] = false;
			$p['MobileChecked'] = false;
			$p['SmsChecked'] = false;
			$p['PatronName'] = $patron->getCompleteName();

			$addresses = $patron->getAddresss();
			if (count($addresses) != 0)
			{
				$p['SnailmailChecked'] = true;
				$contactChannels[] = NotificationPeer::CHANNEL_SNAILMAIL;
			}

			if (($contacts = $patron->getContacts()) != null)
			{
				foreach ($contacts as $contact)
				{
					/* @var $contact Contact   */
					switch ($contact->getContactType())
					{
						case 'E': //email
							$p['EmailChecked'] = true;
							$contactChannels[] = NotificationPeer::CHANNEL_EMAIL;
							break;
						case 'T': //phone
							$p['PhoneChecked'] = true;
							$contactChannels[] = NotificationPeer::CHANNEL_PHONE;
							break;
						case 'C': //cell.
							$p['MobileChecked'] = true;
							$contactChannels[] = NotificationPeer::CHANNEL_MOBILE;
							$p['SmsChecked'] = true;
							$contactChannels[] = NotificationPeer::CHANNEL_SMS;
							break;
						default:
							break;
					}
				}
			}
			$data[] = $p;
		}
		$this->PatronGrid->setVirtualItemCount($recCount);
		$this->PatronGrid->setDataSource($data);
		$this->PatronGrid->dataBind();
		$this->setDatasource($data);

		$this->PatronGridPanel->setVisible($recCount > 0);
		$this->FoundNumber->setText($recCount);

		$this->setControlState('ContactChannels', array_unique($contactChannels));
		$this->Notify->initChannels();
	}

	/**
	 * Manages the change of page in the datagrid.
	 * Uses the viewstate to store the current page.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function changePage($sender, $param)
	{
		$this->PatronGrid->setCurrentPage($param->NewPageIndex);
		$this->populate();
		$this->getPage()->setFocus($this->FoundPanel->getClientID());
	}

	public function globalRefresh()
	{
		$this->populate();
	}

	public function setLoanListRef($loanListRef)
	{
		$this->_loanlist_ref = $loanListRef;
		$this->setControlState('loan_list_ref', $loanListRef, null);
	}

	public function getLoanListRef()
	{
		$this->_loanlist_ref = $this->getControlState('loan_list_ref', null);
		return $this->_loanlist_ref;
	}

	private function setGeneralVisibility($visible)
	{
		$this->NotificationPanel->setVisible($visible);
		$this->PatronGridPanel->setVisible($visible);
		$this->FoundPanel->setVisible($visible);
	}

	public function onFillPatrons($sender, $param)
	{
		$checked = $this->getCheckedItems();

		if (count($checked) > 0)
		{
			$this->setGeneralVisibility(true);
			$this->resetPagination();
			$this->resetFields();
			$this->emptyDatasources();
			$this->resetChecked(true);
			$this->resetAllsolicit(false);
			$this->populate();
			$this->getPage()->setFocus($this->FoundPanel->getClientID());
		}
		else
		{
			$this->setGeneralVisibility(false);
			$this->getPage()->writeMessage(Prado::localize('ATTENZIONE: non hai selezionato alcun prestito'), ClavisMessage::WARNING);
		}
	}

	public function getLoanIds()
	{
		return $this->getCheckedItems();
	}

	public function getDestinations()
	{
		$patrons = PatronPeer::retrieveByPKs($this->getCheckedId());
		return $patrons;
	}

	public function getContactChannels()
	{
		return ($this->getControlState('ContactChannels', array(
					NotificationPeer::CHANNEL_EMAIL,
					NotificationPeer::CHANNEL_SNAILMAIL,
					NotificationPeer::CHANNEL_SMS,
					NotificationPeer::CHANNEL_MOBILE,
					NotificationPeer::CHANNEL_PHONE)));
	}

	protected function getPatronEmails($patronId, $onlyFirst = true)
	{
		$criteria = new Criteria();

		$criteria->add(ContactPeer::CONTACT_TYPE, ContactPeer::TYPE_EMAIL);
		$criteria->add(ContactPeer::PATRON_ID, $patronId);

		$patronEmails = array();
		$contacts = ContactPeer::doSelect($criteria);
		foreach ($contacts as $contact)
		{
			$patronEmails[] = $contact->getContactValue();
		}

		return $patronEmails;
	}

	protected function resetPageState($loanListReloadFlag = true)
	{
		$this->resetFields();
		$this->emptyDatasources();

		if ($loanListReloadFlag)
			$this->loanListInitialReload();
	}

	private function resetFields()
	{
		$this->PatronGridPanel->setVisible(false);
		$this->FoundNumber->setText(0);
	}

	private function emptyDatasources()
	{
		$this->resetPagination();
		$this->resetChecked(true);
		$this->resetAllsolicit(false);
		$this->resetGlobalCriteria();
		$this->PatronGrid->setDatasource(null);
		$this->PatronGrid->dataBind();
		$this->resetDatasource();
	}

	public function resetGetCheckedItemsFunctionName()
	{
		$this->setGetCheckedItemsFunctionName('');
	}

	public function setGetCheckedItemsFunctionName($name = '')
	{
		$this->setViewState('GetCheckedItemsFunctionName', $name, '');
	}

	public function getGetCheckedItemsFunctionName()
	{
		return $this->getViewState('GetCheckedItemsFunctionName', '');
	}

	public function resetCountCheckedItemsFunctionName()
	{
		$this->setCountCheckedItemsFunctionName('');
	}

	public function setCountCheckedItemsFunctionName($name = '')
	{
		$this->setViewState('CountCheckedItemsFunctionName', $name, '');
	}

	public function getCountCheckedItemsFunctionName()
	{
		return $this->getViewState('CountCheckedItemsFunctionName', '');
	}

	public function resetInitialReloadFunctionName()
	{
		$this->setInitialReloadFunctionName('');
	}

	public function setInitialReloadFunctionName($name = '')
	{
		$this->setViewState('InitialReloadFunctionName', $name, '');
	}

	public function getInitialReloadFunctionName()
	{
		return $this->getViewState('InitialReloadFunctionName', '');
	}

	public function loanListInitialReload()
	{
		$functionName = TPropertyValue::ensureString($this->getInitialReloadFunctionName());
		if ($functionName != '')
			$this->getPage()->$functionName();
	}

	public function getCheckedItems()
	{
		$output = array();
		$functionName = TPropertyValue::ensureString($this->getGetCheckedItemsFunctionName());

		if ($functionName != '')
			$output = $this->getPage()->$functionName();

		return $output;
	}

	public function countCheckedItems()
	{
		$output = 0;
		$functionName = TPropertyValue::ensureString($this->getCountCheckedItemsFunctionName());
		if ($functionName != '')
			$output = $this->getPage()->$functionName();

		return $output;
	}

	/////   checking logic

	public function onFlipAllsolicit($sender, $param)
	{
		$checked = $this->getAllsolicit();
		$index = $sender->Parent->Parent->ItemIndex;

		$newStatus = $sender->getChecked();
		$dataSource = $this->getDatasource();

		$row = $dataSource[$index];
		$patronId = $row['PatronId'];

		if ($newStatus != $checked['all'])
			$checked[$patronId] = true;
		else
			unset($checked[$patronId]);

		$this->setAllsolicit($checked);
	}

	public function onFlipChecked($sender, $param)
	{
		$checked = $this->getChecked();
		$index = $sender->Parent->Parent->ItemIndex;

		$newStatus = $sender->getChecked();
		$dataSource = $this->getDatasource();

		$row = $dataSource[$index];
		$patronId = $row['PatronId'];

		if ($newStatus != $checked['all'])
			$checked[$patronId] = true;
		else
			unset($checked[$patronId]);

		$this->setChecked($checked);
	}

	public function onMasterChecked($sender, $param)
	{
		$newStatus = $sender->getChecked();
		$this->resetChecked($newStatus);

		$gridItems = $this->PatronGrid->getItems();
		foreach ($gridItems as $item)
			$item->SolicitUserCol->CheckedBox->setChecked($newStatus);
	}

	public function resetChecked($state = false)
	{
		$this->setChecked(array('all' => $state));
	}

	public function setChecked($checked = null)
	{
		$this->_checked = $checked;
		$this->getApplication()->getSession()->add($this->_checkedSessionName, $checked);
	}

	public function getChecked()
	{
		$this->_checked = $this->getApplication()->getSession()->itemAt($this->_checkedSessionName);
		return $this->_checked;
	}

	public function resetAllsolicit($state = false)
	{
		$this->setAllsolicit(array('all' => $state));
	}

	public function setAllsolicit($checked = null)
	{
		$this->getApplication()->getSession()->add($this->_allsolicitSessionName, $checked);
	}

	public function getAllsolicit()
	{
		return $this->getApplication()->getSession()->itemAt($this->_allsolicitSessionName);
	}

	public function getCheckedId()
	{
		$checked = $this->getChecked();

		$this->_masterChecked = $checked['all'];
		unset($checked['all']);
		$checkedIds = array_keys($checked);

		$output = array();

		if (!$this->_masterChecked)
			$output = $checkedIds;
		else		 // caso del mastercheck inverso
		{
			$criteria = $this->getGlobalCriteria();

			if (!is_null($criteria) && ($criteria instanceof Criteria))
			{
				if (count($checkedIds) > 0)
					$criteria->add(PatronPeer::PATRON_ID, $checkedIds, Criteria::NOT_IN);
				$patrons = PatronPeer::doSelectStmt($criteria);
				while ($patronId = $patrons->fetchColumn(0))
					$output[] = $patronId;
			}
			else if (!is_null($criteria) && (is_array($criteria)))
			{
				$output = array_fill_keys(array_diff($criteria, $checkedIds), true);
			}
		}

		return $output;
	}

	public function getAllsolicitId()
	{
		$checked = $this->getAllsolicit();

		$master = $checked['all'];
		unset($checked['all']);
		$checkedIds = array_keys($checked);

		$output = array();

		if (!$master)
		{
			$output = $checkedIds;
		}
		else		 // caso del mastercheck inverso
		{
			$criteria = $this->getGlobalCriteria();

			if (!is_null($criteria) && ($criteria instanceof Criteria))
			{
				if (count($checkedIds) > 0)
					$criteria->add(PatronPeer::PATRON_ID, $checkedIds, Criteria::NOT_IN);
				$patrons = PatronPeer::doSelectStmt($criteria);
				while ($patronId = $patrons->fetchColumn(0))
					$output[] = $patronId;
			}
			else if (!is_null($criteria) && (is_array($criteria)))
			{
				$output = array_fill_keys(array_diff($criteria, $checkedIds), true);
			}
		}

		return $output;
	}

	private function isAllsolicitPatronId($patronId = 0)
	{
		$return = false;
		if (intval($patronId) > 0)
		{
			$checked = $this->getAllsolicitId();
			$return = in_array($patronId, $checked);
		}
		return $return;
	}

	public function getMasterChecked()
	{
		$masterChecked = false;

		$checked = $this->getChecked();
		if (array_key_exists('all', $checked))
			$masterChecked = $checked['all'];
		else
		{
			$newState = false;
			$checked['all'] = $newState;
			$this->setChecked($checked);
			$masterChecked = $newState;
		}
		return $masterChecked;
	}

	private function resetDatasource()
	{
		$this->setDatasource(array());
	}

	private function setDatasource($datasource = array())
	{
		$this->_datasource = $datasource;
		$this->getApplication()->getSession()->add($this->_datasourceSessionName, $this->_datasource);
	}

	private function getDatasource()
	{
		$this->_datasource = $this->getApplication()->getSession()->itemAt($this->_datasourceSessionName);
		return $this->_datasource;
	}

	public function resetPagination()
	{
		$this->PatronGrid->setCurrentPage(0);
	}
	
}