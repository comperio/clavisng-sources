<?php

/**
 * ClavisACLGrid
 *
 * @author Max Pigozzi
 * @author Ciro Mattia Gonano
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2008 ePortal Technologies
 * @copyright Copyright &copy; 2009 Comperio srl
 */

class ClavisACLGrid extends TTemplateControl {

	private $_datasource = null;

	private $_bNew = false;

	public function onLoad($param) 	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsPostBack()) {
			$c = new Criteria();
			$c->addAscendingOrderByColumn(AppModulePeer::SORT_ORDER);
			$modules = AppModulePeer::doSelect($c);
			$ds = array(0 => '---');
			foreach ($modules as $m) {
				$ds[$m->getModuleId()] = $m->getModuleId();
			}
			$this->ModuleFilter->setDataSource($ds);
			$this->ModuleFilter->dataBind();
			$c = new Criteria();
			$c->addAscendingOrderByColumn(AppProfilePeer::PROFILE_ID);
			$modules = AppProfilePeer::doSelect($c);
			$ds = array(0 => '---');
			foreach ($modules as $m) {
				$ds[$m->getProfileId()] = $m->getName();
			}
			$this->ProfileFilter->setDataSource($ds);
			$this->ProfileFilter->dataBind();
			$this->populateACLGrid();
		}
	}



	public function populate()
	{
		$this->populateACLGrid();
	}


	private function populateACLGrid() {

		$pageSize = $this->ACLGrid->getPageSize();
		$currentPage = $this->ACLGrid->getCurrentPage();

		$c = new Criteria();

		if ($this->ModuleFilter->getSelectedValue())
			$c->add(AppProfileAclPeer::MODULE_ID,$this->ModuleFilter->getSelectedValue());

		if ($this->ProfileFilter->getSelectedValue())
			$c->add(AppProfileAclPeer::PROFILE_ID,$this->ProfileFilter->getSelectedValue());

		$recCount = AppProfileAclPeer::doCount($c);
		$this->ACLGrid->setVirtualItemCount($recCount);

		$c->addAscendingOrderByColumn(AppProfileAclPeer::MODULE_ID);
		$c->addAscendingOrderByColumn(AppProfileAclPeer::ACTION_ID);
		$c->addAscendingOrderByColumn(AppProfileAclPeer::PROFILE_ID);

		$c->setLimit($pageSize);
		$c->setOffset($currentPage * $pageSize);

		$ACLs = AppProfileAclPeer::doSelect($c);

		/* @var $ACL AppProfileAcl */
		foreach ($ACLs as $ACL)
		{
			$p = array();
			$p['ModuleId'] = $ACL->getModuleId();
			$p['ActionId'] = $ACL->getActionId();

			$action = AppActionPeer::retrieveByPK($p['ActionId']);
			if (!is_null($action))
				$p['Action'] = $action->getLabel();
			else
				$p['Action'] = '---';

			$p['ProfileId'] = $ACL->getProfileId();
			$profile = AppProfilePeer::retrieveByPK($p['ProfileId']);
			if (!is_null($profile))
				$p['Profile'] = $profile->getName();
			else
				$p['Profile'] = '---';

			$p['Permission'] = $ACL->getAction();
			$p['Id'] = $ACL->getModuleId().'|'.$ACL->getActionId().'|'.$ACL->getProfileId();

			$this->_datasource[] = $p;
		}

		//$this->ACLGrid->CurrentPageIndex = $this->getViewState("CurrentPage",0);
		$this->ACLGrid->setDataSource($this->_datasource);
		$this->ACLGrid->dataBind();
	}

	public function changePage($sender,$param) {

		$this->ACLGrid->setCurrentPage($param->NewPageIndex);
		$this->populateACLGrid();
	}

	public function getPopupFlag()
	{
		return $this->getPage()->IsPopup();
	}


	public function ACLCreated($sender,$param)
	{

		$item=$param->Item;
		if($item->ItemType==='EditItem')
		{
			$ds = AppModulePeer::doSelectOrderByRank();
			$item->Cells[0]->ModuleNewList->setDataSource($ds);
			$item->Cells[0]->ModuleNewList->dataBind();

			$ds = AppActionPeer::retrieveList($item->DataItem['ModuleId']);
			$item->Cells[1]->ActionNewList->setDataSource($ds);
			$item->Cells[1]->ActionNewList->dataBind();

			$c = new Criteria();
			$c->addAscendingOrderByColumn(AppProfilePeer::PROFILE_ID);
			$ds = AppProfilePeer::doSelect($c);
			$item->Cells[2]->ProfileNewList->setDataSource($ds);
			$item->Cells[2]->ProfileNewList->dataBind();
		}
		if($item->ItemType==='Item' || $item->ItemType==='AlternatingItem' || $item->ItemType==='EditItem')
		{
			// add an alert dialog to delete buttons
			$item->Cells[5]->Controls[0]->Attributes->onclick='if(!confirm(\''.Prado::localize("Sei sicuro?").'\')) return false;';
		}

	}

 	public function editACL($sender,$param)
	{
		$this->getPage()->globalEditCancel();
		$this->_datasource = array();
		$this->setViewState('newItem', false);
		$this->populateACLGrid();
		$this->ACLGrid->setEditItemIndex($param->Item->ItemIndex);
		$this->ACLGrid->setDataSource($this->_datasource);
		$this->ACLGrid->dataBind();
	}

	public function saveACL($sender,$param)
	{

		$item=$param->Item;
		$itemIndex = $item->ItemIndex;



		$row = $this->_datasource[$itemIndex];

		$id = $this->ACLGrid->DataKeys[$itemIndex];

		$keys = explode('|',$id);

		if($this->getViewState('newItem') == true) {
			//save da new item
			$module_id = $item->Cells[0]->Controls[1]->Controls[1]->SelectedValue;
			$action_id = $item->Cells[1]->Controls[1]->Controls[1]->SelectedValue;
			$profile_id = $item->Cells[2]->Controls[1]->Controls[1]->SelectedValue;

			$permission = $item->Cells[3]->Controls[1]->SelectedValue;

		} else {
			//save da update item
			$module_id = $keys[0];
			$action_id = $keys[1];
			$profile_id = $keys[2];

			$permission = $item->Cells[3]->Controls[1]->SelectedValue;
		}

		$acl = AppProfileAclPeer::retrieveByPK($module_id,$action_id,$profile_id);

		if ($acl != null) {

			$acl->setAction($permission);

			$acl->save();

		} else {
			$acl = new AppProfileAcl();

			$acl->setModuleId($module_id);
			$acl->setActionId($action_id);
			$acl->setProfileId($profile_id);
			$acl->setAction($permission);


			$acl->save();

		}


		$this->ACLGrid->EditItemIndex = -1;
		$this->populateACLGrid();


	}

	public function cancelACLEdit($sender,$param)
	{
		if ($this->ACLGrid->EditItemIndex != -1) {
			$this->ACLGrid->EditItemIndex=-1;
			$this->populateACLGrid();
			$this->ACLGrid->DataSource=$this->_datasource;
			$this->ACLGrid->dataBind();

			$this->getPage()->setFocus("anchor_start");
		}
	}

	public function cancelEdit()
	{

		$this->ACLGrid->EditItemIndex=-1;
		$this->ACLGrid->dataBind();

	}


	public function deleteACL($sender,$param)
	{
		//$item = $param->Item;
		$id = $this->ACLGrid->DataKeys[$param->Item->ItemIndex];

		$keys = explode('|',$id);
		AppProfileAclPeer::doDelete($keys);

		$this->ACLGrid->EditItemIndex=-1;
		$this->populateACLGrid();
	}

	public function addNewACL()
	{
		$this->getPage()->globalEditCancel();
		//
		$this->_datasource = array();
		//
		$this->setViewState('newItem', true);
		//

		$p = array();
		$p['Id'] = "";
		$p['ModuleId'] = "LIBRARY";
		$p['ActionId'] = -1;
		$p['Action'] = "";
		$p['ProfileId'] = "";
		$p['Profile'] = "";
		$p['Permission'] = "";

		$this->_datasource[] = $p;

		$this->populateACLGrid();
		//$this->populateProfileGrid();
		//$this->ACLGrid->EditItemIndex=count($this->_datasource) - 1;
		$this->ACLGrid->EditItemIndex=0;
		$this->ACLGrid->DataSource=$this->_datasource;
		$this->ACLGrid->dataBind();

	}

	public function itemDataBound($sender, $param) {
		$item = $param->Item;

		if($item->ItemType == "EditItem") {
			if($this->getViewState('newItem') == true) {
				$item->Cells[0]->moduleNewPanel->Visible=true;
				$item->Cells[0]->moduleEditPanel->Visible=false;

				if (is_null($item->Cells[0]->Controls[1]->Controls[1]->DataSource)) {
					$item->Cells[0]->Controls[1]->Controls[1]->populateList();
					//
					Prado::log("populate");
				}
				/*
				if ($item->DataItem['ModuleId'] != "")
					$item->Cells[0]->Controls[1]->Controls[1]->setSelectedValue($item->DataItem['ModuleId']);
				else
					$item->Cells[0]->Controls[1]->Controls[1]->setSelectedIndex(-1);
				*/
					//
				$item->Cells[1]->actionNewPanel->Visible=true;
				$item->Cells[1]->actionEditPanel->Visible=false;

				$item->Cells[1]->Controls[1]->Controls[1]->setParam1($item->DataItem['ModuleId']);
				$item->Cells[1]->Controls[1]->Controls[1]->populateList();
				$item->Cells[1]->Controls[1]->Controls[1]->setSelectedIndex(0);
				//
				$item->Cells[2]->profileNewPanel->Visible=true;
				$item->Cells[2]->profileEditPanel->Visible=false;

				$item->Cells[2]->Controls[1]->Controls[1]->populateList();
				$item->Cells[2]->Controls[1]->Controls[1]->setSelectedIndex(0);
				//
				$item->Cells[3]->Controls[1]->setSelectedValue('ALLOW');

				//$this->getPage()->setFocus($item->Cells[0]->Controls[1]->Controls[1]->getClientId());

			} else {
				$item->Cells[0]->moduleNewPanel->Visible=false;
				$item->Cells[0]->moduleEditPanel->Visible=true;

				$item->Cells[1]->actionNewPanel->Visible=false;
				$item->Cells[1]->actionEditPanel->Visible=true;

				$item->Cells[2]->profileNewPanel->Visible=false;
				$item->Cells[2]->profileEditPanel->Visible=true;

				$item->Cells[3]->Controls[1]->setSelectedValue($item->DataItem['Permission']);

				//$this->getPage()->setFocus($item->Cells[3]->Controls[1]->getClientId());
				//$this->getPage()->setFocus("anchor_edit");
			}



		}
	}

	public function changedModuleList($sender, $param) {
		//$item = $param->Item;
		//Prado::log("changedModuleList");
		$item = $sender->Parent->Parent->Parent;

		if($item->ItemType == "EditItem") {
			$item->Cells[1]->Controls[1]->Controls[1]->setSelectedIndex(0);
			$item->Cells[1]->Controls[1]->Controls[1]->setParam1($item->Cells[0]->Controls[1]->Controls[1]->getSelectedValue());
			$item->Cells[1]->Controls[1]->Controls[1]->populateList();

		}
	}

	public function globalRefresh()
	{
		$this->populate();
	}

	public function applyFilter($sender,$param) {
		$this->ACLGrid->setCurrentPage(0);
		$this->populateACLGrid();
	}
}