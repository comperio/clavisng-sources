<?php
/**
 * ClavisSMSList
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2011 Comperio srl
 * @license http://www.comperio.it/license/
 */

class ClavisSMSList extends TTemplateControl {

	const MONTHTIME = 2592000;

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallback()) {
			$this->FilterDateFrom->setData(time() - self::MONTHTIME);
			$this->populate();
		}
	}

	public function populate()
	{
		$sm = $this->getApplication()->getModule('sms');

		$from = $this->FilterDateFrom->getTimeStamp();
		$to = $this->FilterDateTo->getTimeStamp();
		if (!$to) {
			$to = time();
			//$this->FilterDateTo->setTimeStamp($to);
		}

		if (!$from || ($from > $to)) {
			$from = $to - self::MONTHTIME;	// default to last month.
			//$this->FilterDateFrom->setTimeStamp($from);
		}

		$ds = $sm->getHistory($from,$to);
		$this->SMSHistoryGrid->setDataSource($ds);
		$this->SMSHistoryGrid->dataBind();
	}

	public function filterHistory($sender, $param) {
		$this->populate();
	}

	public function getPopupFlag() {
		return $this->getPage()->IsPopup();
	}
}