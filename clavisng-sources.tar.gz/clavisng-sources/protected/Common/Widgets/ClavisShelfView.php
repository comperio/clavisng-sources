<?php
/**
 * ClavisShelfView
 *
 * @author Max Pigozzi
 * @link http://www.e-portaltech.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @license http://www.e-portaltech.it/license/
 *
 * Component which shows the data of a single shelf.
 *
 */
require_once("clavis/LookupValue.php");

class ClavisShelfView extends TTemplateControl
{
	/**
	 * Object Shelf which we are treating.
	 *
	 * @var Shelf
	 */
	private $_shelf = null;

	/**
	 * In the onLoad, during first execution of the page we
	 * get the actual shelf and populate the list.
	 *
	 * @param TEventParameter $param
	 */
	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsPostBack())
		{
			$this->getShelf();
			$this->populate();
		}
	}

	public function setShelf($shelf)
	{
		$this->_shelf = $shelf;
		$this->setViewState("shelf", $shelf, null);
	}

	public function getShelf()
	{
		if (is_null($this->_shelf))
			$this->_shelf = $this->getViewState("shelf", null);

		return $this->_shelf;
	}

	/**
	 * Population of main data of the shelf.
	 *
	 */
	public function populate()
	{
		if ($this->_shelf === null)
			return;

		$name = $this->_shelf->getEnsuredShelfName();
		
		if ($name)
			$this->ShelfName->setText($name);

		$description = $this->_shelf->getShelfDescription();
		
		if ($description)
			$this->ShelfDescription->setText($description);

		$statusString = $this->_shelf->getShelfStatusString($this->getApplication()->getGlobalization()->getCulture());
		
		if ($statusString)
			$this->ShelfStatusString->setText($statusString);

		$libraryString = $this->_shelf->getEnsuredLibraryLabel();
		
		if ($libraryString != '')
			$this->ShelfLibraryString->setText($libraryString);

		$typeString = $this->_shelf->getShelfItemtypeString();
		
		if ($typeString != '')
		{
			$this->ShelfItemtypeString->setText($typeString);
			$this->ItemtypePanel->setVisible(true);
		}
		else
		{
			$this->ItemtypePanel->setVisible(false);
		}
	}
	
}