<?php
/**
 * ZetaDriver class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info
 * @comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Modules.Import
 */

/**
 * ZetaDriver class
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Modules.Import
 * @since 2.5.0
 */

class ZetaDriver extends BaseImportDriver implements IImportDriver
{
	const ERR_BADQUERY = 194;

	protected $_element = 'F';
	protected $_parameters = array(
		'user'		=> '',
		'password'	=> '',
		'charset'	=> '',
		'persistent'	=> false,
		'piggyback'		=> false
	);

	public function getOptionalParameters()
	{
		return array(
			'user'		=> 'string',
			'password'	=> 'string',
			'charset'	=> 'string',
			'persistent'	=> 'boolean',
			'piggyback'		=> 'boolean'
		);
	}

	public function getRecordTurbomarc() {}

	/**
	 * Eventually queries the server and returns the results in an array of TurboMarc objects.
	 *
	 * @param Array $queryParams The query criterions as an array of array('field'=>'foo','value'=>'bar') criterions.
	 * 					Currently supported fields are: 'title','ean','date','publisher','author'.
	 * @return Array The query results as an array of TurboMarc objects.
	 * @throws Exception
	 */
	public function search($queryParams)
	{
		if (!extension_loaded('yaz'))
			throw new Exception('YAZ extension is required!',parent::ERR_GENERIC);

		$zconn = yaz_connect($this->_address,$this->_parameters);
		if ($zconn === false)
			throw new Exception('Server is not available',parent::ERR_NOTAVAILABLE);

		$zquery = array();
		foreach ($queryParams as $field => $value) {
			if (!in_array($field,$this->_searchFields))
				continue;
			switch ($field) {
				case 'title':
					$zquery[] = "@attr 1=4 \"{$value}\"";
					break;
				case 'ean':
					$value = Clavis::normalizeStdNum($value);
					$value2 = (strlen($value) == 13) ?
						Clavis::Ean13ToIsbn($value) :
						Clavis::IsbnToEan13($value);
					$zquery[] = "@or @attr 1=8 \"{$value}\" ".
						"@or @or @attr 1=7 \"{$value}\" @attr 1=7 \"".Clavis::hyphenateStdNum($value).'" '.
						"@or @attr 1=7 \"{$value2}\" @attr 1=7 \"".Clavis::hyphenateStdNum($value2).'"';
					break;
				case 'date':
					$zquery[] = "@attr 1=31 \"{$value}\"";
					break;
				case 'publisher':
					$zquery[] = "@attr 1=1018 \"{$value}\"";
					break;
				case 'author':
					$zquery[] = "@attr 1=1003 \"{$value}\"";
					break;
				case 'biblevel':
					$zquery[] = "@attr 1=1021 \"{$value}\"";
					break;
				case 'bid':
					$value = str_replace('\\','\\\\', $value);
					$zquery[] = "@attr 1=1032 \"{$value}\"";
					break;
				default:
					break;
			}
		}
		if (!count($zquery))
			throw new Exception('No search field specified or usable');
		// z39.50 query is in reverse polish notation, so build it accordingly.
		$lastElement = array_pop($zquery);
		if (count($zquery) == 0) {
			$fullquery = $lastElement;
		} else {
			$fullquery = '@and '.implode('@and ',$zquery).' '.$lastElement;
		}

		yaz_syntax($zconn, $this->_syntax);
		yaz_element($zconn, $this->_element);
		//yaz_range($zconn, 1, $this->_max_results); Removes this due to SBN Server issue
		if (yaz_search($zconn, 'rpn', $fullquery) === false)
			throw new Exception("Bad query: $fullquery",self::ERR_BADQUERY);

		/* actually do the query */
		$opts = array('timeout'=>$this->_timeout);
		$ret = yaz_wait($opts);

		if ($ret === false) {
			$error = yaz_error($zconn);
			$errno = yaz_errno($zconn);
			$addinfo = yaz_addinfo($zconn);
			throw new Exception("Connection error: $error ($addinfo)",$errno);
		}
		$hits = yaz_hits($zconn);
		$max_return = min($hits,$this->_max_results);

		$resultSet = array();
		for ($pos=1; $pos<=$max_return; ++$pos) {
			$yaz_record = yaz_record($zconn,$pos,'raw');
			$tm = $this->yaz2tmarc($yaz_record);
			if ($tm instanceof TurboMarc) {
				try {
					$tm = TurboMarc::createRecord($tm->asXML());
					$tm = $this->convertBid($this->applyRecordConversions($tm));
					if (!$tm instanceof TurboMarc)
						throw new Exception('Turbomarc is not a valid turbomarc: '.
							Prado::varDump($tm));
					$resultSet[] = $tm->asXML();
				} catch (Exception $e) {
					throw $e;
				}
			}
		}
		yaz_close($zconn);
		return array(
			'Results'	=> $resultSet,
			'Count'		=> $hits
		);
	}

	/**
	 * Converts a yaz record string to TurboMarc object.
	 *
	 * @param string $yaz_record
	 * @return TurboMarc The converted TurboMarc object
	 * @throws Exception
	 */
	public function yaz2tmarc($yaz_record)
	{
		switch ($this->_format) {
			case 'UNIMARC':
				$tm = TurboMarc::createRecord();
				$tm->parseRecord($yaz_record, $this->_encoding != 'utf8');
				$tm = TurboMarcUtility::sanitize($tm);
				break;
			case 'USMARC':
			case 'MARC21':
				$tm = TurboMarc::createRecord();
				$tm->parseMarc21($yaz_record, $this->_encoding != 'utf8');
				$tm = TurboMarcUtility::sanitize($tm);
                $leader = $tm->getLeader();
                $leader->entitytype = ' ';
                $tm->setLeader($leader);

				break;
			default:
				throw new Exception("Marc standard [{$this->_format}] not recognized");
		}
		return $tm;
	}

	private function convertBid(TurboMarc $tm) {
		$xml = $tm->asXML();
		$source = strtolower($this->_sourceName);
		$temp = <<<EOF
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
	<xsl:output indent="yes"/>
	<xsl:strip-space elements="*"/>

	<xsl:template match="@* | node()">
		<xsl:copy>
			<xsl:apply-templates select="@* | node()"/>
		</xsl:copy>
	</xsl:template>

	<xsl:template match="*[starts-with(local-name(),'s')]">
		<xsl:choose>
			<!-- convert clavis ids -->
			<xsl:when test="local-name()='s3'">
				<xsl:element name="s{$source}">
					<xsl:value-of select="."/>
				</xsl:element>
			</xsl:when>
			<xsl:otherwise>
				<xsl:copy>
					<xsl:apply-templates select="@* | node()"/>
				</xsl:copy>
			</xsl:otherwise>
		</xsl:choose>
	</xsl:template>

</xsl:stylesheet>
EOF;
		$xsl = new DOMDocument;
		$xsl->loadXML($temp);
		$proc = new XSLTProcessor;
		$proc->importStyleSheet($xsl);
		if ($xml instanceof SimpleXMLElement) {
			$doc = dom_import_simplexml($xml)->ownerDocument;
		} else {
			$doc = new DOMDocument();
			$doc->loadXML($xml);
		}
		$sorted = $proc->transformToXML($doc);
		return TurboMarc::createRecord($sorted);
	}
}
