<?php
/**
 * ClavisDriver class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info
 * @comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Modules.Import
 */

/**
 * ClavisDriver class
 * 
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Modules.Import
 * @since 2.5.0
 */
class ClavisDriver extends BaseImportDriver implements IImportDriver
{
	public function getOptionalParameters()
	{
		return array(
			'user'		=> 'string',
			'password'	=> 'string'
		);
	}
	
	public function setAddress($value)
	{
		if (substr($value,0,7)!='http://')
			$value = 'http://'.$value;
		parent::setAddress($value);
	}
	
	public function search($queryParam)
	{
		$ean = null;
		foreach ($queryParam as $field => $param)
			if ($field == 'ean')
				$ean = $param;

		if ($ean != null) {
			$xmlString = @file_get_contents($this->_address.'?export=turbomarc&ean='.$ean);
			if ($xmlString === false)
				throw new Exception('Server not available', parent::ERR_NOTAVAILABLE);
			try {
				$xmlString = self::convertBid($xmlString);
				$collection = TurboMarc::createRecord($xmlString);
				if ($collection['code'] == 'KO')
					return false;
				$ret = array();
				foreach ($collection as $record)
					$ret[] = $record->asXML();
				return array('Count' => count($ret), 'Results' => $ret);
			} catch (Exception $e) {
				Prado::log($xmlString);
				throw new Exception("Bad response from server, please see logs.", parent::ERR_GENERIC);
			}
		}
		return false;
	}

	private function convertBid($xml) {
		$source = strtolower($this->_sourceName);
		$temp = <<<EOF
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
	<xsl:output indent="yes"/>
	<xsl:strip-space elements="*"/>

	<xsl:template match="@* | node()">
		<xsl:copy>
			<xsl:apply-templates select="@* | node()"/>
		</xsl:copy>
	</xsl:template>

	<xsl:template match="*[starts-with(local-name(),'s')]">
		<xsl:choose>
			<!-- convert clavis ids -->
			<xsl:when test="local-name()='s3'">
				<xsl:element name="s{$source}">
					<xsl:value-of select="."/>
				</xsl:element>
			</xsl:when>
			<xsl:otherwise>
				<xsl:copy>
					<xsl:apply-templates select="@* | node()"/>
				</xsl:copy>
			</xsl:otherwise>
		</xsl:choose>
	</xsl:template>

	<xsl:template match="*[starts-with(local-name(),'d')]">
		<xsl:copy>
			<xsl:apply-templates select="@* | node()"/>
		</xsl:copy>
	</xsl:template>

	<xsl:template match="r">
		<xsl:copy>
			<xsl:apply-templates select="@*"/>
			<xsl:apply-templates select="*">
				<xsl:sort select="local-name()"/>
			</xsl:apply-templates>
		</xsl:copy>
	</xsl:template>

</xsl:stylesheet>
EOF;
		$xsl = new DOMDocument;
		$xsl->loadXML($temp);
		$proc = new XSLTProcessor;
		$proc->importStyleSheet($xsl);
		if ($xml instanceof SimpleXMLElement) {
			$doc = dom_import_simplexml($xml)->ownerDocument;
		} else {
			$doc = new DOMDocument();
			$doc->loadXML($xml);
		}
		$sorted = $proc->transformToXML($doc);
		return $sorted;
	}
	
}
