<?php
/**
 * LeggereDriver class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info
 * @comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Modules.Import
 */

/**
 * LeggereDriver class
 * 
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Modules.Import
 * @since 2.5.0
 */
class LeggereDriver extends BaseImportDriver implements IImportDriver
{
	protected $_parameters = array(
		'user'		=> '',
		'password'	=> ''
	);
	
	public function getOptionalParameters()
	{
		return array(
			'user'		=> 'string',
			'password'	=> 'string'
		);
	}
	
	public function setAddress($value)
	{
		if (substr($value,0,7)!='http://')
			$value = 'http://'.$value;
		parent::setAddress($value);
	}
	
	public function search($queryParam)
	{
		$ean = null;
		foreach ($queryParam as $field => $param)
			if ($field == 'ean')
				$ean = $param;
		if ($ean != null) {
			// normalize EAN
			$ean = Clavis::normalizeStdNum($ean);
			if (strlen($ean) != 13)
				$ean = Clavis::IsbnToEan13($ean);
			// silence errors for temporary issues with Leggere
			$xmlString = @file_get_contents("{$this->_address}/esportazione_generica.php?login_username=".
				"{$this->_parameters['user']}&login_password={$this->_parameters['password']}&operation=Immagini_Ean2&ean=".
				$ean);
			if ($xmlString === false)
				throw new Exception('Server not available',parent::ERR_NOTAVAILABLE);

            $parse = $this->parseLeggere($xmlString);
            if($parse === false)
                return array('Count' => 0, 'Results' => array());
			$ret = array($parse->asXML());

			return array('Count' => count($ret), 'Results' => $ret);
		}
		return false;
	}
	
		
	protected function parseLeggere($xmlString)
	{
		try {
			$xml = new SimpleXMLElement($xmlString);
            if(isset($xml->CodiceEAN) && strlen((string)$xml->CodiceEAN) > 1) {
                $tm = TurboMarc::createRecord();
                $l = new TurboMarcLeader();
                $l->recstatus = 'n';
                $l->type = 'a';
                $l->biblevel = 'm';
                $l->hiercode = 0;
                $l->enclevel = 3;
                $l->descrForm = 'n';
                $tm->setLeader($l);
                $tm->setControlField('001', (string)$xml->CodiceEAN);
                $f073 = $tm->addField('073');
                $f073->addSubField('a', (string)$xml->CodiceEAN);
                $f073->addSubField('d', (string)$xml->Prezzo);
                $f100 = $tm->addField('100');
                $f100->setCDF('a', 8, 'd');
                if (trim($xml->DataPubblicazione)) {
                    $year = explode('-', (string)$xml->DataPubblicazione);
                    $year = $year[0];
                } else {
                    $year = '';
                }
                $f100->setCDF('a', 9, $year);
                $f101 = $tm->addField('101');
                $f101->addSubField('a', 'ita');
                $f102 = $tm->addField('102');
                $f102->addSubField('a', 'it');
                $f300 = $tm->addField('300');
                $f300->addSubField('a', str_replace("\n", " ", "Fa parte di: " . (string)$xml->FaParteDi . ". Tit. orig.: " . (string)$xml->TitoloOriginale));
                $f330 = $tm->addField('330');
                $f330->addSubField('a', str_replace("\n", " ", $xml->Testo));

                $tm->setTitle(trim($xml->FormulazioneDiResponsabilità) ?
                    (string)$xml->FormulazioneDiResponsabilità : (string)$xml->Titolo);
                $tm->setPublication($xml->Pubblicazione);
                $tm->setPhysicalDesc($xml->DescrizioneFisica);
                $tm->setEdition($xml->Edizione);
                $tm->setSerie($xml->CollanaBibliografica);

                // indexes
                $idx = 1;
                $baseUrl = $this->_address . '/esportazione_immagini.php?login_username=' .
                    $this->_parameters['user'] . '&login_password=' . $this->_parameters['password'] . '&operation=immagine&ID_Document=';
                foreach ($xml->Indice as $imgid) {
                    $f955 = $tm->addField('955');
                    $f955->addSubField('a', AttachmentPeer::TYPE_INDEX);
                    $f955->addSubField('b', 'image/jpg');
                    $f955->addSubField('d', $baseUrl . $imgid);
                    $f955->addSubField('e', "index$idx.jpg");
                    $f955->addSubField('l', "#{$idx}");
                    $f955->addSubField('n', 'Index');
                    ++$idx;
                }

                return $tm;
            } else {
                return false;
            }
		} catch (Exception $e) {
			throw $e;
			Prado::log('Eccezione import Leggere: '.$e->getMessage());
		}
	}
}
