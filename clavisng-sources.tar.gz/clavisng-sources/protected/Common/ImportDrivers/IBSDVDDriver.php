<?php
/**
 * IBSDriver class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info
 *
 * @comperio  .it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author    Mauro Seno <mauro.seno@comperio.it>
 * @link      http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license   http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version   2.7
 * @package   Modules.Import
 */

/**
 * IBSDVDDriver Class
 * Import data from IBS.
 *
 * @author  Mauro Seno <mauro.seno@comperio.it>
 * @version 2.9
 * @package Modules.Import
 * @since   2.5.0
 */
class IBSDVDDriver extends BaseImportDriver implements IImportDriver
{
	private const IBS_BASE_URL = 'https://www.ibs.it/';

	private const IBS_FAKE_EAN_DESCS = array(
		'idiota-libro-elif-batuman',
		'kafka-sulla-spiaggia-libro-haruki-murakami',
		'norwegian-wood-tokyo-blues-libro-haruki-murakami',
		'signore-degli-anelli-libro-john-r-r-tolkien',
		'love-supreme-cd-john-coltrane',
		'insostenibile-leggerezza-dell-essere-libro-milan-kundera',
		'immortalita-libro-milan-kundera',
		'the-game-libro-alessandro-baricco',
		'amica-geniale-vol-1-libro-elena-ferrante',
		'couldn-t-stand-weather-cd-stevie-ray-vaughan-double-trouble',
		'ballads-cd-dexter-gordon'
	);

	private $translation_table;
	private $current_ean;
	private $xpath;

	/**
	 * @param array $queryParam
	 *
	 * @return array
	 * @throws \RuntimeException
	 */
	public function search($queryParam): array
	{
		$ret = [];

		foreach ($queryParam as $field => $ean) {
			if ($field === 'ean') {
				$this->current_ean = $ean;
				parent::setAddress($this->buildFakeIBSURL($ean));

				$f = ClavisCurl::create(true, true, true)->get($this->_address);
				if ($f['code'] === 200) {
					$this->parseIBS($ean, $f['body']);
					$ret = array($this->getTurbomarc($ean));
				}
			}
		}
		return array('Count' => count($ret), 'Results' => $ret);
	}

	/**
	 * @param       $ean
	 *
	 * @return bool|mixed
	 */
	public function getTurbomarc($ean)
	{
		try {
			$tm = TurboMarc::createRecord();
			$tm->setControlField('001', $ean);

			foreach ($this->translation_table as $key => $value) {
				if ($value['field'] && $value['subfield']) {

					$customCallback = $value['callback'];
					$setFunction = 'set' . ucfirst($key);

					// Note to self.
					// Here we use method_exists and not is_callable because of the __call in the TComponent Parent class.
					// '__call' makes the is_callable function to return true for every non existent method.
					if (method_exists($this, $customCallback)) {
						// Have I set a custom callback function?
						$this->$customCallback($tm, $value);
					} else if (method_exists($this, $setFunction)) {
						// A method exists with the definition set{DescriptionOfTheCurrentBeingImportedField}fields
						$this->$setFunction($tm, $value);
					} else {
						// Ok let's use the generic one and put the current value into the
						// TurboMark fields specified inside the translation table.
						$this->setValue($tm, $value);
					}
				}
			}
			return $tm->asXML();
		} catch (Exception $e) {
			Prado::log('[ERROR]: IBS IMPORT' . $e->getMessage());
		}
		return false;
	}

	/**
	 * @param $ean
	 *
	 * @return string
	 */
	private function buildFakeIBSURL($ean): string
	{
		return self::IBS_BASE_URL . array_rand(array_flip(self::IBS_FAKE_EAN_DESCS), 1) . '/e/' . $ean . '/';
	}

	/**
	 * @param       $tm
	 * @param array $values
	 */
	private function setAnno(&$tm, array $values)
	{
		$value = $this->getNthValue($values);
		$anno = $value->wholeText;

		if ($anno) {
			$f = array_key_exists('d100', (array)$tm) ? $tm->d100 : $tm->addField('100');
			$f->setCDF('a', 8, 'd');
			$f->setCDF('a', 9, $anno);
		}
	}

	/**
	 * @return mixed
	 */
	private function getAnno()
	{
		$titleXPath = $this->translation_table['anno']['xpath'];
		$element = $this->xpath->query($titleXPath)[0]->wholeText;
		return $element;
	}

	/**
	 * @param TurboMarc $tm
	 * @param array     $values
	 */
	private function setProduzione(&$tm, array $values)
	{
		if (empty($this->getDistribuzione($tm, $values))) { // setto la produzione solo se non ho distribuzione.

			$value = $this->getNthValue($values);
			$produzione = $value->wholeText;

			if ($produzione) {
				list($paese, $anno) = $this->splitString($produzione, ',');

				if ($paese || $anno) {
					$f = array_key_exists('d210', (array)$tm) ? $tm->d210 : $tm->addField('210');
					$f->addSubField('a', '[S.l.]');

					if ($paese) {
						$f->addSubField('c', $paese);
					}
					if ($anno) {
						$f->addSubField('d', $anno);
					}
				}

				if ($paese) {
					$f300 = $tm->addField('300');
					$f300->addSubField('a', 'Produzione: ' . $paese);
				}
			}
		}
	}

	/**
	 * @param TurboMarc $tm
	 * @param array     $values
	 *
	 * @throws \Exception
	 */
	private function setDistribuzione(&$tm, $values)
	{
		$value = $this->getNthValue($values);
		$distribuzione = $value->wholeText;

		if ($distribuzione) {
			$annoDistribuzione = $this->getAnno();
			$f = array_key_exists('d210', (array)$tm) ? $tm->d210 : $tm->addField('210');
			$f->addSubField('a', '[S.l.]');
			$f->addSubField('c', $distribuzione);
			if (!empty($annoDistribuzione)) {
				$f->addSubField('d', $annoDistribuzione);
			}
		}
	}

	/**
	 * @param $tm
	 * @param $values
	 *
	 * @return mixed
	 */
	private function getDistribuzione(&$tm, $values)
	{
		$distribuzioneXPath = $this->translation_table['distribuzione']['xpath'];
		$element = $this->xpath->query($distribuzioneXPath)[0]->wholeText;
		return $element;
	}

	/**
	 * @param TurboMarc $tm
	 * @param array     $values
	 *
	 * @throws \Exception
	 */
	private function setEditore(&$tm, $values)
	{
		$value = $this->getNthValue($values);
		$editore = $value->wholeText;

		if ($editore) {
			$annoEdizione = $this->getAnno();
			$f = $tm->addField('210');
			$f->addSubField('a', '[S.l.]');
			$f->addSubField('c', $editore);
			$f->addSubField('d', $annoEdizione);

		}
	}


	/**
	 * @param $tm
	 * @param $values
	 */
	private function setPagine(&$tm, $values)
	{
		$value = $this->getNthValue($values);
		$pagine = $value->wholeText;

		if ($pagine) { // FROM 351p., ill., Rilegato TO  351p. : ill.
			if (strpos($pagine, ',') !== false) {
				$pagine = str_replace(' ', '', $pagine); // in order to avoid recursive replacing of str_ireplace with array as parameters.
				$pagine = str_ireplace(array('.,', 'rilegato', 'brossura'), array('. : ', '', ''), $pagine);
				$pagine = trim($pagine);
				$pagine = trim($pagine, ':');
			}

			if (!empty($pagine)) {
				$f = $tm->addField('215');
				$f->addSubField('a', $pagine);
			}
		}

		$hasNotes = explode(',', $value->wholeText);
		if (!empty($hasNotes[2])) {
			$f = $tm->addField('300');
			$f->addSubField('a', $hasNotes[2]);
		}
	}

	/**
	 * @param TurboMarc $tm
	 * @param array     $values
	 *
	 * @throws \Exception
	 */
	private function setAnnoProduzione(&$tm, $values)
	{
		$value = $this->getNthValue($values);
		$anno = $value->wholeText;

		if ($anno) {
			$f = array_key_exists('d100', (array)$tm) ? $tm->d100 : $tm->addField('100');
			$f->setCDF('a', 0, date('Ymd'));
			$f->setCDF('a', 8, 'i');
			$f->setCDF('a', 9, $anno);
		}
	}

	/**
	 * @param TurboMarc $tm
	 * @param array     $values
	 *
	 * @return bool
	 * @throws \Exception
	 */
	private function setDataPubblicazione(&$tm, $values)
	{
		// vedi setPubblicazione e setDistribuzione
		return true;
	}


	/**
	 * @return mixed
	 */
	private function getAuthor()
	{
		$titleXPath = $this->translation_table['author']['xpath'];
		$element = $this->xpath->query($titleXPath)[0]->wholeText;
		return $element;
	}


	/**
	 * @param TurboMarc $tm
	 * @param array     $values
	 *
	 * @throws \Exception
	 */
	private function setAuthor(&$tm, $values)
	{
		$value = $this->getNthValue($values);
		$author = $value->wholeText;

		if ($author) {
			$f = $tm->addField('200');
			$f->addSubField('f', 'autore: ' . $author);

			// forma inversa
			foreach ($this->splitString($author) as $a) {
				$f700 = $tm->addField('700');
				$f700->addSubField('a', $this->invertAuthor($a));
				$f700->addSubField('4', '070');
			}
		}
	}

	/**
	 * @return mixed
	 */
	private function getArtisti()
	{
		$xPath = $this->translation_table['artisti']['xpath'];
		$element = $this->xpath->query($xPath)[0]->wholeText;
		return $element;
	}

	/**
	 * @return mixed
	 */
	private function getRegia()
	{
		$xPath = $this->translation_table['regia']['xpath'];
		$element = $this->xpath->query($xPath)[0]->wholeText;
		return $element;
	}

	/**
	 * @return mixed
	 */
	private function getSupporto()
	{
		$xPath = $this->translation_table['supporto']['xpath'];
		$element = $this->xpath->query($xPath)[0]->wholeText;
		return $element;
	}


	private function getDataPubblicazione()
	{
		$xPath = $this->translation_table['dataPubblicazione']['xpath'];
		$element = $this->xpath->query($xPath)[0]->wholeText;
		return $element;
	}

	/**
	 * @param TurboMarc $tm
	 * @param array     $values
	 *
	 * @throws \Exception
	 */
	private function setRegia(&$tm, $values)
	{
		$value = $this->getNthValue($values);
		$registi = $value->wholeText;

		if ($registi) {

			$f = $tm->addField('200');
			$f->addSubField('f', 'regia: ' . $registi);

			// forma inversa
			foreach ($this->splitString($registi) as $regista) {
				$f700 = $tm->addField('700');
				$f700->addSubField('a', $this->invertAuthor($regista));
				$f700->addSubField('4', '300');
			}
		}
	}

	/**
	 * @param TurboMarc $tm
	 * @param array     $values
	 *
	 * @throws \Exception
	 */
	private function setInterpreti(&$tm, $values)
	{
		$interpreti = $this->implodeValues($values, ', ');

		if ($interpreti) {
			$f = $tm->addField('200');
			$f->addSubField('g', 'principali interpreti: ' . $interpreti);

			foreach ($this->splitString($interpreti) as $i) {
				$f702 = $tm->addField('702');
				$f702->addSubField('a', $this->invertAuthor($i));
				$f702->addSubField('4', '005');
			}
		}
	}

	/**
	 * @param TurboMarc $tm
	 * @param array     $values
	 *
	 * @throws \Exception
	 */
	private function setLingua(&$tm, $values)
	{
		$value = $this->getNthValue($values);
		$lingue = $value->wholeText;

		if ($lingue) {
			$langMap = array('italiano' => 'ita', 'inglese' => 'eng', 'tedesco' => 'ger', 'francese' => 'fra', 'spagnolo' => 'spa');

			$f300 = $tm->addField('300');
			$f300->addSubField('a', 'Lingue: ' . $lingue);

			foreach ($this->splitString($lingue) as $i) {
				$f101 = $tm->addField('101');
				$f101->addSubField('a', $langMap[$i]);
			}
		}
	}

	/**
	 * @param TurboMarc $tm
	 * @param array     $values
	 *
	 * @throws \Exception
	 */
	private function setSottotitoli(&$tm, $values)
	{
		$value = $this->getNthValue($values);
		$sottotitoli = $value->wholeText;

		if ($sottotitoli) {
			$f300 = $tm->addField('300');
			$f300->addSubField('a', 'Sottotitoli: ' . $sottotitoli);
		}
	}

	/**
	 * @param TurboMarc $tm
	 * @param array     $values
	 *
	 * @return bool
	 * @throws \Exception
	 */
	private function setSupporto(&$tm, $values)
	{
		if ($this->isFilm()) {
			// vedi setDurata.
		} else if ($this->isAudiobook()) {
			$f215 = $tm->addField('215');
			$f215->addSubField('a', 'Audiolibro');
			// setto anche il campo codificato 125 come "Genere testuale: audiolibro"
			$f = array_key_exists('d125', (array)$tm) ? $tm->d125 : $tm->addField('125');
			$f->setCDF('b', 0, 'c');
		} else if (!empty($this->getSupporto())) {
			$f215 = $tm->addField('215');
			$f215->addSubField('a', $this->getSupporto());
		}
		return true;
	}


	/**
	 * @param TurboMarc $tm
	 * @param array     $values
	 *
	 * @throws \Exception
	 */
	private function setContenuti(&$tm, $values)
	{
		$value = $this->getNthValue($values);
		$contentuti = $value->wholeText;

		if ($contentuti) {
			$f327 = $tm->addField('327');
			$f327->addSubField('a', 'Contenuti: ' . $contentuti);
		}
	}

	/**
	 * @param TurboMarc $tm
	 * @param array     $values
	 *
	 * @throws \Exception
	 */
	private function setRating(&$tm, $values)
	{
		$value = $this->getNthValue($values);
		$vietato = $value->wholeText;
		$age = (int)filter_var($vietato, FILTER_SANITIZE_NUMBER_INT);
		if ($age > 10) {
			$f = array_key_exists('d901', (array)$tm) ? $tm->d901 : $tm->addField('901');
			$f->addSubField('g', $age);
		}
	}

	/**
	 * @param TurboMarc $tm
	 * @param array     $values
	 *
	 * @throws \Exception
	 */
	private function setDurata(&$tm, $values)
	{
		$value = $this->getNthValue($values);
		$durata = $value->wholeText;

		if (!empty($durata)) {
			$f215 = $tm->addField('215');
			$f215->addSubField('a', $this->getSupporto() . ' (' . $durata . ')');
		}
	}

	/**
	 * @param TurboMarc $tm
	 * @param array     $values
	 *
	 * @throws \Exception
	 */
	private function setGenere(&$tm, $values)
	{
		$genere = $this->implodeValues($values, ', ');
		if ($genere) {
			$f300 = $tm->addField('300');
			$f300->addSubField('a', 'Genere: ' . trim($genere));
		}
	}

	/**
	 * @param TurboMarc $tm
	 * @param array     $values
	 *
	 * @throws \Exception
	 */
	private function setTraduttore(&$tm, $values)
	{
		$traduttori = $this->implodeValues($values, ', ');
		if ($traduttori) {
			$f300 = $tm->addField('300');
			$f300->addSubField('a', 'Traduttore: ' . trim($traduttori));
		}
	}

	/**
	 * @param TurboMarc $tm
	 * @param array     $values
	 *
	 * @throws \Exception
	 */
	private function setEtichetta(&$tm, $values)
	{
		$etichetta = $this->implodeValues($values, ', ');
		if ($etichetta) {
			$dataPubblicazione = $this->getDataPubblicazione();
			$dataPubblicazione = empty($dataPubblicazione) ? '' : ', ' . $dataPubblicazione;
			$value = trim($etichetta) . $dataPubblicazione;

			$f = $tm->addField('210');
			$f->addSubField('a', '[S.l.]');
			$f->addSubField('c', $value);
		}
	}

	/**
	 * @param TurboMarc $tm
	 * @param array     $values
	 *
	 * @throws \Exception
	 */
	private function setEta(&$tm, $values)
	{
		$eta = $this->implodeValues($values, ', ');
		if ($eta) {
			$f = array_key_exists('d100', (array)$tm) ? $tm->d100 : $tm->addField('100');
			$f->setCDF('a', 17, $this->etaLetturaToTurbomarcField($eta));
		}
	}

	/**
	 * @param TurboMarc $tm
	 * @param array     $values
	 *
	 * @throws \Exception
	 */
	private function setIllustratore(&$tm, $values)
	{
		$illustratori = $this->implodeValues($values, ', ');
		if ($illustratori) {
			$f300 = $tm->addField('300');
			$f300->addSubField('a', 'Illustratore: ' . trim($illustratori));
		}
	}

	/**
	 * @param TurboMarc $tm
	 * @param array     $values
	 *
	 * @throws \Exception
	 */
	private function setAbstract(&$tm, $values)
	{
		$abstract = $this->implodeValues($values, ' ');
		if ($abstract) {
			$f330 = $tm->addField('330');
			$f330->addSubField('a', 'Abstract: ' . trim($abstract));
		}
	}

	/**
	 * @param TurboMarc $tm
	 * @param array     $values
	 *
	 * @throws \Exception
	 */
	private function setEAN(&$tm, $values)
	{
		$value = $this->getNthValue($values, 1);

		// not UTF-8 safe.
		$node_content = preg_replace('/\s+/', '', $value->wholeText);

		if ($value) {
			$f = $tm->addField('073');
			$f->addSubField('a', $node_content);
		}
	}

	/**
	 * @param $tm
	 * @param $values
	 */
	private function setTitle(&$tm, $values)
	{
		$value = $this->getNthValue($values);
		$title = preg_replace('/\s+/', ' ', $value->wholeText);
		$title = preg_replace('/[\.]/', ' : ', $title);
		$title = preg_replace("/[^\s+\pL+._\-:']/u", '', $title);

		if ($this->isFilm()) {
			$title = preg_replace('/\(DVD\)/', '', $title);
			$title = preg_replace('/\(Blu-ray\)/', '', $title);
		}

		if ($title) {
			$f = $tm->addField('200');
			$f->addSubField('a', $title . $this->getTitleAppendix());
		}
	}

	/**
	 * @return string
	 */
	private function getTitleAppendix(): string
	{
		$a = '';
		if ($this->isBook()) {
			$a = $this->getAuthor();
		}

		if ($this->isMusic()) {
			$a = $this->getArtisti();
		}

		if ($this->isFilm()) {
			$a = 'regia di: ' . $this->getRegia();
		}
		return $a ? ' / ' . $a : '';
	}

	/**
	 * @param        $values
	 * @param string $separator
	 *
	 * @return string
	 */
	private function implodeValues($values, $separator = ' '): string
	{
		$count = $values['values']->length;
		$string = '';

		for ($i = 0; $i < $count; $i++) {
			$value = $values['values']->item($i);
			if ($value->wholeText !== '') {
				$string .= $value->wholeText . $separator;
			}
		}
		return trim($string, $separator);
	}

	/**
	 * @param TurboMarc $tm
	 * @param array     $values
	 */
	private function setValue(&$tm, $values)
	{
		$value = $this->getNthValue($values);
		$field = $values['field'];
		$subField = $values['subfield'];

		// not UTF-8 safe.
		$node_content = preg_replace('/\s+/', ' ', $value->wholeText);

		if (!empty($node_content) && $field && $subField) {
			$f = $tm->addField($field);
			$f->addSubField($subField, $node_content);
		}
	}

	/**
	 * @return array
	 */
	private function IBStoTurbomarcTranslationTable(): array
	{
		$table = [];

		// and not(//h1[@class='title__text']/text())
		// -- BOOKS ----------------------------------------------------------------------------------------------------
		$this->addToTable($table, 'title', "//h1[@class='title__text']/text() | //div[@id='title']/h1/text()", 200, 'a');
		$this->addToTable($table, 'author', "//h2[@class='author__title']/a/text()", 200, 'f');
		$this->addToTable($table, 'editore', "//section[@class='product-details']/div[b[text()='Editore:']]/span/a/text()", 210, 'c');
		$this->addToTable($table, 'collana', "//section[@class='product-details']/div[b[text()='Collana:']]/span/a/text()", 225, 'a');
		$this->addToTable($table, 'pagine', "//section[@class='product-details']/div[b[text()='Pagine:']]/span/a/text()", 215, 'a');
		$this->addToTable($table, 'ean', "//ul[@class='product-details__standard-list']/li[strong[text()='EAN:']]/text()", 073, 'a');
		$this->addToTable($table, 'abstract', "//div[@id='nuovo-abstract']//text()", 330, 'a');
		$this->addToTable($table, 'genere', "(//a[@class='breadcrumbs__item-link'])[last()]/text()", 300, 'a');
		$this->addToTable($table, 'anno', "//section[@class='product-details']/div[b[starts-with(text(),'Anno')]]/span/text()", 100, 'a');
		$this->addToTable($table, 'illustratore', "//section[@class='product-details']/div[b[text()='Illustratore:']]/span/a/text()", 300, 'a');
		$this->addToTable($table, 'traduttore', "//section[@class='product-details']/div[b[text()='Traduttore:']]/span/a/text()", 300, 'a');
		$this->addToTable($table, 'eta', "//section[@class='product-details__secondary-info']/div[b[text()='Età di lettura:']]/span/a/text()", 2013, 'b,c,d');

		// -- FILMS ----------------------------------------------------------------------------------------------------
		$this->addToTable($table, 'originalTitle', "//h2[@class='original-title']/text()", 509, 'a');
		$this->addToTable($table, 'regia', "//div[@id='info']/div[b[text()='Regia:']]/span/a/text()", 200, 'f');
		$this->addToTable($table, 'interpreti', "//div[@id='info']/div[b[text()='Interpreti:']]/span/a/text()", 323, 'a');
		$this->addToTable($table, 'annoProduzione', "//div[@id='info']/div[b[text()='Anno:']]/span/text()", '210', 'c');
		$this->addToTable($table, 'supporto', "//div[@id='info']/div[b[text()='Supporto:']]/span/text()", 215, 'a');
		$this->addToTable($table, 'produzione', "//ul[@class='details-list']/li[b[text()='Produzione:']]/span/text()", 210, 'c,d');
		$this->addToTable($table, 'distribuzione', "//ul[@class='details-list']/li[b[text()='Distribuzione:']]/span/text()", 215, 'c,cdf');
		$this->addToTable($table, 'durata', "//ul[@class='details-list']/li[b[text()='Durata:']]/span/text()", 215, 'c,cdf');
		$this->addToTable($table, 'lingua', "//ul[@class='details-list']/li[b[text()='Lingua audio:']]/span/text()", 300, 'a');
		$this->addToTable($table, 'sottotitoli', "//ul[@class='details-list']/li[b[text()='Lingua sottotitoli:']]/span/text()", 300, 'a');
		$this->addToTable($table, 'contenuti', "//ul[@class='details-list']/li[b[text()='Contenuti:']]/span/text()", 327, 'a');
		$this->addToTable($table, 'rating', "//div[@id='info']/div/span/strong[starts-with(text(),'Vietato ai')]/text()", '901', 'a,b,c');

		// -- CD VINILI ----------------------------------------------------------------------------------------------------
		$this->addToTable($table, 'artisti', "//div[@id='info']/div[b[text()='Artisti:']]/span/a/text()", 200, 'f', 'setAuthor');
		$this->addToTable($table, 'numero-dischi', "//div[@id='info']/div[b[text()='Numero dischi:']]/span/text()", '', '');
		$this->addToTable($table, 'etichetta', "//div[@id='info']/div[b[text()='Etichetta:']]/span/a/text()", 210, 'c');
		$this->addToTable($table, 'dataPubblicazione', "//div[@id='info']/div[b[text()='Data di pubblicazione:']]/span/text()", 210, 'd');

		// //div[@id='product-img-ctn']
		$this->addToTable($table, 'cover', "//section[@data-zone='External Data']//a[contains(@class, 'fancybox img-zoom') and contains(@tabindex,'0') or not(@tabindex)]/@href", 955, 'abcd');

		// -- AUDIOLIBRI ----------------------------------------------------------------------------------------------------
		// gia' presenti tutti nei campi fino a qui processati.

		$this->addToTable($table, 'biblevel', "", 901, 'abcd', 'setBiblevel');


		return $table;
	}

	/**
	 * @param      $table
	 * @param      $description
	 * @param      $xpath
	 * @param      $turbo_field
	 * @param      $turbo_subField
	 * @param null $callback
	 */
	private function addToTable(&$table, $description, $xpath, $turbo_field, $turbo_subField, $callback = null)
	{
		$table[$description] = [
			'xpath' => $xpath,
			'field' => $turbo_field,
			'subfield' => $turbo_subField,
			'callback' => $callback
		];
	}

	/**
	 * @param $ean
	 * @param $html
	 *
	 * @return void
	 */
	private function parseIBS($ean, $html)
	{
		if (!$html) {
			throw new RuntimeException('Server not available', parent::ERR_NOTAVAILABLE);
		}

		$dom = new DOMDocument();
		@$dom->loadHTML($html);
		$this->xpath = new DOMXpath($dom);

		// tre macro generi per individuare l'autore o il regista da mettere dopo lo / del titolo della notizia.
		// film
		// cd
		//libri
		foreach ($this->translation_table = $this->IBStoTurbomarcTranslationTable() as $key => $value) {
			if (($domNodeList = $this->xpath->query($value['xpath'])) !== false) {
				$this->translation_table[$key]['values'] = $domNodeList;
			} else {
				Prado::log("[WARNING]: IBS IMPORT XPath not found: {$value['xpath']} on page {$this->_address}");
			}
		}
	}

	/**
	 * @param $age
	 *
	 * @return string
	 */
	private function etaLetturaToTurbomarcField($age): string
	{
		$reparti = [
			'0' => 'b',
			'1' => 'b',
			'2' => 'b',
			'3' => 'b',
			'4' => 'b',
			'5' => 'b',
			'6' => 'c',
			'7' => 'c',
			'8' => 'c',
			'9' => 'c',
			'10' => 'd',
			'11' => 'd',
			'12' => 'd',
			'13' => 'd'
		];

		$age = (string)filter_var($age, FILTER_SANITIZE_NUMBER_INT);
		return array_key_exists($age, $reparti) ? $reparti[$age] : 'u'; // u === sconosciuto
	}

	/**
	 * @return string
	 */
	private function getImportType(): string
	{
		// ie: Libro : Audiolibro
		$type = $this->xpath->query("//ul[@class='levels']/li/a/text()")[0]->wholeText;
		return strtolower($type);
	}

	/**
	 * @return string
	 */
	private function getImportSubType(): string
	{
		$subtype = $this->xpath->query("//div[@id='info']/div[b[text()='Pagine:']]/span/text()")[0]->wholeText;
		return strtolower($subtype);
	}

	/**
	 * @return string
	 */
	private function getImportCateg(): string
	{
		return strtolower($this->getImportType() . ' : ' . $this->getImportSubType());
	}

	/**
	 * @return bool
	 */
	private function isBook(): bool
	{
		return strpos('libri,libro,ebook,e book,ebook in inglese,libri in inglese,libri vintage', $this->getImportType()) !== false;
	}

	/**
	 * @return bool
	 */
	private function isAudiobook(): bool
	{
		return strpos('audiolibro', $this->getImportSubType()) === 0;
	}

	/**
	 * @return bool
	 */
	private function isEBook(): bool
	{
		return strpos('ebook,e book,ebook in inglese', $this->getImportType()) !== false;
	}

	/**
	 * @return bool
	 */
	private function isMusic(): bool
	{
		return strpos('cd musicali,vinili', $this->getImportType()) !== false;
	}

	/**
	 * @return bool
	 */
	private function isFilm(): bool
	{
		return strpos('film,dvd,blu-ray', $this->getImportType()) !== false;
	}

	/**
	 * @param $tm
	 * @param $values
	 */
	private function setBibLevel(&$tm, $values)
	{
		$cSubField = '1'; // default su materiale a stampa
		$aSubField = 'a01'; // materiale linguistico moderno
		$leader = 'a';

		if ($this->isEBook()) {
			$aSubField = 'l01';
			$cSubField = '7';
			$leader = 'l';
		}
		if ($this->isMusic()) {
			$supporto = $this->getSupporto();
			$cSubField = '4';
			$aSubField = (stripos($supporto, 'vinile') === false) ? 'j02' : 'j01'; //j01 se vinile
			$leader = 'j';
		}
		if ($this->isFilm()) {
			$cSubField = '3';
			$aSubField = 'g03';
			$leader = 'g';
		}
		if ($this->isAudiobook()) {
			$cSubField = '5'; //registrazioni sonore non musicali
			$aSubField = 'i02';
			$leader = 'i';
		}

		$l = new TurboMarcLeader;
		$l->biblevel = 'm';
		$l->type = $leader;
		$tm->setLeader($l);

		$f901 = array_key_exists('d901', (array)$tm) ? $tm->d901 : $tm->addField('901');
		$f901->addSubField('a', $aSubField);
		$f901->addSubField('b', 'm');
		$f901->addSubField('c', $cSubField);
	}

	/**
	 * @param $tm
	 * @param $values
	 *
	 * @return array|bool
	 */
	private function setCover(&$tm, $values)
	{
		$value = $this->getNthValue($values);
		$cover_link = $value->nodeValue;
		return $this->downloadCoverFromIBS($this->current_ean, $cover_link);
	}

	/**
	 * @param     $values
	 *
	 * @param int $index
	 *
	 * @return mixed
	 */
	private function getNthValue($values, $index = 0)
	{
		if (array_key_exists('values', $values) && $values['values'] instanceof DOMNodeList) {
			return $values['values']->item($index);
		}
		return '';
	}

	/**
	 * Download the cover from IBS if not present in the cover server.
	 *
	 * @param $ean
	 * @param $cover_link
	 *
	 * @return array|bool
	 */
	private function downloadCoverFromIBS($ean, $cover_link)
	{
		if (!ClavisCovers::hasCover($ean)) {
			$cover_img = file_get_contents($cover_link);
			$upload_ok = ClavisCovers::uploadNewItem($ean, 'C', 'IBS', $cover_img);
			if (!$upload_ok) {
				Prado::log("[WARNING]: Cover upload for ean {$ean} on page {$this->_address} failed.");
			}
			return $upload_ok;
		}
		return true;
	}

	/**
	 * Invert author text exchanging name and lastname
	 * (e.g. Monica Bellucci => Bellucci, Monica)
	 *
	 * @param string $author *
	 *
	 * @return string
	 */
	private function invertAuthor(string $author): string
	{
		$wordList = $this->splitString($author, ' ', 2);
		return implode(', ', array_reverse($wordList));
	}

	/*
	 * @param     $string
	 * @param     $delimiter
	 * @param int $limit
	 *
	 * @return array
	 */
	private function splitString(string $string, string $delimiter = ',', int $limit = null): array
	{
		$words = explode($delimiter, $string, $limit);
		return array_map('trim', $words);
	}
}