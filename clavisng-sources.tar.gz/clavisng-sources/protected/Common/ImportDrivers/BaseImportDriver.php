<?php
/**
 * BaseImportDriver class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info
 * @comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Modules.Import
 */

/**
 * BaseImportDriver class
 * 
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Modules.Import
 * @since 2.5.0
 */
abstract class BaseImportDriver extends TTemplateControl
{
	const ERR_GENERIC = 1;
	const ERR_NOTAVAILABLE = 2;
	
	protected $_sourceId = '';
	protected $_sourceName = '';
	protected $_address = '';
	protected $_timeout = 30;
	protected $_encoding = 'utf8';
	protected $_searchFields = array('title','author','ean','date','publisher');
	protected $_syntax = 'UNIMARC';
	protected $_format = '';
	protected $_turbomarc_conversion = array();
	protected $_max_results = 50;
	protected $_parameters = array();
	
	/**
	 * Returns the optional parameters supported by driver.
	 * This method should be overriden by child classes that supports optional parameters.
	 * 
	 * @return array 
	 */
	public function getOptionalParameters()
	{
		return array();
	}
	
	/**
	 * Returns the source id.
	 * 
	 * @return string The source id.
	 */
	public function getSourceId() {
		return $this->_sourceId;
	}
	
	/**
	 * Sets the source id.
	 *
	 * @param string $value The source id
	 */
	public function setSourceId($value) {
		$this->_sourceId = $value;
	}

	/**
	 * Returns the source id.
	 *
	 * @return string The source id.
	 */
	public function getSourceName() {
		return $this->_sourceName;
	}

	/**
	 * Sets the source id.
	 *
	 * @param string $value The source id
	 */
	public function setSourceName($value) {
		$this->_sourceName = $value;
	}

	/**
	 * Returns the configured address.
	 * 
	 * @return string The configured address.
	 */
	public function getAddress() {
		return $this->_address;
	}
	
	/**
	 * Sets the address (URL) to use by the driver.
	 *
	 * @param string $value The new address
	 */
	public function setAddress($value) {
		$this->_address = $value;
	}
	
	/**
	 * Returns the configured timeout.
	 * 
	 * @return int The configured timeout.
	 */
	public function getTimeout() {
		return $this->_timeout;
	}
	
	/**
	 * Sets the connection timeout.
	 *
	 * @param int $value The timeout (in seconds, defaults to 30)
	 */
	public function setTimeout($value) {
		$this->_timeout = $value;
	}
	
	/**
	 * Returns the encoding used by the source.
	 * 
	 * @return string The encoding.
	 */
	public function getEncoding() {
		return $this->_encoding;
	}
	
	/**
	 * Sets the encoding to use by the driver.
	 *
	 * @param string $value The encoding.
	 */
	public function setEncoding($value) {
		$this->_encoding = $value;
	}
	
	/**
	 * Returns the supported search fields.
	 * 
	 * @return array The supported search fields.
	 */
	public function getSearchFields() {
		return $this->_searchFields;
	}
	
	/**
	 * Sets the supported search fields.
	 *
	 * @param array $value The supported search fields.
	 */
	public function setSearchFields(Array $value) {
		$this->_searchFields = $value;
	}
	
	/**
	 * Returns the syntax used by the driver.
	 * 
	 * @return string The syntax used by the driver.
	 */
	public function getSyntax() {
		return $this->_syntax;
	}
	
	/**
	 * Sets the syntax to use by the driver.
	 *
	 * @param string $value The syntax 
	 */
	public function setSyntax($value) {
		$this->_syntax = $value;
	}
	
	/**
	 * Returns the format used by the driver.
	 * 
	 * @return string The format used by the driver.
	 */
	public function getFormat() {
		return $this->_format;
	}
	
	/**
	 * Sets the format to use by the driver.
	 *
	 * @param string $value The format
	 */
	public function setFormat($value) {
		$this->_format = $value;
	}
	
	/**
	 * Returns the turbomarc conversions to be applied by the driver.
	 * 
	 * @return array The turbomarc conversions to be applied by the driver
	 */
	public function getTurbomarcConversion() {
		return $this->_turbomarc_conversion;
	}
	
	/**
	 * Sets the turbomarc conversions to be applied by the driver.
	 *
	 * @param array $value The turbomarc conversions
	 */
	public function setTurbomarcConversion($value) {
		$this->_turbomarc_conversion = $value;
	}
	
	/**
	 * Returns the mmaximum results returned by search.
	 * 
	 * @return int The maximum number of results.
	 */
	public function getMaxResults() {
		return $this->_max_results;
	}
	
	/**
	 * Sets the maximum of results returned by search.
	 *
	 * @param int $value Maximum result number
	 */
	public function setMaxResults($value) {
		$this->_max_results = $value;
	}
	
	/**
	 * Sets the optional parameters for the driver.
	 *
	 * @param array $value The optional parameters
	 */
	public function setParameters($params = array())
	{
		// load parameters with a foreach() to ensure we only set
		// valid parameters.
		foreach ($this->_parameters as $k => $v)
			if (array_key_exists($k, $params))
				$this->_parameters[$k] = $params[$k];
	}
	
	/**
	 * Returns the optional parameters set for the driver.
	 * 
	 * @return array The optional parameters set for the driver.
	 */
	public function getParameters()
	{
		return $this->_parameters;
	}

	/**
	 * Returns the full turbomarc for the specified record.
	 *
	 * @param string $turbomarc
	 * @return string The full turbomarc for the record.
	 */
	public function getFullTurbomarcRecord($turbomarc)
	{
		return $turbomarc;
	}
	
	protected function applyRecordConversions(TurboMarc $record)
	{
		if (!class_exists('TurbomarcConversion', true))
			throw new Exception('Could not load TurbomarcConversion class.');
		
		foreach ($this->_turbomarc_conversion as $function) {
			if (method_exists('TurbomarcConversion', $function))
				$record = TurbomarcConversion::$function($record);
		}
		return $record;
	}
}
