<?php
/**
 * PushBot module class.
 *
 * A module for sending notification trough the PushBot API.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author    Mauro Seno <mauro.seno@comperio.it>
 * @link      http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license   http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 */

use Pushbots\PushbotsClient;

class PushBotModule extends TModule
{

    /** @var string $ApiKey from clavis-application.xml */
    private $AppID;

    /** @var string $BaseUrl from clavis-application.xml */
    private $AppSecret;

    /**
     * @return string
     */
    public function getAppID()
    {
        return $this->AppID;
    }

    /**
     * @param string $AppID
     */
    public function setAppID($AppID)
    {
        $this->AppID = $AppID;
    }

    /**
     * @return string
     */
    public function getAppSecret()
    {
        return $this->AppSecret;
    }

    /**
     * @param string $AppSecret
     */
    public function setAppSecret($AppSecret)
    {
        $this->AppSecret = $AppSecret;
    }

    /**
     * @param $opac_user_id
     * @param $message
     * @return mixed
     * @throws \GuzzleHttp\Exception\GuzzleException
     */
    public function send($opac_user_id, $message)
    {
        $client = new PushbotsClient($this->getAppID(), $this->getAppSecret());
        return $client->campaign->alias($opac_user_id, $message);
    }


    /**
     * @param string $message
     * @param array  $platform
     * @param string $badge
     * @param array  $payload
     * @return mixed
     * @throws \GuzzleHttp\Exception\GuzzleException
     */
    public function sendAll(
        string $message,
        array $platform = [0, 1, 2, 3, 4],
        string $badge = '+1',
        array $payload = []
    )
    {
        $client = new PushbotsClient($this->getAppID(), $this->getAppSecret());
        //Sample sending campaign to all users
        $r= $client->campaign->send(
            [
                //Platforms
                //0 => iOS
                //1 => Android
                //2 => Chrome
                //3 => Firefox
                //4 => Safari
                'platform' => $platform,
                //Message
                'msg' => $message,
                //Badge [iOS only]
                'badge' => $badge,

                //Notification payload
                'payload' => $payload
            ]);
        return $r;
    }
}