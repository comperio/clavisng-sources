<?php
/**
 * SolrSearch class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Modules.Search
 */
Prado::using('TurboMarc2Solr');

/**
 * SolrSearch Class
 *
 * Provides methods for interacting with a Solr server.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Modules.Search
 * @since 2.5.0
 */
class SolrSearch extends TModule implements ISearchModule {

	/**
	 * Servlet mappings
	 */
	const PING_SERVLET		= '/admin/ping/';
	const UPDATE_SERVLET	= '/update/';
	const SEARCH_SERVLET	= '/select/';
	const TERM_SERVLET		= '/terms/';
	const THREADS_SERVLET	= '/admin/threads/';

	const WT = 'phps';

	private $_sortRules = array(
		'score'		=> '',
		'titleasc'	=> 'sorts_title asc,sorts_author asc,sorti_date asc',
		'titledesc'	=> 'sorts_title desc,sorts_author desc,sorti_date desc',
		'authasc'	=> 'sorts_author asc,sorts_title asc,sorti_date asc',
		'authdesc'	=> 'sorts_author desc,sorts_title desc,sorti_date desc',
		'dateasc'	=> 'sorti_date asc,sorts_lastinvdate asc,sorts_author asc,sorts_title asc',
		'datedesc'	=> 'sorti_date desc,sorts_lastinvdate desc,sorts_author desc,sorts_title desc',
		'classasc'	=> 'sorts_class asc',
		'classdesc'	=> 'sorts_class desc',
        'authtextasc'	=> 'sorts_fulltext asc',
        'authtextdesc'	=> 'sorts_fulltext desc',
        'authtypeasc'	=> 'sorts_type asc,sorts_fulltext asc',
        'authtypedesc'	=> 'sorts_type desc,sorts_fulltext desc',
		'authdatecreateddesc' => 'sorts_created desc',
        'loansdesc' => 'sorti_onloan desc',
        'requestsdesc' => 'sorti_requests desc'
        );
	
	private $_authoritySortRules = array(
		'score'		=> '',
		'textasc'	=> 'sorts_fulltext asc',
		'textdesc'	=> 'sorts_fulltext desc',
		'typeasc'	=> 'facets_authrectype asc',
		'typedesc'	=> 'facets_authrectype desc',);
	private $_dbname;
	private $_recordCollection = 'catalog';
	private $_extraCollection = 'extra';
	private $_authorityCollection = 'authority';
	private $_serverUrl;
	private $_realtimeIndexing = false;

	public function setServerURL($value) {
		$this->_serverUrl = $value;
	}
	public function getServerURL() {
		return $this->_serverUrl;
	}

	public function setDatabaseName($value) {
		$this->_dbname = $value;
	}
	public function getDatabaseName() {
		return $this->_dbname;
	}
	public function setRecordCollection($value) {
		$this->_recordCollection = $value;
	}
	public function getRecordCollection() {
		return $this->_recordCollection;
	}
	public function setExtraCollection($value) {
		$this->_extraCollection = $value;
	}
	public function getExtraCollection() {
		return $this->_extraCollection;
	}
	public function setAuthorityCollection($value) {
		$this->_authorityCollection = $value;
	}
	public function getAuthorityCollection() {
		return $this->_authorityCollection;
	}

	public function setRealtimeIndexing($value) {
		$this->_realtimeIndexing = $value;
	}

	public function getRealtimeIndexing() {
		return $this->_realtimeIndexing;
	}

	public static function escapeString($str)
    {
        $es = ['\\',' ','+','-','&&', '||', '!', '(', ')', '{', '}', '[', ']', '^', '"', '~', '*', '?', ':', '/'];
        $er = ['\\\\','\\ ','\\+','\\-','\\&&', '\\||', '\\!', '\\(', '\\)', '\\{', '\\}', '\\[', '\\]', '\\^', '\\"', '\\~', '\\*', '\\?', '\\:', '\\/'];

        return str_replace($es,$er,$str);
    }

    public function search($query, $start=0, $rows=5000, $sort='', $params=array())
	{
    	$query = ($this->_recordCollection && $this->_dbname) ?
			preg_replace('!(^|[^\w])id:([\("]?)([^\s\)"]+)([\)"]?)!', "$1id:$2{$this->_dbname}\:{$this->_recordCollection}\:$3$4", $query) :
			$query;
		if ($this->_recordCollection)
			$query .= " +collection:{$this->_recordCollection}";
		return $this->_searchInternal($query, $start, $rows, $sort, $params);
	}

	public function searchExtra($query, $start=0, $rows=5000, $sort='', $params=array()) {
		$query = preg_replace('!(^|[^\w])id:([\("]?)([^\s\)"]+)([\)"]?)!', "$1id:$2{$this->_dbname}\\:{$this->_extraCollection}\\:$3$4", $query);
		$query .= " +collection:{$this->_extraCollection}";
		return $this->_searchInternal($query, $start, $rows, $sort, $params);
	}

	public function searchAuthority($query, $start=0, $rows=5000, $sort='', $params=array()) {
		$query = preg_replace('!(^|[^\w])id:([\("]?)([^\s\)"]+)([\)"]?)!', "$1id:$2{$this->_dbname}\\:{$this->_authorityCollection}\\:$3$4", $query);
		$query .= " +collection:{$this->_authorityCollection}";
		return $this->_searchInternal($query, $start, $rows, $sort, $params);
	}

	protected function _searchInternal($query, $start=0, $rows=5000, $sort='', $params=array())
	{
		$params['q'] = $query;
		if ($sort != '' && array_key_exists($sort,$this->_sortRules) && trim($this->_sortRules[$sort]))
			$params['sort'] = $this->_sortRules[$sort];
		$params['wt'] = self::WT;
		if ($start)
			$params['start'] = $start;
		if ($rows)
			$params['rows'] = $rows;
		$queryString = http_build_query($params);
		$queryString = preg_replace('/%5B(?:[0-9]|[1-9][0-9]+)%5D=/', '=', $queryString);
		$data = $this->doSelect($queryString);
		if ($data) {
			$data = unserialize($data);
			foreach ($data['response']['docs'] as $key => $result) {
				list(
					$data['response']['docs'][$key]['Database'],
					$data['response']['docs'][$key]['Collection'],
					$myid) = explode(':', $result['id']);
				$data['response']['docs'][$key]['FullId'] = $result['id'];
				unset($result['id']);
				$data['response']['docs'][$key]['Id'] = $myid;
				if (array_key_exists('turbo_marc',$result))
					$data['response']['docs'][$key]['Turbomarc'] = $result['turbo_marc'];
			}
			return $data;
		}
		return null;
	}

	/**
	 *
	 * @param array $objects
	 * @return boolean
	 * @throws Exception
	 */
	public function index(array $objects, $optimize=false, $saveToFile=false)
	{
		$doc = '';
		foreach ($objects as $id => $tm)
			try {
				$doc .= TurboMarc2Solr::getSolrDoc($tm, $id, $this->_dbname, $this->_recordCollection);
			} catch (Exception $e) {
				Prado::log("ERROR ON RECORD {$id}, XML {$tm} - message {$e->__toString()}\n",
					TLogger::WARNING,'Console');
				echo "ERROR ON RECORD {$id}, XML {$tm} - message {$e->__toString()}\n";
			}
		if ($doc) {
			if ($saveToFile) {
				$filename = tempnam('/tmp/','sol');
				file_put_contents($filename, "<add>{$doc}</add>", FILE_APPEND);
			} else {
				$this->sendUpdate("<add>{$doc}</add>");
				$this->sendCommit();
				if ($optimize)
					$this->sendOptimize();
			}
		}
		return true;
	}

	/**
	 *
	 * @param array $objects
	 * @return boolean
	 * @throws Exception
	 */
	public function indexExtra(array $objects, $optimize=false, $saveToFile=false,$collection=NULL)
	{
		$doc = '';
		foreach ($objects as $id => $tm)
			try {
				$doc .= TurboMarc2Solr::getSolrDoc($tm, $id, $this->_dbname, ($collection == NULL)?$this->_extraCollection : $collection);
			} catch (Exception $e) {
				Prado::log("ERROR ON RECORD {$id}, XML {$tm} - message {$e->__toString()}\n",
					TLogger::WARNING,'Console');
				echo "ERROR ON RECORD {$id}, XML {$tm} - message {$e->__toString()}\n";
			}
		if ($doc) {
			if ($saveToFile) {
				$filename = tempnam('/tmp/','sol');
				file_put_contents($filename, "<add>{$doc}</add>", FILE_APPEND);
			} else {
				$this->sendUpdate("<add>{$doc}</add>");
				$this->sendCommit();
				if ($optimize)
					$this->sendOptimize();
			}
		}
		return true;
	}

	public function indexSingle($object)
	{
		switch ($c=get_class($object)) {
			case 'Manifestation':
				// get UnimarcCache cascade
				$object_id = $object->getManifestationId();
				$object = $object->getTurbomarcCache();
			case 'TurbomarcCache':
				if (!$object_id)
					$object_id = $object->getManifestationId();
				$this->index(array($object_id => $object->getTurbomarc()));
				break;
			default:
				throw new Exception("Don't know how to index a [$c] object.");
		}
	}

	/**
	 *
	 * @param array $objects
	 * @return boolean
	 * @throws Exception
	 */
	public function indexAuthority(array $objects, $optimize=false, $saveToFile=false) {
		$doc = '';
		foreach ($objects as $id => $tm)
			try {
				$doc .= Authority2Solr::getSolrDoc($tm, $id, $this->_dbname, $this->_authorityCollection);
			} catch (Exception $e) {
				Prado::log("ERROR ON AUTHORITY {$id}, XML {$tm} - message {$e->__toString()}\n",
					TLogger::WARNING,'Console');
				echo "ERROR ON RECORD {$id}, XML {$tm} - message {$e->__toString()}\n";
			}
		if ($doc) {
			if ($saveToFile) {
				$filename = tempnam('/tmp/','sol');
				file_put_contents($filename, "<add>{$doc}</add>", FILE_APPEND);
			} else {
				$this->sendUpdate("<add>{$doc}</add>");
				$this->sendCommit();
				if ($optimize)
					$this->sendOptimize();
			}
		}
		return true;
	}

	public function deIndex($ids,$optimize=false,$saveToFile=false)
	{
		return $this->_deIndexInternal($this->_recordCollection,$ids,$optimize,$saveToFile);
	}

	public function deIndexExtra($ids,$optimize=false,$saveToFile=false)
	{
		return $this->_deIndexInternal($this->_extraCollection,$ids,$optimize,$saveToFile);
	}

	public function deIndexAuthority($ids,$optimize=false,$saveToFile=false)
	{
		return $this->_deIndexInternal($this->_authorityCollection,$ids,$optimize,$saveToFile);
	}

	/**
	 * Unindexes specified ID(s).
	 *
	 * @param string $collection
	 * @param int|array $ids
	 * @param boolean $optimize
	 * @param boolean $saveToFile 
	 */
	public function _deIndexInternal($collection,$ids,$optimize=false,$saveToFile=false) {
		if (!is_array($ids))
			$ids = array($ids);

		$doc = '';
		foreach($ids as $id)
			$doc .= "\t<id>{$this->_dbname}:{$collection}:{$id}</id>\n";
		if ($doc) {
			if ($saveToFile) {
				$filename = tempnam('/tmp/','sol');
				file_put_contents($filename, "<delete>{$doc}</delete>", FILE_APPEND);
			} else {
				$this->sendUpdate("<delete>{$doc}</delete>");
				$this->sendCommit();
				if ($optimize)
					$this->sendOptimize();
			}
		}
	}

	/**
	 * Will cleanup the doc index.
	 */
	public function cleanIndex()
	{
		$this->sendUpdate("<delete><query>collection:{$this->_recordCollection}</query></delete>");
		$this->sendCommit();
		$this->sendOptimize();
	}

	/**
	 * Will cleanup the extra index.
	 */
	public function cleanIndexExtra($collection = NULL)
	{
		if($collection == NULL) $collection = $this->_extraCollection;
		$this->sendUpdate("<delete><query>collection:{$collection}</query></delete>");
		$this->sendCommit();
		$this->sendOptimize();
	}

	/**
	 * Will cleanup the authority index.
	 */
	public function cleanIndexAuthority()
	{

		$this->sendUpdate("<delete><query>collection:{$this->_authorityCollection}</query></delete>");
		$this->sendCommit();
		$this->sendOptimize();
	}

	/**
	 * Will cleanup the entire index. All collections.
	 */
	public function cleanIndexFull()
	{
		$this->sendUpdate("<delete><query>*:*</query></delete>");
		$this->sendCommit();
		$this->sendOptimize();
	}

	/**
	 * Performs a Solr query.
	 *
	 * @param string $query The prepared query string
	 * @return mixed The query response.
	 * @throws Exception
	 */
	protected function doSelect($query)
	{
		if (!trim($query))
			return null;
		$query = preg_replace('/%5B(?:[0-9]|[1-9][0-9]+)%5D=/', '=', $query);
		//open connection
		$ch = curl_init();
		//set the url, number of POST vars, POST data
		curl_setopt($ch, CURLOPT_URL, $this->_serverUrl.self::SEARCH_SERVLET);
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $query);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		// Set a timeout of 2 seconds
		//curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 2);
		$data = curl_exec($ch);
		if ($err=curl_errno($ch))
			throw new Exception('Server unavailable: ' . $err);
		curl_close($ch);
		return $data;
	}

	/**
	 *
	 * @param string $post_string
	 * @return boolean
	 */
	public function sendUpdate($post_string)
	{
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL,$this->_serverUrl.self::UPDATE_SERVLET);
		$this_header = array('Content-type: text/xml; charset=utf-8');
		curl_setopt($ch, CURLOPT_HTTPHEADER, $this_header);
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS,$post_string);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		$data = curl_exec($ch);
		if (curl_errno($ch)) {
			return false;
		} else {
			curl_close($ch);
			if (strstr($data,'<result status="0"></result>')) {
				return true;
			} else {
				return false;
			}
		}
	}

	/**
	 * @return boolean
	 */
	public function sendCommit()
	{
		return $this->sendUpdate('<commit/>');
	}

	/**
	 * @return boolean
	 */
	public function sendOptimize()
	{
		return $this->sendUpdate('<optimize/>');
	}
}
