<?php

/**
 * SMSInfobipModule class.
 * A module for sending messages through Infobip SMS gateway.
 * 
 * 
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Cristian Chiarello <cristian@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version $Id$
 */
require_once 'vendor/autoload.php';


class SMSConsip6Module extends SMSDummyModule
{
    private $authSer="";
    private $authContract="";
    private $SOAPService=NULL;
    private $SOAPAuth=NULL;
    
    function getAuthSer()
    {
        return $this->authSer;
    }

    function getAuthContract()
    {
        return $this->authContract;
    }

    function setAuthSer( $authSer )
    {
        $this->authSer = $authSer;
    }

    function setAuthContract( $authContract )
    {
        $this->authContract = $authContract;
    }

    
    protected function getSOAPService()
    {
        if(  is_null( $this->SOAPService) )
        {
            $options = [
                    "trace" => 1,
                    "exception" => 1
                ];

            $this->SOAPService = new CustomerWS($options);
        }
        return $this->SOAPService;
    }

    protected function getSOAPAuth()
    {
        if(  is_null( $this->SOAPAuth) )
        {
            $this->SOAPAuth = new authInfo();
            $this->SOAPAuth->setUsername($this->getAuthUser());
            $this->SOAPAuth->setPassword($this->getAuthPassword());
            $this->SOAPAuth->setContratto($this->getAuthContract());
            $this->SOAPAuth->setSer($this->getAuthSer());
        }
        return $this->SOAPAuth;
    }

    /**
     * 
     * 
     * @param type $requestID
     * @return array with status and essors if any
     */
    public function sendMessage( $requestID = null )
    {
        $result = array( "status" => "OK", "errors" => array(), "data" => array() );

        try
        {
            $dst = $this->getReceiver();
            $service = $this->getSOAPService();

            $auth = $this->getSOAPAuth();

            $invio = new invioSimpleInfo();
            $invio->setTesto($this->getMessage());
            $invio->setNome($this->getSender());
            $invio->setContattiLiberi([$dst]);
            $invio->setTipo(3);
            $invio->setSr(1);

            $p1 = new addNewIstantInvio();
            $p1->setAuth($auth);
            $p1->setInvio($invio);

            $ret = $service->addNewIstantInvio($p1);

            $r = $ret->getReturn();
            
            
            $retStatusCode = $r->getStatusCode();
            if($retStatusCode != 0)
            {
                $result[ "status" ] = "KO";
                $result[ "errors" ][] = " something goes wrong, please see system log.";
                Prado::log(Prado::varDump( $r));
            }
            else
            {
                $idx=$r->getIdx();
                $msgIds = explode("|", $requestID);
                if(is_array($msgIds) && count($msgIds) == 3)
                {
                    $nId = $msgIds[2];
                    $n = NotificationQuery::create()->findOneByNotificationId($nId);
                    if($n instanceof Notification)
                    {
                        $notes=array("backend"=>"consip6", "smsid" => $idx, "notificationid"=>$nId, "to"=>$dst);
                        $n->setNotes(  serialize( $notes ));
                        $n->save();
                    }
                    else
                    {
                        Prado::log(__METHOD__ . " LINE " .__LINE__. " ERROR: invalid request ID ".$requestID." I cannot save message id to notification.");
                    }
                }
                else
                {
                    Prado::log(__METHOD__ . " LINE " .__LINE__. " ERROR: invalid request ID ".$requestID." I cannot save message id to notification.");
                }
            }
        }
        catch ( Exception $ex )
        {
            $exmsg = $ex->getMessage();
            Prado::log( __METHOD__ . " ERR: {$exmsg}" );
            $result[ "status" ] = "KO";
            $result[ "errors" ][] = "Exception {$exmsg}";
            return $result;
        }

        return $result;
    }

    public function getMsgNo()
    {
        $doublechars = array( "€", "[", "]", "{", "}", "|", "\\", "^", "~" );
        $smslen = strlen( $this->getMessage() );
        foreach ( $doublechars as $c )
        {
            $smslen += substr_count( $this->getMessage(), $c );
        }
        return ($smslen < 161) ? 1 : ceil( $smslen / 153 );
    }
    
    /**
     * Checks message status for all pending SMS
     *
     * @return boolean
     */
    public function checkStatus() 
    {
        $ret = FALSE;
        try
        {
            $n = NotificationQuery::create()
                ->filterByNotificationChannel(NotificationPeer::CHANNEL_SMS)
                ->filterByNotificationState(NotificationPeer::STATUS_PENDING)
                ->find();
            foreach ($n as $notification)
            {
                $notes = unserialize($notification->getNotes());
                if (is_array($notes) && array_key_exists('smsid',$notes)) 
                {
                    if(  !array_key_exists( 'backend', $notes ) || $notes['backend']!='consip6')
                    {
                        continue;
                    }
                    
                    //Get SOAP objects
                    $service = $this->getSOAPService();
                    $auth = $this->getSOAPAuth();

                    //sent sms param
                    $invioParam = new getMsgMTFromInvio();
                    $invioParam->setAuthInfo($auth);
                    
                    //Filter object
                    $fc=new filterCollection();
                    //Get info form specific message
                    $fc->setPattern($notes['smsid']);
                    
                    $invioParam->setFilterCollection($fc);
                    
                    //Call (or get???) remote function
                    $invio=$service->getMsgMTFromInvio($invioParam);
                    //Get response
                    $invioResp=$invio->getReturn();

                    $status = $invioResp->getStatusCode();

                    switch ($status)
                    {
                        /*
                         * Sent ok. Reply:
                          object(messageCollection)#6 (4) {
                           ["messageCollection":protected]=>
                            array(1) {
                              [0]=>
                              object(messageSimpleInfo)#7 (8) {
                                ["date":protected]=>
                                string(29) "2016-09-14T12:21:56.007+02:00"
                                ["messageId":protected]=>
                                int(21468072)
                                ["receiver":protected]=>
                                string(14) "00393494085118"
                                ["sender":protected]=>
                                string(10) "biblioteca"
                                ["srdate":protected]=>
                                string(29) "2016-09-14T12:21:57.000+02:00"
                                ["status":protected]=>
                                int(5)
                                ["text":protected]=>
                                string(15) "Prova invio sms"
                                ["type":protected]=>
                                int(2)
                              }
                            }
                            ["idx":protected]=>
                            int(1)
                            ["statusCode":protected]=>
                            int(0)
                            ["statusMessage":protected]=>
                            string(12) "M2M_Successo"
                          }
			 * WARN: Often sms status change after many time... 
                         */
                        case 0:
                            $mc = $invioResp->getMessageCollection();

                            if(!is_null( $mc ))
                            {
                                $mi = $mc[0];
                                $notification->setNotificationState(NotificationPeer::STATUS_DELIVERED);
                                $sent = $mi->getDate();
				$sentDt = $sent;
				if(is_string($sent))
				{
					$sentDt = DateTime::createFromFormat('Y-m-d\TH:i:s.uP', $sent); //ISO with millisec
				}
                                $notification->setDeliveryDate( $sentDt );
                                $acpt = $mi->getSrdate();
				$acptDt = $acpt;
				if(is_string($acpt))
				{
					$acptDt = DateTime::createFromFormat('Y-m-d\TH:i:s.uP', $acpt);
				}
                                $notification->setAcknowledgeDate( $acptDt );
                            }
                            break;

                        /*
                         Wrong number. Reply:
                         object(messageCollection)#6 (4) {
                            ["messageCollection":protected]=>
                            NULL
                            ["idx":protected]=>
                            NULL
                            ["statusCode":protected]=>
                            int(123)
                            ["statusMessage":protected]=>
                            string(21) "M2M_Errore_InvioIdNOK"
                          }
                         */
                        case 123:
                            $notification->setNotificationState(NotificationPeer::STATUS_ERROR);
                             //Try to set contact as wrong
				Contact::setWrongMobileNumber( $notification->getObjectId(), $notes['to'] );
                    }
                    
                    $notification->save();
                    
                }//if (notes format valid)
            }//foreach
            $ret = TRUE;
        }
        catch ( Exception $ex )
        {
            Prado::log(__METHOD__ . " EXCEPTION " . $ex->getMessage());
        }
        
        return $ret;
    }

}
