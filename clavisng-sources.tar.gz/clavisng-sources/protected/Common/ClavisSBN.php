<?php
/**
 * ClavisSBN class file.
 *
 * This file contains all the required classes for SBN dialogue v4.
 * Based upon SBNConnector by Comperio srl.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Modules.SBN
 */
Prado::using('SBNLib');

/**
 * ClavisSBN Class
 *
 * Provides methods for interacting with SBN index v4
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Modules.SBN
 * @since 2.5.1
 */
class ClavisSBN extends TModule {

	private $_enabled = false;
	private $_authuser;
	private $_authpassword;
	private $_address = '';
	private $_nodePrefix;
	private $_defaultLibraryCode = '01';
	private $_bulkLocalizeItemStatus = array('B','F','G','K','Q','R','V');
	private $_profile;

	public function init($config)
	{
		global $SITEPATH;
		parent::init($config);
		if (!$this->_enabled)
			return;
		try {
			if (!file_exists($SITEPATH.'/sbnprofile.xml')) {
				// try to update, then disable module if we have not a profile.
				$this->updateSbnProfile();
				if (!file_exists($SITEPATH.'/sbnprofile.xml')) {
					$this->_enabled = false;
					return;
				}
			}
			$this->_profile = new SimpleXMLElement(file_get_contents($SITEPATH.'/sbnprofile.xml'));
		} catch (Exception $e) {
			// most likely authentication failed, so skip it
			$this->_enabled = false;
		}
	}

	public function setEnabled($value) {
		$this->_enabled = TPropertyValue::ensureBoolean($value);
	}
	public function getEnabled() {
		return $this->_enabled;
	}
	public function setAuthUser($value) {
		$this->_authuser = $value;
	}
	public function getAuthUser() {
		return $this->_authuser;
	}
	public function setAuthPassword($value) {
		$this->_authpassword = $value;
	}
	public function getAuthPassword() {
		return $this->_authpassword;
	}
	public function setAddress($value) {
		$this->_address = $value;
	}
	public function getAddress() {
		return $this->_address;
	}
	public function setNodePrefix($value) {
		$this->_nodePrefix = substr($value,0,3);
	}
	public function getNodePrefix() {
		return $this->_nodePrefix;
	}
	public function setDefaultLibraryCode($value) {
		$this->_defaultLibraryCode = substr($value,0,2);
	}
	public function getDefaultLibraryCode() {
		return $this->_defaultLibraryCode;
	}
	public function setBulkLocalizeItemStatus($value) {
		$this->_bulkLocalizeItemStatus = is_array($value)
			? $value
			: explode(',',$value);
	}
	public function getBulkLocalizeItemStatus() {
		return is_array($this->_bulkLocalizeItemStatus)
			? $this->_bulkLocalizeItemStatus
			: explode(',',$this->_bulkLocalizeItemStatus);
	}

	/**
	 * Create a new SBNRequest object
	 *
	 * @param string $user The user code
	 * @param string $library The library id
	 * @return SBNRequest
	 */
	public function getNewRequest($user='000',$library=null)
	{
		$request = new SBNRequest();
		$request->setAddress($this->_address);
		$request->setAuthUser($this->_authuser);
		$request->setAuthPassword($this->_authpassword);
		$request->setUser($this->getUserCode($user));
		$request->setLibrary($this->getLibraryCode($library));
		return $request;
	}

	public function getLibraryCode($library=null)
	{
		if (is_numeric($library))
			$library = LibraryQuery::create()->findPk($library);
		return ($library instanceof Library) ?
			$this->_nodePrefix.' '.str_pad($library->getSbnCode(),2,'0',STR_PAD_LEFT) :
			$this->_nodePrefix.' '.$this->_defaultLibraryCode;
	}

	public function getUserCode($user)
	{
		return ($user instanceof Librarian || $user instanceof ClavisLibrarian) ?
			$this->_nodePrefix.str_pad($user->getId(),3,'0',STR_PAD_LEFT) :
			$this->_nodePrefix.str_pad(intval($user),3,'0',STR_PAD_LEFT);
	}

	public function getSbnProfile()
	{
		return $this->_profile;
	}

	public function updateSbnProfile()
	{
		global $SITEPATH;

		$req = $this->getNewRequest('000',null);
		$sbn_response = $req->requestCurrentSbnProfile();
		if ('0000' == $sbn_response->SbnMessage->SbnResponse->SbnResult->esito) {
			$sbn_response->SbnMessage->SbnResponse->SbnUserProfile->asXML($SITEPATH.'/sbnprofile.xml');
			$this->_profile = $sbn_response->SbnMessage->SbnResponse->SbnUserProfile;
		}
	}
}
