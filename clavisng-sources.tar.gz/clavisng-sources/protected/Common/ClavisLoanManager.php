<?php
/**
 * ClavisLoanManager class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info
 * @comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Max Pigozzi
 * @author Marco Brancalion <marco@comperio.it>
 * @author Ciro Mattia Gonano
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Core
 */

/**
 * ClavisLoanManager Class
 *
 * @author Max Pigozzi
 * @author Marco Brancalion <marco@comperio.it>
 * @author Ciro Mattia Gonano
 * @version 2.8.9
 * @package Core
 * @since 2.0
 */
class ClavisLoanManager extends TModule implements ILoanManager
{
	//generic boolean for functions which return enumerated
	const OK = 1;
	const ERROR = 0; //generic
	const CALCULATEDATE_ERROR = -1;

	//DO LOAN - errors
	const LOAN_RESERVED = 20;
	const LOAN_NOTRESERVABLE = 22;
	const LOAN_ALREADYRESERVED = 25;
	const LOAN_ILLREQUESTED = 30;
	const LOAN_LOANED = 40;
	const LOAN_NOTLOANED = 41;
	const LOAN_READYTOLOAN = 42;
	const LOAN_REACHEDMAX = 44;
	const LOAN_PATRONNOTENABLED = 46;
	const LOAN_PATRONNOTAGE = 46.3;
	const LOAN_EXTERNALLIBRARYNOTENABLED = 46.135;
	const LOAN_LOANALREADYEXISTS = 49.5;
	const LOAN_ABORTRETURNHOME = 47.2;
	const LOAN_EXTRASYSTEMINCONGRUENCY = 51.4;
	const LOAN_ABORTFORCEACTUAL = 48.45;
	const LOAN_ABORTFORCEOWNER = 49.47;
	const LOAN_ISLATE = 127;
	const LOAN_MANIFESTATIONNOTLOANABLESINCE = 46.4;
	const LOAN_ITEMNOTAVAIL = 46.6;
	
	//RENEWAL - errors
	const RENW_NOTAVAIL = -1;
	const RENW_REACHEDMAXREN = -2;
	const RENW_NOTLOANED = -3;
	const RENW_ALREADYREQUESTED = -4; //la manif. dell'item e' richiesta e non ci sono abbastanza copie disponibili

	//SOLICIT - errors
	const SLCT_NOTAVAIL = -1;

	//RESERVATION - errors
	const RSV_NOTAVAIL = -1;
	const RSV_PATRONHASITEM = -2;
	const RSV_PATRONREQITEM = -3;
	const RSV_PATRONMAXREQ = -4;
	const RSV_PATRONREQMANIF = -5;
	const RSV_ALREADYMANAGED = -6;
	const RSV_UNMANAGENOTSAMEOPERATOR = -6.1;
	const RSV_ALREADYCLOSED = -6.3;
	const RSV_NOTMANAGED = -6.5;
	const RSV_RATING = -7;
    const RSV_PATRONDISABLED = -8;

	//RETURN
	const RETN_PATRONREQUEST = 2;
	const RETN_OKANDMOVE = 1.24;

	const DAYS_1 = 86400;

	public function IsItemLoaned($item, $patron = null)
	{
		if (!($item instanceof Item))
			return false;

		return $item->IsLoaned($patron);
	}

	public function IsItemLoanStatusActive($item, $patron = null)
	{
		if (!($item instanceof Item))
			return false;

		return $item->IsLoanStatusActive($patron);
	}
	
	/**
	 * Verifies if a Patron is enabled for being the subject of a loan, checking
	 * against the system item limits and patron' status.
	 *
	 * @param Patron $patron
	 * @param int $itemId
     * @param bool $reserveMode if in reserve mode extra loans check
	 * @return enumerated (result code)
	 */
	public static function IsPatronAllowedToLoan($patron, $itemId = null, $reserveMode = false)
	{

        if($reserveMode)
            $maxExtraLoans = ClavisParamPeer::getParam('MAXEXTRALOANS', 0);
        else
            $maxExtraLoans = 0;


		if (!$patron instanceof Patron)
			return self::ERROR;

		$item = null;
		if ($itemId > 0)
		{
			$item = ItemQuery::create()->findPk($itemId);
			if (!($item instanceof Item))
				return self::ERROR;
		}

		if ($patron->getPatronStatus() == PatronPeer::STATUS_ENABLED)
		{
			$currentLoanStatuses = ItemPeer::getLoanStatusActive();
			/* these status are:
			self::LOANSTATUS_INLOAN, // B
			self::LOANSTATUS_INTRANSIT, // C
			self::LOANSTATUS_READYFORTRANSIT, // E
			self::LOANSTATUS_READYFORLOAN, // F
			self::LOANSTATUS_READYFORTRANSITTOHOME, // J
			self::LOANSTATUS_INLOANEXTRA, // K
			self::LOANSTATUS_INCONSULTATION, // M
			self::LOANSTATUS_INFREEZEDCONSULTATION // N
			*/

            if ((ClavisParamPeer::getParam('MAXEXTRALOANS', 0) > 0) 
					&& !$reserveMode)
            {
                $currentLoanStatuses = array_diff(	$currentLoanStatuses,
													array(	ItemPeer::LOANSTATUS_INCONSULTATION, ItemPeer::LOANSTATUS_INFREEZEDCONSULTATION,
															ItemPeer::LOANSTATUS_INTRANSIT, ItemPeer::LOANSTATUS_READYFORTRANSIT,
															ItemPeer::LOANSTATUS_READYFORLOAN ));
            } 
			else 
			{
                // Remove items in consultation from active loans of a user.
                $currentLoanStatuses = array_diff(	$currentLoanStatuses,
													array(	ItemPeer::LOANSTATUS_INCONSULTATION,
															ItemPeer::LOANSTATUS_INFREEZEDCONSULTATION ));
            }
			
			// number of total loans per patron
			$current_patron_loans = ItemQuery::create()
										->filterByPatron($patron)
										->filterByLoanStatus($currentLoanStatuses)
										->prune($item)
										->count();

            $current_patron_reservations = ItemRequestQuery::create()
                                            ->filterByPatron($patron)
                                            ->filterByRequestStatus(ItemRequestPeer::getActiveStatus())
                                            ->count();

			$patronMaxLoans = intval($patron->getMaxLoans());

			if ($patronMaxLoans > 0)
			{
				// if the user has a limit in the loans number ...
				return ($current_patron_loans < $patronMaxLoans )
									? self::OK 
									: self::LOAN_REACHEDMAX;
			}
			else
			{
                $maxOperations = ClavisParamPeer::getParam('MAXOPERATIONS_' . $patron->getLoanClass(), '0');
				$max_allowed_loans = intval(ClavisParamPeer::getParam('MAXLOANSALLOWED_' . $patron->getLoanClass() , '0'));

				if (($current_patron_loans >= ($max_allowed_loans + $maxExtraLoans))    // by mbrancalion, 2016-01-15: levato ($max_allowed_loans > 0) in AND all'inizio dell'espressione
                    || (($current_patron_loans + $current_patron_reservations) >= $maxOperations) )
				// general loan limit per user (per system) has been hit
					return self::LOAN_REACHEDMAX;

				$givenMedia = ($item instanceof Item) ? trim($item->getItemMedia()) : '';
				
				if ($givenMedia)
				{
					// check max loans upon item_media_type
					$maxAllowedLoansMedia = intval(ClavisParamPeer::getParam('MAXLOANSALLOWED_'. $patron->getLoanClass(), $givenMedia));
					if ($maxAllowedLoansMedia >= 0)
					{
						$itemsInLoanCountPerMedia = ItemQuery::create()
								->filterByPatron($patron)
								->filterByLoanStatus($currentLoanStatuses)
								->filterByItemMedia($givenMedia)
								->prune($item)
								->count();
				
						if ($itemsInLoanCountPerMedia >= ($maxAllowedLoansMedia + $maxExtraLoans) )
							return self::LOAN_REACHEDMAX;
					}
					return self::OK;
				} 
				else
				{
					// check upon total loans by category
					$allowedMediaArray	 = ClavisParamPeer::getClassParams('MAXLOANSALLOWED_'. $patron->getLoanClass());
					$patronItems		 = ItemQuery::create()
							->filterByPatron($patron)
							->filterByLoanStatus($currentLoanStatuses)
							->prune($item)
							->find();
					foreach ($patronItems as $loanItem)
					{
						$itemMedia = $loanItem->getItemMedia();
						if (array_key_exists($itemMedia, $allowedMediaArray))
						{
							--$allowedMediaArray[$itemMedia];
							if ($maxExtraLoans == ($allowedMediaArray[$itemMedia] + $maxExtraLoans) )
								unset($allowedMediaArray[$itemMedia]);
						}
					}
					
					return count($allowedMediaArray > 0) 
										? self::OK 
										: self::LOAN_REACHEDMAX;
				}
			}
		} 
		else
		{
			return self::LOAN_PATRONNOTENABLED;
		}
	}

	public static function isExternalLibraryAllowedToLoan($library)
	{
		$output = self::LOAN_EXTERNALLIBRARYNOTENABLED;
		
		if (!$library instanceof Library && is_numeric($library))
			$library = LibraryQuery::create()->findPK($library);
		if ($library instanceof Library &&
				$library->getLibraryStatus() == LibraryPeer::STATUS_ACTIVE &&
				$library->isExternal())
			$output = self::OK;
		
		return $output;
	}

	public static function IsRatingAllowed($manifestation = null, $patron = null)
	{
		$return = true;
		if (($manifestation instanceof Manifestation) && ($patron instanceof Patron))
		{
			$rating = intval($manifestation->getRating());

			if ($rating > 0)
				$return = ($patron->getPatronAge() >= $rating);
		}

		return $return;
	}

	/**
	 * It verifies if a Patron is enabled for doing a loan, given a specific Item
	 *
	 * @param Patron $patron
	 * @param Item $item
	 * @param int $libraryId (destination)
	 *
	 * @return boolean
	 *
	 */
	public static function IsLoanAllowed($item, $object = null, $libraryId = null, $reserveMode = false)
	{
		if (!($item instanceof Item))
			return false;

		if ($object instanceof Patron)
		{
			if (self::IsPatronAllowedToLoan($object, $item->getItemId(),$reserveMode) != self::OK)
				return false;

			if (!self::IsRatingAllowed($item->getManifestation(), $object))
				return false;
		}

		if ($object instanceof Library)
		{
			if (self::isExternalLibraryAllowedToLoan($object) != self::OK)
				return false;
		}

		$loanClass = $item->getLoanClass();
		if (in_array($loanClass, ItemPeer::getLoanClassesAvailable()))  //'Disponibile al prestito'
			return true;
		else
		{
			if (!is_null($libraryId) && ($libraryId > 0))
			{
				if (in_array($loanClass, ItemPeer::getLoanClassesLocallyAvailable()) && ($item->getHomeLibraryId() == $libraryId))
					return true;
				else
					return false;
			}

			return false;
		}
	}

	/**
	 * It verifies if an item is available for a immediate loan
	 *
	 * @param Item $item
	 * @param int $localLibraryId (destination library)
	 * @param Patron|Library $object (destination object)
	 *
	 * @return boolean
	 *
	 */
	public function IsItemAvailable($item, $localLibraryId = null, $object = null)
	{
		if (!($item instanceof Item))
			return self::ERROR;

		if (!$item->checkLoanableSince())
			return self::LOAN_MANIFESTATIONNOTLOANABLESINCE;

		$manifestation = $item->getManifestation();
		$itemLoanStatus = $item->getLoanStatus();
		if ($object instanceof Patron)
		{
			if (($manifestation instanceof Manifestation) && (!self::IsRatingAllowed($manifestation, $object)))
				return self::LOAN_PATRONNOTAGE;

			$itemPatronId = $item->getPatronId();
			$patronPatronId = $object->getPatronId();
			$requestedBySameObject = ($itemLoanStatus == ItemPeer::LOANSTATUS_READYFORLOAN
											&& $itemPatronId == $patronPatronId);
		}
		elseif ($object instanceof Library)
		{
			$itemExternalLibraryId = $item->getExternalLibraryId();
			$externalLibraryId = $object->getLibraryId();
			$requestedBySameObject = ($itemLoanStatus == ItemPeer::LOANSTATUS_READYFORLOAN
											&& $itemExternalLibraryId == $externalLibraryId);
		}
		else
		{
			$requestedBySameObject = false;
		}

		$itemAvailableClassFlag = self::IsItemAvailableClass($item, $localLibraryId);
		$loanStatusFlag = in_array($itemLoanStatus, ItemPeer::getLoanStatusAvailable());

		if ($itemAvailableClassFlag && //	'available for loan'
			($loanStatusFlag || $requestedBySameObject)) // 'available (not in loan)'
		{
			return self::OK;	//	can loan
		}
		else
		{
			return self::LOAN_ITEMNOTAVAIL;	//	can't loan immediately
		}
	}

	public function countItemsAvailable(	$manifestationId = null,
											$deliveryLibraryId = null,
											$actualLibraryId = null)
	{
		if (intval($manifestationId) == 0)
			return self::ERROR;
		
		if (intval($actualLibraryId) == 0)
			$actualLibraryId = $this->getUser()->getActualLibraryId();
		
		if (intval($deliveryLibraryId) == 0)
			$deliveryLibraryId = $actualLibraryId;
		
		$queryString = "SELECT COUNT(*)
						FROM item i
						WHERE (i.manifestation_id = {$manifestationId})
				  		AND i.actual_library_id='{$actualLibraryId}'
						AND i.loan_status IN ('" . implode(ItemPeer::getLoanStatusAvailable(), "','") . "')
						AND ((i.issue_id IS NOT NULL AND i.issue_status='" . ItemPeer::ISSUESTATUS_ARRIVED . "')
						 	OR i.issue_id IS NULL)
						AND (i.loan_class IN ('" . implode(ItemPeer::getLoanClassesAvailable(), "','") . "')
						 	OR (i.actual_library_id = {$deliveryLibraryId} AND i.loan_class IN ('" 
								. implode(ItemPeer::getLoanClassesLocallyAvailableIgnoringConsultations(), "','") . "')))
						";

		$connection = Propel::getConnection();
		$stmt = $connection->prepare($queryString);
		$stmt->execute();

		return $stmt->rowCount();
	}
	
	/**
	 * This method calculates if a loan is late.
	 * Parameter can be an Item, a Loan, or a timestamp.
	 *
	 * @param Item||Loan||integer(timestamp) $object
	 * @return enumerated
	 */
	public function isLoanLate($object = null)
	{
		if (($object instanceof Loan) || ($object instanceof Item))
			$dueDate = $object->getDueDate('U');
		else if (intval($object) > 0)
			$dueDate = $object;
		else
			return self::ERROR;
		
		$now = getdate();
		$daystartTimestamp = mktime(0, 0, 0, $now['mon'], $now['mday'], $now['year']);
		
		return ($dueDate < $daystartTimestamp) ? self::LOAN_ISLATE : self::OK;
	}

	public function IsItemAvailableClass(	$item, 
											$localLibraryId = null)
	{
	    if ($localLibraryId == null)
            $localLibraryId = $this->getUser()->getActualLibraryId();

		/* @var $item Item */
		
		//getLoanClassesLocalNew()
		$check = in_array($item->getLoanClass(), ItemPeer::getLoanClassesAvailable());
		$localLibraryId = intval($localLibraryId);

		if ($localLibraryId > 0)
		{
			if (in_array($item->getLoanClass(), ItemPeer::getLoanClassesLocallyAvailable()))
				$check = ($item->getHomeLibraryId() == $localLibraryId);
		}	

		return $check;
	}
	
	public function isRenewSuspended($item)
	{
		if (!($item instanceof Item))
			return self::ERROR;

		return ($item->getRenewalCount() < 0);
	}

	/**
	 * Here we verify if the loan of an item is renewable, according to eventual
	 * requests existing in the system for this item or its manifestation.
	 * And next we check for reaching or not the renew limit parameters (per media
	 * of not).
	 *
	 * @param Item $item
	 * @param ClavisLibrarian $clavisLibrarian
	 * @param Patron/Library $destinationObject
	 *
	 * @return int (enumerated) :
	 *      self::OK
	 * 		self::ERROR : generic error
	 *
	 * 	self::RENW_NOTAVAIL : renewal not available
	 *	self::RENW_REACHEDMAXREN : reached max renewal count
	 *	self::RENW_NOTLOANED : not in loan state (when it was supposed to be)
	 *
	 */
	public function IsLoanRenewable($item, $clavisLibrarian = null, $destinationObject = null)
	{
		if (!$item instanceof Item)
			return self::ERROR;

		if (is_null($clavisLibrarian))
			$clavisLibrarian = $this->getUser();
		
		if (!$clavisLibrarian instanceof ClavisLibrarian)
			return self::ERROR;

		if (!$this->IsItemLoaned($item))
			return self::RENW_NOTLOANED;

		if ($item->getRenewalCount() < 0)
			return self::RENW_NOTAVAIL;

        if(($item->getPatron() instanceof Patron) && $item->getPatron()->getPatronStatus() != PatronPeer::STATUS_ENABLED)
            return self::RENW_NOTAVAIL;

		//NEW (04/05/2007) si verifica il numero delle copie disponibili rispetto a quelle prestate e le richieste pendenti:
		//se (numero delle copie disponibili (per quella manif.) (non prestate AND disponibili al prestito)	-
		//   (numero delle item_request (pendenti OR in gestione) < 0 => NON RINNOVABILE
		//NB la verifica e' prioritaria risp. al numero delle volte che il prestito puo' essere rinnovato, per cui va fatta prima!
		$itemId = intval($item->getItemId());
		$manifestation = null;
		$manifestationId = intval($item->getManifestationId());
		
		if ($manifestationId > 0)
			$manifestation = ManifestationQuery::create()
								->findPK($manifestationId);

		$oocItemFlag =  !($manifestation instanceof Manifestation);
		$issueId = $item->getIssueId();


        // Check if exists a reservation for the specific item
        $thisItemRuquestCount = ItemRequestQuery::create()
									->filterByRequestStatus(ItemRequestPeer::getActiveStatus())
									->filterByManifestationId($manifestationId)
									->_if(!is_null($issueId))
										->filterByIssueId($issueId)
									->_endif()
									->filterByItemId($itemId)
									->count();

        if ($thisItemRuquestCount > 0)
            return self::RENW_ALREADYREQUESTED;

		if (!$oocItemFlag)
		{
			if (LLibraryPeer::isEnabled())	// basin case
			{
				$queryString = "SELECT
									r.request_id as requestId,

									(SELECT GROUP_CONCAT(i.item_id )
										FROM item i

										WHERE

										i.manifestation_id = r.manifestation_id

										AND i.loan_status IN ('" . implode(ItemPeer::getLoanStatusAvailable(), "','") . "')" .

										" AND ((r.issue_id IS NOT NULL 	and r.issue_id = i.issue_id AND i.issue_status = '" . ItemPeer::ISSUESTATUS_ARRIVED . "')" .
										" OR r.issue_id IS NULL)
										AND (i.LOAN_CLASS IN ('" . implode(ItemPeer::getLoanClassesAvailable(true), "','") . "')" .
										" OR (r.delivery_library_id = " . $item->getHomeLibraryId() .
										" AND i.LOAN_CLASS IN ('" . implode(ItemPeer::getLoanClassesLocallyAvailable(true), "','") . "')))" .

										" AND ((r.max_distance IS NOT NULL AND
											i.actual_library_id IN
											(SELECT to_library_id FROM l_library WHERE from_library_id = " . $item->getActualLibraryId() .
												" AND distance <= r.max_distance))
										OR r.max_distance IS NULL)

										GROUP BY i.manifestation_id

									) as itemIds

								FROM item_request r

								WHERE

									r.manifestation_id = " . $manifestationId .

									(!is_null($issueId)
											? " AND r.issue_id = " . $issueId
											: "") .

								" AND (r.item_id IS NULL OR r.item_id = " . $item->getItemId() .")

								AND r.request_status = '" . ItemRequestPeer::STATUS_PENDING . "'" .

								" AND ((r.max_distance IS NOT NULL AND
									r.delivery_library_id IN
									(SELECT to_library_id FROM l_library WHERE from_library_id = " . $item->getActualLibraryId() .
										" AND distance <= r.max_distance))
									OR r.max_distance IS NULL)";

				$connection = Propel::getConnection();
				$stmt = $connection->prepare($queryString);
				$stmt->execute();
				$itemIdsPool = array();

				while ($row = $stmt->fetch(PDO::FETCH_ASSOC))
				{
					$itemIds = $row['itemIds'];
					
					if (count($itemIds) > 0)
						$itemIdsPool = array_merge($itemIdsPool, explode(',', $row['itemIds']));
				}

				$itemIdsPool = array_unique($itemIdsPool);

				if ($stmt->rowCount() > count($itemIdsPool))
					return self::RENW_ALREADYREQUESTED;
			}
			else	// normal, non basin case
			{
				$count_items = ItemQuery::create()
								->filterByManifestationId($manifestationId)
								->_if(!is_null($issueId))
									->filterByIssueId($issueId)
								->_endif()
								->filterByLoanClass(ItemPeer::getLoanClassesAvailable())
								->filterByLoanStatus(ItemPeer::getLoanStatusAvailable())
								->count();
				
				$count_requests = ItemRequestQuery::create()
									->filterByRequestStatus(ItemRequestPeer::getActiveStatus())
									->filterByManifestationId($manifestationId)
									->_if(!is_null($issueId))
										->filterByIssueId($issueId)
									->_endif()
									->condition('item_id','ItemRequest.ItemId = ?',$itemId)
									->condition('item_null','ItemRequest.ItemId IS NULL')
									->where(array('item_id','item_null'),'or')
									->count();
				
				if ($count_requests > $count_items)
					return self::RENW_ALREADYREQUESTED;
			}
		}
		else
		{
			$count_requests = ItemRequestQuery::create()
								->filterByRequestStatus(ItemRequestPeer::getActiveStatus())
								->filterByItemId($itemId)
								->count();
			
			if ($count_requests > 0)
				return self::RENW_ALREADYREQUESTED;
		}

		/**
		 * Here we check if out patron has reached the max renew count parameter.
		 * We consider this parameter "per media", but if its' missing we will
		 * use the general parameter (0).
		 */
		if ($item->getPatron() instanceof Patron)
		{
			$loanClass = $item->getPatron()->getLoanClass();
		}
		elseif($item->getExternalLibraryId() > 0)
		{
			$loanClass = "X";
		}
		else
		{
			$loanClass = "";
		}

		$max_times = ClavisParamPeer::getParam('MAXLOANRENEWS_' . $loanClass, $item->getItemMedia());
		
		if ($max_times == '')
			$max_times = ClavisParamPeer::getParam('MAXLOANRENEWS', '0');
		
		return ($item->getRenewalCount() < $max_times)
							? self::OK
							: self::RENW_REACHEDMAXREN;
	}

	/**
	 * It verifies if the loan of an item is solicitable
	 *
	 * @param Item or Loan $object
	 * @param ClavisLibrarian $clavisLibrarian
	 * @param Patron or Library $destination
	 *
	 * @return int (enumerated) :
	 *      self::OK  : true
	 * 		self::ERROR : generic error
	 *
	 * 	 	self::SLCT_NOTAVAIL : renewal not available
	 */
	public function IsLoanSolicitable($object, $clavisLibrarian = null, $destination = null)
	{
		if (!(($object instanceof Item) || ($object instanceof Loan)) )
			return self::ERROR;   // invalid object

		if (is_null($clavisLibrarian))
			$clavisLibrarian = $this->getUser();
		if (!($clavisLibrarian instanceof ClavisLibrarian))
				return self::ERROR;

		$extra = false;
		if (!is_null($destination))
		{
			if ($destination instanceof Library)
				$extra = true;
			elseif (!($destination instanceof Patron))
				return self::ERROR;
		}

		if ((self::isLoanLate($object) == self::LOAN_ISLATE) && (self::IsLoanStatusCurrent($object)))
			return self::OK;
		else
			return self::SLCT_NOTAVAIL;
	}

/**
 * This method creates extra-system loans, which are conceived
 * for being immediate and effective (no middle states, such as
 * "in transit" status or similar.
 * (from my consortia towards universe)
 *
 * @param int $itemId
 * @param int $libraryId
 * @param date $dueDate
 * @param int $librarianId
 * @return enum
 */
	public function doLoanItemExtra($itemId, $libraryId, $dueDate = null, $librarianId = null)
	{
		/// TODO: controllare di usare la $dueDate che viene passata

		$currentTime = time();
		$item = ItemQuery::create()->findPK($itemId);
		$library = LibraryQuery::create()->findPK($libraryId);
		if (is_null($item) || is_null($library))
			return self::ERROR;

		$librarian = null;
		$librarianId = intval($librarianId);
		if ($librarianId > 0)
			$librarian = LibrarianQuery::create()->findPK($librarianId);
		if (is_null($librarian))
		{
			$librarian = $this->getUser();
			$librarianId = $librarian->getID();
		}

		$_connection = Propel::getConnection();
		$_connection->beginTransaction();
		try
		{
			$item_action = new ItemAction();
			$item_action->setActionDate($currentTime);
			$item_action->setActionType(ItemActionPeer::TYPE_EXTRALOAN); //'Prestito'
			$item_action->setItemId($itemId);

			$item_action->setLibrarianId($librarianId);
			$item_action->setLibraryId($libraryId);

			$fromLibraryId = $librarian->getActualLibraryId();
			if ($fromLibraryId != null)
			{
				$item_action->setFromLibraryId($fromLibraryId);
				$item_action->setLibraryId($fromLibraryId);
			}

			$item_action->setToLibraryId($libraryId);
			$item_action->save();

			$item->setLoanStatus(ItemPeer::LOANSTATUS_INLOANEXTRA);
			$item->setCurrentLoanId(null);
			$item->setCheckIn(null);
			$item->setCheckOut(null);
			$item->setIllTimestamp($currentTime);
			$item->setRenewalCount(0);
			$item->setNotifyCount(0);
			$item->setDueDate(null);       /////// todo
			$item->setPatronId(0);

			$item->setDeliveryLibraryId($libraryId);
			$item->setActualLibraryId($libraryId);

			$item->save();
			$itemId = $item->getItemId();

			$loan = new Loan();
			$loan->setItemId($itemId);
			$loan->setItemHomeLibraryId($item->getHomeLibraryId());
			$loan->setOwnerHomeLibraryId($item->getOwnerLibraryId());

			$loan->setLoanStatus(ItemPeer::LOANSTATUS_INLOANEXTRA);
			$loan->setLoanType(ItemPeer::LOANTYPE_EXTRASYSTEM); // prestito extra-sistema
			$loan->setPatronId(0);
			$itemtit = $item->getCompleteTitle();
			if (!$itemtit)
				$itemtit = Prado::localize('(nessun titolo)');
			$loan->setTitle($itemtit);
			$manifestationId = $item->getManifestationId();
			$loan->setManifestationId($manifestationId);
			$manifestation = ManifestationQuery::create()->findPK($manifestationId);
			if (!is_null($manifestation))
				$loan->setClassCode($manifestation->getClass());

			$loan->setInvNumber($item->getInventorySerieId()."-".$item->getInventoryNumber());
			$loan->setCollocation($item->getCollocation());
			$loan->setItemMedia($item->getItemMedia());
			$loan->setLoanDateBegin($currentTime);
			$loan->setLoanDateEnd(null);
			$loan->setFromLibrary($item->getHomeLibraryId());
			$loan->setToLibrary($libraryId);
			$loan->setEndLibrary(null);
			$loan->setRenewCount(0);
			$loan->setNotifyCount(0);
			$loan->setNotifyAutoCount(0);
			$loan->setDueDate(null);         ///// todo
			$loan->setItemrequestId(null);

			$loan->setItemInventoryDate($item->getInventoryDate('U'));
			$loan->setDestinationName($library->getLabel());

			$loan->setMediapackageSize($item->getMediapackageSize());
			$loan->save();

			$loanId = $loan->getLoanId();
			$item->setCurrentLoanId($loanId);
			$item->save();

			$_connection->commit();
			return self::LOAN_LOANED;
		}
		catch (Exception $e)
		{
			$e = $e;
			$_connection->rollBack();
			return self::ERROR;
		}
	}

	public function throwCalculateDueDateError()
	{
		throw new Exception(Prado::localize("Errori nel passaggio di parametri a [CalculateDueDate] nel loanmanager"));
	}

	/**
	 * Loan of an item
	 * NB dovra' aggiornare:
	 *   - tab. item
	 *   - tab. item request (eventualmente - caso interbibliotecario)
	 *   - tab. loan
	 *   - item. action
	 *
	 * @param Item $item
	 * @param Patron|Library $loanObject : a patron or an external library (in the case of extra system loan)
	 * @param ClavisLibrarian $clavisLibrarian
	 * @param Library $deliveryLibrary
	 * @param ItemRequest $item_request
	 * @param *nix timestamp : $dueDate
	 *
	 * int (enumerated) :
	 * 		   self::OK : true
	 *         self::ERROR : generic error
	 *
	 * 		  self::LOAN_RESERVED : item reservation done;
	 *        self::LOAN_ILLREQUESTED : item booked for a ILL;
	 *        self::LOAN_LOANED : item actually loaned (immediate)
	 *
	 */
	public function DoLoanItem($item,
								$loanObject,
								$clavisLibrarian = null,

								$deliveryLibrary,
								$item_request = null,
								$dueDate = null )
	{

		if (!($item instanceof Item))
			return self::ERROR;

		if (is_null($loanObject))
			return self::ERROR;

		if ($loanObject instanceof Patron)
		{
			$patron = $loanObject;
			$externalLibrary = null;
			$externalLibraryId = null;
		}
		elseif ($loanObject instanceof Library)
		{
			$externalLibrary = $loanObject;
			$externalLibraryId = $externalLibrary->getLibraryId();
			$patron = null;
		}

		if (is_null($clavisLibrarian))
			$clavisLibrarian = Prado::getApplication()->getUser();
		if (!($clavisLibrarian instanceof ClavisLibrarian))
			return self::ERROR;
		$myLibraryId = $clavisLibrarian->getActualLibraryId();

		if (!($deliveryLibrary instanceof Library))
			return self::ERROR;

		if ($item_request != null)
		{
			if (!($item_request instanceof ItemRequest))
				return self::ERROR;
		}

		if ($dueDate != null)
		{
			if(!is_numeric($dueDate))
				return self::ERROR;
		}

		$manifestation = $item->getManifestation();
		$manifestationId = $item->getManifestationId();

		try
		{
			$currentTime = time();
			$isExtra = ($externalLibrary instanceof Library);
			$isExternal = $item->isExternal();

			/** delivery change in case the destination is an external library and there's no node library.
			 * It fixes the case the item has finished an interloan and now is ready to return home, but
			 * there we want to satisfy an existing request towards an external library.
			 */
			if ($isExtra && $this->getExtraSystemNodeLibraryId() == 0)  // non esiste biblioteca nodo e siamo in extraout
 				$deliveryLibrary = $clavisLibrarian->getActualLibrary();

			if ($item->getActualLibraryId() != $deliveryLibrary->getLibraryId())
			{
				//PRESTITO INTERBIBLIOTECARIO
				if (is_null($item_request))
				{
					if (!is_null($manifestation))
						$reserveExitCode = ClavisRequestManager::isManifestationReservable(	$item->getManifestation(),
																							null,
																							$loanObject );
					else
						$reserveExitCode = null;

					switch ($reserveExitCode)
					{
						case self::OK:
							$item_request = new ItemRequest();
							$item_request->setRequestStatus(ItemRequestPeer::STATUS_PENDING);
							$item_request->setItemId($item->getItemId());
							$item_request->setManifestationId($item->getManifestationId());

							$item_request->setPatron($patron);
							$item_request->setExternalLibrary($externalLibrary);

							$item_request->setRequestDate($currentTime);
							$item_request->setDeliveryLibraryId($deliveryLibrary->getLibraryId());

							//$librarian_id = $clavisLibrarian->getId();
							//if (!is_null($librarian_id) && is_numeric($librarian_id) && ($librarian_id > 0))
							$item_request->setLibrarianId(null);  //$librarian_id);

							$expireDate = self::CalculateExpireDate($item_request, $item, $patron);
							if ($expireDate != -1)
								$item_request->setExpireDate($expireDate);
							else
								throw new Exception('');

							$item_request->save();

							//edit patron last_seen for statistics
							if (!is_null($patron))
								$patron->UpdateLastSeen(true);

							return self::LOAN_RESERVED;
							break;


						case self::RSV_PATRONREQMANIF :
							return self::LOAN_ALREADYRESERVED;
							break;

						case self::RSV_PATRONMAXREQ :
						case self::RSV_NOTAVAIL :
						case null:
						default:
							return self::LOAN_NOTRESERVABLE;
							break;
					}
				}
				elseif (self::IsItemAvailable($item, $deliveryLibrary->getLibraryId(), $loanObject) == self::OK)
				{
					//prestito interbibliotecario possibile
					//
					//immediato - richiesta di prenotazione
					//insert item_action (prestito + spostamento da actual_library a delivery_library


					/** 05/11/2009, per eliminare casi in cui una cattiva concorrenza
					* abbia fatto si che piu' di un operatore creda di avere preso in gestione
					* una prenotazione: all'atto del soddisfacimento, l'azione viene impedita
					* e viene notificato che e' presa in gestione da un altro operatore.
					*/
					$requestLibrarianId = intval($item_request->getLibrarianId());
					if ($requestLibrarianId > 0)
					{
						if (($requestLibrarianId != $clavisLibrarian->getId()) &&
							($item_request->getRequestStatus() == ItemRequestPeer::STATUS_WORKING))
						return self::RSV_ALREADYMANAGED;
					}

					$item_action = new ItemAction();
					$item_action->setActionDate($currentTime);
					$item_action->setActionType(ItemActionPeer::TYPE_MANAGEREQUEST); //'Prenotazione'
					$item_action->setItemId($item->getItemId());

					$item_action->setPatron($patron);
					$item_action->setExternalLibrary($externalLibrary);

					$librarian_id = $clavisLibrarian->getId();
					if (!is_null($librarian_id) && is_numeric($librarian_id) && ($librarian_id > 0))
						$item_action->setLibrarianId($librarian_id);

					//library_id
					$library_id = $clavisLibrarian->getActualLibraryId();
					if ($library_id != null)
						$item_action->setLibraryId($library_id);

					$from_library_id = $item->getActualLibraryId();
					if ($from_library_id != null)
						$item_action->setFromLibraryId($from_library_id);

					$to_library_id = $deliveryLibrary->getLibraryId();
					if ($to_library_id != null)
						$item_action->setToLibraryId($to_library_id);

					$item_action->save();

					//item edit
					$item->setCurrentLoanId(null);
					$item->setCheckIn(null);
					$item->setCheckOut(null);
					$item->setIllTimestamp($item_request->getRequestDate());
					$item->setRenewalCount(0);
					$item->setNotifyCount(0);
					$item->setDueDate(null); //NB viene settato dalla DoReadyToLoan2LoanItem()

					$item->setPatron($patron);
					$item->setExternalLibrary($externalLibrary);

					$delivery_library_id = $deliveryLibrary->getLibraryId();
					if ($delivery_library_id != null)
						$item->setDeliveryLibraryId($delivery_library_id);

					$item->save();

					//item_request edit
					if (is_null($item_request->getItemId()))
						$item_request->setItemId($item->getItemId());

					$item_request->setRequestStatus(ItemRequestPeer::STATUS_DONE); //'Soddisfatta'
					ChangelogPeer::logAction($item_request, ChangelogPeer::LOG_UPDATE, $clavisLibrarian,
								Prado::localize("Nell'iniziare il meccanismo di interprestito dell'esemplare con id: {item_id} e' stata automaticamente soddisfatta la prenotazione con id: {request_id}",
													array('item_id' => $item->getItemId(), 'request_id' => $item_request->getRequestId())));
					$item_request->save();


					// Per far scattare subito a "pronti per il transito", senza passare per l'ILL request.
					$returnValue = self::DoILL2ReadyToMoveItem($item, $clavisLibrarian, $item_request->getRequestId());

					if ($returnValue == self::OK)
						return self::LOAN_ILLREQUESTED;
					else
						return $returnValue;
				}
			}
			else
			{
				//PRESTITO SEMPLICE (non interbibliotecario)

				if (self::IsItemAvailable($item, $deliveryLibrary->getLibraryId(), $loanObject) != self::OK)	// not available
                {
					//	item is not available: an item_request gets created

					if (!is_null($manifestation))
						$reserveExitCode = ClavisRequestManager::isManifestationReservable(	$manifestation,
																							null,
																							$loanObject,
																							$externalLibraryId );
					else
						$reserveExitCode = null;

					if ($reserveExitCode == self::OK)
					{
						$item_request = new ItemRequest();
						$item_request->setRequestStatus(ItemRequestPeer::STATUS_PENDING); //'Pendente'
						$item_request->setItemId($item->getItemId());
						$item_request->setManifestationId($manifestationId);

						$item_request->setPatron($patron);
						$item_request->setExternalLibrary($externalLibrary);

						$item_request->setRequestDate($currentTime);
						$item_request->setDeliveryLibraryId($deliveryLibrary->getLibraryId());
						$expireDate = self::CalculateExpireDate($item_request, $item, $patron);
						if ($expireDate != -1)
							$item_request->setExpireDate($expireDate);
						else
							throw new Exception('Expire date not set');

						$item_request->save();

						//edit patron last_seen for statistics
						if (!is_null($patron))
							$patron->UpdateLastSeen(true);

						return self::LOAN_RESERVED;
					} else {
						switch($reserveExitCode) {

							case self::RSV_PATRONREQMANIF :
								return self::LOAN_ALREADYRESERVED;
								break;

							case self::RSV_PATRONMAXREQ :
							case self::RSV_NOTAVAIL :
							default:
								return self::LOAN_NOTRESERVABLE;
						        break;
						}
					}
				}
				else
				{	// item is available --> immediate loan
					$item->setCheckOut($currentTime);

					if (is_null($item_request))
					{
						/**
						 * Fix del problema di concorrenza di presa in gestione fra operatori allo stesso tempo:
						 * ora viene controllato,anche in assenza di passaggio di $item_request da parametri, nella DoLoanItem()
						 */
						if (!self::checkCorrectManagedRequests(	$item->getItemId(),
																$clavisLibrarian->getId(),
																$patron->getPatronId(),
																$externalLibraryId ))
							return self::RSV_ALREADYMANAGED;

						/**
						 * Siamo nel caso in cui si esegua un prestito immediato
						 * direttamente all'utente che ha quest'esemplare in
						 * pronto al prestito, e quindi non dev'essere generato
						 * un altro loan ma riusato quello esistente.
						 */
						$consultationFlag = $item->isStatusConsultation();

						$loan = $item->getCurrentLoan();
						if (is_null($loan) || in_array($loan->getLoanStatus(), ItemPeer::getLoanStatusInactive()))
						{
							$loan = new Loan();   /// problema dei loan mancanti, 29-11-2007
							$loan->setItemId($item->getItemId());
							$loan->setItemOwnerLibraryId($item->getOwnerLibraryId());
							$loan->setItemHomeLibraryId($item->getHomeLibraryId());

							if ($consultationFlag)
								$loan->setLoanType(ItemPeer::LOANTYPE_CONSULTATION);
							elseif ($isExtra || $isExternal)
								$loan->setLoanType(ItemPeer::LOANTYPE_EXTRASYSTEM);
							else
								$loan->setLoanType(($item->getHomeLibraryId() == $myLibraryId)
														? ItemPeer::LOANTYPE_LOCAL
														: ItemPeer::LOANTYPE_INTRASYSTEM);

							$loan->setPatron($patron);
							$loan->setExternalLibrary($externalLibrary);

							if ($isExtra)
								$loan->setDestinationName($externalLibrary->getLabel());
							else
								$loan->setDestinationName($patron->getCompleteName());

							$loan->setTitle($item->getTitle());
							$loan->setManifestationId($manifestationId);
							if (!is_null($manifestation))
								$loan->setClassCode($manifestation->getClass());
							$loan->setInvNumber($item->getInventorySerieId() . "-" . $item->getInventoryNumber());
							$loan->setCollocation($item->getCollocation());
							$loan->setItemMedia($item->getItemMedia());
							$loan->setFromLibrary($item->getActualLibraryId());
							$loan->setToLibrary($deliveryLibrary->getLibraryId());
							$loan->setItemInventoryDate($item->getInventoryDate('U'));
							$loan->setMediapackageSize($item->getMediapackageSize());
							//new: manage statistic fields
							$loan = self::updateLoanForStatistics($loan, $patron, $item);
						}

						if ($consultationFlag)
							$inLoanStatus = ItemPeer::LOANSTATUS_INCONSULTATION;
						else
							$inLoanStatus = ItemPeer::LOANSTATUS_INLOAN;

						$loan->setLoanStatus($inLoanStatus); //'In prestito'
						$loan->setLoanDateBegin($item->getCheckOut());
						$loan->setLoanDateEnd(null);
						$loan->setEndLibrary(null);  //to be set in return item

						$loan->setRenewCount(0);
						$loan->setNotifyCount(0);
						$loan->setNotifyAutoCount(0);
						if (is_null($dueDate))
							$dueDate = self::CalculateDueDate($item, $patron);
						
						if ($dueDate == self::CALCULATEDATE_ERROR)
							self::throwCalculateDueDateError();
						
						$loan->setDueDate($dueDate);
						$loan->setItemrequestId(null);
						$loan->save();

						//item edit
						$item->setLoanStatus($inLoanStatus);	 //'In prestito'
						$item->setCurrentLoanId($loan->getLoanId());
						$item->setCheckIn(null);
						$item->setRenewalCount(0);
						$item->setNotifyCount(0);
						$item->setDueDate($dueDate);
						$item->setPatron($patron);
						$item->setExternalLibrary($externalLibrary);
						$item->setLastSeen($currentTime);

						$delivery_library_id = $deliveryLibrary->getLibraryId();
						if ($delivery_library_id != null)
							$item->setDeliveryLibraryId($deliveryLibrary->getLibraryId());

						$item->save();

						//insert item_action
						$item_action = new ItemAction();
						$item_action->setActionDate($currentTime);
						if ($consultationFlag)
							$item_action->setActionType(ItemActionPeer::TYPE_CONSULTATION); // 'consultazione'
						else
							$item_action->setActionType(ItemActionPeer::TYPE_LOAN); //'Prestito'

						$item_action->setItemId($item->getItemId());
						$item_action->setPatron($patron);
						$item_action->setExternalLibrary($externalLibrary);

						$librarian_id = $clavisLibrarian->getId();
						if ($librarian_id != null)
							$item_action->setLibrarianId($librarian_id);

						//library_id (biblioteca dalla quale parte la richiesta
						$library_id = $clavisLibrarian->getActualLibraryId();
						if ($library_id != null)
							$item_action->setLibraryId($library_id);

						$from_library_id = $item->getActualLibraryId();
						if ($from_library_id != null)
							$item_action->setFromLibraryId($from_library_id );

						$to_library_id = $deliveryLibrary->getLibraryId();
						if ($to_library_id != null)
							$item_action->setToLibraryId($to_library_id );

						$item_action->save();

						//ricerca eventuali prenotazioni
                        $itemRequest = ItemRequestQuery::create()
                            ->filterByPatron($patron)
                            ->filterByItem($item)
                            ->filterByRequestStatus(ItemRequestPeer::getActiveStatus())
                            ->findOne();

                        if($itemRequest == null && $manifestation instanceof Manifestation) {
                            $itemRequest = ItemRequestQuery::create()
                                ->filterByPatron($patron)
                                ->filterByManifestation($manifestation)
                                ->_if($item->getIssueId() > 0)
                                    ->filterByIssueId($item->getIssueId())
                                ->_endIf()
                                ->where('ItemRequest.ItemId IS NULL')
                                ->filterByRequestStatus(ItemRequestPeer::getActiveStatus())
                                ->findOne();
                        }

                        if($itemRequest instanceof ItemRequest)
						{
							if ($itemRequest->getItemId() == null)
								$itemRequest->setItemId($item->getItemId());

							$itemRequest->setRequestStatus(ItemRequestPeer::STATUS_DONE); //'Soddisfatta'
							ChangelogPeer::logAction($itemRequest, ChangelogPeer::LOG_UPDATE, $clavisLibrarian,
										Prado::localize("Nel prestito immediato dell'esemplare con id: {item_id} e' stata automaticamente soddisfatta la prenotazione con id: {request_id}",
												array('item_id' => $item->getItemId(), 'request_id' => $itemRequest->getRequestId())));
							$itemRequest->save();
						}

						$returnExitCode = self::LOAN_LOANED;
					}
					else   // non prestito immediato, ma pronto al prestito
					{
						/** 05/11/2009, per eliminare casi in cui una cattiva concorrenza
						 * abbia fatto si che piu' di un operatore creda di avere preso in gestione
						 * una prenotazione: all'atto del soddisfacimento, l'azione viene impedita
						 * e viene notificato che e' presa in gestione da un altro operatore.
						 */
						$requestLibrarianId = intval($item_request->getLibrarianId());
						if ($requestLibrarianId > 0
								&& $requestLibrarianId != $clavisLibrarian->getId()
								&& $item_request->getRequestStatus() == ItemRequestPeer::STATUS_WORKING)
							return self::RSV_ALREADYMANAGED;

						$currentLoan = $item->getCurrentLoan();
						if (!is_null($currentLoan)
								&& in_array($currentLoan->getLoanStatus(), ItemPeer::getLoanStatusActive()))
							return self::LOAN_LOANALREADYEXISTS;

						$loan = new Loan();
						$loan->setItemId($item->getItemId());
						$loan->setItemOwnerLibraryId($item->getOwnerLibraryId());
						$loan->setItemHomeLibraryId($item->getHomeLibraryId());
						$loan->setLoanStatus(ItemPeer::LOANSTATUS_READYFORLOAN); // pronto al prestito
						$loan->setPatron($patron);
						$loan->setExternalLibrary($externalLibrary);
						$loan->setTitle($item->getTitle());
						$loan->setManifestationId($manifestationId);
						if (!is_null($manifestation))
							$loan->setClassCode($manifestation->getClass());
						$loan->setInvNumber($item->getInventorySerieId()."-".$item->getInventoryNumber());
						$loan->setCollocation($item->getCollocation());
						$loan->setItemMedia($item->getItemMedia());
						$loan->setLoanDateBegin(null);   //($item->getCheckOut());
						$loan->setLoanDateEnd(null);
						$loan->setFromLibrary($item->getActualLibraryId());
						$loan->setToLibrary($deliveryLibrary->getLibraryId());
						$loan->setEndLibrary(null);  //to be set in return item
						$loan->setRenewCount(0);
						$loan->setNotifyCount(0);
						$loan->setNotifyAutoCount(0);
						$loan->setDueDate(null);
						$loan->setItemInventoryDate($item->getInventoryDate('U'));
						$loan->setItemrequestId($item_request->getRequestId());
						$loan->setMediapackageSize($item->getMediapackageSize());

						if ($isExtra)
						{
							$loan->setLoanType(ItemPeer::LOANTYPE_EXTRASYSTEM);
							$loan->setDestinationName($externalLibrary->getLabel());
							// if the item is to be sent to extra library and it isn't ours
							// (it was in extra loan, ready to return home)
							// override from library
							if ($this->getExtraSystemNodeLibraryId() == 0)
								$loan->setFromLibrary($item->getHomeLibraryId());
						}
						else if ($isExternal)
						{
							$loan->setLoanType(ItemPeer::LOANTYPE_EXTRASYSTEM);
						}
						else
						{
							$loan->setLoanType(($item->getHomeLibraryId() == $myLibraryId)
												? ItemPeer::LOANTYPE_LOCAL
												: ItemPeer::LOANTYPE_INTRASYSTEM);
							$loan->setDestinationName($patron->getCompleteName());
						}

						// manage statistic fields
						$loan = $this->updateLoanForStatistics($loan, $patron, $item);
						$loan->save();

						//item edit
						$item->setLoanStatus(ItemPeer::LOANSTATUS_READYFORLOAN);
						$item->setCurrentLoanId($loan->getLoanId());
						$item->setCheckIn(null);
						$item->setRenewalCount(0);
						$item->setNotifyCount(0);
						$item->setDueDate(null);
						$item->setPatron($patron);
						$item->setExternalLibrary($externalLibrary);
						$item->setLastSeen($currentTime);
						$delivery_library_id = $deliveryLibrary->getLibraryId();
						if ($delivery_library_id != null)
							$item->setDeliveryLibraryId($delivery_library_id);
						$item->save();

						//insert item_action
						$item_action = new ItemAction();
						$item_action->setActionDate($currentTime);
						$item_action->setActionType(ItemActionPeer::TYPE_READYFORLOAN);
						$item_action->setItemId($item->getItemId());
						$item_action->setPatron($patron);
						$item_action->setExternalLibrary($externalLibrary);
						$librarian_id = $clavisLibrarian->getId();
						if ($librarian_id != null)
							$item_action->setLibrarianId($librarian_id);
						$library_id = $clavisLibrarian->getActualLibraryId();
						if ($library_id != null)
							$item_action->setLibraryId($library_id);
						$from_library_id = $item->getActualLibraryId();
						if ($from_library_id != null)
							$item_action->setFromLibraryId($from_library_id);
						$to_library_id = $deliveryLibrary->getLibraryId();
						if ($to_library_id != null)
							$item_action->setToLibraryId($to_library_id );
						$item_action->save();

                        // Make Item_request DONE
                        $item_request->setRequestStatus(ItemRequestPeer::STATUS_DONE);
                        $item_request->setItemId($item->getItemId());
                        $item_request->save();

                        ChangelogPeer::logAction($item_request, ChangelogPeer::LOG_UPDATE, $clavisLibrarian,
                            Prado::localize("Nella messa in pronto al prestito dell'esemplare con id: {item_id} e' stata automaticamente soddisfatta la prenotazione con id: {request_id}",
                                array('item_id' => $item->getItemId(), 'request_id' => $item_request->getRequestId())));

						//ricerca eventuali prenotazioni
						// verifica di cancellazione delle richieste
/*
						$ir = ItemRequestQuery::create()
							->filterByRequestStatus(ItemRequestPeer::getActiveStatus());

						if ($manifestation instanceof Manifestation)
							$ir->filterByManifestation($manifestation);
						else
							$ir->filterByItem($item);

						if ($patron instanceof Patron)
							$ir->filterByPatron($patron);
						else if ($externalLibrary instanceof Library)
							$ir->filterByLibraryRelatedByExternalLibraryId($externalLibrary);

						if ($item->getIssueId() > 0)
							$ir->filterByIssueId($item->getIssueId());

						foreach ($ir->find() as $itemRequest)
						{
							if ($itemRequest->getItemId() == null)
								$itemRequest->setItemId($item->getItemId());

							$itemRequest->setRequestStatus(ItemRequestPeer::STATUS_DONE);
							ChangelogPeer::logAction($itemRequest, ChangelogPeer::LOG_UPDATE, $clavisLibrarian,
										Prado::localize("Nella messa in pronto al prestito dell'esemplare con id: {item_id} e' stata automaticamente soddisfatta la prenotazione con id: {request_id}",
												array('item_id' => $item->getItemId(), 'request_id' => $itemRequest->getRequestId())));
							$itemRequest->save();
						}
*/
						$returnExitCode = self::LOAN_READYTOLOAN;
					}
					//edit patron last_seen for statistics
					if (!is_null($patron))
						$patron->UpdateLastSeen(true);

					return $returnExitCode;
				} //end else(immediato)
			} //end else(interbibliotecario)

			return self::ERROR;
		}
		catch (Exception $e)
		{

			return self::ERROR;
		}
	}

	public function DoForcedLoanItem($item, $patron, $clavisLibrarian, $forceInLoanOnly = false, $dueDate = null)
	{
		if (!($item instanceof Item) || !($patron instanceof Patron) || !($clavisLibrarian instanceof ClavisLibrarian))
			return false;

		$myLibraryId = $clavisLibrarian->getActualLibraryId();
		$myLibrary = $clavisLibrarian->getActualLibrary();
		if (!($myLibrary instanceof Library))
			return false;

		if ($dueDate != null)
		{
			if(!is_numeric($dueDate))
				return false;
		}

		if ($forceInLoanOnly)
		{
			if ($item->IsLoaned($patron))
					return false;
		}
		else
		{
			if (self::IsItemAvailable($item, $myLibraryId, $patron) != self::OK)	// if not available
				return false;
		}

		try
		{
			$currentTime = time();
			$manifestation = $item->getManifestation();
			$manifestationId = $item->getManifestationId();

			$item->setCheckOut($currentTime);

			$loan = $item->getCurrentLoan();
			if (is_null($loan) || in_array($loan->getLoanStatus(), ItemPeer::getLoanStatusInactive()))
			{
				$loan = new Loan();
				$loan->setItemId($item->getItemId());
				$loan->setItemOwnerLibraryId($item->getOwnerLibraryId());
				$loan->setItemHomeLibraryId($item->getHomeLibraryId());

				$loan->setLoanType(($item->getHomeLibraryId() == $myLibraryId)
										? ItemPeer::LOANTYPE_LOCAL
										: ItemPeer::LOANTYPE_INTRASYSTEM);

				$loan->setPatron($patron);
				$loan->setExternalLibrary(null);

				$loan->setDestinationName($patron->getCompleteName());

				$loan->setTitle($item->getTitle());
				$loan->setManifestationId($manifestationId);
				if (!is_null($manifestation))
					$loan->setClassCode($manifestation->getClass());

				$loan->setInvNumber($item->getInventorySerieId() . "-" . $item->getInventoryNumber());
				$loan->setCollocation($item->getCollocation());
				$loan->setItemMedia($item->getItemMedia());
				$loan->setFromLibrary($item->getActualLibraryId());
				$loan->setToLibrary($myLibrary->getLibraryId());
				$loan->setItemInventoryDate($item->getInventoryDate('U'));
				$loan->setMediapackageSize($item->getMediapackageSize());
				$loan = self::updateLoanForStatistics($loan, $patron, $item);
			}

			$inLoanStatus = ItemPeer::LOANSTATUS_INLOAN;

			$loan->setLoanStatus($inLoanStatus); //'In prestito'
			$loan->setLoanDateBegin($item->getCheckOut());
			$loan->setLoanDateEnd(null);
			$loan->setEndLibrary(null);  //to be set in return item

			$loan->setRenewCount(0);
			$loan->setNotifyCount(0);
			$loan->setNotifyAutoCount(0);
			if (is_null($dueDate))
				$dueDate = self::CalculateDueDate($item, $patron);
			if ($dueDate == self::CALCULATEDATE_ERROR)
				return false; //self::throwCalculateDueDateError();
			$loan->setDueDate($dueDate);

			$loan->setItemrequestId(null);
			$loan->save();

			//item edit
			$item->setLoanStatus($inLoanStatus);	 //'In prestito'
			$item->setCurrentLoanId($loan->getLoanId());
			$item->setCheckIn(null);
			$item->setRenewalCount(0);
			$item->setNotifyCount(0);
			$item->setDueDate($dueDate);
			$item->setPatron($patron);
			$item->setExternalLibrary(null);
			$item->setLastSeen($currentTime);

			$delivery_library_id = $myLibrary->getLibraryId();
			if ($delivery_library_id != null)
				$item->setDeliveryLibraryId($myLibrary->getLibraryId());

			$item->save();

			//insert item_action
			$item_action = new ItemAction();
			$item_action->setActionDate($currentTime);
				$item_action->setActionType(ItemActionPeer::TYPE_LOAN); //'Prestito'

			$item_action->setItemId($item->getItemId());
			$item_action->setPatron($patron);
			$item_action->setExternalLibrary(null);

			$librarian_id = $clavisLibrarian->getId();
			if ($librarian_id != null)
				$item_action->setLibrarianId($librarian_id);

			//(biblioteca dalla quale parte la richiesta
			$item_action->setLibraryId($myLibraryId);

			$from_library_id = $item->getActualLibraryId();
			if ($from_library_id != null)
				$item_action->setFromLibraryId($from_library_id );

			$to_library_id = $myLibrary->getLibraryId();
			if ($to_library_id != null)
				$item_action->setToLibraryId($to_library_id );

			$item_action->setActionNote(Prado::localize('prestito forzato, da SOAP'));
			$item_action->save();

			$itemRequest = ItemRequestQuery::create()
                ->filterByPatron($patron)
                ->filterByItem($item)
                ->filterByRequestStatus(ItemRequestPeer::getActiveStatus())
                ->findOne();

            if($itemRequest == null && $manifestation instanceof Manifestation) {
                $itemRequest = ItemRequestQuery::create()
                    ->filterByPatron($patron)
                    ->filterByManifestation($manifestation)
                    ->filterByManifestation($manifestation)
                    ->_if($item->getIssueId() > 0)
                        ->filterByIssueId($item->getIssueId())
                    ->_endIf()
                    ->where('ItemRequest.ItemId IS NULL')
                    ->filterByRequestStatus(ItemRequestPeer::getActiveStatus())
                    ->findOne();
            }

			if($itemRequest instanceof ItemRequest)
			{
				if ($itemRequest->getItemId() == null)
					$itemRequest->setItemId($item->getItemId());

				$itemRequest->setRequestStatus(ItemRequestPeer::STATUS_DONE); //'Soddisfatta'
				ChangelogPeer::logAction($itemRequest, ChangelogPeer::LOG_UPDATE, $clavisLibrarian,
							Prado::localize("Nel prestito immediato forzato dell'esemplare con id: {item_id} e' stata automaticamente soddisfatta la prenotazione con id: {request_id}",
									array('item_id' => $item->getItemId(), 'request_id' => $itemRequest->getRequestId())));
				$itemRequest->save();
			}

			return true;
		}
		catch (Exception $e)
		{
			$e = $e;
     		//throw $e;
     		return false;
		}
	}

	public function checkCorrectManagedRequests($itemId = null, $clavisLibrarianId = null, $patronId = null, $externalLibraryId = null)
	{
		$return = false;
		$criteria = new Criteria();

		$itemId = intval($itemId);
		$clavisLibrarianId = intval($clavisLibrarianId);
		$patronId = intval($patronId);
		$externalLibraryId = intval($externalLibraryId);
		if ((($externalLibraryId + $patronId) == 0) || ($clavisLibrarianId == 0) || ($itemId == 0))
			return false;

		$crit1 = $criteria->getNewCriterion(ItemRequestPeer::ITEM_ID, $itemId);
		$item = ItemQuery::create()->findPK($itemId);
		if ($item instanceof Item)
		{
			$manifestationId = intval($item->getManifestationId());
			if ($manifestationId > 0)
			{
				$crit2 = $criteria->getNewCriterion(ItemRequestPeer::MANIFESTATION_ID, $manifestationId);
				$crit1->addOr($crit2);
			}
		}
		$criteria->add($crit1);

		if ($patronId > 0)
			$criteria->addAnd(ItemRequestPeer::PATRON_ID, $patronId);
		elseif ($externalLibraryId > 0)
			$criteria->addAnd(ItemRequestPeer::EXTERNAL_LIBRARY_ID, $externalLibraryId);

		$criteria->addAnd(ItemRequestPeer::REQUEST_STATUS, ItemRequestPeer::STATUS_WORKING);
		$criteria->addAnd(ItemRequestPeer::LIBRARIAN_ID, $clavisLibrarianId, Criteria::NOT_EQUAL);

		$count = ItemRequestPeer::doCount($criteria);
		if ($count == 0)
			$return = true;

		return $return;
  }

    /**
	 * Return of an item
	 *
	 * @param Item $item
	 * @param Patron $patron
	 * @param ClavisLibrarian $clavisLibrarian
	 *
	 * @return int (enumerated) :
	 * 		   self::OK : true
	 *         self::ERROR : generic error
	 *
	 * 		   self::RETN_PATRONREQUEST : it exists (at least) a reservation for the item returned
	 *
	 */
	public function DoReturnItem($item, $patron, $clavisLibrarian)
	{
 		if (!($item instanceof Item))
			return self::ERROR;

		if (is_null($clavisLibrarian))
			$clavisLibrarian = $this->getUser();
		if (!($clavisLibrarian instanceof ClavisLibrarian))
			return self::ERROR;

		if ($item->getLoanStatus() == ItemPeer::LOANSTATUS_INLOANEXTRA)
			return self::doReturnItemExtra($item->getItemId(), $clavisLibrarian);

		if ($item->getLoanStatus() == ItemPeer::LOANSTATUS_INTRANSITTOEXTRA)
			return self::doExtraGoHome($item, $clavisLibrarian);

		$patronId = 0;
		if ($patron != null)
		{
			if (!$patron instanceof Patron)
				return self::ERROR;
			else
				$patronId = $patron->getPatronId();
		}
		else
		{
			$patronId = $item->getPatronId();
			if (is_null($patronId))
				return self::ERROR;
		}

		try
		{
			$myLibraryId = $clavisLibrarian->getActualLibraryId();
			$currentTime = time();
			$consultationFlag = $item->isStatusConsultation();

			$item->setCheckIn($currentTime);
			$extraSystem = false;

			//loan table update
			$loan = LoanQuery::create()
						->findPK($item->getCurrentLoanId());
			if ($loan instanceof Loan)
			{
				$extraSystem = ($loan->getLoanType() == ItemPeer::LOANTYPE_EXTRASYSTEM);
				$loan->setLoanStatus(ItemPeer::LOANSTATUS_CLOSED); //'Concluso'
				$loan->setLoanDateEnd($item->getCheckIn());
				$loan->setEndLibrary($clavisLibrarian->getActualLibraryId());
				$loan->setRenewCount($item->getRenewalCount());
				$loan->setNotifyCount($item->getNotifyCount());
				$loan->save();
			}

			if ($extraSystem)
			{
				/// check a scopo correttivo di cattive importazioni di prestiti extra
				$nodeLibraryId = $this->getExtraSystemNodeLibraryId();
				if ($nodeLibraryId > 0)
				{
					if ($item->getHomeLibraryId() != $nodeLibraryId)
					{
						$item->setHomeLibraryId($nodeLibraryId);

						ChangelogPeer::logAction($item,
								ChangelogPeer::LOG_UPDATE,
								$clavisLibrarian,
								"Aggiornamento home_library alla biblioteca nodo (id: {$nodeLibraryId}) ".
								"per incongruenza da importazione (caso prestito extra-sistema)");
					}
				}
				else
				{
					if ($item->getHomeLibraryId() != $myLibraryId)
					{
						$item->setHomeLibraryId($myLibraryId);

						ChangelogPeer::logAction($item,
								ChangelogPeer::LOG_UPDATE,
								$clavisLibrarian,
								"Aggiornamento home_library alla biblioteca attuale (id: {$myLibraryId}) ".
								"per incongruenza da importazione (caso prestito extra-sistema)");
					}
				}
			}

			//item_action table
			$item_action = new ItemAction();
			$item_action->setActionDate($currentTime);

			if ($consultationFlag)
				$item_action->setActionType(ItemActionPeer::TYPE_CONSULTRETURN);
			elseif ($item->isExternal())
				$item_action->setActionType(ItemActionPeer::TYPE_EXTRAGOHOME); //'Rientro verso extra'
			else
				$item_action->setActionType(ItemActionPeer::TYPE_RETURN); //'Rientro'
			$item_action->setItemId($item->getItemId());
			if ($patronId > 0)
				$item_action->setPatronId($patronId);

			$library_id = $clavisLibrarian->getActualLibraryId();
			if ($library_id != null)
				$item_action->setLibraryId($library_id);

			$librarian_id = $clavisLibrarian->getId();
			if ($librarian_id != null)
				$item_action->setLibrarianId($librarian_id);

			$item_action->save();

			//edit patron last_seen for statistics
			if ($patronId > 0)
			{
				$patron = PatronQuery::create()->findPK($patronId);
				if (!is_null($patron))
					$patron->UpdateLastSeen(true);
			}

			if ($item->getHomeLibraryId() == $myLibraryId)    // se il prestito era interno
			{
				// => chiudo il prestito e metto disponibile l'item
				if ($item->isExternal())
					$item->setLoanStatus(ItemPeer::LOANSTATUS_INTRANSITTOEXTRA); // 'Da tornare nel suo extrasistema'
				else
					$item->setLoanStatus(ItemPeer::LOANSTATUS_AVAILABLE); //'Disponibile'

				$item->setActualLibraryId($myLibraryId);
				$item->setCheckOut(null);
				$item->setLastSeen($currentTime);
				$item->setDueDate(null);
				$item->setPatronId(null);
				$item->setExternalLibraryId(null);
				$item->setIllTimestamp(null);
				$item->setUsageCount($item->getUsageCount() + 1);
				$item->setRenewalCount(0);
				$item->setNotifyCount(0);
				$item->setCurrentLoanId(null); //DA NON SBIANCARE, per sapere l'ultimo prestito che ho fatto e quindi in che biblioteca e' rientrato (per semplificare la gestione delle prenotazioni senza rientrare alla actuallibrary...), quindi in realta' e' un 'last' e non 'current'

				$item->save();
			}
			else    // il prestito era interbibliotecario, e adesso deve essere movimentato in un'altra biblioteca
			{
				//la bibl. di rientro e' diversa dalla bibl. home del libro
				// => movimentazione di rientro //TBV

				//new 20/02/07: per gestire il prestito in rientro non basta piu'
				$item->setLoanStatus(ItemPeer::LOANSTATUS_READYFORTRANSITTOHOME); //'Pronto al transito di rientro'
				$item->setCheckOut(null);
				$item->setLastSeen($currentTime);
				$item->setDueDate(null);
				$item->setPatronId(null);
				$item->setExternalLibraryId(null);
				$item->setUsageCount($item->getUsageCount() + 1);
				$item->setRenewalCount(0);
				$item->setNotifyCount(0);

				//NEW: biblioteca di rientro
				$item->setActualLibraryId($myLibraryId); //e' l'attuale biblioteca nel passaggio di rientro
				$item->setCurrentLoanId(null); //DA NON SBIANCARE, per sapere l'ultimo prestito che ho fatto e quindi in che biblioteca e' rientrato (per semplificare la gestione delle prenotazioni senza rientrare alla actuallibrary...), quindi in realta' e' un 'last' e non 'current'
				$item->setDeliveryLibraryId($item->getHomeLibraryId());   // by mbrancalion

				$item->save();

				//item_action table
				$item_action = new ItemAction();
				$item_action->setActionDate($currentTime);
				$item_action->setActionType(ItemActionPeer::TYPE_READYFORTRANSIT);   //'Pronto al transito'
				$item_action->setItemId($item->getItemId());
				$item_action->setPatronId(null);

				//librarian (doing the action) current infos
				$librarian_id = $clavisLibrarian->getId();
				if ($librarian_id != null)
					$item_action->setLibrarianId($librarian_id);
				//
				$library_id = $clavisLibrarian->getActualLibraryId();
				if ($library_id != null)
					$item_action->setLibraryId($library_id);
				//
				$from_library_id = $item->getActualLibraryId();
				if ($from_library_id != null)
					$item_action->setFromLibraryId($from_library_id);

				$to_library_id = $item->getHomeLibraryId();
				if ($to_library_id != null)
					$item_action->setToLibraryId($to_library_id);

				$item_action->save();
			}

            $rm = Prado::getApplication()->getModule("request");

			if ($rm->isRequested($item))
				return self::RETN_PATRONREQUEST;
			else
				return self::OK;
		}
		catch (Exception $e)
		{
			$e = $e;
			//throw $e;
			return self::ERROR;
		}

    }

    /**
	 * It makes an item return from an extra system loan
	 *
	 * @param Item $item
	 * @param ClavisLibrarian $clavisLibrarian
	 *
	 * @return int (enumerated) :
	 * 		   self::OK : true
	 *         self::ERROR : generic error
	 *
	 * 		   self::RETN_PATRONREQUEST : it exists (at least) a reservation for the item returned
	 *
	 */
    public function doReturnItemExtra($itemId, $clavisLibrarian)
	 {
		$item = ItemQuery::create()->findPK($itemId);
		if (!($item instanceof Item))
			return self::ERROR;

		if (is_null($clavisLibrarian))
			$clavisLibrarian = $this->getUser();
		if (!($clavisLibrarian instanceof ClavisLibrarian))
			return self::ERROR;

		try
		{
			$currentTime = time();
			$item->setCheckIn($currentTime);

			//loan table update
			$fromLibrary = null;
			$toLibrary = null;

			$loan = LoanQuery::create()->findPK($item->getCurrentLoanId());
			if (!is_null($loan))
			{
				$fromLibrary = $loan->getFromLibrary();
				$toLibrary = $loan->getToLibrary();

				$loan->setLoanStatus(ItemPeer::LOANSTATUS_CLOSED); //'Concluso'
				$loan->setLoanDateEnd($item->getCheckIn());
				$loan->setEndLibrary($clavisLibrarian->getActualLibraryId());  //to be set in return
				$loan->setRenewCount($item->getRenewalCount());	 //to be set in return
				$loan->setNotifyCount($item->getNotifyCount()); //to be set in return
				$loan->setDueDate(null);

				/////  $loan->setItemId(null);   // sbiancamento item    ciro dice di no
				$loan->save();
			}

			//item_action table
			$item_action = new ItemAction();
			$item_action->setFromLibraryId($toLibrary);
			$item_action->setToLibraryId($fromLibrary);

			$item_action->setActionDate($currentTime);
			$item_action->setActionType(ItemActionPeer::TYPE_EXTRARETURN);
			$item_action->setItemId($item->getItemId());
			$item_action->setPatronId(null);

			$library_id = $clavisLibrarian->getActualLibraryId();
			if ($library_id != null)
				$item_action->setLibraryId($library_id);

			$librarian_id = $clavisLibrarian->getId();
			if ($librarian_id != null)
				$item_action->setLibrarianId($librarian_id);

			$item_action->save();

			// parte relativa all'item table
			if ($item->getHomeLibraryId() == $clavisLibrarian->getActualLibraryId())    // se il prestito era interno
			{
				$item->setLoanStatus(ItemPeer::LOANSTATUS_AVAILABLE); //'Disponibile'
				$item->setCheckOut(null);
				$item->setLastSeen($currentTime);
				$item->setDueDate(null);
				$item->setPatronId(null);
				$item->setExternalLibraryId(null);
				$item->setIllTimestamp(null);
				$item->setUsageCount($item->getUsageCount() + 1);
				$item->setRenewalCount(0);
				$item->setNotifyCount(0);
				$item->setCurrentLoanId(null); //DA NON SBIANCARE, per sapere l'ultimo prestito che ho fatto e quindi in che biblioteca e' rientrato (per semplificare la gestione delle prenotazioni senza rientrare alla actuallibrary...), quindi in realta' e' un 'last' e non 'current'
				$item->setActualLibraryId($item->getHomeLibraryId());

				$item->save();
			}
			else    // il prestito era interbibliotecario, e adesso deve essere movimentato in un'altra biblioteca
			{
				//la bibl. di rientro e' diversa dalla bibl. home del libro
				$item->setLoanStatus(ItemPeer::LOANSTATUS_READYFORTRANSITTOHOME); //'Pronto al transito di rientro'
				$item->setCheckOut(null);
				$item->setLastSeen($currentTime);
				$item->setDueDate(null);
				$item->setPatronId(null);
				$item->setExternalLibraryId(null);
				$item->setUsageCount($item->getUsageCount() + 1);
				$item->setRenewalCount(0);
				$item->setNotifyCount(0);

				//NEW: libreria di rientro
				$item->setActualLibraryId($clavisLibrarian->getActualLibraryId()); //e' l'attuale biblioteca nel passaggio di rientro
				$item->setCurrentLoanId(null); //DA NON SBIANCARE, per sapere l'ultimo prestito che ho fatto e quindi in che biblioteca e' rientrato (per semplificare la gestione delle prenotazioni senza rientrare alla actuallibrary...), quindi in realta' e' un 'last' e non 'current'
				$item->setDeliveryLibraryId($item->getHomeLibraryId());   // by mbrancalion
				$item->save();

				//item_action table
				$item_action = new ItemAction();
				$item_action->setActionDate($currentTime);
				$item_action->setActionType(ItemActionPeer::TYPE_READYFORTRANSIT);   //'Pronto al transito'
				$item_action->setItemId($item->getItemId());
				$item_action->setPatronId(null);

				//librarian (doing the action) current infos
				$librarian_id = $clavisLibrarian->getId();
				if ($librarian_id != null)
					$item_action->setLibrarianId($librarian_id);

				$library_id = $clavisLibrarian->getActualLibraryId();
				if ($library_id != null)
					$item_action->setLibraryId($library_id);

				$from_library_id = $item->getActualLibraryId();
				if ($from_library_id != null)
					$item_action->setFromLibraryId($from_library_id);

				$to_library_id = $item->getHomeLibraryId();
				if ($to_library_id != null)
					$item_action->setToLibraryId($to_library_id);

				$item_action->save();
			}

//		   $requestCount = ClavisRequestManager::countRequests(	$clavisLibrarian->getActualLibraryId(),
//																null,
//																$item->getItemId());

			if (ClavisRequestManager::isRequested($item))
				return self::RETN_PATRONREQUEST;
			else
				return self::OK;

		}
		catch (Exception $e)
		{
			$e = $e;
			// throw $e;
			return self::ERROR;
		}

    }

    /**
	 * Reset the item to the loanable status (from a 'In rientro')
	 *
	 * @param Item $item
	 * @param ClavisLibrarian $clavisLibrarian
	 *
	 * @return boolean
	 *
	 */
	public function PutOnShelfItem($item, $clavisLibrarian = null, $description = '')
	{
		if (!($item instanceof Item))
			return false;

		if ($clavisLibrarian != null) {
			if (!$clavisLibrarian instanceof ClavisLibrarian)
				return false;
		}

		try
		{
			$currentTime = time();

			/////////$item->setActualLibraryId($item->getHomeLibraryId());   not anymore, after management to other library case.........
			$item->setActualLibraryId($item->getDeliveryLibraryId());
			$sendHomeFlag = ($item->getHomeLibraryId() != $item->getActualLibraryId());
			
			if ($item->isExternal())
			{
				$item->setLoanStatus(ItemPeer::LOANSTATUS_INTRANSITTOEXTRA); // pronto a tornare nel suo consorzio, in quanto extra-sistema
				$item->setHomeLibraryId($item->getOwnerLibraryId());
			}
			else
			{
				$item->setLoanStatus(ItemPeer::LOANSTATUS_AVAILABLE); //'Disponibile'
			}

			$item->setCheckOut(null);
			$item->setLastSeen($currentTime);
			$item->setDueDate(null);
			$item->setPatronId(null);
			$item->setUsageCount($item->getUsageCount() + 1);
			$item->setRenewalCount(0);
			$item->setNotifyCount(0);
			//$item->setCurrentLoanId(null); //DA NON SBIANCARE, per sapere l'ultimo prestito che ho fatto e quindi in che biblioteca e' rientrato (per semplificare la gestione delle prenotazioni senza rientrare alla actuallibrary...), quindi in realta' e' un 'last' e non 'current'

			$item->save();

			$item_action = new ItemAction();
			$item_action->setActionDate(time());
			$item_action->setActionType(ItemActionPeer::TYPE_BACKTOSHELF);   // 'Rimesso a scaffale'
			$item_action->setItemId($item->getItemId());
			$item_action->setPatronId(null);

			$library_id = $clavisLibrarian->getActualLibraryId();
			
			if ($library_id != null)
				$item_action->setLibraryId($library_id);

			$librarian_id = $clavisLibrarian->getId();
			
			if ($librarian_id != null)
				$item_action->setLibrarianId($librarian_id);

			if ($description != '')
				$item_action->setActionNote($description);

			$item_action->save();

			if ($sendHomeFlag)
			{
				/* item is not at home, so go home ! */
				$item->setDeliveryLibraryId($item->getHomeLibraryId());
				$item->setLoanStatus(ItemPeer::LOANSTATUS_READYFORTRANSITTOHOME);
				
				$item->save();

				$itemAction = new ItemAction();
				$itemAction->setActionDate($currentTime);
				$itemAction->setActionType(ItemActionPeer::TYPE_READYFORTRANSIT);
				$itemAction->setItemId($item->getItemId());

				if ($library_id != null)
					$itemAction->setLibraryId($library_id);

				if ($librarian_id != null)
					$itemAction->setLibrarianId($librarian_id);
				
				$itemAction->setFromLibraryId($item->getActualLibraryId());
				$itemAction->setToLibraryId($item->getHomeLibraryId());

				$itemAction->save();
				
				return self::RETN_OKANDMOVE;
			}
			else
			{ 
				return self::OK;
			}

		}
		catch (Exception $e)
		{
			$e = $e;
     		//throw $e;
			//Prado::log("Errore in PutOnShelfItem(): ".Prado::varDump($e));
     		return self::ERROR;
		}
	}

	/**
	 * This method elaborates the Manifestation, finding a list of candidates,
	 * then it calls the DoLoanItem(). If the candidates list is empty, it inserts an
	 * item_request with only the manifestation_id (and item_id null)
	 *
	 * @param Manifestation $patron
	 * @param Patron $patron
	 * @param ClavisLibrarian $clavisLibrarian
	 * @param Library $deliveryLibrary
	 * @param array of Item $excluded_items
	 *
	 * @return boolean
	 *
	 */
	public function DoLoanManifestation($manifestation, $patron, $clavisLibrarian, $deliveryLibrary, $excluded_items = null) {

		if ($manifestation == null)
			return false;

		if (!$manifestation instanceof Manifestation)
			return false;

		if ($patron == null)
			return false;

		if (!$patron instanceof Patron)
			return false;

		if ($clavisLibrarian == null)
			return false;

		if (!$clavisLibrarian instanceof ClavisLibrarian)
			return false;

		if ($deliveryLibrary == null)
			return false;

		if (!$deliveryLibrary instanceof Library)
			return false;

		$candidates = array();
		//1) applica la formula e prendi i candidati
		if ($excluded_items != null)
			$candidates = $this->searchItemFromManifestation($manifestation, $excluded_items);
		else
			$candidates = $this->searchItemFromManifestation($manifestation);

		if (count($candidates) == 0) {
			//no candidates --> insert item_request
			$item_request = new ItemRequest();

			$item_request->setRequestStatus(ItemRequestPeer::STATUS_PENDING);
			$item_request->setItemId(null);
			$item_request->setManifestation($manifestation->getManifestationId());
			$item_request->setPatronId($patron->getPatronId());
			$item_request->setRequestDate(time());
			$item_request->setDeliveryLibraryId($deliveryLibrary->getLibraryId());
			$expireDate = self::CalculateExpireDate($item_request);
			if ($expireDate != -1)
				$item_request->setExpireDate($expireDate);
			else
				throw new Exception();

			$item_request->save();

			//edit patron last_seen for statistics
			$patron->UpdateLastSeen(true);

		} else {
			//do loan item
			if(count($candidates) == 1) {
				return $this->DoLoanItem($candidates[0],$patron,$clavisLibrarian,$deliveryLibrary);
			} else {
				//TBD - foreach($candidates as $candidate) ...

			} //end if(count($candidates) == 1)

		} //end if(count($candidates) == 0)

	}

	/**
	 * Do a renew action
	 *
	 * The optional parameter $dueDate is used when we want to pass a new due date
	 * not expressed in days ($renew_duration) but in an absolute date (in timestamp).
	 *
	 * @param Item $item
	 * @param Patron $patron
	 * @param ClavisLibrarian $clavisLibrarian
	 * @param string $description
	 * @param integer $renew_duration
	 * @param integer $dueDate
	 *
	 * @return boolean
	 *
	 */
	public function DoRenewLoan($item, $destinationObject, $clavisLibrarian, $description, $renew_duration = null, $dueDate = null)
	{
		if (!($item instanceof Item))
			return false;

		if ($destinationObject instanceof Patron)
			$external = false;
		elseif ($destinationObject instanceof Library)
			$external = true;
		else
			return false;

		if (is_null($clavisLibrarian))
			$clavisLibrarian = $this->getUser();
		if (!($clavisLibrarian instanceof ClavisLibrarian))
			return false;

		if ($description != null)
			if (!is_string($description))
				return false;

		try
		{
			$renew_date = self::CalculateRenewDate($item, $destinationObject, $renew_duration, $dueDate);
			if ($renew_date == self::CALCULATEDATE_ERROR)
				self::throwCalculateDueDateError();

			$loan = $item->getCurrentLoan();
			if ($loan instanceof Loan)
			{
				$loan->setDueDate($renew_date);
                                $loan->setNotifyAutoCount(0);

				if ($loan->getRenewCount() < 0)
					return false;
				else
				{
					$newRenewCount = $loan->getRenewCount() + 1;
					$loan->setRenewCount($newRenewCount);
				}

				$loan->save();
			}
			else
				return false;

			$item->setRenewalCount($newRenewCount);
			$item->setDueDate($renew_date);
			$item->save();

			//item_action table
			$item_action = new ItemAction();
			$item_action->setActionDate(time());
			$item_action->setActionType(ItemActionPeer::TYPE_RENEWAL);   //'Rinnovo'
			$item_action->setItemId($item->getItemId());
			if ($external)   // biblioteca esterna
				$item_action->setExternalLibraryId($destinationObject->getLibraryId());
			else       // patron
			{
				$item_action->setPatronId($destinationObject->getPatronId());
				$destinationObject->UpdateLastSeen(true);
			}

			$library_id = $clavisLibrarian->getActualLibraryId();
			if ($library_id != null)
				$item_action->setLibraryId($library_id);

			$librarian_id = $clavisLibrarian->getId();
			if ($librarian_id != null)
				$item_action->setLibrarianId($librarian_id);

			if ($description != '')
				$item_action->setActionNote($description);

			$item_action->save();

			return true;

		}
		catch (Exception $e)
		{
			$e = $e;
     	//	throw $e;
     		return false;
		}
	}

	/**
	 * Do a solicit action
	 *
	 * @param Item|Loan $object
	 * @param Patron|Library $destination
	 * @param ClavisLibrarian $clavisLibrarian
	 * @param string $description
	 * @param string $solicitType
	 * @param Notification $notification
	 * @return mixed
	 */
	public function DoSolicitLoan($object,
								  $destination,
								  $clavisLibrarian,
								  $description,
								  $solicitType = ItemActionPeer::TYPE_SOLICIT ,
								  $notification = null)
	{
		if ($object instanceof Item) {
			$item = $object;
			$loan = $item->getCurrentLoan();
		} else if ($object instanceof Loan) {
			$loan = $object;
			$item = $loan->getItem();
		} else {
			return false;
		}

		if (! $clavisLibrarian instanceof ClavisLibrarian)
			return false;

		if ($description != null && !is_string($description))
			return false;

		try
		{
			//item_action table
			$item_action = new ItemAction();
			$item_action->setActionDate(time());
			$item_action->setActionType($solicitType);
			$item_action->setItemId($item->getItemId());

			$item->setNotifyCount(intval($item->getNotifyCount()) + 1);
			$item->save();

			if ($loan) {
				$loan->setNotifyCount(intval($loan->getNotifyCount()) + 1);
				$loan->save();
				$item_action->setLoan($loan);
			}

			if($notification instanceof Notification)
				$item_action->setNotification($notification);

			if ($destination instanceof Patron)
				$item_action->setPatronId($destination->getPatronId());
			elseif ($destination instanceof Library)
				$item_action->setExternalLibraryId($destination->getLibraryId());

			$library_id = $clavisLibrarian->getActualLibraryId();
			if ($library_id != null)
				$item_action->setLibraryId($library_id);

			$librarian_id = $clavisLibrarian->getID();
			if ($librarian_id != null)
				$item_action->setLibrarianId($librarian_id);

			if ($description != '')
				$item_action->setActionNote($description);

			$item_action->save();

			return $item_action;
		}
		catch (Exception $e)
		{
			return false;
		}
	}

	/**
	 * Abort a loan
	 *
	 * @param Item $item
	 * @param Patron|Library $destinationObject
	 * @param ClavisLibrarian $clavisLibrarian
	 * @param enum $type
	 * @param string $description
	 * @param boolean $force
	 *
	 * @return boolean
	 *
	 */
	public function DoAbortLoan(	$item,
									$destinationObject = null,
									$clavisLibrarian,
									$type,
									$description,

									$force = null )
	{
		if (!in_array($type, ItemActionPeer::getAbortTypes()))
			$type = ItemActionPeer::TYPE_ABORTGENERIC;

		if (!($item instanceof Item))
			return self::ERROR;

		$extra = false;
		if (is_null($destinationObject))
			$destinationObject = $item->getPatron();
		if (is_null($destinationObject))
			$destinationObject = $item->getExternalLibrary();

		if (!is_null($destinationObject))
		{
			$destinationObjectId = intval($destinationObject->getId());
			if ($destinationObject instanceof Library)
				$extra = true;
		}
		else
		{
			$destinationObjectId = 0;
		}

		if (is_null($clavisLibrarian))
			$clavisLibrarian = $this->getUser();
		if (!($clavisLibrarian instanceof ClavisLibrarian))
			return self::ERROR;

		$description = trim($description);
		if ($description != null)
			if (!is_string($description))
				return self::ERROR;

		if (!is_null($force) && !(($force == self::LOAN_ABORTFORCEACTUAL) || ($force == self::LOAN_ABORTFORCEOWNER)))
			$force = null;

		try
		{
			$myLibraryId = intval($clavisLibrarian->getActualLibraryId());
			$myLibrarianId = intval($clavisLibrarian->getID());
			if ($myLibraryId * $myLibrarianId == 0)
				return self::ERROR;

			$currentTime = time();

			if ($force == self::LOAN_ABORTFORCEACTUAL)
				$item->setActualLibraryId($myLibraryId);
			elseif (($force == self::LOAN_ABORTFORCEOWNER)
						|| ($type == ItemActionPeer::TYPE_ABORTPROTEST))	// case of abort for protest (contestazione)
			{
				$item->setActualLibraryId($item->getOwnerLibraryId());
				$item->setHomeLibraryId($item->getOwnerLibraryId());
			}

			$item->save();
			$item = ItemQuery::create()->findPK($item->getItemId());

			$itemOutOfSystem = $item->isOutOfSystem();
			$itemOutOfHome = ($item->isOutOfHome() === true);
			$itemExternal = $item->isExternal();
			$loan = $item->getCurrentLoan();

			// se l'esemplare non e' in casa, genera transito di rientro, ma solo se e' dentro il mio sistema,
			// e se e' un extrasistema solo se esiste una biblioteca nodo
			if ($itemOutOfHome
				&& !$itemOutOfSystem
				&& ((!$itemExternal) || ($itemExternal && $this->getExtraSystemNodeLibraryId() > 0)))
			{
				$transitToHome = true;
				$newLoanStatus = ItemPeer::LOANSTATUS_READYFORTRANSITTOHOME;
				$returnCode = self::LOAN_ABORTRETURNHOME;
				$item->setDeliveryLibraryId($item->getHomeLibraryId());
			}
			else   // altrimenti no
			{
				$transitToHome = false;

				if ($itemExternal)
				{
					if ($item->isOutOfOwner())
						$newLoanStatus = ItemPeer::LOANSTATUS_INTRANSITTOEXTRA;
					else
						$newLoanStatus = ItemPeer::LOANSTATUS_AVAILABLEEXTRA;
				}
				else
					$newLoanStatus = ItemPeer::LOANSTATUS_AVAILABLE;

				$returnCode = self::OK;
				$item->setCurrentLoanId(null);

				if ($itemOutOfSystem)
					$item->setActualLibraryId($item->getHomeLibraryId());
			}

			$item->setLoanStatus($newLoanStatus); //'Disponibile' oppure in transito a casa se e' fuori casa
			$item->setCheckOut(null);
			$item->setCheckIn(null);
			$item->setIllTimestamp(null);
			$item->setDueDate(null);
			$item->setPatronId(null);
			$item->setExternalLibraryId(null);
			$item->setRenewalCount(0);

			//LOAN
			$loanArray = array();
			if ($loan instanceof Loan)
			{
				$loan->setLoanStatus(ItemPeer::LOANSTATUS_CANCELED); //'Annullato'
				$loan->setRenewCount($item->getRenewalCount());
				$loan->setNotifyCount($item->getNotifyCount());
				$loan->setDueDate(null);
				$loan->setLoanDateEnd($currentTime);
				//// ciro dice di no  $loan->setItemId(null);
				$loan->save();
				$loanArray = array($loan);
			}
			else    // caso in cui non sia agganciato un prestito all'item, ma mi devo cercare manualmente i prestiti rotti (v. BiblioInRete)
			{
				$lCrit = new Criteria();
				$lCrit->add(LoanPeer::LOAN_STATUS, array(ItemPeer::LOANSTATUS_CLOSED, ItemPeer::LOANSTATUS_CANCELED), Criteria::NOT_IN);
				foreach ($item->getLoansRelatedByItemId($lCrit) as $lo)
				{
					$lo->setLoanStatus(ItemPeer::LOANSTATUS_CLOSED); //'Annullato'
					$lo->setRenewCount($item->getRenewalCount());
					$lo->setNotifyCount($item->getNotifyCount());
					$lo->setDueDate(null);
					$lo->setLoanDateEnd($currentTime);
					$lo->save();
					$loanArray[] = $lo;
					unset ($lo);
				}
			}
			
			// case of abort for protesting (contestazione)
			if ($type == ItemActionPeer::TYPE_ABORTPROTEST)
			{
				$item->setItemStatus(ItemStatus::ITEMSTATUS_LOST);
				$item->setLoanClass(ItemPeer::LOANCLASS_UNAVAILABLE);
				$item->setOpacVisible(0);
				
				// we put the item in its own home
				
				$item->setHomeLibraryId($item->getOwnerLibraryId());
				$item->setActualLibraryId($item->getOwnerLibraryId());
			}
			
			$item->setNotifyCount(0);
			
			$item->save();

			//item_action table - insert action
			$item_action = new ItemAction();
			$item_action->setActionDate($currentTime);
			$item_action->setActionType($type);		// 'Annullamento' (4 tipi diversi)
			$item_action->setItemId($item->getItemId());

			if (!$extra)
				$item_action->setPatronId($destinationObjectId);
			else   // caso extra
				$item_action->setExternalLibraryId($destinationObjectId);

			$item_action->setLibraryId($myLibraryId);
			$item_action->setLibrarianId($myLibrarianId);

			if ($description != '')
				$item_action->setActionNote($description);

			$item_action->save();

			if ($transitToHome)
			{
				$item_action2 = new ItemAction();
				$item_action2->setActionDate($currentTime);
				$item_action2->setActionType(ItemActionPeer::TYPE_READYFORTRANSIT); //'Pronto al transito'
				$item_action2->setItemId($item->getItemId());

				if (!$extra)
					$item_action2->setPatronId($destinationObjectId);
				else   // caso extra
					$item_action2->setExternalLibraryId($destinationObjectId);

				$item_action2->setLibraryId($myLibraryId);
				$item_action2->setLibrarianId($myLibrarianId);

				if ($description != '')
					$item_action2->setActionNote(Prado::localize("Messo in transito verso la biblioteca proprietaria perché il prestito è stato annullato"));

				$item_action2->setFromLibraryId($item->getActualLibraryId());
				$item_action2->setToLibraryId($item->getHomeLibraryId());

				$item_action2->save();
			}

			if (count($loanArray) > 0)
			{
				foreach ($loanArray as $loanLoop)
					ChangelogPeer::logAction(	$loanLoop,
												ChangelogPeer::LOG_UPDATE,
												$clavisLibrarian,
												"Annullato prestito con id: " . $loanLoop->getLoanId() .
													" da ricerca automatica dei prestiti rotti");
			}
			else
			{
				ChangelogPeer::logAction(	$item,
											ChangelogPeer::LOG_UPDATE,
											$clavisLibrarian,
											"Annullato prestito");
			}

			return $returnCode;
		}
		catch (Exception $e)
		{
			$e = $e;
			///throw($e);
			return self::ERROR;
		}
	}

	/**
	 * Checks if we can change an item's home library
	 * 
	 * @param Item $item
	 * @param Librarian $librarian
	 * @param boolean $pluginMode - if true, we are in the case we don't want to check the item's loan status
	 * @return boolean
	 */
	public function IsItemReassignable($item, $librarian = null, $pluginMode = false)
	{
		if (!$pluginMode)	// in case we care if an item is in loan or transit
		{	
			if (in_array($item->getLoanStatus(),
					array_merge(	ItemPeer::getLoanStatusCurrent(),
									ItemPeer::getLoanStatusPending(),
									ItemPeer::getLoanStatusTransit())))
				return false;

			if (self::IsItemLoaned($item))
				return false;
		}
		
		if (($librarian instanceof Librarian) 
				&& !($librarian->getEditPermission($item)))
			return false;

		return true;
	}

	/**
	 * It changes an item's home library
	 * 
	 * @param int $toLibraryId
	 * @param Item $item
	 * @param ClavisLibrarian $clavisLibrarian
	 * @param boolean $pluginMode - if true, we are in the case we don't want to check the item's loan status
	 * @return enum - results
	 */
	public function DoReassignItemToLibrary($toLibraryId, $item, $clavisLibrarian, $pluginMode = false)
	{
		if (is_null($item) 
				|| !($item instanceof Item))
			return self::ERROR;

		if (is_null($clavisLibrarian) 
				|| !($clavisLibrarian instanceof ClavisLibrarian))
			return self::ERROR;

		$toLibraryId = (int) $toLibraryId;
		
		if (!($toLibraryId > 0))
			return self::ERROR;

		if (!$this->IsItemReassignable($item, $clavisLibrarian, $pluginMode))
			return self::ERROR;

		try
		{
			$oldlibraryId = $item->getHomeLibraryId();

			if ($pluginMode)	// only when called by the items reassign plugin
			{	
				$item->setPrevHomeLibraryId($toLibraryId == $item->getOwnerLibraryId()
												? null	// we are returning to owner
												: $oldlibraryId);	// we are going in assignment to a new library, saving here old one
			}
			else
			{
				$item->setPrevHomeLibraryId(null);
			}
			
			$item->setHomeLibraryId($toLibraryId);

			$canSetStatus = true;
			
			if ($pluginMode)
			{
				//if (self::IsItemLoaned($item) || self::IsInTransit($item) || self::IsReadyForTransit($item))     by drigolin
				if (self::IsItemLoanStatusActive($item)
						|| $item->IsLoanStatusTransit())
					$canSetStatus = false;
			}	
				
			if ($canSetStatus)	// if we can modify item's loan status
			{	
				if ($item->getActualLibraryId() == $toLibraryId)
				{
					$item->setLoanStatus(ItemPeer::LOANSTATUS_AVAILABLE);	// item is already here, set it available
				}
				else
				{
					/* item is not at home, go away! */
					$item->setDeliveryLibraryId($toLibraryId);
					$item->setLoanStatus(ItemPeer::LOANSTATUS_READYFORTRANSITTOHOME);

					$item_action = new ItemAction();
					$item_action->setActionDate(time());
					$item_action->setActionType(ItemActionPeer::TYPE_READYFORTRANSIT); //   ready for transit
					$item_action->setItemId($item->getItemId());

					if (($library_id = $clavisLibrarian->getActualLibraryId()) != null)
						$item_action->setLibraryId($library_id);

					if (($librarian_id = $clavisLibrarian->getId()) != null)
						$item_action->setLibrarianId($librarian_id);

					$item_action->setFromLibraryId($item->getActualLibraryId());
					$item_action->setToLibraryId($toLibraryId);

					$item_action->save();
				}
			}

			$item->save();

			ChangelogPeer::logAction(	$item, 
										ChangelogPeer::LOG_UPDATE, 
										$clavisLibrarian,
										"Modifica biblioteca gestione esemplare con id: {$item->getItemId()} "
											. "- precedente [{$oldlibraryId}], attuale [{$toLibraryId}]");

			return self::OK;
		}
		catch (Exception $e)
		{
			// throw $e;
     		return self::ERROR;
		}
	}

	/* AUX METHODS */

	/**
	 * @param int $ownerLibraryId
	 * @param int $librarianId
	 * @return int: the number of days that we can wait with an item in
	 * "ready to loan" status laying in our library, before incurring in
	 * "late fee" policies ...
	 */
	public function CalculateWaitingDelta($ownerLibraryId = null, $librarianId = null)
	{
		$waitDays = 0;
		$ownerLibraryId = intval($ownerLibraryId);
		$librarianId = intval($librarianId);

		if ($ownerLibraryId * $librarianId != 0)
			$waitDays = intval(ClavisParamPeer::getParam('READYTOLOANWAIT', null, $ownerLibraryId, $librarianId));

		if (($waitDays == 0) && ($ownerLibraryId != 0))
			$waitDays = intval(ClavisParamPeer::getParam('READYTOLOANWAIT', null, $ownerLibraryId));

		if ($waitDays == 0)
			$waitDays = intval(ClavisParamPeer::getParam('READYTOLOANWAIT'));

		if ($waitDays != 0)
			return $waitDays;
		else
			return null;
	}

	/**
	 * Given the days, it calculates the duration in *nix standard
	 * for the due date
	 *
	 * @param Item $item
	 * @param Patron $patron
	 *
	 * @return *nix timestamp : absolute due date
	 *
	 */
	public function CalculateDueDate($item, $patron = null)
	{
		$dueDate = null;
        $loanClass = null;

		if (!($item instanceof Item))
			return self::CALCULATEDATE_ERROR;

		if (!is_null($patron))
		{
			if (!($patron instanceof Patron))
				return self::CALCULATEDATE_ERROR;

            $loanClass = $patron->getLoanClass();
		}
		elseif ($item->getPatronId() != null)
		{
            $patron = $item->getPatron();
			if ($patron instanceof Patron)
				$loanClass = $patron->getLoanClass();
        }
		elseif($item->getExternalLibraryId() != null)
		{
            $loanClass = "X"; //External library
        }

        if (is_null($loanClass))
			return null;

		$currentTime = time();

		if ($item->isStatusConsultation()) // esemplare di consultazione
		{
			$now = getdate();
			$new = mktime(0, 0, 0, $now['mon'], $now['mday'] + 1, $now['year']) - 1;
			$dueDate = $new;
		}
		else
		{
            if($patron instanceof Patron)
                $due_timestamp_rel = ClavisParamPeer::getParam('LOANDURATION_'.$loanClass, $item->getItemMedia()) * self::DAYS_1;
			else
                $due_timestamp_rel = ClavisParamPeer::getParam('LOANDURATION_'.$loanClass, $item->getItemMedia()) * self::DAYS_1;

			$extraDelay = 0;
			$externalDeliveryLibrary = $item->getExternalLibrary();
			if ($externalDeliveryLibrary instanceof Library)
			{
				if ($externalDeliveryLibrary->isExternal() && ($externalDeliveryLibrary->getLibraryId() != $item->getActualLibraryId()))
					$extraDelay = intval(ClavisParamPeer::getParam('EXTRASYSTEMADDDURATION')) * self::DAYS_1;
			}
			$dueDate = $currentTime + $due_timestamp_rel + $extraDelay;
			$library = $this->getUser()->getActualLibrary();
			if ($dueDate && !$externalDeliveryLibrary instanceof Library && $library instanceof Library) {
				$nextOpenDay = LibraryTimetableQuery::create()
					->filterByLibrary($library)
					->filterByTimetableOpen(true)
					->filterByTimetableDay($dueDate, Criteria::GREATER_EQUAL)
					->orderByTimetableDay()
					->findOne();
				if ($nextOpenDay instanceof LibraryTimetable)
					$dueDate = $nextOpenDay->getTimetableDay('U');
			}
		}
		
		return $dueDate;
	}

   	/**
	 * Given the days from Clavis_param, it calculates the duration in *nix standard
	 * for renewing the due date
	 *
	 * We can pass a $renew_duration (in days) or a $dueDate (in absolute time, in timestamp),
	 * or nothing (calculates standard delay).
	 *
	 * @param Item $item
	 * @param Patron|Library $destinationObject
	 * @param integer $renew_duration
	 * @param integer $dueDate
	 *
	 * @return *nix timestamp : absolute renew date
	 *
	 */
	public function CalculateRenewDate($item, $destinationObject = null, $renew_duration = null, $dueDate = null)
	{
		$external = false;
        $loanClass = "";

		if (!($item instanceof Item))
			return self::CALCULATEDATE_ERROR;

		if (!is_null($destinationObject))
		{
			if ($destinationObject instanceof Patron) {
                $external = false;
                $loanClass = $destinationObject->getLoanClass();

            } elseif ($destinationObject instanceof Library) {
                $external = true;
                $loanClass = "X";

            } else
				return self::CALCULATEDATE_ERROR;
		} else {
			if($item->getPatron() != null) {
				$loanClass = $item->getPatron()->getLoanClass();
				$external = false;

			} elseif($item->getExternalLibraryId() != null) {
				$external = true;
				$loanClass = "X";
			}
		}

		if (ClavisParamQuery::getParam('CLAVISPARAM','RenewFromNow') == 'true')
			$actualRenewDate = time();
		else
			$actualRenewDate = $item->getDueDate('U');

		if ($item->isStatusConsultation()) // esemplare di consultazione
			return $actualRenewDate + self::DAYS_1;   // aggiungi un giorno
		else
		{
			if (($renew_duration != null) && (is_numeric($renew_duration)) && ($renew_duration > 0))
				$renew_timestamp_abs = $actualRenewDate + $renew_duration * self::DAYS_1;
			elseif (($dueDate != null) && (is_numeric($dueDate)) && ($dueDate > 0))
				$renew_timestamp_abs = $dueDate;
			else
			{
				$renew_timestamp_rel = ClavisParamPeer::getParam('LOANRENEWDURATION_'.$loanClass, $item->getItemMedia()) * self::DAYS_1;
				$renew_timestamp_abs = $actualRenewDate + $renew_timestamp_rel;
			}

			$library = $item->getActualLibrary();
			if ($renew_timestamp_abs && $library instanceof Library) {
				$nextOpenDay = LibraryTimetableQuery::create()
					->filterByLibrary($library)
					->filterByTimetableOpen(true)
					->filterByTimetableDay($renew_timestamp_abs, Criteria::GREATER_EQUAL)
					->orderByTimetableDay()
					->findOne();
				if ($nextOpenDay instanceof LibraryTimetable)
					$renew_timestamp_abs = $nextOpenDay->getTimetableDay('U');
			}
			return $renew_timestamp_abs;
		}
	}

	/**
	 * Given the days from Clavis_param, it calculates the duration in *nix standard
	 * for renewing the due date
	 *
	 * @param ItemRequest $item_request
	 * @param Item $item
	 * @param Patron $patron
	 *
	 * @return *nix timestamp : absolute expire date for an item_request
	 *
	 */
	public function CalculateExpireDate($item_request, $item = null, $patron = null) {

		if (!$item_request instanceof ItemRequest)
			return -1;

		if ($item != null)
			if (!$item instanceof Item)
				return -1;

        if($item_request->getPatron() instanceof Patron)
            $loanClass = $item_request->getPatron()->getLoanClass();
        else if($item_request->getExternalLibraryId() > 0)
            $loanClass = "X";
        else
            $loanClass = "";

		if ($item == null) {
			//requesting a constant default
			$expire_duration = ClavisParamPeer::getParam('REQUESTDURATION_'.$loanClass,'0'); //default
			if ($expire_duration != null)
				$expire_timestamp_rel = $expire_duration * self::DAYS_1;
			else
				return -1;
		} else {
			//requesting a parametrized default

			$duration = ClavisParamPeer::getParam('REQUESTDURATION_'.$loanClass,'0');
			$expire_timestamp_rel = $duration * self::DAYS_1;
		}

		if (($req_date = $item_request->getRequestDate('U')) != null)
			$expire_timestamp_abs = $req_date + $expire_timestamp_rel;
		else
			$expire_timestamp_abs = time() + $expire_timestamp_rel;

		return $expire_timestamp_abs;
	}


	/**
	 * Given a manifestation, it applies a procedure to find one (or more...) item(s)
	 * from the libraries which could satisfy the request
	 *
	 * @param Manifestation $manifestation
	 * @param array of Item $excluded_items
	 *
	 * @return array of Item $item : the choosen items by the algorhythm
	 *
	 */
	public function SearchItemFromManifestation($manifestation, $excluded_items = null)
	{
		$excluded_items_id = array();

		if (!($manifestation instanceof Manifestation))
			return null;

		if ($excluded_items != null)
			if (!is_array($excluded_items))
			{
				return null;
			}
			else
			{
				foreach($excluded_items as $excluded_item)
				{
					if ($excluded_item instanceof Item)
						$excluded_items_id[] = $excluded_item->getItemId();
				}
			}

		$c = new Criteria();
		$c->addAscendingOrderByColumn(ItemPeer::USAGE_COUNT);
		$crit1 = $c->getNewCriterion(ItemPeer::MANIFESTATION_ID, $manifestation->getManifestationId());

		if (count($excluded_items_id) != 0)
		{
			$crit2 = $c->getNewCriterion(ItemPeer::ITEM_ID, $excluded_items_id, Criteria::NOT_IN);
			$crit1->addAnd($crit2);
		}

		$c->add($crit1);
		$candidates = ItemPeer::doSelect($c);

		return $candidates;
	}


	/**
	 * State calculation
	 */

	/**
	 * Given a item loan state (LookupValuePeer::value_class(LOANSTATUS), it gives an array of possible
	 *  destination actions (type ITEMACTIONTYPE)
	 *
	 * @param $from_loanstatus
	 *
	 * @return array of LookupValuePeer::value_class(ITEMACTIONTYPE)  : array of destination actions
	 *
	 */
	public function CalculateItemActionsFromStatus($from_loanstatus) {
		//TODO
		// LOANSTATUS:
		//'A' --> "Disponibile"
		//'B' --> "In prestito"
		//'C' --> "In transito"
		//'D' --> "Prenotato per ILL"
		//'E' --> "Pronto al transito"
		//'F' --> "Pronto al prestito"
		//'I' --> "In rientro"
		//NB only for loan table (and NOT for item table...)
		//'G' --> "Concluso"
		//'H' --> "Annullato"

		//ITEMACTIONTYPE:
		//'A' --> "Prestito"
		//'B' --> "Rientro"
		//'C' --> "Rinnovo"
		//'D' --> "Sollecito"
		//'E' --> "Pronto al transito"
		//'F' --> "Transito"
		//'I' --> "Pronto al prestito"
		//'G' --> "Prenotazione"
		//'H' --> "Annullamento"

		$return_set = array();

		if ($from_loanstatus == null)
			return $return_set;

		if ((!is_string($from_loanstatus)||(strlen($from_loanstatus) != 1)))
			return $return_set;

		switch ($from_loanstatus)
		{
			case 'A': //"Disponibile" (LOANSTATUS)
					$return_set[] = 'A'; //"Prestito" (ITEMACTIONTYPE)
					//$return_set[] = 'E'; //"Pronto al transito" (ITEMACTIONTYPE)
					//$return_set[] = 'I'; //"Pronto al prestito" (ITEMACTIONTYPE)
					//$return_set[] = 'G'; //"Prenotazione" (ITEMACTIONTYPE)
					$return_set[] = 'H'; //"Annullamento" (ITEMACTIONTYPE)
				break;

			case 'B': //"In prestito" (LOANSTATUS)
					$return_set[] = 'B'; //"Rientro" (ITEMACTIONTYPE)
					$return_set[] = 'C'; //"Rinnovo" (ITEMACTIONTYPE)
					$return_set[] = 'D'; //"Sollecito" (ITEMACTIONTYPE)
					$return_set[] = 'G'; //"Prenotazione" (ITEMACTIONTYPE)
					$return_set[] = 'H'; //"Annullamento" (ITEMACTIONTYPE)
				break;

			case 'C': //"In transito" (LOANSTATUS)
					$return_set[] = 'I'; //"Pronto al prestito" (ITEMACTIONTYPE)
					$return_set[] = 'G'; //"Prenotazione" (ITEMACTIONTYPE)
					$return_set[] = 'H'; //"Annullamento" (ITEMACTIONTYPE)
				break;

			case 'E': //"Pronto al transito" (LOANSTATUS)
					$return_set[] = 'F'; //"Transito" (ITEMACTIONTYPE)
					$return_set[] = 'G'; //"Prenotazione" (ITEMACTIONTYPE)
					$return_set[] = 'H'; //"Annullamento" (ITEMACTIONTYPE)
				break;

			case 'F': //"Pronto al prestito" (LOANSTATUS)
					$return_set[] = 'A'; //"Prestito" (ITEMACTIONTYPE)
					$return_set[] = 'G'; //"Prenotazione" (ITEMACTIONTYPE)
					$return_set[] = 'H'; //"Annullamento" (ITEMACTIONTYPE)
				break;

			case 'G': //"Concluso"
			case 'H': //"Annullato"
				break;

			case 'I': //"In rientro"
					$return_set[] = 'G'; //"Prenotazione" (ITEMACTIONTYPE)
					$return_set[] = 'H'; //"Annullamento" (ITEMACTIONTYPE)
				break;

			default:
				break;
		}

		return $return_set;

	}

	/**
	 * It calculates the array of possible destination actions
	 *
	 * @param Item $item
	 * @param Patron $patron
	 * @param Librarian $clavisLibrarian
	 * @param integer $libraryId
	 *
	 * @return array of LookupValuePeer::value_class(ITEMACTIONTYPE)  : array of destination actions
	 *
	 */
	public function CalculateItemActions($item, $patron = null, $clavisLibrarian = null, $libraryId = null)
	{
		if (!($item instanceof Item))
			return false;

		if (!is_null($patron))
		{
			if (!($patron instanceof Patron))
				return false;
		}

		if (is_null($clavisLibrarian))
			$clavisLibrarian = $this->getUser();

		if (!($clavisLibrarian instanceof ClavisLibrarian))
			return false;

		$return_set = array();
		$from_loanstatus = $item->getLoanStatus();

		switch ($from_loanstatus)
		{
			case ItemPeer::LOANSTATUS_AVAILABLE: //"Disponibile"
				if (self::IsLoanAllowed($item, $patron, $libraryId))
					$return_set[] = ItemActionPeer::TYPE_LOAN; //"Prestito"

				if (ClavisRequestManager::isItemReservable($item, $patron, $libraryId) == self::OK)
					$return_set[] = ItemActionPeer::TYPE_MANAGEREQUEST; //"Prenotazione"

				$return_set[] = ItemActionPeer::TYPE_ABORTGENERIC; //"Annullamento"
				break;

			case ItemPeer::LOANSTATUS_AVAILABLEEXTRA: // "Disponibile, in extra-sistema (non e' fisicamente qui)"

				if (ClavisRequestManager::isItemReservable($item, $patron, $libraryId) == self::OK)
					$return_set[] = ItemActionPeer::TYPE_MANAGEREQUEST; //"Prenotazione"

				$return_set[] = ItemActionPeer::TYPE_ABORTGENERIC; //"Annullamento"
				break;

			case ItemPeer::LOANSTATUS_INLOAN: //"In prestito"
				$return_set[] = ItemActionPeer::TYPE_RETURN; //"Rientro"

				$isAskRenew = $item->isAskRenew($libraryId);
				if (self::IsLoanRenewable($item, $clavisLibrarian, $patron) == self::OK)
				{
					if ($isAskRenew)
						$return_set[] = ItemActionPeer::TYPE_DISABLERENEWAL;  // blocca rinnovabilita'
					$return_set[] = ItemActionPeer::TYPE_RENEWAL; //"Rinnovo"
				}
				elseif (self::isRenewSuspended($item))
				{
					$return_set[] = ItemActionPeer::TYPE_ENABLERENEWAL; //  "Riabilita rinnovo
				}

				if (self::IsLoanSolicitable($item, $clavisLibrarian, $patron) == self::OK)
					$return_set[] = ItemActionPeer::TYPE_SOLICIT; //"Sollecito"

				if (ClavisRequestManager::isItemReservable($item, $patron, $libraryId) == self::OK) //////// && !is_null($manifestation))
					$return_set[] = ItemActionPeer::TYPE_MANAGEREQUEST; //"Prenotazione"

				$return_set[] = ItemActionPeer::TYPE_ABORTGENERIC; //"Annullamento"
				break;

			case ItemPeer::LOANSTATUS_INTRANSIT: //"In transito"
				$return_set[] = ItemActionPeer::TYPE_READYFORLOAN; //"Pronto al prestito"

				if (ClavisRequestManager::isItemReservable($item, $patron, $libraryId) == self::OK)
					$return_set[] = ItemActionPeer::TYPE_MANAGEREQUEST; //"Prenotazione"

				$return_set[] = ItemActionPeer::TYPE_ABORTGENERIC; //"Annullamento"
				break;

			case ItemPeer::LOANSTATUS_READYFORTRANSIT: //"Pronto al transito"
				$return_set[] = ItemActionPeer::TYPE_INTRANSIT; //"Transito"

				if (ClavisRequestManager::isItemReservable($item, $patron, $libraryId) == self::OK)
					$return_set[] = ItemActionPeer::TYPE_MANAGEREQUEST; //"Prenotazione"

				$return_set[] = ItemActionPeer::TYPE_ABORTGENERIC; //"Annullamento"
				break;

			case ItemPeer::LOANSTATUS_READYFORLOAN: //"Pronto al prestito"
				$return_set[] = ItemActionPeer::TYPE_LOAN; //"Prestito"

				if (ClavisRequestManager::isItemReservable($item, $patron, $libraryId) == self::OK) //////// && !is_null($manifestation))
					$return_set[] = ItemActionPeer::TYPE_MANAGEREQUEST; //"Prenotazione"

				$return_set[] = ItemActionPeer::TYPE_ABORTGENERIC; //"Annullamento"
				break;

			case ItemPeer::LOANSTATUS_CLOSED: //"Concluso"
			case ItemPeer::LOANSTATUS_CANCELED: //"Annullato"
				break;

			case ItemPeer::LOANSTATUS_READYFORTRANSITTOHOME: //"Pronto al transito di rientro"
				$return_set[] = ItemActionPeer::TYPE_INTRANSIT; //"Transito"
				if (self::IsLoanAllowed($item, $patron))
					$return_set[] = ItemActionPeer::TYPE_LOAN; //"Prestito"
				if (ClavisRequestManager::isItemReservable($item, $patron, $libraryId) == self::OK)  //////// && !is_null($manifestation))
					$return_set[] = ItemActionPeer::TYPE_MANAGEREQUEST; //"Prenotazione"
				$return_set[] = ItemActionPeer::TYPE_RETURN; //"In rientro"
				$return_set[] = ItemActionPeer::TYPE_ABORTGENERIC; //"Annullamento"
				break;

			case ItemPeer::LOANSTATUS_INTRANSITTOEXTRA: // "Pronto al transito di rientro a extra-sistema"
				if (self::IsLoanAllowed($item, $patron))
					$return_set[] = ItemActionPeer::TYPE_LOAN; //"Prestito"
				if (ClavisRequestManager::isItemReservable($item, $patron, $libraryId) == self::OK)  //////// && !is_null($manifestation))
					$return_set[] = ItemActionPeer::TYPE_MANAGEREQUEST; //"Prenotazione"
				$return_set[] = ItemActionPeer::TYPE_RETURN; //"In rientro"
				$return_set[] = ItemActionPeer::TYPE_ABORTGENERIC; //"Annullamento"
				break;

			case ItemPeer::LOANSTATUS_TOSHELF: //"In rientro"
				if (ClavisRequestManager::isItemReservable($item, $patron, $libraryId) == self::OK) //////// && !is_null($manifestation))
					$return_set[] = ItemActionPeer::TYPE_MANAGEREQUEST; //"Prenotazione"

				$return_set[] = ItemActionPeer::TYPE_ABORTGENERIC; //"Annullamento"
				break;

			case ItemPeer::LOANSTATUS_INLOANEXTRA: //"In prestito extra-sistema"
				$return_set[] = ItemActionPeer::TYPE_EXTRARETURN; //"Rientro da extra"
				$return_set[] = ItemActionPeer::TYPE_ABORTGENERIC; //"Annullamento"

				if (self::IsLoanRenewable($item, $clavisLibrarian, $patron) == self::OK)
				{
					$return_set[] = ItemActionPeer::TYPE_RENEWAL; //"Rinnovo"
				}
				elseif (self::isRenewSuspended($item))
				{
					$return_set[] = ItemActionPeer::TYPE_ENABLERENEWAL; //  "Riabilita rinnovo
				}

				break;

			case ItemPeer::LOANSTATUS_INCONSULTATION: //"In consultazione"
				$return_set[] = ItemActionPeer::TYPE_CONSULTRETURN; // "Rientro da consultazione"

				if (self::IsLoanRenewable($item, $clavisLibrarian, $patron) == self::OK)
				{
					$return_set[] = ItemActionPeer::TYPE_RENEWAL; //"Rinnovo"
				}
				elseif (self::isRenewSuspended($item))
				{
					$return_set[] = ItemActionPeer::TYPE_ENABLERENEWAL; //  "Riabilita rinnovo
				}
				if (ClavisRequestManager::isItemReservable($item, $patron, $libraryId) == self::OK)
					$return_set[] = ItemActionPeer::TYPE_MANAGEREQUEST; //"Prenotazione"
				$return_set[] = ItemActionPeer::TYPE_CONSULTSUSPEND; // "Sospensione di consultazione"
				$return_set[] = ItemActionPeer::TYPE_ABORTGENERIC; //"Annullamento"
				break;

			case ItemPeer::LOANSTATUS_INFREEZEDCONSULTATION: // "In consultazione sospesa"
				$return_set[] = ItemActionPeer::TYPE_CONSULTRETURN; // "Rientro da consultazione"

				if (ClavisRequestManager::isItemReservable($item, $patron, $libraryId) == self::OK)
					$return_set[] = ItemActionPeer::TYPE_MANAGEREQUEST; //"Prenotazione"
				$return_set[] = ItemActionPeer::TYPE_CONSULTRESUME; // "Resume di consultazione"
				$return_set[] = ItemActionPeer::TYPE_ABORTGENERIC; //"Annullamento"
				break;

			default:
				break;
		}

		return $return_set;
	}


	/**
	 * Given an item action (LookupValuePeer::value_class(ITEMACTIONTYPE), it gives an array of possible
	 *  destination actions (type ITEMACTIONTYPE)
	 *
	 * @param $from_itemaction
	 *
	 * @return array of LookupValuePeer::value_class(ITEMACTIONTYPE)  : array of destination actions
	 *
	 */
	public function CalculateItemActionsFromAction($from_itemaction) {

		$return_set = array();

		if ($from_itemaction == null)
			return $return_set;

		if ((!is_string($from_itemaction)||(strlen($from_itemaction) != 1)))
			return $return_set;

		switch ($from_itemaction)
		{
			case 'A': //"Prestito"
				$return_set[] = ItemActionPeer::TYPE_RETURN;	// B, "Rientro"
				$return_set[] = ItemActionPeer::TYPE_RENEWAL;	// C, "Rinnovo"
				$return_set[] = ItemActionPeer::TYPE_SOLICIT;	// D, "Sollecito"
				$return_set[] = ItemActionPeer::TYPE_MANAGEREQUEST;	//'G'; "Prenotazione"
				$return_set[] = ItemActionPeer::TYPE_ABORTGENERIC;	// 'H'; "Annullamento"
				break;

			case 'B': //"Rientro"
				$return_set[] = ItemActionPeer::TYPE_LOAN;		//'A'; "Prestito"
				$return_set[] = ItemActionPeer::TYPE_RENEWAL;	//'C'; "Rinnovo"
				break;

			case 'C': //"Rinnovo"
				$return_set[] = ItemActionPeer::TYPE_RETURN; //'B'; //"Rientro"
				$return_set[] = ItemActionPeer::TYPE_RENEWAL; //'C'; //"Rinnovo"
				$return_set[] = ItemActionPeer::TYPE_SOLICIT; //'D'; //"Sollecito"
				$return_set[] = ItemActionPeer::TYPE_ABORTGENERIC; //'H'; //"Annullamento"
				break;

			case 'D': //"Sollecito"
				$return_set[] = ItemActionPeer::TYPE_RETURN; //'B'; //"Rientro"
				$return_set[] = ItemActionPeer::TYPE_RENEWAL; //'C'; //"Rinnovo"
				$return_set[] = ItemActionPeer::TYPE_SOLICIT; //'D'; //"Sollecito"
				$return_set[] = ItemActionPeer::TYPE_ABORTGENERIC; //'H'; //"Annullamento"
				break;

			case 'E': //"Pronto al transito"
				$return_set[] = ItemActionPeer::TYPE_INTRANSIT; //'F'; //"Transito"
				$return_set[] = ItemActionPeer::TYPE_ABORTGENERIC; //'H'; //"Annullamento"
				break;

			case 'F': //"Transito"
				$return_set[] = ItemActionPeer::TYPE_READYFORLOAN; //'I'; //"Pronto al prestito"
				$return_set[] = ItemActionPeer::TYPE_ABORTGENERIC; //'H'; //"Annullamento"
				break;

			case 'G': //"Prenotazione"
				$return_set[] = ItemActionPeer::TYPE_LOAN; //'A'; //"Prestito"
				$return_set[] = ItemActionPeer::TYPE_READYFORTRANSIT; //'E'; //"Pronto al transito"
				$return_set[] = ItemActionPeer::TYPE_ABORTGENERIC; //'H'; //"Annullamento"
				break;

			case 'H': //"Annullamento"
				$return_set[] = ItemActionPeer::TYPE_LOAN; //'A'; //"Prestito"
				$return_set[] = ItemActionPeer::TYPE_MANAGEREQUEST; //'G'; //"Prenotazione"
				break;

			default:
				break;
		}

		return $return_set;
	}

	/**
	 * Given an item loan state (LookupValuePeer::value_class(LOANSTATUS), it gives an array of possible
	 *  destination states (type LOANSTATUS)
	 *
	 * @param $from_loanstatus
	 *
	 * @return array of LookupValuePeer::value_class(LOANSTATUS)  : array of destination loan stati
	 *
	 */
	public function CalculateLoanStatiFromStatus($from_loanstatus) {   // CREDO SIA DEPRECATA

		$return_set = array();

		if ($from_loanstatus == null)
			return $return_set;

		if ((!is_string($from_loanstatus)||(strlen($from_loanstatus) != 1)))
			return $return_set;

		switch ($from_loanstatus)
		{
			case 'A': //"Disponibile"
					$return_set[] = ItemPeer::LOANSTATUS_INLOAN; //'B'; //"In prestito"
				break;

			case 'B': //"In prestito"
					$return_set[] = ItemPeer::LOANSTATUS_AVAILABLE; //'A'; //"Disponibile"
				break;

			case 'C': //"In transito"
					$return_set[] = ItemPeer::LOANSTATUS_READYFORLOAN; //'F'; //"Pronto al prestito"
				break;

			case 'D': //"Prenotato per ILL"
					$return_set[] = ItemPeer::LOANSTATUS_READYFORTRANSIT; //'E'; //"Pronto al transito"
				break;

			case 'E': //"Pronto al transito"
					$return_set[] = ItemPeer::LOANSTATUS_INTRANSIT; //'C';   //"In transito"
				break;

			case 'F': //"Pronto al prestito"
					$return_set[] = ItemPeer::LOANSTATUS_AVAILABLE; //'A'; //"Disponibile"
					$return_set[] = ItemPeer::LOANSTATUS_INLOAN; //'B'; //"In prestito"
				break;

			case 'G': //"Concluso"
			case 'H': //"Annullato"
				break;

			case 'J': //"Pronto al transito di rientro"
					$return_set[] = ItemPeer::LOANSTATUS_TOSHELF; //'I'; //"In rientro"
					$return_set[] = ItemPeer::LOANSTATUS_AVAILABLE; //'A'; //"Disponibile"

			case 'I': //"In rientro"
					$return_set[] = ItemPeer::LOANSTATUS_AVAILABLE; //'A'; //"Disponibile"
				break;

			default:
				break;
		}

		return $return_set;
	}

	/**
	 * It returns whether the passed loanstatus is considered
	 * active (first statuses: A-F), or not (G-H).
	 *
	 * @param Loan $loan
	 * @return boolean
	 */
	public function IsLoanStatusActive($object)
	{
		if ($object instanceof Loan)   // se fosse prevista una differenziazione in futuro, nella chiamata ...
			$loanStatus = $object->getLoanStatus();
		elseif ($object instanceof Item)
			$loanStatus = $object->getLoanStatus();
		else
			return false;

		return in_array($loanStatus, ItemPeer::getLoanStatusActive());
	}

	public function IsLoanStatusCurrent($object)
	{
		if ($object instanceof Loan)
			$loanStatus = $object->getLoanStatus();
		elseif ($object instanceof Item)
			$loanStatus = $object->getLoanStatus();
		else
			return false;

		return in_array($loanStatus, ItemPeer::getLoanStatusCurrent());
	}

	public function IsIllRequested($item, $patron = null)
	{
		if (!$item instanceof Item)
			return false;

		if (!is_null($patron) && !$patron instanceof Patron)
			return false;

		$q = ItemRequestQuery::create()
					->filterByRequestStatus(ItemRequestPeer::getActiveStatus());
		$manifestationId = intval($item->getManifestationId());
		if ($manifestationId > 0)
			$q->filterByManifestationId($manifestationId);
		else
			$q->filterByItem($item);

		return $q->count() > 0;
	}

	public function IsInTransit($item, $patron = null)
	{
		if (!($item instanceof Item))
			return false;

		if (!is_null($patron))
		{
			if (!$patron instanceof Patron)
				return false;
		    //TODO eventuali logiche su $patron
		}

		if (in_array($item->getLoanStatus(), array(ItemPeer::LOANSTATUS_INTRANSIT))) // 'in transito'
			return true;
		else
			return false;
	}

	public function IsReadyForTransit($item, $patron = null)
	{
		if (!($item instanceof Item))
			return false;

		if (!is_null($patron))
		{
			if (!$patron instanceof Patron)
				return false;
		    //TODO eventuali logiche su $patron
		}

		if (in_array($item->getLoanStatus(),
				array(ItemPeer::LOANSTATUS_READYFORTRANSIT, ItemPeer::LOANSTATUS_READYFORTRANSITTOHOME))) // 'pronto al transito'
			return true;
		else
			return false;
	}

	public function IsOutStatus($status = null)
	{
		if (is_null($status))
			return false;

		$outStati = array(	ItemPeer::LOANSTATUS_READYFORTRANSIT,
							ItemPeer::LOANSTATUS_READYFORTRANSITTOHOME);

		return (count(array_intersect($status, $outStati)) > 0);
	}

	public function IsInStatus($status = null)
	{
		if (is_null($status))
			return false;

		$inStati = array(	ItemPeer::LOANSTATUS_INTRANSIT,
							ItemPeer::LOANSTATUS_READYFORLOAN,
							ItemPeer::LOANSTATUS_TOSHELF);

		return (count(array_intersect($status, $inStati)) > 0);
	}

	/**
	 * It returns an array, for populating dropdown lists, containing
	 * all the loanstatus which are considered active (for loan) as indexes,
	 * and descriptions as corrisponding elements.
	 *
	 * If a true is passed as parameter, a first blank item is created
	 * (index by 0).
	 *
	 * @param boolean $withBlank
	 */
	public function GetActiveLoanStatuses2DropDownList($withBlank = false)
	{
		return LookupValuePeer::getLookupClassValues('LOANSTATUS', $withBlank, null, ItemPeer::getLoanStatusActive());
	}

	/**
	 * It returns an array, for populating dropdown lists, containing
	 * all the loanstatus which are considered inactive (for loan) as indexes,
	 * and descriptions as corrisponding elements.
	 *
	 * If a true is passed as parameter, a first blank item is created
	 * (index by 0).
	 *
	 * @param boolean $withBlank
	 */
	public function GetInactiveLoanStatuses2DropDownList($withBlank = false)
	{
		return LookupValuePeer::getLookupClassValues('LOANSTATUS', $withBlank, null, ItemPeer::getLoanStatusInactive());
	}

	/*
	 * INTER LIBRARY LOAN MANAGEMENT
	 *   - implementation
	 */

    /**
	 * Take the item from the ILL status to the ready to move status
	 *
	 * @param Item $item
	 * @param ClavisLibrarian $clavisLibrarian
	 */
	public function DoILL2ReadyToMoveItem(	$item,
												$clavisLibrarian,
												$requestId = null )
	{
		if (!($item instanceof Item))
			return false;

		if (!($clavisLibrarian instanceof ClavisLibrarian))
			return false;

		$manifestation = $item->getManifestation();
		$manifestationId = $item->getManifestationId();

		try
		{
			/*
			Correzione del caso segnalato da Malacrida il 24-02-2009 (resubmit folle)
			*/
			if (!is_null($item->getCurrentLoanId()))
				return self::LOAN_LOANALREADYEXISTS;

			$currentTime = time();

			$patron = null;
			$patronId = intval($item->getPatronId());
			if ($patronId > 0)
				$patron = PatronQuery::create()->findPK($patronId);
			$externalLibrary = null;
			$externalLibraryId = intval($item->getExternalLibraryId());
			if ($externalLibraryId > 0)
				$externalLibrary = LibraryQuery::create()->findPK($externalLibraryId);
			if (!(is_null($externalLibrary) xor (is_null($patron))))
				return self::LOAN_EXTRASYSTEMINCONGRUENCY;

			$toExtraSystemFlag = ($externalLibrary instanceof Library);
			$isExternal = $item->isExternal();


			$deliveryLibraryId = $item->getDeliveryLibraryId();
			$itemId = $item->getItemId();

			//item_action table
			$item_action = new ItemAction();
			$item_action->setActionType(ItemActionPeer::TYPE_READYFORTRANSIT); //'pronto per il transito'
			$item_action->setItemId($itemId);
			$item_action->setPatron($patron);
			$item_action->setExternalLibrary($externalLibrary);
			$item_action->setLibrarianId($clavisLibrarian->getId());

			//library_id
			$library_id = $clavisLibrarian->getActualLibraryId();
			if ($library_id != null)
				$item_action->setLibraryId($library_id);

			$item_action->setActionDate(time());
			$item_action->setFromLibraryId($item->getActualLibraryId());
			$item_action->setToLibraryId($deliveryLibraryId);
			$item_action->save();

			//item edit
			$item->setLoanStatus(ItemPeer::LOANSTATUS_READYFORTRANSIT); //'pronto al transito'
			$item->setLastSeen($currentTime);

			//loan table
			$loan = new Loan();
			$loan->setItemId($itemId);
			$loan->setItemOwnerLibraryId($item->getOwnerLibraryId());
			$loan->setItemHomeLibraryId($item->getHomeLibraryId());

			$loan->setLoanStatus(ItemPeer::LOANSTATUS_READYFORTRANSIT); // 'pronto al transito'

			// differenziazione per casi extrasistema
			$loan->setLoanType($toExtraSystemFlag || $isExternal
										? ItemPeer::LOANTYPE_EXTRASYSTEM	// prestito extrasistema
										: ItemPeer::LOANTYPE_INTRASYSTEM); //'prestito interbibliotecario'

			$loan->setPatron($patron);
			$loan->setExternalLibrary($externalLibrary);

			if ($toExtraSystemFlag)
				$loan->setDestinationName($externalLibrary->getLabel());
			else
				$loan->setDestinationName($patron->getCompleteName());

			$loan->setTitle($item->getTitle());
			$loan->setManifestationId($manifestationId);
			if (!is_null($manifestation))
				$loan->setClassCode($manifestation->getClass());
			$loan->setInvNumber($item->getInventorySerieId()."-".$item->getInventoryNumber());
			$loan->setCollocation($item->getCollocation());
			$loan->setItemMedia($item->getItemMedia());
			$loan->setLoanDateBegin(null);
			$loan->setLoanDateEnd(null);
			$loan->setFromLibrary($item->getActualLibraryId());
			$loan->setToLibrary($deliveryLibraryId);
			$loan->setEndLibrary(null);  //to be set in return item
			$loan->setRenewCount(0);
			$loan->setNotifyCount(0);
			$loan->setNotifyAutoCount(0);
			$loan->setDueDate(null);

			if (is_int($requestId))
				$loan->setItemrequestId($requestId);   // 03-06-2008

			$loan->setMediapackageSize($item->getMediapackageSize());

			//new: manage statistic fields
			$loan = $this->updateLoanForStatistics($loan, $patron, $item);
			$loan->save();

			$loanId = $loan->getLoanId();
			$item->setCurrentLoanId($loanId);

			$item->setNotifyCount(0);
			$item->save();

			return self::OK;
		}
		catch (Exception $e)
		{
			return self::ERROR;
		}

	}

	/**
	 * Take the item from the ready to move status to the moving status
	 *
	 * @param Item $item
	 * @param ClavisLibrarian $clavisLibrarian
	 */
	public function DoReadyToMove2MovingItem(	$item,
												$clavisLibrarian = null,
												$note = '')
	{
		$note = trim ($note);

		if (!($item instanceof Item))
			return self::ERROR;

		if (is_null($clavisLibrarian))
			$clavisLibrarian = $this->getUser();
		
		if (!$clavisLibrarian instanceof ClavisLibrarian)
			return self::ERROR;

		try
		{
			$currentTime = time();

			$patron = null;
			$patronId = intval($item->getPatronId());
			
			if ($patronId > 0)
				$patron = PatronQuery::create()->findPK($patronId);

			$externalLibrary = null;
			$externalLibraryId = intval($item->getExternalLibraryId());
			
			if ($externalLibraryId > 0)
				$externalLibrary = LibraryQuery::create()->findPK($externalLibraryId);

			if (!(is_null($externalLibrary) xor is_null($patron)) && ($item->getLoanStatus() != ItemPeer::LOANSTATUS_READYFORTRANSITTOHOME))
				return self::LOAN_EXTRASYSTEMINCONGRUENCY;    //// da vedere se dove ritorna viene interpretato  ******

			$deliveryLibraryId = $item->getDeliveryLibraryId();
			$itemId = $item->getItemId();

			if (($patronId > 0) 
					|| ($externalLibraryId > 0))
			{
				//transito di interprestito

				//item_action table
				$item_action = new ItemAction();
				$item_action->setActionType(ItemActionPeer::TYPE_INTRANSIT); //'Transito'
				$item_action->setItemId($itemId);
				$item_action->setPatronId($patronId);
				$item_action->setExternalLibraryId($externalLibraryId);
				$item_action->setLibrarianId($clavisLibrarian->getId());

				//library_id
				$library_id = $clavisLibrarian->getActualLibraryId();
				
				if ($library_id != null)
					$item_action->setLibraryId($library_id);

				$item_action->setActionDate($currentTime);     //  ????
				$item_action->setFromLibraryId($item->getActualLibraryId());
				$item_action->setToLibraryId($deliveryLibraryId);

				if ($note != '')
					$item_action->setActionNote($note);

				$item_action->save();

				$item->setLoanStatus(ItemPeer::LOANSTATUS_INTRANSIT); //'In transito'
				$item->setLastSeen($currentTime);

				$item->save();

				//loan table
				$loan = LoanQuery::create()->findPK($item->getCurrentLoanId());
				
				if ($loan != null)
				{
					$loan->setLoanStatus(ItemPeer::LOANSTATUS_INTRANSIT); // 'In transito'
					$loan->save();
				}
			}
			else
			{
				//transito di rientro

				//item_action table
				$item_action = new ItemAction();
				$item_action->setActionType(ItemActionPeer::TYPE_INTRANSIT); //'Transito'
				$item_action->setItemId($itemId);
				$item_action->setPatronId(null);
				$item_action->setExternalLibraryId(null);
				$item_action->setLibrarianId($clavisLibrarian->getId());

				//library_id
				$library_id = $clavisLibrarian->getActualLibraryId();
				if ($library_id != null)
					$item_action->setLibraryId($library_id);

				$item_action->setActionDate($currentTime);     //  ????
				$item_action->setFromLibraryId($item->getActualLibraryId());
				$item_action->setToLibraryId($item->getHomeLibraryId());

				if ($note != '')
					$item_action->setActionNote($note);

				$item_action->save();

				$item->setLoanStatus(ItemPeer::LOANSTATUS_TOSHELF); //'In rientro'
				$item->setLastSeen($currentTime);
				
				/* if we are in the case of an active management of item to another library, we have to
				 * update the delivery_library_id of the item, because the home_library_id can be
				 * subjectd to a change just under our nose.
				 * 
				 */
				if ((int) $item->getPrevHomeLibraryId() > 0)
					$item->setDeliveryLibraryId($item->getHomeLibraryId());

				$item->save();
			}

			return self::OK;
		}
		catch (Exception $e)
		{
			$e = $e;
			//Prado::log("Errore in DoReadyToMove2MovingItem(): ".Prado::varDump($e));
     		//throw $e;
     		return self::ERROR;
		}
	}

	/**
	 * Take the item from the moving status to the ready to loan status
	 *
	 * @param Item $item
	 * @param ClavisLibrarian $clavisLibrarian
	 */
	public function DoMoved2ReadyToLoanItem($item, $clavisLibrarian)
	{
		if (!($item instanceof Item))
			return false;

		if (!($clavisLibrarian instanceof ClavisLibrarian))
			return false;

		try
		{
			$currentTime = time();
			$deliveryLibraryId = $item->getDeliveryLibraryId();

			$library_id = $clavisLibrarian->getActualLibraryId();
			$librarian_id = $clavisLibrarian->getId();

			//item_action table
			$item_action = new ItemAction();
			$item_action->setActionType(ItemActionPeer::TYPE_READYFORLOAN);  //'Pronto al prestito'
			$item_action->setItemId($item->getItemId());

			$item_action->setPatronId($item->getPatronId());
			$item_action->setExternalLibraryId($item->getExternalLibraryId());

			$item_action->setLibrarianId($librarian_id);

			if (!is_null($library_id))
				$item_action->setLibraryId($library_id);

			$item_action->setActionDate($currentTime);     //  ????
			$item_action->setFromLibraryId($item->getActualLibraryId());
			$item_action->setToLibraryId($deliveryLibraryId);

			$item_action->save();

			//item edit
			$item->setLoanStatus(ItemPeer::LOANSTATUS_READYFORLOAN); //'Pronto al prestito'
			$item->setLastSeen($currentTime);  // 17-10-2008
			$item->setActualLibraryId($deliveryLibraryId); /// settato da mbrancalion, il 20-03-2007

			$item->setDueDate(null);  //$waitingDate);

			$item->save();

			//loan table
			$loan = LoanQuery::create()->findPK($item->getCurrentLoanId());
			if ($loan instanceof Loan)
			{
				$loan->setLoanStatus(ItemPeer::LOANSTATUS_READYFORLOAN); // 'Pronto al prestito'
				$loan->setDueDate(null);  ///$waitingDate);
				$loan->save();
			}

			return true;
		}
		catch (Exception $e)
		{
			return false;
		}

	}

	/**
	 * Take the item from the "ready to loan" status to the actual "in loan" status
	 *
	 * @param Item $item
	 * @param ClavisLibrarian $clavisLibrarian
	 * @param *nix timestamp : $dueDate
	 */
	public function DoReadyToLoan2LoanItem($item, $clavisLibrarian, $dueDate = null)
	{
		if (!($item instanceof Item))
			return false;

		if (!($clavisLibrarian instanceof ClavisLibrarian))
			return false;

		try
		{
			$currentTime = time();
			$itemId = $item->getItemId();
			$patron = $item->getPatron();
	
			if ($patron instanceof Patron)
			{
				$patronCheckReturn = self::IsPatronAllowedToLoan($patron, $itemId);
				
				if ($patronCheckReturn != self::OK)
					return $patronCheckReturn;
			/*
			 * the returnvalue LOAN_REACHEDMAX (per patron) now gets ignored, in the managerequest phase
			 */
			}

			$deliveryLibraryId = $item->getDeliveryLibraryId();
			$patronId = intval($item->getPatronId());
			$externalLibraryId = intval($item->getExternalLibraryId());
			
			if ($patronId > 0)
			{
				$isLoanExtra = false;            // Prestito intrasistema
			}
			elseif ($externalLibraryId > 0)		// Prestito extrasistema
			{
				$isLoanExtra = true;
			}
			else
			{
				return self::ERROR;		// nor item.patron_id not item.external_library_id means that
										// previous operations in loanmanager have not gone very well ...
			}

			$consultationFlag = $item->isStatusConsultation();

			//item_action table
			$item_action = new ItemAction();

			if ($consultationFlag)
			{
				$item_action->setActionType(ItemActionPeer::TYPE_CONSULTATION); // 'consultazione'
			}
			else
			{	
				$item_action->setActionType($isLoanExtra
											? ItemActionPeer::TYPE_EXTRALOAN
											: ItemActionPeer::TYPE_LOAN);
			}
			
			$item_action->setItemId($itemId);
			$item_action->setPatronId($patronId);
			$item_action->setExternalLibraryId($externalLibraryId);
			$item_action->setLibrarianId($clavisLibrarian->getId());

			//library_id
			$library_id = $clavisLibrarian->getActualLibraryId();
			
			if ($library_id != null)
				$item_action->setLibraryId($library_id);

			$item_action->setActionDate($currentTime);     //  ????
			$item_action->setFromLibraryId($item->getActualLibraryId());
			$item_action->setToLibraryId($deliveryLibraryId);

			$item_action->save();

			if ($consultationFlag)
			{
				$inLoanStatus = ItemPeer::LOANSTATUS_INCONSULTATION;
			}
			else
			{
				$inLoanStatus = $isLoanExtra      // in prestito
									? ItemPeer::LOANSTATUS_INLOANEXTRA
									: ItemPeer::LOANSTATUS_INLOAN;
			}

			//item edit
			$item->setLoanStatus($inLoanStatus);
			$item->setCheckOut($currentTime);
			$item->setLastSeen($currentTime);

			if (is_null($dueDate))
				$dueDate = self::CalculateDueDate($item, $item->getPatron());

			if ($dueDate == self::CALCULATEDATE_ERROR)
				self::throwCalculateDueDateError();

			$item->setDueDate($dueDate);
			$item->setNotifyCount(0);

			$item->save();

			//loan table
			$loan = LoanQuery::create()->findPK($item->getCurrentLoanId());

			if ($loan instanceof Loan)
			{
				$loan->setLoanStatus($inLoanStatus);   // 'In prestito'
				$loan->setDueDate($dueDate);
				$loan->setLoanDateBegin($item->getCheckOut());
				$loan->setNotifyCount(0);
				$loan->setNotifyAutoCount(0);

				$loan->save();
			}

			return true;
		}
		catch (Exception $e)
		{
     		return false;
		}
	}

	public function DoManageRequest($itemRequestParam, $clavisLibrarian)
	{
		if (is_null($clavisLibrarian) || !($clavisLibrarian instanceof ClavisLibrarian))
			return self::ERROR;

		$itemRequest = null;
		$itemRequestId = intval($itemRequestParam->getRequestId());
		if ($itemRequestId > 0)
			$itemRequest = ItemRequestQuery::create()->findPK($itemRequestId);
		if (!($itemRequest instanceof ItemRequest))
			return self::ERROR;

		$itemId = intval($itemRequest->getItemId());
		$patron = $itemRequest->getPatron();
		$externalLibrary = $itemRequest->getExternalLibrary();
		if ($patron instanceof Patron)
		{
			$patronCheckReturn = self::IsPatronAllowedToLoan($patron, $itemId);
			if ($patronCheckReturn != self::OK)
				return $patronCheckReturn;
		}
		elseif ($externalLibrary instanceof Library)
		{
			if (self::isExternalLibraryAllowedToLoan($externalLibrary->getLibraryId()) != self::OK)
				return self::LOAN_EXTERNALLIBRARYNOTENABLED;
		}

		$requestStatus = $itemRequest->getRequestStatus();

		if ( $requestStatus == ItemRequestPeer::STATUS_WORKING)
			return self::RSV_ALREADYMANAGED;

		if ($requestStatus == ItemRequestPeer::STATUS_DONE ||
			$requestStatus == ItemRequestPeer::STATUS_EXPIRED ||
			$requestStatus == ItemRequestPeer::STATUS_CANCELED)
			return self::RSV_ALREADYCLOSED;

		try
		{
			$librarianId = intval($clavisLibrarian->getID());
			if ($librarianId == 0)
				return self::ERROR;

			$updatedNum = ItemRequestQuery::create()
							->filterByRequestId($itemRequestId)
							->filterByLibrarianId(null, Criteria::ISNULL)
							->filterByRequestStatus(ItemRequestPeer::STATUS_PENDING)
							->update(array(	'RequestStatus' => ItemRequestPeer::STATUS_WORKING,
											'LibrarianId' => $librarianId), null, true);

			if ($updatedNum > 0)
			{
				ChangelogPeer::logAction($itemRequest, ChangelogPeer::LOG_UPDATE, $clavisLibrarian,
										"E'stata presa in gestione la prenotazione con id: {$itemRequest->getRequestId()}");

				return self::OK;
			}
			else
				return self::ERROR;

		}
		catch (Exception $e)
		{
			$e = $e;
			//Prado::log("Errore in DoManageManifestation(): ".Prado::varDump($e));
     		//throw $e;
     		return self::ERROR;
		}
	}

	public function DoUnManageRequest($itemRequestParam,
										$clavisLibrarian,
										$changelogText = '',
										$force = false) //   <--- does not check if same operator
	{
		$return = null;

		$itemRequest = null;
		$itemRequestId = intval($itemRequestParam->getRequestId());
		if ($itemRequestId > 0)
			$itemRequest = ItemRequestQuery::create()->findPK($itemRequestId);
		if (!($itemRequest instanceof ItemRequest))
			return self::ERROR;

		if (is_null($clavisLibrarian) || !($clavisLibrarian instanceof ClavisLibrarian))
			return self::ERROR;

		if ($itemRequest->getRequestStatus() != ItemRequestPeer::STATUS_WORKING)
			return self::RSV_NOTMANAGED;

		try
		{
			$librarianId = $clavisLibrarian->getId();
			if ($librarianId === $itemRequest->getLibrarianId() || $force)
			{
				$updatedNum = ItemRequestQuery::create()
				->filterByRequestId($itemRequestId)
				->update(array(	'RequestStatus' => ItemRequestPeer::STATUS_PENDING,
								'LibrarianId' => null), null, true);

				if ($updatedNum > 0)
				{
					if ($changelogText == '')
						$changelogText = "Cessazione di gestione della prenotazione con id: {$itemRequest->getRequestId()}";
					ChangelogPeer::logAction($itemRequest, ChangelogPeer::LOG_UPDATE, $clavisLibrarian, $changelogText);
					$return = self::OK;
				}
				else
					return self::ERROR;
			}
			else
			{
				$return  = self::RSV_UNMANAGENOTSAMEOPERATOR;
				//Prado::log("Errore in DoUnManageManifestation(): il librarian che vuole annullare il management non e' lo stesso che lo ha in gestione !!");
			}

			return $return;
		}
		catch (Exception $e)
		{
			$e = $e;
     		//throw $e;
     		return self::ERROR;
		}
	}

	/**
	 * Frees lengthy managed reservations.
	 *
	 * @param type $clavisLibrarian
	 * @return type
	 */
	public function ResetManagedReservations($clavisLibrarian = null)
	{
		if (is_null($clavisLibrarian))
			$clavisLibrarian = $this->getUser();

		if (!$clavisLibrarian instanceof ClavisLibrarian)
				return false;

		try
		{
			$expiretime = time() - intval(ClavisParamQuery::getParam('CLAVISPARAM','ReservationResetValue'));
			$q = ItemRequestQuery::create()
				->filterByRequestStatus(array(ItemRequestPeer::STATUS_WORKING))
				->filterByDateUpdated($expiretime, Criteria::LESS_THAN)
				->update(array(	'RequestStatus'	=> ItemRequestPeer::STATUS_PENDING,
								'LibrarianId'	=> null,
								'DateUpdated'	=> time(),
								'ModifiedBy'	=> $clavisLibrarian->getId()));

			if ($q > 0)
				ChangelogPeer::logAction("ItemRequest reset", ChangelogPeer::LOG_UPDATE, $clavisLibrarian,
					"{$q} prenotazioni 'in gestione' reimpostate in stato 'pendente'", 1);

			return true;
		}
		catch (Exception $e)
		{
			$e = $e;
			// throw $e;
			return false;
		}
	}

	/**
	 * Set expired reservations to expired status.
	 *
	 * @param ClavisLibrarian $clavisLibrarian
	 * @return boolean
	 */
	public function ResetExpiredReservations($clavisLibrarian = null)
	{
		if (is_null($clavisLibrarian))
			$clavisLibrarian = $this->getUser();

		if (!$clavisLibrarian instanceof ClavisLibrarian)
			return false;

		try
		{
			$q = ItemRequestQuery::create()
				->filterByRequestStatus(ItemRequestPeer::getActiveStatus())
				->filterByExpireDate(time(), Criteria::LESS_THAN)
				->update(array(
					'RequestStatus'	=> ItemRequestPeer::STATUS_EXPIRED,
					'LibrarianId'	=> null,
					'DateUpdated'	=> time(),
					'ModifiedBy'	=> $clavisLibrarian->getId()));
			if ($q > 0)
				ChangelogPeer::logAction('ItemRequest', ChangelogPeer::LOG_UPDATE, $clavisLibrarian,
					"Aggiornate {$q} prenotazioni scadute",1);
			return true;
		}
		catch (Exception $e)
		{
			$e = $e;
			// throw $e;
     		return false;
		}
	}

	public function IsItemOutOfHome($item)
	{
		if (!($item instanceof Item))
			return self::ERROR;

		$output = $item->isOutOfHome();
		if ($output === null)
			return self::ERROR;
		else
			return $output;
	}

	public function IsItemOutOfSystem($item)
	{
		if (!($item instanceof Item))
			return self::ERROR;

		$output = $item->isOutOfSystem();
		if ($output === null)
			return self::ERROR;
		else
			return $output;
	}

	/**
	 *
	 * @param int $actualLibraryId
	 * @param boolean $localFlag
	 * @param boolean $managedFlag
	 * @param boolean $ignoreConsultationsFlag
	 * @param Criteria $criteria
	 * @param string $type  <-- it can be "Regular" or "OocMode"
	 * @return Criteria
	 */
	public function CalculateReservationCriteria(	$actualLibraryId = null,
													$localFlag = null,
													$managedFlag = null,

													$ignoreConsultationsFlag = false,
													$criteria = null,
													$type = 'Regular' )
	{
		$actualLibraryId = intval($actualLibraryId);

		if (!($criteria instanceof Criteria))
			$criteria = new Criteria();

		if ($type == 'Regular')
		{
			$criteria->addJoin(	ItemRequestPeer::MANIFESTATION_ID,
								ItemPeer::MANIFESTATION_ID,
								Criteria::INNER_JOIN);

			///////$criteria->addAnd( ItemRequestPeer::MANIFESTATION_ID, 0, Criteria::GREATER_THAN);
			
		}	
		elseif ($type == 'OocMode')   // solo fuori catalogo
		{	
			$criteria->addJoin(	ItemRequestPeer::ITEM_ID,
								ItemPeer::ITEM_ID,
								Criteria::INNER_JOIN);
			
			//////$criteria->addAnd( ItemPeer::MANIFESTATION_ID, 0, Criteria::EQUAL);
		}
		else
			return $criteria;   // we won't do anything

		$criteria->addAnd(	ItemPeer::LOAN_STATUS,
							ItemPeer::getLoanStatusAvailable(),
							Criteria::IN);

		$criteria->addAnd(	ItemRequestPeer::ISSUE_ID,
							"( (" . ItemRequestPeer::ISSUE_ID . "=" . ItemPeer::ISSUE_ID .
										" AND " . ItemPeer::ISSUE_STATUS  . "='" . ItemPeer::ISSUESTATUS_ARRIVED . "')
									OR " . ItemRequestPeer::ISSUE_ID  . " IS NULL
									OR " . ItemPeer::ISSUE_ID . " IS NULL)",
							Criteria::CUSTOM);

		if ($actualLibraryId > 0)
		{
			$criterionClass = $criteria->getNewCriterion(	ItemPeer::LOAN_CLASS,
															ItemPeer::getLoanClassesAvailable(),
															Criteria::IN );
			if ($localFlag === true)
				$criteria->addAnd(	ItemPeer::ACTUAL_LIBRARY_ID,
									$actualLibraryId );

			elseif ($localFlag === false)
				$criteria->addAnd(	ItemPeer::ACTUAL_LIBRARY_ID,
									$actualLibraryId,
									Criteria::NOT_EQUAL );

			if ($ignoreConsultationsFlag)
				$criterionLocalClass = $criteria->getNewCriterion(	ItemPeer::LOAN_CLASS,
																	ItemPeer::getLoanClassesLocallyAvailableIgnoringConsultations(),
																	Criteria::IN);
			else
				$criterionLocalClass = $criteria->getNewCriterion(	ItemPeer::LOAN_CLASS,
																	ItemPeer::getLoanClassesLocallyAvailable(),
																	Criteria::IN );

			$criterionLocalClassLibrary = $criteria->getNewCriterion(	ItemRequestPeer::DELIVERY_LIBRARY_ID,
																		$actualLibraryId);
			$criterionLocalClass->addAnd($criterionLocalClassLibrary);

			$criterionClass->addOr($criterionLocalClass);
			$criteria->add($criterionClass);
		}

		if (!is_null($managedFlag))
		{
			if ($managedFlag == true)
			{
				$criteria->add(ItemRequestPeer::REQUEST_STATUS,ItemRequestPeer::STATUS_WORKING);

				$librarianId = $this->getUser()->getId();
				if ($librarianId > 0)
					$criteria->addAnd(ItemRequestPeer::LIBRARIAN_ID,
										$librarianId);
			}
			else
				$criteria->add(ItemRequestPeer::REQUEST_STATUS,ItemRequestPeer::STATUS_PENDING);
		}
		else
			$criteria->add(	ItemRequestPeer::REQUEST_STATUS,
							ItemRequestPeer::getActiveStatus(),
							Criteria::IN);

		$criteria->setDistinct();

		$criteria->addJoin(ItemRequestPeer::DELIVERY_LIBRARY_ID,
			LibraryPeer::LIBRARY_ID,
			Criteria::INNER_JOIN);

		$criteria->addAnd(LibraryPeer::LIBRARY_STATUS,LibraryPeer::STATUS_ACTIVE);

		return $criteria;
	}


	/**
	 * It returns the number of itemrequests, filtered by library (or actual library
	 * if not specified).
	 *
	 *
	 * @param int $fromLibraryIdFilter	Library, who can fullfil the requests. Default = mine
	 * @param string $objectType	'Item'|'Manifestation' (def. all)
	 * @param int $objectId			(id of above object)
	 * @param boolean $localFlag	It specifies requests i can satisfy. Default false
	 * @param boolean $managed		Returns only pending (false) or managed (true) requests.
	 * 								If null (= default) it specifies the sum of these two.
	 * @param string $type   <-- it cab be "Regular" or "OocMode"
	 * @return int	Number of found requests.
	 */
	public function CountRequests(	$fromLibraryIdFilter = null,
									$objectType = '',
									$objectId = null,

									$localFlag = false,
									$managed = null,
									$type = 'Regular')
	{
		$fromLibraryIdFilter = intval($fromLibraryIdFilter);
		if (!($fromLibraryIdFilter > 0))
			$fromLibraryIdFilter = $this->getUser()->getActualLibraryId();

		$objectId = intval($objectId);

		$criteria = self::CalculateReservationCriteria(	$fromLibraryIdFilter,
														$localFlag,
														$managed,
														null,
														null,
														$type );

		if ($objectId > 0)
		{
			switch ($objectType)
			{
				case 'Manifestation':
					$criteria->addAnd(ItemRequestPeer::MANIFESTATION_ID, $objectId);
					break;

				case 'Item':
					$criteria->addAnd(ItemRequestPeer::ITEM_ID, $objectId);
					break;

				case 'Issue':
					$criteria->addAnd(ItemRequestPeer::ISSUE_ID, $objectId);
					break;

				default:
					break;
			}
		}

		return ItemRequestPeer::doCount($criteria);
	}

	public function GetRequestedObjects(	$fromLibraryIdFilter = null,
											$objectType = '',
											$objectId = null,

											$managed = null,
											$criteria = null,
											$issue_id = null )
	{
		$objectId = intval($objectId);
		if (is_null($fromLibraryIdFilter))
			$fromLibraryIdFilter = $this->getUser()->getActualLibraryId();

		if (is_null($criteria))
			$criteria = new Criteria();

		$issue_id = intval($issue_id);

		if ($objectId > 0)
		{
			switch ($objectType)
			{
				case 'Manifestation':
					$criteria->addJoin(ItemRequestPeer::MANIFESTATION_ID, ItemPeer::MANIFESTATION_ID, Criteria::INNER_JOIN);
					$criteria->addAnd(ItemRequestPeer::MANIFESTATION_ID, $objectId);

					if ($issue_id > 0)
						$criteria->addAnd(ItemPeer::ISSUE_ID, $issue_id);

					return ItemPeer::doSelect($criteria);
					break;

				case 'OocMode':
					$criteria->addAnd(ItemPeer::ITEM_ID, $objectId);
					$criteria->addAnd(ItemPeer::MANIFESTATION_ID, 0);	// was checking if null .....

					return ItemPeer::doSelect($criteria);
					break;

				case 'Item':
					$criteria->addAnd(ItemRequestPeer::ITEM_ID, $objectId);

//					if ($issue_id > 0)
//						$criteria->addAnd(ItemRequestPeer::ISSUE_ID, $objectId);

					return ItemPeer::doSelect($criteria);
					break;

				case 'Issue':
					$criteria->addJoin(ItemRequestPeer::ISSUE_ID, IssuePeer::ISSUE_ID, Criteria::INNER_JOIN);
					$criteria->addAnd(ItemPeer::ISSUE_ID, $objectId);

					return ItemPeer::doSelect($criteria);
					break;

				default:
					return ItemRequestPeer::doSelect($criteria);
					break;
			}

		}
		else
			return array();
	}

	public function CountRequestedObjects(	$fromLibraryIdFilter = null,
												$objectType = '',
												$objectId = null,

												$managed = null,
												$criteria = null,
												$issue_id = null)
	{
		$objectId = intval($objectId);
		if (is_null($fromLibraryIdFilter))
			$fromLibraryIdFilter = $this->getUser()->getActualLibraryId();

		if (is_null($criteria) && !($criteria instanceof Criteria))
			$criteria = new Criteria();

		$issue_id = intval($issue_id);

		if ($objectId > 0)
		{
			switch ($objectType)
			{
				case 'Manifestation':
					$criteria->addJoin(ItemRequestPeer::MANIFESTATION_ID, ItemPeer::MANIFESTATION_ID, Criteria::INNER_JOIN);
					$criteria->addAnd(ItemRequestPeer::MANIFESTATION_ID, $objectId);

					if ($issue_id > 0)
						$criteria->addAnd(ItemPeer::ISSUE_ID, $issue_id);

					return ItemPeer::doCount($criteria);
					break;

				case 'OocMode':
					$criteria->addAnd(ItemPeer::ITEM_ID, $objectId);
					$criteria->addAnd(ItemPeer::MANIFESTATION_ID, 0);	// was checking if null

					return ItemPeer::doCount($criteria);
					break;

				case 'Item':
					$criteria->addAnd(ItemRequestPeer::ITEM_ID, $objectId);

					if ($issue_id > 0)
						$criteria->addAnd(ItemRequestPeer::ISSUE_ID, $issue_id);

					return ItemPeer::doCount($criteria);
					break;

				case 'Issue':
					$criteria->addAnd(ItemRequestPeer::ISSUE_ID, $objectId);

					return ItemPeer::doCount($criteria);
					break;

				default:
					return ItemRequestPeer::doCount($criteria);
					break;
			}
		}
		else
			return 0;
	}

	/**
	 * It updates the current $loan with statistical information
	 *
	 * @param Loan $loan
	 * @param Patron $patron
	 * @param Item $item
	 * @return Loan
	 */
	private function updateLoanForStatistics(	$loan,
												$patron,
												$item )
	{
		if (($patron instanceof Patron)
				&& ($loan instanceof Loan))
		{
			$patron_age = $patron->getPatronAge();
			if (!is_null($patron_age))
				$loan->setPatronAge($patron_age);

			$loan->setPatronCity($patron->getPatronCity());
		}
		//TODO: complete for $item

		return $loan;
	}

	/**
	 * Returns a list of item_request_id ready to be matched
	 * by a Library
	 *
	 * @param int $library_id
	 * @param int $limit
	 * @param int $offset
	 * @param string $sortFiled
	 * @param string $sortDirection
	 */
	public function GetReadyItemRequests(	$library_id,
											$limit,
											$offset,
											$sortFiled,
											$sortDirection)
	{
		$con = Propel::getConnection();

		$requestStatus = "'".join("','",  ItemRequestPeer::STATUS_PENDING)."'";
		$itemLStatus   = "'".join("','",ItemPeer::getLoanStatusAvailable())."'";
		$itemLClass    = "'".join("','",ItemPeer::getLoanClassesAvailable())."'";
		$itemLClassLoc = "'".join("','",ItemPeer::getLoanClassesLocallyAvailable())."'";

		$sql = ("SELECT r.request_id, r.manifestation_id, i.collocation, i.item_id, i.actual_library_id, i.home_library_id, r.delivery_library_id, r.request_date FROM item_request r JOIN item i ON i.manifestation_id = r.manifestation_id WHERE r.request_status IN ($requestStatus) AND i.loan_status IN ($itemLStatus) AND (i.loan_class IN($itemLClass) OR (i.loan_class IN($itemLClassLoc) AND r.delivery_library_id = i.home_library_id) ) AND i.actual_library_id = $library_id ORDER BY r.manifestation_id, r.request_date, i.item_id");
		$pdo = $con->prepare($sql);
		$pdo->execute();

		$resultRequestIds = array();
		$itemMatched = array();
		$prevManifId = 0;

		while($row = $pdo->fetch())
		{
			/* First item_request is the first to serve */
			if($prevManifId != $row['r.manifestation_id'])
			{
				$prevManifId = $row['r.manifestation_id'];
				$resultRequestIds[] = $row['r.request_id'];
				$itemMatched[] = $row['i.item_id'];

			} else if(in_array($row['r.request_id'],$resultRequestIds ) AND
			          in_array($row['i.item_id'],$itemMatched ) ) {
				/* If new request is new and item wasn't used before  then add it*/

				$resultRequestIds[] = $row['r.request_id'];
				$itemMatched[] = $row['i.item_id'];
			}
		}

		return $resultRequestIds;
	}

	public function putLostToAvailableItem($itemId = null)
	{
		$returnMessage = array();
		$itemId = intval($itemId);
		if ($itemId > 0)
		{
			$item = ItemQuery::create()
						->findPK($itemId);
			if ($item instanceof Item)
			{
				$itemtit = trim($item->getCompleteTitle());
				if ($itemtit == '')
					$itemtit = '(' . Prado::localize('nessun titolo') . ')';

				try
				{
					if (in_array($item->getItemStatus(), ItemPeer::getItemStatusLost()))
					{
						$item->setItemStatus(ItemStatus::ITEMSTATUS_ONSHELF);
						$item->setLoanClass(ItemPeer::LOANCLASS_AVAILABLE);
						$item->setOpacVisible(true);
						$item->setLastSeen(time());
						$item->save();


						$returnMessage = array(Prado::localize("Attenzione: l'esemplare '{tit}' [inv: {inv}] che era in stato di SMARRITO viene passato in stato disponibile in quanto ritrovato",
																			array('tit' => $itemtit, 'inv' => $item->getCompleteInventoryNumber())),
														ClavisMessage::INFO);

						ChangelogPeer::logAction($item,
								ChangelogPeer::LOG_UPDATE,
								$this->getUser(),
								$returnMessage[0]);
					}
				}
				catch (Exception $e)
				{
					$e = $e;
					//throw $e;
					$returnMessage = array(Prado::localize("Attenzione: l'esemplare '{tit}' [inv: {inv}] che era in stato di SMARRITO non viene passato in stato disponibile a causa di un errore",
																			array('tit' => $itemtit, 'inv' => $item->getCompleteInventoryNumber())),
													ClavisMessage::ERROR);
				}
			}
		}

		return $returnMessage;
	}

	public function doDisableRenew($itemId, $clavisLibrarian)
	{
		$item = null;
		$itemId = intval($itemId);
		if ($itemId > 0)
			$item = ItemQuery::create()
						->findPK($itemId);
		if (is_null($item))
			return self::ERROR;

		if (!$item->IsLoaned())
			return self::ERROR;

		if (is_null($clavisLibrarian))
			$clavisLibrarian = $this->getUser();
		if (!($clavisLibrarian instanceof ClavisLibrarian))
			return self::ERROR;

		try
		{
			$currentTime = time();

			//item_action table
			$item_action = new ItemAction();
			$item_action->setActionType(ItemActionPeer::TYPE_DISABLERENEWAL); //'sospensione di rinnovo'
			$item_action->setItemId($itemId);
			$item_action->setLibrarianId($clavisLibrarian->getId());

			if ($item->getActualLibrary() instanceof Library)
				$item_action->setLibraryId($item->getActualLibraryId());

			$item_action->setActionDate($currentTime);
			$item_action->save();

			$newRenewValue = ItemPeer::encodeRenew($item->getRenewalCount());

			//item edit
			$item->setRenewalCount($newRenewValue);
			$item->setLastSeen($currentTime);

			$item->save();

			//loan table
			$loan = LoanQuery::create()->findPK($item->getCurrentLoanId());
			if ($loan instanceof Loan)
			{
				$loan->setRenewCount($newRenewValue);
				$loan->save();
			}

			return self::OK;
		}
		catch (Exception $e)
		{
			return self::ERROR;
		}
	}

	public function doEnableRenew($itemId, $clavisLibrarian)
	{
		$item = null;
		$itemId = intval($itemId);
		if ($itemId > 0)
			$item = ItemQuery::create()->findPK($itemId);
		if (is_null($item))
			return self::ERROR;

		if (is_null($clavisLibrarian))
			$clavisLibrarian = $this->getUser();
		if (!($clavisLibrarian instanceof ClavisLibrarian))
			return self::ERROR;

		try
		{
			$currentTime = time();

			//item_action table
			$item_action = new ItemAction();
			$item_action->setActionType(ItemActionPeer::TYPE_ENABLERENEWAL); //'riabilitazione di rinnovo'
			$item_action->setItemId($itemId);
			$item_action->setLibrarianId($clavisLibrarian->getId());

			if ($item->getActualLibrary() instanceof Library)
				$item_action->setLibraryId($item->getActualLibraryId());

			$item_action->setActionDate($currentTime);
			$item_action->save();

			$newRenewValue = ItemPeer::decodeRenew($item->getRenewalCount());

			//item edit
			$item->setRenewalCount($newRenewValue);       //(intval(abs($item->getRenewalCount()) / 10));
			$item->setLastSeen($currentTime);
			$item->save();

			//loan table
			$loan = LoanQuery::create()->findPK($item->getCurrentLoanId());
			if ($loan instanceof Loan)
			{
				$loan->setRenewCount($newRenewValue);
				$loan->save();
			}

			return self::OK;
		}
		catch (Exception $e)
		{
			return self::ERROR;
		}
	}

	/**
	 *	It freezes an active local consultation of an item.
	 *
	 * @param int $itemId
	 * @param ClavisLibrarian $clavisLibrarian
	 *
	 * @return enum  (ClavisLoanManager return value)
	 */
	public function doFreezeConsultation($itemId, $clavisLibrarian)
	{
		$item = null;
		$itemId = intval($itemId);
		if ($itemId > 0)
			$item = ItemQuery::create()->findPK($itemId);
		if (is_null($item))
			return self::ERROR;

		if (is_null($clavisLibrarian))
			$clavisLibrarian = $this->getUser();
		if (!($clavisLibrarian instanceof ClavisLibrarian))
			return self::ERROR;

		try
		{
			$currentTime = time();
			$patronId = $item->getPatronId();

			//item_action table
			$item_action = new ItemAction();

			$item_action->setActionType(ItemActionPeer::TYPE_CONSULTSUSPEND); //'sospensione di consultazione'
			$item_action->setItemId($itemId);
			$item_action->setPatronId($patronId);
			$item_action->setLibrarianId($clavisLibrarian->getId());

			if ($item->getActualLibrary() instanceof Library)
				$item_action->setLibraryId($item->getActualLibraryId());

			$item_action->setActionDate($currentTime);     //  ????
			$item_action->save();

			//item edit
			$item->setLoanStatus(ItemPeer::LOANSTATUS_INFREEZEDCONSULTATION); //'In sospensione di consultazione'
			$item->setLastSeen($currentTime);

			$item->setNotifyCount(0);
			$item->save();

			//loan table
			$loan = LoanQuery::create()->findPK($item->getCurrentLoanId());
			if (!is_null($loan))
			{
				$loan->setLoanStatus(ItemPeer::LOANSTATUS_INFREEZEDCONSULTATION); //'In sospensione di consultazione'
				$loan->setNotifyCount(0);
				$loan->setNotifyAutoCount(0);
				$loan->save();
			}

			return self::OK;
		}
		catch (Exception $e)
		{
			return self::ERROR;
		}
	}

	/**
	 *	It resumes an active local consultation of an item.
	 *
	 * @param int $itemId
	 * @param ClavisLibrarian $clavisLibrarian
	 *
	 * @return enum  (ClavisLoanManager return value)
	 */
	public function doResumeConsultation($itemId, $clavisLibrarian)
	{
		$item = null;
		$itemId = intval($itemId);
		if ($itemId > 0)
			$item = ItemQuery::create()->findPK($itemId);
		if (is_null($item))
			return self::ERROR;

		if (is_null($clavisLibrarian))
			$clavisLibrarian = $this->getUser();
		if (!($clavisLibrarian instanceof ClavisLibrarian))
			return self::ERROR;

		try
		{
			if ($item->getLoanStatus() != ItemPeer::LOANSTATUS_INFREEZEDCONSULTATION)
				return self::ERROR;

			$currentTime = time();
			$patronId = $item->getPatronId();

			$item_action = new ItemAction();

			$item_action->setActionType(ItemActionPeer::TYPE_CONSULTRESUME); // 'ripresa di consultazione'
			$item_action->setItemId($itemId);
			$item_action->setPatronId($patronId);
			$item_action->setLibrarianId($clavisLibrarian->getId());

			if ($item->getActualLibrary() instanceof Library)
				$item_action->setLibraryId($item->getActualLibraryId());

			$item_action->setActionDate($currentTime);     //  ????
			$item_action->save();

			$item->setLoanStatus(ItemPeer::LOANSTATUS_INCONSULTATION); // 'in consultazione'
			$item->setLastSeen($currentTime);

			$dueDate = self::CalculateDueDate($item);
			if ($dueDate == self::CALCULATEDATE_ERROR)
				self::throwCalculateDueDateError();

			$item->setDueDate($dueDate);
			$item->setNotifyCount(0);
			$item->save();

			$loan = LoanQuery::create()->findPK($item->getCurrentLoanId());
			if (!is_null($loan))
			{
				$loan->setLoanStatus(ItemPeer::LOANSTATUS_INCONSULTATION); // 'in consultazione'
				$loan->setDueDate($dueDate);
				$loan->setNotifyCount(0);
				$loan->setNotifyAutoCount(0);
				$loan->save();
			}

			return self::OK;
		}
		catch (Exception $e)
		{
			return self::ERROR;
		}
	}

	/**
	 * Esemplare arrivato da extrasistema, da mettere in prestito interno
	 */
	public function doAcceptFromExtra($item,
										$itemRequest,
										$clavisLibrarian = null )
	{
		if (!($item instanceof Item))
			return self::ERROR;

		if (!is_null($clavisLibrarian) && !($clavisLibrarian instanceof ClavisLibrarian))
			return self::ERROR;

		if (!($itemRequest instanceof ItemRequest))
			return self::ERROR;
		try
		{
			if (is_null($clavisLibrarian))
				$clavisLibrarian = $this->getUser();

			$currentTime = time();
			$myLibraryId = $clavisLibrarian->getActualLibraryId();
			$myId = $clavisLibrarian->getId();

			$deliveryLibraryId = $itemRequest->getDeliveryLibraryId();
			$itemId = $item->getItemId();
			$patronId = $itemRequest->getPatronId();
			$patron = PatronQuery::create()
						->findPK($patronId);
			$requestId = $itemRequest->getRequestId();

			if ($itemRequest->getRequestStatus() != ItemRequestPeer::STATUS_PENDING)
				return self::RSV_ALREADYCLOSED;

			$itemRequest->setRequestStatus(ItemRequestPeer::STATUS_DONE); //'Soddisfatta'
			ChangelogPeer::logAction($itemRequest, ChangelogPeer::LOG_UPDATE, $clavisLibrarian,
					"E' arrivato da extrasistema l'esemplare con id: {$itemId} ed e' stata automaticamente ".
					"soddisfatta la prenotazione con id: {$itemRequest->getRequestId()}");

			$itemRequest->save();

			/// accettazione esemplare extra dentro il nostro sistema
			$item_action = new ItemAction();
			$item_action->setActionType(ItemActionPeer::TYPE_EXTRAACCEPT);  //'Pronto al prestito'
			$item_action->setItemId($itemId);

			$item_action->setPatronId($patronId);
			$item_action->setExternalLibraryId(null);

			$item_action->setLibrarianId($myId);
			$item_action->setLibraryId($myLibraryId);

			$item_action->setActionDate($currentTime);
			$item_action->setFromLibraryId($item->getActualLibraryId());
			$item_action->setToLibraryId($myLibraryId);
			$item_action->save();

			if ($deliveryLibraryId == $myLibraryId)
			{
				// prestito interno
				$item_action = new ItemAction();
				$item_action->setActionType(ItemActionPeer::TYPE_READYFORLOAN);  //'Pronto al prestito'
				$item_action->setItemId($itemId);

				$item_action->setPatronId($patronId);
				$item_action->setExternalLibraryId(null);

				$item_action->setLibrarianId($myId);
				$item_action->setLibraryId($myLibraryId);

				$item_action->setActionDate($currentTime);
				$item_action->setFromLibraryId($item->getActualLibraryId());
				$item_action->setToLibraryId($myLibraryId);
				$item_action->save();

				// loan table
				$loan = new Loan();
				$loan->setItemId($itemId);
				$loan->setItemOwnerLibraryId($item->getOwnerLibraryId());
				$loan->setItemHomeLibraryId($item->getHomeLibraryId());

				$loan->setLoanType(ItemPeer::LOANTYPE_EXTRASYSTEM);
				$loan->setPatronId($patronId);
				$loan->setDestinationName($patron->getCompleteName());

				$loan->setExternalLibrary(null);
				$loan->setTitle($item->getTitle());
				$loan->setManifestationId(0);
				$loan->setInvNumber($item->getInventorySerieId() . "-" . $item->getInventoryNumber());
				$loan->setCollocation($item->getCollocation());
				$loan->setItemMedia($item->getItemMedia());
				$loan->setFromLibrary($myLibraryId);
				$loan->setToLibrary($myLibraryId);
				$loan->setItemInventoryDate($item->getInventoryDate('U'));
				$loan = self::updateLoanForStatistics($loan, $patron, $item);
				$loan->setLoanDateBegin($item->getCheckOut());
				$loan->setLoanDateEnd(null);
				$loan->setEndLibrary(null);  //to be set in return item
				$loan->setRenewCount(0);
				$loan->setNotifyCount(0);
				$loan->setNotifyAutoCount(0);

				$dueDate = self::CalculateDueDate($item, $patron);
				if ($dueDate == self::CALCULATEDATE_ERROR)
					self::throwCalculateDueDateError();
				$loan->setDueDate($dueDate);
				$loan->setItemrequestId(null);

				$loan->setLoanStatus(ItemPeer::LOANSTATUS_READYFORLOAN); // 'Pronto al prestito'
				$loan->setDueDate(null);
				$loan->setMediapackageSize($item->getMediapackageSize());

				$loan->save();

				// item table
				$item->setLoanStatus(ItemPeer::LOANSTATUS_READYFORLOAN); //'Pronto al prestito'
				$item->setLastSeen($currentTime);
				$item->setHomeLibraryId($myLibraryId);   // modifica ciriaca dal 08/03/2010
				$item->setActualLibraryId($myLibraryId);
				$item->setDueDate(null);
				$item->setCurrentLoanId($loan->getLoanId());
				$item->setIllTimestamp($itemRequest->getRequestDate());
				$item->setPatronId($patronId);
				$item->setExternalLibrary(null);
				$item->setCheckIn(null);
				$item->setCheckOut(null);
				$item->setRenewalCount(0);
				$item->setNotifyCount(0);
				$item->setDeliveryLibraryId($myLibraryId);

				$item->save();
			}
			else
			{
				// interprestito nel consorzio interno
				$item_action = new ItemAction();
				$item_action->setActionType(ItemActionPeer::TYPE_READYFORTRANSIT); //'pronto per il transito'
				$item_action->setItemId($itemId);
				$item_action->setPatronId($patronId);
				$item_action->setExternalLibrary(null);
				$item_action->setLibrarianId($myId);
				$item_action->setLibraryId($myLibraryId);

				$item_action->setActionDate($currentTime);
				$item_action->setFromLibraryId($myLibraryId);
				$item_action->setToLibraryId($deliveryLibraryId);

				$item_action->save();

				//item edit
				$item->setLoanStatus(ItemPeer::LOANSTATUS_READYFORTRANSIT); //'pronto al transito'
				$item->setLastSeen($currentTime);
				$item->setHomeLibraryId($myLibraryId);   // modifica ciriaca dal 08/03/2010
				$item->setActualLibraryId($myLibraryId);
				$item->setDeliveryLibraryId($deliveryLibraryId);
				$item->setIllTimestamp($itemRequest->getRequestDate());
				$item->setPatronId($patronId);
				$item->setNotifyCount(0);

				//loan table
				$loan = new Loan();
				$loan->setItemId($itemId);
				$loan->setItemOwnerLibraryId($item->getOwnerLibraryId());
				$loan->setItemHomeLibraryId($item->getHomeLibraryId());

				$loan->setLoanStatus(ItemPeer::LOANSTATUS_READYFORTRANSIT); // 'pronto al transito'
				$loan->setLoanType(ItemPeer::LOANTYPE_EXTRASYSTEM);
				$loan->setPatronId($patronId);
				$loan->setDestinationName($patron->getCompleteName());

				$loan->setExternalLibrary(null);
				$loan->setTitle($item->getTitle());
				$loan->setManifestationId(0);
				$loan->setInvNumber($item->getInventorySerieId() . "-" . $item->getInventoryNumber());
				$loan->setCollocation($item->getCollocation());
				$loan->setItemMedia($item->getItemMedia());
				$loan->setLoanDateBegin(null);
				$loan->setLoanDateEnd(null);
				$loan->setFromLibrary($myLibraryId);
				$loan->setToLibrary($deliveryLibraryId);
				$loan->setEndLibrary(null);  //to be set in return item
				$loan->setRenewCount(0);
				$loan->setNotifyCount(0);
				$loan->setNotifyAutoCount(0);
				$loan->setDueDate(null);
				$loan->setItemrequestId($requestId);
				$loan->setMediapackageSize($item->getMediapackageSize());

				$loan = $this->updateLoanForStatistics($loan, $patron, $item);
				$loan->save();

				$loanId = $loan->getLoanId();
				$item->setCurrentLoanId($loanId);
				$item->save();
			}

			return self::OK;
		}
		catch (Exception $e)
		{
			$e = $e;
			//throw $e;
     		return self::ERROR;
		}
	}

	public function doExtraGoHome($item, $clavisLibrarian = null)
	{
		if (!($item instanceof Item))
			return self::ERROR;

		if (is_null($clavisLibrarian))
				$clavisLibrarian = $this->getUser();
		if (!($clavisLibrarian instanceof ClavisLibrarian))
			return self::ERROR;

		try
		{
			$myLibraryId = $clavisLibrarian->getActualLibraryId();
			$currentTime = time();

			$item->setLoanStatus(ItemPeer::LOANSTATUS_AVAILABLEEXTRA); // nel suo consorzio extra
			$item->setCheckOut(null);
			$item->setLastSeen($currentTime);
			$item->setDueDate(null);
			$item->setPatronId(null);
			$item->setUsageCount($item->getUsageCount() + 1);
			$item->setRenewalCount(0);
			$item->setNotifyCount(0);
			//$item->setCurrentLoanId(null); //DA NON SBIANCARE, per sapere l'ultimo prestito che ho fatto e quindi in che biblioteca e' rientrato (per semplificare la gestione delle prenotazioni senza rientrare alla actuallibrary...), quindi in realta' e' un 'last' e non 'current'
			$item->setActualLibraryId($item->getOwnerLibraryId());    //// ATTENZIONE: rimessa la actual alla sua owner
			$item->setHomeLibraryId($item->getOwnerLibraryId());  // modifica ciriaca del 08/03/2010, per considerare l'item prestabile extrasistemente
			$item->save();

			$item_action = new ItemAction();
			$item_action->setActionDate(time());
			$item_action->setActionType(ItemActionPeer::TYPE_EXTRAGOHOME);   // a casa extra
			$item_action->setItemId($item->getItemId());
			$item_action->setPatronId(null);

			$item_action->setFromLibraryId($myLibraryId);
			$item_action->setToLibraryId($item->getOwnerLibraryId());

			$item_action->setLibraryId($myLibraryId);
			$item_action->setLibrarianId($clavisLibrarian->getId());
			$item_action->save();

			return self::OK;
		}
		catch (Exception $e)
		{
			$e = $e;
     		//throw $e;
     		return self::ERROR;
		}
	}

	public function getLoanDestinationObject($source)
	{
		$return = null;

		if ($source instanceof Item)
		{
			$ret = $source->getPatron();
			if ($ret instanceof Patron)
				$return = $ret;
			else
			{
				$ret = $source->getExternalLibrary();
				if ($ret instanceof Library)
				$return = $ret;
			}
		}
		elseif ($source instanceof Loan)
		{
			$ret = $source->getPatron();
			if ($ret instanceof Patron)
				$return = $ret;
			else
			{
				$ret = $source->getExternalLibrary();
				if ($ret instanceof Library)
				$return = $ret;
			}
		}

		return $return;
	}

	/**
	 * We output an array made as (distance => items number), calculated
	 * as the number of items that are present in the system, divided
	 * in distances according with the starting distance (that would occur
	 * in a loan) from the home of the item and the ending distance as my
	 * own library.
	 *
	 * @param type $manifestationId
	 * @param type $issueId
	 *
	 * @return associative array (distance => array(AVAILABLE items count, ALL items count))
	 */
	public function countAvailableItemsByBasin(	$manifestationId,
												$issueId = null )
	{
		// in progress
		$output = array();

		if (intval($manifestationId) > 0)
		{
			$myLibraryId = $this->getUser()->getActualLibraryId();
			$queryParam = array('myLibraryId' => $myLibraryId);
			$queryParam['manifestationId'] = $manifestationId;

			$issueId = intval($issueId);
			if ($issueId > 0)
			{
				$issueSubqueryString = "AND i.issue_id IS NOT NULL "
										. "AND i.issue_id = :issueId ";

				$queryParam['issueId'] = $issueId;
			}
			else
			{
				$issueSubqueryString = "";
			}

			$queryStringStart = "SELECT COUNT(i.item_id) as itemCount, l.distance as outputdistance "
									. "FROM item i JOIN l_library l ON  l.from_library_id = i.home_library_id "
									. " WHERE l.to_library_id = :myLibraryId "
										. "AND i.manifestation_id IS NOT NULL "
									//	. "AND i.actual_library_id = $myLibraryId "
										. "AND i.manifestation_id = :manifestationId "

										//. "AND i.LOAN_CLASS IN ('" . implode(ItemPeer::getLoanClassesAvailable(), "','") . "')"
										. "AND i.ITEM_STATUS IN ('" . implode(ItemPeer::getItemStatusVisible(), "','") . "')";

			$queryStringEnd =	$issueSubqueryString
									. " group by outputdistance order by outputdistance;";

			$queryString1 = $queryStringStart . $queryStringEnd;

			$connection = Propel::getConnection();
			$stmt1 = $connection->prepare($queryString1);
			$stmt1->execute($queryParam);

			$allItemsArray = array();
			while ($row = $stmt1->fetch(PDO::FETCH_ASSOC))
				$allItemsArray[$row['outputdistance']] = $row['itemCount'];

			$itemStatusQuery = "AND i.LOAN_CLASS IN ('"
								. implode(array_merge(ItemPeer::getLoanClassesAvailable(true),
														 ItemPeer::getLoanClassesLocallyAvailable(true)), "','") . "')";
			$loanStatusQuery = " AND i.LOAN_STATUS IN ('" . implode(ItemPeer::getLoanStatusAvailable(), "','") . "')";
			$queryString2 = $queryStringStart
								. $itemStatusQuery
								. $loanStatusQuery
								. $queryStringEnd;

			$stmt2 = $connection->prepare($queryString2);
			$stmt2->execute($queryParam);

			$availableItemsArray = array();
			while ($row = $stmt2->fetch(PDO::FETCH_ASSOC))
				$availableItemsArray[$row['outputdistance']] = $row['itemCount'];

			for ($distance = 0; $distance <= LLibraryPeer::getMaxLLibraryDistance(); $distance++)
			{
				$availableCount = 0;
				$allCount = 0;

				if (array_key_exists($distance, $availableItemsArray))
					$availableCount = (int)$availableItemsArray[$distance];

				if (array_key_exists($distance, $allItemsArray))
					$allCount = (int)$allItemsArray[$distance];

				if (($availableCount > 0 ) || ($allCount > 0))
					$output[$distance] = array($availableCount, $allCount);
			}
		}

		return $output;
	}

	/**
	 * Returns some stats on a manifestation's items
	 *
	 * @param Manifestation $manifestation
	 * @return array
	 */
	public function extractItemStats(Manifestation $manifestation)
	{
		if (!($manifestation instanceof Manifestation) || !$manifestation->canHaveItems())
			return array(	'Items' => '-',
							'ItemsDetail' => '-',
							'AvailItems' => '-',
							'AvailDetail' => '-',
							'MyColl' => '' );

		$myLibraryId = Prado::getApplication()->getUser()->getActualLibraryId();

		if (LLibraryPeer::isEnabled())		// if BASIN circulation is enabled
		{
			$availableItemsArray = array();
			$allItemsArray = array();
			$itemsRaw = self::countAvailableItemsByBasin($manifestation->getManifestationId());
			$basinLimit = LLibraryPeer::getMaxLLibraryBasin();
			for ($distance = 0; $distance <= LLibraryPeer::getMaxLLibraryDistance(); $distance++)
			{
				$availableItemsCount = 0;
				$allItemsCount = 0;

				if (array_key_exists($distance, $itemsRaw))
				{
					$data = $itemsRaw[$distance];
					if (count($data) == 2)
						list($availableItemsCount, $allItemsCount) = $data;
				}

				if ($distance > $basinLimit)
					$index = $basinLimit + 1;
				else
					$index = $distance;

				if (array_key_exists($index, $availableItemsArray))
					$availableItemsArray[$index] += $availableItemsCount;
				else
					$availableItemsArray[$index] = $availableItemsCount;

				if (array_key_exists($index, $allItemsArray))
					$allItemsArray[$index] += $allItemsCount;
				else
					$allItemsArray[$index] = $allItemsCount;
			}

			$availItems = implode('/', $availableItemsArray);
			$itemsString = implode('/', $allItemsArray);

			$availDetail = "";
			foreach($availableItemsArray as $distance => $count)
				$availDetail .=	ItemRequestPeer::getCompleteMaxDistance($distance, true, true) . ": " . $availableItemsArray[$distance] . "<br />";

			$itemsDetail = "";
			foreach($allItemsArray as $distance => $count)
				$itemsDetail .=	ItemRequestPeer::getCompleteMaxDistance($distance, true, true) . ": " . $allItemsArray[$distance] . "<br />";

			$myItem = ItemQuery::create()
				->filterByManifestation($manifestation)
				->filterByItemStatus(ItemPeer::getItemStatusVisible())
				->findOneByHomeLibraryId($myLibraryId);
			$myColl = $myItem instanceof Item
				? $myItem->getCollocationCombo()
				: '';
			// request block
			//$requestmanager = Prado::getApplication()->getModule('request');

			/*$requestsCount = $requestmanager->countRequests($myLibraryId,
															null,
															null,
															$manifestation->getManifestationId() );*/

			$requestsCount = ItemRequestQuery::create()
				->filterByManifestation($manifestation)
				->filterByRequestStatus(ItemRequestPeer::getActiveStatus())
				->count();
			$availItems .= "&nbsp;({$requestsCount})";
			$availDetail .=	 "<br />". Prado::localize('prenotazioni') . ": " . $requestsCount;
		}
		else	// no basin case (old normal case)
		{
			$items = ItemQuery::create()
				->filterByManifestation($manifestation)
				->filterByItemStatus(ItemPeer::getItemStatusVisible());
			$totItems = $items->count();
			$itemMyAvailable = 0;
			$itemGlobAvailable = 0;
			$itemsArray = array();
			$myColl = '';

			foreach ($items->find() as $item)
			{
				if (!$myColl && $item->getHomeLibraryId() == $myLibraryId)
					$myColl = $item->getCollocationCombo();

				if ((self::IsItemAvailable($item, $myLibraryId) == self::OK)
							&& $item->getActualLibraryId() == $myLibraryId)
					$itemMyAvailable++;
				
				if (self::IsItemAvailable($item) == self::OK)
					$itemGlobAvailable++;

				$library = $item->getLibraryRelatedByHomeLibraryId();
				if ($library instanceof Library)
				{
					if (array_key_exists($library->getLabel(), $itemsArray))
						$itemsArray[$library->getLabel()]++;
					else
						$itemsArray[$library->getLabel()] = 1;
				}
			}

			$itemsDetail = "";
			ksort($itemsArray);
			foreach ($itemsArray as $libraryLabel => $itemCount)
				$itemsDetail .= htmlspecialchars($libraryLabel) . ": $itemCount <br />";

			$requestsCount = ItemRequestQuery::create()
								->filterByManifestation($manifestation)
								->filterByRequestStatus(ItemRequestPeer::STATUS_PENDING)
								->count();

			$availItems = "$itemMyAvailable/$itemGlobAvailable/$requestsCount";
			$availDetail = Prado::localize("Disponibili in biblioteca") . ": $itemMyAvailable<br />"
							. Prado::localize("Disponibili nel sistema") . ": $itemGlobAvailable<br />"
							. Prado::localize("Prenotazioni in coda") . ": $requestsCount";
			
			$iCount = ItemQuery::create()
						->filterByManifestation($manifestation)
						->filterByHomeLibraryId($myLibraryId)
						->filterByItemStatus(ItemPeer::getItemStatusVisible())
						->count();

			$itemsString = "{$iCount}/{$totItems}";
		}	// end of no basin case

		return array(	'AvailItems' => $availItems,		// testo overlib di es. disponibili (sinistra)
						'AvailDetail' => $availDetail,		// contenuto interno overlib di cui sopra (sinistra)

						'MyColl' => $myColl,				// collocazione di uno del primo item della man. (pero' fra i visibili)

						'Items' => $itemsString,			// testo overlib di tutti es. (a destra)
						'ItemsDetail' => $itemsDetail );
			
						//'ResultArray' => $resultArray );	// contenuto interno overlib di cui sopra (destra)
	}

	public function getExtraSystemNodeLibrary()
	{
		$nodeLibrary = null;
		$nodeLibraryId = self::getExtraSystemNodeLibraryId();
		if ($nodeLibraryId > 0)
		{
			$nodeLibrary = LibraryPeer::retrieveByPK($nodeLibraryId);
			if ($nodeLibrary instanceof Library)
			{
				if ($nodeLibrary->isExternal())
				{
					$this->getPage()->writeMessage(Prado::localize("La biblioteca indicata come nodo per i prestiti extrasistema è esterna al consorzio.<br />Contattare l'assistenza."),
													ClavisMessage::ERROR);
					$nodeLibrary = null;
				}
			}
			else
			{
				$this->getPage()->writeMessage(Prado::localize("Attenzione: la biblioteca indicata come nodo per i prestiti extrasistema non esiste.<br />Contattare l'assistenza."),
												ClavisMessage::ERROR);
				$nodeLibrary = null;
			}
		}

		return $nodeLibrary;
	}

	public function getExtraSystemNodeLibraryId()
	{
		return intval(ClavisParamPeer::getParam('EXTRASYSTEMNODELIBRARY'));
	}
	
}
