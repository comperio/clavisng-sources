<?php
/**
 * ClavisLibrarian class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Dario Rigolin <dario@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Core
 */
Prado::using('System.Security.TUser');

/**
 * ClavisLibrarian Class
 *
 * @author Dario Rigolin <dario@comperio.it>
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.8.9
 * @package Core
 * @since 2.0
 */
class ClavisLibrarian extends TUser
{

	const SYSTEM_USER = 1;
	const ADMIN_LABEL = 'ADMIN';
	const DIRECTOR_LABEL = 'RESPONSABILE';
	const SUPERADMIN_USERNAME = 'comperio';
	const SUPERADMIN_LABEL = 'SUPERADMIN';

	private $_aclInfo;
	private $_authPages;
	//private $_authPlugins;
	private $_moduleView;
	private $_libraryID;
	private $_id;
	private $_libraries;
	private $_distanceHash;
	private $_actualLibraryId;
	private $_defaultLibraryId;
	private $_actualShelfId;
	private $_librarianSessionId;
    private $_minProfileId;
	private $_profilesControl;
    private $_profileLabel;

	public function getId()
	{
		return $this->_id;
	}

	public function setId($value)
	{
		$this->_id = $value;
	}

	public function getLibrarian()
	{
		$librarian = null;
		$id = intval($this->getId());
		
		if ($id > 0)
			$librarian = LibrarianQuery::create()->findPk($id);

		return $librarian;
	}

	public function getPrivacyAccepted()
	{
		$librarian = $this->getLibrarian();
		
		if ($librarian instanceof Librarian)
		{
			return $librarian->getPrivacyAccepted();
		}
		else
		{
			return '';
		}
	}
	
	public function getEmail()
	{
		$librarian = $this->getLibrarian();
		
		if ($librarian instanceof Librarian)
		{
			return $librarian->getEmail();
		}
		else
		{
			return '';
		}
	}

	public function getCompleteName($trim = 0)
	{
		$trim = intval($trim);
		$completeName = '';
		$librarian = $this->getLibrarian();
		
		if (!is_null($librarian) 
				&& ($librarian instanceof Librarian ))
			$completeName = $librarian->getCompleteName();

		if (($trim > 0)
				&& (strlen($completeName) > $trim))
			$completeName = "...&nbsp;" . mb_substr($completeName, -$trim);
		
		return $completeName;
	}

	public function getName()
	{
		$name = '';
		$librarian = $this->getLibrarian();

		if (!is_null($librarian) 
				&& ($librarian instanceof Librarian))
			$name = $librarian->getName();

		return $name;
	}

	public function getLastname()
	{
		$lastname = '';
		$librarian = $this->getLibrarian();

		if (!is_null($librarian) 
				&& ($librarian instanceof Librarian))
			$lastname = $librarian->getLastname();

		return $lastname;
	}

	public function getProfileLabel()
	{
        return $this->_profileLabel;
	}

    public function setProfileLabel($profile)
    {
        $this->_profileLabel = $profile;
    }

	public function getProfileIds()
	{
		$profileIds = array();
		$librarian = $this->getLibrarian();
		
		if (!is_null($librarian) 
				&& ($librarian instanceof Librarian))
			$profileIds = $librarian->getProfileIds();

		return $profileIds;
	}

	public function setMinProfileId($profileId)
	{
		$this->_minProfileId = $profileId;
	}

	public function getMinProfileId()
	{
		return $this->_minProfileId;
	}

	public function setProfilesControl($profilesControl)
	{
		$this->_profilesControl = $profilesControl;
	}

	public function getProfilesControl()
	{
		return $this->_profilesControl;
	}
	
	public function getAclInfo()
	{
		return $this->_aclInfo;
	}

	public function setAclInfo($value)
	{
		$this->_aclInfo = $value;
		$this->_moduleView = array();
		$authPages = array_keys($this->getAuthPages());

		foreach($this->_aclInfo['modules'] as $key => $module)
		{
			if (($module['always_view']) 
					&& (in_array($module['page'], $authPages)))
			{
				$cssClass = 'tab';
			}
			else
			{
				$cssClass = 'control_off';
			}

			$this->_moduleView[$key] = array(	'cssclass' => $cssClass,
												'href' => 'index.php?page=' . $module['page'],
												'text' => $module['label'] );
		}
	}

	public function getAllowedModules()
	{
		return $this->_moduleView;
	}

	public function getAuthPages()
	{
		return $this->_authPages;
	}

	public function setAuthPages($value)
	{
		$this->_authPages = $value;
		$this->reloadUser();
	}

//	public function getAuthPlugins()
//	{
//		return $this->_authPlugins;
//	}
//
//	public function setAuthPlugins($value)
//	{
//		$this->_authPlugins = $value;
//		//$this->reloadUser();
//	}

	public function checkAllowedPage($page)
	{
		if ($this->getIsAdmin())
			return true;

		$authPages = $this->getAuthPages();
		if ($page == '' || !count($authPages) || !array_key_exists($page, $authPages))
			return false;

		if ($authPages[$page] == true)
			return true;
		
		return false;
	}

	public function getLibraryID()
	{
		return $this->_libraryID;
	}

	public function setLibraryID($value)
	{
		$this->_libraryID=$value;
	}

	public function getLibraries()
	{
		return $this->_libraries;
	}

	public function getLibraryIds()
	{
		return array_keys($this->_libraries);
	}

	public function getLibrariesWithBlank()
	{
		$output = array(0 => '---');
		
		foreach ($this->_libraries as $index => $row)
			$output[$index] = $row;
		
		return $output;
	}

	public function setLibraries($value)
	{
		$this->_libraries = $value;
	}

	/**
	 * It sets the id of the actual library.
	 *
	 * @param int $value
	 */
	public function setActualLibraryId($value)
	{
		$this->_actualLibraryId = $value;
	}

	/**
	 * It returns the id of the actual library (as setted).
	 *
	 * @return int
	 */
	public function getActualLibraryId()
	{
		return (int) $this->_actualLibraryId;
	}

	/**
	 * It returns (as an entire library class) the actual library
	 * of the librarian, as setted.
	 *
	 * @return Library
	 */
	public function getActualLibrary()
	{
		$libraryId = $this->_actualLibraryId;
		
		if (!is_null($libraryId) 
				&& is_numeric($libraryId))
		{
			return LibraryPeer::retrieveByPK($libraryId);
		}
		else
		{
			return null;
		}
	}

	public function getActualConsortiaId()
	{
		$consortiaId = trim($this->getActualLibrary()->getConsortiaId());
		
		if ($consortiaId != '')
		{
			return $consortiaId;
		}
		else
		{
			return null;
		}
	}

	public function getActualConsortiaLabel()
	{
		$l = $this->getActualLibrary();
		
		if ($l instanceof Library)
		{
            $consortia = $l->getConsortia();
		
			if ($consortia instanceof Consortia)
				return $consortia->getLabel();
        }
		
		return '';
	}

	public function getDefaultLibraryId()
	{
		return (int) $this->_defaultLibraryId;
	}

	public function setDefaultLibraryId($libraryId = null)
	{
		$this->_defaultLibraryId = $libraryId;
	}

	public function setDistanceHash($fromLibraryId)
	{
		$this->_distanceHash = LibraryPeer::getDistanceHash($fromLibraryId);
	}
	
	public function getDistanceHash($distance = null)
	{
		$distance = intval($distance);
		
		if (($distance > 0)
				&& (array_key_exists($distance, $this->_distanceHash)))
		{
			return $this->_distanceHash[$distance];
		}
		else
		{
			return $this->_distanceHash;
		}
	}
	
	/**
	 * It sets the id of the preferred shelfId the librarian wants
	 * to use during this session.
	 *
	 * @param int $value
	 */
	public function getActualShelfId()
	{
		$shelfId = null;
		$savedShelf = intval($this->_actualShelfId);
	
		if ($savedShelf > 0)
			$shelfId = $savedShelf;
		
		return $shelfId;
	}

	public function setActualShelfId($value = null)
	{
		$this->_actualShelfId = $value;
		$this->reloadUser();
	}

	/**
	 * It sets the id of the current librarian session.
	 *
	 * @param int $value
	 */
	public function setLibrarianSessionId($value)
	{
		$this->_librarianSessionId = $value;
	}

	/**
	 * It returns the current librarian session id entry
	 * for the librarian, as setted.
	 *
	 * @return int
	 */
	public function getLibrarianSessionId()
	{
		return $this->_librarianSessionId;
	}

	/**
	 * It returns (as an entire librarian_session class) the current librarian session
	 * of the librarian, as setted.
	 *
	 * @return LibrarianSession
	 */
	public function getLibrarianSession()
	{
		$librarianSessionId = $this->_librarianSessionId;

		if (!is_null($librarianSessionId) 
				&& is_numeric($librarianSessionId))
		{
			return LibrarianSessionPeer::retrieveByPK($librarianSessionId);
		}
		else
		{
			return null;
		}
	}

	/**
	 * It returns the description (as a string) of actual library.
	 *
	 * @return string
	 */
	public function getActualLibraryString()
	{
		return $this->_libraries[$this->_actualLibraryId];
	}

	public function getDefaultLibraryString()
	{
		return $this->_libraries[$this->getDefaultLibraryId()];
	}

	/**
	 * For compatibility.
	 *
	 * @return string
	 */
	public function getActualLibraryLabel()
	{
		return $this->getActualLibraryString();
	}


	/**
	 * It returns true if the current librarian is an administrator.
	 *
	 * @return boolean
	 */
	public function getIsAdmin()
	{
		return $this->isInRole('admin');
	}

	/**
	 * It returns true if the current librarian is a director (responsabile, profile 2)
	 *
	 * @return boolean
	 */
	public function getIsDirector()
	{
		return (array_search(2, $this->getProfileIds()) !== false);
	}
	
	public function getUsername()
	{
		$username = null;
		$librarian = $this->getLibrarian();
		
		if (!is_null($librarian) 
				&& ($librarian instanceof Librarian ))
			$username = $librarian->getUsername();

		return $username;
	}
	
	/**
	 * It returns whether the current librarian is an superadministrator.
	 *
	 * @return boolean
	 */
	public function getIsSuperAdmin()
	{
		return ($this->isInRole('admin')
					&& ($this->getUsername() === self::SUPERADMIN_USERNAME));
	}
	
	/**
	 * It serializes, into a string, some librarian's properties.
	 *
	 * @return string
	 */
	public function saveToString()
	{
		$a = array(	$this->_id,
					$this->_aclInfo,
					$this->_authPages,
					$this->_moduleView,
					$this->_libraryID,

					serialize($this->_libraries),
					serialize($this->_distanceHash),
                    $this->_minProfileId,
                    $this->_profilesControl,			
                    $this->_profileLabel,
			
					$this->_actualLibraryId,
					$this->_defaultLibraryId,
					$this->_actualShelfId,
					$this->_librarianSessionId,
					parent::saveToString() );

		return serialize($a);
	}

	/**
	 * It deserializes a string into some librarian's properties.
	 *
	 * @param string $data
	 * @return string
	 */
	public function loadFromString($data)
	{
		if (!empty($data))
		{
			list (	$id,
					$aclInfo,
					$authPages,
					$moduleView,
					$libraryID,

					$libraries,
					$distanceHashSer,
                    $minProfileId,
					$profilesControl,
                    $profileLabel,
					
					$actualLibraryId,
					$defaultLibraryId,
					$actualShelfId,
					$librarianSessionId,
					$parentData ) = unserialize($data);

			$this->_id = $id;
			$this->_aclInfo = $aclInfo;
			$this->_authPages = $authPages;
			$this->_moduleView = $moduleView;
			$this->_libraryID = $libraryID;
			
			$this->_libraries = unserialize($libraries);
			$this->_distanceHash = unserialize($distanceHashSer);
            $this->_minProfileId = $minProfileId;
			$this->_profilesControl = $profilesControl;
            $this->_profileLabel = $profileLabel;
			
			$this->_actualLibraryId = $actualLibraryId;
			$this->_defaultLibraryId = $defaultLibraryId;
			$this->_actualShelfId = $actualShelfId;
			$this->_librarianSessionId = $librarianSessionId;
			
			return parent::loadFromString($parentData);
		}
		else
		{
			return $this;
		}
	}

	public function getEditPermission($subject, $deep = false) 
	{
		$class = get_class($subject);
		
		if (($class != 'Librarian')			// new logic for superadmin modify case
				&& $this->getIsAdmin())
			return true;

		$minProfileId = $this->getMinProfileId();
		$test = true;

		switch ($class) 
		{
			case 'Authority':
			case 'Classification':
			case 'Subject':
				$editPage = 'Catalog.AuthorityEditPage';
				
				break;

			case 'Bulletin':
				$editPage = 'Communication.BulletinInsertPage';
				
				if ($subject->getProtectedMessage())
					$test = ($subject->getLibrarianId() == $this->getId());
				
				break;

			case 'InventorySerie':
				$editPage = 'Library.InventorySerieInsertPage';
				$test = in_array($subject->getLibraryId(), $this->getLibraryIds());
				
				break;

			case 'Invoice':
				$editPage = 'Acquisition.InvoiceInsertPage';
				
				$test = (in_array($subject->getLibraryId(), $this->getLibraryIds()) 
							&& ($subject->getInvoiceStatus() != InvoicePeer::INVOICESTATUS_CLOSED));
				
				break;

			case 'Issue':
				$editPage = 'Catalog.IssueInsertPage';
				
				if ($deep)
					$test = $subject->isAllItemsMine();
				
				break;

			case 'Item':
				$editPage = 'Catalog.ItemInsertPage';
				
				if (!$subject->isNew())
					//$test = ($this->getActualLibraryId() == $subject->getHomeLibraryId());
					$test = in_array($subject->getHomeLibraryId(), $this->getLibraryIds());
				
				break;

			case 'Librarian':
				$editPage = 'Library.LibrarianInsertPage';

				if ($subject->getUsername() == self::SUPERADMIN_USERNAME)
				{
					return self::getIsSuperAdmin()
									? true
									: false;
				}
				
				if ($this->getIsAdmin())
				{
					return true;
				}
				
				if ($subject->getLibrarianId() == $this->getId())
				{
					// this is an anomaly
					return true;
				}
				elseif ($minProfileId > 2)
				{
					$test = false;
				}
				else
				{
					if (!$subject->isNew())
						$test = ($subject->getMinProfileId() >= $minProfileId)
									&& (!$subject->getLibraryIds() || count(array_intersect($subject->getLibraryIds(), $this->getLibraryIds())) > 0);
				}
				
				break;

			case 'Library':
			    /** @var  $subject Library */
				$editPage = 'Library.LibraryInsertPage';
				//$test = in_array($subject->getLibraryId(), $this->getLibraryIds()) && (!$subject->isNew());
				
				if ($subject->isNew())
				{
					
				}
				else
				{
					$test = in_array($subject->getLibraryId(), $this->getLibraryIds())
										|| ($subject->getCreatedBy() == $this->getId())
                                        || ($this->getIsDirector() && $subject->isExternal() );		// i can edit if i'm the Creator
				}

				break;

			case 'Supplier':
				$editPage = 'Acquisition.SupplierInsertPage';
				
				break;
			
			case 'Manifestation':
				$editPage = 'Catalog.EditRecord';
				
				if (!is_null($this->getLibrarian()))
					$test = $subject->getCatalogationLevel() <= $this->getLibrarian()->getCatLevel();
				
				break;

			case 'Patron':
				$editPage = 'Circulation.PatronPage';
				
				break;

			case 'PurchaseOrder':
				$editPage = 'Acquisition.OrderInsertPage';
				
				if (! $subject->isNew())
					$test = ($this->getActualLibraryId() == $subject->getLibraryId());
				
				break;

			case 'Shelf':
				$editPage = 'Communication.ShelfInsertPage';
				
				if (!$subject->isNew())
					$test = $subject->isEditable($this);
				
				break;

			case 'Subscription':
				$editPage = 'Acquisition.SubscriptionInsertPage';
				
				if (! $subject->isNew())
					$test = ($this->getActualLibraryId() == $subject->getLibraryId());
				
				break;

			case 'Resource':
				$editPage = 'Library.ResourceManager';
				
				if (!$subject->isNew())
					$test = ($this->getActualLibraryId() == $subject->getLibraryId());
				
				break;

			case 'ResourceRule':
				$editPage = 'Library.ResourceRuleEditPage';
				
				if (!$subject->isNew())
					$test = ($this->getActualLibraryId() == $subject->getLibraryId());
				
				break;

			case 'ResourceSession':
				$editPage = 'Library.ResourceRuleEditPage';	// i believe it can work
				
				if (!$subject->isNew())
					$test = ($this->getActualLibraryId() == $subject->getLibraryId());
				
				break;
				
			case 'Budget':
				$editPage = 'Acquisition.BudgetInsertPage';
				
				if (!$subject->isNew())
					$test = ($this->getActualLibraryId() == $subject->getLibraryId());
				
				break;

			case 'Consortia':
				$editPage = 'Help.Support';
				
				$test = $minProfileId < 3;
				
				break;

			case 'LibrarianTask':
				$editPage = 'Communication.TaskListPage';
				
				if (intval($subject->getAssignedLibrarianId() != 0))
				{
					$librarianTest = ($this->getId() == $subject->getAssignedLibrarianId());
				}
				else
				{
					$librarianTest = false;
				}
				
				if (intval($subject->getLibraryId() != 0))
				{
					$libraryTest = (in_array($subject->getLibraryId(), $this->getLibraryIds()));
				}
				else
				{
					$libraryTest = false;
				}
				
				$test = ($librarianTest || $libraryTest);
				
				break;
			
			default:
				throw new Exception('No ACL defined');
		}
		
		return TPropertyValue::ensureBoolean($this->checkAllowedPage($editPage) && $test);
	}

	public function getProfilePermission($objectLibrarianId)
	{
		/*
		 * It's better to get secure that the admin can manipulate profiles,
		 * independently by the profiles_control settings
		 */
		if ($this->getIsAdmin())
			return true;

		$permission = false;
		$profilesControlArray = $this->getProfilesControl();
		
		if (count($profilesControlArray) > 0)
		{
//			$objectProfileId = intval(LibrarianPeer::getMinProfileId($objectLibrarianId));
//
//			if (array_search($objectProfileId, $profilesControlArray) !== false)
//				$permission = true;
			
			$objectProfileIds = LibrarianPeer::getProfileIds($objectLibrarianId);
			
			if (count(array_intersect($objectProfileIds, $profilesControlArray)) > 0)
				$permission = true;	
		}
			
		return $permission;
	}
	
	public function getLibraryPermission($objectLibrarianId)
	{
		return ($this->getIsAdmin()
				|| ($this->getIsDirector()) && (count($this->getLibraryIds()) > 0));
	}
	
	public function getViewPermission($subject = null)
	{
		if ($this->getIsAdmin())
			return true;

		if (is_null($subject))
			return false;

		if (is_string($subject) 
				&& ($subject != ''))
		{
			$class = $subject;
		}
		else
		{
			$class = get_class($subject);
		}

		$page = '';
		
		switch ($class)
		{
			case 'Patron':
				$page = PatronPeer::getViewPage();
				
				break;

			case 'Library':
				$page = LibraryPeer::getViewPage();
				
				break;

			default:
				throw new Exception('No ACL defined');
		}
		return TPropertyValue::ensureBoolean($this->checkAllowedPage($page));
	}

	public function reloadUser()
	{
		Prado::getApplication()->getModule("auth")->updateSessionUser($this);
	}
	
}