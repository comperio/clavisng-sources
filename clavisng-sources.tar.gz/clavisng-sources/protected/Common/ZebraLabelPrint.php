<?php
/**
 * ZebraLabelPrint.php
 *
 * This class generates one or more child controls based on the inclusion type.
 * Goal of these controls is print a label with a Zebra printer, injecting a
 * client-side webserver with an image src.
 *
 * For label templates, a number of placeholders are available, based on the
 * object class; some objects load other ones based on the following:
 * - 'itemrequest' loads #ITEM and #USER placeholders
 * - 'loan' loads #LOAN, #ITEM and #USER placeholders
 * - 'item' loads #ITEM placeholders
 *
 * Placeholders:
 *
 * #LOAN
 * - LOAN_START		Loan start date
 * - LOAN_END		Loan end date
 * - LOAN_DUE		Loan due date
 * - LOAN_LIBRARY	The library label
 * - LOAN_PHONE		The library phone number
 *
 * #ITEM
 * - TITLE			The item title
 * - LIBRARY		Item's owner library label
 * - INVSERIE		Item inventory serie ID
 * - INVNUMBER		Item inventory number
 * - INVENTORY		Inventory serie + Inventory number
 * - SECTION		Item section
 * - COLLOCATION	Item collocation
 * - COLLOCONE		Item collocation (first 4 chars)
 * - COLLOCTWO		Item collocation (from 4 chars to end)
 * - SPECIFICATION	Item specification
 * - SEQUENCEONE	Item Sequence1
 * - SEQUENCETWO	Item Sequence1
 * - BARCODE		Item Barcode
 *
 * #USER
 * - USER_NAME		Patron complete name
 * - USER_MAIL		Patron mail (if exists)
 * - USER_PHONE		Patron phone no. (if exists)
 * - USER_CARDCODE	Patron card code
 *
 * #PATRON_ADDRESS
 * - NAME			Patron complete name
 * - STREET			Patron street
 * - CITY			Patron city
 * - COUNTRY		Patron country
 *
 */
class ZebraLabelPrint extends TWebControl {

	protected $_types = array('embed','popup','js');
	protected $_classes = array('loan','itemrequest','item', 'patronaddress');
	protected $_vars = array();
	protected $_data;
	protected $_templatePath;
	protected $_serverUrl;

	const DEFAULT_TEMPLATE_PATH = 'storage/report/zebra/';
	const DEFAULT_LABEL_SERVER = 'http://localhost:8001/cgi-bin/label.cgi';

	public function onPreRender($param) {
		global $SITEPATH;
		
		parent::onPreRender($param);
		if (! $this->_templatePath = ClavisParamQuery::getParam('CLAVISPARAM','ZebraLabelTemplates'))
			$this->_templatePath = $SITEPATH.'/'.self::DEFAULT_TEMPLATE_PATH;
		if (! $this->_serverUrl = ClavisParamQuery::getParam('CLAVISPARAM','ZebraLabelServer'))
			$this->_serverUrl = self::DEFAULT_LABEL_SERVER;
		$this->_data = $this->buildLabelData();
		if ($this->_data)
			$this->addChildren($this->getType());
	}

	/**
	 * Returns the type of page inclusion:
	 * 	- 0-pixel image (direct print)
	 * 	- popup link (print on-demand)
	 *
	 * @return string The type of page inclusion ('embed' or 'popup').
	 */
	public function getType() {
		return $this->getControlState('IncludeType','embed');
	}
	/**
	 * Sets the type of page inclusion:
	 * 	- 0-pixel image (direct print)
	 * 	- popup link (print on-demand)
	 *
	 * @param string $value The type of inclusion ('embed' or 'popup'). Defaults to 'embed'.
	 */
	public function setType($value) {
		$this->setControlState('IncludeType',TPropertyValue::ensureEnum(strtolower($value),$this->_types),'embed');
	}

	/**
	 * Returns the link text or the alternate description for the image.
	 *
	 * @return string The text associated with the child control.
	 */
	public function getText() {
		return $this->getControlState('Text','');
	}
	/**
	 * Sets the text associated with the control (hyperlink or alternate image text).
	 *
	 * @param string $value The text to associate with control.
	 */
	public function setText($value) {
		$this->setControlState('Text',TPropertyValue::ensureString($value),'');
	}

	/**
	 * Returns the object class for placeholders compilation.
	 *
	 * @return string The object class for placeholders, empty string if not set or invalid.
	 */
	public function getObjectClass() {
		return $this->getControlState('ObjectClass','');
	}
	/**
	 * Sets the object class for placeholders compilation.
	 *
	 * @param string $value The object class.
	 */
	public function setObjectClass($value) {
		$this->setControlState('ObjectClass',TPropertyValue::ensureEnum(strtolower($value),$this->_classes),'');
	}

	/**
	 * Returns the ID for the object to load.
	 *
	 * @return The object ID, null if not set or invalid.
	 */
	public function getObjectId() {
		return $this->getControlState('ObjectId', null);
	}

	/**
	 * Sets the ID for the object to load.
	 *
	 * @param int $value The object ID
	 */
	public function setObjectId($value) {
		$this->setControlState('ObjectId', $value, null);
	}

	/**
	 * Returns the label template's filename.
	 *
	 * @return string The template filename (without extension), empty string if not set or invalid.
	 */
	public function getLabelTpl() {
		return $this->getControlState('LabelTemplate','');
	}
	/**
	 * Sets the template (filename) for the label.
	 *
	 * @param string $value The template's filename (without extension)
	 */
	public function setLabelTpl($value) {
		$this->setControlState('LabelTemplate',TPropertyValue::ensureString($value),'');
	}

	/**
	 * Parses and builds the label's raw data.
	 *
	 * @return string Url-encoded label raw data
	 * @throws Exception
	 */
	protected function buildLabelData() {
		ini_set("memory_limit", "800M");
		set_time_limit(1800);

		if (($class = $this->getObjectClass())=='')
			throw new Exception('Object class not defined or invalid: '.Prado::varDump($class));

		if (($tpl = $this->getLabelTpl())=='')
			throw new Exception('Label template not defined or invalid: '.Prado::varDump($tpl));

		$lbl = @file_get_contents("{$this->_templatePath}{$tpl}.prn");
		if (!$lbl)
			return null;

		$objectId = $this->getObjectId();
		if (is_numeric($objectId)) {
			if ($objectId < 1)
				throw new Exception('Object ID not specified or invalid: '.Prado::varDump($objectId));
			$objectIdArray[] = $objectId;
		} else if (is_array($objectId)) {
			if (count($objectId) == 0)
				return null;
			$objectIdArray = $objectId;
		} else {
			throw new Exception('The type of object ID is invalid: '.Prado::varDump($objectId));
		}

		$wholeEncoded = '';
		foreach ($objectIdArray as $objectId) {
			if ($objectId < 0)
				continue;
			$encodedUrl = $this->buildLabelCore($objectId, $class, $lbl);
			if ($encodedUrl != '')
				$wholeEncoded .= $encodedUrl;
		}
		return $wholeEncoded;
	}

	public function buildLabelCore($objectId = null, $objectClass = null, $lbl = '')
	{
		switch ($objectClass)
		{
			case 'loan':		// mainclass = Loan;
				$l = $this->initVarsForLoan($objectId);
				$i = $this->initVarsForItem($l->getItemId());
				$p = $this->initVarsForPatron($l->getPatronId());
				break;
			case 'itemrequest':	// mainclass = ItemRequest;
				$r = $this->initVarsForItemRequest($objectId);
				$i = $this->initVarsForItem($r->getItemId());
				$p = $this->initVarsForPatron($r->getPatronId());
				break;
			case 'item':		// mainclass = Item;
				$i = $this->initVarsForItem($objectId);
				break;

			case 'patronaddress':	// mainclass = Patron
				$p = $this->initVarsForPatronAddress($objectId);
				break;

			default:
				throw new Exception('Class not specified or invalid: '.Prado::varDump($objectClass));
		}

		preg_match_all('/{(?P<tag>[A-Z_]+)	# capture tag {yada}
			(?P<counter>\d+)?}				# ..and optional multiline counter
			(?:\[							# modifiers [ ]
			(?P<align>[LlCcRr])?			# optional align (L,C,R)
			(?P<width>[\d,]+)\])?			# width (mandatory with align or multiline)
			/x',$lbl,$matches,PREG_SET_ORDER);
		$search = $replace = array();
		foreach ($matches as $match) {
			if (!array_key_exists($match['tag'],$this->_vars))
				continue;
			$search[] = $match[0];
			$align = @trim($match['align']);
			$width = @intval(trim($match['width']));
			$counter = @intval(trim($match['counter']));
			if ($counter) {	// multiline
				$chunks = explode('$',wordwrap($this->_vars[$match['tag']],$width,'$',1));
				$string = array_shift($chunks);
				$this->_vars[$match['tag']] = implode(' ',$chunks);
			} else {
				$string = $this->_vars[$match['tag']];
			}
			if ($width) {	// single-line with width (and optionally align)
				switch ($align) {
					case 'C':	$padtype = STR_PAD_BOTH;	break;
					case 'R':	$padtype = STR_PAD_LEFT;	break;
					case 'L':
					default:	$padtype = STR_PAD_RIGHT;	break;
				}
				$replace[] = (strlen($string) > $width)?
					substr($string,0,$width):
					str_pad($string,$width,' ',$padtype);
			} else {	// no modifiers
				$replace[] = $string;
			}
		}
		return urlencode(str_replace($search,$replace,$lbl));
	}

	/**
	 * Adds the right child(ren) to the control for printing a label.
	 *
	 * @param string $type The include type.
	 */
	protected function addChildren($type) {
		switch ($type) {
			case 'popup':
				$assetPath = $this->publishAsset('ZebraAsset.php');
				$child = new THyperLink();
				$child->setNavigateUrl('#');
				$sessionVarName = 'ZebraLabelUri'.crc32($this->_data);
				$_SESSION[$sessionVarName] = "{$this->_serverUrl}?data={$this->_data}";
				$child->setAttribute('onclick',
					'window.open(\''.$assetPath."?SessionName=".$this->getSession()->getSessionName()
					."&SessionVar=".$sessionVarName."','zebra print','width=1,height=1,".
					"toolbar=no,scrollbars=no,status=no,menubar=no,resizable=no');");
				$child->setText($this->getText());
				break;
			case 'js':
				$this->initVarsForLoan($objectId);
				$this->initVarsForItem($l->getItemId());
				$this->initVarsForPatron($l->getPatronId());
				$vars = '';
				foreach ($this->_vars as $k => $v)
					$vars .= " {$k}=\"{$v}\"";
				$this->getPage()->getClientScript()->registerEndScript(__CLASS__.'_js',
					"sendPrintRequest('receipt','{$vars}')");
				$this->getPage()->getClientScript()->registerEndScript(__CLASS__.'2_js',"alert('Ciao')");
				break;
			case 'embed':
			default:
				$child = new TImage();
				$child->setWidth(0);
				$child->setHeight(0);
				$child->setBorderWidth(0);
				$child->setImageUrl(($this->getVisible())?"{$this->_serverUrl}?data={$this->_data}":'#');
				break;
		}
		$this->addParsedObject($child);
	}

	/**
	 * Compiles placeholders for ItemRequest object.
	 *
	 * @param int $itemRequestId The item request's id
	 * @return ItemRequest The item request object
	 * @throws Exception if supplied ID is not valid
	 */
	protected function initVarsForItemRequest($itemRequestId) {
		$r = ItemRequestPeer::retrieveByPK($itemRequestId);
		if (! $r instanceof ItemRequest)
			throw new Exception('Invalid ItemRequest ID.');
		return $r;
	}

	/**
	 * Compiles placeholders for Loan object.
	 *
	 * @param int $loanId The loan's id
	 * @return Loan The loan object
	 * @throws Exception if supplied ID is not valid
	 */
	protected function initVarsForLoan($loanId) {
		$l = LoanPeer::retrieveByPK($loanId);
		if (! $l instanceof Loan)
			throw new Exception('Invalid Loan ID.');
		$this->_vars['LOAN_START'] = $l->getLoanDateBegin('d/m/Y');
		$this->_vars['LOAN_END'] = $l->getLoanDateEnd('d/m/Y');
		$this->_vars['LOAN_DUE'] = $l->getDueDate('d/m/Y');
		$lib = LibraryPeer::retrieveByPK($l->getToLibrary());
		$this->_vars['LOAN_LIBRARY'] = $lib->getLabel();
		$this->_vars['LOAN_PHONE'] = strval($lib->getPhone());
		return $l;
	}

	/**
	 * Compiles placeholders for Item object.
	 *
	 * @param int $itemId The item's id
	 * @return Item The item object
	 * @throws Exception if supplied ID is not valid
	 */
	protected function initVarsForItem($itemId) {
		$i = ItemPeer::retrieveByPK($itemId);
		if (!$i instanceof Item)
			return null;   ///throw new Exception('Invalid Item ID.');

		$manifestation = $i->getManifestation();

		$this->_vars['TITLE'] = str_replace('"','\'',$i->getTitle());
		if ($manifestation instanceof Manifestation) {
			$this->_vars['AUTHOR'] = $manifestation->getAuthor();
			$this->_vars['SERIE'] = implode('; ',$manifestation->getTurboMarc()->getSeries());
		} else {
			$this->_vars['AUTHOR'] = '';
			$this->_vars['SERIE'] = '';
		}
		$this->_vars['LIBRARY'] = LibraryPeer::getLibraryLabel($i->getOwnerLibraryId());
		$this->_vars['INVSERIE'] = $i->getInventorySerieId();
		$this->_vars['INVNUMBER'] = $i->getInventoryNumber();
		$this->_vars['INVENTORY'] = $i->getInventorySerieId().'-'.$i->getInventoryNumber();
		$this->_vars['SECTION'] = $i->getSection();
		$this->_vars['COLLOCATION'] = $i->getCollocation();
		$this->_vars['SECTCOLL'] = trim($i->getSection().' '.$i->getCollocation());
		$this->_vars['COLLOCONE'] = substr($this->_vars['COLLOCATION'],0,4);
		$this->_vars['COLLOCTWO'] = substr($this->_vars['COLLOCATION'],4);
		$this->_vars['SPECIFICATION'] = $i->getSpecification();
		/*** memo ***/
		$this->_vars['SEQUENCEONE'] = $i->getSequence1();
		$this->_vars['SEQUENCETWO'] = $i->getSequence2();
		$this->_vars['SPECSEQ'] = trim($this->_vars['SPECIFICATION'].' - '.$this->_vars['SEQUENCEONE'],' -');
		$this->_vars['BARCODE'] = $i->getBarcode();
		return $i;
	}

	/**
	 * Compiles placeholders for Patron object.
	 *
	 * @param int $patronId The patron's id
	 * @return Patron The patron object
	 * @throws Exception if supplied ID is not valid
	 */
	protected function initVarsForPatron($patronId) {
		$p = PatronPeer::retrieveByPK($patronId);
		if (! $p instanceof Patron)
			//throw new Exception('Invalid Patron ID.');
			return null;

		$this->_vars['USER_NAME'] = $p->getCompleteName();
		$this->_vars['USER_CARDCODE'] = $p->getCardCode();
		$USER_MAIL = $p->getEmail();
		$this->_vars['USER_MAIL'] = (count($USER_MAIL)>0)?$USER_MAIL[0]:'';
		$USER_PHONE = $p->getPhone();
		$this->_vars['USER_PHONE'] = (count($USER_PHONE)>0)?$USER_PHONE[0]:'';
		return $p;
	}

	/**
	 * Compiles placeholders for patron_address object.
	 *
	 * @param int $patronId The patron's id
	 * @return Patron The patron object
	 * @throws Exception if supplied ID is not valid
	 */
	protected function initVarsForPatronAddress($patronId)
	{
		$p = PatronPeer::retrieveByPK($patronId);
		if (! $p instanceof Patron)
			throw new Exception('Invalid Patron ID.');
		$this->_vars['NAME'] = $p->getCompleteName();

		$addressArray = $p->getPreferredAddressArray();
		$street = $addressArray['street'];
		$city = $addressArray['city'];
		$country = $addressArray['country'];

		$this->_vars['STREET'] = $street;
		$this->_vars['CITY'] = $city;
		$this->_vars['COUNTRY'] = $country;

		return $p;
	}
}
