<?php
/**
 * ClavisUserManager class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Dario Rigolin <dario@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Core
 */
Prado::using('System.Security.IUserManager');
Prado::using('Application.Common.ClavisLibrarian');

/**
 * ClavisUserManager Class
 *
 * @author Dario Rigolin <dario@comperio.it>
 * @version 2.7
 * @package Core
 * @since 2.0
 */
class ClavisUserManager extends TModule implements IUserManager
{
	public function getGuestName()
	{
		return 'Guest';
	}

	/**
	 * It returns a user instance given the user name.
	 * @param string user name, null if it is a guest.
	 * @return TUser the user instance, null if the specified username is not in the user database.
	 */
	public function getUser($username=null)
	{
		if ($username === null)
		{
			return new ClavisLibrarian($this);
		}
		else
		{
			$username = strtolower($username);
			/* @var $librarian Librarian */
			$librarian = LibrarianPeer::retrieveByUsername($username);
			
			if ($librarian!== null)
			{
				$user = new ClavisLibrarian($this);
				$user->setID($librarian->getLibrarianId());
				$user->setName($username);
				$user->setIsGuest(false);

				$roles = $librarian->getRoles();
				// this is an hack in order to prevent infinite looping in the login page
				// should be removed when the transition to Prado role model has been completed.
				if (!array_search('librarian',$roles))
					$roles[] = 'librarian';
				
				$user->setRoles($roles);

//				$authPages = $authPlugins = [];
//				$librarian->getAuthPages($authPages, $authPlugins);
//				$user->setAuthPlugins($authPlugins);
//				$user->setAuthPages($authPages);
				$user->setAuthPages($librarian->getAuthPages());
				
				$acl = $librarian->getACLInfos();
				$user->setAclInfo($acl);

				$contractLeftCount = 0;
				$contractExpiredCount = 0;
				$contractBlockedCount = 0;
				
				$libraries = $librarian->getUserLibraries(	array(),
															true,
															$contractLeftCount,
															$contractExpiredCount,
															$contractBlockedCount);	// expire contract logic checking
				$user->setLibraries($libraries);

				$def = $librarian->getDefaultLibraryId();
				
				if (($def > 0) && (isset($libraries[$def])))
				{
					$defaultLibraryId = $def;
				}
				elseif (count($libraries) > 0)
				{
					$indexes = array_keys($libraries);
					$firstIndex = array_shift($indexes);
					$defaultLibraryId = $firstIndex;
					$librarian->setDefaultLibraryId($defaultLibraryId);
					$librarian->save();
				}
				else
				{
					$defaultLibraryId = null;
				}

				$user->setDefaultLibraryId($defaultLibraryId);
				$user->setActualLibraryId($defaultLibraryId);

				$user->setDistanceHash($defaultLibraryId);
				$user->setMinProfileId($librarian->getMinProfileId());
				$user->setProfilesControl($librarian->getProfilesControl());
                $user->setProfileLabel($librarian->getProfileLabels());

				$user->setActualShelfId(null);
				/* @var $libraryLinks LLibraryLibrarian */
				$libraryLinks = $librarian->getLLibraryLibrarians();

				if(count($libraryLinks) == 0) {
					/* LIBRARIA NOT RELATED TO ANY LIBRARY */
				} else {
					$user->setLibraryID($libraryLinks[0]->getLibrarianId() );
				}

				//SESSION MANAGEMENT
				//
				//1) close expired sessions
				$expired_sessions = LibrarianSessionQuery::create()
					->filterByLibrarianId($librarian->getLibrarianId())
					->filterByEndDate(null,Criteria::ISNULL)
					->find();
				foreach($expired_sessions as $session) {
					$session->setEndDate(time());
					$session->save();
 				}
				
				//create librarian_session entry:
				if (!session_regenerate_id(true))
				{
					Prado::log("It's impossibile to regenerate session, in ClavisUserManager");
					Prado::fatalError("It's impossibile to regenerate session, in ClavisUserManager");
				}
				$new_session = new LibrarianSession();
				$new_session->setLibrarianId($librarian->getLibrarianId());
				$new_session->setCurrentLibraryId($defaultLibraryId);
				$new_session->setSessionIdString($this->getSession()->getSessionID());
				$new_session->setStartDate('now');
				$new_session->setLocalIp(@$_SERVER['HTTP_X_FORWARDED_FOR']);
				$new_session->setPublicIp($_SERVER['REMOTE_ADDR']);
				$new_session->save();

				$user->setLibrarianSessionId($new_session->getLibrarianSessionId());

				$greetingsMessageText = "";
				$greetingsMessageType = ClavisMessage::CONFIRM;
				
				/**
				 * If we are a SUPERADMIN
				 */
				
				if ($user->getIsSuperAdmin())
					$greetingsMessageText .= '**' . ClavisLibrarian::SUPERADMIN_LABEL . '** - &nbsp;';

				/**
				 * If the (default) library has been set for contract expiration
				 */
				if (LibraryPeer::isContractExpire($defaultLibraryId))
				{
					if (($contractDaysExpired = intval(LibraryPeer::getContractDaysExpired($defaultLibraryId))) > 0)
					{
						$greetingsMessageText .= Prado::localize("Il contratto per la biblioteca '{library}' è scaduto {days_expired} giorni fa. Provvedere al suo rinnovo al più presto per evitare l'eventuale disattivazione del servizio.<br/>",
																	array(	'library' => $libraries[$defaultLibraryId],
																			'days_expired' => $contractDaysExpired) );
						
						$greetingsMessageType = ClavisMessage::ERROR;
					}
					elseif (($contractDaysLeft = intval(LibraryPeer::getContractDaysLeft($defaultLibraryId))) > 0)
					{
						$greetingsMessageText .= Prado::localize("Il contratto per la biblioteca '{library}' scadrà tra {days_left} giorni. Ricordati di rinnovarlo se intendi ancora utilizzare il servizio anche dopo il {expire_date}.<br/>",
																	array(	'library' => $libraries[$defaultLibraryId],
																			'days_left' => $contractDaysLeft,
																			'expire_date' => ClavisBase::dateFormat(LibraryPeer::getContractExpireDate($defaultLibraryId), 'dd/MM/yyyy') ));
						
						$greetingsMessageType = ClavisMessage::WARNING;
					}
				}
				
				if ($contractLeftCount > 0)
				{
					$greetingsMessageText .= Prado::localize("N.{num} biblioteche in prossima scadenza contratto.<br />",
																array('num' => $contractLeftCount));
					
					$greetingsMessageType = ClavisMessage::WARNING;
				}
				
				if ($contractExpiredCount > 0)
				{
					$greetingsMessageText .= Prado::localize("N.{num} biblioteche con contratto scaduto.<br />",
																array('num' => $contractExpiredCount));
					
					$greetingsMessageType = ClavisMessage::WARNING;
				}

				if ($contractBlockedCount > 0)
				{
					$greetingsMessageText .= Prado::localize("N.{num} biblioteche con contratto bloccato.<br />",
																array('num' => $contractBlockedCount));
					
					$greetingsMessageType = ClavisMessage::ERROR;
				}

				$greetingsMessageText .= Prado::localize('Benvenuto in Clavis NG, {librarian_name}.',
															array('librarian_name' => $user->getCompleteName()));

				$libraryString = '';
				
				if (intval($defaultLibraryId) > 0) 
				{
					$defaultLibrary = LibraryQuery::create()->findPk($defaultLibraryId);
					if ($defaultLibrary instanceof Library)
						$libraryString = trim($defaultLibrary->getLabel());
				}

				if ($libraryString != '')
					$greetingsMessageText .= '<br />'. Prado::localize('Sei nella biblioteca "{library}".',
																		array('library' => $libraryString));

				Prado::getApplication()->getSession()->add(	'DelayedMessage',
															array(	$greetingsMessageText,
																	$greetingsMessageType ));
				
				return $user;
			}
			else
			{
				return null;
			}
		}
	}

	/**
	 * Validates if the username and password are correct.
	 * @param string user name
	 * @param string password
	 * @return boolean true if validation is successful, false otherwise.
	 */
	public function validateUser($username,$password)
	{
		/* @var $librarian Librarian  */
		$crypt = $this->getApplication()->getModule('crypt');
		$librarian = LibrarianPeer::retrieveByUsername($username);
		
		return $librarian !== null &&
			$librarian->getActivationStatus() == 1 &&
			$crypt->LibrarianVerify($password,$librarian->getSecret());
	}

	public function getUserFromCookie($cookie)
	{
		return null;
	}

	public function saveUserToCookie($cookie)
	{

	}
	
}