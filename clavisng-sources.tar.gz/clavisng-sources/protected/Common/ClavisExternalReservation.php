<?php
/**
 * ClavisExternalReservation file.
 *
 * This file contains all the required classes for SBN dialogue v4.
 * Based upon SBNConnector by Comperio srl.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Dario Rigolin <dario@comperio.it>
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Modules.Circulation
 */

/**
 * ClavisExternalReservation Class
 *
 * @author Dario Rigolin <dario@comperio.it>
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Modules.Circulation
 * @since 2.4.3
 */
class ClavisExternalReservation extends TModule implements IExternalReservation
{
	private $_sendMail = true;

	public function IsPatronAllowedToReserve($patron)
	{
		// TBD
		return true;
	}

	public function doReserve(Patron $patron, $library_id, $inventory, $collocation, $barcode, $title)
	{
		$library = LibraryQuery::create()->findPk($library_id);
		if (!$library instanceof Library)
			throw new Exception('Unknown library',self::ERR_UNKNOWNLIBRARY);

		$item = null;
		/* check if item is already in our database */
		if ($barcode)
			$item = ItemQuery::create()->findOneByBarcode($barcode);
		if (! $item instanceof Item) {
			$invtokens = explode('-', $inventory);
			list($inv_serie,$inv_number) = (count($invtokens) > 1) ?
				$invtokens : array(null,$invtokens[0]);
			$items = ItemQuery::create()
				->filterByOwnerLibraryId($library_id)
				->filterByInventoryNumber($inv_number);
			if ($inv_serie)
				$items->filterByInventorySerieId($inv_serie);

			if ($items->count() < 1) {
				try {
					// create new item
					$item = new Item();
					$item->setManifestationId(0);	// was null - 13-07-2012: see mods to the requests query......
					$item->setLoanClass(ItemPeer::LOANCLASS_AVAILABLE);
					$item->setLoanStatus(ItemPeer::LOANSTATUS_AVAILABLEEXTRA);
					$item->setItemStatus(ItemStatus::ITEMSTATUS_ONSHELF);
					$item->setItemMedia('F');
					$item->setUsageCount(0);
					$item->setOpacVisible(false);
					$item->setCustomField1('EXTRA');
					if ($inv_serie)
						$item->setInventorySerieId($inv_serie);
					$item->setInventoryNumber($inv_number);
					$item->setCollocation($collocation);
					if ($barcode)
						$item->setBarcode($barcode);
					$item->setTitle($title);
					$item->setActualLibraryId($library->getLibraryId());
					$item->setHomeLibraryId($library->getLibraryId());
					$item->setOwnerLibraryId($library->getLibraryId());
					$item->save();
				} catch (Exception $e) {
					throw new Exception('Error in item creation: '.$e->getMessage(),self::ERR_ITEMCREATION);
				}
			} else {
				$item = $items->findOne();
			}
		}
		/* check if an item request already exists */
		$ir = ItemRequestQuery::create()
			->filterByRequestStatus(array(ItemRequestPeer::STATUS_PENDING, ItemRequestPeer::STATUS_WORKING))
			->filterByPatron($patron)
			->filterByItem($item);
		if ($ir->count() > 0)
			throw new Exception('A request already exists for patron.',self::ERR_REQUESTEXISTSFORPATRON);
		try {
			$item_request = new ItemRequest();
			$item_request->setRequestStatus(ItemRequestPeer::STATUS_PENDING);
			$item_request->setItem($item);
			$item_request->setManifestationId($item->getManifestationId());
			$item_request->setPatron($patron);
			$item_request->setLibrarianId(null);
			$item_request->setExternalLibrary($library);
			$item_request->setRequestDate(time());
			$item_request->setDeliveryLibraryId($this->getUser()->getActualLibraryId());
			$item_request->setRequestNote('EXTRA-AUTO');
			$item_request->save();
			$patron->UpdateLastSeen(true);
		} catch (Exception $e) {
			throw new Exception('Error creating request: '.$e->getMessage(),self::ERR_REQUESTCREATION);
		}
		if ($this->_sendMail) {
			try {
				$this->sendReservationMail($this->getUser()->getActualLibrary(), $library, $item);
			} catch (Exception $e) {
				throw new Exception('Error sending mail: '.$e->getMessage(),self::ERR_MAILERROR);
			}
		}
		return true;
	}

	private function sendReservationMail(Library $fromLibrary, Library $toLibrary, Item $item)
	{
		$mailer = $this->getApplication()->getModule('mail');
		$tpl = DocumentTemplatePeer::getTemplate('EXTRA_REQUEST',
			$this->getApplication()->getGlobalization()->getCulture(),
			$fromLibrary->getLibraryId());
		$placeholders = array(
			'{TITLE}'              => $item->getTitle(),
			'{LIBCODE}'            => $toLibrary->getLibraryCode(),
			'{INVENTORY}'          => $item->getInventorySerieId() . '-' . $item->getInventoryNumber(),
			'{COLLOCATION}'        => $item->getCollocationCombo(),
			'{LIBRARY}'            => $fromLibrary->getLabel(),
			'{LIBRARY_CODE}'       => $fromLibrary->getLibraryCode(),
			'{LIBRARY_ADDRESS}'    => $fromLibrary->getAddress(),
			'{LIBRARY_PHONE}'      => $fromLibrary->getPhone(),
			'{LIBRARY_EMAIL}'      => $fromLibrary->getEmail(),
		);

		$mailer->setFrom("\"{$fromLibrary->getLabel()}\" <{$fromLibrary->getEmail()}>");
		$mailer->setSubject($tpl->getTemplateSubject() . "\n");
		$mailer->setBody(str_replace(array_keys($placeholders), array_values($placeholders), $tpl->getTemplateBody()));
		$mailer->setTo($toLibrary->getEmail());
		$mailer->send();
	}

	public function setSendMail($value)
	{
		$this->_sendMail = $value;
	}

}
