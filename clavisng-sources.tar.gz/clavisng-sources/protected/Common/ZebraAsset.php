<?php
if (isset($_GET['SessionName']))
	session_name($_GET['SessionName']);
$sessionVarName = (isset($_GET['SessionVar']))?
	$_GET['SessionVar']:'ZebraLabelUri';
session_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="it" >
<head><title>Ceci n'est pas une page</title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	<meta http-equiv="content-language" content="en"/>
</head>
<body onLoad="window.close();">
<img src="<?php echo $_SESSION[$sessionVarName]?>" />
</body>
</html>