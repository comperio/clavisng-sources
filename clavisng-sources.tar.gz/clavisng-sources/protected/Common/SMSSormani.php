<?php

/**
 * SMSSormani class.
 * A module for sending messages through Sormani (MI) SMS gateway.
 *
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Cristian Chiarello <cristian@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version $Id$
 */
require_once 'vendor/autoload.php';

class SMSSormani extends SMSDummyModule
{

	protected $apiurl = "http://mssormani.comune.milano.it/WSRV/smsService.aspx";
	
	public function setApiUrl($url)
	{
		$this->apiurl = $url;
	}
	
	public function getApiUrl()
	{
		return $this->apiurl;
	}
	
	/**
	 * Send message.
	 * 
	 * @see protected/Common/NotificationManager.php -> DoSmsReport
	 *
	 * @param type $requestID (appid|libid|notificationid)
	 * @return array with status and essors if any
	 */
	public function sendMessage( $requestID = null )
	{
		$result = array( "status" => "OK", "errors" => array(), "data" => array() );
		$notification = NULL;
		$nId = time(); 

		try
		{
			$msgIds = explode( "|", $requestID );
			if ( is_array( $msgIds ) && count( $msgIds ) == 3 )
			{
				$nId = $msgIds[ 2 ];
				$notification = NotificationQuery::create()->findOneByNotificationId( $nId );
				if ( $notification instanceof Notification )
				{
					$notes = array( "backend" => "smssormani", "smsid" => $requestID, "notificationid" => $nId, "to" => $this->getReceiver() );
					$notification->setNotes( serialize( $notes ) );
					$notification->save();
				}
				else
				{
					Prado::log( __METHOD__ . " LINE " . __LINE__ . " ERROR: invalid request ID " . $requestID . " I cannot save message id to notification." );
					$notification = NULL;
				}
			}
			else
			{
				Prado::log( __METHOD__ . " LINE " . __LINE__ . " ERROR: invalid request ID " . $requestID . " I cannot save message id to notification." );
			}
		}
		catch ( Exception $ex )
		{
			Prado::log( __METHOD__ . " ERR: {$ex->getMessage()}" );
			$notification = NULL;
		}

		try
		{
			
			$data = array('id' => $nId, 'c' => $this->getReceiver(), 'm' => $this->getSender() , 't' => $this->getMessage());
			$options = array(
				'http' => array(
					'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
					'method'  => 'POST',
					'content' => http_build_query($data)
				)
			);
			$context  = stream_context_create($options);
			$response = file_get_contents($this->apiurl, false, $context);
			if ($response === FALSE) 
			{
				Prado::log( __METHOD__ . " response error calling {$this->apiurl}" );
			}
			else
			{
				if( $response != "")
				{
					Prado::log( __METHOD__ . " server response: {$response}" );
					$result[ "status" ] = "KO";
					$result[ "errors" ][] = "Exception {$response}";
				}
			}
		}
		catch ( Exception $ex )
		{
			$exmsg = $ex->getMessage();
			Prado::log( __METHOD__ . " ERR: {$exmsg}" );
			$result[ "status" ] = "KO";
			$result[ "errors" ][] = "Exception {$exmsg}";
			return $result;
		}

		return $result;
	}

	public function getMsgNo()
	{
		$doublechars = array( "€", "[", "]", "{", "}", "|", "\\", "^", "~" );
		$smslen = strlen( $this->getMessage() );
		foreach ( $doublechars as $c )
		{
			$smslen += substr_count( $this->getMessage(), $c );
		}
		return ($smslen < 161) ? 1 : ceil( $smslen / 153 );
	}

}
