<?php

/**
 * ClavisPlugin class
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @copyright Copyright &copy; 2011 Comperio srl
 * @version 2.7
 * @package Core
 * @since 2.0
 */
class ClavisPlugin extends TTemplateControl
{
	private $_items;
	private $_shelfId;

	public function resetItems()
	{
		$this->_items = array();
		$this->setItems($this->_items);
	}

	public function setItems($items = null)
	{
		$this->setViewState('Items', $items, null);
	}

	public function getItems()
	{
		$this->_items = $this->getViewState('Items');
		
		return $this->_items;
	}

	public function resetGetCheckedItemsFunctionName()
	{
		$this->setGetCheckedItemsFunctionName('');
	}

	public function resetGetCheckedItemsIdsFunctionName()
	{
		$this->setGetCheckedItemsIdsFunctionName('');
	}

	public function setGetCheckedItemsFunctionName($name = '')
	{
		$this->setViewState('GetCheckedItemsFunctionName', $name, '');
	}

	public function getGetCheckedItemsFunctionName()
	{
		return $this->getViewState('GetCheckedItemsFunctionName', '');
	}

	public function setGetCheckedItemsIdsFunctionName($name = '')
	{
		$this->setViewState('GetCheckedItemsIdsFunctionName', $name, '');
	}

	public function getGetCheckedItemsIdsFunctionName()
	{
		return $this->getViewState('GetCheckedItemsIdsFunctionName', '');
	}

	public function setGetCheckedObjectsIdsFunctionName($name = '')
	{
		$this->setViewState('GetCheckedObjectsIdsFunctionName', $name, '');
	}

	public function getGetCheckedObjectsIdsFunctionName()
	{
		return $this->getViewState('GetCheckedObjectsIdsFunctionName', '');
	}

	public function setCountCheckedItemsFunctionName($name = '')
	{
		$this->setViewState('CountCheckedItemsFunctionName', $name, '');
	}

	public function getCountCheckedItemsFunctionName()
	{
		return $this->getViewState('CountCheckedItemsFunctionName', '');
	}

	public function setRemoveItemsFunctionName($name = '')
	{
		$this->setViewState('RemoveItemsFunctionName', $name, '');
	}
	
	public function getRemoveItemsFunctionName()
	{
		return $this->getViewState('RemoveItemsFunctionName', '');
	}
	
	public function removeItems($param)
	{
		$output = array();
		$functionName = TPropertyValue::ensureString($this->getRemoveItemsFunctionName());

		if ($functionName != '')
			$output = $this->getPage()->$functionName($param);

		return $output;
	}

	public function setMoveItemsFunctionName($name = '')
	{
		$this->setViewState('MoveItemsFunctionName', $name, '');
	}
	
	public function getMoveItemsFunctionName()
	{
		return $this->getViewState('MoveItemsFunctionName', '');
	}
	
	public function moveItems($param1, $param2, $param3)
	{
		$output = array();
		$functionName = TPropertyValue::ensureString($this->getMoveItemsFunctionName());

		if ($functionName != '')
			$output = $this->getPage()->$functionName($param1, $param2, $param3);

		return $output;
	}

	public function getCheckedItems($param1 = false, $param2 = false)
	{
		$output = array();
		$functionName = TPropertyValue::ensureString($this->getGetCheckedItemsFunctionName());

		if ($functionName != '')
			$output = $this->getPage()->$functionName($param1, $param2);

		return $output;
	}

	public function getCheckedItemsIds($param1 = false, $param2 = false)
	{
		$output = array();
		$functionName = TPropertyValue::ensureString($this->getGetCheckedItemsIdsFunctionName());
		
		if ($functionName != '')
			$output = $this->getPage()->$functionName($param1, $param2);

		return $output;
	}

	public function getCheckedObjectsIds($param1 = false, $param2 = false)
	{
		$output = array();
		$functionName = TPropertyValue::ensureString($this->getGetCheckedObjectsIdsFunctionName());
		
		if ($functionName != '')
			$output = $this->getPage()->$functionName($param1, $param2);

		return $output;
	}

	public function countCheckedItems($param1 = false, $param2 = false)
	{
		$output = 0;
		$functionName = TPropertyValue::ensureString($this->getCountCheckedItemsFunctionName());
		
		if ($functionName != '')
			$output = $this->getPage()->$functionName($param1, $param2);

		return $output;
	}

	public function setShelfId($shelfId = null)
	{
		if ($shelfId == null)
		{
			$shelfId = $this->_shelfId;
		}
		else
		{
			$this->_shelfId = $shelfId;
		}

		$this->setViewState('ShelfId', $shelfId, null);
	}

	public function getShelfId()
	{
		if (is_null($this->_shelfId))
			$this->_shelfId = $this->getViewState('ShelfId');

		return $this->_shelfId;
	}

	public function getShelf()
	{
		$output = null;
		$shelfId = intval($this->getShelfId());
		
		if ($shelfId > 0)
			$output = ShelfQuery::create()->findPk($shelfId);

		return $output;
	}

	public function removePlugin()
	{
		$this->getApplication()->getSession()->add('plugin', null);
	}

	public function onCancel($sender, $param)
	{
		$this->getPage()->writeDelayedMessage(Prado::localize('Operazione annullata'),
												ClavisMessage::INFO);
		
		$this->onClose(null, null);
	}

	public function onClose($sender = null, $param = null)
	{
		$this->removePlugin();
		$this->getPage()->reloadPage();
	}

	public function isDataSourceNeeded()
	{
		return true;
	}

	public function createWriter()
	{
		return $this->getPage()->getResponse()->getAdapter()->createNewHtmlWriter('THtmlWriter', $this->getPage()->getResponse());
	}

}