var Comperio = Comperio || {};
Comperio.ClavisNotification = Comperio.ClavisNotification || {};

Comperio.ClavisNotification.notify = function (n) {
	var notifications = JSON.parse(n);

	for (var i = 0; i < notifications.length; i++) {
		notifications[i].options.msg = notifications[i].text;

		if (notifications[i].options.enabled === true) {

			Lobibox.notify(notifications[i].level, notifications[i].options);

			if (typeof Comperio.ClavisLocalStorage !== 'undefined') {
				Comperio.ClavisLocalStorage.pushItem('ClavisNotificationQueue', notifications[i]);
			}
		}
	}
	return true;
};