<?php

/**
 *
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Console
 * @since 2.5.0
 */

require_once('ClavisCommandLineAction.php');

/**
 * @package Console
 * @since 2.5.0
 */
class ClavisActionCleanup extends ClavisCommandLineAction
{
	protected $action = 'cleanup';
	protected $parameters = array();
	protected $optional = array('all | jasper');
	protected $description = 'Cleans up the assets and runtime dir along with compiled jasper templates. If called with optional param "jasper", only cleans jasper templates.';

	private static function rrmdir($path,$pattern = '*')
	{
		if (is_file($path)) {
			if (fnmatch($pattern,basename($path)))
				@unlink($path);
		} else {
			foreach (glob($path.'/*') as $subpath)
				self::rrmdir($subpath,$pattern);
			@rmdir($path);
		}
	}

	public function performAction($args)
	{
		global $basePath, $SITEPATH;

		if (count($args) > 1 && $args[1] != 'jasper')
		{	
			foreach (glob("{$basePath}/assets/*") as $path)
				self::rrmdir($path);

			foreach (glob($SITEPATH."/runtime/*") as $path)
				self::rrmdir($path);
		}
		
		foreach (glob($SITEPATH."/storage/report/jasper/*") as $path)
			self::rrmdir($path,'*.jasper');

		$tpllist = DocumentTemplateQuery::create()
			->filterByTemplateMedia(DocumentTemplatePeer::MEDIA_JASPER)
			->update(array('TemplateBody' => null),null,true);

        $appid = Prado::getApplication()->getID();

        $toDelete = new APCIterator('user', "/^{$appid}-/",APC_ITER_KEY);
        apcu_delete($toDelete);

        echo "\n#### ALL DONE!!! ####\n";
		return true;
	}
}