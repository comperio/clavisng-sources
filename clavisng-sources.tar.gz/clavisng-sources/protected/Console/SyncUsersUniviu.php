<?php

/**
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Console
 * @since 2.5.0
 */

require_once('ClavisCommandLineAction.php');

/**
 * @package Console
 * @since 2.5.0
 */
class ClavisActionSyncUsersUniviu extends ClavisCommandLineAction
{
	protected $action = 'sync_users_univiu';
	protected $parameters = array();
	protected $optional = array('csv_file');
	protected $description = "Synchronization script for UniVIU users. Optional parameter defines the CSV file (or address), defaults to basepath/test.csv";

	public function performAction($args)
	{
		global $basePath;

		$csvfile = (isset($args[1])) ? $args[1] : $basePath.'/test.csv';

		$row = 1;
		if (($handle = fopen($csvfile, 'r')) !== false) {
			while (($data = fgetcsv($handle, 4096, ';', '"')) !== false) {
				if ($data[0] == 'patron_id')
					continue;

				echo "\nbarcode={$data[23]}";

				$p = PatronQuery::create()
					->filterByBarcode($data[23])
					->findOneOrCreate();

				if (trim($data[1]))
					$p->setRegistrationLibraryId($data[1]);
				if (trim($data[2]))
					$p->setPreferredLibraryId($data[2]);
				if (trim($data[4]))
					$p->setGender($data[4]);
				if (trim($data[5]))
					$p->setTitle($data[5]);
				if (trim($data[6]))
					$p->setName($data[6]);
				if (trim($data[7]))
					$p->setLastname($data[7]);
				if (trim($data[8]))
					$p->setCivilStatus($data[8]);
				if (trim($data[9]))
					$p->setNationalId($data[9]);
				if (trim($data[10]))
					$p->setDocumentType($data[10]);
				if (trim($data[11]))
					$p->setDocumentNumber($data[11]);
				if (trim($data[12]))
					$p->setDocumentEmitter($data[12]);
				if (trim($data[13]))
					$p->setDocumentExpiry($data[13]);
				if (trim($data[14]))
					$p->setCitizenship($data[14]);
				if (trim($data[15]))
					$p->setPatronStatus($data[15]);
				if (trim($data[16]))
					$p->setBirthDate($data[16]);
				if (trim($data[17]))
					$p->setBirthCity($data[17]);
				if (trim($data[18]))
					$p->setBirthProvince($data[18]);
				if (trim($data[19]))
					$p->setBirthCountry($data[19]);
				if (trim($data[20]))
					$p->setPatronNote($data[20]);
				if (trim($data[21]))
					$p->setLoanClass($data[21]);
				if (trim($data[22]))
					$p->setCardCode($data[22]);
				if (trim($data[23]))
					$p->setBarcode($data[23]);
				if (trim($data[24]))
					$p->setRfidCode($data[24]);
				if (trim($data[25]))
					$p->setCardExpire($data[25]);
				if (trim($data[26]))
					$p->setMaxLoans($data[26]);
				if (trim($data[27]))
					$p->setSurfEnable($data[27]);
				if (trim($data[28]))
					$p->setOpacUsername($data[28]);
				if (trim($data[29]))
					$p->setOpacSecret($data[29]);
				if (trim($data[33]))
					$p->setVoiceEnable($data[33]);
				if (trim($data[34]))
					$p->setVoicePin($data[34]);
				if (trim($data[35]))
					$p->setOpacEnable($data[35]);
				if (trim($data[36]))
					$p->setPrivacyApprove($data[36]);
				if (trim($data[38]))
					$p->setAreasOfInterest($data[38]);
				if (trim($data[39]))
					$p->setBiography($data[39]);
				if (trim($data[42]))
					$p->setAccessNote($data[42]);
				if (trim($data[43]))
					$p->setAccessAlert($data[43]);
				if (trim($data[44]))
					$p->setStatisticStudy($data[44]);
				if (trim($data[45]))
					$p->setStatisticWork($data[45]);
				if (trim($data[46]))
					$p->setLastSeen($data[46]);
				if (trim($data[47]))
					$p->setCustom1($data[47]);

				try {
					$p->save();
				} catch (Exception $e) {
					die('Ouch! '.$e);
				}

				$address = AddressQuery::create()
					->filterByPatron($p)
					->filterByAddressType($data[51])
					->filterByStreetType($data[54])
					->filterByStreet($data[55])
					->filterByStreetNum($data[56])
					->filterByVillage($data[57])
					->filterByCity($data[58])
					->filterByZip($data[59])
					->filterByProvince($data[60])
					->filterByCountry($data[61])
					->filterByAddressPref($data[52])
					->findOneOrCreate();
				$address->setAddressNote($data[53]);
				$address->save();

				$email = ContactQuery::create()
					->filterByPatron($p)
					->filterByContactType(ContactPeer::TYPE_EMAIL)
					->filterByContactValue($data[49])
					->filterByContactPref($data[50])
					->findOneOrCreate();
				if ($email->isNew())
					$email->save();

				$p->clearAllReferences(true);
				unset($p);
			}
			fclose($handle);
		}
		echo "\n#### ALL DONE!!! ####\n";
		return true;
	}
}