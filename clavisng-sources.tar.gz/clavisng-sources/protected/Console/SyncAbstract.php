<?php
/**
 * ClavisActionSyncAbstract class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Console
 */
require_once('ClavisCommandLineAction.php');

/**
 * ClavisActionSyncAbstract Class
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Console
 * @since 2.5.0
 */
class ClavisActionSyncAbstract extends ClavisCommandLineAction
{
	protected $action = 'sync_abstract';
	protected $parameters = array('--adb abstract.db');
	protected $optional = array();
	protected $description = "";
	/** @var $logger Log */
	protected $logger;


	public function performAction($args)
	{
		$this->logger = Log::factory('console', '', $this->action);
		$this->logger->info('=== Starting ===');

		$params = $this->parseArgs($args);
		try {
			$this->logger->info('Reading abstracts from ' . $params['adb']);

			$adb = new SQLite3($params['adb'], SQLITE3_OPEN_READONLY);
			if ($adb instanceof SQLite3) {
				$statement = $adb->prepare("SELECT ean, abstract FROM abstract WHERE ean = :ean");


				$this->logger->info('Processing manifestations - this can take a long time, please be patient...');
				$manifestations = ManifestationQuery::create()
					->where('unimarc not like \'%<d330%\' and (unimarc like \'%<d073%\' or unimarc like \'%<d010%\')');

				$index = 0;
				$man_count = $manifestations->count();
				$man_result = $manifestations->find();

				/* @var $m Manifestation */
				foreach ($man_result as $m) {

					try {
						$tm = $m->getTurboMarc();
					} catch (Exception $e) {
						$this->logger->err(sprintf('Manifestation with id %s has a Malformed XML. Can\'t save. (%s)', $m->getManifestationId(), $e->getMessage()));
						continue;
					}

					$abstract = $tm->getAbstract();

					$sub = (trim($abstract) !== '') ? ' has an abstract (%s...), skipping.' : '';
					$format_string = sprintf('Processing manifestations - %%s of %%s...%s', $sub);
					$this->logger->info(sprintf($format_string, ++$index, $man_count, mb_substr($abstract, 0, 20)));

					if (trim($abstract) !== '') {
						continue;
					}

					$eans = [];
					foreach ($tm->d073 as $field) {
						if (isset($field->sa)) {
							array_push($eans, (string)$field->sa[0]);
						}
					}

					foreach ($tm->d010 as $field) {
						if (isset($field->sa)) {
							array_push($eans, (string)$field->sa[0]);
						}
					}

					$abstract_set = false;
					foreach ($eans as $ean) {
						$ean = Clavis::normalizeStdNum($ean);
						if (strlen($ean) != 13) {
							$ean = Clavis::IsbnToEan13($ean);
						}

						if ($ean !== '' && $abstract_set == false) {
							$statement->bindValue(':ean', $ean);
							$results = $statement->execute();

							if ($results instanceof SQLite3Result) {
								while ($row = $results->fetchArray()) {
									if (trim($row['abstract']) != '') { // always true, as getAbstract.php exports only records having an abstract.
										try {
											$tm->addField(330)->addSubField('a', trim($row['abstract']));
											$m->setUnimarc($tm->asXML());
											$m->save();
											$abstract_set = true;
											$this->logger->info(sprintf('Set abstract %s  for manifestation [%s] %s', mb_substr($row['abstract'], 0, 20) . '...', $m->getManifestationId(), $m->getTitle()));
										} catch (Exception $e) {
											$this->logger->err(sprintf('Manifestation with id %s can\'t be saved. (%s)', $m->getManifestationId(), $e->getMessage()));
											$abstract_set = false;
										}
									}
								}
							}
						}
					}
					unset($m);
				}

				$this->logger->info('#### ALL DONE!!! ####');
				return true;
			}

			$this->logger->err('Error connecting to the ' . $params['adb'] . ' SQLite file');
			return false;
		} catch (Exception $e) {
			$this->logger->err('Error: ' . $e->getMessage());
		}
	}
}
