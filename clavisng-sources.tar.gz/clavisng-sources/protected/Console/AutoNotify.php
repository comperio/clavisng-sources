<?php

/**
 *
 *
 * @author  Ciro Mattia Gonano
 * @version 2.7
 * @package Console
 * @since   2.5.0
 */

require_once 'ClavisCommandLineAction.php';

/**
 * Interface SendNotification
 */
Interface SendNotification
{
	/**
	 * @param $from
	 * @param $to
	 * @param $message
	 * @param $n
	 * @param $logger
	 * @param $dryRun
	 *
	 * @return mixed
	 */
	public function send($from, $to, $message, $n, $logger, $dryRun);
}

/**
 * @package Console
 *
 * Internal Status Usage
 * A = Queued
 * B1 = Sent to channel 1
 * B2 = Sent to channel 2
 * B3 = Sent to channel 3
 * B4 = Sent to channel 4
 * B5 = Sent to channel 5
 * C = Not delivered
 * D = To be reported
 * E = Reported
 * F = No available channels
 * G = No available template
 * H = No available config
 *
 * @since   2.8.8
 */
class ClavisActionAutoNotify extends ClavisCommandLineAction
{
	/**
	 * @var string
	 */
	protected $action = 'auto_notify';
	/**
	 * @var array
	 */
	protected $parameters = array();
	/**
	 * @var array
	 */
	protected $optional = array('--dryrun', '-config <filepath>');
	/**
	 * @var string
	 */
	protected $description = 'Auto notification scheduled script.';

	/** @var $logger Log */
	protected $logger;
	/**
	 * @var
	 */
	protected $config;
	/**
	 * @var
	 */
	protected $stages;
	/**
	 * @var
	 */
	protected $queries;

	/**
	 * @var
	 */
	protected $dryrun;

	/**
	 * @param $args
	 *
	 * @return bool
	 * @throws \PropelException
	 * @throws \Twig_Error_Loader
	 * @throws \Twig_Error_Runtime
	 * @throws \Twig_Error_Syntax
	 */
	public function performAction($args)
	{
		/*
		Propel::getConnection()->useDebug(true);
		$config = Propel::getConfiguration(PropelConfiguration::TYPE_OBJECT);
		$config->setParameter('debugpdo.logging.details.time.enabled', true);
		$config->setParameter('debugpdo.logging.details.mem.enabled', true);
		Propel::setLogger($this->logger);
		*/

		$params = $this->parseArgs($args);
		$this->dryrun = isset($params['dryrun']) ? true : false;

		$logname = $this->dryrun ? 'DRYRUN-NOTIFY' : 'NOTIFY';
		$this->logger = Log::factory('console', '', $logname);
		$this->logger->info('Starting auto notification script.');

		//if(!$this->loadConfiguration($params))
		//    return false;

		$this->loadConfiguration($params);


		foreach ($this->stages as $stage) {
			$this->processingNotifications($stage);
		}

		$this->reportResults();

		$this->logger->info('Finishing auto notification script.');

		return true;

	}

	/**
	 * @param $notification
	 *
	 * @return mixed
	 */
	public function beforeSend($notification)
	{
		return $notification;
	}

	/**
	 * @param $notification
	 *
	 * @return mixed
	 */
	public function afterSend($notification)
	{
		return $notification;
	}

	/**
	 * @param $notification
	 * @param $stage
	 *
	 * @return mixed
	 */
	public function beforeProcessing($notification, $stage)
	{
		return $notification;
	}

	/**
	 * @param $notification
	 * @param $stage
	 *
	 * @return mixed
	 */
	public function afterProcessing($notification, $stage)
	{
		return $notification;
	}

	/**
	 * @param $params
	 *
	 * @return bool
	 */
	public function loadConfiguration($params)
	{
		if (isset($params['config']) && file_exists($params['config'])) {
			$this->logger->info("Loading configuration from file {$params['config']}");

			$configs = include $params['config'];

			$this->stages = $configs['STAGES'];
			$this->queries = $configs['QUERIES'];
			$this->config = $configs['CONFIG'];

		} else if (isset($params['config'])) {
			$this->logger->err("Unable to load configuration file {$params['config']}");
			return false;
		} else {
			$this->logger->info('Loading configuration sample');
			$this->stages = ['PENDING', 'ERROR', 'LATE'];

			$this->queries = [
				'PENDING' =>
					NotificationQuery::create()
						->filterByNotificationChannel('Z')// Auto Channel
						->filterByNotificationState('A')// Pending
						->filterByInternalStatus('A'), // Queued

				'ERROR' =>
					NotificationQuery::create()
						->filterByNotificationChannel('Z')// Auto Channel
						->filterByNotificationState('D')// Error
						->filterByInternalStatus('B%', Criteria::LIKE), //Sent to any channel
				'LATE' =>
					NotificationQuery::create()
						->filterByNotificationChannel('Z')// Auto Channel
						->filterByNotificationState('B')// Sent
						->filterByInternalStatus('B%', Criteria::LIKE)// Sent to any channel
						->filterByDateUpdated(time() - 60 * 60, Criteria::LESS_THAN), // 1 Hour NO life signs
			];

			$this->config = [
				'report_to' => 'SYSTEM', // LIBRARY, EMAIL
				'default_sender_id' => 1,

				'notification_config' => [
					'A' => [ // Solic 1
						'channels' => ['SMS', 'EMAIL', 'CHATBOT', 'APP', 'VOICE'],
						'deadline' => '5', // In days
						'report_failure' => true,
						'templates' => ['SMS' => 46, 'EMAIL' => 46, 'CHATBOT' => 46, 'APP' => 46, 'VOICE' => 46]
					],
				],
				'contact_map' => [
					'E' => 'EMAIL',
					'C' => 'SMS',
					'L' => 'CHATBOT',
					'T' => 'VOICE',
					'I' => 'APP'
				],
				'channel_config' => [
					'EMAIL' => [
						'retry_after' => '',
						'timeout' => '24', // Afer 1 day with no feedback mail is considered not sent
						'time_window' => ['12:00', '20:00'],
						'enabled' => true,
					],
					'SMS' => [
						'retry_after' => '',
						'timeout' => '4', // Hours
						'time_window' => ['00:00', '23:59'],
						'enabled' => true
					],
					'CHATBOT' => [
						'retry_after' => '',
						'timeout' => '4', // Hours
						'time_window' => ['00:00', '23:59'],
						'enabled' => true,
					],
					'APP' => [
						'retry_after' => '',
						'timeout' => '4', // Hours
						'time_window' => ['00:00', '23:59'],
						'enabled' => true,
					],
					'VOICE' => [
						'retry_after' => '',
						'timeout' => '4', // Hours
						'time_window' => ['00:00', '23:59'],
						'enabled' => true,
					],
				]
			];
		}
	}

	/**
	 * @param $stage
	 *
	 * @throws \PropelException
	 * @throws \Twig_Error_Loader
	 * @throws \Twig_Error_Runtime
	 * @throws \Twig_Error_Syntax
	 */
	public function processingNotifications($stage)
	{
		$this->logger->info("Processing {$stage} notifications");

		$notificationQuery = $this->queries[$stage];

		$this->logger->info('Found ' . $notificationQuery->count() . ' pending notifications');

		foreach ($notificationQuery->find() as $notification) {
			$this->logger->info(">>>> Processing notification id {$notification->getNotificationId()}");

			/** @var $notification Notification */
			if (isset($this->config['notification_config'][$notification->getNotificationClass()])) {
				$notification = $this->beforeProcessing($notification, $stage);

				if ($notification instanceof Notification) {

					$this->handleNotification($notification, $stage);
					$notification = $this->afterProcessing($notification, $stage);

					if ($notification instanceof Notification) {
						try {
							$this->dryrun || $notification->save();
						} catch (Exception $e) {
							$this->logger->err("Unable to update notification id {$notification->getNotificationId()}: " . $e->getMessage());
						}
					}
				}
			} else {
				$this->logger->warning('No config for notification class ' . $notification->getNotificationClass() . ' id: ' . $notification->getNotificationId());
				$notification->setNotificationState('D'); // Error
				$notification->setInternalStatus('H');
				$this->dryrun || $notification->save();
			}
		}
	}

	/**
	 * @throws \PropelException
	 */
	public function reportResults()
	{
		$this->logger->info('Report problems');

		$notificationQuery = NotificationQuery::create()
			->filterByNotificationChannel('Z')// Auto Channel
			->filterByNotificationState(['D', 'G'])// Error or Expired
			->filterByInternalStatus('D'); // To report

		$this->logger->info('Found ' . $notificationQuery->count() . ' to report');

		foreach ($notificationQuery->find() as $n) {
			/** @var $n Notification */
			$reportTo = $this->config['report_to'];

			$this->logger->info("Reporting to {$reportTo} notification id: {$n->getNotificationId()}");
			$n->addLogNote("Riportata notifica a {$reportTo}");
			$n->setInternalStatus('E'); // Reported
			$this->dryrun || $n->save();
		}
	}

	/**
	 * @param \Notification $n
	 * @param               $stage
	 *
	 * @throws \Twig_Error_Loader
	 * @throws \Twig_Error_Runtime
	 * @throws \Twig_Error_Syntax
	 * @throws \PropelException
	 */
	public function handleNotification(Notification $n, $stage)
	{
		$target = $this->findTarget($n);

		if ($target != null && $target['has_contacts']) {

			$nextAction = $this->whatsNextAction($n, $target, $stage);

			if ($nextAction['type'] == 'SEND') {
				try {
					if ($this->sendToChannel($n, $nextAction['channel'], $target)) {
						$n->setNotificationState('B');
						$n->setInternalStatus($nextAction['internal_state']);
						$n->addLogNote("Invio notifica su canale {$nextAction['channel']} a " . implode(',', $target['contacts'][$nextAction['channel']]));
					} else {
						$this->logger->err("Errore invio su canale {$nextAction['channel']}");
						$n->setNotificationState('D'); // Error sending
						$n->setInternalStatus($nextAction['internal_state']);
						$n->addLogNote("Errore Invio notifica su canale {$nextAction['channel']} a " . implode(',', $target['contacts'][$nextAction['channel']]));
					}

				} catch (NotificationNetworkErrorException $e) {
					$this->logger->warning("Canale {$nextAction['channel']} non raggiungibile in questo momento.");
				}
			}
		} else {
			$this->logger->warning('Unable to handle target ' . $n->getObjectClass() . ' id:' . $n->getObjectId());
			$n->setNotificationState('D'); // Error
			$n->setInternalStatus('F'); // No user or contacts
		}
	}

	/**
	 * @param \Notification $n
	 * @param               $channel
	 * @param               $target
	 *
	 * @return bool|mixed
	 * @throws \Twig_Error_Loader
	 * @throws \Twig_Error_Runtime
	 * @throws \Twig_Error_Syntax
	 */
	public function sendToChannel(Notification $n, $channel, $target)
	{
		$this->beforeSend($n);

		$notification_params = json_decode($n->getMessage(), true);

		$dest = $target['contacts'][$channel];
		$message = $this->renderTemplate($n, $channel);
		if (empty($message)) {
			$this->logger->info('La notifica da inviare è vuota. ');
			return false;
		}

		$this->logger->info("Send message [{$message}] to channel {$channel} to {$dest[0]}");

		// get the sender library.
		// -------------------------------------------------------------------------------------------------------------
		$custom_sender = array_key_exists('sender_library_id', $notification_params)
			? $notification_params['sender_library_id']
			: null;
		$default_sender = $this->config['default_sender_id'];
		$sender = (null === $custom_sender) ? $default_sender : $custom_sender;

		// get the library in charge of sms accounting.
		// -------------------------------------------------------------------------------------------------------------
		$custom_charge_library = array_key_exists('charge_library_id', $notification_params)
			? $notification_params['charge_library_id']
			: null;
		$default_charge_library = $this->config['channel_config']['SMS']['charge_library_id'];
		$charge = (null === $custom_charge_library) ? $default_charge_library : $custom_charge_library;

		$notification_center = new NotificationCenter(strtolower($channel));
		$result = $notification_center->send($sender, $dest, $message, $n, $this->logger, $this->dryrun, $charge);

		$this->afterSend($n);
		return $result;
	}

	/**
	 * @param \Notification $n
	 * @param               $channel
	 *
	 * @return string
	 * @throws \Twig_Error_Loader
	 * @throws \Twig_Error_Runtime
	 * @throws \Twig_Error_Syntax
	 */
	public function renderTemplate(Notification $n, $channel)
	{
		// -------------------------------------------------------------------------------------------------------------
		// Interrogo la tabella $tableName alla ricerca dei record con primary key uguale a $values.
		// Se la tabella non e' fra quelle consentite, ritorno il valore espresso in $values.
		// -------------------------------------------------------------------------------------------------------------
		$getTemplateData = function ($tableName, $values) {
			$isValidTable = in_array(strtolower($tableName), array('patron', 'loan', 'item', 'library'));
			$tableClassQuery = ucfirst($tableName) . 'Query';

			$result = $values;
			if ($isValidTable) {
				if (is_array($values)) {
					$result = array_map(function ($value) use ($tableClassQuery) {
						return $tableClassQuery::create()->findPk($value);
					}, $values);
				} else {
					$result = $tableClassQuery::create()->findPk($values);
				}
			}
			return $result;
		};

		// -------------------------------------------------------------------------------------------------------------

		$template_id = $this->config['notification_config'][$n->getNotificationClass()]['templates'][$channel];
		$tpl_object = DocumentTemplatePeer::retrieveByPK($template_id);

		// nel caso in cui non abbia ricevuto un template id valido, ritorno un corpo della notifica vuoto.
		if ($tpl_object === null) {
			$this->logger->err("Template per invio notifica con id $template_id non trovato.");
			return '';
		}

		// -------------------------------------------------------------------------------------------------------------
		// Valorizzo i dati da passare al template twig.
		// -------------------------------------------------------------------------------------------------------------
		$twig_data['notification'] = $n;
		$twig_data['channel'] = $channel;

		$notification_params = (array)json_decode($n->getMessage());
		foreach ($notification_params as $table_name => $values) {
			$twig_data[$table_name] = $getTemplateData($table_name, $values);
		}

		// -------------------------------------------------------------------------------------------------------------
		// Ritorno il testo della notifica da spedire.
		// -------------------------------------------------------------------------------------------------------------
		$loader = new Twig_Loader_Array(
			array($channel => $tpl_object->getTemplateBody())
		);
		$twig = new Twig_Environment($loader);
		$document = $twig->render($channel, $twig_data);

		return $document;
	}

	/**
	 * @param \Notification $n
	 * @param               $target
	 * @param               $stage
	 *
	 * @return null
	 * @throws \PropelException
	 */
	public function whatsNextAction(Notification $n, $target, $stage)
	{
		$action = null;

		$datetime1 = date_create($n->getDateCreated());
		$datetime2 = date_create();
		$interval = date_diff($datetime1, $datetime2);
		$activeDays = $interval->format('%a');

		$deadline = $this->config['notification_config'][$n->getNotificationClass()]['deadline'];

		if ($activeDays > $deadline) {
			$this->logger->info("Notification has been created {$activeDays} ago, deadline is {$deadline} days");
			$n->setNotificationState('G'); // Expired
			if ($this->config['notification_config'][$n->getNotificationClass()]['report_failure']) {
				$n->setInternalStatus('D');
			} else {
				$n->setInternalStatus('E');
			}

			$n->addLogNote("Oltre tempo massimo di consegna. {$activeDays} / {$deadline}");

			return $action;
		}

		$channel = $this->whatsNextChannel($n, $target);

		if ($channel != null) {
			$this->logger->info("Next channel [{$channel}] stage {$stage}");
			$now = date('H:i');

			if ($now >= $this->config['channel_config'][$channel]['time_window'][0] &&
				$now <= $this->config['channel_config'][$channel]['time_window'][1]) {

				if ($stage == 'PENDING') { // First Notification
					$action['type'] = 'SEND';
					$action['channel'] = $channel;
					$action['internal_state'] = "B1 {$channel}";
				} else if ($stage == 'ERROR' || $stage == 'LATE') {
					$action['type'] = 'SEND';
					$action['channel'] = $channel;
					$action['internal_state'] = 'B' . (substr($n->getInternalStatus(), 1, 1) + 1) . " {$channel}";
				} else {
					$this->logger->err("Errore in whatsNextAction {$n->getNotificationId()} stage {$stage}");
					$n->addLogNote("Errore interno, impossibile proseguire stage:{$stage}", 'error');
					$n->setNotificationState('D');
					$n->setInternalStatus('D');
				}
			} else {
				$this->logger->debug("[$now] Not in Time window {$this->config['channel_config'][$channel]['time_window'][0]}-{$this->config['channel_config'][$channel]['time_window'][1]} for channel {$channel}");
			}

		} else {
			$this->logger->info("Esauriti i canali per la notifica id {$n->getNotificationId()} stage {$stage}");
			$n->setNotificationState('D'); //Errore

			if ($this->config['notification_config'][$n->getNotificationClass()]['report_failure']) {
				$n->setInternalStatus('D');
			} else {
				$n->setInternalStatus('E');
			}

			$n->addLogNote('Esauriti i canali di contatto.');
		}

		if ($action != null) {
			$this->logger->info("Next action {$action['type']} on channel {$action['channel']}");
		} else {
			$this->logger->info('No more action');
		}

		return $action;
	}

	/**
	 * @param \Notification $n
	 * @param               $target
	 *
	 * @return mixed|null
	 * @throws \PropelException
	 */
	public function whatsNextChannel(Notification $n, $target)
	{
		$chanPriority = $this->config['notification_config'][$n->getNotificationClass()]['channels'];
		$targetChan = array_keys($target['contacts']);
		$this->logger->debug('System Channel priority ' . implode(', ', $chanPriority));
		$this->logger->debug('Target Channel priority ' . implode(', ', $targetChan));

		if ($chanPriority[0] == 'PREF' && $target['contact_pref'] != null) { // Channel put first user channel
			$p = array_search($target['contact_pref'], $chanPriority);
			if ($p !== false) {
				array_splice($chanPriority, $p, 1);
				array_unshift($chanPriority, $target['contact_pref']);
			} else {
				array_unshift($chanPriority, $target['contact_pref']);
			}
			$this->logger->info('Pref Channel priority ' . implode(', ', $chanPriority));
		}

		$chanPriority = array_intersect($chanPriority, $targetChan);
		$this->logger->info('Intersect priority ' . implode(', ', $chanPriority));

		$internalStatus = trim(substr($n->getInternalStatus(), 0, 2));
		$sentChannel = substr($n->getInternalStatus(), 3);

		// Check if timeout expired for channel
		$datetime1 = date_format(date_create($n->getDateUpdated()), 'U');
		$datetime2 = date_format(date_create(), 'U');
		$timeoutHours = ($datetime2 - $datetime1) / 3600; // Hours.

		if (isset($this->config['channel_config'][$sentChannel]) && ($this->config['channel_config'][$sentChannel]['timeout'] <= $timeoutHours)) {
			$this->logger->debug("Channel timeout is {$this->config['channel_config'][$sentChannel]['timeout']} and actual idle time is {$timeoutHours} [{$sentChannel}]");
		}

		switch ($internalStatus) {
			case 'A': // Queued
				$nextChannel = reset($chanPriority);
				break;
			case 'B1':
			case 'B2':
			case 'B3':
			case 'B4':
			case 'B5':
				$chanUsed = (int)substr($n->getInternalStatus(), 1, 1) - 1;
				if (isset($chanPriority[$chanUsed + 1])) {
					$nextChannel = $chanPriority[$chanUsed + 1];
				} else {
					$nextChannel = null;
				}
				break;
			default:
				$nextChannel = null;
		}

		return $nextChannel;
	}

	/**
	 * @param \Notification $notification
	 *
	 * @return array|null
	 * @throws \PropelException
	 */
	public function findTarget(Notification $notification)
	{
		switch ($notification->getObjectClass()) {
			case 'Patron':
				$patron = PatronQuery::create()->findPk($notification->getObjectId());

				if ($patron instanceof Patron) {
					$target = array(
						'id' => $patron->getPatronId(),
						'name' => $patron->getCompleteName(),
						'class' => 'patron',
						'obj' => $patron,
						'contacts' => array(),
						'contact_pref' => null,
						'has_contacts' => false
					);
					$contacts = $patron->getContacts();
					foreach ($contacts as $contact) {
						/** @var $contact Contact */
						if (isset($this->config['contact_map'][$contact->getContactType()])) {

							$target['contacts'][$this->config['contact_map'][$contact->getContactType()]][] = $contact->getContactValue();
							$target['has_contacts'] = true;
							if ($contact->getContactPref() == '1') {
								$target['contact_pref'] = $this->config['contact_map'][$contact->getContactType()];
							}
						}
					}

				} else {
					$target = null;
				}
				break;
			case 'Library':
				$target = null;
				break;
			default:
				$target = null;
				break;
		}
		return $target;
	}
}

/**
 * Class NotificationNetworkErrorException
 */
class NotificationNetworkErrorException extends \Exception
{
}

/**
 * Class AutoNotifyTypes
 */
class AutoNotifyTypes
{
	const FIRST_SOLICIT = 'A';              // "1° Sollecito ritardo"
	const SECOND_SOLICIT = 'B';             // "2° Sollecito Ritardo"
	const THIRD_SOLICIT = 'C';              // "3° Solelcito Ritardo"
	const UPDATE_RESERVATION = 'M';         // "Aggiornamento prenotazione"
	const CANCEL_RESERVATION = 'L';         // "Annullamento prenotazione"
	const HAPPY_BIRTHDAY = 'I';             // "Auguri"
	const WELCOME = 'J';                    // "Benvenuto"
	const CONFIRM_CONTACT = 'K';            // "Conferma contatto"
	const GENERIC = 'H';                    // "Generica"
	const NEWSLETTER = 'O';                 // "Newsletter"
	const CUSTOM_0 = '0';                   // "Notifica personalizzata 0"
	const CUSTOM_1 = '1';                   // "Notifica personalizzata 1"
	const READY_TO_LOAN = 'F';              // "Pronto al prestito"
	const EXTRA_ILL_READY_TO_LOAN = 'Z';    // "Pronto al prestito Extra ILL"
	const LOAN_EXPIRING = 'E';              // "Prossima scadenza"
	const PASSWORD_RECOVERY = 'P';          // "Recupero password"
	const OPERATION_RECEIPT = 'N';          // "Ricevuta operazione"
	const EXTRA_ILL_REQUEST = 'X';          // "Richiesta Extra ILL"
	const CARD_EXPIRING = 'Q';              // "Scadenza tessera"
	const LOAN_EXPIRED = 'D';               // "Scaduto"
	const EXTRA_ILL_SOLICIT = 'Y';          // "Sollecito Extra ILL"
	const SUSPENDED_CARD = 'G';             // "Sospensione tessera"
	const SUGGESTION = 'R';                 // "Suggerimenti"
}

/**
 * Class SMSNotification
 */
class SMSNotification implements SendNotification
{
	/**
	 * @param      $from
	 * @param      $to
	 * @param      $message
	 * @param      $n
	 * @param      $logger
	 * @param bool $dryRun
	 * @param null $charge_library_id
	 *
	 * @return bool
	 * @throws \NotificationNetworkErrorException
	 * @throws \PropelException
	 * @throws \Exception
	 */
	public function send($from, $to, $message, $n, $logger, $dryRun = false, $charge_library_id = null) // get notification id
	{
		$m = Prado::getApplication()->getModule('sms');
		if (null === $m) {
			$logger->err('Modulo SMS non abilitato');
			return false;
		}

		if (!$m->checkAuth()) {
			$logger->err('Modulo SMS: Autenticazione backend SMS fallita.');
			return false;
		}

		$chargeLibrary = LibraryQuery::create()->findPk($charge_library_id);
		if (!$chargeLibrary instanceof Library) {
			$logger->err('Modulo SMS: Libreria a cui accreditare SMS non valida.');
			return false;
		}

		$receiver = $to[0];
		$s = LibraryQuery::create()->findPk($from);
		$m->setSender($s->getShortlabel());
		$m->setReceiver($receiver);
		$m->setMessage($message);
		$msgno = $m->getMsgNo();
		$smscredit = $chargeLibrary->getActualSMS();

		if ($smscredit < $msgno) {
			$logger->err('Modulo SMS: Credito insufficiente per l\'invio di SMS.');
			return false;
		}

		if ($dryRun) {
			return true;
		}

		$msgid = Prado::getApplication()->getID() . '|' . $from . '|' . $n->getNotificationId();
		$result = $m->sendMessage($msgid);

		if (is_array($result) && ($result['status'] === 'KO') && ($result['code'] === 6 || $result['code'] === 7)) {
			throw new NotificationNetworkErrorException($result['message'], $result['code']);
		}

		if (is_array($result) && ($result['status'] === 'KO')) {
			$logger->err('Modulo SMS: Credito insufficiente per l\'invio di SMS.');
			return false;
		}

		if (is_array($result) && ($result['status'] === 'OK')) {
			$chargeLibrary->setActualSMS($smscredit - $msgno);
			$chargeLibrary->save();

			$n->setDeliveryDate(time());
			return true;
		}
	}
}

/**
 * Class BotNotification
 */
class BotNotification implements SendNotification
{
	/**
	 * @param      $from
	 * @param      $to
	 * @param      $message
	 * @param      $n
	 * @param      $logger
	 * @param bool $dryRun
	 *
	 * @return bool
	 * @throws \NotificationNetworkErrorException
	 */
	public function send($from, $to, $message, $n, $logger, $dryRun = false) //notification id, delivery time
	{
		/** @var \ChatBotModule $chatBotModule */
		$chatBotModule = Prado::getApplication()->getModule('chatbot');
		if ($chatBotModule === null) {
			$logger->err('Modulo chatbot non abilitato');
			return false;
		}

		if ($dryRun) {
			return true;
		}

		$msgData = array('text' => $message, 'mongo_id' => $to[0], 'receipt' => true);
		try {
			$sent = $chatBotModule->send($msgData, $n->getNotificationId());
		} catch (RuntimeException $e) {
			if (($e->getCode() === 6) || ($e->getCode() === 7)) {
				throw new NotificationNetworkErrorException($e->getMessage(), $e->getCode());
			} else {
				throw $e;
			}
		}

		if (!$dryRun && $sent->status === 'OK') {
			$n->setDeliveryDate(time());
			return true;
		}

		return false;
	}
}

/**
 * Class PushNotification
 */
class PushNotification implements SendNotification
{
	/**
	 * @param      $from
	 * @param      $to
	 * @param      $message
	 * @param      $n
	 * @param      $logger
	 * @param bool $dryRun
	 *
	 * @return bool
	 * @throws \GuzzleHttp\Exception\GuzzleException
	 * @throws \NotificationNetworkErrorException
	 */
	public function send($from, $to, $message, $n, $logger, $dryRun = false) //delivery time
	{
		/** @var \PushBotModule $pushBotModule */
		$pushBotModule = Prado::getApplication()->getModule('pushbot');
		if ($pushBotModule === null) {
			$logger->err('Modulo notifiche push non abilitato');
			return false;
		}

		if ($dryRun) {
			return true;
		}

		try {
			$error = $pushBotModule->send($to[0], $message);
		} catch (\GuzzleHttp\Exception\ConnectException $e) {
			throw new NotificationNetworkErrorException($e->getMessage(), $e->getCode());
		} catch (GuzzleHttp\Exception\TransferException $e) {
			throw new NotificationNetworkErrorException($e->getMessage(), $e->getCode());
		}

		if (!$dryRun && $error === null) {
			$n->setDeliveryDate(time());
			return true;
		}
		return false;
	}
}

/**
 * Class MailNotification
 */
class MailNotification implements SendNotification
{
	/**
	 * @param      $from
	 * @param      $to
	 * @param      $message
	 * @param      $n
	 * @param      $logger
	 * @param bool $dryRun
	 *
	 * @return bool
	 * @throws \NotificationNetworkErrorException
	 */
	public function send($from, $to, $message, $n, $logger, $dryRun = false) //notication id, notification class
	{
		$subject = trim(substr($message, 0, strpos($message, "\n")));
		$message = trim(substr($message, strpos($message, "\n") + 1));

		$mailer = Prado::getApplication()->getModule('mail');

		$mailer->setHeaders(array(
			'X-Mailgun-Variables' => '{"notification_id":' . $n->getNotificationId() . '}',
			'X-Mailgun-Tag' => $n->getNotificationClass()
		));

		$sender = LibraryQuery::create()->findPk($from);
		$mailer->setFrom("\"{$sender->getLabel()}\" <{$sender->getEmail()}>");
		$mailer->setSubject($subject);
		$mailer->setBody($message);
		$mailer->setTo(implode(', ', $to));

		if ($dryRun) {
			return true;
		}

		try {
			$mailer->send();
			return true;
		} catch (Exception $e) {
			// see: https://pear.php.net/manual/en/package.mail.mail.send.php
			if (in_array($e->getCode(), array(
				PEAR_MAIL_SMTP_ERROR_CONNECT,
				PEAR_MAIL_SMTP_ERROR_SENDER,
				PEAR_MAIL_SMTP_ERROR_RECIPIENT,
				PEAR_MAIL_SMTP_ERROR_DATA), true)) {
				throw new NotificationNetworkErrorException($e->getMessage(), $e->getCode());
			}
			$logger->err('Errore invio email: ' . $e->getMessage());
			return false;
		}
	}
}

/**
 * Class NotificationCenter
 */
class NotificationCenter
{
	/**
	 * @var array
	 */
	private $contexts = array();
	/**
	 * @var
	 */
	private $medium;

	/**
	 * NotificationCenter constructor.
	 *
	 * @param $medium
	 */
	public function __construct($medium)
	{
		$this->contexts['sms'] = new SMSNotification();
		$this->contexts['email'] = new MailNotification();
		$this->contexts['chatbot'] = new BotNotification();
		$this->contexts['app'] = new PushNotification();

		$this->medium = $medium;
	}

	/**
	 * @param      $from
	 * @param      $to
	 * @param      $message
	 * @param      $n
	 * @param      $logger
	 * @param bool $dryRun
	 * @param null $chargeLibraryID
	 *
	 * @return mixed
	 */
	public function send($from, $to, $message, $n, $logger, $dryRun = false, $chargeLibraryID = null)
	{
		$medium = $this->medium;

		/** @throws NotificationNetworkErrorException */
		return $this->contexts[$medium]->send($from, $to, $message, $n, $logger, $dryRun, $chargeLibraryID);
	}
}