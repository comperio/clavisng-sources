<?php

/**
 *
 *
 * @author Ciro Mattia Gonano
 * @version 2.7
 * @package Console
 * @since 2.5.0
 */

require_once('ClavisCommandLineAction.php');

/**
 * @package Console
 * @since 2.5.0
 */
class ClavisActionImport extends ClavisCommandLineAction
{
	protected $action = 'import';
	protected $parameters = array('file');
	protected $optional = array();
	protected $description = 'Imports a TurboMarc collection from a file; if file is an URL tries to get the contents.';

	public function performAction($args)
	{
		$collection = simplexml_load_file($args[1]);
		if (!$collection) {
			echo "Cannot load XML!\n";
			return false;
		}
		try {
            //$pending = array();
		    foreach ($collection->r as $record) {
				$tm = TurboMarc::createRecord($record->asXML());
				unset($tm->d950);
				unset($tm->d951);
				$m = ManifestationPeer::createFromTurbomarc($tm);
				if ($m instanceof Manifestation)
					echo "\nNew Manifestation ID = ".$m->getManifestationId();
			    $m->clearAllReferences(true);
			    unset($m);
			}
            //echo "\nThe following links have NOT been imported: ";
//          foreach ($pending as $link)
//              echo "\n\t[{$link['link']}] => ({$link['bid_source']}:{$link['bid']}) {$link['title']}";
		} catch (Exception $e) {
			echo "Something went wrong :(\n$e";
			return false;
		}
		return true;
	}
}