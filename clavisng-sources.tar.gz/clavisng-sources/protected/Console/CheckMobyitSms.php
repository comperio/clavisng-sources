<?php
require_once 'protected/Console/ClavisCommandLineAction.php';

class ClavisActionCheckMobyitSms extends ClavisCommandLineAction
{
	/**
	 * @var string
	 */
	protected $action = 'check_mobyit_sms';
	/**
	 * @var array
	 */
	protected $parameters = array('-sender');
	/**
	 * @var array
	 */
	protected $optional = array('--dryrun');
	/**
	 * @var string
	 */
	protected $description = 'Check status of sms sended by Mobyit.';

	/** @var $logger Log */
	protected $logger;
	/**
	 * @var
	 */
	protected $dryrun;

	/**
	 * @param $args
	 *
	 * @return bool
	 */  
	public function performAction($args)
	{
		$params = $this->parseArgs($args);
		$this->dryrun = isset($params['dryrun']) ? true : false;
		$sender = isset($params['sender']) ? $params['sender'] : false;

		$logname = $this->dryrun ? 'DRYRUN-NOTIFY' : 'NOTIFY';
		$this->logger = Log::factory('console', '', $logname);
		$this->logger->info('Starting checking Mobyit sms status.');

		$smsmodule = Prado::getApplication()->getModule('sms');
		$smsmodule->checkAuth();

		$pendingNotifications = NotificationQuery::create()
			->filterByNotificationState('A')	// pending
			->filterByNotificationChannel('H')	// sms
			->find();

		foreach($pendingNotifications as $pendingNotification) {
			$this->logger->info("Working on pending notification {$pendingNotification->getNotificationId()}");
			$order_id = $sender.'_'.$pendingNotification->getNotificationId();
			$response = $smsmodule->checkMessageStatus($order_id);
			if ($response['status'] == 'KO') {
				$this->dryrun || $pendingNotification->setNotificationState('D')->save(); // error
				continue;
			}
			$status = $response['data'][0]->recipients[0]->status;
			$this->logger->debug("Set status");
			if (in_array($status, ['SENT', 'DLVRD'])) 
				$this->dryrun || $pendingNotification->setNotificationState('B')->save(); // sent
			else if (in_array($status, ['TOOM4USER', 'TOOM4NUM', 'ERROR', 'UNKNRCPT', 'UNKNPFX', 'INVALIDDST', 'KO', 'INVALIDCONTENTS']))
				$this->dryrun || $pendingNotification->setNotificationState('D')->save(); // error
			else if ($status == 'TIMEOUT')
				$this->dryrun || $pendingNotification->setNotificationState('F')->save(); // expired
		}

		$this->logger->info('Finishing checking Mobyit sms status.');

		return true;

	}

}
