<?php
/**
 * ClavisActionInitClavis class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Console
 */
require_once('ClavisCommandLineAction.php');

/**
 * ClavisActionInitClavis Class
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Console
 * @since 2.5.0
 */
class ClavisActionInitClavis extends ClavisCommandLineAction
{
	protected $action = 'init_clavis';
	protected $parameters = array();
	protected $optional = array('<additional SQL file>');
	protected $description = 'Init a Clavis installation with default values.';

	private $_outputParams = array();

	public function performAction($args)
	{
		$datadir = Prado::getPathOfNamespace('Application.Data');
		$conn = Propel::getConnection();
		$this->multiQuery($conn,file_get_contents($datadir.'/propel/sql/clavis2_schema.sql'));
		$this->multiQuery($conn,file_get_contents($datadir.'/initdb_default.sql'));
		$this->multiQuery($conn,file_get_contents($datadir.'/unimarc_codes/unimarc_codes.it.sql'));
		$this->multiQuery($conn,file_get_contents($datadir.'/unimarc_codes/unimarc_codes.en.sql'));
		$this->multiQuery($conn,file_get_contents($datadir.'/unimarc_labels/unimarc_labels.it.sql'));
		$this->multiQuery($conn,file_get_contents($datadir.'/unimarc_labels/unimarc_labels.en.sql'));
		$this->multiQuery($conn,file_get_contents($datadir.'/lookup_value/lookup_values.it.sql'));
		$this->multiQuery($conn,file_get_contents($datadir.'/lookup_value/lookup_values.en.sql'));
		$this->multiQuery($conn,file_get_contents($datadir.'/import_sources_default.sql'));

		if (isset($args[1]))
			$this->multiQuery($conn,file_get_contents($args[1]));

		echo "\n#### ALL DONE!!! ####\n";
		return true;
	}

	private function multiQuery($conn,$sql)
	{
		$queries = $this->parseSQL($sql);
		foreach ($queries as $query) {
			echo "\nQUERY: {$query}";
			$conn->exec($query);
		}
	}

	private function parseSQL($sql)
	{
		$delimiter = ';';

		$lines = explode("\n", $sql);
		$linecount = count($lines);
		$sql = '';
		for ($i = 0; $i < $linecount; $i++) {
			if (($i != ($linecount - 1)) || (strlen($lines[$i]) > 0)) {
				if (isset($lines[$i][0]) && $lines[$i][0] != "#") {
					$sql .= $lines[$i] . "\n";
				}
				else {
					$sql .= "\n";
				}
				// Trading a bit of speed for lower mem. use here.
				$lines[$i] = '';
			}
		}

		// Split up our string into "possible" SQL statements.
		$tokens = explode($delimiter, $sql);
		// try to save mem.
		$sql = '';
		$output = array();
		// we don't actually care about the matches preg gives us.
		$matches = array();
		// this is faster than calling count($oktens) every time thru the loop.
		$token_count = count($tokens);
		for ($i = 0; $i < $token_count; $i++) {
			// Don't wanna add an empty string as the last thing in the array.
			if (($i != ($token_count - 1)) || (strlen($tokens[$i] > 0))) {
				// This is the total number of single quotes in the token.
				$total_quotes = preg_match_all("/'/", $tokens[$i], $matches);
				// Counts single quotes that are preceded by an odd number of backslashes,
				// which means they're escaped quotes.
				$escaped_quotes = preg_match_all("/(?<!\\\\)(\\\\\\\\)*\\\\'/", $tokens[$i], $matches);

				$unescaped_quotes = $total_quotes - $escaped_quotes;

				// If the number of unescaped quotes is even, then the delimiter did NOT occur inside a string literal.
				if (($unescaped_quotes % 2) == 0) {
					// It's a complete sql statement.
					$output[] = $tokens[$i];
					// save memory.
					$tokens[$i] = "";
				}
				else {
					// incomplete sql statement. keep adding tokens until we have a complete one.
					// $temp will hold what we have so far.
					$temp = $tokens[$i] . $delimiter;
					// save memory..
					$tokens[$i] = "";

					// Do we have a complete statement yet?
					$complete_stmt = false;

					for ($j = $i + 1; (!$complete_stmt && ($j < $token_count)); $j++) {
						// This is the total number of single quotes in the token.
						$total_quotes = preg_match_all("/'/", $tokens[$j], $matches);
						// Counts single quotes that are preceded by an odd number of backslashes,
						// which means they're escaped quotes.
						$escaped_quotes = preg_match_all("/(?<!\\\\)(\\\\\\\\)*\\\\'/", $tokens[$j], $matches);

						$unescaped_quotes = $total_quotes - $escaped_quotes;

						if (($unescaped_quotes % 2) == 1) {
							// odd number of unescaped quotes. In combination with the previous incomplete
							// statement(s), we now have a complete statement. (2 odds always make an even)
							$output[] = $temp . $tokens[$j];

							// save memory.
							$tokens[$j] = "";
							$temp = "";

							// exit the loop.
							$complete_stmt = true;
							// make sure the outer loop continues at the right point.
							$i = $j;
						}
						else {
							// even number of unescaped quotes. We still don't have a complete statement.
							// (1 odd and 1 even always make an odd)
							$temp .= $tokens[$j] . $delimiter;
							// save memory.
							$tokens[$j] = "";
						}

					} // for..
				} // else
			}
		}
		return $output;
	}
}
