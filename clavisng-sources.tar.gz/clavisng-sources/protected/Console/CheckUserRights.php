<?php
/**
 * ClavisActionCheckUserRights class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Console
 */
require_once('ClavisCommandLineAction.php');

/**
 * ClavisActionCheckUserRights Class
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Console
 * @since 2.5.0
 */
class ClavisActionCheckUserRights extends ClavisCommandLineAction
{
	const AUTO_NOTIFY_NONE = 0;
	const AUTO_NOTIFY_EXPIRING = 1;
	const AUTO_NOTIFY_EXPIRED = 2;

	protected $action = 'check_user_rights';
	protected $parameters = array();
	protected $optional = array('graceperiod','gracesolicits');
	protected $description = 'Revoke loan rights for all late patrons, and re-enables after the revoke time has expired. Use optional parameter to specify the grace period in days (defaults to 7 days) and the grace solicits number (defaults to 0). Optionally check';

	protected $_expired_notify_count = 0;
	protected $_gracePeriod = 7;
	protected $_graceSolicits = 0;
	protected $_graceClasses = array();
	public $patrons_to_notify = array();

	public function performAction($args)
	{
		$send_notification_email = ClavisParamQuery::getParam('CLAVISPARAM','AutoEmailOnRevoke');
        $check_late_loans = ClavisParamQuery::getParam('CLAVISPARAM','AutoLateLoanCheck');
		$check_card_expire = ClavisParamQuery::getParam('CLAVISPARAM','AutoCardExpireCheck');
		$send_email_expiring = ClavisParamQuery::getParam('CLAVISPARAM','AutoEmailLoanExpiring');
		$send_email_expired = ClavisParamQuery::getParam('CLAVISPARAM','AutoEmailLoanExpired');

        Prado::log("Starting CheckUserRights",TLogger::INFO,"Batch");

        print("$send_notification_email $check_late_loans $check_card_expire $send_email_expiring $send_email_expired\n");

		if ('true' == $check_late_loans) {
			// let CLI specified params override preset ones.
			if (count($args) > 1)
				$this->_gracePeriod = intval($args[1]);
			if (count($args) > 2)
				$this->_graceSolicits = intval($args[2]);
			$this->checkLateLoans();
			if ('true' == $send_notification_email) {
				$this->sendNotificationEmail('revoke');
			}
		}

		if ('true' == $send_email_expiring) {
			$this->sendNotificationEmail('expiring');
		}

		if ('true' == $send_email_expired) {
			$this->sendNotificationEmail('expired');
		}

		if ('true' == $check_card_expire) {
			$this->checkCardExpire();
		}

        Prado::log("Finishing CheckUserRights",TLogger::INFO,"Batch");
		echo "\n#### ALL DONE!!! ####\n";
		return true;
	}

	protected function checkLateLoans()
	{
		$conn = Propel::getConnection();

		// retrieve settings from clavis_params
		if ($p = ClavisParamPeer::getParam('AUTOREVOKE_GRACE_DAYS', 0))
			$this->_gracePeriod = $p;
		if ($p = ClavisParamPeer::getParam('AUTOREVOKE_GRACE_SOLICITS', 0))
			$this->_graceSolicits = $p;
		$graceUserClasses = @unserialize(ClavisParamPeer::getParam('AUTOREVOKE_GRACE_USERCLASSES', 0));
		if (is_array($graceUserClasses))
			$this->_graceClasses = $graceUserClasses;

		echo "\n### Expiring late patrons ###";
        Prado::log("Expiring late patrons",TLogger::INFO,"Batch");

		$expireDate = new DateTime();
		$expireDate->sub(new DateInterval('P'.$this->_gracePeriod.'D'));
		if (method_exists('Clavis','getRevokeStmt')) {
			$stmt = Clavis::getRevokeStmt($expireDate->format('Y-m-d'), $this->_graceSolicits, $conn);
		} else {
			$stmt = $conn->prepare('SELECT patron_id, MIN(due_date) AS due_date, GROUP_CONCAT(current_loan_id) AS loan_ids
				FROM item
				WHERE due_date < ?
					AND loan_status = \'B\'
					AND notify_count >= ?
				GROUP BY patron_id');
			$stmt->execute(array($expireDate->format('Y-m-d'), $this->_graceSolicits));
		}
		$counter = 0;
		while ($p = $stmt->fetch(PDO::FETCH_ASSOC))
		{
			$patron = PatronQuery::create()->findOneByPatronId($p['patron_id']);
			if (!$patron instanceof Patron) {
				echo "\nWARNING: patron {$p['patron_id']} not found!!!";
                Prado::log("WARNING: patron {$p['patron_id']} not found!!!",TLogger::WARNING,"Batch");
				continue;
			}
			if (in_array($patron->getLoanClass(), $this->_graceClasses)) {
				echo "\nWARNING: patron {$p['patron_id']} is in grace class {$patron->getLoanClass()} - not revoking.";
                Prado::log("WARNING: patron {$p['patron_id']} is in grace class {$patron->getLoanClass()} - not revoking.",TLogger::WARNING,"Batch");
				continue;
			}
			$oldNote = $patron->getAccessNote();
			$until_dt = new DateTime('now');
			$duedate_dt = new DateTime($p['due_date']);
			$diff = date_diff(new DateTime('now'), $duedate_dt, true);
			if (method_exists('Clavis','getRevokeInterval')) {
				$interval = Clavis::getRevokeInterval($p, $diff);
			} else {
				$interval = $diff;
			}
			// if not a DateInterval or DI is 0, do not revoke
			if (!$interval instanceof DateInterval ||
					Clavis::DateInterval2Seconds($interval) <= Clavis::DateInterval2Seconds(new DateInterval('P0D')))
				continue;
			$until_dt->add($interval);
			$due_date = Clavis::dateFormat($p['due_date']);
			$until = Clavis::dateFormat($until_dt);
			if ($patron->getPatronStatus() == PatronPeer::STATUS_AUTOMATICREVOKED) {
				$patron->setCustom2($until_dt->format('Y-m-d'));
				if (preg_match('!Sospeso fino al [^\s]+ perché in ritardo di [-\d]+ giorni \[dal [^\s]+\s?\]!',$oldNote)>0)
					$newNote = preg_replace('!Sospeso fino al [^\s]+ perché in ritardo di [-\d]+ giorni \[dal [^\s]+\s?\]!',
						"Sospeso fino al {$until} perché in ritardo di {$diff->format('%a')} giorni [dal {$due_date}]",
						$oldNote);
				else
					$newNote = "Sospeso fino al {$until} perché in ritardo di {$diff->format('%a')} giorni [dal {$due_date}] ".$oldNote;
				$patron->setAccessNote($newNote);
				$patron->save();
                Prado::log("Patron [{$patron->getPatronId()}] [{$patron->getCustom2()}] {$patron->getName()} revoked.",TLogger::INFO,"Batch");
                echo "\nPatron [{$patron->getPatronId()}] [{$patron->getCustom2()}] {$patron->getName()} revoked.";
			} else {
				$patron->setPatronStatus(PatronPeer::STATUS_AUTOMATICREVOKED); // Revoca Automatica
				$patron->setCustom2($until_dt->format('Y-m-d'));
				$newNote = "Sospeso fino al {$until} perché in ritardo di {$diff->format('%a')} giorni [dal {$due_date}] ".$oldNote;
				$patron->setAccessNote($newNote);
				$patron->save();
				$this->patrons_to_notify[] = $patron;
				ChangelogPeer::logAction($patron, ChangelogPeer::LOG_WARNING, null, 'Utente bloccato per ritardi, per esemplare con data di rientro: ' . $due_date);
                Prado::log("New Patron [{$patron->getPatronId()}] [{$patron->getCustom2()}] {$patron->getName()} revoked.",TLogger::INFO,"Batch");
                echo "\nNew Patron [{$patron->getPatronId()}] [{$patron->getCustom2()}] {$patron->getName()} revoked.";
			}



			$counter++;
		}

        Prado::log("### Re-enabling patrons ###",TLogger::INFO,"Batch");
		echo "\n### Re-enabling patrons ###";
		$patronlist = PatronQuery::create()
			->setFormatter(ModelCriteria::FORMAT_ON_DEMAND)
			->filterByCustom2(date('Y-m-d'),Criteria::LESS_THAN)
			->filterByPatronStatus(PatronPeer::STATUS_AUTOMATICREVOKED)
			->find();
		foreach ($patronlist as $patron) {
            /* @var $patron Patron */
			$patron->setPatronStatus(PatronPeer::STATUS_ENABLED);
			$newNote = preg_replace('!Sospeso fino al .+ in ritardo di .+ giorni.+dal.+\]\s?!','',$patron->getAccessNote());
			$patron->setAccessNote($newNote);
			$patron->setCustom2('');
			$patron->save();
			ChangelogPeer::logAction($patron, ChangelogPeer::LOG_WARNING, null, 'Utente riabilitato');
			echo "\nPatron [{$patron->getPatronId()}] [{$patron->getCustom2()}] {$patron->getName()} re-enabled.";
            Prado::log("Patron [{$patron->getPatronId()}] [{$patron->getCustom2()}] {$patron->getName()} re-enabled.",TLogger::INFO,"Batch");
		}
	}

	protected function checkCardExpire()
	{
		echo "\n### Expiring patron cards ###";
        Prado::log("Expiring patrona cards",TLogger::INFO,"Batch");

		$patronlist = PatronQuery::create()
            ->filterByPatronStatus(PatronPeer::STATUS_ENABLED)
			->filterByCardExpire(time(),Criteria::LESS_THAN)
            ->find();

        $expired = 0;
        foreach ($patronlist as $patron) {
            /* @var $patron Patron */
            $patron->setPatronStatus(PatronPeer::STATUS_EXPIRED);
            $patron->save();
            ChangelogPeer::logAction($patron, ChangelogPeer::LOG_WARNING, null, 'Utente con diritti scaduti');
            $expired++;
        }

		echo "\nExpired {$expired} patron cards.";
        Prado::log("Expired {$expired} patron cards.",TLogger::INFO,"Batch");
	}

        
        /*
         * Send an e-mail for loan in [revoke|expiring|expired]
         * Modified by Cristian Chiarello on 15/7/14
         * Change notify_auto_count logic, 0 never notify, 1 expiring notify, 2 expired notify
         * and notify_count when send for expired
         */
        
	protected function sendNotificationEmail($mode='revoke')
	{
        Prado::log("Start Notification email [$mode]",TLogger::INFO,"Batch");
		$conn = Propel::getConnection();
		switch ($mode) {

			case 'revoke':
				$sql = 'SELECT to_library, GROUP_CONCAT(loan_id) AS loan_ids
					FROM loan
					WHERE patron_id = ?
						AND loan_status = \''.ItemPeer::LOANSTATUS_INLOAN.'\'
						AND due_date < CURDATE()
					GROUP BY to_library';
				$description = 'Automatic revoke email';
				$solicit_mode = 'revoke';
				$update_notify_count = self::AUTO_NOTIFY_NONE;
				break;

			case 'expiring':

				$from_date = date('Y-m-d');

				$sql = "SELECT to_library, GROUP_CONCAT(loan_id) AS loan_ids
					FROM loan
					JOIN patron ON patron.patron_id = loan.patron_id
					WHERE loan.patron_id = ?
						AND loan_status = '".ItemPeer::LOANSTATUS_INLOAN."'
						AND due_date >= '{$from_date}'
						AND due_date <= from_unixtime(unix_timestamp() + (SELECT CAST(param_value AS UNSIGNED) FROM clavis_param WHERE param_class = concat('ALERTDAYS_',patron.loan_class) AND param_name = (item_media)))
						AND notify_auto_count = 0

					GROUP BY to_library";
				$this->patrons_to_notify = PatronQuery::create()
					->where("patron_id IN (
					SELECT distinct l.patron_id
					FROM loan l
					JOIN patron p ON p.patron_id = l.patron_id
					WHERE l.loan_status = 'B'
						AND l.due_date >= '{$from_date}'
						AND l.due_date <= from_unixtime(unix_timestamp() + (SELECT CAST(c.param_value AS UNSIGNED) FROM clavis_param c WHERE c.param_class = concat('ALERTDAYS_',p.loan_class) AND c.param_name = (l.item_media)))
						AND l.notify_auto_count = 0
					)")
					->find();
                                
				$description = 'Automatic warning email for expiring loans';
				$solicit_mode = 'expiring';
				$update_notify_count = self::AUTO_NOTIFY_EXPIRING;
				break;

			case 'expired':
				$date = date('Y-m-d');
				$sql = "SELECT to_library, GROUP_CONCAT(loan_id) AS loan_ids
					FROM loan
					WHERE patron_id = ?
						AND due_date < '{$date}'
						AND loan_status = '".ItemPeer::LOANSTATUS_INLOAN."'
						AND notify_auto_count < 2 AND notify_count = 0
					GROUP BY to_library";
				$this->patrons_to_notify = PatronQuery::create()
					->useLoanQuery()
						->filterByLoanStatus(ItemPeer::LOANSTATUS_INLOAN)
						->filterByDueDate($date,Criteria::LESS_EQUAL)
						->filterByNotifyAutoCount(self::AUTO_NOTIFY_EXPIRED, Criteria::LESS_THAN)
					->endUse()
					->distinct()
					->find();
				$description = 'Automatic solicit email for expired loans';
				$solicit_mode = 'solicit';
				$update_notify_count = self::AUTO_NOTIFY_EXPIRED;
				break;

			default:
				echo "\nUnknown mode, exiting...";
				return;
		}

		$stmt = $conn->prepare($sql);

		$librarian = LibrarianQuery::create()->findPk(1);
		foreach ($this->patrons_to_notify as $p)
		{
			$loans_to_update = array();
			// can't send email if user has no mail
			if (!$p->getEmail())
				continue;

			$stmt->execute(array($p->getPatronId()));
			while ($loan_by_lib = $stmt->fetch(PDO::FETCH_ASSOC))
			{
				$library = LibraryQuery::create()->findPk($loan_by_lib['to_library']);

				if($library  == null)
					$library = LibraryQuery::create()->filterByLibraryInternal(1)->filterByLibraryStatus(LibraryPeer::STATUS_ACTIVE)->findOne();

				$ret = NotificationHelper::sendNotificationEmail($solicit_mode, $p, $librarian, $library, explode(',',$loan_by_lib['loan_ids']));

                Prado::log("Send notification email to " . join('-',$p->getEmail()) ." Result:". Prado::varDump($ret),TLogger::INFO,"Batch");

				if ($ret)
					$loans_to_update = array_merge($loans_to_update, explode(',',$loan_by_lib['loan_ids']));
			}
			if ($loans_to_update && $update_notify_count !== self::AUTO_NOTIFY_NONE) {
                            
                                LoanQuery::create()
                                        ->filterByLoanId($loans_to_update)
                                        ->update(array('NotifyAutoCount' => $update_notify_count), null, true);

                                if($update_notify_count === self::AUTO_NOTIFY_EXPIRED) //update only if expired
                                {
                                   
                                    
                                   foreach (LoanQuery::create()
                                        ->findByLoanId($loans_to_update) as $loan)
                                   {
                                       $loan->setNotifyCount($loan->getNotifyCount() + 1);
                                       $loan->save();
                                       $item = $loan->getItem();
                                       $item->setNotifyCount($loan->getNotifyCount());
                                       $item->save();
                                   }

                                }
			}
		}
		return true;
	}
}