<?php

/**
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Console
 * @since 2.5.0
 */

require_once('ClavisCommandLineAction.php');

/**
 * @package Console
 * @since 2.5.0
 */
class ClavisActionI18n extends ClavisCommandLineAction
{
	protected $action = 'i18n';
	protected $parameters = array('language');
	protected $optional = array();
	protected $description = "Parses the whole project searching localization calls and generating a .pot template.\n=== NOT YET FUNCTIONAL! ===";

	public $source_dir = './protected';
	public $target_language = 'en_US';
	private $scanned_files = array();

	public function performAction($args)
	{
		Prado::using('System.I18N.Translation');

		$this->target_language = (!$args[1]) ? 'en_US' : $args[1];

		if (!is_dir($this->source_dir)) {
			echo 'Source directory is not valid!';
			exit(1);
		}
		//Searching for PHP or PAGE files
		$this->files_scan($this->source_dir);

		//Search for localization tags and functions in files
		$strings = array();
		foreach ($this->scanned_files AS $file) {
			preg_match_all('/\<\%\[(.+?)\]\%\>/isS', file_get_contents($file), $matches);
			if (sizeof($matches[1]) > 0)
				$strings = array_merge($strings, $matches[1]);

			preg_match_all('/<com:TTranslate (?:.+?)">\s*(.+?)\s*<\/com:TTranslate>/isS', file_get_contents($file), $matches);
			if (sizeof($matches[1]) > 0)
				$strings = array_merge($strings, $matches[1]);

			preg_match_all('/::localize\((.+?)(?:,\s*array\(|\))/isS', file_get_contents($file), $matches);
			foreach($matches[1] as $string) {
				// mangle string for extracting final one.
				if (strpos($string,'$') !== false) {
					echo "\nFound '$' in string [{$string}], variable warning, leaving untranslated.";
					continue;
				}
				$string = trim($string);
				if (in_array($string[0],array('"','\'')))
					$string = substr($string,1);
				if (in_array(substr($string,-1),array('"','\'')))
					$string = substr($string,0,-1);
				$string = preg_replace('!(["\'])\s*\.\s*[\'"]!isS','',$string);
				$string = str_replace('\\\'','\'',$string);
				$string = str_replace('\\"','"',$string);
				if ($string)
					$strings[] = $string;
			}
		}
		foreach ($strings AS &$string) {
			$string = trim($string);
		}
		unset($this->scanned_files);
		$strings = array_values(array_unique($strings));

		$app = Prado::getApplication()->getGlobalization();
		$config = $app->getTranslationConfiguration();
		$source = MessageSource::factory($config['type'],$config['source'],$config['filename']);
		$source->setCulture($this->target_language);
		$messages = $source->load('messages') ? $source->read() : array();
		foreach($strings as $string) {
			foreach($messages as $variant)
				if (!array_key_exists($string,$variant))
					$source->append($string);
		}
		$source->save('messages');

		echo "\n------------------------------------------------------------------------------------------------\n";
		echo "\nDone.\n";
		echo "\n------------------------------------------------------------------------------------------------\n";
		echo "\n#### ALL DONE!!! ####\n";
		return true;
	}

	private function files_scan($dir)
	{
		$files = scandir($dir);
		foreach ($files AS $file) {
			if (is_dir($dir.'/'.$file) && $file[0] != '.')
				$this->files_scan($dir . '/' . $file);
			else if (is_file($dir . '/' . $file) && is_readable($dir . '/' . $file) && (strstr($file, '.tpl') || strstr($file, '.php') || strstr($file, '.page'))) {
				$this->scanned_files[] = $dir . '/' . $file;
			}
		}
	}
}
