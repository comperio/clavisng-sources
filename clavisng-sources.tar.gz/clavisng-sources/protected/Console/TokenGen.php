<?php

/**
 *
 *
 * @author Ciro Mattia Gonano
 * @version 2.7
 * @package Console
 * @since 2.5.0
 */

require_once('ClavisCommandLineAction.php');

/**
 * @package Console
 * @since 2.5.0
 */
class ClavisActionTokenGen extends ClavisCommandLineAction
{
	protected $action = 'tokengen';
	protected $parameters = array("librarian");
	protected $optional = array();
	protected $description = 'Token generation';

	public function performAction($args)
	{

        $librarianUserName = $args[1];
        $librarian = LibrarianQuery::create()->findOneByUsername($librarianUserName);
        if($librarian instanceof Librarian) {
            $token = md5(uniqid());
            print "Token {$token}\n";
            $secret = password_hash($token,PASSWORD_BCRYPT);

            $librarian->setSecret("tok:{$secret}");
            $librarian->save();
        } else {
            print "Librarian {$librarianUserName} sconosciuto\n";
        }
		return true;
	}


}