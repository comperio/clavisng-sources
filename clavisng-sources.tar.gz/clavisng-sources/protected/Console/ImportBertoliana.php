<?php

/**
 *
 * @author Dario Rigolin <dario@comperio.it>
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Console
 * @since 2.5.0
 */

require_once('ClavisCommandLineAction.php');

/**
 * @package Console
 * @since 2.5.0
 */
class ClavisActionImportBertoliana extends ClavisCommandLineAction
{
	protected $action = 'import_bertoliana';
	protected $parameters = array('sebina|sol|unimarc_file');
	protected $optional = array('catalog_number');
	protected $description = "";

	protected $remoteUrl = "http://www.bibliotechevicentine.it/";
	protected $remotePathSebina = "/download/Aggio%20Sebina/";
	protected $remotePathSol = "/download/Aggio%20Sbn/";

	private $_library = array();
	private $_defaultSourceId = 'CSB';
	private $_toIndex;
	private $_authLinkFields = array(
		'500',	// link to work
		'600','601','602','603','604','605','606','607','608','609','610','699',	// link to subjects/term
		'616',	// printers device as subject
		'620',	// place
		'676', '680', '686',	// class
		'700', '701', '702',	// personalname
		'710', '711', '712',	// corporatebodyname
		'716',	// printersdevice
		'720', '721', '722',	// familyname
		'792', '793',
		'921',	// printersdevice
		'931',	// subject-term
	);

	const STOPFILE = 'do_not_index';
	const LOCKFILE = 'index.lock';
	const RETRY = 10;

	public function performAction($args)
	{
		$trial_no = 0;
		do {
			if (++$trial_no > self::RETRY) {
				echo "\nCould not lock index, exiting...\n";
				return true;
			}
			echo "\nTrying to acquire lock [{$trial_no}]...";
			$tmpdir = Prado::getPathOfNamespace('Storage.temp');
			// lock index file in order to prevent conflicts.
			if (file_exists($tmpdir.'/'.self::STOPFILE)) {
				echo "stopfile exists, trying again in 30 secs!";
				continue;
			}
			$lockfp = fopen($tmpdir.'/'.self::LOCKFILE, 'w');
			if (!flock($lockfp, LOCK_EX | LOCK_NB)) {
				echo "index is locked, trying again in 30 secs!";
				continue;
			}
			break;
		} while (sleep(30) == 0);

		switch ($args[1]) {
			case 'sebina':
			case 'zeta':
			case 'sol':
				$uniFile = $this->getDump($args[1]);
				if (!$uniFile) {
					// release lock
					flock($lockfp, LOCK_UN);
					fclose($lockfp);
					echo "\n------------------------------------------------------------------------------------------------\n";
					echo "\nTHERE AIN'T NO NEW DUMPS!!\n";
					echo "\n------------------------------------------------------------------------------------------------\n";
					echo "\n#### ALL DONE!!! ####\n";
					return true;
				}
				break;
			default:
				$uniFile = $args[1];
				break;
		}
		$fp = @fopen($uniFile,'r');
		if(!$fp) {
			echo "\nCannot open $uniFile - exiting now!\n";
			return false;
		}

		// if argument exist get catalog number from it, else try to guess from filename.
		$catalog_num = (isset($args[2])) ? $args[2] : array_shift(explode('_',basename($uniFile)));
		if (strpos($catalog_num,'/') === false)
			$catalog_num = date('Y').'/'.$catalog_num;

		// init libraries array
		foreach (LibraryQuery::create()->find() as $lib)
			$this->_library[$lib->getLibraryCode()] = $lib;

		$ItemShelves = array();
		$manShelf = null;

		/* @var $search SolrSearch */
		$search = Prado::getApplication()->getModule('search');

		// for sol, do not import intermediate
		if (!in_array('sol',$args)) {
			while (($tm = $this->getNextRecord($fp)) !== false)
			{
				// skip deleted records
				if ('d' == $tm->getLeader()->recstatus)
					continue;

				if (in_array($tm->getLeader()->hiercode,array(ManifestationPeer::HIER_TOP)))
				{
					$bid = (string)$tm->c001;
					$sourceId = (array_key_exists('d801', $tm)) ?
						$tm->d801->sb : $this->_defaultSourceId;
					$mup = ManifestationPeer::getOneByBid($sourceId,$bid);
					if ($mup instanceof Manifestation) {
						echo "\nIntermediate manifestation [{$bid}] FOUND!";
						$mup->invalidateCache();
					} else {
						echo "\nIntermediate manifestation [{$bid}] NOT FOUND! Importing...";
						$tm->addField('035');
						$tm->d035->addSubField('a',$bid);
						$tm->d035->addSubField('9',$sourceId);
						unset($tm->d950);
						unset($tm->d951);
						ManifestationPeer::createFromTurbomarc($tm);
					}
				}
			}
			rewind($fp);
		}

		$counter = 0;
		while (($tm = $this->getNextRecord($fp)) !== false)
		{
			// skip deleted records.
			if ('d' == $tm->getLeader()->recstatus)
				continue;

			++$counter;
			$bid = (string)$tm->c001;
			$sourceId = (array_key_exists('d801', $tm)) ?
				(string)$tm->d801->sb : $this->_defaultSourceId;

			echo "\nRecord {$bid} [{$counter}] --- Titolo: ".(string)$tm->d200->sa;

			$man = ManifestationPeer::getOneByBid($sourceId,$bid);
			if ($man instanceof Manifestation)
				' --- manifestation FOUND!';

			list($localtm,$extratm) = $this->fixItems($tm,$args[1]);

			// for sol, do not process local items
			if (!in_array('sol',$args)) {
				if (count($localtm->d950) > 0)	// internal items
				{
					if ($manShelf == null) {
						echo "\nCreating import shelf...";
						$manShelf = new Shelf();
						$manShelf->setShelfName("Nuove notizie scarico {$catalog_num}");
						$manShelf->setShelfDescription("Notizie importate dallo scarico {$catalog_num} del centro di catalogazione SBPVI");
						$manShelf->setShelfItemtype(ShelfPeer::TYPE_MANIFESTATION);
						$manShelf->setShelfStatus(ShelfPeer::VISIBILITY_ALLREADONLY);
						$manShelf->setLibrarianId(1);
						$manShelf->setLibraryId(176);	// FIXME parametrize
						$manShelf->save();
					}

					if (!$man instanceof Manifestation)
					{
						echo "\nCreating manifestation...";
						$mantm = clone $localtm;
						$mantm->addField('035');
						$mantm->d035->addSubField('a',$bid);
						$mantm->d035->addSubField('9',$sourceId);
						unset($mantm->d950);
						unset($mantm->d951);
						for ($i=400; $i<500; ++$i) {
							$xmlTag = "d{$i}";
							foreach ($mantm->$xmlTag as $linkFld) {
								if (isset($linkFld->s3)) {
									$linkFld->addSubField(strtolower($sourceId), (string)$linkFld->s3);
								}
							}
						}
						foreach ($this->_authLinkFields as $i) {
							$xmlTag = "d{$i}";
							foreach ($mantm->$xmlTag as $linkFld) {
								if (isset($linkFld->s3)) {
									$linkFld->addSubField(strtolower($sourceId), (string)$linkFld->s3);
								}
							}
						}
						$man = ManifestationPeer::createFromTurbomarc($mantm);
						if (ManifestationPeer::HIER_LOWER != $man->getHierarchicalLevel())
							$man->setManifestationStatus(ManifestationPeer::STATUS_WORKING);

						echo "adding to shelf...";
						$shItem = new ShelfItem();
						$shItem->setShelf($manShelf);
						$shItem->setObjectId($man->getManifestationId());
						$shItem->setObjectClass('manifestation');
						try {
							$shItem->save();
							$shItem->clearAllReferences(true);
						} catch(Exception $e) {
							echo "ERROR adding manifestation to shelf!!!";
						}
					}

					echo "\n\n*** Creating items ***";

					foreach($localtm->d950 as $item)
					{
						$library = (string)$item->sa;
						if(!array_key_exists($library, $ItemShelves))
						{
							echo "\nCreating shelf for items - library {$item->sy}";
							$itemShelf = new Shelf();
							$itemShelf->setShelfName("Nuovi esemplari scarico {$catalog_num}");
							$itemShelf->setShelfDescription("Esemplari importati dallo scarico {$catalog_num} del centro di catalogazione SBPVI");
							$itemShelf->setShelfItemtype(ShelfPeer::TYPE_ITEM);
							$itemShelf->setShelfStatus(ShelfPeer::VISIBILITY_LIBRARYOPS);
							$itemShelf->setLibraryId($library);
							$itemShelf->setLibrarianId(1);
							$itemShelf->save();
							$ItemShelves[$library] = $itemShelf;
						}
						echo "\nCreating item...";
						$newItem = new Item();
						$newItem->setItemStatus(ItemStatus::ITEMSTATUS_ONSHELF);
						$newItem->setItemMedia(self::BibtypeToItemmedia($man->getBibType()));
						$newItem->setLoanStatus(ItemPeer::LOANSTATUS_AVAILABLE);
						$newItem->setLoanClass(ItemPeer::LOANCLASS_AVAILABLE);
						$newItem->setUsageCount(0);
						$newItem->setOpacVisible(true);
						$newItem->setManifestation($man);
						$newItem->setOwnerLibraryId((string)$item->so);
						$newItem->setHomeLibraryId((string)$item->sa);
						$newItem->setActualLibraryId((string)$item->sn);
						$newItem->setInventorySerieId((string)$item->sb);
						$newItem->setInventoryNumber((string)$item->sc);
						$newItem->setInventoryDate(time());
						$newItem->setCollocation((string)$item->sf);
						$newItem->setTitle($man->getTitle());
						$newItem->save();

						$shItem = new ShelfItem();
						$shItem->setShelf($ItemShelves[$library]);
						$shItem->setObjectId($newItem->getItemId());
						$shItem->setObjectClass('item');
						$shItem->save();
						ShelfPeer::checkShelfItemTypes($ItemShelves[$library], true);

						$newItem->clearAllReferences(true);
						$shItem->clearAllReferences(true);
					}
					ShelfPeer::checkShelfItemTypes($manShelf, true);
				}
			}

			if (count($extratm->d950) > 0)	// external items
				$search->indexExtra(array((string)$extratm->c001 => $extratm->asXML()),false);

			if ($man instanceof Manifestation)
				$man->invalidateCache();
		}
		fclose($fp);

		if (!file_exists($args[1])) {
			// if file does not exist, we're in automatization mode, so delete temp one and update param
			$p = ClavisParamQuery::create()
				->filterByParamClass('BIR_IMPORT')
				->filterByParamName($args[1])
				->findOneOrCreate();
			$p->setParamValue(basename($uniFile,'.uni'));
			$p->save();
			unlink($uniFile);

		}

		// release lock
		flock($lockfp, LOCK_UN);
		fclose($lockfp);

		echo "\n------------------------------------------------------------------------------------------------\n";
		echo "\nDone. Please note that newly created manifestation have not been indexed yet.\n";
		echo "\nYou'll need either to manually launch 'index' action or leave it to the scheduled index updater.\n";
		echo "\n------------------------------------------------------------------------------------------------\n";
		echo "\n#### ALL DONE!!! ####\n";
		return true;
	}

	private function getNextRecord($handle)
	{
		$record = stream_get_line($handle,999999,TurboMarc::UNIMARC_RECORDEND);
		$record = trim(str_replace(array("\n","\r"), ' ', $record));
		if (!$record)
			return false;
		$tm = TurboMarc::createRecord();
		$tm->parseRecord($record,true,false);
		$tm = TurboMarcUtility::sanitize($tm);
		$tm = TurbomarcConversion::Bertoliana($tm);
		$tm = TurbomarcConversion::embed2inline($tm);
		return $tm;
	}
	
	private function fixItems(TurboMarc $tm,$source='sebina')
	{
		$localtm = clone $tm;
		$extratm = clone $tm;

		unset($localtm->d950);
		unset($extratm->d950);

		foreach ($tm->d950 as $src950) {
			for($j=0; $j < count($src950->sd); $j++) {
				$fd = $src950->sd[$j];
				$fe = $src950->se[$j];

				$bibCode = substr($fd,0,2);
				$section = trim(substr($fd,2,10));

				switch ($bibCode) {
					case 'SB':
						$code = sprintf("%s-%s",$bibCode,trim($section));
						break;
					case 'MA':
					case 'BE':
					case 'BA':
						$code = $bibCode;
						break;
					default:
						$code = sprintf("%03d-%3s",$bibCode,$section);
				}

				if (array_key_exists($code, $this->_library))
				{
					// convert Bertoliana 950 mapping to our mapping.
					$libId = $this->_library[$code]->getLibraryId();
					$name = $this->_library[$code]->getLabel();
					$internal = $this->_library[$code]->getLibraryInternal();
					
					$collocation = trim(substr($fd,12,24));
					$specification = trim(substr($fd,36,12));
					$serie  = sprintf("%03s0",$bibCode);
					$inventory = intval(substr($fe,5,9));

					echo "\n --> Library [{$code}: {$name}] FOUND: ".($internal ? 'INT' : 'EXT');

					$item = ItemQuery::create()
						->filterByOwnerLibraryId($libId)
						->filterByInventorySerieId($serie)
						->filterByInventoryNumber($inventory)
						->findOne();

					if ($item instanceof  Item) {
						echo "..item found!";
					} else {
						echo "..item not found: creating...";
						/* @var $f950 TurboMarc */
						$f950 = $internal ? $localtm->addField('950') : $extratm->addField('950');
						$f950->addSubField('a',$libId);
						$f950->addSubField('b',$serie);
						$f950->addSubField('c',intval($inventory));
						$f950->addSubField('f',preg_replace('/\s\s+/', ' ', "$section $collocation $specification"));
						$f950->addSubField('j',ItemStatus::ITEMSTATUS_ONSHELF);
						$f950->addSubField('k',1);
						$f950->addSubField('n',$libId);
						$f950->addSubField('o',$libId);
						$f950->addSubField('p',ItemPeer::LOANCLASS_AVAILABLE);
						$f950->addSubField('s','');
						$f950->addSubField('t',date('Y-m-d H:i:s'));
						$f950->addSubField('y',$name);
					}
				} else {
					echo "\nLibrary [{$code}] unknown!!";
				}
			}
		}
		return array($localtm,$extratm);
	}

	private function getDump($source)
	{
		switch ($source) {
			case 'sol':
				$remoteUrl = $this->remoteUrl;
				$remotePath = $this->remotePathSol;
				break;
			case 'sebina':
				$remoteUrl = $this->remoteUrl;
				$remotePath = $this->remotePathSebina;
				break;
		}
		// get last import from Clavis params
		$lastImport = ClavisParamPeer::getParam('BIR_IMPORT',$source);
		$tmpdir = Prado::getPathOfNamespace('Storage.temp');
		echo "\nChecking remote files...";
		$path = $remotePath.date('Y').'/';
		$filelist = file_get_contents($remoteUrl.$path);
		$pattern = "!<A HREF=\"({$path}[\w\d]+.zip)\">!";
		preg_match_all($pattern,$filelist,$matches);
		if (!count($matches)) {
			// no files returned, try with previous year
			$path = $remotePath.(date('Y')-1).'/';
			$filelist = file_get_contents($remoteUrl.$path);
			$pattern = "!<A HREF=\"({$path}[\w\d]+.zip)\">!";
			preg_match_all($pattern,$filelist,$matches);
			if (!count($matches))	// desist
				return false;
		}
		echo "remote files found!\nGetting last import...";
		$lastfile = '';
		if ($lastImport) {
			$cnt = count($matches[1]);
			for ($i=0; $i<$cnt; ++$i) {
				if (basename($matches[1][$i],'.zip') == $lastImport && isset($matches[1][$i+1])) {
					$lastfile = $remoteUrl.$matches[1][$i+1];
					break;
				}
			}
		} else {
			$lastfile = $remoteUrl.array_pop($matches[1]);
		}
		if (!$lastfile)
			return false;
		$zipname = basename($lastfile);
		echo "last dump is [$zipname]\nDownloading...";
		copy($lastfile,$tmpdir.'/'.$zipname);
		echo 'unzipping...';
		$zip = new ZipArchive;
		$res = $zip->open($tmpdir.'/'.$zipname);
		if (true === $res) {
			$zip->extractTo($tmpdir.'/');
			$zip->close();
			unlink($tmpdir.'/'.$zipname);
		} else {
			echo 'failed, code:' . $res;
		}
		// register as last import
		echo "got file!\nImporting as usual...\n";
		return $tmpdir.'/'.basename($lastfile,'.zip').'.uni';
	}

	public static final function BibtypeToItemmedia($bibtype) {
		$map = array(	'a01' => 'F',
						 'a02' => 'F',
						 'c01' => 'H',
						 'e01' => 'D',
						 'b01' => 'M',
						 'b02' => 'M',
						 'd01' => 'H',
						 'f01' => 'D',
						 'g01' => 'P',
						 'g02' => 'R',
						 'g03' => 'Q',
						 'g04' => 'P',
						 'g05' => 'M',
						 'g06' => 'P',
						 'g07' => 'Q',
						 'g08' => 'E',
						 'j01' => 'A',
						 'j02' => 'A',
						 'j03' => 'A',
						 'j04' => 'A',
						 'j05' => 'A',
						 'j06' => 'A',
						 'j07' => 'A',
						 'i01' => 'F',
						 'i02' => 'F',
						 'i03' => 'F',
						 'i04' => 'F',
						 'i05' => 'F',
						 'i06' => 'F',
						 'i07' => 'F',
						 'k01' => 'C',
						 'k02' => 'C',
						 'k03' => 'C',
						 'k04' => 'C',
						 'k05' => 'C',
						 'k06' => 'C',
						 'k07' => 'C',
						 'k08' => 'C',
						 'k09' => 'C',
						 'k10' => 'C',
						 'k11' => 'C',
						 'l01' => 'N',
						 'l02' => 'N',
						 'r01' => 'I',
						 'r02' => 'I',
						 'r03' => 'I',
						 'r04' => 'I',
						 'r05' => 'I',
						 'r06' => 'I',
						 'r07' => 'I',
						 'r08' => 'I',
						 'r09' => 'I',
						 'r10' => 'I',
						 'r11' => 'I',
						 'r12' => 'I',
						 'r13' => 'I',
						 'r14' => 'I',
						 'r15' => 'I',
						 'r16' => 'I',
						 'r17' => 'I',
						 'r18' => 'I',
						 'r19' => 'I',
						 'r20' => 'I',
						 'r21' => 'I',
						 'r22' => 'I',
						 'r23' => 'I',
						 'r24' => 'I',
						 'r25' => 'I',
						 'r26' => 'I',
						 'r27' => 'I',
						 'r28' => 'I',
						 'r29' => 'I',
						 'r30' => 'I',
						 'r31' => 'I',
						 'r32' => 'I',
						 'r33' => 'I',
						 'r34' => 'I',
						 'm01' => 'G' );

		return (array_key_exists($bibtype,$map))
			? $map[$bibtype]
			: null;
	}
}
