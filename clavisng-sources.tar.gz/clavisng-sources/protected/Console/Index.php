<?php
/**
 * ClavisActionIndex class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Console
 */
require_once('ClavisCommandLineAction.php');

/**
 * ClavisActionIndex Class
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Console
 * @since 2.5.0
 */
class ClavisActionIndex extends ClavisCommandLineAction
{
	protected $action = 'index';
	protected $parameters = array();
	protected $optional = array('update | all | prune | manifestation | authority | <manifestation_id> | a<authority_id> | s<shelfId> | d<date>','debug | noclean');
	protected $description = 'Batch index all manifestations and authorities in db. Use optional argument to specify the index subject: [update] will search&cache all dirty or not-yet-cached manifestations, then index them (default), [manifestation] [authority] and [all] will clean the whole index and reindex all manifestations, authorities or both, respectively; [<manifestation id>] will index a single manifestation, [a<authority_id>] will index a single authority, [s<shelfId>] to take all manifestations contained in a shelf, [d<date>] to index all manifestations updated after a certain date. As second optional argument, you can specify [debug] to write indexing doc to /tmp/solrDoc.xml instead of sending it to Solr server, or [noclean] to avoid cleaning index if you specify [all] as first argument.';

	private $_outputParams = array();

	const STOPFILE = 'do_not_index';
	const LOCKFILE = 'index.lock';
//	const SLICE_COUNT = 16384;
	const SLICE_COUNT = 2048;

	public function performAction($args)
	{
		$tmpdir = Prado::getPathOfNamespace('Storage.temp');
		if (file_exists($tmpdir.'/'.self::STOPFILE)) {
			echo "\nWon't index as you command, my king!\n";
			return true;
		}
		echo "Acquiring index lock...";
		$fp = fopen($tmpdir.'/'.self::LOCKFILE, 'w');
		if (!flock($fp, LOCK_EX | LOCK_NB)) {
			echo "\nIndex is locked, exiting!\n";
			return true;
		}
		echo "locked!";
		$conn = Propel::getConnection();
		if (count($args) < 2)
			$args[1] = 'update';	// 'update' is the default behaviour

		$manif_cache_select_cond = false;
		$auth_cache_select_cond = false;

		switch ($args[1]) {
			case 'manifestation':
				$manif_cache_select_cond = '';
				break;
			case 'authority':
				$auth_cache_select_cond = '';
				break;
			case 'all':
				$manif_cache_select_cond = '';
				$auth_cache_select_cond = '';
				break;

			case 'prune':
				$this->pruneAllIndex();
				break;

			case 'update':
				echo "\nUpdating index...";
                $auth_cache_select_cond = $this->updateAuthorityCaches($conn);
				$manif_cache_select_cond = $this->updateManifestationCaches($conn);
				break;

			default:
				if (is_numeric($args[1])) {
					$manif_cache_select_cond = TurbomarcCachePeer::MANIFESTATION_ID.' = '.$args[1];
				} else if ($args[1]{0} == 'a') {
					$auth_cache_select_cond = TurbomarcauthorityCachePeer::AUTHORITY_ID.' = '.intval(substr($args[1],1));
				} else if ($args[1]{0} == 's') {
					// if argument begins with a 's' user wants to index a shelf
					$shelf_type = $conn->query('SELECT '.ShelfPeer::SHELF_ITEMTYPE.' FROM '.ShelfPeer::TABLE_NAME.
						' WHERE '.ShelfPeer::SHELF_ID.' = '.intval(substr($args[1],1)))->fetchColumn();
					if (!in_array($shelf_type,array(ShelfPeer::TYPE_AUTHORITY,ShelfPeer::TYPE_MANIFESTATION))) {
						echo "\nShelf has no singe item type, cowardly refusing to index it!\n";
						return false;
					}
					$stmt = $conn->prepare('SELECT '.ShelfItemPeer::OBJECT_ID.' FROM '.ShelfItemPeer::TABLE_NAME.
						' WHERE '.ShelfItemPeer::OBJECT_CLASS.' = ? AND '.ShelfItemPeer::SHELF_ID.' = ?');
					$stmt->execute(array($shelf_type,intval(substr($args[1],1))));
					$object_ids = $stmt->fetchAll(PDO::FETCH_COLUMN);
					switch ($shelf_type) {
						case ShelfPeer::TYPE_MANIFESTATION:
							$manif_cache_select_cond = TurbomarcCachePeer::MANIFESTATION_ID.' IN ('.implode(',',$object_ids).')';
							break;
						case ShelfPeer::TYPE_AUTHORITY:
							$auth_cache_select_cond = TurbomarcauthorityCachePeer::AUTHORITY_ID.' IN ('.implode(',',$object_ids).')';
							break;
					}
				} else if ($args[1]{0} == 'd') {
					$date = new DateTime(substr($args[1],1));
					$mids = ManifestationQuery::create()
						->filterByDateUpdated($date, Criteria::GREATER_EQUAL)
						->select(array('ManifestationId'))
						->find()->toArray();
					$manif_cache_select_cond = TurbomarcCachePeer::MANIFESTATION_ID.' IN ('.implode(',',$mids).')';
				}

				break;
		}
		$toFile = (count($args) > 2 && $args[2] == 'debug');

		/* @var $search ISearchModule */
		$search = Prado::getApplication()->getModule('search');

		// clean index if required
		if (count($args) > 1 && (!isset($args[2]) || $args[2] != 'noclean')
				&& in_array($args[1],array('all','manifestation','authority')))
		{
			switch ($args[1]) {
				case 'manifestation':
					$search->cleanIndex();
					break;
				case 'authority':
					$search->cleanIndexAuthority();
					break;
				case 'all':
					$search->cleanIndex();
					$search->cleanIndexAuthority();
					break;
			}
		}

		try {
			if (false !== $manif_cache_select_cond)
				$timings = $this->indexManifestations($conn, $manif_cache_select_cond, $search, $toFile);
			if (false !== $auth_cache_select_cond)
				$timings_auth = $this->indexAuthorities($conn, $auth_cache_select_cond, $search, $toFile);
		} catch (Exception $e) {
			Prado::log("General error - message {$e->__toString()}\n",
						TLogger::ERROR,'Console');
			print "\n!!!! SOMETHING WENT WRONG, please check your logs.\n".
				"Exception throwed is [{$e->getCode()}] {$e->getMessage()}.\n";
			exit();
		}
		// release lock
		flock($fp, LOCK_UN);
		fclose($fp);

		// ALL DONE, OUTPUT STATISTICS
		if (isset($timings) && is_array($timings)) {
			$count = count($timings);
			$total = array_sum($timings);
			$avg = $total / $count;
			sort($timings);
			$middleval = floor(($count-1)/2);
			if ($count % 2) {
				$median = $timings[$middleval];
			} else {
				$low = $timings[$middleval];
				$high = $timings[$middleval+1];
				$median = (($low+$high)/2);
			}
			echo "\n\n".__CLASS__." MANIFESTATION STATISTICS (actually processed):\n".
				"Record count (slices of ".self::SLICE_COUNT." elements): {$count}\nTotal time spent: {$total}\n".
				"Average time for slice indexing: {$avg}\nMedian time: {$median}\n";
		}
		if (isset($timings_auth) && is_array($timings_auth)) {
			$a_count = count($timings_auth);
			$a_total = array_sum($timings_auth);
			$a_avg = $a_total / $a_count;
			sort($timings_auth);
			$a_middleval = floor(($a_count-1)/2);
			if ($a_count % 2) {
				$a_median = $timings_auth[$a_middleval];
			} else {
				$a_low = $timings_auth[$a_middleval];
				$a_high = $timings_auth[$a_middleval+1];
				$a_median = (($a_low+$a_high)/2);
			}
			echo "\n\n".__CLASS__." AUTHORITY STATISTICS (actually processed):\n".
				"Record count (slices of ".self::SLICE_COUNT." elements): {$a_count}\nTotal time spent: {$a_total}\n".
				"Average time for slice indexing: {$a_avg}\nMedian time: {$a_median}\n";
		}
		echo "\n#### ALL DONE!!! ####\n";
		return true;
	}

	private function updateManifestationCaches(PDO $conn)
	{
		require_once('CacheTmarc.php');
		$stmt = $conn->query('SELECT COUNT('.TurbomarcCachePeer::MANIFESTATION_ID.') FROM '.
			TurbomarcCachePeer::TABLE_NAME.' WHERE '.TurbomarcCachePeer::INDEXED.
			' = 0 OR '.TurbomarcCachePeer::DIRTY.' = 1');
		if ($stmt->fetchColumn() < 1) {
			echo " nothing to reindex, index is up-to-date!";
			echo "\n#### ALL DONE!!! ####\n";
			return false;
		}
		$cacheAction = new ClavisActionCacheTmarc();
		$cacheAction->cacheManifestations(true,
			'SELECT '.TurbomarcCachePeer::MANIFESTATION_ID.','.TurbomarcCachePeer::TURBOMARC.
			','.TurbomarcCachePeer::DIRTY.' FROM '.TurbomarcCachePeer::TABLE_NAME.
			' WHERE '.TurbomarcCachePeer::DIRTY.' = ? LIMIT '.self::SLICE_COUNT,
			array(1));
		return TurbomarcCachePeer::DIRTY.' = 0 AND '.
			TurbomarcCachePeer::INDEXED.' = 0 LIMIT '.self::SLICE_COUNT;
	}

	private function updateAuthorityCaches(PDO $conn)
	{
		require_once('CacheTmarc.php');
		$stmt = $conn->query('SELECT COUNT('.TurbomarcauthorityCachePeer::AUTHORITY_ID.') FROM '.
			TurbomarcauthorityCachePeer::TABLE_NAME.' WHERE '.TurbomarcauthorityCachePeer::INDEXED.
			' = 0 OR '.TurbomarcauthorityCachePeer::DIRTY.' = 1');
		if ($stmt->fetchColumn() < 1) {
			echo " nothing to reindex, index is up-to-date!";
			echo "\n#### ALL DONE!!! ####\n";
			return false;
		}
		$cacheAction = new ClavisActionCacheTmarc();
		$cacheAction->cacheAuthorities(true,
			'SELECT '.TurbomarcauthorityCachePeer::AUTHORITY_ID.','.TurbomarcauthorityCachePeer::TURBOMARC.
			','.TurbomarcauthorityCachePeer::DIRTY.' FROM '.TurbomarcauthorityCachePeer::TABLE_NAME.
			' WHERE '.TurbomarcauthorityCachePeer::DIRTY.' = ? LIMIT '.self::SLICE_COUNT,
			array(1));
		return TurbomarcauthorityCachePeer::DIRTY.' = 0 AND '.
			TurbomarcauthorityCachePeer::INDEXED.' = 0 LIMIT '.self::SLICE_COUNT;
	}

	private function indexManifestations(PDO $conn, $cache_select_cond, $search, $toFile)
	{
		$sqlCond = trim($cache_select_cond) ? ' WHERE '.$cache_select_cond : '';
		$stmtCount = $conn->prepare('SELECT COUNT('.TurbomarcCachePeer::MANIFESTATION_ID.') FROM '.
			TurbomarcCachePeer::TABLE_NAME.$sqlCond);
		$stmtCount->execute();
		$rowCount = $stmtCount->fetchColumn(0);
		echo "\n{$rowCount} records to be indexed.";
		if ($rowCount < 1) {
			echo "\nIndex is up-to-date (or some dirty caches remains)!\n";
			return true;
		}
		$mt = microtime(true);
		$stmt = $conn->prepare('SELECT '.TurbomarcCachePeer::MANIFESTATION_ID.','.
			TurbomarcCachePeer::TURBOMARC.' FROM '.TurbomarcCachePeer::TABLE_NAME.$sqlCond);
		$stmt->execute();
		$queryTime = microtime(true) - $mt;
		echo "\nQUERY DONE (in {$queryTime}ms)";
		$data = $timings = array();
		$totalcount = 0;
		$mt = microtime(true);
		while ($row = $stmt->fetch()) {
			$data[$row[0]] = $row[1];
			if (count($data) >= self::SLICE_COUNT) {
				$search->index($data,false,$toFile);
				$id = array_keys($data);
				$count = $conn->exec('UPDATE '.TurbomarcCachePeer::TABLE_NAME.' SET '.TurbomarcCachePeer::INDEXED.
					' = 1 WHERE '.TurbomarcCachePeer::MANIFESTATION_ID.' IN ('.implode(',',$id).')');
				if (count($id) != $count)
					echo "\nCache update got {$count} indexed=1 update against ".count($id)." indexed.";
				$totalcount += count($data);
				echo "\n{$totalcount} records indexed";
				$data = array();
				$timings[] = microtime(true) - $mt;
				$mt = microtime(true);
			}
		}
		if (count($data) > 0) {
			$search->index($data,false,$toFile);
			$id = array_keys($data);
			$count = $conn->exec('UPDATE '.TurbomarcCachePeer::TABLE_NAME.' SET '.TurbomarcCachePeer::INDEXED.
				' = 1 WHERE '.TurbomarcCachePeer::MANIFESTATION_ID.' IN ('.implode(',',$id).')');
			if (count($id) != $count)
				echo "\nCache update got {$count} indexed=1 update against ".count($id)." indexed.";
			$totalcount += count($data);
			echo "\n{$totalcount} records indexed";
			$timings[] = microtime(true) - $mt;
		}
		return $timings;
	}

	private function indexAuthorities(PDO $conn, $cache_select_cond, ISearchModule $search, $toFile)
	{
		$sqlCond = trim($cache_select_cond) ? ' WHERE '.$cache_select_cond : '';
		$stmtCount = $conn->prepare('SELECT COUNT('.TurbomarcauthorityCachePeer::AUTHORITY_ID.') FROM '.
			TurbomarcauthorityCachePeer::TABLE_NAME.$sqlCond);
		$stmtCount->execute();
		$rowCount = $stmtCount->fetchColumn(0);
		echo "\n{$rowCount} authorities to be indexed.";
		if ($rowCount < 1) {
			echo "\nIndex is up-to-date (or some dirty caches remains)!\n";
			return true;
		}
		$mt = microtime(true);
		$stmt = $conn->prepare('SELECT '.TurbomarcauthorityCachePeer::AUTHORITY_ID.','.
			TurbomarcauthorityCachePeer::TURBOMARC.' FROM '.TurbomarcauthorityCachePeer::TABLE_NAME.$sqlCond);
		$stmt->execute();
		$queryTime = microtime(true) - $mt;
		echo "\nQUERY DONE (in {$queryTime}ms)";
		$data = $timings = array();
		$totalcount = 0;
		$mt = microtime(true);
		while ($row = $stmt->fetch()) {
			$data[$row[0]] = $row[1];
			if (count($data) >= self::SLICE_COUNT) {
				$search->indexAuthority($data,false,$toFile);
				$id = array_keys($data);
				$count = $conn->exec('UPDATE '.TurbomarcauthorityCachePeer::TABLE_NAME.
					' SET '.TurbomarcauthorityCachePeer::INDEXED.' = 1 WHERE '.
					TurbomarcauthorityCachePeer::AUTHORITY_ID.' IN ('.implode(',',$id).')');
				if (count($id) != $count)
					echo "\nCache update got {$count} indexed=1 update against ".count($id)." indexed.";
				$totalcount += count($data);
				echo "\n{$totalcount} authorities indexed";
				$data = array();
				$timings[] = microtime(true) - $mt;
				$mt = microtime(true);
			}
		}
		if (count($data) > 0) {
			$search->indexAuthority($data,false,$toFile);
			$id = array_keys($data);
			$count = $conn->exec('UPDATE '.TurbomarcauthorityCachePeer::TABLE_NAME.
				' SET '.TurbomarcauthorityCachePeer::INDEXED.' = 1 WHERE '.
				TurbomarcauthorityCachePeer::AUTHORITY_ID.' IN ('.implode(',',$id).')');
			if (count($id) != $count)
				echo "\nCache update got {$count} indexed=1 update against ".count($id)." indexed.";
			$totalcount += count($data);
			echo "\n{$totalcount} authorities indexed";
			$timings[] = microtime(true) - $mt;
		}
		return $timings;
	}

	public function pruneAllIndex()
	{
		print "\nPrune index\n";

		/* @var $search SolrSearch */
		$search = Prado::getApplication()->getModule('search');

		$manIds  = Propel::getConnection()->query("SELECT manifestation_id,bid FROM manifestation")->fetchAll(PDO::FETCH_COLUMN|PDO::FETCH_GROUP);
		$authIds = Propel::getConnection()->query("SELECT authority_id,bid FROM authority")->fetchAll(PDO::FETCH_COLUMN|PDO::FETCH_GROUP);

		print "All ids loaded ". count($manIds) . "/" . count($authIds). "\n";

		print "Prune Manifestation\n";
		
		$cursor = 0;
		$pageSize = 20000;

		while(1)
		{
			$manIndex = $search->search("*:*",$cursor, $cursor + $pageSize,'id',['fl'=>'id']);

			//var_dump($manIndex['response']);
			//die();
			$delIds = [];
			foreach($manIndex['response']['docs'] as $doc)
				if(!isset($manIds[$doc['Id']]))
				{
					print "Prune manifestation {$doc['Id']}\n";
					$delIds[] = $doc['Id'];
				}
			if(count($delIds) > 0)
				$search->deIndex($delIds);

			if(count($manIndex['response']['docs']) == 0) break;

			$cursor += $pageSize;
		}
		$search->sendCommit();

		$cursor = 0;

		print "Prune Authority\n";

		while(1)
		{
			$autIndex = $search->searchAuthority("*:*",$cursor, $cursor + $pageSize,'id',['fl'=>'id']);
			$delIds = [];
			//var_dump($autIndex['response']);

			foreach($autIndex['response']['docs'] as $doc)
				if(!isset($authIds[$doc['Id']]))
				{
					print "Prune authority {$doc['Id']}\n";
					$delIds[] = $doc['Id'];
				}
			if(count($delIds) > 0)
				$search->deIndexAuthority($delIds);

			if(count($autIndex['response']['docs']) == 0) break;

			$cursor += $pageSize;
		}
		$search->sendCommit();

		$search->sendOptimize();

	}
}
