<?php
/**
 * Rebuilds all manifestations checking for inconsistencies.
 * Requires indexing on completion.
 *
 * Any parameter:
 * 	* sanitize Turbomarc XML:
 * 		* replacing out-of-range chars with spaces.
 * 		* lowercase leader, language and country
 * 		* replace | with space in CDFs
 * 		* remove empty subfields
 *
 * Param 'fields':
 * 	* resets edition_date, edition_language, publisher, bib_level and hierarchical_level from Turbomarc
 *
 * Param 'authors':
 * 	* resets main author retrieving it from 7xx fields (only main/alternative)
 *
 * Param 'titles':
 * 	* resets titles from actual 200, updating cascade all items and loans
 *
 * Param 'full':
 * 	* all of the above
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Console
 * @since 2.5.0
 */
require_once('ClavisCommandLineAction.php');

/**
 * @package Console
 * @since 2.5.0
 */
class ClavisActionRebuildManifestations extends ClavisCommandLineAction
{
	protected $action = 'rebuild_manifestations';
	protected $parameters = array('fields|authors|titles|pubdates|resave|parseisbd|full');
	protected $optional = array('force');
	protected $description = 'Checks manifestations for inconsistencies, and correct them. Please be warned that is a VERY time-consuming task.';

	public function performAction($args)
	{
		$action = (!$args[1] || $args[1] == 'full') ? null : $args[1];
		$force = isset($args[2]) && 'force' == $args[2];
		$sql = 'SELECT '.ManifestationPeer::MANIFESTATION_ID.' FROM '.ManifestationPeer::TABLE_NAME ;
		$counter = 0;
		foreach (Propel::getConnection()->query($sql,PDO::FETCH_NUM) as $mid) {
			$m = ManifestationQuery::create()->findPk($mid[0]);
			if (!$m instanceof Manifestation)
				continue;

			try {
				// sanitize unimarc
				$m->setUnimarc($this->fixTurboMarc($m->getUnimarc()));

				if (!$action || 'fields' == $action)
					$this->resetExplicitFields($m);

				// syncs all authors
				if (!$action || 'authors' == $action)
					$m->syncAuthor();

				if (!$action || 'titles' == $action) {
					$tm = $m->getTurboMarc();
					$text = preg_replace('![\* ]*\x{00C2}\x{0088}(.*?)\x{00C2}\x{0089}!u','$1*',(string)$tm->d200->sa);
					$text = preg_replace('![\* ]*\x{0088}(.*?)\x{0089}!u','$1*',$text);
					$text = preg_replace('![\* ]*\x{001B}.(.*?)\x{001B}.!u','$1*',$text);
					$text = preg_replace('!\*\s*\*!u','*',$text);
					$tm->d200->sa = $text;
					$m->syncTitle();
					if ($m->isColumnModified(ManifestationPeer::TITLE) || $force)
						$this->updateItemTitles($m);
				}

                if (!$action || 'parseisbd' == $action) {
                    $this->fixISBD($m);
                    $m->syncTitle();
                    if ($m->isColumnModified(ManifestationPeer::TITLE) || $force)
                        $this->updateItemTitles($m);
                }

				if (!$action || 'pubdates' == $action) {
					$this->fixPublicationDates($m);
					$this->resetExplicitFields($m);
				}

				if (!$action || 'resave' == $action) {
					$this->fixHierarchicalLevel($m);
				}

				if ($m->isModified() || $force) {
					print "\nUpdating incorrect manifestation [{$m->getManifestationId()}]...";
					$m->save();
				}
			} catch (Exception $e) {
				print "\nEXCEPTION ON manifestation [{$m->getManifestationId()}]\n";
				//throw $e;
			}
			if ((++$counter % 10000) == 0)
				echo "\n{$counter} manifestations processed! ".date('Y-m-d H:i:s');
			$m->clearAllReferences(true);
			unset($m);
		}

		echo "\n------------------------------------------------------------------------------------------------\n";
		echo "\nDone. Please note that corrected manifestation have not been indexed yet.\n";
		echo "\nYou'll need either to manually launch 'index' action or leave it to the scheduled index updater.\n";
		echo "\n------------------------------------------------------------------------------------------------\n";
		echo "\n#### ALL DONE!!! ####\n";
		return true;
	}

	public function resetExplicitFields(Manifestation $m)
	{
		$tm = $m->getTurboMarc();
		$m->setEditionDate(isset($tm->d100) ? trim($tm->d100->getCDF('a',9)) : '');
		$m->setEditionLanguage(isset($tm->d101) ? (string)$tm->d101->children() : '');
		$m->setPublisher(isset($tm->d210) ? (string)$tm->d210->sc : '');
		$l = $tm->getLeader();
		if ($l->biblevel != $m->getBibLevel() &&
				in_array(strtolower($m->getBibLevel()),
					array(ManifestationPeer::LVL_ANALYTIC,ManifestationPeer::LVL_SERIAL,
						ManifestationPeer::LVL_MONOGRAPHIC,ManifestationPeer::LVL_COLLECTION))) {
			$l->biblevel = strtolower($m->getBibLevel());
			$tm->setLeader($l);
			$m->setUnimarc($tm->asXML());
		}
		$m->setBibLevel(strtolower($l->biblevel));
	}

	public function updateItemTitles(Manifestation $m)
	{
		$base_title = $m->getTitle();
		$dewey = $m->getClass();
		if ($m->getBibLevel() == ManifestationPeer::LVL_SERIAL) {
			foreach ($m->getIssues() as $is) {
				$title = "{$base_title} (fasc: {$is->getIssueCombo(false)})";
				$iq = ItemQuery::create()
					->filterByIssue($is)
					->update(array('ManifestationDewey' => $dewey,'Title' => $title));
			}
		} else {
			$iq = ItemQuery::create()
				->filterByManifestation($m)
				->update(array(
					'ManifestationDewey' => $dewey,
					'Title'	=> $base_title));
		}
		LoanPeer::updateTitle($m);
	}

	public function fixTurboMarc($tmxml)
	{
		Clavis::html2xmlEntities($tmxml);
		Clavis::sanitizeForXML($tmxml);

		$patterns = array(
			'!<l>([\w\d\s]+)</l>!ie',	// match leader
			'!<(d10[12])(.+?)</\1>!ie',	// match 101/102
			'!<(d1\d\d)(.+?)</\1>!ie',	// match all CDFs
			'!<(s[\d\w])>\s*</\1>!'		// match empty tags
		);
		$replacements = array(
			"'<l>'.strtolower('$1').'</l>'",	// lowercase leader
			"'<$1'.stripslashes(strtolower('$2')).'</$1>'",	// lowercase language and country
			"'<$1'.stripslashes(str_replace('|',' ','$2')).'</$1>'",	// fix |
			''	// remove empty tags
		);
		$tmxml = preg_replace($patterns, $replacements, $tmxml);

		return $tmxml;
	}

	public function fixISBD(Manifestation $m)
	{
		$tm = $m->getTurboMarc();
		if (isset($tm->d200)) {
			$titles = $tm->getTitle();
			unset($tm->d200);
			$title = "{$titles['nst']}*".array_shift($titles['txt']);
			$tm->setTitle($title, $titles['txt'], $titles['ind']);
			$m->setUnimarc($tm->asXML());
		}
		if (isset($tm->d210)) {
			$pubs = $tm->getPublications();
			unset($tm->d210);
			foreach ($pubs as $pub)
				$tm->setPublication($pub);
			$m->setUnimarc($tm->asXML());
		}
	}

	public function fixPublicationDates(Manifestation $m)
	{
		$tm = $m->getTurboMarc();
		$next_year = date('Y') + 1;
		if (isset($tm->d100)) {
			$datetype = (string)$tm->d100->getCDF('a',8);
			$date = (string)$tm->d100->getCDF('a',9);
			if (('d' == $datetype && (!trim($date) || $date > $next_year)) ||
					(!trim($datetype) && !trim($date)))
			{
				if (isset($tm->d210)) {
					$publication = $tm->getPublications(true);
					unset($tm->d210);
					foreach($publication as $p)
						$tm->setPublication($p['txt'],str_pad($p['ind'],2,' ',STR_PAD_RIGHT));
					$pubdate = (isset($tm->d210->sd) && preg_match('!(\d{4})!',(string)$tm->d210->sd,$match)) ?
						$match[1] : '    ';
				} else {
					$pubdate = '    ';
				}
				$tm->d100->setCDF('a',9,$pubdate);
				$tm->d100->setCDF('a',8, trim($pubdate) ? 'd' : 'f');
				$m->setUnimarc($tm->asXML());
			}
		}
	}

	public function fixHierarchicalLevel(Manifestation $m)
	{
		$m->save();
	}
}
