<?php
/**
 * ClavisActionIndexAuthority class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Console
 */
require_once('ClavisCommandLineAction.php');

/**
 * ClavisActionIndexAuthority Class
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Console
 * @since 2.5.0
 */
class ClavisActionIndexAuthority extends ClavisCommandLineAction
{
	protected $action = 'index_authority';
	protected $parameters = array();
	protected $optional = array('all | <authority_id> | s<shelfId> | d<date>','debug');
	protected $description = 'Batch index all authorities in db. Use optional argument to specify the index subject: [update] will search&cache all dirty or not-yet-cached manifestations, then index them (default), [all] will clean the whole index and reindex all manifestations, [<manifestation id>] will index a single manifestation, [s<shelfId>] to take all manifestations contained in a shelf, [d<date>] to index all manifestations updated after a certain date. Second optional argument, if specified, writes indexing doc to /tmp/solrDoc.xml and doesn\'t send it to Solr server.';

	private $_outputParams = array();

	const STOPFILE = 'do_not_index';
	const LOCKFILE = 'indexauth.lock';
//	const SLICE_COUNT = 16384;
	const SLICE_COUNT = 8912;

	public function performAction($args)
	{
		$tmpdir = Prado::getPathOfNamespace('Storage.temp');
		if (file_exists($tmpdir.'/'.self::STOPFILE)) {
			echo "\nWon't index as you command, my king!\n";
			return true;
		}
		$fp = fopen($tmpdir.'/'.self::LOCKFILE, 'w');
		if (!flock($fp, LOCK_EX | LOCK_NB)) {
			echo "\nIndex is locked, exiting!\n";
			return true;
		}
		$conn = Propel::getConnection();
		$finalOptimize = true;
		$mids = array();
		if (count($args) < 2)
			$args[1] = 'all';	// 'all' is the default behaviour

		switch ($args[1]) {
			case 'all':
				$aids = array();
				break;

			default:
				if (is_integer($args[1])) {
					// if argument is an integer, take it as ManifestationId; elsewhere, try to convert to date.
					$mids = array($args[1]);
				} else if ($args[1][0] == 's') {
					// if argument begins with a 's' user wants to index a shelf
					$stmt = $conn->prepare('SELECT `object_id` FROM `shelf_item`
						WHERE `object_class` = ? AND `shelf_id` = ?');
					$stmt->execute(array(ShelfPeer::TYPE_AUTHORITY,intval(substr($args[1],1))));
					$aids = $stmt->fetchAll(PDO::FETCH_COLUMN);
				} else if ($args[1][0] == 'd') {
					$date = new DateTime(substr($args[1],1));
					$mids = AuthorityQuery::create()
						->filterByDateUpdated($date, Criteria::GREATER_EQUAL)
						->select(array('AuthorityId'))
						->find()->toArray();
				}
				break;
		}
		$toFile = (count($args) > 2 && $args[2] == 'debug');

		/* @var $search ISearchModule */
		$search = Prado::getApplication()->getModule('search');
		if (count($args) > 1 && $args[1] == 'all') {
			// cleanup the whole index
			$search->cleanIndexAuthority();
		}
		try {
			$sqlCond = 'FROM '.AuthorityPeer::TABLE_NAME.' WHERE 1=1 ';
			$params = array(0);
			if (is_integer($mids)) {
				$sqlCond .= ' AND '.AuthorityPeer::AUTHORITY_ID.' = ?';
				$params[] = intval($aids);
			} else if (is_array($aids) && count($aids)>0) {
				$sqlCond .= ' AND '.AuthorityPeer::AUTHORITY_ID.' IN (?'.str_repeat(',?',count($aids)-1).')';
				$params = array_merge($params,$aids);
			}

			$stmtCount = $conn->prepare('SELECT COUNT(*) '.$sqlCond);
			$stmtCount->execute($params);
			$rowCount = $stmtCount->fetchColumn(0);
			echo "{$rowCount} authorities to be indexed.";
			if ($rowCount < 1) {
				echo "\nIndex is up-to-date (or some dirty caches remains)!\n";
				return true;
			}

			$mt = microtime(true);
			$stmt = $conn->prepare('SELECT * '.$sqlCond);
			$stmt->execute($params);
			$queryTime = microtime(true) - $mt;
			echo "\nQUERY DONE (in {$queryTime}ms)";
			$data = $timings = array();
			$totalcount = 0;
			$mt = microtime(true);
			while ($row = $stmt->fetch()) {
				$data[$row[0]] = $row[0];
				if (count($data) >= self::SLICE_COUNT) {
					$search->indexAuthority($data,false,$toFile);
					$totalcount += count($data);
					echo "\n{$totalcount} records indexed";
					$data = array();
					$timings[] = microtime(true) - $mt;
					$mt = microtime(true);
				}
			}
			$search->indexAuthority($data,$finalOptimize,$toFile);
			$totalcount += count($data);
			$timings[] = microtime(true) - $mt;
			echo "\n{$totalcount} records indexed";
		} catch (Exception $e) {
			Prado::log("General error - message {$e->__toString()}\n",
						TLogger::ERROR,'Console');
			print "\n!!!! SOMETHING WENT WRONG, please check your logs.\n".
				"Exception throwed is [{$e->getCode()}] {$e->getMessage()}.\n";
			exit();
		}
		// release lock
		flock($fp, LOCK_UN);
		fclose($fp);

		// ALL DONE, OUTPUT STATISTICS
		$count = count($timings);
		$total = array_sum($timings);
		$avg = $total / $count;
		sort($timings);
		$middleval = floor(($count-1)/2);
		if ($count % 2) {
			$median = $timings[$middleval];
		} else {
			$low = $timings[$middleval];
			$high = $timings[$middleval+1];
			$median = (($low+$high)/2);
		}
		echo "\n\n".__CLASS__." STATISTICS (actually processed):\n".
			"Authority count (slices of ".self::SLICE_COUNT." elements): {$count}\nTotal time spent: {$total}\n".
			"Average time for slice indexing: {$avg}\nMedian time: {$median}\n";
		echo "\n#### ALL DONE!!! ####\n";
		return true;
	}

}
