<?php

/**
 * Base class for command line actions.
 * Mutuated from PradoCommandLineAction by Wei Zhuo.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Console
 * @since 2.5.0
 */
abstract class ClavisCommandLineAction
{
	/**
	 * Execute the action.
	 * @param array command line parameters
	 * @return boolean true if action was handled
	 */
	public abstract function performAction($args);

	protected function createDirectory($dir, $mask)
	{
		if(!is_dir($dir))
		{
			mkdir($dir);
			echo "creating $dir\n";
		}
		if(is_dir($dir))
			chmod($dir, $mask);
	}

	protected function createFile($filename, $content)
	{
		if(!is_file($filename))
		{
			file_put_contents($filename, $content);
			echo "creating $filename\n";
		}
	}

	public function isValidAction($args)
	{
		return strtolower($args[0]) === $this->action &&
				count($args)-1 >= count($this->parameters);
	}

	public function renderHelp($compact=false)
	{
		$params = array();
		foreach($this->parameters as $v)
			$params[] = '<'.$v.'>';
		$parameters = join($params, ' ');
		$options = array();
		foreach($this->optional as $v)
			$options[] = '['.$v.']';
		$optional = (strlen($parameters) ? ' ' : ''). join($options, ' ');
		$description='';
		foreach(explode("\n", wordwrap($this->description,65)) as $line)
			$description .= '    '.$line."\n";
		$ret = "{$this->action} {$parameters}{$optional}";
		if (!$compact)
			$ret .= "\n\n{$description}\n";
		return $ret;
	}

    public function parseArgs($args)
    {
        $param = array();
        for ($i = 1; $i < count($args); $i++) {
            print "PARAM $i {$args[$i]}\n";
            if (substr($args[$i], 0, 2) == '--') {
                $param[substr($args[$i], 2)] = true;
            } elseif ($args[$i][0] == '-') {
                $param[substr($args[$i], 1)] = $args[$i + 1];
                $i++;
            } else {
                $param[] = $args[$i];
            }
        }
        return $param;

    }
}