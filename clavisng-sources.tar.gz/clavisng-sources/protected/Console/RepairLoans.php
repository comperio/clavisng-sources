<?php

/**
 * 
 * @author Marco Brancalion <mbrancalion@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2011 Comperio srl
 * @version 2.7
 * @package Console
 * @since 2.5.0
 */

require_once('ClavisCommandLineAction.php');

/**
 * @package Console
 * @since 2.5.0
 */
class ClavisActionRepairLoans extends ClavisCommandLineAction
{
	protected $action = 'repair_loans';
	protected $parameters = array();
	protected $optional = array('log');
	protected $description = "It repairs/resets the item and loan tables, by crossing data, and also outputs a log of uncertain cases onscreen.
									If called with the parameter 'log' there will be no loan overwriting,
									but only a log of anomalous loans (in a loan_status they should not be)";

	public function performAction($args)
	{
///Prado::log('prova di log', TLogger::INFO, "Clavis-cli");
/// il log non funziona

		$logOnlyFlag = false;
		if (count($args) > 1)  // if parameters exist
		{
			$param = strtolower($args[1]);
			switch (strtolower($param))
			{
				case "log":
					$logOnlyFlag = true;
					break;

				default:
					$logOnlyFlag = false;
			}
		}

		// paranoic assertive user input
		$this->echon("Are you sure you want to proceed with loan repair ?  Type 'yes' to continue: ");
		$handle = fopen ("php://stdin","r");
		$line = fgets($handle);
		if (trim($line) != 'yes')
			$this->echon("ABORTING !", true, true);

		// everythink ok. Go on
		$this->echon("Performing action", true);

		// find active items
		$activeStatus = ItemPeer::getLoanStatusActive();
		array_push($activeStatus, ItemPeer::LOANSTATUS_TOSHELF);


		$itemIds = ItemQuery::create()
						->filterByLoanStatus(ItemPeer::getLoanStatusCurrent())
						->select('ItemId')
						->find();

		$this->echon("Number of items found: " . count($itemIds), true);

		$okLoanIds = array();
		$errorLoanIds = array();
		$otherLoanIds = array();
		$errorItemIds = array();
		$itemCounter = 0;
		foreach ($itemIds as $itemId)
		{
			if (!$logOnlyFlag)
			{
				$this->echon(":" . ++$itemCounter);
				$this->echon("item.item_id = " . $itemId);
			}

			$item = ItemQuery::create()
						->findOneByItemId($itemId);

			$loanQuery = LoanQuery::create()
						->filterByItemId($itemId)
						->filterByLoanStatus($activeStatus)
						->orderByLoanDateBegin('desc')
						->keepQuery();

			$loanNum = $loanQuery->count();

			$loan = $loanQuery->findOne();
			if (!($loan instanceof Loan))
				continue;
			$loanId = $loan->getLoanId();

			if (!$logOnlyFlag)
				$this->echon("loan.loan_id = " . $loanId);
			///

			if ($logOnlyFlag)
			{
				$okLoanIds[] = $loanId;
				/////$this->echon("- skipped");
			}
			else
			{
				if ($this->injectLoan($loan, $item))
				{
					try
					{
						$loan->save();
						$okLoanIds[] = $loanId;
						$this->echon("-> written");
					}
					catch (Exception $e)
					{
						// Prado::log($e);
						$this->echon("** error in writing loan **");
					}
				}
				else
				{
					$this->echon("** error **");
					$errorLoanIds[] = $loanId;
					$errorItemIds[] = $itemId;
				}
			}

			if ($loanNum > 1)   // we found other anomalous loans, which should not exist
			{
				if (!$logOnlyFlag)
					$this->echon('Anomalous loans found with an appended loan_status: ', true);

				$loanQuery->where('Loan.LoanId != ?', $loanId);
				$otherLoans = $loanQuery->find();

				foreach ($otherLoans as $oLoan)
				{
					/** @var $oLoan Loan */
					if (!$logOnlyFlag)
					{
						$this->echon("loan.loan_id: " . $oLoan->getLoanId()
									. " - loan_status: " . $oLoan->getLoanStatus()
									. " (" . $oLoan->getLoanStatusString() . "): resolved to LOANSTATUS_CANCELED");

						$oLoan->setLoanStatus(ItemPeer::LOANSTATUS_CANCELED);
						$oLoan->save();
						$this->echon();
					}

					$otherLoanIds[] = $oLoan->getLoanId();
				}
			}

			unset ($loanQuery);
			unset ($item);
			unset ($loan);

			if (!$logOnlyFlag)
				$this->echon();
		}						// end of foreach (all found items)

		if ($logOnlyFlag)
			$messageOkString = "examined";
		else
			$messageOkString = "initialized";

		if (($okNum = count($okLoanIds)) > 0)
			$this->echon("==> $okNum loans $messageOkString", true);
		else
			$this->echon(" ** No loan $messageOkString", true);

		if (count($errorLoanIds) > 0)
		{
			$this->echon("There were errors in the following cases: ");
			foreach ($errorLoanIds as $in => $errLo)
			{
				$this->echon("item.item_id: " . $errorItemIds[$in]
								.", loan.loan_id: " . $errLo);
			}
			$this->echon();
		}

		if (count($otherLoanIds) > 0)
		{
			$this->echon("There were " . count($otherLoanIds) . " anomalies in loans (appended loans) which were resolved.");
			$this->echon();
		}

		// start logging anomalies
		$this->echon("Starting logging anomalies in loans ...", true);

		$excludeLoanIds = array_merge($okLoanIds, $errorLoanIds, $otherLoanIds);
		sort($excludeLoanIds);

		$anoLoanQuery = LoanQuery::create()
						->where("Loan.LoanId NOT IN ?", $excludeLoanIds)
						->filterByLoanStatus($activeStatus)
						->select('LoanId')
						->keepQuery();

		$anoLoanNum = $anoLoanQuery->count();
		if ($anoLoanNum > 0)
		{
			$this->echon("Number of anomalous loans found: " . $anoLoanNum, true);

			$this->echon("Their loan_id were: ");
			$this->echon();
			foreach ($anoLoanQuery->find() as $anLoanId)
			{
				$this->echon($anLoanId);
			}
		}
		else
			$this->echon("No anomalous loans found", true);

		$this->echon("Completed. Bye.", true, true);
	}

	private function injectLoan(&$loan, $item)
	{
		if (!($loan instanceof Loan) || !($item instanceof Item))
			return false;

		$returnValue = false;
		try
		{
			// de item
			$loan->setTitle($item->getTitle());

			$loan->setItemInventoryDate($item->getInventoryDate('U'));
			$loan->setItemMedia($item->getItemMedia());
			$loan->setMediapackageSize($item->getMediapackageSize());
			$loan->setInvNumber($item->getInventorySerieId() . "-" . $item->getInventoryNumber());
			$loan->setCollocation($item->getCollocation());
			$loan->setItemOwnerLibraryId($item->getOwnerLibraryId());
			$loan->setItemHomeLibraryId($item->getHomeLibraryId());


			$manifestation = $item->getManifestation();
			if ($manifestation instanceof Manifestation)
			{
				$loan->setClassCode($manifestation->getClass());
			}

			// de patron
			$destinationName = "";
			$patron = $loan->getPatron();
			if ($patron instanceof Patron)
			{
				$destinationName = $patron->getCompleteName();

				$age = $patron->getPatronAge($loan->getLoanDateBegin());
				if (!is_null($age))
					$loan->setPatronAge($age);

				$loan->setPatronCity($patron->getPatronCity());
			}
			elseif (($externalLibrary = $loan->getExternalLibrary()) instanceof Library)
			{
				$destinationName = $externalLibrary->getLabel();
			}

			$loan->setDestinationName($destinationName);

			$returnValue = true;
		}
		catch(Exception $e)
		{
			//Prado::log($e);
			$returnValue = false;
		}

		return $returnValue;
	}


	/**
	 * It outputs a string into the console with a newline in the end.
	 * More parameters below
	 *
	 * @param string $param : the text to be shown
	 * @param boolean $newlines : added newlines before and after [false]
	 * @param boolean $dieFlag  : do we have to exit, after printing ? [false]
	 */
	private function echon($param = "", $newlines = false, $dieFlag = false)
	{
		if ($newlines)
			$added = "\n";
		else
			$added = "";

		//if ($param != "")
		echo $added . $param. "\n". $added;

		if ($dieFlag)
			die();
	}

}