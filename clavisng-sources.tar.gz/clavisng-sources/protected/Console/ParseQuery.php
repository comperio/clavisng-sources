<?php

/**
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Console
 * @since 2.5.0
 */

require_once('ClavisCommandLineAction.php');

/**
 * @package Console
 * @since 2.5.0
 */
class ClavisActionParseQuery extends ClavisCommandLineAction
{
	protected $action = 'parse_query';
	protected $parameters = array();
	protected $optional = array('branch');
	protected $description = 'Updates the site database to last version, applying all missing queries. Use [branch] to specify the directory where the queries are kept, defaults to "contrib/dbquery/". Otherwise the dir will be "contrib/dbquery/$BRANCH".';

	private $_connection;

	public function performAction($args)
	{
		$defaultDir = 'contrib/dbquery';
		if (count($args) > 1) 
		{
			$branch = strtoupper($args[1]);
			$query_dir = realpath($defaultDir . '/' . strtolower($args[1]));
			if ($query_dir === false || !is_dir($query_dir))
				die ('** Unable to find directory "'.$query_dir."\".\n");
		} 
		else 
		{
			$branch = 'CORE';
			$query_dir = $defaultDir;
		}
		
		$this->_connection = Propel::getConnection();

		while (($dbStoredVersion = $this->getDbStoredVersion($branch)) === null) {
			print "\nThe database version number is not present: initialing ...\n";
			$this->initDbStoredVersion($branch);
		}

		print "\nBranch is '$branch'";
		print "\nThe database version is $dbStoredVersion\n\n";
		
		$queryArray = $this->parseDirectory($query_dir,$dbStoredVersion);
		

		print "\nStarting applying DB queries:\n";
		print "-----------------------------\n\n";
		$appliedCount = 0;
		foreach ($queryArray as $version => $query) {
			$this->applyQuery($version, $query, $branch);
			++$appliedCount;
		}
		print "\n-----------------------------\n";

		if ($appliedCount > 0)
			print "\nAll queries have been applied, and the database version has been updated to " . $this->getDbStoredVersion($branch) . "\n\n";
		else {
			print "Nothing to do ... The database version is still " . $this->getDbStoredVersion($branch) . "\n\n";
		}

		print "\nUpdating UNIMARC infos... ";
		$this->updateUnimarcLabels();
		$this->updateUnimarcCodes();
		print "done!\n";

		return true;
	}

	protected function getDbStoredVersion($branch = 'CORE') {
		$ver = ClavisParamQuery::create()
			->filterByParamClass('DBVERSION')
			->filterByParamName($branch)
			->findOne();
		return ($ver instanceof ClavisParam) ?
			intval($ver->getParamValue()) : null;
	}

	protected function initDbStoredVersion($branch = 'CORE') 
	{
		try 
		{
			//search for old format dbversion, if found, update it.
			$dbVersion = ClavisParamQuery::create()
				->filterByParamClass('DBVERSION')
				->filterByLibraryId(0)
				->filterByLibrarianId(0)
				->filterByParamName('UNIMARC%',Criteria::NOT_LIKE)
				->filterByParamName($branch)	
				->findOneOrCreate();
			$dbVersion->setParamName($branch);
			$dbVersion->save();
			//print "\nThe database version number has been initialized to 0\n\n";
		} catch (PDOException $exception) {
			$errorMessage = $exception->getMessage();
			$dbClass = Propel::getDB();
			if ($dbClass instanceof DBMySQL) {
				$duplicateCase = strstr($errorMessage, 'Duplicate entry');
				if ($duplicateCase != false) {
					print "   ---   Duplicate error caused by DB version number initialization\n\n";
					exit(1);
				} else {
					throw ($exception);
				}
			} else {
				throw ($exception);
			}
		}
	}

	protected function parseDirectory($directory,$currentVersion)
	{
		$dh = opendir($directory);
		if ($dh === false)
			throw new Exception('Cannot open specified directory.');
		$queryArray = array();
		while (($file = readdir($dh)) !== false) {
			if ($file[0] == '.')
				continue;

			$parts = preg_split('/[.-]/', $file);
			$version = $parts[count($parts) - 1];
			if (!is_numeric($version))
				continue;

			$version = intval($version);
			$completeFilename = $directory.'/'.$file;
			$query = file_get_contents($completeFilename);
			if (array_key_exists($version, $queryArray))
				throw new Exception("More than one patch file with db version number = $version exist !");

			if ($version > $currentVersion)
				$queryArray[$version] = $query;
		}
		ksort($queryArray, SORT_NUMERIC);
		return $queryArray;
	}

	protected function applyQuery($version, $sql, $branch) {
		print "-> ($version)";
		print ":: $sql\n";
		try {
			$pdo = $this->_connection->prepare($sql);
			$queryResult = $pdo->execute();
			$pdo->closeCursor();
			print "   ---   applied   ---    \n";
		} catch (PDOException $exception) {
			$applied = false;
			$errorMessage = $exception->getMessage();
			$dbClass = Propel::getDB();
			if ($dbClass instanceof DBMySQL) {
				$duplicateCase = strstr($errorMessage, 'Duplicate entry');
				if ($duplicateCase != false) {
					print "   ---   Duplicate error caused by query:\n\n";
					print $sql;
					print "\n\nDB version was stopped at ".$this->getDbStoredVersion($branch) . "\n\n";
					exit(1);
				}
				else
					throw ($exception);
			}
			else
				throw ($exception);
		}
	}
	
	protected function updateUnimarcLabels()
	{
		$datadir = Prado::getPathOfNamespace('Application.Data.unimarc_labels');

		foreach (glob("{$datadir}/unimarc_labels.*.sql") as $filename)
		{
			$tokens = explode('.',basename($filename));
			$lang = strtoupper($tokens[1]);
			$labelfile = file($filename);
			$labelfileVersion = trim(substr($labelfile[2], strpos($labelfile[2], 'NUMBER: ') + 8));

			$v = ClavisParamQuery::create()->filterByParamClass('DBVERSION')
				->filterByParamName('UNIMARC_LABELS_'.$lang)
				->findOneOrCreate();
			if ($v->isNew())
				$v->save();
			if (!$v->getParamValue() || $v->getParamValue() < $labelfileVersion) {
				print "updating [{$lang}] labels to v{$labelfileVersion}... ";
				$pdo = $this->_connection->prepare(implode("\n",$labelfile));
				$queryResult = $pdo->execute();
				$pdo->closeCursor();
			}
		}
	}
	
	protected function updateUnimarcCodes()
	{
		$datadir = Prado::getPathOfNamespace('Application.Data.unimarc_codes');

		foreach (glob("{$datadir}/unimarc_codes.*.sql") as $filename)
		{
			$tokens = explode('.',basename($filename));
			$lang = strtoupper($tokens[1]);
			$labelfile = file($filename);
			$labelfileVersion = trim(substr($labelfile[2], strpos($labelfile[2], 'NUMBER: ') + 8));

			$v = ClavisParamQuery::create()->filterByParamClass('DBVERSION')
				->filterByParamName('UNIMARC_CODES_'.$lang)
				->findOneOrCreate();
			if ($v->isNew())
				$v->save();
			if ($v->getParamValue() < $labelfileVersion) {
				print "updating [{$lang}] codes to v{$labelfileVersion}... ";
				$pdo = $this->_connection->prepare(implode("\n",$labelfile));
				$queryResult = $pdo->execute();
				$pdo->closeCursor();
			}
		}
	}
	
}
