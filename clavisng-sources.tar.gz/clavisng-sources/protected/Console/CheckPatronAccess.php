<?php

/**
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Console
 * @since 2.6.1
 */

require_once('ClavisCommandLineAction.php');

/**
 * @package Console
 * @since 2.6.1
 */
class ClavisActionCheckPatronAccess extends ClavisCommandLineAction
{
	protected $action = 'check_patron_access';
	protected $parameters = array();
	protected $optional = array();
	protected $description = 'Checks all patron accesses and force checkout for yesterday.';

	public function performAction($args)
	{
		if (ClavisParamQuery::getParam('CLAVISPARAM','PatronAccessControl') != 'true') {
			echo "\nPatron Access Control is not enabled on this site.";
		} else {
			echo "\nStarting...";
			$count = PatronActionPeer::expireYesterdayChecks();
			echo 'Forced checkout for '.$count.' users.';
		}

		echo "\n#### ALL DONE!!! ####\n";
		return true;
	}

}