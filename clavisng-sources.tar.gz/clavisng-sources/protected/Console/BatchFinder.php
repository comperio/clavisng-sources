<?php
/**
 * ClavisActionExport class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Console
 */
require_once('ClavisCommandLineAction.php');

/**
 * ClavisActionExport Class
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Console
 * @since 2.5.0
 */
class ClavisActionBatchFinder extends ClavisCommandLineAction
{
    protected $action = 'batch_finder';
    protected $parameters = array('shelfid', 'source');
    protected $optional = array();
    protected $description = 'Batch import Manifestation from a shelf';

    protected $_found;

    public function performAction($args)
    {
        $shelfId = $args[1];
        $sourceId = $args[2];


        print "\nStarting - This can take a very long time, please be patient...\n";

        $shelfItems = ShelfItemQuery::create()->findByShelfId($shelfId);

        foreach ($shelfItems as $si) {
            /** @var $si ShelfItem */
            $man = $si->getObject();
            if ($man instanceof Manifestation) {
                print "Manifestation {$man->getBidSource()} : {$man->getManifestationId()} \n";
                if ($this->findRBB($man->getEan())) {
                    print ">>>> Trovato in RBB\n";
                    $rec = $this->_found['Results'][0];
                    $this->buildGraph($rec, "Manifestation", 0, 'RBB');
                    $newm = $this->doJSONImport($rec, "Manifestation", 0);
                    if ($newm instanceof Manifestation) {
                        print "Nuova manifestation: {$newm->getManifestationId()}\n";
                        foreach ($man->getLAuthorityManifestations() as $lam)
                            $lam->delete();

                        foreach ($man->getLManifestationsRelatedByManifestationIdDown() as $lm) {
                            $lm->delete();
                        }
                        foreach ($man->getLManifestationsRelatedByManifestationIdUp() as $lm) {
                            $lm->delete();
                        }
                        $man->save();

                        $newm->setCreatedBy($man->getCreatedBy());
                        $newm->setDateCreated($man->getDateCreated());
                        $newm->save();

                        if ($man->replaceWith($newm)) {
                            $shelfItem = ShelfItemQuery::create()
                                ->filterByShelfId($shelfId)
                                ->filterByObjectClass("manifestation")
                                ->filterByObjectId($newm->getManifestationId())
                                ->findOne();
                            if ($shelfItem instanceof ShelfItem) {
                                print "Rimuovo da scaffale {$shelfId}\n";
                                $shelfItem->delete();

                            } else {
                                print ">>>> notizia non presente nello scaffale {$shelfId}\n";
                            }

                        } else {
                            print "Errore di schiacciamento \n";
                        }

                    } else {
                        print "Errore creazione notizia da RBB (Potrebbe già esistere)\n";
                    }
                }
            }
        }

        echo "\n#### ALL DONE!!! ####\n";
        return true;
    }


    public function findRBB($ean)
    {
        $this->_found = null;

        try {

            $jsonString = @file_get_contents('https://opac.provincia.brescia.it/clavisng/?export=json&ean=' . $ean);
            if ($jsonString === false)
                throw new Exception('Server not available', -1);

            $this->_found = json_decode($jsonString, true);
            if ($this->_found['Count'] == 1) {
                return true;
            } elseif ($this->_found['Count'] > 1) {
                print "Troppi record trovati\n";
                return false;
            } else {
                return false;
            }

        } catch (Exception $e) {
            return false;
        }
    }

    private function buildGraph(&$rec, $mode = "Manifestation", $level = 0, $sourceId = '')
    {
        static $visitStack = [];

        switch ($mode) {
            case "Manifestation":
                $rec['BidSource'] = $sourceId;
                $rec['Bid'] = $rec['ManifestationId'];

                $m1 = ManifestationQuery::create()
                    ->filterByBidSource($sourceId)
                    ->filterByBid($rec['ManifestationId'])
                    ->findOne();
                if ($m1 instanceof Manifestation) {
                    $rec['LocalRecordID'] = $m1->getManifestationId();
                }
                break;

            case "Authority":
                $rec['BidSource'] = $sourceId;
                $rec['Bid'] = $rec['AuthorityId'];

                $a1 = AuthorityQuery::create()
                    ->filterByBidSource($sourceId)
                    ->filterByBid($rec['AuthorityId'])
                    ->findOne();
                if ($a1 instanceof Authority) {

                    $rec['LocalRecordID'] = $a1->getAuthorityId();
                }
                break;
        }

        switch ($mode) {
            case "Manifestation":
                if (isset($rec['LManifestation']) && count($rec['LManifestation']) > 0) {

                    for ($i = 0; $i < count($rec['LManifestation']); $i++) {
                        $this->buildGraph($rec['LManifestation'][$i], 'LManifestation', $level + 1, $sourceId);
                    }

                }
                if (isset($rec['LAuthorityManifestation']) && count($rec['LAuthorityManifestation']) > 0) {

                    for ($i = 0; $i < count($rec['LAuthorityManifestation']); $i++) {
                        $this->buildGraph($rec['LAuthorityManifestation'][$i], 'LAuthorityManifestation', $level + 1, $sourceId);
                    }

                }
                break;
            case "LManifestation":
                if (isset($rec['Manifestation']))
                    $this->buildGraph($rec['Manifestation'], 'Manifestation', $level + 1, $sourceId);
                break;
            case "LAuthorityManifestation":
                if (isset($rec['Authority']))
                    $this->buildGraph($rec['Authority'], 'Authority', $level + 1, $sourceId);
                break;
            case "LAuthority":
                if (isset($rec['Authority']))
                    $this->buildGraph($rec['Authority'], 'Authority', $level + 1, $sourceId);
                break;
            case "Authority":
                if (isset($rec['LAuthority']) && count($rec['LAuthority']) > 0) {

                    for ($i = 0; $i < count($rec['LAuthority']); $i++)
                        $this->buildGraph($rec['LAuthority'][$i], 'LAuthority', $level + 1, $sourceId);

                }
                break;
        }

        return;
    }

    private function doJSONImport(&$rec, $mode = "Manifestation", $level = 0)
    {
        static $catDB = [];
        $m = null;

        switch ($mode) {
            case "Manifestation":
                if (isset($rec['LManifestation']) && count($rec['LManifestation']) > 0) {
                    for ($i = 0; $i < count($rec['LManifestation']); $i++) {
                        $this->doJSONImport($rec['LManifestation'][$i], 'LManifestation', $level + 1);
                    }
                }
                if (isset($rec['LAuthorityManifestation']) && count($rec['LAuthorityManifestation']) > 0) {
                    for ($i = 0; $i < count($rec['LAuthorityManifestation']); $i++) {
                        $this->doJSONImport($rec['LAuthorityManifestation'][$i], 'LAuthorityManifestation', $level + 1);
                    }
                }
                break;
            case "LManifestation":
                if (isset($rec['Manifestation']))
                    $this->doJSONImport($rec['Manifestation'], 'Manifestation', $level + 1);
                break;
            case "LAuthorityManifestation":
                if (isset($rec['Authority']))
                    $this->doJSONImport($rec['Authority'], 'Authority', $level + 1);
                break;
            case "LAuthority":
                if (isset($rec['Authority']))
                    $this->doJSONImport($rec['Authority'], 'Authority', $level + 1);
                break;
            case "Authority":
                if (isset($rec['LAuthority']) && count($rec['LAuthority']) > 0) {
                    for ($i = 0; $i < count($rec['LAuthority']); $i++)
                        $this->doJSONImport($rec['LAuthority'][$i], 'LAuthority', $level + 1);
                }
                break;
        }
        // Import object
        switch ($mode) {
            case "Manifestation":
                //TODO Create/Update Manifestation
                if (isset($rec['LocalRecordID'])) { // Local Record is present get actual Id
                    $rec['ManifestationId'] = $rec['LocalRecordID'];

                } elseif (isset($catDB['Manifestation'][$rec['Bid']])) {
                    $rec['ManifestationId'] = $catDB['Manifestation'][$rec['Bid']];
                } else {
                    // Create a new record
                    $m = new Manifestation();
                    $m->fromArray($rec);

                    $m->setManifestationId(null);
                    $m->setCreatedBy(1);
                    $m->setModifiedBy(1);
                    $m->setDateCreated(time());
                    $m->setDateUpdated(time());
                    $m->setNonSortText($rec['NonSortText']);
                    $m->save();

                    $rec['ManifestationId'] = $m->getManifestationId();
                    $catDB['Manifestation'][$rec['Bid']] = $m->getManifestationId();
                }

                if (isset($rec['LManifestation']) && count($rec['LManifestation']) > 0) {
                    for ($i = 0; $i < count($rec['LManifestation']); $i++) {
                        $rec['LManifestation'][$i]['ManifestationIdUp'] = $rec['ManifestationId'];
                        $rec['LManifestation'][$i]['ManifestationIdDown'] = $rec['LManifestation'][$i]['Manifestation']['ManifestationId'];
                        $lm = new LManifestation();
                        $lm->fromArray($rec['LManifestation'][$i]);

                        $lm->isNew(true);
                        try {
                            $lm->save();
                        } catch (Exception $e) {

                        }
                    }
                }
                if (isset($rec['LAuthorityManifestation']) && count($rec['LAuthorityManifestation']) > 0) {
                    for ($i = 0; $i < count($rec['LAuthorityManifestation']); $i++) {
                        $rec['LAuthorityManifestation'][$i]['AuthorityId'] = $rec['LAuthorityManifestation'][$i]['Authority']['AuthorityId'];
                        $rec['LAuthorityManifestation'][$i]['ManifestationId'] = $rec['ManifestationId'];
                        $lam = new LAuthorityManifestation();
                        $lam->fromArray($rec['LAuthorityManifestation'][$i]);

                        $lam->isNew(true);
                        try {
                            $lam->save();
                        } catch (Exception $e) {

                        }

                    }
                }

                break;

            case "Authority":
                if (isset($rec['LocalRecordID'])) { // Local Record is present get actual Id
                    $rec['AuthorityId'] = $rec['LocalRecordID'];
                } elseif (isset($catDB['Authority'][$rec['Bid']])) {
                    $rec['AuthorityId'] = $catDB['Authority'][$rec['Bid']];
                } else {
                    // Create a new record
                    $a = new Authority();
                    $a->fromArray($rec);

                    $a->setAuthorityId(null);
                    $a->setCreatedBy(1);
                    $a->setModifiedBy(1);
                    $a->setDateCreated(time());
                    $a->setDateUpdated(time());
                    $a->setNonSortText($rec['NonSortText']);
                    $a->save();
                    $rec['AuthorityId'] = $a->getAuthorityId();
                    $catDB['Authority'][$rec['Bid']] = $a->getAuthorityId();

                }

                if (isset($rec['LAuthority']) && count($rec['LAuthority']) > 0) {
                    for ($i = 0; $i < count($rec['LAuthority']); $i++) {
                        $rec['LAuthority'][$i]['AuthorityIdDown'] = $rec['AuthorityId'];
                        $rec['LAuthority'][$i]['AuthorityIdUp'] = $rec['LAuthority'][$i]['Authority']['AuthorityId'];
                        $la = new LAuthority();
                        $la->fromArray($rec['LAuthority'][$i]);

                        $la->isNew(true);
                        try {
                            $la->save();

                            $la->getAuthorityRelatedByAuthorityIdDown()->save();
                            $la->getAuthorityRelatedByAuthorityIdUp()->save();

                        } catch (Exception $e) {

                        }

                    }
                }
                break;
        }

        if ($level == 0 && $mode == 'Manifestation') {
            if ($m == null) {

            }
            return $m;
        }
    }
}
