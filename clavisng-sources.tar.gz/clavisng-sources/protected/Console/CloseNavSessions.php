<?php

/**
 * Should run at midnight by cron
 * @daily /var/www/html/clavisng/clavis-cli all close_nav_sessions >> /var/log/clavis.log 2>&1
 *
 * @author Cristian <ciarez@comperio.it>
 * @version 2.8.2
 * @package Console
 * @since 2.8.2
 */

require_once('ClavisCommandLineAction.php');

/**
 * @package Console
 * @since 2.8.2
 */
class ClavisActionCloseNavSessions extends ClavisCommandLineAction
{
	protected $action = 'close_nav_sessions';
	protected $parameters = array();
	protected $optional = array();
	protected $description = 'Close open navigation sessions if found.';


	public function performAction($args)
	{
		try
		{
			$con = Propel::getConnection();
			$sql = "update resource_session set acctstoptime=DATE_ADD(acctstarttime, INTERVAL acctsessiontime second), acctterminatecause='batch-close' where acctstoptime is null";
			$stmt = $con->prepare($sql);
			$stmt->execute();
			echo __METHOD__ . " done.";
			return true;
		} catch (Exception $ex) {
			echo __METHOD__ . " EXCEPTION: " . $ex->getMessage();
		}
		
		
	}
}