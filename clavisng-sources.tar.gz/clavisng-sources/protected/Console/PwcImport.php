<?php

require_once('ClavisCommandLineAction.php');

/**
 * @package Console
 * @since   2.5.0
 * ./clavis-cli default pwc_import -f ~/patrons.csv -t patrons
 * ./clavis-cli default pwc_import -f ~/loans.csv -t oloans
 * ./clavis-cli default pwc_import -f ~/loans.csv -t cloans
 */
class ClavisActionPwcImport extends ClavisCommandLineAction
{
    protected $action = 'pwc_import';
    protected $parameters = array('-f csv', '-t patrons|oloans|cloans');
    protected $optional = array();
    /** @var $logger Log */
    protected $logger;
    protected $description = 'Import or update patrons, import loans from a CSV file in PWC format.';

    /**
     * @var string
     */
    private $salt = '983274asdfhHGFD%^wPO09!';

    private $disabled_date_format = "d/m/Y";

    /**
     * @inheritDoc
     */
    public function performAction($args)
    {
        /*
         matricola; cognome; nome; email; numeroBadge1; numeroBadge2; centroDiCosto; managementLevel; teamLeader; teamLeader Email; tipo; fineAbilitazione
         CW-100111121;CASSANO;ANDREA LUIGI;ANDREA LUIGI.CASSANO.pwc.com;;260622365;REG CENTRALE Bologna;Director;PUNTI BARBORA;BARBORA.PUNTI.pwc.com;;25/12/2500

        L’email diventa lo username per accesso opac.
        matricola diventa card_code
        badge1 divernta barcode e badge2 diventa codice fiscale
        fineAbilitazione in car_expire e serve per individuare eventuali utenti da disabilitare in clavis.

        centrodicosto, managementLevel e tipo vanno custom property.
        Teamleader email contiene il responsabile dell’utente e deve essere legato usando l_patron con un tipo legame da personalizzare in lookup_table invece di padre/figlio possiamo fare “manager di/ha come manager”.

        Riceviamo ogni volta stessi utenti quindi occorre cercare se una
        anagrafica esiste già e va aggiornata di conseguenza.
        */

        ini_set("auto_detect_line_endings", true);
        $this->logger = Log::factory('console', '', 'pwc');
        $params = $this->parseArgs($args);

        $fin = fopen($params['f'], "r");
        if (!$fin) {
            $this->logger->err("Error opening file " . $params['csvfile']);
            exit();
        }

        $status = false;
        switch ($params['t']) {
            case 'patrons':
                $this->processPatrons($fin);
                break;
            case 'cloans': // closed loans
                $this->processLoans($fin, 'closed');
                break;
            case 'oloans': // open loans
                $this->processLoans($fin, 'open');
                break;
            default:
                $this->logger->err("Unrecognized or missing action type cli param. Specify one of 'patrons' 'cloans' or 'oloans' with the -t switch.");
                exit();
        }

        return $status;
    }

    /**
     * @param $fin
     */
    private function processPatrons($fin)
    {
        $this->disableAllThePatrons();

        $imported_patron = [];
        $header = [
            'matricola', 'cognome', 'nome', 'email', 'numeroBadge1', 'numeroBadge2', 'centroDiCosto',
            'managementLevel', 'teamLeader', 'teamLeaderEmail', 'tipo', 'fineAbilitazione',
        ];

        $this->logger->info("Importing patrons...");
        while ($row = fgetcsv($fin, 0, ";", "\"", "\"")) {
            if (count($row) != count($header)) {
                $this->logger->err("Skipping wrong CSV row " . print_r($row, true));
                continue;
            }

            try {
                $data = array_combine($header, $row);
                $imported_patron[] = $this->importPatron($data);
            } catch (Exception $e) {
                $this->logger->err("Error importing patron [{$data['matricola']}] - [{$data['email']}] [{$e->getMessage()}]");
            }
        }

        foreach ($imported_patron as $p) {
            $this->importLinkPatron($p);
        }

        $this->processDisabledPatron();
    }

    /**
     * @return int
     */
    private function disableAllThePatrons()
    {
        try {
            // Setta ad oggi al data disabilitazione di tutti i patron non ancora disabilitati.
            return PatronQuery::create()
                ->filterByCustom2('', Criteria::EQUAL)
                ->_or()
                ->filterByCustom2(null, Criteria::ISNULL)
                ->_or()
                ->filterByCustom2('Abilitato', Criteria::EQUAL)
                ->update(['Custom2' => date($this->disabled_date_format)]);
        } catch (PropelException $e) {
            $this->logger->err($e->getMessage());
            exit();
        }
    }

    /**
     * @param $p
     * @return mixed
     */
    private function importPatron($p)
    {
        try {
            $isNewPatron = false;
            $p['email'] = trim(str_replace('.pwc.com', '@pwc.com', $p['email']));
            $p['matricola'] = trim($p['matricola']);

            if ($p['matricola'] === '') {
                $this->logger->err("Skipping patron [{$p['email']}] with empty ID");
                return [];
            }

            if ($p['email'] === '') {
                $this->logger->err("Skipping patron with card code [{$p['matricola']}] and empty email");
                return [];
            }

            $patron = PatronQuery::create()
                ->useContactQuery()
                ->filterByContactType(ContactPeer::TYPE_EMAIL)
                ->filterByContactValue($p['email'])
                ->endUse()
                ->findOne();

            if (!$patron instanceof Patron) {
                $patron = new Patron();
                $patron->setDateCreated(time());
                $isNewPatron = true;
                $this->logger->info("Creating patron [{$p['matricola']}] - [{$p['email']}]");
            } else {
                $this->logger->info("Updating existing patron [{$p['matricola']}] - [{$p['email']}]");
            }

            $patron_usernames = PatronQuery::create()
                ->prune($patron)
                ->filterByOpacUsername($p['email']);

            if ($patron_usernames->count() !== 0) {
                $this->logger->err("Patron with id  [{$patron_usernames->findOne()->getPatronId()}] has OPAC username {$p['email']}");
                return [];
            }

            $patron->setLastname($p['cognome']);
            $patron->setName($p['nome']);
            $patron->setCardCode($p['matricola']);

            if (trim($p['numeroBadge1']) != '') {
                $patron->setBarcode(trim($p['numeroBadge1']));
            } else {
                $patron->setBarcode(trim($p['numeroBadge2']));
            }

            if (trim($p['numeroBadge2']) != '')
                $patron->setNationalId(trim($p['numeroBadge2']));

            $patron->setCardExpire(Datetime::createFromFormat('d/m/Y', $p['fineAbilitazione']));
            $patron->setDateUpdated(time());

            if ($isNewPatron) {
                $patron->setBirthDate(new DateTime('2000-01-01'));
                $patron->setCustom1('AA');
                $patron->setSurfEnable('1');
                $patron->setRegistrationLibraryId(1);
                $patron->setPreferredLibraryId(1);

                $patron->setLoanClass("A");
                $patron->setPatronStatus("A");
                $patron->setOpacEnable(true);
            }

            $patron->setCustom2(''); // tolgo la data che indicherebbe patron disabilitato oggi.
            $patron->setOpacUsername($p['email']);
            $patron->setOpacSecret(sha1($p['email'] . $this->salt));
            $patron->save();

            $p['patronId'] = $patron->getPatronId();

            $this->setPatronProperty($patron, 'A', $p['centroDiCosto']);
            $this->setPatronProperty($patron, 'B', $p['managementLevel']);
            $this->setPatronProperty($patron, 'C', $p['tipo']);

            $this->importPatronEmail($p);

            LPatronQuery::create()->filterByParentPatronId($patron->getPatronId())->delete();
        } catch (Exception $e) {
            $this->logger->err("Error processing patron [{$p['matricola']}] - [{$p['email']}] :" . $e->getMessage());
        }

        return $p;
    }

    /**
     * @param $patron
     * @param $property_class
     * @param $value
     * @return bool
     * @throws PropelException
     */
    private function setPatronProperty($patron, $property_class, $value)
    {

        $prop = PatronPropertyQuery::create()
            ->filterByPatron($patron)
            ->filterByPropertyClass($property_class)
            ->findOneOrCreate();

        if ($prop instanceof PatronProperty) {
            $prop->setPropertyValue($value);
            $prop->save();
            return true;
        }

        $this->logger->err("Error saving patron property [{$value}] of patron " . $patron->getOpacUsername() . '.');
        return false;
    }

    /**
     * @param $p
     */
    private function importPatronEmail($p)
    {
        $email = $p['email'];

        try {
            $existingContact = ContactQuery::create()
                ->filterByPatronId($p['patronId'])
                ->filterByContactType('E')
                ->filterByContactValue($email)
                ->findOne();

            if (!$existingContact instanceof Contact) {
                $existingContact = new Contact();
                $existingContact->setPatronId($p['patronId']);
                $existingContact->setContactType("E");
                $existingContact->setContactValue($email);
                $existingContact->save();
            }
        } catch (Exception $e) {
            $this->logger->err("Set email address error for [{$p['matricola']}] - [{$p['email']}]" . $e->getMessage());
        }
    }

    /**
     * @param $p
     */
    private function importLinkPatron($p)
    {
        try {
            $inf_pid = $p['patronId'] ?? -1;
            if ($inf_pid > 0) {
                $p['teamLeaderEmail'] = str_replace('.pwc.com', '@pwc.com', trim($p['teamLeaderEmail']));
                if ($p['teamLeaderEmail'] !== '' && $p['patronId']) {
                    $patron = PatronQuery::create()->findOneByOpacUsername($p['teamLeaderEmail']);
                    if ($patron instanceof Patron) {
                        $this->logger->info("Linking patron [{$p['email']}] to his team leader [{$p['teamLeaderEmail']}]");
                        $sup_pid = $patron->getPatronId();
                        $this->writeLinkPatron($sup_pid, $inf_pid, 'DC');
                    } else {
                        $this->logger->err("Error linking patron [{$p['email']}] to his team leader [{$p['teamLeaderEmail']}]. Team leader not found.");
                    }
                }
            }
        } catch (Exception $e) {
            $this->logger->err("Error linking patron [{$p['email']}] to his team leader [{$p['teamLeaderEmail']}]. " . $e->getMessage());
        }
    }

    /**
     * @param $parentPatronId
     * @param $childPatronId
     * @param $linkType
     * @throws PropelException
     */
    private function writeLinkPatron($parentPatronId, $childPatronId, $linkType)
    {
        $newLPatron = LPatronQuery::create()
            ->filterByParentPatronId($parentPatronId)
            ->filterByChildPatronId($childPatronId)
            ->findOne();

        if ($newLPatron instanceof LPatron) {
            $newLPatron->setLinkType($linkType);
        } else {
            $newLPatron = new LPatron();
            $newLPatron->setParentPatronId($parentPatronId);
            $newLPatron->setChildPatronId($childPatronId);
            $newLPatron->setLinkType($linkType);
        }

        $newLPatron->save();
    }

    /**
     * @throws Exception
     */
    private function processDisabledPatron()
    {
        foreach ($this->getDisabledPatrons() as $patron) {
            $this->anonimizePatron($patron);
        }
    }

    /**
     * @return array|mixed|PropelObjectCollection
     */
    private function getDisabledPatrons()
    {
        return PatronQuery::create()
            // cerco i patron che hanno una data di disabilitazione nel custom 2
            ->filterByCustom2('', Criteria::NOT_EQUAL)
            ->_and()
            ->filterByCustom2(null, Criteria::ISNOTNULL)
            ->filterByLastname('Farlocco%', Criteria::NOT_LIKE)
            ->find();
    }

    /**
     * @param Patron $patron
     * @throws Exception
     */
    private function anonimizePatron(Patron $patron)
    {
        try {
            $disabled_on = DateTime::createFromFormat($this->disabled_date_format, $patron->getCustom2());
            $today = DateTime::createFromFormat($this->disabled_date_format, date($this->disabled_date_format));
            $disabled_days = $disabled_on->diff($today)->days;
        } catch (Exception $e) {
            $this->logger->err("Error calculating anonymization date for user [" . $patron->getCardCode() . "]. " . $e->getMessage());
        }

        if ($disabled_on instanceof DateTime && $disabled_days >= 15 && $patron->getPatronStatus() != 'B') {
            $this->logger->log("Anonimizing patron [" . $patron->getCardCode() . "] -  [" . $patron->getOpacUsername() . "]");
            try {
                ContactQuery::create()
                    ->filterByPatron($patron)
                    ->delete();

            } catch (PropelException $e) {
                $this->logger->err("Error deleting contact for user [" . $patron->getCardCode() . "]. " . $e->getMessage());
            }
//          Do not anonymize patron properties as requested on 20210208
            try {
                $patron->setName('Anonimo');
                $patron->setLastname($today->format($this->disabled_date_format));
                $patron->setNationalId('');
                $patron->setBarcode('');
                $patron->setCardCode(null);
                $patron->setCardExpire(null);
                $patron->setOpacUsername($patron->getPatronId());
                $patron->setOpacSecret('');
                $patron->setOpacSecretExpire(new DateTime('now'));
                $patron->setOpacEnable(false);
                $patron->setSurfEnable(false);
                $patron->setCustom1('BB');

                $patron->setLoanClass("A");
                $patron->setPatronStatus("B");

                $patron->save();
            } catch (Exception $e) {
                $this->logger->err("Error anonimizing user [" . $patron->getCardCode() . "]. " . $e->getMessage());
            }
        }
    }

    /**
     * @param        $fin
     * @param string $status
     */
    private function processLoans($fin, $status = ''): void
    {
        $header = [
            'title',
            'patron',
            'modified_by',
            'loan_date',
            'due_date',
            'id',
            'loan_ends',
            'date_updated',
            'item_type',
            'path'
        ];

        $fakePatrons = $this->getFakePatronsForBogusLoans();

        $this->logger->info("Importing {$status} loans..");
        fgets($fin);  // read one line for nothing (skip header)

        while (($row = fgetcsv($fin, 0, ";", "\"", "\"")) !== false) {

            if (count($row) !== count($header))
                continue;

            try {
                $data = array_combine($header, $row);
                $imported_barcodes = [];
                $imported_loans[] = $this->importLoan($data, $status, $imported_barcodes, $fakePatrons);
            } catch (Exception $e) {
                $this->logger->err("Errore import loan {$data['id']} [{$e->getMessage()}]");
            }
        }
    }

    /**
     * @return array
     * @throws PropelException
     */
    private function getFakePatronsForBogusLoans()
    {
        // Creo un utente "farlocco" su cui attaccano i prestiti storici
        // e un utente "farlocco2 " su cui attaccare prestiti in corso
        // per utenti "sconosciuti".

        $p1_data = [
            'matricola' => 'FarloccoStorico',
            'cognome' => 'Farlocco',
            'nome' => 'Storico',
            'email' => 'FarloccoStorico',
            'numeroBadge1' => 'FarloccoStorico',
            'numeroBadge2' => 'FarloccoStorico',
            'centroDiCosto' => '',
            'managementLevel' => '',
            'teamLeader' => '',
            'teamLeaderEmail' => '',
            'tipo' => '',
            'fineAbilitazione' => '10/10/2500'
        ];

        $p2_data = [
            'matricola' => 'FarloccoInCorso',
            'cognome' => 'Farlocco',
            'nome' => 'In Corso',
            'email' => 'FarloccoInCorso',
            'numeroBadge1' => 'FarloccoInCorso',
            'numeroBadge2' => 'FarloccoInCorso',
            'centroDiCosto' => '',
            'managementLevel' => '',
            'teamLeader' => '',
            'teamLeaderEmail' => '',
            'tipo' => '',
            'fineAbilitazione' => '10/10/2500'
        ];

        $p1 = $this->importPatron($p1_data);
        $p2 = $this->importPatron($p2_data);

        return [
            'hp' => PatronQuery::create()->findOneByPatronId($p1['patronId']),
            'op' => PatronQuery::create()->findOneByPatronId($p2['patronId'])
        ];
    }

    /**
     * @param $l
     * @param $status
     * @return array
     */
    private function importLoan($l, $status, &$imported_barcodes, $fakePatrons)
    {
        // sto importando i prestiti storici e non ho una data di fine prestito (== prestito in corso), termino la procedura.
        if (($status == 'closed') && ($l['loan_ends'] ?? '') == '') {
            return [];
        }

        // sto importando i prestiti in corso ho una data di fine prestito (== prestito storico), termino la procedura.
        if (($status == 'open') && ($l['loan_ends'] ?? '') != '') {
            return [];
        }

        try {

            $bid = trim($l['id']);
            $patron_id = trim($l['patron']);

            if ($bid === '') {
                $this->logger->err("Skipping loan with empty bid for title {$l['title']} with patron {$patron_id} ..");
                return [];
            }

            $patron = PatronQuery::create()->findOneByOpacUsername($patron_id);
            if (!$patron instanceof Patron) {

                $patron = ($status === 'closed')
                    ? $fakePatrons['hp']
                    : $fakePatrons['op'];
            }

            $manifestation = ManifestationQuery::create()
                ->filterbyBid($bid)
                ->findOne();

            if (!$manifestation instanceof Manifestation) {
                $this->logger->err("No manifestation found for bid [{$bid}]");
                return [];
            }

            if ($status == 'closed') {
                $item = ItemQuery::create()
                    ->filterByManifestation($manifestation);
            } else {
                $item = ItemQuery::create()
                    ->filterByManifestation($manifestation)
                    ->filterByCurrentLoanId(null, Criteria::ISNULL);
            }

            if ($item->count() === 0) {
                $this->logger->err("No item found for bid [{$bid}]. Skipping loan import.");
                return [];
            }

            if ($item->count() > 1) {
                $this->logger->err("Multiple items found for bid [{$bid}].");
            }

            if ($status != 'closed' && isset($imported_barcodes[$bid]) && $imported_barcodes[$bid] != '') {
                $this->logger->err("An open loan already exists for barcode [{$bid}], current patron [{$l['patron']}].");
                return [];
            }

            $item = $item->findOne();
            if ($item instanceof Item && $patron instanceof Patron) {
                $this->logger->info("New loan for item with barcode: [{$item->getBarcode()}] - patron: [{$patron->getBarcode()}] - bid [{$bid}]");

                $loan = new Loan();
                $loan->setItemId($item->getItemId());

                $loan->setItemOwnerLibraryId($item->getOwnerLibraryId());
                $loan->setItemHomeLibraryId($item->getHomeLibraryId());

                $loan->setPatronId($patron->getPatronId());
                $loan->setExternalLibrary(null);

                $loan->setDestinationName($patron->getCompleteName());

                $loan->setTitle($l['title']);
                $loan->setManifestationId($item->getManifestationId());

                $loan->setInvNumber($item->getCompleteInventoryNumber());
                $loan->setCollocation($item->getCollocationCombo());
                $loan->setItemMedia($item->getItemMedia());
                $loan->setMediapackageSize(1);

                $loan->setNotifyAutoCount(0);
                $loan->setNotifyCount(0);
                $loan->setRenewCount(0);

                $loan->setLoanDateBegin($this->pwc2cngDate($l['loan_date']));
                $loan->setDueDate($this->pwc2cngDate($l['due_date']));

                $loan->setItemHomeLibraryId($item->getHomeLibraryId());
                $loan->setItemOwnerLibraryId($item->getOwnerLibraryId());

                $loan->setFromLibrary($item->getHomeLibraryId());
                $loan->setToLibrary($item->getHomeLibraryId());
                $loan->setLoanType(ItemPeer::LOANTYPE_LOCAL);
                $loan->setEndLibrary(null);

                if ($l['loan_ends'] != '') { // prestito concluso
                    $loan->setLoanDateEnd($this->pwc2cngDate($l['loan_ends']));
                    $loan->setLoanStatus(ItemPeer::LOANSTATUS_CLOSED);
                    $item->setLoanStatus(ItemPeer::LOANSTATUS_AVAILABLE);
                    $item->setPatron(null);
                    $item->setDueDate(null);
                    $item->setCurrentLoan(null);
                } else { // prestito in corso
                    $loan->setLoanDateEnd(null);
                    $loan->setLoanStatus(ItemPeer::LOANSTATUS_INLOAN);
                    $item->setLoanStatus(ItemPeer::LOANSTATUS_INLOAN);

                    $item->setPatron($patron);
                    $item->setDueDate($loan->getDueDate());
                    $loan->save();
                    $item->setCurrentLoan($loan);
                }

                $loan->save();
                $item->save();

                $imported_barcodes[$bid] = $l['patron'];
                return $imported_barcodes;
            }
        } catch (Exception $e) {
            $this->logger->err($e->getMessage());
        }
        return $l;
    }

    /**
     * @param $pwcDate
     * @return string
     */
    private function pwc2cngDate($pwcDate)
    {
        return DateTime::createFromFormat("m/d/Y", $pwcDate)->format("Y-m-d");
    }
}
