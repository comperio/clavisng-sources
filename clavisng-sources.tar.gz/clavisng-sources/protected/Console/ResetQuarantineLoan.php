<?php

require_once 'ClavisCommandLineAction.php';


class ClavisActionResetQuarantineLoan extends ClavisCommandLineAction
{
	/**
	 * @var string
	 */
	protected $action = 'reset_quarantine_loan';
	/**
	 * @var array
	 */
	protected $parameters = array();
	/**
	 * @var array
	 */
	protected $optional = array('--dryrun');
	/**
	 * @var string
	 */
	protected $description = 'Termina il prestito quarantena se la biblioteca ha configurato questo cpmportamento con il library_property AUTO_QUARANTINE_END';

	/** @var $logger Log */
	protected $logger;
	/**
	 * @var
	 */
	protected $config;
	/**
	 * @var
	 */
	protected $dryrun;

	const QuarantineString = "Quarantena_";

	public function performAction($args)
	{
		$params = $this->parseArgs($args);
		$this->dryrun = isset($params['dryrun']) ? true : false;

		$logname = $this->dryrun ? 'DRYRUN-NOTIFY' : 'NOTIFY';
		$this->logger = Log::factory('console', '', $logname);
		$this->logger->info('Starting reset_quarantine_loan script.');

		$today = new DateTime;
		
		$librariesProp = LibraryPropertyQuery::create()
			->filterByPropertyClass('L')
			->filterByPropertyValue('True')
			->find();
		foreach($librariesProp as $libraryProp) {
			$quarantineBarcode = self::QuarantineString.$libraryProp->getLibraryId();
			$quarantinePatronId = PatronQuery::create()
				->filterByBarcode($quarantineBarcode)
				->findOne()
				->getPatronId();
			$loans = LoanQuery::create()
				->filterByLoanStatus('B')
				->filterByPatronID($quarantinePatronId)
				->filterByDueDate(array('max' => $today->format('Y-m-d h:i:s')))
				->find();
			foreach ($loans as $loan)
				$this->resetLoan($loan);
		}

		$this->logger->info('Finishing reset_quarantine_loan script.');

		return true;
	}

	private function resetLoan ($loan)
	{
		$this->logger->info("Reset loan: {$loan->getLoanId()}");
		$loan->setLoanStatus('G');
		$loan->setLoanDateEnd(time());
		$this->dryrun || $loan->save();

		$item = ItemQuery::create()
			->filterByItemId($loan->getItemId())
			->findOne();

		$tipoRientro = $item->getActualLibraryId() == $item->getHomeLibraryId() ? 'G' : 'J';
		$item->setItemStatus('F');
		$item->setCurrentLoanId(null);
		$item->setLastSeen(time());
		$item->setLoanStatus($tipoRientro);
		$item->setDueDate(null);
		$item->setPatronId(null);
		$item->setCheckIn(time());
		$item->setDateUpdated(time());
		$item->setModifiedBy(1);
		$this->dryrun || $item->save();

		$itemAction = new ItemAction();
		$itemAction->setLibraryId($item->getActualLibraryId());
		$itemAction->setItemId($item->getItemId());
		$itemAction->setPatronId($loan->getPatronId());
		$itemAction->setLibrarianId(1);
		$itemAction->setActionType('B');
		$itemAction->setActionDate(time());
		$itemAction->setActionNote('Rientro automatico da quarantena');
		$itemAction->setDateCreated(time());
		$itemAction->setDateUpdated(time());
		$itemAction->setCreatedBy(1);
		$itemAction->setModifiedBy(1);
		$this->dryrun || $itemAction->save();

		if ($tipoRientro == 'J') {
			$itemActionRientro = new ItemAction();
			$itemActionRientro->setLibraryId($item->getActualLibraryId());
			$itemActionRientro->setItemId($item->getItemId());
			$itemActionRientro->setLibrarianId(1);
			$itemActionRientro->setActionType('E');
			$itemActionRientro->setActionDate(time());
			$itemActionRientro->setFromLibraryId($loan->getFromLibrary());
			$itemActionRientro->setToLibraryId($loan->getToLibrary());
			$itemActionRientro->setDateCreated(time());
			$itemActionRientro->setDateUpdated(time());
			$itemActionRientro->setCreatedBy(1);
			$itemActionRientro->setModifiedBy(1);
			$this->dryrun || $itemActionRientro->save();
		}

	}
}

