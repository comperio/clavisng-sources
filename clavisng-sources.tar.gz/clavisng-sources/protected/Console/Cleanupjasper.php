<?php

/**
 *
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.7
 * @package Console
 * @since 2.5.0
 */

require_once('ClavisCommandLineAction.php');

/**
 * @package Console
 * @since 2.5.0
 */
class ClavisActionCleanupjasper extends ClavisCommandLineAction
{
	protected $action = 'cleanupjasper';
	protected $parameters = array();
	protected $optional = array();
	protected $description = 'Deletes only the .jasper files related to the .jrxml files modified within the last commit.';

	public function performAction($args)
	{
		global $basePath, $SITEPATH;

		$jasperDir = "$SITEPATH/storage/report/jasper";
		exec("cd $jasperDir; git diff --name-only HEAD HEAD~1", $output);
		$list = implode(' ',$output);
		
		$match = array();
		preg_match_all("/\b[^\s]+\.jrxml\b/m", $list, $match);

		$resultArray = array();
		foreach($match[0] as $i => $m)
			$resultArray[$i] = preg_replace("/(jrxml)/m", "jasper", $m);

		$resultString = implode(" ", $resultArray);
		
		if ($resultString != "")
		{
			$command = "cd $jasperDir; rm -f $resultString";
			exec($command);
			
			echo "\n#### Deleted: $resultString ####\n";
		}
		else
		{
			echo "\n#### No need to delete .jasper files ####\n";
		}
		
		return true;
	}
}
