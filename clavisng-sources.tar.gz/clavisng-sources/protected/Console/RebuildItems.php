<?php

/**
 *
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Console
 * @since 2.5.0
 */

require_once('ClavisCommandLineAction.php');

/**
 * @package Console
 * @since 2.5.0
 */
class ClavisActionRebuildItems extends ClavisCommandLineAction
{
	protected $action = 'rebuild_items';
	protected $parameters = array('full|chars|item_media');
	protected $optional = array('force');
	protected $description = 'Checks items for inconsistencies, and correct them, rebuilding all external references. Also rebuilds item_media, specify the function you want by the mandatory parameter. Please be warned that is a VERY time-consuming task.';

	public function performAction($args)
	{
		$force = isset($args[2]) && 'force' == $args[2];

		$conn = Propel::getConnection();

		if ($args[1] == 'full' || $args[1] == 'item_media') {
			$records = $conn->query('SELECT '.ManifestationPeer::MANIFESTATION_ID.','
				.ManifestationPeer::BIB_LEVEL.','.ManifestationPeer::BIB_TYPE
				.' FROM '.ManifestationPeer::TABLE_NAME);
			$update_items = $conn->prepare('UPDATE '.ItemPeer::TABLE_NAME.' SET '.
				ItemPeer::ITEM_MEDIA.' = ? WHERE '.ItemPeer::MANIFESTATION_ID.' = ?');
			while ($man = $records->fetch(PDO::FETCH_ASSOC)) {
				$media = $man['bib_level'] == ManifestationPeer::LVL_SERIAL ?
					'S' : Clavis::BibtypeToItemmedia($man['bib_type']);
				$update_items->execute(array($media,$man['manifestation_id']));
			}
		}

		$items = ItemQuery::create()
			->setFormatter(ModelCriteria::FORMAT_ON_DEMAND)
			->find();

		$counter = 0;
		foreach ($items as $i) {
			/* @var $i Item */
			if ((++$counter % 10000) == 0)
					echo "\n{$counter} items processed! ".date('Y-m-d H:i:s');
			if ($args[1] == 'full' || $args[1] == 'chars')
				$this->sanitizeChars($i,$force);
		}

		$counter = 0;
		print "\nCHECKING ITEM NOTES...";
		foreach (ItemNoteQuery::create()
				->setFormatter(ModelCriteria::FORMAT_ON_DEMAND)
				->find() as $i) {
			/* @var $i ItemNote */
			if ((++$counter % 10000) == 0)
					echo "\n{$counter} item notes processed! ".date('Y-m-d H:i:s');
			if (!trim($i->getNote())) {
				print "\nDeleting empty item note {$i->getNoteId()}...";
				$i->delete();
			}
			if ($i->getNote() != Clavis::sanitizeForXML($i->getNote())) {
				$i->setNote(Clavis::sanitizeForXML($i->getNote()));
				print "\nUpdating incorrect item note {$i->getNoteId()}...";
				$i->save();
			}
		}

		echo "\n#### ALL DONE!!! ####\n";
		return true;
	}

	public function sanitizeChars(Item $i, $forceResave=false)
	{
		if ($forceResave || $i->getCollocationCombo() != Clavis::sanitizeForXML($i->getCollocationCombo())) {
			$i->setCollocation(Clavis::sanitizeForXML($i->getCollocation()));
			$i->setSpecification(Clavis::sanitizeForXML($i->getSpecification()));
			$i->setSequence1(Clavis::sanitizeForXML($i->getSequence1()));
			$i->setSequence2(Clavis::sanitizeForXML($i->getSequence2()));
			$i->setManifestationDewey(Clavis::sanitizeForXML($i->getManifestationDewey()));
		}
		if ($forceResave || $i->isModified()) {
			print "\nUpdating incorrect item {$i->getItemId()}...";
			$i->save();
			LoanQuery::create()
				->filterByItemRelatedByItemId($i)
				->update(array(
					'Title' => $i->getCompleteTitle(),
					'Collocation' => $i->getCollocation(),
					'ItemMedia'	=> $i->getItemMedia(),
					'ClassCode' => $i->getManifestationDewey()));
		}
	}
}
