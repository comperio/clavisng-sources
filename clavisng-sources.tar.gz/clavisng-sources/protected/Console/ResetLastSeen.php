<?php

/**
 * @author Marco Brancalion <mbrancalion@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2011 Comperio SRL
 * @license http://www.comperio.it/license/
 * @version 2.7
 * @package Console
 * @since 2.5.0
 */

require_once('ClavisCommandLineAction.php');

/**
 * @package Console
 * @since 2.5.0
 */
class ClavisActionResetLastSeen extends ClavisCommandLineAction
{
	protected $action = 'reset_last_seen';
	protected $parameters = array('item | patron');
	protected $optional = array();
	protected $description = 'It resets the `last_seen` field to NULL in the table `patron` or `item`. The parameter describes the name of the table, and is mandatory.';

	public function performAction($args)
	{
		if (count($args) > 1)  // if parameters exist
		{
			$table = strtolower($args[1]);
			switch ($table)
			{
				case "item":
					$objQuery = ItemQuery::create();
					$field = "LastSeen";
					$table = "Item";
					break;

				case "patron":
					$objQuery = PatronQuery::create();
					$field = "LastSeen";
					$table = "Patron";
					break;

				default:
					$objQuery = null;
					$field = null;
			}

			if (is_null($objQuery))
				$this->echon("** Table `$table` not valid.", true);
		}
		else   // no parameter
			$this->echon("** No table. Please specify " . $this->parameters[0], true);

		// paranoic assertive user input
		$this->echon("Are you sure you want to reset `$table.$field` to NULL ?  Type 'yes' to continue: ");
		$handle = fopen ("php://stdin","r");
		$line = fgets($handle);
		if (trim($line) != 'yes')
			$this->echon("ABORTING !", true);

		// everythink ok. Go on
		$this->echon("Performing action");

		$resultNum = $objQuery
					->where("$table.$field IS NOT NULL")
					->update(array($field => NULL));

		if ($resultNum > 0)
			$this->echon(" -> $resultNum objects reset. Done.", true);
		else
			$this->echon(" ** No object reset. Done.", true);

		echo "\n#### ALL DONE!!! ####\n";
		return true;
	}

	/**
	 * @param string $param : the text to be shown
	 * @param boolean $dieFlag  : do we have to exit, after printing ? [false]
	 */
	private function echon($param = null, $dieFlag = false)
	{
		if ($param !== "")
			echo "\n$param\n\n";

		if ($dieFlag)
			die();
	}

}