<?php


// run every x minutes by chron
// */x * * * * /var/www/html/clavisng/clavis-cli all get_counters_data >> /var/log/clavis.log 2>&1
 /*
 * @author Cristian <ciarez@comperio.it>
 * @version 2.8.2
 * @package Console
 * @since 2.8.2
 */

require_once('ClavisCommandLineAction.php');

/**
 * @package Console
 * @since 2.8.2
 */
class ClavisActionRunKpiQueries extends ClavisCommandLineAction
{
	protected $action = 'run_kpi_queries';
	protected $parameters = array();
	protected $optional = array();
	protected $description = 'Run queries in kpi_query.';


	public function performAction($args)
	{
		try
		{
			$phpmaj = explode('.',phpversion())[0];
			if($phpmaj != 7)
			{
				echo "Sorry php 7+ is required for cron spec parsing\n";
				return FALSE;
			}
			
			$conn = Propel::getConnection();
			
			$stmt = $conn->prepare("SELECT * FROM kpi_query WHERE next_exec_time IS NULL OR next_exec_time <= NOW()");
			$stmt->execute();
			$queries = $stmt->fetchAll(PDO::FETCH_ASSOC);
			$qCount = count($queries);
			echo("{$qCount} queries to exec\n");
		} catch (Exception $ex) {
			echo __METHOD__ . " EXCEPTION: " . $ex->getMessage();
			return FALSE;
		}
			
		
		echo("***\n");
		foreach($queries as $kpiquery)
		{
			try
			{
				//WARNING: sql MUST return `id_date` `library_id`  `value` fields!
				//echo("Executing ***\n{$kpiquery['sql']}\n***\n");
				echo("Executing query n. {$kpiquery['query_id']}\n");
				$stmt = $conn->prepare($kpiquery['sql']);
				$stmt->execute();
				$kpis = $stmt->fetchAll(PDO::FETCH_ASSOC);
				$nKpi = count($kpis);
				if($nKpi > 0)
				{
					if( isset($kpis[0]['id_date']) && isset($kpis[0]['library_id']) && isset($kpis[0]['value']) )
					{
						echo("Query have  {$nKpi} values\n");
						foreach($kpis as $kpi)
						{
							if(is_numeric($kpi['value']))
							{
								$kpireplace = 'REPLACE INTO kpi_value (id_date, master_key, slave_key, library_id, num_val, txt_val) VALUES (?,?,?,?,?,NULL)';
							}
							else
							{
								$kpireplace = 'REPLACE INTO kpi_value (id_date, master_key, slave_key, library_id, num_val, txt_val) VALUES (?,?,?,?,NULL,?)';
							}
							$stmt = $conn->prepare($kpireplace);
							$stmt->execute(array($kpi['id_date'], $kpiquery['master_key'], $kpiquery['slave_key'], $kpi['library_id'], $kpi['value']));
						}
						echo("query done.\n");
						$cron = Cron\CronExpression::factory($kpiquery['cron_exp']);
						$crontime=$cron->getNextRunDate();
						$stmt = $conn->prepare('UPDATE kpi_query SET next_exec_time=:crontime WHERE query_id=:qid');
						$stmt->execute(array(':crontime' => $crontime->format('Y-m-d H:i:s'), ':qid' =>$kpiquery['query_id']));
						echo("Query next execution time: {$crontime->format('d-m-Y H:i:s')}\n");
					}
					else
					{
						echo("Sorry wrong query fields returned. id_date, library_id, value is needed\n");
					}
				}
			} catch (Exception $ex) {
				echo __METHOD__ . " EXCEPTION executing query id {$kpiquery['query_id']}: " . $ex->getMessage();
				echo("\nSQL:\n[{$kpiquery['sql']}]\n");
				//return FALSE;
			}
			echo("***\n");
		}
		echo("Done.\n");
		return TRUE;
	}
}