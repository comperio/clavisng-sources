<?php
/**
 * ClavisActionCacheTmarc class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Console
 */
require_once('ClavisCommandLineAction.php');

/**
 * ClavisActionCacheTmarc Class
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Console
 * @since 2.5.0
 */
class ClavisActionCacheTmarc extends ClavisCommandLineAction
{
	protected $action = 'cache_tmarc';
	protected $parameters = array('dirty|full|authority|manifestation|fixtable');
	protected $optional = array('<manifestation_id> | a<authority_id> | s<shelfId> | d<date> | <force>');
	protected $description = 'Caches turbomarc for manifestations and authorities. Specify either \'dirty\' to recache only dirty and new manifestations and authorities, \'manifestation\', \'authority\' or \'full\' to recache all manifestations, authorities or both, respectively; \'fixtable\' to check and rebuild incoherent turbomarc_cache table. Use optional argument to search for specific manifestations: [<manifestation id>] to index a single manifestation, [a<authority_id>] to index a single authority, [s<shelfId>] to take all manifestations or authorities contained in a shelf, [date] to index all manifestations updated after a certain date. \'force\' may be specified as second parameter within \'fixtable\' action.';

	private $_connection;
	public $counter = 0;
	public $timings = array();

	const STOPFILE = 'do_not_index';
	const LOCKFILE = 'cache.lock';

	public function performAction($args)
	{
		if ('fixtable' == $args[1]) {
			$force = (count($args) > 2 && 'force' == $args[2]);
			echo "\nFixing turbomarc_cache and turbomarcauthority_cache table...";
			$this->rebuildCacheTable($force);
			echo "\n#### ALL DONE!!! ####\n";
			return true;
		}

		$onlyDirty = ($args[1] == 'dirty');

		$tmpdir = Prado::getPathOfNamespace('Storage.temp');
		if (file_exists($tmpdir.'/'.self::STOPFILE)) {
			echo "\nStopfile exists, won't cache!\n";
			return true;
		}
		echo "\nCreating index stopfile...";
		touch($tmpdir.'/'.self::STOPFILE);
		echo "acquiring lock on caching...";
		$fp = fopen($tmpdir.'/'.self::LOCKFILE, 'w');
		if (!flock($fp, LOCK_EX | LOCK_NB)) {
			echo "\nCaching is locked, exiting!\n";
			return true;
		}
		echo "locked!";

		$this->_connection = Propel::getConnection();

		$do_cache_manif = true;
		$do_cache_auth = true;
		switch($args[1]) {
			case 'authority':
				$do_cache_manif = false;
				break;
			case 'manifestation':
				$do_cache_auth = false;
				break;
		}
		// first, get all already indexed manifestations
		$manif_caches = 'SELECT '.TurbomarcCachePeer::MANIFESTATION_ID.
			' FROM '.TurbomarcCachePeer::TABLE_NAME;
		$auth_caches = 'SELECT '.TurbomarcauthorityCachePeer::AUTHORITY_ID.
			' FROM '.TurbomarcauthorityCachePeer::TABLE_NAME;
		$params = array();
		if (count($args) > 2) {
			// if argument is an integer, take it as ManifestationId; elsewhere, try to convert to date.
			if (is_numeric($args[2])) {
				$manif_caches .= ' WHERE '.TurbomarcCachePeer::MANIFESTATION_ID.' = ?';
				$params = array(intval($args[2]));
				$do_cache_auth = false;
			} else if ($args[2]{0} == 'a') {
				$auth_caches .= ' WHERE '.TurbomarcauthorityCachePeer::AUTHORITY_ID.' = ?';
				$params = array(intval(substr($args[2],1)));
				$do_cache_manif = false;
			} else if ($args[2]{0} == 's') {
				// if argument begins with a 's' user wants to index a shelf
				$shelf_type = $this->_connection->query('SELECT '.ShelfPeer::SHELF_ITEMTYPE.' FROM '.
					ShelfPeer::TABLE_NAME.' WHERE '.ShelfPeer::SHELF_ID.' = '.intval(substr($args[2],1)))->fetchColumn();
				if (!in_array($shelf_type,array(ShelfPeer::TYPE_AUTHORITY,ShelfPeer::TYPE_MANIFESTATION))) {
					echo "\nShelf has no singe item type, cowardly refusing to index it!\n";
					return false;
				}
				switch ($shelf_type) {
					case ShelfPeer::TYPE_MANIFESTATION:
						$manif_caches .= ' WHERE '.TurbomarcCachePeer::MANIFESTATION_ID.' IN (SELECT '.
							ShelfItemPeer::OBJECT_ID.' FROM '.ShelfItemPeer::TABLE_NAME.
							' WHERE '.ShelfItemPeer::SHELF_ID.' = ? AND '.ShelfItemPeer::OBJECT_CLASS.' = ?)';
						$params = array(intval(substr($args[2],1)), ShelfPeer::TYPE_MANIFESTATION);
						$do_cache_auth = false;
						break;
					case ShelfPeer::TYPE_AUTHORITY:
						$auth_caches .= ' WHERE '.TurbomarcauthorityCachePeer::AUTHORITY_ID.' IN (SELECT '.
							ShelfItemPeer::OBJECT_ID.' FROM '.ShelfItemPeer::TABLE_NAME.
							' WHERE '.ShelfItemPeer::SHELF_ID.' = ? AND '.ShelfItemPeer::OBJECT_CLASS.' = ?)';
						$params = array(intval(substr($args[2],1)), ShelfPeer::TYPE_AUTHORITY);
						$do_cache_manif = false;
						break;
				}
			} else if ($args[2]{0} == 'd') {
				$date = new DateTime(substr($args[2],1));
				$manif_caches .= ' LEFT JOIN '.ManifestationPeer::TABLE_NAME.' ON '.
					TurbomarcCachePeer::MANIFESTATION_ID.'='.ManifestationPeer::MANIFESTATION_ID.
					' WHERE '.ManifestationPeer::DATE_UPDATED.' >= ?';
				$params = array($date->format('Y-m-d H:i:s'));
				$do_cache_auth = false;
			}
		}
		if ($onlyDirty) {
			$manif_caches .= (strpos($manif_caches, 'WHERE') === false) ? ' WHERE ' : ' AND ';
			$manif_caches .= TurbomarcCachePeer::DIRTY.' = 1';
			$auth_caches .= (strpos($auth_caches, 'WHERE') === false) ? ' WHERE ' : ' AND ';
			$auth_caches .= TurbomarcauthorityCachePeer::DIRTY.' = 1';
		}

        if ($do_cache_auth)
            $this->cacheAuthorities($onlyDirty, $auth_caches, $params);

		if ($do_cache_manif)
			$this->cacheManifestations($onlyDirty, $manif_caches, $params);

		// release lock
		flock($fp, LOCK_UN);
		fclose($fp);

		// ALL DONE, OUTPUT STATISTICS
		$count = count($this->timings);
		if ($count > 0) {
			$total = array_sum($this->timings);
			$avg = $total / $count;
			sort($this->timings);
			$middleval = floor(($count-1)/2);
			if ($count % 2) {
				$median = $this->timings[$middleval];
			} else {
				$low = $this->timings[$middleval];
				$high = $this->timings[$middleval+1];
				$median = (($low+$high)/2);
			}
			echo "\n\n".__CLASS__." STATISTICS (actually processed):\n".
				"Record count: {$count}\nTotal time spent: {$total}\n".
				"Average time for record: {$avg}\nMedian time: {$median}\n";
		} else {
			echo "\n\nNo record processed!\n";
		}
		echo "\nFreeing indexer...";
		unlink($tmpdir.'/'.self::STOPFILE);
		echo "\n#### ALL DONE!!! ####\n";
		return true;
	}

	public function cacheManifestations($onlyDirty,$cacheQuery,$queryParams=array())
	{
		if (!$this->_connection)
			$this->_connection = Propel::getConnection();
		$this->counter = 0;
		$stmtCaches = $this->_connection->prepare($cacheQuery);
		$stmtCaches->execute($queryParams);
		while ($cache = $stmtCaches->fetch(PDO::FETCH_ASSOC)) {
			try {
				if ((++$this->counter % 10000) == 0)
					echo "\n{$this->counter} manifestations processed! ".date('Y-m-d H:i:s');
				$mt = microtime(true);
				if ($onlyDirty && $cache['dirty'] == 0)
					continue;
				ManifestationPeer::cacheTurboMarc($cache['manifestation_id'],$onlyDirty);
				$this->timings[] = microtime(true) - $mt;
			} catch (Exception $e) {
				echo "\n!!!! SOMETHING WENT WRONG with manifestation [{$cache['manifestation_id']}], please check your logs.\n".
					"Exception throwed is [{$e->getCode()}] {$e->getMessage()}.\n";
				continue;
			}
		}
	}

	public function cacheAuthorities($onlyDirty,$cacheQuery,$queryParams=array())
	{
		if (!$this->_connection)
			$this->_connection = Propel::getConnection();
		$this->counter = 0;
		$stmtCaches = $this->_connection->prepare($cacheQuery);
		$stmtCaches->execute($queryParams);
		while ($cache = $stmtCaches->fetch(PDO::FETCH_ASSOC)) {
			try {
				if ((++$this->counter % 10000) == 0)
					echo "\n{$this->counter} authorities processed! ".date('Y-m-d H:i:s');
				$mt = microtime(true);
				if ($onlyDirty && $cache['dirty'] == 0)
					continue;
				AuthorityPeer::cacheTurboMarc($cache['authority_id'],$onlyDirty);
				$this->timings[] = microtime(true) - $mt;
			} catch (Exception $e) {
				echo "\n!!!! SOMETHING WENT WRONG with authority [{$cache['authority_id']}], please check your logs.\n".
					"Exception throwed is [{$e->getCode()}] {$e->getMessage()}.\n";
				continue;
			}
		}
	}

	public function rebuildCacheTable($force=false)
	{
		if (!$this->_connection)
			$this->_connection = Propel::getConnection();

		if ($force) {
			// check for consistency
			echo "\nConsistency check, this could take some time if you have a lot of records. Please wait...";
			$sql = 'INSERT INTO '.TurbomarcCachePeer::TABLE_NAME.' ('.TurbomarcCachePeer::MANIFESTATION_ID.','
				.TurbomarcCachePeer::TURBOMARC.','.TurbomarcCachePeer::DIRTY.','.TurbomarcCachePeer::INDEXED.','
				.TurbomarcCachePeer::DELETED.') '
				.'SELECT '.ManifestationPeer::MANIFESTATION_ID.',null,1,0,null FROM '.ManifestationPeer::TABLE_NAME
				.' WHERE '.ManifestationPeer::MANIFESTATION_ID.' NOT IN (SELECT '
				.TurbomarcCachePeer::MANIFESTATION_ID.' FROM '.TurbomarcCachePeer::TABLE_NAME.')';
			$this->_connection->exec($sql);
			$sql = 'INSERT INTO '.TurbomarcauthorityCachePeer::TABLE_NAME.' ('.TurbomarcauthorityCachePeer::AUTHORITY_ID
				.','.TurbomarcauthorityCachePeer::TURBOMARC.','.TurbomarcauthorityCachePeer::DIRTY.','.
				TurbomarcauthorityCachePeer::INDEXED.','.TurbomarcauthorityCachePeer::DELETED.') '
				.'SELECT '.AuthorityPeer::AUTHORITY_ID.',null,1,0,null FROM '.AuthorityPeer::TABLE_NAME
				.' WHERE '.AuthorityPeer::AUTHORITY_ID.' NOT IN (SELECT '
				.TurbomarcauthorityCachePeer::AUTHORITY_ID.' FROM '.TurbomarcauthorityCachePeer::TABLE_NAME.')';
			$this->_connection->exec($sql);
		}

		// dirty caches
		echo "\nInvalidating caches and nullifing turbomarc fields...";
		$sql = 'UPDATE '.TurbomarcCachePeer::TABLE_NAME.' SET '
			.TurbomarcCachePeer::TURBOMARC.'=NULL,'
			.TurbomarcCachePeer::DIRTY.'=1,'
			.TurbomarcCachePeer::INDEXED.'=0 ';
		if (!$force)
			$sql .= 'WHERE '.TurbomarcCachePeer::TURBOMARC.' IS NULL OR '
				.TurbomarcCachePeer::TURBOMARC.'=\'\'';
		$this->_connection->exec($sql);
		$sql = 'UPDATE '.TurbomarcauthorityCachePeer::TABLE_NAME.' SET '
			.TurbomarcauthorityCachePeer::TURBOMARC.'=NULL,'
			.TurbomarcauthorityCachePeer::DIRTY.'=1,'
			.TurbomarcauthorityCachePeer::INDEXED.'=0 ';
		if (!$force)
			$sql .= 'WHERE '.TurbomarcauthorityCachePeer::TURBOMARC.' IS NULL OR '
				.TurbomarcauthorityCachePeer::TURBOMARC.'=\'\'';
		$this->_connection->exec($sql);
	}
}
