<?php

/**
 *
 *
 * @author Ciro Mattia Gonano
 * @version 2.7
 * @package Console
 * @since 2.5.0
 */

require_once('ClavisCommandLineAction.php');

/**
 * @package Console
 * @since 2.5.0
 */
class ClavisActionTest extends ClavisCommandLineAction
{
	protected $action = 'test';
	protected $parameters = array();
	protected $optional = array();
	protected $description = 'Test action';

	public function performAction($args)
	{
	    $res = [];

	    //$res = $this->getAuthority(3085,['54'],['P']);
     //   $res = $this->getAuthority(315967,['AB','CD','EF','KL','MN','OP','PK','GH','IJ'],['P','A','C','E','L','T','O']);
        $res = $this->getManifestationGraph(286562,['410','461','500','606','676','610','700','701','702'],['AB','CD','EF','KL','MN','OP','PK','GH','IJ','54'],['P','A','C','E','L','T','O']);
        print_r($res);
        $this->visitGraph($res,'Manifestation');

		return true;
	}

    function getManifestationGraph($mid, $manLinkType = [], $authLinkType = [], $authType = [])
    {
        $res = false;

        $man = ManifestationQuery::create()->findPk($mid);
        if($man instanceof Manifestation) {
            $res = $man->toArray();
            $res['LManifestation']=[];
            $res['LAuthorityManifestation']=[];

            $lms = array_merge(
                $man->getLManifestationsRelatedByManifestationIdUp()->getData(),
                $man->getLManifestationsRelatedByManifestationIdDown()->getData());

            /**@var $lam LManifestation */
            foreach ($lms as $lm) {
                $lmarr = $lm->toArray();
                if($lmarr['ManifestationIdDown'] == $man->getManifestationId()) {
                    $lmarr['LinkType'] = TurboMarcMappings::$reverseLinkType[$lmarr['LinkType']];
                    $lmarr['ManifestationIdUp'] = $lmarr['ManifestationIdDown'];
                    $lmarr['ManifestationIdDown'] = $man->getManifestationId();
                    $m2 = $lm->getManifestationRelatedByManifestationIdUp();
                } else {
                    $m2 = $lm->getManifestationRelatedByManifestationIdDown();
                }

                if(in_array($lmarr['LinkType'],$manLinkType)) {
                    $m2res = $this->getManifestationGraph($m2->getManifestationId(),['702','701','700'],['54'],['E','P']);
                    if($m2res !== false) {
                        $lmarr['Manifestation'] = $m2res;
                    }
                    $res['LManifestation'][] = $lmarr;
                }
            }

            $lams = $man->getLAuthorityManifestationsJoinAuthority();

            foreach ($lams as $lam) {

                $a = $lam->getAuthority();

                print("LAM {$lam->getLinkType()} {$a->getAuthorityType()}\n");

                if(in_array($a->getAuthorityType(),$authType) && in_array($lam->getLinkType(),$manLinkType) ) {
                    $lamarr = $lam->toArray();

                    $lamarr['Authority'] = $this->getAuthorityGraph($a->getAuthorityId(),$authLinkType,$authType);

                    $res['LAuthorityManifestation'][] = $lamarr;
                }
            }


        }

        return $res;
    }

    /**
     * @param $aid int AuthorityId
     * @param array $includeLinkType List of LinkType to Include default empty array
     * @param array $includeType List of Authority Type to Include default empty array
     * @return array JSON Encoded Authority and LAuthority list of Links
     * @throws PropelException
     */
    function getAuthorityGraph($aid, $includeLinkType = [], $includeType = [] )
    {
        $res = false;
        $au = AuthorityQuery::create()->findPk($aid);

        if($au instanceof Authority) {
            $res = $au->toArray();
            $res['LAuthority']=[];

            $lauths = array_merge($au->getLAuthoritysRelatedByAuthorityIdUp()->getData(),$au->getLAuthoritysRelatedByAuthorityIdDown()->getData());
            foreach ($lauths as $lauth) {

                $larr = $lauth->toArray();

                if ($larr['AuthorityIdUp'] == $au->getAuthorityId()) {
                    $larr['LinkType'] = strrev($larr['LinkType']);
                    $larr['AuthorityIdUp'] = $larr['AuthorityIdDown'];
                    $larr['AuthorityIdDown'] = $au->getAuthorityId();

                    $aulnk = $lauth->getAuthorityRelatedByAuthorityIdDown();
                } else {
                    $aulnk = $lauth->getAuthorityRelatedByAuthorityIdUp();
                }

                print "{$larr['LinkType']} - {$aulnk->getAuthorityType()}\n";

                if(in_array($larr['LinkType'],$includeLinkType)
                    && in_array($aulnk->getAuthorityType(),$includeType)) {
                   // $aul = $aulnk->toArray();
                    $aul = $this->getAuthorityGraph($aulnk->getAuthorityId(),$includeLinkType,$includeType);
                    $larr['Authority'] = $aul;

                    $res['LAuthority'][] = $larr;
                }

            }
        }

        return $res;
    }


    function visitGraph($res,$mode="Manifestation",$level = 0) {
        static $visitStack = [];



        switch($mode) {
            case "Manifestation":
                if(isset($res['LManifestation']))
                    foreach ($res['LManifestation'] as $l ) $this->visitGraph($l,'LManifestation',$level+1);
                if(isset($res['LAuthorityManifestation']))
                    foreach ($res['LAuthorityManifestation'] as $l ) $this->visitGraph($l,'LAuthorityManifestation',$level+1);
                break;
            case "LManifestation":
                if(isset($res['Manifestation']))
                    $this->visitGraph($res['Manifestation'],'Manifestation',$level +1);
                break;
            case "LAuthorityManifestation":
                if(isset($res['Authority']))
                    $this->visitGraph($res['Authority'],'Authority',$level +1);
                break;
            case "LAuthority":
                if(isset($res['Authority']))
                    $this->visitGraph($res['Authority'],'Authority',$level +1);
                break;
            case "Authority":
                if(isset($res['LAuthority']))
                    foreach ($res['LAuthority'] as $l ) $this->visitGraph($l,'LAuthority',$level+1);
                break;
            default:

                break;

        }

        $this->printNode($res,$mode,$level);

    }

    function printNode($res,$mode,$level = 0) {
        print str_repeat("   ",$level);
        switch($mode) {
            case "Manifestation":
                print "MAN {$res['Title']}\n";
                break;
            case "LManifestation":
                print "LM {$res['LinkType']} \n";
                break;
            case "LAuthorityManifestation":
                print "LAM {$res['LinkType']} \n";
                break;
            case "LAuthority":
                print "LA {$res['LinkType']} \n";
                break;
            case "Authority":
                print "AUTH[{$res['AuthorityType']}] {$res['FullText']} \n";
                $a = new Authority();
                $a->fromArray($res);
                $a->setAuthorityId(23);
                $a->setNew(false);

                $a->save();
                break;
            default:
                print ">>>>>>>>DEFAULT<<<<<<<<<<<\n";
                break;

        }
    }
}