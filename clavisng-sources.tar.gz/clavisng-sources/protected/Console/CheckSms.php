<?php

/**
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Console
 * @since 2.5.0
 */

require_once('ClavisCommandLineAction.php');

/**
 * @package Console
 * @since 2.5.0
 */
class ClavisActionCheckSms extends ClavisCommandLineAction
{
	protected $action = 'check_sms';
	protected $parameters = array();
	protected $optional = array();
	protected $description = 'Checks all SMS notification without an acknowledge date.';

	public function performAction($args)
	{
		echo "\nStarting...";
		$smsmodule = Prado::getApplication()->getModule('sms');
                $smsmodule->checkStatus();
                /*
		$n = NotificationQuery::create()
			->filterByNotificationChannel(NotificationPeer::CHANNEL_SMS)
			->filterByAcknowledgeDate(null)
			->find();
		foreach ($n as $notification) {
			$notes = unserialize($notification->getNotes());
			if (is_array($notes) && array_key_exists('smsid',$notes)) {
				$response = $smsmodule->checkStatus($notes['smsid']);
				if ($response) {
					echo "\nAcknowledging SMS [{$notes['smsid']}] ID: {$notification->getNotificationId()}";
					$notification->setDeliveryDate($response['sent']);
					$notification->setAcknowledgeDate($response['recv']);
					$notification->save();
				}
			}
		}
                */

		echo "\n#### ALL DONE!!! ####\n";
		return true;
	}

}