<?php

/**
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.8.4
 * @package Console
 * @since 2.5.0
 */

require_once('ClavisCommandLineAction.php');

/**
 * @package Console
 * @since 2.5.0
 */
class ClavisActionCheckNullManifestations extends ClavisCommandLineAction
{
	protected $action = 'check_nullmanifestations';
	protected $parameters = array();
	protected $optional = array();
	protected $description = 'Checks all manifestation where manifestation_status is null (and no other linked objects) and deletes them.';

	public function performAction($args)
	{
		Prado::log(	"\nStarting...",
					TLogger::INFO,
					"Batch");

		$manifestations = ManifestationQuery::create()
								->filterByManifestationStatus(null)
								->find();
			
		Prado::log(	"number of candidate manifestations to delete: " . count($manifestations) . "\n---------------\n\n",
					TLogger::INFO,
					"Batch");
		
		foreach ($manifestations as $manifestation)
		{
			/* @var $manifestation Manifestation */
			
			$ok = true;
			$existingCauses = array();
			
			if ($manifestation->countItems() > 0)
			{
				$ok = false;
				$existingCauses[] = "linked items";
			}
				
			if ($manifestation->getIssues()->count() > 0)
			{
				$ok = false;
				$existingCauses[] = "linked issues";
			}

			if ($manifestation->getLoans()->count() > 0)
			{
				$ok = false;
				$existingCauses[] = "linked loans";
			}

			if ($manifestation->getLAuthorityManifestations()->count())
			{
				$ok = false;
				$existingCauses[] = "linked authorities";
			}

			if ($manifestation->getLManifestationsRelatedByManifestationIdDown()->count() > 0)
			{
				$ok = false;
				$existingCauses[] = "linked lower manifestations";
			}

			if ($manifestation->getLManifestationsRelatedByManifestationIdUp()->count() > 0)
			{
				$ok = false;
				$existingCauses[] = "linked upper manifestations";
			}
			
			if ($ok)	
			{
				try
				{
					Prado::log(	"\nmanifestation with id=" . $manifestation->getManifestationId() . " deleted",
								TLogger::INFO,
								"Batch");
					
					$manifestation->delete();
				}
				catch (Exception $ex)
				{
					Prado::log(	"\n\nError in deleting manifestation with id=" . $manifestation->getManifestationId() . " : " . $ex-getMessage() . "\n\n",
								TLogger::INFO,
								"Batch");
				}
			}
			else
			{
				
				Prado::log(	"\nIt seems to be a regular manifestation. Setting status to 'complete'\n",
							TLogger::INFO,
							"Batch");
				
				$manifestation->setManifestationStatus(ManifestationPeer::STATUS_COMPLETE);
				
				$manifestation->save();
			}
			
		}
		
		Prado::log(	"\n\n#### ALL DONE!!! ####\n",
					TLogger::INFO,
					"Batch");
		
		return true;
	}

}