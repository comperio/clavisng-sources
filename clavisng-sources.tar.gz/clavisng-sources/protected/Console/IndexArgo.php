<?php

/**
 * Batch index manifestations on extra collection.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Console
 * @since 2.5.0
 */
require_once('ClavisCommandLineAction.php');




/**
 * @package Console
 * @since 2.5.0
 */
class ClavisActionIndexArgo extends ClavisCommandLineAction
{
    const COLLECTION_NONE = NULL;
    const COLLECTION_MLOL = 'MLOL';
    const SLICE_COUNT = 8912;
    protected $action = 'index_argo';
    protected $parameters = array('index_file', '--collection name', ' --format aleph500|alma|oclc|MLOL|divbib');
    protected $optional = array('--clean', '-xsl xslfile');
    protected $description = 'Index all manifestation in the given file in the "argo" collection of the Solr server. Use second parameter <file_format> to specify the source of the file (bmw: BookmarkWeb2, rmb: RMB). Third parameter clean before index, remember to set to true with mlol.';
    protected $collection = self::COLLECTION_NONE;
    protected $clean = FALSE;
    private $_libcodes;

    public function performAction($args)
    {
        $fp = FALSE;
        $search = NULL;
        $appId = 'app-name-unset';

        $startTime = microtime(true);

        $params = $this->parseArgs($args);

        print_r($params);

        $this->collection = $params['collection'];
        $this->clean = isset($params['clean']);

        try {
            /** @var SolrSearch $search */
            $search = Prado::getApplication()->getModule('search');
            $appId = Prado::getApplication()->getID();
            $this->printMsg("Processing {$this->collection}...");

            if (isset($params['xsl'])) {
                $xsl = new DOMDocument();
                $xsl->load($params['xsl']);

                $proc = new XSLTProcessor;
                $proc->registerPHPFunctions();
                if(!$proc->importStyleSheet($xsl)) {
                    $this->printMsg("Errore compiling xsl [{$params['xsl']}");
                    die(1);
                }
            } else {
                $proc = null;
            }

            $fp = @fopen($params[0], 'r');
            stream_get_line($fp, 128000, ">");

            if ($fp === false) {
                throw new Exception("FAILED TO OPEN INPUT FILE.");
            }

            foreach (LibraryQuery::create()->find() as $library)
                $this->_libcodes[$library->getLibraryCode()] = $library;

            $data = $timings = array();
            $totalcount = 0;
            $mt = microtime(true);
            if ($this->clean) {
                $search->cleanIndexExtra($this->collection);
            }

            while (!feof($fp)) {
                try {
                    $record = stream_get_line($fp, 128000, "</r>");
                    $record .= "</r>";

                    if(isset($params['cleanpunct'] )) {
                        $record = self::cleanField($record);
                    }

                    $tm = simplexml_load_string($record);

                    if(isset($params['expandGND'])) {

                    }

                    if ($proc != null) {
                        $record = $proc->transformToXML($tm);
                        if($record === false)
                            throw new Exception("Error trasforming XSL");

                        $tm = simplexml_load_string($record);
                    }

                    if($tm === false) throw new Exception("Error XML parsing $record");

                    if(isset($params['cleanCDF'])) {
                        foreach($tm->children() as $fld)
                            if(substr($fld->getName(),0,2) == "d1")
                                foreach ($fld->children() as $sfld)
                                    $sfld[0] = str_replace(["-","|"],[" "," "],(string)$sfld[0]);


                    }

                    $bid = ( string )$tm->c001;
                    $data[$bid] = $tm->asXML();

                } catch (Exception $e) {
                    $this->printMsg("\n" . __METHOD__ . " discarding..." . $e->getMessage());
                    continue;
                }
                if (count($data) >= 10000) {

                    $search->indexExtra($data, false, false, $this->collection);

                    $totalcount += count($data);
                    $this->printMsg("\n{$totalcount} records indexed! [" . (string)(microtime(true) - $mt) . "]");
                    $data = array();

                    $mt = microtime(true);
                }
            }

            $search->indexExtra($data, false, false, $this->collection);

            $totalcount += count($data);
            $timings[] = microtime(true) - $mt;
            $this->printMsg("\n{$totalcount} records indexed");
        } catch (Exception $e) {
            $this->printMsg("\n!!!! SOMETHING WENT WRONG, please check your logs.\n" .
                "Exception throwed is [{$e->getCode()}] {$e->getMessage()}.");
            exit();
        }
        fclose($fp);

        $this->printMsg("Execution time: " . (microtime(true) - $startTime));
        $this->printMsg("\n#### ALL DONE!!! ####");
        return true;
    }

    public function printMsg($msg)
    {
        echo $msg . PHP_EOL;
        Prado::log($msg);
    }

    public static function cleanField($str) {
        $str = str_replace(
            ['<<','>>','&lt;&lt;','&gt;&gt;','/<',':<',' ;<',',<'],
            [''  ,''  ,''        ,''        ,'<'  ,'<'  ,'<'  ,'<'],
            $str);

        return trim($str);
    }

    public function expandGND($id) {

    }
}
