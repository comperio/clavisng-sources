<?php

/**
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Console
 * @since 2.5.0
 */

require_once('ClavisCommandLineAction.php');

/**
 * @package Console
 * @since 2.5.0
 */
class ClavisActionCheckNewItems extends ClavisCommandLineAction
{
	protected $action = 'check_new_items';
	protected $parameters = array();
	protected $optional = array();
	protected $description = 'Checks all "timed local news" items and puts them in available status if the expiration time has past.';

	const TIME30DAYS = 2592000;		// 3600 * 24 * 30
	const TIME60DAYS = 5184000;		// 3600 * 24 * 60
	const TIME90DAYS = 7776000;		// 3600 * 24 * 90
	const TIME10DAYS = 864000;		// 3600 * 24 * 90

	public function performAction($args)
	{
		$unloan_grace_time = intval(ClavisParamPeer::getParam('NEWITEM_UNLOAN_GRACETIME', 0));

		echo "\nStarting...".$unloan_grace_time;

		$actualTime = time();

		$items = ItemQuery::create()
			->setFormatter('PropelOnDemandFormatter')
			->join('Manifestation')
			->condition('new10','Item.LoanClass = ?',ItemPeer::LOANCLASS_LOCALNEW10)
			->condition('new30','Item.LoanClass = ?',ItemPeer::LOANCLASS_LOCALNEW30)
			->condition('new60','Item.LoanClass = ?',ItemPeer::LOANCLASS_LOCALNEW60)
			->condition('new90','Item.LoanClass = ?',ItemPeer::LOANCLASS_LOCALNEW90)
			->condition('invdate_less_10','Item.InventoryDate <= ?',$actualTime - self::TIME10DAYS)
			->condition('invdate_less_30','Item.InventoryDate <= ?',$actualTime - self::TIME30DAYS)
			->condition('invdate_less_60','Item.InventoryDate <= ?',$actualTime - self::TIME60DAYS)
			->condition('invdate_less_90','Item.InventoryDate <= ?',$actualTime - self::TIME90DAYS)
			->combine(array('new10','invdate_less_10'), 'and', 'expired10')
			->combine(array('new30','invdate_less_30'), 'and', 'expired30')
			->combine(array('new60','invdate_less_60'), 'and', 'expired60')
			->combine(array('new90','invdate_less_90'), 'and', 'expired90')
			->combine(array('expired10','expired30','expired60','expired90'),'or','expiredNew')
			->condition('lsnull1','Manifestation.LoanableSince IS NULL')
			->condition('lsnull2','Manifestation.LoanableSince < Item.InventoryDate')
			->combine(array('lsnull1','lsnull2'), 'or', 'lsnull')
			->combine(array('expiredNew','lsnull'),'and','expiredLsNull')

			->condition('new10','Item.LoanClass = ?',ItemPeer::LOANCLASS_LOCALNEW10)
			->condition('new30','Item.LoanClass = ?',ItemPeer::LOANCLASS_LOCALNEW30)
			->condition('new60','Item.LoanClass = ?',ItemPeer::LOANCLASS_LOCALNEW60)
			->condition('new90','Item.LoanClass = ?',ItemPeer::LOANCLASS_LOCALNEW90)
			->condition('since10','Manifestation.LoanableSince <= ?',$actualTime - self::TIME10DAYS)
			->condition('since30','Manifestation.LoanableSince <= ?',$actualTime - self::TIME30DAYS)
			->condition('since60','Manifestation.LoanableSince <= ?',$actualTime - self::TIME60DAYS)
			->condition('since90','Manifestation.LoanableSince <= ?',$actualTime - self::TIME90DAYS)
			->combine(array('new10','since10'), 'and', 'expiredsince10')
			->combine(array('new30','since30'), 'and', 'expiredsince30')
			->combine(array('new60','since60'), 'and', 'expiredsince60')
			->combine(array('new90','since90'), 'and', 'expiredsince90')
			->combine(array('expiredsince10','expiredsince30','expiredsince60','expiredsince90'),'or','expiredSince')
			->condition('lsnotnull','Manifestation.LoanableSince >= Item.InventoryDate')
			->combine(array('expiredSince','lsnotnull'),'and','expiredLsNotNull');

		if ($unloan_grace_time > 0) {
			$items
				->condition('new','Item.LoanClass IN (?,?,?)',
					array(ItemPeer::LOANCLASS_LOCALNEW30,
						ItemPeer::LOANCLASS_LOCALNEW60,
						ItemPeer::LOANCLASS_LOCALNEW90))
				->condition('lsnull1','Manifestation.LoanableSince IS NULL')
				->condition('lsnull2','Manifestation.LoanableSince < Item.InventoryDate')
				->combine(array('lsnull1','lsnull2'), 'or', 'lsnull')
				->condition('not_on_loan','Item.LoanStatus = ?',ItemPeer::LOANSTATUS_AVAILABLE)
				->condition('lastseen_null','Item.LastSeen IS NULL')
				->condition('invdate_less_grace','Item.InventoryDate <= ?',$actualTime - $unloan_grace_time)
				->combine(array('lastseen_null','invdate_less_grace'),'and','neverLoaned')
				->condition('lastseen_overgrace','Item.LastSeen <= ?',$actualTime - $unloan_grace_time)
				->combine(array('neverLoaned','lastseen_overgrace'),'or','lastseen')
				->combine(array('lsnull','new','not_on_loan','lastseen'),'and','unLoaned')
				->where(array('expiredLsNull','expiredLsNotNull','unLoaned'),'or');
		} else {
			$items->where(array('expiredLsNull','expiredLsNotNull'),'or');
		}

		foreach ($items->find() as $item) {
			echo "\nMaking available item {$item->getItemId()}...";
			$item->setLoanClass(ItemPeer::LOANCLASS_AVAILABLE);
			$item->setOpacVisible(true);
			$item->save();
		}

		echo "\n#### ALL DONE!!! ####\n";
		return true;
	}

}