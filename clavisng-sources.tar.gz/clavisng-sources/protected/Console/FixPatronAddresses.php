<?php

/**
 * Use:
 * clavis-cli [site] fix_patron_addresses
 *
 * @author Cristian <ciarez@comperio.it>
 * @package Console
 */

require_once('ClavisCommandLineAction.php');

/**
 * @package Console
 * @since 2.8.2
 */
class ClavisActionFixPatronAddresses extends ClavisCommandLineAction
{
	protected $action = 'fix_patron_addresses';
	protected $parameters = array();
	protected $optional = array("fixprov","writedb","fixprov writedb","delete_empty", "fix_street_prefix");
	protected $description = "Fix address by zip code. Params: fixprov try to substitute extended name with initials. writedb write to db, else create a /tmp/*.csv files";
	protected $debug=TRUE;
	protected $fixprov=FALSE;
	protected $provinces=array();
	//protected $culture = Prado::getApplication()->getGlobalization()->getCulture();
	protected $culture = "it_IT";
	protected $provNameById=array();
	protected $provIniById=array();
	protected $provNameByIni=array();
	protected $provIniByName=array();

	
	protected function normalize($k)
	{
		$k = transliterator_transliterate("Any-Upper",transliterator_transliterate("Latin-ASCII",$k));
		$k = preg_replace("/\s+/"," ",$k);
		$k = preg_replace("/\W/","",$k);
		return $k;
	}
	
	
	protected function loadProvinces()
	{
		$provs=LookupValueQuery::create()
			->filterByValueClass('PROVINCES')
			->filterByValueLanguage($this->culture)
			->find();
		foreach($provs as $p)
		{
			$this->provNameById[$p->getValueKey()]=  $this->normalize($p->getValueLabel());
		}
		
		$provini=LookupValueQuery::create()
			->filterByValueClass('PROVINITIALS')
			->filterByValueLanguage($this->culture)
			->find();
		foreach($provini as $p)
		{
			$this->provIniById[$p->getValueKey()]=$p->getValueLabel();
			$this->provNameByIni[$p->getValueLabel()]=$this->provNameById[$p->getValueKey()];
			$this->provIniByName[$this->provNameById[$p->getValueKey()]]=$p->getValueLabel();
		}
	}
	
	/*
	 * Try to fix province
	 * return same value if ok
	 * new value if fixable
	 * FALSE if bad
	 */
	protected function fixProvince( $prov )
	{
		//if not uppercase, up it
		$isUpper = ctype_upper($prov);
		if( ! $isUpper)
		{
			$prov=strtoupper($prov);
		}
		//Search  province by initials
		if (  in_array( $prov, $this->provIniById ) )
		{
			//if found return initials
			return $prov;
		}

		//If initials try to search name
		if (  in_array( $this->normalize($prov), $this->provNameById ) )
		{
			return $this->provIniByName[$prov];
		}
		else
		{
			return FALSE;
		}
	}
	
	
	protected function fixMultipleZip( $address, $cityIds )
	{
		//get zip code insert for this address
		$addrZip = $address->getZip();
		//get city insert for this address
		$addrCity = $address->getCity();
		//get prov insert for this address
		$addrProv = $address->getProvince();
		$addrPatronId=$address->getPatronId();
		
		//Multiple zip found, alias multiple city for this zip
		$provId="";
		
		//get all cities from db
		$citiesForThisZip=LookupValueQuery::create()
			->filterByValueClass('CITIES')
			->filterByValueLanguage($this->culture)
			->filterByValueKey($cityIds)
			->find();
		//for every city having this zip
		foreach ($citiesForThisZip as $cityZip)
		{
			$aKey=explode("|",$cityZip->getValueKey());
			$cityName=$cityZip->getValueLabel();
			//if name equals to the name insert by user city is ok so zip is ok. I set prov id end stop loop
			$normAddrCity=$this->normalize($addrCity);
			$normCityName=$this->normalize($cityName);
			//if(strcasecmp(  , ) == 0)
			if($normAddrCity == $normCityName)
			{
				//Ok city is correct
				$provId=$aKey[1];
				break;
			}
		}

		//if zip and city is ok
		if($provId != "")
		{
			//get the initials of province
			$correctProv=  $this->provIniById[$provId];
			if($this->debug)
			{
				//if initials not match I fix it
				if($addrProv != $correctProv)
				{
					$this->wrongAddr[]="MULTICAP_PROV_FIXABLE;".$addrZip.";".$addrCity.";".$addrProv.";".$addrPatronId;
					$this->wrongAddr[]="MULTICAP_PROV_FIX;".$addrZip.";".$addrCity.";".$correctProv.";".$addrPatronId;
				}
			}
			else
			{
				//if initials not match I fix it
				if($addrProv != $correctProv)
				{
					$address->setProvince($correctProv);
					$note=$address->getAddressNote();
					if($note == "")
					{
						$note = "SYSTEM ".date("Y-m-d H:i:s").": corretto provincia errata";
						$address->setAddressNote($note);
					}
					$address->save();
				}
			}
		}
		else 
		{
			//No matching city found I can't do nothing
			if($this->debug)
			{
				/*
				if(strpos($addrCity,"Torri") !== FALSE)
				{
					$n=$this->normalize($addrCity);
					echo "$addrCity $n\n";
				}*/
				$this->wrongAddr[]="MULTICAP_BAD;".$addrZip.";".$addrCity.";".$addrProv.";".$addrPatronId;
			}
			else
			{
				//set address ad bad
				$note=$address->getAddressNote();
				if($note == "")
				{
					$note = "SYSTEM ".date("Y-m-d H:i:s").": incoerenza cap,comune, provincia ma impossibile correggere automaticamente";
					$address->setAddressNote($note);
				}
				$address->setAddressType("X");
				$address->save();
			}
		}
		
	}
	
	
	protected function fixBadAddr( $address, $cityProvZipKey )
	{
		//get zip code insert for this address
		$addrZip = $address->getZip();
		//get city insert for this address
		$addrCity = $address->getCity();
		//get prov insert for this address
		$addrProv = $address->getProvince();
		$addrPatronId=$address->getPatronId();
		
		
		//split the key
		$cityProvZipKeyArray=explode("|", $cityProvZipKey);
		//and compose city key
		$cityProvKey=$cityProvZipKeyArray[0]."|".$cityProvZipKeyArray[1];
		//and prov key
		$provKey=$cityProvZipKeyArray[1];

		//Get city and province names
		$cityObj = LookupValueQuery::create()
			->filterByValueClass('CITIES')
			->filterByValueLanguage($this->culture)
			->filterByValueKey($cityProvKey)
			->findOne();

		$provObj = LookupValueQuery::create()
			->filterByValueClass('PROVINITIALS')
			->filterByValueLanguage($this->culture)
			->filterByValueKey($provKey)
			->findOne();


		if(  $cityObj instanceof LookupValue && $provObj instanceof LookupValue )
		{
			//get correct values 
			$correctCity = $cityObj->getValueLabel();
			$correctProv=$provObj->getValueLabel();
			if( $addrCity != $correctCity || $addrProv != $correctProv)
			{
				if($this->debug)
				{
					$this->wrongAddr[]="ADDR_SINGLECAP;".$addrZip.";".$addrCity.";".$addrProv.";".$addrPatronId;
					$this->wrongAddr[]="ADDR_SINGLECAP_FIX;".$addrZip.";".$correctCity.";".$correctProv.";".$addrPatronId;
				}
				else
				{
					$newAddr = new Address();
					$address->copyInto($newAddr);
					$newAddr->setCity($correctCity);
					$newAddr->setProvince($correctProv);
					$newAddr->setCountry($this->defCountry);
					$newAddr->setAddressNote("SYSTEM ".date("Y-m-d H:i:s").": indirizzio con id ".$address->getAddressId()." errato, ho creato questo al suo posto.");
					$newAddr->save();

					$note=$address->getAddressNote();
					if($note == "")
					{
						$note = "SYSTEM ".date("Y-m-d H:i:s").": cap comune provincia non conformi. Vedi indirizzo id ".$newAddr->getAddressId();
						$address->setAddressNote($note);
					}
					$address->setAddressType("X");
					$address->save();
				}
			}

		}
		else
		{
			//If debug mode, notify incosistence of city/provinces if present
			if($this->debug)
			{
				if( ! $cityObj instanceof LookupValue )
				{	
					echo __METHOD__ . " no cities with key {$cityProvKey} found!\n";
					//Strange... Zip have an invalid city code
					$this->inconsistencies[]=$addrZip.";".$address->getCity().";".$cityProvKey. ";".$address->getProvince().";";
				}
				if( ! $provObj instanceof LookupValue )
				{
					//Strange... Zip have an invalid province code
					echo __METHOD__ . " province with key {$cityProvZipKeyArray[1]} not found!\n";
					$this->inconsistencies[]=$addrZip.";".$address->getCity().";;".$address->getProvince().";".$cityProvZipKeyArray[1];
				}
			}
		}
		
	}
	
	

	protected function fixBadZip( $address )
	{
		//get zip code insert for this address
		$addrZip = $address->getZip();
		//get city insert for this address
		$addrCity = $address->getCity();
		//get prov insert for this address
		$addrProv = $address->getProvince();
		$addrPatronId=$address->getPatronId();
		$correctProv="";

		//Try to find correct zip/prov by city name
		$cityKey="";
		$cityObj = LookupValueQuery::create()
			->filterByValueClass('CITIES')
			->filterByValueLanguage($this->culture)
			->filterByValueLabel($addrCity)
			->findOne();
		if( $cityObj instanceof LookupValue )
		{
			// Ok city found but may have more than one zip.  
			$zipCityObj=LookupValueQuery::create()
				->filterByValueClass('ZIPS')
				->filterByValueLanguage($this->culture)
				->filterByValueKey($cityObj->getValueKey() . "|%")
				->find();
			$nzipCity=count($zipCityObj);

			//if no one or many found we cannot fix it :(
			if($nzipCity==1)
			{		
				//If only one is found, we can try to fix it.
				//Get zip code from LookupValue obj
				$correctZip=$zipCityObj[0]->getValueLabel();
				//Get the key of LookupValue obj to get  prov id from it
				$tmpKeys=  explode("|", $zipCityObj[0]->getValueKey());
				//Prov id is the secon element
				$provId=$tmpKeys[1];

				//Try to find prov by its key
				$provObj=LookupValueQuery::create()
					->filterByValueClass('PROVINITIALS')
					->filterByValueLanguage($this->culture)
					->filterByValueKey($provId)
					->findOne();
				if( $provObj instanceof LookupValue)
				{
					//OK! Get the province
					$correctProv=$provObj->getValueLabel();
				}
			}
		}

		if($this->debug)
		{
			if( $correctProv != "" )
			{
				$this->wrongAddr[]="CAP_FIXABLE;".$addrZip.";".$addrCity.";".$addrProv.";".$addrPatronId;
				$this->wrongAddr[]="CAP_FIX;".$correctZip.";".$addrCity.";".$correctProv.";".$addrPatronId;
			}
			else
			{
				$this->wrongAddr[]="CAP_BAD;".$addrZip.";".$addrCity.";".$addrProv.";".$addrPatronId;
			}
		}
		else
		{
			//We have correct zip and prov thanks to city name, we can fix address
			if( $correctProv != "" )
			{
				$newAddr = new Address();
				$address->copyInto($newAddr);
				$newAddr->setZip($correctZip);
				$newAddr->setProvince($correctProv);
				$newAddr->setCountry($this->defCountry);
				$newAddr->setAddressNote("SYSTEM ".date("Y-m-d H:i:s").": indirizzio con id ".$address->getAddressId()." errato, ho creato questo al suo posto.");
				$newAddr->save();

				$note=$address->getAddressNote();
				if($note == "")
				{
					$note = "SYSTEM ".date("Y-m-d H:i:s").": indirizzo non conforme. Vedi indirizzo id ".$newAddr->getAddressId();
					$address->setAddressNote($note);
				}
				$address->setAddressType("X");
				$address->save();
			}
			else //We have correct zip but province is bad, cannot fix.
			{
				$note=$address->getAddressNote();
				if($note == "")
				{
					$note = "SYSTEM ".date("Y-m-d H:i:s").": cap errato";
					$address->setAddressNote($note);
				}
				$address->setAddressType("X");
				$address->save();
			}
		}
		
	}

	public function performAction($args)
	{
		try
		{
			$this->culture=Prado::getApplication()->getGlobalization()->getCulture();
						
			$this->loadProvinces();


			$this->wrongAddr=array();
			$this->wrongAddr[]="NOTE;CAP;COMUNE;PROVINCIA";
			$this->inconsistencies=array();
			$this->inconsistencies[]="ZIP;CITY;MISSINGCITYCODE;PROV;MISSINGPROVCODE";
			
			if(count($args) == 2)
			{
				if ($args[1] == 'fixprov')
				{
					$this->fixprov=TRUE;
				}
				
				if ( $args[1] == 'writedb')
				{
					$this->debug=FALSE;
				}
				
				if ( $args[1] == 'delete_empty')
				{
					$sql = "
						DELETE FROM address WHERE 
						patron_id IS NOT NULL 
						AND (address_type IS NULL OR trim(address_type) = '') 
						AND (address_pref IS NULL  OR trim(address_pref) = '') 
						AND (address_note  IS NULL  OR trim(address_note) = '') 
						AND (street_type IS NULL  OR trim(street_type) = '') 
						AND (street IS NULL OR  length(trim(street)) < 4) 
						AND (street_num IS NULL  OR trim(street_num) = '') 
						AND (village IS NULL  OR trim(village) = '') 
						AND (city IS NULL  OR trim(city) = '') 
						AND (zip IS NULL  OR trim(zip) = '') 
						AND (province IS NULL  OR trim(province) = '') 
						AND (country IS NULL OR trim(country) = '') 
						";

					$r = Propel::getConnection()->exec($sql);
					echo "Empty addresses deleted.\n";
					exit(0);
				}
						
				if ( $args[1] == 'fix_street_prefix')
				{
					$streetFixed = 0;
					echo "Trying to fix streets type...\n";
					$this->culture=Prado::getApplication()->getGlobalization()->getCulture();
				
					//Load all street prefix
					$sp = LookupValueQuery::create()
						->filterByValueClass('STREET')
						->filterByValueLanguage($this->culture)
						->find();
				
				
					$addressObjs = AddressQuery::create()
									->find();
					foreach ($addressObjs as $address)
					{
						//Take original street
						$street = trim($address->getStreet());
						foreach ($sp as $prefix)
						{
							$k = $prefix->getValueKey();
							$v = $prefix->getValueLabel();
							//have street type at beginning?
							if( stripos($street, $v) === 0)
							{
								//Yes. Remove street type from street
								$newStreet=  str_ireplace($v, "",$street);
								$newStreet=trim($newStreet);
								//Set clean street
								$address->setStreet($newStreet);
								//Set street type
								$address->setStreetType($k);
								$address->save();
								$streetFixed++;
								//echo $street." replaced with [". $k."-".$v."] ".$newStreet."\n";
								//Stop street type loop
								break;
							}
						}
					}
									
					
					echo $streetFixed . " street prefix in addresses fixed.\n";
					exit(0);
				}
			}
			
			if(count($args) == 3)
			{
				if ( $args[1] == 'fixprov' )
				{
					$this->fixprov=TRUE;
				}

				if ( $args[2] == 'writedb' )
				{
					$this->debug=FALSE;
				}
			}
			
			
			
			$where=" zip IS NOT NULL AND zip != '' AND address_type != 'X' ";
			
			$this->defCountry = ClavisParamQuery::getParam("CLAVISPARAM","DefaultAddressCountry");
			if( is_null($this->defCountry) || $this->defCountry == "")
			{
				echo "Please set param CLAVISPARAM DefaultAddressCountry\n";
				exit(1);
			}
			
			$addresses =  AddressQuery::create()->where($where)->find();
			echo __METHOD__ . " " . count($addresses) ." found.\n";
			
			//For each zip take the key (like zip|cityid|provid)
			foreach($addresses as $address)
			{
				//get zip code insert for this address
				$addrZip = $address->getZip();
				//get city insert for this address
				$addrCity = $address->getCity();
				//get prov insert for this address
				$addrProv = $address->getProvince();
				$addrPatronId=$address->getPatronId();
				$addrCountry=$address->getCountry();
				
				//if not default country (or subset of default country) don't touch it.
				if( !is_null($addrCountry) && $addrCountry != '' && strpos( $this->defCountry, $addrCountry ) === FALSE )
				{
					continue;
				}
				
							
				if($this->fixprov  )
				{
					$prov=  $this->fixProvince($addrProv);
					if($prov != $addrProv)
					{
						if( $this->debug)
						{
							$this->wrongAddr[]="FIXABLE_PROV;".$addrZip.";".$addrCity.";".$addrProv.";".$addrPatronId;
							$this->wrongAddr[]="FIX_PROV;".$addrZip.";".$addrCity.";".$prov.";".$addrPatronId;
						}
						else
						{
							$address->setProvince($prov);
							$note=$address->getAddressNote();
							if($note == "")
							{
								$note = "SYSTEM ".date("Y-m-d H:i:s").": corretto provincia";
								$address->setAddressNote($note);
							}
							$address->save();	
						}
					}
					elseif($prov==FALSE && $this->debug)
					{
						$this->wrongAddr[]="BAD_PROV;".$addrZip.";".$addrCity.";".$addrProv.";".$addrPatronId;
					}
					continue;
				}

				
				//one zip can match with more cities 
				$zipObj = LookupValueQuery::create()
					->filterByValueClass('ZIPS')
					->filterByValueLanguage($this->culture)
					->filterByValueLabel($addrZip)
					->find();
				
				//Count cities for this zip (may be more than one)
				$ncityForZip=count($zipObj);
				
				//User has  inserted bad zip code (not found into db) so try to check address by city name
				if($ncityForZip==0)
				{
					$this->fixBadZip($address);
	
				}	
				elseif($ncityForZip==1)
				{
					//Zip have only one city. Get it's key
					$cityProvZipKey=$zipObj[0]->getValueKey();
					$this->fixBadAddr($address, $cityProvZipKey);
				}
				else
				{
					$cityIds=array();
					//get all city keys for this zip
					foreach ($zipObj as $zo)
					{
						$aKey=explode("|", $zo->getValueKey());
						$cityIds[]=$aKey[0]."|".$aKey[1];
					}
					$this->fixMultipleZip($address,$cityIds);
				}
			}
			
			if($this->debug)
			{
				file_put_contents("/tmp/wrongaddr.csv", implode("\n", $this->wrongAddr));
				file_put_contents("/tmp/inconsistencies.csv", implode("\n", $this->inconsistencies));
				echo __METHOD__ . " please see /tmp/wrongaddr.csv and /tmp/inconsistencies.csv.\n";
			}
			
			echo __METHOD__ . " done.\n";
			return true;
		} catch (Exception $ex) {
			echo __METHOD__ . " EXCEPTION: " . $ex->getMessage();
		}
		
		
	}
}