<?php

/**
 * Batch deindex manifestations.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Console
 * @since 2.5.0
 */

require_once('ClavisCommandLineAction.php');

/**
 * @package Console
 * @since 2.5.0
 */
class ClavisActionDeindex extends ClavisCommandLineAction
{
	protected $action = 'deindex';
	protected $parameters = array('all | manifestation id | shelf | date');
	protected $optional = array('debug');
	protected $description = 'Batch deindex all manifestations in db. Use mandatory parameter to specify which manifestations to deindex: [manifestation id] to index a single manifestation, [s<shelfId>] to take all manifestations contained in a shelf, [date] to index all manifestations updated after a certain date. Second optional parameter, if specified, writes indexing doc to /tmp/solrDoc.xml and doesn\'t send it to Solr server.';

	private $_outputParams = array();

	public function performAction($args)
	{
		$mids = array();
		if ($args[1] != 'all') {
			// if argument is an integer, take it as ManifestationId; elsewhere, try to convert to date.
			if (intval($args[1]) == $args[1]) {
				$mids = array($args[1]);
			} else if ($args[1]{0} == 's') {
				// if argument begins with a 's' user wants to index a shelf
				$mids = ShelfItemQuery::create()
					->filterByShelfId(intval(substr($args[1],1)))
					->filterByObjectClass('manifestation')
					->select(array('ObjectId'))
					->find();
			} else {
				$mids = ManifestationQuery::create()
					->filterByDateUpdated($args[1], Criteria::GREATER_EQUAL)
					->select(array('ManifestationId'))
					->find();
			}
		}
		$toFile = (count($args) > 2 && $args[2] == 'debug');
		$search = Prado::getApplication()->getModule('search');
		try {
			$search->deIndex($mids,true,$toFile);
			echo count($mids)." records deindexed\n";
		} catch (Exception $e) {
			Prado::log("General error - message {$e->__toString()}\n",
						TLogger::ERROR,'Console');
			print "\n!!!! SOMETHING WENT WRONG, please check your logs.\n".
				"Exception throwed is [{$e->getCode()}] {$e->getMessage()}.\n";
			exit();
		}
		echo "\n#### ALL DONE!!! ####\n";
		return true;
	}

}