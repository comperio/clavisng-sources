<?php


// run every x minutes by chron
// */x * * * * /var/www/html/clavisng/clavis-cli all get_counters_data >> /var/log/clavis.log 2>&1
 /*
  * Import into kpi_values people couters data. Counters need to be configurated as resource into clavis.
  * 
  * @author Cristian <ciarez@comperio.it>
  * @version 2.8.2
  * @package Console
  * @since 2.8.2
  */

require_once('ClavisCommandLineAction.php');

/**
 * @package Console
 * @since 2.8.2
 */
class ClavisActionGetCountersData extends ClavisCommandLineAction
{
	private static $supportedModels = array('footfallcloud','footfalldirect');
	protected $action = 'get_counters_data';
	protected $parameters = array();
	protected $optional = array("model: get data only for specific model only", "date: specify date to download (formatted as d/m/Y)");
	protected $description = 'Retrieve data from resources type counter.';


	public function performAction($args)
	{
		try
		{
			$reqModel= FALSE;
			$reqDate = FALSE;
			$narg = count($args);
			
			switch($narg)
			{
				case 3:
					if( in_array( $args[1], self::$supportedModels ) )
					{
						$reqModel = $args[1];
						echo("Get data for model {$args[1]} only\n");
					}
					else
					{
						echo("WARNING: Model {$args[1]} is not supported\n");
					}
					if(preg_match('/\d{2}\/\d{2}\/\d{4}/',$args[2]))
					{
						$reqDate = $args[2];
					}
					else
					{
						echo("WARNING: date malformed, please use dd/mm/yyyy\n");
					}
					break;
				
				case 2:
					if( in_array( $args[1], self::$supportedModels ) )
					{
						$reqModel = $args[1];
						echo("Get data for model {$reqModel} only\n");
					}
					else
					{
						if(preg_match('/\d{2}\/\d{2}\/\d{4}/',$args[1]))
						{
							$reqDate = $args[1];
						}
						else
						{
							echo("WARNING: date {$reqDate} malformed. Use d/m/Y\n");
						}
					}
			}
			
			$counters = ResourceQuery::create()
				->findByType(Resource::TYPE_PEOPLECOUNTER);
			foreach ($counters as $counter)
			{
				/*
				 * Name is used to store multiple values like
				 * model|url or ip|id
				 */
				$cstring = $counter->getName();
				$mk = $counter->getType();
				$sn = $counter->getShortname();
				$lid = $counter->getLibraryId();
				$carray = explode("|", $cstring);
				$model = $carray[0];
				if($reqModel !== FALSE && $reqModel != $model)
				{
					continue;
				}
				$ip = $carray[1];
				$id = $carray[2];
				
				
				
				
				$accessToken = $counter->getSecret();
				$timingHour = "AnalyticReportDataByHourinExport";
				//$timingDay = "AnalyticReportDataByDayinExport";
				switch($model)
				{
					case "footfallcloud":						
						$conn = Propel::getConnection();
						$dStart = date("d/m/Y");
						if( $reqDate === FALSE )
						{
							$stmt = $conn->prepare("SELECT MAX(id_date) from kpi_value WHERE master_key=? AND (slave_key = ? OR slave_key = ?) AND library_id=?");
							$stmt->execute(array($mk,$sn.'|IN',$sn.'|OUT',$lid));
							$x = $stmt->fetchAll(PDO::FETCH_NUM);
							if( ! is_null($x[0][0]) && preg_match('/\d{2}\/\d{2}\/\d{4}/',$x[0][0]) )
							{
								$dStart =  DateTime::createFromFormat("Y-m-d H:i:s", $x[0][0])->format("d/m/Y");
								echo("Get data for date {$dStart}\n");
							}
						}
						else
						{
							$dStart = $reqDate;
						}
						$dEnd = date("d/m/Y");
						
						//https://footfallcounter.com/footfallcam/AnalyticReportDataByDayinExport?CameraId=6387&StartDate=31/08/2017&EndDate=31/08/2017&inonly=true&outonly=false&outsidetrafficonly=false&turninrate=false&dwelltime=false&returningandnewcustomer=false&access_token=98XWH4flqTmzNSowJH9z11lQdPvZ/jiiIa5PpVGWHh1u%2bdQEd9d/we5YvXKUV85U
						$url = "{$ip}/footfallcam/{$timingHour}?CameraId={$id}&StartDate={$dStart}&EndDate={$dEnd}&inonly=true&outonly=true&outsidetrafficonly=false&access_token={$accessToken}";
						echo("resource {$counter->getResourceId()} '{$sn}' library {$lid}: Calling {$url}\n");
						$jData = file_get_contents($url);
						$j = json_decode($jData,TRUE);
						
						foreach($j["Countings"] as $entry)
						{
							$dt = $entry["ValueDateTimeString"];
							$in = $entry["ValueIn"];
							$out = $entry["ValueOut"];

							$stmt = $conn->prepare("INSERT IGNORE INTO kpi_value (id_date,master_key,slave_key,library_id,num_val,txt_val) VALUES (?,?,?,?,?,?)");
							$stmt->execute(array($dt,$mk,  $sn . "|IN", $lid, $in, NULL));
							$stmt->execute(array($dt,$mk, $sn . "|OUT", $lid, $out, NULL));
							
						}
						
						break;
						
					case "footfallcloudv2":	
						/* API since 12/2017 */
						$conn = Propel::getConnection();
						$dStart = date("d/m/Y");
						if( $reqDate === FALSE )
						{
							$stmt = $conn->prepare("SELECT MAX(id_date) from kpi_value WHERE master_key=? AND (slave_key = ? OR slave_key = ?) AND library_id=?");
							$stmt->execute(array($mk,$sn.'|IN',$sn.'|OUT',$lid));
							$x = $stmt->fetchAll(PDO::FETCH_NUM);
							if( ! is_null($x[0][0]) && preg_match('/\d{2}\/\d{2}\/\d{4}/',$x[0][0]) )
							{
								$dStart =  DateTime::createFromFormat("Y-m-d H:i:s", $x[0][0])->format("d/m/Y");
								echo("Get data for date {$dStart}\n");
							}
						}
						else
						{
							$dStart = $reqDate;
						}
						$dEnd = date("d/m/Y");
						
						//https://footfallcounter.com/FootfallCam/exportData?infoJson={"cat":"1","id":["4004"],"data":[],"fromdate":"19/12/2017","todate":"19/12/2017","period":"0","dateformat":"dd/MM/yyyy"}&access_token=98XWH4flqTmzNSowJH9z1y3DAYOdLYC2oiFirQP6B3c=
						$url = "{$ip}/FootfallCam/exportData?infoJson={\"cat\":\"1\",\"id\":[\"{$id}\"],\"data\":[],\"fromdate\":\"{$dStart}\",\"todate\":\"{$dEnd}\",\"period\":\"0\",\"dateformat\":\"yyyy-MM-dd\"}&access_token={$accessToken}";
						echo("resource {$counter->getResourceId()} '{$sn}' library {$lid}: Calling {$url}\n");
						$jData = file_get_contents($url);
						$j = json_decode($jData,TRUE);
						
						foreach($j["Data"] as $entry)
						{
							$dt = $entry["DateTime"];
							$in = $entry["ValueIn"];
							$out = $entry["ValueOut"];

							$stmt = $conn->prepare("INSERT IGNORE INTO kpi_value (id_date,master_key,slave_key,library_id,num_val,txt_val) VALUES (?,?,?,?,?,?)");
							$stmt->execute(array($dt,$mk,  $sn . "|IN", $lid, $in, NULL));
							$stmt->execute(array($dt,$mk, $sn . "|OUT", $lid, $out, NULL));
							
						}
						
						break;
						
						
					case 'footfalldirect':
						$conn = Propel::getConnection();
						$dStart=date("Ymd");
						if( $reqDate === FALSE )
						{
							$stmt = $conn->prepare("SELECT MAX(id_date) from kpi_value WHERE master_key=? AND (slave_key = ? OR slave_key = ?) AND library_id=?");
							$stmt->execute(array($mk,$sn.'|IN',$sn.'|OUT',$lid));
							$x = $stmt->fetchAll(PDO::FETCH_NUM);
							if( ! is_null($x[0][0]) && preg_match('/\d{2}\/\d{2}\/\d{4}/',$x[0][0]) )
							{
								//yyyy-mm-dd hh:mm::ss
								$dStart =  DateTime::createFromFormat("Y-m-d H:i:s", $x[0][0])->format("Ymd");
								echo("Get data for date {$dStart}\n");
							}
						}
						else
						{
							$dStart =  DateTime::createFromFormat("d/m/Y", $reqDate)->format("Ymd");
						}

						$dEnd=date("Ymd");
						
						//http://192.168.1.137/pi-cgi/data.json?date=20170910-20170927
						$url = "{$ip}/pi-cgi/data.json?date={$dStart}-{$dEnd}";
						echo("resource {$counter->getResourceId()} '{$sn}' library {$lid}: Calling {$url}\n");
						$jData = file_get_contents($url);
						$j = json_decode($jData,TRUE);

						
						foreach($j["data"] as $entry)
						{
							$dt = $entry["time_str"];
							if( strpos($dt, "00:00") !== FALSE)
							{
								$in = $entry["inCount"];
								$out = $entry["outCount"];
								$fdate =  DateTime::createFromFormat("d/m/Y H:i:s", $dt)->format("Y-m-d H:i:s");
								$stmt = $conn->prepare("INSERT IGNORE INTO kpi_value (id_date,master_key,slave_key,library_id,num_val,txt_val) VALUES (?,?,?,?,?,?)");
								$stmt->execute(array($fdate,$mk,  $sn . "|IN", $lid, $in, NULL));
								$stmt->execute(array($fdate,$mk, $sn . "|OUT", $lid, $out, NULL));
							}
							
						}

						break;
						
				}
			}
			echo("Done.\n");
			return TRUE;
		} catch (Exception $ex) {
			echo __METHOD__ . " EXCEPTION: " . $ex->getMessage();
			return FALSE;
		}
	}
}