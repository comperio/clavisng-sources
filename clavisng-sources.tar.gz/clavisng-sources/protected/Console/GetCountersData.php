<?php


// run every x minutes by chron
// */x * * * * /var/www/html/clavisng/clavis-cli all get_counters_data >> /var/log/clavis.log 2>&1
 /*
  * Import into kpi_values people couters data. Counters need to be configurated as resource into clavis.
  * 
  * @author Cristian <ciarez@comperio.it>
  * @version 2.8.2
  * @package Console
  * @since 2.8.2
  */

require_once('ClavisCommandLineAction.php');

/**
 * @package Console
 * @since 2.8.2
 */
class ClavisActionGetCountersData extends ClavisCommandLineAction
{
	//Used on log to help parsing
	const ERRLOGKEY = "PEOPLECOUNTERERR";
	
	private static $supportedModels = array('footfallcloud','footfalldirect');
	protected $action = 'get_counters_data';
	protected $parameters = array();
	protected $optional = array("-fdd/mm/YYYY: 'from' date", "-d: debug");
	protected $description = 'Retrieve data from resources type counter.';
	protected $dbg = FALSE;

	function __construct()
	{
		$this->optional[] = "-mmodel: get data only for specific model only (" . implode("|", self::$supportedModels) .")";
	}
	
	//Logs function to help logging (routing, parsing, ...)
	protected function logDbg($m)
	{
		if($this->dbg)
		{
			echo($m . "\n");
		}
	}
	
	protected function logErr($m)
	{
		echo(self::ERRLOGKEY . " " . $m . "\n");
	}
	
	protected function getCounterLastDataDate($masterKey, $shortName, $libId)
	{
		$ret = FALSE;
		try
		{
			$conn = Propel::getConnection();
			$stmt = $conn->prepare("SELECT MAX(id_date) from kpi_value WHERE master_key=? AND (slave_key = ? OR slave_key = ?) AND library_id=?");
			$stmt->execute(array($masterKey,$shortName.'|IN',$shortName.'|OUT',$libId));
			$x = $stmt->fetchAll(PDO::FETCH_NUM);
			if( ! is_null($x[0][0]) && preg_match('/\d{2}\/\d{2}\/\d{4}/',$x[0][0]) )
			{
				$ret =  DateTime::createFromFormat("Y-m-d H:i:s", $x[0][0])->format("d/m/Y");
				$this->logDbg(__METHOD__ . " Last data date for masterkey: {$masterKey} shortname: {$shortName} libid: {$libId} is {$dStart}\n");
			}
			else
			{
				$this->logDbg(__METHOD__ . " WARNING: no date found for masterkey: {$masterKey} shortname: {$shortName} libid: {$libId}. New counter?");
			}
		}
		catch(Exception $e)
		{
			$this->logErr(__METHOD__ . " exception " . $e->getTraceAsString());
		}
		return $ret;
	}
	
	/*
	 * DEPRECATED, for reference only
	 */
	protected function retrFFV1($ffhost,$counterId,$dStart,$dEnd,$accessToken,$masterKey, $shortName, $libId)
	{
		$conn = Propel::getConnection();
		$timingHour = "AnalyticReportDataByHourinExport";
		$timingDay = "AnalyticReportDataByDayinExport";
		$timingType = $timingHour;
		
		//https://footfallcounter.com/footfallcam/AnalyticReportDataByDayinExport?CameraId=6387&StartDate=31/08/2017&EndDate=31/08/2017&inonly=true&outonly=false&outsidetrafficonly=false&turninrate=false&dwelltime=false&returningandnewcustomer=false&access_token=98XWH4flqTmzNSowJH9z11lQdPvZ/jiiIa5PpVGWHh1u%2bdQEd9d/we5YvXKUV85U
		$url = "{$ffhost}/footfallcam/{$timingType}?CameraId={$id}&StartDate={$dStart}&EndDate={$dEnd}&inonly=true&outonly=true&outsidetrafficonly=false&access_token={$accessToken}";
		$this->logDbg(__METHOD__ . " calling url {$url}\n");
		$jData = file_get_contents($url);
		$j = json_decode($jData,TRUE);
		
		foreach($j["Countings"] as $entry)
		{
			$dt = $entry["ValueDateTimeString"];
			$in = $entry["ValueIn"];
			$out = $entry["ValueOut"];
			
			$stmt = $conn->prepare("INSERT IGNORE INTO kpi_value (id_date,master_key,slave_key,library_id,num_val,txt_val) VALUES (?,?,?,?,?,?)");
			$stmt->execute(array($dt,$masterKey,  $shortName . "|IN", $libId, $in, NULL));
			$stmt->execute(array($dt,$masterKey, $shortName . "|OUT", $libId, $out, NULL));
			
		}
	}
	
	/* 
	 * API since 12/2017 
	 */
	protected function retrFFV2($ffhost,$counterId,$dStart,$dEnd,$accessToken,$masterKey, $shortName, $libId)
	{
		$conn = Propel::getConnection();
		//https://footfallcounter.com/FootfallCam/exportData?infoJson={"cat":"1","id":["4004"],"data":[],"fromdate":"19/12/2017","todate":"19/12/2017","period":"0","dateformat":"dd/MM/yyyy"}&access_token=98XWH4flqTmzNSowJH9z1y3DAYOdLYC2oiFirQP6B3c=
		//$url = "{$ip}/FootfallCam/exportData?infoJson={\"cat\":\"1\",\"id\":[\"{$id}\"],\"data\":[],\"fromdate\":\"{$dStart}\",\"todate\":\"{$dEnd}\",\"period\":\"0\",\"dateformat\":\"yyyy-MM-dd\"}&access_token={$accessToken}";
		/* Fix footfall changes Sept. 2019 */
		$url = "{$ffhost}/FootfallCam/exportData?infoJson={\"cat\":\"1\",\"id\":[\"{$counterId}\"],\"data\":[],\"fromdate\":\"{$dStart}\",\"todate\":\"{$dEnd}\",\"period\":\"0\",\"dateformat\":\"yyyy-MM-dd\",\"timeformat\":\"HH:mm:ss\"}&access_token={$accessToken}";
		$this->logDbg(__METHOD__ . " calling url {$url}\n");
		$jData = file_get_contents($url);
		$j = json_decode($jData,TRUE);
		if( isset($j["Data"]) )
		{
			foreach($j["Data"] as $entry)
			{
				$dt = $entry["DateTime"];
				$in = $entry["ValueIn"];
				$out = $entry["ValueOut"];
				
				$stmt = $conn->prepare("INSERT IGNORE INTO kpi_value (id_date,master_key,slave_key,library_id,num_val,txt_val) VALUES (?,?,?,?,?,?)");
				$stmt->execute(array($dt,$masterKey,  $shortName . "|IN", $libId, $in, NULL));
				$stmt->execute(array($dt,$masterKey, $shortName . "|OUT", $libId, $out, NULL));
				
			}
		}
		else
		{
			$fname = "/tmp/cdata{$counterId}.json";
			file_put_contents($fname, $jData);
			$this->logErr(__METHOD__ . " invalid response from portal. See {$fname}");
		}
	}
	
	protected function retrFFDevice($ffhost,$dStart,$dEnd,$masterKey, $shortName, $libId)
	{
		$conn = Propel::getConnection();
		//http://192.168.1.137/pi-cgi/data.json?date=20170910-20170927
		$url = "{$ffhost}/pi-cgi/data.json?date={$dStart}-{$dEnd}";
		$this->logDbg(__METHOD__ . " calling {$url}\n");
		$jData = file_get_contents($url);
		$j = json_decode($jData,TRUE);
		
		
		foreach($j["data"] as $entry)
		{
			$dt = $entry["time_str"];
			if( strpos($dt, "00:00") !== FALSE)
			{
				$in = $entry["inCount"];
				$out = $entry["outCount"];
				$fdate =  DateTime::createFromFormat("d/m/Y H:i:s", $dt)->format("Y-m-d H:i:s");
				$stmt = $conn->prepare("INSERT IGNORE INTO kpi_value (id_date,master_key,slave_key,library_id,num_val,txt_val) VALUES (?,?,?,?,?,?)");
				$stmt->execute(array($fdate,$masterKey,  $shortName . "|IN", $libId, $in, NULL));
				$stmt->execute(array($fdate,$masterKey, $shortName . "|OUT", $libId, $out, NULL));
			}
			
		}
	}

	public function performAction($args)
	{
		try
		{
			$reqModel= FALSE;
			$reqDate = FALSE;
			/*
			$narg = count($args);
			
			switch($narg)
			{
				// 2 PARAM: specific model from date
				case 3:
					if( in_array( $args[1], self::$supportedModels ) )
					{
						$reqModel = $args[1];
						$this->logDbg("Get data for model {$args[1]} only\n");
					}
					else
					{
						$this->logErr("WARNING: Model {$args[1]} is not supported\n");
					}
					if(preg_match('/\d{2}\/\d{2}\/\d{4}/',$args[2]))
					{
						$reqDate = $args[2];
					}
					else
					{
						$this->logErr("WARNING: date malformed, please use dd/mm/yyyy\n");
					}
					break;
				// 1 PARAM: Specific model OR from date
				case 2:
					if( in_array( $args[1], self::$supportedModels ) )
					{
						$reqModel = $args[1];
						$this->logDbg("Get data for model {$reqModel} only\n");
					}
					else
					{
						if(preg_match('/\d{2}\/\d{2}\/\d{4}/',$args[1]))
						{
							$reqDate = $args[1];
						}
						else
						{
							$this->logErr("WARNING: date {$reqDate} malformed. Use d/m/Y\n");
						}
					}
			}*/
			
			foreach($args as $p)
			{
				if($p == "-d")
				{
					$this->dbg = TRUE;
					continue;
				}
				
				if($p == "-h")
				{
					echo("\nOptional params:\n" . implode("\n", $this->optional) . "\n\n");
					return TRUE;
				}
				
				if( strncmp($p, "-f", 2) === 0 )
				{
					$pdata = str_replace("-f", "", $p);
					if(preg_match('/\d{2}\/\d{2}\/\d{4}/',$pdata))
					{
						$reqDate = $pdata;
					}
					else
					{
						$this->logErr("WARNING: date {$pdata} malformed. Use d/m/Y\n");
					}
				}
				
				if( strncmp($p, "-m", 2) === 0 )
				{
					$pdata = str_replace("-m", "", $p);
					if( in_array( $pdata, self::$supportedModels ) )
					{
						$reqModel = $pdata;
						$this->logDbg("Get data for model {$reqModel} only");
					}
					else
					{
						$this->logErr("WARNING: Model {$pdata} is not supported\n");
					}
				}
			}
			
			
			$counters = ResourceQuery::create()
				->findByType(Resource::TYPE_PEOPLECOUNTER);
			foreach ($counters as $counter)
			{
				/*
				 * Name is used to store multiple values like
				 * model|url or ip|id
				 */
				$cstring = $counter->getName();
				$mk = $counter->getType();
				$sn = $counter->getShortname();
				$lid = $counter->getLibraryId();
				$carray = explode("|", $cstring);
				$model = $carray[0];
				if($reqModel !== FALSE && $reqModel != $model)
				{
					continue;
				}
				$ip = $carray[1];
				$id = $carray[2];
				
				
				/*
				 * 2020-10-23 workaround for new footfall API token
				 * Take access token from big unused text field wellcomeurl
				 * if empty, fallback to old field
				 * @see protected/Common/Widgets/ClavisResourceEdit.php
				 */
				$accessToken = $counter->getWellcomeUrl();
				if( is_null($accessToken) || trim($accessToken) == '' )
				{
					$accessToken = $counter->getSecret();
				}
				
				//$dStart = date("d/m/Y");
				$dtStart = new DateTime();
				$dtStart->sub(new DateInterval("P1D"));
				//default date "from" is yesterday
				$dStart = $dtStart->format("d/m/Y");
				if( $reqDate === FALSE )
				{
					$lastDataDate = $this->getCounterLastDataDate($mk,$sn,$lid);
					if( $lastDataDate !== FALSE )
					{
						$dStart = $lastDataDate;
					}
				}
				else
				{
					$dStart = $reqDate;
				}
				//default "to" date is today
				$dEnd = date("d/m/Y");
				
				echo("Retrieve data for resource id {$counter->getResourceId()} '{$sn}' library {$lid} from {$dStart} to {$dEnd}\n");
				switch($model)
				{
					case "footfallcloud":						
						$this->retrFFV1($ip,$id,$dStart,$dEnd,$accessToken,$mk,$sn,$lid);
						break;
						
					case "footfallcloudv2":	
						$this->retrFFV2($ip,$id,$dStart,$dEnd,$accessToken,$mk,$sn,$lid);
						//Every 10 of the month
						$dom = date("j");
						if( $dom == "10" )
						{
							//re-retrieve all prev month data to fix date hole issues
							$dtFom = new DateTime();
							$dtFom->sub(new DateInterval("P1M"));
							//first of prev month
							$sStart = "01/" . $dtFom->format("m/Y");
							//last of prev month
							$sEnd = $dtFom->format("t/m/Y");
							echo("{$dom} of month detected. Retrieve also data from {$sStart} to {$sEnd}\n");
							$this->retrFFV2($ip,$id,$sStart,$sEnd,$accessToken,$mk,$sn,$lid);
						}
						break;
						
					case 'footfalldirect':
						$this->retrFFDevice($ip,$dStart,$dEnd,$mk,$sn,$lid);
						break;
				}
				echo("resource id {$counter->getResourceId()} '{$sn}' library {$lid} done.\n\n");
			}
			echo("Done.\n");
			return TRUE;
		} catch (Exception $ex) {
			$this->logErr(__METHOD__ . " EXCEPTION: " . $ex->getMessage());
			return FALSE;
		}
	}
}