<?php
/**
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Console
 * @since 2.5.0
 */
require_once('ClavisCommandLineAction.php');

/**
 * @package Console
 * @since 2.5.0
 */
class ClavisActionSbnBatchSync extends ClavisCommandLineAction
{
	protected $action = 'sbn_batch_sync';
	protected $parameters = array('sync|update_sbnz|update_relatorcode|sync_authorities|fixnotes');
	protected $optional = array();
	protected $description = 'A list of actions meant to simplify SBN compliance for the installation.';

    /** @var  $_sbnMod ClavisSBN */
	private $_sbnMod;

	public function performAction($args)
	{
		$action = $args[1];

		$this->_sbnMod = Prado::getApplication()->getModule('sbn');

		switch ($action) {
			case 'update_relatorcode':
				$this->updateRelatorCode();
				break;
			case 'update_sbnz':
				$this->updateSBNzBids();
				break;
			case 'sync_authorities':
				$this->syncAuthorities();
				break;
			case 'fixnotes':
				$this->fixNotes();
				break;
			case 'sync':
				$this->sync();
				break;
            case 'test':
                $this->testDoc();
                break;
			case 'info':
				$this->info($args[2]);
				break;
            default:
                print "Azione sconosciuta o assente\n";
                break;
		}

		echo "\n------------------------------------------------------------------------------------------------\n";
		echo "\n#### ALL DONE!!! ####\n";
		return true;
	}


	public function info($bid)
	{
		$search = array(

			"BID" => $bid,
			"tipoOggetto" => "Materiale",
			"Oggetto" => "M",
			'tipoInfo' => 'Tutti',
			'tipoOperazione' => 'Localizza'
		);
		$req = $this->_sbnMod->getNewRequest();
        $idPolo = $this->_sbnMod->getNodePrefix();

		$resp = $req->searchLocalizationStatus($search);
		$res = (string)$resp->SbnMessage->SbnResponse->SbnResult->esito;
		if($res == "0000") {
			foreach($resp->SbnMessage->SbnResponse->SbnOutput->LocalizzaInfo->T899 as $l) {
                $tipoLoc = $l['tipoInfo'];
                $bibName = (string)$l->a_899;
                $bibId = (string)$l->c1_899;
                $bibCode = (string)$l->c2_899;
                if(substr($bibCode,0,3) == $idPolo)
                    print "($tipoLoc) => $bibId [$bibCode] = $bibName \n";
            }
				//print_r($l);
		}


	}

	public function testDoc()
	{
		$conn = Propel::getConnection();

		$cc1 = 0;
		$cc2 = 0;
		$t1 = time();

		foreach ($conn->query("SELECT manifestation_id FROM manifestation WHERE bid_source = 'SBN' and (last_sbn_sync IS NULL OR last_sbn_sync <= '2013-04-01')") as $mid)
		{
			$man = ManifestationQuery::create()->findPk($mid[0]);
			$sbnRecord = $this->_sbnMod->getNewRequest()->searchTitleByBid($man->getBid(), SBNTypes::OUTPUT_SINTMIN);
			$mbid = $man->getBid();

			$cc1 ++;
			if($cc1 % 1000 == 0) {
				$t = time() - $t1;
				print "Velocità " . ($cc1 / $t) . " rec/s\n";
			}

			if (!isset($sbnRecord->SbnMessage->SbnResponse->SbnResult->esito)
				|| '0000' != $sbnRecord->SbnMessage->SbnResponse->SbnResult->esito)
			{
				$res = "NOT FOUND " . (string)$sbnRecord->SbnMessage->SbnResponse->SbnResult->testoEsito;
				$cc2++;
				print "Processing BID $mbid [{$res}] Processati: $cc1 - Non trovati: $cc2\n";
			}
			else
			{
				$res = "OK";
				//continue;
				$newtm = SBNConverter::SBN2Turbomarc($sbnRecord);

				

				//print "Processing BID $mbid [{$res}] Processati: $cc1 - Non trovati: $cc2\n";
			}


			
		}
	}


    public function testAuth()
    {
		$con = Propel::getConnection();
		foreach($con->query("
			SELECT bid, authority_type, authority_id
			FROM authority a
			WHERE true
			AND a.bid_source = 'SBN'
			AND (a.bid like ('___V%') OR a.bid like ('___L%') OR a.bid like ('___M%'))

		") as $r) {
			$search = array(

				"BID" => $r['bid'],
				"tipoOggetto" => "Materiale",
				"Oggetto" => "M",
				'tipoInfo' => 'Tutti',
				'tipoOperazione' => 'Localizza'
			);
            $objType = SBNConverter::ClavisType2SBNType($r['authority_type']);
            $sbnRecord = $this->_sbnMod->getNewRequest()->searchAuthorityByBid($r['bid'], $objType);
            if (!isset($sbnRecord->SbnMessage->SbnResponse->SbnResult->esito) || '0000' != $sbnRecord->SbnMessage->SbnResponse->SbnResult->esito) {
                $res = "NOT FOUND " . (string)$sbnRecord->SbnMessage->SbnResponse->SbnResult->testoEsito;
            } else {
                $res = "OK";
                $newtm = SBNConverter::SBN2Turbomarc($sbnRecord);
                if (isset($newtm->r))
                    $newtm = $newtm->r;

                $object = AuthorityQuery::create()->findPk($r['authority_id']);

                $object->updateFromTurbomarc($newtm);
                if ($object->getLastSbnSync())
                    $object->setLastSbnSync(time());
                $object->save();
                $req = $this->_sbnMod->getNewRequest();
                $update = array(
                    'objClass'	=> SBNTypes::OBJCLASS_AUT,
                    'objType'	=> (string)$newtm->d099->sd,
                    'bid'		=> $object->getBid()
                );
                $req->sendUpdated(array($update));
            }
			//$resp = $req->searchLocalizationStatus($search);
			//$res = (string)$resp->SbnMessage->SbnResponse->SbnResult->testoEsito;
            print "ID: {$r['authority_id']} BID:{$r['bid']} = $res \n";
		}
    }

    private function _localize($sbnClass, $sbnType, $bid, $object=null)
    {
        // since the localization is "manage", we always use default library code for the node.
        $elements = array(
            array(
                'class'	=> $sbnClass,
                'type'	=> $sbnType,
                'bid'	=> $bid,
                'items'	=> array(array(
                    'libSBNCode'		=> $this->_sbnMod->getLibraryCode(),
                ))
            )
        );

        $req = $this->_sbnMod->getNewRequest();
        $sbn_response = $req->localize($elements,SBNTypes::LOCACTION_LOCALIZE,SBNTypes::LOCTYPE_MANAGE);
        if ('0000' == $sbn_response->SbnMessage->SbnResponse->SbnResult->esito) {
            if($object != null) {
                $detail = SBNConverter::SBN2Turbomarc($this->getSBNDetail((string)$bid, $object));
                if (isset($detail->r))
                    $detail = $detail->r;
                $tm = $object->getTurboMarc();
                unset($tm->d099);
                $tm->appendNode($detail->d099);
                $object->setUnimarc($tm->asXML());
                $object->setLastSbnSync(SBNConverter::SBNTimestamp2DateTime((string)$tm->d099->s5));
                // sync
                $detail = TurboMarcUtility::sortFields($detail);
                list($newtm,) = SBNConverter::getTurbomarcSBNDiff($object->getFullTurboMarc(false), $detail);
                $object->updateFromTurbomarc($newtm);
                $object->save();
                $object->reload();
            }
            return true;
        } else {
            throw new Exception($sbn_response->SbnMessage->SbnResponse->SbnResult->testoEsito);
        }
    }

    protected function getSBNDetail($bid, $object) {
        try {
            if ($object instanceof Manifestation)
                $detail = $this->_sbnMod->getNewRequest()->searchTitleByBid((string)$bid);
            else if ($object instanceof Authority)
                $detail = $this->_sbnMod->getNewRequest()->searchAuthorityByBid((string)$bid,SBNConverter::ClavisType2SBNType($object->getAuthorityType()));
            return $detail;
        } catch (Exception $e) {
            return null;
        }
    }

	public function updateSBNzBids()
	{
		$sql = 'UPDATE IGNORE '.ManifestationPeer::TABLE_NAME.' SET '.ManifestationPeer::BID_SOURCE.'=\'SBN\','
			.ManifestationPeer::BID."=REPLACE(REPLACE(".ManifestationPeer::BID.",'\\\\',''),'ITICCU','') WHERE "
			.ManifestationPeer::BID_SOURCE.'=\'SBNz\'';
		Propel::getConnection()->exec($sql);
		$sql = 'UPDATE IGNORE '.AuthorityPeer::TABLE_NAME.' SET '.AuthorityPeer::BID_SOURCE.'=\'SBN\','
			.AuthorityPeer::BID."=REPLACE(REPLACE(".AuthorityPeer::BID.",'\\\\',''),'ITICCU','') WHERE "
			.AuthorityPeer::BID_SOURCE.'=\'SBNz\'';
		Propel::getConnection()->exec($sql);
	}

	public function updateRelatorCode()
	{
		$sql = 'UPDATE IGNORE '.LAuthorityManifestationPeer::TABLE_NAME.' SET '
			.LAuthorityManifestationPeer::RELATOR_CODE.'=\'070\' WHERE '
			.LAuthorityManifestationPeer::RELATOR_CODE."='000' AND "
			.LAuthorityManifestationPeer::LINK_TYPE.' BETWEEN \'700\' AND \'722\'';
		Propel::getConnection()->exec($sql);
	}

	public function syncAuthorities()
	{

		$auth_no_sync = array(AuthorityPeer::TYPE_WORK, AuthorityPeer::TYPE_CLASS, AuthorityPeer::TYPE_SUBJECT);
		$alist = AuthorityQuery::create()
			->filterByAuthorityType($auth_no_sync, Criteria::NOT_IN)
			->filterByBidSource('SBN')
			->filterByLastSbnSync(null)
            //->filterByBid("CFIL001357")
			->setFormatter('PropelOnDemandFormatter')
            ->limit(10000)
			->find();

        $counter = 0;
		/* @var $a Authority */
		foreach ($alist as $a) {
            $counter++;
			echo "\n{$counter} - Processing [{$a->getAuthorityId()}] with BID [{$a->getBid()}]...";
			try {
				$req = $this->_sbnMod->getNewRequest();
				$ret = $req->searchAuthorityByBid($a->getBid(),SBNConverter::ClavisType2SBNType($a->getAuthorityType()));
				if ($ret && '0000' == $ret->SbnMessage->SbnResponse->SbnResult->esito) {
					$sbndoc = SBNConverter::SBN2Turbomarc($ret,true);
				} else {
					$a->setLastSbnSync('1903-01-01');
					$a->save();
                    $esito = (string)$ret->SbnMessage->SbnResponse->SbnResult->esito;
					echo "[ERROR:{$esito}] not found in index!!!";
					$a->clearAllReferences(true);
					unset($a);
					unset($sbndoc);
					unset($req);
					unset($ret);
					continue;
				}
				$sbnTurbomarc = TurboMarcUtility::sortFields($sbndoc);
				$myTurbomarc = TurboMarc::createRecord($a->cacheTurboMarc())->sortFields();
				list($newtm,$ret) = SBNConverter::getTurbomarcSBNDiff($myTurbomarc,$sbnTurbomarc);
                $res = $this->updateSBNObject($a,$newtm);
                if($res == "3001" ) // Non localizzato
                {
                    $sbnClass = SBNTypes::OBJCLASS_AUT;
                    $sbnType = SBNConverter::ClavisType2SBNType($a->getAuthorityType());
                    $this->_localize($sbnClass,$sbnType,$a->getBid());
                    $res = $this->updateSBNObject($a,$newtm);
                }
                if($res == "0000") {
                    $a->updateFromTurbomarc($newtm);
                    $a->setLastSbnSync(time());
                    $a->save();
                    echo "updated! ";
                }
				$a->clearAllReferences(true);
				unset($a);
				unset($sbndoc);
				unset($sbnTurbomarc);
				unset($myTurbomarc);
				unset($newtm);
				unset($req);
				unset($ret);
                unset($res);
			} catch (Exception $e) {
				echo $e->getMessage();
			}
		}
	}

	protected function updateSBNObject($object,$newtm)
    {
        // send update to SBN
        $req = $this->_sbnMod->getNewRequest();
        if ($object instanceof Manifestation)
        {
            $update = array(
                'objClass'	 => SBNTypes::OBJCLASS_DOC,
                'objType'	 => (string) $newtm->d099->sb,
                'bid'		 => $object->getBid()
            );
        }
        else if ($object instanceof Authority)
        {
            $update = array(
                'objClass'	 => SBNTypes::OBJCLASS_AUT,
                'objType'	 => (string) $newtm->d099->sd,
                'bid'		 => $object->getBid()
            );
        }
        $res = $req->sendUpdated(array($update));
        $esito = (string)$res->SbnMessage->SbnResponse->SbnResult->esito;

        if($esito != "0000") {
            print " ESITO ALLINEA [{$esito}]\n";
            print_r($req->sbnMarc->asXML());
            print_r($res->asXML());

        }
        return $esito ;
    }

	protected function fixNotes()
	{
		$notes = array_keys(LookupValuePeer::getLookupClassValues('UNI3XX'));
		$conn = Propel::getConnection();
		$stmt_update_cache = $conn->prepare('UPDATE '.TurbomarcCachePeer::TABLE_NAME.
				' SET '.TurbomarcCachePeer::TURBOMARC.'=NULL,'.TurbomarcCachePeer::DIRTY.'=1 WHERE '.
				TurbomarcCachePeer::MANIFESTATION_ID.' IN (SELECT '.
				ManifestationPeer::MANIFESTATION_ID.' FROM '.ManifestationPeer::TABLE_NAME.
				' WHERE '.ManifestationPeer::UNIMARC.' LIKE ?)');
		$stmt_update_note = $conn->prepare('UPDATE '.ManifestationPeer::TABLE_NAME.' SET '.ManifestationPeer::UNIMARC.
			'=REPLACE(REPLACE('.ManifestationPeer::UNIMARC.',?,\'<d300\'),?,\'</d300>\')');
		$skiplist = array(300,323,327,330,336,337);
		foreach($notes as $i) {
			if (in_array($i, $skiplist))
				continue;
			echo "\nReplacing note [{$i}]...";
			$stmt_update_cache->execute(array("%</d{$i}>%"));
			$stmt_update_note->execute(array("<d{$i}","</d{$i}>"));
		}
	}

	public function sync()
	{
		ini_set('memory_limit','1024M');
		$auto_sync_edit_types = array('Dati','Legami','Dati e Legami', 'Natura');

		// retrieve sync data for documents
		$req = $this->_sbnMod->getNewRequest();
		$req->setSearchOutputType(SBNTypes::OUTPUT_COMPLETE);
		$ret = $req->getUpdates(SBNTypes::OBJCLASS_DOC,SBNTypes::DOCTYPE_TUTTI);
		if ($ret && '0000' == $ret->SbnMessage->SbnResponse->SbnResult->esito) {
			foreach ($ret->SbnMessage->SbnResponse->SbnOutput->AllineaInfo as $item) {
				// skip TitAccesso, ElementoAut and edits that are not in
				if (isset($item->oggettoVariato->Documento->DatiTitAccesso)
						|| isset($item->oggettoVariato->ElementoAut)
						|| !in_array((string)$item->oggettoVariato['tipoModifica'], $auto_sync_edit_types))
					continue;
				$sbnTurbomarc = SBNConverter::SBN2Turbomarc($item->oggettoVariato);
				$obj = ManifestationPeer::getOneByBid('SBN', (string)$item->T001);
				if (!$obj instanceof Manifestation) {
					echo "\nBID [{$item->T001}] NOT FOUND! Skipping...";
					continue;
				} else {
					echo "\nSyncing BID [{$item->T001}]...";
				}
				$sbnTurbomarc = TurboMarcUtility::sortFields($sbnTurbomarc);
				$myTurbomarc = TurboMarc::createRecord($obj->cacheTurboMarc())->sortFields();
				list($newtm,) = SBNConverter::getTurbomarcSBNDiff($myTurbomarc,$sbnTurbomarc);
				$obj->updateFromTurbomarc($newtm);
				$obj->setLastSbnSync(time());
				$obj->save();
				$update = array(
					'objClass'	=> SBNTypes::OBJCLASS_DOC,
					'objType'	=> (string)$newtm->d099->sb,
					'bid'		=> $obj->getBid()
				);
				$req = $this->_sbnMod->getNewRequest();
				$req->sendUpdated(array($update));
				echo "done!";
				$obj->clearAllReferences(true);
				unset($obj);
				$sbnTurbomarc = $myTurbomarc = null;
			}
		}

		// retrieve sync data for authorities
		foreach (SBNTypes::getAuthorityTypes() as $type) {
			$req = $this->_sbnMod->getNewRequest();
			$req->setSearchOutputType(SBNTypes::OUTPUT_COMPLETE);
			$ret = $req->getUpdates(SBNTypes::OBJCLASS_AUT,$type);
			if ($ret && '0000' == $ret->SbnMessage->SbnResponse->SbnResult->esito) {
				foreach ($ret->SbnMessage->SbnResponse->SbnOutput->AllineaInfo as $item) {
					// skip TitAccesso, ElementoAut and edits that are not in
					if (!in_array((string)$item->oggettoVariato['tipoModifica'], $auto_sync_edit_types))
						continue;
					$sbnTurbomarc = SBNConverter::SBN2Turbomarc($item->oggettoVariato);
					$obj = AuthorityPeer::getOneByBid('SBN', (string)$item->T001);
					if (!$obj instanceof Authority) {
						echo "\nBID [{$item->T001}] NOT FOUND! Skipping...";
						continue;
					} else {
						echo "\nSyncing BID [{$item->T001}]...";
					}
					$sbnTurbomarc = TurboMarcUtility::sortFields($sbnTurbomarc);
					$myTurbomarc = TurboMarc::createRecord($obj->cacheTurboMarc())->sortFields();
					list($newtm,) = SBNConverter::getTurbomarcSBNDiff($myTurbomarc,$sbnTurbomarc);
					$obj->updateFromTurbomarc($newtm);
					$obj->setLastSbnSync(time());
					$obj->save();
					$update = array(
						'objClass'	=> SBNTypes::OBJCLASS_AUT,
						'objType'	=> (string)$newtm->d099->sd,
						'bid'		=> $obj->getBid()
					);
					$req = $this->_sbnMod->getNewRequest();
					$req->sendUpdated(array($update));
					echo "done!";
					$obj->clearAllReferences(true);
					unset($obj);
					$sbnTurbomarc = $myTurbomarc = null;
				}
			}
		}
	}
}
