<?php

/**
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Console
 * @since 2.5.0
 */

require_once('ClavisCommandLineAction.php');

/**
 * @package Console
 * @since 2.5.0
 */
class ClavisActionSyncUsersImt extends ClavisCommandLineAction
{
	protected $action = 'sync_users_imt';
	protected $parameters = array();
	protected $optional = array('xml_file');
	protected $description = "Synchronization script for IMT Lucca users. Optional parameter defines the XML file path (or address), defaults to http://dev.imtlucca.it/library/clavis/users_list.xml.";

	public function performAction($args)
	{
		$IMTXML_ADDRESS = (isset($args[1])) ?
			$args[1] : 'http://dev.imtlucca.it/library/clavis/users_list.xml';

		$title_map = array(
			''	=> null,
			'Prof.'		=> 'T1',
			'Dott.'		=> 'T2',
			'Dott.ssa'	=> 'T3',
			'Prof.ssa'	=> 'T4',
		);

		$work_map = array(
			''	=> null,
			'Full Professor'		=> 1,
			'Associate Professor'	=> 2
		);

		$doc_map = array(
			''	=> null,
			'Identity Card'	=> 'IC',
		);

		$xml = simplexml_load_file($IMTXML_ADDRESS);

		foreach ($xml as $identity) {
			$id = intval($identity->id_people);
			if ($id < 1)
				continue;
			/** @var $p Patron */
			$patrons = PatronPeer::retrieveByBarcode($id);
			if (count($patrons) > 1)
				print "\nDUPLICATED BARCODE $id FOUND!!!";
			if (count($patrons) < 1 || ! $patrons[0] instanceof Patron) {
				$p = new Patron();
				$p->setBarcode($id);
			} else {
				$p = $patrons[0];
			}
			$p->setCardCode($id);
			$p->setName($identity->FirstName);
			$p->setLastname($identity->LastName);
			$p->setTitle($title_map[trim($identity->Title)]);
			$p->setStatisticWork($work_map[trim($identity->Role)]);
			$p->setCitizenship($identity->Citizenship);
			$p->setBirthCity($identity->CityOfBirth);
			$p->setBirthProvince($identity->DistrictOfBirth);
			$p->setBirthCountry($identity->NationOfBirth);
			$p->setBirthDate(new DateTime("{$identity->Birth_YYYY}-{$identity->Birth_MM}-{$identity->Birth_DD}"));
			$p->setGender($identity->Gender_FM);
			$p->setDocumentType($doc_map[trim($identity->DocumentTypeName)]);
			$p->setDocumentNumber($identity->IdentityDocNr);
			$p->setRegistrationLibraryId(1);
			$p->setPreferredLibraryId(1);
			$p->setPatronStatus('A');
			$p->save();
			$p->clearAllReferences(true);

			foreach ($p->getAddresss() as $addr)
				$addr->delete();

			foreach($identity->address as $address) {
				$a = new Address();
				$a->setPatronId($p->getPatronId());
				if ($address->PermanentOrMailing_PM == 'P')
					$a->setAddressType('R');
				if ($address->PermanentOrMailing_PM == 'M')
					$a->setAddressType('D');
				$a->setCity($address->City);
				$a->setCountry($address->Nation);
				$a->setProvince($address->District);
				$a->setStreet($address->StreetName);
				$a->setStreetNum($address->StreetNr);
				$a->setZip($address->ZipCode);
				$a->save();
				$a->clearAllReferences(true);
			}

			foreach($identity->email_address as $email) {
				$value = trim($email->email);
				$cs = ContactQuery::create()
					->filterByContactType(ContactPeer::TYPE_EMAIL)
					->filterByPatronId($p->getPatronId())
					->findByContactValue($value);
				if ($cs->count() != 1 || ! $cs[0] instanceof Contact) {
					$cont = new Contact();
					$cont->setPatronId($p->getPatronId());
					$cont->setContactType('E');
				} else {
					$cont = $cs[0];
				}
				$cont->setContactValue($value);
				$cont->save();
				$cont->clearAllReferences(true);
			}
		}
		echo "\n#### ALL DONE!!! ####\n";
		return true;
	}
}