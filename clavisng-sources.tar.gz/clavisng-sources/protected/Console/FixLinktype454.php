<?php

/**
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Console
 * @since 2.5.0
 */

require_once('ClavisCommandLineAction.php');

/**
 * @package Console
 * @since 2.5.0
 */
class ClavisActionFixLinktype454 extends ClavisCommandLineAction
{
	protected $action = 'fix_linktype454';
	protected $parameters = array();
	protected $optional = array();
	protected $description = "Transforms all authority-manifestation 454 links into titles (embedded in manifestation) and deletes links.";

	public function performAction($args)
	{
		$links = LAuthorityManifestationQuery::create()
			->filterByLinkType(454)
			->setFormatter(ModelCriteria::FORMAT_ON_DEMAND)
			->find();

		foreach ($links as $l) {
			/* @var $l LAuthorityManifestation */
			/* @var $m Manifestation */
			$m = $l->getManifestation();
			/* @var $w Authority */
			$w = $l->getAuthority();
			$tm = $m->getTurboMarc();
			try {
				$f509 = $tm->addField('509')->addSubField('a',$w->getCompleteText());
				$m->setUnimarc($tm->asXML());
				$m->save();
				// now delete link
				$l->delete();
				print "\nFixed title [{$w->getCompleteText()}] for manifestation {$m->getManifestationId()}";
				// free mem
				$m->clearAllReferences(true);
				$w->clearAllReferences(true);
				$l->clearAllReferences(true);
			} catch (Exception $e) {
				print "\nEXCEPTION: {$e->getMessage()}\n";
				throw $e;
			}
		}

		echo "\n#### ALL DONE!!! ####\n";
		return true;
	}
}