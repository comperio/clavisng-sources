<?php

/**
 *
 *
 * @author Ciro Mattia Gonano
 * @version $Id: Import.php 10495 2012-11-28 14:12:48Z ciro $
 * @package Console
 * @since 2.5.0
 */

require_once('ClavisCommandLineAction.php');

/**
 * @package Console
 * @since 2.5.0
 */
class ClavisActionImportUnimarc extends ClavisCommandLineAction
{
    const UNIMARC_RECORDEND = "\x1d";
    const UNIMARC_FIELDEND = "\x1e";
    const UNIMARC_SUBFIELDEND = "\x1f";

    protected $action = 'importunimarc';
    protected $parameters = array('action', 'file');
    protected $optional = array();
    protected $description = 'Imports Turbomarc collection from a file; if file is an URL tries to get the contents.';

    protected $fileIn;
    protected $fileFormat;


    public function performAction($args)
    {
        libxml_use_internal_errors(true);
        $ret = false;
        $params = $this->parseArgs($args);
        switch ($params['a']) {
            case "stat":
                $ret = $this->statAction($params);
                break;

            case "2turbomarc":
                $ret = $this->convertToTurboMarc($params);
                break;
            case "import":
                $ret = $this->importAction($params);
                break;
            case "testxsl":
                $ret = $this->testXslAction($params);
                break;
            case "seeauthority":
                $ret = $this->seeAuthorityAction($params);
                break;
            case "makelinks":
                $ret = $this->makeLManLinks($params);
                break;
        }

        return $ret;
    }

    private function statAction($params)
    {
        $utfconv = false;
        $unitrans = false;
        $charset = "AUTO";

        if (isset($params['i'])) {
            if ($params['i'] == "UTF-8") {
                $utfconv = false;
                $unitrans = false;
                $charset = "AUTO";
            } else if ($params['i'] == "UNIMARC") {
                $utfconv = false;
                $unitrans = true;
                $charset = "AUTO";
            } else {
                $utfconv = true;
                $unitrans = false;
                $charset = $params['i'];
            }
        }

        $stats = array("Record counter" => 0, "No bid" => 0, "No 200" => 0);

        $this->openFile($params['file'], $params['format']);
        while ($rawRecord = $this->readNextRecord()) {
            try {
                $record = $this->parseRecord($rawRecord, $utfconv, $unitrans, $charset);
                $stats["Record counter"]++;
                if (!isset($record->c001)) $stats['No bid']++;
                if (!isset($record->d200)) $stats['No 200']++;

                //print (string)$record->c001 . " " . (string)$record->d702->sr  . "\n";
                print (string)$record->d702->sr . "\n";
            } catch (Exception $e) {
                print "ERR:" . $e->getMessage() . "\n $rawRecord\n";
            }
        }

        foreach ($stats as $label => $value)
            print "$label: $value\n";

        return TRUE;
    }

    private function seeAuthorityAction($params)
    {
        $this->openFile($params['file'], $params['format']);

        if (isset($params['xsl'])) {
            $xsl = new DOMDocument;
            $xsl->load($params['xsl']);

            $proc = new XSLTProcessor();
            $proc->importStyleSheet($xsl);
        } else {
            $proc = null;
        }

        $utfconv = false;
        $unitrans = false;
        $charset = "AUTO";

        if (isset($params['i'])) {
            if ($params['i'] == "UTF-8") {
                $utfconv = false;
                $unitrans = false;
                $charset = "AUTO";
            } else if ($params['i'] == "UNIMARC") {
                $utfconv = false;
                $unitrans = true;
                $charset = "AUTO";
            } else {
                $utfconv = true;
                $unitrans = false;
                $charset = $params['i'];
            }
        }

        $rcounter = 0;
        $m1time = microtime(true);

        while ($rawRecord = $this->readNextRecord()) {
            try {
            $record = $this->parseRecord($rawRecord, $utfconv, $unitrans, $charset);
            } catch(Exception $e) {
                print "Errore di parsing XML: " . $e->getMessage()."\n";
                print "---raw----\n{$rawRecord}\n---------raw------\n";
               // die();
            }
            $rcounter++;

            if ($rcounter % 1000 == 0) {
                $m2time = microtime(true);
                print("Speed: " . (1000.0 / ($m2time - $m1time)) . " rec/s [record $rcounter] [" . ($m2time - $m1time) . "]\n");
                $m1time = $m2time;
            }

            if ($proc != null) {
                $xml = dom_import_simplexml($record);
                $txml = $proc->transformToXML($xml);
                $tm = TurboMarc::createRecord($txml);

            } else
                $tm = $record;

            if(isset($tm->d799))
                foreach($tm->d799 as $f799) {
                    $auth1 = (string)$f799->sa;
                    $auth2 = (string)$f799->sb;

                    $accepted = AuthorityQuery::create()
                        ->filterByFullText($auth2)
                        ->filterByAuthorityRectype(AuthorityPeer::RECTYPE_ACCEPTED)
                        ->filterByAuthorityType(array(AuthorityPeer::TYPE_PERSONALNAME, AuthorityPeer::TYPE_CORPORATEBODYNAME))
                        ->findOne();

                    $variant = AuthorityQuery::create()
                        ->filterByFullText($auth1)
                        ->filterByAuthorityRectype(AuthorityPeer::RECTYPE_VARIANT)
                        ->filterByAuthorityType(array(AuthorityPeer::TYPE_PERSONALNAME, AuthorityPeer::TYPE_CORPORATEBODYNAME))
                        ->find();

                    if($accepted instanceof Authority && count($variant) == 0) {
                        // Create new Variant authority
                        $auth = new Authority();
                        $auth->setAuthorityType($accepted->getAuthorityType());
                        $auth->setSortText($auth1);
                        $auth->setAuthorityRectype(AuthorityPeer::RECTYPE_VARIANT);
                        $auth->setAuthorityCodLevel(05);
                        $auth->setAuthorityStatus(AuthorityPeer::INTERNALSTATUS_REVIEW);
                        $auth->save();

                        $la = new LAuthority();
                        $la->setAuthorityIdUp($auth->getAuthorityId());
                        $la->setAuthorityIdDown($accepted->getAuthorityId());
                        $la->setLinkType("54");
                        $la->save();

                        $la->clearAllReferences(true);
                        $auth->clearAllReferences(true);

                    } else {
                        print "Anomalia!\n";
                        print "Accettate: " .count($accepted) ."\n";
                        print "Variante: " .count($variant) ."\n";
                    }
                }

        }
    }

    private function testXslAction($params)
    {

        $this->openFile($params['file'], $params['format']);

        if (isset($params['xsl'])) {
            $xsl = new DOMDocument;
            $xsl->load($params['xsl']);

            $proc = new XSLTProcessor();
            $proc->importStyleSheet($xsl);
        } else {
            $proc = null;
        }

        if (isset($params['bidsrc']))
            $bidsource = $params['bidsrc'];
        else
            $bidsource = "IMP-" . date('Ymd');

        $utfconv = false;
        $unitrans = false;
        $charset = "AUTO";

        if (isset($params['i'])) {
            if ($params['i'] == "UTF-8") {
                $utfconv = false;
                $unitrans = false;
                $charset = "AUTO";
            } else if ($params['i'] == "UNIMARC") {
                $utfconv = false;
                $unitrans = true;
                $charset = "AUTO";
            } else {
                $utfconv = true;
                $unitrans = false;
                $charset = $params['i'];
            }
        }
        if (isset($params['shelf']))
            $shelf = ShelfPeer::retrieveByPK(intval($params['shelf']));
        else
            $shelf = null;

        $rcounter = 0;
        $m1time = microtime(true);

        if(isset($params['outdir']))
            $outdir = $params['outdir'];
        else
            $outdir = ".";

        while ($rawRecord = $this->readNextRecord()) {
            try {
                $record = $this->parseRecord($rawRecord, $utfconv, $unitrans, $charset);
                $rcounter++;

                if ($rcounter % 10 == 0) {
                    $m2time = microtime(true);
                    print("Speed: " . (10.0 / ($m2time - $m1time)) . " rec/s [record $rcounter] [" . ($m2time - $m1time) . "]\n");
                    $m1time = $m2time;
                }

                if ($proc != null) {
                    $xml = dom_import_simplexml($record);
                    $txml = $proc->transformToXML($xml);
                    $tm = TurboMarc::createRecord($txml);

                } else
                    $tm = $record;

                $bid = (string)$tm->c001;
                if(isset($params['print']))
                    print_r($tm);
                else {
                    file_put_contents("{$outdir}/{$bidsource}-{$bid}.xml",$tm->asXML());
                }

            } catch (Exception $e) {
                print "Eccezione:" . $e->getMessage() . "\n{$rawRecord}\n";
            }
        }
    }


    private function importAction($params)
    {

        // $this->makeLManLinks($params['bidsrc']);
        // return true;

        define('NO_REALTIME_INDEX', true);
        define('NO_CACHE_DIRTY', true);

        $this->openFile($params['file'], $params['format']);


        if (isset($params['xsl'])) {
            $xsl = new DOMDocument;
            $xsl->load($params['xsl']);

            $proc = new XSLTProcessor();
            $proc->importStyleSheet($xsl);
        } else {
            $proc = null;
        }

        if (isset($params['bidsrc']))
            $bidsource = $params['bidsrc'];
        else
            $bidsource = "IMP-" . date('Ymd');

        $utfconv = false;
        $unitrans = false;
        $charset = "AUTO";

        if (isset($params['i'])) {
            if ($params['i'] == "UTF-8") {
                $utfconv = false;
                $unitrans = false;
                $charset = "AUTO";
            } else if ($params['i'] == "UNIMARC") {
                $utfconv = false;
                $unitrans = true;
                $charset = "AUTO";
            } else {
                $utfconv = true;
                $unitrans = false;
                $charset = $params['i'];
            }
        }
        if (isset($params['shelf']))
            $shelf = ShelfPeer::retrieveByPK(intval($params['shelf']));
        else
            $shelf = null;

        $search = Prado::getApplication()->getModule("search");

        $rcounter = 0;
        $m1time = microtime(true);

        while ($rawRecord = $this->readNextRecord()) {
            try {
                $record = $this->parseRecord($rawRecord, $utfconv, $unitrans, $charset);
                $rcounter++;

                if ($rcounter % 10 == 0) {
                    $m2time = microtime(true);
                    print("Speed: " . (10.0 / ($m2time - $m1time)) . " rec/s [record $rcounter] [" . ($m2time - $m1time) . "]\n");
                    $m1time = $m2time;
                }

                if ($proc != null) {
                    $xml = dom_import_simplexml($record);
                    $txml = $proc->transformToXML($xml);
                    $tm = TurboMarc::createRecord($txml);
                    //print_r($tm) . "\n";
                } else
                    $tm = $record;

                //continue;


                if (!isset($tm->d200)) {
                    /** @var $tm TurboMarc */
                    $f200 = $tm->addField("200");
                    $f200->addField("a", "Senza Titolo");
                }

                print $record->c001 . "\n";
                print (string)$tm->d200->sa[0] . "\n";

                $man = null;

                if (isset($record->c001) && isset($params['reusebid'])) {
                    $bid = (string)$record->c001;

                    $man = ManifestationQuery::create()
                        ->filterByBidSource($bidsource)
                        ->findOneByBid($bid);

                }

                if (isset($record->c001) && isset($params['reusesbnbid'])) {
                    $sbnid = (string)$record->c001;

                    if(substr($sbnid,0,8) == "IT\\ICCU\\") {
                        $sbnid = substr($sbnid,8,3) .  substr($sbnid,12);
                    }
                    $man = ManifestationQuery::create()
                            ->filterByBidSource("SBN")
                            ->findOneByBid($sbnid);

                }

                if(isset($params['isbnmerge']) && $man == null) {
                    $numstd = "";
                    if(isset($tm->d010) && isset($tm->d010->sa))
                    {
                        $numstd = str_replace(" ","",str_replace("-","",(string)$tm->d010->sa));
                    }
                    else if(isset($tm->d073) && isset($tm->d073->sa))
                    {
                        $numstd = str_replace(" ","",str_replace("-","",(string)$tm->d073->sa));
                    }
                    if($numstd != "") {
                        $title = str_replace([":","(",")","*"]," ",(string)$tm->d200->sa);
                        //$response = $search->search("fldin_txt_numbers:({$numstd}) AND mrc_d200_sa:\"{$title}\" ");
                        $response = $search->search("fldin_txt_numbers:({$numstd})");
                        if ($response && $response['response']['numFound'] > 0) {

                            print ">>> Trovata n° ". $response['response']['numFound'] .  " => {$numstd} [{$title}]\n";

                            foreach ($response['response']['docs'] as $key => $result) {
                                $man = ManifestationQuery::create()->findPk($result['Id']);
                                if($man instanceof Manifestation) {
                                    print ">>> Link to Manifestation Id:{$result['Id']}\n";
                                    break;
                                }
                                print ">>> Nessun record solr esistente in mysql\n";
                            }
                        }
                    }
                }

                if(isset($params['skip']) && $man instanceof Manifestation) continue;

                if ($man == null) {
                    $man = new Manifestation();

                    if(!isset($tm->d035)) {
                        $f035 = $tm->addField("035");
                        $f035->addSubField("a", (string)$record->c001);
                        $f035->addSubField("9", $bidsource);
                    }

                    $man->setBidSource($bidsource);
                    $man->setBid((string)$record->c001);

                    $links = array();

                    $tmNo4xx = clone $tm;

                    for ($ii = 400; $ii < 500; $ii++)
                        unset($tmNo4xx->{"d" . $ii});

                    if(isset($params['liber']))
                        $tmNo4xx = TurbomarcConversion::LiberDatabase($tmNo4xx);

                    $man->updateFromTurbomarc($tmNo4xx, false, $links);
                }

                $uni = $man->getTurboMarc();

                /** @var $child TurboMarc */
                foreach ($tm->children() as $child)
                    if (substr($child->getName(), 0, 2) == 'd4')
                        $uni->appendNode($child);


                $man->setUnimarc($uni->asXML());
                $man->setManifestationStatus(ManifestationPeer::STATUS_IMPORT);
                $man->save();
                $man->cacheTurboMarc();

                if ($shelf instanceof Shelf) {
                    $shelf->addItemToShelf('manifestation', $man->getManifestationId());
                }

                if (isset($params['series225']) && isset($tm->d225)) {
                    foreach ($tm->d225 as $f225) {

                        $serietxt = (string)$f225->sa;
                        if (!$serietxt)
                            continue;
                        if (isset($tm->d210))
                            $publisher = (string)$tm->d210->sc;
                        else
                            $publisher = "";

                        $manSerie = ManifestationQuery::create()
                            ->filterByBibLevel("c")
                            ->filterByPublisher($publisher)
                            ->findOneByTitle($serietxt);

                        if ($manSerie == NULL) {
                            $serietm = TurboMarc::createRecord();
                            $serietm->setLeader('01234nac0 2201234   450 ');
                            $serietm->setTitle($serietxt);
                            if (isset($tm->d210))
                                $serietm->setPublication((string)$tm->d210->sa . " : " . (string)$tm->d210->sc);

                            $manSerie = ManifestationPeer::createFromTurbomarc($serietm);
                            $manSerie->setBidSource($bidsource);
                            $manSerie->setManifestationStatus(ManifestationPeer::STATUS_IMPORT);
                            $manSerie->save();

                        }

                        $lman = new LManifestation();
                        $lman->setManifestationIdDown($manSerie->getManifestationId());
                        $lman->setManifestationIdUp($man->getManifestationId());
                        if (isset($f225->sv))
                            $lman->setLinkSequence((string)$f225->sv);

                        $lman->setLinkType(410);
                        $lman->save();
                        $lman->clearAllReferences(true);
                        unset($lman);

                        $manSerie->clearAllReferences(true);
                        unset($manSerie);
                    }
                }
                $this->importItems($tm, $man);

                $man->syncTitle();
                $man->syncAuthor();

                $man->clearAllReferences(true);
                unset($man);


            } catch (Exception $e) {
                print "Errore:" . $e->getMessage() . "\n $rawRecord\n";
            }
        }

        // $this->makeLManLinks($bidsource);

        return TRUE;
    }

    private function makeLManLinks($params)
    {

        $bidsource = $params['bidsrc'];

        $lnks = array('d410' => true,'d461no'=>true, 'd463' => true, 'd422' => true, 'd423' => false, 'd430' => true, 'd431'=>true,'d432'=>false,'d434'=>true,'d436'=>false,'d437'=>false,'d446'=>true,'d454' => true, 'd481'=>true );

        print "Pre query\n";
        $mans = ManifestationQuery::create()
            ->filterByBidSource($bidsource)
            ->setFormatter(ModelCriteria::FORMAT_ON_DEMAND)->find();

        print "After query\n";
        foreach ($mans as $man) {
            /** @var $man Manifestation */
            try {
                $tm = $man->reloadTurboMarc();

                foreach ($lnks as $l => $dir) {
                    //print "MAN {$man->getManifestationId()} {$l} " . (string)$tm->{$l}->s1[0] ."\n  ";
                    if (isset($tm->{$l})) {
                        //$dlnk = $tm->{$l};
                        foreach ($tm->{$l} as $dlnk) {
                            $manTo = null;

                            $bidTo = substr((string)$dlnk->s1[0], 3);

                            $manTos = ManifestationQuery::create()
                                ->filterByBidSource($bidsource)
                                ->findByBid($bidTo);

                            foreach ($manTos as $m) {
                                /** @var $m Manifestation */
                                if ($m->getBid() == $bidTo) {
                                    $manTo = $m;
                                    break;
                                }
                            }

                            if ($manTo instanceof Manifestation) {
                                print "{$man->getManifestationId()} [{$man->getBid()}]: $l -> $bidTo [{$manTo->getManifestationId()}]\n";

                                $lman = new LManifestation();
                                $lman->setLinkType(substr($l, 1));


                                if (isset($dlnk->sv))
                                    $lman->setLinkSequence((string)$dlnk->sv);

                                if (isset($dlnk->sn))
                                    $lman->setLinkNote((string)$dlnk->sn);

                                if ($dir) {
                                    $lman->setManifestationIdDown($manTo->getManifestationId());
                                    $lman->setManifestationIdUp($man->getManifestationId());
                                } else {
                                    $lman->setManifestationIdDown($man->getManifestationId());
                                    $lman->setManifestationIdUp($manTo->getManifestationId());
                                }
                                try {

                                    $lman->save();
                                    print "Creo legame\n";
                                } catch (Exception $e) {
                                    print "Link doppio\n";
                                }

                                $lman->clearAllReferences(true);
                                unset($lman);
                                $manTo->clearAllReferences(true);
                                unset($manTo);
                            } else {
                                print "Bid $bidTo non trovato\n";
                            }
                        }
                        unset($tm->{$l});
                    }

                }

                $man->setUnimarc($tm->asXML());
                $man->save();
                $man->clearAllReferences(true);
                unset($man);
            } catch (Exception $e ) {
                print "Errore su manifestation ID: {$man->getManifestationId()} \n";
            }
    }
    }

    private function importItems($tm, Manifestation $man)
    {

        $idx = -1;
        foreach ($tm->d950 as $idx => $item) {
            ++$idx;

            print "Item\n";
            $i = new Item();
            $i->setManifestation($man);

            $i->setTitle($man->getTitle());

            if (array_key_exists('sa', $item))
                $i->setHomeLibraryId((string)$item->sa);
            if (array_key_exists('sb', $item))
                $i->setInventorySerieId((string)$item->sb);
            if (array_key_exists('sc', $item))
                $i->setInventoryNumber((string)$item->sc);
            if (array_key_exists('sd', $item))
                $i->setSection((string)$item->sd);
            if (array_key_exists('se', $item))
                $i->setHeight((string)$item->se);
            if (array_key_exists('sf', $item))
                $i->setCollocation((string)$item->sf);
            if (array_key_exists('sg', $item))
                $i->setSpecification((string)$item->sg);
            if (array_key_exists('sh', $item))
                $i->setSequence1((string)$item->sh);
            if (array_key_exists('si', $item))
                $i->setSequence2((string)$item->si);
            if (array_key_exists('sj', $item))
                $i->setItemStatus((string)$item->sj);
            if (array_key_exists('sk', $item))
                $i->setOpacVisible((string)$item->sk);
            if (array_key_exists('sl', $item))
                $i->setDateDiscarded((string)$item->sl);

            if (array_key_exists('sm', $item))
                $i->setInventoryValue((string)$item->sm);
            if (array_key_exists('sn', $item))
                $i->setActualLibraryId((string)$item->sn);
            if (array_key_exists('so', $item))
                $i->setOwnerLibraryId((string)$item->so);
            if (array_key_exists('sp', $item))
                $i->setLoanClass((string)$item->sp);
            if (array_key_exists('sq', $item))
                $i->setPhysicalStatus((string)$item->sq);
            if (array_key_exists('sr', $item))
                $i->setBarcode((string)$item->sr);


            if (array_key_exists('ss', $item))
                $i->setItemMedia((string)$item->ss);
            else
                $i->setItemMedia(ClavisBase::BibtypeToItemmedia($man->getBibType()));

            if (array_key_exists('st', $item))
                $i->setInventoryDate((string)$item->st);
            if (array_key_exists('su', $item))
                $i->setItemSource((string)$item->su);
            if (array_key_exists('sw', $item))
                $i->setItemIcon((string)$item->sw);

            if (array_key_exists('s4', $item))
                $i->setReprint((string)$item->s4);

            if (array_key_exists('s5', $item))
                $i->setVolumeText((string)$item->s5);
            if (array_key_exists('s6', $item))
                $i->setVolumeNumber((int)$item->s6);

            if (array_key_exists('s7', $item))
                $i->setLoanAlertNote((string)$item->s7);

            if (array_key_exists('sz', $item))
                $i->setIssueId((string)$item->sz);
            else
                $i->setIssueId(null);

            if (array_key_exists('s1', $item))
                $i->setCustomField1((string)$item->s1);
            if (array_key_exists('s2', $item))
                $i->setCustomField2((string)$item->s2);
            if (array_key_exists('s3', $item))
                $i->setCustomField3((string)$item->s3);


            $i->setExternalLibraryId(null);

            $i->setLoanStatus(ItemPeer::LOANSTATUS_AVAILABLE);
            $i->save();

            foreach ($item->sy as $inote) {
                $note = new ItemNote();
                $note->setNoteType($inote['t']);
                $note->setNote((string)$inote);
                $note->setItem($i);
                $note->save();

                $note->clearAllReferences(true);
            }

            // Create fake issue
            if($man->getBibLevel() == "s")
            {
                $issue = new Issue();
                $issue->setManifestation($man);
                $issue->setIssueNumber($i->getCollocationCombo());
                $issue->save();

                $i->setIssue($issue);
                $i->save();

                $issue->clearAllReferences(true);
            }

            // Consistency notes
            foreach ($item->sY as $cnote) {
                $note = new ConsistencyNote();
                $note->setLibraryId($i->getHomeLibraryId());
                $note->setManifestation($man);
                $note->setTextNote((string)$cnote);
                $note->save();

                $i->setConsistencyNote($note);
                $i->save();

                $note->clearAllReferences(true);
            }

            $i->clearAllReferences(true);
            unset($i);
        }

    }

    private function convertToTurbomarc($params)
    {
        $utfconv = false;
        $unitrans = false;
        $charset = "AUTO";

        if (isset($params['i'])) {
            if ($params['i'] == "UTF-8") {
                $utfconv = false;
                $unitrans = false;
                $charset = "AUTO";
            } else if ($params['i'] == "UNIMARC") {
                $utfconv = false;
                $unitrans = true;
                $charset = "AUTO";
            } else {
                $utfconv = true;
                $unitrans = false;
                $charset = $params['i'];
            }
        }
        $this->openFile($params['file'], $params['format']);
        while ($rawRecord = $this->readNextRecord()) {
            $record = $this->parseRecord($rawRecord, $utfconv, $unitrans, $charset);
            print substr($record->asXML(), strlen("<?xml version=\"1.0\"?>"));
        }

        return TRUE;
    }

    private function openFile($filename, $fileFormat)
    {
        $this->fileFormat = $fileFormat;
        $this->fileIn = fopen($filename, "rb");
        //Skip header if needed
        if ($this->fileFormat == "turbomarc") {
           stream_get_line($this->fileIn, 128000, "<collection xmlns=\"http://www.indexdata.com/turbomarc\">"); // Skip collection

        }
    }

    private function readNextRecord()
    {
        $record = false;

        if ($this->fileFormat == "turbomarc") {
            $record = stream_get_line($this->fileIn, 16000000, "</r>");

            /*if(strstr($record,"</r>") !== false) {
                print "----noooo--------\n[{$record}]\n------dd-----\n";
                die();
            }*/

            if ($record !== FALSE)
                $record .= "</r>";




        } else if ($this->fileFormat == "iso2709") {
            $record = stream_get_line($this->fileIn, 16000000, self::UNIMARC_RECORDEND);
            if ($record !== FALSE) {
                $record .= self::UNIMARC_RECORDEND;
                $record = trim($record, " \n\r\t");
            }
        }

        return $record;
    }


    private function parseRecord($record, $utfconv = false, $uniTranslate = false, $charset)
    {
        $rxml = false;

        if ($this->fileFormat == "turbomarc") {
            $rxml = TurboMarc::createRecord($record);
        } else if ($this->fileFormat == "iso2709") {
            $rxml = TurboMarc::createRecord();
            $rxml->parseRecord($record, $utfconv, $uniTranslate, $charset);
        }

        return $rxml;
    }

    private function move4xx(TurboMarc $record)
    {
        $xml = $record->asXML();
        $xml = preg_replace('/<(\/?)d(4\d\d)/', '<$1t$2', $xml);
        $tmarc = TurboMarc::createRecord($xml);

        return $tmarc;
    }


}