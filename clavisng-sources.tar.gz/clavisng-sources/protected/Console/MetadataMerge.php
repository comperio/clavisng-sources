<?php
/**
 * MergeMetadata class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Dario Rigolin <dario@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2020 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.10
 * @package Console
 */
require_once('ClavisCommandLineAction.php');

/**
 * MetadataMerge Class
 *
 * @author Dario Rigolin
 * @version 1.0
 * @package Console
 * @since 2.10.0
 */
class ClavisActionMetadataMerge extends ClavisCommandLineAction
{
    protected $action = 'metadata_merge';
    protected $parameters = array('-a action');
    protected $optional = array();
    protected $description = "";
    /** @var $logger Log */
    protected $logger;


    public function performAction($args)
    {
        $this->logger = Log::factory('console', '', $this->action);
        $this->logger->info('=== Starting ===');

        try {
            $params = $this->parseArgs($args);
            switch ($params['a']) {
                case "editionkey":
                    $this->prepareEditionKey($params);
                    break;
                case "mergekey":
                    $this->prepareMergeKey($params);
                    break;
                case "exportloancsv":
                    $this->exportLoanCSV($params);
                    break;
                case "makejson":
                    $this->makeJSON($params);
                    break;

            }
            return true;
        } catch (Exception $e) {
            $this->logger->err('Error: ' . $e->getMessage());
        }
    }

    public function makeJSON($params)
    {
        $this->logger->info('=== Prepare JSON Make ===');


        $dbh = Propel::getConnection();

        $dbh->exec("DROP TABLE IF EXISTS _manif_json");
        $dbh->exec("CREATE TABLE _manif_json (
          `manid` int(11) NOT NULL,
          `jdoc` JSON NOT NULL
        ) ENGINE=InnoDB ");

        $stm = $dbh->prepare("INSERT INTO _manif_json VALUES(:manid, :json)");

        $dbh->beginTransaction();

        foreach ($dbh->query("
            SELECT manifestation_id, turbomarc
            FROM turbomarc_cache 
        ") as $manif) {
            $tm = simplexml_load_string($manif['turbomarc']);

            $json = json_encode($tm, JSON_PRETTY_PRINT);
            if($json == false)
                $this->logger->err('Broken JSON ' . $tm->asXML());

            $stm->bindValue(":manid",$manif['manifestation_id']);
            $stm->bindValue(":json",$json);
            $stm->execute();

        }
        $dbh->commit();
        $this->logger->info('Finish json make');
    }

    public function prepareEditionKey($params)
    {
        $this->logger->info('=== Prepare Edition Key ===');


        $dbh = Propel::getConnection();

        $dbh->exec("DROP TABLE IF EXISTS _manif_editionkey");
        $dbh->exec("CREATE TABLE `_manif_editionkey` (
          `manid` int(11) NOT NULL,
          `editionkey` varchar(512) NOT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8");

        $dbh->exec("ALTER TABLE `_manif_editionkey`
          ADD PRIMARY KEY (`manid`),
          ADD KEY `mergeidx1` (manid,`editionkey`),
          ADD KEY `mergeidx2` (editionkey,`manid`);
    ");


        $stm = $dbh->prepare("INSERT INTO _manif_editionkey VALUES(:manid, :edkey)");

        $dbh->beginTransaction();

        foreach ($dbh->query("
            SELECT manifestation_id, turbomarc
            FROM turbomarc_cache 
        ") as $manif) {
            $tm = simplexml_load_string($manif['turbomarc']);

            $edkey = $this->calcMergeKey($tm->d200->sa) ;
            if(isset($tm->d700))
                $edkey .= " " . $this->calcMergeKey($this->cleanAuthor($tm->d700->sa)) ;
            elseif(isset($tm->d710))
                $edkey .= " " . $this->calcMergeKey($this->cleanAuthor($tm->d710->sa)) ;

            $stm->bindValue(":manid", $manif['manifestation_id']);
            $stm->bindValue(":edkey", $edkey);
            $stm->execute();
        }
        $dbh->commit();
        $this->logger->info('Finish editionkey calc');
    }


    public function prepareMergeKey($params)
    {
        $appID = Prado::getApplication()->getID();

        $this->logger->info('=== Prepare Merge Key ===');

        $dbh = Propel::getConnection();

        $dbh->exec("DROP TABLE IF EXISTS _manif_mergekey_{$appID}");
        $dbh->exec("CREATE TABLE `_manif_mergekey_{$appID}` (
          `manid` int(11) NOT NULL,
          `algo`  char(1) NOT NULL,
          `mergekey` varchar(512) NOT NULL,
          ean varchar(13) NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8");

        $dbh->exec("ALTER TABLE `_manif_mergekey_{$appID}`
          ADD KEY `mergeidx1` (manid,algo,mergekey),
          ADD KEY `mergeidx2` (mergekey,manid,algo),
          ADD KEY eanidx(ean,manid);
    ");

        $stm = $dbh->prepare("INSERT INTO _manif_mergekey_{$appID} VALUES(:manid, :algo, :mergekey, :ean)");

        $dbh->beginTransaction();

        foreach ($dbh->query("
            SELECT manifestation_id, unimarc
            FROM manifestation 
        ") as $manif) {
            $tm = simplexml_load_string($manif['unimarc']);
            $eanList = [];
            foreach ($tm->d010 as $f010) {
                $eanList[] = ClavisBase::IsbnToEan13($f010->sa);
            }
            foreach ($tm->d073 as $f073) {
                $eanList[] = ClavisBase::IsbnToEan13($f073->sa);
            }

            $title = $this->calcMergeKey($tm->d200->sa);

            foreach ($eanList as $ean) {

                $stm->bindValue(":manid", $manif['manifestation_id']);
                $stm->bindValue(":algo", "A");
                $stm->bindValue(":mergekey", $title . $ean);
                $stm->bindValue(":ean", $ean);
                $stm->execute();
            }
        }

        $dbh->commit();
        $this->logger->info('Finish mergekey calc');
    }

    public function exportLoanCSV($params)
    {
        $filename = $params['filecsv'];
        $year = $params['year'];

        $this->logger->info("=== Export Loan CSV in {$filename} ===");

        $dbh = Propel::getConnection();

        $fp = fopen($filename,"w");



        fclose($fp);
    }

    public function calcMergeKey($k)
    {
        $k = trim(str_replace([' *', '*', '\' ', ', ', ','], [' ', ' ', '\'', ' ', ' '], mb_strtolower(html_entity_decode($k), 'UTF-8')));
        $k = transliterator_transliterate("Any-Lower", transliterator_transliterate("Latin-ASCII", $k));
        $k = preg_replace("/\s+/", " ", $k);
        $k = preg_replace("/\W/", "", $k);
        return trim(substr($k, 0, 1024));
    }

    public function cleanAuthor($au) {

        if(preg_match("/^(.+)<(.+)>$/",$au,$m)) {
            $au = trim($m[1]);
        }

    return $au;
}

}
