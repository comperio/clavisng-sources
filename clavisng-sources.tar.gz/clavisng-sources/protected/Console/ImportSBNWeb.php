<?php

/**
 *
 *
 * @author Dario Rigolin
 * @package Console
 * @since 2.7.3
 */

require_once('ClavisCommandLineAction.php');

class ClavisActionImportSBNWeb extends ClavisCommandLineAction
{
    const UNIMARC_RECORDEND = "\x1d";
    const UNIMARC_FIELDEND = "\x1e";
    const UNIMARC_SUBFIELDEND = "\x1f";

    protected $action = 'importsbnweb';
    protected $parameters = array('action', 'file');
    protected $optional = array();
    protected $description = 'Imports/Syncs SBNWeb UNIMARC export';

    protected $fileIn;
    protected $fileFormat;
    protected $itemdb;
    protected $mandb;
    protected $cache;

    public function performAction($args)
    {
        libxml_use_internal_errors(true);
        $ret = false;
        $params = $this->parseArgs($args);
        var_dump($params);
        switch ($params['a']) {
            case "import":
                $ret = $this->importAction($params);
                break;
            case "seeauthority":
                $ret = $this->seeAuthorityAction($params);
                break;
        }

        return $ret;
    }

    private function seeAuthorityAction($params)
    {
            if(isset($tm->d799))
                foreach($tm->d799 as $f799) {
                    $auth1 = (string)$f799->sa;
                    $auth2 = (string)$f799->sb;

                    $accepted = AuthorityQuery::create()
                        ->filterByFullText($auth2)
                        ->filterByAuthorityRectype(AuthorityPeer::RECTYPE_ACCEPTED)
                        ->filterByAuthorityType(array(AuthorityPeer::TYPE_PERSONALNAME, AuthorityPeer::TYPE_CORPORATEBODYNAME))
                        ->findOne();

                    $variant = AuthorityQuery::create()
                        ->filterByFullText($auth1)
                        ->filterByAuthorityRectype(AuthorityPeer::RECTYPE_VARIANT)
                        ->filterByAuthorityType(array(AuthorityPeer::TYPE_PERSONALNAME, AuthorityPeer::TYPE_CORPORATEBODYNAME))
                        ->find();

                    if($accepted instanceof Authority && count($variant) == 0) {
                        // Create new Variant authority
                        $auth = new Authority();
                        $auth->setAuthorityType($accepted->getAuthorityType());
                        $auth->setSortText($auth1);
                        $auth->setAuthorityRectype(AuthorityPeer::RECTYPE_VARIANT);
                        $auth->setAuthorityCodLevel(05);
                        $auth->setAuthorityStatus(AuthorityPeer::INTERNALSTATUS_REVIEW);
                        $auth->save();

                        $la = new LAuthority();
                        $la->setAuthorityIdUp($auth->getAuthorityId());
                        $la->setAuthorityIdDown($accepted->getAuthorityId());
                        $la->setLinkType("54");
                        $la->save();

                        $la->clearAllReferences(true);
                        $auth->clearAllReferences(true);

                    } else {
                        print "Anomalia!\n";
                        print "Accettate: " .count($accepted) ."\n";
                        print "Variante: " .count($variant) ."\n";
                    }
                }

    }

    private function importAction($params)
    {
        define('NO_REALTIME_INDEX', true);
        define('NO_CACHE_DIRTY', true);

        $fname = $params['file'];

	    $fp = fopen($fname,"r");

	    fgets($fp); //strip forst line

	    $dbh = Propel::getConnection();

	    $this->mandb = $dbh->query("SELECT bid, manifestation_id FROM manifestation where bid_source = 'SBN'")->fetchAll( PDO::FETCH_COLUMN | PDO::FETCH_GROUP);
	    $this->itemdb = $dbh->query("SELECT concat(trim(inventory_serie_id),'-',inventory_number), manifestation.bid FROM item JOIN manifestation ON manifestation.manifestation_id = item.manifestation_id ")->fetchAll( PDO::FETCH_COLUMN | PDO::FETCH_GROUP);

	    print "Trovati " . count($this->mandb). " bids\n";
	    print "Trovati " . count($this->itemdb). " items\n";


        $dbh->query("TRUNCATE TABLE authority");
        $dbh->query("TRUNCATE TABLE l_authority");
        $dbh->query("TRUNCATE TABLE l_authority_item");
        $dbh->query("TRUNCATE TABLE l_authority_manifestation");
        $dbh->query("TRUNCATE TABLE l_subject");

        $this->cache = array();

	    while(!feof($fp))
        {
            $xmlstr= stream_get_line($fp,512000,"</r>") . "</r>";
            $xmlstr = str_replace("|"," ",$xmlstr);
            $xmlstr = str_replace("\xC2\x88","",$xmlstr);
            $xmlstr = str_replace("\xC2\x89","*",$xmlstr);
            try {
                $xml = TurboMarc::createRecord($xmlstr);

                if($xml === FALSE) continue;

                if(isset($xml->d921)) // Fix Marca Tipografica
                    foreach($xml->d921 as $m)
                    {
                        $id = (string)$m->sa;
                        $m->sa = (string)$m->sb;
                        $f = (string)$m->sf;
                        $m->sf = (string)$m->sb;
                        $m->sb = $f;
                        $m->sSBN = $id;
                    }

                $bid = (string)$xml->c001;

                $this->cache[$bid] = $xml->asXML();

                // Skip the loop
                //continue;

                if(isset($xml->d454))
                    foreach($xml->d454 as $tt)
                    {
                        $xml->addField("500")->addSubField('a',(string)$tt->sa);
                    }

                for($i = 400; $i < 500; $i++)
                {
                    $fld = "d{$i}";
                    unset($xml->$fld);
                }

                if(substr($xml->l,7,1) == 's' && isset($xml->d110) && substr($xml->d110->sa,0,1) == 'a' ) $ser = "PERIODICO";
                else if(substr($xml->l,7,1) == 's' && isset($xml->d110) && substr($xml->d110->sa,0,1) == 'b') $ser = "COLLANA";
                else $ser = "";

                if(isset($this->mandb[$bid]))
                    $man = ManifestationQuery::create()->findPk($this->mandb[$bid][0]);
                else
                    $man = new Manifestation();

                $f035 = $xml->addField("035");
                $f035->addSubField("a",$bid);
                $f035->addSubField("9","SBN");

                $man->setBidSource("SBN");
                $man->setBid($bid);

                $links = array();
                $man->updateFromTurbomarc($xml, false, $links);
                $uni = $man->getTurboMarc();
                $man->setUnimarc($uni->asXML());
                $man->setManifestationStatus(ManifestationPeer::STATUS_IMPORT);
                $man->save();

                if(!isset($this->mandb[$bid][0]))
                    $this->mandb[$bid][0] = $man->getManifestationId();

                $this->importItems($bid, $xml, $man);

                $man->clearAllReferences(true);
                unset($man);
                print "Importato $bid\n";

            } catch (Exception $e) {
                print "Exception: " . $e->getMessage() . "\n";
            }
	    }
        print "Start Linking\n";
        $dbh->query("TRUNCATE TABLE l_manifestation");

	    foreach($this->cache as $bid=>$xmlstr)
	    {
		    $xml = TurboMarc::createRecord($xmlstr);

            $flds = array("d410","d421","d430","d431","d434","d447","d451","d454","d461","d462","d464","d488");
            foreach($flds as $f)
                if(isset($xml->$f))
                    foreach($xml->$f as $l)
                    {
                        $bid2 = substr((string)$l->s1,3);
                        if(isset($this->mandb[$bid2][0]) && isset($this->mandb[$bid][0]))
                        {
                            $link = substr($f,1);
                            if($link == '462' || $link == '464') $link = '461';
                            $seq = $dbh->quote(str_pad( (string)$l->sv,16,' ',STR_PAD_LEFT));
                            $manid2 = $this->mandb[$bid2][0];
                            $manid  = $this->mandb[$bid][0];
                            //Clean Existing Links
                            //$dbh->query("DELETE FROM l_manifestation WHERE manifestation_id_up = $manid OR manifestation_id_down = $manid");
                            print "Nuovo legame: $link - $manid / $manid2 [{$bid}] [{$bid2}] [$seq]\n";
                            try
                            {
                                $dbh->query("INSERT INTO l_manifestation(manifestation_id_up,manifestation_id_down,link_type,link_sequence)
                                    VALUES($manid,$manid2,$link,$seq)");
                            } catch (Exception $e) {
                            }
                        }
                        else
                            print "Bid sconosciuti $bid $bid2\n";
                    }
        }

        print "Fine\n";

        return TRUE;
    }

    private function importItems($bid, $xml, Manifestation $man)
    {
        if(substr($xml->l,8,1) == 1) return;
        //if(substr($xml->l,7,1) == 's') return;
        if(!isset($xml->d950->se)) return;
        if(!isset($xml->d950->sd)) return;

        if(isset($xml->d950))
        {
            $subf = array();
            foreach($xml->d950->children() as $child)
                $subf[] = $child;

            for($i=0; $i < count($subf); $i++)
            {
                $child = $subf[$i];
                if($child->getName() == "se")
                {
                    if($subf[$i-1]->getName() == "sd")
                    {
                        $sez = trim(substr((string)$subf[$i-1],3,10));
                        $col = trim(substr((string)$subf[$i-1],13,24));
                        $vol = trim(substr((string)$subf[$i-1],37));
                    } else {
                        $sez = "";
                        $col = "";
                        $vol = "";
                    }
                    // B = Sola consultazione A=Prestabile
                    if(isset($subf[$i+1]) && $subf[$i+1]->getName() == "sf")
                    {
                        $cdfrui = trim((string)$subf[$i+1]);
                    }
                    else
                    {
                        $cdfrui = "*";
                    }
                    if(isset($subf[$i+2]) && $subf[$i+2]->getName() == "sh")
                    {
                        $invdate = substr((string)$subf[$i+2],0,4).'-'.substr((string)$subf[$i+2],4,2).'-'.substr((string)$subf[$i+2],6,2);
                    }
                    else
                    {
                        $invdate = "";
                    }
                    $it = array();
                    $it["InvSerie"] = trim(substr((string)$child,3,3));
                    $it["Inventory"] = intval(substr((string)$child,6,9));
                    $cdsit = trim(substr((string)$child,15,1));
                    $cdnodisp = trim(substr((string)$child,16,2));
                    $cdsuppor = trim(substr((string)$child,18,2));
                    $statocon = trim(substr((string)$child,20,2));
                    $seqcol   = trim(substr((string)$child,24,18));
                    $it["Volume"] = trim(substr((string)$child,44));

                    if($it["InvSerie"] == "") $it["InvSerie"] = "1";

                    if(!isset($this->itemdb["{$it["InvSerie"]}-{$it["Inventory"]}"]))
                    {
                        print "Nuovo inventario {$it["InvSerie"]}-{$it["Inventory"]} [$sez/$col/$seqcol/$vol] $cdsit |$cdnodisp |$cdsuppor |$statocon |$seqcol |$cdfrui\n";
                        $item = new Item();

                        $item->setHomeLibraryId(1);
                        $item->setActualLibraryId(1);
                        $item->setOwnerLibraryId(1);

                        $item->setPhysicalStatus('B');
                        $item->setItemStatus('F');
                        $item->setOpacVisible(true);
                        $item->setLoanStatus(ItemPeer::LOANSTATUS_AVAILABLE);
                        $item->setExternalLibraryId(null);
                        $item->setItemMedia(ClavisBase::BibtypeToItemmedia($man->getBibType()));
                        if($invdate != "")
                            $item->setInventoryDate($invdate);

                        if($cdfrui == 'B')
                            $item->setLoanClass(ItemPeer::LOANCLASS_ONLYCONSULTATION);
                        else
                            $item->setLoanClass(ItemPeer::LOANCLASS_AVAILABLE);



                    } else  {
                        $oldbid = $this->itemdb["{$it["InvSerie"]}-{$it["Inventory"]}"][0];
                        print "BIDNEW {$oldbid}=>{$bid} inventario {$it["InvSerie"]}-{$it["Inventory"]} [$sez/$col/$seqcol/$vol] $cdsit |$cdnodisp |$cdsuppor |$statocon |$seqcol |$cdfrui\n";
                        $item = ItemQuery::create()->filterByInventorySerieId($it["InvSerie"])->findOneByInventoryNumber($it["Inventory"]);

                    }

                    $item->setManifestation($man);
                    $item->setTitle($man->getTitle());

                    $item->setInventorySerieId($it["InvSerie"]);
                    $item->setInventoryNumber($it["Inventory"]);

                    $item->setSection($sez);
                    $item->setCollocation($col);
                    $item->setSpecification($vol);
                    $item->setSequence1($seqcol);

                    $item->setVolumeText($it["Volume"]);

                    $item->setCustomField3("SBNWeb");

                    $item->save();


                    if(substr($xml->l,7,1) == 's' && $item->getIssueId() == null) {
                        // Creo fascicolo
                        $issue = new Issue();
                        $issue->setManifestationId($item->getManifestationId());
                        $issue->setIssueNumber($item->getCollocationCombo());
                        $issue->save();

                        $item->setIssueId($issue->getIssueId());
                        $item->save();

                    } else if(substr($xml->l,7,1) == 's' && $item->getIssueId() > 0) {
                        $iss = $item->getIssue();
                        if($iss instanceof Issue) {
                            $item->getIssue()->setManifestationId($item->getManifestationId());
                            $item->getIssue()->save();
                        }
                    }
                }
            }
        }
    }
}
