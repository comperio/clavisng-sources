<?php

/**
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Console
 * @since 2.5.0
 */

require_once('ClavisCommandLineAction.php');

/**
 * @package Console
 * @since 2.5.0
 */
class ClavisActionExportUnimarc extends ClavisCommandLineAction
{
	protected $action = 'export_unimarc';
	protected $parameters = array('filename');
	protected $optional = array('iso2709 | txt | xml');
	protected $description = 'Exports entire catalog\'s unimarc. Mandatory parameter specifies the filename to save the catalog to; optional parameter specifies a format to use for export (defaults to ISO2709).\nWARNING: this script relies on unimarc_cache, so you\'ll want to ensure cache validity calling cache_tmarc script, before.';

	public function performAction($args)
	{
		echo "\nGenerating file. It can need a lot of time, so please be patient...";
		if (count($args) > 2)
			switch ($args[2]) {
				case 'iso2709':
					$outputFunc = 'getISO2709';
					break;
				case 'txt':
					$outputFunc = 'getTXT';
					break;
				case 'xml':
				case 'tmxml':
					$outputFunc = 'asXML';
					break;
                default:
                    $outputFunc = 'getISO2709';
                    break;
			}
		else
			$outputFunc = 'getISO2709';


        if($outputFunc == "asXML" ) {
            file_put_contents($args[1],"<collection>");
            $count = 0;
            $query = TurbomarcCacheQuery::create();
            if(isset($args[3]))
            {
                $query->useManifestationQuery()
                    ->filterByDateUpdated($args[3],Criteria::GREATER_EQUAL)
                    ->endUse();
            }
            foreach ($query->setFormatter(ModelCriteria::FORMAT_ON_DEMAND)->find() as $cache) {
                /** @var $cache TurbomarcCache */
                /** @var $tm TurboMarc */

                try
                {
                    $tm = $cache->getTurbomarcObject();

                } catch(Exception $e) {
                    // In case of broken record we continue to next one
                    continue;
                }


                $cache->clearAllReferences(true);
                $xml = trim(substr($tm->$outputFunc(),21));
                $oxml = $xml;
                $xml = str_replace("<s/>","",$xml);
                $xml = str_replace("<s></s>","",$xml);
                // Here start a fix for yaz-marcump <l> need to be first child of <r>
                $tm->l = "012345n" . substr((string)$tm->l,7);
                if(substr($xml,0,5) != "<r><l") {
                    $p1 = strpos($xml,"<l>");
                    $p3 = strpos($xml,'<l i1="" i2="">');
                    $p2 = strpos($xml,"</l>");

                    if($p1 !== false && $p2 !== false) {
                //        print("PRIMA: " . substr($xml,3,$p1-3) . "\n");
                //        print("DOPO: ". substr($xml,$p2+4) . "\n");
                //        print("ELLE: " . substr($xml,$p1, $p2-$p1+4) . "\n");
                        $xml = "<r>" . substr($xml,$p1, $p2-$p1+4)  .  substr($xml,3,$p1-3) . substr($xml,$p2+4);
                    } else if($p3 !== false && $p2 !== false) {

                        //        print("PRIMA: " . substr($xml,3,$p1-3) . "\n");
                        //        print("DOPO: ". substr($xml,$p2+4) . "\n");
                        //        print("ELLE: " . substr($xml,$p1, $p2-$p1+4) . "\n");
                        $xml = "<r>" . substr($xml,$p3, $p2-$p3+4)  .  substr($xml,3,$p3-3) . substr($xml,$p2+4);

                    }
                }

                file_put_contents($args[1],$xml,FILE_APPEND); // remove 21 chars of <?xml version="1.0"..
                $count++;
                if($count % 1000 == 0) print "Processati $count\n";
            }
            print "Totale: $count\n";
            file_put_contents($args[1],"</collection>",FILE_APPEND);
        } else {
            foreach (TurbomarcCacheQuery::create()->setFormatter(ModelCriteria::FORMAT_ON_DEMAND)->find() as $cache) {
                $tm = $cache->getTurbomarcObject();
                $cache->clearAllReferences(true);
                file_put_contents($args[1],$tm->$outputFunc(),FILE_APPEND);
            }
        }

		echo "\n#### ALL DONE!!! ####\n";
		return true;
	}

}