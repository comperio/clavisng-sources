<?php

/**
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Console
 * @since 2.5.0
 */

require_once('ClavisCommandLineAction.php');

/**
 * @package Console
 * @since 2.5.0
 */
class ClavisActionLoadSbnDewey extends ClavisCommandLineAction
{
	protected $action = 'load_sbn_dewey';
	protected $parameters = array();
	protected $optional = array('dewey_csv_file');
	protected $description = "Loads SBN dewey descriptions for classes. Optional parameter defines the dewey CSV file path (or address), defaults to ./dewey.csv.";

	public function performAction($args)
	{
		$file = (isset($args[1])) ? $args[1] : dirname(__FILE__).'/dewey.csv';
		print "\nLoading Dewey File";
		$fp = fopen($file, 'r');
		while(!feof($fp))
		{
			$dewey = fgetcsv($fp, 8192, "\t");
			$cl = AuthorityQuery::create()
				->findOneByClassCode($dewey[0]);
			if ($cl instanceof Authority) {
				print "\n{$dewey[0]} found, updating...";
				$tm = $cl->getTurboMarc();
				if (!isset($tm->d676))
					$tm->addField(676);
				if (!isset($tm->d676->sv))
					$tm->d676->addSubField('v',$dewey[1]);
				else
					$tm->d676->sv = $dewey[1];
				if (!isset($tm->d676->sc))
					$tm->d676->addSubField('c',$dewey[2]);
				else
					$tm->d676->sc = $dewey[2];
				$cl->setUnimarc($tm->asXML());
				$cl->save();
				$cl->clearAllReferences(true);
			} else {
				print "\n{$dewey[0]} NOT FOUND";
			}
		}
		fclose($fp);
		echo "\n#### ALL DONE!!! ####\n";
		return true;
	}
}