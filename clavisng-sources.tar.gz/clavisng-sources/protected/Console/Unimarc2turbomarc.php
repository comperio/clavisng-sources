<?php
/**
 * ClavisActionUnimarc2turbomarc class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Console
 */
require_once('ClavisCommandLineAction.php');

/**
 * ClavisActionUnimarc2turbomarc Class
 *
 * @author Ciro Mattia Gonano
 * @version 2.7
 * @package Console
 * @since 2.5.0
 */
class ClavisActionUnimarc2turbomarc extends ClavisCommandLineAction
{
	protected $action = 'unimarc2turbomarc';
	protected $parameters = array();
	protected $optional = array();
	protected $description = 'One-shot action to convert manifestation db records from unimarc txtcompact to turbomarc.';

	public function performAction($args)
	{
		Prado::using('Application.Legacy.UnimarcRecord');
		
		$conn = Propel::getConnection();
		$updateStmt = $conn->prepare('UPDATE `manifestation` SET `unimarc` = ? WHERE `manifestation_id` = ?');
		$markStmt = $conn->prepare('UPDATE `manifestation` SET `manifestation_status` = \'X\' WHERE `manifestation_id` = ?');
		$stmt = $conn->prepare('SELECT `manifestation_id`,`unimarc` FROM `manifestation`');
		$stmt->execute();

		file_put_contents('/tmp/uni2tm.err', "ERROR LOG\n");

		while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
			try {
				if ($row[1]{0} == '<')
					continue;
				print "\nProcessing manifestation {$row[0]}...";
				$uni = new UnimarcRecord();
				$uni->parseTXTCompact(preg_replace('!\$[^\w\d ]!',' ',$row[1]));
				// remove unneeded and problematic fields
				for ($i = 399; $i < 999; $i++) {
					if (501 == $i)
						$i = 600; // leave alone 5xx fields.
					if (801 == $i)
						continue; // leave alone 801
					if (856 == $i)
						continue; // leave alone 856
					if ($uni->existsField($i)) {
						$cnt = $uni->getFieldCount($i);
						for ($j=0; $j<$cnt; ++$j) {
							if (500 == $i) {
								// convert 500 fields to works
								$worktitle = $uni->getSubField($i,'a',$j);
								$title = preg_replace('!\s+!', ' ', (string)$worktitle);
								$sort_text = trim(array_pop(explode('*', $title, 2)));

								$w = AuthorityQuery::create()
									->filterByAuthorityType(AuthorityPeer::TYPE_WORK)
									->filterBySortText($sort_text)
									->findOneOrCreate();

								if ($w->isNew()) {
									$w->setAuthorityRectype(AuthorityPeer::RECTYPE_ACCEPTED);
									$w->setAuthorityCodlevel(0);
									$w->setAuthorityStatus(AuthorityPeer::INTERNALSTATUS_FINAL);
									$w->setSortText($title);
									$w->save();
								}
								// check for already existing link
								$l = LAuthorityManifestationQuery::create()
									->filterByManifestationId($row[0])
									->filterByAuthority($w)
									->filterByLinkType(500);
								if ($l->count() < 1) {
									$l = new LAuthorityManifestation();
									$l->setManifestationId($row[0]);
									$l->setAuthority($w);
									$l->setLinkType(500);
									$l->save();
								}
							}
							$uni->deleteField($i);
						}
					}
				}
				$uni->sortFields();
				$updateStmt->execute(array($uni->getTurboMarc(true),$row[0]));
				unset($uni);
			} catch (Exception $e) {
				$markStmt->execute(array($row[0]));
				print "\n!!!! SOMETHING WENT WRONG, please check your logs.\n".
					"Exception throwed is [{$e->getCode()}] {$e->getMessage()}.\n".
					"Going on with conversion, errors will be logged in /tmp/uni2tm.err\n";
				file_put_contents('/tmp/uni2tm.err', "\n=== ERROR in manifestation [{$row[0]}]: {$e->getMessage()}\n", FILE_APPEND);
				file_put_contents('/tmp/uni2tm.err', $row[1], FILE_APPEND);
			}
		}
		
		print "\n\n#### ALL DONE!!! ####\n";
		return true;
	}
}
