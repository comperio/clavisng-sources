<?php

/**
 *
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Console
 * @since 2.5.0
 */

require_once('ClavisCommandLineAction.php');

/**
 * @package Console
 * @since 2.5.0
 */
class ClavisActionRebuildAuthorities extends ClavisCommandLineAction
{
	protected $action = 'rebuild_authorities';
	protected $parameters = array('subjects|classes|works|common|all');
	protected $optional = array('force','filter_type');
	protected $description = 'Rebuilds authorities checking for unsane characters, and rebuilds subjects accordingly to actual authorities. Specify either \'subjects\' to rebuild only subjects, \'classes\' to rebuild only classes, or \'all\' to rebuild all authorities.';

	public function performAction($args)
	{
		$force = isset($args[2]) && 'force' == $args[2];
		switch ($args[1]) {

			case 'all':
				print "\nREBUILDING ALL AUTHORITIES!";
				$this->rebuildCommon();
				print "\nREBUILDING SUBJECTS!";
				$this->rebuildSubjects();
				print "\nREBUILDING WORKS!";
				$this->rebuildWorks();
				/*print "\nCHECKING PRINTERS DEVICE!";
				$this->rebuildPrintersDevice();*/
				print "\nREBUILDING CLASSES!";
				$this->rebuildClasses($force);
				break;

			case 'prndevices':
				print "\nCHECKING PRINTERS DEVICE!";
				$this->rebuildPrintersDevice();
				break;

			case 'classes':
				print "\nREBUILDING CLASSES!";
				$this->rebuildClasses($force);
				break;

			case 'subjects':
				print "\nREBUILDING SUBJECTS!";
				$this->rebuildSubjects();
				break;

			case 'works':
				print "\nREBUILDING WORKS!";
				$this->rebuildWorks();
				break;

			case 'extdata':
				print "\nREBUILDING EXTDATA!";
				// undocumented args
				$filter_rebuild = isset($args[3]) ? $args[3] : null;
				$this->rebuildExtData(false, $force, $filter_rebuild);
				break;

			// undocumented
			case 'fixnametranslation':
				print "\nFIXING PERSONAL NAMES TRANSLATION!";
				$this->fixUnimarcPersonalNameTranslation();
				break;

			// undocumented
			case 'resave':
				print "\nRESAVING AUTHORITIES!";
				$auths = array();
				$conn = Propel::getConnection();
				// second param should contain the authority type filter
				if (!isset($args[2])) {
					$auths = $conn->query('SELECT * FROM '.AuthorityPeer::TABLE_NAME);
				} else {
					$auths = $conn->query('SELECT * FROM '.AuthorityPeer::TABLE_NAME.' WHERE '.
						AuthorityPeer::AUTHORITY_TYPE.' = \''.substr($args[2],0,1).'\'');
				}
				/** @var $a Authority */
				while($row = $auths->fetch(PDO::FETCH_NUM)) {
					print "\nProcessing [{$row[0]}]";
					$a = new Authority();
					$a->hydrate($row);
					$a = $this->rebuildISBD($a);
					if ($a->isModified())
						$a->save();
					$a->clearAllReferences(true);
					unset($a);
				}
				break;

			case 'common':
			default:
				print "\nREBUILDING COMMON!";
				$this->rebuildCommon();
				break;
		}

		echo "\n#### ALL DONE!!! ####\n";
		return true;
	}

	private function rebuildClasses($force_resave=false)
	{
		$auths = AuthorityQuery::create()
			->filterByAuthorityType(AuthorityPeer::TYPE_CLASS)
			->setFormatter(ModelCriteria::FORMAT_ON_DEMAND)
			->find();
		/** @var $a Authority */
		foreach ($auths as $a) {
			print "\nProcessing class [{$a->getAuthorityId()}] \"{$a->getFullText()}\"...";
			$a->reloadTurboMarc();
			$a->setClassCode(Clavis::sanitizeForXML($a->getClassCode()));
			$tm = $a->getTurboMarc();
			if ($tm instanceof TurboMarc) {
				if (isset($tm->d676))
					$a->setSubjectClass('676');
				else if (isset($tm->d680))
					$a->setSubjectClass('680');
				else if (isset($tm->d686))
					$a->setSubjectClass(isset($tm->d686->s2)
						? (string)$tm->d686->s2 : '686');
			}
			if ($a->isModified() || $force_resave) {
				print "\nUpdating incorrect class {$a->getAuthorityId()} [{$a->getClassCode()}]...";
				$a->save();
			}
			$a->clearAllReferences(true);
			unset($a);
		}
	}

	private function rebuildSubjects()
	{
		$subjs = AuthorityQuery::create()
			->filterByAuthorityType(AuthorityPeer::TYPE_SUBJECT)
			->setFormatter(ModelCriteria::FORMAT_ON_DEMAND)
			->find();
		$sclasses = array_keys(LookupValuePeer::getLookupClassValues('SUBJECTTYPE'));
		foreach ($subjs as $s) {
			print "\nProcessing subject [{$s->getAuthorityId()}] \"{$s->getFullText()}\"...";
			$stype = $s->getSubjectClass();
			if ($stype && !in_array($stype, $sclasses)) {
				print "nulling missing type {$stype}";
				$s->setSubjectClass(null);
			}
			$s->save();
			$s->clearAllReferences(true);
		}
	}

	private function rebuildWorks()
	{
		$works = AuthorityQuery::create()
			->filterByAuthorityType(AuthorityPeer::TYPE_WORK)
			->setFormatter(ModelCriteria::FORMAT_ON_DEMAND)
			->find();
		foreach ($works as $a) {
			$links = $a->getLAuthoritysRelatedByAuthorityIdDown();
			foreach ($links as $link) {
				/** @var $link LAuthority */
				if (!in_array($link->getAuthorityRelatedByAuthorityIdUp()->getAuthorityType(),
					array(	AuthorityPeer::TYPE_PERSONALNAME,
						AuthorityPeer::TYPE_CORPORATEBODYNAME,
						AuthorityPeer::TYPE_FAMILYNAME)))
					continue;
				// if work is DOWN and author is UP, link should be AB
				if (in_array($link->getLinkType(),array('BA','DC','FE'))) {
					$newlink = new LAuthority();
					$newlink->setAuthorityIdDown($a->getAuthorityId());
					$newlink->setAuthorityIdUp($link->getAuthorityIdUp());
					$newlink->setLinkType(strrev($link->getLinkType()));
					$newlink->setRelatorCode($link->getRelatorCode());
					$newlink->setLinkNote($link->getLinkNote());
					$newlink->save();
					$link->delete();
					echo "\nFixed BA link for work [{$a->getAuthorityId()}] and author [{$newlink->getAuthorityIdUp()}]";
					$link->clearAllReferences(true);
					$newlink->clearAllReferences(true);
				}
			}

			$links = $a->getLAuthoritysRelatedByAuthorityIdUp();
			foreach ($links as $link) {
				/** @var $link LAuthority */
				if (!in_array($link->getAuthorityRelatedByAuthorityIdDown()->getAuthorityType(),
					array(	AuthorityPeer::TYPE_PERSONALNAME,
						AuthorityPeer::TYPE_CORPORATEBODYNAME,
						AuthorityPeer::TYPE_FAMILYNAME)))
					continue;
				// if work is UP and author is DOWN, link should be BA
				if (in_array($link->getLinkType(),array('AB','CD','EF'))) {
					$newlink = new LAuthority();
					$newlink->setAuthorityIdDown($link->getAuthorityIdDown());
					$newlink->setAuthorityIdUp($a->getAuthorityId());
					$newlink->setLinkType(strrev($link->getLinkType()));
					$newlink->setRelatorCode($link->getRelatorCode());
					$newlink->setLinkNote($link->getLinkNote());
					$newlink->save();
					$link->delete();
					echo "\nFixed AB link for work [{$a->getAuthorityId()}] and author [{$newlink->getAuthorityIdDown()}]";
					$link->clearAllReferences(true);
					$newlink->clearAllReferences(true);
				}
			}
			// ..then resave work
			$a->save();
		}
	}

	private function rebuildCommon()
	{
		$conn = Propel::getConnection();
		$auths = $conn->query('SELECT '.implode(',',
			array(AuthorityPeer::AUTHORITY_ID,AuthorityPeer::SORT_TEXT,AuthorityPeer::FULL_TEXT,AuthorityPeer::CLASS_CODE)).
			' FROM '.AuthorityPeer::TABLE_NAME.' WHERE '.
				AuthorityPeer::AUTHORITY_TYPE.' <> \''.AuthorityPeer::TYPE_SUBJECT.'\'');
		$upAuth = $conn->prepare(
			'UPDATE '.AuthorityPeer::TABLE_NAME.' SET '.AuthorityPeer::SORT_TEXT.'=?, '.
				AuthorityPeer::FULL_TEXT.'=?, '.AuthorityPeer::CLASS_CODE.'=? WHERE '.
				AuthorityPeer::AUTHORITY_ID.'=?');
		foreach ($auths as $a) {
			print "\nProcessing authority {$a['authority_id']}...";
			$sanest = Clavis::sanitizeForXML(Clavis::html2xmlEntities($a['sort_text']));
			$sanecc = Clavis::sanitizeForXML(Clavis::html2xmlEntities($a['class_code']));
			if ($sanest != $a['sort_text'] || $sanecc != $a['class_code']) {
				print "UPDATING!";
				$upAuth->execute(array($sanest,
					Clavis::sanitizeForXML(Clavis::html2xmlEntities($a['full_text'])),
					$sanecc,
					$a['authority_id']));
			}
		}
	}

	private function rebuildPrintersDeviceExtData()
	{
		$prn = AuthorityQuery::create()
			->filterByAuthorityType(AuthorityPeer::TYPE_PRINTERSDEVICE)
			->filterByExtData(null, Criteria::NOT_EQUAL)
			->setFormatter(ModelCriteria::FORMAT_ON_DEMAND)
			->find();
		foreach ($prn as $a) {
			print "\nProcessing printers device [{$a->getAuthorityId()}] \"{$a->getFullText()}\"...";
			$extdata = unserialize($a->getExtData());
			if (is_array($extdata)) {
				if (array_key_exists('Descrizione', $extdata)) {
					$extdata['Description'] = $extdata['Descrizione'];
					unset($extdata['Descrizione']);
				} else {
					$extdata['Description'] = $a->getSortText();
				}
				if (array_key_exists('Motto', $extdata)) {
					$extdata['Watchword'] = $extdata['Motto'];
					unset($extdata['Motto']);
				}
				if (array_key_exists('Citazione', $extdata)) {
					$extdata['Quotation'] = $extdata['Citazione'];
					unset($extdata['Citazione']);
				}
				$a->setExtData(serialize($extdata));
				$a->save();
				$a->clearAllReferences(true);
			}
		}
	}

	private function rebuildClassesExtData()
	{
		$auths = AuthorityQuery::create()
			->filterByAuthorityType(AuthorityPeer::TYPE_CLASS)
			->setFormatter(ModelCriteria::FORMAT_ON_DEMAND)
			->find();
		/** @var $a Authority */
		foreach ($auths as $a) {
			print "\nProcessing class [{$a->getAuthorityId()}] \"{$a->getFullText()}\"...";
			$a->setClassCode(Clavis::sanitizeForXML($a->getClassCode()));
			$extdata = @unserialize($a->getExtData());
			if (!is_array($extdata)) {
				// most likely unserialize failed, so store a fixed version
				$extdata = array(
					'Note'  => array(),
					'ClassType' => 676,
					'ClassDescription'  => '',
					'ClassItemCode' => $a->getClassCode());
				$a->setExtData(serialize($extdata));
			} else if (array_key_exists('ClassVersion', $extdata)) {
				$extdata['ClassEdition'] = $extdata['ClassVersion'];
				unset($extdata['ClassVersion']);
				$a->setExtData(serialize($extdata));
			}
			if ($a->isModified()) {
				print "\nUpdating incorrect class {$a->getAuthorityId()} [{$a->getClassCode()}]...";
				$a->save();
			}
			$a->clearAllReferences(true);
		}
	}

	private function rebuildExtData($full=false, $force_rebuild=false, $filter_rebuild=null)
	{
		$this->rebuildPrintersDeviceExtData();
		if ($full) {
			$this->rebuildPrintersDeviceExtData();
			$this->rebuildClassesExtData();
		}
		$conn = Propel::getConnection();
		if (!$force_rebuild)
			$auths = $conn->query('SELECT * FROM '.AuthorityPeer::TABLE_NAME
				.' WHERE '.AuthorityPeer::UNIMARC.' IS NULL OR '.AuthorityPeer::UNIMARC.' LIKE \'\'');
		else if (!$filter_rebuild)
			$auths = $conn->query('SELECT * FROM '.AuthorityPeer::TABLE_NAME);
		else
			$auths = $conn->query('SELECT * FROM '.AuthorityPeer::TABLE_NAME
				.' WHERE '.AuthorityPeer::AUTHORITY_TYPE." = '{$filter_rebuild}'");

		$upAuth = $conn->prepare('UPDATE '.AuthorityPeer::TABLE_NAME
			.' SET '.AuthorityPeer::UNIMARC.'=? WHERE '
			.AuthorityPeer::AUTHORITY_ID.'=?');
		foreach ($auths as $a) {
			print "\nProcessing authority {$a['authority_id']}...";
			$extdata = @unserialize($a['ext_data']);
			if (!is_array($extdata))
				$extdata = array();

			$tm = TurboMarc::createRecord();

			$l = new TurboMarcLeader();
			$l->recLen = '01234';
			$l->recstatus = 'n';
			$l->type = $a['authority_rectype'];
			$l->entitytype = AuthorityPeer::mapTypeClavisToUnimarc($a['authority_type']);
			$tm->setLeader($l);

			$c001 = $tm->setControlField('001',$a['authority_id']);
			$c005 = $tm->setControlField('005',date('Ymdhms.0'));

			if (strtolower($a['bid_source']) == 'sbn') {
				$d099 = $tm->addField('099');
				$d099->addSubField('a',$a['bid']);
				$d099->addSubField('d',SBNConverter::ClavisType2SBNType($a['authority_type']));
				$d099->addSubField('e',$a['authority_codlevel']);
				// 801 is supported only by names and works
				if (in_array($a['authority_type'], array(AuthorityPeer::TYPE_PERSONALNAME,AuthorityPeer::TYPE_CORPORATEBODYNAME,
						AuthorityPeer::TYPE_FAMILYNAME,AuthorityPeer::TYPE_WORK))) {
					$d801 = $tm->addField('801');
					$d801->addSubField('a','IT');
					$d801->addSubField('b','ICCU');
				}
			}

			if (array_key_exists('ISADN',$extdata))
				$tm->addField('015')->addSubField('a',$extdata['ISADN']);

			$f100 = $tm->addField('100');
			$f100->setCDF('a',8, $a['authority_status']);
			$f100->setCDF('a',13, 50);	// ISO 10646
			if ($lang=$a['authority_lang']) {
				$tm->addField('101')->addSubField('a',strtolower($lang));
			}
			if (array_key_exists('Country',$extdata) && strlen(trim($extdata['Country'])) == 2)
				$tm->addField('102')->addSubField('a',$extdata['Country']);

			// notes management
			if (array_key_exists('Note',$extdata) && count($extdata['Note']) > 0) {
				foreach ($extdata['Note'] as $n) {
					if (trim($n['Note'])) {
						switch ($n['NoteType']) {
							case 'a':	// general note, 300
								$fnum = 300;
								break;
							case 'c':	// scope note
								$fnum = 330;
								break;
							case 'b':
								$fnum = 340;
								break;
							case 'r':
								$fnum = 830;
						}
						$tm->addField($fnum)->addSubField('a',TurboMarcUtility::encodeXML(trim($n['Note'])));
					}
				}
			}

			// titles
			if (array_key_exists('Titles',$extdata) && count($extdata['Titles']) > 0) {
				foreach ($extdata['Titles'] as $t) {
					if (trim($t['value'])) {
						$f5xx = $tm->addField($t['field']);
						$f5xx->addSubField('a',$t['value']);
						$f5xx->addSubField(strtolower($a['bid_source']),$a['bid']);
					}
				}
			}

			// class
			if (array_key_exists('ClassType',$extdata)) {
				switch ($extdata['ClassType']) {
					case '676':
					case '680':
						$f6xx = $tm->addField($extdata['ClassType']);
						break;
					default:
						$f6xx = $tm->addField('686');
						$f6xx->addSubField('2',$extdata['ClassType']);
						break;
				}
				$f6xx->addSubField('a',$a['class_code']);
				if (isset($extdata['ClassDescription']))
					$f6xx->addSubField('c',$extdata['ClassDescription']);
				if (isset($extdata['ClassEdition']))
					$f6xx->addSubField('v',$extdata['ClassEdition']);
				$f6xx->addSubField('i',isset($extdata['ClassItemCode'])
					? $extdata['ClassItemCode']
					: $a['class_code']);
			}

			// printers device
			if (array_key_exists('Watchword',$extdata)) {
				print "DEvice\n";
				if (!isset($tm->d921))
					$tm->addField(921);
				$tm->d921->addSubField('e',$extdata['Watchword']);
			}
			if (isset($extdata['Index']) && isset($extdata['Quotation'])) {
				if (!isset($tm->d921))
					$tm->addField(921);
				$tm->d921->addSubField('c',$extdata['Index'].$extdata['Quotation']);
			}
			for ($idx=1; $idx<6; ++$idx) {
				if (isset($extdata['Keyword'.$idx])) {
					if (!isset($tm->d921))
						$tm->addField(921);
					$tm->d921->addSubField('b',$extdata['Keyword'.$idx]);
				}
			}
			if (isset($tm->d921) && isset($extdata['Description'])) {
				$tm->d921->addSubField('a',$extdata['Description']);
			}

			switch ($a['authority_type']) {
				case AuthorityPeer::TYPE_SUBJECT:
					$f250 = $tm->addField('250');
					$auths = LSubjectQuery::create()
						->joinAuthorityRelatedByAuthorityId()
						->setFormatter(ModelCriteria::FORMAT_ON_DEMAND)
						->filterBySubjectId($a['authority_id'])
						->orderByPosition();
					if ($auths->count() > 0) {
						$parent = true;
						foreach ($auths->find() as $la) {
							$term = $la->getAuthorityRelatedByAuthorityId();
							if (!$term instanceof Authority) {
								// dangling link!!
								continue;
							}
							if ($parent) {
								$f250->addSubField('a',$term->getFullText());
								$parent = false;
							} else {
								$f250->addSubField('c',$la->getConnector());
								$f250->addSubField('x',$term->getFullText());
							}
							$term->clearAllReferences(true);
							$la->clearAllReferences(true);
						}
					}
					$f250->addSubField('2',$a['subject_class']);
					break;

				case AuthorityPeer::TYPE_ARGUMENT:
				case AuthorityPeer::TYPE_PLACE:
				case AuthorityPeer::TYPE_CHRONOLOGICAL:
					$f931 = $tm->addField(931);
					$f931->addSubField('a',$a['full_text']);
					break;

				case AuthorityPeer::TYPE_WORK:
					$tm->addField('230');
					$tm->d230->addSubField('a',trim($a['non_sort_text'].' *'.$a['sort_text']),' *');
					if (array_key_exists('WorkType',$extdata))
						$tm->d230->addSubField('w',$extdata['WorkType']);
					if (isset($lang))
						$tm->d230->addSubField('m',$lang);
					break;

				case AuthorityPeer::TYPE_CORPORATEBODYNAME:
					if (!isset($extdata['NameForm']))
						$extdata['NameForm'] = 'E';
					switch ($extdata['NameForm']) {
						case 'R': $i1 = '1'; $i2 = ' '; break;
						case 'G': $i1 = '0'; $i2 = '1'; break;
						case 'E': $i1 = '0'; $i2 = '2'; break;
					}
					$text = trim($a['non_sort_text'].' *'.$a['sort_text'],' *');
					$f200 = $tm->addField('210',$i1,$i2);
					$f200->addSubField('i',$extdata['NameForm']);
					$splitTag = preg_split("/([,<;]) /",$text,-1,PREG_SPLIT_DELIM_CAPTURE|PREG_SPLIT_NO_EMPTY);
					if (count($splitTag) == 0)
						$splitTag[0] = $text;
					$f200->addSubField('a',$splitTag[0]);
					for ($i=1; $i<count($splitTag); $i+=2) {
						if (isset($splitTag[$i+1]))
							switch($splitTag[$i]) {
								case ',':
									$f200->addSubField('b',$splitTag[$i+1]);
									break;
								case '<':
								case ';':
									$v = $splitTag[$i+1];
									if (strpos($v,'.')==='.')
										$f200->addSubField('d',$v);
									else if (preg_match('![\d-\?]!',$v)!==false)
										$f200->addSubField('f',$v);
									else
										$f200->addSubField('e',$v);
									break;
							}
					}
					// dates
					$dates = array();
					if (isset($extdata['DateStart']))
						$dates[] = $extdata['DateStart'];
					if (isset($extdata['DateEnd']))
						$dates[] = $extdata['DateEnd'];
					if ($dates = implode('-',$dates))
						$f200->addSubField('f',$dates);
					break;

				case AuthorityPeer::TYPE_TRADEMARK:
					if (!isset($name_fnum))
						$name_fnum = '216';
				case AuthorityPeer::TYPE_FAMILYNAME:
					if (!isset($name_fnum))
						$name_fnum = '220';
				case AuthorityPeer::TYPE_PERSONALNAME:
					if (!isset($name_fnum))
						$name_fnum = '200';
					if (!isset($extdata['NameForm']))
						$extdata['NameForm'] = 'A';
					switch ($extdata['NameForm']) {
						case 'A': $i2 = '0'; break;
						case 'B': $i2 = '0'; break;
						case 'C': $i2 = '1'; break;
						case 'D': $i2 = '1'; break;
					}
					$text = trim($a['non_sort_text'].' *'.$a['sort_text'],' *');
					$f200 = $tm->addField($name_fnum,' ',$i2);
					unset($name_fnum);
					$f200->addSubField('i',$extdata['NameForm']);
					$splitTag = preg_split("/([,<;]) /",$text,-1,PREG_SPLIT_DELIM_CAPTURE|PREG_SPLIT_NO_EMPTY);
					if (count($splitTag) == 0)
						$splitTag[0] = $text;
					$f200->addSubField('a',$splitTag[0]);
					for ($i=1; $i<count($splitTag); $i+=2) {
						if (isset($splitTag[$i+1]))
							switch($splitTag[$i]) {
								case ',':
									$f200->addSubField('b',', '.$splitTag[$i+1]);
									break;
								case '<':
								case ';':
									$f200->addSubField('c',trim($splitTag[$i+1],' >'));
									break;
							}
					}
					// dates
					$dates = array();
					if (isset($extdata['DateStart']))
						$dates[] = $extdata['DateStart'];
					if (isset($extdata['DateEnd']))
						$dates[] = $extdata['DateEnd'];
					$dates = implode('-',$dates);
					if ($dates != '-')
						$f200->addSubField('f',$dates);
					break;

				case AuthorityPeer::TYPE_PUBPLACE:
					$f200 = $tm->addField('260');
					if (array_key_exists('Country',$extdata))
						$f200->addSubField('a',$extdata['Country']);
					if (isset($extdata['Region']))
						$f200->addSubField('c',$extdata['Region']);
					$f200->addSubField('d',$a['sort_text']);
					break;

				default:
					break;
			}

			$xml = TurboMarcUtility::sortFields($tm)->asXML();
			$upAuth->execute(array($xml,$a['authority_id']));
		}
	}

	private function fixUnimarcPersonalNameTranslation()
	{
		$conn = Propel::getConnection();
		$auths = $conn->query('SELECT * FROM '.AuthorityPeer::TABLE_NAME
			.' WHERE '.AuthorityPeer::AUTHORITY_TYPE.' = \''.AuthorityPeer::TYPE_PERSONALNAME.'\'');
		$upAuth = $conn->prepare('UPDATE '.AuthorityPeer::TABLE_NAME
			.' SET '.AuthorityPeer::UNIMARC.'=? WHERE '
			.AuthorityPeer::AUTHORITY_ID.'=?');
		foreach ($auths as $a) {
			print "\nProcessing authority {$a['authority_id']}...";
			$tm = TurboMarc::createRecord($a['unimarc']);
			foreach (array('d300','d330','d340','d830') as $fakenote) {
				foreach ($tm->$fakenote as $fld) {
					if (isset($fld->si)) {
						if (!isset($tm->d200)) {
							$fld200 = $tm->addField('200',$fld['i1'],$fld['i2']);
							if (isset($fld->sa) && trim($fld->sa))
								$fld200->addSubField('a',(string)$fld->sa);
							if (isset($fld->sb) && trim($fld->sb))
								$fld200->addSubField('b',(string)$fld->sb);
							if (isset($fld->sc) && trim($fld->sc))
								$fld200->addSubField('c',(string)$fld->sc);
							if (isset($fld->si) && trim($fld->si))
								$fld200->addSubField('i',(string)$fld->si);
							if (isset($fld->sf) && trim($fld->sf))
								$fld200->addSubField('f',(string)$fld->sf);
						}
						$fld->remove();
					}
				}
			}
			$xml = TurboMarcUtility::sortFields($tm)->asXML();
			$upAuth->execute(array($xml,$a['authority_id']));
		}
	}

	public function rebuildISBD(Authority $a)
	{
		$tm = $a->getTurboMarc();
		unset($fnum);
		switch ($a->getAuthorityType())
		{
            case AuthorityPeer::TYPE_PLACE:
            case AuthorityPeer::TYPE_PUBPLACE:
			case AuthorityPeer::TYPE_ARGUMENT:
				$text = html_entity_decode($a->getSortText());
				unset($tm->d931);
				$f931 = $tm->addField(931);
				$f931->addSubField('a',$text);
				break;

			case AuthorityPeer::TYPE_CORPORATEBODYNAME:
				$text = html_entity_decode($a->getSortText());
				if (isset($tm->d210)) {
					$name_form = (string)$tm->d210->si;
					unset($tm->d210);
				} else {
					$name_form = 'E';
				}
				switch ($name_form) {
					case 'R': $i1 = '1'; $i2 = ' '; break;
					case 'G': $i1 = '0'; $i2 = '1'; break;
					case 'E': $i1 = '0'; $i2 = '2'; break;
					default: $i1 = '1'; $i2 = ' '; break;
				}
				$f200 = $tm->addField('210',$i1,$i2);
				$f200->addSubField('i',$name_form);
				switch ($name_form) {
					case 'R':
						$f200->addSubField('a',trim(strtok($text,'<')));
						while ($v = trim(strtok(';'),'>')) {
							if (substr_compare($v, '. ', -2, 2) === 0)
								$f200->addSubField('d',trim($v,'<; '));
							else if (substr_compare($v,'fl.',0,3)==0
								|| substr_compare($v,'m.',0,2)==0
								|| substr_compare($v,'n.',0,2)==0
								|| substr_compare($v,'sec.',0,4)==0
								|| substr_compare($v,'ca.',0,3)==0
								|| preg_match('!^\s*\d{4}!',$v)>0)
								$f200->addSubField('f',trim($v,'<; '));
							else
								$f200->addSubField('e',trim($v,'<; '));
						}
						break;
					case 'E':
						$f200->addSubField('a',trim(strtok($text,'<')));
						while ($v = trim(strtok(';'),'>')) {
							if (substr_compare($v,'fl.',0,3)==0
								|| substr_compare($v,'m.',0,2)==0
								|| substr_compare($v,'n.',0,2)==0
								|| substr_compare($v,'sec.',0,4)==0
								|| substr_compare($v,'ca.',0,3)==0
								|| preg_match('!^\s*\d{4}!',$v)>0)
								$f200->addSubField('f',trim($v,'<; '));
							else
								$f200->addSubField('c',trim($v,'<; '));
						}
						break;
					case 'G':
						$parts = explode(' : ',$text);
						foreach ($parts as $k => $p) {
							$split = explode(' <',$p,2);
							$f200->addSubField(0==$k?'a':'b',array_shift($split));
							if ($split)
								foreach(explode(' ; ',$split[0]) as $sfc)
									$f200->addSubField('c',trim($sfc,'>; '));
						}
						break;
				}
				break;

			case AuthorityPeer::TYPE_TRADEMARK:
				if (!isset($fnum))
					$fnum = '216';
			case AuthorityPeer::TYPE_FAMILYNAME:
				if (!isset($fnum))
					$fnum = '220';
			case AuthorityPeer::TYPE_PERSONALNAME:
				if (!isset($fnum))
					$fnum = '200';
				$tag = "d{$fnum}";
				$text = html_entity_decode($a->getCompleteText(),ENT_COMPAT,'UTF-8');
				if (isset($tm->$tag)) {
					$name_form = (string)$tm->$tag->si;
					unset($tm->$tag);
				} else {
					$name_form = 'C';
				}
				switch ($name_form) {
					case 'A': $i2 = '0'; break;
					case 'B': $i2 = '0'; break;
					case 'C': $i2 = '1'; break;
					case 'D': $i2 = '1'; break;
					default: $i2 = '0'; break;
				}
				$f200 = $tm->addField($fnum,' ',$i2);
				$f200->addSubField('i',$name_form);
				if (0 == $i2) {
					$f200->addSubField('a',trim(strtok($text,'<')));
				} else {
					$f200->addSubField('a',trim(strtok($text,',')));
					$f200->addSubField('b',', '.trim(strtok('<')));
				}
				while ($v = trim(strtok(';'),'>')) {
					if (substr_compare($v,'fl.',0,3)==0
						|| substr_compare($v,'m.',0,2)==0
						|| substr_compare($v,'n.',0,2)==0
						|| substr_compare($v,'sec.',0,4)==0
						|| substr_compare($v,'ca.',0,3)==0
						|| preg_match('!^\s*\d{4}!',$v)>0)
						$f200->addSubField('f',trim($v,'<; '));
					else
						$f200->addSubField('c',trim($v,'<; '));
				}
				break;

			default:
				break;
		}
		$a->setUnimarc($tm->asXML());
		return $a;
	}
}
