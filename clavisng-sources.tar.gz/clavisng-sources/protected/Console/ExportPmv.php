<?php

/**
 * ClavisActionExportPmv class file.
 *
 * @author Fabio Argenti <fabio@comperio.it>
 * @link https://www.comperio.it/
 * @copyright Copyright &copy; 2006-2019 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Console
 */
require_once('ClavisCommandLineAction.php');

/**
 * ClavisActionExport Class
 *
 * @author Fabio Argenti <fabio@comperio.it>
 * @version 2.8
 * @package Console
 * @since 2.5.0
 */
class ClavisActionExportPmv extends ClavisCommandLineAction {

    protected $action = 'export_pmv';
    protected $parameters = array('s|a');
    protected $optional = array();
    protected $description = 'Export informations of libraries to JSON format for PMV\n';

    /**
     * Input parameters:
     * [(a)nagraphical] [account] [password] [dest_dir]
     * [(s)tatistical] [account] [password] [dest_dir] [model] [date_begin] [date_end]
     * @param type $args
     * @return boolean
     */
    public function performAction($args) {
        if (sizeof($args) < 5) {
            echo "Parameters number error!\n";
            return 1;
        }
        if (($args[1] != "a") && ($args[1] != "s")) {
            echo "Parameter type error!\n";
            return 1;
        }
        if (($args[1] == "a") && (!isset($args[2]) || !isset($args[3]) || !isset($args[4]))) {
            echo "Anagraphical parameters error!\n";
            return 1;
        }
        if (($args[1] == "s") && (!isset($args[2]) || !isset($args[3]) || !isset($args[4]) || !isset($args[5]) || !isset($args[6]) || !isset($args[7]))) {
            echo "Anagraphical parameters error!\n";
            return 1;
        }
        switch ($args[1]) {
            case 'a': // Recupero anagrafica biblioteca
                $data = array();
                $data["account"] = $args[2];
                $data["password"] = $args[3];
                $data["datiAnagrafica"]["tipoAccesso"] = "APERTO";
                $giorni = array('DOM', 'LUN', 'MAR', 'MER', 'GIO', 'VEN', 'SAB');
                foreach (LibraryQuery::create()->findByLibraryInternal(1) as $library) {
                    if (((string) $library->getIllCode() != "")) {
                        // Insieme minimo richiesto
                        $data["codIsil"] = (string) $library->getIllCode();
                        $data["codSbn"] = ((string) $library->getSbnCode() != "" ? (string) $library->getSbnCode() : "");
                        $data["datiAnagrafica"]["deBiblioteca"] = (trim($library->getDescription()) != "" ? trim($library->getDescription()) : "");
                        $data["datiAnagrafica"]["indirizzo"] = (trim($library->getAddress()) != "" ? trim($library->getAddress()) : "");
                        // Estrazione dei valori CAP e Codice ISTAT del Comune
                        if (!is_null($library->getBillingAddress())) {
                            $b = explode(" ", $library->getBillingAddress());
                            $data["datiAnagrafica"]["codCap"] = (isset($b[0]) && !is_null($b[0])) ? trim($b[0]) : "";
                            $data["datiAnagrafica"]["codIstatComune"] = (isset($b[1]) && !is_null($b[1])) ? sprintf("%06s", trim($b[1])) : "";
                        }
                        $data["datiAnagrafica"]["telefono"] = (trim($library->getPhone()) != "" ? preg_replace('/[^0-9]+/', '', trim($library->getPhone())) : "");
                        $data["datiAnagrafica"]["fax"] = (trim($library->getFax()) != "" ? preg_replace('/[^0-9]+/', '', trim($library->getFax())) : "");
                        $data["datiAnagrafica"]["email"] = trim($library->getEmail()); // OBBLIGATORIO
                        if (trim($library->getWebsite()) != "") {
                            $data["datiAnagrafica"]["sitoInternet"] = trim($library->getWebsite());
                        }
                        $data["datiAnagrafica"]["variazioneOrario"] = "Orario dal " . date('j-n-Y', strtotime("+1 day")) . " al " . date('j-n-Y', strtotime("+7 day"));
                        // Recupero orari con filtro su APERTURA, ID_LIBRERIA, 7 GIORNI dalla data di lancio dello script
                        $orario = LibraryTimetableQuery::create()
                                ->filterByLibraryId($library->getLibraryId())
                                ->filterByTimetableOpen(true)
                                ->where('library_timetable.timetable_day >= \'' . date('Y-m-d', strtotime("+1 day")) . '\' AND library_timetable.timetable_day <= \'' . date('Y-m-d', strtotime("+7 day")) . '\'')
                                ->find();
                        // Estrazione nomi giorni e fascia oraria
                        foreach ($orario as $key => $fascia) {
                            // Generazione array degli orari settimanali per biblioteca
                            $temp = array();
                            if (!is_null($fascia->getTime1Start()) && !is_null($fascia->getTime1End())) {
                                $temp["datiAnagrafica"]["orario"][$key]["giorno"] = $giorni[date('w', strtotime($fascia->getTimetableDay()))];
                                $temp["datiAnagrafica"]["orario"][$key]["tipo"] = "M";
                                $temp["datiAnagrafica"]["orario"][$key]["dalle"] = substr($fascia->getTime1Start(), 0, -3);
                                $temp["datiAnagrafica"]["orario"][$key]["alle"] = substr($fascia->getTime1End(), 0, -3);
                            }
                            if (!is_null($fascia->getTime2Start()) && !is_null($fascia->getTime2End())) {
                                $temp["datiAnagrafica"]["orario"][$key + 1]["giorno"] = $giorni[date('w', strtotime($fascia->getTimetableDay()))];
                                $temp["datiAnagrafica"]["orario"][$key + 1]["tipo"] = "P";
                                $temp["datiAnagrafica"]["orario"][$key + 1]["dalle"] = substr($fascia->getTime2Start(), 0, -3);
                                $temp["datiAnagrafica"]["orario"][$key + 1]["alle"] = substr($fascia->getTime2End(), 0, -3);
                            }
                            if (!is_null($fascia->getTime3Start()) && !is_null($fascia->getTime3End())) {
                                $temp["datiAnagrafica"]["orario"][$key + 2]["giorno"] = $giorni[date('w', strtotime($fascia->getTimetableDay()))];
                                $temp["datiAnagrafica"]["orario"][$key + 2]["tipo"] = "S";
                                $temp["datiAnagrafica"]["orario"][$key + 2]["dalle"] = substr($fascia->getTime3Start(), 0, -3);
                                $temp["datiAnagrafica"]["orario"][$key + 2]["alle"] = substr($fascia->getTime3End(), 0, -3);
                            }
                            // Inserimento dell'array orari nell'array principale
                            if (!empty($temp)) {
                                foreach ($temp["datiAnagrafica"]["orario"] as $key => $value) {
                                    if (isset($value["dalle"]) && !is_null($value["dalle"]) && $value["dalle"] != "" &&
                                            isset($value["alle"]) && !is_null($value["alle"]) && $value["alle"] != "") {
                                        $data["datiAnagrafica"]["orario"][] = $value;
                                    }
                                }
                            }
                        }
                        // Scrittura dei singoli file
                        file_put_contents($args[4] . (string) $library->getIllCode() . '.json', json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
                        echo "### ---> Creato file " . (string) $library->getIllCode() . ".json per la Biblioteca di " . $library->getDescription() . " con ID " . $library->getLibraryId() . "\n";
                        unset($data["datiAnagrafica"]["orario"]);
                    } else {
                        echo "### ---> Nessun codice ISIL (CODICE NAZIONALE) per la Biblioteca di " . $library->getDescription() . " con ID " . $library->getLibraryId() . "\n";
                    }
                }
                echo "### ---> End\n";
                Prado::log("Finishing ExportPmv Anagraphical Data", TLogger::INFO, "Batch");
                break;
            case 's':
                $queries = new PMVQueries();
                $con = Propel::getConnection();
                $temp = array();
                // Insieme minimo richiesto dei dati
                $data = array();
                $data["account"] = $args[2];
                $data["password"] = $args[3];
                $data["codModello"] = $args[5];
                // Valori fissi
                $fissi = array();
                $fissi["2006-213"]["rispostaBol1"] = "N";
                $fissi["2006-259"]["rispostaBol1"] = "N";
                $fissi["2006-212"]["rispostaBol1"] = "Y";
                $fissi["2006-201"]["rispostaDlv1"] = "1";
                // Ciclo sulle librerie interne
                foreach (LibraryQuery::create()->findByLibraryInternal(1) as $library) {
                    // Verifica validità biblioteca
                    if (((string) $library->getIllCode() != "")) {
                        $data["codIsil"] = $library->getIllCode();
                        // Costruzione array delle risposte
                        // Estrazione degli index e preparazione dell'array dei risultati
                        // Valori fissi
                        foreach ($fissi as $key => $value) {
                            $val = array_keys($value);
                            $temp["questionario"][] = array("codDomanda" => $key, $val[0] => $value[$val[0]]);
                        }
                        // Valori calcolati
                        // Inserimento delle query nello statement
                        foreach ($queries->populateArray() as $k => $query) {
                            $resp = array();
                            foreach ($query as $key => $sql) {
                                // Crea connessione
                                $command = $con->prepare($sql);
                                // Rimpiazzo dei segnaposti con i parametri passati al lancio dello script
                                // LIBRARY_ID: library_id, DATE_FROM: args[5], DATE_TO: args[6]
                                $libraryID = $library->getLibraryId();
                                $command->bindParam(":lib_id", $libraryID, PDO::PARAM_INT);
                                // Verifico se esistono le date tra i parametri da 'bindare'
                                if (strpos($sql, ":date_from") !== false) {
                                    $command->bindParam(":date_from", $args[6], PDO::PARAM_STR);
                                }
                                if (strpos($sql, ":date_to") !== false) {
                                    $command->bindParam(":date_to", $args[7], PDO::PARAM_STR);
                                }
                                // Esecuzione
                                $command->execute();
                                $val = $command->fetchColumn(0);
                                // Inserisce il valore solo se la query da un risultato
                                if (isset($val) && !is_null($val) && $val != "") {
                                    $resp["codDomanda"] = $k;
                                    $resp[$key] = $val;
                                    $temp["questionario"][] = $resp;
                                }
                            }
                        }
                        // Esecuzione
                        // Inserimento dell'array orari nell'array principale
                        foreach ($temp["questionario"] as $key => $v) {
                            $data["questionario"][] = $v;
                        }
                        unset($temp["questionario"]);
                        // Generazione file in formato JSON
                        file_put_contents($args[4] . (string) $library->getIllCode() . '.json', json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
                        echo "### ---> Creato file " . (string) $library->getIllCode() . ".json per la Biblioteca di " . $library->getDescription() . " con ID " . $library->getLibraryId() . "\n";
                        unset($data["questionario"]);
                    } else {
                        echo "### ---> Nessun codice ISIL (CODICE NAZIONALE) per la Biblioteca di " . $library->getDescription() . " con ID " . $library->getLibraryId() . "\n";
                    }
                }
                echo "### ---> End\n";
                Prado::log("Finishing ExportPmv Statistical Data", TLogger::INFO, "Batch");
                break;
            default:
                break;
        }
        return true;
    }

}
