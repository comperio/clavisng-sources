<?php

/**
 * Realign clavis mikrotik resources with nas radius table
 *
 * @author Cristian <ciarez@comperio.it>
 * @version 2.8.2
 * @package Console
 * @since 2.8.2
 */

require_once('ClavisCommandLineAction.php');

/**
 * @package Console
 * @since 2.8.2
 */
class ClavisActionRealignResources extends ClavisCommandLineAction
{
	protected $action = 'realign_resources';
	protected $parameters = array('clavisurl like mydomain.com/clavisng');
	protected $optional = array('dryrun run without effetive actions');
	protected $description = "WARNING! Radius server will be RESTARTED for EACH resource.\nPAY ATTENTION\nPress CTRL+C to stop.\nRealign clavis mikrotik resources with remote nas radius table.\n";
	
	
	public function performAction($args)
	{
		try
		{
			$rss = ResourceQuery::create()
			->filterByType(Resource::TYPE_MIKROTIK)
			->findByDescription('%'.$args[1].'%');
			echo(count($rss) . " resources found\n");
			foreach($rss as $rs)
			{
				if(isset($args[2]))
				{
					echo("Resource id {$rs->getResourceId()} desc {$rs->getDescription()}\n");
					continue;
				}
				
				
				if($rs instanceof Resource)
				{
					$rid = $rs->getResourceId();
					echo($rid . "\n");
					$client = ClavisRadUtil::getClient($rs->getLibraryId());
					$res = $client->setNas($rs->toArray());
					//Prado::log(Prado::varDump($res));
					if (isset($res['result']) && isset($res['result']['status']) && $res['result']['status'] == 'ack')
					{
						if (isset($res['result']['data']['extid']))
						{
							$extid = $res['result']['data']['extid'];
							$rs->setResourceExternalId($extid);
							$rs->save();
						}
						else
						{
							echo(__METHOD__ . ' no id given from remote for resource \n');
						}
					}
				}
				sleep(5);
			}
			echo __METHOD__ . " done.\n";
			return true;
		} catch (Exception $ex) {
			echo __METHOD__ . " EXCEPTION: " . $ex->getMessage() . "\n";
		}
	}
}