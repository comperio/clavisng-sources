<?php
/**
 * ClavisActionSyncBncfThesaurus class file.
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 * Sources should be available via "Download" link available in all pages.
 * gg * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 * For Commercial Licenses and support please contact Comperio.
 * @author    Mauro Seno <mauro.seno@comperio.it>
 * @link      http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license   http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version   2.9
 * @package   Console
 */
require_once 'ClavisCommandLineAction.php';

/**
 * Class ClavisActionSyncBncfThesaurus
 */
class ClavisActionSyncBncfThesaurus extends ClavisCommandLineAction
{
	protected $action = 'sync_bncf_thesaurus';
	protected $parameters = array();
	protected $optional = array('zipfile');
	protected $description = '';

	private $skosZip = 'http://thes.bncf.firenze.sbn.it/dati/NS-SKOS.zip';

	/**
	 * @param $args
	 * @return bool
	 * @throws \PropelException
	 */
	public function performAction($args)
	{
		echo "=== Starting ===\n";
		if (count($args) > 1) {
			$this->skosZip = $args[1];
		}

		$this->populateTermResource();
		$processedIds = $this->syncTerms();

		$this->syncExpiredTerms($processedIds);

		echo "\n#### ALL DONE!!! ####\n";
		return true;
	}


	/**
	 *
	 */
	private function syncTerms(): array
	{
		echo "Starting sync process...\n";
		$bncf = BncfThesaurus::create($this->skosZip)->parse();
		echo "Syncing done.\n";

		return $bncf->getProcessedBids();
	}

	/**
	 * @throws \PropelException
	 */
	private function populateTermResource()
	{
		$oldAuthorities = AuthorityQuery::create()
			->filterByAuthorityStatus(AuthorityPeer::INTERNALSTATUS_THESAURUS)
			->filterByBidSource(null)
			->filterByBid(null)
			->setFormatter(ModelCriteria::FORMAT_ON_DEMAND)
			->find();
		if ($oldAuthorities->count() < 1) {
			return;
		}

		echo "Recovering old-style terms...\n";
		echo "  (if it's the first time you run this script and you were using old model to sync BNCF\n";
		echo "   this can take some time... please wait)\n";

		foreach ($oldAuthorities as $a) {
			/* @var $a Authority */
			echo "Updating OLD term resource: {$a->getSortText()} [{$a->getAuthorityId()}]...";
			foreach ($a->getNotes() as $n) {
				if (preg_match('!Fonte: <a target="_blank" href="http://thes\.bncf\.firenze\.sbn\.it/termine.php\?id=(\d+)">!', $n['NoteValue'], $match)) {
					echo ' found with termId ' . intval($match[1]) . "!\n";
					try {
						$a->setBidSource(BncfThesaurus::BNCF_BID_SOURCE);
						$a->setBid('http://purl.org/bncf/tid/' . intval($match[1]));
						$a->save();
					} catch (Exception $e) {

					}
					break;
				}
			}
			if (!$a->getBid()) {
				echo " NOT FOUND!!\n";
				// term malformed
				$a->setBidSource(BncfThesaurus::BNCF_BID_SOURCE);
				$a->setBid('WAS-' . $a->getAuthorityId());
				$a->setAuthorityStatus(AuthorityPeer::INTERNALSTATUS_PROVISIONAL);
				$a->setAuthorityType(AuthorityPeer::TYPE_ARGUMENT);
				$a->save();
			}
		}
		echo "..recover finished.\n";
	}

	/**
	 * @param $processedIds
	 * @throws \PropelException
	 */
	private function syncExpiredTerms($processedIds): void
	{
		echo 'Syncing processed bid....' . PHP_EOL;

		$expired = AuthorityQuery::create()
			->filterByAuthorityStatus(AuthorityPeer::INTERNALSTATUS_THESAURUS)
			->filterByBidSource(BncfThesaurus::BNCF_BID_SOURCE)
			->filterByBid($processedIds, Criteria::NOT_IN)
			->setFormatter(ModelCriteria::FORMAT_ON_DEMAND)
			->find();

		$expiredCount = $expired->count();
		if ($expiredCount > 0) {
			echo "\nProcessing $expiredCount expired (not found) terms..." . PHP_EOL;
			$index = 0;
			foreach ($expired as $a) {
				/* @var $a Authority */
				$tr = $a->getBid();
				$termId = (int)str_replace('http://purl.org/bncf/tid/', '', $tr);

				++$index;
				echo "[$index/$expiredCount] Setting termId {$termId} [{$a->getSortText()}] as provisional (c)." . PHP_EOL;

				$a->setBidSource(BncfThesaurus::BNCF_BID_SOURCE);
				$a->setBid(null);

				$a->setAuthorityStatus(AuthorityPeer::INTERNALSTATUS_PROVISIONAL);
				$a->setAuthorityType(AuthorityPeer::TYPE_ARGUMENT);
				$a->save();
			}
		}
	}
}

class BncfThesaurusElement
{
	public $skos;
	public $skosxl;
	public $isoThes;
	public $rfds;

	public $xml;
	public $name;
	public $authority_id;

	public $links;
	public $notes;
	public $recType;
	public $notation;

	public $termName;
	public $literalForm;
	private $type;


	/**
	 * BncfThesaurusElement constructor.
	 * @param \SimpleXMLElement $xml
	 * @param string            $name
	 */
	public function __construct(SimpleXMLElement $xml, string $name)
	{
		$this->xml = $xml;
		$this->name = $name;

		$this->skos = $this->xml->children('http://www.w3.org/2004/02/skos/core#');
		$this->skosxl = $this->xml->children('http://www.w3.org/2008/05/skos-xl#');
		$this->isoThes = $this->xml->children('"http://purl.org/iso25964/skos-thes#"');
		$this->rfds = $this->xml->children('http://www.w3.org/2000/01/rdf-schema');


		// init attributi. initRecType deve essere chiamato prima di initTermName.
		$this->initType($name);
		$this->initRecType();
		$this->initTermName();
		$this->initNotes();
		$this->initNotation();

		// init legami
		$this->initLinks();
	}

	/**
	 * @param \SimpleXMLElement $xml
	 * @param string            $name
	 * @return \BncfThesaurusElement
	 */
	public static function create(SimpleXMLElement $xml, string $name)
	{
		return new self($xml, $name);
	}

	/**
	 * @param \BncfThesaurus $thes
	 * @return \BncfThesaurusElement
	 */
	public function addToTermDB(BncfThesaurus $thes): \BncfThesaurusElement
	{
		$thes->addToTermDB($this);
		return $this;
	}

	/**
	 * @return bool
	 */
	public function isTopTerm(): bool
	{
		$count = count($this->getSkos()->broader);
		return $count < 1;
	}

	/**
	 * @return string
	 */
	public function getFullId(): string
	{
		return (string)$this->xml['about'];
	}

	/**
	 * @return string
	 */
	public function getShortId(): string
	{
		return $this->buildShortId($this->getFullId());
	}

	/**
	 * @param $fullId
	 * @return int
	 */
	public function buildShortId($fullId): int
	{
		return (int)str_replace('http://purl.org/bncf/tid/', '', $fullId);
	}

	/**
	 * @param $shortId
	 * @return string
	 */
	public function buildFullId($shortId)
	{
		return 'http://purl.org/bncf/tid/' . $shortId;
	}

	/**
	 * @param $name
	 */
	public function setName($name): void
	{
		$this->name = $name;
	}

	/**
	 * @return mixed
	 */
	public function getType()
	{
		return $this->type;
	}

	/**
	 * @param string $termName
	 * @return \Authority
	 * @throws \PropelException
	 */
	public function buildAuthority(string $termName): \Authority
	{
		$a = $this->getAuthority($termName);
		$this->populateAuthority($a);
		return $a;
	}

	/**
	 * @return mixed
	 */
	public function getAuthorityId()
	{
		return $this->authority_id;
	}

	/**
	 * @param mixed $authority_id
	 */
	public function setAuthorityId($authority_id): void
	{
		$this->authority_id = $authority_id;
	}

	/**
	 * @return \SimpleXMLElement
	 */
	public function getSkos()
	{
		return $this->xml->children('http://www.w3.org/2004/02/skos/core#');
	}

	/**
	 * @return mixed|string
	 */
	private function getAuthorityType()
	{
		$string = $this->type;
		$typeMap = BncfThesaurus::getTypeMap();

		$string = preg_replace('~&([a-z]{1,2})(?:acute|cedil|circ|grave|lig|orn|ring|slash|th|tilde|uml);~i',
			'$1', htmlentities($string, ENT_QUOTES, 'UTF-8'));
		$string = str_replace(':', ' ', $string);
		$string = strtoupper($string);

		return array_key_exists($string, $typeMap) ? $typeMap[$string] : 'A';
	}

	/**
	 * @return \SimpleXMLElement
	 */
	private function getSkosXL()
	{
		return $this->xml->children('http://www.w3.org/2008/05/skos-xl#');
	}

	/**
	 * @return \SimpleXMLElement
	 */
	private function getIsoThes()
	{
		return $this->xml->children('http://purl.org/iso25964/skos-thes#');
	}

	/**
	 * @return \SimpleXMLElement
	 */
	private function getRDFs()
	{
		return $this->xml->children('http://www.w3.org/2000/01/rdf-schema#');
	}

	/**
	 *
	 */
	private function initNotation(): void
	{
		$this->notation = trim((string)$this->getSkos()->notation);
	}

	/**
	 * @param $termName
	 * @return \Authority
	 * @throws \PropelException
	 */
	private function getAuthority($termName = null): \Authority
	{
		/*
		 * Search if an authority linked to the current bid exists in Clavis.
		 * I can't have another authority with bid equals to the current one,
		 * so during the merge, if this exist, I must squash everything into this one.
		 */

		/** @var \Authority $a */
		$a = AuthorityQuery::create()
			->filterByBidSource(BncfThesaurus::BNCF_BID_SOURCE)
			->filterByBid($this->getFullId())
			->findOne();

		/*
		 *
		 * Perform a search for the $termName on the authority's sort test field in order
		 * to grab all the authorities than can be joined together.
		 */
		if ($termName !== null) {

			$auths = AuthorityQuery::create()
				->filterBySortText($termName)
				->filterByAuthorityType(AuthorityPeer::TYPE_ARGUMENT, Criteria::EQUAL)
				->find();

			/*
			 * If more than one results are found, emit a warning.
			 * Then, save into the bid -> authority map the first authority id found.
			 * (Search for: $el->setAuthorityId($aid);)
			 *
			 * This authority becomes the only authority linked to the current bid.
			 */
			if (\count($auths) > 1) {
				echo "\e[00;31;1m WARNING!! MULTIPLE AUTHORITIES FOUND FOR $this->termName ***\e[0m ";
			}

			// $a is the destination authority.
			$a = ($a instanceof Authority) ? $a : reset($auths);

			// replace all the remaining authorities with the one that must survive and become the one and only official
			// BNCF authority.
			foreach ($auths as $index => $auth) {
				if (!$a->equals($auth)) {
					$row_affected = $auth->replaceWith($a);
					$a->save();

					if ($row_affected === false) {
						echo "\e[00;31;1m Can't squash authority with id $auth->getId() into $a->getId()***\e[0m ";
					}
				}
			}
		}

		/*
		 * Ok, no authority no party. Let's create one.
		 */
		if (!$a instanceof Authority) {
			// ..if not, search for a suitable authority
			echo "\e[00;35;1m *** Creo nuova voce $this->termName ***\e[0m ";

			$a = AuthorityQuery::create()
				->filterBySortText($this->termName)
				->filterByAuthorityStatus(AuthorityPeer::INTERNALSTATUS_THESAURUS)
				->findOneOrCreate();
		}
		return $a;
	}

	/**
	 * @param \Authority $a
	 */
	private function populateAuthority(Authority $a): void
	{
		if ($a instanceof Authority) {
			try {
				$a->setSortText($this->termName);
				$a->setAuthorityStatus(AuthorityPeer::INTERNALSTATUS_THESAURUS);
				$a->setBidSource(BncfThesaurus::BNCF_BID_SOURCE);
				$a->setBid($this->getFullId());

				$a->setAuthorityRectype($this->recType);

				$authorityType = $this->getAuthorityType();

				if (in_array($authorityType, array('A', 'B', 'N'))) {
					$a->setAuthorityType($authorityType);
				} else {
					$a->setAuthorityType('A');
					$a->setAuthoritySubtype($authorityType);
				}
				$a->setAuthorityCodlevel('90');

				if (count($this->notes)) {
					$a->setNotes($this->notes);
				}

				$a->save();

			} catch (Exception $e) {
				die('Exception: ' . $e . "\n" . Prado::varDump($a));
			}
		}
	}

	/**
	 *
	 */
	private function initLinks()
	{
		/**
		 * BT       Broader term (Termine generico)    Relazione gerarchica    relazione tra un termine preferito e il termine preferito immediatamente sovraordinato (più generale). La relazione reciproca é N
		 * NT       Narrower term (Termine specifico)    Relazione gerarchica    relazione tra un termine preferito e il termine preferito immediatamente subordinato (più specifico). La relazione reciproca é BT
		 * RT       Related term (Termine associato)    Relazione associativa    relazione reciproca tra due termini correlati
		 * UF       Used for (Usato per)    Relazione di equivalenza    relazione tra un termine preferito e un suo sinonimo o quasi-sinonimo non preferito (used for). La relazione reciproca é USE
		 * UF+      Used for + (È nel termine composto non preferito)    Legame di scomposizione    collegamento tra i termini preferiti derivanti dalla scomposizione di un termine composto non più accettato e il composto stesso. La relazione reciproca é USE+
		 * USE      Use (Usare)    Relazione di equivalenza    relazione tra un termine non preferito e il termine preferito (use). La relazione reciproca é UF
		 * USE+     Use + (Scomposto in)    Legame di scomposizione    collegamento tra un termine composto non più accettato e i termini derivanti dalla scomposizione. La relazione reciproca é UF+
		 * HSEE     Historical see (Variante storica di)    Legame di variante storica (legame non standard)    collegamento tra un termine non più preferito (variante storica) e il nuovo termine preferito che lo sostituisce. La relazione reciproca é HSF
		 * HSF      Historical seen for (Ha come variante storica)    Legame di variante storica (legame non standard)    collegamento tra un termine preferito e una sua variante storica. La relazione reciproca é HSEE
		 * SNR      Scope Note Reference    Legame di citazione nella nota d'ambito (legame non standard)    collegamento tra un termine non preferito citato nella nota d'ambito di un termine preferito e il termine preferito stesso. La relazione reciproca è SNX
		 * SNX      Is referenced in Scope Note    Legame di citazione nella nota d'ambito (legame non standard)    collegamento tra un termine preferito e un termine non preferito citato nella sua nota d'ambito. La relazione reciproca è SNR
		 * TT       Top Term (Termine apicale)    Relazione gerarchica con il termine apicale    relazione tra un termine preferito e il termine apicale della sua gerarchia
		 */

		$links = BncfThesaurus::getLinkMap();

		$links['BT']['values'] = [];
		foreach ($this->getSkos()->broader as $b) {
			$attr = $b->attributes('http://www.w3.org/1999/02/22-rdf-syntax-ns#');
			$links['BT']['values'][] = (string)$attr['resource'];
		}

		// FIXME
		$links['NT']['values'] = [];
		foreach ($this->getSkos()->narrower as $b) {
			$attr = $b->attributes('http://www.w3.org/1999/02/22-rdf-syntax-ns#');
			$links['NT']['values'][] = (string)$attr['resource'];
		}

		// FIXME
		// per le etichette di nodo
		foreach ($this->getSkos()->member as $b) {
			$attr = $b->attributes('http://www.w3.org/1999/02/22-rdf-syntax-ns#');
			$links['NT']['values'][] = (string)$attr['resource'];
		}

		$links['RT']['values'] = [];
		foreach ($this->getSkos()->related as $b) {
			$attr = $b->attributes('http://www.w3.org/1999/02/22-rdf-syntax-ns#');
			$links['RT']['values'][] = (string)$attr['resource'];
		}

		$links['UF']['values'] = [];
		foreach ($this->getSkosXL()->altLabel as $b) {
			$attr = $b->attributes('http://www.w3.org/1999/02/22-rdf-syntax-ns#');
			$links['UF']['values'][] = (string)$attr['resource'];
		}

		$links['UF+']['values'] = [];
		foreach ($this->getIsoThes()->splitAltlabel as $b) {
			$attr = $b->attributes('http://www.w3.org/1999/02/22-rdf-syntax-ns#');
			$links['UF+']['values'][] = (string)$attr['resource'];
		}

		$links['USE+']['values'] = [];
		foreach ($this->getIsoThes()->plusUseTerm as $b) {
			$attr = $b->attributes('http://www.w3.org/1999/02/22-rdf-syntax-ns#');
			$links['USE+']['values'][] = (string)$attr['resource'];
		}

		$links['CM']['values'] = [];
		foreach ($this->getSkos()->closeMatch as $b) {
			$attr = $b->attributes('http://www.w3.org/1999/02/22-rdf-syntax-ns#');
			$links['CM']['values'][] = (string)$attr['resource'];
		}
		$this->links = $links;
	}

	/**
	 *
	 */
	private function initRecType(): string
	{
		switch ((string)$this->xml->type['resource']) {
			case 'http://www.w3.org/2004/02/skos/core#Collection':
				$this->recType = AuthorityPeer::RECTYPE_NODE;
				break;
			case 'http://purl.org/iso25964/skos-thes#SimpleNonPreferredTerm':
				$this->recType = AuthorityPeer::RECTYPE_VARIANT;
				break;
			case 'http://purl.org/iso25964/skos-thes#SplitNonPreferredTerm':
				$this->recType = AuthorityPeer::RECTYPE_VARIANT;
				break;
			case 'http://purl.org/bncf/tid/Thes':
				$this->recType = AuthorityPeer::RECTYPE_TOPTERM;
				break;
			default:
				$this->recType = AuthorityPeer::RECTYPE_ACCEPTED;
				break;
		}

		if (count($this->getSkos()->topConceptOf) > 0) {
			$this->recType = AuthorityPeer::RECTYPE_TOPTERM;
		}

		return $this->recType;
	}

	/**
	 *
	 */

	private function initNotes(): void
	{
		$notes = [];
		foreach ($this->getSkos()->definition as $note) {
			$notes[] = array(
				'NoteNumber' => '320',
				'NoteValue' => (string)$note);
		}

		foreach ($this->getSkos()->scopeNote as $note) {
			$notes[] = array(
				'NoteNumber' => '330',
				'NoteValue' => (string)$note);
		}

		foreach ($this->getSkos()->historyNote as $note) {
			$notes[] = array(
				'NoteNumber' => '320',
				'NoteValue' => (string)$note);
		}

		foreach ($this->getSkos()->editorialNote as $note) {
			/*			$note = preg_replace('/<.*?>/', '', $note);*/
			$notes[] = array(
				'NoteNumber' => '300',
				'NoteValue' => (string)$note);
		}

		foreach ($this->getSkos()->example as $note) {
			$notes[] = array(
				'NoteNumber' => '320',
				'NoteValue' => (string)$note);
		}

		foreach ($this->getSkos()->notation as $note) {
			$notes[] = array(
				'NoteNumber' => '300',
				'NoteValue' => 'DDC (WebDewey): ' . $note);
		}


		$this->notes = $notes;
	}

	/**
	 * @return string
	 */
	private function initTermName(): string
	{
		$this->termName = trim((string)$this->getSkos()->prefLabel);
		$literalForm = trim((string)$this->getSkosXL()->literalForm);

		if (empty($this->termName)) {
			$this->termName = $literalForm;
		}

		if (empty($this->termName)) {
			$this->termName = trim((string)$this->getRDFs()->label);
		}

		if (empty($this->termName)) {
			throw new RuntimeException("Empty term name for {$this->name}: " . print_r($this->xml, true));
		}

		if ($this->recType === AuthorityPeer::RECTYPE_NODE) {
			$this->termName = preg_replace('/^\[|\]$/', '', $this->termName);
			$this->termName = "[{$this->termName}]";
		}

		return $this->termName;
	}

	/**
	 * @param $name
	 */
	private function initType($name): void
	{
		$type = str_replace(array('.xml', 'NS-SKOS-', '-'), array('', '', ' '), $name);
		if (strpos($type, 'Azioni Attivit') === 0) {
			$type = 'Azioni Attività';
		}

		$this->type = $type;
	}
}

class BncfThesaurus
{
	public const BNCF_BID_SOURCE = 'BNCF_THES';
	private $_skosZip;
	private $_termDB;
	private $_collectionMap;
	private $_processedBids = array();

	/**
	 * @return array
	 */
	public function getProcessedBids()
	{
		return $this->_processedBids;
	}

	/**
	 * BncfThesaurus constructor.
	 * @param $skosZipPath
	 */
	public function __construct($skosZipPath)
	{
		$this->_collectionMap = [];
		$this->_termDB = [];

		$tmpDir = realpath(Prado::getPathOfNamespace('Storage')) . '/temp/';
		if (!is_dir($tmpDir) && !mkdir($tmpDir, '0777', true) && !is_dir($tmpDir)) {
			throw new \RuntimeException(sprintf('Directory "%s" was not created', $tmpDir));
		}

		$this->_skosZip = tempnam($tmpDir, 'bncf');
		copy($skosZipPath, $this->_skosZip);
	}

	/**
	 * @param $skosZipPath
	 * @return \BncfThesaurus
	 */
	public static function create($skosZipPath): \BncfThesaurus
	{
		return new self($skosZipPath);
	}

	/**
	 * @return array
	 */
	public static function getLinkMap(): array
	{
		return [
			'NT' => ['id' => 32, 'swap' => false],     //32
			'BT' => ['id' => 23, 'swap' => false],     //23

			'RT' => ['id' => 11, 'swap' => false],     //11

			'UF' => ['id' => 54, 'swap' => false],     //54
			'USE' => ['id' => 45, 'swap' => false],    //45

			'UF+' => ['id' => 67, 'swap' => true],    //67
			'USE+' => ['id' => 76, 'swap' => true],   //76

			'HSF' => ['id' => 54, 'swap' => false],
			'HSEE' => ['id' => 45, 'swap' => false],    //11

//            'CM' => ['id' => 54, 'values' => []],
//            'HSF' => ['id' => 54, 'values' => []],
//            'SNR' => ['id' => 54, 'values' => []],
//            'SNX' => ['id' => 54, 'values' => []],
//            'XHNX' => ['id' => 23, 'values' => []],    //23
//            'XHNR' => ['id' => 32, 'values' => []]     //32
		];
	}

	/**
	 * @param $key
	 * @param $id
	 * @param $swap
	 */
	public static function getLinkMapID($key, &$id, &$swap)
	{
		$linkMap = self::getLinkMap();
		$id = $linkMap[$key]['id'];
		$swap = $linkMap[$key]['swap'];
	}

	/**
	 * @param $key
	 * @param $id
	 * @param $swap
	 */
	public static function getRelatedLinkMapID($key, &$id, &$swap): void
	{
		$reverse = function ($num) {
			$revnum = 0;

			while ($num !== 0) {
				$revnum = $revnum * 10 + $num % 10;
				$num = (int)($num / 10);
			}
			return $revnum;
		};

		$linkMap = self::getLinkMap();
		$id = $linkMap[$key]['id'];
		$r = $reverse($id);
		foreach ($linkMap as $item) {
			if ($item['id'] === $r) {
				$id = $item['id'];
				$swap = $item['swap'];
			}
		}
	}

	/**
	 * @return array
	 */
	public static function getTypeMap(): array
	{
		return array(
			'AGENTI ORGANISMI' => 'J',
			'AGENTI ORGANIZZAZIONI' => 'Q',
			'AGENTI PERSONE E GRUPPI' => 'R',
			'AGENTI PERSONE GRUPPI' => 'R',
			'AZIONI ATTIVITA' => 'U',
			'AZIONI DISCIPLINE' => 'V',
			'AZIONI PROCESSI' => 'Z',
			'COSE FORME' => 'B',
			'COSE MATERIA' => 'X',
			'COSE OGGETTI' => 'Y',
			'COSE SPAZIO' => 'I',
			'COSE STRUMENTI' => 'W',
			'COSE STRUTTURE' => 'K',
			'TEMPO' => 'N',
			'TERMINE NON CONTROLLATO' => 'A',
			'CLASSE' => 'C',
			'SERIE' => 'D',
			'ENTE' => 'E',
			'FAMIGLIA' => 'F',
			'NOME GEOGRAFICO/LUOGO' => 'G',
			'MARCA TIPOGRAFICA' => 'H',
			'LUOGO DI EDIZIONE' => 'L',
			'MARCA COMMERCIALE' => 'M',
			'OPERA' => 'O',
			'PERSONA' => 'P',
			'SOGGETTO' => 'S',
			'INDICAZIONE CRONOLOGICA' => 'T',
		);
	}

	/**
	 * @param \BncfThesaurusElement $element
	 */
	public function addToTermDB(BncfThesaurusElement $element): void
	{
		$id = $element->getFullId();
		$this->_termDB[$id] = $element;
	}

	/**
	 * @param \Authority $a
	 * @throws \PropelException
	 */
	public function purgeAuthorityPeer(Authority $a): void
	{
		$query = 'DELETE FROM ' . LAuthorityPeer::TABLE_NAME . ' WHERE ' .
			'((' . LAuthorityPeer::AUTHORITY_ID_DOWN . ' = ? AND ' .
			LAuthorityPeer::AUTHORITY_ID_UP . ' IN ' .
			'(SELECT ' . AuthorityPeer::AUTHORITY_ID . ' FROM ' . AuthorityPeer::TABLE_NAME .
			' WHERE ' . AuthorityPeer::AUTHORITY_STATUS . ' = \'' . AuthorityPeer::INTERNALSTATUS_THESAURUS . '\'' .
			' AND ' . AuthorityPeer::BID_SOURCE . ' = \'' . self::BNCF_BID_SOURCE . '\')) OR ' .

			'(' . LAuthorityPeer::AUTHORITY_ID_UP . ' = ? AND ' . LAuthorityPeer::AUTHORITY_ID_DOWN . ' IN ' .
			'(SELECT ' . AuthorityPeer::AUTHORITY_ID . ' FROM ' . AuthorityPeer::TABLE_NAME .
			' WHERE ' . AuthorityPeer::AUTHORITY_STATUS . ' = \'' . AuthorityPeer::INTERNALSTATUS_THESAURUS . '\'' .
			' AND ' . AuthorityPeer::BID_SOURCE . ' = \'' . self::BNCF_BID_SOURCE . '\'))) ' .

			'AND \'' . self::BNCF_BID_SOURCE . '\' = (SELECT ' . AuthorityPeer::BID_SOURCE . ' FROM ' . AuthorityPeer::TABLE_NAME . ' WHERE ' . AuthorityPeer::AUTHORITY_ID . '= ? )';

		$stmt = Propel::getConnection()->prepare($query);
		$stmt->execute(array($a->getAuthorityId(), $a->getAuthorityId(), $a->getAuthorityId()));
		$count = $stmt->rowCount();
		echo(PHP_EOL . "Deleted {$count} linked items from authority " . $a->getSortText() . PHP_EOL);
	}

	/**
	 * @throws \PropelException
	 */
	public function parse(): \BncfThesaurus
	{
		$this->buildTermDB();

		$i = 0;
		$total = \count($this->_termDB) * 3;

		foreach ($this->_termDB as $thesaurus_element) {
			$this->populateCollectionMap($thesaurus_element, ++$i, $total);
		}

		foreach ($this->_termDB as $thesaurus_element) {
			$this->parseTerm($thesaurus_element, ++$i, $total);
		}

		foreach ($this->_termDB as $thesaurus_element) {
			$this->parseLinks($thesaurus_element, ++$i, $total);
		}

		return $this;
	}

	/**
	 * @param $term
	 * @return \BncfThesaurusElement|bool
	 */
	public function hasBid($term)
	{

		if (array_key_exists($term, $this->_termDB)) {
			return $this->_termDB[$term];
		}
		return false;
	}

	/**
	 *
	 */
	private function buildTermDB(): void
	{
		$zip = zip_open($this->_skosZip);
		if (!is_resource($zip)) {
			die("Zip open fail: {$zip}");
		}

		while ($entry = zip_read($zip)) {
			$name = zip_entry_name($entry);

			if (substr($name, 0, 7) !== 'NS-SKOS') {
				continue;
			}

			zip_entry_open($zip, $entry, 'r');
			$entry_content = zip_entry_read($entry, zip_entry_filesize($entry));
			$xml = @simplexml_load_string($entry_content, 'SimpleXMLElement', 0, 'http://www.w3.org/1999/02/22-rdf-syntax-ns#');

			/** @var \SimpleXMLElement $element */
			foreach ($xml as $element) {
				$bncfEl = BncfThesaurusElement::create($element, $name)->addToTermDB($this);
				print "Loading {$bncfEl->getType()} - {$bncfEl->getFullId()}...\n";
			}
			zip_entry_close($entry);
		}
		zip_close($zip);
	}

	/**
	 * @param      $idDown
	 * @param      $idUp
	 * @param      $link_type_id
	 * @param null $sequence
	 * @return \LAuthority
	 * @throws \PropelException
	 */

	private function newAuthorityLink($idDown, $idUp, $link_type_id, $sequence = null): \LAuthority
	{
		$link = new LAuthority();
		$link->setAuthorityIdDown($idDown);
		$link->setAuthorityIdUp($idUp);
		$link->setLinkType($link_type_id);
		if ($sequence !== null) {
			$link->setLinkSequence($sequence);
		}
		$link->save();

		return $link;
	}


	/**
	 * @param $a1_id
	 * @param $a2_id
	 * @param $ltype1
	 * @param $ltype2
	 * @return bool
	 * @throws \PropelException
	 */
	private function hasAuthorityLink($a1_id, $a2_id, $ltype1, $ltype2): bool
	{
		$link = $this->getAuthorityLink($a1_id, $a2_id, $ltype1, $ltype2);
		return ($link instanceof LAuthority);
	}

	/**
	 * @param $a1_id
	 * @param $a2_id
	 * @param $ltype1
	 * @param $ltype2
	 * @throws \PropelException
	 */
	private function deleteAuthorityLink($a1_id, $a2_id, $ltype1, $ltype2)
	{
		$link = $this->getAuthorityLink($a1_id, $a2_id, $ltype1, $ltype2);
		if ($link instanceof LAuthority) {
			LAuthorityQuery::create()->filterByPrimaryKey($link->getPrimaryKey())->delete();
		}
	}

	/**
	 * @param $a1_id
	 * @param $a2_id
	 * @param $ltype1
	 * @param $ltype2
	 * @return mixed
	 * @throws \PropelException
	 */
	private function getAuthorityLink($a1_id, $a2_id, $ltype1, $ltype2)
	{
		$query = LAuthorityQuery::create()
			->condition('classdown1', 'LAuthority.AuthorityIdDown = ?', $a1_id)
			->condition('classdown2', 'LAuthority.AuthorityIdUp = ?', $a2_id)
			->condition('linktype1', 'LAuthority.LinkType = ?', $ltype1)
			->combine(array('classdown1', 'classdown2', 'linktype1'), Criteria::LOGICAL_AND, 'classdown')
			->condition('classup1', 'LAuthority.AuthorityIdDown = ?', $a2_id)
			->condition('classup2', 'LAuthority.AuthorityIdUp = ?', $a1_id)
			->condition('linktype2', 'LAuthority.LinkType = ?', $ltype2)
			->combine(array('classup1', 'classup2', 'linktype2'), Criteria::LOGICAL_AND, 'classup')
			->combine(array('classdown', 'classup'), Criteria::LOGICAL_OR);

		$link = $query->findOne();
		return $link;
	}

	/**
	 * @param \BncfThesaurusElement $element
	 * @param                       $index
	 * @param                       $total
	 * @throws \PropelException
	 */

	private function parseTerm(BncfThesaurusElement $element, $index, $total): void
	{
		echo "[{$index}/{$total}] Processing \033[00;31m{$element->termName}\033[0m: ";

		echo 'Building Authority... ';
		$a = $element->buildAuthority($element->termName);

		$purl = $element->getFullId();
		$aid = $a->getAuthorityId();

		$this->_processedBids[] = $a->getBid();

		$el = $this->_termDB[$purl];
		$el->setAuthorityId($aid);

		$this->purgeAuthorityPeer(AuthorityQuery::create()->findPk($aid));

		echo "Purl {$purl} is linked to the authority \033[00;32m{$aid}\033[0m.\n";
		echo '-------------------------------------------------------------------------------' . PHP_EOL;
	}

	/**
	 * @param \BncfThesaurusElement $element
	 * @param                       $index
	 * @param                       $total
	 * @throws \PropelException
	 */
	private function parseLinks(BncfThesaurusElement $element, $index, $total): void
	{
		echo "[{$index}/{$total}] Building links for \e[00;31m{$element->termName}\e[0m:\n";

		$c = $this->getCollectionWithTerm($element->getShortId());

		if ($element->recType !== AuthorityPeer::RECTYPE_NODE) {
			foreach ($element->links as $lType => $lTerms) {
				/*
				 * Processo i link di tutti i nodi che non siano termini di snodo e topterm con questa eccezione che riguarda  i termini non preferiti.
				 *
				 * Gli UF+ dei record non preferiti *NON* hanno un campo resource ma solo una descrizione, vedi ad esempio: http://purl.org/bncf/tid/14963.
				 *
				 * Ora se il rispettivo termine USE+ e' un record normale il legame viene creato quando processo questo termine.
				 * Se invece lo USE+ relativo e' un TOPTERM questo legame non viene creato in virtu' del $element->recType !== AuthorityPeer::RECTYPE_TOPTERM  qui sotto e
				 *
				 * presente per evitare di legare tutti i narrower del TT cioe' tutti i nodi ad ogni livello sotto
				 * il TT al TT stesso, vedi http://thes.bncf.firenze.sbn.it/dati.php?id=553).
				 *
				 * Quindi per riuscire ad importare il legame USE+ che lega il termine corrente non preferito ad un top term, importo del relativo top term solo i legami UF+.
				 */
				if ($element->recType !== AuthorityPeer::RECTYPE_TOPTERM || ($element->recType === AuthorityPeer::RECTYPE_TOPTERM && $lType === 'UF+')) {
					if (array_key_exists('values', $lTerms)) {
						foreach ($lTerms['values'] as $purl) {

							/** @var \BncfThesaurusElement $related */
							if (array_key_exists($purl, $this->_termDB)) {
								$related = $this->_termDB[$purl];

								self::getLinkMapID($lType, $r1, $swap_1);
								self::getRelatedLinkMapID($lType, $r2, $swap_2);

								if ((int)$r1 > 0) {
									$a1_id = $element->getAuthorityId();
									$a2_id = $related->getAuthorityId();

									echo "\t\tFinding link with type \e[00;35m{$lType}\e[0m ({$r1}) between {$element->termName} ({$a1_id}) and \e[00;33m{$related->termName}\e[0m ({$a2_id})...";

									$hasLink = $this->hasAuthorityLink($a1_id, $a2_id, $r1, $r2);
									if (!$hasLink) {
										$this->newAuthorityLink($element->getAuthorityId(), $related->getAuthorityId(), $swap_1 ? $r2 : $r1);
										echo " not found. Creating a \e[00;32mnew\e[0m one.\n";
									} else {
										echo " found an \e[0034mexisting\e[0m one.\n";
									}
								}
							}
						}
					}
				}

				$this->linkClass($element);
				$this->buildCollectionBound($element, $c);
			}
		}
	}


	/**
	 * @param \BncfThesaurusElement $element
	 * @param                       $index
	 * @param                       $total
	 */
	private function populateCollectionMap(BncfThesaurusElement $element, $index, $total): void
	{
		echo "[{$index}/{$total}] Building collection map for \033[00;31m{$element->termName}\033[0m..." . PHP_EOL;

		if ($element->recType === AuthorityPeer::RECTYPE_NODE || $element->isTopTerm()) {

			$id = $element->getShortId();
			$level = \count($element->getSkos()->member);

			if (array_key_exists($id, $this->_collectionMap) === false) {
				foreach ($element->getSkos()->member as $b) {
					$attr = $b->attributes('http://www.w3.org/1999/02/22-rdf-syntax-ns#');
					$element_id = $element->buildShortId((string)$attr['resource']);

					$this->_collectionMap[$id]['level'] = $level;
					$this->_collectionMap[$id]['elements'][$element_id] = $b;
					$this->_collectionMap[$id]['purl'] = $element->getFullId();
				}
			}
		}
	}

	/**
	 * @param $termId
	 * @return mixed
	 */
	private function getCollectionWithTerm($termId)
	{
		$collections = [];
		foreach ($this->_collectionMap as $collection_id => $elements_array) {
			if (\array_key_exists($termId, $elements_array['elements'])) {
				$collections[$collection_id] = [
					'level' => $elements_array['level'],
					'elements' => $elements_array['elements'],
					'purl' => $elements_array['purl']
				];
			}
		}
		return $this->sortCollectionByLevel($collections);
	}

	/**
	 * @param $collections
	 * @return mixed
	 */
	private function sortCollectionByLevel($collections)
	{
		usort($collections, function ($a, $b) {
			return $a['level'] - $b['level'] > 0;
		});

		return $collections;
	}

	/**
	 * @param \BncfThesaurusElement $element
	 * @param array                 $sortedCollections
	 * @throws \PropelException
	 */
	private function buildCollectionBound(BncfThesaurusElement $element, array $sortedCollections)
	{
		if ($element->recType === AuthorityPeer::RECTYPE_ACCEPTED) {

			/* @var \BncfThesaurusElement $lower_element */
			$lower_element = $this->_termDB[$element->getFullId()];

			// find the top term among the $element param's BT links.
			$last_upper_element = null;
			if (array_key_exists('values', $lower_element->links['BT'])) {
				foreach ($lower_element->links['BT']['values'] as $term) {
					/* @var \BncfThesaurusElement $last_upper_element */
					$last_upper_element = $this->_termDB[$term];
					if ($last_upper_element->isTopTerm()) {
						break;
					}
				}
			}

			foreach ($sortedCollections as $index => $collection) {
				$purl = $collection['purl'];
				/** @var \BncfThesaurusElement $p */
				$upper_element = $this->_termDB[$purl];
				$this->makeBTLink($lower_element, $upper_element);
				$lower_element = $upper_element;
			}

			if ($last_upper_element) {
				// delete original BT link between the  term referenced by the $element parameter and his own BT.
				self::getLinkMapID('BT', $r1, $swap_1);
				self::getRelatedLinkMapID('BT', $r2, $swap_2);
				$this->deleteAuthorityLink($element->getAuthorityId(), $last_upper_element->getAuthorityId(), $r1, $r2);

				// make the bound between the more generic collection found (the last processed in the previous
				// for loop) and the original $element's broader term.
				$this->makeBTLink($lower_element, $last_upper_element);
			}
		}
	}

	/**
	 * @param $lower_element
	 * @param $upper_element
	 * @throws \PropelException
	 */
	private function makeBTLink($lower_element, $upper_element)
	{
		self::getLinkMapID('BT', $r1, $swap_1);
		self::getRelatedLinkMapID('BT', $r2, $swap_2);

		if ((int)$r1 > 0) {
			$hasLink = $this->hasAuthorityLink($lower_element->getAuthorityId(), $upper_element->getAuthorityId(), $r1, $r2);
			if (!$hasLink) {
				$this->newAuthorityLink($lower_element->getAuthorityId(), $upper_element->getAuthorityId(), $r1);
			}
		}
	}

	/**
	 * @param \BncfThesaurusElement $element
	 * @throws \PropelException
	 */
	private function linkClass(BncfThesaurusElement $element): void
	{
		// dewey number
		$s = (string)$element->notation;
		if (!empty($s)) {
			$tm = new TurboMarc('<d676></d676>');
			$tm->addSubField('a', $s);
			$class = AuthorityPeer::getLinkedAuthority(676, $tm);

			if (null !== $class) {
				$element_id = $element->getAuthorityId();
				$related_id = $class->getAuthorityId();

				$link = $this->hasAuthorityLink($element_id, $related_id, 'KL', 'KL');
				if (!$link) {
					$this->newAuthorityLink($element_id, $related_id, 'KL', 0);
				}
			}
		}
	}
}