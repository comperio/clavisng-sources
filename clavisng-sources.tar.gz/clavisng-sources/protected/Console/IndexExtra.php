<?php

/**
 * Batch index manifestations on extra collection.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Console
 * @since 2.5.0
 */
require_once('ClavisCommandLineAction.php');

/**
 * @package Console
 * @since 2.5.0
 */
class ClavisActionIndexExtra extends ClavisCommandLineAction
{
    const COLLECTION_NONE = NULL;
    const COLLECTION_MLOL = 'MLOL';
    
    protected $action = 'index_extra';
    protected $parameters = array( 'index_file', 'file_format=bmw|clavis|rmb|mlol' );
    protected $optional = array( 'clean=false' );
    protected $description = 'Index all manifestation in the given file in the "extra" collection of the Solr server. Use second parameter <file_format> to specify the source of the file (bmw: BookmarkWeb2, rmb: RMB). Third parameter clean before index, remember to set to true with mlol.';
    protected $collection = self::COLLECTION_NONE;
    protected $clean = FALSE;

    const SLICE_COUNT = 8912;

    private $_libcodes;
    
    public function printMsg( $msg )
    {
        echo $msg . PHP_EOL;
        Prado::log($msg);
    }

    /*
     * This is called like "/var/www/html/clavisng-2.8/clavis-cli aosta index_extra /root/MLOL/mlol.uni mlol true"
     * args[1] = /root/MLOL/mlol.uni (Source file, use "none" with mlol)
     * args[2] = mlol (collection id)
     * args[3] = true (clean before index)
     */
    public function performAction( $args )
    {
        $fp = FALSE;
        $search = NULL;
        $appId = 'app-name-unset';
        
        if( $args[ 2 ] == 'mlol' )
        {
            $this->collection = self::COLLECTION_MLOL;
        }
        
        $this->clean = (isset( $args[ 3 ] ) && in_array( $args[ 3 ], array( 'true', 'clean' ) ));
        
        try
        {
            /** @var SolrSearch $search */
            $search = Prado::getApplication()->getModule( 'search' );
            $appId = Prado::getApplication()->getID();
            
            if ( $this->collection = self::COLLECTION_MLOL )
            {
                $this->printMsg("Processing MLOL...");
                ini_set("default_socket_timeout", 600);

                $opts = array(
                    'http' => array("timeout"=>600.0)
                );


                $streamContext = stream_context_create($opts);
                $wsdl = new SoapClient(
                    "https://api.medialibrary.it/api.asmx?WSDL",
                    array( 
                        "trace"=>1, 
                        "connection_timeout" => 600,
                        'stream_context'    => $streamContext,
                        'cache_wsdl'=>WSDL_CACHE_NONE		  
                    )
                );

                //print_r($wsdl->__getFunctions());

                $apiKey   = ClavisParamPeer::getParam('MLOL_API_KEY', 0);
                $portalId = ClavisParamPeer::getParam('MLOL_PORTAL_ID', 0);

                if(trim($apiKey) == "" || intval($portalId) == 0 || trim($portalId) == "") {
                    $this->printMsg("\n#### NO MLOL APIKEY SKIP! ####\n");
                    return false;
                }

                $params = array(
                    "api_key" => $apiKey,
                    "portal_id" => $portalId,
                    "format" => "xmldc",
                    "full_export" => "true");

                $this->printMsg("Retrieving remote records...");
                $mediaResult = $wsdl->GetRecords($params);
                
                $mediaResp = simplexml_load_string($mediaResult->GetRecordsResult->any);
                
                $xml = new DOMDocument();
                $xml->loadXML($mediaResp->asXML());

                $xslfname = Prado::getApplication()->getBasePath()."/Lib/mlol2tmarc.xsl";
                if(!file_exists( $xslfname ))
                {
                    throw new Exception("Error ".$xslfname. " file not found.");
                }
                $xsl = new DOMDocument();
                $xsl->load($xslfname);

                $proc = new XSLTProcessor;
                $proc->registerPHPFunctions();
                $proc->importStyleSheet($xsl);

                $this->printMsg("Transform xml to turbomarc and put into /tmp/".$appId.".tmarc file");
                file_put_contents("/tmp/".$appId.".tmarc", $proc->transformToXML($xml));

                $cmd = "yaz-marcdump -i turbomarc -o marc /tmp/".$appId.".tmarc > /tmp/".$appId.".uni";
                $cmdExitStatus = 0;
                $this->printMsg("Exec {$cmd}");
                system($cmd, $cmdExitStatus);
                if($cmdExitStatus != 0)
                {
                    throw new Exception( "Error executing ".$cmd);
                }

                $this->printMsg("Processing /tmp/".$appId.".uni");
                $fp = @fopen( "/tmp/".$appId.".uni", 'r' );
            }
            else
            {
                $fp = @fopen( $args[ 1 ], 'r' );
            }

            if ( $fp === false )
            {
                throw new Exception( "FAILED TO OPEN INPUT FILE.");
            }
            

            foreach ( LibraryQuery::create()->find() as $library )
                $this->_libcodes[ $library->getLibraryCode() ] = $library;



            $data = $timings = array();
            $totalcount = 0;
            $mt = microtime( true );
            if ( $this->clean )
            {
                if($this->collection == self::COLLECTION_MLOL)
                {
                    $search->cleanIndexExtra('MLOL');
                }
                else
                {
                    $search->cleanIndexExtra();
                }
            }

            while ( !feof( $fp ) )
            {
                $tm = $this->getNextRecord( $fp, $args[ 2 ] );
                // only index records that have items.
                if ( !isset( $tm->d950 ) )
                    continue;
                try
                {
                    $bid = ( string ) $tm->c001;
                    $data[ $bid ] = $tm->asXML();
                }
                catch ( Exception $e )
                {
                    $this->printMsg( "\n".__METHOD__." Corrupted record [invalid XML chars], discarding...");
                    continue;
                }
                if ( count( $data ) >= self::SLICE_COUNT )
                {
                    if ( $args[ 2 ] != 'mlol' )
                        $search->indexExtra( $data, false );
                    else
                        $search->indexExtra( $data, false, false, 'MLOL' );

                    $totalcount += count( $data );
                    $this->printMsg( "\n{$totalcount} records indexed!");
                    $data = array();
                    $timings[] = microtime( true ) - $mt;
                    $mt = microtime( true );
                }
            }//eof

            if ( $args[ 2 ] != 'mlol' )
                $search->indexExtra( $data, false );
            else
                $search->indexExtra( $data, false, false, 'MLOL' );

            $totalcount += count( $data );
            $timings[] = microtime( true ) - $mt;
            $this->printMsg( "\n{$totalcount} records indexed" );
        }
        catch ( Exception $e )
        {
            $this->printMsg( "\n!!!! SOMETHING WENT WRONG, please check your logs.\n" .
                "Exception throwed is [{$e->getCode()}] {$e->getMessage()}.");
            exit();
        }
        fclose( $fp );

        // ALL DONE, OUTPUT STATISTICS
        $count = count( $timings );
        $total = array_sum( $timings );
        $avg = $total / $count;
        sort( $timings );
        $middleval = floor( ($count - 1) / 2 );
        if ( $count % 2 )
        {
            $median = $timings[ $middleval ];
        }
        else
        {
            $low = $timings[ $middleval ];
            $high = $timings[ $middleval + 1 ];
            $median = (($low + $high) / 2);
        }
        $this->printMsg( "\n\n" . __CLASS__ . " STATISTICS (actually processed):\n" .
        "Record count (slices of " . self::SLICE_COUNT . " elements): {$count}\nTotal time spent: {$total}\n" .
        "Average time for slice indexing: {$avg}\nMedian time: {$median}");
        $this->printMsg("\n#### ALL DONE!!! ####");
        return true;
    }

    private function getNextRecord( $handle, $format )
    {
        $record = stream_get_line( $handle, 999999, TurboMarc::UNIMARC_RECORDEND );
        $record = trim( str_replace( array( "\n", "\r" ), ' ', $record ) );
        if ( !$record )
            return false;
        $tm = TurboMarc::createRecord();
        unset( $tm->d899 );
        switch ( $format )
        {
            case 'bmw':
                try
                {
                    $tm->parseRecord( $record, true, false );
                    $tm = TurboMarcUtility::sanitize( $tm );
                }
                catch ( Exception $e )
                {
                    $this->printMsg( "\nCorrupted record [invalid ISO2709 record], discarding...");
                    return false;
                }
                $tm = $this->fixItemsBMW( $tm );
                break;
            case 'rmb':
                try
                {
                    $tm->parseRecord( $record, true, false );
                    $tm = TurboMarcUtility::sanitize( $tm );
                }
                catch ( Exception $e )
                {
                    $this->printMsg( "\nCorrupted record [invalid ISO2709 record], discarding...");
                    return false;
                }
                $tm = $this->fixItemsRMB( $tm );
                break;
            default:
                try
                {
                    $tm->parseRecord( $record, true, false );
                    $tm = TurboMarcUtility::sanitize( $tm );
                }
                catch ( Exception $e )
                {
                    $this->printMsg( "\n".__METHOD__." Corrupted record [invalid ISO2709 record], discarding...");
                    $this->printMsg( $e->getMessage());
                    $this->printMsg( $e->getTraceAsString());
                    $uid = uniqid();
                    $badFileName = "/tmp/{$uid}.uni";
                    file_put_contents($badFileName, $record);
                    $this->printMsg("Bad record dumped to {$badFileName}");
                    return false;
                }
                break;
        }
        return $tm;
    }

    private function fixItemsRMB( TurboMarc $tm )
    {
        $extratm = clone $tm;
        unset( $extratm->d950 );
        $extratm = TurboMarcUtility::sanitize( $extratm );

        foreach ( $tm->d950 as $src950 )
        {
            $bibCode = trim( substr( $src950->sd, 0, 2 ) );
            $section = trim( substr( $src950->sd, 2, 10 ) );
            $collocation = trim( substr( $src950->sd, 12, 24 ) );
            $specification = trim( substr( $src950->sd, 36, 12 ) );
            $inventory = trim( substr( $src950->se, 5, 9 ) );
            $code = 'RMB - ' . $bibCode;

            if ( array_key_exists( $code, $this->_libcodes ) && $this->_libcodes[ $code ]->isExternal() )
            {
                $serie = sprintf( "%03d0", $bibCode );
                $f950 = $extratm->addField( '950' );
                $f950->addSubField( 'a', $this->_libcodes[ $code ]->getLibraryId() );
                $f950->addSubField( 'b', $serie );
                $f950->addSubField( 'c', $inventory );
                $f950->addSubField( 'd', $section );
                $f950->addSubField( 'f', $collocation );
                $f950->addSubField( 'g', $specification );
                $f950->addSubField( 'j', ItemStatus::ITEMSTATUS_ONSHELF );
                $f950->addSubField( 'k', true );
                $f950->addSubField( 'l', preg_replace( '/\s\s+/', ' ', "$section $collocation $specification" ) );
                $f950->addSubField( 'n', $this->_libcodes[ $code ]->getLibraryId() );
                $f950->addSubField( 'o', $this->_libcodes[ $code ]->getLibraryId() );
                $f950->addSubField( 'p', ItemPeer::LOANCLASS_AVAILABLE );
                $f950->addSubField( 'r', ( string ) $src950->sr );
                $f950->addSubField( 't', ( string ) $src950->sb );
                $f950->addSubField( 'y', $this->_libcodes[ $code ]->getLabel() );
            }
        }
        return array_key_exists( 'd950', $extratm ) ? $extratm : null;
    }

    private function fixItemsBMW( TurboMarc $tm )
    {
        $extratm = clone $tm;
        unset( $extratm->d950 );

        foreach ( $tm->d950 as $src950 )
        {
            $bibCode = trim( substr( $src950->sa, 0, 7 ) );
            $inventory = trim( substr( $src950->sa, 7 ) );
            $collocation = $src950->se;
            switch ( $bibCode )
            {
                case 'SB':
                    $code = 'SB-' . substr( $collocation, 0, strpos( $collocation, ' ' ) );
                    break;
                default:
                    $code = $bibCode;
                    break;
            }

            if ( array_key_exists( $code, $this->_libcodes ) && $this->_libcodes[ $code ]->isExternal() )
            {
                $serie = sprintf( "%03d0", $bibCode );
                $f950 = $extratm->addField( '950' );
                $f950->addSubField( 'a', $this->_libcodes[ $code ]->getLibraryId() );
                $f950->addSubField( 'b', $serie );
                $f950->addSubField( 'c', $inventory );
                $f950->addSubField( 'f', $collocation );
                $f950->addSubField( 'j', ItemStatus::ITEMSTATUS_ONSHELF );
                $f950->addSubField( 'k', true );
                $f950->addSubField( 'l', $collocation );
                $f950->addSubField( 'n', $this->_libcodes[ $code ]->getLibraryId() );
                $f950->addSubField( 'o', $this->_libcodes[ $code ]->getLibraryId() );
                $f950->addSubField( 'p', ItemPeer::LOANCLASS_AVAILABLE );
                $f950->addSubField( 'r', ( string ) $src950->sr );
                $f950->addSubField( 't', ( string ) $src950->sb );
                $f950->addSubField( 'y', $this->_libcodes[ $code ]->getLabel() );
            }
        }
        return array_key_exists( 'd950', $extratm ) ? $extratm : null;
    }

}
