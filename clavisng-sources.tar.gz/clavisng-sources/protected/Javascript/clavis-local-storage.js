var Comperio = Comperio || {};

Comperio.ClavisLocalStorage = Comperio.ClavisLocalStorage || {};
Comperio.ClavisLocalStorage.storage = window.localStorage;
Comperio.ClavisLocalStorage.inMemoryStorage = {};
Comperio.ClavisLocalStorage.isSupported = undefined;

/**
 * Test if LocalStorage is available in the current environment.
 */
Comperio.ClavisLocalStorage.hasLocalStorage = function () {
	if (this.isSupported !== undefined) {
		return this.isSupported;
	}

	try {
		var testKey = "__ComperioClavisLoc4lst0raGeKey__";
		this.storage.setItem(testKey, testKey);
		this.storage.removeItem(testKey);
		this.isSupported = true;
		return true;
	} catch (e) {
		this.isSupported = false;
		return false;
	}
};

/**
 * Clear all the LocalStorageItems
 */
Comperio.ClavisLocalStorage.clear = function () {
	if (this.hasLocalStorage()) {
		this.storage.clear();
	} else {
		this.inMemoryStorage = {};
	}
};

/**
 * Get the item with the given key from the localstorage.
 */
Comperio.ClavisLocalStorage.getItem = function (name) {
	if (this.hasLocalStorage()) {
		return this.storage.getItem(name);
	}

	if (this.inMemoryStorage.hasOwnProperty(name)) {
		return this.inMemoryStorage[name];
	}
	return null;
};

/**
 * Set a key value pair into the localstorage bucket.
 */
Comperio.ClavisLocalStorage.setItem = function (name, value) {
	if (this.hasLocalStorage()) {
		this.storage.setItem(name, value);
	} else {
		this.inMemoryStorage[name] = value;
	}
};

/**
 * Delete the item with the given key from the localstorage.
 */
Comperio.ClavisLocalStorage.removeItem = function (name) {
	if (this.hasLocalStorage()) {
		this.storage.removeItem(name);
	} else {
		delete this.inMemoryStorage[name];
	}
};

/**
 * @param name
 * @param value
 * Push a value into an array bucket indexed by name.
 */
Comperio.ClavisLocalStorage.pushItem = function (name, value) {
	var item = this.getItem(name, value) || '[]';
	if (item) {
		var obj = JSON.parse(item);
		if (obj instanceof Array) {
			obj.push(value);
			this.setItem(name, JSON.stringify(obj));
		}
	}
};

/**
 * Get the localstorage items count number
 */
Comperio.ClavisLocalStorage.length = function () {
	if (this.hasLocalStorage()) {
		return this.storage.length;
	} else {
		return Object.keys(this.inMemoryStorage).length;
	}
};

