/**
* Opens an iframe.
* The Id of the iframe is fixed, and is "Popup".
* Parameter "page" is the url of the iframe page.
* "labelId" and "valueId" are the html (real) Id's
* of the "<input>" tags (or similar) where a string
* label and a value will be passed by a javascript
* return function.
*
*/
function openIframe(	page, 
						labelId, 
						valueId, 
						formId, 
						callbackFunction, 
						
						confirmMessage,
						label2Id, 
						value2Id, 
						param, 
						objectType )
{
	window.elementLabelId = labelId;
	window.elementValueId = valueId;
	window.elementLabel2Id = label2Id;
	window.elementValue2Id = value2Id;
	window.elementFormId = formId;
	window.callbackFunction = callbackFunction;

	if (confirmMessage != null)
		if (!confirm(confirmMessage))
			return false;

	iframeUrl = "index.php?page=" + page;

	if (param != null)
		iframeUrl += "&param=" + param;
		if (objectType != null)
			iframeUrl += "&objectType=" + objectType;

    $('PopupMask').style.display = 'inline';
    $('Popup').src= iframeUrl;
    $('Popup').style.display = 'inline';
	return false;
}

/**
 * Returns the "label" and "value" parameters to the
 * opener page.
 *
 */
function onReturn(label, value, updateFlag, labelbis, valuebis)
{
	if ((label != '') && (value != ''))
	{
		outputLabel = parent.document.getElementById(parent.window.elementLabelId);
		outputValue = parent.document.getElementById(parent.window.elementValueId);
		outputLabel.value = label;
		outputValue.value = value;
	}

	if ((labelbis != '') && (valuebis != ''))
	{
		outputLabel2 = parent.document.getElementById(parent.window.elementLabel2Id);
		outputValue2 = parent.document.getElementById(parent.window.elementValue2Id);
		if (outputLabel2 != null)
			outputLabel2.value = labelbis;
		if (outputValue2 != null)
			outputValue2.value = valuebis;
	}

	formId = parent.window.elementFormId;
	if (formId && updateFlag) {
		parent.document.getElementById(formId).submit();
	} else {
		callbackFunction = parent.window.callbackFunction;
		if ((callbackFunction != '' && callbackFunction != null) &&
			(eval('typeof ' + 'parent.' + callbackFunction + " == 'function'"))) {
			eval('parent.' + callbackFunction + '();');
		}
	}

	onClose();
}

/**
 * Opens an iframe for help.
 * The Id of the iframe is fixed, and is "HelpFrame".
 * Parameter "page" is the url of the iframe page.
 * "labelId" and "valueId" are the html (real) Id's
 * of the "<input>" tags (or similar) where a string
 * label and a value will be passed by a javascript
 * return function.
 *
 */
function openHelp(url)
{
	$('PopupMask').style.display = 'inline';
	$('HelpPopup').src = url;
	$('HelpPopupDiv').style.display = 'inline';
	return false;
}
function closeHelp()
{
	$('PopupMask').style.display = 'none';
	$('HelpPopup').src = '';
	$('HelpPopupDiv').style.display = 'none';
	return false;
}

function selecttab(element)
{
    var tabSelected = document.getElementById("loantabs").getElementsByClassName("selected");
    if(element.rel != tabSelected.rel)
    {
        var divToSelect = document.getElementById(element.rel);
        var divSelected = document.getElementById(tabSelected[0].rel);

        tabSelected[0].className = "";
        element.className = "selected";

        divToSelect.className = "innertabselected";
        divSelected.className = "innertab";
    }

}