//
//GESTIONE COOKIES
function Get_Cookie(name) {
    var start = document.cookie.indexOf(name + '=');
    var len = start + name.length + 1;
    //
    //
    if ((!start) && (name != document.cookie.substring(0,name.length)))
         return null;
    if (start == -1)
         return null;
     var end = document.cookie.indexOf(';',len);
     if (end == -1) end = document.cookie.length;

     return unescape(document.cookie.substring(len,end));
}

function Set_Cookie( name, value, expires, path, domain, secure ) {
// set time, it's in milliseconds
    var today = new Date();
    today.setTime( today.getTime() );

	/*
	if the expires variable is set, make the correct
	expires time, the current script below will set
	it for x number of days, to make it for hours,
	delete * 24, for minutes, delete * 60 * 24
	*/
	if ( expires )
	{
		expires = expires * 1000 * 60 * 60 * 24;
	}
	var expires_date = new Date( today.getTime() + (expires) );

	document.cookie = name + "=" +escape( value ) +
		( ( expires ) ? ";expires=" + expires_date.toGMTString() : "" ) +
		( ( path ) ? ";path=" + path : "" ) +
		( ( domain ) ? ";domain=" + domain : "" ) +
		( ( secure ) ? ";secure" : "" );
}


function Delete_Cookie(name,path,domain) {
  if (Get_Cookie(name))
    document.cookie =
      name + '=' +
      ( (path) ? ';path=' + path : '') +
      ( (domain) ? ';domain=' + domain : '') +
      ';expires=Thu, 01-Jan-1970 00:00:01 GMT';
}

//GESTIONE TOGGLING FIELDSET
function checkVisible(strID,img,imgurl) {
	var cookie = Get_Cookie("UI_" + strID);
	//
	if(cookie == "hide") {
		Element.hide(strID);
		//img.src="images/navigate_close.png";
		img.src=imgurl+"_close.png";
	} else if (cookie == "show") {
		Element.show(strID);
		//img.src="images/navigate_open.png";
		img.src=imgurl+"_open.png";
	}
}

function openClose(strID,img, imgurl) {
	var cookie = Get_Cookie("UI_" + strID);
	//
	if(cookie == null) {
		Set_Cookie("UI_" + strID,"hide",'', document.Path, '', '');
		//img.src="images/navigate_close.png";
		img.src=imgurl+"_close.png";
	}  else if (cookie == "hide") {
		Set_Cookie("UI_" + strID,"show",'', document.Path, '', '');
		//img.src="images/navigate_open.png";
		img.src=imgurl+"_open.png";
	} else if(cookie == "show") {
		Set_Cookie("UI_" + strID,"hide",'', document.Path, '', '');
		//img.src="images/navigate_close.png";
		img.src=imgurl+"_close.png";
	}
	Element.toggle(strID);
}

//GESTIONE TOGGLING MENU
function checkVisibleLeftMenu(ID_messages,ID_shortlinks,ID_menutitle,ID_menu,ID_maintitle,ID_main, ID_menucaption, ID_message, ID_footer, img, imgurl, imgcaption) {
 	var cookie = Get_Cookie("UI_" + ID_menu);
 	//
 	if (cookie == null ) {
 		Set_Cookie("UI_" + ID_menu,"show",'', document.Path, '', '');

		openLeftMenu(ID_messages,ID_shortlinks,ID_menutitle,ID_menu,ID_maintitle,ID_main, ID_menucaption, ID_message, ID_footer, img, imgurl, imgcaption);
 	} else if(cookie == "hide") {
 		closeLeftMenu(ID_messages,ID_shortlinks,ID_menutitle,ID_menu,ID_maintitle,ID_main, ID_menucaption, ID_message, ID_footer, img, imgurl, imgcaption);

  	} else if (cookie == "show") {
 		openLeftMenu(ID_messages,ID_shortlinks,ID_menutitle,ID_menu,ID_maintitle,ID_main, ID_menucaption, ID_message, ID_footer, img, imgurl, imgcaption);
  	}
}

function openCloseLeftMenu(ID_messages,ID_shortlinks,ID_menutitle,ID_menu,ID_maintitle,ID_main, ID_menucaption, ID_message, ID_footer, img, imgurl, imgcaption) {
	var cookie = Get_Cookie("UI_" + ID_menu);
	//
	//alert((document.getElementById(img)).src);
	if(cookie == null) {
	    //alert("1");
 		Set_Cookie("UI_" + ID_menu,"show",'', document.Path, '', '');

		openLeftMenu(ID_messages,ID_shortlinks,ID_menutitle,ID_menu,ID_maintitle,ID_main, ID_menucaption, ID_message, ID_footer, img, imgurl, imgcaption);
 	}  else if (cookie == "hide") {
 		//alert("2");
 	    Set_Cookie("UI_" + ID_menu,"show",'', document.Path, '', '');

 		openLeftMenu(ID_messages,ID_shortlinks,ID_menutitle,ID_menu,ID_maintitle,ID_main, ID_menucaption, ID_message, ID_footer, img, imgurl, imgcaption);
 	} else if(cookie == "show") {
 	    //alert("3");
 		Set_Cookie("UI_" + ID_menu,"hide",'', document.Path, '', '');

 		closeLeftMenu(ID_messages,ID_shortlinks,ID_menutitle,ID_menu,ID_maintitle,ID_main, ID_menucaption, ID_message, ID_footer, img, imgurl, imgcaption);
 	}
}


function closeLeftMenu(ID_messages,ID_shortlinks,ID_menutitle,ID_menu,ID_maintitle,ID_main, ID_menucaption, ID_message, ID_footer, img, imgurl, imgcaption) {

	(document.getElementById(img)).src=imgurl+"_close.png";
	(document.getElementById(imgcaption)).style.display = "none";

	getStyleFromElem(ID_menu).width = "20px";
	getStyleFromElem(ID_menutitle).width= "20px";

	getStyleFromElem(ID_main).left = "35px";
	getStyleFromElem(ID_maintitle).left = "35px";

	getStyleFromElem(ID_shortlinks).width= "20px";
	getStyleFromElem(ID_messages).width= "20px";

	getStyleFromElem(ID_footer).left= "35px";

	//getStyleByClass('*','leftpanelcaption').display="none";

	for(var i = 0; i < 100; i++) {
	    var capt=ID_menucaption+i;
	 	var elem = document.getElementById(capt);
		 	if (elem)
		 		elem.style.display="none";
		 	else
		 		break;
	 }

	for(var i = 0; i < 100; i++) {
	    var capt=ID_message+i;
	 	var elem = document.getElementById(capt);
		 	if (elem)
		 		elem.style.display="none";
		 	else
		 		break;
	 }
}

function openLeftMenu(ID_messages,ID_shortlinks,ID_menutitle,ID_menu,ID_maintitle,ID_main, ID_menucaption, ID_message, ID_footer, img, imgurl, imgcaption) {

	(document.getElementById(img)).src=imgurl+"_open.png";
 	(document.getElementById(imgcaption)).style.display = "";

 	getStyleFromElem(ID_menu).width = "158px";
 	getStyleFromElem(ID_menutitle).width= "158px";

 	getStyleFromElem(ID_main).left = "175px";
 	getStyleFromElem(ID_maintitle).left = "175px";

 	getStyleFromElem(ID_shortlinks).width= "158px";
 	getStyleFromElem(ID_messages).width= "158px";

 	getStyleFromElem(ID_footer).left = "175px";

 	//getStyleByClass('*','leftpanelcaption').display="";


	for(var i = 0; i < 100; i++) {
	    var capt=ID_menucaption+i;
	    var elem = document.getElementById(capt);
	 	if (elem)
	 		elem.style.display="";
	 	else
	 		break;
 	}

	for(var i = 0; i < 100; i++) {
	    var capt=ID_message+i;
	    var elem = document.getElementById(capt);
	 	if (elem)
	 		elem.style.display="";
	 	else
	 		break;
 	}
}



function getStyleFromElem(elem){

        if (document.getElementById){
        	return document.getElementById(elem).style;
        } else if (document.all) {
            return document.all[elem].style;
        } else if (document.layers){
            return document.layers[elem];
        }
}