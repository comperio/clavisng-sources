<?php

/**
 * QueryBuilderToPropelDB class file
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 * For Commercial Licenses and support please contact Comperio.
 * @link      http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license   http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version   2.9
 */

class  QueryBuilderToPropelDB implements IQueryBuilderToDB
{

    private $baseQuery = null;

    /**
     * @return QueryBuilderToPropelDB
     */
    public static function create()
    {
        return new self();
    }

    /**
     * @param       $rules
     * @param array $transformationRules
     * @param null $baseQuery
     * @return Criteria
     */
    public function translate($rules, $transformationRules = [], $baseQuery = null, $joinRules = [])
    {
        $criteria = null;
        $this->baseQuery = $baseQuery;
        $qbrc = new QueryBuilderPropelRuleConverter($this, $transformationRules, $baseQuery);

        if (null !== $rules) {
            $criteria = $qbrc->convert($rules, $joinRules);
        }

        return $criteria;
    }

    /**
     * @param $operator
     * @param $field
     * @param $value
     * @return Criteria|Criterion
     */
    public function getOperatorsMap($field, $operator, $value, $type = ''): Criterion
    {
        $toDate = function ($value, $start = true) {
            $value = ($value instanceof DateTime) ? $value : DateTime::createFromFormat("d-m-Y", $value);
            $value = ($value instanceof DateTime) ? $value : DateTime::createFromFormat("Y/m/d", $value);
            if ($start) {
                $value = ($value instanceof DateTime) ? $value->setTime(0, 0, 0)->format('Y-m-d H:i:s') : '';
            } else {
                $value = ($value instanceof DateTime) ? $value->setTime(23, 59, 59)->format('Y-m-d H:i:s') : '';
            }
            return $value;
        };


        $criteria = $this->baseQuery;

        switch ($operator) {
            case 'equal':
                if ($type === 'date') {
                    $date_start = $toDate($value, true);
                    $date_end = $toDate($value, false);

                    $criterion1 = $criteria->getNewCriterion($field, $date_start, Criteria::GREATER_EQUAL);
                    $criterion2 = $criteria->getNewCriterion($field, $date_end, Criteria::LESS_EQUAL);
                    $criterion = $criterion1->addAnd($criterion2);
                } else {
                    $criterion = $criteria->getNewCriterion($field, $value, Criteria::EQUAL);
                }
                break;
            case 'not_equal':
                if ($type === 'date') {
                    $date_start = $toDate($value, true);
                    $date_end = $toDate($value, false);

                    $criterion1 = $criteria->getNewCriterion($field, $date_start, Criteria::LESS_THAN);
                    $criterion2 = $criteria->getNewCriterion($field, $date_end, Criteria::GREATER_THAN);
                    $criterion = $criterion1->addAnd($criterion2);
                } else {
                    $criterion = $criteria->getNewCriterion($field, $value, Criteria::NOT_EQUAL);
                }
                break;
            case 'in':
                $criterion = $criteria->getNewCriterion($field, $value, Criteria::IN);
                break;
            case 'not_in':
                $criterion = $criteria->getNewCriterion($field, $value, Criteria::NOT_IN);
                break;
            case 'less':
                $criterion = $criteria->getNewCriterion($field, $value, Criteria::LESS_THAN);
                break;
            case 'less_or_equal':
                if ($type === 'date') {
                    $date_end = $toDate($value, false);
                    $criterion = $criteria->getNewCriterion($field, $date_end, Criteria::LESS_EQUAL);
                } else {
                    $criterion = $criteria->getNewCriterion($field, $value, Criteria::LESS_EQUAL);
                }
                break;
            case 'greater':
                if ($type === 'date') {
                    $date_end = $toDate($value, false);
                    $criterion = $criteria->getNewCriterion($field, $date_end, Criteria::GREATER_THAN);
                } else {
                    $criterion = $criteria->getNewCriterion($field, $value, Criteria::GREATER_THAN);
                }
                break;
            case 'greater_or_equal':
                $criterion = $criteria->getNewCriterion($field, $value, Criteria::GREATER_EQUAL);
                break;
            case 'between':
                if ($type === 'date') {
                    $date_start = $toDate($value[0], true);
                    $date_end = $toDate($value[1], false);

                    $criterion1 = $criteria->getNewCriterion($field, $date_start, Criteria::GREATER_EQUAL);
                    $criterion2 = $criteria->getNewCriterion($field, $date_end, Criteria::LESS_EQUAL);
                    $criterion = $criterion1->addAnd($criterion2);
                } else {
                    $criterion1 = $criteria->getNewCriterion($field, $value[0], Criteria::GREATER_EQUAL);
                    $criterion2 = $criteria->getNewCriterion($field, $value[1], Criteria::LESS_EQUAL);
                    $criterion = $criterion1->addAnd($criterion2);
                }
                break;
            case 'not_between':
                if ($type === 'date') {
                    $date_start = $toDate($value[0], true);
                    $date_end = $toDate($value[1], false);

                    $criterion1 = $criteria->getNewCriterion($field, $date_start, Criteria::LESS_THAN);
                    $criterion2 = $criteria->getNewCriterion($field, $date_end, Criteria::GREATER_THAN);
                    $criterion = $criterion1->addAnd($criterion2);
                } else {
                    $criterion1 = $criteria->getNewCriterion($field, $value[0], Criteria::LESS_THAN);
                    $criterion2 = $criteria->getNewCriterion($field, $value[1], Criteria::GREATER_THAN);
                    $criterion = $criterion1->addAnd($criterion2);
                }
                break;
            case 'begins_with':
                $criterion = $criteria->getNewCriterion($field, "$value%", Criteria::LIKE);
                break;
            case 'not_begins_with':
                $criterion = $criteria->getNewCriterion($field, "$value%", Criteria::NOT_LIKE);
                break;
            case 'contains':
                $criterion = $criteria->getNewCriterion($field, "%$value%", Criteria::LIKE);
                break;
            case 'not_contains':
                $criterion = $criteria->getNewCriterion($field, "%$value%", Criteria::NOT_LIKE);
                break;
            case 'ends_with':
                $criterion = $criteria->getNewCriterion($field, "%$value", Criteria::LIKE);
                break;
            case 'not_ends_with':
                $criterion = $criteria->getNewCriterion($field, "%$value", Criteria::NOT_LIKE);
                break;
            case 'is_empty':
                $criterion = $criteria->getNewCriterion($field, '', Criteria::EQUAL);
                break;
            case 'is_not_empty':
                $criterion = $criteria->getNewCriterion($field, '', Criteria::NOT_EQUAL);
                break;
            case 'is_null':
                $criterion = $criteria->getNewCriterion($field, null, Criteria::ISNULL);
                break;
            case 'is_not_null':
                $criterion = $criteria->getNewCriterion($field, null, Criteria::ISNOTNULL);
                break;
            case 'not_null_and_not_empty':
                if ($type === 'date') {
                    $criterion = $criteria->getNewCriterion($field, null, Criteria::ISNOTNULL);
                    break;
                }
                $criterion1 = $criteria->getNewCriterion($field, null, Criteria::ISNOTNULL);
                $criterion2 = $criteria->getNewCriterion($field, '', Criteria::NOT_EQUAL);
                $criterion = $criterion1->addAnd($criterion2);
                break;
            case 'null_or_empty':
                if ($type === 'date') {
                    $criterion = $criteria->getNewCriterion($field, null, Criteria::ISNULL);
                    break;
                }
                $criterion1 = $criteria->getNewCriterion($field, null, Criteria::ISNULL);
                $criterion2 = $criteria->getNewCriterion($field, '', Criteria::EQUAL);
                $criterion = $criterion1->addOr($criterion2);
                break;
            case 'null_or_empty_or_zero':
                if ($type === 'date') {
                    $criterion = $criteria->getNewCriterion($field, null, Criteria::ISNULL);
                    break;
                }
                $criterion1 = $criteria->getNewCriterion($field, null, Criteria::ISNULL);
                $criterion2 = $criteria->getNewCriterion($field, '', Criteria::EQUAL);
                $criterion3 = $criteria->getNewCriterion($field, 0, Criteria::EQUAL);
                $criterion = $criterion1->addOr($criterion2)->addOr($criterion3);
                break;
            case 'all':
                $criterion = $criteria->getNewCriterion($field, $value, Criteria::NOT_EQUAL);
                break;
            default:
                throw new RuntimeException('operator not found in the conversion map.');
        }
        return $criterion;
    }

    /**
     * @param $value
     * @return mixed
     */
    public function escapeUserInput($value)
    {
        $reserved_words = [];
        $escaped_words = array_map(function ($item) {
            return '\\' . trim($item);
        }, $reserved_words);

        return str_replace($reserved_words, $escaped_words, $value);
    }
}
