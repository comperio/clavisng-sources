<?php

/**
 * ClavisOTP class file.
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 * For Commercial Licenses and support please contact Comperio.
 * @author    Mauro Seno <mauro.seno@comperio.it>
 * @link      http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2018 Comperio srl
 * @license   http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version   2.8.9
 */

/**
 * ClavisOTP Class
 * @author  Mauro Seno <mauro.seno@comperio.it>
 * @version 2.8.9
 * @since   2.8.9
 */
class ClavisOTP
{
	protected $_codeLength = 6;

	/**
	 * @param      $secret
	 * @param      $code
	 * @param int  $discrepancy
	 * @param null $currentTimeSlice
	 * @return bool
	 */
	public function verifyCode($secret, $code, $discrepancy = 1, $currentTimeSlice = null): bool
	{
		if ($currentTimeSlice === null) {
			$currentTimeSlice = floor(time() / 30);
		}
		if (strlen($code) != 6) {
			return false;
		}

		for ($i = -$discrepancy; $i <= $discrepancy; ++$i) {
			$calculatedCode = $this->getCode($secret, $currentTimeSlice + $i);
			if ($this->timingSafeEquals($calculatedCode, $code)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * @param $token
	 * @return string
	 */
	public function buildCurrentUserSecret($token): string
	{
		$user = Prado::getApplication()->getUser();
		$userId = $user->getID();
		$librarian = LibrarianPeer::retrieveByPK($userId);
		$secret = '';

		if ($librarian instanceof Librarian) {
			$librarian_secret = $librarian->getSecret();
			$otp_token = $token;
			$rnd = $this->combineSecrets($librarian_secret, $otp_token);

			$validChars = $this->_getBase32LookupTable();
			$secretLength = mb_strlen($rnd, 'utf8');

			for ($i = 0; $i < $secretLength; ++$i) {
				$secret .= $validChars[ord($rnd[$i]) & 31];
			}
		}
		return $secret;
	}

	/**
	 * @param $sha
	 * @param $otp
	 * @return bool|string
	 */
	private function combineSecrets($sha, $otp)
	{
		$secret = md5($sha . $otp);
		$secret = str_pad($secret, 16, 'A');

		return (strlen($secret) > 32) ? substr($secret, 0, 32) : $secret;
	}

	/**
	 * @param       $urlencoded_string
	 * @param array $params
	 * @return string
	 */
	public static function getQRCodeGoogleUrl($urlencoded_string, $params = array())
	{
		// https://developers.google.com/chart/infographics/docs/qr_codes
		$width = (!empty($params['width']) && (int)$params['width'] > 0)
			? (int)$params['width']
			: 200;

		$height = (!empty($params['height']) && (int)$params['height'] > 0)
			? (int)$params['height']
			: 200;

		$level = (!empty($params['level']) && in_array($params['level'], array('L', 'M', 'Q', 'H')))
			? $params['level']
			: 'M';

		$url = 'https://chart.googleapis.com/chart?chs=' . $width . 'x' . $height . '&chld=' . $level . '|0&cht=qr&chl=' . $urlencoded_string . '';
		return $url;
	}

	public static function getOTPQRCodeGoogleUrl($name, $secret, $title = null, $params = array())
	{
		$urlencoded = urlencode('otpauth://totp/' . $name . '?secret=' . $secret . '');
		if (isset($title)) {
			$urlencoded .= urlencode('&issuer=' . urlencode($title));
		}
		return self::getQRCodeGoogleUrl($urlencoded, $params);
	}

	/**
	 * @param      $secret
	 * @param null $timeSlice
	 * @return string
	 */
	private function getCode($secret, $timeSlice = null): string
	{
		if ($timeSlice === null) {
			$timeSlice = floor(time() / 30);
		}
		$secretkey = $this->_base32Decode($secret);
		// Pack time into binary string
		$time = chr(0) . chr(0) . chr(0) . chr(0) . pack('N*', $timeSlice);
		// Hash it with users secret key
		$hm = hash_hmac('SHA1', $time, $secretkey, true);
		// Use last nipple of result as index/offset
		$offset = ord(substr($hm, -1)) & 0x0F;
		// grab 4 bytes of the result
		$hashpart = substr($hm, $offset, 4);
		// Unpak binary value
		$value = unpack('N', $hashpart);
		$value = $value[1];
		// Only 32 bits
		$value &= 0x7FFFFFFF;
		$modulo = 10 ** $this->_codeLength;
		return str_pad($value % $modulo, $this->_codeLength, '0', STR_PAD_LEFT);
	}

	/**
	 * @param $safeString
	 * @param $userString
	 * @return bool
	 */
	private function timingSafeEquals($safeString, $userString): bool
	{
		if (function_exists('hash_equals')) {
			return hash_equals($safeString, $userString);
		}

		$safeLen = strlen($safeString);
		$userLen = strlen($userString);
		if ($userLen != $safeLen) {
			return false;
		}

		$result = 0;
		for ($i = 0; $i < $userLen; ++$i) {
			$result |= (ord($safeString[$i]) ^ ord($userString[$i]));
		}
		// They are only identical strings if $result is exactly 0...
		return $result === 0;
	}

	/**
	 * @param $secret
	 * @return bool|string
	 */
	private function _base32Decode($secret)
	{
		if (empty($secret)) {
			return '';
		}
		$base32chars = $this->_getBase32LookupTable();
		$base32charsFlipped = array_flip($base32chars);
		$paddingCharCount = substr_count($secret, $base32chars[32]);
		$allowedValues = array(6, 4, 3, 1, 0);
		if (!in_array($paddingCharCount, $allowedValues)) {
			return false;
		}
		for ($i = 0; $i < 4; ++$i) {
			if ($paddingCharCount == $allowedValues[$i] &&
				substr($secret, -($allowedValues[$i])) != str_repeat($base32chars[32], $allowedValues[$i])) {
				return false;
			}
		}
		$secret = str_replace('=', '', $secret);
		$secret = str_split($secret);
		$num_secret = count($secret);
		$binaryString = '';
		for ($i = 0; $i < $num_secret; $i = $i + 8) {
			$x = '';
			if (!in_array($secret[$i], $base32chars)) {
				return false;
			}
			for ($j = 0; $j < 8; ++$j) {
				$x .= str_pad(base_convert(@$base32charsFlipped[@$secret[$i + $j]], 10, 2), 5, '0', STR_PAD_LEFT);
			}
			$eightBits = str_split($x, 8);
			$num_eightBits = count($eightBits);
			for ($z = 0; $z < $num_eightBits; ++$z) {
				$binaryString .= (($y = chr(base_convert($eightBits[$z], 2, 10))) || ord($y) == 48) ? $y : '';
			}
		}
		return $binaryString;
	}

	/**https://facebook.com
	 * @return array
	 */
	private function _getBase32LookupTable()
	{
		return array(
			'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', //  7
			'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', // 15
			'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', // 23
			'Y', 'Z', '2', '3', '4', '5', '6', '7', // 31
			'=',  // padding char
		);
	}
}