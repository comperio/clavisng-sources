<?php


/**
 * AdminerClavisLogin class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author    Mauro Seno <mauro.seno@comperio.it>
 * @link      http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2018 Comperio srl
 * @license   http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version   2.8.9
 */

/**
 * AdminerClavisLogin Class
 *
 * @author  Mauro Seno <mauro.seno@comperio.it>
 * @version 2.8.9
 * @since   2.8.9
 */
class AdminerClavisLogin
{
	/** @var \Librarian $user */
	private $user;
	private $servers;
	private $otp_secret;

	public function __construct($serverconf)
	{
		$otp = new ClavisOTP();
		$user = Prado::getApplication()->getUser();
		$userId = $user->getID();

		if ($userId === null) {
			header("HTTP/1.0 404 Not Found");
			die();
		}

		$this->user = LibrarianPeer::retrieveByPK($userId);
		if (is_array($serverconf))
			$this->servers = $serverconf;
		else
			$this->servers = [];

		$propel_conf = Propel::getConfiguration();
		$otp_token = $propel_conf['dbadmin']['otp_token'];
		$this->otp_secret = $otp->buildCurrentUserSecret($otp_token);

		$this->initPostConnectionParams();
	}

	public function loginForm()
	{
		?>
		</form>

		<table class="checkable">
			<thead>
			<tr class="">
				<th><?php echo lang('Database') ?></th>
				<th>OTP</th>
				<th></th>
			</tr>
			</thead>

			<?php foreach ($this->servers as $key => $config): ?>
				<form name="form" method="post" enctype="multipart/form-data">
					<tr>
						<td style="vertical-align:middle"> <?php echo $config['label'] ?></td>
						<td style="vertical-align:middle">
							<?php
							if (strlen($config['otp_token']) > 0) {
								echo '<input type=\'number\' name=\'auth[otp]\' size=\'6\' autocomplete=\'off\'>';
							}
							?>
						</td>
						<td>
							<input type="submit" name="<?php echo $key ?>" value="Accedi">
						</td>
					</tr>
				</form>
			<?php endforeach; ?>
		</table>
		<?php return true;
	}

	public function credentials()
	{
		foreach ($this->servers as $config_key => $conf) {
			if ($_SESSION["config"] === $config_key) {
				return array($conf['host'] . ':' . $conf['port'], $conf['username'], $conf['password']);
			}
		}
	}

	public function database()
	{
		foreach ($this->servers as $config_key => $conf) {
			if ($_SESSION["config"] === $config_key) {
				return $conf['database'];
			}
		}
	}

	public function databases()
	{
		foreach ($this->servers as $config_key => $conf) {
			if ($_SESSION["config"] === $config_key) {
				return array($conf['database']);
			}
		}
	}

	public function login($login, $password)
	{
		$result = false;
		$mode = substr($_SESSION["mode"], -4);

		if ($this->user && $this->user->isAdministrator()) {
			$otp = new ClavisOTP();
			$verify = $otp->verifyCode($this->otp_secret, $_SESSION["otp"], 1, $_SESSION['loggedin_time']);
			$result = (
				($mode === 'notp') ||
				($mode === 'yotp' && isset($_SESSION["otp"]) && $verify)
			);
		}

		return $result;
	}

	private function initPostConnectionParams()
	{
		foreach ($this->servers as $config_key => $conf) {
			if ($_POST && $_POST[$config_key]) {
				$_SESSION["otp"] = (string)$_POST["auth"]["otp"];
				$_SESSION["mode"] = strlen($conf['otp_token']) > 0 ? 'yotp' : 'notp';
				$_SESSION["config"] = $config_key;
				$_SESSION["loggedin_time"] = floor(time() / 30);

				$_POST["auth"]["driver"] = 'server';
				$_POST["auth"]["server"] = $conf['host'] . ':' . $conf['port'];
				$_POST["auth"]["username"] = $conf['username'];
				$_POST["auth"]["password"] = $conf['password'];
				$_POST["auth"]["db"] = $conf['database'];
			}
		}
	}
}