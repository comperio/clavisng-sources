<?php
/**
 * ClavisMessage class
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 * For Commercial Licenses and support please contact Comperio.
 * @author    Marco Brancalion <marco@comperio.it>
 * @author    Ciro Mattia Gonano
 * @link      http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license   http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version   2.7
 */

/**
 * ClavisMessage Class
 * @author  Marco Brancalion <marco@comperio.it>
 * @author  Ciro Mattia Gonano
 * @version 2.7
 * @package Libraries
 * @since   2.6
 */
class ClavisMessage
{
	const SHORTTEXT_CHARLIMIT = 12;
	const LONGTEXT_CHARLIMIT = 115;
	const MESSAGESQUEUELIMIT = 25;

	const STRIPTABS_STRING = "\x09";
	const ALLOWEDTAGS_STRING = '<br /><br><b></b><a></a>';

	const TRIM_TAILCHARS = "..";

	const WARNING = 'clavismsg_warning.png';
	const WARNING_COLOR = '#fb6927';

	const CONFIRM = 'clavismsg_confirm.png';
	const CONFIRM_COLOR = '#29B87E';

	const LOADING = 'clavismsg_refresh.png';
	const LOADING_COLOR = '#29B87E';

	const INFO = 'clavismsg_info.png';
	const INFO_COLOR = '#00529b';

	const ERROR = 'clavismsg_error.png';
	const ERROR_COLOR = '#CA2121';

	private static $_messages = array();

	public static function resetMessages()
	{
		self::setMessages(array());
	}

	public static function getColorMatrix()
	{
		return array(self::WARNING => self::WARNING_COLOR,
			self::CONFIRM => self::CONFIRM_COLOR,
			self::LOADING => self::LOADING_COLOR,
			self::INFO => self::INFO_COLOR,
			self::ERROR => self::ERROR_COLOR);
	}

	public static function setMessages($messages = array())
	{
		if (is_array($messages)) {
			$messages = array_slice($messages, 0, self::MESSAGESQUEUELIMIT, true);
			self::$_messages = $messages;

			Prado::getApplication()->getSession()->add('ClavisMessagesArray', $messages);
		}
	}

	public static function getMessages()
	{
		self::$_messages = Prado::getApplication()->getSession()->itemAt('ClavisMessagesArray');
		if (!is_array(self::$_messages))
			self::$_messages = array();

		return self::$_messages;
	}

	public static function cleanMessages($ids = array())
	{
		if (!is_array($ids)
			|| (count($ids) == 0)) {
			self::resetMessages();
			self::setIsMessageNew(false);

			return true;
		}

		// delete parameters where passed
		$allMessages = self::getMessages();
		$diffMessages = array_diff_key($allMessages, array_flip($ids));
		self::setMessages($diffMessages);
	}

	public static function setIsMessageNew($flag = false)
	{
		if (($flag !== true) && ($flag !== false))
			$flag = false;

		Prado::getApplication()->getSession()->add('IsMessageNew', $flag);
	}

	public static function getIsMessageNew()
	{
		$flag = Prado::getApplication()->getSession()->itemAt('IsMessageNew');
		if (($flag !== true)
			&& ($flag !== false))
			$flag = false;

		return $flag;
	}

	public static function writeMessage($text = '', $type = null)
	{
		$text = str_replace(self::STRIPTABS_STRING, "", $text); /// strip tabs
		$text = strip_tags($text, self::ALLOWEDTAGS_STRING);

		self::setIsMessageNew(true);
		self::push(array($text, $type));
	}

	private static function push($newMessage)
	{
		$text = trim($newMessage[0]);
		if (!is_string($text)
			|| ($text == '')) {
			$text = Prado::localize('Il messaggio da visualizzare non è valido !');
			$newMessage[1] = self::ERROR;
		}

		self::$_messages = self::getMessages();

		$newMessage = array(time() => array('body' => $text,
			'type' => $newMessage[1]));

		$newArray = $newMessage;

		foreach (self::$_messages as $ind => $mess)
			$newArray[$ind] = $mess;

		self::$_messages = $newArray;
		self::setMessages(self::$_messages);
	}

	public static function getMessagesDatasource($messagesNumber = 0)
	{
		$datasource = array();
		$mess = 0;

		$messagesDatasource = self::getMessages();

		if ($messagesNumber > 0)
			$messagesDatasource = array_slice($messagesDatasource, 0, $messagesNumber, true);

		foreach ($messagesDatasource as $time => $message) {
			if (array_key_exists('body', $message))
				$text = $message['body'];
			else
				$text = '------------';
			if (array_key_exists('type', $message))
				$type = $message['type'];
			else
				$type = self::ERROR;

			if (strlen($text) >= self::SHORTTEXT_CHARLIMIT)
				$trimmedText = substr($text, 0, self::SHORTTEXT_CHARLIMIT - 1) . self::TRIM_TAILCHARS;
			else
				$trimmedText = $text;

			if (is_null($type))
				$type = self::ERROR;

			$datasource[] = array('caption_id' => 'leftmessage' . $mess++,
				'shorttext' => $trimmedText,
				'longtext' => $text,
				'type' => $type,
				'time' => $time);
		}

		return $datasource;
	}

	public static function getLastMessage($trim = null)
	{
		if (is_null($trim)
			|| ($trim == 0))
			$trim = self::LONGTEXT_CHARLIMIT;

		$firstText = '';
		$firstIcon = '';

		$datasource = self::getMessagesDatasource();
		if (is_array($datasource)) {
			if (array_key_exists(0, $datasource)) {
				$first = $datasource[0];

				if (array_key_exists('longtext', $first))
					$firstText = str_replace(array('<br />', '<br>'), " ", $first['longtext']);

				/** deactivated for the html truncate problem
				 * if (strlen($firstText) >= $trim)
				 * $firstText = substr($firstText, 0, $trim - 1) . self::TRIM_TAILCHARS;
				 */

				if (array_key_exists('type', $first))
					$firstIcon = $first['type'];
			}
		}

		return array($firstText, $firstIcon);
	}

	public static function getTypeString($type = null)
	{
		switch ($type) {
			case self::WARNING:
				$return = 'avviso';
				break;
			case self::CONFIRM:
				$return = 'conferma';
				break;
			case self::LOADING:
				$return = 'caricamento';
				break;
			case self::INFO:
				$return = 'informazione';
				break;
			case self::ERROR:
				$return = 'errore';
				break;
			default:
				$return = '';
		}
		return $return;
	}
}
