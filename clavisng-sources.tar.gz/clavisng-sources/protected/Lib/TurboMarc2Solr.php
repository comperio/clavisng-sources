<?php
/**
 * TurboMarc2Solr class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Dario Rigolin <dario@comperio.it>
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Libraries
 */
require_once 'TurboMarc.php';

/**
 * Class BaseTMarc2Solr
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Libraries
 * @since 2.7.0
 */
class BaseTMarc2Solr
{
	static public $fieldSort = array();

	public static function ClearStates() {
		self::$fieldSort = array();
	}

	public static function fulltextGen($fld, $params) {
		$fstr = '';
		foreach ($fld as $sf)
			if (preg_match('/^'.$params['subfield'].'$/',$sf->getName())) {
				$fstr .= ' '.(string)$sf;
			}
		return array('field' => $params['field'], "value" => trim($fstr));
	}

	public static function normalizeNumber($fld, $params) {
		$ret = array();
		foreach ($fld as $sf)
			$ret[] = array('field' => $params['field'], 'value' => preg_replace("/\s+/","",strtr(trim((string) $sf),"-"," ")));
		return (count($ret) > 0) ? $ret : null;
	}

	public static function fieldMap($fld, $params) {
		$ret = array();
		if(isset($params['tolower']))
		{
			foreach ($fld as $sf)
				if (preg_match('/^' . $params['subfield'] . '$/', $sf->getName()))
					$ret[] = array('field' => $params['field'], 'value' => mb_strtolower(trim((string)$sf), 'utf-8') );

		}
		else if(isset($params['toupper']))
		{
			foreach ($fld as $sf)
				if (preg_match('/^' . $params['subfield'] . '$/', $sf->getName()))
					$ret[] = array('field' => $params['field'], 'value' => mb_strtoupper(trim((string)$sf), 'utf-8'));

		}
		else {
			foreach ($fld as $sf)
				if (preg_match('/^' . $params['subfield'] . '$/', $sf->getName()))
					$ret[] = array('field' => $params['field'], 'value' => trim((string)$sf));
		}

		return (count($ret) > 0) ? $ret : null;
	}

	public static function opacLibrary($fld, $params)
	{
		$ret     = array();
		$lcAvail = array_merge(ItemPeer::getLoanClassesAvailable(), ItemPeer::getLoanClassesLocallyAvailable());
		$isAvail = ItemStatus::getItemStatusManageable();

		if(!isset(self::$fieldSort[$params['field_vis']]))
			self::$fieldSort[$params['field_vis']] = array();

		if(!isset(self::$fieldSort[$params['field_circ']]))
			self::$fieldSort[$params['field_circ']] = array();

		if ((string)$fld->sk == "1" && !in_array((int)$fld->sa, self::$fieldSort[$params['field_vis']]) ) { // OpacVisible = 1
			self::$fieldSort[$params['field_vis']][] = (int)$fld->sa;
			$ret[] = array('field' => $params['field_vis'], 'value' => (int)$fld->sa); // Home Library
		}

		if ((string)$fld->s2 == ItemPeer::LOANSTATUS_AVAILABLE
				&& in_array((string)$fld->sj, $isAvail)
				&& in_array((string)$fld->sp, $lcAvail)
				&& !in_array((int)$fld->sn, self::$fieldSort[$params['field_circ']]))
		{
			self::$fieldSort[$params['field_circ']][] = (int)$fld->sn;
			$ret[] = array('field' => $params['field_circ'], 'value' => (int)$fld->sn); // Actual Library
		}

		return $ret ? : null;
	}

	public static function fieldSort($fld, $params) {
		if (isset(self::$fieldSort[$params['field']]))
			return null;
		$ret = array();
		foreach ($fld as $sf) {
			if (preg_match('/^'.$params['subfield'].'$/', $sf->getName())) {
				$pos = strpos((string) $sf, '*');
				$sortString = ($pos !== false) ?
					substr((string) $sf, $pos + 1) :
					(string) $sf;
				$ret[] = array('field' => $params['field'], 'value' => mb_strtoupper(trim($sortString), 'UTF-8'));
				self::$fieldSort[$params['field']] = true;
				break;
			}
		}
		return (count($ret) > 0) ? $ret : null;
	}

	public static function fieldSearcheableAttach($fld, $params) {
		$out = '';
		if (AttachmentPeer::TYPE_FULLTEXT == (string)$fld->sa
			&& file_exists(AttachmentPeer::getRealStoragePath().'/'.(string)$fld->sp)) {
			$filecontent = file_get_contents(AttachmentPeer::getRealStoragePath().'/'.(string)$fld->sp);
			$filecontent = Clavis::sanitizeForXML($filecontent);
			$out = array('field' => $params['field'], 'value' => $filecontent);
		}
		return $out;
	}
}

/**
 * TurboMarc2Solr Class
 *
 * @author Dario Rigolin <dario@comperio.it>
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Libraries
 * @since 2.5.0
 */
class TurboMarc2Solr extends BaseTMarc2Solr
{
	static public $ALIAS = array(
		'mrc_d035_sa' => 'fldin_str_bid',
		'mrc_d035_s9' => 'fldin_str_bid_source',
		'mrc_d950_sd' => 'fldis_str_section',
		'mrc_d950_sf' => 'fldis_str_collocation',
		'mrc_d951_sd' => 'fldis_str_section',
		'mrc_d951_sf' => 'fldis_str_collocation',
		'mrc_l_6' => 'facets_bibtype',
		'mrc_l_7' => 'facets_biblevel',
		'fldin_txt_subject' => 'facets_subject',
		'fldin_txt_keyword' => 'facets_keyword',
		'fldin_txt_author_main' => 'facets_author_main',
		'mrc_d676_sa' => 'facets_class',
		'mrc_d676_sc' => 'facets_class_desc',
		'mrc_d901_sa' => 'facets_biblevel_full',

		'fldin_str_date'	=> array('facets_date','sorti_date'),

		'fldin_str_date2'	=> 'facets_date2',
		'mrc_d901_sr' => 'sorts_updated',
		'mrc_d901_su' => 'sorts_created',
		'mrc_d901_sl' => 'sorts_loansince',


        'mrc_d901_si' => 'sorts_lastinvdate',
		'mrc_d901_st' => 'sorti_usage',
		'mrc_d909_sa' => 'sorti_requests',
		'mrc_d909_sc' => 'sorti_onloan',
		'mrc_d909_sb' => 'sorti_visibleitems',

        'mrc_d910_sa' => 'fldin_txt_author_main',
        'mrc_d911_sa' => 'fldin_txt_author',
        'mrc_d912_sa' => 'fldin_txt_author',
        'mrc_d913_sa' => 'fldin_txt_subject',
        'mrc_d914_sa' => 'fldin_txt_keyword',
        'mrc_d915_sa' => 'fldin_txt_class',

        'fldin_txt_publisher' => array("facets_publisher","facets_publisherall",'fldin_txt_publisherall','fldin_txt_printer','facets_printer'),

        'fldin_txt_publisherall' => array("facets_publisherall"),

        'fldin_txt_printer' => 'facets_printer',
        'fldin_txt_owner' => 'facets_owner',
	);

	static public $SUBFJOIN = 'd[67]\d\d|d95[01]';

	static public $PREPROCESS = array(
		'd700' => array(
			'method'=>'joinSubFields',
			array('sa' => ',', 'sb' => '-'),
			'sa'),
		'd7\d\d' => array('')
	);

    static public $CACHEDMAPS = array();

	static public $MAPS = array(
		array('d01[0127]' , array('normalizeNumber',array('field'=>'fldin_txt_numbers'))),
		array('d07[13]' , array('normalizeNumber',array('field'=>'fldin_txt_numbers'))),
		array('d020' , array('normalizeNumber',array('field'=>'fldin_txt_numbers'))),

		array('d[234567]\d\d' , array('fulltextGen',array('field'=>'fulltext','subfield'=>'s[a-z]'))),
        array('d91[0-9]' , array('fulltextGen',array('field'=>'fulltext','subfield'=>'sa'))),

		array('d7\d\d',  array('parseAuthorField',array('field'=>'fldin_txt_author',
			'sf'=>'s4','relcode_exclude'=>array('320','390','160','610','620','650','750')))),
		array('d7[012]\d',  array('parseAuthorField',array('field'=>'facets_author',
			'sf'=>'s4','relcode_exclude'=>array('320','390','160','610','620','650','750')))),
		array('d7[019][01]',  array('parseAuthorField',array('field'=>'fldin_txt_author_main',
			'sf'=>'s4','relcode_exclude'=>array('320','390','160','610','620','650','750')))),

		array('d7\d\d', array('parseAuthorField',array('field'=>'fldin_txt_owner',
			'sf'=>'s4','relcode_include'=>array('320','390')))),

		array('d7[012]\d', array('parseAuthorField',array('field'=>'fldin_txt_publisher',
			'sf'=>'s4','relcode_include'=>array('160','610','620','650','750') ) )),

		array('d101' , array('fieldMap',array('field'=>'facets_lang','subfield'=>'sa','tolower'=>true))),
		array('d102' , array('fieldMap',array('field'=>'facets_country','subfield'=>'sa','tolower'=>true))),
		array('d200', array('fieldMap',array('field'=>'fldin_txt_author','subfield'=>'s[fg]'))),

		array('d210', array('fieldMap',array('field'=>'fldin_txt_publisherall','subfield'=>'s[cg]'))),

		array('d6\d\d' , array('fieldMap',array('field'=>'fldin_str_subject','subfield'=>'s3'))),
		array('d7\d\d' , array('fieldMap',array('field'=>'fldin_str_authid','subfield'=>'s3'))),

        array('d7\d\d' , array('pivotField',array('field'=>'mrc_raut','vf'=>'s[a-z]','pf'=>'s4','sep'=>' '))),
        array('d6[0123456]\d' , array('pivotField',array('field'=>'mrc_rsub','vf'=>'s[a-z]','pf'=>'s2','sep'=>' '))),
        array('d6[78]\d' , array('pivotField',array('field'=>'mrc_rcla','vf'=>'s[ac]','pf'=>'s2','sep'=>' '))),

		array('d200|d327|d5\d\d|d423|d454|d461|d917' , array('fieldMap',array('field'=>'fldin_txt_title','subfield'=>'s[acdehit]'))),
		array('d6[78][069]' , array('fieldMap',array('field'=>'fldin_txt_class','subfield'=>'s[acv]'))),
		array('d6[1209]\d' , array('fieldMap',array('field'=>'fldin_txt_subject','subfield'=>'sa'))),
		array('d619' , array('fieldMap',array('field'=>'fldin_txt_keyword','subfield'=>'s[abcd]'))),
		array('d62[09]' , array('fieldMap',array('field'=>'facets_place','subfield'=>'s[abcd]'))),

		array('d3(?!27)', array('fieldMap',array('field'=>'fldin_txt_note','subfield'=>'sa'))),

		array('d100' , array('cdfExtract',array('field'=>'fldin_str_date','subfield'=>'sa','pos'=>9,'len'=>4,'type'=>'int', 'unique'=>true))),
		array('d100' , array('cdfExtract',array('field'=>'fldin_str_date2','subfield'=>'sa','pos'=>13,'len'=>4,'type'=>'int'))),
		array('d100' , array('cdfExtract',array('field'=>'fldin_txt_datetype','subfield'=>'sa','pos'=>8,'len'=>1,'type'=>'string'))),

        array('d105' , array('cdfExtract',array('field'=>'facets_litterature','subfield'=>'sa','pos'=>11,'len'=>1,'type'=>'string'))),

		array('d7[01]0' , array('fieldSort',array('field'=>'sorts_author','subfield'=>'sa'))),
		array('d200' , array('fieldSort',array('field'=>'sorts_title','subfield'=>'sa'))),
		array('d676' , array('fieldSort',array('field'=>'sorts_class','subfield'=>'sa'))),
		array('d950' , array('fieldSort',array('field'=>'sorts_collocation','subfield'=>'sf'))),
        array('d950' , array('fieldSort',array('field'=>'sorts_invnumber','subfield'=>'sc'))),
		array('d950' , array('opacLibrary',array('field_vis'=>'faceti_libvisi','field_circ'=>'faceti_libcirc'))),
		array('d955', array('fieldSearcheableAttach',array('field'=>'fldin_txt_fulltextattach'))),

	);

    public static function buildCacheMaps()
    {
        self::$CACHEDMAPS = array();

        for($i = 0; $i <= 999; $i++)
        {
            $fld = ($i < 10)?sprintf("c%03d",$i):sprintf("d%03d",$i);
            foreach(self::$MAPS as $map)
            {
                $pattern = $map[0];
                if (preg_match("/{$pattern}/", $fld))
                {
                    if(isset(self::$CACHEDMAPS[$fld])) {
                        self::$CACHEDMAPS[$fld][]=$map[1];
                    } else {
                        self::$CACHEDMAPS[$fld]=array($map[1]);
                    }
                }
            }
        }
    }

    public static function calcEditionKey($tm) {
        $titprop = str_replace("*","",(string)$tm->d200->sa);

        $auth = "";
        $key = "";
        if(isset($tm->d700)) {
            $auth = $tm->d700->getAuthorField();
        }
        elseif(isset($tm->d710)) {
            $auth = $tm->d710->getAuthorField();
        }
        elseif(isset($tm->d720)) {
            $auth = $tm->d720->getAuthorField();
        }

        $auth = trim(preg_replace("/<.+>/",'',$auth));

        if(strlen($titprop) > 3 &&  strlen($auth) > 3) {
            $titprop = trim(preg_replace('/\W+/u',' ',$titprop));
            $auth = trim(preg_replace('/\W+/u',' ',$auth));
            $key = "{$titprop}_{$auth}";
        }

        if($key == "") $key = "EDKEY" . (string)$tm->c001;
        return $key;
    }

    public static function pivotField($fld,$params) {
        $ret = null;
        if(isset($fld->{$params['pf']}))
        {
            $value = "";
            foreach($fld->children() as $c)
                if(preg_match("/^{$params['vf']}$/",$c->getName())) $value .= $params['sep'].(string)$c;

            $ret = array('field'=>$params['field'].trim((string)$fld->{$params['pf']}),'value'=>trim($value," {$params['sep']}"));
        }

        return $ret;
    }

	public static function parseAuthorField($fld, $params) {
		$ret = false;
		$sf = $params['sf'];
		if (isset($fld->$sf)) {
			$relCode = (string) $fld->{$params['sf']};
			if (isset($params['relcode_include']) && in_array($relCode, $params['relcode_include']))
				$ret = true;
			else if (isset($params['relcode_exclude']) && !in_array($relCode, $params['relcode_exclude']))
				$ret = true;
		} else {
			// if we're working with exclusion, include fields without relatorcode
			// if we're working with inclusion, don't
			$ret = isset($params['relcode_exclude']);
		}
		return $ret ? array('field' => $params['field'], 'value' => trim($fld->getAuthorField())) : null;
	}

	public static function cdfExtract($fld, $params) {
		$subf = $params['subfield'];
		if (isset($params['unique']) && isset(self::$fieldSort[$params['field']]))
			return null;
		if (isset($fld->$subf)) {
			$value = trim(substr((string) $fld->$subf, $params['pos'], $params['len']));
			if ($params['type'] == 'int')
				$value = intval($value);
			self::$fieldSort[$params['field']] = true;
			return array('field' => $params['field'], 'value' => $value);
		}
		return null;
	}

	public static function getSolrDoc($xmlString,$recordId=0,$database='',$collection='') {
		$xmlDoc = simplexml_load_string($xmlString,'TurboMarc');
		if ($xmlDoc === false)
			throw new Exception ("Failed to load XML for RECORDID:{$recordId}\n $xmlString\n");

		$out = array();
		$cdfString = '';
		self::ClearStates();

        if(count(self::$CACHEDMAPS) == 0) self::buildCacheMaps();

		foreach ($xmlDoc as $n) {
			$e = $n->getName();
			if (preg_match('/'.self::$SUBFJOIN.'/i', $e)) {
				$fval = '';
				foreach ($n as $s) {
					$e1 = $s->getName();
					$fval .= ' $'.$e1.' '.(string)$s;
				}
				$out[] = array('field'=>"sf_$e",'value'=>$fval);
			}

            if(isset(self::$CACHEDMAPS[$e])) {
                foreach(self::$CACHEDMAPS[$e] as $param)
                {
                    $ret = self::{$param[0]}($n,$param[1]);
                    if($ret != null)
                    {
                        if (isset($ret['field']))
                            $out[] = $ret;
                        else
                            $out = array_merge($out, $ret);
                    }
                }
            } else
                foreach(self::$MAPS as $map)
                {
                    $pattern = $map[0];
                    $param = $map[1];
                    if (preg_match("/{$pattern}/", $e))
                    {
                        $ret = self::{$param[0]}($n,$param[1]);
                        if($ret != null)
                        {
                            if (isset($ret['field']))
                                $out[] = $ret;
                            else
                                $out = array_merge($out, $ret);
                        }
                    }
                }

			if ($n->count() > 0) { // Field with subfields
				foreach ($n as $sf) {
					$sfname = $sf->getName();
					if ($e >= 'd100' && $e <= 'd199') {
						$cdfString .= self::processCDF($e, $sfname, (string)$sf);
					//} else if ('d950' == $e || 'd951' == $e) {
					//	$out[] = array('field' => "mrcs_{$e}_{$sfname}", 'value' => (string)$sf);
					} else {
						$out[] = array('field' => "mrc_{$e}_{$sfname}", 'value' => (string)$sf);
					}
				}
			} else {
				// leader
				if ($e == 'l') {
					$out[] = array('field' => 'mrc_l_5', 'value' => substr((string) $n, 5, 1));
					$out[] = array('field' => 'mrc_l_6', 'value' => substr((string) $n, 6, 1));
					$out[] = array('field' => 'mrc_l_7', 'value' => substr((string) $n, 7, 1));
					$out[] = array('field' => 'mrc_l_8', 'value' => substr((string) $n, 8, 1));
					$out[] = array('field' => 'mrc_l_9', 'value' => substr((string) $n, 9, 1));

					$out[] = array('field' => 'mrc_l_17', 'value' => substr((string) $n, 17, 1));
					$out[] = array('field' => 'mrc_l_18', 'value' => substr((string) $n, 18, 1));
					$out[] = array('field' => 'mrc_l_19', 'value' => substr((string) $n, 19, 1));
				} else {
					// c00X
					$out[] = array('field' => "mrc_{$e}", 'value' => (string) $n);
				}
			}
		}
		$out[] = array('field' => 'mrc_cdf', 'value' => $cdfString);
		$out[] = array('field' => 'id', 'value' => $database.':'.$collection.':'.$recordId);
		$out[] = array('field' => 'database', 'value' => $database);
		$out[] = array('field' => 'collection', 'value' => $collection);
		$out[] = array('field' => 'turbo_marc', 'value' => $xmlString);
        $out[] = array('field' => 'edition_key','value'=> self::calcEditionKey($xmlDoc));

		$buffer = "<doc>\n";
		foreach ($out as $fld) {
			if ($fld == null || trim($fld['field']) == "" || trim($fld['value']) == "" )
				continue;

			$buffer .= "<field name=\"{$fld['field']}\">";
			$buffer .= htmlspecialchars($fld['value'], ENT_QUOTES, 'UTF-8');
			$buffer .= "</field>\n";

			if (array_key_exists($fld['field'], self::$ALIAS)) {

                if(is_array(self::$ALIAS[$fld['field']]))
                {
                    foreach(self::$ALIAS[$fld['field']] as $alias)
                    {
                        $buffer .= "<field name=\"" . $alias . "\">";
                        $buffer .= htmlspecialchars($fld['value'], ENT_QUOTES, 'UTF-8');
                        $buffer .= "</field>\n";
                    }
                }
                else
                {
                    $buffer .= "<field name=\"" . self::$ALIAS[$fld['field']] . "\">";
                    $buffer .= htmlspecialchars($fld['value'], ENT_QUOTES, 'UTF-8');
                    $buffer .= "</field>\n";
                }

			}
		}
		$buffer .= "</doc>\n";
        //$buffer = preg_replace("/\\s\\s+/"," ",$buffer);
		return $buffer;
	}

	public static function processCDF($field, $tag, $data)
	{
		// hardcoded CDFs for performance reasons.
		$out = '';
		switch ($field.$tag) {

			case 'd100sa':
				$out .= ' d100_sa_0_' . substr($data, 0, 8).
					' d100_sa_8_' . substr($data, 8, 1).
					' d100_sa_9_' . substr($data, 9, 4).
					' d100_sa_13_' . substr($data, 13, 4).
					' d100_sa_17_' . substr($data, 17, 1).
					' d100_sa_17_' . substr($data, 18, 1).
					' d100_sa_17_' . substr($data, 19, 1).
					' d100_sa_20_' . substr($data, 20, 1).
					' d100_sa_21_' . substr($data, 21, 1).
					' d100_sa_22_' . substr($data, 22, 3).
					' d100_sa_25_' . substr($data, 25, 1).
					' d100_sa_26_' . substr($data, 26, 4).
					' d100_sa_30_' . substr($data, 30, 4).
					' d100_sa_34_' . substr($data, 34, 2);
				break;

			case 'd101s1':
				$out .= ' d101_s1_0_' . substr($data, 0, 3);
				break;

			case 'd101s2':
				$out .= ' d101_s2_0_' . substr($data, 0, 3);
				break;

			case 'd101s3':
				$out .= ' d101_s3_0_' . substr($data, 0, 3);
				break;

			case 'd101sa':
				$out .= ' d101_sa_0_' . substr($data, 0, 3);
				break;

			case 'd101sb':
				$out .= ' d101_sb_0_' . substr($data, 0, 3);
				break;

			case 'd101sc':
				$out .=  ' d101_sc_0_' . substr($data, 0, 3);
				break;

			case 'd101sd':
				$out .= ' d101_sd_0_' . substr($data, 0, 3);
				break;

			case 'd101se':
				$out .= ' d101_se_0_' . substr($data, 0, 3);
				break;

			case 'd101sf':
				$out .= ' d101_sf_0_' . substr($data, 0, 3);
				break;

			case 'd101sg':
				$out .= ' d101_sg_0_' . substr($data, 0, 3);
				break;

			case 'd101sh':
				$out .= ' d101_sh_0_' . substr($data, 0, 3);
				break;

			case 'd101si':
				$out .= ' d101_si_0_' . substr($data, 0, 3);
				break;

			case 'd101sj':
				$out .= ' d101_sj_0_' . substr($data, 0, 3);
				break;

			case 'd102sa':
				$out .= ' d102_sa_0_' . substr($data, 0, 2);
				break;

			case 'd105sa':
				// pos 0/3 are illustrations, merge into 0
				// pos 4/7 are contents, merge into 4
				$out .= ' d105_sa_0_' . substr($data, 0, 1).
					' d105_sa_0_' . substr($data, 1, 1).
					' d105_sa_0_' . substr($data, 2, 1).
					' d105_sa_0_' . substr($data, 3, 1).
					' d105_sa_4_' . substr($data, 4, 1).
					' d105_sa_4_' . substr($data, 5, 1).
					' d105_sa_4_' . substr($data, 6, 1).
					' d105_sa_4_' . substr($data, 7, 1).
					' d105_sa_8_' . substr($data, 8, 1).
					' d105_sa_9_' . substr($data, 9, 1).
					' d105_sa_10_' . substr($data, 10, 1).
					' d105_sa_11_' . substr($data, 11, 1).
					' d105_sa_12_' . substr($data, 12, 1);
				break;

			case 'd106sa':
				$out .= ' d106_sa_0_' . substr($data, 0, 1).
					' d106_sa_0_' . substr($data, 1, 1).
					' d106_sa_0_' . substr($data, 2, 1);
				break;

			case 'd109sa':
				$out .= ' d109_sa_0_' . substr($data, 0, 3).
					' d109_sa_0_' . substr($data, 3, 3).
					' d109_sa_0_' . substr($data, 6, 3).
					' d109_sa_9_' . substr($data, 9, 3).
					' d109_sa_9_' . substr($data, 12, 3).
					' d109_sa_9_' . substr($data, 15, 3).
					' d109_sa_18_' . trim(substr($data, 18, 2)).
					' d109_sa_20_' . trim(substr($data, 20, 2)).
					' d109_sa_22_' . substr($data, 22, 1).
                    ' d109_sa_23_' . substr($data, 23, 1).
                    ' d109_sa_24_' . trim(substr($data, 24, 2)).
                    ' d109_sa_26_' . substr($data, 26, 1).
                    ' d109_sa_27_' . trim(substr($data, 27, 3)).
                    ' d109_sa_30_' . trim(substr($data, 30, 2)).
                    ' d109_sa_32_' . trim(substr($data, 32, 3)).
                    ' d109_sa_35_' . substr($data, 35, 1).
                    ' d109_sa_36_' . trim(substr($data, 36, 3)).
                    ' d109_sa_36_' . trim(substr($data, 39, 3)).
                    ' d109_sa_36_' . trim(substr($data, 42, 3));
				break;

			case 'd110sa':
				$out .= ' d110_sa_0_' . substr($data, 0, 1).
					' d110_sa_1_' . substr($data, 1, 1).
					' d110_sa_2_' . substr($data, 2, 1).
					' d110_sa_3_' . substr($data, 3, 1).
					' d110_sa_4_' . substr($data, 4, 1).
					' d110_sa_5_' . substr($data, 5, 1).
					' d110_sa_6_' . substr($data, 6, 1).
					' d110_sa_7_' . substr($data, 7, 1).
					' d110_sa_8_' . substr($data, 8, 1).
					' d110_sa_9_' . substr($data, 9, 1).
					' d110_sa_10_' . substr($data, 10, 1);
				break;

			case 'd115sa':
				$out .= ' d115_sa_0_' . substr($data, 0, 1).
					' d115_sa_1_' . substr($data, 1, 3).
					' d115_sa_4_' . substr($data, 4, 1).
					' d115_sa_5_' . substr($data, 5, 1).
					' d115_sa_6_' . substr($data, 6, 1).
					' d115_sa_7_' . substr($data, 7, 1).
					' d115_sa_8_' . substr($data, 8, 1).
					' d115_sa_9_' . substr($data, 9, 1).
					' d115_sa_10_' . substr($data, 10, 1).
					' d115_sa_11_' . substr($data, 11, 1).
					' d115_sa_12_' . substr($data, 12, 1).
					' d115_sa_13_' . substr($data, 13, 1).
					' d115_sa_14_' . substr($data, 14, 1).
					' d115_sa_15_' . substr($data, 15, 1).
					' d115_sa_16_' . substr($data, 16, 1).
					' d115_sa_17_' . substr($data, 17, 1).
					' d115_sa_18_' . substr($data, 18, 1).
					' d115_sa_19_' . substr($data, 19, 1);
				break;

			case 'd115sb':
				$out .= ' d115_sb_0_' . substr($data, 0, 1).
					' d115_sb_1_' . substr($data, 1, 1).
					' d115_sb_4_' . substr($data, 4, 1).
					' d115_sb_5_' . substr($data, 5, 1).
					' d115_sb_6_' . substr($data, 6, 1).
					' d115_sb_7_' . substr($data, 7, 1).
					' d115_sb_8_' . substr($data, 8, 1).
					' d115_sb_9_' . substr($data, 9, 6);
				break;

			case 'd116sa':
				$out .= ' d116_sa_0_' . substr($data, 0, 1).
					' d116_sa_1_' . substr($data, 1, 1).
					' d116_sa_2_' . substr($data, 2, 1).
					' d116_sa_3_' . substr($data, 3, 1).
					' d116_sa_4_' . substr($data, 4, 2).
					' d116_sa_6_' . substr($data, 6, 2).
					' d116_sa_8_' . substr($data, 8, 2).
					' d116_sa_10_' . substr($data, 10, 2).
					' d116_sa_12_' . substr($data, 12, 2).
					' d116_sa_14_' . substr($data, 14, 2).
					' d116_sa_16_' . substr($data, 16, 2);
				break;

			case 'd117sa':
				$out .= ' d117_sa_0_' . substr($data, 0, 2).
					' d117_sa_2_' . substr($data, 2, 2).
					' d117_sa_4_' . substr($data, 4, 2).
					' d117_sa_6_' . substr($data, 6, 2).
					' d117_sa_8_' . substr($data, 8, 1);
				break;

			case 'd120sa':
				$out .= ' d120_sa_0_' . substr($data, 0, 1).
					' d120_sa_1_' . substr($data, 1, 1).
					' d120_sa_2_' . substr($data, 2, 1).
					' d120_sa_3_' . substr($data, 3, 1).
					' d120_sa_4_' . substr($data, 4, 1).
					' d120_sa_5_' . substr($data, 5, 1).
					' d120_sa_6_' . substr($data, 6, 1).
					' d120_sa_7_' . substr($data, 7, 2).
					' d120_sa_9_' . substr($data, 9, 2).
					' d120_sa_11_' . substr($data, 11, 2);
				break;

			case 'd121sa':
				$out .= ' d121_sa_0_' . substr($data, 0, 1).
					' d121_sa_1_' . substr($data, 1, 1).
					' d121_sa_2_' . substr($data, 2, 1).
					' d121_sa_3_' . substr($data, 3, 2).
					' d121_sa_5_' . substr($data, 5, 1).
					' d121_sa_6_' . substr($data, 6, 1).
					' d121_sa_7_' . substr($data, 7, 1).
					' d121_sa_8_' . substr($data, 8, 1);
				break;

			case 'd121sb':
				$out .= ' d121_sb_0_' . substr($data, 0, 1).
					' d121_sb_1_' . substr($data, 1, 1).
					' d121_sb_2_' . substr($data, 2, 2).
					' d121_sb_4_' . substr($data, 4, 1).
					' d121_sb_5_' . substr($data, 5, 1).
					' d121_sb_6_' . substr($data, 6, 1).
					' d121_sb_7_' . substr($data, 7, 1);
				break;

			case 'd122sa':
				$out .= ' d122_sa_0_' . substr($data, 0, 1).
					' d122_sa_1_' . substr($data, 1, 4).
					' d122_sa_5_' . substr($data, 5, 2).
					' d122_sa_7_' . substr($data, 7, 2).
					' d122_sa_9_' . substr($data, 9, 2);
				break;

			case 'd123sa':
				$out .= ' d123_sa_0_' . substr($data, 0, 1);
				break;

			case 'd123sd':
				$out .= ' d123_sd_0_' . substr($data, 0, 1).
					' d123_sd_1_' . substr($data, 1, 3).
					' d123_sd_4_' . substr($data, 4, 2).
					' d123_sd_6_' . substr($data, 6, 2);
				break;

			case 'd123se':
				$out .= ' d123_se_0_' . substr($data, 0, 1).
					' d123_se_1_' . substr($data, 1, 3).
					' d123_se_4_' . substr($data, 4, 2).
					' d123_se_6_' . substr($data, 6, 2);
				break;

			case 'd123sf':
				$out .= ' d123_sf_0_' . substr($data, 0, 1).
					' d123_sf_1_' . substr($data, 1, 3).
					' d123_sf_4_' . substr($data, 4, 2).
					' d123_sf_6_' . substr($data, 6, 2);
				break;

			case 'd123sg':
				$out .= ' d123_sg_0_' . substr($data, 0, 1).
					' d123_sg_1_' . substr($data, 1, 3).
					' d123_sg_4_' . substr($data, 4, 2).
					' d123_sg_6_' . substr($data, 6, 2);
				break;

			case 'd123sh':
				$out .= ' d123_sh_0_' . substr($data, 0, 4);
				break;

			case 'd123si':
				$out .= ' d123_si_0_' . substr($data, 0, 1).
					' d123_si_2_' . substr($data, 2, 2).
					' d123_si_4_' . substr($data, 4, 2);
				break;

			case 'd123sj':
				$out .= ' d123_sj_0_' . substr($data, 0, 1).
					' d123_sj_2_' . substr($data, 2, 2).
					' d123_sj_4_' . substr($data, 4, 2);
				break;

			case 'd123sk':
				$out .= ' d123_sk_0_' . substr($data, 0, 1).
					' d123_sk_2_' . substr($data, 2, 2).
					' d123_sk_4_' . substr($data, 4, 2);
				break;

			case 'd123sm':
				$out .= ' d123_sm_0_' . substr($data, 0, 1).
					' d123_sm_2_' . substr($data, 2, 2).
					' d123_sm_4_' . substr($data, 4, 2);
				break;

			case 'd123sn':
				$out .= ' d123_sn_0_' . substr($data, 0, 4);
				break;

			case 'd123so':
				$out .= ' d123_so_0_' . substr($data, 0, 4);
				break;

			case 'd123sp':
				$out .= ' d123_sp_0_' . substr($data, 0, 2).
					' d123_sp_2_' . substr($data, 2, 1);
				break;

			case 'd124sa':
				$out .= ' d124_sa_0_' . substr($data, 0, 1);
				break;

			case 'd124sb':
				$out .= ' d124_sb_0_' . substr($data, 0, 1);
				break;

			case 'd124sc':
				$out .= ' d124_sc_0_' . substr($data, 0, 2);
				break;

			case 'd124sd':
				$out .= ' d124_sd_0_' . substr($data, 0, 1);
				break;

			case 'd124se':
				$out .= ' d124_se_0_' . substr($data, 0, 1);
				break;

			case 'd124sf':
				$out .= ' d124_sf_0_' . substr($data, 0, 2);
				break;

			case 'd124sg':
				$out .= ' d124_sg_0_' . substr($data, 0, 2);
				break;

			case 'd125sa':
				$out .= ' d125_sa_0_' . substr($data, 0, 1).
					' d125_sa_1_' . substr($data, 1, 1);
				break;

			case 'd125sb':
				$out .= ' d125_sb_0_' . substr($data, 0, 1).
					' d125_sb_0_' . substr($data, 1, 1);
				break;

			case 'd125sc':
				$out .= ' d125_sc_0_' . substr($data, 0, 1).
					' d125_sc_1_' . substr($data, 1, 1).
					' d125_sc_2_' . substr($data, 2, 1);
				break;

			case 'd126sa':
				$out .= ' d126_sa_0_' . substr($data, 0, 1).
					' d126_sa_1_' . substr($data, 1, 1).
					' d126_sa_2_' . substr($data, 2, 1).
					' d126_sa_3_' . substr($data, 3, 1).
					' d126_sa_4_' . substr($data, 4, 1).
					' d126_sa_5_' . substr($data, 5, 1).
					' d126_sa_6_' . substr($data, 6, 1).
					' d126_sa_7_' . substr($data, 7, 1).
					' d126_sa_8_' . substr($data, 8, 1).
					' d126_sa_9_' . substr($data, 9, 1).
					' d126_sa_10_' . substr($data, 10, 1).
					' d126_sa_11_' . substr($data, 11, 1).
					' d126_sa_12_' . substr($data, 12, 1).
					' d126_sa_13_' . substr($data, 13, 1).
					' d126_sa_14_' . substr($data, 14, 1);
				break;

			case 'd126sb':
				$out .= ' d126_sb_0_' . substr($data, 0, 1).
					' d126_sb_1_' . substr($data, 1, 1).
					' d126_sb_2_' . substr($data, 2, 1);
				break;

			case 'd127sa':
				$out .= ' d127_sa_0_' . substr($data, 0, 2).
					' d127_sa_2_' . substr($data, 2, 2).
					' d127_sa_4_' . substr($data, 4, 2);
				break;

			case 'd128sa':
				$out .= ' d128_sa_0_' . substr($data, 0, 3);
				break;

			case 'd128sd':
				$out .= ' d128_sd_0_' . substr($data, 0, 3);
				break;

			case 'd130sa':
				$out .= ' d130_sa_0_' . substr($data, 0, 1).
					' d130_sa_1_' . substr($data, 1, 1).
					' d130_sa_2_' . substr($data, 2, 1).
					' d130_sa_3_' . substr($data, 3, 1).
					' d130_sa_4_' . substr($data, 4, 1).
					' d130_sa_7_' . substr($data, 7, 1).
					' d130_sa_8_' . substr($data, 8, 1).
					' d130_sa_9_' . substr($data, 9, 1).
					' d130_sa_10_' . substr($data, 10, 1);
				break;

			case 'd131sa':
				$out .= ' d131_sa_0_' . substr($data, 0, 2);
				break;

			case 'd131sb':
				$out .= ' d131_sb_0_' . substr($data, 0, 3);
				break;

			case 'd131sc':
				$out .= ' d131_sc_0_' . substr($data, 0, 2);
				break;

			case 'd131sd':
				$out .= ' d131_sd_0_' . substr($data, 0, 2);
				break;

			case 'd131se':
				$out .= ' d131_se_0_' . substr($data, 0, 2);
				break;

			case 'd131sf':
				$out .= ' d131_sf_0_' . substr($data, 0, 2);
				break;

			case 'd131sg':
				$out .= ' d131_sg_0_' . substr($data, 0, 2);
				break;

			case 'd131sh':
				$out .= ' d131_sh_0_' . substr($data, 0, 4);
				break;

			case 'd131si':
				$out .= ' d131_si_0_' . substr($data, 0, 4);
				break;

			case 'd131sj':
				$out .= ' d131_sj_0_' . substr($data, 0, 2);
				break;

			case 'd131sk':
				$out .= ' d131_sk_0_' . substr($data, 0, 2);
				break;

			case 'd131sl':
				$out .= ' d131_sl_0_' . substr($data, 0, 2);
				break;

			case 'd135sa':
				$out .= ' d135_sa_0_' . substr($data, 0, 1).
					' d135_sa_1_' . substr($data, 1, 1).
					' d135_sa_2_' . substr($data, 2, 1).
					' d135_sa_3_' . substr($data, 3, 1).
					' d135_sa_4_' . substr($data, 4, 1).
					' d135_sa_5_' . substr($data, 5, 3).
					' d135_sa_8_' . substr($data, 8, 1).
					' d135_sa_9_' . substr($data, 9, 1).
					' d135_sa_10_' . substr($data, 10, 1).
					' d135_sa_11_' . substr($data, 11, 1).
					' d135_sa_12_' . substr($data, 12, 1);
				break;

			case 'd140sa':
				$out .= ' d140_sa_0_' . substr($data, 0, 1).
					' d140_sa_1_' . substr($data, 1, 1).
					' d140_sa_2_' . substr($data, 2, 1).
					' d140_sa_3_' . substr($data, 3, 1).
					' d140_sa_4_' . substr($data, 4, 1).
					' d140_sa_5_' . substr($data, 5, 1).
					' d140_sa_6_' . substr($data, 6, 1).
					' d140_sa_7_' . substr($data, 7, 1).
					' d140_sa_8_' . substr($data, 8, 1).
					' d140_sa_9_' . substr($data, 9, 2).
					' d140_sa_11_' . substr($data, 11, 2).
					' d140_sa_13_' . substr($data, 13, 2).
					' d140_sa_15_' . substr($data, 15, 2).
					' d140_sa_17_' . substr($data, 17, 2).
					' d140_sa_19_' . substr($data, 19, 1).
					' d140_sa_20_' . substr($data, 20, 1).
					' d140_sa_21_' . substr($data, 21, 1).
					' d140_sa_22_' . substr($data, 22, 1).
					' d140_sa_23_' . substr($data, 23, 1).
					' d140_sa_24_' . substr($data, 24, 1).
					' d140_sa_25_' . substr($data, 25, 1);
				break;

			case 'd141sa':
				$out .= ' d141_sa_0_' . substr($data, 0, 1).
					' d141_sa_1_' . substr($data, 1, 1).
					' d141_sa_2_' . substr($data, 2, 1).
					' d141_sa_3_' . substr($data, 3, 1).
					' d141_sa_4_' . substr($data, 4, 1).
					' d141_sa_5_' . substr($data, 5, 1).
					' d141_sa_6_' . substr($data, 6, 1).
					' d141_sa_7_' . substr($data, 7, 1);
				break;

			case 'd141sb':
				$out .= ' d141_sb_0_' . substr($data, 0, 2).
					' d141_sb_2_' . substr($data, 2, 2).
					' d141_sb_4_' . substr($data, 4, 1).
					' d141_sb_5_' . substr($data, 5, 1).
					' d141_sb_6_' . substr($data, 6, 1).
					' d141_sb_7_' . substr($data, 7, 1);
				break;

			case 'd141sc':
				$out .= ' d141_sc_0_' . substr($data, 0, 1);
				break;

			case 'd141s5':
				$out .= ' d141_s5_0_' . substr($data, 0, 15);
				break;

			case 'd141s9':
				$out .= ' d141_s9_0_' . substr($data, 0, 1).
					' d141_s9_1_' . substr($data, 1, 1).
					' d141_s9_2_' . substr($data, 2, 1);
				break;

			case 'd145sa':
				$out .= ' d145_sa_0_' . substr($data, 0, 1);
				break;

			case 'd145sb':
				$out .= ' d145_sb_0_' . substr($data, 0, 2).
					' d145_sb_2_' . substr($data, 2, 3).
					' d145_sb_5_' . substr($data, 5, 3);
				break;

			case 'd145sc':
				$out .= ' d145_sc_0_' . substr($data, 0, 2).
					' d145_sc_2_' . substr($data, 2, 3).
					' d145_sc_5_' . substr($data, 5, 3);
				break;

			case 'd145sd':
				$out .= ' d145_sd_0_' . substr($data, 0, 2).
					' d145_sd_2_' . substr($data, 2, 3).
					' d145_sd_5_' . substr($data, 5, 3);
				break;

			case 'd145se':
				$out .= ' d145_se_0_' . substr($data, 0, 4);
				break;

			case 'd145sf':
				$out .= ' d145_sf_0_' . substr($data, 0, 3).
					' d145_sf_3_' . substr($data, 3, 1);
				break;

			case 'd149sa':
				$out .= ' d149_sa_0_' . substr($data, 0, 2).
					' d149_sa_2_' . substr($data, 2, 2).
					' d149_sa_4_' . substr($data, 4, 2).
					' d149_sa_6_' . substr($data, 6, 2).
					' d149_sa_8_' . substr($data, 8, 2).
					' d149_sa_10_' . substr($data, 10, 1).
					' d149_sa_11_' . substr($data, 11, 1).
					' d149_sa_12_' . substr($data, 12, 1).
					' d149_sa_13_' . substr($data, 13, 1).
					' d149_sa_14_' . substr($data, 14, 1).
					' d149_sa_15_' . substr($data, 15, 1).
					' d149_sa_16_' . substr($data, 16, 1).
					' d149_sa_17_' . substr($data, 17, 1).
					' d149_sa_18_' . substr($data, 18, 1).
					' d149_sa_19_' . substr($data, 19, 1).
					' d149_sa_20_' . substr($data, 20, 1).
					' d149_sa_21_' . substr($data, 21, 1).
					' d149_sa_22_' . substr($data, 22, 1).
					' d149_sa_23_' . substr($data, 23, 1);
				break;

			case 'd149sb':
				$out .= ' d149_sb_0_' . substr($data, 0, 1).
					' d149_sb_1_' . substr($data, 1, 1).
					' d149_sb_2_' . substr($data, 2, 1).
					' d149_sb_3_' . substr($data, 3, 1).
					' d149_sb_4_' . substr($data, 4, 1).
					' d149_sb_5_' . substr($data, 5, 1).
					' d149_sb_6_' . substr($data, 6, 1).
					' d149_sb_7_' . substr($data, 7, 1);
				break;

			case 'd149sc':
				$out .= ' d149_sc_0_' . substr($data, 0, 2).
					' d149_sc_2_' . substr($data, 2, 2).
					' d149_sc_4_' . substr($data, 4, 1).
					' d149_sc_5_' . substr($data, 5, 1).
					' d149_sc_6_' . substr($data, 6, 1).
					' d149_sc_7_' . substr($data, 7, 1);
				break;

			case 'd149sd':
				$out .= ' d149_sd_0_' . substr($data, 0, 1).
					' d149_sd_1_' . substr($data, 1, 1);
				break;

			case 'd149s9':
				$out .= ' d149_s9_0_' . substr($data, 0, 1).
					' d149_s9_1_' . substr($data, 1, 1).
					' d149_s9_2_' . substr($data, 2, 1);
				break;
		}
		return $out;
	}
}

/**
 * Authority2Solr Class
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Libraries
 * @since 2.5.1
 */
class Authority2Solr extends BaseTMarc2Solr
{
	static public $FACETS = array(
		'mrc_d035_sa' => 'fldin_str_bid',
		'mrc_d035_s9' => 'fldin_str_bid_source',
		'mrc_l_9' => 'facets_entitytype',
		'mrc_d901_sm' => 'fldis_str_auth_type',
		'mrc_d901_sn' => 'facets_authrectype',
		'fldis_str_auth_type' => 'facets_authtype',
		'fldis_str_auth_type' => 'sorts_type',
		'mrc_d901_sr' => 'sorts_updated',
		'mrc_d901_su' => 'sorts_created',
        'mrc_d299_sa' => 'fldis_str_fulltext',
        'mrc_d299_sc' => 'sorts_fulltext',
        'mrc_d902_sa' => 'sorts_finger1',
        'mrc_d902_sb' => 'sorts_finger2',
        'mrc_d902_sc' => 'sorts_finger3',
        'mrc_d902_sd' => 'sorts_finger4'
	);

	static public $MAPS = array(
		array('d015' , array('normalizeNumber',array('field'=>'fldin_txt_numbers'))),
		array('d101' , array('fieldMap',array('field'=>'facets_lang','subfield'=>'s[1-9a-z]'))),
		array('d102' , array('fieldMap',array('field'=>'facets_country','subfield'=>'sa'))),
		array('d[234567]\d\d' , array('fulltextGen',array('field'=>'fulltext','subfield'=>'s[a-z]'))),
		array('d(3??|830)', array('fieldMap',array('field'=>'fldin_txt_note','subfield'=>'sa'))),
        array('d(5??)', array('fieldMap',array('field'=>'fldin_txt_titles','subfield'=>'sa'))),
		array('d955', array('fieldSearcheableAttach',array('field'=>'fldin_txt_fulltextattach'))),
	);

	public static function getSolrDoc($xmlString,$authorityId=0,$database='',$collection='')
	{
		$xmlDoc = simplexml_load_string($xmlString,'TurboMarc');
		if ($xmlDoc === false)
			throw new Exception ("Failed to load XML for RECORDID:{$authorityId}\n $xmlString\n");

		$out = array();

		foreach ($xmlDoc as $n) {
			$e = $n->getName();
			foreach(self::$MAPS as $map)
			{
				$pattern = $map[0];
				$param = $map[1];
				if (preg_match("/{$pattern}/", $e))
				{
					$ret = self::{$param[0]}($n,$param[1]);
					if($ret != null)
					{
						if (isset($ret['field']))
							$out[] = $ret;
						else
							$out = array_merge($out, $ret);
					}
				}
			}

			if ($n->count() > 0) { // Field with subfields
				foreach ($n as $sf) {
					$sfname = $sf->getName();
					$out[] = array('field' => "mrc_{$e}_{$sfname}", 'value' => (string)$sf);
				}
			} else {
				// leader
				if ($e == 'l') {
					$out[] = array('field' => 'mrc_l_9', 'value' => substr((string) $n, 9, 1));
				} else {
					// c00X
					$out[] = array('field' => "mrc_{$e}", 'value' => (string) $n);
				}
			}
		}

		$out[] = array('field' => 'id', 'value' => $database.':'.$collection.':'.$authorityId);
		$out[] = array('field' => 'database', 'value' => $database);
		$out[] = array('field' => 'collection', 'value' => $collection);
		$out[] = array('field' => 'turbo_marc', 'value' => $xmlString);

		$buffer = "<doc>\n";
		foreach ($out as $fld) {
			if ($fld == null || trim($fld['field']) == "" || trim($fld['value']) == "" )
				continue;
			$buffer .= "<field name=\"{$fld['field']}\">";
			$buffer .= htmlspecialchars($fld['value'], ENT_QUOTES, 'UTF-8');
			$buffer .= "</field>\n";

			if (array_key_exists($fld['field'], self::$FACETS)) {
				$buffer .= "<field name=\"" . self::$FACETS[$fld['field']] . "\">";
				$buffer .= htmlspecialchars($fld['value'], ENT_QUOTES, 'UTF-8');
				$buffer .= "</field>\n";
			}

		}
		$buffer .= "</doc>\n";
		return $buffer;
	}
}
