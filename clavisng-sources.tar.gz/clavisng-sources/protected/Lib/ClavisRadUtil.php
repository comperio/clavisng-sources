<?php
/**
 * ClavisRadUtil class file
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 */

/**
 * ClavisRadUtil Class
 * 
 * Mar 2019 
 * @todo
 * This should be renamed into ClavisNMUtil because many non radius features was added
 *
 * @author Cristian Chiarello <cristian.chiarello@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2008 ePortal Technologies
 * @copyright Copyright &copy; 2009 Comperio srl
 * @package Lib
 */
class ClavisRadUtil{
	
	//static $RAD_URL = 'http://192.168.1.240/clavisrad/index.php?rpc=radrpc';

	//Class used on clavis param
	const CP_CLASS = 'NETMANAGER';
	
	//Clavis param names
	
	//Radius RPC url - clavisrad
	const CP_RPCURL_LIBPREFS = 'RADRPCURL_LIBPREF';
	const CP_RPCURL_SYSPREFS = 'RADRPCURL_SYSPREF';
	
	//Computed user used time preferences
	const CP_CUUT_LIBPREFS = 'CUUT_LIBPREFS';
	const CP_CUUT_SYSPREFS = 'CUUT_SYSPREFS';
	
	//Age of visible session
	const CP_SESSION_VIEW_AGE = 'SESSION_VIEW_AGE';
	
	/**
	 * Return a string libid|clavisurl used by device to contact clavis correctly
	 * @param ClavisPage $page 
	 * @return string
	 */
	public static function getResourceDesc($page)
	{
		$libid = $page->getUser()->getActualLibraryId();
		/*
		$uri = $page->getApplication()->getRequest()->getUrl();
		$desc = $libid.'|'.$uri->scheme.'://'.$uri->host;
		$tokens = explode('/', $uri->path);
		for($i=1; $i< (count($tokens)-1); $i++)
		{
			$desc .= '/'.$tokens[$i];
		}
		 * 
		 */
		$desc = $libid ."|".ClavisParamQuery::getParam('CLAVISPARAM','BaseUrl');
		return $desc;
	}
	
	/*
	 * Return a RPC client
	 * Search with order:
	 * Library preferences
	 * System preferences
	 * Old clavis param as fallback
	 */
	public static function getClient($library_id)
	{
		$FRURL = urldecode(ClavisParamQuery::getParam(self::CP_CLASS, self::CP_RPCURL_LIBPREFS, $library_id));
		if(!is_null($FRURL) && $FRURL != '')
		{
			return new jsonRPCClient($FRURL);
		}
		
		$FRURL = urldecode(ClavisParamQuery::getParam(self::CP_CLASS, self::CP_RPCURL_SYSPREFS));
		if(!is_null($FRURL) && $FRURL != '')
		{
			return new jsonRPCClient($FRURL);
		}
		
		$FRURL = ClavisParamQuery::getParam('CLAVISPARAM','NetManager');
		if(!is_null($FRURL) && $FRURL != '')
		{
			return new jsonRPCClient($FRURL);
		}

		throw new Exception('Radius RPC url is not set yet!');
	}
}