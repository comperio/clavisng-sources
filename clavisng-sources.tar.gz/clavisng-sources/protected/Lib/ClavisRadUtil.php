<?php

class ClavisRadUtil{
	
	//static $RAD_URL = 'http://192.168.1.240/clavisrad/index.php?rpc=radrpc';

	public static function getResourceDesc($page)
	{
		$libid = $page->getUser()->getActualLibraryId();
		/*
		$uri = $page->getApplication()->getRequest()->getUrl();
		$desc = $libid.'|'.$uri->scheme.'://'.$uri->host;
		$tokens = explode('/', $uri->path);
		for($i=1; $i< (count($tokens)-1); $i++)
		{
			$desc .= '/'.$tokens[$i];
		}
		 * 
		 */
		$desc = $libid ."|".ClavisParamQuery::getParam('CLAVISPARAM','BaseUrl');
		return $desc;
	}
	
	public static function getClient()
	{
		$FRURL = ClavisParamQuery::getParam('CLAVISPARAM','NetManager');
		if(!is_null($FRURL) && $FRURL != '')
		{
			return new jsonRPCClient($FRURL);
		}
		else
		{
			throw new Exception('NetManager clavis param is not set!');
		}
		//return new jsonRPCClient(self::$RAD_URL);
	}
}