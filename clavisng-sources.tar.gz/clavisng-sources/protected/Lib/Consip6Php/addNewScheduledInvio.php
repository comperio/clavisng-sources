<?php

class addNewScheduledInvio
{

    /**
     * @var authInfo $authInfo
     */
    protected $authInfo = null;

    /**
     * @var invioSimpleInfo $invioInfo
     */
    protected $invioInfo = null;

    /**
     * @var schedulerSimpleInfo $schedulerSimpleInfo
     */
    protected $schedulerSimpleInfo = null;

    
    public function __construct()
    {
    
    }

    /**
     * @return authInfo
     */
    public function getAuthInfo()
    {
      return $this->authInfo;
    }

    /**
     * @param authInfo $authInfo
     * @return addNewScheduledInvio
     */
    public function setAuthInfo($authInfo)
    {
      $this->authInfo = $authInfo;
      return $this;
    }

    /**
     * @return invioSimpleInfo
     */
    public function getInvioInfo()
    {
      return $this->invioInfo;
    }

    /**
     * @param invioSimpleInfo $invioInfo
     * @return addNewScheduledInvio
     */
    public function setInvioInfo($invioInfo)
    {
      $this->invioInfo = $invioInfo;
      return $this;
    }

    /**
     * @return schedulerSimpleInfo
     */
    public function getSchedulerSimpleInfo()
    {
      return $this->schedulerSimpleInfo;
    }

    /**
     * @param schedulerSimpleInfo $schedulerSimpleInfo
     * @return addNewScheduledInvio
     */
    public function setSchedulerSimpleInfo($schedulerSimpleInfo)
    {
      $this->schedulerSimpleInfo = $schedulerSimpleInfo;
      return $this;
    }

}
