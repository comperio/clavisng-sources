<?php

class addNewIstantInvio
{

    /**
     * @var authInfo $auth
     */
    protected $auth = null;

    /**
     * @var invioSimpleInfo $invio
     */
    protected $invio = null;

    
    public function __construct()
    {
    
    }

    /**
     * @return authInfo
     */
    public function getAuth()
    {
      return $this->auth;
    }

    /**
     * @param authInfo $auth
     * @return addNewIstantInvio
     */
    public function setAuth($auth)
    {
      $this->auth = $auth;
      return $this;
    }

    /**
     * @return invioSimpleInfo
     */
    public function getInvio()
    {
      return $this->invio;
    }

    /**
     * @param invioSimpleInfo $invio
     * @return addNewIstantInvio
     */
    public function setInvio($invio)
    {
      $this->invio = $invio;
      return $this;
    }

}
