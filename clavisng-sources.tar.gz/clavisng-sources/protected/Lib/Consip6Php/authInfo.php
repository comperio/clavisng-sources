<?php

class authInfo
{

    /**
     * @var string $contratto
     */
    protected $contratto = null;

    /**
     * @var string $password
     */
    protected $password = null;

    /**
     * @var string $ser
     */
    protected $ser = null;

    /**
     * @var string $username
     */
    protected $username = null;

    
    public function __construct()
    {
    
    }

    /**
     * @return string
     */
    public function getContratto()
    {
      return $this->contratto;
    }

    /**
     * @param string $contratto
     * @return authInfo
     */
    public function setContratto($contratto)
    {
      $this->contratto = $contratto;
      return $this;
    }

    /**
     * @return string
     */
    public function getPassword()
    {
      return $this->password;
    }

    /**
     * @param string $password
     * @return authInfo
     */
    public function setPassword($password)
    {
      $this->password = $password;
      return $this;
    }

    /**
     * @return string
     */
    public function getSer()
    {
      return $this->ser;
    }

    /**
     * @param string $ser
     * @return authInfo
     */
    public function setSer($ser)
    {
      $this->ser = $ser;
      return $this;
    }

    /**
     * @return string
     */
    public function getUsername()
    {
      return $this->username;
    }

    /**
     * @param string $username
     * @return authInfo
     */
    public function setUsername($username)
    {
      $this->username = $username;
      return $this;
    }

}
