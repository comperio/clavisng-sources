<?php

class messageSimpleInfo
{

    /**
     * @var \DateTime $date
     */
    protected $date = null;

    /**
     * @var int $messageId
     */
    protected $messageId = null;

    /**
     * @var string $receiver
     */
    protected $receiver = null;

    /**
     * @var string $sender
     */
    protected $sender = null;

    /**
     * @var \DateTime $srdate
     */
    protected $srdate = null;

    /**
     * @var int $status
     */
    protected $status = null;

    /**
     * @var string $text
     */
    protected $text = null;

    /**
     * @var int $type
     */
    protected $type = null;

    
    public function __construct()
    {
    
    }

    /**
     * @return \DateTime
     */
    public function getDate()
    {
      if ($this->date == null) {
        return null;
      } else {
        try {
          return new \DateTime($this->date);
        } catch (\Exception $e) {
          return false;
        }
      }
    }

    /**
     * @param \DateTime $date
     * @return messageSimpleInfo
     */
    public function setDate(\DateTime $date = null)
    {
      if ($date == null) {
       $this->date = null;
      } else {
        $this->date = $date->format(\DateTime::ATOM);
      }
      return $this;
    }

    /**
     * @return int
     */
    public function getMessageId()
    {
      return $this->messageId;
    }

    /**
     * @param int $messageId
     * @return messageSimpleInfo
     */
    public function setMessageId($messageId)
    {
      $this->messageId = $messageId;
      return $this;
    }

    /**
     * @return string
     */
    public function getReceiver()
    {
      return $this->receiver;
    }

    /**
     * @param string $receiver
     * @return messageSimpleInfo
     */
    public function setReceiver($receiver)
    {
      $this->receiver = $receiver;
      return $this;
    }

    /**
     * @return string
     */
    public function getSender()
    {
      return $this->sender;
    }

    /**
     * @param string $sender
     * @return messageSimpleInfo
     */
    public function setSender($sender)
    {
      $this->sender = $sender;
      return $this;
    }

    /**
     * @return \DateTime
     */
    public function getSrdate()
    {
      if ($this->srdate == null) {
        return null;
      } else {
        try {
          return new \DateTime($this->srdate);
        } catch (\Exception $e) {
          return false;
        }
      }
    }

    /**
     * @param \DateTime $srdate
     * @return messageSimpleInfo
     */
    public function setSrdate(\DateTime $srdate = null)
    {
      if ($srdate == null) {
       $this->srdate = null;
      } else {
        $this->srdate = $srdate->format(\DateTime::ATOM);
      }
      return $this;
    }

    /**
     * @return int
     */
    public function getStatus()
    {
      return $this->status;
    }

    /**
     * @param int $status
     * @return messageSimpleInfo
     */
    public function setStatus($status)
    {
      $this->status = $status;
      return $this;
    }

    /**
     * @return string
     */
    public function getText()
    {
      return $this->text;
    }

    /**
     * @param string $text
     * @return messageSimpleInfo
     */
    public function setText($text)
    {
      $this->text = $text;
      return $this;
    }

    /**
     * @return int
     */
    public function getType()
    {
      return $this->type;
    }

    /**
     * @param int $type
     * @return messageSimpleInfo
     */
    public function setType($type)
    {
      $this->type = $type;
      return $this;
    }

}
