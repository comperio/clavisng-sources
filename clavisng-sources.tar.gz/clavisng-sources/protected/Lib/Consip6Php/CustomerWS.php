<?php

class CustomerWS extends \SoapClient
{

    /**
     * @var array $classmap The defined classes
     */
    private static $classmap = array (
      'getMsgMO' => '\\getMsgMO',
      'authInfo' => '\\authInfo',
      'filterCollection' => '\\filterCollection',
      'getMsgMOResponse' => '\\getMsgMOResponse',
      'messageCollection' => '\\messageCollection',
      'serviceResponse' => '\\serviceResponse',
      'messageSimpleInfo' => '\\messageSimpleInfo',
      'listCollection' => '\\listCollection',
      'listSimpleInfo' => '\\listSimpleInfo',
      'bundleCollection' => '\\bundleCollection',
      'bundleSimpleInfo' => '\\bundleSimpleInfo',
      'invioCollection' => '\\invioCollection',
      'invioSimpleInfo' => '\\invioSimpleInfo',
      'getListResponse' => '\\getListResponse',
      'deleteScheduledInvioResponse' => '\\deleteScheduledInvioResponse',
      'addNewScheduledInvioResponse' => '\\addNewScheduledInvioResponse',
      'newList' => '\\newList',
      'contactSimpleInfo' => '\\contactSimpleInfo',
      'getInvioResponse' => '\\getInvioResponse',
      'addNewIstantInvio' => '\\addNewIstantInvio',
      'addNewIstantInvioResponse' => '\\addNewIstantInvioResponse',
      'addNewScheduledInvio' => '\\addNewScheduledInvio',
      'schedulerSimpleInfo' => '\\schedulerSimpleInfo',
      'getList' => '\\getList',
      'deleteList' => '\\deleteList',
      'deleteScheduledInvio' => '\\deleteScheduledInvio',
      'getMsgMTFromInvioResponse' => '\\getMsgMTFromInvioResponse',
      'newListResponse' => '\\newListResponse',
      'getMsgMTFromInvio' => '\\getMsgMTFromInvio',
      'getBundle' => '\\getBundle',
      'getBundleResponse' => '\\getBundleResponse',
      'deleteListResponse' => '\\deleteListResponse',
      'getInvio' => '\\getInvio',
    );

    /**
     * @param array $options A array of config values
     * @param string $wsdl The wsdl file to use
     */
    public function __construct(array $options = array(), $wsdl = null)
    {
      foreach (self::$classmap as $key => $value) {
        if (!isset($options['classmap'][$key])) {
          $options['classmap'][$key] = $value;
        }
      }
      $options = array_merge(array (
      'features' => 1,
    ), $options);
      if (!$wsdl) {
        $wsdl = 'https://msg.telecomitalia.it:443/smashcnsp/CustomerWS?wsdl';
      }
      parent::__construct($wsdl, $options);
    }

    /**
     * @param newList $parameters
     * @return newListResponse
     */
    public function newList(newList $parameters)
    {
      return $this->__soapCall('newList', array($parameters));
    }

    /**
     * @param getBundle $parameters
     * @return getBundleResponse
     */
    public function getBundle(getBundle $parameters)
    {
      return $this->__soapCall('getBundle', array($parameters));
    }

    /**
     * @param getList $parameters
     * @return getListResponse
     */
    public function getList(getList $parameters)
    {
      return $this->__soapCall('getList', array($parameters));
    }

    /**
     * @param getInvio $parameters
     * @return getInvioResponse
     */
    public function getInvio(getInvio $parameters)
    {
      return $this->__soapCall('getInvio', array($parameters));
    }

    /**
     * @param addNewIstantInvio $parameters
     * @return addNewIstantInvioResponse
     */
    public function addNewIstantInvio(addNewIstantInvio $parameters)
    {
      return $this->__soapCall('addNewIstantInvio', array($parameters));
    }

    /**
     * @param addNewScheduledInvio $parameters
     * @return addNewScheduledInvioResponse
     */
    public function addNewScheduledInvio(addNewScheduledInvio $parameters)
    {
      return $this->__soapCall('addNewScheduledInvio', array($parameters));
    }

    /**
     * @param deleteScheduledInvio $parameters
     * @return deleteScheduledInvioResponse
     */
    public function deleteScheduledInvio(deleteScheduledInvio $parameters)
    {
      return $this->__soapCall('deleteScheduledInvio', array($parameters));
    }

    /**
     * @param deleteList $parameters
     * @return deleteListResponse
     */
    public function deleteList(deleteList $parameters)
    {
      return $this->__soapCall('deleteList', array($parameters));
    }

    /**
     * @param getMsgMTFromInvio $parameters
     * @return getMsgMTFromInvioResponse
     */
    public function getMsgMTFromInvio(getMsgMTFromInvio $parameters)
    {
      return $this->__soapCall('getMsgMTFromInvio', array($parameters));
    }

    /**
     * @param getMsgMO $parameters
     * @return getMsgMOResponse
     */
    public function getMsgMO(getMsgMO $parameters)
    {
      return $this->__soapCall('getMsgMO', array($parameters));
    }

}
