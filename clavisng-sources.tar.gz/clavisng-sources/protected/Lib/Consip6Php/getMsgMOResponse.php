<?php

class getMsgMOResponse
{

    /**
     * @var messageCollection $return
     */
    protected $return = null;

    
    public function __construct()
    {
    
    }

    /**
     * @return messageCollection
     */
    public function getReturn()
    {
      return $this->return;
    }

    /**
     * @param messageCollection $return
     * @return getMsgMOResponse
     */
    public function setReturn($return)
    {
      $this->return = $return;
      return $this;
    }

}
