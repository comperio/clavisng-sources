<?php

class getBundle
{

    /**
     * @var authInfo $authInfo
     */
    protected $authInfo = null;

    
    public function __construct()
    {
    
    }

    /**
     * @return authInfo
     */
    public function getAuthInfo()
    {
      return $this->authInfo;
    }

    /**
     * @param authInfo $authInfo
     * @return getBundle
     */
    public function setAuthInfo($authInfo)
    {
      $this->authInfo = $authInfo;
      return $this;
    }

}
