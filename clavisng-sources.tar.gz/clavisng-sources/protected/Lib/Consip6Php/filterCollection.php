<?php

class filterCollection
{

    /**
     * @var \DateTime $endDate
     */
    protected $endDate = null;

    /**
     * @var int[] $ids
     */
    protected $ids = null;

    /**
     * @var int $marker
     */
    protected $marker = null;

    /**
     * @var int $maxKeys
     */
    protected $maxKeys = null;

    /**
     * @var string $pattern
     */
    protected $pattern = null;

    /**
     * @var \DateTime $startDate
     */
    protected $startDate = null;

    
    public function __construct()
    {
    
    }

    /**
     * @return \DateTime
     */
    public function getEndDate()
    {
      if ($this->endDate == null) {
        return null;
      } else {
        try {
          return new \DateTime($this->endDate);
        } catch (\Exception $e) {
          return false;
        }
      }
    }

    /**
     * @param \DateTime $endDate
     * @return filterCollection
     */
    public function setEndDate(\DateTime $endDate = null)
    {
      if ($endDate == null) {
       $this->endDate = null;
      } else {
        $this->endDate = $endDate->format(\DateTime::ATOM);
      }
      return $this;
    }

    /**
     * @return int[]
     */
    public function getIds()
    {
      return $this->ids;
    }

    /**
     * @param int[] $ids
     * @return filterCollection
     */
    public function setIds(array $ids = null)
    {
      $this->ids = $ids;
      return $this;
    }

    /**
     * @return int
     */
    public function getMarker()
    {
      return $this->marker;
    }

    /**
     * @param int $marker
     * @return filterCollection
     */
    public function setMarker($marker)
    {
      $this->marker = $marker;
      return $this;
    }

    /**
     * @return int
     */
    public function getMaxKeys()
    {
      return $this->maxKeys;
    }

    /**
     * @param int $maxKeys
     * @return filterCollection
     */
    public function setMaxKeys($maxKeys)
    {
      $this->maxKeys = $maxKeys;
      return $this;
    }

    /**
     * @return string
     */
    public function getPattern()
    {
      return $this->pattern;
    }

    /**
     * @param string $pattern
     * @return filterCollection
     */
    public function setPattern($pattern)
    {
      $this->pattern = $pattern;
      return $this;
    }

    /**
     * @return \DateTime
     */
    public function getStartDate()
    {
      if ($this->startDate == null) {
        return null;
      } else {
        try {
          return new \DateTime($this->startDate);
        } catch (\Exception $e) {
          return false;
        }
      }
    }

    /**
     * @param \DateTime $startDate
     * @return filterCollection
     */
    public function setStartDate(\DateTime $startDate = null)
    {
      if ($startDate == null) {
       $this->startDate = null;
      } else {
        $this->startDate = $startDate->format(\DateTime::ATOM);
      }
      return $this;
    }

}
