<?php

class getInvioResponse
{

    /**
     * @var invioCollection $return
     */
    protected $return = null;

    
    public function __construct()
    {
    
    }

    /**
     * @return invioCollection
     */
    public function getReturn()
    {
      return $this->return;
    }

    /**
     * @param invioCollection $return
     * @return getInvioResponse
     */
    public function setReturn($return)
    {
      $this->return = $return;
      return $this;
    }

}
