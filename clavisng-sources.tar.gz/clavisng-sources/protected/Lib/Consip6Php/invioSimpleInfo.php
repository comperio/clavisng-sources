<?php

class invioSimpleInfo
{

    /**
     * @var string[] $contattiLiberi
     */
    protected $contattiLiberi = null;

    /**
     * @var \DateTime $dataInvio
     */
    protected $dataInvio = null;

    /**
     * @var int $idInvio
     */
    protected $idInvio = null;

    /**
     * @var int $idLista
     */
    protected $idLista = null;

    /**
     * @var int $invioOver
     */
    protected $invioOver = null;

    /**
     * @var int $invioStato
     */
    protected $invioStato = null;

    /**
     * @var string $nome
     */
    protected $nome = null;

    /**
     * @var int $notificaConsegna
     */
    protected $notificaConsegna = null;

    /**
     * @var int $notificaInvio
     */
    protected $notificaInvio = null;

    /**
     * @var int $retry
     */
    protected $retry = null;

    /**
     * @var int $sr
     */
    protected $sr = null;

    /**
     * @var string $testo
     */
    protected $testo = null;

    /**
     * @var int $tipo
     */
    protected $tipo = null;

    /**
     * @var string $trid
     */
    protected $trid = null;

    
    public function __construct()
    {
    
    }

    /**
     * @return string[]
     */
    public function getContattiLiberi()
    {
      return $this->contattiLiberi;
    }

    /**
     * @param string[] $contattiLiberi
     * @return invioSimpleInfo
     */
    public function setContattiLiberi(array $contattiLiberi = null)
    {
      $this->contattiLiberi = $contattiLiberi;
      return $this;
    }

    /**
     * @return \DateTime
     */
    public function getDataInvio()
    {
      if ($this->dataInvio == null) {
        return null;
      } else {
        try {
          return new \DateTime($this->dataInvio);
        } catch (\Exception $e) {
          return false;
        }
      }
    }

    /**
     * @param \DateTime $dataInvio
     * @return invioSimpleInfo
     */
    public function setDataInvio(\DateTime $dataInvio = null)
    {
      if ($dataInvio == null) {
       $this->dataInvio = null;
      } else {
        $this->dataInvio = $dataInvio->format(\DateTime::ATOM);
      }
      return $this;
    }

    /**
     * @return int
     */
    public function getIdInvio()
    {
      return $this->idInvio;
    }

    /**
     * @param int $idInvio
     * @return invioSimpleInfo
     */
    public function setIdInvio($idInvio)
    {
      $this->idInvio = $idInvio;
      return $this;
    }

    /**
     * @return int
     */
    public function getIdLista()
    {
      return $this->idLista;
    }

    /**
     * @param int $idLista
     * @return invioSimpleInfo
     */
    public function setIdLista($idLista)
    {
      $this->idLista = $idLista;
      return $this;
    }

    /**
     * @return int
     */
    public function getInvioOver()
    {
      return $this->invioOver;
    }

    /**
     * @param int $invioOver
     * @return invioSimpleInfo
     */
    public function setInvioOver($invioOver)
    {
      $this->invioOver = $invioOver;
      return $this;
    }

    /**
     * @return int
     */
    public function getInvioStato()
    {
      return $this->invioStato;
    }

    /**
     * @param int $invioStato
     * @return invioSimpleInfo
     */
    public function setInvioStato($invioStato)
    {
      $this->invioStato = $invioStato;
      return $this;
    }

    /**
     * @return string
     */
    public function getNome()
    {
      return $this->nome;
    }

    /**
     * @param string $nome
     * @return invioSimpleInfo
     */
    public function setNome($nome)
    {
      $this->nome = $nome;
      return $this;
    }

    /**
     * @return int
     */
    public function getNotificaConsegna()
    {
      return $this->notificaConsegna;
    }

    /**
     * @param int $notificaConsegna
     * @return invioSimpleInfo
     */
    public function setNotificaConsegna($notificaConsegna)
    {
      $this->notificaConsegna = $notificaConsegna;
      return $this;
    }

    /**
     * @return int
     */
    public function getNotificaInvio()
    {
      return $this->notificaInvio;
    }

    /**
     * @param int $notificaInvio
     * @return invioSimpleInfo
     */
    public function setNotificaInvio($notificaInvio)
    {
      $this->notificaInvio = $notificaInvio;
      return $this;
    }

    /**
     * @return int
     */
    public function getRetry()
    {
      return $this->retry;
    }

    /**
     * @param int $retry
     * @return invioSimpleInfo
     */
    public function setRetry($retry)
    {
      $this->retry = $retry;
      return $this;
    }

    /**
     * @return int
     */
    public function getSr()
    {
      return $this->sr;
    }

    /**
     * @param int $sr
     * @return invioSimpleInfo
     */
    public function setSr($sr)
    {
      $this->sr = $sr;
      return $this;
    }

    /**
     * @return string
     */
    public function getTesto()
    {
      return $this->testo;
    }

    /**
     * @param string $testo
     * @return invioSimpleInfo
     */
    public function setTesto($testo)
    {
      $this->testo = $testo;
      return $this;
    }

    /**
     * @return int
     */
    public function getTipo()
    {
      return $this->tipo;
    }

    /**
     * @param int $tipo
     * @return invioSimpleInfo
     */
    public function setTipo($tipo)
    {
      $this->tipo = $tipo;
      return $this;
    }

    /**
     * @return string
     */
    public function getTrid()
    {
      return $this->trid;
    }

    /**
     * @param string $trid
     * @return invioSimpleInfo
     */
    public function setTrid($trid)
    {
      $this->trid = $trid;
      return $this;
    }

}
