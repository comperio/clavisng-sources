<?php

class contactSimpleInfo
{

    /**
     * @var string $firstName
     */
    protected $firstName = null;

    /**
     * @var int $idx
     */
    protected $idx = null;

    /**
     * @var string $lastName
     */
    protected $lastName = null;

    /**
     * @var string $msisdn
     */
    protected $msisdn = null;

    
    public function __construct()
    {
    
    }

    /**
     * @return string
     */
    public function getFirstName()
    {
      return $this->firstName;
    }

    /**
     * @param string $firstName
     * @return contactSimpleInfo
     */
    public function setFirstName($firstName)
    {
      $this->firstName = $firstName;
      return $this;
    }

    /**
     * @return int
     */
    public function getIdx()
    {
      return $this->idx;
    }

    /**
     * @param int $idx
     * @return contactSimpleInfo
     */
    public function setIdx($idx)
    {
      $this->idx = $idx;
      return $this;
    }

    /**
     * @return string
     */
    public function getLastName()
    {
      return $this->lastName;
    }

    /**
     * @param string $lastName
     * @return contactSimpleInfo
     */
    public function setLastName($lastName)
    {
      $this->lastName = $lastName;
      return $this;
    }

    /**
     * @return string
     */
    public function getMsisdn()
    {
      return $this->msisdn;
    }

    /**
     * @param string $msisdn
     * @return contactSimpleInfo
     */
    public function setMsisdn($msisdn)
    {
      $this->msisdn = $msisdn;
      return $this;
    }

}
