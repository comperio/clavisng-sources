<?php

class listCollection extends serviceResponse
{

    /**
     * @var listSimpleInfo[] $listCollection
     */
    protected $listCollection = null;

    
    public function __construct()
    {
      parent::__construct();
    }

    /**
     * @return listSimpleInfo[]
     */
    public function getListCollection()
    {
      return $this->listCollection;
    }

    /**
     * @param listSimpleInfo[] $listCollection
     * @return listCollection
     */
    public function setListCollection(array $listCollection = null)
    {
      $this->listCollection = $listCollection;
      return $this;
    }

}
