<?php

class listSimpleInfo
{

    /**
     * @var \DateTime $creationDate
     */
    protected $creationDate = null;

    /**
     * @var int $listId
     */
    protected $listId = null;

    /**
     * @var string $listName
     */
    protected $listName = null;

    
    public function __construct()
    {
    
    }

    /**
     * @return \DateTime
     */
    public function getCreationDate()
    {
      if ($this->creationDate == null) {
        return null;
      } else {
        try {
          return new \DateTime($this->creationDate);
        } catch (\Exception $e) {
          return false;
        }
      }
    }

    /**
     * @param \DateTime $creationDate
     * @return listSimpleInfo
     */
    public function setCreationDate(\DateTime $creationDate = null)
    {
      if ($creationDate == null) {
       $this->creationDate = null;
      } else {
        $this->creationDate = $creationDate->format(\DateTime::ATOM);
      }
      return $this;
    }

    /**
     * @return int
     */
    public function getListId()
    {
      return $this->listId;
    }

    /**
     * @param int $listId
     * @return listSimpleInfo
     */
    public function setListId($listId)
    {
      $this->listId = $listId;
      return $this;
    }

    /**
     * @return string
     */
    public function getListName()
    {
      return $this->listName;
    }

    /**
     * @param string $listName
     * @return listSimpleInfo
     */
    public function setListName($listName)
    {
      $this->listName = $listName;
      return $this;
    }

}
