<?php

class schedulerSimpleInfo
{

    /**
     * @var \DateTime $endDate
     */
    protected $endDate = null;

    /**
     * @var int $fixedDelay
     */
    protected $fixedDelay = null;

    /**
     * @var \DateTime $startDate
     */
    protected $startDate = null;

    
    public function __construct()
    {
    
    }

    /**
     * @return \DateTime
     */
    public function getEndDate()
    {
      if ($this->endDate == null) {
        return null;
      } else {
        try {
          return new \DateTime($this->endDate);
        } catch (\Exception $e) {
          return false;
        }
      }
    }

    /**
     * @param \DateTime $endDate
     * @return schedulerSimpleInfo
     */
    public function setEndDate(\DateTime $endDate = null)
    {
      if ($endDate == null) {
       $this->endDate = null;
      } else {
        $this->endDate = $endDate->format(\DateTime::ATOM);
      }
      return $this;
    }

    /**
     * @return int
     */
    public function getFixedDelay()
    {
      return $this->fixedDelay;
    }

    /**
     * @param int $fixedDelay
     * @return schedulerSimpleInfo
     */
    public function setFixedDelay($fixedDelay)
    {
      $this->fixedDelay = $fixedDelay;
      return $this;
    }

    /**
     * @return \DateTime
     */
    public function getStartDate()
    {
      if ($this->startDate == null) {
        return null;
      } else {
        try {
          return new \DateTime($this->startDate);
        } catch (\Exception $e) {
          return false;
        }
      }
    }

    /**
     * @param \DateTime $startDate
     * @return schedulerSimpleInfo
     */
    public function setStartDate(\DateTime $startDate = null)
    {
      if ($startDate == null) {
       $this->startDate = null;
      } else {
        $this->startDate = $startDate->format(\DateTime::ATOM);
      }
      return $this;
    }

}
