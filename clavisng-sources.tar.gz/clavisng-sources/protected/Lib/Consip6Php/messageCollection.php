<?php

class messageCollection extends serviceResponse
{

    /**
     * @var messageSimpleInfo[] $messageCollection
     */
    protected $messageCollection = null;

    
    public function __construct()
    {
      parent::__construct();
    }

    /**
     * @return messageSimpleInfo[]
     */
    public function getMessageCollection()
    {
      return $this->messageCollection;
    }

    /**
     * @param messageSimpleInfo[] $messageCollection
     * @return messageCollection
     */
    public function setMessageCollection(array $messageCollection = null)
    {
      $this->messageCollection = $messageCollection;
      return $this;
    }

}
