<?php

class deleteScheduledInvioResponse
{

    /**
     * @var serviceResponse $return
     */
    protected $return = null;

    
    public function __construct()
    {
    
    }

    /**
     * @return serviceResponse
     */
    public function getReturn()
    {
      return $this->return;
    }

    /**
     * @param serviceResponse $return
     * @return deleteScheduledInvioResponse
     */
    public function setReturn($return)
    {
      $this->return = $return;
      return $this;
    }

}
