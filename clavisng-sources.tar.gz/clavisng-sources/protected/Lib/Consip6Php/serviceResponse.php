<?php

class serviceResponse
{

    /**
     * @var int $idx
     */
    protected $idx = null;

    /**
     * @var int $statusCode
     */
    protected $statusCode = null;

    /**
     * @var string $statusMessage
     */
    protected $statusMessage = null;

    
    public function __construct()
    {
    
    }

    /**
     * @return int
     */
    public function getIdx()
    {
      return $this->idx;
    }

    /**
     * @param int $idx
     * @return serviceResponse
     */
    public function setIdx($idx)
    {
      $this->idx = $idx;
      return $this;
    }

    /**
     * @return int
     */
    public function getStatusCode()
    {
      return $this->statusCode;
    }

    /**
     * @param int $statusCode
     * @return serviceResponse
     */
    public function setStatusCode($statusCode)
    {
      $this->statusCode = $statusCode;
      return $this;
    }

    /**
     * @return string
     */
    public function getStatusMessage()
    {
      return $this->statusMessage;
    }

    /**
     * @param string $statusMessage
     * @return serviceResponse
     */
    public function setStatusMessage($statusMessage)
    {
      $this->statusMessage = $statusMessage;
      return $this;
    }

}
