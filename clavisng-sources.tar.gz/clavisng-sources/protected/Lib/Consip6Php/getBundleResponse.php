<?php

class getBundleResponse
{

    /**
     * @var bundleCollection $return
     */
    protected $return = null;

    
    public function __construct()
    {
    
    }

    /**
     * @return bundleCollection
     */
    public function getReturn()
    {
      return $this->return;
    }

    /**
     * @param bundleCollection $return
     * @return getBundleResponse
     */
    public function setReturn($return)
    {
      $this->return = $return;
      return $this;
    }

}
