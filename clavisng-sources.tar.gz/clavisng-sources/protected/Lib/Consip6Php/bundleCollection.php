<?php

class bundleCollection extends serviceResponse
{

    /**
     * @var bundleSimpleInfo[] $bundleCollection
     */
    protected $bundleCollection = null;

    
    public function __construct()
    {
      parent::__construct();
    }

    /**
     * @return bundleSimpleInfo[]
     */
    public function getBundleCollection()
    {
      return $this->bundleCollection;
    }

    /**
     * @param bundleSimpleInfo[] $bundleCollection
     * @return bundleCollection
     */
    public function setBundleCollection(array $bundleCollection = null)
    {
      $this->bundleCollection = $bundleCollection;
      return $this;
    }

}
