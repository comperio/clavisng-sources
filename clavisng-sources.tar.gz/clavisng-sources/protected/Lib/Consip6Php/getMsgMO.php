<?php

class getMsgMO
{

    /**
     * @var authInfo $authInfo
     */
    protected $authInfo = null;

    /**
     * @var filterCollection $filterCollection
     */
    protected $filterCollection = null;

    
    public function __construct()
    {
    
    }

    /**
     * @return authInfo
     */
    public function getAuthInfo()
    {
      return $this->authInfo;
    }

    /**
     * @param authInfo $authInfo
     * @return getMsgMO
     */
    public function setAuthInfo($authInfo)
    {
      $this->authInfo = $authInfo;
      return $this;
    }

    /**
     * @return filterCollection
     */
    public function getFilterCollection()
    {
      return $this->filterCollection;
    }

    /**
     * @param filterCollection $filterCollection
     * @return getMsgMO
     */
    public function setFilterCollection($filterCollection)
    {
      $this->filterCollection = $filterCollection;
      return $this;
    }

}
