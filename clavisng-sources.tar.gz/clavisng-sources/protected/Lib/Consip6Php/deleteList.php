<?php

class deleteList
{

    /**
     * @var authInfo $authInfo
     */
    protected $authInfo = null;

    /**
     * @var int $idx
     */
    protected $idx = null;

    
    public function __construct()
    {
    
    }

    /**
     * @return authInfo
     */
    public function getAuthInfo()
    {
      return $this->authInfo;
    }

    /**
     * @param authInfo $authInfo
     * @return deleteList
     */
    public function setAuthInfo($authInfo)
    {
      $this->authInfo = $authInfo;
      return $this;
    }

    /**
     * @return int
     */
    public function getIdx()
    {
      return $this->idx;
    }

    /**
     * @param int $idx
     * @return deleteList
     */
    public function setIdx($idx)
    {
      $this->idx = $idx;
      return $this;
    }

}
