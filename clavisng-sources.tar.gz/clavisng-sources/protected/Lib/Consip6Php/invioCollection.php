<?php

class invioCollection extends serviceResponse
{

    /**
     * @var invioSimpleInfo[] $invioCollection
     */
    protected $invioCollection = null;

    
    public function __construct()
    {
      parent::__construct();
    }

    /**
     * @return invioSimpleInfo[]
     */
    public function getInvioCollection()
    {
      return $this->invioCollection;
    }

    /**
     * @param invioSimpleInfo[] $invioCollection
     * @return invioCollection
     */
    public function setInvioCollection(array $invioCollection = null)
    {
      $this->invioCollection = $invioCollection;
      return $this;
    }

}
