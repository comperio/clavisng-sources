<?php

class bundleSimpleInfo
{

    /**
     * @var int $bundleid
     */
    protected $bundleid = null;

    /**
     * @var string $creditoIniziale
     */
    protected $creditoIniziale = null;

    /**
     * @var int $creditoResiduo
     */
    protected $creditoResiduo = null;

    /**
     * @var \DateTime $data
     */
    protected $data = null;

    /**
     * @var string $serviceCode
     */
    protected $serviceCode = null;

    
    public function __construct()
    {
    
    }

    /**
     * @return int
     */
    public function getBundleid()
    {
      return $this->bundleid;
    }

    /**
     * @param int $bundleid
     * @return bundleSimpleInfo
     */
    public function setBundleid($bundleid)
    {
      $this->bundleid = $bundleid;
      return $this;
    }

    /**
     * @return string
     */
    public function getCreditoIniziale()
    {
      return $this->creditoIniziale;
    }

    /**
     * @param string $creditoIniziale
     * @return bundleSimpleInfo
     */
    public function setCreditoIniziale($creditoIniziale)
    {
      $this->creditoIniziale = $creditoIniziale;
      return $this;
    }

    /**
     * @return int
     */
    public function getCreditoResiduo()
    {
      return $this->creditoResiduo;
    }

    /**
     * @param int $creditoResiduo
     * @return bundleSimpleInfo
     */
    public function setCreditoResiduo($creditoResiduo)
    {
      $this->creditoResiduo = $creditoResiduo;
      return $this;
    }

    /**
     * @return \DateTime
     */
    public function getData()
    {
      if ($this->data == null) {
        return null;
      } else {
        try {
          return new \DateTime($this->data);
        } catch (\Exception $e) {
          return false;
        }
      }
    }

    /**
     * @param \DateTime $data
     * @return bundleSimpleInfo
     */
    public function setData(\DateTime $data = null)
    {
      if ($data == null) {
       $this->data = null;
      } else {
        $this->data = $data->format(\DateTime::ATOM);
      }
      return $this;
    }

    /**
     * @return string
     */
    public function getServiceCode()
    {
      return $this->serviceCode;
    }

    /**
     * @param string $serviceCode
     * @return bundleSimpleInfo
     */
    public function setServiceCode($serviceCode)
    {
      $this->serviceCode = $serviceCode;
      return $this;
    }

}
