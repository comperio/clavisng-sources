<?php


 function autoload_7edbd466304f05498cd3da8b79fa81ee($class)
{
    $classes = array(
        'CustomerWS' => __DIR__ .'/CustomerWS.php',
        'getMsgMO' => __DIR__ .'/getMsgMO.php',
        'authInfo' => __DIR__ .'/authInfo.php',
        'filterCollection' => __DIR__ .'/filterCollection.php',
        'getMsgMOResponse' => __DIR__ .'/getMsgMOResponse.php',
        'messageCollection' => __DIR__ .'/messageCollection.php',
        'serviceResponse' => __DIR__ .'/serviceResponse.php',
        'messageSimpleInfo' => __DIR__ .'/messageSimpleInfo.php',
        'listCollection' => __DIR__ .'/listCollection.php',
        'listSimpleInfo' => __DIR__ .'/listSimpleInfo.php',
        'bundleCollection' => __DIR__ .'/bundleCollection.php',
        'bundleSimpleInfo' => __DIR__ .'/bundleSimpleInfo.php',
        'invioCollection' => __DIR__ .'/invioCollection.php',
        'invioSimpleInfo' => __DIR__ .'/invioSimpleInfo.php',
        'getListResponse' => __DIR__ .'/getListResponse.php',
        'deleteScheduledInvioResponse' => __DIR__ .'/deleteScheduledInvioResponse.php',
        'addNewScheduledInvioResponse' => __DIR__ .'/addNewScheduledInvioResponse.php',
        'newList' => __DIR__ .'/newList.php',
        'contactSimpleInfo' => __DIR__ .'/contactSimpleInfo.php',
        'getInvioResponse' => __DIR__ .'/getInvioResponse.php',
        'addNewIstantInvio' => __DIR__ .'/addNewIstantInvio.php',
        'addNewIstantInvioResponse' => __DIR__ .'/addNewIstantInvioResponse.php',
        'addNewScheduledInvio' => __DIR__ .'/addNewScheduledInvio.php',
        'schedulerSimpleInfo' => __DIR__ .'/schedulerSimpleInfo.php',
        'getList' => __DIR__ .'/getList.php',
        'deleteList' => __DIR__ .'/deleteList.php',
        'deleteScheduledInvio' => __DIR__ .'/deleteScheduledInvio.php',
        'getMsgMTFromInvioResponse' => __DIR__ .'/getMsgMTFromInvioResponse.php',
        'newListResponse' => __DIR__ .'/newListResponse.php',
        'getMsgMTFromInvio' => __DIR__ .'/getMsgMTFromInvio.php',
        'getBundle' => __DIR__ .'/getBundle.php',
        'getBundleResponse' => __DIR__ .'/getBundleResponse.php',
        'deleteListResponse' => __DIR__ .'/deleteListResponse.php',
        'getInvio' => __DIR__ .'/getInvio.php'
    );
    if (!empty($classes[$class])) {
        include $classes[$class];
    };
}

spl_autoload_register('autoload_7edbd466304f05498cd3da8b79fa81ee');

// Do nothing. The rest is just leftovers from the code generation.
{
}
