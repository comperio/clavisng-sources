<?php

class newList
{

    /**
     * @var authInfo $authInfo
     */
    protected $authInfo = null;

    /**
     * @var string $listName
     */
    protected $listName = null;

    /**
     * @var contactSimpleInfo[] $contactList
     */
    protected $contactList = null;

    
    public function __construct()
    {
    
    }

    /**
     * @return authInfo
     */
    public function getAuthInfo()
    {
      return $this->authInfo;
    }

    /**
     * @param authInfo $authInfo
     * @return newList
     */
    public function setAuthInfo($authInfo)
    {
      $this->authInfo = $authInfo;
      return $this;
    }

    /**
     * @return string
     */
    public function getListName()
    {
      return $this->listName;
    }

    /**
     * @param string $listName
     * @return newList
     */
    public function setListName($listName)
    {
      $this->listName = $listName;
      return $this;
    }

    /**
     * @return contactSimpleInfo[]
     */
    public function getContactList()
    {
      return $this->contactList;
    }

    /**
     * @param contactSimpleInfo[] $contactList
     * @return newList
     */
    public function setContactList(array $contactList = null)
    {
      $this->contactList = $contactList;
      return $this;
    }

}
