<?php

class getMsgMTFromInvioResponse
{

    /**
     * @var messageCollection $return
     */
    protected $return = null;

    
    public function __construct()
    {
    
    }

    /**
     * @return messageCollection
     */
    public function getReturn()
    {
      return $this->return;
    }

    /**
     * @param messageCollection $return
     * @return getMsgMTFromInvioResponse
     */
    public function setReturn($return)
    {
      $this->return = $return;
      return $this;
    }

}
