<?php
/**
 * SBNLib file.
 *
 * This file contains all the required classes for SBN dialogue v4.
 * Based upon SBNConnector by Comperio srl.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Modules.SBN
 */

/**
 * SBNRequest Class
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Modules.SBN
 * @since 2.5.1
 */
class SBNRequest
{
	protected $_address;
	protected $_auth = array(
		'user'		=> '',
		'password'	=> '');
	protected $_library;
	protected $_user;
	/* @var SBNMarc */
	public $sbnMarc;

	protected $searchOptions = array(
		'idLista'	=> '',
		'maxRighe'	=> 30,
		'numPrimo'	=> 1,
		'tipoOrd'	=> SBNTypes::SORTTYPE_1,
		'tipoOutput'		=> SBNTypes::OUTPUT_SINTMAX,
		'confermaRicerca'	=> 'S');

	public $searchTitleOptions = array();
	public $searchAutOptions = array();

	public function __construct()
	{
		$this->sbnMarc = SBNMarc::create();
		$this->sbnMarc->SbnMessage->addChild('SbnRequest');
	}

	public function setAddress($v) {
		$this->_address = $v;
	}
	public function getAddress() {
		return $this->_address;
	}
	public function setAuthUser($v) {
		$this->_auth['user'] = $v;
	}
	public function getAuthUser() {
		return $this->_auth['user'];
	}
	public function setAuthPassword($v) {
		$this->_auth['password'] = $v;
	}
	public function getAuthPassword() {
		return $this->_auth['password'];
	}
	public function setLibrary($v) {
		$this->_library = $v;
	}
	public function getLibrary() {
		return $this->_library;
	}
	public function setUser($v) {
		$this->_user = $v;
	}
	public function getUser() {
		return $this->_user;
	}
	public function setSearchId($v) {
		$this->searchOptions['idLista'] = $v;
	}
	public function getSearchId() {
		return $this->searchOptions['idLista'];
	}
	public function setSearchLimit($v) {
		$this->searchOptions['maxRighe'] = $v;
	}
	public function getSearchLimit() {
		return $this->searchOptions['maxRighe'];
	}
	public function setSearchOffset($v) {
		$this->searchOptions['numPrimo'] = $v;
	}
	public function getSearchOffset() {
		return $this->searchOptions['numPrimo'];
	}
	public function setSearchSortType($v) {
		if ($v > 0 && $v < 6)
			$this->searchOptions['tipoOrd'] = $v;
	}
	public function getSearchSortType() {
		return $this->searchOptions['tipoOrd'];
	}
	public function setSearchOutputType($v) {
		$this->searchOptions['tipoOutput'] = $v;
	}
	public function getSearchOutputType() {
		return $this->searchOptions['tipoOutput'];
	}
	public function setSearchConfirm($v) {
		$this->searchOptions['confermaRicerca'] = $v;
	}
	public function getSearchConfirm() {
		return $this->searchOptions['confermaRicerca'];
	}

	/**
	 * Performs a request.
	 *
	 * @return SBNMarc
	 * @throws Exception
	 */
	protected function request()
	{
        $reqseq = microtime(true);
       // file_put_contents("/tmp/sbnlog/{$reqseq}-sbnRequest.xml",$this->sbnMarc->asXML());
		//$resp = file_get_contents('sbnmarc.xml');
		//return new SBNMarc($resp);
		$this->sbnMarc->SbnUser->Biblioteca = $this->_library;
		$this->sbnMarc->SbnUser->UserId = $this->_user;
		try {
			$ch = curl_init();
			$options = array(CURLOPT_URL => $this->_address,
            			     CURLOPT_HEADER => false,
            			     CURLOPT_POST => true,
            			     CURLOPT_POSTFIELDS => $this->sbnMarc->asXML(),
            			     CURLOPT_HTTPAUTH => CURLAUTH_ANY,
            			     CURLOPT_USERPWD => $this->_auth['user'].':'.$this->_auth['password'],
            			     CURLOPT_RETURNTRANSFER => true);
			curl_setopt_array($ch, $options);
			$resp = curl_exec($ch);
          // file_put_contents("/tmp/sbnlog/{$reqseq}-sbnResponse.xml", $resp);

			curl_close($ch);

			return new SBNMarc($resp);
		} catch (Exception $e) {
			Prado::log($e);
			//$errorMsg = @curl_error($ch);
			return null;
			//throw new Exception(get_class($this).': '.$e->getMessage(). "\n(CURL error: ".$errorMsg.')');
		}
	}

	/**
	 * Retrieves SBN profile currently in use.
	 *
	 * @return SBNMarc
	 */
	public function requestCurrentSbnProfile()
	{
		$base = $this->sbnMarc->SbnMessage->SbnRequest->addChild('Cerca', '');
		$this->setSearchOptions();
		$base->addChild('CercaSbnProfile','');
		$base->CercaSbnProfile->addChild('Biblioteca',$this->_library);
		return $this->request();
	}

	/**
	 * Search a record by its bid.
	 *
	 * @param string $bid
	 * @param string $outputType
	 * @return SBNMarc
	 * @throws Exception
	 */
	public function searchTitleByBid($bid, $outputType=SBNTypes::OUTPUT_COMPLETE)
	{
		$bid = htmlspecialchars($bid, ENT_NOQUOTES, 'UTF-8', false);
		// with search by bid, always return analytical if not specified elsewhere
		// NB: this HAS to be set *before* commonSearchTitlePrepare() call.
		$this->searchOptions['tipoOutput'] = $outputType;
		$base = $this->commonSearchTitlePrepare();
		$this->setSearchByTitleOptions();
		$base->addChild('T001', $bid);
		return $this->request();
	}

	/**
	 * Search records by their titles LIKE.
	 *
	 * @param string $title
	 * @return SBNMarc
	 */
	public function searchTitleLike($title)
	{
		return $this->searchTitle($title,SBNTypes::SEARCHOP_LIKE);
	}

	/**
	 * Search records by their titles EQUAL.
	 *
	 * @param string $title
	 * @return SBNMarc
	 */
	public function searchTitleEqual($title)
	{
		return $this->searchTitle($title,SBNTypes::SEARCHOP_EQUAL);
	}

	/**
	 * Search records by their titles.
	 *
	 * @param string $title
	 * @param string $op SBNTYpes::SEARCHOP_*
	 * @return SBNMarc
	 */
	public function searchTitle($title, $op = SBNTypes::SEARCHOP_EQUAL)
	{
		$title = htmlspecialchars($title, ENT_NOQUOTES, 'UTF-8', false);
		$base = $this->commonSearchTitlePrepare();
		$this->setSearchByTitleOptions();
		if ($title) {
			$base->addChild('titoloCerca', '');
			$base->titoloCerca->addChild('stringaCerca', '');
			switch($op) {
				case SBNTypes::SEARCHOP_LIKE:
					$base->titoloCerca->stringaCerca->addChild('stringaLike', $title);
					break;
				case SBNTypes::SEARCHOP_EQUAL:
				default:
					$base->titoloCerca->stringaCerca->addChild('stringaEsatta', $title);
					break;
			}
		}
		return $this->request();
	}

	/**
	 * Search records by their Standard Number.
	 *
	 * @param string $std_num The standard number to search for.
	 * @param string $std_num_type The standard number type (defaults to 010)
	 * @return SBNMarc
	 */
	public function searchTitleByStdNum($std_num, $std_num_type = SBNTypes::STDNUM_ISBN)
	{
		$std_num = htmlspecialchars($std_num, ENT_NOQUOTES, 'UTF-8', false);
		$base = $this->commonSearchTitlePrepare();
		$this->setSearchByTitleOptions();
		$base->addChild('NumSTD');
		$base->NumSTD->addChild('tipoSTD', $std_num_type);
		$base->NumSTD->addChild('numeroSTD', $std_num);
		return $this->request();
	}

	/**
	 * Search records linked to a SBN ID.
	 *
	 * @param $linked_id
	 * @param string $linked_class
	 * @param string $linked_type
	 * @return SBNMarc
	 */
	public function searchTitleByLinkedId($linked_id, $linked_class = SBNTypes::OBJCLASS_AUT, $linked_type = SBNTypes::AUTTYPE_AUTORE)
	{
		$base = $this->sbnMarc->SbnMessage->SbnRequest->addChild('Cerca');
		$this->setSearchOptions();
		$base->addChild('CercaTitolo')->addChild('ArrivoLegame');
		switch ($linked_class) {
			case SBNTypes::OBJCLASS_DOC:
				break;
			case SBNTypes::OBJCLASS_AUT:
				$base->CercaTitolo->ArrivoLegame->addChild('LegameElementoAut');
				$base->CercaTitolo->ArrivoLegame->LegameElementoAut->addAttribute('tipoAuthority',$linked_type);
				$base->CercaTitolo->ArrivoLegame->LegameElementoAut->addAttribute('tipoLegame','tutti');
				$base->CercaTitolo->ArrivoLegame->LegameElementoAut->addChild('idArrivo',$linked_id);
				break;
		}
		return $this->request();
	}

	/**
	 * Search Authority by BID
	 *
	 * @param string $bid The bid to search for.
	 * @param string $authorityType The authority type (defaults to SBNTypes::AUTTYPE_AUTORE)
	 * @return SBNMarc
	 */
	public function searchAuthorityByBid($bid, $authorityType = SBNTypes::AUTTYPE_AUTORE) {
		// with search by bid, always return analytical
		// NB: this HAS to be set *before* commonSearchAutPrepare() call.
		$this->searchOptions['tipoOutput'] = SBNTypes::OUTPUT_COMPLETE;
		$base = $this->commonSearchAutPrepare();
		$base->addChild('tipoAuthority', $authorityType);
		$base->addChild('canaliCercaDatiAut')->addChild('T001', $bid);
		$ret = $this->request();
		if ('0000' == $ret->SbnMessage->SbnResponse->SbnResult->esito
				&& isset($ret->SbnMessage->SbnResponse->SbnOutput->ElementoAut->DatiElementoAut->T001)
				&& $ret->SbnMessage->SbnResponse->SbnOutput->ElementoAut->DatiElementoAut->T001 != $bid) {
			$variant = $ret->xpath("//LegamiElementoAut/ArrivoLegame/LegameElementoAut[idArrivo = \"{$bid}\"]");
			if (count($variant) == 1) {
				$parent_bid = (string)$ret->SbnMessage->SbnResponse->SbnOutput->ElementoAut->DatiElementoAut->T001;
				$parent_type = (string)$ret->SbnMessage->SbnResponse->SbnOutput->ElementoAut->DatiElementoAut['tipoAuthority'];
				$variant = clone $variant[0];
				$ret->SbnMessage->SbnResponse->SbnOutput->ElementoAut->remove();
				$ret->SbnMessage->SbnResponse->SbnOutput->addChild('ElementoAut');
				$ret->SbnMessage->SbnResponse->SbnOutput->ElementoAut->appendNode($variant->ElementoAutLegato->DatiElementoAut);
				$ret->SbnMessage->SbnResponse->SbnOutput->ElementoAut->addChild('LegamiElementoAut')
					->addChild('ArrivoLegame')->addChild('LegameElementoAut')->addChild('idArrivo',$parent_bid);
				$ret->SbnMessage->SbnResponse->SbnOutput->ElementoAut->LegamiElementoAut->ArrivoLegame
					->LegameElementoAut->addAttribute('tipoAuthority',$parent_type);
				$ret->SbnMessage->SbnResponse->SbnOutput->ElementoAut->LegamiElementoAut->ArrivoLegame
					->LegameElementoAut->addAttribute('tipoLegame',(string)$variant['tipoLegame']);
			}
		}
		return $ret;
	}

	/**
	 * @param $search
	 * @return SBNMarc
	 */
	public function searchAuthorityByIsadn($search) {
		return $this->searchAuthority($search,SBNTypes::SEARCHOP_ISADN);
	}

	/**
	 * @param $search
	 * @return SBNMarc
	 */
	public function searchAuthorityEqual($search) {
		return $this->searchAuthority($search,SBNTypes::SEARCHOP_EQUAL);
	}

	/**
	 * @param $search
	 * @return SBNMarc
	 */
	public function searchAuthorityLike($search) {
		return $this->searchAuthority($search,SBNTypes::SEARCHOP_LIKE);
	}

	/**
	 * Search Authority by string.
	 *
	 * @param string $search
	 * @param string $searchType SBNTYpes::SEARCHOP_*
	 * @return SBNMarc
	 */
	public function searchAuthority($search, $searchType = SBNTypes::SEARCHOP_LIKE)
	{
		$search = htmlspecialchars($search, ENT_NOQUOTES, 'UTF-8', false);
		$base = $this->commonSearchAutPrepare();
		$this->setSearchByAutOptions();
		if (!is_null($search))
			$this->prepareSearchAuthorityChannel($base->addChild('canaliCercaDatiAut'),
				$search,$searchType);
		return $this->request();
	}

	/**
	 * Search Printers Device by string.
	 *
	 * @param string|array $search
	 * @return SBNMarc
	 */
	public function searchPrintersDevice($search)
	{
		$base = $this->commonSearchAutPrepare();
		$this->setSearchByAutOptions();
		if (is_array($search))
			foreach ($search as $word)
				$base->addChild('b_921',$word);
		else if (is_string($search))
			$base->addChild('b_921',$search);
		return $this->request();
	}

    /**
     * Search Localization Status
     *
     * @param string|array $search
     * @return SBNMarc
     */
    public function searchLocalizationStatus($search)
    {
        $base = $this->sbnMarc->SbnMessage->SbnRequest;

        $base->addChild('Cerca');
        $this->setSearchOptions();

        $base->Cerca->addChild("CercaLocalizzaInfo");
        $base->Cerca->CercaLocalizzaInfo['tipoInfo'] = $search['tipoInfo'];
        $base->Cerca->CercaLocalizzaInfo['tipoOperazione'] = $search['tipoOperazione'];

        $base->Cerca->CercaLocalizzaInfo->addChild("SbnIDLoc");
        $base->Cerca->CercaLocalizzaInfo->SbnIDLoc = $search['BID'];

        $base->Cerca->CercaLocalizzaInfo->addChild("tipoOggetto");

        if($search['tipoOggetto'] == "Materiale") {
            $base->Cerca->CercaLocalizzaInfo->tipoOggetto->addChild("tipoMateriale");
            $base->Cerca->CercaLocalizzaInfo->tipoOggetto->tipoMateriale = $search['Oggetto'];

        } else if($search['tipoOggetto'] == "Authority") {
            $base->Cerca->CercaLocalizzaInfo->tipoOggetto->addChild("tipoAuthority");
            $base->Cerca->CercaLocalizzaInfo->tipoOggetto->tipoAuthority = $search['Oggetto'];
        }


        return $this->request();
    }


	/**
	 * Search among edit proposals.
	 *
	 * @param string $proposalId The ID of the proposal
	 * @param array $objTypes An array of types to limit search within, as an hash of $type => $class elements, where
	 * 						$type is either SBNTypes::DOCTYPE_* or SBNTypes::AUTTYPE_* and $class is SBNTypes::OBJCLASS_*
	 * @param string $bid The proposal object's BID
	 * @param string $proposalStatus The proposal status (see SBNTypes::PROPOSAL_STATUS_*)
	 * @param string $dateFrom The date range to limit search from in yyyy-mm-dd format. Ignored if $dateTo is null.
	 * @param string $dateTo The date range to limit search to in yyyy-mm-dd format. Ignored if $dateFrom is null.
	 * @param string $proposerLibrary The library code of the proposer library
	 * @param string $proposalReceiver The library code of the receiver library.
	 * @return SBNMarc
	 */
	public function searchEditProposal($proposalId=null, $objTypes=array(), $bid=null,
									   $proposalStatus=null, $dateFrom=null, $dateTo=null,
									   $proposerLibrary=null, $proposalReceiver=null)
	{
		$this->sbnMarc->SbnMessage->SbnRequest->addChild('Cerca', '');
		$this->setSearchOptions();
		$base = $this->sbnMarc->SbnMessage->SbnRequest->Cerca->addChild('CercaPropostaCorrezione');
		if ($proposalId)
			$base->addChild('idProposta', $proposalId);
		if (!empty($objTypes))
			foreach ($objTypes as $type => $class)
				switch ($class) {
					case SBNTypes::OBJCLASS_DOC:
						$base->addChild('tipoOggetto')->addChild('tipoMateriale',$type);
						break;
					case SBNTypes::OBJCLASS_AUT:
						$base->addChild('tipoOggetto')->addChild('tipoAuthority',$type);
						break;
					default:
						break;
				}

		if ($bid)
			$base->addChild('idOggetto',$bid);
		if ($proposalStatus)
			$base->addChild('statoProposta',$proposalStatus);
		if ($bid)
			$base->addChild('idOggetto',$bid);
		if ($dateFrom && $dateTo) {
			$base->addChild('rangeDate');
			$base->rangeDate->addAttribute('tipoFiltroDate',1);
			$base->rangeDate->addChild('dataDa',$dateFrom);
			$base->rangeDate->addChild('dataA',$dateTo);
		}
		if ($proposerLibrary)
			$base->addChild('mittenteProposta')->addChild('Biblioteca',$proposerLibrary);
		if ($proposalReceiver)
			$base->addChild('destinatarioProposta')->addChild('Biblioteca',$proposalReceiver);

		return $this->request();
	}

	/**
	 * Gets all the updates for the node.
	 *
	 * @param string $objClass Wheter to retrieve updates for docs or authorities.
	 * @param string $objType The type for the doc/auth.
	 * @param string $date_from The start date in yyyy-mm-dd format.
	 * @param null $date_end The end date in yyyy-mm-dd format.
	 * @param null $library The library for which retrieve updates.
	 * @return SBNMarc
	 */
	public function getUpdates($objClass=SBNTypes::OBJCLASS_DOC,$objType=SBNTypes::DOCTYPE_TUTTI,
							   $date_from=null, $date_end=null, $library=null, $titFilter = null)
	{
		$base = $this->sbnMarc->SbnMessage->SbnRequest->addChild('ChiediAllinea');
		switch ($objClass) {
			case SBNTypes::OBJCLASS_DOC:
				$base->addChild('tipoOggetto')->addChild('tipoMateriale',$objType);
				break;
			case SBNTypes::OBJCLASS_AUT:
				$base->addChild('tipoOggetto')->addChild('tipoAuthority',$objType);
				break;
		}
		if ($date_from)
			$base->addChild('dataInizio', $date_from);
		if ($date_end)
			$base->addChild('dataFine', $date_end);
		if ($library)
			$base->addChild('biblioteca', $library);

        if($titFilter)
        {
            $filter = $base->addChild("FiltraAllineaTit");
            if(isset($titFilter['naturaSBN']))
                $filter->addChild("naturaSbn",$titFilter['naturaSBN']);
        }

//		$base->addAttribute('tipoOutput', SBNTypes::OUTPUT_COMPLETE);
		$base->addAttribute('tipoOutput', $this->searchOptions['tipoOutput']);
//		$base->addAttribute('tipoInfo', SBNTypes::LOCTYPE_MANAGE);
		return $this->request();
	}

	/**
	 *
	 * @param $updates
	 * @return SBNMarc
	 * @throws Exception If more than 5 updates are passed.
	 */
	public function sendUpdated($updates)
	{
		if (count($updates) > 5)
			throw new Exception('Cannot send more than 5 updates in a single request.');
		$base = $this->sbnMarc->SbnMessage->SbnRequest->addChild('ComunicaAllineati');
		for ($i = 0; $i < count($updates); $i++) {
			$objdata = $base->addChild('allineati');
			switch ($updates[$i]['objClass']) {
				case SBNTypes::OBJCLASS_DOC:
					$objdata->addChild('tipoOggetto')->addChild('tipoMateriale',$updates[$i]['objType']);
					break;
				case SBNTypes::OBJCLASS_AUT:
					$objdata->addChild('tipoOggetto')->addChild('tipoAuthority',$updates[$i]['objType']);
					break;
			}
			$objdata->addChild('idAllineato', $updates[$i]['bid']);
			$objdata->addChild('biblioteca', $this->_library);
			if (isset($updates[$i]['biblioteca'])) {
				foreach ($updates[$i]['biblioteca'] as $key => $biblio) {
					$objdata->addChild('biblioteca', $biblio[$key]);
				}
			}
		}
		return $this->request();
	}

	/**
	 * Localize a bunch of elements.
	 *
	 * @param array $elements An hash of ('bid' => string,'class' => string ,'type' => string,
	 * 						'items' => array(899_element))
	 * @param string $locAction
	 * @param string $locType
	 * @return SBNMarc
	 */
	public function localize(Array $elements,$locAction=SBNTypes::LOCACTION_LOCALIZE,$locType=SBNTypes::LOCTYPE_ALL)
	{
		unset($this->sbnMarc->SbnMessage->SbnRequest->Localizza);
		$base = $this->sbnMarc->SbnMessage->SbnRequest->addChild('Localizza', '');

		foreach ($elements as $element)
		{
			$linfo = $base->addChild('LocalizzaInfo', '');
			$linfo->addAttribute('tipoOperazione', $locAction);
			$linfo->addAttribute('tipoInfo', $locType);
			$linfo->addChild('SbnIDLoc', $element['bid']);
			switch ($element['class']) {
				case SBNTypes::OBJCLASS_DOC:
					$linfo->addChild('tipoOggetto')->addChild('tipoMateriale',
						isset($element['type']) ? $element['type'] : SBNTypes::DOCTYPE_MODERNO);
					break;

				case SBNTypes::OBJCLASS_AUT:
					$linfo->addChild('tipoOggetto')->addChild('tipoAuthority',
						isset($element['type']) ? $element['type'] : SBNTypes::AUTTYPE_AUTORE);
					break;
			}
			if (isset($element['items']) && count($element['items']))
				$this->buildRequestFor899($linfo, $element['items']);
		}
		return $this->request();
	}

	/**
	 * Creates a document/authority in SBN catalog.
	 *
	 * @param string $control
	 * @param string $objClass
	 * @param SimpleXMLElement $sbnmarc
	 * @param $bid
	 * @param bool $localize
	 * @return SBNMarc
	 */
	public function create($control=SBNTypes::CREATECONTROL_CHECK, $objClass=SBNTypes::OBJCLASS_DOC, SimpleXMLElement $sbnmarc,
						   $bid, $localize=false)
	{
		$this->sbnMarc->SbnMessage->SbnRequest->addChild('Crea')->addAttribute('tipoControllo',$control);
		switch ($objClass) {
			case SBNTypes::OBJCLASS_DOC:
				$this->sbnMarc->SbnMessage->SbnRequest->Crea->appendNode($sbnmarc);
				// inject BID
				if (isset($this->sbnMarc->SbnMessage->SbnRequest->Crea->Documento->DatiDocumento->T001))
					$this->sbnMarc->SbnMessage->SbnRequest->Crea->Documento->DatiDocumento->T001 = $bid;
				else
					$this->sbnMarc->SbnMessage->SbnRequest->Crea->Documento->DatiDocumento->addChild('T001',$bid);
				if (isset($this->sbnMarc->SbnMessage->SbnRequest->Crea->Documento->LegamiDocumento))
					$this->sbnMarc->SbnMessage->SbnRequest->Crea->Documento->LegamiDocumento->addChild('idPartenza',$bid);
				break;
			case SBNTypes::OBJCLASS_AUT:
				$this->sbnMarc->SbnMessage->SbnRequest->Crea->appendNode($sbnmarc);
				// inject BID
				if (isset($this->sbnMarc->SbnMessage->SbnRequest->Crea->Documento->DatiDocumento->T001))
					$this->sbnMarc->SbnMessage->SbnRequest->Crea->ElementoAut->DatiElementoAut->T001 = $bid;
				else
					$this->sbnMarc->SbnMessage->SbnRequest->Crea->ElementoAut->DatiElementoAut->addChild('T001',$bid);
				if (isset($this->sbnMarc->SbnMessage->SbnRequest->Crea->ElementoAut->LegamiElementoAut))
					$this->sbnMarc->SbnMessage->SbnRequest->Crea->ElementoAut->LegamiElementoAut->addChild('idPartenza',$bid);
				break;
		}
		if ($localize) {
			$linfo = $this->sbnMarc->SbnMessage->SbnRequest->Crea->addChild('Localizza')->addChild('LocalizzaInfo');
			$linfo->addAttribute('tipoOperazione', SBNTypes::LOCACTION_LOCALIZE);
			$linfo->addAttribute('tipoInfo', SBNTypes::LOCTYPE_MANAGE);
			$linfo->addChild('SbnIDLoc', $bid);
			switch ($objClass) {
				case SBNTypes::OBJCLASS_DOC:
					$linfo->addChild('tipoOggetto')->addChild('tipoMateriale',
						$this->sbnMarc->SbnMessage->SbnRequest->Crea->Documento->DatiDocumento['tipoMateriale']);
					break;
				case SBNTypes::OBJCLASS_AUT:
					$linfo->addChild('tipoOggetto')->addChild('tipoAuthority',
						$this->sbnMarc->SbnMessage->SbnRequest->Crea->ElementoAut->DatiElementoAut['tipoMateriale']);
					break;
			}
		}
		return $this->request();
	}

	/**
	 * Updates a document/authority in SBN catalog.
	 *
	 * @param string $control
	 * @param SimpleXMLElement $sbnmarc
	 * @param bool $dummy
	 * @return SBNMarc
	 */
	public function update($control=SBNTypes::CREATECONTROL_CHECK, SimpleXMLElement $sbnmarc, $dummy=false)
	{
		$this->sbnMarc->SbnMessage->SbnRequest->addChild('Modifica')->addAttribute('tipoControllo',$control);
		$this->sbnMarc->SbnMessage->SbnRequest->Modifica->appendNode($sbnmarc);
		if (isset($this->sbnMarc->SbnMessage->SbnRequest->Modifica->Documento)) {
			$this->sbnMarc->SbnMessage->SbnRequest->Modifica->Documento->addAttribute('statoRecord','c');
			if (isset($this->sbnMarc->SbnMessage->SbnRequest->Modifica->Documento->LegamiDocumento))
				unset($this->sbnMarc->SbnMessage->SbnRequest->Modifica->Documento->LegamiDocumento);
		} else if (isset($this->sbnMarc->SbnMessage->SbnRequest->Modifica->ElementoAut)) {
			$this->sbnMarc->SbnMessage->SbnRequest->Modifica->ElementoAut->DatiElementoAut->addAttribute('statoRecord','c');
		}
		if ($dummy)
			return $this->sbnMarc;
		return $this->request();
	}

	/**
	 * Removes a document/authority from SBN catalog.
	 *
	 * @param string $bid The BID of the object to be removed
	 * @param string $objClass Object class, either SBNTypes::OBJCLASS_DOC or SBNTypes::OBJCLASS_AUT
	 * @param string $objType Object type, either SBNTypes::DOCTYPE_* or SBNTypes::AUTTYPE_*
	 * @return SBNMarc
	 */
	public function delete($bid, $objClass=SBNTypes::OBJCLASS_DOC,$objType=SBNTypes::DOCTYPE_MODERNO)
	{
		$base = $this->sbnMarc->SbnMessage->SbnRequest->addChild('Cancella');
		switch ($objClass) {
			case SBNTypes::OBJCLASS_DOC:
				$base->addChild('tipoOggetto')->addChild('tipoMateriale', $objType);
				break;
			case SBNTypes::OBJCLASS_AUT:
				$base->addChild('tipoOggetto')->addChild('tipoAuthority', $objType);
				break;
		}
		$base->addChild('idCancella', $bid);

		return $this->request();
	}

	/**
	 * Merges.
	 *
	 * @param string $sourceBid The source BID
	 * @param string $targetBid The target BID
	 * @param string $objClass Object class, either SBNTypes::OBJCLASS_DOC or SBNTypes::OBJCLASS_AUT
	 * @param string $objType Object type, either SBNTypes::DOCTYPE_* or SBNTypes::AUTTYPE_*
	 * @param array $moveBid
	 * @return SBNMarc
	 */
	public function merge($sourceBid, $targetBid, $objClass=SBNTypes::OBJCLASS_DOC,$objType=SBNTypes::DOCTYPE_MODERNO,$moveBid=array())
	{
		$base = $this->sbnMarc->SbnMessage->SbnRequest->addChild('Fonde');
		switch ($objClass) {
			case SBNTypes::OBJCLASS_DOC:
				$base->addChild('tipoOggetto')->addChild('tipoMateriale', $objType);
				break;
			case SBNTypes::OBJCLASS_AUT:
				$base->addChild('tipoOggetto')->addChild('tipoAuthority', $objType);
				break;
		}
		$base->addChild('idPartenza', $sourceBid);
		$base->addChild('idArrivo', $targetBid);
		foreach ($moveBid as $id)
			$base->addChild('spostaID', trim($id));

		return $this->request();
	}

	/**
	 * Variantizes an authority.
	 *
	 * @param string $sourceBid The source BID
	 * @param string $targetBid The target BID
	 * @return SBNMarc
	 */
	/*public function variantize($sourceBid, $targetBid)
	{
		$base = $this->sbnMarc->SbnMessage->SbnRequest->addChild('Modifica')->addChild('ElementoAut');
		$base->addChild('DatiElementoAut');
		$base->DatiElementoAut->addAttribute
		if (isset($this->sbnMarc->SbnMessage->SbnRequest->Modifica->Documento))
			$this->sbnMarc->SbnMessage->SbnRequest->Modifica->Documento->LegamiDocumento->addAttribute('tipoOperazione',$action);
		else if (isset($this->sbnMarc->SbnMessage->SbnRequest->Modifica->ElementoAut))
			$this->sbnMarc->SbnMessage->SbnRequest->Modifica->ElementoAut->LegamiElementoAut->addAttribute('tipoOperazione',$action);
		if ($dummy)
			return $this->sbnMarc;
		return $this->request();

		$workSbnMarc->addChild('LegamiElementoAut')->addChild('idPartenza',$targetBid);
		$sbnLink = $workSbnMarc->LegamiElementoAut->addChild('ArrivoLegame')->addChild('LegameElementoAut');
		$sbnLink->addAttribute('tipoAuthority',$sbnType);
		$sbnLink->addAttribute('tipoLegame','USE');
		$sbnLink->addChild('idArrivo',$sourceAuthority->getBid());


		$base = $this->sbnMarc->SbnMessage->SbnRequest->addChild('Fonde');
		switch ($objClass) {
			case SBNTypes::OBJCLASS_DOC:
				$base->addChild('tipoOggetto')->addChild('tipoMateriale', $objType);
				break;
			case SBNTypes::OBJCLASS_AUT:
				$base->addChild('tipoOggetto')->addChild('tipoAuthority', $objType);
				break;
		}
		$base->addChild('idPartenza', $sourceBid);
		$base->addChild('idArrivo', $targetBid);
		foreach ($moveBid as $id)
			$base->addChild('spostaID', trim($id));

		return $this->request();
	}*/

	/**
	 * Delete a document or an authority in index.
	 *
	 * @param string $bid The BID to be deleted.
	 * @param string $objClass Object class, either SBNTypes::OBJCLASS_DOC or SBNTypes::OBJCLASS_AUT
	 * @param string $objType Object type, either SBNTypes::DOCTYPE_* or SBNTypes::AUTTYPE_*
	 * @return SBNMarc
	 */
	public function remove($bid, $objClass=SBNTypes::OBJCLASS_DOC,$objType=SBNTypes::DOCTYPE_MODERNO)
	{
		$base = $this->sbnMarc->SbnMessage->SbnRequest->addChild('Cancella');
		switch ($objClass) {
			case SBNTypes::OBJCLASS_DOC:
				$base->addChild('tipoOggetto')->addChild('tipoMateriale', $objType);
				break;
			case SBNTypes::OBJCLASS_AUT:
				$base->addChild('tipoOggetto')->addChild('tipoAuthority', $objType);
				break;
		}
		$base->addChild('idCancella', $bid);
		return $this->request();
	}

	/**
	 * Updates a document/authority link in SBN catalog.
	 *
	 * @param string $action
	 * @param SimpleXMLElement $sbnmarc
	 * @param bool $dummy
	 * @return SBNMarc
	 */
	public function updateLink($action=SBNTypes::LINKACTION_CREATE, SimpleXMLElement $sbnmarc, $dummy=false)
	{
		$this->sbnMarc->SbnMessage->SbnRequest->addChild('Modifica')->appendNode($sbnmarc);
		if (isset($this->sbnMarc->SbnMessage->SbnRequest->Modifica->Documento))
			$this->sbnMarc->SbnMessage->SbnRequest->Modifica->Documento->LegamiDocumento->addAttribute('tipoOperazione',$action);
		else if (isset($this->sbnMarc->SbnMessage->SbnRequest->Modifica->ElementoAut))
			$this->sbnMarc->SbnMessage->SbnRequest->Modifica->ElementoAut->LegamiElementoAut->addAttribute('tipoOperazione',$action);
		if ($dummy)
			return $this->sbnMarc;
		return $this->request();
	}

	public function addLinkedAutSearchFilter($objType=SBNTypes::AUTTYPE_AUTORE)
	{
		$filter = array();
		$filter['tipoAuthority'] = $objType;
		$filter['canaliCercaDatiAut'];
	}

	/**
	 * @param $bid
	 * @return array
	 */
	public function getPrintersDeviceImages($bid) {
		$ret = $this->searchAuthorityByBid($bid,SBNTypes::AUTTYPE_MARCA);
		if ('0000' == $ret->SbnMessage->SbnResponse->SbnResult->esito
				&& isset($ret->SbnMessage->SbnResponse->SbnOutput->ElementoAut->DatiElementoAut->T856)) {
			$images = array();
			foreach ($ret->SbnMessage->SbnResponse->SbnOutput->ElementoAut->DatiElementoAut->T856 as $f856) {
				$images[(string)$f856->u_856] = (string)$f856->c9_856_1;
			}
			return $images;
		}
		return array();
	}

	/**
	 *
	 * @return SBNMarc
	 */
	private function commonSearchTitlePrepare()
	{
		$base = $this->sbnMarc->SbnMessage->SbnRequest->addChild('Cerca');
		$this->setSearchOptions();
		$base->addChild('CercaTitolo');
		$base->CercaTitolo->addChild('CercaDatiTit');
		return $base->CercaTitolo->CercaDatiTit;
	}

	/**
	 *
	 * @return SBNMarc
	 */
	private function commonSearchAutPrepare()
	{
		$base = $this->sbnMarc->SbnMessage->SbnRequest->addChild('Cerca');
		$this->setSearchOptions();
		$base->addChild('CercaElementoAut');
		$base->CercaElementoAut->addChild('CercaDatiAut');
		return $base->CercaElementoAut->CercaDatiAut;
	}

	private function setSearchOptions()
	{
		if (!isset($this->sbnMarc->SbnMessage->SbnRequest->Cerca))
			throw new Exception('Cannot set search options on a non-search request');
		foreach ($this->searchOptions as $k => $v)
			if ($v)	$this->sbnMarc->SbnMessage->SbnRequest->Cerca->addAttribute($k, $v);
	}

	private function prepareSearchAuthorityChannel(SimpleXMLElement $baseXml,$searchValue,$searchType=SBNTypes::SEARCHOP_LIKE)
	{
		switch ($searchType) {
			case SBNTypes::SEARCHOP_BID:
				$ret = $baseXml->addChild('T001', $searchValue);
				break;
			// ISADN solo autori titoli
			case SBNTypes::SEARCHOP_ISADN:
				$ret = $baseXml->addChild('T015')->addChild('a_015', $searchValue);
				break;
			// ricerca per stringa
			case SBNTypes::SEARCHOP_LIKE:
				$ret = $baseXml->addChild('stringaCerca')->addChild('stringaLike', $searchValue);
				break;
			case SBNTypes::SEARCHOP_EQUAL:
				$ret = $baseXml->addChild('stringaCerca')->addChild('stringaEsatta', $searchValue);
				break;
		}
		return $ret;
	}

	private function setSearchByTitleOptions()
	{
		$base = $this->sbnMarc->SbnMessage->SbnRequest->Cerca->CercaTitolo->CercaDatiTit;
		/*if (!isset($this->searchTitleOptions['naturaSbn']) && !isset($this->searchTitleOptions['tipoMateriale']))
			$this->searchTitleOptions['naturaSbn'] = array(
				SBNTypes::NATURE_MONOGRAFIA,
				SBNTypes::NATURE_SERIALI,
				SBNTypes::NATURE_COLLEZIONE,
				SBNTypes::NATURE_TITOLO_ANALITICO);*/
		foreach ($this->searchTitleOptions as $k => $v)
			switch ($k) {
				case 'guida':
					foreach ($v as $guida) {
						$base->addChild('guida');
						if ($guida['tipoRecord'])
							$base->guida->addAttribute('tipoRecord', $guida['tipoRecord']);
						if ($guida['livelloBibliografico'])
							$base->guida->addAttribute('livelloBibliografico', $guida['livelloBibliografico']);
					}
					break;

				case 'T005_Range':
					$dataDa = array_key_exists('dataDa', $v) ? $v['dataDa'] : '';
					$dataA = array_key_exists('dataA', $v) ? $v['dataA'] : '';
					$base->addChild('T005_Range')->addAttribute('tipofiltroDate', '');
					if ($dataDa)
						$base->T005_Range->addChild('dataDa', $dataDa);
					if ($dataA)
						$base->T005_Range->addChild('dataA', $dataA);
					break;

				case 'elementoAutLegato':
					$base->addChild('ElementoAutLegato');
					if (array_key_exists('tipoAuthority', $v))
						$base->ElementoAutLegato->addChild('tipoAuthority', $v['tipoAuthority']);
					if (array_key_exists('canaliCercaDatiAut', $v)) {
						$base->ElementoAutLegato->addChild('canaliCercaDatiAut');
						$this->prepareSearchAuthorityChannel($base->ElementoAutLegato->canaliCercaDatiAut,
							$v['canaliCercaDatiAut']['searchValue'],$v['canaliCercaDatiAut']['searchType']);
					}
					if (array_key_exists('searchAutKeyCAUT', $v))
						$base->ElementoAutLegato->addChild('chiaviAutoreCerca')->addChild('autoreCAUT',$v['searchAutKeyCAUT']);
					if (array_key_exists('searchAutKeyAUTEUR', $v))
						$base->ElementoAutLegato->addChild('chiaviAutoreCerca')->addChild('autoreAUTEUR',$v['searchAutKeyAUTEUR']);
					if (array_key_exists('searchAutKeyEL1', $v))
						$base->ElementoAutLegato->addChild('chiaviAutoreCerca')->addChild('autoreEL1',$v['searchAutKeyEL1']);
					if (array_key_exists('searchAutKeyEL2', $v))
						$base->ElementoAutLegato->addChild('chiaviAutoreCerca')->addChild('autoreEL2',$v['searchAutKeyEL2']);
					if (array_key_exists('relatorCode', $v))
						$base->ElementoAutLegato->addChild('relatorCode', $v['relatorCode']);
					if (array_key_exists('tipoRespons', $v))
						$base->ElementoAutLegato->addChild('tipoRespons', $v['tipoRespons']);
					break;

				case 'T100_Da':
				case 'T100_A':
				case 'T101':
				case 'T102':
				case 'T105':
				case 'T012':	// DocAntico
				case 'T140':	// DocAntico
				case 'T120':	// DocCartografico
				case 'T123':	// DocCartografico
				case 'T116':	// DocGrafico
					$base->addChild($k);

					foreach ($v as $sf => $vsf)
						if ('id1' == $sf || 'id2' == $sf)
							$base->$k->addAttribute($sf, $vsf);
						else if (is_array($vsf))
							foreach ($vsf as $asf => $avsf)
								$base->$k->addChild($asf, $avsf);
						else
							$base->$k->addChild($sf, $vsf);
					break;


				case 'tipoMateriale':
					if (!is_array($v))
						switch ($v) {
							case SBNTypes::DOCTYPE_ANTICO:
								$base->addAttribute('xsi:type', 'CercaDocAnticoType', 'http://www.w3.org/2001/XMLSchema-instance');
								break;
							case SBNTypes::DOCTYPE_CARTOGRAFICO:
								$base->addAttribute('xsi:type', 'CercaDocCartograficoType', 'http://www.w3.org/2001/XMLSchema-instance');
								break;
							case SBNTypes::DOCTYPE_GRAFICO:
								$base->addAttribute('xsi:type', 'CercaDocGraficaType', 'http://www.w3.org/2001/XMLSchema-instance');
								break;
							case SBNTypes::DOCTYPE_MUSICA:
								$base->addAttribute('xsi:type', 'CercaDocMusicaType', 'http://www.w3.org/2001/XMLSchema-instance');
								break;
							case SBNTypes::DOCTYPE_MODERNO:
							case SBNTypes::DOCTYPE_TUTTI:
							default:
								break;
						}
					// don't break (to still add child)
				case 'naturaSbn':
					if (!is_array($v))
						$v = array($v);
					foreach ($v as $j)
						$base->addChild($k, $j);
					break;

				case 'sottoTipoLegame':
				case 'livelloAut_Da':
				case 'livelloAut_A':
					$base->addChild($k, $v);
					break;

				default:
					break;
			}
	}

	private function setSearchByAutOptions()
	{
		$base = $this->sbnMarc->SbnMessage->SbnRequest->Cerca->CercaElementoAut->CercaDatiAut;
		foreach ($this->searchAutOptions as $k => $v)
			switch ($k) {
				case 'T005_Range':
					$dataDa = array_key_exists('dataDa', $v) ? $v['dataDa'] : '';
					$dataA = array_key_exists('dataDa', $v) ? $v['dataA'] : '';
					$base->addChild('T005_Range')->addAttribute('tipofiltroDate', '');
					if ($dataDa)
						$base->T005_Range->addChild('dataDa', $dataDa);
					if ($dataA)
						$base->T005_Range->addChild('dataA', $dataA);
					break;

				case 'tipoAuthority':
					switch ($v) {
						case SBNTypes::AUTTYPE_AUTORE:
							$base->addAttribute('xsi:type', 'CercaAutoreType', 'http://www.w3.org/2001/XMLSchema-instance');
							break;
						case SBNTypes::AUTTYPE_CLASSE:
						case SBNTypes::AUTTYPE_SOGGETTO:
						case SBNTypes::AUTTYPE_DESCRITTORE:
						case SBNTypes::AUTTYPE_REPERTORIO:
							$base->addAttribute('xsi:type', 'CercaSoggettoDescrittoreClassiReperType', 'http://www.w3.org/2001/XMLSchema-instance');
							break;
						case SBNTypes::AUTTYPE_MARCA:
							$base->addAttribute('xsi:type', 'CercaMarcaType', 'http://www.w3.org/2001/XMLSchema-instance');
							break;
						case SBNTypes::AUTTYPE_LUOGO:
							$base->addAttribute('xsi:type', 'CercaLuogoType', 'http://www.w3.org/2001/XMLSchema-instance');
							break;
						case SBNTypes::AUTTYPE_TITOLO_UNIFORME_MUSICA:
							$base->addAttribute('xsi:type', 'CercaTitoloUniformeMusicaType', 'http://www.w3.org/2001/XMLSchema-instance');
							break;
						case SBNTypes::AUTTYPE_TITOLO_UNIFORME:
						default:
							break;
					}
					// don't break (to still add child)
				case 'livelloAut_Da':
				case 'livelloAut_A':
				case 'formaNome':
				case 'relatorCode':
				default:
					$base->addChild($k, $v);
					break;
			}
	}

	/**
	 * Builds XML node for T899 elements
	 *
	 * @param SimpleXMLElement $locinfo The LocalizzaInfo node to append T899 subnodes
	 * @param array $item_list The array containing T899 elements
	 * @return SimpleXMLElement Updated LocalizzaInfo node
	 */
	private function buildRequestFor899(SimpleXMLElement $locinfo, Array $item_list)
	{
		foreach ($item_list as $T899) {
			if (count($T899)) {
				$T899node = $locinfo->addChild('T899', '');
				if (isset($T899['libName']) && $T899['libName'])
					$T899node->addChild('a_899', $T899['libName']);
				if (isset($T899['libAnagraphicCode']) && $T899['libAnagraphicCode'])
					$T899node->addChild('c1_899', $T899['libAnagraphicCode']);
				if (isset($T899['libSBNCode']) && $T899['libSBNCode'])
					$T899node->addChild('c2_899', $T899['libSBNCode']);
				if (isset($T899['musicObject']) && $T899['musicObject'])
					$T899node->addChild('b_899', $T899['musicObject']);
				if (isset($T899['consistency']) && $T899['consistency'])
					$T899node->addChild('z_899', $T899['consistency']);
				if (isset($T899['collocation']) && $T899['collocation'])
					$T899node->addChild('g_899', $T899['collocation']);
				if (isset($T899['collocationAntique']) && $T899['collocationAntique'])
					$T899node->addChild('s_899', $T899['collocationAntique']);
				if (isset($T899['notes']) && $T899['notes'])
					$T899node->addChild('n_899', $T899['notes']);
				if (isset($T899['electronicFormat']) && $T899['electronicFormat'])
					$T899node->addChild('e_899', $T899['electronicFormat']);
				if (isset($T899['mutilo']) && $T899['mutilo'])
					$T899node->addChild('q_899', $T899['mutilo']);
				if (isset($T899['uri']) && $T899['uri'])
					$T899node->addChild('u_899', $T899['uri']);
				if (isset($T899['digitalizationType']) && $T899['digitalizationType'])
					$T899node->addChild('t_899', $T899['digitalizationType']);
			}
		}
		return $locinfo;
	}
}

/**
 * SBNMarc class
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Modules.SBN
 * @since 2.5.1
 */
class SBNMarc extends SimpleXMLElement
{
	/**
	 * Delegate function to get a new SBNMarc.
	 *
	 * @return SBNMarc
	 */
	public static function create() {
		return new SBNMarc('
<SBNMarc schemaVersion="2.00"
		xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
		xsi:noNamespaceSchemaLocation="SBNMarcv200.xsd">
    <SbnUser>
    	<Biblioteca></Biblioteca>
    	<UserId></UserId>
    </SbnUser>
    <SbnMessage>
    </SbnMessage>
</SBNMarc>');
	}

	public function appendNode(SimpleXMLElement $simplexml) {
		$tmp = dom_import_simplexml($this);
		$new = $tmp->ownerDocument->importNode(dom_import_simplexml($simplexml), true);
		$node = $tmp->appendChild($new);
		return simplexml_import_dom($node, get_class($this));
	}

	/**
	 * Removes itself from DOM tree.
	 *
	 * @return DOMNode itself
	 */
	public function remove() {
		$dom = dom_import_simplexml($this);
		return $dom->parentNode->removeChild($dom);
	}
}

/**
 * SBNConverter class
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Modules.SBN
 * @since 2.5.1
 */
class SBNConverter {

	protected static function getStylesheet($nodes, $maxdepth=10)
	{
		if ($maxdepth < 0)
			return null;
		$children = array();
		foreach ($nodes as $node) {
			foreach ($node->children() as $child) {
				if ($child->getName() == 'ElementoAut' ||
						($child->getName() == 'Documento' && isset($child->DatiTitAccesso)))
					return '/SBN2TurbomarcAuthority.xsl';
				else if ($child->getName() == 'Documento')
					return '/SBN2Turbomarc.xsl';
				$children[] = $child;
			}
		}
		return self::getStylesheet($children, $maxdepth-1);
	}

	public static function SBN2Turbomarc(SBNMarc $sbn, $asXML=false)
	{
		$stylesheet = self::getStylesheet($sbn,10);
		if (!$stylesheet) {
            Prado::fatalError("SBN:\n" + Prado::varDump($sbn));
			throw new Exception('Oops, this should not happen!');
        }
		try {
			$xslt = new XSLTProcessor();
			@$xslt->importStylesheet(DOMDocument::load(dirname(__FILE__).$stylesheet));
			$dom = new DOMDocument();
			$domnode = $dom->importNode(dom_import_simplexml($sbn), true);
			$dom->appendChild($domnode);
			$tmXml = $xslt->transformToXml($dom);
			return ($asXML) ? $tmXml : new TurboMarc($tmXml);
		} catch (Exception $e) {
			throw new Exception('Exception occurred: '.$e->getMessage());
		}
	}

	public static function Turbomarc2SBN(TurboMarc $tm, $asXML=false)
	{
		$stylesheet = trim($tm->getLeader()->entitytype)
			? '/TurbomarcAuthority2SBN.xsl'
			: '/Turbomarc2SBN.xsl';
		try {
			$xslt = new XSLTProcessor();
			@$xslt->importStylesheet(DOMDocument::load(dirname(__FILE__).$stylesheet));
			$dom = new DOMDocument();
			$domnode = $dom->importNode(dom_import_simplexml($tm), true);
			$dom->appendChild($domnode);
			$sbnXml = $xslt->transformToXml($dom);
			return ($asXML) ? $sbnXml : simplexml_load_string($sbnXml,'SBNMarc');
		} catch (Exception $e) {
			throw new Exception('Exception occurred: '.$e->getMessage());
		}
	}

	public static function TurbomarcLink2SBN(TurboMarc $tm, $asXML=false)
	{
		$stylesheet = '/TurbomarcLink2SBN.xsl';
		try {
			$xslt = new XSLTProcessor();
			@$xslt->importStylesheet(DOMDocument::load(dirname(__FILE__).$stylesheet));
			$dom = new DOMDocument();
			$domnode = $dom->importNode(dom_import_simplexml($tm), true);
			$dom->appendChild($domnode);
			$sbnXml = $xslt->transformToXml($dom);
			return ($asXML) ? $sbnXml : simplexml_load_string($sbnXml,'SBNMarc');
		} catch (Exception $e) {
			throw new Exception('Exception occurred: '.$e->getMessage());
		}
	}

	public static function getTurbomarcSBNDiff(TurboMarc $localtm, TurboMarc $sbntm)
	{
		$skipFields = array('001','005','035','316','317','318','319');
		$proc = new XSLTProcessor();
		@$proc->importStylesheet(DOMDocument::load(dirname(__FILE__).'/SBNDiffCleaner.xsl'));
		$doc = dom_import_simplexml($localtm)->ownerDocument;
		$localtm = new TurboMarc($proc->transformToXML($doc));
		$doc = dom_import_simplexml($sbntm)->ownerDocument;
		$sbntm = new TurboMarc($proc->transformToXML($doc));
		if (isset($localtm->r))
			$localtm = $localtm->r;
		if (isset($sbntm->r))
			$sbntm = $sbntm->r;
		$ret = array();

		list($newtm,$diff) = TurboMarcUtility::diff($localtm,$sbntm,true,'ssbn');
		foreach ($diff as $field) {
			if (!in_array($field['fnum'],array('099','921','922','923','926','927','928','929','930','931'))	// whitelist (mainly for SBN)
					&& (strpos($field['fnum'],'9') !== false || in_array($field['fnum'],$skipFields))) {
				// skipped fields
				$tag = ($field['fnum'] < '010' ? 'c' : 'd').$field['fnum'];
				unset($newtm->$tag);
				continue;
			} else if (101 == $field['fnum']) {
				if (TurboMarcUtility::FIELDS_TM1ONLY == $field['status'] ||
						TurboMarcUtility::FIELDS_TM2ONLY == $field['status']) {
					// leave as it is
					$ret[] = $field;
				} else {
					// special handling for 101
					unset($newtm->d101);
					$tmpfld = simplexml_load_string('<d101/>','TurboMarc');
					foreach ($localtm->d101->children() as $sf)
						if ($sf->getTag() == 'a')
							$tmpfld->addSubField('a',(string)$sf);
					$tmpfld = $tmpfld->getFancyTxt(false);
					$notfound = true;
					foreach ($sbntm->xpath(".//d101") as $field2) {
						$sbnfld = $field2->getFancyTxt(false);
						if ($tmpfld == $sbnfld) {
							$field3 = simplexml_load_string($field2->asXML(),'TurboMarc');
							foreach($localtm->d101->children() as $sf)
								if ($sf->getTag() != 'a')
									$field3->addSubField($sf->getTag(),(string)$sf);
							$ret[] = array('fnum' => 101,
								'status' => TurboMarcUtility::FIELDS_EQUAL,
								'tm1fld' => $localtm->d101->getFancyTxt(false),
								'tm2fld' => $sbnfld,
								'mergefld' => $field3->getFancyTxt(false));
							$newtm->appendNode($field3);
							$notfound = false;
							break;
						}
					}
					if ($notfound) {
						$field3 = simplexml_load_string($field2->asXML(),'TurboMarc');
						foreach($localtm->d101->children() as $sf)
							if ($sf->getTag() != 'a')
								$field3->addSubField($sf->getTag(),(string)$sf);
						$ret[] = array('fnum' => 101,
							'status' => TurboMarcUtility::FIELDS_DIFF,
							'tm1fld' => $localtm->d101->getFancyTxt(false),
							'tm2fld' => $sbnfld,
							'mergefld' => $field3->getFancyTxt(false));
						$newtm->appendNode($field3);
					}
				}
			} else {
				if (200 == $field['fnum'] && isset($newtm->d099) && isset($newtm->d200) && 'W' == $newtm->d099->sc)
					$newtm->d200['i1'] = 0;
				// copy fields on our $ret
				$ret[] = $field;
			}
		}
		// process 901
		if (isset($sbntm->d901)) {
			unset($newtm->d901);
			$diff = false;
			$final901 = simplexml_load_string($localtm->d901->asXML(),'TurboMarc');
			if (isset($sbntm->d901->se) && (string)$sbntm->d901->se != (string)$localtm->d901->se) {
				$final901->se = (string)$sbntm->d901->se;
				$diff = true;
			}
            if (isset($sbntm->d901->sn) && (string)$sbntm->d901->sn != (string)$localtm->d901->sn) {
                $final901->sn = (string)$sbntm->d901->sn;
                $diff = true;
            }

			$ret[] = array('fnum' => 901,
				'status' => $diff ? TurboMarcUtility::FIELDS_DIFF : TurboMarcUtility::FIELDS_EQUAL,
				'tm1fld' => $localtm->d901->getFancyTxt(false),
				'tm2fld' => $sbntm->d901->getFancyTxt(false),
				'mergefld' => $final901->getFancyTxt(false));
			$newtm->appendNode($final901);
		}
		return array($newtm,$ret);
	}

	public static function ClavisType2SBNType($type) {
		switch ($type) {
			case 'a02':
			case 'b02':
				return SBNTypes::DOCTYPE_ANTICO;
			case 'e01':
			case 'f01':
				return SBNTypes::DOCTYPE_CARTOGRAFICO;
			case 'c01':
			case 'd01':
				return SBNTypes::DOCTYPE_MUSICA;
			case 'k01':
			case 'k02':
			case 'k03':
			case 'k04':
			case 'k05':
			case 'k06':
			case 'k07':
			case 'k08':
			case 'k09':
			case 'k10':
			case 'k11':
				return SBNTypes::DOCTYPE_GRAFICO;
			case AuthorityPeer::TYPE_CLASS:
				return SBNTypes::AUTTYPE_CLASSE;
			case AuthorityPeer::TYPE_PERSONALNAME:
			case AuthorityPeer::TYPE_CORPORATEBODYNAME:
			case AuthorityPeer::TYPE_FAMILYNAME:
				return SBNTypes::AUTTYPE_AUTORE;
			case AuthorityPeer::TYPE_PLACE:
			case AuthorityPeer::TYPE_PUBPLACE:
				return SBNTypes::AUTTYPE_LUOGO;
			case AuthorityPeer::TYPE_WORK:
				return SBNTypes::AUTTYPE_TITOLO_UNIFORME;
			case AuthorityPeer::TYPE_PRINTERSDEVICE:
				return SBNTypes::AUTTYPE_MARCA;
			case AuthorityPeer::TYPE_SUBJECT:
				return SBNTypes::AUTTYPE_SOGGETTO;
			case AuthorityPeer::TYPE_SERIE:
			case AuthorityPeer::TYPE_TRADEMARK:
			case AuthorityPeer::TYPE_ARGUMENT:
				return SBNTypes::AUTTYPE_DESCRITTORE;
			default:
				return SBNTypes::DOCTYPE_MODERNO;
		}
	}

	public static function SBNType2ClavisType($type) {
		switch ($type) {
			case SBNTypes::DOCTYPE_ANTICO:
				return 'a02';
			case SBNTypes::DOCTYPE_CARTOGRAFICO:
				return 'e01';
			case SBNTypes::DOCTYPE_MUSICA:
				return 'c01';
			case SBNTypes::DOCTYPE_GRAFICO:
				return 'k01';
			case SBNTypes::AUTTYPE_CLASSE:
				return AuthorityPeer::TYPE_CLASS;
			case SBNTypes::AUTTYPE_AUTORE:
				return AuthorityPeer::TYPE_PERSONALNAME;
			case SBNTypes::AUTTYPE_LUOGO:
				return AuthorityPeer::TYPE_PUBPLACE;
			case SBNTypes::AUTTYPE_TITOLO_UNIFORME:
			case SBNTypes::AUTTYPE_TITOLO_UNIFORME_MUSICA:
				return AuthorityPeer::TYPE_WORK;
			case SBNTypes::AUTTYPE_MARCA:
				return AuthorityPeer::TYPE_PRINTERSDEVICE;
			case SBNTypes::AUTTYPE_SOGGETTO:
				return AuthorityPeer::TYPE_SUBJECT;
			case SBNTypes::AUTTYPE_DESCRITTORE:
				return AuthorityPeer::TYPE_ARGUMENT;
			default:
				return SBNTypes::DOCTYPE_MODERNO;
		}
	}

	public static function ClavisType2SBNIdPrefix($type) {
		/* Identificativo SBN dell'oggetto - Ha lunghezza 10 ad eccezione delle classificazioni,
		 *  nel cui caso coincide con il 'D'+cod_edizione+simbolo per il sistema Dewey e cod_sistema+simbolo
		 *  per altri sistemi - Negli altri casi è composto come segue: titoli di tipo materiale antico:
		 *  codice polo+'E'+progressivo; titoli non antichi: codice polo+progressivo;
		 *  autori: codice polo+'V'+progressivo; luoghi:codice polo+'L'+progressivo;
		 *  marche: codice polo+'M'+progressivo; soggetti:codice polo+'C'+progressivo;
		 *  descrittori: codice polo+'D'+progressivo
		 */
		switch ($type) {
			case 'a02':
			case 'b02':
				return 'E';
			case AuthorityPeer::TYPE_CLASS:
				return 'D';
			case AuthorityPeer::TYPE_PERSONALNAME:
			case AuthorityPeer::TYPE_CORPORATEBODYNAME:
			case AuthorityPeer::TYPE_FAMILYNAME:
				return 'V';
			case AuthorityPeer::TYPE_PLACE:
			case AuthorityPeer::TYPE_PUBPLACE:
				return 'L';
			case AuthorityPeer::TYPE_PRINTERSDEVICE:
				return 'M';
			case AuthorityPeer::TYPE_SUBJECT:
				return 'C';
			case AuthorityPeer::TYPE_SERIE:
			case AuthorityPeer::TYPE_TRADEMARK:
			//case AuthorityPeer::TYPE_FORM:
			case AuthorityPeer::TYPE_CHRONOLOGICAL:
			case AuthorityPeer::TYPE_ARGUMENT:
				return 'D';
			default:
				return '';
		}
	}

	/**
	 * @param $timestamp
	 * @return DateTime
	 */
	public static function SBNTimestamp2DateTime($timestamp) {
		if (!$timestamp)	return '';
		return new DateTime(substr($timestamp,0,4).'-'.substr($timestamp,4,2).'-'.substr($timestamp,6,2).
				' '.substr($timestamp,8,2).':'.substr($timestamp,10,2).':'.substr($timestamp,12,2));
	}

	public static function DateTime2SBNTimestamp(DateTime $datetime) {
		if (!$datetime)	return '';
		return $datetime->format('Ymdhis.0');
	}

	public static function SBNTimestamp2Epoch($timestamp) {
		if (!$timestamp)	return '';
		return mktime(substr($timestamp,8,2),substr($timestamp,10,2),substr($timestamp,12,2),
			substr($timestamp,4,2),substr($timestamp,6,2),substr($timestamp,0,4));
	}

	public static function Epoch2SBNTimestamp($epoch) {
		return date('Ymdhis.0');
	}
}

/**
 * SBNTypes class
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Modules.SBN
 * @since 2.5.1
 */
class SBNTypes {

	// search operators
	const SEARCHOP_LIKE		= 'like';
	const SEARCHOP_EQUAL	= 'equal';
	const SEARCHOP_BID		= 'bid';
	const SEARCHOP_ISADN	= 'isadn';

	// search indicators
	const SEARCHIND_TRUE	= 'S';
	const SEARCHIND_FALSE	= 'N';

	// standard numbers
	const STDNUM_ISBN = '010'; // numero ISBN
	const STDNUM_ISSN = '011'; // ISSN International Standard Serial Number
	const STDNUM_ISMN = '013'; // ISMN International Standard Music NUmber
	const STDNUM_NBN = '020'; // NBN National Bibliography Number
	const STDNUM_GPN = '022'; // GPN Government Publication Number
	const STDNUM_L = 'L';
	const STDNUM_C = 'C';
	const STDNUM_D = 'D';
	const STDNUM_E = 'E';
	const STDNUM_ACNP = 'P'; // ACNP numero periodico
	const STDNUM_R = 'R';
	const STDNUM_S = 'S';
	const STDNUM_Y = 'Y';
	const STDNUM_RISM = 'X';

	// sort types
	const SORTTYPE_1 = '1'; //identificativo+stringa+data1
    const SORTTYPE_2 = '2'; //stringa+data1
    const SORTTYPE_3 = '3'; //autore resp.1+stringa+data1
    const SORTTYPE_4 = '4'; //sequenza
    const SORTTYPE_5 = '5';	//data1+stringa

	// output types
    const OUTPUT_COMPLETE		= '000';	//esame analitico
    const OUTPUT_SINTMAX		= '001';	//sintetica max
    const OUTPUT_SINTMIN		= '003';
	const OUTPUT_COMPLETELOC	= '004';	//analitica con info localizzazione

	const OBJCLASS_DOC	= 'M';	//materiale
	const OBJCLASS_AUT	= 'AU';	//authority

	const DOCTYPE_MODERNO	= 'M';	// moderno
	const DOCTYPE_ANTICO	= 'E';	// Antico
	const DOCTYPE_MUSICA	= 'U';	// Musica
	const DOCTYPE_GRAFICO	= 'G';	// Grafico
	const DOCTYPE_CARTOGRAFICO	= 'C';	// Cartografico
	const DOCTYPE_TUTTI		= ' ';

	const NATURE_MONOGRAFIA	= 'M';
	const NATURE_TITOLO_NON_SIGNIFICATIVO	= 'W';
	const NATURE_TITOLO_SUBORDINATO	= 'T';
	const NATURE_ALTRO_TITOLO		= 'D';
	const NATURE_SERIALI			= 'S';
	const NATURE_COLLEZIONE			= 'C';
	const NATURE_PARALLELO			= 'P';
	const NATURE_TITOLO_ANALITICO	= 'N';
	const NATURE_TITOLO_RAGGR_CONTROLLATO		= 'A';
	const NATURE_TITOLO_RAGGR_NON_CONTROLLATO	= 'B';

	const AUTTYPE_AUTORE			= 'AU';	// autore
	const AUTTYPE_TITOLO_UNIFORME	= 'TU';	// titolo uniforme
	const AUTTYPE_TITOLO_UNIFORME_MUSICA	= 'UM';	// titolo uniforme musica
	const AUTTYPE_SOGGETTO			= 'SO'; // soggetto
	const AUTTYPE_DESCRITTORE		= 'DE'; // descrittore
	const AUTTYPE_LUOGO				= 'LU';	// luogo
	const AUTTYPE_CLASSE			= 'CL';	// classe
	const AUTTYPE_MARCA				= 'MA';	// marca
	const AUTTYPE_REPERTORIO		= 'RE'; // repertorio

    const PROPOSAL_STATUS_SENT		= 'I';	// inserita
    const PROPOSAL_STATUS_ACCEPTED	= 'E';	// evasa
    const PROPOSAL_STATUS_REJECTED	= 'R';	// respinta

	const LOCACTION_LOCALIZE	= 'Localizza';
	const LOCACTION_UNLOCALIZE	= 'Delocalizza';
	const LOCACTION_FIX			= 'Correggi';
	const LOCACTION_UPDATE		= 'Allineato';
	const LOCACTION_CHECK		= 'Esame';

	const LOCTYPE_MANAGE	= 'Gestione';
	const LOCTYPE_OWN		= 'Possesso';
	const LOCTYPE_ALL		= 'Tutti';

	const CREATECONTROL_CHECK	= 'Simile';
	const CREATECONTROL_CONFIRM	= 'Conferma';
	const CREATECONTROL_IMPORT	= 'SimileImport';

	const LINKACTION_CREATE	= 'Crea';
	const LINKACTION_UPDATE	= 'Modifica';
	const LINKACTION_DELETE	= 'Cancella';
	const LINKACTION_LIST	= 'Lista';
	const LINKACTION_VARIANTIZE	= 'ScambioForma';

	const AUTNAMEFORM_ACCEPTED	= 'A';
	const AUTNAMEFORM_VARIANT	= 'R';

	public static function getAuthorityTypes()
	{
		return array(
			self::AUTTYPE_AUTORE,
			self::AUTTYPE_TITOLO_UNIFORME,
			self::AUTTYPE_TITOLO_UNIFORME_MUSICA,
			self::AUTTYPE_SOGGETTO,
			self::AUTTYPE_DESCRITTORE,
			self::AUTTYPE_LUOGO,
			self::AUTTYPE_CLASSE,
			self::AUTTYPE_MARCA,
			self::AUTTYPE_REPERTORIO
		);
	}
}
