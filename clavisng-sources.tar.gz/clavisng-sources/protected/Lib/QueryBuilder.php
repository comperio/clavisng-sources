<?php

/**
 * QueryBuilder class file
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 * For Commercial Licenses and support please contact Comperio.
 * @link      http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2019 Comperio srl
 * @license   http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version   2.9
 */

class QueryBuilder extends TTemplateControl implements ICallbackEventHandler, IActiveControl
{
	private $options;
	private $class;
	private $allow;

	// -----------------------------------------------------------------------------------------------------------------
	// ICallbackEventHandler, IActiveControl implementation
	// -----------------------------------------------------------------------------------------------------------------

	/**
	 * Creates a new callback control, sets the adapter to TActiveControlAdapter.
	 */
	public function __construct()
	{
		parent::__construct();
		$this->setAdapter(new TActiveControlAdapter($this));
	}

	/**
	 * @return TBaseActiveCallbackControl standard callback control options.
	 */
	public function getActiveControl()
	{
		return $this->getAdapter()->getBaseActiveControl();
	}

	/**
	 * Raises callback event. The implementation of this function should raise
	 * appropriate event(s) (e.g. OnClick, OnCommand) indicating the component
	 * is responsible for the callback event.
	 * @param TCallbackEventParameter $param the parameter associated with the callback event
	 * @throws \TInvalidDataValueException
	 * @throws \TInvalidOperationException
	 */
	public function raiseCallbackEvent($param)
	{
		$this->onCallback($param);
	}

	// -----------------------------------------------------------------------------------------------------------------
	// Component initialization
	// -----------------------------------------------------------------------------------------------------------------

	/**
	 * @param $param
	 * @throws \TInvalidOperationException
	 */
	public function onInit($param)
	{
		parent::onInit($param);

		$this->attachEventHandler('OnActualLibraryChanged', array($this, 'OnActualLibraryChanged'));
		$this->search->setButtonType(TButtonType::Button);
	}

	/**
	 * Register all the assets files needed by the QueryBuilder component.
	 * @param $param
	 * @throws \THttpException
	 */
	public function onPreRender($param)
	{
		parent::onPreRender($param);

		if ($this->getPage()->getClientSupportsJavaScript()) {

			$scripts = $this->getPage()->getClientScript();

			$scripts->registerPradoScript('prado');
			$scripts->registerPradoScript('ajax');
			$scripts->registerPradoScript('prototype');

			Clavis::registerJQuery($scripts, true);
			Clavis::registerBootstrap($scripts, true, ['bootstrap-select.min.css'], ['bootstrap-select.min.js']);
			Clavis::registerClientScript($scripts, Clavis::getComponentBasePath('MomentJS'), ['moment.min.js']);

			$css_assets = ['query-builder.default.min.css', 'style.css'];
			$js_assets = ['query-builder-autocompleter.js', 'query-builder.standalone.js', 'query-builder.it.js', 'interact.min.js'];

			Clavis::registerStyleSheet($scripts, Clavis::getComponentBasePath('ClavisQueryBuilder'), $css_assets);
			Clavis::registerClientScript($scripts, Clavis::getComponentBasePath('ClavisQueryBuilder'), $js_assets, 'js', false);
		}
	}

	/**
	 * Initialize the prado component parsing the given parameters and calling the setOptions component's own method.
	 * @param null $options
	 * @param null $filters
	 * @param null $rules
	 * @throws \PropelException
	 * @throws \THttpException
	 * @throws \TInvalidDataValueException
	 * @throws \TInvalidOperationException
	 */
	public function init($options = null, $filters = null, $rules = null)
	{
		$options = $options ?? $this->getDefaultOptions();

		/**
		 * Load the native component's plugins/
		 */
		if ($this->hasAllowComponent('not')) {
			$options['plugins'][] = 'not-group';
		}

		if ($this->hasAllowComponent('invert')) {
			$options['plugins'][] = 'invert';
		}

		if ($this->hasAllowComponent('sortable')) {
			$options['plugins'][] = 'sortable';
		}

		/**
		 * Load the prado custom component's behaviours
		 */
		$options['custom']['allowchoice'] = $this->hasAllowComponent('choice');
		$options['custom']['allowcustomrules'] = $this->hasAllowComponent('customrules');
		$options['custom']['allowdefault'] = $this->hasAllowComponent('setdefault');
		$options['custom']['localstoragekey'] = $this->getLocalStorageKey();
		$options['filters'] = [];

		$options['allow_empty'] = true;
		$options['sort_filters'] = true;

		if (null !== $filters) {
			$options['filters'] = $this->setFilters($filters, true);
			$this->setViewStateOptions($options);
		}

		/*
		 * Init specific settings and data given the enabled custom component behaviours
		 * ___BEFORE___ checking for the previously run query on the localstorage.
		 **/
		if ($options['custom']['allowchoice'] || $options['custom']['allowcustomrules']) {
			$this->loadSavedQueries();
		}

		// Set the rule given as parameter. If it's null check the browser local storage
		// for a previously performed query, and if found, set it as the current query.
		// If nothing is found, the initCurrentRule method ask the
		// parent for a default rule, so the response to the onSetDefaultRule event by
		// the parent is mandatory.
		if (null !== $rules) {
			$this->savedRules->setSelectedIndex(0);
			$options['rules'] = $rules;
			$this->setOptions($options);
		} else {
			$this->initCurrentRule();
		}

		$this->setViewStateOptions($options);
		$this->goToNormalMode();
	}

	/**
	 * Ritorna le opzioni di default da settare per il plugin base.
	 * @return array
	 */
	private function getDefaultOptions(): array
	{
		return [
			'plugins' => [
				//'bt-tooltip-errors', 'filter-description',
				'unique-filter',
				'bt-selectpicker',
				'bt-checkbox'
			],
			'rules' => null,
			'filters' => null,
			'lang' => [
				'invert' => 'inverti',
				'not_equal' => 'diverso',
				'NOT' => 'nega',
			]
		];
	}

	/**
	 * @param $component_name
	 * @return bool
	 */
	private function hasAllowComponent($component_name): bool
	{
		return stripos($this->getAllow(), $component_name) !== false;
	}

	// -----------------------------------------------------------------------------------------------------------------
	// Getters and Setters component's property methods
	// -----------------------------------------------------------------------------------------------------------------

	/**
	 * @return mixed
	 */
	public function getAllow()
	{
		return $this->allow;
	}

	/**
	 * @param mixed $allow
	 */
	public function setAllow($allow)
	{
		$this->allow = $allow;
	}

	/**
	 * @return mixed
	 */
	public function getQBClass()
	{
		return $this->class;
	}

	/**
	 * @param mixed $class
	 */
	public function setQBClass($class)
	{
		$this->class = $class;
	}

	/**
	 * @return mixed
	 */
	public function getType()
	{
		return $this->type;
	}

	/**
	 * @param mixed $type
	 */
	public function setType($type)
	{
		$this->type = $type;
	}

	/**
	 * @param $rules
	 * @throws \THttpException
	 */
	public function setRules($rules)
	{
		$options = $this->getOptions();
		$options['rules'] = $rules;

		if (array_key_exists('filters', $options) && count($options['filters']) > 0) {
			$this->setViewStateOptions($options);

			$jsonRules = ClavisBase::jsEncode($rules);
			$cid = $this->getClientID();
			$this->getPage()->getClientScript()->registerEndScript(
				'setRules' . $cid,
				"Comperio.QueryBuilder.$cid.setRules($jsonRules);");
		}
	}

	// -----------------------------------------------------------------------------------------------------------------
	// Query Builder events' callback
	// -----------------------------------------------------------------------------------------------------------------

	/**
	 * @param $sender
	 * @param $param
	 * @return bool
	 * @throws \THttpException
	 * @throws \TInvalidDataValueException
	 * @throws \TInvalidOperationException
	 */
	public function onSearchRequest($sender, $param)
	{
		return $this->onQBSearch();
	}

	/**
	 * @return bool
	 * @throws TInvalidDataValueException
	 * @throws TInvalidOperationException
	 * @throws \THttpException
	 */
	public function onQBSearch()
	{
		// stops the spinner.
		$searchDoneCallback = function () {
			$cid = $this->getClientID();
			$this->getPage()->getClientScript()->registerEndScript(
				'onSearchDoneCallback' . $cid,
				"Comperio.QueryBuilder.$cid.onSearchDoneCallback();"
			);
		};

		$options = $this->getOptions();
		$json_rule = $this->getCurrentRule();
		$object_rule = ClavisBase::jsDecode($json_rule);

		// Dispatch the onQBSearch event to the parent components.
		// The parent, on the onQBSearch handler method, MUST take care of checking if the callback method exists
		// and MUST call it after getting and displaying the results with:
		// <code>
		// if (is_callable($param['callback'])) {
		//		call_user_func($param['callback']);
		// }
		//</code>
		if ($object_rule !== null) {
			$options['rules'] = (array)$object_rule;
			$this->setViewStateOptions($options);
			$this->raiseEvent('onQBSearch', $this, ['rules' => $object_rule, 'callback' => $searchDoneCallback]);
			$this->goToNormalMode();
			return true;
		}
		return false;
	}

	/**
	 * Tell the class witch use the QueryBuilder component to set up the
	 * default rule. The QB main class isn't aware of what the default rule
	 * should be at this point.
	 * @throws \TInvalidDataValueException
	 * @throws \TInvalidOperationException
	 */
	public function onSetDefaultRule()
	{
		return $this->raiseEvent('onSetDefaultRule', $this, null);
	}

	/**
	 * @param $param
	 * @throws \TInvalidDataValueException
	 * @throws \TInvalidOperationException
	 */
	public function onCallback($param)
	{
		$this->raiseEvent('onCallback', $this, $param);
	}

	/**
	 * Save the current query to the document_template table.
	 * The template media identifier for this document's type is 'Q'.
	 * @param $sender
	 * @param $param
	 * @return int
	 * @throws \PropelException
	 * @throws \THttpException
	 * @throws \TInvalidDataValueException
	 * @throws \TInvalidOperationException
	 */
	public function onSaveCurrentQuery($sender, $param): int
	{
		$rule = $this->getCurrentRule();
		if ($rule !== 'null') {

			$name = $this->newFilterName->Text;
			$this->newFilterName->Text = '';

			if (empty($name) || $name === null) {
				return -1;
			}

			$query_template = DocumentTemplateQuery::create()
				->filterByTemplateClass($this->getQBClass())
				->filterByTemplateMedia('Q')
				->filterByTemplateTitle($name)
				->filterByTemplateSubject($name)
				->filterByTemplateDescription($name)
				->filterByTemplateLang('it_IT')
				->filterByLibraryId($this->getUser()->getActualLibraryId())
				->findOneOrCreate();

			$query_template->setTemplateBody($rule);
			$query_template->save();

			$this->reloadSavedQueries($query_template->getDocumentTemplateId());
			$this->goToNormalMode();
			return 0;
		}
		return -1;
	}

	/**
	 * Purge the selected query.
	 * @throws \PropelException
	 * @throws \THttpException
	 * @throws \TInvalidDataValueException
	 * @throws \TInvalidOperationException
	 */
	public function onDeleteCurrentQuery()
	{
		/** @var  \TListItem $toDeleteItem */
		$toDeleteItem = $this->savedRules->getSelectedItem();
		if ($toDeleteItem) {
			$template = DocumentTemplateQuery::create()->findOneByDocumentTemplateId($toDeleteItem->getValue());
			if ($template instanceof DocumentTemplate) {
				$template->delete();
				$this->reloadSavedQueries();
			}
		}
	}

	/**
	 * @throws \TInvalidDataValueException
	 * @throws \TInvalidOperationException
	 * @throws \THttpException
	 */
	public function onSelectionChanged()
	{
		$item = $this->savedRules->getSelectedItem();
		if (isset($item) && $item instanceof TListItem) {
			if ($item->getValue() > 0) {
				$this->setRuleFromCurrentItem($item);
				$this->setNewFilterName($item);
				$this->clearSearchResults();
				return true;
			}
		}

		$this->saveCurrentQueryToLocalStorage(0);
		$rule = $this->onSetDefaultRule();
		$this->setRules($rule[0]);
		$this->clearSearchResults();
		return true;
	}

	private function setNewFilterName($item)
	{
		$name = $item->getText() !== '---' ? $item->getText() : '';
		$this->newFilterName->setText($name);
		return $name;
	}

	/**
	 * React to the current library changed protected/Portlets/FooterPortlet.php:219 event.
	 * @param $sender
	 * @param $params
	 * @return bool
	 * @throws \PropelException
	 * @throws \THttpException
	 * @throws \TInvalidDataValueException
	 * @throws \TInvalidOperationException
	 */
	public function OnActualLibraryChanged($sender, $params)
	{
		$this->clearSearchResults();
		$this->reloadSavedQueries();
		$this->initCurrentRule();
		$this->goToNormalMode();

		return true;
	}

	// -----------------------------------------------------------------------------------------------------------------
	// Saved query management
	// -----------------------------------------------------------------------------------------------------------------

	/**
	 * Populate the drop down list with the previously saved query
	 * for the current librarian or those marked as system wide available. (i.e. ! librarian_id)
	 * @throws \PropelException
	 */
	private function loadSavedQueries()
	{
		$data = $this->getClassRules();

		$this->savedRules->DataTextField = 'name';
		$this->savedRules->DataValueField = 'id';

		$this->savedRules->DataSource = $data;
		$this->savedRules->dataBind();
	}


	/**
	 * Load all the saved queries with class equal to the QBClass component's parameter.
	 * @return array
	 * @throws \PropelException
	 */
	private function getClassRules(): array
	{
		$qbclass = $this->getQBClass();

		$data = DocumentTemplateQuery::create()
			->filterByTemplateMedia('Q')
			->filterByTemplateClass($qbclass)
			->condition('libraryNull', 'DocumentTemplate.LibraryId IS NULL')
			->condition('libraryMine', 'DocumentTemplate.LibraryId = ?', $this->getUser()->getActualLibraryId())
			->combine(array('libraryNull', 'libraryMine'), Criteria::LOGICAL_OR)
			->orderBy('template_title')
			->find();

		$rules[0] = [
			'id' => 0,
			'name' => '---',
			'ruleset' => []
		];

		/** @var \DocumentTemplate $rule */
		foreach ($data as $rule) {
			$id = $rule->getDocumentTemplateId();

			$rules[$id] = [
				'id' => $id,
				'name' => $rule->getTemplateTitle(),
				'ruleset' => $rule->getTemplateBody()
			];
		}

		$this->setViewStateSavedRules($rules);
		return $rules;
	}

	/**
	 * Get the key to access my own localstorage bucket.
	 * @return string
	 */
	private function getLocalStorageKey(): string
	{
		return 'Comperio_Clavis_QueryBuilder_'
			. $this->getQBClass()
			. '-'
			. $this->getUser()->getId()
			. '-'
			. $this->getUser()->getActualLibrary()->getLibraryId();
	}

	/**
	 * Save the current query's document_template id to localstorage.
	 * @param $dtid
	 * @return bool
	 */
	private function saveCurrentQueryToLocalStorage($dtid)
	{
		$key = $this->getLocalStorageKey();
		return setcookie($key, $dtid);
	}

	/**
	 * Set the current query to the latest chosen by the current user for the current QB class.
	 * @return int
	 * @throws \THttpException
	 * @throws \TInvalidDataValueException
	 * @throws \TInvalidOperationException
	 */
	private function initCurrentRule(): int
	{
		$key = $this->getLocalStorageKey();
		$document_template_id = TPropertyValue::ensureInteger($_COOKIE[$key]);

		$options = $this->getOptions();

		if ($document_template_id > 0) {
			$rule = $this->getRuleByDocumentTemplate($document_template_id);
			$options['rules'] = $rule;
			$this->setOptions($options);
			$this->savedRules->setSelectedValue($document_template_id);
		} else {
			$rule = $this->onSetDefaultRule();
			$options['rules'] = $rule[0];
			$this->setOptions($options);
			$this->savedRules->setSelectedIndex(0);
		}

		$this->onSelectionChanged();
		return $document_template_id;
	}

	/**
	 * @param int $documentTemplateId
	 * @throws \THttpException
	 * @throws \TInvalidDataValueException
	 * @throws \TInvalidOperationException
	 * @throws \PropelException
	 */
	private function reloadSavedQueries($documentTemplateId = 0)
	{
		$this->loadSavedQueries();
		$documentTemplateId = ($documentTemplateId > 0) ? $documentTemplateId : 0;
		$this->savedRules->setSelectedValue($documentTemplateId);

		$item = $this->savedRules->getSelectedItem();
		$this->setRuleFromCurrentItem($item);
		$this->setNewFilterName($item);
	}

	// -----------------------------------------------------------------------------------------------------------------
	// QueryBuilder native method wrappers
	// -----------------------------------------------------------------------------------------------------------------

	/**
	 * @throws \THttpException
	 */
	public function validate()
	{
		$cid = $this->getClientID();
		$this->getPage()->getClientScript()->registerEndScript(
			'validate' . $cid,
			"Comperio.QueryBuilder.$cid.validate()");
	}

	/**
	 * Call the 'setOptions' component's native method.
	 * @param mixed $options
	 * @throws \THttpException
	 */
	public function setOptions($options)
	{
		$this->setViewStateOptions($options);

		// package the information and call the 'setOptions' js method.
		$jsOptions = ClavisBase::jsEncode($options);
		$cid = $this->getClientID();
		$this->getPage()->getClientScript()->registerEndScript(
			'setOptions' . $cid,
			"Comperio.QueryBuilder.$cid.setOptions($jsOptions);"
		);
	}

	/**
	 * @return mixed
	 */
	public function getOptions()
	{
		$key = 'qb_options_' . $this->getClientID();
		$options = $this->getViewState($key);
		$this->options = $options;
		return $options;
	}

	/**
	 * @return mixed
	 * @throws \THttpException
	 */
	public function getRules()
	{
		$options = $this->getOptions();
		$rules = $options['rules'];

		$cid = $this->getClientID();
		$this->getPage()->getClientScript()->registerEndScript(
			'getRules' . $cid,
			"Comperio.QueryBuilder.$cid.getRules();");

		return $rules;
	}

	/**
	 * @return mixed
	 */
	public function getCurrentRule()
	{
		return $this->currentStorageRule->getValue();
	}

	/**
	 * @param \TListItem|null $item
	 * @throws \THttpException
	 * @throws \TInvalidDataValueException
	 * @throws \TInvalidOperationException
	 */
	private function setRuleFromCurrentItem(TListItem $item = null)
	{
		if ($item) {
			$document_template_id = TPropertyValue::ensureInteger($item->getValue());
			$ret = $this->saveCurrentQueryToLocalStorage($document_template_id);

			$rule = $this->getRuleByDocumentTemplate($document_template_id);
			$this->setRules($rule);
		} else {
			$this->resetCurrentRules();
		}
	}

	/**
	 * @param int $document_template_id
	 * @return mixed
	 * @throws \TInvalidDataValueException
	 * @throws \TInvalidOperationException
	 */
	private function getRuleByDocumentTemplate(int $document_template_id)
	{
		$savedRules = $this->getViewStateSavedRules();
		$rule = ClavisBase::jsDecode($savedRules[$document_template_id]['ruleset'], true);
		if (empty($rule)) {
			$rule = $this->onSetDefaultRule();
			return $rule[0];
		}
		return $rule;
	}

	/**
	 * @throws \THttpException
	 */
	public function resetCurrentRules()
	{
		$cid = $this->getClientID();
		$this->getPage()->getClientScript()->registerEndScript(
			'reset' . $cid,
			"Comperio.QueryBuilder.$cid.reset();");

		$this->savedRules->setSelectedIndex(0);
		$this->clearSearchResults();
	}

	/**
	 * @throws \THttpException
	 */
	public function goToNormalMode()
	{
		$cid = $this->getClientID();
		$this->getPage()->getClientScript()->registerEndScript(
			'gotoNormalMode' . $cid,
			"Comperio.QueryBuilder.$cid.gotoNormalMode();"
		);
	}

	/**
	 * @return mixed
	 */
	public function getFilters()
	{
		$options = $this->getOptions();
		return $options['filters'];
	}

	/**
	 * @param array $filters
	 * @return array
	 * @throws \THttpException
	 */
	public function setFilters(array $filters, $buffer = false)
	{
		array_walk($filters, function (&$item) {
			if (array_key_exists('field_class', $item)) {
				$item['values'] = LookupValuePeer::getLookupClassValues($item['field_class']);
			}
		});

		if ($buffer) {
			return $filters;
		}

		$options = $this->getOptions();
		$options['filters'] = $filters;
		$this->setOptions($options);
	}

	// -----------------------------------------------------------------------------------------------------------------
	// Page viewState handlers
	// -----------------------------------------------------------------------------------------------------------------

	/**
	 * @param $result
	 */
	public function printCurrentQuery($result)
	{
		$this->resultQuery->Text = $result;
	}

	/**
	 * @param $options
	 */
	private function setViewStateOptions($options)
	{
		// save the options into a state variable
		$this->options = $options;
		$key = 'qb_options_' . $this->getClientID();
		$this->setViewState($key, $options);
	}

	/**
	 * @return mixed
	 */
	private function getViewStateSavedRules()
	{
		$key = 'qb_saved_rules' . $this->getClientID();
		return $this->getViewState($key, []);
	}

	/**
	 * @param $rules
	 */
	private function setViewStateSavedRules($rules)
	{
		$key = 'qb_saved_rules' . $this->getClientID();
		$this->setViewState($key, $rules);
	}


	private function clearSearchResults()
	{
		$this->raiseEvent('onQBSearch', $this, ['rules' => null, 'callback' => null]);
	}
}
