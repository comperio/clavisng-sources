<?php
/**
 * ClavisCurl class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author    Mauro Seno <mauro.seno@comperio.it>
 * @link      http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2018 Comperio s.r.l
 * @license   http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version   2.9
 * @package   Widgets
 */

class ClavisCurl
{
    private const DEFAULT_REQUEST_HEADERS = array(
        'Connection' => 'keep-alive',
        'Accept-Language' => 'it,en-US;q=0.7,en;q=0.3',
        'Accept-Encoding' => 'gzip, deflate, br'
    );

    private const USER_AGENTS = array(
        'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:62.0) Gecko/20100101 Firefox/62.0',
        'Mozilla/5.0 (iPhone; CPU iPhone OS 11_0 like Mac OS X) AppleWebKit/604.1.38 (KHTML, like Gecko) Version/11.0 Mobile/15A372 Safari/604.1',
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.135 Safari/537.36 Edge/12.246',
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_2) AppleWebKit/601.3.9 (KHTML, like Gecko) Version/9.0.2 Safari/601.3.9',
        'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.111 Safari/537.36',
        'Mozilla/5.0 (Apple-iPhone7C2/1202.466; U; CPU like Mac OS X; en) AppleWebKit/420+ (KHTML, like Gecko) Version/3.0 Mobile/1A543 Safari/419.3',
        'Mozilla/5.0 (Windows NT 6.3; Trident/7.0; rv:11.0) like Gecko'
    );

    private const TIDY_CONFIG = [
        'quote-nbsp' => false,
        'indent' => true,
        'clean' => true,
        'output-xml' => true,
        'input-xml' => false,
        'wrap' => '2048'
    ];

    // Can I set a random user agent for you?
    private $_randomUserAgent;
    // Would you mind if I set some insane default heaners?
    private $_defaultRequestHeaders;
    // Let me take care for you of not well formed FrontPage 98 HTML output.
    private $_repairResponseBody;

    /**
     * ClavisCurl constructor.
     *
     * @param bool $setRandomUserAgent
     * @param bool $setDefaultRequestHeaders
     * @param bool $repairResponseBody
     */
    public function __construct(bool $setRandomUserAgent = false, $setDefaultRequestHeaders = false, bool $repairResponseBody = false)
    {
        $this->_defaultRequestHeaders = $setDefaultRequestHeaders;
        $this->_randomUserAgent = $setRandomUserAgent;
        $this->_repairResponseBody = $repairResponseBody;
    }


    public static function create(bool $setRandomUserAgent = false, $setDefaultRequestHeaders = false, bool $repairResponseBody = false)
    {
        return new self($setRandomUserAgent,$setDefaultRequestHeaders,$repairResponseBody);
    }


    /**
     * Send a post request to a URL.
     *
     * @param  string $url
     * @param  array  $urlParameters
     * @param array   $postParameters
     * @param  array  $headers
     * @param  bool   $asJSON
     *
     * @return array
     */
    public function post($url, array $urlParameters = [], array $postParameters = [], array $headers = [], $asJSON = false)
    {
        $request = $this->prepareRequest($url, $urlParameters, $headers);
        curl_setopt($request, CURLOPT_POST, count($postParameters));

        if ($asJSON === true) {
            curl_setopt($request, CURLOPT_POSTFIELDS, json_encode($postParameters));
        } else {
            curl_setopt($request, CURLOPT_POSTFIELDS, http_build_query($postParameters));
        }

        return $this->executeRequest($request);
    }

    /**
     * Send a get request to a URL.
     *
     * @param  string $url
     * @param  array  $urlParameters
     * @param  array  $headers
     * @param  bool   $asJSON
     *
     * @return array
     */
    public function get($url, array $urlParameters = [], array $headers = [], $asJSON = false)
    {
        $request = $this->prepareRequest($url, $urlParameters, $headers);
        $response = $this->executeRequest($request);

        if ($this->_repairResponseBody && $response['code'] === 200) {
            $response['body'] = $this->repairResponse($response['body']);
        }

        return $response;
    }

    /**
     * Executes a curl request.
     *
     * @param  resource $request
     *
     * @return array
     */
    public function executeRequest($request)
    {
        $body = curl_exec($request);
        $info = curl_getinfo($request);
        curl_close($request);

        $statusCode = $info['http_code'] === 0 ? 500 : $info['http_code'];
        return array('code' => $statusCode, 'body' => (string)$body);
    }

    /**
     * Return a random user agent string from the USER_AGENTS list
     *
     * @return mixed
     */
    private function getRandomUserAgent()
    {
        return array_rand(array_flip(self::USER_AGENTS), 1);
    }

    /**
     * Set up the curl request with the given parameters,headers and user agent options.
     *
     * @param string $url
     * @param array  $parameters
     * @param array  $headers
     *
     * @return resource
     */
    private function prepareRequest(string $url, array $parameters = [], array $headers = [])
    {
        $request = curl_init();

        if ($this->_defaultRequestHeaders) {
            $headers[] = self::DEFAULT_REQUEST_HEADERS;
        }

        if ($query = http_build_query($parameters)) {
            $url .= '?' . $query;
        }

        curl_setopt($request, CURLOPT_URL, $url);
        curl_setopt($request, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($request, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($request, CURLINFO_HEADER_OUT, true);
        curl_setopt($request, CURLOPT_SSL_VERIFYPEER, true);
        curl_setopt($request, CURLOPT_USERAGENT, $this->_randomUserAgent ? $this->getRandomUserAgent() : '');

        return $request;
    }

    /**
     * Clean the HTML response with the php tidy extension.
     *
     * @param $response
     *
     * @return string
     */
    private function repairResponse($response): string
    {
        if (!extension_loaded('tidy')) {
            throw new RuntimeException('tidy extension is required to get a not well formatted document repaired');
        }

        $tidy = new tidy();
        $tidy->parseString($response, self::TIDY_CONFIG);
        $tidy->cleanRepair();
        return tidy_get_output($tidy);
    }
}