<?php

/**
 * QueryBuilderSolrRuleConverter class file
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.9
 */
class QueryBuilderSolrRuleConverter implements IQueryBuilderRulesConverter
{
	protected $parser;
	protected $qb;
	protected $transformationRules;

	public function __construct(IQueryBuilderToDB $qbToDBInterface, array $transformationRules, $dao)
	{
		$this->parser = function ($value) use ($qbToDBInterface, $transformationRules) {
			return $this->applyTransform($value, $qbToDBInterface, $transformationRules);
		};
		$this->qb = $qbToDBInterface;
		$this->transformationRules = $transformationRules;
	}

	private function applyTransform($qbField, IQueryBuilderToDB $qbToDBInterface, $transformationRules)
	{
		$return = '';
		$fieldMap = $transformationRules;
		$field_map_to = array_key_exists($qbField->field, $fieldMap) ? $fieldMap[$qbField->field] : $qbField->field;

		if ($field_map_to !== null) {

			if (is_array($field_map_to)) {

				$return .= ' (';

				$field_value = $qbField->value;

				// se ho una mappatura uno a uno fra nome campo qb e campo nel backend corrente..
				if (!is_array($field_map_to['field_name'])) {
					$field_name = $field_map_to['field_name'];
				} else {
					// setto il campo di default per tutti gli altri operatori
					$field_name = $field_map_to['field_name']['default'];
					// ...a questo campo possono corrispondere piu' campi di ricerca nel backend corrente
					// a seconda dell'operatore. Controllo quindi se ho specificato un campo del backend,
					// specifico per questo operatore: in caso affermativo lo assegno...
					if (array_key_exists($qbField->operator, $field_map_to['field_name'])) {
						$field_name = $field_map_to['field_name'][$qbField->operator];
					}
				}

				$transform_type = $field_map_to['transform_type'];
				$transform_params = $field_map_to['transform_param'][$transform_type];

				switch ($transform_type) {

					case 'map':
						$val = array_key_exists($field_value, $transform_params) ? $transform_params[$field_value] : $field_value;
						$escaped_val = $qbToDBInterface->escapeUserInput($val);
						$tmp = $qbToDBInterface->getOperatorsMap($field_name, $qbField->operator, $escaped_val);
						$return .= $tmp;
						break;

					case 'expand':
						$i = $transform_params['item'];
						$v = $transform_params['values'];
						$o = $transform_params['operator'];

						if ($field_value === $i) {
							$acc = [];
							foreach ($v as $val) {
								$escaped_val = $qbToDBInterface->escapeUserInput($val);
								$acc[] = $qbToDBInterface->getOperatorsMap($field_name, $qbField->operator, $escaped_val);
							}
						}

						if (is_array($acc)) {
							$tmp = implode(" $o ", array_filter($acc));
							$return .= $tmp;
						}
						break;

					default:
						$escaped_val = $qbToDBInterface->escapeUserInput($field_value);
						$tmp = $qbToDBInterface->getOperatorsMap($field_name, $qbField->operator, $escaped_val);
						$return .= $tmp;
						break;
				}
				$return .= ') ';
			}

			if (is_string($field_map_to)) {
				$field_name = $field_map_to;
				$escaped_val = $qbToDBInterface->escapeUserInput($qbField->value);
				$return = $qbToDBInterface->getOperatorsMap($field_name, $qbField->operator, $escaped_val);
			}

		} else {
			$field_name = $qbField->field;
			$escaped_val = $qbToDBInterface->escapeUserInput($qbField->value);
			$return = $qbToDBInterface->getOperatorsMap($field_name, $qbField->operator, $escaped_val);
		}
		return $return;
	}

	public function convert(stdClass $r)
	{
		$this->getSolrQuery($result, $r);
		return $result;
	}

	private function getSolrQuery(string &$result, stdClass $r, bool $isLastGroup = true)
	{
		$condition = $r->condition;
		$rules = $r->rules;

		$result .= '(';

		foreach ($rules as $key => $value) {
			if (isset($value->field)) {

				// sto parsando una regola
				// -----------------------------------------------------------------------------------------
				if ('' !== $filter = ($this->parser)($value))
					$result .= $filter;

				$isLastRule = $key === (count($rules) - 1);
				if (!$isLastRule && '' !== $filter) {
					$result .= ' ' . $condition . ' ';
				}
			} else {
				// sono all'interno della definizione di un gruppo
				// -----------------------------------------------------------------------------------------
				$isLastGroup = $key === (count($rules) - 1);
				$this->getSolrQuery($result, $value, $isLastGroup);
			}
		}

		$str = $isLastGroup ? ')' : ") $condition ";
		$result .= $str;
	}
}