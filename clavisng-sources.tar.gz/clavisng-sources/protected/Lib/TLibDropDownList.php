<?php
/**
 * TLibDropDownlist class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Dario Rigolin <dario@comperio.it>
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 ePortal Technologies
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Libraries
 */
Prado::using('System.Web.UI.WebControls.TDropDownList');

/**
 * TLibDropDownlist Class
 *
 * This component extends a normal Prado TDropDownList, but allows automatic
 * self-population of its datasource by making a query in the lookup_value table
 * of the database, and selecting all the elements where DBClass == lookup_value.value_class
 * and with the right internationalization.
 *
 * Parameters are:
 * string DBClass (class in the lookup_tabel),
 * boolean HasBlank (if the datasource has a first blanked value, not selectable).
 * boolean Sorted (if the returned labels are to be sorted)
 *
 * Functions are:
 * boolean isSelected (returns false in the case HasBlank == true and a value has not been selected
 * 						after initial instantiation. Returns true in the remaining cases).
 *
 * @author Dario Rigolin <dario@comperio.it>
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Libraries
 * @since 2.3
 */
class TLibDropDownList extends TDropDownList
{
	const DEFAULTBLANKLABEL = '---';

	/**
	 * Extends the onInit of its parent.
	 * It constructs the datasource of the component (TDropDownList) by using the
	 * DBCLass parameter.
	 *
	 * @param unknown_type $param
	 */
	public function onInit($param)
	{
		parent::onInit($param);

		if (!$this->getPage()->getIsPostBack())
			$this->populateList();
	}

	/**
	 * Alias, for conformity
	 *
	 */
	public function populate()
	{
		$this->populateList();
	}

	/**
	 * It returns a hash with keys and values relative to the
	 * properties of the control.
	 *
	 */
	public function populateList()
	{
		$class = $this->getDBClass();
		if ($class == '')
		{
			$dataSource = array();

			if ($this->getHasBlank())
				$dataSource[0] = $this->getBlankLabel();
			else
				$dataSource = array(-1 => Prado::localize("... classe errata o vuota ..."));

			$this->setDataSource($dataSource);
			$this->dataBind();

			return;
		}

		$dataSource = LibraryValuePeer::getLibraryClassValues($class, $this->getLibraryId(), $this->getSorted(), $this->getLabelLength());

		$addedValues = $this->getAddedValues();
		if (!is_null($addedValues) && is_array($addedValues) && count($addedValues) > 0)
			$dataSource = $addedValues + $dataSource;

		if ($this->getHasBlank())
			$dataSource = array(0 => $this->getBlankLabel()) + $dataSource;
		elseif (count($dataSource) < 1)
			$dataSource = array(-1 => Prado::localize("... classe errata o vuota ..."));

		$preVal = $this->getSelectedIndex();
		$this->setDataSource($dataSource);
		$this->dataBind();

		if ($preVal !== "")
			$this->setSelectedIndex($preVal);
	}

	public function setAddedValues($hash)
	{
		$this->setControlState('AddedValues', $hash, array());
	}

	public function getAddedValues()
	{
		return $this->getControlState('AddedValues', array());
	}

	/**
	 * Specifies the class of the lookup table where to extract data from,
	 * in order to populate the datasource of this component.
	 *
	 * @param string $value
	 */
	public function setDBClass($value)
	{
		$this->setControlState('DBClass', $value);
	}

	/**
	 * Returns the class of the lookup table where to extract data from,
	 * in order to populate the datasource of this component.
	 *
	 * @return string
	 */
	public function getDBClass()
	{
		return $this->getControlState('DBClass');
	}

	/**
	 * Specifies if the datasource of this component has a first empty
	 * selection option (marked as ' --- ' to users).
	 * Default is false.
	 *
	 * @param boolean $value
	 */
	public function setHasBlank($value)
	{
		$this->setControlState('HasBlank', $value);
	}

	/**
	 * Returns if the datasource of this component has a first empty
	 * selection option (marked as ' --- ' to users).
	 * Default is false.
	 *
	 * @return boolean
	 */
	public function getHasBlank()
	{
		$result = $this->getControlState('HasBlank');
		if ($result === "true")
			return true;
		else
			return false;
	}

	public function setBlankLabel($label)
	{
		if (is_null($label))
			$label = self::DEFAULTBLANKLABEL;
		$this->setControlState('BlankLabel', $label);
	}

	public function getBlankLabel()
	{
		$result = $this->getControlState('BlankLabel');
		if (is_null($result))
			return self::DEFAULTBLANKLABEL;
		else
			return $result;
	}

	/**
	 * Specifies if the returned datasource (labels) have
	 * to be sorted alphabetically (ascending).
	 * Default is false.
	 *
	 * @param boolean $value
	 */
	public function setSorted($value)
	{
		$this->setControlState('Sorted', $value);
	}

	/**
	 * Returns if the returned datasource (labels) have
	 * to be sorted alphabetically (ascending).
	 * Default is false.
	 *
	 * @return boolean
	 */
	public function getSorted()
	{
		$result = $this->getControlState('Sorted');
		if ($result === "true")
			return true;
		else
			return false;
	}

	/**
	 * Returns true if the selected value is not the first blank value
	 * (set in case of HasBlank = true).
	 *
	 * @return boolean
	 */
	public function isSelected()
	{
		if ($this->getSelectedIndex() === 0 && $this->getControlState('HasBlank'))
			return false;
		else
			return true;
	}

	public function setSelectedValue($value)
	{
		if ($value == '')
			return false;
		try
		{
			parent::setSelectedValue($value);
		}
		catch (Exception $exception)
		{
			$errorMessage = $exception->getMessage();
			$errorCase = strstr($errorMessage, 'TLibDropDownList.SelectedValue() has an invalid value');

			if ($errorCase == false)
			{
				throw ($exception);
			}
			else
			{
				///// eventuale messaggistica
				Prado::log('errore in TLibDropDownList: selezionato valore non valido');
			}
		}
	}

	public function setSelectedIndex($value = -1)
	{
		if ($value < -1)
			$value = -1;

		try
		{
			parent::setSelectedIndex($value);
		}
		catch (Exception $exception)
		{
			$errorMessage = $exception->getMessage();
			$errorCase = strstr($errorMessage, 'TLibDropDownList.SelectedIndex() has an invalid value');
			if ($errorCase == false)
			{
				throw ($exception);
			}
			else
			{
				///// eventuale messaggistica
				Prado::log('errore in TLibDropDownList: selezionato valore di indice non valido');
			}
		}
	}

	/**
	 * Specifies the library_id for the lookup_values
	 *
	 * @param int $value
	 */
	public function setLibraryId($value)
	{
		$this->setControlState('LibraryId', intval($value), 0);
	}

	/**
	 * Returns the library_id for the loookup_values
	 * Default is '0'
	 *
	 * @return int
	 */
	public function getLibraryId()
	{
		return $this->getControlState('LibraryId', 0);
	}

	public function setLabelLength($value)
	{
		$this->setControlState('LabelLength', intval($value), null);
	}

	public function getLabelLength()
	{
		return $this->getControlState('LabelLength', null);
	}
	
}