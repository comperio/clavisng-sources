<?php
/**
 * TurbomarcConversion class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 ePortal Technologies
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Libraries
 */

/**
 * TurbomarcConversion Class
 *
 * TurbomarcConversion is a collection of function used to convert from various
 * Turbomarc flavours into ClavisNG dialect.
 *
 * Note: all methods declared public here will be available for being selected as
 * valid conversion rule. If you want to add a internal function, please declare
 * it protected or private to make it not list among selectable conversion rules.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Libraries
 * @since 2.5.0
 */
class TurbomarcConversion {

	public static $generiLiberF = array(
		'Albi cartonati'	=> 801,
		'Albi illustrati'	=> 802,
		'Avventure'			=> 805,
		'Dramma'			=> 809,
		'Fantascienza'		=> 811,
		'Fantasy'			=> 812,
		'Fiabe e favole'	=> 813,
		'Filastrocche e poesia'	=> 814,
		'Giallo'			=> 816,
		'Horror e mistero'	=> 819,
		'Libri animati'		=> 820,
		'Libri game'		=> 821,
		'Libri gioco'		=> 822,
		'Libri in materiali vari'	=> 823,
		'Miti e leggende'	=> 825,
		'Racconti'			=> 833,
		'Racconti illustrati'	=> 834,
		'Romanzi'			=> 836,
		'Rosa'				=> 837,
		'Storie della età evolutiva'	=> 843,
		'Storie della natura'	=> 844,
		'Storie di animali'		=> 845,
		'Storie fantastiche'	=> 846,
		'Temi sociali'		=> 848,
		'Temi storici'		=> 849,
		'Umorismo'			=> 850,
		'Western'			=> 851,
		'Letteratura di viaggio'	=> 852
	);

	public static $generiLiberNF = array(
		'Animali'			=> 803,
		'Arte'				=> 804,
		'Biologia'			=> 806,
		'Corpo umano'		=> 807,
		'Divulgazione a fumetti'	=> 808,
		'Ecologia e ambiente'		=> 810,
		'Geografia'			=> 815,
		'Giochi'			=> 817,
		'Hobby e per fare'	=> 818,
		'Linguaggio'		=> 824,
		'Pensiero'			=> 826,
		'Per imparare a contare'			=> 827,
		'Per imparare a leggere'			=> 828,
		'Per imparare forme e colori'		=> 829,
		'Per imparare le lingue straniere'	=> 830,
		'Per imparare le relazioni'			=> 831,
		'Piante'		=> 832,
		'Religione'		=> 835,
		'Scienza'		=> 838,
		'Società'		=> 839,
		'Spettacolo'	=> 840,
		'Sport'			=> 841,
		'Storia'		=> 842,
		'Tecnologia'	=> 847
	);

	/**
	 * Parses a TurboMarc record searching for LiberDatabase fields and converts
	 * them to ClavisNG format.
	 *
	 * @param TurboMarc $turbomarc Source record
	 * @return TurboMarc The record transformed.
	 */
	public static function LiberDatabase(TurboMarc &$turbomarc)
	{
		unset($turbomarc->d399);
		if (array_key_exists('d960', $turbomarc)) {
			foreach ($turbomarc->d960 as $subj) {
				$lt = ((string)$subj->sy == 1) ? '619' : '610'; // TODO: change to 619 when import ready
				$newsubj = $turbomarc->addField($lt);
				$newsubj->addSubField('a', (string)$subj->sa);
				$newsubj->addSubField(2, 'L');
			}
			unset($turbomarc->d960);
		}
		if (array_key_exists('d961', $turbomarc) ||
			array_key_exists('d962', $turbomarc) ||
			array_key_exists('d969', $turbomarc)) {
			$f109 = $turbomarc->addField('109');
			if (array_key_exists('d961', $turbomarc)) {
				$fict = 0;
				$nonfict = 9;
				foreach ($turbomarc->d961 as $d961) {
					$keyword = (string)$d961->sa;
					if (array_key_exists($keyword, self::$generiLiberF) && $fict < 9) {
						$f109->setCDF('a', $fict, self::$generiLiberF[$keyword]);
						$fict += 3;
					} else if (array_key_exists($keyword, self::$generiLiberNF) && $nonfict < 18) {
						$f109->setCDF('a', $nonfict, self::$generiLiberNF[$keyword]);
						$nonfict += 3;
					}
				}
				unset($turbomarc->d961);
			}
			if (array_key_exists('d962', $turbomarc)) {
				$f109->setCDF('a', 18, sprintf("%2d", (string)$turbomarc->d962->sa));
				$f109->setCDF('a', 20, sprintf("%2d", (string)$turbomarc->d962->sb));
				$turbomarc->d962->remove();
			}
			if (array_key_exists('d969', $turbomarc)) {
				$f109->setCDF('a', 22, (string)$turbomarc->d969->sa);
				$turbomarc->d969->remove();
			}
		}
		// end LiberDatabase processing
		return $turbomarc;
	}

	/**
	 * Parses a TurboMarc record converting embedded 4XX fields into inline.
	 *
	 * @param TurboMarc $turbomarc Source record
	 * @return TurboMarc The record transformed.
	 */
	public static function embed2inline(TurboMarc &$turbomarc)
	{
		$to_create = array();
		for ($i=400; $i<500; ++$i) {
			$tag = "d{$i}";
			if (array_key_exists($tag, $turbomarc)) {
				foreach ($turbomarc->$tag as $fld) {
					$bid = (string)$fld->getEmbeddedField('001')->c001;

					if($fld->getEmbeddedField('200'))
						$title = $fld->getEmbeddedField('200')->getTitle();
					else
						$title = ['nst'=>'','txt'=>''];

					$title = explode('/',trim($title['nst'].'*'.implode('. ',$title['txt'])));

					$f100 = $fld->getEmbeddedField('100');
					$date = ($f100) ? trim($f100->getCDF('a',0)) : '';
					$to_create[] = array(
						'fld'	=> $i,
						'3'		=> $bid,
						't'		=> preg_replace('!\s+!', ' ', $title[0]),
						'd'		=> $date);
				}
				unset($turbomarc->$tag);
			}
		}
		foreach ($to_create as $data) {
			$f = $turbomarc->addField($data['fld']);
			$f->addSubField('3',$data['3']);
			$f->addSubField('t',$data['t']);
			$f->addSubField('d',$data['d']);
		}
		return $turbomarc;
	}

	/**
	 * Parses a TurboMarc record converting Bertoliana fields to ClavisNG ones.
	 *
	 * @param TurboMarc $turbomarc Source record
	 * @return TurboMarc The record transformed.
	 */
	public static function Bertoliana(TurboMarc &$turbomarc)
	{
		$f901 = (array_key_exists('d901', $turbomarc)) ?
			$turbomarc->d901 : $turbomarc->addField(901);

        if($turbomarc->getLeader()->hiercode > 1)
            $f901->sd = 0;

		if (array_key_exists('d399', $turbomarc)) {
			$nota399a = trim((string)$turbomarc->d399->sa);
			$nota399b = trim((string)$turbomarc->d399->sb);
			if ($nota399a)
				$turbomarc->addField(321)->addSubField('a', $nota399a);
			if ($nota399b)
				$turbomarc->addField(307)->addSubField('a', $nota399b);
			unset($turbomarc->d399);
		}
		if (array_key_exists('d390',$turbomarc)) {
			$turbomarc->addField(514)->addSubField('a', (string)$turbomarc->d390->sa);
			unset($turbomarc->d390);
		}
		if (array_key_exists('d330',$turbomarc)) {
			foreach ($turbomarc->d330 as $fld) {
				$nota330a = (string)$fld->sa;
				$nota3309 = trim((string)$fld->s9);
				switch ($nota3309) {
					case 'EDITORIALE':
						$fld->sa .= " (Fonte editoriale)";
						break;
					case 'LIBER01':
						$fld->sa .= " (Fonte LiberDatabase: Sommario)";
						break;
					case 'LIBER02':
						$fld->sa .= " (Fonte LiberDatabase: caratteristiche formali)";
						break;
				}
			}
		}
		if (array_key_exists('d520',$turbomarc)) {
			$turbomarc->addField(330)->addSubField('a', (string)$turbomarc->d520->sa);
			unset($turbomarc->d520);
		}
		if (array_key_exists('d299',$turbomarc)) {
			$f901->sg = (string)$turbomarc->d299->sa;
			$f901->sl = str_replace('/','-', (string)$turbomarc->d299->sb);
			unset($turbomarc->d299);
		} else if ('g' == $turbomarc->getLeader()->type) {
			if((isset($turbomarc->d100->sa) && $turbomarc->d100->getCDF('a',9)) > 0)
                $f901->sl = sprintf("%4d-07-01",$turbomarc->d100->getCDF('a',9)+2);
            $f901->sa = "g03";
            $f901->sc = "3";

		} else if ('j' == $turbomarc->getLeader()->type) {
            // Set CD Audio for Musical Audio.
            if((isset($turbomarc->d100->sa) && $turbomarc->d100->getCDF('a',9)) > 0)
                $f901->sl = sprintf("%4d-07-01",$turbomarc->d100->getCDF('a',9)+2);
            $f901->sa = "j02";
            $f901->sc = "4";

        } else if ('i' == $turbomarc->getLeader()->type) {
            // Set CD Audio for Non musical Audio.
            //if((isset($turbomarc->d100->sa) && $turbomarc->d100->getCDF('a',9)) > 0)
            //    $f901->sl = sprintf("%4d-07-01",$turbomarc->d100->getCDF('a',9)+2);
            $f901->sa = "i02";
            $f901->sc = "5";

        }

		return $turbomarc;
	}

	/**
	 * Parses a TurboMarc record searching for Cobiss fields and converts
	 * them to ClavisNG format.
	 *
	 * @param TurboMarc $turbomarc Source record
	 * @return TurboMarc The record transformed.
	 */
	public static function Cobiss(TurboMarc &$turbomarc)
	{
		if (array_key_exists('c000', $turbomarc)) {
			$turbomarc->setControlField('001',$turbomarc->c000->sx);
			unset($turbomarc->c000);
		}
		// end Cobiss processing
		return $turbomarc;
	}

	/**
	 * Parses a TurboMarc record searching for SBN fields and converts
	 * them to ClavisNG format.
	 *
	 * @param TurboMarc $turbomarc Source record
	 * @return TurboMarc The record transformed.
	 */
	public static function SBNz(TurboMarc &$turbomarc)
	{
		$bid = explode('\\',(string)$turbomarc->c001);
		$nodecode = count($bid) > 2 ? $bid[2] : $bid[0];
		// if it has 'E' as 4th char, it's antique
		if (strlen($nodecode) > 3 && 'E' == $nodecode[3]) {
			$f901 = (array_key_exists('d901', $turbomarc)) ?
				$turbomarc->d901 : $turbomarc->addField(901);
			unset($f901->sa);
			$f901->addSubField('a', 'a02');
		}
		// end SBNz processing
		return $turbomarc;
	}


	private static function removeField($field, Turbomarc $turbomarc)
	{
		$unsetField = static function ($field, $turbomarc) {
			if (array_key_exists($field, $turbomarc)) {
					unset($turbomarc->$field);
			}
		};

		if (is_array($field)) {
			foreach ($field as $f) {
				$unsetField($f, $turbomarc);
			}
		} else {
			$unsetField($field, $turbomarc);
		}

		return $turbomarc;
	}

	public static function RimuoviResponsabilitaPrincipale(Turbomarc $turbomarc)
	{
		// 700, 710, 720
		return self::removeField(['d700', 'd710', 'd720'], $turbomarc);
	}

	public static function RimuoviResponsabilitaAlternativa(Turbomarc $turbomarc)
	{
		// 701, 711, 721
		return self::removeField(['d701', 'd711', 'd721'], $turbomarc);
	}

	public static function RimuoviResponsabilitaSecondaria(Turbomarc $turbomarc)
	{
		// 702, 712, 722
		return self::removeField(['d702', 'd712', 'd722'], $turbomarc);
	}

	public static function RimuoviSoggetti(Turbomarc $turbomarc)
	{
		for ($i = 600; $i <= 616; $i++) {$fields[] = "d{$i}";}
		$fields[] = 'd620';

		return self::removeField($fields, $turbomarc);
	}

	public static function RimuoviParoleChiave(Turbomarc $turbomarc)
	{
		return self::removeField('d619', $turbomarc);
	}

	public static function RimuoviDewey(Turbomarc $turbomarc)
	{
		return self::removeField('d676', $turbomarc);
	}

	public static function RimuoviCollana(Turbomarc $turbomarc)
	{
		return self::removeField('d410', $turbomarc);
	}

	public static function RimuoviOpera(Turbomarc $turbomarc)
	{
		return self::removeField('d500', $turbomarc);
	}
}
