<?php

require_once 'vendor/onelogin/php-saml/_toolkit_loader.php';

use OneLogin\Saml2;
use OneLogin\Saml2\Auth;
use OneLogin\Saml2\Constants;

class ClavisSAML
{
    /**
     * @var array|false|mixed
     */
    protected $_localSettings;
    protected $_samlSettings;
    protected $_ssoDir;
    protected $_isCustom;
    private $_samlAuthObject;

    private $_samlAttributes;
    private $_requestID;


    /**
     * ClavisSAML constructor.
     * @param string $customConfigSubdir
     * @param string $sloBinding
     * @throws Saml2\Error
     */
    public function __construct($customConfigSubdir = '', $ssoBinding = Constants::BINDING_HTTP_REDIRECT, $sloBinding = Constants::BINDING_HTTP_REDIRECT)
    {
        $this->_ssoDir = $this->initSsoDir() . $customConfigSubdir;
        $this->setOneLoginBasePath();
        $this->requireOverride();

        $this->_isCustom = file_exists($this->getSsoDir() . '/overrides.php');
        $this->_localSettings = $this->getSiteSettings($ssoBinding, $sloBinding);
        $this->_samlSettings = $this->getSettingsObject();
        $this->_samlAttributes = null;
        $this->_samlAuthObject = $this->initAuthObject();
    }

    /**
     * @return null
     */
    public function getSamlAttributes()
    {
        return $this->_samlAttributes;
    }

    /**
     * @return mixed
     */
    public function getRequestID()
    {
        return $this->_requestID;
    }

    /**
     * @return false|string
     */
    private function initSsoDir()
    {
        $ssoDir = realpath(Prado::getPathOfNamespace('SSO'));
        if (!is_dir($ssoDir) && !mkdir($ssoDir, '0777', true) && !is_dir($ssoDir)) {
            throw new RuntimeException(sprintf('Directory "%s" was not created', $ssoDir));
        }
        return $ssoDir;
    }

    /**
     * @return string
     */
    public function getSsoDir()
    {
        return $this->_ssoDir;
    }

    /**
     * @param $value
     */
    protected function setSsoDir($value)
    {
        $this->_ssoDir = $value;
    }

    /**
     *
     */
    public function setOneLoginBasePath()
    {
        $oneloginbase = $this->getSsoDir() . '/';
        define('ONELOGIN_CUSTOMPATH', $oneloginbase);
    }

    /**
     * @return bool
     */
    public function isCustom(): bool
    {
        return $this->_isCustom;
    }

    /**
     * @return CustomSettings|Saml2\Settings
     */
    public function getSamlSettings()
    {
        return $this->_samlSettings;
    }

    /**
     * @return array|false|mixed
     */
    public function getLocalSettings()
    {
        return $this->_localSettings;
    }

    /**
     *
     */
    private function requireOverride()
    {
        $overrides = $this->getSsoDir() . '/overrides.php';
        if (file_exists($overrides)) {
            require $overrides;
        }
    }

    /**
     * @return CustomSettings|Saml2\Settings
     * @throws Saml2\Error
     */
    private function getSettingsObject()
    {
        if ($this->_isCustom && class_exists('CustomSettings', false)) {
            $settings = new CustomSettings($this->_localSettings);
        } else {
            $settings = new Saml2\Settings($this->_localSettings);
        }

        return $settings;
    }

    /**
     * @return CustomAuth|Auth
     * @throws Saml2\Error
     */
    public function initAuthObject()
    {
        if ($this->isCustom() && class_exists('CustomAuth', false)) {
            $auth = new CustomAuth($this->_localSettings);
        } else {
            $auth = new Auth($this->_localSettings);
        }
        return $auth;
    }

    /**
     * @return Auth|CustomAuth
     */
    public function getAuthObject()
    {
        return $this->_samlAuthObject;
    }

    /**
     * @return array|false|mixed
     * @throws Exception
     */
    private function getSiteSettings($ssoBinding, $sloBinding)
    {
        $ssoDir = $this->_ssoDir;
        $conf_file = $ssoDir . '/settings.php';
        $advanced_conf_file = $ssoDir . '/advanced_settings.php';

        $settings = file_exists($conf_file) ? include $conf_file : false;
        $advanced_settings = file_exists($advanced_conf_file) ? include $advanced_conf_file : false;

        $idp_settings = [];
        if (($settings['idp']['metadataURL'] ?? '') != '') {
            $idp_settings = OneLogin\Saml2\IdPMetadataParser::parseRemoteXML($settings['idp']['metadataURL'], null, null, $ssoBinding, $sloBinding);
            // don't mess with my sp configuration, but downloaded idp configuration takes precedence over the local one.
            unset($idp_settings['sp']);
        }
        if (($settings['idp']['metadataFile'] ?? '') != '') {
            $idp_settings = OneLogin\Saml2\IdPMetadataParser::parseFileXML($settings['idp']['metadataFile'], null, null, $ssoBinding, $sloBinding);
            unset($idp_settings['sp']);
        }

        if (is_array($advanced_settings)) {
            $settings = array_merge($settings, $advanced_settings);
        }

        if (is_array($idp_settings)) {
            $settings = array_merge($settings, $idp_settings);
        }

        return $settings;
    }

    /**
     * @return array
     * @throws Exception
     */
    public function getSAMLAuthData()
    {
        $auth = $this->_samlAuthObject;

        $data['samlUserdata'] = $auth->getAttributes();
        $data['samlNameId'] = $auth->getNameId();
        $data['samlNameIdFormat'] = $auth->getNameIdFormat();
        $data['samlNameIdNameQualifier'] = $auth->getNameIdNameQualifier();
        $data['samlNameIdSPNameQualifier'] = $auth->getNameIdSPNameQualifier();
        $data['samlSessionIndex'] = $auth->getSessionIndex();
        $data['AuthNRequestID'] = $_SESSION['AuthNRequestID'];
        $data['samlUserKey'] = bin2hex(random_bytes(128));

        unset($_SESSION['AuthNRequestID']);
        return $data;
    }

    /**
     * @param $data
     * @param $patron
     * @param false $inSession
     * @return bool
     * @throws PropelException
     */
    public function saveAuthData($data, $patron, $inSession = false)
    {
        if ($inSession) {
            $_SESSION['samlNameId'] = $data['samlNameId'];
            $_SESSION['samlNameIdFormat'] = $data['samlNameIdFormat'];
            $_SESSION['samlNameIdNameQualifier'] = $data['samlNameIdNameQualifier'];
            $_SESSION['samlNameIdSPNameQualifier'] = $data['samlNameIdSPNameQualifier'];
            $_SESSION['samlSessionIndex'] = $data['samlSessionIndex'];
            $_SESSION['samlUserKey'] = $data['samlUserKey'];
            return true;
        }

//        $pa = new PatronAction();
//        $pa->setPatron($patron);
//        $pa->setActionType(PatronActionPeer::SSO_LOGIN_OK);
//        $pa->setActionDate(time());
//        $pa->setActionNote(json_encode($data));
//        $pa->setActionKey($data['samlNameId'] . ":" . $data['samlSessionIndex'] . ":" . $data['autologin_token']);
//        $pa->save();

        return self::saveSuccessfulLoginEvent($data['samlNameId'], $data['samlSessionIndex'], $data['autologin_token'], $patron->getPatronId(), json_encode($data));
    }

    /**
     * @param $nameID
     * @return int|null
     */
    public function getPatronIDFromNameId($nameID): ?int
    {
        $isLoggedIn = PatronActionQuery::create()
            ->filterByActionKey("$nameID:*")
            ->filterByActionType(PatronActionPeer::SSO_LOGIN_OK)
            ->orderByActionDate(Criteria::DESC)
            ->findOne();

        $patronID = null;
        if ($isLoggedIn instanceof PatronAction) {
            $patronID = $isLoggedIn->getPatronId();
        }
        return $patronID;
    }

    /**
     * @param $dng_autologin_token
     * @return PatronAction
     */
    public static function getPatronActionFromClavisToken($dng_autologin_token): PatronAction
    {
        $patronAction = PatronActionQuery::create()
            ->filterByActionKey("*:$dng_autologin_token")
            ->filterByActionType(PatronActionPeer::SSO_LOGIN_OK)
            ->orderByActionDate(Criteria::DESC)
            ->findOne();

        return $patronAction;
    }

    /**
     * @param PatronAction $patronAction
     * @param $phpSessionID
     * @throws PropelException
     */
    public static function updateSessionIdForPatronAction(PatronAction $patronAction, $phpSessionID)
    {
        // update action note
        $json = $patronAction->getActionNote();
        $data = json_decode($json, true);
        $data['sid'] = $phpSessionID;
        $patronAction->setActionNote(json_encode($data));

        // update action key
        $ak = explode(":", $patronAction->getActionKey());
        $patronAction->setActionKey($ak[0] . ":" . $ak[1] . ":" . $phpSessionID);
        $patronAction->save();
    }

    /**
     * @param $nameId
     * @param $sessionIndex
     * @param $session_id
     * @param $patronId
     * @param false $inSession
     * @throws PropelException
     */
    public static function saveLogoutEvent($nameId, $sessionIndex, $session_id, $patronId, $inSession = false)
    {
        if (!$inSession) {
            $actionKey = $nameId . ':' . $sessionIndex . ':' . $session_id;
           self::saveLogoutAttempt($actionKey,$patronId);

            // set the relative login action type to sso_closed.
            $paIn = PatronActionQuery::create()
                ->filterByActionKey($actionKey)
                ->filterByActionType(PatronActionPeer::SSO_LOGIN_OK)
                ->findOne();

            $paIn->setActionType(PatronActionPeer::SSO_CLS);
            $paIn->setActionDate(time());
            $paIn->save();
        }
    }

    public static function saveLogoutAttempt($actionKey, $patronId) {
        $pa = new PatronAction();
        $pa->setPatronId($patronId);
        $pa->setActionType(PatronActionPeer::SSO_LOGOUT);
        $pa->setActionDate(time());
        $pa->setActionKey($actionKey);
        $pa->save();
    }

    public static function saveSuccessfulLoginEvent($nameId, $sessionIndex, $session_id, $patronId, $note = '')
    {
        $actionKey = sprintf("%s:%s:%s", $nameId, $sessionIndex, $session_id);
        $pa = new PatronAction();
        $pa->setPatronId($patronId);
        $pa->setActionType(PatronActionPeer::SSO_LOGIN_OK);
        $pa->setActionDate(time());
        $pa->setActionKey($actionKey);
        $pa->setActionNote($note);
        try {
            $pa->save();
            return true;
        } catch (PropelException $e) {
            return false;
        }
    }

    public static function saveFailedLoginEvent($nameId, $sessionIndex, $session_id, $patronId, $note=null)
    {
        $actionKey = sprintf("%s:%s:%s", $nameId, $sessionIndex, $session_id);
        $pa = new PatronAction();
        $pa->setPatronId($patronId);
        $pa->setActionType(PatronActionPeer::SSO_LOGIN_KO);
        $pa->setActionDate(time());
        $pa->setActionKey($actionKey);
        $pa->setActionNote($note);
        $pa->save();
    }

    /**
     * @param $patronID
     * @param false $fromSession
     * @return array|null[]
     */
    private function loadAuthData($patronID, bool $fromSession = false, $suk = null): array
    {

        $nameId = null;
        $sessionIndex = null;
        $nameIdFormat = null;
        $nameIdNameQualifier = null;
        $nameIdSPNameQualifier = null;
        $samlUserKey = null;

        if ($fromSession) {
            $data = $_SESSION;
        } else {
            $isLoggedInQuery = PatronActionQuery::create()
                ->filterByPatronId($patronID)
                ->filterByActionType(PatronActionPeer::SSO_LOGIN_OK);

            if ((bool)$fromSession == false && isset($suk)) {
                $isLoggedInQuery->filterByActionNote("%$suk%");
            }

            $isLoggedInQuery->orderByActionDate(Criteria::DESC);
            $isLoggedIn = $isLoggedInQuery->findOne();

            if ($isLoggedIn instanceof PatronAction) {
                $json = $isLoggedIn->getActionNote();
                $data = json_decode($json, true);
            } else {
                Prado::log(sprintf("loadAuthData get data failed for patron id %s", $patronID), TLogger::ERROR, 'SOAP');
            }
        }

        if (isset($data['samlNameId'])) {
            $nameId = $data['samlNameId'];
        }
        if (isset($data['samlNameIdFormat'])) {
            $nameIdFormat = $data['samlNameIdFormat'];
        }
        if (isset($data['samlNameIdNameQualifier'])) {
            $nameIdNameQualifier = $data['samlNameIdNameQualifier'];
        }
        if (isset($data['samlNameIdSPNameQualifier'])) {
            $nameIdSPNameQualifier = $data['samlNameIdSPNameQualifier'];
        }
        if (isset($data['samlSessionIndex'])) {
            $sessionIndex = $data['samlSessionIndex'];
        }
        if (isset($data['samlUserKey'])) {
            $samlUserKey = $data['samlUserKey'];
        }

        if (isset($data['sid'])) {
            $phpSessionID = $data['sid'];
        }

        return [$nameId, $nameIdFormat, $nameIdNameQualifier, $nameIdSPNameQualifier, $sessionIndex, $samlUserKey, $phpSessionID];
    }


    public static function getPatronData(int $patronID, $session_id = null, $findOne = true)
    {
        $data = [];
        $isLoggedInQuery = PatronActionQuery::create()
            ->filterByPatronId($patronID)
            ->filterByActionType(PatronActionPeer::SSO_LOGIN_OK);

        if ($session_id !== null) {
            $isLoggedInQuery->filterByActionNote("%$session_id%");
        }

        $isLoggedInQuery->orderByActionDate(Criteria::DESC);
        if ($findOne) {
            $isLoggedIn = $isLoggedInQuery->findOne();

            if ($isLoggedIn instanceof PatronAction) {
                $json = $isLoggedIn->getActionNote();
                $data = json_decode($json, true);
            }
        } else {
            $isLoggedInList = $isLoggedInQuery->find();
            foreach ($isLoggedInList as $isLoggedIn) {
                if ($isLoggedIn instanceof PatronAction) {
                    $json = $isLoggedIn->getActionNote();
                    $data[] = json_decode($json, true);
                }
            }
        }


        return $data;
    }

    /**
     * @param $errors
     * @return bool
     */
    public function isAuthenticated(&$errors)
    {
        $requestID = null;
        if (isset($_SESSION) && isset($_SESSION['AuthNRequestID'])) {
            $requestID = $_SESSION['AuthNRequestID'];
        }

        try {
            $auth = $this->getAuthObject();
            $auth->processResponse($requestID);

            $this->_samlAttributes = $auth->getAttributes();
            $this->_requestID = $requestID;

            $errors = $auth->getErrors(); // request is invalid, so we get errors
        } catch (Exception $e) {
            $errors[] = $e->getMessage(); // request is valid, but an exception occurred. (Or sigh, a validation exception is thrown)
            $this->_samlAttributes = null;
            return false;
        }

        return $auth->isAuthenticated();
    }


    /**
     * @param $errors
     * @return string
     */
    public function getMetadata(&$errors)
    {
        try {
            if ($this->isCustom() && file_exists($this->getSSoDir() . '/schemas/')) {
                // in order to perform correct xml validation we need to set the new path of the schema definitions,
                // that's no more relative to the onelogin settings.php file but to the override.php clavis file
                $this->getSamlSettings()->setSchemasPath($this->getSSoDir() . '/schemas/');
            }

            $metadata = $this->getSamlSettings()->getSPMetadata();
            $errors = $this->getSamlSettings()->validateMetadata($metadata);
            return $metadata;
        } catch (Exception $e) {
            $errors[] = $e->getMessage();
            return '';
        }
    }

    /**
     * @param $returnTo
     * @throws Saml2\Error
     */
    public function login($returnTo)
    {
        $auth = $this->getAuthObject();
        $auth->login($returnTo);
    }

    /**
     * @param $patronID
     * @param bool $fromSession
     * @param null $samlUK
     * @return bool|array
     * @throws Saml2\Error
     */
    public function logout($patronID, $fromSession = false, $samlUK = null, $stay = false)
    {
        list($nameId, $nameIdFormat, $nameIdNameQualifier, $nameIdSPNameQualifier, $sessionIndex, $samlUserKey, $phpSessionID) = $this->loadAuthData($patronID, $fromSession, $samlUK);
        if ($nameId && $samlUserKey === $samlUK) {
            $returnTo = $this->getSamlSettings()->getBaseURL();
            $auth = $this->getAuthObject();
            $redirect_params = $auth->logout($returnTo, [], $nameId, $sessionIndex, $stay, $nameIdFormat, $nameIdNameQualifier, $nameIdSPNameQualifier);
            $this->_samlAttributes = null;
            return $redirect_params ?? true;
        } else {
            Prado::log(sprintf("loadAuthData get data failed for patron id %s during logout", $patronID), TLogger::ERROR, 'SOAP');
        }
        return false;
    }


    /**
     * @param $requestID
     * @param $logoutCallback
     * @return array
     */
    public function processSingleLogoutInstance($requestID, $logoutCallback = null)
    {
        try {
            $auth = $this->getAuthObject();
            $auth->processSLO(false, $requestID, false, $logoutCallback);
            $errors = $auth->getErrors();
        } catch (Exception $e) {
            Prado::log(sprintf("Error processing SLO requestID %s: %s", $requestID, $e->getMessage()), TLogger::ERROR, 'SOAP');
            $errors[] = $e->getMessage();
        }
        return $errors;
    }
}