<?php

class ClavisToken
{
	private $secret;
	private $header;
	private $payload;
	private $token;

	/**
	 * Token constructor.
	 * @param array $payload
	 */
	private function __construct()
	{
		$this->setHeader();
		$this->secret = 'pfA8jGGm6HH9vtpYpgkM5i0C84XhOQiu9NCbsprD8vs=';
	}

	/**
	 * @param array $payload
	 * @return ClavisToken
	 */
	public static function create(): ClavisToken
	{
		return new self();
	}

	/**
	 * @param string $data
	 * @return string
	 */
	private function base64UrlEncode(string $data): string
	{
		$urlSafeData = strtr(base64_encode($data), '+/', '-_');
		return rtrim($urlSafeData, '=');
	}

	/**
	 * @param string $data
	 * @return string
	 */
	private function base64UrlDecode(string $data): string
	{
		$urlUnsafeData = strtr($data, '-_', '+/');
		$paddedData = str_pad($urlUnsafeData, strlen($data) % 4, '=', STR_PAD_RIGHT);
		return base64_decode($paddedData);
	}

	/**
	 * @param string $alg
	 * @param string $typ
	 */
	public function setHeader($alg = 'HS256', $typ = 'JWT'): ClavisToken
	{
		$this->header = [
			'alg' => $alg,
			'typ' => $typ
		];
		return $this;
	}

	/**
	 * @param array $payload
	 * @return ClavisToken
	 */
	public function setPayload(array $payload): ClavisToken
	{
//		Some of them are: iss (issuer), exp (expiration time), sub (subject), aud (audience);
		$this->payload = array_merge(
			['iss' => 'ClavisNG', 'sub' => 'LibrarianBot', 'aud' => 'Librarians'],
			$payload
		);
		return $this;
	}

	/**
	 * @return string
	 */
	public function build($payload): string
	{
		$this->setPayload($payload);
		$headerEncoded = $this->base64UrlEncode(json_encode($this->header));
		$payloadEncoded = $this->base64UrlEncode(json_encode($this->payload));

		// Delimit with period (.)
		$dataEncoded = "$headerEncoded.$payloadEncoded";

		$rawSignature = hash_hmac('sha256', $dataEncoded, $this->secret, true);
		$signatureEncoded = $this->base64UrlEncode($rawSignature);

		// Delimit with second period (.)
		return "$dataEncoded.$signatureEncoded";
	}


	/**
	 * @param $token
	 * @return bool
	 */
	public function verify(): bool
	{
		[$headerEncoded, $payloadEncoded, $signatureEncoded] = explode('.', $this->token);

		$dataEncoded = "$headerEncoded.$payloadEncoded";
		if ($signatureEncoded) {
			$signature = $this->base64UrlDecode($signatureEncoded);
			$rawSignature = hash_hmac('sha256', $dataEncoded, $this->secret, true);
			return hash_equals($rawSignature, $signature);
		}
		return false;
	}

	/**
	 * @param $token
	 * @return bool|mixed
	 */
	public function getPayload()
	{
		if ($this->verify()) {
			[$headerEncoded, $payloadEncoded, $signatureEncoded] = explode('.', $this->token);
			if ($payloadEncoded) {
				$payloadDecoded = $this->base64UrlDecode($payloadEncoded);
				return json_decode($payloadDecoded, true);
			}
			return false;
		}
		return false;
	}

	/**
	 * @param mixed $token
	 * @return ClavisToken
	 */
	public function setToken($token)
	{
		$this->token = $token;
		return $this;
	}


	/**
	 * @return mixed
	 */
	public function getToken()
	{
		return $this->token;
	}
}
