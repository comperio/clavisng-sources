<?php

/**
 * QueryBuilderPropelRuleConverter class file
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 * For Commercial Licenses and support please contact Comperio.
 * @link      http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license   http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version   2.9
 */
class QueryBuilderPropelRuleConverter implements IQueryBuilderRulesConverter
{
    protected $parser;
    protected $qb;
    protected $transformationRules;
    protected $propelQuery;

    /**
     * QueryBuilderPropelRuleConverter constructor.
     * @param IQueryBuilderToDB $queryBuilderToPropel
     * @param array $transformationRules
     * @param ModelCriteria $propelQuery
     */
    public function __construct(IQueryBuilderToDB $queryBuilderToPropel, array $transformationRules, $propelQuery)
    {
        $this->parser = function ($value) use ($queryBuilderToPropel, $transformationRules) {
            return $this->applyTransform($value, $queryBuilderToPropel, $transformationRules);
        };

        $this->qb = $queryBuilderToPropel;
        $this->transformationRules = $transformationRules;
        /** @var ModelCriteria propelQuery */
        $this->propelQuery = $propelQuery;
    }

    /**
     * @param IQueryBuilderToDB $qbToDBInterface
     * @param array $transformationRules
     * @param ModelCriteria $propelQuery
     * @return QueryBuilderPropelRuleConverter
     */
    public static function create(IQueryBuilderToDB $qbToDBInterface,
                                  array             $transformationRules,
                                  ModelCriteria     $propelQuery): QueryBuilderPropelRuleConverter
    {
        return new self($qbToDBInterface, $transformationRules, $propelQuery);
    }

    /**
     * @param stdClass $r
     * @param array $joinRules
     * @return ModelCriteria|null
     */
    public function convert(stdClass $r, array $joinRules = [])
    {
        /**
         * Tell if the current rule is empty or not. Recursively.
         * As soon as possible exit if not empty.
         * @param $r
         * @param $empty
         * @return void
         */
        $is_empty_rule = function ($r, &$empty) use (&$is_empty_rule, &$test_empty) {

            if ($empty === false) {
                return;
            }

            if (isset($r->condition)) {
                foreach ($r->rules as $rule) {
                    $is_empty_rule($rule, $empty);
                }
            } else {
                $empty = $empty && $test_empty($r);
            }
        };

        $test_empty = function ($rule) {

            $empty_operator = (
                ($rule->operator === 'not_null_and_not_empty') ||
                ($rule->operator === 'null_or_empty') ||
                ($rule->operator === 'is_empty') ||
                ($rule->operator === 'is_not_empty') ||
                ($rule->operator === 'is_null') ||
                ($rule->operator === 'is_not_null')
            );

            $empty_value = (trim($rule->value) === '' || !isset($rule->value) || strpos($rule->value, '{"id":null') === 0);

            return ($empty_value && !$empty_operator);
        };

        /**
         * @param                $id
         * @param                $combine_id
         * @param                $combine_array
         * @param                $criterion
         * @param ModelCriteria $q
         */
        $add_condition = function (&$id, &$combine_id, &$combine_array, $criterion, ModelCriteria &$q) {
            if ($criterion instanceof Criterion) {
                $id++;
                $combine_id .= $id;
                $combine_array[] = $id;
                $q->addCond($id, $criterion);
            }
        };

        /**
         * @param $rules
         * @param $condition
         * @param $id
         * @param $q
         * @return int
         */
        $process_node = function ($rules, $condition, int &$id, ModelCriteria &$q) use (&$process_node, &$joinRules, &$add_condition, $is_empty_rule, $test_empty) {
            $combine_id = '';
            $combine_array = [];

            foreach ($rules as $rule) {

                $empty = true;
                $is_empty_rule($rule, $empty);

                if (isset($rule->condition) && !$empty) {
                    // ------------------------------------------------
                    // NODE -------------------------------------------
                    // ------------------------------------------------
                    $node_id = $process_node($rule->rules, $rule->condition, $id, $q);
                    $combine_id .= $node_id;
                    $combine_array[] = $node_id;
                } else {
                    // ------------------------------------------------
                    // LEAF -------------------------------------------
                    // ------------------------------------------------
                    // skip empty rules so the librarian can compile only the fields of interest in a given query,
                    // particularly when using the default ones. A rule is empty when the value is empty and the
                    // operator is not equal to a null_or_empty operator.
                    if ($test_empty($rule)) {
                        continue;
                    }

                    $this->addJoinClause($joinRules, $q, $rule);
                    $this->matchAliasesFromJoinToTransformationRules($rule, $joinRules, $this->transformationRules, $q);

                    $criterion = $this->applyTransform($rule, $this->qb, $this->transformationRules);

                    if ($criterion instanceof Criterion) {
                        $add_condition($id, $combine_id, $combine_array, $criterion, $q);
                    }
                }
            }

            $criteria = $q->combine($combine_array, $condition, $combine_id);

            return (int)$combine_id;
        };

        $id = 0;
        $where_id = $process_node($r->rules, $r->condition, $id, $this->propelQuery);

        /** @var ModelCriteria $model_criteria */
        if ($where_id > 0) {
            $model_criteria = $this->propelQuery->where([(string)$where_id]);
            $sql = $model_criteria->toString();
            return $model_criteria;
        } else {
            $model_criteria = $this->propelQuery;
            $sql = $model_criteria->toString();
            return $model_criteria;
        }
    }

    private function matchAliasesFromJoinToTransformationRules($rule, $joinRules, &$transformationRules, Criteria $criteria)
    {
        if (array_key_exists($rule->id, $transformationRules)) {

            $transformationRule = $transformationRules[$rule->id];
            $table = strstr($rule->field, '.', true);
            $table_join_rules = $joinRules[$table];

            if (array_key_exists($table, $joinRules)
                && ($table_join_rules['isInJoin'] === true)
                && (array_key_exists('aliased_as', $table_join_rules))) {

                $transform_type = $transformationRule['transform_type'];
                $transform_params = $transformationRule['transform_param'][$transform_type];
                $t_rules = $transform_params['rules'];

                // change field name inside the transformation rules, with the aliased one from the corresponding table.
                foreach ($t_rules as $k => $r) {
                    $column = substr($t_rules[$k]['field'], strpos($t_rules[$k]['field'], '.') + 1);
                    $t_rules[$k]['field'] = strstr($table_join_rules['to'], '.', true) . '.' . $column;
                    $t_rules[$k]['aliased_as'] = strstr($table_join_rules['aliased_as'], '.', true) . '.' . $column;
                }
                $transformationRules[$rule->id]['transform_param'][$transform_type]['rules'] = $t_rules;
            }
        }
    }

    /**
     * @param $joinRules
     * @param $rule
     * @param $criteria
     */
    private function addJoinClause(array &$joinRules, ModelCriteria $criteria, &$rule)
    {
        $get_table_name = static function ($name) {
            return strstr($name, '.', true);
        };

        $get_table_column = static function ($name) {
            return substr($name, strpos($name, '.') + 1);
        };

        $table = $get_table_name($rule->field);
        $table_join_rules = $joinRules[$table];

        if ($table_join_rules) {
            /** @var array $table_join_rules */
            /** @var string $to */

            /* set the default for the right part of the join */
            $to = $table_join_rules['to'];

            /**
             * In case of  multiple join on the same table, set the  right part of the join ($the $to variable) accordingly
             * if the allow_multiple_join is set.
             */
            if (array_key_exists($table, $joinRules)
                && $table_join_rules['from']
                && $table_join_rules['to']
                && $table_join_rules['type']
                && $table_join_rules['allow_multiple_join'] // we can do multiple joins
                && $table_join_rules['isInJoin']) { // at least a join condition is already present
                /*
                 *  $c->addAlias("alias1", TablePeer::TABLE_NAME);
                 *  $c->addJoin(TablePeer::alias("alias1", TablePeer::PRIMARY_KEY_COLUMN), TablePeer::PRIMARY_KEY_COLUMN);
                 */
                $table_name = $get_table_name($table_join_rules['to']);
                $table_alias = $table_name . '_' . (int)$table_join_rules['num_joins'];
                $criteria->addAlias($table_alias, $table_name);

                // we keep track of the original table name in order to apply the change to the transformation_rules also
                // before calling the __apply_transform__ method.
                // Same as: PatronPropertyPeer::alias($alias_table, PatronPropertyPeer::PROPERTY_CLASS);
                $table_join_alias = $table_alias . '.' . $get_table_column($table_join_rules['to']);
                $table_join_rules['aliased_as'] = $table_join_alias;

                // update the current rule: set the field's alias value.
                $field_aliased_as = $table_alias . '.' . $get_table_column($rule->field);
                $rule->aliased_as = $field_aliased_as;

                // ...and finally we overwrite the default right part of the join with the aliased one.
                // in order for the join to take place.
                $to = $table_join_alias;
            }

            if ($table_join_rules['from'] != $to) {

                $criteria->addJoin($table_join_rules['from'], $to, $table_join_rules['type']);
                if (array_key_exists('setDistinct', $table_join_rules) && $table_join_rules['setDistinct'] === true) {
                    $criteria->setDistinct();
                }

                $table_join_rules['isInJoin'] = true;
                $table_join_rules['num_joins']++;
                $joinRules[$table] = $table_join_rules;
            }
        }
    }

    /**
     * @param                    $qbField
     * @param IQueryBuilderToDB $qbToDBInterface
     * @param                    $transformationRules
     * @return array|string|stdClass
     */
    private function applyTransform($qbField, IQueryBuilderToDB $qbToDBInterface, $transformationRules)
    {
        $transformationRule = array_key_exists($qbField->id, $transformationRules)
            ? $transformationRules[$qbField->id]
            : $qbField->field;

        if (array_key_exists($qbField->id, $transformationRules)) {
            $criterion = $this->getComplexCriterion($qbField, $qbToDBInterface, $transformationRule);
        } else {
            $criterion = $this->getSimpleCriterion($qbField, $qbToDBInterface, $transformationRule);
        }

        return $criterion;
    }


    private function getComplexCriterion($qbField, IQueryBuilderToDB $qbToDBInterface, array $transformationRule)
    {
        $field_map_to = $transformationRule;
        $field_value = $qbField->value;

        // se ho una mappatura uno a uno fra nome campo qb e campo nel backend corrente..
        if (!is_array($field_map_to['field_name'])) {
            $field_name = $field_map_to['field_name'];
        } else {
            // setto il campo di default per tutti gli altri operatori
            $field_name = $field_map_to['field_name']['default'];

            // ...a questo campo possono corrispondere piu' campi di ricerca nel backend corrente
            // a seconda dell'operatore. Controllo quindi se ho specificato un campo del backend,
            // specifico per questo operatore: in caso affermativo lo assegno...
            if (array_key_exists($qbField->operator, $field_map_to['field_name'])) {
                $field_name = $field_map_to['field_name'][$qbField->operator];
            }
        }


        if ($field_name === null) {
            $field_name = $qbField->field;
        }

        $transform_type = $field_map_to['transform_type'];
        $transform_params = $field_map_to['transform_param'][$transform_type];

        switch ($transform_type) {
            case 'operator_value_map':
                $operator_map = $transform_params['operator_map'];
                $value_map = $transform_params['value_map'];

                $val = array_key_exists($field_value, $value_map) ? $value_map[$field_value] : $field_value;
                $escaped_val = $qbToDBInterface->escapeUserInput($val);
//                $this->coalesceToType($qbField->type, $escaped_val);
                $criterion = $qbToDBInterface->getOperatorsMap($field_name, $operator_map[$field_value], $escaped_val);
                break;

            case 'inject_rules':
                $t_rules = $transform_params['rules'];

                foreach ($t_rules as $key => $rule) {
                    $t_rules[$key]['operator'] = $rule['operator'] !== '?' ? $rule['operator'] : $qbField->operator;
                    $t_rules[$key]['value'] = $rule['value'] !== '?' ? $rule['value'] : $qbField->value;
                    $t_rules[$key]['type'] = $rule['type'] !== '?' ? $rule['type'] : $qbField->type;

                    $escaped_val = $qbToDBInterface->escapeUserInput($t_rules[$key]['value']);
//                    $this->coalesceToType($qbField->type, $escaped_val);
                    $field = $t_rules[$key]['aliased_as'] ?? $t_rules[$key]['field'];
                    $to_inject_criterion[] = $qbToDBInterface->getOperatorsMap($field, $t_rules[$key]['operator'], $escaped_val);
                }
                $operatorMethod = (strtoupper($transform_params['condition']) === Criteria::LOGICAL_AND) ? 'addAnd' : 'addOr';

                /** @var Criterion $criterion */
                $criterion = array_shift($to_inject_criterion);
                foreach ($to_inject_criterion as $c) {
                    $criterion->$operatorMethod($c);
                } // ------------
                break;
            case 'openloans':
                $escaped_val = $qbToDBInterface->escapeUserInput($field_value);
//                $this->coalesceToType($qbField->type, $escaped_val);

                /** @var Criterion $c */
                $c = $qbToDBInterface->getOperatorsMap($field_name, $qbField->operator, $escaped_val);

                $criterion = null;

                $this->propelQuery
                    ->withColumn("(SELECT COUNT(*) FROM item itemopl WHERE itemopl.patron_id = patron.patron_id)", "numLoans")
                    ->addHaving($c);

                break;

            case 'allloans':
                $escaped_val = $qbToDBInterface->escapeUserInput($field_value);
//                $this->coalesceToType($qbField->type, $escaped_val);

                /** @var Criterion $c */
                $c = $qbToDBInterface->getOperatorsMap($field_name, $qbField->operator, $escaped_val);

                $criterion = null;

                $this->propelQuery
                    ->withColumn("(SELECT COUNT(*) FROM loan allloan WHERE allloan.patron_id = patron.patron_id)", "numAllLoans")
                    ->addHaving($c);

                break;
        }

        return $criterion;
    }

    /**
     * @param                    $qbField
     * @param IQueryBuilderToDB $qbToDBInterface
     * @param                    $field_name
     * @return mixed
     */
    private function getSimpleCriterion($qbField, IQueryBuilderToDB $qbToDBInterface, $field_name)
    {
        $value = $qbToDBInterface->escapeUserInput($qbField->value);

        $v = json_decode($qbField->value, true);
        $value = (json_last_error() === JSON_ERROR_NONE) && $v['id'] ? $v['id'] : $value;
//        $this->coalesceToType($qbField->type, $value);
        return $qbToDBInterface->getOperatorsMap($field_name, $qbField->operator, $value, $qbField->type);
    }


    /**
     * Cast the values to the type  declared in the filter definition
     * @param $type
     * @param $value
     */
    private function coalesceToType($type, &$value): void
    {
        $toDate = function (&$value) {
            $value = DateTime::createFromFormat("d-m-Y", $value);
            $value = ($value instanceof DateTime) ? $value : DateTime::createFromFormat("Y/m/d", $value);
            $value = ($value instanceof DateTime) ? $value->setTime(0, 0, 0) : null;
        };

        if ($type === 'date') {
            if (is_array($value)) {
                $toDate($value[0]);
                $toDate($value[1]);
            } else {
                $toDate($value);
            }
        }
    }
}
