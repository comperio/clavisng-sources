<?php
/**
 * ClavisNotificationEvent class
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 * For Commercial Licenses and support please contact Comperio.
 * @author    Dario Rigolin <dario@comperio.it>
 * @author    Marco Brancalion <marco@comperio.it>
 * @author    Ciro Mattia Gonano
 * @link      http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2019 Comperio srl
 * @license   http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version   2.10
 */

/**
 * ClavisNotificationEvent Class
 * @author  Mauro Seno <mauro.seno@comperio.it>
 * @version 2.10
 * @package Core
 * @since   2.10
 */
class ClavisNotificationEvent extends TBroadcastEventParameter
{
	private $_defaultOptions;

	/**
	 * ClavisNotificationEvent constructor.
	 * @param string     $name
	 * @param array|null $parameter
	 */

	public function __construct(string $name = '', array $parameter = null)
	{
		$this->_defaultOptions = self::getDefaultOptions();
		/*
		 * $parameter is an array expecting  a mandatory 'text' field and two optional
		 * fields:
		 * - 'level' (if present must be of type default,success,error,warning or info).
		 * - 'options' (if present must at least contain the keys of the default options).
		 */
		if (!array_key_exists('options', $parameter) || (null === $parameter['options'])) {
			$parameter['options'] = $this->_defaultOptions;
		} else {
			$parameter['options'] = array_merge($this->_defaultOptions, $parameter['options']);
		}

		$librarian_options = $this->getLibrarianNotificationOptions(Prado::getApplication()->getUser()->getLibrarian());
		$parameter['options'] = array_merge($parameter['options'], $librarian_options);

		if (!array_key_exists('level', $parameter) || null === $parameter['level']) {
			$parameter['level'] = 'default';
		}

		if (stripos('default,success,error,warning,info', $parameter['level']) === false) {
			$parameter['level'] = 'default';
		}

		if (!array_key_exists('text', $parameter) || null === $parameter['text']) {
			$parameter['text'] = '';
		}

		$parameter['options']['title'] = $this->getTitleFromLevel($parameter['level']);

		if ($parameter['level'] === 'error' && $parameter['options']['soundOnError']) {
			$parameter['options']['sound'] = true;
		}

		if ($parameter['level'] === 'warning' && $parameter['options']['soundOnWarning']) {
			$parameter['options']['sound'] = true;
		}

		parent::__construct($name, $parameter);
	}

	/**
	 * Get the appropriate title for a notification given the severity level.
	 * @param $level
	 * @return bool|string
	 */
	private function getTitleFromLevel($level)
	{
		$title = 'Info';
		switch ($level) {
			case  'success':
				$title = false;
				break;
			case 'warning':
				$title = 'Attenzione';
				break;
			case 'error':
				$title = 'Errore';
				break;
		}
		return $title;
	}

	/**
	 * @return array
	 */
	public static function getDefaultOptions()
	{
		// AVAILABLE OPTIONS
		// -------------------------------------------------------------------------------------------------------------
		//
		// title: true,                        // Title of notification. Do not include it for default title or set custom string. Set this false to disable title
		// size: 'normal',                     // normal, mini, large
		// soundPath: 'src/sounds/',           // The folder path where sounds are located
		// soundExt: '.ogg',                   // Default extension for all sounds
		// showClass: 'zoomIn',                // Show animation class.
		// hideClass: 'zoomOut',               // Hide animation class.
		// icon: true,                         // Icon of notification. Leave as is for default icon or set custom string
		// msg: '',                            // Message of notification
		// img: null,                          // Image source string
		// closable: true,                     // Make notifications closable
		// delay: 5000,                        // Hide notification after this time (in milliseconds)
		// delayIndicator: true,               // Show timer indicator
		// closeOnClick: true,                 // Close notifications by clicking on them
		// width: 400,                         // Width of notification box
		// sound: true,                        // Sound of notification. Set this false to disable sound. Leave as is for default sound or set custom soud path
		// position: "bottom right"            // Place to show notification. Available options: "top left", "top right", "bottom left", "bottom right"
		// iconSource: "bootstrap"             // "bootstrap" or "fontAwesome" the library which will be used for icons
		// rounded: false,                     // Whether to make notification corners rounded
		// messageHeight: 60,                  // Notification message maximum height. This is not for notification itself, this is for .lobibox-notify-msg
		// pauseDelayOnHover: true,            // When you mouse over on notification, delay will be paused, only if continueDelayOnInactiveTab is false.
		// onClickUrl: null,                   // The url which will be opened when notification is clicked
		// showAfterPrevious: false,           // Set this to true if you want notification not to be shown until previous notification is closed. This is useful for notification queues
		// continueDelayOnInactiveTab: true,

		$soundDir = Prado::getApplication()->getAssetManager()->getPublishedUrl(
			Clavis::getComponentBasePath('ClavisNotification')
		);

		return [
			'pauseDelayOnHover' => true,
			'continueDelayOnInactiveTab' => false,
			'iconSource' => 'fontAwesome',
			'messageHeight' => 100,
			'soundPath' => $soundDir . '/sounds/',
			'sound' => false,

			// user customizable default settings
			'delay' => 5000, // false for sticky but not persistent notification
			'size' => 'normal',
			'position' => 'top right',

			// clavis custom user settings
			'soundOnError' => false,
			'soundOnWarning' => false,
			'delay_time' => 5000
		];
	}

	/**
	 * @param \Librarian $librarian
	 * @return array
	 */
	public function getLibrarianNotificationOptions(Librarian $librarian)
	{
		$librarianPrefs = unserialize($librarian->getPreferences());
		$user_default = self::getUserDefaultNotificationOption();
		return array_merge($user_default, $this->toPrefs($librarianPrefs['popupNotification']));
	}


	public static function getUserDefaultNotificationOption($bool = false)
	{
		$default = self::getDefaultOptions();
		$user_default = [
			'enabled' => false,
			'delay' => $default['delay_time'],
			'delay_time' => $default['delay_time'],
			'size' => $default['size'],
			'position' => $default['position'],
			'soundOnError' => $default['soundOnError'],
			'soundOnWarning' => $default['soundOnWarning']
		];

		return $bool ? self::toBoolean($user_default) : $user_default;
	}

	/**
	 * @param $options
	 * @return array
	 */
	private static function toBoolean($options)
	{
		$default = self::getDefaultOptions();
		$bool = [];
		foreach ($options as $key => $value) {
			$bool[$key] = $options['key'] !== $default['key'];
		}

		$bool['delay_time'] = ($options['delay_time'] !== $default['delay_time']) ? $options['delay_time'] : $default['delay_time'];
		return $bool;
	}

	/**
	 * @param $boolPrefs
	 * @return mixed
	 */
	private function toPrefs($boolPrefs)
	{
		$prefs = [];
		if (is_array($boolPrefs)) {

			if ($boolPrefs['delay_time'] < 0 || $boolPrefs['delay_time'] > 60000) {
				$boolPrefs['delay_time'] = 5000;
			}

			$prefs['enabled'] = $boolPrefs['enabled'];
			$prefs['soundOnError'] = $boolPrefs['soundOnError'];
			$prefs['soundOnWarning'] = $boolPrefs['soundOnWarning'];
			$prefs['size'] = $boolPrefs['size'] ? 'large' : 'normal';

			$prefs['delay_time'] = $boolPrefs['delay_time'];
			$prefs['delay'] = $boolPrefs['delay'] ? false : $prefs['delay_time'];

			$prefs['position'] = $boolPrefs['position'] ? 'bottom right' : 'top right';
		}
		return $prefs;
	}
}