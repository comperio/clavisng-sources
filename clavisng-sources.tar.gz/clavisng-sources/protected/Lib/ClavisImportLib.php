<?php
/**
 * ClavisImportLib class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Dario Rigolin <dario@comperio.it>
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 ePortal Technologies
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Modules.Import
 */

/**
 * ClavisImportLib Class
 *
 * ClavisImportLib is a collection of function used to import Unimarc record into
 * Clavis and can be used as base library to all other import Scripts
 *
 * @author Dario Rigolin <dario@comperio.it>
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Modules.Import
 * @since 2.5.0
 */
class ClavisImportLib {

	/*
	 * case "a": $arr[Annata] = $sf[value]; break;
	  case "b": $arr[Volume] = $sf[value]; break;
	  case "c": $arr[DataFascicolo] = $sf[value]; break;
	  case "d": $arr[DataFascicolo2] = $sf[value]; break;
	  case "e": $arr[TipoFascicolo] = $sf[value]; break;
	  case "f": $arr[StatoFascicolo] = $sf[value]; break;
	  case "g": $arr[NumSerie] = $sf[value]; break;
	  case "h": $arr[NumSerie2] = $sf[value]; break;
	 *
	 * Stato 1=Ricevuto 2=Atteso 3=Lacuna 4=Doppio
	 * Tipo  1=Semplice 2=Multiplo 3=Supplemento
	 */

	public static function doLinkSerials() {
		$statoFasc = array('1');

		$importMans = ManifestationQuery::create()
			->setFormatter(ModelCriteria::FORMAT_ON_DEMAND)
			->findByManifestationStatus(ManifestationPeer::STATUS_IMPORT);

		foreach ($importMans as $book)
		{
			/* @var $book Manifestation */
			$tm = $book->getTurboMarc();

			if (array_key_exists('d209',$tm)) {
				echo "\nTrovato fascicolo {$book->getTitle()}";

				$annata = (string)$tm->d209->sa;
				$volume = (string)$tm->d209->sb;
				$data1 = (string)$tm->d209->sc;
				$data2 = (string)$tm->d209->sd;
				$tipo = (string)$tm->d209->se;
				$stato = (string)$tm->d209->sf;
				$num1 = (string)$tm->d209->sg;
				$num2 = (string)$tm->d209->sh;

				if (trim($annata) == '')
					$annata = $tm->d100->getCDF('a', 9);

				$numero = ($num2 != '') ? "{$num1} / {$num2} ({$annata})" : "{$num1} ({$annata})";

				$lmans = $book->getLManifestationsRelatedByManifestationIdUp();
				$lman461 = array();
				$lman464 = array();

				foreach ($lmans as $l) {
					if ($l->getLinkType() == 461)
						$lman461[] = $l;
					if ($l->getLinkType() == 464)
						$lman464[] = $l;
				}

				echo "\n\tNotizia superiore: ".count($lman461).
					"\n\tAnalitici: ".count($lman464).
					"\n\tTotali legami: ".count($lmans);

				if (count($lman461) > 0) {
					$lman = $lman461[0];
					$issue = new Issue();
					$issue->setManifestationId($lman->getManifestationIdDown());
					$issue->setIssueDate(str_replace('/', '-', $data1));
					$issue->setIssueNumber($numero);

					$issueType = array(
						'1' => 'N', '2' => 'S', '3' => 'T'
					);
					$issue->setIssueType($issueType[$tipo]);
					$issue->setIssueVolume($volume);
					$issue->setIssueYear($annata);
					$issue->setStartNumber($num1);
					$issue->setEndNumber($num2);
					$issue->save();

					$items = $book->getItems();
					foreach ($items as $item) {
						/* @var $item Item */
						$item->setManifestationId($lman->getManifestationIdDown());
						$item->setIssue($issue);
						$item->setIssueArrivalDate($item->getInventoryDate());
						$item->setIssueArrivalDateExpected($item->getInventoryDate());
						$item->setIssueNumber($numero);
						$issueStatus = array(
							'1' => 'A', '2' => 'N', '3' => 'M', '4' => 'A'
						);
						$item->setIssueStatus($issueStatus[$stato]);
						$item->save();
						$item->clearAllReferences(true);
					}

					// Certo analitici
					foreach ($lman464 as $lm) {
						/* @var $lm LManifestation */
						$nlm = new LManifestation();
						$nlm->setManifestationIdUp($issue->getManifestationId());
						$nlm->setManifestationIdDown($lm->getManifestationIdDown());
						$nlm->setLinkType($lm->getLinkType());
						$nlm->setLinkSequence($lm->getLinkSequence());
						$nlm->setIssue($issue);
						$lm->delete();
						$lm->clearAllReferences(true);
						$nlm->save();
						print "\n >>>>>>>>>>> Lego analitico";
					}
					$issue->clearAllReferences();
					$lman->clearAllReferences();
					$book->clearAllReferences(true);
					$book->delete();
				} else {
					print "\nNessun legame esistente!";
				}
			}
		}
	}

	public static function doLinkManifestations()
	{
		$importMans = ManifestationQuery::create()
			->setFormatter(ModelCriteria::FORMAT_ON_DEMAND)
			->findByManifestationStatus(ManifestationPeer::STATUS_IMPORT);
		$manCounter=1;
		foreach ($importMans as $book)
		{
			/* @var $book Manifestation */
			$tm = $book->getTurboMarc();
			$mainBid = (string)$tm->c001;
			echo "\nRecord [$mainBid] $manCounter";
			$manCounter++;

			if (array_key_exists('d200',$tm)) {
				$f200 = $tm->d200;
				$ind = array_key_exists('i1',$f200) ? (string)$f200['i1'] : ' ';
				if ($ind == '1' && array_key_exists('d461', $tm)) {
				   $f461 = $tm->d461;
				   $emb200 = $f461->getEmbeddedField('200');
				   $titleOfSup = ($emb200 instanceof TurboMarc && array_key_exists('sa', $emb200)) ?
					   (string)$emb200->sa.'. ' : '';
				   $book->setTitle($titleOfSup.$book->getTitle());
				   $book->save();
				}
			}
			foreach (array('d410','d461','d454','d423','d451','d421','d456','d422','d500') as $fld) // No 464
				if (array_key_exists($fld,$tm)) {
					foreach ($tm->$fld as $f4xx) {
						$emb200 = $f4xx->getEmbeddedField('200');
						$title = ($emb200 instanceof TurboMarc) ?
							trim((string)$emb200->sa) : 'EMBEDDED MANCATO';
						$bid = (string)$f4xx->getEmbeddedField('001');
						$ver = trim((string)$f4xx->sv);
						if (!$ver && array_key_exists('d225', $tm))
							$ver = $tm->d225->sv;

						echo "\n\t[$mainBid] => [$fld] => [$bid]-[$title $auth2]-[$ver]";
						switch ($fld)
						{
							case 'd410': // Creo Notizia.
								$manSerie = ManifestationQuery::create()->findOneByBid($bid);
								if (!$manSerie instanceof Manifestation) {
									$newr = TurboMarc::createRecord();
									$l = $newr->getLeader();
									$l->biblevel = 'c';
									$l->recstatus = 'n';
									$l->descrForm = ' ';
									$l->enclevel = ' ';
									$l->hiercode = ' ';
									$l->type = 'a';
									$newr->setLeader($l->getLeader());


									////////////// SONO ARRIVATO QUI

									$emb200 = $f4xx->getEmbeddedField('200');
									$seq = $emb200->getSubField('v');
									$emb200->setSubField('v', '');
									$emb300 = $f4xx->getEmbeddedField('300');

									$emb210 = $f4xx->getEmbeddedField('210');

									$f100 = $newr->addField('100');
									$f100->setCDF('a', 0, date('Ymd'));
									$f100->setCDF('a', 8, 'a');
									if ($emb210 != null) {
										$embDate = (string)$emb210->sd;
										if (preg_match('/(\d\d\d\d)/', $embDate, $matches))
											$emb100->setCDF('a', 9, $matches[0]);
									}
									$newr->setControlField('001', (string)$f4xx->getEmbeddedField('001'));
									$f200 = $newr->addField('200');
									$f200 =

									$newr->addField($emb200);
									if ($emb210 != null)
										$newr->addField($emb210);
									if ($emb300 != null)
										$newr->addField($emb300);

									$manSerie = self::doImportUnimarc($newr);
								}

								$lmm = new LManifestation();
								$lmm->setManifestationIdDown($manSerie->getManifestationId());
								$lmm->setManifestationIdUp($book->getManifestationId());
								$lmm->setLinkType($fld);
								$lmm->setLinkSequence($ver);

								try {
									$lmm->save();
								} catch (Exception $e) {
									print "Legame doppio " . $e->getMessage() . "\n";
								}

								$lmm->clearAllReferences(true);
								$manSerie->clearAllReferences(true);


								break;

							case "423":

								$f529 = new UnimarcField("529");
								$f529->addSubField("a", $title);
								$uni->addField($f529);
								$book->setUnimarc($uni->getTXTCompact());

								//Salva manifestation...
								$book->save();
								break;
							case "500":
							case "454": // Creo Autority tipo O (Opera)
								print "500/454 Start\n";

								if ($fld == "500") {
									$titbid = $f4xx->getSubField("3");
									$titlink = $f4xx->getSubField("a");
									$linktype = "500";
								} else {
									$emb4xx = $f4xx->getEmbeddedField("001");
									$titlink = $title;
									$titbid = $emb4xx->getSubField(" ");
									$linktype = "500";
								}
								$c = new Criteria();
								$c->add(AuthorityPeer::CLASS_CODE, $titbid);
								$a = AuthorityPeer::doSelectOne($c);

								if ($a == null) { // NOn esiste l'opera.
									print "Creo Work [$titbid]\n";

									$a = new Authority();
									$a->setAuthorityRectype('x');
									if ($fld == "500")
										$a->setAuthorityStatus('a');
									else
										$a->setAuthorityStatus('c');
									$a->setAuthorityCodlevel(AuthorityPeer::CODLVL_MED);
									$a->setAuthorityType(AuthorityPeer::TYPE_WORK);
									$uniw = array();
									$uniw['WorkTitle'] = $titlink;
									$a->setExtData(serialize($uniw));
									$a->setSortText($titlink);
									$a->setClassCode($titbid);
									$a->save();
									print "Work salvato\n";

									$c2 = new Criteria();
									$c2->add(LAuthorityManifestationPeer::MANIFESTATION_ID,$book->getManifestationId());
									$c2->add(LAuthorityManifestationPeer::LINK_TYPE, array("700", "701"), Criteria::IN);
									$c2->addAscendingOrderByColumn(LAuthorityManifestationPeer::LINK_TYPE);


									$lauthMan = LAuthorityManifestationPeer::doSelectOne($c2);
									print "Trovato autori\n";
									if ($lauthMan != null) {
										/* @var $lnkAuth Authority */
										$lnkAuth = $lauthMan->getAuthority();
										print "Seleziono autore\n";
										if ($lnkAuth->getAuthorityType() == AuthorityPeer::TYPE_PERSONALNAME) {
											// print ">>>>>[$fld] [$titbid] [$author]=[$lnkAuth] [$titlink]\n";
											print "Lego autore a work\n";
											$lnkAA = new LAuthority();
											$lnkAA->setAuthorityIdDown($a->getAuthorityId());
											$lnkAA->setAuthorityIdUp($lnkAuth->getAuthorityId());
											$lnkAA->setLinkType("BA");

											$lnkAA->save();
											print "Salvo 1\n";
											$a->save();
											//print "Salvo 2\n";
											$lnkAA->clearAllReferences(true);

										}
										print "Prima pulizia 1\n";
										$lnkAuth->clearAllReferences(true);
										$lauthMan->clearAllReferences(true);
										print "Dopo pulizia 1\n";
									} else {
										print ">>>>>[$fld] [$titbid] [$titlink]\n";
									}
								}
								print "Lego man ad auth\n";
								$lam = new LAuthorityManifestation();
								$lam->setManifestation($book);
								$lam->setAuthority($a);
								$lam->setLinkType($linktype);
								$lam->setRelatorCode(NULL);
								try {
									$lam->save();
								} catch (Exception $e) {
									print "Link Autore doppio\n";
								}
								$lam->clearAllReferences();
								$a->clearAllReferences();
								print("500/454 Fine\n");

								break;


							default:
								$cm = new Criteria();
								$cm->add(ManifestationPeer::BID, $bid);
								$cm->add(ManifestationPeer::MANIFESTATION_STATUS, "D");
								$mup = ManifestationPeer::doSelectOne($cm);
								if ($mup != null) {
									print "[Lego $fld con " . $mup->getBID() . "\n";

									$lmm = new LManifestation();
									$lmm->setManifestationIdDown($mup->getManifestationId());
									$lmm->setManifestationIdUp($book->getManifestationId());
									$lmm->setLinkType($fld);

									if (trim($ver) == "") {
										$uni2 = new UnimarcRecord();
										$uni2->parseTXTCompact($mup->getUnimarc());

										if ($uni2->existsField("225")) {
											$ver = $uni2->getSubField("225", "v");
										}
									}

									$lmm->setLinkSequence($ver);

									try {
										$lmm->save();
									} catch (Exception $e) {
										print "Legame doppio " . $e->getMessage() . "\n";
									}

									$lmm->clearAllReferences(true);
									$mup->clearAllReferences(true);
								}


								break;
						}

						//$uni->deleteField($fld);
					}
				}
			$book->clearAllReferences(true);
		}
	}

	public static function loadLibraries() {
		$library = array();
		foreach (LibraryQuery::create()->find() as $lib)
			$library[$lib->getLibraryCode()] = $lib;
	}

	public static function loadLibrariesViaLabel() {
		$library = array();
		foreach (LibraryQuery::create()->find() as $lib)
			$library[$lib->getLabel()] = $lib;
	}

	/**
	 * Import a manifestation
	 *
	 * @param TurboMarc $tm
	 * @return Manifestation
	 */
	public static function doImportUnimarc(TurboMarc $tm, $link461=false) {
		global $records;

		if (array_key_exists('d299',$tm)) {
			$vietato = (string)$tm->d299->sa;
			$copyright = (string)$tm->d299->sb;
		} else {
			$vietato = '';
			$copyright = '';
		}

		if (array_key_exists('d109',$tm)) {
			$extraBibType = (string)$tm->d109->sa;
			unset($tm->d109);
		}

		if (array_key_exists('d399', $tm)) {
			$nota399a = (string)$tm->d399->sa;
			$nota399b = (string)$tm->d399->sb;
			if (trim($nota399a) != '')
				$tm->addField(321)->addSubField('a', $nota399a);
			if (trim($nota399b) != '')
				$tm->addField(307)->addSubField('a', $nota399b);
		}

		if (array_key_exists('d390', $tm))
			$tm->addField(514)->addSubField('a', (string)$tm->d390->sa);

		if (array_key_exists('d520', $tm))
			$tm->addField(330)->addSubField('a', (string)$tm->d520->sa);

		if (array_key_exists('d461', $tm) && $link461) {
			$title = '';
			$emb200 = $tm->d461->getEmbeddedField('200');
			if ($emb200 != null)
				$title = $emb200->getString(" ");	// WTF?!?
			$emb210 = $f4xx->getEmbeddedField('210');
			if ($emb210 != null)
				$title .= ". - " . $emb210->getString(" ");
			$emb215 = $f4xx->getEmbeddedField('215');
			if ($emb215 != null)
				$title .= ". - " . $emb215->getString(" ");
			$tm->addField(327)->addSubField('a', "Fa parte di: {$title}");
		}

		if (array_key_exists('d330',$tm)) {
			foreach ($tm->d330 as $fld) {
				$nota330a = (string)$fld->sa;
				$nota3309 = trim((string)$tm->d330->s9);
				switch ($nota3309) {
					case 'EDITORIALE':
						$fld->sa .= " (Fonte editoriale)";
						break;
					case 'LIBER01':
						$fld->sa .= " (Fonte LiberDatabase: Sommario)";
						break;
					case 'LIBER02':
						$fld->sa .= " (Fonte LiberDatabase: caratteristiche formali)";
						break;
				}
			}
		}

		/* @var $l TurboMarcLeader */
		$l = $tm->getLeader();

		$man = new Manifestation();
		$man->setBibLevel(strtolower($l->biblevel));
		$man->setBibType(strtolower($l->type) . '01');
		$man->setRating($vietato);
		$man->setLoanableSince(str_replace("/", "-", $copyright));

		switch (strtolower($l->type)) {
			case 'a':
				$man->setBibTypeFirst(1);
				break;
			case 'b':
				$man->setBibTypeFirst(2);
				break;
			case 'c':
				$man->setBibTypeFirst(2);
				break;
			case 'd':
				$man->setBibTypeFirst(2);
				break;
			case 'e':
				$man->setBibTypeFirst(1);
				break;
			case 'f':
				$man->setBibTypeFirst(2);
				break;
			case 'g':
				$man->setBibTypeFirst(3);
				break;
			case 'i':
				$man->setBibTypeFirst(5);
				break;
			case 'j':
				$man->setBibTypeFirst(4);
				break;
			case 'k':
				$man->setBibTypeFirst(6);
				break;
			case 'l':
				$man->setBibTypeFirst(7);
				break;
			case 'm':
				$man->setBibTypeFirst(9);
				break;
			case 'r':
				$man->setBibTypeFirst(8);
				break;
		}

		$man->setCatalogationLevel(0);
		$man->setManifestationStatus(ManifestationPeer::STATUS_IMPORT);
		$man->syncTitle();
		$man->setAuthor($tm->getAuthor());

		$man->setBid((string)$tm->getControlField('001'));
		$man->setEan((string)$tm->d073->sa);
		$man->setIsbnissn((string)$tm->d010->sa);
		$man->setEditionLanguage((string)$tm->d101->sa);
		$editionDate = $tm->d100->getCDF('a',9);
		if (intval($editionDate) == 0) {
			$editionDate = (string)$tm->d210->sd;
			$matches = array();
			if (preg_match("/(\d+)/", $editionDate)) {
				$editionDate = intval($matches[1]);
			} else {
				$editionDate = 0;
			}
		}
		if ($editionDate > 0 && substr($man->getBibType(), 0, 1) == 'g') {
			// Calcolo 18 mesi per DVD
			$man->setLoanableSince(sprintf("%4d-07-01", $editionDate + 1));
		}
		$man->setEditionDate($editionDate);
		$man->setPublisher(array_key_exists('d210',$tm) ? (string)$tm->d210->sa.' '.(string)$tm->d210->sc : '');
		$man->setUnimarc($tm->asXML());
		$man->save();
		$buffer = '';
		foreach (array(700, 701, 702, 710, 711, 712, 720, 721, 722) as $fld) {
			if ($unimarc->existsField($fld)) {
				for ($i = 0; $i < $unimarc->getFieldCount($fld); ++$i) {

					$author = $unimarc->getAuthor($fld, $i);
					$linktype = 700 + (intval($fld) % 10);
					$fld7xx = $unimarc->getField($fld, $i);
					$relatorcode = $fld7xx->getSubField('4');
					$c = new Criteria();
					switch (substr($fld, 1, 1)) {
						case "0":
							$c->add(AuthorityPeer::AUTHORITY_TYPE, AuthorityPeer::TYPE_PERSONALNAME);
							break;
						case "1":
							$c->add(AuthorityPeer::AUTHORITY_TYPE, AuthorityPeer::TYPE_CORPORATEBODYNAME);
							break;
						case "2":
							$c->add(AuthorityPeer::AUTHORITY_TYPE, AuthorityPeer::TYPE_FAMILYNAME);
							break;
					}

					$c->add(AuthorityPeer::SORT_TEXT, $author);

					$a = AuthorityPeer::doSelectOne($c);
					if ($a == null) {
						$a = new Authority();
						$a->setAuthorityRectype('x');
						$a->setAuthorityStatus('c');
						$a->setAuthorityCodlevel(AuthorityPeer::CODLVL_MED);

						switch (substr($fld, 1, 1)) {
							case "0":
								$a->setAuthorityType(AuthorityPeer::TYPE_PERSONALNAME);
								break;
							case "1":
								$a->setAuthorityType(AuthorityPeer::TYPE_CORPORATEBODYNAME);
								break;
							case "2":
								$a->setAuthorityType(AuthorityPeer::TYPE_FAMILYNAME);
								break;
						}

						$a->setSortText($author);
						$a->setFullText($author);

						$a->save();
						print "Autore: $author [CREATO]\n";
					} else if (LAuthorityManifestationPeer::retrieveByPK($a->getAuthorityId(), $man->getManifestationId(), $linktype, $relatorcode) != null) {
						continue;
					} else {
						print "Autore: $author [TROVATO]\n";
					}
					$lam = new LAuthorityManifestation();
					$lam->setManifestation($man);
					$lam->setAuthority($a);
					$lam->setLinkType($linktype);
					$lam->setRelatorCode($relatorcode);
					try {
						$lam->save();
					} catch (Exception $e) {
						print "Link Autore doppio\n";
					}
					$lam->clearAllReferences();
					$a->clearAllReferences();
				}
			}
		}

		for ($i = 0; $i < $unimarc->getFieldCount("676"); ++$i) {

			$f676 = $unimarc->getField('676', $i);
			$class = $f676->getSubField('a');
			$classTxt = $f676->getSubField('c');
			$classVer = $f676->getSubField('v');
			$c = new Criteria();
			$c->add(AuthorityPeer::CLASS_CODE, $class);
			$a = AuthorityPeer::doSelectOne($c);
			if ($a == null) {
				$a = new Authority();
				$a->setAuthorityRectype('x');
				$a->setAuthorityStatus('c');
				$a->setAuthorityCodlevel(AuthorityPeer::CODLVL_MED);
				$a->setAuthorityType(AuthorityPeer::TYPE_CLASS);
				$a->setClassCode($class);
				$a->setSortText("$class $classTxt");
				$a->setFullText("$class $classTxt");
				$a->setExtData(serialize(array('ClassDescription' => $classTxt,
							'ClassType' => '676', 'ClassEdition' => $classVer)));
				$a->save();
				//print "Classe: $classe Versione: $classeVer Descrizione: $classeTxt [CREATO]\n";
			} else {
				//print "Classe: $classe Versione: $classeVer Descrizione: $classeTxt [TROVATA]\n";
			}
			$lam = new LAuthorityManifestation();
			$lam->setManifestation($man);
			$lam->setAuthority($a);
			$lam->setLinkType(676);
			try {
				$lam->save();
			} catch (Exception $e) {

			}
			$lam->clearAllReferences();
			$a->clearAllReferences();
		}

		if ($unimarc->existsField('620')) {
			$f620 = $unimarc->getField('620');
			$place = $f620->getSubField('d');

			$c = new Criteria();
			$c->add(AuthorityPeer::AUTHORITY_TYPE, AuthorityPeer::TYPE_PUBPLACE);
			$c->add(AuthorityPeer::SORT_TEXT, $place);
			$a = AuthorityPeer::doSelectOne($c);
			if ($a == null) {
				$a = new Authority();
				$a->setAuthorityRectype('x');
				$a->setAuthorityStatus('c');
				$a->setAuthorityCodlevel(AuthorityPeer::CODLVL_MED);
				$a->setAuthorityType(AuthorityPeer::TYPE_PUBPLACE);

				$a->setSortText($place);
				$a->setFullText($place);

				$a->save();
				//print "Classe: $classe Versione: $classeVer Descrizione: $classeTxt [CREATO]\n";
			} else {
				//print "Classe: $classe Versione: $classeVer Descrizione: $classeTxt [TROVATA]\n";
			}
			$lam = new LAuthorityManifestation();
			$lam->setManifestation($man);
			$lam->setAuthority($a);
			$lam->setLinkType(620);
			$lam->save();
			$lam->clearAllReferences();
			$a->clearAllReferences();
		}

		// replaces Liber fields processing
		TurbomarcConversion::LiberDatabase($unimarc);

		foreach (array(600, 601, 602, 603, 604, 605, 606, 607, 610, 615, 626, 660, 661, 670, 960) as $fld) {
			//for ($fld=600; $fld<=610; ++$fld) {
			if ($unimarc->existsField($fld)) {
				for ($i = 0; $i < $unimarc->getFieldCount($fld); ++$i) {

					$f6xx = $unimarc->getField($fld, $i);
					$subj = trim($unimarc->getSubField($fld, 'a', $i));

					$scc = $unimarc->getSubFieldCount($fld, 'x', $i);
					for ($s1 = 0; $s1 < $scc; $s1++)
						$subj .= " - " . trim($unimarc->getSubField($fld, 'x', $i, $s1));

					if ($fld == 960) {
						$soggettario = "L";
					} else {
						$soggettario = $unimarc->getSubField($fld, '2', $i);
					}
					$tipo = $unimarc->getSubField($fld, 'y', $i); // Only on 960
					//$subj = $f6xx->getString(" - ");

					if (trim($soggettario) == "") {
						$soggettario = "G";
					}

					$c = new Criteria();
					$c->add(AuthorityPeer::SORT_TEXT, $subj);
					$c->add(AuthorityPeer::AUTHORITY_TYPE, AuthorityPeer::TYPE_SUBJECT);
					$c->add(AuthorityPeer::SUBJECT_CLASS, $soggettario);

					$a = AuthorityPeer::doSelectOne($c);
					if ($a == null) {
						$a = createSubject($subj, $soggettario);
						print "Sogg: $subj [CREATO]\n";
					} else if (LAuthorityManifestationPeer::retrieveByPK($a->getAuthorityId(), $man->getManifestationId(), $fld, null) != null) {
						continue;
					} else {
						print"Sogg: $subj [TROVATO]\n";
					}
					$lam = new LAuthorityManifestation();
					$lam->setManifestation($man);
					$lam->setAuthority($a);

					if ($tipo == "1")
						$lam->setLinkType(606);
					elseif ($tipo == "2")
						$lam->setLinkType(699);
					else
						$lam->setLinkType($fld);


					try {
						$lam->save();
					} catch (Exception $e) {
						print "Duplicato \n";
					}
					$lam->clearAllReferences();
					$a->clearAllReferences();
				}
			}
		}


		try {
			//  $man->doIndex($indexUrl,$xslPath);
		} catch (Exception $e) {
			//  var_dump($man->getFullUnimarc()->getXML());
		}


		return $man;
	}

	public static function doImportItems($library, $invSerieId, $man, $unimarc) {
		$f950count = $unimarc->getFieldCount('950');

		for ($f = 0; $f < $f950count; $f++) {
			$item = new Item();
			$item->setManifestationId($man->getManifestationId());

			/* @var $f950 UnimarcField */
			$f950 = $unimarc->getField('950', $f);
			$f950a = $f950->getSubField('a');

			$invdate = $f950->getSubField('b');
			if (preg_match('!(\d{2})/(\d{2})/(\d{4})!', $invdate, $matches))
				if ($matches[3] > 1969 && $matches[3] < 2030)
					$item->setInventoryDate("{$matches[3]}-{$matches[2]}-{$matches[1]}");

			$f950e = $f950->getSubField('e');
			if ($f950e) {
				$item->setCollocation(trim(substr($f950e, 0, 50)));
			}

			$f950s = $f950->getSubField('s');
			if ($f950s) {
				$item->setItemMedia($f950s);
			}

			$f950f = $f950->getSubField('f');
			if ($f950f) {
				$physicalmap = array("51" => 'B', "71" => 'D', "01" => 'A', "99" => 'E');
				$loanmap = array("01" => 'B', "60" => 'B', "53" => 'A', '51' => 'D', '52' => 'F');
				$item->setPhysicalStatus($physicalmap[trim(substr($f950f, 0, 3))]);
				$item->setLoanClass($loanmap[trim(substr($f950f, 3, 3))]);
			}

			$item->setItemStatus('F');
			$item->setItemMedia('F');
			$item->setLoanStatus('A');
			$item->setUsageCount(0);
			$item->setOpacVisible(true);

			// TO_DO 950d ubicazione -> sezione

			$item->setInventoryNumber(intval(substr($f950a, 8, 9)));
			$item->setTitle($man->getTitle());

			$f950g = $f950->getSubField('g');
			if ($f950g) {
				$acquiremap = array(
					'B' => 'B',
					'A' => 'C',
					'U' => 'C',
					'M' => 'O',
					'D' => 'E',
					'R' => 'M',
					'F' => 'O',
					'P' => 'O',
					'S' => 'N');
				$currencymap = array('ITL' => 'LIT', 'EUR' => 'EUR', 'USD' => 'USD', 'GBP' => 'GBP');
				$item->setItemSource($acquiremap[trim(substr($f950g, 0, 3))]);
				$currency = trim(substr($f950g, 3, 3));
				if (array_key_exists($currency, $currencymap))
					$item->setCurrency($currencymap[$currency]);
				$item->setInventoryValue(trim(substr($f950g, 6, 12)));
			}

			$f950i = $f950->getSubField('i');
			if ($f950i) {
				$discardmap = array("01 " => 'E', "02 " => 'I', "03 " => 'H');
				if (isset($discardmap[substr($f950i, 0, 3)]))
					$item->setItemStatus($discardmap[substr($f950i, 0, 3)]);
				else
					$item->setItemStatus('F');

				$item->setCustomField2(strtotime(substr($f950i, 3, 10)));
			}
			$item->setCustomField1('AMBROS');

			$libCode = trim(substr($f950a, 0, 7));
			$invSerie = substr($f950a, 7, 1);

			$item->setInventorySerieId($invSerie);



			$item->setActualLibraryId($library[$libCode]);
			$item->setHomeLibraryId($library[$libCode]);
			$item->setOwnerLibraryId($library[$libCode]);

			$item->save();


			$f950p = trim($f950->getSubField('p'));

			if ($f950p != "") {
				$c = new Criteria();
				$c->add(AuthorityPeer::SORT_TEXT, $f950p);
				$a = AuthorityPeer::doSelectOne($c);
				if ($a == null) {
					$a = new Authority();
					$a->setAuthorityRectype('x');
					$a->setAuthorityStatus('c');
					$a->setAuthorityCodlevel(AuthorityPeer::CODLVL_MED);
					$a->setAuthorityType(AuthorityPeer::TYPE_PERSONALNAME);

					$a->setSortText($f950p);
					$a->setFullText($f950p);

					$a->save();
					print "Possessore: $f950p [CREATO]\n";
				} else if (LAuthorityItemPeer::retrieveByPK($a->getAuthorityId(), $item->getItemId(), 700, 390) != null) {
					continue;
				} else {
					print "Possessore: $author [TROVATO]\n";
				}
				$lam = new LAuthorityItem();
				$lam->setItem($item);
				$lam->setAuthority($a);
				$lam->setLinkType(700);
				$lam->setRelatorCode(390);
				try {
					$lam->save();
				} catch (Exception $e) {
					print "Link Possessore doppio\n";
				}
				$lam->clearAllReferences(true);
				$a->clearAllReferences(true);
			}

			$f950n = trim($f950->getSubField('n'));
			if ($f950n != "") {
				$inote = new ItemNote();
				$inote->setItem($item);
				$inote->setNoteType(ItemNotePeer::NOTETYPE_ITEMRELATED);
				$inote->setNote($f950n);
				$inote->save();
				$inote->clearAllReferences(true);
			}
			$item->clearAllReferences(true);
		}
	}

	public static function doImportItemsSOL($library, $invSerieId, $man, $unimarc) {
		$f950count = $unimarc->getFieldCount('950');

		for ($f = 0; $f < $f950count; $f++) {

			/* @var $f950 UnimarcField */
			$f950 = $unimarc->getField('950', $f);

			$f950a = trim($f950->getSubField('a')); // Biblioteca

			$f950eCount = $f950->getSubFieldCount("e");

			for ($sf = 0; $sf < $f950eCount; $sf++) {

				$f950d = $f950->getSubField('d', $sf); // Collocazione [GE RAG       035.1                   NUO         ]

				$bib = trim(substr($f950d, 0, 3));
				$sez = trim(substr($f950d, 3, 10));
				$col = trim(substr($f950d, 13, 24));
				$spe = trim(substr($f950d, 37, 12));

				$f950e = $f950->getSubField('e', $sf); // Inventario [SV    1119              1                   Milano : A. Mondadori, 1958]
				/*
				  00000000001111111111222222222233333333334444444444
				  01234567890123456789012345678901234567890123456789
				  $e BS SLV147               2
				  $e BS BAL123                                   B
				  $e BS BAV45                                    Possedute 2 copie
				  $e CO    29351             4
				 */
				$bib2 = trim(substr($f950e, 0, 3));
				$ser = trim(substr($f950e, 3, 3));
				$inv = trim(substr($f950e, 6, 10));

				$seq = trim(substr($f950e, 24, 20));
				$note = trim(substr($f950e, 45));
				/*
				  if(!isset($library[$bib]) && !isset($library[$ser])) {
				  print "$f950a [$bib] [$ser]\n";
				  exit(0);
				  }
				  if(isset($library[$bib]))
				  $librayId = $library[$ser];
				  else
				  $librayId = $library[$ser];
				 */
				if (!isset($library[$f950a])) {
					print "[$f950a] [$bib][$ser]\n";
					print_r($library);
					//    exit(0);
				}

				print "LIB>>>>>>>>>>>> [$f950a] [$bib][$ser] [" . $library[$f950a] . "]\n";
				$libraryId = $library[$f950a];

				// exit(0);

				$item = new Item();
				$item->setManifestationId($man->getManifestationId());
				$item->setTitle($man->getTitle());
				$item->setInventorySerieId($ser);

				$item->setInventoryNumber($inv);

				$item->setSection($sez);
				$item->setCollocation($col);
				$item->setSpecification($spe);
				$item->setSequence1($seq);
				$item->setSequence2($note);

				$item->setOwnerLibraryId($libraryId);
				$item->setHomeLibraryId($libraryId);
				$item->setActualLibraryId($libraryId);

				$item->setItemStatus('F');

				$item->setItemMedia('F');
				$item->setLoanStatus('A');
				$item->setUsageCount(0);
				$item->setOpacVisible(true);

				$item->setCustomField1("$bib2 $ser $inv $seq");
				$item->setCustomField2($note);

				$item->save();
				$item->setBarcode($ser . $inv);
				$item->save();

				$item->clearAllReferences(true);
			}
		}
	}

	public static function doImportItemsSebina($library, $invSerieId, $man, $unimarc) {
		$f950count = $unimarc->getFieldCount('950');


		if ($unimarc->existsField("954")) {
			$consNote = new ConsistencyNote();

			$consNote->setManifestation($man);
			$consNote->setLibraryId(1);
			$consNote->setTextNote($unimarc->getSubField("954", "a"));

			$consNote->save();
		} else {
			$consNote = null;
		}

		if ($unimarc->existsField("952") && $unimarc->getSubField("952", "a") == "abbonato: Y") {
			$abbon = new Subscription();

			$abbon->setManifestation($man);
			$abbon->setLibraryId(1);

			$abbon->setNotes("Importato");
			$abbon->setSubscriptionStatus("A");
			$abbon->setSubscriptionType("A");
			$abbon->setManagement("A");

			$abbon->save();
		} else {
			$abbon = null;
		}


		for ($f = 0; $f < $f950count; $f++) {
			$item = new Item();
			$item->setManifestationId($man->getManifestationId());



			/* @var $f950 UnimarcField */
			$f950 = $unimarc->getField('950', $f);
			$f950d = $f950->getSubField('d');
			$f950e = $f950->getSubField('e');
			$f950f = $f950->getSubField('f');
			$f950g = $f950->getSubField('g');
			$f950p = $f950->getSubField('p');
			$f950z = $f950->getSubField('z');


			$noteExtra = substr($f950e, 43);

			if ($unimarc->existsField("951", $f)) {
				$f951 = $unimarc->getField('951', $f);
				$f951a = $f951->getSubField('a');
			} else
				$f951a = "";

			try {
				$invdate = new DateTime(substr($f950e, 15, 4) . "-" . substr($f950e, 19, 2) . "-" . substr($f950e, 21, 2) . " 00:00:00");
				$item->setInventoryDate($invdate);
			} catch (Exception $e) {
				print "Data di inventariazione errata [$f950e]\n";
			}


			$libCode = substr($f950d, 0, 2);
			$item->setCollocation(substr($f950d, 2));
			$item->setSection($f950g);
			$item->setSpecification($f951a);
			$item->setInventoryNumber(intval(substr($f950e, 5, 9)));

			$item->setItemStatus('F');

			$item->setItemMedia('F');

			if ($consNote != null)
				$item->setConsistencyNote($consNote);

			if ($abbon != null)
				$item->setSubscriptionId($abbon->getSubscriptionId());


			$item->setLoanStatus('A');
			$item->setUsageCount(0);
			$item->setOpacVisible(true);

			$item->setInventorySerieId($library[$libCode]);
			$item->setActualLibraryId($library[$libCode]);
			$item->setHomeLibraryId($library[$libCode]);
			$item->setOwnerLibraryId($library[$libCode]);

			$item->save();

			if (trim($noteExtra) != "") {
				$inote = new ItemNote();
				$inote->setItem($item);
				$inote->setNoteType("a");
				$inote->setNote($noteExtra);
				$inote->save();

				$inote->clearAllReferences(true);
			}


			if (strtolower($unimarc->biblevel) == 's') {
				$issue = new Issue();

				$issue->setIssueNumber($f950p);
				$issue->setIssueNote($f950p);
				$issue->setIssueType("N");


				$issue->setManifestation($man);

				$issue->save();

				$item->setIssue($issue);
				$item->save();

				$issue->clearAllReferences();
			}
			$item->clearAllReferences();
		}
	}

	public static function createSubject($subjectTxt, $subjClass) {
		$subject = new Authority();

		$subject->setSortText($subjectTxt);

		$subject->setAuthorityCodlevel(AuthorityPeer::CODLVL_MED);
		$subject->setAuthorityRectype(AuthorityPeer::RECTYPE_ACCEPTED);
		$subject->setAuthorityType(AuthorityPeer::TYPE_SUBJECT);
		$subject->setAuthorityStatus("c");
		$subject->setSubjectClass($subjClass);
		$subject->save();

		/** @var $subject Authority */
		$first = $parent = null;
		$elements = $newParts = $partsST = $newunimarc = array();

		$unimarc = array();

		$elements = array_merge(explode(' - ', $subjectTxt));
		$pos = 0;

		foreach ($elements as $e) {
			if (trim($e) == '')
				continue;
			$crit = new Criteria();
			$crit->add(AuthorityPeer::SORT_TEXT, trim($e), Criteria::LIKE);
			$crit->add(AuthorityPeer::AUTHORITY_TYPE, AuthorityPeer::TYPE_SUBJECT, Criteria::NOT_EQUAL);

			$authorities = AuthorityPeer::doSelect($crit);
			if (count($authorities) > 1) {
				$auth = $authorities[0];
			} else {
				$auth = new Authority();
				$auth->setAuthorityType(AuthorityPeer::TYPE_ARGUMENT);
				$auth->setAuthorityRectype('x');
				$auth->setAuthorityCodlevel(0);
				$auth->setAuthorityStatus('c');
				if (array_key_exists('Note', $unimarc)) {
					$authuni = array('Note' => $unimarc['Note']);
					$auth->setExtData(serialize($authuni));
				}
				$auth->setSortText(trim($e));
				$auth->save();
				echo "\nSaved auth " . $auth->getAuthorityId();
			}
			$aID = $auth->getAuthorityId();
			$aST = $auth->getSortText();
			if ($auth->getAuthorityType() == self::TYPE_PLACE) {
				$type = 'L';
			} else if ($auth->getAuthoritySubtype() == self::SUBTYPE_THING_FORM) {
				$type = 'F';
			} else if ($auth->getAuthoritySubtype() == self::SUBTYPE_TIME) {
				$type = 'T';
			} else {
				$type = 'A';
			}
			$partsST[] = $aST;
			$l = new LSubject();
			$l->setAuthorityRelatedBySubjectId($subject);
			$l->setAuthorityId($aID);
			$l->setPosition($pos);
			$l->setType($type);
			$l->save();
			++$pos;
			$l->clearAllReferences(true);
		}

		if (array_key_exists('Note', $unimarc) && $unimarc['Note'] != 'Nessuna nota')
			$newunimarc['Note'] = $unimarc['Note'];
		$subject->setExtData(serialize($newunimarc));
		$subject->save();
		$subject->clearAllReferences(true);

		echo "\nUpdated Subject ID " . $subject->getAuthorityId();
		return $subject;
	}

}
