<?php
/**
 * OverLibMWS class file.
 *
 * AUTHOR NOTICE
 * This component is written using overlibmws revision 228 (20.01.2007). It may
 * or may not work with later versions. Please check the current revision at
 * http://www.macridesweb.com/oltest/changeHistory.html#bottom
 * I'll try to keep it up-to-date; please drop me a line if you get an outdated
 * version.
 *
 * Feedback is greatly appreciated: if you're improving, I'll be glad if you drop me a line.
 *
 * @author Ciro Mattia Gonano <ciro@winged.it> (Prado component)
 * @author Foteos Macrides <admin@macridesweb.com> (overlibmws JS library)
 * @author Erik Bosrup <erik@bosrup.com> (original overlib JS library)
 * @link http://www.winged.it/
 * @link http://www.macridesweb.com/oltest/
 * @link http://www.bosrup.com/web/overlib/
 * @copyright Copyright &copy; 2007 Ciro Mattia Gonano
 * @license Artistic License - http://www.opensource.org/licenses/artistic-license.php
 * @version 2.7
 */

/**
 * OLHyperLink class
 *
 * Hover over anchors (links) and images to invoke DHTML popups.
 *
 * @author Ciro Mattia Gonano <ciro@winged.it>
 * @version 2.7
 * @copyright Copyright &copy; 2007 Ciro Mattia Gonano
 * @license Artistic License - http://www.opensource.org/licenses/artistic-license.php
 */

/* TODO:
 * +v.01: start
 * +v.02: implement www.macridesweb.com/oltest/commandRef.html [Content]
 * +v.03: implement www.macridesweb.com/oltest/commandRef.html [Behavior, Positioning and
 *			Sizes w/out plugins]
 * +v.10: implement www.macridesweb.com/oltest/commandRef.html [Cascading Style Sheets]
 * v.15: implement
 * v.11: implement www.macridesweb.com/oltest/commandRef.html [Dropshadow]
 * v.12: implement www.macridesweb.com/oltest/commandRef.html [Speech Bubbles]
 * v.05: implement www.macridesweb.com/oltest/commandRef.html [Colors, Fonts and Images]
 * v.13: implement www.macridesweb.com/oltest/commandRef.html [Transform Filters]
 * v.14: implement www.macridesweb.com/oltest/commandRef.html [Printing Popups]
 * v.15: complete implementation of all options on www.macridesweb.com/oltest/commandRef.html
 *			but ones that require plugin inclusion.
 * v.20: documentation.
 * v.25: complete implementation of all options on www.macridesweb.com/oltest/commandRef.html
 *			that require plugin inclusion.
 * v.30: documentation.
 * v.35: add handler for onclick()
 */

Prado::using('System.Web.UI.WebControls.THyperLink');

class OLHyperLink extends THyperLink
{
	const OL_ACTION_MOUSEOVER = 1;
	const OL_ACTION_CLICK = 2;

	const OL_PLUGIN_MODAL = 1;
	const OL_PLUGIN_EXCLUSIVE = 2;
	const OL_PLUGIN_FUNCTIONS = 3;
	const OL_PLUGIN_SCROLL = 4;
	const OL_PLUGIN_IFRAME = 5;
	const OL_PLUGIN_CROSSFRAME = 6;
	const OL_PLUGIN_DRAGGABLE = 7;
	const OL_PLUGIN_HIDE = 8;
	const OL_PLUGIN_SHADOW = 9;
	const OL_PLUGIN_BUBBLE = 10;
	const OL_PLUGIN_FILTER = 11;
	const OL_PLUGIN_PRINT = 12;

	private $csm;
	private $assetPath;

	private function escapeSingleQuotes($str)
	{
		return str_replace("'","\'",$str);
	}
	/**
	 * Builds the complete overlib function string.
	 *
	 */
	private function buildOverlibFunction($action)
	{
		$func = '';
		switch ($action) {
			case OLHyperLink::OL_ACTION_MOUSEOVER:
				if (!($val=$this->getOLText()))
					break;
				$func = "overlib('".$this->escapeSingleQuotes($val)."'";
				if (($val=$this->getOLCaption())!='')
					$func .= ",CAPTION, '".$this->escapeSingleQuotes($val)."'";
				if (($val=$this->getOLCloseText())!='')
					$func .= ",CLOSETEXT, '$val'";
				if ($this->getOLCloseClick()) {
					$func .= ",CLOSECLICK";
					if (($val=$this->getOLCloseTitle())!='')
						$func .= ",CLOSETITLE, '".$this->escapeSingleQuotes($val)."'";
				}
				if ($this->getOLNoClose())
					$func .= ",NOCLOSE";
				if ($this->getOLMouseOff())
					$func .= ",MOUSEOFF";
				if (($val=$this->getOLOffDelay())!==null)
					$func .= ",OFFDELAY,'$val'";
				if ($this->getOLCapBelow())
					$func .= ",CAPBELOW";
				if (($val=$this->getOLTextPadding())!==null)
					$func .= ",TEXTPADDING,'$val'";
				if (($val=$this->getOLCaptionPadding())!==null)
					$func .= ",CAPTIONPADDING,'$val'";
				if (($val=$this->getOLBorder())!==null)
					$func .= ",BORDER,'$val'";
				if (($val=$this->getOLBase())!==null)
					$func .= ",BASE,'$val'";
				if ($this->getOLAutoStatusCap())
					$func .= ",AUTOSTATUSCAP";
				else if ($this->getOLAutoStatus())
					$func .= ",AUTOSTATUS";
				else if (($val=$this->getOLStatus())!='')
					$func .= ",STATUS,'$val'";
				if ($this->getOLSticky())
					$func .= ",STICKY";
				if ($this->getOLExclusive()) {
					$this->regPlugin(OLHyperLink::OL_PLUGIN_EXCLUSIVE);
					$func .= ",EXCLUSIVE";
				}
				if (($val=$this->getOLExclusiveStatus())!='')
					$func .= ",EXCLUSIVESTATUS,'$val'";
				if ($this->getOLExclusiveOverride())
					$func .= ",EXCLUSIVEOVERRIDE";
				if ($this->getOLModal()) {
					$this->regPlugin(OLHyperLink::OL_PLUGIN_MODAL);
					$func .= ",MODAL";
				}
				if ($this->getOLNoFollow())
					$func .= ",NOFOLLOW";
				if (($val=$this->getOLWidth())!==null)
					$func .= ",WIDTH,'$val'";
				if ($this->getOLWrap())
					$func .= ",WRAP";
				if (($val=$this->getOLWrapMax())!==null)
					$func .= ",WRAPMAX,'$val'";
				if (($val=$this->getOLHeight())!==null)
					$func .= ",HEIGHT,'$val'";
				/* POSITIONING */
				if (($val=$this->getOLRef())!==null) {
					$func .= ",REF,'$val'";
					if (($val=$this->getOLRefC())!==null) {
						$func .= ",REFC,'$val'";
					}
					if (($val=$this->getOLRefP())!==null) {
						$func .= ",REFP,'$val'";
					}
					if (($val=$this->getOLRefX())!==null) {
						$func .= ",REFX,'$val'";
					}
					if (($val=$this->getOLRefY())!==null) {
						$func .= ",REFY,'$val'";
					}
				} else {
					/* X positioning */
					if (($val=$this->getOLMidX())!==null) {
						$func .= ",MIDX,'$val'";
					} else if (($val=$this->getOLRelX())!==null) {
						$func .= ",RELX,'$val'";
					} else if (($val=$this->getOLFixX())!==null) {
						$func .= ",FIXX,'$val'";
					} else if (($val=$this->getOLOffsetX())!==null) {
						$func .= ",OFFSETX,'$val'";
						if (($val=$this->getOLSnapX())!==null) {
							$func .= ",SNAPX,'$val'";
							$snapXInserted = true;
						}
					} else if ($this->getOLRight()) {
						$func .= ",RIGHT";
						if (($val=$this->getOLSnapX())!==null) {
							$func .= ",SNAPX,'$val'";
							$snapXInserted = true;
						}
					} else if ($this->getOLLeft()) {
						$func .= ",LEFT";
						if (($val=$this->getOLSnapX())!==null) {
							$func .= ",SNAPX,'$val'";
							$snapXInserted = true;
						}
					} else if ($this->getOLCenter()) {
						$func .= ",CENTER";
						if (($val=$this->getOLSnapX())!==null) {
							$func .= ",SNAPX,'$val'";
							$snapXInserted = true;
						}
					}
					/* Y positioning */
					if (($val=$this->getOLMidY())!==null) {
						$func .= ",MIDY,'$val'";
					} else if (($val=$this->getOLRelY())!==null) {
						$func .= ",RELY,'$val'";
					} else if (($val=$this->getOLFixY())!==null) {
						$func .= ",FIXY,'$val'";
					} else if (($val=$this->getOLOffsetY())!==null) {
						$func .= ",OFFSETY,'$val'";
						if (($val=$this->getOLSnapY())!==null) {
							$func .= ",SNAPY,'$val'";
							$snapYInserted = true;
						}
					} else if ($this->getOLBelow()) {
						$func .= ",BELOW";
						if (($val=$this->getOLSnapX())!==null) {
							$func .= ",SNAPY,'$val'";
							$snapYInserted = true;
						}
					} else if ($this->getOLAbove()) {
						$func .= ",ABOVE";
						if (($val=$this->getOLSnapY())!==null) {
							$func .= ",SNAPY,'$val'";
							$snapYInserted = true;
						}
					} else if ($this->getOLVCenter()) {
						$func .= ",VCENTER";
						if (($val=$this->getOLSnapY())!==null) {
							$func .= ",SNAPY,'$val'";
							$snapYInserted = true;
						}
					}
				}
				if ($this->getOLNoJustX())
					$func .= ",NOJUSTX";
				if ($this->getOLNoJustY())
					$func .= ",NOJUSTY";
				if ($this->getOLHAuto()) {
					$func .= ",HAUTO";
					if (($val=$this->getOLSnapX())!==null && isset($snapXInserted)) {
						$func .= ",SNAPY,'$val'";
						$snapXInserted = true;
					}
				}
				if ($this->getOLVAuto()) {
					$func .= ",VAUTO";
					if (($val=$this->getOLSnapY())!==null && isset($snapYInserted)) {
						$func .= ",SNAPY,'$val'";
						$snapYInserted = true;
					}
				}
				if (($val=$this->getOLFrame())!==null) {
					$this->regPlugin(OLHyperLink::OL_PLUGIN_CROSSFRAME);
					$func .= ",FRAME,'$val'";
				}
				if ($this->getOLDraggable()) {
					$this->regPlugin(OLHyperLink::OL_PLUGIN_DRAGGABLE);
					$func .= ",DRAGGABLE";
					if ($this->getOLDragCap())
						$func .= ",DRAGCAP";
					if (($val=$this->getOLDragId())!==null)
						$func .= ",DRAGID,'$val'";
				} else if ($this->getOLScroll()) {
					$this->regPlugin(OLHyperLink::OL_PLUGIN_SCROLL);
					$func .= ",SCROLL";
				}

				/* END POSITIONING */

				if (($val=$this->getOLTimeout())!==null)
					$func .= ",TIMEOUT,'$val'";
				if (($val=$this->getOLDelay())!==null)
					$func .= ",DELAY,'$val'";
				if (($val=$this->getOLLabel())!==null)
					$func .= ",LABEL,'".$this->escapeSingleQuotes($val)."'";
				if (($val=$this->getOLLabel2())!==null)
					$func .= ",LABEL2,'".$this->escapeSingleQuotes($val)."'";


				/* CSS CLASSING */
				if (($val=$this->getOLFGClass())!=='')
					$func .= ",FGCLASS,'$val'";
				if (($val=$this->getOLCGClass())!=='')
					$func .= ",CGCLASS,'$val'";
				if (($val=$this->getOLBGClass())!=='')
					$func .= ",BGCLASS,'$val'";
				if (($val=$this->getOLTextFontClass())!=='')
					$func .= ",TEXTFONTCLASS,'$val'";
				if (($val=$this->getOLCaptionFontClass())!=='')
					$func .= ",CAPTIONFONTCLASS,'$val'";
				if (($val=$this->getOLCloseFontClass())!=='')
					$func .= ",CLOSEFONTCLASS,'$val'";
				/* END CSS CLASSING */

				/* SHADOW */
				if ($this->getOLShadow()) {
					$this->regPlugin(OLHyperLink::OL_PLUGIN_SHADOW);
					$func .= ",SHADOW";
					$func .= ",SHADOWX,'".$this->getOLShadowX()."'";
					$func .= ",SHADOWY,'".$this->getOLShadowY()."'";
					$func .= ",SHADOWCOLOR,'".$this->getOLShadowColor()."'";
					$func .= ",SHADOWOPACITY,'".$this->getOLShadowOpacity()."'";
					if (($val=$this->getOLShadowImage())!==null)
						$func .= ",SHADOWIMAGE,'$val'";
				}
				/* END SHADOW */

				/* CLOSE FUNCTION */
				$func .= ');';
				break;
			case OLHyperLink::OL_ACTION_CLICK:
				break;
		}
		return $func;
	}

	private function regPlugin($plugin)
	{
		switch ($plugin) {
			case OLHyperLink::OL_PLUGIN_MODAL:
				if (!$this->csm->isScriptFileRegistered('overlibmws_modal'))
					$this->csm->registerScriptFile('overlibmws_modal',
						$this->assetPath.'/overlibmws_modal.js');
				break;
			case OLHyperLink::OL_PLUGIN_EXCLUSIVE:
				if (!$this->csm->isScriptFileRegistered('overlibmws_exclusive'))
					$this->csm->registerScriptFile('overlibmws_exclusive',
						$this->assetPath.'/overlibmws_exclusive.js');
				break;
			case OLHyperLink::OL_PLUGIN_FUNCTIONS:
				if (!$this->csm->isScriptFileRegistered('overlibmws_functions'))
					$this->csm->registerScriptFile('overlibmws_functions',
						$this->assetPath.'/overlibmws_functions.js');
				break;
			case OLHyperLink::OL_PLUGIN_SCROLL:
				if (!$this->csm->isScriptFileRegistered('overlibmws_scroll'))
					$this->csm->registerScriptFile('overlibmws_scroll',
						$this->assetPath.'/overlibmws_scroll.js');
				break;
			case OLHyperLink::OL_PLUGIN_IFRAME:
				if (!$this->csm->isScriptFileRegistered('overlibmws_iframe'))
					$this->csm->registerScriptFile('overlibmws_iframe',
						$this->assetPath.'/overlibmws_iframe.js');
				break;
			case OLHyperLink::OL_PLUGIN_CROSSFRAME:
				if (!$this->csm->isScriptFileRegistered('overlibmws_crossframe'))
					$this->csm->registerScriptFile('overlibmws_crossframe',
						$this->assetPath.'/overlibmws_crossframe.js');
				break;
			case OLHyperLink::OL_PLUGIN_DRAGGABLE:
				if (!$this->csm->isScriptFileRegistered('overlibmws_draggable'))
					$this->csm->registerScriptFile('overlibmws_draggable',
						$this->assetPath.'/overlibmws_draggable.js');
				break;
			case OLHyperLink::OL_PLUGIN_HIDE:
				if (!$this->csm->isScriptFileRegistered('overlibmws_hide'))
					$this->csm->registerScriptFile('overlibmws_hide',
						$this->assetPath.'/overlibmws_hide.js');
				break;
			case OLHyperLink::OL_PLUGIN_SHADOW:
				if (!$this->csm->isScriptFileRegistered('overlibmws_shadow'))
					$this->csm->registerScriptFile('overlibmws_shadow',
						$this->assetPath.'/overlibmws_shadow.js');
				break;
			case OLHyperLink::OL_PLUGIN_BUBBLE:
				if (!$this->csm->isScriptFileRegistered('overlibmws_bubble'))
					$this->csm->registerScriptFile('overlibmws_bubble',
						$this->assetPath.'/overlibmws_bubble.js');
				break;
			case OLHyperLink::OL_PLUGIN_FILTER:
				if (!$this->csm->isScriptFileRegistered('overlibmws_filter'))
					$this->csm->registerScriptFile('overlibmws_filter',
						$this->assetPath.'/overlibmws_filter.js');
				break;
			case OLHyperLink::OL_PLUGIN_PRINT:
				if (!$this->csm->isScriptFileRegistered('overlibmws_print'))
					$this->csm->registerScriptFile('overlibmws_print',
						$this->assetPath.'/overlibmws_print.js');
				break;
		}
	}

	public function onInit($param)
	{
		parent::onInit($param);

		$this->assetPath = $this->publishFilePath(dirname(__FILE__).'/overlibmws');
		$this->csm = $this->getPage()->getClientScript();

		if (!$this->csm->isScriptFileRegistered('overlibmws'))
			$this->csm->registerScriptFile('overlibmws', $this->assetPath.'/overlibmws.js');
		if (!$this->csm->isScriptFileRegistered('overlibmws_iframe'))
			$this->csm->registerScriptFile('overlibmws_iframe', $this->assetPath.'/overlibmws_iframe.js');
	}

	/**
	 * Adds attributes related to a hyperlink element to renderer.
	 * @param THtmlWriter the writer used for the rendering purpose
	 */
	protected function addAttributesToRender($writer)
	{
		if ($this->getNavigateUrl()==='')
			$this->setNavigateUrl('javascript:void(0);');
		if (($mouseover=$this->buildOverlibFunction(OLHyperLink::OL_ACTION_MOUSEOVER))!=='') {
			$writer->addAttribute('onmouseover',"return ".$mouseover);
			$writer->addAttribute('onmouseout',"nd(".$this->getOLNDTimeOut().");");
			if (($click=$this->buildOverlibFunction(OLHyperLink::OL_ACTION_CLICK))!=='') {
				$writer->addAttribute('onclick',$click);
			}
		}
		parent::addAttributesToRender($writer);
	}

	/**
	 * @return string the base overlib text.
	 */
	public function getOLText()
	{
		return $this->getControlState('OLText','');
	}
	/**
	 * Sets the base overlib text.
	 * @param string the text to be set
	 */
	public function setOLText($value)
	{
		$this->setControlState('OLText',TPropertyValue::ensureString($value),'');
	}

	/**
	 * @return string the caption.
	 */
	public function getOLCaption()
	{
		return $this->getControlState('OLCaption','');
	}
	/**
	 * Sets the overlib caption.
	 * @param string the tooltip to be set
	 */
	public function setOLCaption($value)
	{
		$this->setControlState('OLCaption',TPropertyValue::ensureString($value),'');
	}

	public function getOLNDTimeOut()
	{
		return $this->getControlState('OLNDTimeOut',0);
	}
	public function setOLNDTimeOut($value)
	{
		$this->setControlState('OLNDTimeOut',TPropertyValue::ensureInteger($value),0);
	}

	public function getOLCloseText()
	{
		return $this->getControlState('OLCloseText','');
	}
	public function setOLCloseText($value)
	{
		$this->setControlState('OLCloseText',TPropertyValue::ensureString($value),'');
	}

	public function getOLCloseClick()
	{
		return $this->getControlState('OLCloseClick',false);
	}
	public function setOLCloseClick($value)
	{
		$this->setControlState('OLCloseClick',TPropertyValue::ensureBoolean($value),false);
	}

	public function getOLCloseTitle()
	{
		return $this->getControlState('OLCloseTitle','');
	}
	public function setOLCloseTitle($value)
	{
		$this->setControlState('OLCloseTitle',TPropertyValue::ensureString($value),'');
	}

	public function getOLNoClose()
	{
		return $this->getControlState('OLNoClose',false);
	}
	public function setOLNoClose($value)
	{
		$this->setControlState('OLNoClose',TPropertyValue::ensureBoolean($value),false);
	}

	public function getOLMouseOff()
	{
		return $this->getControlState('OLMouseOff',false);
	}
	public function setOLMouseOff($value)
	{
		$this->setControlState('OLMouseOff',TPropertyValue::ensureString($value),false);
	}

	public function getOLOffDelay()
	{
		return $this->getControlState('OLOffDelay',null);
	}
	public function setOLOffDelay($value)
	{
		$this->setControlState('OLOffDelay',TPropertyValue::ensureInteger($value),null);
	}

	public function getOLCapBelow()
	{
		return $this->getControlState('OLCapBelow',false);
	}
	public function setOLCapBelow($value)
	{
		$this->setControlState('OLCapBelow',TPropertyValue::ensureBoolean($value),false);
	}

	/*** TODO: array support is not yet implemented
	public function getOLInArray()
	{
		return $this->getControlState('OLInArray',0);
	}
	public function setOLInArray($value)
	{
		$this->setControlState('OLInArray',TPropertyValue::ensureInteger($value),0);
	}
	public function getOLCapArray()
	{
		return $this->getControlState('OLCapArray',0);
	}
	public function setOLCapArray($value)
	{
		$this->setControlState('OLCapArray',TPropertyValue::ensureInteger($value),0);
	}
	*/

	public function getOLTextPadding()
	{
		return $this->getControlState('OLTextPadding',null);
	}
	public function setOLTextPadding($value)
	{
		$this->setControlState('OLTextPadding',TPropertyValue::ensureInteger($value),null);
	}

	public function getOLCaptionPadding()
	{
		return $this->getControlState('OLCaptionPadding',null);
	}
	public function setOLCaptionPadding($value)
	{
		$this->setControlState('OLCaptionPadding',TPropertyValue::ensureInteger($value),null);
	}

	public function getOLBase()
	{
		return $this->getControlState('OLBase',null);
	}
	public function setOLBase($value)
	{
		$this->setControlState('OLBase',TPropertyValue::ensureInteger($value),null);
	}

	public function getOLBorder()
	{
		return $this->getControlState('OLBorder',null);
	}
	public function setOLBorder($value)
	{
		$this->setControlState('OLBorder',TPropertyValue::ensureInteger($value),null);
	}

	public function getOLStatus()
	{
		return $this->getControlState('OLStatus','');
	}
	public function setOLStatus($value)
	{
		$this->setControlState('OLStatus',TPropertyValue::ensureString($value),'');
	}

	public function getOLAutoStatus()
	{
		return $this->getControlState('OLAutoStatus',false);
	}
	public function setOLAutoStatus($value)
	{
		$this->setControlState('OLAutoStatus',TPropertyValue::ensureBoolean($value),false);
	}

	public function getOLAutoStatusCap()
	{
		return $this->getControlState('OLAutoStatusCap',false);
	}
	public function setOLAutoStatusCap($value)
	{
		$this->setControlState('OLAutoStatusCap',TPropertyValue::ensureBoolean($value),false);
	}

	public function getOLSticky()
	{
		return $this->getControlState('OLSticky',false);
	}
	public function setOLSticky($value)
	{
		$this->setControlState('OLSticky',TPropertyValue::ensureBoolean($value),false);
	}

	public function getOLExclusive()
	{
		return $this->getControlState('OLExclusive',false);
	}
	public function setOLExclusive($value)
	{
		$this->setControlState('OLExclusive',TPropertyValue::ensureBoolean($value),false);
	}

	public function getOLExclusiveStatus()
	{
		return $this->getControlState('OLExclusiveStatus','');
	}
	public function setOLExclusiveStatus($value)
	{
		$this->setControlState('OLExclusiveStatus',TPropertyValue::ensureString($value),'');
	}

	public function getOLExclusiveOverride()
	{
		return $this->getControlState('OLExclusiveOverride',false);
	}
	public function setOLExclusiveOverride($value)
	{
		$this->setControlState('OLExclusiveOverride',TPropertyValue::ensureBoolean($value),false);
	}

	public function getOLModal()
	{
		return $this->getControlState('OLModal',false);
	}
	public function setOLModal($value)
	{
		$this->setControlState('OLModal',TPropertyValue::ensureBoolean($value),false);
	}

	public function getOLNoFollow()
	{
		return $this->getControlState('OLNoFollow',false);
	}
	public function setOLNoFollow($value)
	{
		$this->setControlState('OLNoFollow',TPropertyValue::ensureBoolean($value),false);
	}

	public function getOLWidth()
	{
		return $this->getControlState('OLWidth',null);
	}
	public function setOLWidth($value)
	{
		$this->setControlState('OLWidth',TPropertyValue::ensureInteger($value),null);
	}

	public function getOLWrap()
	{
		return $this->getControlState('OLWrap',false);
	}
	public function setOLWrap($value)
	{
		$this->setControlState('OLWrap',TPropertyValue::ensureBoolean($value),false);
	}

	public function getOLWrapMax()
	{
		return $this->getControlState('OLWrapMax',null);
	}
	public function setOLWrapMax($value)
	{
		$this->setControlState('OLWrapMax',TPropertyValue::ensureInteger($value),null);
	}

	public function getOLHeight()
	{
		return $this->getControlState('OLHeight',null);
	}
	public function setOLHeight($value)
	{
		$this->setControlState('OLHeight',TPropertyValue::ensureInteger($value),null);
	}

	public function getOLRight()
	{
		return $this->getControlState('OLRight',false);
	}
	public function setOLRight($value)
	{
		$this->setControlState('OLRight',TPropertyValue::ensureBoolean($value),false);
	}

	public function getOLLeft()
	{
		return $this->getControlState('OLLeft',false);
	}
	public function setOLLeft($value)
	{
		$this->setControlState('OLLeft',TPropertyValue::ensureBoolean($value),false);
	}

	public function getOLCenter()
	{
		return $this->getControlState('OLCenter',false);
	}
	public function setOLCenter($value)
	{
		$this->setControlState('OLCenter',TPropertyValue::ensureBoolean($value),false);
	}

	public function getOLBelow()
	{
		return $this->getControlState('OLBelow',false);
	}
	public function setOLBelow($value)
	{
		$this->setControlState('OLBelow',TPropertyValue::ensureBoolean($value),false);
	}

	public function getOLAbove()
	{
		return $this->getControlState('OLAbove',false);
	}
	public function setOLAbove($value)
	{
		$this->setControlState('OLAbove',TPropertyValue::ensureBoolean($value),false);
	}

	public function getOLVCenter()
	{
		return $this->getControlState('OLVCenter',false);
	}
	public function setOLVCenter($value)
	{
		$this->setControlState('OLVCenter',TPropertyValue::ensureBoolean($value),false);
	}

	public function getOLOffsetX()
	{
		return $this->getControlState('OLOffsetX',null);
	}
	public function setOLOffsetX($value)
	{
		$this->setControlState('OLOffsetX',TPropertyValue::ensureInteger($value),null);
	}
	public function getOLOffsetY()
	{
		return $this->getControlState('OLOffsetY',null);
	}
	public function setOLOffsetY($value)
	{
		$this->setControlState('OLOffsetY',TPropertyValue::ensureInteger($value),null);
	}

	public function getOLSnapX()
	{
		return $this->getControlState('OLSnapX',null);
	}
	public function setOLSnapX($value)
	{
		$this->setControlState('OLSnapX',TPropertyValue::ensureInteger($value),null);
	}
	public function getOLSnapY()
	{
		return $this->getControlState('OLSnapY',null);
	}
	public function setOLSnapY($value)
	{
		$this->setControlState('OLSnapY',TPropertyValue::ensureInteger($value),null);
	}

	public function getOLRelX()
	{
		return $this->getControlState('OLRelX',null);
	}
	public function setOLRelX($value)
	{
		$this->setControlState('OLRelX',TPropertyValue::ensureInteger($value),null);
	}
	public function getOLRelY()
	{
		return $this->getControlState('OLRelY',null);
	}
	public function setOLRelY($value)
	{
		$this->setControlState('OLRelY',TPropertyValue::ensureInteger($value),null);
	}

	public function getOLMidX()
	{
		return $this->getControlState('OLMidX',null);
	}
	public function setOLMidX($value)
	{
		$this->setControlState('OLMidX',TPropertyValue::ensureInteger($value),null);
	}
	public function getOLMidY()
	{
		return $this->getControlState('OLMidY',null);
	}
	public function setOLMidY($value)
	{
		$this->setControlState('OLMidY',TPropertyValue::ensureInteger($value),null);
	}

	public function getOLScroll()
	{
		return $this->getControlState('OLScroll',false);
	}
	public function setOLScroll($value)
	{
		$this->setControlState('OLScroll',TPropertyValue::ensureBoolean($value),false);
	}

	public function getOLRef()
	{
		return $this->getControlState('OLRef',null);
	}
	public function setOLRef($value)
	{
		$this->setControlState('OLRef',TPropertyValue::ensureString($value),null);
	}

	public function getOLRefC()
	{
		return $this->getControlState('OLRefC',null);
	}
	/* The allowable values are 'UL' (Upper Left), 'UR', (Upper Right), 'LL' (Lower Left), and 'LR' (Lower Right) */
	public function setOLRefC($value)
	{
		$this->setControlState('OLRefC',TPropertyValue::ensureString($value),null);
	}

	public function getOLRefP()
	{
		return $this->getControlState('OLRefP',null);
	}
	/* The allowable values are 'UL' (Upper Left), 'UR', (Upper Right), 'LL' (Lower Left), and 'LR' (Lower Right) */
	public function setOLRefP($value)
	{
		$this->setControlState('OLRefP',TPropertyValue::ensureString($value),null);
	}

	public function getOLRefX()
	{
		return $this->getControlState('OLRefX',null);
	}
	public function setOLRefX($value)
	{
		$this->setControlState('OLRefX',TPropertyValue::ensureInteger($value),null);
	}
	public function getOLRefY()
	{
		return $this->getControlState('OLRefY',null);
	}
	public function setOLRefY($value)
	{
		$this->setControlState('OLRefY',TPropertyValue::ensureInteger($value),null);
	}

	public function getOLFixX()
	{
		return $this->getControlState('OLFixX',null);
	}
	/* only >= 0 */
	public function setOLFixX($value)
	{
		$this->setControlState('OLFixX',TPropertyValue::ensureInteger($value),null);
	}
	public function getOLFixY()
	{
		return $this->getControlState('OLFixY',null);
	}
	/* only >= 0 */
	public function setOLFixY($value)
	{
		$this->setControlState('OLFixY',TPropertyValue::ensureInteger($value),null);
	}

	public function getOLNoJustX()
	{
		return $this->getControlState('OLNoJustX',false);
	}
	public function setOLNoJustX($value)
	{
		$this->setControlState('OLNoJustX',TPropertyValue::ensureBoolean($value),false);
	}
	public function getOLNoJustY()
	{
		return $this->getControlState('OLNoJustY',false);
	}
	public function setOLNoJustY($value)
	{
		$this->setControlState('OLNoJustY',TPropertyValue::ensureBoolean($value),false);
	}

	public function getOLHAuto()
	{
		return $this->getControlState('OLHauto',false);
	}
	public function setOLHAuto($value)
	{
		$this->setControlState('OLHAuto',TPropertyValue::ensureBoolean($value),false);
	}
	public function getOLVAuto()
	{
		return $this->getControlState('OLVAuto',false);
	}
	public function setOLVAuto($value)
	{
		$this->setControlState('OLVAuto',TPropertyValue::ensureBoolean($value),false);
	}

	public function getOLFrame()
	{
		return $this->getControlState('OLFrame',null);
	}
	public function setOLFrame($value)
	{
		$this->setControlState('OLFrame',TPropertyValue::ensureString($value),null);
	}

	public function getOLTimeout()
	{
		return $this->getControlState('OLTimeout',null);
	}
	public function setOLTimeout($value)
	{
		$this->setControlState('OLTimeout',TPropertyValue::ensureInteger($value),null);
	}

	public function getOLDelay()
	{
		return $this->getControlState('OLDelay',null);
	}
	public function setOLDelay($value)
	{
		$this->setControlState('OLDelay',TPropertyValue::ensureInteger($value),null);
	}

	public function getOLDraggable()
	{
		return $this->getControlState('OLDraggable',false);
	}
	public function setOLDraggable($value)
	{
		$this->setControlState('OLDraggable',TPropertyValue::ensureBoolean($value),false);
	}
	public function getOLDragCap()
	{
		return $this->getControlState('OLDragCap',false);
	}
	public function setOLDragCap($value)
	{
		$this->setControlState('OLDragCap',TPropertyValue::ensureBoolean($value),false);
	}
	public function getOLDragId()
	{
		return $this->getControlState('OLDragId',null);
	}
	public function setOLDragId($value)
	{
		$this->setControlState('OLDragId',TPropertyValue::ensureString($value),null);
	}

	public function getOLHideSelectBoxes()
	{
		return $this->getControlState('OLHideSelectBoxes',false);
	}
	public function setOLHideSelectBoxes($value)
	{
		$this->setControlState('OLHideSelectBoxes',TPropertyValue::ensureBoolean($value),false);
	}
	public function getOLHideByIdAll()
	{
		return $this->getControlState('OLHideByIdAll',null);
	}
	public function setOLHideByIdAll($value)
	{
		$this->setControlState('OLHideByIdAll',TPropertyValue::ensureString($value),null);
	}
	public function getOLHideByIdNS4()
	{
		return $this->getControlState('OLHideByIdNS4',null);
	}
	public function setOLHideByIdNS4($value)
	{
		$this->setControlState('OLHideByIdNS4',TPropertyValue::ensureString($value),null);
	}
	public function getOLHideById()
	{
		return $this->getControlState('OLHideById',null);
	}
	public function setOLHideById($value)
	{
		$this->setControlState('OLHideById',TPropertyValue::ensureString($value),null);
	}

	public function getOLLabel()
	{
		return $this->getControlState('OLLabel',null);
	}
	public function setOLLabel($value)
	{
		$this->setControlState('OLLabel',TPropertyValue::ensureString($value),null);
	}

	public function getOLLabel2()
	{
		return $this->getControlState('OLLabel2',null);
	}
	public function setOLLabel2($value)
	{
		$this->setControlState('OLLabel2',TPropertyValue::ensureString($value),null);
	}

	/* CSS STYLING */
	public function getOLFGClass()
	{
		return $this->getControlState('OLFGClass','');
	}
	public function setOLFGClass($value)
	{
		$this->setControlState('OLFGClass',TPropertyValue::ensureString($value),'');
	}
	public function getOLCGClass()
	{
		return $this->getControlState('OLCGClass','');
	}
	public function setOLCGClass($value)
	{
		$this->setControlState('OLCGClass',TPropertyValue::ensureString($value),'');
	}
	public function getOLBGClass()
	{
		return $this->getControlState('OLBGClass','');
	}
	public function setOLBGClass($value)
	{
		$this->setControlState('OLBGClass',TPropertyValue::ensureString($value),'');
	}
	public function getOLTextFontClass()
	{
		return $this->getControlState('OLTextFontClass','');
	}
	public function setOLTextFontClass($value)
	{
		$this->setControlState('OLTextFontClass',TPropertyValue::ensureString($value),'');
	}
	public function getOLCaptionFontClass()
	{
		return $this->getControlState('OLCaptionFontClass','');
	}
	public function setOLCaptionFontClass($value)
	{
		$this->setControlState('OLCaptionFontClass',TPropertyValue::ensureString($value),'');
	}
	public function getOLCloseFontClass()
	{
		return $this->getControlState('OLCloseFontClass','');
	}
	public function setOLCloseFontClass($value)
	{
		$this->setControlState('OLCloseFontClass',TPropertyValue::ensureString($value),'');
	}

	public function getOLShadow()
	{
		return $this->getControlState('OLShadow',false);
	}
	public function setOLShadow($value)
	{
		$this->setControlState('OLShadow',TPropertyValue::ensureBoolean($value),false);
	}
	public function getOLShadowX()
	{
		return $this->getControlState('OLShadowX',5);
	}
	public function setOLShadowX($value)
	{
		$this->setControlState('OLShadowX',TPropertyValue::ensureInteger($value),5);
	}
	public function getOLShadowY()
	{
		return $this->getControlState('OLShadowY',5);
	}
	public function setOLShadowY($value)
	{
		$this->setControlState('OLShadowY',TPropertyValue::ensureInteger($value),5);
	}
	public function getOLShadowColor()
	{
		return $this->getControlState('OLShadowColor','#666666');
	}
	public function setOLShadowColor($value)
	{
		$this->setControlState('OLShadowColor',TPropertyValue::ensureString($value),'#666666');
	}
	public function getOLShadowImage()
	{
		return $this->getControlState('OLShadowImage',null);
	}
	public function setOLShadowImage($value)
	{
		$this->setControlState('OLShadowImage',TPropertyValue::ensureString($value),null);
	}
	public function getOLShadowOpacity()
	{
		return $this->getControlState('OLShadowOpacity',60);
	}
	public function setOLShadowOpacity($value)
	{
		$this->setControlState('OLShadowOpacity',TPropertyValue::ensureInteger($value),60);
	}
}
