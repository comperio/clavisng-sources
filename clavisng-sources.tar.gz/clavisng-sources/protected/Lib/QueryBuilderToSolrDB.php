<?php

/**
 * QueryBuilderToSolrDB class file
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.9
 */

class  QueryBuilderToSolrDB implements IQueryBuilderToDB
{
	private function getTransformationRules()
	{
		$fieldMap = [
			'author' => [
				'field_name' => [
					'default' => 'facets_author',
					'begins_with' => 'fldin_txt_author',
					'ends_with' => 'fldin_txt_author'
				]
			],
			'editor' => 'facets_publisher',
			'date' => 'facets_date',
			'biblevel' => [
				'field_name' => [
					'default' => 'facets_biblevel',
				],
				'transform_type' => 'map',
				'transform_param' => [
					'map' => [1 => 'm', 2 => 'b'],
					'expand' => [
						'item' => 'a',
						'values' => ['libreria arzignano', 'biblioteca arzignano'],
						'operator' => 'OR'
					],
					'findreplace' => [
						'find' => 'string',
						'replace' => 'otherstring'
					]
				]
			]
		];
		return $fieldMap;
	}

	public function translate($rules, $transformationRules = [], $dao = null): string
	{
		$query = '';
		$qbrc = new QueryBuilderSolrRuleConverter($this, $transformationRules, $dao);
		$qbrc->convert($query, $rules);
		return $query;
	}

	public function getOperatorsMap($field, $operator, $value, $type='')
	{
		$from = is_array($value) ? $value[0] : $value;
		$to = is_array($value) ? $value[1] : $value;

		$or_value = is_array($value) ?
			implode(' OR ', $value) :
			str_replace(array(',', ' '), ' OR ', preg_replace('/\s+/', ' ', $value));

		$operatorMap = [
			'equal' => "$field:($value)",
			'not_equal' => "(*:* -$field:($value))",
			'in' => "$field:($or_value)",
			'not_in' => "-$field:($or_value)",
			'less' => "$field:\{* TO $value\}",
			'less_or_equal' => "$field:[* TO $value]",
			'greater' => "$field:\{$value TO *\}",
			'greater_or_equal' => "$field:[$value TO *]",
			'between' => "$field:[$from TO $to]",
			'not_between' => "-$field:[$from TO $to]",
			'begins_with' => "$field:($value*)",
			'not_begins_with' => "-$field:($value*)",
			'contains' => "$field:($value)",
			'not_contains' => "-$field:($value)",
			'ends_with' => "$field:(*$value)",
			'not_ends_with' => "-$field:(*$value)",
			'is_empty' => "$field:''",
			'is_not_empty' => "-$field:''",
			'is_null' => "-$field:[* TO *]",
			'is_not_null' => "$field:[* TO *]",
			'not_null_and_not_empty' => "$field:['' TO *] AND -$field:''",
			'null_or_empty' => "(-$field:[* TO *])",
			'null_or_empty_or_zero' => "(-$field:[* TO *])"
		];

		if (array_key_exists($operator, $operatorMap)) {
			return $operatorMap[$operator];
		}

		throw new RuntimeException('operator not found in the conversion map.');
	}

	public function escapeUserInput($value)
	{
		$reserved_words = [
			'+',
			'-',
			'&&',
			'||',
			'!',
			'(',
			')',
			'{',
			'}',
			'[',
			']',
			'^',
			'"',
			'~',
			'*',
			'?',
			':',
			'/'
		];

		$escaped_words = array_map(static function ($item) {
			return '\\' . $item;
		}, $reserved_words);

		return str_replace($reserved_words, $escaped_words, $value);
	}
}
