<?php
class UnimarcUtility {
	public static $charMap = array(
		0x21 => '¡',
		0x22 => '?',
		0x23 => '£',
		0x24 => '$',
		0x25 => '¥',
		0x26 => '?',
		0x27 => '§',
		0x28 => "\'",
		0x29 => '`',
		0x2A => '?',
		0x2B => '«',
		0x2C => '*',
		0x2D => '©',
		0x2E => '®',
		0x2F => '®',
		0x30 => '?',
		0x31 => '?',
		0x32 => '*',
		0x36 => '?',
		0x37 => '·',
		0x38 => '"',
		0x39 => '´',
		0x3A => '?',
		0x3B => '»',
		0x3C => '#',
		0x3D => '?',
		0x3E => '"',
		0x3F => '¿',
		0x61 => 'Æ',
		0x62 => 'Ð',
		0x66 => 'I',
		0x68 => 'L',
		0x69 => 'Ø',
		0x6A => 'O',
		0x6B => 'T',
		0x71 => 'æ',
		0x72 => 'Ð',
		0x73 => 'º',
		0x75 => 'i',
		0x76 => 'i',
		0x78 => 'i',
		0x79 => 'i',
		0x7A => 'o',
		0x7B => 's',
		0x7C => 't');

	function translate($text) {
		$s = '';
		$len = strlen($text);
		$i = 0;
		$ch = '';
		while ($i < $len) {
			if (ord($text{$i}) == 0x0E ) { // Shift char
				$i++;
				if (ord($text{$i}) >= 0x40 && ord($text{$i}) <= 0x5F) {
					$ch = $text{$i};
					$i += 2;
					switch (ord($ch)) {
						case 0x41:				// Grave Accent
							switch($text{$i}) {
								case 'a':
									$s .= 'à';
									break;
								case 'e':
									$s .= 'è';
									break;
								case 'i':
									$s .= 'ì';
									break;
								case 'o':
									$s .= 'ò';
									break;
								case 'u':
									$s .= 'ù';
									break;
								case 'A':
									$s .= 'À';
									break;
								case 'E':
									$s .= 'È';
									break;
								case 'I':
									$s .= 'Ì';
									break;
								case 'O':
									$s .= 'Ò';
									break;
								case 'U':
									$s .= 'Ù';
									break;
								default:
									$s .= $text{$i};
							};
							break;
						case 0x42:              // Acute accent
							switch($text{$i}) {
								case 'a':
									$s .= 'á';
									break;
								case 'e':
									$s .= 'é';
									break;
								case 'i':
									$s .= 'í';
									break;
								case 'o':
									$s .= 'ó';
									break;
									case 'u':
									$s .= 'ú';
									break;
								case 'A':
									$s .= 'Á';
									break;
								case 'E':
									$s .= 'É';
									break;
								case 'I':
									$s .= 'Í';
									break;
								case 'O':
									$s .= 'Ó';
									break;
								case 'U':
									$s .= 'Ú';
									break;
								default:
									$s .= $text{$i};
							};
							break;
						case 0x43:       // Circumflex
							switch($text{$i}) {
								case 'a':
									$s .= 'â';
									break;
								case 'e':
									$s .= 'ê';
									break;
								case 'i':
									$s .= 'î';
									break;
								case 'o':
									$s .= 'ô';
									break;
								case 'u':
									$s .= 'û';
									break;
								case 'A':
									$s .= 'Â';
									break;
								case 'E':
									$s .= 'Ê';
									break;
								case 'I':
									$s .= 'Î';
									break;
								case 'O':
									$s .= 'Ô';
									break;
								case 'U':
									$s .= 'Û';
									break;
								default:
									$s .= $text{$i};
							};
							break;
						case 0x44:			// Tilde accent
							switch($text{$i}) {
								case 'a':
									$s .= 'ã';
									break;
									case 'n':
									$s .= 'ñ';
									break;
								case 'o':
									$s .= 'õ';
										break;
								case 'A':
									$s .= 'Ã';
									break;
								case 'N':
									$s .= 'Ñ';
									break;
								default:
									$s .= $text{$i};
							};
							break;
						case 0x48:
						case 0x49:       // Dieresis or Umlaut
							switch($text{$i}) {
								case 'a':
									$s .= 'ä';
									break;
								case 'e':
									$s .= 'ë';
									break;
								case 'i':
									$s .= 'ï';
									break;
								case 'o':
									$s .= 'ö';
									break;
								case 'u':
									$s .= 'ü';
									break;
								case 'A':
									$s .= 'Ä';
									break;
								case 'E':
									$s .= 'Ë';
									break;
								case 'I':
									$s .= 'Ï';
									break;
								case 'O':
									$s .= 'Ö';
									break;
								case 'U':
									$s .= 'Ü';
									break;
								case 'y':
									$s .= 'ÿ';
									break;
								default:
									$s .= $text{$i};
							};
							break;
						case 0x4A:   // Ring Accent
							switch($text{$i}) {
								case 'a':
									$s .= 'å';
									break;
								case 'A':
									$s .= 'Å';
									break;
								default:
									$s .= $text{$i};
							};
							break;
						case 0x4B:
						case 0x4C:  		// Upperscript comma czec we dont support it
						case 0x4D:			// Double acute accent
							$s .= $text{$i};
							break;
						case 0x50:          // Cedillia
							switch($text{$i}) {
								case 'c':
									$s .= 'ç';
									break;
								case 'C':
									$s .= 'Ç';
									break;
								default:
									$s .= $text{$i};
							};
							break;
						default:
							$s .= $text{$i};
					}
				} else {
					$s .= array_key_exists(ord($text{$i}),self::$charMap)?
						self::$charMap[ord($text{$i})]:'*';
					$i++;
				}
			} else if (ord($text{$i}) == 0x1B){
				$i += 2;
				while (($i < $len) && (ord($text{$i})) != 0x1B) {
					$s .= $text{$i};
					$i++;
				}
				if ($i < $len)
					$s .= '*';
				$i++;
			} else {
				$s .= $text{$i};
			}
			$i++;
		}
		return $s;
	}

	function splitNonSortingText($text,&$nonsort,&$sort) {
		$pos = strpos($text,"\x1b");
		if ($pos === false)
			return false;
		$pos2 = strrpos($text,"\x1b");
		$nonsort = substr($text,$pos+2,($pos2-$pos)-2);
		$sort = substr($text,$pos2+2);
		return true;
	}

    function convertNonSortText($text) {
        $pos = strpos($text, "\x1b");
        if ($pos === false)
            return $text;
        $pos2 = strrpos($text, "\x1b");

        $presort = substr($text,0,$pos);
        $nonsort = substr($text, $pos + 2, ($pos2 - $pos) - 2);

        $sort = substr($text, $pos2 + 2);

        return trim("{$presort}{$nonsort} *{$sort}");
    }

	function fixSBNAccent($text) {
		$pos = strpos($text,"\x0e\x41\x75\x0f");
		return $text;
	}
}