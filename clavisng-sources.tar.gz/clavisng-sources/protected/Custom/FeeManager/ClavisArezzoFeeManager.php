<?php
/**
 * ClavisPistoiaFeeManager class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Dario Rigolin <dario@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2014 Comperio
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Interfaces
 */

/**
 * ClavisArezzoFeeManager class
 *
 * This class implements the FeeManager logic for Arezzo 0.20 cent per day
 * Added INT-2633 If ItemMedia == "O" (eBook Reader) 1.00 euro per day
 *
 * @author Dario Rigolin <dario@comperio.it>
 * @version 2.7
 * @package Interfaces
 * @since 2.7.0
 */
class ClavisArezzoFeeManager extends TModule implements IFeeManager
{

    private $fromDate;

    /**
     * It verifies if a Patron has any fee related to actual loan
     *
     * @param Patron $patron
     *
     * @return boolean
     *
     */
    public function patronHasFee(Patron $patron)
    {

        if (!in_array($this->getUser()->getActualLibraryId(), array(2, 39, 40, 41, 74))) // Valid only on Arezzo Library id=2
            return false;

        $lateLoans = LoanQuery::create()
            ->leftJoinLoanFee()
            ->withColumn("IFNULL(DATEDIFF(loan_date_end,due_date),DATEDIFF(CURDATE(),due_date))", "LateDays")
            ->withColumn("(IFNULL(DATEDIFF(loan_date_end,due_date),DATEDIFF(CURDATE(),due_date)) - IFNULL(grace_days,0))", "LateDaysReal")
            ->filterByPatron($patron)
            ->filterByLoanDateBegin($this->fromDate, Criteria::GREATER_EQUAL)
            ->filterByToLibrary($this->getUser()->getActualLibraryId())
            ->filterByItemHomeLibraryId($this->getUser()->getActualLibraryId())
            ->where("(LoanFee.FeeStatus IS NULL OR LoanFee.FeeStatus = 'P')")
            ->where("((Loan.LoanDateEnd IS NOT NULL AND Loan.LoanDateEnd > Loan.DueDate) OR (Loan.LoanDateEnd IS NULL AND Loan.DueDate < CURDATE() ))")
            ->filterByLoanStatus(array(ItemPeer::LOANSTATUS_CLOSED))
            ->having("LateDaysReal > 0")
            ->count();

        Prado::log(__METHOD__ . "Fee loans = " . $lateLoans);

        return ($lateLoans > 0);
    }

    /**
     * It verifies if a Loan is late and has a fee
     *
     * @param Loan $loan
     *
     * @return boolean
     *
     */
    public function loanHasFee(Loan $loan)
    {
        return true;
    }

    /**
     * It verifies if a Loan is late and has a fee
     *
     * @param Patron $p
     * @param bool $actual If
     *
     * @return mixed
     *
     */
    public function getPatronFeeDetail(Patron $p, $actual = true)
    {
        $feeClass = array();

        if (!in_array($this->getUser()->getActualLibraryId(), array(2, 39, 40, 41, 74))) {
            //Librarian isn't working on Arezzo no fees are display.

            return ($actual) ? "" : array("Total" => 0.0, "Loans" => array(), 'Summary' => array());
        }

        Prado::log(__METHOD__ . " $actual");


        $lateLoansFilter = LoanQuery::create()
            ->leftJoinLoanFee()
            ->withColumn("IFNULL(DATEDIFF(loan_date_end,due_date),DATEDIFF(CURDATE(),due_date))", "LateDays")
            ->filterByPatron($p)
            ->filterByLoanDateBegin($this->fromDate, Criteria::GREATER_EQUAL)
            ->filterByToLibrary($this->getUser()->getActualLibraryId())
            ->filterByItemHomeLibraryId($this->getUser()->getActualLibraryId())
            ->where("(LoanFee.FeeStatus IS NULL OR LoanFee.FeeStatus = 'P')")
            ->where("( (Loan.LoanDateEnd IS NOT NULL AND DATE(Loan.LoanDateEnd) > DATE(Loan.DueDate) ) OR (Loan.LoanDateEnd IS NULL AND Loan.DueDate < CURDATE() ))");

        if ($actual)
            $lateLoansFilter->filterByLoanStatus(ItemPeer::LOANSTATUS_INLOAN);
        else
            $lateLoansFilter->filterByLoanStatus(ItemPeer::LOANSTATUS_CLOSED);

        $lateLoans = $lateLoansFilter->find();

        $now = new DateTime();

        $feeClass['total'] = 0.0;
        $feeClass['maxfeedays'] = 0;

        foreach ($this->getFascie() as $fascia) {
            $feeClass['fees'][$fascia]['loans'] = array();
            $feeClass['fees'][$fascia]['maxdays'] = 0;
            $feeClass['fees'][$fascia]['total'] = 0;
            $feeClass['fees'][$fascia]['text'] = "";
        }

        Prado::log($feeClass);

        foreach ($lateLoans as $l) {
            /** @var  $l Loan */
            Prado::log("Check loan");


            $dDiff = $l->getLateDays();

            $lfee = $l->getLoanFees();
            if (count($lfee) == 0) {
                // Create a new LoanFee if the loan is late
                $lf = new LoanFee();
                $lf->setLoan($l);
                $lf->setGraceDays(0);
                $lf->setGraceNote("");
                $lf->setFeeStatus("P"); // Pending status
                $lf->setLibraryId($this->getUser()->getActualLibraryId());
                $lf->setPatron($p);
                $lf->setRealAmmount(0.0);
                $lf->setTotalAmmount(0.0);
                $lf->setNote("");
                $lf->setFeeClass("");
                $lf->save();
            } else {
                $lf = $lfee[0];
            }

            $larr['LoanId'] = $l->getLoanId();
            $larr['ItemId'] = $l->getItemId();
            $larr['Collocation'] = $l->getCollocation();
            $larr['Title'] = $l->getTitle() . " (" . $l->getInvNumber() . ")";
            $larr['DueDate'] = $l->getDueDate();
            $larr['LoanDateBegin'] = $l->getLoanDateBegin();
            $larr['LoanDateEnd'] = $l->getLoanDateEnd();
            $larr['LoanFee'] = $lf;
            $larr['LateDays'] = $dDiff;
            $larr['GraceDays'] = $lf->getGraceDays();
            $larr['GraceNote'] = $lf->getGraceNote();
            $larr['LateDaysGraced'] = $dDiff - $lf->getGraceDays();
            if ($l->getItem()->getItemMedia() == "O") {
                $larr['FeeValue'] = 1.00 * $larr['LateDaysGraced'];
            } else {
                $larr['FeeValue'] = 0.20 * $larr['LateDaysGraced'];
            }

            $larr['FeeClass'] = "Ritardo generico";

            $lf->setRealAmmount($larr['FeeValue']);
            $lf->setTotalAmmount($larr['FeeValue']);

            $lf->setFeeClass("Ritardo generico")->save();
            $feeClass['fees']["Ritardo generico"]['loans'][] = $larr;

            $feeClass['fees']["Ritardo generico"]['maxdays'] += $larr['LateDaysGraced'];
            $feeClass['fees']["Ritardo generico"]['total'] += $larr['FeeValue'];

        }

        foreach ($feeClass['fees'] as $fascia => $data) {
            if (count($data['loans']) == 0) continue;
            Prado::log("{$fascia} - " . $feeClass['fees'][$fascia]['FeeValue']);


            $feeClass['fees'][$fascia]['total'] += $feeClass['fees'][$fascia]['FeeValue'];
            $feeClass['total'] += $feeClass['fees'][$fascia]['total'];

        }
        if ($actual) {
            $feeReport = "<table><tr><th>Titolo</th><th>Rientro previsto</th><th>Ritardo (gg)</th><th>Fascia</th></tr>";
            foreach ($feeClass['fees'] as $fascia => $data) {
                if (count($data['loans']) == 0) continue;

                foreach ($data['loans'] as $l) {
                    $feeReport .= "<tr>";
                    $feeReport .= "<td>{$l['Title']}</td>";
                    $feeReport .= "<td>" . substr($l['DueDate'], 0, 10) . "</td>";
                    $feeReport .= "<td>{$l['LateDays']}</td>";
                    $feeReport .= "<td>{$fascia}</td>";
                    $feeReport .= "</tr>";
                }
                $feeReport .= "<tr><td colspan='2'>Totale ({$data['maxdays']} gg - " . count($data['loans']) . " pezzi)</td><td>€ {$data['total']}</td><td>{$fascia}</td></tr>";
            }
            $feeReport .= "<tr><td colspan=\"2\">Totale complessivo</td><td>€ {$feeClass['total']}</td></tr>";
            $feeReport .= "</table>";
        } else {

            $feeReport = $this->remapData($feeClass);
        }


        return $feeReport;
    }

    public function getFascie()
    {
        return array(
            "Ritardo generico",
        );
    }

    public function setFromDate($value)
    {
        $this->fromDate = new DateTime($value);
    }

    public function getFromDate()
    {
        return $this->fromDate;
    }

    private function remapData($feeList)
    {
        $result['Loans'] = array();
        $result['Summary'] = array();
        $result['Total'] = $feeList['total'];

        foreach ($feeList['fees'] as $feeRange => $feeData) {
            if (count($feeData['loans']) == 0) continue;
            $result['Loans'] = array_merge($result['Loans'], $feeData['loans']);
            $result['Summary'][] = array(
                "Descr" => "$feeRange ({$feeData['maxdays']}gg - " . count($feeData['loans']) . " elementi)",
                "Total" => $feeData['total']);
        }

        return $result;

    }
}
