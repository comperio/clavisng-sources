<?php

/**
 * TARIFFE E CRITERI PER IL CALCOLO DELL'IMPORTO
 * ---------------------------------------------------------------------------------------------------------------------
 *
 * Fascia di Tolleranza
 * ---------------------------------------------------------------------------------------------------------------------
 * Durante la “fascia” non c'è riscossione di tariffa; se però il ritardo supera la fascia di tolleranza anche di 1 solo
 * giorno, la tariffa viene calcolata sull'intera durata del ritardo COMPRESI i giorni di tolleranza.
 *
 * su LIBRI, AUDIO-LIBRI e CORSI su NBM:........... + 7 gg rispetto la scadenza;
 * su altri NBM e PERIODICI:....................... + 3 gg rispetto la scadenza.
 *
 * Tariffe per ritardata riconsegna
 * ---------------------------------------------------------------------------------------------------------------------
 * (vale su ogni tipologia di materiale)
 *
 * € 0,30 per ogni pezzo    (o kit di prestito) per ogni settimana (7gg) o sua frazione di ritardo.
 *
 * Esempio: se si restituisce un libro dopo 8 giorni dalla sua scadenza la tariffa da applicare sarà pari a 2 settimane
 * (i primi 7 gg + 1 giorno della settimana successiva che – poiché la settimana non è frazionabile – vale per un'ulteriore
 * settimana).
 *
 * Taglia minima e arrotondamenti degli atti di pagamento
 * ---------------------------------------------------------------------------------------------------------------------
 *
 * Taglia minima
 * ---------------------------------------------------------------------------------------------------------------------
 * L'importo minimo di un singolo atto di pagamento (ossia la sommatoria del calcolo della tariffa applicata sull'utente)
 * è di € 0,50 anche qualora l'importo da pagare (in base al calcolo della tariffa) fosse inferiore a questa cifra.
 *
 * Arrotondamenti
 * ---------------------------------------------------------------------------------------------------------------------
 * Per la definizione degli importi da pagare superiori ai € 0,50, al termine del calcolo della tariffa basata su ogni
 * singolo materiale restituito in ritardo, verrà applicato un meccanismo di arrotondamento in eccesso o in difetto, per
 * mantenere l'importo da pagare multiplo di € 0,50. In caso di equidistanza (dall'arrotondamente superiore e inferiore),
 * si applicherà l'arrotondamento per difetto.
 *
 * Esempi: se il calcolo della tariffa definisce un importo di:
 * € 0,60 → l'importo da pagare sarà di € 0,50
 * € 0,75 → l'importo da pagare sarà di € 0,50
 * € 0,90 → l'importo da pagare sarà di € 1,00
 * € 1,25 → l'importo da pagare sarà di € 1,00
 *
 * Il calcolo dell'arrotondamento viene effettuato come ultima operazione di calcolo, sulla sommatoria delle varie
 * componenti di costo della tariffa.
 *
 * Quindi se l'utente deve pagare una tariffa calcolata su 2 documenti in ritardo ed il totale va ridotto del 50%
 * (perché si tratta di un minore di 15 anni), l'arrotondamento andrà applicato SOLTANTO sulla risultante di tutti i calcoli
 * precedenti, ossia:
 *
 * definizione tariffa per 1o doc in ritardo
 * +
 * definizione tariffa per 2o doc in ritardo
 * =
 * calcolo del totale provvisorio
 * riduzione del 50% del totale provvisorio
 * arrotondamento
 *
 * Altre Sanzioni non monetizzabili
 * ---------------------------------------------------------------------------------------------------------------------
 * L'iter dei solleciti prevede che quando, relativamente ad un doc in ritardo, viene spedita la comunicazione di 2o
 * livello, la tessera di quell'utente venga sospesa in attesa di regolarizzazione (ossia la restituzione del materiale
 * + pagamento della relativa tariffa).    L'NRE del caso assume lo stato di “NON RESTITUITO” fintanto che non venga
 * effettivamente reso.
 *
 * Tetti massimi della tariffa
 * ---------------------------------------------------------------------------------------------------------------------
 * La tariffa non può eccedere i seguenti limiti:
 *
 * Per ogni singolo fascicolo di PERIODICO:        € 5,00
 * Per ogni singolo LIBRO o NBM:            € 10,00
 * Tetto massimo per singolo atto di pagamento:    € 25,00
 * (a prescindere dal nro di materiali in ritardo sulla tessera)
 *
 * Riduzione della tariffa per minori di 15 anni
 * ---------------------------------------------------------------------------------------------------------------------
 * (quindi fino a 14 anni + 364 giorni)
 *
 * Su tessere di utenti di questo tipo, LIMITATAMENTE agli NRE associati ad una descrizione catalografica qualificata “R”
 * (ossia materiale per ragazzi), l'importo finale della tariffa (tetti massimi compresi) va ridotto del 50%.
 */


class ClavisCubiFeeManager extends TModule implements IFeeManager
{
    const LIBRI_AUDIO_LIBRI_E_CORSI_SU_NBM = 'LIBRI';
    const ALTRI_NBM_E_PERIODICI = 'NBM e PERIODICI';

    const FASCIA3_DAYS = 7;
    const FASCIA7_DAYS = 7;
    const GRACE_PERIOD_IN_DAYS = 7;

    const FEE_PRICE = 0.30;
    const MIN_FEE_PRICE = 0.50;

    const MAX_FEE_PAYMENT_ACT = 25.00;
    const MAX_FEE_BOOK = 10.00;
    const MAX_FEE_ISSUE = 5.00;

    const UNDER_15_DISCOUNT = 0.5;
    const UNDER_15_HAS_LIVED_DAYS_MAX = 5110 + 364; // 15 years and 364 days.

    private $fromDate;

    public function patronHasFee(Patron $patron)
    {
        $lateLoans = LoanQuery::create()
            ->leftJoinLoanFee()
            ->withColumn("IFNULL(DATEDIFF(loan_date_end,due_date),DATEDIFF(CURDATE(),due_date))", "LateDays")
            ->withColumn("(IFNULL(DATEDIFF(loan_date_end,due_date),DATEDIFF(CURDATE(),due_date)) - IFNULL(grace_days,0))", "LateDaysReal")
            ->filterByPatron($patron)
            ->filterByLoanDateBegin($this->fromDate, Criteria::GREATER_EQUAL)
            ->where("(LoanFee.FeeStatus IS NULL OR LoanFee.FeeStatus = 'P')")
            ->where("((Loan.LoanDateEnd IS NOT NULL AND Loan.LoanDateEnd > Loan.DueDate) OR (Loan.LoanDateEnd IS NULL AND Loan.DueDate < CURDATE() ))")
            ->filterByLoanStatus(array(ItemPeer::LOANSTATUS_CLOSED))
            ->having("LateDaysReal > 0")
            ->count();

        return ($lateLoans > 0);
    }

    public function loanHasFee(Loan $loan)
    {
        return true;
    }

    public function getPatronFeeDetail(Patron $p, bool $actual = true)
    {
        // ---- get late loans -----------------------------------------------------------------------------------------
        $lateLoansFilter = LoanQuery::create()
            ->leftJoinLoanFee()
            ->withColumn("IFNULL(DATEDIFF(loan_date_end,due_date),DATEDIFF(CURDATE(),due_date))", "LateDays")
            ->filterByPatron($p)
            ->filterByLoanDateBegin($this->fromDate, Criteria::GREATER_EQUAL)
            ->where("(LoanFee.FeeStatus IS NULL OR LoanFee.FeeStatus = 'P')")
            ->where("( (Loan.LoanDateEnd IS NOT NULL AND DATE(Loan.LoanDateEnd) > DATE(Loan.DueDate) ) OR (Loan.LoanDateEnd IS NULL AND Loan.DueDate < CURDATE() ))");

        if ($actual) {
            $lateLoansFilter->filterByLoanStatus(ItemPeer::LOANSTATUS_INLOAN);
        } else {
            $lateLoansFilter->filterByLoanStatus(ItemPeer::LOANSTATUS_CLOSED);
        }

        $sql = $lateLoansFilter->toString();

        // --------------------------------------------------------------------------------------------
        $lateLoans = $lateLoansFilter->find();
        $now = new DateTime();

        foreach ($this->getFascie() as $fee_category) {
            $feeClass['fees'][$fee_category]['loans'] = array();
            $feeClass['fees'][$fee_category]['maxdays'] = 0;
            $feeClass['fees'][$fee_category]['total'] = 0;
            $feeClass['fees'][$fee_category]['text'] = "";
        }


        /** @var  $l Loan */
        foreach ($lateLoans as $l) {

            $loanLateForDays = $l->getLateDays();
            $lfee = $l->getLoanFees();

            if (count($lfee) === 0) {
                $lf = new LoanFee();
                $lf->setLoan($l);
                $lf->setGraceDays(0);
                $lf->setGraceNote("");
                $lf->setFeeStatus("P"); // Pending status
                $lf->setLibraryId($this->getUser()->getActualLibraryId());
                $lf->setPatron($p);
                $lf->setRealAmmount(0.0);
                $lf->setTotalAmmount(0.0);
                $lf->setNote("");
                $lf->setFeeClass("");
                $lf->save();
            } else {
                $lf = $lfee[0];
            }

            $larr['LoanId'] = $l->getLoanId();
            $larr['ItemId'] = $l->getItemId();
            $larr['Collocation'] = $l->getCollocation();
            $larr['Title'] = $l->getTitle() . " (" . $l->getInvNumber() . ")";
            $larr['DueDate'] = $l->getDueDate();
            $larr['LoanDateBegin'] = $l->getLoanDateBegin();
            $larr['LoanDateEnd'] = $l->getLoanDateEnd();
            $larr['LoanFee'] = $lf;
            $larr['LateDays'] = $loanLateForDays;
            $larr['GraceDays'] = $lf->getGraceDays();
            $larr['GraceNote'] = $lf->getGraceNote();
            $larr['LateDaysGraced'] = $loanLateForDays - $lf->getGraceDays();
            $larr['FeeValue'] = 0.0;

            $itemMedia = $l->getItemMedia();
            $fee_category = $this->getFasciaFromItemMedia($itemMedia);

            if ($loanLateForDays <= self::GRACE_PERIOD_IN_DAYS) {
                continue;
            }

            $feeValue = self::FEE_PRICE * $this->_getNumWeeks($larr['LateDaysGraced']);

            $larr['FeeClass'] = $fee_category;
            $larr['FeeValue'] = ($fee_category === self::LIBRI_AUDIO_LIBRI_E_CORSI_SU_NBM)
                ? min(self::MAX_FEE_BOOK, $feeValue)
                : min(self::MAX_FEE_ISSUE, $feeValue);

            $lf->setRealAmmount($larr['FeeValue']);
            $lf->setTotalAmmount($larr['FeeValue']);
            $lf->setFeeClass($fee_category)->save();

            $feeClass['fees'][$fee_category]['loans'][] = $larr;

            $feeClass['fees'][$fee_category]['total'] += $larr['FeeValue'];
            $feeClass['total'] += $larr['FeeValue'];
        }

        // minori di 15
        if ($this->isUnderFifteen($p)) {
            $feeClass['fees'][self::LIBRI_AUDIO_LIBRI_E_CORSI_SU_NBM]['total'] *= self::UNDER_15_DISCOUNT;
            $feeClass['fees'][self::ALTRI_NBM_E_PERIODICI]['total'] *= self::UNDER_15_DISCOUNT;
            $feeClass['total'] *= self::UNDER_15_DISCOUNT;
        }

        // tetto sul totale inferiore (0.50 minimo) e superiore (25.00 massimo)
        $feeClass['total'] = $feeClass['total'] > 0
            ? max(min($feeClass['total'], self::MAX_FEE_PAYMENT_ACT), self::MIN_FEE_PRICE)
            : 0;

        $feeClass['fees'][self::LIBRI_AUDIO_LIBRI_E_CORSI_SU_NBM]['total'] = $this->cubiRoundTotal($feeClass['fees'][self::LIBRI_AUDIO_LIBRI_E_CORSI_SU_NBM]['total']);
        $feeClass['fees'][self::ALTRI_NBM_E_PERIODICI]['total'] = $this->cubiRoundTotal($feeClass['fees'][self::ALTRI_NBM_E_PERIODICI]['total']);
        $feeClass['total'] = $this->cubiRoundTotal($feeClass['total']);

        // -------------------------------------------------------------------------------------------------------------

        if ($actual) {
            $feeReport = "<table><tr><th>Titolo</th><th>Rientro previsto</th><th>Ritardo (gg)</th><th>Fascia</th><th>Importo</th></tr>";
            foreach ($feeClass['fees'] as $fascia => $data) {
                if (count($data['loans']) == 0) continue;

                foreach ($data['loans'] as $l) {
                    $feeReport .= "<tr>";
                    $feeReport .= "<td>{$l['Title']}</td>";
                    $feeReport .= "<td>" . substr($l['DueDate'], 0, 10) . "</td>";
                    $feeReport .= "<td>{$l['LateDays']}</td>";
                    $feeReport .= "<td>{$fascia}</td>";
                    $feeReport .= "<td>€ {$l['FeeValue']}</td>";
                    $feeReport .= "</tr>";
                }
                $feeReport .= "<tr><td colspan='2'>Totale " . count($data['loans']) . " pezzi</td><td>€ {$data['total']}</td><td>{$fascia}</td></tr>";
            }
            $feeReport .= "<tr><td colspan=\"2\">Totale complessivo</td><td>€ {$feeClass['total']}</td></tr>";
            $feeReport .= "</table>";
        } else {
            $feeReport = $this->remapData($feeClass);
        }

        return $feeReport;
    }

    public function getFascie()
    {
        return [self::LIBRI_AUDIO_LIBRI_E_CORSI_SU_NBM, self::ALTRI_NBM_E_PERIODICI];
    }

    public function setFromDate($value)
    {
        $this->fromDate = new DateTime($value);
    }

    public function getFromDate()
    {
        return $this->fromDate;
    }

    private function _getNumWeeks($days)
    {
        return ceil($days / 7);
    }

    private function getFasciaFromItemMedia($itemMedia)
    {

        // su LIBRI, AUDIO-LIBRI e CORSI su NBM:........... + 7 gg rispetto la scadenza
        // su altri NBM e PERIODICI:....................... + 3 gg rispetto la scadenza
        $map = [
            'E' => self::ALTRI_NBM_E_PERIODICI,             //Audio
            'L' => self::LIBRI_AUDIO_LIBRI_E_CORSI_SU_NBM,  //Audiolibro -----------------------
            'U' => self::ALTRI_NBM_E_PERIODICI,             //Cartografico
            'D' => self::LIBRI_AUDIO_LIBRI_E_CORSI_SU_NBM,  //Corso Multimediale ----------------
            'R' => self::ALTRI_NBM_E_PERIODICI,  //Programmi e File
            'G' => self::ALTRI_NBM_E_PERIODICI,  //Materiale Grigio
            'T' => self::ALTRI_NBM_E_PERIODICI,  //Kit
            'C' => self::ALTRI_NBM_E_PERIODICI,  //Collana
            'F' => self::LIBRI_AUDIO_LIBRI_E_CORSI_SU_NBM,  //Monografie ---------------------------
            'N' => self::ALTRI_NBM_E_PERIODICI,  //NBM
            'S' => self::ALTRI_NBM_E_PERIODICI,  //Periodici
            'Q' => self::ALTRI_NBM_E_PERIODICI,  //Spartiti e Partiture
            'W' => self::ALTRI_NBM_E_PERIODICI,  //Video
            'O' => self::ALTRI_NBM_E_PERIODICI,  //Fotografia
        ];

        if (array_key_exists($itemMedia, $map) && isset($map[$itemMedia])) {
            return trim($map[$itemMedia]);
        }

        return self::LIBRI_AUDIO_LIBRI_E_CORSI_SU_NBM;
    }

    private function cubiRoundTotal($total)
    {
        return round($total * 2, 0, PHP_ROUND_HALF_DOWN) / 2;
    }

    /**
     * @throws PropelException
     */
    private function isLoanItemForRagazzi(Loan $loan)
    {
        $manifestation = $loan->getManifestation();
        if ($manifestation instanceof Manifestation) {
            try {
                $tm = $manifestation->getTurboMarc();
                $ragazzi = (string)$tm->d100->getCDF('a', 17);
                return ($ragazzi === 'a');

            } catch (Exception $e) {
                return false;
            }
        }
        return false;
    }

    private function isUnderFifteen(Patron $p): bool
    {
        try {
            $born = $p->getBirthDate('Y-m-d');
            $age = DateTime::createFromFormat('Y-m-d', $born)->diff(new DateTime('now'))->y;

            return ($age < 15);

        } catch (Exception $e) {
            error_log("Eccezione FeeCubi:" . $e->getMessage());
            return false;
        }
    }

    private function remapData($feeList)
    {
        $result['Loans'] = array();
        $result['Summary'] = array();
        $result['Total'] = $feeList['total'];

        foreach ($feeList['fees'] as $feeRange => $feeData) {
            if (count($feeData['loans']) == 0) continue;
            $result['Loans'] = array_merge($result['Loans'], $feeData['loans']);
            $result['Summary'][] = array(
                "Descr" => "$feeRange ({$feeData['maxdays']}gg - " . count($feeData['loans']) . " elementi)",
                "Total" => $feeData['total']);
        }

        return $result;

    }
}
