<?php
/**
 * ClavisPistoiaFeeManager class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Dario Rigolin <dario@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2014 Comperio
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Interfaces
 */

/**
 * ClavisPistoiaFeeManager class
 *
 * This class implements the FeeManager logic for Pistoia
 *
 * @author Dario Rigolin <dario@comperio.it>
 * @version 2.7
 * @package Interfaces
 * @since 2.7.0
 */

class ClavisPistoiaFeeManager extends TModule implements IFeeManager
{

    /**
     *
     */
    const FASCIA21 = 'Da 1 a 21gg';
    const FASCIA28 = 'Da 22 a 28gg';
    const FASCIA60 = 'Da 29 a 60gg';
    const FASCIAOVER60 = 'Oltre 60gg';
    const FASCIAEBOOK = 'eBook Reader';

    private  $fromDate;

    /**
     * It verifies if a Patron has any fee related to actual loan
     *
     * @param Patron $patron
     *
     * @return boolean
     *
     */
    public function patronHasFee(Patron $patron)
    {

        if($this->getUser()->getActualLibraryId() != 2)
            return false;

        $lateLoans = LoanQuery::create()
            ->leftJoinLoanFee()
            ->withColumn("calcdays(due_date, loan_date_end, 2)","LateDays")
            ->withColumn("calcdays(due_date, loan_date_end, 2) - IFNULL(grace_days,0)","LateDaysReal")
            ->filterByPatron($patron)
            ->filterByLoanDateBegin($this->fromDate,Criteria::GREATER_EQUAL)
            ->filterByToLibrary(2)
            ->filterByItemHomeLibraryId(2)
            ->where("(LoanFee.FeeStatus IS NULL OR LoanFee.FeeStatus = 'P')")
            ->where("((Loan.LoanDateEnd IS NOT NULL AND Loan.LoanDateEnd > Loan.DueDate) OR (Loan.LoanDateEnd IS NULL AND Loan.DueDate < CURDATE() ))")
            ->filterByLoanStatus(array(ItemPeer::LOANSTATUS_CLOSED))
            ->having("LateDaysReal > 0")
            ->count();

        return ($lateLoans > 0);
    }

    /**
     * It verifies if a Loan is late and has a fee
     *
     * @param Loan $loan
     *
     * @return boolean
     *
     */
    public function loanHasFee(Loan $loan)
    {
        return true;
    }

    /**
     * It verifies if a Loan is late and has a fee
     *
     * @param Patron $p
     * @param bool  $actual If
     *
     * @return mixed
     *
     */
    public function getPatronFeeDetail(Patron $p,$actual = true)
    {
        $feeClass = array();

        if($this->getUser()->getActualLibraryId() != 2)
        {
            //Librarian isn't working on Pistoia no fees are display.

            return ($actual)?"":array("Total"=>0.0, "Loans"=>array(),'Summary'=>array());
        }

        $lateLoansFilter = LoanQuery::create()
            ->leftJoinLoanFee()
            ->withColumn("calcdays(due_date, loan_date_end, 2)","LateDays")
            ->filterByPatron($p)
            ->filterByLoanDateBegin($this->fromDate,Criteria::GREATER_EQUAL)
            ->filterByToLibrary($this->getUser()->getActualLibraryId())
            ->filterByItemHomeLibraryId($this->getUser()->getActualLibraryId())
            ->where("(LoanFee.FeeStatus IS NULL OR LoanFee.FeeStatus = 'P')")
            ->where("( (Loan.LoanDateEnd IS NOT NULL AND DATE(Loan.LoanDateEnd) > DATE(Loan.DueDate) ) OR (Loan.LoanDateEnd IS NULL AND Loan.DueDate < CURDATE() ))")
        ;

        if($actual)
            $lateLoansFilter->filterByLoanStatus(ItemPeer::LOANSTATUS_INLOAN);
        else
            $lateLoansFilter->filterByLoanStatus(ItemPeer::LOANSTATUS_CLOSED);

        $lateLoans = $lateLoansFilter->find();

        $now = new DateTime();

        $feeClass['total'] = 0.0;
        $feeClass['maxfeedays'] = 0;

        foreach($this->getFascie() as $fascia)
        {
            $feeClass['fees'][$fascia]['loans']=array();
            $feeClass['fees'][$fascia]['maxdays']=0;
            $feeClass['fees'][$fascia]['total']=0;
            $feeClass['fees'][$fascia]['text']="";
        }

        foreach($lateLoans as $l)
        {
            /** @var  $l Loan */

           /* if($actual)
                $dDiff = $now->diff($l->getDueDate(null));
            else
                $dDiff = $l->getLoanDateEnd(null)->diff($l->getDueDate(null));
            */

            $dDiff = $l->getLateDays();

            $lfee = $l->getLoanFees();
            if(count($lfee) == 0)
            {
                // Create a new LoanFee if the loan is late
                $lf = new LoanFee();
                $lf->setLoan($l);
                $lf->setGraceDays(0);
                $lf->setGraceNote("");
                $lf->setFeeStatus("P"); // Pending status
                $lf->setLibraryId($this->getUser()->getActualLibraryId());
                $lf->setPatron($p);
                $lf->setRealAmmount(0.0);
                $lf->setTotalAmmount(0.0);
                $lf->setNote("");
                $lf->setFeeClass("");
                $lf->save();
            } else
                $lf = $lfee[0];

            $larr['LoanId']=$l->getLoanId();
            $larr['ItemId']=$l->getItemId();
            $larr['Collocation']=$l->getCollocation();
            $larr['Title']=$l->getTitle() . " (". $l->getInvNumber() .")";
            $larr['DueDate']=$l->getDueDate();
            $larr['LoanDateBegin']=$l->getLoanDateBegin();
            $larr['LoanDateEnd']=$l->getLoanDateEnd();
            $larr['LoanFee']=$lf;
            $larr['LateDays'] = $dDiff;
            $larr['GraceDays']=$lf->getGraceDays();
            $larr['GraceNote']=$lf->getGraceNote();
            $larr['LateDaysGraced']= $dDiff - $lf->getGraceDays();
            $larr['FeeValue']=0.0;

            if($l->getItemMedia() == 'O') // EbookReader
            {
                if($feeClass['fees'][self::FASCIAEBOOK]['maxdays'] < $dDiff)
                    $feeClass['fees'][self::FASCIAEBOOK]['maxdays']=$dDiff;

                $larr['FeeClass']=self::FASCIAEBOOK;
                $lf->setFeeClass(self::FASCIAEBOOK)->save();

                $feeClass['fees'][self::FASCIAEBOOK]['loans'][] = $larr;
            }
            else if($larr['LateDaysGraced'] <= 21)
            {
                if($feeClass['fees'][self::FASCIA21]['maxdays'] < $larr['LateDaysGraced'])
                    $feeClass['fees'][self::FASCIA21]['maxdays'] = $larr['LateDaysGraced'];

                $larr['FeeClass']=self::FASCIA21;
                $lf->setFeeClass(self::FASCIA21)->save();

                $feeClass['fees'][self::FASCIA21]['loans'][] = $larr;
            }
            else if($larr['LateDaysGraced'] <= 28)
            {
                if($feeClass['fees'][self::FASCIA28]['maxdays'] < $larr['LateDaysGraced'])
                    $feeClass['fees'][self::FASCIA28]['maxdays']=$larr['LateDaysGraced'];

                $larr['FeeClass']=self::FASCIA28;
                $lf->setFeeClass(self::FASCIA28)->save();
                $feeClass['fees'][self::FASCIA28]['loans'][] = $larr;
            }
            else if($larr['LateDaysGraced'] <= 60)
            {
                if($feeClass['fees'][self::FASCIA60]['maxdays'] < $larr['LateDaysGraced'])
                    $feeClass['fees'][self::FASCIA60]['maxdays'] = $larr['LateDaysGraced'];

                $larr['FeeClass']=self::FASCIA60;
                $lf->setFeeClass(self::FASCIA60)->save();
                $feeClass['fees'][self::FASCIA60]['loans'][] = $larr;
            }
            else
            {
                if($feeClass['fees'][self::FASCIAOVER60]['maxdays'] < $larr['LateDaysGraced'])
                    $feeClass['fees'][self::FASCIAOVER60]['maxdays']=$larr['LateDaysGraced'];

                $larr['FeeClass']=self::FASCIAOVER60;
                $lf->setFeeClass(self::FASCIAOVER60)->save();
                $feeClass['fees'][self::FASCIAOVER60]['loans'][] = $larr;
            }
        }

        // Move all loans to the higher fee class
        $highFeeClass = null;
        foreach(array(self::FASCIAOVER60,self::FASCIA60,self::FASCIA28,self::FASCIA21) as $f)
        {
            if(isset($feeClass['fees'][$f]) && count($feeClass['fees'][$f]['loans']) > 0 && $highFeeClass == null)
            {
                // Found the highest rate
                $highFeeClass = $f;
            }
            elseif(isset($feeClass['fees'][$f]) && count($feeClass['fees'][$f]['loans']) > 0)
            {
                // Aggregate loans to the highest fees
                $feeClass['fees'][$highFeeClass]['loans'] = array_merge($feeClass['fees'][$highFeeClass]['loans'],$feeClass['fees'][$f]['loans']);
                $feeClass['fees'][$f]['loans'] = array();
                $feeClass['fees'][$f]['total'] = 0.0;
            }
        }

        foreach($feeClass['fees'] as $fascia=>$data)
        {
            if(count($data['loans']) == 0) continue;

            if($fascia == self::FASCIAEBOOK)
            {
                $feeClass['fees'][$fascia]['total'] = $feeClass['fees'][$fascia]['maxdays'] * 3.0;
                $feeClass['total'] += $feeClass['fees'][$fascia]['total'];
            }
            else if($fascia == self::FASCIA21)
            {
                if(count($data['loans']) > 5)
                    $dayCost = 0.20;
                else
                    $dayCost = 0.10;

                $feeClass['fees'][$fascia]['total'] = $feeClass['fees'][$fascia]['maxdays'] * $dayCost;
                $feeClass['total'] += $feeClass['fees'][$fascia]['total'];
            }
            else if($fascia == self::FASCIA28)
            {
                if(count($data['loans'])> 5)
                    $cost = 8.00;
                else
                    $cost = 4.00;

                $feeClass['fees'][$fascia]['total'] = $cost;
                $feeClass['total'] += $feeClass['fees'][$fascia]['total'];
            }
            else if($fascia == self::FASCIA60)
            {
                if(count($data['loans'])> 5)
                    $cost = 16.00;
                else
                    $cost = 8.00;

                $feeClass['fees'][$fascia]['total'] = $cost;
                $feeClass['total'] += $feeClass['fees'][$fascia]['total'];
            }
            else if($fascia == self::FASCIAOVER60)
            {
                if(count($data['loans']) > 5)
                    $cost = 24.00;
                else
                    $cost = 12.00;

                $feeClass['fees'][$fascia]['total'] = $cost;
                $feeClass['total'] += $feeClass['fees'][$fascia]['total'];
            }

        }
        if($actual)
        {
            $feeReport = "<table><tr><th>Titolo</th><th>Rientro previsto</th><th>Ritardo (gg)</th><th>Fascia</th></tr>";
            foreach($feeClass['fees'] as $fascia=>$data)
            {
               if(count($data['loans']) == 0) continue;

               foreach($data['loans'] as $l)
               {
                   $feeReport .= "<tr>";
                   $feeReport .= "<td>{$l['Title']}</td>";
                   $feeReport .= "<td>".substr($l['DueDate'],0,10)."</td>";
                   $feeReport .= "<td>{$l['LateDays']}</td>";
                   $feeReport .= "<td>{$fascia}</td>";
                   $feeReport .= "</tr>";
               }
                $feeReport .= "<tr><td colspan='2'>Totale ({$data['maxdays']} gg - ". count($data['loans'])." pezzi)</td><td>€ {$data['total']}</td><td>{$fascia}</td></tr>";
            }
            $feeReport .= "<tr><td colspan=\"2\">Totale complessivo</td><td>€ {$feeClass['total']}</td></tr>";
            $feeReport .= "</table>";
        } else {

            $feeReport = $this->remapData($feeClass);
        }


        return $feeReport;
    }

    public function getFascie()
    {
        return array(
            self::FASCIA21,
            self::FASCIA28,
            self::FASCIA60,
            self::FASCIAOVER60,
            self::FASCIAEBOOK
        );
    }

    public function setFromDate($value)
    {
        $this->fromDate = new DateTime($value);
    }

    public function getFromDate()
    {
        return $this->fromDate;
    }

    private function remapData($feeList)
    {
        $result['Loans'] = array();
        $result['Summary'] = array();
        $result['Total'] = $feeList['total'];

        foreach($feeList['fees'] as $feeRange=>$feeData)
        {
            if(count($feeData['loans']) == 0) continue;
            $result['Loans'] = array_merge($result['Loans'],$feeData['loans']);
            $result['Summary'][] = array(
                "Descr" => "$feeRange ({$feeData['maxdays']}gg - ". count($feeData['loans'])." elementi)" ,
                "Total" => $feeData['total']);
        }

        return $result;

    }
}