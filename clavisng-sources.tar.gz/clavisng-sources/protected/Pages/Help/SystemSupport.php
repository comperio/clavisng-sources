<?php

class SystemSupport extends ClavisPage
{
    public $_module = 'HELP';
    /* @var Consortia */
    private $_consortia;

    public function onLoad($param)
    {
        parent::onLoad($param);

        $l = $this->getUser()->getActualLibrary();

        $this->_consortia = ($l instanceof Library)
            ? $l->getConsortia()
            : ConsortiaQuery::create()->findOne();

        if (!$this->getIsCallback() && !$this->getIsPostBack())
            $this->populate();
    }

    public function canEdit()
    {
        return $this->getUser()->getEditPermission($this->_consortia);
    }

    public function populate()
    {
        if ($this->_consortia instanceof Consortia) {
            $consortiaInfo = $this->_consortia->getInfo();
        } else {
            $consortiaInfo = '[' . Prado::localize('consortia non esistente') . ']';
        }

        $this->ViewInfo->setText($consortiaInfo);
        $this->EditInfo->setText($consortiaInfo);

        $this->AttachList->setObjectClass('Consortia');
        //	$this->AttachList->setObjectId($this->_consortia->getConsortiaId());
        $this->AttachList->setObjectId(0);

        if ($this->getMode() == 'Edit') {
            $this->AttachList->setReadOnly('false');
            $this->AttachList->populate();
            $this->EditInfoPanel->setVisible(true);
            $this->ViewInfoPanel->setVisible(false);
        } else {
            $this->AttachList->setReadOnly('true');
            $this->AttachList->populate();
            $this->EditInfoPanel->setVisible(false);
            $this->ViewInfoPanel->setVisible(true);
        }
    }

    public function getMode()
    {
        return $this->getViewState('Mode', 'View');
    }

    public function setMode($v)
    {
        $this->setViewState('Mode', TPropertyValue::ensureEnum($v, array('View', 'Edit')), 'View');
    }

    public function onEdit($sender, $param)
    {
        if ($this->canEdit())
            $this->setMode('Edit');

        $this->populate();
    }

    public function onCancel($sender, $param)
    {
        $this->setMode('View');

        $this->populate();
    }

    public function onSave($sender, $param)
    {
        try {
            if ($this->_consortia instanceof Consortia) {
                $info = $this->EditInfo->getText();

                //$this->_consortia->setInfo($info);
                foreach (ConsortiaQuery::create()->find() as $consortiaRow) {
                    $consortiaRow->setInfo($info);
                    $consortiaRow->save();

                    ChangelogPeer::logAction($this->_consortia,
                        ChangelogPeer::LOG_UPDATE,
                        $this->getUser(),
                        'Aggiornamento InfoPage per il consorzio ' . $consortiaRow->getConsortiaId());
                }

                //$this->_consortia->save();

                $this->writeMessage(Prado::localize('Informazioni correttamente salvate'),
                    ClavisMessage::CONFIRM);
            } else {
                $this->writeMessage(Prado::localize('Il consortia non esiste'),
                    ClavisMessage::ERROR);
            }
        } catch (Exception $e) {
            $this->writeMessage(Prado::localize('Errore nel salvataggio delle informazioni: ') . $e,
                ClavisMessage::ERROR);
        }

        $this->setMode('View');

        $this->populate();
    }


}