<?php

/**
 * NotificationInsertPage Page class Module Communication
 *
 * @author Ciro Mattia gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2008 Comperiow
 */

class NotificationInsertPage extends ClavisPage {

	/**
	 * Name of the module where we are.
	 *
	 * @var string
	 */
	public $_module = 'COMMUNICATION';

	/** @var Notification */
	private $_notification = null;

	public function onInit($param)
	{
		parent::onInit($param);

		if (!$this->getIsPostBack())
		{
			$this->getSession()->add('object_id', null);
		    $id = TPropertyValue::ensureInteger($this->getRequest()->itemAt('id'));
			if ($id > 0) {
				$notification = NotificationPeer::retrieveByPK($id);
				if (is_null($notification) && !($notification instanceof Notification))
				{
					$this->writeMessage(Prado::localize('La notifica n. {nid} non esiste',
						array('nid' => $id)),ClavisMessage::ERROR);
					$this->gotoPage('Communication.NotificationListPage');
				}
				$this->setNotification($notification);
			} else {
				$notification = new Notification();
				$this->setNotification($notification);
			}
		}
	}

	/**
	 * On the onLoad we populate the textbox "Title" if the proper
	 * value is passed as a get parameter, and we must initialize
	 * EACH instance of repeatable list in the page (by $this->addItem).
	 *
	 * @param unknown_type $param
	 */
	public function onLoad($param)
	{
		parent::onLoad($param);
		/* caricamento dei dati nella form */
		if(!$this->getIsPostBack() )
		{
			$this->populateForm();
			$this->dataBind();
		}
		$this->UpdateData->setObject($this->getNotification());
	}


	public function notificationSave($sender, $param) {

		$this->_notification->setNotificationState(NotificationPeer::STATUS_PENDING);
		$this->_notification->setNotificationChannel($this->NotificationChannel->getSelectedValue());

		$this->_notification->setMessage($this->Message->getText());
		$this->_notification->setObjectClass($this->ObjectType->getSelectedValue());
		$objectId = $this->getSession()->itemAt('object_id');
		if (!is_null($objectId)) {
			$this->_notification->setObjectId($objectId);
		} else {
			$this->writeMessage(Prado::localize('Selezionare un destinatario'),ClavisMessage::ERROR);
			return;
		}

		$this->_notification->save();

		if ($this->_notification->isNew()) {
			ChangelogPeer::logAction($this->_notification, ChangelogPeer::LOG_CREATE, $this->getUser());
			$this->writeMessage(Prado::localize('Notifica inserita con successo'), ClavisMessage::INFO);
		} else {
			ChangelogPeer::logAction($this->_notification, ChangelogPeer::LOG_UPDATE, $this->getUser());
			$this->writeMessage(Prado::localize('Notifica modificata con successo'), ClavisMessage::INFO);
		}
		$this->setNotification($this->_notification);
		$this->gotoPage('Communication.NotificationListPage');
	}

	public function populateForm() {
		if ($this->_notification === null)
			return;

		$this->NotificationState->setText(LookupValuePeer::getLookupValue('NOTIFICATIONSTATE',
			$this->_notification->getNotificationState()));
		$viewDate = Clavis::dateFormat($this->_notification->getAcknowledgeDate('U'));
		if ($viewDate != '')
			$this->ViewDate->setText($viewDate);
		else
			$this->ViewDate->setText(Prado::localize("Non ancora presa in visione"));

		$this->NotificationChannel->setSelectedValue($this->_notification->getNotificationChannel());

		$objectClass = $this->_notification->getObjectClass();
		$this->ObjectType->setSelectedValue($objectClass);

		$objectId = $this->_notification->getObjectId();

		if(!is_null($objectId)) {
			switch($objectClass) {
				case 'patron':
					$patron = PatronPeer::retrieveByPK($objectId);
					if($patron) {
						$this->ObjectLabel->setText($patron->getCompleteName()." (".$patron->getBarcode().")");
						$this->getSession()->add("object_id", $patron->getPatronId());
					}
					break;

				case 'librarian':
					$librarian = LibrarianPeer::retrieveByPK($objectId);
					if($librarian) {
						$this->ObjectLabel->setText($librarian->getCompleteName()." (".$librarian->getLibrarianId().")");
						$this->getSession()->add("object_id", $librarian->getLibrarianId());
					}
					break;

				case 'library':
					$library = LibraryPeer::retrieveByPK($objectId);
					if($library) {
						$this->ObjectLabel->setText($library->getLabel()." (".$library->getLibraryId().")");
						$this->getSession()->add("object_id", $library->getLibraryId());
					}

					break;

				case 'supplier':
					$supplier = SupplierPeer::retrieveByPK($objectId);
					if($supplier) {
						$this->ObjectLabel->setText($supplier->getSupplierName()." (".$supplier->getSupplierId().")");
						$this->getSession()->add("object_id", $supplier->getSupplierId());
					}

					break;
			}
		}
		//1a versione (da sostituire)
		//$this->ObjectId->setText($this->_notification->getObjectId());

		$this->Message->setText($this->_notification->getMessage());

		$this->UpdateData->setObject($this->_notification);

	}


	/**
	 * setter
	 *
	 * @param Notification $notification
	 */
	public function setNotification($notification) {
		$this->_notification = $notification;
		$this->setViewState("notification",$notification,null);
	}


	/**
	 * getter
	 *
	 * @return Notification
	 *
	 */
	public function getNotification() {
		if(is_null($this->_notification)) {
			$this->_notification = $this->getViewState("notification",null);
		}
		return $this->_notification;
	}


	public function globalEditCancel()
	{

	}

	public function OnObjectChangeType($sender, $param)
	{
		if($this->getIsPostBack())
			$this->ObjectLabel->setText("");

	}

	public function suggestObject($sender, $param)
	{
		$token = $param->getCallBackParameter(); //the partial word to match

		$ObjectType = $this->ObjectType->getSelectedValue();

		switch($ObjectType) {
			case 'patron':
				$sender->setDataSource($this->getPatronSuggestionsFor($token)); //set suggestions
				$sender->dataBind();

				break;

			case 'librarian':
				$sender->setDataSource($this->getLibrarianSuggestionsFor($token)); //set suggestions
				$sender->dataBind();

				break;

			case 'library':
				$sender->setDataSource($this->getLibrarySuggestionsFor($token)); //set suggestions
				$sender->dataBind();

				break;

			case 'supplier':
				$sender->setDataSource($this->getSupplierSuggestionsFor($token)); //set suggestions
				$sender->dataBind();

				break;

		}
		//$sender->render($param->getNewWriter());
	}

	private function getPatronSuggestionsFor($token)
	{
		$list = array();

		$barcodeList = $this->searchBarcode($token);
		if(count($barcodeList) > 0) return $barcodeList;

		$tokens = explode(", ",$token);
		$tokens[0] = (isset($tokens[0]))?$tokens[0]:"";
		$tokens[1] = (isset($tokens[1]))?$tokens[1]:"";

		$c = new Criteria();
		$c->addAscendingOrderByColumn(PatronPeer::LASTNAME );
		$c->addAscendingOrderByColumn(PatronPeer::NAME );

		if($tokens[0] != "")
		$c->add(PatronPeer::LASTNAME , $tokens[0]."%", Criteria::LIKE );

		if($tokens[1] != "")
		$c->add(PatronPeer::NAME  , $tokens[1]."%", Criteria::LIKE );

		$c->setLimit(10);
		$patrons = PatronPeer::doSelect($c);

		for($i=0; $i < count($patrons); $i++) {
			$list[] = $patrons[$i]->getLastname() .' '. $patrons[$i]->getName() . " (" . $patrons[$i]->getBarcode() . ")";
		}
		return $list;
	}

	private function getLibrarianSuggestionsFor($token)
	{
		$list = array();

		$tokens = explode(", ",$token);
		$tokens[0] = (isset($tokens[0]))?$tokens[0]:"";
		$tokens[1] = (isset($tokens[1]))?$tokens[1]:"";

		$c = new Criteria();
		$c->addAscendingOrderByColumn(LibrarianPeer::LASTNAME  );
		$c->addAscendingOrderByColumn(LibrarianPeer::NAME );

		if($tokens[0] != "")
		$c->add(LibrarianPeer::LASTNAME , $tokens[0]."%", Criteria::LIKE );

		if($tokens[1] != "")
		$c->add(LibrarianPeer::NAME  , $tokens[1]."%", Criteria::LIKE );

		$c->setLimit(10);
		$librarian = LibrarianPeer::doSelect($c);

		for($i=0; $i < count($librarian); $i++) {
			$list[] = $librarian[$i]->getLastname() .' '. $librarian[$i]->getName() ." (". $librarian[$i]->getLibrarianId() . ")";
		}
		return $list;
	}

	private function getLibrarySuggestionsFor($token)
	{
		$list = array();

		$tokens = explode(", ",$token);
		$tokens[0] = (isset($tokens[0]))?$tokens[0]:"";
		$tokens[1] = (isset($tokens[1]))?$tokens[1]:"";

		$c = new Criteria();
		$c->addAscendingOrderByColumn(LibraryPeer::LABEL);

		if($tokens[0] != "")
		$c->add(LibraryPeer::LABEL , $tokens[0]."%", Criteria::LIKE );

		$c->setLimit(10);
		$libraries = LibraryPeer::doSelect($c);

		for($i=0; $i < count($libraries); $i++) {
			//$list[] = $libraries[$i]->getLabel();
			$list[] =  $libraries[$i]->getLabel()." (".  $libraries[$i]->getLibraryId() . ")";

		}
		return $list;
	}

	private function getSupplierSuggestionsFor($token)
	{

	}


	/**
	 * Ajax callback which makes some action after the string in the
	 * autocomplete textbox has been choosen.
	 * In particular, it populates some labels with object's data.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function suggestObjectCallBack($sender, $param)
	{

	}

}
