<?php

/**
 * NotificationInsertPopup Page class Module Communication
 *
 * @author Ciro Mattia gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2010 Comperio srl
 */

class NotificationInsertPopup extends ClavisPage {

	public $_module = 'COMMUNICATION';

	public function onInit($param)
	{
		parent::onInit($param);

		if (!$this->getIsPostBack())
		{
			$class = $this->getRequest()->itemAt('objectType');
			switch ($class) {
				case 'Patron':
					$d = PatronPeer::retrieveByPK($this->getRequest()->itemAt('param'));
					break;
				case 'Library':
					$d = LibraryPeer::retrieveByPK($this->getRequest()->itemAt('param'));
					break;
				default:
					break;
			}
			if ($d)
				$this->InsertNotification->setDestination($d);
		}
	}

	public function onSend($sender,$param) {
		$this->InsertNotification->sendNotification();

		// aggiorno la lista delle notifiche all'interno della pagina del patron.
        $this->getApplication()->getSession()->add('UpdatePatronNotificationsList', true);
		$this->getPage()->getClientScript()->registerEndScript(__CLASS__.'_js',"onReturn('','',true);");
	}
}
