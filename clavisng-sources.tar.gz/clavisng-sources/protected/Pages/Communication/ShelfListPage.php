<?php
/**
 * ShelfListPage class file
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 ePortal Technologies
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.8.6
 * @package Pages.Catalog
 */

/**
 * ShelfListPage Page
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.8.6
 * @package Pages.Catalog
 * @since 2.0
 */

class ShelfListPage extends ClavisPage 
{
	public $_module = "COMMUNICATION";

	public function onLoad($param)
	{
		if (!$this->getIsPostBack() 
				&& !$this->getIsCallback())
			$this->setFocus($this->ShelfList->NameSearch->getClientID());

		parent::onLoad($param);
	}

	/**
	 * It deletes permanently a shelf.
	 * In cascade, all the shelfitems linked to this shelf, get
	 * deleted too.
	 *
	 * @param int $shelfId
	 */
	public function deleteShelf($shelfId = null)
	{
		$shelfId = (int) $shelfId;
		
		if ($shelfId > 0)
		{
			$shelf = ShelfQuery::create()->findPk($shelfId);
			
			if ($shelf instanceof Shelf)
			{
				$this->cleanMessageQueue();
				
				$name = $shelf->getShelfCompleteName();

				try
				{
					$deletedShelf = ShelfQuery::create()
										->filterByShelfId($shelfId)
										->delete();
					
					if ($deletedShelf > 0)
					{
						$this->getPage()->enqueueMessage(Prado::localize("Eliminato scaffale '{name}', id={id}.", 
																			array(	'name' => $name,
																					'id' => $shelfId )), 
															ClavisMessage::CONFIRM);

						ChangelogPeer::logAction(	"Shelf",
													ChangelogPeer::LOG_DELETE, 
													$this->getUser(), 
													'Scaffale cancellato, id = ' . $shelfId . ", nome = '" . $name . "'");				

						// dedicated shelf_items deletion

						$deletedShelfItem = ShelfItemQuery::create()
												->filterByShelfId($shelfId)
												->delete();
						
						if ($deletedShelfItem > 0)
						{
							$this->getPage()->enqueueMessage(Prado::localize("Eliminati {num} elementi dello scaffale.",
																				array('num' => $deletedShelfItem)),
																ClavisMessage::CONFIRM);
						}

						$this->globalRefresh();
					}
				}
				catch (Exception $ex)
				{
					$this->getPage()->enqueueMessage(Prado::localize("Errore durante la cancellazione dello scaffale '{name}', id={id}", 
																		array(	'name' => $name,
																				'id' => $shelfId )), 
														ClavisMessage::ERROR);
				}
					
				$this->flushMessage();
			}
			else
			{	
				$this->getPage()->writeMessage(Prado::localize("Errore: lo scaffale con id: {id} non esiste",
															array('id' => $shelfId)), 
										ClavisMessage::ERROR);
			}
		}
		else
		{
			$this->getPage()->writeMessage(Prado::localize("Scaffale non esistente"),
												ClavisMessage::ERROR);
		}
	}

	/**
	 * It performs a refresh (populate) of all the components in this page.
	 *
	 */
	public function globalRefresh()
	{
		$this->ShelfList->globalRefresh();
	}

	/**
	 * It returns whether this page can generate the link menus, which are listed
	 * in standard popup's elements, in a component inside this page.
	 *
	 * @return boolean
	 */
	public function isPopup()
	{
		return false;
	}

	/**
	 * It returns whether this page can generate the unlink menu
	 * in a component inside this page.
	 *
	 * @return boolean
	 */
	public function isDelete()
	{
		return true;
	}

}