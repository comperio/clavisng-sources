<?php
/**
 * ShelfInsertPage class file
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 * For Commercial Licenses and support please contact Comperio.
 *
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 */

/**
 * ShelfInsertPage Class
 * This page is for being inside the popup which outputs
 * a list of shelves.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.7
 * @package Pages.Communication
 * @since 2.1
 */
class ShelfInsertPage extends ClavisPage
{
	/**
	 * Name of the module where we are.
	 *
	 * @var string
	 */
	public $_module = 'COMMUNICATION';

	/** @var Shelf */
	private $_shelf = null;

	public function onInit($param)
	{
		parent::onInit($param);

		$id = intval($this->getRequest()->itemAt('shelfId'));
		if ($id > 0) {
			$this->_shelf = ShelfPeer::retrieveByPK($id);
			if (!$this->_shelf instanceof Shelf) {
				$this->writeMessage(Prado::localize("Lo scaffale con id = {id} non esiste", array('id' => $id)),
					ClavisMessage::ERROR);
				$this->gotoPage('Communication.ShelfListPage');
			}
		} else {
			// create new shelf and set default values
			$this->_shelf = new Shelf();
			$this->_shelf->setLibrarianId($this->getUser()->getId());
			$this->_shelf->setLibraryId($this->getUser()->getActualLibraryId());
			$status = ClavisParamQuery::getParam('CLAVISPARAM','ShelfDefaultStatus');
			if (!$status)
				$status = ShelfPeer::VISIBILITY_LIBRARYOPS;
			$this->_shelf->setShelfStatus($status);
		}
		$this->setShelf($this->_shelf);
	}

	/**
	 * In the onLoad, the first time, we populate the fields
	 * and perform a databind.
	 * Then, everytime, we get the object shelf and proceed
	 * to inform all the eventual components, which will treat all
	 * the bindings of this shelf with other elements, about it.
	 *
	 * @param TEventParameter $param
	 */
	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getIsPostBack()) {
			$shelfStatus = LookupValuePeer::getLookupClassValues('SHELFSTATUS');
			if (!$this->getUser()->getIsAdmin() && array_key_exists(ShelfPeer::VISIBILITY_ADMINS, $shelfStatus))
				unset($shelfStatus[ShelfPeer::VISIBILITY_ADMINS]);
			$this->ShelfStatus->setDataSource($shelfStatus);
			$this->ShelfStatus->dataBind();
			$this->populate();
		}
		$this->getShelf();
	}

	/**
	 * Setter method of object shelf.
	 *
	 * @param Shelf $shelf
	 */
	public function setShelf($shelf)
	{
		$this->setViewState('shelf', $shelf, null);
	}

	/**
	 * Getter method of object shelf.
	 *
	 * @return Shelf
	 */
	public function getShelf()
	{
		if (!$this->_shelf instanceof Shelf)
			$this->_shelf = $this->getViewState('shelf', null);
		return $this->_shelf;
	}

	public function checkAuth($addedCheck = true, $force = null)
	{
		$allow = false;
		if ($this->_shelf instanceof Shelf)
			$allow = $this->_shelf->isEditable($this->getUser());
		parent::checkAuth($allow);
	}

	private function populateLibraryList() {
		$libs = $this->getUser()->getLibraryIds();
		$libs[] = intval($this->_shelf->getLibraryId());
		$libraries = LibraryQuery::create()
			->orderByLabel()
			->findByLibraryId($libs);
		$this->LibraryList->setDataSource($libraries);
		$this->LibraryList->dataBind();
	}

	public function populate()
	{
		$this->populateLibraryList();
		$this->LibraryList->setSelectedValue($this->_shelf->getLibraryId());
		$this->ShelfStatus->setSelectedValue($this->_shelf->getShelfStatus());
		if (!$this->_shelf->isNew()) {
			$this->UpdateData->setObject($this->_shelf);
			$this->ShelfName->setText($this->_shelf->getShelfName());
			$this->ShelfDescription->setText($this->_shelf->getShelfDescription());
		}
	}

	/**
	 * Saves onto the database the object shelf.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onSave($sender, $param)
	{
		$this->shelfSave();
		$this->gotoPage('Communication.ShelfViewPage', array('id' => $this->_shelf->getShelfId()));
	}

	/**
	 * Saves onto the database the object shelf.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onApply($sender, $param)
	{
		$this->shelfSave();
	}

	private function shelfSave()
	{
		try {
			$wasNew = $this->_shelf->isNew();

			$shelfName = strip_tags($this->ShelfName->getText());
			$shelfDescription = strip_tags($this->ShelfDescription->getText());
			$shelfStatus = $this->ShelfStatus->getSelectedValue();

			$this->_shelf->setShelfName($shelfName);
			$this->_shelf->setShelfDescription($shelfDescription);
			$this->_shelf->setShelfStatus($shelfStatus);

			$this->_shelf->save();
			$this->setShelf($this->_shelf);
			if ($wasNew) {
				ChangelogPeer::logAction($this->_shelf, ChangelogPeer::LOG_CREATE, $this->getUser(), 'Nuovo scaffale creato');
				$this->getPage()->writeMessage(Prado::localize("Creato scaffale '{name}' ['{description}']",
					array('name' => $this->_shelf->getShelfName(), 'description' => $this->_shelf->getShelfDescription())), ClavisMessage::INFO);
			} else {
				ChangelogPeer::logAction($this->_shelf, ChangelogPeer::LOG_UPDATE, $this->getUser(), 'Scaffale modificato');
				$this->getPage()->writeMessage(Prado::localize("Scaffale '{name}' ['{description}'] modificato correttamente",
					array('name' => $this->_shelf->getShelfName(), 'description' => $this->_shelf->getShelfDescription())), ClavisMessage::INFO);
			}
		} catch (Exception $exception) {
			switch ($exception->getCode()) {
				case ShelfPeer::SHELF_NAMEEXISTS:
					$this->writeMessage(Prado::localize("Scaffale '{name}' non creato perché esiste già uno scaffale con questo nome nella biblioteca attuale.", array('name' => $this->ShelfName->getText())), ClavisMessage::ERROR);
					$this->ShelfName->setText('');
					break;
				case ShelfPeer::ERROR:
					$this->writeMessage(Prado::localize('Scaffale non creato: {errormsg}', array('errormsg' => $exception->getMessage())), ClavisMessage::ERROR);
					break;
			}
		}
	}

	/**
	 * Exits the creation of a new shelf, without doing anything.
	 * NB: in case the shelf is new (not on database), we return
	 * to the shelves list.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onCancel($sender, $param)
	{
		if ($this->_shelf->isNew())
			$this->gotoPage("Communication.ShelfListPage");
		else
			$this->gotoPage("Communication.ShelfViewPage", array("id" => $this->_shelf->getShelfId()));
	}
}
