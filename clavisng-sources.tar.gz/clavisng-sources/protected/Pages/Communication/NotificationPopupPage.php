<?php
/**
 * NotificationPopupPage Page class Module Communication
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2017 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info
 * @comperio.it.
 * Website: https://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Max Pigozzi
 * @author Marco Brancalion <marco@comperio.it>
 * @link https://www.comperio.it/
 * @copyright Copyright &copy; 2006-2017 Comperio srl
 * @license https://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.8.5
 * @package Pages.Communication
 */

/**
 * NotificationPopupPage Page class Module Communication
 *
 * It displays the notifications' list.
 *
 * @author Max Pigozzi
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.8.9
 * @package Pages.Circulation
 * @since 2.0
 */

class NotificationPopupPage extends ClavisPagePopup
{
	public $_module = 'COMMUNICATION';

	/* @var Notification */
	private $_notification = null;

	public function onInit($param)
	{
		parent::onInit($param);
	
		$notification_id = intval($this->getRequest()->itemAt('param'));
		$notification = NotificationQuery::create()->findPk($notification_id);

		if ($notification instanceof Notification)
			$this->setNotification($notification);
	}

	public function onLoad($param)
	{
		parent::onLoad($param);

		// first page cycle
		if (!$this->getIsPostBack()
				&& !$this->getIsCallback())
		{
			$this->populateForm();
			$this->dataBind();
		}
		
		$this->UpdateData->setObject($this->getNotification());
	}

	public function populateForm() 
	{
		/** @var $this->_notification Notification */ 
		if ($this->_notification === null)
			return;

		$this->NotificationState->setText(LookupValuePeer::getLookupValue(	'NOTIFICATIONSTATE',
																			$this->_notification->getNotificationState()));
		
		
		$notificationClassRaw = $this->_notification->getNotificationClass();
			
		if (is_null($notificationClassRaw))
		{
			$notificationClass = Prado::localize("nessuna classe");
		}
		else
		{
			$notificationClass = LookupValuePeer::getLookupValue('NOTIFICATIONCLASS', $notificationClassRaw);
		}

		$this->NotificationClass->setText($notificationClass);

		$this->NotificationChannel->setText(LookupValuePeer::getLookupValue(	'NOTIFICATIONCHANNEL',
																				$this->_notification->getNotificationChannel()));
		
		$this->ObjectClass->setText(LookupValuePeer::getLookupValue(	'OBJECTCLASS',
																		ucfirst($this->_notification->getObjectClass())));
		
		$this->DateCreated->setValue($this->_notification->getDateCreated('U'));
		$this->DeliveryDate->setValue($this->_notification->getDeliveryDate('U'));
		$this->AcknowledgeDate->setValue($this->_notification->getAcknowledgeDate('U'));
		$this->Message->setText($this->_notification->getMessage());
		
		$this->Notes->setText($this->_notification->getNotes());

		$this->SetSentButton->setEnabled(in_array(	$this->_notification->getNotificationState(),
													array(	NotificationPeer::STATUS_PENDING, 
															NotificationPeer::STATUS_UNKNOWN )));
		
		$this->SetDeliveredButton->setEnabled(in_array(	$this->_notification->getNotificationState(),
														array(	NotificationPeer::STATUS_PENDING,
																NotificationPeer::STATUS_SENT,
																NotificationPeer::STATUS_UNKNOWN )));

		$objectId = $this->_notification->getObjectId();

		if (!is_null($objectId) 
				&& (!$objectId == 0))
		{
			switch (strtolower($this->_notification->getObjectClass())) 
			{
				case 'library':
					$library = LibraryQuery::create()->findPk($objectId);

					if ($library instanceof Library)
					{
						$label = $library->getLabel();
						//$url = 'index.php?page=Library.LibraryViewPage&id='.$objectId;
						$url = LibraryPeer::getNavigateUrl($objectId);
					}
					else
					{
						$label = "(id =" . $objectId . ")";
						$url = '';
					}
					
					break;
					
				case 'librarian':
					$librarian = LibrarianQuery::create()->findPk($objectId);
					
					if ($librarian instanceof Librarian)
					{
						$label = $librarian->getCompleteName();
						$url = LibrarianPeer::getNavigateUrl($objectId);
					} 
					else
					{
						$label = "(id =" . $objectId . ")";
						$url = '';
					}
					
					break;
					
				case 'patron':
					$patron = PatronQuery::create()->findPk($objectId);
					
					if ($patron instanceof Patron)
					{
						$label = $patron->getCompleteName();
						$url = PatronPeer::getNavigateUrl($objectId);
					} 
					else
					{
						$label = "(id =" . $objectId . ")";
						$url = '';
					}
					
					break;
					
				case 'supplier': //fornitore
					$supplier = SupplierQuery::create()->findPk($objectId);
					
					if ($supplier instanceof Supplier)
					{
						$label = $supplier->getSupplierName();
						$url = SupplierPeer::getNavigateUrl($objectId);
					}
					else
					{
						$label = "(id =" . $objectId . ")";
						$url = '';
					}
					
					break;
					
				default:
					$label = Prado::localize("ERRORE");
					$url = '#';
					break;
			}
			
			$this->Receiver->setText($label);
			$this->Receiver->setNavigateUrl($url);
		}
	}

	public function setNotification($notification)
	{
		$this->_notification = $notification;
		$this->setViewState("notification", $notification, null);
	}

	public function getNotification()
	{
		if (is_null($this->_notification))
			$this->_notification = $this->getViewState("notification", null);

		return $this->_notification;
	}

	public function globalEditCancel()
	{

	}

	public function onSetSent($sender, $param)
	{
		$this->_notification->setNotificationState(NotificationPeer::STATUS_SENT);
		$this->_notification->setDeliveryDate(time());
		$this->_notification->save();
		
		$this->populateForm();
	}

	public function onSetDelivered($sender, $param)
	{
		$this->_notification->setNotificationState(NotificationPeer::STATUS_DELIVERED);
		$this->_notification->setAcknowledgeDate(time());
		$this->_notification->save();
		
		$this->populateForm();
	}

}