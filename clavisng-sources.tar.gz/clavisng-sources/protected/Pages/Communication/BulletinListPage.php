<?php

/**
 *
 * @author Marco Brancalion <mbrancalion@e-portaltech.it>
 * @link http://www.e-portaltech.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @license http://www.e-portaltech.it/license/
 */

class BulletinListPage extends ClavisPage
{
	public $_module = "COMMUNICATION";

	public function onLoad($param)
	{
		$clavisLibrarian = $this->getUser();
		$canInsert = $clavisLibrarian->checkAllowedPage('Communication.BulletinInsertPage');

		$this->InsertButton->setEnabled($canInsert);
		$this->EraseButton->setEnabled($canInsert);

		parent::onLoad($param);
	}

	public function onInsertNewBulletin($sender, $param)
	{
		$this->gotoPage("Communication.BulletinInsertPage");
	}

	public function onExpireOldBulletins()
	{
		$result = BulletinPeer::expireOldBulletins();
			
		$this->writeMessage($result . " " . Prado::localize('messaggi interni obsoleti cancellati'),
								$result > 0
									? ClavisMessage::CONFIRM
									: ClavisMessage::ERROR);

		if ($result > 0)
			$this->globalRefresh();
	}

	public function globalRefresh()
	{
		$this->BulletinList->populate();
	}

	public function getPopupFlag()
	{
		return false;
	}

	public function getUnlinkFlag()
	{
		return false;
	}
}