<?php
/**
 * ShelfViewPage class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Pages.Communication
 */
Prado::using('Application.Common.Plugins.*');

/**
 * ShelfViewPage Class
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.7
 * @package Pages.Communication
 * @since 2.1
 */
class ShelfViewPage extends ClavisPage
{
	public $_module = 'COMMUNICATION';
	private $_shelf = null;

	public function onInit($param)
	{
		parent::onInit($param);

		if (!$this->getIsPostBack() && !$this->getIsCallback())
		{
			$this->resetPlugin();
			$excludePlugins = array();

			$shelf = null;
			$id = intval($this->getRequest()->itemAt('id'));
			if ($id > 0)
			{
				$shelf = ShelfQuery::create()->findPk($id);

				if (!($shelf instanceof Shelf))
				{
					$this->writeMessage(Prado::localize("Lo scaffale n.{id} non esiste.", 
															array('id' => $id)), 
											ClavisMessage::ERROR);
					
					$this->gotoPage('Communication.ShelfListPage');
				}
			}

			if (is_null($shelf))
				$shelf = new Shelf();

			$this->setShelf($shelf);

			$plugins = array_intersect_key(	$this->getUser()->getAuthPages(), 
											array_flip(ShelfPeer::getPlugins(	$shelf->isEditable($this->getUser()) 
																							? ShelfPeer::EDITTYPE_EDIT
																							: ShelfPeer::EDITTYPE_NONEDIT,
																				$shelf->getShelfItemtype())));		// type choice

			$this->PluginOperation->setDataSource(LookupValuePeer::getLookupClassValues(	'SHELFPLUGIN', 
																							true, 
																							Prado::localize('seleziona operazione...'),		// first row
																							array_keys($plugins),
																							true));
			
			$this->PluginOperation->dataBind();
		}

		if (($operation = $this->getPlugin()) != null)
		{
			$component = Prado::createComponent($operation);
			$controls = $this->PluginPlaceHolder->getControls();
			$controls->add($component);
			$this->PluginChoicePanel->setCssClass('panel_off');

			////$this->setFocus("FocusAnchor");
		}
		else
		{
			$this->PluginChoicePanel->setCssClass('panel_on');
		}
	}

	public function onLoad($param)
	{
		parent::onLoad($param);

		$shelf = $this->getShelf();

		if (!$this->getIsPostBack() 
				&& !$this->getIsCallback())
		{
			$this->ShelfView->setShelf($shelf);
			$this->ShelfItemList->setShelf($shelf);
			$this->ShelfItemList->setUpdateEmptyFlagFunctionName('updateEmptyFlag');
			$this->UpdateData->setObject($shelf);

			$this->ShelfItemList->resetChecked();
		}

		$this->updateEmptyFlag();

		$canEdit = $this->getUser()->getEditPermission($shelf) && $shelf->isEditable($this->getUser());
		$this->Modify->setEnabled($canEdit);

		// ensure shelf item type is consistent
		ShelfPeer::checkShelfItemTypes($shelf, true);
	}

	public function checkAuth($addedCheck = true, $force = null)
	{
		$allow = true;
		$shelf = $this->getShelf();

		if ($shelf instanceof Shelf)
			$allow = $shelf->isVisible($this->getUser());

		parent::checkAuth($allow);
	}

	public function updateEmptyFlag()
	{
		$this->EmptyFlag->setText($this->countCheckedItems() == 0 ? '1' : '0');
	}

	public function shelfModify($sender, $param)
	{
		$this->gotoPage('Communication.ShelfInsertPage', array('shelfId' => $this->_shelf->getShelfId()));
	}

	public function setShelf($shelf)
	{
		$this->_shelf = $shelf;
		$this->setViewState("shelf", $shelf, null);
	}

	public function getShelf()
	{
		if (is_null($this->_shelf))
			$this->_shelf = $this->getViewState("shelf", null);

		return $this->_shelf;
	}

	/**
	 * This method unlinks a shelf item from a library.
	 *
	 * The function "forceLastShelfItemCriteria, in the object,
	 * is needed to force the recalculation of the shelf
	 * links in case one row in that table is removed.
	 *
	 * @param int $objectId
	 * @param string $objectClass
	 */
	public function unLinkShelfItem($objectId, $objectClass)
	{
		if (($objectClass !== '') && ($objectId != 0))
		{
			$shelfId = $this->_shelf->getShelfId();

			$criteria = new Criteria();
			$criteria->add(ShelfItemPeer::SHELF_ID, $shelfId);
			$criteria->add(ShelfItemPeer::OBJECT_ID, $objectId);
			$criteria->add(ShelfItemPeer::OBJECT_CLASS, $objectClass);
			$result = ShelfItemPeer::doDelete($criteria);

			if ($result > 0)
			{
				if (($objectClass == ShelfPeer::TYPE_MANIFESTATION) || ($objectClass == ShelfPeer::TYPE_MANIFESTATION_BUY))
					ManifestationPeer::invalidateCache($objectId);
			}

			$this->_shelf->forceReloadShelf();
			$this->setShelf($this->_shelf);
			$this->globalRefresh();
		}
	}

	/**
	 * It is called by one of the inner components, and
	 * performs the population (refresh) of all the components
	 * (the calling is included).
	 *
	 */
	public function globalRefresh($param = null)
	{
		$this->resetPlugin();
		$this->ShelfView->populate();
		$this->ShelfItemList->resetDataSource();
		$this->shelfListRefresh($param);
	}

	public function shelfListRefresh($param = null)
	{
		$this->ShelfItemList->populate();
		$this->doRedrawShelfItemListPanel($param);
	}

	private function doRedrawShelfItemListPanel($param = null)
	{
		if ($this->getPage()->getIsCallback())
		{
			if (!is_null($param))
			{
				$writer = $param->getNewWriter();
			}
			else
			{
				$writer = $this->getPage()->createWriter();
			}
			
			$this->ShelfItemListPanel->render($writer);
		}		
	}
	
	/**
	 * It's called by one of the inner componentes, and
	 * performs the "cancel" (return to non-edit status)
	 * of all the components (the calling is included).
	 *
	 * @param TControl $component
	 */
	public function globalCancel($component)
	{
		if ($component !== $this->ShelfView)
			$this->ShelfView->onCancel(null, null);

		if ($component !== $this->ShelfItemList)
			$this->ShelfItemList->onCancel(null, null);
	}

	/**
	 * Whether this page can have components where the menus
	 * inside can generate unlink menus.
	 *
	 * @return boolean
	 */
	public function isUnlink()
	{
		return true;
	}

	/**
	 * Whether this page can have components where the
	 * menus inside can have the standard links that
	 * popups have.
	 *
	 * @return boolean
	 */
	public function IsPopup()
	{
		return false;
	}

	public function removeItems($param)
	{
		$exitValue = $this->ShelfItemList->removeItems($param);
		
		if ($exitValue > 0)
			$this->doRedrawShelfItemListPanel();
		
		return $exitValue;
	}

	public function moveItems($param1, $param2, $param3)
	{
		$exitValue = $this->ShelfItemList->moveItems($param1, $param2, $param3);
		
		if ($exitValue > 0)
			$this->doRedrawShelfItemListPanel();
		
		return $exitValue;
	}
	
	public function getCheckedItems($force = false)
	{
		$dataSource = $this->ShelfItemList->getCheckedItems($force);

		if (is_null($dataSource))
			$dataSource = array();

		return $dataSource;
	}

	public function countCheckedItems($force = false)
	{
		$count = $this->ShelfItemList->countCheckedItems($force);

		if (is_null($count))
			$count = 0;

		return $count;
	}

	public function getCheckedItemsIds($force = false)
	{
		$dataSource = $this->ShelfItemList->getCheckedItemsIds($force);

		if (is_null($dataSource))
			$dataSource = array();

		return $dataSource;
	}

	public function getCheckedObjectsIds($force = false)
	{
		$dataSource = $this->ShelfItemList->getCheckedObjectsIds($force);

		if (is_null($dataSource))
			$dataSource = array();

		return $dataSource;
	}

	public function onConfirmSelection($sender, $param)
	{
		$selectionText = ($sender->getID() == 'SelectionYes' ? 1 : 0);

		$this->SetCheckFlag->setText($selectionText);
		$this->onLoadPlugin($sender, $param);
	}

	public function onLoadPlugin($sender, $param)
	{
		$operation = $this->PluginOperation->getSelectedValue();

		/* @var $component TControl */
		if (($operation != '') && ($operation != '0'))
		{
			$component = Prado::createComponent($operation);

			/**
			 * Checking is some shelfitem were selected, because if there is none
			 * they get all selected.
			 */
			$isDataSourceNeeded = $component->isDataSourceNeeded();

			if ($isDataSourceNeeded)
			{
				if ($this->countCheckedItems() < 1)
					$this->ShelfItemList->setMasterChecked(true);

				$component->setRemoveItemsFunctionName('removeItems');
				$component->setMoveItemsFunctionName('moveItems');
				$component->setGetCheckedItemsFunctionName('getCheckedItems');
				$component->setCountCheckedItemsFunctionName('countCheckedItems');
				$component->setGetCheckedItemsIdsFunctionName('getCheckedItemsIds');
				$component->setGetCheckedObjectsIdsFunctionName('getCheckedObjectsIds');
			}

			$component->setShelfId($this->getShelf()->getShelfId());

			$this->setPlugin($operation);

			$controls = $this->PluginPlaceHolder->getControls();
			$controls->add($component);

			$this->PluginPlaceHolder->dataBind();
			$this->PluginChoicePanel->setCssClass('panel_off');

			$this->getPage()->setFocus("FocusAnchor");
		}
	}

	public function setPlugin($operation)
	{
		$this->getApplication()->getSession()->add("plugin", $operation);
	}

	public function getPlugin()
	{
		$operation = $this->getApplication()->getSession()->itemAt("plugin");

		if (!is_null($operation))
		{
			return $operation;
		}
		else
		{
			return null;
		}
	}

	public function resetPlugin()
	{
		$this->setPlugin(null);
	}

	public function onPluginSelected($sender, $param)
	{
		$this->ExpandPluginButton->setVisible($sender->isSelected());
		$this->PluginChoicePanel->render($param->getNewWriter());
	}
	
}