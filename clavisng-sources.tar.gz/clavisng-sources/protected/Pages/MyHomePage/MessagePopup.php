<?php
/**
 * MessagePopup class
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 */

/**
 * MessagePopup Class
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.7
 * @package Popups.Core
 * @since 2.3
 */

class MessagePopup extends ClavisPagePopup
{
	public $_module = 'MYHOME';
	private $_checked;
	private $_datasource = null;
	private $_checkedSessionName;
	private $_datasourceSessionName;

	private function initVars()
	{
		$uniqueId = $this->getUniqueID();
		$this->_checkedSessionName = "CheckedSessionName" . $uniqueId;
		$this->_datasourceSessionName = "DatasourceSessionName" . $uniqueId;
	}

	public function onInit($param)
	{
		parent::onInit($param);
		$this->initVars();
	}

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallBack())
		{
			$this->reset();
			$this->resetPagination();
		}
	}

	public function resetPagination()
	{
		$this->Grid->setCurrentPage(0);
	}

	public function resetChecked($state = false)
	{
		$this->setChecked(array('all' => $state));
	}

	public function setChecked($checked = null)
	{
		$this->_checked = $checked;
		$this->getApplication()->getSession()->add($this->_checkedSessionName, $checked);
	}

	public function getChecked()
	{
		$this->_checked = $this->getApplication()->getSession()->itemAt($this->_checkedSessionName);
		return $this->_checked;
	}

	public function resetDatasource($datasource = array())
	{
		$this->setDatasource($datasource);
	}

	public function setDatasource($datasource = array())
	{
		$this->_datasource = $datasource;
		$this->getApplication()->getSession()->add($this->_datasourceSessionName, $datasource);
	}

	public function getDatasource()
	{
		$this->_datasource = $this->getApplication()->getSession()->itemAt($this->_datasourceSessionName);
		return $this->_datasource;
	}

	public function globalRefresh()
	{
		$this->resetPagination();
		$this->populate();
	}

	public function populate()
	{
		$currentIndexPage = $this->Grid->getCurrentPage();
		$pageSize = $this->Grid->getPageSize();
		$checkedList = $this->getChecked();
		$masterCheck = $checkedList['all'];

		$messagesDatasource = ClavisMessage::getMessagesDatasource();
		$recCount = count($messagesDatasource);
		$this->Grid->setVirtualItemCount($recCount);
		$this->FoundNumber->setText($recCount);

		if (!is_null($pageSize) && ($pageSize > 0) && !is_null($currentIndexPage))
			$messagesDatasource = array_slice($messagesDatasource, $pageSize * $currentIndexPage, $pageSize);

		$messagesReformatted = array();
		foreach ($messagesDatasource as $messagesRow)
		{
			$id = $messagesRow['time'];
			if (array_key_exists($id, $checkedList))
				$checked = $checkedList[$id];
			else
			{
				$checked = false;
			}
			if ($masterCheck)
				$checked = !$checked;

			$messagesReformatted[] = array(	'checked' => $checked,
											'longtext' => $messagesRow['longtext'],
											'time' => Clavis::dateFormat($messagesRow['time'],'shortdate shorttime'),
											'type' => $messagesRow['type'],
											'typeString' => Prado::localize(ClavisMessage::getTypeString($messagesRow['type'])));
		}

		$this->setDatasource($messagesDatasource);
		$this->Grid->setDataSource($messagesReformatted);
		$this->Grid->dataBind();

		if ($this->getPage()->getIsCallBack())
			$this->GridPanel->render($this->createWriter());
	}

	public function reset()
	{
		$this->resetChecked();
		$this->_datasource = array();
		$this->resetDatasource();
		$this->populate();
	}

	public function getPopupFlag()
	{
		return $this->getPage()->isPopup();
	}

	public function isUnlink()
	{
		return false;
	}

	public function onMasterChecked($sender, $param)
	{
		$newStatus = $sender->getChecked();
		$this->resetChecked($newStatus);

		$gridItems = $this->Grid->getItems();
		foreach($gridItems as $item)
			$item->CheckColumn->Checked->setChecked($newStatus);
	}

	public function getMasterChecked()
	{
		$checked = $this->getChecked();
		return $checked['all'];
	}

	public function onFlipChecked($sender, $param)
	{
		$index = $sender->Parent->Parent->ItemIndex;
		$dataSource = $this->getDatasource();

		$newStatus = $sender->getChecked();
		$checked = $this->getChecked();

		$row = $dataSource[$index];
		$id = $row['time'];

		if ($newStatus != $checked['all'])
			$checked[$id] = true;
		else
			unset($checked[$id]);

		$this->setChecked($checked);
	}

	public function changePage($sender,$param)
	{
		$this->Grid->setCurrentPage($param->NewPageIndex);
		$this->populate();
	}

	public function getCheckedItems()
	{
		$checked = $this->getChecked();
		$masterChecked = $checked['all'];
		unset($checked['all']);
		$checkedIds = array_keys($checked);

		$ids = array();

		if (!$masterChecked)
			$ids = $checkedIds;

		else         // caso del mastercheck inverso
		{
			$messagesDatasource = ClavisMessage::getMessages();

			if (count($checked > 0))
				$messagesDatasource = array_diff_key($messagesDatasource, $checked);

			$ids = array_keys($messagesDatasource);
		}

		return $ids;
	}

	public function onDeleteAll($sender, $param)
	{
		ClavisMessage::cleanMessages();
		$this->getPage()->writeMessage(Prado::localize('Eseguita cancellazione di tutti i messaggi di sistema'),
										ClavisMessage::INFO);
		$this->globalRefresh();
	}

	public function onDeleteSelected($sender, $param)
	{
		$selectedTimes = $this->getCheckedItems();
		ClavisMessage::cleanMessages($selectedTimes);

		$this->getPage()->writeMessage(Prado::localize('Eseguita cancellazione dei messaggi di sistema'),
										ClavisMessage::INFO);
		$this->globalRefresh();
	}
	
	/* DA IMPLEMENTARE, funzione di esportazione di tutti i messaggi di sistema esistenti
	 * senza cancellarli, per esempio su file .csv, o tipo testo normale un po' formattato.
	public function onExportAll($sender, $param)
	{
		$this->getPage()->writeMessage(Prado::localize('Eseguita esportazione di tutti i messaggi di sistema'),
										ClavisMessage::INFO);
		$this->globalRefresh();
	}
	*/
}
