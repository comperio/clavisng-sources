<?php

/**
 * Catalog.IssueCalendarPopup Page class Module
 * @link      http://www.comperio.it/
 * @copyright Copyright &copy; 2019 Comperio srl
 * @version   2.9
 * @package   Popups.Catalog
 * @since     2.9
 */

class IssueCalendarPopup extends ClavisPagePopup
{
	public $_module = 'CATALOG';

	/**
	 * @param $param
	 * @throws \Exception
	 */
	public function onInit($param)
	{
		parent::onInit($param);

		if (!$this->getIsPostBack() && !$this->getIsCallback()) {
			$this->populate();
		}
	}

	/**
	 *
	 */
	public function globalRefresh()
	{

	}

	/**
	 * @return bool
	 */
	public function isUnlink()
	{
		return false;
	}

	/**
	 *
	 */
	public function populate()
	{
		$array = unserialize($this->getRequest()->itemAt('param'));
		$mID = $array['manifestationId'];

		list($year, $displayYear) = $this->IssuesCalendar->getMaxIssuesYear($mID);
		$clavisIssuesCalendarParams = $this->buildYCalendarParams($year, $displayYear);
		$clavisIssuesCalendarParams['model'] = $this->inferModelFromIssuesDescription($clavisIssuesCalendarParams['data']);
//		$clavisIssuesCalendarParams['alwaysRenumber'] = ($clavisIssuesCalendarParams['model'] !== '');
		$this->IssuesCalendar->init($clavisIssuesCalendarParams);
	}

	public static function inferModelFromIssuesDescription($issues)
	{
		$model = [];
		foreach ($issues as $issue) {
			$model[] = self::findModelMatch($issue);
		}
		return (count(array_unique($model)) === 1 && $model[0] !== '') ? $model[0] : '';
	}

	private static function findModelMatch($i)
	{
		$description = $i['issueDescription'];

		//	<com:TListItem Value="vyn" Text="<%[Annata (anno), Numero]%>"/>
		//	<com:TListItem Value="nmy" Text="<%[Numero (mese anno)]%>"/>
		//	<com:TListItem Value="n" Text="<%[Numero]%>"/>

		//	<com:TListItem Value="yn" Text="<%[Anno, Numero]%>"/>
		//	<com:TListItem Value="vn" Text="<%[Annata, Numero]%>"/>

		//	<com:TListItem Value="yn2" Text="<%[(Anno), Numero]%>"/>
		//	<com:TListItem Value="ny" Text="<%[Numero (Anno)]%>"/>
		//	<com:TListItem Value="vn2" Text="<%[A. **, N. ** (mmm. aaaa)]%>"/>
		//	<com:TListItem Value="vn3" Text="<%[A. --, n. -- (mmm. aaaa)]%>"/>

		$numRegExp = '\w+(\/\w+)?';

		if (preg_match("/^\w+ \(\w+\), $numRegExp$/", $description)) return 'vyn';
		if (preg_match("/^$numRegExp \(\w+ \w+\)$/", $description)) return 'nmy';
		if (preg_match("/^$numRegExp+$/", $description)) return 'n';

		if (preg_match("/^\w+, $numRegExp$/", $description)) {
			if ($description === Issue::buildIssueNumber('yn', $i['issueStart'], $i['issueEnd'], $i['issueYear'], $i['issueVolume'], $i['issueTimestamp'])) {
				return 'yn';
			}
		}

		if (preg_match("/^\w+, $numRegExp$/", $description)) {
			if ($description === Issue::buildIssueNumber('vn', $i['issueStart'], $i['issueEnd'], $i['issueYear'], $i['issueVolume'], $i['issueTimestamp'])) {
				return 'vn';
			}
		}

		if (preg_match("/^\(\w+\), $numRegExp$/", $description)) return 'yn2';
		if (preg_match("/^$numRegExp \(\w+\)$/", $description)) return 'ny';

		if (preg_match('/^A\. \w+, N\. \w+ \(\w+\. \w+\)$/', $description)) return 'vn2';
		if (preg_match('/^A\. \w+, n\. \w+ \(\w+. \w+\)$/', $description)) return 'vn3';

		return '';
	}

	/**
	 * @param $sender
	 * @param $params
	 * @throws \PropelException
	 */
	public function onYearChanged($sender, $params)
	{
		$clavisIssuesCalendarParams = $this->buildYCalendarParams($params[0], $params[1]);
		$clavisIssuesCalendarParams['model'] = $this->inferModelFromIssuesDescription($clavisIssuesCalendarParams['data']);
		$this->IssuesCalendar->init($clavisIssuesCalendarParams, true);
	}

	/**
	 * @param $year
	 * @return array
	 * @throws \PropelException
	 */
	public function buildYCalendarParams($year, $displayYear)
	{
		$array = unserialize($this->getRequest()->itemAt('param'));
		$mID = $array['manifestationId'];

		$m = ManifestationPeer::retrieveByPK($mID);
		$issues = $this->getIssues($m, $year);

		$ClavisIssuesCalendarParams = [
			'mode' => 'show',
			'data' => $issues,
			'year' => $year,
			'displayYear' => $displayYear,
			'manifestationId' => $mID
		];
		return $ClavisIssuesCalendarParams;
	}

	/**
	 * @param $sender
	 * @param $param
	 */
	public function onCancel($sender, $param)
	{

	}

	/**
	 * @param \Manifestation $m
	 * @param                $year
	 * @return \Issue[]|\PropelObjectCollection
	 * @throws \PropelException
	 */
	private function getIssues(Manifestation $m, $year)
	{
		$issuesToShow = [];
		$c = new Criteria();
		$c->add(IssuePeer::ISSUE_YEAR, $year);
		$c->add(IssuePeer::ISSUE_DATE, null, Criteria::ISNOTNULL);
		$c->addAscendingOrderByColumn(IssuePeer::ISSUE_DATE);
		$c->addAscendingOrderByColumn(IssuePeer::START_NUMBER);
		$issues = $m->getIssues($c);


		/** @var $i Issue */
		foreach ($issues as $i) {
			$issueDate = (string)$i->getIssueDate('Y-m-d');
			$issueStart = (int)$i->getStartNumber();
			$issueEnd = (int)$i->getEndNumber();
			$issueNum = (string)($issueStart != $issueEnd) ? "{$issueStart}/{$issueEnd}" : $issueStart;
			$issueVolume = (string)$i->getIssueVolume();
			$issueType = $i->getIssueType();
			$issueNote = $i->getIssueNote();

			$ts = strtotime(gmdate($issueDate . '\T00:00:00\Z'));
			$issuesToShow[$ts * 1000] = [
				'issueStart' => $issueStart, // 2
				'issueEnd' => $issueEnd,     // 3
				'issueNum' => $issueNum,     // 2/3
				'issueDescription' => $i->getIssueNumber(), // 1 2018, 2/3
				'issueVolume' => $issueVolume,
				'issueYear' => $year,
				'issueType' => $issueType,
				'issueNote' => $issueNote,
				'issueTimestamp' => $ts * 1000,
				'issueId' => $i->getIssueId(),
				'issuePermissions' => $this->getIssuePermissions($i)
			];
		}
		return $issuesToShow;
	}

	/**
	 * @param $i
	 * @return int
	 */
	private function getIssuePermissions(Issue $i)
	{
		$clavisLibrarian = $this->getUser();
		$canEdit = $clavisLibrarian->getEditPermission($i);
		$canDelete = $i->canPurge();
		return 1 + ($canEdit ? 2 : 0) + ($canDelete ? 4 : 0);
	}
}
