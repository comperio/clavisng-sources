<?php
/**
 * Record class file
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 */

/**
 * Record Class
 *
 * Displays a single manifestation.
 * 
 * @author Marco Brancalion <marco@comperio.it>
 * @author Dario Rigolin <dario@comperio.it>
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2008 ePortal Technologies
 * @copyright Copyright &copy; 2009 Comperio srl
 * @version 2.7
 * @package Pages.Catalog
 * @since 2.0
 */
class Record extends ClavisPage 
{
	public $_module = 'CATALOG';

	/** @var Manifestation */
	private $_manifestation = null;
	private $_loanmanager;
	private $_requestmanager;
	private $_extraModeSessionName;
	
	private $_llibraryActive;
	public $_requestTypeActive;

	/** @var ClavisSBN */
	private $_sbnMod;

	private $_numberFields = array(	'073',
									'010',
									'011',
									'012',
									'013',
									'014',
									'015',
									'016',
									'017',
									'020',
									'021',
									'022',
									'040',
									'071',
									'072' );
	
	public $numberFieldLabels;
	
	private $_f17subtypes = array(	'C' => 'LC card number',
									'P' => 'Codice CNR',
									'R' => 'Codice CRP',
									'S' => 'Titoli SBL',
									'U' => 'CUBI' );
	
	private $_f71subtypes = array(	'0' => 'Registrazione sonora: numero di edizione',
									'1' => 'Registrazione sonora: matrix number',
									'2' => 'Musica a stampa: numero di lastra',
									'3' => 'Musica a stampa: altro numero dell\'editore',
									'4' => 'Numero della videoregistrazione',
									'5' => 'Numero editoriale',
									'6' => 'Numero della risorsa elettronica' );

	protected function initVars() 
	{		
		$uniqueId = $this->getUniqueID();
		$this->_extraModeSessionName = 'ExtraModeSessionName' . $uniqueId;
		$this->_loanmanager = $this->getApplication()->getModule('loan');
		$this->_requestmanager = $this->getApplication()->getModule('request');
		
		$this->_llibraryActive = LLibraryPeer::isEnabled();
		$this->_requestTypeActive = ItemRequestPeer::isRequestType();

		/* populate number labels */
		foreach ($this->_numberFields as $field)
		{
			$sfs = UnimarcLabelsQuery::create()
							->filterByLanguage($this->getApplication()->getGlobalization()->getCulture())
							->filterByUnimarcType('U')
							->findByFieldNumber($field);
			
			foreach ($sfs as $l)
			{
				if (! $tag = $l->getSubfieldTag())
				{
					$this->numberFieldLabels[$field]['label'] = $l->getLabel();
				}
				elseif (!(('012' == $field) && ('a' == $tag))
							&& !(('017' == $field) && ('2' == $tag)))	// exclude 012 $a and 017 $2
				{	
					$this->numberFieldLabels[$field]['subfields'][$l->getSubfieldTag()] = array(	'tag' => $l->getSubfieldTag(),
																									'label' => $l->getLabel(),
																									'maxlength' => $l->getMaxlength() );
				}
			}
			
			foreach ($this->numberFieldLabels as $field => &$v)
				uksort($v['subfields'], 'Clavis::strcmpAZ09');
		}
		
		$this->_sbnMod = $this->getApplication()->getModule('sbn');
	}

	public function onInit($param)
	{
		parent::onInit($param);
		$this->initVars();
	}
	
	public function onLoad($param) 
	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsPostBack())		// if first page cycle
		{
			$this->AvailableItemsPanel->setCssClass('panel_off');
								
			$pk = intval($this->getRequest()->itemAt('manifestationId'));
			if ($pk < 1)
			{
				$this->_manifestation = new Manifestation();
			} 
			else
			{
				$this->_manifestation = ManifestationQuery::create()
											->findOneByManifestationId($pk);
				
				if (!$this->_manifestation instanceof Manifestation)
				{
					$this->writeMessage(Prado::localize('Non esiste la notizia con id: {id}',
															array('id' => $pk)),
											ClavisMessage::ERROR);
				
					$this->gotoPage('Catalog.RecordList');
				}
				else
				{
					$this->ShelfList->setObjectParameters('manifestation', $this->_manifestation->getManifestationId(), false);
					$this->ConsistencyNoteList->setManifestationId($this->_manifestation->getManifestationId());
				}
			}
			
			$this->setManifestation($this->_manifestation);
		}
		else		// if NOT first cycle
		{
			$this->_manifestation = $this->getManifestation();
			
			if (($patronId = $this->CirculationData->getPatronId()) != '')
				$this->CirculationData->populate($patronId);
		}

		$myUser = $this->getUser();
		$isSerial = $this->_manifestation->getBibLevel() == ManifestationPeer::LVL_SERIAL;
		$isMonography = $this->_manifestation->getBibLevel() == ManifestationPeer::LVL_MONOGRAPHIC;

		if (!$this->getIsPostBack() && !$this->getIsCallback())		// first page cycle
		{
			$this->StatisticsPanel->setCssClass("panel_off");
			
			$this->doPatronClean();
			$this->doExternalLibraryClean();
			$this->resetExtraMode();

			$datasource = array();
			$shelfList = ShelfPeer::getVisibleShelves(	$myUser,
														ShelfPeer::TYPE_MANIFESTATION );
			
			foreach ($shelfList as $shelf)
			{
				if ($shelf->isEditable($this->getUser()))
					$datasource[$shelf->getShelfId()] = "({$shelf->getShelfId()}) " . substr(strip_tags($shelf->getShelfName()), 0, 20);
			}
			
			$this->ToShelf->setDataSource($datasource);
			$this->ToShelf->dataBind();

			$actualShelfId = $myUser->getActualShelfId();
			
			if (!is_null($actualShelfId))
			{
				try
				{
					$this->ToShelf->setSelectedValue($actualShelfId);
				}
				catch (Exception $e)
				{
					Prado::log("Lo scaffale preferito con id=$actualShelfId non esiste");
					$myUser->setActualShelfId(null);
				}
			}

			$this->UpdateData->setObject($this->_manifestation);
			$this->ItemListMine->setManifestation($this->_manifestation);
			$this->ItemListOther->setManifestation($this->_manifestation);

			if ($isSerial)
			{
				$this->IssueList->setManifestation($this->_manifestation);
				$this->IssueTabView->setVisible(true);
				$this->ConsistencyNoteTab->setVisible(true);
			}
			else
			{
				$this->IssueTabView->setVisible(false);
				$this->ConsistencyNoteTab->setVisible(false);
				$this->ConsistencyNoteList->setVisible(false);
				$this->TabPanel->setActiveViewIndex(2);
			}

			$this->ItemRequests->setObject($this->_manifestation);
			/// da finire $this->Requests->setObject($this->_manifestation);

			if ($isSerial
					&& $this->getUser()->checkAllowedPage('Catalog.IssueInsertPage'))
			{
				////'Seriali (periodici e collezioni)'
				$this->AddIssue->setVisible(true);
				$this->AddSubscription->setVisible(true);
			}
			else
			{
				$this->AddIssue->setVisible(false);
				$this->AddSubscription->setVisible(false);
			}
			
			if (!$isSerial
					&& !$isMonography)
			{
				$this->RequestsTabView->setVisible(false);
				$this->TabPanel->setActiveViewID('AttachTab');
			}

			$this->populate();
		}	// end of first page cycle

		// permissions checking
		if ($this->_manifestation instanceof Manifestation) 
		{
			$modifyEnabled = $myUser->getEditPermission($this->_manifestation);
			
			$insertEnabled = $myUser->checkAllowedPage('Catalog.ItemInsertPage')
								&& !$this->_manifestation->canHaveItems();
			
			$bulkTeleportEnabled = $myUser->checkAllowedPage('Catalog.ItemInsertBulkPage')
										&& $this->_manifestation->canHaveItems();
			
			$dupEnabled = $myUser->checkAllowedPage('Catalog.EditRecord');
			
			$reserveEnabled = ($this->_requestmanager->isManifestationReservable($this->_manifestation) == ClavisLoanManager::OK)
									&& ($isMonography || $isSerial);
			
			$eraseEnabled = $this->_manifestation->isDeleteable();
		} 
		else 
		{
			$modifyEnabled = false;
			$insertEnabled = false;
			$bulkTeleportEnabled = false;
			$dupEnabled = false;
			$reserveEnabled = false;
			$eraseEnabled = false;
		}

		$this->ReserveManifestationButton->setEnabled($reserveEnabled);
		
		if (!$modifyEnabled)
			$this->Modify->setText(Prado::localize('modifica legami'));
		
		$this->EraseButton->setVisible($modifyEnabled
											&& $eraseEnabled);
		
		/**
		 * This is the 'total delete' case, according to the
		 * CNG-873 ticket
		 */
		if ($this->getUser()->getIsAdmin())
		{
			$this->TotalEraseButton->setVisible(true);
			
			$messageText = Prado::localize("Rimozione totale della notizia con id={id}, titolo '{title}'. Verrà cancellato ogni legame a esemplari, altre notizie, authority, fascicoli, prenotazioni. I prestiti storici verranno conservati senza riferimento a questa notizia.",
												array(	'id' => $this->_manifestation->getId(),
														'title' => $this->_manifestation->getTrimmedTitle(70) ));
			
			$this->TotalEraseButton->setParam($messageText);
		}
		else
		{
			$this->TotalEraseButton->setVisible(false);
		}
		
		$this->AddItem->setVisible($insertEnabled);
		$this->BulkTeleportButton->setVisible($bulkTeleportEnabled);
		$this->CopyManifestationButton->setEnabled($dupEnabled);

		$loanableSince = $this->_manifestation->getLoanableSince('U');
		if ($loanableSince - time() > 0)
		{
		    $this->LoanableSincePanel->setVisible(true);
			$this->LoanableSince->setParameter('date', Clavis::dateFormat($loanableSince));
			$this->LoanableSince->setVisible(true);
		}
		else
		{
			$this->LoanableSince->setVisible(false);
		}

		$this->TurbomarcPanel->setVisible(($this->getApplication()->getMode() == 'Debug')
												|| $this->getUser()->getIsAdmin());
			
		// analysis of possible re-populations, etc
		if ($this->getPage()->getIsPostBack()
				|| $this->getPage()->getIsCallback())		// not first page cycle
		{
			$updateItemRequests = $this->getApplication()->getSession()->itemAt('UpdateItemRequests');
			$delayedMessage = null;
			
			if (!is_null($updateItemRequests)
					&& ($updateItemRequests == true)) 
			{
				$this->getApplication()->getSession()->remove('UpdateItemRequests');

				$patron = $this->getPatron();
				if (!is_null($patron) && ($patron instanceof Patron))
					$this->insertPatron($patron->getPatronId());

				$this->ItemRequests->populate();
				/// da finire $this->Requests->populate();
			}
			
			if ($this->ReloadIssues->getValue() != '')
				$this->IssueList->populate();
			
			if ($this->ReloadItems->getValue() != '')
			{
				$this->ItemListMine->populate();
				$this->ItemListOther->populate();
			}

			if (count($delayedMessage) == 2) 
			{
				$this->getApplication()->getSession()->remove('DelayedMessage');
				$this->writeMessage($delayedMessage[0], $delayedMessage[1]);
			}
		}
	}

	public function resetExtraMode($param = false)
	{
		$this->setExtraMode($param);
	}

	public function setExtraMode($param = false)
	{
		$this->getApplication()->getSession()->add($this->_extraModeSessionName, $param);
	}

	public function getExtraMode()
	{
		return $this->getApplication()->getSession()->itemAt($this->_extraModeSessionName);
	}

	public function setManifestation(Manifestation $man)
	{
		if ($this->_manifestation instanceof Manifestation)
		{	
			$this->setViewState('ManifestationId', $this->_manifestation->isNew()
															? 0 
															: $this->_manifestation->getManifestationId());
		}
		else
		{
			$this->setViewState('ManifestationId', null);
		}
	}

	public function getManifestation()
	{
		if ($this->_manifestation instanceof Manifestation)
			return $this->_manifestation;

		$manId = $this->getViewState('ManifestationId', null);
	
		if ($manId === null)
		{
			return null;
		}
		elseif ($manId === 0)
		{
			return new Manifestation();
		}
		else
		{
			return ManifestationQuery::create()->findOneByManifestationId($manId);
		}
	}

	public function getManifestationId()
	{
		return $this->getViewState('ManifestationId');
	}

	/**
	 * If the page private variable "_manifestation" is not new
	 * (already saved on database) it extracts its values and puts
	 * them in the fields in the page.
	 *
	 */
	public function populate() 
	{
		if ($this->_manifestation->isNew())
			return;

		$tm = $this->_manifestation->cacheTurboMarc(true, false);
		$author = $this->_manifestation->getAuthor();
		$abstract = $this->_manifestation->getAbstract();
		$notes = $this->_manifestation->getNotes();
		$languages = array();

		$prefix = (('0' == $tm->d200['i1']) && isset($tm->d461))
							? preg_replace('!\s+!', ' ', $tm->d461->st) . '. '
							: '';
		
		$title = $prefix . trim($tm->getFullTitle());
		$title = htmlentities($title, ENT_COMPAT, 'UTF-8');
		$author = htmlentities($author, ENT_COMPAT, 'UTF-8');
		$isbd = "<strong>{$author}<br />{$title}</strong><br />";

		if (isset($tm->d101))
		{
			foreach ($tm->d101->children() as $sf)
				if (trim($sf))
					$languages[] = LookupValuePeer::getLookupValue(	'LANGUAGES',
																	(string)$sf, 0)
																	. ' <em>(' . UnimarcCodesPeer::getValueLabel(101, $sf->getTag(), 0, '') . ')</em>';
		}
		
		$v = $tm->getEditions();
		
		if ($v)
			$isbd .= htmlentities(implode(' - ', $v), ENT_COMPAT, 'UTF-8') . '<br />';
		
		foreach ($this->_manifestation->getAreas() as $area)
			$isbd .= ManifestationPeer::getAreaName($area['field']) . ': ' . htmlentities($area['value'], ENT_COMPAT, 'UTF-8') . '<br />';
		
		$v = $tm->getPublications(true);
		if ($v)
		{
			$pub = array(	'  ' => array(),
							'0 '=>array(),
							'1 '=>array() );
			
			foreach ($v as $p)
				@$pub[$p['ind']][] = $p['txt'];
			
			if (count($pub['  ']))
				$isbd .= htmlentities(implode(' - ', $pub['  ']), ENT_COMPAT, 'UTF-8') . '<br />';
			
			if (count($pub['0 ']))
				$isbd .= Prado::localize('poi: ') . htmlentities(implode(' - ', $pub['0 ']), ENT_COMPAT, 'UTF-8') . '<br />';
			
			if (count($pub['1 ']))
				$isbd .= Prado::localize('poi: ') . htmlentities(implode(' - ', $pub['1 ']), ENT_COMPAT, 'UTF-8') . '<br />';
		}
		
		$v = $tm->getPhysicalDescs();
		
		if ($v)
			$isbd .= htmlentities(implode(' - ', $v), ENT_COMPAT, 'UTF-8') . '<br />';

		$isbd .= '<hr />';
		$year = $this->_manifestation->getYear();
		if ($year) {
			switch ($year['type'])
			{
				case 'j':
				case 'z':
					try
					{
						$date = Clavis::dateFormat(new DateTime($year['date']),'shortdate');
					}
					catch (Exception $e)
					{
						$date = $year['date'];
					}
					break;

				default:
					$date = $year['date'];
			}

            $dateLabel = LookupValuePeer::getLookupValue($this->_manifestation->getEntityTypeClass('DATETYPE'),$year['type']);
			$isbd .= '<br /><strong>' . ucfirst($dateLabel). ':</strong> ' . $date;
		}
		
		switch (count($languages))
		{
			case 0:
				break;
			
			case 1:
				$isbd .= '<br /><strong>' . Prado::localize('Lingua') . ':</strong> ' . $languages[0];
				break;
			
			default:
				$isbd .= '<br /><strong>' . Prado::localize('Lingue') . ':</strong> ' . implode(', ', $languages);
		}

		if ($target = trim($this->_manifestation->getTarget()))
		{
			$cur = 17;
			$labels = array();
		
			foreach (explode('-', $target) as $t)
			{
				if (!trim($t))
					continue;
			
				$code = UnimarcCodesQuery::create()
								->findPk([$this->getApplication()->getGlobalization()->getCulture(), 100, 'a', $cur, $t, 'U']);

				if ($code instanceof UnimarcCodes)
					$labels[] = $code->getLabel();
				
				++$cur;
			}
			
			if (count($labels) > 0)
				$isbd .= '<br /><strong>' . Prado::localize('Destinatari') . ':</strong> ' . implode('; ', $labels);
		}

		// standard numbers
		foreach ($this->numberFieldLabels as $fnum => $field)
		{
			$xmlField = "d{$fnum}";
			if (!isset($tm->$xmlField))
				continue;

			/* @var $fld TurboMarc */
			foreach ($tm->$xmlField as $fld)
			{
				switch ($fnum)
				{
					case '017':
						$subtype = array_key_exists((string)$fld->s2,
													$this->_f17subtypes)
															? ' / ' . $this->_f17subtypes[(string)$fld->s2]
															: '';
						
						$isbd .= "<br /><strong>{$field['label']}{$subtype}:</strong> ";
						break;
					
					case '071':
						$subtype = array_key_exists((string)$fld['i1'],
													$this->_f71subtypes)
															? ' / ' . $this->_f71subtypes[(string)$fld['i1']]
															: '';
						
						$isbd .= "<br /><strong>{$field['label']}{$subtype}:</strong> ";
						break;
					
					default:
						$isbd .= "<br /><strong>{$field['label']}:</strong> ";
				}
				
				if ('012' == $fnum)
				{
					if (!isset($fld->ss))
					{	// old format, convert to new one
						$fld->addSubField('s', substr($fld->sa, 0, 4));
						$fld->addSubField('t', substr($fld->sa, 5, 4));
						$fld->addSubField('u', substr($fld->sa, 10, 4));
						$fld->addSubField('v', substr($fld->sa, 15, 4));
						$fld->addSubField('w', substr($fld->sa, 20, 12));
						$fld->addSubField('x', substr($fld->sa, 33));
					}
					
					foreach (array_keys($field['subfields']) as $sftag)
					{
						$xmltag = "s{$sftag}";
					
						if (trim($fld->$xmltag))
							$isbd .= ' '.(string)$fld->$xmltag;
					}
				}
				else
				{
					foreach (array_keys($field['subfields']) as $sftag)
					{
						$xmltag = "s{$sftag}";
					
						if (trim($fld->$xmltag))
							$isbd .= ('a' == $sftag)
											? (string)$fld->$xmltag
											: "; {$fld->$xmltag} <em>({$field['subfields'][$sftag]['label']})</em>";
					}
				}
			}
		}

		if ($series = $tm->getSeries())
			$isbd .= '<br /><strong>' . Prado::localize('Collana') . ':</strong> ' . implode('<br />', $series);
		
		foreach ($notes as $note)
			$isbd .= '<br /><strong>' . LookupValuePeer::getLookupValue('UNI3XX', $note['code'], 0)
							. ":</strong><br> " . nl2br(htmlspecialchars($note['text']));
		
		if ($abstract)
			$isbd .= '<br /><strong>' . Prado::localize('Abstract') . ':</strong> ' . nl2br($abstract);
		
		$titles = $this->_manifestation->getAltTitles();
		if (count($titles) > 0)
		{
			$isbd .= '<br /><strong>' . Prado::localize('Altri titoli') . ':</strong> <br />';
			foreach ($titles as $title)
			{
				$isbd .= '<em>' . LookupValuePeer::getLookupValue('UNI5XX', $title['field'])
								. ':</em> ' . htmlspecialchars($title['value']) . "<br />\n";
			}
		}
		
		$cnt = count($tm->d856);
		if ($cnt > 0)
		{
			$isbd .= '<br /><strong>' . Prado::localize('Risorse elettroniche:') . '</strong><ul>';
		
			for ($i = 0; $i < $cnt; ++$i)
			{
				$fld = $tm->d856[$i];
				$url = (string) $fld->su;
				$type = LookupValuePeer::getLookupValue('ELECTRONICSOURCE', (string) $fld['i1'] . (string) $fld['i2']);
				$note = trim((string) $fld->sz);
			
				if ($note)
					$note = " ({$note})";
				
				$isbd .= "<li><em>{$type}</em>: <a href=\"{$url}\">{$url}</a>{$note}</li>";
			}
			
			$isbd .= '</ul>';
		}

		$isbd .= '<br />';
		$this->ISBD->setText($isbd);
		$this->CDFRepeater->setDataSource($this->_manifestation->getCDFs());
		$this->CDFRepeater->dataBind();

		$manId = $this->_manifestation->getManifestationId();

		/** POPULATE LINKS
		 * Start of retrieving linked authorities
		 */
		
		$workAuthorities = LAuthorityManifestationQuery::create()
								->join('Authority')
								->filterByManifestationId($manId)
								->findByLinkType(500);

		$workAuthoritiesArray = array();
		$workDemultiplexedArray = array();
		
		foreach ($workAuthorities as $lA)
		{
			/* @var $lA LAuthorityManifestation */
			$row = array();
			
			$row['NavigateUrl'] = AuthorityPeer::getNavigateUrl($lA->getAuthorityId());
			$row['WorkNavigateUrl'] = "";
			
			$authority = $lA->getAuthority();
			
			if ($authority instanceof Authority)
			{
				$fullText = $authority->getFullText();
				$workDemultiplexedArray[$authority->getAuthorityId()] = $authority->getAuthoritiesLinkList(true); 
			}
			else
			{
				$fullText = "(" . Prado::localize("non esistente") . ")";
			}

			$row['FullText'] = $fullText;
			
			$row['LinkNote'] = $lA->getLinkNote();
			$row['SourceSync'] = $lA->getSourceSync();
			
			$workAuthoritiesArray[] = $row;
		}

		/**
		 * added logic for demultiplexing works authorities into others
		 */

		$decodedWorkAuthorities = $this->decodeWorkAuthorities($workDemultiplexedArray);
		$linkedWorksAuthoritiesArray = array();
		
		if (array_key_exists('linkedWorks', $decodedWorkAuthorities)
				&& (count($decodedWorkAuthorities['linkedWorks']) > 0))
		{
			$workLinkedOperasAuthoritiesArray = array();
			
			foreach ($decodedWorkAuthorities['linkedWorks'] as $workAuthorityId => $rowArray)
			{
				foreach ($rowArray as $row)
				{				
					$newRow = array();

					$newRow['WorkNavigateUrl'] = AuthorityPeer::getNavigateUrl($workAuthorityId);
					$newRow['NavigateUrl'] = AuthorityPeer::getNavigateUrl($row['AuthorityId']);

					$newRow['FullText'] = $row['FullText'];
					$newRow['LinkTypeLabel'] = $row['LinkTypeLabel'];
					$newRow['LinkNote'] = $row['LinkNote'];

					$workLinkedOperasAuthoritiesArray[] = $newRow;
				}
			}

			if (count($workLinkedOperasAuthoritiesArray) > 0)
				$linkedWorksAuthoritiesArray = $workLinkedOperasAuthoritiesArray;
		}

		$authorAuthorities = LAuthorityManifestationQuery::create()
								->setFormatter(ModelCriteria::FORMAT_ON_DEMAND)
								->filterByManifestationId($manId)
								->filterByLinkType(700, Criteria::GREATER_EQUAL)
								->filterByLinkType(799, Criteria::LESS_EQUAL)
								->useAuthorityQuery()
								->orderByFullText()
								->endUse()
								->find();
		
		$authorAuthoritiesArray = array();
		
		foreach ($authorAuthorities as $lA)
		{
			/* @var $lA LAuthorityManifestation */
			$row = array();
			
			$row['NavigateUrl'] = AuthorityPeer::getNavigateUrl($lA->getAuthorityId());
			$row['WorkNavigateUrl'] = "";
			
			$authority = $lA->getAuthority();
			
			if ($authority instanceof Authority)
			{
				$fullText = $authority->getFullText();
			}
			else
			{
				$fullText = "(" . Prado::localize("non esistente") . ")";
			}
			
			$row['FullText'] = $fullText;
			
			$row['RelatorCode'] = $lA->getRelatorCode();
			$row['LinkNote'] = $lA->getLinkNote();
			$row['SourceSync'] = $lA->getSourceSync();
			
			$authorAuthoritiesArray[] = $row;
		}

		if (array_key_exists('author', $decodedWorkAuthorities)
				&& (count($decodedWorkAuthorities['author']) > 0))
		{
			$workAuthorAuthoritiesArray = array();
			
			foreach ($decodedWorkAuthorities['author'] as $workAuthorityId => $rowArray)
			{
				foreach ($rowArray as $row)
				{				
					$newRow = array();

					$newRow['WorkNavigateUrl'] = AuthorityPeer::getNavigateUrl($workAuthorityId);
					$newRow['NavigateUrl'] = AuthorityPeer::getNavigateUrl($row['AuthorityId']);

					$newRow['FullText'] = $row['FullText'];
					$newRow['RelatorCode'] = $row['RelatorCodeIndex'];
					$newRow['LinkNote'] = $row['LinkNote'];
					$newRow['SourceSync'] = $row['SourceSync'];

					$workAuthorAuthoritiesArray[] = $newRow;
				}
			}

			if (count($workAuthorAuthoritiesArray) > 0)
				$authorAuthoritiesArray = array_merge($workAuthorAuthoritiesArray, $authorAuthoritiesArray);
		}

		$placeAuthorities = LAuthorityManifestationQuery::create()
								->join('Authority')
								->filterByManifestationId($manId)
								->findByLinkType(620);

		$placeAuthoritiesArray = array();
		
		foreach ($placeAuthorities as $lA)
		{
			/* @var $lA LAuthorityManifestation */
			$row = array();
			
			$row['NavigateUrl'] = AuthorityPeer::getNavigateUrl($lA->getAuthorityId());
			$row['WorkNavigateUrl'] = "";
			
			$authority = $lA->getAuthority();
			
			if ($authority instanceof Authority)
			{
				$fullText = $authority->getFullText();
			}
			else
			{
				$fullText = "(" . Prado::localize("non esistente") . ")";
			}
			
			$row['FullText'] = $fullText;
			
			$row['LinkNote'] = $lA->getLinkNote();
			$row['SourceSync'] = $lA->getSourceSync();
			
			$placeAuthoritiesArray[] = $row;
		}
		
		if (array_key_exists('place', $decodedWorkAuthorities)
				&& (count($decodedWorkAuthorities['place']) > 0))
		{
			$workPlaceAuthoritiesArray = array();
			
			foreach ($decodedWorkAuthorities['place'] as $workAuthorityId => $rowArray)
			{
				foreach ($rowArray as $row)
				{
					$newRow = array();

					$newRow['WorkNavigateUrl'] = AuthorityPeer::getNavigateUrl($workAuthorityId);
					$newRow['NavigateUrl'] = AuthorityPeer::getNavigateUrl($row['AuthorityId']);

					$newRow['FullText'] = $row['FullText'];
					$newRow['RelatorCode'] = $row['RelatorCodeIndex'];
					$newRow['LinkNote'] = $row['LinkNote'];
					$newRow['SourceSync'] = $row['SourceSync'];

					$worPlaceAuthoritiesArray[] = $newRow;
				}
			}

			if (count($workPlaceAuthoritiesArray) > 0)
				$placeAuthoritiesArray = array_merge($workPlaceAuthoritiesArray, $placeAuthoritiesArray);
		}

		$formAuthorities = LAuthorityManifestationQuery::create()
								->join('Authority')
								->filterByManifestationId($manId)
								->findByLinkType(608);

		$formAuthoritiesArray = array();
		
		foreach ($formAuthorities as $lA)
		{
			/* @var $lA LAuthorityManifestation */
			$row = array();
			
			$row['NavigateUrl'] = AuthorityPeer::getNavigateUrl($lA->getAuthorityId());
			$row['WorkNavigateUrl'] = "";
			
			$authority = $lA->getAuthority();
			
			if ($authority instanceof Authority)
			{
				$fullText = $authority->getFullText();
				$subjectClass = $authority->getSubjectClass();
			}
			else
			{
				$fullText = "(" . Prado::localize("non esistente") . ")";
				$subjectClass = "";
			}
			
			$row['FullText'] = $fullText;
			$row['SubjectClass'] = $subjectClass;
			
			$row['LinkNote'] = $lA->getLinkNote();
			$row['SourceSync'] = $lA->getSourceSync();
			
			$formAuthoritiesArray[] = $row;
		}
		
		if (array_key_exists('form', $decodedWorkAuthorities)
				&& (count($decodedWorkAuthorities['form']) > 0))
		{
			$workFormAuthoritiesArray = array();
			
			foreach ($decodedWorkAuthorities['form'] as $workAuthorityId => $rowArray)
			{
				foreach ($rowArray as $row)
				{
					$newRow = array();

					$newRow['WorkNavigateUrl'] = AuthorityPeer::getNavigateUrl($workAuthorityId);
					$newRow['NavigateUrl'] = AuthorityPeer::getNavigateUrl($row['AuthorityId']);

					$newRow['FullText'] = $row['FullText'];
					$newRow['RelatorCode'] = $row['RelatorCodeIndex'];
					$newRow['LinkNote'] = $row['LinkNote'];
					$newRow['SourceSync'] = $row['SourceSync'];

					$worFormAuthoritiesArray[] = $newRow;
				}
			}

			if (count($workFormAuthoritiesArray) > 0)
				$formAuthoritiesArray = array_merge($workFormAuthoritiesArray, $formAuthoritiesArray);
		}
		
		$subjectAuthorities = LAuthorityManifestationQuery::create()
								->filterByManifestationId($manId)
								->filterByLinkType(600, Criteria::GREATER_EQUAL)
								->filterByLinkType(610, Criteria::LESS_EQUAL)
								->filterByLinkType(608, Criteria::NOT_EQUAL)
								->filterByLinkType(609, Criteria::NOT_EQUAL)
								->useAuthorityQuery()
								->orderByFullText()
								->endUse()
								->find();

		$subjectAuthoritiesArray = array();
		
		foreach ($subjectAuthorities as $lA)
		{
			/* @var $lA LAuthorityManifestation */
			$row = array();
			
			$row['NavigateUrl'] = AuthorityPeer::getNavigateUrl($lA->getAuthorityId());
			$row['WorkNavigateUrl'] = "";
			
			$authority = $lA->getAuthority();
			
			if ($authority instanceof Authority)
			{
				$fullText = $authority->getFullText();
				$subjectClass = $authority->getSubjectClass();
			}
			else
			{
				$fullText = "(" . Prado::localize("non esistente") . ")";
				$subjectClass = "";
			}
			
			$row['FullText'] = $fullText;
			$row['SubjectClass'] = $subjectClass;
			
			$row['LinkNote'] = $lA->getLinkNote();
			$row['SourceSync'] = $lA->getSourceSync();
			
			$subjectAuthoritiesArray[] = $row;
		}

		if (array_key_exists('subject', $decodedWorkAuthorities)
				&& (count($decodedWorkAuthorities['subject']) > 0))
		{
			$workSubjectAuthoritiesArray = array();
	
			foreach ($decodedWorkAuthorities['subject'] as $workAuthorityId => $rowArray)
			{
				foreach ($rowArray as $row)
				{
					$newRow = array();

					$newRow['WorkNavigateUrl'] = AuthorityPeer::getNavigateUrl($workAuthorityId);
					$newRow['NavigateUrl'] = AuthorityPeer::getNavigateUrl($row['AuthorityId']);

					$newRow['FullText'] = $row['FullText'];
					$newRow['RelatorCode'] = $row['RelatorCodeIndex'];
					$newRow['LinkNote'] = $row['LinkNote'];
					$newRow['SourceSync'] = $row['SourceSync'];

					$workSubjectAuthoritiesArray[] = $newRow;
				}
			}

			if (count($workSubjectAuthoritiesArray) > 0)
				$subjectAuthoritiesArray = array_merge($workSubjectAuthoritiesArray, $subjectAuthoritiesArray);
		}
		
        $keywordsAuthorities = LAuthorityManifestationQuery::create()
								->filterByManifestationId($manId)
								->filterByLinkType(619)
								->useAuthorityQuery()
								->orderByFullText()
								->endUse()
								->find();
		
		$keywordsAuthoritiesArray = array();
		
		foreach ($keywordsAuthorities as $lA)
		{
			/* @var $lA LAuthorityManifestation */
			$row = array();
			
			$row['NavigateUrl'] = AuthorityPeer::getNavigateUrl($lA->getAuthorityId());
			
			$authority = $lA->getAuthority();
			
			if ($authority instanceof Authority)
			{
				$fullText = $authority->getFullText();
				$subjectClass = $authority->getSubjectClass();
			}
			else
			{
				$fullText = "(" . Prado::localize("non esistente") . ")";
				$subjectClass = "";
			}
			
			$row['FullText'] = $fullText;
			$row['SubjectClass'] = $subjectClass;
			
			$row['LinkNote'] = $lA->getLinkNote();
			$row['SourceSync'] = $lA->getSourceSync();
			
			$keywordsAuthoritiesArray[] = $row;
		}
		
		if (array_key_exists('keywords', $decodedWorkAuthorities)
				&& (count($decodedWorkAuthorities['keywords']) > 0))
		{
			$workKeywordsAuthoritiesArray = array();
	
			foreach ($decodedWorkAuthorities['keywords'] as $workAuthorityId => $rowArray)
			{
				foreach ($rowArray as $row)
				{
					$newRow = array();

					$newRow['WorkNavigateUrl'] = AuthorityPeer::getNavigateUrl($workAuthorityId);
					$newRow['NavigateUrl'] = AuthorityPeer::getNavigateUrl($row['AuthorityId']);

					$newRow['FullText'] = $row['FullText'];
					$newRow['RelatorCode'] = $row['RelatorCodeIndex'];
					$newRow['LinkNote'] = $row['LinkNote'];
					$newRow['SourceSync'] = $row['SourceSync'];

					$workKeywordsAuthoritiesArray[] = $newRow;
				}
			}

			if (count($workKeywordsAuthoritiesArray) > 0)
				$keywordsAuthoritiesArray = array_merge($workKeywordsAuthoritiesArray, $keywordsAuthoritiesArray);
		}		
		
		$altSubjectAuthorities = LAuthorityManifestationQuery::create()
								->filterByManifestationId($manId)
								->filterByLinkType(609)
								->useAuthorityQuery()
								->orderByFullText()
								->endUse()
								->find();

		$altSubjectAuthoritiesArray = array();
		
		foreach ($altSubjectAuthorities as $lA)
		{
			/* @var $lA LAuthorityManifestation */
			$row = array();
			
			$row['NavigateUrl'] = AuthorityPeer::getNavigateUrl($lA->getAuthorityId());
			
			$authority = $lA->getAuthority();
			
			if ($authority instanceof Authority)
			{
				$fullText = $authority->getFullText();
				$subjectClass = $authority->getSubjectClass();
			}
			else
			{
				$fullText = "(" . Prado::localize("non esistente") . ")";
				$subjectClass = "";
			}
			
			$row['FullText'] = $fullText;
			$row['SubjectClass'] = $subjectClass;
			
			$row['LinkNote'] = $lA->getLinkNote();
			$row['SourceSync'] = $lA->getSourceSync();
			
			$altSubjectAuthoritiesArray[] = $row;
		}
		
		if (array_key_exists('altSubject', $decodedWorkAuthorities)
				&& (count($decodedWorkAuthorities['altSubject']) > 0))
		{
			$workAltSubjectAuthoritiesArray = array();
	
			foreach ($decodedWorkAuthorities['altSubject'] as $workAuthorityId => $rowArray)
			{
				foreach ($rowArray as $row)
				{
					$newRow = array();

					$newRow['WorkNavigateUrl'] = AuthorityPeer::getNavigateUrl($workAuthorityId);
					$newRow['NavigateUrl'] = AuthorityPeer::getNavigateUrl($row['AuthorityId']);

					$newRow['FullText'] = $row['FullText'];
					$newRow['RelatorCode'] = $row['RelatorCodeIndex'];
					$newRow['LinkNote'] = $row['LinkNote'];
					$newRow['SourceSync'] = $row['SourceSync'];

					$workAltSubjectAuthoritiesArray[] = $newRow;
				}
			}

			if (count($workAltSubjectAuthoritiesArray) > 0)
				$altSubjectAuthoritiesArray = array_merge($workAltSubjectAuthoritiesArray, $altSubjectAuthoritiesArray);
		}	
		
		$classesAuthorities = LAuthorityManifestationQuery::create()
								->join('Authority')
								->filterByManifestationId($manId)
								->filterByLinkType(676)
								->find();

		$classesAuthoritiesArray = array();
		
		foreach ($classesAuthorities as $lA)
		{
			/* @var $lA LAuthorityManifestation */
			$row = array();
			
			$row['NavigateUrl'] = AuthorityPeer::getNavigateUrl($lA->getAuthorityId());
			
			$authority = $lA->getAuthority();
			
			if ($authority instanceof Authority)
			{
				$fullText = $authority->getFullText();
			}
			else
			{
				$fullText = "(" . Prado::localize("non esistente") . ")";
			}
			
			$row['FullText'] = $fullText;
			
			$row['LinkNote'] = $lA->getLinkNote();
			$row['SourceSync'] = $lA->getSourceSync();
			
			$classesAuthoritiesArray[] = $row;
		}
		
		if (array_key_exists('classes', $decodedWorkAuthorities)
				&& (count($decodedWorkAuthorities['classes']) > 0))
		{
			$workClassesAuthoritiesArray = array();
	
			foreach ($decodedWorkAuthorities['classes'] as $workAuthorityId => $rowArray)
			{
				foreach ($rowArray as $row)
				{
					$newRow = array();

					$newRow['WorkNavigateUrl'] = AuthorityPeer::getNavigateUrl($workAuthorityId);
					$newRow['NavigateUrl'] = AuthorityPeer::getNavigateUrl($row['AuthorityId']);

					$newRow['FullText'] = $row['FullText'];
					$newRow['RelatorCode'] = $row['RelatorCodeIndex'];
					$newRow['LinkNote'] = $row['LinkNote'];
					$newRow['SourceSync'] = $row['SourceSync'];

					$workClassesAuthoritiesArray[] = $newRow;
				}
			}

			if (count($workClassesAuthoritiesArray) > 0)
				$classesAuthoritiesArray = array_merge($workClassesAuthoritiesArray, $classesAuthoritiesArray);
		}	
		
		$otherAuthorities = LAuthorityManifestationQuery::create()
								->join('Authority')
								->filterByManifestationId($manId)
								->findByLinkType(921);

		$otherAuthoritiesArray = array();
		
		foreach ($otherAuthorities as $lA)
		{
			/* @var $lA LAuthorityManifestation */
			$row = array();
			
			$row['NavigateUrl'] = AuthorityPeer::getNavigateUrl($lA->getAuthorityId());
			
			$authority = $lA->getAuthority();
			
			if ($authority instanceof Authority)
			{
				$fullText = $authority->getFullText();
			}
			else
			{
				$fullText = "(" . Prado::localize("non esistente") . ")";
			}
			
			$row['FullText'] = $fullText;
			
			$row['LinkType'] = $lA->getLinkType();
			$row['SourceSync'] = $lA->getSourceSync();
			
			$otherAuthoritiesArray[] = $row;
		}
		
		if (array_key_exists('otherAuthorities', $decodedWorkAuthorities)
				&& (count($decodedWorkAuthorities['otherAuthorities']) > 0))
		{
			$workOtherAuthoritiesAuthoritiesArray = array();
	
			foreach ($decodedWorkAuthorities['otherAuthorities'] as $workAuthorityId => $rowArray)
			{
				foreach ($rowArray as $row)
				{
					$newRow = array();

					$newRow['WorkNavigateUrl'] = AuthorityPeer::getNavigateUrl($workAuthorityId);
					$newRow['NavigateUrl'] = AuthorityPeer::getNavigateUrl($row['AuthorityId']);

					$newRow['FullText'] = $row['FullText'];
					$newRow['RelatorCode'] = $row['RelatorCodeIndex'];
					$newRow['LinkNote'] = $row['LinkNote'];
					$newRow['SourceSync'] = $row['SourceSync'];

					$workOtherAuthoritiesAuthoritiesArray[] = $newRow;
				}
			}

			if (count($workOtherAuthoritiesAuthoritiesArray) > 0)
				$otherAuthoritiesAuthoritiesArray = array_merge($workOtherAuthoritiesAuthoritiesArray, $otherAuthoritiesAuthoritiesArray);
		}
		
		////// end of authorities part
		
		$itemLinks = array();

		$actualLibraryId = $this->getUser()->getActualLibraryId();
		$links = LAuthorityItemQuery::create()
						->joinAuthority()
						->useItemQuery()
							->filterByManifestation($this->_manifestation)
						->endUse()
						->find();
		
		foreach ($links as $l)
		{
			$itemLinks[] = array(	'ItemId' => $l->getItem()->getItemId(),
									'ItemInventory' => $l->getItem()->getCompleteInventoryNumber(),
									'ItemColl' => $l->getItem()->getCollocationCombo($actualLibraryId),
									'AuthId' => $l->getAuthorityId(),
									'AuthFullText' => $l->getAuthority()->getFullText(),
									'RelatorCode' => $l->getRelatorCode(),
									'LinkNote' => trim($l->getLinkNote()) );
		}

		/**
		 * Actual part where authorities are databound, by entire object though,
		 * to their repeater.
		 * We need to change this and send to repeaters real arrays, as from the 
		 * CNG-893 on we have some other authorities that derive from those 
		 * linked from the opera (works) authorities here.
		 */
		
		//$this->Authors->setDataSource($authorAuthorities);
		$this->Authors->setDataSource($authorAuthoritiesArray);
		$this->Authors->dataBind();
		
		//$this->Works->setDataSource($workAuthorities);
		$this->Works->setDataSource($workAuthoritiesArray);
		$this->Works->dataBind();
		
		$this->LinkedWorks->setDataSource($linkedWorksAuthoritiesArray);
		$this->LinkedWorks->dataBind();
		
		//$this->Places->setDataSource($placeAuthorities);
		$this->Places->setDataSource($placeAuthoritiesArray);
		$this->Places->dataBind();
		
		//$this->Forms->setDataSource($formAuthorities);
		$this->Forms->setDataSource($formAuthoritiesArray);
		$this->Forms->dataBind();
		
		//$this->Subjects->setDataSource($subjectAuthorities);
		$this->Subjects->setDataSource($subjectAuthoritiesArray);
		$this->Subjects->dataBind();

		//$this->Keywords->setDataSource($keywordsAuthorities);
		$this->Keywords->setDataSource($keywordsAuthoritiesArray);
        $this->Keywords->dataBind();

		//$this->AltSubjects->setDataSource($altSubjectAuthorities);
		$this->AltSubjects->setDataSource($altSubjectAuthoritiesArray);
		$this->AltSubjects->dataBind();
				
		//$this->Classes->setDataSource($classesAuthorities);
		$this->Classes->setDataSource($classesAuthoritiesArray);
		$this->Classes->dataBind();
		
		//$this->OtherAuthorities->setDataSource($otherAuthorities);
		$this->OtherAuthorities->setDataSource($otherAuthoritiesArray);
		$this->OtherAuthorities->dataBind();
		
		// End of authorities databinding
		
		$this->ItemLinks->setDataSource($itemLinks);
		$this->ItemLinks->dataBind();

		$manQuery = LManifestationQuery::create()
						->where('LManifestation.ManifestationIdUp = ?', $manId)
						->orWhere('LManifestation.ManifestationIdDown = ?', $manId)
						->orderByLinkType()
						->orderByLinkSequence()
						->setFormatter(ModelCriteria::FORMAT_ON_DEMAND);

		if ($this->_manifestation->getBibLevel() == ManifestationPeer::LVL_SERIAL)
			$manQuery->filterByIssueId(null);

		$lManifestations = array();
		/* @var $row LManifestation */
		foreach ($manQuery->find() as $row)
		{
			if ($row->getManifestationIdUp() == $manId)
			{
				$manifestation = $row->getManifestationRelatedByManifestationIdDown();
				$linkType = $row->getLinkType();
				$linkTypeString = LookupValuePeer::getLookupValue('UNI4XX', $linkType);
			}
			else
			{
				//patch
				$manifestation = $row->getManifestationRelatedByManifestationIdUp();
				$linkType = TurboMarcMappings::$reverseLinkType[$row->getLinkType()];
				$linkTypeString = LookupValuePeer::getLookupValue('UNI4XX', $linkType);
			}
			
			if (!$manifestation instanceof Manifestation)
				continue;
			
			$title = $manifestation->getTitle();
			$author = trim($manifestation->getAuthor());
			
			if ($author != '')
				$title = "{$author}. {$title}";
			
			$issue = $row->getIssue();
			$lManifestations[] = array(	'manifestationId' => $manifestation->getManifestationId(),
										'manifestationTitle' => $title,
										'linkTypeString' => $linkTypeString,
										'linkSequence' => $row->getLinkSequence(),
										'linkNote' => $row->getLinkNote(),
				
										'issueId' => ($issue instanceof Issue) ? $issue->getIssueId() : 0,
										'issueTitle' => ($issue instanceof Issue) ? $issue->getIssueCombo(false) : '',
										'sourceSync' => $row->getSourceSync() );
			
			if ($issue instanceof Issue)
			{
				$issue->clearAllReferences(true);
				unset($issue);
			}
			
			$manifestation->clearAllReferences(true);
			unset($manifestation);
		}

		$this->LManifestations->setDataSource($lManifestations);
		$this->LManifestations->dataBind();

		$this->AttachList->setObjectClass("Manifestation");
		$this->AttachList->setObjectId($this->_manifestation->getManifestationId());

		$this->SBNPanel->setVisible($this->_sbnMod->getEnabled()
										&& ($this->_manifestation instanceof Manifestation)
										&& !$this->_manifestation->isNew());
		
		// basins part
		if ($this->_llibraryActive)
		{
			$this->AvailableItemsPanel->setCssClass('panel_on');
			$this->AvailableItems->setManifestationId($this->_manifestation->getManifestationId());
			$this->AvailableItems->globalRefresh();
		}
		else
		{
			$this->AvailableItemsPanel->setCssClass('panel_off');
		}
		
		// discarded check part
		$this->DiscardedTeleportButton->setVisible($this->_manifestation->countDiscardedItems() > 0);
				
	}	// end of populate()

	private function decodeWorkAuthorities($workAuthoritiesArray = array())
	{
		$output = array();

		foreach ($workAuthoritiesArray as $workId => $linkedAuthorityRows)
		{
			foreach ($linkedAuthorityRows as $linkedAuthorityRow)
			{
				foreach ($linkedAuthorityRow as $row)
				{
					$values = array(	'AuthorityId' => $row['AuthorityId'],
										'AuthClass' => $row['AuthClass'],
										'PrimaryKey' => $row['PrimaryKey'],
										'SortText' => $row['SortText'],
										'FullText' => $row['FullText'],
										'RelatorCode' => $row['RelatorCode'],
										'RelatorCodeIndex' => $row['RelatorCodeIndex'],
										'LinkType' => $row['LinkType'],
										'LinkTypeLabel' => $row['LinkTypeLabel'],
										'LinkSequence' => $row['LinkSequence'],
										'LinkNote' => $row['LinkNote'],
										'Mutual' => $row['Mutual'] );

					//////// da riempire con casi di linktype che mi deve dare la Camilla
					
					switch ($row['LinkType'])
					{
						case 'AB':
						case 'CD':
						case 'EF':
							$output['author'][$workId][] = $values;
							break;
							
						
						case 'GH':
						case 'HG':	
							$output['subject'][$workId][] = $values;
							break;
						
						case 'IJ':
							$output['altSubject'][$workId][] = $values;
							break;
							
						case 'PK':
							$output['keywords'][$workId][] = $values;
							break;

                        case 'KP':
                            //case 'KP': // Forse non ci serve
                            $output['iskeywords'][$workId][] = $values;
                            break;

						/*
						case 'OP':
							$output['place'][$workId][] = $values;
							break;
						 */
							
						case 'KL':
							$output['classes'][$workId][] = $values;
							break;
						
						//case '1X0':
						//case '0X1':
						case 'HXG':
						case '4X5':
						case '8X8':
						case 'JXI':
						case 'LXK':
						case '5X4':
						case '6X7':
						case '7X6':
						case 'AXA':
						case 'EXF':
						case 'FXE':
						case 'GXH':
						case 'HXG':
						case 'IXJ':
						case 'KXL':
							$output['linkedWorks'][$workId][] = $values;
							break;
					}
				}
			}
		}

		return $output;
	}
	
	/**
	 * It takes the values from the fields in the page and puts
	 * them in the manifestation object of the page, and then
	 * saves it on database.
	 * Then it jumps to this same page, and passes by post the
	 * id of the manifestation we just committed, so to view it.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onModify($sender, $param)
	{
		$this->gotoPage(	'Catalog.EditRecord', 
							array('manifestationId' => $this->_manifestation->getManifestationId()));
	}

	public function onAddItem($sender, $param)
	{
		$this->gotoPage(	'Catalog.ItemInsertPage', 
							array('manifestationId' => $this->_manifestation->getManifestationId()));
	}

	public function onAddIssue($sender, $param)
	{
		$this->gotoPage(	'Catalog.IssueInsertPage', 
							array('manifestationId' => $this->_manifestation->getManifestationId()));
	}

	public function onAddSubscription($sender, $param)
	{
		$this->gotoPage(	'Acquisition.SubscriptionInsertPage', 
							array('manifestationId' => $this->_manifestation->getManifestationId()));
	}

	public function onGotoBulk($sender, $param)
	{
		$manifestationId = intval($this->getManifestationId());
		if ($manifestationId > 0)
			$this->gotoPage(	"Catalog.ItemInsertBulkPage",
								array("manId" => $manifestationId));
	}
	
	public function onGotoDiscarded($sender, $param)
	{
		$manifestationId = intval($this->getManifestationId());
		
		if ($manifestationId > 0)
			$this->gotoPage(	"Catalog.ItemListPage",
								array(	"manifestationId" => $manifestationId,
										"itemStatus" => ItemStatus::ITEMSTATUS_DISCARDED));
	}
	
	/**
	 * @return boolean
	 */
	public function isPopup()
	{
		return false;
	}

	/**
	 * It performs a cancellation of the loan of the item passed
	 * by id.
	 *
	 * NB: it could be partially incomplete.
	 *
	 * @param int $itemId
	 */
	public function resetLoan($itemId)
	{
		if (is_numeric($itemId)
				&& ($itemId > 0))
		{
			$item = ItemQuery::create()->findPk($itemId);
			
			if ($item instanceof Item)
			{
				$item->unLoan();
				$this->_manifestation->forceReloadItems();
				$this->globalRefresh();
			}
		}
	}

	public function renewLoan($itemId) 
	{
		if (is_numeric($itemId)
				&& ($itemId > 0))
		{
			$item = ItemQuery::create()->findPk($itemId);
			
			if ($item instanceof Item)
			{
				$item->renewLoan();
				$this->_manifestation->forceReloadItems();
				$this->globalRefresh();
			}
		}
	}

	public function abortLoan($itemId) 
	{
		if (is_numeric($itemId)
				&& ($itemId > 0))
		{
			$item = ItemQuery::create()->findPk($itemId);
			
			if ($item instanceof Item)
			{
				$item->abortLoan();
				$this->_manifestation->forceReloadItems();
				$this->globalRefresh();
			}
		}
	}

	/**
	 * It refreshes all the components (grids) in the page,
	 * altogether.
	 *
	 */
	public function globalRefresh() 
	{
		$this->ItemListMine->populate();
		$this->ItemListOther->populate();

		if ($this->_manifestation->getBibLevel() == ManifestationPeer::LVL_SERIAL) 
			$this->IssueList->populate();
		
		$this->ItemRequests->populate();
		if ($this->getIsCallback())
			$this->ItemRequestsPanel->render($this->createWriter());
		/// da finire $this->Requests->populate();
		
		$this->ShelfList->populate();
	}

	public function globalCancel($component)
	{
		if ($component !== $this->ShelfList)
			$this->ShelfList->onCancel(null, null);
	}

	public function onOpenReservePanel($sender, $param)
	{
		$this->setExtraMode(false);
		$this->ExtraModeCheck->setChecked(false);

		$this->PanelReserve->setCssClass("panel_on");
		
		if ($this->getPage()->getIsCallBack())
		{
			if (is_null($param))
			{
				$this->PanelReserve->render($this->getPage()->createWriter());
			}
			else
			{
				$this->PanelReserve->render($param->getNewWriter());
			}

			$this->ReserveDeliveryLibrary->setDataSource(LibraryPeer::getLibrariesHash(	null,
																						null, 
																						true, 
																						true ));  // only active libraries
			
			$this->ReserveDeliveryLibrary->dataBind();
			$this->ReserveDeliveryLibrary->setSelectedValue($this->getUser()->getActualLibraryId());
			$this->populateMaxDistance($this->_manifestation, $this->getUser()->getActualLibraryId());
			
			if ($this->_requestTypeActive)
			{	
				$this->RequestTypeList->setDataSource(ItemRequestPeer::getRequestTypes(true));	// with blank
				$this->RequestTypeList->dataBind();
			}
		}

		$this->writeMessage(Prado::localize("Pannello delle prenotazioni aperto"),
								ClavisMessage::INFO);
		
		$this->getPage()->setFocus("anchor_reserve");
	}

	private function populateMaxDistance($manifestation, $deliveryLibraryId)
	{
		// if basin system is active
		if ($this->_llibraryActive)
		{
			$this->MaxDistancePanel->setCssClass('panel_on');
			
			$distances = LLibraryPeer::calculateRequestDistances(false);
			if (count($distances) > 0)	// there are results
			{
				$this->MaxDistance->setCssClass('panel_on_inline');
				$this->MaxDistanceNoResult->setCssClass('panel_off');
				
				$this->MaxDistance->setDataSource($distances);
				$this->MaxDistance->dataBind();

				$minDistance = $this->_requestmanager->calculateMinRequestDistance($manifestation, $deliveryLibraryId);
				if (!is_null($minDistance))
				{
					if (array_key_exists($minDistance, $distances))
					{
						$selectedDistance = $minDistance;
					}
					else 
					{
						$selectedDistance = 0;
					}

					$this->MaxDistance->setSelectedValue($selectedDistance);
				}
				else	// no results
				{
					$this->MaxDistance->setCssClass('panel_off');
					$this->MaxDistanceNoResult->setCssClass('labelError');
				}
			}
			else	// no results
			{
				$this->MaxDistance->setCssClass('panel_off');
				$this->MaxDistanceNoResult->setCssClass('labelError');
			}
		}
		else	// basin system is not active
		{
			$this->MaxDistancePanel->setCssClass('panel_off');
		}
		
		if ($this->getPage()->getIsCallback())
			$this->MaxDistancePanel->render($this->getPage()->createWriter());
	}
	
	public function getPatron() 
	{
		$patron = null;
		$patronId = intval($this->ReserveHiddenValue->getValue());
		
		if ($patronId > 0)
		{
			$patron_id = $patronId;
		}
		else
		{
			$patron_id = intval($this->ReservePatronId->getSafeText());
		}

		if ($patron_id > 0)
			$patron = PatronQuery::create()	->findPk($patron_id);

		return $patron;
	}

	public function getExternalLibraryId()
	{
		$libraryId = intval($this->ReserveHiddenValue2->getValue());
		
		if ($libraryId > 0)
		{
			$library_id = $libraryId;
		}
		else
		{
			$library_id = intval($this->ReserveExternalLibraryId->getSafeText());
		}

		return intval($library_id);
	}

	public function getExternalLibrary()
	{
		$library = null;
		$libraryId = $this->getExternalLibraryId();

		if ($libraryId > 0)
			$library = LibraryQuery::create()->findPk($libraryId);

		return $library;
	}

	public function onReserveManifestation($sender, $param) 
	{
		$this->cleanMessageQueue();

		$manifestation = $this->_manifestation;
		$patron = $this->getPatron();
		$externalLibrary = $this->getExternalLibrary();
		$extraMode = $this->getExtraMode();

		if (!$extraMode
				&& !($patron instanceof Patron))
		{
			$this->enqueueMessage(Prado::localize("Errore sul passaggio parametri dell'utente. Segnalare al fornitore del software"),
									ClavisMessage::ERROR);
		}
		elseif ($extraMode
					&& !($externalLibrary instanceof Library))
		{
			$this->enqueueMessage(Prado::localize("Errore sul passaggio parametri della biblioteca esterna. Segnalare al fornitore del software"),
									ClavisMessage::ERROR);
		}
		else
		{
			$clavisLibrarian = $this->getUser();
			$deliveryLibrary = LibraryQuery::create()
									->findPk($this->ReserveDeliveryLibrary->getSelectedValue());
			
			$request_note = $this->RequestNote->getSafeText();
			
			if ($this->MaxDistanceNoResult->getCssClass() == 'labelError')
			{
				$maxDistanceData = LLibraryPeer::getMaxLLibraryDistance();
			}
			else
			{
				$maxDistanceData = $this->MaxDistance->getSelectedValue();
			}
			
			$maxDistance = ($this->_llibraryActive && !$this->getExtraMode()
									? $maxDistanceData
									: null );

			$requestType = null;
		
			if ($this->_requestTypeActive)
			{
				if ($this->RequestTypeList->getSelectedIndex() > 0)
					$requestType = $this->RequestTypeList->getSelectedValue();
			}
		
			$returnVal = $this->_requestmanager->reserveManifestation(	$manifestation, 
																		$patron, 
																		$deliveryLibrary, 
																		$clavisLibrarian, 
																		$request_note, 
					
																		null, 
																		$this->getExternalLibraryId(),
																		$maxDistance,
																		$requestType);

			if (($returnVal == ClavisLoanManager::OK)
					|| ($returnVal == ClavisLoanManager::RSV_NOTAVAIL))
			{
				if (!$extraMode)
				{
					$this->enqueueMessage(Prado::localize("Notizia prenotata: '{title}' {type}[id: {id}] per l'utente {patronName}",
															array(	'title' => $manifestation->getTrimmedTitle(40),
																	'type' => is_null($requestType) ? '' : '<b>[' . ItemRequestPeer::getRequestTypeString($requestType) . ']</b>&nbsp;',
																	'id' => $manifestation->getManifestationId(),
																	'patronName' => $patron->getCompleteName() )),
											ClavisMessage::CONFIRM);
				}
				else
				{
					$this->enqueueMessage(Prado::localize("Notizia prenotata: '{title}' {type}[id: {id}] per la biblioteca esterna {library} [{consortia}]",
															array(	'title' => $manifestation->getTrimmedTitle(40),
																	'type' => is_null($requestType) ? '' : '<b>[' . ItemRequestPeer::getRequestTypeString($requestType) . ']</b>&nbsp;',
																	'id' => $manifestation->getManifestationId(),
																	'library' => $externalLibrary->getLabel(),
																	'consortia' => $externalLibrary->getConsortiaString(30) )),
											ClavisMessage::CONFIRM);
				}
				
				if ($manifestation->getLoanableSince('U') > time())
					$this->enqueueMessage(Prado::localize('La notizia è disponibile solo dal {date}',
															array('date' => Clavis::dateFormat($manifestation->getLoanableSince('U')))),
											ClavisMessage::WARNING);

				if (!$this->_loanmanager->IsRatingAllowed($manifestation, $patron))
					$this->enqueueMessage(Prado::localize("La notizia è disponibile solo per gli utenti con più di {rating} anni",
															array('rating' => $manifestation->getRating())),
											ClavisMessage::WARNING);

				if ($returnVal == ClavisLoanManager::RSV_NOTAVAIL)
					$this->enqueueMessage(Prado::localize("Attenzione: al momento nessun esemplare è in grado di soddisfare la prenotazione"),
											ClavisMessage::WARNING);

				//cleaning and closing ......
				$this->ReserveHiddenValue->setValue('');
				$this->ReserveHiddenValue2->setValue('');
				
				$this->ReservePatronId->setText('');
				$this->PatronId->setText('');
				$this->ExternalLibraryId->setText('');
				$this->ReserveExternalLibraryId->setText('');

				$this->ReservePatronLabel->setText('');
				$this->ReserveExternalLibraryLabel->setText('');

				$this->UserData->populate(-1);
				$this->CirculationData->setPatronId(null);
				$this->CirculationData->populate(null);
				$this->LibraryData->populate(null);
				
				$this->DoReserve->setEnabled(false);

				$manifestation = ManifestationQuery::create()->findPK($manifestation->getManifestationId());	// it seems to be a form of reloading ...
				
				$this->ItemRequests->setObject($manifestation);
				$this->ItemRequests->globalRefresh();
				if ($this->getIsCallback())
					$this->ItemRequestsPanel->render($param->getNewWriter());
				
				/// da finire $this->Requests->setObject($manifestation);
				/// da finire $this->Requests->globalRefresh();
				
				$this->PanelReserve->setCssClass("panel_off");

				if ($this->getIsCallback())
				{
					if (is_null($param))
					{
						$this->PanelReserve->render($this->getPage()->createWriter());
						/// da finire $this->RequestsPanel->render($this->getPage()->createWriter());
					} 
					else 
					{
						$this->PanelReserve->render($param->getNewWriter());
						/// da finire $this->RequestsPanel->render($param->getNewWriter());
					}
				}
			}
			else
			{
				$this->enqueueMessage(Prado::localize("Prenotazione fallita"),
										ClavisMessage::ERROR);
			}
		}

		$this->flushMessage();
	}

	public function onPatronIdChanged($sender, $param)
	{
		$patron = $this->getPatron();
		
		if (!($patron instanceof Patron))
			return;
	
		$this->insertPatron($patron->getPatronId());
	}

	public function onExternalLibraryIdChanged($sender, $param)
	{
		$library = $this->getExternalLibrary();
		
		if (is_null($library))
			return;

		$this->insertExternalLibrary($library->getLibraryId());
	}

	public function suggestPatron($sender, $param)
	{
		$token = $param->getCallBackParameter(); //the partial word to match
		$sender->setDataSource(PatronPeer::doSuggest($token, 10, true, true)); //set suggestions
		$sender->dataBind(false);
	}

	public function suggestLibrary($sender, $param)
	{
		$token = $param->getCallBackParameter();
		$sender->setDataSource($this->getLibrarySuggestionsFor($token));
		$sender->dataBind(false);
	}

	/**
	 * Ajax callback which makes some action after the string in the
	 * autocomplete textbox has been choosen.
	 * In particular, it populates some labels with patron's data.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function suggestPatronCallBack($sender, $param)
	{
		$resultFlag = false;
		$fieldText = trim($this->ReservePatronLabel->getSafeText());
		$match = array();
	
		if (preg_match("/\(([^\)]+)\)$/", $fieldText, $match))
		{
			$patronBarcode = $match[1];
		}
		else
		{	
			$patronBarcode = $fieldText;
		}

		$patrons = PatronPeer::getPatronsByBarcode($patronBarcode);
		
		if (!empty($patrons))
		{
			$patron = $patrons->shift();
			if ($patron instanceof Patron)
			{
				$patronId = $patron->getPatronId();
				$resultFlag = $this->insertPatron($patronId);
			}
			
			if (!empty($patrons))
			{
				// TODO: notifica di barcodes utente duplicati
			}
		}

		if ($resultFlag)
			$this->ReservePatronLabel->setText('');
	}

	public function suggestLibraryCallBack($sender, $param)
	{
		$resultFlag = false;
		$fieldText = $this->ReserveExternalLibraryLabel->getSafeText();
		$match = array();

		if (preg_match("/\[id:\ ([^\]]+)\]$/", $fieldText, $match))
		{
			$libraryId = $match[1];
		}
		else
		{
			$libraryId = $fieldText;
		}

		$libraryId = intval($libraryId);
		$library = LibraryQuery::create()->findPk($libraryId);

		if ($library instanceof Library)
			$resultFlag = $this->insertExternalLibrary($libraryId, $param);

		if ($resultFlag)
			$this->ReserveExternalLibraryLabel->setText('');
	}

	private function getLibrarySuggestionsFor($token)
	{
		$list = array();
		$criteria = new Criteria();
		$token = trim($token);

		if ($token != "")
		{
			$criteria->add(LibraryPeer::LABEL, "%" . $token . "%", Criteria::LIKE);
			$criteria->add(LibraryPeer::LIBRARY_INTERNAL, 1, Criteria::NOT_EQUAL);

			$criteria->setLimit(10);
			$criteria->addAscendingOrderByColumn(LibraryPeer::LABEL);
			$libraries = LibraryPeer::doSelect($criteria);

			foreach ($libraries as $library)
				$list[] = $library->getLabel() . " (" . $library->getConsortiaString(20) . ") [id: " . $library->getLibraryId() . "]";
		}

		return $list;
	}

	public function insertPatron($patronId)
	{
		$this->cleanMessageQueue();
		$returnValue = false;

		$reserveDeliveryLibraryId = intval($this->ReserveDeliveryLibrary->getSelectedValue());
		$returnFlag = $this->UserData->populate($patronId);

		$this->UserDataPanel->setVisible($returnFlag);
		$this->CirculationData->populate($patronId);

		$patron = PatronQuery::create()	->findPk($patronId);
		
		$barcode = $patron->getBarcode();
		$this->PatronId->setText($patronId);
		$this->ReservePatronLabel->setText($patron->getReverseCompleteName() . ' (' . $barcode . ')');
		$this->ReservePatronId->setText($patronId);

		if ($returnFlag)
		{
			$this->calculateReservable();
			$returnValue = true;
		}
		else
		{
			$this->enqueueMessage(Prado::localize('Errore di formato'),
					ClavisMessage::ERROR);
			
			$this->getPage()->setFocus($this->ReservePatronLabel->getClientID());
			$this->DoReserve->setEnabled(false);
		}

		$this->flushMessage();

		return $returnValue;
	}

	public function insertExternalLibrary($libraryId, $param = null)
	{
		$libraryId = intval($libraryId);
		$returnFlag = true;
		$this->LibraryData->populate($libraryId);								/////   (da implementare un clavislibrarydatacard)
		$returnFlag = ($this->LibraryData->Populated->getValue() == 'true'
							? true
							: false);

		$this->LibraryDataPanel->setCssClass($returnFlag
												? 'panel_on'
												: 'panel_off');
		
		$this->LibraryData->setVisible($returnFlag);

		if ($this->getPage()->getIsCallBack())
		{
			if (is_null($param))
			{
				$writer = $this->getPage()->createWriter();
			}
			else
			{
				$writer = $param->getNewWriter();
			}

			$this->LibraryDataPanel->render($writer);
		}

		$library = LibraryQuery::create()->findPK($libraryId);
		
		if ($library instanceof Library)
		{
			$label = $library->getLabel() . ' (' . $libraryId . ')';
		}
		else
		{
			$label = '';
		}

		$this->ExternalLibraryId->setText($libraryId);
		$this->ReserveExternalLibraryLabel->setText($label);
		$this->ReserveExternalLibraryId->setText($libraryId);

		if ($returnFlag) 
		{
			$verifyCode = $this->_requestmanager->isManifestationReservable($this->_manifestation);
		
			if ($verifyCode == ClavisLoanManager::OK) 
			{
				$this->DoReserve->setEnabled(true);
				$this->getPage()->setFocus($this->DoReserve->getClientID());
			}
			else
			{
				$this->DoReserve->setEnabled(false);

				switch ($verifyCode)
				{
					case ClavisLoanManager::RSV_NOTAVAIL:
						$message = Prado::localize("Notizia non prenotabile");
						break;

					case ClavisLoanManager::RSV_PATRONREQMANIF:
						$message = Prado::localize("Notizia già prenotata dall'utente");
						break;

					case ClavisLoanManager::RSV_PATRONMAXREQ:
						$message = Prado::localize("L'utente ha già raggiunto il numero massimo di prenotazioni consentite");
						break;

					case ClavisLoanManager::RSV_RATING:
						$message = Prado::localize("Prenotazione non possibile perchè utente minore dell'età consentita dal titolo");
						break;

					default:
						$message = Prado::localize("Errore generico");
				}
				
				$this->writeMessage($message,
										ClavisMessage::ERROR);
			}

			return true;
			
		}
		else
		{
			$this->getPage()->setFocus($this->ReserveExternalLibraryLabel->getClientID());
			$this->DoReserve->setEnabled(false);

			return false;
		}
	}

	public function onDuplicateRecord($sender, $param)
	{
		if ($this->_manifestation instanceof Manifestation)
		{
			try
			{
				$newManif = $this->_manifestation->duplicate($this->getUser()->getId());
			}
			catch (Exception $e)
			{
				$error = $e->getMessage();
				$newManif = null;
			}
			
			if ($newManif instanceof Manifestation)
			{
				$this->writeMessage(Prado::localize('Duplicata notizia con id: {srcId} su nuova notizia con id: {newId}',
														array(	'srcId' => $this->_manifestation->getManifestationId(),
																'newId' => $newManif->getManifestationId() )),
										ClavisMessage::CONFIRM);
				
				$this->gotoPage('Catalog.EditRecord', 
									array('manifestationId' => $newManif->getManifestationId()));
			}
			else
			{
				$this->writeMessage(Prado::localize('Errore nella duplicazione della notizia: {error}',
														array('error' => $error)),
										ClavisMessage::ERROR);
				
				$this->reloadPage();
			}
		}
		else
		{
			$this->writeMessage(Prado::localize('La duplicazione della notizia non è possibile'),
									ClavisMessage::ERROR);
			
			$this->reloadPage();
		}
	}

	public function onCloneIssuesFromYear($sender, $param)
	{
		if ((!is_null($this->_manifestation))
				&& ($this->_manifestation->getBibLevel() == 's')
				&& ($this->getUser()->checkAllowedPage('Catalog.IssueInsertPage')))
		{
			$manifestation_id = $this->_manifestation->getManifestationId();
			$starting_number = $this->StartingNumber->getSafeText();
			if (($starting_number == '')
					|| (!is_numeric($starting_number)))
			{
				$this->writeMessage(Prado::localize('Inserire un valore numerico per la numerazione iniziale'),
										ClavisMessage::ERROR);
				
				return;
			}

			$criteria = new Criteria();

			//controlla max numero assegnato
			$criteria->add(IssuePeer::MANIFESTATION_ID, $manifestation_id);
			$criteria->clearSelectColumns();
			$criteria->addSelectColumn("MAX(" . IssuePeer::END_NUMBER . ")");

			$rs = IssuePeer::doSelectStmt($criteria);
			$max_number = -1;
			while ($val = $rs->fetchColumn(0))
			{
				$max_number = (intval($val));
			
				break;
			}

			if ($starting_number <= $max_number)
			{
				$this->writeMessage(Prado::localize('Inserire una numerazione iniziale maggiore di {max_number}',
														array('max_number' => $max_number)),
										ClavisMessage::ERROR);
			
				return;
			}
			
			//seleziona anno
			$criteria->clear();
			$criteria->clearSelectColumns();
			$criteria->addSelectColumn('MAX(' . IssuePeer::ISSUE_YEAR . ')');
			$criteria->add(IssuePeer::MANIFESTATION_ID, $manifestation_id);

			$rs = IssuePeer::doSelectStmt($criteria);
			$max_year = -1;
			while ($val = $rs->fetchColumn(0))
			{
				$max_year = (intval($val));
			
				break;
			}

			$new_year = $max_year + 1;
			$retValue = IssuePeer::duplicateVolume(	$this->_manifestation,
													$max_year,
													$new_year,
													$starting_number,
													null,

													$this->getUser());

			if ($retValue === false)
			{
				$this->writeMessage(Prado::localize('errore nella creazione dei fascicoli per l\'annata {newYear}',
														array('newYear' => $new_year)),
										ClavisMessage::ERROR);

				$this->reloadPage();
			}
			else
			{
				ChangelogPeer::logAction(	$this->_manifestation,
											ChangelogPeer::LOG_UPDATE,
											$this->getUser(),
											"creati {$retValue} fascicoli per l'annata {$new_year}");
											
				$this->writeMessage(Prado::localize('Creati {numIssue} fascicoli per l\'annata {volume} della notizia con id: {manId}',
														array(	'numIssue' => $retValue,
																'volume' => $new_year,
																'manId' => $manifestation_id)),
						
										ClavisMessage::INFO);

				$this->reloadPage();
			}
		}
		else
		{
			$this->writeMessage(Prado::localize('La duplicazione dei fascicoli non è possibile'),
									ClavisMessage::ERROR);
			
			$this->reloadPage();
		}
	}

	public function onGenerateIssues($sender, $param)
	{
		if ((!is_null($this->_manifestation))
				&& ($this->_manifestation->getBibLevel() == 's')
				&& ($this->getUser()->checkAllowedPage('Catalog.IssueInsertPage'))) 
		{
			$manifestation_id = $this->_manifestation->getManifestationId();

			$year = $this->IssuesYear->getSafeText();
			$starting_number = $this->StartingNumber->getSafeText();
			$how_many_issues = $this->HowManyIssues->getSafeText();
			$start_date = $this->StartDate->getTimestamp();
			$end_date = $this->EndDate->getTimestamp();

			//controlli
			$criteria = new Criteria();

			//controlla anno
			if (($year == '')
					|| (!is_numeric($year)))
			{
				$this->writeMessage(Prado::localize('Inserire un valore numerico per l\'annata'),
										ClavisMessage::ERROR);
				
				return;
			}

			//seleziona anno
			$criteria->clear();
			$criteria->clearSelectColumns();
			$criteria->addSelectColumn('MAX(' . IssuePeer::ISSUE_YEAR . ')');
			$criteria->add(IssuePeer::MANIFESTATION_ID, $manifestation_id);

			$rs = IssuePeer::doSelectStmt($criteria);
			$max_year = -1;
			while ($val = $rs->fetchColumn(0)) 
			{
				$max_year = (intval($val));
			
				break;
			}

			if ($year <= $max_year)
			{
				$this->writeMessage(Prado::localize('Inserire un\'annata maggiore di {max_year}',
										array('max_year' => $max_year)),
						
									ClavisMessage::ERROR);
			
				return;
			}

			//controlla starting_number
			if (($starting_number == '')
					|| (!is_numeric($starting_number)))
			{
				$this->writeMessage(Prado::localize('Inserire un valore numerico per la numerazione iniziale'),
										ClavisMessage::ERROR);
				
				return;
			}

			$criteria->clearSelectColumns();
			$criteria->add(IssuePeer::MANIFESTATION_ID, $manifestation_id);
			$criteria->addSelectColumn("MAX(" . IssuePeer::END_NUMBER . ")");

			$rs = IssuePeer::doSelectStmt($criteria);
			$max_number = -1;
			while ($val = $rs->fetchColumn(0))
			{
				$max_number = (intval($val));
			
				break;
			}

			if ($starting_number <= $max_number)
			{
				$this->writeMessage(Prado::localize('Inserire una numerazione iniziale maggiore di {max_number}',
														array('max_number' => $max_number)),
										ClavisMessage::ERROR);
			
				return;
			}

			//controlla how_many_issues
			if (($how_many_issues == '')
					|| (!is_numeric($how_many_issues)))
			{
				$this->writeMessage(Prado::localize('inserire un valore numerico maggiore di zero per il numero di fascicoli'),
										ClavisMessage::ERROR);
				
				return;
			}

			//controlla start_date
			$criteria->clear();
			$criteria->clearSelectColumns();
			$criteria->add(IssuePeer::MANIFESTATION_ID, $manifestation_id);
			//$criteria->add(IssuePeer::ISSUE_YEAR, $year);
			$criteria->addSelectColumn("MAX(" . IssuePeer::ISSUE_DATE . ")");

			$rs = IssuePeer::doSelectStmt($criteria);
			$max_start_date = -1;
			while ($val = $rs->fetchColumn(0))
			{
				$max_start_date = $val;
			
				break;
			}

			if ($start_date == null)
			{
				$this->writeMessage(Prado::localize('Inserire una data iniziale'),
										ClavisMessage::ERROR);
				
				return;
			}

			if (($max_start_date == '')
					|| ($start_date <= strtotime($max_start_date)))
			{
				$this->writeMessage(Prado::localize('Inserire una data iniziale maggiore di {max_start_date}',
														array('max_start_date' => $max_start_date)),
										ClavisMessage::ERROR);
				
				return;
			}

			if ($end_date == null)
			{
				$this->writeMessage(Prado::localize('Inserire una data finale maggiore di {start_date}',
														array('start_date' => $start_date)),
										ClavisMessage::ERROR);
				
				return;
			}

			//controlla end_date
			if ($end_date < $start_date)
			{
				$this->writeMessage(Prado::localize('Inserire una data iniziale maggiore di {max_start_date}',
														array('max_start_date' => $max_start_date)),
										ClavisMessage::ERROR);
				
				return;
			}

			//do insert
			$retValue = IssuePeer::createForManifestation(	$this->_manifestation,
																$year,
																$how_many_issues,
																$starting_number,
																$start_date,
					
																$end_date,
																$this->getUser());

			if ($retValue === false)
			{
				$this->writeMessage(Prado::localize('Errore nella creazione dei fascicoli'),
										ClavisMessage::ERROR);
				
				$this->reloadPage();
			}
			else
			{
				ChangelogPeer::logAction(	$this->_manifestation,
											ChangelogPeer::LOG_UPDATE,
											$this->getUser(),
											"creati {$retValue} fascicoli");
											
				$this->writeMessage(Prado::localize('Creati {count} fascicoli della notizia con id: {manifestation_id}',
														array(	'count' => $retValue,
																'manifestation_id' => $manifestation_id) ),
										ClavisMessage::INFO);
				
				$this->reloadPage();
			}
		}
		else
		{
			$this->writeMessage(Prado::localize('La duplicazione dei fascicoli non è possibile'),
									ClavisMessage::ERROR);
			
			$this->reloadPage();
		}
	}

	/**
	 * User by the 'add to shelf' in the lower right part of screen.
	 *
	 */
	public function onAddToShelf($sender, $param)
	{
		$shelfId = $this->ToShelf->getSelectedValue();
		$this->getUser()->setActualShelfId(intval($shelfId));
		$this->doAddToShelf($shelfId);
	}

	/**
	 * Adds this record to a shelf (taken from a popup list).
	 *
	 */
	public function onAddToShelf1($sender, $param)
	{
		$shelfId = intval($this->ShelfResultValue->getValue());
		$this->doAddToShelf($shelfId);
	}

	private function doAddToShelf($shelfId)
	{
		$shelf = null;
		$result = false;

		if ($shelfId > 0)
			$shelf = ShelfQuery::create()->findPK($shelfId);

		$manifestation = $this->_manifestation;
		
		if (!is_null($manifestation)
				&& ($manifestation instanceof Manifestation))
			$manifestationId = intval($manifestation->getManifestationId());

		if (($shelf instanceof Shelf)
				&& (intval($manifestationId) > 0))
			$result = $shelf->addItemToShelf(shelfpeer::TYPE_MANIFESTATION, $manifestationId);

		if ($result)
		{
			$this->getPage()->globalRefresh();
			$this->writeMessage(Prado::localize("Notizia aggiunta allo scaffale '{shelfname}'",
													array('shelfname' => $shelf->getShelfName())),
									ClavisMessage::CONFIRM);
		}
		else
		{
			$this->writeMessage(Prado::localize('Notizia non aggiunta a scaffale'),
									ClavisMessage::ERROR);
		}
	}

	public function onAddItemsToShelf1($sender, $param)
	{
		$shelfId = intval($this->ShelfResultValueItem1->getValue());
		$this->ShelfResultValueItem1->setValue('');

		$checkedId = $this->ItemListMine->getCheckedId(true);
		$this->ItemListMine->resetCheckedItems();

		$this->doAddItemsToShelf($shelfId, $checkedId, $param);
	}

	public function onAddItemsToShelf2($sender, $param)
	{
		$shelfId = intval($this->ShelfResultValueItem2->getValue());
		$this->ShelfResultValueItem2->setValue('');

		$checkedId = $this->ItemListOther->getCheckedId(true);
		$this->ItemListOther->resetCheckedItems();

		$this->doAddItemsToShelf($shelfId, $checkedId, $param);
	}

	public function onAddIssuesToShelf($sender, $param)
	{
		$shelfId = intval($this->ShelfResultValueIssue->getValue());
		$this->ShelfResultValueIssue->setValue('');

		$checkedId = $this->IssueList->getCheckedId();   // don't believe it's correct to autoselect every issue, by puttin 'true'
		$this->IssueList->resetChecked();

		$this->doAddIssuesToShelf($shelfId, $checkedId, $param);
	}
	
	private function doAddItemsToShelf(	$shelfId = null,
										$checkedId = array(),
										$param)
	{
		$this->getPage()->cleanMessageQueue();

		$shelfId = intval($shelfId);
		
		if ($shelfId > 0) 
		{
			$shelf = ShelfQuery::create()->findPK($shelfId);
			
			if ($shelf instanceof Shelf) 
			{
				$ok = $shelf->addItemToShelf('item', $checkedId);
				$failed = count($checkedId) - $ok;

				$this->getPage()->enqueueMessage(Prado::localize("{ok} esemplari aggiunti allo scaffale {shelf}",
																	array(	'ok' => $ok,
																			'shelf' => $shelf->getShelfCompleteName() )),
													ClavisMessage::CONFIRM);

				if ($failed > 0)
					$this->getPage()->enqueueMessage(Prado::localize("{failed} esemplari non aggiunti allo scaffale {shelf}",
																		array(	'failed' => $failed,
																				'shelf' => $shelf->getShelfCompleteName() )),
														ClavisMessage::ERROR);

				$this->ItemListMine->populate();
				$this->ItemListOther->populate();
			}
		}
		else
		{
			$this->getPage()->enqueueMessage(Prado::localize("Errore nel passaggio dei parametri. Segnalare al fornitore del software."),
																ClavisMessage::ERROR);
		}

		$this->getPage()->flushMessage();
	}

	private function doAddIssuesToShelf(	$shelfId = null,
											$checkedId = array(),
											$param)
	{
		$this->getPage()->cleanMessageQueue();

		$shelfId = intval($shelfId);
		
		if ($shelfId > 0) 
		{
			$shelf = ShelfQuery::create()->findPK($shelfId);
			
			if ($shelf instanceof Shelf) 
			{
				$ok = $shelf->addItemToShelf('issue', $checkedId);
				$failed = count($checkedId) - $ok;

				$this->getPage()->enqueueMessage(Prado::localize("{ok} fascicoli aggiunti allo scaffale {shelf}",
																	array(	'ok' => $ok,
																			'shelf' => $shelf->getShelfCompleteName() )),
													ClavisMessage::CONFIRM);

				if ($failed > 0)
					$this->getPage()->enqueueMessage(Prado::localize("{failed} fascicoli non aggiunti allo scaffale {shelf}",
																		array(	'failed' => $failed,
																				'shelf' => $shelf->getShelfCompleteName() )),
														ClavisMessage::ERROR);

				$this->IssueList->populate();
				$this->IssueList->populate();
			}
		}
		else
		{
			$this->getPage()->enqueueMessage(Prado::localize("Errore nel passaggio dei parametri. Segnalare al fornitore del software."),
																ClavisMessage::ERROR);
		}

		$this->getPage()->flushMessage();
	}
	
	public function onEraseRecord($sender, $param)
	{
		$this->getPage()->cleanMessageQueue();
		
		if (!is_null($this->_manifestation)		// for super-sureness super-sayan
				&& ($this->_manifestation instanceof Manifestation))
		{
			try
			{
				$manifestationId = $this->_manifestation->getManifestationId();
				$manifestationTitle = $this->_manifestation->getTitle();
				
				/**
				 * This manifestation's items unlinking logic (they should be all discarded ones).
				 * They need to become OOC items.
				 */
				$countItemModified = 0;
				$allItems = $this->_manifestation->getItems();
				
				$criteria = new Criteria;
				$criteria->add(ItemPeer::ITEM_STATUS, ItemStatus::ITEMSTATUS_DISCARDED);
				$countItems = $this->_manifestation->countItems($criteria);
				
				if (count($allItems) == $countItems)	// for paranoid sureness, all items must be discarded
				{
					foreach ($allItems as $item)
					{
						$item->setManifestationId(0);
						$item->setTitle($manifestationTitle);
						
						$saved = $item->save();
						if ($saved > 0)
						{
							$countItemModified++;
							
							ChangelogPeer::logAction(	$item,
														ChangelogPeer::LOG_MODIFY,
														$this->getUser(),
														'Modificato esemplare, messo fuori catalogo dalla notizia con id = ' . $manifestationId);
						}
					}	
				}
				// end of items logic

				/**
				 * Issues part. Delete them all.
				 */

				$countIssueDeleted = 0;
				
				$issues = $this->_manifestation->getIssues();
				foreach ($issues as $issue)
				{
					foreach ($issue->getItems() as $issueItems)
						$issueItems->delete();
					
					$issue->delete();
					$countIssueDeleted++;
				}
				
				// end of issue deletion part
				
				/**
				 * This manifestation's loan unlinking logic.
				 */
				$countLoanModified = 0;
				$loans = $this->_manifestation->getLoans();
				foreach ($loans as $loan)
				{
					$loan->setManifestation(null);
					
					$saved = $loan->save();
					if ($saved > 0)
					{
						$countLoanModified++;

						ChangelogPeer::logAction(	$loan,
													ChangelogPeer::LOG_MODIFY,
													$this->getUser(),
													'Modificato prestito, sbiancato legame con notizia con id = ' . $manifestationId);
					}					
				}
				// end of loans logic
				
				/**
				 * Unlinking from authorities
				 */
				$countLAuthorityDeleted = 0;
				$l_authorities = $this->_manifestation->getLAuthorityManifestations();
				foreach ($l_authorities as $l_row)
				{
					$l_row->delete();
					$countLAuthorityDeleted++;
				}
				// end of unlinking authorities
				
				/**
				 * Unlinking from other manifestations
				 */
				$countLManifestationDeleted = 0;
				$l_manifestation_down = $this->_manifestation->getLManifestationsRelatedByManifestationIdDown();
				foreach ($l_manifestation_down as $l_row)
				{
					$l_row->delete();
					$countLManifestationDeleted++;
				}

				$l_manifestation_up = $this->_manifestation->getLManifestationsRelatedByManifestationIdUp();
				foreach ($l_manifestation_up as $l_row)
				{
					$l_row->delete();
					$countLManifestationDeleted++;
				}
				// end of unlinking other manifestations
				
				/**
				 * Real deleting of the manifestation, executed as the last action.
				 */
				$this->_manifestation->delete();
				
				ChangelogPeer::logAction(	$this->_manifestation,
											ChangelogPeer::LOG_DELETE,
											$this->getUser(),
											'Cancellata notizia con id = ' . $manifestationId);
				
				$this->enqueueMessage(Prado::localize('Cancellata notizia con id = {id}, "{title}"',
																array(	'id' => $manifestationId,
																		'title' => $manifestationTitle )),
											ClavisMessage::INFO);

				if ($countItemModified > 0)
					$this->enqueueMessage(Prado::localize("Un totale di {id} esemplari passati a stato 'fuori catalogo'.",
																array('id' => $countItemModified)),
											ClavisMessage::INFO);				
				
				if ($countIssueDeleted > 0)
					$this->enqueueMessage(Prado::localize("Un totale di {id} fascicoli cancellati.",
																array('id' => $countIssueDeleted)),
											ClavisMessage::INFO);	
				
				if ($countLoanModified > 0)
					$this->enqueueMessage(Prado::localize("Un totale di {id} prestiti modificati, cancellando il legame alla notizia cancellata.",
																array('id' => $countLoanModified)),
											ClavisMessage::INFO);				
				
				if ($countLAuthorityDeleted > 0)
					$this->enqueueMessage(Prado::localize("Un totale di {id} legami ad authority cancellati.",
																array('id' => $countLAuthorityDeleted)),
											ClavisMessage::INFO);				
				
				if ($countLManifestationDeleted > 0)
					$this->enqueueMessage(Prado::localize("Un totale di {id} legami a notizie cancellati.",
																array('id' => $countLManifestationDeleted)),
											ClavisMessage::INFO);				
				
				$gotoElement = ClavisBase::delEditObjectStack(	ClavisBase::EDITOBJECTSSTACK_TYPEMANIFESTATION,
																$manifestationId);

				if (ClavisBase::isValidElementObjectStack($gotoElement))
				{
					$this->getPage()->enqueueMessage(Prado::localize("É stato rimosso un oggetto dalla coda di catalogazione"),
														ClavisMessage::INFO);
					
					if ($gotoElement[0] == ClavisBase::EDITOBJECTSSTACK_TYPEMANIFESTATION)
					{
						$this->getPage()->flushDelayedMessage();
						
						$this->gotoPage(	'Catalog.EditRecord', 
											array(	'manifestationId' => $gotoElement[1],
													'selectTab' => 'TabAuthority' ));
					}
					elseif ($gotoElement[0] == ClavisBase::EDITOBJECTSSTACK_TYPEAUTHORITY)
					{
						$this->getPage()->flushDelayedMessage();
						
						$this->gotoPage(	'Catalog.AuthorityEditPage', 
											array(	'id' => $gotoElement[1],
													'selectTab' => 'TabAuthLink' ));
					}

				}
				elseif ((count($gotoElement) == 3)
							&& (is_null($gotoElement[0])))
				{
					$this->getPage()->enqueueMessage(Prado::localize("É stato rimossa la coda di catalogazione"),
														ClavisMessage::INFO);
					
					$this->getPage()->flushDelayedMessage();
					
					$this->gotoPage('Catalog.RecordList');
				}
				else
				{	
					$this->flushDelayedMessage();
					$this->gotoPage('Catalog.RecordList');
				}
			}
			catch (Exception $e)
			{
				$this->writeMessage(Prado::localize("Errore durante la cancellazione della notizia, con messaggio '{msg}'. Riportare al fornitore del software.",
															array('msg' => $e->getMessage())),
										ClavisMessage::ERROR);
			}
		}
		else
		{
			$this->writeMessage(Prado::localize('La notizia non è cancellabile. Segnalare al fornitore del software.'),
									ClavisMessage::ERROR);
		}
	}

	public function onTotalEraseRecord($sender, $param)
	{
		$captchaSuccess = $this->CaptchaSuccessFlag->getValue();
		
		if ($captchaSuccess != 1)
		{
			$this->writeMessage(Prado::localize('Errore di autenticazione col captcha'),
									ClavisMessage::ERROR);
			
			return false;
		}

		/**
		 * From now on, we will replicate the normal deletion of a manifestation
		 * but with small modifies (i.e.: storing of past loans).
		 * 
		 * We want an indipendent logic on deletion on this particular form of 
		 * total admin deletion of a manifestation.
		 * 
		 * NOTE: maybe we could implement a failsafe recovering strategy, the same
		 * way it's in Patron->replaceWith() (Patron->exportToMysql() ).
		 */
		
		if (!is_null($this->_manifestation)		// for super-sureness super-sayan
				&& ($this->_manifestation instanceof Manifestation))
		{
			try
			{
				$connection = Propel::getConnection();
				$connection->beginTransaction();
		
				$this->cleanMessageQueue();
				$manifestationId = $this->_manifestation->getManifestationId();
				
				/**
				 * items
				 */
				$itemIdsQuery = $connection->prepare("SELECT `item_id` from `item` WHERE `manifestation_id`={$manifestationId}");
				$itemIdsQuery->execute();
				$itemIds = $itemIdsQuery->fetchAll(PDO::FETCH_COLUMN, 0);
				$itemIdsString = implode(',', $itemIds);

				if (count($itemIds) > 0)
				{
					$itemExportArray = ItemPeer::exportToMySql($itemIds);		// param is an array, NB: return is an array of strings

					foreach ($itemExportArray as $itemExportElement)
						LibrarianPeer::writeAttachment($this->getUser()->getId(), $itemExportElement, 'cancellazione esemplari');

					ChangelogPeer::logActionBulk(	$itemIds,
													'Item',
													ChangelogPeer::LOG_DELETE,
													$this->getUser(),
													"Cancellazione forzosa di esemplari con id=({$itemIdsString}), collegati alla notizia con id={$manifestationId}");

					$affectedRows = ItemQuery::create()
										->filterByItemId($itemIds)
										->delete();

					if ($affectedRows > 0)
						$this->enqueueMessage(Prado::localize("N.{num} esemplari rimossi",
																	array('num' => $affectedRows)),
												ClavisMessage::CONFIRM);	
				}
				
				/**
				 * loans
				 */
				$loanIdsQuery = $connection->prepare("SELECT `loan_id` from `loan` WHERE `manifestation_id`={$manifestationId}");
				$loanIdsQuery->execute();
				$loanIds = $loanIdsQuery->fetchAll(PDO::FETCH_COLUMN, 0);
				
				if (count($loanIds) > 0)
				{
					$loanIdsString = implode(',', $loanIds);
					$loanExportArray = LoanPeer::exportToMySql($loanIds);
					
					
					foreach ($loanExportArray as $loanExportElement)
						LibrarianPeer::writeAttachment($this->getUser()->getId(), $loanExportElement, 'modifica prestiti');
										
					ChangelogPeer::logActionBulk(	$loanIds,
													'Loan',
													ChangelogPeer::LOG_MODIFY,
													$this->getUser(),
													"Modifica dei prestiti (azzeramento riferimenti) con id=({$loanIdsString}) per la notizia con id={$manifestationId}");

					$affectedRows = LoanQuery::create()
										->filterByItemId($itemIds)
										->update(array(	'ManifestationId' => 0, 
														'ItemId' => 0 ));
					
					if ($affectedRows > 0)
						$this->enqueueMessage(Prado::localize("N.{num} prestiti modificati",
																	array('num' => $affectedRows)),
												ClavisMessage::CONFIRM);	
				}
				
				/**
				 * Issues part. Delete them all. And linked items too
				 */
				$issueIdsQuery = $connection->prepare("SELECT `issue_id` from `issue` WHERE `manifestation_id`={$manifestationId}");
				$issueIdsQuery->execute();
				$issueIds = $issueIdsQuery->fetchAll(PDO::FETCH_COLUMN, 0);

				if (count($issueIds) > 0)
				{	
					$issueIdsString = implode(',', $issueIds);
					$issueExportText = IssuePeer::exportToMySql($issueIds);

					$itemIssueIdsQuery = $connection->prepare("SELECT `item_id` from `item` WHERE `issue_id` IN ({$issueIdsString})");
					$itemIssueIdsQuery->execute();
					$itemIssueIds = $itemIssueIdsQuery->fetchAll(PDO::FETCH_COLUMN, 0);
					$itemIssueIdsString = implode(',', $itemIssueIds);
					$itemIssueExportText = ItemPeer::exportToMySql($itemIssueIds);

					LibrarianPeer::writeAttachment($this->getUser()->getId(), $issueExportText, 'cancellazione fascicoli');

					ChangelogPeer::logActionBulk(	$issueIds,
													'Issue',
													ChangelogPeer::LOG_DELETE,
													$this->getUser(),
													"Cancellazione fascicoli con id=({$issueIdsString}), durante la cancellazione forzosa della notizia con id={$manifestationId}");

					LibrarianPeer::writeAttachment($this->getUser()->getId(), $itemIssueExportText, 'cancellazione esemplari legati a fascicoli');

					ChangelogPeer::logActionBulk(	$itemIssueIds,
													'Item',
													ChangelogPeer::LOG_DELETE,
													$this->getUser(),
													"Cancellazione esemplari legati a fascicoli, con id=({$itemIssueIdsString}), durante la cancellazione forzosa della notizia con id={$manifestationId}");

					$affectedRows = IssueQuery::create()
										->filterByIssueId($issueIds)
										->delete();

					if ($affectedRows > 0)
						$this->enqueueMessage(Prado::localize("N.{num} fascicoli rimossi",
																	array('num' => $affectedRows)),
												ClavisMessage::CONFIRM);
					
					$affectedRows = ItemQuery::create()
										->filterByItemId($itemIssueIds)
										->delete();
					
					if ($affectedRows > 0)
						$this->enqueueMessage(Prado::localize("N.{num} esemplari (di fascicoli) rimossi",
																	array('num' => $affectedRows)),
												ClavisMessage::CONFIRM);	
				}
				// end of issue deletion part
				
				/**
				 * Authorities (links to, not real authorities)
				 */
				$lAuthorityIdsQuery = $connection->prepare("SELECT `authority_id`, `manifestation_id`, `link_type`, `relator_code` FROM `l_authority_manifestation` WHERE `manifestation_id`={$manifestationId}");
				$lAuthorityIdsQuery->execute();
				$lAuths = $lAuthorityIdsQuery->fetchAll(PDO::FETCH_NUM);
				
				if (count($lAuths))
				{	
					$lAuthorityExportText = LAuthorityManifestationPeer::exportToMySql($lAuths);
					LibrarianPeer::writeAttachment($this->getUser()->getId(), $lAuthorityExportText, 'cancellazione legami con authority');

					/**  We don't log it for now: the type of changelog 'LAuthorityManifestation'
					 * has not been created yet.....
					ChangelogPeer::logActionBulk(	$lAuths,
									'LAuthorityManifestation',
									ChangelogPeer::LOG_DELETE,
									$this->getUser(),
									"Cancellazione legami con authority della notizia con id=({$manifestationId})");
					*/

					$affectedRows = LAuthorityManifestationQuery::create()
										->filterByPrimaryKeys($lAuths)
										->delete();
					
					if ($affectedRows > 0)
						$this->enqueueMessage(Prado::localize("N.{num} legami ad authority rimossi",
																	array('num' => $affectedRows)),
												ClavisMessage::CONFIRM);	
				}

				// end of authorities
				
				/**
				 * Links to other manifestations: we will remove links only
				 */
				
				$lManifestationIdsQuery = $connection->prepare("SELECT `manifestation_id_up`, `manifestation_id_down`  FROM `l_manifestation` WHERE `manifestation_id_up`={$manifestationId} OR `manifestation_id_down`={$manifestationId}");
				$lManifestationIdsQuery->execute();
				$lManif = $lManifestationIdsQuery->fetchAll(PDO::FETCH_NUM);
				
				if (count($lManif))
				{
					$lManifestationExportText = LManifestationPeer::exportToMySql($lManif);
					LibrarianPeer::writeAttachment($this->getUser()->getId(), $lManifestationExportText, 'cancellazione legami con notizie');

					/** We don't log it for now: the type of changelog 'LManifestation'
					* has not been created yet.....
					ChangelogPeer::logActionBulk(	$lManif,
													'LManifestation',
													ChangelogPeer::LOG_DELETE,
													$this->getUser(),
													"Cancellazione legami con manifestation della notizia con id=({$manifestationId})");
					*/

					$affectedRows = LManifestationQuery::create()
										->filterByPrimaryKeys($lManif)
										->delete();
					
					if ($affectedRows > 0)
						$this->enqueueMessage(Prado::localize("N.{num} legami a notizie rimossi",
																	array('num' => $affectedRows)),
												ClavisMessage::CONFIRM);
				}
				
				/**
				 * Itemrequests. We are removing the requests that are linked
				 * to this manifestation only AND to linked items that maybe
				 * we have removed above in the items part
				 */
				
				$requestQueryString = "SELECT `request_id` from `item_request` WHERE `manifestation_id`={$manifestationId}";
				
				/**
				 * We want also the requests made on the items (they were deleted too)
				 */
				if ($itemIdsString != "")
					$requestQueryString .= " OR `item_id` IN ({$itemIdsString})";
				
				$requestIdsQuery = $connection->prepare($requestQueryString);
				$requestIdsQuery->execute();
				$requestIds = $requestIdsQuery->fetchAll(PDO::FETCH_COLUMN, 0);
				
				if (count($requestIds))
				{
					$requestIdsString = implode(',', $requestIds);
					$requestExportText = ItemRequestPeer::exportToMySql($requestIds);

					/**    da riattivare */
					LibrarianPeer::writeAttachment($this->getUser()->getId(), $requestExportText, 'cancellazione prenotazioni sulla notizia rimossa');

					ChangelogPeer::logActionBulk(	$requestIds,
													'ItemRequest',
													ChangelogPeer::LOG_DELETE,
													$this->getUser(),
													"Cancellazione delle prenotazioni con id=({$requestIdsString}) per la notizia con id={$manifestationId} e gli esemplari eventualmente collegati");

					$affectedRows = ItemRequestQuery::create()
										->filterByRequestId($requestIds)
										->delete();
					
					if ($affectedRows > 0)
						$this->enqueueMessage(Prado::localize("N.{num} legami a notizie rimossi",
																	array('num' => $affectedRows)),
												ClavisMessage::CONFIRM);
				}
				
				/**
				 * Real deleting of the manifestation, executed as the last action.
				 */
												
				$manifestationExportText = ManifestationPeer::exportToMySql($manifestationId);
				LibrarianPeer::writeAttachment($this->getUser()->getId(), $manifestationExportText, 'cancellazione notizia');
				
				ChangelogPeer::logAction(	$this->_manifestation,
											ChangelogPeer::LOG_DELETE,
											$this->getUser(),
											'Cancellata notizia con id = ' . $manifestationId);
				
				$this->enqueueMessage(Prado::localize('Cancellata notizia con id = {id}, "{title}"',
																array(	'id' => $manifestationId,
																		'title' => $this->_manifestation->getTrimmedTitle(30) )),
											ClavisMessage::CONFIRM);

				$affectedRows = $this->_manifestation->delete();

				if ($affectedRows > 0)
						$this->enqueueMessage(Prado::localize("Notizia con id={$id} rimossa",
																	array('id' => $manifestationId)),
												ClavisMessage::CONFIRM);
				
				$connection->commit();
				
				$gotoElement = ClavisBase::delEditObjectStack(	ClavisBase::EDITOBJECTSSTACK_TYPEMANIFESTATION,
																$manifestationId);
								
				if (ClavisBase::isValidElementObjectStack($gotoElement))
				{
					$this->getPage()->enqueueMessage(Prado::localize("É stato rimosso un oggetto dalla coda di catalogazione"),
														ClavisMessage::INFO);
					
					if ($gotoElement[0] == ClavisBase::EDITOBJECTSSTACK_TYPEMANIFESTATION)
					{
						$this->getPage()->flushDelayedMessage();
						
						$this->gotoPage(	'Catalog.EditRecord', 
											array(	'manifestationId' => $gotoElement[1],
													'selectTab' => 'TabAuthority' ));
					}
					elseif ($gotoElement[0] == ClavisBase::EDITOBJECTSSTACK_TYPEAUTHORITY)
					{
						$this->getPage()->flushDelayedMessage();
						
						$this->gotoPage(	'Catalog.AuthorityEditPage', 
											array(	'id' => $gotoElement[1],
													'selectTab' => 'TabAuthLink' ));
					}

				}
				elseif ((count($gotoElement) == 3)
							&& (is_null($gotoElement[0])))
				{
					$this->getPage()->enqueueMessage(Prado::localize("É stato rimossa la coda di catalogazione"),
														ClavisMessage::INFO);
					
					$this->getPage()->flushDelayedMessage();
					
					$this->gotoPage('Catalog.RecordList');
				}
				else
				{	
					$this->flushDelayedMessage();
					$this->gotoPage('Catalog.RecordList');
				}				
			}
			catch (Exception $e)
			{
				$connection->rollBack();
				
				$this->writeMessage(Prado::localize("Errore durante la cancellazione della notizia, con messaggio '{msg}'. Segnalare al fornitore del software.",
															array('msg' => $e->getMessage())),
										ClavisMessage::ERROR);
			}
		}	// end of a real manifestation here
		else
		{
			$this->writeMessage(Prado::localize('Errore interno sulla notizia. Segnalare al fornitore del software.'),
									ClavisMessage::ERROR);
		}
	}
	
	public function onSelectReplacement($sender, $param)
	{
		$this->getPage()->gotoPage('Catalog.RecordReplace',
									array(	'target' => $this->_manifestation->getManifestationId(),
											'q' => $this->_manifestation->getTitle() ));
	}

	public function onPatronClean($sender, $param)
	{
		$this->doPatronClean(true);
	}

	private function doPatronClean($focus = false)
	{
		$this->ReservePatronLabel->setText('');
		$this->UserData->populate(null);
		$this->CirculationData->setPatronId(null);
		$this->CirculationData->populate(null);

		$this->PatronId->setText(0);
		$this->ReserveHiddenValue->setValue('');
		$this->DoReserve->setEnabled(false);

		if ($focus)
			$this->setFocus($this->ReservePatronLabel->getClientID());
	}

	public function onPatronReload($sender, $param)
	{
		$this->insertPatron(trim($this->PatronId->getSafeText()));
	}

	public function onExternalLibraryClean($sender, $param)
	{
		$this->doExternalLibraryClean(true, $param);
	}

	private function doExternalLibraryClean($focus = false, $param = null)
	{
		$this->LibraryData->populate(null);	// implementare una sorta di ClavisLibraryDataCard
		$this->LibraryDataPanel->setCssClass('panel_off');
	
		if ($this->getPage()->getIsCallBack())
		{
			if (is_null($param))
			{
				$this->LibraryDataPanel->render($this->getPage()->createWriter());
			}
			else
			{
				$this->LibraryDataPanel->render($param->getNewWriter());
			}
		}

		$this->ExternalLibraryId->setText(0);
		$this->ReserveHiddenValue2->setValue('');
		$this->DoReserve->setEnabled(false);
		$this->ReserveExternalLibraryLabel->setText('');

		if ($focus)
			$this->setFocus($this->ReserveExternalLibraryLabel->getClientID());
	}

	public function onExternalLibraryReload($sender, $param)
	{
		$this->insertExternalLibrary(trim($this->ExternalLibraryId->getSafeText()));
	}

	public function onSwitchExtraMode($sender, $param)
	{
		$this->doPatronClean();
		$this->doExternalLibraryClean();
		$this->setExtraMode(!$this->getExtraMode());

		$this->MaxDistancePanel->setVisible(!$this->getExtraMode());
			
		if (!is_null($param)
				&& $this->getPage()->getIsCallBack())
			$this->PanelReserve->render($param->getNewWriter());
	}

	public function onReserveDeliveryLibraryChanged($sender, $param)
	{
		$this->calculateReservable();
	}

	private function calculateReservable()
	{
		$patron = $this->getPatron();
		$deliveryLibraryId = $this->ReserveDeliveryLibrary->getSelectedValue();
		$this->drawReserveButton($this->_manifestation, $patron, $deliveryLibraryId);
		
		if ($this->_llibraryActive
				&& !$this->getExtraMode())
			$this->populateMaxDistance($this->_manifestation, $deliveryLibraryId);
	}

	private function drawReserveButton($manifestation, $patron, $deliveryLibraryId)
	{
		$reserve = false;
	
		if ($patron instanceof Patron)
		{
			switch ($this->_requestmanager->isManifestationReservable(	$manifestation, 
																		null, 
																		$patron, 
																		$deliveryLibraryId)) 
			{
				case ClavisLoanManager::OK:
					$this->getPage()->writeMessage(Prado::localize("La prenotazione è consentita"),
														ClavisMessage::INFO);
					
					$reserve = true;
					break;

				case ClavisLoanManager::RSV_NOTAVAIL:
					$this->getPage()->writeMessage(Prado::localize("Attenzione: la prenotazione viene consentita, però al momento nessun esemplare nel sistema può soddisfarla"),
														ClavisMessage::WARNING);
					
					$reserve = true;
					break;

				case ClavisLoanManager::RSV_PATRONMAXREQ:
					$this->getPage()->writeMessage(Prado::localize("L'utente ha già raggiunto il massimo numero di prenotazioni [{count}]",
																		array('count'=>ClavisParamPeer::getParam('MAXLOANRESERVATIONS_' . $patron->getLoanClass(), '0'))),
														ClavisMessage::ERROR);
					
					break;

				case ClavisLoanManager::RSV_PATRONREQMANIF:
					$this->getPage()->writeMessage(Prado::localize("L'utente ha già una prenotazione per questo titolo"),
														ClavisMessage::ERROR);
					
					break;

                case ClavisLoanManager::RSV_PATRONDISABLED:
                    $this->getPage()->writeMessage(Prado::localize("L'utente non è abilitato"),
														ClavisMessage::ERROR);
                    
					break;

				case ClavisLoanManager::RSV_RATING:
					$this->getPage()->writeMessage(Prado::localize("La prenotazione non è possibile perchè l'utente ha un'età minore di come consentito dal titolo"),
														ClavisMessage::ERROR);
					
					break;

				case ClavisLoanManager::ERROR:
				default:
					$this->getPage()->writeMessage(Prado::localize("Errore: l'esemplare non è prenotabile da questo utente"),
														ClavisMessage::ERROR);
			}
		}

		$this->DoReserve->setEnabled($reserve);
	}

	public function onCalculateStatistics($sender, $param)
	{
		$loanDataSource = array();
		$manifestationId = intval($this->_manifestation->getManifestationId());
		if ($manifestationId > 0)
		{
			$connection = Propel::getConnection(LoanPeer::DATABASE_NAME);
			
			$statsMyLibraryCond = ($this->StatsMyLibraryFilter->getChecked()
									? " AND " . LoanPeer::ITEM_HOME_LIBRARY_ID . ' = ' . $this->getUser()->getActualLibraryId()
									: "");
			
			$sql = 'SELECT YEAR('.LoanPeer::LOAN_DATE_BEGIN.'), COUNT('.LoanPeer::LOAN_DATE_BEGIN.')
						FROM '.LoanPeer::TABLE_NAME.'
						WHERE '.LoanPeer::MANIFESTATION_ID.' = :manId '
						. $statsMyLibraryCond . 
						' GROUP BY YEAR('.LoanPeer::LOAN_DATE_BEGIN.')
						ORDER BY '.LoanPeer::LOAN_DATE_BEGIN.' DESC';
			
			$statement = $connection->prepare($sql);
			$statement->execute(array(':manId' => $this->_manifestation->getManifestationId()));

			while ($row = $statement->fetch())
				$loanDataSource[] = array($row[0], $row[1]);

			$this->LoanGrid->setDataSource($loanDataSource);
			$this->LoanGrid->dataBind();
		}
		
		$this->LoanGridPanel->setCssClass((count($loanDataSource) > 0)
														? "panel_on"
														: "panel_off");
		
		$baseLoanQuery = LoanQuery::create()->filterByManifestation($this->_manifestation);
		
		if ($this->StatsMyLibraryFilter->getChecked())
			$baseLoanQuery->filterByItemHomeLibraryId($this->getUser()->getActualLibraryId());
		
		$totalLoansCount = $baseLoanQuery->count();

		if ($totalLoansCount > 0)
		{
			$this->TotalLoansLabel->setText($totalLoansCount);
		}
		else
		{
			$this->TotalLoansLabel->setText("(" . Prado::localize("nessuno") . ")");
		}
		
		$activeLoansCount = $baseLoanQuery->filterByLoanStatus(ItemPeer::getLoanStatusActive())->count();
	
		if ($activeLoansCount > 0)
		{
			$this->ActiveLoansLabel->setText($activeLoansCount);
		}
		else
		{
			$this->ActiveLoansLabel->setText("(" . Prado::localize("nessuno") . ")");
		}
						
		$lastLoan = $baseLoanQuery->orderByLoanDateBegin(criteria::DESC)->findOne();
		
		if ($lastLoan instanceof Loan)
		{
			$date = $lastLoan->getLoanDateBegin('U');
			$this->LastLoanDate->setValue($date);
			$this->LastLoanDate->setVisible(true);
			$this->LastLoanNone->setVisible(false);
		}
		else
		{
			$this->LastLoanDate->setVisible(false);
			$this->LastLoanNone->setVisible(true);
		}
		
		$this->StatisticsPanel->setCssClass("panel_on");
		
		if (!is_null($param) && ($this->getIsCallback()))
			$this->StatisticsPanel->render($param->getNewWriter());
	}

	public function checkSBNLink($sender,$param)
	{
		if (!$this->_sbnMod->getEnabled()
				|| ($this->_manifestation->getBidSource() != 'SBN'))
		{
			$param->IsValid = true;
		}
		elseif ($this->_manifestation->getLastSbnSync('U'))
		{
			$param->IsValid = false;
		} 
		else
		{
			// check items
			$ic = ItemQuery::create()
					->filterByManifestation($this->_manifestation)
					->filterByLastSbnSync(null,Criteria::NOT_EQUAL)
					->count();
			
			$param->IsValid = ($ic == 0);
		}
	}
	
}
