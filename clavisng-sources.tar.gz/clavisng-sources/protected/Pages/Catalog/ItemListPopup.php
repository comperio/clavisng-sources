<?php

/**
 * ItemListPopup
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @copyright Copyright &copy; 2010 Comperio srl
 * @version 2.7
 * @package Popups.Catalog
 * @since 2.1
 */

class ItemListPopup extends ClavisPagePopup
{
	public $_module = 'CATALOG';

	public function onInit($param)
	{
		parent::onInit($param);

		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallback())
		{
			if ($this->getRequest()->itemAt('param'))
				$this->ItemList->setVisualizationStyle('param');

			$givenItemIds = TPropertyValue::ensureArray($this->getRequest()->itemAt('object'));
			if (!is_null($givenItemIds) && (count($givenItemIds) > 0)) {
				$this->ItemList->setGivenItemIds($givenItemIds);
				$this->SearchPanel->setVisible(false);
			} else {
				$this->SearchPanel->setVisible(true);
			}
		}
	}

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallback())
		{
			$this->populateSearchPanel();
			$libraries = LibraryPeer::getLibrariesHashWithBlank();
			$this->HomeLibraryFilter->setDataSource($libraries);
			$this->HomeLibraryFilter->dataBind();
			$this->HomeLibraryFilter->setSelectedValue($this->getUser()->getActualLibraryId());
			//$this->onSearchItem(null, null);
			$this->setFocus($this->BarcodeFilter->getClientID());
		}
	}

	public function onCancel($sender, $param)
	{
	}

	public function isUnlink()
	{
		return false;
	}

	public function setVisualizationStyle($value)
	{
		$this->ItemList->setVisualizationStyle($value);
	}

	public function populateSearchPanel() 
	{
		if (!$this->SearchPanel->getVisible())
			return;
	
		$lid = $this->getUser()->getActualLibraryId();
		$c = new Criteria();
		$c->add(InventorySeriePeer::LIBRARY_ID,$lid);
		$c->addAscendingOrderByColumn(InventorySeriePeer::CLOSED);
		$c->addAscendingOrderByColumn(InventorySeriePeer::READONLY);
		$c->addAscendingOrderByColumn(InventorySeriePeer::INVENTORY_SERIE_ID);
		$inv_series = InventorySeriePeer::doSelect($c);
		$ds = array(''=>'---');
		foreach ($inv_series as $i) {
			$ds[$i->getInventorySerieId()] = $i->getInventorySerieId().' ('.
				$i->getInventoryCounter().')';
		}
		
		$this->InventorySerieIdFilter->setDataSource($ds);
		$this->InventorySerieIdFilter->dataBind();
	}

	public function resetFilterExists()
	{
		$this->setFilterExists(false);
	}

	public function setFilterExists($value = false)
	{
		if (!is_bool($value))
			$value = false;

		$this->setViewState("FilterExists", $value, false);
	}

	public function getFilterExists()
	{
		$output = $this->getViewState("FilterExists", false);
		$this->resetFilterExists();
		
		return $output;
	}

	public function setFilterRepeaterDataSource($data)
	{
		$this->setViewState("FilterRepeaterDataSource", $data, null);
	}

	public function getFilterRepeaterDataSource()
	{
		return $this->getViewState("FilterRepeaterDataSource", null);
	}

	public function resetFilterRepeater()
	{
		$this->FilterRepeater->setDataSource(array());
	}

	public function globalRefresh()
	{
		$this->ItemList->populate();
	}

	public function onLocalSearch($sender, $param)
	{
		$actualLibraryId = $this->getUser()->getActualLibraryId();
		$this->LibraryFilter->setSelectedValue($actualLibraryId);

		$this->search();
	}


	public function onSearchItem($sender, $param)
	{
		$this->resetPagination();
		$this->FilteredSearch();
	}

	public function FilteredSearch()
	{
		$criteria = new Criteria();

		$barcode = TPropertyValue::ensureString(trim($this->BarcodeFilter->getSafeText()));
		if ($barcode != '')
			$criteria->addAnd(ItemPeer::BARCODE, $barcode);

		$title = TPropertyValue::ensureString(trim($this->TitleFilter->getSafeText()));
		if ($title != '')
			$criteria->addAnd(ItemPeer::TITLE, $title . "%", Criteria::LIKE);

		$inventoryNumberFrom = intval(trim($this->InventoryFilterFrom->getSafeText()));
		$inventoryNumberTo = intval(trim($this->InventoryFilterTo->getSafeText()));
		if (($inventoryNumberFrom > 0) || ($inventoryNumberTo > 0))
		{
			if ($inventoryNumberTo == 0)
				$criteria->add(ItemPeer::INVENTORY_NUMBER, $inventoryNumberFrom);
			else
			{
				$inventoryCriterion = null;

				if ($inventoryNumberFrom > 0)
					$inventoryCriterion = $criteria->getNewCriterion(ItemPeer::INVENTORY_NUMBER, $inventoryNumberFrom, Criteria::GREATER_EQUAL);

				if ($inventoryNumberTo > 0)
				{
					$inventoryCriterion2 = $criteria->getNewCriterion(ItemPeer::INVENTORY_NUMBER, $inventoryNumberTo, Criteria::LESS_EQUAL);
					if (!is_null($inventoryCriterion))

						$inventoryCriterion->addAnd($inventoryCriterion2);
					else
						$inventoryCriterion = $inventoryCriterion2;
				}

				if (!is_null($inventoryCriterion))
					$criteria->addAnd($inventoryCriterion);
			}
		}

		if ($this->InventorySerieIdFilter->getSelectedIndex() > 0)
		{
			$inventorySerieId = $this->InventorySerieIdFilter->getSelectedValue();
			$criteria->addAnd(ItemPeer::INVENTORY_SERIE_ID, $inventorySerieId);
		}

		if ($this->HomeLibraryFilter->getSelectedIndex() > 0)
		{
			$homeLibraryFilter = $this->HomeLibraryFilter->getSelectedValue();
			$criteria->addAnd(ItemPeer::HOME_LIBRARY_ID, $homeLibraryFilter);
		}

		$this->ItemList->setExternalCriteria($criteria);
		$this->ItemList->populate();
	}

	public function search()
	{
		$filtersDataSource = $this->readDataSource();
		if (count($filtersDataSource) > 0)
		{
			$dataSource = $filtersDataSource;
			foreach ($dataSource as $index => $row)
			{
				if ($row['key'] == 0)
					unset($filtersDataSource[$index]);
			}

			if (count($filtersDataSource) > 0)
			{
				$criteria = new Criteria();
				if (isset($baseCriterion))
					unset($baseCriterion);
				$keyMap = $this->getKeyMap();
				$relationMap = $this->getRelationMap();
				foreach ($filtersDataSource as $index => $row)
				{
					$key = $keyMap[$row['key']];
					$relation = $relationMap[$row['relation']];
					$value = $row['value'];
					$operator = $row['operator'];

					if (!isset($baseCriterion))
						$baseCriterion = $criteria->getNewCriterion($key, $value, $relation);
					else
					{
						$criterion = $criteria->getNewCriterion($key, $value, $relation);
						switch ($operator)
						{
							case 'and':
								$baseCriterion->addAnd($criterion);
								break;
							case 'or':
								$baseCriterion->addOr($criterion);
								break;
							default:
								break;
						}
					}
				}

				$criteria->add($baseCriterion);

				$pageSize = $this->ItemList->getPageSize();
				$currentPage = $this->ItemList->getCurrentPage();

				$recCount = ItemPeer::doCount($criteria);

				$criteria->setLimit($pageSize);
				$criteria->setOffset($currentPage * $pageSize);

				$items = ItemPeer::doSelect($criteria);
				$itemIds = array();
				if (count($items) > 0)
				{
					foreach ($items as $item)
						$itemIds[] = $item->getItemId();
				}

				$this->ItemList->setExternalRecCount($recCount);
				$this->ItemList->setGivenItemIds($itemIds);
				$this->ItemList->populate();
			}
		}
	}

	public function onCleanSearch($sender, $param)
	{
		$this->doCleanSearch();
		$this->ItemList->populate();
		$this->doToLibrarySwitches();
	}

	private function doCleanSearch()
	{
		$this->BarcodeFilter->setText('');
		$this->TitleFilter->setText('');
		$this->InventorySerieIdFilter->setSelectedIndex(0);
		$this->InventoryFilterFrom->setText('');
		$this->InventoryFilterTo->setText('');
		$this->HomeLibraryFilter->setSelectedIndex(0);
		$this->ItemList->resetExternalCriteria();
		$this->ItemList->resetPagination();
	}

	public function resetPagination()
	{
		$this->ItemList->resetPagination();
	}

	public function readDataSource()
	{
		$dataSource = array();
		$items = $this->FilterRepeater->getItems();
		foreach ($items as $item)
		{
			$key = $item->KeyDropDownList->getSelectedValue();
			$relation = $item->RelationDropDownList->getSelectedValue();
			$valueTextBox = $item->ValueTextBox->getSafeText();
			$valueDropDownList = $item->ValueDropDown->getSelectedValue();
			$valueDatePicker = $item->ValueDatePicker->getTimeStamp();
			$valueType = $item->ValueType->getValue();
			$operator = $item->OperatorDropDownList->getSelectedValue();

			$newRow = array('key' => $key, 
							'relation' => $relation, 
							'valueText' => $valueTextBox, 
							'valueSelectedValue' => $valueDropDownList, 
							'valueTimeStamp' => $valueDatePicker, 
							'valueType' => $valueType, 
							'operator' => $operator );
			
			$dataSource[] = $newRow;
		}
		
		return $dataSource;
	}

	public function onBuildRepeaterRow($sender, $param)
	{
		$item = $param->Item;
		if (($item->ItemType === 'Item') || ($item->ItemType === 'AlternatingItem'))
		{
			$item->KeyDropDownList->setDataSource($this->getKeyList());
			$item->KeyDropDownList->dataBind();

			$item->RelationDropDownList->setDataSource($this->getRelationList());
			$item->RelationDropDownList->dataBind();

			$valueType = $item->DataItem['valueType'];


			$item->OperatorDropDownList->setDataSource($this->getOperatorList());
			$item->OperatorDropDownList->dataBind();
			$item->OperatorDropDownList->setVisible($item->ItemIndex != 0);
		}

	}

	public function onAddRepeaterRow($sender, $param)
	{
		$repeaterSource = $this->readDataSource();
		$newRow = array('key' => 0, 
						'relation' => 0, 
						'valueText' => '', 
						'valueSelectedValue' => 0, 
						'valueTimeStamp' => null, 
						'valueType' => 'TextBox', 
						'operator' => 'and' );
		
		$repeaterSource[] = $newRow;
		$this->FilterRepeater->setDataSource($repeaterSource);
		$this->FilterRepeater->dataBind();
	}

	public function onDeleteRepeaterRow($sender, $param)
	{
		$rowToDelete = $sender->Parent->ItemIndex;
		$dataSource = $this->readDataSource();
		if (isset($dataSource[$rowToDelete]))
		{
			unset($dataSource[$rowToDelete]);
			$this->FilterRepeater->setDataSource($dataSource);
			$this->FilterRepeater->dataBind();
		}
	}

	private function getKeyList()
	{
		$list =    array(	'---',
							'barcode',
							'stato dell\'esemplare',
							'stato del prestito',
							'biblioteca proprietaria',
							'biblioteca che gestisce',
							'biblioteca corrente',
							'biblioteca di destinazione',
					);
		
		return $list;
	}

	public function onSelectMyLibrary($sender, $param)
	{
		$newLibrary = $this->getUser()->getActualLibraryId();
		if ($newLibrary >= 0)
			$this->HomeLibraryFilter->setSelectedValue($newLibrary);
		
		$this->doToLibrarySwitches();
		$this->HomeLibraryFilterPanel->render($param->getNewWriter());
	}

	public function onSelectAllLibrary($sender, $param)
	{
		$newLibrary = 0;
		$this->HomeLibraryFilter->setSelectedValue($newLibrary);
		$this->doToLibrarySwitches();
		$this->HomeLibraryFilterPanel->render($param->getNewWriter());
	}

	public function doToLibrarySwitches()
	{
		$linksVisibility = $this->HomeLibraryFilter->getSelectedIndex() > 0;
		$this->HomeLibraryFilterAllLinkButton->setVisible($linksVisibility);
		$this->HomeLibraryFilterOnlySelectedLinkButton->setVisible(!$linksVisibility);
	}
	
}
