<?php

/**
 * CompleteRecord Page class Module Catalog
 *
 * @author Ciro Mattia Gonano
 * @link http://www.e-portaltech.it/
 * @copyright Copyright &copy; 2008 ePortal Technologies
 * @license http://www.e-portaltech.it/license/
 */

class CompleteRecord extends ClavisPage {

	/**
	 * Module where we are.
	 *
	 * @var string
	 */
	public $_module = 'CATALOG';

	/**
	 * The manifestation object.
	 *
	 * @var Manifestation
	 */
	private $_manifestation = null;

	public function onInit($param) {
		parent::onInit($param);
		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallBack()) {
			$manifestationId = TPropertyValue::ensureInteger($this->getRequest()->itemAt('manifestationId'));
			if ($manifestationId < 1) {
				$this->writeMessage(Prado::localize('E\' necessario specificare una notizia da completare.'));
				$this->returnPage();
			}
			$manifestation = ManifestationPeer::retrieveByPK($manifestationId);
			if ($manifestationId === null) {
				$this->writeMessage(Prado::localize('E\' necessario specificare una notizia da completare.'));
				$this->returnPage();
			}
			$this->_manifestation = $manifestation;
			$this->populate();
		}
	}

	/**
	 * Exits the editing of an item, without doing anything.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onCancel($sender,$param) {
		$manifestation = $this->getManifestation();
		$manifestationId = (!is_null($manifestation))?$manifestation->getManifestationId():0;
		if (!$manifestation->isNew() && ($manifestationId > 0))
			$this->gotoPage("Catalog.Record", array("manifestationId" => $manifestationId));
		else
			$this->gotoPage("Catalog.Record");
	}

	public function populate() {
		$m = $this->getManifestation();


		$this->ManStatus->setSelectedValue($this->_manifestation->getManifestationStatus());
		$this->ManLevel->setSelectedValue($this->_manifestation->getCatalogationLevel());
		$this->BibLevel->setSelectedValue($this->_manifestation->getBibLevel());
		$this->BibObjFirst->setSelectedValue($this->_manifestation->getBibTypeFirst());
		if ($this->_manifestation->getBibType() != null) {
			$this->BibObj->setVisible(true);
			$this->BibObj->setDBClass("OGGBIBL_".$this->_manifestation->getBibTypeFirst());
			$this->BibObj->populateList();
			$this->BibObj->setSelectedValue($this->_manifestation->getBibType());
		}
		if (($r=$this->_manifestation->getRating())!=NULL)
			$this->ManRating->setSelectedValue($r);
		else
			$this->ManRating->setSelectedIndex(0);
		if ($ls=$this->_manifestation->getLoanableSince(null))
			$this->LoanableSince->setTimestamp($ls);

		$unimarc = new UnimarcRecord();
		$unimarc->parseTXTCompact($this->_manifestation->getUnimarc());

		$f010 = $unimarc->getField("010");
		$this->F010a->Text = $unimarc->getSubField("010",'a');
		$this->F010b->Text = $unimarc->getSubField("010",'b');
		$this->F010d->Text = $unimarc->getSubField("010",'d');
		$this->F010z->Text = $unimarc->getSubField("010",'z');

		$f011 = $unimarc->getField("011");
		$this->F011a->Text = $unimarc->getSubField("011",'a');
		$this->F011b->Text = $unimarc->getSubField("011",'b');
		$this->F011d->Text = $unimarc->getSubField("011",'d');
		$this->F011z->Text = $unimarc->getSubField("011",'z');

		$f073 = $unimarc->getField("073");
		$this->F073a->Text = $unimarc->getSubField("073",'a');
		$this->F073b->Text = $unimarc->getSubField("073",'b');
		$this->F073d->Text = $unimarc->getSubField("073",'d');
		$this->F073z->Text = $unimarc->getSubField("073",'z');

		if ($unimarc->existsField('100')) {
			$f100 = $unimarc->getField(100);
			try {
				$f100_a_8 = $f100->getCDFField('a',8);
				if ($f100_a_8 != false)
					$this->DateType->setValue(strtr($f100_a_8," ","a"));
			} catch (Exception $e) {}
			$this->F100aDate1->Text = $f100->getCDFField('a',9);
			$this->F100aDate2->Text = $f100->getCDFField('a',13);
			try {
				$f100_a_17 = $f100->getCDFField('a',17);
				$this->F100a17->Value = $f100_a_17;
			} catch(Exception $e) {}
			try {
				$this->F100a18->Value = $f100->getCDFField('a',18);
			} catch(Exception $e) {}
			try {
				$this->F100a19->Value = $f100->getCDFField('a',19);
			} catch(Exception $e) {}
			try {
				$this->F100a20->Value = $f100->getCDFField('a',20);
			} catch(Exception $e) {}
		}

		if ($unimarc->existsField('101')) {
			$f101 = $unimarc->getField("101");
			try {
				$this->F101Ind1->setSelectedValue($f101->indicator[0]);
			} catch (Exception $e) {}
			$ds101 = array();
			for($i=0; $i < count($f101->subFieldList); $i++) {
				$ds101[] = array("LangTag"=>$f101->tagList[$i], "LangCode"=>strtolower($f101->subFieldList[$i]));
			}
		} else {
			$ds101[] = array("LangTag"=>"a", "LangCode"=>"abs");
		}

		$this->RepF101->setDataSource($ds101);
		$this->RepF101->dataBind();

		if ($unimarc->existsField('102'))
			$this->F102a->setSelectedValue(strtolower($unimarc->getSubField("102",'a')));

		if ($unimarc->existsField('110')) {
			$f110 = $unimarc->getField("110");
			$this->F110a0->Value = $f110->getCDFField('a',0);
			$this->F110a1->Value = $f110->getCDFField('a',1);
		}

		if($unimarc->existsField('115')) {
			$f115 = $unimarc->getField("115");
			$this->F115a0->Value = $f115->getCDFField('a',0);
			$this->F115a3->Text = $f115->getCDFField('a',3);
			$this->F115a4->Value = $f115->getCDFField('a',4);
			$this->F115a5->Value = $f115->getCDFField('a',5);
		}

		$title = $unimarc->getTitle();
		$this->F200->setText(trim($title['nst']).'*'.trim($title['txt'][0]));
		$editions = array();
		for ($i=0; ($e=$unimarc->getEdition($i))!=''; ++$i)
			$editions[] = array('txt'=>$e);
		$this->RepF205->setDataSource($editions);
		$this->RepF205->dataBind();

		$areas = array();
		$cnt = $unimarc->getFieldCount(206);
		for ($i=0; $i<$cnt; ++$i)
			$areas[] = array('field'=>206,'value'=>$unimarc->getSubField(206,'a',$i));
		$cnt = $unimarc->getFieldCount(207);
		for ($i=0; $i<$cnt; ++$i)
			$areas[] = array('field'=>207,'value'=>$unimarc->getSubField(207,'a',$i));
		$cnt = $unimarc->getFieldCount(208);
		for ($i=0; $i<$cnt; ++$i)
			$areas[] = array('field'=>208,'value'=>$unimarc->getSubField(208,'a',$i));
		$cnt = $unimarc->getFieldCount(230);
		for ($i=0; $i<$cnt; ++$i)
			$areas[] = array('field'=>230,'value'=>$unimarc->getSubField(230,'a',$i));
		if (count($areas)<1) {
			$areas[] = array('field'=>null,'value'=>'');
		}
		$this->RepF2XX->setDataSource($areas);
		$this->RepF2XX->dataBind();

		$publications = array();
		foreach ($unimarc->getPublications(true) as $p) {
			$publications[] = $p;
		}
		$this->RepF210->setDataSource($publications);
		$this->RepF210->dataBind();

		$physdesc = array();
		for ($i=0; ($p=$unimarc->getPhysicalDesc($i))!=''; ++$i)
			$physdesc[] = array('txt'=>$p);
		$this->RepF215->setDataSource($physdesc);
		$this->RepF215->dataBind();

		$series = array();
		$seriecnt = $unimarc->getFieldCount(225);
		if ($seriecnt > 0) {
			for ($i=0; $i<$seriecnt; ++$i) {
				$series[] = array('desc'=>$unimarc->getSubField(225,'a',$i),
					'num'=>$unimarc->getSubField(225,'v',$i));
			}
		} else {
			$series[] = array('desc'=>'','num'=>'');
		}
		$this->RepF225->setDataSource($series);
		$this->RepF225->dataBind();

		$ds5xx = array();
		$ds5xx = array();
		for ($field=500; $field<600; ++$field) {
			if ($unimarc->existsField($field)) {
				$fCount = $unimarc->getFieldCount($field);
				for($i = 0; $i < $fCount; $i++) {
					$ds5xx[] = array('field'=> $field,'value'=> $unimarc->getSubField($field,'a',$i));
				}
			}
		}
		$this->RepF5XX->setDataSource($ds5xx);
		$this->RepF5XX->dataBind();

		$ds3xx = array();
		for ($field=300; $field<400; ++$field) {
			if ($unimarc->existsField($field)) {
				$fCount = $unimarc->getFieldCount($field);
				for($i = 0; $i < $fCount; $i++) {
					$ds3xx[] = array('NoteNumber'=> $field,'NoteValue'=> $unimarc->getSubField($field,'a',$i));
				}
			}
		}
		$this->RepF3XX->setDataSource($ds3xx);
		$this->RepF3XX->dataBind();

		if($unimarc->existsField(206)) {

		}

		if($unimarc->existsField(207)) {

		}

		if($unimarc->existsField(208)) {

		}

		if($unimarc->existsField(230)) {

		}

		$this->refreshISBD();
		$this->populateLinkDropDown();
	}

	public function Leggere() {
		$ean = trim($this->EAN->getSafeText());
		$xmlString = file_get_contents($this->leggereSrv.$ean);
		try {
			$xml = new SimpleXMLElement($xmlString);
			$man = $this->initImportedManifestation();
			$uni = new UnimarcRecord();
			$f073 = new UnimarcField('073');
			$f073->addSubField('a',$ean);
			$f073->addSubField('d',$xml->Prezzo);
			$uni->addField($f073);
			$f101 = new UnimarcField('101');
			$f101->addSubField('a','ita');
			$uni->addField($f101);
			$f102 = new UnimarcField('102');
			$f102->addSubField('a','it');
			$uni->addField($f102);
			$f300 = new UnimarcField('300');
			$f300->addSubField('a',"Fa parte di: ".$xml->FaParteDi.". Tit. orig.: ".$xml->TitoloOriginale);
			$uni->addField($f300);
			if(trim($xml->FormulazioneDiResponsabilità) == '')
				$uni->setTitle($xml->Titolo);
			else
				$uni->setTitle($xml->FormulazioneDiResponsabilità);
			$uni->setPublication($xml->Pubblicazione);
			$uni->setPhysicalDesc($xml->DescrizioneFisica);
			$uni->setEdition($xml->Edizione);
			$uni->setSerie($xml->CollanaBibliografica);
			$man->setUnimarc($uni->getTXTCompact());
			$man->save();
			$this->completeFromLeggere($man,$xml);
			$man->doIndex();
			$this->gotoPage('Catalog.EditRecord',array('manifestationId' => $man->getManifestationId()));
		} catch (Exception $e) {
			Prado::log('Eccezione import Leggere: '.$e->getMessage());
		}
}
}
