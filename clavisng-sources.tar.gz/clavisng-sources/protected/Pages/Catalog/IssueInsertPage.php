<?php
/**
 * IssueInsertPage class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Pages.Catalog
 */

/**
 * IssueInsertPage Class
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Pages.Catalog
 * @since 2.0
 */
class IssueInsertPage extends ClavisPage
{
	/**
	 * Name of the module where we are.
	 *
	 * @var string
	 */
	public $_module = 'CATALOG';
	/**
	 * @var Issue
	 */
	private $_issue = null;

	public function onInit($param)
	{
		parent::onInit($param);

		if (!$this->getIsPostBack())
		{
			$issue = null;
			$issue_id = intval($this->getRequest()->itemAt('issueId'));
			$manif_id = intval($this->getRequest()->itemAt('manifestationId'));
			if ($issue_id > 0)
			{
				$issue = IssueQuery::create()->findPk($issue_id);
				if (!$issue instanceof Issue)
				{
					$this->writeMessage(Prado::localize('Il fascicolo con id [{id}] non esiste', array('id' => $issue_id)), ClavisMessage::ERROR);
					$this->gotoPage('Catalog.Record');
				}
			}

			$this->UpdateData->setObject($issue);

			if (is_null($issue))
			{
				$issue = new Issue();
				if ($manif_id > 0)
					$issue->setManifestationId($manif_id);
			}
			$this->setIssue($issue);
		}
	}

	/**
	 * On the onLoad we populate the textbox "Title" if the proper
	 * value is passed as a get parameter, and we must initialize
	 * EACH instance of repeatable list in the page (by $this->addItem).
	 *
	 * @param unknown_type $param
	 */
	public function onLoad($param)
	{
		parent::onLoad($param);
		if (!$this->getIsPostBack())
		{
			$this->populateForm();
			$this->dataBind();
		}
		$this->UpdateData->setObject($this->getIssue());
	}

	public function onCancel($sender, $param)
	{
		if ($this->isReturnPageEnabled())
			$this->returnPage();
		$this->gotoPage('Catalog.IssueViewPage', array('id' => $this->_issue->getIssueId()));
	}

	public function onSave($sender, $param)
	{
		try
		{
			if ($this->getIsValid())
			{
				$this->issueSave();
				$this->gotoPage('Catalog.IssueViewPage', array('id' => $this->_issue->getIssueId()));
			}
		}
		catch (IssueException $ie)
		{
			if ($ie->getCode() == 1)
				$this->writeMessage(Prado::localize('Non posso cancellare fascicoli con esemplari in arrivo'), ClavisMessage::ERROR);
			Prado::log(__METHOD__ . " " . __LINE__ . " IssueException " . $ie->getMessage());
		}
		catch (Exception $ge)
		{
			Prado::log(__METHOD__ . " " . __LINE__ . " excpt " . $ge->getMessage() . "\nPlease check also the methods of a custom ObjectTriggers class if exist");
			throw $ge;
		}
	}

	public function onApply($sender, $param)
	{
		if ($this->getIsValid())
			$this->issueSave();
	}

	protected function issueSave()
	{
		$this->_issue->setIssueNumber($this->IssueNumber->getSafeText());
		$this->_issue->setIssueYear($this->IssueYear->getSafeText());
		$this->_issue->setIssueVolume($this->IssueVolume->getSafeText());
		$this->_issue->setIssueType($this->IssueType->getSelectedValue());
		$this->_issue->setIssueDate($this->IssueDate->getTimestamp());
		$this->_issue->setStartNumber($this->StartNumber->getSafeText());
		$this->_issue->setEndNumber($this->EndNumber->getSafeText());
		$this->_issue->setIssueNote($this->IssueNote->getSafeText());
		$this->_issue->save();

		$this->setIssue($this->_issue);

		if ($this->getRequest()->itemAt('issueId'))
		{
			ChangelogPeer::logAction($this->_issue, ChangelogPeer::LOG_UPDATE, $this->getUser());
			$this->writeMessage(Prado::localize('Fascicolo modificato con successo'), ClavisMessage::INFO);
		}
		else
		{
			ChangelogPeer::logAction($this->_issue, ChangelogPeer::LOG_CREATE, $this->getUser());
			$this->writeMessage(Prado::localize('Fascicolo inserito con successo'), ClavisMessage::INFO);
		}
	}

	public function populateForm()
	{
		if ($this->_issue === null)
			return;

		$this->UpdateData->setObject($this->_issue);

		$manifestation = ManifestationPeer::retrieveByPK($this->_issue->getManifestationId());
		$this->ManifestationView->setManifestation($manifestation);

		$this->IssueNumber->setText($this->_issue->getIssueNumber());
		$this->IssueYear->setText($this->_issue->getIssueYear());
		$this->IssueVolume->setText($this->_issue->getIssueVolume());
		$this->IssueType->setSelectedValue($this->_issue->getIssueType());
		$this->IssueDate->setTimestamp($this->_issue->getIssueDate('U'));
		$this->StartNumber->setText($this->_issue->getStartNumber());
		$this->EndNumber->setText($this->_issue->getEndNumber());
		$this->IssueNote->setText($this->_issue->getIssueNote());

		$this->AttachList->setObjectClass('Issue');
		$this->AttachList->setObjectId($this->_issue->getIssueId());
	}

	/**
	 * setter
	 *
	 * @param Issue $issue
	 */
	public function setIssue($issue)
	{
		$this->_issue = $issue;
		$this->setViewState('issue', $issue, null);
	}

	/**
	 * getter
	 *
	 * @return Issue
	 *
	 */
	public function getIssue()
	{
		if (is_null($this->_issue))
			$this->_issue = $this->getViewState('issue', null);
		return $this->_issue;
	}

	public function globalEditCancel()
	{
		
	}
	
}