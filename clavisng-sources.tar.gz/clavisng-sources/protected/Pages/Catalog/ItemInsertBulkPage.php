<?php
/**
 * ItemInsertBulkPage class file
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 */

/**
 * ItemInsertBulkPage Class
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2008 ePortal Technologies
 * @copyright Copyright &copy; 2009 Comperio srl
 * @version 2.7
 * @package Pages.Catalog
 * @since 2.4.3
 */
class ItemInsertBulkPage extends ClavisPage
{
	const STARTITEMNUM = 0;
	const MAXITEMNUM = 50;
	
	public $_module = 'CATALOG';
	private $_storedDatasourceSessionName;
	
	public $_systemCurrency;

	private function initVars()
	{
		$uniqueId = $this->getUniqueID();
		$this->_storedDatasourceSessionName = "storedDatasourceSessionName" . $uniqueId;
		
		$this->_systemCurrency = ClavisParamQuery::getParam('CLAVISPARAM','SystemCurrency');
	}
	
	public function onInit($param)
	{
		parent::onInit($param);
		$this->initVars();

		if (!$this->getIsPostBack() && !$this->getIsCallback())   // first time only (page init)
		{
			$this->ForceActualLibraryCheck->setChecked(false);
			$this->resetInputMode();    // initial mode to 'true', for creating new items
			$this->resetBarcodeMode();	// initial mode to 'false', for inserting inv.ser/inv.number and not barcode
			$this->resetStoredDataSource();
			$this->resetManifestation();
			$this->ShelfId->setValue(0);
			$this->RealTotNum->setText("0");
			$this->CurrencyValueTextBox->setText('');
			$this->InventoryValueTextBox->setText('');
			$this->doResetShelf();
			$this->doResetSupplier();
			$this->MediaType->setDataSource(LookupValuePeer::getLookupClassValues('ITEMMEDIATYPE',
				true, '('.Prado::localize('dalla notizia').')' )  );
			$this->MediaType->dataBind();

			$this->RecordChooserPanel->setCssClass('panel_on');
			$this->ReloadPanel->setCssClass('panel_off');
			$this->GotoShelfPanel->setCssClass('panel_off');
			$this->PrintPanel->setCssClass('panel_off');
			
			$manifestationId = intval($this->getRequest()->itemAt('manId'));
			if ($manifestationId > 0)
			{
				$manifestation = ManifestationPeer::retrieveByPK($manifestationId);
		
				$this->RecordChooser->setManifestation($manifestation);
				$this->RecordChooser->ManifestationView->update($manifestationId);
		
				$this->drawAll($manifestationId);
			}
		}
	}

	public function onLoad($param)
	{
		parent::onLoad($param);
		
		if (!$this->getIsPostBack() && !$this->getIsCallback())   // first time only (page init)
		{
			$userShelfId = $this->getUser()->getActualShelfId();

			if (!is_null($userShelfId))
			{
				try
				{
					$this->doShelfChanged($userShelfId);
					
					$this->getPage()->writeMessage(Prado::localize("Impostato lo scaffale preferito dell'operatore a '{scaff}' (id={id})",
																		array(	'id' => $userShelfId,
																				'scaff' => ShelfPeer::getShelfName($userShelfId) )),
													ClavisMessage::INFO);
				}
				catch (Exception $e)
				{
					//Prado::log("Lo scaffale preferito con id=$userShelfId non esiste");
					//$myUser->setActualShelfId(null);
				}
			}
		}
	}
	
	public function onPreRender($param) 
	{
		parent::onPreRender($param);

		if (!$this->getIsPostBack() && !$this->getIsCallback())   // first time
		{
			$this->drawAll();
		}
		else   // further visits
		{
			if (count($this->getStoredDataSource()) == 0)
			{
				$this->drawAll(intval($this->RecordChooser->getManifestationId()));
			}
		}
	}
	
	public function onToggleBarcode($sender, $param)
	{
		$this->InventorySerieColumn->setVisible(!$this->InventorySerieColumn->getVisible());
		$this->BarcodeColumn->setVisible(!$this->BarcodeColumn->getVisible());

		$this->setBarcodeMode(!$this->getBarcodeMode());	// invert barcodemode state
		
//		if ($this->InputGridPanel->getCssClass() != "panel_off")
//			$this->InputGridPanel->render($param->getNewWriter());
	}
	
	public function resetManifestation()
	{
		$this->RecordChooser->clean();
	}
	
	public function resetStoredDataSource()
	{
		$this->setStoredDataSource(array());
	}
	
	public function getStoredDataSource()
	{
		return $this->getApplication()->getSession()->itemAt($this->_storedDatasourceSessionName, null);
	}

	public function setStoredDataSource($param = null)
	{
		$this->getApplication()->getSession()->add($this->_storedDatasourceSessionName, $param, null);
	}
	
	public function resetInputMode($mode = true)
	{
		$this->setInputMode($mode);
	}
	
	public function setInputMode($mode = true)
	{
		$this->setViewState('BulkInputMode', $mode, true);
	}
	
	public function getInputMode()
	{
		$mode = $this->getViewState('BulkInputMode', true);
		
		if (($mode != true) && ($mode != false))
			$mode = true;
		
		return $mode;
	}
	
	public function resetBarcodeMode($mode = false)
	{
		$this->setBarcodeMode($mode);
	}
	
	public function setBarcodeMode($mode = false)
	{
		$this->setViewState('BulkBarcodeMode', $mode, false);
	}
	
	public function getBarcodeMode()
	{
		$mode = $this->getViewState('BulkBarcodeMode', false);
		
		if (($mode != true) && ($mode != false))
			$mode = false;
		
		return $mode;
	}
	
	private function drawColumns($inputModeView, $barcodeMode = false)
	{
		$this->NewItemsColumn->setVisible($inputModeView);
		$this->InventorySerieColumn->setVisible($inputModeView && !$barcodeMode);
		$this->BarcodeColumn->setVisible($inputModeView && $barcodeMode);
		$this->CollocationComboColumn->setVisible($inputModeView);
		$this->ItemStatusColumn->setVisible($inputModeView);
		$this->LoanClassColumn->setVisible($inputModeView);
		$this->ReprintColumn->setVisible($inputModeView);

		// visible only after creation
		$this->NewCreatedColumn->setVisible(!$inputModeView);
	}
	
	private function drawAll($manifestationId = null)
	{
		$valid = $this->drawButtonPanel($manifestationId);
		if ($valid)
		{
			// visibility/shading of columns
			$this->drawColumns($this->getInputMode(), $this->getBarcodeMode());

			$this->InputGridPanel->setCssClass("panel_on");
			$this->ShelfPanel->setCssClass("panel_on_inline");
			$this->HomeOptionPanel->setCssClass("panel_on_inline");
			$this->CurrencyValuePanel->setCssClass("panel_on_inline");
			$this->InventoryValuePanel->setCssClass("panel_on_inline");
			$this->SupplierPanel->setCssClass("panel_on_inline");
			$this->ItemMediaPanel->setCssClass("panel_on_inline");
			$this->ItemSourcePanel->setCssClass("panel_on_inline");
			
			$this->drawInputGrid();
		}
		else
		{
			$this->InputGridPanel->setCssClass("panel_off");
			$this->ShelfPanel->setCssClass("panel_off");
			$this->HomeOptionPanel->setCssClass("panel_off");
			$this->CurrencyValuePanel->setCssClass("panel_off");
			$this->InventoryValuePanel->setCssClass("panel_off");
			$this->SupplierPanel->setCssClass("panel_off");
			$this->ItemMediaPanel->setCssClass("panel_off");
			$this->ItemSourcePanel->setCssClass("panel_off");
		}

		if ($this->getIsCallback())
		{
			if ($this->InputGridPanel->getCssClass() != "panel_off")
				$this->InputGridPanel->render($this->createWriter());

			if ($this->ShelfPanel->getCssClass() != "panel_off")
				$this->ShelfPanel->render($this->createWriter());
			
			if ($this->HomeOptionPanel->getCssClass() != "panel_off")
				$this->HomeOptionPanel->render($this->createWriter());
			
			if ($this->CurrencyValuePanel->getCssClass() != "panel_off")
				$this->CurrencyValuePanel->render($this->createWriter());

			if ($this->InventoryValuePanel->getCssClass() != "panel_off")
				$this->InventoryValuePanel->render($this->createWriter());
			
			if ($this->SupplierPanel->getCssClass() != "panel_off")
				$this->SupplierPanel->render($this->createWriter());
			
			if ($this->ItemMediaPanel->getCssClass() != "panel_off")
				$this->ItemMediaPanel->render($this->createWriter());

			if ($this->ItemSourcePanel->getCssClass() != "panel_off")
				$this->ItemSourcePanel->render($this->createWriter());
		}
	}
	
	private function drawButtonPanel($paramManifestationId = null)
	{
		$chosen = false;
		$valid = false;
	
		$paramManifestation = null;
		$paramManifestationId = intval($paramManifestationId);
		if ($paramManifestationId > 0)
			$paramManifestation = ManifestationPeer::retrieveByPK($paramManifestationId);
		if ($paramManifestation instanceof Manifestation)
			$manifestation = $paramManifestation;
		else
			$manifestation = $this->RecordChooser->getManifestation();
	
		if ($manifestation instanceof Manifestation)
		{	
			$chosen = true;
			
			if ($manifestation->canHaveItems())
				$valid = true;
		}

		if ($chosen)
		{
			if ($valid)
			{
				$this->ButtonPanel->setCssClass('panel_on_inline');
			}
			else
			{
				$this->getPage()->writeMessage(Prado::localize("La notizia selezionata non è usabile"),
													ClavisMessage::WARNING);

				$this->RecordChooser->clean();
				$this->ButtonPanel->setCssClass('panel_off');
			}	
		}
		else
		{
			$this->RecordChooser->clean();
			$this->ButtonPanel->setCssClass('panel_off');
		}

		if ($this->getIsCallback())
			$this->ButtonPanel->render($this->createWriter());
		
		return $valid;   // we return the validity of the manifestation
	}
	
	public function onRedrawInputGrid($sender, $param)
	{
		$this->drawInputGrid(null, null, $param);
	}
	
	/**
	 * Here we draw the input grid (pre action) or the result of the
	 * items creation (post action), and output it to the online
	 * datagrid.
	 * 
	 * @param array $datasource
	 * @param boolean $inputMode
	 * @param TEventParameter $param
	 * @return type 
	 */
	private function drawInputGrid($datasource = array(), $inputMode = true, $param = null)
	{
		if (!is_bool($inputMode))
			$inputMode = true;
		
		$this->setInputMode($inputMode);
		
		$manifestation = $this->RecordChooser->getManifestation();
		
		if (!($manifestation instanceof Manifestation))
		{
			$this->getPage()->writeMessage(Prado::localize("Notizia scelta non valida"),
											ClavisMessage::ERROR);
			return false;
		}
		
		$class = $manifestation->getClass();
		$forceOwnerLibrary = $this->ForceOwnerLibraryCheck->getChecked();

		if ($forceOwnerLibrary)
		{
			$actualLibrary = $this->getUser()->getActualLibrary();
			$forceInventorySeries = $actualLibrary->getInventorySeries2Array();
		}
		
		if ($inputMode)   // initial mode
		{
			if (count($datasource) == 0)   // first population
			{
				foreach (LibraryPeer::getLibrariesHash(null, null, true, true) as $libraryId => $libraryLabel)
				{
					if ($forceOwnerLibrary)
					{
						$inventorySeries = $forceInventorySeries;
					}
					else
					{
						$library = LibraryQuery::create()->findPk($libraryId);
					
						if ($library instanceof Library)
						{
							$inventorySeries = $library->getInventorySeries2Array();
						}
						else
						{
							$inventorySeries = array();
						}
					}

					$datasource[] = array(	'LibraryId' => $libraryId,
											'LibraryLabel' => $libraryLabel,

											'ItemsNumber' => self::STARTITEMNUM,
						
											'InventorySeries' => $inventorySeries,
											'SelectedInventorySeries' => 0,
											'Barcodes' => '',
						
											'SelectedSection' => 0,
											'Collocation' => $class,
											'Specification' => "",
											'Sequence1' => "",
											'Sequence2' => "",
											'Reprint' => "",

											'SelectedItemStatus' => ItemStatus::ITEMSTATUS_ONSHELF,
											'SelectedLoanClass' => ItemPeer::LOANCLASS_AVAILABLE,

											'RepeaterCreated' => array(), 
											'CreatedIds' => array() );
				}
			}
		}
		else   // post creation mode
		{
			if (count($datasource) > 0)
			{
				$this->drawColumns(false);
				
				///$this->RecordChooserPanel->setCssClass('panel_off');
				$this->ButtonPanel->setCssClass('panel_off');
				$this->ShelfPanel->setCssClass('panel_off');
				$this->HomeOptionPanel->setCssClass('panel_off');
				
				$this->CurrencyValuePanel->setCssClass('panel_off');
				$this->InventoryValuePanel->setCssClass('panel_off');
				
				$this->SupplierPanel->setCssClass('panel_off');
				$this->ItemMediaPanel->setCssClass('panel_off');
				$this->ItemSourcePanel->setCssClass('panel_off');
				
				$this->ReloadPanel->setCssClass('panel_on');
				$this->PrintPanel->setCssClass('panel_on_inline');
				
				foreach ($datasource as $index => $row) 
				{
					$repeaterCreated = array();
					if (array_key_exists('CreatedItems', $row))
					{
						foreach ($row['CreatedItems'] as $itemId => $itemData)
						{
							$barcode = trim($itemData['barcode']);
							if ($barcode == '')
								$barcode = '---';
							
							$itemStatusString = trim($itemData['itemStatusString']);
							if ($itemStatusString != '')
								$itemStatusString = '(' . $itemStatusString . ')';
							
							$loanClassString = trim($itemData['loanClassString']);
							if ($loanClassString == '')
								$loanClassString = Prado::localize('<stato indefinito>');
							
							$itemStatus = $loanClassString . ' ' . $itemStatusString;
							$collocationCombo = trim($itemData['collocationCombo']);
														
							$destination = trim($itemData['destination']);
							if ($destination != '')
								$destination = ', &nbsp;&nbsp;['
												. Prado::localize("l'esemplare e' in 'PRONTO AL TRANSITO DI RIENTRO' con destinazione {destination}",
																	array('destination' => $destination))
												. ']';
							
							$text = $itemData['completeInventory'];
							if ((trim($text) == '') || ($text == "0"))
								$text = Prado::localize('barcode: {barcode}',array('barcode' => $itemData['barcode']));
							if (trim($text) == '')
								$text = Prado::localize('nuovo esemplare');


							if ($collocationCombo != "")
								$text .= " (" . $collocationCombo . ")";

							if ($itemStatus != "")
								$text .= " [" . $itemStatus . "]";
							
							$repeaterCreated[] = array(	'itemId' => $itemId,
														'text' => $text,
														'toolTip' => '['. Prado::localize("clicca per modificare l'esemplare") . ']&nbsp;&nbsp;'
																. Prado::localize('titolo') .': '. $itemData['title'] .', &nbsp;&nbsp;'
																. Prado::localize('barcode') .': '. $barcode .', &nbsp;&nbsp;'
																. Prado::localize('serie inv.- num.inv') .': '. $itemData['completeInventory'] .', &nbsp;&nbsp;' 
																. $itemStatus 
																. $destination );
						}
					}

					$datasource[$index]['RepeaterCreated'] = $repeaterCreated;
					$datasource[$index]['InventorySeries'] = array();
				}
			
				if ((count($datasource) > 0) && (intval($this->ShelfId->getValue()) > 0))
					$this->GotoShelfPanel->setCssClass('panel_on_inline');
			}
			else
			{
				$this->getPage()->writeMessage(Prado::localize("Errore nei dati dopo la creazione di nuovi esemplari: insieme di dati vuoto"),
												ClavisMessage::ERROR);
				return false;
			}
		}
		
		$this->InputGrid->setDataSource($datasource);
		$this->InputGrid->dataBind();
		
		$this->EmptyLabel->setVisible(count($datasource) == 0);
		
		$this->setStoredDataSource($datasource);
		
		if ($this->getIsCallback())
		{
			if ($param instanceof TEventParameter && false)
				$writer = $param;
			else
				$writer = $this->createWriter();
			
			if (!is_null($writer))
				$this->InputGridPanel->render($writer);
		}
	}
	
	public function onCreateItems($sender, $param)
	{
		ini_set("memory_limit", "700M");
		set_time_limit(0);
				
		$this->getPage()->cleanMessageQueue();
		
		$manifestation = $this->RecordChooser->getManifestation();
		if (!($manifestation instanceof Manifestation))
		{
			$this->getPage()->writeMessage(Prado::localize("Notizia scelta non valida"),
											ClavisMessage::ERROR);
			return false;
		}
		
		$shelf = null;
		$shelfId = intval($this->ShelfId->getValue());
		if ($shelfId > 0)
			$shelf = ShelfQuery::create()
						->findPk($shelfId);
		
		if (!($shelf instanceof Shelf))
			$shelfId = 0;

		$currencyValue = ClavisBase::numberFormat($this->CurrencyValueTextBox->getSafeText(), '#.00', null, null, false);
		$inventoryValue = ClavisBase::numberFormat($this->InventoryValueTextBox->getSafeText(), '#.00', null, null, false);
		
		$supplierId = intval($this->ItemSupplierId->getValue());
		$source = $this->ItemSource->getSelectedValue();
		if ($this->MediaType->getSelectedIndex() == 0)
			$mediaType = Clavis::BibtypeToItemmedia($manifestation->getBibType());
		else
			$mediaType = $this->MediaType->getSelectedValue();
		
		$storedDataSource = $this->getStoredDataSource();
		$readData = array();
		foreach ($this->InputGrid->getItems() as $rowItemIndex => $rowItem)
		{	
			if (	$rowItem->ItemType == 'Item'		
					|| $rowItem->ItemType == 'AlternatingItem' )
			{
				$libraryId = intval($rowItem->LibraryColumn->LibraryId->getValue());
				if ($libraryId == 0)
					continue;
				
				$libraryLabel = $rowItem->LibraryColumn->LibraryLabel->getText();
				$rowItemsNumber = trim($rowItem->NewItemsColumn->RealNewItemsNumber->getText());
				
				if ($this->getBarcodeMode())
				{
					$selectedInventorySeries = "";
					$barcodes = explode(',', $rowItem->BarcodeColumn->Barcode->getSafeText());
				}
				else
				{
					$selectedInventorySeries = $rowItem->InventorySerieColumn->InventorySerie->getSelectedValue();
					$barcodes = array();
				}
				
				$selectedSection = $rowItem->CollocationComboColumn->Section->getSelectedIndex();
				if ($selectedSection == '-1')
					$selectedSection = '';
				else 
					$selectedSection = $rowItem->CollocationComboColumn->Section->getSelectedValue();
				
				$collocation = trim($rowItem->CollocationComboColumn->Collocation->getSafeText());
				$specification = trim($rowItem->CollocationComboColumn->Specification->getSafeText());
				$sequence1 = trim($rowItem->CollocationComboColumn->Sequence1->getSafeText());
				$sequence2 = trim($rowItem->CollocationComboColumn->Sequence2->getSafeText());
				$reprint = trim($rowItem->ReprintColumn->Reprint->getSafeText());

				$selectedItemStatus = $rowItem->ItemStatusColumn->ItemStatus->getSelectedIndex();
				if ($selectedItemStatus == '-1')
					$selectedItemStatus = '';
				else 
					$selectedItemStatus = $rowItem->ItemStatusColumn->ItemStatus->getSelectedValue();

				$selectedLoanClass = $rowItem->LoanClassColumn->LoanClass->getSelectedIndex();
				if ($selectedLoanClass == '-1')
					$selectedLoanClass = '';
				else 
					$selectedLoanClass = $rowItem->LoanClassColumn->LoanClass->getSelectedValue();
				
				if ($rowItemsNumber > 0)   // everything is ok
				{				
					$readData[] = array('LibraryId' => $libraryId,
										'LibraryLabel' => $libraryLabel,
										'ItemsNumber' => $rowItemsNumber,
										
										'SelectedInventorySeries' => $selectedInventorySeries,
										'Barcodes' => $barcodes,
						
										'SelectedSection' => $selectedSection,
										'Collocation' => $collocation,
										'Specification' => $specification,
										'Sequence1' => $sequence1,
										'Sequence2' => $sequence2,
										'Reprint' => $reprint,
										
										'SelectedItemStatus' => $selectedItemStatus,
										'SelectedLoanClass' => $selectedLoanClass,
										'CreatedItems' => array() );
					
					// do we need these, here below ? ........
					$storedDataSource[$rowItemIndex]['ItemsNumber'] = $rowItemsNumber;
					
					$storedDataSource[$rowItemIndex]['SelectedInventorySeries'] = $selectedInventorySeries;
					$storedDataSource[$rowItemIndex]['Barcodes'] = $barcodes;
					
					$storedDataSource[$rowItemIndex]['SelectedSection'] = $selectedSection;
					$storedDataSource[$rowItemIndex]['Collocation'] = $collocation;
					$storedDataSource[$rowItemIndex]['Specification'] = $specification;
					$storedDataSource[$rowItemIndex]['Sequence1'] = $sequence1;
					$storedDataSource[$rowItemIndex]['Sequence2'] = $sequence2;
					$storedDataSource[$rowItemIndex]['Reprint'] = $reprint;

					$storedDataSource[$rowItemIndex]['SelectedItemStatus'] = $selectedItemStatus;
					$storedDataSource[$rowItemIndex]['SelectedLoanClass'] = $selectedLoanClass;
				}
				else
				{
					unset ($storedDataSource[$rowItemIndex]);         // do we need this? ....
				}
			}  // end of the 'if we are in a correct row'
			
			unset($rowItem);  // we are paranoid .....
		}  // end of foreach cycle that reads a row from the screen input
		
		if (count($readData) == 0)
		{
			$this->getPage()->enqueueMessage(Prado::localize("Attenzione: nessun esemplare da creare"),
											ClavisMessage::WARNING);
		}
		else   // creation is possible
		{
			$created = 0;
			$errors = 0;
			$shelfAdded = 0;

			$cloneReadData = $readData;
			foreach ($cloneReadData as $rowIndex => $rowLibrary)		// cycle on libraries ***
			{
				$createdData = array();

				/**
				 * $rowLibrary is a row of the read table. It's an array, with read fields
				 */
				$createdItemsArray = $this->createItem(	$rowLibrary, 
														$manifestation,
														$mediaType,
														$shelfId,
														$currencyValue,
						
														$inventoryValue,
														$supplierId,
														$source);
				
				if (is_array($createdItemsArray) && (count($createdItemsArray) == 3))
				{
					if (array_key_exists('createdData', $createdItemsArray))
					{
						$createdData = $createdItemsArray['createdData'];
						$created += count($createdData);
					}

					if (array_key_exists('errors', $createdItemsArray))
						$errors += (int) $createdItemsArray['errors'];
					
					if (array_key_exists('shelfAdded', $createdItemsArray) && ($shelfId > 0))
						$shelfAdded += (int) $createdItemsArray['shelfAdded'];
				}
				else
				{
					$errors++;
				}

				$readData[$rowIndex]['CreatedItems'] = $createdData;
			}		// end of foreach cycle for real item creation (by calling private method) ***

			$this->getPage()->enqueueMessage(($created == 1)
					? Prado::localize("Creato 1 esemplare")
					: Prado::localize("Creati {num} esemplari",array('num' => $created)),
				($created > 0 ? ClavisMessage::CONFIRM : ClavisMessage::WARNING));
			
			if ($errors > 0)
				$this->getPage()->enqueueMessage(Prado::localize("Sono presenti {num} errori nella creazione di esemplari",
																	array('num' => $errors)),
													ClavisMessage::WARNING);
			
			if ($shelfAdded > 0)
				$this->getPage()->enqueueMessage(Prado::localize("Sono stati aggiunti {num} esemplari nello scaffale '{shelf}'",
																	array(	'num' => $shelfAdded, 
																			'shelf' => $shelf->getShelfCompleteName(', '))),
													ClavisMessage::CONFIRM);
		}

		$this->getPage()->flushMessage();
		
		$this->setStoredDataSource($readData);  //$storedDataSource);   did i need it ? .......
		$this->drawInputGrid($readData, false, $param);    // second parameter is for input mode false (post creation)
	}
	
	private function createItem(	$data = array(), 
									$manifestation = null,
									$mediaType = null,
									$shelfId = 0,
									$currencyValue = null,
			
									$inventoryValue = null,
									$supplierId = null,
									$source = null)
	{
		$errorArray = array('createdData' => array(),
							'errors' => 1,
							'shelfAdded' => 0 );
		
		if (count($data) == 0)
			return $errorArray;
		
		if (!($manifestation instanceOf Manifestation))
			return $errorArray;
		
		$shelfId = intval($shelfId);
		$supplierId = intval($supplierId);
		
		if (is_null($mediaType) 
				|| ($mediaType == ""))
			$mediaType = Clavis::BibtypeToItemmedia($manifestation->getBibType());
		
		try
		{
			$libraryId = intval($data['LibraryId']);
			
			if ($libraryId == 0)
				return $errorArray;
			
			/** Logic for attribution of the actual library of newly
			 * created items, and whether they have to be put in
			 * ready for transit to home (if they're not at home)
			 */
			if ($this->ForceActualLibraryCheck->getChecked())
			{
				$actualLibrary = $this->getUser()->getActualLibraryId();
			}
			else
			{
				$actualLibrary = $libraryId;
			}
								
			if ($actualLibrary != $libraryId)
			{
				$loanStatus = ItemPeer::LOANSTATUS_READYFORTRANSITTOHOME;
				$deliveryLibraryId = $libraryId;
			}
			else
			{
				$loanStatus = ItemPeer::LOANSTATUS_AVAILABLE;
				$deliveryLibraryId = null;
			}
			/* end */
			
			if ($this->ForceOwnerLibraryCheck->getChecked())
			{
				$ownerlLibraryId = $this->getUser()->getActualLibraryId();
			}
			else
			{
				$ownerlLibraryId = $libraryId;
			}
			
			$itemsNumber = intval($data['ItemsNumber']);
			
			if ($itemsNumber == 0)
			{
				// nothing to do or done .....
				return array(	'createdData' => array(),
								'errors' => 0,
								'shelfAdded' => 0 );
			}
			
			if (($itemsNumber > self::MAXITEMNUM)
					|| ($itemsNumber < self::STARTITEMNUM))
				return $errorArray;
			
			$createdData = array();
			$errors = 0;
			$shelfAdded = 0;
			
			for ($index = 0; $index < $itemsNumber; $index++)
			{
				$item = new Item();
				
				$item->setOwnerLibraryId($ownerlLibraryId);
				$item->setHomeLibraryId($libraryId);
				$item->setActualLibraryId($actualLibrary);
				$item->setDeliveryLibraryId($deliveryLibraryId);
				
				$item->setManifestation($manifestation);
				$item->setTitle($manifestation->getTitle());
				$item->setManifestationDewey($manifestation->getClass());
				$item->setItemMedia($mediaType);
				$item->setItemSource($source);

				$item->setOpacVisible(true);
                
				$itemStatus = $data['SelectedItemStatus'];
				
				if ($itemStatus == '')
					$itemStatus = ItemStatus::ITEMSTATUS_ONSHELF;
				
				$item->setItemStatus($itemStatus);

				$loanClass = $data['SelectedLoanClass'];
				
				if ($loanClass == '')
					$loanClass = ItemPeer::LOANCLASS_AVAILABLE;
				
				$item->setLoanClass($loanClass);
				$item->setLoanStatus($loanStatus);
				$inventorySerieId = $data['SelectedInventorySeries'];
				$item->setInventorySerieId($inventorySerieId);

				if ($inventorySerieId != "")	// inventory case
				{
					$invNumber = InventorySeriePeer::calculateNextInventoryCounter($inventorySerieId, $ownerlLibraryId);
					
					if ($invNumber == false) 
						$invNumber = "";
					
					$barcode = "";
				}
				else	// barcode case
				{
					$invNumber = "";
					
					if (array_key_exists('Barcodes', $data))
					{
						$barcodes = $data['Barcodes'];
						
						if (array_key_exists($index, $barcodes))
						{
							$barcode = $barcodes[$index];
							
							if (!is_null($barcode) 
									&& ($barcode != ""))
								$item->setBarcode($barcode);
						}
					}
				}
				
				$item->setInventoryNumber($invNumber);
				$item->setSection($data['SelectedSection']);
				$item->setCollocation($data['Collocation']);
				$item->setSpecification($data['Specification']);
				$item->setSequence1($data['Sequence1']);
				$item->setSequence2($data['Sequence2']);
				$item->setReprint($data['Reprint']);
				$item->setInventoryDate(time());
				
				$item->setCurrency($this->_systemCurrency);
				$item->setCurrencyValue($currencyValue);
				$item->setInventoryValue($inventoryValue);
				
				$item->setDateDiscarded(null);
				
				if ($supplierId > 0)
					$item->setSupplierId($supplierId);
				
				$returnValue = $item->save();

				if ($returnValue == 1)   // save operation, and check if it worked
				{
					$item->reload(true);   /// for update the barcode, created by a sql trigger
					$itemId = $item->getItemId();
					
					// condensation ......
					$createdData[$itemId] = array(	'title' => $item->getCompleteTitle(),
													'barcode' => $item->getBarcode(),
													'completeInventory' => $item->getCompleteInventoryNumber(),
													'collocationCombo' => $item->getCollocationCombo(),
													'itemStatusString' => $item->getItemStatusString(),
													
													'loanClassString' => $item->getLoanClassString(),
													'destination' => ($item->getLoanStatus() == ItemPeer::LOANSTATUS_READYFORTRANSITTOHOME)
																		? $item->getHomeLibraryLabel()
																		: '' );
					
					ChangelogPeer::logAction(	$item, 
												ChangelogPeer::LOG_CREATE, 
												$this->getUser(),
												'Creato nuovo esemplare da pagina bulk, con id = ' . $itemId);
					
					if ($shelfId > 0)
					{
						if (ShelfPeer::addItemToShelf($shelfId, 'item', $itemId))
							$shelfAdded++;
					}
				}
				else
				{
					$errors++;
				}
				
				$item->clearAllReferences(true);	// we are paranoid
			}		// end of for cycle (creation of items)
			
			return array(	'createdData' => $createdData,
							'errors' => $errors,
							'shelfAdded' => $shelfAdded );
		}
		catch (Exception $e)
		{
			//throw($e);
			Prado::log('Exception in ItemInsertBulkPage->createItem(): '. Prado::varDump($e));			
			
			return $errorArray;
		}
	}
	
	/**
	 * We need this for populating some dropdownlists in each datagrid's row
	 * 
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onItemCreated($sender, $param)
	{
		$item = $param->Item;
		
		if ($item->ItemType == 'Item' 
			|| $item->ItemType == 'AlternatingItem' )
				
		{
			$data = $item->getData();
			if (!is_null($data))
			{
				if (array_key_exists('LibraryId', $data))
				{
					$libraryId = intval($data['LibraryId']);
					if ($libraryId > 0)
					{
						$item->CollocationComboColumn->Section->setLibraryId($libraryId);
						$item->CollocationComboColumn->Section->populate();
					}
				}
			}

			if ($this->getPage()->getIsPostBack()
					&& (get_class($item->LoanClassColumn->LoanClass->getDataSource()) != 'TMap'))
				$item->LoanClassColumn->LoanClass->populate();
			
			if ($this->getPage()->getIsPostBack()
					&& (get_class($item->ItemStatusColumn->ItemStatus->getDataSource()) != 'TMap'))
				$item->ItemStatusColumn->ItemStatus->populate();
		}
		elseif ($item->ItemType == 'Header')  // population of master controls, in the column headers
		{
			if (get_class($item->ItemStatusColumn->ItemStatusMaster->getDataSource()) != 'TMap')
				$item->ItemStatusColumn->ItemStatusMaster->populate();
			
			if (get_class($item->LoanClassColumn->LoanClassMaster->getDataSource()) != 'TMap')
				$item->LoanClassColumn->LoanClassMaster->populate();
		}
	}

	/**
	 * We need this for selecting something, if a selection exists,
	 * in some dropdownlists in each datagrid's row
	 * 
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onItemDataBound($sender, $param)
	{
		$item = $param->Item;
		
		if ($item->ItemType == 'Item' 
			|| $item->ItemType == 'AlternatingItem'	)
				
		{
			$data = $item->getData();
			if (!is_null($data))
			{
				if (array_key_exists('SelectedInventorySeries', $data)
						&& ($item->InventorySerieColumn->InventorySerie->getCssClass() == 'panel_on'))
					$item->InventorySerieColumn->InventorySerie->setSelectedValue($data['SelectedInventorySeries']);

				if (array_key_exists('SelectedSection', $data))
					$item->CollocationComboColumn->Section->setSelectedIndex($data['SelectedSection']);				
				
				if (array_key_exists('SelectedItemStatus', $data))
					$item->ItemStatusColumn->ItemStatus->setSelectedValue($data['SelectedItemStatus']);
				
				if (array_key_exists('SelectedLoanClass', $data))
					$item->LoanClassColumn->LoanClass->setSelectedValue($data['SelectedLoanClass']);
			}
		}		
	}

	public function onShelfChanged($sender, $param)
 	{
 		$id = intval($this->ShelfId->getValue());

		if ($id > 0)
		{
			$this->getUser()->setActualShelfId($id);		
			$this->getPage()->writeMessage(Prado::localize("Salvato in sessione utente lo scaffale '{scaff}' (id={id}) come preferito dell'operatore",
																array(	'id' => $id,
																		'scaff' => ShelfPeer::getShelfName($id) )),
											ClavisMessage::INFO);
		}

		$this->doShelfChanged($id, $param);
 	}

	private function doShelfChanged($shelfId = null, $param = null)
 	{
 		$shelf = null;
 		$id = intval($shelfId);
		
 		if ($id > 0)
 			$shelf = ShelfQuery::create()->findPk($id);
		
 		if ($shelf instanceof Shelf)
 		{
			$this->ShelfName->setText($shelf->getShelfName());
			$this->ShelfName->setNavigateUrl($this->getService()->constructUrl(	'Communication.ShelfViewPage',
																				array('id' => $shelf->getShelfId())));
			
			$this->ShelfName->setEnabled(true);
			$this->ShelfName->setTarget('parent');
			
 			$this->setShelfChoiceDone(true, $param);
 		}
		else
		{
			$this->doResetShelf($param);
		}
 	}
	
	public function onResetShelf($sender, $param)
	{
		$this->getUser()->setActualShelfId(null);
		
		$this->doResetShelf($param);
	}

	private function doResetShelf($param = null)
	{
		$this->ShelfId->setValue(0);
		$this->ShelfName->setText(Prado::localize("nessun scaffale"));
		$this->ShelfName->setNavigateUrl('');
		$this->ShelfName->setEnabled(false);
		//$this->ShelfName->setTarget('parent');
		$this->ShelfId->setValue('');
				
		$this->setShelfChoiceDone(false, $param);
	}
	
 	public function setShelfChoiceDone($flag, $param = null)
 	{
		////// maybe we want to see that button    $this->PopupShelfLinkButton->setVisible(!$flag);
		$this->ShelfResetButton->setVisible($flag);

		if ($this->getIsCallback())
		{
			if (is_null($param))
				$writer = $this->createWriter();
			else
				$writer = $param->getNewWriter();
			
			$this->ShelfPanel->render($writer);
		}
 	}
	
	public function onSupplierChanged($sender, $param)
 	{
 		$supplier = null;
 		$id = intval($this->ItemSupplierId->getValue());
 		if ($id > 0)
 			$supplier = SupplierPeer::retrieveByPK($id);
 		if ($supplier instanceof Supplier)
 		{
 			$this->ItemSupplier->setText($supplier->getSupplierName());
			$this->ItemSupplier->setNavigateUrl($this->getService()->constructUrl('Acquisition.SupplierInsertPage',
				array('supplierId' => $supplier->getSupplierId())));
			$this->ItemSupplier->setEnabled(true);
			$this->ItemSupplier->setTarget('parent');
			
 			$this->setSupplierChoiceDone(true, $param);
 		}
		else
		{
			$this->doResetSupplier($param);
		}
 	}

	public function onResetSupplier($sender, $param)
	{
		$this->doResetSupplier($param);
	}

	private function doResetSupplier($param = null)
	{
		$this->ItemSupplier->setText(Prado::localize('nessun fornitore'));
		$this->ItemSupplier->setNavigateUrl('');
		$this->ItemSupplier->setEnabled(false);
		//$this->ItemSupplier->setTarget('parent');
		$this->ItemSupplierId->setValue('');
		$this->setSupplierChoiceDone(false, $param);
	}
	
 	public function setSupplierChoiceDone($flag, $param = null)
 	{
		$this->PopupSupplierLinkButton->setVisible(!$flag);
		$this->SupplierResetButton->setVisible($flag);

		if ($this->getIsCallback())
		{
			if (is_null($param))
				$writer = $this->createWriter();
			else
				$writer = $param->getNewWriter();
			
			$this->SupplierPanel->render($writer);
		}
 	}
	
	public function onReloadPage($sender, $param)
	{
		$this->gotoPage('Catalog.ItemInsertBulkPage');
	}
	
	public function getMinNum()
	{
		return self::STARTITEMNUM;
	}

	public function getMaxNum()
	{
		return self::MAXITEMNUM;
	}
	
	/**
	 * If this page can have components where the menus
	 * inside can generate unlink menus.
	 *
	 * @return boolean
	 */
	public function isUnlink() 
	{
		return true;
	}

	/**
	 * If this page can have components where the
	 * menus inside can have the standard links that
	 * popups have.
	 *
	 * @return boolean
	 */
	public function isPopup() 
	{
		return false;
	}
	
	public function onPrintLabels($sender, $param) 
	{
		$itemIds = array();
		
		foreach ($this->getStoredDataSource() as $index => $row) 
		{
			if (array_key_exists('CreatedItems', $row))
			{
				foreach ($row['CreatedItems'] as $itemId => $itemData)
					$itemIds[] = $itemId;
			}
		}

		if (count($itemIds) == 0) 
		{
			$this->getPage()->writeMessage(Prado::localize('Nessuna etichetta da stampare'),
											ClavisMessage::WARNING);
			return;
		} 
		else 
		{
			$ids = implode(',', $itemIds);
			$this->JRPBox->setObjectId($ids);
			$this->JRPBox->printReport();
		}
	}


	///////  for debugging purpose
	public function onRedrawGrid($sender, $param)
	{
		$manId = 1063704; //1996; //502599;
		$man = ManifestationPeer::retrieveByPK($manId);
		//$this->setManifestation($man);
		
		$this->RecordChooser->setManifestation($man);
		$this->RecordChooser->ManifestationView->update($manId);
		
		$this->drawAll($manId);
	}

}