<?php
/**
 * ItemListPage class file.
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author    Marco Brancalion <marco@comperio.it>
 * @link      http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license   http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version   2.8.8
 * @package   Pages.Catalog
 */

/**
 * ItemListPage Class
 *
 * @author  Marco Brancalion <marco@comperio.it>
 * @version 2.8.8
 * @package Pages.Catalog
 * @since   2.0
 */
class ItemListPage extends ClavisPage
{
	public $_module = 'CATALOG';
	public $_llibraryActive;

	public function onInit($param)
	{
		parent::onInit($param);
		$this->initVars();

		if (!$this->getIsPostBack()
			&& !$this->getIsCallBack()) {

			$filters = [];
			$urlParams = $this->getUrlParams();

			foreach ($urlParams as $paramKey => $paramValue) {
				switch ($paramKey) {
					case 'barcode':
						$filters['BarcodeFilter'] = $paramValue;
						break;
					case 'inventory':
						$filters['InventoryFilter'] = $paramValue;
						break;
					case 'manifestationId':
						$filters['ManifestationIdFilter'] = $paramValue;
						break;
					case 'itemStatus':
						$filters['ItemStatusFilter'] = $paramValue;
						break;
				}
			}

			$this->setFilterExists(count($filters) > 0);
			$givenItemIds = TPropertyValue::ensureArray($this->getRequest()->itemAt('id'));

			if (!is_null($givenItemIds) && (count($givenItemIds) > 0))
				$this->QB1->setGivenItemIds($givenItemIds);
		}
	}

	private function initVars()
	{
		$this->_llibraryActive = LLibraryPeer::isEnabled();
	}

	public function setFilterExists($value = false)
	{
		if (!is_bool($value))
			$value = false;

		$this->setViewState("FilterExists", $value, false);
	}

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallBack()) {

			// parameter handling passed via get request to this page
			if ($this->getRequest()->itemAt('itemStatus') === ItemStatus::ITEMSTATUS_DISCARDED) {
				$mid = $this->getRequest()->itemAt('manifestationId');
				$this->QB1->setAllow();
				$this->QB1->init(null, $this->getScartatiQBRules($mid));
				$this->searchDiscarded($mid);
			} else if (
				($section = filter_input(INPUT_GET, 'section', FILTER_SANITIZE_STRING)) &&
				($library = filter_input(INPUT_GET, 'library', FILTER_VALIDATE_INT))) {
				$this->QB1->setAllow();
				$this->QB1->init(null, $this->getSectionQBRules($section, $library));
				$this->searchSection($section, $library);
			} else {
				$this->QB1->init();
			}
		}
	}

	public function searchDiscarded($manifestation_id = null)
	{
		$criteria = new Criteria;
		$criteria->add(ItemPeer::ITEM_STATUS, ItemStatus::ITEMSTATUS_DISCARDED, Criteria::EQUAL);
		if ($manifestation_id) {
			$criteria->add(ItemPeer::MANIFESTATION_ID, $manifestation_id, Criteria::EQUAL);
		}
		$this->QB1->searchByCriteria($criteria);
	}

	public function getScartatiQBRules($manifestation_id = null): array
	{
		$rules = [
			'flags' => [
				'no_add_rule' => true,
				'no_add_group' => true,
			],

			'condition' => 'AND',
			'rules' => [
				[
					'id' => 'no_manifestation',
					'operator' => 'equal',
					'value' => 1
				],
				[
					'id' => 'item_status',
					'operator' => 'equal',
					'value' => ItemStatus::ITEMSTATUS_DISCARDED
				]
			]
		];

		if ($manifestation_id > 0) {
			array_push($rules['rules'], [
				'id' => 'id_notizia',
				'operator' => 'equal',
				'value' => $manifestation_id
			]);
		}
		return $rules;
	}


	public function searchSection($section, $library_id)  {
		$criteria = new Criteria;
		$criteria->add(ItemPeer::SECTION, $section, Criteria::EQUAL);
		$criteria->addAnd(ItemPeer::HOME_LIBRARY_ID, $library_id, Criteria::EQUAL);
		$this->QB1->searchByCriteria($criteria);
	}

	public function getSectionQBRules($section, $library_id) {
		$json = ClavisBase::jsEncode(['id'=> $library_id, 'description'=> LibraryPeer::getLibraryLabel($library_id)]);

		$rules = [
			'flags' => [
				'no_add_rule' => true,
				'no_add_group' => true,
			],

			'condition' => 'AND',
			'rules' => [
				[
					'id' => 'section',
					'operator' => 'equal',
					'value' => $section
				],
				[
					'id' => 'home_library',
					'operator' => 'equal',
					'value' => $json
				]
			]
		];

		return $rules;

	}

	// ------------------------------------------------------------------------------------------------------------------

	public function resetPagination()
	{
		$this->QB1->resetPagination();
	}

	public function globalRefreshIn()
	{
		$this->globalRefresh();
	}

	public function globalRefresh()
	{
		$this->QB1->populate();
	}

	public function onExternalChangePage()
	{

	}

	public function onCleanSearch($sender, $param)
	{
		$this->QB1->populate();

		if ($this->getPage()->getIsCallback())
			$this->ListPanel->render($this->getPage()->createWriter());
	}

	public function onBuildRepeaterRow($sender, $param)
	{
		$item = $param->Item;
		if (($item->ItemType === 'Item')
			|| ($item->ItemType === 'AlternatingItem')) {

		}
	}

	public function onAddRepeaterRow($sender, $param)
	{
		$repeaterSource = $this->readDataSource();
		$newRow = ['key' => 0,
			'relation' => 0,
			'valueText' => '',
			'valueSelectedValue' => 0,
			'valueTimeStamp' => null,

			'valueType' => 'TextBox',
			'operator' => 'and'];

		$repeaterSource[] = $newRow;  //$repeaterSource->add(new TControl());

		$this->FilterRepeater->setDataSource($repeaterSource);
		$this->FilterRepeater->dataBind();
	}

	public function onDeleteRepeaterRow($sender, $param)
	{
		$rowToDelete = $sender->Parent->ItemIndex;
		$dataSource = $this->readDataSource();

		if (isset($dataSource[$rowToDelete])) {
			unset($dataSource[$rowToDelete]);
			$this->FilterRepeater->setDataSource($dataSource);
			$this->FilterRepeater->dataBind();
		}
	}

	public function onTemp($sender, $param)
	{
		// per fare un postback a vuoto
	}


	public function onSuggest($sender,$param)
	{
		return 1;
	}

	public function onCreate($sender,$param)
	{
		return 1;
	}
}
