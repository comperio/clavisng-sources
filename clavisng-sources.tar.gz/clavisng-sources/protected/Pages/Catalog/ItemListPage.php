<?php
/**
 * ItemListPage class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.8.8
 * @package Pages.Catalog
 */

/**
 * ItemListPage Class
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.8.8
 * @package Pages.Catalog
 * @since 2.0
 */
class ItemListPage extends ClavisPage
{
	const NULLSECTION = '**NULLSECTIONVALUE';
	public $_module = "CATALOG";
	public $customs_type = array('text', 'text', 'text');
	
	public $_llibraryActive;

	private function initVars()
	{
		$this->_llibraryActive = LLibraryPeer::isEnabled();
	}
	
	public function onInit($param)
	{
		parent::onInit($param);
		$this->initVars();

		if (!$this->getIsPostBack() 
				&& !$this->getIsCallBack())
		{
			$this->doCleanSearch();

			$filters = array();
			$urlParams = $this->getUrlParams();
			
			foreach ($urlParams as $paramKey => $paramValue)
			{
				switch ($paramKey)
				{
					case 'barcode':
						$filters['BarcodeFilter'] = $paramValue;
						
						break;

					case 'inventory':
						$filters['InventoryFilter'] = $paramValue;
					
						break;
				
					case 'manifestationId':
						$filters['ManifestationIdFilter'] = $paramValue;
					
						break;

					case 'itemStatus':
						$filters['ItemStatusFilter'] = $paramValue;
					
						break;
				}
			}

			if (count($filters) > 0)
				$this->setFilterExists(true);
			
			foreach ($filters as $controlName => $controlContent)
			{
				$controls = $this->findControlsByID($controlName);
				$control = $controls[0];

				/**
				 * questo serve, in teoria, per verificare
				 * che questo controllo esista nella pagina ...
				 */
				if (!is_null($control))
				{
					$controlId = $control->getID();

					switch (get_class($control))
					{
						case 'TTextBox':
							$this->$controlId->setText($controlContent);
						
							break;

						case 'TDropDownList':
						case 'TDBDropDownList':	
							$this->$controlId->setSelectedValue($controlContent);
						
							break;
					}
				}
			}

			$givenItemIds = TPropertyValue::ensureArray($this->getRequest()->itemAt('id'));
			
			if (!is_null($givenItemIds) 
					&& (count($givenItemIds) > 0))
				$this->ItemList->setGivenItemIds($givenItemIds);
		}
	}

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (LookupValuePeer::classExists('ITEMCUST1'))
			$this->customs_type[0] = 'list';
		
		if (LookupValuePeer::classExists('ITEMCUST2'))
			$this->customs_type[1] = 'list';
		
		if (LookupValuePeer::classExists('ITEMCUST3'))
			$this->customs_type[2] = 'list';

		if (!$this->getPage()->getIsPostBack() 
				&& !$this->getPage()->getIsCallBack())
		{
			$this->populateSerieSection();

			//$libraries = LibraryPeer::getLibrariesHashWithBlank(null, null, true);
			
			if ($this->_llibraryActive)
			{
				$basinDistance = LLibraryPeer::getMaxLLibraryBasin();
				
				$libraries = LibraryPeer::getLibrariesHash(	array(	LibraryPeer::BLANKVALUE,
																	LibraryPeer::EXCLUDEMYLIBRARY,
																	LibraryPeer::INBASIN,
																	LibraryPeer::OUTBASIN ),

															array(	'---',
																	'<' . Prado::localize('tutte tranne la mia') . '>',
																	'<' . LookupValuePeer::getLookupValue('BASINLABEL', $basinDistance) . '>',
																	'<' . LookupValuePeer::getLookupValue('BASINLABEL', $basinDistance + 1) . '>' ),

															null,
															true );
			}
			else
			{
				$libraries = LibraryPeer::getLibrariesHash(	array(	LibraryPeer::BLANKVALUE,
																	LibraryPeer::EXCLUDEMYLIBRARY ),

															array(	'---',
																	'<' . Prado::localize('tutte tranne la mia') . '>' ),

															null,
															true );
			}
			
			$this->OwnerLibraryFilter->setDataSource($libraries);
			$this->OwnerLibraryFilter->dataBind();
			$this->HomeLibraryFilter->setDataSource($libraries);
			$this->HomeLibraryFilter->dataBind();
			$this->ActualLibraryFilter->setDataSource($libraries);
			$this->ActualLibraryFilter->dataBind();
			$this->DeliveryLibraryFilter->setDataSource($libraries);
			$this->DeliveryLibraryFilter->dataBind();

			$sectkey=$this->getRequest()->itemAt('section');
			$library=$this->getRequest()->itemAt('library');
			
			if ($sectkey && $library)
			{
				$section = LibraryValueQuery::create()->findPK(array($sectkey, 'ITEMSECTION', $library));
				
				if ($section instanceof LibraryValue)
				{
					$this->SectionFilter->setSelectedValue($section->getValueKey());
					$this->HomeLibraryFilter->setSelectedValue($section->getValueLibraryId());
					$this->setFilterExists(true);
				}
			}

			$this->SupplierFilter->setDataSource(SupplierPeer::findAll2DataSource(true));	// with blank
			$this->SupplierFilter->dataBind();
			
			//$this->resetNoManifestationFilter();

			if ($this->getFilterExists())
			{
				$this->onSearchItem(null, null);
				//$this->resetFilters();
			}

			$this->setFocus($this->BarcodeFilter->getClientID());
		}

		$this->doToLibrarySwitches();
	}

	public function populateSerieSection()
	{
		$lid = $this->getUser()->getActualLibraryId();
	
		$inv_series = InventorySerieQuery::create()
						->orderByClosed()
						->orderByReadonly()
						->orderByInventorySerieId()
						->findByLibraryId($lid);
		
		$ds = array('' => '---');
		
		foreach ($inv_series as $i)
		{
			$ds[$i->getInventorySerieId()] = $i->getDescription() . ' (' .
				$i->getInventorySerieId() . ')';
		}
		
		$this->InventorySerieIdFilter->setDataSource($ds);
		$this->InventorySerieIdFilter->dataBind();
		$this->SectionFilter->setLibraryId($lid);
		$this->SectionFilter->setAddedValues(array('**IS*NULL**' => '(' . Prado::localize('valore nullo') . ')'));
		$this->SectionFilter->populateList();
	}

	public function resetFilterExists()
	{
		$this->setFilterExists(false);
	}

	public function setFilterExists($value = false)
	{
		if (!is_bool($value))
			$value = false;

		$this->setViewState("FilterExists", $value, false);
	}

	public function getFilterExists()
	{
		$output = $this->getViewState("FilterExists", false);
		$this->resetFilterExists();

		return $output;
	}

	public function setFilterRepeaterDataSource($data)
	{
		$this->setViewState("FilterRepeaterDataSource", $data, null);
	}

	public function getFilterRepeaterDataSource()
	{
		return $this->getViewState("FilterRepeaterDataSource", null);
	}

	public function resetFilterRepeater()
	{
		$this->FilterRepeater->setDataSource(array());
	}

	public function globalRefresh()
	{
		$this->ItemList->populate();
	}

 	public function globalRefreshIn()
 	{
		$this->globalRefresh();
	}

	public function onExternalChangePage()
	{
		$this->doSearch();
	}

	public function onAddToShelf($sender, $param)
	{
		//ini_set("memory_limit", "700M");
		//set_time_limit(0);
		$this->getPage()->cleanMessageQueue();
		
		$shelfId = intval($this->ShelfResultValue->getValue());
		$shelf = ShelfQuery::create()->findPK($shelfId);
		$this->ShelfResultValue->setValue('');
		
		if ($shelf instanceof Shelf)
		{
			$checkedId = $this->ItemList->getCheckedId();
			$this->ItemList->resetCheckedItems();
			$ok = intval($shelf->addItemToShelf('item', $checkedId));
			$failed = count($checkedId) - $ok;
			$shelf->save();
			
			$this->getPage()->enqueueMessage(Prado::localize("{ok} esemplari aggiunti/aggiornati nello scaffale {shelf}",
																	array(	'ok' => $ok, 
																			'shelf' => $shelf->getShelfCompleteName() )),
												ClavisMessage::CONFIRM);
			
			if ($failed > 0)
			{
				$this->getPage()->enqueueMessage(Prado::localize("{failed} esemplari non aggiunti allo scaffale {shelf} in conseguenza di errori",
																		array(	'failed' => $failed, 
																				'shelf' => $shelf->getShelfCompleteName() )),
													ClavisMessage::ERROR);
			}
		}
		else
		{
			$this->getPage()->enqueueMessage(Prado::localize("Lo scaffale scelto non risulta valido."), 
												ClavisMessage::ERROR);
		}
		
		$this->getPage()->globalRefresh();
		$this->getPage()->flushMessage();
	}

	public function onLocalSearch($sender, $param)
	{
		$actualLibraryId = $this->getUser()->getActualLibraryId();
		$this->LibraryFilter->setSelectedValue($actualLibraryId);

		$this->search();
	}

	public function onSearchItem($sender, $param)
	{
		$this->resetPagination();
		$this->doSearch();
	}

	public function doSearch()
	{
		$actualLibraryId = $this->getUser()->getActualLibraryId();
		
		/** @var $criteria Criteria */
		$criteria = new Criteria();
        $itemId = intval(trim($this->ItemIdFilter->getSafeText()));
        
		if ($itemId > 0)
			$criteria->addAnd(ItemPeer::ITEM_ID, $itemId);

        $manifestationId = intval(trim($this->ManifestationIdFilter->getSafeText()));

		if ($manifestationId > 0)
			$criteria->addAnd(ItemPeer::MANIFESTATION_ID, $manifestationId);
		
		$barcode = TPropertyValue::ensureString(trim($this->BarcodeFilter->getSafeText()));
		
		if ($barcode != '')
			$criteria->addAnd(ItemPeer::BARCODE, $barcode, Criteria::LIKE);

		$title = TPropertyValue::ensureString(trim($this->TitleFilter->getSafeText()));
		
		if ($title != '')
			$criteria->addAnd(ItemPeer::TITLE, $title . "%", Criteria::LIKE);

		$inventoryNumberFrom = intval(trim($this->InventoryFilterFrom->getSafeText()));
		$inventoryNumberTo = intval(trim($this->InventoryFilterTo->getSafeText()));
		
		if (($inventoryNumberFrom > 0) || ($inventoryNumberTo > 0))
		{
			if ($inventoryNumberTo == 0)
			{
				$criteria->add(ItemPeer::INVENTORY_NUMBER, $inventoryNumberFrom);
			}
			else
			{
				$inventoryCriterion = null;

				if ($inventoryNumberFrom > 0)
					$inventoryCriterion = $criteria->getNewCriterion(ItemPeer::INVENTORY_NUMBER, $inventoryNumberFrom, Criteria::GREATER_EQUAL);

				if ($inventoryNumberTo > 0)
				{
					$inventoryCriterion2 = $criteria->getNewCriterion(ItemPeer::INVENTORY_NUMBER, $inventoryNumberTo, Criteria::LESS_EQUAL);
					if (!is_null($inventoryCriterion))
					{
						$inventoryCriterion->addAnd($inventoryCriterion2);
					}
					else
					{
						$inventoryCriterion = $inventoryCriterion2;
					}
				}

				if (!is_null($inventoryCriterion))
					$criteria->addAnd($inventoryCriterion);
			}
		}

		if ($this->SectionFilter->getSelectedIndex() > 0)
		{
			$sectionFilter = $this->SectionFilter->getSelectedValue();

			if ($sectionFilter == '**IS*NULL**')
			{
				$criteria->addAnd(ItemPeer::SECTION, null, Criteria::ISNULL);
			}
			else
			{
				$criteria->addAnd(ItemPeer::SECTION, $sectionFilter, Criteria::LIKE);
			}
		}

		$collocationFilterFrom = trim($this->CollocationFilterFrom->getSafeText());
		$collocationFilterTo = trim($this->CollocationFilterTo->getSafeText());

		if (($collocationFilterFrom != '') 
				|| ($collocationFilterTo != ''))
		{
			if ($collocationFilterTo == '')
			{
				$criteria->addAnd(ItemPeer::COLLOCATION, $collocationFilterFrom . '%', Criteria::LIKE);
			}
			else
			{
				$collocationCriterion = null;

				if ($collocationFilterFrom != '')
					$collocationCriterion = $criteria->getNewCriterion(ItemPeer::COLLOCATION, $collocationFilterFrom, Criteria::GREATER_EQUAL);

				$collocationCriterion2 = $criteria->getNewCriterion(ItemPeer::COLLOCATION, $collocationFilterTo, Criteria::LESS_EQUAL);

				if (!is_null($collocationCriterion))
				{
					$collocationCriterion->addAnd($collocationCriterion2);
				}
				else
				{
					$collocationCriterion = $collocationCriterion2;
				}

				if (!is_null($collocationCriterion))
					$criteria->addAnd($collocationCriterion);
			}
		}
        
        $specificationFilterFrom = trim($this->SpecificationFilterFrom->getSafeText());
		$specificationFilterTo = trim($this->SpecificationFilterTo->getSafeText());

		if (($specificationFilterFrom != '') 
				|| ($specificationFilterTo != ''))
		{
			if ($specificationFilterTo == '')
			{
				$criteria->addAnd(ItemPeer::SPECIFICATION, $specificationFilterFrom . '%', Criteria::LIKE);
			}
			else
			{
				$specificationCriterion = null;

				if ($specificationFilterFrom != '')
					$specificationCriterion = $criteria->getNewCriterion(ItemPeer::SPECIFICATION, $specificationFilterFrom, Criteria::GREATER_EQUAL);

				$specificationCriterion2 = $criteria->getNewCriterion(ItemPeer::SPECIFICATION, $specificationFilterTo, Criteria::LESS_EQUAL);

				if (!is_null($specificationCriterion))
				{
					$specificationCriterion->addAnd($specificationCriterion2);
				}
				else
				{
					$specificationCriterion = $specificationCriterion2;
				}

				if (!is_null($specificationCriterion))
					$criteria->addAnd($specificationCriterion);
			}
		}
        
        $sequenceFilter1 = trim($this->SequenceFilter1->getSafeText());
		$sequenceFilter2 = trim($this->SequenceFilter2->getSafeText());
          
		if ($sequenceFilter1 != '')
				$criteria->addAnd(ItemPeer::SEQUENCE1, $sequenceFilter1 . '%', Criteria::LIKE);
		
		if ($sequenceFilter2 != '')
				$criteria->addAnd(ItemPeer::SEQUENCE2, $sequenceFilter2 . '%', Criteria::LIKE);

		if ($cf = trim($this->ConsistencyNoteFilter->getText()))
		{
			$cnotes = ConsistencyNoteQuery::create()
						->select('ConsistencyNoteId')
						->findByTextNote($cf);
			
			$criteria->addAnd(ItemPeer::CONSISTENCY_NOTE_ID, $cnotes->toArray(), Criteria::IN);
		}

		if (($this->customs_type[0] == 'list') 
				&& ($this->CustomList1->getSelectedIndex() > 0))
		{
			$criteria->add(ItemPeer::CUSTOM_FIELD1, $this->CustomList1->getSelectedValue());
		}
		elseif (($this->customs_type[0] == 'text') 
				&& trim($this->Custom1->getSafeText()))
		{
			$criteria->add(ItemPeer::CUSTOM_FIELD1, trim($this->Custom1->getSafeText()), Criteria::LIKE);
		}	

		if (($this->customs_type[1] == 'list') 
				&& ($this->CustomList2->getSelectedIndex() > 0))
		{
			$criteria->add(ItemPeer::CUSTOM_FIELD2, $this->CustomList2->getSelectedValue());
		}
		elseif (($this->customs_type[1] == 'text') 
				&& trim($this->Custom2->getSafeText()))
		{
			$criteria->add(ItemPeer::CUSTOM_FIELD2, trim($this->Custom2->getSafeText()), Criteria::LIKE);
		}

		if (($this->customs_type[2] == 'list') 
				&& ($this->CustomList3->getSelectedIndex() > 0))
		{
			$criteria->add(ItemPeer::CUSTOM_FIELD3, $this->CustomList3->getSelectedValue());
		}
		elseif (($this->customs_type[2] == 'text')
				&& trim($this->Custom3->getSafeText()))
		{
			$criteria->add(ItemPeer::CUSTOM_FIELD3, trim($this->Custom3->getSafeText()), Criteria::LIKE);
		}

		$lastSeenDate = $this->LastSeenFilter->getSafeText() != '' ? $this->LastSeenFilter->getTimeStamp() : null;
		
		if (!is_null($lastSeenDate) && ($lastSeenDate > 0))
		{
			$cr1 = $criteria->getNewCriterion(ItemPeer::LAST_SEEN, $lastSeenDate, Criteria::LESS_EQUAL);
			$cr2 = $criteria->getNewCriterion(ItemPeer::LAST_SEEN, null, Criteria::ISNULL);
			$cr1->addOr($cr2);
			$criteria->addAnd($cr1);
		}

		$inventoryFilterDateFrom = $this->InventoryFilterDateFrom->getSafeText() != '' ? $this->InventoryFilterDateFrom->getTimeStamp() : null;
		$inventoryFilterDateTo = $this->InventoryFilterDateTo->getSafeText() != '' ? $this->InventoryFilterDateTo->getTimeStamp() : null;

		if (!is_null($inventoryFilterDateFrom) && ($inventoryFilterDateFrom > 0))
			$criteria->addAnd(ItemPeer::INVENTORY_DATE, $inventoryFilterDateFrom, Criteria::GREATER_EQUAL);

		if (!is_null($inventoryFilterDateTo) && ($inventoryFilterDateTo > 0))
			$criteria->addAnd(ItemPeer::INVENTORY_DATE, $inventoryFilterDateTo + 86399, Criteria::LESS_EQUAL);

		if ($this->InventorySerieIdFilter->getSelectedIndex() > 0)
		{
			$inventorySerieId = $this->InventorySerieIdFilter->getSelectedValue();
			$criteria->addAnd(ItemPeer::INVENTORY_SERIE_ID, $inventorySerieId);
		}

		if ($this->ItemStatusFilter->getSelectedIndex() > 0)
			$criteria->addAnd(ItemPeer::ITEM_STATUS, $this->ItemStatusFilter->getSelectedValue());
		
		if ($this->ItemOrderStatusFilter->getSelectedIndex() > 0)
			$criteria->addAnd(ItemPeer::ITEM_ORDER_STATUS, $this->ItemOrderStatusFilter->getSelectedValue());

		if ($this->ItemPhysicalStatusFilter->getSelectedIndex() > 0)
		{
			$itemPhysicalStatusFilter = $this->ItemPhysicalStatusFilter->getSelectedValue();
			$criteria->addAnd(ItemPeer::PHYSICAL_STATUS, $itemPhysicalStatusFilter);
		}

		if ($this->IssueStatusFilter->getSelectedIndex() > 0)
		{
			$issueStatusFilter = $this->IssueStatusFilter->getSelectedValue();
			$criteria->addAnd(ItemPeer::ISSUE_STATUS, $issueStatusFilter);
		}

		if ($this->LoanClassFilter->getSelectedIndex() > 0)
		{
			$loanClassFilter = $this->LoanClassFilter->getSelectedValue();
			$criteria->addAnd(ItemPeer::LOAN_CLASS, $loanClassFilter);
		}

		if ($this->LoanStatusFilter->getSelectedIndex() > 0)
		{
			$loanStatusFilter = $this->LoanStatusFilter->getSelectedValue();
			$criteria->addAnd(ItemPeer::LOAN_STATUS , $loanStatusFilter);
		}

		if ($this->_llibraryActive)
		{
			$basinDistance = LLibraryPeer::getMaxLLibraryBasin();
			$distanceHash = LibraryPeer::getDistanceHash($actualLibraryId);
			$inBasinIds = implode(',', array_slice($distanceHash, 0, $basinDistance + 1 , true));
			$outBasinIds = implode(',', array_slice($distanceHash, $basinDistance + 1, count($distanceHash) - 1, true));
		}
		else
		{
			$inBasinIds = "";
			$outBasinIds = "";
		}	

		if ($this->OwnerLibraryFilter->getSelectedIndex() > 0)
		{
			$ownerLibraryFilter = $this->OwnerLibraryFilter->getSelectedValue();
			
			if ($ownerLibraryFilter == LibraryPeer::EXCLUDEMYLIBRARY)
			{
				$criteria->addAnd(ItemPeer::OWNER_LIBRARY_ID, $actualLibraryId, Criteria::NOT_EQUAL);
			}
			elseif ($this->_llibraryActive
						&& ($ownerLibraryFilter == LibraryPeer::INBASIN))
			{
				$criteria->addAnd(ItemPeer::OWNER_LIBRARY_ID, $inBasinIds, Criteria::IN);	
			}
			elseif ($this->_llibraryActive
						&& ($ownerLibraryFilter == LibraryPeer::OUTBASIN))
			{
				$criteria->addAnd(ItemPeer::OWNER_LIBRARY_ID, $outBasinIds, Criteria::IN);	
			}
			else
			{
				$criteria->addAnd(ItemPeer::OWNER_LIBRARY_ID, $ownerLibraryFilter);
			}
		}
		
		if ($this->HomeLibraryFilter->getSelectedIndex() > 0)
		{
			$homeLibraryFilter = $this->HomeLibraryFilter->getSelectedValue();
			
			if ($homeLibraryFilter == LibraryPeer::EXCLUDEMYLIBRARY)
			{
				$criteria->addAnd(ItemPeer::HOME_LIBRARY_ID, $actualLibraryId, Criteria::NOT_EQUAL);
			}
			elseif ($this->_llibraryActive
						&& ($homeLibraryFilter == LibraryPeer::INBASIN))
			{
				$criteria->addAnd(ItemPeer::HOME_LIBRARY_ID, $inBasinIds, Criteria::IN);	
			}
			elseif ($this->_llibraryActive
						&& ($homeLibraryFilter == LibraryPeer::OUTBASIN))
			{
				$criteria->addAnd(ItemPeer::HOME_LIBRARY_ID, $outBasinIds, Criteria::IN);	
			}
			else
			{
				$criteria->addAnd(ItemPeer::HOME_LIBRARY_ID, $homeLibraryFilter);
			}
		}

		if ($this->ActualLibraryFilter->getSelectedIndex() > 0)
		{
			$actualLibraryFilter = $this->ActualLibraryFilter->getSelectedValue();
			
			if ($actualLibraryFilter == LibraryPeer::EXCLUDEMYLIBRARY)
			{
				$criteria->addAnd(ItemPeer::ACTUAL_LIBRARY_ID, $actualLibraryId, Criteria::NOT_EQUAL);
			}
			elseif ($this->_llibraryActive
						&& ($actualLibraryFilter == LibraryPeer::INBASIN))
			{
				$criteria->addAnd(ItemPeer::ACTUAL_LIBRARY_ID, $inBasinIds, Criteria::IN);	
			}
			elseif ($this->_llibraryActive
						&& ($actualLibraryFilter == LibraryPeer::OUTBASIN))
			{
				$criteria->addAnd(ItemPeer::ACTUAL_LIBRARY_ID, $outBasinIds, Criteria::IN);	
			}
			else
			{
				$criteria->addAnd(ItemPeer::ACTUAL_LIBRARY_ID, $actualLibraryFilter);
			}
		}

		if ($this->DeliveryLibraryFilter->getSelectedIndex() > 0)
		{
			$deliveryLibraryFilter = $this->DeliveryLibraryFilter->getSelectedValue();
			
			if ($deliveryLibraryFilter == LibraryPeer::EXCLUDEMYLIBRARY)
			{
				$criteria->addAnd(ItemPeer::DELIVERY_LIBRARY_ID, $deliveryLibraryFilter, Criteria::NOT_EQUAL);
			}
			elseif ($this->_llibraryActive
						&& ($deliveryLibraryFilter == LibraryPeer::INBASIN))
			{
				$criteria->addAnd(ItemPeer::DELIVERY_LIBRARY_ID, $inBasinIds, Criteria::IN);	
			}
			elseif ($this->_llibraryActive
						&& ($deliveryLibraryFilter == LibraryPeer::OUTBASIN))
			{
				$criteria->addAnd(ItemPeer::DELIVERY_LIBRARY_ID, $outBasinIds, Criteria::IN);	
			}
			else
			{
				$criteria->addAnd(ItemPeer::DELIVERY_LIBRARY_ID, $deliveryLibraryFilter);
			}			
		}
		
        $editingDateFrom = $this->EditingDateFrom->getSafeText() != '' ? $this->EditingDateFrom->getTimeStamp() : null;
		
		if (!is_null($editingDateFrom) && ($editingDateFrom > 0))
			$criteria->addAnd(ItemPeer::DATE_UPDATED, $editingDateFrom, Criteria::GREATER_EQUAL);
        
        $editingDateTo = $this->EditingDateTo->getSafeText() != '' ? ($this->EditingDateTo->getTimeStamp() + (24 * 60 * 60) ): null;
		
		if (!is_null($editingDateTo) && ($editingDateTo > 0))
			$criteria->addAnd(ItemPeer::DATE_UPDATED, $editingDateTo, Criteria::LESS_EQUAL);

        $dateDiscardedFrom = $this->DateDiscardedFrom->getSafeText() != '' ? $this->DateDiscardedFrom->getTimeStamp("U") : null;
		
		if (!is_null($dateDiscardedFrom) && ($dateDiscardedFrom > 0))
			$criteria->addAnd(ItemPeer::DATE_DISCARDED, $dateDiscardedFrom, Criteria::GREATER_EQUAL);
        
        $dateDiscardedTo = $this->DateDiscardedTo->getSafeText() != '' ? ($this->DateDiscardedTo->getTimeStamp("U") + (24 * 60 * 60) ): null;
		
		if (!is_null($dateDiscardedTo) && ($dateDiscardedTo > 0))
			$criteria->addAnd(ItemPeer::DATE_DISCARDED, $dateDiscardedTo, Criteria::LESS_EQUAL);
		
		if ($this->ItemMediaTypeFilter->getSelectedIndex() > 0)
		{
			$itemMediaTypeFilter = $this->ItemMediaTypeFilter->getSelectedValue();
			$criteria->addAnd(ItemPeer::ITEM_MEDIA, $itemMediaTypeFilter);
		}

		if ($this->ItemSourceFilter->getSelectedIndex() > 0)
		{
			$itemSourceFilter = $this->ItemSourceFilter->getSelectedValue();
			$criteria->addAnd(ItemPeer::ITEM_SOURCE, $itemSourceFilter);
		}

		switch ($this->NoManifestationFilter->getSelectedValue())
		{
			case 1:
				$criterionNoMan1 = $criteria->getNewCriterion(ItemPeer::MANIFESTATION_ID, 0, Criteria::GREATER_THAN);
				$criteria->addAnd($criterionNoMan1);
				
				break;

			case 2:
				$criterionNoMan1 = $criteria->getNewCriterion(ItemPeer::MANIFESTATION_ID, 0);
				$criteria->addAnd($criterionNoMan1);
				
				break;

			default:
				break;
		}

		switch ($this->OpacVisible->getSelectedValue())
		{
			case 1:
				$criteria->addAnd(ItemPeer::OPAC_VISIBLE, 1);
				
				break;

			case 2:
				$criteria->addAnd(ItemPeer::OPAC_VISIBLE, 0);
				
				break;

			default:
				break;
		}

		if ($this->SupplierFilter->getSelectedIndex() > 0)
			$criteria->addAnd(ItemPeer::SUPPLIER_ID, $this->SupplierFilter->getSelectedValue());
		
		$this->ItemList->setExternalCriteria($criteria);
		$this->ItemList->populate();

		if ($this->getPage()->getIsCallback())
			$this->ListPanel->render($this->getPage()->createWriter());
	}

	public function search()
	{
		$filtersDataSource = $this->readDataSource();
		
		if (count($filtersDataSource) > 0)
		{
			$dataSource = $filtersDataSource;
			foreach ($dataSource as $index => $row)
			{
				if ($row['key'] == 0)
					unset($filtersDataSource[$index]);
			}

			if (count($filtersDataSource) > 0)
			{
				$criteria = new Criteria();

				if (isset($baseCriterion))
					unset($baseCriterion);
				
				$keyMap = $this->getKeyMap();
				$relationMap = $this->getRelationMap();
				
				foreach ($filtersDataSource as $index => $row)
				{
					$key = $keyMap[$row['key']];
					$relation = $relationMap[$row['relation']];
					$value = $row['value'];
					$operator = $row['operator'];

					if (!isset($baseCriterion))
					{
						$baseCriterion = $criteria->getNewCriterion($key, $value, $relation);
					}
					else
					{
						$criterion = $criteria->getNewCriterion($key, $value, $relation);
						switch ($operator)
						{
							case 'and':
								$baseCriterion->addAnd($criterion);
								
								break;
							
							case 'or':
								$baseCriterion->addOr($criterion);
								
								break;
							
							default:
								break;
						}
					}
				}

				$criteria->add($baseCriterion);

				$pageSize = $this->ItemList->getPageSize();
				$currentPage = $this->ItemList->getCurrentPage();

				$recCount = ItemPeer::doCount($criteria);

				$criteria->setLimit($pageSize);
				$criteria->setOffset($currentPage * $pageSize);

				$items = ItemPeer::doSelect($criteria);
				$itemIds = array();
				
				if (count($items) > 0)
				{
					foreach ($items as $item)
						$itemIds[] = $item->getItemId();
				}

				$this->ItemList->setExternalRecCount($recCount);
				$this->ItemList->setGivenItemIds($itemIds);
				$this->ItemList->populate();
			}
		}
	}

	public function onCleanSearch($sender, $param)
	{
		$this->doCleanSearch();
		$this->ItemList->populate();
		$this->doToLibrarySwitches();
		
		if ($this->getPage()->getIsCallback())
			$this->ListPanel->render($this->getPage()->createWriter());
	}

	private function doCleanSearch()
	{
		$this->BarcodeFilter->setText('');
		$this->TitleFilter->setText('');
		$this->InventorySerieIdFilter->setSelectedIndex(0);

		$this->InventoryFilterFrom->setText('');
		$this->InventoryFilterTo->setText('');

		$this->SectionFilter->setSelectedIndex(-1);

		$this->CollocationFilterFrom->setText('');
		$this->CollocationFilterTo->setText('');
        
        $this->SpecificationFilterFrom->setText('');
		$this->SpecificationFilterTo->setText('');
        $this->SequenceFilter1->setText('');
        $this->SequenceFilter2->setText('');
		$this->CustomList1->setSelectedIndex(-1);
		$this->Custom1->setText('');
		$this->CustomList2->setSelectedIndex(-1);
		$this->Custom2->setText('');
		$this->CustomList3->setSelectedIndex(-1);
		$this->Custom3->setText('');
        
        $this->EditingDateFrom->setText('');
        $this->EditingDateTo->setText('');
		
        $this->DateDiscardedFrom->setText('');
        $this->DateDiscardedTo->setText('');
        
		$this->ItemStatusFilter->setSelectedIndex(0);
		$this->ItemOrderStatusFilter->setSelectedIndex(0);
		$this->ItemPhysicalStatusFilter->setSelectedIndex(0);
		$this->LoanClassFilter->setSelectedIndex(0);
		$this->LoanStatusFilter->setSelectedIndex(0);
		$this->OwnerLibraryFilter->setSelectedIndex(0);
		$this->HomeLibraryFilter->setSelectedIndex(0);
		$this->ActualLibraryFilter->setSelectedIndex(0);
		$this->DeliveryLibraryFilter->setSelectedIndex(0);

		$this->ItemMediaTypeFilter->setSelectedIndex(0);
		$this->ItemSourceFilter->setSelectedIndex(0);

		$this->ItemList->resetExternalCriteria();
		$this->ItemList->resetPagination();  //
		$this->NoManifestationFilter->setSelectedIndex(0);
		$this->OpacVisible->setSelectedIndex(0);
		
		$this->SupplierFilter->setSelectedIndex(0);
	}

	public function resetPagination()
	{
		$this->ItemList->resetPagination();
	}

	public function readDataSource()
	{
		$dataSource = array();
		$items = $this->FilterRepeater->getItems();
		foreach ($items as $index => $item)
		{
			$key = $item->KeyDropDownList->getSelectedValue();
			$relation = $item->RelationDropDownList->getSelectedValue();
			$valueTextBox = $item->ValueTextBox->getSafeText();
			$valueDropDownList = $item->ValueDropDown->getSelectedValue();
			$valueDatePicker = $item->ValueDatePicker->getTimeStamp();
			$valueType = $item->ValueType->getValue();
			$operator = $item->OperatorDropDownList->getSelectedValue();

			$newRow = array(	'key' => $key, 
								'relation' => $relation, 
								'valueText' => $valueTextBox, 
								'valueSelectedValue' => $valueDropDownList, 
								'valueTimeStamp' => $valueDatePicker, 

								'valueType' => $valueType, 
								'operator' => $operator );
			
			$dataSource[] = $newRow;
		}

		return $dataSource;
	}

	public function onBuildRepeaterRow($sender, $param)
	{
		$item = $param->Item;
		if (($item->ItemType === 'Item') 
				|| ($item->ItemType === 'AlternatingItem'))
		{
			$item->KeyDropDownList->setDataSource($this->getKeyList());
			$item->KeyDropDownList->dataBind();

			$item->RelationDropDownList->setDataSource($this->getRelationList());
			$item->RelationDropDownList->dataBind();

			$valueType = $item->DataItem['valueType'];

			$item->OperatorDropDownList->setDataSource($this->getOperatorList());
			$item->OperatorDropDownList->dataBind();
			$item->OperatorDropDownList->setVisible($item->ItemIndex != 0);
		}
	}

	public function onAddRepeaterRow($sender, $param)
	{
		$repeaterSource = $this->readDataSource();
		$newRow = array(	'key' => 0, 
							'relation' => 0, 
							'valueText' => '', 
							'valueSelectedValue' => 0, 
							'valueTimeStamp' => null, 
			
							'valueType' => 'TextBox', 
							'operator' => 'and' );
		
		$repeaterSource[] = $newRow;  //$repeaterSource->add(new TControl());

		$this->FilterRepeater->setDataSource($repeaterSource);
		$this->FilterRepeater->dataBind();
	}

	public function onDeleteRepeaterRow($sender, $param)
	{
		$rowToDelete = $sender->Parent->ItemIndex;
		$dataSource = $this->readDataSource();
		
		if (isset($dataSource[$rowToDelete]))
		{
			unset($dataSource[$rowToDelete]);
			$this->FilterRepeater->setDataSource($dataSource);
			$this->FilterRepeater->dataBind();
		}
	}

	private function getKeyList()
	{
		$list =    array(	'---',
							'barcode',
							'stato dell\'esemplare',
							'stato del prestito',
							'biblioteca proprietaria',
							
							'biblioteca che gestisce',
							'biblioteca corrente',
							'biblioteca di destinazione' );
		return $list;
	}

	private function getKeyMap()
	{
		$map = array(	null,
						ItemPeer::BARCODE,
						ItemPeer::ITEM_STATUS,
						ItemPeer::LOAN_STATUS,
						ItemPeer::OWNER_LIBRARY_ID,
			
						ItemPeer::HOME_LIBRARY_ID,
						ItemPeer::ACTUAL_LIBRARY_ID,
						ItemPeer::DELIVERY_LIBRARY_ID );

		return $map;
	}

	private function getRelationList()
	{
		$list =    array(	'=',
							'diverso da',
							'>',
							'<',
							'> o =',
			
							'< o =',
							'inizia per' );

		return $list;
	}

	private function getRelationMap()
	{
		$map = array(	Criteria::EQUAL,
						Criteria::NOT_EQUAL,
						Criteria::GREATER_THAN,
						Criteria::LESS_THAN,
						Criteria::GREATER_EQUAL,
						
						Criteria::LESS_EQUAL,
						Criteria::LIKE );

		return $map;
	}

	private function getOperatorList()
	{
		$list = array(	'and' => 'AND',
						'or' => 'OR' );

		return $list;
	}

	public function onTemp($sender, $param)
	{
		// per fare un postback a vuoto
	}

	public function getValueTypeControl()
	{
		return array(	'TextBox',
						'TextBox',
						'DropDownList',
						'DropDownList',
						'DropDownList',
			
						'DropDownList',
						'DropDownList',
						'DropDownList' );
	}

	public function getValueTypeSql()
	{
		return array(	'TextBox',
						'TextBox',
						'select value_key, value_label from lookup_value where value_class="ITEMSTATUS"',
						'DropDownList',
						'DropDownList',
			
						'DropDownList',
						'DropDownList',
						'DropDownList' );
	}

	public function onValueTypeChanged($sender, $param)
	{
		$item = $sender->Parent;

		$item->ValueType->setValue('DropDownList');
		$item->TextBoxPanel->setCssClass('control_off');
		$item->DropDownListPanel->setCssClass('control_on');

		$item->ValueDropDown->setDataSource($this->getRelationList());
		$item->ValueDropDown->dataBind();
	}

	public function onResetInventoryDateFilter($sender, $param)
	{
		$this->InventoryFilterDateFrom->setText(null);
 		$this->InventoryFilterDateTo->setText(null);

 		if (!is_null($param) 
				&& ($this->getIsCallback()))
 			$this->InventoryDateFilterPanel->render($param->getNewWriter());
	}
	
	public function onResetEditingDateFilter($sender, $param)
	{
		$this->EditingDateFrom->setText(null);
 		$this->EditingDateTo->setText(null);

 		if (!is_null($param) 
				&& ($this->getIsCallback()))
 			$this->EditingDateFilterPanel->render($param->getNewWriter());
	}
	
	public function onResetDateDiscardedFilter($sender, $param)
	{
		$this->DateDiscardedFrom->setText(null);
 		$this->DateDiscardedTo->setText(null);

 		if (!is_null($param) && ($this->getIsCallback()))
 			$this->DateDiscardedFilterPanel->render($param->getNewWriter());
	}
	
	public function onSelectMyLibrary($sender, $param)
	{
		$newLibrary = $this->getUser()->getActualLibraryId();
		
		if ($newLibrary >= 0)
			$this->HomeLibraryFilter->setSelectedValue($newLibrary);

		$this->doToLibrarySwitches();
		$this->HomeLibraryFilterPanel->render($param->getNewWriter());
	}

	public function onSelectAllLibrary($sender, $param)
	{
		$newLibrary = 0;
		$this->HomeLibraryFilter->setSelectedValue($newLibrary);

		$this->doToLibrarySwitches();
		$this->HomeLibraryFilterPanel->render($param->getNewWriter());
	}

	public function doToLibrarySwitches()
	{
		$linksVisibility = $this->HomeLibraryFilter->getSelectedIndex() > 0;
		$this->HomeLibraryFilterAllLinkButton->setVisible($linksVisibility);
		$this->HomeLibraryFilterOnlySelectedLinkButton->setVisible(!$linksVisibility);
	}

	private function resetNoManifestationFilter()
	{
		$this->NoManifestationFilter->setSelectedIndex(0);
	}

	public function onChangeNoManifestation($sender, $param)
	{
		$this->onSearchItem(null, null);
	}

}