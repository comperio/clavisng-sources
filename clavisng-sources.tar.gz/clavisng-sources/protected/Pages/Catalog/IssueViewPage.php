<?php

/**
 * IssueViewPage class
 *
 * @author Max Pigozzi <mpigozzi@e-portaltech.it>
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2008 ePortal Technologies
 * @copyright Copyright &copy; 2009 Comperio srl
 * @version 2.7
 * @package Pages.Catalog
 * @since 2.3
 */
class IssueViewPage extends ClavisPage
{
	public $_module = 'CATALOG';
	private $_id;
	private $_issue = null;
	private $_loanmanager;
	private $_requestmanager;
	private $_extraModeSessionName;
	private $_llibraryActive;

	private function initVars()
	{
		$this->_loanmanager = $this->getApplication()->getModule('loan');
		$this->_requestmanager = $this->getApplication()->getModule('request');
		$this->_llibraryActive = (ClavisParamPeer::getParam('LLIBRARY_ACTIVE') == 1);

		$uniqueId = $this->getUniqueID();
		$this->_extraModeSessionName = 'ExtraModeSessionName' . $uniqueId;
	}

	/**
	 * On the onInit phase, the first time we enter the page,
	 *  we get the eventual librarianId, passed
	 * as a get parameter or create a new one, and next we use the
	 * internal function setLibrarian to put it in the viewstate.
	 *
	 * @param TEventParameter $param
	 */
	public function onInit($param)
	{
		parent::onInit($param);
		$this->initVars();

		$this->setIssueId(intval($this->getRequest()->itemAt('id')));

		$issue = IssueQuery::create()->findPk($this->_id);
		if (!($issue instanceof Issue))
		{
			$this->writeMessage(Prado::localize('Il fascicolo con id=')
					. $this->_id . ' '
					. Prado::localize('non esiste'), ClavisMessage::ERROR);

			$this->gotoPage('Catalog.Record');
		}

		$this->setIssue($issue);
	}

	/**
	 * On the onLoad we populate the textbox "Title" if the proper
	 * value is passed as a get parameter, and we must initialize
	 * EACH instance of repeatable list in the page (by $this->addItem).
	 *
	 * @param unknown_type $param
	 */
	public function onLoad($param)
	{
		parent::onLoad($param);

		$myUser = $this->getUser();
		if ($this->_id > 0)
		{
			$issue = $this->getIssue();
			$this->UpdateData->setObject($issue);
			$this->IssueView->setIssue($issue);
			$this->ItemListMine->setIssue($issue);
			$this->ItemListOther->setIssue($issue);
			$this->AttachList->setObjectClass('Issue');
			$this->AttachList->setObjectId($this->_id);

			$analytics = array();

			$cup = new Criteria();
			$cup->add(LManifestationPeer::ISSUE_ID, $this->_id);
			$cdown = clone $cup;
			$cup->add(LManifestationPeer::MANIFESTATION_ID_DOWN, $issue->getManifestationId());
			$cdown->add(LManifestationPeer::MANIFESTATION_ID_UP, $issue->getManifestationId());
			$lmandown = LManifestationPeer::doSelectJoinManifestationRelatedByManifestationIdDown($cdown);
			$lmanup = LManifestationPeer::doSelectJoinManifestationRelatedByManifestationIdUp($cup);
			/* @var $l LManifestation */
			foreach ($lmandown as $l)
				$analytics[] = $l->getManifestationRelatedByManifestationIdDown();
			foreach ($lmanup as $l)
				$analytics[] = $l->getManifestationRelatedByManifestationIdUp();
			$this->Analytics->setDataSource($analytics);
			$this->Analytics->dataBind();

			$reservable = $this->_requestmanager->isIssueReservable($issue);
			$this->ReserveIssueButton->setEnabled($reservable);
		}

		$this->InsertItem->setEnabled($myUser->checkAllowedPage('Catalog.ItemInsertPage'));
		$this->Edit->setEnabled($myUser->checkAllowedPage('Catalog.IssueInsertPage'));

		if (!$this->getIsPostBack() && !$this->getIsCallback())
		{
			if ($reservable && false)
			{
				$this->ReserveDeliveryLibrary->setDataSource(LibraryPeer::getLibrariesHash());
				$this->ReserveDeliveryLibrary->dataBind();
				$this->ReserveDeliveryLibrary->setSelectedValue($myUser->getActualLibraryId());
			}

			$this->doPatronClean();
			$this->doExternalLibraryClean();
			$this->resetExtraMode();
		}

		// discarded check part
		$manifestation = null;
		$manifestationId = $this->getManifestationId();
		if (intval($this->getManifestationId()) > 0)
			$manifestation = ManifestationQuery::create()->findPk($manifestationId);

		if ($manifestation instanceof Manifestation)
			$this->DiscardedTeleportButton->setVisible($manifestation->countDiscardedItems() > 0);
		else
			$this->DiscardedTeleportButton->setVisible(false);
	}

	public function onIssueEdit($sender, $param)
	{
		$this->gotoPage("Catalog.IssueInsertPage", array("issueId" => $this->getIssueId()));
	}

	public function onItemInsert($sender, $param)
	{
		$this->getIssue();

		if (!is_null($this->_issue))
			$this->gotoPage("Catalog.ItemInsertPage", array("issueId" => $this->getIssueId()));
	}

	public function onAnalyticInsert($sender, $param)
	{
		$this->getIssue();
		if (is_null($this->_issue))
			return;

		$man = new Manifestation();
		$man->setManifestationStatus(ManifestationPeer::STATUS_INCOMPLETE);
		$man->setCatalogationLevel(0);
		$man->setBibLevel('a');
		$tm = TurboMarc::createRecord();
		$l = new TurboMarcLeader();
		$l->biblevel = 'a';
		$tm->setLeader($l);
		$f101 = $tm->addField('101');
		$f101->addSubField('a', 'ita');
		$f200 = $tm->addField('200');
		$f200->addSubField('a', 'Nuovo titolo di contenuto');
		$man->setUnimarc($tm->asXML());
		$man->setTitle('Nuovo titolo di contenuto');
		$man->save();
		$lman = new LManifestation();
		$lman->setManifestationIdUp($man->getManifestationId());
		$lman->setManifestationIdDown($this->_issue->getManifestationId());
		$lman->setIssueId($this->_id);
		$lman->setLinkType(461);
		$lman->save();
		$this->gotoPage('Catalog.EditRecord', array('manifestationId' => $man->getManifestationId()));
	}

	public function onIssueReplace($sender, $param)
	{
		$this->getIssue();

		if (!is_null($this->_issue))
			$this->gotoPageWithReturn("Catalog.IssueReplacePage", array("issueId" => $this->getIssueId()));
	}

	public function setIssue($issue)
	{
		$this->_issue = $issue;
		$this->setViewState("issue", $issue, null);
	}

	public function getIssue()
	{
		if (is_null($this->_issue))
			$this->_issue = $this->getViewState('issue', null);

		return $this->_issue;
	}

	public function setIssueId($id)
	{
		$this->_id = $id;
		$this->setViewState("id", $id, null);
	}

	public function getIssueId()
	{
		if (is_null($this->_id))
			$this->_id = $this->getViewState("id", null);

		return $this->_id;
	}

	public function getManifestationId()
	{
		$manifestationId = null;
		$issue = $this->getIssue();
		if ($issue instanceof Issue)
			$manifestationId = $issue->getManifestationId();

		return $manifestationId;
	}

	/**
	 * It is called by one of the inner components, and
	 * performs the population (refresh) of all the components
	 * (the calling is included).
	 *
	 */
	public function globalRefresh()
	{
		//$this->ProfilesGrid->populate();
		//$this->LibrarianGrid->populate();
		//$this->NotificationList->populate();
	}

	/**
	 * It's called by one of the inner componentes, and
	 * performs the "cancel" (return to non-edit status)
	 * of all the components (the calling is included).
	 *
	 * @param TControl $component
	 */
	public function globalCancel($component)
	{
		
	}

	public function resetExtraMode($param = false)
	{
		$this->setExtraMode($param);
	}

	public function setExtraMode($param = false)
	{
		$this->getApplication()->getSession()->add($this->_extraModeSessionName, $param);
	}

	public function getExtraMode()
	{
		return $this->getApplication()->getSession()->itemAt($this->_extraModeSessionName);
	}

	public function onSwitchExtraMode($sender, $param)
	{
		$this->doPatronClean();
		$this->doExternalLibraryClean();
		$this->setExtraMode(!$this->getExtraMode());

		$this->MaxDistancePanel->setVisible(!$this->getExtraMode());

		if (!is_null($param) && $this->getPage()->getIsCallBack())
			$this->PanelReserve->render($param->getNewWriter());
	}

	public function onOpenReservePanel($sender, $param)
	{
		$this->setExtraMode(false);
		$this->ExtraModeCheck->setChecked(false);

		$this->populateMaxDistance($this->getIssue(), $this->getUser()->getActualLibraryId());

		$this->PanelReserve->setCssClass("panel_on");
		if ($this->getPage()->getIsCallBack())
		{
			if (is_null($param))
				$this->PanelReserve->render($this->getPage()->createWriter());
			else
				$this->PanelReserve->render($param->getNewWriter());

			$this->ReserveDeliveryLibrary->setDataSource(LibraryPeer::getLibrariesHash(null, null, true, true));  // solo attive ...
			$this->ReserveDeliveryLibrary->dataBind();
			$this->ReserveDeliveryLibrary->setSelectedValue($this->getUser()->getActualLibraryId());
		}

		$this->writeMessage(Prado::localize("Pannello delle prenotazioni aperto"), ClavisMessage::INFO);
		$this->getPage()->setFocus("anchor_reserve");
	}

	public function onExternalLibraryIdChanged($sender, $param)
	{
		$library = $this->getExternalLibrary();
		if (is_null($library))
			return;

		$this->insertExternalLibrary($library->getLibraryId());
	}

	private function populateMaxDistance($issue, $deliveryLibraryId)
	{
		// if basin system is active
		if ($this->_llibraryActive)
		{
			$this->MaxDistancePanel->setCssClass('panel_on');

			//$manifestation = $issue->getManifestation();
			$distances = LLibraryPeer::calculateRequestDistances(false);

			if ((count($distances) > 0) && ($issue instanceof Issue)) // there are results
			{
				$this->MaxDistance->setCssClass('panel_on_inline');
				$this->MaxDistanceNoResult->setCssClass('panel_off');

				$this->MaxDistance->setDataSource($distances);
				$this->MaxDistance->dataBind();

				$minDistance = $this->_requestmanager->calculateMinRequestDistance($issue, $deliveryLibraryId);
				if (!is_null($minDistance))
				{
					if (array_key_exists($minDistance, $distances))
						$selectedDistance = $minDistance;
					else
						$selectedDistance = 0;

					$this->MaxDistance->setSelectedValue($selectedDistance);
				}
			}
			else // no results
			{
				$this->MaxDistance->setCssClass('panel_off');
				$this->MaxDistanceNoResult->setCssClass('labelError');
			}
		}
		else // basin system is not active
		{
			$this->MaxDistancePanel->setCssClass('panel_off');
		}

		if ($this->getPage()->getIsCallback())
			$this->MaxDistancePanel->render($this->getPage()->createWriter());
	}

	public function suggestPatron($sender, $param)
	{
		$token = $param->getCallBackParameter(); //the partial word to match
		$sender->setDataSource(PatronPeer::doSuggest($token, 10, true,true)); //set suggestions
		$sender->dataBind();
	}

	/**
	 * Ajax callback which makes some action after the string in the
	 * autocomplete textbox has been choosen.
	 * In particular, it populates some labels with patron's data.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function suggestPatronCallBack($sender, $param)
	{
		$resultFlag = false;
		$fieldText = trim( $this->ReservePatronLabel->getSafeText() );
		$match = array();
		if (preg_match("/\(([^\)]+)\)$/", $fieldText, $match))
			$patronBarcode = $match[1];
		else
			$patronBarcode = $fieldText;

		$patrons = PatronPeer::getPatronsByBarcode($patronBarcode);

		if ($patrons->isEmpty())
		{
			$this->ReservePatronLabel->setText('');
			return;
		}

		$patron = $patrons->shift();
		if (!$patrons->isEmpty())
		{
			// TODO: notifica di barcodes utente duplicati
			// Per adesso lo fa la ClavisUserDataCard
		}

		if ($patron instanceof Patron)
		{
			$patronId = $patron->getPatronId();
			$resultFlag = $this->insertPatron($patronId);
		}

		if ($resultFlag)
			$this->ReservePatronLabel->setText('');
	}

	

	public function insertPatron($patronId)
	{
		$returnFlag = $this->UserData->populate($patronId);

		$this->UserDataPanel->setVisible($returnFlag);
		$this->CirculationData->populate($patronId);

		$patron = PatronPeer::retrieveByPK($patronId);
		$barcode = $patron->getBarcode();
		$this->PatronId->setText($barcode);
		$this->ReservePatronLabel->setText($patron->getReverseCompleteName() . ' (' . $barcode . ')');
		$this->ReservePatronId->setText($patronId);

		if ($returnFlag)
		{
			$this->calculateReservable();

			return true;
		}
		else
		{
			$this->writeMessage(Prado::localize('Errore di formato'), ClavisMessage::ERROR);
			$this->getPage()->setFocus($this->ReservePatronLabel->getClientID());

			$this->DoReserve->setEnabled(false);
			return false;
		}
	}

	public function suggestLibrary($sender, $param)
	{
		$token = $param->getCallBackParameter();
		$sender->setDataSource($this->getLibrarySuggestionsFor($token));
		$sender->dataBind(false);
	}

	public function suggestLibraryCallBack($sender, $param)
	{
		$resultFlag = false;
		$fieldText = $this->ReserveExternalLibraryLabel->getSafeText();
		$match = array();

		if (preg_match("/\[id:\ ([^\]]+)\]$/", $fieldText, $match))
			$libraryId = $match[1];
		else
			$libraryId = $fieldText;

		$libraryId = intval($libraryId);
		$library = LibraryPeer::retrieveByPK($libraryId);

		if (!is_null($library))
			$resultFlag = $this->insertExternalLibrary($libraryId, $param);

		if ($resultFlag)
			$this->ReserveExternalLibraryLabel->setText('');
	}

	private function getLibrarySuggestionsFor($token)
	{
		$list = array();
		$criteria = new Criteria();

		$token = trim($token);
		if ($token != "")
		{
			$criteria->add(LibraryPeer::LABEL, "%" . $token . "%", Criteria::LIKE);
			$criteria->add(LibraryPeer::LIBRARY_INTERNAL, 1, Criteria::NOT_EQUAL);

			$criteria->setLimit(10);
			$criteria->addAscendingOrderByColumn(LibraryPeer::LABEL);
			$libraries = LibraryPeer::doSelect($criteria);

			foreach ($libraries as $library)
				$list[] = $library->getLabel() . " (" . $library->getConsortiaString(20) . ") [id: " . $library->getLibraryId() . "]";
		}

		return $list;
	}

	public function insertExternalLibrary($libraryId, $param = null)
	{
		$libraryId = intval($libraryId);
		$returnFlag = true;
		$this->LibraryData->populate($libraryId);  /////da implementare un clavislibrarydatacard
		$returnFlag = ($this->LibraryData->Populated->getValue() == 'true' ? true : false);

		$this->LibraryDataPanel->setCssClass($returnFlag ? 'panel_on' : 'panel_off');	//setVisible($returnFlag);
		$this->LibraryData->setVisible($returnFlag);

		if ($this->getPage()->getIsCallBack())
		{
			if (is_null($param))
				$writer = $this->getPage()->createWriter();
			else
				$writer = $param->getNewWriter();

			$this->LibraryDataPanel->render($writer);
		}

		$library = LibraryPeer::retrieveByPK($libraryId);
		if (is_null($library))
			$label = '';
		else
			$label = $library->getLabel() . ' (' . $libraryId . ')';

		$this->ExternalLibraryId->setText($libraryId);
		$this->ReserveExternalLibraryLabel->setText($label);
		$this->ReserveExternalLibraryId->setText($libraryId);

		if ($returnFlag)
		{
			$verifyCode = $this->_requestmanager->isIssueReservable($this->_issue);
			if ($verifyCode == ClavisLoanManager::OK)
			{
				$this->DoReserve->setEnabled(true);
				$this->getPage()->setFocus($this->DoReserve->getClientID());
			}
			else
			{
				$this->DoReserve->setEnabled(false);

				switch ($verifyCode)
				{
					case ClavisLoanManager::RSV_NOTAVAIL:
						$message = Prado::localize("Notizia non prenotabile");
						break;

					case ClavisLoanManager::RSV_PATRONREQMANIF:
						$message = Prado::localize("Notizia già prenotata dall'utente");
						break;

					case ClavisLoanManager::RSV_PATRONMAXREQ:
						$message = Prado::localize("L'utente ha gia' raggiunto il numero massimo di prenotazioni consentite");
						break;

					case ClavisLoanManager::RSV_RATING:
						$this->getPage()->writeMessage(Prado::localize("Prenotazione non possibile perchè utente minore dell'età consentita dal titolo."), ClavisMessage::ERROR);
						break;

					default:
						$message = Prado::localize("errore");
						break;
				}

				$this->writeMessage($message, ClavisMessage::ERROR);
			}

			return true;
		}
		else
		{
			$this->getPage()->setFocus($this->ReserveExternalLibraryLabel->getClientID());

			$this->DoReserve->setEnabled(false);
			return false;
		}
	}

	public function getPatron()
	{
		$patron = null;
		$patronId = intval($this->ReservePatronId->getSafeText());
		if ($patronId > 0)
			$patron_id = $patronId;
		else
			$patron_id = intval($this->ReserveHiddenValue->getValue());

		if ($patron_id > 0)
			$patron = PatronPeer::retrieveByPK($patron_id);

		return $patron;
	}

	public function getExternalLibraryId()
	{
		$libraryId = intval($this->ReserveHiddenValue2->getValue());
		if ($libraryId > 0)
			$library_id = $libraryId;
		else
			$library_id = intval($this->ReserveExternalLibraryId->getSafeText());

		return intval($library_id);
	}

	public function getExternalLibrary()
	{
		$library = null;

		$libraryId = $this->getExternalLibraryId();
		if ($libraryId > 0)
			$library = LibraryPeer::retrieveByPK($libraryId);

		return $library;
	}

	public function onPatronIdChanged($sender, $param)
	{
		$patron = $this->getPatron();
		if (is_null($patron))
			return;

		$this->insertPatron($patron->getPatronId());
	}

	public function onReserveDeliveryLibraryChanged($sender, $param)
	{
		$this->calculateReservable();
	}

	private function calculateReservable()
	{
		$patron = $this->getPatron();

		$deliveryLibraryId = $this->ReserveDeliveryLibrary->getSelectedValue();
		$this->drawReserveButton($this->_issue, $patron, $deliveryLibraryId);

		if ($this->_llibraryActive && !$this->getExtraMode())
			$this->populateMaxDistance($this->_issue, $deliveryLibraryId);
	}

	private function drawReserveButton($issue, $patron, $deliveryLibraryId)
	{
		$reserve = false;

		if ($patron instanceof Patron)
		{
			switch ($this->_requestmanager->isIssueReservable($issue, $patron, $deliveryLibraryId))
			{
				case (ClavisLoanManager::OK) :
					$this->getPage()->writeMessage(Prado::localize("La prenotazione è consentita"), ClavisMessage::INFO);
					$reserve = true;
					break;

				case (ClavisLoanManager::RSV_NOTAVAIL) :
					$this->getPage()->writeMessage(Prado::localize("Attenzione: la prenotazione viene consentita, però al momento nessun esemplare nel sistema può soddisfarla !!"), ClavisMessage::ERROR);
					$reserve = true;
					break;
				/// Esemplare non disponibile per il prestito

				case (ClavisLoanManager::RSV_PATRONMAXREQ) :
					$this->getPage()->writeMessage(Prado::localize("L'utente ha già raggiunto il massimo numero di prenotazioni [{max}]", array('max' => ClavisParamPeer::getParam('MAXLOANRESERVATIONS_' . $patron->getLoanClass(), '0'))), ClavisMessage::ERROR);
					break;

				case (ClavisLoanManager::RSV_PATRONREQMANIF) :
					$this->getPage()->writeMessage(Prado::localize("L'utente ha già una prenotazione per questo titolo"), ClavisMessage::ERROR);
					break;

				case ClavisLoanManager::RSV_RATING:
					$this->getPage()->writeMessage(Prado::localize("Prenotazione non possibile perchè utente minore dell'età consentita dal titolo."), ClavisMessage::ERROR);
					break;

				case (ClavisLoanManager::ERROR) :
				default:
					$this->getPage()->writeMessage(Prado::localize("Errore: esemplare non prenotabile da questo utente"), ClavisMessage::ERROR);
					break;
			}
		}

		$this->DoReserve->setEnabled($reserve);
	}

	public function onReserveIssue($sender, $param)
	{
		$this->cleanMessageQueue();

		$issue = $this->getIssue();
		$patron = $this->getPatron();
		$externalLibrary = $this->getExternalLibrary();
		$extraMode = $this->getExtraMode();

		$manifestation = $issue->getManifestation();
		if (!$manifestation instanceof Manifestation)
		{
			$this->enqueueMessage(Prado::localize("Errore: al fascicolo non corrisponde nessuna notizia"),
									ClavisMessage::ERROR);
		}
		elseif (!$extraMode && !($patron instanceof Patron))
		{
			$this->enqueueMessage(Prado::localize("Errore sul passaggio parametri dell'utente"),
									ClavisMessage::ERROR);
		}
		elseif ($extraMode && !($externalLibrary instanceof Library))
		{
			$this->enqueueMessage(Prado::localize("Errore sul passaggio parametri della biblioteca esterna"),
									ClavisMessage::ERROR);
		}
		else
		{
			$clavisLibrarian = $this->getUser();
			$deliveryLibrary = LibraryQuery::create()
					->findPk($this->ReserveDeliveryLibrary->getSelectedValue());

			$request_note = $this->RequestNote->getSafeText();

			$maxDistance = ($this->_llibraryActive && !$this->getExtraMode() ? $this->MaxDistance->getSelectedValue() : null );

			$returnVal = $this->_requestmanager->reserveManifestation($manifestation, $patron, $deliveryLibrary, $clavisLibrarian, $request_note, $issue->getIssueId(), $this->getExternalLibraryId(), $maxDistance);

			if (($returnVal == ClavisLoanManager::OK) || ($returnVal == ClavisLoanManager::RSV_NOTAVAIL))
			{
				if (!$extraMode)
					$this->enqueueMessage(Prado::localize("Fascicolo prenotato: '{title}' / {issue} [id: {id}] per l'utente {patronName}", array('title'		 => $manifestation->getTrimmedTitle(40),
								'issue'		 => $issue->getIssueCombo(true),
								'id'		 => $manifestation->getManifestationId(),
								'patronName' => $patron->getCompleteName())), ClavisMessage::CONFIRM);
				else
					if ($manifestation->getLoanableSince('U') > time())
						$this->enqueueMessage(Prado::localize('La notizia cui il fascicolo si riferisce è disponibile solo dal {date}', array('date' => Clavis::dateFormat($manifestation->getLoanableSince('U')))), ClavisMessage::WARNING);

				if (!$this->_loanmanager->IsRatingAllowed($manifestation, $patron))
					$this->enqueueMessage(Prado::localize("La notizia cui il fascicolo si riferisce è disponibile solo per gli utenti con piu' di {rating} anni", array('rating' => $manifestation->getRating())), ClavisMessage::WARNING);

				if ($returnVal == ClavisLoanManager::RSV_NOTAVAIL)
					$this->enqueueMessage(Prado::localize("Attenzione: al momento non esiste alcun esemplare in grado di soddisfare la prenotazione per questo fascicolo"), ClavisMessage::WARNING);

				//cleaning and closing ......
				$this->ReserveHiddenValue->setValue('');
				$this->ReserveHiddenValue2->setValue('');

				$this->ReservePatronId->setText('');
				$this->PatronId->setText('');
				$this->ExternalLibraryId->setText('');
				$this->ReserveExternalLibraryId->setText('');

				$this->ReservePatronLabel->setText('');
				$this->ReserveExternalLibraryLabel->setText('');

				$this->UserData->populate(-1);
				$this->CirculationData->setPatronId(null);
				$this->CirculationData->populate(null);
				$this->LibraryData->populate(null);

				$this->DoReserve->setEnabled(false);
				$this->PanelReserve->setCssClass("panel_off");

				if ($this->getIsCallback())
				{
					if (is_null($param))
						$this->PanelReserve->render($this->getPage()->createWriter());
					else
						$this->PanelReserve->render($param->getNewWriter());
				}
			}
			else
			{
				$this->enqueueMessage(Prado::localize("Prenotazione fallita"), ClavisMessage::ERROR);
			}
		}

		$this->flushMessage();
	}

	public function onPatronClean($sender, $param)
	{
		$this->doPatronClean(true);
	}

	private function doPatronClean($focus = false)
	{
		$this->ReservePatronLabel->setText('');
		$this->UserData->populate(null);
		$this->CirculationData->setPatronId(null);
		$this->CirculationData->populate(null);

		$this->PatronId->setText(0);
		$this->ReserveHiddenValue->setValue('');
		$this->DoReserve->setEnabled(false);

		if ($focus)
			$this->setFocus($this->ReservePatronLabel->getClientID());
	}

	public function onPatronReload($sender, $param)
	{
		$this->insertPatronId(trim($this->PatronId->getSafeText()));
	}

	public function onExternalLibraryClean($sender, $param)
	{
		$this->doExternalLibraryClean(true, $param);
	}

	private function doExternalLibraryClean($focus = false, $param = null)
	{
		$this->LibraryData->populate(null); // implementare una sorta di ClavisLibraryDataCard
		$this->LibraryDataPanel->setCssClass('panel_off');
		if ($this->getPage()->getIsCallBack())
		{
			if (is_null($param))
				$this->LibraryDataPanel->render($this->getPage()->createWriter());
			else
				$this->LibraryDataPanel->render($param->getNewWriter());
		}

		$this->ExternalLibraryId->setText(0);
		$this->ReserveHiddenValue2->setValue('');
		$this->DoReserve->setEnabled(false);

		$this->ReserveExternalLibraryLabel->setText('');
		if ($focus)
			$this->setFocus($this->ReserveExternalLibraryLabel->getClientID());
	}

	public function onGotoDiscarded($sender, $param)
	{
		$manifestationId = $this->getManifestationId();

		if (intval($manifestationId) > 0)
			$this->gotoPage(	"Catalog.ItemListPage", 
								array(	"manifestationId" => $manifestationId,
										"itemStatus" => ItemStatus::ITEMSTATUS_DISCARDED ));
	}
	
}