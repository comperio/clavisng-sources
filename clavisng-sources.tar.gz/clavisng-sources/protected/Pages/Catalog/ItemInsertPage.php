<?php
/**
 * ItemInsertPage class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Pages.Catalog
 */

/**
 * ItemInsertPage Class
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Pages.Catalog
 * @since 2.0
 */
class ItemInsertPage extends ClavisPage
{
	public $_module = 'CATALOG';
	public $_itemId;
	/* @var Item */
	private $_item = null;
	private $_isNew;
	/* @var ClavisSBN */
	protected $_sbnMod;

	public $_itemOwnerTest;
	public $_invoiceClosedFlag;

	protected $_loanmanager;

	public $_decimalSep = '';
	public $_groupSep = '';
	public $_invdecimalSep = '';
	public $_invgroupSep = '';
	
	public $_maxPrice;
	public $customs_type = array('text','text','text');
	
	private function initVars()
	{
		$this->_loanmanager = $this->getApplication()->getModule('loan');
		$this->_maxPrice = (float) ClavisParamQuery::getParam('CLAVISPARAM','AcquisitionMaxPriceLimit');
		
		$separatorData = ClavisBase::getSeparatorData();

		if (array_key_exists('decimal', $separatorData))
			$this->_decimalSep = $separatorData['decimal'];
		
		if (array_key_exists('group', $separatorData))
			$this->_groupSep = $separatorData['group'];
		
		if (array_key_exists('invariantdecimal', $separatorData))
			$this->_invdecimalSep = $separatorData['invariantdecimal'];
		
		if (array_key_exists('invariantgroup', $separatorData))
			$this->_invgroupSep = $separatorData['invariantgroup'];
	}

	public function onInit($param)
	{
		parent::onInit($param);
		$this->initVars();

		if (!$this->getIsPostBack() && !$this->getIsCallback())		// first page cycle
		{
			$issueValidFlag = false;
			
			$this->ExternalAlertPanel->setCssClass('panel_off');

		    $id = intval($this->getRequest()->itemAt('id'));
		    $manif_id = intval($this->getRequest()->itemAt('manifestationId'));
		    $issue_id = intval($this->getRequest()->itemAt('issueId'));

			if ($id > 0) 
			{
				$this->setIsNew(false);

				$item = ItemQuery::create()->findPK($id);
				if (!($item instanceof Item))
				{
					$this->writeMessage(Prado::localize("L'esemplare con id = {id} non esiste", 
															array('id' => $id)),
											ClavisMessage::ERROR);
					
					$this->gotoPage('Catalog.ItemListPage');
				}
				
				$this->setItem($item);
				$this->btnGetInventoryCounter->setEnabled(true);
			} 
			else 
			{
				$this->setIsNew(true);

				$item = new Item();
				$item->setLoanStatus(ItemPeer::LOANSTATUS_AVAILABLE);
				$item->setOwnerLibraryId($this->getUser()->getActualLibraryId());
				$item->setHomeLibraryId($this->getUser()->getActualLibraryId());
				$item->setActualLibraryId($this->getUser()->getActualLibraryId());

				if ($manif_id > 0)
				{
					$manifestation = ManifestationQuery::create()->findPK($manif_id);
					if ($manifestation instanceof Manifestation)
					{
						$item->setManifestationId($manif_id);
						if (ClavisParamQuery::getParam('CLAVISPARAM','AutoItemCallNumber') == 'true')
						{
							$class = $manifestation->getClass(true);
							
							if ($class instanceof Authority) 
							{
								$tm = $class->getTurboMarc();
								if (isset($tm->d676->si))
									$code = (string)$tm->d676->si;
								else if (isset($tm->d680->si))
									$code = (string)$tm->d680->si;
								else if (isset($tm->d686->si))
									$code = (string)$tm->d686->si;
								else
									$code = $class->getClassCode();
								$item->setCollocation($code);
							}
							$author = explode('*',$manifestation->getAuthor(),2);
							$author = array_pop($author);
							$item->setSpecification(trim(mb_strtoupper(mb_substr($author,0,3,'UTF-8'),'UTF-8').' '.
								mb_strtoupper(mb_substr($manifestation->getSortText(),0,3,'UTF-8'),'UTF-8')));
						}
					}
					else	// it's an OOC
					{
						$item->setManifestationId(0);
					}
				}
				else	// it's an OOC
				{
					$item->setManifestationId(0);
				}
				
				
				if ($issue_id != null) 
				{
					$issue = IssueQuery::create()->findPK($issue_id);
					
					if ($issue instanceof Issue) 
					{
						$issueValidFlag = true;
						$item->setIssueId($issue_id);
						$issueManifestation = $issue->getManifestation();
						if (is_null(($issueManifestation)))
							$issueManifestation = 0;
						$item->setManifestation($issueManifestation);
                                                
						/*
						 * This settings was reported from itemSave:
						 * old code is not working in some cases so a bit clean was made
						 * with $this->_item as target.
						 */
						$item->setIssueYear($issue->getIssueYear());
						$item->setIssueNumber($issue->getStartNumber());
						$item->setIssueDescription($issue->getIssueNumber());
					}
				}
				else
				{
					$item->setIssueYear('');
					$item->setIssueNumber(0);
					$item->setIssueDescription('');
				}

				$this->setItem($item);
			}	// end of IF itemId was not passed as a param

			if ($this->getIsNew())		// item is being created (not yet existing in DB)
			{
				$this->ItemPurchaseTabView->setVisible(false);
				$this->LinkTabView->setVisible(false);
				$this->NotesPanel->setVisible(false);
				$this->ItemIssueTabView->setVisible($issueValidFlag);

				$this->NewConsistencyOnTheFly->Attributes->onclick = "alert('".
					Prado::localize('E\\\' necessario salvare l\\\'esemplare per abilitare la creazione al volo di una nuova consistenza.')."');return false;";
				$this->NewConsistencyOnTheFly->setForeColor('gray');
			} 
			else		// item is already existing in the DB
			{
				$this->Notes->setItem($this->getItem());
				$this->ItemIssueTabView->setVisible(intval($item->getIssueId()) > 0);
			}

			$this->AuthorityLink->setItemId($this->getItemId());
			$this->AuthorityLink->populate();

			$this->populateSerieSection();
			
			$manifestation = $this->_item->getManifestation();
			if ($manifestation instanceof Manifestation) 
			{
		    	$this->PopupIssueLinkButton->setEnabled(true);
		    	$popupPage = 'Catalog.IssueListPopup&param=' . $manifestation->getManifestationId();
		    	$this->PopupIssueLinkButton->setPopupPage($popupPage);
				$this->populateConsistencyList();
		    } 
			else 
			{
		    	$this->PopupIssueLinkButton->setEnabled(false);
		    	$this->PopupIssueLinkButton->setVisible(false);
		    }

		    if (!is_null($issue_id))
			{
		    	$this->PopupIssueLinkButton->setEnabled(false);
		    	$this->PopupIssueLinkButton->setVisible(false);
		    }

			$mediapackage_size_max = intval(ClavisParamPeer::getParam('MEDIAPACKAGE_SIZE_MAX'));
			if ($mediapackage_size_max > 0)
			{
				$mediapackageArray = array();
				for ($co = 1; $co <= $mediapackage_size_max; $co++)
					$mediapackageArray[$co] = $co;
				$this->Mediapackage_size->setDataSource($mediapackageArray);
				$this->Mediapackage_size->dataBind();
			}
		}  // end of first page execution

		if ($this->getIsNew())
			$this->PageTitle->setText(Prado::localize('Inserimento nuovo esemplare'));
		else
			$this->PageTitle->setText(Prado::localize('Modifica esemplare'));
		
		$this->_itemOwnerTest = true;
		$item = $this->getItem();
		if ($item instanceof Item)
		{
			$ownerLibraryId = intval($item->getOwnerLibraryId());
			if ($ownerLibraryId > 0)
				$this->_itemOwnerTest = in_array($ownerLibraryId, $this->getUser()->getLibraryIds());
		}
	}

	public function onLoad($param)
	{
		parent::onLoad($param);

		$this->_sbnMod = $this->getApplication()->getModule('sbn');

		if (LookupValuePeer::classExists('ITEMCUST1'))
			$this->customs_type[0] = 'list';
		
		if (LookupValuePeer::classExists('ITEMCUST2'))
			$this->customs_type[1] = 'list';
		
		if (LookupValuePeer::classExists('ITEMCUST3'))
			$this->customs_type[2] = 'list';

		$item = $this->getItem();
		$this->_isNew = $this->getIsNew();

		if (!$this->getIsPostBack() && !$this->getIsCallback())
		{
			$ownerLibraryId = intval($item->getOwnerLibraryId());
			if ($ownerLibraryId > 0)
			{
				$this->PopupBudgetLinkButton->setParam($ownerLibraryId);
				$this->PopupBudgetLinkButton->setObjectType('library');
			}
			
			$changeableOwner = $this->getOwnerLibraryChangeable();
			$changeableHome = $this->getItemLibraryChangeable();

			$this->ManifestationView->setManifestation($item->getManifestation());

			//$manifestation = $item->getManifestation();
			//if ($manifestation instanceof Manifestation)
			if (!$item->isOoc())	
			{
				$this->ChooseOwnerLibrary->setVisible($changeableOwner);
				$this->ChooseActualLibrary->setVisible(false);
				$this->ManifestationYesPanel->setVisible(true);
				$this->ManifestationNoPanel->setVisible(false);
				$this->ManifestationView->setManifestation($item->getManifestation());
			}
			else	// Ooc, fuori catalogo
			{
				$this->ChooseOwnerLibrary->setVisible($changeableOwner);	// && $this->_isNew
				$this->ChooseActualLibrary->setVisible($changeableHome && $this->_isNew);
				$this->ManifestationYesPanel->setVisible(false);
				$this->ManifestationNoPanel->setVisible(true);
				$this->ItemTitle->setText($item->getTitle());
			}

			$this->drawInventorySerieIdPanel($item->isExternal());

			$this->UpdateData->setObject($item);
			$this->populate();
		}
		
		$this->SBNTabView->setVisible($this->_sbnMod->getEnabled()
										&& ($item instanceof Item)
										&& !$item->isNew()
										&& !$item->isOoc());
	}

	public function onPreRender($param)
	{
		parent::onPreRender($param);

		if ($this->SBNTabView->getVisible()) {
			switch ($this->SBNActions->getSbnStatus()) {
				case 'unlocalizable':
					$this->SBNTabView->setCaption('SBN <img style="height:12px;border:0;margin:0;padding:0;" src="themes/Default/icons/nav_plain_red-16.png" />');
					break;
				case 'localizable':
					$this->SBNTabView->setCaption('SBN <img style="height:12px;border:0;margin:0;padding:0;" src="themes/Default/icons/nav_plain_yellow-16.png" />');
					break;
				default:
					$this->SBNTabView->setCaption('SBN <img style="height:12px;border:0;margin:0;padding:0;" src="themes/Default/icons/nav_plain_green-16.png" />');
					break;
			}
		}

		$this->setPurchaseEditEnabledStatus();

		if ($this->getPage()->getIsCallback())
		{
			$this->renderInvoicePanel();
			$this->renderOrderPanel();
			$this->renderSupplierPanel();
			$this->renderBudgetPanel();
		}
		
		$item = $this->getItem();
		$this->_isNew = $this->getIsNew();
		
		if ((!$this->_isNew)
				&& ($this->_item->getInventoryNumber() > 0)	 // we don't need to check if we have no inv.number
				&& (!$item->isInventoryNumberUnique()))
			$this->InventoryNumberLabel->setText(Prado::localize("Numero di inventario") . " <b>(" . Prado::localize("multiplo") . ")</b>");
		else
			$this->InventoryNumberLabel->setText(Prado::localize("Numero di inventario"));
	}
	
	public function setPurchaseEditEnabledStatus()
	{
		$this->ItemVolumeNumber->setEnabled($this->_itemOwnerTest);
		
		/**
		 * Note: see if the following is to incapsulate into its own method, in
		 * ClavisLibrarian or not, in the future.
		 */
		$acquisitionAllowed = array_key_exists('ACQUISITION', $this->getUser()->getAllowedModules());
		/**
		 * If invoice is in status of 'closed', many things in the page
		 * cannot be modified, and this is prioritary, hence we find it
		 * in the end
		 */
		if ($this->_invoiceClosedFlag || !$this->_itemOwnerTest || !$acquisitionAllowed)
			$this->disablePurchaseEdit();
		else
			$this->enablePurchaseEdit();
		
		if ($this->getIsCallback())
			$this->PurchasePanel->render($this->createWriter());
	}
	
	protected function enablePurchaseEdit()
	{
		$this->PopupInvoiceLinkButton->setVisible(true);
		$this->InvoiceResetButton->setVisible(true);
		$this->PopupOrderLinkButton->setVisible(true);
		$this->OrderResetButton->setVisible(true);
		$this->PopupSupplierLinkButton->setVisible(true);
		$this->SupplierResetButton->setVisible(true);
		$this->PopupBudgetLinkButton->setVisible(true);
		$this->BudgetResetButton->setVisible(true);
		$this->ItemOrderStatus->setEnabled(true);
		
		$this->DisabledPurchaseWarning->setVisible(false);
	}
	
	protected function disablePurchaseEdit()
	{
		$this->PopupInvoiceLinkButton->setVisible(false);
		$this->InvoiceResetButton->setVisible(false);
		$this->PopupOrderLinkButton->setVisible(false);
		$this->OrderResetButton->setVisible(false);
		$this->PopupSupplierLinkButton->setVisible(false);
		$this->SupplierResetButton->setVisible(false);
		$this->PopupBudgetLinkButton->setVisible(false);
		$this->BudgetResetButton->setVisible(false);
		//$this->ItemSource->setEnabled(false);
		$this->ItemCurrency->setEnabled(false);
		$this->ItemCost->setEnabled(false);		//setReadOnly(true);
		$this->ItemDiscount->setEnabled(false);
		$this->ItemValue->setEnabled(false);
		$this->ItemOrderStatus->setEnabled(false);
		
		$this->DisabledPurchaseWarning->setVisible(true);		
	}

	public function populateConsistencyList()
	{
		$notes = ConsistencyNoteQuery::create()
					->filterByManifestationId($this->_item->getManifestationId())
					->filterByLibraryId($this->_item->getHomeLibraryId())
					->find();
		
		$ds = array('' => '---');
		foreach ($notes as $cn)
			$ds[$cn->getConsistencyNoteId()] = $cn->getCollocation().' / '.$cn->getTextNote();
		
		$this->ConsistencyList->setDataSource($ds);
		$this->ConsistencyList->dataBind();
	}

	public function populateSerieSection() 
	{
		$lid = intval($this->NewOwnerLibraryId->getValue());
		
		if ($lid == 0)
			$lid = $this->_item->getOwnerLibraryId();
		
		$inv_series = InventorySerieQuery::create()
						->orderByClosed()
						->orderByReadonly()
						->orderByInventorySerieId()
						->findByLibraryId($lid);
		
		$ds = array();
		
		foreach ($inv_series as $i)
		{
			$ds[$i->getInventorySerieId()] = $i->getDescription() . ' (' .
				$i->getInventorySerieId() . ')';
		}
		
		$this->InventorySerieId->setDataSource($ds);
		$this->InventorySerieId->dataBind();
		
		// sections part
		$sid = intval($this->HomeLibraryHid->getValue());
		
		if ($sid == 0)
		{
			$prevHomeLibrary = $this->_item->getPrevHomeLibrary();
			
			if ($prevHomeLibrary instanceof Library)
			{
				$sid = $prevHomeLibrary->getLibraryId();
				$this->SectionLabel->setText(Prado::localize("Sezione di {addPrev}",
												array('addPrev' => $prevHomeLibrary->getLabel(true, true))));
				
			}
			else
			{
				$sid = $this->_item->getHomeLibraryId();
			}
		}
		
		$this->Section->setLibraryId($sid);
		$this->Section->populateList();
	}

	public function updateConsistencyList($sender, $param)
	{
		$this->populateConsistencyList();
	}

	public function setIsNew($state)
	{
		$this->setViewState('isNew', $state, true);
	}

	public function getIsNew()
	{
		$state = $this->getViewState('isNew', true);
		return $state;
	}

	public function setExtraMode($val)
	{
		if ($val === 'true')
			$val = true;
		elseif ($val != true)
			$val = false;

		$this->setViewState('ExtraMode', $val, false);
	}

	public function getExtraMode()
	{
		return $this->getViewState('ExtraMode', false);
	}

	public function setItem($item)
	{
		if (!$item instanceof Item)
			return false;

		$this->_item = $item;
		$this->setViewState('item', $item, null);
	}

	public function getItem()
	{
		$this->_item = $this->getViewState('item', null);
		
		return $this->_item;
	}

	public function getItemId()
	{
		$item = $this->getItem();
		if ($item instanceof Item)
			return $item->getItemId();
		else
			return '';
	}

	public function checkAuth($addedCheck = true, $force = null)
	{
		$addedCheck = true;
		$item = $this->getItem();
		if ($item instanceof Item)
			$addedCheck = $this->getUser()->getEditPermission($item);
		
		parent::checkAuth($addedCheck, $force);
	}

	public function onSave($sender, $param)
	{
		if ($this->getIsValid()) 
		{
			if ($this->saveItem($param)) {
				$this->returnPage();

				if ($this->_item->getIssueId() > 0 && $this->_isNew)
					$this->gotoPage('Catalog.IssueViewPage', array('id' => $this->_item->getIssueId()));
				else
					$this->gotoPage('Catalog.ItemViewPage', array('id' => $this->_item->getItemId()));
			}
		}
	}

	public function onApply($sender, $param)
	{
		if ($this->getIsValid()) 
		{
			if ($this->saveItem($param))
			{
				if ($this->_isNew)
					$this->gotoPage('Catalog.ItemInsertPage',array('id' => $this->_item->getItemId()));
				else
					$this->OpacVisible->setChecked($this->_item->getOpacVisible());
			}
		}
	}

	protected function saveItem($param = null)
	{
		/** @var Item $_item */
		
		$this->cleanMessageQueue();
                	
		$this->_item->setOpacVisible($this->OpacVisible->getChecked());
		
		if ($this->ItemIcon->getSelectedIndex() == 0)
		{
			$this->_item->setItemIcon('');
		}
		else
		{
			$this->_item->setItemIcon($this->ItemIcon->getSelectedValue());
		}

		$this->_item->setReprint($this->Reprint->getSafeText());

		if ($this->Section->getSelectedIndex() == 0)
		{
			$this->_item->setSection(null);
		}
		else
		{
			$this->_item->setSection($this->Section->getSelectedValue());
		}

		$this->_item->setCollocation($this->Collocation->getSafeText());
		$this->_item->setSequence1($this->Sequence1->getSafeText());
		$this->_item->setSequence2($this->Sequence2->getSafeText());
		$this->_item->setSpecification($this->Specification->getSafeText());

		$this->_item->setBarcode($this->Barcode->getSafeText());
		$this->_item->setRfidCode($this->Rfid->getSafeText());
		$this->_item->setMediapackageSize($this->Mediapackage_size->getSelectedValue());

		//inventory part
		if (is_null($this->InventoryDate)) 
		{
			//NB se la data di inventariazione e' nulla, ma il numero di inventario e' presente, allora
			// suppongo di inserire la data attuale
			if ($this->InventoryNumber->getSafeText() != '') {
				$this->_item->setInventoryDate(time());
			}
		} 
		else 
		{
			$this->_item->setInventoryDate($this->InventoryDate->getTimeStamp());
		}

		//stati
		$itemOrderStatus = $this->ItemOrderStatus->getSelectedValue();
		$this->_item->setItemOrderStatus($itemOrderStatus);
		
		$oldItemStatus = $this->_item->getItemStatus();
		$newItemStatus = $this->ItemStatus->getSelectedValue();
		
		if ($oldItemStatus != $newItemStatus
				&& in_array($newItemStatus, ItemPeer::getItemStatusNotAvailable()))
		{
			$this->_item->setLoanClass(ItemPeer::LOANCLASS_UNAVAILABLE);
			$this->LoanClass->setSelectedValue(ItemPeer::LOANCLASS_UNAVAILABLE);
		}
		else
		{
			$this->_item->setLoanClass($this->LoanClass->getSelectedValue());
		}
		
		$this->_item->setItemStatus($newItemStatus);

		$logDiscard = array();

		// never discarded before
		if (($newItemStatus == ItemStatus::ITEMSTATUS_DISCARDED)
				&& ($oldItemStatus != ItemStatus::ITEMSTATUS_DISCARDED))
			// if the new status is a discarded one and "not the previous one"
		{
			$discardtime = $this->DiscardDate->getTimeStamp();
			
			if (!$discardtime)
				$this->DiscardDate->setTimeStamp(time());
			
			$this->enqueueMessage(Prado::localize('Esemplare messo in stato di ') . LookupValuePeer::getLookupValue(	'ITEMSTATUS',
																														$newItemStatus),
										ClavisMessage::WARNING);
			
			$logDiscard = array(	$this->_item,
									ChangelogPeer::LOG_UPDATE,
									$this->getUser(),
									'Esemplare messo in stato di ' . LookupValuePeer::getLookupValue(	'ITEMSTATUS',
																										$newItemStatus));
		}
		elseif (($newItemStatus != ItemStatus::ITEMSTATUS_DISCARDED)
				&& ($oldItemStatus == ItemStatus::ITEMSTATUS_DISCARDED))
			// if the new status is not a discarded one and the previous one was
		{
			$oldDiscardDate = $this->_item->getDateDiscarded();
			$oldDiscardNote = $this->_item->getDiscardNote();
			$this->DiscardDate->setTimeStamp(null);
			$this->DiscardNote->setText('');
			$this->_item->setDateDiscarded(null);
			$this->_item->setDiscardNote(null);
			$this->enqueueMessage(Prado::localize('Data di scarto e provvedimento eliminati per cambio di stato.'),
									ClavisMessage::WARNING);
			
			$logDiscard = array(	$this->_item,
									ChangelogPeer::LOG_UPDATE,
									$this->getUser(),
									"Data di scarto e provvedimento eliminati per cambio di stato, valori precenti: data [{$oldDiscardDate}] provvedimento [{$oldDiscardNote}]");
		}

		if ($this->DiscardDate->getTimeStamp())
			$this->_item->setDateDiscarded($this->DiscardDate->getTimeStamp());
		
		$this->_item->setDiscardNote($this->DiscardNote->getText());
		$this->_item->setPhysicalStatus($this->PhysicalStatus->getSelectedValue());
		$this->_item->setItemMedia($this->ItemMedia->getSelectedValue());

		$invoiceId = intval($this->ItemInvoiceId->getValue());
		
		if ($invoiceId == 0)
			$invoiceId = null;
		
		$oldInvoiceId = $this->_item->getInvoiceId();
		$this->_item->setInvoiceId($invoiceId);
		
		$orderId = intval($this->ItemOrderId->getValue());
		
		if ($orderId == 0)
			$orderId = null;
		
		$oldOrderId = $this->_item->getOrderId();
		$this->_item->setOrderId($orderId);
		
		if (($oldInvoiceId != $invoiceId)
				|| ($oldOrderId != $orderId))
		{
			$order = PurchaseOrderQuery::create()->findPk($orderId);
			
			if ($order instanceof PurchaseOrder)
				$order->recalculateOrderStatus();
			
			if ($oldOrderId != $orderId)
			{
				$oldOrder = PurchaseOrderQuery::create()->findPk($oldOrderId);
				
				if ($oldOrder instanceof PurchaseOrder)
					$oldOrder->recalculateOrderStatus();
			}	
		}
		
		$this->_item->setCurrency($this->ItemCurrency->getSelectedValue());
		
		// the last param is for overriding culture (for transforming the decimal point to '.' and then applying US culture, for DB
		$itemCost = ClavisBase::numberFormat(	$this->ItemCost->getSafeText(),
												'#.00',
												null,
												false);
		
		$oldItemCost = $this->_item->getCurrencyValue();
		$this->_item->setCurrencyValue($itemCost);
		$this->ItemCost->setText(ClavisBase::numberFormat(	$itemCost,
															'#.00'));	// reformatting to video

		$itemDiscountRaw = $this->ItemDiscount->getSafeText();
		
		if ($itemDiscountRaw == "")
		{
			$this->_item->setDiscountValue(null);
			$itemDiscount = null;
		}
		else
		{
			$itemDiscount = ClavisBase::numberFormat(	$this->ItemDiscount->getSafeText(),
														'#.00',
														null,
														false);
			
			$oldItemDiscount = $this->_item->getDiscountValue();
			$this->_item->setDiscountValue($itemDiscount);
			$this->ItemDiscount->setText(ClavisBase::numberFormat(	$itemDiscount,
																	'#.00%'));	// reformatting to video
		}
		
		$itemValue = ClavisBase::numberFormat(	$this->ItemValue->getSafeText(),
												'#.00',
												null,
												false);
		
		$oldItemValue = $this->_item->getInventoryValue();

		// in editing, if itemCost or ItemDiscount (if not null)  gets modified
		// a re-calculation of new inventoryValue is necessary
		if ((!is_null($itemDiscount))
				&& ($itemValue == $oldItemValue) 
				&& (($itemCost != $oldItemCost) || ($itemDiscount != $oldItemDiscount)))
			$itemValue = $itemCost - ($itemCost * $itemDiscount / 100);
		
		$this->ItemValue->setText(ClavisBase::numberFormat(	$itemValue,
															'#.00'));	// reformatting to video
		
		$this->_item->setInventoryValue($itemValue);
		$this->_item->setItemSource($this->ItemSource->getSelectedValue());

		// physical data part
		$width = $this->ItemWidth->getSafeText();
		$this->_item->setWidth(is_null($width) || $width === "" ? null : intval($width));
		
		$height = $this->ItemHeight->getSafeText();
		$this->_item->setHeight(is_null($height) || $height === "" ? null : intval($height));
		
		$this->_item->setWeight(ClavisBase::numberFormat(	$this->ItemWeight->getSafeText(),
															'#.00',
															null,
															false));

		$this->_item->setVolumeNumber(intval($this->ItemVolumeNumber->getSafeText()));
		$this->_item->setVolumeText($this->ItemVolumeText->getSafeText());

		$this->_item->setLoanAlertNote($this->ItemAlertNote->getSafeText());
		$this->_item->setLoanAlert($this->ItemAlert->getSelectedValue());
		
		$consNote = ConsistencyNoteQuery::create()->findPk($this->ConsistencyList->getSelectedValue());
		$this->_item->setConsistencyNote($consNote);

		$issueInventoryNumber = $this->ItemIssueInvNumber->getSafeText();
		$this->_item->setIssueInventoryNumber(is_null($issueInventoryNumber) || $issueInventoryNumber === "" ? null : intval($issueInventoryNumber));
		
		$this->_item->setIssueArrivalDateExpected($this->ItemIssueArrivalDateExpected->getTimestamp());
		$this->_item->setIssueArrivalDate($this->ItemIssueArrivalDate->getTimestamp());
		
		//TODO: completare con gestione legami con abbonamenti
		$subcriptionId = $this->ItemSubscription->getSafeText();
		$this->_item->setSubscriptionId(is_null($subcriptionId) || $subcriptionId === "" ? null : intval($subcriptionId));
		
		$this->_item->setIssueStatus($this->ItemIssueStatus->getSelectedValue());

		if ($this->_isNew)
		{
			$this->_item->setHomeLibraryId($this->getUser()->getActualLibraryId());

			$newOwnerLibraryId = intval($this->NewOwnerLibraryId->getValue());
			
			if ($newOwnerLibraryId > 0)
			{
				$this->_item->setOwnerLibraryId($newOwnerLibraryId);
			}
			else
			{
				$this->_item->setOwnerLibraryId($this->getUser()->getActualLibraryId());
			}

			$newHomeLibraryId = intval($this->HomeLibraryHid->getValue());
			
			if ($newHomeLibraryId > 0)
			{
				$this->_item->setHomeLibraryId($newHomeLibraryId);
			}
			else
			{
				$this->_item->setHomeLibraryId($this->getUser()->getActualLibraryId());
			}

			$newActualLibraryId = intval($this->NewActualLibraryId->getValue());
			
			if ($newActualLibraryId > 0)
			{
				$this->_item->setActualLibraryId($newActualLibraryId);
			}
			else
			{
				$this->_item->setActualLibraryId($this->getUser()->getActualLibraryId());
			}

			$actualLibrary = $this->_item->getOwnerLibrary();
			
			if ($actualLibrary instanceof Library && $actualLibrary->isExternal())
				$this->_item->setLoanStatus(ItemPeer::LOANSTATUS_AVAILABLEEXTRA);
		}
		else
		{
			$newOwnerLibraryId = intval($this->NewOwnerLibraryId->getValue());
			
			if ($newOwnerLibraryId > 0)
			{
				$this->_item->setOwnerLibraryId($newOwnerLibraryId);
				$this->ChooseOwnerLibrary->setVisible($this->getOwnerLibraryChangeable($this->_item));
			}
		}

		$manif = $this->_item->getManifestation();
		
		if ($manif instanceof Manifestation) 
		{
			$newTitle = $manif->getTitle();
			$issue = $this->_item->getIssue();
		
			if ($issue instanceof Issue)
				$newTitle .= ' (fasc: ' . $issue->getIssueCombo(false) . ')';

			$this->_item->setTitle($newTitle);
			$this->_item->setManifestationDewey($manif->getClass());
		}

		$exit = false;
                
		if ($this->_item->getItemStatus() == ItemStatus::ITEMSTATUS_INORDER)	// if is in order
		{
			$this->_item->setInventoryNumber(intval($this->InventoryNumber->getSafeText()));
		} 
		else 
		{ // not "in order"
			if (!$this->manageInventory())	// returns false if duplicated (and not null)
			{
				///	$this->cleanMessageQueue();    does not seem very useful (mbrancalion)
				$this->enqueueMessage(Prado::localize('Numero di inventario duplicato. Inserire un valore diverso.'),
										ClavisMessage::ERROR);
				
				$this->InventoryNumber->setText(intval($this->InventoryNumber->getText()) . "<---");

				// what's it for ?..........
//				if ($this->getExtraMode())
//					$currSerie = trim($this->InventorySerieIdFree->getSafeText());
//				else
//					$currSerie = $this->InventorySerieId->getSelectedValue();
				
				$this->populateSerieSection();
				
				$exit = true;
			}
		}

		if ($exit)
		{
			$this->flushMessage();
			
			return false;
		}

				/*
		* Check for better inventory number use.
		* If a number exist for this issue, check that is
		* the same of the other for this issue.
		* If differ or more than one number is used,
		* warning message was showed
		*/                                
		$iNrs = $this->_item->getIssueExistingInventory(	$this->_item->getIssueId(),
															$this->_item->getHomeLibraryId(),
															$this->_item->getManifestationId());

		if ($iNrs instanceof PropelArrayCollection)
		{
			$ic = count($iNrs);

			//if more than one was found
			if ($ic > 1)
			{
				$msg = Prado::localize("Più inventari in uso nella stessa annata") . "(";

				foreach($iNrs as $iNr)
					$msg .= $iNr['item.inventory_number'] ."-";
	
				$msg .= ")";

				$this->enqueueMessage($msg,
										ClavisMessage::WARNING);
			}


		}	// inventory check and suggestion end
		
		$this->_item->setCustomField1($this->Custom1->getSafeText());
		$this->_item->setCustomField2($this->Custom2->getSafeText());
		$this->_item->setCustomField3($this->Custom3->getSafeText());
		
		if ($this->customs_type[0] == 'list')
			$this->_item->setCustomField1($this->CustomList1->getSelectedValue());
		
		if ($this->customs_type[1] == 'list')
			$this->_item->setCustomField2($this->CustomList2->getSelectedValue());
		
		if ($this->customs_type[2] == 'list')
			$this->_item->setCustomField3($this->CustomList3->getSelectedValue());
		
		// Out of catalog case
		if ($this->_item->isOoc())
		{
			$currentTitle = trim($this->_item->getTitle());
			$newTitle = trim($this->ItemTitle->getSafeText());
			
			if ($currentTitle != $newTitle)		// title has been significantly changed
			{
				$this->_item->setTitle($newTitle);
			
				if (!$this->getIsNew())		// only if item is already existing on DB
				{
					/**
					 * All existing loans related to this item
					 */
					$itemLoans = LoanQuery::create()
									->filterByItemId($this->_item->getItemId())
									->find();
					
					$counterLoanTitleModified = 0;
					$counterLoanTitleError = 0;
					foreach ($itemLoans as $loan)
					{
						try
						{
							$loan->setTitle($newTitle);
							$loan->save();
							$counterLoanTitleModified++;
						}
						catch (Exception $e)
						{
							$counterLoanTitleError++;
						}
					}
					
					if ($counterLoanTitleModified > 0)
						$this->enqueueMessage(Prado::localize("Modificato il titolo su {num} prestiti collegati all'esemplare (anche storici)", 
																	array('num' => $counterLoanTitleModified)), 
												ClavisMessage::CONFIRM);
					
					if ($counterLoanTitleError > 0)
						$this->enqueueMessage(Prado::localize("Errore su tentata modifica del titolo su {num} prestiti collegati all'esemplare (anche storici)", 
																	array('num' => $counterLoanTitleError)), 
												ClavisMessage::ERROR);
				}
			}
		}
		// end of Out of catalog case
		
		$ownerLibrary = $this->_item->getOwnerLibrary();
		
		if ($ownerLibrary instanceof Library)
			$skipLibraryChanges = ($ownerLibrary->isExternal() && $this->_item->isNew());
		
		$newHomeLibraryId =	$this->HomeLibraryHid->getValue();
		
		if ($this->getItemLibraryChangeable()
					&& ((int) $newHomeLibraryId != 0)
					&&	($newHomeLibraryId != $this->_item->getHomeLibraryId())
					&& !$skipLibraryChanges )
		{
			$returnCode = $this->_loanmanager->DoReassignItemToLibrary(	$this->HomeLibraryHid->getValue(), 
																		$this->_item, 
																		$this->getUser());
			switch ($returnCode) 
			{
				case ClavisLoanManager::ERROR:
					$this->enqueueMessage(Prado::localize('Impossibile modificare la biblioteca di gestione'),	/// mbrancalion, da analizzare
											ClavisMessage::ERROR);
					break;
			
				default:
					break;
			}
		}

		$supplierId = intval($this->ItemSupplierId->getValue());
		if ($supplierId == 0)
			$supplierId = null;
		$this->_item->setSupplierId($supplierId);
			
		// budget part (saveitem)
		$budgetId = intval($this->BudgetId->getValue());
		if ($budgetId == 0)
			$budgetId = null;
		$this->_item->setBudgetId($budgetId);
                
		try 
		{
			$this->_item->save();
			
			if ($manif instanceof Manifestation)
				$manif->doIndex();
		} 
		catch (Exception $e) 
		{
			throw $e;		/// mbrancalion, da analizzare se lanciare eccezione o catturare
		}

		if ($this->_isNew) 
		{
			ChangelogPeer::logAction(	$this->_item,
										ChangelogPeer::LOG_CREATE,
										$this->getUser(),
										'Creato nuovo esemplare ' . $this->_item->getItemId());
			
			$this->enqueueMessage(Prado::localize('Creato nuovo esemplare, con id: {itemId}', 
														array('itemId' => $this->_item->getItemId())),
									ClavisMessage::CONFIRM);
		} 
		else 
		{
			ChangelogPeer::logAction(	$this->_item,
										ChangelogPeer::LOG_UPDATE,
										$this->getUser(),
										'Aggiornamento dati esemplare ' . $this->_item->getItemId());
			
			$this->enqueueMessage(Prado::localize('Modificato esemplare con id: {itemId}', 
													array('itemId' => $this->_item->getItemId())), 
									ClavisMessage::CONFIRM);
		}
		
		if (count($logDiscard) == 4)
			ChangelogPeer::logAction(	$logDiscard[0],
										$logDiscard[1],
										$logDiscard[2],
										$logDiscard[3] );
		
		$this->flushMessage();
		
		return true;
	}

	protected function manageInventory() 
	{
		$newInventoryNumber = trim($this->InventoryNumber->getSafeText());

		if ($this->getExtraMode())
			$newInventorySerieId = trim($this->InventorySerieIdFree->getSafeText());
		else
			$newInventorySerieId = $this->InventorySerieId->getSelectedValue();
		
		// We want to be able to set a null value ("")
		if ($newInventoryNumber === "")
			$newInventoryNumber = null;
		else
			$newInventoryNumber = intval($newInventoryNumber);

		// duplicates check
		$duplicateExist = (!is_null($newInventoryNumber)
								&& !$this->_item->isInventoryNumberUnique(	$newInventoryNumber,
																			$newInventorySerieId));
		
		if ($duplicateExist)
		{
			$newInventoryNumber = null;
		}

		// if we don't need to modify the field: all is ok, nothing to do
		if ($this->_isNew
				|| ($this->_item->getInventoryNumber() !== $newInventoryNumber)
				|| ($this->_item->getInventorySerieId() !== $newInventorySerieId))
		{	

			$this->_item->setInventoryNumber($newInventoryNumber);
			$this->_item->setInventorySerieId($newInventorySerieId);

			if ($this->_isNew)
				$this->_item->setHomeLibraryId( $this->getUser()->getActualLibraryId());

			if (is_null($this->InventoryDate->getSafeText()))
				$this->_item->setInventoryDate(time());
			else
				$this->_item->setInventoryDate($this->InventoryDate->getTimeStamp());
		}
		
		return !$duplicateExist;
	}
	
	protected function onGetInventoryCounterCallback($sender, $param)
	{
		if ($this->getExtraMode())
			$inventorySerieId = trim($this->InventorySerieIdFree->getSafeText());
		else
			$inventorySerieId = $this->InventorySerieId->getSelectedValue();

		if ($this->getIsNew())
			$libraryId = $this->getUser()->getActualLibraryId();
		else
			$libraryId = $this->_item->getOwnerLibraryId();
		
		$invCounter = InventorySeriePeer::calculateNextInventoryCounter(	$inventorySerieId,
																			$libraryId);
		
		if ($invCounter != false)
		{
			$this->InventoryNumber->setText($invCounter);
		}
		else
		{
			$this->writeMessage(Prado::localize("Errore nell'assegnazione automatica del contatore di inventario"),
									ClavisMessage::ERROR);
		}
	}
	
	public function globalRefresh()
	{
		$this->SBNActions->populate();
	}

	public function globalCancel($component)
	{
	}

	public function isUnlink()
	{
		return true;
	}

	public function isPopup()
	{
		return false;
	}

	public function populate()
	{
		/* @var Item $this->_item */
		if (is_null($this->getItem()))
			return;

		$this->UpdateData->setObject($this->_item);
		if ($this->_item->isNew())
		{
			$this->OpacVisible->setEnabled(false);
		}
		else
		{
			$this->OpacVisible->setChecked($this->_item->getOpacVisible());
		}

		$loan_class = $this->_item->isNew()
							? ItemPeer::getLoanClassesAvailable(null, true)
							: $this->_item->getLoanClass();

		$this->LoanClass->setSelectedValue($loan_class[0]);
		
		$itemIcon = $this->_item->getItemIcon();
		if (!is_null($itemIcon))
			$this->ItemIcon->setSelectedValue($itemIcon);

		$this->Reprint->setText($this->_item->getReprint());

		//collocazione
		$this->Section->setSelectedValue($this->_item->getSection());
		$this->Collocation->setText($this->_item->getCollocation());
		$this->Sequence1->setText($this->_item->getSequence1());
		$this->Sequence2->setText($this->_item->getSequence2());
		$this->Specification->setText($this->_item->getSpecification());
		$this->Barcode->setText($this->_item->getBarcode());
		$this->Rfid->setText($this->_item->getRfidCode());
		$this->Mediapackage_size->setSelectedValue($this->_item->getMediapackageSize());

		//inventariazione
		/* moved into the onPreRender()
		 */
                    
		$inventorySerieId = $this->_item->getInventorySerieId();
		$libraryId = $this->_item->getOwnerLibraryId();

		if ($this->getExtraMode())
		{
			$this->InventorySerieIdFree->setText($inventorySerieId);
		}
		elseif (count($this->InventorySerieId->getDataSource()->toArray()))
		{
			if (!is_null((InventorySerieQuery::create()->findPK(array($inventorySerieId, $libraryId))))
					&& !$this->_isNew)
				$this->InventorySerieId->setSelectedValue($inventorySerieId);
			else
			    $this->InventorySerieId->setSelectedIndex(0);
		}

		$this->InventoryNumber->setText($this->_item->getInventoryNumber());
		$this->InventoryDate->setTimestamp($this->_isNew
												? time()
												: $this->_item->getInventoryDate('U'));

		$this->DiscardDate->setTimeStamp($this->_item->getDateDiscarded('U')
												? $this->_item->getDateDiscarded('U')
												: '');
		
		$this->DiscardNote->setText($this->_item->getDiscardNote());

		/* XXX FIXME tutti questi valori hardcoded di default vanno cambiati!!! */
		//stati
		if ($this->_isNew)
		{
			$itemMediaTypeValues = LookupValuePeer::getLookupClassValues('ITEMMEDIATYPE');
			if (isset($itemMediaTypeValues['F']))
				$this->ItemMedia->setSelectedValue('F');
		}
		else
		{
			$this->ItemMedia->setSelectedValue($this->_item->getItemMedia());
		}

		if ($this->_isNew) 
		{
			$itemStatusTypeValues = LookupValuePeer::getLookupClassValues('ITEMSTATUS');
			if (isset($itemStatusTypeValues[ItemStatus::ITEMSTATUS_ONSHELF]))
				$this->ItemStatus->setSelectedValue(ItemStatus::ITEMSTATUS_ONSHELF);
		} 
		else 
		{
			$this->ItemStatus->setSelectedValue($this->_item->getItemStatus());
		}

		$itemOrderStatus = $this->_item->getItemOrderStatus();
		if (!is_null($itemOrderStatus))
			$this->ItemOrderStatus->setSelectedValue($itemOrderStatus);
		
		$this->PhysicalStatus->setSelectedValue($this->_item->getPhysicalStatus());

		//valore
		$this->ItemCurrency->setSelectedValue($this->_item->getCurrency());

		// db -> video
		$this->ItemCost->setText(ClavisBase::numberFormat(	$this->_item->getCurrencyValue(),
															'#.00'));
		
		$itemDiscount = $this->_item->getDiscountValue();
		if (is_null($itemDiscount))
			$itemDiscount = "";
		else
			$itemDiscount = ClavisBase::numberFormat(	$this->_item->getDiscountValue(),
														'#.00%');
		
		$this->ItemDiscount->setText($itemDiscount);
		$this->ItemValue->setText(ClavisBase::numberFormat(	$this->_item->getInventoryValue(),
																'#.00'));

		if (!$this->_isNew)
			$this->ItemSource->setSelectedValue($this->_item->getItemSource());

		// invoice auth part
		$this->_invoiceClosedFlag = false;
		$this->PopupInvoiceLinkButton->setVisible(false);
		$this->InvoiceResetButton->setVisible(false);
		$invoice = $this->_item->getInvoice();
		if ($invoice instanceof Invoice) 
		{
			$this->ItemInvoice->setEnabled(true);
			$this->ItemInvoice->setNavigateUrl($this->getService()->constructUrl(	'Acquisition.InvoiceViewPage',
																					array('id' => $invoice->getInvoiceId())));
			
			$this->ItemInvoice->setText($invoice->getInvoiceCompleteLabel());
			$this->ItemInvoice->setVisible(true);
			$this->ItemInvoiceId->setValue($invoice->getInvoiceId());
			
			if ($invoice->getInvoiceStatus() == InvoicePeer::INVOICESTATUS_OPEN)
			{
				$this->PopupInvoiceLinkButton->setVisible(true);
				$this->InvoiceResetButton->setVisible(true);
			}
			else	// invoice is closed
			{
				$this->_invoiceClosedFlag = true;
			}
		} 
		else	// no invoice
		{
			$this->ItemInvoice->setEnabled(false);
			$this->ItemInvoice->setText(Prado::localize('nessuna fattura'));
			$this->ItemInvoiceId->setValue(0);
			$this->InvoiceResetButton->setVisible(false);
		}
		
		// order auth part
		$this->PopupOrderLinkButton->setVisible(false);
		$this->OrderResetButton->setVisible(false);
		$order = $this->_item->getPurchaseOrder();
		if ($order instanceof PurchaseOrder) 
		{
			$this->ItemOrder->setEnabled(true);
			$this->ItemOrder->setNavigateUrl($this->getService()->constructUrl(	'Acquisition.OrderViewPage',
																				array('id' => $order->getOrderId())));
			
			$this->ItemOrder->setText($order->getOrderId() . ' (' . $order->getOrderDate('Y/m/d') . ')');
			$this->ItemOrderId->setValue($order->getOrderId());

			if ($order->getOrderStatus() == PurchaseOrderPeer::STATUS_OPEN)
			{
				$this->PopupOrderLinkButton->setVisible(true);
				$this->OrderResetButton->setVisible(true);
			}
		} 
		else 
		{
			$this->ItemOrder->setEnabled(false);
			$this->ItemOrder->setText(Prado::localize('nessun ordine'));
			$this->ItemOrderId->setValue(0);
		}
        
		// supplier auth part
        $supplier = $this->_item->getSupplier();
		if ($supplier instanceof Supplier) 
		{
			$this->ItemSupplier->setEnabled(true);
			$this->ItemSupplier->setNavigateUrl($this->getService()->constructUrl(	'Acquisition.SupplierInsertPage',
																					array('supplierId' => $supplier->getSupplierId())));
			
			$this->ItemSupplier->setText($supplier->getSupplierName());
			$this->ItemSupplierId->setValue($supplier->getSupplierId());
			$this->SupplierResetButton->setVisible(true);
		} 
		else 
		{
			$this->ItemSupplier->setEnabled(false);
			$this->ItemSupplier->setText(Prado::localize('nessun fornitore'));
			$this->ItemSupplierId->setValue(0);
			$this->SupplierResetButton->setVisible(false);
		}

		// budget auth part
        $budget = $this->_item->getBudget();
		if ($budget instanceof Budget) 
		{
			$this->BudgetLink->setEnabled(true);
			$this->BudgetLink->setNavigateUrl($this->getService()->constructUrl(	'Acquisition.BudgetViewPage',
																					array('id' => $budget->getBudgetId())));
			
			$this->BudgetLink->setText($budget->getCompleteBudgetTitle());
			$this->BudgetId->setValue($budget->getBudgetId());
			$this->BudgetResetButton->setVisible(true);
		} 
		else 
		{
			$this->BudgetLink->setEnabled(false);
			$this->BudgetLink->setText(Prado::localize('nessun budget'));
			$this->BudgetId->setValue(0);
			$this->BudgetResetButton->setVisible(false);
		}

		// item physical data
		$this->ItemWidth->setText($this->_item->getWidth());
		$this->ItemHeight->setText($this->_item->getHeight());
		$this->ItemWeight->setText(ClavisBase::numberFormat(	$this->_item->getWeight(),
																'#.00'));

		$this->ItemVolumeNumber->setText($this->_item->getVolumeNumber());
		$this->ItemVolumeText->setText($this->_item->getVolumeText());

		$nonExistingLibrary = Prado::localize("dato mancante");
		
		if ($this->_isNew) 
		{
			$actualLibrary = $this->getUser()->getActualLibrary();
			$ownerLibrary = $actualLibrary;
			$homeLibrary = $actualLibrary;
			$prevHomeLibrary = null;
		} 
		else 
		{
			$ownerLibrary = $this->_item->getOwnerLibrary();
			$homeLibrary = $this->_item->getHomeLibrary();
			$prevHomeLibrary = $this->_item->getPrevHomeLibrary();
			$actualLibrary = $this->_item->getActualLibrary();			
		}

		if ($ownerLibrary instanceof Library)
		{
			$this->OwnerLibrary->setText($ownerLibrary->getLabel(true, true));
			//$this->OwnerLibrary->setEnabled(true);
		}
		else
		{
			$this->OwnerLibrary->setText($nonExistingLibrary);
			//$this->OwnerLibrary->setEnabled(false);
		}

		if ($homeLibrary instanceof Library)
		{
			///$homeLibraryLabel = $homeLibrary->getLabel(true, true);
			$homeLibraryLabel = $this->_item->getHomeLibraryLabel(true, true);
			//$this->HomeLibrary->setEnabled(true);
			
			$this->HomeLibrary->setText($homeLibraryLabel);
		}
		else
		{
			$this->HomeLibrary->setText($nonExistingLibrary);
			//$this->HomeLibrary->setEnabled(false);
		}

		if ($actualLibrary instanceof Library)
		{
			$this->ActualLibrary->setText($actualLibrary->getLabel(true, true));
			//$this->ActualLibrary->setEnabled(true);
		}
		else
		{
			$this->ActualLibrary->setText($nonExistingLibrary);
			//$this->ActualLibrary->setEnabled(false);
		}
		
		$this->ItemAlertNote->setText($this->_item->getLoanAlertNote());
		$this->ItemAlert->setSelectedValue($this->_item->getLoanAlert());

		$ic = -1;

		/*
		* Check for better inventory number use.
		* If a number exist for this issue, check that is
		* the same of the other for this issue.
		* If differ or more than one number is used,
		* warning message was showed
		*/
		$iNrs = $this->_item->getIssueExistingInventory(	$this->_item->getIssueId(),
															$this->_item->getHomeLibraryId(),
															$this->_item->getManifestationId());

		if ($iNrs instanceof PropelArrayCollection)
		{
			$ic = count($iNrs);
		} // inventory check and suggestion end
		
		if ($this->_isNew) 
		{

			/*
			 * if only one serial found for issue populate field
			 */

			if ($ic == 1)
			{
				$this->InventorySerieId->setSelectedValue($iNrs[0]['item.inventory_serie_id']);
				$this->InventoryNumber->Text = $iNrs[0]['item.inventory_number'];
			}
		} 
		else 
		{
			$cds = $this->ConsistencyList->getDataSource();
			if (!is_null($cds)
					&& array_key_exists($this->_item->getConsistencyNoteId(), $cds->toArray()))
				$this->ConsistencyList->setSelectedValue($this->_item->getConsistencyNoteId());
			else
			    $this->ConsistencyList->setSelectedIndex(0);
			
			$this->ItemIssueId->setValue($this->_item->getIssueId());
			$this->ItemIssue->setText($this->_item->getIssueNumber());
			$this->ItemIssueInvNumber->setText($this->_item->getIssueInventoryNumber());
			$this->ItemIssueArrivalDateExpected->setTimestamp($this->_item->getIssueArrivalDateExpected('U'));
			$this->ItemIssueArrivalDate->setTimestamp($this->_item->getIssueArrivalDate('U'));
			$this->ItemSubscription->setText($this->_item->getSubscriptionId()); //TODO: completare con gestione legami con abbonamenti
			$this->ItemIssueStatus->setSelectedValue($this->_item->getIssueStatus());
		}
                
		if( $ic > 1)
        {
			$msg = Prado::localize("Più inventari in uso nella stessa annata") . "(";
			foreach($iNrs as $iNr)
				$msg .= $iNr['item.inventory_number'] ."-";
			$msg .= ")";

			$this->getPage()->writeMessage($msg,
											ClavisMessage::WARNING);

		}

		$this->Custom1->setText($this->_item->getCustomField1());
		$this->Custom2->setText($this->_item->getCustomField2());
		$this->Custom3->setText($this->_item->getCustomField3());
		
		if ($this->customs_type[0] == 'list')
			$this->CustomList1->setSelectedValue($this->_item->getCustomField1());
		
		if ($this->customs_type[1] == 'list')
			$this->CustomList2->setSelectedValue($this->_item->getCustomField2());
		
		if ($this->customs_type[2] == 'list')
			$this->CustomList3->setSelectedValue($this->_item->getCustomField3());
	}

	protected function getItemHomeLibraryId()
	{
		$this->getItem();

		if (!is_null($this->_item))
			return $this->_item->getHomeLibraryId();
		else
			return 0;
	}

	public function getOwnerLibraryChangeable($item = null)
	{
		if (is_null($item))
			$item = $this->getItem();

		if ($item instanceof Item)
			return TPropertyValue::ensureBoolean(in_array(	$item->getOwnerLibraryId(),
															$this->getUser()->getLibraryIds()));
		else
			return false;
	}
	
	public function getItemLibraryChangeable()
	{
		if ($this->getIsNew()
			 && ((intval($this->getItem()->getManifestationId()) > 0)
					|| ($this->ExternalAlertPanel->getCssClass() == 'panel_on_inline')) )	// if we have an external OOC
		{
			return false;
		}
		else	// normal case
		{	
			return $this->_loanmanager->IsItemReassignable(	$this->getItem(),
															$this->getUser());
		}
	}

	public function validateBarcode($sender,$param)
	{
		$candidateBarcode = $param->getValue();
		$isDuplicate = !ItemPeer::checkBarcodeUnique(	$candidateBarcode,
														$this->getItem());
		
		if ($isDuplicate) 
		{
			$param->IsValid = false;
			$this->getPage()->writeMessage(Prado::localize("Il barcode '{barcode}' è già in uso nel sistema",
																array('barcode' => $candidateBarcode)),
												ClavisMessage::ERROR);
		} 
		else 
		{
			$param->IsValid = true;
		}
	}

	/**
	 * Exits the editing of an item, without doing anything.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onCancel($sender, $param)
	{
		$item = $this->getItem();
		if ($item instanceof Item)
			$itemId = $item->getItemId();
		else
			$itemId = 0;

		if (!$this->getIsNew()
				&& ($itemId > 0))
			$this->gotoPage(	"Catalog.ItemViewPage",
								array("id" => $itemId));
		else
		{
			$manifestationId = intval($item->getManifestationId());
			if ($manifestationId > 0)
				$this->gotoPage(	'Catalog.Record',
									array('manifestationId' => $manifestationId));
			else
				$this->gotoPage("Catalog.RecordList");
		}
	}

	public function onNewLink($sender,$param)
	{
		$this->getItem();
		$linkAuthID = intval($this->AuthorityID->getValue());

		if (AuthorityQuery::create()->findPK($linkAuthID) instanceof Authority)
		{
			$link = new LAuthorityItem();
			$link->setItem($this->_item);
			$link->setAuthorityId($linkAuthID);
			$link->setRelatorCode($this->RelatorCode->getSelectedValue());
			// hardcoded linktype for items
			$link->setLinkType(702);
			$link->setLinkNote($this->LinkNote->getText());

			try
			{
				$link->save();
				ChangelogPeer::logAction(	$this->_item,
											ChangelogPeer::LOG_CREATE,
											$this->getUser(),
											'Creato nuovo legame fra esemplare (id = ' . $this->_item->getItemId()
													. ', titolo = '.$this->_item->getTrimmedTitle(80, '') . ') e authority (id = '.$linkAuthID.')');

				$this->getPage()->writeMessage(Prado::localize("Creato legame fra l'esemplare con id: {itemId} e l'authority con id: {authId}",
																	array(	'itemId' => $this->_item->getItemId(),
																			'authId' => $linkAuthID)),
													ClavisMessage::CONFIRM);

				$this->cleanItem();
				$this->AuthorityLink->populate();
			}
			catch (PropelException $exception)
			{
				$errorMessage = $exception->getCause()->getMessage();
				$dbClass = Propel::getDB();
				if ($dbClass instanceof DBMySQL)
				{
					$duplicateCase = strstr($errorMessage, 'Duplicate entry');
					if ($duplicateCase != false)
					{
						$this->getPage()->writeMessage(Prado::localize("Errore nella creazione del legame fra l'esemplare con id: {itemId} e l'authority con id: {authId}: esiste gia'.",
																			array(	'itemId' => $this->_item->getItemId(),
																					'authId' => $linkAuthID)),
															ClavisMessage::ERROR);
					}
					else
					{
						throw ($exception);
					}
				}
				else
				{
					throw ($exception);
				}
			}
		}
		else
		{
			$this->getPage()->writeMessage(Prado::localize("L'authority con id: {id} non esiste",
																array('id' => $linkAuthID)),
												ClavisMessage::ERROR);
		}
		$this->LinkNote->setText('');
		$this->AuthorityID->setValue('');
		$this->NewAuthLink->setText('');
		$this->AuthorityLink->populate();
	}

	public function cleanItem()
	{
		$this->_item = null;
		$this->getItem();
	}

	public function authLinkCancel($sender,$param) 
	{
		$this->AuthorityLink->EditItemIndex=-1;
		$this->bindAuthGrid();
	}

	public function onSuggestAuthority($sender, $param)
	{
		$prefix = $param->getToken();

		$this->NewAuthOnTheFly->setParam(urlencode($prefix));

		$authList = AuthorityPeer::doSuggest($prefix,10);
		$authData = array();
		/* @var $auth Authority */
		foreach($authList as $auth)
			$authData[] = array('id' => $auth->getAuthorityId(),
								'text' => $auth->getFullTextSpec() );
		
		$sender->setDataSource($authData);
		$sender->dataBind();
	}

	public function onSuggestSelectAuthority($sender, $param) 
	{
		$ok = false;
		$authority = null;
		
		$authorityId = $sender->Suggestions->DataKeys[$param->selectedIndex];
		$a = AuthorityQuery::create()->findPK($authorityId);
		if ($a instanceof Authority)
			$authority = $a->getAcceptedAuthority();
		
		if ($authority instanceof Authority)
		{
			// the str_replace is needed for authorities can have &lt; instead of <,
			// in sort_text.
			$sender->setText(trim(str_replace(	'&lt;',
												'<',
												$authority->getFullText())));
			
			$this->AuthorityID->setValue($authority->getAuthorityId());
			$ok = true;
		} 
		
		if (!$ok)
		{
			$sender->setText('');
			$this->AuthorityID->setValue(null);
		}
	}

	public function eraseAuthorityLink($keys)
	{
		$goOn = true;

		if (!is_array($keys) 
				|| (count($keys) == 0))
		{
			$this->getPage()->writeMessage(Prado::localize("Errore nel passaggio dei parametri durante la cancellazione di un legame esemplare-authority.<br />Riportare al fornitore del software, grazie"),
												ClavisMessage::ERROR);
			$goOn = false;
		}
		list(	$authorityId,
				$itemId,
				$linkType,
				$relatorCode ) = $keys;
		
		$link = LAuthorityItemQuery::create()->findPK(array(	$authorityId, 
																$itemId, 
																$linkType, 
																$relatorCode ));
		
		if (!($link instanceof LAuthorityItem))
		{
			$this->getPage()->writeMessage(Prado::localize("Errore nel recupero del legame fra esemplare e authority, nel tentativo di cancellarlo.<br />Riportare al fornitore del software, grazie"),
												ClavisMessage::ERROR);
			$goOn = false;
		}

		if ($goOn)
		{
			try
			{
				$link->delete();
				$this->getPage()->writeMessage(Prado::localize("Cancellato legame fra l'esemplare con id: {itemId} e l'authority con id: {authId}",
																	array(	'itemId' => $itemId,
																			'authId' => $authorityId )),
												ClavisMessage::CONFIRM);
			}
			catch (Exception $e)
			{
				$e = $e;	// for avoiding Netbeans IDE's stupid warning
				$this->getPage()->writeMessage(Prado::localize("Errore: non è riuscita la cancellazione del legame fra l'esemplare con id: {itemId} e l'authority con id: {authId}",
																	array(	'itemId' => $itemId,
																			'authId' => $authorityId )),
												ClavisMessage::ERROR);
			}
		}
		
		$this->AuthorityLink->populate();  // update lista
	}

	public function onCheckNewOwnerLibrary($sender, $param)
	{
		$newOwnerLibraryId = intval($this->NewOwnerLibraryId->getValue());
		if ($newOwnerLibraryId > 0)
		{
			$newOwnerLibrary = LibraryQuery::create()->findPK(intval($newOwnerLibraryId));
			if ($newOwnerLibrary instanceof Library)
			{
				if ($newOwnerLibrary->isExternal())
				{
					$this->ExternalAlertPanel->setCssClass('panel_on_inline');
					$this->NewActualLibraryId->setValue($newOwnerLibraryId);
					$this->ActualLibrary->setText($newOwnerLibrary->getLabel(true, true));
					$this->HomeLibraryHid->setValue($newOwnerLibraryId);
					$this->HomeLibrary->setText($newOwnerLibrary->getLabel(true, true));
					$this->ChooseActualLibrary->setVisible(false);
					
					$this->drawInventorySerieIdPanel(true, $param);
				}
				else
				{
					$this->ExternalAlertPanel->setCssClass('panel_off');
					$this->ChooseActualLibrary->setVisible(true);
					$this->populateSerieSection();

					$this->drawInventorySerieIdPanel(false, $param);
				}
			}
			
			$this->InventoryNumber->setText("");
		}
	}

	private function drawInventorySerieIdPanel($val = false, $param = null)
	{
		$this->setExtraMode($val);

		if ($this->getIsCallback())
		{
			if (is_null($param))
				$writer = $this->createWriter();
			else
				$writer = $param->getNewWriter();

			$this->InventorySerieIdPanel->render($writer);
		}
	}
        
	public function onInvoiceChanged($sender, $param)
 	{
		$invoice = InvoiceQuery::create()->findPK(intval($this->ItemInvoiceId->getValue()));
 		if ($invoice instanceof Invoice)
 		{
 			$this->ItemInvoice->setText($invoice->getInvoiceCompleteLabel());
			$this->ItemInvoice->setNavigateUrl($this->getService()->constructUrl(	'Acquisition.InvoiceViewPage',
																					array('id' => $invoice->getInvoiceId())));
			$this->ItemInvoice->setEnabled(true);
 			$this->setInvoiceChoiceDone(true, $param);
			$this->_invoiceClosedFlag = ($invoice->getInvoiceStatus() != InvoicePeer::INVOICESTATUS_OPEN);
			$this->setPurchaseEditEnabledStatus();
 		}
		else
		{
			$this->doResetInvoice($param);
		}
 	}

	public function onResetInvoice($sender, $param)
	{
		$this->doResetInvoice($param);
	}

	private function doResetInvoice($param = null)
	{
		$this->ItemInvoice->setText(Prado::localize('nessuna fattura'));
		$this->ItemInvoice->setNavigateUrl('');
		$this->ItemInvoiceId->setValue('');
		$this->setInvoiceChoiceDone(false, $param);
	}
	
 	public function setInvoiceChoiceDone($flag, $param = null)
 	{
		$this->InvoiceResetButton->setVisible($flag);

		if ($this->getIsCallback())
			$this->renderInvoicePanel($param);
 	}
	
	public function renderInvoicePanel($param = null)
	{
		if (is_null($param))
			$writer = $this->createWriter();
		else
			$writer = $param->getNewWriter();

		$this->InvoicePanel->render($writer);
	}
	
	public function onOrderChanged($sender, $param)
 	{
 		$order = null;
 		$id = intval($this->ItemOrderId->getValue());
 		if ($id > 0)
 			$order = PurchaseOrderQuery::create()->findPK($id);
 		if ($order instanceof PurchaseOrder)
 		{
			$this->ItemOrder->setText($order->getOrderId().' ('.$order->getOrderDate('Y/m/d').')');
			$this->ItemOrder->setNavigateUrl($this->getService()->constructUrl(	'Acquisition.OrderViewPage',
																				array('id' => $order->getOrderId())));
			
			$this->ItemOrder->setEnabled(true);
 			$this->setOrderChoiceDone(true, $param);
 		}
		else
		{
			$this->doResetOrder($param);
		}
 	}

	public function onResetOrder($sender, $param)
	{
		$this->doResetOrder($param);
	}

	private function doResetOrder($param = null)
	{
		$this->ItemOrder->setText(Prado::localize('nessun ordine'));
		$this->ItemOrder->setNavigateUrl('');
		$this->ItemOrderId->setValue('');
		$this->setOrderChoiceDone(false, $param);
	}
	
 	public function setOrderChoiceDone($flag, $param = null)
 	{
		$this->OrderResetButton->setVisible($flag);

		if ($this->getIsCallback())
			$this->renderOrderPanel($param);
 	}
	
	public function renderOrderPanel($param = null)
	{
		if (is_null($param))
			$writer = $this->createWriter();
		else
			$writer = $param->getNewWriter();

		$this->OrderPanel->render($writer);
	}
			
	public function onSupplierChanged($sender, $param)
 	{
 		$supplier = null;
 		$id = intval($this->ItemSupplierId->getValue());
 		if ($id > 0)
 			$supplier = SupplierQuery::create()->findPK($id);
 		if ($supplier instanceof Supplier)
		{
			$discount = $supplier->getDiscount();
		
			if (!is_null($discount))
				$this->calculateItemValueServerSide($discount);
				
 			$this->ItemSupplier->setText($supplier->getSupplierName());
			$this->ItemSupplier->setNavigateUrl($this->getService()->constructUrl(	'Acquisition.SupplierInsertPage',
																					array('supplierId' => $supplier->getSupplierId())));
			$this->ItemSupplier->setText($supplier->getSupplierName());
			$this->ItemSupplier->setEnabled(true);
			
 			$this->setSupplierChoiceDone(true, $param);
 		}
		else
		{
			$this->doResetSupplier($param);
		}
 	}

	public function calculateItemValueServerSide($itemDiscount)
	{
		$itemCost = ClavisBase::numberFormat(	$this->ItemCost->getSafeText(),
												'#.00',
												null,
												false);
		
		$itemValue = sprintf(	"%01.2f",
								floatval($itemCost) - (floatval($itemCost) * floatval($itemDiscount) / 100));

		$this->ItemValue->setText(ClavisBase::numberFormat(	$itemValue,
																'#.00'));
		
		$this->ItemDiscount->setText(ClavisBase::numberFormat(	$itemDiscount,
																'#.00%'));
	}
		
	public function onResetSupplier($sender, $param)
	{
		$this->doResetSupplier($param);
	}

	private function doResetSupplier($param = null)
	{
		$this->ItemSupplier->setText(Prado::localize('nessun fornitore'));
		$this->ItemSupplier->setNavigateUrl('');
		$this->ItemSupplierId->setValue('');
		$this->setSupplierChoiceDone(false, $param);
	}
	
 	public function setSupplierChoiceDone($flag, $param = null)
 	{
		$this->SupplierResetButton->setVisible($flag);

		if ($this->getIsCallback())
			$this->renderSupplierPanel($param);
 	}

	public function renderSupplierPanel($param = null)
	{
		if (is_null($param))
			$writer = $this->createWriter();
		else
			$writer = $param->getNewWriter();

		$this->SupplierPanel->render($writer);
	}
	
	public function onBudgetChanged($sender, $param)
 	{
 		$budget = null;
 		$id = intval($this->BudgetId->getValue());
 		if ($id > 0)
 			$budget = BudgetQuery::create()->findPK($id);
 		if ($budget instanceof Budget)
 		{
			$this->BudgetLink->setText($budget->getCompleteBudgetTitle());
			$this->BudgetLink->setNavigateUrl($this->getService()->constructUrl(	'Acquisition.BudgetViewPage',
																					array('id' => $budget->getBudgetId())));
			
			$this->BudgetLink->setEnabled(true);
			$this->setBudgetChoiceDone(true, $param);
 		}
		else
		{
			$this->doResetBudget($param);
		}
 	}

	public function onResetBudget($sender, $param)
	{
		$this->doResetBudget($param);
	}

	private function doResetBudget($param = null)
	{
		$this->BudgetLink->setText(Prado::localize('nessun budget'));
		$this->BudgetLink->setNavigateUrl('');
		$this->BudgetId->setValue('');
		$this->setBudgetChoiceDone(false, $param);
	}
	
 	public function setBudgetChoiceDone($flag, $param = null)
 	{
		$this->BudgetResetButton->setVisible($flag);

		if ($this->getIsCallback())
			$this->renderBudgetPanel($param);
 	}
	
	public function renderBudgetPanel($param = null)
	{
		if (is_null($param))
			$writer = $this->createWriter();
		else
			$writer = $param->getNewWriter();

		$this->BudgetPanel->render($writer);
	}
	
	public function onCheckItemCost($sender, $param)
	{
		$param->isValid = true;
		
		$itemCost = ClavisBase::numberFormat($this->ItemCost->getSafeText(), '#.00', null, false);
		if ($itemCost < 0.00)
		{
			$this->ItemCostValidator->setErrorMessage('<br />' . Prado::localize('il prezzo dev\'essere maggiore di 0'));
			
			$param->isValid = false;
			return $param->isValid;
		}
		
		$budget = BudgetQuery::create()->findPk(intval($this->BudgetId->getValue()));
		if ($budget instanceof Budget)
		{
			$invoicedCombo = $budget->getInvoicedCombo();
		
			if (array_key_exists("RestAllocated", $invoicedCombo))
			{
				$restAllocated = $invoicedCombo["RestAllocated"];

				$item = $this->getItem();
				if ($item instanceof Item)
				{
					$oldInventoryValue = $item->getInventoryValue();
					$newInventoryValue = ClavisBase::numberFormat(	$this->ItemValue->getSafeText(),
																	'#.00',
																	null,
																	false);

					if (($restAllocated + $oldInventoryValue - $newInventoryValue) < 0)
					{
						$param->isValid = false;
						$this->ItemCostValidator->setErrorMessage('<br />' . Prado::localize("Attenzione: budget ('{budgetTitle}', id: {budgetId}) insufficiente",
																								array(	'budgetTitle' => $budget->getCompleteBudgetTitle(),
																										'budgetId' => $budget->getBudgetId())));
					}
				}
			}		
		}
	}
	
}
