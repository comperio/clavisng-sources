<?php
/**
 * AuthorityReplace class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 ePortal Technologies
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Pages.Catalog
 */

/**
 * AuthorityReplace Class
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Pages.Catalog
 * @since 2.3
 */
class AuthorityReplace extends ClavisPage {

	public $_module = 'CATALOG';
	private $_toReplace;
	private $_uniqueId;
	/** @var ClavisSBN */
	private $_sbnMod;

	public $_activeClusterQuery;

	public function onLoad($param)
	{
		parent::onLoad($param);
		$this->_sbnMod = $this->getApplication()->getModule('sbn');
		$this->_uniqueId = $this->getUniqueID();

		if (!$this->getIsPostBack() && !$this->getIsCallback()) {
			$this->resetToReplace();
			if ($authId = $this->getRequest()->itemAt('target')) {
				$a = AuthorityPeer::retrieveByPK($authId);
				if ($a instanceof Authority) {
					$this->MainAuthority->authority = $a;
					$this->MainAuthority->setAuthorityId($authId);
					$this->MainAuthority->populate();
				}
			}
			$this->populate();
		}
	}

	public function setToReplace() {
		$this->getApplication()->getSession()->add('ToReplace'.$this->_uniqueId, $this->_toReplace);
	}
	public function resetToReplace() {
		$this->getApplication()->getSession()->remove('ToReplace'.$this->_uniqueId);
	}
	public function getToReplace() {
		if (!$this->_toReplace)
			$this->_toReplace = $this->getApplication()->getSession()->itemAt('ToReplace'.$this->_uniqueId);
		if (!is_array($this->_toReplace))
			$this->_toReplace = array();
		return $this->_toReplace;
	}

	public function populate($param=null)
	{
		$targetAuthority = $this->MainAuthority->authority;
		$targetSubject = ($targetAuthority instanceof Authority &&
			$targetAuthority->getAuthorityType() == AuthorityPeer::TYPE_SUBJECT);

		$this->getToReplace();
		$authids = array_flip($this->_toReplace);
		$ds = array();
		$authorities = AuthorityQuery::create()->findByAuthorityId($this->_toReplace);
		foreach ($authorities as $a) {
			/* @var $a Authority */
			$p['AuthorityId'] = $a->getAuthorityId();
			$authType = $a->getAuthorityType();
                        /*
			if (AuthorityPeer::TYPE_WORK == $authType) {	// works are not allowed, unset from replace array and continue
				unset($authids[$p['AuthorityId']]);
				continue;
			}
                         *
                         */
			if (($targetSubject && AuthorityPeer::TYPE_SUBJECT != $authType) ||
					(!$targetSubject && AuthorityPeer::TYPE_SUBJECT == $authType)) {
				unset($authids[$p['AuthorityId']]);
				continue;
			}
			if (AuthorityPeer::TYPE_CLASS == $authType)
				$p['TypeSpec'] = LookupValuePeer::getLookupValue('CLASSTYPE', $a->getSubjectClass());
			else if (AuthorityPeer::TYPE_SUBJECT == $authType)
				$p['TypeSpec'] = LookupValuePeer::getLookupValue('SUBJECTTYPE', $a->getSubjectClass());
			else
				$p['TypeSpec'] = '';
			$p['AuthorityId'] = $a->getAuthorityId();
			$p['AuthorityType'] = $a->getAuthorityTypeLabel();
			$p['FullText'] = htmlentities($a->getFullText(), ENT_COMPAT, 'UTF-8');
			$p['Notes'] = '';
			foreach ($a->getNotes() as $n)
				$p['Notes'] .= '<em>'.LookupValuePeer::getLookupValue('UNI3XXAUTH',$n['NoteNumber'])
					.':</em> '.htmlentities(strip_tags($n['NoteValue'])).'<br />';
			$p['AuthorityRecType'] = LookupValuePeer::getLookupValue('AUTHRECTYPE',$a->getAuthorityRectype());
			$p['AuthorityLink'] = '';
			$viewBaseLink = $this->getService()->constructUrl(
				$this->getPage()->isPopup()?'Catalog.AuthorityListPopup':'Catalog.AuthorityList',
				array('search'=>''));
			$linkList = $a->getAuthoritiesLinkList(true,true);
			foreach ($linkList as $linkLabel => $links) {
				$p['AuthorityLink'] .= "<p class=\"authoritylinklisthdr\">{$linkLabel}</p>".
					'<ul class="authoritylinklist">';
				foreach ($links as $id => $term)
					$p['AuthorityLink'] .= "<li><a href=\"{$viewBaseLink}{$term['FullText']}".
						'" title="'.Prado::localize('Cerca questa authority')."\">{$term['FullText']}</a></li>";
				$p['AuthorityLink'] .= '</ul>';
			}
			$p['ManifestationLinkCount'] = $a->countLAuthorityManifestations();
			$ds[] = $p;
		}
		$this->ResultGrid->setDataSource($ds);
		$this->ResultGrid->dataBind();
		$this->ToReplaceCount->Parameters->count = count($ds);
		$this->_toReplace = array_flip($authids);
		$this->setToReplace();

		if ($this->getPage()->getIsCallback())
		{
			if (!is_null($param))
				$writer = $param->getNewWriter();
			else
				$writer = $this->getPage()->createWriter();

			if (!is_null($writer))
				$this->ToReplaceCountPanel->render($writer);
		}
	}

	public function onChooseAuthority($sender, $param)
	{
		$authority = AuthorityQuery::create()->findPk($this->AuthorityResultValue->getValue());
		if ($authority instanceof Authority) {
                        /*
			if ($authority->getAuthorityType() == AuthorityPeer::TYPE_WORK) {
				$this->writeMessage(Prado::localize('Al momento non è possibile lo schiacciamento di Opere'), ClavisMessage::ERROR);
				$this->MainAuthority->authority = null;
				$this->MainAuthority->setAuthorityId(null);
				$this->MainAuthorityLink->setVisible(false);
				return;
			}*/
			$this->MainAuthority->authority = $authority;
			$this->MainAuthority->setAuthorityId($authority->getAuthorityId());
			$this->MainAuthority->populate();
			$this->MainAuthorityLink->setNavigateUrl(
				$this->getService()->constructUrl('Catalog.AuthorityViewPage',
					array('id'=>$authority->getAuthorityId())));
			$this->MainAuthorityLink->setVisible(true);
		} else {
			$this->writeMessage(Prado::localize('Selezione non valida'), ClavisMessage::ERROR);
			$this->MainAuthority->authority = null;
			$this->MainAuthority->setAuthorityId(null);
			$this->MainAuthorityLink->setVisible(false);
		}
		$this->populate($param);
	}

	public function onVariantize($sender, $param)
	{
		$this->replace(true);
		$this->populate($param);
	}
	public function onReplace($sender, $param)
	{
		$this->replace(false);
		$this->populate($param);
	}

	private function replace($variantize=false) {
		set_time_limit(0);

		$successNumber = $failNumber = 0;
		$okString = $failedString = '';

		$currentLibrarian = $this->getUser();
		$targetAuthority = $this->MainAuthority->authority;

		if (! $targetAuthority instanceof Authority) {
			$this->getPage()->writeMessage(Prado::localize('Non è stata scelta alcuna authority su cui schiacciare'),
				ClavisMessage::ERROR);
			return false;
		}
		$sourceAuthorityIds = $this->getToReplace();
		$totalNumber = count($sourceAuthorityIds);

		if ($sbnEnabled = $this->_sbnMod->getEnabled()) {
			$targetBid = $targetAuthority->getBidSource() == 'SBN'
				? $targetAuthority->getBid() : null;
		}

		foreach ($sourceAuthorityIds as $sourceAuthorityId) {
			$sourceAuthority = AuthorityQuery::create()->findPk($sourceAuthorityId);
			if ($sourceAuthority instanceof Authority) {
				if ($sbnEnabled && $sourceAuthority->getBidSource() == 'SBN' && !$targetBid) {
					// refuse to replace SBN authority with a non-SBN one
					$rowString = Prado::localize('<br />[{id}] è legato a SBN, impossibile schiacciare ({text})',
						array('id' => $sourceAuthorityId,
							'text' => $sourceAuthority->getFullText()));
					$result = false;
				} else if ($sbnEnabled && $sourceAuthority->getBidSource() == 'SBN' && $targetBid) {
					if ($variantize) {
						$tm = $sourceAuthority->getTurboMarc();
						$l = $tm->getLeader();
						$l->type = AuthorityPeer::RECTYPE_VARIANT;
						$tm->setLeader($l);
						$sbnMarc = SBNConverter::Turbomarc2SBN($tm);
						$type = SBNConverter::ClavisType2SBNType($sourceAuthority->getAuthorityType());
						if (!isset($tm->d099->sb))
							$tm->d099->addSubField('d',SBNConverter::ClavisType2SBNType($type));
						if (AuthorityPeer::TYPE_CLASS == $type) {
							// 'D'+cod_edizione+simbolo per il sistema Dewey e cod_sistema+simbolo per altri sistemi
							if (isset($tm->d676)) {
								$bid = 'D'.$tm->d676->sv.$tm->d676->sa;
							} else if (isset($tm->d686)) {
								$bid = $tm->d686->s2.$tm->d686->sa;
							}
						}
						$l = $sbnMarc->addChild('LegamiElementoAut')->addChild('ArrivoLegame')
							->addChild('LegameElementoAut');
						$l->addAttribute('tipoAuthority',SBNConverter::ClavisType2SBNType($targetAuthority->getAuthorityType()));
						$l->addAttribute('tipoLegame','4XX');
						$l->addChild('idArrivo',$targetAuthority->getBid());
						$node = $this->_sbnMod->getNodePrefix();
						$node .= SBNConverter::ClavisType2SBNIdPrefix($type);
						$cntparam = ClavisParamQuery::create()->filterByParamClass('SBNCOUNTER')->filterByParamName($node)->findOneOrCreate();
						$counter = intval($cntparam->getParamValue()) + 1;
						$sourceBid = $node.str_pad($counter,10-strlen($node),0,STR_PAD_LEFT);
						$req = $this->_sbnMod->getNewRequest();
						$req->create(SBNTypes::CREATECONTROL_CONFIRM, SBNTypes::OBJCLASS_AUT,$sbnMarc, $sourceBid);
					} else {
						$sourceBid = $sourceAuthority->getBid();
					}
					$req = $this->_sbnMod->getNewRequest();
					$sbn_response = $req->merge($sourceBid, $targetBid,SBNTypes::OBJCLASS_AUT, SBNTypes::OBJCLASS_AUT);
					switch ($sbn_response->SbnMessage->SbnResponse->SbnResult->esito) {
						case '0000':	// correctly merged
							$rowString = Prado::localize('<br />[{id}] correttamente fuso in SBN ({text})',
								array('id' => $sourceAuthorityId,
									'text' => $sourceAuthority->getFullText()));
							$result = $sourceAuthority->replaceWith($targetAuthority, $currentLibrarian);
							break;
						default:
							$rowString = Prado::localize('<br />[{id}] errore SBN: {sbnErrorMessage}, impossibile schiacciare ({text})',
								array('id' => $sourceAuthorityId,
									'sbnErrorMessage' => (string)$sbn_response->SbnMessage->SbnResponse->SbnResult->testoEsito,
									'text' => $sourceAuthority->getFullText()));
							$result = false;
					}
				} else {
					$result = ($variantize) ?
						$sourceAuthority->variantizeWith($targetAuthority, $currentLibrarian) :
						$sourceAuthority->replaceWith($targetAuthority, $currentLibrarian) ;
					$rowString = Prado::localize('<br />[{id}] ({text})',
						array('id' => $sourceAuthorityId,
							'text' => $sourceAuthority->getFullText()));
					if ($result !== false)
						$successNumber++;
					else
						$failNumber++;
				}
				if ($result) {
					$successNumber++;
					$okString .= $rowString;
				} else {
					$failNumber++;
					$failedString .= $rowString;
				}
			}
		}

		$targetAuthority->save();

		if ($successNumber > 0)
			$this->getPage()->writeMessage($successNumber == 1 ?
					Prado::localize('1 elemento processato su {total}: <br/>{message}',array('total'=>$totalNumber, 'message' => $okString)) :
					Prado::localize('{count} elementi processati su {total}',
						array('count' => $successNumber, 'total' => $totalNumber, 'message' => $okString)),
				ClavisMessage::INFO);

		if ($failNumber > 0)
			$this->writeMessage($failNumber == 1 ?
					Prado::localize('1 elemento NON processato su {total}: <br/>{message}',
						array('total'=>$totalNumber, 'message' => $failedString)) :
					Prado::localize('{count} elementi NON processati su {total}: <br/>{message}',
							array('count' => $successNumber, 'total' => $totalNumber, 'message' => $failedString)),
				ClavisMessage::ERROR);

		if ($successNumber == 0 && $failNumber == 0)
			$this->writeMessage(Prado::localize('Nessun elemento processato'),ClavisMessage::WARNING);
	}

	public function onMultiAuthoritySelect($sender, $param) {
		$val = $this->SelectedAuthority->getValue();
		$this->getToReplace();
		if ($val == 'multi')
			$this->_toReplace = array_merge($this->_toReplace,unserialize($this->SelectedId->getValue()));
		else
			$this->_toReplace[] = intval($this->SelectedId->getValue());
		$this->setToReplace();
		$this->populate($param);
	}

	public function onItemRemove($sender, $param) {
		$this->getToReplace();
		$id = $this->ResultGrid->DataKeys[$param->getItem()->getItemIndex()];
		$k = array_search($id,$this->_toReplace);
		if ($k !== false)
			unset($this->_toReplace[$k]);
		$this->setToReplace();
		$this->populate();
	}

	public function  onClusterSearch($sender, $param) {
        /** @var SolrSearch $solr */
        $solr = $this->getApplication()->getModule("search");

        $authtypes = join(" OR ", $this->TypeFilter->getSelectedValues());
        $rectype = $this->AuthRecType->getSelectedValue();
        $cluster_finger = $this->SortKeyFilter->getSelectedValue();
        $wordfilter = trim($this->WordFilter->getText());


        $query=[];
        $params = ["facet"=>"true","facet.field"=>$cluster_finger,"facet.mincount"=>2 ];
        $query[] = "fldis_str_auth_type: ({$authtypes})";
        if($wordfilter != "")
            $query[] = "fulltext: ($wordfilter) ";
        if($rectype != "0")
            $query[] = "facets_authrectype: {$rectype}";

        $this->_activeClusterQuery = implode(" AND ", $query) . " AND {$cluster_finger}: ";

        $result = $solr->searchAuthority(	implode(" AND ", $query),
													0,
													0,
													"",
													$params);

        $clusters = $result['facet_counts']['facet_fields'][ $cluster_finger];

        $clusterData = [];
        foreach($clusters as $key => $count) {
            $clusterData[] = [
              "key" => $key,
              "count"=> $count,
            ];
        }
        $this->ClusterDataList->setDataSource($clusterData);
        $this->ClusterDataList->dataBind();
        $this->setControlState("clustdata",$clusterData);
    }

}