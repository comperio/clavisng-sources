<?php
/**
 * AuthorityViewPage file.
 *
 * This file contains all the required classes for SBN dialogue v4.
 * Based upon SBNConnector by Comperio srl.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Ciro Mattia Gonano
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.8.6
 * @package Pages.Catalog
 */

/**
 * AuthorityViewPage Class
 *
 * @author Ciro Mattia Gonano
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.8.6
 * @package Pages.Catalog
 * @since 2.0
 */
class AuthorityViewPage extends ClavisPage
{
	public $_module = 'CATALOG';

	/* @var Authority */
	public $authority = null;
	
	public function onInit($param)
	{
		parent::onInit($param);

		if (!$this->getIsPostBack() 
				&& !$this->getIsCallback())
		{
			$id = intval($this->getRequest()->itemAt('id'));
			$a = AuthorityQuery::create()->findPk($id);
			
			if (!$a instanceof Authority)
			{
				$this->writeMessage(Prado::localize("L'authority con ID {id} non esiste",
														array('id' => $id)),
										ClavisMessage::ERROR);
				
				$this->gotoPage('Catalog.AuthorityList');
			}
			
			$this->setAuthorityId($id);
			$this->AuthViewer->setAuthorityId($id);
			$this->UpdateData->setObject($a);
			
			$canEdit = $this->getApplication()->getUser()->getEditPermission($a)
							&& ($a->getAuthorityCodlevel() <= $this->getUser()->getLibrarian()->getCatLevel());
			
			$canDelete = $a->isDeleteable();
			$this->EditButton->setEnabled($canEdit);
			$this->DeleteButton->setEnabled($canDelete);
		}
	}

	public function onLoad($param)
	{
		parent::onLoad($param);
		
		if ($this->getUser()->getIsAdmin())
		{
			$authority = $this->getAuthority();
			
			if ($authority instanceof Authority)
			{	
				$this->TotalEraseButton->setVisible(true);

				$messageText = Prado::localize("Rimozione totale dell'authority con id={id}, titolo '{title}'. Verrà cancellato ogni legame a notizie({lManifestationCount}), esemplari ({lItemCount}), authority ({lAuthoritiesCount}), soggetti ({lSubjectCount}).",
													array(	'id' => $authority->getAuthorityId(),
															'title' => $authority->getCompleteText(),
															'lManifestationCount' => $authority->countLAuthorityManifestations(),
															'lItemCount' => $authority->countLAuthorityItems(),
															'lAuthoritiesCount' => $authority->countLAuthoritysRelatedByAuthorityIdUp() + $authority->countLAuthoritysRelatedByAuthorityIdDown(),
															'lSubjectCount' => $authority->countLSubjectsRelatedByAuthorityId()	));

				$this->TotalEraseButton->setParam($messageText);
			}
			else
			{
				$this->TotalEraseButton->setVisible(false);
			}
		}
		else
		{
			$this->TotalEraseButton->setVisible(false);
		}

		$myUser = $this->getUser();
		
		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallback())
		{	
			$shelvesDatasource = array();
			$shelfList = ShelfPeer::getVisibleShelves(	$myUser,
														ShelfPeer::TYPE_AUTHORITY );
			
			foreach ($shelfList as $shelf)
			{
				if ($shelf->isEditable($this->getUser()))
					$shelvesDatasource[$shelf->getShelfId()] = "({$shelf->getShelfId()}) " . substr(strip_tags($shelf->getShelfName()), 0, 20);
			}

			$this->ToShelf->setDataSource($shelvesDatasource);
			$this->ToShelf->dataBind();

			$actualShelfId = $myUser->getActualShelfId();
			
			if (!is_null($actualShelfId))
			{
				try
				{
					$this->ToShelf->setSelectedValue($actualShelfId);
				}
				catch (Exception $e)
				{
					Prado::log("Lo scaffale preferito con id=$actualShelfId non esiste");
					$myUser->setActualShelfId(null);
				}
			}
		}
	}

	public function setAuthorityId($value)
	{
		$this->setViewState('AuthId', intval($value), null);
	}

	public function getAuthorityId()
	{
		return $this->getViewState('AuthId', null);
	}

	public function getAuthority()
	{
		$authority = null;
		$authorityId = (int) $this->getAuthorityId();
				
		if ($authorityId > 0)
			$authority = AuthorityQuery::create()->findPk($authorityId);
		
		return $authority;
	}
	
	public function onModify($sender, $param)
	{
		$this->gotoPage('Catalog.AuthorityEditPage', array('id' => $this->getAuthorityId()));
	}

	public function onDelete($sender, $param)
	{
		$this->getPage()->cleanMessageQueue();
		
		try
		{
			$authorityId = intval($this->getAuthorityId());
			$authority = $this->getAuthority();
			
			if ($authority instanceof Authority)
			{	
				$authorityTitle = $authority->getFullText();
				
				$authority->delete();

				ChangelogPeer::logAction(	'Authority', 
											ChangelogPeer::LOG_DELETE, 
											$this->getUser(),
											'Cancellata authority con id = ' . $authorityId,
											$authorityId);

				$this->getPage()->enqueueMessage(Prado::localize("L'authority '[{id}] {title}' è stata eliminata",
																	array(	'id' => $authorityId, 
																			'title' => $authorityTitle )),
													ClavisMessage::CONFIRM);

				$gotoElement = ClavisBase::delEditObjectStack(	ClavisBase::EDITOBJECTSSTACK_TYPEAUTHORITY,
																$authorityId);

				if (ClavisBase::isValidElementObjectStack($gotoElement))
				{
					$this->getPage()->enqueueMessage(Prado::localize("É stato rimosso un oggetto dalla coda di catalogazione"),
														ClavisMessage::INFO);
					
					if ($gotoElement[0] == ClavisBase::EDITOBJECTSSTACK_TYPEMANIFESTATION)
					{
						$this->getPage()->flushDelayedMessage();
						
						$this->gotoPage(	'Catalog.EditRecord', 
											array(	'manifestationId' => $gotoElement[1],
													'selectTab' => 'TabAuthority' ));
					}
					elseif ($gotoElement[0] == ClavisBase::EDITOBJECTSSTACK_TYPEAUTHORITY)
					{
						$this->getPage()->flushDelayedMessage();
						
						$this->gotoPage(	'Catalog.AuthorityEditPage', 
											array(	'id' => $gotoElement[1],
													'selectTab' => 'TabAuthLink' ));
					}

				}
				elseif ((count($gotoElement) == 3)
							&& (is_null($gotoElement[0])))
				{
					$this->getPage()->enqueueMessage(Prado::localize("É stato rimossa la coda di catalogazione"),
														ClavisMessage::INFO);
					
					$this->getPage()->flushDelayedMessage();
					
					$this->gotoPage('Catalog.AuthorityList');
				}
				else
				{
					$this->getPage()->flushDelayedMessage();
					
					$this->gotoPage('Catalog.AuthorityList');
				}
			}
			else
			{
				$this->getPage()->writeMessage(Prado::localize("L'authority non è stata eliminata perchè l'id: {id} non esiste",
																	array('id' => $authorityId)),
												ClavisMessage::ERROR);

				return false;
			}
		} 
		catch (Exception $e) 
		{
			$this->writeMessage(Prado::localize("Impossibile eliminare l'authority"), 
									ClavisMessage::ERROR);
		}
	}

	public function onAddToShelf($sender, $param)
	{
		$shelfId = $this->ToShelf->getSelectedValue();
		$this->getUser()->setActualShelfId(intval($shelfId));
		$this->doAddToShelf($shelfId);
	}	

	private function doAddToShelf($shelfId)
	{
		$shelf = null;
		$result = false;

		if ($shelfId > 0)
			$shelf = ShelfQuery::create()->findPK($shelfId);

		if (!($shelf instanceof Shelf))
		{
			$this->writeMessage(Prado::localize("Lo scaffale con id={id} non esiste",
													array('id' => $shelfId)),
									ClavisMessage::ERROR);
			
			return false;
		}
					
		$authorityId = (int) $this->getAuthorityId();

		if ($authorityId == 0)
		{
			$this->writeMessage(Prado::localize("Errore interno nel passaggio del parametro di id dell'authority"),
									ClavisMessage::ERROR);
			
			return false;
		}
			
		$result = $shelf->addItemToShelf(shelfpeer::TYPE_AUTHORITY, $authorityId);

		if ($result)
		{
			//$this->getPage()->globalRefresh();
			$this->AuthViewer->populate();
			
			$this->writeMessage(Prado::localize("Authority aggiunta allo scaffale '{shelfname}' con id={shelfid}",
													array(	'shelfname' => $shelf->getShelfName(),
															'shelfid' => $shelf->getShelfId() )),
									ClavisMessage::CONFIRM);
		}
		else
		{
			$this->writeMessage(Prado::localize("Notizia non aggiunta allo scaffale '{shelfname}' con id={shelfid}",
													array(	'shelfname' => $shelf->getShelfName(),
															'shelfid' => $shelf->getShelfId() )),				
									ClavisMessage::ERROR);
		}
	}					
					
	public function onTotalErase($sender, $param)
	{
		$captchaSuccess = $this->CaptchaSuccessFlag->getValue();
		
		if ($captchaSuccess != 1)
		{
			$this->writeMessage(Prado::localize('Errore di autenticazione col captcha'),
									ClavisMessage::ERROR);
			
			return false;
		}

		$authority = $this->getAuthority();
		
		if (($authority instanceof Authority))   // for super-sureness super-sayan
		{
			$authorityId = $authority->getAuthorityId();
			
			try
			{
				$connection = Propel::getConnection();
				$connection->beginTransaction();
		
				$this->cleanMessageQueue();
				
				/**
				 * links to manifestations
				 */
				try
				{
					$lAuthorityManifestationCount = $authority->countLAuthorityManifestations();
					$authority->getLAuthorityManifestations()->delete();
					
					$this->enqueueMessage(Prado::localize("N.{num} legami con notizie rimossi",
																array('num' => $lAuthorityManifestationCount)),
												ClavisMessage::CONFIRM);
					
					ChangelogPeer::logAction(	$authority, 
												ChangelogPeer::LOG_DELETE, 
												$this->getUser(), 
												"Cancellazione forzosa di $lAuthorityManifestationCount notizie collegate all'authority");
				}
				catch (PropelException $e_lAuthorityManifestation)
				{
					$lAuthorityManifestationCount = 0;
				}
				
				/**
				 * links to items
				 */
				try
				{
					$lAuthorityItemCount = $authority->countLAuthorityItems();
					$authority->getLAuthorityItems()->delete();
					
					$this->enqueueMessage(Prado::localize("N.{num} legami con esemplari rimossi",
																array('num' => $lAuthorityItemCount)),
												ClavisMessage::CONFIRM);
					
					ChangelogPeer::logAction(	$authority, 
												ChangelogPeer::LOG_DELETE, 
												$this->getUser(), 
												"Cancellazione forzosa di $lAuthorityItemCount esemplari collegati all'authority");
				}
				catch (PropelException $e_lAuthorityItem)
				{
					$lAuthorityItemCount = 0;
				}
				
				/**
				 * links to authorities
				 */
				try
				{
					$lAuthorityCount = $authority->countLAuthoritysRelatedByAuthorityIdUp() + $authority->countLAuthoritysRelatedByAuthorityIdDown();
					$authority->getLAuthoritysRelatedByAuthorityIdUp()->delete();
					$authority->getLAuthoritysRelatedByAuthorityIdDown()->delete();
					
					$this->enqueueMessage(Prado::localize("N.{num} legami con authority rimossi",
																array('num' => $lAuthorityCount)),
												ClavisMessage::CONFIRM);
					
					ChangelogPeer::logAction(	$authority, 
												ChangelogPeer::LOG_DELETE, 
												$this->getUser(), 
												"Cancellazione forzosa di $lAuthorityCount authority collegate al questa authority");
				}
				catch (PropelException $e_lAuthority)
				{
					$lAuthorityCount = 0;
				}
				
				/**
				 * subjects related to items
				 */
				try
				{
					$lSubjectCount = $authority->countLSubjectsRelatedByAuthorityId();
					$authority->getLSubjectsRelatedByAuthorityId()->delete();
					
					$this->enqueueMessage(Prado::localize("N.{num} soggetti (legati all'authority) rimossi",
																array('num' => $lSubjectCount)),
												ClavisMessage::CONFIRM);
					
					ChangelogPeer::logAction(	$authority, 
												ChangelogPeer::LOG_DELETE, 
												$this->getUser(), 
												"Cancellazione forzosa di $lSubjectCount soggetti che hanno come argomento questa authority");
				}
				catch (PropelException $e_lSubject)
				{
					$lSubjectCount = 0;
				}

				try
				{
					$authority->delete();

					$this->enqueueMessage(Prado::localize("Rimossa authority con id={id}, titolo '{title}'",
													array(	'id' => $authority->getAuthorityId(),
															'title' => $authority->getCompleteText() ),
												ClavisMessage::CONFIRM));
									
					ChangelogPeer::logAction(	'Authority', 
												ChangelogPeer::LOG_DELETE, 
												$this->getUser(),
												'Cancellata authority con id = ' . $authorityId,
												$authorityId);
				}
				catch (PropelException $e_authority)
				{

				}

				$connection->commit();
				
				$this->flushDelayedMessage();
				$this->gotoPage('Catalog.AuthorityList');
			}
			catch (Exception $e)
			{
				$connection->rollBack();
				
				$this->writeMessage(Prado::localize("Errore durante la cancellazione dell'authority, con messaggio '{msg}'",
															array('msg' => $e->getMessage())),
										ClavisMessage::ERROR);
			}
		}	// end of an existing authority here
		else
		{
			$this->writeMessage(Prado::localize("Errore interno sul passaggio parametro dell'authority. Segnalare al fornitore del software."),
									ClavisMessage::ERROR);
		}
	}

	public function globalRefresh()
	{
		$this->AuthViewer->globalRefresh();
	}
	
}