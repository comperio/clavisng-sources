<?php
/**
 * ItemNotePopup class file.
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 ePortal Technologies
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Popups.Catalog
 */

/**
 * ItemNotePopup Class
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.7
 * @package Popups.Catalog
 * @since 2.3
 */
class ItemNotePopup extends ClavisPagePopup
{
	public $_module = 'CATALOG';

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallBack()) {
			$valid = true;
			$itemValid = true;
			$new = false;

			$itemId = intval($this->getRequest()->itemAt('itemId'));
			if ($itemId > 0) {
				$item = ItemPeer::retrieveByPK($itemId);
				if (is_null($item))
					$itemValid = false;
			}

			if (!$itemValid) {
				$this->writeMessage(Prado::localize("L'esemplare con id = {id} non esiste. Errore di ClavisNG nel passaggio dei parametri: avvisare il Centro Servizi", array('id' => $itemId)), ClavisMessage::ERROR);
				return false;
			}
			else {
				$this->setItemId($itemId);
			}

			$id = intval($this->getRequest()->itemAt('itemNoteId'));
			if ($id > 0) {
				$itemNote = ItemNotePeer::retrieveByPK($id);
				if (is_null($itemNote))
					$valid = false;
			}
			else {
				$new = true;
			}

			if (!$valid) {
				$this->writeMessage(Prado::localize("La nota sull'esemplare con id [{id}] non esiste.", array('id' => $id)), ClavisMessage::ERROR);
				return false;
			}

			if ($new) {
				$newItemNote = new ItemNote;
				$newItemNote->setItemId($this->getItemId());
				$newItemNote->save();
				$id = $newItemNote->getNoteId();
			}

			$this->setItemNoteId($id);
			$this->globalRefresh();
		}
	}

	public function setItemNoteId($id = null)
	{
		$id = intval($id);
		$this->setViewState("ItemNoteId", $id, 0);
	}

	public function getItemNoteId()
	{
		return intval($this->getViewState("ItemNoteId", 0));
	}

	public function setItemId($id = null)
	{
		$id = intval($id);
		$this->setViewState("ItemId", $id, 0);
	}

	public function getItemId()
	{
		return intval($this->getViewState("ItemId", 0));
	}

	public function globalRefresh()
	{
		$this->populate();
	}


	public function populate()
	{
		$itemNoteId = $this->getItemNoteId();
		$itemNote = ItemNotePeer::retrieveByPK($itemNoteId);
		if ($itemNote instanceof ItemNote) {
			$item = $itemNote->getItem();
			if (!$item instanceof Item) {
				$this->writeMessage(Prado::localize("L'esemplare collegato alla nota [{noteId}] non esiste.", array('noteId' => $itemNoteId)), ClavisMessage::ERROR);
				return false;
			}
			$this->ItemTitle->setText($item->getTrimmedTitle(60));
			$this->NoteType->setSelectedValue($itemNote->getNoteType());
			$this->NoteLabel->setText($itemNote->getNote());
		}
	}

	public function isUnlink()
	{
		return false;
	}

	public function onSave($sender, $param)
	{
		$noteContent = $this->NoteLabel->getSafeText();
		$noteType = $this->NoteType->getSelectedValue();

		$itemNoteId = $this->getItemNoteId();
		if ($itemNoteId > 0)
			$itemNote = ItemNotePeer::retrieveByPK($itemNoteId);
		if (!($itemNote instanceof ItemNote)) {
			$this->writeMessage(Prado::localize("La nota sull'esemplare non esiste. Errore di ClavisNG nel passaggio dei parametri: avvisare il Centro Servizi"), ClavisMessage::ERROR);
			return false;
		}

		$itemNote->setNote($noteContent);
		$itemNote->setNoteType($noteType);
		$itemNote->save();

		$this->getPage()->writeDelayedMessage(Prado::localize("Salvata nota con id: {noteId} sull'esemplare con id: {itemId}", array('noteId' => $itemNote->getNoteId(), 'itemId' => $itemNote->getItemId())), ClavisMessage::CONFIRM);

		$this->getApplication()->getSession()->add('UpdateItemNotes', true);
		$scriptMgr = $this->getPage()->getClientScript();
		$scriptMgr->registerEndScript('submit', 'parent.onSubmit();');
		$scriptMgr->registerEndScript('popupClose', 'onClose();');
	}
	
}
