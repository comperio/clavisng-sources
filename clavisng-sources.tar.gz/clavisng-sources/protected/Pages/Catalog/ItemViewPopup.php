<?php

/**
 * ItemViewPopup class
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2009-2011 Comperio srl
 * @version 2.7
 * @package Popups.Catalog
 * @since 2.5.0
 */

class ItemViewPopup extends ClavisPagePopup
{
	public $_module = 'CATALOG';

	public function onInit($param)
	{
		parent::onInit($param);
		if (!$this->getIsPostBack() && !$this->getIsCallback()) {
			$i = ItemQuery::create()->findPk($this->getRequest()->itemAt('param'));
			if ($i instanceof Item)
				$this->ItemView->setItem($i);
		}
	}

	public function globalRefresh()
	{
		$this->populate();
	}

	public function isUnlink()
	{
		return false;
	}


	public function populate()
	{
		$this->ItemView->populate();
	}
	
}