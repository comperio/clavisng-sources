<?php

/**
 * RecordListPopup class
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @copyright Copyright &copy; 2011 Comperio srl
 * @version 2.7
 * @package Popups.Catalog
 * @since 2.0
 */

class RecordListPopup extends ClavisPagePopup
{
	public $_module = 'CATALOG';

	public function onInit($param) {
		parent::onInit($param);

		$search = $this->getRequest()->itemAt('search');
		if ($search)
			$this->RecordList->setSearch($search);
		if ($this->getRequest()->itemAt('param') == 'multiSelect') {
			$this->MultiSelectPanel->setVisible(true);
			$this->RecordList->setMultiSelect(true);
		} else {
			$this->MultiSelectPanel->setVisible(false);
			$this->RecordList->setMultiSelect(false);
		}
	}

	public function onCancel($sender, $param) {
	}

	public function globalRefresh() {
		$this->RecordList->populate();
	}

	public function isUnlink() {
		return false;
	}

	public function onMultiSelect($sender, $param) {
		$idlist = $this->RecordList->getCheckedIds();
		$ret = ($idlist) ? serialize($idlist) : null;
		$this->getPage()->getClientScript()->registerEndScript(__CLASS__.'_js','onReturn(\'multi\',\''.$ret.'\',true);');
	}
	
}
