<?php
/**
 * RecordReplace class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 ePortal Technologies
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Pages.Catalog
 */

/**
 * RecordReplace Class
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Pages.Catalog
 * @since 2.3
 */
class RecordReplace extends ClavisPage {

	public $_module = 'CATALOG';
	private $_toReplace;
	private $_uniqueId;
	/** @var ClavisSBN */
	private $_sbnMod;

	public function onLoad($param) {
		parent::onLoad($param);

		$this->_sbnMod = $this->getApplication()->getModule('sbn');
		$this->_uniqueId = $this->getUniqueID();

		if (!$this->getIsPostBack() && !$this->getIsCallback()) {
			$this->resetToReplace();
			$m = ManifestationPeer::retrieveByPK($this->getRequest()->itemAt('target'));
			if ($m instanceof Manifestation) {
				$this->RecordChooser->setManifestation($m);
				$this->RecordChooser->ManifestationView->update($m->getManifestationId());
			}
			$this->populate();
		}
	}

	public function setToReplace() {
		$this->getApplication()->getSession()->add('ToReplace'.$this->_uniqueId, $this->_toReplace);
	}
	public function resetToReplace() {
		$this->getApplication()->getSession()->remove('ToReplace'.$this->_uniqueId);
	}
	public function getToReplace() {
		if (!$this->_toReplace)
			$this->_toReplace = $this->getApplication()->getSession()->itemAt('ToReplace'.$this->_uniqueId);
		if (!is_array($this->_toReplace))
			$this->_toReplace = array();
		return $this->_toReplace;
	}

	public function populate($param=null) {
		$this->getToReplace();
		$ds = array();
		/* preload lookups for biblevel */
		$lookup_bl = LookupValuePeer::getLookupClassValues('LIVBIBL');

		$records = ManifestationQuery::create()->findByManifestationId($this->_toReplace);
		foreach ($records as $m) {
			/* @var $m Manifestation */
			$tm = $m->getTurboMarc();
			$result['ManifestationId'] = $m->getManifestationId();
			$result['BibLevelCode'] = $m->getBibLevel();
			$result['BibLevelLabel'] = (array_key_exists($result['BibLevelCode'], $lookup_bl)) ?
				$lookup_bl[$result['BibLevelCode']] : '---';
			$result['BibTypeCode'] = strtolower($m->getBibType());
			$result['BibTypeLabel'] = $m->getBibTypeLabel();
			if (($year = $m->getEditionDate()) === 0)
				$year = '';
			$result['Year'] = $year;
			$result['Publisher'] = $m->getPublisher();
			$result['Title'] = trim($tm->getFullTitle());
			$result['Author'] = $tm->getAuthor();
			$result['EAN'] = $tm->getEAN();
			$result['Editions'] = implode(' - ',$tm->getEditions());
			$result['Publications'] = implode(' - ',$tm->getPublications());
			$result['Series'] = implode(' - ',$tm->getSeries());
			$itemStats = $this->getApplication()->getModule('loan')->extractItemStats($m);
			$result['Items'] = $itemStats['Items'];
			$result['ItemsDetail'] = $itemStats['ItemsDetail'];
			$result['AvailItems'] = $itemStats['AvailItems'];
			$result['AvailDetail'] = $itemStats['AvailDetail'];
			$result['MyCollocation'] = $itemStats['MyColl'];
			$ds[] = $result;
		}
		$this->ResultGrid->setDataSource($ds);
		$this->ResultGrid->dataBind();
		$this->ToReplaceCount->Parameters->count = count($ds);

		if ($this->getPage()->getIsCallback())
		{
			if (!is_null($param))
				$writer = $param->getNewWriter();
			else
				$writer = $this->getPage()->createWriter();

			if (!is_null($writer))
				$this->ToReplaceCountPanel->render($writer);
		}
	}

	public function onReplace($sender, $param)
	{
		$okCount = $failedCount = 0;
		$okString = $failedString = '';
		$currentLibrarian = $this->getUser();

		/* @var $targetManifestation Manifestation */
		$targetManifestation = $this->RecordChooser->getManifestation();
		if ($targetManifestation instanceof Manifestation) {
			$targetManifestationId = $targetManifestation->getManifestationId();
		}
		$sourceManifestationIds = $this->getToReplace();

		if ($sbnEnabled = $this->_sbnMod->getEnabled()) {
			$targetBid = $targetManifestation->getBidSource() == 'SBN'
				? $targetManifestation->getBid() : null;
			$sbnType = SBNConverter::ClavisType2SBNType($targetManifestation->getBibType());
		}
		foreach ($sourceManifestationIds as $sourceManifestationId) {
			$sourceManifestationId = intval($sourceManifestationId);
			if ($sourceManifestationId > 0) {
				if ($sourceManifestationId == $targetManifestationId)
					continue;    //  schiacciamento su se stesso

				$sourceManifestation = ManifestationQuery::create()->findPk($sourceManifestationId);
				if ($sourceManifestation instanceof Manifestation) {
					if ($sbnEnabled && $sourceManifestation->getBidSource() == 'SBN' && !$targetBid) {
						// refuse to replace SBN manifestation with a non-SBN one
						$rowString = Prado::localize('<br />[{id}] è legato a SBN, impossibile schiacciare ({title})',
							array('id' => $sourceManifestationId,
								'title' => $sourceManifestation->getTrimmedTitle(40, '/')));
						$result = false;
					} else if ($sbnEnabled && $sourceManifestation->getBidSource() == 'SBN' && $targetBid) {
						$req = $this->_sbnMod->getNewRequest();
						$sbn_response = $req->merge($sourceManifestation->getBid(), $targetBid,SBNTypes::OBJCLASS_DOC, $sbnType);
						switch ($sbn_response->SbnMessage->SbnResponse->SbnResult->esito) {
							case '0000':	// correctly merged
								$rowString = Prado::localize('<br />[{id}] correttamente fuso in SBN ({title})',
									array('id' => $sourceManifestationId,
										'title' => $sourceManifestation->getTrimmedTitle(40, '/')));
								$result = $sourceManifestation->replaceWith($targetManifestation, $currentLibrarian);
								break;
							default:
								$rowString = Prado::localize('<br />[{id}] errore SBN: {sbnErrorMessage}, impossibile schiacciare ({title})',
									array('id' => $sourceManifestationId,
										'sbnMessage' => (string)$sbn_response->SbnMessage->SbnResponse->SbnResult->testoEsito,
										'title' => $sourceManifestation->getTrimmedTitle(40, '/')));
								$result = false;
						}
					} else {
						$rowString = Prado::localize('<br />[{id}] ({title})',
							array('id' => $sourceManifestationId,
								'title' => $sourceManifestation->getTrimmedTitle(40, '/')));
						$result = $sourceManifestation->replaceWith($targetManifestation, $currentLibrarian);
					}
					if ($result) {
						// deindex manifestation
						$okCount++;
						$okString .= $rowString;
					} else {
						$failedCount++;
						$failedString .= $rowString;
					}
				}
			}
		}

		$targetManifestation->doIndex();
		if ($okCount == 0 && $failedCount == 0)
			$errorCode = ClavisMessage::INFO;
		else if ($failedCount > 0)
			$errorCode = ClavisMessage::WARNING;
		else
			$errorCode = ClavisMessage::CONFIRM;
		$messageText = '';

		if ($okCount > 0) {
			$this->resetToReplace();
			$messageText .= $okCount . ' ' . ($okCount == 1 ? Prado::localize('notizia schiacciata') : Prado::localize('notizie schiacciate'));
		}

		if ($failedCount > 0)
			$messageText .= ($okCount > 0 ? ' / ' : '') . $failedCount . ' ' .
				($failedCount == 1 ? Prado::localize('notizia NON schiacciata') :
					Prado::localize('notizie NON schiacciate'));

		if (($okString != '') || ($failedString != ''))
		{
			$messageText .= '&nbsp;&nbsp;&nbsp;&nbsp;<br /><br />';
			if ($okString != '')
				$messageText .= Prado::localize('Schiacciate') . ':<br />' . $okString;

			if ($failedString != '')
				$messageText .= ($okString != '' ? '<br /><br />' : '') .
				 Prado::localize('Operazione fallita per') . ':<br />' . $failedString;
		}
		else
		{
			$messageText = Prado::localize('Nessuna operazione è stata effettuata');
			$errorCode = ClavisMessage::ERROR;
		}
		$this->getPage()->writeMessage($messageText, $errorCode);
		$this->populate($param);
	}

	public function onMultiRecordSelect($sender, $param) {
		$val = $this->SelectedRecord->getValue();
		$this->getToReplace();
		if ($val == 'multi')
			$this->_toReplace = array_merge($this->_toReplace,unserialize($this->SelectedId->getValue()));
		else
			$this->_toReplace[] = intval($this->SelectedId->getValue());
		$this->setToReplace();
		$this->populate($param);
	}

	public function onItemRemove($sender, $param) {
		$this->getToReplace();
		$id = $this->ResultGrid->DataKeys[$param->getItem()->getItemIndex()];
		$k = array_search($id,$this->_toReplace);
		if ($k !== false)
			unset($this->_toReplace[$k]);
		$this->setToReplace();
		$this->populate();
	}
}
