<?php
/**
 * AuthorityEditPage class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: https://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Ciro Mattia Gonano
 * @author Marco Brancalion <marco@comperio.it>
 * @link https://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 ePortal Technologies
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.8.6
 * @package Pages.Catalog
 */

/**
 * AuthorityEditPage Class
 *
 * @author Ciro Mattia Gonano
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.8.6
 * @package Pages.Catalog
 * @since 2.0
 */
class AuthorityEditPage extends ClavisPage
{
	public $_module = 'CATALOG';

	public function onInit($param) 
	{
		parent::onInit($param);

		if (!$this->getIsPostBack() 
				&& !$this->getIsCallback())
		{
			$id = intval($this->getRequest()->itemAt('id'));
			
			if ($id > 0) 
			{
				$this->setAuthorityId($id);
				$this->AuthEdit->setAuthorityId($id);
			}
			else
			{
				$auth = new Authority();
				
				if ($v=$this->getRequest()->itemAt('Title'))
					$auth->setSortText($v);
				
				if ($v=$this->getRequest()->itemAt('authType'))
					$auth->setAuthorityType($v);
				
				$this->AuthEdit->authority = $auth;
			}
			
			$this->UpdateData->setObject(AuthorityQuery::create()->findPk($id));
		}
		else  // not first cycles
		{
			if ($this->getApplication()->getSession()->itemAt('NewAuthorityDelayedMessageFlag'))
			{
				$this->getApplication()->getSession()->remove('NewAuthorityDelayedMessageFlag');

				$this->getPage()->writeMessage(Prado::localize('Voce di authority inserita con successo'), 
												ClavisMessage::CONFIRM);
			}
		}
	}

	public function onLoad($param)
	{
		parent::onLoad($param);
		
		$authorityId = $this->AuthEdit->getAuthorityId();
		
		$isReturnableObjectStack = ClavisBase::isReturnableObjectStack(	ClavisBase::EDITOBJECTSSTACK_TYPEAUTHORITY, 
																		$authorityId);

		/**
		 * Autofill part, in the links panels
		 * 
		 * linked manifestation autofill part from session's stack relative
		 * to the editObjects
		 */
		if (!ClavisBase::isEndlineObjectStack(	ClavisBase::EDITOBJECTSSTACK_TYPEAUTHORITY, 
												$authorityId))
		{
			$fillOk = false;
			
			$lastLinkObject = ClavisBase::getFillableObjectStack(	ClavisBase::EDITOBJECTSSTACK_TYPEAUTHORITY, 
																	$authorityId);
			
			if (ClavisBase::isValidElementObjectStack($lastLinkObject))
			{
				ClavisBase::delEditObjectStack();
				
				list($linkObjectType, $linkObjectId, $title) = $lastLinkObject;
				
				if ($linkObjectId > 0)
				{
					if ($linkObjectType == ClavisBase::EDITOBJECTSSTACK_TYPEMANIFESTATION)
					{
						/*			Not managed case
						$linkManifestation = ManifestationQuery::create()->findPk($linkObjectId);

						if ($linkManifestation instanceof Manifestation)
						{
							$this->RecordResultLabel->setText($linkManifestation->getTitle());	// don't trim
							$this->RecordResultValue->setValue($linkObjectId);
							
							$fillOk = true;
						}
						else
						{
							$this->writeMessage(Prado::localize("Il parametro passato come notizia da collegare non identifica alcun oggetto esistente. Riportare al fornitore del software"),
													ClavisMessage::ERROR);
						}		AuthEdit->AuthLink->NewAuthLink     AuthEdit->AuthLink->AuthorityID
						 */       
					}
					elseif ($linkObjectType == ClavisBase::EDITOBJECTSSTACK_TYPEAUTHORITY)
					{
						$linkAuthority = AuthorityQuery::create()->findPk($linkObjectId);

						if ($linkAuthority instanceof Authority)
						{
							$this->AuthEdit->AuthLink->NewAuthLink->setText($linkAuthority->getFullText());
							$this->AuthEdit->AuthLink->AuthorityID->setValue($linkObjectId);
							
							$this->AuthEdit->AuthLink->setAuthority(AuthorityQuery::create()->findPk($authorityId));
							$this->AuthEdit->AuthLink->populateDropDowns($linkAuthority);
							
							$fillOk = true;
						}
						else
						{
							$this->writeMessage(Prado::localize("Il parametro passato come authority da collegare non identifica alcun oggetto esistente. Riportare al fornitore del software"),
													ClavisMessage::ERROR);
						}
					}
				}

				// another check for endline, after the popping of an element from editObjectStack
				ClavisBase::isEndlineObjectStack(	ClavisBase::EDITOBJECTSSTACK_TYPEAUTHORITY, 
													$authorityId, 
													true);
			}
			
			if ($fillOk)
			{
				$this->AuthEdit->AuthEditTPanel->setActiveViewID('TabAuthLink');

				$this->writeMessage(Prado::localize("Dati di legame a oggetto compilati automaticamente"),
														ClavisMessage::INFO);	
			}
		}
		else
		{
			ClavisBase::isEndlineObjectStack(	ClavisBase::EDITOBJECTSSTACK_TYPEAUTHORITY, 
												$authorityId, 
												true);
		}

		// on first page cycle
		if (!$this->getPage()->getIsPostBack()
				&& !$this->getPage()->getIsCallBack())
		{
			if ($authorityId > 0)
			{
				$authority = AuthorityQuery::create()->findPk($authorityId);

				if ($authority instanceof Authority)
				{
					$modifyEnabled = $this->getUser()->getEditPermission($authority);

					/* check if librarian can actually edit this manifestation */
					if (!$modifyEnabled)
					{
						$this->Apply->setVisible(false);
						$this->Save->setVisible(false);
						$this->SaveAndReturn->setVisible(false);
					}
					else
					{
						$this->Apply->setVisible(true);
						$this->Save->setVisible(!$isReturnableObjectStack);
						$this->SaveAndReturn->setVisible($isReturnableObjectStack);
					}
				}
			}
		}
	}
	
	public function setAuthorityId($value) 
	{
		$this->setViewState('AuthId', intval($value), null);
	}

	public function getAuthorityId() 
	{
		return $this->getViewState('AuthId', null);
	}

	public function onSave($sender, $param)
	{
		$wasNew = $this->AuthEdit->authority->isNew();
		$exit = $this->AuthEdit->onSave($sender, $param);

		if (!$exit)
		{
			$this->getPage()->writeMessage(Prado::localize('Nessuna azione eseguita'), 
												ClavisMessage::INFO);
			
			return false;
		}

		if ($param->getCommandParameter() == 'apply')
		{	
			if ($wasNew)
			{
				$this->gotoPage(	'Catalog.AuthorityEditPage', 
									array('id' => $this->AuthEdit->getAuthorityId()));
			}
			else
			{
				$this->AuthEdit->populate();
			}
		}
		elseif ($param->getCommandParameter() == 'saveandreturn')
		{
			$secondElement = ClavisBase::readSecondEditObjectStack();
			
			if ((ClavisBase::isReturnableObjectStack(	ClavisBase::EDITOBJECTSSTACK_TYPEAUTHORITY, 
														$this->AuthEdit->getAuthorityId()))
					&& (ClavisBase::isValidElementObjectStack($secondElement)))
			{
				if ($secondElement[0] == ClavisBase::EDITOBJECTSSTACK_TYPEMANIFESTATION)	// manifestation
				{
					$this->gotoPage(	'Catalog.EditRecord', 
										array(	'manifestationId' => $secondElement[1],
												//'selectTab' => 'TabAuthLink' 
											));
				}
				elseif ($secondElement[0] == ClavisBase::EDITOBJECTSSTACK_TYPEAUTHORITY)	// authority
				{
					$this->gotoPage(	'Catalog.AuthorityEditPage', 
										array(	'id' => $secondElement[1],
												//'selectTab' => 'TabAuthLink' 
											));
				}
			}
			else
			{	
				$this->writeDelayedMessage(Prado::localize("Non è possibile tornare indietro all'oggetto per il collegamento"),
												ClavisMessage::ERROR);
				
				$this->gotoPage(	'Catalog.AuthorityViewPage', 
									array('id' => $this->AuthEdit->getAuthorityId()));
			}
		}
		elseif ($param->getCommandParameter() == 'save')
		{
			$this->gotoPage(	'Catalog.AuthorityViewPage', 
								array('id' => $this->AuthEdit->getAuthorityId()));
		}
		else
		{
			$this->getPage()->writeMessage(Prado::localize('Nessuna azione eseguita'), 
												ClavisMessage::INFO);
			
			return false;
		}
	}

	public function onCancelOperation($sender, $param)
	{
		if ($this->AuthEdit->getAuthorityId())
		{
			$this->gotoPage('Catalog.AuthorityViewPage', array('id' => $this->AuthEdit->getAuthorityId()));
		}
		else
		{
			$this->gotoPage('Catalog.AuthorityViewPage');
		}
	}
	
}