<?php

/**
 * AuthorityList Page class Module Catalog
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2010 Comperio srl
 */

class AuthorityList extends ClavisPage
{
	public $_module = 'CATALOG';

	public function onInit($param)
	{
		parent::onInit($param);

		$search = $this->getRequest()->itemAt('search');
		if ($search)
			$this->AuthorityList->setSearch($search);
	}

	public function onPreRender($param) 
	{
		parent::onPreRender($param);
		
		$addToShelfVisible = (intval($this->AuthorityList->FoundNumber->getText()) > 0);
		
		$this->AddToShelfPanel->setVisible($addToShelfVisible);
		$this->OperationPanel->setVisible($addToShelfVisible);
	}
	
	public function globalRefresh()
	{
		$this->AuthorityList->resetSorting();
		$this->AuthorityList->resetDataSource();
	}
	
	public function onAddToShelf($sender, $param)
	{
		$counter = 0;
		$shelfId = intval(trim($this->ShelfResultValue->getSafeText()));

		$this->ShelfResultLabel->setText('');
		$this->ShelfResultValue->setText('');

		if ($shelfId > 0)
		{
			$shelf = ShelfQuery::create()->findPk($shelfId);
			
			if ($shelf instanceof Shelf)
				$counter = $shelf->addItemToShelf(	'authority',
													$this->AuthorityList->getCheckedIds(true));
		}
		
		if ($counter > 0) 
		{
			$this->writeMessage($counter == 1 ?
											Prado::localize('1 elemento processato') :
											Prado::localize('{count} elementi processati',
																array('count' => $counter)),
								ClavisMessage::CONFIRM);
			
			$this->AuthorityList->populate();  // forced re-population
		} 
		else 
		{
			$this->writeMessage(Prado::localize("Nessun elemento aggiunto a scaffale"),
									ClavisMessage::ERROR);
		}
	}
	
}
