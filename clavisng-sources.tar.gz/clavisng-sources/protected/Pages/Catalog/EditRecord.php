<?php
/**
 * EditRecord class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author    Dario Rigolin <dario@comperio.it>
 * @author    Ciro Mattia Gonano
 * @link      http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 ePortal Technologies
 * @license   http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version   2.8.6
 * @package   Pages.Catalog
 */

/**
 * EditRecord Class
 *
 * @author  Dario Rigolin <dario@comperio.it>
 * @author  Ciro Mattia Gonano
 * @author  Marco Brancalion <marco@comperio.it>
 * @version 2.8.6
 * @package Pages.Catalog
 * @since   2.0
 */
class EditRecord extends ClavisPage
{
	const LANGUAGE_DEFAULT = 'it_IT';
	const TIMEOUT_LIMIT = 5;

	public $_module = 'CATALOG';
	public $numberFieldLabels;
	public $f101labels = array();
	/** @var Manifestation */
	private $_manifestation = null;
	/** @var ClavisSBN */
	private $_sbnMod;
	private $_authLinkTypesAllowed = array(AuthorityPeer::TYPE_CLASS,
		AuthorityPeer::TYPE_CORPORATEBODYNAME,
		AuthorityPeer::TYPE_FAMILYNAME,
		//	AuthorityPeer::TYPE_FORM,
		AuthorityPeer::TYPE_PERSONALNAME,
		AuthorityPeer::TYPE_PLACE,
		AuthorityPeer::TYPE_PRINTERSDEVICE,
		AuthorityPeer::TYPE_PUBPLACE,
		AuthorityPeer::TYPE_TRADEMARK,
		AuthorityPeer::TYPE_WORK,
		AuthorityPeer::TYPE_SUBJECT);
	private $_numberFields = array('073',
		'010',
		'011',
		'012',
		'013',
		'014',
		'015',
		'016',
		'017',
		'020',
		'021',
		'022',
		'040',
		'071',
		'072');

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!class_exists('TurboMarc'))
			throw new Exception('You should include TurboMarc class', 1);

		$this->_sbnMod = $this->getApplication()->getModule('sbn');

		/* populate number labels */
		foreach ($this->_numberFields as $field) {
			$sfs = UnimarcLabelsQuery::create()
				->filterByLanguage($this->getApplication()->getGlobalization()->getCulture())
				->filterByUnimarcType('U')
				->findByFieldNumber($field);

			foreach ($sfs as $l) {
				if (!$tag = $l->getSubfieldTag()) {
					$this->numberFieldLabels[$field]['label'] = $l->getLabel();
				} else if (!(('012' == $field) && ('a' == $tag))
					&& !(('017' == $field) && ('2' == $tag)))    // exclude 012 $a and 017 $2
				{
					$this->numberFieldLabels[$field]['subfields'][$l->getSubfieldTag()] = array('tag' => $l->getSubfieldTag(),
						'label' => $l->getLabel(),
						'maxlength' => $l->getMaxlength());
				}
			}

			foreach ($this->numberFieldLabels as $field => &$v)
				uksort($v['subfields'], 'Clavis::strcmpAZ09');
		}

		$labels101 = UnimarcCodesQuery::create()
			->filterByLanguage($this->getApplication()->getGlobalization()->getCulture())
			->filterByUnimarcType('U')
			->filterByFieldNumber(101)
			->orderBySubfieldTag()
			->find();

		foreach ($labels101 as $label) {
			if (!array_key_exists($label->getSubfieldTag(), $this->f101labels))
				$this->f101labels[$label->getSubfieldTag()] = $label->getLabel();
		}

		$this->TabAuthority->setVisible(false);
		$this->TabAttach->setVisible(false);

		$this->TurbomarcPanel->setVisible($this->getApplication()->getMode() == 'Debug'
			|| $this->getUser()->getIsAdmin());

		$manifestationId = intval($this->getRequest()->itemAt('manifestationId'));

		if ($manifestationId == 0) {
			$manifestation = new Manifestation();
			$this->setManifestation($manifestation);
			$this->initManifestation();
		} else {
			$manifestation = ManifestationQuery::create()->findPk($manifestationId);

			if (!$manifestation instanceof Manifestation)
				$this->gotoErrorPage($manifestationId);

			$modifyEnabled = $this->getUser()->getEditPermission($manifestation)
				&& ($manifestation->getCatalogationLevel() <= $this->getUser()->getLibrarian()->getCatLevel());
		}

		$isReturnableObjectStack = ClavisBase::isReturnableObjectStack(ClavisBase::EDITOBJECTSSTACK_TYPEMANIFESTATION,
			$manifestationId);

		/**
		 * Autofill part, in the links panels
		 *
		 * linked manifestation autofill part from session's stack relative
		 * to the editObjects
		 */
		if (!ClavisBase::isEndlineObjectStack(ClavisBase::EDITOBJECTSSTACK_TYPEMANIFESTATION,
			$manifestationId)) {
			$fillOk = false;

			$lastLinkObject = ClavisBase::getFillableObjectStack(ClavisBase::EDITOBJECTSSTACK_TYPEMANIFESTATION,
				$manifestationId);

			if (ClavisBase::isValidElementObjectStack($lastLinkObject)) {
				ClavisBase::delEditObjectStack();

				list($linkObjectType, $linkObjectId, $title) = $lastLinkObject;

				if ($linkObjectId > 0) {
					if ($linkObjectType == ClavisBase::EDITOBJECTSSTACK_TYPEMANIFESTATION) {
						$linkManifestation = ManifestationQuery::create()->findPk($linkObjectId);

						if ($linkManifestation instanceof Manifestation) {
							$this->RecordResultLabel->setText($linkManifestation->getTitle());    // don't trim
							$this->RecordResultValue->setValue($linkObjectId);

							$fillOk = true;
						} else {
							$this->writeMessage(Prado::localize("Il parametro passato come notizia da collegare non identifica alcun oggetto esistente. Riportare al fornitore del software"),
								ClavisMessage::ERROR);
						}
					} else if ($linkObjectType == ClavisBase::EDITOBJECTSSTACK_TYPEAUTHORITY) {
						$linkAuthority = AuthorityQuery::create()->findPk($linkObjectId);

						if ($linkAuthority instanceof Authority) {
							$this->NewAuthLink->setText($linkAuthority->getFullText());
							$this->AuthorityID->setValue($linkObjectId);

							$fillOk = true;
						} else {
							$this->writeMessage(Prado::localize("Il parametro passato come authority da collegare non identifica alcun oggetto esistente. Riportare al fornitore del software"),
								ClavisMessage::ERROR);
						}
					}
				}

				// another check for endline, after the popping of an element from editObjectStack
				ClavisBase::isEndlineObjectStack(ClavisBase::EDITOBJECTSSTACK_TYPEMANIFESTATION,
					$manifestationId,
					true);
			}

			if ($fillOk) {
				$this->MyTabPanel->setActiveViewID('TabAuthority');

				$this->writeMessage(Prado::localize("Dati di legame a oggetto compilati automaticamente"),
					ClavisMessage::INFO);
			}
		} else {
			ClavisBase::isEndlineObjectStack(ClavisBase::EDITOBJECTSSTACK_TYPEMANIFESTATION,
				$manifestationId,
				true);
		}

		// first page cycle
		if (!$this->getPage()->getIsPostBack()
			&& !$this->getPage()->getIsCallBack()) {
			/* tabview selection by request parameter */
			try {
				$selectTab = $this->getRequest()->itemAt('selectTab');

				if (is_numeric($selectTab)
					&& $selectTab > 0) {
					$this->MyTabPanel->setActiveViewIndex($selectTab);
				} else if (is_string($selectTab)
					&& $selectTab != "") {
					$this->MyTabPanel->setActiveViewID($selectTab);
				}
			} catch (Exception $e) {
				//Prado::log($e);
			}

			if ($manifestationId > 0) {
				/* check if librarian can actually edit this manifestation */
				if (!$modifyEnabled) {
					$this->TabQualification->setVisible(false);
					$this->TabDescription->setVisible(false);
					$this->TabTitles->setVisible(false);
					$this->TabNote->setVisible(false);
					$this->TabNumbers->setVisible(false);
					$this->TabCDF->setVisible(false);
					$this->TabQualification->setVisible(false);
					$this->MyTabPanel->setActiveViewID('TabAuthority');
					$this->Apply->setVisible(false);
					$this->Save->setVisible(false);
					$this->SaveAndReturn->setVisible(false);
				} else {
					$this->Save->setVisible(!$isReturnableObjectStack);
					$this->SaveAndReturn->setVisible($isReturnableObjectStack);
				}

				$this->TabAuthority->setVisible(true);
				$this->TabAttach->setVisible(true);
				$this->setManifestation($manifestation);
				$this->AttachList->setObjectClass('Manifestation');
				$this->AttachList->setObjectId($manifestationId);

				$catlevel = $this->getUser()->getLibrarian()->getCatLevel();

				if (!$catlevel)
					$catlevel = '05';

				$ds = LookupValueQuery::create()
					->filterByValueLanguage($this->getApplication()->getGlobalization()->getCulture())
					->filterByValueClass('CATLEVEL')
					->filterByValueKey($catlevel, Criteria::LESS_EQUAL)
					->find();

				$this->ManLevel->setDataSource($ds);
				$this->ManLevel->dataBind();
			} else {
				$manifestation = new Manifestation();
				$this->setManifestation($manifestation);
				$this->initManifestation();
			}

			$this->populateUnimarc();
			$this->bindAuthGrid();
			$this->bindManGrid();
		} else {
			if (!$manifestation->isNew()) {
				$this->TabAuthority->setVisible(true);
				$this->TabAttach->setVisible(true);
			}
		}

		switch ($this->DataClass->SelectedValue) {

			case "a":
				$this->getClientScript()->registerStyleSheet("archoff", ".archhide {display: none;}");
				$this->dataClassChange(null, null);
				break;
			case "m":
				$this->getClientScript()->registerStyleSheet("archoff", ".archhide {display: none;}");
				$this->getClientScript()->registerStyleSheet("musoff", ".archhide {display: none;}");
				$this->dataClassChange(null, null);
				break;
		}

		$this->SBNTabView->setVisible($modifyEnabled
			&& $this->_sbnMod->getEnabled()
			&& $manifestation instanceof Manifestation
			&& !$manifestation->isNew());
		if ($this->SBNTabView->getVisible()) {
			$img = $this->SBNActions->getStatusIcon();
			$this->SBNTabView->setCaption("SBN <img style=\"height:12px;border:0;margin:0;padding:0;\" src=\"{$img['img']}\" alt=\"{$img['txt']}\" />");
		}
	}

	public function initManifestation()
	{
		$tm = TurboMarc::createRecord();
		$tm->addField(100, '');
		$f = $tm->addField(200);
		$f->addSubField('a', '');
		$f = $tm->addField(205);
		$f->addSubField('a', '');
		$f = $tm->addField(210);
		$f->addSubField('a', '');
		$f = $tm->addField(215);
		$f->addSubField('a', '');
		$f = $tm->addField(225);
		$f->addSubField('a', '');
		$f->addSubField('v', '');

		$this->_manifestation->setUnimarc($tm->asXML());
		$this->_manifestation->setBibLevel('m');
		$this->_manifestation->setBibTypeFirst(1);
	}

	public function populate()
	{
		$this->populateUnimarc();
		$this->bindAuthGrid();
		$this->bindManGrid();
	}

	public function populateUnimarc()
	{
		$this->ManStatus->setSelectedValue($this->_manifestation->getManifestationStatus());
		$this->ManLevel->setSelectedValue($this->_manifestation->getCatalogationLevel());
		$this->HierLevel->setText(LookupValuePeer::getLookupValue('HIERLEVEL', $this->_manifestation->getHierarchicalLevel()));
		$this->BibLevel->setSelectedValue($this->_manifestation->getBibLevel());
		$this->BibObjFirst->setSelectedValue($this->_manifestation->getBibTypeFirst());

		$firstValue = $this->BibObjFirst->getSelectedValue();

		if ($firstValue) {
			$this->BibObj->setVisible(true);
			$this->BibObj->setDBClass('OGGBIBL_' . $firstValue);
			$this->BibObj->populateList();
			$this->BibObj->setSelectedValue($this->_manifestation->getBibType());
		} else {
			$this->BibObj->setVisible(false);
		}

		$this->BidSource->setText($this->_manifestation->getBidSource());
		$this->Bid->setText($this->_manifestation->getBid());

		if ($r = $this->_manifestation->getRating()) {
			$this->ManRating->setSelectedValue($r);
		} else {
			$this->ManRating->setSelectedIndex(0);
		}

		if ($ls = $this->_manifestation->getLoanableSince('U'))
			$this->LoanableSince->setTimestamp($ls);

		$tm = TurboMarc::createRecord($this->_manifestation->getUnimarc());

		$this->DataClass->setSelectedValue($tm->getLeader()->entitytype);

		$ds = $numberfields = array();

		foreach ($this->numberFieldLabels as $fnum => $field) {
			$numberfields[] = array('field' => $fnum,
				'label' => $field['label']);

			$xmlField = "d{$fnum}";

			if (!isset($tm->$xmlField))
				continue;

			/* @var $fld TurboMarc */
			foreach ($tm->$xmlField as $fld) {
				$num = array();

				if ('012' == $fnum && !isset($fld->ss)) { // old format, convert to new one
					$fld->addSubField('s', substr($fld->sa, 0, 4));
					$fld->addSubField('t', substr($fld->sa, 5, 4));
					$fld->addSubField('u', substr($fld->sa, 10, 4));
					$fld->addSubField('v', substr($fld->sa, 15, 4));
					$fld->addSubField('w', substr($fld->sa, 20, 12));
					$fld->addSubField('x', substr($fld->sa, 33));
				}

				if ('071' == $fnum)
					$num['i1'] = $fld['i1'];

				if ('017' == $fnum)
					$num['s2'] = (string)$fld->s2;

				$num['field'] = $fnum;
				$num['fieldlabel'] = $field['label'];
				$num['subfields'] = array();

				foreach (array_keys($field['subfields']) as $sftag) {
					$xmltag = "s{$sftag}";
					$num['subfields'][$sftag] = (string)$fld->$xmltag;
				}

				$ds[] = $num;
			}
		}

		if (count($ds) < 1) {
			$num = array('field' => '073',
				'fieldlabel' => $this->numberFieldLabels['073']['label'],
				'subfields' => array());

			foreach (array_keys($this->numberFieldLabels['073']['subfields']) as $sftag)
				$num['subfields'][$sftag] = '';

			$ds[] = $num;
		}

		$this->RepNumbers->setDataSource($ds);
		$this->RepNumbers->dataBind();
		$this->NewNumberList->setDataSource($numberfields);
		$this->NewNumberList->dataBind();

		$ds = array();

		if (!empty($tm->d856)) {
			foreach ($tm->d856 as $field) {
				$ds[] = array('field' => 856,
					'ind' => (string)$field->attributes()->i1,
					'u' => (string)$field->su,
					'z' => (string)$field->sz);
			}
		}

		$this->Rep856->setDataSource($ds);
		$this->Rep856->dataBind();

		if (isset($tm->d100)) {
			try {
				$f100_a_0 = $tm->d100->getCDF('a', 0);

				if (!$f100_a_0)
					$f100_a_0 = date('Ymd');

				$this->F100a0->setValue($f100_a_0);
			} catch (Exception $e) {
				$this->F100a0->setValue(date('Ymd'));
			}

			try {
				$f100_a_8 = $tm->d100->getCDF('a', 8);

				if ($f100_a_8 != false)
					$this->DateType->setSelectedValue(strtr($f100_a_8, ' ', 'a'));
			} catch (Exception $e) {

			}

			$this->F100aDate1->setText(trim($tm->d100->getCDF('a', 9)));
			$this->F100aDate2->setText(trim($tm->d100->getCDF('a', 13)));

			try {
				$this->F100a17->setValue(trim($tm->d100->getCDF('a', 17)));
			} catch (Exception $e) {

			}

			try {
				$this->F100a18->setValue(trim($tm->d100->getCDF('a', 18)));
			} catch (Exception $e) {

			}

			try {
				$this->F100a19->setValue(trim($tm->d100->getCDF('a', 19)));
			} catch (Exception $e) {

			}

			try {
				$this->F100a20->setValue(trim($tm->d100->getCDF('a', 20)));
			} catch (Exception $e) {

			}
		}

		if (isset($tm->d101)) {
			try {
				$this->F101Ind1->setSelectedValue((string)$tm->d101['i1']);
			} catch (Exception $e) {

			}

			$ds101 = array();

			foreach ($tm->d101->children() as $sf) {
				$ds101[] = array('LangTag' => $sf->getTag(),
					'LangCode' => strtolower((string)$sf));
			}
		} else {
			$ds101[] = array('LangTag' => 'a', 'LangCode' => 'ita');
		}

		$this->RepF101->setDataSource($ds101);
		$this->RepF101->dataBind();

		if (isset($tm->d102))
			$this->F102a->setSelectedValue(strtolower((string)$tm->d102->sa));

		$title = $tm->getTitle(200, true);
		$sort_text = trim(array_shift($title['txt']));
		$this->F200ind->setChecked($title['ind'] == '1 ');
		$this->F200->setText(trim($title['nst'] . '*' . $sort_text));
		$ds = array();

		foreach ($title['txt'] as $c) {
			$ds[] = array(
				'Text' => $c,
				'Label' => ($this->DataClass->SelectedValue == ' ') ? Prado::localize("Titolo proprio di altro autore") :
					Prado::localize("Altro titolo")
			);
		}
		$this->RepF200c->setDataSource($ds);
		$this->RepF200c->databind();

		$editions = array();

		foreach ($tm->getEditions(true) as $e)
			$editions[] = array('txt' => $e);

		if (count($editions) < 1)
			$editions[] = array('txt' => '');

		$this->RepF205->setDataSource($editions);
		$this->RepF205->dataBind();

		$areas = array();

		foreach ($tm->d206 as $f206)
			$areas[] = array('field' => 206,
				'value' => (string)$f206->sa);

		foreach ($tm->d207 as $f207)
			$areas[] = array('field' => 207,
				'value' => (string)$f207->sa);

		foreach ($tm->d208 as $f208)
			$areas[] = array('field' => 208,
				'value' => (string)$f208->sa);

		foreach ($tm->d230 as $f230)
			$areas[] = array('field' => 230,
				'value' => (string)$f230->sa);
		if (count($areas) < 1)
			$areas[] = array('field' => null,
				'value' => '');

		$this->RepF2XX->setDataSource($areas);
		$this->RepF2XX->dataBind();

		$publications = array();

		foreach ($tm->getPublications(true, true) as $p)
			$publications[] = $p;

		if (count($publications) < 1)
			$publications[] = array('ind' => '  ',
				'txt' => '');

		$this->RepF210->setDataSource($publications);
		$this->RepF210->dataBind();

		$physdesc = array();

		foreach ($tm->getPhysicalDescs(true) as $p)
			$physdesc[] = array('txt' => $p);

		if (count($physdesc) < 1)
			$physdesc[] = array('txt' => '');

		$this->RepF215->setDataSource($physdesc);
		$this->RepF215->dataBind();

		$series = array();
		foreach ($tm->getSeries(true) as $s) {
			$ser_uni = explode(' ; ', $s);
			$series[] = array('desc' => $ser_uni[0],
				'num' => (count($ser_uni) > 1) ? $ser_uni[1] : '');
		}

		if (!$series)
			$series[] = array('desc' => '',
				'num' => '');

		$this->RepF225->setDataSource($series);
		$this->RepF225->dataBind();

		$ds5xx = array();
		for ($field = 500; $field < 600; ++$field) {
			$tag = "d$field";
			if (isset($tm->$tag)) {
				foreach ($tm->$tag as $fld)
					$ds5xx[] = array('field' => $field,
						'value' => (string)$fld->sa,
						'bid' => (string)$fld->s3);
			}
		}

		$this->RepF5XX->setDataSource($ds5xx);
		$this->RepF5XX->dataBind();

		$ds3xx = array();
		$n3xx = array_keys(LookupValuePeer::getLookupClassValues("UNI3XX"));

		foreach ($n3xx as $field) {
			$tag = "d$field";

			if (isset($tm->$tag)) {
				$fieldContent = array();

				foreach ($tm->$tag as $fld) {
					if ($field < 400)
						$ds3xx[] = array('NoteNumber' => $field,
							'NoteValue' => (string)$fld->sa);

					else {
						$noteTxt = "";

						foreach ($fld->children() as $c)
							$noteTxt .= "<[" . substr($c->getName(), 1) . "] " . $c['l'] . ">\n:" . (string)$c . "\n";

						$ds3xx[] = array('NoteNumber' => $field,
							'NoteValue' => trim($noteTxt));
					}
				}
			}
		}

		$this->RepF3XX->setDataSource($ds3xx);
		$this->RepF3XX->dataBind();

		$this->refreshISBD();
		$this->populateLinkDropDown();

//		$remoteCoverServer = ClavisParamQuery::getParam('CLAVISPARAM', 'RemoteCoverServer');
//
//		if ($remoteCoverServer)
//		{
//			$ean = $this->getEANFromManifestation();
//			$key = 'c24160fecc46e71ece61914511fc044f9dee40ac';
//			$reply = @file_get_contents("{$remoteCoverServer}/getcover.php?key={$key}&ean={$ean}&act=check");
//			$this->RemoteCoverCheck->setVisible($reply == 'OK');
//		}
	}

	public function refreshISBD()
	{
		$isbd = str_replace('\n', ' ', $this->_manifestation->getTitle());

		foreach ($this->RepF205->Items as $item) {
			$value = trim($item->F205->getText());

			if ($value != '')
				$isbd .= '<b>. - </b>' . $value;
		}

		foreach ($this->RepF2XX->Items as $item) {
			$value = trim($item->F2XXValue->getText());

			if ($value != '')
				$isbd .= '<b>. - </b>' . $value;
		}

		foreach ($this->RepF210->Items as $item) {
			$value = trim($item->F210Value->getText());

			if ($value != '')
				$isbd .= '<b>. - </b>' . $value;
		}

		foreach ($this->RepF215->Items as $item) {
			$value = trim($item->F215->getText());

			if ($value != '')
				$isbd .= '<b>. - </b>' . $value;
		}

		foreach ($this->RepF225->Items as $item) {
			$value = trim($item->F225a->getText());

			if ($value != '')
				$isbd .= '<b>. - </b>' . $value;
		}

		$this->ISBD->setText($isbd);
	}

	/**
	 * Returns the manifestation object
	 *
	 * @return Manifestation
	 */
	public function getManifestation()
	{
		if ($this->_manifestation == null) {
			$manifestationId = intval($this->getRequest()->itemAt('manifestationId'));
			$manifestation = ManifestationPeer::retrieveByPK($manifestationId);

			if ($manifestation === null)
				$this->gotoPage('ErrorPage');

			$this->setManifestation($manifestation);
		}

		return $this->_manifestation;
	}

	public function setManifestation($value)
	{
		$this->_manifestation = $value;
		$this->getSession()->add('manifestation', $value);
	}

	public function getManifestationId()
	{
		$manifestationId = null;
		$manifestation = $this->getManifestation();

		if ($manifestation instanceof Manifestation)
			$manifestationId = $manifestation->getManifestationId();

		return $manifestationId;
	}

	public function cleanManifestation()
	{
		$this->_manifestation = null;
		$this->getManifestation();
	}

	public function getRecordHasMainAuthor()
	{
		//$mid = intval($this->getRequest()->itemAt('manifestationId'));
		$mid = $this->getManifestationId();

		if ($mid < 1)
			return false;

		$c = LAuthorityManifestationQuery::create()
			->filterByManifestationId($mid)
			->filterByLinkType(array(700, 710))
			->count();

		return ($c > 0);
	}

	public function getRecordHasAltAuthors()
	{
		//$mid = intval($this->getRequest()->itemAt('manifestationId'));
		$mid = $this->getManifestationId();

		if ($mid < 1)
			return false;

		$c = new Criteria();
		$c->add(LAuthorityManifestationPeer::MANIFESTATION_ID, $mid);
		$c->add(LAuthorityManifestationPeer::LINK_TYPE, array(701, 711), Criteria::IN);

		return LAuthorityManifestationPeer::doCount($c) > 1;
	}

	public function populateLinkDropDown($a = null)
	{
		list($ds, $select) = $this->calculateLinkDropDown($a);

		$this->LinkType->setDataSource($ds);
		$this->LinkType->dataBind();

		if (!$select) {
			$this->LinkType->setSelectedIndex(0);
		} else {
			$this->LinkType->setSelectedValue($select);
		}
	}

	public function onNewLink($sender, $param)
	{
		$this->getManifestation();
		$linkAuthID = intval($this->AuthorityID->getValue());
		$linkedAuth = AuthorityQuery::create()->findPk($linkAuthID);

		if ($linkedAuth instanceof Authority) {
			$link = new LAuthorityManifestation();
			$link->setManifestation($this->_manifestation);
			$link->setAuthorityId($linkAuthID);
			$link->setRelatorCode($this->RelatorCode->getSelectedValue());
			$linkType = $this->LinkType->getSelectedValue();

			if ($linkType == '610') {
				$type = $linkedAuth->getAuthorityType();

				if ($type == AuthorityPeer::TYPE_SUBJECT)
					$type = $linkedAuth->getAuthorityRelatedByParentId()->getAuthorityType();

				switch ($type) {
					case AuthorityPeer::TYPE_PERSONALNAME:
						$linkType = '600';
						break;

					case AuthorityPeer::TYPE_CORPORATEBODYNAME:
						$linkType = '601';
						break;

					case AuthorityPeer::TYPE_FAMILYNAME:
						$linkType = '602';
						break;

					case AuthorityPeer::TYPE_WORK:
						$linkType = '605';
						break;

					case AuthorityPeer::TYPE_PLACE:
						$linkType = '607';
						break;
					//	case AuthorityPeer::TYPE_FORM:
					//		$linkType = '608';
					//		break;

					case AuthorityPeer::TYPE_TRADEMARK:
						$linkType = '616';
						break;

					case AuthorityPeer::TYPE_PUBPLACE:
						$linkType = '620';
						break;

					case AuthorityPeer::TYPE_PRINTERSDEVICE:
						$linkType = '921';
						break;

					case AuthorityPeer::TYPE_ARGUMENT:
						$linkType = '610';
						break;

					default:
						$linkType = '606';
						break;
				}
			}

			$link->setLinkType($linkType);
			$link->setLinkNote($this->LinkNote->getText());

			// search for already existing link - add the new one only
			// if link is not in db already.
			$linkcheck = LAuthorityManifestationPeer::retrieveByPK($link->getAuthorityId(),
				$link->getManifestationId(),
				$link->getLinkType(),
				$link->getRelatorCode());

			if (!$linkcheck instanceof LAuthorityManifestation) {
				$link->save();

				$manId = $this->_manifestation->getManifestationId();
				$manifestationTitle = $this->_manifestation->getTrimmedTitle(80, '');

				ChangelogPeer::logAction($this->_manifestation,
					ChangelogPeer::LOG_CREATE,
					$this->getUser(),
					'Creato nuovo legame fra notizia (id = ' . $manId . ', titolo = ' . $manifestationTitle
					. ') e authority (id = ' . $linkAuthID . ')');

				$this->writeMessage(Prado::localize("Creato nuovo legame fra la notizia (id = {manid}, titolo = '{manifestationTitle}') e l'authority (id = {authid})",
					array('manid' => $manid,
						'manifestationTitle' => $manifestationTitle,
						'authid' => $linkAuthID)),
					ClavisMessage::CONFIRM);
			}

			$this->cleanManifestation();
			$this->authLinkCancel($sender, $param);
			$this->bindAuthGrid();
		} else {
			$this->getPage()->writeMessage(Prado::localize("Nessuna azione di legame ad authority eseguita"),
				ClavisMessage::INFO);
		}

		$this->populateLinkDropDown();
		$this->LinkType->SelectedIndex = -1;
		$this->LinkNote->setText('');
		$this->RelatorCode->SelectedIndex = -1;
		$this->AuthorityID->setValue('');
		$this->NewAuthLink->setText('');
	}

	public function onSuggestAuthority($sender, $param)
	{
		$prefix = $param->getToken();

		$this->NewAuthOnTheFly->setParam(urlencode($prefix));
		$this->authLinkTypeChanged($sender, $param);

		$authList = ('true' == ClavisParamQuery::getParam('CLAVISPARAM', 'AllTermsAsSubjects'))
			? AuthorityPeer::doSuggest($prefix, 10)
			: AuthorityPeer::doSuggest($prefix, 10, $this->_authLinkTypesAllowed);

		$authData = array();

		/* @var $auth Authority */
		foreach ($authList as $auth) {
			if ($auth instanceof Authority)
				$authData[] = array('id' => $auth->getAuthorityId(),
					'text' => $auth->getFullTextSpec());
		}

		$sender->setDataSource($authData);
		$sender->dataBind();
	}

	public function onSuggestSelectAuthority($sender, $param)
	{
		$id = $sender->Suggestions->DataKeys[$param->selectedIndex];
		$a = AuthorityQuery::create()->findPk($id);
		$a = $a->getAcceptedAuthority();

		if ($a instanceof Authority) {
			// the str_replace is needed for authorities can have &lt; instead of <,
			// in sort_text.
			$sender->setText(trim(str_replace('&lt;', '<', $a->getFullText())));
			$this->AuthorityID->setValue($a->getAuthorityId());
			$this->setAutoLinkType($sender, $param, $a);
		} else {
			$sender->setText('');
			$this->AuthorityID->setValue(null);
		}
	}

	public function setAutoLinkType($sender, $param, $a = null)
	{
		$this->populateLinkDropDown($a);
		/* correctly update params for Create */
		$this->NewAuthOnTheFly->setParam($this->NewAuthLink->getText());
		$this->authLinkTypeChanged($sender, $param);
	}

	public function authLinkTypeChanged($sender, $param)
	{
		switch ($this->LinkType->getSelectedValue()) {
			case '616':
				$val = AuthorityPeer::TYPE_TRADEMARK;
				break;

			case '620':
				$val = AuthorityPeer::TYPE_PUBPLACE;
				break;

			case '676':
				$val = AuthorityPeer::TYPE_CLASS;
				break;

			case '500':
				$val = AuthorityPeer::TYPE_WORK;
				break;

			case '921':
				$val = AuthorityPeer::TYPE_PRINTERSDEVICE;
				break;

			case '700':
			case '702':
			case '701':
				$val = AuthorityPeer::TYPE_PERSONALNAME;
				break;

			default:
				$val = AuthorityPeer::TYPE_SUBJECT;
				break;
		}

		$this->NewAuthPanel->render($param->getNewWriter());
		$this->NewAuthOnTheFly->setObjectType($val);
		$this->NewAuthOnTheFly->render($param->getNewWriter());
	}

	public function bindAuthGrid()
	{
		$this->SBNAuthSyncColumn->setVisible($this->_sbnMod->getEnabled());
		$manId = $this->_manifestation->getManifestationId();

		$lAuthLists = LAuthorityManifestationQuery::create()
			->filterByManifestationId($manId)
			->joinAuthority()
			->orderByLinkType()
			->setFormatter(ModelCriteria::FORMAT_ON_DEMAND)
			->find();

		$authGridDS = array();

		/* @var $lAuth LAuthorityManifestation */
		foreach ($lAuthLists as $lAuth) {
			$a = $lAuth->getAuthority();
			if ($a instanceof Authority) {
				$row['FullText'] = str_replace('<', '&lt;', $a->getFullText());
				$a->clearAllReferences(true);
			} else {
				$row['FullText'] = 'nessuna authority';
			}

			$row['AuthId'] = $lAuth->getAuthorityId();
			$row['LinkType'] = LookupValuePeer::getLookupValue('LINKTYPE', $lAuth->getLinkType());
			$row['LinkTypeIndex'] = $lAuth->getLinkType();
			$row['RelatorCodeValue'] = $lAuth->getRelatorCode();
			$row['RelatorCode'] = LookupValuePeer::getLookupValue('RELATORCODE', $row['RelatorCodeValue']);
			$row['LinkNote'] = $lAuth->getLinkNote();
			$row['LinkClass'] = get_class($lAuth);
			$row['DataKey'] = $row['AuthId'] . '-' . $manId . '-' . $lAuth->getLinkType() . '-' . $row['RelatorCodeValue'];
			$authGridDS[] = $row;
			$lAuth->clearAllReferences(true);

			unset($lAuth);
		}

		$this->AuthGrid->setDataSource($authGridDS);
		$this->AuthGrid->dataBind();

		if ($this->getPage()->getIsCallback())
			$this->AuthGridPanel->render($this->getPage()->createWriter());
		//$this->getPage()->getResponse()->getAdapter()->createNewHtmlWriter(	'THtmlWriter', $this->getPage()->getResponse()));
	}

	public function onAuthItemDataBound($sender, $param)
	{
		$item = $param->Item;

		if ($item->ItemType == 'EditItem') {
			$ls = LookupValuePeer::getLookupClassValues('RELATORCODE', true, '---', array(), true);
			$item->Cells[2]->EditRelatorCode->setDataSource($ls);
			$item->Cells[2]->EditRelatorCode->dataBind();
			$item->Cells[2]->EditRelatorCode->setSelectedValue($item->DataItem['RelatorCodeValue']);

			//$linkTypes = LookupValuePeer::getLookupClassValues('LINKTYPE', true, '---', array(), true);
			list($linkTypes, $select) = $this->calculateLinkDropDown();

			$item->Cells[0]->LinkTypeDropdownList->setDataSource($linkTypes);
			$item->Cells[0]->LinkTypeDropdownList->dataBind();
			$item->Cells[0]->LinkTypeDropdownList->setSelectedValue($item->DataItem['LinkTypeIndex']);
		}
	}

	public function onManItemDataBound($sender, $param)
	{
		$item = $param->Item;

		if ($item->ItemType == 'EditItem') {
			$linkTypes = $this->calculateManLinkDropDown();

			$item->Cells[0]->ManLinkTypeDropdownList->setDataSource($linkTypes);
			$item->Cells[0]->ManLinkTypeDropdownList->dataBind();
			$item->Cells[0]->ManLinkTypeDropdownList->setSelectedValue($item->DataItem['LinkTypeIndex']);
		}
	}

	public function setManLink($sender, $param)
	{
		$m = $this->getManifestation();

		if ($m->getBibLevel() != 'a')
			return;

		$linkedManifestation = ManifestationQuery::create()->findPk($this->RecordResultValue->getValue());

		if (!($linkedManifestation instanceof Manifestation))
			throw new Exception('Invalid linked manifestation!');

		if ($linkedManifestation->getBibLevel() == 's') {// serial - enable issue select
			$this->IssueLinkChooser->setParam($linkedManifestation->getManifestationId());
			$this->LinkedIssueSelect->setCssClass('panel_on');
			$this->LinkedIssueSelect->render($param->getNewWriter());
		}
	}

	public function bindManGrid()
	{
		set_time_limit(0);

		$this->SBNManSyncColumn->setVisible($this->_sbnMod->getEnabled());
		$pageSize = $this->ManGrid->getPageSize();
		$currentIndexPage = $this->ManGrid->getCurrentPage();
		$manId = $this->_manifestation->getManifestationId();

		$lManQuery = LManifestationQuery::create()
			->where('LManifestation.ManifestationIdUp = ?', $manId)
			->orWhere('LManifestation.ManifestationIdDown = ?', $manId)
			->orderByLinkType()
			->orderByLinkSequence()
			->setFormatter(ModelCriteria::FORMAT_ON_DEMAND)
			->keepQuery();

		$lManCount = $lManQuery->count();

		$lManLists = $lManQuery
			->setLimit($pageSize)
			->setOffset($currentIndexPage * $pageSize)
			->find();

		$manGridDS = array();

		/* @var $lman LManifestation */
		foreach ($lManLists as $lman) {
			if ($lman->getManifestationIdUp() == $manId) {
				$manifestationRelated = $lman->getManifestationRelatedByManifestationIdDown();
				$row['ManId'] = $lman->getManifestationIdDown();
				$row['LinkType'] = LookupValuePeer::getLookupValue('UNI4XX', $lman->getLinkType());
			} else {
				//patch
				$manifestationRelated = $lman->getManifestationRelatedByManifestationIdUp();
				$row['ManId'] = $lman->getManifestationIdUp();
				$row['LinkType'] = LookupValuePeer::getLookupValue('UNI4XX', TurboMarcMappings::$reverseLinkType[$lman->getLinkType()]);
			}

			$row['LinkTypeIndex'] = $lman->getLinkType();
			$row['SortText'] = '---';

			if ($manifestationRelated instanceof Manifestation) {
				$row['SortText'] = $manifestationRelated->getTitle();
				$manifestationRelated->clearAllReferences(true);

				unset($manifestationRelated);
			}

			$issue = $lman->getIssue();

			if ($issue instanceof Issue) {
				$row['SortText'] .= ' [' . $issue->getIssueCombo(false) . ']';
				$issue->clearAllReferences(true);

				unset($issue);
			}

			$row['LinkNote'] = $lman->getLinkNote();
			$row['LinkSequence'] = $lman->getLinkSequence();
			$row['LinkClass'] = get_class($lman);
			$row['DataKey'] = implode('-', $lman->getPrimaryKey());

			$manGridDS[] = $row;
			$lman->clearAllReferences(true);

			unset($lman);
		}

		$this->ManGrid->setVirtualItemCount($lManCount);
		$this->ManGrid->setDataSource($manGridDS);
		$this->ManGrid->dataBind();

		if ($this->getPage()->getIsCallback())
			$this->ManGridPanel->render($this->getPage()->createWriter());
	}

	public function changeManGridPage($sender, $param)
	{
		$this->ManGrid->setCurrentPage($param->NewPageIndex);
		$this->bindManGrid();
	}

	public function authLinkEdit($sender, $param)
	{
		$item = $param->Item;
		$this->AuthGrid->EditItemIndex = $item->ItemIndex;
		$this->bindAuthGrid();
	}

	public function authLinkUpdate($sender, $param)
	{
		$item = $param->Item;

		list($authid, $manid, $oldLinkType, $oldRelatorCode) = explode('-', $this->AuthGrid->DataKeys[$item->ItemIndex]);
		$oldLink = LAuthorityManifestationPeer::retrieveByPK($authid, $manid, $oldLinkType, $oldRelatorCode);

		if ($oldLink instanceof LAuthorityManifestation) {
			$newRelatorCode = $item->RelatorCodeAndNote->EditRelatorCode->getSelectedValue();
			$relatorCodeChangedFlag = ($newRelatorCode != $oldRelatorCode);

			$newLinkType = $item->AuthLinkTypeColumn->LinkTypeDropdownList->getSelectedValue();
			$linkTypeChangedFlag = ($newLinkType != $oldLinkType);

			$newNote = trim($item->RelatorCodeAndNote->EditLinkNote->getText());
			$oldNote = $oldLink->getLinkNote();
			$noteChangedFlag = ($newNote != $oldNote);

			if ($relatorCodeChangedFlag
				|| $linkTypeChangedFlag
				|| $noteChangedFlag) {
				$newLink = new LAuthorityManifestation();
				$newLink->setAuthorityId($authid);
				$newLink->setManifestationId($manid);

				$newLink->setRelatorCode($relatorCodeChangedFlag ? $newRelatorCode : $oldRelatorCode);
				$newLink->setLinkType($linkTypeChangedFlag ? $newLinkType : $oldLinkType);
				$newLink->setLinkNote($noteChangedFlag ? $newNote : $oldNote);
				$newLink->setLinkSequence($oldLink->getLinkSequence());

				try {
					$oldLink->delete();
					$newLink->save();

					$linkedAuth = $newLink->getAuthority();

					if (($linkedAuth->getBidSource() == 'SBN')
						&& $linkedAuth->getBid())
						$this->SBNActions->updateLinkToSBN('Update', $newLink);

					$manId = $this->_manifestation->getManifestationId();
					$manifestationTitle = $this->_manifestation->getTrimmedTitle(80, '');

					ChangelogPeer::logAction($manifestation,
						ChangelogPeer::LOG_UPDATE,
						$this->getUser(),
						'Modificato legame fra notizia (id = ' . $manid . ', titolo = ' . $manifestationTitle
						. ') e authority (id = ' . $authid . ')');

					$this->writeMessage(Prado::localize("Modificato legame fra la notizia (id = {manid}, titolo = '{manifestationTitle}') e l'authority (id = {authid})",
						array('manid' => $manid,
							'manifestationTitle' => $manifestationTitle,
							'authid' => $authid)),
						ClavisMessage::CONFIRM);
				} catch (Exception $e) {
					$this->writeMessage(Prado::localize('Modifica authority collegata fallita: ') . " " . $e,
						ClavisMessage::ERROR);
				}
			}
		} else {
			$this->writeMessage(Prado::localize("Errore su tentativo di modifica dell'authority collegata: non esiste più il record corrispondente alla chiave '{key}'. Riportare al fornitore del software",
				array('key' => $this->AuthGrid->DataKeys[$item->ItemIndex])),
				ClavisMessage::ERROR);
		}

		$this->AuthGrid->EditItemIndex = -1;
		$this->bindAuthGrid();
	}

	public function authLinkCancel($sender, $param)
	{
		$this->AuthGrid->EditItemIndex = -1;
		$this->bindAuthGrid();
	}

	public function authLinkDelete($sender, $param)
	{
		$dataKey = $param->getCommandParameter();

		if (!is_string($dataKey)
			|| is_null($dataKey)) {
			$this->writeMessage(Prado::localize("Errore nel passaggio parametri durante la cancellazione del legame notizia-authority. Riportare al fornitore del software",
				ClavisMessage::ERROR));

			return;
		}

		list($authid, $manid, $lt, $rc) = explode('-', $dataKey);
		$link = LAuthorityManifestationPeer::retrieveByPK($authid, $manid, $lt, $rc);

		if ($link instanceof LAuthorityManifestation) {
			$linkedAuth = $link->getAuthority();
			$manifestation = $link->getManifestation();

			$link->delete();

			$manifestationTitle = $manifestation instanceof Manifestation
				? $manifestation->getTrimmedTitle(80, '')
				: Prado::localize('(notizia [{manid}] non valida!)', array('manid' => $manid));

			ChangelogPeer::logAction($manifestation,
				ChangelogPeer::LOG_DELETE,
				$this->getUser(),
				'Cancellato legame fra notizia (id = ' . $manid . ', titolo = ' . $manifestationTitle
				. ') e authority (id = ' . $authid . ')');

			$this->writeMessage(Prado::localize("Cancellato legame fra la notizia (id = {manId}, titolo = '{manifestationTitle}') e l'authority (id = {authId})",
				array('manId' => $manid,
					'manifestationTitle' => $manifestationTitle,
					'authId' => $authid)),
				ClavisMessage::CONFIRM);

			$this->cleanManifestation();
			$this->bindAuthGrid();
			$this->populateLinkDropDown();
		} else {
			$this->writeMessage(Prado::localize("Errore durante la cancellazione del legame notizia-authority. Riportare al fornitore del software",
				ClavisMessage::ERROR));

			return;
		}
	}

	public function authLinkCommand($sender, $param)
	{
		$item = $param->getItem();
		switch ($param->getCommandName()) {
			case 'sbnLinkCreate':
				list($authid, $manid, $lt, $rc) = explode('-', $this->AuthGrid->DataKeys[$param->Item->ItemIndex]);
				$link = LAuthorityManifestationPeer::retrieveByPK($authid, $manid, $lt, $rc);

				if ($link instanceof LAuthorityManifestation) {
					if ($link->getAuthority()->getBidSource() == 'SBN' && $link->getAuthority()->getBid())
						$this->SBNActions->updateLinkToSBN('Create', $link);
				}

				break;

			case 'sbnLinkDelete':
				list($authid, $manid, $lt, $rc) = explode('-', $this->AuthGrid->DataKeys[$param->Item->ItemIndex]);
				$link = LAuthorityManifestationPeer::retrieveByPK($authid, $manid, $lt, $rc);

				if ($link instanceof LAuthorityManifestation) {
					if (($link->getAuthority()->getBidSource() == 'SBN')
						&& $link->getAuthority()->getBid())
						$this->SBNActions->updateLinkToSBN('Delete', $link);
				}

				break;
		}

		$this->bindAuthGrid();
	}

	public function bibLevelChange($sender, $param)
	{
		if ($this->_sbnMod->getEnabled()
			&& !$this->SBNActions->isUnlinkable()) {
			$this->SBNNatureWarning->setVisible(true);
		} else {
			$this->SBNNatureWarning->setVisible(false);
		}
	}

	public function getDataClass()
	{
		return $this->DataClass->SelectedValue;
	}

	public function dataClassChange($sender, $param)
	{
		$man = $this->getManifestation();
		$tm = $man->getTurboMarc();
		$l = $tm->getLeader();
		$l->entitytype = $this->DataClass->getSelectedValue();
		$tm->setLeader($l);
		$this->_manifestation->setUnimarc($tm->asXML());

		switch ($this->DataClass->SelectedValue) {
			case " ":
				$this->BibLevel->setDBClass("LIVBIBL");
				$this->BibLevel->populate();
				$this->DateType->setDBClass("DATETYPE");
				$this->DateType->populate();
				$this->BibLevelLabel->setText(Prado::localize("livello bibliografico"));
				$this->Tit200Label->setText(Prado::localize("Titolo e formulazione di responsabilità"));
				$this->Add200c->setText(Prado::localize("Aggiungi titolo proprio di altro autore"));
				$this->Pub210Label->setText(Prado::localize("Pubblicazione"));
				$this->Phy215Label->setText(Prado::localize("Descrizione fisica"));

				$this->getClientScript()->registerEndScript("archoff", "
                [].forEach.call(document.getElementsByClassName('archhide'), function (el) {el.style.display='';});
                ");
				$this->getClientScript()->registerStyleSheet("archoff", ".archhide { }");
				break;
			case "a":
				$this->BibLevel->setDBClass("LIVBIBLARCH");
				$this->BibLevel->populate();
				$this->DateType->setDBClass("DATETYPEARCH");
				$this->DateType->populate();
				$this->BibLevelLabel->setText(Prado::localize("livello descrizione"));

				$this->Tit200Label->setText(Prado::localize("Titolo"));
				$this->Add200c->setText(Prado::localize("Aggiungi altro titolo"));
				$this->Pub210Label->setText(Prado::localize("Data e produzione"));
				$this->Phy215Label->setText(Prado::localize("Consistenza"));

				$this->getClientScript()->registerEndScript("archoff", "
                [].forEach.call(document.getElementsByClassName('archhide'), function (el) {el.style.display='none';});
                ");
				$this->getClientScript()->registerStyleSheet("archoff", ".archhide {display: none;}");

				break;

			case "m":
				$this->BibLevel->setDBClass("LIVBIBLMUS");
				$this->BibLevel->populate();
				$this->DateType->setDBClass("DATETYPEARCH");
				$this->DateType->populate();
				$this->BibLevelLabel->setText(Prado::localize("livello descrizione"));

				$this->F101Ind1->setVisible(false);

				$this->Tit200Label->setText(Prado::localize("Titolo e contributi"));
				$this->Add200c->setText(Prado::localize("Aggiungi altro titolo"));
				$this->Pub210Label->setText(Prado::localize("Data e produzione"));
				$this->Phy215Label->setText(Prado::localize("Descrizione fisica"));

				$this->getClientScript()->registerEndScript("archoff", "
                [].forEach.call(document.getElementsByClassName('archhide'), function (el) {el.style.display='none';});
                ");
				$this->getClientScript()->registerEndScript("musoff", "
                [].forEach.call(document.getElementsByClassName('mushide'), function (el) {el.style.display='none';});
                ");
				$this->getClientScript()->registerStyleSheet("archoff", ".archhide {display: none;}");
				$this->getClientScript()->registerStyleSheet("musoff", ".mushide {display: none;}");
		}
		//$this->populateUnimarc();

	}

	public function objFirstChange($sender, $param)
	{
		$firstValue = $sender->getSelectedValue();
		if ($firstValue) {
			$this->BibObj->setVisible(true);
			$this->BibObj->setDBClass('OGGBIBL_' . $firstValue);
			$this->BibObj->populateList();
			$this->MyTabPanel->setActiveViewIndex(0);
		} else {
			$this->BibObj->setVisible(false);
		}
	}

	public function bindNumberSubfields($sender, $param)
	{
		$item = $param->Item;
		if (($item->ItemType === 'Item')
			|| ($item->ItemType === 'AlternatingItem')) {
			$idx = 0;
			$ds = array();

			foreach ($item->Data['subfields'] as $k => $v) {
				$ds[] = array('index' => ++$idx,
					'tag' => $k,
					'taglabel' => $this->numberFieldLabels[$item->Data['field']]['subfields'][$k]['label'],
					'maxlength' => $this->numberFieldLabels[$item->Data['field']]['subfields'][$k]['maxlength'],
					'value' => $v);
			}

			$item->NumberSubfields->setDataSource($ds);
			$item->NumberSubfields->dataBind();
		}
	}

	public function addNumber($sender, $param)
	{
		$ds = array();

		foreach ($this->RepNumbers->Items as $item) {
			$num = array();
			$fld = $item->Field->getValue();

			if ('071' == $fld)
				$num['i1'] = $item->i1->getSelectedValue();

			if ('017' == $fld)
				$num['s2'] = $item->s2->getSelectedValue();

			$num['field'] = $fld;
			$num['fieldlabel'] = $this->numberFieldLabels[$fld]['label'];
			$num['subfields'] = array();

			foreach ($item->NumberSubfields->Items as $sfitem)
				$num['subfields'][$sfitem->Subfield->getValue()] = $sfitem->Value->getText();

			$ds[] = $num;
		}

		$newfield = $this->NewNumberList->getSelectedValue();
		$num = array('field' => $newfield,
			'fieldlabel' => $this->numberFieldLabels[$newfield]['label']);

		$num['subfields'] = array();

		foreach (array_keys($this->numberFieldLabels[$newfield]['subfields']) as $sftag)
			$num['subfields'][$sftag] = '';

		if ('017' == $newfield)
			$num['i1'] = '';

		$ds[] = $num;
		$this->RepNumbers->setDataSource($ds);
		$this->RepNumbers->dataBind();
	}

	public function add856($sender, $param)
	{
		$ds = array();

		foreach ($this->Rep856->Items as $item) {
			$url = trim($item->u->getText());

			if ($url)
				$ds[] = array('field' => '856',
					'ind' => $item->ind->getValue(),
					'u' => $url,
					'z' => $item->z->getText());
		}

		$newind = $this->New856List->getSelectedValue();

		$ds[] = array('field' => '856',
			'ind' => $newind,
			'u' => '',
			'z' => '');

		$this->Rep856->setDataSource($ds);
		$this->Rep856->dataBind();
	}

	public function onClickAdd200c($sender, $param)
	{
		$ds = array();

		foreach ($this->RepF200c->Items as $item) {
			$value = $item->F200c->getText();

			if (trim($value) != '')
				$ds[] = array(
					'Text' => $value,
					'Label' => ($this->DataClass->SelectedValue == ' ') ? Prado::localize("Titolo proprio di altro autore") :
						Prado::localize("Altro titolo"));
		}

		$ds[] = array(
			'Text' => '',
			'Label' => ($this->DataClass->SelectedValue == ' ') ? Prado::localize("Titolo proprio di altro autore") :
				Prado::localize("Altro titolo"));
		$this->RepF200c->setDataSource($ds);
		$this->RepF200c->dataBind();
	}

	public function onClickAdd205($sender, $param)
	{
		$ds = array();

		foreach ($this->RepF205->Items as $item) {
			$value = $item->F205->getText();

			if (trim($value) != '')
				$ds[] = array('txt' => $value);
		}

		$ds[] = array('txt' => '');
		$this->RepF205->setDataSource($ds);
		$this->RepF205->dataBind();
	}

	public function onClickAdd2XX($sender, $param)
	{
		$ds = array();

		foreach ($this->RepF2XX->Items as $item) {
			$value = $item->F2XXValue->getText();

			if (trim($value) != '')

				$ds[] = array('value' => $value,
					'field' => $item->F2XXField->getSelectedValue());
		}

		$ds[] = array('value' => '',
			'field' => null);

		$this->RepF2XX->setDataSource($ds);
		$this->RepF2XX->dataBind();
	}

	public function onClickAdd210($sender, $param)
	{
		$ds = array();

		foreach ($this->RepF210->Items as $item) {
			$value = $item->F210Value->getText();

			if (trim($value) != '')
				$ds[] = array('txt' => $value,
					'ind' => $item->F210Field->getSelectedValue());
		}

		$ds[] = array('txt' => '',
			'ind' => '  ');

		$this->RepF210->setDataSource($ds);
		$this->RepF210->dataBind();
	}

	public function onClickAdd215($sender, $param)
	{
		$ds = array();

		foreach ($this->RepF215->Items as $item) {
			$value = $item->F215->getText();

			if (trim($value) != '')
				$ds[] = array('txt' => $value);
		}

		$ds[] = array('txt' => '');
		$this->RepF215->setDataSource($ds);
		$this->RepF215->dataBind();
	}

	public function onClickAdd225($sender, $param)
	{
		$ds = array();

		foreach ($this->RepF225->Items as $item) {
			$value = $item->F225a->getText();

			if (trim($value) != '')
				$ds[] = array('desc' => $value,
					'num' => $item->F225v->getText());
		}

		$ds[] = array('desc' => '',
			'num' => '');

		$this->RepF225->setDataSource($ds);
		$this->RepF225->dataBind();
	}

	public function addCDF($sender, $param)
	{
		$ds = array();

		foreach ($this->CDFRepeater->Items as $item) {
			$value = $item->F200c->getText();

			if (trim($value) != '')
				$ds[] = array('Text' => $value);
		}

		$ds[] = array('Text' => '');
		$this->RepF200c->setDataSource($ds);
		$this->RepF200c->dataBind();
	}

	public function addNote($sender, $param)
	{
		$ds = array();

		foreach ($this->RepF3XX->Items as $item) {
			$ds[] = array('NoteNumber' => $item->F3XXField->getSelectedValue(),
				'NoteValue' => $item->F3XXValue->getText());
		}

		$ds[] = array('NoteNumber' => 300,
			'NoteValue' => '');

		$this->RepF3XX->setDataSource($ds);
		$this->RepF3XX->dataBind();
		$this->refreshISBD();
	}

	public function addTitle($sender, $param)
	{
		$ds = array();

		foreach ($this->RepF5XX->Items as $item) {
			$value = $item->F5XXValue->getText();
			$bid = $item->F5XXBid->getValue();

			if (trim($value) != '')
				$ds[] = array('field' => $item->F5XXField->getSelectedValue(),
					'value' => $value,
					'bid' => $bid);
		}

		$ds[] = array('field' => 517,
			'value' => '',
			'bid' => '');

		$this->RepF5XX->setDataSource($ds);
		$this->RepF5XX->dataBind();
		$this->refreshISBD();
	}

	public function validateBibLevel($sender, $param)
	{
		if ($this->_manifestation->getBibLevel() == $param->getValue())
			return;

		$this->_manifestation->setBibLevel($param->getValue());

		if ((($this->_manifestation->getBibLevel() != ManifestationPeer::LVL_SERIAL) && $this->_manifestation->countItems())
			&& !$this->_manifestation->canHaveItems()) {
			$param->IsValid = false;
			$this->_manifestation->reload();
		}
	}

	public function validateManLink461($sender, $param)
	{
		if ((461 == $param->getValue())
			&& ($this->_manifestation->getBibLevel() != ManifestationPeer::LVL_ANALYTIC)) {
			$manDown = ManifestationQuery::create()->findPk($this->RecordResultValue->getValue());

			if ($manDown instanceof Manifestation
				&& (($manDown->getBibLevel() != ManifestationPeer::LVL_SERIAL)
					&& $manDown->countItems())) {
				$param->IsValid = false;

				return;
			}
		}

		$param->IsValid = true;

		return;
	}

	public function validateManLink463($sender, $param)
	{
		if ((463 == $param->getValue())
			&& ($this->_manifestation->getBibLevel() != ManifestationPeer::LVL_SERIAL)
			&& $this->_manifestation->countItems()) {
			$param->IsValid = false;

			return;
		}

		$param->IsValid = true;

		return;
	}

	public function onSave($sender, $param)
	{
		$this->refreshISBD();

		if ($this->getIsValid()) {
			$this->saveRecord();

			$this->gotoPage('Catalog.Record',
				array('manifestationId' => $this->_manifestation->getManifestationId()));
		}
	}

	public function onSaveAndReturn($sender, $param)
	{
		$this->refreshISBD();

		if ($this->getIsValid()) {
			$this->saveRecord();

			//$lastElement = clavisbase::readEditObjectStack();
			$secondElement = ClavisBase::readSecondEditObjectStack();

			if ((ClavisBase::isReturnableObjectStack(ClavisBase::EDITOBJECTSSTACK_TYPEMANIFESTATION,
					$this->getManifestationId()))
				&& (ClavisBase::isValidElementObjectStack($secondElement))) {
				if ($secondElement[0] == ClavisBase::EDITOBJECTSSTACK_TYPEMANIFESTATION)    // manifestation
				{
					$this->gotoPage('Catalog.EditRecord',
						array('manifestationId' => $secondElement[1]
							//'selectTab' => 'TabAuthority' ));
						));
				} else if ($secondElement[0] == ClavisBase::EDITOBJECTSSTACK_TYPEAUTHORITY)    // authority
				{
					$this->gotoPage('Catalog.AuthorityEditPage',
						array('id' => $secondElement[1]
							/////***** todo autoselect in AuthorityEditPage
							//'selectTab' => 'TabAuthority' ));
						));
				}
			} else {
				$this->writeDelayedMessage(Prado::localize("Non è possibile tornare indietro all'oggetto per il collegamento"),
					ClavisMessage::ERROR);

				$this->gotoPage('Catalog.Record',
					array('manifestationId' => $this->_manifestation->getManifestationId()));
			}
		}
	}

	public function saveAndEdit($sender, $param)
	{
		$this->refreshISBD();

		if ($this->getIsValid()) {
			$this->saveRecord();
			$this->populate();
		}
	}

	public function OnF5xxDataBound($sender, $param)
	{
		$item = $param->Item;
		$item->F5XXField->populateList();
		$item->F5XXField->setVisible($this->getDataClass() != 'm');
		$item->F5XXField->setSelectedValue($item->DataItem['field']);
	}

	public function OnF3xxDataBound($sender, $param)
	{
		$item = $param->Item;
		if ($this->getDataClass() == 'm')
			$item->F3XXField->setDBClass("UNI3XXMUS");
		$item->F3XXField->populateList();
		$item->F3XXField->setSelectedValue($item->DataItem['NoteNumber']);
	}

	public function onChooseManifestation($sender, $param)
	{

	}

	public function onNote3XXSelected($sender, $param)
	{
		$sbnNotes = array(
			"922" => "<[a] Genere di rappresentazione (M8D1, Tab GENR, valori ammessi (1 car.): Rappresentazione = 1; Prima rappresentazione = 2; Registrazione = 3 ; Registrazione dal vivo = 4 ; Rimasterizzazione = 5 ; Non specificato = 0)>
:
<[p] Anno di rappresentazione (M8D2, 4 caratteri>
:
<[q] Periodo di rappresentazione (M8D3>
:
<[r] Teatro di rappresentazione (M8D5)>
:
<[s] Luogo di rappresentazione (M8D4)>
:
<[t] Nota alla rappresentazione (M8D7)>
:
<[u] Occasione di rappresentazione (M8D6)>
:",
			"923" => "<[b] Codice stesura (Tab STES, valori ammessi (1 car.): Autografo = A; Autografo incerto = B; Autografo in parte = C; Copia = D; Copia di vari copisti = E)>
:
<[c] Indicatore di composito (Valori ammessi (1 car.): S = SI; N = NO>
:
<[d] Indicatore di palinsensto (Valori ammessi (1 car.): S = SI; N = NO>
:
<[e] Datazione (max 10 car.(es.: 1787-08-10)>
:
<[g] Codice materia (Tab MAMU, valori ammessi (campo ripetibile, max 2 car.): Misto = X;  altro = Z; Pellicola = G; Lucido = F; Pergamena = E; Pasta di legno = D; Carta di riso = C; Cartaceo = B; Carta = A>
:
<[h] Illustrazioni>
:
<[i] Notazione musicale>
:
<[l] Legatura (per manoscritti)>
:
<[m] Conservazione (per manoscritti)>
:",
			"926" => "<[a] Indicatore dell'incipit (valori ammessi: Posteriore = P; Successivo = S;>
:
<[b] Numero di composizione (M8F1) (max 2 num.)>
:
<[c] Contesto musicale (M8F12)>
:
<[f] Numero di movimento (M8F2) (max 2 num.)>
:
<[g] Numero progressivo nel movimento (M8F3) (max 2 num.)>
:
<[h] Voce/strumento (registro musicale) (M8F5) (max 9 car.)>
:
<[i] Codice forma musicale (Tab FOMU, M8F6) (max 4 car.)>
:
<[l] Tonalità (Tab TONO, M8F8) (max 2 car.)>
:
<[m] Chiave musicale (M8F9) (max 3 car.)>
:
<[n] Alterazioni (M8F10)>
:
<[o] Misura (M8F11)>
:
<[p] Tempo musicale>
:
<[q] Nome del personaggio (M8F4)>
:
<[q] BID del titolo di incipit letterario (max 33 car.)>
:",
			"927" => "<[a] Personaggio (M8E1)>
:
<[b] Voce o strumento (M8E2)>
:
<[3] VID dell'Interprete (M8E3) (max 33 car.)>
:");

		$fld = $sender->getSelectedValue();

		if ($fld > 900) {
			$sender->getParent()->F3XXValue->setText($sbnNotes[$fld]);
		}
	}

	public function recLinkEdit($sender, $param)
	{
		$this->ManGrid->EditItemIndex = $param->Item->ItemIndex;
		$this->bindManGrid();
	}

	public function recLinkUpdate($sender, $param)
	{
		$item = $param->Item;
		$primaryKeys = explode('-', $this->ManGrid->DataKeys[$item->ItemIndex]);
		$link = LManifestationQuery::create()->findPK($primaryKeys);

		if ($link instanceof LManifestation) {
			$link->setLinkSequence($item->recLinkSeqColumn->TextBox->getText());
			$link->setLinkNote($item->recLinkNoteColumn->TextBox->getText());
			$link->setLinkType($item->ManLinkTypeColumn->ManLinkTypeDropdownList->getSelectedValue());

			try {
				$link->save();

				$manId1 = $this->_manifestation->getManifestationId();
				$manifestationTitle1 = $this->_manifestation->getTrimmedTitle(80, '');

				$manifestationRelated = ($link->getManifestationIdUp() == $manId1
					? $link->getManifestationRelatedByManifestationIdDown()
					: $link->getManifestationRelatedByManifestationIdUp());

				$manid2 = $manifestationRelated->getManifestationId();
				$manifestationTitle2 = $manifestationRelated->getTrimmedTitle(80, '');

				ChangelogPeer::logAction($manifestation,
					ChangelogPeer::LOG_UPDATE,
					$this->getUser(),
					'Modificato legame fra notizia (id = ' . $manid1 . ', titolo = \'' . $manifestationTitle1 . '\')'
					. ' e notizia (id = ' . $manid2 . ', titolo = \'' . $manifestationTitle2 . '\')');

				$this->writeMessage(Prado::localize("Modificato legame fra la notizia (id = {manid1}, titolo = '{manifestationTitle1}') e la notizia (id = {manid2}, titolo = '{manifestationTitle2}')",
					array('manid1' => $manid,
						'manifestationTitle1' => $manifestationTitle,
						'manid2' => $manid2,
						'manifestationTitle2' => $manifestationTitle2)),
					ClavisMessage::CONFIRM);
			} catch (Exception $e) {
				$this->writeMessage(Prado::localize('Impossibile aggiornare il legame ad altra notizia'),
					ClavisMessage::ERROR);
			}
		} else {
			$this->writeMessage(Prado::localize("Errore su tentativo di modifica della notizia collegata: non esiste più il record corrispondente alla chiave '{key}'. Riportare al fornitore del software",
				array('key' => $this->AuthGrid->DataKeys[$item->ItemIndex])),
				ClavisMessage::ERROR);
		}

		$this->ManGrid->EditItemIndex = -1;
		$this->bindManGrid();
	}

	public function recLinkCancel($sender, $param)
	{
		$this->ManGrid->EditItemIndex = -1;
		$this->bindManGrid();
	}

	public function recLinkCommand($sender, $param)
	{
		$item = $param->getItem();

		switch ($param->getCommandName()) {
			case 'sbnLinkCreate':
				$link = LManifestationQuery::create()->findPK(explode('-', $this->ManGrid->DataKeys[$item->ItemIndex]));

				if ($link instanceof LManifestation) {
					if (($link->getManifestationRelatedByManifestationIdDown()->getBidSource() == 'SBN')
						&& $link->getManifestationRelatedByManifestationIdDown()->getBid()
						&& ($link->getManifestationRelatedByManifestationIdUp()->getBidSource() == 'SBN')
						&& $link->getManifestationRelatedByManifestationIdUp()->getBid()) {
						$this->SBNActions->updateLinkToSBN('Create', $link);
					} else {
						$this->getPage()->writeMessage(Prado::localize('Almeno una delle due notizie non è collegata all\'indice. Impossibile creare il legame.'), ClavisMessage::ERROR);
					}
				}

				break;

			case 'sbnLinkDelete':
				$link = LManifestationQuery::create()->findPK(explode('-', $this->ManGrid->DataKeys[$item->ItemIndex]));

				if ($link instanceof LManifestation) {
					if (($link->getManifestationRelatedByManifestationIdDown()->getBidSource() == 'SBN')
						&& $link->getManifestationRelatedByManifestationIdDown()->getBid()
						&& ($link->getManifestationRelatedByManifestationIdUp()->getBidSource() == 'SBN')
						&& $link->getManifestationRelatedByManifestationIdUp()->getBid())
						$this->SBNActions->updateLinkToSBN('Delete', $link);
				}

				break;
		}

		$this->bindManGrid();
	}

	public function onNewManLink($sender, $param)
	{
		if (!$this->getIsValid())
			return;

		$manDownId = intval($this->RecordResultValue->getValue());

		if ($this->_manifestation->getManifestationId() == $manDownId) {
			$this->writeMessage(Prado::localize('Impossibile legare una notizia con sé stessa'),
				ClavisMessage::ERROR);

			return;
		}

		$lman = new LManifestation();
		$lman->setManifestationIdUp($this->_manifestation->getManifestationId());
		$lman->setManifestationIdDown($manDownId);
		$lman->setLinkNote($this->ManLinkNote->getSafeText());
		$lman->setLinkType($this->ManLinkType->getSelectedValue());
		$lman->setLinkSequence($this->ManLinkSequence->getText());

		if ($issue_id = intval($this->IssueResultValue->getValue())) {
			$lman->setIssueId($issue_id);
			$log_add = ' / issue_id = ' . $issue_id;
		} else {
			$log_add = '';
		}

		try {
			$lman->save();
		} catch (PropelException $pe) {
			$this->writeMessage(Prado::localize('Impossibile legare le due notizie: esiste già un legame'),
				ClavisMessage::ERROR);

			return;
		}

		$manId1 = $this->_manifestation->getManifestationId();
		$manifestationTitle1 = $this->_manifestation->getTrimmedTitle(80, '');

		$manifestationRelated = ($lman->getManifestationIdUp() == $manId1
			? $lman->getManifestationRelatedByManifestationIdDown()
			: $lman->getManifestationRelatedByManifestationIdUp());

		$manid2 = $manifestationRelated->getManifestationId();
		$manifestationTitle2 = $manifestationRelated->getTrimmedTitle(80, '');

		ChangelogPeer::logAction($this->_manifestation,
			ChangelogPeer::LOG_CREATE,
			$this->getUser(),
			'Creato nuovo legame fra la notizia (id = ' . $manid1 . $log_add . ', titolo = \'' . $manifestationTitle1 . '\')'
			. ' e la notizia (id = ' . $manid2 . ', titolo = \'' . $manifestationTitle2 . '\')');

		$this->writeMessage(Prado::localize("Creato nuovo legame fra la notizia (id = {manid1}{logadd}, titolo = '{manifestationTitle1}') e la notizia (id = {manid2}, titolo = '{manifestationTitle2}')",
			array('manid1' => $manid,
				'logadd' => $log_add,
				'manifestationTitle1' => $manifestationTitle,
				'manid2' => $manid2,
				'manifestationTitle2' => $manifestationTitle2)),
			ClavisMessage::CONFIRM);

		// if linktype is 461 or 463, save manifestations to recalculate hierarchical level
		if (($lman->getLinkType() == 461)
			|| ($lman->getLinkType() == 463)) {
			$lman->getManifestationRelatedByManifestationIdDown()->save();
			$this->_manifestation->save();
		} else {
			$mann = $lman->getManifestationRelatedByManifestationIdDown();

			if ($mann instanceof Manifestation)
				$mann->invalidateCache();

			$mann = $lman->getManifestationRelatedByManifestationIdUp();

			if ($mann instanceof Manifestation)
				$mann->invalidateCache();
		}

		$this->ManLinkType->setSelectedIndex(-1);
		$this->ManLinkNote->setText('');
		$this->ManLinkSequence->setText('');
		$this->RecordResultValue->setValue('');
		$this->RecordResultLabel->setText('');
		$this->IssueResultValue->setValue('');
		$this->IssueResultLabel->setText('');
		$this->LinkedIssueSelect->setCssClass('panel_off');

		$this->bindManGrid();
	}

	public function onDeleteRecLink($sender, $param)
	{
		$linkedman = null;
		$lman = LManifestationQuery::create()->findPK(explode('-', $param->getCommandParameter()));

		if ($lman instanceof LManifestation) {
			$linkedman = ($lman->getManifestationIdDown() == $this->_manifestation->getManifestationId()
				? $lman->getManifestationRelatedByManifestationIdUp()
				: $lman->getManifestationRelatedByManifestationIdDown());

			$lman->delete();
		} else {
			$this->writeMessage(Prado::localize("Errore durante la cancellazione del legame notizia-notizia. Riportare al fornitore del software"),
				ClavisMessage::ERROR);

			return;
		}

		if ($linkedman instanceof Manifestation) {
			$manId1 = $this->_manifestation->getManifestationId();
			$manifestationTitle1 = $this->_manifestation->getTrimmedTitle(80, '');
			$manId2 = $linkedman->getManifestationId();
			$manifestationTitle2 = $linkedman->getTrimmedTitle(80, '');

			ChangelogPeer::logAction($this->_manifestation,
				ChangelogPeer::LOG_DELETE,
				$this->getUser(),
				'Cancellato legame fra notizia (id = ' . $manId1 . ', titolo = ' . $manifestationTitle1
				. ') e notizia (id = ' . $manId2 . ', titolo = ' . $manifestationTitle2 . ')');

			$this->writeMessage(Prado::localize("Cancellato legame fra la notizia (id = {manId1}, titolo = '{manifestationTitle1}') e la notizia (id = {manId2}, titolo = '{manifestationTitle2}')",
				array('manId1' => $manId1,
					'manifestationTitle1' => $manifestationTitle1,
					'manId2' => $manId2,
					'manifestationTitle2' => $manifestationTitle2)),
				ClavisMessage::CONFIRM);

			$linkedman->invalidateCache();
			$this->_manifestation->invalidateCache();

			$this->ManLinkNote->setText('');
			$this->RecordResultValue->setValue('');
			$this->RecordResultLabel->setText('');
			$this->bindManGrid();
		} else {
			$this->writeMessage(Prado::localize("Errore durante la cancellazione del legame notizia-notizia. Riportare al fornitore del software"),
				ClavisMessage::ERROR);

			return;
		}
	}

	/**
	 * Exits the editing of an item, without doing anything.
	 *
	 * @param TControl        $sender
	 * @param TEventParameter $param
	 */
	public function onCancel($sender, $param)
	{
		$manifestation = $this->getManifestation();

		if (!is_null($manifestation)) {
			$manifestationId = $manifestation->getManifestationId();
		} else {
			$manifestationId = 0;
		}

		if ($manifestationId > 0) {
			$this->gotoPage('Catalog.Record', array('manifestationId' => $manifestationId));
		} else {
			$this->gotoPage('Catalog.Record');
		}
	}

	public function AddLanguage($sender, $param)
	{
		$newDatasource = array();

		foreach ($this->RepF101->Items as $item) {
			$tag = $item->F101Tag->getSelectedValue();
			$value = $item->F101Value->getSelectedValue();

			$newDatasource[] = array('LangCode' => $value,
				'LangTag' => $tag);
		}

		$newDatasource[] = array('LangCode' => 'ita',
			'LangTag' => 'a');

		$this->RepF101->setDataSource($newDatasource);
		$this->RepF101->dataBind();
	}

	public function DeleteLanguage($sender, $param)
	{
		$index = $param->getCommandParameter();
		$newDatasource = array();

		foreach ($this->RepF101->Items as $item) {
			if ($item->ItemIndex == $index)
				continue;

			$tag = $item->F101Tag->getSelectedValue();
			$value = $item->F101Value->getSelectedValue();
			$newDatasource[] = array('LangCode' => $value,
				'LangTag' => $tag);
		}

		$this->RepF101->setDataSource($newDatasource);
		$this->RepF101->dataBind();
	}

	public function onRepF101DataBound($sender, $param)
	{
		$item = $param->Item;
		if ($this->getDataClass() == 'm')
			$item->F101Tag->setVisible(false);
		else
			$item->F101Tag->setVisible(true);

		$item->F101Tag->setDataSource($this->f101labels);
		$item->F101Tag->dataBind();
		$item->F101Tag->setSelectedValue($item->DataItem['LangTag']);
		$item->F101Value->populate();
		$item->F101Value->setSelectedValue($item->DataItem['LangCode']);
	}

	public function onUnlinkBid($sender, $param)
	{
		if ($this->getIsValid()) {
			$this->_manifestation->setBidSource(null);
			$this->_manifestation->setBid(null);
			$tm = $this->_manifestation->getTurboMarc();

			if (isset($tm->d099))
				unset($tm->d099);

			$this->_manifestation->setUnimarc($tm->asXML());
			$this->_manifestation->save();
			$this->Bid->setText('');
			$this->BidSource->setText('');
			$this->SBNActions->populate();

			$this->writeMessage(Prado::localize('Dati sorgente correttamente eliminati'),
				ClavisMessage::CONFIRM);
		}
	}

	public function checkSBNLink($sender, $param)
	{
		if (!$this->_sbnMod->getEnabled()
			|| ($this->_manifestation->getBidSource() != 'SBN')) {
			$param->IsValid = true;
		} else if (!$this->SBNActions->isUnlinkable()) {
			$param->IsValid = false;
		} else {
			// check items
			$ic = ItemQuery::create()
				->filterByManifestation($this->_manifestation)
				->filterByLastSbnSync(null, Criteria::NOT_EQUAL)
				->count();

			$param->IsValid = ($ic == 0);
		}
	}

	public function onGotoStackedManifestation($sender, $param)
	{
		$manifestationId = intval($this->getManifestationId());

		$this->refreshISBD();

		if ($this->getIsValid()) {
			$this->saveRecord();
		} else {
			$this->writeMessage(Prado::localize('Non è possibile creare una nuova notizia da collegare in quanto sono presenti errori di salvataggio della notizia corrente'),
				ClavisMessage::ERROR);

			return false;
		}

		if (($manifestationId > 0)) {
			$newManifestationId = $this->doCreateNewManifestation(trim($this->RecordResultLabel->getSafeText()));

			if ($newManifestationId > 0) {
				if (ClavisBase::isEmptyObjectStack())
					ClavisBase::pushEditObjectStack(Clavisbase::EDITOBJECTSSTACK_TYPEMANIFESTATION,
						$manifestationId,
						$this->getManifestation()->getTitle()); ///,	$newManifestationId );

				ClavisBase::pushEditObjectStack(Clavisbase::EDITOBJECTSSTACK_TYPEMANIFESTATION,
					$newManifestationId,
					ManifestationQuery::create()->findPk($newManifestationId)->getTitle());

				$this->enqueueMessage(Prado::localize('Modifica della notizia con id={manid} messa in attesa',
					array('manid' => $manifestationId)),
					ClavisMessage::INFO);

				$this->flushDelayedMessage();

				$this->gotoPage('Catalog.EditRecord',
					array('manifestationId' => $newManifestationId)); //,	'selectTab' => 'TabAuthority' ));
			}
		} else {
			$this->writeMessage(Prado::localize('Nuova notizia non creata'),
				ClavisMessage::ERROR);

			return false;
		}
	}

	public function onGotoStackedAuthority($sender, $param)
	{
		$manifestationId = intval($this->getManifestationId());

		$this->refreshISBD();

		if ($this->getIsValid()) {
			$this->saveRecord();
		} else {
			$this->writeMessage(Prado::localize('Non è possibile creare una nuova authority da collegare in quanto sono presenti errori di salvataggio della notizia corrente'),
				ClavisMessage::ERROR);

			return false;
		}

		if (($manifestationId > 0)) {
			//$newManifestationId = $this->doCreateManif();
			$newAuthorityId = $this->doCreateNewAuthority(trim($this->NewAuthLink->getSafeText()));

			if ($newAuthorityId > 0) {
				if (ClavisBase::isEmptyObjectStack())
					ClavisBase::pushEditObjectStack(Clavisbase::EDITOBJECTSSTACK_TYPEMANIFESTATION,
						$manifestationId,
						$this->getManifestation()->getTitle());

				ClavisBase::pushEditObjectStack(Clavisbase::EDITOBJECTSSTACK_TYPEAUTHORITY,
					$newAuthorityId,
					AuthorityQuery::create()->findPk($newAuthorityId)->getCompleteText());

				$this->enqueueMessage(Prado::localize('Modifica della notizia con id={manid} messa in attesa',
					array('manid' => $manifestationId)),
					ClavisMessage::INFO);

				$this->flushDelayedMessage();

				$this->gotoPage('Catalog.AuthorityEditPage',
					array('id' => $newAuthorityId));
			} else {
				$this->writeMessage(Prado::localize('Nuova authority non creata'),
					ClavisMessage::ERROR);

				return false;
			}
		}
	}

	protected function saveRecord()
	{
		$tm = $this->buildUnimarc();
		$this->_manifestation->setUnimarc($tm->asXML());

		$this->_manifestation->syncTitle();
		$this->_manifestation->setEditionDate(intval($this->F100aDate1->getText()));
		$this->_manifestation->setEditionLanguage(isset($tm->d101) ? (string)$tm->d101->children() : '');
		$this->_manifestation->setPublisher(isset($tm->d210) ? (string)$tm->d210->sc : '');
		$this->_manifestation->syncAuthor();
		$this->_manifestation->setBibLevel($this->BibLevel->getSelectedValue());
		$this->_manifestation->setBibTypeFirst($this->BibObjFirst->getSelectedValue());
		$this->_manifestation->setBibType($this->BibObj->getSelectedValue());

		/// START /// the following block updates explicitly the title on linked
		// items and loans (AND HAVE TO BE HERE!)
		// it updates title on lower-level manifestations (463) without significant title
		if ($this->_manifestation->isColumnModified(ManifestationPeer::TITLE)) {
			$base_title = $this->_manifestation->getTitle();
			$dewey = $this->_manifestation->getClass();

			if ($this->_manifestation->getBibLevel() == ManifestationPeer::LVL_SERIAL) {
				foreach ($this->_manifestation->getIssues() as $is) {
					$title = "{$base_title} (fasc: {$is->getIssueCombo(false)})";

					$iq = ItemQuery::create()
						->filterByIssue($is)
						->update(array('ManifestationDewey' => $dewey,
							'Title' => $title));
				}
			} else {
				$iq = ItemQuery::create()
					->filterByManifestation($this->_manifestation)
					->update(array('ManifestationDewey' => $dewey,
						'Title' => $base_title));
			}

			LoanPeer::updateTitle($this->_manifestation);

			$lower = LManifestationQuery::create()
				->condition('up1', 'LManifestation.ManifestationIdUp = ?', $this->_manifestation->getManifestationId())
				->condition('up2', 'LManifestation.LinkType = ?', 463)
				->combine(array('up1', 'up2'), 'and', 'up')
				->condition('down1', 'LManifestation.ManifestationIdDown = ?', $this->_manifestation->getManifestationId())
				->condition('down2', 'LManifestation.LinkType = ?', 461)
				->combine(array('down1', 'down2'), 'and', 'down')
				->where(array('down', 'up'), 'or')
				->find();

			foreach ($lower as $llm) {
				$lmanif = ($llm->getLinkType() == 463) ?
					$llm->getManifestationRelatedByManifestationIdDown() :
					$llm->getManifestationRelatedByManifestationIdUp();

				if ($lmanif instanceof Manifestation) {
					$title = $lmanif->getTurboMarc()->getTitle();
					if ($title['ind'][0] == '0') {
						$lmanif->syncTitle($base_title);
						$lmanif->save();
					}
				}
			}
		}
		/// END /// item/loan title update

		$this->_manifestation->setManifestationStatus(($this->ManStatus->getSelectedValue() == ManifestationPeer::STATUS_IMPORT)
			? ManifestationPeer::STATUS_INCOMPLETE
			: $this->ManStatus->getSelectedValue());

		$this->_manifestation->setCatalogationLevel($this->ManLevel->getSelectedValue());
		$this->_manifestation->setLoanableSince($this->LoanableSince->getTimestamp());
		$this->_manifestation->setRating($this->ManRating->getSelectedValue());

		// call SBN update
		$this->_manifestation->save();
		$this->SBNActions->updateToSBN();
		$this->_manifestation->doIndex();

		ChangelogPeer::logAction($this->_manifestation,
			ChangelogPeer::LOG_UPDATE,
			$this->getUser(),
			'Modificata notizia con id = ' . $this->_manifestation->getManifestationId()
			. ', titolo = ' . $this->_manifestation->getTrimmedTitle(80, ''));

		$url = Prado::getApplication()->getService()->constructUrl('Catalog.Record',
			array('manifestationId' => $this->_manifestation->getManifestationId()));

		$manData = "'<a href='" . $url . "'>" . $this->_manifestation->getCompleteTitle('') . "</a>'";

		$this->getPage()->enqueueMessage(Prado::localize('Notizia salvata: {newman}',
			array('newman' => $manData)),
			ClavisMessage::CONFIRM);
	}

	private function gotoErrorPage($id)
	{
		$this->writeMessage(__CLASS__ . Prado::localize(' La notizia con id = {id} non esiste', array('id' => $id)), ClavisMessage::ERROR);
		$this->gotoPage('Catalog.RecordList');
	}

	private function calculateLinkDropDown($a = null)
	{
		if (!$a instanceof Authority)
			$a = AuthorityQuery::create()->findPk(intval($this->AuthorityID->getValue()));

		$select = null;

		if ((!$a instanceof Authority)
			|| ($a->getAuthorityRectype() == AuthorityPeer::RECTYPE_NODE)) {
			$this->AuthorityID->setValue('');
			$this->NewAuthLink->setText('');
			$fldlist = array(700, 702, 701, 610, 609, 619, 620, 676, 500, 921);
		} else {
			switch ($a->getAuthorityType()) {
				case AuthorityPeer::TYPE_TRADEMARK:
					$fldlist = array(616, 619);
					$select = '616';
					break;

				case AuthorityPeer::TYPE_PUBPLACE:
					$fldlist = array(620, 619);
					$select = '620';
					break;

				case AuthorityPeer::TYPE_CLASS:
					$fldlist = array(676, 619);
					$select = '676';
					break;

				case AuthorityPeer::TYPE_WORK:
					$fldlist = array(500, 619);
					$select = '500';
					break;

				case AuthorityPeer::TYPE_PRINTERSDEVICE:
					$fldlist = array(921, 619);
					$select = '921';
					break;

				case AuthorityPeer::TYPE_PERSONALNAME:
				case AuthorityPeer::TYPE_CORPORATEBODYNAME:
				case AuthorityPeer::TYPE_FAMILYNAME:
					$fldlist = array(700, 702, 701, 610, 609, 619);

					if ($this->getRecordHasMainAuthor())
						$fldlist = array_diff($fldlist, array(700));

					if ($this->getRecordHasAltAuthors())
						$fldlist = array_diff($fldlist, array(701));

					break;

				default:
					$fldlist = array(610, 609, 619);
					break;
			}
		}

		$options = LookupValuePeer::getLookupClassValues('LINKTYPE');
		$ds = array();

		foreach ($fldlist as $fld)
			$ds[$fld] = $options[$fld];

		return array($ds, $select);
	}

	private function calculateManLinkDropDown()
	{
		return LookupValuePeer::getLookupClassValues('UNI4XX');
	}

	/**
	 *
	 * @return TurboMarc
	 */
	private function buildUnimarc()
	{
		$tm = TurboMarc::createRecord();
		$l = new TurboMarcLeader();
		$l->recLen = '01234';
		$l->recstatus = 'n';
		$l->biblevel = $this->BibLevel->getSelectedValue();
		$l->type = substr($this->BibObj->getSelectedValue(), 0, 1);
		$l->entitytype = $this->DataClass->getSelectedValue();

		$tm->setLeader($l);

		$f001 = $tm->setControlField('001', $this->_manifestation->getManifestationId());
		$f005 = $tm->setControlField('005', date('Ymdhms.0'));

		$oldtm = $this->_manifestation->getTurboMarc();

		if (isset($oldtm->d099)) {
			if ($l->type == "e")
				$oldtm->d099->sb = "C";

			if (($l->type == "c")
				|| ($l->type == "d")
				|| ($l->type == "j"))
				$oldtm->d099->sb = "U";

			if ($l->type == "g")
				$oldtm->d099->sb = "M";

			if ($l->type == "l")
				$oldtm->d099->sb = "M";

			if ($l->type == "i")
				$oldtm->d099->sb = "M";

			$tm->appendNode($oldtm->d099);
		}

		if (isset($oldtm->d801))
			$tm->appendNode($oldtm->d801);

		$this->_manifestation->setIsbnissn('');
		$this->_manifestation->setEan('');

		foreach ($this->RepNumbers->Items as $item) {
			$fnum = $item->Field->getValue();
			$fld = array();

			foreach ($item->NumberSubfields->Items as $sfitem) {
				$tag = $sfitem->Subfield->getValue();
				$fld[$tag] = $sfitem->Value->getText();
			}

			if (!implode('', $fld))
				continue;

			$ind1 = $ind2 = ' ';

			if ('011' == $fnum)
				$ind1 = '#';

			if ('017' == $fnum)
				$ind1 = '7';

			if ('071' == $fnum)
				$ind1 = $item->i1->getSelectedValue();

			if (in_array($fnum, array('017', '071', '072', '073')))
				$ind2 = 0;

			$field = $tm->addField($fnum, $ind1, $ind2);

			foreach ($fld as $tag => $value)
				$field->addSubField($tag, $value);

			if ('012' == $fnum)
				$field->addSubField('a', str_pad($fld['s'], 4) . ' '
					. str_pad($fld['t'], 4) . ' '
					. str_pad($fld['u'], 4) . ' '
					. str_pad($fld['v'], 4) . ' '
					. str_pad($fld['w'], 12) . ' '
					. $fld['x']);

			if ('017' == $fnum)
				$field->addSubField('2', $item->s2->getSelectedValue());

			if ($field instanceof TurboMarc) {
				switch ($field->getTag()) {
					case '073':
						$this->_manifestation->setEan((string)$field->sa);
						break;

					case '010':
					case '011':
						$this->_manifestation->setIsbnissn(trim($this->_manifestation->getIsbnissn() . ' ' . (string)$field->sa));
						break;
				}
			}
		}

		$f100 = $tm->addField('100');
		$f100->setCDF('a', 0, $this->F100a0->getValue());
		$f100->setCDF('a', 8, $this->DateType->getSelectedValue());
		$f100->setCDF('a', 9, $this->F100aDate1->getText());
		$f100->setCDF('a', 13, $this->F100aDate2->getText());
		$f100->setCDF('a', 17, $this->F100a17->getValue());
		$f100->setCDF('a', 18, $this->F100a18->getValue());
		$f100->setCDF('a', 19, $this->F100a19->getValue());
		$f100->setCDF('a', 20, $this->F100a20->getValue());
		$f101 = $tm->addField('101', $this->F101Ind1->getSelectedValue());

		foreach ($this->RepF101->Items as $item) {
			$tag = $item->F101Tag->getSelectedValue();
			$value = $item->F101Value->getSelectedValue();
			$f101->addSubField($tag, $value);
		}

		$f102 = $tm->addField('102');
		$f102->addSubField('a', substr($this->F102a->getSelectedValue(), 0, 2));

		/* cdf fields */
		foreach ($this->CDFRepeater->getCDFList() as $cdf) {
			if (isset($cdf['subfields']['0'])) {
				$i1 = substr($cdf['subfields']['0'], 1, 1);
				$i2 = substr($cdf['subfields']['0'], 2, 1);
			} else {
				$i1 = $i2 = ' ';
			}

			$fld = $tm->addField($cdf['fieldnum'], $i1, $i2);

			foreach ($cdf['subfields'] as $tag => $value)
				if ('0' != $tag)
					$fld->addSubField($tag, $value);
		}
		/* end cdf fields */

		$f200a = trim(str_replace('\n', ' ', $this->F200->getText()));
		$f200c = array();
		foreach ($this->RepF200c->Items as $item) {
			$value = trim($item->F200c->getText());

			if ($value != '')
				$f200c[] = $value;
		}

		$standaloneTitle = $this->F200ind->getChecked();
		$tm->setTitle($f200a, $f200c, $standaloneTitle ? '1 ' : '0 ');

		foreach ($this->RepF205->Items as $item) {
			$value = trim($item->F205->getText());

			if ($value != '')
				$tm->setEdition($value);
		}

		foreach ($this->RepF210->Items as $item) {
			$value = trim($item->F210Value->getText());

			if ($value != '')
				$tm->setPublication($value, $item->F210Field->getSelectedValue());
		}

		foreach ($this->RepF215->Items as $item) {
			$value = trim($item->F215->getText());

			if ($value != '')
				$tm->setPhysicalDesc($value);
		}

		foreach ($this->RepF225->Items as $item) {
			$value = trim($item->F225a->getText());

			if ($value != '') {
				if (($v = $item->F225v->getText()) != '')
					$value .= ' ; ' . $v;

				$tm->setSerie($value);
			}
		}

		foreach ($this->RepF2XX->Items as $item) {
			$value = trim($item->F2XXValue->getText());

			if ($value != '')
				$f2xx = $tm->addField($item->F2XXField->getSelectedValue())
					->addSubField('a', $value);
		}

		foreach ($this->RepF3XX->Items as $item) {
			$f3xxNum = $item->F3XXField->getSelectedValue();
			//$f3xxValues = preg_split('(\r\n|\n|\r)', html_entity_decode($item->F3XXValue->getText()));
			$f3xxValues = array(html_entity_decode($item->F3XXValue->getText()));

			foreach ($f3xxValues as $f3xxValue) {
				$f3xxValue = preg_replace('/(\s)+/', '$1', $f3xxValue);

				if ($f3xxValue != '') {
					if ($f3xxNum < 400) {
						$f3xx = $tm->addField($f3xxNum)->addSubField('a', $f3xxValue);
					} else { //Note SBN structured
						$f3xx = $tm->addField($f3xxNum);
						$match = array();
						$tag = "";
						$label = "";

						foreach (explode("\n", $f3xxValue) as $l) {
							if (preg_match("/^<\\[([a-z0-9])\\] (.*)>$/", $l, $match)) {
								$tag = $match[1];
								$label = $match[2];
							} else if (preg_match("/^:(.*)$/", $l, $match)) {
								$sf = $f3xx->addSubField($tag, trim($match[1]));
								$sf['l'] = htmlentities($label, null, 'UTF-8');
								$tag = "";
								$label = "";
							}
						}
					}
				}
			}
		}

		foreach ($this->RepF5XX->Items as $item) {
			$f5xxBid = trim($item->F5XXBid->getValue());
			$f5xxNum = $item->F5XXField->getSelectedValue();
			$f5xxValue = trim(str_replace(array('\n', '\r'), array(' ', ''), $item->F5XXValue->getText()));

			if ($f5xxValue != '') {
				$f5xx = $tm->addField($f5xxNum);
				$f5xx->addSubField('a', $f5xxValue);
				$f5xx->addSubField('sbn', $f5xxBid);
			}
		}

		foreach ($this->Rep856->Items as $item) {
			$url = trim($item->u->getText());

			if ($url) {
				$field = $tm->addField('856', $item->ind->getValue());
				$field->addSubField('u', $url);
				$field->addSubField('z', $item->z->getText());
			}
		}

		return TurboMarcUtility::sortFields($tm);
	}

	private function doCreateNewManifestation($newTitle = "")
	{
		$newManifestationId = null;

		try {
			$newManifestation = new Manifestation();
			$newManifestation->setManifestationStatus(null); //ManifestationPeer::STATUS_COMPLETE);
			$cat_level = '05';

			if ($this->getUser() instanceof ClavisLibrarian)
				$cat_level = $this->getUser()->getLibrarian()->getCatLevel();

			$newManifestation->setCatalogationLevel($cat_level);
			$tm = TurboMarc::createRecord();
			$tm->setLeader(' 1234nam0 2201234   450 ');
			$f101 = $tm->addField('101');
			$f101->addSubField('a', 'ita');

			if ($newTitle == "")
				$newTitle = "Nuova notizia";

			$tm->setTitle($newTitle);
			$newManifestation->setUnimarc($tm->asXML());
			$newManifestation->syncTitle();
			$newManifestation->save();

			ChangelogPeer::logAction($newManifestation,
				ChangelogPeer::LOG_CREATE,
				$this->getUser(),
				'Nuova notizia creata');

			$newManifestationId = $newManifestation->getManifestationId();
			$url = Prado::getApplication()->getService()->constructUrl('Catalog.Record',
				array('manifestationId' => $newManifestationId));

			$newManData = "'<a href='" . $url . "'>" . $newManifestation->getCompleteTitle('') . "</a>'";

			$this->getPage()->enqueueMessage(Prado::localize('Notizia creata: {newman}. Procedere alla catalogazione ...',
				array('newman' => $newManData)),
				ClavisMessage::CONFIRM);
		} catch (Exception $e) {
			Prado::log('Exception: ' . $e->getMessage());

			$this->writeMessage(Prado::localize('Errore durante la creazione di una nuova notizia: ') . $e->getMessage(),
				ClavisMessage::ERROR);
		}

		return $newManifestationId;
	}

	private function doCreateNewAuthority($newTitle = "")
	{
		$newAuthorityId = null;

		try {
			$newAuthority = new Authority();
			$newAuthority->setAuthorityStatus(null);

//			$cat_level = '05';
//			
//			if ($this->getUser() instanceof ClavisLibrarian)
//				$cat_level = $this->getUser()->getLibrarian()->getCatLevel();
//			
			$newAuthority->setAuthorityCodLevel(05);
			$tm = TurboMarc::createRecord();
//			$tm->setLeader(' 1234nam0 2201234   450 ');
			$f101 = $tm->addField('101');
			$f101->addSubField('a', 'ita');
			///////////////////$tm->setTitle(Prado::localize('Nuova authority'));
			$newAuthority->setUnimarc($tm->asXML());
			//$newAuthority->syncTitle();

			if ($newTitle == "")
				$newTitle = "Nuova authority";

			$newAuthority->setSortText($newTitle);
			$newAuthority->save();

			ChangelogPeer::logAction($newAuthority,
				ChangelogPeer::LOG_CREATE,
				$this->getUser(),
				'Nuova authority creata');

			$newAuthorityId = $newAuthority->getAuthorityId();
			$url = Prado::getApplication()->getService()->constructUrl('Catalog.AuthorityViewPage',
				array('id' => $newAuthorityId));

			$queue = "'<a href='" . $url . "'>" . $newAuthority->getCompleteText() . "</a>'";

			$this->getPage()->enqueueMessage($wasNew
				? Prado::localize('Voce di authority inserita') . ": " . $queue
				: Prado::localize('Voce di authority salvata') . ": " . $queue,
				ClavisMessage::CONFIRM);
		} catch (Exception $e) {
			Prado::log('Exception: ' . $e->getMessage());

			$this->writeMessage(Prado::localize('Errore durante la creazione di una nuova authority: ') . $e->getMessage(),
				ClavisMessage::ERROR);
		}

		return $newAuthorityId;
	}

}