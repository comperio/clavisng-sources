<?php
/**
 * NewRecord class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Pages.Catalog
 */
Prado::using('Application.Common.ImportDrivers.*');

/**
 * NewRecord Class
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Pages.Catalog
 * @since 2.5.0
 */
class NewRecord extends ClavisPage {

	const MAX_RESULTS = 100;

	public $_module = 'CATALOG';
	private $_error_sources = array();
	private $lookup_bl;
	private $_sortOptions = array(
		0			=> '---',
		'Title'		=> 'titolo',
		'Author'	=> 'autore');
	private $_actualSortBy = '';

	public function onLoad($param) {
		parent::onLoad($param);

		/* preload lookups for biblevel */
		$this->lookup_bl = LookupValuePeer::getLookupClassValues('LIVBIBL');

		if (!$this->getIsPostBack() && !$this->getIsCallback()) {
			$this->saveResults(array());
			$this->populate();
			if ($data=$this->getSession()->itemAt('NewRecordSearch')) {
				$this->cleanSearch(null,null);
				$this->getSession()->remove('NewRecordSearch');
				if ($data) {
					$this->cleanSearch(null,null);
					$this->BID->setText($data['bid']);
					$this->LinkBucketNote->setVisible(true);
					$this->LinkBucketNote->getParameters()->add('link',$data['link']);
					$this->LinkBucketNote->getParameters()->add('title',$data['title']);
					$this->doSearch(null,null);
					$this->setActiveSource($data['bid_source']);

                    if($this->getSession()->itemAt('ImmediateImport') == true) {
                        $fakeParam = new TCommandEventParameter('import',0);
                        $this->resultAction(null,$fakeParam);
                    }
				}
			} else {
				$this->setActiveSource('Catalog');
			}
		} else {
			$this->LinkBucketNote->setVisible(false);
			if ($v = $this->LinkBucketSearch->getValue()) {
				$data = json_decode($v);
				if ($data) {
					$this->cleanSearch(null,null);
					$this->BID->setText($data['bid']);
					$this->LinkBucketNote->setVisible(true);
					$this->LinkBucketNote->getParameters()->add('link',$data['link']);
					$this->LinkBucketNote->getParameters()->add('title',$data['title']);
					$this->doSearch(null,null);
					$this->setActiveSource($data['bid_source']);
				}
			}
			$this->updateBucketButton();
		}
	}

	public function populate()
	{
		if (ClavisParamQuery::getParam('CLAVISPARAM','AlwaysShowCreateManifestation') == 'true')
			$this->CreateMan->setVisible(true);

		$importSources = ImportSourceQuery::create()
			->filterByEnabled(true)
			->findList();
		$this->ImportSources->setDataSource($importSources);
		$this->ImportSources->dataBind();

		$this->SearchSort->setDataSource($this->_sortOptions);
		$this->SearchSort->dataBind();

		$this->updateBucketButton();
		$this->populateResultGrid();
	}

	protected function updateBucketButton() {
		$bucket = $this->getSession()->itemAt('ImportLinkBucket');
		if (is_array($bucket)) {
			$bucketcount = 0;
			foreach ($bucket as $record)
				foreach ($record['links'] as $link)
					++$bucketcount;
			if ($bucketcount) {
				$this->ImportLinkBucketButton->setText(
					Prado::localize('legami non ancora importati [{count}]',
						array('count' => $bucketcount)));
				$this->ImportLinkBucketButton->setVisible(true);
				return;
			}
		}
		$this->ImportLinkBucketButton->setVisible(false);
	}

	protected function populateResultGrid() {
		$this->ErrorSources->setDataSource($this->_error_sources);
		$this->ErrorSources->dataBind();
		$sourceId = $this->getActiveSource();
		$results = $this->getLastResults();
		if (!$results) {
			$this->ResultPanel->setVisible(false);
			return;
		}
		$this->ResultPanel->setVisible(true);
		// if current source has no results, set active source id to the first containing results
		if (!array_key_exists($sourceId,$results) || !$results[$sourceId]['Count'])
			foreach ($results as $source)
				if ($source['Count'] > 0) {
					$sourceId = $source['SourceID'];
					$this->setActiveSource($sourceId);
					break;
				}

		$sourceds = array();
		foreach ($results as $rid => &$result) {
			$classAppend = ($result['SourceID'] == 'Catalog') ? ' red' : '';
			$sourceds[] = array(
				'SourceID'		=> $result['SourceID'],
				'SourceLabel'	=> $result['SourceLabel'],
				'Count'			=> $result['Count'],
				'CssClass'	=> (($rid == $sourceId) ? 'tab-active' : 'tab-normal').$classAppend,
			);
		}
		$this->SourceRepeater->setDataSource($sourceds);
		$this->SourceRepeater->dataBind();
		if (array_key_exists($sourceId, $results) && array_key_exists('Results', $results[$sourceId])) {
			if ($this->SearchSort->getSelectedValue()) {
				$this->_actualSortBy = $this->SearchSort->getSelectedValue();
				usort($results[$sourceId]['Results'], array(__CLASS__,'sortResults'));
			}
			$this->ResultGrid->setDataSource($results[$sourceId]['Results']);
			$this->ResultCount->setText($results[$sourceId]['Count']);
			$this->ResultOverflow->setCssClass($results[$sourceId]['Count'] > 100 ? 'labelError control_on' : 'control_off');
			$this->ResultSource->setText($results[$sourceId]['SourceLabel']);
		} else {
			$this->ResultGrid->setDataSource(array());
		}
		$this->ResultGrid->dataBind();
	}

	public function cleanSearch($sender,$param)
	{
		$this->LinkBucketSearch->setValue('');
		$this->BID->setText('');
		$this->EAN->setText('');
		$this->Title->setText('');
		$this->Date->setText('');
		$this->Author->setText('');
		$this->Publisher->setText('');
		$this->BibLevel->setSelectedIndex(0);
	}

	/**
	 * Saves results in temporary storage.
	 *
	 * @param array $results The results array.
	 */
	public function saveResults($results) {
		// the results HAS to be kept in session AND session variable named
		// 'NewRecordLastResults' in order the ImportEditPopup to work
		// (IPC issue).
		$this->getSession()->add('NewRecordLastResults', $results);
	}

	/**
	 * Returns the last search results.
	 *
	 * @return array
	 */
	public function getLastResults() {
		// the results HAS to be kept in session AND session variable named
		// 'NewRecordLastResults' in order the ImportEditPopup to work
		// (IPC issue).
		return $this->getSession()->itemAt('NewRecordLastResults');
	}

	/**
	 * Sets the current source id.
	 *
	 * @param string $sourceId The active source ID.
	 */
	public function setActiveSource($sourceId) {
		$this->getSession()->add('ActiveSource',$sourceId);
	}

	/**
	 * Returns the current source id.
	 *
	 * @return string The active source ID.
	 */
	public function getActiveSource() {
		return $this->getSession()->itemAt('ActiveSource');
	}

	private function getSearchParams()
	{
		$params = array();
		$bid = trim($this->BID->getSafeText());
		if ($bid != '')
			$params['bid'] = $bid;
		$title = trim($this->Title->getSafeText());
		if ($title != '')
			$params['title'] = $title;
		$ean = trim($this->EAN->getSafeText());
		if ($ean != '')
			$params['ean'] = $ean;
		$params['biblevel'] = $this->BibLevel->getSelectedValue();
		$date = trim($this->Date->getSafeText());
		if (is_numeric($date))
			$params['date'] = $date;
		$publisher = trim($this->Publisher->getSafeText());
		if ($publisher != '')
			$params['publisher'] = $publisher;
		$author = trim($this->Author->getSafeText());
		if ($author != '')
			$params['author'] = $author;
		return $params;
	}

	public function doSearch($sender, $param)
	{
		$this->saveResults(array());
		$this->_actualSortBy = '';
		$this->_error_sources = array();
		$this->setActiveSource(0);

		$searchParams = $this->getSearchParams();
		if (count($searchParams) < 2) {
			$this->getPage()->writeMessage(Prado::localize('È necessario specificare almeno un parametro di ricerca'),
				ClavisMessage::ERROR);
			$this->CreateMan->setVisible(false);
			return;
		}
		$this->CreateMan->setVisible(true);
		$results = array();

		$results['Catalog'] = $this->searchCatalog($searchParams);

		foreach ($this->ImportSources->getItems() as $row) {
			if (!$row->SourceSelected->getChecked())
				continue;
			$source = ImportSourceQuery::create()->findPk($row->SourceName->getValue());
			if (!$source instanceof ImportSource)
				continue;
			$driverClass = $source->getDriver();
			if (!class_exists($driverClass))
				continue;
			$driver = new $driverClass;
			$driver->setSourceName($source->getName());
			$driver->setAddress($source->getAddress());
			$driver->setTimeout($source->getTimeout());
			$driver->setEncoding($source->getEncoding());
			$driver->setSearchFields($source->getSearchFields());
			$driver->setSyntax($source->getSyntax());
			$driver->setFormat($source->getFormat());
			$driver->setTurbomarcConversion($source->getTurbomarcConversion());
			$driver->setMaxResults(self::MAX_RESULTS);
			$driver->setParameters($source->getOptions());
			$sourceResults = array(
				'DriverClass'	=> $driverClass,
				'SourceID'		=> $source->getName(),
				'SourceLabel'	=> $source->getLabel(),
				'Count'			=> 0,
				'Results'		=> array()
			);
			try {
				$srch = $driver->search($searchParams);
				if ($srch !== false) {
					$sourceResults['Count'] = $srch['Count'];
					foreach ($srch['Results'] as $id => $tm)
						$sourceResults['Results'][] = $this->prepareResult($source->getName(),$id,
							$tm,$source->getDefaultCatlevel());
				}
				$results[$source->getName()] = $sourceResults;

			} catch (Exception $e) {
				$this->_error_sources[] = array(
				'SourceLabel'	=> $source->getLabel(),
				'ErrorMessage'	=> $e->getCode() == BaseImportDriver::ERR_NOTAVAILABLE ?
					Prado::localize('server non disponibile') : $e->getMessage());
			}
		}
		$this->saveResults($results);
		$this->populateResultGrid();
	}

	private function buildHtmlTree(&$rec, $mode="Manifestation", $level = 0, $sourceId='') {
        static $visitStack = [];

        $span = "<span class=\"caret caret-down\" onclick='this.parentElement.querySelector(\".nested\").classList.toggle(\"active\"); this.classList.toggle(\"caret-down\");'></span>";
        $t1 = "<li>";

        if($level == 0)
            $ret = "<ul class='treeview'>";
        else
            $ret = "";

        $ret .= $t1;
        switch($mode) {
            case "Manifestation":
                $rec['BidSource'] = $sourceId;
                $rec['Bid']=$rec['ManifestationId'];

                if(count($rec['LManifestation']) > 0 || count($rec['LAuthorityManifestation']) > 0 )
                    $ret .= $span;

                if($level > 0)
                    $ret .="<input style='display: none;' type='checkbox' checked/>{$rec['Title']} ";
                else
                    $ret .="Reticolo";

                $m1 = ManifestationQuery::create()
                    ->filterByBidSource($sourceId)
                    ->filterByBid($rec['ManifestationId'])
                    ->findOne();
                if($m1 instanceof Manifestation) {
                    $url = $this->getService()->constructUrl("Catalog.Record", ['manifestationId'=>$m1->getManifestationId()], null, false);
                    $ret .= "<a href=\"{$url}\" target='_blank'>Trovata</a>";
                    $rec['LocalRecordID'] = $m1->getManifestationId();
                }
                break;
            case "LManifestation":
                $ret .= $span."{$rec['LinkType']} " . LookupValuePeer::getLookupValue("UNI4XX",$rec['LinkType']);
                break;
            case "LAuthorityManifestation":
                $ret .= $span."{$rec['LinkType']} " . LookupValuePeer::getLookupValue("LINKTYPE",$rec['LinkType']);
                break;
            case "LAuthority":
                $ret .= $span." "
                    . LookupValuePeer::getLookupValue("AUTHLINKTYPEMUTUAL",$rec['LinkType'])
                    . LookupValuePeer::getLookupValue("AUTHLINKTYPE",$rec['LinkType']);
                break;
            case "Authority":
                $rec['BidSource'] = $sourceId;
                $rec['Bid']=$rec['AuthorityId'];

                if(count($rec['LAuthority']) > 0 )
                    $ret .= $span;
                $ret .= "<input style='display: none;' type='checkbox' checked/>[{$rec['AuthorityType']}] {$rec['FullText']} ";
                $a1 = AuthorityQuery::create()
                    ->filterByBidSource($sourceId)
                    ->filterByBid($rec['AuthorityId'])
                    ->findOne();
                $foudDetail = "";
                if($a1 == null) { // Fallback to identical type and text
                    $a1 = AuthorityQuery::create()
                        ->filterByAuthorityType($rec['AuthorityType'])
                        ->filterByFullText($rec['FullText'])
                        ->findOne();

                    $foudDetail=".";
                }

                if($a1 instanceof Authority) {
                    $url = $this->getService()->constructUrl("Catalog.AuthorityViewPage",['id'=>$a1->getAuthorityId()],null,false);
                    $ret .= "<a href=\"{$url}\" target='_blank'>Trovata{$foudDetail}</a>";
                    $rec['LocalRecordID'] = $a1->getAuthorityId();
                    $foudDetail = "";
                }
                break;
        }

        if($level == 0)
            $ret .= "<ul class='nested '>";
        else
            $ret .= "<ul class='nested active'>";

        switch($mode) {
            case "Manifestation":
                if(isset($rec['LManifestation']) && count($rec['LManifestation']) > 0) {

                    for($i=0; $i < count($rec['LManifestation']); $i++) {
                        $ret .= $this->buildHtmlTree($rec['LManifestation'][$i], 'LManifestation', $level + 1, $sourceId);
                    }

                }
                if(isset($rec['LAuthorityManifestation']) && count($rec['LAuthorityManifestation']) > 0) {

                    for($i=0; $i < count($rec['LAuthorityManifestation']); $i++) {
                        $ret .= $this->buildHtmlTree($rec['LAuthorityManifestation'][$i], 'LAuthorityManifestation', $level + 1, $sourceId);
                    }

                }
                break;
            case "LManifestation":
                if(isset($rec['Manifestation']))
                    $ret .= $this->buildHtmlTree($rec['Manifestation'],'Manifestation',$level +1, $sourceId);
                break;
            case "LAuthorityManifestation":
                if(isset($rec['Authority']))
                    $ret .=  $this->buildHtmlTree($rec['Authority'],'Authority',$level +1, $sourceId);
                break;
            case "LAuthority":
                if(isset($rec['Authority']))
                    $ret .=  $this->buildHtmlTree($rec['Authority'],'Authority',$level +1, $sourceId) ;
                break;
            case "Authority":
                if(isset($rec['LAuthority']) && count($rec['LAuthority']) > 0) {

                    for($i=0; $i < count($rec['LAuthority']); $i++)
                        $ret .= $this->buildHtmlTree($rec['LAuthority'][$i], 'LAuthority', $level + 1, $sourceId);

                }
                break;
        }
        $ret .= "</ul>";
        $ret.="</li>";
        if($level == 0)
            $ret .= "</ul>";

        return $ret;
    }

	protected function prepareResult($sourceId,$recordId,$result,$catlevel=0)
	{
		$our_record = null;

		if(is_array($result)) {
		    $ret = array('Id' => $recordId, 'ClavisId' => $recordId, 'InCatalog' => false);

            $result['BidSource'] =$sourceId;
            $result['Bid'] = $result['ManifestationId'];

            $our_record_id = ManifestationPeer::bidExists($sourceId, $result['ManifestationId']);

            if ($our_record_id) {
                $ret['ClavisId'] = $our_record_id;
                $ret['InCatalog'] = true;
            }

            $ret['BidSource'] =$sourceId;
            $ret['Bid'] = $result['ManifestationId'];

            $tm = TurboMarc::createRecord($result['Unimarc']);
            if(isset($tm->d105)) {
                $genere = ($tm->d105->getCDF('a',11) == 'a')?" (Fiction)":" (Non fiction)";
            } else {
                $genere = " (Genere non specificato)";
            }

            $ret['Title'] = htmlspecialchars(trim($tm->getFullTitle()));
            $ret['Author'] = htmlspecialchars($tm->getAuthor());
            $ret['EAN'] = $tm->getEAN();
            $ret['Editions'] = htmlspecialchars(implode(' - ', $tm->getEditions()));
            $ret['Publications'] = htmlspecialchars(implode(' - ', $tm->getPublications()) . " $genere");

            $ret['RawHTML'] =$this->buildHtmlTree($result,'Manifestation',0,$sourceId);
            $ret['JSONData'] = $result;

        } else {
		    $turbomarc = $result;
            $tm = TurboMarc::createRecord($turbomarc);
            // remove 950 - we don't import items!
            unset($tm->d950);
            if ($sourceId != 'Catalog') {
                // copy bid in 035
                unset($tm->d035);
                $f035 = $tm->addField('035');
                $f035->addSubField('a', (string)$tm->c001);
                $f035->addSubField('9', $sourceId);
                // have we already imported that record in catalog?
                $our_record_id = ManifestationPeer::bidExists($sourceId, (string)$tm->c001);
            } else {
                $our_record_id = $recordId;
            }
            if ($catlevel > 0) {
                $tm->d901->se = $catlevel;
            }
            $ret = array('Id' => $recordId, 'ClavisId' => $recordId, 'Turbomarc' => $tm->asXML(), 'InCatalog' => false);
            $l = $tm->getLeader();
            // the following is to avoid errors with SBN - TEMP!!!
            if (!$l instanceof TurboMarcLeader)
                return null;

            if ($our_record_id) {
                $ret['ClavisId'] = $our_record_id;
                $ret['InCatalog'] = true;
            }
            $ret['Bid'] = (string)$tm->d035->sa;
            $ret['BidSource'] = (string)$tm->d035->s9;
            $ret['BibLevelCode'] = $l->biblevel;
            $ret['BibLevelLabel'] = (array_key_exists($ret['BibLevelCode'], $this->lookup_bl)) ?
                $this->lookup_bl[$ret['BibLevelCode']] : '---';
            $ret['Title'] = htmlspecialchars(trim($tm->getFullTitle()));
            $ret['Author'] = htmlspecialchars($tm->getAuthor());
            $ret['EAN'] = $tm->getEAN();
            $ret['Editions'] = htmlspecialchars(implode(' - ', $tm->getEditions()));
            $ret['Publications'] = htmlspecialchars(implode(' - ', $tm->getPublications()));
            $ret['Series'] = htmlspecialchars(implode(' - ', $tm->getSeries()));
            $ret['Dewey'] = $tm->getDewey();
            $ret['Subjects'] = htmlspecialchars(implode(', ', $tm->getSubjects()));
            $ret['PartOf'] = array_key_exists('d461', $tm) ? "{$tm->d461->st} [{$tm->d461->s1}]" : '';
        }
		return $ret;
	}

	public function sortResults($a, $b) {
		return strcmp($a[$this->_actualSortBy],$b[$this->_actualSortBy]);
	}

	public function sourceSelected($sender, $param)
	{
		switch ($param->getCommandName()) {
			case 'selected':
				$this->setActiveSource($param->getCommandParameter());
				$this->populateResultGrid();
				break;
		}
	}

	public function sortingChanged($sender, $param)
	{
		$this->populateResultGrid();
	}

	public function onFake($sender, $param) {

    }

	public function onDetailedImport($sender,$param)
	{
		$resultId = intval($this->ImportRecordId->getValue());
		$sourceId = $this->getActiveSource();
		$results = $this->getLastResults();
		if (array_key_exists($sourceId, $results) &&
				array_key_exists('Results', $results[$sourceId]) &&
				array_key_exists($resultId, $results[$sourceId]['Results'])) {

		   // $this->saveResults([]);
			$this->doImport($results[$sourceId]['Results'][$resultId]['Turbomarc']);
		} else {
			Prado::log("Non riconosciuto: recordId [{$resultId}] sourceId [{$sourceId}]");
			$this->writeMessage(Prado::localize('Risultato non riconosciuto, impossibile importare.'),
				ClavisMessage::ERROR);
		}
	}

	public function resultAction($sender,$param)
	{
		switch ($param->getCommandName()) {
			case 'import':
				$resultId = $param->getCommandParameter();
				$sourceId = $this->getActiveSource();
				$results = $this->getLastResults();

                Prado::log("Import result id:" . $resultId);

				if ($results &&
						array_key_exists($sourceId, $results) &&
						array_key_exists('Results', $results[$sourceId]) &&
						array_key_exists($resultId, $results[$sourceId]['Results']))
				{
					$driver = new $results[$sourceId]['DriverClass'];
					if(isset($results[$sourceId]['Results'][$resultId]['JSONData'])) {
					    $this->doJSONImport($results[$sourceId]['Results'][$resultId]['JSONData'],"Manifestation");

                    } else {
                        $tmxml = $driver->getFullTurbomarcRecord($results[$sourceId]['Results'][$resultId]['Turbomarc']);
                       // $this->saveResults([]);
                        Prado::log("Save record {$resultId}");
                        $this->doImport($tmxml);
                    }
				} else {
					Prado::log("Non riconosciuto: recordId [{$resultId}] sourceId [{$sourceId}]");
					$this->writeMessage(Prado::localize('Risultato non riconosciuto, impossibile importare.'),
						ClavisMessage::ERROR);
				}
				break;
		}
	}

	private function doJSONImport(&$rec,$mode="Manifestation",$level = 0)
    {
        static $catDB = [];

        switch($mode) {
            case "Manifestation":
                if(isset($rec['LManifestation']) && count($rec['LManifestation']) > 0) {
                    for($i=0; $i < count($rec['LManifestation']); $i++) {
                        $this->doJSONImport($rec['LManifestation'][$i], 'LManifestation',$level+1);
                    }
                }
                if(isset($rec['LAuthorityManifestation']) && count($rec['LAuthorityManifestation']) > 0) {
                    for($i=0; $i < count($rec['LAuthorityManifestation']); $i++) {
                        $this->doJSONImport($rec['LAuthorityManifestation'][$i], 'LAuthorityManifestation',$level+1);
                    }
                }
                break;
            case "LManifestation":
                if(isset($rec['Manifestation']))
                    $this->doJSONImport($rec['Manifestation'],'Manifestation',$level+1);
                break;
            case "LAuthorityManifestation":
                if(isset($rec['Authority']))
                    $this->doJSONImport($rec['Authority'],'Authority',$level+1);
                break;
            case "LAuthority":
                if(isset($rec['Authority']))
                    $this->doJSONImport($rec['Authority'],'Authority',$level+1) ;
                break;
            case "Authority":
                if(isset($rec['LAuthority']) && count($rec['LAuthority']) > 0) {
                    for($i=0; $i < count($rec['LAuthority']); $i++)
                        $this->doJSONImport($rec['LAuthority'][$i], 'LAuthority',$level+1);
                }
                break;
        }
        // Import object
        switch($mode) {
            case "Manifestation":
                //TODO Create/Update Manifestation
                if(isset($rec['LocalRecordID'])) { // Local Record is present get actual Id
                    $rec['ManifestationId'] = $rec['LocalRecordID'];

                }
                elseif(isset($catDB['Manifestation'][$rec['Bid']])) {
                    $rec['ManifestationId'] = $catDB['Manifestation'][$rec['Bid']];
                }
                else {
                    // Create a new record
                    $m = new Manifestation();
                    $m->fromArray($rec);

                    $m->setManifestationId(null);
                    $m->setCreatedBy($this->getUser()->getId());
                    $m->setModifiedBy($this->getUser()->getId());
                    $m->setDateCreated(time());
                    $m->setDateUpdated(time());
                    $m->setNonSortText($rec['NonSortText']);
                    $m->save();
                    $m->doIndex();

                    ChangelogPeer::logAction($m, ChangelogPeer::LOG_CREATE, $this->getUser(), 'Nuova notizia importata');

                    $rec['ManifestationId'] = $m->getManifestationId();
                    $catDB['Manifestation'][$rec['Bid']] = $m->getManifestationId();
                }

                if(isset($rec['LManifestation']) && count($rec['LManifestation']) > 0) {
                    for($i=0; $i < count($rec['LManifestation']); $i++) {
                        $rec['LManifestation'][$i]['ManifestationIdUp'] =  $rec['ManifestationId'];
                        $rec['LManifestation'][$i]['ManifestationIdDown'] =  $rec['LManifestation'][$i]['Manifestation']['ManifestationId'];
                        $lm = new LManifestation();
                        $lm->fromArray($rec['LManifestation'][$i]);

                        $lm->isNew(true);
                        try {
                            $lm->save();
                        } catch (Exception $e) {

                        }
                    }
                }
                if(isset($rec['LAuthorityManifestation']) && count($rec['LAuthorityManifestation']) > 0) {
                    for($i=0; $i < count($rec['LAuthorityManifestation']); $i++) {
                        $rec['LAuthorityManifestation'][$i]['AuthorityId'] = $rec['LAuthorityManifestation'][$i]['Authority']['AuthorityId'];
                        $rec['LAuthorityManifestation'][$i]['ManifestationId'] =  $rec['ManifestationId'];
                        $lam = new LAuthorityManifestation();
                        $lam->fromArray($rec['LAuthorityManifestation'][$i]);

                        $lam->isNew(true);
                        try {
                            $lam->save();
                        } catch (Exception $e) {

                        }

                    }
                }

                break;

            case "Authority":
                if(isset($rec['LocalRecordID'])) { // Local Record is present get actual Id
                    $rec['AuthorityId'] = $rec['LocalRecordID'];
                }
                elseif(isset($catDB['Authority'][$rec['Bid']])) {
                    $rec['AuthorityId'] = $catDB['Authority'][$rec['Bid']];
                }
                else {
                    // Create a new record
                    $a = new Authority();
                    $a->fromArray($rec);

                    $a->setAuthorityId(null);
                    $a->setCreatedBy($this->getUser()->getId());
                    $a->setModifiedBy($this->getUser()->getId());
                    $a->setDateCreated(time());
                    $a->setDateUpdated(time());
                    $a->setNonSortText($rec['NonSortText']);
                    $a->save();
                    $a->doIndex();
                    $rec['AuthorityId'] = $a->getAuthorityId();
                    $catDB['Authority'][$rec['Bid']] = $a->getAuthorityId();

                    ChangelogPeer::logAction($a, ChangelogPeer::LOG_CREATE, $this->getUser(), 'Nuova authority importata');
                }

                if(isset($rec['LAuthority']) && count($rec['LAuthority']) > 0) {
                    for($i=0; $i < count($rec['LAuthority']); $i++) {
                        $rec['LAuthority'][$i]['AuthorityIdDown'] = $rec['AuthorityId'];
                        $rec['LAuthority'][$i]['AuthorityIdUp'] = $rec['LAuthority'][$i]['Authority']['AuthorityId'];
                        $la = new LAuthority();
                        $la->fromArray($rec['LAuthority'][$i]);

                        $la->isNew(true);
                        try {
                            $la->save();

                            $la->getAuthorityRelatedByAuthorityIdDown()->save();
                            $la->getAuthorityRelatedByAuthorityIdUp()->save();

                        } catch (Exception $e) {

                        }

                    }
                }
                break;
        }

        if($level == 0 && $mode == 'Manifestation' && ($m instanceof Manifestation)) {

			$msg = Prado::localize('Notizia importata correttamente.');
			$type = ClavisMessage::CONFIRM;

			$this->writeMessage($msg, $type);
			$this->gotoPage('Catalog.Record',array('manifestationId' => $m->getManifestationId()));
        }
    }

	private function doImport($turbomarc)
	{
		$linkbucket = $this->getSession()->itemAt('ImportLinkBucket');
		if (!is_array($linkbucket))
			$linkbucket = array();
		try {
			$lbcount = count($linkbucket);
			$tm = TurboMarc::createRecord($turbomarc);
			// do all needed pre-import stuff (e.g. import series)
			$this->doPreImport($tm);
			$m = ManifestationPeer::createFromTurbomarc($tm, false, $linkbucket);
			$m->doIndex();
			$lbcount2 = count($linkbucket);
			// update linkbucket: since import went well, if BID is in bucket, remove it.
			foreach ($linkbucket as $k => $manifestation)
				foreach($manifestation['links'] as $j => $link)
					if ($link['bid_source'] == $m->getBidSource() &&
							$link['bid'] == $m->getBid())
						unset($linkbucket[$k]['links'][$j]);
			// updated, readd into session.
			$this->getSession()->add('ImportLinkBucket',$linkbucket);
			ChangelogPeer::logAction($m, ChangelogPeer::LOG_CREATE, $this->getUser(), 'Nuova notizia importata');

			$msg = Prado::localize('Notizia importata correttamente.');
			$type = ClavisMessage::CONFIRM;
			if ($lbcount != $lbcount2) {
				$msg .= Prado::localize(' {count} legami sono stati aggiunti alla lista dei non ancora importati.',
					array('count' => count($linkbucket[$m->getManifestationId()]['links'])));
				$type = ClavisMessage::WARNING;
			}
			$this->writeMessage($msg, $type);
			$this->gotoPage('Catalog.Record',array('manifestationId' => $m->getManifestationId()));
		} catch (Exception $e) {
			throw $e;
			Prado::log('Exception: '.$e->getMessage());
			$this->writeMessage(Prado::localize('Errore durante l\'importazione della notizia: ').
				$e->getMessage(), ClavisMessage::ERROR);
		}
	}

	private function doPreImport(TurboMarc $tm)
	{
		$bidFld = 's'.strtolower($tm->d035->s9);
		// check if record has a BID'ed serie, if we haven't it in catalog, yet, import!
		if (isset($tm->d410))
			foreach ($tm->d410 as $seriefld)
				if (($seriefld->s3 && !ManifestationPeer::bidExists((string)$seriefld->s5,(string)$seriefld->s3))
					|| (isset($seriefld->$bidFld) && !ManifestationPeer::bidExists((string)$tm->d035->s9,(string)$seriefld->$bidFld)))
				{
					if (isset($seriefld->$bidFld)) {
						$bid_source = (string)$tm->d035->s9;
						$bid = (string)$seriefld->$bidFld;
					} else {
						$bid_source = (string)$seriefld->s5;
						$bid = (string)$seriefld->s3;
					}
					$sourceId = $this->getActiveSource();
					$results = $this->getLastResults();
					if (array_key_exists($sourceId, $results) &&
						array_key_exists('Results', $results[$sourceId]))
					{
						$driver = new $results[$sourceId]['DriverClass'];
						$serietm = TurboMarc::createRecord();
						$serietm->addField('035')->addSubField('a', $bid);
						$serietm->d035->addSubField('9', $bid_source);
						// search for it in current source
						$serietm = TurboMarc::createRecord($driver->getFullTurbomarcRecord($serietm->asXML()));
						if (isset($serietm->d200)) {
							$serie = ManifestationPeer::createFromTurbomarc($serietm);
							$serie->doIndex();
						} else {
							$serietm->setLeader('01234nac1 2201234   450 ');
							$f101 = $serietm->addField('101');
							$f101->addSubField('a','ita');
							$serietm->setTitle((string)$seriefld->st);
							$serie = ManifestationPeer::createFromTurbomarc($serietm);
							$serie->setManifestationStatus(ManifestationPeer::STATUS_IMPORT);
							$cat_level = '05';
							if ($this->getUser() instanceof ClavisLibrarian)
								$cat_level = $this->getUser()->getLibrarian()->getCatLevel();
							$serie->setCatalogationLevel($cat_level);
							$serie->save();
							$serie->doIndex();
						}
					}
				}
	}

	public function doCreateManif($sender, $param)
	{
		try
		{
			$man = new Manifestation();
			$man->setManifestationStatus(null); //ManifestationPeer::STATUS_COMPLETE);
			$cat_level = '05';
			
			if ($this->getUser() instanceof ClavisLibrarian)
				$cat_level = $this->getUser()->getLibrarian()->getCatLevel();
			
			$man->setCatalogationLevel($cat_level);
			$tm = TurboMarc::createRecord();
			$tm->setLeader(' 1234nam0 2201234   450 ');
			$f101 = $tm->addField('101');
			$f101->addSubField('a', 'ita');
			$tm->setTitle(Prado::localize('Nuova notizia'));
			$man->setUnimarc($tm->asXML());
			$man->syncTitle();
			$man->save();
			
			ChangelogPeer::logAction($man, ChangelogPeer::LOG_CREATE, $this->getUser(), 'Nuova notizia creata');
			
			$this->writeMessage(Prado::localize('Notizia creata, procedere alla catalogazione...'),
									ClavisMessage::CONFIRM);
			
			Prado::log("Create {$man->getManifestationId()}");
			
			$this->gotoPage(	'Catalog.EditRecord',
								array('manifestationId' => $man->getManifestationId()));
		}
		catch (Exception $e)
		{
			Prado::log('Exception: ' . $e->getMessage());
			
			$this->writeMessage(Prado::localize('Errore durante la creazione di una nuova notizia: ') . $e->getMessage(),
									ClavisMessage::ERROR);
		}
	}

	public function onSourceItemCreated($sender, $param) {
		$item = $param->getItem();
		if ($item->ItemType === 'Item' || $item->ItemType === 'AlternatingItem') {

		}
	}

	protected function searchCatalog($searchParams)
	{
		$query = '';
		foreach ($searchParams as $k => $v)

			switch($k) {
				case 'title':
                    $v = str_replace(":"," ",$v);
					//$query .= " +(mrc_d200_sa:({$v}))";
                    $query .= " +(fldin_txt_title:({$v}))";
					break;
				case 'ean':
					$v1 = Clavis::hyphenateStdNum($v);
					$v2 = Clavis::normalizeStdNum($v);
					$query .= " +(fldin_txt_numbers:{$v1} OR fldin_txt_numbers:{$v2})";
					break;
				case 'date':
					$query .= " +(sorti_date:({$v}))";
					break;
				case 'biblevel':
					$query .= " +(mrc_l_7:({$v}))";
					break;
				case 'id':
					$query .= " +(id:{$v})";
					break;
				case 'bid':
					$v = addslashes($v);
					$query .= " +(id:({$v}) OR fldin_str_bid:(\"{$v}\"))";
					break;
				case 'publisher':
					$query .= " +(mrc_d210_sc:({$v}) OR fldin_txt_publisher:({$v}))";
					break;
				case 'author':
					$query .= " +(fldin_txt_author:({$v}))";
					break;
			}
		try {
			$response = $this->getApplication()->getModule('search')->search($query,0,self::MAX_RESULTS);
			$ds = array();
			foreach ($response['response']['docs'] as $key => $result)
				$ds[] = $this->prepareResult('Catalog',$result['Id'],$result['turbo_marc']);
			$ret = array(
				'SourceID'		=> 'Catalog',
				'SourceLabel'	=> Prado::localize('In catalogo'),
				'Results'		=> $ds,
				'Count'			=> $response['response']['numFound']);
		} catch (Exception $e) {
			$this->_error_sources[] = array(
				'SourceLabel'	=> Prado::localize('In catalogo'),
				'ErrorMessage'	=> $e->getCode() == BaseImportDriver::ERR_NOTAVAILABLE ?
					Prado::localize('server non disponibile') : $e->getMessage()
			);
			$ret = array(
			'SourceID'		=> 'Catalog',
			'SourceLabel'	=> Prado::localize('In catalogo'),
			'Results'		=> array(),
			'Count'			=> 0);
		}
		return $ret;
	}
}
