<?php

/**
 * IssueReplacePage class Module Catalog
 *
 * @author Marco Brancalion <mbrancalion@e-portaltech.it>
 * @author Max Pigozzi <mpigozzi@e-portaltech.it>
 * @link http://www.e-portaltech.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @license http://www.e-portaltech.it/license/
 */

class IssueReplacePage extends ClavisPage {

	public $_module = "CATALOG";

	private $_id;
	private $_issue = null;

	public function onInit($param)
	{
		parent::onInit($param);
		$this->setId(TPropertyValue::ensureInteger($this->Request['issueId']));
		if($this->_id > 0)
		{
			$issue = IssuePeer::retrieveByPK($this->_id);
			if(is_null($issue))
			{
				$this->gotoPage("ErrorPage");

			}
			$this->setIssue($issue);
		}



	}

	public function onLoad($param)
	{
		parent::onLoad($param);

		if(!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallback())
		{

			if($this->getId() > 0)
			{
				//
				$this->IssueView->setIssue($this->getIssue());
				if($this->_issue) {
					$manifestation = ManifestationPeer::retrieveByPK($this->_issue->getManifestationId());
					if($manifestation)
						$this->IssueList->setManifestation($manifestation);
				}
			}

			$this->IssueList->setLibrary($this->getUser()->getActualLibrary());
		}
		if ($this->isReturnPageEnabled())
			$this->ReturnButton->setVisible(true);

	}

	public function globalRefresh()
	{
		$this->IssueList->globalRefresh();
	}


	public function onReplace($sender, $param)
	{

		$successNumber = 0;
		$failNumber = 0;

		$targetIssueId = 0;
		$currentLibrarian = $this->getUser();
		$targetIssue = $this->getIssue();
		if(!is_null($targetIssue))
			$targetIssueId = $targetIssue->getIssueId();
		else
			return;
		$sourceIssueIds = $this->IssueList->getCheckedId();
		$totalNumber = count($sourceIssueIds);

		//Prado::log("sourceIssueIds::totalNumbers=$totalNumber");
		//return;

		foreach ($sourceIssueIds as $sourceIssueId)
		{
			$sourceIssueId = TPropertyValue::ensureInteger($sourceIssueId);
			if ($sourceIssueId > 0)
			{
				if ($sourceIssueId == $targetIssueId) {
					$this->writeMessage(Prado::localize("Non è possibile schiacciare un fascicolo su se stesso!"),ClavisMessage::ERROR);
					continue;    //  schiacciamento su se stesso
				}
				$sourceIssue = IssuePeer::retrieveByPK($sourceIssueId);
				if (!is_null($sourceIssue) && ($sourceIssue instanceof Issue))
				{
					$result = $sourceIssue->replaceWith($targetIssue, $currentLibrarian);
					if ($result)
						$successNumber++;
					else
						$failNumber++;
				}
			}
		}

		if ($successNumber > 0)
		{
			$this->IssueList->resetDataSource();
			$this->IssueList->globalRefresh();
			$this->getPage()->writeMessage(($successNumber == 1)
				? Prado::localize('1 fascicolo processato')
				: Prado::localize('{count} fascicoli processati',
					array('count'=>$successNumber)),ClavisMessage::INFO);
		}

		if ($failNumber > 0)
			$this->getPage()->writeMessage(($failNumber == 1)
				? Prado::localize('1 fascicolo NON processato')
				: Prado::localize('{count} fascicoli NON processati',
					array('count'=>$failNumber)),ClavisMessage::ERROR);
	}




	/**
	 * setter
	 *
	 * @param int $id
	 */
	public function setId($id) {
		$this->_id = $id;
		$this->setViewState("id",$id,null);
	}


	/**
	 * getter
	 *
	 * @return Id
	 *
	 */
	public function getId() {
		if(is_null($this->_id)) {
			$this->_id = $this->getViewState("id",null);
		}
		return $this->_id;
	}

	/**
	 * Setter method of object issue.
	 *
	 * @param Issue $issue
	 */
	public function setIssue($issue)
	{
		$this->_issue = $issue;
		$this->setViewState("issue", $issue, null);
	}

	/**
	 * Getter method of object issue.
	 *
	 * @return Issue
	 *
	 */
	public function getIssue()
	{
		if(is_null($this->_issue))
			$this->_issue = $this->getViewState("issue", null);
		return $this->_issue;
	}

	public function onReturn($sender, $param)
	{
		if($this->isReturnPageEnabled())
			$this->returnPage();

	}
}

?>