<?php

/**
 * IssueCreationPopup Page class Module
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2009 Comperio srl
 * @version 2.7
 * @package Popups.Catalog
 * @since 2.2
 */

class IssueCreationPopup extends ClavisPagePopup
{
	public $_module = 'CATALOG';

	public function onInit($param)
	{
		parent::onInit($param);
		if (!$this->getIsPostBack() && !$this->getIsCallback()) {
			$m = ManifestationPeer::retrieveByPK($this->getRequest()->itemAt('param'));
			if ($m instanceof Manifestation)
				$this->IssueWizard->setManifestation($m);
		}
	}

	public function onCancel($sender, $param)
	{

	}

	public function globalRefresh()
	{
	}

	public function isUnlink()
	{
		return false;
	}

}