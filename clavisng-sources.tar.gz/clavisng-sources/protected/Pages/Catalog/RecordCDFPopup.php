<?php

/**
 * RecordCDFPopup class
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2009 Comperio srl
 * @version 2.7
 * @package Popups.Catalog
 * @since 2.3
 */

Prado::using('TurboMarc');

class RecordCDFPopup extends ClavisPagePopup
{
	public $_module = 'CATALOG';

	private $_mode = 'View';

	public function onLoad($param)
	{
		parent::onLoad($param);

		$param = unserialize($this->getRequest()->itemAt('param'));
		$this->setMode($this->getRequest()->itemAt('objectType'));
		$mode = $this->getMode();
		$this->FieldLabel->setText($param['fieldlabel']);
		$this->FieldNumber->setText($param['fieldnum']);
		$flist = array();

		foreach (TurboMarcMappings::$cdflist[$param['fieldnum']] as $tag => $positions) {
			if (strlen($tag) > 1)
				continue;
			if (!array_key_exists($tag, $param['subfields']))	// create null field
				$param['subfields'][$tag] = str_repeat(' ',TurboMarcMappings::$cdflist[$param['fieldnum']][$tag.'_len']);
			foreach ($positions as $p => $l) {
				$value = substr($param['subfields'][$tag],$p,$l);
				/* if viewing and no value is set, skip it */
				if ($mode == 'View' && !trim($value))
					continue;
				$flist[] =
					array('key' => "{$param['fieldnum']}-{$tag}-{$p}",
						'field' => $param['fieldnum'],
						'tag' => $tag,
						'pos' => $p,
						'len' => $l,
						'grouplabel' => UnimarcCodesPeer::getGroupLabel($param['fieldnum'], $tag, $p),
						'value' => $value);
			}
		}
		$this->setViewState('field', $param);
		$this->SubfieldRepeater->setDataSource($flist);
		$this->dataBind();
	}

	public function ItemCreated($sender, $param) {
		$item = $param->Item;
		if ($item->ItemType==='Item' || $item->ItemType==='AlternatingItem') {
			if ($this->getMode()=='View')
				$item->SubfieldValue->setDesignMode(ClavisUnimarcField::TLABEL);
			$item->SubfieldValue->dataBind();
		}
	}

	public function onSave($sender, $param) {
		$field = $this->getViewState('field');
		foreach ($this->SubfieldRepeater->getItems() as $item) {
			$data = $item->getDataItem();
			$value = $item->SubfieldValue->getValue();
			if (strlen($value) <= $data['len'])
				$value = sprintf("%{$data['len']}s",$value);
			$field['subfields'][$data['tag']] = substr_replace($field['subfields'][$data['tag']], $value, $data['pos'], $data['len']);
		}
		$this->getPage()->getClientScript()->registerEndScript(__CLASS__.'_js','onReturn(\''.
			$field['key'].'\',\''.addslashes(serialize($field)).'\',true);');
	}

	public function setMode($value) {
		$this->setViewState('Mode', $value,'View');
	}

	public function getMode() {
		return $this->getViewState('Mode','View');
	}
}