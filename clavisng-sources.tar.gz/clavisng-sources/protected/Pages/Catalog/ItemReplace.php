<?php

/**
 * ItemReplace Page class Module Circulation
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2010 Comperio srl
 * @version 2.7
 * @package Pages.Catalog
 * @since 2.4
 */

class ItemReplace extends ClavisPage {

	public $_module = 'CATALOG';
	public $_item;

	public function onLoad($param)
	{
		parent::onLoad($param);

		$this->_item = ItemPeer::retrieveByPK($this->getRequest()->itemAt('itemId'));

		if (!$this->getIsPostBack() && !$this->getIsCallback()) {
			if ($this->_item instanceof Item) {
				$m = $this->_item->getManifestation();
				if ($m instanceof Manifestation) {
					$this->RecordChooser->setManifestation($m);
					$this->RecordChooser->ManifestationView->update($m->getManifestationId());
				}
			}
		}
	}

	public function globalRefresh()
	{
		$this->ManifestationList->globalRefresh();
	}

	public function onReplace($sender, $param)
	{
		$manif_id = $this->RecordChooser->getManifestationId();
		$manifestation = $this->RecordChooser->getManifestation();
		if (! $manifestation instanceof Manifestation) {
			$this->writeMessage(Prado::localize('Notizia inesistente'),ClavisMessage::ERROR);
			$this->reloadPage();
		}
		$issue = $this->RecordChooser->getIssue();

		if ($this->_item->moveToManifestation($manifestation, $issue, false, $this->getUser())) {
			$this->writeMessage(Prado::localize('Notizia sostituita con successo.'),ClavisMessage::INFO);
		} else {
			$this->writeMessage(Prado::localize('Errore nella sostituzione della notizia.'),ClavisMessage::ERROR);
		}
		$this->gotoPage('Catalog.ItemViewPage',array('id' => $this->_item->getItemId()));
	}
}
