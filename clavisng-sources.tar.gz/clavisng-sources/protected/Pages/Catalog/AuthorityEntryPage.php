<?php

/**
 * AuthorityEntryPage Page class Module Circulation
 *
 * @author Dario Rigolin <drigolin@e-portaltech.it>
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2008 ePortal Technologies
 * @copyright Copyright &copy; 2009 Comperio srl
 */

class AuthorityEntryPage extends ClavisPage {

	public $_module = 'CATALOG';
	
	public $catrescnt = 0;

	public function searchAuth($sender, $param) {
		$result = $this->AuthorityType->getSelectedValue();
		$this->setViewState('authType', $result);

		$result = $this->AuthorityType->getSelectedItem()->getText();
		$this->setViewState('authLabel', $result);

		$title = $this->Title->getText();
		$this->getPage()->setViewState('Title', $title);

		$criteria = new Criteria();
		$criteria->add(AuthorityPeer::AUTHORITY_TYPE,$this->AuthorityType->getSelectedValue());
		if ($this->IsPart->getChecked())
			$criteria->add(AuthorityPeer::SORT_TEXT,$this->Title->getText());
		else
			$criteria->add(AuthorityPeer::SORT_TEXT,'%'.$this->Title->getText().'%',Criteria::LIKE);
		$criteria->setLimit(50);
		$this->catrescnt = AuthorityPeer::doCount($criteria);
		$authorities = AuthorityPeer::doSelect($criteria);
		$ds = array();
		/* @var $a Authority */
		foreach ($authorities as $a) {
			$ds[] = array(
				'authid'	=> $a->getAuthorityId(),
				'desc'		=> htmlentities($a->getFullText(),ENT_COMPAT,'UTF-8'),
				'rectype'	=> LookupValuePeer::getLookupValue('AUTHRECTYPE',$a->getAuthorityRectype()),
			);
		}
		$this->CatalogResults->setDataSource($ds);
		$this->CreateAuth->setVisible(true);
		$this->dataBind();
	}


	public function onInsertAuth($sender, $param) {
		$title = $this->Title->getText();
		$authType = $this->getViewState('authType');
		$this->gotoPage('Catalog.AuthorityEditPage', array('Title' => $title, 'authType' => $authType));
	}

}
