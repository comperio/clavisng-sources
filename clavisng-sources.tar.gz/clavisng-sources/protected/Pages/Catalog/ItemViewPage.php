<?php
/**
 * ItemViewPage class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Pages.Catalog
 */

/**
 * ItemViewPage Class
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Pages.Catalog
 * @since 2.0
 */
class ItemViewPage extends ClavisPage
{
	public $_module = 'CATALOG';
    /**
     * @var Item
     */
	private $_item = null;
	/* @var ClavisSBN */
	protected $_sbnMod;

	public function onInit($param)
	{
		parent::onInit($param);

		if (!$this->getIsPostBack()
				&& !$this->getIsCallback())
		{
		    $id = intval($this->getRequest()->itemAt('id'));
			
			if ($id > 0)
			{
				$item = ItemQuery::create()->findPK($id);
			
				if (!($item instanceof Item))
				{
					$this->writeMessage(Prado::localize("L'esemplare con id = {id} non esiste", 
															array('id' => $id)),
											ClavisMessage::ERROR);
					
					$this->gotoPage('Catalog.ItemListPage');
				}
				
				$this->setItem($item);
				$this->ItemActions->setItemId($id);
				$this->ShelfList->setObjectParameters('item', $this->_item->getItemId(), false);
			}
			else
			{
				$item = new Item();
				$this->setItem($item);
			}

			$this->AuthorityLink->setItemId($item->getItemId());
			$this->AuthorityLink->populate();
			$this->Notes->setItem($this->getItem());
			$this->ItemActionList->setObject($this->_item);
			$this->LoanList2->setObject($this->_item);

			$selectTab = intval($this->getRequest()->itemAt('selectTab'));
			
			if ($selectTab > 0)
				$this->TabPanel->setActiveViewIndex($selectTab);

			$action = TPropertyValue::ensureString($this->getRequest()->itemAt('action'));
			
			if ($action == 'openReserve')
			{
				$this->ItemActions->setOpenReservePanel(true);
				$this->TabPanel->setActiveViewID('ActionsTabView');
			}
			elseif ($action == 'openLoan')
			{
				$this->ItemActions->setOpenLoanPanel(true);
				$this->TabPanel->setActiveViewID('ActionsTabView');
			}
		}
	}

	public function onLoad($param)
	{
		parent::onLoad($param);

		$this->_sbnMod = $this->getApplication()->getModule('sbn');

		$myUser = $this->getUser();
		$item = $this->getItem();

		if (!$this->getIsPostBack()
				&& !$this->getIsCallback())
		{
			$shelfList = ShelfPeer::getVisibleShelves($myUser, ShelfPeer::TYPE_ITEM);
            $datasource = array();
			
			foreach ($shelfList as $shelf)
			{	
				if ($shelf->isEditable($this->getUser()))
					$datasource[$shelf->getShelfId()] = "({$shelf->getShelfId()}) "
						. substr(strip_tags($shelf->getShelfName()), 0, 20);
			}
			
			$this->ToShelf->setDataSource($datasource);
			$this->ToShelf->dataBind();

			$actualShelfId = $myUser->getActualShelfId();
			
			if (!is_null($actualShelfId))
			{
				try
				{
					$this->ToShelf->setSelectedValue($actualShelfId);
				}
				catch (Exception $error)
				{
					Prado::log('Lo scaffale preferito non esiste');
					$myUser->setActualShelfId(null);
				}
			}

			$manifestation = $item->getManifestation();
			
			if ($manifestation instanceof Manifestation)
			{
				$this->ManifestationYesPanel->setVisible(true);
				$this->ManifestationNoPanel->setVisible(false);
				$this->ManifestationView->setManifestation($item->getManifestation());
			}
			else
			{
				$this->ManifestationYesPanel->setVisible(false);
				$this->ManifestationNoPanel->setVisible(true);
				$this->ItemTitle->setText($item->getTitle());
			}

			$this->ItemView->setItem($item);
			$this->UpdateData->setObject($item);
			$this->Requests->setObject($item);
			$this->ItemActionList->setObject($item);
		}

		if ($item instanceof Item) 
		{
			$modifyEnabled = $myUser->getEditPermission($item);
			$hasActiveLoans = $item->IsLoaned();
		}
		else 
		{
			$modifyEnabled = false;
			$hasActiveLoans = true;
		}

		$this->Modify->setEnabled($modifyEnabled);
		$this->EraseButton->setVisible($modifyEnabled && $item->isDeleteable());
		$this->SubstManifButton->setVisible($modifyEnabled && !$hasActiveLoans && $this->ManifestationYesPanel->getVisible());
		$this->ItemReplaceButton->setVisible($modifyEnabled && !$hasActiveLoans);

		if ($this->getIsPostBack()
				|| $this->getIsCallback())
		{
			$updateItemRequests = $this->getApplication()->getSession()->itemAt('UpdateItemRequests');
			
			if (!is_null($updateItemRequests) && ($updateItemRequests == true))
			{
				$this->getApplication()->getSession()->remove('UpdateItemRequests');
				$this->Requests->globalRefresh();
			}
		}

		/* What code below do? Print always an empty row and?
		if (true)
		{
			Prado::log($this->ZebraPrintFront->getHasControls());
		}
		 * 
		 */
		
		$this->SBNTabView->setVisible($this->_sbnMod->getEnabled()
											&& $this->_item instanceof Item
											&& !$this->_item->isNew()
											&& $this->_item->getManifestation() instanceof Manifestation);
	}

	public function onPreRender($param)
	{
		parent::onPreRender($param);

		if ($this->SBNTabView->getVisible())
		{
			switch ($this->SBNActions->getSbnStatus())
			{
				case 'unlocalizable':
					$this->SBNTabView->setCaption('SBN <img style="border:0;margin:0;padding:0;height:12px;" src="themes/Default/icons/nav_plain_red-16.png" />');
			
					break;
				
				case 'localizable':
					$this->SBNTabView->setCaption('SBN <img style="border:0;margin:0;padding:0;height:12px;" src="themes/Default/icons/nav_plain_yellow-16.png" />');
				
					break;
				
				default:
					$this->SBNTabView->setCaption('SBN <img style="border:0;margin:0;padding:0;height:12px;" src="themes/Default/icons/nav_plain_green-16.png" />');
			}
		}

		$tempManifestationId = intval($this->RecordChooser->getManifestationId());

		if ($tempManifestationId > 0)
			$this->TempManifestationId->setValue($tempManifestationId);

		$tempManifestationVisibleFlag = ($tempManifestationId > 0);
		$this->ManifestationLinkConfirmPanel->setVisible($tempManifestationVisibleFlag);
		$this->ManifestationLinkConfirmButton->setVisible($tempManifestationVisibleFlag);
		
		if (intval($this->LoanList2->FoundNumber->getText()) > 0)
			$this->EraseButton->setVisible(false);
	}

	public function onPreRenderComplete($param)
	{
		parent::onPreRenderComplete($param);
	}

	public function onJRPrint($sender, $param)
	{
		$this->JRPBox->printReport();
	}
	
	public function itemModify($sender, $param)
	{
		$this->gotoPage("Catalog.ItemInsertPage", array("id" => $this->_item->getItemId()));
	}

	public function onSubstManifestation($sender, $param)
	{
		$itemId = intval($this->getItemId());
	
		if ($itemId > 0)
			$this->gotoPage('Catalog.ItemReplace', array('itemId' => $itemId));
	}

	public function setItem($item)
	{
		$this->_item = $item;
		$this->setViewState('item', $item, null);
	}

	public function getItem()
	{
		$this->_item = $this->getViewState('item', null);
	
		return $this->_item;
	}

	public function getItemId()
	{
		$item = $this->getItem();
		
		if (!is_null($item))
		{
			return $item->getItemId();
		}
		else
		{
			return "";
		}
	}

	/**
	 * This method unlinks a item item from a library.
	 *
	 * The function "forceLastItemItemCriteria, in the object,
	 * is needed to force the recalculation of the item
	 * links in case one row in that table is removed.
	 *
	 * @param int $objectId
	 * @param string $objectClass
	 */
	public function unLinkItemItem($objectId, $objectClass)
	{
		if ($objectClass !== '' and $objectId != 0)
		{
			$itemId = $this->_item->getItemId();

			$criteria = new Criteria();
			$criteria->add(ItemItemPeer::SHELF_ID, $itemId);
			$criteria->add(ItemItemPeer::OBJECT_ID, $objectId);
			$criteria->add(ItemItemPeer::OBJECT_CLASS, $objectClass);
			ItemPeer::doDelete($criteria);

			$this->_item->forceReloadItem();
			$this->setItem($this->_item);
			$this->globalRefresh();
		}
	}

	/**
	 * It is called by one of the inner components, and
	 * performs the population (refresh) of all the components
	 * (the calling is included).
	 *
	 */
	public function globalRefresh()
	{
		$this->ItemView->populate();
		$this->ShelfList->populate();
		$this->SBNActions->populate();
	}

	/**
	 * It's called by one of the inner componentes, and
	 * performs the "cancel" (return to non-edit status)
	 * of all the components (the calling is included).
	 *
	 * @param TControl $component
	 */
	public function globalCancel($component)
	{
		if ($component !== $this->ItemView)
			$this->ItemView->onCancel(null, null);
	
		if ($component !== $this->ShelfList)
			$this->ShelfList->onCancel(null, null);
	}

	/**
	 * Whether this page can have components where the menus
	 * inside can generate unlink menus.
	 *
	 * @return boolean
	 */
	public function isUnlink()
	{
		return true;
	}

	/**
	 * Whether this page can have components where the
	 * menus inside can have the standard links that
	 * popups have.
	 *
	 * @return boolean
	 */
	public function isPopup()
	{
		return false;
	}

	public function Unlink($shelfId)
	{
		try
		{
			if (!is_null($shelfId) && is_numeric($shelfId))
			{
				$item = $this->getItem();
			
				if (!is_null($item)
						&& ($item instanceof Item))
				{
					$itemId = $item->getItemId();
					$criteria = new Criteria();
					$criteria->add(ShelfItemPeer::SHELF_ID, $shelfId);
					$criteria->add(ShelfItemPeer::OBJECT_ID, $itemId);
					ShelfItemPeer::doDelete($criteria);
					$this->globalRefresh();
				}
			}
		}
		catch (PropelException $e)
		{
			// dummy
		}
	}

	public function onReplaceItem($sender, $param)
	{
		$srcItem = $this->_item;
		$dstItem = ItemQuery::create()->findPK($this->ReplaceItemId->getValue());

		if (!($srcItem instanceof Item)
				|| (!$dstItem instanceof Item))
		{
			$this->writeMessage(Prado::localize("L'esemplare di partenza o l'esemplare su cui schiacciare non sono validi."), ClavisMessage::ERROR);
		
			return;
		}
		try
		{
			$srcItemId = $srcItem->getItemId();
			$dstItemId = $dstItem->getItemId();
			$srcItem->replaceWith($dstItem, $this->getUser());
		
			$this->writeMessage(Prado::localize("L'esemplare {srcItemId} è stato correttamente schiacciato sull'esemplare {dstItemId}.",
														array(	'srcItemId' => $srcItemId,
																'dstItemId' => $dstItemId)),
									ClavisMessage::INFO);
			
			$this->gotoPage('Catalog.ItemViewPage', array('id' => $dstItemId));
		}
		catch (Exception $e)
		{
			$this->writeMessage(Prado::localize("Errore nella sostituzione dei dati dell'utente: {msg}",
														array('msg' => $e->getMessage())),
									ClavisMessage::ERROR);

			Prado::log(__METHOD__ . " ERROR: {$e->getMessage()}");
		}
	}

	public function itemErase($sender, $param) 
	{
		$loans = $this->_item->getLoans();

		if (count($loans) > 0)
		{
			$this->writeMessage(Prado::localize("Sull'esemplare sono stati effettuati prestiti. Non è possibile eliminarlo dal database"),
									ClavisMessage::ERROR);

			return false;
		}

		try
		{
			$manid = $this->_item->getManifestationId();
			$itemid = $this->_item->getItemId();
			$title = $this->_item->getTrimmedTitle(50);

			ChangelogPeer::logAction(	$this->_item,
										ChangelogPeer::LOG_DELETE,
										$this->getUser(),
										'Cancellato esemplare con id ' . $itemid);
			
			$this->_item->delete();

			/**
			 * elimination of authorities that are related to this item
			 */
			$criteria = new Criteria();
			$criteria->add(LAuthorityItemPeer::ITEM_ID, $itemid);
			LAuthorityItemPeer::doDelete($criteria);

			/**
			 * elimination of itemrequests that are related to this item
			 */

			$itemRequests = $this->_item->getItemRequests();
			
			if (!is_null($itemRequests) && is_array($itemRequests))
			{
				foreach ($itemRequests as $itemRequest)
				{
					$itemRequest->setItemId(null);
					$itemRequest->save();
			
					ChangelogPeer::logAction(	$itemRequest,
												ChangelogPeer::LOG_UPDATE,
												$this->getApplication()->getUser(),
												"Modifica della prenotazione con id={$itemRequest->getRequestId()}: levata prenotazione per per esemplare (cancellato) e lasciata per notizia.");
				}
			}
			
			$this->writeMessage(Prado::localize("Operazione conclusa con successo: l'esemplare con id: {id} '{title}' è stato eliminato",
													array(	'id' =>$itemid,
															'title' => $title )), 
									ClavisMessage::CONFIRM);

			/**
			 * If manifestation_id exists (not OOC) we redirect to Manifestation page
			 * with a manifestation_id search parameter.
			 * Otherwise we goto that page without any parameter.
			 */
			if (is_null($manid))
			{
				$this->gotoPage('Catalog.RecordList');
			}
			else
			{
				$this->gotoPage('Catalog.Record', array('manifestationId' => $manid));
			}
		}
		catch (Exception $e)
		{
			ChangelogPeer::logAction(	$this->_item, ChangelogPeer::LOG_ERROR,
										$this->getUser(),
										"Errore nell'eliminazione esemplare con id " . $itemid);
			
			$this->writeMessage(Prado::localize("Errore nell'eseguire l'operazione. L'esemplare non è stato eliminato. Si prega di contattare il fornitore del software."),
									ClavisMessage::ERROR);
		}
	}

	/**
	 * Adds this item to a shelf (taken from a popup list).
	 *
	 */
	public function onAddToShelf($sender, $param)
	{
		$shelfId = intval($this->ShelfResultValue->getValue());
		$this->doAddToShelf($shelfId);
	}

	/**
	 * User by the 'add to shelf' in the lower right part of screen.
	 *
	 */
	public function onAddToShelf2($sender, $param)
	{
		$shelfId = intval($this->ToShelf->getSelectedValue());
		$this->getUser()->setActualShelfId(intval($shelfId));
		$this->doAddToShelf($shelfId);
	}

	private function doAddToShelf($shelfId)
	{
		$shelf = null;
		$itemId = null;
		$result = false;
		
		if ($shelfId > 0)
			$shelf = ShelfQuery::create()->findPK($shelfId);

		$item = $this->getItem();
		
		if (!is_null($item)
				&& ($item instanceof Item))
			$itemId = intval($item->getItemId());

		if (!is_null($shelf)
				&& !is_null($itemId)
				&& ($itemId > 0))
		{
			$result = $shelf->addItemToShelf(ShelfPeer::TYPE_ITEM, $itemId);
		}
//		else
//		{
//			Prado::log('In itemviewpage, fallito inserimento rapido da scaffale');
//		}

		if ($result)
		{
			$this->getPage()->globalRefresh();
			
			$this->writeMessage(Prado::localize("Esemplare aggiunto allo scaffale '{shelf}'",
													array('shelf' => $shelf->getShelfName())),
									ClavisMessage::INFO);
		}
		else
		{
			$this->writeMessage(Prado::localize("Esemplare non aggiunto a scaffale"),
									ClavisMessage::ERROR);
		}
	}

	public function onLinkManifestation($sender, $param)
	{
		$manifestation = null;
		$manifestationId = intval($this->TempManifestationId->getValue());
		
		if ($manifestationId > 0)
			$manifestation = ManifestationQuery::create()->findPK($manifestationId);
		
		if (!($manifestation instanceof Manifestation))
		{
			$this->writeMessage(Prado::localize("Non è stata scelta alcuna notizia"),
									ClavisMessage::ERROR);
		
			return false;
		}
		
		$this->_item = $this->getItem();
		$this->_item->setManifestationId($manifestationId);
		$this->_item->setTitle($manifestation->getTitle());
		$this->_item->setManifestationDewey($manifestation->getClass());

		/**
		$issue = null;
		$issueId = intval($this->TempIssueId->getValue());
		
		if ($issueId > 0)
			$issue = IssueQuery::create()->findPk($issueId);
		*/
		$issue = $this->RecordChooser->getIssue();
		
		if ($issue instanceof Issue)
			$this->_item->setIssue($issue);
		
		$this->_item->save();

		foreach ($this->_item->getItemRequests() as $req) {
		    $req->setManifestationId( $manifestationId);
		    $req->save();
        }
		
		ChangelogPeer::logAction(	$this->_item,
									ChangelogPeer::LOG_UPDATE,
									$this->getUser(),
									'Aggiornamento dati esemplare ' . $this->_item->getItemId());

		$this->writeDelayedMessage(Prado::localize('Modificato esemplare con id: {itemId}',
														array('itemId' => $this->_item->getItemId())),
										ClavisMessage::WARNING);

		// page reload with new data (by self-teleport)
		$this->gotoPage("Catalog.ItemViewPage", array("id" => $this->_item->getItemId()));
	}

	public function onGotoLoan($sender, $param)
	{
		$itemId = intval($this->getItemId());
		
		if ($itemId > 0)
			$this->gotoPage("Circulation.NewLoan", array("itemId" => $itemId));
	}
	
}
