<?php
/**
 * PatronViewPage class file.
 *
 * This file contains all the required classes for SBN dialogue v4.
 * Based upon SBNConnector by Comperio srl.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @author Ciro Mattia Gonano
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Pages.Circulation
 */

/**
 * PatronViewPage Class
 *
 * This page performs the visualization of the data relative
 * to a single patron.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @author Ciro Mattia Gonano
 * @version 2.7
 * @package Pages.Circulation
 * @since 2.0
 */
class PatronViewPage extends ClavisPage
{
	const _18YEARSOLD = 567648000; //86400*365*18
	const AGE_LIMIT = 18;
	const TIMEOUT_LIMIT = 5;

	public $_module = 'CIRCULATION';
	private $_patron = null;
	private $_llibraryActive = false;

	/**
	 * The id of the patron we're treating.
	 *
	 * @var int
	 */
	private $_patronId;

	public function onInit($param)
	{
		parent::onInit($param);

		$this->_llibraryActive = (ClavisParamPeer::getParam('LLIBRARY_ACTIVE') == 1);

		if (!$this->getIsPostBack())
		{
			$this->setPatronId(null);
			$patron = null;
			$id = intval($this->getRequest()->itemAt('id'));

			$this->setPatronId($id);
		
			if ($id > 0)
			{
				$patron = PatronQuery::create()->findPk($id);
			
				if (!($patron instanceof Patron))
					$this->onPatronExistsError($id);

				$this->setPatron($patron);
				$this->UpdateData->setObject($this->_patron);
				$this->PatronView->setPatronId($id);
				$this->PatronSummary->populateView($id);
				$this->ShelfList->setObjectParameters('patron', $this->getPatronId());
				$this->populateRelativesList();
				$this->ItemActionList->setObject($this->_patron);
				$this->PatronActionList->setObject($this->_patron);

				$this->ItemRequestList->setObject($this->_patron);
				///// da finire $this->RequestsList->setObject($this->_patron);

				$this->CurrentLoanList->setObject($this->_patron);
				$this->OldLoanList->setObject($this->_patron);

                $this->WalletList->setObjectId($id);
				
                if ($this->getApplication()->getModule("fee") instanceof TModule)
                    $this->FeeList->setPatronId($id);

				if (!$patron->getBirthDate() && !$this->getIsCallback())
				{
					$this->appendDelayedMessage(Prado::localize("L'utente non ha una data di nascita"),
													ClavisMessage::WARNING);
				}
				elseif (($patron->getPatronAge() < self::AGE_LIMIT)
							&& !$this->getIsCallback())
				{	
					$this->appendDelayedMessage(Prado::localize("L'utente è un minore di 18 anni"),
													ClavisMessage::WARNING);
				}
				
				$this->NotificationList->setObjectClass("patron");
				$this->NotificationList->setObjectId($patron->getPatronId());
				$this->NotificationList->populate();

				$this->AttachmentManager->setObjectClass("Patron");
				$this->AttachmentManager->setObjectId($patron->getPatronId());
				$this->populateResourceOwnerDDList();
			}
			else
			{
				$this->onPatronExistsError($id);
			}
		}

		$activeViewId = $this->TabPanel->getActiveViewId();
		
		if ($activeViewId != 'LoanTab' && false) {
			$this->CurrentLoanList->setPopulable(false);
			$this->OldLoanList->setPopulable(false);
		}
		
		$this->flushDelayedMessage();
	}

	/**
	 * On the onLoad we populate the textbox "Title" if the proper
	 * value is passed as a get parameter, and we must initialize
	 * EACH instance of repeatable list in the page (by $this->addItem).
	 *
	 * @param TEventParameter $param
	 */
	public function onLoad($param)
	{
		parent::onLoad($param);

		$this->getPatron();
		
		/* caricamento dei dati nella form */
		if (!$this->getIsPostBack() && !$this->getIsCallback())
		{
			$this->ReserveDeliveryLibrary->setDataSource(LibraryPeer::getLibrariesHash(null, null, true, true));  // solo attive ...
			$this->ReserveDeliveryLibrary->dataBind();
			$this->ReserveDeliveryLibrary->setSelectedValue($this->getUser()->getActualLibraryId());

			$popupUrl = 'MyHomePage.ChangelogPopup&objectClass=Patron&objectId=' . $this->getPatronId()
							. '&eventType=' . ChangelogPeer::LOG_PATRONCARDPRINT;
			
			$this->PrintCardHistoryPopup->setPopupPage($popupUrl);
		}
		
		if (!is_null($this->_patron)
				&& ($this->_patron instanceof Patron))
		{
			$modifyEnabled = $this->getUser()->getEditPermission($this->_patron);
			$this->ResourceRuleList->setFilterByPatron($this->_patron->getPatronId());
			$this->ResourceSessionList->setFilterByPatron($this->_patron->getPatronId());
			$this->ResourceSessionList->setHideClosed(TRUE);
			$this->OldResourceSessionList->setFilterByPatron($this->_patron->getPatronId());
			$this->OldResourceSessionList->setHideActive(TRUE);
			$timeUsed = $this->_patron->getSessionTime(time(), NULL, NULL);
		
			if (is_array($timeUsed))
			{
				$dow = date('w', time());
				$td = 0;
				$tw = 0;
				
				foreach($timeUsed as $idx => $dayTime)
				{
					if ($idx == $dow)
						$td = $dayTime;
					
					$tw += $dayTime;
				}
				
				$format = "%h ore e %i minuti";
				$thistime = new Datetime();
				
				//$td = $timeUsed['day'];
				if ( $td > 0)
				{
					$daydt = new DateTime();
					$daydt->add(new DateInterval('PT' . $td . 'S'));
					$diff = $daydt->diff($thistime);
					$this->GlobalDayTime->Text = $diff->format($format);
				}
				else
				{
					$this->GlobalDayTime->Text = '0';
				}
				
				//$tw = $timeUsed['week'];
				if ( $tw > 0 )
				{
					$weekdt = new DateTime();
					$weekdt->add(new DateInterval('PT' . $tw . 'S'));
					$diff = $weekdt->diff($thistime);
					$this->GlobalWeekTime->Text = $diff->format($format);
				}
				else
				{
					$this->GlobalWeekTime->Text = 0;
				}
			}
			else
			{
				Prado::log("timeused is not an array", TLogger::DEBUG, "LLDebug");
			}
			/*
			$NMurl = ClavisParamQuery::getParam('CLAVISPARAM','NetManager');
			if (!$NMurl) {
				$this->NetManagerTab->setVisible(false);
			} else {
				$context = stream_context_create(array('http' => array('timeout'=> self::TIMEOUT_LIMIT)));
				$this->NetManagerTab->setVisible(true);
				$library = $this->getUser()->getActualLibrary();
				if ($library instanceof Library) {
					$srcUrl = $NMurl . '/index.php?r=nm_patron_wallet/clavisPatSummary' .
						'&library_code=' . $library->getLibraryCode() .
						'&library_id=' . $library->getLibraryId() .
						'&consortia_id=' . $library->getConsortiaId() .
						'&librarian_id=' . $this->getUser()->getId() .
						'&patron_id=' . $this->_patron->getPatronId();
					$fget = @file_get_contents($srcUrl, false, $context);
					$this->NetManagerWallet->setText(
						($fget === false) ?
							Prado::localize('<em>Server NetManager temporaneamente non disponibile.</em>') :
							$fget);
					$srcUrl = $NMurl . '/index.php?r=nm_navigation_session/clavisPatSummary' .
						'&library_code=' . $library->getLibraryCode() .
						'&library_id=' . $library->getLibraryId() .
						'&consortia_id=' . $library->getConsortiaId() .
						'&librarian_id=' . $this->getUser()->getId() .
						'&patron_id=' . $this->_patron->getPatronId();
					$fget = @file_get_contents($srcUrl, false, $context);
					$this->NetManagerNavigation->setText(
						($fget === false) ?
							Prado::localize('<em>Server NetManager temporaneamente non disponibile.</em>') :
							$fget);
					$srcUrl = $NMurl . '/index.php?r=nm_userful_session/clavisPatSummary' .
						'&library_code=' . $library->getLibraryCode() .
						'&library_id=' . $library->getLibraryId() .
						'&consortia_id=' . $library->getConsortiaId() .
						'&librarian_id=' . $this->getUser()->getId() .
						'&patron_id=' . $this->_patron->getPatronId();
					$fget = @file_get_contents($srcUrl, false, $context);
					$this->NetManagerUserful->setText(
						($fget === false) ?
							Prado::localize('<em>Server NetManager temporaneamente non disponibile.</em>') :
							$fget);
				}
			}
			 * 
			 */
		}
		else
		{
			$modifyEnabled = false;
		}
		
		$this->Edit->setEnabled($modifyEnabled);
		$this->PatronReplaceButton->setVisible($modifyEnabled);
		$this->PatronNotifyButton->setVisible($this->getUser()->checkAllowedPage('Communication.NotificationInsertPopup'));

		if ($this->getIsPostBack()
				|| $this->getIsCallback())
		{
            $this->ShelfList->globalRefresh();
			$updateItemRequests = $this->getApplication()->getSession()->itemAt('UpdateItemRequests');
		
			if (!is_null($updateItemRequests)
					&& ($updateItemRequests == true))
			{
				$this->getApplication()->getSession()->remove('UpdateItemRequests');
				$this->ItemRequestList->globalRefresh();
			}

			// aggiorno la lista delle notifiche se settato UpdatePatronNotificationsList.
            // ---------------------------------------------------------------------------------------------------------
            $updateNotificationsList = $this->getApplication()->getSession()->itemAt('UpdatePatronNotificationsList');
            if ($updateNotificationsList)
            {
                $this->getApplication()->getSession()->remove('UpdatePatronNotificationsList');
                $this->NotificationList->populate();

                // without this instruction the labels on the page are wiped out.
                $this->PatronView->populate();
            }
		}
	}

	public function onPreRender($param)
	{
		parent::onPreRender($param);
		
		$this->populateReservePanel();
	}

	public function onPatronExistsError($id = 0)
	{
		$message = ($id > 0
						? Prado::localize("L'utente con id [{id}] non esiste.",
												array('id'=>$id))
						: Prado::localize("L'utente non è specificato."));
		
		$this->writeMessage($message,
								ClavisMessage::ERROR);
		
		$this->gotoPage('Circulation.PatronList');
	}

	/**
	 * We go to the page which performs the editing of
	 * this patron.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onPatronEdit($sender, $param)
	{
		$this->gotoPage("Circulation.PatronPage",
							array("id" => $this->getPatronId()));
	}

	public function setPatronId($id)
	{
		$this->_patronId = $id;
		$this->PatronId->setValue($this->_patronId);
	}

	/**
	 * It is called by one of the inner components, and
	 * performs the population (refresh) of all the components
	 * (the calling one is included).
	 *
	 */
	public function globalRefresh()
	{
		$this->PatronView->populate();
		$this->ShelfList->populate();
		$this->populateRelativesList();
		//$this->ItemActionList->populate();

		$this->ItemRequestList->populate();
		///// da finire $this->RequestsList->populate();

		$this->CurrentLoanList->populate();
		$this->OldLoanList->populate();
	}

	public function setPatron($patron = null)
	{
		$this->_patron = $patron;
		$this->setViewState("patron", $patron, null);
	}

	public function getPatron()
	{
		$this->_patron = $this->getViewState("patron", null);
		
		return $this->_patron;
	}

	public function getPatronId()
	{
		$patronId = 0;
		$patron = $this->getPatron();
		
		if (!is_null($patron)
				&& ($patron instanceof Patron))
			$patronId = $patron->getPatronId();

		return $patronId;
	}

	public function getPatronGender()
	{
		$gender = '';
		$patron = $this->getPatron();
		
		if (!is_null($patron)
				&& ($patron instanceof Patron))
			$gender = $patron->getGender();

		return $gender;
	}

	public function patronReload()
	{
		$patron = $this->getPatron();
		
		if (!is_null($patron)
				&& ($patron instanceof Patron))
		{
			$patron->reload(true); // deep reload
			$this->setPatron(PatronQuery::create()->findPk($this->_patron->getPatronId()));
		}
	}

	/**
	 * Callback called for populating a single row of the RelativesList
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function relativeRepeaterDataBound($sender, $param)
	{
		$item = $param->Item;
		$patron_gender = '';
		$patron = $this->getPatron();
		
		if (!is_null($patron)
				&& ($patron instanceof $patron))
			$patron_gender = $patron->getGender();

		if ($item->ItemType == "EditItem")
		{
			$item->edRelativeType->populateList();

			if ($item->edRelativeDirect->Value == "true")
			{
				$item->edRelativeType->SetSelectedValue($item->DataItem["LinktypeIdx"]);
			}
			elseif ($item->edRelativeDirect->Value == "false")
			{
				if ($item->DataItem["LinktypeIdx"] == "AB")
				{
					$item->edRelativeType->SetSelectedValue($item->DataItem["LinktypeIdx"]);
				}
				elseif ($item->DataItem["LinktypeIdx"] == "DC")
				{ //figlio
					if ($patron_gender == "M")
					{
						$item->edRelativeType->SetSelectedValue("CD"); //padre
					}
					elseif ($patron_gender == "F")
					{
						$item->edRelativeType->SetSelectedValue("EF"); //madre
					}
				}
				else
				{
					$item->edRelativeType->SetSelectedValue(strrev($item->DataItem["LinktypeIdx"]));
				}
			}
		}
	}

	/**
	 * This callback is called when one wants to cancel
	 * the editing of a row in the relatives' panel
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function cancelEditRelative($sender, $param)
	{

		$this->RelativesList->SelectedItemIndex = -1;
		$this->RelativesList->EditItemIndex = -1;
		$this->PatronView->populateView($this->getPatronId());
		$this->populateRelativesList();
	}

	/**
	 * This callback is called when one wants to delete
	 * a row in the relatives' panel
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function editRelative($sender, $param)
	{
		$this->RelativesList->SelectedItemIndex = -1;
		$this->RelativesList->EditItemIndex = $param->Item->ItemIndex;

		$this->PatronView->populateView($this->getPatronId());
		$this->populateRelativesList();
	}

	/**
	 * Callback for updating a relative link.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function updateRelative($sender, $param)
	{

		$item = $param->Item;

		$parentId = $this->getPatronId();
		$parent_patron_gender = $this->getPatronGender();
		$str_params = unserialize($param->getCommandParameter());

		$childId = $str_params[0];
		$relativeDirect = $str_params[1];

		if ($relativeDirect == "true")
		{
			$l_patron = LPatronPeer::retrieveByPK($parentId, $childId);
			$l_patron->setLinkType($item->edRelativeType->SelectedValue);

			$l_patron->save();
		}
		elseif ($relativeDirect == "false")
		{
			$l_patron = LPatronPeer::retrieveByPK($childId, $parentId);
		
			if ($item->edRelativeType->SelectedValue == "AB") //fratello
			{
				$l_patron->setLinkType($item->edRelativeType->SelectedValue);
			}
			elseif ($item->edRelativeType->SelectedValue == "DC")
			{ //figlio
				if ($parent_patron_gender == "M")
				{
					$l_patron->setLinkType("CD");
				}
				elseif ($parent_patron_gender == "F")
				{
					$l_patron->setLinkType("EF");
				}
			}
			else
			{
				$l_patron->setLinkType(strrev($item->edRelativeType->SelectedValue));
			}

			$l_patron->save();
		}

		$this->patronReload();

		$id = intval($this->Request['id']);
		if ($id > 0)
		{
			$patron = PatronQuery::create()->findPk($id);
			
			if ($patron instanceof Patron)
				$this->setPatron($patron);
		}

		$this->RelativesList->SelectedItemIndex = -1;
		$this->RelativesList->EditItemIndex = -1;

		$this->PatronView->populateView($this->getPatronId());
		$this->populateRelativesList();
	}

	/**
	 * Callback called for deleting a relative link.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function deleteRelative($sender, $param)
	{

		$str_params = explode("|", $param->getCommandParameter());
		$childId = $str_params[0];
		$relativeDirect = $str_params[1];

		if (!is_null($childId) and is_numeric($childId))
		{
			$parentId = $this->getPatronId(); ///$this->getPatron()->getPatronId();

			if ($relativeDirect == "true")
			{
				$criteria = new Criteria();
				$criterion = $criteria->getNewCriterion(LPatronPeer::PARENT_PATRON_ID, $parentId);
				$criterion2 = $criteria->getNewCriterion(LPatronPeer::CHILD_PATRON_ID, $childId);
				$criterion->addAnd($criterion2);
				$criteria->add($criterion);

				LPatronPeer::doDelete($criteria);

			}
			elseif ($relativeDirect == "false")
			{
				$criteria = new Criteria();
				$criterion = $criteria->getNewCriterion(LPatronPeer::PARENT_PATRON_ID, $childId);
				$criterion2 = $criteria->getNewCriterion(LPatronPeer::CHILD_PATRON_ID, $parentId);
				$criterion->addAnd($criterion2);
				$criteria->add($criterion);

				LPatronPeer::doDelete($criteria);

			}
			
			$this->patronReload(true); // deep reload
		}

		$this->Page->globalRefresh();
		$this->patronReload();

		$id = intval($this->Request['id']);
		
		if ($id > 0)
		{
			$patron = PatronQuery::create()->findPk($id);
			
			if ($patron instanceof Patron)
				$this->setPatron($patron);
		}

		$this->RelativesList->SelectedItemIndex = -1;
		$this->RelativesList->EditItemIndex = -1;

		$this->PatronView->populateView($this->getPatronId());
		$this->populateRelativesList();
	}

	/**
	 * Callback for adding a new relative to the current patron
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onAddRelative($sender, $param)
	{
		$relativeId = $this->ResultValue->getValue();

		try
		{
			if (!is_null($relativeId)
					&& is_numeric($relativeId)
					&& ($relativeId != $this->getPatronId()))
			{
				$relative = new LPatron();
				$relative->setParentPatronId($this->getPatronId());
				$relative->setChildPatronId($relativeId);
				$relative->save();
				
				$this->_patron->reload(true); // deep reload
			}

			$this->populate();

			//immediate edit
			$this->RelativesList->EditItemIndex = 0;
			$this->RelativesList->dataBind();
		}
		catch (Exception $e)
		{
			// dummy
		}
	}

	/**
	 * It populates the list of relatives.
	 *
	 */
	public function populateRelativesList()
	{
		$relativeData = array();
		$relatives = array();

		$patron = $this->getPatron();
		
		if ($patron instanceof Patron)
			$relatives = $patron->getLPatronsRelatedByParentPatronId();

		$edit_relativeId = $this->ResultValue->getValue();

		//DIRETTA (non serve invertire)
		foreach ($relatives as $relative)
		{
			$patron = PatronQuery::create()->findPk($relative->getChildPatronId());

			if ($patron instanceof Patron)
			{
				$p = array();

				$id = $patron->getPatronId();
				$p["id"] = $id;
				$p["Name"] = $patron->getName();
				$p["Lastname"] = $patron->getLastname();
				//$linkType = LookupValuePeer::getLookupValue('PATRONLINKTYPE',$relative->getLinktype());
				$linkType = $relative->getLinktype();

				if ($linkType !== "")
				{
					$p["Linktype"] = LookupValuePeer::getLookupValue('PATRONLINKTYPE', $linkType);
				}
				else
				{
					$p["Linktype"] = "---";
				}
				
				$p["LinktypeIdx"] = $linkType;
				$p["RelativeDirect"] = "true";

				if ($id != $edit_relativeId)
				{
					$relativeData[] = $p;
				}
				else
				{
					array_unshift($relativeData, $p);
				}
			}
		}
		
		//INVERSA (bisogna prendere il reciproco)
		$relatives = array();
		$patron = $this->getPatron();
		
		if (!is_null($patron)
				&& ($patron instanceof Patron))
			$relatives = $patron->getLPatronsRelatedByChildPatronId();
		
		foreach ($relatives as $relative)
		{
			$patron = PatronQuery::create()->findPk($relative->getParentPatronId());

			if ($patron instanceof Patron)
			{
				$patron_gender = $patron->getGender();
				$p = array();
				$id = $patron->getPatronId();

				$p["id"] = $id;
				$p["Name"] = $patron->getName();
				$p["Lastname"] = $patron->getLastname();

				$linkType = $relative->getLinktype();

				if ($linkType !== '')
				{
					if ($linkType == 'DC')
					{ //figlio: in inverse devo trovare se il patron e' padre o madre
						switch ($patron_gender)
						{
							case 'F':
								$p["Linktype"] = LookupValuePeer::getLookupValue('PATRONLINKTYPE', 'EF'); //madre
							case 'M':
							default:
								$p["Linktype"] = LookupValuePeer::getLookupValue('PATRONLINKTYPE', 'CD'); //padre
						
								break;
						}
					}
					else
					{
						// get reverse
						$p["Linktype"] = LookupValuePeer::getLookupValue('PATRONLINKTYPE', $linkType, true);
					}
				}
				else
				{
					$p["Linktype"] = '---';
				}

				$p["LinktypeIdx"] = $linkType;
				$p["RelativeDirect"] = "false";

				if ($id != $edit_relativeId)
				{
					$relativeData[] = $p;
				}
				else
				{
					array_unshift($relativeData, $p);
				}
			}
		}

		if ($patron instanceof Patron)
			$patron->reload(true); // deep reload

		$this->RelativesList->DataSource = $relativeData;
		$this->RelativesList->dataBind();
	}

	public function populate()
	{
		$this->patronReload();
		$this->ShelfList->setObjectParameters('patron', $this->getPatronId());		/// provato a cambiare di posto, guarda appena sotto
		$this->getPage()->globalRefresh();

		$patron = PatronQuery::create()->findPk($this->getPatronId());
		
		if ($patron === null)
			$this->gotoPage("ErrorPage");
		
		$this->setPatron($patron);

		$this->PatronView->populateView($this->getPatronId());
		/////$this->ShelfList->setObjectParameters('patron', $this->getPatronId());
		$this->UpdateData->setObject($this->getPatron());
		$this->populateRelativesList();
		
		$this->WalletList->reloadData();
	}

	public function globalCancel($component)
	{
		if ($component !== $this->PatronView)
			$this->PatronView->onCancel(null, null);
		
		if ($component !== $this->ShelfList)
			$this->ShelfList->onCancel(null, null);
		
		if ($component !== $this->RelativesList)
			$this->RelativesList->cancelEditRelative(null, null);
		
		if ($component !== $this->ItemActionList)
			$this->ItemActionList->onCancel(null, null);
		
		if ($component !== $this->ItemRequestList)
		{
			$this->ItemRequestList->onCancel(null, null);
			///// da finire $this->RequestsList->onCancel(null, null);
		}
	}

	public function onAddToShelf($sender, $param)
	{
		$successCount = 0;
		$shelfId = $this->ShelfResultValue->getValue();
		
		if (is_numeric($shelfId)
				&& !is_null($shelfId))
		{
			$shelf = ShelfQuery::create()->findPk($shelfId);
			
			if ($shelf instanceof Shelf)
				$successCount = $shelf->addItemToShelf('patron', $this->getPatronId());
		}
		
		if ($successCount > 0)
		{	
			$this->getPage()->writeMessage(Prado::localize("Utente '{patronName}' (id: {patronId}) aggiunto allo scaffale '{shelfName}' (id: {shelfId})",
																array(	'patronName' => $this->getPatron()->getCompleteName(),
																		'patronId' => $this->getPatronId(),
																		'shelfName' => $shelf->getShelfCompleteName(),
																		'shelfId' => $shelf->getShelfId() )),
												ClavisMessage::CONFIRM);
			$this->getPage()->globalRefresh();
			$this->setFocus($this->AddToShelfLink->getClientID());
		}
		else
		{
			$this->getPage()->writeMessage(Prado::localize("Utente '{patronName}' (id: {patronId}) non aggiunto allo scaffale '{shelfName}' (id: {shelfId}) a causa di errori",
																array(	'patronName' => $this->getPatron()->getCompleteName(),
																		'patronId' => $this->getPatronId(),
																		'shelfName' => $shelf->getShelfCompleteName(),
																		'shelfId' => $shelf->getShelfId() )),
												ClavisMessage::ERROR);
		}
	}

	/**
	 * It returns whether this page can have components where
	 * "unlink" methods are present.
	 *
	 * @return boolean
	 */
	public function isUnlink()
	{
		return true;
	}

	public function onGotoLoan($sender, $param)
	{
		$patronId = intval($this->getPatronId());
		
		if ($patronId > 0)
			$this->gotoPage("Circulation.NewLoan",
								array("patronId" => $patronId));
	}

	public function onGotoRequests($sender, $param)
	{
		$patronId = intval($this->getPatronId());
		
		if ($patronId > 0)
			$this->gotoPage("Circulation.ManageRequests",
								array("patronId" => $patronId));
	}
	
	public function onReplacePatron($sender, $param)
	{
		$patronSourceId = intval($this->getPatronId());
		$patronDestId = intval($this->ResultPatronId->getValue());

		if (($patronSourceId > 0)
				&& ($patronDestId > 0))
		{
			if ($patronSourceId == $patronDestId)
			{
				$this->writeMessage(Prado::localize("Sostituzione non effettuata: l'utente sorgente è uguale all'utente destinazione"),
										ClavisMessage::WARNING);
					
				return false;
			}
			
			$patronSource = PatronQuery::create()->findPk($patronSourceId);
			$patronDest = PatronQuery::create()->findPk($patronDestId);

			if (($patronSource instanceof Patron)
					&& ($patronDest instanceof Patron))
			{
				if ($patronSource->replaceWith($patronDest))			//, $this->getUser());)
				{
					$this->writeDelayedMessage(Prado::localize("Dati utente con id={patronSourceId} sostituiti con successo con dati dell'utente con id={patronDestId}.",
																	array(	'patronSourceId' => $patronSourceId,
																			'patronDestId' => $patronDestId)),
													ClavisMessage::CONFIRM);
					
					$this->gotoPage('Circulation.PatronViewPage',
										array('id' => $patronDestId));
				} 
				else
				{
					$this->writeMessage(Prado::localize("Errore interno nella sostituzione dei dati dell'utente"),
											ClavisMessage::ERROR);
				}
			}
			else
			{
				$this->writeMessage(Prado::localize("Errore nella sostituzione dei dati dell'utente"),
										ClavisMessage::ERROR);
			}
		}
	}

	public function populateReservePanel()
	{
		$manifestation = $this->RecordChooser->getManifestation();
		
		if ($manifestation instanceof Manifestation)
		{
			$this->ManifestationReservePanel->setVisible(true);
			$this->calculateReservable();
			$this->populateMaxDistance($manifestation, $this->getUser()->getActualLibraryId());
		}
		else
		{
			$this->ManifestationReservePanel->setVisible(false);
		}
	}

	public function onReserveDeliveryLibraryChanged($sender, $param)
	{
		$this->calculateReservable();
	}

	private function calculateReservable()
	{
		$manifestation = $this->RecordChooser->getManifestation();
		$patron = $this->getPatron();
		$deliveryLibraryId = $this->ReserveDeliveryLibrary->getSelectedValue();
		$this->drawReserveButton($manifestation, $patron, $deliveryLibraryId);
	
		if ($this->_llibraryActive)
			$this->populateMaxDistance($manifestation, $deliveryLibraryId);
	}

	private function drawReserveButton(Manifestation $manifestation, Patron $patron, $deliveryLibraryId)
	{
		$reserve = false;
		
		switch ($this->getApplication()->getModule('request')->isManifestationReservable(	$manifestation,
																							null,
																							$patron,
																							$deliveryLibraryId))
		{
			case ClavisLoanManager::OK:
				$this->getPage()->writeMessage(Prado::localize("La prenotazione è consentita"),
													ClavisMessage::INFO);
				
				$reserve = true;
				
				break;

			case ClavisLoanManager::RSV_NOTAVAIL:
				$this->getPage()->writeMessage(Prado::localize("Attenzione: la prenotazione viene consentita, però al momento nessun esemplare nel sistema può soddisfarla."),
													ClavisMessage::WARNING);
				
				$reserve = true;
				
				break;

            case ClavisLoanManager::RSV_PATRONDISABLED:
                $this->getPage()->writeMessage(Prado::localize("Utente non abilitato"),
													ClavisMessage::ERROR);
				
                break;

			case ClavisLoanManager::RSV_PATRONMAXREQ:
				$this->getPage()->writeMessage(Prado::localize("L'utente ha già raggiunto il massimo numero di prenotazioni [{count}].",
																	array('count'=>ClavisParamPeer::getParam('MAXLOANRESERVATIONS_'.$patron->getLoanClass(), '0'))),
													ClavisMessage::ERROR);
				
				break;

			case ClavisLoanManager::RSV_PATRONREQMANIF:
				$this->getPage()->writeMessage(Prado::localize("L'utente ha già una prenotazione per questo titolo."),
													ClavisMessage::ERROR);
				
				break;

			case ClavisLoanManager::RSV_RATING:
				$this->getPage()->writeMessage(Prado::localize("Prenotazione non possibile perchè utente minore dell'età consentita dal titolo."),
													ClavisMessage::ERROR);
				
				break;

			case ClavisLoanManager::ERROR:
			default:
				$this->getPage()->writeMessage(Prado::localize("Errore: esemplare non prenotabile da questo utente"),
													ClavisMessage::ERROR);
				
				break;
		}
		
		$this->DoReserve->setEnabled($reserve);
	}

	private function populateMaxDistance($manifestation, $deliveryLibraryId)
	{
		// if basin system is active
		if ($this->_llibraryActive)
		{
			$this->MaxDistancePanel->setCssClass('panel_on');
			$distances = LLibraryPeer::calculateRequestDistances(false);

			if (count($distances) > 0)	// there are results
			{
				$this->MaxDistance->setCssClass('panel_on_inline');
				$this->MaxDistanceNoResult->setCssClass('panel_off');

				$this->MaxDistance->setDataSource($distances);
				$this->MaxDistance->dataBind();

				$minDistance = $this->getApplication()->getModule('request')->calculateMinRequestDistance($manifestation, $deliveryLibraryId);
				
				if (!is_null($minDistance))
				{
					if (array_key_exists($minDistance, $distances))
					{
						$selectedDistance = $minDistance;
					}
					else
					{
						$selectedDistance = 0;
					}

					$this->MaxDistance->setSelectedValue($selectedDistance);
				}
			}
			else	// no results
			{
				$this->MaxDistance->setCssClass('panel_off');
				$this->MaxDistanceNoResult->setCssClass('labelError');
			}
		}
		else	// basin system is not active
		{
			$this->MaxDistancePanel->setCssClass('panel_off');
		}

		if ($this->getPage()->getIsCallback())
			$this->MaxDistancePanel->render($this->getPage()->createWriter());
	}

	public function onReserveManifestation($sender, $param)
	{
		$this->cleanMessageQueue();

		$manifestation = $this->RecordChooser->getManifestation();
		$patron = $this->getPatron();

		$clavisLibrarian = $this->getUser();
		$deliveryLibrary = LibraryQuery::create()->findPk($this->ReserveDeliveryLibrary->getSelectedValue());

		$request_note = $this->RequestNote->getSafeText();
		$maxDistance = $this->_llibraryActive
							? $this->MaxDistance->getSelectedValue()
							: null;

		$returnVal = $this->getApplication()->getModule('request')->reserveManifestation(	$manifestation,
																							$patron,
																							$deliveryLibrary,
																							$clavisLibrarian,
																							$request_note,
																							
																							null,
																							null,
																							$maxDistance);

		if (in_array($returnVal, array(ClavisLoanManager::OK, ClavisLoanManager::RSV_NOTAVAIL)))
		{
			$this->enqueueMessage(Prado::localize("Notizia prenotata: '{title}' [id: {id}] per l'utente {patronName}",
														array(	'title' => $manifestation->getTrimmedTitle(40),
																'id' => $manifestation->getManifestationId(),
																'patronName' => $patron->getCompleteName())),
										ClavisMessage::CONFIRM);

			if ($manifestation->getLoanableSince('U') > time())
				$this->enqueueMessage(Prado::localize('La notizia è disponibile solo dal {date}',
															array('date' => Clavis::dateFormat($manifestation->getLoanableSince('U')))),
											ClavisMessage::WARNING);

			if (!$this->getApplication()->getModule('loan')->IsRatingAllowed($manifestation, $patron))
				$this->enqueueMessage(Prado::localize("La notizia è disponibile solo per gli utenti con più di {rating} anni",
															array('rating' => $manifestation->getRating())),
											ClavisMessage::WARNING);

			if ($returnVal == ClavisLoanManager::RSV_NOTAVAIL)
				$this->enqueueMessage(Prado::localize("Attenzione: al momento non esiste alcun esemplare in grado di soddisfare la prenotazione."),
															ClavisMessage::WARNING);

			$this->RecordChooser->clean();
			$this->ReserveDeliveryLibrary->setSelectedValue($this->getUser()->getActualLibraryId());
			$this->ItemRequestList->globalRefresh();
		}
		else
		{
			$this->enqueueMessage(Prado::localize("Prenotazione fallita"),
										ClavisMessage::ERROR);
		}
		
		$this->flushMessage();
	}

	public function onPrintPatronCard($sender, $param)
	{
		$prompt = $this->CardPrint->getSelectedPrompt();
		
		ChangelogPeer::logAction(	$this->_patron,
									ChangelogPeer::LOG_PATRONCARDPRINT,
									$this->getUser(),
									Prado::localize("stampata tessera utente \"{template}\" per l'utente \"{username}\" [id: {userid}, barcode: {userbarcode}] {params}",
															array(	'username' => $this->_patron->getCompleteName(),
																	'template' => $this->CardPrint->getSelectedReportName(),
																	'userid' => $this->_patron->getPatronId(),
																	'userbarcode' => $this->_patron->getBarcode(),
																	'params' => ($prompt) ? ' [' . implode(', ', $prompt) . ']' : '' )));
		
		$this->CardPrint->printReport();
	}

	public function onPrintCurrentLoans($sender, $param)
	{
		$this->printJRPLoans($this->CurrentLoanList, $this->CurrentLoansPrint);
	}

	public function onPrintOldLoans($sender, $param)
	{
		$this->printJRPLoans($this->OldLoanList, $this->OldLoansPrint);
	}

	public function printJRPLoans(TControl $loanListControl, JasperPrintBox $jrpbox)
	{
		$ids = implode(',', $loanListControl->getCheckedItems(true, true));
		$jrpbox->setObjectId($ids);
		$jrpbox->addOptionalParam('P_ORDER', $loanListControl->getSortingExpression());
		$jrpbox->addOptionalParam('P_ORDERDIR', $loanListControl->getSortingDirection());
		$jrpbox->printReport();
	}

	public function onPrintItemRequests($sender, $param)
	{
		$datasource = array();
		
		foreach ($this->ItemRequestList->getDataSource() as $row)
			$datasource[] = $row['Id'];

		$this->ItemRequestPrint->setObjectId(implode(',', $datasource));
		$this->ItemRequestPrint->printReport();
	}

	public function onPrintRequests($sender, $param)
	{
		$datasource = array();
		
		foreach ($this->RequestsList->getDataSource() as $row)
			$datasource[] = $row['Id'];

		$this->RequestsPrint->setObjectId(implode(',', $datasource));
		$this->RequestsPrint->printReport();
	}

	public function onSwitchOnlyCanceledLoans($sender, $param)
	{
		$checked = $sender->getChecked();
		$onlyCanceledEffective = ($this->OldLoanList->getLoanStatus() == ItemPeer::LOANSTATUS_CANCELED);

		if ($checked != $onlyCanceledEffective)
		{
			$this->OldLoanList->setLoanStatus(ItemPeer::LOANSTATUS_CANCELED);
			$this->getPage()->writeMessage(Prado::localize("Prestiti storici filtrati per stato di 'annullato'"),
												ClavisMessage::INFO);
		}
		else
		{
			$this->OldLoanList->setLoanStatus(null);
		}

		$this->OldLoanList->populate();
		$this->OldLoanPanel->render($param->getNewWriter());
	}
	
        public function onSearchClosedLoanList($sender, $param) {
            $text = $this->SearchClosedLoanList->getSafeText();
            if ($text == "") { return; }
            $this->OldLoanList->setSearchTitleClosedLoanList($text);
            $this->OldLoanList->populate();
            $this->OldLoanPanel->render($param->getNewWriter());
        }

        public function onResetClosedLoanList($sender, $param) {
            $this->SearchClosedLoanList->Text = "";
            $this->OldLoanList->setSearchTitleClosedLoanList(null);
            $this->OldLoanList->populate();
            $this->OldLoanPanel->render($param->getNewWriter());
        }
        
	public function printNMStats($sender, $param)
	{
		//$this->WalletPrint->addOptionalParam("P_WALLETIDS", ($idList=="")?"0":$idList );
		$this->NMPrint->printReport();
	}
	
	public function toggleCreditPanel($sender, $param)
	{
	    $this->AddCreditPanel->setVisible( !( $this->AddCreditPanel->getVisible() ) );     
	}
	
	
	public function addCredit($sender, $param)
	{
		//Prado::log("Addcredit");
		
		$rule = new ResourceRule();
		$rule->setPriority(1);
		$ro = $this->ResourceOwner->getSelectedValue();
		
		
		if (!is_null($ro)
				&& ($ro != '')
				&& ($ro != '---'))
		{
			if( $ro != '.' )
			{
				$res = ResourceQuery::create()->findOneByName($ro);
				if (!($res instanceof Resource))
				{
					$this->writeMessage(Prado::localize("Risorsa {$ro} non valida"),
											ClavisMessage::ERROR);
					
					return;
				}
			}
			$rule->setResourceOwner($ro);
		}
		else
		{
			$this->writeMessage(Prado::localize("Specificare una risorsa"),
									ClavisMessage::ERROR);
		}
		
		$rule->setPatronId($this->_patron->getPatronId());
		$rule->setType(ResourceRule::TYPE_CREDIT);
		/*$rp = $this->ResourcePattern->getSafeText();
		if (!is_null($rp)
				&& ($rp != ''))
		{
			$rule->setResourcePattern($rp);
		}
		else
		{
			$this->writeMessage(Prado::localize("Specificare un modello"),
									ClavisMessage::ERROR);
		}
		*/
		$rule->setResourcePattern('.');
		
		$ra = $this->Amount->getSafeText();
		
		if (!is_null($ra)
				&& ($ra != '')
				&& ($ra != '0'))
		{
			$rule->setAmount($ra);
		}
		else
		{
			$this->writeMessage(Prado::localize("Specificare un credito"), 
									ClavisMessage::ERROR);
		}
		
		$rule->setUsed(0);
		$rule->setValidityStart($this->ValidityStart->getTimeStamp());
		$de = new DateTime();
		$de->setTimestamp($this->ValidityEnd->getTimeStamp());
		$de->setTime(23, 59, 59);
		$rule->setValidityEnd($de);
		$rule->setLibraryId($this->getUser()->getActualLibraryId());
		$rule->setNote($this->Note->getSafeText());
		
		try
		{
			$rule->save();

			ChangelogPeer::logAction(	$rule,
										ChangelogPeer::LOG_CREATE,
										$this->getUser(),
										"Creata regola con id: {$rule->getResourceRuleId()}");

			$this->writeMessage(Prado::localize("Creata regola con id: {id} ",
													array('id' => $rule->getResourceRuleId())),
									ClavisMessage::CONFIRM );
			
			$this->populateResourceOwnerDDList();
			$this->ResourceRuleList->populate();
			
			//Reset fields
			$this->ResourceOwner->setSelectedValue('');
			$this->ResourcePattern->setText("");
			$this->Amount->setText("");
			$this->ValidityStart->setText("");
			$this->ValidityEnd->setText("");
			$this->Note->setText("");
		}
		catch (Exception $ex)
		{
			Prado::log(__METHOD__ . " EXCEPTION: " . $ex->getMessage());
			$this->writeMessage(Prado::localize("Errore creando la regola, vedi log"),
									ClavisMessage::ERROR);
		}
	}
	
	public function populateResourceOwnerDDList()
	{
		/*
		 * Get all resources of this library
		 */
		$libid = $this->getUser()->getActualLibraryId();
		//Prado::log("Search all resource with libid ".$libid);
		
		$resourceColl = ResourceQuery::create()
							->filterByLibraryId($libid)
							->find();
		
		$rnames = array('' => '---', '.' => 'tutte');
		
		foreach($resourceColl as $r)
		{
			//$rnames[$r->getResourceId()] = $r->getName();
			$ip = $r->getName();
			$name = $r->getShortName();
			//$rnames[$ip] = $ip;
			$rnames[$ip] = $name;
		}
		
		$this->ResourceOwner->DataSource = $rnames;
		$this->ResourceOwner->dataBind();
	}
	
}
