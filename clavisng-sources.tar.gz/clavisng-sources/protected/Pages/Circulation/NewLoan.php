<?php
/**
 * NewLoan class file
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 */

/**
 * NewLoan class
 *
 * This page is responsible to manage loans.
 *
 * @author Dario Rigolin <dario@comperio.it>
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.7
 * @package Pages.Circulation
 * @since 2.0
 */
class NewLoan extends ClavisPage
{
	const TEMPLATE_BASENAME = 'templates';
	const TEMPLATE_FILENAME = 'template_immediateLoans';
	const LOANDIRECTION_DOLOAN = 242;
	const LOANDIRECTION_DOUNLOAN = 342;
	public $_module = 'CIRCULATION';
	private $_noReset;
	protected $_loanmanager;
	protected $_requestmanager;
	private $_deliveryLibraryId;
	private $_requestId;
	private $_blipMode;
	private $_rfidMode;
	private $_panelDraw;
	const INPUT_SOURCE_USER = 'user';
	const INPUT_SOURCE_RFID = 'rfid';

	private function initVars()
	{
		$this->_loanmanager = $this->getApplication()->getModule('loan');
		$this->_requestmanager = $this->getApplication()->getModule('request');
	}

	public function onInit($param)
	{
		parent::onInit($param);
		$this->initVars();

		$this->LastOperationPanel->setCssClass('panel_off');
		$this->_noReset = false;
		$itemId = null;
		$patronBarcode = null;
		$this->_requestId = null;

		/**
		 * first execution of page
		 */
		if (!$this->getPage()->getIsPostBack()
				&& !$this->getPage()->getIsCallback())
		{
			$this->globalReset();
			$this->cleanPatron();
			
			if ($this->getBlipMode())
			{
				$this->BlipModeCheck->setChecked(true);
				$this->BlipModeLabel->setCssClass('formlabelborderblue');
			}

			$this->getApplication()->getSession()->remove('ReassignedItemIds');
			$this->setDeliveryLibraryId(null);

			$patronBarcode = TPropertyValue::ensureString($this->getRequest()->itemAt('patronBarcode'));
			if ($patronBarcode != '')
			{
				/** @var $patrons PropelObjectCollection */
				$patrons = PatronPeer::getPatronsByBarcode($patronBarcode);
				$patron = $patrons->shift();
				
				if ($patron instanceof Patron)
				{
					$patronId = $patron->getPatronId();
					$this->insertPatronId($patronId);
					$this->_noReset = true;
				}

				if (!$patrons->isEmpty())
				{
					// TODO: notifica di barcodes utente duplicati
					// Per adesso lo fa la ClavisUserDataCard
				}
			}

			$patronId = intval($this->getRequest()->itemAt('patronId'));
			
			if ($patronId > 0)
			{
				$this->insertPatronId($patronId);
				$this->_noReset = true;
			}

			$items = ItemQuery::create()->findPKs($this->getRequest()->itemAt('itemId'));
			
			if ($items->count() > 0)
			{
				if ($this->getBlipMode())
				{
					$this->blipmode(false);
					$this->enqueueMessage(Prado::localize('Ricordarsi di riattivare la modalità rapida, se desiderato'), ClavisMessage::INFO);
					$this->flushMessage();
				}
				
				$this->_requestId = intval($this->getRequest()->itemAt('requestId'));
				
				foreach ($items as $item)
					$this->insertFromGetParameters($item, $this->_requestId);
				
				$this->_noReset = true;
			}
		}
		$this->attachEventHandler('OnClavisClientMessage', array($this, 'OnClavisClientMessage'));
	}
	
	public function OnClavisClientMessage($sender, $param)
	{
		$cbparam = $param->getParameter();
		$ccdata = $cbparam->getCallbackParameter();
		$cmd = $ccdata->command;
		
		if($cmd == 'pollscan')
		{

			$tags = RfidUtil::getTagsFromJson($ccdata->jsontags);

			$ptags = $tags[RfidUtil::TAG_TYPE_PATRON];
			$itags = $tags[RfidUtil::TAG_TYPE_ITEM];
			$ntags = $tags[RfidUtil::TAG_TYPE_NONE];
			
			$nrptag = count($ptags);
			$nritag = count($itags);
			
			
			//Emulate old clavisclientwidget
			if($nrptag > 1)
			{
				$this->writeMessage(Prado::localize("Più di una tessera utente"), ClavisMessage::WARNING);
			}
			
			if($nrptag == 1)
			{
				$patron = PatronQuery::create()->findOneByBarcode($ptags[0]->itemid);
				if ($patron instanceof Patron)
				{
					$this->insertPatron($patron, NewLoan::INPUT_SOURCE_RFID);
				}
			}
			else
			{
				//already check input source
				$this->cleanPatron();
			}
			
			
			$this->cleanItems(NewLoan::INPUT_SOURCE_RFID);

			
			foreach ($itags as $itemrfidata)
			{
				$itemobj = ItemQuery::create()->findOneByBarcode($itemrfidata->itemid);
				if($itemobj instanceof Item)
				{
					// lost check
					$returnMessage = $this->getApplication()->getModule('loan')->putLostToAvailableItem($itemobj->getItemId());
					if (count($returnMessage) > 0)
					{
						$this->writeMessage($returnMessage[0], $returnMessage[1]);
					}
					$this->addItem($itemobj, NewLoan::INPUT_SOURCE_RFID);
				}
			}
			RfidUtil::syncDbWithTags($this->getPage()->getClientScript(), $itags, $ptags);
			
			$this->globalRefresh($param);
			$this->drawPanels();
		}
	}

	public function onLoad($param)
	{
		parent::onLoad($param);

		$this->_panelDraw = array(	$this->AvailablePanel->getClientId() => true,
									$this->UnAvailablePanel->getClientId() => true,
									$this->LoanedPanel->getClientId() => true,
									$this->IllRequestedPanel->getClientId() => true);

		/**
		 * first execution of page
		 */
		if (!($this->getPage()->getIsPostBack())
				&& !($this->getPage()->getIsCallback()))
		{
			if (is_null($this->getDeliveryLibraryId()))
				$this->setDeliveryLibraryId($this->getUser()->getActualLibraryId());
			
			if ($this->getDeliveryLibraryFlag())
			{
				$this->DeliveryLibrary->setDatasource(LibraryPeer::getLibraryLabelsHash());
				$this->DeliveryLibrary->databind();
			}

			$presentPatronId = intval($this->PatronId->getText());
			if ($presentPatronId > 0)
			{
				$this->setFocus($this->ItemField->getClientID());
			}
			else
			{
				$this->setFocus($this->ResultLabel->getClientID());
			}

			$this->drawPanels();
		}
		// end of first execution of page

		$deliveryLibrary = $this->getDeliveryLibraryId();
		
		if ($this->getDeliveryLibraryFlag())
			$this->DeliveryLibrary->setSelectedValue($deliveryLibrary);

		$this->AvailableFound->setDeliveryLibraryId($deliveryLibrary);
		$this->UnAvailableFound->setDeliveryLibraryId($deliveryLibrary);
		$this->LoanedFound->setDeliveryLibraryId($deliveryLibrary);
		$this->IllRequestedFound->setDeliveryLibraryId($deliveryLibrary);

		/**
		 * Actions we can do on a page reload (postback),
		 * after an action (i.e.: a popup making an operation)
		 */
		if ($this->getPage()->getIsPostBack() || $this->getPage()->getIsCallback())
		{
			$reassignedItemIds = $this->getApplication()->getSession()->itemAt('ReassignedItemIds');
			$updateItemRequests = $this->getApplication()->getSession()->itemAt('UpdateItemRequests');
			$updateItemId = intval($this->getApplication()->getSession()->itemAt('UpdateItemId'));

			if ($updateItemId > 0)
			{
				$this->getApplication()->getSession()->remove('UpdateItemId');
				$dontUpdate = intval($this->getApplication()->getSession()->itemAt('DontUpdateLoanPage'));
				
				if ($dontUpdate == 1)
				{
					$this->getApplication()->getSession()->remove('DontUpdateLoanPage');
				}
				else
				{	
					$item = ItemQuery::create()
							->findPK($updateItemId);

					if ($item instanceof Item)
					{
						$this->datasourceUpdate($item);
						$this->panelsRefresh($param);
					}
				}
				
				$this->refreshCirculationData();
			}

			if (!is_null($reassignedItemIds) && count($reassignedItemIds) > 0)
			{
				$this->getApplication()->getSession()->remove('ReassignedItemIds');
				$this->refreshReassigned($reassignedItemIds, $param);
			}

			if (!is_null($updateItemRequests) && ($updateItemRequests == true))
			{
				$this->getApplication()->getSession()->remove('UpdateItemRequests');
				$this->globalRefresh($param);
				$this->flushMessage();
			}
		}

		if ($this->getSession()->itemAt('ZebraItemRequestId') &&
				'true' == ClavisParamQuery::getParam('CLAVISPARAM', 'ZebraAutoRequest'))
		{
			$ir = $this->getSession()->itemAt('ZebraItemRequestId');
			$this->getSession()->remove('ZebraItemRequestId');
			//$this->ClavisClient->printItemRequestLabel('itemrequest', $ir);
			RfidUtil::printItemRequestLabel($this->getPage()->getClientScript(),'itemrequest', $ir);
		}
	}

	public function drawPanels()
	{
		/// Available
		if ($this->_panelDraw[$this->AvailablePanel->getClientId()])
		{
			$this->AvailablePanel->setCssClass($this->getPanelCssClass($this->AvailableFound->HiddenFoundNumber->getValue() > 0));
		}
		else
		{
			$this->AvailablePanel->setCssClass($this->getPanelCssClass(true, true));
			$this->_panelDraw[$this->AvailablePanel->getClientId()] = true;
		}

		/// UnAvailable
		if (array_key_exists($this->UnAvailablePanel->getClientId(), $this->_panelDraw))
		{
			$this->UnAvailablePanel->setCssClass($this->getPanelCssClass($this->UnAvailableFound->HiddenFoundNumber->getValue() > 0));
		}
		else
		{
			$this->UnAvailablePanel->setCssClass($this->getPanelCssClass(true, true));
			$this->_panelDraw[$this->UnAvailablePanel->getClientId()] = true;
		}

		/// Loaned
		if (array_key_exists($this->LoanedPanel->getClientId(), $this->_panelDraw))
		{
			$this->LoanedPanel->setCssClass($this->getPanelCssClass($this->LoanedFound->HiddenFoundNumber->getValue() > 0));
		}
		else
		{
			$this->LoanedPanel->setCssClass($this->getPanelCssClass(true, true));
			$this->_panelDraw[$this->LoanedPanel->getClientId()] = true;
		}

		/// IllRequested
		if (array_key_exists($this->IllRequestedPanel->getClientId(), $this->_panelDraw))
		{
			$this->IllRequestedPanel->setCssClass($this->getPanelCssClass($this->IllRequestedFound->HiddenFoundNumber->getValue() > 0));
		}
		else
		{
			$this->IllRequestedPanel->setCssClass($this->getPanelCssClass(true, true));
			$this->_panelDraw[$this->IllRequestedPanel->getClientId()] = true;
		}
	}

	public function getDeliveryLibraryFlag()
	{
		return false;
	}

	public function setDeliveryLibraryId($libraryId = null)
	{
		$this->getApplication()->getSession()->add("DeliveryLibraryId", $libraryId, null);
		$this->_deliveryLibraryId = $libraryId;
	}

	public function getDeliveryLibraryId()
	{
		$libraryId = $this->getApplication()->getSession()->itemAt("DeliveryLibraryId", null);
		$this->_deliveryLibraryId = $libraryId;

		return $libraryId;
	}

	public function resetBlipMode()
	{
		if (!array_key_exists('NewLoanBlipMode', $_COOKIE))
			$this->setBlipMode(false);
	}

	public function setBlipMode($mode = false)
	{
		/// OLD $this->getApplication()->getSession()->add('BlipMode', $mode);

		$value = ($mode === true ? 1 : 0);
		setcookie('NewLoanBlipMode', $value);
		$this->_blipMode = $value;

		$this->setViewState('BlipMode', $value, 0);
	}

	public function getBlipMode()
	{
		// OLD     $this->_blipMode = $this->getApplication()->getSession()->itemAt('BlipMode');

		if (!$this->getIsPostBack() && !$this->getIsCallback())
			$value = $this->getViewState('BlipMode', 0);
		else
		{
			if (array_key_exists('NewLoanBlipMode', $_COOKIE))
			{
				$value = $_COOKIE['NewLoanBlipMode'];
			}
			else
			{
				$value = 0;
			}
		}

		$this->_blipMode = ($value == 1);
		return $this->_blipMode;
	}

	public function resetRfidMode()
	{
		$this->setRfidMode(false);
	}

	public function setRfidMode($mode = false)
	{
		$this->getApplication()->getSession()->add('RfidMode', $mode);
		$this->_rfidMode = $mode;
	}

	public function getRfidMode()
	{
		$this->_rfidMode = $this->getApplication()->getSession()->itemAt('RfidMode');
		
		return (is_null($this->_rfidMode) ? false : $this->_rfidMode);
	}

	private function resetLastMovementQueue()
	{
		$this->getApplication()->getSession()->add('LastMovementQueue', array());
	}

	private function addLastMovementQueue($addLoanId, $loanDirection = null)
	{
		if (($loanDirection != self::LOANDIRECTION_DOLOAN) && ($loanDirection != self::LOANDIRECTION_DOUNLOAN))
			return false;

		$queue = $this->getApplication()->getSession()->itemAt('LastMovementQueue');
		if (!is_array($queue))
			$queue = array();

		if (array_key_exists('loanDirection', $queue))
		{
			if ($queue['loanDirection'] != $loanDirection)
				$queue = array();
		}

		$queue['loanDirection'] = $loanDirection;
		$queue[] = $addLoanId;

		$this->getApplication()->getSession()->add('LastMovementQueue', $queue);
	}

	private function getLastMovementQueue()
	{
		$queue = $this->getApplication()->getSession()->itemAt('LastMovementQueue');

		return $queue;
	}

	public function suggestPatron($sender, $param)
	{
		$token = trim($param->getToken()); //the partial word to match   trim($this->ResultLabel->getSafeText());
		if ($token == "")
			return;

		$sender->setDataSource(PatronPeer::doSuggest($token, 10, true,true));
		$sender->dataBind();
	}

	public function suggestPatronCallBack($sender, $param)
	{
		$resultFlag = false;
		$fieldText = trim($this->ResultLabel->getSafeText());
		if ($fieldText == "")
			return;

		$this->ResultLabel->setText('');
		$match = array();
		if (preg_match("/\(([^\)]+)\)\$/", $fieldText, $match))
		{
			$patronBarcode = $match[1];
		}
		else
		{
			$patronBarcode = $fieldText;
		}

		/** @var $patrons PropelObjectCollection */
		$patrons = PatronPeer::getPatronsByBarcode($patronBarcode);

		if ($patrons->isEmpty())
			return;

		$patron = $patrons->shift();
		if (!$patrons->isEmpty())
		{
			// TODO: notifica di barcodes utente duplicati
			// Per adesso lo fa la ClavisUserDataCard
		}

		if ($patron instanceof Patron)
		{
			$this->resetLastMovementQueue();
			$resultFlag = $this->insertPatron($patron);
		}
	}

	public function drawDuplicateItemBarcodePanel($newState = false, $param = null)
	{
		$currentState = $this->DuplicateItemBarcodePanel->getCssClass() == "panel_on" ? true : false;

		if ($currentState != $newState)
		{
			$newCssClass = $newState ? 'panel_on' : 'panel_off';
			$this->DuplicateItemBarcodePanel->setCssClass($newCssClass);
		}

		if (!is_null($param) && $this->getPage()->getIsCallback())
			$this->DuplicateItemBarcodePanel->render($param->getNewWriter());
	}

	public function cleanItems($inputSource=NULL)
	{
		if( $inputSource == self::INPUT_SOURCE_RFID )
		{
			$objs = array($this->AvailableFound, $this->UnAvailableFound, $this->LoanedFound, $this->IllRequestedFound);
			$itemSources = $this->getViewState('ITEMS_INPUT_SOURCE');
			if( ! is_null($itemSources) && is_array($itemSources))
			{
				foreach($itemSources as $itemid => $source)
				{
					if($source == $inputSource)
					{
						foreach($objs as $obj)
						{
							$obj->deleteItemIds($itemid);
							unset($itemSources[$itemid]);
						}//foreach obj
					}
				}//foreach itemsources
			}//isnull
			$this->setViewState('ITEMS_INPUT_SOURCE',$itemSources);
		}
		else
		{
			$this->AvailableFound->resetDataSource();
			$this->UnAvailableFound->resetDataSource();
			$this->LoanedFound->resetDataSource();
			$this->IllRequestedFound->resetDataSource();
		}
		$this->drawPanels();
	}

	public function insertPatron($patron = null, $inputType = self::INPUT_SOURCE_USER)
	{
		if (!is_null($patron) && $patron instanceof Patron)
			$this->insertPatronId($patron->getPatronId(), $inputType);
	}

	public function insertPatronId($patronId, $inputType = self::INPUT_SOURCE_USER)
	{
		$oldPatronSource = $this->getViewState('PATRON_INPUT_SOURCE');
		
		$oldPatronId = intval($this->PatronId->getText());
		$this->PatronId->setText($patronId);

		if (is_null($patronId))
		{
			if( $oldPatronSource == self::INPUT_SOURCE_RFID )
			{
				$this->cleanPatron();
				$this->writeMessage(Prado::localize('Non è più selezionato alcun utente'),
										ClavisMessage::WARNING);
			}
			
			return false;
		}

		if ($oldPatronId == 0)
		{
			$this->refreshReassigned(array_merge($this->AvailableFound->getDatasourceIds(), $this->UnAvailableFound->getDatasourceIds()));
		}
		else
		{
			$this->cleanItems($inputType);
		}

		$this->setViewState('PATRON_INPUT_SOURCE',$inputType);
		$returnFlag = $this->UserData->populate($patronId);
		$this->CirculationData->populate($patronId);
		$this->UserDataPanel->setVisible($returnFlag);
		///$this->drawLastMovementPrintButton($returnFlag);

		if ($returnFlag)
		{
			$this->setFocus($this->ItemField->getClientID());
			$this->ItemField->setText('');
			$this->PatronId->setText($patronId);
		}
		else
		{
			$this->setFocus($this->ResultLabel->getClientID());
		}

		return $returnFlag;
	}

	private function drawLastMovementPrintButton($val = false)
	{
		$this->LastMovementPrintButtonPanel->setStyle('position:relative; left: 15px; display: ' . ($val ? 'inline' : 'none'));
		$this->LastMovementPrintButton->setStyle('position:relative; left: 15px; display: ' . ($val ? 'inline' : 'none'));

		if ($this->getIsCallBack())
			$this->LastMovementPrintButtonPanel->render($this->createWriter());
	}

	/**
	 * It gives back a list of string with patrons'd datas, which patrons
	 * all have the barcode passed as a parameter.
	 *
	 * @param string $barcode
	 * @return array
	 */
	private function searchBarcode($barcode)
	{
		$list = array();
		$c = new Criteria();
		$c->add(PatronPeer::BARCODE, $barcode);
		$patrons = PatronPeer::doSelect($c);

		for ($i = 0; $i < count($patrons); $i++)
		{
			$list[] = $patrons[$i]->getLastname() . ' ' . $patrons[$i]->getName() .
					" (" . $patrons[$i]->getBarcode() . ")<span class=\"informal\"> " .
					Clavis::dateFormat($patrons[$i]->getBirthDate('U')) . "</span>";
		}
		return $list;
	}

	/**
	 * Ajax callback which takes the barcode (usually read by means
	 * of a barcode reader device) and calls the method of the inner
	 * components (which manages the items grid) which adds to it.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function checkItemCallBack($sender, $param)
	{
		/* @var $item Item */

		$itemInput = trim($this->ItemField->getSafeText());
		$this->ItemField->setText('');

		if ($itemInput !== '')
		{
			$items = ItemPeer::retrieveByDataInput($itemInput);
			
			if (!is_null($items)
					&& (count($items) > 0))
			{
				$oldItems = $items;
				$item = is_array($items) ? array_shift($items) : $items->shift();

				// lost check
				$returnMessage = $this->_loanmanager->putLostToAvailableItem($item->getItemId());
				
				if (count($returnMessage) > 0)
					$this->getPage()->writeMessage($returnMessage[0], $returnMessage[1]);

				if (count($oldItems) == 1)
				{
					$this->drawDuplicateItemBarcodePanel(false, $param);
				}
				else  // nel caso di trovati duplicati
				{
					$encodedUrl = ItemPeer::encodeItems2Url($oldItems);
					$this->DuplicateItemId->setText($encodedUrl);
					$this->DuplicateItemHyperLink->dataBind();
					$this->DuplicateItemPopupButton->dataBind();
					$this->drawDuplicateItemBarcodePanel(true, $param);
				}

				if ($this->getBlipMode()) // rapid mode
				{
					$this->blipUpdate($item);
				}
				else
				{
					$this->addItem($item);
				}

				$this->panelsRefresh($param);
			}
			else // the insert data (presumably a barcode) is not valid for finding any related item
			{
				$candidateItemId = 0;
				$candidateUrl = '';

				if ((count(explode('-', $itemInput)) == 1) // if the string has no '-'
						&& (is_numeric($itemInput)))  // and the input is numeric (for inventory numbers)
				{
					$libraryCode = '';
					$actualLibrary = $this->getUser()->getActualLibrary();
					if ($actualLibrary instanceof Library)
						$libraryCode = trim($actualLibrary->getLibraryCode());
					
					if ($libraryCode != '')
					{
						$item = ItemQuery::create()
								->filterByInventorySerieId($libraryCode)
								->filterByInventoryNumber($itemInput)
								->findOne();

						if ($item instanceof Item)
						{
							$candidateItemId = $item->getItemId();
							$candidateUrl = '<a href="index.php?page=Circulation.NewLoan&itemId=' . $candidateItemId
									. (($patronId = $this->getPatronId()) > 0 ? '&patronId=' . $patronId : '')
									. '">' . $libraryCode . '-' . $itemInput . '</a>';
						}
					}
				}

				if ($candidateItemId > 0)
				{
					$this->getPage()->writeMessage(Prado::localize("L'esemplare {url} potrebbe soddisfare la tua ricerca ? Altrimenti nessun esemplare corrisponde", array('url' => $candidateUrl)), ClavisMessage::WARNING);
				}
				else // normal case
				{
					$this->getPage()->writeMessage(Prado::localize("Nessun esemplare corrisponde"), ClavisMessage::ERROR);
				}
			}
		}
	}

	public function getSelectedPatron()
	{
		$patron = null;
		$patronId = intval($this->PatronId->getSafeText());
		
		if ($patronId > 0)
			$patron = PatronQuery::create()->findPK($patronId);;
		
			return $patron;
	}

	public function blipUpdate($item)	//, $param = null)
	{
		$this->cleanMessageQueue();
		$patron = null;
		$exitCode = null;
		$patron = $this->getSelectedPatron();

		$clavisLibrarian = $this->getUser();
		$actualLibraryId = $clavisLibrarian->getActualLibraryId();
		
		if ($actualLibraryId !== 0)
		{
			$deliveryLibrary = null;
			$deliveryLibraryId = intval($this->getDeliveryLibraryId());
			
			if ($deliveryLibraryId > 0)
				$deliveryLibrary = LibraryQuery::create()->findPK($deliveryLibraryId);

			/**
			 * modified on lun 4 apr 2011: see Clerici's report about quick-mode newloan page,
			 * called with item_id parameter (does nothing)

			  else
			  return false;  //non fa niente. Da sistemare
			 */
			if ($this->_loanmanager->isItemLoaned($item))
			{
				if (!is_null($patron)
						&& !$this->_loanmanager->isItemLoaned($item, $patron))  // errore: prestito a persona diversa cui era stato prestato
				{
					if (!($deliveryLibrary instanceof Library))
					{
						$this->writeMessage(Prado::localize("E' stata tentata la correzione di un prestito erroneo, ma la biblioteca di destinazione non e' stata specificata"),
												ClavisMessage::ERROR);
						
						return false;
					}

					$this->_loanmanager->DoReturnItem($item, null, $clavisLibrarian);

					$this->enqueueMessage(Prado::localize("Annullato prestito erroneo ad altro utente."), ClavisMessage::WARNING);

					$exitCode = $this->doLoan(	$item,
												$patron,
												$clavisLibrarian,
												$deliveryLibrary,
												null,
							
												$this->_loanmanager->CalculateDueDate($item));

					$direction = ClavisCirculationDataCard::DIRECTION_LOAN;

					$this->enqueueMessage(Prado::localize("L'esemplare è ora {status} a {name}",
																array(	'name' => $patron->getCompleteName(),
																		'status' => $item->getLoanStatusString())),
											ClavisMessage::CONFIRM);
				}
				else	// do unloan
				{
					$message = '';
					$exitCode = $this->doUnloan($item, $clavisLibrarian);   //, $param);

					if ($exitCode == true)
					{
						if ($this->_loanmanager->IsItemOutOfHome($item) == true)
						{
							$homeLibraryLabel = $item->getHomeLibraryLabel();
							if ($homeLibraryLabel != '')
							{
								$libraryString = ", " . Prado::localize("per la biblioteca") . ": '" . $homeLibraryLabel . "'";
							}
							else
							{
								$libraryString = "";
							}
							
							if ($message != '')
								$message .= '<br />';
							
							$message .= Prado::localize('Mettere in cesta') . $libraryString . '.';
						}

						if ($message != '')
							$this->enqueueMessage($message,
													ClavisMessage::CONFIRM);
						
						$direction = ClavisCirculationDataCard::DIRECTION_RETURN;
					}
					else   // errore sulla doUnloan
					{
						$this->writeMessage(Prado::localize('Errore sul rientro'),
												ClavisMessage::ERROR);
						
						return false;
					}
				}
			}
			elseif (($isItemAvailableReturnValue = $this->_loanmanager->IsItemAvailable($item, $deliveryLibraryId, $patron)) != ClavisLoanManager::OK)   // is in other stati, thus not available anycase
			{
				// TODO: differenziare, da $isItemAvailableReturnValue
				$manifestation = $item->getManifestation();
				
				if ($manifestation instanceof Manifestation)
				{
					if ($isItemAvailableReturnValue == ClavisLoanManager::LOAN_MANIFESTATIONNOTLOANABLESINCE)
						$this->enqueueMessage(Prado::localize('La notizia è disponibile solo dal {date}',
																	array('date' => Clavis::dateFormat($manifestation->getLoanableSince('U')))),
												ClavisMessage::ERROR);

					//if (!$this->_loanmanager->IsRatingAllowed($manifestation, $selectedPatron))
					if ($isItemAvailableReturnValue == ClavisLoanManager::LOAN_PATRONNOTAGE)
						$this->enqueueMessage(Prado::localize("La notizia è disponibile solo per gli utenti con piu' di {rating} anni",
																	array('rating' => $manifestation->getRating())),
												ClavisMessage::ERROR);
				}

				$this->setFocus($this->ResultLabel->getClientID());
				
				return false;
			}
			else	///  is not in loan and is available: gonna loan it !
			{
				if (is_null($patron))
				{
					$this->writeMessage(Prado::localize("L'esemplare è disponibile ma nessun utente è stato selezionato per il prestito"),
											ClavisMessage::ERROR);
					$this->setFocus($this->ResultLabel->getClientID());
				
					return false;
				}

				if (!($deliveryLibrary instanceof Library))
				{
					$this->writeMessage(Prado::localize("E' stato tentato un prestito, ma la biblioteca di destinazione non è stata specificata"),
											ClavisMessage::ERROR);
					
					return false;
				}

				/**
				 * Modifica del 14-09-2007
				 * Per cercare di fare di sistemare un'actualLibraryId erronea di un item
				 * (nel caso sia stato importato erroneamente come residente attualmente
				 * in un'altra biblioteca, e invece e' qui da me (l'ho blippato).
				 * Gli forzo un'actualLibraryId come la mia che ho adesso.
				 */
				$itemActualLibraryId = intval($item->getActualLibraryId());
				if (is_null($itemActualLibraryId) || ($itemActualLibraryId != $actualLibraryId))
				{
					$this->enqueueMessage(Prado::localize("Attenzione: la biblioteca corrente dell'esemplare è erronea. Verrà ora impostata alla biblioteca corrente dell'operatore"),
											ClavisMessage::WARNING);
					
					$item->setActualLibraryId($actualLibraryId);
					$item->save();
					$item->reload(true);
				}

				$exitCode = $this->doLoan(	$item,
											$patron,
											$clavisLibrarian,
											$deliveryLibrary,
											null,
								
											$this->_loanmanager->CalculateDueDate($item));

				$direction = ClavisCirculationDataCard::DIRECTION_LOAN;
			}

			if ($exitCode)
			{
				if ($patron instanceof Patron)
					$this->CirculationData->populate(	$patron->getPatronId(),
														$item->getItemId(),
														$direction);
			}

			$this->setFocus($this->ItemField->getClientID());
			$this->flushMessage();
		}
	}

	private function insertFromGetParameters($item = null, $itemRequestId = null)
	{
		$deliveryLibraryId = null;
		$patron = null;

		if (!is_null($itemRequestId)
				&& ($itemRequestId > 0))
		{
			$itemRequest = ItemRequestQuery::create()->findPK($itemRequestId);
			
			if (!is_null($itemRequest)
					&& ($itemRequest instanceof ItemRequest))
			{
				$patronId = $itemRequest->getPatronId();
				
				if ($patronId > 0)
					$this->insertPatronId($patronId);

				$deliveryLibraryId = intval($itemRequest->getDeliveryLibraryId());
				
				if ($deliveryLibraryId > 0)
					$this->setDeliveryLibraryId($deliveryLibraryId);
			}
		}

		if (intval($this->getDeliveryLibraryId()) == 0)
		{
			$deliveryLibraryId = $this->getUser()->getActualLibraryId();
			$this->setDeliveryLibraryId($deliveryLibraryId);
		}

		if (!is_null($item) && ($item instanceof Item))
		{
			if (is_null($patron))
				$patron = $item->getPatron();

			$object = null;
			$objectPanel = null;
			$checkFlag = true;

			if ($this->getBlipMode())
			{
				$this->LastOperationPanel->setCssClass('panel_on');
				$this->LastOperationPanel->setVisible(true);
				$this->blipUpdate($item); //, $param);
			}
			else
			{
				$isRequestedFlag = $this->_requestmanager->countRequests(	$this->getUser()->getActualLibraryId(),
																			null,
																			$item->getItemId(),
																			null,
																			true) > 0; // fake simulation parameter
				
				if ($isRequestedFlag && !$item->isReadyForLoan())  // CNG-818
				{
					$object = $this->IllRequestedFound;
					$objectPanel = $this->IllRequestedPanel;
				}
				elseif ($this->_loanmanager->IsItemLoaned($item))	// B, in prestito
				{
					$object = $this->LoanedFound;
					$objectPanel = $this->LoanedPanel;
				}
				elseif ($this->_loanmanager->IsItemAvailable($item, $deliveryLibraryId, $patron) == ClavisLoanManager::OK) // A, item available
				{
					$object = $this->AvailableFound;
					$objectPanel = $this->AvailablePanel;
				}
				elseif ($this->_loanmanager->IsItemAvailable($item, $deliveryLibraryId, $patron) != ClavisLoanManager::OK) // item is non available
				{
					$object = $this->UnAvailableFound;
					$objectPanel = $this->UnAvailablePanel;
					$checkFlag = false;
				}

				if (($object != null) && ($objectPanel != null))
				{
					$object->addToDatasource($item, $itemRequestId, $checkFlag);
					$object->populate();
				}
				else
				{
					$this->writeMessage(Prado::localize('Nessun esemplare corrisponde'),
											ClavisMessage::ERROR);
				}
			}
		}
		else
		{
			$this->writeMessage(Prado::localize('Nessun esemplare corrisponde'),
									ClavisMessage::ERROR);
		}
	}

	/**
	 * It refreshes all the components (grids) in the page
	 * referring to panel which have at their inside the
	 * visualization of the items in their various loan statuses.
	 *
	 */
	public function globalRefresh($param = null)
	{
		$this->AvailableFound->populate();
		$this->UnAvailableFound->populate();
		$this->LoanedFound->populate();
		$this->IllRequestedFound->populate();

		if ($this->getIsCallback())
		{
			$this->AvailablePanel->render($this->createWriter());
			$this->UnAvailablePanel->render($this->createWriter());
			$this->LoanedPanel->render($this->createWriter());
			$this->IllRequestedPanel->render($this->createWriter());
		}

		$this->refreshCirculationData();
	}

	private function refreshCirculationData()
	{
		$patronId = intval($this->CirculationData->getPatronId());

		if ($patronId > 0)
		{
			$this->CirculationData->populate($patronId);
			$this->UserData->populate($patronId);
		}
	}

	public function refreshReassigned($itemIds, $param = null)
	{
		$selectedPatron = $this->getSelectedPatron();
		$deliveryLibraryId = $this->getUser()->getActualLibraryId();
		
		$items = ItemQuery::create()
					->findPks($itemIds);

		foreach ($items as $item)
		{
			if ($this->_loanmanager->IsItemAvailable($item, $deliveryLibraryId, $selectedPatron) == ClavisLoanManager::OK) // if available
			{
				$this->AvailableFound->addToDatasource($item, null, true);
				$this->UnAvailableFound->deleteItemIds($item->getItemId());
			}
			else
			{
				$this->UnAvailableFound->addToDatasource($item, null, false);
				$this->AvailableFound->deleteItemIds($item->getItemId());
			}

			$this->AvailableFound->populate();
			$this->UnAvailableFound->populate();

			$this->drawPanels();
		}

		if ($this->getPage()->getIsCallback())
		{
			$this->AvailablePanel->render($this->createWriter());
			$this->UnAvailablePanel->render($this->createWriter());
		}
	}

	public function globalUpdate()
	{
		$this->LoanedFound->updateDatasource();
		$this->IllRequestedFound->updateDatasource();
		$this->AvailableFound->updateDatasource();
		$this->UnAvailableFound->updateDatasource();
	}

	public function globalReset()
	{
		if (array_key_exists('NewLoanBlipMode', $_COOKIE)
				&& ($_COOKIE['NewLoanBlipMode'] == 1))
			$this->setBlipMode(true);

		$this->resetBlipMode();
		$this->resetRfidMode();
		$this->resetLastMovementQueue();

		$this->UserData->populate(null);
		$this->CirculationData->populate(null);
		$this->CirculationData->setPatronId(null);

		$this->circulationReset();
	}

	private function circulationReset()
	{
		$this->AvailableFound->resetDataSource();
		$this->UnAvailableFound->resetDataSource();
		$this->LoanedFound->resetDataSource();
		$this->IllRequestedFound->resetDataSource();
	}

	private function getPatron()
	{
		$patron = (object) null;
		$patronId = $this->getPatronId();

		if ($patronId > 0)
			$patron = PatronQuery::create()
						->findPK($patronId);

		return $patron;
	}

	private function getPatronId()
	{
		return intval($this->PatronId->getSafeText());
	}

	/**
	 * This method performs the loan action (by the clavis loan manager)
	 * on the items collected in the grid in the page (only checked ones).
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 * @return boolean
	 */
	public function onForceConsultation($sender, $param)
	{
		$this->cleanMessageQueue();
		$toRefreshFlag = false;

		$patron = $this->getPatron();
		$clavisLibrarian = $this->getUser();
		$myLibraryId = $clavisLibrarian->getActualLibraryId();
	
		if (($myLibraryId !== 0)
				&& ($patron instanceof Patron))
		{
			if (($deliveryLibraryId = $this->getDeliveryLibraryId()) > 0)
			{
				$deliveryLibrary = LibraryQuery::create()->findPK($deliveryLibraryId);
			}
			else
			{
				$this->writeMessage(Prado::localize('La biblioteca di destinazione è nulla'),
										ClavisMessage::ERROR);
				
				return false;
			}

			$now = getdate();
			$dueDate = mktime(0, 0, 0, $now['mon'], $now['mday'] + 1, $now['year']) - 1;
			$itemId = 0;
			
			if (!is_null($param))
			{
				$value = $param->CommandParameter;
			
				if (intval($value) > 0)
				{
					$itemId = $value;
				}
				elseif (is_string($value))
				{
					$arr = unserialize($value);
					
					if (count($arr) == 2)
						list($itemId, ) = $arr;
				}
			}

			if ($itemId > 0)
			{
				$newItemRequestId = null;
				$checkedDatasource = array(
					array(	'itemId' => $itemId,
							'dueDate' => $dueDate,
							'itemRequestId' => $newItemRequestId));
			}
			else
			{
				$checkedDatasource = $this->AvailableFound->getCheckedItemIds();
			}
			
			foreach ($checkedDatasource as $row)
			{
				$itemId = $row['itemId'];
			
				if (($itemRequestId = $row['itemRequestId']) > 0)
				{
					$itemRequest = ItemRequestQuery::create()->findPK($itemRequestId);
				}
				else
				{
					$itemRequest = null;
				}
				
				$item = ItemQuery::create()->findPK($itemId);
				$previousLoanClass = $item->getLoanClass();
				
				if (!$item->isStatusConsultation())
					$item->setLoanClass(ItemPeer::LOANCLASS_ONLYCONSULTATION);
				
				$toRefreshFlag = $this->doLoan(	$item,
												$patron,
												$clavisLibrarian,
												$deliveryLibrary,
												$itemRequest,
												
												$dueDate);
				
				$item->setLoanClass($previousLoanClass);
				$item->save();
			}
		}
		else	// loaner's data are not correct
		{
			if (!$patron instanceof Patron)
			{
				$messageBody = Prado::localize("Dati dell'utente mancanti");
			}
			elseif ($myLibraryId == 0)
			{
				$messageBody = Prado::localize("Errore sul reperimento della biblioteca corrente dell'operatore !");
			}
			else
			{
				$messageBody = Prado::localize('Dati mancanti...');
			}
			
			$this->enqueueMessage($messageBody,
									ClavisMessage::ERROR);
		}
		
		$this->flushMessage();
		
		if ($toRefreshFlag)
			$this->panelsRefresh($param);
		
		$this->returnPage();
	}

	/**
	 * This method performs the loan action (by the clavis loan manager)
	 * on the items collected in the grid in the page (only checked ones).
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 * @return boolean
	 */
	public function onLoan($sender, $param)
	{
		$this->cleanMessageQueue();
		$toRefreshFlag = false;
		$patron = $this->getPatron();
		$clavisLibrarian = $this->getUser();
		$myLibraryId = $clavisLibrarian->getActualLibraryId();
		
		if (($myLibraryId !== 0) && ($patron instanceof Patron))
		{
			if (($deliveryLibraryId = $this->getDeliveryLibraryId()) > 0)
			{
				$deliveryLibrary = LibraryQuery::create()->findPK($deliveryLibraryId);
			}
			else
			{
				$this->writeMessage(Prado::localize('La biblioteca di destinazione è nulla'),
										ClavisMessage::ERROR);

				return false;
			}

			$itemId = 0;
			$newDueDate = null;
			
			if (!is_null($param))
			{
				$value = $param->CommandParameter;
				if (intval($value) > 0)
				{
					$itemId = $value;
				}
				elseif (is_string($value))
				{
					$arr = unserialize($value);
			
					if (count($arr) == 2)
						list($itemId, $newDueDate) = $arr;
				}
			}

			if ($itemId > 0)
			{
				$newItemRequestId = null;
				if (is_null($newDueDate))
					$newDueDate = $this->_loanmanager->CalculateDueDate(ItemQuery::create()
										->findPK($itemId));
				
				$checkedDatasource = array(array(	'itemId' => $itemId,
													'dueDate' => $newDueDate,
													'itemRequestId' => $newItemRequestId));
			}
			else
			{
				$checkedDatasource = $this->AvailableFound->getCheckedItemIds();
			}

			foreach ($checkedDatasource as $row)
			{
				$itemId = $row['itemId'];
				if (($itemRequestId = $row['itemRequestId']) > 0)
				{
					$itemRequest = ItemRequestQuery::create()->findPK($itemRequestId);
				}
				else
				{
					$itemRequest = null;
				}
				
				$dueDate = $row['dueDate'];

				$item = ItemQuery::create()
							->findPK($itemId);

				$toRefreshFlag = $this->doLoan(	$item,
												$patron,
												$clavisLibrarian,
												$deliveryLibrary,
												$itemRequest,

												$dueDate);
			}
		}
		else
		{
			if (!($patron instanceof Patron))
			{
				$messageBody = Prado::localize("Dati dell'utente mancanti");
			}
			elseif ($myLibraryId == 0)
			{
				$messageBody = Prado::localize("Errore sul reperimento della biblioteca corrente dell'operatore !");
			}
			else
			{
				$messageBody = Prado::localize('Dati mancanti...');
			}

			$this->enqueueMessage($messageBody,
									ClavisMessage::ERROR);
		}

		$this->flushMessage();

		if ($toRefreshFlag)
			$this->panelsRefresh($param);

		$this->returnPage();
	}

	public function onReadyToLoan2Loan($sender, $param)
	{
		$itemId = $sender->getCustomData();
		$item = ItemQuery::create()->findPk($itemId);
		
		if (!($item instanceof Item))
		{
			$this->getPage()->writeMessage(Prado::localize("L'esemplare con id={id} non esiste. Contattare il fornitore del software.",
																array("id" => $itemId)),
												ClavisMessage::ERROR);
		}

		$this->cleanMessageQueue();
		$toRefreshFlag = false;
		$patron = $item->getPatron();
		$clavisLibrarian = $this->getUser();
		$myLibraryId = $clavisLibrarian->getActualLibraryId();

		if (($myLibraryId !== 0)
				&& ($patron instanceof Patron))
		{
			$newItemRequestId = null;
			$dueDate = $this->_loanmanager->CalculateDueDate($item);

			$toRefreshFlag = $this->doLoan(	$item,
											$patron,
											$clavisLibrarian,
											$clavisLibrarian->getActualLibrary(), // deliverylibrary
											null,

											$dueDate);
		}
		else
		{
			if (!($patron instanceof Patron))
			{
				$messageBody = Prado::localize("Dati dell'utente mancanti");
			}
			elseif ($myLibraryId == 0)
			{
				$messageBody = Prado::localize("Errore sulla biblioteca corrente dell'operatore !");
			}
			else
			{
				$messageBody = Prado::localize('Dati mancanti. Riportare al fornitore del software, con tutti i dettagli.');
			}

			$this->enqueueMessage($messageBody,
									ClavisMessage::ERROR);
		}

		$this->flushMessage();

		if ($toRefreshFlag)
			$this->panelsRefresh($param);

		$this->returnPage();
	}

	private function doLoan(	$item,
								$patron,
								$clavisLibrarian,
								$deliveryLibrary,
								$itemRequest,
				
								$dueDate)
	{
		if ($item instanceof Item)
		{
			$itemId = $item->getItemId();
		}
		else
		{
			$itemId = null;
		}

		$myLibraryId = $this->getUser()->getActualLibraryId();

		if ($deliveryLibrary instanceof Library)
		{
			$deliveryLibraryId = $deliveryLibrary->getLibraryId();
		}
		else
		{
			$deliveryLibraryId = $myLibraryId;
		}

		$exitCode = false;
		
		if ($patron instanceof Patron)
		{
			$patronBarcode = $patron->getBarcode();
		}
		else
		{
			$patronBarcode = "<" . Prado::localize('barcode utente mancante') . ">";
		}

		$warningNotMine = false;
		$alienString = '';
		
		if (!is_null($itemId))
		{
			if ($item->getIsAlien())
			{
				$alienString = Prado::localize(' (di altra biblioteca)');
			}
			else
			{
				if ($myLibraryId != $item->getActualLibraryId())
					$warningNotMine = true;
			}
		}

		$isPatronAllowed = $this->_loanmanager->IsPatronAllowedToLoan($patron, $itemId);
		
		if ($isPatronAllowed == ClavisLoanManager::LOAN_PATRONNOTENABLED)
		{
			$this->enqueueMessage(Prado::localize("L'esemplare n. {itemid}{alienString}: <em>\"{title}\"</em> NON è prestabile a <strong>{patron}</strong> perché l'utente non è abilitato al prestito",
														array(	'itemid' => $item->getItemId(),
																'title' => $item->getTrimmedTitle(40),
																'patron' => $patron->getCompleteName(),
																'alienString' => $alienString)),
									ClavisMessage::ERROR);
		}

		if ($isPatronAllowed == ClavisLoanManager::LOAN_REACHEDMAX)
		{
			$this->enqueueMessage(Prado::localize("L'esemplare n. {itemid}{alienString}: <em>\"{title}\"</em> NON è prestabile a <strong>{patron}</strong> perché l'utente ha raggiunto il massimo numero di prestiti consentiti",
														array(	'itemid' => $item->getItemId(),
																'title' => $item->getTrimmedTitle(40),
																'patron' => $patron->getCompleteName(),
																'alienString' => $alienString)),
									ClavisMessage::ERROR);
		}

		$isItemAvailableReturnValue = $this->_loanmanager->IsItemAvailable($item, $deliveryLibraryId, $patron);

		if ($isItemAvailableReturnValue != ClavisLoanManager::OK)
		{
			if ($this->getBlipMode())
				$this->blipMode(false);

			if ($patron instanceof Patron)
			{	
				$this->enqueueMessage(Prado::localize("L'esemplare n. {itemid}{alienString}: <em>\"{title}\"</em> NON è disponibile per <strong>{patron}</strong>",
															array(	'itemid' => $item->getItemId(),
																	'title' => $item->getTrimmedTitle(40),
																	'patron' => $patron->getCompleteName(),
																	'alienString' => $alienString)),
										ClavisMessage::ERROR);
			}
			else
			{	
				$this->enqueueMessage(Prado::localize("L'esemplare n. {itemid}{alienString}: <em>\"{title}\"</em> NON è disponibile",
															array(	'itemid' => $item->getItemId(),
																	'title' => $item->getTrimmedTitle(40),
																	'alienString' => $alienString)),
										ClavisMessage::ERROR);
			}
			
			$manifestation = $item->getManifestation();
			
			if ($manifestation instanceof Manifestation)
			{
				if ($isItemAvailableReturnValue == ClavisLoanManager::LOAN_MANIFESTATIONNOTLOANABLESINCE)
					$this->enqueueMessage(Prado::localize('La notizia è disponibile solo dal {date}',
																array('date' => Clavis::dateFormat($manifestation->getLoanableSince('U')))),
												ClavisMessage::ERROR);

				if ($isItemAvailableReturnValue == ClavisLoanManager::LOAN_PATRONNOTAGE)
					$this->enqueueMessage(Prado::localize("La notizia è disponibile solo per gli utenti con piu' di {rating} anni",
																array('rating' => $manifestation->getRating())),
												ClavisMessage::ERROR);
			}

			if (in_array($item->getLoanClass(), ItemPeer::getLoanClassesConsultation()))
			{
				$this->enqueueMessage(Prado::localize("L'esemplare è disponibile solo per consultazione, all'interno della biblioteca di appartenenza"),
											ClavisMessage::ERROR);
			}
		}

		// if everything seems to be ok for loaning ...
		if (($item instanceof Item)
				&& ($isPatronAllowed == ClavisLoanManager::OK)
				&& ($isItemAvailableReturnValue == ClavisLoanManager::OK))
		{
			$item->setActualLibraryId($deliveryLibraryId);

			$resultLoan = $this->_loanmanager->DoLoanItem(	$item,
															$patron,
															$clavisLibrarian,
															$deliveryLibrary,
															$itemRequest,

															$dueDate);
			switch ($resultLoan)
			{
				case ClavisLoanManager::LOAN_LOANED:
					$this->addLastMovementQueue($item->getCurrentLoanId(), self::LOANDIRECTION_DOLOAN);

					$loanStatusString = strtolower($item->getLoanStatusString());
					$labelText = Prado::localize("Esemplare{alienString} '<em>{title}</em>' [barcode: {barcode}] {status} all'utente <b>{patron}</b> [barcode: {patronBarcode}]",
														array(	'barcode' => $item->getBarcode(),
																'title' => $item->getTrimmedTitle(40),
																'patron' => "<a href='" . $patron->getNavigateUrl() . $patron->getPatronId() . "' target='parent'>" . $patron->getCompleteName() . "</a>",
																'patronBarcode' => $patronBarcode,
																'status' => $loanStatusString,
																'alienString' => $alienString));

					if ('true' == ClavisParamQuery::getParam('CLAVISPARAM', 'ZebraAutoReceipt'))
					{
						//$this->ClavisClient->printLoanLabel('receipt', $item->getCurrentLoanId());
						RfidUtil::printLoanLabel($this->getPage()->getClientScript(),'receipt', $item->getCurrentLoanId());
					}

					if ($this->getBlipMode())
					{
						$this->LastOperationLabel->setText($labelText);
						$this->LastOperationLabel->setCssClass('bordergreen');
						$this->LastOperationLabel2->setText('');
						$this->LastOperationPanel->setCssClass('panel_on');
					}

					$this->enqueueMessage($labelText, ClavisMessage::CONFIRM);

					if ($warningNotMine)
						$this->enqueueMessage(Prado::localize("Attenzione: secondo il sistema l'esemplare con barcode: {barcode} non era in questa biblioteca. Pregasi ricontrollare.",
																	array('barcode' => $item->getBarcode())),
												ClavisMessage::WARNING);

					$this->AvailableFound->deleteItemIds($item->getId());
					$this->datasourceUpdate(ItemQuery::create()->findPK($item->getItemId()), null, null, false);

					$this->refreshCirculationData();
					$exitCode = true;
					
					break;

				case ClavisLoanManager::LOAN_READYTOLOAN:
					$labelText = Prado::localize("Esemplare n.{itemId}{alienString} '{title}' pronto al prestito per {patron}",
														array(	'itemId' => $item->getItemId(),
																'alienString' => $alienString,
																'title' => $item->getTrimmedTitle(40),
																'patron' => '<a href="' . $this->getService()->constructUrl('Circulation.PatronViewPage', array('id' => $patron->getPatronId())) . '" target="parent">' . $patron->getCompleteName() . '</a>' ));

					// ready-to-loan automatic notification
					if (ClavisParamQuery::getParam('CLAVISPARAM', 'AutoEmailLoanReady') == 'true')
					{
						$ret = NotificationHelper::sendNotificationEmail(	'readyforloan',
																			$patron,
																			$clavisLibrarian->getLibrarian(),
																			$deliveryLibrary,
																			array($item->getCurrentLoanId()));
						
						if ($ret)
						{
							$item->setNotifyCount($item->getNotifyCount() + 1);
							$item->save();
							$loan = $item->getLoanRelatedByCurrentLoanId();
							$loan->setNotifyCount($loan->getNotifyCount() + 1);
							$loan->save();
							$labelText .= Prado::localize(' - notificato automaticamente via email');
						}
					}
					
					if ($this->getBlipMode())
					{
						$this->LastOperationLabel->setText($labelText);
						$this->LastOperationLabel->setCssClass('bordergreen');
						$this->LastOperationLabel2->setText('');
						$this->LastOperationPanel->setCssClass('panel_on');
					}

					$this->enqueueMessage($labelText, ClavisMessage::CONFIRM);
					$this->AvailableFound->deleteItemIds($item->getId());
					$this->datasourceUpdate(ItemQuery::create()->findPK($item->getItemId()), null, null, false);

					$this->refreshCirculationData();
					$exitCode = true;

					break;

				case ClavisLoanManager::LOAN_RESERVED:
					$labelText = Prado::localize("Esemplare n.{itemId}{alienString} '{title}' prenotato per {patron}",
														array(	'itemId' => $item->getItemId(),
																'alienString' => $alienString,
																'title' => $item->getTrimmedTitle(40),
																'patron' => '<a href="' . $this->getService()->constructUrl('Circulation.PatronViewPage', array('id' => $patron->getPatronId())) . '" target="parent">' . $patron->getCompleteName() . '</a>' ));
					
					if ($this->getBlipMode())
					{
						$this->LastOperationLabel->setText($labelText);
						$this->LastOperationLabel->setCssClass('bordergreen');
						$this->LastOperationLabel2->setText('');
						$this->LastOperationPanel->setCssClass('panel_on');
					}
					
					$this->enqueueMessage($labelText, ClavisMessage::CONFIRM);

					/// after Paolo's request
					$this->AvailableFound->deleteItemIds($item->getId());
					$this->refreshCirculationData();
					$exitCode = true;

					break;

				case ClavisLoanManager::LOAN_ILLREQUESTED:
					$labelText = Prado::localize("Esemplare n.{itemId}{alienString} '{title}' richiesto per ILL per l'utente {patron}",
														array(	'itemId' => $item->getItemId(),
																'alienString' => $alienString,
																'title' => $item->getTrimmedTitle(40),
																'patron' => '<a href="' . $this->getService()->constructUrl('Circulation.PatronViewPage', array('id' => $patron->getPatronId())) . '" target="parent">' . $patron->getCompleteName() . '</a>' ));

					if ($this->getBlipMode())
					{
						$this->LastOperationLabel->setText($labelText);
						$this->LastOperationLabel->setCssClass('bordergreen');
						$this->LastOperationLabel2->setText('');
						$this->LastOperationPanel->setCssClass('panel_on');
					}

					$this->enqueueMessage($labelText,
											ClavisMessage::CONFIRM);

					$this->AvailableFound->deleteItemIds($item->getItemId());
					$this->datasourceUpdate(ItemQuery::create()->findPK($item->getItemId()), null, null, false);

					$this->refreshCirculationData();
					$exitCode = true;

					break;

				case ClavisLoanManager::LOAN_NOTRESERVABLE:
					$this->enqueueMessage(Prado::localize("La notizia '{title}' NON É PRENOTABILE da {name}",
																array(	'title' => $item->getTrimmedTitle(40),
																		'name' => $patron->getCompleteName() )),
											ClavisMessage::ERROR);
					
					$exitCode = false;

					break;

				case ClavisLoanManager::LOAN_ALREADYRESERVED:
					$this->enqueueMessage(Prado::localize("La notizia '{title}' É GIÁ STATA PRENOTATA da {name}",
																array(	'title' => $item->getTrimmedTitle(40),
																		'name' => $patron->getCompleteName() )),
											ClavisMessage::ERROR);
					
					$exitCode = false;
					
					break;

				case ClavisLoanManager::LOAN_LOANALREADYEXISTS:
					$this->enqueueMessage(Prado::localize("Un prestito per l'esemplare '{title}' [barcode: {barcode}] è già in corso",
																array(	'title' => $item->getTrimmedTitle(40),
																		'barcode' => $item->getBarcode() )),
											ClavisMessage::ERROR);
					
					$exitCode = false;
					
					break;

				case ClavisLoanManager::RSV_ALREADYMANAGED:
					$this->enqueueMessage(Prado::localize("L'esemplare '{title}' [barcode: {barcode}] è già in gestione ad un altro operatore, per cui non è possibile prestarlo",
																array(	'title' => $item->getTrimmedTitle(40),
																		'barcode' => $item->getBarcode() )),
											ClavisMessage::ERROR);
					
					$exitCode = false;
					
					break;

				case ClavisLoanManager::ERROR:
					$this->enqueueMessage(Prado::localize("Errore generico: l'esemplare con id = {itemId}{alienString} '{title}' NON PRESTATO a {name}",
																array(	'itemId' => $item->getItemId(),
																		'title' => $item->getTrimmedTitle(40),
																		'name' => $patron->getCompleteName(),
																		'alienString' => $alienString )),
											ClavisMessage::ERROR);
					
					$exitCode = false;
					
					break;
			}
		}

		if ($exitCode)
			$item->save();   // forse e' ridondante, ma serve per fissare per ogni caso la nuova actual_library_id

		return $exitCode;
	}

	public function onUnloan($sender, $param)
	{
		$clavisLibrarian = $this->getUser();
		$itemId = 0;
		
		if (!is_null($param))
			$itemId = $param->CommandParameter;
		
		if ($itemId > 0)
		{
			$newItemRequestId = null;
			$newDueDate = $this->_loanmanager->CalculateDueDate(ItemQuery::create()	->findPK($itemId));
			
			$checkedDatasource = array(array(	'itemId' => $itemId,
												'dueDate' => $newDueDate,
												'itemRequestId' => $newItemRequestId ));
		}
		else
		{
			$checkedDatasource = $this->LoanedFound->getCheckedItemIds();
		}

		$toRefreshFlag = false;
		$this->cleanMessageQueue();
		
		foreach ($checkedDatasource as $row)
		{
			$itemId = $row['itemId'];
			
			if (($itemRequestId = $row['itemRequestId']) > 0)
			{
				$itemRequest = ItemRequestQuery::create()->findPK($itemRequestId);
			}
			else
			{
				$itemRequest = null;
			}

			$item = ItemQuery::create()	->findPK($itemId);
			$isItemLoaned = $this->_loanmanager->IsItemLoaned($item);
			
			if (!$isItemLoaned)
			{
				$this->enqueueMessage(Prado::localize("L'esemplare con id = {item_id} e barcode = '{item_barcode}' NON É IN PRESTITO",
															array(	'item_id' => $item->getId(),
																	'item_barcode' => $item->getBarcode() )),
										ClavisMessage::ERROR);

				return false;
			}

			if (($item instanceof Item)
					&& $isItemLoaned)
			{
				if ($this->doUnloan($item, $clavisLibrarian))   // , $param
				{
					$toRefreshFlag = true;
					$this->LoanedFound->deleteItemIds($itemId);
				}
			}
		}

		$this->flushMessage();

		if ($toRefreshFlag)
		{
			$this->globalRefresh();
			$this->drawPanels();
		}
	}

	public function onFreezeConsultation($sender, $param)
	{
		$clavisLibrarian = $this->getUser();
		$itemId = 0;

		if (!is_null($param))
			$itemId = $param->CommandParameter;

		if ($itemId > 0)
		{
			$checkedDatasource = array(array('itemId' => $itemId));
		}
		else
		{
			$checkedDatasource = $this->LoanedFound->getCheckedItemIds();
		}

		$toRefreshFlag = false;
		$this->cleanMessageQueue();

		foreach ($checkedDatasource as $row)
		{
			$itemId = $row['itemId'];
			$item = ItemQuery::create()	->findPK($itemId);
			$isItemLoaned = $this->_loanmanager->IsItemLoaned($item);

			if (!$isItemLoaned)
			{
				$this->enqueueMessage(Prado::localize("L'esemplare con id = {item_id} e barcode = '{item_barcode}' NON É IN CONSULTAZIONE",
															array(	'item_id' => $item->getId(),
																	'item_barcode' => $item->getBarcode() )),
										ClavisMessage::ERROR);
				
				return false;
			}

			if (($item instanceof Item)
					&& $isItemLoaned)
			{
				if ($this->doFreezeConsultation($itemId, $clavisLibrarian, $param))
					$toRefreshFlag = true;
			}
		}

		if ($toRefreshFlag)
		{
			$this->globalRefresh();
			$this->drawPanels();
		}

		$this->flushMessage();
	}

	public function onResumeConsultation($sender, $param)
	{
		$clavisLibrarian = $this->getUser();
		$itemId = 0;

		if (!is_null($param))
			$itemId = $param->CommandParameter;

		if ($itemId > 0)
		{
			$checkedDatasource = array(array('itemId' => $itemId));
		}
		else
		{
			$checkedDatasource = $this->LoanedFound->getCheckedItemIds();
		}

		$toRefreshFlag = false;
		$this->cleanMessageQueue();

		foreach ($checkedDatasource as $row)
		{
			$itemId = $row['itemId'];
			$item = ItemQuery::create()	->findPK($itemId);
			$isItemLoaned = $this->_loanmanager->IsItemLoaned($item);
			
			if (!$isItemLoaned)
			{
				$this->enqueueMessage(Prado::localize("L'esemplare con id = {item_id} e barcode = '{item_barcode}' NON É IN CONSULTAZIONE",
															array(	'item_id' => $item->getId(),
																	'item_barcode' => $item->getBarcode() )),
										ClavisMessage::ERROR);
				
				return false;
			}
			
			if (($item instanceof Item)
					&& $isItemLoaned)
			{
				if ($this->doResumeConsultation($itemId, $clavisLibrarian, $param))
					$toRefreshFlag = true;
			}
		}

		if ($toRefreshFlag)
		{
			$this->globalRefresh();
			$this->drawPanels();
		}

		$this->flushMessage();
	}

	public function onSuspendRenew($sender, $param)
	{
		$this->getPage()->cleanMessageQueue();

		$clavisLibrarian = $this->getUser();
		$ok = false;

		$item = (object) null;
		$itemId = intval($param->CommandParameter);

		if ($itemId > 0)
			$item = ItemQuery::create()	->findPK($itemId);
		
		if ($item instanceof Item)
		{
			$itemtit = $item->getCompleteTitle();
		
			if (!$itemtit)
				$itemtit = '(' . Prado::localize('nessun titolo') . ')';

			if ($this->_loanmanager->IsItemLoaned($item))
			{
				switch ($this->_loanmanager->doDisableRenew($itemId, $clavisLibrarian))
				{
					case ClavisLoanManager::OK:
						$this->getPage()->enqueueMessage(Prado::localize("L'esemplare con titolo '{title}' [barcode: {barcode}, inv: {inv}] è stato sospeso dalle proroghe",
																				array(	'title' => $itemtit,
																						'inv' => $item->getCompleteInventoryNumber(),
																						'barcode' => $item->getBarcode() )),
															ClavisMessage::INFO);
						
						$ok = true;
						
						break;

					case ClavisLoanManager::ERROR:
						$this->getPage()->enqueueMessage(Prado::localize("L'operazione di sospensione di proroga è fallita"),
															ClavisMessage::ERROR);
						
						break;

					default:
						$this->getPage()->enqueueMessage(Prado::localize("Errore sconosciuto durante la sospensione di proroga"),
															ClavisMessage::ERROR);
						
						break;
				}
			}
			else
			{
				$this->getPage()->enqueueMessage(Prado::localize("L'esemplare con id = {id} e barcode = '{barcode}' NON É IN PRESTITO",
																		array(	'id' => $item->getId(),
																				'barcode' => $item->getBarcode() )),
													ClavisMessage::ERROR);
			}
		}
		else
		{
			$this->getPage()->enqueueMessage(Prado::localize("Errore nel passaggio dei parametri. Contattare il fornitore del software."),
												ClavisMessage::ERROR);
		}

		if ($ok)
		{
			$this->insertFromGetParameters($item);
			$this->globalRefresh();
		}

		$this->getPage()->flushMessage();
	}

	public function onRenewLoan($sender, $param)
	{
		$this->getPage()->cleanMessageQueue();

		$item = null;
		$itemId = intval($param->CommandParameter);
		if ($itemId > 0)
			$item = ItemQuery::create()	->findPK($itemId);

		if ($item instanceof Item)
		{
			$clavisLibrarian = $this->getUser();
			$destinationObject = $this->_loanmanager->getLoanDestinationObject($item);
			
			if (!is_null($destinationObject))
			{
				if ($this->_loanmanager->DoRenewLoan(	$item,
														$destinationObject,
														$clavisLibrarian,
														Prado::localize('rinnovo standard')))
				{
					$item->reload();
					
					$this->getPage()->enqueueMessage(Prado::localize("Proroga fino al {date} eseguita correttamente per il prestito sull'esemplare '{title}', inv: {inv}, barcode: {barcode}",
																		array(	'date' => Clavis::dateFormat($item->getDueDate('U')),
																				'title' => $item->getTrimmedTitle(60),
																				'inv' => $item->getCompleteInventoryNumber(),
																				'barcode' => $item->getBarcode() )),
														ClavisMessage::INFO);

					$this->insertFromGetParameters($item);
					$this->globalRefresh();
				}
				else
				{
					$this->getPage()->enqueueMessage(Prado::localize("Proroga fallita sull'esemplare '{title}', inv: {inv}, barcode: {barcode}",
																		array(	'title' => $item->getTrimmedTitle(60),
																				'inv' => $item->getCompleteInventoryNumber(),
																				'barcode' => $item->getBarcode() )),
														ClavisMessage::ERROR);
				}
			}
			else
			{
				$this->getPage()->enqueueMessage(Prado::localize("Incongruenza sulla proroga dell'esemplare con id: {id}. Contattare il fornitore del software.",
																	array('id' => $item->getItemId())),
													ClavisMessage::ERROR);
			}
		}

		$this->getPage()->flushMessage();
	}

	public function onIllRequestedUnloan($sender, $param)
	{
		$clavisLibrarian = $this->getUser();
		$itemId = 0;

		if (!is_null($param))
			$itemId = $param->CommandParameter;

		if ($itemId > 0)
		{
			$newItemRequestId = null;
			$newDueDate = $this->_loanmanager->CalculateDueDate(ItemQuery::create()	->findPK($itemId));
			
			$checkedDatasource = array(array(	'itemId' => $itemId,
												'dueDate' => $newDueDate,
												'itemRequestId' => $newItemRequestId) );
		}
		else
		{
			$checkedDatasource = $this->IllRequestedFound->getCheckedItemIds();
		}

		$toRefreshFlag = false;
		
		foreach ($checkedDatasource as $row)
		{
			$itemId = $row['itemId'];
		
			if (($itemRequestId = $row['itemRequestId']) > 0)
			{
				$itemRequest = ItemRequestQuery::create()->findPK($itemRequestId);
			}
			else
			{
				$itemRequest = null;
			}

			$item = ItemQuery::create()	->findPK($itemId);
			$isItemLoaned = $this->_loanmanager->IsItemLoaned($item);
			
			if (!$isItemLoaned)
				$this->getPage()->writeMessage(Prado::localize("L'esemplare n. {item_id} NON É IN PRESTITO",
																	array('item_id' => $item->getId())),
													ClavisMessage::ERROR);

			if (!is_null($item)
					&& ($item instanceof Item)
					&& $isItemLoaned)
			{
				if ($this->doUnloan($item, $clavisLibrarian))
				{
					$toRefreshFlag = true;
					$this->IllRequestedFound->deleteItemIds($itemId);
				}
			}
		}

		if ($toRefreshFlag)
		{
			$this->globalRefresh();
			$this->drawPanels();
		}
	}

	private function doUnloan($item, $clavisLibrarian)
	{
		$itemId = $item->getItemId();
		$alienString = ($item->getIsAlien()
							? " " . Prado::localize("di altra biblioteca") . " "
							: "");

		$patron = $item->getPatron();
		
		if ($patron instanceof Patron)
		{
			$extraMode = false;
			$patronBarcode = $patron->getBarcode();
		}
		else
		{
			$extraMode = true;
			$patronBarcode = '--';
		}

		$externalLibrary = $item->getExternalLibrary();

		if (!($patron instanceof Patron)
				&& !($externalLibrary instanceof Library))
		{
			$this->enqueueMessage(Prado::localize("Incongruenza: l'esemplare con id: {itemId} ha sia il patron che la biblioteca esterna nulli. Riportare, con dettagli, al fornitore del software.",
														array('itemId' => $itemId)),
									ClavisMessage::ERROR);

			return false;
		}

		$myLibraryId = $this->getUser()->getActualLibraryId();
		$isLate = ($this->_loanmanager->isLoanLate($item) == ClavisLoanManager::LOAN_ISLATE);
		$dueDate = Clavis::dateFormat($item->getDueDate('U'));
		$loan_id = $item->getCurrentLoanId();

		$returnCode = $this->_loanmanager->DoReturnItem(	$item,
															$patron,
															$clavisLibrarian);

		$exitCode = false;
		$labelText = '';
		$messageText = '';
		$messageType = ClavisMessage::ERROR;

		if (($returnCode == ClavisLoanManager::OK)
				|| ($returnCode == ClavisLoanManager::RETN_PATRONREQUEST))  // if return of item went ok
		{
			$this->addLastMovementQueue($loan_id, self::LOANDIRECTION_DOUNLOAN);

			if ('true' == ClavisParamQuery::getParam('CLAVISPARAM', 'ZebraAutoReceipt'))
			{
				//$this->ClavisClient->printLoanLabel('receipt_return', $loan_id);
				RfidUtil::printLoanLabel($this->getPage()->getClientScript(),'receipt_return', $loan_id);
			}

			$exitCode = true;

			if (!$extraMode)
			{
				$labelText = Prado::localize("Rientro eseguito per l'utente <b>{patron}</b> [barcode: {patronBarcode}] dell'esemplare{alien} [barcode: {itemBarcode}] '{title}', ",
													array(	'alien' => $alienString,
															'itemBarcode' => $item->getBarcode(),
															'title' => $item->getTrimmedTitle(40),
															'patron' => "<a href='" . "index.php?page=Circulation.NewLoan&patronId=" . $patron->getPatronId() . "' target='_top' title='" . Prado::localize("vai al Banco Prestiti con questo utente") . "'>" . $patron->getCompleteName() . "</a>",
															'patronBarcode' => $patronBarcode ));
			}
			else
			{
				$labelText = Prado::localize("Rientro eseguito dell'esemplare{alien} [barcode: {itemBarcode}] '{title}', dalla biblioteca esterna <b>{exlib}</b>",
													array(	'alien' => $alienString,
															'itemBarcode' => $item->getBarcode(),
															'title' => $item->getTrimmedTitle(40),
															'exlib' => "<a href='" . $externalLibrary->getNavigateUrl() . $externalLibrary->getLibraryId() . "' target='parent'>" . $externalLibrary->getLabel() . "</a>"));
			}

			$messageType = ClavisMessage::CONFIRM;

			if ($isLate)
			{
				$labelText .= ', <b>** ' . Prado::localize("consegnato in ritardo") . "</b> "
									. Prado::localize("scaduto il {dueDate}",
														array('dueDate' => $dueDate))
									. " <b>**</b>";

				$messageType = ClavisMessage::WARNING;
			}

			$messageText = $labelText;

			if ($returnCode == ClavisLoanManager::RETN_PATRONREQUEST)
			{

				$requests = $this->_requestmanager->getRequests(	$myLibraryId,
																	null,
																	null,
																	null,
																	$itemId);

				$minRequestId = null;
				$minRequestDate = null;
				
				foreach ($requests as $rowRequest)
				{
					if (is_null($minRequestId)
							|| ($rowRequest['requestDate'] < $minRequestDate))
					{
						$minRequestId = $rowRequest['requestId'];
						$minRequestDate = $rowRequest['requestDate'];
					}
				}

				if (!is_null($minRequestId))
				{
					$messageText .= ' ' . Prado::localize('ed esistono prenotazioni.');
					$messageType = ClavisMessage::WARNING;
				}

				$serializedParameter2 = urlencode(serialize(array($minRequestId, count($requests), $itemId)));
				$labelText .= '&nbsp;(<a target="_self" href="javascript:void(0)" onclick="openIframe(\'Circulation.ManageRequestsPopup&immediateLoan=1\',null,null,\'' . $this->getForm()->getClientID() . '\',null,null,null,null,\'' . $serializedParameter2 . '\',\'Manifestation\'); return false;">' . Prado::localize('esistono prenotazioni') . '</a>)&nbsp;';
			}

			if ($item->getLoanStatus() == ItemPeer::LOANSTATUS_READYFORTRANSITTOHOME)
			{
				$messageText .= '<br />' . Prado::localize("L'esemplare è stato messo in 'pronto al transito di rientro'.");
			}
			elseif ($item->getLoanStatus() == ItemPeer::LOANSTATUS_INTRANSITTOEXTRA)
			{
				$messageText .= '<br />' . Prado::localize("L'esemplare è stato messo in 'rientro verso extrasistema'.");
			}

			if ($this->getBlipMode())
			{
				$this->LastOperationLabel->setText($labelText);
				$this->LastOperationLabel->setCssClass('bordered');
				$this->LastOperationPanel->setCssClass('panel_on');

				if (($accessNote = trim($patron->getAccessNote())) != '')
					$this->LastOperationLabel2->setText("<b>" . Prado::localize("Nota sull'accesso") . "</b>: "
															. "{$accessNote}<br /><hr /><br />");
			}

			$this->LoanedFound->deleteItemIds($item->getId());
			$this->datasourceUpdate(ItemQuery::create()->findPK($itemId), null, null, false);

			$this->refreshCirculationData();
		}
		elseif ($returnCode == ClavisLoanManager::ERROR)
		{
			$messageText = Prado::localize("Errore: esemplare n.{itemId}{alienString} '{title}' NON RITORNATO",
												array(	'itemId' => $itemId,
														'alienString' => $alienString,
														'title' => $item->getTrimmedTitle(40) ));

			$messageType = ClavisMessage::ERROR;
			$exitCode = false;
		}
		else
		{
			$messageText = Prado::localize("Valore di ritorno sconosciuto durante il rientro del prestito. Riportare al fornitore del software.");
			$messageType = ClavisMessage::ERROR;
			$exitCode = false;
		}

		$this->enqueueMessage($messageText, $messageType);

		return $exitCode;
	}

	private function doFreezeConsultation($itemId, $clavisLibrarian, $param)
	{
		$item = null;
		$itemId = intval($itemId);
		$item = ItemQuery::create()	->findPK($itemId);
		
		if (!($item instanceof Item))
		{
			$this->enqueueMessage("Il parametro passato è incongruente: esemplare inesistente. Contattare il fornitore del software.",
										ClavisMessage::ERROR);
			
			return false;
		}

		$patron = $item->getPatron();
		$returnCode = $this->_loanmanager->doFreezeConsultation($itemId, $clavisLibrarian);
		$exitCode = false;
		$labelText = '';
		$messageText = '';
		$messageType = ClavisMessage::ERROR;

		if (($returnCode == ClavisLoanManager::OK))
		{
			$exitCode = true;
			
			$labelText = Prado::localize("Messa in deposito dell'esemplare '{title}' [barcode: {barcode}, inv: {inventory}], per l'utente <b>{patron}</b> [barcode: {patronBarcode}]",
												array(	'barcode' => $item->getBarcode(),
														'inventory' => $item->getCompleteInventoryNumber(),
														'title' => $item->getTrimmedTitle(40),
														'patron' => "<a href='index.php?page=Circulation.PatronViewPage&id="
																		. $patron->getPatronId() . "' target='parent'>"
																		. $patron->getCompleteName() . "</a>",
														
														'patronBarcode'	 => $patron->getBarcode() ));

			$messageType = ClavisMessage::CONFIRM;
			$messageText = $labelText;

			if ($this->getBlipMode())
			{
				$this->LastOperationLabel->setText($labelText);
				$this->LastOperationLabel->setCssClass('borderyellow');
				$this->LastOperationPanel->setCssClass('panel_on');

				if (($accessNote = trim($patron->getAccessNote())) != '')
					$this->LastOperationLabel2->setText(Prado::localize("<b>Nota sull'accesso</b>: ") . "{$accessNote}<br /><hr /><br />");
			}

			$this->datasourceUpdate(ItemQuery::create()	->findPK($item->getItemId()));
			$this->refreshCirculationData();
		}
		elseif ($returnCode == ClavisLoanManager::ERROR)
		{
			$messageText = Prado::localize("Errore: esemplare '{title}' [barcode '{barcode}'] NON MESSO IN DEPOSITO",
												array(	'title' => $item->getTrimmedTitle(40),
														'barcode' => $item->getBarcode() ));

			$messageType = ClavisMessage::ERROR;
			$exitCode = false;
		}
		else
		{
			$messageText = Prado::localize('Valore di ritorno sconosciuto');
			$messageType = ClavisMessage::ERROR;
			$exitCode = false;
		}
		$this->enqueueMessage($messageText, $messageType);

		return $exitCode;
	}

	private function doResumeConsultation($itemId, $clavisLibrarian, $param)
	{
		$item = null;
		$itemId = intval($itemId);
		$item = ItemQuery::create()	->findPK($itemId);
		
		if (!($item instanceof Item))
		{
			$this->enqueueMessage("Il parametro passato è incongruente: esemplare inesistente. Riportare al fornitore del software",
										ClavisMessage::ERROR);

			return false;
		}

		$patron = $item->getPatron();
		$returnCode = $this->_loanmanager->doResumeConsultation($itemId, $clavisLibrarian);
		$exitCode = false;
		$labelText = '';
		$messageText = '';
		$messageType = ClavisMessage::ERROR;

		if (($returnCode == ClavisLoanManager::OK))
		{
			$exitCode = true;
			
			$labelText = Prado::localize("Ripresa della consultazione dell'esemplare '{title}' [barcode: {barcode}, inv: {inventory}], all'utente <b>{patron}</b> [barcode: {patronBarcode}]",
												array(	'barcode' => $item->getBarcode(),
														'inventory' => $item->getCompleteInventoryNumber(),
														'title' => $item->getTrimmedTitle(40),
														'patron' => "<a href='index.php?page=Circulation.PatronViewPage&id="
																		. $patron->getPatronId() . "' target='parent'>"
																		. $patron->getCompleteName() . "</a>",
														
														'patronBarcode'	 => $patron->getBarcode() ));

			$messageType = ClavisMessage::CONFIRM;
			$messageText = $labelText;

			if ($this->getBlipMode())
			{
				$this->LastOperationLabel->setText($labelText);
				$this->LastOperationLabel->setCssClass('bordergreen');
				$this->LastOperationPanel->setCssClass('panel_on');

				if (($accessNote = trim($patron->getAccessNote())) != '')
					$this->LastOperationLabel2->setText(Prado::localize("<b>Nota sull'accesso</b>: ") . "{$accessNote}<br /><hr /><br />");
			}

			$this->datasourceUpdate(ItemQuery::create()	->findPK($item->getItemId()));

			$this->refreshCirculationData();
		}
		elseif ($returnCode == ClavisLoanManager::ERROR)
		{
			$messageText = Prado::localize("Errore: esemplare '{title}' [barcode '{barcode}'] NON RIMESSO IN CONSULTAZIONE",
												array(	'title' => $item->getTrimmedTitle(40),
														'barcode' => $item->getBarcode() ));
			
			$messageType = ClavisMessage::ERROR;
			$exitCode = false;
		}
		else
		{
			$messageText = Prado::localize('Valore di ritorno sconosciuto. Riportare al fornitore del software.');
			$messageType = ClavisMessage::ERROR;
			$exitCode = false;
		}

		$this->enqueueMessage($messageText, $messageType);

		return $exitCode;
	}

	public function reassignRejectedItems($items)
	{
		foreach ($items as $item)
			$this->datasourceUpdate($item, false);
	}

	public function addItemId($itemId = null, $inputSource=self::INPUT_SOURCE_USER)
	{
		$itemId = intval($itemId);
		
		if ($itemId > 0)
		{
			$item = ItemQuery::create()	->findPK($itemId);
			$this->addItem($item, $inputSource);
		}
	}

	public function addItem($item = null, $inputSource=self::INPUT_SOURCE_USER)
	{
		if ($item instanceof Item)
		{
			$this->datasourceUpdate($item);
			$itemSources = $this->getViewState('ITEMS_INPUT_SOURCE');
			if( is_null($itemSources) )
			{
				$itemSources = array();
			}
			$itemSources[$item->getItemId()] = $inputSource;
			$this->setViewState('ITEMS_INPUT_SOURCE', $itemSources);
		}
	}

	public function removeItemId($itemId = null)
	{
		$itemId = intval($itemId);
		
		if ($itemId > 0)
		{
			$item = ItemQuery::create()	->findPK($itemId);
			$this->removeItem($item);
		}
	}

	public function removeItem($item = null)
	{
		if ($item instanceof Item)
			$this->datasourceUpdate($item, null, true);
	}

	public function datasourceUpdate(	$item,
										$disableDrawPanel = false,
										$deleteFlag = false,
										$doFlushMessages = true)
	{
		$selectedPatron = $this->getSelectedPatron();
		$deliveryLibraryId = $this->getUser()->getActualLibraryId();
		
		if ($item instanceof Item)
		{
			$object = null;
			$objectPanel = null;
			$checkFlag = true;
			$drawPanelId = null;

			$otherObjects = array(	$this->IllRequestedFound,
									$this->LoanedFound,
									$this->AvailableFound,
									$this->UnAvailableFound );

			$otherPanels = array(	$this->IllRequestedPanel,
									$this->LoanedPanel,
									$this->AvailablePanel,
									$this->UnAvailablePanel );

			$itemId = $item->getItemId();
			
			if ($deleteFlag)
			{
				foreach ($otherObjects as $panel => $otherObject)
				{
					$otherPanel = $otherPanels[$panel];
					$otherObject->deleteItemIds($itemId);
					$otherPanel->setCssClass(count($otherObject->getDatasource()) > 0
																			? 'panel_on'
																			: 'panel_off');
				}
			}
			else
			{
				$isRequestedFlag = $this->_requestmanager->countRequests(	$this->getUser()->getActualLibraryId(),
																			null,
																			$itemId,
																			null,
																			true) > 0; // fake simulation parameter

				$isLoanedFlag = $this->_loanmanager->IsItemLoaned($item);
				$isItemAvailableReturnValue = $this->_loanmanager->IsItemAvailable(	$item,
																					$deliveryLibraryId,
																					$selectedPatron);

				if ($isRequestedFlag // goto requested panel
						&& !$item->isReadyForLoan())  // CNG-818)
				{
					$object = $this->IllRequestedFound;
					$objectPanel = $this->IllRequestedPanel;
					unset($otherObjects[0]);
					unset($otherPanels[0]);

					if ($disableDrawPanel)
						$drawPanelId = $this->IllRequestedPanel->getClientId();
				}
				elseif ($isLoanedFlag) // goto loaned panel		
				{
					$object = $this->LoanedFound;
					$objectPanel = $this->LoanedPanel;
					unset($otherObjects[1]);
					unset($otherPanels[1]);

					if ($disableDrawPanel)
						$drawPanelId = $this->LoanedPanel->getClientId();
				}
				elseif ($isItemAvailableReturnValue == ClavisLoanManager::OK) // goto available panel				
				{
					$object = $this->AvailableFound;
					$objectPanel = $this->AvailablePanel;
					unset($otherObjects[2]);
					unset($otherPanels[2]);

					if ($disableDrawPanel)
						$drawPanelId = $this->AvailablePanel->getClientId();
					
					$otherManagedReservation = "";
					$connection = Propel::getConnection();
		
					$query = $connection->prepare("SELECT DISTINCT count(*) as count, librarian_id FROM `item_request` ir 
													WHERE ir.request_status='" . ItemRequestPeer::STATUS_WORKING . "' 
														AND ir.library_id=" . $this->getUser()->getActualLibraryId() . "
															
														AND ( ((ir.manifestation_id = 0) AND (ir.item_id = " . $itemId . "))
																OR (ir.manifestation_id = " . $item->getManifestationId() . ") )

														GROUP BY ir.librarian_id;");
																	// AND ir.librarian_id<>" . $this->getUser()->getId() . "
					
					$query->execute();

					foreach ($query->fetchAll(PDO::FETCH_ASSOC) as $row)
					{
						$librarianId = $row['librarian_id'];
						$name = LibrarianPeer::getLibrarianNameByPk($librarianId);
						$count = $row['count'];

			//			$otherManagedReservationArray[] = array(	'librarianId' => $librarianId,
			//														'name' => $name,
			//														'count' => $count );

						//$otherManagedReservation .= $name . ': ' . $count . ', ';
						$otherManagedReservation .= $name . ', ';
					}
					
					if ($otherManagedReservation != "")
					{	
						$otherManagedReservation = trim($otherManagedReservation, ', ');
						
						$itemData = "'" . $item->getCompleteTitle() . "', " . $item->getCompleteInventoryNumber() . ")";
						
						$this->enqueueMessage(Prado::localize("L'esemplare {itemData} si riferisce ad una prenotazione in gestione da altro operatore della biblioteca corrente ({otherManaged})",
																array(	'itemData' => $itemData,
																		'otherManaged' => $otherManagedReservation )),
												ClavisMessage::WARNING);
						
					}
				}
				elseif ($isItemAvailableReturnValue != ClavisLoanManager::OK) // goto unavailable panel
				{
					$manifestation = $item->getManifestation();
					
					if ($manifestation instanceof Manifestation)
					{
						if ($isItemAvailableReturnValue == ClavisLoanManager::LOAN_MANIFESTATIONNOTLOANABLESINCE)
							$this->enqueueMessage(Prado::localize('La notizia è disponibile solo dal {date}',
																		array('date' => Clavis::dateFormat($manifestation->getLoanableSince('U')))),
													ClavisMessage::ERROR);

						if ($isItemAvailableReturnValue == ClavisLoanManager::LOAN_PATRONNOTAGE)
							$this->enqueueMessage(Prado::localize("La notizia è disponibile solo per gli utenti con piu' di {rating} anni",
																		array('rating' => $manifestation->getRating())),
													ClavisMessage::ERROR);
					}

					$object = $this->UnAvailableFound;
					$objectPanel = $this->UnAvailablePanel;
					unset($otherObjects[3]);
					unset($otherPanels[3]);
					$checkFlag = false;

					if ($disableDrawPanel)
						$drawPanelId = $this->UnAvailablePanel->getClientId();
				}

				if (!is_null($drawPanelId))
					$this->_panelDraw[$drawPanelId] = false;

				// we do something, if it's possible
				if (!is_null($object) && !is_null($objectPanel))
				{
					$object->addToDatasource($item, null, $checkFlag);

					if (count($object->getDatasource()) == 0)
					{
						$objectPanel->setCssClass('panel_off');
						$this->enqueueMessage(Prado::localize('Nessun esemplare corrisponde'),
													ClavisMessage::ERROR);
					}
					elseif (count($otherObjects) > 0)
					{
						foreach ($otherObjects as $panel => $otherObject)
						{
							$otherPanel = $otherPanels[$panel];
							$otherObject->deleteItemIds($itemId);
							$otherPanel->setCssClass(count($otherObject->getDatasource()) > 0
																					? 'panel_on'
																					: 'panel_off');
						}
					}
				}
				else
				{
					$this->enqueueMessage(Prado::localize("Errore sull'oggetto"),
												ClavisMessage::ERROR);
				}
			}
		}
		else // generic error
		{
			$this->enqueueMessage(Prado::localize("Errore sull'esemplare"),
										ClavisMessage::ERROR);
		}

		if ($doFlushMessages)
			$this->flushMessage();
	}

	public function onAbortLoan($sender, $param)
	{
		$abortDescription = $this->LoanedAbortDescription->getSafeText();
		$resultsString = "";

		$clavisLibrarian = $this->getUser();
		$itemId = 0;
		
		if (!is_null($param))
			$itemId = $param->CommandParameter;
		
		if ($itemId > 0)
		{
			$newItemRequestId = null;
			$newDueDate = $this->_loanmanager->CalculateDueDate(ItemQuery::create()->findPK($itemId));
			
			$checkedDatasource = array(array(	'itemId' => $itemId,
												'dueDate' => $newDueDate,
												'itemRequestId' => $newItemRequestId ));
		}
		else
		{
			$checkedDatasource = $this->LoanedFound->getCheckedItemIds();
		}

		foreach ($checkedDatasource as $row)
		{
			$itemId = $row['itemId'];

			if (($itemRequestId = $row['itemRequestId']) > 0)
			{
				$itemRequest = ItemRequestQuery::create()->findPK($itemRequestId);
			}
			else
			{
				$itemRequest = null;
			}

			$item = ItemQuery::create()->findPK($itemId);
			$isItemLoaned = $this->_loanmanager->IsItemLoaned($item);
			
			if (!$isItemLoaned)
				$this->writeMessage(Prado::localize("L'esemplare con record id: {id} non è in prestito",
														array('id' => $item->getId())),
										ClavisMessage::ERROR);

			if (!is_null($item)
					&& ($item instanceof Item)
					&& $isItemLoaned)
			{
				if ($this->_loanmanager->DoAbortLoan(	$item,
														$item->getPatron(),
														$clavisLibrarian,
														$abortDescription))
				{
					$this->LoanedAbortDescription->setText('');
					$this->LoanedFound->deleteItemIds($itemId);
					$this->datasourceUpdate(ItemQuery::create()->findPK($item->getItemId()));   // c'era null come secondo parametro

					$resultsString .= ('esemplare n.' . $item->getId() . '(' . $item->getCompleteName() . ') => Annullato<br />');
					$this->getPage()->writeMessage(Prado::localize('Esemplare n.{itemId} ABORTITO',
																		array('itemId' => $item->getItemId())),
														ClavisMessage::CONFIRM);
				}
				else
				{
					$resultsString .= ('esemplare n.' . $item->getId() . '(' . $item->getCompleteName() . ') => FAILED, non annullato<br />');
					$this->getPage()->writeMessage(Prado::localize('Esemplare n.{itemId} NON ABORTITO',
																		array('itemId' => $item->getItemId())),
														ClavisMessage::ERROR);
				}
			}
		}

		$this->globalRefresh();
		$this->drawPanels();
	}

	public function onAbortIllRequested($sender, $param)   ///// maybe not used anymore ..........
	{
		$this->cleanMessageQueue();

		$abortDescription = $this->IllRequestedAbortDescription->getSafeText();
		$clavisLibrarian = $this->getUser();
		$itemId = 0;

		if (!is_null($param))
			$itemId = $param->CommandParameter;

		if ($itemId > 0)
		{
			$newItemRequestId = null;
			$newDueDate = $this->_loanmanager->CalculateDueDate(ItemQuery::create()	->findPK($itemId));
			
			$checkedDatasource = array(array(	'itemId' => $itemId,
												'dueDate' => $newDueDate,
												'itemRequestId' => $newItemRequestId));
		}
		else
		{
			$checkedDatasource = $this->IllRequestedFound->getCheckedItemIds();
		}

		foreach ($checkedDatasource as $row)
		{
			$itemId = $row['itemId'];
			
			if (($itemRequestId = $row['itemRequestId']) > 0)
			{
				$itemRequest = ItemRequestQuery::create()->findPK($itemRequestId);
			}
			else
			{
				$itemRequest = null;
			}

			$item = ItemQuery::create()->findPK($itemId);

			$isIllRequested = $this->_requestmanager->countRequests(	$this->getUser()->getActualLibraryId(),
																		null,
																		$item->getItemId(),
																		null,
																		true) > 0; // fake simulation parameter
			
			if (!$isIllRequested)
				$this->enqueueMessage(Prado::localize("L'esemplare n.{item_id} NON E' PRENOTATO PER I.L.L.",
															array('item_id' => $item->getId())),
										ClavisMessage::ERROR);

			if (($item instanceof Item)
					&& $isIllRequested)
			{
				if ($this->_loanmanager->DoAbortLoan(	$item,
														$item->getPatron(),
														$clavisLibrarian,
														$abortDescription))
				{
					$this->IllRequestedAbortDescription->setText('');
					$this->IllRequestedFound->deleteItemIds($itemId);
					
					$this->datasourceUpdate(ItemQuery::create()->findPK($item->getItemId()));

					$this->enqueueMessage(Prado::localize("Esemplare n.{item_id} abortito da I.L.L.",
																array('item_id' => $item->getId())),
											ClavisMessage::CONFIRM);
				}
				else
				{
					$this->enqueueMessage(Prado::localize("Esemplare n.{item_id} NON ABORTITO DA I.L.L.",
																array('item_id' => $item->getId())),
											ClavisMessage::ERROR);
				}
			}
		}

		$this->flushMessage();

		$this->globalRefresh();
		$this->drawPanels();
	}

	public function getPanelCssClass($newState = true, $force = false)
	{
		$secondCondition = ($force
								? true
								: !$this->getBlipMode());

		return (($newState
					&& $secondCondition)
			? 'panel_on'
			: 'panel_off');
	}

	public function onFlipBlipMode($sender, $param)
	{
		$newState = $sender->getChecked();
		$this->blipMode($newState, $param);
		$this->flushMessage();
	}

	public function blipMode($newState = false, $param = null)
	{
		$this->setBlipMode($newState);
		$this->BlipModeCheck->setChecked($newState);
		$this->BlipModeLabel->setCssClass($newState ? 'formlabelborderblue' : 'formlabel');

		if ($newState)
		{
			$this->enqueueMessage(Prado::localize('Modalità rapida attivata'),
									ClavisMessage::INFO);
			
			if (!(intval($this->PatronId->getSafeText()) > 0))
			{
				$this->setFocus($this->ResultLabel->getClientID());
			}
			else
			{
				$this->setFocus($this->ItemField->getClientID());
			}

			$this->circulationReset();
		}
		else
		{
			$this->enqueueMessage(Prado::localize('Modalità rapida disattivata'),
									ClavisMessage::WARNING);
			
			$this->LastOperationPanel->setCssClass('panel_off');
			$this->circulationReset();

			if ($this->getIsCallback())
			{
				if (is_null($param))
				{
					$writer = $this->createWriter();
				}
				else
				{
					$writer = $param->getNewWriter();
				}

				$this->LastOperationPanel->render($writer);
			}
		}

		$this->drawPanels();
	}

	public function onFlipRfidMode($sender, $param)
	{
		$newState = $sender->getChecked();
		$this->rfidMode($newState, $param);
		$this->flushMessage();
	}

	public function rfidMode($newState = false, $param = null)
	{
		$this->setRfidMode($newState);
		$this->RfidModeCheck->setChecked($newState);
		$this->RfidModeLabel->setCssClass($newState
											? 'formlabelborderblue'
											: 'formlabel');

		if ($newState)
		{
			$this->enqueueMessage(Prado::localize('Riconoscimento automatico RFID attivato'),
										ClavisMessage::INFO);
		}
		else
		{
			$this->enqueueMessage(Prado::localize('Riconoscimento automatico RFID disattivato'),
										ClavisMessage::WARNING);
		}

		$this->drawPanels();
	}

	/*
	 * Called by button
	 */
	public function onPatronClean($sender, $param)
	{
		$this->ResultLabel->setText('');
		$this->ItemField->setText('');
		$this->CirculationData->setPatronId(null);
		$this->CirculationData->populate(null);
		$this->UserData->populate(null);
		$this->PatronId->setText(0);
		$this->ReserveHiddenValue->setValue('');

		$this->setFocus($this->ResultLabel->getClientID());
	}

	/*
	 * Called by code
	 */
	public function cleanPatron()
	{
		//Clean patron only if it has been readed from rf card
		$inputSource = $this->getViewState('PATRON_INPUT_SOURCE');
		if( $inputSource == self::INPUT_SOURCE_RFID)
		{
			$this->onPatronClean(null, null);
		}
	}

	public function onPatronReload($sender, $param)
	{
		$this->insertPatronId(trim($this->PatronId->getSafeText()));
	}

	public function onReloadPage($sender, $param)
	{
		$this->gotoPage('Circulation.NewLoan');
	}

	public function onPatronIdChanged($sender, $param)
	{
		$this->insertPatronId(intval($this->ReserveHiddenValue->getValue()));
	}

	public function onItemIdChanged($sender, $param)
	{
		$this->addItemId(intval($this->DuplicateItemHiddenValue->getValue()));

		$this->globalRefresh($param);
		$this->drawPanels();
	}

	public function panelsRefresh($param)
	{
		$this->globalRefresh($param);
		$this->drawPanels($param);
	}

	public function OLDonLastMovementPrintJasper($sender, $param)
	{
		$librarianId = $this->getUser()->getID();
		$libraryId = $this->getUser()->getActualLibraryId();
		$patron = $this->getPatron();

		if (!($patron instanceof Patron))
		{
			$this->writeMessage(Prado::localize("Errore: nessun utente selezionato"),
									ClavisMessage::ERROR);
			
			return false;
		}
		
		$patronId = $patron->getPatronId();
		$checkedDatasource1 = $this->LoanedFound->getCheckedItemIds();
		$checkedDatasource2 = $this->IllRequestedFound->getCheckedItemIds();
		$checkedDatasource = array_merge($checkedDatasource1, $checkedDatasource2);

		if (count($checkedDatasource) == 0)
		{
			$this->writeMessage(Prado::localize("Nessun prestito da stampare"),
									ClavisMessage::WARNING);
			
			return false;
		}

		$ids = "";
		
		foreach ($checkedDatasource as $row)
		{
			$item = null;
			$itemId = intval($row['itemId']);
		
			if ($itemId > 0)
				$item = ItemQuery::create()	->findPK($itemId);
			
			if (!($item instanceof Item))
				continue;

			if (!$this->_loanmanager->IsItemLoaned($item))
				continue;

			$loan = (object) null;
			$loanId = intval($item->getCurrentLoanId());
			
			if ($loanId > 0)
				$loan = LoanQuery::create()	->findPK($loanId);
			
			if (!($loan instanceof Loan))
				continue;

			if ($loan->getPatronId() != $patronId)
				continue;

			unset($item);
			unset($loan);

			$ids = $ids . $itemId . ",";
		}
		
		$ids = rtrim($ids, ",");

		if ($ids == "")
		{
			$this->writeMessage(Prado::localize("Nessun dato da stampare"),
									ClavisMessage::WARNING);
			
			return false;
		}

		$this->JRPBox->setObjectId($ids);
		$this->JRPBox->addOptionalParam('P_PATRONID', $patronId);
		$this->JRPBox->addOptionalParam('P_LIBRARYID', $libraryId);
		$this->JRPBox->addOptionalParam('P_LIBRARIANID', $librarianId);
		$this->JRPBox->printReport();
	}

	public function onLastMovementPrintJasper($sender, $param)
	{
		$librarianId = $this->getUser()->getID();
		$libraryId = $this->getUser()->getActualLibraryId();
		$loanIdQueue = $this->getLastMovementQueue();

		if (count($loanIdQueue) == 0)
		{
			$this->writeMessage(Prado::localize("Nessun prestito da stampare"),
									ClavisMessage::WARNING);

			$this->resetLastMovementQueue();

			return false;
		}

		$goOnFlag = true;
		$loanDirectionParam = "";
		
		if (array_key_exists('loanDirection', $loanIdQueue))
		{
			$loanDirection = $loanIdQueue['loanDirection'];
			unset($loanIdQueue['loanDirection']);

			switch ($loanDirection)
			{
				case self::LOANDIRECTION_DOLOAN:
					$loanDirectionParam = "out";

					break;

				case self::LOANDIRECTION_DOUNLOAN:
					$loanDirectionParam = "in";

					break;

				default:
					$goOnFlag = false;
			}
		}
		else
		{
			$goOnFlag = false;
		}

		if (!$goOnFlag)
		{
			$this->writeMessage(Prado::localize("Incongruenza su direzione report prestiti sul Banco. Riportare al fornitore del software."),
									ClavisMessage::ERROR);

			return false;
		}

		$objectIdsArray = array();
		
		foreach ($loanIdQueue as $loanId)
		{
			$loan = null;
		
			if ($loanId > 0)
				$loan = LoanQuery::create()->findPK($loanId);
			
			if (!($loan instanceof Loan))
				continue;

			$objectIdsArray[] = $loan->getLoanId();
			unset($loan);
		}

		$objectIds = implode(',', $objectIdsArray);

		if ($objectIds == "")
		{
			$this->writeMessage(Prado::localize("Nessun dato da stampare"),
									ClavisMessage::WARNING);

			return false;
		}

		// ok, we can print

		$this->JRPBox->setObjectId($objectIds);
		$this->JRPBox->addOptionalParam('P_LIBRARYID', $libraryId);
		$this->JRPBox->addOptionalParam('P_LIBRARIANID', $librarianId);
		$this->JRPBox->addOptionalParam('P_LOANDIRECTION', $loanDirectionParam);
		$this->JRPBox->printReport();
	}
	
}
