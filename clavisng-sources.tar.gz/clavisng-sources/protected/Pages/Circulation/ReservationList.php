<?php
/**
 * ReservationList Page class Module Catalog
 *
 * @author Marco Brancalion <mbrancalion@e-portaltech.it>
 * @link http://www.e-portaltech.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @license http://www.e-portaltech.it/license/
 *
 *
 * It views the actual interbibliotecary requests.
 *
 */
class ReservationList extends ClavisPage
{
	public $_module = "CIRCULATION";
	protected $_loanmanager;
	protected $_requestmanager;
	private $_fromLibraryId;
	private $_toLibraryId;
	private $_loanStatus;
	public $_llibraryActive;
	public $_requestTypeActive;
	
	private function initVars()
	{
		$this->_loanmanager = $this->getApplication()->getModule("loan");
		$this->_requestmanager = $this->getApplication()->getModule("request");
		$this->_llibraryActive = LLibraryPeer::isEnabled();
		$this->_requestTypeActive = ItemRequestPeer::isRequestType();
	}

	public function onInit($param)
	{
		parent::onInit($param);
		$this->initVars();

		/**
		 * Maybe it's no more necessary ...
		  ini_set('memory_limit', '700M');
		  set_time_limit(0);
		 */
		if (!$this->getPage()->getIsPostBack() 
				&& !$this->getPage()->getIsCallBack())
		{
			$this->doCleanFilter(false);
			
			/// mbrancaliontemp
			$this->doNeverCleanFilter(false); // don't populate at start
			$this->NeverRequestCatList->setDatasource($this->_requestmanager->getNeverRequestCategories(true));
			$this->NeverRequestCatList->databind();
		}
	}

	/**
	 * It manages the mechanism of setting (resetting/initialization) the
	 * dropdowns which perform as filters for the population of the
	 * loans grid.
	 *
	 * @param TEventParameter $param
	 */
	public function onLoad($param)
	{
		parent::onLoad($param);

		$this->_toLibraryId = $this->getToLibraryId();
		$this->_loanStatus = $this->getLoanStatus();

		if (!$this->getPage()->getIsPostBack()
				&& !$this->getPage()->getIsCallBack())
		{
			$this->_requestmanager->resetManagedReservations($this->getUser());
			$this->_requestmanager->resetExpiredReservations($this->getUser());

			$this->ToLibrary->setDataSource(LibraryPeer::getLibrariesHashWithBlank(null, null, true, 35));

			$selectedDeliveryLibrary = intval($this->getUser()->getActualLibraryId());
			if ($selectedDeliveryLibrary > 0)
				$this->ToLibrary->setSelectedValue($selectedDeliveryLibrary);
			
			if ($this->_llibraryActive)
			{	
				$this->MaxDistanceListFilter->setDataSource(LLibraryPeer::calculateRequestDistances(true));	// with blank
				$this->MaxDistanceListFilter->dataBind();
			}

			if ($this->_requestTypeActive)
			{	
				$requestTypes = ItemRequestPeer::getRequestTypes(true);	// with blank
				$nullValue = array(ItemRequestPeer::REQUESTTYPE_NULLVALUESTRING => Prado::localize('normale'));
				$requestTypes = array_merge(array_slice($requestTypes, 0, 1), $nullValue, array_slice($requestTypes, 1, null, true));
				
				$this->RequestTypeListFilter->setDataSource($requestTypes);
				$this->RequestTypeListFilter->dataBind();
				$this->RequestTypeListFilter->setSelectedValue(ItemRequestPeer::REQUESTTYPE_NULLVALUESTRING);
			}
			
			/**
			 * Filling of itemrequeststatus values into the checkboxlist, only first selected by default
			 */
			$statusDataSource = LookupValuePeer::getLookupClassValues('ITEMREQUESTSTATUS');
			$itemRequestActiveStatus = ItemRequestPeer::STATUS_PENDING;
			foreach ($statusDataSource as $value => $text)
			{
				$item = new TListItem();
				$item->setText($text);
				$item->setValue($value);

				$item->setSelected($value == $itemRequestActiveStatus);
				$this->StatusList->getItems()->add($item);
			}

			$this->ControlSwitches->dataBind();

			$this->globalRefresh(false, false);
			$this->getApplication()->getSession()->remove('ReassignedItemIds');
		}
		else
		{
			$reassignedItemIds = $this->getApplication()->getSession()->itemAt('ReassignedItemIds');
			$updateItemRequests = $this->getApplication()->getSession()->itemAt('UpdateItemRequests');

			if (!is_null($reassignedItemIds) && count($reassignedItemIds) > 0)
			{
				$this->getApplication()->getSession()->remove('ReassignedItemIds');
				$this->globalRefresh();
			}
			elseif (!is_null($updateItemRequests)
					&& ($updateItemRequests == true))
			{
				$this->getApplication()->getSession()->remove('UpdateItemRequests');
				$this->globalRefresh(true, true);	// with population
			}
		}

		$this->doToLibrarySwitches();
	}
/**/
	public function onPreRender($param) 
	{
		parent::onPreRender($param);
//var_dump(intval($this->Reservation->countCheckedItems()));
		$addToShelfVisible = (intval($this->Reservation->countCheckedItems()) > 0);
		$this->ReservationOperationPanel->setStyle('margin-top: 4em; display: ' . ($addToShelfVisible ? 'inline': 'none') . ";");
	}
/**/	
	private function readItemRequestStatusList()
	{
		$items = $this->StatusList->getItems();
		$resultArray = array();
		foreach ($items as $item)
		{
			if ($item->getSelected())
				$resultArray[] = $item->getValue();
		}

		return $resultArray;
	}

	private function writeItemRequestStatusList($values = array())
	{
		if (count($values) == 0)
			return;

		$items = $this->StatusList->getItems();
		foreach ($items as $item)
		{
			$value = $item->getValue();
			if (isset($values[$value]))
			{
				$item->setSelected($values[$value]);
			}
			else
			{
				$item->setSelected(false);
			}
		}
	}

	public function setToLibraryId($lib)
	{
		$this->_toLibraryId = $lib;
		$this->setViewState('toLibraryId', $this->_toLibraryId, null);
	}

	public function getToLibraryId()
	{
		if (($lib = $this->_toLibraryId) == null)
		{
			$lib = $this->getViewState('toLibraryId', null);
			$this->_toLibraryId = $lib;
		}

		return $lib;
	}

	public function setFromLibraryId($lib)
	{
		$this->_fromLibraryId = $lib;
		$this->setViewState('fromLibraryId', $this->_fromLibraryId, null);
	}

	public function getFromLibraryId()
	{
		if (($lib = $this->_fromLibraryId) == null)
		{
			$lib = $this->getViewState('fromLibraryId', null);
			$this->_fromLibraryId = $lib;
		}

		return $lib;
	}

	public function setLoanStatus($loanStatus)
	{
		$this->_loanStatus = $loanStatus;
		$this->setViewState('loanStatus', $this->_loanStatus, null);
	}

	public function getLoanStatus()
	{
		if (($loanStatus = $this->_loanStatus) == null)
			$this->_loanStatus = $loanStatus;

		return $loanStatus;
	}

	/**
	 * Does this page have popups inside?.....
	 *
	 * @return boolean
	 */
	public function isPopup()
	{
		return false;
	}

	public function globalRefresh($populate = false, $neverPopulate = false)
	{
		$this->refreshReservation($populate);
		
		if ($this->NeverRequestCatList->getSelectedIndex() >= 1)
			$this->refreshNeverReservation($neverPopulate);
	}

	public function refreshReservation($populate = true)
	{
		$toLibraryId = $this->ToLibrary->getSelectedValue();
		$patronId = $this->HiddenValue->Value;

		$outDateFrom = $this->OutDateFrom->getSafeText() != '' ? $this->OutDateFrom->getTimeStamp() : null;
		$outDateTo = $this->OutDateTo->getSafeText() != '' ? $this->OutDateTo->getTimeStamp() : null;

		$statusList = $this->readItemRequestStatusList();
		$notManageableFlag = false;

		$oocMode = $this->OocModeFilter->getSelectedValue();
		if ($oocMode == "1")
		{
			$oocMode = true;
		}
		else
		{
			$oocMode = false;
		}

		$maxDistance = null;
					
		if ($this->_llibraryActive
				&& ($this->MaxDistanceListFilter->getSelectedIndex() > 0))
			$maxDistance = $this->MaxDistanceListFilter->getSelectedValue();

		$requestType = null;
					
		if ($this->_requestTypeActive
				&& ($this->RequestTypeListFilter->getSelectedIndex() > 0))
			$requestType = $this->RequestTypeListFilter->getSelectedValue();

		$this->Reservation->setFilters(	null,
										$toLibraryId,
										$patronId,
										null, //$renewCount,
										$outDateFrom,
				
										$outDateTo,
										$statusList,
										null,
										null,
										null,
				
										null,
										$notManageableFlag,
										$oocMode,
										null,
										$maxDistance,
				
										$requestType);	// 16

		$this->Reservation->resetDataSource();

		if ($populate)
			$this->Reservation->populate();
	}

	public function refreshNeverReservation($populateFlag = false)
	{
		$category = $this->NeverRequestCatList->getSelectedValue();

		if ($populateFlag
				&& (!in_array($category, array_keys($this->_requestmanager->getNeverRequestCategories()))))
		{
			$this->getPage()->writeMessage(Prado::localize("Selezionare un criterio di ricerca per le prenotazioni non soddisfacibili"),
											ClavisMessage::WARNING);
		
			return false;
		}
		
		$this->NeverReservation->setNeverRequestCategory($category);
		$this->NeverReservation->resetDataSource(false);

		if ($populateFlag)
			$this->NeverReservation->populate();
	}
	
	public function onCleanFilter($sender, $param)
	{
		$this->doCleanFilter(false); // no more autopopulate after cleaning
	}

	public function onNeverCleanFilter($sender, $param)
	{
		$this->doNeverCleanFilter(false);
	}

	public function doCleanFilter($populateFlag = false)
	{
		$this->onResetOutDate(null, null);
		$this->onResetPatron(null, null);
		
		if ($this->_llibraryActive)
			$this->MaxDistanceListFilter->setSelectedIndex(-1);

		if ($this->_requestTypeActive)
			$this->RequestTypeListFilter->setSelectedValue(ItemRequestPeer::REQUESTTYPE_NULLVALUESTRING);

		$this->doToLibrarySwitches();

		$itemRequestActiveStatus = ItemRequestPeer::STATUS_PENDING;
		$this->writeItemRequestStatusList(array($itemRequestActiveStatus => true));

		$this->OocModeFilter->setSelectedIndex(0);

		$this->refreshReservation($populateFlag);
	}

	// mbrancaliontemp, vecchia versione, da tirare via
	public function doNeverCleanFilterOLD($populateFlag = false)
	{
		$this->LoanStatusFlagCheckBox->setChecked(false);
		$this->LoanableSinceFlagCheckBox->setChecked(false);
		$this->onNeverResetOutDate(null, null);
		$this->refreshNeverReservation($populateFlag);
	}

	public function doNeverCleanFilter($populateFlag = false)
	{
		$this->NeverRequestCatList->setSelectedIndex(-1);
		$this->refreshNeverReservation($populateFlag);
	}

	public function doToLibrarySwitches()
	{
		$linksVisibility = $this->ToLibrary->getSelectedIndex() > 0;
		$this->ToLibraryAllLinkButton->setVisible($linksVisibility);
		$this->ToLibraryOnlySelectedLinkButton->setVisible(!$linksVisibility);
	}

	/**
	 * It resets (also visually) the choice of patron.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onResetPatron($sender, $param)
	{
		$this->HiddenLabel->setValue('');
		$this->HiddenValue->setValue('');
		$this->PatronLabel->setText('');
		$this->setPatronChoiceDone(false, $param);
	}

	/**
	 * It updates the page in case a new patron is choosen.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onPatronIdChanged($sender, $param)
	{
		$patron = null;
		$patronId = intval($this->HiddenValue->getValue());
		
		if ($patronId > 0)
			$patron = PatronQuery::create()
					->findPK($patronId);
		
		if ($patron instanceof Patron)
		{
			$completeName = $patron->getCompleteName();
			$barcode = trim($patron->getBarcode());
			if ($barcode != '')
				$barcode = ' (' . $barcode . ')';

			$this->PatronLabel->setText($completeName . $barcode);
			$this->setPatronChoiceDone(true, $param);
		}
	}

	/**
	 * Updates page elements if choice of patron is valid
	 *
	 * @param boolean $flag
	 * @param TEventParameter $param
	 */
	public function setPatronChoiceDone($flag, $param)
	{
		$this->PatronLabel->setVisible($flag);
		$this->PatronChoiceButton->setVisible(!$flag);
		$this->PatronResetButton->setVisible($flag);

		if (!is_null($param))
			$this->PatronPanel->render($param->getNewWriter());
	}

	/**
	 * It resets (also visually) the date choice.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onResetOutDate($sender, $param)
	{
		$this->OutDateFrom->setText(null);
		$this->OutDateTo->setText(null);

		if ($this->getPage()->getIsCallback())
		{
			if (is_null($param))
			{
				$writer = $this->getPage()->createWriter();
			}
			else
			{
				$writer = $param->getNewWriter();
			}

			$this->OutDatePanel->render($writer);
		}
	}

	public function onNeverResetOutDate($sender, $param)
	{
		$this->NeverOutDateFrom->setText(null);
		$this->NeverOutDateTo->setText(null);

		if ($this->getPage()->getIsCallback())
		{
			if (is_null($param))
			{
				$writer = $this->getPage()->createWriter();
			}
			else
			{
				$writer = $param->getNewWriter();
			}

			$this->NeverOutDatePanel->render($writer);
		}
	}

	/**
	 * Callback from search button in the page.
	 * It performs retrieving of filters and next it populates.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onSearch($sender, $param)
	{
		$this->refreshReservation();
	}

	public function onNeverSearch($sender, $param)
	{
		$this->refreshNeverReservation(true);
	}

	public function onSubmit($sender, $param)
	{
		$this->globalRefresh(true, true);	// with population
	}
	
	public function drawDuplicateItemBarcodePanel($newState = false, $param = null)
	{
		$currentState = $this->DuplicateItemBarcodePanel->getCssClass() == "panel_on" ? true : false;

		if ($currentState != $newState)
		{
			$newCssClass = $newState ? 'panel_on' : 'panel_off';
			$this->DuplicateItemBarcodePanel->setCssClass($newCssClass);

			if ($this->getPage()->getIsCallback() && !is_null($param))
				$this->DuplicateItemBarcodePlaceHolder->render($param->getNewWriter());
		}
	}

	public function onPrintJRPReservation($sender, $param)
	{
		$datasource = $this->Reservation->getCheckedItems(true, true, true);	 // all + reset, + jaspermode

		if (array_key_exists('requestId', $datasource))
			$requestId = $datasource['requestId'];
		
		if (array_key_exists('itemId', $datasource))
			$itemId = $datasource['itemId'];

		if (count($requestId) == 0)
		{
			$this->getPage()->writeMessage(Prado::localize("Non c'è nulla da stampare"),
											ClavisMessage::WARNING);
			
			return;
		}

		$requestId = implode(',', $requestId);
		$itemId = implode(',', $itemId);

		$this->JRPBox->setObjectId($requestId);
		$this->JRPBox->addOptionalParam('P_ITEMIDPOOL', $itemId);
		$this->JRPBox->printReport();
	}

	public function onSelectLibrary($sender, $param)
	{
		$newLibrary = intval($param->getCommandParameter());
		if ($newLibrary >= 0)
		{
			$this->ToLibrary->setSelectedValue($newLibrary);
			//$this->onSubmit(null, null);
			$this->refreshReservation(true);
		}

		$this->doToLibrarySwitches();
	}
	
	/** probably unused, logic was moved into ClavisManageRequestsList */
	/* now reactivated for generic searched requests */
	public function onAddToShelf($sender, $param)
	{
		$counter = 0;
		$shelfId = intval(trim($this->ShelfResultValue->getSafeText()));

		$this->ShelfResultLabel->setText('');
		$this->ShelfResultValue->setText('');

		if ($shelfId > 0)
		{
			$shelf = ShelfQuery::create()->findPk($shelfId);
			
			if ($shelf instanceof Shelf)
			{
				$ids = [];
				
				foreach ($this->Reservation->getCheckedItems() as $requestCombo)
					$ids[] = $requestCombo['id'];
				
				if (count($ids) == 0)
				{
					$this->writeMessage(Prado::localize("Non risultano elementi selezionati. Riportare al fornitore del software."), 
											ClavisMessage::ERROR);

					return false;
				}
				
				$counter = $shelf->addItemToShelf(ShelfPeer::TYPE_ITEM_REQUEST, $ids);
			}
			else
			{
				$this->writeMessage(Prado::localize("Lo scaffale con id: {shelfid} non esiste. Riportare al fornitore del software.",
														array('shelfid' => $shelfId)), 
										ClavisMessage::ERROR);
				
				return false;
			}
		}

		if ($counter > 0)
		{
			$this->writeMessage(Prado::localize("N° {count} prenotazioni aggiunte nello scaffale '{shelfname}' (id: {shelfid})", 
														array(	'count' => $counter,
																'shelfname' => $shelf->getShelfCompleteName(','),
																'shelfid' => $shelfId )),
									ClavisMessage::CONFIRM);
		}
		else
		{	
			$this->writeMessage(Prado::localize("Nessun elemento aggiunto a scaffale"), 
									ClavisMessage::ERROR);
		}
	}
	
}