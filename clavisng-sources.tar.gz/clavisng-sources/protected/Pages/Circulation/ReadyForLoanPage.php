<?php
/**
 * ReadyForLoanPage class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 ePortal Technologies
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Pages.Circulation
 */

/**
 * ReadyForLoanPage Class
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.8.9
 * @package Pages.Circulation
 * @since 2.0
 */
class ReadyForLoanPage extends ClavisPage
{
	public $_module = 'CIRCULATION';
	protected $_loanmanager;
	
	private $_fromLibraryId;
	private $_loanStatus;

 	public function initVars()
 	{
 		$this->_loanmanager = $this->getApplication()->getModule('loan');
 	}

	public function onInit($param)
	{
		parent::onInit($param);
		$this->initVars();

		$this->MultiSoliciter->setGetCheckedItemsFunctionName('getCheckedItems');
		$this->MultiSoliciter->setCountCheckedItemsFunctionName('countCheckedItems');
		$this->MultiSoliciter->setInitialReloadFunctionName('loanListInitialReload');

		// first page cycle
		if (!$this->getPage()->getIsPostBack() 
				&& !$this->getPage()->getIsCallback())
		{
			$this->ReadyForLoan->setLoanStatusMode(array(ItemPeer::LOANSTATUS_READYFORLOAN));
			$this->doCleanFilters();
		}
	}

	public function onLoad($param)
	{
		parent::onLoad($param);

		$this->_fromLibraryId = $this->getFromLibraryId();
		$this->_loanStatus = $this->getLoanStatus();

		// first page cycle
		if (!$this->getPage()->getIsPostBack())
		{
			$librariesWithBlank = LibraryPeer::getLibrariesHashWithBlank();
			$this->FromLibrary->setDataSource($librariesWithBlank);
			$this->ControlSwitches->dataBind();

			$this->ContactBooleanFilter->setDataSource(array(	1 => Prado::localize('con'),
																0 => Prado::localize('senza') ));

			$this->ContactBooleanFilter->dataBind();
			$this->ContactBooleanFilter->setSelectedValue(1);
			
			$this->SolicitCount->setDataSource(array(	-1 => '--',
														0 => '0',
														1 => '1',
														2 => '2',
														3 => Prado::localize('più di') . ' 2') );

			$this->SolicitCount->dataBind();
			$this->SolicitCount->setSelectedValue(-1);

			$this->globalRefresh();

			//$this->focusToComponent($this->LoanBarcodeTextbox);
			$this->setFocus($this->BarcodeFilter);
		}
	}

	// setters & getters
	
 	public function setFromLibraryId($lib)
 	{
 		$this->_fromLibraryId = $lib;
 		$this->setViewState('fromLibraryId', $this->_fromLibraryId, null);
 	}

 	public function getFromLibraryId()
 	{
 		if (($lib = $this->_fromLibraryId) == null)
 		{
 			$lib = $this->getViewState('fromLibraryId', null);
 			$this->_fromLibraryId = $lib;
 		}
		
		return $lib;
 	}

 	public function setLoanStatus($loanStatus)
 	{
 		$this->_loanStatus = $loanStatus;
 		$this->setViewState('loanStatus', $this->_loanStatus, null);
 	}

 	public function getLoanStatus()
 	{
 		if (($loanStatus = $this->_loanStatus) == null)
 			$this->_loanStatus = $loanStatus;

		return $loanStatus;
 	}

 	/**
 	 * Does this page have popups inside?.....
 	 *
 	 * @return boolean
 	 */
 	public function isPopup()
 	{
 		return false;
 	}

 	/**
 	 * It refreshes all the components (grids) in the page,
 	 * altogether.
 	 *
 	 */
 	public function globalRefresh()
 	{
 		$barcode = $this->BarcodeFilter->getSafeText();
		$fromLibraryId = $this->FromLibrary->getSelectedValue();
		$patronId = $this->HiddenValue->Value;

		$outDateFrom = $this->OutDateFrom->getText() != '' ? $this->OutDateFrom->getTimeStamp() : null;
		$outDateTo = $this->OutDateTo->getText() != '' ? $this->OutDateTo->getTimeStamp() : null;

		$lastSeenDateFrom = $this->LastSeenDateFrom->getText() != '' ? $this->LastSeenDateFrom->getTimeStamp() : null;
		$lastSeenDateTo = $this->LastSeenDateTo->getText() != '' ? $this->LastSeenDateTo->getTimeStamp() : null;

		$contactFilter = $this->ContactFilter->getSelectedValue();
		$preferredContact = $this->PreferredCheck->getChecked();
		
		switch ($this->ContactBooleanFilter->getSelectedValue())
		{
			case 0:
				$contactBoolean = false;
		
				break;
			
			case 1:
			default:
				$contactBoolean = true;
		}

		$solicitCount = $this->SolicitCount->getSelectedValue();
		
 		$this->ReadyForLoan->setFilters(	$barcode,
											$fromLibraryId,
											$patronId,
											$outDateFrom,
											$outDateTo,

											$lastSeenDateFrom,
											$lastSeenDateTo,
											false,
											$contactFilter,
											$preferredContact,

											$contactBoolean,
											$solicitCount);

 		$this->ReadyForLoan->resetDataSource();
 	}

 	/**
 	 * It updates the page in case a new patron is choosen.
 	 */
	public function onPatronIdChanged($sender, $param)
 	{
 		$patron = null;
 		$id = intval($this->HiddenValue->getValue());
		
 		if ($id > 0)
 			$patron = PatronQuery::create()->findPK($id);
		
 		if ($patron instanceof Patron)
 		{
 			$completeName = $patron->getCompleteName();
 			$barcode = trim($patron->getBarcode());
 		
			if ($barcode != '')
 				$barcode = ' (' . $barcode . ')';

 			$this->PatronLabel->setText($completeName . $barcode);
 			$this->setPatronChoiceDone(true, $param);
 		}
 	}
	
 	/**
 	 * It resets (also visually) the choice of patron.
 	 */
	public function onResetPatron($sender, $param)
	{
		$this->HiddenLabel->setValue('');
		$this->HiddenValue->setValue('');
 		$this->PatronLabel->setText('');
		$this->setPatronChoiceDone(false, $param);
	}

 	public function setPatronChoiceDone($flag, $param)
 	{
		$this->PatronLabel->setVisible($flag);
		$this->PatronChoiceButton->setVisible(!$flag);
		$this->PatronResetButton->setVisible($flag);

		if (!is_null($param) 
				&& $this->getPage()->getIsCallback())
			$this->PatronPanel->render($param->getNewWriter());
 	}
	
 	/**
 	 * It resets (also visually) the date choice.
 	 */
	public function onResetOutDate($sender, $param)
	{
		$this->OutDateFrom->setText('');
		$this->OutDateTo->setText('');

		if ($this->getPage()->getIsCallback() 
				&& !is_null($param))
			$this->OutDatePanel->render($param->getNewWriter());
	}

	public function onResetLastSeenDate($sender, $param)
	{
		$this->LastSeenDateFrom->setText('');
		$this->LastSeenDateTo->setText('');

		if ($this->getPage()->getIsCallback() 
				&& !is_null($param))
			$this->LastSeenPanel->render($param->getNewWriter());
	}

	private function doCleanFilters()
	{
		$this->onResetPatron(null, null);
		$this->onResetOutDate(null, null);
		$this->onResetLastSeenDate(null, null);
		$this->FromLibrary->setSelectedIndex(0);
		$this->BarcodeFilter->setText('');
		$this->ContactFilter->setSelectedIndex(0);
		$this->PreferredCheck->setChecked(false);
		$this->ContactBooleanFilter->setSelectedValue(1);
		$this->SolicitCount->setSelectedValue(-1);
	}
	
	public function onCleanFilters($sender, $param)
	{
		$this->doCleanFilters();
		$this->globalRefresh();
		
		//$this->focusToComponent($this->BarcodeFilter);
		$this->setFocus($this->BarcodeFilter);
	}

	/**
	 * Callback from update button in the page.
	 * It performs retrieving of filters and next it populates.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onSubmit($sender, $param)
	{
		$this->globalRefresh();
		$this->setFocus($this->LoanBarcodeTextbox);
	}

	public function onLoan($sender, $param)
	{
		$input = $this->LoanBarcodeTextbox->getSafeText();
		$input = trim($input);
		
		if ($input != '')
		{
			$this->LoanBarcodeTextbox->setText('');
			$loanable = $this->ReadyForLoan->searchCodesIntoDatasource($input);
		}
		else
		{
			$loanable = $this->ReadyForLoan->getItemsWithDueDate();
		}

		if (count($loanable) == 0)
		{
			$this->getPage()->writeMessage(Prado::localize("Nessun elemento da processare riconosciuto come valido"), 
											ClavisMessage::INFO);
			
			//$this->focusToComponent($this->LoanBarcodeTextbox);
			$this->setFocus($this->LoanBarcodeTextbox);

			return false;
		}

		$clavisLibrarian = $this->getUser();
		$loanCount = 0;
		$consultationCount = 0;
		$failedCount = 0;
		$patronNotEnabledCount = 0;
		$patronReachedMaxCount = 0;

		$this->cleanMessageQueue();
		$zebraReceiptFlag = ClavisParamQuery::getParam('CLAVISPARAM', 'ZebraAutoReceipt');
				
		/* @var $item Item */
		foreach ($loanable as $row)
		{
			$item = $row['item'];
			$inventory = $item->getCompleteInventoryNumber();
			$barcode = $item->getBarcode();
			$dueDate = $row['dueDate'];
			
			$result = $this->_loanmanager->DoReadyToLoan2LoanItem(	$item, 
																	$clavisLibrarian, 
																	$dueDate );

			$itemDataString = $item->getTrimmedTitle(40, true)	// indication of external property
									. ($inventory == ''
										? ''
										: ' (' . Prado::localize('inventario') . ': ' . $inventory . ')')
					
									. ($barcode == '' 
										? '' 
										: ' (' . Prado::localize('barcode:') . $barcode . ')');
			
			if ($result == ClavisLoanManager::OK)
			{
				if ($item->isStatusConsultation())
				{
					$consultationCount++;
					
					$this->enqueueMessage(Prado::localize("In consultazione") . ": " . $itemDataString,
											ClavisMessage::CONFIRM);
				}
				else
				{
					$loanCount++;
					$this->enqueueMessage(Prado::localize("In prestito") . ": " . $itemDataString,
											ClavisMessage::CONFIRM);
				}
				
				if ('true' == $zebraReceiptFlag)
					$this->ClavisClient->printLoanLabel('receipt', $item->getCurrentLoanId());
			}
			elseif ($result == ClavisLoanManager::LOAN_PATRONNOTENABLED)
			{
				$patron = $item->getPatron();
				
				$patronData = ($patron instanceof Patron
								? $patron->getReverseCompleteName()
								: "(" . Prado::localize('utente inesistente') . ")" );
				
				$patronNotEnabledCount++;
				
				$this->enqueueMessage(Prado::localize("Operazione fallita su '{item}' perchè all'utente '{patron}' non sono consentiti prestiti",
														array(	'item' => $itemDataString,
																'patron' => $patronData )),
										ClavisMessage::ERROR);
			}
			else	// fallback
			{
				$failedCount++;
				$this->enqueueMessage(Prado::localize("Operazione fallita su") . ": " . $itemDataString,
										ClavisMessage::ERROR);
			}
		}

		if ($consultationCount + $loanCount > 1)
		{	
			if ($consultationCount > 0)
				$this->enqueueMessage(Prado::localize("Totale messi consultazione: {consultationCount}",
														array('consultationCount' => $consultationCount)),
										ClavisMessage::CONFIRM);	

			if ($loanCount > 0)
				$this->enqueueMessage(Prado::localize("Totale passati in prestito: {loanCount}",
														array('loanCount' => $loanCount)),
										ClavisMessage::CONFIRM);
		}
		
		if ($failedCount > 0)
			$this->enqueueMessage(Prado::localize("Totale errori: {failedCount}",
													array('failedCount' => $failedCount)),
									ClavisMessage::ERROR);		
		
		if ($patronNotEnabledCount > 0)
			$this->enqueueMessage(Prado::localize("Totale errori per utente non abilitato: {count}",
													array('count' => $patronNotEnabledCount)),
									ClavisMessage::ERROR);		
		
		if ($loanCount + $consultationCount + $failedCount + $patronNotEnabledCount == 0)
			$this->enqueueMessage(Prado::localize("Nessuna operazione è stata effettuata"),
									ClavisMessage::INFO);		

		$this->flushMessage();
		
		//$this->focusToComponent($this->LoanBarcodeTextbox);
		$this->setFocus($this->LoanBarcodeTextbox);

		// if something worked, we need to redraw the list
		if ($loanCount + $consultationCount > 0)
		{
			$this->ReadyForLoan->resetDataSource();

			if ($this->getIsCallback())
			{
				$this->ReadyForLoanPanel->render(is_null($param)
													? $this->createWriter()
													: $param->getNewWriter());
			}
		}
	}

	public function onPrintJRPReadyForLoan($sender, $param)  // items to put to shelf again
	{
		$datasource = $this->ReadyForLoan->getCheckedItemsItemId(true, true);     // all + reset
		$ids = implode(',', $datasource);	

		$this->JRPBox->setObjectId($ids);
		$this->JRPBox->addOptionalParam('P_ORDER', $this->ReadyForLoan->getSortingExpression());		
		$this->JRPBox->addOptionalParam('P_ORDERDIR', $this->ReadyForLoan->getSortingDirection());
		
		$this->JRPBox->printReport();
	}	
	
	private function focusToComponent($component = null)
	{
		if (is_null($component))
			return false;

		if ($this->getPage()->getIsCallback())
		{
			$page= $this->Application->getService('page')->RequestedPage;
			$page->CallbackClient->callClientFunction("Prado.Element.focus", array($component->getClientID()));
		}
		else
		{
			$this->UserFocus->setFocusComponent($component);
		}
	}

	public function getCheckedItems($force = false, $reset = false)
	{
		$dataSource = $this->ReadyForLoan->getCheckedItemsLoanId($force, $reset);
		
		if (is_null($dataSource))
			$dataSource = array();
		
		return $dataSource;
	}

	public function countCheckedItems()
	{
		$count = $this->ReadyForLoan->countCheckedItems();
		
		if (is_null($count))
			$count = 0;
		
		return $count;
	}

	public function loanListInitialReload()
	{
		$this->ReadyForLoan->resetDataSource();
	}
	
}