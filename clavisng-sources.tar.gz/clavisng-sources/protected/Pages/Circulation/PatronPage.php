<?php
/**
 * PatronPage class file.
 * This file contains all the required classes for SBN dialogue v4.
 * Based upon SBNConnector by Comperio srl.
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 * For Commercial Licenses and support please contact Comperio.
 * @author    Dario Rigolin <dario@comperio.it>
 * @author Ciro Mattia Gonano
 * @link      http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license   http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version   2.7
 * @package   Pages.Circulation
 */

/**
 * PatronPage Class
 * @author  Dario Rigolin <dario@comperio.it>
 * @author  Max Pigozzi
 * @author Ciro Mattia Gonano
 * @author  Cristian Chiarello <cristian.chiarello@comperio.it>
 * @author  Marco Brancalion <marco@comperio.it>
 * @version 2.7
 * @package Pages.Circulation
 * @since   2.0
 */
class PatronPage extends ClavisPage
{
	public $_module = 'CIRCULATION';

	/**
	 * @var Patron  patron object
	 */
	private $_patron = null;
	public $customs_type = array('text', 'text', 'text');

	public function onInit($param)
	{
		parent::onInit($param);

		if (!$this->getIsPostBack())
		{
			$patron = null;
			$id = intval($this->getRequest()->itemAt('id'));
			
			if ($id > 0)
			{
				$patron = PatronQuery::create()->findPk($id);

				if (!($patron instanceof Patron))
				{
					$this->writeMessage(Prado::localize("L'utente con id = {id} non esiste", array('id' => $id)),
						ClavisMessage::ERROR);

					$this->gotoPage('Circulation.PatronList');
				}
			}

			if (is_null($patron))
			{
				$patron = new Patron();
				$this->setIsNew(true);
				$this->PatronSummary->setIsNew(true);
			}

			$newPatronParams = $this->getRequest()->itemAt('newPatronParams');
			
			if ($newPatronParams !== '')
			{
				$newPatronParams = @unserialize($newPatronParams);
			
				if (is_array($newPatronParams))
				{
					foreach ($newPatronParams as  $rule) {
						switch ($rule['id']) {
							case 'lastname':
								$patron->setLastname($rule['value']);
								break;

							case 'name':
								$patron->setName($rule['value']);
								break;

							case 'birth_date':
								try {
									$patron->setBirthDate($rule['value']);
								} catch (Exception $e) { /* if date is malformed, fail gracefully and ignore it. */ }
								break;

							case 'national_id':
								$patron->setNationalId($rule['value']);
								break;
						}
					}
				}
			}

			$this->setPatron($patron);
			$this->PatronSummary->populate($patron->getPatronId());
		}

		if (!$this->getIsPostBack() && !$this->getIsCallback())   // first time
		{
			$this->ModifyAnagAddrButton->setVisible($this->getUser()->checkAllowedPage('Circulation.AddressListAnag'));
			$this->ModifyAddrButton->setVisible($this->getUser()->checkAllowedPage('Circulation.AddressList'));
		}
	}

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (LookupValuePeer::classExists('PATRONCUST1'))
			$this->customs_type[0] = 'list';

		if (LookupValuePeer::classExists('PATRONCUST2'))
			$this->customs_type[1] = 'list';

		if (LookupValuePeer::classExists('PATRONCUST3'))
			$this->customs_type[2] = 'list';

		// if we are in first page cycle
		if (!$this->getIsPostBack()
			&& !$this->getIsCallback()) {
			$libraries = LibraryPeer::getLibrariesHashWithBlank(null, true);    // only internal ones
			$this->FavLibrary->setDataSource($libraries);
			$this->FavLibrary->dataBind();

			$this->setAddAddress(false);
			$this->setAddContact(false);

			$this->populateForm();
			$this->dataBind();
		} else    // not first page cycles
		{
			//gestione postback da popup di selezione foto
			if ($this->ChangePhotoPopupValue->getValue() == 'OK')
			{
				ChangelogPeer::logAction($this->getPatron(),        // in this row we fixed the cause for object_class as (string) 'null' in changelogs....
					ChangelogPeer::LOG_UPDATE,
					$this->getUser(),
					'cambiata foto identificativa');

				$this->writeMessage(Prado::localize('Foto cambiata correttamente'),
					ClavisMessage::INFO);

				$this->reloadPage();
			} 
			elseif ($this->ChangePhotoPopupValue->getValue() == 'CANCEL')
			{
				$this->reloadPage();
			}
		}

		$this->getPatron();

		if (!$this->getIsNew())
		{
			$this->Photo->setImageURL($this->getRequest()->constructUrl('file', $this->_patron->getPhotoFileId()));
			$this->populateProperties();
			$this->AttachmentManager->setObjectClass('Patron');
			$this->AttachmentManager->setObjectId($this->_patron->getPatronId());
		}

		/**
		 * Modifica di mbrancalion, 29-02-2008.
		 * Serve per l'apertura, con una sola riga in edit, di address e contact,
		 * nel caso siamo nell'inserimento di un nuovo patron.
		 */
		if (!$this->getIsPostBack()
				&& !$this->getIsCallback()
				&& $this->getIsNew()) {
			$this->globalEditCancel();

			$newAddress = new Address();
			$this->AddressList->setDataSource(array($newAddress));
			$this->AddressList->SelectedItemIndex = -1;
			$this->AddressList->EditItemIndex = 0;
			$this->AddressList->dataBind();

			$newContact = new Contact();
			$this->ContactList->setDataSource(array($newContact));
			$this->ContactList->SelectedItemIndex = -1;
			$this->ContactList->EditItemIndex = 0;
			$this->ContactList->dataBind();

			$this->setFocus($this->Lastname->getClientId());
		}

		$this->setIsEditAddress(false);
		$this->setIsEditContact(false);
	}

	public function setIsEditAddress($value = false)
	{
		$value = TPropertyValue::ensureBoolean($value);
		$this->setControlState("IsEditAddress", $value, false);
	}

	public function getIsEditAddress()
	{
		return $this->getControlState("IsEditAddress", false);
	}

	public function setIsEditContact($value = false)
	{
		$value = TPropertyValue::ensureBoolean($value);
		$this->setControlState("IsEditContact", $value, false);
	}

	public function getIsEditContact()
	{
		return $this->getControlState("IsEditContact", false);
	}

	public function setIsNew($isNew)
	{
		$isNew = TPropertyValue::ensureBoolean($isNew);
		$this->setControlState("is_new", $isNew, false);
	}

	public function getIsNew()
	{
		return $this->getControlState("is_new", false);
	}

	public function setAddAddress($value)
	{
		$value = TPropertyValue::ensureBoolean($value);
		$this->setControlState("AddAddress", $value, false);
	}

	public function getAddAddress()
	{
		return $this->getControlState("AddAddress", false);
	}

	public function setAddContact($value)
	{
		$value = TPropertyValue::ensureBoolean($value);
		$this->setControlState("AddContact", $value, false);
	}

	public function getAddContact()
	{
		return $this->getControlState("AddContact", false);
	}

	public function setReadOnly($sender, $param)
	{
		$list = $this->Main->getControls();

		foreach ($list as $comp) 
		{
			if ($comp instanceof TControl
					&& $comp->canSetProperty('ReadOnly'))
				$comp->setReadOnly(true);
		}
	}

	public function patronSave()
	{
		if (!$this->getIsValid())
			return false;

		$this->cleanMessageQueue();

		$this->_patron->setTitle($this->Title->getSelectedValue());

		$firstName = trim($this->Firstname->getSafeText());
		$lastName = trim($this->Lastname->getSafeText());
		$this->_patron->setName($firstName);
		$this->_patron->setLastname($lastName);

		if (($this->_patron->getPatronStatus() != $this->PatronState->getSelectedValue())
			&& !is_null($this->_patron->getPatronId()))
			ChangelogPeer::logAction($this->_patron,
										ChangelogPeer::LOG_UPDATE,
										$this->getUser(),
										"aggiornato stato: '"
										. LookupValuePeer::getLookupValue('PATRONSTATE', $this->PatronState->getSelectedValue())
										. "'");

		$this->_patron->setPatronStatus($this->PatronState->getSelectedValue());
		$this->_patron->setGender($this->Sex->getSelectedValue());
		$this->_patron->setCivilStatus($this->CivilState->getSelectedValue());

		$birthDate = trim($this->BirthDate->getDate());
		if ($birthDate !== "") 
		{
			$bd = new DateTime($birthDate);
		} 
		else 
		{
			$bd = null;
		}

		$this->_patron->setBirthDate($bd);

		$city = $this->BirthCity->getSafeText();

		if ($city == '')
			$city = null;

		$this->_patron->setBirthCity($city);

		$province = $this->BirthProvince->getSafeText();

		if ($province == '')
			$province = null;

		$this->_patron->setBirthProvince($province);


		$country = $this->BirthCountry->getSafeText();

		if ($country == '') 
		{
			$country = null;
		} 
		else 
		{
			if (!LookupValueQuery::countryExists($country)) 
			{
				$this->enqueueMessage(Prado::localize("Dati anagrafici: nazione non ISO"),
										ClavisMessage::WARNING);
			}
		}

		$this->_patron->setBirthCountry($country);

		$citizenship = $this->Citizenship->getSafeText();

		if ($citizenship == '') 
		{
			$citizenship = null;
		} 
		else 
		{
			if (!LookupValueQuery::citizenshipExists($citizenship)) 
			{
				$this->enqueueMessage(Prado::localize("Dati anagrafici: nazionalità non ISO"),
										ClavisMessage::WARNING);
			}
		}

		$this->_patron->setCitizenship($citizenship);

		$this->_patron->setDocumentExpiry($this->DocExpireDate->getData());
		$this->_patron->setDocumentType($this->DocType->getSelectedValue());
		$this->_patron->setDocumentNumber($this->DocNumber->getSafeText());
		$this->_patron->setDocumentEmitter($this->DocReleasedBy->getSafeText());

		$barcode = trim(TPropertyValue::ensureString($this->Barcode->getSafeText()));

		if ($barcode == '')
			$barcode = null;

		$this->_patron->setBarcode($barcode);

		$this->_patron->setRfidCode($this->Rfidcode->getSafeText());
		$this->_patron->setVoicePin($this->Voicepin->getSafeText());

		$this->_patron->setOpacEnable($this->ActiveOpac->getChecked());
		$this->_patron->setSurfEnable($this->ActiveSurf->getChecked());
		$this->_patron->setVoiceEnable($this->ActiveVoice->Checked);

		$this->_patron->setPrivacyApprove($this->PrivacyApprove->getChecked());

		$this->_patron->setNationalId($this->NationalCode->getSafeText());
		$this->_patron->setPatronNote($this->PatronNote->getSafeText());

		$this->_patron->setCardCode($this->CardCode->getSafeText());
		$this->_patron->setCardExpire($this->CardExpire->getDate());

		$this->_patron->setPreferredLibraryId($this->FavLibrary->getSelectedValue());

		//TODO: controllo se new, nel caso prendo la current library del clavislibrarian e memorizzo
		if ($this->_patron->isNew())
			$this->_patron->setRegistrationLibraryId($this->getUser()->getActualLibraryId());

		$this->_patron->setLoanClass($this->PatronClass->getSelectedValue());

		$this->_patron->setAccessNote($this->AccessNote->getSafeText());
		$this->_patron->setAccessAlert($this->AccessAlert->getSelectedValue());

		$maxLoans = trim($this->MaxLoans->getSafeText());
		
		if (!is_null($maxLoans)) 
		{
			$maxLoans = intval($maxLoans);

			if ($maxLoans < 1)
				$maxLoans = null;
		}
		
		$this->_patron->setMaxLoans($maxLoans);

		$this->_patron->setBiography($this->Biography->getSafeText());
		$this->_patron->setStatisticStudy($this->StudyLevel->getSelectedValue());
		$this->_patron->setStatisticWork($this->Work->getSelectedValue());

		$this->_patron->setCustom1($this->Custom1->getSafeText());
		$this->_patron->setCustom2($this->Custom2->getSafeText());
		$this->_patron->setCustom3($this->Custom3->getSafeText());

		if ($this->customs_type[0] == 'list')
			$this->_patron->setCustom1($this->CustomList1->getSelectedValue());

		if ($this->customs_type[1] == 'list')
			$this->_patron->setCustom2($this->CustomList2->getSelectedValue());

		if ($this->customs_type[2] == 'list')
			$this->_patron->setCustom3($this->CustomList3->getSelectedValue());

		try 
		{
			if ($nickname = trim($this->Nickname->getSafeText()))
				$this->_patron->setOpacUsername($nickname);

			if ($password = trim($this->Password->getSafeText())) 
			{
				$cryptmod = $this->getApplication()->getModule('crypt');
				$this->_patron->setOpacSecret($cryptmod->PatronEncrypt($password));
			}

			/** we don't want the capability to modify the password expiration (CNG-957)
			 * $expDate = $this->ExpirePassword->getSafeText();
			 * $d = DateTime::createFromFormat('Y-m-d', $expDate);
			 * if (($d != false)
			 * && ($d->format('Y-m-d') === $expDate))
			 * $this->_patron->setOpacSecretExpire($expDate);
			 */

			$this->setPatron($this->_patron);
			$this->_patron->save();

			$this->enqueueMessage(Prado::localize("Salvato utente {name} con id = {id}",
													array(	'name' => $this->_patron->getCompleteName(),
															'id' => $this->_patron->getPatronId() )),
									ClavisMessage::CONFIRM);

			if (($this->getIsNew()
				&& (!$this->getAddAddress())))   // la seconda condizione e' da pensarci se serva........
			{
				ChangelogPeer::logAction($this->_patron,
											ChangelogPeer::LOG_CREATE,
											$this->getUser(),
											"aggiunto utente ({$this->_patron->getCompleteName()})");

				$this->saveNewAddress();
				$this->saveNewContact();

			} 
			else 
			{
				ChangelogPeer::logAction($this->_patron,
											ChangelogPeer::LOG_UPDATE,
											$this->getUser(),
											"modificato utente ({$this->_patron->getCompleteName()})");
			}

			$this->AttachmentManager->setObjectClass('Patron');
			$this->AttachmentManager->setObjectId($this->_patron->getPatronId());
		} 
		catch (PropelException $exception) 
		{
			$errorMessage = $exception->getCause()->getMessage();
			$dbClass = Propel::getDB();

			if ($dbClass instanceof DBMySQL
					&& ($duplicateCase = strstr($errorMessage, 'Duplicate entry')) != false) 
			{
				$this->enqueueMessage(Prado::localize("Il barcode utente '{barcode}' è già stato assegnato.",
															array('barcode' => $barcode)),
										ClavisMessage::ERROR);

				$this->MainTab->setActiveViewID('AccessTab');

				return false;
			} 
			else 
			{
				throw $exception;
			}
		} catch (Exception $e) 
		{
			if ($e->getCode() == LibrarianPeer::EXCP_USERNAME_DUP) 
			{
				$this->enqueueMessage(Prado::localize("Il nome utente '{username}' è già stato assegnato ad un utente o ad un bibliotecario.",
					array('username' => $nickname)),
					ClavisMessage::ERROR);

				$this->MainTab->setActiveViewID('AccessTab');

				return false;
			} 
			else 
			{
				throw $e;
			}
		}

		$this->flushMessage();
	}

	public function onSave($sender, $param)
	{
		if ($this->getIsValid()) 
		{
			$this->patronSave();
		
			$this->writeMessage(Prado::localize('Modificato patron con id: {id}',
													array('id' => $this->getPatron()->getPatronId())),
									ClavisMessage::INFO);
			
			if ($this->getAddAddress()
				|| $this->getAddContact())
			{
				return true;
			}
			else
			{
				$this->gotoViewPage($this->_patron->getPatronId());
			}
		} 
		else 
		{
			$this->writeMessage(Prado::localize('Errore nel salvataggio. Cercare messaggi di errore sulla pagina.'),
									ClavisMessage::ERROR);
		}
	}

	public function saveAndEdit($sender, $param)
	{
		if ($this->getIsValid()) 
		{
			$wasNew = $this->_patron->isNew();
			$this->patronSave();

			if ($wasNew) 
			{
				$this->gotoPage($this->getPagePath(),
									array('id' => $this->_patron->getPatronId()));
			} 
			else 
			{
				$this->PatronSummary->populate($this->getPatron()->getPatronId());
			}

			$this->populateForm();
		} 
		else 
		{
			$this->writeMessage(Prado::localize('Errore nel salvataggio. Cercare messaggi di errore sulla pagina.'),
									ClavisMessage::ERROR);
		}
	}

	/**
	 * Exits the editing of an item, without doing anything.
	 * @param TControl        $sender
	 * @param TEventParameter $param
	 */
	public function onCancel($sender, $param)
	{
		$this->gotoViewPage();
	}

	public function gotoViewPage($patronId = null)
	{
		if (is_null($patronId))
		{
			$patron = $this->getPatron();
		}
		else
		{
			$patron = PatronQuery::create()->findPk($patronId);
		}
		
		if ($patron instanceof Patron)
			$this->gotoPage('Circulation.PatronViewPage',
								array('id' => $patron->getPatronId()));
	}

	public function populateForm()
	{
		if (!($this->_patron instanceof Patron))
		{
			$this->getPage()->writeMessage(Prado::localize('Errore interno nel passaggio di parametri alla visualizzazione dati utente. Riportare al fornitore del software.'),
											ClavisMessage::ERROR);

			return;
		}

		if (LookupValuePeer::classExists('PATRONCUST1'))
			$this->customs_type[0] = 'list';

		if (LookupValuePeer::classExists('PATRONCUST2'))
			$this->customs_type[1] = 'list';

		if (LookupValuePeer::classExists('PATRONCUST3'))
			$this->customs_type[2] = 'list';

		$this->UpdateData->setObject($this->_patron);
		$this->Photo->setPopupPage($this->getPhotoPopupUrl());

		$this->Title->setSelectedValue($this->_patron->getTitle());
		$this->Lastname->setText($this->_patron->getLastname());
		$this->Firstname->setText($this->_patron->getName());


		if (($gender = $this->_patron->getGender()) != null)
			$this->Sex->setSelectedValue($gender);

		$this->CivilState->setSelectedValue($this->_patron->getCivilStatus());

		if ($bd = $this->_patron->getBirthDate('U'))
			$this->BirthDate->setTimeStamp($bd);

		$this->BirthCity->setText($this->_patron->getBirthCity());
		$this->BirthProvince->setText($this->_patron->getBirthProvince());
		$this->BirthCountry->setText($this->_patron->getBirthCountry());
		$this->Citizenship->setText($this->_patron->getCitizenship());

		$this->Barcode->setText($this->_patron->getBarcode());
		$this->Rfidcode->setText($this->_patron->getRfidCode());
		$this->Voicepin->setText($this->_patron->getVoicePin());

		$this->ActiveOpac->setChecked($this->_patron->getOpacEnable() ? true : false);
		$this->ActiveSurf->setChecked($this->_patron->getSurfEnable() ? true : false);
		$this->ActiveVoice->setChecked($this->_patron->getVoiceEnable() ? true : false);

		$this->PrivacyApprove->setChecked($this->_patron->getPrivacyApprove());
		$this->DocExpireDate->setTimeStamp($this->_patron->getDocumentExpiry('U'));
		$this->DocType->setSelectedValue($this->_patron->getDocumentType());
		$this->DocNumber->setText($this->_patron->getDocumentNumber());
		$this->DocReleasedBy->setText($this->_patron->getDocumentEmitter());
		$this->NationalCode->setText($this->_patron->getNationalId());
		$this->PatronNote->setText($this->_patron->getPatronNote());
		$this->PatronState->setSelectedValue($this->_patron->getPatronStatus());
		$this->CardCode->setText($this->_patron->getCardCode());
		$this->CardExpire->setTimeStamp($this->_patron->getCardExpire('U'));

		if (!$this->getIsNew()) 
		{
			//edit
			$reg_library = $this->_patron->getRegistrationLibrary();

			if ($reg_library != null)
				$this->RegLibrary->setText($reg_library->getDescription());

			$this->ActiveOpac->setChecked($this->_patron->getOpacEnable() ? true : false);
			$this->FavLibrary->setSelectedValue($this->_patron->getPreferredLibraryId());
		} 
		else 
		{
			//new
			/* @var $reg_library Library */
			$reg_library = $this->getApplication()->getUser()->getActualLibrary();

			if ($reg_library != null) 
			{
				$this->RegLibrary->setText($reg_library->getDescription());
				$this->FavLibrary->setSelectedValue($reg_library->getLibraryId());
			}

			$this->ActiveOpac->setChecked(true);
		}

		$this->PatronClass->setSelectedValue($this->_patron->getLoanClass());
		$this->AccessNote->setText($this->_patron->getAccessNote());
		$this->AccessAlert->setSelectedValue($this->_patron->getAccessAlert());
		$this->MaxLoans->setText($this->_patron->getMaxLoans());
		$this->Biography->setText($this->_patron->getBiography());
		$this->StudyLevel->setSelectedValue($this->_patron->getStatisticStudy());
		$this->Work->setSelectedValue($this->_patron->getStatisticWork());

		$this->Custom1->setText($this->_patron->getCustom1());
		$this->Custom2->setText($this->_patron->getCustom2());
		$this->Custom3->setText($this->_patron->getCustom3());

		if ($this->customs_type[0] == 'list')
			$this->CustomList1->setSelectedValue($this->_patron->getCustom1());

		if ($this->customs_type[1] == 'list')
			$this->CustomList2->setSelectedValue($this->_patron->getCustom2());

		if ($this->customs_type[2] == 'list')
			$this->CustomList3->setSelectedValue($this->_patron->getCustom3());

		$this->Nickname->setText($this->_patron->getOpacUsername());
		$this->ExpirePassword->setValue($this->_patron->getOpacSecretExpire('U'));

		if (($librarian = $this->_patron->getLibrarian()) instanceof Librarian) 
		{
			$this->WebPassword->setEnabled(false);
			$this->LibrarianAlert->setVisible(true);
			$this->LibrarianLinkAlert->setVisible(true);
			$this->LibrarianLinkAlert->setNavigateUrl($this->getService()->constructUrl('Library.LibrarianViewPage',
															array('id' => $librarian->getLibrarianId())));

			$this->LibrarianLinkAlert->setEnabled(true);
		}

		$this->reloadPatron();

		$addressData = $this->getPatron()->getAddresss();
		$this->AddressList->setDataSource($addressData);
		$this->AddressList->dataBind();

		$contactData = $this->getPatron()->getContacts();
		$this->ContactList->DataSource = $contactData;
		$this->ContactList->dataBind();

		if ($this->_patron->isNew()) 
		{
			$this->PatronPropertyButton->setEnabled(false);
		} 
		else 
		{
			$this->PatronPropertyButton->setEnabled(true);

			$popupPage = "Circulation.PropertyPopup&id=" . $this->_patron->getPatronId() . "&object=patron";
			$this->PatronPropertyButton->setPopupPage($popupPage);
			$this->populateProperties();
		}

		$this->Password->setText('');
		$this->Confirm->setText('');
	}

	public function populateProperties()
	{
		$c = new Criteria();
		$c->add(PatronPropertyPeer::PATRON_ID, $this->getPatron()->getPatronId());
		$c->addAscendingOrderByColumn(PatronPropertyPeer::PROPERTY_CLASS);

		$properties = PatronPropertyPeer::doSelect($c);
		$arr = array();

		/* @var $property PatronProperty */
		foreach ($properties as $property) 
		{
			$p = array();
			$p['PropertyLabel'] = LookupValuePeer::getLookupValue("PATRONPROPERTY", $property->getPropertyClass());
			$p['PropertyValue'] = $property->getPropertyValue();
			$p['id'] = $property->getId();

			$arr[] = $p;
		}

		$this->PropertyGrid->setDataSource($arr);
		$this->PropertyGrid->dataBind();
	}

	public function addressRepeaterDataBound($sender, $param)
	{
		$item = $param->Item;

		if ($item->ItemType == "EditItem") 
		{
			$item->AddressType->populateList();
			$item->AddressType->SetSelectedValue($item->DataItem->getAddressType());

			$item->AddrStreetType->populateList();
			$item->AddrStreetType->SetSelectedValue($item->DataItem->getStreetType());
		}
	}

	public function addAddress($sender, $param)
	{
		$this->SaveButton->setEnabled(false);
		$this->Apply->setEnabled(false);
		$this->globalEditCancel();
		$this->setAddAddress(true);

		if ($this->getPatron()->isNew()) 
		{
			if (!$this->patronSave()) 
			{
				$this->SaveButton->setEnabled(true);
				$this->Apply->setEnabled(true);

				return;
			}
		}

		$address = new Address();
		$address->setPatron($this->getPatron());
		$address->save();
		$this->getPatron()->addAddress($address);
		$this->getPatron()->reload(true);  // deep reload

		ChangelogPeer::logAction($this->getPatron(),
									ChangelogPeer::LOG_UPDATE,
									$this->getUser(),
									"aggiunto indirizzo (id: {$address->getAddressId()}) - totale indirizzi: " . count($this->AddressList->getItems()));

		$this->refreshRepeaters();
		$this->AddressList->EditItemIndex = count($this->AddressList->getItems()) - 1;
		$this->AddressList->dataBind();
		$this->setIsEditAddress(true);

		$this->getPage()->setFocus("anchor_address");
	}

	public function cancelAddress($sender, $param)
	{
		if ($this->getAddAddress()) 
		{
			$item = $param->Item;
			$itemIndex = $param->Item->ItemIndex;

			$addresses = $this->getPatron()->getAddresss();
			$addresses[$itemIndex]->delete();

			$this->getPatron()->reload(true);  // deep reload
		}

		$this->AddressList->SelectedItemIndex = -1;
		$this->AddressList->EditItemIndex = -1;
		$this->refreshRepeaters();

		$this->SaveButton->setEnabled(true);
		$this->Apply->setEnabled(true);
		$this->setAddAddress(false);

		$this->getPage()->setFocus("anchor_address");
		$this->setIsEditAddress(false);
	}

	public function editAddress($sender, $param)
	{
		$this->globalEditCancel();

		$this->AddressList->SelectedItemIndex = -1;
		$this->AddressList->EditItemIndex = $param->Item->ItemIndex;
		$this->refreshRepeaters();

		$this->SaveButton->setEnabled(false);
		$this->Apply->setEnabled(false);
		$this->setIsEditAddress(true);
	}

	public function updateAddress($sender, $param)
	{
		$item = $param->Item;
		$itemIndex = $param->Item->ItemIndex;
		$addresses = $this->getPatron()->getAddresss();

		if (!$this->doUpdateAddress($item, $itemIndex, $addresses))
			return false;

		ChangelogPeer::logAction($this->getPatron(),
									ChangelogPeer::LOG_UPDATE,
									$this->getUser(),
									"aggiornato indirizzo (id: {$addresses[$itemIndex]->getAddressId()})");

		$this->AddressList->SelectedItemIndex = -1;
		$this->AddressList->EditItemIndex = -1;
		$this->refreshRepeaters();
		$this->SaveButton->setEnabled(true);
		$this->Apply->setEnabled(true);
		$this->setAddAddress(false);

		$this->getPage()->setFocus("anchor_address");
		$this->setIsEditAddress(false);
	}

	public function saveNewAddress()
	{
		$items = $this->AddressList->getItems();
		$item = $items->itemAt(0);
		$patron = $this->getPatron();

		if (is_null($patron)
			|| !($patron instanceof Patron)) 
		{
			$this->writeMessage(Prado::localize("Errore nell'inserimento di un nuovo indirizzo"),
									ClavisMessage::ERROR);

			return false;
		}

		$addrStreet = trim($item->AddrStreet->getSafeText());

		if ($addrStreet != '') 
		{
			$address = new Address();
			$address->setStreetType($item->AddrStreetType->getSelectedValue());
			$address->setStreet($addrStreet);
			$address->setAddressType($item->AddressType->getSelectedValue());
			$address->setStreetNum($item->AddrStreetNumber->getSafeText());
			$address->setVillage($item->AddrVillage->getSafeText());

			$addrCountry = trim($item->AddrCountry->getSafeText());
			$defaultCountry = ClavisParamQuery::getParam("CLAVISPARAM", "DefaultAddressCountry");
			$isDefaultCountry = ($addrCountry == $defaultCountry);
			$addrCity = trim($item->AddrCity->getSafeText());

			if ($addrCity == '') 
			{
				$addrCity = null;
			} 
			else 
			{
				if (!LookupValueQuery::cityExists($addrCity) && $isDefaultCountry) 
				{
					$this->writeMessage(Prado::localize("Comune non valido"),
											ClavisMessage::ERROR);

					return false;
				}

//				if( ! LookupValueQuery::checkAddressDep( $addrProvince, $addrCity) && $isDefaultCountry )
//				{
//					$this->writeMessage(Prado::localize("comune o provincia non coerenti"), ClavisMessage::ERROR);
//					return FALSE;
//				}
			}

			$address->setCity($addrCity);
			$addrProvince = trim($item->AddrProvince->getSafeText());

			if ($addrProvince == '')
			{
				$addrProvince = null;
			} 
			else
			{
				if (!LookupValueQuery::provinceExists($addrProvince) && $isDefaultCountry)
				{
					$this->writeMessage(Prado::localize("Provincia non valida"),
						ClavisMessage::ERROR);

					return false;
				}
			}

			$address->setProvince($addrProvince);

			if (!is_null($addrCity)
				&& !is_null($addrProvince))
			{
				if (!LookupValueQuery::checkAddressDep($addrProvince, $addrCity)
					&& $isDefaultCountry)
				{
					$this->writeMessage(Prado::localize("comune o provincia non coerenti"),
						ClavisMessage::ERROR);

					return false;
				}
			}

			if ($addrCountry == '')
			{
				$addrCountry = null;
			} 
			else
			{
				if (!LookupValueQuery::countryExists($addrCountry))
				{
					$this->writeMessage(Prado::localize("Nazione non valida"),
						ClavisMessage::ERROR);

					return false;
				}
			}

			$address->setCountry($addrCountry);
			$addrZip = trim($item->AddrZip->getSafeText());

			if ($addrZip == '') {
				$addrZip = null;
			} else {
				if (!LookupValueQuery::zipExists($addrZip)
					&& $isDefaultCountry) {
					$this->writeMessage(Prado::localize("CAP non valido"),
						ClavisMessage::ERROR);

					return false;
				}

				if (!LookupValueQuery::checkAddressDep($addrProvince, $addrCity, $addrZip)
					&& $isDefaultCountry) {
					$this->writeMessage(Prado::localize("CAP, comune o provincia non coerenti"),
						ClavisMessage::ERROR);

					return false;
				}
			}

			$address->setZip($addrZip);
			$address->setAddressNote($item->AddrNote->getSafeText());
			$address->setAddressPref($item->AddrPref->getChecked());
			$address->setPatronId($patron->getPatronId());
			$address->save();

			ChangelogPeer::logAction($this->getPatron(),
				ChangelogPeer::LOG_CREATE,
				$this->getUser(),
				"aggiunto indirizzo (id: {$address->getAddressId()})");
		}
	}

	private function doUpdateAddress($item, $itemIndex, $addresses)
	{
		$addresses[$itemIndex]->setStreetType($item->AddrStreetType->getSelectedValue());
		$addresses[$itemIndex]->setStreet($item->AddrStreet->getSafeText());
		$addresses[$itemIndex]->setAddressType($item->AddressType->getSelectedValue());
		$addresses[$itemIndex]->setStreetNum($item->AddrStreetNumber->getSafeText());
		$addresses[$itemIndex]->setVillage($item->AddrVillage->getSafeText());

		$addrCity = $item->AddrCity->getSafeText();
		$addrCountry = $item->AddrCountry->getSafeText();
		$addrProvince = $item->AddrProvince->getSafeText();
		$defaultCountry = ClavisParamQuery::getParam("CLAVISPARAM", "DefaultAddressCountry");
		$isDefaultCountry = ($addrCountry == $defaultCountry);

		if ($addrCity == '')
		{
			$addrCity = null;
		} 
		else
		{
			if (!LookupValueQuery::cityExists($addrCity)
				&& $isDefaultCountry) {
				$this->writeMessage(Prado::localize("Comune non valido"),
					ClavisMessage::ERROR);

				return false;
			}

			if (($addrProvince != "")
				&& !LookupValueQuery::checkAddressDep($addrProvince, $addrCity)
				&& $isDefaultCountry) {
				$this->writeMessage(Prado::localize(" comune o provincia non coerenti"),
					ClavisMessage::ERROR);

				return false;
			}
		}

		$addresses[$itemIndex]->setCity($addrCity);

		if ($addrProvince == '')
		{
			$addrProvince = null;
		} 
		else
		{
			if (!LookupValueQuery::provinceExists($addrProvince)
				&& $isDefaultCountry) {
				$this->writeMessage(Prado::localize("Provincia non valida"),
					ClavisMessage::ERROR);

				return false;
			}
		}

		$addresses[$itemIndex]->setProvince($addrProvince);

		if ($addrCountry == '')
		{
			$addrCountry = null;
		} 
		else 
		{
			if (!LookupValueQuery::countryExists($addrCountry))
			{
				$this->writeMessage(Prado::localize("Nazione non valida"),
					ClavisMessage::ERROR);

				return false;
			}
		}

		$addresses[$itemIndex]->setCountry($addrCountry);
		$addrZip = $item->AddrZip->getSafeText();
		$addrZip = trim($item->AddrZip->getSafeText());

		if ($addrZip == '')
		{
			$addrZip = null;
		} 
		else
		{
			if (!LookupValueQuery::zipExists($addrZip)
				&& $isDefaultCountry) 
			{
				$this->writeMessage(Prado::localize("CAP non valido"),
					ClavisMessage::ERROR);

				return false;
			}

			if (($addrProvince != "")
				&& ($addrCity != "")
				&& !LookupValueQuery::checkAddressDep($addrProvince, $addrCity, $addrZip)
				&& $isDefaultCountry)
			{
				$this->writeMessage(Prado::localize("CAP, comune o provincia non coerenti"),
					ClavisMessage::ERROR);

				return false;
			}
		}

		$addresses[$itemIndex]->setZip($addrZip);
		$addresses[$itemIndex]->setAddressNote($item->AddrNote->getSafeText());

		if ($item->AddrPref->getChecked())
		{
			for ($i = 0; $i < count($addresses); $i++)
			{
				$addresses[$i]->setAddressPref(false);
				$addresses[$i]->save();
			}

			$addresses[$itemIndex]->setAddressPref(true);
		}
		else 
		{
			$addresses[$itemIndex]->setAddressPref(false);
		}

		$addresses[$itemIndex]->save();

		return true;
	}

	public function deleteAddress($sender, $param)
	{
		$dataSource = $this->getPatron()->getAddresss();
		$addressId = $param->getCommandParameter();
		$newDataSource = array();

		foreach ($dataSource as $address) 
		{
			if ($address->getAddressId() != $addressId) 
			{
				$newDataSource[] = $address;
			} 
			else 
			{
				if (!$address->isDeleted())
					$address->delete();

				ChangelogPeer::logAction($this->getPatron(),
					ChangelogPeer::LOG_UPDATE,
					$this->getUser(),
					"rimosso indirizzo (id: {$addressId}) - totale indirizzi: "
					. count($this->AddressList->getItems()));
			}
		}

		$this->getPatron()->reload(true);  // deep reload
		$id = intval($this->getRequest()->itemAt('id'));

		if ($id > 0) 
		{
			$patron = PatronQuery::create()->findPk($id);

			if ($patron instanceof Patron)
				$this->setPatron($patron);
		}

		$this->AddressList->SelectedItemIndex = -1;
		$this->AddressList->EditItemIndex = -1;

		$this->refreshRepeaters();
		$this->setAddAddress(false);

		$this->getPage()->setFocus("anchor_address");
		$this->setIsEditAddress(false);
	}

	public function addContact($sender, $param)
	{
		$this->SaveButton->setEnabled(false);
		$this->Apply->setEnabled(false);
		$this->globalEditCancel();
		$this->setAddContact(true);

		if ($this->getPatron()->isNew()) 
		{
			if (!$this->patronSave()) 
			{
				$this->SaveButton->setEnabled(true);
				$this->Apply->setEnabled(true);

				return;
			}
		}

		$contact = new Contact();
		$contact->setPatron($this->getPatron());
		$contact->save();

		$this->getPatron()->addContact($contact);
		$this->reloadPatron();

		ChangelogPeer::logAction($this->getPatron(),
									ChangelogPeer::LOG_UPDATE,
									$this->getUser(),
									"aggiunto contatto (id: {$contact->getContactId()}) - totale contatti: "
									. count($this->ContactList->getItems()));

		$this->refreshRepeaters();

		$this->ContactList->EditItemIndex = count($this->ContactList->getItems()) - 1;
		$this->ContactList->dataBind();

		$this->setIsEditContact(true);
		$this->getPage()->setFocus("anchor_contact");
	}

	public function editContact($sender, $param)
	{
		$this->globalEditCancel();

		$this->ContactList->SelectedItemIndex = -1;
		$this->ContactList->EditItemIndex = $param->Item->ItemIndex;
		$this->refreshRepeaters();

		$this->SaveButton->setEnabled(false);
		$this->Apply->setEnabled(false);

		$this->setIsEditContact(true);
		$this->getPage()->setFocus("anchor_contact");
	}

	public function deleteContact($sender, $param)
	{
		$dataSource = $this->getPatron()->getContacts();
		$contactId = $param->getCommandParameter();

		$newDataSource = array();
		foreach ($dataSource as $contact)
		{
			if ($contact->getContactId() != $contactId)
			{
				$newDataSource[] = $contact;
			} 
			else 
			{
				ChangelogPeer::logAction($this->getPatron(),
											ChangelogPeer::LOG_DELETE,
											$this->getUser(),
											"rimosso contatto (id: {$contact->getContactId()}) - totale contatti: "
											. count($this->ContactList->getItems()));

				$contact->delete();
			}
		}

		$this->getPatron()->reload(true);  // deep reload

		$id = intval($this->getRequest()->itemAt('id'));

		if ($id > 0) 
		{
			$patron = PatronQuery::create()->findPk($id);

			if ($patron instanceof Patron)
				$this->setPatron($patron);
		}

		$this->ContactList->SelectedItemIndex = -1;
		$this->ContactList->EditItemIndex = -1;
		$this->refreshRepeaters();
		$this->setAddContact(false);

		$this->setIsEditContact(false);
		$this->getPage()->setFocus("anchor_contact");
	}

	public function cancelContact($sender, $param)
	{
		if ($this->getAddContact()) 
		{
			$item = $param->Item;
			$itemIndex = $param->Item->ItemIndex;

			$contacts = $this->getPatron()->getContacts();
			$contacts[$itemIndex]->delete();

			$this->getPatron()->reload(true);  // deep reload
		}

		$this->ContactList->SelectedItemIndex = -1;
		$this->ContactList->EditItemIndex = -1;
		$this->refreshRepeaters();
		$this->SaveButton->setEnabled(true);
		$this->Apply->setEnabled(true);
		$this->setAddContact(false);

		$this->setIsEditContact(false);
		$this->getPage()->setFocus("anchor_contact");
	}

	public function contactRepeaterDataBound($sender, $param)
	{
		$item = $param->Item;

		if ($item->ItemType == "EditItem") 
		{
			$item->ContactType->populateList();
			$item->ContactType->SetSelectedValue($item->DataItem->getContactType());
		}
	}

	public function updateContact($sender, $param)
	{
		$item = $param->Item;
		$itemIndex = $param->Item->ItemIndex;
		$contacts = $this->getPatron()->getContacts();

		$this->doUpdateContact($item, $itemIndex, $contacts);

		ChangelogPeer::logAction($this->getPatron(),
			ChangelogPeer::LOG_UPDATE,
			$this->getUser(),
			"aggiornato contatto (id: {$contacts[$itemIndex]->getContactId()})");

		$this->ContactList->SelectedItemIndex = -1;
		$this->ContactList->EditItemIndex = -1;
		$this->refreshRepeaters();

		$this->SaveButton->setEnabled(true);
		$this->Apply->setEnabled(true);
		$this->setAddContact(false);

		$this->setIsEditContact(false);
		$this->getPage()->setFocus("anchor_contact");
	}

	public function saveNewContact()
	{
		$items = $this->ContactList->getItems();
		$item = $items->itemAt(0);
		$patron = $this->getPatron();

		if (is_null($patron) || !($patron instanceof Patron))
			return false;

		$contactValue = trim($item->ContactValue->getSafeText());

		if ($contactValue != '')
		{
			$contact = new Contact();
			$contact->setContactType($item->ContactType->getSelectedValue());
			$contact->setContactValue($contactValue);
			$contact->setContactNote($item->EditContactNote->getSafeText());
			$contact->setContactPref($item->ContactPref->getChecked());

			$contact->setPatronId($patron->getPatronId());
			$contact->save();

			ChangelogPeer::logAction($this->getPatron(),
				ChangelogPeer::LOG_CREATE,
				$this->getUser(),
				"aggiunto contatto (id: {$contact->getContactId()})");

			$this->setIsEditContact(false);
			$this->getPage()->setFocus("anchor_contact");
		}
	}

	private function doUpdateContact($item, $itemIndex, $contacts)
	{
		$contacts[$itemIndex]->setContactType($item->ContactType->getSelectedValue());
		$contacts[$itemIndex]->setContactValue($item->ContactValue->getSafeText());
		$contacts[$itemIndex]->setContactNote($item->EditContactNote->getSafeText());

		if ($item->ContactPref->getChecked())
		{
			for ($i = 0; $i < count($contacts); $i++) 
			{
				$contacts[$i]->setContactPref(false);
				$contacts[$i]->save();
			}

			$contacts[$itemIndex]->setContactPref(true);
		} 
		else 
		{
			$contacts[$itemIndex]->setContactPref(false);
		}

		$contacts[$itemIndex]->save();
	}

	private function refreshRepeaters()
	{
		$this->ContactList->setDataSource($this->getPatron()->getContacts());
		$this->ContactList->dataBind();
		$this->AddressList->setDataSource($this->getPatron()->getAddresss());
		$this->AddressList->dataBind();
	}

	private function setAddressSuggestion($ds = array())
	{
		$this->getApplication()->getSession()->add('PatronBirthCityDataSource', $ds, array());
	}

	private function getAddressSuggestion()
	{
		return $this->getApplication()->getSession()->itemAt('PatronBirthCityDataSource', array());
	}

	private function setPatronCitizenshipSuggestions($ds = array())
	{
		$this->getApplication()->getSession()->add('PatronCitizenshipDataSource', $ds, array());
	}

	private function getPatronCitizenshipSuggestions()
	{
		return $this->getApplication()->getSession()->itemAt('PatronCitizenshipDataSource', array());
	}

	public function suggestBirthCity($sender, $param)
	{
		$token = $param->getCallbackParameter();
		$ds = PatronPeer::doSuggestAddress($token, PatronPeer::BIRTH_CITY);

		if (count($ds) > 0) 
		{
			$sender->setDataSource($ds);
			$sender->dataBind();
			$this->setAddressSuggestion($ds);
		}
	}

	public function selectBirthCity($sender, $param)
	{
		$index = $param->selectedIndex;
		$sender->setText('');
		$ds = $this->getAddressSuggestion();
		$this->setAddressSuggestion(array());

		if (array_key_exists($index, $ds)) 
		{
			$row = $ds[$index];
			$array = $row['array'];
			$city = trim($array[0]);
			$province = trim($array[1]);
			$country = trim($array[2]);

			if ($city != '')
				$this->BirthCity->setText($city);

			if ($province != '')
				$this->BirthProvince->setText($province);

			if ($country != '')
				$this->BirthCountry->setText($country);
		}
	}

	public function suggestBirthProvince($sender, $param)
	{
		$token = $param->getCallbackParameter();
		$ds = PatronPeer::doSuggestAddress($token, PatronPeer::BIRTH_PROVINCE);

		if (count($ds) > 0) 
		{
			$sender->setDataSource($ds);
			$sender->dataBind();
			$this->setAddressSuggestion($ds);
		}
	}

	public function selectBirthProvince($sender, $param)
	{
		$index = $param->selectedIndex;
		$sender->setText('');
		$ds = $this->getAddressSuggestion();
		$this->setAddressSuggestion(array());

		if (array_key_exists($index, $ds)) 
		{
			$row = $ds[$index];

			$array = $row['array'];
			$province = trim($array[0]);
			$country = trim($array[1]);

			if ($province != '')
				$this->BirthProvince->setText($province);

			if ($country != '')
				$this->BirthCountry->setText($country);
		}
	}

	public function suggestBirthCountry($sender, $param)
	{
		$token = $param->getCallbackParameter();
		$ds = LookupValueQuery::getSuggestCountry($token);

		if (count($ds) > 0) 
		{
			$sender->setDataSource($ds);
			$sender->dataBind();
			$this->setAddressSuggestion($ds);
		}
	}

	public function selectBirthCountry($sender, $param)
	{
		$index = $param->selectedIndex;
		$sender->setText('');

		$ds = $this->getAddressSuggestion();
		$this->setAddressSuggestion(array());


		if (array_key_exists($index, $ds)) 
		{
			$row = $ds[$index];
			$this->BirthCountry->setText($row['text']);
		}
	}

	public function suggestCitizenship($sender, $param)
	{
		$token = $param->getCallbackParameter();
		$ds = LookupValueQuery::getSuggestCitizenship($token);

		if (count($ds) > 0) 
		{
			$sender->setDataSource($ds);
			$sender->dataBind();
			$this->setPatronCitizenshipSuggestions($ds);
		}
	}

	public function selectCitizenship($sender, $param)
	{
		$index = $param->selectedIndex;
		$sender->setText('');

		$ds = $this->getPatronCitizenshipSuggestions();
		$this->setPatronCitizenshipSuggestions(array());

		if (array_key_exists($index, $ds)) 
		{
			$row = $ds[$index];
			$this->Citizenship->setText($row['text']);
		}
	}

	public function suggestCity($sender, $param)
	{
		$text = $sender->getText();
		$token = $param->getCallbackParameter();
		$ds = LookupValueQuery::getSuggestCity($token);

		if (count($ds) > 0) 
		{
			$sender->setDataSource($ds);
			$sender->dataBind();
			$this->setAddressSuggestion($ds);
			$sender->setText($text);
		}
	}

	public function selectCity($sender, $param)
	{
		$defaultCountry = ClavisParamQuery::getParam("CLAVISPARAM", "DefaultAddressCountry");
		$itemIndex = $sender->Parent->getItemIndex();
		$items = $this->AddressList->getItems();
		$item = $items->itemAt($itemIndex);

		$index = $param->selectedIndex;
		$sender->setText('');

		$ds = $this->getAddressSuggestion();
		$this->setAddressSuggestion(array());

		if (array_key_exists($index, $ds)) 
		{
			$row = $ds[$index];
			$item->AddrCity->setText($row['text']);

			/*$cityKey = LookupValueQuery::getCityProvince($row['id']);
			if($cityKey != '')
			{
				$item->AddrProvince->setText($cityKey);
			}*/

			$item->AddrZip->setText("");
			$item->AddrProvince->setText($row['prov']);
			$item->AddrCountry->setText($defaultCountry);
		}
	}

	public function suggestZip($sender, $param)
	{
		$text = $sender->getText();
		$token = $param->getCallbackParameter();
		//$ds = PatronPeer::doSuggestAddress($token, AddressPeer::ZIP);
		$ds = LookupValueQuery::getSuggestZip($token);

		if (count($ds) > 0) 
		{
			$sender->setDataSource($ds);
			$sender->dataBind();
			$this->setAddressSuggestion($ds);
			$sender->setText($text);
		}
	}

	public function selectZip($sender, $param)
	{
		$defaultCountry = ClavisParamQuery::getParam("CLAVISPARAM", "DefaultAddressCountry");
		$itemIndex = $sender->Parent->getItemIndex();
		$items = $this->AddressList->getItems();
		$item = $items->itemAt($itemIndex);

		$index = $param->selectedIndex;
		$sender->setText('');

		$ds = $this->getAddressSuggestion();
		$this->setAddressSuggestion(array());

		if (array_key_exists($index, $ds)) 
		{
			$row = $ds[$index];
			$item->AddrZip->setText($row['text']);
			$item->AddrCity->setText($row['city']);
			$item->AddrProvince->setText($row['prov']);
			$item->AddrCountry->setText($defaultCountry);

			/*
			$array = $row['array'];

			$zip = trim($array[0]);
			$province = trim($array[1]);
			$country = trim($array[2]);

			if ($zip != '')
				$item->AddrZip->setText($zip);

			if ($province != '')
				$item->AddrProvince->setText($province);

			if ($country != '')
				$item->AddrCountry->setText($country);*/
		}
	}

	public function suggestProvince($sender, $param)
	{
		$text = $sender->getText();
		$token = $param->getCallbackParameter();
		$ds = LookupValueQuery::getSuggestProvince($token);

		if (count($ds) > 0) 
		{
			$sender->setDataSource($ds);
			$sender->dataBind();
			$this->setAddressSuggestion($ds);
			$sender->setText($text);
		}
	}

	public function selectProvince($sender, $param)
	{
		$defaultCountry = ClavisParamQuery::getParam("CLAVISPARAM", "DefaultAddressCountry");
		$itemIndex = $sender->Parent->getItemIndex();
		$items = $this->AddressList->getItems();
		$item = $items->itemAt($itemIndex);

		$index = $param->selectedIndex;
		$sender->setText('');

		$ds = $this->getAddressSuggestion();
		$this->setAddressSuggestion(array());

		if (array_key_exists($index, $ds)) 
		{
			$row = $ds[$index];
			$item->AddrZip->setText("");
			$item->AddrCity->setText("");
			$item->AddrProvince->setText($row['text']);
			$item->AddrCountry->setText($defaultCountry);
		}
	}

	public function suggestCountry($sender, $param)
	{
		$text = $sender->getText();
		$token = $param->getCallbackParameter();
		$ds = LookupValueQuery::getSuggestCountry($token);

		if (count($ds) > 0) 
		{
			$sender->setDataSource($ds);
			$sender->dataBind();
			$this->setAddressSuggestion($ds);
			$sender->setText($text);
		}
	}

	public function selectCountry($sender, $param)
	{
		$itemIndex = $sender->Parent->getItemIndex();
		$items = $this->AddressList->getItems();
		$item = $items->itemAt($itemIndex);

		$index = $param->selectedIndex;
		$sender->setText('');

		$ds = $this->getAddressSuggestion();
		$this->setAddressSuggestion(array());

		if (array_key_exists($index, $ds)) 
		{
			$row = $ds[$index];
			$item->AddrZip->setText("");
			$item->AddrCity->setText("");
			$item->AddrProvince->setText("");
			$item->AddrCountry->setText($row['text']);
		}
	}

	public function suggestDocumentEmitter($sender, $param)
	{
		$token = $param->getCallbackParameter();
		$sql = 'SELECT DISTINCT ' . PatronPeer::DOCUMENT_EMITTER . ' FROM ' . PatronPeer::TABLE_NAME . '
						WHERE ' . PatronPeer::DOCUMENT_EMITTER . ' LIKE \'' . $token . '%\' ORDER BY ' . PatronPeer::DOCUMENT_EMITTER;

		$stmt = Propel::getConnection()->query($sql);
		$ds = $stmt->fetchAll(PDO::FETCH_COLUMN, 0);

		$sender->setDataSource($ds);
		$sender->dataBind();
	}

	public function reloadPatron()
	{
		$patron = $this->getPatron();
		$patron->reload(true);  // deep reload
		$this->setPatron($patron);
	}

	public function setPatron(Patron $patron)
	{
		$this->_patron = $patron;
		$this->setViewState("patron", $patron, null);
	}

	public function getPatron()
	{
		if (is_null($this->_patron))
			$this->_patron = $this->getViewState("patron", null);

		return $this->_patron;
	}

	private function VerifyPassword($password, $confirm)
	{
		if ((is_null($password)) || (is_null($confirm)))
			return false;
		
		if ($password === $confirm) 
		{
			return true;
		} 
		else 
		{
			return false;
		}
	}

	public function changePassword($sender, $param)
	{
		$bChanged = false;
		$password = $this->Password->getSafeText();
		$confirm = $this->Confirm->getSafeText();

		if ($this->_patron != null)
			$this->setPatron($this->_patron);

		$patron = $this->getPatron();

		//manage password...
		if ($password != '') {
			if ($password !== $confirm)
			{
				$this->writeMessage(Prado::localize("La password e la sua verifica non coincidono"),
					ClavisMessage::ERROR);

				$this->refreshRepeaters();

				return;
			}

			if (strlen($password) < 1) 
			{
				$this->writeMessage(Prado::localize("La password è troppo corta"),
					ClavisMessage::ERROR);

				$this->refreshRepeaters();

				return;
			}

			/* load ClavisCrypt module and directly set new password via setOpacSecret */
			$cryptmod = $this->getApplication()->getModule('crypt');
			$patron->setOpacSecret($cryptmod->PatronEncrypt($password));

			$bChanged = true;
		}

		//manage username...
		$userName = $this->Nickname->getSafeText();

		if ($userName != '') 
		{
			if ($patron->getOpacUsername() != $userName) 
			{
				$criteria = new Criteria();

				$criteria->add(PatronPeer::OPAC_USERNAME, $userName);

				if (PatronPeer::doCount($criteria) != 0) 
				{
					$this->writeMessage(Prado::localize("Username OPAC già esistente"),
						ClavisMessage::ERROR);

					$this->Nickname->setText($patron->getOpacUsername());
					$this->refreshRepeaters();

					return;
				}
			}

			$patron->setOpacUsername($userName);
			$bChanged = true;
		}

		if ($bChanged) 
		{
			$patron->save();

			ChangelogPeer::logAction($patron,
				ChangelogPeer::LOG_UPDATE,
				$this->getUser(),
				"cambiati username/password OPAC");

			$this->setPatron($patron);

			$this->writeMessage(Prado::localize("Username e/o password cambiati correttamente"),
				ClavisMessage::INFO);

			$this->gotoPage("Circulation.PatronPage",
							array("id" => $this->_patron->getPatronId()));
		}
	}

	public function globalEditCancel()
	{
		$this->AddressList->SelectedItemIndex = -1;
		$this->AddressList->EditItemIndex = -1;
		$this->AddressList->dataBind();

		$this->ContactList->SelectedItemIndex = -1;
		$this->ContactList->EditItemIndex = -1;
		$this->ContactList->dataBind();
	}

	protected function onChangeImage($sender, $param)
	{

	}

	public function getPhotoPopupUrl()
	{
		$patron_id = -1;
		$this->getPatron();

		if ($this->_patron->isNew()) 
		{
			$this->Photo->Enabled = false;

			return;
		}

		if ($this->_patron != null)
			$patron_id = $this->_patron->getPatronId();

		$popup_url = "Circulation.PatronChooseImagePopup";

		if ($patron_id != -1)
			$popup_url .= "&patronId=" . $patron_id;

		return $popup_url;
	}

	public function onCheckBirthDateExists($sender, $param)
	{
		$param->setIsValid(true);
		$sex = $this->Sex->getSelectedValue();

		// we are in the cases of a female or a male patron
		if (in_array($sex, PatronPeer::getRealSex())) {
			$birthDate = trim($this->BirthDate->getText());

			if ($birthDate == "") 
			{
				$this->getPage()->writeMessage(Prado::localize("Data di nascita non inserita"),
												ClavisMessage::ERROR);

				$param->setIsValid(false);

				return false;
			}

			$dateFormat = $this->BirthDate->getDateFormat();

			if (strlen($dateFormat))
			{
				$formatter = Prado::createComponent('System.Util.TSimpleDateFormatter', $dateFormat);
				$dateValid = $formatter->isValidDate($birthDate);
			} 
			else 
			{
				$dateValid = strtotime($value) > 0;
			}

			if (!$dateValid) 
			{
				$this->getPage()->writeMessage(Prado::localize("Data di nascita in formato non valido"),
					ClavisMessage::ERROR);

				$param->setIsValid(false);
			}
			
			$candidateDate = (int) $this->BirthDate->getTimeStamp();
			$now = getdate()[0];
			
			if ($candidateDate > $now)
			{
				$this->getPage()->writeMessage(Prado::localize("Data di nascita collocata nel futuro"),
												ClavisMessage::ERROR);
				
				$param->setIsValid(false);		// being born in the future is not contemplated
			}
		}
	}

	public function checkBarcodeDuplicate($sender, $param)
	{
		$barcode = trim($this->Barcode->getSafeText());

		if ($barcode == "")
			return;    // now awe have triggers for attributing a new barcode to unfilled fields...

		$c = new Criteria();
		$c->add(PatronPeer::BARCODE, $barcode);

		if (!$this->getIsNew())
			$c->add(PatronPeer::PATRON_ID, $this->_patron->getPatronId(), Criteria::NOT_EQUAL);

		$cnt = PatronPeer::doCount($c);

		if ($cnt > 0) 
		{
			$this->getPage()->writeMessage(Prado::localize("Il codice a barre specificato è già assegnato ad un altro utente."),
				ClavisMessage::ERROR);

			$param->isValid = false;
		}
	}

	public function onCheckLastname($sender, $param)
	{
		$lastname = trim($this->Lastname->getSafeText());

		if ($lastname == '') 
		{
			$this->getPage()->writeMessage(Prado::localize("Il campo COGNOME non può essere vuoto"),
				ClavisMessage::ERROR);

			$param->isValid = false;
		}
	}

	public function onCheckPassword($sender, $param)
	{
		$password = trim($this->Password->getSafeText());
		$confirm = trim($this->Confirm->getSafeText());

		if ($password != '') 
		{
			if ($password !== $confirm) 
			{
				$this->getPage()->writeMessage(Prado::localize("La password e la sua conferma non coincidono"),
					ClavisMessage::ERROR);

				$param->isValid = false;

				return;
			}

			if (strlen($password) < 1) 
			{
				$this->getPage()->writeMessage(Prado::localize("La password è troppo corta"),
					ClavisMessage::ERROR);

				$param->isValid = false;

				return;
			}
		}
	}

	public function onCheckNickname($sender, $param)
	{
		$userName = trim($this->Nickname->getSafeText());

		if ($userName != '') {
			$criteria = new Criteria();
			$criteria->add(PatronPeer::OPAC_USERNAME, $userName);

			if (!$this->getIsNew()
					&& ($this->getPatron() instanceof Patron))
				$criteria->addAnd(PatronPeer::PATRON_ID, $this->getPatron()->getPatronId(), Criteria::NOT_EQUAL);

			if (PatronPeer::doCount($criteria) > 0)
				$param->isValid = false;
		}
	}

	public function onBlipBarcode($sender, $param)
	{
		$this->setFocus($this->Rfidcode->getClientID());
	}

	public function onBlipNationalCode($sender, $param)
	{
		$this->setFocus($this->NationalCode->getClientID());
	}

	public function onBlipNickname($sender, $param)
	{
		$this->setFocus($this->Password->getClientID());
	}

}