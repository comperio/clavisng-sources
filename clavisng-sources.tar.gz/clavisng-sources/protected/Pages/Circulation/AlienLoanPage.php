<?php

/**
 * AlienLoanPage
 *
 * It shows the items which are loaned to or from other consortia.
 * The page will be divided into 2 panels (items out, and items in).
 * 
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2009 ePortal Technologies
 * @version 2.7
 * @package Pages.Circulation
 * @since 2.3
 */

class AlienLoanPage extends ClavisPage
{
	const INV_SEP = " // ";

	public $_module = 'CIRCULATION';
	protected $_loanmanager;
	private $_toLibraryId;
	private $_fromLibraryId;
	
 	public function initVars()
 	{
 		$this->_loanmanager = $this->getApplication()->getModule("loan");
 	}

	public function onInit($param)
	{
		parent::onInit($param);
		$this->initVars();

		$this->_toLibraryId = $this->getToLibraryId();
		$this->_fromLibraryId = $this->getFromLibraryId();
		
		$this->LoanListTo->setAutomaticPopulate(false);
		$this->LoanListIn->setAutomaticPopulate(false);
		$this->ExtraRequestsIn->setAutoPopulate(false);

		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallBack())
			$this->doCleanSearch(null, null);
	}

	/**
	 * It manages the mechanism of setting (resetting/initialization) the
	 * dropdowns which perform as filters for the population of the
	 * loans grid.
	 *
	 * @param TEventParameter $param
	 */
	public function onLoad($param)
	{
		parent::onLoad($param);
		
		// first page cycle
		if (!$this->getIsPostBack() && !$this->getIsCallback())
		{
			$this->ReadyForLoan->setLoanStatusMode(array(ItemPeer::LOANSTATUS_READYFORLOAN));
			$this->ReadyForLoan->setDoubleCounterViewMode(false);
			
			$this->ReadyForLoan->setFilters(null, 
					null, 
					null, 
					null, 
					null, 
					
					null, 
					null, 
					true);   // 8th -> extrasystem
			
			$this->refreshReadyForLoan($param);

			$this->FromLibraryTo->setDataSource(LibraryPeer::getLibrariesHash(	array(LibraryPeer::BLANKVALUE, LibraryPeer::EXCLUDEMYLIBRARY),
																				array('---','<' . Prado::localize('tutte tranne la mia') . '>'),
																				null,
																				true));   // internal libraries

			$this->ToLibraryTo->setDataSource(LibraryPeer::getLibrariesHashWithBlank(	null,
																						false));  // external libraries
			$this->ControlSwitchesTo->dataBind();

			$this->LoanListTo->setFilters($this->_fromLibraryId, $this->_toLibraryId);
			$this->refreshLoanOut($param);
			
			$this->ExtraRequestsIn->cleanFilters();
			$this->refreshExtraRequestsIn();
		}
		
		// not first page cycle
		if ($this->getPage()->getIsPostBack() || $this->getPage()->getIsCallback())
		{
			$updateItemRequests = $this->getApplication()->getSession()->itemAt('UpdateItemRequests');
			if (!is_null($updateItemRequests) && ($updateItemRequests == true))
			{
				$this->getApplication()->getSession()->remove('UpdateItemRequests');
				$this->refreshExtraRequestsIn();
			}
		}
	}

	public function globalRefresh($param = null)
	{
		$this->globalRefreshOut($param);
		$this->globalRefreshIn($param);
	}

 	public function globalRefreshOut($param = null)
 	{
		$fromLibraryId = $this->FromLibraryTo->getSelectedValue();
 		$toLibraryId = $this->ToLibraryTo->getSelectedValue();

		$outDateFrom = ($this->OutDateFrom->getSafeText() != '' 
							? $this->OutDateFrom->getTimeStamp() 
							: null);
		
		$outDateTo = ($this->OutDateTo->getSafeText() != '' 
							? $this->OutDateTo->getTimeStamp() 
							: null);

  		$this->LoanListTo->setFilters($fromLibraryId, $toLibraryId, $outDateFrom, $outDateTo);
		$this->refreshLoanOut($param);
		$this->refreshReadyForLoan($param);
 	}

 	public function globalRefreshIn($param = null)
 	{
		$this->refreshExtraRequestsIn($param);
		$this->refreshLoanIn($param);
		$this->refreshExtraGoHome($param);
	}

	private function refreshLoanOut($param = null)
	{
		$this->LoanListTo->resetDataSource();

		if ($this->getPage()->getIsCallBack())
		{
			if (is_null($param))
			{
				$writer = $this->createWriter();
			}
			else
			{
				$writer = $param->getNewWriter();
			}
			
			$this->LoanListToPanel->render($writer);
		}
	}

	private function refreshLoanIn($param = null)
	{
		$this->LoanListIn->resetDataSource();

		if ($this->getPage()->getIsCallBack())
		{
			if (is_null($param))
				$writer = $this->createWriter();
			else
				$writer = $param->getNewWriter();
			$this->LoanListInPanel->render($writer);
		}
	}

	private function refreshReadyForLoan($param = null)
	{
		$this->ReadyForLoan->resetDataSource();

		if ($this->getIsCallback())
		{
			if (is_null($param))
				$writer = $this->createWriter();
			else
				$writer = $param->getNewWriter();
			$this->ReadyForLoanPanel->render($writer);
		}
	}

	public function refreshExtraRequestsIn($param = null)
	{
		$this->ExtraRequestsIn->populate();
		
		$this->ExtraRequestsInPrintPanel->setStyle('display:' . (count($this->ExtraRequestsIn->getDataSource()) > 0
																	? 'block'
																	: 'none'));
		
		if ($this->getIsCallback())
		{
			if (is_null($param))
			{
				$writer = $this->createWriter();
			}
			else
			{
				$writer = $param->getNewWriter();
			}
			
			$this->ExtraRequestsInPanel->render($writer);
		}
	}

	private function refreshExtraGoHome($param = null)
	{
		$this->ExtraGoHome->resetDataSource();

		if ($this->getIsCallback())
		{
			if (is_null($param))
				$writer = $this->createWriter();
			else
				$writer = $param->getNewWriter();
			$this->ExtraGoHomePanel->render($writer);
		}
	}

 	public function setToLibraryId($lib)
 	{
 		$this->_toLibraryId = $lib;
 		$this->setViewState('toLibraryId', $this->_toLibraryId, null);
 	}

 	public function getToLibraryId()
 	{
 		if (($lib = $this->_toLibraryId) == null)
 		{
 			$lib = $this->getViewState('toLibraryId', null);
 			$this->_toLibraryId = $lib;
 		}
		return $lib;
 	}

 	public function setFromLibraryId($lib)
 	{
 		$this->_fromLibraryId = $lib;
 		$this->setViewState('fromLibraryId', $this->_fromLibraryId, null);
 	}

 	public function getFromLibraryId()
 	{
 		if (($lib = $this->_fromLibraryId) == null)
 		{
 			$lib = $this->getViewState('fromLibraryId', null);
 			$this->_fromLibraryId = $lib;
 		}
		return $lib;
 	}

  	/**
 	 * Does this page have popups inside?.....
 	 *
 	 * @return boolean
 	 */
 	public function isPopup()
 	{
 		return false;
 	}

	public function onResetOutDate($sender, $param)
	{
		$this->OutDateFrom->setText('');
 		$this->OutDateTo->setText('');

 		 if ($this->getIsCallback() && !is_null($param))
 			$this->OutDatePanel->render($param->getNewWriter());
	}

	/**
	 * Callback from update button in the page.
	 * It performs retrieving of filters and next it populates.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onSubmit($sender, $param)
	{
		$this->globalRefresh();
	}

	public function onUnloanOut($sender, $param)
	{
		$checkedItemIds = array();
		$input = $this->ReturnBarcodeTextbox->getSafeText();
		$input = trim($input);
		if ($input != '')
		{
			$this->ReturnBarcodeTextbox->setText('');

			$items = ItemPeer::retrieveByDataInput($input);
			//// skip item doppioni, TODO
			if (count($items) == 1)
				$item = $items[0];
			else
				$item = null;

			if ($item instanceof Item)
			{
				$itemId = $item->getItemId();
				
				if ($this->LoanListTo->searchIdIntoDatasource($itemId))
					$checkedItemIds = array($itemId);
			}
		}
		else
		{
			if ($this->ReturnBarcodeTextbox->getText() === '')
				$checkedItemIds = $this->LoanListTo->getCheckedItems2ItemIds();
		}

		if (count($checkedItemIds) == 0)
		{
			$this->getPage()->writeMessage(Prado::localize('Nessun elemento da processare riconosciuto come valido'), ClavisMessage::ERROR);
			$this->UserFocus->setFocusComponent($this->ReturnBarcodeTextbox);
			return false;
		}

		$updatePageFlag = true;
		$clavisLibrarian = $this->getUser();
		$this->getPage()->cleanMessageQueue();

		foreach ($checkedItemIds as $itemId)
		{
			$returnValue = $this->LoanListTo->doUnLoan($itemId, $clavisLibrarian);
			$updatePageFlag = $updatePageFlag && $returnValue;
		}

		if ($updatePageFlag)
			$this->globalRefreshOut($param);

		$this->flushMessage();
	}
	
	public function onUnloanIn($sender, $param)
	{
		$checkedItemIds = array();
		$input = $this->ReturnBarcodeTextboxIn->getSafeText();
		$input = trim($input);
		if ($input != '')
		{
			$this->ReturnBarcodeTextboxIn->setText('');

			$items = ItemPeer::retrieveByDataInput($input);
			//// skip item doppioni, TODO
			if (count($items) == 1)
				$item = $items[0];
			else
				$item = null;

			if ($item instanceof Item)
			{
				$itemId = $item->getItemId();
				if ($this->LoanListIn->searchIdIntoDatasource($itemId))
					$checkedItemIds = array($itemId);
			}
		}
		else
		{
			if ($this->ReturnBarcodeTextboxIn->getText() === '')
				$checkedItemIds = $this->LoanListIn->getCheckedItems2ItemIds();
		}

		if (count($checkedItemIds) == 0)
		{
			$this->getPage()->writeMessage(Prado::localize('Nessun elemento da processare riconosciuto come valido'), ClavisMessage::ERROR);
			$this->UserFocus->setFocusComponent($this->ReturnBarcodeTextboxIn);
			return false;
		}

		$updatePageFlag = true;
		$clavisLibrarian = $this->getUser();
		$this->getPage()->cleanMessageQueue();

		foreach ($checkedItemIds as $itemId)
		{
			$returnValue = $this->LoanListIn->doUnLoan($itemId, $clavisLibrarian);
			$updatePageFlag = $updatePageFlag && $returnValue;
		}

		if ($updatePageFlag)
			$this->globalRefreshIn($param);

		$this->flushMessage();
	}

	private function doCleanSearch($par1, $par2)
	{
		$this->onCleanSearch($par1, $par2);
	}

	public function onCleanSearch($sender, $param)
	{
		$this->FromLibraryTo->setSelectedIndex(0);
		$this->ToLibraryTo->setSelectedIndex(0);
		$this->onResetOutDate(null, null);

		if (!is_null($sender) && !is_null($param))
			$this->globalRefresh();
	}

	public function onReportJRPInLoanExtraOut($sender, $param)
	{
		$datasource = $this->LoanListTo->getCheckedItems(true, true);    // all + reset
		$ids = implode(',', $datasource);	

		$this->JRPBox2->setObjectId($ids);
		$this->JRPBox2->addOptionalParam('P_ORDER', $this->LoanListTo->getSortingExpression());		
		$this->JRPBox2->addOptionalParam('P_ORDERDIR', $this->LoanListTo->getSortingDirection());
		
		$this->JRPBox2->printReport();
	}

	public function onReportJRPInLoanExtraIn($sender, $param)
	{
		$datasource = $this->LoanListIn->getCheckedItems(true, true);      // all + reset
		
		$ids = implode(',', $datasource);
		if ($ids == "")
		{
			$this->getPage()->writemessage(Prado::localize("Nessun elemento da stampare"), ClavisMessage::ERROR);
			return false;
		}
		
		$this->JRPBox4->setObjectId($ids);
		$this->JRPBox4->addOptionalParam('P_ORDER', $this->LoanListIn->getSortingExpression());		
		$this->JRPBox4->addOptionalParam('P_ORDERDIR', $this->LoanListIn->getSortingDirection());
		
		$this->JRPBox4->printReport();
	}

	public function getCheckedItems($force = false, $reset = false)
	{
		$dataSource = $this->LoanListTo->getCheckedItems($force, $reset);
		if (is_null($dataSource))
			$dataSource = array();
		
		return $dataSource;
	}

	public function countCheckedItems($force = false, $reset = false)
	{
		$count = $this->LoanListTo->countCheckedItems($force, $reset);
		if (is_null($count))
			$count = 0;

		return $count;
	}

	public function loanListInitialReload()
	{
		$this->LoanListTo->initialReload();
	}

	public function drawDuplicateItemBarcodePanel($newState = false, $param = null)
	{
		$currentState = $this->DuplicateItemBarcodePanel->getCssClass() == "panel_on" ? true : false;

		if ($currentState != $newState)
		{
			$newCssClass = $newState ? 'panel_on' : 'panel_off';

			$this->DuplicateItemBarcodePanel->setCssClass($newCssClass);

			if ($this->getPage()->getIsCallback())
			{
				if (is_null($param))
					$writer = $this->getPage()->createWriter();
				else
					$writer = $param->getNewWriter();

				$this->DuplicateItemBarcodePlaceHolder->render($writer);
			}
		}
	}

	private function doLoan($item, $patron, $clavisLibrarian, $deliveryLibrary, $itemRequest, $dueDate, $param = null)
	{
		if (!is_null($deliveryLibrary) && ($deliveryLibrary instanceof Library))
			$deliveryLibraryId = $deliveryLibrary->getLibraryId();
		else
			$deliveryLibraryId = $this->getUser()->getActualLibraryId();

		$exitCode = false;

		$alienString = ($item->getIsAlien()) ? Prado::localize(' (di altra biblioteca)') : '';

		$isItemAvailable = ($this->_loanmanager->IsItemAvailable($item, $deliveryLibraryId, $patron) == ClavisLoanManager::OK);
		$isPatronAllowed = $this->_loanmanager->IsPatronAllowedToLoan($patron, $item->getItemId());

		if ($isPatronAllowed == ClavisLoanManager::LOAN_PATRONNOTENABLED)
		{
			$this->enqueueMessage(Prado::localize("L'esemplare n. {itemid}{alienString}: <em>\"{title}\"</em> non è prestabile a <strong>{patron}</strong> perché l'utente non è abilitato al prestito",
													array(	'alienString' => $alienString,
															'itemid' => $item->getItemId(),
															'title' => $item->getTrimmedTitle(40),
															'patron' => $patron->getCompleteName())),
									ClavisMessage::ERROR);
		}
		elseif ($isPatronAllowed == ClavisLoanManager::LOAN_REACHEDMAX)
		{
			$this->enqueueMessage(Prado::localize("L'esemplare n. {itemid}{alienString}: <em>\"{title}\"</em> non è prestabile a <strong>{patron}</strong> perché è stato raggiunto il massimo numero di prestiti consentiti",
													array(	'alienString' => $alienString,
															'itemid' => $item->getItemId(),
															'title' => $item->getTrimmedTitle(40),	
															'patron' => $patron->getCompleteName())), 
									ClavisMessage::ERROR);
		}

		if (!$isItemAvailable)
		{
			if ($this->getBlipMode())
				$this->blipMode(false);

			$this->enqueueMessage(Prado::localize("L'esemplare n. {itemid}{alienString}: <em>\"{title}\"</em> non è disponibile per <strong>{patron}</strong>",
													array(	'alienString' => $alienString,
															'itemid' => $item->getItemId(),
															'title' => $item->getTrimmedTitle(40),	
															'patron' => $patron->getCompleteName())), 
									ClavisMessage::ERROR);

			$manifestation = $item->getManifestation();
			if ($manifestation instanceof Manifestation)
			{
				if (!$item->checkLoanableSince())
					$this->enqueueMessage(Prado::localize('La notizia è disponibile solo dal {date}',
													array('date' => $manifestation->getLoanableSince('%x'))),
											ClavisMessage::ERROR);

				if (!$this->_loanmanager->IsRatingAllowed($manifestation, $patron))
					$this->enqueueMessage(Prado::localize("La notizia è disponibile solo per gli utenti con piu' di {rating} anni",
															array(	'rating' => $manifestation->getRating())), 
											ClavisMessage::ERROR);
			}
		}

		if (($item instanceof Item) 
				&& ($isPatronAllowed == ClavisLoanManager::OK) 
				&& $isItemAvailable)
		{
			//$oldItemActualLibraryId = $item->getActualLibraryId();
			$item->setActualLibraryId($deliveryLibraryId);

			$resultLoan = $this->_loanmanager->DoLoanItem(	$item, 
															$patron, 
															$clavisLibrarian,	
															$deliveryLibrary, 
															$itemRequest, 
					
															$dueDate);

			switch ($resultLoan) 
			{
				case ClavisLoanManager::LOAN_LOANED:
					$labelText = Prado::localize("Esemplare{alienString} '<em>{title}</em>' [barcode: {barcode}] in prestito a <strong>{patron}</strong>.",
													array(	'alienString' => $alienString,
															'barcode' => $item->getBarcode(),
															'title' => $item->getTrimmedTitle(40),
															'patron' => $patron->getCompleteName()));

					if ('true' == ClavisParamQuery::getParam('CLAVISPARAM','ZebraAutoReceipt'))
					{
						//$this->ClavisClient->printLoanLabel('receipt',$item->getCurrentLoanId());
						RfidUtil::printLoanLabel($this->getPage()->getClientScript(),'receipt',$item->getCurrentLoanId());
					}
					if ($this->getBlipMode()) {
						$this->LastOperationLabel->setText($labelText);
						$this->LastOperationLabel->setCssClass('bordergreen');
						$this->LastOperationPanel->setCssClass('panel_on');
					}
					/// put out message also in blip mode       else
					$this->enqueueMessage($labelText, ClavisMessage::CONFIRM);

					$this->AvailableFound->deleteItemIds($item->getId());
					$this->datasourceUpdate(ItemQuery::create()->findPK($item->getItemId()));

					if (($patronId = $this->CirculationData->getPatronId()) > 0)
						$this->CirculationData->populate($patronId);

					$exitCode = true;
					break;

				case ClavisLoanManager::LOAN_READYTOLOAN:
					$labelText = Prado::localize("Esemplare n.{itemId}{alienString} '{title}' pronto al prestito per l'utente '{patron}'",
													array(	'alienString' => $alienString,
															'itemId' => $item->getItemId(),
															'title' => $item->getTrimmedTitle(40),
															'patron'=>$patron->getCompleteName()));

					// ready-to-loan automatic notification
					if (ClavisParamQuery::getParam('CLAVISPARAM','AutoEmailLoanReady') == 'true')
					{
						$ret = NotificationHelper::sendNotificationEmail('readyforloan', $patron,
							$clavisLibrarian->getLibrarian(), $deliveryLibrary,
							array($item->getCurrentLoanId()));
						if ($ret) {
							$item->setNotifyCount($item->getNotifyCount() + 1);
							$item->save();
							$loan = $item->getLoanRelatedByCurrentLoanId();
							$loan->setNotifyCount($loan->getNotifyCount() + 1);
							$loan->save();
							$labelText .= Prado::localize(' - notificato automaticamente via email');
						}
					}

					if ($this->getBlipMode())
					{
						$this->LastOperationLabel->setText($labelText);
						$this->LastOperationLabel->setCssClass('bordergreen');
						$this->LastOperationPanel->setCssClass('panel_on');
					}
					/// put out message also in blip mode       else
					$this->enqueueMessage($labelText, ClavisMessage::CONFIRM);

					$this->AvailableFound->deleteItemIds($item->getId());
					$this->datasourceUpdate(ItemQuery::create()->findPK($item->getItemId()));

					if (($patronId = $this->CirculationData->getPatronId()) > 0)
						$this->CirculationData->populate($patronId);

					$exitCode = true;
					break;

				case ClavisLoanManager::LOAN_RESERVED:
					$labelText = Prado::localize("Esemplare n.{itemId}{alienString} '{title}' prenotato per l'utente '{patron}'",
													array(	'alienString' => $alienString,
															'itemId' => $item->getItemId(),
															'title' => $item->getTrimmedTitle(40),
															'patron' => $patron->getCompleteName()));

					if ($this->getBlipMode())
					{
						$this->LastOperationLabel->setText($labelText);
						$this->LastOperationLabel->setCssClass('bordergreen');
						$this->LastOperationPanel->setCssClass('panel_on');
					}
					/// put out message also in blip mode       else
					$this->enqueueMessage($labelText, ClavisMessage::CONFIRM);

					$this->AvailableFound->deleteItemIds($item->getId());

					if (($patronId = $this->CirculationData->getPatronId()) > 0)
						$this->CirculationData->populate($patronId);

					$exitCode = true;
					break;

				case ClavisLoanManager::LOAN_ILLREQUESTED:
					$labelText = Prado::localize("Esemplare n.{itemId}{alienString} '{title}' richiesto per ILL per l'utente '{patron}'",
													array(	'alienString' => $alienString,
															'itemId' => $item->getItemId(),
															'title' => $item->getTrimmedTitle(40),
															'patron'=>$patron->getCompleteName()));

					if ($this->getBlipMode())
					{
						$this->LastOperationLabel->setText($labelText);
						$this->LastOperationLabel->setCssClass('bordergreen');
						$this->LastOperationPanel->setCssClass('panel_on');
					}
					/// put out message also in blip mode       else
						$this->enqueueMessage($labelText, ClavisMessage::CONFIRM);

					$this->AvailableFound->deleteItemIds($item->getItemId());
					$this->datasourceUpdate(ItemQuery::create()->findPK($item->getItemId()));
					if (($patronId = $this->CirculationData->getPatronId()) > 0)
						$this->CirculationData->populate($patronId);
					$exitCode = true;
					break;

				case ClavisLoanManager::LOAN_NOTRESERVABLE:
					$this->enqueueMessage(Prado::localize('La notizia \'{title}\' NON E\' PRENOTABILE da {name}',
									array('title' => $item->getTrimmedTitle(40), 'name'=> $patron->getCompleteName())), ClavisMessage::ERROR);
					$exitCode = false;
					break;

				case ClavisLoanManager::LOAN_ALREADYRESERVED:
					$this->enqueueMessage(Prado::localize('La notizia \'{title}\' E\' GIA\' STATA PRENOTATA da {name}',
									array('title' => $item->getTrimmedTitle(40), 'name'=> $patron->getCompleteName())), ClavisMessage::ERROR);
					$exitCode = false;
					break;

				case ClavisLoanManager::ERROR:
					$this->enqueueMessage(Prado::localize("Errore generico: l'esemplare con id = {itemId}{alienString} '{title}' NON PRESTATO a {name}",
							array('alienString'=>$alienString,
								'itemId' => $item->getItemId(),
								'title' => $item->getTrimmedTitle(40),
								'name'=> $patron->getCompleteName())), ClavisMessage::ERROR);
					$exitCode = false;
					break;
			}

			if (!is_null($itemRequest))
			{
				if ($itemRequest->getRequestStatus() == ItemRequestPeer::STATUS_DONE)
				{
					$this->globalReset();
					$this->returnPage();
				}
			}
		}

		if ($exitCode)
			$item->save();   // forse e' ridondante, ma serve per fissare per ogni caso la nuova actual_library_id

		$this->flushMessage();
		return $exitCode;
	}

	public function onSetOnLoan($sender, $param)
	{
		$input = $this->LoanBarcodeTextbox->getSafeText();
		$input = trim($input);
		if ($input != '')
		{
			$this->LoanBarcodeTextbox->setText('');
			$loanable = $this->ReadyForLoan->searchCodesIntoDatasource($input);
		}
		else
			$loanable = $this->ReadyForLoan->getItemsWithDueDate();

		if (count($loanable) == 0)
		{
			$this->getPage()->writeMessage(Prado::localize('Nessun elemento da processare riconosciuto come valido'), ClavisMessage::ERROR);
			$this->UserFocus->setFocusComponent($this->LoanBarcodeTextbox);
			return false;
		}

		$clavisLibrarian = $this->getUser();
		$okCount = 0;
		$okString = '';
		$failedCount = 0;
		$failedString = '';
		$patronNotEnabledCount = 0;
		$patronNotEnabledString = '';

		/* @var $item Item */
		foreach ($loanable as $row)
		{
			$item = $row['item'];
			$barcode = $item->getBarcode();
			$dueDate = $row['dueDate'];
			$result = $this->_loanmanager->DoReadyToLoan2LoanItem($item, $clavisLibrarian, $dueDate);
			$itemDataString = '<br />&nbsp;- ' 
								. $item->getTrimmedTitle(40) 
								. ($barcode == '' 
											? '' 
											: ' (' . Prado::localize('barcode') . ': ' . $barcode) . ')';

			if ($result == ClavisLoanManager::OK)
			{
				$okCount++;
				$okString .= $itemDataString;
			}
			elseif ($result == ClavisLoanManager::LOAN_PATRONNOTENABLED)
			{
				$patronNotEnabledCount++;
				$patronNotEnabledString .= $itemDataString;
			}	
			else	// fallback
			{
				$failedCount++;
				$failedString .= $itemDataString;
			}
		}

		$errorCode = ClavisMessage::ERROR;
		if (($okCount + $failedCount + $patronNotEnabledCount) == 0)
			$errorCode = ClavisMessage::INFO;
		else
		{
			if ($failedCount + $patronNotEnabledCount > 0)
				$errorCode = ClavisMessage::WARNING;
			else
				$errorCode = ClavisMessage::CONFIRM;
		}
		$messageText = '';

		if ($okCount > 0)
			$messageText .= (1 == $okCount)
								? Prado::localize('1 esemplare in prestito')
								: Prado::localize('{count} esemplari in prestito', 
													array('count' => $okCount));

		if ($patronNotEnabledCount > 0) 
		{
			if ($okCount > 1)
				$messageText .= ' / ';
			$messageText .= ($patronNotEnabledCount == 1)
								? Prado::localize("1 esemplare NON in prestito perchè l'utente non è abilitato")
								: Prado::localize("{count} esemplari NON in prestito perchè l'utente non è abilitato", 
													array('count' => $patronNotEnabledCount));
		}

		if ($failedCount > 0) 
		{
			if (($okCount + $patronNotEnabledCount) > 1)
				$messageText .= ' / ';
			$messageText .= (1 == $failedCount)
								? Prado::localize('1 esemplare NON in prestito')
								: Prado::localize('{count} esemplari NON in prestito', 
													array('count' => $failedCount));
		}
		
		if (($okString != '') || ($failedString != '') || ($patronNotEnabledString != ''))
		{
			$messageText .= '&nbsp;&nbsp;&nbsp;&nbsp;<br /><br />';
			if ($okString != '')
				$messageText .= Prado::localize('In prestito') . ':<br />' . $okString;

			if ($patronNotEnabledString != '')
				$messageText .= ($okString != '' ? '<br /><br />' : '') .
				 Prado::localize('Operazione fallita (utente non abilitato) xper') . ':<br />' . $failedString;
			
			if ($failedString != '')
				$messageText .= (($okString != '') || ($patronNotEnabledString != '') ? '<br /><br />' : '') .
				 Prado::localize('Operazione fallita per') . ':<br />' . $failedString;
		}
		else
		{
			$messageText = Prado::localize('Nessuna operazione è stata effettuata');
			$errorCode = ClavisMessage::ERROR;
		}

		$this->getPage()->writeMessage($messageText, $errorCode);
		$this->UserFocus->setFocusComponent($this->LoanBarcodeTextbox);
		///$this->setFocus($this->LoanBarcodeTextbox->getClientID());

		if ($okCount > 0)
			$this->globalRefresh($param);
	}

	public function onReportJRPReadyForLoanExtraOut($sender, $param)
	{
		$datasource = $this->ReadyForLoan->getCheckedItemsItemId(true, true);     // all + reset
		$ids = implode(',', $datasource);	

		$this->JRPBox1->setObjectId($ids);
		$this->JRPBox1->addOptionalParam('P_ORDER', $this->ReadyForLoan->getSortingExpression());		
		$this->JRPBox1->addOptionalParam('P_ORDERDIR', $this->ReadyForLoan->getSortingDirection());
		
		$this->JRPBox1->printReport();
	}	

	public function onReportJRPReservationExtraIn($sender, $param)
	{
		$datasource = $this->ExtraRequestsIn->getCheckedItemIds(true, true);      // all + reset
		
		$ids = implode(',', $datasource);
		if ($ids == "")
		{
			$this->getPage()->writemessage(Prado::localize("Nessun elemento da stampare"), ClavisMessage::ERROR);
			return false;
		}
		
		$this->JRPBox3->setObjectId($ids);
		$this->JRPBox3->addOptionalParam('P_ORDER', $this->ExtraRequestsIn->getSortingExpression());		
		$this->JRPBox3->addOptionalParam('P_ORDERDIR', $this->ExtraRequestsIn->getSortingDirection());
		
		$this->JRPBox3->printReport();
	}	

	public function onReportJRPReadyForTransitExtraIn($sender, $param)
	{
		$datasource = $this->ExtraGoHome->getCheckedId(true, true);      // all + reset
		$ids = implode(',', $datasource);
		if ($ids == "")
		{
			$this->getPage()->writemessage(Prado::localize("Nessun elemento da stampare"), ClavisMessage::ERROR);
			return false;
		}
		
		$this->JRPBox5->setObjectId($ids);
		$this->JRPBox5->addOptionalParam('P_ORDER', $this->ExtraGoHome->getSortingExpression());		
		$this->JRPBox5->addOptionalParam('P_ORDERDIR', $this->ExtraGoHome->getSortingDirection());
		$this->JRPBox5->printReport();
	}

}
