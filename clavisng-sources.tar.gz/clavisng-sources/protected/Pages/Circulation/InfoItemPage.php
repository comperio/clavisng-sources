<?php

/**
 * InfoItemPage class
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @version 2.7
 * @package Pages.Circulation
 * @since 2.0
 */

class InfoItemPage extends ClavisPage {

	public $_module = 'CIRCULATION';

	public function onInit($param)
	{
		parent::onInit($param);
		$this->attachEventHandler('OnClavisClientMessage', array($this, 'OnClavisClientMessage'));
	}
	
	public function OnClavisClientMessage($sender, $param)
	{
		$cbparam = $param->getParameter();
		$ccdata = $cbparam->getCallbackParameter();
		$cmd = $ccdata->command;
		
		//ClavisClient is replying to a pollscan
		if($cmd == 'pollscan')
		{
			$tags = RfidUtil::getTagsFromJson($ccdata->jsontags);
			$ptags = $tags[RfidUtil::TAG_TYPE_PATRON];
			$itags = $tags[RfidUtil::TAG_TYPE_ITEM];
			
			$nritags = count($itags);
			
			if($nritags > 0)
			{
				$barcode = $itags[0]->itemid;
				if($barcode != '')
				{
					$this->ItemField->setText($barcode);
					$this->performItemTasks($sender, $cbparam);
					$this->setViewState('itemsource', 'rfid');
				}
			}
			else
			{
				$vs = $this->getViewState('itemsource', NULL);
				if( ! is_null($vs) && $vs == 'rfid')
				{
					$this->panelsActivation(false);
				}
			}
		}
	}
	
	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallBack())
		{
			$this->panelsActivation(false);
			$this->setFocus($this->ItemField->getClientID());
		}

		$this->ItemInsertPanel->setCssClass("panel_off");

		if ($this->getIsCallback())
			$this->ItemInsertPanel->render($this->createWriter());
	}

	public function drawDuplicateItemBarcodePanel($newState = false, $param = null)
	{
		$currentState = $this->DuplicateItemBarcodePanel->getCssClass() == "panel_on" ? true : false;

		if ($currentState != $newState)
		{
			$newCssClass = $newState ? 'panel_on' : 'panel_off';

			$this->DuplicateItemBarcodePanel->setCssClass($newCssClass);

			if (!is_null($param))
				$this->DuplicateItemBarcodePlaceHolder->render($param->getNewWriter());
		}
	}

	public function checkItemCallBack($sender, $param)
	{
		$this->setViewState('itemsource', 'ui');
		$this->performItemTasks($sender, $param);
	}
	
	public function performItemTasks($sender, $param)
	{
		$itemInput = trim($this->ItemField->getSafeText());
		$this->ItemField->setText('');

		if ($itemInput != '')
		{
			$items = ItemPeer::retrieveByDataInput($itemInput);

			if (!is_null($items) && (count($items) > 0))
			{
				if (isset($items[0]))
					$item = $items[0];
				else
					$item = null;


				if (count($items) == 1)
				{
					$this->drawDuplicateItemBarcodePanel(false, $param);
				}
				else  // nel caso di trovati duplicati
				{
					$encodedUrl = ItemPeer::encodeItems2Url($items);
					$this->DuplicateItemId->setText($encodedUrl);
					$this->DuplicateItemHyperLink->dataBind();
					$this->drawDuplicateItemBarcodePanel(true, $param);
				}

				$canEdit = $this->getUser()->getEditPermission($item);
				$this->ModifyButton->setEnabled($canEdit);
				$this->GotoViewButton->setVisible($this->getUser()->checkAllowedPage('Catalog.ItemViewPage') == true);

				$this->setItem($item);
				$this->panelsActivation(true);
				$this->ItemView->setItem($item);
				$this->ItemView->populate();

				$this->ManifestationView->setManifestation($item->getManifestation());
				$this->ManifestationView->populate();

				if ($this->getIsCallback())
				{
					$this->ItemView->render($param->getNewWriter());
					$this->ManifestationView->render($param->getNewWriter());
					$this->ModifyButton->render($param->getNewWriter());
					$this->GotoViewButton->render($param->getNewWriter());
				}
			}
			else
			{
				$this->getPage()->writeMessage(Prado::localize("Nessun esemplare è identificato da {itemInput}", array('itemInput' => $itemInput)),
												ClavisMessage::ERROR);
				$this->panelsActivation(false);
				$this->ItemInsertPanel->setCssClass("panel_on");

				if ($this->getIsCallback())
					$this->ItemInsertPanel->render($param->getNewWriter());

				$this->setItem(null);
			}
		}
	}

	public function setItem($item)
	{
		$this->setControlState("Item", $item, null);
	}

	public function getItem()
	{
		return $this->getControlState("Item", null);
	}

	public function panelsActivation($bool)
	{
		if ($bool)
		{
			$this->ItemViewPanel->setCssClass("panel_on");
			$this->ButtonPanel->setCssClass("panel_on");
		}
		else
		{
			$this->ItemViewPanel->setCssClass("panel_off");
			$this->ButtonPanel->setCssClass("panel_off");
		}
	}

	public function blipUpdate($item, $param)
	{
		$loanmanager = $this->getApplication()->getModule('loan');
		$patron = null;
		$exitCode = null;
		$patronBarcode = $this->PatronBarcode->getSafeText();
		if (!is_null($patronBarcode) and ($patronBarcode != ''))
			$patron = PatronPeer::getPatronByBarcode($patronBarcode);

		$clavisLibrarian = $this->getUser();
		$actualLibraryId = $clavisLibrarian->getActualLibraryId();
		if ($actualLibraryId !== 0)                 // and !is_null($patron))
		{
			if (($deliveryLibraryId = $this->getDeliveryLibraryId()) > 0)
				$deliveryLibrary = LibraryPeer::retrieveByPK($deliveryLibraryId);
			else
				return false;  //non fa niente. Da sistemare

			if ($loanmanager->isItemLoaned($item))
			{
				if (!is_null($patron) && !$loanmanager->isItemLoaned($item, $patron))  // errore: prestito a persona diversa cui era stato prestato
				{
					$loanmanager->DoReturnItem($item, null, $clavisLibrarian);
					$this->getPage()->writeMessage(Prado::localize("Annullato prestito erroneo ad altro utente. L'esemplare è ora in prestito a {patron}.",
						array('patron'=>$patron->getCompleteName())), ClavisMessage::WARNING);

					$exitCode = $this->doLoan($item, $patron, $clavisLibrarian, $deliveryLibrary, null, $loanmanager->CalculateDueDate($item));
					$direction = ClavisCirculationDataCard::DIRECTION_LOAN;
				}
				else
				{
					$message = '';
					$exitCode = $this->doUnloan($item, $clavisLibrarian, $param);

					if ($exitCode == true)
					{
						if (is_null($patron))
							$message .= "Esemplare '" . $item->getTrimmedTitle(40) . " (" . $item->getItemId() . ") ritornato.";

						if ($loanmanager->IsItemOutOfHome($item) == true)
						{
							$homeLibraryLabel = $item->getHomeLibraryLabel();
							if ($homeLibraryLabel != '')
								$libraryString = ', per la biblioteca: \'' . $homeLibraryLabel. '\'';
							else
								$libraryString = '';
							if ($message != '')
								$message .= '<br />';
							$message .= 'Mettere in cesta' . $libraryString. '.';
						}

						if ($message != '')
							$this->getPage()->writeMessage($message, ClavisMessage::CONFIRM);
						$direction = ClavisCirculationDataCard::DIRECTION_RETURN;
					}
					else   // errore sulla doUnloan
						$this->getPage()->writeMessage('Errore sul rientro',ClavisMessage::ERROR);
				}
			}
			else
			{
				if (is_null($patron))
				{
					$this->getPage()->writeMessage('Utente non selezionato.',ClavisMessage::ERROR);
					$this->setFocus($this->ResultLabel->getClientID());
					return false;
				}
				$exitCode = $this->doLoan($item, $patron, $clavisLibrarian, $deliveryLibrary, null, $loanmanager->CalculateDueDate($item));
				$direction = ClavisCirculationDataCard::DIRECTION_LOAN;
			}

			if ($exitCode)
				$this->CirculationData->populate($patronBarcode, $item->getItemId(), $direction);
			$this->setFocus($this->ItemField->getClientID());
		}
	}

	public function onItemModify($sender, $param)
	{
		$item = $this->getItem();
		if (!is_null($item) && ($item instanceof Item))
			$this->gotoPageWithReturn('Catalog.ItemInsertPage', array('id' => $item->getItemId()));
	}

	public function onItemInsert($sender, $param)
	{
		$this->gotoPageWithReturn('Catalog.ItemInsertPage');
	}

	public function onGotoViewPage($sender, $param)
	{
		$item = $this->getItem();
		if ($item instanceof Item)
			$this->gotoPage("Catalog.ItemViewPage", array("id" => $item->getItemId()));
	}

}
