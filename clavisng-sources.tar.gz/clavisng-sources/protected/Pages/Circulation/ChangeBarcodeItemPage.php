<?php
/**
 * ChangeBarcodeItemPage class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info
 * @comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Pages.Circulation
 */

/**
 * ChangeBarcodeItemPage class
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.7
 * @package Pages.Circulation
 * @since 2.5.2
 */
class ChangeBarcodeItemPage extends ClavisPage {

	public $_module = "CIRCULATION";

	/** @param ClavisLoanManager $_loanmanager */
	protected $_loanmanager;

	public function onLoad($param)
	{
		parent::onLoad($param);

		$this->_loanmanager = $this->getApplication()->getModule('loan');
		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallBack())
		{
			$this->panelsActivation(false);
			$this->setFocus($this->ItemField->getClientID());
		}

		$this->ItemInsertPanel->setCssClass("panel_off");

		if ($this->getIsCallback())
			$this->ItemInsertPanel->render($this->createWriter());
	}

	public function drawDuplicateItemBarcodePanel($newState = false, $param = null)
	{
		$currentState = $this->DuplicateItemBarcodePanel->getCssClass() == "panel_on" ? true : false;

		if ($currentState != $newState)
		{
			$newCssClass = $newState ? 'panel_on' : 'panel_off';

			$this->DuplicateItemBarcodePanel->setCssClass($newCssClass);

			if (!is_null($param))
			{
				$this->DuplicateItemBarcodePlaceHolder->render($param->getNewWriter());
			}
		}
	}

	public function checkItemCallBack($sender, $param)
	{
		$itemInput = trim($this->ItemField->getSafeText());
		$this->ItemField->setText('');

		if ($itemInput != '')
		{
            $c= new Criteria();
            $c->add(ItemPeer::HOME_LIBRARY_ID, $this->getUser()->getActualLibraryId() );
            $c->add(ItemPeer::INVENTORY_NUMBER,$itemInput);
            
			$items = ItemPeer::doSelect($c);

			if (!is_null($items) && (count($items) > 0))
			{
				if (isset($items[0]))
					$item = $items[0];
				else
					$item = null;


				if (count($items) == 1)
				{
					$this->drawDuplicateItemBarcodePanel(false, $param);
				}
				else  // nel caso di trovati duplicati
				{
					$encodedUrl = ItemPeer::encodeItems2Url($items);
					$this->DuplicateItemId->setText($encodedUrl);
					$this->DuplicateItemHyperLink->dataBind();
					$this->drawDuplicateItemBarcodePanel(true, $param);
				}

				$canEdit = $this->getUser()->getEditPermission($item);
				$this->ModifyButton->setEnabled($canEdit);
				$this->GotoViewButton->setVisible($this->getUser()->checkAllowedPage('Catalog.ItemViewPage') == true);

				$this->setItem($item);
				$this->panelsActivation(true);
				$this->ItemView->setItem($item);
				$this->ItemView->populate();

				$this->ManifestationView->setManifestation($item->getManifestation());
				$this->ManifestationView->populate();

				if ($this->getIsCallback())
				{
					$this->ItemView->render($param->getNewWriter());
					$this->ManifestationView->render($param->getNewWriter());
					$this->ModifyButton->render($param->getNewWriter());
					$this->GotoViewButton->render($param->getNewWriter());
                    $this->getPage()->setFocus($this->BarcodeField);
				}
			}
			else
			{
				$this->getPage()->writeMessage(Prado::localize("Nessun esemplare è identificato da {itemInput}", array('itemInput' => $itemInput)),
												ClavisMessage::ERROR);
				$this->panelsActivation(false);
				$this->ItemInsertPanel->setCssClass("panel_on");

				if ($this->getIsCallback())
					$this->ItemInsertPanel->render($param->getNewWriter());

				$this->setItem(null);
			}

		}
	}

    public function setBarcodeItemCallBack($sender, $param)
	{
        $barcode = trim($this->BarcodeField->getSafeText());
		$this->BarcodeField->setText('');

		if ($barcode != '')
        {
            $bcodeCount = ItemQuery::create()
                ->filterByBarcode($barcode)
                ->count();

            if($bcodeCount > 0 ) {
                $this->getPage()->writeMessage(Prado::localize("Barcode duplicato"),ClavisMessage::ERROR);
                return;
            }


            try {
                $item = $this->getItem();
                $item->setBarcode($barcode);
                $item->save();
                $this->setItem($item);
                $this->ItemView->setItem($item);
				$this->ItemView->populate();

				$this->ManifestationView->setManifestation($item->getManifestation());
				$this->ManifestationView->populate();

				if ($this->getIsCallback())
				{
					$this->ItemView->render($param->getNewWriter());
					$this->ManifestationView->render($param->getNewWriter());
					$this->ModifyButton->render($param->getNewWriter());
					$this->GotoViewButton->render($param->getNewWriter());
				}
            } catch (Exception $e) {
                $this->getPage()->writeMessage(Prado::localize("Errore nell'aggiornamento dell'esemplare"),ClavisMessage::ERROR);
            }
        }
    }
    
    
	public function setItem($item)
	{
		$this->setControlState("Item", $item, null);
	}

    /**
     * @return Item
     */
    public function getItem()
	{
		return $this->getControlState("Item", null);

	}

	public function panelsActivation($bool)
	{
		if ($bool)
		{
			$this->ItemViewPanel->setCssClass("panel_on");
			$this->ButtonPanel->setCssClass("panel_on");
		}
		else
		{
			$this->ItemViewPanel->setCssClass("panel_off");
			$this->ButtonPanel->setCssClass("panel_off");
		}
	}

	public function onItemModify($sender, $param)
	{
		$item = $this->getItem();
		if (!is_null($item) && ($item instanceof Item))
			$this->gotoPageWithReturn('Catalog.ItemInsertPage', array('id' => $item->getItemId()));
	}

	public function onItemInsert($sender, $param)
	{
		$this->gotoPageWithReturn('Catalog.ItemInsertPage');
	}

	public function onGotoViewPage($sender, $param)
	{
		$item = $this->getItem();
		if ($item instanceof Item)
			$this->gotoPage("Catalog.ItemViewPage", array("id" => $item->getItemId()));
	}

}
