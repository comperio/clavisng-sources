<?php

/**
 * RenewItemPopup class
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @version 2.7
 * @package Popups.Circulation
 * @since 2.1
 */

class RenewItemPopup extends ClavisPagePopup
{
	private	$_loanmanager;
	public $_module = 'CIRCULATION';

	private function initVars()
	{
		$this->_loanmanager = $this->getApplication()->getModule("loan");
	}

	public function onInit($param)
	{
		parent::onInit($param);
		$this->initVars();
	}

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsPostBack() 
				&& !$this->getPage()->getIsCallBack())
		{
			$ids = array();
			$objectType = $this->Request['objectType'];
			$param = $this->Request['param'];

			if ($objectType == 'Array')
			{
				$ids = unserialize($param);

				if (array_key_exists(-1, $ids))
				{
					if ($ids[-1] == 0)
					{
						$this->AddedText->setText(Prado::localize("solo per gli esemplari prestati da questa biblioteca"));
					}
					elseif ($ids[-1] == 1)
					{
						$this->AddedText->setText(Prado::localize("per tutti gli esemplari attualmente in prestito"));
					}
					
					unset ($ids[-1]);
				}
				
				if (count($ids) == 1)
				{
					$loan = LoanQuery::create()->findPk($ids[0]);
					
					if ($loan instanceof Loan)
					{
						$ids = array($loan->getItemId());
					}
					else
					{
						$ids = array();
					}
				}
			}
			else
			{
				$itemId = intval($param);
				
				if ($itemId > 0)
					$ids = array($itemId);
			}

			$this->setItemIds($ids);
			$this->populate();
		}
	}

	public function setItemIds($itemId)
	{
		$this->setViewState("ItemId", $itemId, array());
	}

	public function getItemIds()
	{
		return $this->getViewState("ItemId", array());
	}

	public function populate()
	{
		$okFlag = false;
		$ids = $this->getItemIds();

		if (count($ids) == 1)
		{
			$this->SingleLoanPanel->setVisible(true);
			$this->MultiLoanPanel->setVisible(false);

			$item = ItemQuery::create()->findPk($ids[0]);
			
			if ($item instanceof Item)
			{
				$okFlag = true;
				
				$this->Title->setText($item->getTitle());
				$this->Date->setValue($item->getDueDate('U'));
				$this->RenewNum->setText($item->getRenewalCountLabel());
				$this->NewDate->setTimeStamp($this->_loanmanager->CalculateRenewDate($item));
			}
		}
		elseif (count($ids) > 1)
		{
			$this->SingleLoanPanel->setVisible(false);
			$this->MultiLoanPanel->setVisible(true);
			$this->LoanGrid->initialReload($ids);
			$okFlag = true;
		}

		if (!$okFlag)
		{
			$this->Title->setText('');
			$this->getPage()->writeMessage("Nessun parametro è stato passato al popup. Riportare al fornitore del software",
												ClavisMessage::ERROR);
		}
	}

	public function onRenewLoan($sender, $param)
	{
		$this->getPage()->cleanMessageQueue();
		
		$okFlag = false;
		$renewDate = $this->NewDate->getTimeStamp();
		$ids = $this->getItemIds();
		
		if (count($ids) > 1)
		{
			$newArr = array();
		
			foreach ($ids as $loanId)
			{
				$loan = LoanQuery::create()->findPk($loanId);
			
				if (!is_null($loan))
				{
					$iId = intval($loan->getItemId());
				
					if ($iId > 0)
						$newArr[] = $iId;
				}
			}
			
			$ids = $newArr;
		}

		foreach ($ids as $itemId)
		{
			$item = null;
			
			if ($itemId > 0)
				$item = ItemQuery::create()->findPk($itemId);

			if (!is_null($item) 
					&& ($item instanceof Item))
			{
				$clavisLibrarian = $this->getUser();
				$destinationObject = $this->_loanmanager->getLoanDestinationObject($item);
				
				if (!is_null($destinationObject))
				{
					if ($this->_loanmanager->DoRenewLoan(	$item, 
															$destinationObject, 
															$clavisLibrarian, 
															Prado::localize('rinnovo standard'), 
															null, 
							
															$renewDate ))
					{	// ok case
						$okFlag = true;
						$this->getPage()->enqueueMessage(Prado::localize("Prestito dell'esemplare '{title}' [barcode: {barcode}] prorogato alla data {date}",
																				array(	'date' => Clavis::dateFormat($item->getDueDate('U'),'shortdate'),
																						'title' => $item->getTrimmedTitle(50),
																						'barcode' => $item->getBarcode())),
															ClavisMessage::CONFIRM);
					}
					else
					{	// renew failed
						$this->getPage()->enqueueMessage(Prado::localize("Fallita proroga dell'esemplare '{title}' [barcode: {barcode}] alla data {date}",
																				array(	'date' => Clavis::dateFormat($item->getDueDate('U'),'shortdate'),
																						'title' => $item->getTrimmedTitle(50),
																						'barcode' => $item->getBarcode())),
															ClavisMessage::ERROR);
					}
				}
				else
				{	
					$this->getPage()->enqueueMessage(Prado::localize("Incongruenza sulla proroga dell'esemplare con id: {id}.<br />Riportare al fornitore del software, grazie",
																			array('id' => $item->getItemId())),
														ClavisMessage::ERROR);
				}
			}
		}

		if ($okFlag)
		{
			if (count($ids) > 1)
			{
				$this->getApplication()->getSession()->add('UpdateItemId', 9999999999);
			}
			else	
			{
				$this->getApplication()->getSession()->add('UpdateItemId', $itemId);
				$this->getApplication()->getSession()->add('DontUpdateLoanPage', 1);
			}
		}
		else
		{
			$this->getPage()->enqueueMessage(Prado::localize('Errore sulla proroga: ricontrollare la data ({date})', 
																array(	'date' => Clavis::dateFormat($this->NewDate->getTimeStamp(),
																		'shortdate'))), 
												ClavisMessage::ERROR);
		}

		////$this->getPage()->flushDelayedMessage(true);   // first page load
		$this->getPage()->flushDelayedMessage();   // normal postback main page
		
		$this->getPage()->getClientScript()->registerEndScript(__CLASS__.'_js','onReturn(\'\',\'\',true);');
	}

	public function isUnlink()
	{
		return false;
	}
	
}