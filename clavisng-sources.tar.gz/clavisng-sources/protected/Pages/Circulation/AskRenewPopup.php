<?php

/**
 * AskRenewPopup
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @version 2.7
 * @package Popups.Circulation
 * @since 2.2
 */

class AskRenewPopup extends ClavisPagePopup
{
	const INVALIDEMAIL = '**NOeMail**';

	private	$_loanmanager;
	
	public $_module = 'CIRCULATION';

	private function initVars()
	{
		$this->_loanmanager = $this->getApplication()->getModule("loan");
	}

	public function onInit($param)
	{
		parent::onInit($param);
		$this->initVars();
	}

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallBack())
		{
			$ids = array();
			$objectType = $this->Request['objectType'];
			$param = $this->Request['param'];

			if ($objectType == 'Array')
			{
				$ids = unserialize($param);
				if (count($ids) == 1)
				{
					$loan = LoanPeer::retrieveByPK($ids[0]);
					if ($loan instanceof Loan)
						$ids = array($loan->getItemId());
					else
						$ids = array();
				}
			}
			else
			{
				$itemId = intval($param);
				if ($itemId > 0)
					$ids = array($itemId);
			}

			$this->setItemIds($ids);
			$this->populate();
		}
	}

	public function setItemIds($itemId)
	{
		$this->setViewState("ItemId", $itemId, array());
	}

	public function getItemIds()
	{
		return $this->getViewState("ItemId", array());
	}

	public function isUnlink()
	{
		return false;
	}
	
	public function populate()
	{
		$okFlag = false;
		$ids = $this->getItemIds();

		if (count($ids) == 1)
		{
			$this->SingleLoanPanel->setVisible(true);
			$this->MultiLoanPanel->setVisible(false);

			$item = ItemPeer::retrieveByPK($ids[0]);
			if ($item instanceof Item)
			{
				$myLibraryId = $this->getUser()->getActualLibraryId();
				$myLibrary = $this->getUser()->getActualLibrary();
				$myConsortiumString = $myLibrary->getConsortiaString();

				$okFlag = true;
				$title = $item->getTitle();
				$this->Title->setText($title);

				$dueDate = Clavis::dateFormat($item->getDueDate('U'));
				$this->Date->setText($dueDate);

				$renewDate = $this->_loanmanager->CalculateRenewDate($item);
				$this->NewDate->setTimeStamp($renewDate);

				$externalLibraryString = $item->getOwnerLibraryLabel(false, null, false);
				$this->ExternalLibrary->setText($externalLibraryString);
				$externalLibrary = $item->getOwnerLibrary();
				if (!($externalLibrary instanceof Library))
				{
					$this->getPage()->writeMessage("Errore nel passaggio dei parametri, contattare il fornitore del software.",ClavisMessage::ERROR);
					$this->ProcessButton->setVisible(false);
					return;
				}
				$emailAddress = $externalLibrary->getEmail();
				$this->EmailAddress->setText($emailAddress);

				$template = DocumentTemplatePeer::getTemplate(	'EXTRA_RENEW_ASK',
																				$this->getApplication()->getGlobalization()->getCulture(),
																				$myLibraryId);

				$this->Body->setText($template->getTemplateBody());
				
				$subject = "[$myConsortiumString]: " . $template->getTemplateTitle();
				$this->Subject->setText($subject);
			}
		}
		elseif (count($ids) > 1)
		{
			$this->SingleLoanPanel->setVisible(false);
			$this->MultiLoanPanel->setVisible(true);
			$this->LoanGrid->initialReload($ids);
			$okFlag = true;
		}

		if (!$okFlag)
		{
			$this->Title->setText('');
			$this->getPage()->writeMessage(Prado::localize("Errore nel passaggio dei parametri, contattare il fornitore del software."),ClavisMessage::ERROR);
		}
	}

	public function onAskRenew($sender, $param)
	{
		$this->cleanMessageQueue();

		$ids = $this->getItemIds();

		if (count($ids) == 1)
		{
			$item = ItemPeer::retrieveByPK($ids[0]);
			
			if ($item instanceof Item)
			{
				$loan = $item->getCurrentLoan();
				
				if ($loan instanceof Loan)
				{
					$item = $loan->getItem();
					
					if ($item instanceof Item)
					{
						$patron = $loan->getPatron();
						$library = $item->getOwnerLibraryLabel();

						$oldDueDate = Clavis::dateFormat($loan->getDueDate('U'));
						$newRenewDate = Clavis::dateFormat($this->_loanmanager->CalculateRenewDate($item, $patron));

						$notificationManager = $this->getApplication()->getModule('notification');
						$resultAddress = $notificationManager->sendEmailRenew('EXTRA_RENEW_ASK', $loan, $oldDueDate, $newRenewDate);
			
						if ($resultAddress == self::INVALIDEMAIL)
							$this->getPage()->enqueueMessage(Prado::localize("La biblioteca richiedente [{library}] non ha un indirizzo email valido",
																				array('library' => $library ) ),
																ClavisMessage::ERROR);
						elseif ($resultAddress != '')
						{
							$this->getPage()->enqueueMessage(Prado::localize("É stata correttamente richiesta la proroga dell'esemplare '{title}' [inv: {inv}, coll: {coll}] alla biblioteca '{library}', all'indirizzo '{email}'",
																				array(	'date' => $newRenewDate,
																						'title' => $item->getTrimmedTitle(60),
																						'inv' => $item->getCompleteInventoryNumber(),
																						'coll' => $item->getCollocationCombo(),
																						'library' => $library,
																						'email' => $resultAddress )),
																ClavisMessage::INFO);

						}
						else
						{
							$this->getPage()->enqueueMessage(Prado::localize("É fallita la richiesta di proroga per l'esemplare '{title}' [inv: {inv}]",
																				array('title' => $item->getTrimmedTitle(60),
																						'inv' => $item->getCompleteInventoryNumber() )),
																ClavisMessage::ERROR);
						}
					}
					else
					{
						$this->getPage()->enqueueMessage(Prado::localize("Errore nel passaggio dei parametri. Riportare al fornitore del software."),
															ClavisMessage::ERROR);
					}
				}
				else
				{
					$this->getPage()->enqueueMessage(Prado::localize("Incongruenza sul database durante la richiesta di proroga, relativamente al prestito con loan_id = {loanId}. Riportare al fornitore del software.",
																			array('loanId' => $item->getCurrentLoanId() )),
														ClavisMessage::ERROR);
				}
			}
			else
			{		
				$this->getPage()->enqueueMessage(Prado::localize("L'esemplare con item_id = {itemId} non esiste. Riportare al fornitore del software.",
																		array('itemId' => $ids[0] )),
													ClavisMessage::ERROR);
			}
		}
		else
		{
			$this->getPage()->enqueueMessage(Prado::localize("Errore nel passaggio dei parametri durante la richiesta di proroga. Riportare al fornitore del software."),
												ClavisMessage::ERROR);
		}
		
		// chiusura popup
		$this->getPage()->flushDelayedMessage();
		$this->getPage()->getClientScript()->registerEndScript(__CLASS__.'_js','onReturn(\'\',\'\',true);');
	}

	/// probably no more used by anyone. Moved to the NotificationManager (by mbrancalion)
	private function sendEmailRenew($templateName = '', $loan = null, $oldDueDate = null, $newRenewDate = null, $description = null)
	{
		/* @var $patron Patron */
		/* @var $externalLibrary Library */

		/* @var $myLibrary Library */
		/* @var $loan Loan */

		$templateName = trim($templateName);
		if ($templateName == '')
			return false;

		$success = false;
		$clavisLibrarian = $this->getUser();

		$patronData = '---';
		$patron = $loan->getPatron();
		if ($patron instanceof Patron)
			$patronData = $patron->getCompleteName();

		$item = $loan->getItem();
		if(!($item instanceof Item))
			return '';

		$library = $item->getOwnerLibrary();
		if ($library instanceof Library)
		{
			$libraryEmailString = trim($library->getEmail());
			if ($libraryEmailString == '')
				return self::INVALIDEMAIL;

			$libraryEmail = array($libraryEmailString);
		}
		else
			return self::INVALIDEMAIL;

		$libraryString = $item->getOwnerLibraryLabel(false, true, false, false);   // strip tags, no addendum

		if (is_null($oldDueDate))
			$oldDueDate = Clavis::dateFormat($loan->getDueDate('U'));

		if (is_null($newRenewDate))
			$newRenewDate = Clavis::dateFormat($this->_loanmanager->CalculateRenewDate($item, $patron));

		$title = $item->getTrimmedTitle(60);
		$inventory = $item->getCompleteInventoryNumber();
		$collocation = $item->getCollocationCombo();

		$myLibrary = $this->getUser()->getActualLibrary();
		$myLibraryId = $this->getUser()->getActualLibraryId();
		$myConsortiumString = $myLibrary->getConsortiaString();

		$notificationManager = $this->getApplication()->getModule('notification');

		if ($description != '')
			$description = Prado::localize("con la seguente motivazione") . ":\n" . $description . "\n";

		$class = get_class($library);
		$receiverId = $library->getLibraryId();

		$template = DocumentTemplatePeer::getTemplate(	$templateName,
														$this->getApplication()->getGlobalization()->getCulture(),
														$myLibraryId);

		$subject = trim($this->Subject->getSafeText());
		$body = trim($this->Body->getSafeText());

		if ($subject == '')
			$subject = "[$myConsortiumString]: " . $template->getTemplateTitle();

		if ($body == '')
			$body = $template->getTemplateBody();

		$arr_alias = array(	'EXTERNALLIBRARY' => $libraryString,
							'TITLE'		=> $title,
							'INVENTORY' => $inventory,
							'COLLOCATION' => $collocation,
							'PATRON' => $patronData,
							'OLDRENEW' => $oldDueDate,
							'NEWRENEW' => $newRenewDate,

							'MOTIVATION'	=> $description,
							'LIBRARY'		=> $myLibrary->getLabel(),
							'LIBRARY_CODE'	=> $myLibrary->getLibraryCode(),
							'LIBRARY_DESCRIPTION'	=> $myLibrary->getDescription(),
							'LIBRARY_CITY'		=> $myLibrary->getCity(),
							'LIBRARY_ADDRESS'	=> $myLibrary->getAddress(),
							'LIBRARY_PHONE'	=> $myLibrary->getPhone(),
							'LIBRARY_FAX'	=> $myLibrary->getFax(),
							'LIBRARY_EMAIL'	=> $myLibrary->getEmail() );

		$mailData = array();
		$mailData['to'] = $libraryEmail;
		$mailData['bcc'] = array();
		$mailData['cc'] = array();
		$mailData['body'] = '';
		$mailData['subject'] = $subject;

		$mailData['from'] = array(	'name' => $myLibrary->getLabel(),
									'email' => $myLibrary->getEmail());

		$notificationData = array(	'sender_library_id' => $myLibraryId,
									'receiver_class' => $class,
									'receiver_id' => $receiverId,
									'notification_class' => 'X',
									'description' => Prado::localize("Richiesta proroga a biblioteca esterna"),
									'notes' => array() );

		try
		{
			$ret = $notificationManager->DoEmailReport(	$body,
														$arr_alias,
														$mailData,
														NotificationManager::EMAIL_AUTO,
														$notificationData);

			if ($ret === true)
				$success = implode(',', $libraryEmail);
		}
		catch (Exception $e)
		{
			//throw ($e);
			$success = false;
		}

		return $success;
	}
	
}