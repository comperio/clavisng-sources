<?php

/**
 * PatronList page
 * @author    Dario Rigolin <dario@comperio.it>
 * @author    Marco Brancalion <marco@comperio.it>
 * @link      http://www.e-portaltech.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @license   http://www.e-portaltech.it/license/
 */

class PatronList extends ClavisPage
{
	public $_module = 'CIRCULATION';

	/**
	 * @param $param
	 */
	public function onInit($param)
	{
		parent::onInit($param);

		if (!$this->getIsPostBack() && !$this->getIsCallback()) {
			$this->setNewPatronFlag(TPropertyValue::ensureBoolean($this->Request['newPatron']));
			$this->setAfterSearch(false);
			$this->PatronList->initQueryBuilder();
		}
	}

	/**
	 * @param $param
	 */
	public function onPreRender($param)
	{
		parent::onPreRender($param);

		$newPatronFlag = $this->getNewPatronFlag();
		$addToShelfVisible = !$newPatronFlag && (count($this->PatronList->getDataSource()) > 0);
		$addToPatronVisible = $newPatronFlag
			&& $this->getAfterSearch()
			&& ($this->getPage()->getIsPostBack() || $this->getPage()->getIsCallback());

		$this->AddToShelfPanel->setVisible($addToShelfVisible);
		$this->AddPatronPanel->setVisible($addToPatronVisible);
		$this->OperationPanel->setVisible($addToShelfVisible || $addToPatronVisible);

		if ($newPatronFlag) {
			$this->PageLabel->setText(Prado::localize('Ricerca utente esistente'));
		}
	}

	/**
	 * @param bool $flag
	 */
	public function setNewPatronFlag($flag = false)
	{
		$this->setViewState('NewPatronFlag', $flag, false);
	}

	/**
	 * @return mixed|null
	 */
	public function getNewPatronFlag()
	{
		return $this->getViewState('NewPatronFlag', false);
	}


	/**
	 * @param bool $flag
	 */
	public function setAfterSearch($flag = false)
	{
		$this->setViewState('afterSearchFlag', $flag, false);
	}

	/**
	 * @return bool
	 */
	public function getAfterSearch(): bool
	{
		return TPropertyValue::ensureBoolean($this->getViewState('afterSearchFlag', false));
	}

	/**
	 *
	 */
	public function globalRefresh()
	{
		$this->PatronList->populate();
	}

	/**
	 * @param $sender
	 * @param $param
	 */
	public function onAddToShelf($sender, $param)
	{
		$counter = 0;
		$shelfId = (int) trim($this->ShelfResultValue->getSafeText());

		$this->ShelfResultLabel->setText('');
		$this->ShelfResultValue->setText('');

		if ($shelfId > 0)
		{
			$shelf = ShelfQuery::create()->findPk($shelfId);
			
			if (($shelf instanceof Shelf) && null !== $shelf)
				$counter = $shelf->addItemToShelf('patron', $this->PatronList->getCheckedId(true));
		}

		if ($counter > 0)
		{
			$this->writeMessage($counter == 1 ? Prado::localize('1 elemento processato') : Prado::localize('{count} elementi processati',
																	array('count' => $counter)),
									  ClavisMessage::CONFIRM);
		}
		else
		{
			$this->writeMessage(Prado::localize('Nessun elemento aggiunto a scaffale'),
									ClavisMessage::ERROR);
		}
	}

	/**
	 * @param $sender
	 * @param $param
	 */
	public function onAddNewPatron($sender, $param)
	{
		$newPatronFilters = $this->PatronList->getNewPatronFilters();

		$this->gotoPage('Circulation.PatronPage',
			array('newPatronParams' => urlencode(serialize($newPatronFilters))));
	}


	public function onPatronSearchDone($sender, $params)
	{
		$this->setAfterSearch(true);
	}
}
