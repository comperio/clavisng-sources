<?php

/**
 * Home class
 *
 * @author Dario Rigolin <dario@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @version 2.7
 * @package Pages.Circulation
 * @since 2.0
 */
class Home extends ClavisPage
{
	public $_module = 'CIRCULATION';

	public function onInit($param)
	{
		parent::onInit($param);

		if (!$this->getIsPostBack() && !$this->getIsCallback())
		{
			$filters = array(	'PatronStatusFilter' => PatronPeer::STATUS_INCOMPLETE,
								'LibraryFilter' => $this->getUser()->getActualLibraryId() );
			
			$this->PatronList->setFilters($filters);
			$this->PatronList->setViewFilters(false);
		}
	}

	public function populate()
	{
		$this->globalRefresh();
	}
	
}
