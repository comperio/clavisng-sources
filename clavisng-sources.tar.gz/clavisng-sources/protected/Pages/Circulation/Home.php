<?php

/**
 * Home class
 * @author    Dario Rigolin <dario@comperio.it>
 * @link      http://www.comperio.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @version   2.7
 * @package   Pages.Circulation
 * @since     2.0
 */
class Home extends ClavisPage
{
	public $_module = 'CIRCULATION';

	public function onInit($param)
	{
		parent::onInit($param);
		$this->attachEventHandler('OnActualLibraryChanged', array($this, 'OnActualLibraryChanged'));

		if (!$this->getIsPostBack() && !$this->getIsCallback()) {
			$this->getPatronsStatusIncomplete();
		}
	}

	public function OnActualLibraryChanged()
	{
		$this->getPatronsStatusIncomplete();
	}

	public function populate()
	{
		$this->globalRefresh();
	}

	private function getPatronsStatusIncomplete()
	{
		$criteria = new Criteria;
		$criteria->add(PatronPeer::PATRON_STATUS, PatronPeer::STATUS_INCOMPLETE, Criteria::EQUAL);
		$criteria->addAnd(PatronPeer::PREFERRED_LIBRARY_ID, $this->getUser()->getActualLibraryId());

 		$this->PatronList->searchByCriteria($criteria);
	}
}
