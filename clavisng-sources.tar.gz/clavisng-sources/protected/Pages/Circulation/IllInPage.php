<?php
/**
 * IllInPage class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info
 * @comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.8.9
 * @package Pages.Circulation
 */

/**
 * IllInPage Class
 *
 * It permits the views of the actual interbibliotecary requests.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.8.9
 * @package Pages.Circulation
 * @since 2.1
 */
class IllInPage extends ClavisPage
{
	public $_module = 'CIRCULATION';
	protected $_loanmanager;
	
	private $_fromLibraryId;
	private $_loanStatus;

	private function initVars()
	{
		$this->_loanmanager = $this->getApplication()->getModule('loan');
	}
	
	public function onInit($param)
	{
		parent::onInit($param);
		$this->initVars();
		
		// first page cycle
		if (!$this->getPage()->getIsPostBack())
		{
			$this->InTransit->setLoanStatusMode(array(ItemPeer::LOANSTATUS_INTRANSIT));
			$this->ToShelf->setLoanStatusMode(array(ItemPeer::LOANSTATUS_TOSHELF));
		}
	}

	/**
	 * It manages the mechanism of setting (resetting/initialization) the
	 * dropdowns which perform as filters for the population of the
	 * loans grid.
	 *
	 * @param TEventParameter $param
	 */
	public function onLoad($param)
	{
		parent::onLoad($param);

		$this->_fromLibraryId = $this->getFromLibraryId();
		$this->_loanStatus = $this->getLoanStatus();

		// first page cycle
		if (!$this->getPage()->getIsPostBack() 
				&& !$this->getPage()->getIsCallBack())
		{
			$selectTab = intval($this->getRequest()->itemAt('selectTab'));
			
			if ($selectTab > 0)
				$this->MainTab->setActiveViewIndex($selectTab);

			$librariesWithBlank = LibraryPeer::getLibrariesHashWithBlank(null, null, true, 35);
			$this->FromLibrary->setDataSource($librariesWithBlank);
			$this->ControlSwitches->dataBind();

			$this->globalRefresh();

			$this->focusToComponent($this->ReadyForLoanBarcodeTextbox);
		}
	}

 	public function setFromLibraryId($lib)
 	{
 		$this->_fromLibraryId = $lib;
 		$this->setViewState('fromLibraryId', $this->_fromLibraryId, null);
 	}

 	public function getFromLibraryId()
 	{
 		if (($lib = $this->_fromLibraryId) == null)
 		{
 			$lib = $this->getViewState('fromLibraryId', null);
 			$this->_fromLibraryId = $lib;
 		}
		
		return $lib;
 	}

 	public function setLoanStatus($loanStatus)
 	{
 		$this->_loanStatus = $loanStatus;
 		$this->setViewState('loanStatus', $this->_loanStatus, null);
 	}

 	public function getLoanStatus()
 	{
 		if (($loanStatus = $this->_loanStatus) == null)
 			$this->_loanStatus = $loanStatus;
		
		return $loanStatus;
 	}

 	/**
 	 * Does this page have popups inside?.....
 	 *
 	 * @return boolean
 	 */
 	public function isPopup()
 	{
 		return false;
 	}

 	/**
 	 * It refreshes all the components (grids) in the page,
 	 * altogether.
 	 *
 	 */
 	public function globalRefresh()
 	{
 		$barcode = $this->BarcodeFilter->getSafeText();
		$fromLibraryId = $this->FromLibrary->getSelectedValue();
		$patronId = $this->HiddenValue->Value;

		$outDateFrom = $this->OutDateFrom->getText() != '' 
							? $this->OutDateFrom->getTimeStamp() 
							: null;
		
		$outDateTo = $this->OutDateTo->getText() != '' 
							? $this->OutDateTo->getTimeStamp() 
							: null;

		$this->InTransit->setFilters(	$barcode,
										$fromLibraryId,
										$patronId,
										$outDateFrom,
										$outDateTo );

 		$this->InTransit->resetDataSource();

 		$this->ToShelf->setFilters(	$barcode, 
									$fromLibraryId,
									$patronId,
									$outDateFrom,
									$outDateTo );
		
 		$this->ToShelf->resetDataSource();
 	}

 	/**
 	 * It updates the page in case a new patron is choosen.
 	 *
 	 * @param TControl $sender
 	 * @param TEventParameter $param
 	 */
 	public function onPatronIdChanged($sender, $param)
 	{
 		$id = $this->HiddenValue->getValue();
		$patron = PatronQuery::create()->findPk($id);
 		$completeName = $patron->getCompleteName();
 		$this->PatronLabel->Text = $completeName;
 		$this->PatronPanel->Visible = true;
 	}

 	/**
 	 * It resets (also visually) the choice of patron.
 	 *
 	 * @param TControl $sender
 	 * @param TEventParameter $param
 	 */
	public function onResetPatron($sender, $param)
	{
		$this->HiddenValue->setValue('');
 		$this->PatronPanel->Visible = false;
	}

 	/**
 	 * It resets (also visually) the date choice.
 	 *
 	 * @param TControl $sender
 	 * @param TEventParameter $param
 	 */
	public function onResetOutDate($sender, $param)
	{
		$this->OutDateFrom->setText('');
 		$this->OutDateTo->setText('');

		if ($this->getIsCallback()
				&& !is_null($param))
			$this->DatesPanel->render($param->getNewWriter());
	}

	public function onCleanFilters($sender, $param)
	{
		$this->onResetPatron(null, null);
		$this->onResetOutDate(null, null);
		$this->FromLibrary->setSelectedIndex(0);
		$this->BarcodeFilter->setText('');

		$this->globalRefresh();
	}

	/**
	 * Callback from update button in the page.
	 * It performs retrieving of filters and next it populates.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onSubmit($sender, $param)
	{
		$this->globalRefresh();
	}

	public function onReadyForLoan($sender, $param)
	{
		$input = $this->ReadyForLoanBarcodeTextbox->getSafeText();
		$input = trim($input);
		
		if ($input != '')
		{
			$this->ReadyForLoanBarcodeTextbox->setText('');
			$readyForLoans = $this->InTransit->searchCodesIntoDatasource($input);
		}
		else
		{
			$readyForLoans = $this->InTransit->getItemsWithDueDate();
		}

		if (count($readyForLoans) == 0)
		{
			$this->getPage()->writeMessage(Prado::localize('Nessun elemento da processare riconosciuto come valido'), 
											ClavisMessage::ERROR);
			
			//$this->UserFocus->setFocusComponent($this->ReadyForLoanBarcodeTextbox);
			$this->focusToComponent($this->ReadyForLoanBarcodeTextbox);
			
			return false;
		}

		$this->cleanMessageQueue();
		
		$clavisLibrarian = $this->getUser();
		$okCount = 0;
		$failedCount = 0;
		$okString = '';
		$failedString = '';

		/* @var $item Item */
		foreach ($readyForLoans as $row)
		{
			$item = $row['item'];
			$barcode = $item->getBarcode();
			$patron = $item->getPatron();
			
			$result = $this->_loanmanager->DoMoved2ReadyToLoanItem($item, $clavisLibrarian);
			$itemDataString = '<br />&nbsp;- ' 
								. (intval($item->getExternalLibraryId()) > 0 ? '[<b>' . Prado::localize('extra sistema') . '</b>]&nbsp;' : '')
								. $item->getTrimmedTitle(40) 
								. ($barcode == '' ? '' : ' (' . Prado::localize('barcode') . ': ' . $barcode) . ')';

			if ($result)
			{
				$okCount++;
								
				// ready-to-loan automatic notification
				if ($patron->isNonActive())
				{
					$this->enqueueMessage(Prado::localize("L'utente {patron} (per l'esemplare {item}) non possiede i diritti di prestito",
															array( 'patron' => $patron->getCompleteName(),
																	'item' => $itemDataString )),
											ClavisMessage::WARNING);	
				}
				elseif (ClavisParamQuery::getParam('CLAVISPARAM','AutoEmailLoanReady') == 'true')
				{
					$ret = NotificationHelper::sendNotificationEmail(	'readyforloan', 
																		$patron,
																		$clavisLibrarian->getLibrarian(), 
																		$item->getLibraryRelatedByActualLibraryId(),
																		array($item->getCurrentLoanId()));
					
					if ($ret)
					{
						$item->setNotifyCount($item->getNotifyCount() + 1);
						$item->save();
					
						$loan = $item->getLoanRelatedByCurrentLoanId();
						$loan->setNotifyCount($loan->getNotifyCount() + 1);
						$loan->save();
						
						$itemDataString .= Prado::localize(' - notificato automaticamente via email');
					}
				}
				
				$okString .= $itemDataString;
			}
			else
			{
				$failedCount++;
				$failedString .= $itemDataString;
			}
		}
		
		// Output messages
		if ($okCount > 0)
		{	
			$this->enqueueMessage(Prado::localize("N. {count} esemplari passati in stato 'pronto al prestito'",
													array('count' => $okCount)),
									ClavisMessage::CONFIRM);
			
			if ($okString != '')
			{
				$this->enqueueMessage(Prado::localize("Esemplari passati: {string}",
														array('string' => $okString)),
										ClavisMessage::CONFIRM);
			}	
		}

		if ($failedCount > 0)
		{
			$this->enqueueMessage(Prado::localize("N. {count} esemplari NON passati in stato 'pronto al prestito'",
													array('count' => $failedCount)),
									ClavisMessage::ERROR);
			
			if ($failedString != '')
			{
				$this->enqueueMessage(Prado::localize("Operazione di messa in 'pronto al prestito' fallita per: {string}",
														array('string' => $failedString)),
										ClavisMessage::ERROR);
			}			
		}
		
		if (($okCount + $failedCount) == 0)
		{
			$this->enqueueMessage(Prado::localize("Nessuna operazione effettuata"),
													ClavisMessage::INFO);
		}

		$this->flushMessage();

		//$this->UserFocus->setFocusComponent($this->ReadyForLoanBarcodeTextbox);
		$this->focusToComponent($this->ReadyForLoanBarcodeTextbox);

		if ($okCount > 0)
		{
			$this->InTransit->resetDataSource();
			
			if ($this->getIsCallback())
				$this->InTransitPanel->render(is_null($param) ? $writer = $this->createWriter() : $writer = $param->getNewWriter());
		}
	}

	public function onPutToShelf($sender, $param)
	{
		$input = $this->PutToShelfBarcodeTextbox->getSafeText();
		$input = trim($input);
		
		if ($input != '')
		{
			$this->PutToShelfBarcodeTextbox->setText('');
			$shelfable = $this->ToShelf->searchCodesIntoDatasource($input);
		}
		else
		{
			$shelfable = $this->ToShelf->getItemsWithDueDate();
		}

		if (count($shelfable) == 0)
		{
			$this->getPage()->writeMessage(Prado::localize('Nessun elemento da processare riconosciuto come valido'), 
											ClavisMessage::ERROR);
			
			$this->focusToComponent($this->PutToShelfBarcodeTextbox);

			return false;
		}
		else
		{
			$requestmanager = $this->getApplication()->getModule('request');
		}

		$this->cleanMessageQueue();
				
		$clavisLibrarian = $this->getUser();
		$fromLibraryId = $clavisLibrarian->getActualLibraryId();
		$okCount = 0;
		$failedCount = 0;
		$okString = '';
		$toMoveCount = 0;
		$failedString = '';
		
		/* @var $item Item */
		foreach ($shelfable as $row)
		{
			$item = $row['item'];
			$barcode = $item->getBarcode();
		
			$result = $this->_loanmanager->PutOnShelfItem($item, $clavisLibrarian);
						
			$requestCount = $requestmanager->countRequests(	$fromLibraryId,
															null,
															$item->getItemId());

			$itemDataString =	'<br />&nbsp;- ' .
								($requestCount > 0 
										? '<b>[' . Prado::localize('ESISTONO PRENOTAZIONI') . ']</b>:&nbsp;' 
										: '') .
								$item->getTrimmedTitle(40) .
								($barcode == '' ? '' : ' (' . Prado::localize('barcode') . ': ' .
								$barcode) . ')';

			if ($result == ClavisLoanManager::OK)
			{
				$okCount++;
				$okString .= $itemDataString;
			}
			elseif ($result == ClavisLoanManager::RETN_OKANDMOVE)
			{
				$okCount++;
				$toMoveCount++;
				
				$okString .= $itemDataString . '&nbsp;<b>[' . Prado::localize('messo in pronto al transito verso la biblioteca di gestione') . ']</b>&nbsp;';
			}
			else
			{
				$failedCount++;
				$failedString .= $itemDataString;
			}
		}

		// Output messages
		if ($okCount > 0)
		{	
			$this->enqueueMessage(Prado::localize("N. {count} esemplari rimessi a scaffale",
													array('count' => $okCount)),
									ClavisMessage::CONFIRM);
			
			if ($okString != '')
			{
				$this->enqueueMessage(Prado::localize("Esemplari messi a scaffale: {string}",
														array('string' => $okString)),
										ClavisMessage::CONFIRM);
			}	
		}
		
		if ($toMoveCount > 0)
		{	
			$this->enqueueMessage(Prado::localize("N. {count} esemplari messi automaticamente in pronto al transito per tornare alla loro biblioteca di gestione",
													array('count' => $toMoveCount)),
									ClavisMessage::WARNING);
		}
		
		if ($failedCount > 0)
		{
			$this->enqueueMessage(Prado::localize("N. {count} esemplari NON rimessi a scaffale",
													array('count' => $failedCount)),
									ClavisMessage::ERROR);
			
			if ($failedString != '')
			{
				$this->enqueueMessage(Prado::localize("Operazione di rimessa a scaffale fallita per: {string}",
														array('string' => $failedString)),
										ClavisMessage::ERROR);
			}			
		}
		
		if (($okCount + $failedCount + $toMoveCount) == 0)
		{
			$this->enqueueMessage(Prado::localize("Nessuna operazione effettuata"),
													ClavisMessage::INFO);
		}

		$this->flushMessage();
	
		$this->focusToComponent($this->PutToShelfBarcodeTextbox);
		
		if ($okCount > 0)
		{
			$this->ToShelf->resetDataSource();
			
			if ($this->getIsCallback())
				$this->ToShelfPanel->render(is_null($param) ? $this->createWriter() : $writer = $param->getNewWriter());
		}
	}

	public function getSelectedTabParameter($param = null)
	{
		return array('selectTab' => (!is_null($param))
										? $param
										: $this->MainTab->getActiveViewIndex());
	}

	private function focusToComponent($component = null)
	{
		if (is_null($component))
			return false;

		if ($this->getPage()->getIsCallback())
		{
			$page= $this->Application->getservice('page')->RequestedPage;
			$page->CallbackClient->callClientFunction("Prado.Element.focus", array($component->getClientID()));
		}
		else
		{
			$this->UserFocus->setFocusComponent($component);
		}
	}
	
	public function onPrintJRPInTransit($sender, $param)   // items arriving for loan
	{
		$datasource = $this->InTransit->getCheckedItemsItemId(true, true);     // all + reset
		$ids = implode(',', $datasource);	

		$this->JRPBoxInTransit->setObjectId($ids);
		$this->JRPBoxInTransit->addOptionalParam('P_ORDER', $this->InTransit->getSortingExpression());
		$this->JRPBoxInTransit->addOptionalParam('P_ORDERDIR', $this->InTransit->getSortingDirection());
		
		$this->JRPBoxInTransit->printReport();
	}
	
	public function onPrintJRPToShelf($sender, $param)  // items to put to shelf again
	{
		$datasource = $this->ToShelf->getCheckedItemsItemId(true, true);     // all + reset
		$ids = implode(',', $datasource);	

		$this->JRPBoxToShelf->setObjectId($ids);
		$this->JRPBoxToShelf->addOptionalParam('P_ORDER', $this->ToShelf->getSortingExpression());
		$this->JRPBoxToShelf->addOptionalParam('P_ORDERDIR', $this->ToShelf->getSortingDirection());
		
		$this->JRPBoxToShelf->printReport();
	}	
	
}