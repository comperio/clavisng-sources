<?php

/**
 * @author Marco Brancalion <marco@comperio.it>
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2011 Comperio SRL
 *
 */

class AddressList extends ClavisPage
{
	public $_module = 'CIRCULATION';

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallback())
		{
			$this->clearFilters();
			$this->getPage()->setFocus($this->AddrCity->getClientID());
		}

		if ($this->getPage()->getIsPostBack() || $this->getPage()->getIsCallback())
		{
			$updateSearch = $this->getApplication()->getSession()->itemAt('UpdateSearch');
			
			if (!is_null($updateSearch) && ($updateSearch == true))
			{
				$this->getApplication()->getSession()->remove('UpdateSearch');
				$this->doSearch(false);
			}
		}
	}

	public function onPreRender($param)
	{
		parent::onPreRender($param);

		$enabledModify = (count($this->List->getCheckedItemIds()) > 0);
		$this->OperationPanel->setCssClass($enabledModify
												? 'panel_on'
												: 'panel_shaded' );

		$oldEnabled = $this->OperationPanel->getEnabled();
		$this->OperationPanel->setEnabled($enabledModify);

		if (($enabledModify != $oldEnabled) && $this->getIsCallback())
			$this->OperationPanel->render($this->getPage()->createWriter());
	}

	public function populate()
	{
		$this->List->populate();
	}

	public function globalRefresh()
	{
		$this->List->resetDataSource();
	}

	public function onCleanSearch()
	{
		$this->onCancel(null, null);
	}

	public function onCancel($sender, $param)
	{
		$this->clearFilters();
		$this->doSearch();
		$this->getPage()->setFocus($this->AddrCity->getClientID());
	}

	public function clearFilters()
	{
		$this->AddressType->setSelectedIndex(0);
		$this->AddrStreetType->setSelectedIndex(0);

		$this->AddrStreet->setText('');
		$this->AddrStreetNumber->setText('');
		$this->AddrVillage->setText('');
		$this->AddrZip->setText('');
		$this->AddrCity->setText('');
		$this->AddrProvince->setText('');
		$this->AddrCountry->setText('');
		$this->AddrNote->setText('');

		$this->AddrPref->setChecked(false);
		$this->onResetPatron(null, null);
	}

	public function onSearch($sender, $param)
	{
		$this->doSearch();
	}

	public function doSearch($resetPagination = true)
	{
		$addressType = $this->AddressType->getSelectedValue();
		if ($addressType == '0')
			$addressType = null;
		$addrStreetType = $this->AddrStreetType->getSelectedValue();
		if ($addrStreetType == '0')
			$addrStreetType = null;

		$addrStreet = trim($this->	AddrStreet->getSafeText());
		$addrStreetNumber = trim($this->AddrStreetNumber->getSafeText());
		$addrVillage = trim($this->AddrVillage->getSafeText());
		$addrZip = trim($this->AddrZip->getSafeText());
		$addrCity = trim($this->AddrCity->getSafeText());
		$addrProvince = trim($this->AddrProvince->getSafeText());
		$addrCountry = trim($this->AddrCountry->getSafeText());
		$addrNote = trim($this->AddrNote->getSafeText());
		$addrPref = $this->AddrPref->getChecked();
		$patronId = intval($this->PatronId->getValue());

		$this->List->setFilters($addressType,
								$addrStreetType,
								$addrStreet,
								$addrStreetNumber,
								$addrVillage,
								$addrZip,
								$addrCity,
								$addrProvince,
								$addrCountry,
								$addrNote,
								$addrPref,
								$patronId );

		$this->List->resetDataSource(true, $resetPagination);
	}

 	/**
 	 * It updates the page in case a new patron is choosen.
 	 *
 	 * @param TControl $sender
 	 * @param TEventParameter $param
 	 */
 	public function onPatronIdChanged($sender, $param)
 	{
 		$patron = null;
 		$id = intval($this->PatronId->getValue());
 		if ($id > 0)
 			$patron = PatronPeer::retrieveByPK($id);
 		if ($patron instanceof Patron)
 		{
 			$completeName = $patron->getCompleteName();
 			$barcode = trim($patron->getBarcode());
 			if ($barcode != '')
 				$barcode = ' (' . $barcode . ')';

 			$this->PatronLabel->setText($completeName . $barcode);
 			$this->setPatronChoiceDone(true, $param);
 		}
 	}

	public function onResetPatron($sender, $param)
	{
		$this->HiddenLabel->setValue('');
		$this->PatronId->setValue('');
 		$this->PatronLabel->setText('');
 		$this->setPatronChoiceDone(false, $param);
	}

 	public function setPatronChoiceDone($flag, $param)
 	{
		$this->PatronLabel->setVisible($flag);
		$this->PatronChoiceButton->setVisible(!$flag);
		$this->PatronResetButton->setVisible($flag);

		if ($this->getPage()->getIsCallback())
		{
			if (is_null($param))
				$newWriter = $this->getPage()->createWriter();
			else
				$newWriter = $param->getNewWriter();

			$this->PatronPanel->render($newWriter);
		}
 	}

	public function onModify($sender, $param)
	{
		$idsArray = $this->List->getCheckedItemIds();
		if (count($idsArray) == 0)
		{
			$this->writeMessage(Prado::localize("Non sono state selezionate righe"), ClavisMessage::WARNING);
			return false;
		}

		$this->cleanMessageQueue();
		
		$addrZip = trim($this->AddrZipMod->getSafeText());
		$addrCity = trim($this->AddrCityMod->getSafeText());
		$addrProvince = trim($this->AddrProvinceMod->getSafeText());
		$addrCountry = trim($this->AddrCountryMod->getSafeText());
		
		$defaultCountry = ClavisParamQuery::getParam("CLAVISPARAM","DefaultAddressCountry");

		$isDefaultCountry = ($addrCountry == $defaultCountry);

		if ($addrZip . $addrCity . $addrProvince . $addrCountry == "")
		{
			$this->writeMessage(Prado::localize("Non è stato inserito alcunché nei campi per nuove modifiche"), ClavisMessage::WARNING);
			return false;
		}
		

		if( ! LookupValueQuery::zipExists( $addrZip) && $isDefaultCountry )
		{
			$this->writeMessage(Prado::localize("CAP non valido"), ClavisMessage::ERROR);
			return FALSE;
		}

		if( ! LookupValueQuery::checkAddressDep( $addrProvince, $addrCity, $addrZip) && $isDefaultCountry )
		{
			$this->writeMessage(Prado::localize("CAP, comune o provincia non coerenti"), ClavisMessage::ERROR);
			return FALSE;
		}

		
		
		if( ! LookupValueQuery::cityExists( $addrCity) && $isDefaultCountry )
		{
			$this->writeMessage(Prado::localize("Comune non valido"), ClavisMessage::ERROR);
			return FALSE;
		}
		
		if( ! LookupValueQuery::provinceExists( $addrProvince)  && $isDefaultCountry )
		{
			$this->writeMessage(Prado::localize("Provincia non valida"), ClavisMessage::ERROR);
			return FALSE;
		}
		
		if( ! LookupValueQuery::countryExists( $addrCountry) )
		{
			$this->writeMessage(Prado::localize("Nazione non valida"), ClavisMessage::ERROR);
			return FALSE;
		}
		

		$ok = 0;
		$failed = 0;
		
		/** @var $address Address */
		foreach ($idsArray as $addressId)
		{
			$address = AddressPeer::retrieveByPk($addressId);
			if ($address instanceof Address)
			{
				try
				{
					if ($addrZip != "")
						$address->setZip($addrZip);
					
					if ($addrCity != "")
						$address->setCity($addrCity);

					if ($addrProvince != "")
						$address->setProvince($addrProvince);

					if ($addrCountry != "")
						$address->setCountry($addrCountry);
					
					$address->save();
					unset ($address);
					$ok++;
				}
				catch (Exception $e)
				{
					$failed++;
				}
			}
			else
				$failed++;
		}

		if ($ok + $failed == 0)
		{
			$this->getPage()->enqueueMessage(Prado::localize("Nessuna modifica effettuata"),
											ClavisMessage::WARNING);
		}
		else
		{
			if ($ok > 0)
			{
				$this->enqueueMessage((1 == $ok)
						? Prado::localize('1 indirizzo modificato')
						: Prado::localize('{count} indirizzi modificati',array('count'=>$ok)),
					ClavisMessage::CONFIRM);
				$this->List->populate();
			}

			if ($failed > 0)
				$this->enqueueMessage((1 == $failed)
						? Prado::localize('1 modifica fallita')
						: Prado::localize('{count} modifiche fallite',array('count'=>$failed)),
					ClavisMessage::WARNING);
		}
		
		$this->flushMessage();
	}
	
	
	private function setAddressSuggestion($ds = array())
	{
		$this->getApplication()->getSession()->add('PatronBirthCityDataSource', $ds, array());
	}

	private function getAddressSuggestion()
	{
		return $this->getApplication()->getSession()->itemAt('PatronBirthCityDataSource', array());
	}
	
	
	public function suggestCity($sender, $param)
	{
		$text = $sender->getText();
		$token = $param->getCallbackParameter();
		$ds = LookupValueQuery::getSuggestCity($token);
		
		if (count($ds) > 0)
		{
			$sender->setDataSource($ds);
			$sender->dataBind();
			$this->setAddressSuggestion($ds);
			$sender->setText($text);
		}
	}

	public function selectCity($sender, $param)
	{
		$defaultCountry = ClavisParamQuery::getParam("CLAVISPARAM","DefaultAddressCountry");
		//$itemIndex = $sender->Parent->getItemIndex();
		//$items = $this->AddressList->getItems();
		//$item = $items->itemAt($itemIndex);

		$index = $param->selectedIndex;
		$sender->setText('');

		$ds = $this->getAddressSuggestion();
		$this->setAddressSuggestion(array());

		if (array_key_exists($index, $ds))
		{
			$row = $ds[$index];
			$this->AddrZipMod->setText("");
			$this->AddrCityMod->setText($row['text']);
			$this->AddrProvinceMod->setText($row['prov']);
			$this->AddrCountryMod->setText($defaultCountry);
			//Prado::log(__METHOD__ . " def country {$defaultCountry}");
		}
	}

	public function suggestZip($sender, $param)
	{
		$text = $sender->getText();
		$token = $param->getCallbackParameter();
		//$ds = PatronPeer::doSuggestAddress($token, AddressPeer::ZIP);
		$ds = LookupValueQuery::getSuggestZip($token);

		if (count($ds) > 0)
		{
			$sender->setDataSource($ds);
			$sender->dataBind();
			$this->setAddressSuggestion($ds);
			$sender->setText($text);
		}
	}

	public function selectZip($sender, $param)
	{
		$defaultCountry = ClavisParamQuery::getParam("CLAVISPARAM","DefaultAddressCountry");

		$index = $param->selectedIndex;
		$sender->setText('');

		$ds = $this->getAddressSuggestion();
		$this->setAddressSuggestion(array());

		if (array_key_exists($index, $ds))
		{
			$row = $ds[$index];
			//$array = $row['array'];
			
			$this->AddrZipMod->setText($row['text']);
			$this->AddrCityMod->setText($row['city']);
			$this->AddrProvinceMod->setText($row['prov']);
			$this->AddrCountryMod->setText($defaultCountry);
			/*
			$zip = trim($array[0]);
			$province = trim($array[1]);
			$country = trim($array[2]);

			if ($zip != '')
				$this->AddrZipMod->setText($zip);

			if ($province != '')
				$this->AddrProvinceMod->setText($province);

			if ($country != '')
				$this->AddrCountryMod->setText($country);*/
		}
	}

	public function suggestProvince($sender, $param)
	{
		$text = $sender->getText();
		$token = $param->getCallbackParameter();
		$ds = LookupValueQuery::getSuggestProvince($token);

		if (count($ds) > 0)
		{
			$sender->setDataSource($ds);
			$sender->dataBind();
			$this->setAddressSuggestion($ds);
			$sender->setText($text);
		}
	}

	public function selectProvince($sender, $param)
	{
		$defaultCountry = ClavisParamQuery::getParam("CLAVISPARAM","DefaultAddressCountry");
		//$itemIndex = $sender->Parent->getItemIndex();
		//$items = $this->AddressList->getItems();
		//$item = $items->itemAt($itemIndex);

		$index = $param->selectedIndex;
		$sender->setText('');

		$ds = $this->getAddressSuggestion();
		$this->setAddressSuggestion(array());

		if (array_key_exists($index, $ds))
		{
			$row = $ds[$index];
			$this->AddrZipMod->setText("");
			$this->AddrCityMod->setText("");
			$this->AddrProvinceMod->setText($row['text']);
			$this->AddrCountryMod->setText($defaultCountry);
			//Prado::log(__METHOD__ . " def country {$defaultCountry}");
		}
	}

	public function suggestCountry($sender, $param)
	{
		$text = $sender->getText();
		$token = $param->getCallbackParameter();
		$ds = LookupValueQuery::getSuggestCountry($token);

		if (count($ds) > 0)
		{
			$sender->setDataSource($ds);
			$sender->dataBind();
			$this->setAddressSuggestion($ds);
			$sender->setText($text);
		}
	}

	public function selectCountry($sender, $param)
	{
		//$itemIndex = $sender->Parent->getItemIndex();
		//$items = $this->AddressList->getItems();
		//$item = $items->itemAt($itemIndex);

		$index = $param->selectedIndex;
		$sender->setText('');

		$ds = $this->getAddressSuggestion();
		$this->setAddressSuggestion(array());

		if (array_key_exists($index, $ds))
		{
			$row = $ds[$index];
			$this->AddrZipMod->setText("");
			$this->AddrCityMod->setText("");
			$this->AddrProvinceMod->setText("");
			$this->AddrCountryMod->setText($row['text']);
		}
	}

}
