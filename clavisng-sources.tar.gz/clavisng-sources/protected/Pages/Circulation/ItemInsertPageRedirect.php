<?php

/**
 * @author Marco Brancalion <mbrancalion@e-portaltech.it>
 * @link http://www.e-portaltech.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @license http://www.e-portaltech.it/license/
 *
 * This page redirects to Catalog.ItemInsertPage, so that
 * we can edit a new "out of catalog" item.
 *
 */
class ItemInsertPageRedirect extends ClavisPage
{
	public $_module = "CIRCULATION";
	public $_pageName = "ItemInsertPage";

	public function onLoad($param)
	{
		parent::onLoad($param);

		$this->gotoPage('Catalog.ItemInsertPage');
	}
}