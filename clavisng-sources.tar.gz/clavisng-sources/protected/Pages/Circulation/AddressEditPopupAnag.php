<?php
/**
 * AddressEditPopupAnag class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Popups.Circulation
 */

/**
 * AddressEditPopupAnag
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.7
 * @package Popups.Circulation
 * @since 2.4
 */
class AddressEditPopupAnag extends ClavisPagePopup
{
	public $_module = 'CIRCULATION';
	
	public function onInit($param)
	{
		parent::onInit($param);
	
		if (!$this->getIsPostBack() )
		{
		   $id = intval($this->getRequest()->itemAt('param'));
			if ($id > 0)
				$this->setPatronId($id);
		}
	}

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsPostBack())
			$this->populate();
	}

	public function setPatronId($id = null)
	{
		$this->setViewState('PatronId', $id, null);
	}

	public function getPatronId()
	{
		return $this->getViewState('PatronId', null);
	}

	public function getPatron()
	{
		$patron = null;
		$patronId = intval($this->getPatronId());
		if ($patronId > 0)
			$patron = PatronPeer::retrieveByPK($patronId);

		return $patron;
	}

	public function onCancel($sender, $param)
	{

	}

	public function checkTrimmed(Patron $patron)
	{
		$v = $patron->getBirthCity();
		if (strlen(trim($v)) != $v)
			$patron->setBirthCity(trim($v));
		$v = $patron->getBirthProvince();
		if (strlen(trim($v)) != $v)
			$patron->setBirthProvince(trim($v));
		$v = $patron->getBirthCountry();
		if (strlen(trim($v)) != $v)
			$patron->setBirthCountry(trim($v));
		$v = $patron->getCitizenship();
		if (strlen(trim($v)) != $v)
			$patron->setCitizenship(trim($v));
		if ($patron->isModified()) {
			$patron->save();
			$patron->reload();
		}
	}

	public function populate()
	{
		/** @var $patron Patron */
		$patron = $this->getPatron();
		if (!$patron instanceof Patron)
			return false;

		$this->checkTrimmed($patron);
		$patronId = $patron->getPatronId();

		if (($birthCity = $patron->getBirthCity()) != '')
			$this->BirthCity->setText($birthCity);

		$birthProvince = $patron->getBirthProvince();
		if ($birthProvince != '')
			$this->BirthProvince->setText($birthProvince);

		$birthCountry = $patron->getBirthCountry();
		if ($birthCountry != '')
			$this->BirthCountry->setText($birthCountry);

		$citizenship = $patron->getCitizenship();
		if ($citizenship != '')
			$this->Citizenship->setText($citizenship);

		$patronNote = $patron->getPatronNote();
		if ($patronNote != '')
			$this->PatronNote->setText($patronNote);

		$patronName = trim($patron->getReverseCompleteName());
		if ($patronName != '')
				$patronName = "<a href='" . $patron->getNavigateUrl() . $patronId . "' target='parent'>" . $patronName . "</a>";
		$patronName .= '&nbsp;(' . Prado::localize("id") . ':&nbsp;' . $patronId . ')';
		$this->Patron->setText($patronName);
	}

	public function onSave($sender, $param)
	{
		$this->doSave();
	}

	private function doSave()
	{
		$patron = $this->getPatron();
		if (!($patron instanceof Patron))
		{
			$this->writeMessage(Prado::localize("L'indirizzo anagrafico da salvare non è stato memorizzato nella finestra di popup."), ClavisMessage::ERROR);
			return false;
		}

		$patron->setBirthCity(trim($this->BirthCity->getSafeText()));
		$patron->setBirthProvince(trim($this->BirthProvince->getSafeText()));
		$patron->setBirthCountry(trim($this->BirthCountry->getSafeText()));
		$patron->setCitizenship(trim($this->Citizenship->getSafeText()));
		$patron->setPatronNote(trim($this->PatronNote->getSafeText()));

		$affectedRows = $patron->save();
		if ($affectedRows > 0)
		{
			ChangelogPeer::logAction($patron, ChangelogPeer::LOG_UPDATE, $this->getUser(),
						Prado::localize("Modificato manualmente l'indirizzo anagrafico dell'utente '{name}', record_id: {id}",
											array('name' => $patron->getCompleteName(),
													'id' => $patron->getPatronId())));

			$this->getPage()->writeDelayedMessage(Prado::localize("Modificato manualmente l'indirizzo anagrafico dell'utente '{name}', record_id: {id}",
											array('name' => $patron->getCompleteName(),
													'id' => $patron->getPatronId())),
									ClavisMessage::CONFIRM);

			$this->getApplication()->getSession()->add('UpdateSearch', true);
		}
		else
		{
			$this->getPage()->writeDelayedMessage(Prado::localize("Nessuna modifica manuale dell'indirizzo anagrafico dell'utente con id: {id}",
											array('id' => $patron->getPatronId())),
									ClavisMessage::ERROR);
		}
		// chiusura popup
		$this->getPage()->getClientScript()->registerEndScript(__CLASS__.'_js','onReturn(\'\',\'\',true);');
	}

	public function globalRefresh()
	{
		$this->populate();
	}

	public function isUnlink()
	{
		return false;
	}
	
}
