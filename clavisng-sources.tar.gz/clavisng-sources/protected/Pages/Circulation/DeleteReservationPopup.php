<?php
/**
 * DeleteReservationPopup class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 ePortal Technologies
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Pages.Catalog
 */

/**
 * DeleteReservationPopup Class
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.7
 * @package Popups.Circulation
 * @since 2.1
 */
class DeleteReservationPopup extends ClavisPagePopup
{
	private $_itemRequestId;
	public $_llibraryActive;
	public $_requestTypeActive;
	
	public $_module = 'CIRCULATION';

	private function initVars()
	{
		$this->_llibraryActive = (ClavisParamPeer::getParam('LLIBRARY_ACTIVE') == 1);
		$this->_requestTypeActive = ItemRequestPeer::isRequestType();
	}

	public function onInit($param)
	{
		parent::onInit($param);
		
		$this->initVars();
	}
	
	public function onLoad($param) 
	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallBack()) 
		{
			$itemRequestId = intval($this->getRequest()->itemAt('param'));
			$this->setItemRequestId($itemRequestId);
			$this->populate();
			$this->MailCheck->setChecked(true);
		}
	}

	public function setItemRequestId($itemRequestId) 
	{
		$this->_itemRequestId = $itemRequestId;
		$this->setViewState("ItemRequestId", $itemRequestId, null);
	}

	public function getItemRequestId() 
	{
		$this->_itemRequestId = $this->getViewState("ItemRequestId", null);
		
		return $this->_itemRequestId;
	}

	private function getItemRequest()
	{
		$itemRequest = ItemRequestQuery::create()
						->findPk(intval($this->getItemRequestId()));
		
		if ($itemRequest instanceof ItemRequest)
		{
			return $itemRequest;
		}
		else
		{
			return null;
		}
	}
	
	public function populate() 
	{
		$maxDistanceVisibility = $this->_llibraryActive;
		$okFlag = false;
		$itemRequest = $this->getItemRequest();

		if ($itemRequest instanceof ItemRequest) 
		{
			$okFlag = true;
			$itemRequestObject = $itemRequest->getItemRequestObject();
			$objectString = '';

			if ($itemRequestObject instanceof Item)
			{
				$objectString = ' ' . Prado::localize('di un esemplare');
			}
			elseif ($itemRequestObject instanceof Issue)
			{
				$objectString = ' ' . Prado::localize('di un fascicolo');
			}
			elseif ($itemRequestObject instanceof Manifestation)
			{
				$objectString = ' ' . Prado::localize('di una notizia');
			}
			else 
			{
				$objectString = ' ' . Prado::localize('INCONGRUENTE, con request id: ') . $itemRequest->getRequestId();
				$okFlag = false;
				$this->writeMessage(Prado::localize("La prenotazione si riferisce ad un oggetto che non esiste più: "), 
										ClavisMessage::ERROR);
			}

			$this->ObjectString->setText($objectString);

			if (!$okFlag)
				return;  // the object_id in the item_requests points to a non-existent object

			$title = $itemRequestObject->getCompleteTitle();
			$itemRequestObjectNavigateUrl = $itemRequestObject->getNavigateUrl() . $itemRequestObject->getId();

			if ($itemRequestObject instanceof Item) 
			{
				$this->ItemDataPanel->setVisible(true);
				$collocation = $itemRequestObject->getCollocationCombo(Prado::getApplication()->getUser()->getActualLibraryId());
				$inventoryNumber = $itemRequestObject->getCompleteInventoryNumber();
				$homeLibraryId = $itemRequestObject->getHomeLibraryId();
				$homeLibraryText = $itemRequestObject->getHomeLibraryLabel();

				$this->Collocation->setText($collocation);
				$this->InventoryNumber->setText($inventoryNumber);
				$this->HomeLibrary->setText($homeLibraryText);
				$this->HomeLibrary->setNavigateUrl(LibraryPeer::getNavigateUrl($homeLibraryId));
				
				$maxDistanceVisibility = false;
			}
			else
			{
				$this->ItemDataPanel->setVisible(false);
			}

			$this->Title->setText($title);
			$this->Title->setNavigateUrl($itemRequestObjectNavigateUrl);
				
			$patronId = $itemRequest->getPatronId();
			$toolTip = '';
			$patron = $itemRequest->getPatron();

			if ($patron instanceof Patron)
			{
				$patronCompleteName = $patron->getCompleteName();
				$navigateUrl = PatronPeer::getNavigateUrl($patronId);
			}
			else
			{
				$maxDistanceVisibility = false;
				$externalLibraryId = intval($itemRequest->getExternalLibraryId());
				$externalLibrary = LibraryPeer::retrieveByPK($externalLibraryId);

				if ($externalLibrary instanceof Library)
				{
					$patronCompleteName = $externalLibrary->getLabel(true, false, true, 30);
					$navigateUrl = LibraryPeer::getNavigateUrl($externalLibrary->getLibraryId());
					$toolTip = $externalLibrary->getTrimmedDescription(100) . ' (' .
									Prado::localize('consorzio') . ": ". $externalLibrary->getConsortiaString(100) . ')';
				}
				else
				{
					$patronCompleteName = "(" . Prado::localize("senza nome") . ")";
					$navigateUrl = '';
				}
			}

			$this->Patron->setText($patronCompleteName);
			$this->Patron->setNavigateUrl($navigateUrl);
			$this->Patron->setToolTip($toolTip);
					
			$this->RequestDate->setValue($itemRequest->getRequestDate('U'));
			$this->ExpireDate->setValue($itemRequest->getExpireDate('U'));
			
			$requester = ($itemRequest->getCreatedBy() == 1)
								? $itemRequest->getPatronCompleteName() . Prado::localize(' (via OPAC)')
								: $itemRequest->getModifiedByNameString();
			
			$this->RequesterCompleteName->setText($requester);
		
			$this->DeliveryLibrary->setText($itemRequest->getDeliveryLibraryLabel());
			$this->DeliveryLibrary->setNavigateUrl(LibraryPeer::getNavigateUrl($itemRequest->getDeliveryLibraryId()));

			if ($maxDistanceVisibility)
			{
				$this->MaxDistancePanel->setCssClass('panel_on');
				$this->MaxDistance->setText($itemRequest->getCompleteMaxDistance());
			}
			else
			{
				$this->MaxDistancePanel->setCssClass('panel_off');
			}
			
			if ($this->_requestTypeActive)
			{
				$this->RequestTypePanel->setVisible(true);
				$this->RequestType->setText(ItemRequestPeer::getRequestTypeString($itemRequest->getRequestType()));
			}
			else
			{
				$this->RequestTypePanel->setVisible(false);
			}
		}

		if (!$okFlag) 
		{
			$this->Title->setText('');
			$this->writeMessage(Prado::localize("Il parametro non è stato passato al popup. Riportare al fornitore del software"), 
									ClavisMessage::ERROR);
		}
	}

	public function onDeleteItemRequest($sender, $param) 
	{
		$this->cleanMessageQueue();
		$request = ItemRequestQuery::create()->findPk($this->getItemRequestId());
		
		if ($request instanceof ItemRequest)
		{
			try
			{
				$this->getApplication()->getModule('request')->doNullRequest(	$request,
																				$this->getUser(),
																				trim($this->AbortDescription->getSafeText()));
				
				$this->getApplication()->getSession()->add('UpdateItemRequests', true);
				
				$this->enqueueMessage(Prado::localize("Prenotazione cancellata per l'utente {user}, con titolo '{title}'",
															array(	'user' => $request->getPatronCompleteName(),
																	'title' => $request->getTrimmedTitle(100) )),
										ClavisMessage::INFO);
				
				if ($this->MailCheck->getChecked())
				{
					try
					{
						$emailSent = $this->sendEmail(	$request,
														trim($this->AbortDescription->getSafeText()));
						
						$this->enqueueMessage(Prado::localize("Spedita email informativa all'indirizzo '{address}'",
																	array('address' => $emailSent)),
												ClavisMessage::INFO);
					}
					catch (Exception $e)
					{
						$this->enqueueMessage(Prado::localize("Errore nella spedizione della mail: {error}",
																	array('error' => $e->getMessage())),
												ClavisMessage::WARNING);
					}
				}
			}
			catch (Exception $e)
			{
				$this->enqueueMessage(Prado::localize("Errore nella cancellazione"),
											ClavisMessage::ERROR);
			}
		}

		// close popup
		$this->flushDelayedMessage();
		$this->getPage()->getClientScript()->registerEndScript(__CLASS__ . '_js', 'onReturn(\'\',\'\',true);');
	}

	public function isUnlink() 
	{
		return false;
	}

	private function sendEmail($request = null, $description)
	{
		if ($request instanceof ItemRequest) 
		{
			$myLibrary = $this->getUser()->getActualLibrary();
			$myConsortiumString = $myLibrary->getConsortiaString();
			$myLibraryId = $this->getUser()->getActualLibraryId();
			$external = false;
			$notificationManager = $this->getApplication()->getModule('notification');
			$userEmail = '';

			$item = $request->getItem();
			$manifestation = $request->getManifestation();
			
			if ($item instanceof Item) 
			{
				$object = Prado::localize('titolo: {title}', array('title' => $item->getTitle())) . "\n"
								. Prado::localize('inventario: {inv}', array('inv' => $item->getCompleteInventoryNumber())) . "\n"
								. Prado::localize('collocazione: {coll}', array('coll' => $item->getCollocation()));
			} 
			elseif ($manifestation instanceof Manifestation) 
			{
				$object = Prado::localize('titolo: {title}', array('title' => $manifestation->getTitle()));
			} 
			else 
			{
				throw new Exception('cannot find a valid Item or Manifestation for this request.');
			}

			$patron = $request->getPatron();
			$externalLibrary = $request->getExternalLibrary();
			
			if ($patron instanceof Patron) 
			{
				$userEmail = $patron->getEmail();
			} 
			elseif ($externalLibrary instanceof Library) 
			{
				$external = true;
				$userEmail = array($externalLibrary->getEmail());
			}

			if ($description != '')
				$description = Prado::localize("con la seguente motivazione") . ":\n" . $description . "\n";

			if ($external) 
			{
				$class = get_class($externalLibrary);
				$receiverId = $externalLibrary->getLibraryId();

				$template = DocumentTemplatePeer::getTemplate('NULL_REQUEST_EXTERNALLIBRARY',
					$this->getApplication()->getGlobalization()->getCulture(), $myLibraryId);
				
				if (!$template instanceof DocumentTemplate)
					throw new Exception('mail template NULL_REQUEST_EXTERNALLIBRARY not found');
				
				$homeLibraryLabel = '';
				$consortium = '';
				
				if ($item instanceof Item) 
				{
					$homeLibrary = $item->getHomeLibrary();
					
					if ($homeLibrary instanceof Library) 
					{
						$homeLibraryLabel = trim($item->getHomeLibraryLabel());
						
						if ($homeLibraryLabel != '')
							$homeLibraryLabel = Prado::localize('biblioteca') . ': ' . $homeLibraryLabel;

						$consortium = $homeLibrary->getConsortiaString();
						
						if ($consortium != '')
							$consortium = Prado::localize('consorzio') . ': ' . $consortium;
					}
				}

				$arr_alias = array(	'OBJECT' => $object,
									'LIBLABEL' => $homeLibraryLabel,
									'CONSORTIUM' => $consortium,
									'MOTIVATION' => $description,
									'LIBRARY' => $myLibrary->getLabel(),
									'LIBRARY_CODE' => $myLibrary->getLibraryCode(),
									'LIBRARY_DESCRIPTION' => $myLibrary->getDescription(),
									'LIBRARY_CITY' => $myLibrary->getCity(),
									'LIBRARY_ADDRESS' => $myLibrary->getAddress(),
									'LIBRARY_PHONE' => $myLibrary->getPhone(),
									'LIBRARY_FAX' => $myLibrary->getFax(),
									'LIBRARY_EMAIL' => $myLibrary->getEmail());
			}
			else 
			{
				$class = get_class($patron);
				$receiverId = $patron->getPatronId();

				$template = DocumentTemplatePeer::getTemplate(	'NULL_REQUEST_PATRON',
																$this->getApplication()->getGlobalization()->getCulture(), 
																$myLibraryId);
				
				if (!$template instanceof DocumentTemplate)
					throw new Exception('mail template NULL_REQUEST_PATRON not found');

				$homeLibraryLabel = '';
				
				if ($item instanceof Item) 
				{
					$homeLibrary = $item->getHomeLibrary();
					
					if ($homeLibrary instanceof Library)
					{
						$homeLibraryLabel = $item->getHomeLibraryLabel();
						
						if ($homeLibraryLabel != '')
							$homeLibraryLabel = Prado::localize('biblioteca') . ': ' . $homeLibraryLabel;
					}
				}

				$arr_alias = array(	'OBJECT' => $object,
									'LIBLABEL' => $homeLibraryLabel,
									'PATRON_NAME' => $patron->getName(),
									'PATRON_LASTNAME' => $patron->getLastname(),
									'PATRON_BARCODE' => $patron->getBarcode(),
									'MOTIVATION' => $description,
									'LIBRARY' => $myLibrary->getLabel(),
									'LIBRARY_CODE' => $myLibrary->getLibraryCode(),
									'LIBRARY_DESCRIPTION' => $myLibrary->getDescription(),
									'LIBRARY_CITY' => $myLibrary->getCity(),
									'LIBRARY_ADDRESS' => $myLibrary->getAddress(),
									'LIBRARY_PHONE' => $myLibrary->getPhone(),
									'LIBRARY_FAX' => $myLibrary->getFax(),
									'LIBRARY_EMAIL' => $myLibrary->getEmail());
			}

			$mailData = array();
			$mailData['to'] = $userEmail;
			$mailData['bcc'] = array();
			$mailData['cc'] = array();
			$mailData['body'] = '';
			$mailData['subject'] = "[$myConsortiumString]: " . $template->getTemplateSubject();

			$mailData['from'] = array(	'name' => $myLibrary->getLabel(),
										'email' => $myLibrary->getEmail());

			$notificationData = array(	'sender_library_id' => $myLibraryId,
										'receiver_class' => $class,
										'receiver_id' => $receiverId,
										'description' => Prado::localize("Annullamento prenotazione"),
										'notification_class'=>'L',
										'notes' => array());

			// don't try/catch here, let the Exception propagate to caller.
			$ret = $notificationManager->DoEmailReport(	$template->getTemplateBody(), 
														$arr_alias, 
														$mailData, 
														NotificationManager::EMAIL_AUTO, 
														$notificationData);
			if ($ret === true)
				$success = implode(',', $userEmail);
		}
		
		return $success;
	}

}