<?php

/**
 *
 * PropertyPopup class
 *
 * @author Max Pigozzi
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.e-portaltech.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @license http://www.e-portaltech.it/license/
 */

class PropertyPopup extends ClavisPagePopup
{
	protected $_object;
	protected $_id;
	protected $_datasource;

	public $_module = "CIRCULATION";
	
	public function onInit($param)
	{
		parent::onInit($param);

		if (!$this->getPage()->getIsPostBack())
		{
			$this->setStoredDataSource(array());
			$this->setObject(null);
			$this->setId(null);
			
			$object = null;

			$id = intval($this->getRequest()->itemAt('id'));
			$objectType = $this->getRequest()->itemAt('object');

			$this->setId($id);
			
			if ($id > 0)
			{
				switch ($objectType)
				{
					case 'patron':
						$object = PatronQuery::create()->findPk($id);
						$objectClass = 'patron';
						
						break;
					
					case 'library':
						$object = LibraryQuery::create()->findPk($id);
						$objectClass = 'library';
						
						break;

					default:
						$object = null;
						$objectClass = null;
				}
				
				$this->setObject($object);
				$this->setObjectClass($objectClass);
			}
		}
	}
			
	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsPostBack())
		{
			$object = $this->getObject();
			
			if (!is_null($object))
			{
				$this->populate();
				$this->ErrorLabel->setVisible(false);
				$this->NewPropertyButton->setVisible(true);
			}
			else
			{
				$this->ErrorLabel->setVisible(true);
				$this->NewPropertyButton->setVisible(false);
				
				$this->getPage()->writeMessage(Prado::localize("Errore sul passaggio di parametri relativo all'oggetto"),
												ClavisMessage::ERROR);
			}
		}
	}
	
	public function onPreRender($param)
	{
		parent::onPreRender($param);
			
		//var_dump($this->Attribute->getDataSource());die;
		
		
	}
	
	public function onChangePage($sender, $param)
	{
		$this->PropertyGrid->setCurrentPage($param->NewPageIndex);
		
		$this->populate();
	}
	
	public function populate()
	{
		$pageSize = $this->PropertyGrid->getPageSize();
		$currentIndexPage = $this->PropertyGrid->getCurrentPage();

		$object = $this->getObject();
		$id = $this->getId();
		$objectClass = $this->getObjectClass();

		switch ($objectClass)
		{
			case 'patron':
				$query = PatronPropertyQuery::create()
							->filterByPatronId($id);
				
				break;

			case 'library':
				$query = LibraryPropertyQuery::create()
							->filterByLibraryId($id);
				
				break;
			
			default:
				$this->getPage()->writeMessage(Prado::localize("Errore sul passaggio di parametri relativo all'oggetto"),
												ClavisMessage::ERROR);
				
				return;
		}

		$recCount = $query->count();

		$query->orderByPropertyClass(Criteria::ASC);
				
		if ($pageSize > 0)
		{
			$query->limit($pageSize)
					->offset($currentIndexPage * $pageSize);
		}

		$properties = $query->find();
		
		$this->_datasource = array();
		
		/* @var $property PatronProperty */
		foreach ($properties as $property)     
		{
			$p = array();
			
			$p['PropertyKey'] = $property->getPropertyClass();
			
			switch ($objectClass)
			{
				case 'patron':
					$propertyLabel = LookupValuePeer::getLookupValue("PATRONPROPERTY", $property->getPropertyClass());
					
					break;
				
				case 'library':
					$propertyLabel = LookupValuePeer::getLookupValue("LIBRARYPROPERTY", $property->getPropertyClass());
					
					break;
				
				default:
					$propertyLabel = "--";
			}
			
			$p['PropertyLabel'] = $propertyLabel;

			$p['PropertyValue'] = $property->getPropertyValue();
			
			switch ($objectClass)
			{
				case 'patron':
					$p['id'] = $property->getId();
					break;
				
				case 'library':
					$p['id'] = $property->getLibraryPropertyId();
					
					break;
				
				default:
					$p['id'] = null;

			}

			$this->_datasource[] = $p;
		}

		if ($pageSize > 0)
			$this->PropertyGrid->setVirtualItemCount($recCount);
		
		$this->FoundNumber->setText($recCount);
		$this->PropertyGrid->setDataSource($this->_datasource);
		$this->PropertyGrid->dataBind();
		
		$this->setStoredDataSource($this->_datasource);
	}
	
	public function onCreateNewProperty($sender, $param)
	{
		$this->getPage()->globalEditCancel();
		$this->NewPropertyButton->setVisible(false);
		
		$this->_datasource = $this->getStoredDataSource();
		$this->setNewItem(true);
		
		$newRow = array();
		$newRow['id'] = -1;
		
		switch ($this->getObjectClass())
		{
			case 'patron':
				$allValues = LookupValuePeer::getLookupClassValues("PATRONPROPERTY");
				
				break;
			
			case 'library':
				$allValues = LookupValuePeer::getLookupClassValues("LIBRARYPROPERTY");
				
				break;
			
			default:
				$allValues = array();
		}
		
		reset($allValues);
		$first = each($allValues); 
		$newRow['PropertyKey'] = $first['key'];
		$newRow['PropertyLabel'] = $first['value'];
		$newRow['PropertyValue'] = "";
		$this->_datasource = array_merge(array($newRow), $this->_datasource);

		//$this->populate();
		$this->PropertyGrid->setEditItemIndex(0);
		$this->PropertyGrid->setDataSource($this->_datasource);
		$this->PropertyGrid->dataBind();
	}
	
	private function renderAttributeList($control)
	{
		$dbClass = $this->getObjectClass() == 'patron' 
											? 'PATRONPROPERTY'
											: ($this->getObjectClass() == 'library'
																	? 'LIBRARYPROPERTY'
																	: '');
		
		$datasource = LookupValuePeer::getLookupClassValues(	$dbClass,
																null,
																null,
																null,
																true);	// sorted

		foreach ($datasource as $ind => $el)
		{
			if (strtoupper(substr($ind, 0, 1)) == 'X')
				$datasource[$ind] = "$el ($ind)";
		}

		$control->setDataSource($datasource);
		$control->dataBind();
	}
	
	public function itemDataBound($sender, $param) 
	{
		$item = $param->Item;
		
		if ($item->ItemType == "EditItem") 
		{
			$item->setStyle('background-color: #DDDDFF;');
			
			if ($this->getNewItem()) 
			{
				$item->Cells[0]->attributeNewPanel->setVisible(true);
				$item->Cells[0]->attributeEditPanel->setVisible(false);
				
				//if (is_null($item->Cells[0]->Controls[1]->Controls[1]->DataSource)) 
				//	$item->Cells[0]->Controls[1]->Controls[1]->populateList();
				$this->renderAttributeList($item->Cells[0]->Controls[1]->Controls[1]);
			} 
			else 
			{
				$item->Cells[0]->attributeNewPanel->setVisible(false);
				$item->Cells[0]->attributeEditPanel->setVisible(true);
			}
		}
	}
	
	public function editProperty($sender, $param)
	{
		$this->NewPropertyButton->setVisible(false);
		
		$this->getPage()->globalEditCancel();
		$this->_datasource = $this->getStoredDataSource();
		$this->setNewItem(false);
		$this->populate();

		$this->PropertyGrid->setEditItemIndex($param->Item->ItemIndex);
		$this->PropertyGrid->setDataSource($this->_datasource);
		$this->PropertyGrid->dataBind();
	}
	
	public function saveProperty($sender, $param)
	{
		$item = $param->getItem();
		$itemIndex = $item->getItemIndex();
		$id = $this->PropertyGrid->DataKeys[$itemIndex];
		
		$propertyKey = '';
		$propertyValue = '';
		if ($this->getNewItem()) 
		{
			//save da new item
			$propertyKey = $item->Cells[0]->Controls[1]->Controls[1]->getSelectedValue(); 
			$propertyValue = $item->Cells[1]->Controls[1]->getSafeText();
		} 
		else 
		{
			//save da update item
			$propertyValue = $item->Cells[1]->Controls[1]->getSafeText();
		}
			
		switch ($this->getObjectClass())
		{
			case 'patron':
				$property = PatronPropertyQuery::create()->findPk($id);
				$objectClassname = "utente";
				
				break;
			
			case 'library':
				$property = LibraryPropertyQuery::create()->findPk($id);
				$objectClassname = "biblioteca";
				
				break;
			
			default:
				$property = null;
		}
		
		if (!is_null($property))	// if property already exists
		{
			$property->setPropertyValue($propertyValue);
			$saveResult = $property->save();
			
			if ($saveResult)
			{
				$this->getPage()->appendDelayedMessage(Prado::localize("Salvato attributo su {class} con id={objectId}",
																			array(	'class' => $objectClassname,
																					'objectId' => $id )),
															ClavisMessage::CONFIRM);
			}
			else
			{
				$this->getPage()->appendDelayedMessage(Prado::localize("Errore su salvataggio attributo su {class} con id={objectId}",
																			array(	'class' => $objectClassname,
																					'objectId' => $id )),
															ClavisMessage::ERROR);
			}
		} 
		else	// if property is created as new
		{
			switch ($this->getObjectClass())
			{
				case 'patron':
					$property = new PatronProperty();
					$property->setPatronId($this->getId());

					break;

				case 'library':
					$property = new LibraryProperty();
					$property->setLibraryId($this->getId());

					break;

				default:
					return false;
			}
			
			$property->setPropertyClass($propertyKey);
			$property->setPropertyValue($propertyValue);
			$saveResult = $property->save();
			
			if ($saveResult)
			{
				$this->getPage()->appendDelayedMessage(Prado::localize("Creato nuovo attributo su {class} con id={objectId}",
																			array(	'class' => $objectClassname,
																					'objectId' => $id )),
															ClavisMessage::CONFIRM);
			}
			else
			{
				$this->getPage()->appendDelayedMessage(Prado::localize("Errore su creazione nuovo attributo su {class} con id={objectId}",
																			array(	'class' => $objectClassname,
																					'objectId' => $id )),
															ClavisMessage::ERROR);
			}
		}
					
		$this->globalEditCancel();
	}
	
	public function deleteProperty($sender, $param)
	{
		$item = $param->Item;
		$itemIndex = $item->ItemIndex;
		$id = $this->PropertyGrid->DataKeys[$itemIndex];
		$error = false;
			
		switch ($this->getObjectClass())
		{
			case 'patron':
				$property = PatronPropertyQuery::create()->findPk($id);
				
				if ($property instanceof PatronProperty)
				{
					$objectId = $property->getPatronId();
					
					try
					{
						$property->delete();
					
						$this->getPage()->appendDelayedMessage(Prado::localize("Cancellato attributo con id={id} dall'utente con id={objectId}",
																			array(	'id' => $id,
																					'objectId' => $objectId )),
															ClavisMessage::CONFIRM);
					}
					catch (Exception $exc)
					{
						$error = true;
						
						$this->getPage()->appendDelayedMessage(Prado::localize("Errore nella cancellazione dell'attributo con id={id} dal patron con id={objectId}",
																			array(	'id' => $id,
																					'objectId' => $objectId )),
															ClavisMessage::ERROR);						
					}
				}
				
				break;

			case 'library':
				$property = LibraryPropertyQuery::create()->findPk($id);
				
				if ($property instanceof LibraryProperty)
				{
					$objectId = $property->getLibraryId();
					
					try
					{
						$property->delete();
					
						$this->getPage()->appendDelayedMessage(Prado::localize("Cancellato attributo con id={id} dalla biblioteca con id={objectId}",
																			array(	'id' => $id,
																					'objectId' => $objectId )),
															ClavisMessage::CONFIRM);
					}
					catch (Exception $exc)
					{
						$error = true;
						
						$this->getPage()->appendDelayedMessage(Prado::localize("Errore nella cancellazione dell'attributo con id={id} dalla biblioteca con id={objectId}",
																			array(	'id' => $id,
																					'objectId' => $objectId )),
															ClavisMessage::ERROR);						
					}
				}

				break;

			default:
				$error = true;
		}
		
		if ($error)
		{
			//$this->flushMessage();
			$this->flushDelayedMessage();
			
		}
		else
		{
			$this->globalRefresh();
			$this->getApplication()->getSession()->add('DoFlushMessage', true);
		}
	}
	
	public function cancelPropertyEdit($sender, $param)
	{
		$this->globalEditCancel();
	}

	public function setId($id) 
	{
		$this->_id = $id;
		$this->setViewState("id", $id, null);
	}

	public function getId($hideAutoID = true)
	{
		if (is_null($this->_id)) 
			$this->_id = $this->getViewState("id", null);

		return $this->_id;
	}

	public function setObject($object)
	{
		$this->_object = $object;
		$this->setViewState("object", $object, null);
	}

	public function getObject()
	{
		if (is_null($this->_object))
			$this->_object = $this->getViewState("object", null);
		
		return $this->_object;
	}

	public function setObjectClass($objectClass)
	{
		$this->setViewState("objectClass", $objectClass, null);
	}

	public function getObjectClass()
	{
		return $this->getViewState("objectClass", null);
	}
	
	public function setStoredDataSource($param = array())
	{
		$this->setViewState("StoredDataSource", $param, array());
	}

	public function getStoredDataSource()
	{
		return $this->getViewState("StoredDataSource", array());
	}
	
	public function setNewItem($param = false)
	{
		$this->setViewState("newItemProperty", $param, false);
	}

	public function getNewItem()
	{
		return $this->getViewState("newItemProperty", false);
	}
	
	public function globalEditCancel()
	{
		$this->PropertyGrid->setEditItemIndex(-1);
		$this->globalRefresh();
	}
	
	public function globalRefresh()
	{
		$this->NewPropertyButton->setVisible(true);
		$this->populate();
	}

	public function isUnlink()
	{
		return false;
	}
	
}