<?php

/**
 * AddressEditPopup
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.e-portaltech.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @license http://www.e-portaltech.it/license/
 */

class AddressEditPopup extends ClavisPagePopup
{
	public $_module = 'CIRCULATION';

	public function onInit($param)
	{
		parent::onInit($param);

		if (!$this->getIsPostBack() )
		{
			$id = intval($this->getRequest()->itemAt('param'));
			if ($id > 0)
				$this->setAddressId($id);
		}
	}

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsPostBack())
			$this->populate();
	}

	public function setAddressId($id = null)
	{
		$this->setViewState('AddressId', $id, null);
	}

	public function getAddressId()
	{
		return $this->getViewState('AddressId', null);
	}

	public function getAddress()
	{
		$address = null;
		$addressId = intval($this->getAddressId());
		if ($addressId > 0)
			$address = AddressPeer::retrieveByPK($addressId);

		return $address;
	}

	public function onCancel($sender, $param)
	{

	}

	public function populate()
	{
		/* @var $address Address */
		$address = $this->getAddress();
		if (is_null($address))
			return false;

		$addressType = TPropertyValue::ensureString($address->getAddressType());
		if ($addressType != '')
			$this->AddressType->setSelectedValue($addressType);

		$addrStreetType = TPropertyValue::ensureString($address->getStreetType());
		if ($addrStreetType != '')
			$this->AddrStreetType->setSelectedValue($addrStreetType);

		$addrStreet = TPropertyValue::ensureString($address->getStreet());
		$addrStreetTrimmed = trim($addrStreet);
		if ($addrStreet != '')
		{
			$this->AddrStreet->setText($addrStreetTrimmed);
			$this->AddrStreetTrimmed->setVisible(strlen($addrStreet) != strlen($addrStreetTrimmed));
		}
		else
		{
			$this->AddrStreetTrimmed->setVisible(false);
		}

		$addrStreetNumber = TPropertyValue::ensureString($address->getStreetNum());
		$addrStreetNumberTrimmed = trim($addrStreetNumber);
		if ($addrStreetNumber != '')
		{
			$this->AddrStreetNumber->setText($addrStreetNumberTrimmed);
			$this->AddrStreetNumberTrimmed->setVisible(strlen($addrStreetNumber) != strlen($addrStreetNumberTrimmed));
		}
		else
		{
			$this->AddrStreetNumberTrimmed->setVisible(false);
		}

		$addrVillage = TPropertyValue::ensureString($address->getVillage());
		$addrVillageTrimmed = trim($addrVillage);
		if ($addrVillage != '')
		{
			$this->AddrVillage->setText($addrVillageTrimmed);
			$this->AddrVillageTrimmed->setVisible(strlen($addrVillage) != strlen($addrVillageTrimmed));
		}
		else
		{
			$this->AddrVillageTrimmed->setVisible(false);
		}

		$addrPref = TPropertyValue::ensureBoolean($address->getAddressPref());
		if ($addrPref == true)
			$this->AddrPref->setChecked(true);

		$addrZip = TPropertyValue::ensureString($address->getZip());
		$addrZipTrimmed = trim($addrZip);
		if ($addrZip != '')
		{
			$this->AddrZip->setText($addrZipTrimmed);
			$this->AddrZipTrimmed->setVisible(strlen($addrZip) != strlen($addrZipTrimmed));
		}
		else
		{
			$this->AddrZipTrimmed->setVisible(false);
		}

		$addrCity = TPropertyValue::ensureString($address->getCity());
		$addrCityTrimmed = trim($addrCity);
		if ($addrCity != '')
		{
			$this->AddrCity->setText($addrCityTrimmed);
			$this->AddrCityTrimmed->setVisible(strlen($addrCity) != strlen($addrCityTrimmed));
		}
		else
		{
			$this->AddrCityTrimmed->setVisible(false);
		}

		$addrProvince = TPropertyValue::ensureString($address->getProvince());
		$addrProvinceTrimmed = trim($addrProvince);
		if ($addrProvince != '')
		{
			$this->AddrProvince->setText($addrProvinceTrimmed);
			$this->AddrProvinceTrimmed->setVisible(strlen($addrProvince) != strlen($addrProvinceTrimmed));
		}
		else
		{
			$this->AddrProvinceTrimmed->setVisible(false);
		}

		$addrCountry = TPropertyValue::ensureString($address->getCountry());
		$addrCountryTrimmed = trim($addrCountry);
		if ($addrCountry != '')
		{
			$this->AddrCountry->setText($addrCountryTrimmed);
			$this->AddrCountryTrimmed->setVisible(strlen($addrCountry) != strlen($addrCountryTrimmed));
		}
		else
		{
			$this->AddrCountryTrimmed->setVisible(false);
		}

		$addrNote = TPropertyValue::ensureString($address->getAddressNote());
		if ($addrNote != '')
			$this->AddrNote->setText($addrNote);

		$trimmedFlag =	$this->AddrStreetTrimmed->getVisible() ||
						$this->AddrStreetNumberTrimmed->getVisible() ||
						$this->AddrVillageTrimmed->getVisible() ||
						$this->AddrZipTrimmed->getVisible() ||
						$this->AddrCityTrimmed->getVisible() ||
						$this->AddrProvinceTrimmed->getVisible() ||
						$this->AddrCountryTrimmed->getVisible();

		$this->LegendaPanel->setVisible($trimmedFlag);
	}

	public function onSave($sender, $param)
	{
		$this->doSave();
	}

	private function doSave()
	{
		/** @var $address Address */
		$address = $this->getAddress();
		if (is_null($address))
		{
			$this->writeMessage(Prado::localize("L'indirizzo da salvare non è stato memorizzato nella finestra di popup. Pregasi contattare il Centro Servizi descrivendo dettagliatamente il problema"), ClavisMessage::ERROR);
			return false;
		}

		$address->setAddressType(TPropertyValue::ensureString($this->AddressType->getSelectedValue()));
		$address->setStreetType(TPropertyValue::ensureString($this->AddrStreetType->getSelectedValue()));
		$address->setStreet(trim($this->AddrStreet->getSafeText()));
		$address->setStreetNum(trim($this->AddrStreetNumber->getSafeText()));
		$address->setVillage(trim($this->AddrVillage->getSafeText()));
		$address->setAddressPref($this->AddrPref->getChecked());
		$address->setZip(trim($this->AddrZip->getSafeText()));
		$address->setCity(trim($this->AddrCity->getSafeText()));
		$address->setProvince(trim($this->AddrProvince->getSafeText()));
		$address->setCountry(trim($this->AddrCountry->getSafeText()));
		$address->setAddressNote(trim($this->AddrNote->getSafeText()));

		$affectedRows = $address->save();
		if ($affectedRows > 0)
		{
			ChangelogPeer::logAction($address, ChangelogPeer::LOG_UPDATE, $this->getUser(),
						Prado::localize("Modificato manualmente l'indirizzo con id: {id}",
											array('id' => $address->getAddressId())));

			$this->getPage()->writeDelayedMessage(Prado::localize("Modificato manualmente l'indirizzo con id: {id}",
											array('id' => $address->getAddressId())),
									ClavisMessage::CONFIRM);

			$this->getApplication()->getSession()->add('UpdateSearch', true);
		}
		else
		{
			$this->getPage()->writeDelayedMessage(Prado::localize("Nessuna modifica manuale effettuata dell'indirizzo con id: {id}",
											array('id' => $address->getAddressId())),
									ClavisMessage::ERROR);
		}
		
		// here we're closing the popup
		$this->getPage()->getClientScript()->registerEndScript(__CLASS__.'_js','onReturn(\'\',\'\',true);');
	}

	public function globalRefresh()
	{
		$this->populate();
	}

	public function isUnlink()
	{
		return false;
	}
}