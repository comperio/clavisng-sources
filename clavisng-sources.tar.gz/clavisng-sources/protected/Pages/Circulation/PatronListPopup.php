<?php

/**
 * PatronListPopup Page class Module Circulation
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2010 Comperio srl
 */

class PatronListPopup extends ClavisPagePopup
{
	public $_module = 'CIRCULATION';

	public function onLoad($param)
	{
		parent::onLoad($param);

		if ((!($this->getPage()->getIsPostBack())) && (!($this->getPage()->getIsCallback())))
		{
			$param = $this->getRequest()->itemAt('param');
			if ($param)
				$this->PatronList->setPopupCustomReturn($param,$param);
			$this->dataBind();
			$this->setFocus($this->PatronList->BarcodeFilter);
		}

	}

	public function onSave($sender, $param)
	{
		if (($patronName = $this->PatronName->getSafeText()) != null)
		{
			$newPatron = new Patron();
			$newPatron->setName($patronName);
			$newPatron->setLastname($this->PatronLastname->getSafeText());

			$currentDate = date('Y-m-d H:i:s');
			$currentUser = $this->User->getID();
			$newPatron->setDateCreated($currentDate);
			$newPatron->setCreatedBy($currentUser);
			$newPatron->setDateUpdated($currentDate);
			$newPatron->setModifiedBy($currentUser);

			$newPatron->setLibraryId(0);
			$newPatron->save();

			$this->PatronList->populate();
			$this->ClearInputDialog();
			$this->dataBind();
		}
	}

	private function ClearInputDialog()
	{
		$this->PatronName->setText('');
		$this->PatronLastname->setText('');
	}

	public function globalRefresh()
	{
		$this->PatronList->populate();
	}

	public function isUnlink()
	{
		return false;
	}
}
