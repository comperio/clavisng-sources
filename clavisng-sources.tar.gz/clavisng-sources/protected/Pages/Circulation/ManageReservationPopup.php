<?php

/**
 *
 * ManageReservationPopup Test Page class Module Library
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.e-portaltech.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @license http://www.e-portaltech.it/license/
 */


class ManageReservationPopup extends ClavisPagePopup
{
	public $_module = "CIRCULATION";
	protected $_loanmanager;
	protected $_requestmanager;

	private $_fromLibraryId;
	private $_toLibraryId;
	private $_loanStatus;

 	public function initVars()
 	{
 		$this->_loanmanager = $this->getApplication()->getModule("loan");
		$this->_requestmanager = $this->getApplication()->getModule("request");
 	}

	public function onInit($param)
	{
		parent::onInit($param);
		$this->initVars();

		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallBack())
		{
			$paramId = $this->getRequest()->itemAt('param');
			if ($paramId == "")
			{
				$this->getPage()->writeMessage(Prado::localize("Errore nel passaggio dei parametri, contattare il fornitore del software."),
														ClavisMessage::ERROR);
				return false;
			}
			
			$objectType = TPropertyValue::ensureString($this->getRequest()->itemAt('objectType'));

			$object = null;
			switch ($objectType)
			{
				case "Patron":
					$object = PatronQuery::create()->findPK($paramId);
					break;

				case "Manifestation":
					$itemId = null;
					$issueId = null;

					$arrPar = @unserialize($paramId);
					if (is_array($arrPar) && count($arrPar) > 1)
					{
						if (array_key_exists('manifestationId', $arrPar))
							$manifestationId = $arrPar['manifestationId'];
						else
						{
							$this->Reservation->setOocMode(true);
							$this->ReservationAll->setOocMode(true);
						}

						if (array_key_exists('itemId', $arrPar))
							$itemId = $arrPar['itemId'];
						
						if (array_key_exists('issueId', $arrPar))
							$issueId = $arrPar['issueId'];
					}
					else
						$manifestationId = $paramId;

					$this->setObject2($itemId);
					
					if ($manifestationId > 0)
						$object = ManifestationQuery::create()->findPK($manifestationId);
					
					break;

				case "Issue":
					$itemId = null;
					$manifestationId = null;

					$arrPar = @unserialize($paramId);
					if (is_array($arrPar) && count($arrPar) > 1)
					{
						if (array_key_exists('issueId', $arrPar))
							$issueId = $arrPar['issueId'];
						else
						{
							$this->Reservation->setOocMode(true);
							$this->ReservationAll->setOocMode(true);
						}

						if (array_key_exists('itemId', $arrPar))
							$itemId = $arrPar['itemId'];
						
						if (array_key_exists('manifestationId', $arrPar))
							$manifestationId = $arrPar['manifestationId'];
					}
					else
						$issueId = $paramId;

					$this->setObject2($itemId);
					
					if ($issueId > 0)
						$object = IssueQuery::create()->findPK($issueId);
					
					break;
					
				case "Item":

					$issueId = null;
					
					$arrPar = @unserialize($paramId);
					if (is_array($arrPar) && count($arrPar) > 1)
					{
						if (array_key_exists('manifestationId', $arrPar))
							$manifestationId = $arrPar['manifestationId'];
						else
						{
							$this->Reservation->setOocMode(true);
							$this->ReservationAll->setOocMode(true);
						}

						if (array_key_exists('itemId', $arrPar))
							$itemId = $arrPar['itemId'];
						
						if (array_key_exists('issueId', $arrPar))
							$issueId = $arrPar['issueId'];						
					}
					else
						$itemId = $paramId;

					$object = ItemQuery::create()->findPK($itemId);
					$this->Reservation->setOocMode(true);
					$this->ReservationAll->setOocMode(true);
					break;

				case "ItemRequest":
					$object = ItemRequestQuery::create()->findPK($paramId);
					break;

				case "Library":
					$object = LibraryQuery::create()->findPK($paramId);
					break;

				case "Librarian":
					$object = LibrarianQuery::create()->findPK($paramId);
					break;

				case "Loan":
					$object = LoanQuery::create()->findPK($paramId);
					break;

				default:
					$object = ItemQuery::create()->findPK($paramId);
					break;
			}

			if (!is_null($object))
			{
				$this->setObject($object);
				$this->Reservation->setObject($object);
				$this->ReservationAll->setObject($object);
			}
			else
				$this->getPage()->writeMessage("Errore nel passaggio dei parametri, contattare il fornitore del software.",
												ClavisMessage::ERROR);
				
		}
	}

	/**
	 * It manages the mechanism of setting (resetting/initialization) the
	 * dropdowns which perform as filters for the population of the
	 * loans grid.
	 *
	 * @param TEventParameter $param
	 */
	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallBack())
		{
			$this->_loanmanager->ResetManagedReservations($this->getUser());
			$this->_loanmanager->ResetExpiredReservations($this->getUser());

			$this->globalRefresh();
		}
	}

	public function setObject($object)
	{
		$this->setControlState("object", $object, null);
	}

	public function getObject()
	{
		return $this->getControlState("object", null);
	}

	public function setObject2($object)
	{
		$this->setControlState("object2", $object, null);
	}

	public function getObject2()
	{
		return $this->getControlState("object2", null);
	}

 	public function setToLibraryId($lib)
 	{
 		$this->_toLibraryId = $lib;
 		$this->setViewState('toLibraryId', $this->_toLibraryId, null);
 	}

 	public function getToLibraryId()
 	{
 		if (($lib = $this->_toLibraryId) == null)
 		{
 			$lib = $this->getViewState('toLibraryId', null);
 			$this->_toLibraryId = $lib;
 		}
		return $lib;
 	}

 	public function setFromLibraryId($lib)
 	{
 		$this->_fromLibraryId = $lib;
 		$this->setViewState('fromLibraryId', $this->_fromLibraryId, null);
 	}

 	public function getFromLibraryId()
 	{
 		if (($lib = $this->_fromLibraryId) == null)
 		{
 			$lib = $this->getViewState('fromLibraryId', null);
 			$this->_fromLibraryId = $lib;
 		}
		return $lib;
 	}

 	public function setLoanStatus($loanStatus)
 	{
 		$this->_loanStatus = $loanStatus;
 		$this->setViewState('loanStatus', $this->_loanStatus, null);
 	}

 	public function getLoanStatus()
 	{
 		if (($loanStatus = $this->_loanStatus) == null)
 		{
 			$this->_loanStatus = $loanStatus;
 		}

		return $loanStatus;
 	}

 	public function isPopup()
 	{
 		return true;
 	}

 	public function globalRefresh()
 	{
		if (!is_null($this->getObject()))
		{
			$this->Reservation->resetDataSource();
			$this->ReservationAll->resetDataSource();
		}
				
		$this->ForceLoanPanel->setVisible(count($this->Reservation->getStoredDataSource()) == 0);
 	}

 	/**
 	 * It updates the page in case a new patron is choosen.
 	 *
 	 * @param TControl $sender
 	 * @param TEventParameter $param
 	 */
 	public function onPatronIdChanged($sender, $param)
 	{
 		$id = $this->HiddenValue->getValue();
 		$patron = PatronQuery::create()->findPK($id);
 		$completeName = $patron->getCompleteName();
 		$this->PatronLabel->setText($completeName);
 		$this->PatronPanel->setVisible(true);
 	}

	public function onResetPatron($sender, $param)
	{
		$this->HiddenValue->setValue('');
 		$this->PatronPanel->Visible = false;
	}

	public function onResetOutDate($sender, $param)
	{
		$this->OutDateFrom->setText('');
 		$this->OutDateTo->setText('');
	}

	public function onSubmit($sender, $param)
	{
		$this->globalRefresh();
	}

	public function onManageRequests($sender, $param)
	{
		$okCheckedRequests = $this->Reservation->getCheckedItems();
		$clavisLibrarian = $this->getUser();

		foreach ($okCheckedRequests as $row)
		{
			$request = $row['request'];
			$this->_loanmanager->DoManageRequest($request, $clavisLibrarian);
		}

		$this->globalRefresh();
	}

	public function onUnManageRequests($sender, $param)
	{
		$okCheckedRequests = $this->ManagedReservation->getCheckedItems();
		$clavisLibrarian = $this->getUser();

		foreach ($okCheckedRequests as $row)
		{
			$request = $row['request'];
			$this->_loanmanager->DoUnManageRequest($request, $clavisLibrarian);
		}

		$this->globalRefresh();
	}

	public function onImmediateLoan($sender, $param)
	{
		$barcode = trim($sender->getSafeText());
		$sender->setText('');

		if (!$this->ManagedReservation->existsBarcode($barcode))
		{
			$this->ItemField->setText('');
			$this->writeMessage(Prado::localize('Il codice a barre non si riferisce a nessuna prenotazione presa in gestione !'), ClavisMessage::ERROR);
			return;
		}

		if ($barcode !== '')
		{
			$items = ItemPeer::retrieveByBarcode($barcode);
			
			/**
			 * Fix temporaneo, nell'attesa di gestire i risultati duplicati
			 */
			$item = $items[0];

			if ($item instanceof Item)
			{
				$reqId = intval($item->retrieveFirstItemRequestId());
				if ($reqId > 0)
					$itemRequest = ItemRequestQuery::create()->findPK($reqId);

				if ($itemRequest instanceof ItemRequest)
				{
					$patron = $itemRequest->getPatron();
					$dueDate = $this->_loanmanager->CalculateDueDate($item);
					$clavisLibrarian = $this->getUser();
					$deliveryLibrary = $itemRequest->getDeliveryLibrary();
					$deliveryLibraryId = $deliveryLibrary->getLibraryId();

					$isItemAvailable = ($this->_loanmanager->IsItemAvailable($item, $deliveryLibraryId) == ClavisLoanManager::OK);
					
					if ($patron instanceof Patron)
					{
						$patronData = $patron->getReverseCompleteName();
						$isPatronAllowed = $this->_loanmanager->IsPatronAllowedToLoan($patron, $item->getItemId());
					}
					else
					{
						$patronData = "--";
						$isPatronAllowed = ClavisLoanManager::LOAN_PATRONNOTENABLED;
					}

					if ($isPatronAllowed == ClavisLoanManager::LOAN_PATRONNOTENABLED)
							$this->writeMessage(Prado::localize("L'esemplare '{title}' [barcode: {barcode}] non è prestabile perchè l'utente {patron} non è abilitato",
																array(	'title' => $item->getTrimmedTitle(40), 
																		'barcode' => $item->getBarcode(),
																		'patron' => $patronData)),
													ClavisMessage::ERROR);
					
					if ($isPatronAllowed == ClavisLoanManager::LOAN_REACHEDMAX)
							$this->writeMessage(Prado::localize("L'esemplare '{title}' [barcode: {barcode}] non è prestabile perchè l'utente {patron} ha raggiunto il massimo numero di prestiti consentiti",
																array(	'title' => $item->getTrimmedTitle(40), 
																		'barcode' => $item->getBarcode(),
																		'patron' => $patronData)),
													ClavisMessage::ERROR);
										
					if (!$isItemAvailable)
							$this->writeMessage(Prado::localize("L'esemplare '{title}' [barcode: {barcode}] non è disponibile",
																array(	'title' => $item->getTrimmedTitle(40), 
																		'barcode' => $item->getBarcode())),
													ClavisMessage::ERROR);

					if (($isPatronAllowed == ClavisLoanManager::OK) && $isItemAvailable)
					{
						$loanResult = $this->_loanmanager->DoLoanItem(	$item, 
																		$patron, 
																		$clavisLibrarian, 
																		$deliveryLibrary, 
																		$itemRequest, 
								
																		$dueDate);
						switch ($loanResult)
						{
							case ClavisLoanManager::LOAN_READYTOLOAN:
								$labelText = Prado::localize("Esemplare '{title}' [barcode: {barcode}] pronto al prestito per l'utente {patron}",
																	array(	'title' => $item->getTitle(),
																			'barcode' => $item->getBarcode(),
																			'patron' => $patronData));

								// ready-to-loan automatic notification
								if (ClavisParamQuery::getParam('CLAVISPARAM','AutoEmailLoanReady') == 'true')
								{
									$ret = NotificationHelper::sendNotificationEmail('readyforloan', $patron,
										$clavisLibrarian->getLibrarian(), $deliveryLibrary,
										array($item->getCurrentLoanId()));
									if ($ret) {
										$item->setNotifyCount($item->getNotifyCount() + 1);
										$item->save();
										$loan = $item->getLoanRelatedByCurrentLoanId();
										$loan->setNotifyCount($loan->getNotifyCount() + 1);
										$loan->save();
										$labelText .= Prado::localize(' - notificato automaticamente via email');
									}
								}
								$this->writeMessage($labelText, ClavisMessage::CONFIRM);
								$this->UserFocus->setFocusComponent($this->ItemField);
								$return = true;
								break;

							case ClavisLoanManager::LOAN_ILLREQUESTED:
								$this->writeMessage(Prado::localize("Esemplare '{title}' [barcode: {barcode}] pronto al transito per l'utente {patron}",
																	array(	'title' => $item->getTitle(),
																			'barcode' => $item->getBarcode(),
																			'patron' => $patronData)), 
														ClavisMessage::CONFIRM);

								$this->UserFocus->setFocusComponent($this->ItemField);
								$return = true;
								break;

							case ClavisLoanManager::LOAN_LOANALREADYEXISTS:
								$this->getPage()->writeMessage(Prado::localize("Un prestito per l'esemplare '{title}' [barcode: {barcode}] è già in corso",
																				array(	'title' => $item->getTrimmedTitle(40), 
																						'barcode' => $item->getBarcode()),
																ClavisMessage::ERROR));
								break;

							case ClavisLoanManager::OK:
							case true:
								$this->writeMessage(Prado::localize("Esemplare '{title}' [barcode: {barcode}] pronto in prestito all'utente {patron}",
																	array(	'title' => $item->getTitle(),
																			'barcode' => $item->getBarcode(),
																			'patron' => $patronData)), 
														ClavisMessage::CONFIRM);
																
								$this->UserFocus->setFocusComponent($this->ItemField);
								$return = true;
								break;

							// fallback
							case ClavisLoanManager::ERROR:
							case false:
								$this->writeMessage(Prado::localize('Esemplare n.{itemId} "{title}" NON PRESTATO',
																	array(	'itemId' => $item->getItemId(),
																			'title' => $item->getTitle())), 
													ClavisMessage::ERROR);
								break;

							default:
								break;
						}
					}
				}
			}
		}
	}

	public function onGotoLoan($sender, $param)
	{
		$itemId = intval($this->getObject2());
		if ($itemId > 0)
			$this->getPage()->gotoPageWithReturn('Catalog.ItemViewPage', array('action' => 'openLoan', 'id' => $itemId));
	}
	
}
