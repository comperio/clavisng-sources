<?php

/**
 * @author Marco Brancalion <mbrancalion@e-portaltech.it>
 * @author Max Pigozzi <mpigozzi@e-portaltech.it>
 * @link http://www.e-portaltech.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @license http://www.e-portaltech.it/license/
 *
 * This page redirects to Circulation.PatronList with the parameter
 * newPatron set to true, so that we enter that page in the "new patron"
 * mode.
 */
class PatronPageRedirect extends ClavisPage
{
	public $_module = "CIRCULATION";
	public $_pageName = "Patron";

	public function onLoad($param)
	{
		parent::onLoad($param);

		$this->gotoPage('Circulation.PatronList', array('newPatron' => true));
	}
}