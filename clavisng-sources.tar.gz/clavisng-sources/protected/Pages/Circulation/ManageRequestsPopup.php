<?php
/**
 * ManageRequestsPopup class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 ePortal Technologies
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Pages.Catalog
 */

/**
 * ManageRequestsPopup Class
 *
 * We use this popup page for selecting an available item
 * for taking it under management (for requests).
 * 
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.7
 * @package Popups.Circulation
 * @since 2.0
 */
class ManageRequestsPopup extends ClavisPagePopup
{
	private $_itemRequestId;
	protected $_requestManager;

	public $_module = 'CIRCULATION';
	public $_llibraryActive;

	private function initVars()
	{
		$this->_llibraryActive = LLibraryPeer::isEnabled();
		$this->_requestManager = $this->getApplication()->getModule('request');
	}

	public function onInit($param)
	{
		parent::onInit($param);
		$this->initVars();

		$this->MaxDistanceColumn->setVisible($this->_llibraryActive);	
	}

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallBack())
		{
			list($itemRequestId, $sCount, $itemId) = unserialize($this->getRequest()->itemAt('param'));

			if ($this->getRequest()->itemAt('immediateLoan') == "1")
				$this->setImmediateLoan(true);

			$this->setItemRequestId($itemRequestId);
			$this->setItemId($itemId);
			$this->populate($sCount > 0);
		}
	}

	public function setItemRequestId($itemRequestId)
	{
		$this->_itemRequestId = $itemRequestId;
		$this->setViewState("ItemRequestId", $itemRequestId, null);
	}

	public function getItemRequestId()
	{
		$this->_itemRequestId = $this->getViewState("ItemRequestId", null);
		return $this->_itemRequestId;
	}

	private function getItemRequest()
	{
		$itemRequest = ItemRequestQuery::create()
						->findPk(intval($this->getItemRequestId()));
		
		if ($itemRequest instanceof ItemRequest)
			return $itemRequest;
		else
			return null;
	}

	public function setItemId($param)
	{
		$this->setViewState("ParamItemId", $param, null);
	}

	public function getItemId()
	{
		return $this->getViewState("ParamItemId", null);
	}
	
	private function getItem()
	{
		$item = null;
		$itemId = intval($this->getItemId());
		if ($itemId > 0)
			$item = ItemQuery::create()
						->findPk($itemId);
		return $item;
	}
	
	public function setImmediateLoan($param = false)
	{
		if ($param === true)
			$param = true;
		else
			$param = false;

		$this->setControlState("ImmediateLoan", $param, false);
	}

	public function getImmediateLoan()
	{
		return $this->getControlState("ImmediateLoan", false);
	}
	
	public function populate($enableProcessFlag)
	{
		$this->getPage()->cleanMessageQueue();
				
		$this->_itemRequestId = null;
		$item = null;
		
		$itemId = intval($this->getItemId());
		if ($itemId > 0)
			$item = ItemQuery::create()
						->findPk($itemId);

		if ($item instanceof Item)
		{
			$manifestation = $item->getManifestation();
			$issue = $item->getIssue();
			
			if ($issue instanceof Issue)
				$objectType = ItemRequestPeer::OBJECTTYPE_ISSUE;
			elseif ($manifestation instanceof Manifestation)
				$objectType = ItemRequestPeer::OBJECTTYPE_MANIFESTATION;
			else
				$objectType = ItemRequestPeer::OBJECTTYPE_ITEM;
			
			$this->_itemRequestId = intval($this->calculateRequestIdFromItemId($itemId, $objectType));
		}
		else
		{
			$this->_itemRequestId = intval($this->getItemRequestId());
		}
		
		if ($this->_itemRequestId > 0)
		{
			$itemRequest = ItemRequestQuery::create()
							->findPK($this->_itemRequestId);

			if ($itemRequest instanceof ItemRequest)
			{
				$data = array();
				foreach($requestsRaw = $this->_requestManager->getRequestsDetailed($this->_itemRequestId) as $row)
				{
					$dataRow = array();
					
					$requestId = $row['requestId'];
					$dataRow['requestId'] = $requestId;
					
					$request = null;
					if (intval($requestId) > 0)
						$request = ItemRequestQuery::create()
									->findPK($requestId);
					if (!($request instanceof ItemRequest))
						continue;
			
					$manifestationId = $row['manifestationId'];
					$itemId = $row['itemId'];
					$issueId = $row['issueId'];
					$maxDistance = $row['maxDistance'];
					
					if (!is_null($issueId))
					{
						// request is on ISSUE
						$requestTypeImage = "requesttype_issue.png";
						$requestTypeText = Prado::localize("prenotazione per fascicolo");
					}
					elseif (!is_null($itemId))
					{
						// request is on ITEM
						$requestTypeImage = "requesttype_item.png";
						$requestTypeText = Prado::localize("prenotazione per esemplare");
					}
					elseif ($manifestationId > 0)
					{
						// request is on MANIFESTATION
						$requestTypeImage = "";
						$requestTypeText = "";
					}
					else
					{
						// fallback (should not happen)
						$requestTypeImage = "";
						$requestTypeText = "";
					}
			
					$dataRow['requestTypeImage'] = $requestTypeImage;
					$dataRow['requestTypeText'] = $requestTypeText;
					
					$dataRow['requestStatus'] = $row['requestStatus'];
					
					$destinationText = Prado::localize('indefinito');	// priming
					$destinationNavigateUrl = "";
					$patronId = intval($row['patronId']);
					$externalLibraryId = intval($row['externalLibraryId']);
					$deliveryLibraryText = "";
			
					/**
					* Imported from ClavisManageRequestsList
					* 
					* this should be the number of items that other libraris in the system
					* can actually use for this request that i can process, on my behalf.
					* 
					* If it's == 0, my library is the only library that can process that request.
					*/
					
					$alienItemsCount = 0;
			
					if ($patronId > 0)
					{
						$patron = PatronQuery::create()
									->findPK($patronId);
						if ($patron instanceof Patron)
						{
							$destinationText = $patron->getCompleteName();
							
							$loanCount = LoanQuery::create()
								->filterByPatron($patron)
								->filterByLoanStatus(ItemPeer::getLoanStatusActive())
								->count();

							if ($loanCount > 0)
								$destinationText .= "&nbsp;(<b>$loanCount</b>)";
				
							$destinationNavigateUrl = $patron->getNavigateUrl(true);
						}
						
						$deliveryLibrary = $request->getDeliveryLibrary();
						if ($deliveryLibrary instanceof Library)
						{
							$deliveryLibraryText = "<br />->&nbsp;" . $deliveryLibrary->getLabel(null, null, null, 20);
							
							$alienItemsCount = $this->_requestManager->countRequestAllCandidateItems(	$deliveryLibrary->getLibraryId(),
																										$maxDistance,
																										$manifestationId,
																										$itemId,
																										$issueId);
						}
					}
					elseif ($externalLibraryId > 0)
					{
						$library = LibraryQuery::create()
									->findPK($externalLibraryId);
						if ($library instanceof Library)
						{
							$destinationText = $library->getLabel(true, false, true, 30);
							$destinationNavigateUrl = $library->getNavigateUrl(true);
						}
					}
					
					$flagCode = ($alienItemsCount > 0
									? ClavisRequestManager::no_flag
									: ClavisRequestManager::red_flag );
					$dataRow['flagCode'] = $flagCode;
								
					$dataRow['destinationText'] = $destinationText;
					$dataRow['destinationNavigateUrl'] = $destinationNavigateUrl;
					
					$dataRow['requestDate'] = $row['requestDate'];
					$dataRow['expireDate'] = $row['expireDate'];
					
					$dataRow['requestNote'] = $row['requestNote'];
					
					$dataRow['deliveryLibraryText'] = $deliveryLibraryText;
					
					$maxDistance = $request->getMaxDistance();
					if (is_null($maxDistance))
						$maxDistance = LLibraryPeer::NULLDISTANCE;
					$dataRow['maxDistance'] = $maxDistance;
			
					$dataRow['enableProcessFlag'] = $enableProcessFlag;
					
					$librarian = null;
					$librarianId = intval($row['librarianId']);
					if ($librarianId > 0)
						$librarian = LibrarianQuery::create()->findPk($librarianId);
					if ($librarian instanceof Librarian)
						$librarianName = $librarian->getCompleteName();
					else
						$librarianName = '---';
					$dataRow['librarianName'] = $librarianName;
					
					$data[] = $dataRow;
				}
				
				$recCount = count($data);
				$this->Grid->setVirtualItemCount($recCount);
				$this->Grid->setDataSource($data);
				$this->Grid->dataBind();
			}
			else
			{
				$this->getPage()->enqueueMessage(Prado::localize("Errore: prenotazione incongruente: l'id viene passato [{reqId}] ma la prenotazione relativa non esiste",
																	array('reqId' => $this->_itemRequestId)),
													ClavisMessage::ERROR);
			}
		}
		else
		{
			$this->getPage()->enqueueMessage(Prado::localize("Errore interno: il parametro non è stato passato al popup di visualizzazione prenotazione. Riportare al fornitore del software"), 
												ClavisMessage::ERROR);
		}
		
		$this->flushMessage();
	}

	public function isUnlink()
	{
		return false;
	}
	
	public function onManageRequest($sender, $param) 
	{
		$requestId = $param->getCommandParameter();
		
		if (intval($requestId) > 0)
		{
			$this->getPage()->cleanMessageQueue();
			$okCloseFlag = false;
			
			/** 
			 * Attempt to loan immediately, because probably we are a popup as in 
			 * the newloan page.
			 */
			if ($this->getImmediateLoan())
			{
				$loanManager = $this->getApplication()->getModule('loan');
				
				/**
				// lost check
				$returnMessage = $loanManager->putLostToAvailableItem($itemId);
				if (count($returnMessage) > 0)
					$this->getPage()->enqueueMessage($returnMessage[0], $returnMessage[1]);
				*/	
				
				$item = $this->getItem();
				if ($item instanceof Item)
				{
					$itemRequest = ItemRequestQuery::create()
										->findPK($requestId);

					if ($itemRequest instanceof ItemRequest)
					{
						$patron = $itemRequest->getPatron();
						if ($patron instanceof Patron)
						{
							$patronData = $patron->getReverseCompleteName();
							$isPatronAllowed = $loanManager->IsPatronAllowedToLoan($patron, $item->getItemId(),true);
						}
						else    // extrasystem case
						{
							$externalLibraryId = intval($itemRequest->getExternalLibraryId());
							$isPatronAllowed = $loanManager->isExternalLibraryAllowedToLoan($externalLibraryId);
							$patron = LibraryQuery::create()
										->findPK($externalLibraryId);   // extrasystem case, patron equals externallibrary inside loanmanager::DoLoanItem
							$patronData = $patron->getLabel(true, true, true);	// this is an external library
						}

						$dueDate = $loanManager->CalculateDueDate($item);
						$deliveryLibrary = $itemRequest->getDeliveryLibrary();
						$deliveryLibraryId = $deliveryLibrary->getLibraryId();

//						if ($isPatronAllowed != ClavisLoanManager::OK)
//								$this->enqueueMessage(Prado::localize("L'utente non è abilitato al prestito di '{title}' [barcode: {barcode}].",
//																		array('title' => $item->getTrimmedTitle(40), 'barcode' => $item->getBarcode())),
//														ClavisMessage::ERROR);
						switch ($isPatronAllowed)
						{
							case ClavisLoanManager::LOAN_PATRONNOTENABLED:
								$this->enqueueMessage(Prado::localize("L'utente '{patron}' non è abilitato al prestito",
																		array(	'patron' => $patronData)),
														ClavisMessage::ERROR);
								break;
							
							case ClavisLoanManager::LOAN_REACHEDMAX:
								$this->enqueueMessage(Prado::localize("L'utente '{patron}' non è abilitato al prestito di '{title}' [barcode: {barcode}] perchè è stato superato il numero dei prestiti consentiti",
																		array(	'patron' => $patronData,
																				'title' => $item->getTrimmedTitle(40), 
																				'barcode' => $item->getBarcode())),
														ClavisMessage::ERROR);
								break;

							case ClavisLoanManager::LOAN_EXTERNALLIBRARYNOTENABLED:
								$this->enqueueMessage(Prado::localize("La biblioteca esterna '{patron}' non è abilitata al prestito di '{title}' [barcode: {barcode}]",
																		array(	'patron' => $patronData,
																				'title' => $item->getTrimmedTitle(40), 
																				'barcode' => $item->getBarcode())),
														ClavisMessage::ERROR);
								break;
						}
						
						$isItemAvailable = ($loanManager->IsItemAvailable($item, $deliveryLibraryId) == ClavisLoanManager::OK);
						if (!$isItemAvailable)
								$this->enqueueMessage(Prado::localize("L'esemplare '{title}' [barcode: {barcode}] non è disponibile",
																		array(	'title' => $item->getTrimmedTitle(40), 
																				'barcode' => $item->getBarcode())),
														ClavisMessage::ERROR);

						if (($isPatronAllowed == ClavisLoanManager::OK) && $isItemAvailable)
						{
							$loanResult = $loanManager->DoLoanItem(	$item, 
																	$patron, 
																	$this->getUser(), 
																	$deliveryLibrary, 
																	$itemRequest, 

																	$dueDate );
							switch ($loanResult)
							{
								case ClavisLoanManager::LOAN_READYTOLOAN:
									$labelText = Prado::localize("Esemplare '{title}' [barcode: {barcode}] pronto al prestito per l'utente '{patron}'",
																			array(	'patron' => $patronData,
																					'title' => $item->getTrimmedTitle(40), 
																					'barcode' => $item->getBarcode()));

									// ready-to-loan automatic notification
									if (ClavisParamQuery::getParam('CLAVISPARAM','AutoEmailLoanReady') == 'true')
									{
										$ret = NotificationHelper::sendNotificationEmail('readyforloan', $patron,
											$this->getUser()->getLibrarian(), $deliveryLibrary,
											array($item->getCurrentLoanId()));
										if ($ret) {
											$item->setNotifyCount($item->getNotifyCount() + 1);
											$item->save();
											$loan = $item->getLoanRelatedByCurrentLoanId();
											$loan->setNotifyCount($loan->getNotifyCount() + 1);
											$loan->save();
											$labelText .= Prado::localize(' - notificato automaticamente via email');
										}
									}
									$this->enqueueMessage($labelText, ClavisMessage::CONFIRM);
									$okCloseFlag = true;
									break;

								case ClavisLoanManager::LOAN_ILLREQUESTED:
									$this->enqueueMessage(Prado::localize("Esemplare '{title}' [barcode: {barcode}] pronto al transito per l'utente '{patron}'",
																			array(	'patron' => $patronData,
																					'title' => $item->getTrimmedTitle(40), 
																					'barcode' => $item->getBarcode())),
															ClavisMessage::CONFIRM);

									$okCloseFlag = true;
									break;

								case ClavisLoanManager::LOAN_LOANALREADYEXISTS:
									$this->enqueueMessage(Prado::localize("Un prestito per l'esemplare '{title}' (barcode: {barcode}) è già in corso",
																			array(	'title' => $item->getTrimmedTitle(40), 
																					'barcode' => $item->getBarcode()),
															ClavisMessage::ERROR));
									break;

								case ClavisLoanManager::RSV_ALREADYMANAGED:
									$this->enqueueMessage(Prado::localize("L'esemplare '{title}' (barcode: {barcode}) è già in gestione ad un altro operatore, per cui non è possibile prestarlo",
																			array(	'title' => $item->getTrimmedTitle(40), 
																					'barcode' => $item->getBarcode()),
															ClavisMessage::ERROR));
									break;

								case ClavisLoanManager::OK:
								case true:
									$this->enqueueMessage(Prado::localize("Esemplare '{title}' [barcode: {barcode}] in prestito all'utente '{patron}'",
																			array(	'patron' => $patronData,
																					'title' => $item->getTrimmedTitle(40), 
																					'barcode' => $item->getBarcode())),
															ClavisMessage::CONFIRM);									

									$okCloseFlag = true;
									break;

								case ClavisLoanManager::ERROR:
								case false:
								default:

									$this->enqueueMessage(Prado::localize("ERRORE: esemplare '{title}' (barcode: {barcode}) non prestato",
																			array(	'title' => $item->getTrimmedTitle(40), 
																					'barcode' => $item->getBarcode())),
															ClavisMessage::ERROR);
									break;
							}
						}
					}	// $request is a valid ItemRequest
					else
					{
						$this->enqueueMessage(Prado::localize("ERRORE sul passaggio parametri della prenotazione durante il prestito successivo alla presa in gestione.<br />Riportare al fornitore del software, grazie"),
												ClavisMessage::ERROR);
					}
				}	// end of if item is valid
				else
				{
					$this->enqueueMessage(Prado::localize("ERRORE sul passaggio parametri dell'esemplare durante il prestito.<br />Riportare al fornitore del software, grazie"),
											ClavisMessage::ERROR);
				}
			}	// end of if immediate loan			
			
			else	// instead we manage the request
			{
				$returnValue = $this->_requestManager->manageRequest($requestId, $this->getUser());
				switch ($returnValue)
				{
					case ClavisLoanManager::OK:
						$okCloseFlag = true;
						$this->enqueueMessage(Prado::localize("Prenotazione presa in gestione correttamente"),
												ClavisMessage::CONFIRM);
						break;

					case ClavisLoanManager::RSV_ALREADYMANAGED:
						$this->enqueueMessage(Prado::localize("Prenotazione già presa in gestione"),
												ClavisMessage::WARNING);
						break;

					case ClavisLoanManager::RSV_ALREADYCLOSED:
						$this->enqueueMessage(Prado::localize("Prenotazione già soddisfatta o chiusa o annullata"),
												ClavisMessage::WARNING);
						break;

					case ClavisLoanManager::LOAN_PATRONNOTENABLED:
						$this->enqueueMessage(Prado::localize("Non è possibile prendere in gestione la prenotazione perché l'utente destinatario non è abilitato"),
												ClavisMessage::ERROR);
						break;

					case ClavisLoanManager::LOAN_REACHEDMAX:
						$this->enqueueMessage(Prado::localize("Non è possibile prendere in gestione la prenotazione perché l'utente destinatario ha raggiunto il massimo numero di prestiti consentiti"),
												ClavisMessage::ERROR);
						break;
					
					case ClavisLoanManager::LOAN_EXTERNALLIBRARYNOTENABLED:
						$this->enqueueMessage(Prado::localize("Non è possibile prendere in gestione la prenotazione perché la biblioteca destinataria [esterna] non è abilitata"),
												ClavisMessage::ERROR);
						break;

					default:
						$this->enqueueMessage(Prado::localize("Non è possibile prendere in gestione la prenotazione"),
												ClavisMessage::ERROR);
						break;
				}			
			}
				
			if ($okCloseFlag)		// we can close the popup and put out a delayed message
			{
				$itemId = intval($this->getItemId());
				
				if ($itemId > 0)
				{
					$this->getApplication()->getSession()->add('UpdateItemId', $itemId);
				}
				else
				{
					$this->getApplication()->getSession()->add('UpdateClavisManageRequestsList', true);
				}

				$this->getPage()->flushDelayedMessage();
				$this->getPage()->getClientScript()->registerEndScript(__CLASS__.'_js','onReturn(\'\',\'\',true);');
			}
			else 
			{	// the popup doesn't get closed, so we need an immediate message
				$this->getPage()->flushMessage();
			}
		}	// end if part where $requestId is correct
		else
		{
			$this->getPage()->writeMessage(Prado::localize("Errore nel passaggio del parametro della prenotazione.<br />Riportare al fornitore del software, grazie"),
											ClavisMessage::ERROR);
			return false;
		}
	}

	private function calculateRequestIdFromItemId(	$itemId,
														$objectType )
	{
		$request = null;
		
		if (($itemId > 0) && ($objectType != ""))
		{
			switch ($objectType)
			{
				case ItemRequestPeer::OBJECTTYPE_ITEM:
					$request = ItemRequestQuery::create()
								->filterByRequestStatus(array(	ItemRequestPeer::STATUS_PENDING,
																ItemRequestPeer::STATUS_WORKING))
								->filterByItemId($itemId)
								->findOne();
					break;

				case ItemRequestPeer::OBJECTTYPE_MANIFESTATION:
					
					$item = ItemQuery::create()
							->findPk($itemId);
					
					$manifestationId = intval($item->getManifestationId());
					
					if (($item instanceof Item) && ($manifestationId > 0))
					{	
						$request = ItemRequestQuery::create()
									->filterByRequestStatus(array(	ItemRequestPeer::STATUS_PENDING,
																	ItemRequestPeer::STATUS_WORKING))
									->filterByManifestationId($manifestationId)
									->findOne();
					}
					break;

				case ItemRequestPeer::OBJECTTYPE_ISSUE:
					
					$item = ItemQuery::create()
							->findPk($itemId);
					
					$manifestationId = intval($item->getManifestationId());
					$issueId = intval($item->getIssueId());
					
					if (($item instanceof Item) && ($manifestationId > 0) && ($issueId > 0))
					{	
						$request = ItemRequestQuery::create()
									->filterByRequestStatus(array(	ItemRequestPeer::STATUS_PENDING,
																	ItemRequestPeer::STATUS_WORKING))
									->filterByManifestationId($manifestationId)
									->filterByIssueId($issueId)
									->findOne();
					}
					break;
					
				default:
					break;
			}
		}
			
		if ($request instanceof ItemRequest)
			return $request->getRequestId();
		else
			return null;
	}
	
}
