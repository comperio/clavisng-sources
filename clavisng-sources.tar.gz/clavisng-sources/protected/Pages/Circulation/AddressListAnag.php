<?php
/**
 * AddressListAnag class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Pagess.Circulation
 */

/**
 * AddressListAnag
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.7
 * @package Pages.Circulation
 * @since 2.4
 */
class AddressListAnag extends ClavisPage
{
	public $_module = 'CIRCULATION';

	public function onLoad($param)
	{
		parent::onLoad($param);
		
		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallback())
		{
			$this->clearFilters();
			$this->doSearch();

			$this->getPage()->setFocus($this->BirthCity->getClientID());
		}

		if ($this->getPage()->getIsPostBack() || $this->getPage()->getIsCallback())
		{
			$updateSearch = $this->getApplication()->getSession()->itemAt('UpdateSearch');
			if (!is_null($updateSearch) && ($updateSearch == true))
			{
				$this->getApplication()->getSession()->remove('UpdateSearch');
				$this->doSearch(false);
			}
		}
	}

	public function onPreRender($param)
	{
		parent::onPreRender($param);

		$enabledModify = (count($this->List->getCheckedItemIds()) > 0);
		$this->OperationPanel->setCssClass($enabledModify
												? 'panel_on'
												: 'panel_shaded' );

		$oldEnabled = $this->OperationPanel->getEnabled();
		$this->OperationPanel->setEnabled($enabledModify);

		if (($enabledModify != $oldEnabled) && $this->getIsCallback())
			$this->OperationPanel->render($this->getPage()->createWriter());
	}

	public function populate()
	{
		$this->List->populate();
	}

	public function globalRefresh()
	{
		$this->List->resetDataSource();
	}

	public function onCleanSearch()
	{
		$this->onCancel(null, null);
	}

	public function onCancel($sender, $param)
	{
		$this->clearFilters();
		$this->doSearch();
		$this->getPage()->setFocus($this->BirthCity->getClientID());
	}

	public function clearFilters()
	{
		$this->BirthCity->setText('');
		$this->BirthProvince->setText('');
		$this->BirthCountry->setText('');
		$this->BirthCitizenship->setText('');
		$this->BirthNote->setText('');
	}

	public function onSearch($sender, $param)
	{
		$this->doSearch();
	}

	public function doSearch($resetPagination = true)
	{
		$birthCity = trim($this->BirthCity->getSafeText());
		$birthProvince = trim($this->BirthProvince->getSafeText());
		$birthCountry = trim($this->BirthCountry->getSafeText());
		$birthCitizenship = trim($this->BirthCitizenship->getSafeText());
		$birthNote = trim($this->BirthNote->getSafeText());

		$this->List->setFilters($birthCity,
								$birthProvince,
								$birthCountry,
								$birthCitizenship,
								$birthNote );

		$this->List->resetDataSource(true, $resetPagination);
	}

	public function onModify($sender, $param)
	{
		$idsArray = $this->List->getCheckedItemIds();
		if (count($idsArray) == 0)
		{
			$this->writeMessage(Prado::localize("Non sono state selezionate righe"), ClavisMessage::WARNING);
			return false;
		}

		$this->cleanMessageQueue();

		$birthCity = trim($this->BirthCityMod->getSafeText());
		$birthProvince = trim($this->BirthProvinceMod->getSafeText());
		$birthCountry = trim($this->BirthCountryMod->getSafeText());
		$birthCitizenship = trim($this->BirthCitizenshipMod->getSafeText());

		if ($birthCity . $birthProvince . $birthCountry . $birthCitizenship == "")
		{
			$this->writeMessage(Prado::localize("Non è stato inserito alcunché nei campi per nuove modifiche"), ClavisMessage::WARNING);
			return false;
		}

		$ok = 0;
		$failed = 0;

		/** @var $address Address */
		foreach ($idsArray as $patronId)
		{
			$patron = PatronPeer::retrieveByPk($patronId);
			if ($patron instanceof Patron)
			{
				try
				{
					if ($birthCity != "")
						$patron->setBirthCity($birthCity);

					if ($birthProvince != "")
						$patron->setBirthProvince($birthProvince);

					if ($birthCountry != "")
						$patron->setBirthCountry($birthCountry);

					if ($birthCitizenship != "")
						$patron->setCitizenship($birthCitizenship);

					$patron->save();
					ChangelogPeer::logAction(	$patron,
												ChangelogPeer::LOG_UPDATE,
												$this->getUser(),
												"modificata anagrafica utente ({$patron->getCompleteName()}) dalla pagina modifica indirizzi anagrafici");

					unset ($patron);
					$ok++;
				}
				catch (Exception $e)
				{
					$failed++;
				}
			}
			else
				$failed++;
		}

		if ($ok + $failed == 0)
		{
			$this->getPage()->enqueueMessage(Prado::localize("Nessuna modifica effettuata"),
											ClavisMessage::WARNING);
		}
		else
		{
			if ($ok > 0)
			{
				$this->enqueueMessage((1 == $ok)
						? Prado::localize('1 anagrafica utente modificata')
						: Prado::localize('{count} anagrafiche utente modificate',array('count'=>$ok)),
					ClavisMessage::CONFIRM);
				$this->List->populate();
			}

			if ($failed > 0)
				$this->enqueueMessage((1 == $failed)
						? Prado::localize('1 modifica anagrafica fallita')
						: Prado::localize('{count} modifiche anagrafiche fallite',array('count'=>$failed)),
					ClavisMessage::WARNING);
		}
		
		$this->flushMessage();
	}
	
}
