<?php

/**
 * PatronChooseImagePopup
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2011 Comperio srl
 */

class PatronChooseImagePopup extends ClavisPagePopup
{
	public $_module = 'CIRCULATION';

	public function onInit($param)
	{
		parent::onInit($param);
		
		if (!$this->getPage()->getIsPostBack())
		{
			$this->PhotoUploader->setUserId($this->getRequest()->itemAt('patronId'));
			
			$p = AttachmentQuery::create()
					->filterByAttachmentType(AttachmentPeer::TYPE_PHOTO)
					->filterByObjectType('Patron')
					->filterByObjectId($this->getRequest()->itemAt('patronId'))
					->findOne();
			
			if ($p instanceof Attachment)
				$this->PhotoUploader->setCurrentPhotoId($p->getAttachmentId());
		}
	}

	public function onCancel($sender, $param)
	{
		
	}

	public function globalRefresh()
	{
		
	}

	public function isUnlink()
	{
		return false;
	}

	public function onSubmitClick($sender, $param)
	{
		
	}
	
}
