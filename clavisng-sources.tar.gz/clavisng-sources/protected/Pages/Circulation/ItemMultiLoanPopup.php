<?php

/**
 * ItemMultiLoanPopup page
 * 
 * It's used inside the ManagedReservationList (list of managed requests)
 * for choosing which item we want to use for processing.
 *
 * @author Marco Brancalion <mbrancalion@e-portaltech.it>
 * @link http://www.e-portaltech.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @license http://www.e-portaltech.it/license/
 */

class ItemMultiLoanPopup extends ClavisPagePopup
{
	public $_module = "CIRCULATION";

	private $_objectId;
	protected $_loanmanager;
	protected $_requestmanager;

	private function initVars()
	{
		$this->_loanmanager = $this->getApplication()->getModule("loan");
		$this->_requestmanager = $this->getApplication()->getModule("request");
	}

	public function onInit($param)
	{
		parent::onInit($param);
		$this->initVars();

		if (!$this->getIsPostBack() )
		{
			$objectId = intval($this->Request['param']);
		    if ($objectId > 0)
				$this->setObjectId($objectId);
		}
	}

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsPostBack())
		{
			$requestId = intval($this->getObjectId());
			if ($requestId > 0)
			{
				$this->populate($requestId);
			}
			else
			{
				$this->MainPanel->setVisible(false);
				$this->ErrorPanel->setVisible(true);
				
				return false;
			}
		}
	}

	public function setObjectId($id)
	{
		$this->_objectId = $id;
		$this->setViewState("ObjectId", $id, null);
	}

	public function getObjectId()
	{
		if(is_null($this->_objectId))
			$this->_objectId = $this->getViewState("ObjectId", null);
		
		return $this->_objectId;
	}

	public function setDataSource($ds)
	{
		$this->setViewState("DataSource", $ds, array());
	}

	public function getDataSource()
	{
		return $this->getViewState("DataSource", array());
	}

	public function globalRefresh()
	{
		$this->populate();
	}

	/**
	 * Whether a component inside this page can have unlink methods
	 * into its rows.
	 *
	 * @return boolean
	 */
	public function isUnlink()
	{
		return false;
	}

	/**
	 * Whether a component inside this page can have methods which
	 * are active in the case it's inside a popup.
	 *
	 * @return boolean
	 */
	public function isPopup()
	{
		return true;
	}

	/**
	 * Whether a component inside this page can have delete methods.
	 *
	 * @return boolean
	 */
	public function isDelete()
	{
		return false;
	}

	public function populate($requestId = null)
	{
		if (is_null($requestId))
			$requestId = intval($this->getObjectId());

		$request = null;

		if ($requestId > 0)
			$request = ItemRequestQuery::create()
							->findPK($requestId);
			
		if (!($request instanceof ItemRequest))
		{
			$this->MainPanel->setVisible(false);
			$this->ErrorPanel->setVisible(true);
			
			return false;
		}
		
		$title = "---";
		$manifestation = $request->getManifestation();

		if ($manifestation instanceof Manifestation)
		{
			$title = $manifestation->getTrimmedTitle(150);
		}
		else
		{
			$item = $request->getItem();
			if ($item instanceof Item)
				$title = $item->getTrimmedTitle(150);
		}
		$this->Title->setText($title);
		
		$itemIds = $this->_requestmanager->getRequestMyCandidateItemIds($request->getDeliveryLibraryId(), 
																		$request->getMaxDistance(), 
																		$request->getManifestationId(), 
																		$request->getItemId(), 
																		$request->getIssueId());

		$gridData = array();
		$checkedFlag = (count($itemIds) == 1);
		
		foreach ($itemIds as $rowItemId)
		{
			$item = ItemQuery::create()
						->findPK($rowItemId);
			
			if (!($item instanceof Item))
				continue;
			
			$row = array();

			$collocationCombo = $item->getCollocationCombo($this->getUser()->getActualLibraryId());
			$row['Collocation'] = $collocationCombo;

			$inventoryNumber = $item->getCompleteInventoryNumber();
			$row['InventoryNumber'] = $inventoryNumber;

			$barcode = $item->getBarcode();
			$row['Barcode'] = $barcode;

			$row['ItemId'] = $item->getItemId();
			$row['Checked'] = $checkedFlag;

			$gridData[] = $row;
		}

		$this->Grid->setDataSource($gridData);
		$this->Grid->dataBind();

		$this->setDataSource($gridData);
	}

	public function onLoan($sender, $param)
	{
		$this->cleanMessageQueue();
		$toRefreshFlag = false;

		$itemIds = array();
		foreach($this->Grid->getItems() as $row)
		{
			if ($row->CheckColumn->CheckBox->getChecked())
			{
				$itemId = intval($row->ItemIdColumn->ItemId->getValue());
				if ($itemId > 0)
					$itemIds[] = $itemId;
			}
		}

		if (count($itemIds) > 0)
		{
			$request = null;
			$requestId = intval($this->getObjectId());

			if ($requestId > 0)
				$request = ItemRequestQuery::create()
								->findPK($requestId);

			if (is_null($request) || !($request instanceof ItemRequest ))
				return false;

			$ok = true;
			$patron = $request->getPatron();

			if ($patron instanceof Patron)
			{
				$loanObject = $patron;
				if ($this->_loanmanager->IsPatronAllowedToLoan($patron,null,true) == ClavisLoanManager::LOAN_PATRONNOTENABLED)
				{
					$this->getPage()->enqueueMessage(Prado::localize("L'utente {patron} NON è abilitato al prestito",
																		array('patron' => $patron->getReverseCompleteName())),
														ClavisMessage::ERROR);
					$ok = false;
				}
				elseif ($this->_loanmanager->IsPatronAllowedToLoan($patron,null,true) == ClavisLoanManager::LOAN_REACHEDMAX)
				{
					$this->getPage()->enqueueMessage(Prado::localize("L'utente {patron} ha superato il massimo numero di prestiti consentiti",
																		array('patron' => $patron->getReverseCompleteName())),
														ClavisMessage::ERROR);
					$ok = false;
				}
			}
			else	// destination is an external library
			{
				$externalLibrary = null;
				$externalLibraryId = intval($request->getExternalLibraryId());
				if ($externalLibraryId > 0)
					$externalLibrary = LibraryQuery::create()
											->findPK($externalLibraryId);
				$loanObject = $externalLibrary;
				if ($externalLibrary instanceof Library)
				{
					if ($this->_loanmanager->isExternalLibraryAllowedToLoan($externalLibraryId) != ClavisLoanManager::OK)
					{
						$this->getPage()->enqueueMessage(Prado::localize("Alla biblioteca {library} non sono permessi prestiti",
																			array(	'library' => $externalLibrary->getLabel(true, true, true))),
															ClavisMessage::ERROR);
						$ok = false;
					}
				}
				else	// fallback, destination is nor a patron nor an external library
				{
					$this->getPage()->enqueueMessage(Prado::localize("Errore: nella prenotazione con id: {requestId} non sono specificati né un utente né una biblioteca esterna come destinatari.<br />Riportare al fornitore del software, grazie",
																		array('requestId' => $request->getRequestId())),
														ClavisMessage::ERROR);
					$ok = false;
				}
			}

			if ($ok)	// possible
			{
				$clavisLibrarian = $this->getUser();
				$isExtra = ($loanObject instanceof Library);

				if ($isExtra)
				{
					$deliveryLibrary = $clavisLibrarian->getActualLibrary();
				}
				else
				{
					$deliveryLibrary = $request->getDeliveryLibrary();
				}
				
				$deliveryLibraryId = $deliveryLibrary->getLibraryId();

				foreach ($itemIds as $itemId)
				{
					$item = ItemQuery::create()
								->findPK($itemId);
					$dueDate = $this->_loanmanager->CalculateDueDate($item);

					if (($isItemAvailableReturnValue = $this->_loanmanager->IsItemAvailable($item, $deliveryLibraryId)) == ClavisLoanManager::OK)
					{
						// check for loanability per item's media + patron
						if ((!$isExtra)
								&& ($this->_loanmanager->IsPatronAllowedToLoan($patron, $itemId,true) == ClavisLoanManager::LOAN_REACHEDMAX))
						{	
							$this->getPage()->enqueueMessage(Prado::localize("L'esemplare con id: {itemId}, '{title}' [barcode: {barcode}] NON è prestabile all'utente {patron} perchè è stato superato il massimo numero di prestiti consentiti",
																				array(	'title' => $item->getTrimmedTitle(40),
																						'barcode' => $item->getBarcode(),
																						'patron' => $patron->getReverseCompleteName(),
																						'itemId' => $itemId)),
																ClavisMessage::ERROR);
							$ok = false;
						}
						
						if ($ok)
						{
							$loanResultValue = $this->_loanmanager->DoLoanItem(	$item, 
																				$loanObject, 
																				$clavisLibrarian, 
																				$deliveryLibrary, 
																				$request, 

																				$dueDate);
							switch ($loanResultValue)
							{
								case ClavisLoanManager::LOAN_LOANALREADYEXISTS:
									$this->getPage()->enqueueMessage(Prado::localize("Errore: un prestito è già in corso per l'esemplare '{title}' [barcode: {barcode}]",
																						array(	'title' => $item->getTrimmedTitle(40),
																								'barcode' => $item->getBarcode())),
																		ClavisMessage::ERROR);
									break;

								case ClavisLoanManager::RSV_ALREADYMANAGED:
									$this->getPage()->enqueueMessage(Prado::localize("Il prestito NON è possibile perchè l'esemplare '{title}' [barcode: {barcode}] è già in gestione ad un altro operatore",
																						array(	'title' => $item->getTrimmedTitle(40),
																								'barcode' => $item->getBarcode()),
																		ClavisMessage::ERROR));
									//$toRefreshFlag = true;
									break;

								case ClavisLoanManager::LOAN_READYTOLOAN:
									$labelText = Prado::localize("Esemplare '{title}' [barcode: {barcode}] pronto al prestito per '{patron}'",
										array('title' => $item->getTrimmedTitle(40),
											'barcode' => $item->getBarcode(),
											'patron' => ($isExtra
												? $loanObject->getLabel(true, true, true)	// external library
												: $loanObject->getCompleteName())));	// patron

									// ready-to-loan automatic notification
									if (ClavisParamQuery::getParam('CLAVISPARAM','AutoEmailLoanReady') == 'true' && $loanObject instanceof Patron)
									{
										$ret = NotificationHelper::sendNotificationEmail('readyforloan', $loanObject,
											$clavisLibrarian->getLibrarian(), $deliveryLibrary,
											array($item->getCurrentLoanId()));
										if ($ret) {
											$item->setNotifyCount($item->getNotifyCount() + 1);
											$item->save();
											$loan = $item->getLoanRelatedByCurrentLoanId();
											$loan->setNotifyCount($loan->getNotifyCount() + 1);
											$loan->save();
											$labelText .= Prado::localize(' - notificato automaticamente via email');
										}
									}
									$this->getPage()->enqueueMessage($labelText, ClavisMessage::CONFIRM);
									$toRefreshFlag = true;
									break;

								case ClavisLoanManager::LOAN_ILLREQUESTED:
									$this->getPage()->enqueueMessage(Prado::localize("Esemplare '{title}' [barcode: {barcode}] pronto al transito",
																						array(	'title' => $item->getTrimmedTitle(40),
																								'barcode' => $item->getBarcode())),
																		ClavisMessage::CONFIRM);
									$toRefreshFlag = true;
									break;

								case ClavisLoanManager::LOAN_EXTRASYSTEMINCONGRUENCY:
									$this->getPage()->enqueueMessage(Prado::localize("Esemplare '{title}' [barcode: {barcode}] non prestato perché esiste una incongruenza nei dati su utente e biblioteca esterna.<br />Riportare al fornitore del software, grazie",
																						array(	'title' => $item->getTrimmedTitle(40),
																								'barcode' => $item->getBarcode())),
																		ClavisMessage::ERROR);
									break;

								case ClavisLoanManager::OK:
								case ClavisLoanManager::LOAN_LOANED:
								case true:
									$this->getPage()->enqueueMessage(Prado::localize("Esemplare '{title}' [barcode: {barcode}] in prestito a '{patron}'",
																						array(	'title' => $item->getTrimmedTitle(40),
																								'barcode' => $item->getBarcode(),
																								'patron' => ($isExtra
																												? $loanObject->getLabel(true, true, true)	// external library
																												: $loanObject->getCompleteName()))),			// patron
																		ClavisMessage::CONFIRM);									
									
									$toRefreshFlag = true;
									break;

								case ClavisLoanManager::ERROR:
								case false:
									$this->getPage()->enqueueMessage(Prado::localize("Errore generico: esemplare n. {itemId} '{title}' NON prestato",
																						array(	'itemId' => $item->getId(),
																								'title' => $item->getTitle())),
																		ClavisMessage::ERROR);

									break;

								default:
									break;
							}
						}
					}
					else
					{
						// TODO: differenziare casistiche
//						$this->getPage()->enqueueMessage(Prado::localize("L'esemplare con id: {itemId}, '{title}' [barcode: {barcode}] NON è disponibile",
//																			array(	'title' => $item->getTrimmedTitle(40),
//																					'barcode' => $item->getBarcode(),
//																					'itemId' => $item->getId())),
//															ClavisMessage::ERROR);
						
						$manifestation = $item->getManifestation();
						if ($manifestation instanceof Manifestation)
						{
							if ($isItemAvailableReturnValue == ClavisLoanManager::LOAN_MANIFESTATIONNOTLOANABLESINCE)
								$this->enqueueMessage(Prado::localize('La notizia è disponibile solo dal {date}',
																		array('date' => Clavis::dateFormat($manifestation->getLoanableSince('U'),'shortdate'))),
														ClavisMessage::ERROR);

							//if (!$this->_loanmanager->IsRatingAllowed($manifestation, $selectedPatron))
							if ($isItemAvailableReturnValue == ClavisLoanManager::LOAN_PATRONNOTAGE)
								$this->enqueueMessage(Prado::localize("La notizia è disponibile solo per gli utenti con piu' di {rating} anni",
																		array('rating' => $manifestation->getRating())),
														ClavisMessage::ERROR);
						}
					}
				}
			}	// end of possible cases
		}
		else
		{	
			$this->enqueueMessage(Prado::localize('Non è stata eseguita nessuna operazione: nessun esemplare selezionato.'),
													ClavisMessage::WARNING);
		}
		
		if ($toRefreshFlag)
			$this->getApplication()->getSession()->add('UpdateItemRequests', true);

		$this->flushDelayedMessage();

//		$scriptMgr = $this->getPage()->getClientScript();
//		$scriptMgr->registerEndScript('popupClose','onClose();');
		$this->getPage()->getClientScript()->registerEndScript(__CLASS__.'_js','onReturn(\'\',\'\',true);');
	}

}
