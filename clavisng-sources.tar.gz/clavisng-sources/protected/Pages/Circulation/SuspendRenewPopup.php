<?php

/**
 * SuspendRenewPopup
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @version 2.7
 * @package Popups.Circulation
 * @since 2.1
 */

class SuspendRenewPopup extends ClavisPagePopup
{
	public $_module = 'CIRCULATION';

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallBack())
		{
			$ids = array();
			$objectType = $this->Request['objectType'];
			$param = $this->Request['param'];

			if ($objectType == 'Array')
			{
				$ids = unserialize($param);
				if (count($ids) == 1)
				{
					$loan = LoanPeer::retrieveByPK($ids[0]);
					if ($loan instanceof Loan)
						$ids = array($loan->getItemId());
					else
						$ids = array();
				}
			}
			else
			{
				$itemId = intval($param);
				if ($itemId > 0)
					$ids = array($itemId);
			}

			$this->setItemIds($ids);
			$this->populate();
		}
	}

	public function setItemIds($itemId)
	{
		$this->setViewState("ItemId", $itemId, array());
	}

	public function getItemIds()
	{
		return $this->getViewState("ItemId", array());
	}

	public function isUnlink()
	{
		return false;
	}
	
	public function populate()
	{
		$okFlag = false;
		$ids = $this->getItemIds();

		if (count($ids) == 1)
		{
			$this->SingleLoanPanel->setVisible(true);
			$this->MultiLoanPanel->setVisible(false);

			$item = ItemPeer::retrieveByPK($ids[0]);
			if ($item instanceof Item)
			{
				$okFlag = true;
				$title = $item->getTitle();

				$dueDate = $item->getDueDate('U');
				$this->Title->setText($title);
				$this->Date->setValue($dueDate);
			}
		}
		elseif (count($ids) > 1)
		{
			$this->SingleLoanPanel->setVisible(false);
			$this->MultiLoanPanel->setVisible(true);
			$this->LoanGrid->initialReload($ids);
			$okFlag = true;
		}

		if (!$okFlag)
		{
			$this->Title->setText('');
			$this->getPage()->writeMessage("Nessun parametro è stato passato al popup", ClavisMessage::ERROR);
		}
	}

	public function onSuspendRenew($sender, $param)
	{
		$this->getPage()->cleanMessageQueue();
		$okFlag = false;
		
		$ids = $this->getItemIds();
		if (count($ids) > 1)
		{
			$newArr = array();
			foreach ($ids as $loanId)
			{
				$loan = LoanPeer::retrieveByPK($loanId);
				if (!is_null($loan))
				{
					$iId = intval($loan->getItemId());
					if ($iId > 0)
						$newArr[] = $iId;
				}
			}
			$ids = $newArr;
		}

		foreach ($ids as $itemId)
		{
			$item = null;
			if ($itemId > 0)
				$item = ItemPeer::retrieveByPK($itemId);

			if ($item instanceof Item)
			{
				$clavisLibrarian = $this->getUser();
				$patron = $item->getPatron();

				$loanmanager = $this->getApplication()->getModule('loan');
				
				if ($loanmanager->IsItemLoaned($item))
				{
					$itemtit = $item->getCompleteTitle();
					if (!$itemtit)
						$itemtit = Prado::localize('(nessun titolo)');

					switch ($loanmanager->doDisableRenew($itemId, $clavisLibrarian))
					{
						case ClavisLoanManager::OK:
							$this->getPage()->enqueueMessage(Prado::localize("L'esemplare con titolo '{title}' [barcode: {barcode}, inv: {inv}] è stato sospeso dalle proroghe.",
														array('title' => $itemtit,
																'inv' => $item->getCompleteInventoryNumber(),
																'barcode' => $item->getBarcode())),
														$messageType = ClavisMessage::INFO);
							$ok = true;
						break;

						case ClavisLoanManager::ERROR:
							$this->getPage()->enqueueMessage(Prado::localize("L'operazione di sospensione di proroga è fallita"),
															ClavisMessage::ERROR);
						break;

						default:
							$this->getPage()->enqueueMessage(Prado::localize("Errore sconosciuto durante la sospensione di proroga"),
															ClavisMessage::ERROR);
						break;
					}
				}
				else
				{
					$this->getPage()->enqueueMessage(Prado::localize("L'esemplare con id = {id} e barcode = '{barcode}' NON E' IN PRESTITO !",
													array('id' => $itemId,
															'barcode' => $item->getBarcode())),
													ClavisMessage::ERROR);
				}
			}
			else
				$this->getPage()->enqueueMessage(Prado::localize("Errore nel passaggio dei parametri, contattare il fornitore del software."),
																ClavisMessage::ERROR);
		}

		if ($okFlag)
			$this->getApplication()->getSession()->add('UpdateItemId', $itemId);

		$this->flushDelayedMessage();
		$this->getPage()->getClientScript()->registerEndScript(__CLASS__.'_js','onReturn(\'\',\'\',true);');
	}
	
}
