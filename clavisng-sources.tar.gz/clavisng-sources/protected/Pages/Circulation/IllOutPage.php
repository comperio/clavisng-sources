<?php
/**
 * IllOutPage class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info
 * @comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Pages.Circulation
 */

/**
 * IllOutPage class
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.7
 * @package Pages.Circulation
 * @since 2.3
 */
class IllOutPage extends ClavisPage
{
	public $_module = 'CIRCULATION';
	protected $_loanmanager;

	private $_toLibraryId;
	private $_loanStatus;

	private function initVars()
	{
		$this->_loanmanager = $this->getApplication()->getModule('loan');
	}
	
	public function onInit($param)
	{
		parent::onInit($param);
		$this->initVars();

		if (!$this->getPage()->getIsPostBack()
				&& !$this->getPage()->getIsCallBack())
		{
			$this->doCleanFilters();
		}
		
//		$this->ReadyForTransitGrid->setLoanStatusMode(array(	ItemPeer::LOANSTATUS_READYFORTRANSIT,
//																ItemPeer::LOANSTATUS_READYFORTRANSITTOHOME ));
	}

	/**
	 * It manages the mechanism of setting (resetting/initialization) the
	 * dropdowns which perform as filters for the population of the
	 * loans grid.
	 *
	 * @param TEventParameter $param
	 */
	public function onLoad($param)
	{
		parent::onLoad($param);

		$this->_toLibraryId = $this->getToLibraryId();
		$this->_loanStatus = $this->getLoanStatus();

		//$this->checkLoanStatusMode();
	
		if (!$this->getPage()->getIsPostBack())
		{
			$librariesWithBlank = LibraryPeer::getLibrariesHashWithBlank(null, null, true, 35);
			$this->ToLibrary->setDataSource($librariesWithBlank);
			$this->ControlSwitches->dataBind();
			$this->globalRefresh();

			$this->focusToComponent($this->ReadyForTransitBarcodeTextbox);
		}
		
		/**
		 * Actions we can do on a page reload (postback),
		 * after an action (i.e.: a popup making an operation)
		 */
		if ($this->getPage()->getIsPostBack() 
				|| $this->getPage()->getIsCallback())
		{
			$updateItemId = intval($this->getApplication()->getSession()->itemAt('UpdateItemId'));

			if ($updateItemId > 0)
			{
				$this->getApplication()->getSession()->remove('UpdateItemId');
				$this->globalRefresh();
			}
		}
	}

 	/**
 	 * It sets the property $_toLibraryId
 	 *
 	 * @param int $lib
 	 */
 	public function setToLibraryId($lib)
 	{
 		$this->_toLibraryId = $lib;
 		$this->setViewState('toLibraryId', $this->_toLibraryId, null);
 	}

 	/**
 	 * It returns the property $_toLibraryId
 	 *
 	 * @return int
 	 */
 	public function getToLibraryId()
 	{
 		if (($lib = $this->_toLibraryId) == null)
 		{
 			$lib = $this->getViewState('toLibraryId', null);
 			$this->_toLibraryId = $lib;
 		}

		return $lib;
 	}

  	/**
 	 * It sets the property $_fromLibraryId
 	 *
 	 * @param int $lib
 	 */
 	public function setFromLibraryId($lib)
 	{
 		$this->_fromLibraryId = $lib;
 		$this->setViewState('fromLibraryId', $this->_fromLibraryId, null);
 	}

  	/**
 	 * It returns the property $_fromLibraryId
 	 *
 	 * @return int
 	 */
 	public function getFromLibraryId()
 	{
 		if (($lib = $this->_fromLibraryId) == null)
 		{
 			$lib = $this->getViewState('fromLibraryId', null);
 			$this->_fromLibraryId = $lib;
 		}

		return $lib;
 	}

  	/**
 	 * It sets the property $_loanStatus
 	 *
 	 * @param string $loanStatus
 	 */
 	public function setLoanStatus($loanStatus)
 	{
 		$this->_loanStatus = $loanStatus;
 		$this->setViewState('loanStatus', $this->_loanStatus, null);
 	}

 	/**
 	 * It returns the property $_loanStatus
 	 *
 	 * @return string
 	 */
 	public function getLoanStatus()
 	{
 		if (($loanStatus = $this->_loanStatus) == null)
 		{
 			///$loanStatus = $this->getViewState('loanStatus', null);
 			$this->_loanStatus = $loanStatus;
 		}

		return $loanStatus;
 	}

 	/**
 	 * Does this page have popups inside?.....
 	 *
 	 * @return boolean
 	 */
 	public function isPopup()
 	{
 		return false;
 	}

 	/**
 	 * It refreshes all the components (grids) in the page,
 	 * altogether.
 	 *
 	 */
 	public function globalRefresh()
 	{
		$toLibraryId = $this->ToLibrary->getSelectedValue();
		$patronId = $this->HiddenValue->getValue();
		$barcode = trim($this->BarcodeFilter->getSafeText());

		$outDateFrom = ($this->OutDateFrom->getText() != ''
							? $this->OutDateFrom->getTimeStamp()
							: null);
		
		$outDateTo = ($this->OutDateTo->getText() != ''
							? $this->OutDateTo->getTimeStamp()
							: null);

//		$transitFilter = $this->TransitFilter->getChecked();
//		$returnFilter = $this->ReturnFilter->getChecked();
		
 		$this->ReadyForTransitGrid->setFilters(	$barcode,
												$toLibraryId,
												$patronId,
												$outDateFrom,
												$outDateTo,
				
												null,
												null,
												null,
												null,
												null,

												null,
												null);//,
//												$transitFilter,
//												$returnFilter);
		
		$this->checkLoanStatusMode();
		
 		$this->ReadyForTransitGrid->resetDataSource();
 	}

	protected function checkLoanStatusMode()
	{
		$loanStatusModeArray = array();
		
		if ($this->TransitFilter->getChecked() == true)
			$loanStatusModeArray[] = ItemPeer::LOANSTATUS_READYFORTRANSIT;

		if ($this->ReturnFilter->getChecked() == true)
			$loanStatusModeArray[] = ItemPeer::LOANSTATUS_READYFORTRANSITTOHOME;
		
		$this->ReadyForTransitGrid->setLoanStatusMode($loanStatusModeArray);	
	}
	
 	/**
 	 * It updates the page in the case a new patron is choosen.
 	 *
 	 * @param TControl $sender
 	 * @param TEventParameter $param
 	 */
 	public function onPatronIdChanged($sender, $param)
 	{
 		$patron = null;
 		$id = intval($this->HiddenValue->getValue());
 		if ($id > 0)
 			$patron = PatronQuery::create()
						->findPK($id);
 		if ($patron instanceof Patron)
 		{
 			$completeName = $patron->getCompleteName();
 			$barcode = trim($patron->getBarcode());
 			if ($barcode != '')
 				$barcode = ' (' . $barcode . ')';

 			$this->PatronLabel->setText($completeName . $barcode);
 			$this->setPatronChoiceDone(true, $param);
 		}
 	}
	
 	/**
 	 * It resets (also visually) the choice of patron.
 	 *
 	 * @param TControl $sender
 	 * @param TEventParameter $param
 	 */
	public function onResetPatron($sender, $param)
	{
		$this->HiddenValue->setValue('');
		$this->HiddenValue->setValue('');
 		$this->PatronLabel->setText('');
 		
		$this->setPatronChoiceDone(false, $param);
	}

	private function setPatronChoiceDone($flag, $param)
 	{
		$this->PatronLabel->setVisible($flag);
		$this->PatronChoiceButton->setVisible(!$flag);
		$this->PatronResetButton->setVisible($flag);

		if (!is_null($param) && $this->getPage()->getIsCallback())
			$this->PatronPanel->render($param->getNewWriter());
 	}
	
 	/**
 	 * It resets (also visually) the date choice.
 	 *
 	 * @param TControl $sender
 	 * @param TEventParameter $param
 	 */
	public function onResetOutDate($sender, $param)
	{
		$this->OutDateFrom->setText('');
 		$this->OutDateTo->setText('');

 		if (!is_null($param))
			$this->OutDatePanel->render($param->getNewWriter());
	}

	public function onCleanFilters($sender, $param)
	{
		$this->doCleanFilters();
		$this->globalRefresh();
	}
	
	private function doCleanFilters()
	{
		$this->onResetPatron(null, null);
		$this->onResetOutDate(null, null);
		$this->ToLibrary->setSelectedIndex(0);
		$this->BarcodeFilter->setText('');
		
		$this->TransitFilter->setChecked(true);
		$this->ReturnFilter->setChecked(true);
	}
	
	/**
	 * Callback from update button in the page.
	 * It performs retrieving of filters and next it populates.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onSubmit($sender, $param)
	{
		$this->globalRefresh();
	}

	public function onTransit($sender, $param)
	{
		$input = $this->ReadyForTransitBarcodeTextbox->getSafeText();
		$input = trim($input);
		if ($input != '')
		{
			$this->ReadyForTransitBarcodeTextbox->setText('');
			$readyToMove = $this->ReadyForTransitGrid->searchCodesIntoDatasource($input);
		}
		else
		{
			$readyToMove = $this->ReadyForTransitGrid->getItemsWithDueDate();
		}

		if (count($readyToMove) == 0)
		{
			$this->getPage()->writeMessage(Prado::localize('Nessun elemento da processare riconosciuto come valido'),
												ClavisMessage::ERROR);
			
			$this->focusToComponent($this->ReadyForTransitBarcodeTextbox);
			
			return false;
		}

		$clavisLibrarian = $this->getUser();
		$okCount = 0;
		$failedCount = 0;
		$okString = '';
		$failedString = '';

		/* @var $item Item */
		foreach ($readyToMove as $row)
		{
			$item = $row['item'];
			$barcode = $item->getBarcode();

			$result = $this->_loanmanager->DoReadyToMove2MovingItem($item, $clavisLibrarian);
			$itemDataString = '<br />&nbsp;- ' . $item->getTrimmedTitle(40) . ($barcode == '' ? '' : ' (' . Prado::localize('barcode') . ': ' . $barcode) . ')';

			if ($result == ClavisLoanManager::OK)
			{
				$okCount++;
				$okString .= $itemDataString;
			}
			else
			{
				$failedCount++;
				$failedString .= $itemDataString;
			}
		}

		$errorCode = ClavisMessage::ERROR;
		if (($okCount == 0) && ($failedCount == 0))
		{
			$errorCode = ClavisMessage::INFO;
		}
		else
		{
			if ($failedCount > 0)
				$errorCode = ClavisMessage::WARNING;
			else
				$errorCode = ClavisMessage::CONFIRM;
		}
		
		$messageText = '';

		if ($okCount > 0)
			$messageText .= (1 == $okCount)
								? Prado::localize('1 esemplare in transito')
								: Prado::localize('{count} esemplari in transito',
														array('count' => $okCount));

		if ($failedCount > 0)
		{
			if ($okCount > 0)
				$messageText .= ' / ';
			
			$messageText .= (1 == $failedCount)
								? Prado::localize('1 esemplare NON in transito')
								: Prado::localize('{count} esemplari NON in transito',
														array('count' => $failedCount));
		}

		if (($okString != '')
				|| ($failedString != ''))
		{
			$messageText .= '&nbsp;&nbsp;&nbsp;&nbsp;<br /><br />';
			if ($okString != '')
				$messageText .= Prado::localize('In transito') . ':<br />' . $okString;

			if ($failedString != '')
				$messageText .= ($okString != '' ? '<br /><br />' : '') . Prado::localize('Operazione fallita per') . ':<br />' . $failedString;
		}
		else
		{
			$messageText = Prado::localize('Nessuna operazione è stata effettuata');
			$errorCode = ClavisMessage::ERROR;
		}

		$this->getPage()->writeMessage($messageText, $errorCode);
		$this->focusToComponent($this->ReadyForTransitBarcodeTextbox);

		if ($okCount > 0)
		{
			$this->ReadyForTransitGrid->resetDataSource();

			if (is_null($param))
				$writer = $this->createWriter();
			else
				$writer = $param->getNewWriter();
				
			$this->ReadyForTransitGridPanel->render($writer);
		}
	}

	private function focusToComponent($component = null)
	{
		if (is_null($component))
			return false;

		if ($this->getPage()->getIsCallback())
		{
			$page = $this->Application->getservice('page')->RequestedPage;
			$page->CallbackClient->callClientFunction("Prado.Element.focus", array($component->getClientID()));
		}
		else
		{
			$this->UserFocus->setFocusComponent($component);
		}
	}
	
	public function onPrintJRP($sender, $param) 
	{
		$datasource = $this->ReadyForTransitGrid->getCheckedItemsItemId(true, true);     // all + reset
		$ids = implode(',', $datasource);	

		$this->JRPBox->setObjectId($ids);
		$this->JRPBox->addOptionalParam('P_ORDER', $this->ReadyForTransitGrid->getSortingExpression());		
		$this->JRPBox->addOptionalParam('P_ORDERDIR', $this->ReadyForTransitGrid->getSortingDirection());
		
		$this->JRPBox->printReport();
	}
	
}
