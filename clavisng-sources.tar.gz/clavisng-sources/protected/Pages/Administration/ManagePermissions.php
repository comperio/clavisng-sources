<?php

/**
 * ManagePermissions Page class Module ADMIN
 *
 * @author Max Pigozzi <mpigozzi@e-portaltech.it>
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2008 ePortal Technologies
 * @copyright Copyright &copy; 2009 Comperio srl
 */

class ManagePermissions extends ClavisPage {

	public $_module = 'ADMIN';

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsPostBack())
		{
			$this->dataBind();
		}
	}

	public function onCreateNewACLDialog($sender, $param)
	{
		$this->globalEditCancel();
		$this->ACLGrid->addNewACL();
	}

	public function globalEditCancel()
	{
		$this->ACLGrid->cancelACLEdit(null,null);
	}

}
