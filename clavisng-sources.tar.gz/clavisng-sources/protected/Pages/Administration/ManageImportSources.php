<?php

/**
 * ManaageImportSources class
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2011 Comperio srl
 * @version 2.7
 * @package Pages
 * @since 2.5.0
 */

Prado::using('Application.Common.ImportDrivers.*');

class ManageImportSources extends ClavisPage {

	public $_module = 'ADMIN';

	public function onLoad($param) {
		parent::onLoad($param);
		if (!$this->getIsPostBack() && !$this->getIsCallback()) {
			$this->dataBind();
		}
	}
}
