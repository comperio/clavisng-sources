<?php
/**
 * ManageParameters class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @author Ciro Mattia Gonano
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 ePortal Technologies
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.8.9
 * @package Pages.Administration
 */

/**
 * ManageParameters Class
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @author Ciro Mattia Gonano
 * @version 2.8.9
 * @package Pages.Administration
 * @since 2.3
 */
class ManageParameters extends ClavisPage
{
	public $_module = 'ADMIN';
	private $_llibrary_active = false;
	private $_llibrary_distances = array(-1 => '---');

	public function onLoad($param)
	{
		parent::onLoad($param);

		// first page cycle
		if (!$this->getIsPostBack() 
				&& !$this->getIsCallback())
		{
			$profiles = array();

			$allAppProfile = AppProfileQuery::create()
					->select(array('profile_id', 'name', 'profiles_control'))
					->find();

			foreach ($allAppProfile as $ap)
			{
				//$profilesControls[] = array('ProfileLabel' => $ap['name'] . ' (' . $ap['profile_id'] . ')');
				$profiles[$ap['profile_id']] = array(	'profileId' => $ap['profile_id'],
														'profileLabel' => $ap['name'],
														'profilesControl' => $ap['profiles_control'] );
			}

			$this->setProfiles($profiles);

            $ds = LookupValuePeer::getLookupClassValues("PATRONLOANCLASS");
            $ds["X"] = Prado::localize("Extra sistema");
            $this->PatronLoanClass->setDataSource($ds);
            $this->PatronLoanClass->dataBind();
            $this->PatronLoanClass->setSelectedIndex(0);
			$this->populate();
		}
	}
	
	public function setProfiles($param)
	{
		$this->setViewState("ProfilesSession", $param, array());
	}

	public function getProfiles()
	{
		return $this->getViewState("ProfilesSession", array());
	}
	
	public function populate()
	{
		if ($this->_llibrary_active = LLibraryPeer::isEnabled())
			$this->_llibrary_distances = LLibraryPeer::calculateLLibraryDistanceHash();

		$codes = $labels = array();

		foreach (ClavisParamQuery::create()->findByParamClass('DBVERSION') as $param)
		{
			$name = explode('_',$param->getParamName());
			$value = $param->getParamValue();
		
			switch ($name[0])
			{
				case 'CORE':
					$this->DbVersionCore->setText($param->getParamValue());
			
					break;
				
				case 'UNIMARC':
					switch ($name[1])
					{
						case 'CODES':
							$codes[] = $name[2].':'.$value;
					
							break;
						
						case 'LABELS':
							$labels[] = $name[2].':'.$value;
						
							break;
						
					}
					
					break;
			}
		}

        $selPatronLoanClass = $this->PatronLoanClass->getSelectedValue();

		$this->DbVersionCodes->setText(implode(' | ',$codes));
		$this->DbVersionLabels->setText(implode(' | ',$labels));
		
		$userClasses = LookupValuePeer::getLookupClassValues('PATRONLOANCLASS');
		$this->AutoRevokeGraceUserClasses->setDataSource($userClasses);
		$this->AutoRevokeGraceUserClasses->dataBind();
		
		$libraries = LibraryPeer::getLibrariesHash(	array(LibraryPeer::BLANKVALUE),
													array('---'),
													null,
													true );
		
		$this->ExtraNodeLibrary->setDataSource($libraries);
		$this->ExtraNodeLibrary->dataBind();
		
		$loan_params = array('0' => array(	'key' => 0,
											'label' => '-',
											'loan_duration' => 0,
											'max_loans' => 0,
											'renewal_duration' => 0,
			
											'max_renewals' => 0,
											'request_duration' => 0,
											'max_requests' => 0,
                                            'max_operations' => 0,
                                            'renew_from' => 0,
            
											'renew_to' => 0,
                                            'alert_days' =>0,
											'max_distance' => 0 ));
		
		foreach (LookupValuePeer::getLookupClassValues('ITEMMEDIATYPE') as $key => $value)
		{	
				$loan_params[$key] = array(	'key' => $key,
											'label' => $value,
											'loan_duration' => 0,
											'max_loans' => 0,
											'renewal_duration' => 0,
					
											'max_renewals' => 0,
											'request_duration' => 0,
											'max_requests' => 0,
											'max_operations' => 0,
											'renew_from' => 0,
					
											'renew_to' => 0,
											'alert_days' =>0,
											'max_distance' => -1 );
		}
		
		foreach (ClavisParamPeer::getClassParams('LOANDURATION_' . $selPatronLoanClass) as $key => $value)
		{		
			if (array_key_exists($key, $loan_params))
				$loan_params[$key]['loan_duration'] = $value;
		}
		
		foreach (ClavisParamPeer::getClassParams('MAXLOANSALLOWED_' . $selPatronLoanClass) as $key => $value)
		{		
			if (array_key_exists($key, $loan_params))
				$loan_params[$key]['max_loans'] = $value;
		}

		foreach (ClavisParamPeer::getClassParams('LOANRENEWDURATION_' . $selPatronLoanClass) as $key => $value)
		{
			if (array_key_exists($key, $loan_params))
				$loan_params[$key]['renewal_duration'] = $value;
		}

		foreach (ClavisParamPeer::getClassParams('MAXLOANRENEWS_' . $selPatronLoanClass) as $key => $value)
		{		
			if (array_key_exists($key, $loan_params))
				$loan_params[$key]['max_renewals'] = $value;
		}

		foreach (ClavisParamPeer::getClassParams('REQUESTDURATION_' . $selPatronLoanClass) as $key => $value)
		{
			if (array_key_exists($key, $loan_params))
				$loan_params[$key]['request_duration'] = $value;
		}

		foreach (ClavisParamPeer::getClassParams('MAXLOANRESERVATIONS_' . $selPatronLoanClass) as $key => $value)
		{
			if (array_key_exists($key, $loan_params))
				$loan_params[$key]['max_requests'] = $value;
		}

        foreach (ClavisParamPeer::getClassParams('RENEWFROM_' . $selPatronLoanClass) as $key => $value)
		{
            if (array_key_exists($key, $loan_params))
                $loan_params[$key]['renew_from'] = $value;
		}

        foreach (ClavisParamPeer::getClassParams('RENEWTO_' . $selPatronLoanClass) as $key => $value)
		{
            if (array_key_exists($key, $loan_params))
                $loan_params[$key]['renew_to'] = $value;
		}

        foreach (ClavisParamPeer::getClassParams('MAXOPERATIONS_' . $selPatronLoanClass) as $key => $value)
		{
            if (array_key_exists($key, $loan_params))
                $loan_params[$key]['max_operations'] = $value;
		}

        foreach (ClavisParamPeer::getClassParams('ALERTDAYS_' . $selPatronLoanClass) as $key => $value)
		{
            if (array_key_exists($key, $loan_params))
                $loan_params[$key]['alert_days'] = $value / 86400;
		}

		foreach (ClavisParamPeer::getClassParams('MAXDISTANCE_' . $selPatronLoanClass) as $key => $value)
		{
			if (array_key_exists($key, $loan_params))
				$loan_params[$key]['max_distance'] = $value;
		}

		$this->LoanParamsRepeater->setDataSource($loan_params);
		
		$this->RenewalLimitBefore->setText(floor(ClavisParamPeer::getParam('LOANRENEWALTIME', 'FROM') / 86400));
		$this->RenewalLimitAfter->setText(floor(ClavisParamPeer::getParam('LOANRENEWALTIME', 'UNTIL') / 86400));
		$this->ExpiringLoanLimit->setText(floor(ClavisParamPeer::getParam('LOANEXPIRING', 0) / 86400));
		$this->ReadyToLoanWait->setText(ClavisParamPeer::getParam('READYTOLOANWAIT', 0));
		$this->MaxOperations->setText(ClavisParamPeer::getParam('MAXTOTALOPERATIONS', 0));
        $this->MaxExtraLoans->setText(ClavisParamPeer::getParam('MAXEXTRALOANS', 0));
        $this->AutoRevokeGraceDays->setText(ClavisParamPeer::getParam('AUTOREVOKE_GRACE_DAYS', 0));
		$this->AutoRevokeGraceSolicits->setText(ClavisParamPeer::getParam('AUTOREVOKE_GRACE_SOLICITS', 0));
		$graceUserClasses = @unserialize(ClavisParamPeer::getParam('AUTOREVOKE_GRACE_USERCLASSES', 0));
		
		if (!is_array($graceUserClasses))
			$graceUserClasses = array();
		
		$this->AutoRevokeGraceUserClasses->setSelectedValues($graceUserClasses);
		$this->NewItemUnloanGraceTime->setText(intval(ClavisParamPeer::getParam('NEWITEM_UNLOAN_GRACETIME', 0)) / 86400);
		$this->ExtraRenewConfirmEmail->setChecked(ClavisParamPeer::getParam('EXTRARENEW_CONFIRMEMAIL', 0) == 1);
		$this->ExtraRenewalDuration->setText(ClavisParamPeer::getParam('EXTRASYSTEMADDDURATION', 0));
		$nodelib = ClavisParamPeer::getParam('EXTRASYSTEMNODELIBRARY', 0);
		
		if (array_key_exists($nodelib,$libraries))
			$this->ExtraNodeLibrary->setSelectedValue($nodelib);
		
		$this->LibraryDistanceActive->setChecked(ClavisParamPeer::getParam('LLIBRARY_ACTIVE', 0) == 1);
		$this->MaxLibraryDistance->setText(ClavisParamPeer::getParam('MAX_LLIBRARY_DISTANCE', 0));
		$this->MaxLibraryBasin->setText(ClavisParamPeer::getParam('MAX_LLIBRARY_BASIN', 0));
		$this->MediaPackageMax->setText(ClavisParamPeer::getParam('MEDIAPACKAGE_SIZE_MAX', 0));
		$this->MLOLAPIKey->setText(ClavisParamPeer::getParam('MLOL_API_KEY', 0));
		$this->MLOLPortalId->setText(ClavisParamPeer::getParam('MLOL_PORTAL_ID', 0));
		
		// Sys params
		$this->populateSysParams();
		
		// Config
		$this->populateConfig();

		$this->dataBind();
	}

	public function dataBindLoanParamsRepeater($sender,$param)
	{
		$item = $param->Item;
	
		if (($item->ItemType === 'Item') 
				|| ($item->ItemType==='AlternatingItem')) 
		{
			if ($this->_llibrary_active)
			{
				$item->MaxDistance->setDataSource($this->_llibrary_distances);
				$item->MaxDistance->dataBind();
			} 
			else 
			{
				$item->MaxDistance->setEnabled(false);
			}
		}
	}
	
	private function populateSysParams()
	{
		$params = ClavisParamQuery::getClassParams('CLAVISPARAM');
	
		if (count($params) < 1)
			$params = $this->convertParamsFromXMLtoDB();

		// load profile dropdown
		$this->DefaultLibrarianProfile->setDataSource(AppProfileQuery::create()->orderByProfileId()->find());
		$this->DefaultLibrarianProfile->dataBind();

		$this->Maintenance->setChecked($params['Maintenance'] == 'true');
		$this->BaseUrl->setText($params['BaseUrl']);
		$this->OpacUrl->setText($params['OPACUrl']);
		$this->SiteTitle->setText($params['SiteTitle']);
		$this->SiteOwner->setText($params['SiteOwner']);
		$this->AdminEmail->setText($params['AdminEmail']);
		$this->ReportEmail->setText($params['ReportEmail']);
		$this->RemoteCoverServer->setText($params['RemoteCoverServer']);
		$this->NetManager->setText($params['NetManager']);
		$this->ClavisClientHost->setText($params['ClavisClientHost']);
		$this->ClavisClientPort->setText($params['ClavisClientPort']);
		$this->BookSellersServerUrl->setText($params['BookSellersServerUrl']);

        $this->InjectHeaderHTML->setText($params['InjectHeaderHTML']);
        $this->InjectStartBodyHTML->setText($params['InjectStartBodyHTML']);
        $this->InjectEndBodyHTML->setText($params['InjectEndBodyHTML']);

		$this->ExpireOldBulletinLimit->setText($params['ExpireOldBulletinLimit']);
		$this->ReservationResetValue->setText($params['ReservationResetValue']);
		
		$currencies = array();
		
		foreach(CultureInfo::getInstance(Prado::getApplication()->getGlobalization()->getCulture())->getCurrencies() as $icur => $cur)
			$currencies[$icur] = "$cur[1] ($cur[0])";
		
		$this->SystemCurrency->setDataSource($currencies);
		$this->SystemCurrency->setSelectedValue($params['SystemCurrency']);
		
		$this->AcquisitionMaxPriceLimit->setText($params['AcquisitionMaxPriceLimit']);

		$chanList = array();
		
		if ($params['EnableChannelSnailmail'] == 'true')
			$chanList[] = 'EnableChannelSnailmail';
		
		if ($params['EnableChannelEmail'] == 'true')
			$chanList[] = 'EnableChannelEmail';
		
		if ($params['EnableChannelSMS'] == 'true')
			$chanList[] = 'EnableChannelSMS';
		
		if ($params['EnableChannelPhone'] == 'true')
			$chanList[] = 'EnableChannelPhone';
		
		if ($params['EnableChannelPortal'] == 'true')
			$chanList[] = 'EnableChannelPortal';
		
		if ($params['EnableChannelFax'] == 'true')
			$chanList[] = 'EnableChannelFax';
		
		if ($params['EnableChannelIM'] == 'true')
			$chanList[] = 'EnableChannelIM';
		
		$this->EnabledChannelList->setSelectedValues($chanList);

		if ($this->getUser()->getIsSuperAdmin())
			$this->ContractAlertDaysBefore->setText($params['ContractAlertDaysBefore']);
		
		$this->ZebraAutoReceipt->setChecked($params['ZebraAutoReceipt'] == 'true');
		$this->ZebraAutoRequest->setChecked($params['ZebraAutoRequest'] == 'true');
		$this->AutoItemCallNumber->setChecked($params['AutoItemCallNumber'] == 'true');
		$this->AutoCardExpireCheck->setChecked($params['AutoCardExpireCheck'] == 'true');
		$this->AutoLateLoanCheck->setChecked($params['AutoLateLoanCheck'] == 'true');

		$this->MailSentFrom->setSelectedValue($params['MailSentFrom']);
		$this->SMSSentFrom->setSelectedValue($params['SMSSentFrom']);
		$this->AutoEmailOnRevoke->setChecked($params['AutoEmailOnRevoke'] == 'true');
		$this->AutoEmailLoanExpiring->setChecked($params['AutoEmailLoanExpiring'] == 'true');
		$this->AutoEmailLoanExpired->setChecked($params['AutoEmailLoanExpired'] == 'true');
		$this->AutoEmailLoanReady->setChecked($params['AutoEmailLoanReady'] == 'true');

		$this->ShelfDefaultStatus->setSelectedValue($params['ShelfDefaultStatus']);
		$this->DefaultLibrarianProfile->setSelectedValue($params['DefaultLibrarianProfile']);
		$this->DefaultLibrarianRole->setSelectedValue($params['DefaultLibrarianRole']);
		$this->AllTermsAsSubjects->setChecked($params['AllTermsAsSubjects'] == 'true');
		$this->UnboxNewSubjects->setChecked($params['UnboxNewSubjects'] == 'true');
		$this->RenewFromNow->setChecked($params['RenewFromNow'] == 'true');
		$this->HideZeroItem->setChecked($params['HideZeroItem'] == 'true');
		$this->AlwaysShowCreateManifestation->setChecked($params['AlwaysShowCreateManifestation'] == 'true');
		$this->ImportDetailLinkCheck->setChecked($params['ImportDetailLinkCheck'] == 'true');
		$this->PatronAccessControl->setChecked($params['PatronAccessControl'] == 'true');
		
		/// profiles section
		$profiles = $this->getProfiles();

		if (count($profiles) > 0)
		{	
			$this->ProfilesControlList->setDataSource($profiles);
			$this->ProfilesControlList->dataBind();
		}
	}
	
	public function onProfilesControlDataBound($sender, $param) 
	{
//		$profiles[$ap['profile_id']] = array(	'profileLabel' => $ap['name'],
//												'profilesControl' => $ap['profiles_control'] );
						
		$item = $param->Item;

		if (($item->ItemType == 'Item') 
				|| ($item->ItemType == 'AlternatingItem'))
		{
			$profilesControlRowFlipped = array_flip(AppProfilePeer::getProfilesControl($item->ProfileId->getValue()));

			foreach ($this->getProfiles() as $profileId => $profile)
			{
				$newCheck = new TListItem();
				$newCheck->setValue($profileId);
				$newCheck->setText($profile['profileLabel']);
				$newCheck->setSelected(array_key_exists($profileId, $profilesControlRowFlipped));
				
				$item->ProfilesCheckList->getItems()->add($newCheck);
			}
		}
	}
	
	private function saveProfilesControl()
	{
		$resultArray = array();
		$rows = $this->ProfilesControlList->getItems();

		foreach ($rows as $index => $row)
		{
			$profileId = intval($row->ProfileId->getValue());
			$rowChecks = array();
			
			foreach ($row->ProfilesCheckList->getItems() as $check)
				$rowChecks[$check->getValue()] = $check->getSelected();
			
			$resultArray[$profileId] = $rowChecks;
		}

		return AppProfilePeer::setProfilesControl($resultArray);
	}
	
	private function populateConfig()
	{
		$filename = $this->getApplication()->getConfigurationFile();
		$application = simplexml_load_file($filename);

		$this->ConfigAppId->setText((string)$application['id']);
		$this->ConfigAppMode->setSelectedValue($application['mode']);

		$xml = $application->xpath('//module[@id="session"]');
	
		if ($xml && count($xml) > 0)
			$this->ConfigSolrSessionTimeout->setText((string)$xml[0]['Timeout']);

		$xml = $application->xpath('//module[@id="cache"]');
		
		if ($xml && count($xml) > 0)
			$this->ConfigCacheEngine->setSelectedValue(substr(strrchr($xml[0]['class'],'.'),1));

		$xml = $application->xpath('//module[@id="search"]');

		if ($xml && count($xml) > 0)
		{
			$this->ConfigSolrDatabaseName->setText((string)$xml[0]['DatabaseName']);
			$this->ConfigSolrAddress->setText((string)$xml[0]['ServerURL']);
		}

		$itemStatus = LookupValuePeer::getLookupClassValues('ITEMSTATUS');
		$this->ConfigSBNBulkLocalizeStatus->setDataSource($itemStatus);
		$this->ConfigSBNBulkLocalizeStatus->dataBind();
		
		$xml = $application->xpath('//module[@id="sbn"]');
		
		if ($xml && count($xml) > 0)
		{
			$this->ConfigSBNEnabled->setChecked('true' == (string)$xml[0]['Enabled']);
			$this->ConfigSBNUser->setText((string)$xml[0]['AuthUser']);
			$this->ConfigSBNPassword->setText((string)$xml[0]['AuthPassword']);
			$this->ConfigSBNAddress->setText((string)$xml[0]['Address']);
			$this->ConfigSBNNodePrefix->setText((string)$xml[0]['NodePrefix']);
			$this->ConfigSBNDefaultLibrary->setText((string)$xml[0]['DefaultLibraryCode']);
			$is = explode(',',$xml[0]['BulkLocalizeItemStatus']);
		
			if (count($is) < 1)
				$is = array('B','F','G','K','Q','R','V');
			
			$this->ConfigSBNBulkLocalizeStatus->setSelectedValues($is);
		}
		else
		{
			$this->ConfigSBNEnabled->setChecked(false);
		}

		$xml = $application->xpath('//module[@id="mail"]');
		
		if ($xml && count($xml) > 0)
		{
			$this->ConfigMailMTA->setText((string)$xml[0]['Host']);
			$this->ConfigMailFrom->setText((string)$xml[0]['From']);
		}

		$xml = $application->xpath('//module[@id="sms"]');
		
		if ($xml && count($xml) > 0)
		{
			$this->ConfigSMSUser->setText((string)$xml[0]['AuthUser']);
			$this->ConfigSMSPassword->setText((string)$xml[0]['AuthPassword']);
			$this->ConfigSMSSender->setText((string)$xml[0]['Sender']);
		}

		$xml = $application->xpath('//module[@id="crypt"]');
		
		$this->ConfigCryptEngine->setSelectedValue(($xml && count($xml) > 0) ?
			substr(strrchr($xml[0]['class'],'.'),1) : 'ClavisCryptDefault');

		$xml = $application->xpath('//service[@id="extauth"]');
		
		$this->ConfigExtauthAllow->setText(($xml && count($xml) > 0 && trim($xml[0]->authorization->allow['ips'])) ?
			trim($xml[0]->authorization->allow['ips']) : '*');

		$xml = $application->xpath('//service[@id="clavisws"]');
		
		$this->ConfigSOAPAllow->setText(($xml && count($xml) > 0 && trim($xml[0]->authorization->allow['ips']))
											? trim($xml[0]->authorization->allow['ips']) 
											: '*');

		$xml = $application->xpath('//service[@id="soap"]');
		
		$this->ConfigIlibraryAllow->setText(($xml && count($xml) > 0 && trim($xml[0]->authorization->allow['ips']))
											? trim($xml[0]->authorization->allow['ips']) 
											: '*');

		$xml = $application->xpath('//service[@id="soapsafesurf"]');
		
		$this->ConfigSafesurfAllow->setText(($xml && count($xml) > 0 && trim($xml[0]->authorization->allow['ips']))
											? trim($xml[0]->authorization->allow['ips']) 
											: '*');
	}

	public function onReload($sender,$params)
	{
			$this->populate();
	}

    public function onChangedPatronLoanClass($sender, $params)
	{
        $this->populate();
    }

	public function onSaveParams($sender,$params)
	{
        $appid = Prado::getApplication()->getID();

        //$toDelete = new APCIterator('user', "/^{$appid}-/",APC_ITER_KEY);
        //apc_delete($toDelete);
        apcu_clear_cache();

        $selPatronLoanClass = $this->PatronLoanClass->getSelectedValue();

		try
		{
			$updateParam = Propel::getConnection()->prepare(
				'REPLACE INTO '.ClavisParamPeer::TABLE_NAME.' ('.ClavisParamPeer::PARAM_CLASS.
				','.ClavisParamPeer::PARAM_NAME.','.ClavisParamPeer::LIBRARY_ID.
				','.ClavisParamPeer::LIBRARIAN_ID.','.ClavisParamPeer::PARAM_VALUE.
				') VALUES (?,?,0,0,?)');
			
			$toupd = array();
			
			foreach ($this->LoanParamsRepeater->getItems() as $row)
			{
				$name = $row->Key->getValue();
				$updateParam->execute(array('LOANDURATION_'.$selPatronLoanClass,$name,$row->LoanDuration->getText()));
				$updateParam->execute(array('MAXLOANSALLOWED_'.$selPatronLoanClass,$name,$row->MaxLoans->getText()));
				$updateParam->execute(array('LOANRENEWDURATION_'.$selPatronLoanClass,$name,$row->RenewalDuration->getText()));
				$updateParam->execute(array('MAXLOANRENEWS_'.$selPatronLoanClass,$name,$row->MaxRenewals->getText()));
				$updateParam->execute(array('REQUESTDURATION_'.$selPatronLoanClass,$name,$row->RequestDuration->getText()));
				$updateParam->execute(array('MAXLOANRESERVATIONS_'.$selPatronLoanClass,$name,$row->MaxRequests->getText()));

                $updateParam->execute(array('RENEWFROM_'.$selPatronLoanClass,$name,$row->RenewFrom->getText()));
                $updateParam->execute(array('RENEWTO_'.$selPatronLoanClass,$name,$row->RenewTo->getText()));

                $updateParam->execute(array('MAXOPERATIONS_'.$selPatronLoanClass,$name,$row->MaxOperations->getText()));
                $updateParam->execute(array('ALERTDAYS_'.$selPatronLoanClass,$name,$row->AlertDays->getText()  * 86400));

				$updateParam->execute(array('MAXDISTANCE_'.$selPatronLoanClass,$name,$row->MaxDistance->getSelectedValue()));
			}
			
			$updateParam->execute(array('LOANRENEWALTIME','FROM',$this->RenewalLimitBefore->getText() * 86400));
			$updateParam->execute(array('LOANRENEWALTIME','UNTIL',$this->RenewalLimitAfter->getText() * 86400));
			$updateParam->execute(array('LOANEXPIRING',0,$this->ExpiringLoanLimit->getText() * 86400));
			$updateParam->execute(array('READYTOLOANWAIT',0,$this->ReadyToLoanWait->getText()));
			$updateParam->execute(array('MAXTOTALOPERATIONS',0,$this->MaxOperations->getText()));
            $updateParam->execute(array('MAXEXTRALOANS',0,$this->MaxExtraLoans->getText()));
            $updateParam->execute(array('AUTOREVOKE_GRACE_DAYS',0,$this->AutoRevokeGraceDays->getText()));
			$updateParam->execute(array('AUTOREVOKE_GRACE_SOLICITS',0,$this->AutoRevokeGraceSolicits->getText()));
			
			$graceUserClasses = serialize($this->AutoRevokeGraceUserClasses->getSelectedValues());
			
			$updateParam->execute(array('AUTOREVOKE_GRACE_USERCLASSES',0,$graceUserClasses));
			$updateParam->execute(array('NEWITEM_UNLOAN_GRACETIME',0,$this->NewItemUnloanGraceTime->getText() * 86400));
			$updateParam->execute(array('EXTRARENEW_CONFIRMEMAIL',0,$this->ExtraRenewConfirmEmail->getChecked() ? '1' : '0'));
			$updateParam->execute(array('EXTRASYSTEMADDDURATION',0,$this->ExtraRenewalDuration->getText()));
			$updateParam->execute(array('EXTRASYSTEMNODELIBRARY',0,$this->ExtraNodeLibrary->getText()));
			$updateParam->execute(array('LLIBRARY_ACTIVE',0,$this->LibraryDistanceActive->getChecked() ? '1' : '0'));
			
			$action = AppActionQuery::create()->findPk(24);
			
			if ($action instanceof AppAction)
			{
				$action->setMenuVisible($this->LibraryDistanceActive->getChecked());
				$action->save();
			}
			
			$updateParam->execute(array('MAX_LLIBRARY_DISTANCE',0,$this->MaxLibraryDistance->getText()));
			$updateParam->execute(array('MAX_LLIBRARY_BASIN',0,$this->MaxLibraryBasin->getSafeText()));
			$updateParam->execute(array('MEDIAPACKAGE_SIZE_MAX',0,$this->MediaPackageMax->getText()));
			$updateParam->execute(array('MLOL_API_KEY',0,$this->MLOLAPIKey->getText()));
			$updateParam->execute(array('MLOL_PORTAL_ID',0,$this->MLOLPortalId->getText()));

			ChangelogPeer::logAction('clavis-paramdb',ChangelogPeer::LOG_UPDATE,$this->getUser()->getLibrarian(),'Aggiornati parametri di circolazione',0);
			
			$this->getPage()->writeMessage(Prado::localize('Parametri di circolazione salvati correttamente'),
																ClavisMessage::CONFIRM);
			
		}
		catch (Exception $e)
		{
			$this->getPage()->writeMessage(Prado::localize('Errore nel salvataggio dei parametri: {msg}',
																array( 'msg' => $e->getMessage())),
												ClavisMessage::ERROR);
		}
		
		$this->populate();
	}
	
	public function onSaveSysParams($sender,$params)
	{
		$this->cleanMessageQueue();
		
		try 
		{
            $appid = Prado::getApplication()->getID();

            //apc_clear_cache();
            //$toDelete = new APCIterator('user', "/^{$appid}-/",APC_ITER_KEY);
            //apc_delete($toDelete);
            apcu_clear_cache();

			$updateParam = Propel::getConnection()->prepare('REPLACE INTO '.ClavisParamPeer::TABLE_NAME.' ('.ClavisParamPeer::PARAM_CLASS.
																','.ClavisParamPeer::PARAM_NAME.','.ClavisParamPeer::LIBRARY_ID.
																','.ClavisParamPeer::LIBRARIAN_ID.','.ClavisParamPeer::PARAM_VALUE.
																') VALUES (\'CLAVISPARAM\',?,0,0,?)');

			$updateParam->execute(array('Maintenance', $this->Maintenance->getChecked() ? 'true' : 'false'));
			$updateParam->execute(array('BaseUrl', $this->BaseUrl->getText()));
			$updateParam->execute(array('OPACUrl', $this->OpacUrl->getText()));
			$updateParam->execute(array('SiteTitle', $this->SiteTitle->getText()));
			$updateParam->execute(array('SiteOwner', $this->SiteOwner->getText()));
			$updateParam->execute(array('AdminEmail', $this->AdminEmail->getText()));
			$updateParam->execute(array('ReportEmail', $this->ReportEmail->getText()));
			$updateParam->execute(array('RemoteCoverServer', $this->RemoteCoverServer->getText()));
			$updateParam->execute(array('NetManager', $this->NetManager->getText()));
			$updateParam->execute(array('ClavisClientHost', $this->ClavisClientHost->getText()));
			$updateParam->execute(array('ClavisClientPort', intval($this->ClavisClientPort->getText())));
			$updateParam->execute(array('BookSellersServerUrl', $this->BookSellersServerUrl->getText()));

            $updateParam->execute(array('InjectHeaderHTML', $this->InjectHeaderHTML->getText()));
            $updateParam->execute(array('InjectStartBodyHTML', $this->InjectStartBodyHTML->getText()));
            $updateParam->execute(array('InjectEndBodyHTML', $this->InjectEndBodyHTML->getText()));

			$updateParam->execute(array('SystemCurrency', $this->SystemCurrency->getSelectedValue()));
			$updateParam->execute(array('AcquisitionMaxPriceLimit', $this->AcquisitionMaxPriceLimit->getText()));
			
			if ($this->getUser()->getIsSuperAdmin())
				$updateParam->execute(array('ContractAlertDaysBefore', intval($this->ContractAlertDaysBefore->getSafeText())));
			
			$updateParam->execute(array('ExpireOldBulletinLimit', $this->ExpireOldBulletinLimit->getText()));
			$updateParam->execute(array('ReservationResetValue', $this->ReservationResetValue->getText()));
			$updateParam->execute(array('ShelfDefaultStatus', $this->ShelfDefaultStatus->getSelectedValue()));
			$updateParam->execute(array('DefaultLibrarianProfile', $this->DefaultLibrarianProfile->getSelectedValue()));
			$updateParam->execute(array('DefaultLibrarianRole', $this->DefaultLibrarianRole->getSelectedValue()));
			$updateParam->execute(array('AutoItemCallNumber', $this->AutoItemCallNumber->getChecked() ? 'true' : 'false'));
			$updateParam->execute(array('AutoCardExpireCheck', $this->AutoCardExpireCheck->getChecked() ? 'true' : 'false'));
			$updateParam->execute(array('AutoLateLoanCheck', $this->AutoLateLoanCheck->getChecked() ? 'true' : 'false'));
			$updateParam->execute(array('ZebraAutoReceipt', $this->ZebraAutoReceipt->getChecked() ? 'true' : 'false'));
			$updateParam->execute(array('ZebraAutoRequest', $this->ZebraAutoRequest->getChecked() ? 'true' : 'false'));
			$updateParam->execute(array('MailSentFrom', $this->MailSentFrom->getSelectedValue()));
			$updateParam->execute(array('SMSSentFrom', $this->SMSSentFrom->getSelectedValue()));
			$updateParam->execute(array('AutoEmailOnRevoke', $this->AutoEmailOnRevoke->getChecked() ? 'true' : 'false'));
			$updateParam->execute(array('AutoEmailLoanExpiring', $this->AutoEmailLoanExpiring->getChecked() ? 'true' : 'false'));
			$updateParam->execute(array('AutoEmailLoanExpired', $this->AutoEmailLoanExpired->getChecked() ? 'true' : 'false'));
			$updateParam->execute(array('AutoEmailLoanReady', $this->AutoEmailLoanReady->getChecked() ? 'true' : 'false'));
			$updateParam->execute(array('AllTermsAsSubjects', $this->AllTermsAsSubjects->getChecked() ? 'true' : 'false'));
            $updateParam->execute(array('UnboxNewSubjects', $this->UnboxNewSubjects->getChecked() ? 'true' : 'false'));
			$updateParam->execute(array('RenewFromNow', $this->RenewFromNow->getChecked() ? 'true' : 'false'));
			$updateParam->execute(array('HideZeroItem', $this->HideZeroItem->getChecked() ? 'true' : 'false'));
			$updateParam->execute(array('AlwaysShowCreateManifestation', $this->AlwaysShowCreateManifestation->getChecked() ? 'true' : 'false'));
			$updateParam->execute(array('ImportDetailLinkCheck', $this->ImportDetailLinkCheck->getChecked() ? 'true' : 'false'));
			$updateParam->execute(array('PatronAccessControl', $this->PatronAccessControl->getChecked() ? 'true' : 'false'));
			
			$action = AppActionQuery::create()->findPk(42);
			$action->setMenuVisible($this->PatronAccessControl->getChecked());
			$action->save();
			
			$chanList = $this->EnabledChannelList->getSelectedValues();
			
			$updateParam->execute(array('EnableChannelSnailmail', 
									in_array('EnableChannelSnailmail', $chanList) ? 'true' : 'false'));
			
			$updateParam->execute(array('EnableChannelEmail', 
									in_array('EnableChannelEmail', $chanList) ? 'true' : 'false'));
			
			$updateParam->execute(array('EnableChannelSMS', 
									in_array('EnableChannelSMS', $chanList) ? 'true' : 'false'));
			
			$updateParam->execute(array('EnableChannelPhone', 
									in_array('EnableChannelPhone', $chanList) ? 'true' : 'false'));
			
			$updateParam->execute(array('EnableChannelPortal', 
									in_array('EnableChannelPortal', $chanList) ? 'true' : 'false'));
			
			$updateParam->execute(array('EnableChannelFax', 
									in_array('EnableChannelFax', $chanList) ? 'true' : 'false'));
			
			$updateParam->execute(array('EnableChannelIM', 
									in_array('EnableChannelIM', $chanList) ? 'true' : 'false'));

			ClavisParamQuery::clearCache();
			
			if ($this->saveProfilesControl())
				$this->enqueueMessage(Prado::localize('Aggiornato il controllo dei profili operatore.'),
													ClavisMessage::CONFIRM);

			ChangelogPeer::logAction(	'clavis-param',
										ChangelogPeer::LOG_UPDATE,
										$this->getUser(),
										'Aggiornati parametri di sistema',
										0);
			
			$this->enqueueMessage(Prado::localize('Parametri di sistema salvati correttamente'),
									ClavisMessage::CONFIRM);
			
		} 
		catch (Exception $e)
		{
			$this->getPage()->enqueueMessage(Prado::localize('Errore nel salvataggio dei parametri: {msg}',
																array('msg' => $e->getMessage())),
												ClavisMessage::ERROR);
		}
		
		$this->populate();
		
		$this->flushMessage();
	}

	public function onSaveConfig($sender,$params)
	{
		try 
		{
			$filename = $this->getApplication()->getConfigurationFile();
		
			if (!is_writable($filename))
				throw new Exception('Configuration file is not writable');

			$xml = new SimpleXMLElement("<application></application>");
			$xml->addAttribute('id',$this->ConfigAppId->getText());
			$xml->addAttribute('mode',$this->ConfigAppMode->getSelectedValue());
			
			$paths = $xml->addChild('paths');
			$node = $paths->addChild('alias');
			$node->addAttribute('id','SitePath');
			$node->addAttribute('path','.');
			$node = $paths->addChild('alias');
			$node->addAttribute('id','Storage');
			$node->addAttribute('path','./storage/');
			$node = $paths->addChild('using');
			$node->addAttribute('namespace','System.I18N.*');
			$node = $paths->addChild('using');
			$node->addAttribute('namespace','System.Web.UI.ActiveControls.*');
			$node = $paths->addChild('using');
			$node->addAttribute('namespace','Application.Interfaces.*');
			$node = $paths->addChild('using');
			$node->addAttribute('namespace','Application.Lib.*');
			$node = $paths->addChild('using');
			$node->addAttribute('namespace','Application.Common.Widgets.*');
			$node = $paths->addChild('using');
			$node->addAttribute('namespace','Application.Common.*');
			
			$modules = $xml->addChild('modules');
			
			// friendly urls modules
			$module = $modules->addChild('module');
			$module->addAttribute('id','urlrequest');
			$module->addAttribute('class','THttpRequest');
			$module->addAttribute('UrlManager','friendly-url');
			$module = $modules->addChild('module');
			$module->addAttribute('id','friendly-url');
			$module->addAttribute('class','System.Web.TUrlMapping');
			$module->addAttribute('EnableCustomUrl','true');
			$url = $module->addChild('url');
			$url->addAttribute('ServiceID','rest');
			$url->addAttribute('ServiceParameter','ConfigParam');
			$url->addAttribute('pattern','api/v1/{object}/{method}/{id}');
			$url->addAttribute('parameters.id','.*');
			$url->addAttribute('parameters.method','\w+');
			$url->addAttribute('parameters.object','\w+');

			// session module
			$module = $modules->addChild('module');
			$module->addAttribute('id','session');
			$module->addAttribute('class','THttpSession');
			$module->addAttribute('SessionName','ClavisNG');
			$module->addAttribute('CookieMode','Only');
			$module->addAttribute('AutoStart','true');
			$module->addAttribute('Timeout',intval($this->ConfigSolrSessionTimeout->getText()));
			
			// cache module
			$module = $modules->addChild('module');
			$module->addAttribute('id','cache');
			$module->addAttribute('class','System.Caching.'.$this->ConfigCacheEngine->getSelectedValue());
			
			// error module
			$module = $modules->addChild('module');
			$module->addAttribute('id','error');
			$module->addAttribute('class','Application.Common.ClavisErrorHandler');
			
			// log module
			$module = $modules->addChild('module');
			$module->addAttribute('id','log');
			$module->addAttribute('class','System.Util.TLogRouter');
			$logroute = $module->addChild('route');
			$logroute->addAttribute('class','TFileLogRoute');
			$logroute->addAttribute('LogPath','SitePath.log');
			$logroute->addAttribute('LogFile','prado.log');
			$logroute->addAttribute('MaxLogFiles','5');
			$logroute->addAttribute('MaxFileSize','1024');
			$logroute->addAttribute('Categories','Uncategorized,ClavisNG');
			$logroute->addAttribute('Levels','Info');
			$logroute = $module->addChild('route');
			$logroute->addAttribute('class','TFileLogRoute');
			$logroute->addAttribute('LogPath','SitePath.log');
			$logroute->addAttribute('LogFile','prado.log');
			$logroute->addAttribute('MaxLogFiles','5');
			$logroute->addAttribute('MaxFileSize','1024');
			$logroute->addAttribute('Categories','System');
			$logroute->addAttribute('Levels','Warning,Error,Alert,Fatal');
			$logroute = $module->addChild('route');
			$logroute->addAttribute('class','TFileLogRoute');
			$logroute->addAttribute('LogPath','SitePath.log');
			$logroute->addAttribute('LogFile','prado-soap.log');
			$logroute->addAttribute('MaxLogFiles','5');
			$logroute->addAttribute('MaxFileSize','1024');
			$logroute->addAttribute('Categories','SOAP');
			$logroute->addAttribute('Levels','Info');
			$logroute = $module->addChild('route');
			$logroute->addAttribute('class','TFileLogRoute');
			$logroute->addAttribute('LogPath','SitePath.log');
			$logroute->addAttribute('LogFile','prado-file.log');
			$logroute->addAttribute('MaxLogFiles','5');
			$logroute->addAttribute('MaxFileSize','1024');
			$logroute->addAttribute('Categories','FileService');
			$logroute->addAttribute('Levels','Notice,Warning,Error,Alert,Fatal');
			
			// globalization module
			$module = $modules->addChild('module');
			$module->addAttribute('id','globalization');
			$module->addAttribute('class','TGlobalizationAutoDetect');
			$module->addAttribute('DefaultCulture','it_IT');
			$module->addAttribute('DefaultCharset','UTF-8');
			$translation = $module->addChild('translation');
			$translation->addAttribute('type','XLIFF');
			$translation->addAttribute('source','Application.Messages');
			$translation->addAttribute('autosave','false');
			$translation->addAttribute('cache','true');
			
			// search module
			$module = $modules->addChild('module');
			$module->addAttribute('id','search');
			$module->addAttribute('class','Application.Common.SolrSearch');
			$module->addAttribute('DatabaseName',$this->ConfigSolrDatabaseName->getText());
			$module->addAttribute('RecordCollection','catalog');
			$module->addAttribute('ExtraCollection','extra');
			$module->addAttribute('AuthorityCollection','authority');
			$module->addAttribute('ServerURL',$this->ConfigSolrAddress->getText());
			$module->addAttribute('RealtimeIndexing','false');
			
			// sbn module
			$module = $modules->addChild('module');
			$module->addAttribute('id','sbn');
			$module->addAttribute('class','Application.Common.ClavisSBN');
			$module->addAttribute('Enabled',$this->ConfigSBNEnabled->getChecked() ? 'true' : 'false');
			$module->addAttribute('AuthUser',$this->ConfigSBNUser->getText());
			$module->addAttribute('AuthPassword',$this->ConfigSBNPassword->getText());
			$module->addAttribute('Address',$this->ConfigSBNAddress->getSelectedValue());
			$module->addAttribute('NodePrefix',$this->ConfigSBNNodePrefix->getText());
			$module->addAttribute('DefaultLibraryCode',$this->ConfigSBNDefaultLibrary->getText());
			$module->addAttribute('BulkLocalizeItemStatus',implode(',',$this->ConfigSBNBulkLocalizeStatus->getSelectedValues()));
			$this->ConfigSBNEnabled->getChecked()
				? $this->enableSBNInterface()
				: $this->disableSBNInterface();
			
			// price module
			$module = $modules->addChild('module');
			$module->addAttribute('id','price');
			$module->addAttribute('class','Application.Common.ClavisPriceManager');
			
			// notification module
			$module = $modules->addChild('module');
			$module->addAttribute('id','notification');
			$module->addAttribute('class','Application.Common.NotificationManager');
			
			// mail module
			$module = $modules->addChild('module');
			$module->addAttribute('id','mail');
			$module->addAttribute('class','SMTPMail');
			$module->addAttribute('Host',$this->ConfigMailMTA->getText());
			$module->addAttribute('Auth','false');
			$module->addAttribute('From',$this->ConfigMailFrom->getText());
			$module->addAttribute('Localhost','localhost');
			
			// sms module
			$module = $modules->addChild('module');
			$module->addAttribute('id','sms');
			$module->addAttribute('class','SMSTrendModule');
			$module->addAttribute('AuthUser',$this->ConfigSMSUser->getText());
			$module->addAttribute('AuthPassword',$this->ConfigSMSPassword->getText());
			$module->addAttribute('Sender',$this->ConfigSMSSender->getText());
			
			// JReport module
			$module = $modules->addChild('module');
			$module->addAttribute('id','JReport');
			$module->addAttribute('class','JRPHPModule');
			$module->addAttribute('JavaBridgeURL','127.0.0.1:8081');
			$module->addAttribute('ReportPath','Storage.report.jasper');
			$module->addAttribute('SpoolerPath','Storage.spooler');
			
			// users module
			$module = $modules->addChild('module');
			$module->addAttribute('id','users');
			$module->addAttribute('class','Application.Common.ClavisUserManager');
			
			// auth module
			$module = $modules->addChild('module');
			$module->addAttribute('id','auth');
			$module->addAttribute('class','System.Security.TAuthManager');
			$module->addAttribute('UserManager','users');
			$module->addAttribute('LoginPage','Login');
			
			// loan module
			$module = $modules->addChild('module');
			$module->addAttribute('id','loan');
			$module->addAttribute('class','Application.Common.ClavisLoanManager');
			
			// request module
			$module = $modules->addChild('module');
			$module->addAttribute('id','request');
			$module->addAttribute('class','Application.Common.ClavisRequestManager');
			
			// extrarequest module
			$module = $modules->addChild('module');
			$module->addAttribute('id','extrarequest');
			$module->addAttribute('class','Application.Common.ClavisExternalReservation');
			
			// crypt module
			$module = $modules->addChild('module');
			$module->addAttribute('id','crypt');
			$module->addAttribute('class','Application.Lib.'.$this->ConfigCryptEngine->getSelectedValue());

			$services = $xml->addChild('services');
			
			// rest service
			$service = $services->addChild('service');
			$service->addAttribute('id','rest');
			$service->addAttribute('class','Application.Services.ClavisRestApi');
			
			// page service
			$service = $services->addChild('service');
			$service->addAttribute('id','page');
			$service->addAttribute('class','TPageService');
			$service->addAttribute('BasePath','Application.Pages');
			$service->addAttribute('DefaultPage','MyHomePage.Home');
			$child = $service->addChild('pages');
			$child->addAttribute('MasterClass','Application.Layouts.MainLayout');
			$child->addAttribute('Theme','Default');
			$child = $service->addChild('authorization');
			$allow = $child->addChild('allow');
			$allow->addAttribute('pages','Login,Error.*,Guest.*');
			$allow->addAttribute('users','*');
			$allow = $child->addChild('allow');
			$allow->addAttribute('pages','MyHomePage.*,Acquisition.*,Catalog.*,Circulation.*,Communication.*,Help.*,Library.*,Reports.*,SBN.*');
			$allow->addAttribute('roles','librarian,admin');
			$allow = $child->addChild('allow');
			$allow->addAttribute('pages','Administration.*');
			$allow->addAttribute('roles','admin');
			$deny = $child->addChild('deny');
			$deny->addAttribute('users','*');
			
			// file service
			$service = $services->addChild('service');
			$service->addAttribute('id','file');
			$service->addAttribute('class','Application.Services.ClavisFileService');
			
			// export service
			$service = $services->addChild('service');
			$service->addAttribute('id','export');
			$service->addAttribute('class','Application.Services.ClavisExportService');
			$service->addAttribute('NoCache','false');
			
			// extauth service
			$service = $services->addChild('service');
			$service->addAttribute('id','extauth');
			$service->addAttribute('class','Application.Services.ClavisAuthService');
			$child = $service->addChild('authorization');
			$allow = $child->addChild('allow');
			$allow->addAttribute('ips',$this->ConfigExtauthAllow->getText());
			$deny = $child->addChild('deny');
			$deny->addAttribute('users','*');
			
			// SOAP service
			$service = $services->addChild('service');
			$service->addAttribute('id','clavisws');
			$service->addAttribute('class','System.Web.Services.TSoapService');
			$soap = $service->addChild('soap');
			$soap->addAttribute('id','user');
			$soap->addAttribute('provider','Application.Services.SOAP.UserFunctions');
			$soap = $service->addChild('soap');
			$soap->addAttribute('id','catalog');
			$soap->addAttribute('provider','Application.Services.SOAP.CatalogFunctions');
			$soap = $service->addChild('soap');
			$soap->addAttribute('id','loan');
			$soap->addAttribute('provider','Application.Services.SOAP.LoanFunctions');
			$soap = $service->addChild('soap');
			$soap->addAttribute('id','consortia');
			$soap->addAttribute('provider','Application.Services.SOAP.ConsortiaFunctions');
			$child = $service->addChild('authorization');
			$allow = $child->addChild('allow');
			$allow->addAttribute('ips',$this->ConfigSOAPAllow->getText());
			$deny = $child->addChild('deny');
			$deny->addAttribute('users','*');
			
			// SOAP for iLibrary
			$service = $services->addChild('service');
			$service->addAttribute('id','soap');
			$service->addAttribute('class','System.Web.Services.TSoapService');
			$soap = $service->addChild('soap');
			$soap->addAttribute('id','ClavisSoap');
			$soap->addAttribute('provider','Application.Services.ClavisSoapInterface');
			$child = $service->addChild('authorization');
			$allow = $child->addChild('allow');
			$allow->addAttribute('ips',$this->ConfigIlibraryAllow->getText());
			$deny = $child->addChild('deny');
			$deny->addAttribute('users','*');
			
			// SOAP for SafeSurf
			$service = $services->addChild('service');
			$service->addAttribute('id','soapsafesurf');
			$service->addAttribute('class','System.Web.Services.TSoapService');
			$soap = $service->addChild('soap');
			$soap->addAttribute('id','ClavisSafeSurfSoap');
			$soap->addAttribute('provider','Application.Services.ClavisSafeSurfSoapInterface');
			$child = $service->addChild('authorization');
			$allow = $child->addChild('allow');
			$allow->addAttribute('ips',$this->ConfigSafesurfAllow->getText());
			$deny = $child->addChild('deny');
			$deny->addAttribute('users','*');

			$dom = new DOMDocument('1.0');
			$dom->preserveWhiteSpace = false;
			$dom->formatOutput = true;
			$dom->loadXML($xml->asXML());
			
			if ($dom->save($filename) === false)
				throw new Exception('Could not save to file');

			ChangelogPeer::logAction(	'clavis-application',
										ChangelogPeer::LOG_UPDATE,
										$this->getUser(),
										'Aggiornata configurazione di sistema',0);
			
			$this->getPage()->writeMessage(Prado::localize('Configurazione salvata correttamente'),
											ClavisMessage::CONFIRM);
		}
		catch (Exception $e)
		{
			$this->getPage()->writeMessage(Prado::localize('Errore nel salvataggio della configurazione: {msg}',
																array('msg'=>$e->getMessage())),
											ClavisMessage::ERROR);
		}
		
		$this->populate();
	}

	private function enableSBNInterface()
	{
		$source = ImportSourceQuery::create()
					->findOneByName('SBN');
		
		if (!$source instanceof ImportSource)
		{
			$source = new ImportSource();
			$source->setName('SBN');
			$source->setLabel('SBN');
			$source->setDriver('SBNDriver');
			$source->setEnabled(true);
			$source->setSelected(true);
			$source->setTimeout(30);
			$source->insertAtTop();
			$source->save();
		}
		
		$mod = AppModuleQuery::create()->findPk('SBN');
		
		if (!$mod instanceof AppModule)
		{
			$this->writeMessage(Prado::localize('Impossibile trovare la scheda SBN.'), 
									ClavisMessage::WARNING);
			
			return;
		}
		
		$mod->setAlwaysView(true);
		$mod->save();
	}

	private function disableSBNInterface()
	{
		$source = ImportSourceQuery::create()
					->findOneByName('SBN');
		
		if ($source instanceof ImportSource)
			$source->delete();

		$mod = AppModuleQuery::create()->findPk('SBN');
		
		if (!$mod instanceof AppModule)
		{
			$this->writeMessage(Prado::localize('Impossibile trovare la scheda SBN.'),
									ClavisMessage::ERROR);
			
			return;
		}
		
		$mod->setAlwaysView(false);
		$mod->save();
	}

	private function convertParamsFromXMLToDB()
	{
		$filename = $this->getApplication()->getModule('param')->getParameterFile();
		$xml = simplexml_load_file($filename);
		
		$updateParam = Propel::getConnection()->prepare(	'REPLACE INTO '.ClavisParamPeer::TABLE_NAME.' ('.ClavisParamPeer::PARAM_CLASS.
																','.ClavisParamPeer::PARAM_NAME.','.ClavisParamPeer::LIBRARY_ID.
																','.ClavisParamPeer::LIBRARIAN_ID.','.ClavisParamPeer::PARAM_VALUE.
																') VALUES (\'CLAVISPARAM\',?,0,0,?)');
		
		foreach($xml->children() as $param)
			$updateParam->execute(array((string)$param['id'],(string)$param['value']));
		
		return ClavisParamQuery::getClassParams('CLAVISPARAM');
	}
	
}