<?php
/**
 * PrivacyAcceptPage class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 ePortal Technologies
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Pages.PrivacyAccept
 */

/**
 * ErrorPage Class
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.7
 * @package Pages.PrivacyAccept
 * @since 2.4.2
 */
class PrivacyAcceptPage extends ClavisPage
{
	const PRIVACYTEXT_SAMPLE = "Testo d'esempio per il documento per la gestione della privacy per gli operatori.";
	
	public $_module = 'ADMIN';
	private $_loggedLibrarian;
	private $_privacyLibrarianText;
	private $_privacyLibrarianFile;
	
	private function initVars()
	{
		$this->_loggedLibrarian = $this->getUser()->getLibrarian();
		$this->_privacyLibrarianFile = AttachmentPeer::getRealStoragePath() . '/privacyLibrarianText';
		
		if (file_exists($this->_privacyLibrarianFile))
		{
			$this->_privacyLibrarianText = file_get_contents($this->_privacyLibrarianFile);
		}	
		else
		{
			$this->_privacyLibrarianText = self::PRIVACYTEXT_SAMPLE;
			file_put_contents($this->_privacyLibrarianFile, $this->_privacyLibrarianText);
		}
	}
	
	public function onLoad($param)
	{
		parent::onLoad($param);
		$this->initVars();
		
		if ($this->_loggedLibrarian instanceof Librarian)
		{
			// if i already accepted, i can't stay in this page
			if (!LibrarianPeer::isPrivacyActive()
					|| $this->_loggedLibrarian->isPrivacyAccepted())
				$this->getResponse()->redirect($this->getService()->getDefaultPageUrl());
		}
		
		// first page cycle
		if (!$this->getIsPostBack() 
				&& !$this->getIsCallback())
		{	
			$this->_privacyLibrarianFile = AttachmentPeer::getRealStoragePath() . '/privacyLibrarianText';

			if (file_exists($this->_privacyLibrarianFile))
			{
				$this->_privacyLibrarianText = file_get_contents($this->_privacyLibrarianFile);
			}	
			else
			{
				$this->_privacyLibrarianText = self::PRIVACYTEXT_SAMPLE;
				file_put_contents($this->_privacyLibrarianFile, $this->_privacyLibrarianText);
			}
			
			$this->PrivacyLibrarianText->setText($this->_privacyLibrarianText);
		}
	}
	
	public function checkAuth($addedCheck = true, $force = null)
	{
		/*
		 * Dummy.
		 * Because we don't need to pass again in the ClavisPageBase->checkAuth() method:
		 * we came here from a call in that method.
		 */
	}
	
	public function onPrivacyAccept($sender, $param)
	{
		$this->_loggedLibrarian->acceptPrivacy();
		
		/** @var Librarian $this->_loggedLibrarian */
		$librarianId = $this->_loggedLibrarian->getLibrarianId();
		$librarianName = $this->_loggedLibrarian->getCompleteName();
		
		ChangelogPeer::logAction(	$this->_loggedLibrarian,
									ChangelogPeer::LOG_UPDATE,
									$this->getUser(),
									"É stata letta e accettata la vigente normativa sulla privacy da parte dell'operatore con id = {$librarianId}, nome = '{$librarianName}'",
									$librarianId);

		$this->writeDelayedMessage(Prado::localize("É stata letta e accettata la vigente normativa sulla privacy da parte dell'operatore con id = {librarianId}, nome = '{librarianName}'",
															array(	'librarianId' => $librarianId,
																	'librarianName' => $librarianName )),
								ClavisMessage::WARNING);
		
		$this->getResponse()->redirect($this->getService()->getDefaultPageUrl());
	}

}
