<?php

/**
 * Kpi Page class Module Administration
 *
 * @author Cristian Chiarello <ciarez@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2010 Comperio srl
 */

class Kpi extends ClavisPage {

	public $_module = 'ADMIN';

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getIsPostBack() && !$this->getIsCallback())
		{
			$this->dataBind();
		}
	}
	
	public function globalRefresh() {
		//method override to avoid warning message
	}
}