<?php
/**
 * Login class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Dario Rigolin <dario@comperio.it>
 * @author Ciro Mattia Gonano
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 ePortal Technologies
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.8.9
 * @package Pages.Core
 */

/**
 * Login Class
 *
 * @author Dario Rigolin <dario@comperio.it>
 * @author Ciro Mattia Gonano
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.8.9
 * @package Pages.Core
 * @since 2.8.8
 */
class LoginNewPassword extends ClavisPage
{
	public function onInit($param)
	{
		parent::onInit($param);

		$this->getResponse()->redirect($this->getService()->constructUrl("Login"));
		
		////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		


		// if user is already logged in, redirect.
		if (!$this->getUser()->getIsGuest())
		{
            $this->setFocus($this->NewPassword->getClientId());
		} else {
            $url = Prado::getApplication()->getService()->constructUrl('Login');
            $this->getResponse()->redirect($url);
            return;
        }
	}

	public function onLoad($param)
	{
		parent::onLoad($param);

	}

	
	public function checkAuth()
	{
		$this->LibrarianId->setValue($this->getUser()->getLibrarian()->getId());
		//////////////////$this->getApplication()->getModule('auth')->logout();
		
		return true;
	}
	/**
	 * We handle the password changing phase of a librarian into Clavis
	 *
	 * @param TComponent $sender
	 * @param TParam $param
	 */
	public function changePassword($sender, $param)
	{
		if ($this->getIsValid())
		{
            $authmod = $this->getApplication()->getModule('auth');

            // obtain the URL of the privileged page that the user wanted to visit originally
            $url = $authmod->getReturnUrl();
			
            if (empty($url) || strpos($url, 'page=' . $authmod->getLoginPage()) !== false)  // the user accesses the login page directly
                $url = $this->getService()->getDefaultPageUrl();

            $this->getResponse()->redirect($url);
		}
	}

	public function validatePassword($sender, $param)
	{
	    /** @var Librarian $librarian */
		$librarian = $this->getUser()->getLibrarian();
		$oldSecret = $librarian->getSecret();

		$pwd1 = $this->NewPassword->getSafeText();
        $pwd2 = $this->NewPasswordConfirm->getSafeText();

        $cryptmod = $this->getApplication()->getModule('crypt');
        $newSecret = $cryptmod->LibrarianEncrypt($pwd1);

		if (($pwd1 != $pwd2) || ($newSecret == $oldSecret))
		{
			$param->setIsValid(false);
		}
		else
		{
		    $librarian->setSecret($newSecret);
            $date = date_create();
            date_add($date, date_interval_create_from_date_string('6 months'));
		    $librarian->setSecretExpire($date);
			$param->setIsValid(true);
            $librarian->save();
		}
	}

    public function onCancel($sender, $param)
    {
		$this->gotoPage("Login");
		
//        $currentSession = $this->getUser()->getLibrarianSession();
//        if(!is_null($currentSession)) {
//            $currentSession->setEndDate('now');
//            $currentSession->save();
//        }
//        //logout
//        $this->getApplication()->getModule('auth')->logout();
//        $this->getResponse()->redirect($this->getService()->getDefaultPageUrl());
    }

}