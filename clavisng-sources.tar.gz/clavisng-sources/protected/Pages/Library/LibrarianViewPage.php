<?php
/**
 * LibrarianViewPage class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @author Ciro Mattia Gonano
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.8.8
 * @package Pages.Library
 */

/**
 * LibrarianViewPage Class
 *
 * @author Marco Brancalion <marco.brancalion@comperio.it>
 * @author Ciro Mattia Gonano
 * @version 2.8.8
 * @package Pages.Library
 * @since 2.0
 */
class LibrarianViewPage extends ClavisPage
{
	/**
	 * Name of the module where we are.
	 *
	 * @var string
	 */
	public $_module = 'LIBRARY';

	/**
	 * Object Librarian which we are treating.
	 *
	 * @var Librarian
	 */
	private $_librarian = null;
	
	public function onInit($param)
	{
		parent::onInit($param);

		if (!$this->getIsPostBack())	// first page cycle
		{
		    $id = intval($this->getRequest()->itemAt('id'));
			
			if ($id > 0)
			{
				$librarian = LibrarianQuery::create()->findPk($id);
				
				if (!($librarian instanceof Librarian))
				{
					$this->writeMessage(Prado::localize("L'operatore con id = {id} non esiste",
															array('id' => $id)),
											ClavisMessage::ERROR);
					
					$this->gotoPage('Library.LibrarianListPage');
				}

				$this->setLibrarian($librarian);
				$this->calculateAllowedLibraries();
			}
			else
			{
				$this->writeMessage(Prado::localize("Nessun id operatore specificato"),
										ClavisMessage::ERROR);
				
				$this->gotoPage('Library.LibrarianListPage');
			}
			
			// tab teleport
			$selectTab = intval($this->getRequest()->itemAt('selectTab'));
			
			if ($selectTab > 0)
				$this->TabPanel->setActiveViewIndex($selectTab);
		}
	}

	/**
	 * In the onLoad, the first time, we populate the fields
	 * and perform a databind.
	 * Then, everytime, we get the object librarian and proceed
	 * to inform all the eventual components, which will treat all
	 * the bindings of this librarian with other elements, about it.
	 * @param TEventParameter $param
	 */
	public function onLoad($param)
	{
		parent::onLoad($param);

		$librarian = $this->getLibrarian();
		
		if (!$this->getIsPostBack()
				&& !$this->getIsCallback())		// first page cycle
		{
			$role = ClavisParamQuery::getParam('CLAVISPARAM', 'DefaultLibrarianRole');
			
			if (is_null($role))
				$role = '0';
			
			$this->LinkRole->setSelectedValue($role);

			$this->LibrarianView->setLibrarian($librarian);
			$this->ProfilesGrid->setLibrarian($librarian);
			$this->LibrariesGrid->setLibrarian($librarian);
			$this->UpdateData->setObject($librarian);

			$this->NotificationList->setObjectClass(NotificationPeer::OBJECTTYPE_LIBRARIAN);
			$this->NotificationList->setObjectId($this->_librarian->getLibrarianId());
			$this->NotificationList->populate();

			$librarianId = $this->getLibrarianId();
			
			if ($librarianId > 0)
			{
				$this->ChangelogList->setUserClass('ClavisLibrarian');
				$this->ChangelogList->setUserId($librarianId);
				
				$this->ItemActionList->setLibrarianId($librarianId);
				//$this->ItemActionList->populate();
				$this->HistoryTab->setVisible(true);
				$this->LibrarianPopupNotificationOptions->init($librarian);
			}
			else
			{
				$this->HistoryTab->setVisible(false);
			}
		}
		
		$this->AttachmentManager->setObjectClass('Librarian');
		$this->AttachmentManager->setObjectId($this->_librarian->getLibrarianId());
		
		$canEdit = $this->getUser()->getEditPermission($this->_librarian);
		$this->Modify->setEnabled($canEdit);
	}
	
	/**
	 * Saves onto the database the object librarian.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onLibrarianModify($sender, $param)
	{
		$this->gotoPage("Library.LibrarianInsertPage", array("librarianId"=>$this->_librarian->getLibrarianId()));
	}

	public function setLibrarian($librarian)
	{
		$this->_librarian = $librarian;
		$this->setViewState("librarian", $librarian, null);
	}

	public function getLibrarian()
	{
		$this->_librarian = $this->getViewState("librarian", null);
		
		return $this->_librarian;
	}

	public function getLibrarianId()
	{
		$librarian = $this->getLibrarian();
		
		if ($librarian instanceof Librarian)
		{
			return $librarian->getLibrarianId();
		}
		else
		{
			return 0;
		}
	}

	/**
	 * Callback of the button which adds a new profile.
	 * It calls the proper event in the external component.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onAddProfile($sender, $param)
	{
		$this->ProfilesGrid->onAddProfile();
	}

	/**
	 * Links the selected library to current librarian.
	 * --
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onAddLibrary($sender, $param)
	{
		$this->ProfilesGrid->onAddProfile();
		$libraryId = $this->ResultValue->getValue();

		if (!is_null($libraryId) 
				&& is_numeric($libraryId))
		{
			$library = new LLibraryLibrarian();
			$library->setLibraryId($libraryId);
			$library->setLibrarianId($this->_librarian->getLibrarianId());
			$library->save();
			//$this->_librarian->addLLibraryLibrarian($library);
			$this->_librarian->forceReloadLLibraryLibrarian();
		}
		
		$this->Page->globalRefresh();
		$this->setFocus($this->AddLibraryLink->getClientId());
	}

	/**
	 * It unlinks a library from the list of libraries which are
	 * associated to the given librarian.
	 *
	 * The function "forceReloadLLibraryLibrarian, in the object,
	 * is needed to force the recalculation of the l_library_librarian
	 * links in case one row in that table is removed.
	 *
	 */
	public function onUnlink($sender, $param)
	{
		$libraryId = $param->CommandParameter;
		
		if (!is_null($libraryId) 
				&& is_numeric($libraryId))
		{
			$librarianId = $this->_librarian->getLibrarianId();

			$criteria = new Criteria();
			$criterion = $criteria->getNewCriterion(LLibraryLibrarianPeer::LIBRARY_ID, $libraryId);
			$criterion2 = $criteria->getNewCriterion(LLibraryLibrarianPeer::LIBRARIAN_ID, $librarianId);
			$criterion->addAnd($criterion2);
			$criteria->add($criterion);
			LLibraryLibrarianPeer::doDelete($criteria);
			$this->_librarian->forceReloadLLibraryLibrarian();
		}

		$libraryLabel = LibraryPeer::getLibraryLabel($libraryId);
		$this->getPage()->writeMessage(Prado::localize("Slegata dall'utente la biblioteca '{bibl}'",
															array('bibl' => $libraryLabel)),
											ClavisMessage::INFO);
		
		ChangelogPeer::logAction(	$this->_librarian,
									ChangelogPeer::LOG_UPDATE,
									$this->getUser(), "Slegata biblioteca '{$libraryLabel}'");

		$this->reloadLibrarian();
		$this->LibrariesGrid->setLibrarian($this->_librarian);
		$this->LibrariesGrid->populate();
		
		$this->calculateAllowedLibraries();
	}

	private function reloadLibrarian()
	{
		$librarian = $this->getLibrarian();
		$librarian->reload(true);
		$this->setLibrarian($librarian);
	}
	
	/**
	 * It is called by one of the inner components, and
	 * performs the population (refresh) of all the components
	 * (the calling is included).
	 *
	 */
	public function globalRefresh()
	{
		$this->ProfilesGrid->populate();
		$this->LibrariesGrid->populate();
		$this->calculateAllowedLibraries();
	}

	/**
	 * It's called by one of the inner components, and
	 * performs the "cancel" (return to non-edit status)
	 * of all the components (the calling is included).
	 *
	 * @param TControl $component
	 */
	public function globalCancel($component)
	{
		if ($component !== $this->ProfilesGrid)
			$this->ProfilesGrid->onCancel(null, null);
		
		if ($component !== $this->LibrariesGrid)
			$this->LibrariesGrid->onCancel(null, null);
	}
	
	//////////************ da valutare se dentro metterci getProfilePermission    mbrancalion  : VALUTATO
	public function isUnlink()
	{
		//return $this->getPermission();  //$this->getUser()->getIsAdmin();
		return $this->getProfilePermission();
	}

	public function getPermission()
	{
		return $this->getUser()->getEditPermission($this->_librarian);
		
	}

	public function getProfilePermission()
	{
		//return $this->getUser()->getEditPermission(new Librarian());
		return $this->getUser()->getProfilePermission($this->getLibrarianId());
	}

	public function getLibraryPermission()
	{
		return $this->getUser()->getLibraryPermission($this->getLibrarianId());
	}

	public function onMultiLibrarySelect($sender, $param)
	{
		$val = $this->SelectedLibrary->getValue();
		
		$lids = ($val == 'multi')
					? unserialize($this->SelectedId->getValue())
					: array(intval($this->SelectedId->getValue()));
		
		$l = LibraryQuery::create()->findPks($lids);
		$lCount = $l->count();
		
		$this->LinkLibrariesButton->setVisible($lCount > 0);
		$this->LibrariesToLinkNumber->setValue("($lCount)");
		
		$this->LibrariesToLink->setDataSource($l);
		$this->LibrariesToLink->dataBind();
	}
	
	public function onLinkNewLibraries($sender, $param)
	{
		$this->cleanMessageQueue();
		
		$val = $this->SelectedLibrary->getValue();
		
		$lids = ($val == 'multi')
					? unserialize($this->SelectedId->getValue())
					: array(intval($this->SelectedId->getValue()));
		
		$libraries = LibraryQuery::create()->findPks($lids);
		$myLibrarianId = $this->_librarian->getLibrarianId();
		$librarianName = $this->_librarian->getCompleteName();
		$role = $this->LinkRole->getSelectedValue();
		$opac_visible = $this->OpacVisible->getChecked();
		$addedCounter = 0;
		$errorCounter = 0;
		
		foreach ($libraries as $l)
		{
			if ($l->addLibrarian($myLibrarianId,$role,$opac_visible))
			{
				$addedCounter++;
				
				ChangelogPeer::logAction(	$l,
											ChangelogPeer::LOG_UPDATE,
											$this->getUser(),
											"Legato operatore '{$librarianName}' (id: {$myLibrarianId}) alla biblioteca");
			}
			else	// error
			{
				$errorCounter++;
			}
		}
		
		if (($addedCounter + $errorCounter) == 0)
			$this->getPage()->enqueueMessage(Prado::localize("Nessuna biblioteca aggiunta ad operatore."),
												ClavisMessage::INFO);
		
		if ($addedCounter > 0)
		{
			$this->getPage()->enqueueMessage(Prado::localize("Aggiunte {count} biblioteche a questo operatore.",
																	array('count' => $addedCounter)),
												ClavisMessage::CONFIRM);
		
			$this->reloadLibrarian();
			$this->LibrariesGrid->setLibrarian($this->_librarian);
			$this->LibrariesGrid->populate();
			
			$this->calculateAllowedLibraries();
			$this->renderAddLibrariesPanel($param);
			$this->renderLibrariesGridPanel($param);
		}
		
		if ($errorCounter > 0)
		{
			$this->getPage()->enqueueMessage(Prado::localize("Presenti {count} errori su aggiunta bilioteche ad operatore.",
																	array('count' => $errorCounter)),
												ClavisMessage::ERROR);
		}
		
		$this->LinkLibrariesButton->setVisible(false);
		$this->LibrariesToLink->setDataSource(array());
		$this->LibrariesToLink->dataBind();
		
		$this->flushMessage();
		//$this->reloadPage($this->getSelectedTabParameter(1));	// teleport to the libraries tab
	}
	
	private function renderLibrariesGridPanel($param)
	{
		$this->LibrariesGridPanel->render(is_null($param)
											? $this->createWriter()
											: $param->getNewWriter());
	}
	
	private function renderAddLibrariesPanel($param)
	{
		$this->AddLibrariesPanel->render(is_null($param)
											? $this->createWriter()
											: $param->getNewWriter());
	}
	
	public function calculateAllowedLibraries()
	{
		$allowedLibraryArray = array();
		
		if ($this->getUser()->getIsDirector())
			$allowedLibraryArray = $this->getUser()->getLibraryIds();		// the director's libraries

		if ((count($allowedLibraryArray) > 0)
				|| ($this->getApplication()->getUser()->getIsAdmin()))
		{
			$this->setParam2Popup('libraryIds', serialize($allowedLibraryArray));
			$this->AddLibrariesPanel->setCssClass('panel_on');
		}
		else
		{
			$this->AddLibrariesPanel->setCssClass('panel_off');
		}
	}
	
	private function setParam2Popup($name, $value)
	{
		$actualParam = array(	'multiSelect' => 'multiSelect',
								$name => $value );
		
		$this->SelectLibraryButton->setParam(serialize($actualParam));
		$this->SelectLibraryButton->dataBind();
	}
	
	public function getSelectedTabParameter($param = null)
	{
		$av = is_null($param) 
				? $this->getPage()->TabPanel->getActiveViewIndex()
				: $param;
		
		return array('selectTab' => $av);
	}
	
	//////////////
	
	public function calculateAllowedLibrariesOLD()
	{
		$librarianLibraryIds = $this->getLibrarian()->getLibraryIds();
		$actualLibraryIds = $this->getApplication()->getUser()->getLibraryIds();
		$allowedLibraryArray = array_diff($actualLibraryIds, $librarianLibraryIds);

		if ((count($allowedLibraryArray) > 0)
				|| ($this->getApplication()->getUser()->getIsAdmin()))
		{
			$this->setParam2Popup('libraryIds', serialize($allowedLibraryArray));
			$this->AddLibrariesPanel->setCssClass('panel_on');
		}
		else
		{
			$this->AddLibrariesPanel->setCssClass('panel_off');
		}
	}
	
}