<?php
/**
 * LibraryInsertPage class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @author Ciro Mattia Gonano
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.8.9
 * @package Pages.Library
 */

/**
 * LibraryInsertPage Class
 *
 * @author Massimiliano Pigozzi
 * @author Ciro Mattia Gonano
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.8.9
 * @package Pages.Library
 * @since 2.0
 */
class LibraryInsertPage extends ClavisPage
{
	public $_module = 'LIBRARY';

	private $_wasNew;
	private $_updateGrid;
	private $_colorizeRowSessionName;
	
	private function initVars()
	{
		$this->_colorizeRowSessionName = 'ColorizeRowSessionName'. $this->getUniqueID();
	}

	public function onInit($param)
	{
		parent::onInit($param);
		$this->initVars();

		// moved just below $this->_updateGrid = true;
		
		if (!$this->getIsPostBack() 
				&& !$this->getIsCallback())
		{
			$this->_updateGrid = true;		// moved here from above, mbrancalion, test
			$this->setCurrentDaysInTheGrid([]);
			$this->setAlternateTableSource([]);		// reset
			
			$this->CheckLoanDueDateCheckBox->setChecked(true);
			$this->resetColorizeRow();
			
			$library = null;
			$id = intval($this->getRequest()->itemAt('id'));
			
			if ($id > 0)
			{
				$library = LibraryQuery::create()->findPk($id);
			}
			else
			{
				/// ... = $clavisLibrarian->getEditPermission(new Library());
				$library = new Library();
			}

			if (!($library instanceof Library))
			{
				$this->writeMessage(Prado::localize('La biblioteca con id = {id} non esiste',
														array('id' => $id)),
										ClavisMessage::ERROR);

				$this->gotoPage('Library.LibraryList');
			}
			else
			{
				$this->UpdateData->setObject($library);
				$this->setLibrary($library);
				$this->setLibraryId($library->getLibraryId());
				
//				if (!$library->isNew())
//				{
//					$this->populateProperties();
//				}
			}
			
			$this->_updateGrid = false;
			
			if ($tab = $this->getRequest()->itemAt('tab'))
				$this->TabPanel->setActiveViewIndex($tab);
			
			$fromDate = (int) $this->getRequest()->itemAt('fromDate');
			$toDate = (int) $this->getRequest()->itemAt('toDate');
	
			if ($fromDate * $toDate > 0)
			{
				$this->DayInsertFromTextBox->setData($fromDate);
				$this->DayInsertToTextBox->setData($toDate);
			} else {
                $this->DayInsertFromTextBox->setData(time());
                $this->DayInsertToTextBox->setData(time());
            }
		}
	}

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getIsPostBack() && !$this->getIsCallback())
		{
			$this->Timetable->setLibraryId($this->getLibraryId());
			$this->setSingleDayMode(false);
			$this->HolidayColumn->setVisible(false);

			$this->writeTimeGrid($this->calculateMultipleRow());

			$this->populate();  // all the rest

			/* tabview selection by request parameter */
			try
			{
				$selectTab = $this->getRequest()->itemAt('selectTab');
				
				if (is_numeric($selectTab) 
						&& $selectTab > 0)
				{
					$this->TabPanel->setActiveViewIndex($selectTab);
				}
				elseif (is_string($selectTab) 
						&& $selectTab != "")
				{
					$this->TabPanel->setActiveViewID($selectTab);
				}
			}
			catch (Exception $e)
			{
				//Prado::log($e);
			}
		}
		else
		{
			$this->populateProperties();

//			$doFlushMessages = $this->getApplication()->getSession()->itemAt('DoFlushMessage');
//
//			if (!is_null($doFlushMessages) 
//					&& ($doFlushMessages == true))
//			{
//				$this->getApplication()->getSession()->remove('DoFlushMessage');
//				$this->flushMessage();
//			}
			
			$this->flushDelayedMessage();
		}

		if ($this->getIsPostBack())
		{
			if (($shelfId = intval($this->ShelfId->getValue())) > 0)
			{
				$shelf = null;
				$shelf = ShelfQuery::create()->findPk($shelfId);
				
				if ($shelf instanceof Shelf)
					$this->ShelfName->setText($shelf->getEnsuredShelfName());
			}
			
			///////////$this->reloadDaysInTheGrid();
		}
		
		if ($this->getLibrary()->getLibraryId())
		{
			$this->AttachmentManager->setObjectClass('Library');
			$this->AttachmentManager->setObjectId($this->getLibrary()->getLibraryId());
		}
	}

	public function onPreRender($param) 
	{
		parent::onPreRender($param);
		
		if ($this->getIsNewLibrary())
		{
			$this->TimeTableTabView->setVisible(false);
			$this->AttachmentTab->setVisible(false);
		}
		else
		{
			/*
			 * Repopulation (refresh) of timetable input grid.
			 * We need it, or after any postback the inserted textfields and weekdays
			 * get lost.
			 */
			$this->AttachmentTab->setVisible(true);
			$this->TimeTableTabView->setVisible(true);
			
			if ($this->getPage()->getIsPostBack())
			{
				if ($this->_updateGrid)
				{
					$this->updateGrid();

					$this->_updateGrid = false;
				}
				
				if ($this->getPage()->getIsCallback())
				{
					$this->writeTimeGrid($this->doUpdateDaysInTheGrid());
				}
			}
		}
	}
	
	public function checkAuth($addedCheck = true, $force = null)
	{
		$addedCheck = false;
		$clavisLibrarian = $this->getUser();
		
		if ($clavisLibrarian instanceof ClavisLibrarian)
		{
			$library = $this->getLibrary();
			
			if ($library instanceof Library)
				$addedCheck = $clavisLibrarian->getEditPermission($library);
		}

		parent::checkAuth($addedCheck, $force);
	}

	public function resetColorizeRow()
	{
		$this->setColorizeRow(array());
	}
	
	public function setColorizeRow($param = null)
	{
		$this->getApplication()->getSession()->add($this->_colorizeRowSessionName, $param, array());
	}

	public function getColorizeRow()
	{
		return $this->getApplication()->getSession()->itemAt($this->_colorizeRowSessionName, array());
	}
	
	private function pushColorizeRow($param = null)
	{
		if (is_null($param))
			return false;

		$colorized = $this->getColorizeRow();
		$colorized[$param] = true;
		$this->setColorizeRow($colorized);
	}
	
	private function popColorizeRow($param = null)
	{
		if (is_null($param))
			return false;

		$colorized = $this->getColorizeRow();
		
		if (array_key_exists($param, $colorized) && $colorized[$param])
		{
			unset ($colorized[$param]);
			$this->setColorizeRow($colorized);
			
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public function setCurrentDaysInTheGrid($param = [])
	{
		//$this->setControlState("CurrentDaysInTheGrid", serialize($param));
		$this->CurrentDaysInTheGrid->setValue(serialize($param));
	}

	public function getCurrentDaysInTheGrid($type = null)
	{
		$returnValue = [];
		
		//$arr = unserialize($this->getControlState("CurrentDaysInTheGrid", []));
		$arr = unserialize($this->CurrentDaysInTheGrid->getValue());
	
		if (!is_array($arr))
			$arr = [];
		
		/**
		 * 0 or 1 reflects the $this->getSingleDayMode() parts of the stored data
		 */
		if (!array_key_exists(0, $arr))
			$arr[0] = [];
		
		if (!array_key_exists(1, $arr))
			$arr[1] = [];
		
		if (!is_null($type)
				&& (($type == 0) 
				|| ($type == 1)))
		{
			$returnValue = $arr[$type];
		}		
		else
		{	
			$returnValue = $arr;
		}
		
		return $returnValue;
	}
		
	private function updateCurrentDaysInTheGrid($type, $values)
	{
		if ((($type == 0) 
				|| ($type == 1))
				&& (count($values) > 0))
		{
			$days = $this->getCurrentDaysInTheGrid();
			$days[(int) $type] = $values;
			
			$this->setCurrentDaysInTheGrid($days);
		}
	}
	
	public function setAlternateTableSource($param = null)
	{
		$this->setControlState("AlternateTableSource", serialize($param));
	}

	public function getAlternateTableSource()
	{
		return unserialize($this->getControlState("AlternateTableSource", []));
	}

	public function setSingleDayMode($param = null)
	{
		if (is_null($param))
			$param = false;
		
		$this->setControlState("SingleDayMode", $param, false);
		
		if ($param)
		{
			$this->DateLabel->setText(Prado::localize("data:"));
		}
		else
		{
			$this->DateLabel->setText(Prado::localize("data dal:"));
		}
	}

	public function getSingleDayMode()
	{
		return $this->getControlState("SingleDayMode", false);
	}

	public function setLibrary(Library $library)
	{
		$this->setViewState('library', $library, null);
	}

	public function getLibrary()
	{
		return $this->getViewState('library', null);
	}

	public function setLibraryId($param)
	{
		$this->setViewState('library_id', $param, null);
	}

	public function getLibraryId()
	{
		return $this->getViewState('library_id', null);
	}

	public function setFromDate($param)
	{
		$this->setControlState('fromDateInput', $param, null);
	}

	public function getFromDate()
	{
		return $this->getControlState('fromDateInput', null);
	}

	public function setToDate($param)
	{
		$this->setControlState('toDateInput', $param, null);
	}

	public function getToDate()
	{
		return $this->getControlState('toDateInput', null);
	}

	public function getIsNewLibrary()
	{
		$library = $this->getLibrary();
		
		return ($library instanceof Library && $library->isNew());
	}

	/**
	 * Exits the editing, without doing anything.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onCancel($sender, $param)
	{
		$library = $this->getLibrary();
		
		if (!$this->getIsNewLibrary() && $library instanceof Library)
		{
			$this->gotoPage(	'Library.LibraryViewPage',
								array('id' => $library->getLibraryId()));
		}
		else
		{
			$this->gotoPage('Library.LibraryList');
		}
	}
	
	public function onSave($sender, $param)
	{
		if ($this->getIsValid())
		{
			$this->saveLibrary();
			$this->gotoPage(	'Library.LibraryViewPage',
								array(	'id' => $this->getLibrary()->getLibraryId(),
										'fromDate' => $this->DayInsertFromTextBox->getData(),
										'toDate' => $this->DayInsertToTextBox->getData() ));
		}
		else
		{
			// here, and the method below, we had enqueueMessage(), and it seemed wrong ...
			$this->getPage()->writeMessage(Prado::localize("Salvataggio fallito: cercare un messaggio d'errore nella pagina, guardando in tutte le linguette"),
												ClavisMessage::ERROR);
		}
	}

	public function onApply($sender, $param)
	{
		if ($this->getIsValid())
		{
			$this->saveLibrary();
			$this->gotoPage(	$this->getPagePath(),
								array(	'id' => $this->getLibrary()->getLibraryId(),
										'tab' => $this->TabPanel->getActiveViewIndex(),
										'fromDate' => $this->DayInsertFromTextBox->getData(),
										'toDate' => $this->DayInsertToTextBox->getData() ));
		}
		else
		{
			$this->getPage()->writeMessage(Prado::localize("Salvataggio fallito: cercare un messaggio d'errore nella pagina, guardando in tutte le linguette"),
												ClavisMessage::ERROR);
		}
	}
	
	public function saveLibrary()
	{
		$library = $this->getLibrary();
		
		if (!($library instanceof Library))
		{
			$this->getPage()->writeMessage(Prado::localize("Errore: biblioteca non esistente"),
												ClavisMessage::ERROR);
			return false;
		}

		if ($this->TimeTableTabView->getVisible())
			$this->onWriteTimetable("onSave", null);

		$libraryId = $library->getLibraryId();
		$this->_wasNew = $library->isNew();

		$library->setLibraryClass($this->Libraryclass->getSelectedValue());
		$library->setConsortiaId($this->Consortia->getSelectedValue());
		$library->setDescription($this->Description->getSafeText());
		$library->setLabel($this->Label->getSafeText());
		
		$library->setLibraryCode(trim($this->LibraryCode->getSafeText()));
		
		$library->setIllCode(trim($this->IllCode->getSafeText()));
		$library->setSbnCode(trim($this->SbnCode->getSafeText()));
		$library->setShortlabel(trim($this->Shortlabel->getSafeText()));
		$library->setLibraryType($this->Librarytype->getSelectedValue());
		
		$library->setLibraryInternal($this->LibraryInternal->getChecked());
		
		$library->setLibraryStatus($this->Librarystatus->getSelectedValue());
		$library->setAddress($this->Address->getSafeText());
		$library->setCountry($this->Country->getSafeText());
		$library->setProvince($this->Province->getSafeText());
		$library->setCity($this->City->getSafeText());
		$library->setPhone($this->Phone->getSafeText());
		$library->setFax($this->Fax->getSafeText());
		$library->setEmail($this->Email->getSafeText());
		$library->setWebsite($this->Website->getSafeText());
		$library->setBillingAddress($this->Billingaddress->getSafeText());
		
		$candidateParentLibraryId = (int) $this->ParentLibraryId->getValue();		

		if ($candidateParentLibraryId == 0)
			$candidateParentLibraryId = null;
		
		$library->setParentLibraryId($candidateParentLibraryId);
		
		if ($this->getUser()->getIsSuperAdmin())
		{
			$contractExpireDate = $this->ContractExpireDate->getTimeStamp();
			
			if (!is_null($contractExpireDate)
					&& (intval($contractExpireDate) > 0))
			{
				LibraryPeer::setContractExpireDate($contractExpireDate, $libraryId);
				
				$contractExpireTolerance = intval($this->ContractExpireTolerance->getSafeText());
				LibraryPeer::setContractExpireTolerance($contractExpireTolerance, $libraryId);
			}		
		}
		
		$isModified = $library->isModified();

		if ($isModified)
		{
			$fields = array();
			
			foreach ($library->getModifiedColumns() as $column)
			{
				$expCol = explode('.', $column);
				$fields[] = $expCol[1];
			}
			
			$modifiedColumns = implode(', ', $fields);
			
			$library->save();
			apcu_clear_cache();

			$this->setLibrary($library);
			$this->enqueueMessage(Prado::localize('Dati della biblioteca "{libraryLabel}" ({libraryDescription}) modificati e salvati correttamente',
													array(	'libraryLabel' => $library->getLabel(),
															'libraryDescription' => $library->getDescription())),
									ClavisMessage::CONFIRM);
			
			ChangelogPeer::logAction(	$library,
										($this->_wasNew)
												? ChangelogPeer::LOG_CREATE
												: ChangelogPeer::LOG_UPDATE,
										$this->getUser(),
										"Modificati dati della biblioteca nei campi: {$modifiedColumns}");
		}
		else	// nothing done
		{
			$this->enqueueMessage(Prado::localize('Nessun dato della biblioteca "{libraryLabel}" ({libraryDescription}) modificato',
													array(	'libraryLabel' => $library->getLabel(),
															'libraryDescription' => $library->getDescription())),
									ClavisMessage::INFO);
		}
		
		$this->flushMessage();
	}

	public function populate()
	{
		$consortias = ConsortiaQuery::create()->find();
		$this->Consortia->setDataSource($consortias);
		$this->Consortia->dataBind();

		$library = $this->getLibrary();
		
		if (!($library instanceof Library))
		{
			$this->getPage()->writeMessage(Prado::localize("Errore: biblioteca non esistente. Riportare l'errore al fornitore del software."),
												ClavisMessage::ERROR);
			
			return false;
		}

		$libraryId = $library->getLibraryId();
		$this->UpdateData->setObject($library);
		$this->Libraryclass->setSelectedValue(strtoupper($library->getLibraryClass()));
		
		$cid = $library->getConsortiaId();
		
		if ($cid)
			$this->Consortia->setSelectedValue($cid);
		
		$this->Description->setText($library->getDescription());
		$this->Label->setText($library->getLabel());
		$this->LibraryCode->setText($library->getLibraryCode());
		$this->IllCode->setText($library->getIllCode());
		$this->SbnCode->setText($library->getSbnCode());
		$this->Shortlabel->setText($library->getShortlabel());
		$this->Librarytype->setSelectedValue($library->getLibraryType());
		
		$internalBool = ($library->getLibraryInternal() == "1");
		$internalEnableFlag = true;
		
		if (!$this->getUser()->getIsAdmin())
		{
			if ($library->isNew())
			{
				//if (!$this->getUser()->getEditPermission($library))
				$internalEnableFlag = false;
			}
			else	// already existing
			{
				if ($internalBool == false)
					$internalEnableFlag = false;
			}
		}

		if ($internalEnableFlag)
		{
			$this->LibraryInternalDisableLabel->setVisible(false);
			$this->LibraryInternal->setEnabled(true);
		}
		else
		{
			$internalBool = false;
			$this->LibraryInternalDisableLabel->setVisible(true);
			$this->LibraryInternal->setEnabled(false);
		}
		
		$this->LibraryInternal->setChecked($internalBool);
		
		$this->Librarystatus->setSelectedValue($library->getLibraryStatus());
		$this->Address->setText($library->getAddress());
		$this->Country->setText($library->getCountry());
		$this->Province->setText($library->getProvince());
		$this->City->setText($library->getCity());
		$this->Phone->setText($library->getPhone());
		$this->Fax->setText($library->getFax());
		$this->Email->setText($library->getEmail());
		$this->Website->setText($library->getWebsite());
		$this->Billingaddress->setText($library->getBillingAddress());
		
		if (!$library->hasChildrenLibrary())
		{	
			$candidateLibraryArray = LibraryQuery::create()
										->filterByLibraryInternal(1)
										->filterByParentLibraryId(null)
										->prune($this)
										->prune($library->getParentLibrary())
										->select(array('library_id'))
										->find()->toArray();

			$this->PopupParentLibraryLinkButton->setParam(array(	'showUnlink' => false,
																	'libraryIds' => serialize($candidateLibraryArray),
																	'customPopupTitle' => Prado::localize('Scegli biblioteca genitore di {mother}',
																											array('mother' => $library->getLabel())) ));
			
			$this->ParentLibrary->setText($library->getParentLibraryLabel());		
			
			$this->ParentLibraryPanel->setCssClass('panel_on_inline');
		}
		else
		{
			$this->ParentLibraryPanel->setCssClass('panel_off');
		}
		
		if ($this->getUser()->getIsSuperAdmin())
		{
			if (LibraryPeer::isContractExpire($libraryId))
			{
				$this->ContractExpireDate->setText(ClavisBase::dateFormat(LibraryPeer::getContractExpireDate($libraryId), 'dd-MM-yyyy'));
				$this->ContractExpireTolerance->setText(LibraryPeer::getContractExpireTolerance($libraryId));
			}		
		}
			
		if ($library->isNew()) 
		{
			$this->PropertyButton->setEnabled(false);
		} 
		else 
		{
			$this->PropertyButton->setEnabled(true);

			$popupPage = "Circulation.PropertyPopup&id=" . $library->getLibraryId() . "&object=library";
			$this->PropertyButton->setPopupPage($popupPage);
			$this->populateProperties();
		}
	}

	public function onResetParentLibrary($sender, $param)
	{
		$this->doResetParentLibrary($param);
	}

	private function doResetParentLibrary($param = null)
	{
		$this->ParentLibrary->setText("");
		$this->ParentLibraryId->setValue('');
		
		$this->renderParentLibraryPanel($param);
	}
	
	private function renderParentLibraryPanel($param = null)
	{
		$this->ParentLibraryPanel->render(is_null($param)
											? $this->createWriter()
											: $param->getNewWriter());
	}
	
	public function populateProperties()
	{
		$properties = LibraryPropertyQuery::create()
							->filterByLibraryId($this->getLibraryId())
							->orderByPropertyClass(Criteria::ASC)
							->find();

		$arr = array();

		foreach ($properties as $property)
		{
			$p = array();
			$p['PropertyLabel'] = LookupValuePeer::getLookupValue("LIBRARYPROPERTY", $property->getPropertyClass());
			$p['PropertyValue'] = $property->getPropertyValue();
			$p['id'] = $property->getLibraryPropertyId();

			$arr[] = $p;
		}

		$this->PropertyGrid->setDataSource($arr);
		$this->PropertyGrid->dataBind();
	}
	
	private function calculateMultipleRow()  // maybe in the future we can have parameters, for data fill
	{
		$weekdays = LookupValuePeer::getLookupClassValues('DAYSOFWEEKSHORT');
		$newGrid = [];
		$daysInTheGrid = [];
		
		foreach ($weekdays as $index => $row)
		{
			$newGrid[$index] = array(	'wdayString' => $row,
										'wdayNum' => $index,
										'day' => '0',
				
										't1Start' => '',
										't1End' => '',
										't2Start' => '',
										't2End' => '',
										't3Start' => '',
										't3End' => '',
				
										't1Enabled' => false,
										't2Enabled' => false,
										't3Enabled' => false,
										
										'open' => -1,
										'holiday' => false,
										'note' => '',
										'noteEnabled' => true );
			
			$daysInTheGrid[] = array_slice($newGrid[$index], 0, 3);
		}

		$this->updateCurrentDaysInTheGrid(0, $daysInTheGrid);	// 0 because we are in multiple week mode
		
		return $newGrid;
	}
	
	private function calculateSingleRow(	$day = null,
											$existing = array())
	{
		if (intval($day) == 0)
			return array();
		
		$wDay = date('N', $day) - 1;
		
		$t1Start = '';
		$t1End = '';
		$t2Start = '';
		$t2End = '';
		$t3Start = '';
		$t3End = '';
		$open = '';
		$holiday = '';
		$note = '';

		if (is_array($existing)
				&& (count($existing) > 0))
		{
			if (array_key_exists('t1Start', $existing))
				$t1Start = $existing['t1Start'];
			
			if (array_key_exists('t1End', $existing))
				$t1End = $existing['t1End'];
			
			if (array_key_exists('t2Start', $existing))
				$t2Start = $existing['t2Start'];
			
			if (array_key_exists('t2End', $existing))
				$t2End = $existing['t2End'];
			
			if (array_key_exists('t3Start', $existing))
				$t3Start = $existing['t3Start'];
			
			if (array_key_exists('t3End', $existing))
				$t3End = $existing['t3End'];
			
			if (array_key_exists('open', $existing))
				$open = (int) $existing['open'];
			
			if (array_key_exists('holiday', $existing))
				$holiday = $existing['holiday'];
			
			if (array_key_exists('note', $existing))
				$note = $existing['note'];
		}

		$data = array(	'wdayString' => LookupValuePeer::getLookupValue('DAYSOFWEEKSHORT', $wDay),
						'wdayNum' => $wDay,
						'day' => $day,
			
						't1Start' => $t1Start,
						't1End' => $t1End,
						't2Start' => $t2Start,
						't2End' => $t2End,
						't3Start' => $t3Start,
						't3End' => $t3End,

						'open' => $open,
						'holiday' => $holiday,
						'note' => $note,
						'noteEnabled' => $open >= 0 );
		
		$this->updateCurrentDaysInTheGrid(1, array(array_slice($data, 0, 3)));	// 1 because we are in single day mode
		
		return $data;
	}
	
	public function onChangedDayInsertFrom($sender, $param)
	{
		$day = ($this->DayInsertFromTextBox->getSafeText() != ''
							? $this->DayInsertFromTextBox->getTimeStamp()
							: null);
		
		$this->DayInsertFromTextBoxCopy->setText($day);
		
		if (intval($day) == 0)
		{
			$this->DayInsertFromTextBox->setText('');
			$this->getPage()->writeMessage(Prado::localize("Specificare una data"),
												ClavisMessage::WARNING);
			
			return false;
		}

		if ($this->getSingleDayMode())
		{
			$readTimeGrid = $this->readTimeGrid($param);
			
			if (array_key_exists('ok', $readTimeGrid))
				unset ($readTimeGrid['ok']);
			
			if (array_key_exists('timetableErrorsFlag', $readTimeGrid))
				unset ($readTimeGrid['timetableErrorsFlag']);
			
			if (array_key_exists('allModified', $readTimeGrid))
				unset ($readTimeGrid['allModified']);

			/**
			$newGrid = array();
			$newGrid[] = $this->calculateSingleRow($day, $readTimeGrid[0]);

			$this->writeTimeGrid($newGrid, $param);
			 */
			
			$this->doFillSingleDay($day);
		}
	}
	
	public function onChangedDayInsertTo($sender, $param)
	{
		$day = ($this->DayInsertToTextBox->getSafeText() != ''
							? $this->DayInsertToTextBox->getTimeStamp()
							: null);
				
		$this->DayInsertToTextBoxCopy->setText($day);
	}
	
	public function onSwitchSingleDayMode($sender, $param)
	{
		$singleMode = !$this->getSingleDayMode();
		$storedSource = $this->getAlternateTableSource();  //var_dump($storedSource);
		$onScreenSource = $this->readTimeGrid();
		
		/*
		if (!$singleMode)
		{
			$aa = $this->getAlternateTableSource();
			if (count($aa) > 0)
			{	
				var_dump($aa);
				die;
			}
		}
		*/
		
		
		
		// if single day mode
		if ($singleMode
				&& (count($storedSource) == 0))
		{
			$day = ($this->DayInsertFromTextBox->getSafeText() != ''
							? $this->DayInsertFromTextBox->getTimeStamp()
							: null);

			if (intval($day) == 0)
			{
				$this->SingleModeCheckBox->setChecked(false);
				$this->getPage()->writeMessage(Prado::localize("Specificare un giorno nel campo 'data dal'"),
													ClavisMessage::WARNING);
				
				return false;
			}

			/**
			$storedSource = array();
			$storedSource[] = $this->calculateSingleRow($day);
			 */
			$this->doFillSingleDay($day);
			$this->setAlternateTableSource($onScreenSource);			//// mbrancalion, da vedere se lasciare o no

			return;
			
		}	// end of single day mode
		
		if (!$singleMode
				&& (count($storedSource) < 2))
			$storedSource = $this->calculateMultipleRow();

		$this->setAlternateTableSource($onScreenSource);		
		$this->setSingleDayMode($singleMode);
		$this->HolidayColumn->setVisible($singleMode);
		$this->writeTimeGrid($storedSource, $param);
		$this->_updateGrid = false;
	}

	public function onDayInsertFromChanged($sender, $param)  // prova, da cancellare
	{
		$dayTo = trim($this->DayInsertToTextBox->getSafeText());
		
		if ($dayTo == "")
		{
			$this->ModifyTimetablePanel->render($param->getNewWriter());
			
			return false;
		}
	}

	private function isTimesValid($start = "", $end = "")
	{
		if (($start == TClavisTimePicker::TIME_INVALID)
				|| ($end == TClavisTimePicker::TIME_INVALID))
			return false;
		
		if (($start . $end) == "")
			return true;
		
		if (($start == "")
				|| ($end == ""))
			return false;
		
		if ($start >= $end)
			return false;
		
		return true;
	}
	
	private function readTimeGrid($param = null, $dayOnly = '')
	{
		$ok = true;
		$allModified = false;
		$timetableErrorsFlag = false;
		$readTimeGrid = array();

		foreach ($this->TimeGrid->getItems() as $row)
		{
			$rowError = false;
			$rowTimeTouched = false;
			
			$wdayString = $row->DayColumn->WdayStringValue->getValue();
			$wdayNum = $row->DayColumn->WdayNumValue->getValue();
			$day = $row->DayColumn->DayValue->getValue();
			
			if (($dayOnly != '')
					&& ($day != $dayOnly))
				continue;
			
			$holiday = $row->HolidayColumn->HolidayCheckBox->getChecked();

			if (!$holiday)
			{
				$t1Start = $row->Time1Column->T1Start->readTime();
				$t1End = $row->Time1Column->T1End->readTime();

				if (!$this->isTimesValid($t1Start, $t1End))
				{
					$t1Start = "";
					$t1End = "";
					$row->Time1Column->T1Start->resetTime();
					$row->Time1Column->T1End->resetTime();
					$rowError = true;
				}

				$t2Start = $row->Time2Column->T2Start->readTime();
				$t2End = $row->Time2Column->T2End->readTime();

				if (!$this->isTimesValid($t2Start, $t2End))				
				{
					$t2Start = "";
					$t2End = "";
					$row->Time2Column->T2Start->resetTime();
					$row->Time2Column->T2End->resetTime();
					$rowError = true;
				}

				$t3Start = $row->Time3Column->T3Start->readTime();
				$t3End = $row->Time3Column->T3End->readTime();

				if (!$this->isTimesValid($t3Start, $t3End))
				{
					$t3Start = "";
					$t3End = "";
					$row->Time3Column->T3Start->resetTime();
					$row->Time3Column->T3End->resetTime();
					$rowError = true;
				}
			}
			else	// if "holiday" control has been marked
			{
				$t1Start = "";
				$t1End = "";
				$t2Start = "";
				$t2End = "";
				$t3Start = "";
				$t3End = "";
			}
			
			$open = (int) $row->OpenColumn->OpenSelect->getSelectedValue();
			$note = $row->NoteColumn->Note->getSafeText();
				
			$timesTouched = (($t1Start . $t1End . $t2Start . $t2End . $t3Start . $t3End) != ""); 
			
			$rowTouched = ( $timesTouched
								|| $holiday
								|| ($open >= 0));

			// checking logic
			
			/**
			 * If opening times are left untouched
			 */
			if (!$timesTouched)
			{
				/**
				 * If we only marked holiday or rather we put this day as 'closed'
				 */
				if (($open == 0) // closed
						|| $holiday)
				{
					$open = 0;
					$t1Start = "";
					$t1End = "";
					$t2Start = "";
					$t2End = "";
					$t3Start = "";
					$t3End = "";

					$rowModified = true;
				}

				/**
				 * If we put the as 'open' but we have selected no opening times.
				 * We can't accept it, and have to (output the error and)
				 * reset to "undefined" (and not open).
				 */
				elseif ($open == 1)	
				{
					$timetableErrorsFlag = true;	// to evaluate if we still want it
					$open = -1;
					$t1Start = "";
					$t1End = "";
					$t2Start = "";
					$t2End = "";
					$t3Start = "";
					$t3End = "";

					//////$this->pushColorizeRow($row->getItemIndex());		// do we still want it ? .......................................
					$row->OpenColumn->OpenSelect->setSelectedValue(-1);
					$rowModified = false;
				}
			}
			
			/**
			 * If we have touched someway the opening times
			 */
			else
			{
				/**
				 * If we have selected some times, but we selected
				 * as explicit 'closed' or as 'holiday'.
				 * Maybe it's not used anymore (after active callback insertion)
				 */
				if (($open == 0)
						|| $holiday)
				{
					//$timetableErrorsFlag = true;
					$t1Start = "";
					$t1End = "";
					$t2Start = "";
					$t2End = "";
					$t3Start = "";
					$t3End = "";

					//$this->pushColorizeRow($row->getItemIndex());
					$row->OpenColumn->OpenSelect->setSelectedValue(0);

					$rowModified = true;
				}

				/**
				 * Everything seems ok for modifying a day time
				 */
				else
				{
					$rowModified = true;
				}
			}
			
			if ($rowModified)
				$allModified = true;

			$readTimeGrid[$row->getItemIndex()] = array(	'wdayString' => $wdayString,
															'wdayNum' => $wdayNum,
															'day' => $day,

															't1Start' => $t1Start,
															't1End' => $t1End,
															't2Start' => $t2Start,
															't2End' => $t2End,
															't3Start' => $t3Start,
															't3End' => $t3End,

															'open' => $open,
															'holiday' => $holiday,
															'note' => $row->NoteColumn->Note->getSafeText(),
															'noteEnabled' => $open >= 0,
															'rowModified' => $rowModified );

		}  // end of cycle into the grid of times

		if (count($readTimeGrid) > 0)
			$readTimeGrid['ok'] = $ok;
		
		$readTimeGrid['timetableErrorsFlag'] = $timetableErrorsFlag;
		$readTimeGrid['allModified'] = $allModified;
		
		////// mbrancalion, da valutare se serve
//		if ($this->getPage()->getIsCallback() && !is_null($param))
//			$this->GridPanel->render($param->getNewWriter());
		
		$this->renderTimeTable($param);

		return $readTimeGrid;
	}

		private function readActualTimeGridDays($param = null, $dayOnly = '')
	{
		$readTimeGrid = [];

		foreach ($this->TimeGrid->getItems() as $row)
		{
			$wdayString = $row->DayColumn->WdayStringValue->getValue();
			$wdayNum = $row->DayColumn->WdayNumValue->getValue();
			$day = $row->DayColumn->DayValue->getValue();
			
			if (($dayOnly != '')
					&& ($day != $dayOnly))
				continue;
			
//			$holiday = $row->HolidayColumn->HolidayCheckBox->getChecked();

			$readTimeGrid[$row->getItemIndex()] = array(	'wdayString' => $wdayString,
															'wdayNum' => $wdayNum,
															'day' => $day );

		}  // end of cycle

		return $readTimeGrid;
	}

	private function OLDreadTimeGrid($param = null, $dayOnly = '')
	{
		$ok = true;
		$touched = false;
		$timetableErrorsFlag = false;
		$readTimeGrid = array();

		foreach ($this->TimeGrid->getItems() as $row)
		{
			$rowError = false;
			$rowTimeTouched = false;
			
			$wdayString = $row->DayColumn->WdayString->getText();
			$wdayNum = $row->DayColumn->WdayNum->getText();
			$day = $row->DayColumn->Day->getValue();
			
			if ($day != $dayOnly)
				continue;
			
			$holiday = $row->HolidayColumn->HolidayCheckBox->getChecked();

			if (!$holiday)
			{
				$t1Start = $row->Time1Column->T1Start->readTime();
				$t1End = $row->Time1Column->T1End->readTime();

				if (!$this->isTimesValid($t1Start, $t1End))
				{
					$t1Start = "";
					$t1End = "";
					$row->Time1Column->T1Start->resetTime();
					$row->Time1Column->T1End->resetTime();
					$rowError = true;
				}

				$t2Start = $row->Time2Column->T2Start->readTime();
				$t2End = $row->Time2Column->T2End->readTime();

				if (!$this->isTimesValid($t2Start, $t2End))				
				{
					$t2Start = "";
					$t2End = "";
					$row->Time2Column->T2Start->resetTime();
					$row->Time2Column->T2End->resetTime();
					$rowError = true;
				}

				$t3Start = $row->Time3Column->T3Start->readTime();
				$t3End = $row->Time3Column->T3End->readTime();

				if (!$this->isTimesValid($t3Start, $t3End))
				{
					$t3Start = "";
					$t3End = "";
					$row->Time3Column->T3Start->resetTime();
					$row->Time3Column->T3End->resetTime();
					$rowError = true;
				}
			}
			else	// if "holiday" control has been marked
			{
				$t1Start = "";
				$t1End = "";
				$t2Start = "";
				$t2End = "";
				$t3Start = "";
				$t3End = "";
			}
			
			$open = $row->OpenColumn->OpenSelect->getSelectedValue();
			$note = $row->NoteColumn->Note->getSafeText();
						
			$rowTimeTouched = ((($t1Start . $t1End . $t2Start . $t2End . $t3Start . $t3End) != "") 
								|| $holiday
								|| ($open >= 0));

			if (!$rowTimeTouched
					&& (($open == 0) || $holiday))
			{
				/**
				 * If we only marked holiday or rather we put this day as closed
				 */
				$open = 0;
				$t1Start = "";
				$t1End = "";
				$t2Start = "";
				$t2End = "";
				$t3Start = "";
				$t3End = "";
				
				$touched = true;
			}
			elseif (!$rowTimeTouched && ($open == 1))	
			{
				/**
				 * If we put the as 'open' but we have selected no time.
				 * We can't accept it, and have to (output the error and)
				 * reset to "undefined" (and not open).
				 */
				$timetableErrorsFlag = true;
				$open = -1;
				$t1Start = "";
				$t1End = "";
				$t2Start = "";
				$t2End = "";
				$t3Start = "";
				$t3End = "";
				
				//////$this->pushColorizeRow($row->getItemIndex());		// do we still want it ? .......................................
				$row->OpenColumn->OpenSelect->setSelectedValue(-1);
			}
			elseif ($rowTimeTouched && ($open == 0))
			{
				/**
				 * If we have selected some times, but we selected
				 * as explicit 'closed'.
				 * Maybe it's not used anymore (after active callback insertion)
				 */
				//$timetableErrorsFlag = true;
				$t1Start = "";
				$t1End = "";
				$t2Start = "";
				$t2End = "";
				$t3Start = "";
				$t3End = "";
				
				//$this->pushColorizeRow($row->getItemIndex());
				$row->OpenColumn->OpenSelect->setSelectedValue(0);
				
				$touched = true;
			}
			else
			{
				/**
				 * Everything seems ok for modifying a day time
				 */
				if ($rowTimeTouched)
					$touched = true;
			}

			$readTimeGrid[$row->getItemIndex()] = array('wdayString' => $wdayString,
														'wdayNum' => $wdayNum,
														'day' => $day,

														't1Start' => $t1Start,
														't1End' => $t1End,
														't2Start' => $t2Start,
														't2End' => $t2End,
														't3Start' => $t3Start,
														't3End' => $t3End,

														'open' => (int) $open,
														'holiday' => $holiday,
														'note' => $row->NoteColumn->Note->getSafeText() );
			
		}  // end of cycle into the grid of times

		if (count($readTimeGrid) > 0)
			$readTimeGrid['ok'] = $ok;
		
		$readTimeGrid['timetableErrorsFlag'] = $timetableErrorsFlag;
		$readTimeGrid['allModified'] = $touched;
		
//		if ($this->getPage()->getIsCallback() && !is_null($param))
//			$this->GridPanel->render($param->getNewWriter());
		$this->renderTimeTable($param);

		return $readTimeGrid;
	}

	public function onColorize($sender, $param)
	{
		$item = $param->Item;
		$itemIndex = $item->ItemIndex;
		
		if (($item->getItemType() != "Item")
				&& ($item->getItemType() != "AlternatingItem"))
			return false;
	
		if ($this->popColorizeRow($itemIndex))
			$item->setStyle('background: red');	
	}
	
	private function writeTimeGrid(	$grid = null,
									$param = null)
	{
		if (!is_array($grid) 
				|| count($grid) == 0)
			return false;

		if (array_key_exists('ok', $grid))
			unset ($grid['ok']);
		
		if (array_key_exists('timetableErrorsFlag', $grid))
			unset ($grid['timetableErrorsFlag']);

		if (array_key_exists('allModified', $grid))
			unset ($grid['allModified']);

		$this->TimeGrid->setDataSource($grid);
		$this->TimeGrid->dataBind();
		
//		if ($this->getPage()->getIsCallBack())
//		{
//			$writer = ($param instanceof TEventParameter) 
//							? $param->getNewWriter() 
//							: $this->getPage()->createWriter();
//			
//			$this->GridPanel->dataBind();
//			$this->GridPanel->render($writer);
//		}
		
		$this->renderTimeTable($param);
	}
	
	private function doUpdateDaysInTheGrid($param = null)
	{
		$storedDays = $this->getCurrentDaysInTheGrid($this->getSingleDayMode());
		
		if (!is_array($storedDays) 
				|| count($storedDays) == 0)
			return false;

		$currentGrid = [];
		
		foreach ($this->TimeGrid->getItems() as $index => $row)
		{
			$wdayString = $storedDays[$index]['wdayString'];
			$wdayNum = $storedDays[$index]['wdayNum'];
			$day = $storedDays[$index]['day'];
			
			$open = (int) $row->OpenColumn->OpenSelect->getSelectedValue();
			$holiday = $row->HolidayColumn->HolidayCheckBox->getChecked();

			$t1Start = $row->Time1Column->T1Start->readTime();
			$t1End = $row->Time1Column->T1End->readTime();
			$t2Start = $row->Time2Column->T2Start->readTime();
			$t2End = $row->Time2Column->T2End->readTime();
			$t3Start = $row->Time3Column->T3Start->readTime();
			$t3End = $row->Time3Column->T3End->readTime();
			
			$note = $row->NoteColumn->Note->getSafeText();
			
			$currentGrid[$index] = array(	'wdayString' => $wdayString,
											'wdayNum' => $wdayNum,
											'day' => $day,

											't1Start' => $t1Start,
											't1End' => $t1End,
											't2Start' => $t2Start,
											't2End' => $t2End,
											't3Start' => $t3Start,
											't3End' => $t3End,

											'open' => (int) $open,
											'holiday' => $holiday,
											'note' => $row->NoteColumn->Note->getSafeText(),
											'noteEnabled' => $open > 0,);
		}
		
		/////$this->renderTimeTable($param);
		return $currentGrid;
	}
	
	private function updateGrid()
	{
		//$open = $row->OpenColumn->OpenSelect->getSelectedValue();
		$grid = $this->readTimeGrid();

		if (!is_null($grid) && (count($grid) > 0))
			$this->writeTimeGrid($grid);
	}
	
	public function onPutHoliday($sender, $param)
	{
		if ($sender->getChecked())
		{
			$sender->getParent()->getParent()->OpenColumn->OpenSelect->setSelectedValue("0");
			
			$this->onChangeOpenSelect($sender->getParent()->getParent()->OpenColumn->OpenSelect, $param);
//			
//			$sender->getParent()->getParent()->Time1Column->T1Start->setEnabled(false);
//			$sender->getParent()->getParent()->Time1Column->T1End->setEnabled(false);
//			$sender->getParent()->getParent()->Time2Column->T2Start->setEnabled(false);
//			$sender->getParent()->getParent()->Time2Column->T2End->setEnabled(false);
//			$sender->getParent()->getParent()->Time3Column->T3Start->setEnabled(false);
//			$sender->getParent()->getParent()->Time3Column->T3End->setEnabled(false);
//			
//			$sender->getParent()->getParent()->Time1Column->T1Start->resetTime();
//			$sender->getParent()->getParent()->Time1Column->T1End->resetTime();
//			$sender->getParent()->getParent()->Time2Column->T2Start->resetTime();
//			$sender->getParent()->getParent()->Time2Column->T2End->resetTime();
//			$sender->getParent()->getParent()->Time3Column->T3Start->resetTime();
//			$sender->getParent()->getParent()->Time3Column->T3End->resetTime();
//			
//			$this->renderTimeTable($param);
		}
	}
	
	public function onChangeOpenSelect($sender, $param)
	{
//		foreach ($this->TimeGrid->getItems() as $row)
//		{
//			$wdayString = $row->DayColumn->WdayString->getText();
//			$day = $row->DayColumn->Day->getValue();
//			
//			$open = $row->OpenColumn->OpenSelect->getSelectedValue();
//		}
		
		//CONTINUARE FACENDO UPDATARE SOLO LA RIGA NUOVA, determinata dal $sender
		//		e usare il metodo sopra updateGrid()
				
		
		$this->_updateGrid = false;  /// test
		
		$newOpenState = ($sender->getSelectedValue() > 0);

		/////$index = $sender->getParent()->getParent()->getItemIndex();

		$sender->getParent()->getParent()->Time1Column->T1Start->setEnabled($newOpenState);
		$sender->getParent()->getParent()->Time1Column->T1End->setEnabled($newOpenState);
		$sender->getParent()->getParent()->Time2Column->T2Start->setEnabled($newOpenState);
		$sender->getParent()->getParent()->Time2Column->T2End->setEnabled($newOpenState);
		$sender->getParent()->getParent()->Time3Column->T3Start->setEnabled($newOpenState);
		$sender->getParent()->getParent()->Time3Column->T3End->setEnabled($newOpenState);

		if ($newOpenState == false)
		{
			$sender->getParent()->getParent()->Time1Column->T1Start->resetTime();
			$sender->getParent()->getParent()->Time1Column->T1End->resetTime();
			$sender->getParent()->getParent()->Time2Column->T2Start->resetTime();
			$sender->getParent()->getParent()->Time2Column->T2End->resetTime();
			$sender->getParent()->getParent()->Time3Column->T3Start->resetTime();
			$sender->getParent()->getParent()->Time3Column->T3End->resetTime();
		}

		$this->renderTimeTable($param);
	}

	private function renderTimeTable($param)
	{
		if ($this->getPage()->getIsCallback())
		{
			$this->GridPanel->render($param instanceof TCallbackEventParameter
											? $writer = $param->getNewWriter()
											: $writer = $this->getPage()->createWriter());
		}
	}
	
	public function onCopyBelow($sender, $param)
	{
		$row = $sender->getParent()->getParent();
		
		$openSelect = $row->OpenColumn->OpenSelect->getSelectedValue();
		$open = $openSelect >= 0;
				
		$t1Start = "";
		$t1End = "";
		$t2Start = "";
		$t2End = "";
		$t3Start = "";
		$t3End = "";
		
		if ($open)
		{
			$t1Start = $row->Time1Column->T1Start->readTime();
			$t1End = $row->Time1Column->T1End->readTime();

			if (!$this->isTimesValid($t1Start, $t1End))
			{
				$t1Start = "";
				$t1End = "";
			}

			$t2Start = $row->Time2Column->T2Start->readTime();
			$t2End = $row->Time2Column->T2End->readTime();

			if (!$this->isTimesValid($t2Start, $t2End))
			{
				$t2Start = "";
				$t2End = "";
			}

			$t3Start = $row->Time3Column->T3Start->readTime();
			$t3End = $row->Time3Column->T3End->readTime();

			if (!$this->isTimesValid($t3Start, $t3End))
			{
				$t3Start = "";
				$t3End = "";
			}
		}
		
		if ($t1Start . $t1End . $t2Start . $t2End . $t3Start . $t3End == '')
			$openSelect = -1;
		
		//$note = ($open ? $row->NoteColumn->Note->getText() : '');
		$note = $row->NoteColumn->Note->getText();
		
		// write on next row
		$nextItemIndex = $row->getItemIndex() + 1;

		if ($nextItemIndex == 7)
			$nextItemIndex = 0;		// toroid style

		$nextItem = $row->getParent()->getItems()->itemAt($nextItemIndex);
		
		$nextItem->OpenColumn->OpenSelect->setSelectedValue($openSelect);
		
		$nextItem->Time1Column->T1Start->setEnabled($open);
		$nextItem->Time1Column->T1End->setEnabled($open);
		$nextItem->Time2Column->T2Start->setEnabled($open);
		$nextItem->Time2Column->T2End->setEnabled($open);
		$nextItem->Time3Column->T3Start->setEnabled($open);
		$nextItem->Time3Column->T3End->setEnabled($open);
		
		$nextItem->Time1Column->T1Start->writeTime($t1Start);
		$nextItem->Time1Column->T1End->writeTime($t1End);
		$nextItem->Time2Column->T2Start->writeTime($t2Start);
		$nextItem->Time2Column->T2End->writeTime($t2End);
		$nextItem->Time3Column->T3Start->writeTime($t3Start);
		$nextItem->Time3Column->T3End->writeTime($t3End);
		
		$nextItem->NoteColumn->Note->setEnabled($open);
		$nextItem->NoteColumn->Note->setText($note);
		
		$this->renderTimeTable($param);
	}
	
	public function onResetTimes($sender, $param)
	{
		$sender->getParent()->getParent()->Time1Column->T1Start->resetTime();
		$sender->getParent()->getParent()->Time1Column->T1End->resetTime();
		$sender->getParent()->getParent()->Time2Column->T2Start->resetTime();
		$sender->getParent()->getParent()->Time2Column->T2End->resetTime();
		$sender->getParent()->getParent()->Time3Column->T3Start->resetTime();
		$sender->getParent()->getParent()->Time3Column->T3End->resetTime();
		
		//$sender->getParent()->getParent()->OpenColumn->OpenSelect->setSelectedValue(-1);
		//$sender->getParent()->getParent()->NoteColumn->Note->setText('');
		//$sender->getParent()->getParent()->HolidayColumn->HolidayCheckBox->setChecked(false);
		



/////$this->updateGrid();
		
		
		
		$this->renderTimeTable($param);
	}
	
	public function onFillSingleDay($sender, $param)
	{
		$day = intval($param->CommandParameter);
	
		if ($day == 0)
			return false;
		
		$this->doFillSingleDay($day);
	}
	
	private function doFillSingleDay($day = 0)
	{
		if ($day == 0)
		{
			$this->getPage()->writeMessage(Prado::localize("Errore sul passaggio dei parametri in aggiorna orario giorno singolo"),
												ClavisMessage::ERROR);
		
			return false;
		}
				
		$existing = array();
		
		$timeRow = LibraryTimetableQuery::create()
						->filterByLibraryId($this->getLibraryId())
						->filterByTimetableDay($day)
						->findOne();
		
		if ($timeRow instanceof LibraryTimetable)
		{
			$existing = array(	'open' => $timeRow->getTimetableOpen(),
								'holiday' => $timeRow->getTimetableHoliday(),
								'note' => $timeRow->getTimetableNote(),
								'noteEnabled' => true,
								't1Start' => $timeRow->getTime1Start(),
								't1End' => $timeRow->getTime1End(),
								't2Start' => $timeRow->getTime2Start(),
								't2End' => $timeRow->getTime2End(),
								't3Start' => $timeRow->getTime3Start(),
								't3End' => $timeRow->getTime3End() );
		}
		else
		{
			$existing = array(	'open' => -1,
								'holiday' => 0,
								'note' => '',
								'noteEnabled' => false,
								't1Start' => 0,
								't1End' => 0,
								't2Start' => 0,
								't2End' => 0,
								't3Start' => 0,
								't3End' => 0 );
		}

		$storedSource = $this->getAlternateTableSource();
		//////$readTimeGridd = $this->readTimeGrid();
		//////$this->setAlternateTableSource($readTimeGridd);
		
		if (count($storedSource) == 0)
		{	
			//$storedSource = array();
			//$storedSource[] = $this->calculateSingleRow($day, $existing);
			$storedSource = array($this->calculateSingleRow($day, $existing));
		}
		
		$this->writeTimeGrid($storedSource);

//var_dump($this->getAlternateTableSource());die;
		$this->setSingleDayMode(true);
		$this->HolidayColumn->setVisible(true);
		$this->DayInsertFromTextBox->setTimeStamp($day);
		$this->SingleModeCheckBox->setChecked(true);
		$this->_updateGrid = false;
	}
	
	public function onWriteTimetable($sender, $param)
	{
		$someUpdated = false;
		
		$this->getPage()->cleanMessageQueue();
		$multiLibraryMode = false;
		$keepExistingTimetableMode = false;
		$resultCheckDueDate = array();
		$dueDateCheckFlag = ($this->CheckLoanDueDateCheckBox->getChecked() == true);

		$readTimeGrid = $this->readTimeGrid($param, $this->getSingleDayMode());		/// !!!!!!!!!!!!!!!!!

		if (array_key_exists('allModified', $readTimeGrid)
				&& ($readTimeGrid['allModified']) === false)
		{
			return false;
		}
		
		if (array_key_exists('ok', $readTimeGrid)
				&& !$readTimeGrid['ok'])
		{
			$this->getPage()->enqueueMessage(Prado::localize("Azzeramento degli orari non effettuato in modo corretto. Riprovare."),
												ClavisMessage::WARNING);
		}
		elseif (array_key_exists('timetableErrorsFlag', $readTimeGrid)
					&& $readTimeGrid['timetableErrorsFlag'])
		{
			$this->getPage()->enqueueMessage(Prado::localize("Uno o più giorni sono stati considerati chiusi per incongruenze fra dichiarazione di apertura e orari. Riprovare."),
												ClavisMessage::WARNING);
		}
		else
		{	// everything is ok
			if (array_key_exists('ok', $readTimeGrid))
				unset ($readTimeGrid['ok']);
			
			if (array_key_exists('timetableErrorsFlag', $readTimeGrid))
				unset ($readTimeGrid['timetableErrorsFlag']);

			if (array_key_exists('allModified', $readTimeGrid))
				unset ($readTimeGrid['allModified']);
			
			$myLibraryId = $this->getLibraryId();
			
			if (intval($myLibraryId) > 0)
			{
				$targetLibraryIds['myLibrary'] = $myLibraryId;

				/****		Obscured part
				if ($this->KeepWritingMode->getChecked())
				{
					$keepExistingTimetableMode = true;
				}
				elseif($this->OverwriteWritingMode->getChecked())
				{
					$keepExistingTimetableMode = false;
				}
				else
				{
					$keepExistingTimetableMode = false;
				}
				 * 
				 */
				$keepExistingTimetableMode = false;
				
				// multilibrary part (admin mode)
				if ($this->MultiLibraryCheck->getChecked())
				{
					$shelfId = intval($this->ShelfId->getValue());
					
					if ($shelfId > 0)
					{
						$otherLibraryIds = ShelfItemQuery::create()
											->filterByShelfId($shelfId)
											->filterByObjectClass(ShelfPeer::TYPE_LIBRARY)
											->clearSelectColumns()
											->select(array("object_id"))	// we want the library_id's only
											->find()->toArray();
						
						if (count($otherLibraryIds) > 0)
						{
							$targetLibraryIds = $otherLibraryIds;
							$targetLibraryIds['myLibrary'] = $myLibraryId;
							$multiLibraryMode = true;
						}
					}
				}	// endof multilibrary part (admin)
				
				$targetLibraryIdsString = implode(',', $targetLibraryIds);

				// everything seems ok: we're gonna write new timetables in the table .....
				$fromDate = $this->DayInsertFromTextBox->getSafeText() != '' 
									? $this->DayInsertFromTextBox->getTimeStamp() 
									: null;
				
				if (!is_null($fromDate))
				{
					if (count($readTimeGrid) == 7)       // week mode (from starting to ending date)
					{
						$toDate = $this->DayInsertToTextBox->getSafeText() != '' 
											? $this->DayInsertToTextBox->getTimeStamp() 
											: null;
						
						if (is_null($toDate))
						{
							$toDate = $fromDate;
							$this->DayInsertToTextBox->setText($this->DayInsertFromTextBox->getText());
						}
							
						if (!is_null($toDate))
						{
							$ok = 0;
							$failed = [];
							$none = [];
							$holidaySkip = [];
							$unknown = [];
							
							// we want a cycle on a dates interval
							for ($date = $fromDate; $date <= $toDate; $date += ClavisLoanManager::DAYS_1)
							{								
								// weekday's logic, from the input grid
								$weekDayNumber = date('N', $date) - 1;
								
								if (!array_key_exists($weekDayNumber, $readTimeGrid))
									continue;	// we won't consider a non edited weekday
								
								$returnValue = $this->doSaveTimetable(	$targetLibraryIds,
																		$date,
																		$readTimeGrid[$weekDayNumber],

																		false,			// singlemode													))
																		$keepExistingTimetableMode);
								
								switch ($returnValue)
								{
									case LibraryTimetablePeer::WRITE_OK:
										$ok++;
										
										break;

									case LibraryTimetablePeer::WRITE_NONE:
										$none[] = Clavis::dateFormat($date);
										
										break;

									case LibraryTimetablePeer::WRITE_HOLIDAYSKIP:
										$holidaySkip[] = Clavis::dateFormat($date);
										
										break;

									case LibraryTimetablePeer::WRITE_FAILED:
										$failed[] = Clavis::dateFormat($date);
										
										break;
									
									default:
										$unknown[] = Clavis::dateFormat($date);
								}
							}   // end of 'for' cycle
							
							if ($ok > 0)
							{
								$someUpdated = true;
								$formattedFromDate = Clavis::dateFormat($fromDate);
								$formattedToDate = Clavis::dateFormat($toDate);
																		
								$this->getPage()->enqueueMessage(Prado::localize("Modificata tabella degli orari dalla data {data1} fino alla data {data2}. Sono stati modificati {num} giorni nelle biblioteche con id={libraries}",
																					array(	'data1' => $formattedFromDate,
																							'data2' => $formattedToDate,
																							'num' => $ok,
																							'libraries' => $targetLibraryIdsString )),
																	ClavisMessage::CONFIRM);

								ChangelogPeer::logAction(	$multiLibraryMode ? "Librarian" : "Library",
															ChangelogPeer::LOG_UPDATE,
															$this->getUser(),
															"Modificati orari per le biblioteche con id=$targetLibraryIdsString. Modificati $ok giorni dalla data $formattedFromDate alla data $formattedToDate",
															$multiLibraryMode ? $this->getUser()->getId() : $myLibraryId);
								
								// cheching for moving loans
								if ($dueDateCheckFlag)
								{	
									$resultCheckDueDate = $this->checkLoanDueDate(	array_values($targetLibraryIds),	// libraryIds
																					$fromDate,
																					$toDate );
								}
								
								$this->Timetable->populate();
							}

							if (count($unknown) > 0)
							{
								$this->getPage()->enqueueMessage(Prado::localize("Giorni non modificati, a causa di errori sconosciuti, nella tabella orari per le {date} nelle biblioteche con id={libraries}",
																					array(	'date' => implode(',', $unknown), 
																							'libraries' => $targetLibraryIdsString )),
																	ClavisMessage::ERROR);
								
								ChangelogPeer::logAction(	$multiLibraryMode ? "Librarian" : "Library",
															ChangelogPeer::LOG_UPDATE,
															$this->getUser(),
															"Errori sconosciuti sulla modifica orari biblioteche con id=$targetLibraryIdsString, per i giorni: " . implode(',', $unknown),
															$multiLibraryMode ? $this->getUser()->getId() : $myLibraryId);
							}
							
							if (count($failed) > 0)
							{
								$this->getPage()->enqueueMessage(Prado::localize("Giorni non modificati, a causa di errori, nella tabella orari: {date} nelle biblioteche con id={libraries}",
																					array(	'date' => implode(',', $failed), 
																							'libraries' => $targetLibraryIdsString )),
																	ClavisMessage::ERROR);
								
								ChangelogPeer::logAction(	$multiLibraryMode ? "Librarian" : "Library",
															ChangelogPeer::LOG_UPDATE,
															$this->getUser(),
															"Errori sulla modifica orari biblioteche con id=$targetLibraryIdsString, giorni: " . implode(',', $failed),
															$multiLibraryMode ? $this->getUser()->getId() : $myLibraryId);
							}

							if (count($none) > 0)
							{
								$this->getPage()->enqueueMessage(Prado::localize("Giorni non modificati nella tabella orari: {date} nelle biblioteche con id={libraries}",
																					array(	'date' => implode(',', $none), 
																							'libraries' => $targetLibraryIdsString )),
																	ClavisMessage::INFO);
								
								ChangelogPeer::logAction(	$multiLibraryMode ? "Librarian" : "Library",
															ChangelogPeer::LOG_UPDATE,
															$this->getUser(),
															"Giorni non modificati nella tabella orari delle biblioteche con id=$targetLibraryIdsString, giorni: " . implode(',', $failed),
															$multiLibraryMode ? $this->getUser()->getId() : $myLibraryId);
							}

							if (count($holidaySkip) > 0)
							{
								$this->getPage()->enqueueMessage(Prado::localize("Giorni non modificati nella tabella orari perchè sono già giorni festivi: {date} nelle biblioteche con id={libraries}",
																					array(	'date' => implode(',', $holidaySkip), 
																							'libraries' => $targetLibraryIdsString )),
																	ClavisMessage::WARNING);
								
								ChangelogPeer::logAction(	$multiLibraryMode ? "Librarian" : "Library",
															ChangelogPeer::LOG_UPDATE,
															$this->getUser(),
															"Giorni non modificati perchè sono già giorni festivi, nella tabella orari delle biblioteche con id=$targetLibraryIdsString, giorni: " . implode(',', $holidaySkip),
															$multiLibraryMode ? $this->getUser()->getId() : $myLibraryId);
							}
						}	// end of 'final date specified'
						else
						{
							$this->getPage()->enqueueMessage(Prado::localize("Data finale non specificata"),
																ClavisMessage::ERROR);
						}
						
					}  // endof entire week mode (7 days)
					elseif (count($readTimeGrid) == 1)   // single day case (starting date alone, as a 'date')
					{
						$returnValue = $this->doSaveTimetable(	$targetLibraryIds,
																$fromDate,
																array_pop($readTimeGrid),

																true,		   // singlemode
																$keepExistingTimetableMode);

						$formattedFromDate = Clavis::dateFormat($fromDate);
						
						switch ($returnValue)
						{
							case LibraryTimetablePeer::WRITE_OK:
								
								$someUpdated = true;
								
								$this->getPage()->enqueueMessage(Prado::localize("Modificato giorno con data {day} nella tabella degli orari, nelle biblioteche con id={libraries}",
																					array(	'day' => $formattedFromDate,
																							'libraries' => $targetLibraryIdsString )),
																	ClavisMessage::CONFIRM);

								ChangelogPeer::logAction(	$multiLibraryMode ? "Librarian" : "Library",
															ChangelogPeer::LOG_UPDATE,
															$this->getUser(),
															"Modificati orari nelle biblioteche con id=$targetLibraryIdsString , giorno singolo per la data {$formattedFromDate}",
															$multiLibraryMode ? $this->getUser()->getId() : $myLibraryId);
								
								if ($dueDateCheckFlag)
								{	
									$resultCheckDueDate = $this->checkLoanDueDate(	array_values($targetLibraryIds),	// libraryIds
																					$fromDate,
																					$fromDate);
								}

								$this->Timetable->populate();

								break;

							case LibraryTimetablePeer::WRITE_HOLIDAYSKIP:
								$this->getPage()->enqueueMessage(Prado::localize("Giorno {date} non modificato perchè è già un giorno festivo nella tabella orari nelle biblioteche con id={libraries}",
																					array(	'date' => $formattedFromDate, 
																							'libraries' => $targetLibraryIdsString )),
																	ClavisMessage::INFO);
								
								ChangelogPeer::logAction(	$multiLibraryMode ? "Librarian" : "Library",
															ChangelogPeer::LOG_UPDATE,
															$this->getUser(),
															"Giorno $formattedFromDate non modificato perchè è già un giorno festivo nella tabella orari delle biblioteche con id=$targetLibraryIdsString",
															$multiLibraryMode ? $this->getUser()->getId() : $myLibraryId);

								break;

							case LibraryTimetablePeer::WRITE_FAILED:
								$this->getPage()->enqueueMessage(Prado::localize("Giorno {date} non modificato a causa di errori nella tabella orari nelle biblioteche con id={libraries}",
																					array(	'date' => $formattedFromDate, 
																							'libraries' => $targetLibraryIdsString )),
																	ClavisMessage::INFO);
								
								ChangelogPeer::logAction(	$multiLibraryMode ? "Librarian" : "Library",
															ChangelogPeer::LOG_UPDATE,
															$this->getUser(),
															"Giorno $formattedFromDate non modificato a causa di errori nella tabella orari delle biblioteche con id=$targetLibraryIdsString",
															$multiLibraryMode ? $this->getUser()->getId() : $myLibraryId);

								break;

							case LibraryTimetablePeer::WRITE_NONE:
								$this->getPage()->enqueueMessage(Prado::localize("Giorno {date} non modificato nella tabella orari nelle biblioteche con id={libraries}",
																					array(	'date' => $formattedFromDate, 
																							'libraries' => $targetLibraryIdsString )),
																	ClavisMessage::INFO);
								
								ChangelogPeer::logAction(	$multiLibraryMode ? "Librarian" : "Library",
															ChangelogPeer::LOG_UPDATE,
															$this->getUser(),
															"Giorno $formattedFromDate non modificato nella tabella orari delle biblioteche con id=$targetLibraryIdsString",
															$multiLibraryMode ? $this->getUser()->getId() : $myLibraryId);
								
								break;
								
							default:	// unknown
								$this->getPage()->enqueueMessage(Prado::localize("Giorno {date} non modificato per errore sconosciuto nella tabella orari nelle biblioteche con id={libraries}",
																					array(	'date' => $formattedFromDate, 
																							'libraries' => $targetLibraryIdsString )),
																	ClavisMessage::INFO);
								
								ChangelogPeer::logAction(	$multiLibraryMode ? "Librarian" : "Library",
															ChangelogPeer::LOG_UPDATE,
															$this->getUser(),
															"Giorno $formattedFromDate non modificato per errore sconosciuto nella tabella orari delle biblioteche con id=$targetLibraryIdsString",
															$multiLibraryMode ? $this->getUser()->getId() : $myLibraryId);
								
						}	// end of switch for $returnValue
					}	// endof single day mode
					else     // we have an error
					{
						/// not week mode nor single day mode
						$this->getPage()->enqueueMessage(Prado::localize("Errore interno nella lettura della griglia nuovi orari"),
															ClavisMessage::ERROR);
					}
					
					/// testing
					if (!is_null($fromDate)
							&& !is_null($toDate))
					{
						$this->setFromDate($fromDate);
						$this->setToDate($toDate);
					}
//$fd = $this->getFromDate();					
				}	// end of starting date correctly present
				else
				{
					if ($this->getSingleDayMode())
					{
						$this->getPage()->enqueueMessage(Prado::localize("Data non specificata"),
															ClavisMessage::ERROR);
					}
					else
					{	
						$this->getPage()->enqueueMessage(Prado::localize("Data di partenza non specificata"),
															ClavisMessage::ERROR);
					}
				}
			}
			else
			{
				$this->getPage()->enqueueMessage(Prado::localize("Errore nel passaggio del parametro della biblioteca corrente. Si prega di riportare l'errore in maniera dettagliata al fornitore del software"),
													ClavisMessage::WARNING);
			}
		}

		// if some loan had their due_date moved, i want a message
		if ($someUpdated
				&& $dueDateCheckFlag)
		{
			if (is_array($resultCheckDueDate)
				&& (count($resultCheckDueDate) > 0))
			{
				$movedDueDatesArray = array();
				$itemIdNavigateUrl = ItemPeer::getNavigateUrl();
				$itemTitle = Prado::localize("visualizza questo esemplare");

				foreach ($resultCheckDueDate as $itemId => $dueDate)
				{
					$movedDueDatesArray[] = Prado::localize("Data prevista di ritorno per l'esemplare con id: {id} spostata al {dueDate}",
																array(	'id' => "<a href='" . $itemIdNavigateUrl . $itemId . "' target='_blank' title='" . $itemTitle . "'>" . $itemId . "</a>",
																		'dueDate' => $dueDate));
				}

				if (count($movedDueDatesArray) > 0)
					$this->getPage()->enqueueMessage(implode(" - ", $movedDueDatesArray),
														ClavisMessage::CONFIRM);
			}
			else
			{
				$this->getPage()->enqueueMessage(Prado::localize("Non è stato necessario spostare alcuna data di scadenza prestiti"),
														ClavisMessage::CONFIRM);
			}
		}
		
		if ($sender !== "onSave")
			$this->getPage()->flushMessage();
		
		return $procedingOk;	// we need to know is some changes have been attempted
	}
	
	private function OLDdoSaveTimetable(	$libraryIds,		// maybe int, maybe array (multilibrary)
										$date,
										$row = array(),
										$singleMode = false,
										$keepExisting = false)
	{
		if (count($row) == 0)
			return LibraryTimetablePeer::WRITE_NONE;

		if (is_null($keepExisting))
			$keepExisting = false;

		if (is_numeric($libraryIds))	// if it's a numeric id, we want an array of ids
			$libraryIds = array($libraryIds);
		
		/**
		 * Initialize the variables from valued passed by parameter (normalized)
		 */
		$t1Start = ($row['t1Start'] != "" ? $row['t1Start'] : null);
		$t1End = ($row['t1End'] != "" ? $row['t1End'] : null);
		$t2Start = ($row['t2Start'] != "" ? $row['t2Start'] : null);
		$t2End = ($row['t2End'] != "" ? $row['t2End'] : null);
		$t3Start = ($row['t3Start'] != "" ? $row['t3Start'] : null);
		$t3End = ($row['t3End'] != "" ? $row['t3End'] : null);
		$holiday = ($singleMode ? $row['holiday'] : false);
		$note = ($row['note'] != "" ? $row['note'] : null);
		$open = (!is_null($row['open']) ? $row['open'] : -1);	// -1 is the 'undefined' value for library openness

		try
		{
			/**
			 * We want to rollback if something goes wrong
			 */
			$connection = Propel::getConnection();
			$holidayNeutralFlag = false;
			
			$timeRows = LibraryTimetableQuery::create()
							->filterByLibraryId($libraryIds)
							->filterByTimetableDay($date)
							->find();

			if ($timeRows->count() < count($libraryIds))
			{
				$newTimeRows = array();
				$libraryIdsPresent = array();

				foreach ($timeRows as $timeRow)
				{
					if (in_array($timeRow->getLibraryId(), $libraryIds))
					{
						$newTimeRows[] = $timeRow;
						$libraryIdsPresent[] = $timeRow->getLibraryId();
					}
				}

				$libraryIdsMissing = array_diff($libraryIds, $libraryIdsPresent);
				
				foreach ($libraryIdsMissing as $libraryId)
				{
					$newTimeRow = new LibraryTimetable();
					$newTimeRow->setTimetableDay($date);
					$newTimeRow->setLibraryId($libraryId);
					$newTimeRow->setDateCreated(time());
					$newTimeRow->setCreatedBy($this->getUser()->getId());
					
					$newTimeRows[] = $newTimeRow;
					
					unset($newTimeRow);
				}
				
				$timeRows = $newTimeRows;
			}
			
			/**
			 * Main cycle on timetables elements to be managed
			 */
			foreach ($timeRows as $timeRow)
			{
				$oldHoliday = $timeRow->getTimetableHoliday();
				
				if ($keepExisting)
				{
					// setting as a new 'holiday', or keeping it from saved row
					//  means that we want everything closed, that day.
					// Same thing if we explicitly chose "closed"
					if ($holiday
							|| (($oldHoliday == 1) && !$singleMode)
							|| ($open == 0))
					{
						$timeRow->setTime1Start(null);
						$timeRow->setTime1End(null);
						$timeRow->setTime2Start(null);
						$timeRow->setTime2End(null);
						$timeRow->setTime3Start(null);
						$timeRow->setTime3End(null);

						if ($oldHoliday == 1)
						{
							$holidayNeutralFlag = true;
						}
						else
						{
							$timeRow->setTimetableHoliday($holiday ? 1 : 0);
						}
						
						$timeRow->setTimetableOpen(0);
						$timeRow->setTimetableNote($note);
					}
					else	// surely no holiday has been chosen,
							// or chosen to explicit "close"
					{
						// if we touched them, use them, otherwise use
						// the already saved values
						if (!is_null($t1Start))
							$timeRow->setTime1Start($t1Start);

						if (!is_null($t1End))
							$timeRow->setTime1End($t1End);

						if (!is_null($t2Start))
							$timeRow->setTime2Start($t2Start);

						if (!is_null($t2End))
							$timeRow->setTime2End($t2End);

						if (!is_null($t3Start))
							$timeRow->setTime3Start($t3Start);

						if (!is_null($t3End))
							$timeRow->setTime3End($t3End);

						if (!is_null($note))
							$timeRow->setTimetableNote($note);

						$timeRow->setTimetableOpen(1);
						$timeRow->setTimetableHoliday(0);
					}
				}	// end of keep existing
				else	// overwriting mode
				{
					if ((is_null($t1Start)
						&& is_null($t1End)
						&& is_null($t2Start)
						&& is_null($t2End)		
						&& is_null($t3Start)
						&& is_null($t3End))
							||$holiday
							|| ($oldHoliday == 1)
							|| ($open == 0))	// explicit desire to close
					{
						$timeRow->setTime1Start(null);
						$timeRow->setTime1End(null);
						$timeRow->setTime2Start(null);
						$timeRow->setTime2End(null);
						$timeRow->setTime3Start(null);
						$timeRow->setTime3End(null);
						
						if (($oldHoliday == 1)
								&& ($holiday == 1))
						{
							$holidayNeutralFlag = true;
						}
						else
						{
							$timeRow->setTimetableHoliday($holiday ? 1 : 0);
						}	
						
						$timeRow->setTimetableOpen(0);
						$timeRow->setTimetableNote($note);
					}
					else
					{
						// In any case, use new fetched values
						$timeRow->setTime1Start($t1Start);
						$timeRow->setTime1End($t1End);
						$timeRow->setTime2Start($t2Start);
						$timeRow->setTime2End($t2End);
						$timeRow->setTime3Start($t3Start);
						$timeRow->setTime3End($t3End);
						
						$timeRow->setTimetableOpen(1);
						$timeRow->setTimetableHoliday(0);
						$timeRow->setTimetableNote($note);
					}
				}	// end of overwriting mode
				
				$timeRow->save();
				$connection->commit();
			}	// endof foreach $timeRows, ciclo principale sugli orari

			return $holidayNeutralFlag
						? LibraryTimetablePeer::WRITE_HOLIDAYSKIP
						: LibraryTimetablePeer::WRITE_OK;
		}
		catch (Exception $e)
		{
			//Prado::fatalError($e);
			$connection->rollback();
			
			return LibraryTimetablePeer::WRITE_FAILED;
		}
	}

	private function doSaveTimetable(	$libraryIds,		// maybe int, maybe array (multilibrary)
										$date,
										$row = array(),
										$singleMode = false,
										$keepExisting = false)
	{
		if ((count($row) == 0)
				|| (!$row['rowModified']))
			return LibraryTimetablePeer::WRITE_NONE;	// nothing to do

		if (is_null($keepExisting))
			$keepExisting = false;

		if (is_numeric($libraryIds))	// if a $libraryIds is a single numeric id, we want an array of ids instead
			$libraryIds = array($libraryIds);
		
		/**
		 * Normalization of the variables that are passed as parameters
		 */
		$t1Start = ($row['t1Start'] != "" ? $row['t1Start'] : null);
		$t1End = ($row['t1End'] != "" ? $row['t1End'] : null);
		$t2Start = ($row['t2Start'] != "" ? $row['t2Start'] : null);
		$t2End = ($row['t2End'] != "" ? $row['t2End'] : null);
		$t3Start = ($row['t3Start'] != "" ? $row['t3Start'] : null);
		$t3End = ($row['t3End'] != "" ? $row['t3End'] : null);
		$holiday = ($singleMode ? $row['holiday'] : false);
		$note = ($row['note'] != "" ? $row['note'] : null);
		$open = (!is_null($row['open']) ? $row['open'] : -1);	// -1 is the 'undefined' value for library openness, "invariate"

		try
		{
			$connection = Propel::getConnection();
			$holidayNeutralFlag = false;
			
			$timeRows = LibraryTimetableQuery::create()
							->filterByLibraryId($libraryIds)
							->filterByTimetableDay($date)
							->find();

			if ($timeRows->count() < count($libraryIds))
			{
				$newTimeRows = array();
				$libraryIdsPresent = array();

				foreach ($timeRows as $timeRow)
				{
					if (in_array($timeRow->getLibraryId(), $libraryIds))
					{
						$newTimeRows[] = $timeRow;
						$libraryIdsPresent[] = $timeRow->getLibraryId();
					}
				}

				$libraryIdsMissing = array_diff($libraryIds, $libraryIdsPresent);
				
				foreach ($libraryIdsMissing as $libraryId)
				{
					$newTimeRow = new LibraryTimetable();
					$newTimeRow->setTimetableDay($date);
					$newTimeRow->setLibraryId($libraryId);
					$newTimeRow->setDateCreated(time());
					$newTimeRow->setCreatedBy($this->getUser()->getId());
					
					$newTimeRows[] = $newTimeRow;
					
					unset($newTimeRow);
				}
				
				$timeRows = $newTimeRows;
			}

			/**
			 * Main cycle on timetables elements to be managed
			 */
			foreach ($timeRows as $timeRow)
			{
				$oldHoliday = $timeRow->getTimetableHoliday();
				
				if ($keepExisting)
				{
					// setting as a new 'holiday', or keeping it from saved row
					//  means that we want everything closed, that day.
					// Same thing if we explicitly chose "closed"
					if ($holiday
							|| ($oldHoliday == 1)
							|| ($open == 0))
					{
						$timeRow->setTime1Start(null);
						$timeRow->setTime1End(null);
						$timeRow->setTime2Start(null);
						$timeRow->setTime2End(null);
						$timeRow->setTime3Start(null);
						$timeRow->setTime3End(null);

						if ($oldHoliday == 1)
						{
							$holidayNeutralFlag = true;
						}
						else
						{
							$timeRow->setTimetableHoliday($holiday ? 1 : 0);
						}
						
						$timeRow->setTimetableOpen(0);
						$timeRow->setTimetableNote($note);
					}
					elseif ($open == 1)	
							/* 
							Open day.
							Surely no holiday has been chosen,
							or chosen to explicit "close"
							*/
					{
						// if we touched them, use them, otherwise use
						// the already saved values
						if (!is_null($t1Start))
							$timeRow->setTime1Start($t1Start);

						if (!is_null($t1End))
							$timeRow->setTime1End($t1End);

						if (!is_null($t2Start))
							$timeRow->setTime2Start($t2Start);

						if (!is_null($t2End))
							$timeRow->setTime2End($t2End);

						if (!is_null($t3Start))
							$timeRow->setTime3Start($t3Start);

						if (!is_null($t3End))
							$timeRow->setTime3End($t3End);

						if (!is_null($note))
							$timeRow->setTimetableNote($note);

						$timeRow->setTimetableOpen(1);
						$timeRow->setTimetableHoliday(0);
					}
				}	// end of keep existing
				
				else	// overwriting mode
				{
					if ((is_null($t1Start)
						&& is_null($t1End)
						&& is_null($t2Start)
						&& is_null($t2End)		
						&& is_null($t3Start)
						&& is_null($t3End)))
					{
						if (($open == 0)
								|| $holiday
								|| ($oldHoliday == 1))
						{
							$timeRow->setTime1Start(null);
							$timeRow->setTime1End(null);
							$timeRow->setTime2Start(null);
							$timeRow->setTime2End(null);
							$timeRow->setTime3Start(null);
							$timeRow->setTime3End(null);

							if (($oldHoliday == 1)
									&& ($holiday == 1))
							{
								$holidayNeutralFlag = true;
							}
							else
							{
								$timeRow->setTimetableHoliday($holiday ? 1 : 0);
							}	

							$timeRow->setTimetableOpen(0);
							$timeRow->setTimetableNote($note);
						}
						elseif ($open < 1)	// closed or invariate
						{
							return LibraryTimetablePeer::WRITE_NONE;
						}
					}
					elseif ($open == 1)	// open day, everything regular
					{
						// In any case, use new fetched values
						$timeRow->setTime1Start($t1Start);
						$timeRow->setTime1End($t1End);
						$timeRow->setTime2Start($t2Start);
						$timeRow->setTime2End($t2End);
						$timeRow->setTime3Start($t3Start);
						$timeRow->setTime3End($t3End);
						
						$timeRow->setTimetableOpen(1);
						$timeRow->setTimetableHoliday(0);
						$timeRow->setTimetableNote($note);
					}
				}	// end of overwriting mode
				
				$timeRow->save();
				$connection->commit();
			}	// endof foreach $timeRows, ciclo principale sugli orari

			return $holidayNeutralFlag
						? LibraryTimetablePeer::WRITE_HOLIDAYSKIP
						: LibraryTimetablePeer::WRITE_OK;
		}
		catch (Exception $e)
		{
			//Prado::fatalError($e);
			$connection->rollback();
			
			return LibraryTimetablePeer::WRITE_FAILED;
		}
	}
	
	public function validateLibraryCode($sender, $param)
	{
		$validFlag = false;
		$libraryCode = trim($this->LibraryCode->getSafeText());
		
		if ($libraryCode != "")
			$validFlag = (LibraryQuery::create()
								->filterByLibraryCode($libraryCode)
								->prune($this->getLibrary())->count() == 0);
		
		$param->setIsValid($validFlag);
	}
	
	public function onResetShelf($sender, $param)
	{
		$this->doResetShelf($param);
	}

	private function doResetShelf($param = null)
	{
		$this->ShelfName->setText("");
		$this->ShelfId->setValue('');
		
		$this->renderShelfPanel($param);
	}
	
	public function renderShelfPanel($param = null)
	{
		if ($this->getIsCallback())
			$this->ShelfPanel->render(is_null($param) ? $this->createWriter() : $param->getNewWriter());
	}
	
	private function checkLoanDueDate(	$libraryIds,
										$rawFromDate,
										$rawToDate	)
	{
		$fromDate = Clavis::dateFormat($rawFromDate, "yyyy-MM-dd");
		$toDate = Clavis::dateFormat($rawToDate, "yyyy-MM-dd");
		
		$result = array();
		
		$items = ItemQuery::create()
					->filterByLoanStatus(ItemPeer::getLoanStatusCurrent())
					->where("(Item.DueDate >= '$fromDate') AND (Item.DueDate <= '$toDate')")
					->filterByActualLibraryId($libraryIds)
					->find();

		// involved items
		foreach ($items as $item)
		{
			if (LibraryTimetableQuery::create()
										->filterByLibraryId($item->getActualLibraryId())
										->filterByTimetableOpen(true)
										->filterByTimetableDay($item->getDueDate())
										->count() == 0)
			{
				$nextOpenDayTimeTable = LibraryTimetableQuery::create()
											->filterByLibraryId($item->getActualLibraryId())
											->filterByTimetableOpen(true)
											->filterByTimetableDay($item->getDueDate(), Criteria::GREATER_THAN)
											->orderByTimetableDay()
											->findOne();

				if ($nextOpenDayTimeTable instanceof LibraryTimetable)
						//&& ($nextOpenDayTimeTable->getTimetableDay("Y-m-d") != $rawFromDate))
				{
					$nextOpenDay = $nextOpenDayTimeTable->getTimetableDay("d-m-Y");
					$item->setDueDate($nextOpenDay);
					$item->save();

					$loan = LoanQuery::create()->findPk($item->getCurrentLoanId());
					
					if ($loan instanceof Loan)
					{
						$loan->setDueDate($nextOpenDay);
						$loan->save();

						ChangelogPeer::logAction(	$loan,
													ChangelogPeer::LOG_MODIFY,
													$this->getUser(),
													'Modificato prestito per cambio date apertura biblioteca, spostata data prevista di ritorno al ' . $nextOpenDay);

						ChangelogPeer::logAction(	$item,
													ChangelogPeer::LOG_MODIFY,
													$this->getUser(),
													'Modificato prestito per cambio date apertura biblioteca, spostata data prevista di ritorno al ' . $nextOpenDay);

						unset($loan);
					}

					$result[$item->getItemId()] = $nextOpenDay;
				}

				unset ($nextOpenDayTimeTable);
			}
		}
		
		return $result;
	}
	
}