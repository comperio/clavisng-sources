<?php
/**
 * LibraryViewPage class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Pages.Library
 */

/**
 * LibraryViewPage class
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.7
 * @package Pages.Library
 * @since 2.0
 */
class LibraryViewPage extends ClavisPage
{
	public $_module = 'LIBRARY';
	private $_libraryId;
	private $_library = null;

	/**
	 * On the onInit phase, the first time we enter the page,
	 *  we get the eventual librarianId, passed
	 * as a get parameter or create a new one, and next we use the
	 * internal function setLibrarian to put it in the viewstate.
	 *
	 * @param TEventParameter $param
	 */
	public function onInit($param)
	{
		parent::onInit($param);

		$ok = false;
		$this->setLibraryId(null);
		$this->setLibrary(null);
		
		if (!$this->getIsPostBack() 
				&& !$this->getIsCallback())
		{
			$originalId = $this->getRequest()->itemAt('id');
			$libraryId = intval($originalId);
			
			if ($libraryId > 0)
			{
				$library = LibraryPeer::retrieveByPK($libraryId);
			
				if ($library instanceof Library)
				{
					$this->setLibraryId($libraryId);
					$this->setLibrary($library);
					$ok = true;
				}
			}

			if (!$ok)
			{
				if ($originalId == "")
					$originalId = "(" . Prado::localize('vuoto') . ")";
				
				$this->writeMessage(Prado::localize('La biblioteca con id: {library_id} non esiste',
														array('library_id' => $originalId)),
										ClavisMessage::ERROR);
				
				$this->gotoPage('Library.LibraryList');
			}
			
			// distances calculation, or not
			if (ClavisParamPeer::getParam('LLIBRARY_ACTIVE') == 1)	// basin system is active
			{
				$this->DistanceTab->setVisible(true);
				$this->LLibraryView->setFromLibraryId($this->getLibraryId());
				$this->LLibraryView->populate();	// no automatic population of that widget
			}
			else
			{
				$this->DistanceTab->setVisible(false);
			}
			
			$selectTabID = trim($this->getRequest()->itemAt('selectTabID'));
			
			if ($selectTabID != "")
				try
				{
					$this->TabPanel->setActiveViewID($selectTabID);
				}
				catch (Exception $e)
				{
					//Prado::log($e);
				}
		}
	}

	public function onLoad($param)
	{
		parent::onLoad($param);

		$library = $this->getLibrary();
		if ($library instanceof Library)
		{
			$myId = $this->getUser()->getId();
			$libraryId = $this->getLibraryId();
			
			$this->LibraryView->populate($libraryId);

			$this->LibrarianGrid->setLibrary($library);
			$this->UpdateData->setObject($library);

			$this->NotificationList->setSenderLibraryId($libraryId);
			$this->NotificationList->populate();


            $l = LibraryQuery::create()->findPk($libraryId);

            if ($l instanceof Library)
                $this->SMSAccount->setText('<strong>' . Prado::localize('SMS rimanenti: {count}',
                        array('count' => $l->getActualSMS()))
                    . '</strong>');


			$canEdit = $this->getUser()->getEditPermission($library);

			$this->Edit->setEnabled($canEdit);
			$this->NewLibrarian->setVisible($canEdit);

			$this->AttachmentManager->setObjectClass('Library');
			$this->AttachmentManager->setObjectId($libraryId);
			
			$this->ActiveResourceSessionList->setHideClosed(TRUE);
			$this->OldResourceSessionList->setHideActive(TRUE);
			$this->ActiveResourceSessionList->setFilterByLibrary($library->getLibraryId());
			$this->OldResourceSessionList->setFilterByLibrary($library->getLibraryId());

			/*
			$NMurl = ClavisParamQuery::getParam('CLAVISPARAM','NetManager');
			if (!$NMurl) {
				$this->NetManagerTab->setVisible(false);
			} else {
				$this->NetManagerTab->setVisible(true);
				$srcUrl = $NMurl.'/index.php?r=nm_navigation_session/clavisLibSummary'.
					'&library_code='.$library->getLibraryCode().
					'&library_id='.$libraryId.
					'&consortia_id='.$library->getConsortiaId().
					'&librarian_id='.$myId;
				$fget = @file_get_contents($srcUrl,false,$context);
				$this->NetManagerNavigation->setText(
					($fget === false) ?
						Prado::localize('<em>Server NetManager temporaneamente non disponibile.</em>') :
						$fget);
				$srcUrl = $NMurl.'/index.php?r=nm_userful_session/clavisLibSummary'.
					'&library_code='.$library->getLibraryCode().
					'&library_id='.$libraryId.
					'&consortia_id='.$library->getConsortiaId().
					'&librarian_id='.$myId;
				$fget = @file_get_contents($srcUrl,false,$context);
				$this->NetManagerUserful->setText(
					($fget === false) ?
						Prado::localize('<em>Server NetManager temporaneamente non disponibile.</em>') :
						$fget);
			}
			*/
			 
			$this->ItemActionList->setLibraryId($libraryId);
            $this->WalletList->setObjectId($libraryId);

			$this->HistoryTab->setVisible(true);
		}
		else
		{
			$this->setLibraryId(null);
			
			$this->Edit->setEnabled(false);
			$this->NewLibrarian->setVisible(false);
			$this->HistoryTab->setVisible(false);
		}
	}

	public function onLibraryEdit($sender, $param)
	{
		$this->gotoPage("Library.LibraryInsertPage", array("id" => $this->getLibraryId()));
	}

	public function setLibraryId($value)
	{
		$this->_libraryId = $value;
		$this->setViewState("LibraryId", $value, null);
	}

	public function getLibraryId()
	{
		$this->_libraryId = $this->getViewState("LibraryId", null);
		
		return $this->_libraryId;
	}

	/**
	 * It is called by one of the inner components, and
	 * performs the population (refresh) of all the components
	 * (the calling is included).
	 *
	 */
	public function globalRefresh()
	{
		//$this->ProfilesGrid->populate();
		$this->LibrarianGrid->populate();
		$this->NotificationList->populate();
		$this->ActiveResourceSessionList->populate();
		$this->OldResourceSessionList->populate();
	}

	/**
	 * Refresh "old sessions" grid after session action
	 *
	 */
	public function sessionsRefresh($writer)
	{
		//$this->ActiveResourceSessionList->populate();
		//$this->ActiveResourceSessionList->GridActivePanel->render($writer);
		$this->OldResourceSessionList->populate();
		$this->OldResourceSessionList->GridActivePanel->render($writer);
	}
	
	/**
	 * It's called by one of the inner componentes, and
	 * performs the "cancel" (return to non-edit status)
	 * of all the components (the calling is included).
	 *
	 * @param TControl $component
	 */
	public function globalCancel($component)
	{
		if ($component !== $this->LibrarianGrid)
			$this->LibrarianGrid->onCancel(null, null);

	}

	/**
	 * Callback of the button which adds a new profile.
	 * It calls the proper event in the external component.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onAddProfile($sender, $param)
	{
		$this->LibrarianGrid->onAddLibrarian();
	}

	public function isUnlink()
	{
		return false;  // true
	}

	public function setLibrary($library)
	{
		$this->_library = $library;
		$this->setViewState('Library', $library, null);
	}

	public function getLibrary()
	{
		$this->_library = $this->getViewState('Library', null);
		
		return $this->_library;
	}

	public function AddLibrarian($librarianId)
	{
		$library = $this->getLibrary();
		
		if (!($library instanceof Library))
		{
			$this->getPage()->writeMessage(Prado::localize("Errore: la biblioteca non esiste"), 
											ClavisMessage::ERROR);
			
			return false;
		}

		$librarian = null;
		$librarianId = intval($librarianId);
		
		if ($librarianId > 0)
			$librarian = LibrarianQuery::create()->findPk($librarianId);
		
		if (!($librarian instanceof Librarian))
		{
			$this->getPage()->writeMessage(Prado::localize("Errore: l'operatore passato come parametro non esiste"), 
												ClavisMessage::ERROR);
			
			return false;
		}

		try
		{
			$librarian_lnk = new LLibraryLibrarian();
			$librarian_lnk->setLibraryId($library->getLibraryId());
			$librarian_lnk->setLibrarianId($librarianId);
			$librarian_lnk->setLinkRole($this->LinkRole->getSelectedValue());

			$librarian_lnk->save();

			$library->addLLibraryLibrarian($librarian_lnk);
			$this->setLibrary($library);

		} catch (PropelException $e)
		{
			Prado::Log(Prado::varDump($e->getCause()));
		}
	}

	public function onHiddenValueChanged($param)
	{
		$this->LinkRolePanel->setVisible(true);
		$this->ResultLabel->setVisible(true);
		$this->LibrarianLabel->setText($this->ResultLabel->getValue());
		$this->AddLibrarian->setVisible(false);

		$this->setFocus($this->LibrarianLabel->getClientId());
	}

	public function OnInsertLibrarianLink($sender, $param)
	{
		$library = $this->getLibrary();
		
		if ($library instanceof Library)
		{
			$librarianId = intval($this->ResultValue->getValue());
			if ($librarianId == 0)
			{
				$this->getPage()->writeMessage(Prado::localize("Errore sull'operatore"),
													ClavisMessage::ERROR);
				
				return false;
			}

			$role = TPropertyValue::ensureString($this->LinkRole->getSelectedValue());
			
			if (trim($role) == '')
				$role = 'B';

			if ($library->addLibrarian($librarianId, $role))
			{
				$librarian = LibrarianQuery::create()->findPk($librarianId);
				
				if (is_null($librarian))
				{
					$this->getPage()->writeMessage(Prado::localize("Errore nell'inserimento dell'operatore"),
														ClavisMessage::ERROR);
					
					return false;
				}

				$librarianName = $librarian->getCompleteName();
				
				$this->getPage()->writeDelayedMessage(Prado::localize("Operatore '{name}' legato alla biblioteca",
																		array('name' => $librarianName)),
														ClavisMessage::CONFIRM);

				ChangelogPeer::logAction(	$this->_library, 
											ChangelogPeer::LOG_UPDATE, 
											$this->getUser(),
											"Legato operatore '{$librarianName}' (id: {$librarianId}) alla biblioteca" );

				$this->reloadPage();
			}
			else
			{	
				$this->getPage()->writeMessage(Prado::localize("Errore nell'inserimento dell'operatore"),
													ClavisMessage::ERROR);
			}
		}
		else
		{
			$this->getPage()->writeMessage(Prado::localize("Biblioteca mancante"),
												ClavisMessage::ERROR);
		}
	}

	public function Unlink($librarianId)
	{
		$this->UnlinkLibrarian($librarianId);
		$this->globalRefresh();
	}

	public function UnlinkLibrarian($librarianId)
	{
		try
		{
			if (!is_null($librarianId) 
					&& is_numeric($librarianId))
				{
					$libraryId = $this->getLibrary()->getLibraryId();

					$criteria = new Criteria();
					$criterion = $criteria->getNewCriterion(LLibraryLibrarianPeer::LIBRARIAN_ID, $librarianId);
					$criterion2 = $criteria->getNewCriterion(LLibraryLibrarianPeer::LIBRARY_ID, $libraryId);
					$criterion->addAnd($criterion2);
					$criteria->add($criterion);
					LLibraryLibrarianPeer::doDelete($criteria);

					$library = $this->getLibrary();
					$library->reload(true);  // deep reload
					$this->setLibrary($library);
			}

		}
		catch (PropelException $e)
		{
			//Prado::Log(Prado::varDump($e->getCause()));
		}
	}

	
	public function printNMStats($sender, $param)
	{
		//$this->WalletPrint->addOptionalParam("P_WALLETIDS", ($idList=="")?"0":$idList );
		$this->NMPrint->printReport();
	}
	
}