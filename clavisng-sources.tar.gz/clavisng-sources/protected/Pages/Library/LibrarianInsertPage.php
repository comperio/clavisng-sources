<?php
/**
 * LibrarianInsertPage class file.
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 * For Commercial Licenses and support please contact Comperio.
 * @author    Ciro Mattia Gonano
 * @author    Marco Brancalion <marco@comperio.it>
 * @link      http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license   http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version   2.7
 * @package   Pages.Library
 */

/**
 * LibrarianInsertPage Class
 * @author  Marco Brancalion <marco@comperio.it>
 * @author  Ciro Mattia Gonano
 * @version 2.8.6
 * @package Pages.Library
 * @since   2.0
 */
class LibrarianInsertPage extends ClavisPage
{
	public $_module = 'LIBRARY';
	/* @var Librarian */
	private $_librarian = null;

	public function onInit($param)
	{
		parent::onInit($param);

		if (!$this->getIsPostBack())
		{
			$librarian = null;
			$id = (int)$this->getRequest()->itemAt('librarianId');

			if ($id > 0)
			{
				$librarian = LibrarianQuery::create()->findPk($id);

				if (is_null($librarian) 
						|| !($librarian instanceof Librarian))
				{
					$this->writeMessage(Prado::localize("Il bibliotecario con id = {id} non esiste",
															array('id' => $id)),
											ClavisMessage::ERROR);

					$this->gotoPage('Library.LibrarianListPage');
				}
			}

			$this->UpdateData->setObject($librarian);

			if (!($librarian instanceof Librarian))
				$librarian = new Librarian();

			$this->setLibrarian($librarian);

			if ($librarian->isNew())
			{
				$this->DefaultLibrary->setDataSource(LibraryPeer::getLibrariesHash(null, null, null, true));  // internal only
				$this->DefaultLibrary->dataBind();
				$this->DefaultLibrary->setSelectedValue($this->getUser()->getActualLibraryId());
			}
			else
			{
				$this->AttachmentManager->setObjectClass('Librarian');
				$this->AttachmentManager->setObjectId($librarian->getLibrarianId());
				$this->DefaultLibrary->setDataSource($librarian->getUserLibraries(array($this->librarian->getDefaultLibraryId())));
				$this->DefaultLibrary->dataBind();
			}

			$this->LibrarianPopupNotificationOptions->init($librarian);
		}
	}

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getIsPostBack())
		{
			// on first page cycle
			$this->populate();
			$this->dataBind();
		}
		else
		{
			// on next page cycles
			// managing of photo selection popup
			if ($this->ChangePhotoPopupValue->getValue() == "OK")
			{
				$this->writeDelayedMessage(Prado::localize('Foto operatore cambiata correttamente'),
											ClavisMessage::INFO);

				$this->reloadPage();
			}
			elseif ($this->ChangePhotoPopupValue->getValue() == "CANCEL")
			{
				$this->reloadPage();
			}
		}

		$this->getLibrarian();
		
		if ($this->_librarian->getLibrarianId() === null)
			$this->Photo->setEnabled(false);

		$photoId = $this->_librarian->getPhotoFileId();

		if ($photoId)
			$this->Photo->setImageURL($this->getRequest()->constructUrl('file', $photoId));
	}

	public function onSave($sender, $param)
	{
		if ($this->getIsValid())
		{
			$this->cleanMessageQueue();

			$isNew = $this->_librarian->isNew();
			$ret = $this->doLibrarianSave();

			if ($ret
					&& ($param->getCommandParameter() == "close"))
			{
				$this->flushDelayedMessage();
			
				$this->gotoPage(	'Library.LibrarianViewPage',
									array('id' => $this->_librarian->getLibrarianId()));
			}
			else
			{
				$this->flushMessage();
			}
		}
	}

	/**
	 * Save librarian data on DB
	 * @return boolean
	 * @throws \PropelException
	 */
	private function doLibrarianSave()
	{
		try
		{
			if (!$this->_librarian instanceof Librarian)
				$this->_librarian = new Librarian();

			$wasNew = $this->_librarian->isNew();
			$resettedPrivacyFlag = false;

			$username = trim($this->Username->getSafeText());
			$password = trim($this->Password->getSafeText());

			if ($username)
				$this->_librarian->setUsername($username);

			if ($password)
			{
				$cryptmod = $this->getApplication()->getModule('crypt');
				$this->_librarian->setSecret($cryptmod->LibrarianEncrypt($password));
			}

			$this->_librarian->setName($this->Name->getSafeText());
			$this->_librarian->setLastname($this->Lastname->getSafeText());
			$this->_librarian->setBirthdate($this->BirthDate->getTimeStamp());
			$this->_librarian->setPhone($this->Phone->getSafeText());
			$this->_librarian->setEmail($this->Email->getSafeText());
			$this->_librarian->setLibrarianNote($this->LibrarianNote->getText());
			$this->_librarian->setCatLevel($this->CatLevel->getSelectedValue());
			$this->_librarian->setActivationStatus($this->ActivationStatus->getChecked());
			//$this->_librarian->setPatron(PatronQuery::create()->findPk($this->PatronId->getValue()));
			$defaultLibraryId = $this->DefaultLibrary->getSelectedValue();

			if ($defaultLibraryId != '0')
				$this->_librarian->setDefaultLibraryId($defaultLibraryId);

			/* admins part, with expirations, etc */
			if ($this->getUser()->getIsAdmin()
					|| $this->getUser()->getIsDirector())
			{
				$secretExpire = $this->SecretExpireEdit->getTimeStamp();

				if ($secretExpire == "")
					$secretExpire = null;

				$this->_librarian->setSecretExpire($secretExpire);

				$librarianExpire = $this->LibrarianExpireEdit->getTimeStamp();

				if ($librarianExpire == "")
					$librarianExpire = null;

				$this->_librarian->setLibrarianExpire($librarianExpire);

				// resetting of privacy acception, for this single librarian
				if (LibrarianPeer::isPrivacyActive()
						&& $this->PrivacyAcceptReset->getChecked())
				{
					$this->_librarian->setPrivacyAccepted(null);
					$resettedPrivacyFlag = true;
				}
			}

			/* end of admins part */

			$linkedPatronId = intval($this->PatronId->getValue());

			if ($linkedPatronId == 0)
				$linkedPatronId = null;

			$this->_librarian->setPatronId($linkedPatronId);
			$this->_librarian->save();

			if ($linkedPatronId > 0)
			{
				/**
				 * We have to check if the linked patron has already been linked to
				 * another existing librarian
				 */
				$linkedOtherLibrariansToPatron = LibrarianQuery::create()
													->select('LibrarianId')
													->prune($this->_librarian)
													->findByPatronId($linkedPatronId)
													->toArray();

				if (count($linkedOtherLibrariansToPatron) > 0)
				{
					$this->enqueueMessage(Prado::localize("Attenzione: esistono altri bibliotecari nel sistema legati al medesimo utente, id = {ids}",
																array('ids' => implode(',', $linkedOtherLibrariansToPatron))),
											ClavisMessage::WARNING);
				}
				
				
				$patron = PatronQuery::create()->findOneByPatronId($linkedPatronId);
				if($patron instanceof Patron)
				{
					$patron->setOpacUsername($username);
					if($password)
					{
						$cryptmod = $this->getApplication()->getModule('crypt');
						$patron->setOpacSecret($cryptmod->PatronEncrypt($password));
					}		
					$patron->save();
				}
				else
				{
					throw new Exception("Linked patron not found");
				}
			}
			else
			{
				//Search patron with this username...
				$patron = PatronQuery::create()->findOneByOpacUsername($username);
				if($patron instanceof Patron)
				{
					//and rename user to avoid check issues
					$fdate = date("YmdHis");
					$patron->setOpacUsername($username . "_unlinked{$fdate}");
					$patron->save();
				}
			}

			$profiles = LLibrarianProfileQuery::create()
							->filterByLibrarian($this->_librarian)
							->count();

			if ($profiles < 1)
			{
				$profileId = max(	ClavisParamQuery::getParam('CLAVISPARAM', 'DefaultLibrarianProfile'),
									$this->getUser()->getMinProfileId());

				$profile = new LLibrarianProfile();

				$profile->setLibrarian($this->_librarian)
							->setProfileId($profileId)
							->setSortOrder(1)
							->save();
			}

			if ($defaultLibraryId != '0')
			{
				$link = LLibraryLibrarianQuery::create()
							->filterByLibrarian($this->_librarian)
							->filterByLibraryId($defaultLibraryId)
							->findOneOrCreate();

				if ($link->isNew())
				{
					$role = ClavisParamQuery::getParam('CLAVISPARAM', 'DefaultLibrarianRole');

					if (!$role)
						$role = 'A';

					$link->setLibrarian($this->_librarian)
								->setLibraryId($defaultLibraryId)
								->setLinkRole($role)
								->setOpacVisible(true)
								->save();
				}
			}

			$this->setLibrarian($this->_librarian);
			$librarianId = $this->_librarian->getLibrarianId();
			$librarianName = $this->_librarian->getCompleteName();

			$this->LibrarianPopupNotificationOptions->saveLibrarianNotificationPreferences($this->_librarian);

			ChangelogPeer::logAction(	$this->_librarian,
										$wasNew ? ChangelogPeer::LOG_CREATE : ChangelogPeer::LOG_UPDATE,
										$this->getUser(),
										$wasNew ? "Creato" : "Modificato" . " operatore, id = {$librarianId}, nome = '{$librarianName}'",
										$librarianId);

			$this->enqueueMessage(sprintf("%s %s",
									Prado::localize($wasNew ? "Creato" : "Modificato"),
									Prado::localize("operatore, id = {librarianId}, nome = '{librarianName}'",
														array('librarianId' => $librarianId, 'librarianName' => $librarianName))),
									ClavisMessage::CONFIRM);

			if ($resettedPrivacyFlag)
			{
				ChangelogPeer::logAction(	$this->_librarian,
											ChangelogPeer::LOG_UPDATE,
											$this->getUser(),
											"É stata resettata l'accettazione della privacy per operatore con id = {$librarianId}, nome = '{$librarianName}'",
											$librarianId);

				$this->enqueueMessage(Prado::localize("É stata resettata l'accettazione della privacy per l'operatore con id = {librarianId}, nome = '{librarianName}'",
																	array(	'librarianId' => $librarianId,
																			'librarianName' => $librarianName )),
										ClavisMessage::WARNING);
			}

			return true;	// success
		}
		catch (PropelException $exception)
		{
			$errorMessage = $exception->getCause()->getMessage();
			$dbClass = Propel::getDB();

			if ($dbClass instanceof DBMySQL)
			{
				$duplicateCase = strstr($errorMessage, 'Duplicate entry');

				if ($duplicateCase !== false)
				{
					$usernameArray = sscanf($duplicateCase, "Duplicate entry %s");
					$username = $usernameArray[0];

					$this->enqueueMessage(Prado::localize("Lo username {username} è già in uso",
						array('username' => (is_null($username) ? '' : $username . ' '))),
						ClavisMessage::ERROR);

					$this->Username->setText('');
					$this->_librarian->setUsername(null);
				}
				else
				{
					//throw ($exception);
					$this->enqueueMessage(Prado::localize("Errore durante il salvataggio del bibliotecario"),
											ClavisMessage::ERROR);
				}
			}
			else
			{
				//throw ($exception);
				$this->enqueueMessage(Prado::localize("Errore durante il salvataggio del bibliotecario"),
										ClavisMessage::ERROR);
			}
		}
	}

	public function onCancel($sender, $param)
	{
		$this->writeMessage(Prado::localize('Annullata operazione di modifica operatore'),
								ClavisMessage::INFO);

		$this->gotoPage(	"Library.LibrarianViewPage",
							array("id" => $this->_librarian->getLibrarianId()));
	}

	/**
	 * We populate the fields in the page with data of object
	 * librarian which are stored in the database.
	 */
	public function populate()
	{
		if ($this->_librarian === null)
			return;

		if (!$this->_librarian->isNew())
			$this->Photo->setPopupPage('Library.LibrarianChooseImagePopup&librarianId=' . $this->_librarian->getLibrarianId());

		$p = $this->_librarian->getPatron();

		if ($p instanceof Patron)
		{
			$this->PatronId->setValue($p->getPatronId());
			$this->PatronLabel->setText($p->getCompleteName());
		}

		$this->UpdateData->setObject($this->_librarian);
		$username = $this->_librarian->getUsername();

		if ($username != '')
			$this->Username->setText($username);

		$password = $this->_librarian->getSecret();

		if ($password != '')
			$this->Password->setText($password);

		$name = $this->_librarian->getName();

		if ($name != '')
			$this->Name->setText($name);

		$lastname = $this->_librarian->getLastname();

		if ($lastname != '')
			$this->Lastname->setText($lastname);

		$this->BirthDate->setTimeStamp($birthdate = $this->_librarian->getBirthdate('U'));
		$this->Phone->setText($this->_librarian->getPhone());

		$email = $this->_librarian->getEmail();

		if ($email != '')
			$this->Email->setText($email);

		$defaultLibraryId = intval($this->_librarian->getDefaultLibraryId());

		try
		{
			if ($defaultLibraryId > 0)
				$this->DefaultLibrary->setSelectedValue($defaultLibraryId);
		}
		catch (Exception $exception)
		{
			$errorMessage = $exception->getMessage();
			$errorCase = strstr($errorMessage, 'TDropDownList.SelectedValue has an invalid value');
			
			if ($errorCase != false)
			{
				$library = LibraryQuery::create()->findPk($defaultLibraryId);
			
				if ($library instanceof Library)
				{
					$dataSource = $this->DefaultLibrary->getDataSource();
					$dataSource->add(	$defaultLibraryId,
										$library->getLabel());

					$data = $dataSource->toArray();
					$this->DefaultLibrary->setDataSource($dataSource);
					$this->DefaultLibrary->dataBind();
					$this->DefaultLibrary->setSelectedValue($defaultLibraryId);
				}
			}
			else
			{
				throw ($exception);
			}
		}

		$this->LibrarianNote->setText($this->_librarian->getLibrarianNote());
		$catLevel = $this->_librarian->getCatLevel();

		if ($catLevel === '')
			$catLevel = '0';

		$this->CatLevel->setSelectedValue($catLevel);
		$this->ActivationStatus->setChecked($this->_librarian->getActivationStatus());

		// secret_expire part
		if ($this->getUser()->getIsAdmin()
				|| $this->getUser()->getIsDirector())
		{
			$this->SecretExpirePanel->setVisible(true);
			$this->SecretExpireEdit->setVisible(true);
			$this->SecretExpireLabel->setVisible(false);

			$secretExpire = $this->_librarian->getSecretExpire('U');

			if (is_null($secretExpire))
			{
				$this->SecretExpireEdit->setText("---");
			}
			else
			{
				$this->SecretExpireEdit->setTimeStamp($secretExpire);
			}
		}
		elseif (!is_null($this->_librarian->getSecretExpire()))
		{
			$this->SecretExpirePanel->setVisible(true);
			$this->SecretExpireEdit->setVisible(false);
			$this->SecretExpireLabel->setVisible(true);

			$this->SecretExpire->setValue($this->_librarian->getSecretExpire('U'));
		}
		else
		{
			$this->SecretExpirePanel->setVisible(false);
		}

		// librarian_expire part
		if ($this->getUser()->getIsAdmin()
				|| $this->getUser()->getIsDirector())
		{
			$this->LibrarianExpirePanel->setVisible(true);
			$this->LibrarianExpireEdit->setVisible(true);
			$this->LibrarianExpireLabel->setVisible(false);

			$librarianExpire = $this->_librarian->getLibrarianExpire('U');

			if (is_null($librarianExpire))
			{
				$this->LibrarianExpireEdit->setText("---");
			} 
			else
			{
				$this->LibrarianExpireEdit->setTimeStamp($librarianExpire);
			}
		}
		elseif (!is_null($this->_librarian->getLibrarianExpire()))
		{
			$this->LibrarianExpirePanel->setVisible(true);
			$this->LibrarianExpireEdit->setVisible(false);
			$this->LibrarianExpireLabel->setVisible(true);

			$this->LibrarianExpire->setValue($this->_librarian->getLibrarianExpire('U'));
		} 
		else
		{
			$this->LibrarianExpirePanel->setVisible(false);
		}

		// privacy accept part
		if (LibrarianPeer::isPrivacyActive()
				&& $this->getUser()->getIsAdmin())
		{
			$this->PrivacyAcceptPanel->setVisible(true);
			$privacyAcceptDate = $this->_librarian->getPrivacyAccepted('U');

			if (is_null($privacyAcceptDate))
			{
				$this->PrivacyAcceptLabel->setText("non accettata");
				$this->PrivacyAcceptReset->setVisible(false);
			}
			else
			{
				$this->PrivacyAcceptLabel->setText(Clavis::dateFormat($privacyAcceptDate));
				$this->PrivacyAcceptReset->setVisible(true);
			}
		}
		else
		{
			$this->PrivacyAcceptPanel->setVisible(false);
		}
	}

	public function setLibrarian($librarian)
	{
		$this->_librarian = $librarian;
		$this->setViewState("librarian", $librarian, null);
	}

	public function getLibrarian()
	{
		if (is_null($this->_librarian))
			$this->_librarian = $this->getViewState("librarian", null);

		return $this->_librarian;
	}

	public function checkAuth($addedCheck = true, $force = null)
	{
		$this->getLibrarian();
		$auth = ($this->_librarian instanceof Librarian)
					? $this->getUser()->getEditPermission($this->_librarian)
					: null;

		parent::checkAuth(true, $auth);
	}

	public function checkUsername($sender, $param)
	{
		$username = $this->Username->getSafeText();

		if (($username == '')
				|| !$this->_librarian->allowedUsername($username))
			$param->isValid = false;
	}

	public function onCheckNewPassword($sender, $param)
	{
		if ($this->_librarian->isNew()
				&& (trim($this->Password->getSafeText()) == ''))
			$param->isValid = false;
	}

	public function suggestPatron($sender, $param)
	{
		$token = trim($param->getToken());
		
		if (!$token)
			return;

		$sender->setDataSource(PatronPeer::doSuggest($token, 10, true, true));
		$sender->dataBind();
	}

	public function suggestPatronCallBack($sender, $param)
	{
		$fieldText = trim($this->PatronLabel->getSafeText());

		if ($fieldText == "")
			return;

		$match = array();

		if (preg_match("/\(([^\)]+)\)\$/", $fieldText, $match))
		{
			$patronBarcode = $match[1];
		}
		else
		{
			$patronBarcode = $fieldText;
		}

		/** @var $patrons PropelObjectCollection */
		$patrons = PatronPeer::getPatronsByBarcode($patronBarcode);

		if ($patrons->isEmpty())
		{
			$this->PatronLabel->setText('');
		
			return;
		}

		$patron = $patrons->shift();
		if (!$patrons->isEmpty())
		{
			// TODO: notifica di barcodes utente duplicati
			// Per adesso lo fa la ClavisUserDataCard
		}

		if ($patron instanceof Patron)
		{
			$this->compilePatron($patron->getPatronId());
		}
	}

	public function selectPatronCallBack($sender, $param)
	{
		$this->compilePatron($this->PatronId->getValue());
	}

	private function compilePatron($id)
	{
		$p = PatronQuery::create()->findPk($id);

		if ($p instanceof Patron)
		{
			$this->PatronLabel->setText($p->getCompleteName());
			$this->PatronId->setValue($p->getPatronId());
		}
		else
		{
			$this->PatronLabel->setText('');
			$this->PatronId->setValue(null);
		}
	}

	public function onPatronUnlink($sender, $param)
	{
		$this->compilePatron(null);
	}

}