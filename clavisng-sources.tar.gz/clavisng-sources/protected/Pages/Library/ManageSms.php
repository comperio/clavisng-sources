<?php
/**
 * ManageSms class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2017 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: https://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Fabio Argenti <fabio.argenti@comperio.it>
 * @author Marco Brancalion <marco@comperio.it>
 * @link https://www.comperio.it/
 * @copyright Copyright &copy; 2006-2017 ePortal Technologies
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.8.7
 * @package Pages.Catalog
 */

/**
 * ManageSms Class
 *
 * @author Fabio Argenti <fabio.argenti@comperio.it>
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.8.7
 * @package Pages.Catalog
 * @since 2.8.6
 */

class ManageSms extends ClavisPage
{
	public $_module = "LIBRARY";
	public $_isSuperadmin;

	protected function initVars() 
	{	
		$this->_isSuperadmin = $this->getUser()->getIsSuperAdmin();
	}

	public function onInit($param)
	{
		parent::onInit($param);
		$this->initVars();
	}
	
	public function onLoad($param)
	{
		parent::onLoad($param);

        if (!$this->getPage()->getIsPostBack() 
				&& !$this->getPage()->getIsCallback()) 
		{
			$this->globalRefresh();
		}
	}

	public function onPreRender($param)
	{
		parent::onPreRender($param);

        if (!$this->getPage()->getIsPostBack() 
				&& !$this->getPage()->getIsCallback()) 
		{
			$this->setChangelogListProperties();
			$this->ChangelogList->populate();
		}		
	}
	
	public function globalRefresh()
	{
		$this->populateValue();
		$this->populateDropdown();
		
		$this->SmsToAssign->setText("");
		$this->NoteSmsAssign->setText("");
		
		$this->SmsToTransfer->setText("");
		$this->NoteSmsTransfer->setText("");

		$this->setChangelogListProperties();
		$this->ChangelogList->populate();
	}

	private function setChangelogListProperties()
	{
		$this->ChangelogList->setViewFilters(true);
		$this->ChangelogList->setEventType(ChangelogPeer::LOG_SMSASSIGN);
		$this->ChangelogList->setObjectClass("Library");
	}
	
	private function populateValue()
	{
		$globalSms = $this->getSysAv();
		
		$this->GlobalAllocabledSms->setText($globalSms);
		$this->GlobalAllocabledSms2->setText($globalSms);
		
		$allocated = $this->calculateAllocatedSms();
		$this->SystemAllocatedSms->setText($allocated);
	}
	
	private function populateDropdown()
	{
		$tempLibraryDestAssig = LibraryPeer::getLibrariesHashWithBlank(	TRUE, 
																		TRUE);

		foreach ($tempLibraryDestAssig as $key => $value)
		{
			if ($key != 0)
				$tempLibraryDestAssig[$key] .= " (" . $this->getLibraryAvSms($key) . ")";
		}
		
		$this->LibraryDestAssig->setDataSource($tempLibraryDestAssig);
		$this->LibraryDestAssig->dataBind();
		$this->LibraryDestAssig->setSelectedIndex(-1);
		
		$this->LibrarySrcTrasf->setDataSource($tempLibraryDestAssig);
		$this->LibrarySrcTrasf->dataBind();
		$this->LibrarySrcTrasf->setSelectedIndex(-1);
		
		$this->LibraryDestTrasf->setDataSource($tempLibraryDestAssig);
		$this->LibraryDestTrasf->dataBind();
		$this->LibraryDestTrasf->setSelectedIndex(-1);
	}
	
	private function getLibraryAvSms($libraryId)
	{
		return ClavisParamPeer::getParam(	'SMSACCOUNT', 
											'ACTUAL', 
											$libraryId, 
											null, 
											false); 
	}
			
	private function setLibraryAvSms(	$libraryId, 
										$value)
	{
		try
		{
			ClavisParamQuery::create()
								->filterByParamClass('SMSACCOUNT')
								->filterByParamName('ACTUAL')
								->filterByLibraryId($libraryId)
								->update(array('ParamValue' => ($value)));
			
			return true;
		}
		catch (PropelException $e)
		{
			return false;
		}
	}
	
	public function onAssignSms($sender, $param)
	{
		$value = intval($this->SmsToAssign->getSafeText());
		
		if ($value > 0)
		{
			$toLibraryId = $this->LibraryDestAssig->getSelectedValue();
			$toLibraryLabel = "";
			$toLibrary = null;
			
			if ($toLibraryId > 0)
				$toLibrary = LibraryQuery::create()->findPk($toLibraryId);

			if ($toLibrary instanceof Library)
			{
				$toLibraryLabel = $toLibrary->getTrimmedLabel(30);
			}
			else
			{
				$this->getPage()->writeMessage(Prado::localize("La biblioteca destinazione con id={id} non esiste",
																		array('id' => $toLibraryId)), 
													ClavisMessage::ERROR);
				
				return false;
			}
			
			$note = trim($this->NoteSmsAssign->getSafeText());
			
			if ($note != "")
				$note = " (" . $note . ")";
						
			$okFlag = $this->doAssignSms(	$toLibraryId,
											$value);
				
			if ($okFlag)	
			{
				$this->getPage()->writeMessage(Prado::localize("Assegnati correttamente {value} SMS alla biblioteca {to}, per un totale attuale di {total}",
																	array(	'value' => $value,
																			'to' => $toLibraryLabel,
																			'total' => $this->getLibraryAvSms($toLibraryId))), 
													ClavisMessage::CONFIRM);
				
				// writing logs
				ChangelogPeer::logAction(	'Library', 
											ChangelogPeer::LOG_SMSASSIGN, 
											$this->getUser(),
											Prado::localize("Assegnati {value} SMS alla biblioteca '{to}' per un totale di {total} {note}", 
																array(	'value' => $value,
																		'to' => $toLibraryLabel,
																		'total' => $this->getLibraryAvSms($toLibraryId),
																		'note' => $note )), 

											$toLibraryId);
				
				$this->globalRefresh();
			}
			else
			{
				$this->getPage()->writeMessage(Prado::localize("Errore sul trasferimento di {value} SMS da biblioteca {from} alla biblioteca {to}",
																	array('value' => $value)), 
													ClavisMessage::ERROR);
			}
		}
		else
		{
			$this->getPage()->writeMessage(Prado::localize("Operazione di assegnazione SMS non effettuata: la quantità indicata non è un numero valido"), 
												ClavisMessage::WARNING);
		}
	}

	public function onTransferSMS($sender, $param)
	{
		$value = intval($this->SmsToTransfer->getSafeText());

		if ($value > 0)
		{
			$fromLibraryId = intval($this->LibrarySrcTrasf->getSelectedValue());
			$fromLibraryLabel = "";
			$fromLibrary = null;
			
			if ($fromLibraryId > 0)
				$fromLibrary = LibraryQuery::create()->findPk($fromLibraryId);
			
			if ($fromLibrary instanceof Library)
			{
				$fromLibraryLabel = $fromLibrary->getTrimmedLabel(30);
			}
			else
			{
				$this->getPage()->writeMessage(Prado::localize("La biblioteca sorgente, con id={id} non esiste",
																		array('id' => $fromLibraryId)), 
														ClavisMessage::ERROR);
				
				return false;
			}
			
			$toLibraryId = $this->LibraryDestTrasf->getSelectedValue();
			$toLibraryLabel = "";
			$toLibrary = null;
			
			if ($toLibraryId > 0)
				$toLibrary = LibraryQuery::create()->findPk($toLibraryId);
			
			if ($toLibrary instanceof Library)
			{
				$toLibraryLabel = $toLibrary->getTrimmedLabel(30);
			}
			else
			{
				$this->getPage()->writeMessage(Prado::localize("La biblioteca destinazione, con id={id} non esiste",
																		array('id' => $toLibraryId)), 
														ClavisMessage::ERROR);
				
				return false;
			}
			
			if ($fromLibraryId == $toLibraryId)
			{
				$this->getPage()->writeMessage(Prado::localize("La biblioteca sorgente corrisponde con la biblioteca di destinazione: nessuna azione eseguibile"), 
													ClavisMessage::WARNING);

				return false;
			}
			
			$fromLibrarySmsActual = $this->getLibraryAvSms($fromLibraryId);
			$toLibrarySmsActual = $this->getLibraryAvSms($toLibraryId);
			
			$note = trim($this->NoteSmsTransfer->getSafeText());
				
			if ($note != "")
				$note = " (" . $note . ")";
		
			$okFlag = $this->doTransferSms(	$fromLibraryId, 
											$toLibraryId, 
											$value);

			if ($okFlag)
			{	
				// we had a delayed message here, previously
				$this->getPage()->writeMessage(Prado::localize("Trasferiti correttamente {value} SMS dalla biblioteca '{from}' ({totalFrom}) alla biblioteca '{to}' ({totalTo})",
																	array(	'value' => $value,
																			'from' => $fromLibraryLabel,
																			'totalFrom' => $this->getLibraryAvSms($fromLibraryId),
																			'to' => $toLibraryLabel,
																			'totalTo' => $this->getLibraryAvSms($toLibraryId) )), 
													ClavisMessage::CONFIRM);

				
				// writing logs
				ChangelogPeer::logAction(	'Library', 
											ChangelogPeer::LOG_SMSASSIGN, 
											$this->getUser(),
											Prado::localize("Trasferiti {value} SMS alla biblioteca '{to}', totale attuale {total} {note}", 
																array(	'value' => $value,
																		'to' => $toLibraryLabel,
																		'total' => $this->getLibraryAvSms($fromLibraryId),
																		'note' => $note )), 

											$toLibraryId);

				ChangelogPeer::logAction(	'Library', 
											ChangelogPeer::LOG_SMSASSIGN, 
											$this->getUser(),
											Prado::localize("Ricevuti {value} SMS dalla biblioteca '{from}', totale attuale {total} {note}", 
																array(	'value' => $value,
																		'from' => $fromLibraryLabel,
																		'total' => $this->getLibraryAvSms($toLibraryId),
																		'note' => $note )), 

											$fromLibraryId);

				$this->globalRefresh();
			}
			else
			{
				$this->getPage()->writeMessage(Prado::localize("Errore sul trasferimento di {value} SMS da biblioteca {from} alla biblioteca {to}",
																	array('value' => $value)), 
													ClavisMessage::ERROR);
			}

		}
		else
		{
			$this->getPage()->writeMessage(Prado::localize("Operazione di trasferimento SMS non effettuata: la quantità indicata non è un numero valido"), 
												ClavisMessage::WARNING);
		}
	}

	public function onAddAvSMS($sender, $param)
	{
		// for supersayan sureness
		if (!$this->_isSuperadmin)
		{
			$this->getPage()->writeMessage(Prado::localize("L'operazione non è consentita perchè non in possesso dei poteri di SUPERADMIN"), 
												ClavisMessage::WARNING);

			return false;
		}

		$avSmsToAdd = trim($this->AvSmsToAdd->getSafeText());
		
		if ($avSmsToAdd == 0)
		{
			$this->getPage()->writeMessage(Prado::localize("Il numero da sommare agli SMS allocabili è uguale a zero. Nessuna operazione da eseguire"), 
												ClavisMessage::INFO);

			return false;
			
		}
		
		$okFlag = $this->setSysAv($this->getSysAv() + $avSmsToAdd);
		
		if ($okFlag)
		{
			$note = $this->SmsToAddNote->getSafeText();
			
			if ($note != "")
				$note = " (" . $note . ")";
			
			$this->getPage()->writeMessage(Prado::localize("Aggiunti {delta} SMS allocabili. Ora l'ammontare è pari a {total}{note}",
																array(	'delta' => $avSmsToAdd,
																		'total' => $this->getSysAv(),
																		'note' => $note )), 
												ClavisMessage::CONFIRM);
			
			// writing logs
			ChangelogPeer::logAction(	'Library', 
										ChangelogPeer::LOG_SMSASSIGN, 
										$this->getUser(),
										Prado::localize("Aggiunti {value} SMS allocabili, per un totale di {total}{note}", 
															array(	'value' => $avSmsToAdd,
																	'total' => $this->getSysAv(),
																	'note' => $note )), 
										$this->getUser()->getActualLibraryId());
			
			$this->AvSmsToAdd->setText("");
			$this->SmsToAddNote->setText("");
			
			$this->globalRefresh();
		}
		else
		{
			$this->getPage()->writeMessage(Prado::localize("Errore nella modifica degli SMS allocabili da parte di SUPERADMIN"), 
												ClavisMessage::ERROR);
		}
	}
	
	/**
	 * Here we actuate the downloading of changelog, in a CSV style formatted file
	 */
	public function onCsvSmsLogDownload()
	{
		$encoding = ($this->FormatForExcel->getChecked() 
							? 'Windows-1252' 
							: 'UTF-8');
		
		$now = getdate();
		$dateSubfix = $now['year'] . "-" . $now['mon'] . "-" . $now['mday'];
		header('Content-Type: text/csv; charset=' . $encoding);
		header('Content-Disposition: inline; filename=logSMS' . '_' . $dateSubfix . '.csv');
		$fp = fopen('php://output', 'w');
		
		$headers = array(	"Data", 
							"Descrizione", 
							"Operatore", 
							"Biblioteca dell'operatore" );
		
		fputcsv($fp, $headers, ',', '"');
		
		foreach ($this->ChangelogList->DataSource as $row)
		{
			fputcsv(	$fp,
						array(	date("d-m-Y H:i:s", $row["EventDate"]), 
								$row["EventDescription"], 
								$row["UserName"], 
								$row["LibraryLabel"] ), 
					
						',', 
						'"');
		}
		
		fclose($fp);
		die();
	}

	/**
	 * @return int
	 */
	private function calculateAllocatedSms()
	{
		$tempLibraryDestAssig = LibraryPeer::getLibrariesHash(	NULL, 
																NULL, 
																TRUE, 
																TRUE);
		
		$total = 0;
		
		foreach ($tempLibraryDestAssig as $key => $value)
			$total += intval($this->getLibraryAvSms($key));
		
		return $total;
	}

	/**
	 * It returns the amount of sms that are assignable, by system
	 * @return int
	 */
	private function getSysAv()
	{
		$sysAv = 0;

		$sysAvObj = ClavisParamQuery::create()
						->filterByParamClass('SMSACCOUNT')
						->filterByParamName('SYSAVAILABLE')
						->findOne();

		if ($sysAvObj instanceof ClavisParam)
		{
			$sysAv = intval($sysAvObj->getParamValue());
		}
		else
		{
			$this->getPage()->writeMessage("Attenzione, non esiste nel sistema il parametro che descrive il numero degli sms allocabili",
												ClavisMessage::INFO);
		}

		return $sysAv;
	}
	
	/**
	 * It writes the amount of sms that are assignable, by system
	 * @param int $value
	 * @return boolean
	 */
	private function setSysAv($value)
	{
		try
		{
			ClavisParamQuery::create()
								->filterByParamClass('SMSACCOUNT')
								->filterByParamName('SYSAVAILABLE')
								->update(array('ParamValue' => ($value)));
			
			return true;
		}
		catch (PropelException $e)
		{
			return false;
		}
	}
	
	/**
	 * @param int $toLibraryId
	 * @param int $value
	 * 
	 * @return boolean
	 */
	private function doAssignSms(	$toLibraryId, 
									$value)
	{
		$connection = Propel::getConnection();
		$connection->beginTransaction();

		$toLibrarySmsActual = $this->getLibraryAvSms($toLibraryId);

		/**
		 * Logic for checking sms availability.
		 * If we are logged as a superadmin, we don't need to check
		 */
		if (!$this->_isSuperadmin)
		{
			// sms number's availability check
			$sysAv = $this->getSysAv();

			if ($sysAv < $value)
			{
				$connection->rollBack();

				// here below the message was delayed, previously
				$this->writeMessage(Prado::localize("La richiesta di accreditamento ({value}) supera gli SMS disponibili ({available})",
														array(	'value' => $value,
																'available' => $sysAv )),
										ClavisMessage::ERROR);

				return false;
			}
		}

		try
		{
			// updating system sms counter
			if (!$this->_isSuperadmin)
				$this->setSysAv($sysAv - $value);

			// updating library with its new sms amount
			$this->setLibraryAvSms(	$toLibraryId, 
									$toLibrarySmsActual + $value);

			$connection->commit();
			$okFlag = true;
		}
		catch (Exception $ex)
		{
			$connection->rollBack();
			$okFlag = false;
		}
		
		return $okFlag;
	}

	/**
	 * @param int $fromLibraryId
	 * @param int $toLibraryId
	 * @param int $value
	 * 
	 * @return boolean
	 */
	private function doTransferSms(	$fromLibraryId, 
									$toLibraryId, 
									$value)
	{
		$connection = Propel::getConnection();
		$connection->beginTransaction();
		
		$fromLibrarySmsActual = $this->getLibraryAvSms($fromLibraryId);
		$toLibrarySmsActual = $this->getLibraryAvSms($toLibraryId);

		if ($value > $fromLibrarySmsActual)
		{
			$connection->rollBack();
			
			$this->getPage()->writeMessage(Prado::localize("Attenzione: nessuna operazione eseguita perché il numero di sms da trasferire supera la disponibilità attuale della biblioteca sorgente"), 
												ClavisMessage::ERROR);

			return false;
		}
		
		try
		{
			// updating donor library
			$this->setLibraryAvSms(	$fromLibraryId,
									$fromLibrarySmsActual - $value);

			// updating receiver library
			$this->setLibraryAvSms(	$toLibraryId,
									$toLibrarySmsActual + $value);
			$connection->commit();
			$okFlag = true;
		}
		catch (PropelException $e)
		{
			$connection->rollBack();
			$okFlag = false;
		}
		
		return $okFlag;
	}
	
}