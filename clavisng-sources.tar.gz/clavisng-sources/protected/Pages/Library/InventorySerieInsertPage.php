<?php
/**
 * InventorySerieInsertPage class file
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 */

/**
 * InventorySerieInsertPage Class
 *
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2008 ePortal Technologies
 * @copyright Copyright &copy; 2009 Comperio srl
 * @version 2.7
 * @package Pages.Library
 * @since 2.0
 */
/**
 * InventorySerieInsertPage class
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2008 ePortal Technologies
 * @copyright Copyright &copy; 2008-2011 Comperio srl
 * @version 2.7
 * @package Pages
 * @since 2.0
 */


class InventorySerieInsertPage extends ClavisPage
{
	public $_module = 'LIBRARY';
	/* @var InventorySerie */
	private $_inventorySerie = null;

	public function onInit($param)
	{
		parent::onInit($param);

		if (!$this->getIsPostBack())
		{
			$_inventorySerie = null;

		    $invSerieId = $this->getRequest()->itemAt('id');
		    $libraryId = intval($this->getRequest()->itemAt('libraryId'));
			if ($invSerieId != '')
			{
				$_inventorySerie = InventorySeriePeer::retrieveByPK($invSerieId, $libraryId);
				if (is_null($_inventorySerie) || !($_inventorySerie instanceof InventorySerie )) {
					$this->writeMessage(Prado::localize('La serie inventariale {invSerieId} non esiste',
						array('invSerieId' => $invSerieId)),ClavisMessage::ERROR);
					$this->gotoPage('Library.InventorySerieListPage');
				}
				if (!in_array($libraryId,$this->getUser()->getLibraryIds()) &&
						!$this->getUser()->getIsAdmin()) {
					$this->writeMessage(Prado::localize('La serie inventariale {invSerieId}
							è modificabile solo da operatori associati alla biblioteca con ID {library}',
						array('invSerieId' => $invSerieId,'library' => $libraryId)),ClavisMessage::ERROR);
					$this->gotoPage('Library.InventorySerieListPage');
				}
			}
			$this->UpdateData->setObject($_inventorySerie);
			if (is_null($_inventorySerie)) {
				$this->setViewState('is_new', true);
				$_inventorySerie = new InventorySerie();
			}
			$this->setInventorySerie($_inventorySerie);
		}
	}

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getIsPostBack()) {
			$this->populateForm();
			$this->dataBind();
		}
		$this->getInventorySerie();
	}

	public function onCancel($sender, $param)
	{
		if ($this->_inventorySerie instanceof InventorySerie && !$this->_inventorySerie->isNew())
			$this->gotoPage('Library.InventorySerieViewPage',
				array('id' => $this->_inventorySerie->getInventorySerieId(),
					'libraryId'	=> $this->_inventorySerie->getLibraryId()));
		else
			$this->gotoPage('Library.InventorySerieListPage');
	}


	public function onSave($sender, $param)
	{
		if ($this->getIsValid() && $this->saveInventorySerie())
			$this->gotoPage('Library.InventorySerieViewPage',
				array('id' => $this->_inventorySerie->getInventorySerieId(),
					'libraryId'	=> $this->_inventorySerie->getLibraryId()));
	}

	public function saveAndEdit($sender, $param)
	{
		if ($this->getIsValid()) {
			$this->saveInventorySerie();
			$this->populate();
		}
	}

	public function saveInventorySerie()
	{
		$actualLibraryId = $this->getUser()->getActualLibraryId();
		$inventorySerieID = $this->InventorySerieID->getSafeText();
		$counter = intval($this->InvCounter->getSafeText());
		if ($counter < 0) {
			$this->writeMessage(Prado::localize('Il contatore deve essere un numero positivo'),ClavisMessage::ERROR);
			return false;
		}

		if ($this->getViewState('is_new')) {
			$invSerieTest = InventorySeriePeer::retrieveByPK($inventorySerieID, $actualLibraryId);
			if (!is_null($invSerieTest)) {
				$this->writeMessage();
				$this->writeMessage('L\'ID specificato è già stato assegnato ad un\'altra serie inventariale.');
				return false;
			}
			$this->_inventorySerie->setInventoryCounter($counter);
			$this->_inventorySerie->setLibraryId($actualLibraryId);
		} else {
			$max_counter = 0;
			$criteria = new Criteria();

			$criteria->clearSelectColumns();
			$criteria->addSelectColumn('MAX('.ItemPeer::INVENTORY_NUMBER.')');
			$criteria->add(ItemPeer::INVENTORY_SERIE_ID, $inventorySerieID);
			$criteria->addAnd(ItemPeer::HOME_LIBRARY_ID, $this->_inventorySerie->getLibraryId());

			$response = ItemPeer::doSelectStmt($criteria);

			while ($co = $response->fetchColumn(0)) {
				$max_counter = $co;
				break;
			}

			if ($counter < $max_counter) {
				$this->InvCounter->setText($max_counter +1);
				$this->getPage()->setFocus($this->InvCounter->getClientId());
				$this->writeMessage(Prado::localize('Il numero di inventario inserito è minore del contatore ({max_counter}) specificato.',
					array('max_counter'=>$max_counter)));
				return false;
			}
			$this->_inventorySerie->setInventoryCounter($counter);
		}

		$this->_inventorySerie->setInventorySerieId($inventorySerieID);
		$this->_inventorySerie->setDescription($this->Description->getSafeText());
		$this->_inventorySerie->setClosed($this->ClosedSerie->getChecked());
		$this->_inventorySerie->setReadonly($this->ReadOnlySerie->getChecked());
		$this->_inventorySerie->save();
		if ($this->getViewState('is_new')) {
			$actualLibrary = $this->getUser()->getActualLibrary();
			ChangelogPeer::logAction($this->_inventorySerie,
				ChangelogPeer::LOG_CREATE, $this->getUser(),
				"aggiunta serie inventariale \"{$this->_inventorySerie->getInventorySerieId()}\" per biblioteca \"{$actualLibrary->getLabel()}\"");
			$this->writeMessage(Prado::localize('Serie inventariale inserita con successo'),ClavisMessage::INFO);
		} else {
			$libraryLabel = '[non definita]';
			$library = $this->_inventorySerie->getLibrary();
			if (!is_null($library))
				$libraryLabel = $library->getLabel();

			ChangelogPeer::logAction($this->_inventorySerie, ChangelogPeer::LOG_UPDATE, $this->getUser(),
				"modificata serie inventariale \"{$this->_inventorySerie->getInventorySerieId()}\" per biblioteca \"{$libraryLabel}\"");
			$this->writeMessage(Prado::localize('Serie inventariale modificata con successo'),ClavisMessage::INFO);
		}
		$this->setInventorySerie($this->_inventorySerie);
		return true;
	}

	public function populateForm()
	{
		$this->populate();
	}

	/**
	 * Populates the fields in the page with data of object
	 * librarian which are stored in the database.
	 */
	public function populate()
	{
		if ($this->_inventorySerie === null)
			return;

		if (!$this->getViewState('is_new'))	 {
			$this->InventorySerieID->setText($this->_inventorySerie->getInventorySerieId());
			$library = $this->_inventorySerie->getLibrary();
			if(!is_null($library))
				$this->LibraryLabel->setText($library->getLabel());
			$this->Description->setText($this->_inventorySerie->getDescription());
		} else {
			$currentLibrary = $this->getUser()->getActualLibrary();
			if (!is_null($currentLibrary)) {
				$this->LibraryLabel->setText($currentLibrary->getLabel());
			} else {
				$this->writeMessage(Prado::localize('Non è stata definita una biblioteca corrente per l\'operatore!'));
			}
		}
		$this->InvCounter->setText($this->_inventorySerie->getInventoryCounter());
		$this->ClosedSerie->setChecked($this->_inventorySerie->getClosed());
		$this->ReadOnlySerie->setChecked($this->_inventorySerie->getReadonly());
		$this->UpdateData->setObject($this->_inventorySerie);
	}

	/**
	 * Setter method of object inventory serie.
	 *
	 * @param InventorySerie $inventorySerie
	 */
	public function setInventorySerie($inventorySerie)
	{
		$this->_inventorySerie = $inventorySerie;
		$this->setViewState('inventory_serie', $inventorySerie, null);
	}

	/**
	 * Getter method of object invenotry serie.
	 *
	 * @return InventorySerie
	 */
	public function getInventorySerie()
	{
		if (is_null($this->_inventorySerie))
			$this->_inventorySerie = $this->getViewState('inventory_serie', null);
		return $this->_inventorySerie;
	}
	
	public function updateCounter($sender,$param)
	{
		$item = ItemQuery::create()
			->filterByInventorySerie($this->getInventorySerie())
			->orderByInventoryNumber(Criteria::DESC)
			->limit(1)
			->findOne();
		if ($item instanceof Item)
			$this->InvCounter->setText($item->getInventoryNumber());
	}

}
