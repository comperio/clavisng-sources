<?php
/**
 * LibraryList class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Pages.Library
 */

/**
 * LibraryList Class
 *
 * @author Massimiliano Pigozzi
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.8.3
 * @package Pages.Library
 * @since 2.0
 */
class LibraryList extends ClavisPage
{
	public $_module = 'LIBRARY';

	public function globalRefresh()
	{
		$this->LibraryList->populate();
	}

	public function onAddToShelf($sender, $param)
	{
		$this->getPage()->cleanMessageQueue();
		$errorFlag = false;
		
		$shelfId = intval($this->ShelfResultValue->getText());
		
		if ($shelfId > 0)
		{
			$shelf = ShelfQuery::create()->findPk($shelfId);
			
			if ($shelf instanceof Shelf)
			{
				//$checkedLibraries = $this->LibraryList->getCheckedItems();
				$ids = $this->LibraryList->getCheckedIds();
				
				if (count($ids) == 0)
				{
					$this->getPage()->enqueueMessage(Prado::localize("Nessuna biblioteca è stata selezionata per essere aggiunta a scaffale"),
														ClavisMessage::WARNING);
					
					$this->getPage()->flushMessage();
					
					return false;
				}
				
				$countDone = 0;
				$countFailed = 0;
//				$ids = array();
//				foreach ($checkedLibraries as $library)
//					$ids[] = $library->getLibraryId();

				$countDone = $shelf->addItemToShelf(ShelfPeer::TYPE_LIBRARY, $ids);
				$countFailed = count($ids) - $countDone;
	
				if ($countDone > 0) 
				{
					$this->getPage()->enqueueMessage(Prado::localize("N. {count} biblioteche aggiunte allo scaffale {shelfname} con id: {shelfid}",
																		array(	'count' => $countDone,
																				'shelfname' => $shelf->getShelfCompleteName(),
																				'shelfid' => $shelfId)),
														ClavisMessage::CONFIRM);
					
					/////////$this->globalRefresh();
				}

				if ($countFailed > 0)
					$this->getPage()->enqueueMessage(Prado::localize("N. {count} biblioteche non aggiunte a scaffale",
																			array('count' => $countFailed)),
														ClavisMessage::ERROR);
				
				if (($countDone + $countFailed) == 0)
					$this->getPage()->enqueueMessage(Prado::localize("Nessuna biblioteca è stata selezionata per essere aggiunta a scaffale"),
														ClavisMessage::WARNING);
			}
			else
			{
				$errorFlag = true;
			}
		}
		else
		{
			$errorFlag = true;
		}

		if ($errorFlag)
		{
			$this->enqueueMessage(Prado::localize('Errore: scaffale non valido'),
									ClavisMessage::ERROR);
			
			return false;
		}
		
		$this->getPage()->flushMessage();
	}
	
	public function onNewLibrary($sender, $param)
	{
		$this->gotoPage("Library.LibraryInsertPage");
	}
}
