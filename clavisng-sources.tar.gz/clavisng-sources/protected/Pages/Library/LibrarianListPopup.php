<?php

/**
 *
 * LibrarianListPopup Test Page class Module Library
 *
 * @author Massimiliano Pigozzi <mpigozzi@e-portaltech.it>
 * @link http://www.e-portaltech.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @license http://www.e-portaltech.it/license/
 */

class LibrarianListPopup extends ClavisPagePopup
{
	public $_module = "LIBRARY";

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsPostBack())
		{
			$this->dataBind();
		}
	}

	public function onSave($sender, $param)
	{
		if (($librarianName = $this->LibrarianName->Text) != null)
		{
			$newLibrarian = new Librarian();
			$newLibrarian->setName($librarianName);
			$newLibrarian->setLastname($this->LibrarianLastname->getSafeText());

			$currentDate = date('Y-m-d H:i:s');
			$currentUser = $this->User->getID();
			$newLibrarian->setDateCreated($currentDate);
			$newLibrarian->setCreatedBy($currentUser);
			$newLibrarian->setDateUpdated($currentDate);
			$newLibrarian->setModifiedBy($currentUser);

			$newLibrarian->save();

			$this->LibrarianList->populate();
			$this->NewLibrarianDialog->setVisible(false);
			$this->ClearInputDialog();
			$this->dataBind();
		}
	}

	public function onCancel($sender, $param)
	{
		$this->NewLibrarianDialog->setVisible(false);
	}

	private function ClearInputDialog()
	{
		$this->LibrarianName->setText('');
		$this->LibrarianLastname->setText('');
	}

	public function globalRefresh()
	{
		$this->LibrarianList->populate();
	}

	public function isUnlink()
	{
		return false;
	}
}