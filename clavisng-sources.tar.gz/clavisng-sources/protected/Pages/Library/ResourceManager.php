<?php
/**
 * ResourceManager class file
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 */

/**
 * ResourceManager Class
 *
 * @author Cristian Chiarello <cristian.chiarello@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2008 ePortal Technologies
 * @copyright Copyright &copy; 2009 Comperio srl
 * @package Pages.Library
 */
class ResourceManager extends ClavisPage
{
	public $_module = 'LIBRARY';

	public function onLoad($param)
	{
		parent::onLoad($param);
		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallBack()) {

			$this->populate();
		}
	}
	
	public function populate()
	{
		$resip = $this->getRequest()->itemAt('resip');
		if(!is_null( $resip ) && $resip != '')
		{
			$this->ResourceList->setResourceIP($resip);
			$this->ResourceRuleList->setResourceIP($resip);
		}
		$this->ResourceList->populate();
		$this->ResourceRuleList->populate();
		
		$this->populateNMParams();
		
	}
	
	
	public function IsPopup()
	{
		return false;
	}
	
	public function importNas($sender, $param)
	{
		//Prado::log(__METHOD__);
		$nss = NULL;
		$nNas = 0;
		$count = 0;
		$desc = '';
		try
		{
			$client=ClavisRadUtil::getClient($this->getUser()->getActualLibraryId());
			$desc = ClavisRadUtil::getResourceDesc($this);
			$res = $client->getNas(array('description'=>$desc));
			if( isset( $res['result'] ) && isset( $res['result']['status'] ) && $res['result']['status'] == 'ack' )
			{
				if( is_array( $res['result']['data'] ) )
				{
					$nss = $res['result']['data'];
					$nNas = count($nss);
				}
				else
				{
					$this->writeMessage( Prado::localize( "Nessuna risorsa da importare" ), ClavisMessage::INFO );
					Prado::log(__METHOD__ . ' no nas imported from remote');
				}
			}
		} catch (Exception $ex) {
			Prado::log(__METHOD__ . ' EXCPT ' . $ex->getMessage());
		}
		
		
		

		if( $nNas > 0)
		{
			$libid = $this->getUser()->getActualLibraryId();
			foreach($nss as $n)
			{
				$r = ResourceQuery::create()
					->filterByResourceExternalId($n['id'])
					->filterByDescription($desc)
					->findOne();
				if(!($r instanceof Resource))
				{
					$r = new Resource();
				}
				$r->setResourceExternalId($n['id']);
				$r->setName($n['name']);
				$r->setShortname($n['shortname']);
				$r->setType('mikrotik');
				$r->setSecret($n['secret']);
				$r->setDescription($desc);
				$r->setLibraryId($libid);
				try
				{
					$r->save();
					if($r->isNew()) $count++;
				} catch (Exception $ex) {
					Prado::log(__METHOD__ . ' EXCPT ' . $ex->getMessage());
				}
				
			}
			$this->writeMessage( Prado::localize( "Importate {$count} risorse (di {$nNas} trovate)" ), ClavisMessage::INFO );
			$this->reloadPage();
		}	
	}
	
	
	public function showAll($sender, $param)
	{
		$ip = $this->ResourceList->getResourceIP();
		if(!is_null( $ip ) && $ip != '')
		{
			$this->ResourceList->setResourceIP(NULL);
		}
		$this->gotoPage('Library.ResourceManager');
	}
	
	
	public function newRes($sender, $param)
	{
		$this->ResourceEdit->setVisible(TRUE);
		$this->ResourceEdit->setMode("ins");
		$this->ResourceEdit->populate();
	}
	
	public function editRes($sender, $param)
	{
		$pk = $param->getCommandParameter();
		$this->ResourceEdit->setVisible(TRUE);
		$this->ResourceEdit->setMode( "edit");
		$this->ResourceEdit->setResPK($pk);
		$this->ResourceEdit->populate();
	}
	
	
	public function newResRule($sender, $param)
	{
		$this->ResourceRuleEdit->setVisible(TRUE);
		$this->ResourceRuleEdit->setMode("ins");
		$this->ResourceRuleEdit->populate();
	}
	
	
	public function editRuleRes($sender, $param)
	{
		$pk = $param->getCommandParameter();
		$this->ResourceRuleEdit->setVisible(TRUE);
		$this->ResourceRuleEdit->setMode( "edit");
		$this->ResourceRuleEdit->setRulePK($pk);
		$this->ResourceRuleEdit->populate();
	}
	
	public function populateNMParams()
	{
		$nmp = ClavisParamQuery::create()
		->filterByParamName(ClavisRadUtil::CP_CUUT_LIBPREFS)
		->filterByLibraryId($this->getUser()->getActualLibraryId())
		->filterByParamClass(ClavisRadUtil::CP_CLASS)
		->findOne();
		if($nmp instanceof ClavisParam)
		{
			$prefs = json_decode($nmp->getParamValue(),TRUE);
			if($prefs["ctlib"] == 1)
			{
				$this->CTLib->setChecked(TRUE);
			}
			else
			{
				$this->CTLib->setChecked(FALSE);
			}
			
			if($prefs["ctres"] == 1)
			{
				$this->CTRes->setChecked(TRUE);
			}
			else
			{
				$this->CTRes->setChecked(FALSE);
			}
			
			if($prefs["ctgrp"] == 1)
			{
				$this->CTGrp->setChecked(TRUE);
			}
			else
			{
				$this->CTGrp->setChecked(FALSE);
			}
			
			$this->NMParamPanel->setVisible(TRUE);
			$this->ShowNMParamPanelLink->setVisible(FALSE);
		}
		else
		{
			$this->NMParamPanel->setVisible(FALSE);
			$this->ShowNMParamPanelLink->setVisible(TRUE);
		}
		
		$nmru = ClavisParamQuery::create()
		->filterByParamName(ClavisRadUtil::CP_RPCURL_LIBPREFS)
		->filterByLibraryId($this->getUser()->getActualLibraryId())
		->filterByParamClass(ClavisRadUtil::CP_CLASS)
		->findOne();
		if($nmru instanceof ClavisParam)
		{
			$this->URLClavisRad->setText(urldecode($nmru->getParamValue()));
			$this->NMRadRPCPanel->setVisible(TRUE);
			$this->ShowNMRadRPCPanelLink->setVisible(FALSE);
		}
		else
		{
			$this->NMRadRPCPanel->setVisible(FALSE);
			$this->ShowNMRadRPCPanelLink->setVisible(TRUE);
		}
		
		
		$cpsva = ClavisParamQuery::create()
		->filterByParamName(ClavisRadUtil::CP_SESSION_VIEW_AGE)
		->filterByLibraryId($this->getUser()->getActualLibraryId())
		->filterByParamClass(ClavisRadUtil::CP_CLASS)
		->findOne();
		if( $cpsva instanceof ClavisParam)
		{
			$sva = $cpsva->getParamValue();
			$this->SessionViewAge->setText($sva);
		}
	}
	
	public function showNMParamPanel($sender, $param)
	{
		$this->NMParamPanel->setVisible(TRUE);
	}
	
	public function showNMRadRPCPanel($sender, $param)
	{
		$this->NMRadRPCPanel->setVisible(TRUE);
	}
	
	public function saveNMParam($sender, $param)
	{
		$p = array("ctlib" => 0,"ctres" => 0,"ctgrp" => 0);
		$p["ctlib"] = ($this->CTLib->Checked) ? 1 : 0;
		$p["ctres"] = ($this->CTRes->Checked) ? 1 : 0;
		$p["ctgrp"] = ($this->CTGrp->Checked) ? 1 : 0;
		$nmp = ClavisParamQuery::create()
				->filterByParamName(ClavisRadUtil::CP_CUUT_LIBPREFS)
				->filterByLibraryId($this->getUser()->getActualLibraryId())
				->filterByParamClass(ClavisRadUtil::CP_CLASS)
				->findOne();
		if( !($nmp instanceof ClavisParam))
		{
			$nmp = new ClavisParam();
			$nmp->setParamName(ClavisRadUtil::CP_CUUT_LIBPREFS);
			$nmp->setLibraryId($this->getUser()->getActualLibraryId());
			$nmp->setParamClass(ClavisRadUtil::CP_CLASS);
		}
		$nmp->setParamValue(json_encode($p));
		$nmp->save();
		$this->ShowNMParamPanelLink->setVisible(FALSE);
	}
	
	public function delNMParam($sender, $param)
	{
		$nmp = ClavisParamQuery::create()
				->filterByParamName(ClavisRadUtil::CP_CUUT_LIBPREFS)
				->filterByLibraryId($this->getUser()->getActualLibraryId())
				->filterByParamClass(ClavisRadUtil::CP_CLASS)
				->findOne();
		if( $nmp instanceof ClavisParam )
		{
			$nmp->delete();
		}
		$this->NMParamPanel->setVisible(FALSE);
		$this->ShowNMParamPanelLink->setVisible(TRUE);
	}
	
	public function saveNMRadRPC($sender, $param)
	{
		$nmru = ClavisParamQuery::create()
			->filterByParamName(ClavisRadUtil::CP_RPCURL_LIBPREFS)
			->filterByLibraryId($this->getUser()->getActualLibraryId())
			->filterByParamClass(ClavisRadUtil::CP_CLASS)
			->findOne();
		if( !($nmru instanceof ClavisParam))
		{
			$nmru = new ClavisParam();
			$nmru->setParamName(ClavisRadUtil::CP_RPCURL_LIBPREFS);
			$nmru->setLibraryId($this->getUser()->getActualLibraryId());
			$nmru->setParamClass(ClavisRadUtil::CP_CLASS);
		}
		$nmru->setParamValue(urlencode($this->URLClavisRad->getSafeText()));
		$nmru->save();
		$this->ShowNMRadRPCPanelLink->setVisible(FALSE);
	}
	
	public function delNMRadRPC($sender, $param)
	{
		$nmru = ClavisParamQuery::create()
			->filterByParamName(ClavisRadUtil::CP_RPCURL_LIBPREFS)
			->filterByLibraryId($this->getUser()->getActualLibraryId())
			->filterByParamClass(ClavisRadUtil::CP_CLASS)
			->findOne();
		if($nmru instanceof ClavisParam)
		{
			$nmru->delete();
			$this->NMRadRPCPanel->setVisible(FALSE);
			$this->ShowNMRadRPCPanelLink->setVisible(TRUE);
		}
	}
	
	public function saveNMOtherParams($sender, $param)
	{
		$nmru = ClavisParamQuery::create()
		->filterByParamName(ClavisRadUtil::CP_SESSION_VIEW_AGE)
		->filterByLibraryId($this->getUser()->getActualLibraryId())
		->filterByParamClass(ClavisRadUtil::CP_CLASS)
		->findOne();
		if( !($nmru instanceof ClavisParam))
		{
			$nmru = new ClavisParam();
			$nmru->setParamName(ClavisRadUtil::CP_SESSION_VIEW_AGE);
			$nmru->setLibraryId($this->getUser()->getActualLibraryId());
			$nmru->setParamClass(ClavisRadUtil::CP_CLASS);
		}
		
		$sva = $this->SessionsViewAge->getSafeText();
		if($sva != '')
		{
			if(is_numeric($sva))
			{
				$nmru->setParamValue($sva);
				$nmru->save();
			}
			else 
			{
				$this->writeMessage( Prado::localize( "Valore non valido" ), ClavisMessage::ERROR );
			}
		}
		else
		{
			if( ! $nmru->isNew())
			{
				$nmru->delete();
			}
		}
	}

}
