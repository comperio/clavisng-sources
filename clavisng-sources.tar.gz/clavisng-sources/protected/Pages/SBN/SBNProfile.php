<?php
/**
 * SBNProfile class file.
 *
 * This file contains all the required classes for SBN dialogue v4.
 * Based upon SBNConnector by Comperio srl.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Pages.SBN
 */

/**
 * SBNProfile Class
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Pages.SBN
 * @since 2.5.1
 */
class SBNProfile extends ClavisPage {

	public $_module = 'SBN';

	/* @var ClavisSBN */
	public $_sbnMod;

	private $_activities = array();
	private $_docparams = array();
	private $_autparams = array();

	public function onLoad($param)
	{
		parent::onLoad($param);
		$this->_sbnMod = $this->getApplication()->getModule('sbn');
		if (!$this->_sbnMod instanceof TModule ||
				!$this->_sbnMod->getEnabled())
		{
			$this->SBNNotEnabled->setVisible(true);
			$this->SBNEnabled->setVisible(false);
			return;
		}
		if (!$this->getIsPostback())
			$this->populate();
	}

	public function populate()
	{
		$profile = $this->_sbnMod->getSbnProfile();

		$this->UserId->setText((string)$profile->SbnUser->UserId);
		$this->Biblioteca->setText((string)$profile->SbnUser->Biblioteca);
		foreach ($profile->AttivitaAbilitate as $x) {
			$subactivities = array();
			foreach ($x->SottoAttivita as $s)
				$subactivities[] = (string)$s;
			$this->_activities[]	= array(
				'activity'	=> (string)$x->Attivita,
				'subactivities'	=> $subactivities);
		}
		foreach ($profile->ParametriDocumenti as $x)
			$this->_docparams[] = array(
				'tipoMateriale'			=> (string)$x['tipoMateriale'],
				'livelloAut'			=> (string)$x['livelloAut'],
				'abilitaOggetto'		=> (string)$x['abilitaOggetto'],
				'abilitatoForzatura'	=> (string)$x['abilitatoForzatura']
			);
		foreach ($profile->ParametriAuthority as $x)
			$this->_autparams[] = array(
				'tipoAuthority'		=> (string)$x['tipoAuthority'],
				'abilitaAuthority'	=> (string)$x['abilitaAuthority'],
				'abilitaLegamiDoc'	=> (string)$x['abilitaLegamiDoc'],
				'reticoloLegamiDoc'	=> (string)$x['reticoloLegamiDoc'],
				'livelloAut'		=> (string)$x['livelloAut'],
				'abilitatoForzatura'	=> (string)$x['abilitatoForzatura']
			);
		$this->Activities->setDataSource($this->_activities);
		$this->DocParams->setDataSource($this->_docparams);
		$this->AutParams->setDataSource($this->_autparams);
		$this->livelloAdesione->setText((string)$profile->Parametri['livelloAdesione']);
		$this->livelloAutDoc->setText((string)$profile->Parametri['livelloAutDoc']);
		$this->tipoReticoloDoc->setText((string)$profile->Parametri['tipoReticoloDoc']);
		$this->tipoAllineamento->setText((string)$profile->Parametri['tipoAllineamento']);
		$this->spogliDiPeriodici->setText((string)$profile->Parametri['spogliDiPeriodici']);
		$this->autoriSuperflui->setText((string)$profile->Parametri['autoriSuperflui']);
		$this->c2_250->setText((string)$profile->Parametri->c2_250);
		$this->sistemaClassificazione->setText((string)$profile->Parametri->sistemaClassificazione);
		$this->dataBind();
	}

	public function onProfileUpdate($sender,$param)
	{
		$this->_sbnMod->updateSbnProfile();
		$this->populate();
	}
}
