<?php
/**
 * SBNCreatePopup class file.
 *
 * This file contains all the required classes for SBN dialogue v4.
 * Based upon SBNConnector by Comperio srl.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Pages.SBN
 */

/**
 * SBNCreatePopup Class
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Pages.SBN
 * @since 2.5.1
 */
class SBNCreatePopup extends ClavisPagePopup {

	const MAX_RETRIES = 30;
	public $_module = 'SBN';

	/* @var ClavisSBN */
	public $_sbnMod;
	private $_objectId;
	private $_objectClass;
	/* @var Authority|Manifestation */
	public $object;

	private $lookup_bl;
	private $retries = 0;

	public function onLoad($param)
	{
		parent::onLoad($param);
		$this->_sbnMod = $this->getApplication()->getModule('sbn');
		if (!$this->_sbnMod instanceof TModule ||
				!$this->_sbnMod->getEnabled())
		{
			$this->SBNNotEnabled->setVisible(true);
			$this->SBNEnabled->setVisible(false);
			return;
		}
		$this->_objectId = $this->getRequest()->itemAt('param');
		$this->_objectClass = $this->getRequest()->itemAt('objectType');
		$this->getObject();
		/* preload lookups for biblevel */
		$this->lookup_bl = LookupValuePeer::getLookupClassValues('LIVBIBL');

		$this->sendCreateRequest();
	}

	public function getObject()
	{
		if (!$this->object) {
			switch ($this->_objectClass) {
				case 'Manifestation':
					$this->object = ManifestationQuery::create()->findPk($this->_objectId);
					break;
				case 'Authority':
					$this->object = AuthorityQuery::create()->findPk($this->_objectId);
					break;
				default:
					Prado::fatalError('Something very bad has happened');
			}
		}
		return $this->object;
	}

	public function sendCreateRequest($force=false)
	{
		$node = $this->_sbnMod->getNodePrefix();
		$sbnmod = $this->getApplication()->getModule('sbn');
		$request = $sbnmod->getNewRequest();
		$tm = TurboMarc::createRecord($this->object->cacheTurboMarc());
		if (!isset($tm->d099)) {
			$f099 = $tm->addField('099');
			$f099->addSubField('e',(string)$tm->d901->se);
		}
		if (isset($tm->d099->se) && $tm->d099->se < '51') {
			// authority level is out-of-bounds
			$this->SbnErrorPanel->setVisible(true);
			$this->SbnErrorMessage->setText('L\'oggetto ha un livello di catalogazione troppo basso per poter essere caricato in indice SBN. Alzare il livello di catalogazione e riprovare.');
			$this->ResultGrid->setDataSource(array());
			$this->ResultGrid->dataBind();
			return;
		}
		if (isset($tm->d901->se) && $tm->d901->se > '90') {
			// authority level is out-of-bounds
			$this->SbnErrorPanel->setVisible(true);
			$this->SbnErrorMessage->setText(Prado::localize('L\'oggetto ha un livello di catalogazione troppo alto per poter essere caricato in indice SBN. Abbassare il livello di catalogazione e riprovare.'));
			$this->ResultGrid->setDataSource(array());
			$this->ResultGrid->dataBind();
			return;
		}
		switch ($this->_objectClass) {
			case 'Manifestation':
				$type = $this->object->getBibType();
				if (!isset($tm->d099->sb)) {
					$tm->d099->addSubField('b',SBNConverter::ClavisType2SBNType($type));
					switch ($this->object->getBibLevel()) {
						case ManifestationPeer::LVL_MONOGRAPHIC:
							$tm->d099->addSubField('c',(0 == $tm->d200['i1']) ? 'M' : 'W'); break;
						case ManifestationPeer::LVL_SERIAL:
							$tm->d099->addSubField('c','S'); break;
						case ManifestationPeer::LVL_COLLECTION:
							$tm->d099->addSubField('c','C'); break;
						case ManifestationPeer::LVL_ANALYTIC:
							$tm->d099->addSubField('c','N'); break;
					}
				}
				$uppertitle = false;
				if (0 == $tm->d200['i1'] && isset($tm->d461)) {
					$uppertitle = clone $tm->d461;
				}
				for ($i=400; $i<801; ++$i) {
					$tag = 'd'.$i;
					unset($tm->$tag);
					if (500 == $i)
						$i = 600;
				}
				if (0 == $tm->d200['i1'] && $uppertitle) {
					$tm->appendNode($uppertitle);
				}
				$sbnType = SBNTypes::OBJCLASS_DOC;
				$sbnMarc = SBNConverter::Turbomarc2SBN($tm);
				break;
			case 'Authority':
				$type = $this->object->getAuthorityType();
				if (!isset($tm->d099->sb))
					$tm->d099->addSubField('d',SBNConverter::ClavisType2SBNType($type));

                if(AuthorityPeer::TYPE_WORK == $type && (isset($tm->d928) || isset($tm->d929)))
                    $tm->d099->sd = SBNTypes::AUTTYPE_TITOLO_UNIFORME_MUSICA;

				if (AuthorityPeer::TYPE_CLASS == $type) {
					// 'D'+cod_edizione+simbolo per il sistema Dewey e cod_sistema+simbolo per altri sistemi
					if (isset($tm->d676)) {
						$bid = 'D'.$tm->d676->sv.$tm->d676->sa;
					} else if (isset($tm->d686)) {
						$bid = $tm->d686->s2.$tm->d686->sa;
					}
				}
				$sbnMarc = SBNConverter::Turbomarc2SBN($tm);
				if (AuthorityPeer::RECTYPE_VARIANT == $this->object->getAuthorityRectype()) {
					$aa = $this->object->getAcceptedAuthority();
					if (!$aa instanceof Authority || $aa->getBidSource() != 'SBN' || !$aa->getBid()) {
						$this->SbnErrorPanel->setVisible(true);
						$this->SbnErrorMessage->setText(Prado::localize("L'authority non ha una forma accettata, richiesta da indice SBN.\nCreazione fallita."));
						$this->ResultGrid->setDataSource(array());
						$this->ResultGrid->dataBind();
						return;
					}
					$l = $sbnMarc->addChild('LegamiElementoAut')->addChild('ArrivoLegame')
						->addChild('LegameElementoAut');
					$l->addAttribute('tipoAuthority',SBNConverter::ClavisType2SBNType($aa->getAuthorityType()));
					$l->addAttribute('tipoLegame','4XX');
					$l->addChild('idArrivo',$aa->getBid());
				}
				$sbnType = SBNTypes::OBJCLASS_AUT;
				break;
		}
		if (!isset($bid)) {
			$node .= SBNConverter::ClavisType2SBNIdPrefix($type);
			$cntparam = ClavisParamQuery::create()->filterByParamClass('SBNCOUNTER')->filterByParamName($node)->findOneOrCreate();
			$counter = intval($cntparam->getParamValue()) + 1;
			$bid = $node.str_pad($counter,10-strlen($node),0,STR_PAD_LEFT);
		}

		$sbn_response = $request->create($force ? SBNTypes::CREATECONTROL_CONFIRM : SBNTypes::CREATECONTROL_CHECK,
			$sbnType, $sbnMarc, $bid);
		if (!$sbn_response instanceof SBNMarc) {
			$this->SbnErrorPanel->setVisible(true);
			$this->SbnErrorMessage->setText(Prado::localize('La connessione all\'indice è fallita, si prega di riprovare più tardi.'));
			$this->ResultGrid->setDataSource(array());
			$this->ResultGrid->dataBind();
			return;
		}
		$this->SbnReq->setText($request->sbnMarc->asXML());
		$this->SbnResp->setText($sbn_response->asXML());
		$resultSet = array();
		switch ($sbn_response->SbnMessage->SbnResponse->SbnResult->esito) {
			case '3004':	// alike titles found
				$hits = (string)$sbn_response->SbnMessage->SbnResponse->SbnOutput['totRighe'];
				switch ($this->_objectClass) {
					case 'Manifestation':
						foreach ($sbn_response->SbnMessage->SbnResponse->SbnOutput->Documento as $doc)
							if ($rec = $this->parseTurbomarc(
									SBNConverter::SBN2Turbomarc(
										$sbnmod->getNewRequest()->searchTitleByBid((string)$doc->DatiDocumento->T001))))
								$resultSet[] = $rec;
						break;
					case 'Authority':
						$tmCollection = SBNConverter::SBN2Turbomarc($sbn_response);
						foreach ($tmCollection->children() as $r)
							if ($rec = $this->parseTurbomarc($r))
								$resultSet[] = $rec;
						break;
				}
				$this->ResultOverflow->setVisible((int)$sbn_response->SbnMessage->SbnResponse->SbnOutput['totRighe'] > (int)$sbn_response->SbnMessage->SbnResponse->SbnOutput['maxRighe']);
				$this->ResultGrid->setDataSource($resultSet);
				$this->ResultGrid->dataBind();
				$this->ResultNumLabel->Parameters->results = $hits;
				$this->SbnFoundTitles->setVisible(true);
				break;
			case '0000':	// correctly created
				if (isset($cntparam))
					$cntparam->setParamValue($counter)->save();
				$this->SbnConfirmCreation->setVisible(true);
				switch ($this->_objectClass) {
					case 'Manifestation':
						$bid = (string)$sbn_response->SbnMessage->SbnResponse->SbnOutput->Documento->DatiDocumento->T001;
						$ts = (string)$sbn_response->SbnMessage->SbnResponse->SbnOutput->Documento->DatiDocumento->T005;
						break;
					case 'Authority':
						$bid = (string)$sbn_response->SbnMessage->SbnResponse->SbnOutput->ElementoAut->DatiElementoAut->T001;
						$ts = (string)$sbn_response->SbnMessage->SbnResponse->SbnOutput->ElementoAut->DatiElementoAut->T005;
						break;
				}
				$d099 = isset($tm->d099) ? $tm->d099 : $tm->addField('099');
				$d099->addSubField('a',$bid);
				$d099->addSubField('5',$ts);
				$resultSet[] = $this->parseTurbomarc($tm);
				$this->ResultGrid->setDataSource($resultSet);
				$this->ResultGrid->dataBind();
				$this->SbnFoundTitles->setVisible(false);
				break;
			case '3012':	// already existing BID
			case '3126':	// already existing and deleted BID
				$cntparam->setParamValue($counter)->save();
				if (++$this->retries > self::MAX_RETRIES) {
					$this->SbnErrorPanel->setVisible(true);
					$this->SbnErrorMessage->setText(Prado::localize('Rilevato ID duplicato per troppi tentativi, si prega di riprovare più tardi.'));
					$this->ResultGrid->setDataSource(array());
					$this->ResultGrid->dataBind();
					return;
				}
				$this->sendCreateRequest();
				return;
			default:
				$this->SbnErrorPanel->setVisible(true);
				$this->SbnErrorMessage->setText((string)$sbn_response->SbnMessage->SbnResponse->SbnResult->testoEsito);
				$this->ResultGrid->setDataSource(array());
				$this->ResultGrid->dataBind();
				return;
		}
	}

	private function parseTurbomarc(TurboMarc $tm) {
		$ret = array('Id' => 0, 'Turbomarc' => $tm->asXML());
		switch ($this->_objectClass) {
			case 'Manifestation':
				return $this->parseTurbomarcManifestation($tm);
			case 'Authority':
				return $this->parseTurbomarcAuthority($tm);
		}
	}

	private function parseTurbomarcManifestation(TurboMarc $tm) {
		if (isset($tm->r))
			$tm = $tm->r;
		$ret = array('Id' => 0, 'ClavisId' => 0, 'Turbomarc' => $tm->asXML(), 'InCatalog' => false);
		$l = $tm->getLeader();
		// the following is to avoid errors with SBN - TEMP!!!
		if (! $l instanceof TurboMarcLeader)
			return null;
		$our_record_id = ManifestationPeer::bidExists((string)$tm->d035->s9,(string)$tm->d035->sa);
		if ($our_record_id) {
			$ret['ClavisId'] = $ret['Id'] = $our_record_id;
			$ret['InCatalog'] = true;
		}
		$ret['Bid'] = (string)$tm->d099->sa;
		$ret['Text'] = '';
		if ($v = $tm->getAuthor())
			$ret['Text'] .= $v.'<br/>';
		$ret['Text'] .= '<strong>'.trim($tm->getFullTitle()).'</strong>';
		if ($tm->getEAN())
			$ret['Text'] .= '<br/>'.$tm->getEAN();
		if ($v = implode(' - ',$tm->getEditions()))
			$ret['Text'] .= '<br/>'.$v;
		if ($v = implode(' - ',$tm->getPublications()))
			$ret['Text'] .= '<br/>'.$v;
		if ($v = implode(' - ',$tm->getPhysicalDescs()))
			$ret['Text'] .= '<br/>'.$v;
		if ($v = implode(' - ',$tm->getSeries()))
			$ret['Text'] .= '<br/>'.$v;
		if (isset($tm->d461))
			$ret['Text'] .= '<br/><em>'.Prado::localize('Fa parte di: ')."</em> {$tm->d461->st} [{$tm->d461->s1}]";
		if ($v = $tm->getDewey())
			$ret['Text'] .= '<br/><em>'.Prado::localize('Classe: ').'</em>'.$v;
		if ($v = implode(' - ',$tm->getSubjects()))
			$ret['Text'] .= '<br/><em>'.Prado::localize('Soggetti: ').'</em>'.$v;
		return $ret;
	}

	private function parseTurbomarcAuthority(TurboMarc $tm) {
		$ret = array('Id' => 0, 'ClavisId' => 0, 'InCatalog' => false);
		$l = $tm->getLeader();
		$our_auth_id = AuthorityPeer::bidExists((string)$tm->d035->s9,(string)$tm->d035->sa);
		if ($our_auth_id) {
			$ret['ClavisId'] = $ret['Id'] = $our_auth_id;
			$ret['InCatalog'] = true;
		}
		$ret['Bid'] = (string)$tm->d099->sa;
		$ret['AuthType'] = (string)$tm->d099->sd;
		$ret['Text'] = '';
		if ($v = $tm->getAuthor())
			$ret['Text'] .= $v.'<br/>';

		switch ((string)$tm->d099->sd) {
			case SBNTypes::AUTTYPE_AUTORE:
				if (isset($tm->d200)) {	// AutPersonaleType
					$ret['Text'] .= $tm->getAuthor(200);
				} else if (isset($tm->d210)) {	// EnteType
					$ret['Text'] .= $tm->getAuthor(210);
				}
				break;
			case SBNTypes::AUTTYPE_TITOLO_UNIFORME:
			case SBNTypes::AUTTYPE_TITOLO_UNIFORME_MUSICA:
				$ret['Text'] .= (string)$tm->d230->sa;
				break;
			case SBNTypes::AUTTYPE_SOGGETTO:
				$ret['Text'] .= "[{$tm->d250->s2}] ".(string)$tm->d250->sa;
				if (isset($tm->d250->sx))
					$ret['Text'] .= ' - '.implode(' - ',$tm->d250->sx);
				break;
			case SBNTypes::AUTTYPE_DESCRITTORE:
				$ret['Text'] .= "[{$tm->d931->s2}] {$tm->d931->sa}";
				break;
			case SBNTypes::AUTTYPE_LUOGO:
				$ret['Text'] .= (string)$tm->d260->sd;
				break;
			case SBNTypes::AUTTYPE_CLASSE:
				$ret['Text'] .= (isset($tm->d676)) ?
					"[{$tm->d676->sv}] {$tm->d676->sa} {$tm->d676->sc}" :
					"[{$tm->d686->s2}] {$tm->d686->sa} {$tm->d686->s2}" ;
				break;
			case SBNTypes::AUTTYPE_MARCA:
				$ret['Text'] .= (string)$tm->d921->sa;
				break;
			case SBNTypes::AUTTYPE_REPERTORIO:
				$ret['Text'] .= "[{$tm->d930->s2}] {$tm->d930->sa}";
				break;
		}
		$ret['Text'] = '<strong>'.htmlentities($ret['Text'],ENT_QUOTES,'UTF-8').'</strong>';
		return $ret;
	}

	public function onForceCreate($sender, $param) {
		$this->sendCreateRequest(true);
	}
}
