<?php
/**
 * SBNSync class file.
 *
 * This file contains all the required classes for SBN dialogue v4.
 * Based upon SBNConnector by Comperio srl.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Pages.SBN
 */

/**
 * SBNSync Class
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Pages.SBN
 * @since 2.5.1
 */
class SBNSync extends ClavisPage {

	public $_module = 'SBN';

	/* @var ClavisSBN */
	public $_sbnMod;
	public $lookup_bl;

	public function onLoad($param)
	{
		parent::onLoad($param);
		$this->_sbnMod = $this->getApplication()->getModule('sbn');
		if (!$this->_sbnMod instanceof TModule ||
				!$this->_sbnMod->getEnabled())
		{
			$this->SBNNotEnabled->setVisible(true);
			$this->SBNEnabled->setVisible(false);
			return;
		}
		/* preload lookups for biblevel */
		$this->lookup_bl = LookupValuePeer::getLookupClassValues('LIVBIBL');
		if ($this->getIsPostBack() && $this->FakeValue->getValue()) {
			$this->FakeValue->setValue(null);
			$this->FakeLabel->setValue(null);
			$this->populate();
		}
	}

	public function completePager($sender,$param) {
		$pager = $param->Pager->getControls();
		//$pager->add(' / ' . $this->ResultGrid->getPageCount());

		$label = new TLabel();
		$label->setID('PageRowsLabel');
		$label->setText(Prado::localize('righe per pagina').' ');
		$pager->insertAt(0,$label);

		$pageSizeSelect = new TDropDownList();
		$pageSizeSelect->setID('PageRows');
		$pageSizeSelect->setAutoPostBack(true);
		foreach(array(10, 20, 50, 100) as $value) {
			$element = new TListItem();
			$element->setText($value);
			$element->setValue($value);
			$pageSizeSelect->getItems()->add($element);
		}
		if (($pageSize = $sender->getPageSize()) > 0)
			$pageSizeSelect->setSelectedValue($pageSize);
		$pager->insertAt(1,$pageSizeSelect);
		$pageSizeSelect->attachEventHandler('OnSelectedIndexChanged', array($this, 'onChangePageSize'));
		$pager->insertAt(2,' | ');
	}

	private function parseTurbomarc($tm) {
		$ret = array(
			'Id' => 0,
			'ClavisId' => 0,
			'Turbomarc' => '',
			'Bid' => '',
			'BidSource' => 'SBN',
			'BibLevelCode' => '',
			'BibLevelLabel' => '',
			'Title'	=> '',
			'Author' => '',
			'EAN' => '',
			'Editions' => '',
			'Publications' => '',
			'Series' => '',
			'Dewey' => '',
			'Subjects' => '',
			'PartOf' => ''
		);
		if (!$tm)
			return $ret;
		$l = $tm->getLeader();
		// the following is to avoid errors with SBN - TEMP!!!
		if (! $l instanceof TurboMarcLeader)
			return $ret;

		$our_record_id = ManifestationPeer::bidExists((string)$tm->d035->s9,(string)$tm->d035->sa);
		if ($our_record_id)
			$ret['ClavisId'] = $ret['Id'] = $our_record_id;
		$ret['Turbomarc'] = $tm->asXML();
		$ret['DocType'] = (string)$tm->d099->sb;
		$ret['Bid'] = (string)$tm->d035->sa;
		$ret['BidSource'] = (string)$tm->d035->s9;
		$ret['BibLevelCode'] = $l->biblevel;
		$ret['BibLevelLabel'] = (array_key_exists($ret['BibLevelCode'], $this->lookup_bl)) ?
			$this->lookup_bl[$ret['BibLevelCode']] : '---';
		$ret['Title'] = trim($tm->getFullTitle());
		$ret['Author'] = $tm->getAuthor();
		$ret['EAN'] = $tm->getEAN();
		$ret['Editions'] = implode(' - ',$tm->getEditions());
		$ret['Publications'] = implode(' - ',$tm->getPublications());
		$ret['Series'] = implode(' - ',$tm->getSeries());
		$ret['Dewey'] = $tm->getDewey();
		$ret['Subjects'] = implode(', ',$tm->getSubjects());
		$ret['PartOf'] = isset($tm->d461) ? "{$tm->d461->st} [{$tm->d461->s1}]" : '';
		return $ret;
	}

	private function parseTurbomarcAuthority($tm) {
		$ret = array('Id' => 0,
			'ClavisId' => 0,
			'Turbomarc' => '',
			'Bid' => '',
			'BidSource' => 'SBN',
			'AuthType' => '',
			'Author' => '',
			'Text' => '');
		if (!$tm)
			return $ret;
		$l = $tm->getLeader();
		$our_auth_id = AuthorityPeer::bidExists((string)$tm->d035->s9,(string)$tm->d035->sa);
		if ($our_auth_id)
			$ret['ClavisId'] = $ret['Id'] = $our_auth_id;
		$ret['Turbomarc'] = $tm->asXML();
		$ret['Bid'] = (string)$tm->d035->sa;
		$ret['BidSource'] = (string)$tm->d035->s9;
		$ret['AuthType'] = (string)$tm->d099->sd;
		$ret['Author'] = $tm->getAuthor();

		switch ((string)$tm->d099->sd) {
			case SBNTypes::AUTTYPE_AUTORE:
				if (isset($tm->d200)) {	// AutPersonaleType
					$ret['Text'] = $tm->getAuthor(200);
				} else if (isset($tm->d210)) {	// EnteType
					$ret['Text'] = $tm->getAuthor(210);
				}
				break;
			case SBNTypes::AUTTYPE_TITOLO_UNIFORME:
			case SBNTypes::AUTTYPE_TITOLO_UNIFORME_MUSICA:
				$ret['Text'] = (string)$tm->d230->sa;
				break;
			case SBNTypes::AUTTYPE_SOGGETTO:
				$ret['Text'] = "[{$tm->d250->s2}] ".(string)$tm->d250->sa;
				foreach ($tm->d250->sx as $subd)
					$ret['Text'] .= ' - '.$subd;
				break;
			case SBNTypes::AUTTYPE_DESCRITTORE:
				$ret['Text'] = "[{$tm->d931->s2}] {$tm->d931->sa}";
				break;
			case SBNTypes::AUTTYPE_LUOGO:
				$ret['Text'] = (string)$tm->d260->sd;
				break;
			case SBNTypes::AUTTYPE_CLASSE:
				$ret['Text'] = (isset($tm->d676)) ?
					"[{$tm->d676->sv}] {$tm->d676->sa} {$tm->d676->sc}" :
					"[{$tm->d686->s2}] {$tm->d686->sa} {$tm->d686->sc}" ;
				break;
			case SBNTypes::AUTTYPE_MARCA:
				$ret['Text'] = (string)$tm->d921->sa;
				break;
			case SBNTypes::AUTTYPE_REPERTORIO:
				$ret['Text'] = "[{$tm->d930->s2}] {$tm->d930->sa}";
				break;
			default:
				$ret['Text'] = Prado::localize('Tipo authority non riconosciuto: {authtype}',
					array('authtype'=>(string)$tm->d099->sd));
		}
		$ret['Text'] = htmlentities($ret['Text'],ENT_QUOTES,'UTF-8');
		return $ret;
	}

	public function onSyncRequest($sender, $param)
	{
		$this->populate();
	}

	public function populate()
	{
		$lastsync = new DateTime('2012-01-01');
		$curdate = new DateTime('now');
		$resultSet = array();
		while ($curdate > $lastsync) {
			$fromdate = $curdate->sub(new DateInterval('P3M'));
			$req = $this->_sbnMod->getNewRequest();
			$req->setSearchOutputType(SBNTypes::OUTPUT_COMPLETE);
			$ret = $req->getUpdates(SBNTypes::OBJCLASS_DOC,SBNTypes::DOCTYPE_TUTTI);
			$hits = 0;
			if ($ret && '0000' == $ret->SbnMessage->SbnResponse->SbnResult->esito) {
				$hits = (string)$ret->SbnMessage->SbnResponse->SbnOutput['totRighe'];
				foreach ($ret->SbnMessage->SbnResponse->SbnOutput->AllineaInfo as $item) {
					// skip TitAccesso and ElementoAut
					if (isset($item->oggettoVariato->Documento->DatiTitAccesso)
							|| isset($item->oggettoVariato->ElementoAut))
						continue;
					$tm = ('Cancellato' == (string)$item->oggettoVariato['tipoModifica'])
						? null : SBNConverter::SBN2Turbomarc($item->oggettoVariato)->r;
					$data = $this->parseTurbomarc($tm);
					$data['TargetBid'] = $data['Bid'];
					$data['TargetClavisId'] = $data['ClavisId'];
					$data['Bid'] = (string)$item->T001;
					$data['ClavisId'] = ManifestationPeer::bidExists($data['BidSource'], $data['Bid']);
					$data['editType'] = (string)$item->oggettoVariato['tipoModifica'];
					if ($data['ClavisId'] && 'Cancellato' == $data['editType'])
						$data['Deleteable'] = ManifestationPeer::getOneByBid($data['BidSource'], $data['Bid'])->isDeleteable();
					$resultSet[] = $data;
				}
			}
			$curdate = $fromdate;
			break; // PATCH TODO:
		}
		$this->DocUpdatesGrid->setVirtualItemCount($hits);
		$this->DocUpdatesGrid->setDataSource($resultSet);
		$this->DocUpdatesGrid->dataBind();

		$resultSet = array();
		$hits = 0;
		foreach (SBNTypes::getAuthorityTypes() as $type) {
			$req = $this->_sbnMod->getNewRequest();
			$req->setSearchOutputType(SBNTypes::OUTPUT_COMPLETE);
			$ret = $req->getUpdates(SBNTypes::OBJCLASS_AUT,$type);
			if ($ret && '0000' == $ret->SbnMessage->SbnResponse->SbnResult->esito) {
				$hits += (string)$ret->SbnMessage->SbnResponse->SbnOutput['totRighe'];
				foreach ($ret->SbnMessage->SbnResponse->SbnOutput->AllineaInfo as $item) {
					$tm = ('Cancellato' == (string)$item->oggettoVariato['tipoModifica'])
						? null : SBNConverter::SBN2Turbomarc($item->oggettoVariato)->r;
					$data = $this->parseTurbomarcAuthority($tm);
					$data['TargetBid'] = $data['Bid'];
					$data['TargetClavisId'] = $data['ClavisId'];
					$data['Bid'] = (string)$item->T001;
					$data['ClavisId'] = AuthorityPeer::bidExists($data['BidSource'], $data['Bid']);
					$data['editType'] = (string)$item->oggettoVariato['tipoModifica'];
					if ($data['ClavisId'] && 'Cancellato' == $data['editType'])
						$data['Deleteable'] = AuthorityPeer::getOneByBid($data['BidSource'], $data['Bid'])->isDeleteable();
					$resultSet[] = $data;
				}
			}
			$ret = null;
		}
		$this->AutUpdatesGrid->setVirtualItemCount($hits);
		$this->AutUpdatesGrid->setDataSource($resultSet);
		$this->AutUpdatesGrid->dataBind();

		return;
	}

	public function resultAction($sender,$param)
	{
		$data = $param->getCommandParameter();
		switch ($param->getCommandName()) {

			case 'import':
				try {
					$this->import($data);
					$msg = Prado::localize('Importazione eseguita correttamente.');
					$type = ClavisMessage::CONFIRM;
					$this->getPage()->writeMessage($msg, $type);
				} catch (PropelException $e) {
					// duplicate!
					$this->getPage()->writeMessage(Prado::localize('Errore durante l\'importazione: '.
					'il *ID esiste già nella base dati'), ClavisMessage::ERROR);
				} catch (Exception $e) {
					Prado::log('Exception: '.$e->getMessage());
					$this->getPage()->writeMessage(Prado::localize('Errore durante l\'importazione: ').$e->getMessage(),
						ClavisMessage::ERROR);
				}
				break;

			case 'unlink':
				$clavisId = $data['ClavisId'];
				$obj = isset($data['AuthType'])
					? AuthorityQuery::create()->findPk($clavisId)
					: ManifestationQuery::create()->findPk($clavisId);
				$obj->setBidSource(null);
				$obj->setBid(null);
				$tm = $obj->getTurboMarc();
				if (isset($tm->d099))
					unset($tm->d099);
				$obj->setUnimarc($tm->asXML());
				$obj->save();
				$this->getPage()->writeMessage(Prado::localize('Dati sorgente correttamente eliminati.'),
					ClavisMessage::CONFIRM);
				// don't break
			case 'unlocalize':
				$bid = $data['Bid'];
				if (isset($data['AuthType'])) {
					$sbnClass = SBNTypes::OBJCLASS_AUT;
					$sbnType = $data['AuthType'];
				} else {
					$sbnClass = SBNTypes::OBJCLASS_DOC;
					$sbnType = $data['DocType'];
				}
				// since the localization is "manage", we always use default library code for the node.
				$elements = array(
					array(
						'class'	=> $sbnClass,
						'type'	=> $sbnType,
						'bid'	=> $bid,
						'items'	=> array(array(
							'libSBNCode'		=> $this->_sbnMod->getLibraryCode(),
						))
					)
				);
				$req = $this->_sbnMod->getNewRequest();
				$req->localize($elements,SBNTypes::LOCACTION_UNLOCALIZE,SBNTypes::LOCTYPE_ALL);
				$this->getPage()->writeMessage(Prado::localize('Oggetto correttamente delocalizzato per gestione da SBN.'),ClavisMessage::CONFIRM);
				break;

			case 'merge':
				if (isset($data['AuthType'])) {
					$src = AuthorityPeer::getOneByBid($data['BidSource'],$data['Bid']);
					if (!$src instanceof Authority) {
						$this->getPage()->writeMessage(
							Prado::localize('Authority di partenza non trovata in catalogo.'),
							ClavisMessage::ERROR);
						break;
					}
					$dst = (!$data['TargetClavisId'])
						? $this->import($data)	// target record does not exists, let's import it!
						: AuthorityPeer::getOneByBid($data['BidSource'],$data['TargetBid']);
					if (!$dst instanceof Authority) {
						$this->getPage()->writeMessage(
							Prado::localize('Authority di destinazione non trovata in catalogo.'),
							ClavisMessage::ERROR);
						break;
					}
					$update = array(
						'objClass'	=> SBNTypes::OBJCLASS_AUT,
						'objType'	=> $data['AuthType'],
						'bid'		=> $data['Bid']);
				} else {
					$src = ManifestationPeer::getOneByBid($data['BidSource'],$data['Bid']);
					if (!$src instanceof Manifestation) {
						$this->getPage()->writeMessage(
							Prado::localize('Notizia di partenza non trovata in catalogo.'),
							ClavisMessage::ERROR);
						break;
					}
					$dst = (!$data['TargetClavisId'])
						? $this->import($data)	// target record does not exists, let's import it!
						: ManifestationPeer::getOneByBid($data['BidSource'],$data['TargetBid']);
					if (!$dst instanceof Manifestation) {
						$this->getPage()->writeMessage(
							Prado::localize('Notizia di destinazione non trovata in catalogo.'),
							ClavisMessage::ERROR);
						break;
					}
					$update = array(
						'objClass'	=> SBNTypes::OBJCLASS_DOC,
						'objType'	=> $data['DocType'],
						'bid'		=> $data['Bid']);
				}
				$src->replaceWith($dst, $this->getUser());
				$req = $this->_sbnMod->getNewRequest();
				$req->sendUpdated(array($update));
				$this->getPage()->writeMessage(Prado::localize('Schiacciamento eseguito correttamente.'),ClavisMessage::CONFIRM);
				break;

			case 'delete':
				try {
					if (isset($data['AuthType'])) {
						$obj = AuthorityPeer::getOneByBid($data['BidSource'],$data['Bid']);
						$update = array(
							'objClass'	=> SBNTypes::OBJCLASS_AUT,
							'objType'	=> $data['AuthType'],
							'bid'		=> $data['Bid']);
					} else {
						$obj = ManifestationPeer::getOneByBid($data['BidSource'],$data['Bid']);
						$update = array(
							'objClass'	=> SBNTypes::OBJCLASS_DOC,
							'objType'	=> $data['DocType'],
							'bid'		=> $data['Bid']);
					}
					ChangelogPeer::logAction($obj, ChangelogPeer::LOG_DELETE, $this->getUser(),
						'Cancellato record con id = '.$obj->getId().' per allineamento SBN');
					$obj->delete();
					$req = $this->_sbnMod->getNewRequest();
					$req->sendUpdated(array($update));
					$this->getPage()->writeMessage(Prado::localize('Eliminazione eseguita correttamente.'),ClavisMessage::CONFIRM);
				} catch (Exception $e) {
					$this->getPage()->writeMessage(Prado::localize('Errore durante l\'eliminazione.'),ClavisMessage::ERROR);
				}
				break;
		}
		$this->populate();
	}

	protected function import($data)
	{
		if (isset($data['AuthType'])) {
			$tm = TurboMarc::createRecord($data['Turbomarc']);
			$a = AuthorityPeer::createFromTurbomarc($tm);
			$a->doIndex();
			ChangelogPeer::logAction($a, ChangelogPeer::LOG_CREATE, $this->getUser(), 'Nuova authority importata');
			return $a;
		} else {
			$linkbucket = $this->getSession()->itemAt('ImportLinkBucket');
			if (!is_array($linkbucket))
				$linkbucket = array();
			$lbcount = count($linkbucket);
			$tm = TurboMarc::createRecord($data['Turbomarc']);
			// do all needed pre-import stuff (e.g. import series)
			$this->doPreImport($tm);
			$m = ManifestationPeer::createFromTurbomarc($tm, false, $linkbucket);
			$m->doIndex();
			$lbcount2 = count($linkbucket);
			// update linkbucket: since import went well, if BID is in bucket, remove it.
			foreach ($linkbucket as $k => $manifestation)
				foreach($manifestation['links'] as $j => $link)
					if ($link['bid_source'] == $m->getBidSource() &&
						$link['bid'] == $m->getBid())
						unset($linkbucket[$k]['links'][$j]);
			// updated, readd into session.
			$this->getSession()->add('ImportLinkBucket',$linkbucket);
			ChangelogPeer::logAction($m, ChangelogPeer::LOG_CREATE, $this->getUser(), 'Nuova notizia importata');
			return $m;
		}
	}

	private function doPreImport(TurboMarc $tm)
	{
		$bidFld = 's'.strtolower($tm->d035->s9);
		// check if record has a BID'ed serie, if we haven't it in catalog, yet, import!
		if (isset($tm->d410))
			foreach ($tm->d410 as $seriefld)
				if (isset($seriefld->$bidFld) && !ManifestationPeer::bidExists((string)$tm->d035->s9,(string)$seriefld->$bidFld))
				{
					$req = $this->_sbnMod->getNewRequest();
					$ret = $req->searchTitleByBid((string)$seriefld->$bidFld);
					if (isset($ret->SbnMessage->SbnResponse->SbnResult->esito)
						&& '0000' == $ret->SbnMessage->SbnResponse->SbnResult->esito)
					{
						$tm = SBNConverter::SBN2Turbomarc($ret)->r;
						if (isset($tm->d200)) {
							$serie = ManifestationPeer::createFromTurbomarc($tm);
							$serie->doIndex();
						}
					}
				}
	}
}
