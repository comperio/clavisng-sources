<?php

/**
 * Record Page class Module Catalog
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @author Dario Rigolin <dario@e-portaltech.it>
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2008 ePortal Technologies
 * @copyright Copyright &copy; 2009 Comperio srl
 *
 * It inserts and views single manifestations.
 */

class RecordAmbrosiana extends ClavisPage {

	/**
	 * Module where we are.
	 *
	 * @var string
	 */
	public $_module = 'CATALOG';

	private $_manifestation;

	public function onInit($param)
	{
		parent::onInit($param);
		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallback())
		{
			$this->setReturnUrl(intval($this->getRequest()->itemAt('returnUrl')));

			$manifestationId = intval($this->getRequest()->itemAt('manifestationId'));
			if ($manifestationId > 0)
			{
				$manifestation = ManifestationPeer::retrieveByPK($manifestationId);
				if (is_null($manifestation))
					$this->gotoExit(serialize(array(Prado::localize("Errore: nessuna notizia corrisponde"), '', '', '')));
			}
			else
				$manifestation = new Manifestation();

			$this->setManifestation($manifestation);
		}
	}

	/**
	 * Populates the fields in the page in case that the
	 * manifestation already exists on database.
	 * And puts it in the private variable $this->_manifestation.
	 *
	 * @param TEventParameter $param
	 */
	public function onLoad($param)
	{
		parent::onLoad($param);

		$myUser = $this->getUser();
		$iAmAdmin = $myUser->getIsAdmin();
		$this->_manifestation = $this->getManifestation();

		$isSerial = $this->_manifestation->getBibLevel() == ManifestationPeer::LVL_SERIAL;
		$isMonography = $this->_manifestation->getBibLevel() == ManifestationPeer::LVL_MONOGRAPHIC;
		$hasIssues = ($this->_manifestation->countIssues() > 0);

		if (!$this->getIsPostBack() && !$this->getIsCallback())
		{
			$this->ItemList->setManifestation($this->_manifestation);
			$this->ItemList->setHomeLibraryId($this->getHomeLibraryId());

			if ($isSerial)
				$this->IssueList->setManifestation($this->_manifestation);

			$this->populate();
			$this->setFocus($this->UserBarcode);
		}

		if ($this->getIsPostBack() || $this->getIsCallback())
			$this->ItemList->populate();

		$this->LoanableSincePanel->setVisible($this->getManifestation()->getLoanableSince('U') - time() > 0);
	}

	public function onPreRender($param)
	{
		parent::onPreRender($param);

		$foundItemsCount = count($this->ItemList->getDataSource());
		$this->YesResult->setVisible($foundItemsCount);
		$this->NoResult->setVisible(!$foundItemsCount);
		$this->UtilityPanel->setVisible($foundItemsCount);
	}

	/**
 	 * Sets the manifestation object in the viewstate.
 	 *
 	 * @param BaseObject $man
 	 */
	public function setManifestation($man)
	{
		$this->_manifestation = $man;
		$this->setViewState('manifestation', $this->_manifestation, null);
	}

	/**
 	 * Gets the manifestation object from the viewstate, and puts it
 	 * in the relative page private variable.
 	 *
 	 * @return Manifestation
 	 */
	public function getManifestation()
	{
		if (($man = $this->_manifestation) == null)
		{
			$man = $this->getViewState('manifestation', null);
			$this->_manifestation = $man;
		}
		return $man;
	}

	public function getManifestationId()
	{
		$return = null;
		$manifestation = $this->getManifestation();
		if (!is_null($manifestation) && ($manifestation instanceof Manifestation ))
			$return = $manifestation->getManifestationId();
		return $return;
	}

	public function setReturnUrl($param)
	{
		$this->setViewState('returnUrl', $param, '');
	}

	public function getReturnUrl()
	{
		return $this->getViewState('returnUrl', '');
	}

	/**
 	 * If the page private variable "_manifestation" is not new
 	 * (already saved on database) it extracts its values and puts
 	 * them in the fields in the page.
 	 *
 	 */
	public function populate()
	{
		if ($this->_manifestation->isNew())
			return;

		$author = $this->_manifestation->getAuthor();
		$ean = $this->_manifestation->getEan();
		$isbn = $this->_manifestation->getIsbnissn();
		$abstract = $this->_manifestation->getAbstract();
		$notes = $this->_manifestation->getNotes();
		$cdf = $this->_manifestation->getCDFs();
		$languages = array();
		$tm = $this->_manifestation->getTurboMarc();

		$title = htmlentities($tm->getFullTitle(), ENT_COMPAT, 'UTF-8');
		$isbd = "<strong>$author<br />{$title}</strong><br />";

		foreach ($this->_manifestation->getLanguages() as $l)
			$languages[] = LookupValuePeer::getLookupValue('LANGUAGES',$l,0);

		$v = $tm->getEditions();
		if ($v)
			$isbd .= implode('<br />',$v).'<br />';
		foreach ($this->_manifestation->getAreas() as $area)
			$isbd .= ManifestationPeer::getAreaName($area['field']).': '.$area['value'].'<br />';
		$v = $tm->getPublications();
		if ($v)
			$isbd .= implode('<br />', $v).'<br />';
		$v = $tm->getPhysicalDescs();
		if ($v)
			$isbd .= implode('<br />', $v).'<br />';


		$isbd .= '<hr />';
		$year = $this->_manifestation->getYear();
		if ($year) {
			switch ($year['type']) {
				case 'j':
					$dt = new DateTime($year['date']);
					$date = Clavis::dateFormat($dt);
					break;
				default:
					$date = $year['date'];
					break;
			}
			$isbd .= '<br /><strong>'.ucfirst(UnimarcCodesPeer::getValueLabel(100,'a',8,$year['type'])).':</strong> '.$date;
		}
		if (count($languages)>0)
			$isbd .= '<br /><strong>'.Prado::localize('Lingua').':</strong> '.implode(', ',$languages);


		if ($target = trim($this->_manifestation->getTarget())) {
			$cur = 17;
			$labels = array();
			foreach (explode('-',$target) as $t) {
				if (!trim($t))
					break;
				$code = UnimarcCodesPeer::retrieveByPK($this->getApplication()->getGlobalization()->getCulture(),
					100,'a',$cur,$t,'U');
				if ($code instanceof UnimarcCodes)
					$labels[] = $code->getLabel();
				++$cur;
			}
			if (count($labels)>0) {
				$isbd .= '<br /><strong>'.Prado::localize('Destinatari: ').'</strong>'.
					implode('; ',$labels);
			}
		}
		$isbd .= '<br />';
		if ($ean)
			$isbd .= '<strong>'.Prado::localize('EAN').":</strong> $ean<br />";
		if ($isbn)
			$isbd .= '<strong>'.Prado::localize('ISBN/ISSN').":</strong> $isbn<br />";
		if ($series = $tm->getSeries())
			$isbd .= '<strong>'.Prado::localize('Collana').':</strong> '.
				implode('<br />',$series).'<br />';
		foreach ($notes as $note)
			$isbd .= '<strong>'.LookupValuePeer::getLookupValue('UNI3XX',$note['code'],0).
				":</strong> {$note['text']}<br />";
		if ($abstract)
			$isbd .= '<strong>'.Prado::localize('Abstract').":</strong> $abstract<br />";
		$titles = $this->_manifestation->getAltTitles();
		if (count($titles)>0) {
			$isbd .= '<strong>'.Prado::localize('Altri titoli:').'</strong><br />';
			foreach ($titles as $title) {
				$isbd .= '<em>'.LookupValuePeer::getLookupValue('UNI5XX', $title['field']).
					":</em> {$title['value']}<br />\n";
			}
		}
		$cnt = count($tm->d856);
		if ($cnt>0) {
			$isbd .= '<strong>'.Prado::localize('Risorse elettroniche:').'</strong><ul>';
			for ($i=0; $i<$cnt; ++$i) {
				$fld = $tm->d856[$i];
				$url = (string)$fld->su;
				$type = LookupValuePeer::getLookupValue('ELECTRONICSOURCE',$fld['i1'].$fld['i2']);
				$note = trim((string)$fld->sz);
				if ($note)
					$note = " ({$note})";
				$isbd .= "<li><em>{$type}</em>: <a href=\"{$url}\">{$url}{$note}</a></li>";
			}
			$isbd .= '</ul>';
		}

		$this->ISBD->setText($isbd);
		$this->CDFRepeater->setDataSource($cdf);
		$this->CDFRepeater->dataBind();

		/* POPULATE LINKS */
		$criteria = new Criteria();
		$criteria->add(LAuthorityManifestationPeer::LINK_TYPE, 700, Criteria::GREATER_EQUAL);
		$criteria->addAnd(LAuthorityManifestationPeer::LINK_TYPE, 799, Criteria::LESS_EQUAL);
		$authorAuthorities = $this->_manifestation->getLAuthorityManifestations($criteria);
		$criteria = new Criteria();
		$criteria->add(LAuthorityManifestationPeer::LINK_TYPE, 500, Criteria::EQUAL);
		$workAuthorities = $this->_manifestation->getLAuthorityManifestations($criteria);
		$criteria->clear();
		$criteria->add(LAuthorityManifestationPeer::LINK_TYPE, 620);
		$placeAuthorities = $this->_manifestation->getLAuthorityManifestations($criteria);
		$criteria->clear();
		$criteria->add(LAuthorityManifestationPeer::LINK_TYPE, 608);
		$formAuthorities = $this->_manifestation->getLAuthorityManifestations($criteria);
		$criteria->clear();
		$criteria->add(LAuthorityManifestationPeer::LINK_TYPE, 600, Criteria::GREATER_EQUAL);
		$criteria->addAnd(LAuthorityManifestationPeer::LINK_TYPE, 610, Criteria::LESS_EQUAL);
		$criteria->addAnd(LAuthorityManifestationPeer::LINK_TYPE, 608, Criteria::NOT_EQUAL);
		$subjectAuthorities = $this->_manifestation->getLAuthorityManifestations($criteria);
		$criteria->clear();
		$criteria->add(LAuthorityManifestationPeer::LINK_TYPE, 676);
		$classesAuthorities = $this->_manifestation->getLAuthorityManifestations($criteria);
		$criteria->clear();
		$criteria->add(LAuthorityManifestationPeer::LINK_TYPE, 921);
		$otherAuthorities = $this->_manifestation->getLAuthorityManifestations($criteria);
		$itemLinks = array();
		foreach ($this->_manifestation->getItems() as $i) {
			/** @var $i Item */
			foreach ($i->getLAuthorityItemsJoinAuthority() as $l) {
				$itemLinks[] = array(
					'ItemId'		=> $i->getItemId(),
					'ItemInventory'	=> $i->getCompleteInventoryNumber(),
					'AuthId'		=> $l->getAuthorityId(),
					'AuthFullText'	=> $l->getAuthority()->getFullText(),
					'RelatorCode'	=> $l->getRelatorCode()
				);
			}
		}

		$this->Authors->setDataSource($authorAuthorities);
		$this->Authors->dataBind();
		$this->Works->setDataSource($workAuthorities);
		$this->Works->dataBind();
		$this->Places->setDataSource($placeAuthorities);
		$this->Places->dataBind();
		$this->Forms->setDataSource($formAuthorities);
		$this->Forms->dataBind();
		$this->Subjects->setDataSource($subjectAuthorities);
		$this->Subjects->dataBind();
		$this->Classes->setDataSource($classesAuthorities);
		$this->Classes->dataBind();
		$this->OtherAuthorities->setDataSource($otherAuthorities);
		$this->OtherAuthorities->dataBind();
		$this->ItemLinks->setDataSource($itemLinks);
		$this->ItemLinks->dataBind();

		$criteria->clear();
		if ($this->_manifestation->getBibLevel() == ManifestationPeer::LVL_SERIAL)
			$criteria->add(LManifestationPeer::ISSUE_ID,null,Criteria::ISNULL);
		$criteria->addAscendingOrderByColumn(LManifestationPeer::LINK_TYPE);
		$criteria->addAscendingOrderByColumn(LManifestationPeer::LINK_SEQUENCE);
		$lManifestationsIdDown = $this->_manifestation->getLManifestationsRelatedByManifestationIdDown($criteria);
		$lManifestationsIdUp = $this->_manifestation->getLManifestationsRelatedByManifestationIdUp($criteria);
		$lManifestations = array();
		/* @var $row LManifestation */
		foreach ($lManifestationsIdDown as $row) {
			$id = intval($row->getManifestationIdUp());
			if ($id < 1)
				continue;
			$manifestation = ManifestationPeer::retrieveByPK($id);
			if (!($manifestation instanceof Manifestation))
				continue;
			$title = $manifestation->getTitle();
			$author = trim($manifestation->getAuthor());
			if ($author != '')
				$title = "{$author}. {$title}";
			$linkType = TurboMarcMappings::$reverseLinkType[$row->getLinkType()];
			$linkTypeString = LookupValuePeer::getLookupValue('UNI4XX', $linkType);
			$lManifestations[] = array(	'manifestationId' => $id,
										'manifestationTitle' => $title,
										'linkTypeString' => $linkTypeString );
		}

		foreach ($lManifestationsIdUp as $row) {
			$id = intval($row->getManifestationIdDown());
			if ($id < 1)
				continue;
			$manifestation = ManifestationPeer::retrieveByPK($id);
			if (!($manifestation instanceof Manifestation))
				continue;
			$title = $manifestation->getTitle();
			$author = trim($manifestation->getAuthor());
			if ($author != '')
				$title = "{$author}. {$title}";
			$linkType = $row->getLinkType();
			$linkTypeString = LookupValuePeer::getLookupValue('UNI4XX', $linkType);
			$lManifestations[] = array(	'manifestationId' => $id,
										'manifestationTitle' => $title,
										'linkTypeString' => $linkTypeString );
		}

		$this->LManifestations->setDataSource($lManifestations);
		$this->LManifestations->dataBind();
	}


	/**
 	 * Does this page have popups inside?.....
 	 *
 	 * @return boolean
 	 */
	public function isPopup()
	{
		return false;
	}


	/**
 	 * It refreshes all the components (grids) in the page,
 	 * altogether.
 	 *
 	 */
	public function globalRefresh()
	{
		$this->ItemList->populate();

		if ($this->_manifestation->getBibLevel() == ManifestationPeer::LVL_SERIAL)
			$this->IssueList->populate();

		$this->Requests->populate();
	}

	public function globalCancel($component)
	{

	}

	public function onItemReserve($sender, $param)
	{
		if (!$this->getIsValid())  // if validation control fails
			return false;

		$homeLibraryId = $this->getHomeLibraryId();
		$deliveryLibrary = LibraryPeer::retrieveByPK($homeLibraryId);
		$ids = $this->ItemList->getCheckedId(true);
		$barcode = trim($this->UserBarcode->getSafeText());
		$patrons = PatronPeer::retrieveByBarcode($barcode);
		$patron = $patrons[0];

		$requestNote = trim($this->RequestNote->getSafeText());
		if ($requestNote == '')
		{
			$requestNote = Prado::localize("Prenotazione guest, senza autenticazione");
			$message4 = '';
		}
		else
			$message4 = $requestNote;

		$ok = $failed = $itemString = array();
		foreach ($ids as $itemId)
		{
			$item = ItemPeer::retrieveByPK($itemId);
			if (!is_null($item))
			{
				if ($this->getApplication()->getModule('request')->reserveItem($item, $patron, $deliveryLibrary, 1, $requestNote))
				{
					$ok[] = $itemId;

					$newString = Prado::localize('id') . ": " . $item->getItemId() . ", ";
					$newString .= Prado::localize('collocazione.') . ": " . $item->getCollocationCombo($homeLibraryId) . ", ";
					$newString .= Prado::localize('inventario.') . ": " . $item->getCompleteInventoryNumber();
					$itemString[] = $newString;
				}
				else
					$failed[] = $itemId;
			}
			else
				$failed[] = $itemId;
		}

		// return message creation
		$message1 = Prado::localize("Sono stati prenotati {num} esemplari della seguente notizia", array('num' => count($ok))) . ":<br/><br/>";

		$message2 = $this->getManifestation()->getTrimmedTitle(150);

		$message3 = '';
		if (count($ok) > 0)
			$message3 .= Prado::localize("Esemplari: ") . "<br /><br />";
		foreach ($itemString as $rowString)
			$message3 .= $rowString . "<br />";

		$this->gotoExit(serialize(array($message1, $message2, $message3, $message4)));
	}

	public function checkBarcode($sender, $param)    // custom validation method
	{
		$barcode = trim($this->UserBarcode->getSafeText());
		if ($barcode == '')
		{
			$this->BarcodeValidator->setText(Prado::localize('il barcode è obbligatorio'));
			$param->isValid = false;
			return false;
		}

		$ids = $this->ItemList->getCheckedId(true);
		if (count($ids) == 0)
		{
			$this->BarcodeValidator->setText(Prado::localize('nessun esemplare è stato selezionato'));
			$param->isValid = false;
			return false;
		}

		$c = new Criteria();
		$c->add(PatronPeer::BARCODE,$barcode);

		$count = PatronPeer::doCount($c);
		if ($count == 0)
		{
			$this->BarcodeValidator->setText(Prado::localize('al barcode inserito non corrisponde nessun utente'));
			$param->isValid = false;
		}
		elseif ($count > 1)
		{
			$this->BarcodeValidator->setText(Prado::localize('il barcode inserito identifica più di un utente'));
			$param->isValid = false;
		}
		else
			$param->isValid = true;
	}

	public function getHomeLibraryId()
	{
		return 1;   // Biblioteca Ambrosiana
	}

	private function gotoExit($message = '')
	{
		$message = trim($message);
		$this->gotoPage("Guest.ExitAmbrosiana", array('message' => $message, 'manifestationId' => $this->getManifestationId()));
	}

	public function onExit($sender, $param)
	{
		$this->gotoExit(serialize(array(Prado::localize("Attenzione: nessun esemplare collegato alla notizia è disponibile"), '', '', '')));
	}

	public function onCancel($sender, $param)
	{
		$this->gotoExit(serialize(array(Prado::localize("Operazione annullata"), '', '', '')));
	}

}
