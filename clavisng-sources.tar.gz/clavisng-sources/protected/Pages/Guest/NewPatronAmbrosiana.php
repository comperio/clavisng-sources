<?php

/**
 * PatronPage Page class Module Circulation
 *
 * @author Dario Rigolin <drigolin@e-portaltech.it>
 * @author Max Pigozzi <mpigozzi@e-portaltech.it>
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.e-portaltech.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @license http://www.e-portaltech.it/license/
 */
class NewPatronAmbrosiana extends ClavisPage
{
	public $_module = 'GUEST';
	private $_patron = null;

	public function onInit($param)
	{
		parent::onInit($param);

		if (!$this->getIsPostBack())
		{
			$patron = new Patron();
			$this->setPatron($patron);
			$this->setIsNew(true);
		}
	}

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getIsPostBack() && !$this->getIsCallback())
		{
			$this->setAddAddress(false);
			$this->setAddContact(false);

			$this->populateForm();
			$this->dataBind();
		}

		$this->getPatron();
		/**
		 * Modifica di mbrancalion, 29-02-2008.
		 * Serve per l'apertura, con una sola riga in edit, di address e contact,
		 * nel caso siamo nell'inserimento di un nuovo patron.
		 */
		if (!$this->getIsPostBack() && !$this->getIsCallback() && $this->getIsNew())
		{
			$this->globalEditCancel();
			$newAddress = new Address();
			$this->AddressList->setDataSource(array($newAddress));
			$this->AddressList->SelectedItemIndex = -1;
			$this->AddressList->EditItemIndex = 0;
			$this->AddressList->dataBind();

			$newContact = new Contact();
			$this->ContactList->setDataSource(array($newContact));
			$this->ContactList->SelectedItemIndex = -1;
			$this->ContactList->EditItemIndex = 0;
			$this->ContactList->dataBind();

			$this->setFocus($this->Lastname->getClientId());
			//$this->UserFocus->setFocusComponent($this->Lastname);
		}
	}

	public function setIsNew($isNew)
	{
		$isNew = TPropertyValue::ensureBoolean($isNew);
		$this->setControlState("is_new", $isNew, false);
	}

	public function getIsNew()
	{
		return $this->getControlState("is_new", false);
	}

	public function setAddAddress($value)
	{
		$value = TPropertyValue::ensureBoolean($value);
		$this->setControlState("AddAddress", $value, false);
	}

	public function getAddAddress()
	{
		return $this->getControlState("AddAddress", false);
	}

	public function setAddContact($value)
	{
		$value = TPropertyValue::ensureBoolean($value);
		$this->setControlState("AddContact", $value, false);
	}

	public function getAddContact()
	{
		return $this->getControlState("AddContact", false);
	}

	public function setReadOnly($sender, $param)
	{
		$list = $this->Main->getControls();
		foreach ($list as $comp)
		{
			if ($comp instanceof TControl && $comp->canSetProperty('ReadOnly'))
				$comp->setReadOnly(true);
		}
	}

	public function patronSave($sender, $param)
	{
		if (!$this->getIsValid())
			return false;

		$this->_patron->setTitle($this->Title->getSelectedValue());

		$firstName = trim($this->Firstname->getSafeText());
		$lastName = trim($this->Lastname->getSafeText());
		$this->_patron->setName($firstName);
		$this->_patron->setLastname($lastName);

		$this->_patron->setPatronStatus(PatronPeer::STATUS_INCOMPLETE);

		$this->_patron->setGender($this->Sex->getSelectedValue());

		$this->_patron->setBirthDate($this->BirthDate->getData());

		$city = $this->BirthCity->getSafeText();
		if ($city == '')
			$city = null;
		$this->_patron->setBirthCity($city);

		$province = $this->BirthProvince->getSafeText();
		if ($province == '')
			$province = null;
		$this->_patron->setBirthProvince($province);

		$country = $this->BirthCountry->getSafeText();
		if ($country == '')
			$country = null;
		$this->_patron->setBirthCountry($country);

		$citizenship = $this->Citizenship->getSafeText();
		if ($citizenship == '')
			$citizenship = null;
		$this->_patron->setCitizenship($citizenship);
		$this->_patron->setPatronNote($this->PatronNote->getSafeText());
		$this->_patron->setPreferredLibraryId($this->getHomeLibraryId());  // ambrosiana, cablata
		$this->_patron->setRegistrationLibraryId($this->getHomeLibraryId()); // ambrosiana, cablata
		switch ($this->Custom2->getSelectedValue())
		{
			case 1:
				$customValue = Prado::localize('stampati');
				break;

			case 2:
				$customValue = Prado::localize('manoscritti e stampati');
				break;

			default:
				$customValue = '';
		}
		$this->_patron->setCustom2($customValue);

		$this->setPatron($this->_patron);

		try
		{
			$this->_patron->save();
		}
		catch (PropelException $exception)
		{
			$errorMessage = $exception->getCause()->getMessage();
			$dbClass = Propel::getDB();
			if ($dbClass instanceof DBMySQL)
			{
				$duplicateCase = strstr($errorMessage, 'Duplicate entry');
				if ($duplicateCase != false)
				{
					//$this->DuplicateBarcodePanel->setVisible(true);
					$this->writeMessage(Prado::localize("Il barcode utente '{barcode}' è già stato assegnato. Modificarlo.", array('barcode' => $barcode)), ClavisMessage::ERROR);
					$this->MainTab->setActiveViewID('AccessTab');
					return false;
				}
				else
					throw ($exception);
			}
			else
				throw ($exception);
		}

		ChangelogPeer::logAction($this->_patron, ChangelogPeer::LOG_CREATE, $this->getUser(), "aggiunto utente (" . $this->_patron->getCompleteName() . ")");
		$this->saveNewAddress();
		$this->saveNewContact();

		$patronId = $this->_patron->getPatronId();
		$this->gotoExit(serialize(array(Prado::localize("Inserimento nuovo utente con id: {id} conclusa. <br />L'utente sarà soggetto ad approvazione prima di potere utilizzare i servizi.", array('id' => $patronId)), '', '', '')));
	}

	public function populateForm()
	{

		if ($this->_patron === null)
			return;

		$this->Title->SelectedValue = $this->_patron->getTitle();
		$this->Lastname->Text = $this->_patron->getLastname();
		$this->Firstname->Text = $this->_patron->getName();

		if (($gender = $this->_patron->getGender()) != null)
			$this->Sex->SelectedValue = $gender;

		$this->BirthDate->setTimestamp($this->_patron->getBirthDate('U'));
		$this->BirthCity->Text = $this->_patron->getBirthCity();
		$this->BirthProvince->Text = $this->_patron->getBirthProvince();
		$this->BirthCountry->Text = $this->_patron->getBirthCountry();
		$this->Citizenship->Text = $this->_patron->getCitizenship();

		$this->PatronNote->Text = $this->_patron->getPatronNote();
		$this->getPatron()->reload(true);  // deep reload

		$addressData = $this->getPatron()->getAddresss();
		$this->AddressList->DataSource = $addressData;
		$this->AddressList->dataBind();

		$contactData = $this->getPatron()->getContacts();
		$this->ContactList->DataSource = $contactData;
		$this->ContactList->dataBind();
	}

	public function populateProperties()
	{
		$c = new Criteria();
		$c->add(PatronPropertyPeer::PATRON_ID, $this->getPatron()->getPatronId());
		$c->addAscendingOrderByColumn(PatronPropertyPeer::PROPERTY_CLASS);

		$properties = PatronPropertyPeer::doSelect($c);

		$arr = array();

		/* @var $property PatronProperty */
		foreach ($properties as $property)
		{
			$p = array();
			$p['PropertyLabel'] = LookupValuePeer::getLookupValue("PATRONPROPERTY", $property->getPropertyClass());
			$p['PropertyValue'] = $property->getPropertyValue();

			$p['id'] = $property->getId();

			$arr[] = $p;
		}

		//$this->ACLGrid->CurrentPageIndex = $this->getViewState("CurrentPage",0);
		$this->PropertyGrid->setDataSource($arr);
		$this->PropertyGrid->dataBind();
	}

	public function addressRepeaterDataBound($sender, $param)
	{
		$item = $param->Item;

		if ($item->ItemType == "EditItem")
		{

			$item->AddressType->populateList();
			$item->AddressType->SetSelectedValue($item->DataItem->getAddressType());

			$item->AddrStreetType->populateList();
			$item->AddrStreetType->SetSelectedValue($item->DataItem->getStreetType());
		}
	}

	public function addAddress($sender, $param)
	{

		$this->SaveButton->setEnabled(false);
		$this->globalEditCancel();
		$this->setAddAddress(true);

		if ($this->getPatron()->isNew())
		{
			if (!$this->patronSave(null, null))
			{
				$this->SaveButton->setEnabled(true);
				return;
			}
		}

		$address = new Address();
		$address->setPatron($this->getPatron());
		$address->save();
		$this->getPatron()->addAddress($address);
		$this->getPatron()->reload(true);   // deep reload
		ChangelogPeer::logAction($this->getPatron(), ChangelogPeer::LOG_UPDATE, $this->getUser(), "aggiunto indirizzo (id:" . $address->getAddressId() . ") - totale indirizzi:" . count($this->AddressList->getItems()));
		$this->refreshRepeaters();
		$this->AddressList->EditItemIndex = count($this->AddressList->getItems()) - 1;
		$this->AddressList->dataBind();
	}

	public function cancelAddress($sender, $param)
	{

		if ($this->getAddAddress())
		{
			$item = $param->Item;
			$itemIndex = $param->Item->ItemIndex;

			$addresses = $this->getPatron()->getAddresss();

			$addresses[$itemIndex]->delete();

			$this->getPatron()->reload(true);   // deep reload
		}
		$this->AddressList->SelectedItemIndex = -1;
		$this->AddressList->EditItemIndex = -1;
		$this->refreshRepeaters();

		$this->SaveButton->setEnabled(true);

		$this->setAddAddress(false);
		//$this->setViewState("add_contact", false);
	}

	public function editAddress($sender, $param)
	{

		//$this->setViewState("edit_address",true);

		$this->globalEditCancel();

		$this->AddressList->SelectedItemIndex = -1;
		$this->AddressList->EditItemIndex = $param->Item->ItemIndex;
		$this->refreshRepeaters();

		$this->SaveButton->setEnabled(false);
	}

	public function updateAddress($sender, $param)
	{
		$item = $param->Item;
		$itemIndex = $param->Item->ItemIndex;
		$addresses = $this->getPatron()->getAddresss();

		$this->doUpdateAddress($item, $itemIndex, $addresses);

		ChangelogPeer::logAction($this->getPatron(), ChangelogPeer::LOG_UPDATE, $this->getUser(), "aggiornato indirizzo (id:" . $addresses[$itemIndex]->getAddressId() . ")");
		$this->AddressList->SelectedItemIndex = -1;
		$this->AddressList->EditItemIndex = -1;
		$this->refreshRepeaters();
		$this->SaveButton->setEnabled(true);
		$this->setAddAddress(false);
	}

	public function saveNewAddress()
	{
		$items = $this->AddressList->getItems();
		$item = $items->itemAt(0);
		$patron = $this->getPatron();
		if (is_null($patron) || !($patron instanceof Patron))
		{
			$this->writeMessage(Prado::localize('Errore nell\'inserimento di un nuovo indirizzo'), ClavisMessage::ERROR);
			return false;
		}

		$addrStreet = trim($item->AddrStreet->getSafeText());
		if ($addrStreet != '')
		{
			$address = new Address();

			$address->setStreetType($item->AddrStreetType->getSelectedValue());
			$address->setStreet($addrStreet);
			$address->setAddressType($item->AddressType->getSelectedValue());
			$address->setStreetNum($item->AddrStreetNumber->getSafeText());
			$address->setVillage($item->AddrVillage->getSafeText());

			$addrCity = trim($item->AddrCity->getSafeText());
			if ($addrCity == '')
				$addrCity = null;
			$address->setCity($addrCity);

			$addrProvince = trim($item->AddrProvince->getSafeText());
			if ($addrProvince == '')
				$addrProvince = null;
			$address->setProvince($addrProvince);

			$addrCountry = trim($item->AddrCountry->getSafeText());
			if ($addrCountry == '')
				$addrCountry = null;
			$address->setCountry($addrCountry);

			$addrZip = trim($item->AddrZip->getSafeText());
			if ($addrZip == '')
				$addrZip = null;
			$address->setZip($addrZip);

			$address->setAddressNote($item->AddrNote->getSafeText());
			$address->setAddressPref($item->AddrPref->getChecked());

			$address->setPatronId($patron->getPatronId());
			$address->save();
			ChangelogPeer::logAction($this->getPatron(), ChangelogPeer::LOG_CREATE, $this->getUser(), "aggiunto indirizzo (id:" . $address->getAddressId() . ")");
		}
	}

	private function doUpdateAddress($item, $itemIndex, $addresses)
	{
		$addresses[$itemIndex]->setStreetType($item->AddrStreetType->getSelectedValue());
		$addresses[$itemIndex]->setStreet($item->AddrStreet->getSafeText());
		$addresses[$itemIndex]->setAddressType($item->AddressType->getSelectedValue());
		$addresses[$itemIndex]->setStreetNum($item->AddrStreetNumber->getSafeText());
		$addresses[$itemIndex]->setVillage($item->AddrVillage->getSafeText());

		$addrCity = $item->AddrCity->getSafeText();
		if ($addrCity == '')
			$addrCity = null;
		$addresses[$itemIndex]->setCity($addrCity);

		$addrProvince = $item->AddrProvince->getSafeText();
		if ($addrProvince == '')
			$addrProvince = null;
		$addresses[$itemIndex]->setProvince($addrProvince);

		$addrCountry = $item->AddrCountry->getSafeText();
		if ($addrCountry == '')
			$addrCountry = null;
		$addresses[$itemIndex]->setCountry($addrCountry);

		$addrZip = $item->AddrZip->getSafeText();
		if ($addrZip == '')
			$addrZip = null;
		$addresses[$itemIndex]->setZip($addrZip);

		$addresses[$itemIndex]->setAddressNote($item->AddrNote->getSafeText());

		if ($item->AddrPref->getChecked())
		{
			for ($i = 0; $i < count($addresses); $i++)
			{
				$addresses[$i]->setAddressPref(false);
				$addresses[$i]->save();
			}
			$addresses[$itemIndex]->setAddressPref(true);
		}
		else
			$addresses[$itemIndex]->setAddressPref(false);

		$addresses[$itemIndex]->save();
	}

	public function deleteAddress($sender, $param)
	{

		$dataSource = $this->getPatron()->getAddresss();
		$addressId = $param->getCommandParameter();

		$newDataSource = array();
		foreach ($dataSource as $address)
		{
			if ($address->getAddressId() != $addressId)
			{
				$newDataSource[] = $address;
			}
			else
			{
				$address->delete();

				ChangelogPeer::logAction($this->getPatron(), ChangelogPeer::LOG_UPDATE, $this->getUser(), "rimosso indirizzo (id:" . $addressId . ") - totale indirizzi:" . count($this->AddressList->getItems()));
			}
		}


		$this->getPatron()->reload(true);   // deep reload

		$id = intval($this->Request['id']);
		if ($id > 0)
		{
			$patron = PatronPeer::retrieveByPK($id);
			if ($patron != null)
				$this->setPatron($patron);
		}

		$this->AddressList->SelectedItemIndex = -1;
		$this->AddressList->EditItemIndex = -1;

		$this->refreshRepeaters();

		$this->setAddAddress(false);
	}

	public function addContact($sender, $param)
	{

		$this->SaveButton->setEnabled(false);

		$this->globalEditCancel();

		$this->setAddContact(true);

		if ($this->getPatron()->isNew())
		{
			if (!$this->patronSave(null, null))
			{
				$this->SaveButton->setEnabled(true);
				return;
			}
		}

		$contact = new Contact();
		$contact->setPatron($this->getPatron());
		$contact->save();

		$this->getPatron()->addContact($contact);

		ChangelogPeer::logAction($this->getPatron(), ChangelogPeer::LOG_UPDATE, $this->getUser(), "aggiunto contatto (id:" . $contact->getContactId() . ") - totale contatti:" . count($this->ContactList->getItems()));

		$this->refreshRepeaters();

		$this->ContactList->EditItemIndex = count($this->ContactList->getDataSource()) - 1;

		$this->ContactList->dataBind();
	}

	public function editContact($sender, $param)
	{

		$this->globalEditCancel();

		$this->ContactList->SelectedItemIndex = -1;
		$this->ContactList->EditItemIndex = $param->Item->ItemIndex;
		$this->refreshRepeaters();

		$this->SaveButton->setEnabled(false);
	}

	public function deleteContact($sender, $param)
	{

		$dataSource = $this->getPatron()->getContacts();

		$contactId = $param->getCommandParameter();

		$newDataSource = array();
		foreach ($dataSource as $contact)
		{
			if ($contact->getContactId() != $contactId)
			{
				$newDataSource[] = $contact;
			}
			else
			{
				ChangelogPeer::logAction($this->getPatron(), ChangelogPeer::LOG_DELETE, $this->getUser(), "rimosso contatto (id:" . $contact->getContactId() . ") - totale contatti:" . count($this->ContactList->getItems()));

				$contact->delete();
			}
		}

		$this->getPatron()->reload(true);  // deep reload

		$id = intval($this->Request['id']);
		if ($id > 0)
		{

			$patron = PatronPeer::retrieveByPK($id);
			if ($patron != null)
				$this->setPatron($patron);
		}

		$this->ContactList->SelectedItemIndex = -1;
		$this->ContactList->EditItemIndex = -1;

		$this->refreshRepeaters();

		$this->setAddContact(false);
	}

	public function cancelContact($sender, $param)
	{
		if ($this->getAddContact())
		{
			$item = $param->Item;
			$itemIndex = $param->Item->ItemIndex;

			$contacts = $this->getPatron()->getContacts();

			$contacts[$itemIndex]->delete();

			$this->getPatron()->reload(true);   // deep reload
		}

		$this->ContactList->SelectedItemIndex = -1;
		$this->ContactList->EditItemIndex = -1;
		$this->refreshRepeaters();

		$this->SaveButton->setEnabled(true);

		$this->setAddContact(false);
	}

	public function contactRepeaterDataBound($sender, $param)
	{
		$item = $param->Item;

		if ($item->ItemType == "EditItem")
		{

			$item->ContactType->populateList();
			$item->ContactType->SetSelectedValue($item->DataItem->getContactType());
		}
	}

	public function updateContact($sender, $param)
	{
		$item = $param->Item;
		$itemIndex = $param->Item->ItemIndex;
		$contacts = $this->getPatron()->getContacts();

		$this->doUpdateContact($item, $itemIndex, $contacts);

		ChangelogPeer::logAction($this->getPatron(), ChangelogPeer::LOG_UPDATE, $this->getUser(), "aggiornato contatto (id:" . $contacts[$itemIndex]->getContactId() . ")");
		$this->ContactList->SelectedItemIndex = -1;
		$this->ContactList->EditItemIndex = -1;
		$this->refreshRepeaters();

		$this->SaveButton->setEnabled(true);
		$this->setAddContact(false);
	}

	public function saveNewContact()
	{
		$items = $this->ContactList->getItems();
		$item = $items->itemAt(0);
		$patron = $this->getPatron();
		if (is_null($patron) || !($patron instanceof Patron))
		{
//Prado::log('error', 'errore di inserimento nuovo contact');
			return false;
		}

		$contactValue = trim($item->ContactValue->getSafeText());
		if ($contactValue != '')
		{
			$contact = new Contact();
			$contact->setContactType($item->ContactType->getSelectedValue());
			$contact->setContactValue($contactValue);
			$contact->setContactNote($item->EditContactNote->getSafeText());
			$contact->setContactPref($item->ContactPref->getChecked());

			$contact->setPatronId($patron->getPatronId());
			$contact->save();
			ChangelogPeer::logAction($this->getPatron(), ChangelogPeer::LOG_CREATE, $this->getUser(), "aggiunto contatto (id:" . $contact->getContactId() . ")");
		}
	}

	private function doUpdateContact($item, $itemIndex, $contacts)
	{
		$contacts[$itemIndex]->setContactType($item->ContactType->getSelectedValue());
		$contacts[$itemIndex]->setContactValue($item->ContactValue->getSafeText());
		$contacts[$itemIndex]->setContactNote($item->EditContactNote->getSafeText());

		if ($item->ContactPref->getChecked())
		{
			for ($i = 0; $i < count($contacts); $i++)
			{
				$contacts[$i]->setContactPref(false);
				$contacts[$i]->save();
			}
			$contacts[$itemIndex]->setContactPref(true);
		}
		else
			$contacts[$itemIndex]->setContactPref(false);

		$contacts[$itemIndex]->save();
	}

	private function refreshRepeaters()
	{

		$this->ContactList->setDataSource($this->getPatron()->getContacts());
		$this->ContactList->dataBind();

		$this->AddressList->setDataSource($this->getPatron()->getAddresss());
		$this->AddressList->dataBind();
	}

	private function setAddressSuggestion($ds = array())
	{
		$this->getApplication()->getSession()->add('PatronBirthCityDataSource', $ds, array());
	}

	private function getAddressSuggestion()
	{
		return $this->getApplication()->getSession()->itemAt('PatronBirthCityDataSource', array());
	}

	private function setPatronCitizenshipSuggestions($ds = array())
	{
		$this->getApplication()->getSession()->add('PatronCitizenshipDataSource', $ds, array());
	}

	private function getPatronCitizenshipSuggestions()
	{
		return $this->getApplication()->getSession()->itemAt('PatronCitizenshipDataSource', array());
	}

	public function suggestBirthCity($sender, $param)
	{
		$token = $param->getCallbackParameter();

		$ds = PatronPeer::doSuggestAddress($token, PatronPeer::BIRTH_CITY);
//var_dump($ds);die;
		if (count($ds) > 0)
		{
			$sender->setDataSource($ds);
			$sender->dataBind();
			$this->setAddressSuggestion($ds);
		}
	}

	public function selectBirthCity($sender, $param)
	{
		$index = $param->selectedIndex;
		$sender->setText('');

		$ds = $this->getAddressSuggestion();
		$this->setAddressSuggestion(array());

		if (array_key_exists($index, $ds))
		{
			$row = $ds[$index];
			$array = $row['array'];
			$city = trim($array[0]);
			$province = trim($array[1]);
			$country = trim($array[2]);

			if ($city != '')
				$this->BirthCity->setText($city);

			if ($province != '')
				$this->BirthProvince->setText($province);

			if ($country != '')
				$this->BirthCountry->setText($country);
		}
	}

	public function suggestBirthProvince($sender, $param)
	{
		$token = $param->getCallbackParameter();

		$ds = PatronPeer::doSuggestAddress($token, PatronPeer::BIRTH_PROVINCE);
		if (count($ds) > 0)
		{
			$sender->setDataSource($ds);
			$sender->dataBind();
			$this->setAddressSuggestion($ds);
		}
	}

	public function selectBirthProvince($sender, $param)
	{
		$index = $param->selectedIndex;
		$sender->setText('');

		$ds = $this->getAddressSuggestion();
		$this->setAddressSuggestion(array());

		if (array_key_exists($index, $ds))
		{
			$row = $ds[$index];

			$array = $row['array'];
			$province = trim($array[0]);
			$country = trim($array[1]);

			if ($province != '')
				$this->BirthProvince->setText($province);

			if ($country != '')
				$this->BirthCountry->setText($country);
		}
	}

	public function suggestBirthCountry($sender, $param)
	{
		$token = $param->getCallbackParameter();

		$ds = PatronPeer::doSuggestAddress($token, PatronPeer::BIRTH_COUNTRY);
		if (count($ds) > 0)
		{
			$sender->setDataSource($ds);
			$sender->dataBind();
			$this->setAddressSuggestion($ds);
		}
	}

	public function selectBirthCountry($sender, $param)
	{
		$index = $param->selectedIndex;
		$sender->setText('');

		$ds = $this->getAddressSuggestion();
		$this->setAddressSuggestion(array());

		if (array_key_exists($index, $ds))
		{
			$row = $ds[$index];

			$array = $row['array'];
			$country = trim($array[0]);

			if ($country != '')
				$this->BirthCountry->setText($country);
		}
	}

	public function suggestCitizenship($sender, $param)
	{
		$token = $param->getCallbackParameter();

		$ds = PatronPeer::doSuggestCitizenship($token);
		if (count($ds) > 0)
		{
			$sender->setDataSource($ds);
			$sender->dataBind();
			$this->setPatronCitizenshipSuggestions($ds);
		}
	}

	public function selectCitizenship($sender, $param)
	{
		$index = $param->selectedIndex;
		$sender->setText('');

		$ds = $this->getPatronCitizenshipSuggestions();
		$this->setPatronCitizenshipSuggestions(array());

		if (array_key_exists($index, $ds))
		{
			$row = $ds[$index];
			$czs = trim($row['text']);

			if ($czs != '')
				$this->Citizenship->setText($czs);
		}
	}

	public function suggestCity($sender, $param)
	{
		$text = $sender->getText();
		$token = $param->getCallbackParameter();
		$ds = PatronPeer::doSuggestAddress($token, AddressPeer::CITY);

		if (count($ds) > 0)
		{
			$sender->setDataSource($ds);
			$sender->dataBind();
			$this->setAddressSuggestion($ds);
			$sender->setText($text);
		}
	}

	public function selectCity($sender, $param)
	{
		$itemIndex = $sender->Parent->getItemIndex();
		$items = $this->AddressList->getItems();
		$item = $items->itemAt($itemIndex);

		$index = $param->selectedIndex;
		$sender->setText('');

		$ds = $this->getAddressSuggestion();
		$this->setAddressSuggestion(array());

		if (array_key_exists($index, $ds))
		{
			$row = $ds[$index];
			$array = $row['array'];

			$city = trim($array[0]);
			$zip = trim($array[1]);
			$province = trim($array[2]);
			$country = trim($array[3]);

			if ($city != '')
				$item->AddrCity->setText($city);

			if ($zip != '')
				$item->AddrZip->setText($zip);

			if ($province != '')
				$item->AddrProvince->setText($province);

			if ($country != '')
				$item->AddrCountry->setText($country);
		}
	}

	public function suggestZip($sender, $param)
	{
		$text = $sender->getText();
		$token = $param->getCallbackParameter();
		$ds = PatronPeer::doSuggestAddress($token, AddressPeer::ZIP);

		if (count($ds) > 0)
		{
			$sender->setDataSource($ds);
			$sender->dataBind();
			$this->setAddressSuggestion($ds);
			$sender->setText($text);
		}
	}

	public function selectZip($sender, $param)
	{
		$itemIndex = $sender->Parent->getItemIndex();
		$items = $this->AddressList->getItems();
		$item = $items->itemAt($itemIndex);

		$index = $param->selectedIndex;
		$sender->setText('');

		$ds = $this->getAddressSuggestion();
		$this->setAddressSuggestion(array());

		if (array_key_exists($index, $ds))
		{
			$row = $ds[$index];
			$array = $row['array'];

			$zip = trim($array[0]);
			$province = trim($array[1]);
			$country = trim($array[2]);

			if ($zip != '')
				$item->AddrZip->setText($zip);

			if ($province != '')
				$item->AddrProvince->setText($province);

			if ($country != '')
				$item->AddrCountry->setText($country);
		}
	}

	public function suggestProvince($sender, $param)
	{
		$text = $sender->getText();
		$token = $param->getCallbackParameter();
		$ds = PatronPeer::doSuggestAddress($token, AddressPeer::PROVINCE);

		if (count($ds) > 0)
		{
			$sender->setDataSource($ds);
			$sender->dataBind();
			$this->setAddressSuggestion($ds);
			$sender->setText($text);
		}
	}

	public function selectProvince($sender, $param)
	{
		$itemIndex = $sender->Parent->getItemIndex();
		$items = $this->AddressList->getItems();
		$item = $items->itemAt($itemIndex);

		$index = $param->selectedIndex;
		$sender->setText('');

		$ds = $this->getAddressSuggestion();
		$this->setAddressSuggestion(array());

		if (array_key_exists($index, $ds))
		{
			$row = $ds[$index];
			$array = $row['array'];

			$province = trim($array[0]);
			$country = trim($array[1]);

			if ($province != '')
				$item->AddrProvince->setText($province);

			if ($country != '')
				$item->AddrCountry->setText($country);
		}
	}

	public function suggestCountry($sender, $param)
	{
		$text = $sender->getText();
		$token = $param->getCallbackParameter();
		$ds = PatronPeer::doSuggestAddress($token, AddressPeer::COUNTRY);

		if (count($ds) > 0)
		{
			$sender->setDataSource($ds);
			$sender->dataBind();
			$this->setAddressSuggestion($ds);
			$sender->setText($text);
		}
	}

	public function selectCountry($sender, $param)
	{
		$itemIndex = $sender->Parent->getItemIndex();
		$items = $this->AddressList->getItems();
		$item = $items->itemAt($itemIndex);

		$index = $param->selectedIndex;
		$sender->setText('');

		$ds = $this->getAddressSuggestion();
		$this->setAddressSuggestion(array());

		if (array_key_exists($index, $ds))
		{
			$row = $ds[$index];
			$array = $row['array'];

			$country = trim($array[0]);

			if ($country != '')
				$item->AddrCountry->setText($country);
		}
	}

	public function suggestDocumentEmitter($sender, $param)
	{
		$token = $param->getCallbackParameter();
		$sql = 'SELECT DISTINCT ' . PatronPeer::DOCUMENT_EMITTER . ' FROM ' . PatronPeer::TABLE_NAME . '
			WHERE ' . PatronPeer::DOCUMENT_EMITTER . ' LIKE \'' . $token . '%\' ORDER BY ' . PatronPeer::DOCUMENT_EMITTER;
		$stmt = Propel::getConnection()->query($sql);
		$ds = $stmt->fetchAll(PDO::FETCH_COLUMN, 0);
		$sender->setDataSource($ds);
		$sender->dataBind();
	}

	public function setPatron(Patron $patron)
	{
		$this->_patron = $patron;
		$this->setViewState("patron", $patron, null);
	}

	public function getPatron()
	{
		if (is_null($this->_patron))
		{
			$this->_patron = $this->getViewState("patron", null);
		}
		return $this->_patron;
	}

	private function VerifyPassword($password, $confirm)
	{
		if ((is_null($password)) || (is_null($confirm)))
			return false;
		if ($password === $confirm)
			return true;
		else
			return false;
	}

	public function changePassword($sender, $param)
	{
		$bChanged = false;
		$password = $this->Password->getSafeText();
		$confirm = $this->Confirm->getSafeText();

		if ($this->_patron != null)
			$this->setPatron($this->_patron);

		$patron = $this->getPatron();

		//manage password...
		if ($password != '')
		{
			if ($password !== $confirm)
			{
				$this->writeMessage(Prado::localize("La password e la sua verifica non coincidono"), ClavisMessage::ERROR);
				$this->refreshRepeaters();
				return;
			}

			if (strlen($password) < 1)
			{
				$this->writeMessage(Prado::localize("La password è troppo corta"), ClavisMessage::ERROR);
				$this->refreshRepeaters();
				return;
			}

			/* load ClavisCrypt module and directly set new password via setOpacSecret */
			$cryptmod = $this->getApplication()->getModule('crypt');
			$patron->setOpacSecret($cryptmod->PatronEncrypt($password));

			$bChanged = true;
		}
		//manage username...
		$userName = $this->Nickname->getSafeText();

		if ($userName != '')
		{
			if ($patron->getOpacUsername() != $userName)
			{
				$criteria = new Criteria();

				$criteria->add(PatronPeer::OPAC_USERNAME, $userName);

				if (PatronPeer::doCount($criteria) != 0)
				{

					$this->writeMessage(Prado::localize("Username OPAC già esistente"), ClavisMessage::ERROR);
					$this->Nickname->setText($patron->getOpacUsername());
					$this->refreshRepeaters();
					return;
				}
			}

			$patron->setOpacUsername($userName);

			$bChanged = true;
		}

		if ($bChanged)
		{

			$patron->save();
			ChangelogPeer::logAction($patron, ChangelogPeer::LOG_UPDATE, $this->getUser(), "cambiati username/password OPAC");
			$this->setPatron($patron);

			$this->writeMessage(Prado::localize("Username e/o password cambiati correttamente"), ClavisMessage::INFO);
			$this->gotoPage("Circulation.PatronPage", array("id" => $this->_patron->getPatronId()));
		}
	}

	public function globalEditCancel()
	{
		$this->AddressList->SelectedItemIndex = -1;
		$this->AddressList->EditItemIndex = -1;
		$this->AddressList->dataBind();

		$this->ContactList->SelectedItemIndex = -1;
		$this->ContactList->EditItemIndex = -1;
		$this->ContactList->dataBind();
	}

	protected function onChangeImage($sender, $param)
	{

		//if($this->getPatron()->isNew()) $this->patronSave(null,null);
	}

	public function getPhotoPopupUrl()
	{

		$patron_id = -1;

		$this->getPatron();

		if ($this->_patron->isNew())
		{
			$this->Photo->Enabled = false;
			return;
		}

		if ($this->_patron != null)
		{
			$patron_id = $this->_patron->getPatronId();
		}

		$popup_url = "Circulation.PatronChooseImagePopup";

		if ($patron_id != -1)
		{
			$popup_url .= "&patronId=" . $patron_id;
		}

		return $popup_url;
	}

	public function checkBarcodeDuplicate($sender, $param)
	{
		$barcode = trim($this->Barcode->getSafeText());
		$c = new Criteria();
		$c->add(PatronPeer::BARCODE, $barcode);
		if (!$this->getIsNew())
			$c->add(PatronPeer::PATRON_ID, $this->_patron->getPatronId(), Criteria::NOT_EQUAL);
		$cnt = PatronPeer::doCount($c);
		if ($cnt > 0)
		{
			$this->writeMessage(Prado::localize("Il codice a barre specificato è già assegnato ad un altro utente."), ClavisMessage::ERROR);
			$param->isValid = false;
		}
	}

	public function onCheckLastname($sender, $param)
	{
		$lastname = trim($this->Lastname->getSafeText());

		if ($lastname == '')
		{
			$this->writeMessage(Prado::localize("Il campo COGNOME non può essere vuoto"), ClavisMessage::ERROR);
			$param->isValid = false;
		}
	}

	public function onCheckPassword($sender, $param)
	{
		$password = trim($this->Password->getSafeText());
		$confirm = trim($this->Confirm->getSafeText());

		if ($password != '')
		{
			if ($password !== $confirm)
			{
				$this->writeMessage(Prado::localize("La password e la sua conferma non coincidono"), ClavisMessage::ERROR);
				//$this->refreshRepeaters();
				$param->isValid = false;
				return;
			}

			if (strlen($password) < 1)
			{
				$this->writeMessage(Prado::localize("La password è troppo corta"), ClavisMessage::ERROR);
				//$this->refreshRepeaters();
				$param->isValid = false;
				return;
			}
		}
		// se fallisce $param->isValid = false;
	}

	public function onCheckNickname($sender, $param)
	{
		$userName = trim($this->Nickname->getSafeText());
		if ($userName != '')
		{
			$criteria = new Criteria();
			$criteria->add(PatronPeer::OPAC_USERNAME, $userName);
			if (!$this->getIsNew())
			{
				$patronId = null;
				$patron = $this->getPatron();
				if ($patron instanceof Patron)
					$patronId = $patron->getPatronId();
				if (intval($patronId) > 0)
					$criteria->addAnd(PatronPeer::PATRON_ID, $patronId, Criteria::NOT_EQUAL);
			}
			if (PatronPeer::doCount($criteria) > 0)
			{
				$this->Nickname->setText($patron->getOpacUsername());
				//$this->refreshRepeaters();
				$param->isValid = false;
			}
		}
	}

	public function onBlipBarcode($sender, $param)
	{
		$this->setFocus($this->Rfidcode->getClientID());
	}

	public function onBlipNickname($sender, $param)
	{
		$this->setFocus($this->Password->getClientID());
	}

	public function getHomeLibraryId()
	{
		return 1;   // Biblioteca Ambrosiana
	}

	private function gotoExit($message = '')
	{
		$message = trim($message);
		$this->gotoPage("Guest.ExitAmbrosiana", array('message' => $message, 'gotopage' => $this->getUrlPath()));
	}

	public function onCancel($sender, $param)
	{
		$this->gotoExit(serialize(array(Prado::localize("Operazione annullata"), '', '', '')));
	}

	public function onValidateLastname($sender, $param)
	{
		$lastname = trim($this->Lastname->getSafeText());
		if ($lastname == '')
			$param->isValid = false;
		else
			$param->isValid = true;
	}
}