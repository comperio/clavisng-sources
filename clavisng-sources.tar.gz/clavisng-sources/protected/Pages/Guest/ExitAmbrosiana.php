<?php

/**
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2008 ePortal Technologies
 * @copyright Copyright &copy; 2009 Comperio srl
 *
 * It inserts and views single manifestations.
 */

class ExitAmbrosiana extends ClavisPage
{
	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallback())
		{
			$this->setManifestationId(intval($this->getRequest()->itemAt('manifestationId')));
			$this->setMessage($this->getRequest()->itemAt('message'));
			$gotopage = $this->getRequest()->itemAt('gotopage');
			if ($gotopage == '')
			{
				$this->ReturnLink->setNavigateUrl($this->getReturnUrl($this->getManifestationId()));
				$this->ReturnLink->setText(Prado::localize("Torna all'Opac"));
			}
			else
			{
				$this->ReturnLink->setNavigateUrl($gotopage);
				$this->ReturnLink->setText(Prado::localize("Torna all'inserimento utenti"));
			}

			$this->populate();
		}
	}

	public function populate()
	{
		$message = trim($this->getMessage());
		if ($message != '')
		{
			list ($message1, $message2, $message3, $message4) = unserialize($message);

			$this->Message1->setText($message1);

			$this->Message2->setText($message2);
			$this->Message2->setVisible(trim($message2) != '');

			$this->Message3->setText($message3);

			if ($message4 != '')
			{
				$this->NotePanel->setVisible(true);
				$this->Message4->setText($message4);
			}
			else
				$this->NotePanel->setVisible(false);
		}
	}

	public function setManifestationId($param)
	{
		$this->setViewState('manifestationId', $param, null);
	}

	public function getManifestationId()
	{
		return $this->getViewState('manifestationId', null);
	}

	public function setMessage($param)
	{
		$this->setViewState('message', $param, '');
	}

	public function getMessage()
	{
		return $this->getViewState('message', '');
	}

//	public function setGotopage($param)
//	{
//		$param = TPropertyValue::ensureString($param);
//		$this->setViewState('gotopage', $param, '');
//	}
//
//	public function getGotopage()
//	{
//		return $this->getViewState('gotopage', '');
//	}

	/**
 	 * Does this page have popups inside?.....
 	 *
 	 * @return boolean
 	 */
	public function isPopup()
	{
		return false;
	}

	private function getReturnUrl($param)
	{
		if ($param > 0)
			$queue = "viewdetail.php?bid=" . $param;
		else
			$queue = "";

		return "http://ambrosiana.comperio.it/opac/" . $queue;
	}

	public function onReturn($sender, $param)
	{

	}
}
