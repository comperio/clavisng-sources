<?php
/**
 * Created by PhpStorm.
 * User: dario
 * Date: 18/06/2014
 * Time: 18:09
 */

class UseTicket extends ClavisPage
{

    public function changeTicketCode($sender, $param)
    {
        $ticket_id = $sender->getText();
        $dbh = Propel::getConnection();

        $ticket = $dbh->query("SELECT * FROM _tickets WHERE ticket_id = " . $dbh->quote($ticket_id))->fetch(PDO::FETCH_ASSOC);
        if(isset($ticket['ticket_id'])) {
            if(isset($ticket['patron_id']))
            {
                $sender->setText("");
                $this->TicketMsg->setText("Errore ticket già usato da patron_id: {$ticket['patron_id']}");
                $sender->focus();
            } else {
                $this->PatronBarcode->setEnabled(true);
                $this->PatronBarcode->focus();
                $this->TicketMsg->setText("Ticket valido!");
                $this->setViewState("ticket_id",$ticket_id);
            }

        } else {
            $sender->setText("");
            $this->TicketMsg->setText("Errore ticket inesistente");
            $sender->focus();
        }
    }

    public function changePatronBarcode($sender, $param)
    {
        $patron = PatronQuery::create()
            ->findOneByBarcode($this->PatronBarcode->getText());

        if($patron == null)
            $patron = PatronQuery::create()
                ->findOneByPatronId($this->PatronBarcode->getText());

        if($patron instanceof Patron)
        {
            $this->PatronMsg->setText("Utente: " . $patron->getCompleteName());
            $this->UseIt->setEnabled(true);
            $this->setViewState("patron_id",$patron->getPatronId());

        } else {
            $this->PatronMsg->setText("Impossibile trovare utente");
        }

    }

    public function useTicketClick($sender, $param)
    {
        $pdo = Propel::getConnection();
        $patron_id = $this->getViewState("patron_id");
        $ticket_id = $this->getViewState("ticket_id");

        $payment_type = $this->PaymentType->getSelectedValue();


        $librarian_id = $this->getUser()->getId();
        $library_id = $this->getUser()->getActualLibraryId();

        $pdo->query("UPDATE patron SET loan_class='$', card_expire=DATE_ADD(current_date(),INTERVAL 1 YEAR) WHERE patron_id = $patron_id");
        $pdo->query("UPDATE _tickets 
                SET patron_id = $patron_id, 
                    date_used = current_timestamp(), 
                    used_by={$librarian_id},
                    payment_type=". $pdo->quote($payment_type) . "
                WHERE ticket_id = " . $pdo->quote($ticket_id));

        $pdo->query("INSERT INTO patron_wallet (`wallet_id`, `patron_id`, `library_id`, `wallet_action`, `wallet_type`, `wallet_status`, `amount`, `wallet_note`, `date_closed`, `receipt_id`, `date_created`, `date_updated`, `created_by`, `modified_by`) VALUES (NULL, '$patron_id', '{$library_id}', 'D', 'A', 'B', '10.0', 'Pagato con ticket sostenitore codice: {$ticket_id}', CURDATE(), NULL, CURDATE(), CURDATE(), '{$librarian_id}', '{$$librarian_id}');");

        $this->StatusMsg->setText("Ticket caricato con successo");

        $this->UseIt->setEnabled(false);
        $this->PatronMsg->setText("...");
        $this->TicketMsg->setText("...");
        $this->PatronBarcode->setText("");
        $this->PatronBarcode->setEnabled(false);
        $this->TicketCode->setText("");
        $this->TicketCode->focus();

    }
}