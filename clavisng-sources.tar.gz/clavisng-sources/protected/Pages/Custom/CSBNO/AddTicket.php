<?php

/**
 * Home class
 *
 * @author Dario Rigolin <dario@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @version 2.7
 * @package Pages.Circulation
 * @since 2.0
 */

class AddTicket extends ClavisPage {

    public $_module = 'CUSTOM';

    public function onLoad($param)
    {
        if(!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallback() )
        {
            $this->loadResellerList();
            $this->loadTicketGrid();
        }

    }

    public function loadResellerList()
    {
        $dbh = Propel::getConnection();

        $resellers = $dbh->query("SELECT seller_id, name FROM _ticketseller ORDER by name")->fetchAll(PDO::FETCH_ASSOC);
        $this->SellerID->setDataSource($resellers);
        $this->SellerID->dataBind();
    }

    public function loadTicketGrid()
    {
        $dbh = Propel::getConnection();

        $ticketData = $dbh->query("SELECT * FROM _tickets t JOIN _ticketseller s ON t.reseller = s.seller_id ORDER BY t.date_created DESC,t.ticket_id DESC LIMIT 200")->fetchAll(PDO::FETCH_ASSOC);
        $this->TicketList->setDataSource($ticketData);
        $this->TicketList->dataBind();
    }

    public function createTicketList($sender, $param)
    {
        $reseller_id = intval($this->SellerID->getSelectedValue());
        $firstTicketId = $this->FirstCode->getSafeText();
        $lastTicketId = $this->LastCode->getSafeText();
        $totTickets = intval(substr($lastTicketId,0,12)) - intval(substr($firstTicketId,0,12)) + 1;
        $firstNum = intval(substr($firstTicketId,0,12));
        $lastNum = intval(substr($lastTicketId,0,12));
        $toDelete = $this->DeleteTicket->getChecked();

        $amount = floatval(substr($firstTicketId,1,4)) / 10.0;

        if((strlen($firstTicketId) == 13 && strlen($lastTicketId) == 13 && $reseller_id > 0) || $toDelete) {
            $dbh = Propel::getConnection();

            if($toDelete)
            {
                for($i = $firstNum; $i <= $lastNum; $i++)
                {
                    $ticket_id = $i;
                    $crc = $this->calcEANCRC($ticket_id);
                    $ticket_id .= $crc;

                    $dbh->query("DELETE FROM _tickets WHERE patron_id IS NULL AND ticket_id = " . $dbh->quote($ticket_id));
                }
            }
            else
            {
                $stm = $dbh->prepare("REPLACE INTO _tickets(reseller,ticket_id,amount,created_by, date_created) VALUES(?,?,?,?,current_timestamp())");
                $tickets = array();
                for($i = 0; $i < $totTickets; $i++)
                {
                    $tickets[$i] = $firstNum + $i;
                    $crc = $this->calcEANCRC($tickets[$i]);
                    $tickets[$i] .= $crc;

                    $dbh->query("DELETE FROM _tickets WHERE patron_id IS NULL AND ticket_id = " . $dbh->quote($tickets[$i]));

                    $stm->execute(array($reseller_id,$tickets[$i],$amount,1));
                }
            }

            $this->loadTicketGrid();

        }
        $this->SellerID->setText("");
        $this->FirstCode->setText("");
        $this->LastCode->setText("");
        $this->DeleteTicket->setChecked(false);

    }

    private function calcEANCRC($ean)
    {
        $crcA = 0;
        $crcB = 0;
        for($i=11; $i >= 0; $i--)
            if($i%2 == 0 )
                $crcA += intval(substr($ean,$i,1));
            else
                $crcB += 3 * intval(substr($ean,$i,1));

        $total = $crcA + $crcB;
        $nextten=ceil($total/10)*10;
        $crc = $nextten - $total;

        return $crc;
    }
}

