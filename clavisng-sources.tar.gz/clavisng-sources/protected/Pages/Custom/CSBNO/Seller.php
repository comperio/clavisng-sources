<?php

/**
 * Home class
 *
 * @author Dario Rigolin <dario@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @version 2.7
 * @package Pages.Circulation
 * @since 2.0
 */

class Seller extends ClavisPage {

    public $_module = 'CUSTOM';

    public function onLoad($param)
    {
        if(!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallback() )
        {
            $this->loadSellerGrid();
        }

    }

    public function addSeller($sender, $param)
    {
        $denom = $this->Description->getSafeText();
        $pivacf = $this->PIVACF->getSafeText();
        $city = $this->City->getSafeText();

        $dbh = Propel::getConnection();
        $stm = $dbh->prepare("INSERT INTO _ticketseller(name,code,city) VALUES(?,?,?)")->execute(array($denom,$pivacf,$city));

        $this->Description->setText("");
        $this->PIVACF->setText("");
        $this->City->setText("");

        $this->loadSellerGrid();
    }

    public function loadSellerGrid()
    {
        $dbh = Propel::getConnection();

        $sellerData = $dbh->query("SELECT * FROM _ticketseller ORDER BY seller_id DESC")->fetchAll(PDO::FETCH_ASSOC);
        $this->SellerList->setDataSource($sellerData);
        $this->SellerList->dataBind();
    }

    public function sellerListCommand($sender, $param)
    {
        $command = $param->CommandName;
        $sellerId = $sender->DataKeys[$param->Item->itemIndex];

        switch($command)
        {
            case "Edit":
                $sender->EditItemIndex=$param->Item->ItemIndex;
                $this->loadSellerGrid();
                break;
            case "Update":
                $sender->EditItemIndex=-1;
                $denom = $param->Item->SellerName->TextBox->getSafeText();
                $pivacf = $param->Item->SellerCode->TextBox->getSafeText();
                $city = $param->Item->SellerCity->TextBox->getSafeText();

                $dbh = Propel::getConnection();
                $dbh->prepare("UPDATE _ticketseller SET name = ?, code = ?, city= ? WHERE seller_id = ?")->execute(array($denom,$pivacf,$city, $sellerId));

                $this->loadSellerGrid();
                break;
            case "Cancel":
                $sender->EditItemIndex=-1;
                $this->loadSellerGrid();
                break;
        }
    }

}

