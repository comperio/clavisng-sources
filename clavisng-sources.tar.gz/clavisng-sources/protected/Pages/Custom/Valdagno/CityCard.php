<?php

/**
 * Custom page for Valdagno city card. Called from 3rd part web app, edit patron after new card insert.
 * Operator profile is needed to get this page  to work.
 * 
 * For ACL use something like:
 * INSERT INTO app_action VALUES(100000, 30, 'City Card', 'Custom.Valdagno.CityCard','CUSTOM',0);
 * INSERT INTO app_module VALUES ('CUSTOM',15,'Custom','Custom.Home',0);
 * INSERT INTO app_profile_acl VALUES('CUSTOM',100000,5,'ALLOW');
 * 
 * WARN: logout if you want to reload acl.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Cristian Chiarello <cristian@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2017 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.8
 */

class CityCard extends ClavisPage 
{
	public $_module = 'CUSTOM';
	public $idbadge = FALSE;
	public $codfisc = FALSE;
	public $newBarcode = FALSE;
	
	public function onLoad($param)
	{
		parent::onLoad($param);
		
		$request = $this->getRequest();
		if( isset($request['idbadge']) && $request['idbadge'] != '' )
		{
			$this->idbadge = $request['idbadge'] ;
			$this->newBarcode = $this->getClavisID($this->idbadge);
		}
		$this->codfisc = ( isset($request['codfisc']) && $request['codfisc'] != '' ) ? $request['codfisc'] : FALSE;
		
		if(!$this->getPage()->getIsPostBack() && !$this->getPage()->getIsCallback() )
		{
			
			if( ! isset($request['action']) )
			{
				$this->populate();
			}
			else
			{
				$newBarcode = $request['newbarcode'];
				if( isset($request['patronid']) && $request['patronid'] != '' ) 
				{
					$pid=$request['patronid'];
					$p = PatronQuery::create()->findOneByPatronId($pid);
					if( $p instanceof Patron)
					{
						$p->setBarcode($newBarcode);
						$newRfidCode=  str_replace("VLD", "00000000", $newBarcode);
						$p->setRfidCode($newRfidCode);
						try
						{
							$p->save();	
							$this->gotoPage("Circulation.PatronViewPage", array("id" => $pid));
						}
						catch ( Exception $ex )
						{
							Prado::log(__METHOD__ . " " . $ex->getMessage());
						}
					}
					else
					{
						Prado::log(__METHOD__ . " action {$request['action']}: no patron with id {$pid}");
					}
				}
				else
				{
					Prado::log(__METHOD__ . " action {$request['action']}: missing patronid");
				}
			}
		}
		
	}
	
	public function populate()
	{
		$request = $this->getRequest();
		
		$p=array();

		
		if( $this->newBarcode !== FALSE)
		{
			$p[] = "barcode='{$this->newBarcode}'";
		}
		
		if( $this->codfisc !== FALSE )
		{
			$p[] = "national_id='{$this->codfisc}'";
		}
		
		if(empty($p))
		{
			return;
		}
		
		$where = implode(" OR ", $p);
		
		$patrons = PatronQuery::create()->where($where)->find();
		//$patrons = PatronQuery::create()->limit(5)->orderBy('lastname')->find();
		
		$this->PatronList->getItemStyle()->setCssClass("dgItem");
		$this->PatronList->getAlternatingItemStyle()->setCssClass("dgAltItem");
		$this->PatronList->getHeaderStyle()->setCssClass("dgHeaderItem");
		$this->PatronList->getStyle()->setCssClass("dgStyle");

		$ds = array();

		switch(count($patrons))
		{
			case 0:
				$con=  Propel::getConnection();
				$con->beginTransaction();
				try
				{
					$newPatron = new Patron();
					$newPatron->setRegistrationLibraryId(27);
					$newPatron->setPreferredLibraryId(27);
					$newPatron->setOpacUsername($request['codfisc']);
					$newPatron->setOpacSecret(sha1($request['codfisc']));
					$newPatron->setBarcode($this->newBarcode);
					$newPatron->setRfidCode( str_replace("VLD", "00000000", $this->newBarcode) );
					$newPatron->setNationalId($request['codfisc']);
					$newPatron->setName($request['nome']);
					$newPatron->setLastname($request['cognome']);
					$newPatron->save();
					
					$id = $newPatron->getPatronId();
					$address = new Address();
					$address->setPatronId($id);
					$address->setAddressType('R');
					$address->setStreetType('V1');
					$address->setStreet($request['via']);
					$address->setStreetNum($request['civico']);
					$address->setZip($request['cap']);
					$address->setCity($request['comune']);
					$address->setProvince($request['provincia']);
					$address->save();

					$con->commit();
					//Prado::log(__METHOD__." case 0 ".$this->getService()->constructUrl('Circulation.PatronViewPage',array('id'=>'5')));
					//$this->gotoPage("Circulation.PatronViewPage", array("id" => $newPatron->getPatronId()));
					$this->gotoPage("Circulation.PatronPage", array("id" => $id));
				}
				catch(Exception $e)
				{
					$con->rollBack();
					$this->writeMessage(Prado::localize("Errore nel caricamento del nuovo utente. Vedi log di clavis."), ClavisMessage::ERROR);
					Prado::log(__METHOD__ . " " . $e->getMessage());
				}
				break;
			/*
			case 1:
				$id = $patrons[0]->getPatronId();
				//Prado::log(__METHOD__." case 1 ".$this->getService()->constructUrl('Circulation.PatronViewPage',array('id'=>'5')));
				//$this->gotoPage("Circulation.PatronViewPage", array("id" => $patrons[0]->getPatronId()));
				$this->gotoPage("Circulation.PatronPage", array("id" => $id));
				break;
			 * 
			 */
			default:
				$this->PatronListPanel->setVisible(TRUE);
				foreach($patrons as $patron)
				{
					$barcode=$patron->getBarcode();
					$rfidcode = $patron->getRfidCode();
					$aPatron = array();
					$aPatron['COGNOME E NOME'] = $patron->getLastName() . " " . $patron->getName();
					$aPatron['BARCODE'] = $barcode;
					$aPatron['NUOVO BARCODE'] = $this->newBarcode;
					$born = $patron->getBirthCity();
					if($patron->getBirthProvince() != '')
						$born.= " (" .$patron->getBirthProvince(). ")";
					$aPatron['NATO A'] =  $born;
					$birthDate = $patron->getBirthDate(NULL);
					if( ! is_null($birthDate) )
					{
						$aPatron['NATO IL'] = date_format($patron->getBirthDate(NULL),"d/m/Y");
					}
					else
					{
						$aPatron['NATO IL'] = "-";
					}
					$lib=  LibraryQuery::create()->findOneByLibraryId($patron->getRegistrationLibraryId());
					if($lib instanceof Library)
					{
						$aPatron['BIBLIOTECA'] = $lib->getLabel();
					}
					else
					{
						$aPatron['BIBLIOTECA'] = "-";
					}
					$aPatron['CREATO IL'] = date_format($patron->getDateCreated(NULL),"d/m/Y");
					$aPatron['AZIONI'] =  "<a href=\"".$this->getService()->constructUrl('Circulation.PatronViewPage',array('id'=>$patron->getPatronId()))."\">Vedi</a>";
					$rfidSubstr = str_replace("VLD", "", $this->newBarcode);
					
					/*
					 * if existing barcode not equals new barcode and rfid code not contain new rfid user can bind patron to this rfid
					*/
					if( $barcode != $this->newBarcode && ( strpos( $rfidcode, $rfidSubstr ) === FALSE ) )
					{
						$aPatron['AZIONI'] .=  "<br/><a href=\"".$this->getService()->constructUrl( 'Custom.Valdagno.CityCard', array('action'=>'bind', 'newbarcode' => $this->newBarcode, 'patronid'=>$patron->getPatronId()) )."\">Associa</a>";
					}
					$ds[] = $aPatron;
				}
				//Prado::log(Prado::varDump($ds));
				break;
		}
		
		$this->PatronList->setDataSource($ds);
		$this->PatronList->dataBind();
		
	}


	public function getClavisID( $idbadge )
	{
		$aIdb = str_split($idbadge, 2);
		$aIdb = array_reverse($aIdb);
		return "VLD".implode("", $aIdb);
	}
	
}