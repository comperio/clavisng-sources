<?php

/**
 * OrderInsertPage class
 *
 * NB notare il meccanismo di ripopolamento dei campi che derivano da popup, in caso
 * di validazione non a buon fine di un campo in insert: non viene conservato il valore delle
 * label ma solo quello dell'hiddenfield, per cui bisogna ripopolare sulla onLoad() (solo in
 * postback, perche' in callback non funziona).
 *
 * @author Max Pigozzi <mpigozzi@e-portaltech.it>
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @copyright Copyright &copy; 2010 Comperio srl
 * @version 2.7
 * @package Pages.Acquisition
 * @since 2.2
 */

class OrderInsertPage extends ClavisPage 
{
	const DELIVERY_DEFAULT_INTERVAL = 2592000;	// 30 days in seconds

	public $_module = 'ACQUISITION';
	public $order = null;
		
	public function onInit($param)
	{
		parent::onInit($param);
		
		if (!$this->getIsPostBack() && !$this->getIsCallback())		// first cycle
		{
			$this->getApplication()->getSession()->remove('UpdateClavisItemList');
			$this->getApplication()->getSession()->remove('UpdateManifestationId');
		}
	}
	
	/**
	 * On the onLoad we populate the textbox "Title" if the proper
	 * value is passed as a get parameter, and we must initialize
	 * EACH instance of repeatable list in the page (by $this->addItem).
	 *
	 * @param unknown_type $param
	 */
	public function onLoad($param)
	{
		parent::onLoad($param);
		
		if (!$this->getIsPostBack() && !$this->getIsCallback())		// first cycle
		{
			$id = intval($this->getRequest()->itemAt('id'));
			if ($id > 0)
			{
				$order = PurchaseOrderQuery::create()->findPK($id);
				if (!($order instanceof PurchaseOrder))
				{
					$this->writeMessage(Prado::localize("L'ordine con id = {id} non esiste",
															array('id' => $id)),
										ClavisMessage::ERROR);
					$this->gotoPage('Acquisition.OrderListPage');
				} elseif($order->getOrderStatus() != PurchaseOrderPeer::STATUS_OPEN) {
                    $this->writeMessage(Prado::localize("L'ordine con id = {id} non è modificabile",
                            array('id' => $id))
                        ,ClavisMessage::ERROR);
                    $this->gotoPage('Acquisition.OrderListPage');
                }
				
				$this->ItemOrderList->setPurchaseOrder($order);
			} 
			else 
			{
				$order = new PurchaseOrder();
				$order->setOrderStatus(PurchaseOrderPeer::STATUS_OPEN);
				$order->setLibrary($this->getUser()->getActualLibrary());
				$order->setOrderDate(time());
				$order->setDeliveryDate(time());
			}
			
			$this->setOrder($order);

			if ($this->order->isNew()) 
			{
				$this->OrderInsertFieldset->setUserOpen(false);
				$this->ItemOrderList->setPurchaseOrder(null);
				$this->ItemOrderList->setDisablePopulate(true);
			} 
			else 
			{
				switch ($this->order->getOrderStatus()) 
				{
					case PurchaseOrderPeer::STATUS_OPEN:
						break;

					case PurchaseOrderPeer::STATUS_CLOSED:
					case PurchaseOrderPeer::STATUS_FULLDISPATCHED:
					case PurchaseOrderPeer::STATUS_SENT:
					case PurchaseOrderPeer::STATUS_PARTDISPATCHED:
						$this->PopupSupplierLinkButton->setVisible(false);
						break;
				}
			}

			/*
			 * We cannot modify closed orders ......
			$this->SendOrder->setVisible($order->getOrderStatus() == PurchaseOrderPeer::STATUS_CLOSED);
			 */
			
			// XXX FIXME: people that can't edit orders should not get to this page...
			//if ($this->getUser()->getActualLibraryId() != $this->order->getLibraryId())
			//	$this->ModifyOrder->setEnabled(false);

			$this->populate();
			$this->dataBind();
			$this->UpdateData->setObject($this->getOrder());
			//////$this->ItemOrderList->setShowInvoiceCol($this->order->getOrderStatus() != PurchaseOrderPeer::STATUS_OPEN);

		} 
		elseif ($this->getIsPostBack() && !$this->getIsCallback())	// during postback only
		{
			$this->getOrder();
			$supplier = SupplierQuery::create()->findPK($this->SupplierId->getValue());
			if ($supplier instanceof Supplier)
				$this->Supplier->setText($supplier->getSupplierName());
		} 
		elseif ($this->getIsCallback())	// during callbacks
		{
			// hack to make orderstatus available on callback
			$this->order = PurchaseOrderQuery::create()->findPK($this->OrderId->getValue());
			if (!($this->order instanceof PurchaseOrder))
			{
				$this->order = new PurchaseOrder();
				$this->order->setOrderStatus(PurchaseOrderPeer::STATUS_OPEN);
			}
		}
		
		if ($this->getIsPostBack() || $this->getIsCallback())	// not in first cycle, anyway
		{
			$updateClavisItemList = $this->getApplication()->getSession()->itemAt('UpdateClavisItemList');
			if ($updateClavisItemList)
			{
				$this->getApplication()->getSession()->remove('UpdateClavisItemList');
				$this->ItemOrderList->populate();
				
				if ($this->getIsCallback())
					$this->ItemOrderListPanel->render($this->createWriter());
			}
		}
	}

	public function populate() 
	{
		$this->OrderId->setValue($this->order->isNew() 
									? 0 
									: $this->order->getOrderId());
		
		$this->OrderTitle->setText($this->order->getOrderTitle());
		$this->OrderType->setSelectedValue($this->order->getOrderType());
		//$this->OrderStatus->setSelectedValue($this->order->getOrderStatus());
		$this->OrderStatus->setText($this->order->getOrderStatusString());
		
		$l = $this->order->getLibrary();
		if ($l instanceof Library) 
		{
			$libraryId = $l->getLibraryId();
			$this->LibraryId->setValue($libraryId);
			$this->Library->setText($l->getLabel());
		}
		else
		{
			$libraryId = null;
		}
		
		$supplier = SupplierQuery::create()->findPK($this->order->getSupplierId());
		if ($supplier instanceof Supplier) 
		{
			$this->Supplier->setText($supplier->getSupplierName());
			$supplierId = intval($supplier->getSupplierId());
			$this->SupplierId->setValue($supplierId);

			$this->AccountIdList->setVisible(true);
			$accountIds = array(-1 => '---');
			$priceManager = $this->getApplication()->getModule('price');
			foreach ($priceManager->getAccountIds($supplierId, $libraryId) as $row)
				$accountIds[$row] = $row;
		
			$this->AccountIdList->setDataSource($accountIds);
			$this->AccountIdList->dataBind();
			$accountId = $this->order->getAccountId();
			if (!is_null($accountId))
				$this->AccountIdList->setSelectedValue($accountId);
		}
		else
		{
			$this->AccountIdList->setVisible(false);
		}
			
		$this->OrderDate->setTimestamp($this->order->getOrderDate('U'));
		$this->DeliveryDate->setTimestamp($this->order->getDeliveryDate('U'));
		$this->OrderDiscount->setText(ClavisBase::numberFormat($this->order->getOrderDiscount(), '#.00%'));
		$this->OrderNote->setText($this->order->getOrdernote());
	}

	public function setOrder(PurchaseOrder $order) 
	{
		$this->order = $order;
		$this->setViewState('PurchaseOrder',$order,null);
	}
	
	public function getOrder() 
	{
		if (is_null($this->order))
			$this->order = $this->getViewState('PurchaseOrder',null);
	
		return $this->order;
	}

	public function getOrderId() 
	{
		$order = $this->getOrder();
		
		if ($order instanceof PurchaseOrder)
			return $order->getOrderId();
		else
			return null;
	}
	
	private function getOrderTitle($completeFlag = false)
	{
		$returnValue = "--";
		
		/** @var $order PurchaseOrder */
		$order = $this->getOrder();

		if ($order instanceof PurchaseOrder)
		{
			$returnValue = $order->getOrderTitle();
					
			if ($completeFlag && ($returnValue != ""))
				$returnValue .= " (" . $order->getOrderId() . ")";
		}
		
		return $returnValue;
	}
	
	public function getManifestationId()
	{
		$manifestationId = intval($this->ManifestationId->getValue());
		if ($manifestationId > 0)
			return $manifestationId;
		else
			return null;
	}
	
	public function onCheckOrderDiscountValidity($sender, $param)
	{
		$value = ClavisBase::numberFormat($this->OrderDiscount->getSafeText(), '#.00', null, false);

		if (($value < 0.00) || ($value > 100.00))
			$param->isValid = false;
		else
			$param->isValid = true;
		
		return $param->isValid;
	}
	
	public function onSave($sender, $param)
	{
		$this->doSaveOrder($param);	
		
		$this->gotoPage("Acquisition.OrderInsertPage", 
							array('id' => $this->order->getOrderId()));
	}
	
	public function onSaveExit($sender, $param)
	{
		$this->doSaveOrder($param);
					
		$this->gotoPage("Acquisition.OrderViewPage", 
							array('id' => $this->order->getOrderId()));
	}
	
	protected function doSaveOrder($param)
	{
		if (!$this->getIsValid())
			return false;
				
		$isNew = $this->order->isNew();

		$this->order->setOrderTitle($this->OrderTitle->getSafeText());
		$this->order->setOrderType($this->OrderType->getSelectedValue());
		$this->order->setSupplierId($this->SupplierId->getValue());
		$this->order->setOrderDate($this->OrderDate->getTimestamp());
		$this->order->setDeliveryDate($this->DeliveryDate->getTimestamp());
		
		$orderDiscount = ClavisBase::numberFormat($this->OrderDiscount->getSafeText(), '#.00', null, false);
		$this->order->setOrderDiscount($orderDiscount);
		$this->OrderDiscount->setText(ClavisBase::numberFormat($orderDiscount, '#.00%'));	// reformatting to video
		
		$this->order->setOrderNote($this->OrderNote->getSafeText());

		if ($this->AccountIdList->getSelectedValue() == -1)
			$accountId = null;
		else
			$accountId = $this->AccountIdList->getSelectedValue();
		$this->order->setAccountId($accountId);
		
		$this->order->save();

		if ($isNew) 
		{
			ChangelogPeer::logAction(	$this->order,
										ChangelogPeer::LOG_CREATE, 
										$this->getUser());
			
			$this->writeMessage(Prado::localize("Ordine inserito correttamente"),
									ClavisMessage::CONFIRM);
		} 
		else 
		{
			ChangelogPeer::logAction(	$this->order, 
										ChangelogPeer::LOG_UPDATE, 
										$this->getUser());
			
			$this->writeMessage(Prado::localize("Ordine modificato correttamente"),
									ClavisMessage::CONFIRM);
		}
	}

	public function onCloseOrder($sender, $param)
	{
		if (!($this->order instanceof PurchaseOrder))
		{
			$this->getPage()->writeMessage(Prado::localize("Ordine non valido"), ClavisMessage::ERROR);
			return false;
		}

		$this->order->setOrderStatus(PurchaseOrderPeer::STATUS_CLOSED);
		$this->order->save();

		ChangelogPeer::logAction(	$this->order, 
									ChangelogPeer::LOG_UPDATE , 
									$this->getUser(), 
									'chiusura ordine');
		
		$this->writeMessage(Prado::localize("Ordine chiuso correttamente"),
								ClavisMessage::INFO);
		
		$this->gotoPage('Acquisition.OrderInsertPage', 
							array('id' => $this->order->getOrderId()));
	}

	public function onReopenOrder($sender, $param)
	{
		if (!($this->order instanceof PurchaseOrder))
		{
			$this->getPage()->writeMessage(Prado::localize("Ordine non valido"), 
											ClavisMessage::ERROR);
			return false;
		}			

		$this->order->setOrderStatus(PurchaseOrderPeer::STATUS_OPEN);
		$this->order->save();

		ChangelogPeer::logAction(	$this->order, 
									ChangelogPeer::LOG_UPDATE , 
									$this->getUser(), 
									'riapertura ordine');
		
		$this->writeMessage(Prado::localize("Ordine riaperto"),
								ClavisMessage::INFO);
		
		$this->gotoPage('Acquisition.OrderInsertPage', 
							array('id' => $this->order->getOrderId()));
	}

	public function onDeleteOrder($sender, $param)
	{
		if (!($this->order instanceof PurchaseOrder))
		{
			$this->getPage()->writeMessage(Prado::localize("Ordine non valido"), 
											ClavisMessage::ERROR);
			return false;
		}

		$order_id = $this->order->getOrderId();
		
		foreach ($this->order->getItems() as $i) 
		{
			$i->setOrderId(null);
			$i->save();
		}
		
		$this->order->delete();
		
		ChangelogPeer::logAction(	$this->order, 
									ChangelogPeer::LOG_DELETE, 
									$this->getUser());
		
		$this->writeMessage(Prado::localize("L'ordine con id = {id} è stato eliminato (eventuali esemplari associati sono ancora presenti)",
												array('id' => $order_id)),
							ClavisMessage::INFO);
		
		$this->gotoPage('Acquisition.OrderListPage');
	}

	public function onDeleteOrderAndItems($sender, $param)
	{
		if (!($this->order instanceof PurchaseOrder))
		{
			$this->getPage()->writeMessage(Prado::localize("Ordine non valido"), 
											ClavisMessage::ERROR);
			return false;
		}

		$order_id = $this->order->getOrderId();
		if (intval($order_id) < 1)	// paranoid control to avoid ENTIRE ITEM TABLE deletion
			return false;
		ItemQuery::create()
			->filterByOrderId($order_id)
			->delete();
		$this->order->delete();
		
		ChangelogPeer::logAction(	$this->order, 
									ChangelogPeer::LOG_DELETE, 
									$this->getUser());
		
		$this->writeMessage(Prado::localize("L'ordine con id = {id} e tutti gli esemplari ad esso associati sono stati eliminati",
												array('id' => $order_id)),
							ClavisMessage::INFO);
		
		$this->gotoPage('Acquisition.OrderListPage');
	}

	public function onOrderSent($sender, $param)
	{
		if (!($this->order instanceof PurchaseOrder))
		{
			$this->getPage()->writeMessage(Prado::localize("Ordine non valido"), 
											ClavisMessage::ERROR);
			return false;
		}
		
		$this->order->setOrderStatus(PurchaseOrderPeer::STATUS_SENT);
		$this->order->save();
		
		ChangelogPeer::logAction(	$this->order, 
									ChangelogPeer::LOG_UPDATE , 
									$this->getUser(), 
									'ordine impostato a SPEDITO');
		
		$this->writeMessage(Prado::localize("Ordine impostato a 'SPEDITO'"),
								ClavisMessage::INFO);
		$this->reloadPage();
    }

	public function onBackToView($sender, $param)
	{
		$orderId = intval($this->order->getOrderId());
		if ($orderId > 0)
			$this->gotoPage('Acquisition.OrderViewPage',
								array('id' => $orderId));
		else
			$this->gotoPage('Acquisition.OrderListPage');
	}

	public function OnInvoiceIdChanged($sender,$param) 
	{
		$itemId = $sender->Parent->ObjItemId->getValue();
		$invoiceId = $sender->Parent->InvoiceId->getValue();
		$orderId = $sender->Parent->OrderId->getValue();
		
		$this->gotoPage('Acquisition.InvoiceInsertPage',
						array(	'id' => $invoiceId, 
								'itemId' => $itemId, 
								'orderId' => $orderId));
	}
	
	public function onResetSupplier($sender, $param)
	{
		$this->doResetSupplier($param);
	}

	private function doResetSupplier($param = null)
	{
		$this->Supplier->setText("");
		$this->SupplierId->setValue('');
		
		$this->renderSupplierPanel($param);
	}
	
	public function renderSupplierPanel($param = null)
	{
		if (is_null($param))
			$writer = $this->createWriter();
		else
			$writer = $param->getNewWriter();

		$this->SupplierPanel->render($writer);
	}
	
	public function onUpdateSupplierCallback($sender, $param)
	{
		$supplier = SupplierQuery::create()->findPK(intval($this->SupplierId->getValue()));
		if ($supplier instanceof Supplier) 
			$this->OrderDiscount->setText(ClavisBase::numberFormat($supplier->getDiscount(), '#.00%'));
	}
}
