<?php

/**
 * SupplierListPopup Test Page class Module Acquisizioni
 *
 * @author Dario Rigolin <drigolin@e-portaltech.it>
 * @link http://www.e-portaltech.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @license http://www.e-portaltech.it/license/
 */

class SupplierListPopup extends ClavisPagePopup
{
	public $_module = "ACQUISITION";

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getPage()->getIsPostBack())
		{
			$this->NewSupplierDialog->setVisible(false);
			$this->dataBind();
		}
	}

	public function onOpenNewSupplierDialog($sender, $param)
	{
		$this->NewSupplierDialog->setVisible(true);
	}

	public function onSave($sender, $param)
	{
		if (($supplierName = $this->SupplierName->getText()) != null)
		{
			$newSupplier = new Supplier();
			$newSupplier->setSupplierName($supplierName);

			$currentDate = date('Y-m-d H:i:s');
			$currentUser = $this->User->getID();
			$newSupplier->setDateCreated($currentDate);
			$newSupplier->setCreatedBy($currentUser);
			$newSupplier->setDateUpdated($currentDate);
			$newSupplier->setModifiedBy($currentUser);

			$newSupplier->save();

			$this->SupplierList->populate($newSupplier);
			$this->onCancel(null, null);
		}
	}

	public function onCancel($sender, $param)
	{
		$this->SupplierName->setText('');
		$this->NewSupplierDialog->setVisible(false);
	}
}
