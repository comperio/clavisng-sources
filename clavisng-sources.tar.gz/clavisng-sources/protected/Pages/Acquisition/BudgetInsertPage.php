<?php
/**
 * BudgetInsertPage class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Massimiliano Pigozzi <mpigozzi@e-portaltech.it>
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 ePortal Technologies
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Pages.Acquisition
 */

/**
 * BudgetInsertPage Class
 *
 * @author Massimiliano Pigozzi <mpigozzi@e-portaltech.it>
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Pages.Acquisition
 * @since 2.1
 */
class BudgetInsertPage extends ClavisPage
{
	/**
	 * Name of the module where we are.
	 *
	 * @var string
	 */
	public $_module = 'ACQUISITION';
	private $_budget = null;
	
	public $_systemCurrency;

	public function onInit($param)
	{
		parent::onInit($param);
		$this->_systemCurrency = ClavisParamQuery::getParam('CLAVISPARAM','SystemCurrency');
		if (!$this->getIsPostBack() )
		{
		    $budgetId = intval($this->getRequest()->itemAt('id'));
			if ($budgetId > 0)
			{
				$budget = BudgetQuery::create()
							->findPk($budgetId);
				
				if (!($budget instanceof Budget))
				{
					$this->writeMessage(Prado::localize("Il budget con id = {id} non esiste", array('id' => $budgetId)),
										ClavisMessage::ERROR);
					$this->gotoPage('Acquisition.BudgetList');
				}
			} 
			else 
			{
				$budget = new Budget();
			}
							
			$this->setBudget($budget);
			$this->UpdateData->setObject($this->getBudget());
			
			$this->BudgetLibrary->setDataSource($this->getUser()->getLibraries());
			$this->BudgetLibrary->dataBind();
		}
	}

	/**
	 * On the onLoad we populate the textbox "Title" if the proper
	 * value is passed as a get parameter, and we must initialize
	 * EACH instance of repeatable list in the page (by $this->addItem).
	 *
	 * @param unknown_type $param
	 */
	public function onLoad($param)
	{
		parent::onLoad($param);
		
		/* caricamento dei dati nella form */
		if (!$this->getIsPostBack() )
		{
			$this->populate();
		}
	}

	/**
	 * setters & getters
	 */
	public function setBudget($budget) 
	{
		$this->_budget = $budget;
		$this->setViewState("budget", $budget, null);
	}

	public function getBudget() 
	{
		$this->_budget = $this->getViewState("budget", null);
		return $this->_budget;
	}

	public function populate()
	{
		$this->populateForm();
	}
	
	public function populateForm() 
	{
		$this->getBudget();
		if (!($this->_budget instanceof Budget))
			return;

		$this->BudgetTitle->setText($this->_budget->getBudgetTitle());
		$this->BudgetYear->setText($this->_budget->getBudgetYear());
		
		//$this->LibraryId->setValue($this->_budget->getLibraryId());
		//$this->Library->setText($this->_budget->getLibraryLabel());
		
		try
		{
			if ($this->_budget->isNew())
				$this->BudgetLibrary->setSelectedValue($this->getUser()->getActualLibraryId());
			else 
				$this->BudgetLibrary->setSelectedValue($this->_budget->getLibraryId());
		}
		catch (Exception $exception)
		{
		}	
				
		$this->StartValidity->setTimestamp($this->_budget->getStartValidity('U'));
		$this->EndValidity->setTimestamp($this->_budget->getEndValidity('U'));

		$this->TotalAmount->setText(ClavisBase::numberFormat($this->_budget->getTotalAmount(), '#.00'));
		//$this->Tolerance->setText($this->_budget->getTolerance());
		$this->Notes->setText($this->_budget->getBudgetNotes());
	}
	
	public function onValidateUnique($sender, $param)
	{
		$param->isValid = true;
		
		$this->getBudget();
		$budgetTitle = $this->BudgetTitle->getSafeText();
		$budgetYear = $this->BudgetYear->getSafeText();
		if ($this->BudgetLibrary->getSelectedValue() > 0)
			$budgetLibraryId = $this->BudgetLibrary->getSelectedValue();
		else
			$budgetLibraryId = null;
				
		if (	//!$this->_budget->isNew()
				($budgetTitle != "")
				&& ($budgetYear != "")
				&& !is_null($budgetLibraryId))
		{
			$duplicatesCount = BudgetQuery::create()
								->filterByBudgetTitle($budgetTitle)
								->filterByBudgetYear($budgetYear)
								->filterByLibraryId($budgetLibraryId)
								->prune($this->_budget)
								->count();

			if ($duplicatesCount > 0)
			{
				$param->isValid = false;
				
				$this->getPage()->writeMessage("Attenzione, dati identici per titolo/anno/biblioteca sono stati inseriti in un budget già esistente",
												ClavisMessage::ERROR);
			}
		}
	}
	
	public function onSaveBudget($sender, $param) 
	{
		if (!$this->getIsValid()) 
			return false;
		
		$this->getBudget();
		$exitFlag = ($sender->getId() == "SaveButton");
		
		$isNew = $this->_budget->isNew();

		$this->_budget->setBudgetTitle($this->BudgetTitle->getSafeText());
		$this->_budget->setBudgetYear($this->BudgetYear->getSafeText());
		
		$libraryIdSelected = $this->BudgetLibrary->getSelectedValue();
		if ($libraryIdSelected > 0)
			$this->_budget->setLibraryId($this->BudgetLibrary->getSelectedValue());
		
		$this->_budget->setStartValidity($this->StartValidity->getTimeStamp());
		$this->_budget->setEndValidity($this->EndValidity->getTimeStamp());
		
		$totalAmount = ClavisBase::numberFormat($this->TotalAmount->getSafeText(), '#.00', null, false);
		$this->_budget->setTotalAmount($totalAmount);
		$this->TotalAmount->setText(ClavisBase::numberFormat($totalAmount, '#.00'));	// reformatting to video
		
		$this->_budget->setBudgetNotes($this->Notes->getSafeText());
		$this->_budget->save();

		if ($isNew) 
		{
			ChangelogPeer::logAction(	$this->_budget, 
										ChangelogPeer::LOG_CREATE, 
										$this->getUser());
			
			$this->writeMessage(Prado::localize('Budget inserito con successo'), 
									ClavisMessage::CONFIRM);
		} 
		else 
		{
			ChangelogPeer::logAction(	$this->_budget, 
										ChangelogPeer::LOG_UPDATE, 
										$this->getUser());
			
			$this->writeMessage(Prado::localize('Budget modificato con successo'), 
									ClavisMessage::CONFIRM);
		}
		
		$this->setBudget($this->_budget);
		
		if ($exitFlag)
			$this->gotoPage(BudgetPeer::getViewPage(),
							array('id'=>$this->_budget->getBudgetId()));
	}
	
	/**
	 * Exits the editing of a budget, without doing anything.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onCancel($sender, $param)
	{
		$budget = $this->getBudget();
		if ($budget instanceof Budget)
			$budgetId = intval($budget->getBudgetId());
		else
			$budgetId = 0;

		if (($budgetId == 0) && !$budget->isNew())
			$this->gotoPage("Acquisition.BudgetList");
		else
			$this->gotoPage(BudgetPeer::getViewPage(), array('id' => $budgetId));
	}
	
}
