<?php

/**
 * Acquisition.OrderViewPage Page class Module Acquisition
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @copyright Copyright &copy; 2010 Comperio srl
 */


class OrderViewPage extends ClavisPage 
{
	public $_module = 'ACQUISITION';
	protected $_orderId;

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getIsPostBack() && !$this->getIsCallback())
		{
			$id = intval($this->getRequest()->itemAt('id'));
			$order = PurchaseOrderQuery::create()->findPk($id);
			if ($order instanceof PurchaseOrder)
			{
				$this->setOrderId($id);

				$this->populate();

				$this->Edit->setEnabled($this->getUser()->getEditPermission($order) &&
										in_array(	$order->getOrderStatus(),
													array(	PurchaseOrderPeer::STATUS_CLOSED,
															PurchaseOrderPeer::STATUS_OPEN)));
				
				$this->SendOrder->setVisible($order->getOrderStatus() == PurchaseOrderPeer::STATUS_CLOSED);
				
				switch ($order->getOrderStatus()) 
				{
					case PurchaseOrderPeer::STATUS_OPEN:
						$this->AddTitle->setEnabled(true);
						$this->AddTitleQuickButton->setEnabled(true);
						$this->RemoveTitles->setEnabled(true);

						break;

					case PurchaseOrderPeer::STATUS_CLOSED:
					case PurchaseOrderPeer::STATUS_FULLDISPATCHED:
					case PurchaseOrderPeer::STATUS_SENT:
					case PurchaseOrderPeer::STATUS_PARTDISPATCHED:
						$this->AddTitle->setEnabled(false);
						$this->AddTitleQuickButton->setEnabled(false);
						$this->RemoveTitles->setEnabled(false);
						
						break;
				}
			} 
			else 
			{
				$this->writeMessage(Prado::localize("L'ordine con id = {id} non esiste",
															array('id' => $id)),
										ClavisMessage::ERROR);
									
				$this->gotoPage('Acquisition.OrderListPage');
			}
			
			$this->MultiOrderPopupButtonPanel->setStyle("display: none");
			$this->EditTitleQuickPopupButton->setStyle("display: none");
		}
		else		// not in first cycle
		{
			$updateClavisItemList = $this->getApplication()->getSession()->itemAt('UpdateClavisItemList');
			$updateManifestationId = $this->getApplication()->getSession()->itemAt('UpdateManifestationId');

			if ($updateClavisItemList)
			{
				$this->getApplication()->getSession()->remove('UpdateClavisItemList');
				$this->ItemOrderList->populate();
				
				if ($this->getIsCallback())
					$this->ItemOrderListPanel->render($this->createWriter());
			}
			
			if ($updateManifestationId)
			{
				$this->getApplication()->getSession()->remove('UpdateManifestationId');
				$this->ManifestationId->setValue($updateManifestationId);
				$this->populateManifestationData($updateManifestationId);
				
				if ($this->getIsCallback())
					$this->ItemOrderListPanel->render($this->createWriter());
			}
		}
	}

	public function populate()
	{
		$order = $this->getOrder();
		
		$this->OrderView->setOrder($order);
		$this->UpdateData->setObject($order);
		
		$this->ItemOrderList->setPurchaseOrder($order);
	}
	
	public function onOrderEdit($sender, $param)
	{
		$this->gotoPage('Acquisition.OrderInsertPage', array('id'=>$this->getOrderId()));
    }

	public function onOrderSent($sender, $param)
	{
		$order = $this->getOrder();
		if ($order instanceof PurchaseOrder) 
		{
			$order->setOrderStatus(PurchaseOrderPeer::STATUS_SENT);
			$order->save();
			
			ChangelogPeer::logAction(	$order,
										ChangelogPeer::LOG_UPDATE, 
										$this->getUser(), 
										'ordine impostato a SPEDITO');
			
			$this->writeMessage(Prado::localize('Ordine impostato a SPEDITO'),
									ClavisMessage::INFO);
		}
		
		$this->reloadPage();
    }

	public function setOrderId($id) 
	{
		$this->_orderId = $id;
		$this->setViewState('OrderId',$id,null);
	}

	public function getOrderId() 
	{
		if (is_null($this->_orderId)) {
			$this->_orderId = $this->getViewState('OrderId',null);
		}
		return $this->_orderId;
	}

	public function getOrder()
	{
		$order = null;
		$orderId = intval($this->getOrderId());
		if ($orderId > 0)
			$order = PurchaseOrderQuery::create()->findPk($orderId);
			
		return $order;
	}
	
	private function getOrderTitle($completeFlag = false)
	{
		$returnValue = "--";
		
		/** @var $order PurchaseOrder */
		$order = $this->getOrder();

		if ($order instanceof PurchaseOrder)
		{
			$returnValue = $order->getOrderTitle();
					
			if ($completeFlag && ($returnValue != ""))
				$returnValue .= " (" . $order->getOrderId() . ")";
		}
		
		return $returnValue;
	}
	
	/**
	 * It is called by one of the inner components, and
	 * performs the population (refresh) of all the components
	 * (the calling is included).
	 *
	 */
	public function globalRefresh()
	{
		$this->OrderView->populate();
	}

	/**
	 * It's called by one of the inner components, and
	 * performs the "cancel" (return to non-edit status)
	 * of all the components (the calling is included).
	 *
	 * @param TControl $component
	 */
	public function globalCancel($component)
	{
	}

	public function OnInvoiceIdChanged($sender,$param) 
	{
		$itemId = $sender->Parent->ObjItemId->getValue();
		$invoiceId = $sender->Parent->InvoiceId->getValue();
		$orderId = $sender->Parent->OrderId->getValue();
		
		$this->gotoPage('Acquisition.InvoiceInsertPage',
						array(	'id' => $invoiceId, 
								'itemId' => $itemId, 
								'orderId' => $orderId));
	}
	
	public function onRemoveTitlesFromOrder($sender, $param)
	{
		$checkedIds = $this->ItemOrderList->getCheckedId();
		if (count($checkedIds) > 0) 
		{
			$removedCount = ItemQuery::create()
								->filterByItemId($checkedIds)
								->delete();

			$orderTitle = $this->getOrderTitle();
			
			$this->getPage()->writeMessage(Prado::localize("Rimossi {removedCount} esemplari dall'ordine {orderTitle}",
															array(	'removedCount' => $removedCount,
																	'orderTitle' => $orderTitle)),
											$removedCount > 0
												? ClavisMessage::CONFIRM
												: ClavisMessage::INFO);
			
			if ($removedCount > 0)
			{
				$this->ItemOrderList->populate();

				ChangelogPeer::logAction(	$this->getOrder(), 
											ChangelogPeer::LOG_UPDATE, 
											$this->getUser(), 
											"rimossi $removedCount esemplari collegati all'ordine '$orderTitle'");
			}
		}
		else
		{
			$this->getPage()->writeMessage(Prado::localize('Nessun elemento selezionato'),
											ClavisMessage::WARNING);
			
			return false;
		}
	}
	
	public function onItemSelected($sender, $param) 
	{
		$manifestationId = intval($this->ManifestationId->getValue());
		
		if ($manifestationId > 0)
			$this->populateManifestationData($manifestationId);
	}
	
	private function populateManifestationData($manifestationId)
	{
		$manifestation = null;
		if ($manifestationId > 0)
			$manifestation = ManifestationQuery::create()
								->findPk($manifestationId);
		
		if ($manifestation instanceof Manifestation)
		{
			$priceManager = $this->getApplication()->getModule('price');
			$listPrice = $priceManager->getManifestationListPrice($manifestation);

			if (is_null($listPrice))
				$listPrice = '--';
			else
				$listPrice = ClavisBase::numberFormat($listPrice, '#.00');
			
			$yearRaw = $manifestation->getYear();
			if ($yearRaw) 
				$year = $yearRaw['date'];
			else
				$year = '--';

			$title = '--';
			$author = '--';
			$ean = '--';
			$publisher = '--';
				
			$manTurbomarc = $manifestation->getTurboMarc();
			if ($manTurbomarc instanceof TurboMarc)
			{
				$title = (string) $manTurbomarc->d200->sa;
				$author = (string) $manTurbomarc->d200->sf;
				
				$ean = $manTurbomarc->getEAN();
				$publisher = implode('. ', $manTurbomarc->getPublications());
				$serie = trim(implode('/', $manTurbomarc->getSeries()), '/');
			}

			if ($title == "")
				$title = '--';			
			if ($author == "")
				$author = '--';
			if ($ean == "")
				$ean = '--';
			if ($publisher == "")
				$publisher = '--';
			
			$blobData = array();
			$blobData[] = array('label' => Prado::localize('titolo'), 'data' => $title);
			$blobData[] = array('label' => Prado::localize('autore'), 'data' => $author);
			$blobData[] = array('label' => Prado::localize('EAN'), 'data' => $ean);
			$blobData[] = array('label' => Prado::localize('anno'), 'data' => $year);
			$blobData[] = array('label' => Prado::localize('editore'), 'data' => $publisher);
			$blobData[] = array('label' => Prado::localize('collana'), 'data' => $serie);
			$blobData[] = array('label' => Prado::localize('prezzo') . ' (' . ClavisParamQuery::getParam('CLAVISPARAM','SystemCurrency') . ')', 'data' => $listPrice);
			
			$this->ChosenTitleData->setDataSource($blobData);
			$this->ChosenTitleData->dataBind();
			
			$this->MultiOrderPopupButton->setParam(serialize(array(	'orderId' => $this->getOrderId(),
																	'manifestationId' => $manifestationId)));
			
			$quickId = intval($manifestation->getQuickId());
			if ($quickId > 0)
			{
				$this->EditTitleQuickPopupButton->setStyle("display: inline");
				$this->EditTitleQuickPopupButton->setParam($quickId);
			}
			else
			{
				$this->EditTitleQuickPopupButton->setStyle("display: none");
			}
			
			$this->MultiOrderPopupButtonPanel->setStyle("display: inline");
			if ($this->getIsCallback())
				$this->MultiOrderPopupButtonPanel->render($this->createWriter());
		}	// end of "if manifestation instance of Manifestation
	}
	
	public function onInsertTitleInOrder($sender, $param)
	{
		if (!$this->getIsValid())
			return false;
		
		if (!($this->order instanceof PurchaseOrder))
		{
			$this->getPage()->writeMessage(Prado::localize("Ordine non valido"), 
											ClavisMessage::ERROR);
			return false;
		}
				
		$man = null;
		$manifestationId = intval($this->ManifestationId->getValue());
		if ($manifestationId > 0)
			$man = ManifestationQuery::create()->findPK($manifestationId);

		if (!($man instanceof Manifestation))
		{
			$this->getPage()->writeMessage(Prado::localize("Titolo specificato non valido [id = {id}]",
															array('id' => $manifestationId)), 
											ClavisMessage::ERROR);
			return false;
		}
			
		$projectedPrice = intval($this->ChosenTitlePrice->getSafeText());
		$discountedPrice = $projectedPrice;
		
		if ($projectedPrice < 0) 
		{
			$this->writeMessage(Prado::localize("Inserire correttamente il prezzo di acquisto dell'esemplare"), 
													ClavisMessage::WARNING);
			return false;
		}
		
		if (($discount = intval($this->ChosenTitleDiscount->getSafeText())) > 0) 
		{
			$discamount = round(($projectedPrice * $discount / 100), 2);
			$discountedPrice = $projectedPrice - $discamount;
		}
		
		$l = null;
		$lid = intval($this->LibraryId->getValue());
		$l = LibraryQuery::create()->findPK($lid);
		if (!($l instanceof Library))
		{
			$lid = $this->getUser()->getActualLibraryId();
			$l = $this->getUser()->getActualLibrary();
		}

		$returnValue = $this->order->addItemToOrder($manifestationId,
													$lid,
													$projectedPrice,
													$discountedPrice);

		if (intval($returnValue) == 0)    // <--- it returns the item_id of the newly created item
		{
			$this->getPage()->writeMessage(Prado::localize("Errore nell'aggiungere il titolo all'ordine '{title}'",
															array('title' => $man->getTitle())), 
											ClavisMessage::ERROR);
			return false;
		}
		
		ChangelogPeer::logAction(	$this->order, 
									ChangelogPeer::LOG_UPDATE, 
									$this->getUser(), 
									'aggiunto item id: ' . $returnValue);
		
		$this->getPage()->writeMessage(Prado::localize("Titolo aggiunto all'ordine '{title}'",
														array('title' => $man->getTitle())), 
										ClavisMessage::CONFIRM);

		$this->ItemOrderList->setPurchaseOrder($this->order);
		$this->ItemOrderList->populate();

		$this->ManifestationId->setValue('');
		$this->ChosenTitleData->setDataSource(array());
		$this->ChosenTitleData->dataBind();
		
		$this->ChosenTitleDiscount->setText(ClavisBase::numberFormat($this->OrderDiscount->getSafeText(), '#.00%'));
		$this->ChosenTitlePrice->setText(ClavisBase::numberFormat(0, '#.00'));

		$this->setFocus($this->ChosenTitlePrice->getClientId());
	}
	
}
