<?php
/**
 * InvoiceInsertPage class file
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 */

/**
 * InvoiceInsertPage class
 *
 * @author Max Pigozzi <mpigozzi@e-portaltech.it>
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Pages.Acquisition
 * @since 2.1
 */

class InvoiceInsertPage extends ClavisPage 
{
	public $_module = 'ACQUISITION';

	private $_invoice;
	private $_itemId;
	
	public $_systemCurrency;

	public function onLoad($param)
	{
		parent::onLoad($param);

		$this->_systemCurrency = ClavisParamQuery::getParam('CLAVISPARAM','SystemCurrency');
		if (!$this->getIsPostBack() && !$this->getIsCallback())		// first page cycle
		{
			$this->CloseInvoice->setEnabled(false);
			
			$id = intval($this->getRequest()->itemAt('id'));
			if ($id > 0)
			{
				$invoice = InvoiceQuery::create()->findPk($id);
				if (!($invoice instanceof Invoice)) 
				{
					$this->writeMessage(Prado::localize("La fattura d'acquisto con id = {id} non esiste",
														array('id' => $id))
										,ClavisMessage::ERROR);
					$this->gotoPage('Acquisition.InvoiceListPage');
				} elseif($invoice->getInvoiceStatus() == InvoicePeer::INVOICESTATUS_CLOSED) {
                    $this->writeMessage(Prado::localize("La fattura d'acquisto con id = {id} è chiusa",
                            array('id' => $id))
                        ,ClavisMessage::ERROR);
                    $this->gotoPage('Acquisition.InvoiceListPage');
                }

			} 
			else 
			{
				$invoice = new Invoice();
				$invoice->setLibrary($this->getUser()->getActualLibrary());
			}
			$this->setInvoice($invoice);

			$itemId = intval($this->getRequest()->itemAt('itemId'));
			if ($itemId > 0)
				$this->setItemId($itemId);

			$this->Library->setDataSource(LibraryPeer::getLibrariesHash(null, null, null, true));  // only internal
			$this->Library->dataBind();
			
			if ($invoice->isNew()) 
			{
				$this->DeleteInvoice->setEnabled(false);
				///$this->InvoiceItemList->setShowInvoiceCol(false);
			} 
			else 
			{
				$this->DeleteInvoice->setEnabled(true);
				$this->InvoiceItemList->setInvoice($this->_invoice);
				///$this->InvoiceItemList->setShowInvoiceCol(true);
				$this->InvoiceItemList->populate();
			}

			$this->populate();
			$this->UpdateData->setObject($this->_invoice);
			
			$this->CloseInvoice->setEnabled($invoice->getInvoiceStatus() == InvoicePeer::INVOICESTATUS_OPEN);
		} 
		elseif ($this->getIsPostBack() && !$this->getIsCallback()) 
		{
			$this->getInvoice();
		} 

		if ($this->getIsPostBack() || $this->getIsCallback())	// not first page cycle
		{
			$updateClavisItemList = $this->getApplication()->getSession()->itemAt('UpdateClavisItemList');
			if ($updateClavisItemList)
			{
				$this->getApplication()->getSession()->remove('UpdateClavisItemList');
				$this->InvoiceItemList->populate();
				
				if ($this->getIsCallback())
					$this->InvoiceItemListPanel->render($this->createWriter());
			}
		}
	}

	public function checkAuth($addedCheck = true, $force = null)
	{
		$allow = true;
		$invoice = $this->getInvoice();

		if (($invoice instanceof Invoice))
			$allow = $this->getUser()->getEditPermission($invoice);
		parent::checkAuth($allow);
	}
	
	public function setItemId($itemId) 
	{
		$this->_itemId = $itemId;
		$this->getApplication()->getSession()->add('item_id', $itemId);
	}
	
	public function getItemId() 
	{
		$this->_itemId = $this->getApplication()->getSession()->itemAt('item_id');
		return $this->_itemId;
	}

	public function setInvoice(Invoice $invoice) 
	{
		$this->_invoice = $invoice;
		$this->setViewState('invoice', $invoice, null);
	}
	
	public function getInvoice() 
	{
		$this->_invoice = $this->getViewState('invoice', null);
		return $this->_invoice;
	}
	
	public function populate() 
	{
		if (!($this->_invoice instanceof Invoice))
			return;
		
		$this->InvoiceNumber->setText($this->_invoice->getInvoiceNumber());
		$this->InvoiceStatus->setText($this->_invoice->getInvoiceStatusString());
		$this->InvoiceDate->setTimestamp($this->_invoice->getInvoiceDate('U'));
		$this->LibraryId->setValue($this->_invoice->getLibraryId());
		$this->Library->setSelectedValue($this->_invoice->getLibraryId());

		$this->ExtraCost->setText(ClavisBase::numberFormat($this->_invoice->getCurrierPrice(), '#.00'));
		$this->Supplier->setText($this->_invoice->getSupplierName());
		$this->SupplierId->setValue($this->_invoice->getSupplierId());
	}

	public function onSaveInvoice($sender,$param)
	{
        if (!$this->getIsValid()) {
            return false;
        }
		$destinationParam = $param->CommandParameter;
		
		$isNew = $this->_invoice->isNew();

		$this->_invoice->setInvoiceNumber($this->InvoiceNumber->getSafeText());
		///////$this->_invoice->setInvoiceStatus($this->InvoiceStatus->getSelectedValue());
		$this->_invoice->setInvoiceDate($this->InvoiceDate->getTimestamp());
		$this->_invoice->setLibraryId($this->Library->getSelectedValue());

		$this->_invoice->setCurrierPrice(floatval(ClavisBase::numberFormat($this->ExtraCost->getSafeText(), '#.00', null, false)));
		$this->_invoice->setSupplierId($this->SupplierId->getValue());
		$this->_invoice->save();

		if ($isNew) {
			ChangelogPeer::logAction($this->_invoice, ChangelogPeer::LOG_CREATE, $this->getUser(), 'creata fattura');
			$this->writeMessage(Prado::localize('Fattura inserita correttamente. Aggiungere gli esemplari o l\'ordine.'),
				ClavisMessage::INFO);
		} else {
			ChangelogPeer::logAction($this->_invoice, ChangelogPeer::LOG_UPDATE, $this->getUser(), "modificati dati fattura");
			$this->writeMessage(Prado::localize('Fattura modificata correttamente'),ClavisMessage::INFO);
		}
		
		if ($destinationParam == "Goto")
			$this->gotoPage('Acquisition.InvoiceViewPage', array('id' => $this->_invoice->getInvoiceId()));
		else
			$this->gotoPage('Acquisition.InvoiceInsertPage', array('id' => $this->_invoice->getInvoiceId()));
	}

	/**
	 * It is called by one of the inner components, and
	 * performs the population (refresh) of all the components
	 * (the calling is included).
	 *
	 */
	public function globalRefresh()
	{
		$this->getInvoice();

		$this->InvoiceItemList->setInvoice($this->_invoice);
		$this->InvoiceItemList->populate();
	}

	/**
	 * It's called by one of the inner componentes, and
	 * performs the "cancel" (return to non-edit status)
	 * of all the components (the calling is included).
	 *
	 * @param TControl $component
	 */
	public function globalCancel($component)
	{
	}

	/**
	 * Exits the editing, without doing anything.
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onCancel($sender, $param)
	{
		$invoice = $this->getInvoice();
		if ($invoice instanceof Invoice)
			$invoiceId = $invoice->getInvoiceId();
		else
			$invoiceId = 0;

		if ($invoiceId > 0)
			$this->gotoPage('Acquisition.InvoiceViewPage', array('id' => $invoiceId));
		else
			$this->gotoPage('Acquisition.InvoiceViewPage');
	}

	/*
	 * Extreme escamotage, for make ClavisItemList find this method, born for the
	 * OrderInsertPage
	 */
	public function OnInvoiceIdChanged($sender,$param)
	{

	}

    /*
	 * Validation of unique InvoiceNumber and Supplier ID
	 * OrderInsertPage
	 */
    public function onValidateInvoiceNumber($sender,$param)
    {
        $candidateInventoryNumber = $param->getValue();
        $supplierId = intval($this->SupplierId->getValue());
        /* @var $invoice Invoice */
        $invoice = $this->getInvoice();
        if(!$invoice->isNew() && $invoice->getInvoiceNumber() == $candidateInventoryNumber) {
            $param->IsValid = true;
            return true;
        }

        if($supplierId > 0 && trim($candidateInventoryNumber) != "" ) {

            $invoiceCount = InvoiceQuery::create()
                ->filterBySupplierId($supplierId)
                ->filterByInvoiceNumber($candidateInventoryNumber)
                ->count();
            if($invoiceCount > 0) {
                $param->IsValid = false;
                $this->getPage()->writeMessage(Prado::localize("Il numero fattura {invoice} è già presente",array('invoice' => $candidateInventoryNumber)), ClavisMessage::ERROR);
            } else
                $param->IsValid = true;
        }
    }
	
	public function onDeleteInvoice($sender, $param)
	{
		$done = false;
		
		if ($this->_invoice instanceof Invoice)
		{
			try
			{
				$invoiceId = $this->_invoice->getInvoiceId(); 
				$this->_invoice->delete();

				$done = true;
				ChangelogPeer::logAction($this->_invoice, ChangelogPeer::LOG_DELETE, $this->getUser(), "fattura cancellata, con id=" . $invoiceId);
				$this->writeMessage(Prado::localize('Fattura con id = {id} cancellata',
													array('id' => $invoiceId)), 
									ClavisMessage::CONFIRM);

				$this->gotoPage('Acquisition.InvoiceListPage');
			}
			catch(PropelException $e)
			{
				//throw ($e);
			}
			
		}
		
		if (!$done)
		{
			$this->writeMessage(Prado::localize('Errore su database: fattura non cancellata. Contattare il Centro Servizi descrivendo il problema'), 
								ClavisMessage::ERROR);
			return false;
		}
	}
	
	public function onResetSupplier($sender, $param)
	{
		$this->doResetSupplier($param);
	}

	private function doResetSupplier($param = null)
	{
		$this->Supplier->setText("");
		$this->SupplierId->setValue('');
		
		$this->renderSupplierPanel($param);
	}
	
	public function renderSupplierPanel($param = null)
	{
		if (is_null($param))
			$writer = $this->createWriter();
		else
			$writer = $param->getNewWriter();

		$this->SupplierPanel->render($writer);
	}
	
	public function onCloseInvoice($sender, $param)
	{
		$invoice = $this->getInvoice();
		if (!($invoice instanceof Invoice))
		{
			$this->getPage()->writeMessage(Prado::localize("Errore nel passaggio parametri fattura"),
												ClavisMessage::ERROR);
					return;
		}
		
		try
		{
			$invoice->setInvoiceStatus(InvoicePeer::INVOICESTATUS_CLOSED);
			$invoice->save();
			
			ChangelogPeer::logAction($invoice, ChangelogPeer::LOG_UPDATE, $this->getUser(), "chiusa fattura");
			$this->writeMessage(Prado::localize('Fattura chiusa correttamente'),
									ClavisMessage::INFO);
			
			$this->reloadPage();
		}
		catch (Exception $error)
		{
			$error = $error;
			//throw($error);

			$this->getPage()->writeMessage(Prado::localize("Errore nella procedura di chiusura della fattura"),
												ClavisMessage::ERROR);
				return;
		}
	}
	
}
