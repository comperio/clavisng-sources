<?php
/**
 * BulkOrderInsert class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Dario Rigolin <dario@comperio.it>
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 ePortal Technologies
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Pages.Acquisition
 */

/**
 * BulkOrderInsert Class
 *
 * @author Dario Rigolin <dario@comperio.it>
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Pages.Acquisition
 * @since 2.6
 */
class BulkOrderInsert extends ClavisPage
{
    public $_module = "ACQUISITION";
    private $riga = 1;

    public function onLoad($param)
    {
        $this->Rows->Text = "";
		
		// first page cycle
		if (!$this->getIsPostBack() && !$this->getIsCallback())
		{
			$this->OrderType->setSelectedValue(PurchaseOrderPeer::TYPE_SUPPLIER);
			$this->OrderStatus->setSelectedValue(PurchaseOrderPeer::STATUS_OPEN);
			$this->ItemStatus->setSelectedValue(ItemStatus::ITEMSTATUS_INORDER);
			$this->ItemOrderStatus->setSelectedValue(ItemStatus::ITEMORDERSTATUS_INORDER);
			$this->InvoiceStatus->setSelectedValue(InvoicePeer::INVOICESTATUS_OPEN);
		}
    }

    public function LoadCSV($sender, $param)
    {
        if ($sender->HasFile) {
            $this->Result->Text = $this->Result->Text . " You just uploaded a file:<br/>Name: {$sender->FileName} {$sender->LocalName} <br/>Size: {$sender->FileSize}<br/>Type: {$sender->FileType}";
        }
    }

    public function LoadAndProcess($sender, $param)
    {
        if ($this->CSVUpload->HasFile) {

            $allOK = $this->ImportCSV(true);
            if(!$this->Simulation->Checked && $allOK)
            {
                $this->ImportCSV(false);
            } elseif(!$this->Simulation->Checked) {
                $this->Result->Text = "L'ordine non è stato creato.";
            } elseif($this->Simulation->Checked) {
                $this->Result->Text = "Simulazione eseguita";
            }
        }
    }

    /**
     * Import/simulate a massive order. Creates an order and items and manifestation.
     * Performs various checks about Budget availability, existence of the EAN, budget
     * library
     *
     * @param bool $isSimulation
     * @return bool return true if is safe to import
     */
    public function ImportCSV($isSimulation = true)
    {
        $allOK = true;
        $budgetsSum = array();
        $priceAlert = (float)ClavisParamQuery::getParam('CLAVISPARAM','AcquisitionMaxPriceLimit');

        $fin = fopen($this->CSVUpload->LocalName, "r");
        $header = fgetcsv($fin, null, ";");
        $this->Rows->Text = "";
        $columns = count($header);
        for ($i = 0; $i < $columns; $i++)
            $header[strtoupper($header[$i])] = strtoupper($header[$i]);

        $fileOK = true;

        foreach(array('ISBN-13','SCONTO','IMPORTO','BIB','BUDGET','ANNO','TITOLO','AUTORE','EDITORE') as $cn)
            if(!isset($header[$cn])) {
                $this->LogMessage("ERRORE","IL file non ha una colonna '{$cn}' ",true);
                $fileOK = false;
            }

        if(!$fileOK) return false;

        $order = null;
        $manifs = array();
        $items = array();
        $invoice = null;

        $supplier_id = intval($this->SupplierId->Value);
        $supplier = SupplierPeer::retrieveByPK($supplier_id);

        while ($r = fgetcsv($fin, null, ";")) {
            $this->riga++;
            $row = array();
            for ($i = 0; $i < $columns; $i++)
                $row[strtoupper($header[$i])] = mb_convert_encoding(trim($r[$i]),'UTF-8','AUTO, ISO-8859-1, ISO-8859-15, WINDOWS-1252');

            $row['ISBN-13'] = str_replace("-","",$row['ISBN-13']);
            $row['SCONTO'] = str_replace(",", ".", $row['SCONTO']);
            $row['SCONTO'] = str_replace("%", "", $row['SCONTO']);

            if($this->NetPrices->getChecked())
            {
                $row['IMPORTO'] = round(floatval(str_replace(",", ".", $row['IMPORTO'])),2);
                $row['PREZZO'] = round(100.0 * floatval($row['IMPORTO']) / (100.0 - floatval($row['SCONTO'])),2);
            }  else {
                $row['PREZZO'] = round(floatval(str_replace(",", ".", $row['IMPORTO'])),2);
                $row['IMPORTO'] = round(floatval($row['PREZZO']) - ( floatval($row['PREZZO']) / 100.0  * floatval($row['SCONTO'])),2 );
            }

            if($supplier instanceof Supplier && floatval($supplier->getDiscount()) > 0.0 && $row['SCONTO'] != $supplier->getDiscount())
                $this->LogMessage("ATTENZIONE","Sconto {$row['SCONTO']} diverso dallo sconto fornitore",true);

            $row['Lib'] = 0;
            $lib = LibraryQuery::create()->findOneByLibraryCode($row['BIB']);
            if ($lib instanceof Library)
                $row['Lib'] = $lib->getLibraryId();
            else {
                $this->LogMessage("ERRORE","Biblioteca non trovata ({$row['BIB']}) ",true);
                $allOK = false;
            }
            $budget = BudgetQuery::create()
                ->filterByEndValidity(time(),Criteria::GREATER_EQUAL)
                ->findOneByBudgetTitle("{$row['BIB']} {$row['BUDGET']}");

            $row['Budcla'] = 0;
            if ($budget instanceof Budget) {
                if(isset($budgetsSum[$budget->getBudgetId()]))
                    $budgetsSum[$budget->getBudgetId()] += floatval($row['IMPORTO']);
                else
                    $budgetsSum[$budget->getBudgetId()] = floatval($row['IMPORTO']);

                $row['Budcla'] = $budget->getBudgetId();
            }
            else {
                $this->LogMessage("ERRORE","Budget non trovato ({$row['BIB']} {$row['BUDGET']}) ",true);
                $allOK = false;
            }
            if(!ClavisBase::checkEanValid($row['ISBN-13']))
                $this->LogMessage("ATTENZIONE","EAN Non valido: ({$row['ISBN-13']}) ",true);

            $man = null;
            if(trim($row['ISBN-13']) != "" && ClavisBase::checkEanValid($row['ISBN-13'])) {
                $man = ManifestationQuery::create()->findOneByEan($row['ISBN-13']);
                if($man == null) {
                    $man = ManifestationQuery::create()->findOneByIsbnissn($row['ISBN-13']);
                    if($man == null) {
                        $isbn10 = Clavis::Ean13ToIsbn($row['ISBN-13']);
                        $man = ManifestationQuery::create()->findOneByIsbnissn($isbn10);
                        if($man == null) {
                            $isbn10 = Clavis::hyphenateStdNum($isbn10);
                            $man = ManifestationQuery::create()->findOneByIsbnissn($isbn10);
                        }
                    }
                }
            }

            if ($man instanceof Manifestation)
                $row['Manif'] = $man->getManifestationId() . " " . $man->getTitle();
            else {
                // Search into the ISBN for an ISBN-13
                if ($man instanceof Manifestation)
                    $row['Manif'] = $man->getManifestationId() . " " . $man->getTitle();
                else if (!$isSimulation) {
                    // Not found Manifestation then create a new one.
                    $man = new Manifestation();
                    $tm = TurboMarc::createRecord();

                    $l = new TurboMarcLeader();
                    $l->recLen = '01234';
                    $l->recstatus = 'n';

                    $l->biblevel = ManifestationPeer::LVL_MONOGRAPHIC;
                    $l->type = 'a';

                    $tm->setLeader($l);

                    $ldr = new TurboMarcLeader();
                    $ldr->biblevel = "m";
                    $ldr->hiercode = "0";
                    $ldr->type = "a";
                    $tm->setLeader($ldr);

                    $f100 = $tm->addCDField("100");
                    $f100->setCDF("a", 0, date('Ymd'));
                    if (intval($row['ANNO']) > 0) {
                        $f100->setCDF('a', 9, substr($row['ANNO'], 0, 4));
                        $f100->setCDF('a', 8, 'd');
                    }
                    $f073 = $tm->addField("073");
                    $f073->addSubField("a", $row['ISBN-13']);
                    $f073->addSubField("d", $row['PREZZO']);
                    $f200 = $tm->addField("200");
                    $f200->addSubField("a", $row['TITOLO']);
                    $f200->addSubField("f", $row['AUTORE']);
                    $f210 = $tm->addField("210");
                    $f210->addSubField("a","s.l.");
                    $f210->addSubField("c", $row['EDITORE']);
                    $f210->addSubField("d", $row['ANNO']);

                    $man = ManifestationPeer::createFromTurbomarc($tm);
                    $man->setManifestationStatus(ManifestationPeer::STATUS_IMPORT);

                    $man->syncAuthor();
                    $man->syncTitle();

                    $man->setBibLevel(ManifestationPeer::LVL_MONOGRAPHIC);
                    $man->setBibTypeFirst('1');
                    $man->setBibType('a01');
                    $man->setEan($row['ISBN-13']);
                    $man->save();
                    $man->reload(true);
                    $man->setQuick(true);

                    $man->save();
                    $man->doIndex();

                    $row['Manif'] = $man->getManifestationId() . " " . $man->getTitle();

                    $manifs[] = $man;
                } else {
                     $this->LogMessage("Crea notizia","{$row['TITOLO']} ")   ;
                }
            }

            if ($order == null) {

                if (!$isSimulation ) {
                    $order = new PurchaseOrder();
                    $order->setLibraryId($this->getUser()->getActualLibraryId());

                    $order->setOrderDate(time());
                    $order->setOrderNote("Ordine massivo");
                    $order->setOrderTitle(trim($this->OrderDesc->getSafeText()));
                    if ($supplier_id > 0)
                        $order->setSupplierId($supplier_id);
                    $order->setOrderType($this->OrderType->getSelectedValue());
                    $order->setDeliveryDate($this->OrderDelivery->getTimestamp());
                    $order->setOrderDiscount($row['SCONTO']);
                    $order->setOrderStatus($this->OrderStatus->getSelectedValue());
                    $order->save();
                    $orderUrl = $this->getPage()->getService()->constructUrl("Acquisition.OrderViewPage", array("id"=>$order->getOrderId()), null, false);
                    $this->Result->Text = "Ordine ID {$order->getOrderId()} creato. <a href=\"{$orderUrl}\">Vedi</a>";
                } else {
                    //  $this->LogMessage("Creato ordine");
                    $order = true;
                }
            }

            if (!$isSimulation && ($man instanceof Manifestation) && ($row['Lib'] > 0) && ($row['Budcla'] > 0) ) {
                $itemId = $order->addItemToOrder($man->getManifestationId(), $row['Lib'], $row['PREZZO'], $row['IMPORTO']);
                $item = ItemQuery::create()->findPk($itemId);
                $item->setItemStatus($this->ItemStatus->getSelectedValue());
				$item->setItemOrderStatus($this->ItemOrderStatus->getSelectedValue());
                $item->setBudgetId($row['Budcla']);
                $item->setOwnerLibraryId($row['Lib']);
                $item->setHomeLibraryId($row['Lib']);
                $item->setActualLibraryId($row['Lib']);
                $item->setDiscountValue($row['SCONTO']);

                if($supplier_id > 0)
                    $item->setSupplierId($supplier_id);

                if($this->Invoice->getChecked()) {
                    if($invoice === null) {
                        $invoice = new Invoice();
                        $invoice->setLibraryId($this->getUser()->getActualLibraryId());
                        $invoice->setInvoiceStatus($this->InvoiceStatus->getSelectedValue());

                        if($supplier_id > 0 )
                            $invoice->setSupplierId($supplier_id);
                        $invoice->setInvoiceNumber($this->InvoiceDescr->getSafeText());
                        $invoice->save();
                    }
                    $item->setInvoiceId($invoice->getInvoiceId());

                }
                $item->save();
                $items[] = $itemId;
            } else {
                $eanOK = ClavisBase::checkEanValid($row['ISBN-13']);
                if(!$eanOK) $this->LogMessage("EAN {$row['ISBN-13']} ERRATO titolo {$row['TITOLO']}",true);
                if($man instanceof Manifestation)
                {
                    if(null !== ItemQuery::create()
                        ->filterByHomeLibraryId($row['Lib'])
                        ->filterByManifestationId($man->getManifestationId())
                        ->findOne()) {
                        $this->LogMessage("ATTENZIONE"," EAN GIA' IN BIBLIOTECA {$row['ISBN-13']}  titolo {$row['TITOLO']} all'ordine {$row['BIB']}",true);
                    }
                }

                $this->LogMessage("Aggiunto titolo","{$row['TITOLO']} all'ordine {$row['BIB']} [Netto: " . ClavisBase::numberFormat($row['IMPORTO'],'c') . "] [Lordo: " . ClavisBase::numberFormat($row['PREZZO'],'c') . "] Sconto: {$row['SCONTO']}");
            }

            if($row['IMPORTO'] > $priceAlert)
                $this->LogMessage("ATTENZIONE","L'importo " . ClavisBase::numberFormat($row['IMPORTO'],'c') . " è anomalo",true);

        }
        foreach($budgetsSum as $budgetId=>$ammount) {
            $budget = BudgetPeer::retrieveByPK($budgetId);
            if($budget instanceof Budget) {
                $available = $budget->getInvoicedCombo();
                $allOK = $allOK && ($available['RestAllocated'] >= $ammount);
                $this->LogMessage("Resoconto budget","{$budget->getBudgetTitle()} Importo Richiesto: " . ClavisBase::numberFormat($ammount,'c') .  " Importo Disponibile: " . ClavisBase::numberFormat($available['RestAllocated'],'c') ,($available['RestAllocated']<$ammount));
            }
        }
        fclose($fin);

        return $allOK;
    }

    public function LogMessage($azione,$message,$alert=false)
    {
        if($alert)
            $this->Rows->Text = $this->Rows->Text . "<tr><td>{$this->riga}</td><td><b>$azione</b></td><td><span style=\"color: red; font-weight: bold;\">$message</span></td></tr>";
        else
            $this->Rows->Text = $this->Rows->Text . "<tr><td>{$this->riga}</td><td>$azione</td><td>$message</td></tr>";
    }
}
