<?php
/**
 * ManagePurchaseLists class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Ciro Mattia Gonano
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 ePortal Technologies
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Pages.Acquisition
 */

/**
 * ManagePurchaseLists Class
 *
 * @author Ciro Mattia Gonano
 * @version 2.7
 * @package Pages.Acquisition
 * @since 2.5.0
 */
class ManagePurchaseLists extends ClavisPage
{
	const MAX_RESULTS = 30;
	public $_module = 'ACQUISITION';
	private $lookup_bl;

	public function onLoad($param)
	{
		parent::onLoad($param);

		/* preload lookups for biblevel */
		$this->lookup_bl = LookupValuePeer::getLookupClassValues('LIVBIBL');
		if (!$this->getIsPostBack() && !$this->getIsCallback())
		{
			if ($this->Request->contains('orderid'))
			{
				$this->ShelfSelectPanel->setVisible(false);
				$this->OrderSelectPanel->setVisible(true);
				$order = PurchaseOrderPeer::retrieveByPK($this->Request['orderid']);
				
				if ($order instanceof PurchaseOrder)
				{
					$this->OrderData->Text = $order->getOrderTitle();
					$this->OrderId->Value = $order->getOrderId();
				}
				else
				{
					$this->writeMessage(Prado::localize('Impossible trovare l\'ordine richiesto'),
										 ClavisMessage::ERROR);
				}
			}
			else
			{
				$this->ShelfSelectPanel->setVisible(true);
				$this->OrderSelectPanel->setVisible(false);
			}

			$this->populate();
		}
	}

	public function isOrderMode()
	{
		return $this->Request->contains('orderid');
	}

	public function populate()
	{
		
	}

	public function cleanSearch($sender, $param)
	{
		$this->EAN->setText('');
		$this->Title->setText('');
		$this->Author->setText('');
	}

	private function getSearchParams()
	{
		$params = array();
		$title = trim($this->Title->getSafeText());
		
		if ($title != '')
			$params['title'] = $title;
		
		$ean = trim($this->EAN->getSafeText());
		
		if ($ean != '')
			$params['ean'] = $ean;
		
		$author = trim($this->Author->getSafeText());
		
		if ($author != '')
			$params['author'] = $author;
		
		$publisher = trim($this->Publisher->getSafeText());
		
		if ($publisher != '')
			$params['publisher'] = $publisher;
		
		$serie = trim($this->Serie->getSafeText());
		
		if ($serie != '')
			$params['serie'] = $serie;

		return $params;
	}

	public function doSearch($sender, $param)
	{
		$searchParams = $this->getSearchParams();
		
		if (count($searchParams) < 1)
		{
			$this->getPage()->writeMessage(Prado::localize('È necessario specificare almeno un parametro di ricerca'),
												  ClavisMessage::ERROR);
			
			return;
		}
		
		$catalogDataSource = $this->search($this->getApplication()->getModule('search'), $searchParams);
		$purchaseDataSource = array();
		
		if (ClavisParamQuery::getParam('CLAVISPARAM', 'BookSellersServerUrl'))
		{
			$extSearch = new SolrSearch();
			$extSearch->setServerURL(ClavisParamQuery::getParam('CLAVISPARAM', 'BookSellersServerUrl'));
			$extSearch->setDatabaseName(null);
			$extSearch->setRecordCollection(null);
			$purchaseDataSource = $this->search($extSearch, $searchParams);
		}
		
		$this->CatalogResultGrid->setDataSource($catalogDataSource);
		$this->CatalogResultGrid->dataBind();
		$this->PurchaseResultGrid->setDataSource($purchaseDataSource);
		$this->PurchaseResultGrid->dataBind();
	}

	protected function prepareResult($turbomarc)
	{
		$tm = TurboMarc::createRecord($turbomarc);
		
		// remove 950 - we don't import items!
		unset($tm->d950);
		
		$ret = array('Turbomarc' => $tm->asXML());
		$l = $tm->getLeader();
		$ret['BibLevelCode'] = $l->biblevel;
		$ret['BibLevelLabel'] = (array_key_exists($ret['BibLevelCode'], $this->lookup_bl)) ?
				$this->lookup_bl[$ret['BibLevelCode']] : '---';
		$ret['Title'] = $tm->getFullTitle();
		$ret['Author'] = $tm->getAuthor();
		$ret['EAN'] = $tm->getEAN();
		$ret['Editions'] = implode(' - ', $tm->getEditions());
		$ret['Publications'] = implode(' - ', $tm->getPublications());
		$ret['Series'] = implode(' - ', $tm->getSeries());
		$ret['Dewey'] = $tm->getDewey();
		$ret['Subjects'] = implode(', ', $tm->getSubjects());
		$ret['PartOf'] = array_key_exists('d461', $tm) ? "{$tm->d461->st} [{$tm->d461->s1}]" : '';
		$ret['Note'] = (string) $tm->d300->sa;
		$ret['ListPrice'] = (string) $tm->d073->sd;
		
		return $ret;
	}

	public function resultAction($sender, $param)
	{
		if (!$this->isValid)
			return false;

		$shelf = null;
		$order = null;

		if ($this->isOrderMode())
		{
			$order = PurchaseOrderPeer::retrieveByPK($this->Request['orderid']);
			
			if (!$order instanceof PurchaseOrder)
				return false;
		}
		else
		{
			$shelf = ShelfQuery::create()->findPk($this->ShelfId->getValue());
			
			if (!$shelf instanceof Shelf)
				return false;
		}

		switch ($param->getCommandName())
		{
			case 'importAndAddToShelf':
				$turbomarc = $param->getCommandParameter();
				$tm = TurboMarc::createRecord($turbomarc);
				$m = ManifestationPeer::createFromTurbomarc($tm);
				$m->doIndex();
				
				break;
			
			case 'addToShelf':
				$m = ManifestationQuery::create()->findPk($param->getCommandParameter());
				
				break;
		}

		if ($m instanceof Manifestation)
		{
			if ($this->isOrderMode())
			{
				$lib = $order->getLibrary();
				
				if (!$lib instanceof Library)
					$lib = $this->User->getActualLibrary();
				
				$supplier = $order->getSupplier();
				$discount = 0.0;
				
				if ($supplier instanceof Supplier)
					$discount = $order->getSupplier()->getDiscount();

				$listprice = 0.0;
				$ean = $m->getEan();
				
				if ($ean != "")
				{
					/** @var $cpm CalderonePriceManager */
					$cpm = $this->getApplication()->getModule('price');
					$listPrice = $cpm->getListPrice($ean);
					
					if ($listPrice > 0.0)
						$discount = $listPrice - ($listPrice / 100.0 * $discount);
				}

				$order->addItemToOrder($m->getManifestationId(), $lib->getLibraryId(), $listPrice, $discount);
				$this->writeMessage(Prado::localize('Esemplare correttamente aggiunto all\'ordine'),
										ClavisMessage::CONFIRM);
			}
			else
			{
				$shelf->addItemToShelf(ShelfPeer::TYPE_MANIFESTATION_BUY, $m->getManifestationId());
				$this->writeMessage(Prado::localize('Notizia correttamente aggiunta allo scaffale di acquisto'),
										ClavisMessage::CONFIRM);
			}
		}
	}

	protected function search($searchModule, $searchParams)
	{
		$query = '';
		
		foreach ($searchParams as $k => $v)
		{
			switch ($k)
			{
				case 'title':
					$query .= " +(fldin_txt_title:({$v}))";
					
					break;
				
				case 'ean':
					$query .= " +(fldin_txt_numbers:{$v})";
					
					break;
				
				case 'author':
					$query .= " +(fldin_txt_author:({$v}))";
					
					break;
				
				case 'publisher':
					$query .= " +(mrc_d210_sc:({$v}) OR fldin_txt_publisher:({$v}))";
					
					break;
				
				case 'serie':
					$query .= " +(mrc_d225_sa:({$v}))";
					
					break;
			}
		}
		
		try
		{
			$response = $searchModule->search($query, 0, self::MAX_RESULTS);
			$ds = array();
			
			foreach ($response['response']['docs'] as $key => $result)
				$ds[] = array_merge(array('Id' => $result['Id']), $this->prepareResult($result['turbo_marc']));
			
			$ret = $ds;
		}
		catch (Exception $e)
		{
			$ret = array();
		}
		
		return $ret;
	}

	public function onSuggestShelf($sender, $param)
	{
		$token = $param->getToken();
		
		$shelfList = ShelfQuery::create()
						->filterByShelfItemtype(ShelfPeer::TYPE_MANIFESTATION_BUY)
						->filterByShelfName($token . '%', Criteria::LIKE)
						->find();
		
		$ds = array();
		
		/* @var $shelf Shelf */
		foreach ($shelfList as $shelf)
		{
			$ds[] = array(	'id' => $shelf->getShelfId(),
							'text' => $shelf->getShelfName() );
		}
		
		$sender->setDataSource($ds);
		$sender->dataBind();
	}

	public function onSuggestSelectShelf($sender, $param)
	{
		$id = $sender->Suggestions->DataKeys[$param->selectedIndex];
		$s = ShelfQuery::create()->findPk($id);
		
		if ($s instanceof Shelf)
		{
			$this->ShelfId->setValue($s->getShelfId());
			$this->ShelfLink->setEnabled(true);
		}
		else
		{
			$sender->setText('');
			$this->ShelfId->setValue(null);
			$this->ShelfLink->setEnabled(false);
		}
	}

	public function updateShelfLink($sender, $param)
	{
		$this->ShelfLink->setEnabled(true);
	}

	public function onShelfLink($sender, $param)
	{
		$shelfId = $this->ShelfId->getValue();
		
		if ($shelfId)
			$this->gotoPage('Communication.ShelfViewPage', array('id' => $shelfId));
	}
	
}