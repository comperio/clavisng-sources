<?php

/**
 * InvoiceListPopup Test Page class Module Library
 *
 * @author Max Pigozzi <mpigozzi@e-portaltech.it>
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @copyright Copyright &copy; 2010 Comperio srl
 */

class InvoiceListPopup extends ClavisPagePopup
{

	public $_module = 'ACQUISITION';
		
	public function onInit($param)
	{
		parent::onInit($param);
	
		if (!$this->getIsPostBack() )
		{
		   $paramArray = unserialize($this->getRequest()->itemAt('param'));
		   if (is_array($paramArray) && (count($paramArray) > 0))
			   $this->InvoiceList->setFilters($paramArray);
		}
	}
	
	public function onPreRender($param)
	{
		parent::onPreRender($param);
		
		if (!$this->getIsPostBack() )
			$this->InvoiceList->search();
	}
	
	public function globalRefresh()
	{
		$this->InvoiceList->populate();
	}

	public function globalEditCancel()
	{

		
	}

}
