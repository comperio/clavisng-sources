<?php

/**
 * Subscription Insert Page class Module Acquisition
 *
 * @author Max Pigozzi <mpigozzi@e-portaltech.it>
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @copyright Copyright &copy; 2009 Comperio srl
 */


class SubscriptionInsertPage extends ClavisPage {

	/**
	 * Module where we are.
	 *
	 * @var string
	 */
	public $_module = 'ACQUISITION';

	/**
	 * The subscription object.
	 *
	 * @var Subscription
	 */
	private $_subscription;

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getIsPostBack())
		{
			$sub = SubscriptionPeer::retrieveByPk($this->getRequest()->itemAt('id'));
			if (! $sub instanceof Subscription) {
				$manifestation = ManifestationPeer::retrieveByPK($this->getRequest()->itemAt('manifestationId'));
				if ($manifestation instanceof Manifestation) {
					$sub = new Subscription();
					$sub->setManifestation($manifestation);
				} else {
					$this->writeMessage(Prado::localize('L\'abbonamento specificato non esiste, o non è possibile'.
						' crearne uno nuovo dalla notizia specificata.'),ClavisMessage::ERROR);
					$this->gotoPage('Acquisition.SubscriptionListPage');
				}
			}
			$this->setSubscription($sub);
			$this->setManifestation($sub->getManifestation());
			$this->populate();
			if (!$sub->isNew())
			{
				$this->UpdateData->setObject($this->_subscription);
			}
		} else {
			$this->getSubscription();
		}
	}


 	/**
 	 * Sets the subscription object in the viewstate.
 	 *
 	 * @param Subscription $subscription
 	 */
 	public function setSubscription($subscription)
 	{
 		$this->_subscription = $subscription;
 		$this->setViewState('subscription', $this->_subscription, null);
 	}

 	/**
 	 * Gets the subscription object from the viewstate, and puts it
 	 * in the relative page private variable.
 	 *
 	 * @return Subscription
 	 */
 	public function getSubscription()
 	{
 		if (is_null($this->_subscription))
 			$this->_subscription = $this->getViewState('subscription', null);
		return $this->_subscription;
 	}


 	/**
 	 * Sets the manifestation object in the viewstate.
 	 *
 	 * @param Manifestation $manifestation
 	 */
 	public function setManifestation($manifestation)
 	{
 		$this->setViewState('manifestation', $manifestation, null);
 	}

 	/**
 	 * Gets the manifestation object from the viewstate
 	 *
 	 * @return Manifestation
 	 */
 	public function getManifestation()
 	{
 		return $this->getViewState('manifestation', null);
 	}

 	/**
 	 * If the page private variable "_supplier" is not new
 	 * (already saved on database) it extracts its values and puts
 	 * them in the fields in the page.
 	 *
 	 */
 	public function populate()
 	{
		$this->ManifestationView->setManifestation($this->_subscription->getManifestation());
		$this->ManifestationId->setValue($this->_subscription->getManifestationId());

		$c = new Criteria();
		$c->add(IssuePeer::MANIFESTATION_ID,$this->_subscription->getManifestationId());
		$c->clearSelectColumns()->addSelectColumn(IssuePeer::ISSUE_YEAR);
		$c->setDistinct();
		$c->addDescendingOrderByColumn(IssuePeer::ISSUE_YEAR);
		$stmt = IssuePeer::doSelectStmt($c);
		$volume_ds = array();
		while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
			$volume_ds[$row[0]] = $row[0];
		}
		$this->Volume->setDataSource($volume_ds);
		$this->Volume->dataBind();

		if ($this->_subscription->isNew()) {
 			$this->Library->setText($this->getUser()->getActualLibrary()->getDescription());
 			$this->LibraryId->setValue($this->getUser()->getActualLibraryId());
			$tm = $this->_subscription->getManifestation()->getTurboMarc();
			if (array_key_exists('d110',$tm))
				$this->Frequence->setValue($tm->d110->getCDF('a','1'));
 		} else {
 			$library = $this->_subscription->getLibrary();
	 		if ($library instanceof Library) {
				$this->Library->setText($library->getLabel());
				$this->LibraryId->setValue($library->getLibraryId());
			}
 			$supplier = $this->_subscription->getSupplier();
			if ($supplier instanceof Supplier) {
				$this->Supplier->setText($supplier->getSupplierName());
				$this->SupplierId->setValue($supplier->getSupplierId());
			}
			$budget = $this->_subscription->getBudget();
			if ($budget instanceof Budget) {
				$this->Budget->setText($budget->getBudgetTitle());
				$this->BudgetId->setValue($budget->getBudgetId());
			}

			$vol = $this->_subscription->getVolume();
			if (array_key_exists($vol, $volume_ds))
				$this->Volume->setSelectedValue($vol);

			$this->Year->setText($this->_subscription->getYear());
			$this->Frequence->setValue($this->_subscription->getFrequence());
			$this->Management->setSelectedValue($this->_subscription->getManagement());
			$this->Tolerance->setText($this->_subscription->getTolerance());
			$this->StartDate->setDate($this->_subscription->getStartDate());
			$this->EndDate->setDate($this->_subscription->getEndDate());
			$payment = unserialize($this->_subscription->getPayment());
			if (is_array($payment)) {
				if (array_key_exists('PayType', $payment))
					$this->PayType->setText($payment['PayType']);
				if (array_key_exists('PayData', $payment))
					$this->PayData->setText($payment['PayData']);
				if (array_key_exists('PayCc', $payment))
					$this->PayCc->setText($payment['PayCc']);
				if (array_key_exists('PayPrice', $payment))
					$this->PayPrice->setText($payment['PayPrice']);
				if (array_key_exists('PaySuspended', $payment))
					$this->PaySuspended->setChecked($payment['PaySuspended']=='Y');
			}
			$this->Note->setText($this->_subscription->getNotes());
			$this->SubscriptionStatus->setSelectedValue($this->_subscription->getSubscriptionStatus());
			$this->SubscriptionType->setSelectedValue($this->_subscription->getSubscriptionType());
		}
 	}

	public function onSuggestSupplier($sender, $param) {
		$prefix = $param->getToken();
		$suppList = SupplierPeer::doSuggest($prefix,10);
		$suppData = array();
		/* @var $s Supplier */
		foreach($suppList as $s) {
			$suppData[] = array(
				'id'	=> $s->getSupplierId(),
				'text'	=> $s->getSupplierName());
		}
		$sender->setDataSource($suppData);
		$sender->dataBind();
	}

	public function onSuggestSelectSupplier($sender,$param) {
		$id = $sender->Suggestions->DataKeys[$param->selectedIndex];
		$s = SupplierPeer::retrieveByPK($id);
		if ($s instanceof Supplier) {
			$sender->setText($s->getSupplierName());
			$this->SupplierId->setValue($s->getSupplierId());
		} else {
			$sender->setText('');
			$this->SupplierId->setValue(null);
		}
	}

	public function onSuggestBudget($sender, $param) {
		$prefix = $param->getToken();
		$budgList = BudgetPeer::doSuggest($prefix,10);
		$budgData = array();
		/* @var $s Budget */
		foreach($budgList as $b) {
			$budgData[] = array(
				'id'	=> $b->getBudgetId,
				'text'	=> $b->getBudgetTitle());
		}
		$sender->setDataSource($budgData);
		$sender->dataBind();
	}

	public function onSuggestSelectBudget($sender,$param) {
		$id = $sender->Suggestions->DataKeys[$param->selectedIndex];
		$s = BudgetPeer::retrieveByPK($id);
		if ($s instanceof Budget) {
			$sender->setText($s->getBudgetTitle());
			$this->BudgetId->setValue($s->getBudgetId());
		} else {
			$sender->setText('');
			$this->BudgetId->setValue(null);
		}
	}
 	/**
 	 * It takes the values from the fields in the page and puts
 	 * them in the supplier object of the page, and then
 	 * saves it on database.
 	 * Then it jumps to this same page, and passes by post the
 	 * id of the supplier we just committed, so to view it.
 	 *
 	 * @param TControl $sender
 	 * @param TEventParameter $param
 	 */
 	public function onSave($sender, $param)
 	{
		$this->_subscription->setManifestationId($this->ManifestationId->getValue());
		$this->_subscription->setLibraryId($this->LibraryId->getValue());
		$this->_subscription->setSupplierId($this->SupplierId->getValue());
		$this->_subscription->setBudgetId($this->BudgetId->getValue());
		$this->_subscription->setSubscriptionStatus($this->SubscriptionStatus->getSelectedValue());
		$this->_subscription->setSubscriptionType($this->SubscriptionType->getSelectedValue());
		$this->_subscription->setVolume($this->Volume->getSelectedValue());
		$this->_subscription->setYear($this->Year->getSafeText());
		$this->_subscription->setFrequence($this->Frequence->getValue());
		$this->_subscription->setTolerance($this->Tolerance->getText());
		$this->_subscription->setStartDate($this->StartDate->getTimestamp());
		$this->_subscription->setEndDate($this->EndDate->getTimestamp());
		$this->_subscription->setManagement($this->Management->getSelectedValue());

		$payment = array();
		$payment['PayType'] = $this->PayType->getSafeText();
		$payment['PayData'] = $this->PayData->getSafeText();
		$payment['PayCc'] = $this->PayCc->getSafeText();
		$payment['PayPrice'] = $this->PayPrice->getSafeText();
		$payment['PaySuspended'] = $this->PaySuspended->getChecked()? 'Y':'N';

		$serialized = serialize($payment);
		$this->_subscription->setPayment($serialized);
		$this->_subscription->setNotes($this->Note->getSafeText());

		$wasNew = $this->_subscription->isNew();
		$this->_subscription->save();

		if ($wasNew) {
			ChangelogPeer::logAction($this->_subscription, ChangelogPeer::LOG_CREATE, $this->getUser());
			$this->writeMessage(Prado::localize('Abbonamento creato con successo'), ClavisMessage::INFO);
		} else {
			ChangelogPeer::logAction($this->_subscription, ChangelogPeer::LOG_UPDATE, $this->getUser());
			$this->writeMessage(Prado::localize('Abbonamento modificato con successo'), ClavisMessage::INFO);
		}
		$this->setSubscription($this->_subscription);
		$this->gotoPage('Acquisition.SubscriptionViewPage', array('id' => $this->_subscription->getSubscriptionId()));
	}
}
