<?php

/**
 * SubscriptionViewPage Page class Module Acquisition
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2009 Comperio
 */

class SubscriptionViewPage extends ClavisPage {

	public $_module = 'ACQUISITION';

	protected $_subscriptionId;
	/** @var Subscription */
	protected $_subscription;

	public function onInit($param)
	{
		parent::onInit($param);
		$id = intval($this->getRequest()->itemAt('id'));
		if ($id > 0) {
			$this->setSubscriptionId($id);
			$this->_subscription = SubscriptionPeer::retrieveByPK($id);
			if (! $this->_subscription instanceof Subscription) {
				$this->writeMessage(Prado::localize('L\'abbonamento n. {subscription_id} non esiste',
					array('subscription_id' => $id)),ClavisMessage::ERROR);
				$order = null;
				$this->gotoPage('Acquisition.SubscriptionListPage');
			}
			$this->SubscriptionView->setSubscription($this->_subscription);
			$this->GenerateItems->setSubscription($this->_subscription);
		}

	}
	/**
	 * On the onLoad we populate the textbox "Title" if the proper
	 * value is passed as a get parameter, and we must initialize
	 * EACH instance of repeatable list in the page (by $this->addItem).
	 *
	 * @param unknown_type $param
	 */
	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getIsPostBack()) {
			$this->UpdateData->setObject($this->_subscription);
			$this->Edit->setEnabled($this->getUser()->getEditPermission($this->_subscription));
			
			//1) faccio una query: se esistono gia' esemplari per (manif_id, annata, biblioteca) allora NON abilito il pulsante
			/*$criteria = new Criteria();
			$criteria->add(IssuePeer::MANIFESTATION_ID, $subscription->getManifestationId());
			$criteria->add(IssuePeer::ISSUE_YEAR, $subscription->getVolume());
			$criteria->addJoin(ItemPeer::ISSUE_ID, IssuePeer::ISSUE_ID);
			$criteria->add(ItemPeer::HOME_LIBRARY_ID, $subscription->getLibraryId());
			$count = ItemPeer::doCount($criteria);
			$this->GenerateItems->setVisible($count < 1);
			if ($count >= 1)
				Prado::log(Prado::varDump(ItemPeer::doSelect($criteria)));*/
		}
	}

	public function onSubscriptionEdit($sender, $param)
	{
		$id = intval($this->getRequest()->itemAt('id'));
		if($id > 0)
			$this->gotoPage('Acquisition.SubscriptionInsertPage', array('id'=>$id));
	}

	/**
	 * setter
	 *
	 * @param int $id
	 */
	public function setSubscriptionId($id) {
		$this->_subscriptionId = $id;
		$this->setViewState('subscription_id',$id,null);
	}

	/**
	 * getter
	 *
	 * @return Id
	 *
	 */
	public function getSubscriptionId() {
		if (is_null($this->_subscriptionId))
			$this->_subscriptionId = $this->getViewState('subscription_id',null);
		return $this->_subscriptionId;
	}

	/**
	 * It is called by one of the inner components, and
	 * performs the population (refresh) of all the components
	 * (the calling is included).
	 *
	 */
	public function globalRefresh()
	{
		$this->SubscriptionView->populate();
	}

	/**
	 * It's called by one of the inner componentes, and
	 * performs the "cancel" (return to non-edit status)
	 * of all the components (the calling is included).
	 *
	 * @param TControl $component
	 */
	public function globalCancel($component)
	{
	}
}
