<?php

/**
 * SupplierInsertPage class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @author Max Pigozzi <mpigozzi@expired.org>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Pages.Catalog
 */

/**
 * Supplier Insert Page class Module Acquisition
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.7
 * @package Pages.Acquisition
 * @since 2.0
 *
 * For editing single suppliers.
 *
 */

class SupplierInsertPage extends ClavisPage 
{
	public $_module = 'ACQUISITION';
	private $_supplier;

	public function onInit($param)
	{
		parent::onInit($param);

		if (!$this->getIsPostBack())
		{
			$supplierId = intval($this->getRequest()->itemAt('supplierId'));
			if ($supplierId > 0)
			{
				$supplier = SupplierQuery::create()->findPk($supplierId);
				if (!($supplier instanceof Supplier)) 
				{
					$this->writeMessage(Prado::localize('Fornitore non valido'), 
											ClavisMessage::ERROR);
					
					$this->gotoPage('Acquisition.SupplierList');
				}
				
				$this->setSupplier($supplier);
			}
			else
			{
				$supplier = new Supplier();
				$this->setSupplier($supplier);
			}
		}
	}

	/**
	 * Populates the fields in the page in case that the
	 * supplier already exists on database.
	 * And puts it in the private variable $this->_supplier.
	 *
	 * @param TEventParameter $param
	 */
	public function onLoad($param)
	{
		parent::onLoad($param);
		
		if (!$this->getIsPostBack()) 
		{
			$this->getSupplier();
				
		    if($this->_supplier->isNew()) 
			{
				/*
				$this->NotificationList->setObjectClass('supplier');
				$this->NotificationList->setObjectId(0);
				$this->NotificationList->populate();
				 */
					
			} 
			else 
			{
				$this->populate();
							
				$this->UpdateData->setObject($this->_supplier);
				
				if (!is_null($this->_supplier)) 
				{
					/*
					$this->NotificationList->setObjectClass('supplier');
					$this->NotificationList->setObjectId($this->_supplier->getSupplierId());
					$this->NotificationList->populate();
					 */
				}
			}
		}
		
		$this->getSupplier();
	}

 	/**
 	 * Sets the supplier object in the viewstate.
 	 *
 	 * @param Supplier $supplier
 	 */
 	public function setSupplier($supplier)
 	{
 		$this->_supplier = $supplier;
 		$this->setViewState('supplier', $this->_supplier, null);
 	}

 	/**
 	 * Gets the supplier object from the viewstate, and puts it
 	 * in the relative page private variable.
 	 *
 	 * @return Supplier
 	 */
 	public function getSupplier()
 	{
 		if (($supplier = $this->_supplier) == null)
 		{
 			$supplier = $this->getViewState('supplier', null);
 			$this->_supplier = $supplier;
 		}
		
		return $supplier;
 	}
 	
 
 	/**
 	 * If the page private variable "_supplier" is not new
 	 * (already saved on database) it extracts its values and puts
 	 * them in the fields in the page.
 	 *
 	 */
 	public function populate()
 	{
 		
 		if ($this->_supplier->isNew()) 
		{
 			$this->NewSupplierLabel->setText(Prado::localize('nuovo '));
 			return;
 		} 
		else 
		{
			$this->NewSupplierLabel->setText(' ' );
		}

		$this->SupplierName->setText($this->_supplier->getSupplierName());
		$this->SupplierCode->setText($this->_supplier->getSupplierCode());
		$this->SupplierStatus->setSelectedValue($this->_supplier->getSupplierStatus());
		
		$this->VatCode->setText($this->_supplier->getVatCode());
		$this->PaymentMode->setSelectedValue(intval($this->_supplier->getPaymentMode()));
		$this->CC->setText($this->_supplier->getCc());

		$this->PhoneNumber->setText($this->_supplier->getPhoneNumber());
		$this->PhoneNumber2->setText($this->_supplier->getPhoneNumber2());
		$this->FaxNumber->setText($this->_supplier->getFaxNumber());
		
		$this->ContactName->setText($this->_supplier->getContactName());
		$this->Address->setText($this->_supplier->getAddress());
		$this->City->setText($this->_supplier->getCity());
		
		$this->Province->setText($this->_supplier->getProvince());
		$this->Country->setText($this->_supplier->getCountry());
		$this->Zipcode->setText($this->_supplier->getZipcode());
		
		$this->Notes->setText($this->_supplier->getNotes());
		
		$discount = $this->_supplier->getDiscount();
		if (is_null($discount))
			$discountFormatted = "";
		else
			$discountFormatted = ClavisBase::numberFormat($this->_supplier->getDiscount(), '#.00%');
		$this->Discount->setText($discountFormatted);
 	}

 	/**
 	 * It takes the values from the fields in the page and puts
 	 * them in the supplier object of the page, and then
 	 * saves it on database.
 	 * Then it jumps to this same page, and passes by post the
 	 * id of the supplier we just committed, so to view it.
 	 *
 	 * @param TControl $sender
 	 * @param TEventParameter $param
 	 */
 	public function onSave($sender, $param)
 	{
		if (!$this->getIsValid())
			return false;
				
		$destinationParam = $param->CommandParameter;
		
		$isNew = $this->_supplier->isNew();

		$supplierName = $this->SupplierName->getSafeText();
		$supplierCode = $this->SupplierCode->getSafeText();
		$vatCode = $this->VatCode->getSafeText();
		$supplierStatus = $this->SupplierStatus->getSelectedValue();
		$paymentMode = $this->PaymentMode->getSelectedValue();
		$cc = $this->CC->getSafeText();
		$phoneNumber = $this->PhoneNumber->getSafeText();
		$phoneNumber2 = $this->PhoneNumber2->getSafeText();
		$faxNumber = $this->FaxNumber->getSafeText();
		$contactName = $this->ContactName->getSafeText();
		$address = $this->Address->getSafeText();
		$city = $this->City->getSafeText();
		$province = $this->Province->getSafeText();
		$state = $this->Country->getSafeText();
		$zipcode = $this->Zipcode->getSafeText();
		$notes = $this->Notes->getSafeText();
		if ($this->Discount->getSafeText() == "")
			$discount = null;
		else
			$discount = ClavisBase::numberFormat($this->Discount->getSafeText(), '#.00', null, false);

		$this->_supplier->setSupplierName($supplierName);
		$this->_supplier->setSupplierCode($supplierCode);
		$this->_supplier->setVatCode($vatCode);
		$this->_supplier->setSupplierStatus($supplierStatus);
		$this->_supplier->setPaymentMode($paymentMode);
		$this->_supplier->setCC($cc);
		$this->_supplier->setPhoneNumber($phoneNumber);
		$this->_supplier->setPhoneNumber2($phoneNumber2);
		$this->_supplier->setFaxNumber($faxNumber);
		$this->_supplier->setContactName($contactName);
		$this->_supplier->setAddress($address);
		$this->_supplier->setCity($city);
		$this->_supplier->setProvince($province);
		$this->_supplier->setCountry($state);
		$this->_supplier->setZipcode($zipcode == "" ? null : $zipcode);
		$this->_supplier->setDiscount($discount);
		$this->_supplier->setNotes($notes);
		$this->_supplier->save();

		if ($isNew)
		{
			ChangelogPeer::logAction(	$this->_supplier, 
										ChangelogPeer::LOG_CREATE, 
										$this->getUser() );
			
			$this->writeMessage(Prado::localize('Fornitore inserito con successo'), 
								ClavisMessage::CONFIRM);
		} 
		else 
		{
			ChangelogPeer::logAction(	$this->_supplier, 
										ChangelogPeer::LOG_UPDATE, 
										$this->getUser() );
			
			$this->writeMessage(Prado::localize('Fornitore modificato con successo'), 
			ClavisMessage::CONFIRM);
		}
		
		$this->setSupplier($this->_supplier);
		
		if ($destinationParam == "Goto")
			$this->gotoPage('Acquisition.SupplierPage', array('supplierId' => $this->_supplier->getSupplierId()));
		else
			$this->reloadPage();
 	}
	
	public function onCancel($sender, $param)
	{
		$supplier = $this->getSupplier();
		if ($supplier instanceof Supplier)
		{
			if ($supplier->isNew())
				$this->gotoPage('Acquisition.SupplierInsertPage');
			else
				$this->gotoPage('Acquisition.SupplierPage', array('supplierId' => $supplier->getSupplierId()));
		}
		else
		{
			$this->gotoPage('Acquisition.SupplierList');
		}
	}
	
	public function onCheckDiscountValidity($sender, $param)
	{
		$value = ClavisBase::numberFormat($this->Discount->getSafeText(), '#.00', null, false);

		if (($value < 0.00) || ($value > 100.00))
			$param->isValid = false;
		else
			$param->isValid = true;
		
		return $param->isValid;
	}
	
}
