<?php
/**
 * MultiOrderPopup class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Popups.Catalog
 */

/**
 * MultiOrderPopup Class
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Popups.Catalog
 * @since 2.1
 */
class MultiOrderPopup extends ClavisPagePopup
{
	const STARTITEMNUM = 0;
	const MAXITEMNUM = 50;
	
	public $_decimalSep = '';
	public $_groupSep = '';
	public $_invdecimalSep = '';
	public $_invgroupSep = '';
	
	public $_module = 'CATALOG';
	
	public $_systemCurrency;
	public $_maxPrice;

	private function initVars()
	{
		$this->_systemCurrency = ClavisParamQuery::getParam('CLAVISPARAM','SystemCurrency');
		$this->_maxPrice = (float) ClavisParamQuery::getParam('CLAVISPARAM','AcquisitionMaxPriceLimit');
		
		$separatorData = ClavisBase::getSeparatorData();

		if (array_key_exists('decimal', $separatorData))
			$this->_decimalSep = $separatorData['decimal'];
		
		if (array_key_exists('group', $separatorData))
			$this->_groupSep = $separatorData['group'];
		
		if (array_key_exists('invariantdecimal', $separatorData))
			$this->_invdecimalSep = $separatorData['invariantdecimal'];
		
		if (array_key_exists('invariantgroup', $separatorData))
			$this->_invgroupSep = $separatorData['invariantgroup'];
	}
	
	public function onInit($param)
	{
		parent::onInit($param);
		$this->initVars();

		if (!$this->getIsPostBack() && !$this->getIsCallback())
		{
			$this->ErrorPanel->setVisible(false);
		}
	}

	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->getIsPostBack() && !$this->getIsCallback())
		{
			$this->RealTotNum->setText("0");
			
			$paramArray = unserialize($this->getRequest()->itemAt('param'));

			$orderId = null;
			$manifestationId = null;
			
			if (array_key_exists('orderId', $paramArray))
				$orderId = $paramArray['orderId'];

			if (array_key_exists('manifestationId', $paramArray))
				$manifestationId = $paramArray['manifestationId'];
			
			$this->setOrderId($orderId);
			$this->setManifestationId($manifestationId);
			
			$this->populate();
		}
	}

	public function setOrderId($param = null) 
	{
		$this->setViewState('PurchaseOrderId', $param, null);
	}
	
	public function getOrderId()
	{
		return $this->getViewState('PurchaseOrderId', null);
	}
	
	public function getOrder() 
	{
		$orderId = intval($this->getOrderId());
		if ($orderId > 0)
			return PurchaseOrderQuery::create()->findPk($orderId);
		else
			return null;
	}
	
	public function setManifestationId($param = null) 
	{
		$this->setViewState('ManifestationId', $param, null);
	}
	
	public function getManifestationId()
	{
		return $this->getViewState('ManifestationId', null);
	}
	
	public function getManifestation() 
	{
		$manifestationId = intval($this->getManifestationId());
		if ($manifestationId > 0)
			return ManifestationQuery::create()->findPk($manifestationId);
		else
			return null;
	}
	
	public function populate()
	{
		$price = 0;
		$manifestation = $this->getManifestation();
		if ($manifestation instanceof Manifestation)
		{
			$priceManager = $this->getApplication()->getModule('price');
			$price = $priceManager->getManifestationListPrice($manifestation);
			if (is_null($price))
				$price = 0;
		}
		
		$this->ItemCost->setText(ClavisBase::numberFormat($price, '#.00'));
		
		$discount = 0;
		$order = $this->getOrder();
		if ($order instanceof PurchaseOrder)
		{
			$discount = $order->getOrderDiscount();
			if (is_null($discount))
				$discount = 0;
		}
		
		$this->ItemDiscount->setText(ClavisBase::numberFormat($discount, '#.00%'));
		
		$value = $price - ($price * $discount / 100);
		$this->ItemValue->setText(ClavisBase::numberFormat($value, '#.00'));
		
		$this->ItemOrderStatus->setSelectedValue(ItemStatus::ITEMORDERSTATUS_INORDER);
		
		// libraries list part drawing
		$grid = $this->initLibraryGrid();
		$this->OrderGrid->setDataSource($grid);
		$this->OrderGrid->dataBind();
	}

	private function initLibraryGrid()
	{
		///$budgetSessionArray = $this->getCookieBudgetSession();
	
		$budgetCriteria = new Criteria();
		$dataSource = array();
		$noItemsCount = 0;
		$manifestationId = $this->getManifestationId();
		foreach ($this->getUser()->getLibraries(null, true) as $libraryId => $libraryLabel)		// internal only
		{
			$row = array();

			$row['LibraryId'] = $libraryId;

			if (strlen($libraryLabel) > 35)
				$libraryLabel = mb_substr($libraryLabel, 0, 35, 'utf8') . '...';

			$row['LibraryLabel'] = $libraryLabel;

			$budgetCriteria->clear();
			$budgetCriteria->add(LibraryPeer::LIBRARY_ID, $libraryId);

			$actualDate = date('Y-m-d');
			$budgetCriteria->add(BudgetPeer::START_VALIDITY, $actualDate, Criteria::LESS_EQUAL);
			$budgetCriteria->add(BudgetPeer::END_VALIDITY, $actualDate, Criteria::GREATER_EQUAL);

			$budgetArray = array();
			foreach (BudgetPeer::doSelectJoinLibrary($budgetCriteria) as $budget)
				$budgetArray[$budget->getBudgetId()] = $budget->getCompleteBudgetTitle();

			$itemButtonEnable = false;
			
			if (count($budgetArray) > 0)
				$budgetArray[-1] = Prado::localize("selezionare un budget");
			else
				$budgetArray[-1] = '---';
			
			ksort($budgetArray);
			$row['BudgetDataSource'] = $budgetArray;
			
//			if (array_key_exists($libraryId, $budgetSessionArray))
//			{
//				$budgetDataSourceSelected = $budgetSessionArray[$libraryId];
//				
//				if ((count($budgetArray) > 0) && ($budgetDataSourceSelected > 0))
//				{
//					$itemButtonEnable = true;
//					$noItemsCount++;
//				}
//			}
//			else
//			{
			$budgetDataSourceSelected = -1;
			//}
			
			$row['BudgetDataSourceSelected'] = $budgetDataSourceSelected;
			$row['ItemsNumber'] = 0;
			$row['ItemButtonEnable'] = $itemButtonEnable;
		
			$row['OwnedItemsNum'] = ItemQuery::create()
										->filterByOwnerLibraryId($libraryId)
										->filterByManifestationId($manifestationId)
										->count();
			
			$dataSource[] = $row;
		}
		
		$this->NoItemsCount->setText($noItemsCount);
				
		return $dataSource;
	}
	
//	private function setCookieBudgetSession($data)
//	{
//		setcookie('MultiOrderPopup_BudgetSessionArray', serialize($data));
//	}
//
//	private function getCookieBudgetSession()
//	{
//		if (array_key_exists('MultiOrderPopup_BudgetSessionArray', $_COOKIE))
//			return unserialize($_COOKIE['MultiOrderPopup_BudgetSessionArray']);
//		else
//			return array();
//	}
	
	public function onBudgetChanged($sender, $param)
	{
		$validSelectionFlag = ($sender->getSelectedIndex() > 0); 
				
		$sender->getParent()->getParent()->ItemCountColumn->AddItemButton->setStyle($validSelectionFlag
																						? "display: inline"
																						: "display: none");
		
		$sender->getParent()->getParent()->ItemCountColumn->SubtractItemButton->setStyle($validSelectionFlag
																							? "display: inline"
																							: "display: none");
		
		$oldItemsNum = intval($sender->getParent()->getParent()->ItemCountColumn->RealNewItemsNumber->getText());
		$sender->getParent()->getParent()->ItemCountColumn->RealNewItemsNumber->setText(0);
		$sender->getParent()->getParent()->ItemCountColumn->NewItemsNumber->setText(0);
		$sender->getParent()->getParent()->ItemCountColumn->NewItemsPanel->setStyle($validSelectionFlag
																						? "display: inline"
																						: "display: none");
		
		if ($validSelectionFlag)
		{
			$this->NoItemsCount->setText(intval($this->NoItemsCount->getText()) + 1);
			$this->TotNumPanel->render($this->createWriter());
		}

		if ($oldItemsNum > 0)	// if some item was added for creation
		{
			$totNum = intval($this->RealTotNum->getText());
			$updatedTotNum = intval($totNum - $oldItemsNum);

			$this->RealTotNum->setText($updatedTotNum);
			$this->TotNum->setText($updatedTotNum);
			$this->TotNumPanel->render($this->createWriter());
		}
		else					// 0 items were for creation
		{
			if ((!$validSelectionFlag) && (($noItemsCount = intval($this->NoItemsCount->getText())) > 0))
			{
				$this->NoItemsCount->setText($noItemsCount - 1);
				$this->TotNumPanel->render($this->createWriter());
			}
		}
		
		$sender->getParent()->getParent()->ItemCountColumn->NewItemsPanel->render($this->createWriter());
		
//		$libraryId = $sender->getParent()->getParent()->LibraryColumn->LibraryId->getValue();
//		if ($libraryId > 0)
//			$this->updateCookieBudgetSession($libraryId, $sender->getSelectedValue());
	}

//	private function updateCookieBudgetSession($libraryId, $selected)
//	{
//		$budgetSession = $this->getCookieBudgetSession();
//		
//		if ($selected < 0)
//			unset ($budgetSession[$libraryId]);
//		else
//			$budgetSession[$libraryId] = $selected;
//
//		$this->setCookieBudgetSession($budgetSession);	
//	}
	
	/**
	 * We create the items in order
	 *
	 * @param TControl $sender
	 * @param TEventParameter $param
	 */
	public function onApply($sender, $param)
	{
		if (!$this->getPage()->getIsValid())
			return false;
		
		ini_set("memory_limit", "700M");
		set_time_limit(0);
		
		$this->getPage()->cleanMessageQueue();
		
		$orderId = $this->getOrderId();
		if (!($orderId > 0))
		{
			$this->getPage()->writeMessage(Prado::localize("Ordine non valido"),
											ClavisMessage::ERROR);
			return false;
		}
		
		$manifestation = $this->getManifestation();
		if (!($manifestation instanceof Manifestation))
		{
			$this->getPage()->writeMessage(Prado::localize("Notizia scelta non valida"),
											ClavisMessage::ERROR);
			return false;
		}
		
		$itemCost = ClavisBase::numberFormat($this->ItemCost->getSafeText(), '#.00', null, false);
		$itemDiscount = ClavisBase::numberFormat($this->ItemDiscount->getSafeText(), '#.00%', null, false);
		$itemValue = ClavisBase::numberFormat($this->ItemValue->getSafeText(), '#.00', null, false);
		
		$itemStatus = ItemStatus::ITEMSTATUS_INORDER;     //$this->ItemStatus->getSelectedValue();
		$itemOrderStatus = $this->ItemOrderStatus->getSelectedValue();	//ItemStatus::ITEMORDERSTATUS_INORDER;
		$loanStatus = ItemPeer::LOANSTATUS_AVAILABLE;
		$loanClass = ItemPeer::LOANCLASS_UNAVAILABLE;
	
		$created = 0;
		$errors = 0;
		$errorText = array();
		$okFlag = true;
		$readData = array();
		foreach ($this->OrderGrid->getItems() as $rowItem)
		{	
			if (	$rowItem->ItemType == 'Item'		
					|| $rowItem->ItemType == 'AlternatingItem' )
			{
				$libraryId = intval($rowItem->LibraryColumn->LibraryId->getValue());
				if ($libraryId == 0)
					continue;
				
				$libraryLabel = $rowItem->LibraryColumn->LibraryLabel->getText();
				$budgetId = intval($rowItem->BudgetColumn->BudgetList->getSelectedValue());
				if ($budgetId <= 0)
					$budgetId = null;
				
				$rowItemsNumber = trim($rowItem->ItemCountColumn->RealNewItemsNumber->getText());
								
				if ($rowItemsNumber > 0)   // everything is ok
				{				
					// check for budget amount
					// $itemValue to multiply for $rowItemsNumber is my total value for the row
					
					$budget = BudgetQuery::create()->findPk($budgetId);
					if ($budget instanceof Budget)
					{
						//$totalAmount = $budget->getTotalAmount();
						$invoicedCombo = $budget->getInvoicedCombo();
						if (array_key_exists("RestAllocated", $invoicedCombo))
							$restAllocated = $invoicedCombo["RestAllocated"];
						else
							$restAllocated = 0;
						
						$totalLibraryValue = $itemValue * $rowItemsNumber;
						
						if ($restAllocated < $totalLibraryValue)
						{
							$okFlag = false;
							
							$total = ClavisBase::numberFormat($totalLibraryValue, '#.00') . ' ' . $this->_systemCurrency;
							$sfor = ClavisBase::numberFormat($totalLibraryValue - $restAllocated, '#.00') . ' ' . $this->_systemCurrency;
							$res = ClavisBase::numberFormat($restAllocated, '#.00') . ' ' . $this->_systemCurrency;
							
							$errorText[] = Prado::localize("Attenzione: la spesa preventivata ({total}) per il budget '{budgetTitle}' (id: {budgetId}), biblioteca '{library}', sfora di {sfor} l'ammontare disponibile ({res})",
													array(	'total' => $total,
															'budgetTitle' => $budget->getCompleteBudgetTitle(),
															'budgetId' => $budget->getBudgetId(),
															'library' => $libraryLabel,
															'sfor' => $sfor,
															'res' => $res));
						}
					}
					
					$readData[] = array('LibraryId' => $libraryId,
										'LibraryLabel' => $libraryLabel,
										'BudgetId' => $budgetId,
										'ItemsNumber' => $rowItemsNumber );
				}
			}  // end of the 'if we are in a correct row'
			
			unset($rowItem);  // we are paranoid .....
		}  // end of foreach cycle that reads a row from the screen input
		
		if (count($readData) == 0)
		{
			$this->getPage()->enqueueMessage(Prado::localize("Attenzione: nessun esemplare da creare"),
											ClavisMessage::WARNING);
		}
		elseif (!$okFlag)	// not everything ok: budget is not enough
		{
			$this->ErrorText->setText(implode('<br />', $errorText));
			$this->ErrorPanel->setVisible(true);
			$this->setFocus("anchor_error");
		}
		else   // new item creation part
		{
			$this->ErrorPanel->setVisible(false);
			//$cloneReadData = $readData;
			foreach ($readData as $rowData)		// cycle on libraries ***
			{
				/**
				 * $rowLibrary is a row of the read table. It's an array, with read fields
				 */
				$createdItemsArray = $this->createItem(	$rowData, 
														$manifestation,
														$itemStatus,
														$itemOrderStatus,
														$loanStatus,
						
														$loanClass,
														$itemCost,
														$itemDiscount,
														$itemValue,
														$orderId );
				
				if (is_array($createdItemsArray) && (count($createdItemsArray) == 2))
				{
					if (array_key_exists('createdNum', $createdItemsArray))
					{
						$created += (int) $createdItemsArray['createdNum'];
					}

					if (array_key_exists('errorNum', $createdItemsArray))
						$errors += (int) $createdItemsArray['errorNum'];
				}
				else
				{
					$errors++;
				}
			}		// end of foreach cycle for real item creation (by calling private method) ***

			$this->getPage()->enqueueMessage(($created == 1)
					? Prado::localize("Creato 1 esemplare")
					: Prado::localize("Creati {num} esemplari",array('num' => $created)),
				($created > 0 ? ClavisMessage::CONFIRM : ClavisMessage::WARNING));
			
			if ($errors > 0)
				$this->getPage()->enqueueMessage(Prado::localize("Sono presenti {num} errori nella creazione di esemplari",
																	array('num' => $errors)),
													ClavisMessage::WARNING);
		}

		$this->getPage()->flushMessage();

		if ($created > 0)
			$this->getApplication()->getSession()->add('UpdateClavisItemList', true);
		
		// close popup
		if ($okFlag)
			$this->getPage()->getClientScript()->registerEndScript(__CLASS__.'_js','onReturn(\'\',\'\',true);');
	}
	
	private function createItem(	$rowData, 
									$manifestation,
									$itemStatus,
									$itemOrderStatus,
									$loanStatus,
			
									$loanClass,
									$itemCost,
									$itemDiscount,
									$itemValue,
									$orderId )
	{
		$errorArray = array('createdNum' => 0,
							'errorNum' => 1 );
		
		if (count($rowData) == 0)
			return $errorArray;
		
		if (!($manifestation instanceOf Manifestation))
			return $errorArray;
		
		$mediaType = Clavis::BibtypeToItemmedia($manifestation->getBibType());
		
		try
		{
			$libraryId = intval($rowData['LibraryId']);
			if ($libraryId == 0)
				return $errorArray;
			
			$itemsNumber = intval($rowData['ItemsNumber']);
			if ($itemsNumber == 0)
				// nothing to do or done .....
				return array(	'createdNum' => 0,
								'errors' => 0 );
			
			$budgetId = intval($rowData['BudgetId']);
			if ($budgetId == 0)
				$budgetId = null;
							
			if (($itemsNumber > self::MAXITEMNUM)
				|| ($itemsNumber < self::STARTITEMNUM))
				return $errorArray;
			
			$currentTime = time();
			$systemCurrency = ClavisParamQuery::getParam('CLAVISPARAM','SystemCurrency');
			
			$order = PurchaseOrderQuery::create()->findPk($orderId);
			if ($order instanceof PurchaseOrder)
				$supplierId = $order->getSupplierId();
			else
				$supplierId = null;
					
			$createdNum = 0;
			$errorNum = 0;
			
			for ($index = 0; $index < $itemsNumber; $index++)
			{
				$item = new Item();
				
				$item->setOwnerLibraryId($libraryId);
				$item->setHomeLibraryId($libraryId);
				$item->setActualLibraryId($libraryId);
				
				$item->setManifestation($manifestation);
				$item->setTitle($manifestation->getTitle());
				$item->setManifestationDewey($manifestation->getClass());
				$item->setItemMedia($mediaType);

				$item->setOpacVisible(true);
                
				$item->setItemStatus($itemStatus);
				$item->setItemOrderStatus($itemOrderStatus);
				$item->setLoanStatus($loanStatus);
				$item->setLoanClass($loanClass);
				
				$item->setBudgetId($budgetId);
				
				$item->setInventoryDate($currentTime);	// ????
				
				$item->setCurrency($systemCurrency);		// ?????
				$item->setCurrencyValue($itemCost);
				$item->setDiscountValue($itemDiscount);
				$item->setInventoryValue($itemValue);
				
				$item->setDateDiscarded(null);
				
				$item->setOrderId($orderId);
				$item->setSupplierId($supplierId);
				
				$savedNum = $item->save();

				if ($savedNum == 1)   // check if saving worked or not
				{
					$item->reload(true);   /// for update the barcode, created by a sql trigger
					$itemId = $item->getItemId();
					
					$createdNum++;
					
					ChangelogPeer::logAction($item, ChangelogPeer::LOG_CREATE, $this->getUser(),
											'Creato nuovo esemplare da popup multi order, con id = ' . $itemId);
				}
				else
				{
					$errorNum++;
				}
				
				$item->clearAllReferences(true);	// we are paranoid
			}		// end of for cycle (creation of items)
			
			return array(	'createdNum' => $createdNum,
							'errorNum' => $errorNum );
		}
		catch (Exception $e)
		{
			//throw($e);
			//Prado::log('Exception in MultiOrderPopup->createItem(): '. Prado::varDump($e));			
			return $errorArray;
		}
	}
	
	/**
	 * It is called by one of the inner components, and
	 * performs the population (refresh) of all the components
	 * (the calling is included).
	 *
	 */
	public function globalRefresh()
	{
		//$this->ItemView->populate();
	}

	/**
	 * It's called by one of the inner componentes, and
	 * performs the "cancel" (return to non-edit status)
	 * of all the components (the calling is included).
	 *
	 * @param TControl $component
	 */
	public function globalCancel($component)
	{
		//if ($component !== $this->ItemView)
		//	$this->ItemView->onCancel(null, null);
	}

	/**
	 * Whether this page can have components where the menus
	 * inside can generate unlink menus.
	 *
	 * @return boolean
	 */
	public function isUnlink()
	{
		return true;
	}

	/**
	 * Whether this page can have components where the
	 * menus inside can have the standard links that
	 * popups have.
	 *
	 * @return boolean
	 */
	public function isPopup()
	{
		return true;
	}

	public function onCheckItemCost($sender, $param)
	{
		$value = ClavisBase::numberFormat($this->ItemCost->getSafeText(), '#.00', null, false);
	
		if ($value < 0.00)					// (($value < 0.00) || ($value > $this->_maxPrice))
			$param->isValid = false;
		else
			$param->isValid = true;
		
		return $param->isValid;		
	}
	
	public function onCheckItemDiscount($sender, $param)
	{
		$value = ClavisBase::numberFormat($this->ItemDiscount->getSafeText(), '#.00%', null, false);
	
		if (($value < 0.00) || ($value > 100.00))
			$param->isValid = false;
		else
			$param->isValid = true;
		
		return $param->isValid;		
	}	

	public function onCheckItemValue($sender, $param)
	{
		$value = ClavisBase::numberFormat($this->ItemValue->getSafeText(), '#.00', null, false);
	
		if ($value < 0.00)
			$param->isValid = false;
		else
			$param->isValid = true;
		
		return $param->isValid;		
	}
	
	public function getMinNum()
	{
		return self::STARTITEMNUM;
	}

	public function getMaxNum()
	{
		return self::MAXITEMNUM;
	}
}
