<?php

/**
 * OrderListPage class
 *
 * @author Max Pigozzi <mpigozzi@e-portaltech.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @version 2.7
 * @package Pages.Acquisition
 * @since 2.2
 */

class OrderListPage extends ClavisPage 
{
	public $_module = 'ACQUISITION';
	
	public function onLoad($param)
	{
		parent::onLoad($param);
		
		if (!$this->getIsPostBack() && !$this->getIsCallback())
		{
			$this->globalRefresh();
		}
	}
	
	public function globalRefresh()
	{
		$this->OrderList->populate();
	}

	public function globalEditCancel()
	{
		
	}
	
}
