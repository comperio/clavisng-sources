<?php

/**
 * SupplierPage class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Pages.Catalog
 */

/**
 * Supplier Page class Module Acquisition
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.7
 * @package Pages.Acquisition
 * @since 2.0
 *
 * For viewing single suppliers.
 *
 */

class SupplierPage extends ClavisPage 
{
	public $_module = 'ACQUISITION';

	/* @var Supplier */
	private $_supplier;

	public function onInit($param)
	{
		parent::onInit($param);

		if (!$this->getPage()->getIsPostBack())
		{
			$supplierId = intval($this->Request['supplierId']);
			if ($supplierId == 0)
				$supplierId = intval($this->Request['id']);
			if ($supplierId > 0)
			{
				$supplier = SupplierQuery::create()->findPk($supplierId);
				if (!($supplier instanceof Supplier))
				{
					$this->writeMessage(Prado::localize("Il fornitore con id = {id} non esiste",
														array('id' => $supplierId)),
										ClavisMessage::ERROR);
					$supplier = null;
					$this->gotoPage('Acquisition.SupplierList');
				}

				$this->setSupplier($supplier);
			}
			else
			{
				$supplier = new Supplier();
				$this->setSupplier($supplier);
			}

			$this->EditButton->setEnabled($this->getUser()->getEditPermission($supplier));
			
			if (!$supplier->isNew())
			{	
				$items = ItemQuery::create()
							->filterBySupplierId($this->getSupplierId())
							->find();

				$itemIds = array();
				foreach ($items as $item)
					$itemIds[] = $item->getItemId();
			
				$this->ItemList->setGivenItemIds($itemIds);

				$this->OrderList->setSupplierFilterId($this->getSupplierId());
				
				$this->ListsPanel->setVisible(true);
			}
			else	// is new
			{
				$this->ItemList->setGivenItemIds(array());

				$this->OrderList->setSupplierFilterId(0);
				
				$this->ListsPanel->setVisible(false);
			}
		}
	}

	/**
	 * Populates the fields in the page in case that the
	 * supplier already exists on database.
	 * And puts it in the private variable $this->_supplier.
	 *
	 * @param TEventParameter $param
	 */
	public function onLoad($param)
	{
		parent::onLoad($param);

		if (!$this->Page->getIsPostBack())
			$this->populate();
		
		$this->_supplier = $this->getSupplier();
		
		if ($this->_supplier instanceof Supplier) 
			$this->UpdateData->setObject($this->_supplier);
	}

 	/**
 	 * Setters & getters
 	 */
 	public function setSupplier($supplier)
 	{
 		$this->_supplier = $supplier;
 		$this->setViewState('supplier', $this->_supplier, null);
 	}

 	public function getSupplier()
 	{
 		if (($supplier = $this->_supplier) == null)
 		{
 			$supplier = $this->getViewState('supplier', null);
 			$this->_supplier = $supplier;
 		}
		return $supplier;
 	}

	public function getSupplierId()
	{
		$supplier = $this->getSupplier();
		if ($supplier instanceof Supplier)
			return $supplier->getSupplierId();
		else
			return 0;
	}
	
 	/**
 	 * If the page private variable "_supplier" is not new
 	 * (already saved on database) it extracts its values and puts
 	 * them in the fields in the page.
 	 */
 	public function populate()
 	{
		/** @var $this->_supplier Supplier */
		
 		if($this->_supplier->isNew())
 		{
 			$this->NewSupplierLabel->setText(Prado::localize("nuovo "));
 			return;
 		}

		if (!$this->_supplier->isNew())
			$this->NewSupplierLabel->setText('');

		$discount = $this->_supplier->getDiscount();
		if (is_null($discount))
			$discount = "";
		else
			$discount = ClavisBase::numberFormat($this->_supplier->getDiscount(), '#.00%');
		
		$this->Discount->setText($discount);
		
		$this->SupplierName->setText($this->_supplier->getSupplierName());
		$this->SupplierCode->setText($this->_supplier->getSupplierCode());
		$this->SupplierStatus->setText(LookupValuePeer::getLookupValue('SUPPLIERSTATUS', $this->_supplier->getSupplierStatus()));

		$this->VatCode->setText($this->_supplier->getVatCode());
		$this->PaymentMode->setText(LookupValuePeer::getLookupValue('SUPPLIERPAYMETHOD', intval($this->_supplier->getPaymentMode())));
		$this->CC->setText($this->_supplier->getCc());

		$this->PhoneNumber->setText($this->_supplier->getPhoneNumber());
		$this->PhoneNumber2->setText($this->_supplier->getPhoneNumber2());
		$this->FaxNumber->setText($this->_supplier->getFaxNumber());
		
		$this->ContactName->setText($this->_supplier->getContactName());
		$this->Address->setText($this->_supplier->getAddress());
		$this->City->setText($this->_supplier->getCity());
		
		$this->Province->setText($this->_supplier->getProvince());
		$this->Country->setText($this->_supplier->getCountry());
		$this->Zipcode->setText($this->_supplier->getZipcode());
		
		$this->Notes->setText(nl2br($this->_supplier->getNotes()));
 	}

 	/**
 	 * It takes the values from the fields in the page and puts
 	 * them in the supplier object of the page, and then
 	 * saves it on database.
 	 * Then it jumps to this same page, and passes by post the
 	 * id of the supplier we just committed, so to view it.
 	 *
 	 * @param TControl $sender
 	 * @param TEventParameter $param
 	 */
 	public function onSave($sender, $param)
 	{
		$supplierName = $this->SupplierName->getSafeText();
		$vatCode = $this->VatCode->getSafeText();
		$supplierStatus = $this->SupplierStatus->getSafeText();
		$paymentMode = $this->PaymentMode->getSafeText();
		$phoneNumber = $this->PhoneNumber->getSafeText();
		$faxNumber = $this->FaxNumber->getSafeText();
		$contactName = $this->ContactName->getSafeText();
		$address = $this->Address->getSafeText();
		$zipcode = $this->Zipcode->getSafeText();
		$discount = $this->Discount->getSafeText();

		$this->_supplier->setSupplierName($supplierName);
		$this->_supplier->setVatCode($vatCode);
		$this->_supplier->setSupplierStatus($supplierStatus);
		$this->_supplier->setPaymentMode($paymentMode);
		$this->_supplier->setPhoneNumber($phoneNumber);
		$this->_supplier->setFaxNumber($faxNumber);
		$this->_supplier->setContactName($contactName);
		$this->_supplier->setAddress($address);
		$this->_supplier->setZipcode($zipcode);
		$this->_supplier->setDiscount($discount);

		$wasNew = $this->_supplier->isNew();
		$this->_supplier->save();

		if ($wasNew) 
		{
			ChangelogPeer::logAction(	$this->_supplier,
										ChangelogPeer::LOG_CREATE, 
										$this->getUser());
		} 
		else 
		{
			ChangelogPeer::logAction(	$this->_supplier, 
										ChangelogPeer::LOG_UPDATE, 
										$this->getUser());
		}
		
		$this->setSupplier($this->_supplier);
		$this->gotoPage('Acquisition.SupplierPage', array('supplierId' => $this->_supplier->getSupplierId()));
 	}

	public function onEdit($sender, $param)
	{
		if ($this->_supplier instanceof Supplier)
			$this->gotoPage("Acquisition.SupplierInsertPage", 
							array("supplierId" => $this->_supplier->getSupplierId()) );
	}
	
}
