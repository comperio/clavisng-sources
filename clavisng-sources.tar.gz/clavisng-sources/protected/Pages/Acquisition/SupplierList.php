<?php

/**
 * CircHome Page class Module Acquisizioni
 *
 * @author Dario Rigolin <drigolin@e-portaltech.it>
 * @link http://www.e-portaltech.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @license http://www.e-portaltech.it/license/
 */

class SupplierList extends ClavisPage {

	public $_module = "ACQUISITION";



}

