<?php

/**
 * Acquisition.SubscriptionListPage Page class Module Acquisition
 *
 * @author Max Pigozzi <mpigozzi@e-portaltech.it>
 * @link http://www.e-portaltech.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @license http://www.e-portaltech.it/license/
 */

class SubscriptionListPage extends ClavisPage {

	public $_module = "ACQUISITION";


	public function onLoad($param)
	{
		parent::onLoad($param);

		if(!$this->getIsPostBack() ) {

		    $manifId = intval($this->Request['manifestationId']);
		    $libraryId = intval($this->Request['libraryId']);
			if($manifId > 0)
			{
				$manifestation = ManifestationPeer::retrieveByPK($manifId);
				if(!is_null($manifestation))
				{
					$this->SubscriptionList->setManifestation($manifestation);
				}
			}

			if($libraryId > 0)
			{
				$library = LibraryPeer::retrieveByPK($libraryId);
				if(!is_null($library))
				{
					$this->SubscriptionList->setLibrary($library);
				}
			}

		}
	}

	public function globalRefresh()
	{
		$this->SubscriptionList->populate();
	}

	public function globalEditCancel()
	{


	}

}

?>