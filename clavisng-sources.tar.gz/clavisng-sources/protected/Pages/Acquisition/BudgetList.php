<?php

/**
 * BudgetList Page class Module Acquisizioni
 *
 * @author Massimiliano Pigozzi <mpigozzi@e-portaltech.it>
 * @link http://www.e-portaltech.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @license http://www.e-portaltech.it/license/
 */

class BudgetList extends ClavisPage {

	public $_module = 'ACQUISITION';

}
