<?php
/**
 * InvoiceViewPage class file
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 */

/**
 * Acquisition.InvoiceViewPage Page class Module Acquisition
 *
 * @author Max Pigozzi <mpigozzi@e-portaltech.it>
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @copyright Copyright &copy; 2010 Comperio srl
 */

class InvoiceViewPage extends ClavisPage 
{
	public $_module = "ACQUISITION";

	public $_decimalSep = '';
	public $_groupSep = '';
	public $_invdecimalSep = '';
	public $_invgroupSep = '';
	
	public $_systemCurrency;
	public $_maxPrice;
	
	private function initVars()
	{
		$this->_systemCurrency = ClavisParamQuery::getParam('CLAVISPARAM','SystemCurrency');
		$this->_maxPrice = (float) ClavisParamQuery::getParam('CLAVISPARAM','AcquisitionMaxPriceLimit');
		
		$separatorData = ClavisBase::getSeparatorData();

		if (array_key_exists('decimal', $separatorData))
			$this->_decimalSep = $separatorData['decimal'];
		
		if (array_key_exists('group', $separatorData))
			$this->_groupSep = $separatorData['group'];
		
		if (array_key_exists('invariantdecimal', $separatorData))
			$this->_invdecimalSep = $separatorData['invariantdecimal'];
		
		if (array_key_exists('invariantgroup', $separatorData))
			$this->_invgroupSep = $separatorData['invariantgroup'];
	}
	
	public function onInit($param)
	{
		parent::onInit($param);
		$this->initVars();
	}
		
	/**
	 * On the onLoad we populate the textbox "Title" if the proper
	 * value is passed as a get parameter, and we must initialize
	 * EACH instance of repeatable list in the page (by $this->addItem).
	 *
	 * @param unknown_type $param
	 */
	public function onLoad($param)
	{
		parent::onLoad($param);
		/* caricamento dei dati nella form */

		$invoice = null;
							
		if (!$this->getIsPostBack() && !$this->getIsCallback())		// first page cycle
		{
			$this->AddItems->setVisible(false);
			$this->CloseInvoice->setEnabled(false);
			
			$editEnabled = false;
		    $id = intval($this->Request['id']);
			if ($id > 0)
			{
				$invoice = InvoiceQuery::create()->findPk($id);
				if (!($invoice instanceof Invoice ))
				{
					$this->writeMessage(Prado::localize("La fattura d'acquisto n. {id} non esiste",
														array('id' => $id)),
										ClavisMessage::ERROR);

					$this->gotoPage('Acquisition.InvoiceListPage');
				}

				$this->setInvoice($invoice);
				
				$editEnabled = $this->getUser()->getEditPermission($invoice);
				$this->UpdateData->setObject($invoice);
				
				$this->InvoiceItemList->setInvoice($invoice);
				$this->InvoiceItemList->populate();
				
				$this->InvoiceView->setInventoryAmountValue($invoice->getInventoryAmountValue());

				$this->InvoiceView->setInvoice($invoice);

				if (!$invoice->isNew()
						&& ($invoice->getInvoiceStatus() != InvoicePeer::INVOICESTATUS_CLOSED))
					$this->AddItems->setVisible(true);
				
				$this->CloseInvoice->setEnabled($invoice->getInvoiceStatus() == InvoicePeer::INVOICESTATUS_OPEN);
			}  

			$this->Edit->setEnabled($editEnabled && $invoice->getInvoiceStatus() == InvoicePeer::INVOICESTATUS_OPEN);
		}
		else		// not in first page cycle
		{
			$updateClavisItemList = $this->getApplication()->getSession()->itemAt('UpdateClavisItemList');
			if ($updateClavisItemList)
			{
				$this->getApplication()->getSession()->remove('UpdateClavisItemList');
				$this->InvoiceItemList->populate();
				
				if ($this->getIsCallback())
					$this->InvoiceItemListPanel->render($this->createWriter());
			}
		}
	}

	public function onPreRender($param)
	{
		parent::onPreRender($param);
		
		$this->RemoveItemButton->setVisible($this->isCanRemoveItemsFromInvoice());
	}
	
	private function isCanRemoveItemsFromInvoice()
	{
		$remove = false;
		$invoice = $this->getInvoice();
		if ($invoice instanceof Invoice)
		{
			$remove = (($invoice->getInvoiceStatus() == InvoicePeer::INVOICESTATUS_OPEN) 
							&& ($this->InvoiceItemList->getCounter() > 0));
		}

		return $remove;
	}
	
	//handlers
	public function onInvoiceEdit($sender, $param)
	{
		$id = intval($this->Request['id']);
		if ($id > 0)
			$this->gotoPage("Acquisition.InvoiceInsertPage", 
							array("id" => $this->getInvoiceId()) );
	}

	/**
	 * setters & getters
	 */

	public function setInvoice($invoice = null) 
	{
		if (!($invoice instanceof Invoice))
			$invoice = null;
		
		$this->setViewState("invoice", $invoice, null);
	}

	public function getInvoice() 
	{
		$invoice = $this->getViewState("invoice", null);

		if (!($invoice instanceof Invoice))
			$invoice = null;
		
		return $invoice;
	}

	public function getInvoiceId() 
	{
		$invoiceId = null;
		$invoice = $this->getInvoice();

		if ($invoice instanceof Invoice)
			$invoiceId = $invoice->getInvoiceId();
		
		return $invoiceId;
	}
	
	/**
	 * It is called by one of the inner components, and
	 * performs the population (refresh) of all the components
	 * (the calling is included).
	 *
	 */
	public function globalRefresh()
	{
		$this->InvoiceView->populate();
	}

	/**
	 * It's called by one of the inner componentes, and
	 * performs the "cancel" (return to non-edit status)
	 * of all the components (the calling is included).
	 *
	 * @param TControl $component
	 */
	public function globalCancel($component)
	{
		//if ($component !== $this->LibrarianGrid)
		//	$this->LibrarianGrid->onCancel(null, null);
	}

	public function onValidateBarcode($sender,$param)
	{
		$candidateBarcode = $param->getValue();
		$isDuplicate = !ItemPeer::checkBarcodeUnique($candidateBarcode, $this->getNewItem());
		if ($isDuplicate) 
		{
			$param->IsValid = false;
			$this->getPage()->writeMessage(Prado::localize("Il barcode '{barcode}' è già in uso nel sistema",
				array('barcode' => $candidateBarcode)), ClavisMessage::ERROR);
		} 
		else 
		{
			$param->IsValid = true;
		}
	}
	
	private function getNewItem()
	{
		$item = null;
		$itemId = intval($this->NewItemId->getValue());
		if ($itemId > 0)
			$item = ItemQuery::create()->findPk($itemId);

		return $item;
	}
	
	protected function onGetInventoryCounterCallback($sender, $param) 
	{
		$newItem = $this->getNewItem();
		if (!($newItem instanceof Item))
		{
			$this->writeMessage(Prado::localize("Errore interno nel reperimento dell'esemplare"),
				ClavisMessage::ERROR);
			
			return false;
		}
		
		$inventorySerieId = $this->InventorySerieId->getSelectedValue();
		$libraryId = $newItem->getOwnerLibraryId();
		
		$invCounter = InventorySeriePeer::calculateNextInventoryCounter($inventorySerieId, $libraryId);
		if ($invCounter != false) 
			$this->InventoryNumber->setText($invCounter);

		else 
			$this->writeMessage(Prado::localize("Errore nell'assegnazione automatica del contatore di inventario"),
									ClavisMessage::ERROR);
	}
	
	protected function saveInventoryCounter($item = null) 
	{
		if (!($item instanceof Item))
			return false;
		
		$tentativeCounter = trim($this->InventoryNumber->getSafeText());
		if ($tentativeCounter === "")
			return true;

		$tentativeCounter = intval($tentativeCounter);
		// if editing and inv number has not been modified, return.
		if ($item->getInventoryNumber() == $tentativeCounter)
			return true;

		$invSerId = $this->InventorySerieId->getSelectedValue();

		//verify it's not assigned
		if (!ItemPeer::isInventoryDuplicated(	$invSerId,
												$tentativeCounter, 
												$item->isNew() 
													? $this->getUser()->getActualLibraryId() 
													: $item->getOwnerLibraryId()) )
		{
			$item->setInventoryNumber($tentativeCounter);
			$item->save();

			return true;
		}
		else 
		{
			return false;
		}
	}
	
	public function onAddItemToInvoice($sender, $param)
	{
		if (!$this->getIsValid()) 
		{
			return false;
		}
		
		$invoice = $this->getInvoice();
		if (!($invoice instanceof Invoice))
		{
			$this->writeMessage(Prado::localize('Errore interno: fattura inesistente. Contattare il fornitore del software.'), 
									ClavisMessage::ERROR);
			return false;
		}
		
		$item = ItemQuery::create()->findPk($this->NewItemId->getValue());
		if (!$item instanceof Item) 
		{
			$this->writeMessage(Prado::localize('Esemplare non valido'),
									ClavisMessage::ERROR);
			$this->globalRefresh();
			return false;
		}

		if (!$this->saveInventoryCounter($item)) 
		{
			$this->writeMessage(Prado::localize('Il numero di inventario è già assegnato'), 
									ClavisMessage::ERROR);

			return false;
		}
		
		$item->setInventorySerieId($this->InventorySerieId->getSelectedValue());
		$item->setInventoryDate(time());  /// ??????
					
		$item->setBarcode(trim($this->Barcode->getSafeText()));
		$item->setItemStatus($this->ItemStatus->getSelectedValue());
		$item->setItemOrderStatus(ItemStatus::ITEMORDERSTATUS_ORDERDONE);	// it seems the most logical action ...
		$item->setLoanClass($this->ItemLoanClass->getSelectedValue());
		$item->setInvoice($invoice);
		$item->setSection($this->Section->getSelectedValue());
		$item->setCollocation($this->Collocation->getSafeText());
		$item->setSpecification($this->Specification->getSafeText());
		$item->setSequence1($this->Sequence1->getSafeText());
		$item->setSequence2($this->Sequence2->getSafeText());
		$item->setDateDiscarded(null);

		$item->setDiscountValue(ClavisBase::numberFormat($this->ItemDiscount->getSafeText(), '#.00%',null,false));
        $item->setInventoryValue(ClavisBase::numberFormat($this->ItemValue->getSafeText(), '#.00', null, false));
		$item->setCurrencyValue(ClavisBase::numberFormat($this->ItemCost->getSafeText(), '#.00', null, false));

		$item->save();
		
		ChangelogPeer::logAction(	$item, 
									ChangelogPeer::LOG_UPDATE,
									$this->getUser(), 
									'Esemplare aggiornato in fattura');

		$order = $item->getPurchaseOrder();
		if ($order instanceof PurchaseOrder) 
		{
			$order->recalculateOrderStatus();
			ChangelogPeer::logAction(	$order, 
										ChangelogPeer::LOG_UPDATE,
										$this->getUser(), 
										'Aggiornato stato ordine: aggiunto esemplare con id=' . $item->getItemId());
		}
		
		$this->writeMessage(Prado::localize("Esemplare '{title}' (id: {id}) inserito correttamente in fattura",
												array(	'title' => $item->getTrimmedTitle(40),
														'id' => $item->getItemId())), 
								ClavisMessage::CONFIRM);
		
		$this->InvoiceItemList->globalRefresh();
		$this->InvoiceItemList->setMasterChecked(false);
		$this->ItemPanel->setCssClass('panel_off');
		if ($this->getIsCallback())
			$this->ItemPanel->render($param->getNewWriter());
	}
	
	public function onDrawAddItemGrid($sender, $param)
	{
		$token = trim($this->AddItemTextBox->getSafeText());
		if ($token == "")
		{
			$this->AddItemError->setStyle('	display: inline; 
											color: red; 
											border:none;
											padding: 0px;
											background-color: inherit;');
			return false;
		}
		
		$this->AddItemTextBox->setText('');
		$values = array(Clavis::normalizeStdNum($token), Clavis::hyphenateStdNum($token));

		$q = ItemQuery::create()
				->useManifestationQuery()
					->filterByEan($values)
					->_or()
					->filterByISBNISSN($values)
					->_or()
					->filterByTitle("$token%", Criteria::LIKE)
					->_or()
					->filterBySortText("$token%", Criteria::LIKE)
					->endUse()
				->filterByItemOrderStatus(ItemStatus::ITEMORDERSTATUS_INORDER)
				->filterByOwnerLibraryId($this->getUser()->getLibraryIds())
				->orderByDateCreated();

		$items = $q->find();
		
		if ($items->isEmpty())
		{
			$q = ItemQuery::create()
					->filterByItemOrderStatus(ItemStatus::ITEMORDERSTATUS_INORDER)
					->filterByOwnerLibraryId($this->getUser()->getLibraryIds())
					->filterByItemId($token);

			$items = $q->find();
		}

		$itemDataSource = array();
		if (!$items->isEmpty())		// some results are found
		{
			$firstItem = $items[0];
			if ($firstItem instanceof Item)
				$title = $firstItem->getTitle();
			else
				$title = '(' . Prado::localize("senza titolo") . ')';
			
			$this->AddItemTitle->setStyle("display: inline");
			$this->AddItemTitle->setText($title);
			$this->AddItemError->setStyle('display: none');
			

			foreach ($items as $item) 
			{
				/* @var $item Item */

				$itemId = $item->getItemId();
				$ownerLibraryString = $item->getOwnerLibraryLabel();
				$homeLibraryString = $item->getHomeLibraryLabel();
				$dateCreated = $item->getDateCreated('U');

				$order = $item->getPurchaseOrder();
				if ($order instanceof PurchaseOrder) 
				{
					$orderId = $order->getOrderId();
					$orderTitle = $order->getOrderTitle();
					$supplierName = trim($order->getSupplierName());
					if ($supplierName != '')
						$orderTitle .= ' (' . $supplierName . ')';
				}
				else
				{
					$orderId = 0;
					$orderTitle = '---';
				}

				$itemDataSource[] = array(	'itemId'		=> $itemId,
											'ownerLibraryString' => $ownerLibraryString,
											'homeLibraryString' => $homeLibraryString,
											'dateCreated'	=> $dateCreated,
											'orderId'		=> $orderId,
											'orderTitle'	=> $orderTitle );
			}

		}
		else						// no results found
		{
			$this->AddItemTitle->setStyle("display: none");
			$this->AddItemError->setStyle('	display: inline; 
											color: red; 
											border:none;
											padding: 0px;
											background-color: inherit;');			
		}
		
		$this->AddItemGrid->setDataSource($itemDataSource);
		$this->AddItemGrid->dataBind();
	}
	
	public function resetAddItemGrid()
	{
		$this->AddItemTitle->setStyle("display: none");	
		$this->AddItemGrid->setDataSource(array());
		$this->AddItemGrid->dataBind();
	}
	
	public function onAddItemChosen($sender, $param)
	{
		switch ($param->getCommandName()) 
		{
			case 'itemIdChosen':
				
				$item = null;
				$itemId = intval($param->getCommandParameter());
				if ($itemId > 0)
					$item = ItemQuery::create()->findPk($itemId);
				if (!($item instanceof Item))
				{
					$this->AddItemTextBox->setText("");
					$this->getPage()->writeMessage(Prado::localize("Nessun esemplare corrisponde"),
													ClavisMessage::ERROR);
					return;
				}
				
				$this->NewItemId->setValue($item->getItemId());
				$tit = $item->getCompleteTitle();
				if (!$tit)
					$tit = Prado::localize('(nessun titolo)');
				
				$this->ChosenTitle->setText($tit);
				$order = $item->getPurchaseOrder();
				if ($order instanceof PurchaseOrder) 
				{
					$this->ChosenOrder->setText($order->getOrderTitle());
					$this->ChosenSupplier->setText($order->getSupplierName());
					$this->ChosenOrderView->setNavigateUrl('index.php?page=Acquisition.OrderViewPage&id='.$order->getOrderId());
				}
				
				if (is_null($item->getPrevHomeLibraryId()))
				{
					$sectionLibraryId = $item->getHomeLibraryId();
				}
				else	// item is assigned to another library
				{
					$sectionLibraryId = $item->getPrevHomeLibraryId();
					$prevHomeLibrary = $item->getPrevHomeLibrary();

					if ($prevHomeLibrary instanceof Library)
						$this->SectionLabel->setText(Prado::localize("sezione di {addPrev}",
														array('addPrev' => $prevHomeLibrary->getLabel(true, true))));
				}

				$this->Section->setLibraryId($sectionLibraryId);
				$this->Section->populateList();

				$this->ItemCost->setText(ClavisBase::numberFormat($item->getCurrencyValue(), '#.00'));
                $this->ItemDiscount->setText(ClavisBase::numberFormat($item->getDiscountValue(), '#.00%'));
				$this->ItemValue->setText(ClavisBase::numberFormat($item->getInventoryValue(), '#.00'));
				
				$this->ItemPanel->setCssClass('panel_on');
				
				$this->ItemStatus->setDataSource(LookupValuePeer::getLookupClassValues(	'ITEMSTATUS', 
																						false, 
																						null, 
																						array(	ItemStatus::ITEMSTATUS_ORDERDONE, 
																								ItemStatus::ITEMSTATUS_ONSHELF, 
																								ItemStatus::ITEMSTATUS_INCATALOGATION),
																						true));
				$this->ItemStatus->dataBind();
				$this->ItemStatus->setSelectedValue(ItemStatus::ITEMSTATUS_ORDERDONE);
				
				$this->AddItemGrid->setDataSource(array());
				$this->AddItemGrid->dataBind();
				$this->AddItemTitle->setStyle('display: none');

				$inv_series = InventorySerieQuery::create()
										->filterByLibraryId($item->getOwnerLibraryId())
										->orderByClosed()
										->orderByReadonly()
										->orderByInventorySerieId()
										->find();
		
				$ds = array();
				foreach ($inv_series as $i) 
					$ds[$i->getInventorySerieId()] = $i->getInventorySerieId() . ' (' 
														. $i->getInventoryCounter().')';

				$this->InventorySerieId->setDataSource($ds);
				$this->InventorySerieId->dataBind();
		
				$this->ItemLoanClass->setSelectedIndex(-1);
				$this->Section->setSelectedIndex(-1);
				$this->Collocation->setText('');
				$this->Specification->setText('');
				$this->Sequence1->setText('');
				$this->Sequence2->setText('');
				$this->Barcode->setText('');
				$this->InventoryNumber->setText('');
				
				if ($this->getIsCallback())
					$this->ItemPanel->render($this->createWriter());
				
				break;
		}
	}
	
	public function onCheckItemCost($sender, $param)
	{
		$value = ClavisBase::numberFormat($this->ItemCost->getSafeText(), '#.00', null, false);
	
		if ($value < 0.00)					// (($value < 0.00) || ($value > $this->_maxPrice))
			$param->isValid = false;
		else
			$param->isValid = true;
		
		return $param->isValid;		
	}
	
	public function onCheckItemDiscount($sender, $param)
	{
		$value = ClavisBase::numberFormat($this->ItemDiscount->getSafeText(), '#.00%', null, false);
	
		if (($value < 0.00) || ($value > 100.00))
			$param->isValid = false;
		else
			$param->isValid = true;
		
		return $param->isValid;		
	}	

	public function onCheckItemValue($sender, $param)
	{
		$value = ClavisBase::numberFormat($this->ItemValue->getSafeText(), '#.00', null, false);
	
		if ($value < 0.00)
			$param->isValid = false;
		else
			$param->isValid = true;
		
		return $param->isValid;		
	}

	public function onCloseInvoice($sender, $param)
	{
		$invoice = $this->getInvoice();
		if (!($invoice instanceof Invoice))
		{
			$this->getPage()->writeMessage(Prado::localize("Errore nel passaggio parametri fattura"),
												ClavisMessage::ERROR);
					return;
		}
		
		try
		{
			$invoice->setInvoiceStatus(InvoicePeer::INVOICESTATUS_CLOSED);
			$invoice->save();
			
			ChangelogPeer::logAction($invoice, ChangelogPeer::LOG_UPDATE, $this->getUser(), "chiusa fattura");
			$this->writeMessage(Prado::localize('Fattura chiusa correttamente'),
									ClavisMessage::INFO);
			
			$this->reloadPage();
		}
		catch (Exception $error)
		{
			$error = $error;
			//throw($error);

			$this->getPage()->writeMessage(Prado::localize("Errore nella procedura di chiusura della fattura"),
												ClavisMessage::ERROR);
				return;
		}
	}

	public function onJRPrint($sender, $param) 
	{
		$this->JRPBox->printReport();
	}
	
	public function onItemInvoiceUnlink($sender, $param)
	{
		if (!$this->isCanRemoveItemsFromInvoice())
		{
			$this->getPage()->writeMessage(Prado::localize("Errore: non è possibile rimuovere esemplari dalla fattura"),
											ClavisMessage::ERROR);
			
			return false;
		}
		
		$checkedIds = $this->InvoiceItemList->getCheckedId();
		if (count($checkedIds) > 0) 
		{
			$removedCount = ItemQuery::create()
								->filterByItemId($checkedIds)
								->update(array( 'InvoiceId' => null,
												'ItemStatus' => ItemStatus::ITEMSTATUS_INORDER,
												'ItemOrderStatus' => ItemStatus::ITEMORDERSTATUS_INORDER));

			$invoice = $this->getInvoice();
	
			$this->getPage()->writeMessage(Prado::localize("Slegati {removedCount} esemplari dalla fattura {invoiceLabel}",
															array(	'removedCount' => $removedCount,
																	'invoiceLabel' => $invoice->getInvoiceCompleteLabel(true))),		// with library indication
											$removedCount > 0
												? ClavisMessage::CONFIRM
												: ClavisMessage::INFO);
			
			if ($removedCount > 0)
			{
				$this->InvoiceItemList->populate();

				ChangelogPeer::logAction(	$this->getInvoice(), 
											ChangelogPeer::LOG_UPDATE, 
											$this->getUser(), 
											"rimossi $removedCount esemplari collegati alla fattura " . $invoice->getInvoiceCompleteLabel(true));
				
				$orders = PurchaseOrderQuery::create()
							->useItemQuery()
								->filterByItemId($checkedIds)
							->endUse()
							->find();

				foreach($orders as $order)
					$order->recalculateOrderStatus();
			}
		}
		else
		{
			$this->getPage()->writeMessage(Prado::localize('Nessun elemento selezionato o rimuovibile'),
											ClavisMessage::WARNING);
			
			return false;
		}
	}
	
}
