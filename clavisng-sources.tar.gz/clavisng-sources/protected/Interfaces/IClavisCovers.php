<?php

interface IClavisCovers
{
	public static function getRemoteCover($ean);
	public static function getRemoteIndex($ean);

	public static function getRemoteCoverURL($ean);
	public static function getRemoteIndexURL($ean);

	public static function getCalderoneURL($ean);

	public static function getRemoteInfo($ean);
	public static function checkRemoteCover($ean);

	public static function hasData($ean);
}