<?php

interface IQueryBuilderRulesConverter
{
	public function convert(stdClass $r);
}