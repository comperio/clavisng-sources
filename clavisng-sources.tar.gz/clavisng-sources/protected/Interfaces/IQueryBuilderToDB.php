<?php

interface IQueryBuilderToDB
{
	public function getOperatorsMap($field, $operator, $value,$type='');

	public function escapeUserInput($value);

	public function translate($rules, $transformationRules = [], $dbAccessObject = null);
}
