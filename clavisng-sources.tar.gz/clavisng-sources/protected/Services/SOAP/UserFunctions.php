<?php

/**
 * UserFunctions class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Services.SOAP
 */

Prado::using('Application.Services.SOAP.BaseSoap');

/**
 * UserFunctions class
 *
 * This class implements a list of SOAP methods for interfacing with Clavis users.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Services.SOAP
 * @since 2.5.0
 */

include_once 'protected/Common/ClavisHasher.php';

class UserFunctions extends BaseSoap
{
    use Hasher;

    private $_user = null;

    /**
     * Ritorna null se il contatto non esiste, user altrimenti
     *
     * @param string $search
     * @param string $searchfield
     * @return boolean
     * @soapmethod
     */
    public function getUserContacts($search, $searchfield)
    {
        $this->setNewRelicTransaction("SOAP." . __METHOD__);
        $user = false;
        /* Cerco il contatto in base al tipo */
        switch ($searchfield) {
            case 'username':
                $query = PatronQuery::create()->filterByOpacUsername($search);
                break;
            case 'email':
                $query = PatronQuery::create()
                    ->useContactQuery()
                    ->filterByContactType(ContactPeer::TYPE_EMAIL)
                    ->filterByContactValue($search)
                    ->endUse();
                break;
            case 'contact_value':
                $query = PatronQuery::create()
                    ->useContactQuery()
                    ->filterByContactType(ContactPeer::TYPE_MOBILE)
                    ->filterByContactValue($search)
                    ->endUse();
                break;
            case 'national_id':
                $query = PatronQuery::create()->filterByNationalId($search);
                break;
            default:
                break;
        }
        if ($query->count() > 0) {
            $user = true;
        }
        Prado::log("Richiesta esistenza contatto: " . $searchfield . ":" . $search . " = " . Prado::varDump($user));
        return $user;
    }

    /**
     * Log in a user.
     *
     * @param string $username
     * @param string $password
     * @return boolean
     * @soapmethod
     */
    public function loginUser($username, $password): bool
    {
        $this->setNewRelicTransaction("SOAP." . __METHOD__);
        if (!$this->_authenticated)
            $this->fault('Wrong auth', 'Authentication credential are not valid', 'Client');
        $crypt = Prado::getApplication()->getModule('crypt');
        $user = $this->getClavisUser($username);
        $patron = null;

        // we can have four scenarios:
        // 1. user is a Librarian who IS Webmaster/Sitemaster AND HAS a linked Patron
        // 2. user is a Librarian who IS Webmaster/Sitemaster BUT does NOT have a linked Patron
        // 3. user is a Librarian who IS NOT Webmaster/Sitemaster BUT HAS a linked Patron
        // 4. user is a Patron
        // The last two fall into the same case - Patron only.
        // -------------------------------------------------------------------------------------------------------------

        // Librarian with a linked patron.
        // ----------------------------------------------------------------------------------
        if ($user instanceof Librarian && $crypt->LibrarianVerify($password, $user->getSecret())) {
            $patron = $user->getPatron();
            // check if librarian has webmaster or sitemaster profile
            $hasprofile = LLibrarianProfileQuery::create()
                ->filterByLibrarian($user)
                ->filterByProfileId(array(7, 8));
            // CNG-1396: check activation status for librarian before logging in
            if (($hasprofile->count() > 0) && ($user->getActivationStatus() == 1)) {
                Prado::log("librarian / MASTER [$username] auth OK", TLogger::INFO, 'SOAP');
                return true;
            }
        } else if ($user instanceof Patron && substr($password, 0, 4) === 'sso@') {

            // Single Sign On login with APIKEY
            // ----------------------------------------------------------------------------------
            $apikey = DNGSimpleAuthenticator::getApiKey();
            $hashed_password = substr($password, 4, strlen($password));

            if ($this->hash_is_valid($apikey, $username . $apikey, $hashed_password)) {
                $patron = $user;
            }
        } else if ($user instanceof Patron && $crypt->PatronVerify($password, $user->getOpacSecret())) {
            // Username / Password login
            // ----------------------------------------------------------------------------------
            $patron = $user;
        }

        if ($patron instanceof Patron) {
            if (!$patron->getOpacEnable()) {
                Prado::log("patron [$username] auth OK but not enabled", TLogger::INFO, 'SOAP');
                return false;
            }

            Prado::log("patron [$username] auth OK", TLogger::INFO, 'SOAP');
            ClavisSAML::saveSuccessfulLoginEvent($username, '', '', $patron->getPatronId());
            return true;
        }

        Prado::log("[$username] auth KO", TLogger::INFO, 'SOAP');

        if (strpos($password, 'sso@') === 0) {
            ClavisSAML::saveFailedLoginEvent($username, '', '', 0);
        }
        return false;
    }

    /**
     *
     * @param string $search
     * @param string $searchfield
     * @return Patron|Librarian
     */
    protected function getClavisUser($search, $searchfield = null)
    {
        if ($this->_user) {
            return $this->_user;
        }
        if (!$searchfield) {
            $searchfield = 'username';
        }
        if ('username' == $searchfield) {
            // search among Librarians
            $user = LibrarianQuery::create()->findOneByUsername($search);
        } else if ('email' == $searchfield) // search among Librarians
        {
            $user = LibrarianQuery::create()->findOneByEmail($search);
        }

        if (!in_array($searchfield, array('username', 'email')) || !$user instanceof Librarian) {
            // search among Patrons
            switch ($searchfield) {
                case 'id':
                    $user = PatronQuery::create()->findOneByPatronId($search);
                    break;
                case 'barcode':
                    $user = PatronQuery::create()->findOneByBarcode($search);
                    break;
                case 'email':
                    $query = PatronQuery::create()
                        ->useContactQuery()
                        ->filterByContactType(ContactPeer::TYPE_EMAIL)
                        ->filterByContactValue($search)
                        ->endUse();

                    if ($query->count() == 1)
                        $user = $query->findOne();
                    else
                        $user = null;
                    break;
                case 'nationalidsso':
                case 'nationalid':
                    $query = PatronQuery::create()
                        ->filterByNationalId($search);

                    if (($searchfield === 'nationalidsso') && ($query->count() === 0)) {
                        ClavisSAML::saveFailedLoginEvent($search, null, null, 0, "User search for national_id failed: $search");
                    }

                    if ($query->count() == 1)
                        $user = $query->findOne();
                    else
                        $user = null;
                    break;
                case 'username':
                default:
                    $user = PatronQuery::create()->findOneByOpacUsername($search);
                    break;
            }
            if (!$user instanceof Patron)
                return false;
        }
        $this->_user = $user;
        return $this->_user;
    }

    /**
     * Log out a user logged in with saml signon.
     * Relates to the SP initiated logout process.
     *
     * @param string $username
     * @return array
     * @soapmethod
     */
    public function logoutUser(string $username): array
    {
        list($username, $session_id) = explode(":", $username);

        $this->setNewRelicTransaction("SOAP." . __METHOD__);
        if (!$this->_authenticated) {
            $this->fault('Wrong auth', 'Authentication credential are not valid', 'Client');
        }

        $user = $this->getClavisUser($username, 'id');
        if ($user instanceof Patron) {
            $sloBinding = ClavisBase::getServiceConfiguration('dso', 'sloBinding');
            $ssoBinding = ClavisBase::getServiceConfiguration('dso', 'ssoBinding');

            $saml = new ClavisSAML('/dng', $ssoBinding, $sloBinding);
            $data = $saml::getPatronData($user->getPatronId(), $session_id);
            $samlUK = $data['samlUserKey'];
            $redirect_params = $saml->logout($user->getPatronId(), false, $samlUK, true);

            // POST BINDING
            if (array_key_exists('action', $redirect_params) && array_key_exists('parameters', $redirect_params)) {
                $saml::saveLogoutEvent($data['samlNameId'], $data['samlSessinIndex'], $session_id, $user->getPatronId());
                return $redirect_params;
            }

            // REDIRECT BINDING
            if ((filter_var($redirect_params, FILTER_VALIDATE_URL) !== false) && ((string)$sloBinding === "urn:oasis:names:tc:SAML:2.0:bindings:HTTP-REDIRECT")) {
                $saml::saveLogoutEvent($data['samlNameId'], $data['samlSessionIndex'], $session_id, $user->getPatronId());
                return ['action' => $redirect_params, 'parameters' => ''];
            }

            ClavisSAML::saveLogoutAttempt($username, $user->getPatronId());

            // ERROR
            return [];

        }

        Prado::log("[$username] logout KO", TLogger::INFO, 'SOAP');
        ClavisSAML::saveLogoutAttempt($username, null);

        return array();
    }

    /**
     * Store DNG's php session id to the patron action relative to the login token
     * used by the autologin feature.
     *
     * @param string $token
     * @param string $session_id
     * @return boolean
     * @soapmethod
     */
    public function saveSessionIdentifier(string $token, string $session_id): bool
    {
        $pa = ClavisSAML::getPatronActionFromClavisToken($token);
        if ($pa instanceof PatronAction) {
            ClavisSAML::updateSessionIdForPatronAction($pa, $session_id);
        }
        return true;
    }

    /**
     * Retrieves data for a user.
     *
     * @param string $search
     * @param string $searchfield Optional, can be 'username','id','contact_value','barcode' or 'email' or 'omocodia'
     * @return array
     * @soapmethod
     */
    public function getUserData($search, $searchfield = null)
    {
        $this->setNewRelicTransaction("SOAP." . __METHOD__);
//		if (!$this->_authenticated)
//			$this->fault('Wrong auth','Authentication credential are not valid','Client');

//        Prado::log($searchfield, TLogger::INFO, 'SOAP');
        if ($searchfield == 'omocodia') {
            list($name, $lastname, $birthdate) = explode('#', $search);
            Prado::log($search, TLogger::INFO, 'SOAP');
            $user = PatronQuery::create()->findByArray(array('Name' => $name, 'Lastname' => $lastname, 'BirthDate' => $birthdate));
//            Prado::log(Prado::varDump($user, 3), TLogger::INFO, 'SOAP');
            Prado::log($user[0], TLogger::INFO, 'SOAP');
            if ($user[0] != '') {
                return array(0 => 1);
            } else {
                return array(0 => 0);
            }
        }

        if (!$searchfield)
            $searchfield = 'username';
        $ret = array();
        $user = $this->getClavisUser($search, $searchfield);
        $req = Prado::getApplication()->getRequest();
        if ($user instanceof Librarian) {
            $patron = $user->getPatron();
            $hasprofile = LLibrarianProfileQuery::create()
                ->filterByLibrarian($user)
                ->filterByProfileId(array(7, 8))
                ->findOne();
            if ($hasprofile instanceof LLibrarianProfile) {
                $ret['librarian'] = $user->toArray();
                switch ($hasprofile->getProfileId()) {
                    case 7:
                        $ret['group'] = 'webmaster';
                        break;
                    case 8:
                        $ret['group'] = 'sitemaster';
                        break;
                }
                $photoId = $user->getPhotoFileId();
                $ret['photoUrl'] = $photoId ? rtrim(ClavisParamQuery::getParam('CLAVISPARAM', 'BaseUrl'), '/') . '/index.php?file=' . $photoId : '';
                $ret['libroles'] = array();
                foreach ($user->getLLibraryLibrarians() as $librole)
                    /* @var $librole LLibraryLibrarian */
                    $ret['libroles'][$librole->getLibraryId()] = $librole->getLinkRole();
            } else {
                $ret['group'] = 'patron';
            }
        } else if ($user instanceof Patron) {
            $patron = $user;
            $ret['group'] = 'patron';
        } else {
            return 'Neither librarian nor patron found: ' . Prado::varDump($user, 3);
        }
        if ($patron instanceof Patron) {
            $ret['patron'] = $patron->toArray();
            $ret['addresses'] = array();
            foreach ($patron->getAddresss() as $a)
                $ret['addresses'][] = $a->toArray();
            $ret['contacts'] = array();
            foreach ($patron->getContacts() as $c)
                $ret['contacts'][] = $c->toArray();

            $query = PatronPropertyQuery::create()->filterByPatronId($ret['patron']["PatronId"]);
            $ret['properties'] = array($query->select(array('PropertyClass', 'PropertyValue'))->find()->toArray());

        }
        return $ret;
    }

    /**
     * Set Privacy data about Patron
     *
     * @param string $username
     * @param string $privacy_approve
     * @param string $data_trx
     * @param string $newsletter
     * @param string $p3
     * @param string $p4
     * @param string $p5
     * @return string
     * @soapmethod
     */

    public function setPrivacy($username, $privacy_approve = null, $data_trx = '', $newsletter = '', $p3 = '', $p4 = '', $p5 = '')
    {
        $this->setNewRelicTransaction("SOAP." . __METHOD__);

        if (!$this->_authenticated)
            $this->fault('Wrong auth', 'Authentication credential are not valid', 'Client');
        $user = $this->getClavisUser($username);
        if (!$user instanceof Patron)
            throw new Exception('Invalid patron');

        if ($data_trx != '') {
            list($dtclass, $dtvalue) = explode(":", $data_trx);
            $prop = PatronPropertyQuery::create()
                ->filterByPatron($user)
                ->filterByPropertyClass($dtclass)
                ->findOne();
            if ($prop instanceof PatronProperty) {
                $prop->setPropertyValue($dtvalue);
                $prop->save();
            }
        }

        if ($newsletter != '') {
            list($nlclass, $nlvalue) = explode(":", $newsletter);
            $prop = PatronPropertyQuery::create()
                ->filterByPatron($user)
                ->filterByPropertyClass($nlclass)
                ->findOne();
            if ($prop instanceof PatronProperty) {
                $prop->setPropertyValue($nlvalue);
                $prop->save();
            }
        }

        if ($p3 != '') {
            list($p3class, $p3value) = explode(":", $p3);
            $prop = PatronPropertyQuery::create()
                ->filterByPatron($user)
                ->filterByPropertyClass($p3class)
                ->findOne();
            if ($prop instanceof PatronProperty) {
                $prop->setPropertyValue($p3value);
                $prop->save();
            }
        }

        if ($p4 != '') {
            list($p4class, $p4value) = explode(":", $p4);
            $prop = PatronPropertyQuery::create()
                ->filterByPatron($user)
                ->filterByPropertyClass($p4class)
                ->findOne();
            if ($prop instanceof PatronProperty) {
                $prop->setPropertyValue($p4value);
                $prop->save();
            }
        }

        if ($p5 != '') {
            list($p5class, $p5value) = explode(":", $p5);
            $prop = PatronPropertyQuery::create()
                ->filterByPatron($user)
                ->filterByPropertyClass($p5class)
                ->findOne();
            if ($prop instanceof PatronProperty) {
                $prop->setPropertyValue($p5value);
                $prop->save();
            }
        }

        if (!is_null($privacy_approve)) {
            try {
                $user->setPrivacyApprove("1");
                $user->save();
            } catch (Exception $e) {
            }
        }

        ChangelogPeer::logAction($user, ChangelogPeer::LOG_UPDATE, 1, "[WS] preferenze privacy modificate per l'utente [{$user->getPatronId()}] ({$user->getCompleteName()})");
        return true;
    }

    /**
     * Changes a user's password with a new one.
     *
     * @param string $username
     * @param string $oldpassword
     * @param string $newpassword
     * @param string $expirepassword
     * @return boolean
     * @soapmethod
     */
    public function setNewPassword($username, $oldpassword, $newpassword, $expirepassword)
    {
        $this->setNewRelicTransaction("SOAP." . __METHOD__);
        if (!$this->_authenticated)
            $this->fault('Wrong auth', 'Authentication credential are not valid', 'Client');
        $crypt = Prado::getApplication()->getModule('crypt');
        $user = $this->getClavisUser($username);
        if (($user instanceof Patron && $crypt->PatronVerify($oldpassword, $user->getOpacSecret())) || ($user instanceof Librarian && $crypt->LibrarianVerify($oldpassword, $user->getSecret()))) {
            return $this->setPassword($username, $newpassword, $expirepassword);
        } else {
            return false;
        }
    }

    /**
     * Sets a user's password.
     *
     * @param string $username
     * @param string $newpassword
     * @param string $expirepassword
     * @return boolean
     * @soapmethod
     */
    public function setPassword($username, $newpassword, $expirepassword)
    {
        $this->setNewRelicTransaction("SOAP." . __METHOD__);
        if (!$this->_authenticated)
            $this->fault('Wrong auth', 'Authentication credential are not valid', 'Client');
        $crypt = Prado::getApplication()->getModule('crypt');
        $user = $this->getClavisUser($username);
        if ($user instanceof Patron) {
            try {
                $user->setOpacSecret($crypt->PatronEncrypt($newpassword));
                $user->setOpacSecretExpire($expirepassword);
                $user->save();
                ChangelogPeer::logAction($user, ChangelogPeer::LOG_UPDATE, 1, "[WS] password modificata per l'utente [{$user->getPatronId()}] ({$user->getCompleteName()}, scadenza:" . ((is_null($expirepassword)) ? "mai" : $expirepassword) . ")");
                return true;
            } catch (Exception $e) {

            }
        } else if ($user instanceof Librarian) {
            try {
                $user->setSecret($crypt->LibrarianEncrypt($newpassword));
                $user->save();
                ChangelogPeer::logAction($user, ChangelogPeer::LOG_UPDATE, 1, "[WS] password modificata per l'utente [{$user->getLibrarianId()}] ({$user->getCompleteName()})");
                return true;
            } catch (Exception $e) {

            }
        }
        return false;
    }

    /**
     * Changes a patron's username.
     *
     * @param string $oldusername
     * @param string $newusername
     * @return boolean
     * @soapmethod
     */
    public function setNewUsername($oldusername, $newusername)
    {
        $this->setNewRelicTransaction("SOAP." . __METHOD__);
        if (!$this->_authenticated)
            $this->fault('Wrong auth', 'Authentication credential are not valid', 'Client');
        $user = $this->getClavisUser($oldusername);
        if ($user instanceof Patron) {
            try {
                $user->setOpacUsername($newusername);
                $user->save();
                ChangelogPeer::logAction($user, ChangelogPeer::LOG_UPDATE, 1, "[WS] username modificato per l'utente [{$user->getPatronId()}] ({$user->getCompleteName()})");
                return true;
            } catch (Exception $e) {
                return false;
            }
        } else if ($user instanceof Librarian) {
            try {
                $user->setUsername($newusername);
                $user->save();
                ChangelogPeer::logAction($user, ChangelogPeer::LOG_UPDATE, 1, "[WS] username modificato per l'operatore [{$user->getLibrarianId()}] ({$user->getCompleteName()})");
                return true;
            } catch (Exception $e) {
                return false;
            }
        } else {
            return false;
        }
        return false;
    }

    /**
     * Allow new custom user registration from DNG
     *
     * @param array $dataSet
     * @return array
     * @throws Exception
     * @soapmethod
     */
    public function registerNewCustomUser($dataSet)
    {
        $this->setNewRelicTransaction("SOAP." . __METHOD__);
        if (!$this->_authenticated)
            $this->fault('Wrong auth', 'Authentication credential are not valid', 'Client');

        // Separazione Contatti e Indirizzo
        $contact = $dataSet["contact"];
        $address = $dataSet["address"];
        $properties = $dataSet["properties"];
        unset($dataSet["contact"]);
        unset($dataSet["address"]);
        unset($dataSet["properties"]);

        // Verifica di base
        if (PatronQuery::create()->filterByNationalId($dataSet["required"]["personal"]["NationalId"])->count() > 0)
            throw new Exception('ErrorTextCF');
        if (LibraryQuery::create()->filterByLibraryId($dataSet["required"]["login"]["RegistrationLibraryId"])->count() != 1)
            throw new Exception('ErrorTextLibraryId');

        if (ContactQuery::create()->filterByContactValue($contact["ContactEmail"])->count() > 0)
            throw new Exception('ErrorTextEmail');

        if (isset($dataSet["other"]["OpacUsername"])) {
            if (PatronQuery::create()->filterByOpacUsername($dataSet["other"]["OpacUsername"])->count() > 0)
                throw new Exception('ErrorTextUsername');
        }

        // Estrapolazione iniziale
        $pwd_crypt = Prado::getApplication()->getModule('crypt')->PatronEncrypt($dataSet["required"]["login"]["OpacSecret"]);
        unset($dataSet["required"]["login"]["OpacSecret"]);

        $loan_classes = array_keys(LookupValuePeer::getLookupClassValues('PATRONLOANCLASS'));
        $loan_class = $dataSet["flags"]["LoanClass"];
        if (!in_array($loan_class, $loan_classes))
            $loan_class = $loan_classes[0];
        unset($dataSet["flags"]["LoanClass"]);

        $patron_statuses = array_keys(LookupValuePeer::getLookupClassValues('PATRONSTATE'));
        $patron_status = $dataSet["flags"]["PatronStatus"];
        if (!in_array($patron_status, $patron_statuses))
            $patron_status = PatronPeer::STATUS_INCOMPLETE;
        unset($dataSet["flags"]["PatronStatus"]);

        // Salvataggio
        try {
            $user = new Patron();

            // Informazioni personali, login e nascita OBBLIGATORIE
            foreach ($dataSet["required"] as $keyr => $required) {
                foreach ($required as $key => $data) {
                    $name = "set" . $key;
                    $user->$name($data);
                }
            }
            $user->setPreferredLibraryId($dataSet["required"]["login"]["RegistrationLibraryId"]);
            unset($dataSet["required"]);

            // Documenti, altri, flags
            foreach ($dataSet as $keyr => $required) {
                foreach ($required as $key => $data) {
                    $name = "set" . $key;
                    $user->$name($data);
                }
                unset($dataSet[$keyr]);
            }

            $user->setOpacSecret($pwd_crypt);
            $user->setPatronStatus($patron_status);
            $user->setLoanClass($loan_class);

            // Note finali e salvataggio
            $user->setAccessNote(Prado::localize("Utente creato da OPAC con registrazione custom"));
            $user->save();

            // Recupero lo username
            $user->reload();
            $username = $user->getOpacUsername();
            // Aggiunta contatti dopo aver salvato e ricavato lo USERNAME
            $this->editContact($username, '', 'E', $contact["ContactEmail"], 1);
            if ($contact["ContactType|T"] != "") {
                $this->editContact($username, '', 'T', $contact["ContactType|T"], 0);
            }
            if ($contact["ContactType|C"] != "") {
                $this->editContact($username, '', 'C', $contact["ContactType|C"], 0);
            }

            // Aggiunta indirizzo dopo aver salvato e ricavato lo USERNAME
            if ($address["Street"] != "") {
                $this->editAddress($username, '', $address["AddressType"], 0, $address["StreetType"], $address["Street"],
                    $address["StreetNum"], $address["Village"], $address["City"], $address["Zip"], $address["Province"], $address["Country"]);
            }

            if (!empty($properties)) {
                foreach ($properties as $key => $value) {
                    $property = new PatronProperty();
                    $property->setPatronId($user->getId());
                    $property->setPropertyClass($key);
                    $property->setPropertyValue($value == 1 ? "yes" : "no");
                    $property->save();
                }
            }

            ChangelogPeer::logAction($user, ChangelogPeer::LOG_CREATE, 1, "[WS] creato nuovo utente con registrazione custom: [{$user->getPatronId()}] ({$user->getCompleteName()})");
            return $user->toArray();

        } catch (PropelException $e) {
            throw new Exception("ErrorTextUser");
        } catch (Exception $e) {
            throw new Exception("ErrorGenericUsername");
        }
    }

    /**
     * Insert or edit a contact with specified values.
     * All values are optional, if not specified the related field will be set to ''.
     *
     * @param string $username
     * @param int $contact_id
     * @param string $contact_type
     * @param string $contact_value
     * @param int $contact_pref
     * @return array The contact added or modified.
     * @throws Exception
     * @soapmethod
     */
    public function editContact($username,
                                $contact_id = null,
                                $contact_type = '',
                                $contact_value = '',
                                $contact_pref = 0)
    {
        $this->setNewRelicTransaction("SOAP." . __METHOD__);

        if (!$this->_authenticated)
            $this->fault('Wrong auth', 'Authentication credential are not valid', 'Client');

        $user = $this->getPatron($this->getClavisUser($username));

        if (!$user instanceof Patron)
            throw new Exception('Invalid patron');

        if (!in_array($user->getPatronStatus(), array(PatronPeer::STATUS_ENABLED, PatronPeer::STATUS_INCOMPLETE)))
            throw new Exception('Patron is not enabled');

        try {
            if ($contact_id) {
                /** @var Contact $c */
                $c = ContactQuery::create()->findPk($contact_id);

                if (!$c instanceof Contact)
                    throw new Exception('No contact matching ID ' . $contact_id);

                $action = ChangelogPeer::LOG_UPDATE;

                $patronId = $user->getPatronId();
                $patronName = $user->getCompleteName();

                $contactId = $c->getContactId();
                $contactValue = $c->getContactValue();
                $contactType = $c->getContactTypeString();
                $contactPref = ($c->getContactPref() == '1');

                $msg = "[WS] per l'utente '{$patronName}' (id={$patronId}) è stato modificato il contatto id={$contactId}, '{$contactValue}' ({$contactType}"
                    . ($contactPref ? ", preferito" : "")
                    . ")";
            } else {
                $c = new Contact;
                $c->setPatron($user);
                $action = ChangelogPeer::LOG_CREATE;
                $msg = "[WS] contatto creato (id: {$c->getContactId()})";
            }

            $contact_types = array_keys(LookupValuePeer::getLookupClassValues('CONTACTTYPE'));

            $c->setContactType(in_array($contact_type, $contact_types) ? $contact_type : $contact_types[0]);
            $c->setContactValue($contact_value);
            $c->setContactPref($contact_pref);
            $c->save();

            ChangelogPeer::logAction($user,
                $action,
                1,
                $msg);

            return $c->toArray();
        } catch (Exception $e) {
            throw new Exception('Contact saving failed');
        }
    }

    /**
     * @param Librarian|Patron $clavis_user
     * @return bool|null
     */
    protected function getPatron($clavis_user)
    {
        if ($clavis_user instanceof Patron) {
            return $clavis_user;
        } else if ($clavis_user instanceof Librarian) {
            $patron = $clavis_user->getPatron();
            if ($patron instanceof Patron)
                return $patron;
        }
        return null;
    }

    /**
     * Insert or edit an address with specified values.
     * All values are optional, if not specified the related field will be set to ''.
     *
     * @param string $username
     * @param int $address_id
     * @param string $address_type
     * @param int $address_pref
     * @param string $street_type
     * @param string $street
     * @param string $street_num
     * @param string $village
     * @param string $city
     * @param string $zip
     * @param string $province
     * @param string $country
     * @return array The address added or modified.
     * @throws Exception
     * @soapmethod
     */
    public function editAddress($username,
                                $address_id = null,
                                $address_type = '',
                                $address_pref = 0,
                                $street_type = '',

                                $street = '',
                                $street_num = '',
                                $village = '',
                                $city = '',
                                $zip = '',

                                $province = '',
                                $country = '')
    {
        $this->setNewRelicTransaction("SOAP." . __METHOD__);

        if (!$this->_authenticated)
            $this->fault('Wrong auth', 'Authentication credential are not valid', 'Client');

        $user = $this->getPatron($this->getClavisUser($username));

        if (!$user instanceof Patron)
            throw new Exception('Invalid patron');

        if (!in_array($user->getPatronStatus(), array(PatronPeer::STATUS_ENABLED, PatronPeer::STATUS_INCOMPLETE)))
            throw new Exception('Patron is not enabled');

        try {
            if ($address_id) {
                $a = AddressQuery::create()->findPk($address_id);

                if (!$a instanceof Address)
                    throw new Exception('No address matching ID ' . $address_id);

                $action = ChangelogPeer::LOG_UPDATE;

                $patronId = $user->getPatronId();
                $patronName = $user->getCompleteName();

                $addressId = $a->getAddressId();
                $addressType = $a->getAddressTypeString();
                $address = $a->getAddressString();
                $village = trim($a->getVillage());
                $city = trim($a->getCity());
                $zip = trim($a->getZip());
                $province = trim($a->getProvince());
                $country = trim($a->getCountry());
                $preferred = ($a->getAddressPref() == '1');
                $note = trim($a->getAddressNote());

                //$msg = "[WS] indirizzo modificato (id: {$a->getAddressId()}). " . $a->getAddressString() .' ' .$a->getCity();

                $msg = "[WS] per l'utente '{$patronName}' (id={$patronId}) è stato modificato l'indirizzo id={$addressId}, ({$addressType}) "
                    . "{$address}";

                if ($village != '')
                    $msg .= ", {$village}";

                if ($city != '')
                    $msg .= ", {$city}";

                if ($zip != '')
                    $msg .= ", {$zip}";

                if ($province != '')
                    $msg .= ", {$province}";

                if ($country != '')
                    $msg .= ", {$country}";

                if ($preferred)
                    $msg .= ", (preferito)";

                if ($note != '')
                    $msg .= ", nota={$note}";
            } else {
                $a = new Address;
                $a->setPatron($user);
                $action = ChangelogPeer::LOG_CREATE;
                $msg = "[WS] contatto creato (id: {$a->getAddressId()})";
            }

            $address_types = array_keys(LookupValuePeer::getLookupClassValues('ADDRESSTYPE'));
            $street_types = array_keys(LookupValuePeer::getLookupClassValues('STREET'));

            $a->setAddressType(in_array($address_type, $address_types) ? $address_type : $address_types[0]);
            $a->setAddressPref($address_pref);
            $a->setStreetType(in_array($street_type, $street_types) ? $street_type : $street_types[0]);
            $a->setStreet($street);
            $a->setStreetNum($street_num);
            $a->setVillage($village);
            $a->setCity($city);
            $a->setZip($zip);
            $a->setProvince($province);
            $a->setCountry($country);

            $a->save();

            ChangelogPeer::logAction($user,
                $action,
                1,
                $msg);

            return $a->toArray();
        } catch (Exception $e) {
            throw new Exception('Address saving failed');
        }
    }

    /**
     * Allows registration of a new user.
     *
     * @param string $username
     * @param string $password
     * @param string $expirepassword
     * @param string $name
     * @param string $lastname
     * @param int $registration_library_id
     * @param string $national_id
     * @param string $gender
     * @param string $title
     * @param string $civil_status
     * @param string $document_type
     * @param string $document_number
     * @param string $document_emitter
     * @param string $document_expiry
     * @param string $citizenship
     * @param string $birth_date
     * @param string $birth_city
     * @param string $birth_province
     * @param string $birth_country
     * @param string $patron_status
     * @param string $loan_class
     * @param bool $privacy_approve
     * @param bool $patronOpacEnabled
     * @param bool $patronSurfEnabled
     * @param bool $patronAccessAlert
     * @param string $type_of_registration
     * @return array The newly created user.
     * @throws Exception
     * @soapmethod
     */
    public function registerNewUser($username, $password, $expirepassword, $name, $lastname, $registration_library_id, $national_id, $gender,
                                    $title, $civil_status, $document_type, $document_number, $document_emitter, $document_expiry, $citizenship, $birth_date, $birth_city,
                                    $birth_province, $birth_country, $patron_status, $loan_class, $privacy_approve, $patronOpacEnabled, $patronSurfEnabled, $patronAccessAlert,
                                    $type_of_registration = "standard")
    {

        if ($type_of_registration == "twilio") {
            $this->setNewRelicTransaction("SOAP." . __METHOD__);
            if (!$this->_authenticated)
                $this->fault('Wrong auth', 'Authentication credential are not valid', 'Client');

            if (PatronQuery::create()->filterByNationalId($national_id)->count() > 0)
                throw new Exception('ErrorTextCF');
            if (PatronQuery::create()->filterByOpacUsername($username)->count() > 0)
                throw new Exception('ErrorTextUsername');

            if (LibrarianQuery::create()->filterByUsername($username)->count() > 0)
                throw new Exception('ErrorLibrarianUsername');
            if (LibraryQuery::create()->filterByLibraryId($registration_library_id)->count() != 1)
                throw new Exception('ErrorLibrary');

            try {
                $pwd_crypt = Prado::getApplication()->getModule('crypt')->PatronEncrypt($password);
                // checks on enum values
                $loan_classes = array_keys(LookupValuePeer::getLookupClassValues('PATRONLOANCLASS'));
                if (!in_array($loan_class, $loan_classes))
                    $loan_class = $loan_classes[0];
                $patron_statuses = array_keys(LookupValuePeer::getLookupClassValues('PATRONSTATE'));
                if (!in_array($patron_status, $patron_statuses))
                    $patron_status = PatronPeer::STATUS_INCOMPLETE;

                $user = new Patron();
                $user->setOpacUsername($username);
                $user->setOpacSecret($pwd_crypt);
                $user->setOpacSecretExpire($expirepassword);
                $user->setName($name);
                $user->setLastname($lastname);
                $user->setRegistrationLibraryId($registration_library_id);
                $user->setPreferredLibraryId($registration_library_id);
                $user->setNationalId($national_id);
                $user->setPatronStatus($patron_status);
                $user->setLoanClass($loan_class);
                $user->setPrivacyApprove($privacy_approve);
                $user->setAccessNote(Prado::localize("Utente creato da OPAC con verifica del numero di cellulare"));
                $user->setOpacEnable(1);
                $user->save();
                // Recupero lo username
                $user->reload();
                ChangelogPeer::logAction($user, ChangelogPeer::LOG_CREATE, 1, "[WS] creato nuovo utente con verifica del numero di cellulare: [{$user->getPatronId()}] ({$user->getCompleteName()})");
                return $user->toArray();
            } catch (PropelException $e) {
                throw new Exception('ErrorTextUsername');
            } catch (Exception $e) {
                throw new Exception('ErrorGenericUsername');
            }
        } else if ($type_of_registration == "standard") {
            $this->setNewRelicTransaction("SOAP." . __METHOD__);
            if (!$this->_authenticated)
                $this->fault('Wrong auth', 'Authentication credential are not valid', 'Client');
            if (PatronQuery::create()->filterByNationalId($national_id)->count() > 0)
                throw new Exception('Esiste già un utente con questo codice fiscale');
            if (PatronQuery::create()->filterByOpacUsername($username)->count() > 0)
                throw new Exception('Username già scelto da un altro utente');
            if (LibrarianQuery::create()->filterByUsername($username)->count() > 0)
                throw new Exception('A librarian with this username already exists');
            if (LibraryQuery::create()->filterByLibraryId($registration_library_id)->count() != 1)
                throw new Exception('La libreria specificata non esiste.');
            try {
                $pwd_crypt = Prado::getApplication()->getModule('crypt')->PatronEncrypt($password);
                // checks on enum values
                $genders = array_keys(LookupValuePeer::getLookupClassValues('SEX'));
                if (!in_array($gender, $genders))
                    $gender = null;
                $titles = array_keys(LookupValuePeer::getLookupClassValues('TITLE'));
                if (!in_array($title, $titles))
                    $title = null;
                $civil_statuses = array_keys(LookupValuePeer::getLookupClassValues('CIVILSTATE'));
                if (!in_array($civil_status, $civil_statuses))
                    $civil_status = null;
                $doctypes = array_keys(LookupValuePeer::getLookupClassValues('IDDOCS'));
                if (!in_array($document_type, $doctypes))
                    $document_type = null;
                $loan_classes = array_keys(LookupValuePeer::getLookupClassValues('PATRONLOANCLASS'));
                if (!in_array($loan_class, $loan_classes))
                    $loan_class = $loan_classes[0];
                $patron_statuses = array_keys(LookupValuePeer::getLookupClassValues('PATRONSTATE'));
                if (!in_array($patron_status, $patron_statuses))
                    $patron_status = PatronPeer::STATUS_INCOMPLETE;
                $user = new Patron();
                $user->setOpacUsername($username);
                $user->setOpacSecret($pwd_crypt);
                $user->setOpacSecretExpire($expirepassword);
                $user->setName($name);
                $user->setLastname($lastname);
                $user->setRegistrationLibraryId($registration_library_id);
                $user->setPreferredLibraryId($registration_library_id);
                $user->setNationalId($national_id);
                $user->setGender($gender);
                $user->setTitle($title);
                $user->setCivilStatus($civil_status);
                $user->setDocumentType($document_type);
                $user->setDocumentNumber($document_number);
                $user->setDocumentEmitter($document_emitter);
                $user->setDocumentExpiry($document_expiry);
                $user->setCitizenship($citizenship);
                $user->setBirthDate($birth_date);
                $user->setBirthCity($birth_city);
                $user->setBirthProvince($birth_province);
                $user->setBirthCountry($birth_country);
                $user->setPatronStatus($patron_status);
                $user->setLoanClass($loan_class);
                $user->setPrivacyApprove($privacy_approve);
                $user->setAccessNote(Prado::localize("Utente creato da OPAC"));
                $user->setOpacEnable($patronOpacEnabled);
                $user->setSurfEnable($patronSurfEnabled);
                $user->setAccessAlert($patronAccessAlert);
                $user->save();
                // Recupero lo username
                $user->reload();
                ChangelogPeer::logAction($user, ChangelogPeer::LOG_CREATE, 1, "[WS] creato nuovo utente: [{$user->getPatronId()}] ({$user->getCompleteName()})");
                return $user->toArray();
            } catch (PropelException $e) {
                throw new Exception('User already exists');
            } catch (Exception $e) {
                throw new Exception('Patron saving failed');
            }
        }
    }

    /**
     * Changes a patron's prefs.
     *
     * @param string $username
     * @param int $preferred_library_id
     * @param string $statistic_study
     * @param string $statistic_work
     * @param array $areas_of_interest
     * @return array User data.
     * @throws Exception
     * @soapmethod
     */
    public function setUserPrefs($username, $preferred_library_id = null, $statistic_study = null, $statistic_work = null, $areas_of_interest = null)
    {
        $this->setNewRelicTransaction("SOAP." . __METHOD__);
        if (!$this->_authenticated)
            $this->fault('Wrong auth', 'Authentication credential are not valid', 'Client');
        $user = $this->getPatron($this->getClavisUser($username));
        if (!$user instanceof Patron)
            throw new Exception('Invalid patron');

        try {
            if ($preferred_library_id > 0 &&
                LibraryQuery::create()->filterByLibraryId($preferred_library_id)->count() == 1)
                $user->setPreferredLibraryId($preferred_library_id);
            if ($statistic_study !== null)
                $user->setStatisticStudy($statistic_study);
            if ($statistic_work !== null)
                $user->setStatisticWork($statistic_work);
            if (is_array($areas_of_interest))
                $user->setAreasOfInterest($areas_of_interest);
            $user->save();
            ChangelogPeer::logAction($user, ChangelogPeer::LOG_UPDATE, 1, "[WS] preferenze modificate per l'utente [{$user->getPatronId()}] ({$user->getCompleteName()})");
            return $user->toArray();
        } catch (Exception $e) {
            return false;
        }
        return false;
    }

    /**
     * Returns an array of notifications by a specified patron.
     *
     * @param string $username The patron
     * @param bool $unacked If true, returns only not acknowledged (new/unread) notifications.
     * @param int $timelimit Will return only notifications created at last $timelimit ago. 0 means no limit.
     * @return array
     * @throws Exception
     * @soapmethod
     */
    public function getAllOpacNotifications($username, $unacked = false, $timelimit = 0)
    {
        $this->setNewRelicTransaction("SOAP." . __METHOD__);
        if (!$this->_authenticated)
            $this->fault('Wrong auth', 'Authentication credential are not valid', 'Client');
        $user = $this->getPatron($this->getClavisUser($username));
        if (!$user instanceof Patron)
            throw new Exception('Invalid patron');

        $notifications = NotificationQuery::create()
            ->setFormatter(ModelCriteria::FORMAT_ARRAY)
            ->filterByObjectClass('patron')
            ->filterByObjectId($user->getPatronId())
            ->filterByNotificationChannel(NotificationPeer::CHANNEL_PORTAL)
            ->filterByNotificationState(array(
                NotificationPeer::STATUS_PENDING,
                NotificationPeer::STATUS_SENT))
            ->orderByDateCreated();
        if ($timelimit > 0)
            $notifications->filterByDateCreated(time() - $timelimit, Criteria::GREATER_EQUAL);

        return $notifications->find()->toArray();
    }

    /**
     * Acknowledges a notification.
     *
     * @param int $notificationId The id of the notification to acknowledge.
     * @return bool True if acknowledgement was successful, false elsewhere.
     * @throws Exception
     * @soapmethod
     */
    public function ackNotification($notificationId)
    {
        $this->setNewRelicTransaction("SOAP." . __METHOD__);
        if (!$this->_authenticated)
            $this->fault('Wrong auth', 'Authentication credential are not valid', 'Client');
        $n = NotificationQuery::create()
            ->filterByNotificationChannel(NotificationPeer::CHANNEL_PORTAL)
            ->findOneByNotificationId($notificationId);
        if (!$n instanceof Notification)
            throw new Exception('Invalid notification');

        $n->setNotificationState(NotificationPeer::STATUS_DELIVERED);
        $n->setInternalStatus(NotificationPeer::STATUS_DELIVERED);
        $n->setAcknowledgeDate(time());
        $n->save();
        ChangelogPeer::logAction($n, ChangelogPeer::LOG_UPDATE, 1, "[WS] notifica confermata");
        return true;
    }

    /**
     * Returns a list of purchase proposal that belongs to a patron.
     *
     * @param string $username The patron
     * @param string $status (optional) If specified, returns only proposal with this status.
     * @param int $start (optional) Indice dei record
     * @param int $limit (optional) Numero massimo dei record richiesti
     * @return array The purchase proposals list.
     * @throws Exception
     * @soapmethod
     */
    public function getPurchaseProposalList($username, $status = null, $start = null, $limit = null)
    {
        $this->setNewRelicTransaction("SOAP." . __METHOD__);
        if (!$this->_authenticated)
            $this->fault('Wrong auth', 'Authentication credential are not valid', 'Client');
        $user = $this->getPatron($this->getClavisUser($username));
        if (!$user instanceof Patron)
            throw new Exception('Invalid patron');
        $ret = array();
        $ret[0] = PurchaseProposalQuery::create()
            ->setFormatter(ModelCriteria::FORMAT_ARRAY)
            ->filterByPatronId($user->getPatronId())
            ->count();
        $list = PurchaseProposalQuery::create()
            ->setFormatter(ModelCriteria::FORMAT_ON_DEMAND)
            ->filterByPatronId($user->getPatronId())
            ->orderByProposalDate(Criteria::DESC);
        /* Offset paginazione */
        if (intval($start) > 0)
            $list->offset(intval($start));
        /* Limite dei record richiesti */
        if (intval($limit) > 0)
            $list->limit(intval($limit));
        if ($status)
            $list->filterByStatus($status);
        $ls = $list->find();
        foreach ($ls as $l)
            $ret[] = $l->toArray();

        return $ret;
    }

    /**
     * Insert or edit a purchase proposal with specified values.
     * All values are optional, if not specified the related field will be set to ''.
     *
     * @param string $username
     * @param int $proposal_id (optional) the purchase proposal ID; if not specified,
     *            a new proposal will be created.
     * @param string $title
     * @param string $author
     * @param string $publisher
     * @param string $year
     * @param string $ean
     * @param string $notes
     * @return array The proposal data.
     * @throws Exception
     * @soapmethod
     */
    public function editPurchaseProposal($username, $proposal_id = null, $title = '', $author = '', $publisher = '', $year = '', $ean = '', $notes = '')
    {
        $this->setNewRelicTransaction("SOAP." . __METHOD__);
        if (!$this->_authenticated)
            $this->fault('Wrong auth', 'Authentication credential are not valid', 'Client');
        $user = $this->getPatron($this->getClavisUser($username));
        if (!$user instanceof Patron)
            throw new Exception('Invalid patron');
        if ($user->getPatronStatus() != PatronPeer::STATUS_ENABLED)
            throw new Exception('Patron is not enabled');
        try {
            if ($proposal_id) {
                $p = PurchaseProposalQuery::create()->findPk($proposal_id);
                if (!$p instanceof PurchaseProposal)
                    throw new Exception('No proposal matching ID ' . $proposal_id);
                if ($p->getStatus() != PurchaseProposalPeer::STATUS_PENDING)
                    throw new Exception('Cannot edit a proposal already managed.');
                $action = ChangelogPeer::LOG_UPDATE;
                $msg = "[WS] proposta d'acquisto modificata (id: {$p->getProposalId()})";
            } else {
                $p = new PurchaseProposal;
                $p->setPatron($user);
                $p->setStatus(PurchaseProposalPeer::STATUS_PENDING);
                $p->setProposalDate(time());
                $action = ChangelogPeer::LOG_CREATE;
                $msg = "[WS] proposta d'acquisto creata (id: {$p->getProposalId()})";
            }
            $p->setTitle($title);
            $p->setAuthor($author);
            $p->setPublisher($publisher);
            $p->setYear($year);
            $p->setEan($ean);
            $p->setNotes($notes);
            $p->save();
            ChangelogPeer::logAction($user, $action, 1, $msg);
            return $p->toArray();
        } catch (Exception $e) {
            throw new Exception('Proposal saving failed');
        }
    }

    /**
     * Tenta di ritirare una proposta d'acquisto in "attesa"
     *
     * @param int $proposal_id
     * @return bool
     * @throws Exception
     * @soapmethod
     */
    public function retirePurchaseProposal($proposal_id)
    {
        $this->setNewRelicTransaction("SOAP." . __METHOD__);

        if (!$this->_authenticated) {
            $this->fault('Wrong auth', 'Authentication credential are not valid', 'Client');
        }

        try {
            $p = PurchaseProposalQuery::create()->findPk($proposal_id);
            if (!$p instanceof PurchaseProposal)
                throw new Exception('No proposal matching ID ' . $proposal_id);
        } catch (Exception $e) {
            throw new Exception('Proposta inesistente: ' . $proposal_id);
        }

        try {
            if ($p->getStatus() != PurchaseProposalPeer::STATUS_PENDING)
                throw new Exception('Cannot retire a proposal already managed.');
        } catch (Exception $e) {
            throw new Exception('Richiesta di ritiro già gestita dalla biblioteca');
        }

        try {
            if ($p->getPatron()->getPatronStatus() != PatronPeer::STATUS_ENABLED)
                throw new Exception('Patron is not enabled');
        } catch (Exception $e) {
            throw new Exception('Utente non abilitato');
        }

        try {
            $p->setStatus(PurchaseProposalPeer::STATUS_RETIRED);
            $p->save();
            ChangelogPeer::logAction($p->getPatron(), ChangelogPeer::LOG_UPDATE, 1, "[WS] proposta ritirata (id: {$p->getProposalId()})");
            return true;
        } catch (Exception $e) {
            throw new Exception('Errore nella richiesta di ritiro della proposta');
        }
    }

    /**
     * Deletes a contact.
     *
     * @param int $contact_id
     * @return bool
     * @throws Exception
     * @soapmethod
     */
    public function deleteContact($contact_id)
    {
        $this->setNewRelicTransaction("SOAP." . __METHOD__);

        if (!$this->_authenticated)
            $this->fault('Wrong auth', 'Authentication credential are not valid', 'Client');

        try {
            $c = ContactQuery::create()->findPk($contact_id);

            if (!$c instanceof Contact)
                throw new Exception('No contact matching ID ' . $contact_id);

            if (ContactQuery::create()->filterByPatronId($c->getPatronId())->prune($c)->count() < 1)
                throw new Exception('Unable to remove last contact for patron.');

            $user = $c->getPatron();

            if (!$user instanceof Patron)
                throw new Exception('Invalid patron');

            if ($user->getPatronStatus() != PatronPeer::STATUS_ENABLED)
                throw new Exception('Patron is not enabled');

            $patronId = $user->getPatronId();
            $patronName = $user->getCompleteName();

            $contactId = $c->getContactId();
            $contactValue = $c->getContactValue();
            $contactType = $c->getContactTypeString();
            $contactPref = ($c->getContactPref() == '1');

            $msg = "[WS] per l'utente '{$patronName}' (id={$patronId}) è stato eliminto il contatto id={$contactId}, '{$contactValue}' ({$contactType}"
                . ($contactPref ? ", preferito" : "")
                . ")";

            ChangelogPeer::logAction($user,
                ChangelogPeer::LOG_DELETE,
                1,
                $msg);

            $c->delete();

            return true;
        } catch (Exception $e) {
            throw new Exception('Contact deletion failed');
        }
    }

    /**
     * Deletes an address.
     *
     * @param int $address_id
     * @return bool
     * @throws Exception
     * @soapmethod
     */
    public function deleteAddress($address_id)
    {
        $this->setNewRelicTransaction("SOAP." . __METHOD__);

        if (!$this->_authenticated)
            $this->fault('Wrong auth', 'Authentication credential are not valid', 'Client');

        try {
            $a = AddressQuery::create()->findPk($address_id);

            if (!$a instanceof Address)
                throw new Exception('No address matching ID ' . $address_id);

            if (AddressQuery::create()->filterByPatronId($a->getPatronId())->prune($a)->count() < 1)
                throw new Exception('Unable to remove last address for patron.');

            $user = $a->getPatron();

            if (!$user instanceof Patron)
                throw new Exception('Invalid patron');

            if ($user->getPatronStatus() != PatronPeer::STATUS_ENABLED)
                throw new Exception('Patron is not enabled');

            if ($user->getPatronStatus() != PatronPeer::STATUS_ENABLED)
                throw new Exception('Patron is not enabled');

            $patronId = $user->getPatronId();
            $patronName = $user->getCompleteName();

            $addressId = $a->getAddressId();
            $addressType = $a->getAddressTypeString();
            $address = $a->getAddressString();
            $village = trim($a->getVillage());
            $city = trim($a->getCity());
            $zip = trim($a->getZip());
            $province = trim($a->getProvince());
            $country = trim($a->getCountry());
            $preferred = ($a->getAddressPref() == '1');
            $note = trim($a->getAddressNote());

            $msg = "[WS] per l'utente '{$patronName}' (id={$patronId}) è stato cancellato l'indirizzo id={$addressId}, ({$addressType}) "
                . "{$address}";

            if ($village != '')
                $msg .= ", {$village}";

            if ($city != '')
                $msg .= ", {$city}";

            if ($zip != '')
                $msg .= ", {$zip}";

            if ($province != '')
                $msg .= ", {$province}";

            if ($country != '')
                $msg .= ", {$country}";

            if ($preferred)
                $msg .= ", (preferito)";

            if ($note != '')
                $msg .= ", nota={$note}";

            ChangelogPeer::logAction($user,
                ChangelogPeer::LOG_DELETE,
                1,
                $msg);

            $a->delete();

            return true;
        } catch (Exception $e) {
            throw new Exception('Address deletion failed');
        }
    }

}