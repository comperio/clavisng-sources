<?php
/**
 * CatalogFunctions class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Services.SOAP
 */
Prado::using('Application.Services.SOAP.BaseSoap');

/**
 * CatalogFunctions class
 *
 * This class implements a list of SOAP methods for interfacing with Clavis catalog.
 *
 * @author Ciro Mattia Gonano <ciro@comperio .it>
 * @version 2.7
 * @package Services.SOAP
 * @since 2.5.0
 */
class CatalogFunctions extends BaseSoap
{
	private $_user = null;

	/**
	 * Returns an array containing info about a list of manifestations, for each one:
	 *	'reserveable' is true if it's possible to place item requests on the manifestation
	 *  'onloan_items_info' contains all items ON LOAN, with some additional infos:
	 *    'loan_status_str' is the loan status in readable format
	 *    'loan_status' the loan status code
	 *    'due_date' the loan due date
	 *    'patron_id' the id of the borrowing patron
	 *  'due_date_next' the next expected return date
	 *  'visible_items' the total count of visible items
	 * 	'onloan_items' the total count of items on loan
	 *  'pending_requests' the total count of pending requests
	 * 
	 * @param array $mids
	 * @return array
	 * @soapmethod
	 */
	public function getManifestationListInfo(array $mids) {
            $this->setNewRelicTransaction("SOAP." . __METHOD__);
		if (!$this->_authenticated)
			$this->fault('Wrong auth','Authentication credential are not valid','Client');
		$ret = array();
		$marray = ManifestationQuery::create()->joinItem()->findByManifestationId($mids);
		foreach ($marray as $m)
			$ret[$m->getManifestationId()] = $this->getManifestationInfo($m);
		return $ret;
	}

	/**
	 * Returns an array containing info about a single manifestation:
	 *	'reserveable' is true if it's possible to place item requests on the manifestation
	 *  'onloan_items_info' contains all items ON LOAN, with some additional infos:
	 *    'loan_status_str' is the loan status in readable format
	 *    'loan_status' the loan status code
	 *    'due_date' the loan due date
	 *    'patron_id' the id of the borrowing patron
	 *  'due_date_next' the next expected return date
	 *  'visible_items' the total count of visible items
	 * 	'onloan_items' the total count of items on loan
	 *  'pending_requests' the total count of pending requests
	 * 
	 * @param int|Manifestation $m Manifestation object or Manifestation ID.
	 * @return array
	 */
	protected function getManifestationInfo($m) {
		if (!$m instanceof Manifestation)
			$m = ManifestationQuery::create()->joinItem()->findOneByManifestationId($m);
		if (!$m instanceof Manifestation) {
			Prado::log(__CLASS__.'::'.__FUNCTION__.'(): unable to find manifestation ID '.$m->getManifestationId(),'Warning','SOAP');
			return false;
		}
		$reserveEnabled =
			($m->getBibLevel() == ManifestationPeer::LVL_MONOGRAPHIC &&
			Prado::getApplication()->getModule('request')->isManifestationReservable($m) == ClavisLoanManager::OK);
		$ret = array(
			'reserveable'		=> intval($reserveEnabled),
			'onloan_items_info'	=> array(),
			'due_date_next'		=> null,
			'visible_items'		=> 0,
			'onloan_items'		=> 0,
			'pending_requests'	=> 0,
		);
		foreach ($m->getItems() as $item) {
			if ($item->getOpacVisible()) {
				++$ret['visible_items'];
				if ($item->IsLoaned()) {
					++$ret['onloan_items'];
					/* @var $item Item */
					$ret['onloan_items_info'][$item->getItemId()] = array(
						'loan_status_str'	=> $item->getLoanStatusString(),
						'loan_status'	=> $item->getLoanStatus(),
						'due_date'		=> $item->getDueDate('U'),
						'patron_id'		=> $item->getPatronId());
					if (!$ret['due_date_next'] || $ret['due_date_next'] > $item->getDueDate('U'))
						$ret['due_date_next'] = $item->getDueDate('U');
				}
			}
		}
		$ret['pending_requests'] = ItemRequestQuery::create()
			->filterByManifestation($m)
			->filterByRequestStatus(array(ItemRequestPeer::STATUS_PENDING,ItemRequestPeer::STATUS_WORKING))
			->count();
		return $ret;
	}

	/**
	 * Returns a collection of shelves belonging to a library.
	 *
	 * @param int $library_id The library ID
	 * @return array
	 * @soapmethod
	 */
	public function getShelvesForLibrary($library_id) {
            $this->setNewRelicTransaction("SOAP." . __METHOD__);
		if (!$this->_authenticated)
			$this->fault('Wrong auth','Authentication credential are not valid','Client');
		$shelves = ShelfQuery::create()
			->filterByShelfStatus(array(ShelfPeer::VISIBILITY_ALLOPS,ShelfPeer::VISIBILITY_ALLREADONLY,ShelfPeer::VISIBILITY_OPAC))
			->filterByShelfItemtype('manifestation')
			->setFormatter(ModelCriteria::FORMAT_ARRAY)
			->findByLibraryId($library_id);
		return $shelves->toArray();
	}

	/**
	 * Returns a collection of record ids contained in a shelf.
	 *
	 * @param int $shelf_id The shelf ID
	 * @return array
	 * @soapmethod
	 */
	public function getRecordsInShelf($shelf_id) {
             $this->setNewRelicTransaction("SOAP." . __METHOD__);
		if (!$this->_authenticated)
			$this->fault('Wrong auth','Authentication credential are not valid','Client');
		$q = ShelfItemQuery::create()
			->distinct()
			->setFormatter(ModelCriteria::FORMAT_ARRAY)
			->filterByObjectClass(ShelfPeer::TYPE_MANIFESTATION)
			->filterByShelfId($shelf_id)
			->find();
		$recordIds = array();
		foreach ($q as $item)
			$recordIds[] = $item['ObjectId'];
		return $recordIds;
	}

	/**
	 * Perform a search in catalog.
	 *
	 * @param $query
	 * @return array
	 * @soapmethod
	 */
	public function search($query='',$max_results=10,$offset=0) {
            $this->setNewRelicTransaction("SOAP." . __METHOD__);
		return $this->getApplication()->getModule('search')->search($query,$offset,$max_results);
	}
}
