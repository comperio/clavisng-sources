<?php
/**
 * ConsortiaFunctions class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Services.SOAP
 */
Prado::using('Application.Services.SOAP.BaseSoap');

/**
 * ConsortiaFunctions Class
 *
 * ConsortiaFunctions provides a list of SOAP methods for interfacing with Clavis libraries and consortia.
 * 
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Services.SOAP
 * @since 2.5.0
 */
class ConsortiaFunctions extends BaseSoap
{
	/**
	 * Returns libraries in the system.
	 *
	 * @param string $filter Either 'all', 'internal' or 'active'. Defaults to 'all'.
	 * @return array
	 * @soapmethod
	 */
	public function getLibraries($filter='all') {
            $this->setNewRelicTransaction("SOAP." . __METHOD__);
		if (!$this->_authenticated)
			$this->fault('Wrong auth','Authentication credential are not valid','Client');
		$libs = LibraryQuery::create()
			->setFormatter(ModelCriteria::FORMAT_ARRAY);
		switch ($filter) {
			case 'internal':
				$libs->filterByLibraryInternal(true);
				break;
			case 'active':
				$libs->filterByLibraryInternal(true)
					->filterByLibraryStatus(LibraryPeer::STATUS_ACTIVE);
				break;
			case 'all':
			default:
				break;
		}
		return $libs->find()->toArray();
	}

	/**
	 * Returns all internal libraries in the system.
	 *
	 * @return array
	 * @soapmethod
	 */
	public function getInternalLibraries() {
            $this->setNewRelicTransaction("SOAP." . __METHOD__);
		return self::getLibraries('internal');
	}

	/**
	 * Returns all active and internal libraries in the system.
	 *
	 * @return array
	 * @soapmethod
	 */
	public function getActiveLibraries() {
            $this->setNewRelicTransaction("SOAP." . __METHOD__);
		return self::getLibraries('active');
	}

	/**
	 * Returns a collection of libraries related to a librarian.
	 *
	 * @param int $librarian_id The librarian ID
	 * @return array
	 * @soapmethod
	 */
	public function getLibrariesForLibrarian($librarian_id) {
            $this->setNewRelicTransaction("SOAP." . __METHOD__);
		if (!$this->_authenticated)
			$this->fault('Wrong auth','Authentication credential are not valid','Client');
		$libs = LLibraryLibrarianQuery::create()
			->setFormatter(ModelCriteria::FORMAT_ARRAY)
			->joinLibrary()
			->findByLibrarianId($librarian_id);
		return $libs->toArray();
	}

	/**
	 * Returns library data along with staff.
	 *
	 * @param int $library_id
	 * @return array
	 * @soapmethod
	 */
	public function getLibraryData($library_id) {
            $this->setNewRelicTransaction("SOAP." . __METHOD__);
		if (!$this->_authenticated)
			$this->fault('Wrong auth','Authentication credential are not valid','Client');
		$lib = LibraryQuery::create()->findOneByLibraryId($library_id);
		if (!$lib instanceof Library) // try to search by library code
			$lib = LibraryQuery::create()->findOneByLibraryCode($library_id);
		if (!$lib instanceof Library)
			return false;
		$ret = $lib->toArray();
		$ret['staff'] = array();
		$librarians = LLibraryLibrarianQuery::create()
			->filterByOpacVisible(true)
			->useLibrarianQuery()
				->filterByActivationStatus(true)
			->endUse()
			->findByLibraryId($library_id);
		$req = Prado::getApplication()->getRequest();
		$baseUrl = $req->getBaseUrl();
		$roleLabelsMap = LookupValuePeer::getLookupClassValues('LIBRARIANROLE');
		foreach ($librarians as $link) {
			$lib = $link->getLibrarian();
			if (!array_key_exists($link->getLinkRole(), $roleLabelsMap))
				continue;
			$ret['staff'][] = array(
				'FirstName'	=> $lib->getName(),
				'LastName'	=> $lib->getLastname(),
				'RoleCode'	=> $link->getLinkRole(),
				'RoleLabel'	=> $roleLabelsMap[$link->getLinkRole()],
				'Email'		=> $lib->getEmail(),
				'Phone'		=> $lib->getPhone(),
				'Bio'		=> $lib->getLibrarianNote(),
				'PhotoURL'	=> ($lib->getPhotoFileId() > 0) ?
					$baseUrl.$req->constructUrl('file',$lib->getPhotoFileId()) :
					'http://www.gravatar.com/avatar/'.md5(strtolower(trim($lib->getEmail()))).'?r=pg&d=mm&s=100'
			);

		}
		return $ret;
	}

	/**
	 * Returns a collection of timetables for a library in a time interval.
	 *
	 * @param int $library_id
	 * @param int $from From time (timestamp)
	 * @param int $to To time (timestamp)
	 * @return array
	 * @soapmethod
	 */
	public function getLibraryTimetable($library_id,$from,$to) {
            $this->setNewRelicTransaction("SOAP." . __METHOD__);
		if (!$this->_authenticated)
			$this->fault('Wrong auth','Authentication credential are not valid','Client');
		$lib = LibraryQuery::create()->findOneByLibraryId($library_id);
		if (!$lib instanceof Library) // try to search by library code
			$lib = LibraryQuery::create()->findOneByLibraryCode($library_id);
		if (!$lib instanceof Library)
			return false;
		$timetable = LibraryTimetableQuery::create()
			->filterByTimeTableDay(date('Y-m-d',$from),Criteria::GREATER_EQUAL)
			->filterByTimeTableDay(date('Y-m-d',$to+86399),Criteria::LESS_EQUAL)
			->orderBy('TimetableDay')
			->findByLibraryId($lib->getLibraryId());
		$ret = array();
		foreach ($timetable as $tt) {
			$ret[] = array(
				'TimetableDay'		=> $tt->getTimetableDay('U'),
				'TimetableOpen' 	=> $tt->getTimetableOpen(),
				'TimetableHoliday'	=> $tt->getTimetableHoliday(),
				'Time1Start'		=> $tt->getTime1Start(),
				'Time1End'			=> $tt->getTime1End(),
				'Time2Start'		=> $tt->getTime2Start(),
				'Time2End'			=> $tt->getTime2End(),
				'Time3Start'		=> $tt->getTime3Start(),
				'Time3End'			=> $tt->getTime3End(),
				'TimetableNote'		=> $tt->getTimetableNote()
			);
		}
		return $ret;
	}
	
	/**
	 * Returns a list of all distinct classes in lookup_value table, filtered
	 * by language provided.
	 *
	 * @param string $lang The language ISO code (e.g. 'it_IT'). If not specified,
	 *				fallbacks on default locale.
	 * @return array The list of classes.
	 * @soapmethod
	 */
	public function getLookupClasses($lang = null) {
            $this->setNewRelicTransaction("SOAP." . __METHOD__);
		if (!$this->_authenticated)
			$this->fault('Wrong auth','Authentication credential are not valid','Client');
		if (!$lang)
			$lang = $this->getApplication()->getGlobalization()->getCulture();
		$classes = LookupValueQuery::create()
			->filterByValueLanguage($lang)
			->orderByValueClass()
			->select('ValueClass')
			->setDistinct()
			->find()
			->toArray();
		return $classes;
	}
	
	/**
	 * Returns all values for a specific class, filtered by language and ordered
	 * by rank.
	 * 
	 * @param string $class The specified class
	 * @param string $lang (optional) The language ISO code (e.g. 'it_IT').
	 *				If not specified, fallbacks on default locale.
	 * @return array An hash of key => value for class values.
	 * @soapmethod
	 */
	public function getLookupValues($class,$lang=null) {
            $this->setNewRelicTransaction("SOAP." . __METHOD__);
		if (!$this->_authenticated)
			$this->fault('Wrong auth','Authentication credential are not valid','Client');
		if (!$class)
			$this->fault('No class','No class specified','Client');
		if (!$lang)
			$lang = $this->getApplication()->getGlobalization()->getCulture();
		$values = LookupValueQuery::create()
			->filterByValueLanguage($lang)
			->filterByValueClass($class)
			->orderByRank()
			->find();
		$ret = array();
		foreach ($values as $value)
			$ret[$value->getValueKey()] = $value->getValueLabel();
		return $ret;
	}
}
