<?php
/**
 * LoanFunctions class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Services.SOAP
 */
Prado::using('Application.Services.SOAP.BaseSoap');

/**
 * LoanFunctions Class
 *
 * This class implements a list of SOAP methods for interfacing with Clavis loans and circulation.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Services.SOAP
 * @since 2.5.0
 */
class LoanFunctions extends BaseSoap
{
	/**
	 *
	 * @param string $username
	 * @return Patron/Librarian
	 */
	protected function getPatron($username) {
		// search among Librarians
		$user = LibrarianQuery::create()->findOneByUsername($username);
		if (!$user instanceof Librarian) {
			// search among Patrons
			$user = PatronQuery::create()->findOneByOpacUsername($username);
			if (! $user instanceof Patron) {
				$user = PatronQuery::create()->findOneByBarcode($username);
				if (! $user instanceof Patron)
					return false;
			}
		} else {
			$user = $user->getPatron();
		}
		return $user;
	}

	/**
	 * Returns all active loans for a Patron.
	 *
	 * @param string $username The username/barcode for patron to be inspected.
	 * @return array
	 * @soapmethod
	 */
	public function getPatronActiveLoans($username) {
            $this->setNewRelicTransaction("SOAP." . __METHOD__);
		if (!$this->_authenticated)
			$this->fault('Wrong auth','Authentication credential are not valid','Client');
		$ret = array();
		$intLib = LibraryPeer::getLibraries(false, true);
		$patron = $this->getPatron($username);
		if ($patron instanceof Patron) {
			/* @var $lm ClavisLoanManager */
			$lm = $this->getApplication()->getModule('loan');
			$renewWindowFrom = time() + ClavisParamPeer::getParam('LOANRENEWALTIME', 'FROM');
			$renewWindowUntil = time() - ClavisParamPeer::getParam('LOANRENEWALTIME', 'UNTIL');
			$items = ItemQuery::create()
				->filterByPatron($patron)
				->findByLoanStatus(ItemPeer::getLoanStatusActive());
			foreach ($items as $item) {
				/* @var $item Item */
				$iarr = $item->toArray();
				$due_date = $item->getDueDate('U');
				$iarr['Renewable'] = intval(
					$due_date < $renewWindowFrom &&
					$due_date > $renewWindowUntil &&
					$lm->IsLoanRenewable($item, null, $patron) == ClavisLoanManager::OK);
				$iarr['ExtraLib'] = !in_array($item->getOwnerLibraryId(),$intLib);
				$ret[] = $iarr;
			}
		}
		return $ret;
	}

	/**
	 * Returns all pending loans for a Patron.
	 * 'Pending' means the book is on its way to the patron.
	 *
	 * @param string $username The username/barcode for patron to be inspected.
	 * @return array
	 * @soapmethod
	 */
	public function getPatronPendingLoans($username) {
            $this->setNewRelicTransaction("SOAP." . __METHOD__);
		if (! $this->_authenticated)
			$this->fault('Wrong auth','Authentication credential are not valid','Client');
		$ret = array();
		$patron = $this->getPatron($username);
		if ($patron instanceof Patron) {
			$criteria = new Criteria();
			$criteria->add(ItemPeer::LOAN_STATUS, ItemPeer::getLoanStatusPending(), Criteria::IN);
			$ls = $patron->getItems($criteria);
			foreach ($ls as $l)
				$ret[] = $l->toArray();
                        $ret["maxDeliveryTimeout"] = ClavisParamPeer::getParam('READYTOLOANWAIT');
		}
		return $ret;
	}
	
	/**
	  * Returns all closed loans for a Patron, ordered by descending ending date.
	  *
	  * @param string $username Username/barcode
	  * @param int $start (optional) Indice dei record
	  * @param int $limit (optional) Numero massimo di record richiesti
	  * @param string $search (optional) Testo della ricerca
	  * @param string $orderBy (optional) Tipo di ordinamento
	  * @param string $orderDirection (optional) Direzione di ordinamento ASC o DESC
	  * @return array
	  * @soapmethod
	  */
	public function getPatronClosedLoans($username, $start = null, $limit = null, $search = "", $orderBy = null, $orderDirection = null) {
		$this->setNewRelicTransaction("SOAP." . __METHOD__);
		if (! $this->_authenticated) $this->fault('Wrong auth','Authentication credential are not valid','Client');
		$ret = array();

		$patron = $this->getPatron($username);
		if ($patron instanceof Patron) {
		if ($search != "") {
			$ret[0] = LoanQuery::create()
					->setFormatter(ModelCriteria::FORMAT_ON_DEMAND)
					->filterByPatron($patron)
					->filterByLoanStatus("G")
					->filterByTitle("%$search%", Criteria::LIKE)
					->count();
			$q = LoanQuery::create()
				->setFormatter(ModelCriteria::FORMAT_ON_DEMAND)
				->filterByPatron($patron)
				->filterByLoanStatus("G")
				->filterByTitle("%$search%", Criteria::LIKE);
		} else {
			$ret[0] = LoanQuery::create()
					->setFormatter(ModelCriteria::FORMAT_ON_DEMAND)
					->filterByPatron($patron)
					->filterByLoanStatus("G")
					->count();
			$q = LoanQuery::create()
				->setFormatter(ModelCriteria::FORMAT_ON_DEMAND)
				->filterByPatron($patron)
				->filterByLoanStatus("G");
		}

		if($ret[0] > $limit) {
			/* Offset per paginazione della query */
			$q->offset(intval($start));
			/* Limite dei record richiesti */
			$q->limit(intval($limit));
		}

		/* Richiesta di ordinamento */
		if ( ($orderBy != "") && ($orderDirection != "") ) {
			if ($orderDirection == "ASC") {
				$q->$orderBy(Criteria::ASC);
			} else {
				$q->$orderBy(Criteria::DESC);
			}
		}

		$ls = $q->find();
		foreach ($ls as $l) $ret[] = $l->toArray();
		}
		return $ret;
	}

	/**
	 * Returns all active requests for a Patron.
	 *
	 * @param string $username The username/barcode for patron to be inspected.
	 * @return array
	 * @soapmethod
	 */
	public function getPatronActiveRequests($username) {
            $this->setNewRelicTransaction("SOAP." . __METHOD__);
		if (! $this->_authenticated)
			$this->fault('Wrong auth','Authentication credential are not valid','Client');
		$ret = array();
		$patron = $this->getPatron($username);
		if ($patron instanceof Patron) {
			$q = ItemRequestQuery::create()
				->filterByPatron($patron)
				->filterByRequestStatus(array(
					ItemRequestPeer::STATUS_PENDING,
					ItemRequestPeer::STATUS_WORKING))
				->setFormatter(ModelCriteria::FORMAT_ON_DEMAND);
			foreach ($q->find() as $r) {
				/* @var $r ItemRequest */
				$rarr = $r->toArray();
				$rarr['Title'] = $r->getTitle();
				$rarr['Queue'] = $r->getQueuePosition();
                $isExtra = 0;
                if($r->getItem() instanceof Item) {
                    $isExtra = $r->getItem()->getOwnerLibrary()->isExternal();
                }
                $rarr['IsExtra'] = $isExtra;
				$ret[] = $rarr;
			}
		}
		return $ret;
	}
	
	/**
	 * Renews a loan for the specified item.
	 *
	 * @param int $item_id The item
	 * @return string
	 * @soapmethod
	 */
	public function renewItemLoan($item_id) {
            $this->setNewRelicTransaction("SOAP." . __METHOD__);
		if (! $this->_authenticated)
			$this->fault('Wrong auth','Authentication credential are not valid','Client');
		$item = ItemQuery::create()->findPk($item_id);
		if ($item instanceof Item) {
			if (!in_array($item->getLoanStatus(),ItemPeer::getLoanStatusActive()))
				return 'Item is not on loan';
			$patron = $item->getPatron();
			$lm = $this->getApplication()->getModule('loan');
			$due_date = $item->getDueDate('U');
			$renewWindowFrom = time() + ClavisParamPeer::getParam('LOANRENEWALTIME', 'FROM');
			$renewWindowUntil = time() - ClavisParamPeer::getParam('LOANRENEWALTIME', 'UNTIL');
			if ($due_date > $renewWindowFrom)
				return "Renew not allowed: too early (due_date: {$due_date} - allowed from: {$renewWindowFrom})";
			if ($due_date < $renewWindowUntil)
				return "Renew not allowed: too late (due_date: {$due_date} - allowed to: {$renewWindowUntil})";
			$ret = $lm->IsLoanRenewable($item, null, $patron);
			if (ClavisLoanManager::OK != $ret)
				return 'Item is not renewable: '.$ret;
			/* @var $lm ClavisLoanManager */
			$lm = $this->getApplication()->getModule('loan');
			$ret = $lm->DoRenewLoan($item, $patron, null, 'Renewal via OPAC/SOAP');
			return ($ret == ClavisLoanManager::OK) ? 'OK' : 'Error '.$ret;
		}
		return 'Item is not valid';
	}
	
	/**
	 * Places an itemrequest for a manifestation.
	 *
	 * @param int $manifestation_id The manifestation ID.
	 * @param string $username The patron handle to which the request is placed.
	 * @param string $delivery_library The id of the delivery library.
	 * @param int $issue_id (optional) The id of the issue to request.
     * @param string $reservation_note (optional) Nota aggiuntiva dell'utente.
	 * @return string
	 * @soapmethod
	 */
	public function addReservation($manifestation_id,$username,$delivery_library,$issue_id=null, $reservation_note = null) {
            $this->setNewRelicTransaction("SOAP." . __METHOD__);
//		if (! $this->_authenticated)
//			$this->fault('Wrong auth','Authentication credential are not valid','Client');
		$patron = $this->getPatron($username);
		if (! $patron instanceof Patron) {
			Prado::log("Patron not valid [$username]", TLogger::INFO, 'SOAP');
			return 'Patron is not valid.';
		}
		if ($patron->getPatronStatus() != PatronPeer::STATUS_ENABLED) {
			Prado::log("Patron not enabled [$username]", TLogger::INFO, 'SOAP');
			return 'Patron is not enabled.';
		}
		$manifestation = ManifestationQuery::create()->findPk($manifestation_id);
		if (! $manifestation instanceof Manifestation) {
			Prado::log("Manifestation not valid [$manifestation_id]", TLogger::INFO, 'SOAP');
			return 'Manifestation is not valid.';
		}
		$deliveryLibrary = LibraryQuery::create()->findPk($delivery_library);
		if (! $deliveryLibrary instanceof Library) {
			Prado::log("Library not valid [$delivery_library]", TLogger::INFO, 'SOAP');
			return 'Library is not valid.';
		}
		/* @var $rm ClavisRequestManager */
		$rm = $this->getApplication()->getModule('request');
		$distance = null;

		if (ClavisParamPeer::getParam('LLIBRARY_ACTIVE') == 1) {
            $distanceRaw = $rm->calculateMinRequestDistance($manifestation, $delivery_library);

            if (is_null($distanceRaw)) {
                Prado::log("Library not valid [$delivery_library]", TLogger::INFO, 'SOAP');
                return 'Library is not valid.';
            } else {
                $distance = intval($distanceRaw);
            }
        }

        // Verifica se la nota esiste
        If (!$reservation_note)
            $reservation_note = '';

		$returnVal = $rm->reserveManifestation($manifestation,
			$patron,
			$deliveryLibrary,
			null,
            $reservation_note,
			$issue_id,
			null,
			$distance);

		return $returnVal;
	}
	
	/**
	 * Changes an itemrequest delivery library, only if it isn't already managed.
	 *
	 * @param int $request_id The request ID.
	 * @param string $delivery_library The id of the new delivery library.
	 * @return string
	 * @throws Exception
	 * @soapmethod
	 */
	public function changeReservationDeliveryLibrary($request_id,$delivery_library) {
            $this->setNewRelicTransaction("SOAP." . __METHOD__);
		if (! $this->_authenticated)
			$this->fault('Wrong auth','Authentication credential are not valid','Client');
		$deliveryLibrary = LibraryQuery::create()->findPk($delivery_library);
		if (! $deliveryLibrary instanceof Library) {
			Prado::log("Library not valid [$delivery_library]", TLogger::INFO, 'SOAP');
			return 'Library is not valid.';
		}
		$itemRequest = ItemRequestQuery::create()->findPk($request_id);
		if (! $itemRequest instanceof ItemRequest) {
			Prado::log("Request not valid [$request_id]", TLogger::INFO, 'SOAP');
			return 'Request is not valid.';
		}
		if ($itemRequest->getRequestStatus() != ItemRequestPeer::STATUS_PENDING) {
			Prado::log("Request already managed [$request_id]", TLogger::INFO, 'SOAP');
			return 'Request is already managed.';
		}
		if ($itemRequest->getPatron()->getPatronStatus() != PatronPeer::STATUS_ENABLED) {
			Prado::log("Patron not enabled", TLogger::INFO, 'SOAP');
			return 'Patron is not enabled.';
		}
		try {
			$itemRequest->setDeliveryLibraryId($deliveryLibrary->getLibraryId());
			$itemRequest->save();
			ChangelogPeer::logAction($itemRequest, ChangelogPeer::LOG_UPDATE, LibrarianPeer::retrieveByPK(1),
				 '[WS] Modifica della prenotazione con id=' . $itemRequest->getRequestId());
		} catch (Exception $e) {
			throw new Exception('Exception'.$e->getMessage());
		}
		return 'OK';
	}
	
	/**
	 * Cancels a reservation that's not already managed.
	 *
	 * @param int $request_id The request ID.
	 * @return string
	 * @soapmethod
	 */
	public function cancelReservation($request_id) {
            $this->setNewRelicTransaction("SOAP." . __METHOD__);
		if (! $this->_authenticated)
			$this->fault('Wrong auth','Authentication credential are not valid','Client');
		$itemRequest = ItemRequestQuery::create()->findPk($request_id);
		if (! $itemRequest instanceof ItemRequest) {
			Prado::log("Request not valid [$request_id]", TLogger::INFO, 'SOAP');
			return 'Request is not valid.';
		}
		if ($itemRequest->getRequestStatus() != ItemRequestPeer::STATUS_PENDING) {
			Prado::log("Request already managed [$request_id]", TLogger::INFO, 'SOAP');
			return 'Request is already managed.';
		}
		if ($itemRequest->getPatron()->getPatronStatus() != PatronPeer::STATUS_ENABLED) {
			Prado::log("Patron not enabled", TLogger::INFO, 'SOAP');
			return 'Patron is not enabled.';
		}
		try {
			$itemRequest->setRequestStatus(ItemRequestPeer::STATUS_CANCELED);
			$itemRequest->setLibrarianId(null);
			$itemRequest->setLibraryId(null);
			$itemRequest->save();
			ChangelogPeer::logAction($itemRequest, ChangelogPeer::LOG_UPDATE, LibrarianPeer::retrieveByPK(1),
				'[WS] Annullamento della prenotazione con id=' . $itemRequest->getRequestId());
		} catch (Exception $e) {
			throw new Exception('Exception'.$e->getMessage());
		}
		return 'OK';
	}
}
