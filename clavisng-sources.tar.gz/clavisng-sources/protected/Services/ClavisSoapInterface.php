<?php

/**
 * @version 2.7
 */

class ClavisSoapInterface
{
	/**
	 * Reference to LoanManager
	 *
	 * @var ClavisLoanManager
	 */
	private $loanManager;

        
        public function setNewRelicTransaction($transname) {
            
            if (extension_loaded('newrelic')) {
                newrelic_set_appname ("ClavisNG - " . Prado::getApplication()->getID());
                newrelic_name_transaction($transname);
            }
        }
        
        
	/**
	 * @param string $username Librarian Username
	 * @param string $password Librarian Password
	 * @return boolean
	 * @soapmethod
	 */
	public function loginLibrarian($username, $password) {
            $this->setNewRelicTransaction("SOAP." . __METHOD__);
		Prado::log("loginLibrarian: $username, $password", TLogger::INFO, 'SOAP');
		/* @var $lm ClavisLoanManager */
		$this->loanManager = Prado::getApplication()->getModule('loan');
		/* @var $um TAuthManager */
		$auth = Prado::getApplication()->getModule('auth');
		$logi = $auth->login($username, $password);
		Prado::log($logi ? 'Login OK!' : 'Login KO!', TLogger::INFO, 'SOAP');
		return $logi;
	}

	/**
	 * Get an Item via Barcode
	 *
	 * @param string $barcode
	 * @return Item
	 */
	private function findItem($barcode) {
		return ItemQuery::create()->findOneByBarcode($barcode);
	}

	/**
	 * Get a Patron via Barcode
	 *
	 * @param string $barcode
	 * @return Patron
	 */
	private function findPatron($barcode) {
		$patron = PatronQuery::create()->findOneByBarcode($barcode);
        if($patron == null)
            $patron = PatronQuery::create()->findOneByNationalId($barcode);

        return $patron;
	}

	/**
	 * @param string $usernameLib username/barcode (patron)
	 * @param string $passwordLib passowrd
	 * @param string $username username/barcode (patron)
	 * @param string $password passowrd
	 * @return array
	 * @soapmethod
	 */
	public function loginUser($usernameLib, $passwordLib, $username, $password) {
            $this->setNewRelicTransaction("SOAP." . __METHOD__);
		$login = $this->loginLibrarian($usernameLib, $passwordLib);
		if ($login) {
			$patron = $this->authenticatePatron($username, $password);
			/** @var $patron Patron */
			if ($patron != null) {
				$c = new Criteria();
				$c->add(LoanPeer::LOAN_STATUS, ItemPeer::getLoanStatusActive(), Criteria::IN);
				$loans = $patron->getLoansJoinItemRelatedByItemId($c);
				$loanHash = array();
				/* @var $loan Loan */
				foreach ($loans as $loan) {
					$loanHash [] = array(
						'Title' => $loan->getItem()->getTitle(),
						'Barcode' => $loan->getItem()->getBarcode(),
						'DueDate' => $loan->getDueDate('d-m-Y'),
						'Late' => ($loan->getDueDate('Ymd') < date('Ymd')) ? 'Y' : 'N',
						'Status' => $loan->getLoanStatusString(),
						'StatusCode' => $loan->getLoanStatus(),
						'ActualLib' => $loan->getItem()->getActualLibraryId(),
						'ActualLibString' => $loan->getItem()->getActualLibrary()->getLabel(),
						'HomeLib' => $loan->getItem()->getHomeLibraryId(),
						'HomeLibString' => $loan->getItem()->getHomeLibrary()->getLabel());
				}
				$userData = array(
					'Nome'		=> $patron->getCompleteName(),
					'Barcode'	=> $patron->getBarcode(),
					'Status'	=> $patron->getPatronStatusString(),
					'Loans'		=> $loanHash);
				return $userData;
			}
		}
		$ret = array('Error' => 'Errore di autenticazione');
		return $ret;
	}

	/**
	 * @param string $username username/barcode (patron)
	 * @param string $password passowrd
	 * @param string $libraryId
	 * @return array
	 * @soapmethod
	 */
	public function listInTransit($username, $password, $libraryId) {
            $this->setNewRelicTransaction("SOAP." . __METHOD__);
		Prado::log("List in transit [$libraryId]", TLogger::INFO, 'SOAP');
		$login = $this->loginLibrarian($username, $password);
		if ($login) {
			/** @var $url TUri */
			$items = ItemQuery::create()
				->filterByLoanStatus('C')
				->filterByDeliveryLibraryId($libraryId)
				->find();
			$itemData = array();
			foreach ($items as $item) {
				$itemData[] = array(
					'Title' => $item->getTitle(),
					'Author' => $item->getManifestation()->getAuthor(),
					'Year' => $item->getManifestation()->getEditionDate(),
					'Publisher' => $item->getManifestation()->getPublisher(),
					'CoverUrl' => Prado::getApplication()->getRequest()->getBaseUrl()
						.Prado::getApplication()->getRequest()->constructUrl('file','cover',array('id'=>$item->getManifestationId())),
					'BookID' => $item->getManifestationId(),
					'Barcode' => $item->getBarcode(),
					'Scadenza' => $item->getDueDate('d-m-Y'),
					'Stato' => $item->getLoanStatusString(),
					'StatoCode' => $item->getLoanStatus(),
					'PatronId' => $item->getPatronBarcode(),
					'DeliveryLib' => $item->getDeliveryLibraryId(),
					'DeliveryLibString' => $item->getDeliveryLibrary()->getLabel(),
					'ActualLib' => $item->getActualLibraryId(),
					'ActualLibString' => $item->getActualLibrary()->getLabel(),
					'DueDate' => (intval($item->getCurrentLoanId() > 0)) ? LoanPeer::retrieveByPk($item->getCurrentLoanId())->getDueDate('d-m-Y') : '');
			}
			return $itemData;
		}
		$ret = array('Error' => 'Errore di autenticazione');
		return $ret;
	}

	/**
	 * @param string $username username/barcode (patron)
	 * @param string $password passowrd
	 * @param string $barcode
	 * @return array
	 * @soapmethod
	 */
	public function bookLoad($username, $password, $barcode) {
            $this->setNewRelicTransaction("SOAP." . __METHOD__);
		Prado::log("BookLoad", TLogger::INFO, 'SOAP');
		$login = $this->loginLibrarian($username, $password);
		if ($login) {
			$item = $this->findItem($barcode);
			if ($item != null) {
				if ($this->loanManager->IsInTransit($item)) {
					$result = $this->loanManager->DoMoved2ReadyToLoanItem($item, Prado::getApplication()->getUser());
					if ($result) {
						Prado::log('Load OK', TLogger::INFO, 'SOAP');
						// TODO inviare una email all'utente
						return array('Result' => 'Esemplare pronto al prestito');
					} else {
						return array('Error' => 'Errore generico...');
					}
				} else {
					return array('Error' => 'L\'esemplare non risulta in transito');
				}
			} else {
				return array('Error' => 'Barcode sconosciuto');
			}
		}
		return array('Error' => 'Errore di autorizzazione');
	}

	/**
	 * @param string $username username/barcode (patron)
	 * @param string $password passowrd
	 * @param string $barcode
	 * @return array
	 * @soapmethod
	 */
	public function bookUnLoad($username, $password, $barcode) {
            $this->setNewRelicTransaction("SOAP." . __METHOD__);
		Prado::log('BookUnload', TLogger::INFO, 'SOAP');
		$login = $this->loginLibrarian($username, $password);
		if ($login) {
			$item = $this->findItem($barcode);
			if ($item != null) {
				if ($this->loanManager->IsReadyForTransit($item)) {
					$result = $this->loanManager->DoReadyToMove2MovingItem($item, Prado::getApplication()->getUser());
					if ($result) {
						Prado::log('UnLoad OK', TLogger::INFO, 'SOAP');
						// TODO inviare una email all'utente
						return array('Result' => 'Esemplare in transito');
					} else {
						return array('Error' => 'Errore generico...');
					}
				} else {
					return array('Error' => 'L\'esemplare non risulta in pronto al transito');
				}
			} else {
				return array('Error' => 'Barcode sconosciuto');
			}
		}
		return array('Error' => 'Errore di autorizzazione');
	}

	/**
	 * @param string $username username/barcode (macchina)
	 * @param string $password passowrd   (macchina)
	 * @param string $barcode
	 * @return array
	 * @soapmethod
	 */
	public function checkBook($username, $password, $barcode) {
            $this->setNewRelicTransaction("SOAP." . __METHOD__);
		Prado::log('CheckBook', TLogger::INFO, 'SOAP');

		$login = $this->loginLibrarian($username, $password);
		if ($login) {
			/** @var $url TUri */
			$c = new Criteria();
			$c->add(ItemPeer::BARCODE, $barcode);
			$item = ItemPeer::doSelectOne($c);
			if ($item != null) {
				Prado::log("Book $barcode trovato", TLogger::INFO, 'SOAP');

				$reqCount = ItemRequestQuery::create()
					->filterByManifestationId($item->getManifestationId())
					->_if($item->getManifestationId() == 0)
						->filterByItemId($item->getItemId())
					->_endif()
					->filterByRequestStatus(ItemRequestPeer::getActiveStatus())
					->count();

                $manId = $item->getManifestationId();
				$bookInfo = array(
					'Title' => $item->getTitle(),
					'Author' => ($manId == 0)?"":$item->getManifestation()->getAuthor(),
					'Year' => ($manId == 0)?"":$item->getManifestation()->getEditionDate(),
					'Publisher' => ($manId == 0)?"":$item->getManifestation()->getPublisher(),
					'CoverUrl' => Prado::getApplication()->getRequest()->getBaseUrl()
						.Prado::getApplication()->getRequest()->constructUrl('file','cover',array('id'=>$item->getManifestationId())),
					'BookID' => $item->getManifestationId(),
					'Barcode' => $item->getBarcode(),
					'Scadenza' => $item->getDueDate('d-m-Y'),
					'Stato' => $item->getLoanStatusString(),
					'StatoCode' => $item->getLoanStatus(),
					'PatronId' => $item->getPatronBarcode(),
                    'Section' => $item->getSection(),
                    'Collocation' => $item->getCollocation(),
					'CollocationCombo' => $item->getCollocationCombo(),
					'Reservation' => $reqCount,
					'DeliveryLib' => $item->getDeliveryLibraryId(),
					'ActualLib' => $item->getActualLibraryId(),
					'ActualLibString' => $item->getActualLibrary()->getLabel(),
					'DueDate' => (intval($item->getCurrentLoanId() > 0)) ? LoanPeer::retrieveByPk($item->getCurrentLoanId())->getDueDate('d-m-Y') : '');
				return $bookInfo;
			} else {
				Prado::log("Errore barcode $barcode sconosciuto", TLogger::INFO, 'SOAP');
				return array('Error' => 'Barcode sconosciuto');
			}
		}
		Prado::log('Autenticazione fallita', TLogger::INFO, 'SOAP');
		return array('Error' => 'Autenticazione errata');
	}

	/**
	 * @param string $username username/barcode (macchina)
	 * @param string $password passowrd   (macchina)
	 * @param string $barcodePatron
	 * @param string $barcodeItem
	 * @return array
	 * @soapmethod
	 */
	public function isLoanAllowed($username, $password, $barcodePatron, $barcodeItem) {
            $this->setNewRelicTransaction("SOAP." . __METHOD__);
		Prado::log('isLoanAllowed', TLogger::INFO, 'SOAP');
		$ret = false;
		$login = $this->loginLibrarian($username, $password);
		if ($login) {
			$item = $this->findItem($barcodeItem);
			$patron = $this->findPatron($barcodePatron);
			if ($item != null) {
				if ($patron != null) {
                    $itemOk = $this->loanManager->IsItemAvailable($item,Prado::getApplication()->getUser()->getActualLibraryId());
					$loanOK = $this->loanManager->IsLoanAllowed($item, $patron, Prado::getApplication()->getUser()->getActualLibraryId());

                    if($item->getLoanClass() == ItemPeer::LOANCLASS_LOCALCONSULTATION ||
                        $item->getLoanClass() == ItemPeer::LOANCLASS_ONLYCONSULTATION)
                        $itemOk = false;

					if ($loanOK && $itemOk) {
						return array('Result' => 'OK');
					} else {
						Prado::log("LoanAllowedError esemplare $barcodeItem all'utente $barcodePatron KO", TLogger::INFO, 'SOAP');
						return array('Error' => 'Prestito non consentito');
					}
				} else {
					Prado::log("Barcode utente $barcodeItem sconosciuto", TLogger::INFO, 'SOAP');
					return array('Error' => "Barcode Utente $barcodeItem sconosciuto");
				}
			} else {
				Prado::log("Esemplare $barcodeItem sconosciuto", TLogger::INFO, 'SOAP');
				return array('Error' => "Barcode esemplare $barcodeItem sconosciuto");
			}
		}
		Prado::log('Autenticazione fallita', TLogger::INFO, 'SOAP');
		return array('Error' => 'Autenticazione errata');
	}

	/**
	 * @param string $username username/barcode (macchina)
	 * @param string $password passowrd   (macchina)
	 * @param string $barcodePatron
	 * @param string $barcodeItem
	 * @return array
	 * @soapmethod
	 */
	public function newLoan($username, $password, $barcodePatron, $barcodeItem) {
            $this->setNewRelicTransaction("SOAP." . __METHOD__);
		Prado::log('New loan', TLogger::INFO, 'SOAP');
		$ret = false;
		$login = $this->loginLibrarian($username, $password);
		if ($login) {
			$item = $this->findItem($barcodeItem);
			$patron = $this->findPatron($barcodePatron);
			if ($item != null)
			{
				$this->loanManager->putLostToAvailableItem($item->getItemId());
				
				if ($patron != null) {

                    $itemOk = $this->loanManager->IsItemAvailable($item,Prado::getApplication()->getUser()->getActualLibraryId());
					$loanOK = $this->loanManager->IsLoanAllowed($item, $patron, Prado::getApplication()->getUser()->getActualLibraryId());

                    if($item->getLoanClass() == ItemPeer::LOANCLASS_LOCALCONSULTATION ||
                        $item->getLoanClass() == ItemPeer::LOANCLASS_ONLYCONSULTATION)
                        $itemOk = false;

					if ($itemOk && $loanOK) {
						if ($item->getLoanStatus() == ItemPeer::LOANSTATUS_READYFORLOAN)
							$ret = $this->loanManager->DoReadyToLoan2LoanItem($item, Prado::getApplication()->getUser());
						elseif ($item->getLoanStatus() == ItemPeer::LOANSTATUS_AVAILABLE
							|| $item->getLoanStatus() == ItemPeer::LOANSTATUS_READYFORTRANSITTOHOME)
							$ret = $this->loanManager->DoLoanItem($item, $patron, Prado::getApplication()->getUser(), Prado::getApplication()->getUser()->getActualLibrary());

						if (($ret == true) || ($ret == ClavisLoanManager::OK))
						{
							Prado::log("Prestito esemplare $barcodeItem all'utente $barcodePatron OK", TLogger::INFO, 'SOAP');

							return array('DueDate' => $item->getDueDate("d-m-Y"), 'LoanStatus' => $item->getLoanStatus());
						} else {
							Prado::log("DoLoanItem error esemplare $barcodeItem all'utente $barcodePatron KO", TLogger::INFO, 'SOAP');
							return array('Error' => 'Prestito non consentito');
						}
					} else {
						Prado::log("LoanAllowedError esemplare $barcodeItem all'utente $barcodePatron KO", TLogger::INFO, 'SOAP');
						return array('Error' => 'Prestito non consentito');
					}
				} else {
					Prado::log("Barcode utente $barcodeItem sconosciuto", TLogger::INFO, "SOAP");
					return array('Error' => "Barcode Utente $barcodeItem sconosciuto");
				}
			} else {
				Prado::log("Esemplare $barcodeItem sconosciuto", TLogger::INFO, 'SOAP');
				return array('Error' => "Barcode esemplare $barcodeItem sconosciuto");
			}
		}

		Prado::log('Autenticazione fallita', TLogger::INFO, 'SOAP');
		return array('Error' => 'Autenticazione errata');
	}

	/**
	 * @param string $username username/barcode (macchina)
	 * @param string $password passowrd   (macchina)
	 * @param string $barcodePatron
	 * @param string $barcodeItem
	 * @return array
	 * @soapmethod
	 */
	public function returnItem($username, $password, $barcodeItem) {
            $this->setNewRelicTransaction("SOAP." . __METHOD__);
		Prado::log("Return item $barcodeItem", TLogger::INFO, 'SOAP');
		$login = $this->loginLibrarian($username, $password);
		if ($login) {
			$item = $this->findItem($barcodeItem);
			if ($item != null) {
				$this->loanManager->putLostToAvailableItem($item->getItemId());
				
				$ret = $this->loanManager->DoReturnItem($item, $item->getPatron(), Prado::getApplication()->getUser());
				$ret = true;
				if ($ret) {
					Prado::log("Restituzione $barcodeItem OK", TLogger::INFO, 'SOAP');
					return array();
				} else {
					Prado::log("Errore durante restituzione $barcodeItem", TLogger::INFO, 'SOAP');
					return array('Error' => 'Errore durante la restituzione');
				}
			} else {
				Prado::log("Esemplare $barcodeItem sconosciuto", TLogger::INFO, "SOAP");
				return array('Error' => "Esemplare $barcodeItem sconosciuto");
			}
		}
		Prado::log('Autenticazione fallita', TLogger::INFO, "SOAP");
		return array('Error' => 'Errore di autorizzazione');
	}

	/**
	 * Authenticate a Patron an return a Patron instance
	 *
	 * @param string $username
	 * @param string $password
	 * @return Patron
	 */
	private function authenticatePatron($barcode, $password) {
		$crypt = Prado::getApplication()->getModule('crypt');
		$patron = PatronQuery::create()->findOneByBarcode($barcode);
		if($patron == null)
            $patron = PatronQuery::create()->findOneByNationalId($barcode);

		if ($patron instanceof Patron && $crypt->PatronVerify($password, $patron->getOpacSecret())) {
			Prado::log("authenticatePatron: $barcode OK", TLogger::INFO, 'SOAP');
			return $patron;
		} else {
			Prado::log("authenticatePatron: $barcode NON OK", TLogger::INFO, 'SOAP');
			return $patron;
		}
	}
}
