<?php
/**
 * ClavisRestApi class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 * For Commercial Licenses and support please contact Comperio.
 */

/**
 * ClavisRestApi Class
 *
 * @author Dario Rigolin <drigolin@comperio.it>
 * @author Ciro Mattia Gonano
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.7
 * @package Services
 * @since 2.6.1
 */
class ClavisRestApi extends TService
{
    protected $reply = array();
    protected $librarian = null;

    /**
     * Runs the service.
     */
    public function run()
    {
        Prado::log(__METHOD__ . " called", TLogger::INFO, 'SOAP');
        Prado::log($this->getRequest()->getUrl()->getPath(), TLogger::INFO, 'SOAP');
        $this->reply['REQUEST'] = array(
            "ID" => $this->getApplication()->getID(),
            "REQUESTMETHOD" => $_SERVER['REQUEST_METHOD'],
            //   "SERVICEPARAM" => $this->getRequest()->getServiceParameter(),
            //   "SERVICEID" => $this->getService()->getID(),
            "USERHOST" => $this->getRequest()->getUserHostAddress(),
            "APIOBJECT" => $this->getRequest()->itemAt("object"),
            "APIMETHOD" => $this->getRequest()->itemAt("method"),
            "APIID" => $this->getRequest()->itemAt("id"),

            "XSIGNATURE" => @$_SERVER['HTTP_X_CLAVIS_SIGNATURE'],
            "XUSERNAME" => @$_SERVER['HTTP_X_CLAVIS_USERNAME'],
            "XPASSWORD" => @$_SERVER['HTTP_X_CLAVIS_PASSWORD'],
            "XLIBRARY" => @$_SERVER['HTTP_X_CLAVIS_LIBRARY'],
            "REQSTART" => microtime(true));

        $librarian = LibrarianQuery::create()->findOneByUsername(@$_SERVER['HTTP_X_CLAVIS_USERNAME']);
        if ($librarian instanceof Librarian && $librarian->getActivationStatus() == 1)  {
            $crypt = $this->getApplication()->getModule('crypt');

            if(substr($librarian->getSecret(),0,4) == "tok:" &&
                password_verify(@$_SERVER['HTTP_X_CLAVIS_PASSWORD'], substr($librarian->getSecret(),4))
                ) {
                $this->librarian = $librarian;

            } elseif ($librarian->getActivationStatus() == 1 && $crypt->LibrarianVerify(@$_SERVER['HTTP_X_CLAVIS_PASSWORD'], $librarian->getSecret())) {
                $this->librarian = $librarian;
            }
        }
        if ($this->librarian == null) {
            Prado::log('REST API Librarian NULL!!!', TLogger::ALERT, 'SOAP');
        }

        $reqMethod = ucfirst($_SERVER['REQUEST_METHOD']);
        $apiObject = ucfirst($this->getRequest()->itemAt("object"));
        $apiMethod = ucfirst($this->getRequest()->itemAt("method"));

        $methodToCall = "{$reqMethod}{$apiObject}{$apiMethod}";

        if (extension_loaded('newrelic')) {
            newrelic_set_appname("ClavisNG - " . $this->getApplication()->getID());
            newrelic_name_transaction($methodToCall);
            foreach ($this->reply['REQUEST'] as $k => $v) {
                if ($k !== "ID")
                    newrelic_add_custom_parameter($k, $v);
            }
        }

        $replyOk = true;
        if (method_exists($this, $methodToCall)) {
            $replyOk = $this->$methodToCall();
        } else {
            Prado::log(__METHOD__ . " {$methodToCall} not exist. wrong url?");
            $this->reply["REPLY"] = array("STATUS" => "KO", "ERRORINFO" => " {$methodToCall}: method not implemented");
        }

        if ($replyOk)
            $this->sendReply();
    }

    private function sendReply()
    {
        ini_set('memory_limit', '1024M');
        $this->reply["REQUEST"]["REQEND"] = microtime(true);
        $this->reply["REQUEST"]["REQTIME"] = $this->reply["REQUEST"]["REQEND"] - $this->reply["REQUEST"]["REQSTART"];

        $response = $this->getResponse();
        $response->setCharset('UTF-8');

        switch ($this->getRequest()->itemAt('output')) {
            case "raw":
                $response->setCacheControl('nocache');
                $mime_type = Clavis::mime_content_type($this->reply['REPLY']['RAW_FILENAME']);
                $response->writeFile('turnstile.db',
                    file_get_contents($this->reply['REPLY']['RAW_FILENAME']),
                    $mime_type,
                    array('Content-type: ' . $mime_type),
                    false);
                break;

            case "phps":
                $response->setContentType('application/phps');
                $response->write(serialize($this->reply));
                break;

            case "xml":
                $response->setContentType('text/xml');
                $response->write($this->array2xml($this->reply));
                break;

            case "json":
            default:
                $response->setContentType('application/json');
                $response->write(TJavaScript::jsonEncode($this->reply));
                break;
        }
    }

    private function array2xml($array, $xml = false)
    {
        if ($xml === false) {
            $xml = new SimpleXMLElement('<root/>');
        }
        foreach ($array as $key => $value) {
            if (is_array($value)) {
                $this->array2xml($value, $xml->addChild($key));
            } else {
                $xml->addChild($key, $value);
            }
        }
        return $xml->asXML();
    }


    private function PostItemReadytoLoan()
    {
        Prado::log('PostItemReadyToLoan start', TLogger::INFO, 'SOAP');
        /** @var $lm ClavisLoanManager */
        $lm = Prado::getApplication()->getModule("loan");
        /** @var ClavisRequestManager $rm */
        $rm = Prado::getApplication()->getModule("request");
        $auth = Prado::getApplication()->getModule('auth');

        $login = $auth->login($this->reply["REQUEST"]['XUSERNAME'], $this->reply["REQUEST"]['XPASSWORD']);
        Prado::log($login ? 'Login OK!' : 'Login KO!', TLogger::INFO, 'SOAP');

        if (!$login) {
            $this->reply['REPLY']['STATUS'] = "KO";
            $this->reply['REPLY']['ERRORCODE'] = "AUTHERR";
            $this->reply['REPLY']['ERRORINFO'] = "Errore di autenticazione";
            return true;
        }

        $itembarcode = $this->getRequest()->itemAt('itemid');
        $item = ItemQuery::create()->findOneByBarcode($itembarcode);
        if ($lm->IsInTransit($item)) {
            if ($lm->DoMoved2ReadyToLoanItem($item, Prado::getApplication()->getUser())) {
                $this->reply['REPLY']['STATUS'] = "OK";
                $this->reply['REPLY']['RESULT']['Status'] = "READYTOLOAN";

                if (ClavisParamQuery::getParam('CLAVISPARAM', 'AutoEmailLoanReady') == 'true') {
                    $ret = NotificationHelper::sendNotificationEmail('readyforloan',
                        $item->getPatron(),
                        $this->librarian,
                        $item->getLibraryRelatedByActualLibraryId(),
                        array($item->getCurrentLoanId()));

                    if ($ret) {
                        $item->setNotifyCount($item->getNotifyCount() + 1);
                        $item->save();

                        $loan = $item->getLoanRelatedByCurrentLoanId();
                        $loan->setNotifyCount($loan->getNotifyCount() + 1);
                        $loan->save();
                    }
                }

            } else {
                $this->reply['REPLY']['STATUS'] = "KO";
                $this->reply['REPLY']['RESULT']['Status'] = "ERROR";
                $this->reply['REPLY']['ERRORINFO'] = "Errore generico interno";
            }

        } else {
            $this->reply['REPLY']['STATUS'] = "KO";
            $this->reply['REPLY']['RESULT']['Status'] = "NOTINTRANSIT";
            $this->reply['REPLY']['ERRORINFO'] = "Esemplare non in transito";
        }

        return true;
    }


    private function PostItemForcetransit()
    {
        Prado::log('PostItemForceTransit start', TLogger::INFO, 'SOAP');
        /** @var $lm ClavisLoanManager */
        $lm = Prado::getApplication()->getModule("loan");
        /** @var ClavisRequestManager $rm */
        $rm = Prado::getApplication()->getModule("request");
        $auth = Prado::getApplication()->getModule('auth');

        $login = $auth->login($this->reply["REQUEST"]['XUSERNAME'], $this->reply["REQUEST"]['XPASSWORD']);
        Prado::log($login ? 'Login OK!' : 'Login KO!', TLogger::INFO, 'SOAP');

        if (!$login) {
            $this->reply['REPLY']['STATUS'] = "KO";
            $this->reply['REPLY']['ERRORCODE'] = "AUTHERR";
            $this->reply['REPLY']['ERRORINFO'] = "Errore di autenticazione";
            return true;
        }

        $itembarcode = $this->getRequest()->itemAt('itemid');
        $item = ItemQuery::create()->findOneByBarcode($itembarcode);
        if ($lm->IsReadyForTransit($item)) {
            if ($lm->DoReadyToMove2MovingItem($item, Prado::getApplication()->getUser())) {
                $this->reply['REPLY']['STATUS'] = "OK";
                $this->reply['REPLY']['RESULT']['Status'] = "INTRANSIT";
            } else {
                $this->reply['REPLY']['STATUS'] = "KO";
                $this->reply['REPLY']['RESULT']['Status'] = "ERROR";
                $this->reply['REPLY']['ERRORINFO'] = "Errore generico interno";
            }

        } else {
            $this->reply['REPLY']['STATUS'] = "KO";
            $this->reply['REPLY']['RESULT']['Status'] = "NOTINTRANSIT";
            $this->reply['REPLY']['ERRORINFO'] = "Esemplare non pronto al transito";
        }

        return true;
    }

    private function PostItemAbortloan()
    {
        Prado::log('PostItemAbortLoan start', TLogger::INFO, 'SOAP');
        /** @var $lm ClavisLoanManager */
        $lm = Prado::getApplication()->getModule("loan");
        /** @var ClavisRequestManager $rm */
        $rm = Prado::getApplication()->getModule("request");
        $auth = Prado::getApplication()->getModule('auth');

        $login = $auth->login($this->reply["REQUEST"]['XUSERNAME'], $this->reply["REQUEST"]['XPASSWORD']);
        Prado::log($login ? 'Login OK!' : 'Login KO!', TLogger::INFO, 'SOAP');

        if (!$login) {
            $this->reply['REPLY']['STATUS'] = "KO";
            $this->reply['REPLY']['ERRORCODE'] = "AUTHERR";
            $this->reply['REPLY']['ERRORINFO'] = "Errore di autenticazione";
            return true;
        }

        $itembarcode = $this->getRequest()->itemAt('itemid');
        $item = ItemQuery::create()->findOneByBarcode($itembarcode);
        if ($lm->IsLoanStatusActive($item)) {
            if ($lm->DoAbortLoan($item, null, Prado::getApplication()->getUser(), ItemActionPeer::TYPE_ABORTGENERIC, "Annullamento via API")) {
                $this->reply['REPLY']['STATUS'] = "OK";
                $this->reply['REPLY']['RESULT']['Status'] = "ABORTED";
            } else {
                $this->reply['REPLY']['STATUS'] = "KO";
                $this->reply['REPLY']['RESULT']['Status'] = "ERROR";
                $this->reply['REPLY']['ERRORINFO'] = "Errore generico interno";
            }

        } else {
            $this->reply['REPLY']['STATUS'] = "KO";
            $this->reply['REPLY']['RESULT']['Status'] = "NOTINTRANSIT";
            $this->reply['REPLY']['ERRORINFO'] = "Esemplare non in prestito";
        }

        return true;
    }

    private function PostItemCheckout()
    {
        Prado::log('GetItemCheckOut start', TLogger::INFO, 'SOAP');
        /** @var $lm ClavisLoanManager */
        $lm = Prado::getApplication()->getModule("loan");
        /** @var ClavisRequestManager $rm */
        $rm = Prado::getApplication()->getModule("request");
        $auth = Prado::getApplication()->getModule('auth');

        $login = $auth->login($this->reply["REQUEST"]['XUSERNAME'], $this->reply["REQUEST"]['XPASSWORD']);
        Prado::log($login ? 'Login OK!' : 'Login KO!', TLogger::INFO, 'SOAP');

        if (!$login) {
            $this->reply['REPLY']['STATUS'] = "KO";
            $this->reply['REPLY']['ERRORCODE'] = "AUTHERR";
            $this->reply['REPLY']['ERRORINFO'] = "Errore di autenticazione";
            return true;
        }

        $itembarcode = $this->getRequest()->itemAt('itemid');
        $item = ItemQuery::create()->findOneByBarcode($itembarcode);

        $patronbarcode = $this->getRequest()->itemAt('patronid');
        $patron = PatronQuery::create()->findOneByBarcode($patronbarcode);
        if ($patron == null)
            $patron = PatronQuery::create()->findOneByNationalId($patronbarcode);

        $loanonbooked = $this->getRequest()->itemAt('loanonbooked') == "true";
        $consultation = $this->getRequest()->itemAt('consultation') == "true";

        if ($item instanceof Item && $patron instanceof Patron) {
            $lm->putLostToAvailableItem($item->getItemId());

            $this->reply['REPLY']['RESULT'] = array(
                "Title" => $item->getTitle(),

                "Message" => "",
                "Media" => $item->getItemMedia(),
                "ItemId" => $item->getItemId(),
                "Barcode" => $item->getBarcode(),
                "LoanClass" => $item->getLoanClass(),
                "Inventory" => $item->getCompleteInventoryNumber(),
                "Collocation" => $item->getCollocationCombo(),
                "Rfid" => $item->getRfidCode(),
                "Renewable" => false,
                "Late" => false
            );

            $isReadyForLoanOk = ($item->getPatronId() == $patron->getPatronId()) && ($item->getLoanStatus() == ItemPeer::LOANSTATUS_READYFORLOAN);

            if ($item->IsLoaned() && (!$isReadyForLoanOk)) {
                $this->reply['REPLY']['STATUS'] = "OK";
                $this->reply['REPLY']['RESULT']['Status'] = "LOAN";

            } else if ((!$loanonbooked) && (!$isReadyForLoanOk) && ($rm->countRequests(0, null, $item->getItemId(), null, true) > 0)) {
                $this->reply['REPLY']['STATUS'] = "OK";
                $this->reply['REPLY']['RESULT']['Status'] = "BOOK";

            } else if ($lm->IsLoanAllowed($item, $patron, $this->reply['REQUEST']['XLIBRARY'])) {

                $this->reply['REPLY']['STATUS'] = "OK";

                if ($consultation) {
                    $previousLoanClass = $item->getLoanClass();
                    if (!$item->isStatusConsultation())
                        $item->setLoanClass(ItemPeer::LOANCLASS_ONLYCONSULTATION);
                }
                $res = $lm->DoLoanItem($item, $patron, Prado::getApplication()->getUser(), LibraryQuery::create()->findPk($this->reply['REQUEST']['XLIBRARY']));

                if ($consultation) {
                    $item->setLoanClass($previousLoanClass);
                    $item->save();
                }

                $item->reload();

                $this->reply['REPLY']['RESULT']["LoanStatusRes"] = $res;
                $this->reply['REPLY']['RESULT']["DueDate"] = $item->getDueDate('%F');
                $this->reply['REPLY']['RESULT']["LoanStatus"] = $item->getLoanStatus();
                if ($res == ClavisLoanManager::OK || $res == ClavisLoanManager::LOAN_LOANED) {
                    $this->reply['REPLY']['RESULT']['Status'] = "OK";
                } else {
                    $this->reply['REPLY']['RESULT']['Status'] = "ERR";
                }
            } else {
                $this->reply['REPLY']['STATUS'] = "OK";
                $this->reply['REPLY']['RESULT']['Status'] = "CARD";
                $this->reply['REPLY']['RESULT']["LoanStatus"] = "ERR";
            }
        } else {
            $this->reply['REPLY']['STATUS'] = "KO";
            $this->reply['REPLY']['ERRORCODE'] = "NOTFOUND";
            $this->reply['REPLY']['ERRORINFO'] = "Barcode sconosciuto";
        }

        return true;
    }

    private function GetItemCheckin()
    {
        Prado::log('GetItemCheckin start', TLogger::INFO, 'SOAP');
        /** @var $lm ClavisLoanManager */
        $lm = Prado::getApplication()->getModule("loan");
        $auth = Prado::getApplication()->getModule('auth');

        if ($this->librarian == null) {
            Prado::log("GetPatronStatus AUTH ERR", TLogger::INFO, 'SOAP');
            $this->reply['REPLY']['STATUS'] = "KO";
            $this->reply['REPLY']['ERRORCODE'] = "AUTHERR";
            $this->reply['REPLY']['ERRORINFO'] = "Non autorizzato";
            return true;
        }

        Prado::getApplication()->getUser()->setActualLibraryId($this->reply['REQUEST']['XLIBRARY']);
        Prado::getApplication()->getUser()->setId($this->librarian->getLibrarianId());

        $itembarcode = $this->getRequest()->itemAt('id');
        $item = ItemQuery::create()->findOneByBarcode($itembarcode);
        if ($item instanceof Item) {
            $lm->putLostToAvailableItem($item->getItemId());

            if ($lm->IsItemLoaned($item)) {
                $late = ($lm->isLoanLate($item) == ClavisLoanManager::LOAN_ISLATE);
                $patron = $item->getPatron();
                $resCheckIn = $lm->DoReturnItem($item, null, Prado::getApplication()->getUser());

                $status = "ERR";
                $message = "";
                if ($resCheckIn == ClavisLoanManager::OK) $status = "OK";
                else if ($resCheckIn == ClavisLoanManager::RETN_PATRONREQUEST) $status = "OKREQ";
                else if ($resCheckIn == ClavisLoanManager::ERROR) $status = "ERR";

                if ($late) $status = "LATE";


                $patronHasFee = false;
                if ($patron instanceof Patron) {
                    if ($this->getApplication()->getModule("fee") instanceof TModule)
                        if ($this->getApplication()->getModule("fee")->patronHasFee($patron))
                            $patronHasFee = true;

                }

                $item->reload();
                $this->reply['REPLY']['STATUS'] = "OK";
                $this->reply['REPLY']['RESULT'] = array(
                    "Title" => $item->getTitle(),
                    "DueDate" => $item->getDueDate('%F'),
                    "LoanStatus" => $item->getLoanStatus(),
                    "LoanClass" => $item->getLoanClass(),
                    "Status" => $status,
                    "Message" => $message,
                    "Media" => $item->getItemMedia(),
                    "ItemId" => $item->getItemId(),
                    "Barcode" => $item->getBarcode(),
                    "Inventory" => $item->getCompleteInventoryNumber(),
                    "PatronHasFee" => $patronHasFee,
                    "Collocation" => $item->getCollocationCombo(),
                    "Rfid" => $item->getRfidCode(),
                    "Renewable" => (bool)($lm->IsLoanRenewable($item) == ClavisLoanManager::OK),
                    "Late" => (bool)($lm->isLoanLate($item) == ClavisLoanManager::LOAN_ISLATE)
                );
            } else {

                $this->reply['REPLY']['STATUS'] = "OK";
                $this->reply['REPLY']['RESULT'] = array(
                    "Title" => $item->getTitle(),
                    "DueDate" => $item->getDueDate('%F'),
                    "LoanStatus" => $item->getLoanStatus(),
                    "LoanClass" => $item->getLoanClass(),
                    "Status" => "NOTLOAN",
                    "Message" => "",
                    "PatronHasFee" => false,
                    "Media" => $item->getItemMedia(),
                    "ItemId" => $item->getItemId(),
                    "Rfid" => $item->getRfidCode(),
                    "Barcode" => $item->getBarcode(),
                    "Renewable" => (bool)($lm->IsLoanRenewable($item) == ClavisLoanManager::OK),
                    "Late" => false
                );
            }
        } else {
            $this->reply['REPLY']['STATUS'] = "KO";
            $this->reply['REPLY']['ERRORCODE'] = "NOTFOUND";
            $this->reply['REPLY']['ERRORINFO'] = "Barcode sconosciuto";
        }
        return true;
    }

    private function GetBidCheck()
    {
        Prado::log('GetBIDCheck start', TLogger::INFO, 'SOAP');
        $bid = $this->getRequest()->itemAt('id');
        $man = ManifestationQuery::create()->findOneByBid($bid);
        if ($man == null)
            $man = ManifestationQuery::create()->findOneByBid("IT\\ICCU\\" . substr($bid, 0, 3) . "\\" . substr($bid, 3));

        if ($man instanceof Manifestation) {

            $baseUrl = rtrim(ClavisParamQuery::getParam('CLAVISPARAM', 'OpacUrl'), '/') . '/opac/detail/view/';

            $this->reply['REPLY']['STATUS'] = "OK";
            $this->reply['REPLY']['RESULT'] = [
                'MANID' => $man->getManifestationId(),
                'OPACURL' => $baseUrl . $man->getManifestationId(),
                'CLAVISURL' => ''
            ];
        } else {
            $this->reply['REPLY']['STATUS'] = "KO";
            $this->reply['REPLY']['ERRORCODE'] = "";
            $this->reply['REPLY']['ERRORINFO'] = "";
        }

        return true;
    }

    private function GetRfidCheck()
    {
        Prado::log('GetBIDCheck start', TLogger::INFO, 'SOAP');
        $rfid = $this->getRequest()->itemAt('id');
        $item = ItemQuery::create()->findOneByRfidCode($rfid);

        if ($item instanceof Item) {

            $this->reply['REPLY']['STATUS'] = "OK";
            $this->reply['REPLY']['RESULT'] = [
                'Title' => $item->getTitle(),
                'Barcode' => $item->getBarcode(),
                'Library' => $item->getHomeLibraryLabel()
            ];
        } else {
            $this->reply['REPLY']['STATUS'] = "KO";
            $this->reply['REPLY']['ERRORCODE'] = "";
            $this->reply['REPLY']['ERRORINFO'] = "";
        }

        return true;
    }

    private function GetItemOpacheck()
    {
        Prado::log('GetOpacCheck start', TLogger::INFO, 'SOAP');

        if ($this->librarian == null) {
            Prado::log("GetOpacCheck AUTH ERR", TLogger::INFO, 'SOAP');
            $this->reply['REPLY']['STATUS'] = "KO";
            $this->reply['REPLY']['ERRORCODE'] = "AUTHERR";
            $this->reply['REPLY']['ERRORINFO'] = "Non autorizzato";
            return true;
        }

        $ean = $this->getRequest()->itemAt('id');

        $search = $this->getApplication()->getModule('search');
        $search->setRecordCollection(null);
        $response = $search->search("fldin_txt_numbers:({$ean}) +collection:catalog", 0, 10, '', array());

        if ($response && $response['response']['numFound'] >= 0) {

            $baseUrl = rtrim(ClavisParamQuery::getParam('CLAVISPARAM', 'OpacUrl'), '/') . '/opac/detail/view/';

            $this->reply['REPLY']['STATUS'] = "OK";
            $this->reply['REPLY']['RESULT'] = [
                'NUMFOUND' => $response['response']['numFound'],
                'OPACURL' => "{$baseUrl}" . $response['response']['docs'][0]['id'],
                'LIBRARIES' => []
            ];

            foreach ($response['response']['docs'] as $doc) {
                $items = ItemQuery::create()
                    ->filterByItemStatus(['E'], Criteria::NOT_IN)
                    ->filterByManifestationId($doc['Id'])->find();
                foreach ($items as $item) {
                    /** @var Item $item */
                    $bib = $item->getHomeLibraryLabel();
                    if (!isset($this->reply['REPLY']['RESULT']['LIBRARIES'][$bib]))
                        $this->reply['REPLY']['RESULT']['LIBRARIES'][$bib] = 0;

                    $this->reply['REPLY']['RESULT']['LIBRARIES'][$bib]++;
                }
            }


            $this->reply['REPLY']['ERRORCODE'] = "";
            $this->reply['REPLY']['ERRORINFO'] = "";

            return true;

        } else {
            $this->reply['REPLY']['STATUS'] = "OK";
            $this->reply['REPLY']['RESULT'] = [
                'NUMFOUND' => 0,
                'OPACURL' => '',
                'LIBRARIES' => []
            ];
            $this->reply['REPLY']['ERRORCODE'] = "";
            $this->reply['REPLY']['ERRORINFO'] = "";
            return true;
        }
    }

    private function GetLibraryStatus()
    {
        Prado::log('GetLibraryStatus start', TLogger::INFO, 'SOAP');

        if ($this->librarian == null) {
            Prado::log("GetLibraryStatus AUTH ERR", TLogger::INFO, 'SOAP');
            $this->reply['REPLY']['STATUS'] = "KO";
            $this->reply['REPLY']['ERRORCODE'] = "AUTHERR";
            $this->reply['REPLY']['ERRORINFO'] = "Non autorizzato";
            return true;
        }

        $library = LibraryQuery::create()->findPk($this->getRequest()->itemAt('id'));

        if ($library instanceof Library) {
            if ($library->isLibraryOpen() == LibraryPeer::OPEN) {
                $this->reply['REPLY']['STATUS'] = "OK";
                $this->reply['REPLY']['ERRORCODE'] = "";
                $this->reply['REPLY']['ERRORINFO'] = "";
                $this->reply['REPLY']['RESULT'] = "OPEN";
            } elseif ($library->isLibraryOpen() == LibraryPeer::NOTSETOPEN) {
                $this->reply['REPLY']['STATUS'] = "OK";
                $this->reply['REPLY']['ERRORCODE'] = "";
                $this->reply['REPLY']['ERRORINFO'] = "";
                $this->reply['REPLY']['RESULT'] = "OPEN";
            } else {
                $this->reply['REPLY']['STATUS'] = "OK";
                $this->reply['REPLY']['ERRORCODE'] = "";
                $this->reply['REPLY']['ERRORINFO'] = "";
                $this->reply['REPLY']['RESULT'] = "CLOSED";
            }

        } else {
            $this->reply['REPLY']['STATUS'] = "KO";
            $this->reply['REPLY']['ERRORCODE'] = "LIBUNK";
            $this->reply['REPLY']['ERRORINFO'] = "Biblioteca sconosciuta";
        }

        return true;

    }

    private function GetItemStatus()
    {
        Prado::log('GetItemStatus start', TLogger::INFO, 'SOAP');

        if ($this->librarian == null) {
            Prado::log("GetItemStatus AUTH ERR", TLogger::INFO, 'SOAP');
            $this->reply['REPLY']['STATUS'] = "KO";
            $this->reply['REPLY']['ERRORCODE'] = "AUTHERR";
            $this->reply['REPLY']['ERRORINFO'] = "Non autorizzato";
            return true;
        }

        $itembarcode = $this->getRequest()->itemAt('id');
        $item = ItemQuery::create()->findOneByBarcode($itembarcode);
        if ($item instanceof Item) {
            $this->reply['REPLY']['STATUS'] = "OK";
            $this->reply['REPLY']['RESULT'] = array(
                "Title" => $item->getTitle(),
                "DueDate" => $item->getDueDate('%F'),
                "LoanStatus" => $item->getLoanStatus(),
                "LoanClass" => $item->getLoanClass(),
                "Status" => "",
                "Message" => "",
                "Media" => $item->getItemMedia(),
                "ItemId" => $item->getItemId(),
                "Barcode" => $item->getBarcode(),
                "Inventory" => $item->getCompleteInventoryNumber(),
                "Collocation" => $item->getCollocationCombo(),
                "Rfid" => $item->getRfidCode(),
                "PatronBarcode" => (($item->getPatron() instanceof Patron) ? $item->getPatron()->getBarcode() : ""),
                "ActualLibrary" => $item->getActualLibraryId(),
                "HomeLibrary" => $item->getHomeLibraryId(),
                "DeliveryLibrary" => $item->getDeliveryLibraryId(),
                "Renewable" => false,
                "Late" => false
            );
        } else {
            $this->reply['REPLY']['STATUS'] = "KO";
            $this->reply['REPLY']['ERRORCODE'] = "NOTFOUND";
            $this->reply['REPLY']['ERRORINFO'] = "Barcode sconosciuto";
        }
        return true;
    }

    private function GetItemDetail()
    {
        Prado::log('GetItemDetail start', TLogger::INFO, 'SOAP');

        if ($this->librarian == null) {
            Prado::log("GetItemStatus AUTH ERR", TLogger::INFO, 'SOAP');
            $this->reply['REPLY']['STATUS'] = "KO";
            $this->reply['REPLY']['ERRORCODE'] = "AUTHERR";
            $this->reply['REPLY']['ERRORINFO'] = "Non autorizzato";
            return true;
        }

        $itembarcode = $this->getRequest()->itemAt('id');
        $item = ItemQuery::create()->leftJoinManifestation()->findOneByBarcode($itembarcode);

        if ($item instanceof Item && $item->getManifestation() instanceof Manifestation) {
            $man = $item->getManifestation();
            $tm = $man->getTurboMarc();

            $abstract = $tm->getAbstract();
            $ean = $man->getEan();
            $author = $man->getAuthor();
            $lang = $man->getEditionLanguage();
            $otherLangs = "..";
            $phys = $tm->getPhysicalDesc(false);
            $year = $man->getEditionDate();
        } else {
            $abstract = "";
            $ean = "";
            $author = "";
            $lang = "";
            $otherLangs = "";
            $phys = "";
            $year = "";
        }

        if ($item instanceof Item) {
            $this->reply['REPLY']['STATUS'] = "OK";
            $this->reply['REPLY']['RESULT'] = array(
                "Title" => $item->getTitle(),
                "DueDate" => $item->getDueDate('%F'),
                "LoanStatus" => $item->getLoanStatus(),
                "LoanClass" => $item->getLoanClass(),
                "Status" => "",
                "Message" => "",
                "Media" => $item->getItemMedia(),
                "ItemId" => $item->getItemId(),
                "Barcode" => $item->getBarcode(),
                "Inventory" => $item->getCompleteInventoryNumber(),
                "Collocation" => $item->getCollocationCombo(),
                "Rfid" => $item->getRfidCode(),
                "PatronBarcode" => (($item->getPatron() instanceof Patron) ? $item->getPatron()->getBarcode() : ""),
                "ActualLibrary" => $item->getActualLibraryId(),
                "HomeLibrary" => $item->getHomeLibraryId(),
                "DeliveryLibrary" => $item->getDeliveryLibraryId(),
                "Renewable" => false,
                "Late" => false,

                "Abstract" => $abstract,
                "EAN" => $ean,
                "Author" => $author,
                "Language" => $lang,
                "Otherlanguages" => $otherLangs,
                "PhysicalDescription" => $phys,
                "Year" => $year

            );
        } else {
            $this->reply['REPLY']['STATUS'] = "KO";
            $this->reply['REPLY']['ERRORCODE'] = "NOTFOUND";
            $this->reply['REPLY']['ERRORINFO'] = "Barcode sconosciuto";
        }
        return true;
    }

    private function GetPatronRenew()
    {
        Prado::log('GetPatronRenew start', TLogger::INFO, 'SOAP');
        /** @var $lm ClavisLoanManager */
        $lm = Prado::getApplication()->getModule("loan");
        if ($this->librarian == null) {
            Prado::log("GetPatronStatus AUTH ERR", TLogger::INFO, 'SOAP');
            $this->reply['REPLY']['STATUS'] = "KO";
            $this->reply['REPLY']['ERRORCODE'] = "AUTHERR";
            $this->reply['REPLY']['ERRORINFO'] = "Non autorizzato";
            return true;
        }
        $patronid = $this->getRequest()->itemAt('id');
        $patron = PatronQuery::create()->findOneByPatronId($patronid);

        if ($patron instanceof Patron) {
            Prado::log("GetPatronRenew OK ID:[{$patronid}]", TLogger::INFO, 'SOAP');
            $this->reply['REPLY']['STATUS'] = "OK";
            $patronData = array(
                "Name" => trim($patron->getName() . ' ' . $patron->getLastname()),
                "Status" => $patron->getPatronStatus(),
                "Email" => $patron->getEmail2String(),
                "BirthData" => $patron->getBirthDate(),
                "PatronId" => $patron->getPatronId(),
                "Barcode" => $patron->getBarcode(),
                "InLoan" => 0,
                "InTransit" => 0,
                "ReadyToLoan" => 0,
                "Late" => 0,
                "Loans" => array()
            );

            $loans = $patron->getItems();

            foreach ($loans as $l) {

                $due_date = $l->getDueDate('U');
                $renewWindowFrom = time() - ClavisParamPeer::getParam('LOANRENEWALTIME', 'FROM');
                $renewWindowUntil = time() + ClavisParamPeer::getParam('LOANRENEWALTIME', 'UNTIL');
                if (($lm->IsLoanRenewable($l) == ClavisLoanManager::OK)
                    && $due_date >= $renewWindowFrom && $due_date <= $renewWindowUntil
                )
                    $renew = true;
                else
                    $renew = false;

                if ($renew) {
                    $r = $lm->DoRenewLoan($l, $patron, null, null);
                    Prado::log("Renew " . $l->getBarcode() . " : " . Prado::varDump($r), TLogger::INFO, 'SOAP');
                }

                $l->reload();
                $status = "OK";
                $message = "";

                if ($l->getLoanStatus() == ItemPeer::LOANSTATUS_READYFORLOAN) {
                    $status = "READY";
                    $message = "Pronto al prestito";
                    $patronData['ReadyToLoan']++;
                } else if ($l->getLoanStatus() == ItemPeer::LOANSTATUS_INTRANSIT) {
                    $status = "INTRANSIT";
                    $message = "In Transito";
                    $patronData['InTransit']++;
                } else if ($lm->isLoanLate($l) == ClavisLoanManager::LOAN_ISLATE) {
                    $status = "LATE";
                    $message = "Scaduto";
                    $patronData['Late']++;

                }
                $patronData['InLoan']++;

                $patronData['Loans'][] = array(
                    "Title" => $l->getTitle(),
                    "DueDate" => $l->getDueDate('%F'),
                    "LoanStatus" => $l->getLoanStatus(),
                    "Status" => $status,
                    "Message" => $message,
                    "Media" => $l->getItemMedia(),
                    "ItemId" => $l->getItemId(),
                    "ActualLibrary" => $l->getActualLibraryId(),
                    "LoanClass" => $l->getLoanClass(),
                    "Barcode" => $l->getBarcode(),
                    "Inventory" => $l->getCompleteInventoryNumber(),
                    "Collocation" => $l->getCollocationCombo(),
                    "Renewable" => (bool)($lm->IsLoanRenewable($l) == ClavisLoanManager::OK),
                    "Late" => (bool)($lm->isLoanLate($l) == ClavisLoanManager::LOAN_ISLATE)
                );
            }

            $this->reply['REPLY']['RESULT'] = $patronData;
        } else {
            Prado::log("GetPatronStatus ID:[{$patronid}] NOT FOUND", TLogger::INFO, 'SOAP');
            $this->reply['REPLY']['STATUS'] = "KO";
            $this->reply['REPLY']['ERRORCODE'] = "NOTFOUND";
            $this->reply['REPLY']['ERRORINFO'] = "ID sconosciuto";

        }

        return true;
    }


    /* Get PatronCheck
        api/vi/patron/check/12342
    */
    private function GetPatronCheck()
    {
        Prado::log('GetPatronCheck start', TLogger::INFO, 'SOAP');
        /** @var $lm ClavisLoanManager */
        $lm = Prado::getApplication()->getModule("loan");

        if ($this->librarian == null) {
            Prado::log("GetPatronCheck AUTH ERR", TLogger::INFO, 'SOAP');
            $this->reply['REPLY']['STATUS'] = "KO";
            $this->reply['REPLY']['ERRORCODE'] = "AUTHERR";
            $this->reply['REPLY']['ERRORINFO'] = "Non autorizzato";
            return true;
        }

        Prado::getApplication()->getUser()->setActualLibraryId($this->reply['REQUEST']['XLIBRARY']);
        Prado::getApplication()->getUser()->setId($this->librarian->getLibrarianId());

        $patronUsername = $this->getRequest()->itemAt('id');

        $patronCount = PatronQuery::create()
            ->filterByOpacUsername($patronUsername)
            ->_or()
            ->filterByNationalId($patronUsername)
            ->count();

        $patron = PatronQuery::create()->findOneByOpacUsername($patronUsername);

        if ($patron == null) {
            $patron = PatronQuery::create()->findOneByNationalId($patronUsername);
        }

        if ($patron instanceof Patron && $patronCount == 1) {
            Prado::log("GetPatronStatus OK Barcode:[{$patronUsername}]", TLogger::INFO, 'SOAP');
            $this->reply['REPLY']['STATUS'] = "OK";
            $this->reply['REPLY']['PATRON'] = $patron->toArray();
        } elseif ($patronCount > 1) {
            $this->reply['REPLY']['STATUS'] = "KO";
            $this->reply['REPLY']['ERRORCODE'] = "DUPLICATE";
            $this->reply['REPLY']['ERRORINFO'] = "Utente doppio";
            return true;
        } else {
            $this->reply['REPLY']['STATUS'] = "KO";
            $this->reply['REPLY']['ERRORCODE'] = "NOTFOUND";
            $this->reply['REPLY']['ERRORINFO'] = "Utente sconosciuto";
            return true;
        }

        return true;
    }

    /* Get PatronStatus
        api/vi/patron/status/12342
    */
    private function GetPatronStatus()
    {
        Prado::log('GetPatronStatus start', TLogger::INFO, 'SOAP');
        /** @var $lm ClavisLoanManager */
        $lm = Prado::getApplication()->getModule("loan");

        if ($this->librarian == null) {
            Prado::log("GetPatronStatus AUTH ERR", TLogger::INFO, 'SOAP');
            $this->reply['REPLY']['STATUS'] = "KO";
            $this->reply['REPLY']['ERRORCODE'] = "AUTHERR";
            $this->reply['REPLY']['ERRORINFO'] = "Non autorizzato";
            return true;
        }

        $auth = Prado::getApplication()->getModule('auth');

        $librarian = LibrarianQuery::create()->findOneByUsername($this->reply['REQUEST']['XUSERNAME']);

        Prado::getApplication()->getUser()->setActualLibraryId($this->reply['REQUEST']['XLIBRARY']);
        Prado::getApplication()->getUser()->setId($this->librarian->getLibrarianId());

        $patronBarcode = $this->getRequest()->itemAt('id');

        $patronCount = PatronQuery::create()->filterByBarcode($patronBarcode)->count();

        $patron = PatronQuery::create()->findOneByBarcode($patronBarcode);
        if ($patron == null) {
            $patron = PatronQuery::create()->findOneByNationalId($patronBarcode);
            $patronCount = PatronQuery::create()->filterByNationalId($patronBarcode)->count();
        }
        if ($patron instanceof Patron && $patronCount == 1) {
            Prado::log("GetPatronStatus OK Barcode:[{$patronBarcode}]", TLogger::INFO, 'SOAP');

            $patronHasFee = false;
            if ($this->getApplication()->getModule("fee") instanceof TModule) {
                if ($this->getApplication()->getModule("fee")->patronHasFee($patron)) {
                    $patronHasFee = true;
                }
            }

            $this->reply['REPLY']['STATUS'] = "OK";
            $patronData = array(
                "Name" => trim($patron->getName() . ' ' . $patron->getLastname()),
                "Status" => $patron->getPatronStatus(),
                "LoanClass" => $patron->getLoanClass(),
                "Email" => $patron->getEmail2String(),
                "Phone" => $patron->getPhone2String(),
                "BirthData" => $patron->getBirthDate(),
                "PatronId" => $patron->getPatronId(),
                "Barcode" => $patron->getBarcode(),
                "OpacEn" => $patron->getOpacEnable(),
                "SurfEn" => $patron->getSurfEnable(),
                "VoiceEn" => $patron->getVoiceEnable(),
                "HasPendingFee" => $patronHasFee,
                "HasPendingWallet" => $patron->hasPendingWallets(),
                "InLoan" => 0,
                "InTransit" => 0,
                "ReadyToLoan" => 0,
                "Late" => 0,
                "Loans" => array()
            );

            $loans = $patron->getItems();
            foreach ($loans as $l) {
                $status = "OK";
                $message = "";

                if ($l->getLoanStatus() == ItemPeer::LOANSTATUS_READYFORLOAN) {
                    $status = "READY";
                    $message = "Pronto al prestito";
                    $patronData['ReadyToLoan']++;
                } else if ($l->getLoanStatus() == ItemPeer::LOANSTATUS_INTRANSIT || $l->getLoanStatus() == ItemPeer::LOANSTATUS_READYFORTRANSIT) {
                    $status = "INTRANSIT";
                    $message = "In Transito";
                    $patronData['InTransit']++;
                } else if ($lm->isLoanLate($l) == ClavisLoanManager::LOAN_ISLATE && ($l->getLoanStatus() == ItemPeer::LOANSTATUS_INLOAN || $l->getLoanStatus() == ItemPeer::LOANSTATUS_INCONSULTATION)) {
                    $status = "LATE";
                    $message = "Scaduto";
                    $patronData['Late']++;

                }
                $patronData['InLoan']++;

                $due_date = $l->getDueDate('U');
                $renewWindowFrom = time() - ClavisParamPeer::getParam('LOANRENEWALTIME', 'FROM');
                $renewWindowUntil = time() + ClavisParamPeer::getParam('LOANRENEWALTIME', 'UNTIL');
                if (($lm->IsLoanRenewable($l) == ClavisLoanManager::OK)
                    && $due_date >= $renewWindowFrom && $due_date <= $renewWindowUntil
                )
                    $renew = true;
                else
                    $renew = false;

                $patronData['Loans'][] = array(
                    "Title" => $l->getTitle(),
                    "DueDate" => $l->getDueDate('%F'),
                    "LoanStatus" => $l->getLoanStatus(),
                    "Status" => $status,
                    "Message" => $message,
                    "Media" => $l->getItemMedia(),
                    "ItemId" => $l->getItemId(),
                    "ActualLibrary" => $l->getActualLibraryId(),
                    "LoanClass" => $l->getLoanClass(),
                    "Barcode" => $l->getBarcode(),
                    "Inventory" => $l->getCompleteInventoryNumber(),
                    "Collocation" => $l->getCollocationCombo(),
                    "Renewable" => $renew,
                    "Late" => (bool)($lm->isLoanLate($l) == ClavisLoanManager::LOAN_ISLATE && ($l->getLoanStatus() == ItemPeer::LOANSTATUS_INLOAN || $l->getLoanStatus() == ItemPeer::LOANSTATUS_INCONSULTATION))
                );
            }

            $this->reply['REPLY']['RESULT'] = $patronData;
        } else {
            Prado::log("GetPatronStatus Barcode:[{$patronBarcode}] NOT FOUND", TLogger::INFO, 'SOAP');
            $this->reply['REPLY']['STATUS'] = "KO";
            $this->reply['REPLY']['ERRORCODE'] = ($patronCount > 1) ? "MULTIPLE INSTANCES" : "NOTFOUND";
            $this->reply['REPLY']['ERRORINFO'] = ($patronCount > 1) ? "Barcode doppio" : "Barcode sconosciuto";
        }

        return true;
    }


    /**
     * Perform get request (friendly-url, see application.xml).
     * Calling via /api/v1/patron/turnstile/<import|all|today|id>
     *
     */
    private function GetPatronTurnstile()
    {

        if ($this->librarian == null) {
            Prado::log(__METHOD__ . " AUTH ERR", TLogger::INFO, 'SOAP');
            $this->reply['REPLY']['STATUS'] = "KO";
            $this->reply['REPLY']['ERRORCODE'] = "AUTHERR";
            $this->reply['REPLY']['ERRORINFO'] = "Non autorizzato";
            return true;
        }
        set_time_limit(0);
        switch ($this->getRequest()->itemAt('id')) {

            case 'import':
                $this->reply['REPLY'] = array("STATUS" => "OK");
                $pquery = PatronQuery::create()
                    ->select(array('PatronId', 'Name', 'Lastname', 'Barcode', 'DateUpdated', 'check_in', 'check_out'))
                    ->filterByBarcode(null, Criteria::NOT_EQUAL);

                $datefrom = $this->getRequest()->itemAt('datefrom');
                if (!is_null($datefrom)) {
                    $pquery->filterByDateUpdated(urldecode($datefrom), Criteria::GREATER_THAN);
                }
                //Prado::log($pquery->toString());
                $this->reply['REPLY']['QUERY'] = $pquery->toString();
                $this->reply['REPLY']['RESULT'] = $pquery->find();

                break;

            case 'all':
                $this->reply['REPLY'] = array("STATUS" => "OK");
                $c = Propel::getConnection();
                $stmt = $c->prepare('SELECT ' . PatronPeer::BARCODE . ' as Barcode,' .
                    PatronPeer::CHECK_IN . ' as CheckIn,' .
                    PatronPeer::CHECK_OUT . ' as CheckOut,' .
                    PatronPeer::CHECK_LIBRARY . ' as CheckLibrary,' .
                    PatronPeer::DATE_UPDATED . ' as DateUpdated ' .
                    ' FROM ' . PatronPeer::TABLE_NAME . ' WHERE ' . PatronPeer::BARCODE . ' IS NOT NULL');
                $stmt->execute();
                $this->reply['REPLY']['RESULT'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
                break;

            case 'allsqlite':
                $c = Propel::getConnection();
                $stmt = $c->prepare('SELECT ' . PatronPeer::BARCODE . ' as Barcode,' .
                    PatronPeer::CHECK_IN . ' as CheckIn,' .
                    PatronPeer::CHECK_OUT . ' as CheckOut,' .
                    PatronPeer::CHECK_LIBRARY . ' as CheckLibrary,' .
                    PatronPeer::DATE_UPDATED . ' as DateUpdated ' .
                    ' FROM ' . PatronPeer::TABLE_NAME . ' WHERE ' . PatronPeer::BARCODE . ' IS NOT NULL');
                $stmt->execute();
                $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
                try {
                    $tmpdir = Prado::getPathOfNamespace('Storage.temp');
                    $dbfile = $tmpdir . '/turnstile.db';
                    if (file_exists($dbfile))
                        unlink($dbfile);
                    $db = new SQLite3($dbfile);
                    $db->query('DROP TABLE IF EXISTS patron');
                    $db->query('CREATE TABLE patron(Barcode TEXT PRIMARY KEY ASC, CheckIn TEXT, CheckOut TEXT, CheckLibrary TEXT, DateUpdated TEXT)');
                    $db->query('BEGIN TRANSACTION');
                    $dbins = $db->prepare('INSERT INTO patron(Barcode, CheckIn, CheckOut,CheckLibrary,DateUpdated) VALUES (:Barcode,:CheckIn,:CheckOut,:CheckLibrary,:DateUpdated)');
                    foreach ($rows as $row) {
                        $dbins->bindParam(':Barcode', $row['Barcode']);
                        $dbins->bindParam(':CheckIn', $row['CheckIn']);
                        $dbins->bindParam(':CheckOut', $row['CheckOut']);
                        $dbins->bindParam(':CheckLibrary', $row['CheckLibrary']);
                        $dbins->bindParam(':DateUpdated', $row['DateUpdated']);
                        $dbins->execute();
                    }
                    $db->query('COMMIT');
                    $db->query('CREATE INDEX barcode_idx ON patron (Barcode)');
                    $db->query('CREATE INDEX update_idx ON patron (DateUpdated)');
                    $this->reply['REPLY'] = array(
                        'STATUS' => 'OK',
                        'RAW_FILENAME' => $dbfile);
                } catch (Exception $e) {
                    $this->reply['REPLY'] = array(
                        'STATUS' => 'KO',
                        'RESULT' => null);
                    throw $e;
                }
                break;
            case 'today':
                $this->reply['REPLY'] = array("STATUS" => "OK");
                $this->reply['REPLY']['RESULT'] = PatronQuery::create()
                    ->select(array('Barcode', 'CheckIn', 'CheckOut', 'CheckLibrary', 'DateUpdated'))
                    ->filterByBarcode(null, Criteria::NOT_EQUAL)
                    ->filterByDateUpdated(mktime(0, 0, 0), Criteria::GREATER_THAN)
                    ->find()
                    ->toArray();
                break;
            default:
                $this->reply['REPLY']['RESULT'] = PatronQuery::create()
                    ->select(array('Barcode', 'CheckIn', 'CheckOut', 'CheckLibrary', 'DateUpdated'))
                    ->filterByPatronId($this->getRequest()->itemAt('id'))
                    ->filterByBarcode(null, Criteria::NOT_EQUAL)
                    ->findOne()
                    ->toArray();
                break;
        }

        return true;
    }

    /**
     * Perform post request (friendly-url, see application.xml).
     * Calling via /api/v1/patron/turnstile/1
     *
     * Change it's function by post parameters
     * if "cmd" is set it can perform getpatron | setaccess
     * else only register patron action (actions parameter)
     * but use some default settings NOT USED BY setaccess-actions
     */
    private function PostPatronTurnstile()
    {
        if ($this->librarian == null) {
            Prado::log(__METHOD__ . " AUTH ERR", TLogger::INFO, 'SOAP');
            $this->reply['REPLY']['STATUS'] = "KO";
            $this->reply['REPLY']['ERRORCODE'] = "AUTHERR";
            $this->reply['REPLY']['ERRORINFO'] = "Non autorizzato";
            return true;
        }
        $command = $this->getRequest()->itemAt('cmd');
        if (!is_null($command)) {
            //Prado::log(__METHOD__ . " " . __LINE__ . " Perform {$command} action");
            if ($command == "getpatron") {

                try {
                    $pquery = PatronQuery::create()
                        ->select(array('PatronId', 'Name', 'Lastname', 'Barcode', 'DateUpdated', 'check_in', 'check_out'))
                        ->filterByBarcode(null, Criteria::NOT_EQUAL);

                    $datefrom = $this->getRequest()->itemAt('datefrom');
                    if (!is_null($datefrom)) {
                        $pquery->filterByDateUpdated(urldecode($datefrom), Criteria::GREATER_THAN);
                    }

                    //Prado::log($pquery->toString());

                    //Reply array
                    $this->reply['REPLY']['STATUS'] = "OK";
                    $this->reply['REPLY']['PERFORMEDQUERY'] = $pquery->toString();
                    $this->reply['REPLY']['RESULT'] = $pquery->find();
                } catch (Exception $e) {
                    $this->reply['REPLY']['STATUS'] = "KO";
                    $this->reply['REPLY']['ERRORINFO'] = "EXCEPTION {$e->getMessage()}";
                    Prado::log(__METHOD__ . " " . __LINE__ . " EXCEPTION: " . $e->getMessage());
                }

            }//getpatron


            if ($command == "setaccess") {
                try {
                    $actions = json_decode($this->getRequest()->itemAt('actions'));
                    if (!is_null($actions)) {

                        $conn = Propel::getConnection();
                        $res = array();
                        foreach ($actions as $row) {

                            //direction
                            $dId = $row[1];
                            //patron id
                            $pId = $row[2];
                            //datetime
                            $dt = substr($row[3], 0, 19);
                            //lib id
                            $lId = $row[4];
                            //action key
                            $ak = $row[5];

                            /*
                             * WARN: propel is not used because change date_updated @ save!
                             */
                            $dtq = $conn->quote($dt);
                            $pIdq = $conn->quote($pId);

                            if ($row[1] == 'in') {
                                //$conn->exec("update patron set check_in={$dtq} where barcode={$pIdq}");
                                $type = PatronActionPeer::ACTION_CHECKIN;
                            } elseif ($row[1] == 'out') {
                                //$conn->exec("update patron set check_out={$dtq} where barcode={$pIdq}");
                                $type = PatronActionPeer::ACTION_CHECKOUT;
                            } elseif ($row[1] == 'fail') {
                                $type = PatronActionPeer::ACCESS_FAILED;
                            } else {
                                $type = $row[1];
                            }

                            $thisPatron = PatronQuery::create()->findOneByBarcode($pId);
                            if ($thisPatron instanceof Patron) {
                                if ($lId == '') $lId = $thisPatron->getCheckLibrary();
                                $log = new PatronAction();
                                $log->setPatron($thisPatron);
                                $log->setLibraryId($lId);
                                $log->setActionType($type);
                                $log->setActionDate($dt);
                                $log->setActionKey($ak);
                                if (isset($row[6]) && $row[6] !== NULL && $row[6] != '') {
                                    $log->setActionNote($row[6]);
                                }

                                $log->setModifiedBy($this->librarian->getLibrarianId());
                                $log->setCreatedBy($this->librarian->getLibrarianId());

                                $log->save();
                                $res[] = $row;
                            } else {
                                Prado::log(__METHOD__ . " Unable to log action for patron id {$pId}");
                            }

                        }//foreach actions

                        //Reply array
                        $this->reply['REPLY']['STATUS'] = "OK";
                        $this->reply['REPLY']['RESULT'] = $res;

                    }//actions not null
                    else {
                        $this->reply['REPLY']['STATUS'] = "KO";
                        $this->reply['REPLY']['ERRORINFO'] = "ERROR no actions to insert";
                    }
                } catch (Exception $e) {
                    $this->reply['REPLY']['STATUS'] = "KO";
                    $this->reply['REPLY']['ERRORINFO'] = "EXCEPTION {$e->getMessage()}";
                    Prado::log(__METHOD__ . " " . __LINE__ . " EXCEPTION: " . $e->getMessage());
                }

            }//setaccess

        } else {
            $actions = json_decode($this->getRequest()->itemAt('actions'));
            if ($actions) {
                $this->reply['REPLY'] = array("STATUS" => "OK");
                $con = Propel::getConnection();
                $stmt = $con->prepare('UPDATE ' . PatronPeer::TABLE_NAME . ' SET ' .
                    PatronPeer::CHECK_IN . ' = ?, ' .
                    PatronPeer::CHECK_OUT . ' = ?, ' .
                    PatronPeer::CHECK_LIBRARY . ' = ?, ' .
                    PatronPeer::DATE_UPDATED . ' = ? ' .
                    'WHERE ' . PatronPeer::BARCODE . ' = ?');
                $result = array();

                foreach ($actions as $row) {
                    $log = null;
                    $p = PatronPeer::getPatronByBarcode($row[2]);

                    if (!$p instanceof Patron) {
                        Prado::log(__METHOD__ . " unable to log action for patron whith barcode {$row[2]}");
                        continue;
                    }
                    try {
                        if ($row[4] == '') $p->getCheckLibrary();
                        if ('in' == $row[1]) {
                            $log = PatronActionPeer::patronCheckIn($p,
                                $row[4],
                                substr($row[3], 0, 19),
                                $row[5]);
                        } else if ('out' == $row[1]) {
                            $log = PatronActionPeer::patronCheckOut($p,
                                $row[4],
                                substr($row[3], 0, 19),
                                $row[5]);
                        }
                        if ($log instanceof PatronAction)
                            $result[] = $row[0];
                    } catch (Exception $e) {
                        Prado::log(__METHOD__ . " exception inserting patro action " . $e->getMessage());
                    };
                }
                $this->reply['REPLY']['RESULT'] = $result;
            } else {
                $this->reply['REPLY'] = array("STATUS" => "KO", "ERRORINFO" => "No post data");
            }
        }//command null

        return true;
    }

    private function PostPatronAuth()
    {
        Prado::log('PostPatronAuthCheck start', TLogger::INFO, 'SOAP');
        $apiid = $this->reply["REQUEST"]['APIID'];

        $crypt = Prado::getApplication()->getModule('crypt');
        $check = $this->getRequest()->itemAt("check");
        $opac_username = $this->getRequest()->itemAt("username");
        $opac_secret = $this->getRequest()->itemAt("password");
        $user = PatronQuery::create()->findOneByOpacUsername($opac_username);

        if (($user instanceof Patron && $this->librarian instanceof Librarian) && ($crypt->PatronVerify($opac_secret, $user->getOpacSecret()) || $apiid == "nocheck")) {
            $this->reply['REPLY']['STATUS'] = "OK";
            switch ($check) {
                case "ALL":
                    $this->reply['REPLY']['PATRON'] = $user->toArray();
                    $this->reply['REPLY']['PATRON']['Email'] = $user->getEmail2String();
                    $this->reply['REPLY']['PATRON']['Phone'] = $user->getPhone2String();
                    break;
                case "SURF":
                    $this->reply['REPLY']['PATRON']['SURF'] = $user->getSurfEnable();
                    $this->reply['REPLY']['PATRON']['STATUS'] = $user->getPatronStatus();
                    $this->reply['REPLY']['PATRON']['CLASS'] = $user->getLoanClass();
                    $this->reply['REPLY']['PATRON']['NAME'] = $user->getCompleteName();
                    $this->reply['REPLY']['PATRON']['BARCODE'] = $user->getBarcode();

                    break;
                case "WALLET":
                    $this->reply['REPLY']['PATRON']['SURF'] = $user->getSurfEnable();
                    $this->reply['REPLY']['PATRON']['STATUS'] = $user->getPatronStatus();
                    $this->reply['REPLY']['PATRON']['CLASS'] = $user->getLoanClass();
                    $this->reply['REPLY']['PATRON']['NAME'] = $user->getCompleteName();
                    $this->reply['REPLY']['PATRON']['BARCODE'] = $user->getBarcode();
                    $this->reply['REPLY']['PATRON']['EMAIL'] = $user->getEmail()[0];

                    $this->reply['REPLY']['PATRON']['WALLET'] = $user->getWalletBalance("P", $this->reply["REQUEST"]['XLIBRARY']);

                    break;

            }
            $this->reply['REPLY']['ERRORCODE'] = "";
            $this->reply['REPLY']['ERRORINFO'] = "$apiid";

        } else {
            $this->reply['REPLY']['STATUS'] = "KO";
            $this->reply['REPLY']['ERRORCODE'] = "AUTHERR";
            $this->reply['REPLY']['ERRORINFO'] = "Errore di autenticazione";
        }
        return true;
    }

    private function PostPatronResetpassword()
    {
        Prado::log('PostPatronResetpassword start', TLogger::INFO, 'SOAP');

        if ($this->librarian == null) {
            Prado::log("PostPatronNew AUTH ERR", TLogger::INFO, 'SOAP');
            $this->reply['REPLY']['STATUS'] = "KO";
            $this->reply['REPLY']['ERRORCODE'] = "AUTHERR";
            $this->reply['REPLY']['ERRORINFO'] = "Non autorizzato";
            return true;
        }

        /** @var ClavisCryptCSBNO $crypt */
        $crypt = Prado::getApplication()->getModule('crypt');

        $nationalid = $this->getRequest()->itemAt("nationalid");
        $password = $this->getRequest()->itemAt("password");

        $patron = PatronQuery::create()->findOneByNationalId($nationalid);
        if ($patron instanceof Patron && strlen($password) > 6) {
            $patron->setOpacSecret($crypt->PatronEncrypt($password));
            $patron->save();

            ChangelogPeer::logAction($patron, ChangelogPeer::LOG_UPDATE, $this->librarian, "Aggiornata password via RESTAPI");
            $this->reply['REPLY']['STATUS'] = "OK";
            $this->reply['REPLY']['ERRORCODE'] = "";
            $this->reply['REPLY']['ERRORINFO'] = "";
        } else {
            $this->reply['REPLY']['STATUS'] = "KO";
            $this->reply['REPLY']['ERRORCODE'] = "PATRONERROR";
            $this->reply['REPLY']['ERRORINFO'] = "Codice inesistente";
        }
        return true;
    }


    private function PostPatronInsert()
    {
        Prado::log('PostPatronInsert start', TLogger::INFO, 'SOAP');

        if ($this->librarian == null) {
            Prado::log("PostPatronNew AUTH ERR", TLogger::INFO, 'SOAP');
            $this->reply['REPLY']['STATUS'] = "KO";
            $this->reply['REPLY']['ERRORCODE'] = "AUTHERR";
            $this->reply['REPLY']['ERRORINFO'] = "Client Non autorizzato";
            return true;
        }

        /** @var ClavisCryptCSBNO $crypt */
        $crypt = Prado::getApplication()->getModule('crypt');

        /*
         * Codice Fiscale, Nome, Cognome, Data dinascita, Comune residenza, Email, Telefono, password, consenso privacy,
         */
        $fldNames = ['nationalid', 'name', 'lastname', 'birthdate', 'city', 'email', 'phone', 'password',
            'privacy', 'loanclass', 'note', 'cardexpire', 'cardcode', 'username', 'barcode', 'library'];
        $flds = [];
        $validation = true;
        foreach ($fldNames as $fname) {
            $flds[$fname] = trim($this->getRequest()->itemAt($fname));
            if ($flds[$fname] == "") {
                $validation = false;
            }
        }

        if (!$validation) {
            $this->reply['REPLY']['STATUS'] = "KO";
            $this->reply['REPLY']['ERRORCODE'] = "MISSINGFIELD";
            $this->reply['REPLY']['ERRORINFO'] = "Dati mancanti";
        } else {

            if (trim($flds['nationalid']) != "" && strlen($flds['nationalid']) == 16) {
                $patron = PatronQuery::create()->findOneByNationalId($flds['nationalid']);
                if (is_null($patron)) {
                    try {
                        $patron = new Patron();
                        $patron->setName($flds['name']);
                        $patron->setLastname($flds['lastname']);
                        $patron->setPreferredLibraryId($flds['library']);
                        $patron->setRegistrationLibraryId($_SERVER['HTTP_X_CLAVIS_LIBRARY']);
                        $patron->setPatronStatus("A");
                        $patron->setLoanClass($flds['loanclass']);
                        $patron->setBirthDate($flds['birthdate']);
                        $patron->setPrivacyApprove($flds['privacy'] == "true");
                        $patron->setBarcode($flds['barcode']);
                        $patron->setOpacUsername($flds['username']);
                        $patron->setNationalId($flds['nationalid']);
                        $patron->setPatronNote("Creato da WS. {$flds['note']}");
                        $patron->setOpacEnable(true);
                        $patron->setOpacSecret($crypt->PatronEncrypt($flds['password']));
                        $patron->setCardCode($flds['cardcode']);
                        $patron->setCardExpire($flds['cardexpire']);
                        $patron->save();

                        ChangelogPeer::logAction($patron, ChangelogPeer::LOG_UPDATE, $this->librarian, "Creato utente via RESTAPI");

                        $email = new Contact();
                        $email->setContactType("E");
                        $email->setContactValue($flds['email']);
                        $email->setPatron($patron);
                        $email->save();

                        $phone = new Contact();
                        $phone->setContactType(ContactPeer::TYPE_MOBILE);
                        $phone->setContactValue($flds['phone']);
                        $phone->setPatron($patron);
                        $phone->save();

                        $city = new Address();
                        $city->setCity($flds['city']);
                        $city->setPatron($patron);
                        $city->save();

                        $this->reply['REPLY']['STATUS'] = "OK";
                        $this->reply['REPLY']['ERRORCODE'] = "";
                        $this->reply['REPLY']['ERRORINFO'] = "";

                        return true;

                    } catch (Exception $e) {
                        $this->reply['REPLY']['STATUS'] = "KO";
                        $this->reply['REPLY']['ERRORCODE'] = "EXCEPTIONINSERT";
                        $this->reply['REPLY']['ERRORINFO'] = "Exception creazione utente";

                        return true;
                    }

                } else {
                    $this->reply['REPLY']['STATUS'] = "KO";
                    $this->reply['REPLY']['ERRORCODE'] = "NATIONALIDEXISTS";
                    $this->reply['REPLY']['ERRORINFO'] = "Codice fiscale esistente";

                    return true;
                }
            }
            $this->reply['REPLY']['STATUS'] = "KO";
            $this->reply['REPLY']['ERRORCODE'] = "WRONG NATIONALID";
            $this->reply['REPLY']['ERRORINFO'] = "Codice fiscale errato";
        }
        return true;
    }


    private function PostPatronUpdate()
    {
        Prado::log('PostPatronUpdate start', TLogger::INFO, 'SOAP');

        if ($this->librarian == null) {
            Prado::log("PostPatronUpdate AUTH ERR", TLogger::INFO, 'SOAP');
            $this->reply['REPLY']['STATUS'] = "KO";
            $this->reply['REPLY']['ERRORCODE'] = "AUTHERR";
            $this->reply['REPLY']['ERRORINFO'] = "Client Non autorizzato";
            return true;
        }

        /** @var ClavisCryptCSBNO $crypt */
        $crypt = Prado::getApplication()->getModule('crypt');

        /*
         * Codice Fiscale, Nome, Cognome, Data dinascita, Comune residenza, Email, Telefono, password, consenso privacy,
         */
        $fldNames = ['nationalid', 'loanclass', 'cardexpire','patronstatus'];
        $flds = [];
        $validation = true;
        foreach ($fldNames as $fname) {
            $flds[$fname] = trim($this->getRequest()->itemAt($fname));
            if ($flds[$fname] == "") {
                $validation = false;
            }
        }

        if (!$validation) {
            $this->reply['REPLY']['STATUS'] = "KO";
            $this->reply['REPLY']['ERRORCODE'] = "MISSINGFIELD";
            $this->reply['REPLY']['ERRORINFO'] = "Dati mancanti";
        }

        $patron = PatronQuery::create()->findOneByNationalId($flds['nationalid']);
        if ($patron instanceof Patron) {
            try {

                $patron->setLoanClass($flds['loanclass']);
                $patron->setCardExpire($flds['cardexpire']);
                $patron->setPatronStatus($flds['patronstatus']);
                $patron->save();

                ChangelogPeer::logAction($patron, ChangelogPeer::LOG_UPDATE, $this->librarian, "Update loanstatus loanclass expire utente via RESTAPI");

                $this->reply['REPLY']['STATUS'] = "OK";
                $this->reply['REPLY']['ERRORCODE'] = "";
                $this->reply['REPLY']['ERRORINFO'] = "";

                return true;

            } catch (Exception $e) {
                $this->reply['REPLY']['STATUS'] = "KO";
                $this->reply['REPLY']['ERRORCODE'] = "EXCEPTIONINSERT";
                $this->reply['REPLY']['ERRORINFO'] = "Exception aggiornamento utente";

                return true;
            }

        }

        $this->reply['REPLY']['STATUS'] = "KO";
        $this->reply['REPLY']['ERRORCODE'] = "NATIONALIDEXISTS";
        $this->reply['REPLY']['ERRORINFO'] = "Codice fiscale inesistente";

        return true;
    }


    private function PostWalletNew()
    {
        Prado::log('PostWalletNew start', TLogger::INFO, 'SOAP');
        $opac_username = $this->getRequest()->itemAt("username");
        $amount = $this->getRequest()->itemAt('amount');
        $wType = $this->getRequest()->itemAt('wallet');
        $wStatus = $this->getRequest()->itemAt('status');
        $wID = $this->getRequest()->itemAt('uid');
        $note = $this->getRequest()->itemAt('note');

        if ($this->librarian == null) {
            Prado::log("GetPatronStatus AUTH ERR", TLogger::INFO, 'SOAP');
            $this->reply['REPLY']['STATUS'] = "KO";
            $this->reply['REPLY']['ERRORCODE'] = "AUTHERR";
            $this->reply['REPLY']['ERRORINFO'] = "Non autorizzato";
            return true;
        }

        $patron = PatronQuery::create()->findOneByOpacUsername($opac_username);
        if ($patron instanceof Patron) {
            $w = new PatronWallet();
            $w->setReceiptId($wID);
            $w->setLibraryId($this->reply["REQUEST"]['XLIBRARY']);
            $w->setPatron($patron);
            $w->setWalletType($wType);
            $w->setAmount($amount);
            $w->setWalletNote($note);
            $w->setWalletStatus($wStatus);
            $w->setDateClosed(time());
            $w->setDateCreated(time());
            $w->setDateUpdated(time());
            if ($this->librarian != null) {
                $w->setCreatedBy($this->librarian->getLibrarianId());
                $w->setModifiedBy($this->librarian->getLibrarianId());
            }
            try {
                $w->save();
                $this->reply['REPLY']['STATUS'] = "OK";
                $this->reply['REPLY']['ERRORCODE'] = "";
                $this->reply['REPLY']['ERRORINFO'] = "";

            } catch (Exception $e) {
                $this->reply['REPLY']['STATUS'] = "KO";
                $this->reply['REPLY']['ERRORCODE'] = "WALLETERR";
                $this->reply['REPLY']['ERRORINFO'] = "ERR:" . $e->getMessage();
            }
        } else {
            $this->reply['REPLY']['STATUS'] = "KO";
            $this->reply['REPLY']['ERRORCODE'] = "AUTHERR";
            $this->reply['REPLY']['ERRORINFO'] = "Utente sconosciuto";
        }
        return true;
    }

    /**
     *
     * This method request a full list of Pending ItemRequest.
     *
     * @return bool
     * @throws PropelException
     */

    private function PostItemrequestPending()
    {
        Prado::log(__METHOD__ . 'start', TLogger::INFO, 'SOAP');
        $apiid = $this->reply["REQUEST"]['APIID'];

        $delivery_library_id = $this->getRequest()->itemAt("delivery_library_id");
        $request_type = $this->getRequest()->itemAt("request_type");

        $login = ($this->librarian instanceof Librarian);

        if (!$login) {
            $this->reply['REPLY']['STATUS'] = "KO";
            $this->reply['REPLY']['ERRORCODE'] = "AUTHERR";
            $this->reply['REPLY']['ERRORINFO'] = "Errore di autenticazione";
            return true;
        } else {

            Prado::log("Api Request process request ALL Delivery {$delivery_library_id} Type: {$request_type}", TLogger::INFO, 'SOAP');

            /** @var ClavisUserManager $auth */
            $auth = Prado::getApplication()->getModule('auth');
            Prado::getApplication()->getUser()->setActualLibraryId($this->reply['REQUEST']['XLIBRARY']);
            Prado::getApplication()->getUser()->setDistanceHash($this->reply['REQUEST']['XLIBRARY']);

            //$login = $auth->login($this->reply["REQUEST"]['XUSERNAME'], $this->reply["REQUEST"]['XPASSWORD']);


            $requests = ItemRequestQuery::create()
                ->filterByRequestStatus(ItemRequestPeer::STATUS_PENDING)
                ->filterByRequestType($request_type)
                ->filterByDeliveryLibraryId($delivery_library_id)
                ->find();
            $respList = [];

            foreach ($requests as $request) {
                /** @var ItemRequest $request */

                Prado::log("Api Request process request id {$request->getRequestId()}", TLogger::INFO, 'SOAP');

                //Prado::log(Prado::varDump($row));
                $item = $request->getItem();
                if ($item instanceof Item) {
                    $r = [
                        "title" => $item->getTitle(),
                        "note" => $request->getRequestNote(),
                        "type" => $request->getRequestType(),
                        "delivery_library" => $request->getDeliveryLibrary()->getLabel(),
                        "Inv" => $item->getCompleteInventoryNumber(),
                        "Coll" => $item->getCollocationCombo(),
                        "barcode_item" => $item->getBarcode(),
                        "request_id" => $request->getRequestId(),
                        "request_date" => $request->getRequestDate(),
                        "patron_name" => ($request->getPatron() == null) ? $request->getExternalLibrary()->getLabel() : $request->getPatron()->getCompleteName(),
                        "patron_barcode" => ($request->getPatron() == null) ? "ESTERNA" : $request->getPatron()->getBarcode(),

                    ];
                    $respList[] = $r;
                }
            }

            $this->reply['REPLY']['STATUS'] = "OK";
            $this->reply['REPLY']['REQUESTS'] = $respList;
            $this->reply['REPLY']['ERRORCODE'] = "";
            $this->reply['REPLY']['ERRORINFO'] = "";
            return true;

        }
    }

    private function PostItemrequestList()
    {
        Prado::log(__METHOD__ . 'start', TLogger::INFO, 'SOAP');
        $apiid = $this->reply["REQUEST"]['APIID'];

        $delivery_library_id = $this->getRequest()->itemAt("delivery_library_id");
        $request_type = $this->getRequest()->itemAt("request_type");

        $login = ($this->librarian instanceof Librarian);

        if (!$login) {
            $this->reply['REPLY']['STATUS'] = "KO";
            $this->reply['REPLY']['ERRORCODE'] = "AUTHERR";
            $this->reply['REPLY']['ERRORINFO'] = "Errore di autenticazione";
            return true;
        } else {

            Prado::log("Api Request process request Delivery {$delivery_library_id} Type: {$request_type}", TLogger::INFO, 'SOAP');

            /** @var ClavisUserManager $auth */
            $auth = Prado::getApplication()->getModule('auth');
            Prado::getApplication()->getUser()->setActualLibraryId($this->reply['REQUEST']['XLIBRARY']);
            Prado::getApplication()->getUser()->setDistanceHash($this->reply['REQUEST']['XLIBRARY']);

            //$login = $auth->login($this->reply["REQUEST"]['XUSERNAME'], $this->reply["REQUEST"]['XPASSWORD']);

            /** @var ClavisRequestManager $requestManager */
            $requestManager = $crypt = $this->getApplication()->getModule('request');

            $itemFilters = array('section' => "",
                'collocation' => "",
                'manifestationIdParam' => "",
                'itemIdParam' => "",
                'patron' => "",
                'deliveryLibraryId' => $delivery_library_id,
                'maxDistance' => "",
                'requestType' => $request_type);


            $requestsRaw = $requestManager->getRequests(null, 0, 100, $itemFilters);

            foreach ($requestsRaw as $index => $row) {
                /** @var ItemRequest $request */

                $request = ItemRequestQuery::create()
                    ->joinPatron()
                    ->joinLibraryRelatedByDeliveryLibraryId()
                    ->findOneByRequestId($row['requestId']);

                Prado::log("Api Request process request id {$row['requestId']}", TLogger::INFO, 'SOAP');

                //Prado::log(Prado::varDump($row));
                $item = ItemQuery::create()->findPk($row['idata'][0]);
                $r = [
                    "title" => $row['title'],
                    "note" => $request->getRequestNote(),
                    "type" => $request->getRequestType(),
                    "delivery_library" => $request->getDeliveryLibrary()->getLabel(),
                    "Inv" => "{$row['idata'][2]}-{$row['idata'][3]}",
                    "Coll" => $item->getCollocationCombo(),
                    "barcode_item" => $item->getBarcode(),
                    "request_id" => $row['requestId'],
                    "request_date" => $row['requestDate'],
                    "patron_name" => ($request->getPatron() == null) ? $request->getExternalLibrary()->getLabel() : $request->getPatron()->getCompleteName(),
                    "patron_barcode" => ($request->getPatron() == null) ? "ESTERNA" : $request->getPatron()->getBarcode(),

                ];
                $requests[] = $r;
            }

            $this->reply['REPLY']['STATUS'] = "OK";
            $this->reply['REPLY']['REQUESTS'] = $requests;
            $this->reply['REPLY']['ERRORCODE'] = "";
            $this->reply['REPLY']['ERRORINFO'] = "";
            return true;

        }
    }

    private function PostItemrequestNew()
    {
        Prado::log(__METHOD__ . 'start', TLogger::INFO, 'SOAP');
        $apiid = $this->reply["REQUEST"]['APIID'];

        $manifestion_id = $this->getRequest()->itemAt("manifestation_id");
        $issue_id = $this->getRequest()->itemAt("issue_id");
        $item_id = $this->getRequest()->itemAt("item_id");
        $item_barcode = $this->getRequest()->itemAt("item_barcode");
        $item_inventory = $this->getRequest()->itemAt("item_inventory");
        $patron_id = $this->getRequest()->itemAt("patron_id");
        $patron_barcode = $this->getRequest()->itemAt("patron_barcode");
        $patron_username = $this->getRequest()->itemAt("patron_username");
        $expire_date = $this->getRequest()->itemAt("expire_date");
        $delivery_library_id = $this->getRequest()->itemAt("delivery_library_id");
        $request_note = $this->getRequest()->itemAt("request_note");
        $request_type = $this->getRequest()->itemAt("request_type");

        $login = ($this->librarian instanceof Librarian);

        if (!$login) {
            $this->reply['REPLY']['STATUS'] = "KO";
            $this->reply['REPLY']['ERRORCODE'] = "AUTHERR";
            $this->reply['REPLY']['ERRORINFO'] = "Errore di autenticazione";
            return true;
        } else {
            $patron = null;
            $item = null;

            // Check Patron
            $patron = PatronQuery::create()->findOneByOpacUsername($patron_username);
            if ($patron == null)
                $patron = PatronQuery::create()->findOneByBarcode($patron_barcode);

            if ($patron == null) {
                $this->reply['REPLY']['STATUS'] = "KO";
                $this->reply['REPLY']['ERRORCODE'] = "PATRONERR";
                $this->reply['REPLY']['ERRORINFO'] = "Utente non trovato";
                return true;
            }

            if ($item_id != null)
                $item = ItemQuery::create()->findPk($item_id);

            if ($item == null && $item_barcode != null)
                $item = ItemQuery::create()->findOneByBarcode($item_barcode);

            if (preg_match("/^(.+)-(.+)$/", $item_inventory, $match) && $item == null) {

                $item = ItemQuery::create()
                    ->_if($issue_id != null)
                    ->filterByIssueId($issue_id)
                    ->_endif()
                    ->filterByInventorySerieId($match[1])
                    ->findOneByInventoryNumber($match[2]);
            }

            if ($item == null) {
                $this->reply['REPLY']['STATUS'] = "KO";
                $this->reply['REPLY']['ERRORCODE'] = "ITEMERR";
                $this->reply['REPLY']['ERRORINFO'] = "Esemplare non trovato ID:{$item_id} INV:{$item_inventory}";
                return true;
            }

            $request = new ItemRequest();
            $request->setPatron($patron);
            $request->setManifestationId($item->getManifestationId());
            $request->setItem($item);
            $request->setIssueId($item->getIssueId());
            $request->setDeliveryLibraryId($delivery_library_id);
            $request->setRequestType($request_type);
            $request->setRequestNote("[WS]" . $request_note);
            $request->setRequestStatus("A");
            $request->setRequestDate(time());

            if (is_null($expire_date))
                $request->setExpireDate(time() + 60 * 60 * 24 * 2);
            else
                $request->setExpireDate($expire_date);

            try {
                $request->save();
                $request->reload();
                $this->reply['REPLY']['STATUS'] = "OK";
                $this->reply['REPLY']['REQUEST'] = $request->toArray();
                $this->reply['REPLY']['ERRORCODE'] = "";
                $this->reply['REPLY']['ERRORINFO'] = "";
                return true;
            } catch (Exception $e) {

                $it = $this->getRequest();
                $params = "";
                foreach ($it as $k => $v) {
                    $params .= $k . "=" . $v . " ";
                }
                $this->reply['REPLY']['STATUS'] = "KO";
                $this->reply['REPLY']['ERRORCODE'] = "EXCEPTION";
                $this->reply['REPLY']['RECV_PARAMS'] = $params;
                $this->reply['REPLY']['ERRORINFO'] = $e->getMessage();
                Prado::log(__METHOD__ . " PARAMS: {$params} EXCEPTION: " . $e->getMessage());
                return TRUE;
            }
        }
    }

    private function PostItemNew()
    {
        Prado::log('PostItemNew start', TLogger::INFO, 'SOAP');
        $apiid = $this->reply["REQUEST"]['APIID'];

        $ownerLibrary = $this->getRequest()->itemAt("owner_library");
        $itemSection = $this->getRequest()->itemAt("section");
        $itemCollocation = $this->getRequest()->itemAt("collocation");
        $specification = $this->getRequest()->itemAt("specification");
        $itemInvSerie = $this->getRequest()->itemAt("inventory_serie");
        $ean = $this->getRequest()->itemAt("ean");
        $media = $this->getRequest()->itemAt("media");
        $loanClass = $this->getRequest()->itemAt("loan_class");
        $status = $this->getRequest()->itemAt("status");
        $source = $this->getRequest()->itemAt("source");
        $inventorynum = $this->getRequest()->itemAt("inventory_number");
        $uuid = $this->getRequest()->itemAt("uuid");
        $title = $this->getRequest()->itemAt("title");

        $login = ($this->librarian instanceof Librarian);

        if (!$login) {
            $this->reply['REPLY']['STATUS'] = "KO";
            $this->reply['REPLY']['ERRORCODE'] = "AUTHERR";
            $this->reply['REPLY']['ERRORINFO'] = "Errore di autenticazione";
            return true;
        } else {

            $item = new Item();

            if (is_null($title)) {

                if ($uuid != null) {
                    $itemUid = ItemQuery::create()->findOneByCustomField3($uuid);
                    if ($itemUid instanceof Item) {
                        $this->reply['REPLY']['STATUS'] = "OK";
                        $this->reply['REPLY']['ITEM'] = $itemUid->toArray();
                        $this->reply['REPLY']['ERRORCODE'] = "";
                        $this->reply['REPLY']['ERRORINFO'] = "Via UUID";
                        return true;
                    }
                }

                $invSerie = InventorySerieQuery::create()
                    ->filterByInventorySerieId($itemInvSerie)
                    ->findOne();

                $man = ManifestationQuery::create()->findOneByEan($ean);
                if ($man == null) {
                    $man = ManifestationQuery::create()->findOneByIsbnissn($ean);
                }

                if ($man instanceof Manifestation) {

                    if ($invSerie instanceof InventorySerie && $inventorynum == "new") {

                        if ($ownerLibrary == null) {
                            $ownerLibrary = $invSerie->getLibraryId();
                        }

                        $inventorynum = InventorySeriePeer::calculateNextInventoryCounter($itemInvSerie, $ownerLibrary);
                    }

                    $item->setManifestation($man);
                    $item->setTitle($man->getTitle());
                    $item->setCustomField3($uuid);

                } else {
                    $this->reply['REPLY']['STATUS'] = "KO";
                    $this->reply['REPLY']['ERRORCODE'] = "EANERR";
                    $this->reply['REPLY']['ERRORINFO'] = "EAN Sconosciuto";
                    return true;
                }
            } else {
                $item->setManifestationId(0);
                $item->setTitle($title);
                $item->setCustomField3("Fuori catalogo");
            }

            $item->setSection($itemSection);
            $item->setCollocation($itemCollocation);
            $item->setSpecification($specification);
            $item->setItemMedia($media);

            $item->setInventorySerieId($itemInvSerie);
            $item->setInventoryNumber($inventorynum);

            $item->setOwnerLibraryId($ownerLibrary);
            $item->setHomeLibraryId($ownerLibrary);
            $item->setActualLibraryId($ownerLibrary);

            $item->setLoanStatus(ItemPeer::LOANSTATUS_AVAILABLE);
            $item->setLoanClass($loanClass);
            $item->setItemStatus($status);
            $item->setItemSource($source);

            $item->setCreatedBy($this->librarian->getLibrarianId());
            $item->setModifiedBy($this->librarian->getLibrarianId());
            $item->setDateCreated(time());
            $item->setDateUpdated(time());
            $item->setInventoryDate(time());


            try {
                $item->save();
                $item->reload();
                $this->reply['REPLY']['STATUS'] = "OK";
                $this->reply['REPLY']['ITEM'] = $item->toArray();
                $this->reply['REPLY']['ERRORCODE'] = "";
                $this->reply['REPLY']['ERRORINFO'] = "";
                return true;
            } catch (Exception $e) {

                $it = $this->getRequest();
                $params = "";
                foreach ($it as $k => $v) {
                    $params .= $k . "=" . $v . " ";
                }
                $this->reply['REPLY']['STATUS'] = "KO";
                $this->reply['REPLY']['ERRORCODE'] = "EXCEPTION";
                $this->reply['REPLY']['RECV_PARAMS'] = $params;
                $this->reply['REPLY']['ERRORINFO'] = $e->getMessage();
                Prado::log(__METHOD__ . " PARAMS: {$params} EXCEPTION: " . $e->getMessage());
                return TRUE;
            }

        }
    }

    private function PostPatronApp()
    {
        Prado::log('PostPatronApp start', TLogger::INFO, 'SOAP');
        $opac_username = $this->getRequest()->itemAt("username");
        $password = $this->getRequest()->itemAt("password");

        if ($this->librarian == null) {
            Prado::log("PostPatronApp AUTH ERR", TLogger::INFO, 'SOAP');
            $this->reply['REPLY']['STATUS'] = "KO";
            $this->reply['REPLY']['ERRORCODE'] = "AUTHERR";
            $this->reply['REPLY']['ERRORINFO'] = "Non autorizzato";
            return;
        }
    }

    private function PostMobileappLogin()
    {
        Prado::log('PostMobileappLogin start', TLogger::INFO, 'SOAP');
        $apiid = $this->reply["REQUEST"]['APIID'];

        $crypt = Prado::getApplication()->getModule('crypt');
        $opac_username = $this->getRequest()->itemAt("username");
        $opac_secret = $this->getRequest()->itemAt("password");
        $user = PatronQuery::create()->findOneByOpacUsername($opac_username);

        if (($user instanceof Patron && $this->librarian instanceof Librarian) && ($crypt->PatronVerify($opac_secret, $user->getOpacSecret()))) {

            if (ContactQuery::create()
                    ->filterByPatron($user)
                    ->filterByContactType("A")// App
                    ->count() == 0
            ) {
                // Create a new contact for the patron
                $contact = new Contact();
                $contact->setPatron($user);
                $contact->setContactType("A");
                $contact->setContactValue($opac_username);
                $contact->save();
            }

            $loans = [];
            $readyToLoan = [];
            $loanLate = 0;
            $inTransit = [];
            $notifs = [];
            $newNotif = 0;

            $reservs = [];

            foreach (ItemRequestQuery::create()
                         ->filterByPatron($user)
                         ->filterByRequestStatus("A")// Pendenti
                ->find() as $r) {
                /* @var $r ItemRequest */

                if ($r->getManifestation() instanceof Manifestation)
                    $title = $r->getManifestation()->getTitle();
                elseif ($r->getItem() instanceof Item)
                    $title = $r->getItem()->getTitle();
                else
                    $title = "(senza titolo)";

                $reservs[] = [
                    "Title" => $title,
                    "Status" => "Pending",
                    "Expire" => $r->getExpireDate('Y-m-d'),
                    "Library" => $r->getDeliveryLibraryId(),
                    "LibraryName" => $r->getDeliveryLibraryDescription()
                ];
            }

            foreach ($user->getItems() as $l) {
                $ldata = [
                    "Title" => $l->getTitle(),
                    "Status" => $l->getLoanStatusString(),
                    "Late" => false,
                    "LateDays" => 0,
                    "DueDate" => "",
                    "Collocation" => $l->getCollocationCombo(),
                    "Barcode" => $l->getBarcode(),
                    "Library" => $l->getActualLibraryId(),
                    "LibraryName" => $l->getActualLibraryDescription(),
                ];

                if ($l->getLoanStatus() == ItemPeer::LOANSTATUS_INLOAN) {
                    $ldata['DueDate'] = $l->getDueDate('Y-m-d');

                    if ($l->getDueDate("U") < time()) {
                        $loanLate++;
                        $ldata["Late"] = true;

                    }
                    $loans[] = $ldata;
                } elseif ($l->getLoanStatus() == ItemPeer::LOANSTATUS_INTRANSIT || $l->getLoanStatus() == ItemPeer::LOANSTATUS_READYFORTRANSIT) {
                    $inTransit[] = $ldata;
                } elseif ($l->getLoanStatus() == ItemPeer::LOANSTATUS_READYFORLOAN) {
                    $readyToLoan[] = $ldata;
                }
            }

            foreach (NotificationQuery::create()
                         ->filterByObjectClass("PATRON")
                         ->filterByObjectId($user->getPatronId())
                         ->filterByNotificationChannel("I")// App Channel
                ->filterByInternalStatus("A")// Unread and Read
                ->find() as $n) {
                /* @var $n Notification */

                if ($n->getNotificationState() == 'A')
                    $newNotif++;

                $notifs[] = [
                    "Id" => $n->getNotificationId(),
                    "Date" => $n->getDateCreated(),
                    "Status" => ($n->getNotificationState() == 'A') ? "New" : "Read",
                    "Message" => $n->getMessage(),
                    "Library" => $n->getSenderLibraryId(),
                    "LibraryName" => $n->getLibrary()->getDescription(),
                ];
            }

            $infoMessagge = "";
            $infoColor = "000000";

            if ($newNotif > 0) {
                $infoMessagge = "Hai nuovi messaggi";
                $infoColor = "00FF00";
            }

            if ($user->getPatronStatus() != 'A') {
                $infoMessagge = "La tua tessera non è attiva";
                $infoColor = "FF0000";
            }

            if ($loanLate > 0) {
                $infoMessagge = "Hai prestiti in ritardo";
                $infoColor = "FF0000";
            }


            $resp = [
                "Status" => "OK",
                "StatusMessage" => "",
                "InfoMessage" => $infoMessagge,
                "InfoType" => $infoColor,
                "User" => [
                    "Name" => $user->getCompleteName(),
                    "Email" => $user->getEmail2String(),
                    "Mobile" => $user->getPhone2String(),
                    "BirthDate" => $user->getBirthDate('Y-m-d'),
                    "PreferredLbrary" => $user->getPreferredLibrary()->getDescription(),
                    "Status" => $user->getPatronStatusString(),
                    "LoanClass" => $user->getLoanClass(),
                    "Barcode" => $user->getBarcode(),
                    "Username" => $user->getOpacUsername(),
                ],
                "CardSummary" => [
                    "Loans" => count($loans),
                    "Late" => $loanLate,
                    "Reservations" => count($reservs),
                    "InTransit" => count($inTransit),
                    "ReadyToLoan" => count($readyToLoan),
                    "Notifications" => $newNotif,
                ],
                "Loans" => $loans,
                "ReadyToLoan" => $readyToLoan,
                "InTransit" => $inTransit,
                "Reservations" => $reservs,
                "Notifications" => $notifs,
            ];

        } else {
            $resp = [
                "Status" => "KO",
                "StatusMessage" => "LoginFailed",
            ];

        }

        header("Content-Type: text/json");
        print json_encode($resp);
        return false;
    }

    private function PostMobileappNotify()
    {
        Prado::log('PostMobileappNotify start', TLogger::INFO, 'SOAP');
        $apiid = $this->reply["REQUEST"]['APIID'];
        $notifyId = $this->getRequest()->itemAt("notification");

        $notif = NotificationQuery::create()->findOneByNotificationId($notifyId);

        if ($this->librarian instanceof Librarian && $notif instanceof Notification) {

            $status = "";

            if ($apiid == "read") {
                $notif->setAcknowledgeDate(time());
                $notif->setNotificationState("C"); //Confirmed
                $notif->save();
                $status = "Notification mark as read";
            } elseif ($apiid == "delete") {
                if ($notif->getAcknowledgeDate() == null)
                    $notif->setAcknowledgeDate(time());

                $notif->setNotificationState("C"); //Confirmed
                $notif->setInternalStatus("B"); // Device APP deleted
                $notif->save();
                $status = "Notification mark as delete";
            }

            $resp = [
                "Status" => "OK",
                "StatusMessage" => $status,
            ];
        } else {
            $resp = [
                "Status" => "KO",
                "StatusMessage" => "LoginFailed",
            ];

        }

        header("Content-Type: text/json");
        print json_encode($resp);
        return false;
    }

    private function PostWebhookTelegram()
    {
        Prado::log('PostWebHookTelegram start', TLogger::INFO, 'SOAP');
        $apiid = $this->reply["REQUEST"]['APIID'];

        $telegramToken = ClavisParamQuery::getParam("TELEGRAM", "TOKEN");
        $telegramAPIID = ClavisParamQuery::getParam("TELEGRAM", "APIID");
        $botSecret = ClavisParamQuery::getParam("TELEGRAM", "SECRET");
        $botName = ClavisParamQuery::getParam("TELEGRAM", "BOTNAME");
        $botWelcome = ClavisParamQuery::getParam("TELEGRAM", "BOTWELCOME");

        $opacurl = ClavisParamQuery::getParam('CLAVISPARAM', 'OPACUrl');

        $tg = new telegramBot($telegramToken);

        $postdata = file_get_contents("php://input");
        $update = json_decode($postdata, true);

        Prado::log(Prado::varDump($update), TLogger::INFO, 'SOAP');

        if ($apiid == $telegramAPIID) Prado::log("API ID OK", TLogger::INFO, 'SOAP');

        $username = $update['message']['from']['first_name'];
        $userid = $update['message']['from']['id'];
        $text = $update['message']['text'];

        Prado::log("TEXT: [{$text}]", TLogger::INFO, 'SOAP');

        $contact = ContactQuery::create()
            ->filterByContactType("L")// Telegram
            ->findOneByContactValue($userid);

        if ($contact instanceof Contact) {
            $patron = $contact->getPatron();

            $match = [];

            Prado::log("Trovato contatto", TLogger::INFO, 'SOAP');

            if (preg_match("#/tessera#", $text)) {
                Prado::log("Comando tessera", TLogger::INFO, 'SOAP');

                $items = $patron->getItems();
                $c = new Criteria();
                $c->add(ItemRequestPeer::REQUEST_STATUS, ItemRequestPeer::STATUS_PENDING);
                $reqs = $patron->getItemRequests($c);

                $respMsg = "";
                $seq = 1;

                $respMsg .= "Il tuo stato tessera è: <strong>" . $patron->getPatronStatusString() . "</strong>\n";

                if (count($items) == 0)
                    $respMsg .= "Non hai prestiti in corso.\n ";
                else {
                    $respMsg .= "Prestiti in corso:\n";
                    foreach ($items as $l) {
                        $dd = $l->getDueDate("U");
                        if ($dd < time())
                            $late = true;
                        else
                            $late = false;

                        $days = floor(abs(time() - $dd) / (60 * 60 * 24));
                        $respMsg .= "{$seq}. " . $l->getTrimmedTitle(20) . (($late) ? " <strong>Scaduto da </strong>" : " Scade tra ") . "{$days} giorni.\n";
                        $seq++;
                    }
                }
                $seq = 1;
                if (count($reqs) == 0)
                    $respMsg .= "Non hai prenotazioni in attesa.\n ";
                else {
                    $respMsg .= "Prenotazioni in corso:\n";
                    foreach ($reqs as $r) {
                        $title = ($r->getManifestation() instanceof Manifestation) ? $r->getManifestation()->getTrimmedTitle(20, '') : $r->getItem()->getTrimmedTitle(20);
                        $pos = $r->getQueuePosition();
                        $respMsg .= "{$seq}. {$title}. In posizione {$pos}.\n";
                        $seq++;
                    }

                }
                Prado::log("MEssaggio: {$respMsg}", TLogger::INFO, "SOAP");
                $tg->sendMessage($userid, $respMsg, "HTML");

            } elseif (preg_match("#/cerca (.+)$#", $text, $match)) {
                $solrQuery = $match[1];

                Prado::log("Comando cerca [$solrQuery]", TLogger::INFO, 'SOAP');
                /* @var $search SolrSearch */
                $search = $this->getApplication()->getModule("search");
                $response = $search->search("(fulltext:({$solrQuery})) AND mrc_d950_sj:[* TO *] AND collection:(catalog OR MLOL)", 0, 1, '', ["facet" => "true", "facet.field" => "collection"]);

                if ($response && $response['response']['numFound'] > 0) {
                    Prado::log(Prado::varDump($response), TLogger::INFO, 'SOAP');

                    $totfound = $response['response']['numFound'];
                    $docnum = (isset($response['facet_counts']['facet_fields']['collection']['catalog'])) ? $response['facet_counts']['facet_fields']['collection']['catalog'] : 0;
                    $mlolnum = (isset($response['facet_counts']['facet_fields']['collection']['MLOL'])) ? $response['facet_counts']['facet_fields']['collection']['MLOL'] : 0;
                    if ($mlolnum > 0)
                        $mloltxt = " e {$mlolnum} sono eBook";
                    else
                        $mloltxt = "";

                    $tg->sendMessage($userid, "Ho trovato {$totfound} risultati{$mloltxt}. <a href=\"{$opacurl}/opac/search/lst?q=" . urlencode($match[1]) . "\">Vedi</a>", "HTML");
                } else
                    $tg->sendMessage($userid, "Non ho trovato niente. Prova a <a href=\"{$opacurl}\">cercare on line</a>", "HTML");

            } else {
                $tg->sendMessage($userid, "Non ho compreso il comando [{$text}] che hai inserito.\nConsulta la lista dei miei comandi.");
            }

        } elseif (preg_match('#/start (\d+):(.+)$#', $text, $match)) {
            $patron_id = $match[1];
            $signature = $match[2];

            $bs = crypt($patron_id, $botSecret);

            Prado::log("Comando start for patron {$patron_id} {$signature}=={$bs}", TLogger::INFO, 'SOAP');
            $patron = PatronQuery::create()->findPk($patron_id);
            if ($patron instanceof Patron && $signature == md5(crypt($patron_id, $botSecret))) {
                $ct = ContactQuery::create()
                    ->filterByContactType("L")
                    ->filterByPatron($patron)
                    ->findOne();

                if ($ct == null)
                    $ct = new Contact();

                $ct->setPatron($patron);
                $ct->setContactValue($userid);
                $ct->setContactType("L");
                $ct->setContactNote("Creato da DNG");
                $ct->save();
                $tg->sendMessage($userid, "Benvenuto {$patron->getName()}.\nIl tuo account è stato validato correttamente.");
            } else {
                $tg->sendMessage($userid, "Non sono riuscito a collegare il tuo account telegram. Riprova più tardi e se il problema persiste contatta la tua biblioteca.");
            }
        } elseif (preg_match("#/segretocmd \\[(.+)\\]#", $text, $match)) {
            $patron = PatronQuery::create()->findOneByBarcode($match[1]);
            if ($patron instanceof Patron) {
                $ct = new Contact();
                $ct->setPatron($patron);
                $ct->setContactValue($userid);
                $ct->setContactType("L");
                $ct->setContactNote("Creato da amministratore via backdoor");
                $ct->save();
                $tg->sendMessage($userid, "Benvenuto {$patron->getName()}.\nIl tuo account è stato validato usando la backdoor.");
            } else
                $tg->sendMessage($userid, "Non sono riuscito a trovare questo barcode.");
        } else {
            $tg->sendMessage($userid, "Ciao {$username}, sono {$botName}.\n{$botWelcome}");
        }

        //$tg->sendMessage($update['message']['chat']['id'],"Benvenuto {$username}, {$update['message']['text']}"  );

        $resp = ['Amici' => "OK", "ID" => $apiid];

        header("Content-Type: text/json");
        print json_encode($resp);
        return false;
    }

    private function PostWebhookMailgun()
    {
        Prado::log('PostWebHookMailGun start', TLogger::INFO, 'SOAP');
        $apiId = $this->reply["REQUEST"]['APIID'];

        $event = $_REQUEST['event'];
        $domain = $_REQUEST['domain'];
        $ts = $_REQUEST['timestamp'];
        $recip = $_REQUEST['recipient'];
        $reason = $_REQUEST['reason'] ?? "";
        $code = $_REQUEST['code'] ?? "";
        $error = $_REQUEST['error'] ?? "";
        $description = $_REQUEST['description'] ?? "";
        $notificationId = $_REQUEST['notification_id'] ?? "";

        $notify = NotificationQuery::create()->findPk($notificationId);
        $contact = ContactQuery::create()->filterByContactType(ContactPeer::TYPE_EMAIL)->findOneByContactValue($recip);

        Prado::log("MAILGUN API[$apiId] EVENT[$event] REASON[$reason] $recip [$code]", TLogger::INFO, "SOAP");
        Prado::log(Prado::varDump($_REQUEST), TLogger::INFO, "SOAP");

        $resp = $this->_buildMailgunResponse($apiId, $notify, $contact, $ts, $reason, $code, $error, $description);

        header("Content-Type: text/json");
        print json_encode($resp);
        return false;
    }

    private function _buildMailgunResponse($apiId, $notify, $contact, $ts, $reason, $code, $error, $description): array
    {
        $resp = ['Res' => "OK"];
        switch ($apiId) {
            case "delivered":
                if ($notify instanceof Notification) {
                    $notify->setAcknowledgeDate($ts);
                    $notify->setNotificationState(NotificationPeer::STATUS_DELIVERED);
                    $notify->setNotes($notify->getNotes() . "\n" . "CONSEGNA OK!");
                    $notify->save();
                }

                break;
            case "dropped":
                if ($notify instanceof Notification) {
                    $notify->setNotificationState(NotificationPeer::STATUS_ERROR);
                    $notify->setNotes($notify->getNotes() . "\n" . "DROPPED: {$reason} [{$code}] {$error} {$description}");
                    $notify->save();
                }

                if ($contact instanceof Contact && ($reason === "bounce")) {
                    $contact->setContactType(ContactPeer::TYPE_WRONG);
                    $contact->save();
                }
                break;
            case "hardbounce":
                if ($notify instanceof Notification) {
                    $notify->setNotificationState(NotificationPeer::STATUS_ERROR);
                    $notify->setNotes($notify->getNotes() . "\n" . "HARD BOUNCE: [{$code}] {$error} {$description}");
                    $notify->save();
                }

                if ($contact instanceof Contact) {
                    $contact->setContactType(ContactPeer::TYPE_WRONG);
                    $contact->save();
                }
                break;
            case "spam":
                if ($notify instanceof Notification) {
                    $notify->setNotificationState(NotificationPeer::STATUS_ERROR);
                    $notify->setNotes($notify->getNotes() . "\n" . "SPAM: {$reason} [{$code}] {$error} ");
                    $notify->save();
                }
                break;
            case "open":
            case "click":
            case "unsubscribe":
                break;
            default:
                $resp = ['Res' => "KO", "Message" => "Method not supported"];
                break;
        }

        return $resp;
    }

    /**
     * @throws PropelException
     * @throws JsonException
     */
    private function PostWebhookMailgun2()
    {
        Prado::log('PostWebHookMailGun version 2 start', TLogger::INFO, 'SOAP');

        try {
            $postdata = json_decode(file_get_contents("php://input"), true, 512, JSON_THROW_ON_ERROR);
            $event_details = $postdata['event-data'];

            $apiId = $this->reply["REQUEST"]['APIID'];
            $notificationId = $event_details['user-variables']['notification_id'] ?? '';
            $consortia = $event_details['user-variables']['consortia'] ?? '';

            $event = $event_details['event'];
            $recip = $event_details['recipient'];
            $domain = $event_details['recipient-domain'];
            $ts = $event_details['timestamp'];

            $code = $event_details['delivery-status']['code'] ?? "";
            $description = $event_details['delivery-status']['description'] ?? "";
            $error = $event_details['delivery-status']['message'] ?? "";
            $reason = $event_details['reason'] ?? $event_details['reject']['reason'] ?? "";

            $notify = NotificationQuery::create()->findPk($notificationId);
            $contact = ContactQuery::create()->filterByContactType(ContactPeer::TYPE_EMAIL)->findOneByContactValue($recip);

            Prado::log("MAILGUN API[$apiId] EVENT[$event] REASON[$reason] $recip [$code]", TLogger::INFO, "SOAP");
            Prado::log(Prado::varDump($_REQUEST), TLogger::INFO, "SOAP");

            $resp = $this->_buildMailgunResponse($apiId, $notify, $contact, $ts, $reason, $code, $error, $description);

            header("Content-Type: text/json");
            print json_encode($resp);
            return false;

        } catch (JsonException $e) {
            $resp = ['Res' => "KO", "Message" => $e->getMessage()];
        }

        header("Content-Type: text/json");
        print json_encode($resp, JSON_THROW_ON_ERROR);
        return false;
    }


    private function PostWebhookInfobip()
    {
        //Prado::log( __METHOD__ . ' start', TLogger::INFO, 'SOAP' );

        $postdata = file_get_contents("php://input");

        //Prado::log( __METHOD__ . " id is {$this->getRequest()->itemAt('id')}", TLogger::INFO, 'SOAP' );

        //Prado::log( Prado::varDump( $postdata ), TLogger::INFO, 'SOAP' );
        $smsResult = json_decode($postdata);
        if (!is_null($smsResult)) {
            foreach ($smsResult->{'results'} as $result) {
                $acpt = $result->{'doneAt'};
                //Prado::log( __METHOD__ . " done at {$acpt}", TLogger::INFO, 'SOAP' );
                $acptDt = DateTime::createFromFormat('Y-m-d\TH:i:s.uP', $acpt);
                $acptDt->setTimezone(new DateTimeZone('Europe/Rome'));
                //Prado::log( __METHOD__ . " accepted {$acptDt->format('Y-m-d H:i:s')}", TLogger::INFO, 'SOAP' );
                $msgId = $result->{'messageId'};
                //Prado::log( __METHOD__ . " msg-id {$msgId}", TLogger::INFO, 'SOAP' );
                $msgIds = explode("|", $msgId);
                if (is_array($msgIds) && count($msgIds) == 3) {
                    $nId = $msgIds[2];
                    $n = NotificationQuery::create()->findOneByNotificationId($nId);
                    if ($n instanceof Notification) {
                        if ($result->{'status'}->{'id'} == 5) //DELIVERED
                        {
                            $n->setNotificationState(NotificationPeer::STATUS_DELIVERED);
                            $n->setAcknowledgeDate($acptDt);
                        } else {
                            //message was not delivered  ($result->{'status'}->{'name'} $result->{'error'}->{'name'} can be useful)
                            $n->setNotificationState(NotificationPeer::STATUS_ERROR);
                            $note = $n->getNotes();
                            $n->setNotes("{$note} R: {$result->{'status'}->{'name'}} E: {$result->{'error'}->{'name'}} To: {$result->{'to'}}");

                            if ($result->{'error'}->{'name'} == 'EC_UNKNOWN_SUBSCRIBER') {
                                // TODO make contact in error. $result->{'to'}
                            }
                        }
                        try {
                            $n->save();
                        } catch (Exception $ex) {
                            Prado::log(__METHOD__ . " error saving notification {$ex->getMessage()}");
                        }
                    } else {
                        Prado::log(__METHOD__ . " error loading notification id {$nId}");
                        Prado::log(Prado::varDump($msgIds));
                    }
                } else {
                    Prado::log(__METHOD__ . " error parsing message id {$msgId}");
                }

            }
        }
    }

    private function GetLockerStatus()
    {
        Prado::log('GetLockerStatus start', TLogger::INFO, 'SOAP');

        if ($this->librarian == null) {
            Prado::log("GetLockerStatus AUTH ERR", TLogger::INFO, 'SOAP');
            $this->reply['REPLY']['STATUS'] = "KO";
            $this->reply['REPLY']['ERRORCODE'] = "AUTHERR";
            $this->reply['REPLY']['ERRORINFO'] = "Non autorizzato";
            return true;
        }

        $lockerID = $this->getRequest()->itemAt('id');

        $locker = ResourceQuery::create()->filterByType(["locker", "returnbox"])->findOneByName($lockerID);
        $cells = ResourceRuleQuery::create()->findByResourceOwner($lockerID);

        $cellStatus = ["cells" => []];

        foreach ($cells as $cell) {
            /** @var ResourceRule $cell */

            $cellData = [
                "lockID" => intval($cell->getAmount()),
                "column" => $cell->getResourceGroup(),
                "row" => $cell->getResourcePattern(),
                "items" => [],
                "patron" => []
            ];

            $patron = PatronQuery::create()->findPk($cell->getPatronId());
            if ($patron instanceof Patron) {
                $cellData['patron'] = [
                    "name" => $patron->getCompleteName(),
                    "barcode" => $patron->getBarcode()
                ];
                $itemData = json_decode($cell->getConf(), true);
                foreach ($itemData as $itemBarcode => $itemData) {
                    $itemData['days'] = date_diff(DateTime::createFromFormat("U", time()), DateTime::createFromFormat("U", $itemData['loadDate']))->days;
                    $cellData['items'][] = $itemData;
                }
            }

            $cellStatus['cells'][] = $cellData;
        }

        if ($locker instanceof Resource) {
            $conf = json_decode($locker->getConf(), true);
            $this->reply['REPLY']['STATUS'] = "OK";
            $this->reply['REPLY']['RESULT'] = [
                "totCells" => count($cells),
                "config" => $conf,
                "cellStatus" => $cellStatus
            ];
        } else {
            $this->reply['REPLY']['STATUS'] = "KO";
            $this->reply['REPLY']['ERRORCODE'] = "NOTFOUND";
            $this->reply['REPLY']['ERRORINFO'] = "Locker {$lockerID} non trovato o privo di celle";
        }
        return true;
    }


    private function GetLockerLoad()
    {
        Prado::log('GetLockerLoad start', TLogger::INFO, 'SOAP');

        if ($this->librarian == null) {
            Prado::log("GetLockerLoad AUTH ERR", TLogger::INFO, 'SOAP');
            $this->reply['REPLY']['STATUS'] = "KO";
            $this->reply['REPLY']['ERRORCODE'] = "AUTHERR";
            $this->reply['REPLY']['ERRORINFO'] = "Non autorizzato";
            return true;
        }

        $lockerID = $this->getRequest()->itemAt('id');
        $column = $this->getRequest()->itemAt('column');
        $row = $this->getRequest()->itemAt('row');
        $itemBarcode = $this->getRequest()->itemAt('itemBarcode');
        $patronBarcode = $this->getRequest()->itemAt('patronBarcode');

        $locker = ResourceQuery::create()->filterByType(["locker", "returnbox"])->findOneByName($lockerID);
        $patron = PatronQuery::create()->findOneByBarcode($patronBarcode);
        $item = ItemQuery::create()->findOneByBarcode($itemBarcode);

        $this->reply['REPLY']['STATUS'] = "KO";
        $this->reply['REPLY']['ERRORCODE'] = "LOCKUNK";
        $this->reply['REPLY']['ERRORINFO'] = "Locker sconosciuto";

        $cell = null;
        if ($locker instanceof Resource) {
            // Find if a cell for the patron is allocated
            if ($patron instanceof Patron) {
                // $cell = ResourceRuleQuery::create()->filterByPatronId($patron->getPatronId())->findOneByResourceOwner($lockerID);
                $cell = null;
            }
            if (is_null($cell)) {
                $cell = ResourceRuleQuery::create()->filterByResourceGroup($column)->filterByResourcePattern($row)->findOneByResourceOwner($lockerID);
                // TO DO check che la cella non sia di un utente diverso
            }

            if ($cell instanceof ResourceRule) {
                $cellData = json_decode($cell->getConf(), true);

                if (!isset($cellData[$itemBarcode])) {
                    $cell->setPatronId($patron->getPatronId());
                    $cellData[$itemBarcode] = [
                        "title" => $item->getTitle(),
                        "barcode" => $itemBarcode,
                        "loadDate" => time()

                    ];
                    $cell->setConf(json_encode($cellData));
                    $cell->save();
                }

                /** @var $lm ClavisLoanManager */
                $lm = Prado::getApplication()->getModule("loan");

                if ($lm->IsInTransit($item)) {
                    if ($lm->DoMoved2ReadyToLoanItem($item, Prado::getApplication()->getUser())) {

                        if (ClavisParamQuery::getParam('CLAVISPARAM', 'AutoEmailLoanReady') == 'true') {
                            $ret = NotificationHelper::sendNotificationEmail('readyforloan',
                                $item->getPatron(),
                                $this->librarian,
                                $item->getLibraryRelatedByActualLibraryId(),
                                array($item->getCurrentLoanId()));

                            if ($ret) {
                                $item->setNotifyCount($item->getNotifyCount() + 1);
                                $item->save();

                                $loan = $item->getLoanRelatedByCurrentLoanId();
                                $loan->setNotifyCount($loan->getNotifyCount() + 1);
                                $loan->save();
                            }
                        }
                    }
                }

                try {
                    $itemActionLoad = new ItemAction();
                    $itemActionLoad->setLibraryId($item->getActualLibraryId());
                    $itemActionLoad->setItemId($item->getItemId());
                    $itemActionLoad->setLibrarianId($this->librarian->getLibrarianId());
                    $itemActionLoad->setActionType(ItemActionPeer::TYPE_READYFORLOAN);
                    $itemActionLoad->setActionDate(time());
                    $itemActionLoad->setFromLibraryId($item->getActualLibraryId());
                    $itemActionLoad->setToLibraryId($item->getActualLibraryId());
                    $itemActionLoad->setDateCreated(time());
                    $itemActionLoad->setDateUpdated(time());
                    $itemActionLoad->setCreatedBy($this->librarian->getLibrarianId());
                    $itemActionLoad->setModifiedBy($this->librarian->getLibrarianId());
                    $itemActionLoad->setActionNote("Caricato nel Locker {$lockerID} nella Cella {$cell->getNote()}");
                    $itemActionLoad->save();
                } catch(Exception $e) {
                    Prado::log("Errore nel caricamento: " .$e->getMessage());
                    $this->reply['REPLY']['ERRORCODE'] = "ERR";
                    $this->reply['REPLY']['ERRORINFO'] = $e->getMessage();
                    return true;
                }

                $this->reply['REPLY']['STATUS'] = "OK";
                $this->reply['REPLY']['ERRORCODE'] = "";
                $this->reply['REPLY']['ERRORINFO'] = "";


            } else {
                $this->reply['REPLY']['ERRORCODE'] = "CELLUNK";
                $this->reply['REPLY']['ERRORINFO'] = "Impossibile trovare la cella";
            }
        }

        return true;
    }

    /**
     * Unload all items into a cell of a locker, doedn
     */
    private function GetLockerUnload()
    {
        Prado::log('GetLockerUnload start', TLogger::INFO, 'SOAP');

        if ($this->librarian == null) {
            Prado::log("GetLockerUnload AUTH ERR", TLogger::INFO, 'SOAP');
            $this->reply['REPLY']['STATUS'] = "KO";
            $this->reply['REPLY']['ERRORCODE'] = "AUTHERR";
            $this->reply['REPLY']['ERRORINFO'] = "Non autorizzato";
            return true;
        }

        $lockerID = $this->getRequest()->itemAt('id');
        $column = $this->getRequest()->itemAt('column');
        $row = $this->getRequest()->itemAt('row');

        $patronBarcode = $this->getRequest()->itemAt('patronBarcode');

        $locker = ResourceQuery::create()->filterByType(["locker", "returnbox"])->findOneByName($lockerID);
        $cell = ResourceRuleQuery::create()->filterByResourceGroup($column)->filterByResourcePattern($row)->findOneByResourceOwner($lockerID);
        $patron = PatronQuery::create()->findOneByBarcode($patronBarcode);

        if ($locker instanceof Resource) {
            // Find if a cell for the patron is allocated
            if ($patron instanceof Patron) {
                $cell = ResourceRuleQuery::create()->filterByPatronId($patron->getPatronId())
                    ->filterByResourceGroup($column)
                    ->filterByResourcePattern($row)
                    ->findOneByResourceOwner($lockerID);
            }

            if ($cell instanceof ResourceRule) {
                // Empty Cell

                $cell->setPatronId(null);
                $cell->setConf("{}");
                $cell->save();

                $this->reply['REPLY']['STATUS'] = "OK";
                $this->reply['REPLY']['ERRORCODE'] = "";
                $this->reply['REPLY']['ERRORINFO'] = "";

                // add itemAction (load into locker)

            } else {
                $this->reply['REPLY']['ERRORCODE'] = "CELLUNK";
                $this->reply['REPLY']['ERRORINFO'] = "Impossibile trovare la cella";
            }
        }
        return true;
    }

    private function GetLockerCheckout()
    {
        Prado::log('GetLockerCheckout start', TLogger::INFO, 'SOAP');
        $auth = Prado::getApplication()->getModule('auth');

        if ($this->librarian == null) {
            Prado::log("GetLockerCheckout AUTH ERR", TLogger::INFO, 'SOAP');
            $this->reply['REPLY']['STATUS'] = "KO";
            $this->reply['REPLY']['ERRORCODE'] = "AUTHERR";
            $this->reply['REPLY']['ERRORINFO'] = "Non autorizzato";
            return true;
        }

        $login = $auth->login($this->reply["REQUEST"]['XUSERNAME'], $this->reply["REQUEST"]['XPASSWORD']);
        Prado::log($login ? 'Login OK!' : 'Login KO!', TLogger::INFO, 'SOAP');

        $lockerID = $this->getRequest()->itemAt('id');
        $column = $this->getRequest()->itemAt('column');
        $row = $this->getRequest()->itemAt('row');
        $patronBarcode = $this->getRequest()->itemAt('patronBarcode');

        $locker = ResourceQuery::create()->filterByType(["locker", "returnbox"])->findOneByName($lockerID);
        $patron = PatronQuery::create()->findOneByBarcode($patronBarcode);

        $this->reply['REPLY']['STATUS'] = "KO";
        $this->reply['REPLY']['ERRORCODE'] = "LOCKUNK";
        $this->reply['REPLY']['ERRORINFO'] = "Locker sconosciuto";

        if ($locker instanceof Resource && $patron instanceof Patron) {
            $cell = ResourceRuleQuery::create()
                ->filterByResourceGroup($column)
                ->filterByResourcePattern($row)
                ->filterByPatronId($patron->getPatronId())
                ->findOneByResourceOwner($lockerID);
            if ($cell instanceof ResourceRule) {

                $cellData = json_decode($cell->getConf(), true);

                Prado::log(Prado::varDump($cellData));

                /** @var $lm ClavisLoanManager */
                $lm = Prado::getApplication()->getModule("loan");

                $checkoutData = [];
                foreach ($cellData as $itemBarcode => $data) {

                //    error_log("CELL DATA $itemBarcode");

                    $item = ItemQuery::create()->findOneByBarcode($itemBarcode);

                    $res = $lm->DoLoanItem($item, $patron, Prado::getApplication()->getUser(), LibraryQuery::create()->findPk($this->reply['REQUEST']['XLIBRARY']));

                    $checkoutData[] = array(
                        "Title" => $item->getTitle(),
                        "Message" => "",
                        "Media" => $item->getItemMedia(),
                        "ItemId" => $item->getItemId(),
                        "Barcode" => $item->getBarcode(),
                        "LoanClass" => $item->getLoanClass(),
                        "Inventory" => $item->getCompleteInventoryNumber(),
                        "Collocation" => $item->getCollocationCombo(),
                        "Rfid" => $item->getRfidCode(),
                        "Renewable" => false,
                        "Late" => false,
                        "LoanStatusRes" => $res,
                        "DueDate" => $item->getDueDate("d-m-Y"),
                        "LoanStatus" => $item->getLoanStatus(),
                        "Status" => ($res == ClavisLoanManager::OK || $res == ClavisLoanManager::LOAN_LOANED)?"OK":"ERR"
                    );
                }

                $cell->setPatronId(null);
                $cell->setConf("{}");
                $cell->save();

                if (count($checkoutData) > 0) {
                    $this->reply['REPLY']['STATUS'] = "OK";
                    $this->reply['REPLY']['RESULT'] = $checkoutData;
                    $this->reply['REPLY']['ERRORCODE'] = "";
                    $this->reply['REPLY']['ERRORINFO'] = "";
                } else {
                    $this->reply['REPLY']['STATUS'] = "KO";
                    $this->reply['REPLY']['ERRORCODE'] = "CELLEMPTY";
                    $this->reply['REPLY']['ERRORINFO'] = "Cella vuota";
                }
            }
        } else {
            $this->reply['REPLY']['STATUS'] = "KO";
            $this->reply['REPLY']['ERRORCODE'] = "LOCKUNK";
            $this->reply['REPLY']['ERRORINFO'] = "Locker sconosciuto";
        }

        return true;
    }
}