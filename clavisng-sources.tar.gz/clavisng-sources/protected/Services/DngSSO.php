<?php

/*
 * Questo modulo permette l'autenticazione via SSO (Single Sign On) tramite il protocollo SAML2.0
 * Per funzionare correttamente deve essere modificato il file clavis-application.xml del site
 * su cui vogliamo abilitare questa funzionalita', verificando che nelle sezioni paths, module, e
 * services vi siano le direttive indicate qui in seguito:
 *
  <paths>
          <alias id="SSO" path="./sso/"/>
  </paths>

  <module id="friendly-url" class="System.Web.TUrlMapping" EnableCustomUrl="true">
		<url ServiceID="sso" ServiceParameter="supermegakiavesegreta!" pattern="sso/{action}" parameters.action="(\w+)?"/>
  </module>

  <services>
        <service id="sso" class="Application.Services.ClavisSSO" DefaultPage="MyHomePage.Home"/>
  </services>

 * Nella cartella sites/nomesito/sso inoltre e' necessario vi siano questi file di configurazione:
 * settings.php, advanced_settings.php o un link ai file posti sotto vcs e presenti nella cartella
 * contrib/sso-settings/nomesito/{settings.php, advanced_settings.php}.
 *
 * 2) Nella cartella sites/nomesito/sso/certs e' necessario vi sia il certificato e la chiave privata per
 * firmare e criptare i messaggi nel caso la comunicazione con l'idp lo richieda.
 * Devono avere questi nomi: sp.crt e sp.key rispettivamente il certificato x509 e la chiave privata.
 * Sono generati dal comando getCerts.sh che si trova nella cartella contrib/sso-bin che e' un wrapper per
 * questo comando:
 * sudo ./sso-keygen.sh -s nomesito -h nost.ngrok.io -e https://host.ngrok.io/sso/ "$@"
 * dove con l'opzione -s passo il nome del sito clavisng, con -h l'host su cui generare il certificato e con -e
 * l'entityID del ServiceProvider (ClavisSSO).
 * E'possibile generare anche un file statico di metadati relativi al Service Provider con il comando
 * `./sso-bin/getMetada   -h host.example.com -s nomesito` da mandare al IDP ma tecnicamente non e' piu'
 * necessario in quanto l'endpoint clavisng/sso/metadata, una volta compilati correttamente i parametri
 * in settings.php, si preoccupa di generarli automaticamente; e' questo url che dovra' essere comunicato all'idp.
**/

use OneLogin\Saml2\Constants;

require_once 'protected/Services/ClavisSSO.php';

/**
 * Class DngSSO
 */
class DngSSO extends ClavisSSO
{
    /**
     * @var
     */
    public $DNGUrl;

    /**
     * @var
     */
    protected $sloBinding;

    protected $ssoBinding;

    /**
     * @return mixed
     */
    public function getDNGUrl()
    {
        return $this->DNGUrl;
    }

    /**
     * @return mixed
     */
    public function getSloBinding()
    {
        return $this->sloBinding ?? Constants::BINDING_HTTP_REDIRECT;
    }

    public function getSsoBinding()
    {
        return $this->ssoBinding ?? Constants::BINDING_HTTP_REDIRECT;
    }

    /**
     * @throws \OneLogin\Saml2\Error
     */
    protected function initSAMLHandler()
    {
        $this->saml = new ClavisSAML('/dng', $this->getSsoBinding(), $this->getSloBinding());
    }

    // -----------------------------------------------------------------------------------------------------------------
    // LOGIN
    // -----------------------------------------------------------------------------------------------------------------

    protected function doLocalLogin(&$patronAuthData, &$samlAuthData): bool
    {
        $patron = $patronAuthData['patron'];
        $dngUrl = $this->getDNGUrl();
        $apikey = DNGSimpleAuthenticator::getApiKey();
        $ok = DNGSimpleAuthenticator::create($patron, $apikey, $dngUrl)->authorize($loginData);
        if ($ok) {
            $samlAuthData['autologin_token'] = $loginData['autologin_token'];
            $samlAuthData['sid'] = $loginData['sid'];
        }
        return $ok;
    }

    /**
     *
     */
    protected function onLocalAuthenticationFail()
    {
        header("Location: " . $this->getDNGUrl() . 'sso-user-not-found');
        exit();
    }

    /**
     *
     */
    protected function onIdpAuthenticationFail()
    {
        header("Location: " . $this->getDNGUrl() . 'sso-error');
        exit();
    }

    /**
     * @param $patronAuthData
     * @param $samlAuthData
     * @throws PropelException
     */
    protected function onSuccessfulLogin($patronAuthData, $samlAuthData)
    {
        $tkn = $samlAuthData['autologin_token'];
        $this->saml->saveAuthData($samlAuthData, $patronAuthData['patron'], false);

        $dngUrl = $this->getDNGUrl();
        header("Location: " . $dngUrl . "mydiscovery?autoLogin={$tkn}");
        exit();
    }

    protected function onLoginError($patronAuthData, $samlAuthData)
    {

        $pid = null;
        $patron = $patronAuthData['patron'];

        if ($patron instanceof Patron) {
            $pid = $patron->getPatronId();
        }
        $this->saml::saveFailedLoginEvent($samlAuthData['samlNameId'], $samlAuthData['samlSessionIndex'], $samlAuthData['autologin_token'], $pid);

        $dngUrl = $this->getDNGUrl();
        header("Location: " . $dngUrl . 'sso-error');
        exit();
    }


    // -----------------------------------------------------------------------------------------------------------------
    // LOGOUT
    // -----------------------------------------------------------------------------------------------------------------

    /**
     * @return bool
     * @throws \OneLogin\Saml2\Error
     */
    protected function doLogout()
    {
        $pid = filter_var($_REQUEST['patronID'], FILTER_SANITIZE_NUMBER_INT);
        $samlUK = filter_var($_REQUEST['key'], FILTER_SANITIZE_STRING);
        $this->saml->logout($pid, false, $samlUK, false);

        return true;
    }

    protected function sloCallback($logoutRequest)
    {
        if (isset($_REQUEST['SAMLResponse'])) {
            if ($logoutRequest->getStatus() === Constants::STATUS_SUCCESS) {
                if (is_callable('ClavisSSOAuthenticator::onLogoutSuccess')) {
                    ClavisSSOAuthenticator::onLogoutSuccess($this->getDNGUrl());
                }
                return true;
            }

            if (is_callable('ClavisSSOAuthenticator::onLogoutFail')) {
                ClavisSSOAuthenticator::onLogoutFail($logoutRequest->getStatus(), $this->getDNGUrl());
            }
            return false;
        }

        if (isset($_REQUEST['SAMLRequest'])) {
            // IDP INITIATED FLOW STARTS HERE ----------------------------------------------------------------
            /** @var CustomLogoutRequest $logoutRequest */
            $nameID = CustomLogoutRequest::getNameId($logoutRequest->getXML(), $this->saml->getSamlSettings()->getSPkey());

            // get patron ID
            // -----------------------------------------------------------------------------------------------
            $patronID = $this->saml->getPatronIDFromNameId($nameID);

            // get session indexes from logout request
            $sessionIndexes = CustomLogoutRequest::getSessionIndexes($logoutRequest->getXML());

            // remove dng sessions linked to the given session index
            foreach ($sessionIndexes as $sessionIndex) {
                if ($patronID > 0) {
                    $datas = ClavisSAML::getPatronData($patronID, $sessionIndex, false);

                    foreach ($datas as $data) {
                        ClavisSSOAuthenticator::doIDPInitiatedLogout(['patronID' => $patronID, 'sessionID' => $data['sid'], 'dngURL' => $this->getDNGUrl()]);
                        $this->saml::saveLogoutEvent($nameID, $sessionIndex, $data['sid'], $patronID);
                    }
                }
            }

            // returns to the slo flow that sends back the logout response to the idp
            return true;
        }
        return false;
    }

    /**
     * @param $patron
     * @param $data
     */
    protected function onLogoutSuccess($patron, $data)
    {

    }
}
