<?php
/**
 * ClavisSafeSurfSoapInterface class
 * The class is used by the system netmanager
 * and provides methods for calling soap web application netmanager
 * and AAA server freeradius
 *
 * @author Dario Rigolin <drigolin@comperio.it>
 * @author Isacco Occhiali <isacco.occhiali@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2009-2010 Comperio srl
 * @license http://www.comperio.it/license/
 * @version 2.7
 */
class ClavisSafeSurfSoapInterface {
	/**
	 * Reference to LoanManager
	 *
	 * @var ClavisLoanManager
	 */
	private $loanManager;

        
        public function setNewRelicTransaction($transname) {
            
            if (extension_loaded('newrelic')) {
                newrelic_set_appname ("ClavisNG - " . Prado::getApplication()->getID());
                newrelic_name_transaction($transname);
            }
        }
        
	/**
         *
         * @param string $username
         * @param string $password
         * @return array
         * @soapmethod
         */
	public function loginLibrarian($username, $password) {
            $this->setNewRelicTransaction("SOAP." . __METHOD__);
		$crypt = Prado::getApplication()->getModule("crypt");
		$criteria = new Criteria();
		$criteria->add(LibrarianPeer::USERNAME, $username);
		$librarian = LibrarianPeer::doSelectOne($criteria);
		if($librarian != null && $crypt->LibrarianVerify($password,$librarian->getSecret()) ) {
			$ldata=array();
			$ldata=array('nome_completo'=>$librarian->getCompleteName(),'librarian_id'=>$librarian->getId(),'username'=>$librarian->getUserName());
			return $ldata;
		}else{
			return array("error"=>"login fallito!");
		}
	}

	/**
         *
         * @param string $username
         * @return array
         * @soapmethod
         */
	public function getLibrarian($username) {
            $this->setNewRelicTransaction("SOAP." . __METHOD__);
		$criteria = new Criteria();
		$criteria->add(LibrarianPeer::USERNAME, $username);
		$result = LibrarianPeer::doSelectOne($criteria);
		$librarian_data=array();
		$librarian_data=array('Nome'=>$result->getCompleteName(),'Username'=>$result->getUsername());
		#Prado::log ( "get librarian ".$librarian_data['Nome']." OK", TLogger::INFO, "SOAP" );
		return $librarian_data;
	}

	/**
         *
         * @param string $username
         * @param string $password
         * @return array
         * @soapmethod
         */
	public function getPatron($username,$password) {
            $this->setNewRelicTransaction("SOAP." . __METHOD__);
		$crypt = Prado::getApplication()->getModule("crypt");
		$criteria = new Criteria();
		$criteria->add(PatronPeer::OPAC_USERNAME, $username);
		$patron = PatronPeer::doSelectOne($criteria);
                $document_expiry='null';
                if($patron != null && $crypt->PatronVerify($password,$patron->getOpacSecret()) ) {
                        /* COMMIT ON SEPTEMBER 2010
                        if(!is_null($patron->getDocumentExpiry()) && $patron->getDocumentExpiry()!=''){
                                $document_expiry=$patron->getDocumentExpiry('%Y-%m-%d');
                        }
                        $patron_data=array('nome_completo'=>$patron->getCompleteName(),'patron_id'=>$patron->getId(),'username'=>$patron->getOpacUsername(),'patron_barcode'=>$patron->getBarcode(),'patron_cardcode'=>$patron->getCardCode(),'opac_enable'=>$patron->getOpacEnable(),'patron_status'=>$patron->getPatronStatus(),'document_expiry'=>$document_expiry);

                         *
                         */
                         /*
                        $patron_data=array(
                            'nome_completo'=>$patron->getCompleteName(),
                            'patron_id'=>$patron->getId(),
                            'username'=>$patron->getOpacUsername(),
                            'patron_barcode'=>$patron->getBarcode(),
                            'patron_cardcode'=>$patron->getCardCode(),
                            'opac_enable'=>intval($patron->getOpacEnable()),
                            'surf_enable'=>intval($patron->getSurfEnable()),
                            'patron_status'=>$patron->getPatronStatus()
                            );*/
                        
                        $patron_data = $patron->toArray();
                        
                        //for compatibility
                        $patron_data['nome_completo'] = $patron->getCompleteName();
                        $patron_data['patron_id'] = $patron->getId();
                        $patron_data['username'] = $patron->getOpacUsername();
                        $patron_data['patron_barcode'] = $patron->getBarcode();
                        $patron_data['patron_cardcode'] = $patron->getCardCode();
                        $patron_data['opac_enable'] = intval($patron->getOpacEnable());
                        $patron_data['surf_enable'] = intval($patron->getSurfEnable());
                        $patron_data['patron_status'] = $patron->getPatronStatus();
                        
                        return $patron_data;
                }else{
                        return array("error"=>"Login fallito! $password, $username");
                }
	}

	/**
         * @param string $username
         * @return array
         * @soapmethod
         */
	public function getPatronByUsername($username) {
            $this->setNewRelicTransaction("SOAP." . __METHOD__);
		$criteria = new Criteria();
		$criteria->add(PatronPeer::OPAC_USERNAME, '%'.$username.'%',Criteria::LIKE);
		$patron = PatronPeer::doSelectOne($criteria);
		$consortiaid=0;
		if(!is_null($patron)){
			$library = $patron->getPreferredLibrary();
			if(!is_null($library)){
				$consortiaid=$library->getConsortiaId();
				$patron_data=array();
				$patron_data=array('Nome'=>$patron->getCompleteName(),'PatronId'=>$patron->getId(),'Username'=>$patron->getOpacUsername(),'Barcode'=>$patron->getBarcode(),'ConsortiaId'=>$consortiaid);
				return $patron_data;
			}else{
				return array("error"=>"Nessuna Biblioteca preferita trovata");
			}
		}else{
			return array("error"=>"Nessun utente trovato!");
		}


	}

	/**
         * @param string $patronid
         * @return array
         * @soapmethod
         */
	public function getPatronById($patronid) {
            $this->setNewRelicTransaction("SOAP." . __METHOD__);
		$consortiaid=0;
		$patron_data=array();
		$patron = PatronPeer::retrieveByPk($patronid);
		if(!is_null($patron)){
			$library = $patron->getPreferredLibrary();
			if(!is_null($library)){
				$consortiaid=$library->getConsortiaId();
			}
			$patron_data=array('Nome'=>$patron->getCompleteName(),'LibraryId'=>$patron->getPreferredLibraryId(),'Username'=>$patron->getOpacUsername(),'Barcode'=>$patron->getBarcode(),'ConsortiaId'=>$consortiaid);
		}
		else
		{
			Prado::log(__METHOD__.' '.__LINE__. " *** ERROR *** no patron with id $patronid");
		}
				
		return $patron_data;
	}

	/**
	 * Get an Item via Barcode
	 *
	 * @param string $barcode
	 * @return Item
	 */
	private function findItem($barcode)
	{
		$c = new Criteria ( );
		$c->add ( ItemPeer::BARCODE, $barcode );
		$item = ItemPeer::doSelectOne ( $c );

		return $item;
	}

	/**
	 * Get a Partron via Barcode
	 *
	 * @param string $barcode
	 * @return Patron
	 */
	private function findPatron($barcode)
	{
		$c = new Criteria ( );
		$c->add ( PatronPeer::BARCODE, $barcode );
		$patron = PatronPeer::doSelectOne ( $c );

		return $patron;
	}

	/**
	 * Get a Partron by Barcode
	 * @param string $barcode
	 * @return array
         * @soapmethod
	 */
	public function getPatronByBarcode($barcode)
	{
            $this->setNewRelicTransaction("SOAP." . __METHOD__);
                $c = new Criteria ( );
                $c->add ( PatronPeer::BARCODE, $barcode );
                $patron = PatronPeer::doSelectOne ( $c );
		// set patron array
		$patron_data=array();
                $patron_data=array("nome_completo"=>$patron->getCompleteName(),"username"=>$patron->getOpacUsername(),"patron_barcode"=>$patron->getBarcode(),"patron_id"=>$patron->getId());
                return $patron_data;
	}

	/**
	 * @param string $usernameLib username/barcode (patron)
	 * @param string $passwordLib passowrd
	 * @param string $username username/barcode (patron)
	 * @param string $password passowrd
	 * @return array
	 * @soapmethod
	 */
	public function loginUser($usernameLib, $passwordLib, $username, $password) {
            $this->setNewRelicTransaction("SOAP." . __METHOD__);
		$login = $this->loginLibrarian ( $usernameLib, $passwordLib );
		if($login){
			$userData=array();
			$patron = $this->getPatron($username,$password);
			if($patron){
				$userData = $patron;
			}
			return $userData;

		}
	}

	/**
	 * @param string $username username/barcode (patron)
	 * @param string $password passowrd
	 * @param string $barcode
	 * @return array
	 * @soapmethod
	 */
	public function bookLoad($username, $password, $barcode) {
            $this->setNewRelicTransaction("SOAP." . __METHOD__);
		$login = $this->loginLibrarian ( $username, $password );
		if ($login) {
			$item = $this->findItem($barcode);
			if($item != null)
			{
				if($this->loanManager->IsInTransit($item))
				{
					$result = $this->loanManager->DoMoved2ReadyToLoanItem($item,Prado::getApplication()->getUser());
					if($result) {
						// TODO inviare una email all'utente
						return array("Result"=>"Esemplare pronto al prestito");
					} else {
						return array("Error"=>"Errore generico...");
					}
				} else {
					return array("Error"=>"L'esemplare non risulta in transito");
				}
			} else {
				return array("Error"=>"Barcode sconosciuto");
			}

		}
		return array("Error"=>"Errore di autorizzazione");
	}

	/**
	 * @param string $username username/barcode (patron)
	 * @param string $password passowrd
	 * @param string $barcode
	 * @return array
	 * @soapmethod
	 */
	public function bookUnLoad($username, $password, $barcode) {
            $this->setNewRelicTransaction("SOAP." . __METHOD__);
		$login = $this->loginLibrarian ( $username, $password );
		if ($login) {

		}
		return array("Error"=>"Errore di autorizzazione");
	}

	/**
	 * @param string $username username/barcode (macchina)
	 * @param string $password passowrd   (macchina)
	 * @param string $barcode
	 * @return array
	 * @soapmethod
	 */
	public function checkBook($username, $password, $barcode) {
            $this->setNewRelicTransaction("SOAP." . __METHOD__);
		Prado::log("CheckBook",TLogger::INFO,"SOAP");

		$login = $this->loginLibrarian ( $username, $password );
		if ($login) {

			$c = new Criteria ( );
			$c->add ( ItemPeer::BARCODE, $barcode );
			$item = ItemPeer::doSelectOne ( $c );
			if ($item != null) {
				Prado::log("Book $barcode trovato",TLogger::INFO,"SOAP");
				$bookInfo = array (
					"Title" => $item->getTitle (),
					"Author" => $item->getManifestation ()->getAuthor (),
					"Year" => $item->getManifestation()->getPublisher(),
					"Publisher" => $item->getManifestation()->getPublisher(),
					"CoverUrl" => $this->getRequest()->constructUrl('file','cover',array('id'=>$item->getManifestationId())),
					"BookID" => $item->getManifestationId(),
					"Barcode" => $item->getBarcode(),
					"Scadenza" => $item->getDueDate("d-m-Y"),
					"Stato" => $item->getLoanStatusString(),
					"PatronId" => $item->getPatronBarcode() );
				return $bookInfo;
			} else {
				Prado::log("Errore barcode $barcode sconosciuto",TLogger::INFO,"SOAP");
				return array ("Error"=>"Barcode sconosciuto" );
			}

		}
		Prado::log("Autenticazione fallita",TLogger::INFO,"SOAP");
		return array ("Error"=>"Autenticazione errata" );
	}

	/**
	 * @param string $username username/barcode (macchina)
	 * @param string $password passowrd   (macchina)
	 * @param string $barcodePatron
	 * @param string $barcodeItem
	 * @return array
	 * @soapmethod
	 */
	public function newLoan($username, $password, $barcodePatron, $barcodeItem) {
            $this->setNewRelicTransaction("SOAP." . __METHOD__);
		Prado::log("New loan",TLogger::INFO,"SOAP");
		$login = $this->loginLibrarian ( $username, $password );
		if ($login) {
			$item = $this->findItem($barcodeItem);
			$patron = $this->findPatron($barcodePatron);
			if($item != null)
			{
				if($patron != null)
				{
					if($item->getLoanStatus() == ItemPeer::LOANSTATUS_READYFORLOAN)
						$ret = $this->loanManager->DoReadyToLoan2LoanItem($item,Prado::getApplication()->getUser());
					else
						$ret = $this->loanManager->DoLoanItem($item,$patron,Prado::getApplication()->getUser(), Prado::getApplication()->getUser()->getActualLibrary());

					if (($ret == true) || ($ret == ClavisLoanManager::OK))
					{
						Prado::log("Prestito esemplare $barcodeItem all'utente $barcodePatron OK",TLogger::INFO,"SOAP");

						return array ("DueDate"=> $item->getDueDate("d-m-Y"));
					} else {
						Prado::log("DoLoanItem error esemplare $barcodeItem all'utente $barcodePatron KO",TLogger::INFO,"SOAP");
						return array ("Error"=>"Errore durante il prestito" );
					}

				} else {
					Prado::log("Barcode utente $barcodeItem sconosciuto",TLogger::INFO,"SOAP");
					return array ("Error"=>"Barcode Utente $barcodeItem sconosciuto" );
				}

			} else {
				Prado::log("Esemplare $barcodeItem sconosciuto",TLogger::INFO,"SOAP");
				return array ("Error"=>"Barcode esemplare $barcodeItem sconosciuto" );
			}
		}

		Prado::log("Autenticazione fallita",TLogger::INFO,"SOAP");
		return array ("Error"=>"Autenticazione errata" );
	}

	/**
	 * @param string $username username/barcode (macchina)
	 * @param string $password passowrd   (macchina)
	 * @param string $barcodePatron
	 * @param string $barcodeItem
	 * @return array
	 * @soapmethod
	 */
	public function returnItem($username, $password, $barcodeItem) {
            $this->setNewRelicTransaction("SOAP." . __METHOD__);
		Prado::log("Return item $barcodeItem",TLogger::INFO,"SOAP");
		$login = $this->loginLibrarian ( $username, $password );
		if ($login) {
			$item = $this->findItem($barcodeItem);
			if($item != null)
			{
				$ret = $this->loanManager->DoReturnItem($item,$item->getPatron(),Prado::getApplication()->getUser());
				if($ret)
				{
					Prado::log("Restituzione $barcodeItem OK",TLogger::INFO,"SOAP");
					return array();
				} else {
					Prado::log("Errore durante restituzione $barcodeItem",TLogger::INFO,"SOAP");
					return array("Error"=>"Errore durante la restituzione");
				}
			} else {
				Prado::log("Esemplare $barcodeItem sconosciuto",TLogger::INFO,"SOAP");
				return array("Error"=>"Esemplare $barcodeItem sconosciuto");
			}
		}
		Prado::log("Autenticazione fallita",TLogger::INFO,"SOAP");
		return array("Error"=>"Errore di autorizzazione");
	}

	/**
	 * Authenticate a Patron an return a Patron instance
	 *
	 * @param string $username
	 * @param string $password
	 * @return Patron
	 */
	private function authenticatePatron($barcode, $password) {

		$crypt = Prado::getApplication()->getModule("crypt");

		$c = new Criteria ( );
		$c->add ( PatronPeer::BARCODE, $barcode );


		$patron = PatronPeer::doSelectOne ( $c );


		if($patron != null && $crypt->PatronVerify($password,$patron->getOpacSecret()) ) {
			Prado::log ( "authenticatePatron: $barcode OK", TLogger::INFO, "SOAP" );

		} else {
			Prado::log ( "authenticatePatron: $barcode NON OK", TLogger::INFO, "SOAP" );
		}
		return $patron;
	}

	/**
	 * test
	 *
	 * @param string $username
	 * @param string $password
	 * @return array
	 * @soapmethod
	 */
	public function test() {
            $this->setNewRelicTransaction("SOAP." . __METHOD__);
		$patron=array();
		$patron = array("Nome"=>"Isacco Occhiali","PatronId"=>"9");
		return $patron;
	}

}

?>
