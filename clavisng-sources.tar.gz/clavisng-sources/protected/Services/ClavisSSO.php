<?php


use OneLogin\Saml2;
use OneLogin\Saml2\Constants;

/**
 * Class ClavisSSO
 */
class ClavisSSO extends TService
{
    /**
     * @var
     */
    public $DefaultPage;

    /**
     * @var ClavisSAML
     */
    protected $saml;

    /**
     * @var
     */
    protected $sloBinding;
    protected $ssoBinding;

    /**
     * @throws \OneLogin\Saml2\Error
     * @throws Exception
     */
    public function run()
    {
        $this->initSAMLHandler();
        $this->loadLocalAuthenticator();

        $action = strtolower($this->getRequest()->itemAt("action"));

        switch ($action) {
            case 'metadata':
                $this->getMetadata();
                break;
            case 'login':
                $this->doLogin();
                break;
            case 'logout':
                $this->doLogout();
                break;
            case 'loggedout':
            case 'slo':
                $this->SLOHandler();
                break;
            case 'acs':
                $this->consumeAttributes();
                break;
            default:
        }
    }

    /**
     * @throws Saml2\Error
     */
    protected function initSAMLHandler()
    {
        $this->saml = new ClavisSAML('', $this->getSsoBinding(), $this->getSloBinding());
    }

    /**
     * @return mixed
     */
    public function getDefaultPage()
    {
        return $this->DefaultPage;
    }

    /**
     * @throws Saml2\Error
     */
    protected function getMetadata(): void
    {
        $metadata = $this->saml->getMetadata($errors);

        if (empty($errors)) {
            header('Content-Type: text/xml');
            echo $metadata;
            die();
        }

        error_log(print_r($errors, true));
        throw new Saml2\Error(
            'Invalid SP metadata: ' . implode(', ', $errors),
            Saml2\Error::METADATA_SP_INVALID
        );
    }

    /**
     * @param null $returnTo
     */
    protected function doLogin($returnTo = null)
    {
        $this->saml->login($returnTo);
    }

    /**
     * @return bool
     */
    protected function doLogout()
    {
        $pid = filter_var($_REQUEST['patronID'], FILTER_SANITIZE_NUMBER_INT);
        $samlUK = filter_var($_REQUEST['key'], FILTER_SANITIZE_STRING);

        if (!$this->saml->logout($pid, true, $samlUK)) {
            $returnTo = $this->saml->getSamlSettings()->getBaseURL();
            $this->getResponse()->redirect($returnTo);
        }

        $data = $this->saml->getSAMLAuthData();
        $data['samlUserKey'] = $samlUK;
        $patron = PatronQuery::create()->findOneByPatronId($pid);
        $this->onLogoutSuccess($patron, $data);
        return true;
    }

    /**
     *
     */
    protected function SLOHandler()
    {
        $requestID = null;
        if (isset($_SESSION) && isset($_SESSION['LogoutRequestID'])) {
            $requestID = $_SESSION['LogoutRequestID'];
        }

        // -------------------------------------------------------------------------------------------------------------
        $errors = $this->saml->processSingleLogoutInstance($requestID, function ($logoutRequestResponse) {
            $this->sloCallback($logoutRequestResponse);
        });
        // -------------------------------------------------------------------------------------------------------------

        // Print out errors, if debug is enabled
        // -------------------------------------------------------------------------------------------------------------
        if ($this->saml->getSamlSettings()->isDebugActive() && count($errors) > 0) {
            error_log("PRINT SLO ERRORS" . print_r($errors, true));
        }
    }

    /**
     * @throws Exception
     */
    protected function consumeAttributes()
    {
        $isAuthenticated = $this->saml->isAuthenticated($errors);

        // Print out errors, if debug is enabled
        // -------------------------------------------------------------------------------------------------------------
        if ($this->saml->getSamlSettings()->isDebugActive() && count($errors) > 0) {
            echo print_r($errors, true);
            exit();
        }

        // Login on the IDP failed
        // -------------------------------------------------------------------------------------------------------------
        if (!$isAuthenticated) {
            if (is_callable('ClavisSSOAuthenticator::onIdpAuthenticationFail')) {
                ClavisSSOAuthenticator::onIdpAuthenticationFail();
            } else {
                $this->onIdpAuthenticationFail();
            }
        }
        $patronAuthData = ClavisSSOAuthenticator::authenticate($this->saml->getSamlAttributes(), $this->saml->getLocalSettings());

        // Patron not found on the local backend
        // -------------------------------------------------------------------------------------------------------------
        if (!$patronAuthData['isAuthenticated']) {
            if (is_callable('ClavisSSOAuthenticator::onLocalAuthenticationFail')) {
                ClavisSSOAuthenticator::onLocalAuthenticationFail();
            } else {
                $this->onLocalAuthenticationFail();
            }
        }

        // Patron identification succeeded
        // -------------------------------------------------------------------------------------------------------------
        $samlAuthData = $this->saml->getSAMLAuthData();
        $samlAuthData['samlRequestID'] = $this->saml->getRequestID();

        $ok = $this->doLocalLogin($patronAuthData, $samlAuthData);
        if ($ok) {
            $this->onSuccessfulLogin($patronAuthData, $samlAuthData);
        } else {
            $this->onLoginError($patronAuthData, $samlAuthData);
        }
    }

    /**
     * @return false|mixed
     */
    protected function loadLocalAuthenticator()
    {
        $site_auth_module = $this->saml->getSsoDir() . '/sso-authenticator.php';
        $load_ok = file_exists($site_auth_module) ? require $site_auth_module : false;
        return $load_ok;
    }

    // -------------------------------------------------------------------------------------------------------------
    // Methods to be overridden by subclasses to customize the login process
    // -------------------------------------------------------------------------------------------------------------
    /**
     * @param $patronAuthData
     * @param $samlAuthData
     * @throws PropelException
     */
    protected function onSuccessfulLogin($patronAuthData, $samlAuthData)
    {
        $this->saml->saveAuthData($samlAuthData, $patronAuthData['patron'], true);
        $this->getResponse()->redirect($this->getRequest()->constructUrl('MyHomePage.Home', []));
    }

    protected function onLoginError($patronAuthData, $samlAuthData)
    {
        $pid = null;
        $patron = $patronAuthData['patron'];
        
        if ($patron instanceof Patron) {
            $pid = $patron->getPatronId();
        }
        $this->saml::saveFailedLoginEvent($samlAuthData['samlNameId'], $samlAuthData['samlSessionIndex'], $samlAuthData['autologin_token'], $pid);
        $this->getResponse()->redirect($this->getRequest()->constructUrl('MyHomePage.Home', []));

    }

    protected function doLocalLogin(&$patronAuthData, &$samlAuthData): bool
    {
        $apikey = $this->getApplication()->getRequest()->getServiceParameter();
        $clavis_auth = Prado::getApplication()->getModule('auth');
        $clavis_auth->login($patronAuthData['username'], $apikey);
        return true;
    }

    /**
     * @param $patron
     * @param $data
     * @throws PropelException
     */
    protected function onLogoutSuccess($patron, $data)
    {
        $this->saml::saveLogoutEvent($data['samlNameId'], $data['samlSessionIndex'], $data['sid'], $patron->getPatronId(), true);
    }

    /**
     *
     */
    protected function onIdpAuthenticationFail()
    {
        $settings = $this->saml->getLocalSettings();
        $error_url = $settings['error_url'] ??
            ClavisParamPeer::getParam('CLAVISPARAM', 'BaseUrl') . "index.php?page=Login&error_message=Errore di autenticazione con IdP";

        $this->getResponse()->redirect($error_url);
        exit();
    }

    /**
     *
     */
    protected function onLocalAuthenticationFail()
    {
        $settings = $this->saml->getLocalSettings();
        $error_url = $settings['error_url'] ??
            ClavisParamPeer::getParam('CLAVISPARAM', 'BaseUrl') . "index.php?page=Login&error_message=Utente non abilitato o presente in Clavis";
        $this->getResponse()->redirect($error_url);
        exit();
    }
    // -----------------------------------------------------------------------------------------------------------------

    /**
     * @return mixed
     */
    public function getSloBinding()
    {
        return $this->sloBinding ?? Constants::BINDING_HTTP_REDIRECT;
    }

    /**
     * @return mixed
     */
    public function getSsoBinding()
    {
        return $this->ssoBinding ?? Constants::BINDING_HTTP_REDIRECT;
    }

    /**
     *
     * @throws Exception
     */
    protected function sloCallback($logoutRequestResponse)
    {
        $returnTo = $this->getSamlSettings()->getBaseURL();
        $this->getApplication()->getModule('auth')->logout();
        $this->getResponse()->redirect($returnTo);
    }

}
