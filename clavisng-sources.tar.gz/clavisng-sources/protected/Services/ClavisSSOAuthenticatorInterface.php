<?php

interface ClavisSSOAuthenticatorInterface
{
    public static function authenticate($attributes = []);

    public static function onAuthenticationSuccess($authData = []);

    public static function onLocalAuthenticationFail();

    public static function onIdpAuthenticationFail();

    public static function onLogoutSuccess();

    public static function doLogout();

}