<?php

/*
 * Questo modulo permette l'autenticazione via SSO (Single Sign On) tramite il protocollo SAML2.0 di SPID.
 * Per funzionare correttamente deve essere modificato il file clavis-application.xml del site
 * su cui vogliamo abilitare questa funzionalita', verificando che nelle sezioni paths, module, e
 * services vi siano le direttive indicate qui in seguito:
 *
  <paths>
          <alias id="SPID" path="./spid/"/>
  </paths>

  <module id="friendly-url" class="System.Web.TUrlMapping" EnableCustomUrl="true">
		<url ServiceID="spid" ServiceParameter="supermegakiavesegreta!" pattern="spid/{action}" parameters.action="(\w+)?"/>
  </module>

  <services>
        <service id="spid" class="Application.Services.ClavisSPID" DefaultPage="MyHomePage.Home"/>
  </services>

 * Nella cartella sites/nomesito/spid inoltre e' necessario vi sia il file di configurazione
 * settings.php o un link ai file posti sotto vcs e presenti nella cartella
 * contrib/sso-settings/nomesito/settings.php.
 *
 * 2) Nella cartella sites/nomesito/spid/certs e' necessario vi sia il certificato e la chiave privata per
 * firmare e criptare i messaggi nel caso la comunicazione con l'idp lo richieda.
 * Devono avere questi nomi: sp.crt e sp.key rispettivamente il certificato x509 e la chiave privata.
 * Sono generati dal comando getCerts.sh che si trova nella cartella contrib/sso-bin che e' un wrapper per
 * questo comando:
 * sudo ./sso-keygen.sh -s nomesito -h nost.ngrok.io -e https://host.ngrok.io/sso/ "$@"
 * dove con l'opzione -s passo il nome del sito clavisng, con -h l'host su cui generare il certificato e con -e
 * l'entityID del ServiceProvider.
 */

/**
 * Class ClavisSPID
 */
class ClavisSPID extends TService
{
    private $sp;
    private $settings;
    private $extra_settings;

    public function run()
    {
        $this->settings = $this->loadSiteSettings();
        $this->extra_settings = $this->loadSiteSettings(true);

        $this->sp = new Italia\Spid\Sp($this->settings, null);
        $action = strtolower($this->getRequest()->itemAt("action"));

        switch ($action) {
            case 'metadata':
                $this->getMetadata();
                break;
            case 'login':
                $this->doLogin();
                break;
            case 'logout':
                $this->doLogout();
                break;
            case 'slo':
                $this->slo();
                break;
            case 'acs':
                $this->parseAttributes();
                break;
            default:
        }
    }

    private function loadSiteSettings($extra = false)
    {
        $ssoDir = self::getSpidConfDir();
        $settings = $ssoDir . '/settings.php';
        $advanced_conf_file = $ssoDir . '/advanced_settings.php';

        if ($extra) {
            $settings = file_exists($advanced_conf_file) ? include $advanced_conf_file : false;
        } else {
            $settings = file_exists($settings) ? include $settings : false;
        }

        return $settings;
    }

    private function getFailedLoginErrorUrl($error_message = ''): string
    {
        $baseUrl = ClavisParamPeer::getParam('CLAVISPARAM', 'BaseUrl');
        if ($error_message) {
            $em = htmlentities(Prado::localize($error_message));
            return $baseUrl . "index.php?page=Login&error_message=$em";
        }
        return $baseUrl . "index.php?page=Login";
    }

    /**
     * @return false|string
     */
    protected static function getSpidConfDir()
    {
        $ssoDir = realpath(Prado::getPathOfNamespace('SPID'));
        if (!is_dir($ssoDir) && !mkdir($ssoDir, '0777', true) && !is_dir($ssoDir)) {
            throw new RuntimeException(sprintf('Directory " % s" was not created', $ssoDir));
        }
        return $ssoDir;
    }

    public function getMetadata()
    {
        header('Content-type: text/xml');
        echo $this->sp->getSPMetadata();
        die();
    }

    public function doLogin()
    {
        if (isset($_GET) && isset($_GET['idp'])) {
            $idp = $_GET['idp'];
        } else {
            $this->getResponse()->redirect($this->getFailedLoginErrorUrl("IDP non riconosciuto"));
        }

        $spid_level = $this->extra_settings['spid_auth_level'];
        if ($spid_level >= 1 && $spid_level <= 3) {
            $level = $spid_level;
        } else {
            $this->getResponse()->redirect($this->getFailedLoginErrorUrl("Livello di autenticazione SPID errato"));
        }

        // Login params: $idpName, $assertId, $attrId, $level, $redirectTo = null, $shouldRedirect = true
        if (!$url = $this->sp->login($idp, 0, 0, $level, null, true)) {
            $this->getResponse()->redirect($this->getRequest()->constructUrl('MyHomePage.Home', []));
        } else {
            $this->getResponse()->redirect($url);
        }
    }

    public function doLogout()
    {
        if (!$url = $this->sp->logout(0)) {
            $this->getResponse()->redirect($this->getRequest()->constructUrl('MyHomePage.Home', []));
        } else {
            $this->getResponse()->redirect($url);
        }
    }

    public function slo()
    {
        if ($this->sp->isAuthenticated()) {
            $this->getResponse()->redirect($this->getRequest()->constructUrl('MyHomePage.Home', []));
        } else {
            $this->getResponse()->redirect($this->getFailedLoginErrorUrl());
        }
    }

    public function parseAttributes()
    {
        try {
            if ($this->sp->isAuthenticated()) {
                $site_auth_module = $this->getSpidConfDir() . '/sso-authenticator.php';
                $load_ok = file_exists($site_auth_module) && require_once $site_auth_module;
                if ($load_ok) {
                    $attributes = $this->sp->getAttributes();
                    $authData = ClavisSSOAuthenticator::authenticate($attributes);

                    if ($authData['isAuthenticated']) {
                        $apikey = $this->getApplication()->getRequest()->getServiceParameter();
                        $clavis_auth = Prado::getApplication()->getModule('auth');
                        $clavis_auth->login($authData['username'], $apikey);
                        $this->getResponse()->redirect($this->getRequest()->constructUrl('MyHomePage.Home', []));
                        return true;
                    } else {
                        $error_message = 'Login SPID effettuato, ma utente non riconosciuto in Clavis.';
                        $_SESSION['idpName'] = null;
                        $_SESSION['spidSession']['idp'] = null;
                    }
                } else {
                    $error_message = 'Modulo di autenticazione non trovato';
                }
            } else {
                $error_message = 'Autenticazione SPID fallita';
            }

        } catch (Exception $e) {
            $error_message = $e->getMessage() ?? '';
        }

        $this->getResponse()->redirect($this->getFailedLoginErrorUrl($error_message));
        return false;
    }
}