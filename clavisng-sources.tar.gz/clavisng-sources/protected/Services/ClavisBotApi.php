<?php

/**
 * ClavisBotApi class file.
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 * For Commercial Licenses and support please contact Comperio.
 */

class ClavisBotApi extends TService
{
    const SOLR_MAX_RESULTS = 10;

    protected $reply = [];

    /** @var Librarian $librarian */
    protected $librarian;
    protected $botsecret;

    /**
     * @throws PropelException
     */
    public function run()
    {


        $this->botsecret = null;
        if (Prado::getApplication()->getModule('chatbot') !== null) {
            $this->botsecret = Prado::getApplication()->getModule('chatbot')->getApiKey();
        }

        $this->reply['REQUEST'] = [
            'ID' => $this->getApplication()->getID(),
            'REQUESTMETHOD' => $_SERVER['REQUEST_METHOD'],
            'USERHOST' => $this->getRequest()->getUserHostAddress(),
            'APIOBJECT' => $this->getRequest()->itemAt('object'),
            'APIMETHOD' => $this->getRequest()->itemAt('method'),
            'APIID' => $this->getRequest()->itemAt('id'),
            'XSIGNATURE' => @$_SERVER['HTTP_X_CLAVIS_SIGNATURE'],
            'XUSERNAME' => @$_SERVER['HTTP_X_CLAVIS_USERNAME'],
            'XPASSWORD' => @$_SERVER['HTTP_X_CLAVIS_PASSWORD'],
            'XLIBRARY' => @$_SERVER['HTTP_X_CLAVIS_LIBRARY'],
            'XSEARCH' => @$_SERVER['HTTP_X_CLAVIS_SEARCH'],
            "XTOKEN" => @$_SERVER['HTTP_X_CLAVIS_TOKEN'],
            'REQSTART' => microtime(true)
        ];

        // username and password based authentication
        // -------------------------------------------------------------------------------------------------------------
        $librarian = LibrarianQuery::create()->findOneByUsername(@$_SERVER['HTTP_X_CLAVIS_USERNAME']);
        if ($librarian instanceof Librarian) {
            $crypt = $this->getApplication()->getModule('crypt');
            /** @noinspection TypeUnsafeComparisonInspection */
            if ($librarian->getActivationStatus() == 1 && $crypt->LibrarianVerify(@$_SERVER['HTTP_X_CLAVIS_PASSWORD'], $librarian->getSecret())) {
                $this->librarian = $librarian;
            }
        }

        // token based authentication
        // -------------------------------------------------------------------------------------------------------------
        if (!$this->librarian instanceof Librarian) {
            $apiToken = ApiTokenQuery::create()
                ->filterByToken(@$_SERVER['HTTP_X_CLAVIS_TOKEN'])
                ->filterByDomain('LIBRARIAN_BOT')
                ->where('(ApiToken.expires > ? OR ApiToken.expires IS NULL)', date('Y-m-d 00:00:00'))
                ->findOne();

            if ($apiToken instanceof ApiToken) {
                Prado::log('API TOKEN FOUND.... finding the relative librarian', TLogger::ALERT, 'SOAP');
                $librarian = LibrarianQuery::create()->filterByApiTokenRelatedByLibrarianId($apiToken)->findOne();
                if (($librarian instanceof Librarian) && ($librarian->getActivationStatus() == 1)) {
                    $this->librarian = $librarian;
                }
            }
        }
        // -------------------------------------------------------------------------------------------------------------

        $reqMethod = ucfirst($_SERVER['REQUEST_METHOD']);
        $apiObject = ucfirst($this->getRequest()->itemAt('object'));
        $apiMethod = ucfirst($this->getRequest()->itemAt('method'));
        $methodToCall = "{$reqMethod}{$apiObject}{$apiMethod}";

        if (extension_loaded('newrelic')) {
            newrelic_set_appname('ClavisNG - ' . $this->getApplication()->getID());
            newrelic_name_transaction($methodToCall);
            foreach ($this->reply['REQUEST'] as $k => $v) {
                if ($k !== 'ID') {
                    newrelic_add_custom_parameter($k, $v);
                }
            }
        }

        $replyOk = true;

        // -------------------------------------------------------------------------------------------------------------
        // Unauthenticated user
        // -------------------------------------------------------------------------------------------------------------
        if (!($this->librarian instanceof Librarian)) {
            Prado::log('REST API Librarian INVALID!!!', TLogger::ALERT, 'SOAP');

            $this->librarian = null;
            $this->reply['REPLY']['STATUS'] = 'KO';
            $this->reply['REPLY']['ERRORCODE'] = 'AUTHERR';
            $this->reply['REPLY']['ERRORINFO'] = 'Non autorizzato';
            $this->sendReply();
            return true;
        }

        // -------------------------------------------------------------------------------------------------------------
        // Call specified method if exists
        // -------------------------------------------------------------------------------------------------------------
        if (method_exists($this, $methodToCall)) {
            $replyOk = $this->$methodToCall();
        } else {
            Prado::log(__METHOD__ . " {$methodToCall} not exist. wrong url?");
            $this->reply['REPLY'] = ['STATUS' => 'KO', 'ERRORINFO' => " {$methodToCall}: method not implemented"];
        }

        if ($replyOk) {
            $this->sendReply();
        }
    }

    /**
     *
     */
    private function sendReply()
    {
        ini_set('memory_limit', '1024M');
        $this->reply['REQUEST']['REQEND'] = microtime(true);
        $this->reply['REQUEST']['REQTIME'] = $this->reply['REQUEST']['REQEND'] - $this->reply['REQUEST']['REQSTART'];

        $response = $this->getResponse();
        $response->setCharset('UTF-8');

        switch ($this->getRequest()->itemAt('output')) {
            case 'raw':
                $response->setCacheControl('nocache');
                $mime_type = Clavis::mime_content_type($this->reply['REPLY']['RAW_FILENAME']);
                $response->writeFile('turnstile.db',
                    file_get_contents($this->reply['REPLY']['RAW_FILENAME']),
                    $mime_type,
                    ['Content-type: ' . $mime_type],
                    false);
                break;

            case 'phps':
                $response->setContentType('application/phps');
                $response->write(serialize($this->reply));
                break;

            case 'xml':
                $response->setContentType('text/xml');
                $response->write($this->array2xml($this->reply));
                break;

            case 'json':
            default:
                $response->setContentType('application/json');
                $response->write(TJavaScript::jsonEncode($this->reply));
                break;
        }
    }

    /**
     * @param      $array
     * @param bool $xml
     * @return mixed
     */
    private function array2xml($array, $xml = false)
    {
        if ($xml === false) {
            $xml = new SimpleXMLElement('<root/>');
        }
        foreach ($array as $key => $value) {
            if (is_array($value)) {
                $this->array2xml($value, $xml->addChild($key));
            } else {
                $xml->addChild($key, $value);
            }
        }
        return $xml->asXML();
    }

    /**
     * ritorna il patron con id passato come parametro
     * @throws PropelException`
     */
    private function GetPatronId()
    {
        return $this->GetPatronList($this->getRequest()->itemAt('id'));
    }

    /**
     * ritorna una lista di patron che hanno un'identificativo uguale a quello indicato.
     * @param string $id
     * @return bool
     * @throws PropelException
     */
    private function GetPatronList($id = '')
    {
        // Authorization check
        // -------------------------------------------------------------------------------------------------------------
        if ($this->librarian == null) {
            Prado::log(__METHOD__ . ' AUTH ERR', TLogger::INFO, 'SOAP');
            $this->reply['REPLY']['STATUS'] = 'KO';
            $this->reply['REPLY']['ERRORCODE'] = 'AUTHERR';
            $this->reply['REPLY']['ERRORINFO'] = 'Non autorizzato';
            return true;
        }

        // Be optimistic about this search result.
        // -------------------------------------------------------------------------------------------------------------
        $this->reply['REPLY']['STATUS'] = 'OK';

        // Get the search field
        // -------------------------------------------------------------------------------------------------------------
        $searchValue = $this->getRequest()->itemAt('id');

        // Get the data
        // -------------------------------------------------------------------------------------------------------------
        if (strlen($id) > 0) {
            $patrons = $this->_search_id_callback($searchValue);
        } else {
            $patrons = $this->_search_multi_callback($searchValue);
        }

        // Format the result to send back.
        // -------------------------------------------------------------------------------------------------------------
        $p = [];
        if (isset($patrons) && count($patrons) > 0) {
            $p = $this->fetchPatronData($patrons);
        } else {
            Prado::log(__METHOD__ . " SEARCHVALUE: [{$searchValue}] NOT FOUND", TLogger::INFO, 'SOAP');
            $this->reply['REPLY']['STATUS'] = 'KO';
            $this->reply['REPLY']['ERRORCODE'] = 'NOTFOUND';
            $this->reply['REPLY']['ERRORINFO'] = 'Chiave di ricerca non valida';
        }

        $this->reply['REPLY']['RESULT'] = ['patrons' => $p];
        return true;
    }

    /**
     * @return bool
     * @throws PropelException
     */
    private function GetPatronSearch()
    {
        // Authorization check
        // -------------------------------------------------------------------------------------------------------------
        if ($this->librarian == null) {
            Prado::log(__METHOD__ . ' AUTH ERR', TLogger::INFO, 'SOAP');
            $this->reply['REPLY']['STATUS'] = 'KO';
            $this->reply['REPLY']['ERRORCODE'] = 'AUTHERR';
            $this->reply['REPLY']['ERRORINFO'] = 'Non autorizzato';
            return true;
        }

        $this->reply['REPLY']['STATUS'] = 'KO';
        $searchValue = $this->getRequest()->itemAt('id');
        $searchType = $this->getRequest()->itemAt('type');

        $p = [];

        switch ($searchType) {
            case 'id':
                $patrons = $this->_search_id_callback($searchValue);
                break;
            case 'barcode':
                $patrons = $this->_search_barcode_callback($searchValue);
                break;
            case 'card':
                $patrons = $this->_search_cardid_callback($searchValue);
                break;
            case 'nid':
                $patrons = $this->_search_nid_callback($searchValue);
                break;
        }

        if (!empty($patrons)) {
            $this->reply['REPLY']['STATUS'] = 'OK';
            $p = $this->fetchPatronData($patrons);
        } else {
            $this->reply['REPLY']['ERRORCODE'] = 'NO_VALID_DATA_FOUND';
            $this->reply['REPLY']['ERRORINFO'] = 'Identificativo utente non valido';
        }

        $this->reply['REPLY']['RESULT'] = ['patrons' => $p];
        return true;
    }

    /**
     * @param $patrons
     * @return array
     * @throws PropelException
     */
    private function fetchPatronData($patrons)
    {
        foreach ($patrons as $patron) {

            $contact = ContactQuery::create()
                ->filterByPatronId($patron->getPatronId())
                ->filterByContactType(ContactPeer::TYPE_MOBILE)
                ->findOne();

            $mobile = '';
            if ($contact instanceof Contact) {
                $mobile = $contact->getContactValue();
            }

            $p[] = [
                'patron_id' => $patron->getPatronId(),
                'library_id' => $patron->getPreferredLibraryId(),
                'consortia_id' => $patron->getPreferredLibrary()->getConsortiaId(),
                'first_name' => ucfirst(trim($patron->getName())),
                'last_name' => ucfirst(trim($patron->getLastname())),
                'status' => $patron->getPatronStatus(),
                'status_string' => $patron->getPatronStatusString(),
                'custom2' => $patron->getCustom2(),
                'mail' => $patron->getEmail2String(),
                'birthday' => $patron->getBirthDate(),
                'barcode' => $patron->getBarcode(),
                'card' => $patron->getCardCode(),
                'card_expires' => $patron->getCardExpire(),
                'loan_class' => $patron->getLoanClass(),
                'mobile' => $mobile,
                'loans' => $this->_loanSummary($patron),
            ];
        }

        return $p;
    }

    /**
     * @param $patron_id
     * @return mixed
     */
    private function _search_id_callback($patron_id)
    {
        $q = PatronQuery::create()
            ->filterByPrimaryKey($patron_id)
            ->find()
            ->getData();

        return $q;
    }

    /**
     * @param $searchValue
     * @return array
     */
    private function _search_multi_callback($searchValue)
    {
        $searchFor = explode('|', $this->reply['REQUEST']['XSEARCH']);

        foreach ($searchFor as $key => $value) {
            $function = '_search_' . $value . '_callback';
            Prado::log(__METHOD__ . " calls function [{$function}] with param $searchValue", TLogger::INFO, 'SOAP');
            $patrons = $this->$function($searchValue);

            if (count($patrons) > 0) {
                return $patrons;
            }
        }
        return [];
    }

    /**
     * Returns a loan summary, given the patron object.
     * @param Patron $patron
     * @return array
     * @throws PropelException
     */
    private function _loanSummary($patron)
    {
        if (!($patron instanceof Patron)) {
            return [];
        }
        /** @var $lm ClavisLoanManager */
        $lm = Prado::getApplication()->getModule('loan');
        /** @var  $loans LoanQuery */
        $loans = $patron->getItems();

        $c = (new Criteria())->add(ItemRequestPeer::REQUEST_STATUS, ItemRequestPeer::STATUS_PENDING);

        $ret = [];

        // prestiti
        // -------------------------------------------------------------------------------------------------------------
        foreach ($loans as $l) {
            $due_date = (int)$l->getDueDate('U');
            $renewWindowFrom = time() - ClavisParamPeer::getParam('LOANRENEWALTIME', 'FROM');
            $renewWindowUntil = time() + ClavisParamPeer::getParam('LOANRENEWALTIME', 'UNTIL');
            $renewable = (bool)($lm->IsLoanRenewable($l) === ClavisLoanManager::OK);

            $isexpiring = (bool)(
                $due_date > time() &&
                $due_date < time() + ClavisParamPeer::getParam('LOANRENEWALTIME', 'FROM')
            );

            // -- ready -----------------------------------------------------------
            $isReady = $l->getLoanStatus() == ItemPeer::LOANSTATUS_READYFORLOAN;
            // -- transit ---------------------------------------------------------
            $isInTransit = $l->getLoanStatus() == ItemPeer::LOANSTATUS_INTRANSIT
                || $l->getLoanStatus() == ItemPeer::LOANSTATUS_READYFORTRANSIT;
            // -- late ------------------------------------------------------------
            $isLate = $lm->isLoanLate($l) == ClavisLoanManager::LOAN_ISLATE
                && $l->getLoanStatus() == ItemPeer::LOANSTATUS_INLOAN;
            // -- renewable --------------------------------------------------------
            $isRenewable = $renewable && ($due_date >= $renewWindowFrom && $due_date <= $renewWindowUntil);
            $itemTitle = $l->getTrimmedTitle(20);

            $title = ($l->getManifestation() instanceof Manifestation) ?
                $l->getManifestation()->getTrimmedTitle(20, '') :
                $itemTitle;

            $item = (object)[
                'title' => $title,
                'dueDate' => $due_date,
                'isExpiring' => $isexpiring,
                'isRenewable' => $isRenewable,
                'isLate' => $isLate,
            ];

            $status = '';
            if ($isReady) {
                $status = 'ready';
            }

            if ($isInTransit) {
                $status = 'transit';
            }

            if ($isLate) {
                $status = 'late';
            }

            if ($isRenewable) {
                $status = 'renewable';
            }

            if ($status !== '') {
                $ret[$status]['count']++;
                $ret[$status]['items'][] = $item;
            }

            $ret['loaned']['count']++;
            $ret['loaned']['items'][] = $item;
        }

        // prenotazioni in attesa
        // -------------------------------------------------------------------------------------------------------------
        $reqs = $patron->getItemRequests($c);
        foreach ($reqs as $r) {
            $ret['pending']['count']++;
            $title = ($r->getManifestation() instanceof Manifestation) ? $r->getManifestation()->getTrimmedTitle(20, '') : $r->getItem()->getTrimmedTitle(20);
            $pos = $r->getQueuePosition();
            $ret['pending']['items'][] = (object)['title' => $title, 'position' => $pos];
        }
        return $ret;
    }

    /**
     * Aggiorna le informazioni di contatto per il patron indicato, aggiungendo, aggiornando o eliminando il canale BOT
     */
    private function PostPatronContact()
    {
        if ($this->librarian == null) {
            Prado::log(__METHOD__ . ' AUTH ERR', TLogger::INFO, 'SOAP');
            $this->reply['REPLY']['STATUS'] = 'KO';
            $this->reply['REPLY']['ERRORCODE'] = 'AUTHERR';
            $this->reply['REPLY']['ERRORINFO'] = 'Non autorizzato';
            return true;
        }

        $action = $this->getRequest()->itemAt('id');

        $user_id = $this->getRequest()->itemAt('user_id');
        $patron_id = $this->getRequest()->itemAt('patron_id');
        $signature = $this->getRequest()->itemAt('signature');

        $patron = PatronQuery::create()->findPk((int)$patron_id);
        if ($patron instanceof Patron && $signature == md5(crypt($patron_id, $this->botsecret))) {

            $ct = ContactQuery::create()
                ->filterByContactType('L')
                ->filterByPatron($patron)
                ->findOne();

            if ($action === 'delete') {
                if (null != $ct) {
                    $ct->delete();
                }

            } else if ($action === 'add') {
                if ($ct == null) {
                    $ct = new Contact();
                }

                $ct->setPatron($patron);
                $ct->setContactValue($user_id); //mongo id for the current user
                $ct->setContactType('L');
                $ct->setContactNote('Creato da Bot');
                $ct->save();
            }

            $this->reply['REPLY']['STATUS'] = 'OK';
            $this->reply['REPLY']['RESULT']['Status'] = 'OK';
            return true;

        } else {
            $this->reply['REPLY']['STATUS'] = 'KO';
            $this->reply['REPLY']['RESULT']['Status'] = 'ERR';
            $this->reply['REPLY']['ERRORINFO'] = 'EXCEPTION {PATRON ID ' . $patron_id . 'NOT FOUND}';
            Prado::log(__METHOD__ . ' ' . __LINE__ . ' EXCEPTION:  PATRON ID ' . $patron_id . ' NOT FOUND', TLogger::INFO, 'SOAP');
            return false;
        }
    }

    /**
     * Crea dal bot un nuovo utente all'interno di clavis. Se esiste gia' un utente con mail o cellulare
     * uguale a quello indicato ritorna l'identificativo del patron corrispondente
     * @throws Exception
     */
    private function PostPatronAdd()
    {
        if ($this->librarian == null) {
            Prado::log(__METHOD__ . ' AUTH ERR', TLogger::INFO, 'SOAP');
            $this->reply['REPLY']['STATUS'] = 'KO';
            $this->reply['REPLY']['ERRORCODE'] = 'AUTHERR';
            $this->reply['REPLY']['ERRORINFO'] = 'Non autorizzato';
            return true;
        }

        $user = (object)$this->getRequest()->itemAt('data');
        $registration_library_id = $this->getRequest()->itemAt('libraryId');
        $loan_class = $this->getRequest()->itemAt('loanClass');
        $patron_status = $this->getRequest()->itemAt('patronStatus');
        $signature = $this->getRequest()->itemAt('signature');

//		$librarian_id = $this->getRequest()->itemAt('librarian_id');
//		$token = urldecode($this->getRequest()->itemAt('token'));
//		$tokenEsists = $this->librarianHasToken($librarian_id, $token);

        // comperio bot with authentications provided locally by every bot configuration.
        $scheck = md5(crypt("{$user->birth_year}{$user->birth_month}{$user->birth_day}", $this->botsecret));
        // librarianbot with authentication provided
        $apiToken = ApiTokenQuery::create()->filterByToken(@$_SERVER['HTTP_X_CLAVIS_TOKEN'])->findOne();
        if ($apiToken) {
            $tcheck = md5(crypt("{$user->birth_year}{$user->birth_month}{$user->birth_day}", $apiToken->getToken()));
        }
//		Prado::log(__METHOD__ . ' Controllo signature ' . "{$signature} === {$scheck}", TLogger::INFO, 'SOAP');
        if ($signature === $scheck || $signature === $tcheck) {
            // ---------------------------------------------------------------------------------------------------------
            // controllo se ho già patron con gli elementi indicati.
            // ---------------------------------------------------------------------------------------------------------
            $mails = $this->_search_mail_callback($user->email);
            $mobiles = $this->_search_mobile_callback($user->mobile);

            /** @var PatronQuery $found_existing_patron */
            $found_existing_patron = null;
            if (isset($user->email) && (count($mails) === 1)) {
                $found_existing_patron = $mails[0];
            }

            if (isset($user->mobile) && (count($mobiles) === 1)) {
                $found_existing_patron = $mobiles[0];
            }

            Prado::log(__METHOD__ . "cerco utenti con mail: $user->email o telefono: $user->mobile", TLogger::INFO, 'SOAP');
            if ((null !== $found_existing_patron) && $found_existing_patron->getPatronId() > 0) {
                Prado::log(__METHOD__ . ' ' . $found_existing_patron->getPatronId() . ' onboarding ha trovato utente esistente da collegare al BOT', TLogger::INFO, 'SOAP');
                $this->reply['REPLY']['STATUS'] = 'OK';
                $this->reply['REPLY']['RESULT']['Status'] = 'OK';
                $this->reply['REPLY']['RESULT']['patron_id'] = $found_existing_patron->getPatronId();
                $this->reply['REPLY']['ERRORINFO'] = "L'utente e' stato agganciato al patron gia' esistente nel sistema con identificativo " . $found_existing_patron->getPatronId();
                return true;
            }

            // Ho trovato utenti multipli con quel numero di telefono o con quella mail
            // ---------------------------------------------------------------------------------------------------------
            if ((isset($user->email) && (count($mails) > 1)) || (isset($user->mobile) && (count($mobiles) > 1))) {
                $this->reply['REPLY']['STATUS'] = 'KO';
                $this->reply['REPLY']['RESULT']['Status'] = 'ERR';
                $this->reply['REPLY']['RESULT']['patron_id'] = -1;
                $this->reply['REPLY']['ERRORINFO'] = 'Trovati più utenti associati alla mail ' . $user->email . ' o con telefono ' . $user->mobile . '. Utente non creato';
                Prado::log(__METHOD__ . ' onboarding ha trovato più di un utente da collegare al BOT con telefono o mail uguali a ' . $user->email . ' ' . $user->mobile, TLogger::INFO, 'SOAP');
                return true;
            }

            // Inserisco patron con i dati forniti.
            // ---------------------------------------------------------------------------------------------------------
            try {
                $loan_classes = array_keys(LookupValuePeer::getLookupClassValues('PATRONLOANCLASS'));
                if (!in_array($loan_class, $loan_classes, true)) {
                    $loan_class = $loan_classes[0];
                }

                $patron_statuses = array_keys(LookupValuePeer::getLookupClassValues('PATRONSTATE'));
                if (!in_array($patron_status, $patron_statuses, true)) {
                    $patron_status = PatronPeer::STATUS_INCOMPLETE;
                }

                $d = DateTime::createFromFormat('Ymd', $user->ymdDate);

                $p = new Patron();
                $p->setName($user->first_name);
                $p->setLastname($user->last_name);
                $p->setRegistrationLibraryId($registration_library_id);
                $p->setPreferredLibraryId($registration_library_id);
                $p->setPatronStatus($patron_status);
                $p->setBirthDate($d);
                $p->setLoanClass($loan_class);
                $p->setAccessNote('Utente creato da BOT');
                $p->setOpacEnable(0);

                $address = new Address();
                $address->setPatron($p);
                $address->setStreet($user->street);
                $address->setCity($user->city);
                $address->setCountry('Italia');

                $p->save();
                $address->save();

                if (isset($user->email)) {
                    $c = new Contact();
                    $c->setPatron($p);
                    $c->setContactType('E');
                    $c->setContactValue($user->email);
                    $c->save();
                }

                if (isset($user->mobile)) {
                    $c = new Contact();
                    $c->setPatron($p);
                    $c->setContactType('C');
                    $c->setContactValue($user->mobile);
                    $c->save();
                }

                $p->reload(true);

                Prado::log(__METHOD__ . ' ' . $p->getPatronId() . ' Creato nuovo utente da BOT', TLogger::INFO, 'SOAP');
                $this->reply['REPLY']['STATUS'] = 'OK';
                $this->reply['REPLY']['RESULT']['Status'] = 'OK';
                $this->reply['REPLY']['RESULT']['patron_id'] = $p->getPatronId();
                return true;
            } catch (PropelException $e) {
                $this->reply['REPLY']['STATUS'] = 'KO';
                $this->reply['REPLY']['RESULT']['Status'] = 'ERR';
                $this->reply['REPLY']['ERRORINFO'] = 'EXCEPTION ' . $e->getMessage();
                Prado::log(__METHOD__ . ' ' . __LINE__ . ' EXCEPTION: ' . $e->getMessage(), TLogger::INFO, 'SOAP');
                return false;
            }
        }
        return false;
    }

    /**
     * @param $searchValue
     * @return array
     */
    private function _search_mail_callback($searchValue)
    {
        if ($searchValue === '') {
            return [];
        }

        $q = PatronQuery::create()
            ->useContactQuery()
            ->filterByContactType(ContactPeer::TYPE_EMAIL)
            ->filterByContactValue($searchValue)
            ->endUse()
            ->limit(10)
            ->find()
            ->getData();

        return $q;
    }

    /**
     * @param $searchValue
     * @return array
     */
    private function _search_mobile_callback($searchValue)
    {
        $searchForMobile = function ($searchValue) {
            $results = [];

            if ($searchValue !== '') {
                $results = PatronQuery::create()
                    ->useContactQuery()
                    ->filterByContactType(ContactPeer::TYPE_MOBILE)
                    ->filterByContactValue($searchValue)
                    ->endUse()
                    ->limit(10)
                    ->find()
                    ->getData();
            }
            return $results;
        };

        $v1 = preg_replace('/[^\d+]/', '', $searchValue); // with international prefix (i.e. digit and + sign only)
        $v2 = preg_replace('/^\+\d{2}/', '', $searchValue); // without international prefix and allows everything else.

        $result_set1 = $searchForMobile($v1);
        $result_set2 = $searchForMobile($v2);

        return count($result_set1) > 0 ? $result_set1 : $result_set2;
    }

    /**
     * rinnova tutti i prestiti rinnovabili per il patron indicato
     */
    private function GetPatronRenew()
    {
        Prado::log('GetPatronRenew start', TLogger::INFO, 'SOAP');
        /** @var $lm ClavisLoanManager */
        $lm = Prado::getApplication()->getModule('loan');
        if ($this->librarian == null) {
            Prado::log('GetPatronStatus AUTH ERR', TLogger::INFO, 'SOAP');
            $this->reply['REPLY']['STATUS'] = 'KO';
            $this->reply['REPLY']['ERRORCODE'] = 'AUTHERR';
            $this->reply['REPLY']['ERRORINFO'] = 'Non autorizzato';
            return true;
        }

        $patronid = $this->getRequest()->itemAt('id');
        $patron = PatronQuery::create()->findOneByPatronId($patronid);

        if ($patron instanceof Patron) {
            Prado::log("GetPatronRenew OK ID:[{$patronid}]", TLogger::INFO, 'SOAP');
            $this->reply['REPLY']['STATUS'] = 'OK';
            $patronData = [
                'Name' => trim($patron->getName() . ' ' . $patron->getLastname()),
                'Status' => $patron->getPatronStatus(),
                'Email' => $patron->getEmail2String(),
                'BirthData' => $patron->getBirthDate(),
                'PatronId' => $patron->getPatronId(),
                'Barcode' => $patron->getBarcode(),
                'InLoan' => 0,
                'InTransit' => 0,
                'ReadyToLoan' => 0,
                'Late' => 0,
                'Loans' => [],
            ];

            $loans = $patron->getItems();

            foreach ($loans as $l) {

                $due_date = $l->getDueDate('U');
                $renewWindowFrom = time() - ClavisParamPeer::getParam('LOANRENEWALTIME', 'FROM');
                $renewWindowUntil = time() + ClavisParamPeer::getParam('LOANRENEWALTIME', 'UNTIL');
                if (($lm->IsLoanRenewable($l) == ClavisLoanManager::OK)
                    && $due_date >= $renewWindowFrom && $due_date <= $renewWindowUntil
                ) {
                    $renew = true;
                } else {
                    $renew = false;
                }

                if ($renew) {
                    $r = $lm->DoRenewLoan($l, $patron, null, null);
                    Prado::log('Renew ' . $l->getBarcode() . ' : ' . Prado::varDump($r), TLogger::INFO, 'SOAP');
                }

                $l->reload();
                $status = 'OK';
                $message = '';

                if ($l->getLoanStatus() == ItemPeer::LOANSTATUS_READYFORLOAN) {
                    $status = 'READY';
                    $message = 'Pronto al prestito';
                    $patronData['ReadyToLoan']++;
                } else if ($l->getLoanStatus() == ItemPeer::LOANSTATUS_INTRANSIT) {
                    $status = 'INTRANSIT';
                    $message = 'In Transito';
                    $patronData['InTransit']++;
                } else if ($lm->isLoanLate($l) == ClavisLoanManager::LOAN_ISLATE) {
                    $status = 'LATE';
                    $message = 'Scaduto';
                    $patronData['Late']++;

                }
                $patronData['InLoan']++;

                $patronData['Loans'][] = [
                    'Title' => $l->getTitle(),
                    'DueDate' => $l->getDueDate('%F'),
                    'LoanStatus' => $l->getLoanStatus(),
                    'Status' => $status,
                    'Message' => $message,
                    'Media' => $l->getItemMedia(),
                    'ItemId' => $l->getItemId(),
                    'ActualLibrary' => $l->getActualLibraryId(),
                    'LoanClass' => $l->getLoanClass(),
                    'Barcode' => $l->getBarcode(),
                    'Inventory' => $l->getCompleteInventoryNumber(),
                    'Collocation' => $l->getCollocationCombo(),
                    'Renewable' => (bool)($lm->IsLoanRenewable($l) == ClavisLoanManager::OK),
                    'Late' => (bool)($lm->isLoanLate($l) == ClavisLoanManager::LOAN_ISLATE),
                ];
            }

            $this->reply['REPLY']['RESULT'] = $patronData;
        } else {
            Prado::log("GetPatronStatus ID:[{$patronid}] NOT FOUND", TLogger::INFO, 'SOAP');
            $this->reply['REPLY']['STATUS'] = 'KO';
            $this->reply['REPLY']['ERRORCODE'] = 'NOTFOUND';
            $this->reply['REPLY']['ERRORINFO'] = 'ID sconosciuto';
        }

        return true;
    }

    /**
     * Rinnova il prestito per l'elemento indicato, se possibile.
     */
    private function PostItemRenew()
    {
        if ($this->librarian == null) {
            Prado::log(__METHOD__ . ' AUTH ERR', TLogger::INFO, 'SOAP');
            $this->reply['REPLY']['STATUS'] = 'KO';
            $this->reply['REPLY']['ERRORCODE'] = 'AUTHERR';
            $this->reply['REPLY']['ERRORINFO'] = 'Non autorizzato';
            return true;
        }

        $lm = Prado::getApplication()->getModule('loan');
        $item_id = $this->getRequest()->itemAt('item_id');
        $patron_id = $this->getRequest()->itemAt('patron_id');

        $patron = PatronQuery::create()->findOneByPatronId($patron_id);
        if (!$patron instanceof Patron) {
            $this->reply['REPLY']['STATUS'] = 'KO';
            $this->reply['REPLY']['RESULT']['Status'] = 'PATRON_NOT_FOUND';
            $this->reply['REPLY']['RESULT']['Message'] = 'Utente non riconosciuto';
            return false;
        }

        Prado::log("GetPatronRenew OK ID:[{$patron_id}]", TLogger::INFO, 'SOAP');
        $l = ItemQuery::create()->findOneByItemId($item_id);
        if (!$l instanceof Item) {
            $this->reply['REPLY']['STATUS'] = 'KO';
            $this->reply['REPLY']['RESULT']['Status'] = 'ITEM_NOT_FOUND';
            $this->reply['REPLY']['RESULT']['Message'] = 'Prestito non riconosciuto';
            return false;
        }

        $due_date = $l->getDueDate('U');
        $renewWindowFrom = time() - ClavisParamPeer::getParam('LOANRENEWALTIME', 'FROM');
        $renewWindowUntil = time() + ClavisParamPeer::getParam('LOANRENEWALTIME', 'UNTIL');
        $canRenew = $due_date >= $renewWindowFrom && $due_date <= $renewWindowUntil;
        $renew = (bool)(($lm->IsLoanRenewable($l) == ClavisLoanManager::OK) && $canRenew);

        if ($renew) {
            $r = $lm->DoRenewLoan($l, $patron, null, null);
            Prado::log('Renew ' . $l->getBarcode() . ' : ' . Prado::varDump($r), TLogger::INFO, 'SOAP');
        }
        $l->reload();

        $status = '';
        $message = '';
        if ($l->getLoanStatus() == ItemPeer::LOANSTATUS_READYFORLOAN) {
            $status = 'READY';
            $message = 'Pronto al prestito';
        } else if ($l->getLoanStatus() == ItemPeer::LOANSTATUS_INTRANSIT) {
            $status = 'INTRANSIT';
            $message = 'In Transito';
        } else if ($lm->isLoanLate($l) == ClavisLoanManager::LOAN_ISLATE) {
            $status = 'LATE';
            $message = 'Scaduto';
        }

        $this->reply['REPLY']['STATUS'] = 'OK';
        $this->reply['REPLY']['RESULT']['status'] = $status;
        $this->reply['REPLY']['RESULT']['message'] = $message;
        return true;
    }

    private function PostItemNew()
    {
        if (($this->reply['REQUEST']['HTTP_X_CLAVIS_TOKEN'] !== null && $this->librarian === null)) {
            $this->reply['REPLY']['STATUS'] = 'KO';
            $this->reply['REPLY']['ERRORCODE'] = 'AUTHERR';
            $this->reply['REPLY']['ERRORINFO'] = 'Errore di autenticazione';
            return true;
        }

        // item ------------------------------------------------
        $manifestationID = $this->getRequest()->itemAt('manifestationId');
        $libraryId = $this->getRequest()->itemAt('libraryId');
        $manifestation = ManifestationQuery::create()->findOneByManifestationId($manifestationID);

        $collocation = $this->getRequest()->itemAt('itemCollocation');
        $barcode = $this->getRequest()->itemAt('itemBarcode');
        $mediaType = $this->getRequest()->itemAt('itemMediaType');
        $status = $this->getRequest()->itemAt('itemStatus');

        $loanClass = $this->getRequest()->itemAt('loanClass');
        $inventorySerie = $this->getRequest()->itemAt('itemInventorySerie');
        $inventoryNumber = $this->getRequest()->itemAt('itemInventoryNumber');

        $physicalStatus = $this->getRequest()->itemAt('itemPhysicalStatus');
        $specification = $this->getRequest()->itemAt('itemSpecification');
        $section = $this->getRequest()->itemAt('itemSection');

        try {
            $newItem = new Item();
            $newItem->setHomeLibraryId($libraryId);
            $newItem->setOwnerLibraryId($libraryId);
            $newItem->setActualLibraryId($libraryId);

            $newItem->setPhysicalStatus($physicalStatus);
            $newItem->setSpecification($specification);
            $newItem->setSection($section);

            if ($manifestation instanceof Manifestation) {
                $newTitle = $manifestation->getCompleteTitle();
                $manifestationDewey = $manifestation->getClass();
                if ((string)$newTitle === '')
                    $newTitle = '(' . Prado::localize('senza titolo') . ')';

                $newItem->setTitle($newTitle);
                $newItem->setManifestationDewey($manifestationDewey);
                $newItem->setManifestationId($manifestationID);

            }

            $newItem->setInventorySerieId($inventorySerie);
            $newItem->setInventoryNumber($inventoryNumber);

            $newItem->setCollocation($collocation);
            $newItem->setBarcode($barcode);


            if ($status === '')
                $status = ItemStatusBase::ITEMSTATUS_ONSHELF;

            if ($loanClass === '')
                $loanClass = ItemPeer::LOANCLASS_AVAILABLE;

            $newItem->setItemStatus(status);
            $newItem->setLoanClass($loanClass);
            $newItem->setLoanStatus(ItemPeer::LOANSTATUS_AVAILABLE);
            $newItem->setItemMedia($mediaType);

            $newItem->save();
            $newItemId = $newItem->getItemId();

            $this->reply['REPLY']['STATUS'] = 'OK';
            $this->reply['REPLY']['RESULT']['item'] = $newItemId;
            $this->reply['REPLY']['RESULT']['message'] = 'Esemplare creato correttamente (Id:' . $newItemId . ')';
            return true;
        } catch (Exception $e) {
            $this->reply['REPLY']['STATUS'] = 'KO';
            $this->reply['REPLY']['ERRORCODE'] = 'ITEM_CREATION_FAILED';
            $this->reply['REPLY']['ERRORINFO'] = $e->getMessage();
            return true;
        }

    }

    private function PostItemInit()
    {

        if (($this->reply['REQUEST']['HTTP_X_CLAVIS_TOKEN'] !== null && $this->librarian === null)) {
            $this->reply['REPLY']['STATUS'] = 'KO';
            $this->reply['REPLY']['ERRORCODE'] = 'AUTHERR';
            $this->reply['REPLY']['ERRORINFO'] = 'Errore di autenticazione';
            return true;
        }

        // params ------------------------------------------------------------------------------------------------------
        $manifestationID = $this->getRequest()->itemAt('id');
        $libraryID = $this->getRequest()->itemAt('libraryId');


        $is = InventorySerieQuery::create()->orderByClosed()->orderByReadonly()->orderByInventorySerieId()->findByLibraryId($libraryID);
        $inventorySeries = [];
        $inventoryNumbers = [];
        /** @var InventorySerie $inventory */
        foreach ($is as $inventory) {
            $id = $inventory->getInventorySerieId();
            $description = $inventory->getDescription();
            $inventorySeries[$id] = $description;
            $inventoryNumbers[$id] = InventorySeriePeer::calculateNextInventoryCounter($id, $libraryID);
        }

        $sections = LibraryValueQuery::create()
            ->filterByValueClass('ITEMSECTION')
            ->filterByValueLibraryId($libraryID)
            ->orderByValueKey()
            ->find();

        $itemSections = [];
        /** @var LibraryValue $section */
        foreach ($sections as $section) {
            $id = $section->getValueKey();
            $description = $section->getValueLabel();
            $itemSections[$id] = $description;
        }

        // response buildup --------------------------------------------------------------------------------------------
        try {
            if ($manifestationID > 0) {
                $manifestation = ManifestationQuery::create()->findOneByManifestationId($manifestationID);
                if ($manifestation instanceof Manifestation) {
                    $itemCreationParams = [
                        'itemSpecification' => $this->_getItemSpecification($manifestation),
                        'itemCollocation' => $this->_getItemCollocation($manifestation),
                        'itemMediaTypeList' => LookupValuePeer::getLookupClassValues('ITEMMEDIATYPE'),
                        'itemStatusList' => LookupValuePeer::getLookupClassValues('ITEMSTATUS'),
                        'itemPhysicalStatusList' => LookupValuePeer::getLookupClassValues('ITEMPHYSICALSTATUS'),
                        'itemSectionList' => $itemSections,
                        'loanClassesList' => LookupValuePeer::getLookupClassValues('LOANCLASS'),
                        'itemInventorySeries' => $inventorySeries,
                        'itemInventoryNumber' => $inventoryNumbers
                    ];

                    $this->reply['REPLY']['STATUS'] = 'OK';
                    $this->reply['REPLY']['RESULT']['itemParams'] = $itemCreationParams;
                    return true;
                }
            }
            throw new RuntimeException('Invalid manifestation given');

        } catch (Exception $e) {
            $this->reply['REPLY']['STATUS'] = 'KO';
            $this->reply['REPLY']['ERRORCODE'] = 'ITEM_PARAMS_ERROR';
            $this->reply['REPLY']['ERRORINFO'] = $e->getMessage();
            return true;
        }
    }

    private function _getItemCollocation(Manifestation $manifestation)
    {
        $class = $manifestation->getClass(true);

        $code = '';
        if ($class instanceof Authority) {
            $tm = $class->getTurboMarc();
            if (isset($tm->d676->si))
                $code = (string)$tm->d676->si;
            else if (isset($tm->d680->si))
                $code = (string)$tm->d680->si;
            else if (isset($tm->d686->si))
                $code = (string)$tm->d686->si;
            else
                $code = $class->getClassCode();
        }
        return $code;
    }

    private function _getItemSpecification(Manifestation $manifestation)
    {
        $author = explode('*', $manifestation->getAuthor(), 2);
        $author = array_pop($author);

        $specification = trim(mb_strtoupper(mb_substr($author, 0, 3, 'UTF-8'), 'UTF-8')
            . ' '
            . mb_strtoupper(mb_substr($manifestation->getSortText(), 0, 3, 'UTF-8'), 'UTF-8'));

        return $specification;
    }

    private function getInventoryNumber($inventorySerieId, $libraryId)
    {
        return InventorySeriePeer::calculateNextInventoryCounter($inventorySerieId, $libraryId);
    }

    /**
     * Effettua l'autoprestito per l'elemento indicato come parametro
     * @throws PropelException
     */
    private function PostItemCheckout()
    {
        /** @var $lm ClavisLoanManager */
        $lm = Prado::getApplication()->getModule('loan');
        /** @var ClavisRequestManager $rm */
        $rm = Prado::getApplication()->getModule('request');
        $auth = Prado::getApplication()->getModule('auth');

        // -------------------------------------------------------------------------------------------------------------
        // username - password based authentication (users' bot)
        // -------------------------------------------------------------------------------------------------------------

        if ($this->reply['REQUEST']['XUSERNAME'] !== null && $this->reply['REQUEST']['XPASSWORD'] !== null) {
            $login = $auth->login($this->reply['REQUEST']['XUSERNAME'], $this->reply['REQUEST']['XPASSWORD']);
            if (!$login) {
                $this->reply['REPLY']['STATUS'] = 'KO';
                $this->reply['REPLY']['ERRORCODE'] = 'AUTHERR';
                $this->reply['REPLY']['ERRORINFO'] = 'Errore di autenticazione';
                return true;
            }
        }

        // -------------------------------------------------------------------------------------------------------------
        // api token based authentication (librarians' bot)
        // -------------------------------------------------------------------------------------------------------------
        if (($this->reply['REQUEST']['HTTP_X_CLAVIS_TOKEN'] !== null && $this->librarian === null)) {
            $this->reply['REPLY']['STATUS'] = 'KO';
            $this->reply['REPLY']['ERRORCODE'] = 'AUTHERR';
            $this->reply['REPLY']['ERRORINFO'] = 'Errore di autenticazione';
            return true;
        }

        // item ------------------------------------------------
        $itembarcode = $this->getRequest()->itemAt('itemid');
        $item = ItemQuery::create()->findOneByBarcode($itembarcode);

        // patron ----------------------------------------------
        $patronid = $this->getRequest()->itemAt('patronid');
        $patron = PatronQuery::create()->findOneByPatronId($patronid);
        $loanonbooked = $this->getRequest()->itemAt('loanonbooked') === 'true';

        // library ----------------------------------------------
        $libraryid = $this->reply['REQUEST']['XLIBRARY'] ?? $this->getRequest()->itemAt('libraryid');
        $library = LibraryQuery::create()->findOneByLibraryId($libraryid);

        if (!$item instanceof Item) {
            Prado::log(__METHOD__ . "Elemento con barcode $itembarcode non trovato.", TLogger::INFO, 'SOAP');
        }

        if (!$patron instanceof Patron) {
            Prado::log(__METHOD__ . "Patron con id $patronid non trovato. ", TLogger::INFO, 'SOAP');
        }

        if (!$library instanceof Library) {
            Prado::log(__METHOD__ . "Library con id $libraryid non trovata. ", TLogger::INFO, 'SOAP');
        }

        if ($item instanceof Item &&
            $patron instanceof Patron &&
            $library instanceof Library) {

            Prado::log(__METHOD__ . "Loan item $itembarcode, patron: $patronid, library: $libraryid", TLogger::INFO, 'SOAP');

            $this->reply['REPLY']['RESULT'] = [
                'Title' => $item->getTitle(),
                'Message' => '',
                'Media' => $item->getItemMedia(),
                'ItemId' => $item->getItemId(),
                'Barcode' => $item->getBarcode(),
                'LoanClass' => $item->getLoanClass(),
                'Inventory' => $item->getCompleteInventoryNumber(),
                'Collocation' => $item->getCollocationCombo(),
                'Renewable' => false,
                'Late' => false,
            ];

            if ($item->IsLoaned() || ($item->getPatronId() != $patron->getPatronId() && $item->getLoanStatus() == ItemPeer::LOANSTATUS_READYFORLOAN)) {
                $this->reply['REPLY']['STATUS'] = 'OK';
                $this->reply['REPLY']['RESULT']['Status'] = 'LOAN';
                $this->reply['REPLY']['ERRORINFO'] = "L'elemento richiesto non è disponibile ora per il prestito.";

            } else if ((!$loanonbooked) && $rm->countRequests(0, null, $item->getItemId(), null, true) > 0) {
                $this->reply['REPLY']['STATUS'] = 'OK';
                $this->reply['REPLY']['RESULT']['Status'] = 'BOOK';
                $this->reply['REPLY']['ERRORINFO'] = 'Ci sono altre prenotazioni pendenti per questo elemento. Rivolgiti al banco prestiti per favore.';

            } else if ($lm->IsLoanAllowed($item, $patron, $libraryid)) {

                $this->reply['REPLY']['STATUS'] = 'OK';

                /** @var ClavisLibrarian $user */
                $user = Prado::getApplication()->getUser(); //guest
                $user->setId($this->librarian->getId()); // set the actual librarian
                $user->setActualLibraryId($libraryid); // set the actual library

                $res = $lm->DoLoanItem(
                    $item,
                    $patron,
                    $user,
                    LibraryQuery::create()->findPk($libraryid)
                );

                $item->reload();

                $this->reply['REPLY']['RESULT']['LoanStatusRes'] = $res;
                $this->reply['REPLY']['RESULT']['DueDate'] = $item->getDueDate('%F');
                $this->reply['REPLY']['RESULT']['LoanStatus'] = $item->getLoanStatus();

                if ($res === ClavisLoanManager::OK || $res === ClavisLoanManager::LOAN_LOANED) {
                    $this->reply['REPLY']['RESULT']['Status'] = 'OK';
                    $this->reply['REPLY']['ERRORINFO'] = "Prestito di {$item->getTitle()} effettuato con successo. Bravo!";
                } else {
                    $this->reply['REPLY']['RESULT']['Status'] = 'ERR';
                    $this->reply['REPLY']['ERRORINFO'] = "Ho effettuato una prenotazione per {$item->getTitle()} a nome {$patron->getLastname()} {$patron->getName()}.";
                }
            } else {
                $this->reply['REPLY']['STATUS'] = 'OK';
                $this->reply['REPLY']['RESULT']['Status'] = 'CARD';
                $this->reply['REPLY']['RESULT']['LoanStatus'] = 'ERR';
                $this->reply['REPLY']['ERRORINFO'] = "Impossibile completare l'operazione. Contattare il banco prestiti.";
            }
        } else {
            $this->reply['REPLY']['STATUS'] = 'KO';
            $this->reply['REPLY']['ERRORCODE'] = 'NOTFOUND';
            $this->reply['REPLY']['ERRORINFO'] = "Impossibile completare l'operazione. Contattare il banco prestiti.";
        }
        return true;
    }

    /**
     * @return bool
     * @throws PropelException
     */
    private function PostManifestationReserve()
    {
        // ---------- authorized user check
        if ($this->librarian == null) {
            Prado::log(__METHOD__ . ' AUTH ERR', TLogger::INFO, 'SOAP');
            $this->reply['REPLY']['STATUS'] = 'KO';
            $this->reply['REPLY']['ERRORCODE'] = 'AUTHERR';
            $this->reply['REPLY']['ERRORINFO'] = 'Non autorizzato';
            return true;
        }

        // ---------- valid delivery library check
        $deliveryLibrary = $this->getRequest()->itemAt('deliveryLibraryId');
        $library = LibraryQuery::create()->findOneByLibraryId($deliveryLibrary);
        if (!$library instanceof Library) {
            $this->reply['REPLY']['STATUS'] = 'KO';
            $this->reply['REPLY']['RESULT']['Status'] = 'LIBRARY_NOT_FOUND';
            $this->reply['REPLY']['RESULT']['Message'] = 'Biblioteca di destinazione non riconosciuta';
            return true;
        }

        // ---------- valid patron check
        $patron_id = $this->getRequest()->itemAt('patronId');
        $patron = PatronQuery::create()->findOneByPatronId($patron_id);
        if (!$patron instanceof Patron) {
            $this->reply['REPLY']['STATUS'] = 'KO';
            $this->reply['REPLY']['RESULT']['Status'] = 'PATRON_NOT_FOUND';
            $this->reply['REPLY']['RESULT']['Message'] = 'Utente non riconosciuto';
            return true;
        }

        // ---------- valid manifestation check
        $ean = $this->getRequest()->itemAt('id');
        $manifestation = $this->_getManifestationFromEAN($ean);

        if (!$ean || !($manifestation instanceof Manifestation)) {
            $manifestationId = $this->getRequest()->itemAt('manifestationId');
            $manifestation = ManifestationQuery::create()->findOneByManifestationId($manifestationId);
        }

        if (!($manifestation instanceof Manifestation)) {
            $this->reply['REPLY']['STATUS'] = 'KO';
            $this->reply['REPLY']['RESULT']['status'] = 'MANIFESTATION_NOT_FOUND';
            $this->reply['REPLY']['RESULT']['message'] = 'Manifestation su ' . $ean . ' non trovata';
            return true;
        }

        // ---------- perform the reservation
        /** @var ClavisRequestManager $reqManager */
        $reqManager = Prado::getApplication()->getModule('request');
        $returnVal = $reqManager->reserveManifestation($manifestation, $patron, $library);

        if ($returnVal === ClavisLoanManager::OK) {
            $this->reply['REPLY']['STATUS'] = 'OK';
            $this->reply['REPLY']['RESULT']['status'] = $returnVal;
            $this->reply['REPLY']['RESULT']['message'] = 'Prenotazione avvenuta con successo';
            return true;
        }

        $this->reply['REPLY']['STATUS'] = 'KO';
        $this->reply['REPLY']['RESULT']['status'] = $returnVal;
        $this->reply['REPLY']['RESULT']['message'] = 'Prenotazione fallita. [' . $returnVal . ']';
        return true;
    }


    private function _getManifestationFromEAN($ean)
    {
        $stdNum = ClavisBase::normalizeStdNum($ean);
        $manifestation = null;

        if (ClavisBase::checkEanValid($stdNum)) {
            $manifestation = ManifestationQuery::create()->findOneByEan($stdNum);
            if ($manifestation === null) {
                $manifestation = ManifestationQuery::create()->findOneByIsbnissn($stdNum);
            }
            if ($manifestation === null) {
                $isbn10 = Clavis::Ean13ToIsbn($stdNum);
                $manifestation = ManifestationQuery::create()->findOneByIsbnissn($isbn10);
            }
            if ($manifestation === null) {
                $isbn10 = Clavis::hyphenateStdNum($isbn10);
                $manifestation = ManifestationQuery::create()->findOneByIsbnissn($isbn10);
            }
        }
        return $manifestation;
    }

    /**
     * @return bool
     */
    private function PostLibraryInfo()
    {
        // Authorization check
        // -------------------------------------------------------------------------------------------------------------
        if ($this->librarian == null) {
            Prado::log(__METHOD__ . ' AUTH ERR', TLogger::INFO, 'SOAP');
            $this->reply['REPLY']['STATUS'] = 'KO';
            $this->reply['REPLY']['ERRORCODE'] = 'AUTHERR';
            $this->reply['REPLY']['ERRORINFO'] = 'Non autorizzato';
            return true;
        }

        // Get post params
        // -------------------------------------------------------------------------------------------------------------
        $request = $this->getRequest();
        $libraryid = $request->itemAt('library_id');
        $location = $request->itemAt('location');
        $info = $request->itemAt('info');
        $hours = $request->itemAt('hours');
        $library_list = [];

        if ($location) {
            $library_list = LibraryQuery::create()
                ->filterByLabel('%' . $location . '%')
                ->filterByLibraryStatus(LibraryPeer::STATUS_ACTIVE)
                ->filterByLibraryInternal(true)
                ->limit(5)
                ->find();
        }
        try {
            $library = LibraryQuery::create()->findOneByLibraryId($libraryid);
        } catch (Exception $e) {
            $this->botApiErrorLog($e->getMessage(), __METHOD__);
        }

        if ($library instanceof Library) {
            Prado::log(__METHOD__ . " OK ID:[{$libraryid}]", TLogger::INFO, 'SOAP');

            // Get preferred library timetable
            // ---------------------------------------------------------------------------------------------------------
            $preferred_library_data = [
                'libraryName' => $library->getDescription(),
                'isOpen' => $library->isLibraryOpen(),
                'timetable' => $library->getTimetable(),
                'nextOpen' => $library->getTimeTableNextOpen(),
            ];

            foreach ($library_list as $library) {
                if ($library instanceof Library) {
                    $location_library_data[] = [
                        'libraryName' => $library->getDescription(),
                        'isOpen' => $library->isLibraryOpen(),
                        'timetable' => $library->getTimetable(),
                        'nextOpen' => $library->getTimeTableNextOpen(),
                    ];
                }
            }

            $this->reply['REPLY']['STATUS'] = 'OK';
            $this->reply['REPLY']['RESULT'] = [
                'preferred' => $preferred_library_data,
                'location' => $location_library_data
            ];
            Prado::log(__METHOD__ . ' OK got library info. ' . print_r($this->reply['REPLY']['RESULT'], true), TLogger::INFO, 'SOAP');
        } else {
            Prado::log(__METHOD__ . " ID:[{$libraryid}] NOT FOUND", TLogger::INFO, 'SOAP');
            $this->reply['REPLY']['STATUS'] = 'KO';
            $this->reply['REPLY']['ERRORCODE'] = 'NOTFOUND';
            $this->reply['REPLY']['ERRORINFO'] = 'ID sconosciuto';
        }

        return true;
    }

    /**
     * @param $msg
     * @param $methodName
     */
    private function botApiErrorLog($msg, $methodName)
    {
        Prado::log("[BOT][ERROR][$methodName]$msg", TLogger::ERROR, "ClavisNG");
    }

    /**
     * Segna la notifica identificata da receipt_id come letta per l'utente con mongoid user_id.
     * @return bool
     * @throws Exception
     * @throws PropelException
     */
    private function PostNotificationReceipt()
    {
        $signature = $this->getRequest()->itemAt('signature');
        $receipt_id = $this->getRequest()->itemAt('receipt_id');
        $user_id = $this->getRequest()->itemAt('user_id'); //mongoid
        $ts = $this->getRequest()->itemAt('ts'); //timestamp
        $gone = $this->getRequest()->itemAt('gone'); //true if the user has unsubscribed itself from all the bot channels

        if (!($signature === md5(crypt($receipt_id, $this->botsecret)))) {
            $this->reply['REPLY']['STATUS'] = 'UNAUTHORIZED';
            $this->reply['REPLY']['RESULT']['Status'] = 'UNAUTHORIZED';
            $this->reply['REPLY']['RESULT']['Message'] = 'Azione non consentita';
            return false;
        }

        $notify = NotificationQuery::create()->findPk($receipt_id);
        $contact = ContactQuery::create()->filterByContactType(ContactPeer::TYPE_CHATBOT)->findOneByContactValue($user_id);

        // se il bot mi ha notificato che l'utente non ha piu' canali bot attivi, marco come non valido questo contatto.
        if ($contact instanceof Contact && $gone) {
            $this->reply['REPLY']['STATUS'] = 'OK';
            $this->reply['REPLY']['RESULT']['Status'] = 'GONE';
            $this->reply['REPLY']['RESULT']['Message'] = 'Utente del bot non trovato.';
            $contact->setContactType(ContactPeer::TYPE_WRONG);
            $contact->save();
            return true;
        }

        if ($notify instanceof Notification) {
            $notify->setAcknowledgeDate($ts);
            $notify->setNotificationState(NotificationPeer::STATUS_DELIVERED);
            $notify->addLogNote('Consegna OK');
            $notify->save();

            $this->reply['REPLY']['STATUS'] = 'OK';
            $this->reply['REPLY']['RESULT']['Status'] = 'ACKNOWLEDGED';
            $this->reply['REPLY']['RESULT']['Message'] = 'Notifica confermata correttamente';
            return true;
        }

        $this->reply['REPLY']['STATUS'] = 'KO';
        $this->reply['REPLY']['RESULT']['Status'] = 'PENDING';
        $this->reply['REPLY']['RESULT']['Message'] = "Notifica $receipt_id non confermata correttamente";
        return false;
    }

    /**
     * Manda il messaggio `message` con oggetto `subject` alla mail `mail_address`
     * @return bool
     */
    private function PostSendmailAddress()
    {
        /** @var $mailer SMTPMail */
        $mailer = Prado::getApplication()->getModule('mail');

        $mail_address = $this->getRequest()->itemAt('mail_address');
        $subject = $this->getRequest()->itemAt('subject');
        $message = $this->getRequest()->itemAt('message');
        $signature = $this->getRequest()->itemAt('signature');

        if (!($signature === md5(crypt($mail_address, $this->botsecret)))) {
            return false;
        }

        $mailer->setSubject($subject);
        $mailer->setBody($message);
        $mailer->setTo($mail_address);

        try {
            $mailer->send();
            $result = true;
            $this->reply['REPLY']['STATUS'] = 'OK';
            $this->reply['REPLY']['RESULT']['Status'] = 'SENT';
            $this->reply['REPLY']['RESULT']['Message'] = 'Mail spedita correttamente';
        } catch (Exception $e) {
            $result = false;
            Prado::log(__METHOD__ . ': invio mail fallito. ' . $e->getMessage(), TLogger::INFO, 'SOAP');

            $this->reply['REPLY']['STATUS'] = 'KO';
            $this->reply['REPLY']['ERRORCODE'] = 'NOTSENT';
            $this->reply['REPLY']['ERRORINFO'] = '[EXCEPTION] Mail non inviata: ' . $e->getMessage();
        }
        return $result;
    }

    /**
     * Manda il messaggio `message` alla biblioteca preferita dell'utente identificato dal mongoid
     * `user_id`
     * @return bool
     */
    private function PostSendmailLibrary()
    {
        /** @var $mailer SMTPMail */
        $mailer = Prado::getApplication()->getModule('mail');

        $user_id = $this->getRequest()->itemAt('user_id'); // mongoid
        $message = $this->getRequest()->itemAt('message');
        $signature = $this->getRequest()->itemAt('signature');

        if (!($signature == md5(crypt($user_id, $this->botsecret)))) {
            return false;
        }

        $patron = PatronQuery::create()
            ->useContactQuery()
            ->filterByContactType(ContactPeer::TYPE_CHATBOT)
            ->filterByContactValue($user_id)
            ->endUse()
            ->findOne();

        if (!$patron instanceof Patron) {
            Prado::log(__METHOD__ . ': Patron non trovato ', TLogger::INFO, 'SOAP');
            return false;
        }

        $dest = NotificationEmail::getEmailSender(
            'library',
            null,
            $patron->getPreferredLibrary(),
            null
        );

        $subject = 'Messaggio da ' . $patron->getCompleteName() . ' tramite BOT';
        $message = trim($message);

        $mailer->setSubject($subject);
        $mailer->setBody($message);
        $mailer->setTo($dest['email']);

        Prado::log(__METHOD__ . ": invio mail utente $subject a biblioteca " . $dest['email'], TLogger::INFO, 'SOAP');


        try {
            $mailer->send();
            $result = true;

            $this->reply['REPLY']['STATUS'] = 'OK';
            $this->reply['REPLY']['RESULT']['Status'] = 'SENT';
            $this->reply['REPLY']['RESULT']['Message'] = 'Mail spedita correttamente';

        } catch (Exception $e) {
            $result = false;
            Prado::log(__METHOD__ . ': invio mail fallito. ' . $e->getMessage(), TLogger::INFO, 'SOAP');

            $this->reply['REPLY']['STATUS'] = 'KO';
            $this->reply['REPLY']['ERRORCODE'] = 'NOTSENT';
            $this->reply['REPLY']['ERRORINFO'] = '[EXCEPTION] Mail non inviata: ' . $e->getMessage();
        }
        return $result;
    }

    /**
     * Manda un sms al numero di cellulare indicato.
     */
    private function PostSendSMS()
    {
        $mobile = $this->getRequest()->itemAt('mobile');
        $message = $this->getRequest()->itemAt('message');
        $signature = $this->getRequest()->itemAt('signature');
        $library_id = $this->getRequest()->itemAt('library_id');

        /* @var $m SMSTrendModule */
        $m = $this->getApplication()->getModule('sms');
        /** @var LibraryQuery $lsender */
        $lsender = LibraryQuery::create()->findPk($library_id);

        $m->setReceiver($mobile);
        $m->setMessage($message);

        $msgno = $m->getMsgNo();
        $smscredit = $lsender->getActualSMS();

        if (!$lsender instanceof Library) {
            $this->reply['REPLY']['STATUS'] = 'KO';
            $this->reply['REPLY']['ERRORCODE'] = 'SENDERLIB_NOTFOUND';
            $this->reply['REPLY']['ERRORINFO'] = '[EXCEPTION] sender lib not found';
            Prado::log(__METHOD__ . ": invio sms fallito. {$this->reply['REPLY']['ERRORINFO']}", TLogger::INFO, 'SOAP');
            return false;
        }

        if (!$m->checkAuth()) {
            $this->reply['REPLY']['STATUS'] = 'KO';
            $this->reply['REPLY']['ERRORCODE'] = 'WRONG_AUTHPARAMS';
            $this->reply['REPLY']['ERRORINFO'] = '[EXCEPTION] wrong auth params';
            Prado::log(__METHOD__ . ": invio sms fallito. {$this->reply['REPLY']['ERRORINFO']}", TLogger::INFO, 'SOAP');
            return false;
        }

        if (!($signature === md5(crypt($mobile, $this->botsecret)))) {
            $this->reply['REPLY']['STATUS'] = 'KO';
            $this->reply['REPLY']['ERRORCODE'] = 'WRONG_SIGNATURE';
            $this->reply['REPLY']['ERRORINFO'] = '[EXCEPTION] wrong signature';
            Prado::log(__METHOD__ . ": invio sms fallito. {$this->reply['REPLY']['ERRORINFO']}", TLogger::INFO, 'SOAP');
            return false;
        }

        if ($smscredit < $msgno) {
            $this->reply['REPLY']['STATUS'] = 'KO';
            $this->reply['REPLY']['ERRORCODE'] = 'CREDIT_INSUFFICIENT';
            $this->reply['REPLY']['ERRORINFO'] = '[EXCEPTION] not enough credit found';
            Prado::log(__METHOD__ . ": invio sms fallito. {$this->reply['REPLY']['ERRORINFO']}", TLogger::INFO, 'SOAP');
            return false;
        }

        $msgid = $this->getApplication()->getID() . '|' . $library_id . '|' . '-1';
        $result = $m->sendMessage($msgid);

        if (is_array($result) && ($result['status'] === 'KO')) {
            $this->reply['REPLY']['STATUS'] = 'KO';
            $this->reply['REPLY']['ERRORCODE'] = 'ERROR_SENDING';
            $this->reply['REPLY']['ERRORINFO'] = '[EXCEPTION] sending error';
            Prado::log(__METHOD__ . ": invio sms fallito. {$this->reply['REPLY']['ERRORINFO']}", TLogger::INFO, 'SOAP');
            return false;
        }

        if (is_array($result) && ($result['status'] === 'OK')) {
            try {
                //se l'invio è stato effettuato con successo, scalo l'inviato dal credito totale degli sms.
                $lsender->save();
                $lsender->setActualSMS($smscredit - $msgno);
            } catch (Exception $e) {
                $this->reply['REPLY']['STATUS'] = 'KO';
                $this->reply['REPLY']['ERRORCODE'] = 'ERROR_ASSIGNING';
                $this->reply['REPLY']['ERRORINFO'] = '[EXCEPTION] set sms to library error';
                Prado::log(__METHOD__ . ": invio sms fallito. {$this->reply['REPLY']['ERRORINFO']}", TLogger::INFO, 'SOAP');
                return false;
            }

            Prado::log(__METHOD__ . ": invio sms a $mobile completato.", TLogger::INFO, 'SOAP');
            $this->reply['REPLY']['STATUS'] = 'OK';
            $this->reply['REPLY']['ERRORCODE'] = 'SENT';
            $this->reply['REPLY']['ERRORINFO'] = '';
            return true;
        }

        return false;
    }

    /**
     * Method used by librarian bot to search for barcode/standard number or title.
     * Barcode must be a standard object with the value stored in an object field named value.
     * So the calling method must pass the data in this way:  urlencode(json_encode(array('type' => 'EAN_13', 'value' => 98273472684)))
     * @return bool
     */
    private function GetCatalogFind()
    {
        $response = [];
        $searchType = $this->getRequest()->itemAt('id');
        $numItemsToReturn = $this->getRequest()->itemAt('totItems') ?? self::SOLR_MAX_RESULTS;
        $libraryId = TPropertyValue::ensureInteger(urldecode($_GET['actualLibraryId']));

        Prado::log(__METHOD__ . "searchtype: $searchType, libraryID: $libraryId", TLogger::INFO, 'SOAP');

        switch ($searchType) {
            case 'barcode':
                $barcode = TPropertyValue::ensureString(urldecode($_GET['barcode']));
                $solrSearchResponse = $this->_handleCatalogSearchFromBarcode($barcode, -1);
                $rsp = $this->_parseSolrResponseArray($solrSearchResponse, $numItemsToReturn);
                $response = $this->_buildCatalogSearchResponseArray($rsp, $libraryId);
                break;
            case 'sn':
                $withItems = array_key_exists('withItems', $_GET) ? (bool)$_GET['withItems'] : true;
                $solrSearchResponse = $this->_handleCatalogSearchFromSN(urldecode($_GET['sn']), -1, $withItems);
                $rsp = $this->_parseSolrResponseArray($solrSearchResponse, $numItemsToReturn);
                $response = $this->_buildCatalogSearchResponseArray($rsp, $libraryId);
                break;
            case 'title':
                $solrSearchResponse = $this->_handleCatalogSearchFromTitle(urldecode($_GET['book']), -1);
                $rsp = $this->_parseSolrResponseArray($solrSearchResponse, $numItemsToReturn);
                $response = $this->_buildCatalogSearchResponseArray($rsp, $libraryId);
                break;
        }

        $this->reply['REPLY']['STATUS'] = 'OK';
        $this->reply['REPLY']['RESULT'] = $response;
        return true;
    }

    /**
     * Effettua una ricerca in Clavis secondo quanto specificato in $searchType
     * @throws Exception
     */
    private function GetCatalogSearch()
    {
        $searchType = $this->getRequest()->itemAt('id');

        switch ($searchType) {
            case 'df':
                $params = [
                    'material' => urldecode($_GET['material']),
                    'target' => urldecode($_GET['target']),
                    'search' => urldecode($_GET['search']),
                    'title' => urldecode($_GET['title']),
                    'author' => urldecode($_GET['author']),
                    'genre' => urldecode($_GET['genre']),
                    'priority' => urldecode($_GET['priority']),
                    'fuzzy' => urldecode($_GET['fuzzy']),
                    'message' => urldecode($_GET['message']),
                ];
                $r = $this->_handleCatalogSearchFromDF($params);
                break;
            case 'book':
                $r = $this->_handleCatalogSearchFromOCR(urldecode($_GET['book']));
                break;
            case 'landmark':
                $r = $this->_handleCatalogSearchFromLandmark(urldecode($_GET['landmarks']), urldecode($_GET['labels']));
                break;
            case 'barcode':
                $barcode = urldecode($_GET['barcode']);
                $response = $this->_handleCatalogSearchFromBarcode($barcode, -1);
                $opacLink = "opac/search/lst?standard-number={$barcode}";
                $index = @random_int(0, min(self::SOLR_MAX_RESULTS, count($response['response']['docs'])) - 1);
                $sr = $this->_parseSolrResponse($response, $index);
                $r = $this->_buildCatalogSearchResponse($sr, $opacLink);
                break;
            case 'location':
                $r = $this->_handleCatalogSearchFromGeolocation(urldecode($_GET['location']));
                break;
            case 'trendingreads':
                $r = $this->_handleTrendingReadsCatalogSearch();
                break;
            case 'trendingbooked':
                $r = $this->_handleTrendingBookedCatalogSearch();
                break;
        }

        $this->reply['REPLY']['STATUS'] = 'OK';
        $this->reply['REPLY']['RESULT'] = [$r];
        return true;
    }

    /**
     * Handles a catalog search with data coming from a dialogflow response.
     * @param $clavisSearchMessage
     * @return stdClass
     */
    private function _handleCatalogSearchFromDF($clavisSearchMessage)
    {
        // -------------------------------------------------------------------------------------------------------------
        // Params
        // -------------------------------------------------------------------------------------------------------------
        $r = null;
        $material = $this->_mapMaterial(explode(',', urldecode(trim($clavisSearchMessage['material']))));
        $target = $this->_mapTarget(explode(',', urldecode(trim($clavisSearchMessage['target']))));
        $search = urldecode($clavisSearchMessage['search']);
        $title = urldecode(trim($clavisSearchMessage['title']));
        $author = urldecode(trim($clavisSearchMessage['author']));
        $genre = urldecode(trim($clavisSearchMessage['genre']));
        $message = $clavisSearchMessage['message'];
        $priority = $clavisSearchMessage['priority'];
        $fuzzy = (bool)$clavisSearchMessage['fuzzy'];

        $this->botApiLog('[SEARCH] ----------------------------------------------------------------------------- ');
        $this->botApiLog("[SEARCH][MSG] priority: $priority: $message");
        $this->botApiLog("[SEARCH][PARAMS] material:$material, target:$target, search:$search, title:$title, author:$author, genre:$genre");

        // -------------------------------------------------------------------------------------------------------------
        // Solr Query Filters
        // -------------------------------------------------------------------------------------------------------------
        $qSearchAuthor = $this->getSearchAuthorQuery($author);
        $qSearchTitle = $this->getSearchTitleQuery($title);
        $qSearchSubject = $this->getSearchSubjectQuery($genre);

        $qSearchMaterial = $this->getSearchMaterialQuery($material);
        $qSearchTarget = $this->getSearchTargetQuery($target);
        $qSearchFullText = $this->getSearchFullTextQuery($search);

        $relevance = $this->_getRelevanceSolrQueryParams();
        $qFilterQuery = $this->getSearchFilterQuery();

        // -------------------------------------------------------------------------------------------------------------
        // Build Solr Query Pool
        // -------------------------------------------------------------------------------------------------------------

        if ($priority === 'author') {
            $qSearchFullText = $search === '' ? $this->getSearchFullTextQuery($author) : $qSearchFullText;
            $search = $author;
            $this->appendQueryCondition($solrQuery, $qSearchAuthor, true);
            $this->appendQueryCondition($solrQuery, $qSearchSubject);
            $this->appendQueryCondition($solrQuery, $qSearchFullText);
            $this->appendFilterCondition($solrQuery, $qFilterQuery);
            $q['author'] = $solrQuery;
        }

        if ($priority === 'title') {
            $qSearchFullText = $search === '' ? $this->getSearchFullTextQuery($title) : $qSearchFullText;
            $search = $title;
            $this->appendQueryCondition($solrQuery, $qSearchTitle, true);
            $this->appendQueryCondition($solrQuery, $qSearchSubject);
            $this->appendQueryCondition($solrQuery, $qSearchFullText);
            $this->appendFilterCondition($solrQuery, $qFilterQuery);
            $q['title'] = $solrQuery;
        }

        if ($fuzzy === true || ($priority !== 'title' && $priority !== 'search')) {
            $this->appendQueryCondition($solrQuery, $qSearchTitle, true);
            $this->appendQueryCondition($solrQuery, $qSearchAuthor);
            $this->appendQueryCondition($solrQuery, $qSearchSubject);
            $this->appendQueryCondition($solrQuery, $qSearchFullText);
            $this->appendFilterCondition($solrQuery, $qFilterQuery);
            $q['all'] = $solrQuery;
        }

        if ($fuzzy === true || ($priority !== 'title' && $priority !== 'search')) {
            $this->appendQueryCondition($solrQuery, $qSearchFullText, true);
            $this->appendFilterCondition($solrQuery, $qFilterQuery);
            $q['fulltext'] = $solrQuery;
        }
        // -------------------------------------------------------------------------------------------------------------
        // Find out the minimum and possibly the best results set.
        // -------------------------------------------------------------------------------------------------------------
        foreach ($q as $name => $query) {
            $hasResults = $this->_solrSearch($query, $response, '', $relevance, self::SOLR_MAX_RESULTS, $name);
            $r[] = ['name' => $name, 'query' => $query, 'hasResults' => $hasResults, 'response' => $response];
        }

        $sortByResultsNumber = function ($r) {
            $r = array_filter($r, function ($element) {
                return (int)$element['hasResults'] > 0;
            });

            usort($r, function ($a, $b) {
                return ($a['hasResults'] === $b['hasResults']) ? 0 : ($a['hasResults'] < $b['hasResults']) ? -1 : 1;
            });
            return $r;
        };

        $sortByWeights = function ($r) {
            $weights = ['all', 'title', 'author', 'fulltext'];
            $r = array_filter($r, function ($element) {
                return (int)$element['hasResults'] > 0;
            });

            usort($r, function ($a, $b) use ($weights) {
                $pos_a = array_search($a['name'], $weights);
                $pos_b = array_search($b['name'], $weights);
                return $pos_a - $pos_b;
            });
            return $r;
        };

        // reset() rewinds array's internal pointer to the first element and returns the value of the first array element,
        // or FALSE if the array is empty.
        $matchesArray = $sortByWeights($r);
        $bestMatch = reset($matchesArray);

        // -------------------------------------------------------------------------------------------------------------
        // I have the best result so far. Trying to apply target filter and see if I can further restrict
        // the result pool.
        // -------------------------------------------------------------------------------------------------------------
        $bestQuery = $bestMatch['query'];
        $bestName = $bestMatch['name'];

        $name = 'bestWithTM'; // best match with target and matarial
        $this->appendQueryCondition($bestQuery, $qSearchTarget);
        $this->appendQueryCondition($bestQuery, $qSearchMaterial);
        $hasResults = $this->_solrSearch($bestQuery, $response, '', $relevance, self::SOLR_MAX_RESULTS, $name);

        if ($hasResults > 5 && $target !== '') {
            $bestMatch = ['name' => $name, 'query' => $bestQuery, 'hasResults' => $hasResults, 'response' => $response];
        } else {
            $bestQuery = $bestMatch['query'];
            $name = 'bestWithM'; // best match with matarial.
            $this->appendQueryCondition($bestQuery, $qSearchMaterial);
            $hasResults = $this->_solrSearch($bestQuery, $response, '', $relevance, self::SOLR_MAX_RESULTS, $name);
            if ($hasResults > 0) {
                $bestMatch = ['name' => $name, 'query' => $bestQuery, 'hasResults' => $hasResults, 'response' => $response];
            }
        }

        // -------------------------------------------------------------------------------------------------------------
        // OPAC Url Construction
        // -------------------------------------------------------------------------------------------------------------
        $urlMaterial = $material > 0 ? "&facets-materiale={$material}" : '';
        $urlTarget = $target != '' ? "&facets-target={$target}" : '';

//        $urlSearchItem = ($bestName === 'author' || $bestName === 'title') ? $bestName : $search;
        $urlSearchItem = $search;
        $urlEncodedSearch = urlencode($urlSearchItem);
        $opacLink = "opac/search/lst?q={$urlEncodedSearch}";

        if ($bestMatch['name'] === 'bestWithTM') {
            $opacLink = "opac/search/lst?q={$urlEncodedSearch}{$urlMaterial}{$urlTarget}";
        }

        if ($bestMatch['name'] === 'bestWithM') {
            $opacLink = "opac/search/lst?q={$urlEncodedSearch}{$urlMaterial}";
        }

        // -------------------------------------------------------------------------------------------------------------
        // Parse and return the best result
        // -------------------------------------------------------------------------------------------------------------
        $maxIndex = (int)$bestMatch['hasResults'] > 0 ? (int)$bestMatch['hasResults'] - 1 : 0;
        $index = random_int(0, min(self::SOLR_MAX_RESULTS, $maxIndex));
        $sr = $this->_parseSolrResponse($bestMatch['response'], $index);
        $r = $this->_buildCatalogSearchResponse($sr, $opacLink);
        return $r;
    }

    /**
     * @param $materials
     * @return mixed
     */
    private function _mapMaterial($materials)
    {
        $map = [
            'libro' => -1,
            'manoscritto' => 2,
            'dvd' => 3,
            'musica' => 4,
            'audiolibri' => 5,
            'grafica' => 6,
            'ebook' => 7,
        ];

        foreach ($materials as $material) {
            if (isset($map[$material])) {
                return $map[$material];
            }
        }
        return $map['libro'];
    }

    /**
     * Mappa i valori ritornati dal target dialogflow con i rispettivi valori
     * turbomarc.
     * @param $targets
     * @return mixed
     */
    private function _mapTarget($targets)
    {
        $map = [
            'adulto' => 'm',
            'elementare' => 'c',
            'ragazzo' => 'd',
            'prescolare' => 'b',
            'giovane' => 'e',
        ];

        foreach ($targets as $target) {
            if (isset($map[$target])) {
                return $map[$target];
            }
        }
        return '';
    }

    /**
     * @param $msg
     */
    private function botApiLog($msg)
    {
        Prado::log("[BOT]$msg", TLogger::INFO, "ClavisNG");
    }

    /**
     * @param $search
     * @return string
     */
    private function getSearchAuthorQuery($search)
    {
        $search = $this->_cleanString($search);
        if ('' !== $search) {
            $andSearch = preg_replace('/\s/', ' AND ', $search);
            $query = "fldin_txt_author:($andSearch)";
            return $query;
        }
        return '';
    }

    /**
     * @param $string
     * @return mixed|string
     */
    private function _cleanString($string)
    {
        $string = $this->_wipePunctuation($string);
        $string = $this->_wipePrepositions($string);
        $string = $this->_wipeConjunction($string);
        $string = $this->_wipeArticles($string);
        $string = $this->_wipeMultipleSpaces($string);
        $string = $this->_solrEscapeQuery($string);

        return $string;
    }

    /**
     * @param $string
     * @return string
     */
    private function _wipePunctuation($string)
    {
        $string = strtolower(preg_replace('/[_,;:.\'!?"]+/', '', $string));
        return $string;
    }

    /**
     * @param $string
     * @return string
     */
    private function _wipePrepositions($string)
    {
        $string = trim(preg_replace('/\b(di|a|da|in|con|su(ll[e|a|o])?|per|tra|fra)\b/', ' ', $string));
        return $string;
    }

    /**
     * @param $string
     * @return string
     */
    private function _wipeConjunction($string)
    {
        $string = trim(preg_replace('/\b([eo])\b/', ' ', $string));
        return $string;
    }

    /**
     * @param $string
     * @return string
     */
    private function _wipeArticles($string)
    {
        $string = trim(preg_replace('/\b(il|lo|la|i|gli|le)\b/', ' ', $string));
        $string = trim(preg_replace('/\b(un|uno|una)\b/', ' ', $string));
        return $string;
    }

    /**
     * @param $string
     * @return string
     */
    private function _wipeMultipleSpaces($string)
    {
        $string = trim(preg_replace('/\s+/', ' ', $string));
        return $string;
    }

    /**
     * @param $solrQuery
     * @return mixed
     */
    private function _solrEscapeQuery($solrQuery)
    {
        $reserved_words = [
            '+',
            '-',
            '&&',
            '||',
            '!',
            '(',
            ')',
            '{',
            '}',
            '[',
            ']',
            '^',
            '"',
            '~',
            '*',
            '?',
            ':',
            '/'
        ];

        $escaped_words = array_map(
            function ($item) {
                return '\\' . $item;
            },
            $reserved_words
        );

        return str_replace($reserved_words, $escaped_words, $solrQuery);
    }

    /**
     * @param $search
     * @return string
     */
    private function getSearchTitleQuery($search)
    {
        $search = $this->_cleanString($search);
        if ('' !== $search) {
            $andSearch = preg_replace('/\s/', ' AND ', $search);
            return "+(fldin_txt_title:($andSearch))";
        }
        return '';
    }

    /**
     * @param $search
     * @return string
     */
    private function getSearchSubjectQuery($search)
    {
        $search = $this->_cleanString($search);
        if ('' !== $search) {
            $andSearch = preg_replace('/\s/', ' AND ', $search);
            $query = "fldin_txt_subject:($andSearch)";
            return $query;
        }
        return '';
    }

    /**
     * @param $search
     * @return string
     */
    private function getSearchMaterialQuery($search)
    {
        $search = $this->_cleanString($search);
        if ('' !== $search) {
            $andSearch = preg_replace('/\s/', ' AND ', $search);
            $query = "(mrc_d901_sc:($andSearch))";
            return $query;
        }
        return '';
    }

    /**
     * @param $search
     * @return string
     */
    private function getSearchTargetQuery($search)
    {
        $search = $this->_cleanString($search);
        if ('' !== $search) {
            return "(mrc_cdf:(d100_sa_17_$search))";
        }
        return '';
    }

    /**
     * @param $search
     * @return string
     */
    private function getSearchFullTextQuery($search)
    {
        $search = $this->_cleanString($search);
        if ('' !== $search) {
            return "fulltext:($search)";
        }
        return '';
    }

    /**
     * @return array
     */
    private function _getRelevanceSolrQueryParams()
    {
        $qf = 'mrc_d200_sa^10000 mrc_d200_sc^10000 mrc_d500_sa^1000 mrc_d200_sd^1000 mrc_d200_se^1000 mrc_d200_sh^1000 mrc_d200_si^1000 mrc_d225_sa^1000 mrc_d225_sd^1000 '
            . 'mrc_d225_se^1000 mrc_d225_sh^1000 mrc_d225_si^1000 mrc_d210_sc^1000 mrc_d210_sg^1000  mrc_d423_st^100 mrc_d454_st^100 mrc_d461_st^100 mrc_d327_sa^100 '
            . 'mrc_d410_st^100 mrc_d225_sf^100 fldin_txt_title^10 fldin_txt_author_main^1000 fldin_txt_author^100  fldin_txt_subject^1000  mrc_d676_sa^100 mrc_d680_sa^100 '
            . 'mrc_d686_sa^100 mrc_d676_sc^100 mrc_d680_sc^100 mrc_d686_sc^100  fldin_txt_note^10  mrc_d215_sa sorti_date  mrc_d010_sa mrc_d011_sa mrc_d073_sa ';

        $pf = 'mrc_d200_sa^10000 mrc_d200_sc^10000 mrc_d500_sa^1000 mrc_d200_sd^1000 mrc_d200_se^1000 mrc_d200_sh^1000 mrc_d200_si^1000 mrc_d225_sa^1000 mrc_d225_sd^1000 '
            . 'mrc_d225_se^1000 mrc_d225_sh^1000 mrc_d225_si^1000 mrc_d210_sc^1000 mrc_d210_sg^1000 mrc_d423_st^100 mrc_d454_st^100 mrc_d461_st^100 mrc_d327_sa^100 mrc_d410_st^100 mrc_d225_sf^100 '
            . 'fldin_txt_title^10 fldin_txt_author_main^1000 fldin_txt_author^100 fldin_txt_subject^1000 mrc_d676_sa^100 mrc_d680_sa^100 mrc_d686_sa^100 mrc_d676_sc^100 mrc_d680_sc^100 mrc_d686_sc^100 '
            . 'fldin_txt_note^10 mrc_d215_sa sorti_date mrc_d010_sa mrc_d011_sa mrc_d073_sa ';

        return ['qf' => $qf, 'pf' => $pf];
    }

    /**
     * @return string
     */
    private function getSearchFilterQuery()
    {
        // Cerco nel catalogo gli elementi disponibili (mrc_d950_sj) oppure elementi MLOL.
        return '((collection:catalog AND mrc_d950_sj:[* TO *]) OR (collection:MLOL))';
    }

    /**
     * @param        $solrQuery
     * @param        $condition
     * @param bool $init
     * @param string $op
     */
    private function appendQueryCondition(&$solrQuery, $condition, $init = false, $op = 'AND')
    {
        $solrQuery = $init ? '' : $solrQuery;
        $solrQuery = $solrQuery ?? '';

        if ($condition !== '') {
            $cond = $solrQuery !== '' ? " $op " : '';
            if ($solrQuery !== '' || ($solrQuery === '' && $init)) {
                $solrQuery = $solrQuery . $cond . $condition;
            }
        }
    }

    /**
     * @param $solrQuery
     * @param $condition
     */
    private function appendFilterCondition(&$solrQuery, $condition)
    {
        if ($solrQuery !== '') {
            $this->appendQueryCondition($solrQuery, $condition);
        }
    }

    /**
     * @param        $solrQuery
     * @param        $response
     * @param string $sortCriteria
     * @param array $extra
     * @param null $maxResults
     * @param string $queryname
     * @return int
     */

    // For $sortCriteria options search for private $_sortRules
    // 31-10-2109: change default sortcriteria from dateDesc to score... it seems more reasonable to me now and provide better overall results
    // expecially over a targeted query (i.e. "la coscienza di zeno")
    private function _solrSearch($solrQuery, &$response, $sortCriteria = '', $extra = [], $maxResults = null, $queryname = '')
    {
        if ($solrQuery != '') {
            $params = array_merge(['facet' => 'true', 'facet.field' => 'collection'], $extra);

            $search = $this->getApplication()->getModule('search');
            $search->setRecordCollection(null);

            $maxResults = null === $maxResults ? self::SOLR_MAX_RESULTS : (int)$maxResults;
            //----------------------------------------------------------------------------------------------------------
            $response = $search->search($solrQuery, 0, $maxResults, $sortCriteria, $params);
            //----------------------------------------------------------------------------------------------------------
            $nf = $response['response']['numFound'];
            if ($response && $response['response']['numFound'] > 0) {
                return $response['response']['numFound'];
            }
        }
        return 0;
    }

    /**
     * @param      $response
     * @param int $docIndex
     * @return array
     */
    private function _parseSolrResponse($response, $docIndex = 0): array
    {

        $docIndex = $docIndex >= 0 ? $docIndex : 0;
        $totfound = $response['response']['numFound'] ?: 0;
        $mlol = @$response['facet_counts']['facet_fields']['collection']['MLOL'] ?: 0;
        $ean = $this->_getEANfromTurboMark($response['response']['docs'][$docIndex]['turbo_marc']);
        $title = $response['response']['docs'][$docIndex]['sorts_title'] ?: '';
        $author = $response['response']['docs'][$docIndex]['sorts_author'] ?: '';
        $ids = explode(':', $response['response']['docs'][$docIndex]['id']);

        return [
            'found' => $totfound,
            'mlol' => $mlol,
            'ean' => $ean,
            'title' => $title,
            'author' => $author,
            'manifestation_id' => @end($ids)
        ];
    }

    private function _parseSolrResponseArray($response, $numItemsToReturn)
    {
        $r = [];
        $numItemsToReturn = min($numItemsToReturn, $response['response']['numFound']);
        if ($numItemsToReturn > 0) {
            $r['found'] = $response['response']['numFound'] ?: 0;
            $r['mlol'] = @$response['facet_counts']['facet_fields']['collection']['MLOL'] ?? 0;

            for ($i = 0; $i < $numItemsToReturn; $i++) {
                $ids = explode(':', $response['response']['docs'][$i]['id']);
                $r['items'][] = [
                    'ean' => $this->_getEANfromTurboMark($response['response']['docs'][$i]['turbo_marc']),
                    'title' => $response['response']['docs'][$i]['sorts_title'] ?: '',
                    'author' => $response['response']['docs'][$i]['sorts_author'] ?: '',
                    'manifestation_id' => @end($ids)
                ];
            }
        }
        return $r;

    }

    /**
     * @param $tm
     * @return mixed
     */
    private function _getEANfromTurboMark($tm)
    {
        $turbomark = simplexml_load_string($tm);
        list($d073, $d010, $d011) = [
            Clavis::normalizeStdNum($turbomark->d073->sa),
            Clavis::normalizeStdNum($turbomark->d010->sa[0]),
            Clavis::normalizeStdNum($turbomark->d011->sa[0]),
        ];

        return $d073 ?: $d010 ?: $d011;
    }

    private function _buildCatalogSearchResponseArray($sr, $actualLibraryId = -1)
    {
        $r = [];
        foreach ($sr['items'] as $key => $item) {
            $in_library = null;
            $in_system = null;

            if (isset($item['ean'])) {
                if ((int)$item['manifestation_id'] > 0) {

                    /** @var Item $in_library */
                    $in_library = ItemQuery::create()
                        ->useManifestationQuery()
                        ->filterByManifestationId($item['manifestation_id'])
                        ->endUse()
                        ->filterByActualLibraryId($actualLibraryId)
                        ->filterByItemStatus(ItemStatus::ITEMSTATUS_ONSHELF)
                        ->findOne();

                    /** @var Item $in_system */
                    $in_system = ItemQuery::create()
                        ->useManifestationQuery()
                        ->filterByManifestationId($item['manifestation_id'])
                        ->endUse()
                        ->filterByItemStatus(ItemStatus::ITEMSTATUS_ONSHELF)
                        ->findOne();
                }

                $no_item = ((!isset($in_library)) && (!isset($in_system)));

                /** @noinspection NestedTernaryOperatorInspection */
                $item_collocation = $no_item ? '' : (isset($in_library) ?
                    $in_library->getInventoryCollocationCombo() :
                    $in_system->getInventoryCollocationCombo());

                /** @noinspection NestedTernaryOperatorInspection */
                $item_inventory = $no_item ? '' : (isset($in_library) ?
                    $in_library->getCompleteInventoryNumber() :
                    $in_system->getCompleteInventoryNumber());

                /** @noinspection NestedTernaryOperatorInspection */
                $manifestation_id = $no_item ? $item['manifestation_id'] : (isset($in_library) ?
                    $in_library->getManifestationId() :
                    $in_system->getManifestationId());

                $r['items'][] = [
                    'cover_link' => $item['ean'] !== '' ? 'http://covers.comperio.it/calderone/viewmongofile.php?ean=' . $item['ean'] : '',
                    'cover_title' => $item['title'] ?: '',
                    'cover_author' => $item['author'] ?: '',
                    'item_collocation' => $item_collocation,
                    'item_inventory' => $item_inventory,
                    'item_ean' => $item['ean'],
                    'item_manifestation_id' => $manifestation_id,
                    'is_external' => $in_library === null && $in_system !== null,
                    'external_library' => isset($in_system) ? $in_system->getActualLibraryDescription() : ''
                ];
            }
        }

        $r['found'] = $sr['found'];
        $r['mlol'] = $sr['mlol'];

        return $r;
    }

    /**
     * @param      $sr
     * @param      $opacLink
     * @return stdClass
     */
    private function _buildCatalogSearchResponse($sr, $opacLink)
    {
        $ids = explode(':', $sr['id']);
        $response = new stdClass();
        $response->num_items = $sr['found'];
        $response->categories = (object)['ebooks' => $sr['mlol']];
        $response->cover_link = $sr['ean'] !== '' ? 'http://covers.comperio.it/calderone/viewmongofile.php?ean=' . $sr['ean'] : '';

        $response->cover_title = $sr['title'] ?: '';
        $response->cover_author = $sr['author'] ?: '';
        $response->manifestation_id = @end($ids) ?: 0;
        $response->opac_link = $opacLink;

        return $response;

    }

    /**
     * @param     $text
     * @param int $actualLibraryId
     * @return stdClass|null
     */
    private function _handleCatalogSearchFromOCR($text, $actualLibraryId = 0)
    {
        // Solr Query
        // -------------------------------------------------------------------------------------------------------------
        $r = null;
        if ('' !== trim($text)) {
            $solrQuery = "(fulltext:($text)) AND ((collection:catalog AND mrc_d950_sj:[* TO *]) OR (collection:MLOL))";

            if ($actualLibraryId > 0) {
                $solrQuery .= ' AND sf_d950:("' .
                    ' $sj F' . // stato fisico su scaffale
                    ' $sn ' . $actualLibraryId . //biblioteca corrente impostata da bibliotecario
                    '"~100' .
                    'AND "' .
                    '$sj F"' .
                    'AND "' .
                    '$sn ' . $actualLibraryId . '")';
            }

            $hasResults = $this->_solrSearch($solrQuery, $response);
            $opacLink = $this->_buildOPACadvancedSearchLink($text);

            // Parse and return the result
            // -------------------------------------------------------------------------------------------------------------
            $index = rand(0, min(self::SOLR_MAX_RESULTS, count($response['response']['docs'])) - 1);
            $sr = $this->_parseSolrResponse($response, $index);
            $r = $this->_buildCatalogSearchResponse($sr, $opacLink);
        }
        return $r;
    }

    /**
     * @param      $title
     * @param      $actualLibraryId
     * @return stdClass|null
     */
    private function _handleCatalogSearchFromTitle($title, $actualLibraryId)
    {
        // Solr Query
        // -------------------------------------------------------------------------------------------------------------
        $response = null;
        if ('' !== trim($title)) {
            $solrQuery = "(fldin_txt_title:($title)) AND mrc_d950_sj:[* TO *]";

            if ($actualLibraryId > 0) {
                $solrQuery .= ' AND sf_d950:("' .
                    ' $sj F' . // stato fisico su scaffale
                    ' $sn ' . $actualLibraryId . //biblioteca corrente impostata da bibliotecario
                    '"~100' .
                    'AND "' .
                    '$sj F"' .
                    'AND "' .
                    '$sn ' . $actualLibraryId . '")';
                // (fldin_txt_title:(sole)) AND mrc_d950_sj:[* TO *] AND sf_d950:("$sj F $sn 2"~100 AND "$sj F" AND "$sn 2")
            }
            $this->_solrSearch($solrQuery, $response, '');
        }
        return $response;
    }


    /**
     * @param      $standardNumber
     * @param      $actualLibraryId
     * @param bool $withItems
     * @return stdClass|null
     */
    private function _handleCatalogSearchFromSN($standardNumber, $actualLibraryId, $withItems = true)
    {
        $response = null;
        $normalizedSN = Clavis::normalizeStdNum($standardNumber);
        $r = null;
        if ('' !== trim($standardNumber)) {
            $solrQuery = "(fldin_txt_numbers:($normalizedSN))";
            $solrQuery .= $withItems ? ' AND mrc_d950_sj:[* TO *]' : '';

            if ($actualLibraryId > 0) {
                $solrQuery .= ' AND sf_d950:("' .
                    ' $sj F' . // stato fisico su scaffale
                    ' $sn ' . $actualLibraryId . // biblioteca corrente impostata da bibliotecario
                    '"~100' .
                    'AND "' .
                    '$sj F"' .
                    'AND "' .
                    '$sn ' . $actualLibraryId . '")';
            }
            $this->_solrSearch($solrQuery, $response, '');
        }
        return $response;
    }

    /**
     * @param      $text
     * @param bool $fulltext
     * @return string
     */
    private function _buildOPACadvancedSearchLink($text, $fulltext = true)
    {
        // divido per parola, ma se ci sono i doppi apici considero la frase intera come un unica parola. "parola mia".
        $terms = preg_split('/("[^"]*")|\h+/', $text, -1, PREG_SPLIT_NO_EMPTY | PREG_SPLIT_DELIM_CAPTURE);

        $opacLink = 'opac/advanced?op_1=or';
        $s = $fulltext ? 'q' : 'title';

        foreach ($terms as $key => $term) {
            $index = $key + 4;
            $term = urlencode(trim($term));
            $opacLink .= "&field_{$index}={$s}&lop_{$index}=1&value_{$index}={$term}";
        }

        $opacLink .= '&submit=&sort=score&page=20';
        return $opacLink;
    }

    /**
     * @param       $landmark
     * @param array $labels
     * @return stdClass|null
     * @throws Exception
     */
    private function _handleCatalogSearchFromLandmark($landmark, $labels = [])
    {
        $search = $landmark ?: implode(' ', $labels);
        return $this->_handleCatalogSearchFromOCR($search, -1, false);
    }

    /**
     * @param $barcode
     * @param $actualLibraryId
     * @return stdClass|null
     */
    private function _handleCatalogSearchFromBarcode($barcode, $actualLibraryId)
    {
        $b = json_decode($barcode);
        $barcode = Clavis::normalizeStdNum($b->value);
        $r = null;

        $search_lib = '';
        if ($actualLibraryId > 0) {
            $search_lib = "sf_d950:(\$sa {$actualLibraryId}) AND";
        }

        if ('' !== trim($barcode)) {
            $solrQuery =
                "(mrc_d073_sa:(+{$barcode}) OR " .
                "mrc_d010_sa:(+{$barcode}) OR " .
                "mrc_d011_sa:(+{$barcode}) OR " .
                "mrc_d012_sa:(+{$barcode}) OR " .
                "mrc_d013_sa:(+{$barcode}) OR " .
                "mrc_d014_sa:(+{$barcode}) OR " .
                "mrc_d015_sa:(+{$barcode}) OR " .
                "mrc_d016_sa:(+{$barcode}) OR " .
                "mrc_d017_sa:(+{$barcode}) OR " .
                "mrc_d020_sa:(+{$barcode}) OR " .
                "mrc_d021_sa:(+{$barcode}) OR " .
                "mrc_d022_sa:(+{$barcode}) OR " .
                "mrc_d040_sa:(+{$barcode}) OR " .
                "mrc_d071_sa:(+{$barcode}) OR " .
                "mrc_d072_sa:(+{$barcode})) AND " .
                $search_lib .
                '((collection:catalog AND mrc_d950_sj:[* TO *]) OR (collection:MLOL))';

            $this->_solrSearch($solrQuery, $response);
        }
        return $response;
    }

    /**
     * @param $locationString
     * @return stdClass|null
     * @throws Exception
     */
    private function _handleCatalogSearchFromGeolocation($locationString)
    {
        return $this->_handleCatalogSearchFromLandmark($locationString);
    }

    /**
     * @return array
     */
    private function _handleTrendingReadsCatalogSearch()
    {
        $r = [];
        $trending = $this->_getTrendingSolrQueryParams();
        $hasResults = $this->_solrSearch($trending['query'], $response, 'loansdesc', $trending['params']);
        $max = min(10, $hasResults);
        for ($i = 0; $i < $max; $i++) {
            $r[] = $this->_parseSolrResponse($response, $i);
        }

        return $r;
    }

    /**
     * @return array
     */
    private function _getTrendingSolrQueryParams()
    {
        $solrQuery = '(fulltext:(*:*)) AND ((collection: catalog) AND (faceti_libvisi:[* TO *] OR (*:* NOT (mrc_d901_sb:m AND (mrc_d901_sd:3 OR mrc_d901_sd:0 OR (*:* -mrc_d901_sd:[* TO *]))))) AND ((*:* NOT mrc_d901_sb:s) OR (mrc_d950_sx:U OR mrc_d950_sx:A OR mrc_d945_sn:[* TO *])) OR (mrc_d901_sa:l02))';
        $params = $this->_getRelevanceSolrQueryParams();
        return ['query' => $solrQuery, 'params' => $params];
    }

    /**
     * @return array
     */
    private function _handleTrendingBookedCatalogSearch()
    {
        $r = [];
        $trending = $this->_getTrendingSolrQueryParams();
        $hasResults = $this->_solrSearch($trending['query'], $response, 'sorti_requests', $trending['params']);
        $max = min(10, $hasResults);
        for ($i = 0; $i < $max; $i++) {
            $r[] = $this->_parseSolrResponse($response, $i);
        }
        return $r;
    }

    /**
     * @param $searchValue
     * @return array
     */
    private function _search_cardid_callback($searchValue)
    {
        if ($searchValue === '') {
            return [];
        }

        return PatronQuery::create()
            ->findByCardCode($searchValue)
            ->getData();
    }

    /**
     * @param $searchValue
     * @return array
     */
    private function _search_barcode_callback($searchValue)
    {
        if ($searchValue === '') {
            return [];
        }

        return PatronQuery::create()
            ->findByBarcode($searchValue)
            ->getData();
    }


    /**
     * @param $searchValue
     * @return array
     */
    private function _search_nid_callback($searchValue)
    {
        if ($searchValue === '') {
            return [];
        }

        return PatronQuery::create()
            ->findByNationalId($searchValue)
            ->getData();
    }

    /**
     * @param        $search
     * @param null $author
     * @param string $condition
     * @return string
     */
    private function getSearchAuthorSubjectQuery($search, $author = null, $condition = 'OR'): string
    {
        $author = $author ?? $search;
        $a = $this->getSearchAuthorQuery($author);
        $s = $this->getSearchSubjectQuery($search);

        return ($a !== '' && $s !== '')
            ? "($a $condition $s)"
            : "$a$s";
    }

    /**
     * @return bool
     */
    private function GetLibrarianLibraries()
    {

        // Get post params
        // -------------------------------------------------------------------------------------------------------------
        $request = $this->getRequest();
        $librarian_id = $request->itemAt('id');

        if (!($librarian_id > 0)) {
            $this->botApiErrorLog("Invalid parameters: librarianid: $librarian_id.", __METHOD__);
        }

        try {
            /** @var Librarian $librarian */
            $librarian = LibrarianQuery::create()->findOneByLibrarianId($librarian_id);
            $libraries = $librarian->getUserLibraries(array(),
                true,
                $contractLeftCount,
                $contractExpiredCount,
                $contractBlockedCount);

            $this->reply['REPLY']['STATUS'] = 'OK';
            $this->reply['REPLY']['RESULT']['libraries'] = $libraries;
            return true;
        } catch (Exception $e) {
            $this->botApiErrorLog($e->getMessage(), __METHOD__);
            return false;
        }
    }

    /**
     * @return bool
     * @throws PropelException
     */
    private function PostLibrarianValidate()
    {
        // Get post params
        // -------------------------------------------------------------------------------------------------------------
        $request = $this->getRequest();
        $librarian_id = $request->itemAt('librarian_id');
        $token = urldecode($request->itemAt('token'));

        $librarian = LibrarianQuery::create()->findOneByLibrarianId($librarian_id);

        if (!($librarian instanceof Librarian) && !($librarian_id > 0)) {
            $this->botApiErrorLog("Invalid parameters: librarianidlibr: $librarian_id, token: $token", __METHOD__);
        }

        try {
            $hasToken = 0;
            if ($token !== '') {
                $hasToken = ApiTokenQuery::create()
                    ->filterByLibrarianId($librarian_id)
                    ->filterByToken($token)
                    ->filterByDomain('LIBRARIAN_BOT')
                    ->where('(ApiToken.expires > ? OR ApiToken.expires IS NULL)', date('Y-m-d 00:00:00'))
                    ->count();
            }
            if ($hasToken > 0) {
                $this->reply['REPLY']['STATUS'] = 'OK';
                $this->reply['REPLY']['RESULT']['tokens'] = $hasToken;
                return true;
            }
        } catch (Exception $e) {
            $this->botApiErrorLog($e->getMessage(), __METHOD__);
            return false;
        }

        $this->reply['REPLY']['STATUS'] = 'KO';
        $this->reply['REPLY']['RESULT']['tokens'] = [];
        return true;
    }

    private function PostLibrarianForget()
    {
        try {
            $librarian_id = $this->getRequest()->itemAt('id');
            $librarian = LibrarianQuery::create()->findOneByLibrarianId($librarian_id);
            Prado::log('PostLibrarianForget called: ' . $librarian_id, TLogger::ALERT, 'SOAP');

            $affectedRows = false;
            if ($librarian instanceof Librarian) {
                $affectedRows = ApiTokenQuery::create()
                    ->filterByLibrarianId($librarian_id)
                    ->filterByToken(@$_SERVER['HTTP_X_CLAVIS_TOKEN'])
                    ->filterByDomain('LIBRARIAN_BOT')
                    ->update([
                        'Expires' => (new DateTime())->format('Y-m-d H:i:s')
                    ]);
            }

            $this->reply['REPLY']['STATUS'] = 'OK';
            $this->reply['REPLY']['RESULT']['tokens'] = $affectedRows;
            return true;
        } catch (Exception $e) {
            $this->botApiErrorLog($e->getMessage(), __METHOD__);
            $this->reply['REPLY']['STATUS'] = 'KO';
            $this->reply['REPLY']['RESULT']['tokens'] = [];
            return true;
        }
    }

    /**
     * @param $librarian_id
     * @param $token
     * @return bool
     */
    private function librarianHasToken($librarian_id, $token)
    {
        $hasToken = ApiTokenQuery::create()
            ->filterByLibrarianId($librarian_id)
            ->filterByToken($token)
            ->count();

        return ($hasToken > 0);
    }

    /**
     * @return bool
     * @throws PropelException
     */
    private function PostItemReturn()
    {
        $barcodeItem = $this->getRequest()->itemAt('id');
        $actualLibraryId = $this->getRequest()->itemAt('actualLibraryId');
        $librarianId = $this->getRequest()->itemAt('librarianId');

        $item = ItemQuery::create()->findOneByBarcode($barcodeItem);

        if (!$item instanceof Item) {
            Prado::log("Esemplare $barcodeItem sconosciuto", TLogger::INFO, "SOAP");
            $this->reply['REPLY']['STATUS'] = 'KO';
            $this->reply['REPLY']['RESULT']['Status'] = 'NOT_FOUND';
            $this->reply['REPLY']['ERRORINFO'] = "Nessun esemplari con barcode $barcodeItem";
            return true;
        }

        Prado::getApplication()->getUser()->setActualLibraryId($actualLibraryId);
        Prado::getApplication()->getUser()->setId($librarianId);

        /** @var $lm ClavisLoanManager */
        $lm = Prado::getApplication()->getModule('loan');
        $lm->putLostToAvailableItem($item->getItemId());
        $ret = $lm->DoReturnItem($item, $item->getPatron(), Prado::getApplication()->getUser());
        if ($ret) {
            Prado::log("Restituzione $barcodeItem OK", TLogger::INFO, 'SOAP');
            $this->reply['REPLY']['STATUS'] = 'OK';
            $this->reply['REPLY']['RESULT']['Status'] = 'IS_BACK';
            $this->reply['REPLY']['ERRORINFO'] = "Restituzione dell'elemento con $barcodeItem effettuata con successo";
            return true;
        }

        $patron = $item->getPatron();
        $patronName = $patron ? $patron->getCompleteName() : 'Nessun utente associato al prestito';
        $itemTitle = $item ? $item->getTitle() : 'Nessun titolo associato al barcode';

        Prado::log("Errore durante restituzione $barcodeItem", TLogger::INFO, 'SOAP');
        $this->reply['REPLY']['STATUS'] = 'KO';
        $this->reply['REPLY']['RESULT']['Status'] = 'ERROR';
        $this->reply['REPLY']['ERRORINFO'] = $itemTitle . ' - ' . $patronName;
        return true;
    }
}
