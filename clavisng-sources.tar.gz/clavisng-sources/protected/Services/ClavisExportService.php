<?php
/**
 * ClavisExportService class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info
 * @comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Services
 */

/**
 * ClavisExportService Class
 *
 * ClavisExportService provides a method for exporting database data in a wide
 * range of formats.
 * Takes two parameters:
 * <ul>
 * <li><strong>serviceParameter</strong> (i.e. index.php?export=format) identifies the
 * format for the output. Currently supported: "iso2709", "csv", "cdd", "turbomarc" or "xml".</li>
 * <li>either <strong>id</strong>, <strong>ean</strong> or <strong>data</strong>:
 * the former two searches for the corresponding manifestation and returns it, the latter
 * output all manifestations updated in the range specified (as YYYYMMDDyyyymmdd,
 * capital means "from").</li>
 * </ul>
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Services
 * @since 2.5.0
 */
class ClavisExportService extends AuthTService
{
	private $_nocache = false;
	const MAX_RESULTS = 10;

	/**
	 * Runs the service.
	 */
	public function run()
	{
		$m = array();
		$format = $this->getRequest()->getServiceParameter();
                
        if (extension_loaded('newrelic')) {
            newrelic_set_appname ("ClavisNG - " . $this->getApplication()->getID());
            newrelic_name_transaction("EXPORTSERVICE." . __METHOD__);
            newrelic_add_custom_parameter('FORMAT', $format );
        }
                
                
		if ($mid = $this->getRequest()->itemAt('id')) {
			$m = ManifestationQuery::create()->findByManifestationId($mid);
		} else if($format == 'json'){
            $params = [];
            $fld = ['title','ean','date','publisher','author','biblevel','bid'];
            foreach ($this->getRequest() as $name=>$value) {
                if(in_array($name,$fld) && trim($value) != '') {
                    $params[$name]=$value;
                }
            }
            if(count($params)>0) {
                $ret = $this->searchCatalog($params);
                $this->getResponse()->setContentType('text/json');
                $this->getResponse()->write(json_encode($ret));
                Prado::getApplication()->completeRequest();
                return;
            }
        } else if ($ean = $this->getRequest()->itemAt('ean')) {
			$ean = Clavis::normalizeStdNum($ean);
			$response = Prado::getApplication()->getModule('search')->search(
				"+(fldin_txt_numbers:{$ean})",0,50);
			$idArray = array();
			if ($response)
				foreach ($response['response']['docs'] as $key => $result)
					$idArray[] = $result['Id'];

			$m = ManifestationQuery::create()->findByManifestationId($idArray);

		} else if ($date = $this->getRequest()->itemAt('data')) {
			$date1 = substr($date,0,4)."-".substr($date,4,2)."-".substr($date,6,2);
			$date2 = substr($date,8,4)."-".substr($date,12,2)."-".substr($date,14,2);
			$m = ManifestationQuery::create()
				->filterByDateUpdated($date1, Criteria::GREATER_EQUAL)
				->filterByDateUpdated($date2, Criteria::LESS_EQUAL)
				->find();
		} else {
		    $params = [];
            $fld = ['title','ean','date','publisher','author','biblevel','bid'];
            foreach ($this->getRequest() as $name=>$value) {
                if(in_array($name,$fld) && trim($value) != '') {
                    $params[$name]=$value;
                }
            }
            if(count($params)>0) {
                $response = $this->searchSolr($params);
                $idArray = array();
                if ($response)
                    foreach ($response['response']['docs'] as $key => $result)
                        $idArray[] = $result['Id'];
                $m = ManifestationQuery::create()->findByManifestationId($idArray);
            }
        }

		if (!$m || $m->count() < 1) {
			switch ($format) {
				case 'iso2907':
				case 'iso2709':
				case 'csv':
				case 'cdd':
					die('KO');
                    break;
                case 'json':
                    die(json_encode(['error'=>'KO']));
                    break;
				case 'turbomarc':
				case 'xml':
				default:
					die("<result code=\"KO\">EAN non riconosciuto o date non valide</result>");
			}
		}

		$resp = Prado::getApplication()->getResponse();

		switch ($format) {
            case 'json':
                $resp->setContentType('text/json');
                $resp->write(json_encode($res));
                break;
			case 'iso2709':
				$resp->setContentType('text/txt');
				foreach ($m as $man) {
					$iso = TurboMarc::createRecord($man->cacheTurboMarc(!$this->getNoCache()))
						->getISO2709();
					$resp->write($iso);
				}
				break;
			case 'csv':
				break;
			case 'cdd':
				$resp->setContentType('text/xml');
				$resp->write("<?xml version=\"1.0\" encoding=\"utf-8\" ?>\n<result code=\"OK\">");
                /** @var Manifestation $man */
				foreach ($m as $man) {


					$ean = trim($man->getEan());
					$isbn = trim($man->getIsbnissn());
					$tm = TurboMarcUtility::sanitize($man->cacheTurbomarc(true,false));
					$unimarc = $tm->getTXT();

					print "\n<manifestation>\n\t<bid>{$man->getManifestationId()}</bid>";
					if ($ean)
						print "\n\t<ean>{$ean}</ean>";
					if ($isbn)
						print "\n\t<isbn>{$isbn}</isbn>";
					print "\n\t<unimarc><![CDATA[".
						str_replace(array('&','<','>'),array('&amp;','&lt;','&gt;'),$unimarc).
						"]]></unimarc>";

					$class = LAuthorityManifestationQuery::create()
						->filterByManifestation($man)
						->findOneByLinkType(676);
					if ($class instanceof LAuthorityManifestation)
						print "\n\t<class code=\"{$class->getAuthority()->getClassCode()}\">\n\t\t".
							str_replace(array("\x1E","\x1F","\x1D",'&','<','>'),array('','','','&amp;','&lt;','&gt;'),
								$class->getAuthority()->getSortText())."\n\t</class>";
					unset($class);

					$subjects = LAuthorityManifestationQuery::create()
						->filterByManifestation($man)
						->condition('ge600', 'LAuthorityManifestation.LinkType >= ?', 600)
						->condition('le620',  'LAuthorityManifestation.LinkType <= ?', 620)
						->combine(array('ge600','le620'), Criteria::LOGICAL_AND)
						->find();

					foreach ($subjects as $link) {
						print "\n\t<subject id=\"{$link->getAuthority()->getAuthorityId()}\">\n\t\t".
							str_replace(array("\x1E","\x1F","\x1D",'&','<','>'),array('','','','&amp;','&lt;','&gt;'),
								$link->getAuthority()->getSortText())."\n\t</subject>";
						$link->clearAllReferences(true);
					}
					unset($subjects);
					print "\n</manifestation>";
					$man->clearAllReferences(true);
					unset($man);
				}
				$resp->write("\n</result>");
				break;
			case 'turbomarc':
			case 'xml':
			default:
				$resp->setContentType('text/xml');
				$c = TurboMarc::createCollection();
                /** @var Manifestation $man */
				foreach ($m as $man) {
					$r = TurboMarc::createRecord($man->cacheTurboMarc(!$this->getNoCache()));
					$r2 = $r->sortFields();
					$c->appendNode($r2);
				}
				$resp->write($c->asXML());
				break;
		}
		Prado::getApplication()->completeRequest();
	}

	public function setNoCache($value) {
		$this->_nocache = TPropertyValue::ensureBoolean($value);

	}

	public function getNoCache() {
		return $this->_nocache;
	}

	protected function searchSolr($searchParams) {
        $query = '';
        foreach ($searchParams as $k => $v)

            switch($k) {
                case 'title':
                    $v = str_replace(":"," ",$v);
                    //$query .= " +(mrc_d200_sa:({$v}))";
                    $query .= " +(fldin_txt_title:({$v}))";
                    break;
                case 'ean':
                    $v1 = Clavis::hyphenateStdNum($v);
                    $v2 = Clavis::normalizeStdNum($v);
                    $query .= " +(fldin_txt_numbers:{$v1} OR fldin_txt_numbers:{$v2})";
                    break;
                case 'date':
                    $query .= " +(sorti_date:({$v}))";
                    break;
                case 'biblevel':
                    $query .= " +(mrc_l_7:({$v}))";
                    break;
                case 'id':
                    $query .= " +(id:{$v})";
                    break;
                case 'bid':
                    $v = addslashes($v);
                    $query .= " +(id:({$v}) OR fldin_str_bid:(\"{$v}\"))";
                    break;
                case 'publisher':
                    $query .= " +(mrc_d210_sc:({$v}) OR fldin_txt_publisher:({$v}))";
                    break;
                case 'author':
                    $query .= " +(fldin_txt_author:({$v}))";
                    break;
            }

        $response = $this->getApplication()->getModule('search')->search($query,0,self::MAX_RESULTS);
        return $response;
    }

    protected function searchCatalog($searchParams)
    {
            $response = $this->searchSolr($searchParams);

            $ds = array();
            foreach ($response['response']['docs'] as $key => $result) {
                $man = ManifestationQuery::create()->findPk($result['Id']);
                if($man instanceof Manifestation)
                    $ds[] = $man->getManifestationGraph(
                        ['410','461','500','606','676','610','609','619','620','700','701','702'],
                        ['AB','CD','EF','KL','MN','OP','PK','GH','IJ','54'],
                        ['P','A','C','E','L','T','O','G','F']);
            }
            $ret = array(
                'Results'		=> $ds,
                'Count'			=> $response['response']['numFound']
            );

        return $ret;
    }
}
