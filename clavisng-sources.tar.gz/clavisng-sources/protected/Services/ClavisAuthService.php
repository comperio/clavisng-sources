<?php
/**
 * ClavisAuthService class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info
 * @comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Services
 */

/**
 * ClavisAuthService Class
 *
 * ClavisAuthService provides a method for authenticating users for external applications.
 * Takes three parameters:
 * <ul>
 * <li><strong>serviceParameter</strong> (i.e. index.php?export=format) identifies the
 * format for the output. Currently supported: "mlol".</li>
 * <li><strong>username</strong>: the username to verify.</li>
 * <li><strong>password</strong>: the password to verify (already crypted).</li>
 * </ul>
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Services
 * @since 2.5.0
 */
class ClavisAuthService extends AuthTService
{
	/**
	 * Runs the service.
	 */
	public function run()
	{
		$format = $this->getRequest()->getServiceParameter();
		$username = $this->getRequest()->itemAt('username');
		$pwdlib = $this->getRequest()->itemAt('pwdlib');
		$pwdusr = $this->getRequest()->itemAt('pwdusr');
		$p = $this->verifyUser($username,$pwdlib,$pwdusr);

        if (extension_loaded('newrelic')) {
            newrelic_set_appname ("ClavisNG - " . $this->getApplication()->getID());
            newrelic_name_transaction("AUTHSERVICE." . __METHOD__);
            newrelic_add_custom_parameter('FORMAT', $format );
            newrelic_add_custom_parameter('USERNAME', $username );
            newrelic_add_custom_parameter('PWDLIB', $pwdlib );
            newrelic_add_custom_parameter('PWDUSR', $pwdusr );
        }

		$resp = Prado::getApplication()->getResponse();
		switch ($format) {
			case 'mlol':
				$resp->setContentType('text/xml');
				$xml = new SimpleXMLElement('<response></response>');
				if ($p instanceof Patron) {
                    $xml->addChild('status','ok');
                    $xml->addChild('firstname',$p->getName());
                    $xml->addChild('lastname',$p->getLastname());
                    $xml->addChild('library',$p->getPreferredLibraryId());
                    $xml->addChild('patronstatus',$p->getPatronStatus());
                    $xml->addChild('opacenable',$p->getOpacEnable());
                    $xml->addChild('surfenable',$p->getSurfEnable());
                    $xml->addChild('voiceenable',$p->getVoiceEnable());
                    $xml->addChild('class',$p->getLoanClass());
                    $xml->addChild('age',$p->getPatronAge());
                    $xml->addChild('barcode',$p->getBarcode());
                    $xml->addChild('nationalid',$p->getNationalId());
                    $xml->addChild('patron_id',$p->getPatronId());
                    $xml->addChild('custom1', $p->getCustom1());
                    $xml->addChild('custom2', $p->getCustom2());
                    $xml->addChild('custom3', $p->getCustom3());
                    $xml->addChild('group','default');
				} else {
					$xml->addChild('status','ko');
				}
				$resp->write($xml->asXML());
				break;
			default:
				$resp->setContentType('text/txt');
				$resp->write('Format not implemented');
		}
		Prado::getApplication()->completeRequest();
	}

	/**
	 *
	 * @param string $username
	 * @param string $pwdlib
	 * @param string $pwdusr
	 * @return Patron/Librarian
	 */
	protected function verifyUser($username,$pwdlib,$pwdusr) {
		$crypt = Prado::getApplication()->getModule('crypt');
		// search among Librarians
		$user = LibrarianQuery::create()
			->filterByPatronId(null,Criteria::NOT_EQUAL)
			->filterBySecret($pwdlib)
			->findOneByUsername($username);
		if ($user instanceof Librarian)
			return $user->getPatron();
		$user = PatronQuery::create()
			->filterByOpacSecret($pwdusr)
			->findOneByOpacUsername($username);
		if ($user instanceof Patron)
			return $user;
		return null;
	}
}
