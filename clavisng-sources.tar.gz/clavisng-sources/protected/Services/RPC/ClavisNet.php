<?php
/**
 * Implements some api for radius and radius like net devices
 *
 * @author Cristian Chiarello <ciarez@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2009-2015 Comperio srl
 * @license http://www.comperio.it/license/
 */
class ClavisNet extends TRpcApiProvider
{
	
	protected $resourceHierarchy;
	protected $ips;
	protected $rms;
	protected $rulemanager;
	

	public function __construct( \TRpcServer $rpcServer )
	{
		parent::__construct( $rpcServer );
		$this->resourceHierarchy = 0;
		$this->ips = NULL;
		$this->rms = array();
		$this->rulemanager = $this->getApplication()->getModule('rulemanager');
	}
	
	/*
	 * This method call a clavisrad rcp service.
	 * Clavisrad send a radius disconnect to mikrotik to disconnect user
	 */
	public function disconnectMikrotikUser( $session_arr )
	{
		try
		{
			Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
				" Disconnecting user..."
				);
			//FIXME library_id from session_arr. Who need this method?
			$client= ClavisRadUtil::getClient(0);
			$res = $client->radiusDisconnect( $session_arr );
			if( isset( $res['result'] ) && isset( $res['result']['status'] ) && $res['result']['status'] == 'ack' )
			{
				Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
					" Done."
					);
				return TRUE;
			}
			else
			{
				Prado::log(__METHOD__ . "[" . __LINE__ . "] " . 
					" Sorry, an error occured."
					);
				if( isset( $res['result']['errors'] ))
				{
					$errs = $res['result']['errors'];
					$laste = '';
					foreach($errs as $k => $v)
					{
						$laste = $k . " :" . $v;
						Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
							" ERROR: ".$laste
							);
					}
					return FALSE;

				}
			}
		}
		catch (Exception $ex)
		{
			Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
				" EXCEPTION: ".$ex->getMessage()
				);
			return FALSE;
		}
	}
	
	
	public function closeSessions($slist)
	{
		$tend = time();
		foreach($slist as $s)
		{
			$logsessionid = "user {$s->getUsername()} id {$s->getResourceSessionId()} acctuniqueid {$s->getAcctuniqueid()} started at {$s->getAcctstarttime()}";
			
			$rsType = $s->getType();
			if($rsType == Resource::TYPE_MIKROTIK)
			{
				Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
					" closing mikrotik session {$logsessionid}",
					TLogger::DEBUG, 'NM_RPC');
				$client= ClavisRadUtil::getClient($s->getLibraryId());
				$res = $client->radiusDisconnect( $s->toArray() );
				if( isset( $res['result'] ) && isset( $res['result']['status'] ) && $res['result']['status'] == 'ack' )
				{
					Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
						" clavisrad close session OK {$logsessionid}",
						TLogger::DEBUG, 'NM_RPC');
				}
				else
				{
					Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
						" clavisrad close session FAIL {$logsessionid}",
						TLogger::DEBUG, 'NM_RPC');
					if( isset( $res['result']['errors'] ))
					{
						$errs = $res['result']['errors'];
						$laste = '';
						foreach($errs as $k => $v)
						{
							$laste = $k . " :" . $v;
							Prado::log(__METHOD__ . "[" . __LINE__ . "] " . 
								$laste,
								TLogger::DEBUG, 'NM_RPC');
						}
					}
				}
			}
			Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
				" closing session in clavis {$logsessionid}",
				TLogger::DEBUG, 'NM_RPC');
			$tstart = $s->getAcctstarttime(NULL)->getTimestamp();
			$telapsed = $tend - $tstart;
			$tsession = $s->getAcctsessiontime();
			if( !is_numeric($tsession) )
			{
				$tsession = 0;
			}
			
			$tassigned = $s->getConnectinfoStop();
			if( is_numeric($tassigned) )
			{
				$tassigned = intval($tassigned);
			}
			else
			{
				$tassigned = 0;
			}
			
			$timings = array();
			if( $tassigned > 0 )
			{
				$timings[] = $tassigned;
			}
			
			if( $telapsed > 0 && $telapsed < $tassigned)
			{
				$timings[] = $telapsed;
			}
			
			
			$timings[] = $tsession;
			
			
			$tclose = $tstart;
			$tmin=0;
			if( count($timings) > 0 )
			{
				//Take minimum from timings
				$tmin = min($timings);
				
				$tclose = $tstart + $tmin;
			}
			
			
			$s->setAcctsessiontime($tmin);
			$s->setAcctstoptime($tclose);
			$s->setAcctterminatecause('MULTIPLE-SESSIONS-ON-AUTH');
			$s->save();
		}
	}
	

	
	/*
	 * Perform freeradius authentication.
	 * @param array $radRequest $RAD_REQUEST perl hash from freeradius clavis perl script
	 * 
	 * Sep 23 15:45:18 [Info] [Uncategorized] array
	(
		[Framed-IP-Address] => '10.0.5.150'
		[Service-Type] => 'Login-User'
		[Calling-Station-Id] => 'CC:D2:9B:B7:E9:F0'
		[Called-Station-Id] => 'hss-wlan1'
		[NAS-IP-Address] => '192.168.1.252'
		[User-Password] => 'z'
		[NAS-Port-Id] => 'wlan1'
		[NAS-Port] => '2156920835'
		[NAS-Identifier] => 'MikroTik'
		[WISPr-Logoff-URL] => 'http://10.0.5.1/logout'
		[Mikrotik-Host-IP] => '10.0.5.150'
		[User-Name] => 'mazinga'
		[NAS-Port-Type] => 'Wireless-802.11'
		[Acct-Session-Id] => '80900003'
	)
	*/
	public function freeRadiusAuth( $radRequest )
	{
		$retVal = array("status"=>"ack","errors"=>array(),"data"=>array());

		try
		{
		    $cleanusername = trim($radRequest['User-Name']);
		    $usr = $radRequest['User-Name'];
		    $framedipaddress = $radRequest['Framed-IP-Address'];
		    $nasipaddress = $radRequest['NAS-IP-Address'];
		    $wisprlogoffurl =$radRequest['WISPr-Logoff-URL'];
		    $acctsessionid = $radRequest['Acct-Session-Id'];
		    $calledstationid = $radRequest['Called-Station-Id'];
		    $callingstationid = $radRequest['Calling-Station-Id'];
		    
		    
		    $reqdesc = " usr {$usr} (cleaned {$cleanusername}) resource {$nasipaddress} sid {$acctsessionid} from MAC {$callingstationid}";
		    Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
		    	$reqdesc,
		    	TLogger::DEBUG, 'NM_RPC');
		    
			if(  !array_key_exists( 'User-Password', $radRequest ) )
			{
				$retVal["status"] = "nak";
				$retVal["errors"]["AUTH_MISCONFIG"] = "Profilo hotspot - login non configurata correttamente (richiesto PAP)";
				Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
					" hotspot profile - login misconfigured (PAP required)",
					TLogger::ERROR);
				Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
					" hotspot profile - login misconfigured (PAP required)",
					TLogger::DEBUG, 'NM_RPC');
				return $retVal;
			}
			$pwd = $radRequest['User-Password'];
			
			
			
			$res = ResourceQuery::create()
				->findOneByName($nasipaddress);
			
			if( ! ($res instanceof Resource) )
			{
				$retVal["status"] = "nak";
				$retVal["errors"]["RESOURCE_NOT_FOUND"] = "Risorsa {$nasipaddress} non trovata";
				Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
					" resource {$nasipaddress} not found",
					TLogger::ERROR);
				Prado::log(__METHOD__ . " resource {$nasipaddress} not found", TLogger::DEBUG, 'NM_RPC');
				return $retVal;
			}
			
			if( $res->getResourceStatus() == Resource::STATUS_DISABLED )
			{
				$retVal["status"] = "nak";
				$retVal["errors"]["RESOURCE_DISABLED"] = "Risorsa {$nasipaddress} disabilitata";
				Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
					" resource {$nasipaddress} disabled",
					TLogger::ERROR);
				Prado::log(__METHOD__ . " resource {$nasipaddress} disabled", TLogger::DEBUG, 'NM_RPC');
				return $retVal;
			}
			

			switch( $res->getResourceHealthStatus() )
			{
				//When resource is faulty log only, continue anyway
				case Resource::HEALTH_STATUS_FAULTY:
					Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
						" faulty resource detected: {$nasipaddress}",
						TLogger::WARNING);
					break;
					
				case Resource::HEALTH_STATUS_BROKEN:
					$retVal["status"] = "nak";
					$retVal["errors"]["RESOURCE_BROKEN"] = "Dispositivo {$nasipaddress} danneggiato";
					Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
						" broken resource detected: {$nasipaddress}",
						TLogger::WARNING);
					Prado::log(__METHOD__ . " resource {$nasipaddress} broken", TLogger::DEBUG, 'NM_RPC');
					return $retVal;
			}
			
			//Search the user by it's web/opac username
			$patron = PatronQuery::create()
				->findOneByOpacUsername($cleanusername);
			
			
			//If not found
			if ( ! ($patron instanceof Patron) )
			{
				$retVal["status"] = "nak";
				$retVal["errors"]["USER_NOT_FOUND"] = "Utente {$cleanusername} non trovato";
				Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
					" patron {$cleanusername} not found",
					TLogger::ERROR);
				Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
					" patron {$cleanusername} not found",
					TLogger::DEBUG, 'NM_RPC');
				return $retVal;
			}
			
			//Is patron priviledged?
			$params = $this->getApplication()->getParameters();
			$isPrivPatron = ( isset($params['priv_loan_class'])  && $patron->getLoanClass() == $params['priv_loan_class'] );
			
			//Close opened sessions for this user
			$q = ResourceSessionQuery::create()
			->filterByUsername($cleanusername)
			->filterByAcctstoptime(NULL, Criteria::ISNULL);
			//Priviledged patron can have multiple session, one by MAC
			if( $isPrivPatron )
			{
			    $q->filterByCallingstationid($callingstationid);
			}
			$openedSessions = $q->orderByAcctstarttime('desc')->find();
			
			$scount = count($openedSessions);
			if( $scount > 0 )
			{
			    Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
			    	" {$scount} opened sessions found for user {$usr} device {$callingstationid}, closing...",
			    	TLogger::ERROR);
			    $this->closeSessions($openedSessions);
			}
			
			
			
			//Is patron password correct?
			$crypt = Prado::getApplication()->getModule("crypt");
			if( ! $crypt->PatronVerify( $pwd,$patron->getOpacSecret() ) )
			{
				//may be a librarian with linked patron but same username, different password
				$librarian = LibrarianQuery::create()->findOneByUsername($cleanusername);
				if( ( !($librarian instanceof Librarian) ) || (! $crypt->LibrarianVerify( $pwd, $librarian->getSecret() ) ) )
				{
					$retVal["status"] = "nak";
					$retVal["errors"]["USER_PWD_INVALID"] = "Password non valida per lo username " . $usr;
					Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
						" invalid password for {$usr}",
						TLogger::DEBUG, 'NM_RPC');
					PatronActionPeer::writePatronAction($patron->getPatronId(),
						$res->getLibraryId(),
						PatronActionPeer::ACCESS_FAILED, 
						"password errata");
					return $retVal;
				}
			}
			
			//Is patron surf enabled?
			$surfen = $patron->getSurfEnable();
			if ( $surfen != '1' )
			{
				$retVal["status"] = "nak";
				$retVal["errors"]["USER_NOT_SURF_ENABLED"] = "Utente {$cleanusername} non abilitato alla navigazione";
				Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
					" patron {$cleanusername} not surf enabled",
					TLogger::DEBUG, 'NM_RPC');
				PatronActionPeer::writePatronAction($patron->getPatronId(),
					$res->getLibraryId(),
					PatronActionPeer::ACCESS_FAILED, 
					"navigazione internet disabilitata");
				return $retVal;
			}
			
			
			//Is patron authorized to use services?
			$serviceen = $patron->getPatronStatus();
			if ( $serviceen != 'A' )
			{
				$retVal["status"] = "nak";
				$retVal["errors"]["USER_NOT_SERVICE_ENABLED"] = "Utente {$cleanusername} non abilitato ai servizi";
				Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
					" patron {$cleanusername} not service enabled",
					TLogger::DEBUG, 'NM_RPC');
				PatronActionPeer::writePatronAction($patron->getPatronId(),
					$res->getLibraryId(),
					PatronActionPeer::ACCESS_FAILED, 
					"utente non abilitato");
				return $retVal;
			}
			
			
			//Check for priviledged patron: if loan class match with loan class set on parameter of prado app, not parse rules
			if( $isPrivPatron )
			{
			    Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
			    	" priv user {$cleanusername} detect, cedits not set (loan class: param [{$params['priv_loan_class']}] patron [".$patron->getLoanClass() ."])",
			    	TLogger::DEBUG, 'NM_RPC');
			}
			else
			{
				$this->rulemanager->initVars( $patron, $res, $calledstationid, $framedipaddress, $callingstationid);
				$retVal = $this->rulemanager->parseRule( NULL );
			}
			
			
			/*
			 * Create a redirect url based on logoff url
			 * User can specify IP or DNS plus a custom page inside mikrotik: called url will be something like http://IP|DNS/x/y/custom_page
			 * Can also specify a custom complete url; if needed, some params can be used as IP DNS PATH.
			 * For ex.: http://www.mysite.com?action=redirect&hsip={IP}&hspath={PATH}
			 */
			$redirectUrl = $wisprlogoffurl;
			$awlu = explode("/", $wisprlogoffurl);
			//Prado::log(__METHOD__ . " wisprlogoffurl $wisprlogoffurl", TLogger::DEBUG, 'NM_RPC');
			//Prado::log(Prado::varDump( $awlu), TLogger::DEBUG, 'NM_RPC');
			$IP = $awlu[2];
			$awluItemsCount = count($awlu);
			$awluLastItemIndex = $awluItemsCount-1;
			$aPath = array();
			for($x=3; $x <= $awluLastItemIndex; $x++)
			{
				$aPath[]=$awlu[$x];
			}
			$wellcomeUrl = $res->getWellcomeUrl();
			
			if( ! is_null($wellcomeUrl) && $wellcomeUrl != '')
			{
				if( strpos($wellcomeUrl, "IP") === 0 )
				{
					$redirectUrl = str_replace('logout', substr($wellcomeUrl, 2), $wisprlogoffurl);
				}
				elseif( strpos($wellcomeUrl, "DNS") === 0 )
				{
					$wu=substr($wellcomeUrl, 3);
					//Prado::log(Prado::varDump( $awlu), TLogger::DEBUG, 'NM_RPC');
					$awlu[2] = $calledstationid;
					$awlu[$awluLastItemIndex] = $wu;
					$redirectUrl = implode("/", $awlu);
				}
				else
				{
					$redirectUrl = str_replace(array('{IP}','{DNS}','{PATH}'), array($IP, $calledstationid, implode('/',$aPath)), $wellcomeUrl);
				}
				$retVal["data"]["redirecturl"] = $redirectUrl;
			}
			
			//get complete patron info
			$retVal["data"]["patron"] = $patron->toArray();
			
			
			//Prado::log(Prado::varDump($retVal), TLogger::DEBUG, 'NM_RPC');
			return $retVal;
			
		} catch (Exception $ex) {
			Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
				" **** EXCEPTION " . $ex->getMessage(),
				TLogger::ERROR);
			Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
				" **** EXCEPTION " . $ex->getMessage(),
				TLogger::DEBUG, 'NM_RPC');
			$retVal["status"] = "nak";
			$retVal["errors"]["EXCEPTION"] = "Errore sul server clavis. Consultare i log di clavis";
			return $retVal;
		}
	}
	
	
	
	/*
	 * DEPRECATED
	 * Perform authentication.
	 * If resource is a mikrotik, nasipaddress is the wan ip of mikrotik and framedipaddress
	 * is the mk connected dev ip.
	 * If the resource is a pc, the 3rd and 4th params are the same ip (of the pc)
	 */
	public function radAuth($usr, $pwd, $framedipaddress, $nasipaddress, $wisprlogoffurl, $acctsessionid )
	{
		$retVal = array("status"=>"ack","errors"=>array(),"data"=>array());
		
		try
		{
			$res = ResourceQuery::create()
				->findOneByName($nasipaddress);
			
			if( ! ($res instanceof Resource) )
			{
				$retVal["status"] = "nak";
				$retVal["errors"]["RESOURCE_NOT_FOUND"] = "Risorsa {$nasipaddress} non trovata";
				Prado::log(__METHOD__ . " " . __LINE__ .
					" resource {$nasipaddress} not found",
					TLogger::DEBUG, 'NM_RPC');
				return $retVal;
			}
			
			
			//Search the user by it's web/opac username
			$patron = PatronQuery::create()
				->findOneByOpacUsername($usr);
			
			
			//If not found
			if ( ! ($patron instanceof Patron) )
			{
				$retVal["status"] = "nak";
				$retVal["errors"]["USER_NOT_FOUND"] = "Utente {$usr} non trovato";
				Prado::log(__METHOD__ . " " . __LINE__ .
					" patron {$usr} not found",
					TLogger::DEBUG, 'NM_RPC');
				return $retVal;
			}
			
			
			/*
			 * Check if active session exist: if found, don't auth user
			 */
			
			$ss = $this->getOpenSessions($patron->getOpacUsername());
			
			if( isset($ss['byuser'][0]) )
			{
				$retVal["status"] = "nak";
				$retVal["errors"]["USER_CONNECTED"] = "Hai una sessione attiva. Per favore esegui un logout nella postazione che stavi usando o chiedi a un operatore di chiuderla da clavis.";
				Prado::log(__METHOD__ . " " . __LINE__ . " patron {$usr} have active session (acctuniqueid {$ss['byuser'][0]->getAcctuniqueid()})", TLogger::DEBUG, 'NM_RPC');
				PatronActionPeer::writePatronAction($patron->getPatronId(),
					$res->getLibraryId(),
					PatronActionPeer::ACCESS_FAILED, 
					"rilevata sessione ancora aperta (ID {$ss['byuser'][0]->getAcctuniqueid()})");
				return $retVal;
			}

						
			$surfen = $patron->getSurfEnable();
			if ( $surfen != '1' )
			{
				$retVal["status"] = "nak";
				$retVal["errors"]["USER_NOT_SURF_ENABLED"] = "Utente {$usr} non abilitato alla navigazione";
				Prado::log(__METHOD__ . " " . __LINE__ .
					" patron {$usr} not surf enabled",
					TLogger::DEBUG, 'NM_RPC');
				PatronActionPeer::writePatronAction($patron->getPatronId(),
					$res->getLibraryId(),
					PatronActionPeer::ACCESS_FAILED, 
					"navigazione internet disabilitata");
				return $retVal;
			}
			
			$serviceen = $patron->getPatronStatus();
			if ( $serviceen != 'A' )
			{
				$retVal["status"] = "nak";
				$retVal["errors"]["USER_NOT_SERVICE_ENABLED"] = "Utente {$usr} non abilitato ai servizi";
				Prado::log(__METHOD__ . " " . __LINE__ .
					" patron {$usr} not service enabled",
					TLogger::DEBUG, 'NM_RPC');
				PatronActionPeer::writePatronAction($patron->getPatronId(),
					$res->getLibraryId(),
					PatronActionPeer::ACCESS_FAILED, 
					"utente non abilitato");
				return $retVal;
			}
			
			
			$crypt = Prado::getApplication()->getModule("crypt");
			//Check password
			if( ! $crypt->PatronVerify($pwd,$patron->getOpacSecret() ) )
			{
				$retVal["status"] = "nak";
				$retVal["errors"]["USER_PWD_INVALID"] = "Password non valida per lo username " . $usr;
				Prado::log(__METHOD__ . " " . __LINE__ .
					" invalid password for {$usr}",
					TLogger::DEBUG, 'NM_RPC');
				PatronActionPeer::writePatronAction($patron->getPatronId(),
					$res->getLibraryId(),
					PatronActionPeer::ACCESS_FAILED, 
					"password errata");
				return $retVal;
			}

			
			$this->rulemanager->initVars( $patron, $res, NULL, $framedipaddress);
			$retVal = $this->rulemanager->parseRule( NULL );
						
			
			//return complete patron info
			$retVal["data"]["patron"] = $patron->toArray();
			
			//@TODO: parametrize url or use status page (default after login)
			if( !is_null( $wisprlogoffurl ) && $wisprlogoffurl != '')
			{
				//return the redirection url
				$tk = explode('/', $wisprlogoffurl);

				$ntk = count($tk);
				$hsip = $tk[$ntk - 2];
				$afterloginurl= 'http://' . $hsip . '/wellcome.html';
				//Prado::log(__METHOD__ . " " . __LINE__ . "  myurl {$myurl} ", TLogger::DEBUG);
				//$retVal["data"]["redirecturl"] = 'http://'.$calledstationid.'/wellcome.html';
				$retVal["data"]["redirecturl"] = $afterloginurl;
			}
			
			
			//Prado::log(Prado::varDump($retVal));
			return $retVal;
			
		} catch (Exception $ex) {
			Prado::log(__METHOD__ .
				" **** EXCEPTION " . $ex->getMessage(),
				TLogger::DEBUG, 'NM_RPC');
			$retVal["status"] = "nak";
			$retVal["errors"]["EXCEPTION"] = "Errore sul server clavis. Consultare i log di clavis";
			return $retVal;
		}
	}
	
	
	
	/*
	 *************************************************************************************************************************
	 * Async methods for start, update and close a session
	 * This methods are called from a non mikotik systems for remote management of clavis session 
	 ************************************************************************************************************************* 
	 */
	
	
	/*
	 * Search open session by user and id: always search session by same user but different id
	 * to find potential old session not correctly closed
	 */
	public function getOpenSessions( $usr, $acctuniqueid=NULL )
	{
		$sessions = array();
		
		if( $acctuniqueid != NULL)
		{
			$sessions['byuser'] = ResourceSessionQuery::create()
				->filterByUsername($usr)
				->where(" acctstoptime IS NULL AND acctuniqueid != '" . $acctuniqueid ."' ")
				->orderBy( "resource_session_id", Criteria::DESC)
				->find();
			
			
			$sessions['byid'] = ResourceSessionQuery::create()
				->filterByUsername($usr)
				->filterByAcctuniqueid($acctuniqueid)
				->where(" acctstoptime IS NULL ")
				->orderBy( "resource_session_id", Criteria::DESC)
				->find();
		}
		else
		{
			$sessions['byuser'] = ResourceSessionQuery::create()
				->filterByUsername($usr)
				->where(" acctstoptime IS NULL ")
				->orderBy( "resource_session_id", Criteria::DESC)
				->find();
		}
		
		return $sessions;

	}
	
	
	public function getLastClosedSession( $usr, $acctuniqueid )
	{
		return ResourceSessionQuery::create()
				->filterByUsername($usr)
				->filterByAcctuniqueid($acctuniqueid)
				->where(" acctstoptime IS NOT NULL AND DATE(acctstarttime) = CURDATE() ")
				->orderBy( "resource_session_id", Criteria::DESC)
				->findOne();
	}
	
	
	
	/**
	 * Start an independent resource session on clavis (non mikrotik devices)
	 * @param array $sessiondata array emulating radius req
	 * @return array with response info
	 */
	public function startSession( $sessiondata )
	{
		$retVal = array("status"=>"ack","errors"=>array(),"data"=>array());
		
		try
		{
			//Prado::log(Prado::varDump( $sessiondata ));
			$sessiondata = $sessiondata[0]; //node-json-rpc ... ???
			//Prado::log(Prado::varDump( $sessiondata ));
			
			$username = $sessiondata['username'];
			$nasname = $sessiondata['nasname'];
			$credits = $sessiondata['credits'];
			
			$res = ResourceQuery::create()
				->findOneByName($nasname);
			
			if( ! ($res instanceof Resource) )
			{
				$retVal["status"] = "nak";
				$retVal["errors"]["RESOURCE_NOT_FOUND"] = "Risorsa {$nasname} non trovata";
				Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
					" resource {$nasname} not found"
					);
				return $retVal;
			}
			
			
			//Search the user by it's web/opac username
			$patron = PatronQuery::create()
				->findOneByOpacUsername($username);
			
			
			//If not found
			if ( ! ($patron instanceof Patron) )
			{
				$retVal["status"] = "nak";
				$retVal["errors"]["USER_NOT_FOUND"] = "Utente {$username} non trovato";
				Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
					" patron {$username} not found"
					);
				return $retVal;
			}
			
			
			
			$uid = uniqid();
			
			$newrs = new ResourceSession();

			

				
			if( ! $this->assertField( $newrs->getFramedipaddress() ) ) $newrs->setFramedipaddress($sessiondata['framedipaddress']);
			if( ! $this->assertField( $newrs->getNasporttype() ) ) $newrs->setNasporttype($sessiondata['nasporttype']);
			if( ! $this->assertField( $newrs->getCalledstationid() ) ) $newrs->setCalledstationid($sessiondata['calledstationid']);
			if( ! $this->assertField( $newrs->getCallingstationid() ) ) $newrs->setCallingstationid($sessiondata['callingstationid']);

			
			
			$newrs->setResourceId($res->getResourceId());
			$newrs->setLibraryId($res->getLibraryId());
			$newrs->setPatronId($patron->getPatronId());
			
			if( ! $this->assertField( $newrs->getNasname() ) ) $newrs->setNasname($res->getName());
			if( ! $this->assertField( $newrs->getShortname() ) ) $newrs->setShortname($res->getShortname());
			if( ! $this->assertField( $newrs->getType() ) ) $newrs->setType($res->getType());
			if( ! $this->assertField( $newrs->getDescription() ) ) $newrs->setDescription($res->getDescription());
			
			if( ! $this->assertField( $newrs->getAcctsessionid() ) ) $newrs->setAcctsessionid($uid);
			if( ! $this->assertField( $newrs->getAcctuniqueid() ) ) $newrs->setAcctuniqueid($uid);
			if( ! $this->assertField( $newrs->getUsername() ) ) $newrs->setUsername($username);

			
			$newrs->setAcctstarttime(  time() );
			$newrs->setAcctsessiontime( 0 );
			

			$newrs->setConnectinfoStop($credits);
			
			$newrs->save();
			
			$retVal['data'] = $newrs->toArray();
			
			Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
				" {$username} done."
				);
			
			return $retVal;
			
		} 
		catch (Exception $ex) 
		{
			Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
				" EXCP " . $ex->getMessage()
				);
			Prado::log( $ex->getTraceAsString() );
			$retVal["status"] = "nak";
			$retVal["errors"]["EXCEPTION"] = "Errore sul server clavis. Consultare i log di clavis";
			return $retVal;
		}
	}
	
	public function assertField( $field )
	{
		if(!is_null( $field) && $field != '') return TRUE;
		else return FALSE;
	}
	
	
	
	
	
	/*
	 * Update an independent resource session on clavis
	 */
	public function updateSession( $sessiondata )
	{
		$retVal = array("status"=>"ack","errors"=>array(),"data"=>array());
		
		try
		{
			//Prado::log(Prado::varDump( $sessiondata ));
			$sessiondata = $sessiondata[0];
			$username = $sessiondata['username'];
			$acctuniqueid = $sessiondata['acctuniqueid'];
			$acctsessiontime = $sessiondata['acctsessiontime'];
			
			// TODO: if other open session found, what we do?
			$ss = $this->getOpenSessions($username, $acctuniqueid);
			
			if( ! array_key_exists( 'byid', $ss ) || ! isset($ss['byid'][0]) )
			{
				$lastclose  = $this->getLastClosedSession($username, $acctuniqueid);
				//Prado::log(Prado::varDump($lastclose));
				if($lastclose instanceof ResourceSession)
				{
					$retVal['data'] = $lastclose->toArray();
					return $retVal;
				}
				else
				{
					$retVal["status"] = "nak";
					$retVal["errors"]["SESSION_NOT_FOUND_ON_UPDT"] = "Errore in clavis (sessione non trovata)";
					Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
						" unable to update session with id {$acctuniqueid} - not found"
						);
					return $retVal;
				}
			}
			
			
			$s = $ss['byid'][0];
			if($s instanceof ResourceSession)
			{
				//Check congruence
				$enddt = new DateTime();
				//Prado::log(__METHOD__ . " line " . __LINE__ . $enddt->format('Y-m-d H:i:s'));
				//$startdt = new DateTime();
				//$startdt->setTimestamp($s->getAcctstarttime());
				$startdt = $s->getAcctstarttime(NULL);
				//Prado::log(__METHOD__ . " line " . __LINE__ . $startdt->format('Y-m-d H:i:s'));
				
				$diff = $enddt->diff($startdt);
				//Prado::log(Prado::varDump( $diff ));
				
				$secTot = $diff->s + ($diff->i * 60) + ($diff->h * 3600);
				
				if($secTot < $acctsessiontime)
				{
					Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
						" WARNING!! Give me {$acctsessiontime} seconds but difference between start and now is {$secTot} seconds. "
						);	
				}
				$s->setAcctsessiontime( $secTot );
				$s->save();
				
				$retVal['data'] = $s->toArray();
				
			}
			else
			{
				$retVal["status"] = "nak";
				$retVal["errors"]["SESSION_NOT_FOUND_ON_UPDT"] = "Errore in clavis (sessione non valida)";
				Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
					"  ResourceSession object not valid"
					);
			}
			return $retVal;
			
		} 
		catch (Exception $ex) 
		{
			Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
				" EXCP " . $ex->getMessage()
				);
			$retVal["status"] = "nak";
			$retVal["errors"]["EXCEPTION"] = "Errore sul server clavis. Consultare i log di clavis";
			return $retVal;
		}
	}
	
	
	
	/**
	 * Stop an independent resource session on clavis (used by non mikrotik devices)
	 * @param array $sessiondata array emulating radius req
	 * @return array with response info
	 */
	public function endSession( $sessiondata )
	{
		$retVal = array("status"=>"ack","errors"=>array(),"data"=>array());
		
		try
		{
			$sessiondata = $sessiondata[0];
			$username = $sessiondata['username'];
			$acctuniqueid = $sessiondata['acctuniqueid'];
			$acctsessiontime = $sessiondata['acctsessiontime'];
			$framedipaddress = $sessiondata['framedipaddress'];
			$calledstationid = $sessiondata['calledstationid'];
			$callingstationid = $sessiondata['callingstationid'];
			
			// TODO: if other open session found, what we do?
			$ss = $this->getOpenSessions($username, $acctuniqueid);
			
			if( ! array_key_exists( 'byid', $ss ) || ! isset($ss['byid'][0]) )
			{
				$lastclose  = $this->getLastClosedSession($username, $acctuniqueid);
				//Prado::log(Prado::varDump($lastclose));
				if($lastclose instanceof ResourceSession)
				{
					$retVal['data'] = $lastclose->toArray();
					return $retVal;
				}
				else
				{
					$retVal["status"] = "nak";
					$retVal["errors"]["SESSION_NOT_FOUND_ON_UPDT"] = "Errore in clavis (sessione non trovata)";
					Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
						" unable to close session with id {$acctuniqueid} - not found"
						);
				}
			}
			
			
			$s = $ss['byid'][0];
			if($s instanceof ResourceSession)
			{

				
				$res = ResourceQuery::create()
				->findOneByResourceId($s->getResourceId());
			
				if( ! ($res instanceof Resource) )
				{
					$retVal["status"] = "nak";
					$retVal["errors"]["RESOURCE_NOT_FOUND"] = "Risorsa {$resourcename} non trovata";
					Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
						" resource {$resourcename} not found"
						);
					return $retVal;
				}


				//Search the user by it's web/opac username
				$patron = PatronQuery::create()
					->findOneByPatronId($s->getPatronId());


				//If not found
				if ( ! ($patron instanceof Patron) )
				{
					$retVal["status"] = "nak";
					$retVal["errors"]["USER_NOT_FOUND"] = "Utente {$usr} non trovato";
					Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
						" patron {$usr} not found"
						);
					return $retVal;
				}
				
				$this->rulemanager->initVars( $patron, $res, $calledstationid, $framedipaddress, $callingstationid);
				$this->rulemanager->updateCredits($s, $acctsessiontime);//THIS JUST SET STOPTIME AND SESSIONTIME
				
				//Prado::log(__METHOD__ . " line " . __LINE__ . " resource session id ".$s);
				//$retVal = $this->updateCreditsHierarchy($patron, $res, $s, $amount);
				Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
					" {$username} done."
					);
				
				$retVal['data'] = $s->toArray();
			}
			else
			{
				$retVal["status"] = "nak";
				$retVal["errors"]["SESSION_NOT_FOUND_ON_UPDT"] = "Errore interno. Non trovo la sessione da chiudere";
				Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
					" resource to close not found"
					);
			}
			return $retVal;
			
		} 
		catch (Exception $ex) 
		{
			Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
				" EXCP " . $ex->getMessage()
				);
			$retVal["status"] = "nak";
			$retVal["errors"]["EXCEPTION"] = "Errore sul server clavis. Consultare i log di clavis";
			return $retVal;
		}
	}
	
	/*
	 *************************************************************************************************************************
	 * Async methods end
	 ************************************************************************************************************************* 
	 */
	
	
	
	
	/*
	 * Fix old session with duplicate acctuniqueid if exist
	 */
	public function fixAcctuniqueid($sessions)
	{
		foreach($sessions as $s)
		{
			try
			{
				$rsfix = ResourceSessionQuery::create()
					->filterByAcctuniqueid($s['acctuniqueid'])
					->filterByAcctStarttime($s['acctstarttime'], Criteria::NOT_EQUAL)
					->find();

				foreach($rsfix as $sfix)
				{
					$newid = $sfix->getResourceSessionId() . $sfix->getAcctuniqueid();
					Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
						" updating acctuniqueid from {$s['acctuniqueid']} to {$newid}"
						);
					$sfix->setAcctuniqueid($newid);
					$sfix->save();
				}
			}
			catch (Exception $ex)
			{
				Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
					" EXCP usr {$s['username']} acctuniqueid {$s['acctuniqueid']} acctstarttime {$s['acctstarttime']}" . $ex->getMessage()
					);
			}
		}
	}
	
	
	/*
	 * If multiple session found for user-mac take only the most recent.
	 */
	public function closeInvalidSessions( $user )
	{
	    $sbystartdate = ResourceSessionQuery::create()
	    ->filterByUsername($user)
	    ->filterByAcctstoptime(NULL, Criteria::ISNULL) /*open only*/
	    ->orderByCallingstationid()
	    ->orderByAcctstarttime() /*order by start (last is the newer)*/
	    ->find();
	    //for each mac take all sessions
	    $sbymac = array();
	    foreach($sbystartdate as $s)
	    {
	        $mac = $s->getCallingstationid();
	        $sbymac[$mac][]=$s;
	    }
	    
	    //for each mac check how many sesson is open (should be only one)
	    foreach($sbymac as $mac => $s)
	    {
	        $nsessionbymac = count($sbymac[$mac]);
	        //If more than one session is open for this user-mac
	        if($nsessionbymac > 1)
	        {
	            Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
	            	" #### WARNING #### MULTIPLE SESSION ON CLAVIS for {$user} on MAC {$mac} Closing...",
	            	TLogger::DEBUG, 'NM_RPC');
	            //remove the last (sould be the current real session)
	            array_pop($sbymac[$mac]);
	            //and close all other
	            $this->closeSessions($sbymac[$mac]);
	        }
	    }
	}
	
	/**
	 * Used to align freeradius radacct with clavis. If received sessions are correctly saved into clavis,
	 * clavisrad on freereadius server remove record.  Update session if exists else create a new one.
	 * May need a performance monitoring. See /etc/freeradius/clavis.pl on freeradius server.
	 * Used by mikrotik devices
	 * @param array $sessions radius sessions
	 * @return array See retval variable
	 */
	public function importsessions( $sessions )
	{
		$retVal = array("status"=>"ack","errors"=>array(),"data"=>array());
		
		//$this->fixAcctuniqueid($sessions);
		
		$userSessions = array();
		$badDateTime = array();
		
		$con = Propel::getConnection();
		$con->beginTransaction();
		
		try
		{
			$imported = 0;
			$updated = 0;
			$nSession = count($sessions);
			$newSession;
			$curdate = date("Y-m-d");

			Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
				"************** {$nSession} sessions received ************",
				TLogger::DEBUG, 'NM_RPC');
			foreach($sessions as $s)
			{
				$rs = NULL;
				$susername = $s['username'];
				$scleanusername = trim($susername);
				$sid = $s['acctsessionid'];
				$suid = $s['acctuniqueid'];
				$sstart = $s['acctstarttime'];
				$sstop = $s['acctstoptime'];
				$sresname = $s['nasname'];
				$smacaddr = $s['callingstationid'];
				$calledstationid = $s['calledstationid'];
				$framedipaddress = $s['framedipaddress'];
				
				
				$insessionid = "usr {$susername} cleaned ({$scleanusername}) acctsessionid = {$sid} acctuniqueid {$suid} starttime {$sstart} resource {$sresname}";
				
				Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
					" incoming session: {$insessionid}. Checking...",
					TLogger::DEBUG, 'NM_RPC');
				
				$userSessions[$scleanusername][] = $s;
				
				//check  session date: if not valid add to array and use BAD_MKTK_DATE log key for log parsing
				$sstartdate = explode(" ", $sstart)[0];
				if($sstartdate != $curdate)
				{
					$desc = $s['description'];
					Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
						" #### ERROR #### radius session with wrong/old date [libid/url: {$desc} res: {$sresname}]",
						TLogger::DEBUG, 'NM_RPC');
					Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
						" #### ERROR #### BAD_MKTK_DATE radius session with wrong/old date [libid/url: {$desc} res: {$sresname}]"
						);
					if( ! in_array($sresname, $badDateTime, TRUE)) $badDateTime[] = $sresname;
					continue;
				}
				
				
				$pid = NULL;
				Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
					" Search patron with username {$scleanusername}",
					TLogger::DEBUG, 'NM_RPC');
				$patron = PatronQuery::create()
					->filterByOpacUsername($scleanusername)
					->findOne();
				if($patron instanceof Patron)
				{
					$pid = $patron->getPatronId();
					Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
						" patron found patron_id={$pid}",
						TLogger::DEBUG, 'NM_RPC');
				}
				else
				{
					//throw new Exception(__METHOD__ . "Invalid patron detected");
					Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
						" #### ERROR #### PATRON {$scleanusername} MISSING ON CLAVIS!?!?!?!");
					Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
						" #### ERROR #### PATRON {$scleanusername} MISSING ON CLAVIS!?!?!?!",
						TLogger::DEBUG, 'NM_RPC');
					continue;
				}

				$rid = NULL;
				$rlibid = NULL;
				Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
					" Search resource with name {$sresname}",
					TLogger::DEBUG, 'NM_RPC');
				$res = ResourceQuery::create()->findOneByName($sresname);
				if($res instanceof Resource)
				{
					$rid = $res->getResourceId();
					$rlibid = $res->getLibraryId();
					Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
						" resource found resource_id={$rid}",
						TLogger::DEBUG, 'NM_RPC');
				}
				else
				{
					//throw new Exception(__METHOD__ . "Invalid resource detected");
					Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
						" #### ERROR #### RESOURCE {$sresname} MISSING ON CLAVIS!?!?!?!");
					Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
						" #### ERROR #### RESOURCE {$sresname} MISSING ON CLAVIS!?!?!?!",
						TLogger::DEBUG, 'NM_RPC');
					continue;
				}
				

				$rs = ResourceSessionQuery::create()
				    ->filterByUsername($scleanusername)
					->filterByAcctsessionid($sid)
					->filterByCallingstationid($smacaddr)
					->filterByNasname($sresname)
					->where("DATE(acctstarttime) = '{$sstartdate}'")
				    ->findOne();

				if( ! $rs instanceof ResourceSession)
				{
					$rs = new ResourceSession();
					$newSession = TRUE;
					Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
						" {$insessionid} INSERT",
						TLogger::DEBUG, 'NM_RPC');
				}
				else
				{
					/*Avoid update credits (and other things) if session already imported and closed*/
					$ast = $rs->getAcctstoptime();
					$atc = $rs->getAcctterminatecause();
					$rsjson = $rs->toJSON();
					/*
					if(  ! is_null( $ast ) || $ast != '' )
					{
						Prado::log(__METHOD__ . " {$insessionid} IGNORE BECAUSE CLOSED ON {$ast}",TLogger::DEBUG, 'NM_RPC');
						continue;
					}
					else
					{
						Prado::log(__METHOD__ . " {$insessionid} UPDATE",TLogger::DEBUG, 'NM_RPC');
					}*/
					
					Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
						" {$insessionid} UPDATE",
						TLogger::DEBUG, 'NM_RPC');
					if( $ast != $sstop)
					{
					    $updtmsg = __METHOD__ . " {$insessionid} acctstoptime differ (may be a close) - incoming [{$sstop}] local stoptime [{$ast}]";
					    if( ! is_null($ast) )
					    {
					        $updtmsg .= " local json {$rsjson} this will be updated";
					    }
					    Prado::log($updtmsg, TLogger::DEBUG, 'NM_RPC');
					}
					
					$newSession = FALSE;
				}

				$ownnfo = explode("|", $s['description']);
				$lib = $ownnfo[0];

				$rs->setPatronId($pid);
				$rs->setResourceId($rid);
				$rs->setLibraryId($rlibid);
				$rs->setNasname($s['nasname']);
				$rs->setShortname($s['shortname']);
				$rs->setType($s['type']);
				$rs->setPorts($s['ports']);
				$rs->setSecret($s['secret']);
				$rs->setServer($s['server']);
				$rs->setCommunity($s['community']);
				$rs->setDescription($s['description']);
				$rs->setAcctsessionid($s['acctsessionid']);
				$rs->setAcctuniqueid($s['acctuniqueid']);
				$rs->setUsername($scleanusername);
				$rs->setGroupname($s['groupname']);
				$rs->setRealm($s['realm']);
				$rs->setNasipaddress($s['nasipaddress']);
				$rs->setNasportid($s['nasportid']);
				$rs->setNasporttype($s['nasporttype']);
				$rs->setAcctstarttime($s['acctstarttime']);
				$rs->setAcctstoptime($s['acctstoptime']);
				$rs->setAcctsessiontime($s['acctsessiontime']);
				$rs->setAcctauthentic($s['acctauthentic']);
				$rs->setConnectinfoStart($s['connectinfo_start']);
				//Used to store session timeout
				//$rs->setConnectinfoStop($s['connectinfo_stop']);
				$rs->setAcctinputoctets($s['acctinputoctets']);
				$rs->setAcctoutputoctets($s['acctoutputoctets']);
				$rs->setCalledstationid($s['calledstationid']);
				$rs->setCallingstationid($s['callingstationid']);
				$rs->setAcctterminatecause($s['acctterminatecause']);
				$rs->setServicetype($s['servicetype']);
				$rs->setFramedprotocol($s['framedprotocol']);
				$rs->setFramedipaddress($s['framedipaddress']);
				$rs->setAcctstartdelay($s['acctstartdelay']);
				$rs->setAcctstopdelay($s['acctstopdelay']);
				$rs->setXascendsessionsvrkey($s['xascendsessionsvrkey']);

				
				$this->rulemanager->initVars( $patron, $res, $calledstationid, $framedipaddress, $smacaddr );
				/*Starting session, store assigned credits to ConnectInfoStop field so connected device can read it*/
				if($newSession)
				{
					$rv = $this->rulemanager->parseRule( NULL );
					$rs->setConnectinfoStop($rv['data']['credits']);
				}
				
				/*This is a closing session*/
				if($s['acctstoptime'] != NULL)
				{
					$this->rulemanager->updateCredits(NULL, $s['acctsessiontime']);
				}
				
				$rs->save();
			
				if($newSession)
				{
					$imported++;
				}
				else
				{
					$updated++;
				}
				
				
			}
			$con->commit();
			
			
			
			
			foreach($userSessions as $usr => $us)
			{
				$nus = count($us);
				if($nus > 1)
				{
					Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
						" #### WARNING #### MULTIPLE SESSION FROM RADIUS for {$usr}",
						TLogger::DEBUG, 'NM_RPC');
					$jsonsessions = json_encode($us);
					Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
						" sessions: {$jsonsessions}",
						TLogger::DEBUG, 'NM_RPC');
					Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
						" #### WARNING #### MULTIPLE SESSION FROM RADIUS for {$usr}");
				}
                $this->closeInvalidSessions($usr);
			}

			
			// Check all resources with bad date
			foreach($badDateTime as $bdt)
			{
				$res = ResourceQuery::create()->findOneByName($bdt);
				if($res instanceof Resource)
				{
					$cl = ChangelogQuery::create()
					->filterByObjectId($res->getResourceId())
					->filterByObjectClass('Resource')
					->filterByEventDate(array("min"=>$curdate." 00:00:00", "max"=>$curdate." 23:59:59"))
					->findOne();
					if( ! ($cl instanceof Changelog))
					{
						$cldesc="NM: dispositivo ".$bdt." con data errata";
						/*
						 * ChangelogPeer::logAction('Resource', ChangelogPeer::LOG_ERROR, 1, $cldesc, $res->getResourceId());
						 * not set library id
						 */
						$entry = new Changelog();
						$entry->setEventDate(time());
						$entry->setEventType(ChangelogPeer::LOG_ERROR);
						$entry->setEventDescription($cldesc);
						$entry->setObjectClass('Resource');
						$entry->setObjectId($res->getResourceId());
						$entry->setUserClass('ClavisLibrarian');
						$entry->setUserId(1);
						$entry->setSessionId(null);
						$entry->setLibraryId($res->getLibraryId());
						$entry->save();
					}
				}
			}
			
			Prado::log(__METHOD__ . "[" . __LINE__ . "] "  .
				"Imported {$imported} updated {$updated}\n\n",
				TLogger::DEBUG, 'NM_RPC');
			return $retVal;
		}
		catch (Exception $ex)
		{
			$con->rollBack();
			Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
				" EXCP " . $ex->getMessage()
				);
			$retVal["status"] = "nak";
			$retVal["errors"]["EXCEPTION"] = "Errore sul server clavis. Consultare i log di clavis";
			return $retVal;
		}
				
	}
	
	protected function checkLibrarian($lusr, $lpwd)
	{
		$retval = FALSE;
		$crypt = Prado::getApplication()->getModule("crypt");
		$l = LibrarianQuery::create()->findOneByUsername($lusr);
		if($l instanceof Librarian)
		{
			$retval = $crypt->LibrarianVerify($lpwd,$l->getSecret());
		}
		return $retval;
	}
	
	public function setResource($lusr, $lpwd, $params)
	{
		$retVal = array("status"=>"ack","errors"=>array(),"data"=>array());
		if($this->checkLibrarian($lusr, $lpwd))
		{
			$rs = ResourceQuery::create();
			if(isset($params["library_id"]))
			{
				$rs->filterByLibraryId($params["library_id"]);
			}
			if(isset($params["name"]))
			{
				$rs->filterByName($params["name"]);
			}
			$r = $rs->findOne();
			
			//If resource exists update else create it
			if( !($r instanceof Resource ) )
			{
				$r = new Resource();
			}
			
			if(isset($params["library_id"]))
			{
				$r->setLibraryId($params["library_id"]);
			}
			if(isset($params["type"]))
			{
				$r->setType($params["type"]);
			}
			if(isset($params["name"]))
			{
				$r->setName($params["name"]);
			}
			if(isset($params["shortname"]))
			{
				$r->setShortname($params["shortname"]);
			}
			if(isset($params["secret"]))
			{
				$r->setSecret($params["secret"]);
			}
			if(isset($params["cost"]))
			{
				$r->setCost($params["cost"]);
			}
			if(isset($params["conf"]))
			{
				$r->setConf($params["conf"]);
			}
			if(isset($params["info"]))
			{
				$r->setInfo($params["info"]);
			}
			try 
			{
				$r->save();
			}
			catch (Exception $e)
			{
				Prado::log(__METHOD__ . "[" . __LINE__ . "] " . 
					$e->getTraceAsString()
					);
				$retVal["status"] = "nak";
				$retVal["errors"][] = "INTERNAL_ERROR";
			}
		}
		else
		{
			$retVal["status"] = "nak";
			$retVal["errors"][] = "NOT_AUTHORIZED";
			Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
				" not authorized"
				);
		}
		return $retVal;
	}
	
	public function getResource($lusr, $lpwd, $params)
	{
		$retVal = array("status"=>"ack","errors"=>array(),"data"=>array());
		if($this->checkLibrarian($lusr, $lpwd))
		{
			$rs = ResourceQuery::create();
			if(isset($params["library_id"]))
			{
				$rs->filterByLibraryId($params["library_id"]);
			}
			if(isset($params["name"]))
			{
				$rs->filterByName($params["name"]);
			}
			$r = $rs->findOne();
			if($r instanceof Resource)
			{
				$retVal["data"] = $r->toArray();
				$retVal["data"]["Conf"] = json_decode($r->getConf());
			}
			else 
			{
				$retVal["status"] = "nak";
				$retVal["errors"][] = "NOT_FOUND";
				Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
					" not found",
					TLogger::DEBUG, 'NM_RPC');
			}
		}
		else
		{
			$retVal["status"] = "nak";
			$retVal["errors"][] = "NOT_AUTHORIZED";
			Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
				" not authorized"
				);
		}
		return $retVal;
	}
	
	public function getPrintersCost($lusr, $lpwd, $lid)
	{
		$retVal = array("status"=>"ack","errors"=>array(),"data"=>array());
		if($this->checkLibrarian($lusr, $lpwd))
		{
			$rs = ResourceQuery::create()
				->filterByType(Resource::TYPE_PRINTER)
				->filterByLibraryId($lid)
				->find();
			foreach($rs as $r)
			{
				$retVal["data"][$r->getName()] = $r->getCost();
			}
		}
		else
		{
			$retVal["status"] = "nak";
			$retVal["errors"][] = "NOT_AUTHORIZED";
			Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
				" not authorized"
				);
		}
		return $retVal;
	}
	
	public function getConf($lusr, $lpwd, $lid, $resource, $group=NULL)
	{
		$retVal = array("status"=>"ack","errors"=>array(),"data"=>array());
		if($this->checkLibrarian($lusr, $lpwd))
		{
			if( $group  != NULL )
			{
				Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
					" a group [{$group}] is specified, search conf on table resourcerule [res owner {$resource}]",
					TLogger::DEBUG, 'NM_RPC');
				$q = ResourceRuleQuery::create()
				->filterByType(ResourceRule::TYPE_CONF)
				->filterByLibraryId($lid)
				->filterByResourceOwner($resource)
				->filterByResourceGroup($group);
				$rulers = $q->findOne();
				if($rulers instanceof ResourceRule)
				{
					$conf = $rulers->getConf();
					if($conf != NULL && $conf != '')
					{
						$retVal["data"] = json_decode($conf);
					}
				}
				else
				{
					$retVal["status"] = "nak";
					$retVal["errors"][] = "NOT_FOUND";
					Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
						" not found. Query " . $q->toString(),
						TLogger::DEBUG, 'NM_RPC');
				}
			}
			else
			{
				Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
					" NO group is specified, search conf on table resource",
					TLogger::DEBUG, 'NM_RPC');
				$rs = ResourceQuery::create()
				->filterByLibraryId($lid)
				->filterByName($resource);
				$r = $rs->findOne();
				if($r instanceof Resource)
				{
					$conf = $r->getConf();
					if($conf != NULL && $conf != '')
					{
						$retVal["data"] = json_decode($conf);
					}
				}
				else
				{
					$retVal["status"] = "nak";
					$retVal["errors"][] = "NOT_FOUND";
					Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
						" not found. Query: " . $rs->toString(),
						TLogger::DEBUG, 'NM_RPC');
				}
			}
		}
		else
		{
			$retVal["status"] = "nak";
			$retVal["errors"][] = "NOT_AUTHORIZED";
			Prado::log(__METHOD__ . "[" . __LINE__ . "] " .
				" not authorized"
				);
		}
		return $retVal;
	}
	
	public function registerMethods()
	{
		return array(
			'frauth' => array( 'method' => array( $this, 'freeRadiusAuth' ) ),
			'radauth' => array( 'method' => array( $this, 'radAuth' ) ),
			'startsession' => array( 'method' => array( $this, 'startSession' ) ),
			'updatesession' => array( 'method' => array( $this, 'updateSession' ) ),
			'endsession' => array( 'method' => array( $this, 'endSession' ) ),
			'importsessions' => array( 'method' => array( $this, 'importsessions' ) ),
			'setres' => array( 'method' => array( $this, 'setResource' ) ),
			'getres' => array( 'method' => array( $this, 'getResource' ) ),
			'getprinterscost' => array( 'method' => array( $this, 'getPrintersCost' ) ),
			'getconf' => array( 'method' => array( $this, 'getConf' ) )
		);
	}

}
