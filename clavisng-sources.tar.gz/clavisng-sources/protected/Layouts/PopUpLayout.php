<?php
/**
 * PopUpLayout class
 *
 * @author Dario Rigolin <dario@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @copyright Copyright &copy; 2011 Comperio srl
 * @version 2.7
 * @package Layouts
 * @since 2.0
 */
class PopUpLayout extends TTemplateControl
{

    public function onInit()
    {
        $params = $this->getRequest()->itemAt('param');

        $fullscreen = false;
        if (($array_params = unserialize($params)) !== false) {
	        if (array_key_exists('mode', $array_params) && $array_params['mode'] === 'fullscreen') {
		        $fullscreen = true;
	        }
        }

        if ($fullscreen) {
		        $this->getPage()->getClientScript()->registerEndScript(__CLASS__ . '_js', 'fullscreenPopup();');
	        } else {
		        $this->getPage()->getClientScript()->registerEndScript(__CLASS__ . '_js', 'standardPopup();');
	        }
    }

    protected function closePopup()
    {
        $this->getPage()->getClientScript()->registerEndScript(__CLASS__ . '_js', 'onClose();');
    }
}
