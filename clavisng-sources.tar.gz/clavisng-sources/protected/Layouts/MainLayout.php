<?php
/**
 * MainLayout class
 *
 * @author Dario Rigolin <dario@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006 ePortal Technologies
 * @copyright Copyright &copy; 2011 Comperio srl
 * @version 2.7
 * @package Layouts
 * @since 2.0
 */
class MainLayout extends TTemplateControl
{
	
}