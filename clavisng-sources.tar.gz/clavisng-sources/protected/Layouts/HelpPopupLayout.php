<?php
/**
 * HelpPopupLayout class
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2013 Comperio srl
 * @version 2.7
 * @package Layouts
 * @since 2.6
 */
class HelpPopupLayout extends TTemplateControl
{
	protected function closePopup() {
		$this->getPage()->getClientScript()->registerEndScript(__CLASS__.'_js','onClose();');
	}
}
