<?php
/**
 * site-conf.php
 *
 * This file is for hardcoded values such as item statuses etc.
 * Copy into sites/<site>/site-conf.php for per-site customizations.
 * 
 * Custom configuration for Clavis-Torino - last update 02/02/12
 *
 * @author Dario Rigolin <dario@comperio.it>
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2012 Comperio srl
 * @version $Id$
 * @package Core
 * @since 2.5.0
 */

require_once('protected/Interfaces/ItemStatusInterface.php');

/**
 * ItemStatus class
 *
 * @author Dario Rigolin <dario@comperio.it>
 * @package Core
 * @since 2.5.0
*/
class ItemStatus implements ItemStatusInterface
{
	const ITEMSTATUS_INORDER		= 'A';
	const ITEMSTATUS_INCATALOGATION	= 'B';
	const ITEMSTATUS_CORRUPTED		= 'C';
	const ITEMSTATUS_TODISCARD		= 'D';
	const ITEMSTATUS_DISCARDED		= 'E';
	const ITEMSTATUS_ONSHELF		= 'F';
	const ITEMSTATUS_INDEPOSIT		= 'G';
	const ITEMSTATUS_LOST			= 'H';
	const ITEMSTATUS_DISCARDEDOBSOLETE	= 'I';
	const ITEMSTATUS_DISCARDEDDAMAGED	= 'J';
	const ITEMSTATUS_NEW				= 'K';
	const ITEMSTATUS_ORDERDONE			= 'L';
	const ITEMSTATUS_ORDERNULL			= 'M';
	const ITEMSTATUS_LOSTTOCHANGE		= 'N';
	const ITEMSTATUS_LOSTTODROP			= 'O';
	const ITEMSTATUS_TODISCARDANDCHANGE	= 'P';
	const ITEMSTATUS_TOCOPY				= 'Q';
	const ITEMSTATUS_CONSERVATION		= 'R';
	const ITEMSTATUS_NOTFOUNDTOSEARCH	= 'S';
	const ITEMSTATUS_EXPOSED			= 'V';
	const ITEMSTATUS_STOLEN 			= 'W';
	const ITEMSTATUS_INRESTORATION		= 'X';   
	const ITEMSTATUS_HOLDFORACTIVITIES	= 'Y'; 
       
   	const ITEMORDERSTATUS_INORDER		= 'A';
	const ITEMORDERSTATUS_ORDERDONE		= 'L';
	const ITEMORDERSTATUS_ORDERNULL		= 'M';
	const ITEMORDERSTATUS_NOORDER		= 'N';
 
    // Stati da considerare smarrito => H, N, S, W
	public static final function getItemStatusLost()
	{
		return array(
			self::ITEMSTATUS_LOST,
			self::ITEMSTATUS_LOSTTOCHANGE,
			self::ITEMSTATUS_STOLEN,
			self::ITEMSTATUS_NOTFOUNDTOSEARCH);
	}

	public static final function getItemStatusDiscarded()
	{
		return array(
			self::ITEMSTATUS_DISCARDED,
			self::ITEMSTATUS_DISCARDEDOBSOLETE,
			self::ITEMSTATUS_DISCARDEDDAMAGED);
	}
    
    // Stati da considerare visibili in Clavis => tutti (eccetto gli scartati)
	public static final function getItemStatusVisible()
	{
		return array(
	    self::ITEMSTATUS_INORDER,
	    self::ITEMSTATUS_INCATALOGATION,
	    self::ITEMSTATUS_CORRUPTED,
	    self::ITEMSTATUS_TODISCARD,
	    self::ITEMSTATUS_ONSHELF,
	    self::ITEMSTATUS_INDEPOSIT,
	    self::ITEMSTATUS_LOST,
	    self::ITEMSTATUS_NEW,
	    self::ITEMSTATUS_ORDERDONE,
	    self::ITEMSTATUS_ORDERNULL,
	    self::ITEMSTATUS_LOSTTOCHANGE,
	    self::ITEMSTATUS_LOSTTODROP,
	    self::ITEMSTATUS_TODISCARDANDCHANGE,
	    self::ITEMSTATUS_TOCOPY,
	    self::ITEMSTATUS_CONSERVATION,
	    self::ITEMSTATUS_NOTFOUNDTOSEARCH,
            self::ITEMSTATUS_EXPOSED,
            self::ITEMSTATUS_STOLEN,
            self::ITEMSTATUS_INRESTORATION,
	    self::ITEMSTATUS_HOLDFORACTIVITIES);
	}
    
    // Stati che rendono visibile l'esemplare in OPAC => C, F, G, K, Q, R, V, X, Y
	public static final function getItemStatusOpacVisible() {
		return array(
			self::ITEMSTATUS_CORRUPTED,
            self::ITEMSTATUS_ONSHELF,
            self::ITEMSTATUS_INDEPOSIT,
            self::ITEMSTATUS_NEW,
            self::ITEMSTATUS_TOCOPY,
            self::ITEMSTATUS_CONSERVATION,
            self::ITEMSTATUS_EXPOSED,
            self::ITEMSTATUS_INRESTORATION,
	    self::ITEMSTATUS_HOLDFORACTIVITIES);
	}
    
    // Stati che rendono un esemplare in grado di soddisfare una prenotazione => F, G, K, V
	public static final function getItemStatusManageable()
	{
		return array(
			self::ITEMSTATUS_ONSHELF,
			self::ITEMSTATUS_INDEPOSIT,
			self::ITEMSTATUS_NEW,
			self::ITEMSTATUS_EXPOSED);
	}
    
    // Stati che rendono un esemplare non disponibile al prestito => A, B, C, D, E, H, I, J, L, M, O, P, Q, R, W, X, Y
	public static final function getItemStatusNotAvailable()
	{
		return array(
			self::ITEMSTATUS_INORDER,
            self::ITEMSTATUS_INCATALOGATION,
            self::ITEMSTATUS_CORRUPTED,
            self::ITEMSTATUS_TODISCARD,
            self::ITEMSTATUS_DISCARDED,
            self::ITEMSTATUS_LOST,
            self::ITEMSTATUS_DISCARDEDOBSOLETE,
            self::ITEMSTATUS_DISCARDEDDAMAGED,
            self::ITEMSTATUS_ORDERDONE,
            self::ITEMSTATUS_ORDERNULL,
            self::ITEMSTATUS_LOSTTODROP,
            self::ITEMSTATUS_TODISCARDANDCHANGE,
            self::ITEMSTATUS_TOCOPY,
            self::ITEMSTATUS_CONSERVATION,
            self::ITEMSTATUS_STOLEN,
            self::ITEMSTATUS_INRESTORATION,
            self::ITEMSTATUS_HOLDFORACTIVITIES);
	}
}


class ObjectTriggers {

	public static $_issue_nestId = array();

/**
     * When an Item is updated and its issue arrival status is changed from expected/next to arrived/last, take
     * a number of action for other items belonging to the same serial:
     * 1. set all issues expecting early as "missing"
     * 2. set all "arrived" to loan class "available"
     * 3. set the last arrived in the year as "last arrived" and "not available"
     * 4. set the next expected in the year as "next"
     * NOTE: this has to be deactivated or reworked if a single library has 2+ items for each issue.
     *
     * @param Item $item
     * @return bool
     */
    public static function onItemUpdate(Item $item)
    {
        // update cascade related issues
        if ($item->getIssueId() > 0) {
            if (array_key_exists('issueStatus', $item->_oldValues)
                    && in_array($item->_oldValues['issueStatus'], ItemPeer::getIssueStatusExpected())
                    && in_array($item->getIssueStatus(), ItemPeer::getIssueStatusArrived()))
            {
                // an expected issue arrived, so
                // 1. set all issues expecting early as "missing"
                // 2. set all "arrived" to loan class "available"
                // 3. set the last arrived in the year as "last arrived" and "not available"
                // 4. set the next expected in the year as "next"
                $arrivalDate    = $item->getIssueArrivalDate('U');
                if (!$arrivalDate)
                    $arrivalDate = time();
                // 1. set all issues expecting early as "missing"
                ItemQuery::create()
                    ->filterByManifestationId($item->getManifestationId())
                    ->filterByIssueYear($item->getIssueYear())
                    ->filterByIssueStatus(ItemPeer::getIssueStatusExpected())
                    ->filterByIssueArrivalDateExpected($arrivalDate, Criteria::LESS_THAN)
                    ->filterByHomeLibraryId($item->getHomeLibraryId())
                    ->update(array('IssueStatus' => ItemPeer::ISSUESTATUS_MISSING));
                // 2. set all "arrived" to loan class "available" or ONlY consultation for Civica e Musicale
		if($item->getOwnerLibraryId() == 2 || $item->getOwnerLibraryId() == 3) 
		ItemQuery::create()
                    ->filterByManifestationId($item->getManifestationId())
                    ->filterByIssueYear($item->getIssueYear())
                    ->filterByIssueStatus(ItemPeer::getIssueStatusArrived())
                    ->filterByHomeLibraryId($item->getHomeLibraryId())
                    ->update(array('IssueStatus' => ItemPeer::ISSUESTATUS_ARRIVED
				   ,'LoanClass' => ItemPeer::LOANCLASS_ONLYCONSULTATION));
		else
                ItemQuery::create()
                    ->filterByManifestationId($item->getManifestationId())
                    ->filterByIssueYear($item->getIssueYear())
                    ->filterByIssueStatus(ItemPeer::getIssueStatusArrived())
                    ->filterByHomeLibraryId($item->getHomeLibraryId())
                    ->update(array('IssueStatus' => ItemPeer::ISSUESTATUS_ARRIVED,
                                   'LoanClass' => ItemPeer::LOANCLASS_AVAILABLE));
			

                // 3. set the last arrived in the year as "last arrived" and "not available"
                $i = ItemQuery::create()
                    ->filterByManifestationId($item->getManifestationId())
                    ->filterByIssueYear($item->getIssueYear())
                    ->filterByIssueStatus(ItemPeer::getIssueStatusArrived())
                    ->filterByHomeLibraryId($item->getHomeLibraryId())
                    ->orderByIssueArrivalDate(Criteria::DESC)
                    ->orderByIssueNumber(Criteria::DESC)
                    ->findOne();
                if ($i instanceof Item) {
                    $i->setIssueStatus(ItemPeer::ISSUESTATUS_LAST);
                    $i->setLoanClass(ItemPeer::LOANCLASS_UNAVAILABLE);
                    $i->save();
                }
                // 4. set the next expected in the year as "next"
                ItemQuery::create()
                    ->filterByManifestationId($item->getManifestationId())
                    ->filterByIssueYear($item->getIssueYear())
                    ->filterByIssueStatus(ItemPeer::getIssueStatusExpected())
                    ->filterByHomeLibraryId($item->getHomeLibraryId())
                    ->update(array('IssueStatus' => ItemPeer::ISSUESTATUS_EXPECTED));
                $i = ItemQuery::create()
                    ->filterByManifestationId($item->getManifestationId())
                    ->filterByIssueYear($item->getIssueYear())
                    ->filterByIssueStatus(ItemPeer::getIssueStatusExpected())
                    ->filterByHomeLibraryId($item->getHomeLibraryId())
                    ->orderByIssueArrivalDateExpected(Criteria::ASC)
                    ->orderByIssueNumber(Criteria::ASC)
                    ->findOne();
                if ($i instanceof Item) {
                    $i->setIssueStatus(ItemPeer::ISSUESTATUS_NEXT);
                    $i->save();
                }
            }
        }
        return true;
    }

   	public function onIssueUpdate(Issue $issue)
	{
		self::$_issue_nestId[] = $issue->getIssueId();
		/* if start number has changed, chain update */

		/*

		Non necessaria rinumerazione su Torino.


		if (array_key_exists('startNumber',$issue->_oldValues) &&
			$issue->getStartNumber() > $issue->_oldValues['startNumber']) {
			$delta = $issue->getStartNumber() - $issue->_oldValues['startNumber'];
			$issueQuery = IssueQuery::create()
				->filterByIssueId(self::$_issue_nestId, Criteria::NOT_IN)
				->filterByManifestationId($issue->getManifestationId())
				->filterByIssueYear($issue->getIssueYear())
				->filterByStartNumber($issue->_oldValues['startNumber'], Criteria::GREATER_THAN);
			if ($issue->getIssueVolume())
				$issueQuery->filterByIssueVolume($issue->getIssueVolume());
			$i = $issueQuery->orderByStartNumber()->findOne();
			if ($i instanceof Issue) {
				$sn = $i->getStartNumber();
				$en = $i->getEndNumber();
				$i->setStartNumber($sn + $delta);
				$i->setEndNumber($en + $delta);
				$i->save();
				$i->clearAllReferences(true);
			}
		}
		*/
		/* update issue, delete middle ones */
		/// DEACTIVATED
		/*$toDelete = IssueQuery::create()
			->filterByManifestationId($issue->getManifestationId())
			->filterByIssueYear($issue->getIssueYear())
			->filterByStartNumber($issue->getStartNumber(),Criteria::GREATER_EQUAL)
			->filterByStartNumber($issue->getEndNumber(),Criteria::LESS_EQUAL)
			->prune($issue);
		if ($issue->getIssueVolume())
			$toDelete->filterByIssueVolume($issue->getIssueVolume());

		$issues = $toDelete->find();
		foreach ($issues as $i) {
			try {
				$i->delete();
				if ($i->isDeleted())
					ChangelogPeer::logAction($i, ChangelogPeer::LOG_DELETE,
						null, '[AUTO] eliminato fascicolo '.$i->getIssueCombo());
				$i->clearAllReferences(true);
			} catch (Exception $e) {
				Prado::log(Prado::varDump($e));
			}
		}*/

		$issue->updateLinkedItems();
		return true;
	}
}
/*
class Clavis extends ClavisBase
{
    public static function getRevokeInterval($row, DateInterval $diff)
    {
	$diff_s = Clavis::DateInterval2Seconds($diff);
	return ($diff_s < 31556926) ? $diff : new DateInterval('P365D');
    }
}
*/
