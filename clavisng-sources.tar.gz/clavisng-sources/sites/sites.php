<?php
$sites = array(
	"urladdress_example" => "sitedir",
);

