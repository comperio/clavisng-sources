<?php
/**
 * Clavis command line tool.
 * Based upon prado-cli.php script.
 *
 * Should be called as:
 * $ php clavis-cli.php <site> <task> <arguments>
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @copyright Copyright &copy; 2011 Comperio srl
 */

if(!isset($_SERVER['argv']) || php_sapi_name()!=='cli')
	die('Must be run from the command line');

require 'vendor/autoload.php';
// shift out my name from args
$argv = $_SERVER['argv'];
array_shift($argv);
if (empty($argv))
	$argv = array('help');

$basePath = __DIR__;
// source all actions
if (!is_dir($basePath.'/protected/Console'))
	throw new Exception('Cannot open task directory.');
foreach (glob("{$basePath}/protected/Console/*.php") as $file) {
	if (basename($file) == 'ClavisCommandLineAction.php')
		continue;
	require($file);
}

$confdir = $basePath.'/sites';
// The following block identifies the correct configuration directory upon request URL.
$sites = array();
if (file_exists($confdir.'/sites.php'))
	include($confdir.'/sites.php');

$siteArg = array_shift($argv);

function getActionName($action) {
	return str_replace(' ','', ucwords(str_replace('_',' ',strtolower($action))));
}

function printHelp() {
	global $basePath, $argv, $confdir;
	$directory = $basePath.'/protected/Console';
	if (!is_dir($directory))
		throw new Exception('Cannot open task directory.');
	if (count($argv) > 0 && file_exists($directory.'/'.getActionName($argv[0]).'.php')) {
		// single action help
		$action = getActionName($argv[0]);
		echo "\nClavisNG Command Line Interface - v 1.0\n\n";
		require_once($directory.'/'.$action.'.php');
		$a = 'ClavisAction'.$action;
		$action = new $a;
		echo "  usage: clavis-cli SITE ".$action->renderHelp(false);
	} else {
		echo "\nClavisNG Command Line Interface - v 1.0\n";
		echo "    usage: clavis-cli SITE ACTION <parameter> [optional]\n";
		echo "  example: clavis-cli localhost.biblio.test parseQuery\n";
		echo "\nThe following actions are currently available:\n";

		$actions = array();
		foreach (glob("{$basePath}/protected/Console/*.php") as $file) {
			if (basename($file) == 'ClavisCommandLineAction.php')
				continue;
			require_once($file);
			$actions[] = 'ClavisAction'.substr(basename($file),0,strpos(basename($file),'.'));
		}
		sort($actions);
		foreach ($actions as $a) {
			$action = new $a;
			echo "\n * ".$action->renderHelp(true);
		}
		echo "\n\nType 'clavis-cli help ACTION' to get specific help for an action.\n\n";
	}
}

$site_pool = array();

switch ($siteArg) {
	case 'help':
		die(printHelp());
	case 'none':
		// script is service or development and should not connect to specific DB
		$dir = 'default';
		break;
	default:
		if (file_exists($confdir.'/'.$siteArg.'/clavis-application.xml'))
			$dir = $siteArg;
		break;
}

if (!isset($dir)) {
	echo "Error: site [{$siteArg}] not valid, please specify either none or an existing site, BEFORE the action.\n";
	echo "Type 'clavis-cli help' to get help.\n\n";
	die();
}

if (count($argv) < 1)
	die("ClavisNG Command Line Interface - v 1.0\nPlease specify an action - type 'clavis-cli help' to get help.\n\n");

// if all is first argument, there's probably a catch in multisite execution support,
// so shift it away.
if ($argv[0] == 'all')
	array_shift($argv);

$actionName = getActionName($argv[0]);
$actionClass = 'ClavisAction'.$actionName;
if (!class_exists($actionClass))
	die("ClavisNG Command Line Interface - v 1.0\nInvalid action - type 'clavis-cli help' to get help.\n\n");

include($basePath.'/propel_init.php');
if ((@include 'pradolite.php') === false)
	include 'prado.php';

$SITEPATH = $confdir.'/'.$dir;
Propel::init($SITEPATH.'/propel-conf.php');
Propel::disableInstancePooling();

require_once(dirname(__FILE__).'/ClavisBase.php');
require_once('protected/Data/ObjectTriggersBase.php');
require_once('protected/Data/ItemStatusBase.php');
if (file_exists($SITEPATH.'/site-conf.php'))
	include($SITEPATH.'/site-conf.php');

/**
 * Defines Clavis class if not defined.
 */
if(!class_exists('Clavis',false))
{
	/**
	 * Clavis class.
	 *
	 * @author Ciro Mattia Gonano <ciro@comperio.it>
	 * @version $Id$
	 * @package Core
	 * @since 2.5.2
	 */
	class Clavis extends ClavisBase
	{
	}
}
/**
 * Defines ItemStatus class if not defined.
 */
if(!class_exists('ItemStatus',false))
{
	/**
	 * ItemStatus class.
	 *
	 * @author Ciro Mattia Gonano <ciro@comperio.it>
	 * @version $Id$
	 * @package Core
	 * @since 2.6.5
	 */
	class ItemStatus extends ItemStatusBase
	{
	}
}
/**
 * Defines ObjectTriggers class if not defined.
 */
if(!class_exists('ObjectTriggers',false))
{
	/**
	 * ObjectTriggers class.
	 *
	 * @author Ciro Mattia Gonano <ciro@comperio.it>
	 * @version $Id$
	 * @package Core
	 * @since 2.5.2
	 */
	class ObjectTriggers extends ObjectTriggersBase
	{
	}
}

$application = new TShellApplication('protected',false);
$conf = $SITEPATH.'/clavis-application-shell.xml';
// regen config file without caching module
$xml = simplexml_load_file($SITEPATH.'/clavis-application.xml');
foreach ($xml->modules->children() as $mod)
	if ('cache' == $mod['id']) {
		$dom = dom_import_simplexml($mod);
		$dom->parentNode->removeChild($dom);
	}
$xml->saveXML($conf);

$application->setConfigurationFile($conf);
$application->setRuntimePath($SITEPATH.'/runtime/');
$application->run();

ob_implicit_flush(true);
@ob_end_flush();
restore_exception_handler();

//register action class and run
$myargv = $argv;
$action = new $actionClass;
if (! $action instanceof ClavisCommandLineAction)
	die("ClavisNG Command Line Interface - v 1.0\nInvalid action - type 'clavis-cli help' to get help.\n\n");
try {
	echo "\n*** PROCESSING SITE [{$siteArg}] with ACTION [{$actionName}] ***\n";
	if ($action->isValidAction($myargv)) {
		if (!$action->performAction($myargv))
			echo "\nAction FAILED, see logs.\n";

        $application->raiseEvent("OnEndRequest",$application,null);
	} else {
		echo "\nWRONG PARAMETERS: ".implode(', ',$myargv)."\n\nUsage: clavis-cli SITE ".$action->renderHelp();
	}
} catch (Exception $e) {
	echo "Action FAILED / Exception throwed ($e), see logs.\n\n";
}

Propel::close();

/**************** END **********************/
die();
