#!/usr/bin/perl
use CGI qw/:standard/;
use Device::SerialPort qw( :PARAM :STAT 0.07 );
use JSON;

CGI::initialize_globals();

my $paction= param('action');
my $pafi= param('afi');
my $pmem= param('mem');
my $ptag= param('tag');
my $pcallback= param('callback');

print "Content-type: text/javascript\n\n"; # Two newlines!!

my $PortName = "/dev/ttyUSB0";


# $lockfile is optional
$PortObj = new Device::SerialPort ($PortName)
       || die "ERROR: Can't open $PortName: $!\n";
       
$PortObj->user_msg(ON);
$PortObj->baudrate(38400);
$PortObj->databits(8);
$PortObj->parity("even");
$PortObj->stopbits(1);
#$PortObj->read_char_time(1);
$PortObj->read_const_time(50);

if( defined $paction)
{
  
  if($paction eq "SCAN")
  {
   
    sendRFIDResetRF();
    
    my @tagList = sendRFIDScan();
    my $json = ();
    my $count = 1;
    $json->[0]->{'ERROR'} = "OK";
    $json->[0]->{'STATUS'} = "OK";
    foreach my $tagId (@tagList) 
    {
      #my $afi = sendRFIDGetAFI($tagId);
      #my $mem = sendRFIDGetTagData($tagId);
      $json->[$count]->{'EID'} = $tagId;
      
      #print "TAG: $tagId ";
      
      if( defined $pafi)
      {
	my $afi = sendRFIDGetAFI($tagId);
	$json->[$count]->{'AFI'} = $afi; 
	#print "AFI=$afi ";
      }
      
      if(defined $pmem)
      {
	my $mem = sendRFIDGetTagData($tagId);
	$json->[$count]->{'MEM'} = $mem; 
	#print "MEM=$mem";
      }
      $count++;
      #print "\n";
    }
    $json->[0]->{'COUNT'} = $count-1;
     $jhtml = to_json($json);
    
     print "$pcallback($jhtml);";
     
  } 
  elsif($paction eq "SWVER") 
  {
    my $ret = sendRFIDCmd("FF65");
    my $json = ();
    $json->{'STATUS'} = bintohex($ret);
    $json->{'ERROR'} = 0;
  
    my $jhtml = to_json($json);
    print "$pcallback($jhtml);";
   # print "FF65 => " . bintohex($ret) ."\n";
  }
  elsif($paction eq "SETAFI") 
  {
    my @tags = split(/,/,$ptag);
    my @afis = split(/,/,$pafi);
    my $json = ();
    
    if(scalar(@tags) == scalar(@afis))
    {
      $json->{'STATUS'} = 0;
      $json->{'ERROR'} = "";
      $json->{'SUCC'} = 0;
      $json->{'FAIL'} = 0;
      for(my $i = 0; $i < scalar(@tags); $i++)
      {
	$ret = sendRFIDSetAFI($tags[$i],$afis[$i]);
	if($ret ne "00")
	{
	  $json->{'STATUS'} = -1;
	  $json->{'ERROR'} .= "-Errore AFI su Tag " . $tags[$i];
	  $json->{'FAIL'}++;
	} else {
	  $json->{'SUCC'}++;
	}
      }
    } else {
      $json->{'STATUS'} = -1;
      $json->{'ERROR'} = "EID e tag non coincidono";
  
    }
  
    my $jhtml = to_json($json);
    print "$pcallback($jhtml);";
   # print "FF65 => " . bintohex($ret) ."\n";
  }
  else 
  {
    die "ERROR: Azione [$paction] sconosciuta\n";
  }
} else {
  die "ERROR: Nessuna azione specificata\n";
}




sub sendRFIDResetRF
{
  my $ret = sendRFIDCmd("FF69");
  #print "FF69 => " . bintohex($ret) ."\n";

}

sub sendRFIDSetEAS
{
  my $tagId = shift;
  my $eas   = shift;
}

sub sendRFIDGetEAS
{
  my $tagId = shift;
}

sub sendRFIDSetAFI
{
  my $tagId = shift;
  my $afi   = shift;
  
  my $ret = bintohex(sendRFIDCmd("FFB02701$tagId".$afi));
  my $status = substr($ret,6,2);
  
  return $status;
  
}

sub sendRFIDGetAFI
{
  my $tagId = shift;
  my $ret = bintohex(sendRFIDCmd("FFB02B01$tagId"));
  #print "$ret\n";
  return substr($ret,26,2);
}

sub sendRFIDSetTagData
{
   my $tagId = shift;
   my $data  = shift;
   my $mem = "";
   for(my $i = 0; $i < length($data); $i += 8)
   {
      $mem .= reverseBlock(substr($data,$i,8));
   }
  
   my $ret = bintohex(sendRFIDCmd("FFB02401".$tagId."001A04" . $mem));
   return $ret;
}

sub sendRFIDGetTagData
{
  my $tagId = shift;
  
  my $ret = bintohex(sendRFIDCmd("FFB02301".$tagId."001A"));
  my $block = hex(substr($ret,8,2));
  $ret = substr($ret,12,$block*10);
  my $result = "";
  for(my $i=0; $i < $block; $i++)
  {
    my $blk = substr($ret,$i*10+2,8);
    $result .= reverseBlock($blk);
   # printf( "Block %2d: %s %s\n",$i,$blk,reverseBlock($blk));
  }
  #print "Block $block Len " . length($ret)/2 ."\n";
  return $result;
}

sub reverseBlock
{
  my $block = shift;
  my $res = "";
  for(my $i = length($block)-2; $i >= 0; $i -= 2)
  {
    $res .= substr($block,$i,2);
  }
  return $res;
}


sub sendRFReset
{
  sendRFIDCmd("FF69");
}

sub sendRFIDScan
{
  my $ret = bintohex(sendRFIDCmd("FFB00100"));
#  print "AL $ret\n";
  my @tagList;
  my $status = substr($ret,6,2);
  if($status eq "00")
  { 
  	my $tagNum = hex(substr($ret,8,2));
  
  	#print "Letti $tagNum tags\n";
	  for(my $i = 0; $i < $tagNum; $i++)
	  {
	    my $tagId = substr($ret,14 + 20 * $i,16);
	    #print "TAG: $tagId [$i]\n";
	    push(@tagList,$tagId);
	  }
  }
  
  return sort(@tagList);
}

sub sendRFIDCmd
{
  my $cmd = shift;
  
  my $isoCmd =  prepareISOCmd($cmd);
  my $ret = $PortObj->write(hextobin( $isoCmd ));
  if(($ret*2) == length($isoCmd))
  {
 #   select(undef, undef, undef, 0.25);
    my $count;
    my $len;
    my $buffer;
    my $response;
    $count = 0;
    
    while ($count == 0)
    {
      # Get stream length
      ($count,$len)=$PortObj->read(1); 
    }
    $response = $len;
    $len = ord($len);
    #print "Letto $count e $len\n";
    while(length($response) < $len)
    {
      ($count,$buffer)=$PortObj->read(ord($len)); # will read _up to_ 255 chars
      if($count > 0)
      {
	$response .= $buffer;
      }
	
    }
    
    #print "Letto $count wait $len " . bintohex($response) . "\n";
    return $response;
    
  } else {
    print "ERROR: invio dati errato\n";
    return 0;
  }
}

sub hextobin
{
  my $hexString = shift;
  my $binString = "";
  
  for(my $i=0; $i < length($hexString); $i += 2)
  {
    $binString .= pack("C", hex(substr($hexString,$i,2)) ) ;
  }
  
  return $binString;
}

sub bintohex
{
  my $binString = shift;
  my $hexString = "";
  
  for(my $i=0; $i < length($binString); $i++)
  {
    
    $hexString .= sprintf("%02X", ord(substr($binString,$i,1)) );
  }
  
  return $hexString;
}

sub mycrc16
{
  my $data = shift;
  my $crc = 0xFFFF;
  
  for(my $i=0; $i < length($data); $i++)
  {
    my $ch = ord(substr($data,$i,1)); 
    $crc ^= $ch;
    
    for(my $j=0; $j < 8; $j++)
    {   
      if ($crc & 0x0001)
      {
	$crc = ($crc >> 1) ^ 0x8408;
      } else {
	$crc = ($crc >> 1);
      }
    }
  }
  return $crc;
}

sub mycrc16hex
{
  my $data = shift;
  my $crc = sprintf("%04X",mycrc16($data));
  
  return substr($crc,2,2).substr($crc,0,2);
}

sub prepareISOCmd
{
  my $isoCmd = shift;
  
  #Calculare length plus 2 CRC bytes + 1 length byte
  my $len = length($isoCmd)/2 + 3; 
  
  #Prepend lenght before CRC
  $isoCmd = sprintf("%02X",$len) . $isoCmd;
  $isoCmd = $isoCmd . mycrc16hex(hextobin($isoCmd));
  
  return $isoCmd
}