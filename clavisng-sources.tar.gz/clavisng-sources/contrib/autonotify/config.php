<?php

/**
 * FILE DI ESEMPIO PER LA CONFIGURAZIONE DELL'AUTO NOTIFICATORE
 */

return [
	'STAGES' => ['PENDING', 'ERROR', 'LATE'],
	'QUERIES' => [
		'PENDING' =>
			NotificationQuery::create()
				->filterByNotificationChannel('Z')// Auto Channel
				->filterByNotificationState('A')// Pending
				->filterByInternalStatus('A'), // Queued

		'ERROR' =>
			NotificationQuery::create()
				->filterByNotificationChannel('Z')// Auto Channel
				->filterByNotificationState('D')// Error
				->filterByInternalStatus('B%', Criteria::LIKE), //Sent to any channel
		'LATE' =>
			NotificationQuery::create()
				->filterByNotificationChannel('Z')// Auto Channel
				->filterByNotificationState('B')// Sent
				->filterByInternalStatus('B%', Criteria::LIKE)// Sent to any channel
				->filterByDateUpdated(time() - 60 * 60, Criteria::LESS_THAN), // 1 Hour NO life signs

	],
	'CONFIG' => [
		'report_to' => 'SYSTEM', // LIBRARY, EMAIL
		'default_sender_id' => 1,

		'notification_config' => [
			AutoNotifyTypes::FIRST_SOLICIT => [
				'channels' => ['APP', 'SMS', 'CHATBOT', 'VOICE', 'EMAIL'],
				'deadline' => '5', // In days
				'report_failure' => true,
				'templates' => ['SMS' => 156, 'EMAIL' => 156, 'CHATBOT' => 156, 'APP' => 156, 'VOICE' => 156] // PK DEI TEMPLATE DA USARE PER CIASCUN CANALE.
			],

		],
		'contact_map' => [
			'E' => 'EMAIL',
			'C' => 'SMS',
			'L' => 'CHATBOT',
			'T' => 'VOICE',
			'I' => 'APP'
		],

		'channel_config' => [
			'EMAIL' => [
				'retry_after' => '',
				'timeout' => '24', // Afer 1 day with no feedback mail is considered not sent
				'time_window' => ['12:00', '20:00'],
				'enabled' => true,
			],
			'SMS' => [
				'retry_after' => '',
				'timeout' => '4', // Hours
				'time_window' => ['00:00', '23:59'],
				'enabled' => true,
				'charge_library_id' => 1,
			],
			'CHATBOT' => [
				'retry_after' => '',
				'timeout' => '4', // Hours
				'time_window' => ['00:00', '23:59'],
				'enabled' => true,
			],
			'APP' => [
				'retry_after' => '',
				'timeout' => '4', // Hours
				'time_window' => ['00:00', '23:59'],
				'enabled' => true,
			],
			'VOICE' => [
				'retry_after' => '',
				'timeout' => '4', // Hours
				'time_window' => ['00:00', '23:59'],
				'enabled' => true,
			],

		]
	]
];