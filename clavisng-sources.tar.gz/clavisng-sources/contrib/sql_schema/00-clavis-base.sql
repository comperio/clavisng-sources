SET foreign_key_checks = 0;
SET NAMES 'utf8' COLLATE 'utf8_general_ci';


CREATE TABLE `_statvalues` (
  `vclass` varchar(32) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `vlow` varchar(32) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `vhigh` varchar(32) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `vlabel` varchar(128) CHARACTER SET latin1 DEFAULT NULL,
  PRIMARY KEY (`vclass`,`vlow`,`vhigh`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



CREATE TABLE `address` (
  `address_id` int(11) NOT NULL AUTO_INCREMENT,
  `patron_id` int(11) NOT NULL,
  `address_type` char(1) DEFAULT NULL,
  `address_pref` char(1) DEFAULT NULL,
  `address_note` varchar(255) DEFAULT NULL,
  `street_type` varchar(255) DEFAULT NULL,
  `street` varchar(255) DEFAULT NULL,
  `street_num` varchar(255) DEFAULT NULL,
  `village` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `zip` varchar(16) DEFAULT NULL,
  `province` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`address_id`),
  KEY `FI__patron_address` (`patron_id`)
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;



CREATE TABLE `app_action` (
  `action_id` int(11) NOT NULL AUTO_INCREMENT,
  `sort_order` int(11) NOT NULL,
  `label` varchar(40) DEFAULT NULL,
  `page` varchar(255) DEFAULT NULL,
  `module_id` varchar(32) DEFAULT NULL,
  `menu_visible` char(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`action_id`),
  KEY `FI__Action_Module` (`module_id`)
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;



CREATE TABLE `app_module` (
  `module_id` varchar(32) NOT NULL,
  `sort_order` int(11) NOT NULL,
  `label` varchar(32) NOT NULL,
  `page` varchar(255) NOT NULL,
  `always_view` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`module_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



CREATE TABLE `app_profile` (
  `profile_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) DEFAULT NULL,
  `role` varchar(32) NOT NULL,
  `profiles_control` varchar(33) DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`profile_id`)
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;



CREATE TABLE `app_profile_acl` (
  `module_id` varchar(32) NOT NULL,
  `action_id` int(11) NOT NULL,
  `profile_id` int(11) NOT NULL,
  `action` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`module_id`,`action_id`,`profile_id`),
  KEY `FI__Acl_Profile` (`profile_id`),
  KEY `FI__Acl_Action` (`action_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



CREATE TABLE `attachment` (
  `attachment_id` int(11) NOT NULL AUTO_INCREMENT,
  `attachment_type` varchar(8) DEFAULT NULL,
  `object_id` int(11) DEFAULT NULL,
  `object_type` varchar(32) DEFAULT NULL,
  `mime_type` varchar(128) DEFAULT NULL,
  `file_size` int(11) DEFAULT NULL,
  `file_path` varchar(255) DEFAULT NULL,
  `file_label` varchar(255) DEFAULT NULL,
  `license` char(3) DEFAULT NULL,
  `file_description` text,
  `file_name` varchar(255) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `date_updated` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`attachment_id`),
  KEY `attachment_idx` (`object_id`,`object_type`),
  KEY `FI__441` (`created_by`),
  KEY `FI__442` (`modified_by`)
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;



CREATE TABLE `authority` (
  `authority_id` int(11) NOT NULL AUTO_INCREMENT,
  `non_sort_text` varchar(255) DEFAULT NULL,
  `sort_text` varchar(2000) DEFAULT NULL,
  `full_text` varchar(2000) NOT NULL,
  `authority_type` varchar(5) DEFAULT NULL,
  `authority_subtype` char(1) DEFAULT NULL,
  `authority_rectype` char(1) DEFAULT NULL,
  `authority_status` char(1) DEFAULT NULL,
  `unimarc` text,
  `ext_data` text,
  `authority_lang` char(3) DEFAULT NULL,
  `authority_codlevel` char(2) DEFAULT '05',
  `parent_id` int(11) DEFAULT NULL,
  `subject_class` varchar(32) DEFAULT NULL,
  `class_code` varchar(32) DEFAULT NULL,
  `bid_source` varchar(64) DEFAULT NULL,
  `bid` varchar(64) DEFAULT NULL,
  `last_sbn_sync` datetime DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `date_updated` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`authority_id`),
  UNIQUE KEY `authority_U_1` (`bid_source`,`bid`),
  KEY `sort_text_index` (`sort_text`(255)),
  KEY `authority_type_index` (`authority_type`),
  KEY `FI__authority_parent` (`parent_id`),
  KEY `FI__44c` (`created_by`),
  KEY `FI__44d` (`modified_by`),
  KEY `authority_fulltext` (`full_text`(255),`subject_class`)
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;



CREATE TABLE `budget` (
  `budget_id` int(11) NOT NULL AUTO_INCREMENT,
  `library_id` int(11) DEFAULT NULL,
  `budget_title` varchar(255) DEFAULT NULL,
  `budget_year` int(11) DEFAULT NULL,
  `start_validity` date DEFAULT NULL,
  `end_validity` date DEFAULT NULL,
  `total_amount` decimal(10,2) DEFAULT NULL,
  `tolerance` decimal(10,2) DEFAULT NULL,
  `budget_notes` varchar(255) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `date_updated` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`budget_id`),
  KEY `FI__54` (`library_id`),
  KEY `FI__44x` (`created_by`),
  KEY `FI__44y` (`modified_by`)
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;



CREATE TABLE `budget_operation` (
  `budget_id` int(11) NOT NULL AUTO_INCREMENT,
  `amount` decimal(10,2) DEFAULT NULL,
  `operation_note` varchar(255) DEFAULT NULL,
  `operation_date` date DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `date_updated` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`budget_id`),
  KEY `FI__53` (`budget_id`),
  KEY `FI__44k` (`created_by`),
  KEY `FI__44j` (`modified_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



CREATE TABLE `bulletin` (
  `bulletin_id` int(11) NOT NULL AUTO_INCREMENT,
  `publish_start_date` date DEFAULT NULL,
  `publish_end_date` date DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `body` text,
  `scope` char(1) DEFAULT NULL,
  `sticky` tinyint(1) NOT NULL DEFAULT '0',
  `protected_message` tinyint(1) NOT NULL DEFAULT '0',
  `librarian_id` int(11) DEFAULT NULL,
  `library_id` int(11) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `date_updated` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`bulletin_id`),
  KEY `FI_letin_library_idx` (`library_id`),
  KEY `FI_letin_librarian_idx` (`librarian_id`),
  KEY `FI__44ii` (`created_by`),
  KEY `FI__44ll` (`modified_by`)
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;



CREATE TABLE `changelog` (
  `event_id` int(11) NOT NULL AUTO_INCREMENT,
  `event_date` datetime DEFAULT NULL,
  `event_description` varchar(255) DEFAULT NULL,
  `event_type` varchar(8) DEFAULT NULL,
  `object_id` int(11) DEFAULT NULL,
  `object_class` varchar(64) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `user_class` varchar(64) DEFAULT NULL,
  `session_id` int(11) DEFAULT NULL,
  `library_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`event_id`),
  KEY `changelog_obj_idx` (`object_id`,`object_class`),
  KEY `library_id` (`library_id`)
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;



CREATE TABLE `clavis_param` (
  `param_name` varchar(64) NOT NULL,
  `library_id` int(11) NOT NULL DEFAULT '0',
  `librarian_id` int(11) NOT NULL DEFAULT '0',
  `param_class` varchar(64) NOT NULL,
  `param_value` varchar(4000) DEFAULT NULL,
  PRIMARY KEY (`param_name`,`library_id`,`librarian_id`,`param_class`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



CREATE TABLE `consistency_note` (
  `consistency_note_id` int(11) NOT NULL AUTO_INCREMENT,
  `collocation` varchar(255) NOT NULL,
  `text_note` text NOT NULL,
  `closed` int(11) NOT NULL DEFAULT '0',
  `library_id` int(11) NOT NULL,
  `manifestation_id` int(11) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `date_updated` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`consistency_note_id`),
  KEY `FI_sistency_library` (`library_id`),
  KEY `FI_sistency_manifestation` (`manifestation_id`),
  KEY `FI__44e` (`created_by`),
  KEY `FI__44f` (`modified_by`)
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;



CREATE TABLE `consortia` (
  `consortia_id` char(7) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `label` varchar(255) DEFAULT NULL,
  `token` varchar(255) DEFAULT NULL,
  `info` text,
  `date_created` datetime DEFAULT NULL,
  `date_updated` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`consortia_id`),
  KEY `FI__44n` (`created_by`),
  KEY `FI__44o` (`modified_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



CREATE TABLE `contact` (
  `contact_id` int(11) NOT NULL AUTO_INCREMENT,
  `patron_id` int(11) NOT NULL,
  `contact_type` char(1) DEFAULT NULL,
  `contact_value` varchar(255) DEFAULT NULL,
  `contact_pref` char(1) DEFAULT NULL,
  `contact_note` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`contact_id`),
  KEY `FI__patron_contact` (`patron_id`),
  KEY `contact_value` (`contact_value`,`contact_type`)
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;



CREATE TABLE `document_template` (
  `document_template_id` int(11) NOT NULL AUTO_INCREMENT,
  `template_media` char(1) DEFAULT NULL,
  `template_description` text,
  `template_title` varchar(255) DEFAULT NULL,
  `template_subject` varchar(255) DEFAULT NULL,
  `template_body` text,
  `template_class` varchar(255) DEFAULT NULL,
  `template_lang` varchar(16) DEFAULT NULL,
  `library_id` int(11) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `date_updated` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`document_template_id`),
  KEY `FI__44oo` (`created_by`),
  KEY `FI__44pp` (`modified_by`),
  KEY `FI__44ss` (`library_id`),
  KEY `document_template_I_1` (`template_class`,`template_lang`,`library_id`)
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;



CREATE TABLE `ill_request` (
  `ill_request_id` int(11) NOT NULL AUTO_INCREMENT,
  `request_status` char(1) DEFAULT NULL,
  `request_date` datetime DEFAULT NULL,
  `from_library_id` int(11) DEFAULT NULL,
  `to_library_id` int(11) DEFAULT NULL,
  `patron_id` int(11) DEFAULT NULL,
  `request_key` varchar(32) DEFAULT NULL,
  `librarian_id` int(11) DEFAULT NULL,
  `item_location` varchar(64) DEFAULT NULL,
  `item_title` varchar(2000) DEFAULT NULL,
  `start_loan_date` date DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `title` varchar(2000) DEFAULT NULL,
  `unimarc` text,
  `date_created` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`ill_request_id`),
  KEY `FI__445` (`created_by`),
  KEY `FI__446` (`modified_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



CREATE TABLE `import_source` (
  `name` varchar(255) NOT NULL COMMENT 'The name (id) for the source',
  `label` varchar(255) NOT NULL COMMENT 'The label to display to identify source',
  `driver` varchar(255) NOT NULL COMMENT 'The driver the source will be using',
  `address` varchar(255) DEFAULT NULL COMMENT 'The URL to connect to',
  `enabled` tinyint(1) DEFAULT '1' COMMENT 'Whether the source is enabled for use or not',
  `selected` tinyint(1) DEFAULT '1' COMMENT 'Whether the source is selected by default',
  `timeout` int(11) DEFAULT NULL COMMENT 'The timeout for external answer',
  `encoding` varchar(32) DEFAULT NULL COMMENT 'The char encoding the source is using',
  `search_fields` text COMMENT 'The fileds enabled for searching',
  `syntax` varchar(32) DEFAULT NULL COMMENT 'The syntax for the source (if applicable)',
  `format` varchar(32) DEFAULT NULL COMMENT 'The format for the source (if applicable)',
  `turbomarc_conversion` text COMMENT 'The turbomarc conversions to be applied (if applicable)',
  `options` text COMMENT 'Driver''s optional parameters, if needed',
  `default_catlevel` char(2) DEFAULT NULL,
  `sortable_rank` int(11) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `date_updated` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `import_source_FI_1` (`created_by`),
  KEY `import_source_FI_2` (`modified_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



CREATE TABLE `inventory_serie` (
  `inventory_serie_id` varchar(128) NOT NULL,
  `library_id` int(11) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `inventory_counter` int(11) DEFAULT NULL,
  `closed` int(11) DEFAULT NULL,
  `readonly` int(11) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `date_updated` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`inventory_serie_id`,`library_id`),
  KEY `FI__23` (`library_id`),
  KEY `FI__44gg` (`created_by`),
  KEY `FI__44hh` (`modified_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



CREATE TABLE `invoice` (
  `invoice_id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_status` char(1) NOT NULL DEFAULT 'A',
  `supplier_id` int(11) NOT NULL,
  `library_id` int(11) NOT NULL,
  `budget_id` int(11) NOT NULL,
  `invoice_date` date DEFAULT NULL,
  `invoice_number` varchar(64) DEFAULT NULL,
  `currier_price` decimal(10,2) DEFAULT NULL,
  `accounted` int(11) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `date_updated` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`invoice_id`),
  KEY `FI__43` (`supplier_id`),
  KEY `FI__44cc` (`created_by`),
  KEY `FI__44dd` (`modified_by`)
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8 COMMENT='This table cointains invoices received by a library and is l';



CREATE TABLE `issue` (
  `issue_id` int(11) NOT NULL AUTO_INCREMENT,
  `issue_number` varchar(64) DEFAULT NULL,
  `start_number` int(11) DEFAULT NULL,
  `end_number` int(11) DEFAULT NULL,
  `issue_year` varchar(4) DEFAULT NULL,
  `issue_volume` varchar(255) NOT NULL,
  `issue_note` varchar(255) DEFAULT NULL,
  `issue_type` char(1) DEFAULT NULL,
  `issue_date` date DEFAULT NULL,
  `manifestation_id` int(11) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `date_updated` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`issue_id`),
  KEY `FI__manifestation_issue` (`manifestation_id`),
  KEY `FI__449` (`created_by`),
  KEY `FI__4410` (`modified_by`)
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;



CREATE TABLE `item` (
  `item_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text,
  `manifestation_id` int(11) DEFAULT NULL,
  `manifestation_dewey` char(16) DEFAULT NULL,
  `item_media` char(1) DEFAULT NULL,
  `item_status` char(1) DEFAULT NULL,
  `item_order_status` char(1) NOT NULL DEFAULT 'N',
  `item_icon` char(3) NOT NULL,
  `physical_status` char(1) DEFAULT NULL,
  `item_source` char(1) DEFAULT NULL,
  `opac_visible` tinyint(1) DEFAULT NULL,
  `inventory_serie_id` varchar(128) NOT NULL,
  `inventory_number` int(11) DEFAULT NULL,
  `inventory_date` date DEFAULT NULL,
  `owner_library_id` int(11) NOT NULL,
  `home_library_id` int(11) NOT NULL,
  `collocation` varchar(128) DEFAULT NULL,
  `section` varchar(128) DEFAULT NULL,
  `sequence1` varchar(128) DEFAULT NULL,
  `sequence2` varchar(128) DEFAULT NULL,
  `specification` varchar(128) DEFAULT NULL,
  `reprint` varchar(64) DEFAULT NULL,
  `width` int(11) DEFAULT NULL,
  `height` int(11) DEFAULT NULL,
  `weight` decimal(5,2) DEFAULT NULL,
  `volume_number` int(11) DEFAULT NULL,
  `volume_text` varchar(128) DEFAULT NULL,
  `mediapackage_size` int(11) NOT NULL DEFAULT '1',
  `current_loan_id` int(11) DEFAULT NULL,
  `loan_class` char(3) DEFAULT NULL,
  `last_seen` date DEFAULT NULL,
  `loan_status` char(1) DEFAULT NULL,
  `loan_alert` char(1) DEFAULT NULL,
  `loan_alert_note` text,
  `usage_count` int(11) DEFAULT '0',
  `delivery_library_id` int(11) DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `patron_id` int(11) DEFAULT NULL,
  `external_library_id` int(11) DEFAULT NULL,
  `renewal_count` int(11) NOT NULL DEFAULT '0',
  `notify_count` int(11) DEFAULT '0',
  `check_out` datetime DEFAULT NULL,
  `check_in` datetime DEFAULT NULL,
  `ill_timestamp` datetime DEFAULT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `order_id` int(11) DEFAULT NULL,
  `budget_id` int(11) DEFAULT NULL,
  `currency` varchar(3) DEFAULT NULL,
  `currency_value` decimal(10,2) DEFAULT NULL,
  `discount_value` decimal(4,2) NOT NULL DEFAULT '0.00',
  `inventory_value` decimal(10,2) DEFAULT NULL,
  `issue_inventory_number` int(11) DEFAULT NULL,
  `issue_id` int(11) DEFAULT NULL,
  `issue_year` varchar(4) DEFAULT NULL,
  `issue_number` int(11) NOT NULL,
  `issue_description` varchar(128) DEFAULT NULL,
  `issue_arrival_date` date DEFAULT NULL,
  `issue_arrival_date_expected` date DEFAULT NULL,
  `issue_status` char(1) DEFAULT NULL,
  `subscription_id` int(11) DEFAULT NULL,
  `consistency_note_id` int(11) DEFAULT NULL,
  `actual_library_id` int(11) DEFAULT NULL,
  `barcode` varchar(64) DEFAULT NULL,
  `rfid_code` varchar(64) DEFAULT NULL,
  `custom_field1` varchar(255) DEFAULT NULL,
  `custom_field2` varchar(128) DEFAULT NULL,
  `custom_field3` varchar(128) DEFAULT NULL,
  `unimarc` text,
  `last_sbn_sync` datetime DEFAULT NULL,
  `date_discarded` datetime DEFAULT NULL,
  `discard_note` varchar(256) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `date_updated` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`item_id`),
  KEY `ownlib_status_idx` (`owner_library_id`,`item_status`),
  KEY `idx_item_loanstatus` (`loan_status`),
  KEY `item_issue_number_idx` (`issue_description`),
  KEY `item_barcode_idx` (`barcode`),
  KEY `item_rfidcode_idx` (`rfid_code`),
  KEY `Igm_idx` (`inventory_date`,`item_media`,`item_source`,`owner_library_id`),
  KEY `FI__issue_item` (`issue_id`),
  KEY `FI__08` (`manifestation_id`),
  KEY `FI__08_consistency` (`consistency_note_id`),
  KEY `FI_m__home_library_idx` (`home_library_id`),
  KEY `FI__item_delivery` (`delivery_library_id`),
  KEY `FI__item_actual` (`actual_library_id`),
  KEY `FI__24` (`inventory_serie_id`),
  KEY `FI__40` (`order_id`),
  KEY `FI__44g` (`invoice_id`),
  KEY `FI__44h` (`created_by`),
  KEY `FI__44i` (`modified_by`),
  KEY `FI__Patron_Item` (`patron_id`),
  KEY `FI__Loan_Item2` (`current_loan_id`),
  KEY `FI__item_external_library` (`external_library_id`),
  KEY `item_issue_year_idx` (`issue_year`),
  KEY `item_request_speedup` (`manifestation_id`,`actual_library_id`,`loan_class`,`loan_status`),
  KEY `Man_lastdate` (`manifestation_id`,`inventory_date`),
  KEY `budget_idx` (`budget_id`),
  KEY `inventory_serie_idx` (`inventory_serie_id`,`inventory_number`)
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;



CREATE TABLE `item_action` (
  `item_action_id` int(11) NOT NULL AUTO_INCREMENT,
  `library_id` int(11) NOT NULL,
  `item_id` int(11) DEFAULT NULL,
  `loan_id` int(11) DEFAULT NULL,
  `notification_id` int(11) DEFAULT NULL,
  `patron_id` int(11) DEFAULT NULL,
  `external_library_id` int(11) DEFAULT NULL,
  `librarian_id` int(11) DEFAULT NULL,
  `action_type` char(3) DEFAULT NULL,
  `action_date` datetime DEFAULT NULL,
  `from_library_id` int(11) DEFAULT NULL,
  `to_library_id` int(11) DEFAULT NULL,
  `action_note` varchar(255) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `date_updated` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`item_action_id`),
  KEY `FI__ItemAct_Created` (`created_by`),
  KEY `FI__ItemAct_Modified` (`modified_by`),
  KEY `FI__25` (`item_id`),
  KEY `FI__45` (`patron_id`),
  KEY `FI__itemaction_external_library` (`external_library_id`),
  KEY `FI__46` (`library_id`),
  KEY `FI__47` (`from_library_id`),
  KEY `FI__48` (`to_library_id`),
  KEY `item_action_FI_4` (`loan_id`),
  KEY `item_action_FI_5` (`notification_id`)
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;



CREATE TABLE `item_note` (
  `note_id` int(11) NOT NULL AUTO_INCREMENT,
  `note_type` char(3) DEFAULT NULL,
  `item_id` int(11) DEFAULT NULL,
  `note` text,
  PRIMARY KEY (`note_id`),
  KEY `FI__itemnote_item` (`item_id`)
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;



CREATE TABLE `item_request` (
  `request_id` int(11) NOT NULL AUTO_INCREMENT,
  `request_status` char(1) DEFAULT NULL,
  `manifestation_id` int(11) NOT NULL,
  `item_id` int(11) DEFAULT NULL,
  `issue_id` int(11) DEFAULT NULL,
  `patron_id` int(11) DEFAULT NULL,
  `external_library_id` int(11) DEFAULT NULL,
  `delivery_library_id` int(11) DEFAULT NULL,
  `max_distance` int(11) DEFAULT NULL,
  `request_type` char(1) DEFAULT NULL,
  `librarian_id` int(11) DEFAULT NULL,
  `request_date` datetime DEFAULT NULL,
  `expire_date` datetime DEFAULT NULL,
  `request_note` varchar(255) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `date_updated` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`request_id`),
  KEY `FI__itemreq_2` (`created_by`),
  KEY `FI__itemreq_3` (`modified_by`),
  KEY `FI__itemreq_librarian` (`librarian_id`),
  KEY `FI__itemreq_patron` (`patron_id`),
  KEY `FI__itemreq_external_library` (`external_library_id`),
  KEY `FI__itemreq_man` (`manifestation_id`),
  KEY `FI__itemreq_item` (`item_id`),
  KEY `FI__ItemReq_Issue` (`issue_id`),
  KEY `FI__itemreq_library` (`delivery_library_id`),
  KEY `item_request_I_1` (`request_status`,`expire_date`)
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;



CREATE TABLE `kpi_query` (
  `query_id` int(11) NOT NULL AUTO_INCREMENT,
  `master_key` varchar(255) DEFAULT NULL,
  `slave_key` varchar(255) DEFAULT NULL,
  `sql` text,
  `cron_exp` varchar(255) DEFAULT NULL,
  `next_exec_time` datetime DEFAULT NULL,
  `description` text,
  PRIMARY KEY (`query_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



CREATE TABLE `kpi_value` (
  `id_date` datetime NOT NULL,
  `master_key` varchar(255) NOT NULL,
  `slave_key` varchar(255) NOT NULL,
  `library_id` int(11) NOT NULL,
  `num_val` decimal(12,2) DEFAULT NULL,
  `txt_val` text,
  PRIMARY KEY (`id_date`,`master_key`,`slave_key`,`library_id`),
  KEY `ma_sl` (`master_key`,`slave_key`),
  KEY `lib_ma_sl` (`library_id`,`master_key`,`slave_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



CREATE TABLE `l_authority` (
  `authority_id_down` int(11) NOT NULL,
  `authority_id_up` int(11) NOT NULL,
  `link_type` char(3) NOT NULL,
  `relator_code` char(3) NOT NULL DEFAULT '',
  `link_sequence` varchar(16) NOT NULL,
  `link_note` text,
  `source_sync` char(1) DEFAULT '0',
  PRIMARY KEY (`authority_id_down`,`authority_id_up`,`link_type`,`relator_code`),
  KEY `FI__10` (`authority_id_up`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



CREATE TABLE `l_authority_item` (
  `authority_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `link_type` int(11) NOT NULL,
  `relator_code` char(3) NOT NULL,
  `link_sequence` int(11) DEFAULT NULL,
  `link_note` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`authority_id`,`item_id`,`link_type`,`relator_code`),
  KEY `FI__authitem_02` (`item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



CREATE TABLE `l_authority_manifestation` (
  `authority_id` int(11) NOT NULL,
  `manifestation_id` int(11) NOT NULL,
  `link_type` int(11) NOT NULL,
  `relator_code` char(3) NOT NULL,
  `link_sequence` int(11) DEFAULT NULL,
  `link_note` varchar(255) DEFAULT NULL,
  `source_sync` char(1) DEFAULT '0',
  PRIMARY KEY (`authority_id`,`manifestation_id`,`relator_code`,`link_type`) USING BTREE,
  KEY `FI__07` (`manifestation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



CREATE TABLE `l_librarian_profile` (
  `profile_id` int(11) NOT NULL,
  `librarian_id` int(11) NOT NULL,
  `sort_order` int(11) DEFAULT NULL,
  PRIMARY KEY (`profile_id`,`librarian_id`),
  KEY `FI__Librarian_Profile` (`librarian_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



CREATE TABLE `l_library` (
  `from_library_id` int(11) NOT NULL,
  `to_library_id` int(11) NOT NULL,
  `distance` int(11) DEFAULT NULL,
  PRIMARY KEY (`from_library_id`,`to_library_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



CREATE TABLE `l_library_librarian` (
  `library_id` int(11) NOT NULL,
  `librarian_id` int(11) NOT NULL,
  `link_role` char(3) DEFAULT NULL,
  `opac_visible` tinyint(4) DEFAULT '1',
  PRIMARY KEY (`library_id`,`librarian_id`),
  KEY `FI__24` (`librarian_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



CREATE TABLE `l_manifestation` (
  `manifestation_id_up` int(11) NOT NULL,
  `manifestation_id_down` int(11) NOT NULL,
  `link_type` int(11) DEFAULT NULL,
  `link_sequence` varchar(16) DEFAULT NULL,
  `link_note` varchar(255) DEFAULT NULL,
  `issue_id` int(11) DEFAULT NULL,
  `source_sync` char(1) DEFAULT '0',
  PRIMARY KEY (`manifestation_id_up`,`manifestation_id_down`),
  KEY `FI__l_man_issue` (`issue_id`),
  KEY `FI__20` (`manifestation_id_down`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



CREATE TABLE `l_patron` (
  `parent_patron_id` int(11) NOT NULL,
  `child_patron_id` int(11) NOT NULL,
  `link_type` char(2) DEFAULT NULL,
  PRIMARY KEY (`parent_patron_id`,`child_patron_id`),
  KEY `FI__27` (`child_patron_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



CREATE TABLE `l_subject` (
  `authority_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `position` int(11) NOT NULL,
  `type` char(1) DEFAULT NULL,
  `connector` varchar(32) DEFAULT '- ',
  PRIMARY KEY (`authority_id`,`subject_id`,`position`),
  KEY `FI__subject_02` (`subject_id`),
  KEY `lsubject_connector_idx` (`connector`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



CREATE TABLE `librarian` (
  `librarian_id` int(11) NOT NULL AUTO_INCREMENT,
  `patron_id` int(11) DEFAULT NULL,
  `name` varchar(64) DEFAULT NULL,
  `lastname` varchar(64) DEFAULT NULL,
  `birthdate` date DEFAULT NULL,
  `phone` varchar(16) DEFAULT NULL,
  `email` varchar(64) DEFAULT NULL,
  `username` varchar(32) NOT NULL,
  `secret` varchar(32) DEFAULT NULL,
  `secret_expire` date DEFAULT NULL,
  `librarian_expire` date DEFAULT NULL,
  `preferences` text,
  `default_library_id` int(11) DEFAULT NULL,
  `cat_level` char(2) DEFAULT '05',
  `activation_status` char(1) DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `date_updated` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`librarian_id`),
  UNIQUE KEY `librarian_U_1` (`username`),
  KEY `FI__444t` (`default_library_id`),
  KEY `FI__44r` (`created_by`),
  KEY `FI__44s` (`modified_by`),
  KEY `I_referenced_patron_FK_5_1` (`patron_id`)
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;



CREATE TABLE `librarian_session` (
  `librarian_session_id` int(11) NOT NULL AUTO_INCREMENT,
  `librarian_id` int(11) DEFAULT NULL,
  `current_library_id` int(11) DEFAULT NULL,
  `session_id_string` varchar(128) DEFAULT NULL,
  `start_date` datetime DEFAULT NULL,
  `last_action_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `public_ip` varchar(15) DEFAULT NULL,
  `local_ip` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`librarian_session_id`),
  KEY `FI__444r` (`librarian_id`),
  KEY `FI__445r` (`current_library_id`),
  KEY `librarian_end_date` (`librarian_id`,`end_date`)
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;



CREATE TABLE `librarian_task` (
  `task_id` int(11) NOT NULL AUTO_INCREMENT,
  `task_title` varchar(255) DEFAULT NULL,
  `task_note` text,
  `library_id` int(11) DEFAULT NULL,
  `assigned_librarian_id` int(11) DEFAULT NULL,
  `due_date` datetime DEFAULT NULL,
  `start_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `task_status` char(1) DEFAULT NULL,
  `done_percent` int(11) DEFAULT '0',
  `date_created` datetime DEFAULT NULL,
  `date_updated` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`task_id`),
  KEY `task_duedate_idx` (`due_date`),
  KEY `FI__task_librarian` (`assigned_librarian_id`),
  KEY `FI__task_library` (`library_id`),
  KEY `FI__4414` (`created_by`),
  KEY `FI__4415` (`modified_by`)
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;



CREATE TABLE `library` (
  `library_id` int(11) NOT NULL AUTO_INCREMENT,
  `library_class` varchar(4) DEFAULT NULL,
  `consortia_id` char(7) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `label` varchar(255) DEFAULT NULL,
  `shortlabel` char(16) DEFAULT NULL,
  `library_code` varchar(8) DEFAULT NULL,
  `ill_code` varchar(64) NOT NULL,
  `sbn_code` char(2) DEFAULT NULL,
  `library_type` char(1) DEFAULT NULL,
  `library_internal` char(1) NOT NULL DEFAULT '1',
  `library_status` char(1) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `phone` varchar(16) DEFAULT NULL,
  `fax` varchar(16) DEFAULT NULL,
  `email` varchar(128) DEFAULT NULL,
  `billing_address` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `province` varchar(255) DEFAULT NULL,
  `country` varchar(128) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `date_updated` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`library_id`),
  KEY `FI__26` (`consortia_id`),
  KEY `FI__44p` (`created_by`),
  KEY `FI__44q` (`modified_by`)
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;



CREATE TABLE `library_property` (
  `library_property_id` int(11) NOT NULL AUTO_INCREMENT,
  `library_id` int(11) NOT NULL,
  `property_class` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `property_value` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `date_updated` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`library_property_id`),
  KEY `library_idx` (`library_id`),
  KEY `class_idx` (`property_class`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



CREATE TABLE `library_timetable` (
  `timetable_id` int(11) NOT NULL AUTO_INCREMENT,
  `library_id` int(11) NOT NULL,
  `timetable_day` date NOT NULL,
  `timetable_open` tinyint(1) DEFAULT '0',
  `timetable_holiday` tinyint(1) DEFAULT '0',
  `time1_start` time DEFAULT NULL,
  `time1_end` time DEFAULT NULL,
  `time2_start` time DEFAULT NULL,
  `time2_end` time DEFAULT NULL,
  `time3_start` time DEFAULT NULL,
  `time3_end` time DEFAULT NULL,
  `timetable_note` varchar(255) DEFAULT '',
  `date_created` datetime DEFAULT NULL,
  `date_updated` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`timetable_id`),
  KEY `library_day` (`library_id`,`timetable_day`)
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;



CREATE TABLE `library_value` (
  `value_key` varchar(64) NOT NULL,
  `value_class` varchar(64) NOT NULL,
  `value_library_id` int(11) NOT NULL DEFAULT '0',
  `value_label` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`value_key`,`value_class`,`value_library_id`),
  KEY `FI__55` (`value_library_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



CREATE TABLE `loan` (
  `loan_id` int(11) NOT NULL AUTO_INCREMENT,
  `loan_status` char(1) DEFAULT NULL,
  `loan_type` char(1) DEFAULT NULL,
  `loan_class` varchar(3) DEFAULT NULL,
  `manifestation_id` int(11) DEFAULT NULL,
  `item_id` int(11) DEFAULT NULL,
  `item_owner_library_id` int(11) DEFAULT NULL,
  `item_home_library_id` int(11) DEFAULT NULL,
  `itemrequest_id` int(11) DEFAULT NULL,
  `patron_id` int(11) DEFAULT NULL,
  `external_library_id` int(11) DEFAULT NULL,
  `destination_name` varchar(255) DEFAULT NULL,
  `patron_age` int(11) DEFAULT NULL,
  `patron_city` varchar(255) DEFAULT NULL,
  `patron_stat1` varchar(16) DEFAULT NULL,
  `patron_stat2` varchar(16) DEFAULT NULL,
  `patron_stat3` varchar(16) DEFAULT NULL,
  `item_inventory_date` datetime DEFAULT NULL,
  `item_stat1` varchar(16) DEFAULT NULL,
  `item_stat2` varchar(16) DEFAULT NULL,
  `item_stat3` varchar(16) DEFAULT NULL,
  `loan_date1` datetime DEFAULT NULL,
  `loan_date2` datetime DEFAULT NULL,
  `loan_date3` datetime DEFAULT NULL,
  `title` text,
  `class_code` varchar(16) DEFAULT NULL,
  `inv_number` varchar(16) DEFAULT NULL,
  `collocation` varchar(16) DEFAULT NULL,
  `item_media` char(3) DEFAULT NULL,
  `mediapackage_size` int(11) NOT NULL DEFAULT '1',
  `loan_date_begin` datetime DEFAULT NULL,
  `loan_date_end` datetime DEFAULT NULL,
  `due_date` datetime DEFAULT NULL,
  `from_library` int(11) DEFAULT NULL,
  `to_library` int(11) DEFAULT NULL,
  `end_library` int(11) DEFAULT NULL,
  `renew_count` int(11) NOT NULL DEFAULT '0',
  `notify_count` int(11) DEFAULT '0',
  `notify_auto_count` int(11) DEFAULT '0',
  PRIMARY KEY (`loan_id`),
  KEY `idx_loan_loanstatus` (`loan_status`),
  KEY `FI__loan_date_begin` (`loan_date_begin`),
  KEY `FI__to_library` (`to_library`),
  KEY `FI__loan_item` (`item_id`),
  KEY `FI__loan_manifestation` (`manifestation_id`),
  KEY `FI__loan_fromlib` (`from_library`),
  KEY `FI__loan_endlib` (`end_library`),
  KEY `idx_loan_manifestation_id` (`manifestation_id`),
  KEY `loantype_idx` (`loan_type`),
  KEY `FI__loan_external_library` (`external_library_id`),
  KEY `loan_loantype_idx` (`loan_type`),
  KEY `FI__loan_patron` (`patron_id`,`loan_status`)
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;



CREATE TABLE `loan_fee` (
  `fee_id` int(11) NOT NULL AUTO_INCREMENT,
  `loan_id` int(11) NOT NULL,
  `patron_id` int(11) NOT NULL,
  `wallet_id` int(11) DEFAULT NULL,
  `fee_status` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `grace_days` int(11) DEFAULT '0',
  `grace_note` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `note` varchar(1024) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fee_class` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `total_ammount` decimal(10,0) DEFAULT NULL,
  `real_ammount` decimal(10,0) DEFAULT NULL,
  `library_id` int(11) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `date_updated` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`fee_id`),
  KEY `loan_fee_FI_3` (`loan_id`),
  KEY `loan_fee_FI_4` (`patron_id`),
  KEY `loan_fee_FI_5` (`wallet_id`),
  KEY `loan_fee_FI_6` (`library_id`),
  KEY `loan_fee_FI_1` (`created_by`),
  KEY `loan_fee_FI_2` (`modified_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



CREATE TABLE `lookup_value` (
  `value_key` varchar(64) NOT NULL,
  `value_language` varchar(6) NOT NULL,
  `value_class` varchar(64) NOT NULL,
  `value_label` varchar(255) DEFAULT NULL,
  `sortable_rank` int(11) DEFAULT NULL,
  `sortable_scope` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`value_key`,`value_language`,`value_class`),
  KEY `sugg_label` (`value_class`,`value_language`,`value_label`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



CREATE TABLE `manifestation` (
  `manifestation_id` int(11) NOT NULL AUTO_INCREMENT,
  `bib_level` char(1) DEFAULT NULL,
  `bib_type` char(3) DEFAULT NULL,
  `bib_type_first` char(3) DEFAULT NULL,
  `hierarchical_level` int(11) DEFAULT NULL,
  `catalogation_level` char(2) DEFAULT '05',
  `manifestation_status` char(1) DEFAULT NULL,
  `edition_language` char(3) DEFAULT NULL,
  `edition_date` int(11) DEFAULT NULL,
  `unimarc` mediumtext,
  `bid_source` varchar(64) DEFAULT NULL,
  `bid` varchar(64) DEFAULT NULL,
  `ISBNISSN` varchar(32) DEFAULT NULL,
  `EAN` varchar(32) DEFAULT NULL,
  `non_sort_text` varchar(128) DEFAULT NULL,
  `sort_text` varchar(255) DEFAULT NULL,
  `title` varchar(2000) DEFAULT NULL,
  `author` varchar(1000) DEFAULT NULL,
  `publisher` varchar(1000) DEFAULT NULL,
  `loanable_since` datetime DEFAULT NULL,
  `rating` int(11) DEFAULT NULL,
  `last_sbn_sync` datetime DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `date_updated` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`manifestation_id`),
  KEY `edition_language_idx` (`edition_language`),
  KEY `man_bid_idx` (`bid`),
  KEY `man_isbn_idx` (`ISBNISSN`),
  KEY `man_ean_idx` (`EAN`),
  KEY `man_sort_text_idx` (`sort_text`),
  KEY `FI__44e` (`created_by`),
  KEY `FI__44f` (`modified_by`)
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;



CREATE TABLE `notification` (
  `notification_id` int(11) NOT NULL AUTO_INCREMENT,
  `notification_state` char(1) DEFAULT NULL,
  `notification_channel` char(1) DEFAULT NULL,
  `notification_class` varchar(4) DEFAULT NULL,
  `object_class` varchar(64) DEFAULT NULL,
  `object_id` int(11) DEFAULT NULL,
  `sender_library_id` int(11) DEFAULT NULL,
  `delivery_date` datetime DEFAULT NULL,
  `acknowledge_date` datetime DEFAULT NULL,
  `internal_status` varchar(32) DEFAULT '',
  `message` text,
  `notes` text,
  `date_created` datetime DEFAULT NULL,
  `date_updated` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`notification_id`),
  KEY `FI__445x` (`created_by`),
  KEY `FI__446x` (`modified_by`),
  KEY `idx_object` (`object_class`,`object_id`),
  KEY `notification_channel` (`notification_channel`,`notification_state`,`delivery_date`),
  KEY `object_id_class_idx` (`object_id`,`object_class`),
  KEY `notification_class_idx` (`notification_class`)
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;



CREATE TABLE `patron` (
  `patron_id` int(11) NOT NULL AUTO_INCREMENT,
  `registration_library_id` int(11) NOT NULL,
  `preferred_library_id` int(11) NOT NULL,
  `gender` char(1) DEFAULT NULL,
  `title` varchar(64) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `lastname` varchar(255) DEFAULT NULL,
  `civil_status` char(1) DEFAULT NULL,
  `national_id` varchar(64) DEFAULT NULL,
  `document_type` varchar(64) DEFAULT NULL,
  `document_number` varchar(64) DEFAULT NULL,
  `document_emitter` varchar(64) DEFAULT NULL,
  `document_expiry` date DEFAULT NULL,
  `citizenship` varchar(64) DEFAULT NULL,
  `patron_status` char(1) DEFAULT NULL,
  `birth_date` date DEFAULT NULL,
  `birth_city` varchar(255) DEFAULT NULL,
  `birth_province` varchar(255) DEFAULT NULL,
  `birth_country` varchar(255) DEFAULT NULL,
  `patron_note` text,
  `loan_class` char(1) DEFAULT NULL,
  `card_code` varchar(64) DEFAULT NULL,
  `barcode` varchar(64) DEFAULT NULL,
  `rfid_code` varchar(64) DEFAULT NULL,
  `card_expire` date DEFAULT NULL,
  `max_loans` int(11) DEFAULT NULL,
  `surf_enable` char(1) DEFAULT NULL,
  `opac_username` varchar(64) DEFAULT NULL,
  `opac_secret` char(40) DEFAULT NULL,
  `opac_secret_expire` date DEFAULT NULL,
  `voice_enable` char(1) DEFAULT NULL,
  `voice_pin` varchar(8) DEFAULT NULL,
  `opac_enable` char(1) DEFAULT NULL,
  `privacy_approve` char(1) DEFAULT NULL,
  `areas_of_interest` text,
  `biography` text,
  `access_note` varchar(255) DEFAULT NULL,
  `access_alert` char(1) DEFAULT NULL,
  `statistic_study` char(1) DEFAULT NULL,
  `statistic_work` char(1) DEFAULT NULL,
  `last_seen` datetime DEFAULT NULL,
  `custom1` varchar(255) DEFAULT NULL,
  `custom2` varchar(255) DEFAULT NULL,
  `custom3` varchar(255) DEFAULT NULL,
  `check_in` datetime DEFAULT NULL,
  `check_out` datetime DEFAULT NULL,
  `check_library` int(11) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `date_updated` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`patron_id`),
  UNIQUE KEY `patron_barcode_idx` (`barcode`),
  KEY `patron_crdcode_idx` (`card_code`),
  KEY `patron_rfidcode_idx` (`rfid_code`),
  KEY `patron_username_idx` (`opac_username`),
  KEY `FI__51` (`registration_library_id`),
  KEY `FI__52` (`preferred_library_id`),
  KEY `FI__44t` (`created_by`),
  KEY `FI__44u` (`modified_by`),
  KEY `patron_lastname` (`lastname`(128),`name`(128)),
  KEY `check_out_idx` (`check_out`),
  KEY `patron_FI_5` (`check_library`),
  KEY `patron_national_idx` (`national_id`)
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;



CREATE TABLE `patron_action` (
  `action_id` int(11) NOT NULL AUTO_INCREMENT,
  `patron_id` int(11) NOT NULL,
  `library_id` int(11) DEFAULT NULL,
  `action_type` char(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `action_date` datetime DEFAULT NULL,
  `action_note` text COLLATE utf8_unicode_ci,
  `action_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `date_updated` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`action_id`),
  KEY `patron_action_FI_3` (`patron_id`),
  KEY `patron_action_FI_4` (`library_id`),
  KEY `patron_action_FI_1` (`created_by`),
  KEY `patron_action_FI_2` (`modified_by`)
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



CREATE TABLE `patron_property` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `patron_id` int(11) NOT NULL,
  `property_class` char(1) NOT NULL,
  `property_value` varchar(255) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `date_updated` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `patron_idx` (`patron_id`),
  KEY `class_idx` (`property_class`)
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;



CREATE TABLE `patron_wallet` (
  `wallet_id` int(11) NOT NULL AUTO_INCREMENT,
  `patron_id` int(11) DEFAULT NULL,
  `library_id` int(11) NOT NULL,
  `wallet_action` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `wallet_type` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `wallet_status` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `wallet_note` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_closed` date DEFAULT NULL,
  `receipt_id` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `date_updated` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`wallet_id`),
  UNIQUE KEY `receipt_idx` (`receipt_id`,`library_id`),
  KEY `patron_wallet_FI_3` (`patron_id`),
  KEY `patron_wallet_FI_4` (`library_id`),
  KEY `patron_wallet_FI_1` (`created_by`),
  KEY `patron_wallet_FI_2` (`modified_by`)
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



CREATE TABLE `purchase_order` (
  `order_id` int(11) NOT NULL AUTO_INCREMENT,
  `library_id` int(11) DEFAULT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `account_id` varchar(32) DEFAULT NULL,
  `order_title` varchar(255) DEFAULT NULL,
  `order_date` date DEFAULT NULL,
  `delivery_date` date DEFAULT NULL,
  `order_discount` decimal(4,2) DEFAULT NULL,
  `order_type` char(1) DEFAULT NULL,
  `order_status` char(1) DEFAULT NULL,
  `order_note` text,
  `date_created` datetime DEFAULT NULL,
  `date_updated` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`order_id`),
  KEY `FI__41` (`library_id`),
  KEY `FI__42` (`supplier_id`),
  KEY `FI__44aa` (`created_by`),
  KEY `FI__44bb` (`modified_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



CREATE TABLE `purchase_proposal` (
  `proposal_id` int(11) NOT NULL AUTO_INCREMENT,
  `patron_id` int(11) NOT NULL,
  `author` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `publisher` varchar(255) DEFAULT NULL,
  `year` int(11) DEFAULT NULL,
  `notes` varchar(255) DEFAULT NULL,
  `librarian_notes` varchar(255) DEFAULT NULL,
  `status` char(1) DEFAULT NULL,
  `ean` varchar(16) DEFAULT NULL,
  `rda` varchar(255) NOT NULL,
  `item_id` int(11) DEFAULT NULL,
  `proposal_date` datetime DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `date_updated` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`proposal_id`),
  KEY `proposal_patron_index` (`patron_id`),
  KEY `FI__56bis` (`modified_by`),
  KEY `FI__Proposal_Created` (`created_by`)
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;



CREATE TABLE `query_log` (
  `log_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `librarian_id` int(11) NOT NULL,
  `database_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ip_address` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `event_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `event_data` varchar(4000) COLLATE utf8_unicode_ci NOT NULL,
  `date_created` datetime NOT NULL,
  PRIMARY KEY (`log_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



CREATE TABLE `resource` (
  `resource_id` int(11) NOT NULL AUTO_INCREMENT,
  `resource_external_id` varchar(255) DEFAULT NULL,
  `resource_class` varchar(255) DEFAULT NULL,
  `resource_status` char(1) DEFAULT NULL,
  `library_id` int(11) NOT NULL,
  `name` varchar(128) NOT NULL,
  `shortname` varchar(32) NOT NULL,
  `type` varchar(30) NOT NULL,
  `ports` int(5) DEFAULT NULL,
  `secret` varchar(255) DEFAULT NULL,
  `server` varchar(64) DEFAULT NULL,
  `community` varchar(50) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `admin_usr` varchar(255) DEFAULT NULL,
  `admin_pwd` varchar(255) DEFAULT NULL,
  `note` text,
  `wellcome_url` text,
  PRIMARY KEY (`resource_id`),
  KEY `name_index` (`name`),
  KEY `external_id_index` (`resource_external_id`),
  KEY `resource_FI_1` (`library_id`)
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;



CREATE TABLE `resource_request` (
  `resource_request_id` int(11) NOT NULL AUTO_INCREMENT,
  `resource_id` int(11) NOT NULL,
  `resource_action` char(1) DEFAULT NULL,
  `patron_id` int(11) DEFAULT NULL,
  `request_note` varchar(255) DEFAULT NULL,
  `request_start` datetime DEFAULT NULL,
  `request_end` datetime DEFAULT NULL,
  `time_tolerance` int(11) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `date_updated` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`resource_request_id`),
  KEY `resource_request_FI_3` (`resource_id`),
  KEY `resource_request_FI_4` (`patron_id`),
  KEY `resource_request_FI_1` (`created_by`),
  KEY `resource_request_FI_2` (`modified_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



CREATE TABLE `resource_rule` (
  `resource_rule_id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `priority` int(11) NOT NULL,
  `resource_pattern` varchar(255) NOT NULL,
  `resource_owner` varchar(255) DEFAULT NULL,
  `library_id` int(11) NOT NULL,
  `patron_id` int(11) DEFAULT NULL,
  `amount` float(10,2) DEFAULT '0.00',
  `used` float(10,2) DEFAULT '0.00',
  `validity_start` datetime DEFAULT NULL,
  `validity_end` datetime DEFAULT NULL,
  `note` text,
  PRIMARY KEY (`resource_rule_id`)
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;



CREATE TABLE `resource_session` (
  `resource_session_id` int(11) NOT NULL AUTO_INCREMENT,
  `resource_id` int(11) NOT NULL,
  `patron_id` int(11) NOT NULL,
  `library_id` int(11) NOT NULL DEFAULT '0',
  `nasname` varchar(128) DEFAULT NULL,
  `shortname` varchar(32) DEFAULT NULL,
  `type` varchar(30) DEFAULT NULL,
  `ports` int(5) DEFAULT NULL,
  `secret` varchar(60) NOT NULL,
  `server` varchar(64) DEFAULT NULL,
  `community` varchar(50) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `acctsessionid` varchar(64) NOT NULL DEFAULT '',
  `acctuniqueid` varchar(32) NOT NULL DEFAULT '',
  `username` varchar(64) NOT NULL DEFAULT '',
  `groupname` varchar(64) NOT NULL DEFAULT '',
  `realm` varchar(64) DEFAULT '',
  `nasipaddress` varchar(15) NOT NULL DEFAULT '',
  `nasportid` varchar(15) DEFAULT NULL,
  `nasporttype` varchar(32) DEFAULT NULL,
  `acctstarttime` datetime DEFAULT NULL,
  `acctstoptime` datetime DEFAULT NULL,
  `acctsessiontime` int(12) DEFAULT NULL,
  `acctauthentic` varchar(32) DEFAULT NULL,
  `connectinfo_start` varchar(50) DEFAULT NULL,
  `connectinfo_stop` varchar(50) DEFAULT NULL,
  `acctinputoctets` bigint(20) DEFAULT NULL,
  `acctoutputoctets` bigint(20) DEFAULT NULL,
  `calledstationid` varchar(50) NOT NULL DEFAULT '',
  `callingstationid` varchar(50) NOT NULL DEFAULT '',
  `acctterminatecause` varchar(32) NOT NULL DEFAULT '',
  `servicetype` varchar(32) DEFAULT NULL,
  `framedprotocol` varchar(32) DEFAULT NULL,
  `framedipaddress` varchar(15) NOT NULL DEFAULT '',
  `acctstartdelay` int(12) DEFAULT NULL,
  `acctstopdelay` int(12) DEFAULT NULL,
  `xascendsessionsvrkey` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`resource_session_id`),
  UNIQUE KEY `resource_session_U_1` (`acctuniqueid`),
  KEY `resource_session_FI_1` (`resource_id`),
  KEY `resource_session_FI_2` (`patron_id`),
  KEY `library_id` (`library_id`),
  KEY `acctsessionid_idx` (`acctsessionid`),
  KEY `used_time_idx` (`patron_id`,`acctstoptime`),
  CONSTRAINT `resource_session_ibfk_1` FOREIGN KEY (`library_id`) REFERENCES `library` (`library_id`)
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;



CREATE TABLE `robot` (
  `robot_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL,
  `object` varchar(255) DEFAULT NULL,
  `robot_state` char(1) DEFAULT NULL,
  `script` varchar(255) DEFAULT NULL,
  `sort_order` int(11) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `date_updated` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`robot_id`),
  KEY `FI__Robot_Libr1` (`created_by`),
  KEY `FI__Robot_Libr2` (`modified_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



CREATE TABLE `shelf` (
  `shelf_id` int(11) NOT NULL AUTO_INCREMENT,
  `shelf_name` varchar(255) DEFAULT NULL,
  `shelf_description` text,
  `shelf_status` char(1) DEFAULT NULL,
  `shelf_itemtype` varchar(64) DEFAULT NULL,
  `librarian_id` int(11) NOT NULL,
  `library_id` int(11) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `date_updated` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `sortable_rank` int(11) DEFAULT NULL,
  PRIMARY KEY (`shelf_id`),
  KEY `FI__library_shelf` (`library_id`),
  KEY `FI__owner` (`librarian_id`),
  KEY `FI__Shelf_Created` (`created_by`),
  KEY `FI__Shelf_Modified` (`modified_by`),
  KEY `shelf_itemtype` (`shelf_itemtype`),
  KEY `itemtype_idx` (`shelf_itemtype`)
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;



CREATE TABLE `shelf_item` (
  `shelf_id` int(11) NOT NULL,
  `object_id` int(11) NOT NULL,
  `object_class` varchar(32) NOT NULL,
  `item_status` char(1) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `date_updated` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`shelf_id`,`object_id`,`object_class`),
  KEY `FI__Shelfitem_Created` (`created_by`),
  KEY `idx_object` (`object_class`,`object_id`),
  KEY `object_idx` (`object_id`,`object_class`,`shelf_id`),
  CONSTRAINT `Rel_Shelfitem_Created` FOREIGN KEY (`created_by`) REFERENCES `librarian` (`librarian_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



CREATE TABLE `subscription` (
  `subscription_id` int(11) NOT NULL AUTO_INCREMENT,
  `library_id` int(11) NOT NULL,
  `manifestation_id` int(11) NOT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `budget_id` int(11) DEFAULT NULL,
  `year` int(11) DEFAULT NULL,
  `volume` int(11) DEFAULT NULL,
  `frequence` char(1) DEFAULT NULL,
  `tolerance` int(11) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `subscription_status` char(1) DEFAULT NULL,
  `subscription_type` char(1) DEFAULT NULL,
  `ejournal_provider` int(11) DEFAULT NULL,
  `management` char(1) DEFAULT NULL,
  `payment` text,
  `notes` varchar(255) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `date_updated` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`subscription_id`),
  KEY `FI__27` (`library_id`),
  KEY `FI__SubMan` (`manifestation_id`),
  KEY `FI__SubSup` (`supplier_id`),
  KEY `FI__SupBud` (`budget_id`),
  KEY `FI__44l` (`created_by`),
  KEY `FI__44m` (`modified_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



CREATE TABLE `supplier` (
  `supplier_id` int(11) NOT NULL AUTO_INCREMENT,
  `supplier_name` varchar(255) DEFAULT NULL,
  `supplier_code` varchar(32) DEFAULT NULL,
  `vat_code` varchar(64) DEFAULT NULL,
  `supplier_status` char(1) DEFAULT NULL,
  `payment_mode` char(1) DEFAULT NULL,
  `cc` varchar(255) DEFAULT NULL,
  `phone_number` varchar(24) DEFAULT NULL,
  `phone_number2` varchar(24) DEFAULT NULL,
  `fax_number` varchar(24) DEFAULT NULL,
  `email` varchar(128) DEFAULT NULL,
  `contact_name` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `province` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `country` varchar(64) DEFAULT NULL,
  `zipcode` int(11) DEFAULT NULL,
  `discount` decimal(5,2) DEFAULT NULL,
  `notes` text,
  `date_created` datetime DEFAULT NULL,
  `date_updated` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`supplier_id`),
  KEY `FI__44oo` (`created_by`),
  KEY `FI__44pp` (`modified_by`)
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;



CREATE TABLE `turbomarc_cache` (
  `manifestation_id` int(11) NOT NULL,
  `turbomarc` longtext COLLATE utf8_unicode_ci,
  `dirty` tinyint(1) DEFAULT NULL,
  `indexed` tinyint(1) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`manifestation_id`),
  KEY `dirty_idx` (`dirty`),
  KEY `indexed` (`indexed`),
  KEY `deleted` (`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



CREATE TABLE `turbomarcauthority_cache` (
  `authority_id` int(11) NOT NULL,
  `turbomarc` longtext COLLATE utf8_unicode_ci,
  `dirty` tinyint(1) DEFAULT NULL,
  `indexed` tinyint(1) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`authority_id`),
  KEY `dirty_idx` (`dirty`),
  KEY `indexed` (`indexed`),
  KEY `deleted` (`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



CREATE TABLE `unimarc_codes` (
  `language` varchar(8) NOT NULL,
  `field_number` int(11) NOT NULL,
  `subfield_tag` char(1) NOT NULL,
  `pos` decimal(2,0) NOT NULL,
  `group_label` varchar(128) NOT NULL,
  `code_value` varchar(4) NOT NULL,
  `unimarc_type` char(1) NOT NULL,
  `field_length` char(3) NOT NULL,
  `label` varchar(128) NOT NULL,
  `help` text NOT NULL,
  PRIMARY KEY (`language`,`field_number`,`subfield_tag`,`pos`,`code_value`,`unimarc_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



CREATE TABLE `unimarc_labels` (
  `language` varchar(8) NOT NULL,
  `field_number` int(11) NOT NULL,
  `subfield_tag` char(1) NOT NULL,
  `unimarc_type` char(1) NOT NULL,
  `label` varchar(128) NOT NULL,
  `note` text NOT NULL,
  `maxlength` int(11) DEFAULT NULL,
  `mandatory` tinyint(1) DEFAULT NULL,
  `multiple` tinyint(1) DEFAULT NULL,
  `cdf` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`language`,`field_number`,`subfield_tag`,`unimarc_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

