INSERT INTO `l_librarian_profile` (`profile_id`, `librarian_id`, `sort_order`) VALUES
(1, 1, 1),
(4, 1, 3),
(8, 1, 1);
