<?php
/**
 * ClavisBase class file
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version $Id$
 */

/**
 * ClavisBase Class
 *
 * Contains some core functions for manipulating data
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2008 ePortal Technologies
 * @copyright Copyright &copy; 2009 Comperio srl
 * @version 2.7-dev
 * @package Core
 * @since 2.5.2
 */
class ClavisBase
{
	public static function getBasePath()
	{
		return __DIR__;
	}

	/**
	 * @return string the version of Clavis
	 */
	public static function getVersion()
	{
		return '2.7.2';
	}

	public static function getCodename() {
		return 'Canary';
	}

	public static function getDBString()
	{
		$conf = Propel::getConfiguration();
		$info = array();
		list($dbtype,$connparams) = explode(':',$conf['datasources']['clavis']['connection']['dsn'],2);
		foreach (explode(';',$connparams) as $token) {
			if (strpos($token, '=') === false) continue;
			list($key,$value) = explode('=', $token, 2);
			$info[$key] = $value;
		}
		return @$info['dbname'].'@'.@$info['host'].':'.@$info['port'];
	}

	protected static function getRevisionFromVCS() {
		$basePath = self::getBasePath();
		if (file_exists($basePath.'/.git')) {
			return exec("git describe --always");
		}
	}

	public static function getRevision() {
		$app = Prado::getApplication();
		if ($app instanceof TApplication) {
			/** @var $cachemod TCache */
			$cachemod = $app->getModule('cache');
			$rev = $cachemod->get('ClavisRevision');
			if (!$rev) {
				$rev = self::getRevisionFromVCS();
				$cachemod->add('ClavisRevision',$rev);
			}
			return $rev;
		}
		return self::getRevisionFromVCS();
	}

	public static function getRevisionLog() {
		$basePath = self::getBasePath();
		if (file_exists($basePath.'/.svn')) {
			$currentRev = intval(self::getRevision());
			$startRev = max(0,$currentRev-500);
			$svn = exec('which svn');
			if (!file_exists($svn))
				return "'svn' not found, check your Subversion install.";
			$out = exec("2>&1 {$svn} log --stop-on-copy -r {$startRev}:{$currentRev}",$output,$retval);
			$log = array();
			$currentRev = '';
			foreach ($output as $row) {
				if ('------------------------------------------------------------------------' == $row) {
					array_unshift($log,$currentRev);
					$currentRev = '';
				}
				$currentRev .= "\n{$row}";
			}
			return $log;
		} else if (file_exists($basePath.'/.git')) {
			exec("git log --pretty=format:'------------------------------------------------------------------------%n%h | %an <%ae> | %ai | %N%n%n%s%n' --abbrev-commit --since=2.months",
				$output);
			return $output;
		}
	}

	public static function sortTableArray(Array &$array, $key = 'fnum', $dir = SORT_ASC) {
		$sortcol = array();
		foreach ($array as $k => $v)
			$sortcol[$k]  = $v[$key];
		return array_multisort($sortcol, $dir, $array);
	}

	public static function normalizeStdNum($number) {
		return preg_replace("/\s+/","",strtr(trim($number),"-"," "));
	}

	public static function IsbnToEan13($isbn)
	{
		$isbn = self::normalizeStdNum($isbn);
		if (strlen($isbn)!=10)
			return $isbn;
		$code = '978'.substr($isbn,0,9);
		try {
			$code .= self::calculateChecksum($code);
		} catch (Exception $e) {
			return null;
		}
		return $code;
	}

	public static function Ean13ToIsbn($ean) {
		$ean = self::normalizeStdNum($ean);
		if (strlen($ean)==10)
			return $ean;
		if (strlen($ean)==8)	// it's a ISSN
			return $ean;
		$code = substr($ean,3,9);
		try {
			$code .= self::calculateIsbnChecksum($code);
		} catch (Exception $e) {
			return null;
		}
		return $code;
	}

	private static function calculateChecksum($code) {
		if ($code == null || strlen($code) != 12)
			throw new Exception("Code length should be 12, i.e. excluding the checksum digit\n");
		$sum = 0;
		for ($i = 0; $i < 12; $i++) {
			$v = $code[$i];
			if (is_numeric($v)) {
				$sum += ($i % 2 == 0 ? $v : $v * 3);
			} else {
				throw new Exception("Checksum non numerico\n");
			}
		}
		$check = 10 - ($sum % 10);
		return $check % 10;
	}
	
	public static function checkEanValid($ean = '')
	{
		$returnFlag = false;
		
		if (strlen($ean) == 13)
		{
			$checksumChar = substr($ean, -1);	// last char
			$eanBody = substr($ean, 0, -1);		// all but last char

			try
			{
				if ((int) self::calculateChecksum($eanBody) === (int) $checksumChar)
					$returnFlag = true;
			}
			catch (Exception $e)
			{
				$e = $e;
				//throw($e);
				//Prado::log('Exception in ClavisBase::checkEanValid(): '. Prado::varDump($e));			
			}
		}
		
		return $returnFlag;
	}

	private static function calculateIsbnChecksum($code) {
		if ($code == null || strlen($code) != 9)
			throw new Exception("Code length should be 9, i.e. excluding the checksum digit\n");
		$sum = 0;
		for ($i=0; $i<9; $i++) {
			$v = $code[$i];
			if (is_numeric($v)) {
				$sum += ($v * (10-$i));
			} else {
				throw new Exception("Checksum non numerico\n");
			}
		}
		$check = 11 - ($sum % 11);
		return ($check == 10)?'X':$check;
	}

	/* ISBN Hyphenation Conventions
	 * Code found at http://usin.org/software/servers/ISBN-ISSN.phps
	 * Works for ISBN/EAN only, ISSN to implement.
	 */
	private static $country_group_partition = array('0', '80', '950', '9960', '99900');

	//  This map specifies the following ranges for country/group prefixes:
	//  0-7, 80-94, 950-995, 9960-9989, 99900-99999.  An ISBN beginning with
	//  0 through 7 is thus hyphenated after the first character, while an
	//  ISBN beginning with 950 through 995 is hyphenated after the third.

	private static function prefix_length_from_map ($s, $map) {
		for ($i = 1; $i < sizeof($map); $i++) {
			if (strcmp($s, $map[$i]) < 0)
				return strlen($map[$i-1]);
		}
		return strlen($map[$i-1]);
	}

	private static function country_group_code ($isbn_proto) {
		$cglen = self::prefix_length_from_map($isbn_proto, self::$country_group_partition);
		return substr($isbn_proto, 0, $cglen);
	}

	private static $country_group_map =
		array(
			0 => array(array('00',200,7000,85000,900000,9500000),
					'English group 0:AU:CA:GI:IE:NZ:PR:ZA:SZ:GB:US:ZW'),
			1 => array(array('00000000',55000,869800,9999900),
					'English group 1:AU:CA:GI:IE:NZ:PR:ZA:SZ:GB:US:ZW'),
			2 => array(array('00',200,40000000,500,7000,84000,900000,9500000),
					'French group:FR:BE:CA:LU:CH'),
			3 => array(array('00',200,7000,85000,900000,9500000),
					'German group:AT:DE:CH'),
			4 => array(array('00',200,7000,85000,900000,9500000), 'JP'),
			5 => array(array('00',200,7000,85000,900000,9500000),
					'Former USSR group:RU:AM:AZ:BY:EE:GE:KZ:KG:LV:LT:MD:TJ:TM:UA:UZ'),
			7 => array(array('00',100,5000,80000,900000), 'CN'),
			80 => array(array('00',200,7000,85000,900000), 'Czech/Slovak:CZ:SK'),
			81 => array(array('00',200,7000,85000,900000), 'IN'),
			82 => array(array('00',200,7000,90000,990000), 'NO'),
			83 => array(array('00',200,7000,85000,900000), 'PL'),
			84 => array(array('00',200,7000,85000,900000,95000,9700), 'ES'),
			85 => array(array('00',200,7000,85000,900000), 'BR'),
			86 => array(array('00',300,7000,80000,900000), 'Balkans:YU:BA:HR:MK:SI'),
			87 => array(array('00',400,7000,85000,970000), 'DK'),
			88 => array(array('00',200,7000,85000,900000), 'Italian group:IT:CH'),
			89 => array(array('00',300,7000,85000,950000), 'Korean group:KP:KR'),
			90 => array(array('00',200,5000,70000,800000,9000000), 'Dutch group:NL:BE'),
			91 => array(array('0',20,500,6500000,7000,8000000,85000,9500000,970000), 'SE'),
			92 => array(array('0',60,800,9000), 'INT'), // International organizations
			93 => array(array('0000000'), 'IN'),
			950 => array(array('00',500,9000,99000), 'AR'),
			951 => array(array('0',20,550,8900,95000), 'FI'),
			952 => array(array('00',200,5000,89,9500,99000), 'FI'),
			953 => array(array('0',10,150,6000,96000), 'HR'),
			954 => array(array('00',400,8000,90000), 'BG'),
			955 => array(array('0',20,550,800000,9000,95000), 'LK'),
			956 => array(array('00',200,7000), 'CL'),
			957 => array(array('00',440,8500,97000), 'TW'),
			958 => array(array('0',600,9000,95000), 'CO'),
			959 => array(array('00',200,7000), 'CU'),
			960 => array(array('00',200,7000,85000), 'GR'),
			961 => array(array('00',200,6000,90000), 'SI'),
			962 => array(array('00',200,7000,85000), 'HK'),
			963 => array(array('00',200,7000,85000), 'HU'),
			964 => array(array('00',300,5500,90000), 'IR'),
			965 => array(array('00',200,7000,90000), 'IL'),
			966 => array(array('00',500,7000,90000), 'UA'),
			967 => array(array('0',60,900,9900,99900), 'MY'),
			968 => array(array('000000',10,400,500000,6000,800,900000), 'MX'),
			969 => array(array('0',20,400,8000), 'PK'),
			970 => array(array('00',600,9000,91000), 'MX'),
			971 => array(array('00',500,8500,91000), 'PH'),
			972 => array(array('0',20,550,8000,95000), 'PT'),
			973 => array(array('0',20,550,9000,95000), 'RO'),
			974 => array(array('00',200,7000,85000,900000), 'TH'),
			975 => array(array('00',300,6000,92000,980000), 'TR'),
			976 => array(array('0',40,600,8000,95000),
					'Caribbean Community:AG:BS:BB:BZ:KY:DM:GD:GY:JM:MS:KN:LC:VC:TT:VG'),
			977 => array(array('00',200,5000,70000), 'EG'),
			978 => array(array('000',2000,30000), 'NG'),
			979 => array(array('0',20,300000,400,700000,8000,95000), 'ID'),
			980 => array(array('00',200,6000), 'VE'),
			981 => array(array('00',200,3000), 'SG'),
			982 => array(array('00',100,500000),
					'South Pacific:CK:FJ:KI:MH:NR:NU:SB:TK:TO:TV:VU:WS'),
			983 => array(array('000',2000,300000,50,800,9000,99000), 'MY'),
			984 => array(array('00',400,8000,90000), 'BD'),
			985 => array(array('00',400,6000,90000), 'BY'),
			986 => array(array('000000'), 'TW'),
			987 => array(array('00',500,9000,99000), 'AR'),
			9952 => array(array('00000'), 'AZ'),
			9953 => array(array('0',20,9000), 'LB'),
			9954 => array(array('00',8000), 'MA'),
			9955 => array(array('00',400), 'LT'),
			9956 => array(array('00000'), 'CM'),
			9957 => array(array('00',8000), 'JO'),
			9958 => array(array('0',10,500,7000,9000), 'BA'),
			9959 => array(array('00'), 'Libya'),
			9960 => array(array('00',600,9000), 'SA'),
			9961 => array(array('0',50,800,9500), 'DZ'),
			9962 => array(array('00000'), 'PA'),
			9963 => array(array('0',30,550,7500), 'CY'),
			9964 => array(array('0',70,950), 'GH'),
			9965 => array(array('00',400,9000), 'KZ'),
			9966 => array(array('00',70000,800,9600), 'KE'),
			9967 => array(array('00000'), 'KG'),
			9968 => array(array('0',10,700,9700), 'CR'),
			9970 => array(array('00',400,9000), 'UG'),
			9971 => array(array('0',60,900,9900), 'SG'),
			9972 => array(array('0',40,600,9000), 'PE'),
			9973 => array(array('0',10,700,9700), 'TN'),
			9974 => array(array('0',30,550,7500), 'UY'),
			9975 => array(array('0',50,900,9500), 'MD'),
			9976 => array(array('0',60,900,99000,9990), 'TZ'),
			9977 => array(array('00',900,9900), 'CR'),
			9978 => array(array('00',950,9900), 'EC'),
			9979 => array(array('0',50,800,9000), 'IS'),
			9980 => array(array('0',40,900,9900), 'PG'),
			9981 => array(array('0',20,800,9500), 'MA'),
			9982 => array(array('00',40000,800,9900), 'ZM'),
			9983 => array(array('00',500,80,950,9900), 'GM'),
			9984 => array(array('00',500,9000), 'LV'),
			9985 => array(array('0',50,800,9000), 'EE'),
			9986 => array(array('00',400,9000), 'LT'),
			9987 => array(array('00',400,8800), 'TZ'),
			9988 => array(array('0',30,550,7500), 'GH'),
			9989 => array(array('0',30,600,9700), 'MK'),
			99901 => array(array('00'), 'BH'),
			99903 => array(array('0',20,900), 'MU'),
			99904 => array(array('0',60,900), 'AN'),
			99905 => array(array('0',60,900), 'BO'),
			99906 => array(array('0',60,900), 'KW'),
			99908 => array(array('0',10,900), 'MW'),
			99909 => array(array('0',40,950), 'MT'),
			99910 => array(array('0000'), 'SL'),
			99911 => array(array('00',600), 'LS'),
			99912 => array(array('0',60,900), 'BW'),
			99913 => array(array('0',30,600), 'AD'),
			99914 => array(array('0',50,900), 'SR'),
			99915 => array(array('0',50,800), 'FK'),
			99916 => array(array('0',30,700), 'NA'),
			99917 => array(array('0',30), 'BN'),
			99918 => array(array('0',40,900), 'FO'),
			99919 => array(array('0',40,900), 'BJ'),
			99920 => array(array('0',50,900), 'AD'),
			99921 => array(array('0',20,700), 'QA'),
			99922 => array(array('0',50), 'GT'),
			99923 => array(array('0',20,800), 'SV'),
			99924 => array(array('0',30), 'NI'),
			99925 => array(array('0',40,800), 'PY'),
			99926 => array(array('0000',600), 'HN'),
			99927 => array(array('0',30,600), 'AL'),
			99928 => array(array('0',50,800), 'GE'),
			99929 => array(array('0000'), 'MN'),
			99930 => array(array('0',50,800), 'AM'),
			99931 => array(array('0000'), 'SC'),
			99932 => array(array('0',10), 'MT'),
			99933 => array(array('00',300), 'NP'),
			99934 => array(array('0'), 'DO'),
			99935 => array(array('0000'), 'HT'),
			99936 => array(array('0000'), 'BT'),
			99937 => array(array('0',20), 'MO')
	);

	public static function hyphenateStdNum($num_proto)
	{
		$prefix = '';
		$num_proto = self::normalizeStdNum($num_proto);
		// is length is 8, it's an ISSN
		if (strlen($num_proto)==8)
			return substr($num_proto,0,4).'-'.substr($num_proto,4);

		if (strlen($num_proto)==13) {
			$prefix = substr($num_proto,0,3).'-';
			$num_proto = substr($num_proto, 3);
		}
		$cg = self::country_group_code($num_proto);
		$cglen = strlen($cg);
		$pubandbook = substr($num_proto, $cglen, 9-$cglen);
		$checkdigit = substr($num_proto,9,1);
		if (array_key_exists($cg,self::$country_group_map) && is_array(self::$country_group_map[$cg])) {
			$publen = self::prefix_length_from_map($pubandbook, self::$country_group_map[$cg][0]);
			if ($cglen + $publen == 9) {
				return "{$prefix}{$cg}-{$pubandbook}-{$checkdigit}";
			} else {
				$pubcode = substr($pubandbook, 0, $publen);
				$bookno = substr($pubandbook, $publen);
				return "{$prefix}{$cg}-{$pubcode}-{$bookno}-{$checkdigit}";
			}
		} else {
			return "{$prefix}{$cg}-{$pubandbook}-{$checkdigit}";
		}
	}

	public static final function BibtypeToItemmedia($bibtype) {
		$map = array(	'a01' => 'F',
						'a02' => 'F',
						'c01' => 'H',
						'e01' => 'D',
						'b01' => 'M',
						'b02' => 'M',
						'd01' => 'H',
						'f01' => 'D',
						'g01' => 'P',
						'g02' => 'R',
						'g03' => 'Q',
						'g04' => 'P',
						'g05' => 'M',
						'g06' => 'P',
						'g07' => 'Q',
						'g08' => 'E',
						'j01' => 'A',
						'j02' => 'A',
						'j03' => 'A',
						'j04' => 'A',
						'j05' => 'A',
						'j06' => 'A',
						'j07' => 'A',
						'i01' => 'A',
						'i02' => 'A',
						'i03' => 'A',
						'i04' => 'A',
						'i05' => 'A',
						'i06' => 'A',
						'i07' => 'A',
						'k01' => 'C',
						'k02' => 'C',
						'k03' => 'C',
						'k04' => 'C',
						'k05' => 'C',
						'k06' => 'C',
						'k07' => 'C',
						'k08' => 'C',
						'k09' => 'C',
						'k10' => 'C',
						'k11' => 'C',
						'l01' => 'N',
						'l02' => 'N',
						'r01' => 'I',
						'r02' => 'I',
						'r03' => 'I',
						'r04' => 'I',
						'r05' => 'I',
						'r06' => 'I',
						'r07' => 'I',
						'r08' => 'I',
						'r09' => 'I',
						'r10' => 'I',
						'r11' => 'I',
						'r12' => 'I',
						'r13' => 'I',
						'r14' => 'I',
						'r15' => 'I',
						'r16' => 'I',
						'r17' => 'I',
						'r18' => 'I',
						'r19' => 'I',
						'r20' => 'I',
						'r21' => 'I',
						'r22' => 'I',
						'r23' => 'I',
						'r24' => 'I',
						'r25' => 'I',
						'r26' => 'I',
						'r27' => 'I',
						'r28' => 'I',
						'r29' => 'I',
						'r30' => 'I',
						'r31' => 'I',
						'r32' => 'I',
						'r33' => 'I',
						'r34' => 'I',
						'm01' => 'G' );

		return (array_key_exists($bibtype,$map))
					? $map[$bibtype]
					: null;
	}

	public static final function MarcXML2TurboMarc($marcxml)
	{
		if (!$marcxml instanceof SimpleXMLElement)
			$marcxml = simplexml_load_string($marcxml);
		$tm = TurboMarc::createRecord();
		$tm->setLeader((string)$marcxml->leader);
		foreach($marcxml->controlfield as $cf) {
			$tmcf = $tm->addCDField($cf['tag'],(string)$cf);
		}
		foreach($marcxml->datafield as $df) {
			$tmdf = $tm->addField($df['tag'],$df['ind1'],$df['ind2']);
			foreach($df->subfield as $sf) {
				$tmsf = $tmdf->addSubField($sf['code'], (string)$sf);
			}
		}
		return $tm;
	}

	public static final function html2xmlEntities($str) {
		$xml = array('&#34;', '&#38;', '&#38;', '&#60;', '&#62;', '&#160;', '&#161;',
			'&#162;', '&#163;', '&#164;', '&#165;', '&#166;', '&#167;', '&#168;',
			'&#169;', '&#170;', '&#171;', '&#172;', '&#173;', '&#174;', '&#175;',
			'&#176;', '&#177;', '&#178;', '&#179;', '&#180;', '&#181;', '&#182;',
			'&#183;', '&#184;', '&#185;', '&#186;', '&#187;', '&#188;', '&#189;',
			'&#190;', '&#191;', '&#192;', '&#193;', '&#194;', '&#195;', '&#196;',
			'&#197;', '&#198;', '&#199;', '&#200;', '&#201;', '&#202;', '&#203;',
			'&#204;', '&#205;', '&#206;', '&#207;', '&#208;', '&#209;', '&#210;',
			'&#211;', '&#212;', '&#213;', '&#214;', '&#215;', '&#216;', '&#217;',
			'&#218;', '&#219;', '&#220;', '&#221;', '&#222;', '&#223;', '&#224;',
			'&#225;', '&#226;', '&#227;', '&#228;', '&#229;', '&#230;', '&#231;',
			'&#232;', '&#233;', '&#234;', '&#235;', '&#236;', '&#237;', '&#238;',
			'&#239;', '&#240;', '&#241;', '&#242;', '&#243;', '&#244;', '&#245;',
			'&#246;', '&#247;', '&#248;', '&#249;', '&#250;', '&#251;', '&#252;',
			'&#253;', '&#254;', '&#255;');
		$html = array('&quot;', '&amp;', '&amp;', '&lt;', '&gt;', '&nbsp;', '&iexcl;',
			'&cent;', '&pound;', '&curren;', '&yen;', '&brvbar;', '&sect;', '&uml;',
			'&copy;', '&ordf;', '&laquo;', '&not;', '&shy;', '&reg;', '&macr;',
			'&deg;', '&plusmn;', '&sup2;', '&sup3;', '&acute;', '&micro;', '&para;',
			'&middot;', '&cedil;', '&sup1;', '&ordm;', '&raquo;', '&frac14;', '&frac12;',
			'&frac34;', '&iquest;', '&Agrave;', '&Aacute;', '&Acirc;', '&Atilde;',
			'&Auml;', '&Aring;', '&AElig;', '&Ccedil;', '&Egrave;', '&Eacute;',
			'&Ecirc;', '&Euml;', '&Igrave;', '&Iacute;', '&Icirc;', '&Iuml;', '&ETH;',
			'&Ntilde;', '&Ograve;', '&Oacute;', '&Ocirc;', '&Otilde;', '&Ouml;',
			'&times;', '&Oslash;', '&Ugrave;', '&Uacute;', '&Ucirc;', '&Uuml;',
			'&Yacute;', '&THORN;', '&szlig;', '&agrave;', '&aacute;', '&acirc;',
			'&atilde;', '&auml;', '&aring;', '&aelig;', '&ccedil;', '&egrave;',
			'&eacute;', '&ecirc;', '&euml;', '&igrave;', '&iacute;', '&icirc;',
			'&iuml;', '&eth;', '&ntilde;', '&ograve;', '&oacute;', '&ocirc;',
			'&otilde;', '&ouml;', '&divide;', '&oslash;', '&ugrave;', '&uacute;',
			'&ucirc;', '&uuml;', '&yacute;', '&thorn;', '&yuml;');
		$str = str_replace($html, $xml, $str);
		$str = str_ireplace($html, $xml, $str);
		return $str;
	}

	/**
	 * Ensure string contains only XML-accepted chars.
	 *
	 * @param string $string
	 * @return string
	 */
	public static function sanitizeForXML($string)
	{
		// first, convert to XML entities
		$string = mb_convert_encoding($string,'UTF-8','UTF-8, ISO-8859-1, ISO-8859-15, auto');
		// then, ensure no crap chars are inside our string
		$accepted_xml_chars = '/[^\x{0009}\x{000a}\x{000d}\x{0020}-\x{D7FF}\x{E000}-\x{FFFD}]+/u';
		$real_ampersand = '/&([^#])/';
		$string = preg_replace(array($accepted_xml_chars,$real_ampersand), array('','&amp;$1'), $string);

		return $string;
	}

	/**
	 * Formats a XML string for displaying in HTML.
	 *
	 * @param string $xml
	 * @return string Formatted XML
	 */
	public static function formatXmlString($xml)
	{
		$padlength = 4;
		// add marker linefeeds to aid the pretty-tokeniser (adds a linefeed between all tag-end boundaries)
		$xml = preg_replace('/(>)(<)(\/*)/', "$1\n$2$3", $xml);

		// now indent the tags
		$token = strtok($xml, "\n");
		$result = ''; // holds formatted version as it is built
		$pad = 0; // initial indent
		$matches = array(); // returns from preg_matches()
		// scan each line and adjust indent based on opening/closing tags
		while ($token !== false) {
			// test for the various tag states
			// 1. open and closing tags on same line - no change
			if (preg_match('/.+<\/\w[^>]*>$/', $token, $matches)) {
				$indent = 0;
			}
			// 2. closing tag - outdent now
			else if (preg_match('/^<\/\w/', $token, $matches)) {
				$pad--;
				$indent = 0;
			}
			// 3. opening tag - don't pad this one, only subsequent tags
			else if (preg_match('/^<\w[^>]*[^\/]>.*$/', $token, $matches)) {
				$indent = 1;
			}
			// 4. no indentation needed
			else {
				$indent = 0;
			}

			// pad the line with the required number of leading spaces
			$line = str_pad($token, strlen($token) + $pad * $padlength, ' ', STR_PAD_LEFT);
			$result .= $line . "\n"; // add to the cumulative result, with linefeed
			$token = strtok("\n"); // get the next token
			$pad += $indent; // update the pad size for subsequent lines
		}
		return $result;
	}

	public static function strcmpAZ09($a,$b)
	{
		$aint = intval($a); $bint = intval($b);
		return ($aint == $bint) ? strcmp($a, $b) : strcmp($aint,$bint);
	}

	public static function mime_content_type($filename) {
		if (function_exists('finfo_open')) {
			$finfo = finfo_open(FILEINFO_MIME_TYPE);
			return finfo_file($finfo, $filename);
		} else if (function_exists('mime_content_type')) {
			return mime_content_type($filename);
		} else {
			return 'text/txt';
		}
	}

	/**
	 * @param int $forcedwidth
	 * @param int $forcedheight
	 * @param string $sourcefile
	 * @param string $destfile
	 * @param int $imgcomp
	 * @return boolean
	 */
	public static function resampleImageJpg($forcedwidth, $forcedheight, $sourcefile, $destfile, $imgcomp)
	{
		if (file_exists($sourcefile))
		{
			list($width, $height, $type, $attr)= getimagesize($sourcefile);
			if (!$width || !$height)
				return false;	// file is not a valid image

			if (($width - $forcedwidth) >= ($height - $forcedheight))
			{
				$dstwidth = $forcedwidth;
				$dstheight = $forcedwidth / $width * $height;
			} else {
				$dstheight = $forcedheight;
				$dstwidth = $forcedheight / $height * $width;
			}

			$img_src = @imagecreatefromjpeg($sourcefile);
			if ($img_src !== false) {
				$img_dst = imagecreatetruecolor($dstwidth, $dstheight);
				imagecopyresampled($img_dst, $img_src, 0, 0, 0, 0, $dstwidth, $dstheight, $width, $height);
				imagejpeg($img_dst, $destfile, 100 - $imgcomp);
				imagedestroy($img_dst);
				return true;
			}
		}
		return false;
	}

	/**
	 * For the number for a certain pattern. The valid patterns are
	 * 'c', 'd', 'e', 'p' or a custom pattern, such as "#.000" for
	 * 3 decimal places.
	 * Requires Prado.
	 * @param mixed the number to format.
	 * @param string the format pattern: 'c' for currency, 'd' for decimal,
	 * 'e' for scientific, 'p' for percentage or a custom pattern.
	 * E.g. "#.000" will format the number to 3 decimal places.
	 * @param string 3-letter ISO 4217 code. For example, the code
	 * "USD" represents the US Dollar and "EUR" represents the Euro currency.
	 * @param string Encoding charset.
	 * @return string formatted number string
	 */
	public static function numberFormat(	$number, 
											$pattern='d', 
											$charset='UTF-8', 
											$applyMyCultureFlag = true)
	{
		Prado::using('System.I18N.core.NumberFormat');
		
		$currency = Prado::getApplication()->getParameters()->itemAt('SystemCurrency');
		if (TPropertyValue::ensureString($currency) == "")
			$currency = 'EUR';	// fallback
		
		if ($applyMyCultureFlag)
		{
			$finalCulture = Prado::getApplication()->getGlobalization()->getCulture();
		}
		else
		{
			$number = self::normalizeNumber($number);
			$finalCulture = CultureInfo::getInvariantCulture()->getName();	// default en culture, for writing on DB
		}

		$formatter = new NumberFormat($finalCulture);
		$formattedValue = $formatter->format(	$number,
												$pattern,
												$currency,
												"{$charset}//TRANSLIT" );
		
		return $formattedValue;
	}

	public static function normalizeNumber($number, $culture = null)
	{
		$separatorData = self::getSeparatorData($culture);
		
		if (array_key_exists('group', $separatorData))
			$number = str_replace($separatorData['group'], "", $number);

		if (array_key_exists('decimal', $separatorData))
		{	
			if (array_key_exists('invariantdecimal', $separatorData))
				$invDecimal = $separatorData['invariantdecimal'];
			else
				$invDecimal = ".";
			
			$number = str_replace($separatorData['decimal'], $invDecimal, $number);
		}

		return $number;
	}
	
	public static function getSeparatorData($culture = null)
	{
		Prado::using('System.I18N.core.NumberFormat');
		
		if (is_null($culture))
			$culture = Prado::getApplication()->getGlobalization()->getCulture();
		
		$numberFormatInfo = CultureInfo::getInstance($culture)->getNumberFormat();
		$decimalSeparator = $numberFormatInfo->getDecimalSeparator();
		$groupSeparator = $numberFormatInfo->getGroupSeparator();
		
		$invariantCulture = CultureInfo::getInvariantCulture()->getName();
		$invariantNumberFormatInfo = CultureInfo::getInstance($invariantCulture)->getNumberFormat();
		
		$invariantDecimalSeparator = $invariantNumberFormatInfo->getDecimalSeparator();
		$invariantGroupSeparator = $invariantNumberFormatInfo->getGroupSeparator();
		
		return array(	'decimal' => $decimalSeparator,
						'group' => $groupSeparator,
						'invariantdecimal' => $invariantDecimalSeparator,
						'invariantgroup' => $invariantGroupSeparator );
	}

	public static function getCurrencySymbol($culture = null)
	{
		Prado::using('System.I18N.core.NumberFormat');
		
		if (is_null($culture))
			$culture = Prado::getApplication()->getGlobalization()->getCulture();

		$numberFormatInfo = CultureInfo::getInstance($culture)->getNumberFormat();

		return $numberFormatInfo->getCurrencySymbol(Prado::getApplication()->getParameters()->itemAt('SystemCurrency'));		
	}

	/**
	 * Format a date according to the pattern.
	 * Requires Prado.
	 * @param mixed $time the time as integer, string in strtotime format or DateTime instance.
	 * @param string $pattern date pattern, up to two tokens (one for date, one for time)
	 * among 'fulldate', 'longdate', 'mediumdate', 'shortdate' for date,
	 * 'fulltime', 'longtime', 'mediumtime', 'shorttime' for time.
	 * See http://www.pradosoft.com/demos/quickstart/?page=Advanced.I18N for full patterns.
	 * @param string $charset
	 * @param null $culture
	 * @return string formatted date time.
	 */
	public static function dateFormat($time, $pattern='shortdate', $charset='UTF-8', $culture=null)
	{
		// if time is 0 do not return it formatted, return empty string instead.
		if (!$time)	return '';

		Prado::using('System.I18N.core.DateFormat');
		// get them from TDateFormat
		$_patternPresets = array(
			'fulldate'=>'P','full'=>'P',
			'longdate'=>'D','long'=>'d',
			'mediumdate'=>'p','medium'=>'p',
			'shortdate'=>'d','short'=>'d',
			'fulltime'=>'Q', 'longtime'=>'T',
			'mediumtime'=>'q', 'shorttime'=>'t');

		$formatter = (null !== $culture)
			? new DateFormat($culture)
			: new DateFormat(Prado::getApplication()->getGlobalization()->getCulture());

		//try the subpattern of "date time" presets
		$subpatterns = explode(' ',$pattern,2);
		$datetime = array();
		if (count($subpatterns)==2)
		{
			$datetime[] = array_key_exists(strtolower($subpatterns[0]),$_patternPresets)
				? $_patternPresets[$subpatterns[0]] : null;
			$datetime[] = array_key_exists(strtolower($subpatterns[1]),$_patternPresets)
				? $_patternPresets[$subpatterns[1]] : null;
		}
		$dfpattern = (count($datetime) == 2 && strlen($datetime[0]) == 1 && strlen($datetime[1]) == 1)
			? $datetime
			: (array_key_exists(strtolower($pattern),$_patternPresets)
				? $_patternPresets[$pattern] : null);
		if (null === $dfpattern)
			$dfpattern = $pattern;
		if (!is_array($dfpattern) && strlen($dfpattern) == 0)
			$dfpattern = null;

		if ($time instanceof DateTime)
			$time = $time->format('U');
		$formattedValue = $formatter->format($time,$dfpattern,"{$charset}//TRANSLIT");
		return $formattedValue;
	}

	/**
	 * Convert human readable format to bytes
	 *
	 * @param string $size Size to convert in bytes
	 * @return string
	 */
	public static function sizeToBytes($size)
	{
		$l = substr($size, -1);
		$ret = substr($size, 0, -1);
		switch (strtoupper($l)) {
			case 'P':
				$ret *= 1024;
			case 'T':
				$ret *= 1024;
			case 'G':
				$ret *= 1024;
			case 'M':
				$ret *= 1024;
			case 'K':
				$ret *= 1024;
				break;
		}
		return $ret;
	}

	/**
	 * Convert bytes to human readable format
	 *
	 * @param integer $bytes Size in bytes to convert
	 * @param integer $precision The number of decimals to use
	 * @return string
	 */
	public static function bytesToSize($bytes, $precision = 2)
	{
		$kilobyte = 1024;
		$megabyte = $kilobyte * 1024;
		$gigabyte = $megabyte * 1024;
		$terabyte = $gigabyte * 1024;
		$petabyte = $terabyte * 1024;
		if (($bytes >= 0) && ($bytes < $kilobyte)) {
			return $bytes;
		} elseif (($bytes >= $kilobyte) && ($bytes < $megabyte)) {
			return round($bytes / $kilobyte, $precision) . 'K';
		} elseif (($bytes >= $megabyte) && ($bytes < $gigabyte)) {
			return round($bytes / $megabyte, $precision) . 'M';
		} elseif (($bytes >= $gigabyte) && ($bytes < $terabyte)) {
			return round($bytes / $gigabyte, $precision) . 'G';
		} elseif ($bytes >= $terabyte) {
			return round($bytes / $terabyte, $precision) . 'T';
		} elseif ($bytes >= $petabyte) {
			return round($bytes / $petabyte, $precision) . 'P';
		} else {
			return $bytes;
		}
	}

	/**
	 * Returns the max upload size in MB.
	 *
	 * @param boolean $asSize If true returns human readable format, else returns bytes.
	 * @return string
	 */
	public static function getMaxUploadSize($asSize = true) {
		$max_upload = self::sizeToBytes(ini_get('upload_max_filesize'));
		$max_post = self::sizeToBytes(ini_get('post_max_size'));
		$memory_limit = self::sizeToBytes(ini_get('memory_limit'));
		$size = min($max_upload, $max_post, $memory_limit);
		if ($asSize)
			$size = self::bytesToSize($size);
		return $size;
	}

	/**
	 * Converts a DateInterval object to seconds (absolute)
	 */
	public static function DateInterval2Seconds(DateInterval $dt)
	{
		$total_seconds =
			intval($dt->y) * 31556926 +
			intval($dt->m) * 2592000 +
			intval($dt->d) * 86400 +
			intval($dt->h) * 3600 +
			intval($dt->i) * 60 +
			intval($dt->s);
		return (int)$total_seconds;
	}

	private static function isDateInterval($object)
	{
		if (!is_a($object, 'DateInterval')) {
			throw new Exception('Parameter dateInterval type has to be a Dateinterval.');
		}
	}
}