<?php
$MAINTENANCE = 'maintenance';
$PROPEL_INITED = false;
require 'vendor/autoload.php';
include('bootstrap.php');
include('propel_init.php');

require_once(dirname(__FILE__).'/ClavisBase.php');
require_once('protected/Data/ObjectTriggersBase.php');
require_once('protected/Data/ItemStatusBase.php');
if (file_exists($SITEPATH.'/site-conf.php'))
	include($SITEPATH.'/site-conf.php');

/**
 * Defines Clavis class if not defined.
 */
if(!class_exists('Clavis',false))
{
	/**
	 * Clavis class.
	 *
	 * @author Ciro Mattia Gonano <ciro@comperio.it>
	 * @version $Id$
	 * @package Core
	 * @since 2.5.2
	 */
	class Clavis extends ClavisBase
	{
	}
}
/**
 * Defines ItemStatus class if not defined.
 */
if(!class_exists('ItemStatus',false))
{
	/**
	 * ItemStatus class.
	 *
	 * @author Ciro Mattia Gonano <ciro@comperio.it>
	 * @version $Id$
	 * @package Core
	 * @since 2.6.5
	 */
	class ItemStatus extends ItemStatusBase
	{
	}
}
/**
 * Defines ObjectTriggers class if not defined.
 */
if(!class_exists('ObjectTriggers',false))
{
	/**
	 * ObjectTriggers class.
	 *
	 * @author Ciro Mattia Gonano <ciro@comperio.it>
	 * @version $Id$
	 * @package Core
	 * @since 2.5.2
	 */
	class ObjectTriggers extends ObjectTriggersBase
	{
	}
}

if ((@include 'pradolite.php') === false)
	include 'prado.php';

$application = new TApplication();
$application->setConfigurationFile($SITEPATH.'/clavis-application.xml');
$application->setRuntimePath($SITEPATH.'/runtime/');

// comment
$application->run();
