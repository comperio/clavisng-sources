<?php

/* The present file will be loaded prior to scanning for directories.
 * There you can define an associative array named $sites, which maps domains
 * to directories, in the form of:
 *
 * $sites = array(
 *   'The url to alias' => 'A directory within the sites directory'
 * );
 * 
 * Example:
 * 1) create a clavistest directory into sites direcory and change where needed
 * 2) create a symlink into web server root to clavis dir like ln -s clavisng clavistest
 * 3) add array entries like 'localhost.~user.clavistest'=>'clavistest','yourip.~user.clavistest'=>'clavistest'
 */

$sites = array();

