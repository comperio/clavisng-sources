<?php
$basePath = dirname(__FILE__);
$confdir = __DIR__.'/sites';
// The following block identifies the correct configuration directory upon request URL.
$sites = array();
if (file_exists($confdir.'/sites.php'))
	include($confdir.'/sites.php');

$testConfDir = true;

$sapi_type = php_sapi_name();
if (substr($sapi_type, 0, 3) == 'cli')
	die('Please use "bootstrap_cli.php" for CLI scripts.');

$revSrv = implode('.',array_reverse(explode(':',rtrim($_SERVER['HTTP_HOST'],'.'))));
// for performance, if site is listed in sites array, take it as conf
if (array_key_exists($revSrv,$sites) && file_exists($confdir.'/'.$sites[$revSrv])) {
	// warning: NO CHECK ON clavis-application.xml EXISTENCE!!!
	$SITEPATH = $confdir.'/'.$sites[$revSrv];
	$testConfDir = false;
} else {
	$server = explode('.',$revSrv);
}

if ($testConfDir) {
	$uri = explode('/', $_SERVER['SCRIPT_NAME'] ? $_SERVER['SCRIPT_NAME'] : $_SERVER['SCRIPT_FILENAME']);
	for ($i = count($uri) - 1; $i > 0; $i--) {
		for ($j = count($server); $j > 0; $j--) {
			$dir = implode('.', array_slice($server, -$j)) . implode('.', array_slice($uri, 0, $i));
			if (isset($sites[$dir]) && file_exists($confdir.'/'.$sites[$dir]))
				$dir = $sites[$dir];
			if (file_exists($confdir.'/'.$dir.'/clavis-application.xml')) {
				$SITEPATH = $confdir.'/'.$dir;
				break 2;
			}
		}
	}
}

if (!isset($SITEPATH))
	$SITEPATH = $confdir.'/default';
// end configuration directory identification.

// prefer pradolite, use prado if it's missing (trunk prado?)
//$frameworkPath = $basePath.'/vendor/prado/prado/framework/pradolite.php';
//if (!file_exists($frameworkPath))
//	$frameworkPath = $basePath.'/vendor/prado/prado/framework/prado.php';
