<?php
if (!isset($PROPEL_INITED) || !$PROPEL_INITED) {
	$my_dirname = dirname(__FILE__);
	set_include_path($my_dirname.'/protected/Data/propel/classes/'.PATH_SEPARATOR.get_include_path());
	require_once('Propel.php');
	if (isset($SITEPATH))
		Propel::init($SITEPATH.'/propel-conf.php');
	else
		Propel::init('protected/Data/propel/conf/clavis-conf.php');
	require_once($my_dirname.'/protected/Data/propel/SerializableCriteria.php');
	$PROPEL_INITED = true;

//    Propel::getConnection()->useDebug(true);
//    $config = Propel::getConfiguration(PropelConfiguration::TYPE_OBJECT);
//    $config->setParameter('debugpdo.logging.details.time.enabled', true);
//    $config->setParameter('debugpdo.logging.details.mem.enabled', true);

    //Questo solo in casi speciali
    //$config->setParameter('debugpdo.logging.details.method.enabled',true);
        
}
