<?php
/**
 * ILoanManager interface file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 ePortal Technologies
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Interfaces
 */

/**
 * ILoanManager Interface
 *
 * interface which declares methods for supporting loans
 * It'll be implemented in a specific class, depending on algorhythms linked to the customer's choice
 *
 * @author Max Pigozzi <mpigozzi@e-portaltech.it>
 * @version 2.7
 * @package Interfaces
 * @since 2.5.0
 */
interface ILoanManager {

	/**
	 * It verifies if a Patron is enabled for doing a loan
	 *
	 * @param Patron $patron
	 * @param Item $item
     * @param bool $reserveMode If in reserve mode check on extra quantity
	 *
	 * @return boolean
	 *
	 */
	public static function IsPatronAllowedToLoan($patron, $itemId = null, $reserveMode = false);

	public static function isExternalLibraryAllowedToLoan($libraryId);

	/**
	 * 
	 */
	public static function IsRatingAllowed($manifestation = null, $patron = null);
	
	/**
	 * It verifies if a Patron is enabled for doing a loan
	 *
	 * @param Item $item
	 * @param Patron $patron
	 *
	 * @return boolean
	 *
	 */
	public static function IsLoanAllowed($item, $patron = null, $libraryId = null);

	/**
	 * It verifies if an item is available for a immediate loan
	 *
	 * @param Item $item
	 * @param Patron $patron
	 *
	 * @return boolean
	 *
	 */
	public function IsItemAvailable($item, $localLibraryId = null);

	public function IsItemAvailableClass($item, $localLibraryId = null);

	/**
	 * It verifies if a renew of a loan, of an item, is in state of suspended (negative)
	 *
	 * @param Item $item
	 * @return boolean 
	 */
	public function isRenewSuspended($item);

	/**
	 * It verifies if the loan of an item is renewable
	 *
	 * @param Item $item
	 * @param ClavisLibrarian $clavisLibrarian
	 * @param Patron $patron
	 *
	 * @return int (enumerated) :
	 *      self::OK  : true
	 * 		self::ERROR : generic error
	 *
	 * 	 	self::RENW_NOTAVAIL : renewal not available
	 *		self::RENW_REACHEDMAXREN : reached max renewal count
	 *
	 */
	public function IsLoanRenewable($item, $clavisLibrarian = null, $patron = null);

	/**
	 * It verifies if the loan of an item is solicitable
	 *
	 * @param Item or Loan $object
	 * @param ClavisLibrarian $clavisLibrarian
	 * @param Patron or Library $destination
	 *
	 * @return int (enumerated) :
	 *      self::OK  : true
	 * 		self::ERROR : generic error
	 *
	 * 	 	self::SLCT_NOTAVAIL : renewal not available
	 *
	 *
	 */
	public function IsLoanSolicitable($object, $clavisLibrarian = null, $destination = null);

	/**
	 * Loan of an item for extra system
	 *
	 * @param int $itemId
	 * @param int $toLibraryId
	 * @param *nix timestamp : $dueDate
	 * @param int $librarianId 
	 * 
	 * @return int
	 *
	 */
	public function doLoanItemExtra($itemId, $toLibraryId, $dueDate = null, $librarianId = null);

	/**
	 * 
	 */
	public function throwCalculateDueDateError();

	/**
	 * Loan of an item
	 *
	 * @param Item $item
	 * @param Patron|Library $loanObject : a patron or an external library (in the case of extra system loan)
	 * @param ClavisLibrarian $clavisLibrarian
	 * @param Library $deliveryLibrary
	 * @param ItemRequest $item_request
	 * @param *nix timestamp : $dueDate
	 *
	 * @return boolean
	 *
	 */
	public function DoLoanItem($item, 
								$loanObject, 
								$clavisLibrarian = null, 
			
								$deliveryLibrary, 
								$item_request = null, 
								$dueDate = null);

	/**
	 * Loan of an item, in a stupid way (made by the iLib24 (automated loan spot).
	 * We only must check if the item is not in actual loan
	 *
	 * @param Item $item
	 * @param Patron $patron
	 * @param ClavisLibrarian $clavisLibrarian
	 * @param boolean $forceInLoanOnly : if true, loan is forbidden only if the item is in some patron's hands
	 * @param *nix timestamp : $dueDate
	 *
	 * @return boolean
	 *
	 */
	public function DoForcedLoanItem($item, $patron, $clavisLibrarian, $forceInLoanOnly = false, $dueDate = null);

	/**
	 * Return of an item
	 *
	 * @param Item $item
	 * @param Patron $patron
	 * @param ClavisLibrarian $clavisLibrarian
	 *
	 * @return int (enumerated) :
	 * 		   self::OK : true
	 *         self::ERROR : generic error
	 *
	 * 		   self::RETN_PATRONREQUEST  : it exists (at least) a reservation for the item returned
	 *
	 */
	public function DoReturnItem($item, $patron, $clavisLibrarian);



	/**
	 * Loan of a manifestation
	 *
	 * @param Manifestation $manifestation
	 * @param Patron $patron
	 * @param ClavisLibrarian $clavisLibrarian
	 * @param Library $deliveryLibrary
	 * @param array of Item $excluded_items
	 *
	 * @return boolean
	 *
	 */
	public function DoLoanManifestation($manifestation, $patron, $clavisLibrarian, $deliveryLibrary, $excluded_items = null);



	/**
	 * Do a renew action
	 *
	 * @param Item $item
	 * @param Patron $patron
	 * @param ClavisLibrarian $clavisLibrarian
	 * @param string $description
	 * @param integer $renew_duration
	 * @param integer $dueDate
	 *
	 * @return boolean
	 *
	 */
	public function DoRenewLoan($item, $patron, $clavisLibrarian, $description, $renew_duration = null, $dueDate = null);

	/**
	 * Abort a loan
	 *
	 * @param Item $item
	 * @param Patron|Library $destinationObject
	 * @param ClavisLibrarian $clavisLibrarian
	 * @param enum $type
	 * @param string $description
	 * @param boolean $force
	 *
	 * @return boolean
	 */
	public function DoAbortLoan(	$item, 
									$destinationObject = null, 
									$clavisLibrarian, 
									$type, 
									$description, 
			
									$force = null);

	/* AUX METHODS */

	public function CalculateWaitingDelta($ownerLibraryId = null, $librarianId = null);

	/**
	 * Given the days, it calculates the duration in *nix standard
	 *
	 * @param Item $item
	 * @param Patron $patron
	 *
	 * @return *nix timestamp : absolute due date
	 *
	 */
	public function CalculateDueDate($item, $patron = null);

	/**
	 * Given the days from Clavis_param, it calculates the duration in *nix standard
	 * for renewing the due date
	 *
	 * @param Item $item
	 * @param Patron $patron
	 * @param integer $renew_duration
	 * @param integer $dueDate
	 *
	 * @return *nix timestamp : absolute renew date
	 *
	 */
	public function CalculateRenewDate($item, $patron = null, $renew_duration = null, $dueDate = null);

	/**
	 * Given the days from Clavis_param, it calculates the expirein *nix standard
	 * for expiring the item_request
	 *
	 * @param ItemRequest $item_request
	 * @param Item $item
	 * @param Patron $patron
	 *
	 *
	 * @return *nix timestamp : absolute expire date
	 *
	 */
	public function CalculateExpireDate($item_request, $item = null, $patron = null);


	/**
	 * Given a manifestation, it applies a procedure to find one (or more...) item(s)
	 * from the libraries which could satisfy the request
	 *
	 * @param Manifestation $manifestation
	 * @param array of Item $excluded_items
	 *
	 * @return array of Item $item : the choosen items by the algorhythm
	 *
	 */
	public function SearchItemFromManifestation($manifestation, $excluded_items = null);


	/**
	 * State calculation
	 */

	/**
	 * Given a item loan state (LookupValuePeer::value_class(LOANSTATUS), it gives an array of possible
	 *  destination actions (type ITEMACTIONTYPE)
	 *
	 * @param $from_loanstatus
	 *
	 * @return array of LookupValuePeer::value_class(ITEMACTIONTYPE)  : array of destination actions
	 *
	 */
	public function CalculateItemActionsFromStatus($from_loanstatus);


	/**
	 * It calculates the array of possible destination actions from a function of the three parameters
	 *
	 * @param Item $item
	 * @param Patron $patron
	 * @param Librarian $clavisLibrarian
	 * @param integer $library
	 *
	 * @return array of LookupValuePeer::value_class(ITEMACTIONTYPE)  : array of destination actions
	 *
	 */
	public function CalculateItemActions($item, $patron = null, $clavisLibrarian = null, $library = null);


	/**
	 * Given a loan status (LookupValuePeer::value_class(ITEMACTIONTYPE), it gives an array of possible
	 *  destination actions (type ITEMACTIONTYPE)
	 *
	 * @param $from_itemaction
	 *
	 * @return array of LookupValuePeer::value_class(ITEMACTIONTYPE)  : array of destination actions
	 *
	 */
	public function CalculateItemActionsFromAction($from_itemaction);

	/**
	 * Given a loan status (LookupValuePeer::value_class(LOANSTATUS), it gives an array of
	 * possible destination states (type LOANSTATUS)
	 *
	 * @param $from_loanstatus
	 *
	 * @return array of LookupValuePeer::value_class(LOANSTATUS)  : array of destination loan status
	 *
	 */
	public function CalculateLoanStatiFromStatus($from_loanstatus);

	/**
	 * It returns whether the passed loanstatus is considered
	 * active (first statuses: A-F), or not (G-H).
	 *
	 * @param Loan $loanStatus
	 * @return boolean
	 */
	public function IsLoanStatusActive($loan);

	public function IsLoanStatusCurrent($object);
				
	public function IsItemLoaned($item, $patron = null);

	public function IsIllRequested($item, $patron = null);
	public function IsInTransit($item, $patron = null);
	public function IsReadyForTransit($item, $patron = null);

	public function IsOutStatus($status = null);

	public function IsInStatus($status = null);

	/**
	 * It returns an array, for populating dropdown lists, containing
	 * all the loanstatus which are considered active (for loan) as indexes,
	 * and descriptions as corrisponding elements.
	 *
	 * If a true is passed as parameter, a first blank item is created
	 * (index by 0).
	 *
	 * @param boolean $withBlank
	 */
	public function GetActiveLoanStatuses2DropDownList($withBlank = false);

	/**
	 * It returns an array, for populating dropdown lists, containing
	 * all the loanstatus which are considered inactive (for loan) as indexes,
	 * and descriptions as corrisponding elements.
	 *
	 * If a true is passed as parameter, a first blank item is created
	 * (index by 0).
	 *
	 * @param boolean $withBlank
	 */
	public function GetInactiveLoanStatuses2DropDownList($withBlank = false);

	/**
	 * To be removed (same as DoILL2ReadyToMoveItem())
	 * Here for compatibility
	 *
	 * @param Item $item
	 * @param ClavisLibrarian $clavisLibrarian
	 *
	 * @return boolean
	 *
	 */
	/*
	public function DoILL2LoanItem($item, $clavisLibrarian);
	*/

	/**
	 * Take the item from the ILL status to the ready to move status
	 *
	 * @param Item $item
	 * @param ClavisLibrarian $clavisLibrarian
	 * @param int $requestId
	 *
	 * @return boolean
	 *
	 */
	public function DoILL2ReadyToMoveItem($item, $clavisLibrarian, $requestId = null);

	/**
	 * Take the item from the ready to move status to the moving status
	 *
	 * @param Item $item
	 * @param ClavisLibrarian $clavisLibrarian
	 *
	 * @return boolean
	 *
	 */
	public function DoReadyToMove2MovingItem($item, $clavisLibrarian = null, $note = '');

	/**
	 * Take the item from the moving status to the ready to loan status
	 *
	 * @param Item $item
	 * @param ClavisLibrarian $clavisLibrarian
	 *
	 * @return boolean
	 *
	 */
	public function DoMoved2ReadyToLoanItem($item, $clavisLibrarian);

	/**
	 * Take the item from the ready to loan status to the actual loan status
	 *
	 * @param Item $item
	 * @param ClavisLibrarian $clavisLibrarian
	 * @param *nix timestamp : $dueDate
	 *
	 * @return boolean
	 *
	 */
	public function DoReadyToLoan2LoanItem($item, $clavisLibrarian, $dueDate = null);


	/**
	 * Reset the item to the loanable status (from a 'In rientro')
	 *
	 * @param Item $item
	 * @param ClavisLibrarian $clavisLibrarian
	 *
	 * @return boolean
	 *
	 */
	public function PutOnShelfItem($item, $clavisLibrarian = null);

	public function DoManageRequest($manifestation, $clavisLibrarian);
	public function DoUnManageRequest($manifestation, $clavisLibrarian, $force = false);
	public function ResetManagedReservations();
	public function ResetExpiredReservations();

	public function IsItemOutOfHome($item);

	public function CalculateReservationCriteria(	$actualLibraryId = null,
														$localFlag = null,
														$managedFlag = null,
														$ignoreConsultationsFlag = false,
														$criteria = null,
														$type = 'Regular' );
	
	public function CountRequests(	$fromLibraryIdFilter = null, 
									$objectType = '', 
									$objectId = null, 
			
									$localFlag = true, 
									$managed = null,
									$type = 'Regular');
	
	public function GetRequestedObjects(	$fromLibraryIdFilter = null, 
											$objectType = '', 
											$objectId = null, 
			
											$managed = null, 
											$criteria = null, 
											$issue_id = null);

	public function CountRequestedObjects(	$fromLibraryIdFilter = null, 
												$objectType = '', 
												$objectId = null, 
			
												$managed = null, 
												$criteria = null, 
												$issue_id = null);

	/**
	 * Returns a list of item_request_id ready to be matched
	 * by a Library
	 *
	 * @param int $library_id
	 * @param int $limit
	 * @param int $offset
	 * @param string $sortFiled
	 * @param string $sortDirection
	 */
	public function GetReadyItemRequests($library_id, $limit, $offset, $sortFiled, $sortDirection);

	public function putLostToAvailableItem($itemId = null);

	/**
	 *	It disables the renewability of an item.
	 *
	 * @param int $itemId
	 * @param ClavisLibrarian $clavisLibrarian
	 *
	 * @return enum  (ClavisLoanManager return value)
	 */
	public function doDisableRenew($itemId, $clavisLibrarian);

	/**
	 *	It enables the renewability of an item.
	 *
	 * @param int $itemId
	 * @param ClavisLibrarian $clavisLibrarian
	 *
	 * @return enum  (ClavisLoanManager return value)
	 */
	public function doEnableRenew($itemId, $clavisLibrarian);

	/**
	 *	It freezes an active local consultation of an item.
	 *
	 * @param int $itemId
	 * @param ClavisLibrarian $clavisLibrarian
	 *
	 * @return enum  (ClavisLoanManager return value)
	 */
	public function doFreezeConsultation($itemId, $clavisLibrarian);

	/**
	 *	It resumes an active local consultation of an item.
	 *
	 * @param int $itemId
	 * @param ClavisLibrarian $clavisLibrarian
	 *
	 * @return enum  (ClavisLoanManager return value)
	 */
	public function doResumeConsultation($itemId, $clavisLibrarian);

	/**
	 * It manages the entrance of out-of-catalog items from an extra-system,
	 * and sets the loan as a normal inter-consortia loan
	 *
	 * @param Item $item
	 * @param ItemRequest $itemRequest
	 * @param ClavisLibrarian $clavisLibrarian
	 */
	public function doAcceptFromExtra($item, $itemRequest, $clavisLibrarian = null);

	/**
	 * It returns an out-of-catalog item to his own consortia
	 * @param Item $item
	 * @param ClavisLibrarian $clavisLibrarian
	 */
	public function doExtraGoHome($item, $clavisLibrarian = null);

	/**
	 * It returns the propel object which is the destination of the given loan
	 * (or the related item).
	 *
	 * @param Item/Loan $source
	 *
	 * @return Patron/Library
	 */
	public function getLoanDestinationObject($source);
	
	/**
	 * We output an array made as (distance => items number), calculated
	 * as the number of items that are present in the system, divided
	 * in distances according with the starting distance (that would occur
	 * in a loan) from the home of the item and the ending distance as my
	 * own library.
	 * 
	 * @param type $manifestationId
	 * @param type $issueId
	 * 
	 * @return associative array (distance => array(AVAILABLE items count, ALL items count)) 
	 */
	public function countAvailableItemsByBasin($manifestationId, $issueId = null);
		
}
