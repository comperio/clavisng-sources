<?php
/**
 * IRequestManager interface file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 ePortal Technologies
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Interfaces
 */

/**
 * IRequestManager Interface
 *
 * Interface which declares methods for requesting.
 *
 * @author Marco Brancalion <marco@comperio.it>
 * @version 2.7
 * @package Interfaces
 * @since 2.5.0
 */
interface IRequestManager 
{
	/**
	 * calculateRequestDistances()
	 * 
	 * It outputs an array with possible distances (referred to basins)
	 * for perfecting a request of an object (manifestation) with a
	 * particular delivery library in mind.
	 * 
	 * If there are not distance, an empty array will be returned.
	 * 
	 * @param Manifestation $manifestation
	 * @param int $deliveryLibraryId
	 * 
	 * @return array 
	 */	
	public function calculateRequestDistances(Manifestation $manifestation, $deliveryLibraryId);

	/**
	 * calculateMinRequestDistance()
	 * 
	 * It outputs an  integer that is the min distance
	 * that has been found for perfecting a request of an 
	 * object (manifestation or an issue) with a particular 
	 * delivery library in mind.
	 * 
	 * If there are not valid distances, a null value is returned.
	 * 
	 * @param Manifestation|Issue $propelObject
	 * @param int $deliveryLibraryId
	 * 
	 * @return int or null
	 */	
	public function calculateMinRequestDistance(	$propelObject, 
													$deliveryLibraryId);
		
	/**
	* Explicit reservation of an item
	*
	* @param Item $item
	* @param Patron $patron
	* @param Library $deliveryLibrary
	* @param ClavisLibrarian $clavisLibrarian
	* @param string $description
	* @param int $externalLibraryId
	*
	* @return boolean
	*/
	public function reserveItem(	$item,
									$patron,
									$deliveryLibrary,
									$clavisLibrarian = null,
									$description = null,
									$externalLibraryId = null );
	/**
	 * reserveManifestation()
	 * 
	 * Reservation of a manifestation
	 *
	 * @param Manifestation $manifestation
	 * @param Patron $patron
	 * @param Library $deliveryLibrary
	 * @param ClavisLibrarian $clavisLibrarian
	 * @param string $description

	 * @param integer $issue_id
	 * @param integer $externaLibraryId
	 * @param integer $maxDistance
	 */	
	public function reserveManifestation(	$manifestation,
											$patron,
											$deliveryLibrary,
											$clavisLibrarian = null,
											$description = null,

											$issue_id = null,
											$externalLibraryId = null,
											$maxDistance = null );
	
	/**
	 * It verifies if an item is reservable for a loan
	 *
	 * @param Item $item
	 * @param Patron/Library $destination
	 * @param integer $libraryId
	 * @param boolean $itemCheckForceFlag (itemId check)
	 *
	 * @return int (enumerated) :
	 * 		   self::OK : true
	 *         self::ERROR : generic error
	 *
	 * 		   self::RSV_NOTAVAIL : $item not available for loan
	 * 		   self::RSV_PATRONHASITEM : $item->patron_id == $patron->patron_id
	 * 		   self::RSV_PATRONREQITEM : $item already requested from $patron
	 * 		   self::RSV_PATRONMAXREQ : $patron has reached maximum requests
	 *
	 */
	public static function isItemReservable(	$item,
										$destination = null, 
										$libraryId = null, 
										$itemCheckForceFlag = false );

	public function isManifestationReservable(Manifestation $manifestation,
													$issueId = null,
													$destination = null,
													$deliveryLibraryId = null);
	
	public function isIssueReservable($issue, $destination = null, $libraryId = null);
	
	/**
	 * getManifestationRequests()
	 * 
	 * We get requests with the new NewCirc system, filtered for
	 * manifestation
	 * 
	 * @param int $manifestationId 
	 * 
	 * @return array
	 */
	public function getManifestationRequests($manifestationId);

	public function getRequests(	$actualLibraryId = null, 
									$currentIndexPage = null,
									$pageSize = null,
			
									$itemFilters = array(),
									$itemIdParam = 0);
	
	public function countRequests(	$actualLibraryId = null,
									$itemFilters = array(),
									$itemIdParam = 0,
									$manifestationIdParam = 0,
									$fakeReturnFlag = false);
	
	public function getNeverRequests(	$actualLibraryId = null, 
										$currentIndexPage = null,
										$pageSize = null,
										$filters = array());
	
	public function countNeverRequests(	$actualLibraryId = null,
											$filters = array());
	
	public function getRequestsDetailed($requestId, $actualLibraryId = null);
	
	public function getRequestItemIds($requestId, $actualLibraryId = null);
	
	public function getRequestMyCandidateItemIds($deliveryLibraryId,
													$maxDistance,
													$requestManifestationId,
													$requestItemId,
													$requestIssueId);
	
	public function countRequestAllCandidateItems(	$deliveryLibraryId,
														$maxDistance,
														$requestManifestationId,
														$requestItemId,
														$requestIssueId);
	
	public function manageRequest($itemRequestId, $clavisLibrarian);
	
	public function unManageRequest(	$itemRequestId,
										$clavisLibrarian,
										$changelogText = '',
										$force = false);
	
	public function resetManagedReservations($clavisLibrarian = null);
	
	public function resetExpiredReservations($clavisLibrarian = null);
	
	public static function isItemAvailableClass(	$item,
											$localLibraryId = null);

	public function doNullRequest(ItemRequest $itemRequest,
								  ClavisLibrarian $clavisLibrarian,
								  $note = '');
	
	public function isRequested(	$item, 
									$patron = null);
}
