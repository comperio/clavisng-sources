<?php
/**
 * TurboMarc class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Dario Rigolin <dario@comperio.it>
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 ePortal Technologies
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Libraries
 */

/**
 * TurboMarc Class
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Libraries
 * @since 2.5.0
 */
class TurboMarc extends SimpleXMLElement
{
	const UNIMARC_RECORDEND	= "\x1d";
	const UNIMARC_FIELDEND = "\x1e";
	const UNIMARC_SUBFIELDEND = "\x1f";

	const NST_CONTROL_IN = '';
	const NST_CONTROL_OUT = '';

	/**
	 * Delegate function to get a new TurboMarc collection.
	 *
	 * @return TurboMarc
	 */
	public static function createCollection() {
		return new TurboMarc('<collection xmlns="http://www.indexdata.com/turbomarc"></collection>');
	}

	/**
	 * Delegate function to get a new TurboMarc record.
	 *
	 * @param string $xml Record's XML (defaults to empty record).
	 * @return TurboMarc
	 */
	public static function createRecord($xml='<r></r>') {
		return new TurboMarc($xml);
	}

	/**
	 * Appends a SimpleXMLElement to current tree.
	 *
	 * @param SimpleXMLElement $simplexml The element to be appended.
	 * @return TurboMarc Self (for fluid interface).
	 */
	public function appendNode(SimpleXMLElement &$simplexml) {
		$node = $this->addChild($simplexml->getName(), htmlspecialchars($simplexml));
		foreach ($simplexml->attributes() as $attr_key => $attr_value)
			$node->addAttribute($attr_key, $attr_value);
		foreach ($simplexml->children() as $simplexml_child)
			$node->appendNode($simplexml_child);
		return $this;
    }

	/**
	 * Removes itself from DOM tree.
	 *
	 * @return DOMNode itself
	 */
	public function remove() {
        $dom = dom_import_simplexml($this);
        return $dom->parentNode->removeChild($dom);
    }

	/**
	 * Sets the leader to record, adds it if missing, updates it if already existent.
	 *
	 * @param string $leaderValue The leader value, complete string.
	 * @return TurboMarc The leader element.
	 * @throws Exception
	 */
	public function setLeader($leaderValue) {
		if (is_string($leaderValue))
			$leader = new TurboMarcLeader($leaderValue);
		else if ($leaderValue instanceof TurboMarcLeader)
			$leader = $leaderValue;
		else
			throw new Exception(__FUNCTION__.' called with param neither string nor TurboMarcLeader.');
		if (!$this->l instanceof SimpleXMLElement)
			$this->addChild('l');
		$this->l = $leader->getLeader();
		return $this->l;
	}

	/**
	 *
	 * @return TurboMarcLeader
	 */
	public function getLeader() {
		return (isset($this->l)) ?
			new TurboMarcLeader((string)$this->l) :
			new TurboMarcLeader();
	}

	/**
	 * Returns the field num/tag, i.e. the element's name with stripped first char.
	 *
	 * @return string
	 */
	public function getTag() {
		return trim(substr($this->getName(),1));
	}

	/**
     * Creates a new empty Record in the tree and returns it
     *
     * @return TurboMarc Created record
     */
    public function addRecord()
    {
        return $this->addChild('r');
    }

	/**
	 * Adds a control field.
	 * Can only be used for 001-009 fields.
	 *
	 * @param string $field
	 * @param string $value
	 * @return TurboMarc Created field
	 * @throws Exception
	 */
	public function setControlField($field, $value)
    {
		if (intval($field) > '009')
			throw new Exception(__FUNCTION__.'() can only be used for 001-009 fields.');
		$xmlTag = "c{$field}";
		unset($this->$xmlTag);
		$this->addChild($xmlTag,TurboMarcUtility::encodeXML($value));
		return $this->$xmlTag;
    }

	/**
     * Creates a new Field in the tree and returns it.
     *
     * @param string $tag Tag number 000-999
     * @param string $ind1 Indicator 1 One char
     * @param string $ind2 Indicator 2 One char
     * @return TurboMarc Created field
     */
    public function addField($tag, $ind1 = ' ', $ind2 = ' ')
    {
		if ($tag < '010')
			return $this->setControlField($tag,'');
        $field = $this->addChild('d'.$tag);
		$field->addAttribute('i1', $ind1);
        $field->addAttribute('i2', $ind2);
        return $field;
    }

	/**
	 * Creates a new CDField in the tree and returns it.
	 *
	 * @param string $tag Tag number 100-199
	 * @return TurboMarc Created field
	 * @throws Exception
	 */
	public function addCDField($tag) {
		if (!array_key_exists($tag, TurboMarcMappings::$cdflist))
			throw new Exception("The field '{$tag}' is not supported.");
		$xmlName = 'd'.$tag;
		// check if repeatable
		if (TurboMarcMappings::$cdflist[$tag]['rep']) {
			$field = $this->addChild($xmlName);
		} else {
            if(isset($this->$xmlName))
			    $field = $this->$xmlName;
			else
				$field = $this->addChild($xmlName);
		}
		return $field;
	}

	/**
	 * Adds a subfield to a field, escaping special chars.
	 *
	 * @param string $code The subfield code
	 * @param string $value The subfield value
	 * @return TurboMarc Created subfield
	 */
    public function addSubField($code,$value)
    {
		return $this->addChild('s'.$code,htmlspecialchars($value, ENT_COMPAT, 'UTF-8', false));
    }

	/**
	 * Adds a subfield to a field, without performing any kind of escape.
	 *
	 * @param string $code The subfield code
	 * @param string $value The subfield value
	 * @return TurboMarc Created subfield
	 */
    public function addSubFieldRaw($code,$value)
    {
        return $this->addChild('s'.$code,$value);
    }

	/**
	 * Sets a CDF
	 * @param string $tag CDF's tag
	 * @param string $pos CDF's position
	 * @param string $value The CDF's value
	 * @return TurboMarc Itself for fluid interface
	 * @throws Exception
	 */
	public function setCDF($tag,$pos,$value) {
		$fnum = substr($this->getName(),1,3);
		$len = @TurboMarcMappings::$cdflist[$fnum][$tag][$pos];
		if (!$len)
			throw new Exception("Either field, tag or position not recognized ({$fnum} | {$tag} | {$pos})");
		// remove pipe char in cdfs (issued by ticket #938)
		$value = str_replace('|', ' ', $value);
		if (strlen($value) <= $len)
			$value = sprintf("%{$len}s",$value);
		$xmlName = "s$tag";
		if (!isset($this->$xmlName))
			$this->addSubField($tag, str_repeat(' ',TurboMarcMappings::$cdflist[$fnum][$tag.'_len']));
		if (strlen((string)$this->$xmlName) != $len)
			$this->$xmlName = str_pad((string)$this->$xmlName,$len);
		$this->$xmlName = substr_replace((string)$this->$xmlName,$value,$pos,$len);
		return $this;
	}

	/**
	 * Gets the value of a CDF, NOT trimmed.
	 *
	 * @param string $tag CDF's tag
	 * @param string $pos CDF's position
	 * @return string The CDF's value
	 * @throws Exception
	 */
	public function getCDF($tag,$pos) {
		$fnum = $this->getTag();
		$xmlTag = "s{$tag}";
		$len = @TurboMarcMappings::$cdflist[$fnum][$tag][$pos];
		if (!$len)
			throw new Exception("Either field, tag or position not recognized ({$fnum} | {$tag} | {$pos})");
		return (isset($this->$xmlTag)) ?
			substr($this->$xmlTag, $pos, $len) :
			str_repeat(' ',TurboMarcMappings::$cdflist[$fnum][$tag.'_len']);
	}

	/**
	 * To be called upon a d100-d199 field. Returns an array of all field's CDFs.
	 *
	 * @return array
	 */
	public function getCDFArray() {
		$ret = array();
		if ($this['i1'] != ' ' || $this['i2'] != ' ')
			$ret['0'] = " {$this['i1']}{$this['i2']}";
		foreach ($this->children() as $sf)
			$ret[$sf->getTag()] = (string)$sf;
		return $ret;
	}

	/**
	 * Returns a TurboMarc object representing an embedded field (found in 46X links).
	 *
	 * @param int $num The embedded field num.
	 * @return TurboMarc The embedded field.
	 */
	public function getEmbeddedField($num) {
		$f = null;
		foreach ($this->children() as $sf) {
			if ($sf->getName() == 's1' &&
					substr((string)$sf, 0, 3) == "{$num}" &&
					$f === null) {
				$f = self::createRecord("<d{$num}></d{$num}>");
				if ($num <= '009') {
					$f->setControlField($num, substr((string)$sf, 3));
					return $f;
				}
			} else if ($sf->getName() != 's1' && $f != null) {
				$f->addSubField($sf->getTag(), (string)$sf);
			} else if ($sf->getName() == 's1' && $f != null) {
				return $f;
			}
		}
		return $f;
	}

	/**
	 * Returns a TurboMarc object representing an embedded record (found in 46X links).
	 *
	 * @return TurboMarc The embedded record.
	 */
	public function getEmbeddedRecord() {
		$tm = self::createRecord();
		foreach ($this->children() as $sf) {
			if ($sf->getName() == 's1') {
				$num = substr((string)$sf, 0, 3);
				if ($num <= '009') {
					$tm->setControlField($num, substr((string)$sf, 3));
					continue;
				}
				$f = $tm->addField($num);
			} else if ($sf->getName() != 's1') {
				$f->addSubField($sf->getTag(), (string)$sf);
			}
		}
		return $tm;
	}

	/**
	 * Parses a ISO 2709 record and converts it to this Turbomarc object.
	 *
	 * @param string $record The record in ISO 2709 format
	 * @param boolean $utfconv Wether to convert
	 * @param boolean $uniTranslate
     * @param string $charsets
	 * @return TurboMarc
	 */
	public function parseRecord($record, $utfconv=false, $uniTranslate=false,$charset='UTF-8, ISO-8859-1, ISO-8859-15, auto')
	{
		$fields = explode("\x1E", $record);
		$dir = substr($fields[0], 24);
		$this->setLeader(substr($record, 0, 24));

		for ($i = 0; $i < strlen($dir); $i+=12) {
			$fnum = substr($dir, $i, 3);
			$pos = intval(($i / 12) + 1);

            if(!isset($fields[$pos])) continue;
            $field = $fields[$pos];

			if ($utfconv)
                $field = TurboMarcUtility::convertNonSortText(mb_convert_encoding($field,'UTF-8',$charset));
			else if ($uniTranslate)
				$field = utf8_encode(TurboMarcUtility::translate($field));
			else
				$field = TurboMarcUtility::convertNonSortText($field);

			$fld = ($fnum > '000' && $fnum < '010') ?
				$this->setControlField($fnum,$field) :
				$this->addField($fnum)->parseField($field);
		}
		return $this;
	}

	/**
	 *
	 * @param string $field
	 * @return TurboMarc
	 */
	private function parseField($field) {
		$fnum = $this->getTag();
		// remove pipe char in cdfs (issued by ticket #938)
		if ($fnum >= 100 && $fnum < 200)
			$field = str_replace('|', ' ', $field);
		$this['i1'] = substr($field,0,1);
		$this['i2'] = substr($field,1,1);
		$subfields = explode(self::UNIMARC_SUBFIELDEND,substr($field,3));
		foreach ($subfields as $v) {
			$tag = substr($v,0,1);
			$v = TurboMarcUtility::encodeXML(substr($v,1));
			if (trim($v))
				$this->addSubField($tag,$v);
		}
		return $this;
	}

	public function parseMarc21($record, $utfconv=false)
	{
		$dirLen = intval(substr($record,12,5))-25;
		$dirItem = $dirLen/12;
		$dirValue = substr($record,24,$dirLen);
		$this->setLeader($record);
		$fullcode = substr($record,25+$dirLen);
		for ($i=0; $i<$dirItem; $i++) {
			$fnum = substr($dirValue,$i * 12, 3);
			$len = intval(substr($dirValue,$i * 12 + 3, 4));
			$pos = intval(substr($dirValue,$i * 12 + 7, 5));
			$field =  substr($record,25 + $dirLen + $pos, $len - 1);

			if ($utfconv)
				$field = iconv('iso8859-1','utf-8',$field);

			TurboMarcUtility::addMarc21toUnimarc($this,$fnum,$field);
		}
		return $this;
	}

	public function getISO2709()
	{
		if (isset($this->l)) {
			// record
			$body = $directory = '';
			$dirpos = 0;
			foreach ($this->children() as $field)
				if (($tag = intval($field->getTag())) > 0) {
					$isofld = $field->getISO2709();
					$len = strlen($isofld);
					$directory .= sprintf("%03d%04d%05d",$tag,$len,$dirpos);
					$dirpos += $len;
					$body .= $isofld;
				}
			$baseStart = strlen($directory) + 25;
			$recLen = strlen($body) + $baseStart + 1;
			if ($recLen > 99999) $recLen = 99999; // Fix for HUGE records

			$l = $this->getLeader();
			$txt = sprintf("%05d%1s%1s%1s%1s 22%05d%1s%1s 450 ",
					$recLen,$l->recstatus, $l->type, $l->biblevel, $l->hiercode,
					$baseStart, $l->enclevel, $l->descrForm).
				$directory.self::UNIMARC_FIELDEND.
				$body.self::UNIMARC_RECORDEND;
		} else {
			// field
			$tag = $this->getTag();
			$txt = ($tag < '010') ?
				'' : sprintf("%1s%1s",$this['i1'], $this['i2']);
			if ($tag < '010')
				$txt .= (string)$this;
			else
				foreach ($this->children() as $sf) {
					$tag = $sf->getTag();
					
					if (strlen($tag) > 1)
						continue; // for fixing custom tags (ex. bnz)
					
					$txt .= (!trim($tag)) ?
						str_replace("\n",'',$sf) : self::UNIMARC_SUBFIELDEND.$tag.str_replace("\n",'',$sf);
				}
			$txt .= self::UNIMARC_FIELDEND;
		}
		return $txt;
	}

	public function toArray()
	{
		$return = array();
		if (isset($this->r))
			return $this->r->toArray();
		if (isset($this->l)) {
			// record
			$return['l'] = (string)$this->l;
			foreach ($this->children() as $name => $field)
				if ($name[0] == 'l')
					continue;
				else if ($name[0] == 'c')
					$return[$name] = (string)$field;
				else if (isset($return[$name]))
					$return[$name][] = $field->toArray();
				else
					$return[$name] = array($field->toArray());
		} else {
			// field
			$return['indicator1'] = (string)$this['i1'];
			$return['indicator2'] = (string)$this['i2'];
			foreach ($this->children() as $name => $sfield)
				$return[$name] = (string)$sfield;
		}
		return $return;
	}

	public function getTXT()
	{
		if (isset($this->l)) {
			// record
			$l = $this->getLeader();
			$txt = sprintf("%1s%1s%1s%1s%1s%1s",$l->recstatus, $l->descrForm, $l->type,
				$l->hiercode, $l->biblevel, $l->enclevel);
			foreach ($this->children() as $field)
				if (intval($field->getTag()) > 0)
					$txt .= "\n".$field->getTXT();
		} else {
			// field
			$tag = $this->getTag();
			$txt = sprintf("%3s%1s%1s",$tag,$this['i1'],$this['i2']);
			if ($tag < 010)
				$txt .= (string)$this;
			else
				foreach ($this->children() as $sf)
					$txt .= "\${$sf->getTag()}{$sf}";
		}
		return $txt;
	}

	public function getFancyTxt($with_heading = true, $ignore_indicators = false)
	{
		$fnum = $this->getName();
		if ('c' == $fnum[0])
			return (string)$this;
		$txt = '';
		if ($with_heading)
			$txt .= $ignore_indicators
				? sprintf("%3s   ",$this->getTag())
				: sprintf("%3s %1s%1s",$this->getTag(),$this['i1'],$this['i2']);
		foreach ($this->children() as $sf)
			if ((string)$sf != '')	// skip empty fields
				$txt .= " \${$sf->getTag()} $sf";
		return $txt;
	}


	function getEAN() {
		if (isset($this->d073))
			return (string)$this->d073->sa;
		else if (isset($this->d010))
			return (string)$this->d010->sa;
	}

	function getISBD($escape=false) {
		return $this->getTitle(200,$escape);
	}

	public function getTitle($field = 200, $escape=false) {
		$tag = "d{$field}";
		// can be called on record OR d200.
		$f200 = (!isset($this->$tag)) ?
			$this : $this->$tag;

		$ind = str_pad($f200['i1'],1,' ');
		$ind .= str_pad($f200['i2'],1,' ');
		if ($ind == '  ')
			$ind = '1 ';
		$title = array(
			'nst'	=> '',
			'txt'	=> array(),
			'ind'	=> $ind);
		$findH = false;
		$i = 0;
		foreach ($f200->children() as $sf) {
			$v = trim((string)$sf);

            if($escape)
                $v = str_replace(array(" ; "," : "," / "),array(" \\; "," \\: "," \\/ "),$v);

			switch ($sf->getName()) {
				case 'sa':
					if (count($title['txt']) == 0) {
						$title['txt'][0] = '';
						if (strpos($v, '*') === false) {
							@$title['txt'][0] = $v;
						} else {
							$title['nst'] = substr($v, 0, strpos($v, '*'));
							if ($title['nst'] == '*')
								$title['nst'] = '';
							$title['txt'][$i] = substr($v, strpos($v, '*') + 1);
						}
					} else {
						@$title['txt'][$i] .= " ; $v";
					}
					break;
				case 'sb':
					@$title['txt'][$i] .= " [$v]";
					break;
				case 'sc':
					@$title['txt'][++$i] = $v;
					break;
				case 'sd':
					@$title['txt'][$i] .= " = $v";
					break;
				case 'se':
					@$title['txt'][$i] .= " : $v";
					break;
				case 'sf':
					@$title['txt'][$i] .= " / $v";
					break;
				case 'sg':
					@$title['txt'][$i] .= " ; $v";
					break;
				case 'sh':
					$findH = true;
					@$title['txt'][$i] .= (($escape)?"^. $v":". $v");
					break;
				case 'si':
                    if($escape)
					    @$title['txt'][$i] .= ($findH) ? "^, $v" : "^. $v";
                    else
                        @$title['txt'][$i] .= ($findH) ? ", $v" : ". $v";
					break;
			}
		}
		if (count($title['txt']) < 1)
			$title['txt'][0] = '';
		return $title;
	}

	/**
	 * Returns the title as a string.
	 *
	 * @param bool $complete If false it does not include $c.
	 * @param int $field
	 * @return string
	 */
	public function getFullTitle($complete=true, $field=200,$escape=false)
	{
		$title = $this->getTitle($field,$escape);
		$ret = trim($title['nst'].implode('. ',$title['txt']));
		return $ret;
	}

	/**
	 *
	 * @param string $value Title value
	 * @param array $others (optional) array of other titles
	 * @param string $indicator Two-char string
	 * @return TurboMarc Created/updated field 200
	 */
	public function setTitle($value,$others=array(), $indicator='1 ') {
		$fld = isset($this->d200) ?
			$this->d200 : $this->addField(200,$indicator{0},$indicator{1});
		$fld->parse200('a',$value);
		foreach ($others as $text)
			$fld->parse200('c',$text);
		return $fld;
	}

	/**
	 *
	 * @return string
	 */
	public function getEdition($escape=false) {
		$edit = '';
		foreach ($this->children() as $sf) {
			$v = trim((string)$sf);
            if($escape)
                $v = str_replace(array(" = ", " / ", " ; ", ", "),array(" \\= ", " \\/ ", " \\; ", "\\, "),$v);

			switch ($sf->getName()) {
					case 'sa':
						$edit .= $v;
						break;
					case 'sd':
						$edit .= " = ".$v;
						break;
					case 'sf':
						$edit .= " / ".$v;
						break;
					case 'sg':
						$edit .= " ; ".$v;
						break;
					case 'sb':
						$edit .= ", ".$v;
						break;
			}
		}
		return $edit;
	}

	/**
	 *
	 * @return array of strings
	 */
	public function getEditions($escape=false) {
		$ret = array();
		foreach($this->d205 as $field)
			$ret[] = $field->getEdition($escape);
		return $ret;
	}

	/**
	 *
	 * @param string $value
	 * @return TurboMarc Itself
	 */
	public function setEdition($value) {
		$splitTag = preg_split('#(?<!\\\)( = | / | ; |, )#',$value ,-1,PREG_SPLIT_DELIM_CAPTURE | PREG_SPLIT_NO_EMPTY );
		if (count($splitTag)==0)
			return;
		$fld = $this->addField('205');
		$fld->addSubField('a',str_replace(array("\\, "," \\; "," \\: "," \\= "," \\/ "),array(", "," ; "," : "," = "," / "),$splitTag[0]));
		$beforeBrace = true;
		for ($i=1; $i < count($splitTag); $i+=2) {
			switch(trim($splitTag[$i])) {
				case ";":
					$fld->addSubField('g',str_replace(array("\\, "," \\; "," \\: "," \\= "," \\/ "),array(", "," ; "," : "," = "," / "),$splitTag[$i+1]));
					break;
				case "=":
					$fld->addSubField('d',str_replace(array("\\, "," \\; "," \\: "," \\= "," \\/ "),array(", "," ; "," : "," = "," / "),$splitTag[$i+1]));
					break;
				case "/":
					$fld->addSubField('f',str_replace(array("\\, "," \\; "," \\: "," \\= "," \\/ "),array(", "," ; "," : "," = "," / "),$splitTag[$i+1]));
					break;
				case ",":
					$fld->addSubField('b',str_replace(array("\\, "," \\; "," \\: "," \\= "," \\/ "),array(", "," ; "," : "," = "," / "),$splitTag[$i+1]));
					break;
			}
		}
		return $fld;
	}

	/**
	 *
	 * @param boolean $ind
     * @param boolena $escape Escape isbd syntax
	 * @return string
	 */
	public function getPublication($ind=false,$escape=false) {
		$publ = '';
		$check = false;
		$tmp = 0;
		foreach ($this->children() as $sf) {
			$v = trim((string)$sf);
            if($escape)
                $v = str_replace(array(", "," ; "," : "),array("\\, "," \\; "," \\: "),$v);

			switch ($sf->getName()) {
				case 'sa':
					if ($tmp==1)
						$publ.= " ; ";
					$publ .= $v;
					$tmp = 1;
					break;
				case 'sb':
					$publ .= ", ".$v;
					break;
				case 'sc':
					$publ .= " : ".$v;
					break;
				case 'sd':
					if ($publ)
						$publ .= ', ';
					$publ .= $v;
					break;
				case 'se':
					$publ.= ($check)?" ; ".$v:" (".$v;
					$check = true;
					break;
				case 'sf':
					$publ .= ", ".$v;
					break;
				case 'sg':
					$publ .= " : ".$v;
					break;
				case 'sh':
					$publ .= ", ".$v;
					break;
			}
		}
		if ($check)
			$publ .= ')';
		$i = str_pad((string)$this['i1'].(string)$this['i2'],2,' ',STR_PAD_RIGHT);
		return ($ind)?array('txt'=>$publ,'ind'=>$i):$publ;
	}

	public function getPublications($ind=false,$escape=false) {
		$ret = array();
		foreach($this->d210 as $field)
			$ret[] = $field->getPublication($ind,$escape);
		return $ret;
	}

	public function setPublication($value,$indicator='  ') {
		$splitTag = preg_split('#(?<!\\\)(, | : | ; )#',' '.$value,-1,PREG_SPLIT_DELIM_CAPTURE);
		$tagCnt = count($splitTag);
		switch ($tagCnt) {
			case 0:
				return;
			case 1:
				$firstTag = 'd';
				break;
			default:
				$firstTag = 'a';
				break;
		}
		$fld = $this->addField('210', $indicator{0}, $indicator{1});
		if (trim($splitTag[0]))
			$fld->addSubField($firstTag,trim(str_replace(array("\\, "," \\; "," \\: "),array(", "," ; "," : "),$splitTag[0])));
		$beforeBrace = true;
		$sfe = null;
		for ($i=1; $i < $tagCnt; $i+=2) {
			if (!isset($splitTag[$i+1]))
				break;
			if ($beforeBrace && ($bp = strpos($splitTag[$i+1],' (')) !== false) {
				// brace found, subsplit accordingly
				$splitTag[$tagCnt-1] = rtrim($splitTag[$tagCnt-1],') ');
				$sfe = substr($splitTag[$i+1],$bp+2);
				$splitTag[$i+1] = substr($splitTag[$i+1],0,$bp);
			}
			switch(trim($splitTag[$i])) {
				case ';':
					$tag = $beforeBrace ? 'a' : 'e';
					break;
				case ':':
					$tag = $beforeBrace ? 'c' : 'g';
					break;
				case ',':
					$tag = $beforeBrace ? 'd' : 'h';
					break;
			}
			$fld->addSubField($tag,str_replace(array("\\, "," \\; "," \\: "),array(", "," ; "," : "),$splitTag[$i+1]));
			if ($sfe) {
				$fld->addSubField('e',$sfe);
				$beforeBrace = $sfe = false;
			}
		}
		return $fld;
	}

	public function getPhysicalDesc($escape) {
		$physdesc = '';
		foreach ($this->children() as $sf) {
			$v = trim((string)$sf);
            if($escape)
                $v = str_replace(array(" + "," ; "," : "),array(" \\+ "," \\; "," \\: "),$v);
			switch ($sf->getName()) {
				case 'sa':
					$physdesc .= $v;
					break;
				case 'sc':
					if ($v != '')
						$physdesc .= ' : '.$v;
					break;
				case 'sd':
					$physdesc .= ' ; '.$v;
					break;
				case 'se':
					if ($v != '')
						$physdesc .= ' + '.$v;
					break;
			}
		}
		while (strpos($physdesc,'))'))
			$physdesc = str_replace('))',')',$physdesc);
		return $physdesc;
	}

	public function getPhysicalDescs($escape=false) {
		$ret = array();
		foreach($this->d215 as $field)
			$ret[] = $field->getPhysicalDesc($escape);
		return $ret;
	}

	public function setPhysicalDesc($value) {

        $splitTag = preg_split('# (?<!\\\)(:|;|\\+) #',' '.$value,-1,PREG_SPLIT_DELIM_CAPTURE | PREG_SPLIT_NO_EMPTY);
		//$splitTag = preg_split(  "/ (:|;|\+) /",$value ,-1,PREG_SPLIT_DELIM_CAPTURE | PREG_SPLIT_NO_EMPTY );
		if (count($splitTag)==0)
			return;
		$fld = $this->addField('215');
		$lastf = $fld->addSubField('a',str_replace(array(" \\: "," \\; "," \\+ "),array(" : "," ; "," + "),trim($splitTag[0])));
        $findPlus = false;
		for ($i=1; $i < count($splitTag); $i+=2) {
			switch(trim($splitTag[$i])) {
				case ";":
                    if(!$findPlus)
                        $lastf = $fld->addSubField('d',trim(str_replace(array(" \\: "," \\; "," \\+ "),array(" : "," ; "," + "),$splitTag[$i+1])));
                    else {
                        $dom=dom_import_simplexml($lastf);
                        $dom->nodeValue .= " ; " . trim($splitTag[$i+1]);
                    }
					break;
				case ":":
                    if(!$findPlus)
                        $lastf = $fld->addSubField('c',trim(str_replace(array(" \\: "," \\; "," \\+ "),array(" : "," ; "," + "),$splitTag[$i+1])));
                    else {
                        $dom=dom_import_simplexml($lastf);
                        $dom->nodeValue .= " : " . trim($splitTag[$i+1]);
                    }
					break;
				case "+":
                    $lastf = $fld->addSubField('e',trim(str_replace(array(" \\: "," \\; "," \\+ "),array(" : "," ; "," + "),$splitTag[$i+1])));
                    $findPlus = true;
					break;
			}
		}
		return $fld;
	}


	public function getSerie($escape=false) {
		$series = '';
		$tmp=0;
		foreach($this->children() as $sf) {
			$v = (string)$sf;
            if($escape)
                $v = str_replace(
                        array(" = "," / "," : ",". ",", "," ; "),
                        array(" \\= "," \\/ "," \\: ","\\. ","\\, "," \\; "),$v);

			switch ($sf->getName()) {
				case 'sa':
					$series .= $v;
					break;
				case 'sd':
					$series .= " = ".$v;
					break;
				case 'se':
					$series .= " : ".$v;
					break;
				case 'sf':
					$series .= " / ".$v;
					break;
				case 'sh':
					$series .= ". ".$v;
					$tmp=1;
					break;
				case 'si':
					if ($tmp==1) {
						$series.=", ";
					} else {
						$series.=". ";
					}
					$series.=$v;
					break;
				case 'sv':
					$series.=" ; ".$v;
					break;
				case 'sx':
					$series.=", ".$v;
					break;
			}
		}
		return $series;
	}

	public function getSeries($escape=false) {
		$ret = array();
		foreach($this->d225 as $field)
			$ret[] = $field->getSerie($escape);
		return $ret;
	}

	public function setSerie($value) {
		$splitTag = preg_split('#(?<!\\\)(, | : | ; | / | = |\. )#',$value,-1,PREG_SPLIT_DELIM_CAPTURE | PREG_SPLIT_NO_EMPTY );
		if (count($splitTag)==0)
			return;
		$fld = $this->addField('225');
		$fld->addSubField('a',str_replace(array("\\, "," \\; "," \\: "," \\/ "," \\= ","\\. "),array(", "," ; "," : "," / "," = ",". "),$splitTag[0]));
		$beforeH = true;
		for ($i=1; $i < count($splitTag); $i+=2) {
			switch(trim($splitTag[$i])) {
				case "=":
					$fld->addSubField('d',str_replace(array("\\, "," \\; "," \\: "," \\/ "," \\= ","\\. "),array(", "," ; "," : "," / "," = ",". "),$splitTag[$i+1]));
					break;
				case ":":
					$fld->addSubField('e',str_replace(array("\\, "," \\; "," \\: "," \\/ "," \\= ","\\. "),array(", "," ; "," : "," / "," = ",". "),$splitTag[$i+1]));
					break;
				case "/":
					$fld->addSubField('f',str_replace(array("\\, "," \\; "," \\: "," \\/ "," \\= ","\\. "),array(", "," ; "," : "," / "," = ",". "),$splitTag[$i+1]));
					break;
				case ";":
					$fld->addSubField('v',str_replace(array("\\, "," \\; "," \\: "," \\/ "," \\= ","\\. "),array(", "," ; "," : "," / "," = ",". "),$splitTag[$i+1]));
					break;
				case ".":
					$tag = $beforeH ? 'h' : 'i';
					$fld->addSubField($tag,str_replace(array("\\, "," \\; "," \\: "," \\/ "," \\= ","\\. "),array(", "," ; "," : "," / "," = ",". "),$splitTag[$i+1]));
					$beforeH = false;
					break;
				case ",":
					$tag = $beforeH ? 'x' : 'i';
					$fld->addSubField($tag,str_replace(array("\\, "," \\; "," \\: "," \\/ "," \\= ","\\. "),array(", "," ; "," : "," / "," = ",". "),$splitTag[$i+1]));
					break;
			}
		}
		return $fld;
	}

	/**
	 *
	 * @param int $fieldNum The unimarc field in which to search for author.
	 *						If not specified, searches in all 7[012][01] fields.
	 * @return string
	 */
	public function getAuthor($fieldNum=null) {
		$flist = array('200','210','700','701','710','711','720','721');
		if (in_array($fieldNum,$flist))
			$flist = array($fieldNum);
		else
			$flist = array('700','701','710','711','720','721');

		$author = '';
		foreach ($flist as $fnum) {
			$xmlNum = "d{$fnum}";
			if (isset($this->$xmlNum))
				$author = $this->$xmlNum->getAuthorField();
			if ($author)	break;	// break at first found
		}
		return $author;
	}

	public function getAuthorField() {
		$author = '';
		//$ab_separator = (substr($this->getTag(),1,1) == 1 && isset($this->si) && 'G' == (string)$this->si) ? ' : ' : ', ';
        $ab_separator = (substr($this->getTag(),1,1) == 1 ) ? ' : ' : ', ';

        foreach ($this->children() as $sf) {
			$v = (string)$sf;
			if (trim($v))
				switch ($sf->getName()) {
					case 'sa':
						$author .= $v;
						break;
					case 'sb':
						$author .= $ab_separator.$v;
						break;
					case 'sc':
					case 'sd':
					case 'se':
					case 'sf':
						$author .= " <$v>";
						break;
				}
		}
		$author = str_replace(array('<>','< >','> <',', , ',',,',', <','<<','>>','< <','> >'),array('','',' ; ',', ',',',' <','<','>','<','>'),$author);
		return $author;
	}

	/**
	 *
	 * @return string
	 */
	public function getDewey() {
		return (isset($this->d676)) ?
			(string) $this->d676->sa : '';
	}

	/**
	 *
	 * @return string
	 */
	public function getSubjects()
	{
		$ret = array();
		for ($i=600; $i<=610; ++$i) {
			$tag = "d{$i}";
			if (isset($this->$tag))
				foreach ($this->$tag as $f) {
					$subj = (string)$f->sa;
					foreach ($f->sx as $sf)
						$subj .= ' - '.trim($sf);
					if (isset($f->s2) && trim($f->s2))
						$subj = "{$f->s2}/{$subj}";
					$ret[] = $subj;
				}
		}
		return $ret;
	}

	/**
	 *
	 * @return TurboMarc
	 * @throws Exception if leader does not exists
	 */
	public function getAuthorityMainField()
	{
		// try all the main fields serially
		$mainfields = array('d200','d210','d220','d230','d216','d260',
			'd250','d921','d931','d676','d680','d686');
		foreach ($mainfields as $field)
			if (isset($this->$field))
				return $this->$field;
		return null;
	}

	/**
	 *
	 * @param string $firstTag
	 * @param string $text
	 * @return TurboMarc Itself
	 */
	private function parse200($firstTag, $text)
	{
		$splitTag = preg_split('#(?<!\\\)( / | : | ; | = |\\^\\. |\\^, )#',$text,-1, PREG_SPLIT_DELIM_CAPTURE|PREG_SPLIT_NO_EMPTY);
		if (count($splitTag) == 0)
			$splitTag[0] = $text;
		$prevf = $this->addSubField($firstTag,trim(str_replace(array(" \\; "," \\: "," \\/ "),array(" ; "," : "," / "),$splitTag[0])));
		$beforeSlash = true;

		for ($i=1; $i<count($splitTag); $i+=2) {
			if (isset($splitTag[$i+1]))
				switch(trim($splitTag[$i])) {
					case "/":
						$prevf = $this->addSubField('f',trim(str_replace(array(" \\; "," \\: "," \\/ "),array(" ; "," : "," / "),$splitTag[$i+1])));
						$beforeSlash = false;
						break;
					case ":":
                        $prevf = $this->addSubField('e',trim(str_replace(array(" \\; "," \\: "," \\/ "),array(" ; "," : "," / "),$splitTag[$i+1])));
						break;
					case "=":
                        if(in_array($prevf->getTag(),array('a','c','d')))
                            $prevf = $this->addSubField('d',trim(str_replace(array(" \\; "," \\: "," \\/ "),array(" ; "," : "," / "),$splitTag[$i+1])));
                        else {
                            $dom=dom_import_simplexml($prevf);
                            $dom->nodeValue .= " = " . trim($splitTag[$i+1]);
                        }
						break;
					case "^.":
                        if(isset($splitTag[$i+2]) && trim($splitTag[$i+2]) == "^," )
                            $prevf = $this->addSubField('h',str_replace(array(" \\; "," \\: "," \\/ "),array(" ; "," : "," / "),$splitTag[$i+1]));
                        else
                            $prevf = $this->addSubField('i',str_replace(array(" \\; "," \\: "," \\/ "),array(" ; "," : "," / "),$splitTag[$i+1]));
						break;
					case "^,":
                        $prevf = $this->addSubField('i',str_replace(array(" \\; "," \\: "," \\/ "),array(" ; "," : "," / "),$splitTag[$i+1]));
						break;

					case ";":
						$tag = ($beforeSlash) ? 'a' : 'g';
                        $prevf = $this->addSubField($tag,str_replace(array(" \\; "," \\: "," \\/ "),array(" ; "," : "," / "),$splitTag[$i+1]));
						break;
				}
		}
		return $this;
	}

	/**
	 *
	 * @param string $firstTag
	 * @param string $text
	 * @return TurboMarc Itself
	 */
	public function parseAuthor($firstTag, $text)
	{
		$splitTag = preg_split("/([,<;]) /",$text,-1, PREG_SPLIT_DELIM_CAPTURE|PREG_SPLIT_NO_EMPTY);
		if (count($splitTag) == 0)
			$splitTag[0] = $text;
		$this->addSubField($firstTag,$splitTag[0]);
		for ($i=1; $i<count($splitTag); $i+=2) {
			if (isset($splitTag[$i+1]))
				switch($splitTag[$i]) {
					case ',':
						$this->addSubField('b',', '.$splitTag[$i+1]);
						break;
					case '<':
					case ';':
						$v = trim($splitTag[$i+1],' >');
						if (substr($v,-1)=='.')	// . found
							$sftag = 'd';
						else
							$sftag = 'c';
						$this->addSubField($sftag,$v);
						break;
				}
		}
		return $this;
	}

	public function sortFields($asXML=false)
	{
		return TurboMarcUtility::sortFields($this,$asXML);
	}
}

/**
 * TurboMarcLeader Class
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Libraries
 * @since 2.5.0
 */
class TurboMarcLeader {

	public $recLen;
	public $dirLen;
	public $dirItem;
	public $dirValue;

	public $recstatus;
	public $type;
	public $biblevel=' ';
	public $hiercode=' ';
	public $entitytype=' ';
	public $enclevel;
	public $descrForm;

	public function __construct($value = null) {
		if ($value)
			$this->setLeader($value);
	}

	/**
	 * Sets TurboMarcLeader from string format.
	 *
	 * @param string $value
	 */
	public function setLeader($value) {
		$this->recLen = str_pad(substr($value,0,5),5,'0',STR_PAD_LEFT);
		$this->dirLen = intval(substr($value,12,5))-25;
		$this->dirItem = $this->dirLen/12;
		$this->dirValue = substr($value,24,$this->dirLen);
		$this->recstatus	= substr($value,5,1);
		$this->type			= substr($value,6,1);
		$this->biblevel		= substr($value,7,1);	// bibliographic-only
		$this->hiercode		= substr($value,8,1);	// bibliographic-only
		$this->entitytype	= substr($value,9,1);	// authority-only
		$this->enclevel		= substr($value,17,1);
		$this->descrForm	= substr($value,18,1);
	}

	/**
	 * Returns the leader string formatted.
	 *
	 * @return string The leader in string format
	 */
	public function getLeader() {
		return sprintf('%5s%1s%1s%1s%1s%1s2201234%1s%1s 450 ',
			$this->recLen,
			$this->recstatus,
			$this->type,
			$this->biblevel,
			$this->hiercode,
			$this->entitytype,
			$this->enclevel,
			$this->descrForm);
	}

	/**
	 * Returns the leader in ISO 2709 format.
	 *
	 * @return string The leader in ISO2709 format
	 */
	public function getLeaderISO2709() {
		return sprintf("%05d%1s%1s%1s%1s%1s22%05d%1s%1s 450 ",
			$this->recLen, $this->recstatus, $this->type, $this->biblevel,$this->hiercode,
			$this->entitytype,$this->enclevel,$this->descrForm);
	}

}

/**
 * TurboMarcMappings Class
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Libraries
 * @since 2.5.0
 */
class TurboMarcMappings {

	public static $reverseLinkType = array(
		'409'=>'411',
		'410'=>'419',
        '411'=>'409',
	 	'412'=>'413',
		'413'=>'412',
		'419'=>'410',
		'421'=>'422',
		'422'=>'421',
		'423'=>'423',
		'424'=>'425',
		'425'=>'424',
		'430'=>'440',
		'431'=>'441',
		'432'=>'442',
		'433'=>'443',
		'434'=>'444',
		'435'=>'445',
		'437'=>'448',
		'436'=>'446',
		'440'=>'430',
		'441'=>'431',
		'442'=>'432',
		'443'=>'433',
		'444'=>'434',
		'445'=>'435',
		'446'=>'436',
		'447'=>'447',
		'448'=>'437',
		'451'=>'451',
		'452'=>'452',
		'453'=>'454',
		'454'=>'453',
		'455'=>'456',
		'456'=>'455',
		'461'=>'463',
		'463'=>'461',
		// 462 and 464 should be removed.
		'462'=>'462',
		'464'=>'463',
		'470'=>'470',
		'481'=>'482',
		'482'=>'481',
		'488'=>'488'
	);

	public static $cdflist = array(
		'100'	=> array(
			'rep'	=> false,
			'a_len'	=> 36,
			'a'		=> array(0=>8, 8=>1, 9=>4, 13=>4, 17=>1, 18=>1,
				19=>1, 20=>1, 21=>1, 22=>3, 25=>1, 26=>4, 30=>4, 34=>2)),
		'101'	=> array(
			'rep'	=> false,
			'a_len'	=> 3,
			'a'		=> array(0=>3),
			'b_len'	=> 3,
			'b'		=> array(0=>3),
			'c_len'	=> 3,
			'c'		=> array(0=>3),
			'd_len'	=> 3,
			'd'		=> array(0=>3),
			'e_len'	=> 3,
			'e'		=> array(0=>3),
			'f_len'	=> 3,
			'f'		=> array(0=>3),
			'g_len'	=> 3,
			'g'		=> array(0=>3),
			'h_len'	=> 3,
			'h'		=> array(0=>3),
			'i_len'	=> 3,
			'i'		=> array(0=>3),
			'j_len'	=> 3,
			'j'		=> array(0=>3)),
		'102'	=> array(
			'rep'	=> false,
			'a_len'	=> 2,
			'a'		=> array(0=>2)),
		'105'	=> array(
			'rep'	=> false,
			'a_len'	=> 13,
			'a'		=> array(0=>1, 1=>1, 2=>1, 3=>1, 4=>1, 5=>1, 6=>1, 7=>1, 8=>1, 9=>1, 10=>1, 11=>1, 12=>1)),
		'106'	=> array(
			'rep'	=> true,
			'a_len'	=> 3,
			'a'		=> array(0=>1, 1=>1, 2=>1)),
		'109'	=> array(
			'rep'	=> false,
			'a_len'	=> 23,
			'a'		=> array(0=>3, 3=>3, 6=>3, 9=>3, 12=>3, 15=>3, 18=>2, 20=>2, 22=>1)),
		'110'	=> array(
			'rep'	=> false,
			'a_len'	=> 11,
			'a'		=> array(0=>1, 1=>1, 2=>1, 3=>1, 4=>1, 5=>1, 6=>1, 7=>1, 8=>1, 9=>1, 10=>1)),
		'115'	=> array(
			'rep'	=> true,
			'a_len'	=> 20,
			'a'		=> array(0=>1, 1=>3, 4=>1, 5=>1, 6=>1, 7=>1, 8=>1, 9=>1, 10=>1,
				11=>1, 12=>1, 13=>1, 14=>1, 15=>1, 16=>1, 17=>1, 18=>1, 19=>1),
			'b_len'	=> 15,
			'b'		=> array(0=>1, 1=>1, 4=>1, 5=>1, 6=>1, 7=>1, 8=>1, 9=>6)),
		'116'	=> array(
			'rep'	=> true,
			'a_len'	=> 18,
			'a'		=> array(0=>1, 1=>1, 2=>1, 3=>1, 4=>2, 6=>2, 8=>2, 10=>2, 12=>2, 14=>2, 16=>2)),
		'117'	=> array(
			'rep'	=> true,
			'a_len'	=> 9,
			'a'		=> array(0=>2, 2=>2, 4=>2, 6=>2, 8=>1)),
		'120'	=> array(
			'rep'	=> false,
			'a_len'	=> 13,
			'a'		=> array(0=>1, 1=>1, 2=>1, 3=>1, 4=>1, 5=>1, 6=>1, 7=>2, 9=>2, 11=>2)),
		'121'	=> array(
			'rep'	=> false,
			'a_len'	=> 9,
			'a'		=> array(0=>1, 1=>1, 2=>1, 3=>2, 5=>1, 6=>1, 7=>1, 8=>1),
			'b_len'	=> 8,
			'b'		=> array(0=>1, 1=>1, 2=>2, 4=>1, 5=>1, 6=>1, 7=>1)),
		'122'	=> array(
			'rep'	=> true,
			'a_len'	=> 11,
			'a'		=> array(0=>1, 1=>4, 5=>2, 7=>2, 9=>2)),
		'123'	=> array(
			'rep'	=> true,
			'0_len'	=> 1,
			'0'		=> array(1=>1),
			'a_len'	=> 1,
			'a'		=> array(0=>1),
			'd_len'	=> 8,
			'd'		=> array(0=>1, 1=>3, 4=>2, 6=>2),
			'e_len'	=> 8,
			'e'		=> array(0=>1, 1=>3, 4=>2, 6=>2),
			'f_len'	=> 8,
			'f'		=> array(0=>1, 1=>3, 4=>2, 6=>2),
			'g_len'	=> 8,
			'g'		=> array(0=>1, 1=>3, 4=>2, 6=>2),
			'h_len'	=> 4,
			'h'		=> array(0=>4),
			'i_len'	=> 8,
			'i'		=> array(0=>1, 1=>3, 4=>2, 6=>2),
			'j_len'	=> 8,
			'j'		=> array(0=>1, 1=>3, 4=>2, 6=>2),
			'k_len'	=> 6,
			'k'		=> array(0=>1, 2=>2, 4=>2),
			'm_len'	=> 6,
			'm'		=> array(0=>1, 2=>2, 4=>2),
			'n_len'	=> 4,
			'n'		=> array(0=>4),
			'o_len'	=> 4,
			'o'		=> array(0=>4),
			'p_len'	=> 3,
			'p'		=> array(0=>2, 2=>1)),
		'124'	=> array(
			'rep'	=> true,
			'a_len'	=> 1,
			'a'		=> array(0=>1),
			'b_len'	=> 1,
			'b'		=> array(0=>1),
			'c_len'	=> 2,
			'c'		=> array(0=>2),
			'd_len'	=> 1,
			'd'		=> array(0=>1),
			'e_len'	=> 1,
			'e'		=> array(0=>1),
			'f_len'	=> 2,
			'f'		=> array(0=>2),
			'g_len'	=> 2,
			'g'		=> array(0=>2)),
		'125'	=> array(
			'rep'	=> false,
			'a_len'	=> 2,
			'a'		=> array(0=>1,1=>1),
			'b_len'	=> 2,
			'b'		=> array(0=>1,1=>1),
			// $c is defined as variable length, for ease of implementation
			// I assume it has only 3 positions. When needed, you can add as
			// many as wanted.
			'c_len'	=> 3,
			'c'		=> array(0=>1,1=>1,2=>1)),
		'126'	=> array(
			'rep'	=> false,
			'a_len'	=> 15,
			'a'		=> array(0=>1,1=>1,2=>1,3=>1,4=>1,5=>1,6=>1,7=>1,8=>1,9=>1,10=>1,11=>1,12=>1,13=>1,14=>1),
			'b_len'	=> 3,
			'b'		=> array(0=>1,1=>1,2=>1)),
		'127'	=> array(
			'rep'	=> false,
			'a_len'	=> 6,
			'a'		=> array(0=>2,2=>2,4=>2)),
		'128'	=> array(
			'rep'	=> true,
			'a_len'	=> 3,
			'a'		=> array(0=>3),
			'd_len'	=> 3,
			'd'		=> array(0=>3)),
		'130'	=> array(
			'rep'	=> true,
			'a_len'	=> 11,
			'a'		=> array(0=>1,1=>1,2=>1,3=>1,4=>1,7=>1,8=>1,9=>1,10=>1)),
		'131'	=> array(
			'rep'	=> false,
			'a_len'	=> 2,
			'a'		=> array(0=>2),
			'b_len'	=> 3,
			'b'		=> array(0=>3),
			'c_len'	=> 2,
			'c'		=> array(0=>2),
			'd_len'	=> 2,
			'd'		=> array(0=>2),
			'e_len'	=> 2,
			'e'		=> array(0=>2),
			'f_len'	=> 2,
			'f'		=> array(0=>2),
			'g_len'	=> 2,
			'g'		=> array(0=>2),
			'h_len'	=> 4,
			'h'		=> array(0=>4),
			'i_len'	=> 4,
			'i'		=> array(0=>4),
			'j_len'	=> 2,
			'j'		=> array(0=>2),
			'k_len'	=> 2,
			'k'		=> array(0=>2),
			'l_len'	=> 2,
			'l'		=> array(0=>2)),
		'135'	=> array(
			'rep'	=> true,
			'a_len'	=> 13,
			'a'		=> array(0=>1,1=>1,2=>1,3=>1,4=>1,5=>3,8=>1,9=>1,10=>1,11=>1,12=>1)),
		'140'	=> array(
			'rep'	=> false,
			'a_len'	=> 26,
			'a'		=> array(0=>1,1=>1,2=>1,3=>1,4=>1,5=>1,6=>1,7=>1,8=>1,9=>2,11=>2,
				13=>2,15=>2,17=>2,19=>1,20=>1,21=>1,22=>1,23=>1,24=>1,25=>1)),
		'141'	=> array(
			'rep'	=> true,
			'a_len'	=> 8,
			'a'		=> array(0=>1,1=>1,2=>1,3=>1,4=>1,5=>1,6=>1,7=>1),
			'b_len'	=> 8,
			'b'		=> array(0=>2,2=>2,4=>1,5=>1,6=>1,7=>1),
			'c_len'	=> 1,
			'c'		=> array(0=>1),
			'5_len'	=> 15,
			'5'		=> array(0=>15),
			'9_len'	=> 3,
			'9'		=> array(0=>1,1=>1,2=>1)),
		'145'	=> array(
			'rep'	=> true,
			'a_len'	=> 1,
			'a'		=> array(0=>1),
			'b_len'	=> 8,
			'b'		=> array(0=>2,2=>3,5=>2,7=>1),
			'c_len'	=> 8,
			'c'		=> array(0=>2,2=>3,5=>2,7=>1),
			'd_len'	=> 8,
			'd'		=> array(0=>2,2=>3,5=>2,7=>1),
			'e_len'	=> 4,
			'e'		=> array(0=>4),
			'f_len'	=> 4,
			'f'		=> array(0=>3,3=>1)),
		'149'	=> array(
			'rep'	=> false,
			'a_len'	=> 24,
			'a'		=> array(0=>2,2=>2,4=>2,6=>2,8=>2,10=>1,11=>1,12=>1,13=>1,14=>1,
				15=>1,16=>1,17=>1,18=>1,19=>1,20=>1,21=>1,22=>1,23=>1),
			'b_len'	=> 8,
			'b'		=> array(0=>1,1=>1,2=>1,3=>1,4=>1,5=>1,6=>1,7=>1),
			'c_len'	=> 8,
			'c'		=> array(0=>2,2=>2,4=>1,5=>1,6=>1,7=>1),
			'd_len'	=> 2,
			'd'		=> array(0=>1,1=>1),
			'9_len'	=> 3,
			'9'		=> array(0=>1,1=>1,2=>1)),
        '182'   => array(
            'rep' => false,
            'a_len' => 1,
            'a' => array( 0 => 1 )
        ),
        '181'  => array(
            'rep' => true,
            'a_len' => 1,
            'a' => array( 0 => 1),
            'b_len' => 6,
            'b' => array( 0=>1,1=>1,2=>1,3=>1,4=>1,5=>1)
        )
	);
}

/**
 * TurboMarcUtility Class
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Libraries
 * @since 2.5.0
 */
class TurboMarcUtility {

	const HIER_LOWER = 0;
	const HIER_TOP = 1;

	const FIELDS_EQUAL = 0;
	const FIELDS_DIFF = 1;
	const FIELDS_TM1ONLY = 2;
	const FIELDS_TM2ONLY = 3;

	/**
	 * Sort fields.
	 *
	 * @param string $turbomarc
	 * @param bool $asXML
	 * @return string|TurboMarc
	 */
	public static function sortFields($turbomarc,$asXML=false)
	{
		$temp = <<<EOT
		<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0">
			<xsl:output indent="yes"/>

			<xsl:template match="@* | node()">
				<xsl:copy>
					<xsl:apply-templates select="@* | node()"/>
 				</xsl:copy>
 			</xsl:template>

		  <xsl:template match="r">
			<xsl:copy>
			  <xsl:apply-templates select="@*"/>
			  <xsl:apply-templates select="*">
				<xsl:sort select="local-name()"/>
			  </xsl:apply-templates>
			</xsl:copy>
		  </xsl:template>

		</xsl:stylesheet>
EOT;
		$xsl = new DOMDocument;
		$xsl->loadXML($temp);
		$proc = new XSLTProcessor;
		$proc->importStyleSheet($xsl);
		if ($turbomarc instanceof SimpleXMLElement) {
			$doc = dom_import_simplexml($turbomarc)->ownerDocument;
		} else {
			$doc = new DOMDocument();
			$doc->loadXML($turbomarc);
		}
		$sorted = $proc->transformToXML($doc);
		return $asXML ? $sorted : TurboMarc::createRecord($sorted);
	}

	public static function translate($text) {
		$s = '';
		$len = strlen($text);
		$i = 0;
		$ch = '';
		while ($i < $len) {
			if (ord($text{$i}) == 0x0E ) { // Shift char
				$i++;
				if (ord($text{$i}) >= 0x40 && ord($text{$i}) <= 0x5F) {
					$ch = $text{$i};
					$i += 2;
					switch (ord($ch)) {
						case 0x41:				// Grave Accent
							switch($text{$i}) {
								case 'a':	$s .= 'à';	break;
								case 'e':	$s .= 'è';	break;
								case 'i':	$s .= 'ì';	break;
								case 'o':	$s .= 'ò';	break;
								case 'u':	$s .= 'ù';	break;
								case 'A':	$s .= 'À';	break;
								case 'E':	$s .= 'È';	break;
								case 'I':	$s .= 'Ì';	break;
								case 'O':	$s .= 'Ò';	break;
								case 'U':	$s .= 'Ù';	break;
								default:	$s .= $text{$i};
							};
							break;
						case 0x42:              // Acute accent
							switch($text{$i}) {
								case 'a':	$s .= 'á';	break;
								case 'e':	$s .= 'é';	break;
								case 'i':	$s .= 'í';	break;
								case 'o':	$s .= 'ó';	break;
								case 'u':	$s .= 'ú';	break;
								case 'A':	$s .= 'Á';	break;
								case 'E':	$s .= 'É';	break;
								case 'I':	$s .= 'Í';	break;
								case 'O':	$s .= 'Ó';	break;
								case 'U':	$s .= 'Ú';	break;
								default:	$s .= $text{$i};
							};
							break;
						case 0x43:       // Circumflex
							switch($text{$i}) {
								case 'a':	$s .= 'â';	break;
								case 'e':	$s .= 'ê';	break;
								case 'i':	$s .= 'î';	break;
								case 'o':	$s .= 'ô';	break;
								case 'u':	$s .= 'û';	break;
								case 'A':	$s .= 'Â';	break;
								case 'E':	$s .= 'Ê';	break;
								case 'I':	$s .= 'Î';	break;
								case 'O':	$s .= 'Ô';	break;
								case 'U':	$s .= 'Û';	break;
								default:	$s .= $text{$i};
							};
							break;
						case 0x44:			// Tilde accent
							switch($text{$i}) {
								case 'a':	$s .= 'ã';	break;
								case 'n':	$s .= 'ñ';	break;
								case 'o':	$s .= 'õ';	break;
								case 'A':	$s .= 'Ã';	break;
								case 'N':	$s .= 'Ñ';	break;
								default:	$s .= $text{$i};
							};
							break;
						case 0x48:
						case 0x49:       // Dieresis or Umlaut
							switch($text{$i}) {
								case 'a':	$s .= 'ä';	break;
								case 'e':	$s .= 'ë';	break;
								case 'i':	$s .= 'ï';	break;
								case 'o':	$s .= 'ö';	break;
								case 'u':	$s .= 'ü';	break;
								case 'A':	$s .= 'Ä';	break;
								case 'E':	$s .= 'Ë';	break;
								case 'I':	$s .= 'Ï';	break;
								case 'O':	$s .= 'Ö';	break;
								case 'U':	$s .= 'Ü';	break;
								case 'y':	$s .= 'ÿ';	break;
								default:	$s .= $text{$i};
							};
							break;
						case 0x4A:   // Ring Accent
							switch($text{$i}) {
								case 'a':	$s .= 'å';	break;
								case 'A':	$s .= 'Å';	break;
								default:	$s .= $text{$i};
							};
							break;
						case 0x50:          // Cedillia
							switch($text{$i}) {
								case 'c':	$s .= 'ç';	break;
								case 'C':	$s .= 'Ç';	break;
								default:	$s .= $text{$i};
							};
							break;
						case 0x4B:
						case 0x4C:  		// Upperscript comma czec we dont support it
						case 0x4D:			// Double acute accent
						default:
							$s .= $text{$i};
					}
				} else {
					$s .= array_key_exists(ord($text{$i}),self::$charMap)?
						self::$charMap[ord($text{$i})]:'*';
					$i++;
				}
			} else if (ord($text{$i}) == 0x1B || ord($text{$i}) == 0xC2){
				$i += 2;
				while ((ord($text{$i}) != 0x1B || ord($text{$i}) != 0xC2) && ($i < $len)) {
					$s .= $text{$i};
					$i++;
				}
				$s .= '*';
				$i++;
			} else {
				$s .= $text{$i};
			}
			$i++;
		}
		return $s;
	}

	/**
	 *
	 * @param string $text
	 * @return string
	 */
	public static function convertNonSortText($text) {
		$text = preg_replace('![\* ]*\x{00C2}\x{0088}(.*?)\x{00C2}\x{0089}!u','$1*',$text);
		$text = preg_replace('![\* ]*\x{0088}(.*?)\x{0089}!u','$1*',$text);
		$text = preg_replace('![\* ]*\x{001B}.(.*?)\x{001B}.!u','$1*',$text);
		return $text;
	}

	/**
	 * Adds a MARC21/USMARC formatted field to a TurboMarc object, converting it
	 * to equivalent Unimarc fields.
	 *
	 * @param TurboMarc $tm
	 * @param int $fnum
	 * @param string $field
	 * @return TurboMarc The newly created field.
	 */
	public static function addMarc21toUnimarc(TurboMarc &$tm, $fnum, $field)
	{
        if (!$field)
            return;
		$sf = array();
		$i1 = $i2 = ' ';
		if (intval($fnum) > 10) {
			$i1 = substr($field,0,1);
			$i2 = substr($field,1,1);
			foreach (explode(TurboMarc::UNIMARC_SUBFIELDEND,substr($field,3)) as $v)
				$sf[substr($v,0,1)] = TurboMarcUtility::encodeXML(substr($v,1));
		}
		$ret = null;
		switch($fnum) {
			case 1:
				$ret = $tm->setControlField('001', $field);
				break;

			case 5:
				$ret = $tm->setControlField('005', substr($field,0,8));
				break;

			case 8:
				$ret = $tm->addField('100');
				$ret->setCDF('a', 0, '  '.substr($field,0,6));
				$map = array(
					'c'	=> 'a',
					'd'	=> 'b',
					'u' => 'c',
					's'	=> 'd',
					'r'	=> 'e',
					'q'	=> 'f',
					'm'	=> 'g',
					't'	=> 'h',
					'p'	=> 'i',
					'e'	=> 'j'
				);
				$pos8 = array_key_exists(substr($field,6,1),$map) ? $map[substr($field,6,1)] : 'd';
				$ret->setCDF('a',8,$pos8);
				$ret->setCDF('a',9,substr($field,7,4));
				$ret->setCDF('a',13,substr($field,11,4));
				$map = array(
					'a'	=> 'b',
					'b'	=> 'c',
					'j'	=> 'a',
					'c'	=> 'd',
					'd'	=> 'e',
					'e'	=> 'k',
					'g'	=> 'm'
				);
				$pos17 = array_key_exists(substr($field,22,1),$map) ? $map[substr($field,22,1)] : 'u';
				$ret->setCDF('a',17,$pos17.'  ');
				$map = array(
					'f'	=> 'a',
					's'	=> 'b',
					'l'	=> 'c',
					'c'	=> 'e',
					'i'	=> 'f',
					'z'	=> 'z',
					'o'	=> 'h',
				);
				$pos20 = array_key_exists(substr($field,28,1),$map) ? $map[substr($field,28,1)] : 'u';
				$ret->setCDF('a',20,$pos20);
				$ret->setCDF('a',21,(substr($field,38,1) == '#') ? '0' : '1');
				$ret->setCDF('a',22,'ita');
				$ret->setCDF('a',25,'y');
				$ret->setCDF('a',34,substr($field,33,1));
				break;

			case 20:
				if (array_key_exists('a', $sf)) {
					$isbn = $sf['a'];
					$tag = '010';
					if (strlen($isbn) == 10)
						$tag = '010';
					if (strlen($isbn) == 13 && strpos($isbn,'-') === false)
						$tag = '073';
					$ret = $tm->addField($tag);
					$ret->addSubField('a',$isbn);
					if (array_key_exists('c', $sf))
						$ret->addSubField('d',$isbn);
					if (array_key_exists('z', $sf))
						$ret->addSubField('z',$isbn);
					if (array_key_exists('6', $sf))
						$ret->addSubField('6',$isbn);
				}
				break;

			case 22:
				$ret = $tm->addField('011');
				$ret->addSubField('a',$sf['a']);
				break;

//			case 35:
//				$ret = new UnimarcField(35);
//				$ret->addSubField('a',$this->getSubField('a'));
//				break;

			case 50:
				$ret = $tm->addField('680');
				$ret->addSubField('a',$sf['a']);
				if (array_key_exists('b', $sf))
					$ret->addSubField('b',$sf['b']);
				break;

			case 80:
				$ret = $tm->addField('675');
				$ret->addSubField('a',$sf['a']);
				break;

			case 82:
				$ret = $tm->addField('676');
				$ret->addSubField('a',$sf['a']);
				if (array_key_exists('2', $sf))
					$ret->addSubField('v',$sf['2']);
				break;

			case 84:
				$ret = $tm->addField('686');
				$ret->addSubField('a',$sf['a']);
				if (array_key_exists('b', $sf))
					$ret->addSubField('b',$sf['b']);
				if (array_key_exists('2', $sf))
					$ret->addSubField('2',$sf['2']);
				break;

			case 100:
				$ret = $tm->addField('700');
				$ret->addSubField('a',$sf['a']);
				if (array_key_exists('c', $sf))
					$ret->addSubField('c',$sf['c']);
				if (array_key_exists('d', $sf))
					$ret->addSubField('f',$sf['d']);
				if (array_key_exists('q', $sf))
					$ret->addSubField('g',$sf['q']);
				break;

			case 110:
				$ret = $tm->addField('710');
				$ret['i1'] = '0';
				$ret['i2'] = $i1;
				$ret->addSubField('a',$sf['a']);
				if (array_key_exists('b', $sf))
					$ret->addSubField('b',$sf['b']);
				if (array_key_exists('n', $sf))
					$ret->addSubField('d',$sf['n']);
				if (array_key_exists('c', $sf))
					$ret->addSubField('e',$sf['c']);
				break;

			case 111:
				$ret = $tm->addField('710');
				$ret['i1'] = '1';
				$ret['i2'] = $i1;
				$ret->addSubField('a',$sf['a']);
				if (array_key_exists('e', $sf))
					$ret->addSubField('b',$sf['e']);
				if (array_key_exists('d', $sf))
					$ret->addSubField('f',$sf['d']);
				if (array_key_exists('c', $sf))
					$ret->addSubField('e',$sf['c']);
				if (array_key_exists('n', $sf))
					$ret->addSubField('d',$sf['n']);
				if (array_key_exists('g', $sf))
					$ret->addSubField('g',$sf['g']);
				if (array_key_exists('h', $sf))
					$ret->addSubField('h',$sf['h']);
				break;

			case 130:
				$ret = $tm->addField('500');
				$ret->addSubField('a',$sf['a']);
				if (array_key_exists('l', $sf) && $sf['l'] != '')
					$ret->addSubField('m',$sf['l']);
				break;

			case 240:
				$ret = $tm->addField('500');
				$ret->addSubField('a',$sf['a']);
				break;

			case 242:
				$ret = $tm->addField('541');
				$ret->addSubField('a',$sf['a']);
				break;

			case 245:
				$ret = $tm->addField('200');
				$ret->addSubField('a', implode(' ',$sf));
				break;

			case 246:
				$ret = $tm->addField('517');
				$ret->addSubField('a',$sf['a']);
				break;

			case 250:
				$ret = $tm->addField('205');
				$ret->addSubField('a',implode(' ',$sf));
				break;

			case 255:
				$ret = $tm->addField('206');
				$ret->addSubField('a',implode(' ',$sf));
				break;

			case 260:
				$ret = $tm->addField('210');
				$ret->addSubField('a',implode(' ',$sf));
				break;

			case 300:
				$ret = $tm->addField('215');
				$ret->addSubField('a',implode(' ',$sf));
				break;

			case 310:
				$ret = $tm->addField('326');
				$ret->addSubField('a',$sf['a']);
				break;

			case 440:
				$ret = $tm->addField('225');
				$ret->addSubField('a',trim($sf['a'],' ;'));
				if (array_key_exists('v', $sf) && $sf['v'] != '')
					$ret->addSubField('v',$sf['v']);
				break;

			case 500:
				$ret = $tm->addField('300');
				$ret->addSubField('a',$sf['a']);
				break;

			case 600:
			case 650:
				$ret = $tm->addField('610');
				$ret->addSubField('a',$sf['a']);
				break;

			case 700:
				$ret = $tm->addField('702');
				$ret->addSubField('a',$sf['a']);
				if (array_key_exists('c', $sf))
					$ret->addSubField('c',$sf['c']);
				if (array_key_exists('d', $sf))
					$ret->addSubField('f',$sf['d']);
				if (array_key_exists('q', $sf))
					$ret->addSubField('g',$sf['q']);
				break;

			case 710:
				$ret = $tm->addField('711');
				$ret['i1'] = '0';
				$ret['i2'] = $i1;
				$ret->addSubField('a',$sf['a']);
				if (array_key_exists('b', $sf))
					$ret->addSubField('b',$sf['b']);
				if (array_key_exists('n', $sf))
					$ret->addSubField('d',$sf['n']);
				if (array_key_exists('c', $sf))
					$ret->addSubField('e',$sf['c']);
				break;

			case 711:
				$ret = $tm->addField('711');
				$ret['i1'] = '1';
				$ret['i2'] = $i1;
				$ret->addSubField('a',$sf['a']);
				if (array_key_exists('e', $sf))
					$ret->addSubField('b',$sf['e']);
				if (array_key_exists('d', $sf))
					$ret->addSubField('f',$sf['d']);
				if (array_key_exists('c', $sf))
					$ret->addSubField('e',$sf['c']);
				if (array_key_exists('n', $sf))
					$ret->addSubField('d',$sf['n']);
				if (array_key_exists('g', $sf))
					$ret->addSubField('g',$sf['g']);
				if (array_key_exists('h', $sf))
					$ret->addSubField('h',$sf['h']);
				break;

			case 740:
				$ret = $tm->addField('540');
				$ret->addSubField('a',$sf['a']);
				break;

			case 752:
				$ret = $tm->addField('702');
				$ret->addSubField('a',$sf['a']);
				break;
		}
		return $ret;
	}

	/**
	 * Parses a TurboMarc record and sanitizes it
	 * (fix hier_level, lowercase leader, language and country, remove empty tags, 899 and pipe from CDFs)
	 *
	 * @param TurboMarc $turbomarc Source record
	 * @return TurboMarc The record transformed.
	 */
	public static function sanitize(TurboMarc $turbomarc)
	{
		// if hiercode is lower than top, set it to bottom (avoid middle)
		$leader = $turbomarc->getLeader();
		if (!$leader instanceof TurboMarcLeader)
			$leader = new TurboMarcLeader();
		if ($leader->hiercode > self::HIER_TOP) {
			$leader->hiercode = self::HIER_LOWER;
			$turbomarc->setLeader($leader);
		}
		$tmxml = $turbomarc->asXML();
		// wipe out 899 (item field for SBN) to get a more
		// compact Turbomarc.
		$func_leader = function($m){return '<l>'.strtolower($m[1]).'</l>';};	// lowercase leader
		$func_lang = function($m){return "<{$m[1]}".stripslashes(strtolower($m[2]))."</{$m[1]}>";};	// lowercase language and country
		$func_fixpipe = function($m){return "<{$m[1]}".stripslashes(str_replace('|',' ',$m[2]))."</{$m[1]}>";};	// fix |
		$tmxml = preg_replace_callback('!<l>([\w\d\s]+)</l>!i', $func_leader, $tmxml);	// match leader
		$tmxml = preg_replace_callback('!<(d10[12])(.+?)</\1>!i', $func_lang, $tmxml);	// match 101/102
		$tmxml = preg_replace_callback('!<(d1\d\d)(.+?)</\1>!i', $func_fixpipe, $tmxml);	// match all CDFs
		$patterns = array(
			'!<(s[\d\w])>\s*</\1>!',	// match empty tags
			'/(<d899.+?)+(<\/d899>)/i',	// match 899
		);
		$tmxml = preg_replace($patterns, '', $tmxml);
		$turbomarc = TurboMarc::createRecord($tmxml);
		return $turbomarc;
	}

	/**
	 * Ensure string contains only XML-accepted chars.
	 *
	 * @param string $string
	 * @return string
	 */
	public static function encodeXML($string)
	{
		// first, convert to XML entities
		$string = mb_convert_encoding($string,'UTF-8','UTF-8, ISO-8859-1, ISO-8859-15, auto');
		// convert common HTML entities to XML equivalent
		$string = self::html2xmlEntities($string);
		// then, ensure no crap chars are inside our string
		$accepted_xml_chars = '/[^\x{0009}\x{000a}\x{000d}\x{0020}-\x{D7FF}\x{E000}-\x{FFFD}]+/u';
		$real_ampersand = '/&(?!amp;)(?!#)/';
		//$string = preg_replace(array($accepted_xml_chars,$real_ampersand), array('','&amp;$1'), $string);
        $string = preg_replace(array($accepted_xml_chars), array(''), $string);

		return $string;
	}

	public static final function html2xmlEntities($str) {
		$xml = array('&#34;', '&#38;', '&#38;', '&#60;', '&#62;', '&#160;', '&#161;',
			'&#162;', '&#163;', '&#164;', '&#165;', '&#166;', '&#167;', '&#168;',
			'&#169;', '&#170;', '&#171;', '&#172;', '&#173;', '&#174;', '&#175;',
			'&#176;', '&#177;', '&#178;', '&#179;', '&#180;', '&#181;', '&#182;',
			'&#183;', '&#184;', '&#185;', '&#186;', '&#187;', '&#188;', '&#189;',
			'&#190;', '&#191;', '&#192;', '&#193;', '&#194;', '&#195;', '&#196;',
			'&#197;', '&#198;', '&#199;', '&#200;', '&#201;', '&#202;', '&#203;',
			'&#204;', '&#205;', '&#206;', '&#207;', '&#208;', '&#209;', '&#210;',
			'&#211;', '&#212;', '&#213;', '&#214;', '&#215;', '&#216;', '&#217;',
			'&#218;', '&#219;', '&#220;', '&#221;', '&#222;', '&#223;', '&#224;',
			'&#225;', '&#226;', '&#227;', '&#228;', '&#229;', '&#230;', '&#231;',
			'&#232;', '&#233;', '&#234;', '&#235;', '&#236;', '&#237;', '&#238;',
			'&#239;', '&#240;', '&#241;', '&#242;', '&#243;', '&#244;', '&#245;',
			'&#246;', '&#247;', '&#248;', '&#249;', '&#250;', '&#251;', '&#252;',
			'&#253;', '&#254;', '&#255;');
		$html = array('&quot;', '&amp;', '&amp;', '&lt;', '&gt;', '&nbsp;', '&iexcl;',
			'&cent;', '&pound;', '&curren;', '&yen;', '&brvbar;', '&sect;', '&uml;',
			'&copy;', '&ordf;', '&laquo;', '&not;', '&shy;', '&reg;', '&macr;',
			'&deg;', '&plusmn;', '&sup2;', '&sup3;', '&acute;', '&micro;', '&para;',
			'&middot;', '&cedil;', '&sup1;', '&ordm;', '&raquo;', '&frac14;', '&frac12;',
			'&frac34;', '&iquest;', '&Agrave;', '&Aacute;', '&Acirc;', '&Atilde;',
			'&Auml;', '&Aring;', '&AElig;', '&Ccedil;', '&Egrave;', '&Eacute;',
			'&Ecirc;', '&Euml;', '&Igrave;', '&Iacute;', '&Icirc;', '&Iuml;', '&ETH;',
			'&Ntilde;', '&Ograve;', '&Oacute;', '&Ocirc;', '&Otilde;', '&Ouml;',
			'&times;', '&Oslash;', '&Ugrave;', '&Uacute;', '&Ucirc;', '&Uuml;',
			'&Yacute;', '&THORN;', '&szlig;', '&agrave;', '&aacute;', '&acirc;',
			'&atilde;', '&auml;', '&aring;', '&aelig;', '&ccedil;', '&egrave;',
			'&eacute;', '&ecirc;', '&euml;', '&igrave;', '&iacute;', '&icirc;',
			'&iuml;', '&eth;', '&ntilde;', '&ograve;', '&oacute;', '&ocirc;',
			'&otilde;', '&ouml;', '&divide;', '&oslash;', '&ugrave;', '&uacute;',
			'&ucirc;', '&uuml;', '&yacute;', '&thorn;', '&yuml;');
		$str = str_replace($html, $xml, $str);
		$str = str_ireplace($html, $xml, $str);
		return $str;
	}

	public static function diff(TurboMarc $tm1, TurboMarc $tm2, $ignore_indicators = false, $link_idsf=null)
	{
		$newtm = TurboMarc::createRecord();
		// clone XML to avoid mangling original
		$tm1 = isset($tm1->r)
			? simplexml_load_string($tm1->r->asXML(),'TurboMarc')
			: simplexml_load_string($tm1->asXML(),'TurboMarc');
		$tm2 = isset($tm2->r)
			? simplexml_load_string($tm2->r->asXML(),'TurboMarc')
			: simplexml_load_string($tm2->asXML(),'TurboMarc');
		$ret = array();
		foreach ($tm1->children() as $field1) {
			$tag = $field1->getName();
			if ('l' == $tag) {
				$ret[] = array('fnum' => 'l',
					'status' => (string)$field1 == (string)$tm2->l ? self::FIELDS_EQUAL : self::FIELDS_DIFF,
					'tm1fld' => (string)$field1,
					'tm2fld' => (string)$tm2->l,
					'mergefld' => (string)$tm2->l);
				$newtm->setLeader($tm2->getLeader());
				unset($tm2->l);
				continue;
			} else {
				unset($field1->sdiff);
				$fnum = $field1->getTag();
				$tm1fld = $field1->getFancyTxt(false, '200' != $fnum && $ignore_indicators);
				$search = $tm2->xpath(".//{$tag}");
				if (count($search) < 1) {
					$ret[] = array('fnum' => $fnum,
						'status' => self::FIELDS_TM1ONLY,
						'tm1fld' => $field1->getFancyTxt(false, '200' != $fnum && $ignore_indicators),
						'tm2fld' => '',
						'mergefld' => $field1->getFancyTxt(false, '200' != $fnum && $ignore_indicators));
					if (self::isLinkField($fnum))
						$field1->addSubField('diff',self::FIELDS_TM1ONLY);
					$newtm->appendNode($field1);
				} else {
					$diffield = $tm2fld = null;
					$found = false;
					// reverse the search results to avoid messing order if fields are not equal
					foreach (array_reverse($search) as $field2) {
						$tm2fld = $field2->getFancyTxt(false, $ignore_indicators);
						if (self::isLinkField($fnum) && $link_idsf
								&& isset($field1->$link_idsf) && isset($field2->$link_idsf))
						{
							$compare = (string)$field1->$link_idsf == (string)$field2->$link_idsf
								|| (string)$field1->s3 == (string)$field2->s3;
						} else {
							$compare = $tm1fld == $tm2fld;
						}
						if ($compare) {
							$ret[] = array('fnum' => $fnum,
								'status' => self::FIELDS_EQUAL,
								'tm1fld' => $field1->getFancyTxt(false, $ignore_indicators),
								'tm2fld' => $tm2fld,
								'mergefld' => $field2->getFancyTxt(false, $ignore_indicators));
							if (self::isLinkField($fnum))
								$field2->addSubField('diff',self::FIELDS_EQUAL);
							$newtm->appendNode($field2);
							$dom = dom_import_simplexml($field2);
							$dom->parentNode->removeChild($dom);
							$found = true;
							break;
						}
						$diffield = $field2;
					}
					if (!$found && $diffield instanceof TurboMarc && !self::isLinkField($fnum))
					{
						$ret[] = array('fnum' => $fnum,
							'status' => self::FIELDS_DIFF,
							'tm1fld' => $field1->getFancyTxt(false, $ignore_indicators),
							'tm2fld' => $tm2fld,
							'mergefld' => $diffield->getFancyTxt(false, $ignore_indicators));
						$newtm->appendNode($diffield);
						$dom = dom_import_simplexml($diffield);
						$dom->parentNode->removeChild($dom);
					}
				}
			}
		}
		// search all tm2-only
		foreach ($tm2->children() as $field2) {
			$tag = $field2->getName();
			// non-link fields
			$ret[] = array('fnum' => $field2->getTag(),
				'status' => self::FIELDS_TM2ONLY,
				'tm1fld' => '',
				'tm2fld' => $field2->getFancyTxt(false, $ignore_indicators),
				'mergefld' => $field2->getFancyTxt(false, $ignore_indicators));
			if (self::isLinkField($field2->getTag()))
				$field2->addSubField('diff',self::FIELDS_TM2ONLY);
			$newtm->appendNode($field2);
		}
		return array($newtm,$ret);
	}

	public static function isLinkField($fnum) {
		$linkFields = array(
			//'410','461','463',
			'410','419','422','421','430','431','441','434','444','440','447','451','461','463','464',
			'500',	// link to work
			'600','601','602','603','604','605','606','607','608','609','610','699',	// link to subjects/term
			'616',	// printers device as subject
			'620',	// place
			'676', '680', '686',	// class
			'700', '701', '702',	// personalname
			'710', '711', '712',	// corporatebodyname
			'716',	// printersdevice
			'720', '721', '722',	// familyname
			'792', '793',
			'921',	// printersdevice
			'931',	// subject-term
		);
		return in_array($fnum,$linkFields);
	}
}
