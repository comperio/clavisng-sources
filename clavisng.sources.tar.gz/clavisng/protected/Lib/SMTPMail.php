<?php
/**
 * Class SMTPMail
 *
 * A module for sending emails through an SMTP server.
 *
 * The actual version bases upon PEAR::Mail with 'smtp' backend; therefore you'll
 * need at least two PEAR packages installed:
 * 	- Mail
 *  - Net::SMTP
 *
 * Example of use:
 * => in your application.xml:
 * ===
 * <module id="mail" class="SMTPMail" Host="your.mailserver.it"
 *			Auth="true" Username="an.user.of.mailserver.it" Password="TheGreatSecret"
 *			Localhost="host.your.mailserver.it" AlwaysBcc="big.brother@1984.com" />
 * ===
 * => in your PHP code:
 * ===
 * 		$m = $this->Application->getModule('mail');
 *		$m->setFrom('Ciro <ciro@winged.it>');
 *		$m->setTo('Ciro Mattia Gonano <cmgonano@e-portaltech.it>, Another User <another.user@e-portaltech.it>');
 * 		$m->setCc('The Phantom <thephantom@e-portaltech.it>');
 *		$m->setSubject('This is not a mail');
 *		$m->setBody('Hooray!');
 *		$m->send();
 * ===
 *
 * TODO:
 *  - it should be nice to have TLS support, and maybe an integrated mail client
 * 		(to not rely always on PEAR::Mail)
 *
 * @author Ciro Mattia Gonano <cmgonano@e-portaltech.it>
 * @link http://www.e-portaltech.it/
 * @copyright Copyright &copy; 2007 Ciro Mattia Gonano
 * @version 2.7
 * @license MIT (http://www.opensource.org/licenses/mit-license.html)
 *
 * Copyright (c) 2007 Ciro Mattia Gonano
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

require_once('Mail.php');
require_once('Mail/RFC822.php');

class SMTPMail extends TModule {

	private $_params = array();
	private $_headers = array();
	private $_alwaysBcc = '';
	private $_from = '';
	private $_to;
	private $_cc;
	private $_bcc;
	private $_subject;
	private $_body;

	public function init($config) {
		parent::init($config);
		$this->resetMail();
	}

	private function resetMail() {
		$this->_to = '';
		$this->_cc = '';
		$this->_bcc = '';
		$this->_subject = '';
		$this->_body = '';
	}
	/**
	 * Sends the email.
	 * On successful sending, clean all mail fields but 'From'.
	 *
	 * @throws Exception if no recipients are set.
	 * @throws Exception on error connecting to SMTP server.
	 * @throws Exception on error on mail sending.
	 */
	public function send() {
		$recipients = array();
		if ($this->_to)
			$recipients[] = $this->_to;
		if ($this->_cc)
			$recipients[] = $this->_cc;
		if ($this->_bcc)
			$recipients[] = $this->_bcc;
		if ($this->_alwaysBcc)
			$recipients[] = $this->_alwaysBcc;
		if (count($recipients)<1) {
			throw new Exception('No recipients set',1);
		} else {
			$rcpt = implode(',',$recipients);
		}
		$mailFactory = Mail::factory('smtp',$this->_params);
		if (PEAR::isError($mailFactory)) {
			throw new Exception($mailFactory->getMessage(),$mailFactory->getCode());
		}
		if (!isset($this->_headers['Content-type']))
			$this->_headers['Content-type'] = 'text/plain; charset=utf-8';
		if ($this->_from)
			$this->_headers['From'] = $this->_from;
		if ($this->_to)
			$this->_headers['To'] = $this->_to;
		if ($this->_cc)
			$this->_headers['Cc'] = $this->_cc;
		if ($this->_subject)
			$this->_headers['Subject'] = $this->_subject;
		$res = $mailFactory->send($rcpt,$this->_headers,$this->_body);
		if (PEAR::isError($res)) {
			throw new Exception('Failed to send mail: '.$res->getMessage(),$res->getCode());
		}
		$this->resetMail();
	}

	private function validateAddress($address) {
		return !PEAR::isError(Mail_RFC822::parseAddressList($address));
	}

	public function validateEmailAddress($address)
	{
        return preg_match("/^\\w+([-+.]\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*\$/", $address);
	}

	/**
	 * Sets the SMTP server address.
	 *
	 * @param string $value The address of server to connect. Default is localhost.
	 */
	public function setHost($value) {
		$this->_params['host'] = $value;
	}
	/**
	 * Returns the STMP server address.
	 *
	 * @return string The address of server to connect.
	 */
	public function getHost() {
		return $this->_params['host'];
	}
	/**
	 * Sets the SMTP server's port to connect.
	 *
	 * @param integer $value The SMTP server port. Defaults to 25.
	 */
	public function setPort($value) {
		$this->_params['port'] = TPropertyValue::ensureInteger($value);
	}
	/**
	 * Returns the SMTP server port.
	 *
	 * @return integer The SMTP server port.
	 */
	public function getPort() {
		return $this->_params['port'];
	}
	/**
	 * Whether or not to use SMTP authentication.
	 *
	 * @param boolean $value Whether or not to use SMTP authentication. Default is false.
	 */
	public function setAuth($value) {
		$this->_params['auth'] = TPropertyValue::ensureBoolean($value);
	}
	/**
	 * Returns wether or not to use SMTP authentication.
	 *
	 * @return boolean Whether or not to use SMTP authentication.
	 */
	public function getAuth() {
		return $this->_params['auth'];
	}
	/**
	 * Sets the username to use for SMTP authentication.
	 *
	 * @param string $value The username to use for SMTP authentication.
	 */
	public function setUsername($value) {
		$this->_params['username'] = $value;
	}
	/**
	 * Returns the username to use for SMTP authentication.
	 *
	 * @return string The username to use for SMTP authentication.
	 */
	public function getUsername() {
		return $this->_params['username'];
	}
	/**
	 * Sets the password to use for SMTP authentication.
	 *
	 * @param string $value The password to use for SMTP authentication.
	 */
	public function setPassword($value) {
		$this->_params['password'] = $value;
	}
	/**
	 * Returns the password to use for SMTP authentication.
	 *
	 * @return string The password to use for SMTP authentication.
	 */
	public function getPassword() {
		return $this->_params['password'];
	}
	/**
	 * Sets the value to give when sending EHLO or HELO.
	 *
	 * @param string $value The value to give when sending EHLO or HELO. Defaults to localhost.
	 */
	public function setLocalhost($value) {
		$this->_params['localhost'] = $value;
	}
	/**
	 * Returns the value to give when sending EHLO or HELO.
	 *
	 * @return string The value to give when sending EHLO or HELO.
	 */
	public function getLocalhost() {
		return $this->_params['localhost'];
	}
	/**
	 * Sets the SMTP connection timeout.
	 *
	 * @param integer $value The SMTP connection timeout. Defaults to NULL (no timeout).
	 */
	public function setTimeout($value) {
		$this->_params['timeout'] = ($value==null)?null:TPropertyValue::ensureInteger($value);
	}
	/**
	 * Returns the SMTP connection timeout.
	 *
	 * @return integer The SMTP connection timeout.
	 */
	public function getTimeout() {
		return $this->_params['timeout'];
	}
	/**
	 * Sets whether to use VERP or not.
	 *
	 * @param boolean $value Whether to use VERP or not. Default is false.
	 */
	public function setVerp($value) {
		$this->_params['verp'] = TPropertyValue::ensureBoolean($value);
	}
	/**
	 * Returns whether to use VERP or not.
	 *
	 * @return boolean Whether to use VERP or not.
	 */
	public function getVerp() {
		return $this->_params['verp'];
	}
	/**
	 * Sets whether to enable SMTP debug mode or not.
	 *
	 * @param boolean $value Whether to enable SMTP debug mode or not. Default is false.
	 */
	public function setDebug($value) {
		$this->_params['debug'] = TPropertyValue::ensureBoolean($value);
	}
	/**
	 * Returns whether to enable SMTP debug mode or not.
	 *
	 * @return boolean Whether to enable SMTP debug mode or not.
	 */
	public function getDebug() {
		return $this->_params['debug'];

	}
	/**
	 * Indicates whether or not the SMTP connection should persist over multiple calls to the send() method.
	 *
	 * @param boolean $value Whether or not the SMTP connection should persist. Defaults to false.
	 */
	public function setPersist($value) {
		$this->_params['persist'] = TPropertyValue::ensureBoolean($value);
	}
	/**
	 * Returns whether or not the SMTP connection should persist over multiple calls to the send() method.
	 *
	 * @return boolean Whether or not the SMTP connection should persist.
	 */
	public function getPersist() {
		return $this->_params['persist'];
	}
	/**
	 * Sets the addresses to always Bcc to.
	 * The input should be a comma-separated list of addresses in the form:
	 * - user@domain.com
	 * - Firstname Lastname <user@domain.com>
	 *
	 * (e.g.: "An User <an.user@example.com>, Another User <another.user@example.com>, third.user@example.com").
	 *
	 * @param string $value The addresses list to always Bcc to.
	 */
	public function setAlwaysBcc($value) {
		if (!$this->_alwaysBcc && (self::validateAddress(TPropertyValue::ensureString($value))))
			$this->_alwaysBcc = TPropertyValue::ensureString($value);
	}
	/**
	 * Returns the addresses to always Bcc to.
	 *
	 * @return string The the addresses to always Bcc to.
	 */
	public function getAlwaysBcc() {
		return $this->_alwaysBcc;
	}

	/**
	 * Sets custom headers for email.
	 *
	 * @param array $value An array of mail headers, in the form of array('HeaderName'=>'HeaderValue').
	 */
	public function setHeaders($value) {
		$this->_headers = TPropertyValue::ensureArray($value);
	}
	/**
	 * Returns the custom headers for email.
	 *
	 * @return array The mail headers array.
	 */
	public function getHeaders() {
		return $this->_headers;
	}
	/**
	 * Sets the From: mail field.
	 * The specified address should be formatted:
	 * - user@domain.com
	 * - Firstname Lastname <user@domain.com>
	 *
	 * @param string $value The From: address.
	 */
	public function setFrom($value) {
		$this->_from = TPropertyValue::ensureString($value);
	}
	/**
	 * Returns the From: mail field.
	 *
	 * @return string The From: mail field.
	 */
	public function getFrom() {
		return $this->_from;
	}
	/**
	 * Sets the email To: field.
	 * The input should be a comma-separated list of addresses in the form:
	 * - user@domain.com
	 * - Firstname Lastname <user@domain.com>
	 *
	 * (e.g.: "An User <an.user@example.com>, Another User <another.user@example.com>, third.user@example.com").
	 *
	 * @param string $value The To: address list.
	 */
	public function setTo($value) {
		$this->_to = TPropertyValue::ensureString($value);
	}
	/**
	 * Returns the To: email field.
	 *
	 * @return string The email To: field.
	 */
	public function getTo() {
		return $this->_to;
	}
	/**
	 * Sets the email Cc: field.
	 * The input should be a comma-separated list of addresses in the form:
	 * - user@domain.com
	 * - Firstname Lastname <user@domain.com>
	 *
	 * (e.g.: "An User <an.user@example.com>, Another User <another.user@example.com>, third.user@example.com").
	 *
	 * @param string $value The Cc: address list.
	 */
	public function setCc($value) {
		$this->_cc = TPropertyValue::ensureString($value);
	}
	/**
	 * Returns the Cc: email field.
	 *
	 * @return string The email Cc: field.
	 */
	public function getCc() {
		return $this->_cc;
	}
	/**
	 * Sets the email Bcc: field.
	 * The input should be a comma-separated list of addresses in the form:
	 * - user@domain.com
	 * - Firstname Lastname <user@domain.com>
	 *
	 * (e.g.: "An User <an.user@example.com>, Another User <another.user@example.com>, third.user@example.com").
	 *
	 * @param string $value The Bcc: address list.
	 */
	public function setBcc($value) {
		$this->_bcc = TPropertyValue::ensureString($value);
	}
	/**
	 * Returns the Bcc: email field.
	 *
	 * @return string The email Bcc: field.
	 */
	public function getBcc() {
		return $this->_bcc;
	}
	/**
	 * Sets the email subject.
	 *
	 * @param string $value The email subject.
	 */
	public function setSubject($value) {
		$this->_subject = TPropertyValue::ensureString($value);
	}
	/**
	 * Returns the email subject.
	 *
	 * @return string The email subject.
	 */
	public function getSubject() {
		return $this->_subject;
	}
	/**
	 * Sets email body
	 *
	 * @param string $value The email body.
	 */
	public function setBody($value) {
		$this->_body = $value;
	}
	/**
	 * Returns the email body.
	 *
	 * @return string The email body.
	 */
	public function getBody() {
		return $this->_body;
	}
}

?>