<?php
/**
 * AuthTService class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info
 * @comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package Modules.Authentication
 */

/**
 * Include classes to be used by page service
 */
Prado::using('System.TService');

/**
 * AuthTService class.
 *
 * AuthTService extends base {@link TService} adding authentication (as {@link TPageService} does).
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Modules.Authentication
 * @since 2.5.1
 */
class AuthTService extends TService
{
	/**
	 * Configuration file name
	 */
	const CONFIG_FILE_XML='config.xml';
	/**
	 * Configuration file name
	 */
	const CONFIG_FILE_PHP='config.php';
	/**
	 * Prefix of ID used for storing parsed configuration in cache
	 */
	const CONFIG_CACHE_PREFIX='prado:authservice:';
	/**
	 * @var array list of initial page property values
	 */
	private $_properties=array();
	/**
	 * @var boolean whether service is initialized
	 */
	private $_initialized=false;

	/**
	 * Initializes the service.
	 * This method is required by IService interface and is invoked by application.
	 * @param TXmlElement service configuration
	 */
	public function init($config)
	{
		$serviceConfig=$this->loadServiceConfig($config);
		$this->initServiceContext($serviceConfig);
		$this->_initialized=true;
	}

	/**
	 * Initializes context.
	 * @param AuthTConfiguration
	 */
	protected function initServiceContext($serviceConfig)
	{
		$this->applyConfiguration($serviceConfig);
	}

	/**
	 * Applies a page configuration.
	 * @param TPageConfiguration the configuration
	 */
	protected function applyConfiguration($config)
	{
		$this->getApplication()->getAuthorizationRules()->mergeWith($config->getRules());
	}

	/**
	 * Collects configuration for service.
	 * @param TXmlElement additional configuration specified in the application configuration
	 * @return TConfiguration
	 */
	protected function loadServiceConfig($config)
	{
		$application=$this->getApplication();
		if(($cache=$application->getCache())===null)
		{
			$serviceConfig=new AuthTConfiguration();
			if($config!==null)
			{
				if($application->getConfigurationType()==TApplication::CONFIG_TYPE_PHP)
					$serviceConfig->loadPageConfigurationFromPhp($config,$application->getBasePath(),'');
				else
					$serviceConfig->loadPageConfigurationFromXml($config,$application->getBasePath(),'');
			}
			$serviceConfig->loadFromFiles($this->getBasePath());
		}
		else
		{
			$configCached=true;
			$currentTimestamp=array();
			$arr=$cache->get(self::CONFIG_CACHE_PREFIX.$this->getID());
			if(is_array($arr))
			{
				list($serviceConfig,$timestamps)=$arr;
				if($application->getMode()!==TApplicationMode::Performance)
				{
					foreach($timestamps as $fileName=>$timestamp)
					{
						if($fileName===0) // application config file
						{
							$appConfigFile=$application->getConfigurationFile();
							$currentTimestamp[0]=$appConfigFile===null?0:@filemtime($appConfigFile);
							if($currentTimestamp[0]>$timestamp || ($timestamp>0 && !$currentTimestamp[0]))
								$configCached=false;
						}
						else
						{
							$currentTimestamp[$fileName]=@filemtime($fileName);
							if($currentTimestamp[$fileName]>$timestamp || ($timestamp>0 && !$currentTimestamp[$fileName]))
								$configCached=false;
						}
					}
				}
			}
			else
			{
				$configCached=false;
				$appConfigFile=$application->getConfigurationFile();
				$currentTimestamp[0]=$appConfigFile===null?0:@filemtime($appConfigFile);
			}
			if(!$configCached)
			{
				$serviceConfig=new AuthTConfiguration();
				if($config!==null)
				{
					if($application->getConfigurationType()==TApplication::CONFIG_TYPE_PHP)
						$serviceConfig->loadServiceConfigurationFromPhp($config);
					else
						$serviceConfig->loadServiceConfigurationFromXml($config);
				}
				$cache->set(self::CONFIG_CACHE_PREFIX.$this->getID(),array($serviceConfig,$currentTimestamp));
			}
		}
		return $serviceConfig;
	}
}


/**
 * AuthTConfiguration class
 *
 * AuthTConfiguration represents the configuration for a AuthTService.
 * Configurations along this path are merged together to be provided for the page.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @version 2.7
 * @package Modules.Authentication
 * @since 2.5.1
 */
class AuthTConfiguration extends TComponent
{
	/**
	 * @var array list of application configurations
	 */
	private $_appConfigs=array();

	/**
	 * @var TAuthorizationRuleCollection list of authorization rules
	 */
	private $_rules=array();

	/**
	 * Returns list of authorization rules.
	 * The authorization rules are aggregated (bottom-up) from configuration files
	 * along the path to the specified page.
	 * @return TAuthorizationRuleCollection collection of authorization rules
	 */
	public function getRules()
	{
		return $this->_rules;
	}

	/**
	 * Loads configuration for a page specified in a path format.
	 * @param string root path for pages
	 */
	public function loadFromFiles($basePath)
	{
		$this->_rules=new TAuthorizationRuleCollection($this->_rules);
	}

	public function loadFromPhp($config,$configPath)
	{
		$this->loadApplicationConfigurationFromPhp($config,$configPath);
		$this->loadServiceConfigurationFromPhp($config);
	}

	/**
	 * Loads a service configuration.
	 * The configuration includes information for both application
	 * and service.
	 * @param TXmlElement config xml element
	 * @param string the directory containing this configuration
	 */
	public function loadFromXml($dom,$configPath)
	{
		$this->loadApplicationConfigurationFromXml($dom,$configPath);
		$this->loadServiceConfigurationFromXml($dom);
	}
	
	public function loadApplicationConfigurationFromPhp($config,$configPath)
	{
		$appConfig=new TApplicationConfiguration;
		$appConfig->loadFromPhp($config,$configPath);
		$this->_appConfigs[]=$appConfig;
	}

	/**
	 * Loads the configuration specific for application part
	 * @param TXmlElement config xml element
	 * @param string base path corresponding to this xml element
	 */
	public function loadApplicationConfigurationFromXml($dom,$configPath)
	{
		$appConfig=new TApplicationConfiguration;
		$appConfig->loadFromXml($dom,$configPath);
		$this->_appConfigs[]=$appConfig;
	}

	public function loadServiceConfigurationFromPhp($config)
	{
		// authorization
		if(isset($config['authorization']) && is_array($config['authorization']))
		{
			$rules = array();
			foreach($config['authorization'] as $authorization)
			{
				$action = isset($authorization['action'])?$authorization['action']:'';
				$users = isset($authorization['users'])?$authorization['users']:'';
				$roles = isset($authorization['roles'])?$authorization['roles']:'';
				$verb = isset($authorization['verb'])?$authorization['verb']:'';
				$ips = isset($authorization['ips'])?$authorization['ips']:'';
				$rules[]=new TAuthorizationRule($action,$users,$roles,$verb,$ips);
			}
			$this->_rules=array_merge($rules,$this->_rules);
		}
	}

	/**
	 * Loads the configuration specific for service.
	 * @param TXmlElement config xml element
	 */
	public function loadServiceConfigurationFromXml($dom)
	{
		// authorization
		if(($authorizationNode=$dom->getElementByTagName('authorization'))!==null)
		{
			$rules=array();
			foreach($authorizationNode->getElements() as $node)
				$rules[]=new TAuthorizationRule($node->getTagName(),$node->getAttribute('users'),$node->getAttribute('roles'),$node->getAttribute('verb'),$node->getAttribute('ips'));
			$this->_rules=array_merge($rules,$this->_rules);
		}
	}
}

