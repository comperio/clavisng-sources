<?php
/**
 * 
 * @author Marco Brancalion <marco@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2009 ePortal Technologies
 * @version 2.7
 * @package Layouts
 * @since 2.0
 */
class ExitAmbrosianaLayout extends TTemplateControl
{


}
