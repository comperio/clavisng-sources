<?php
/**
 * ClavisFileService file
 *
 * ClavisFileService provides a method for retrieving a file linked to an attachment.
 * Takes the attachment id as service parameter, or <strong>cover</strong> to get
 * cover.
 * If <strong>cover</strong> is specified, you can specify either <strong>id</strong>,
 * <strong>ean</strong> or <strong>isbn</strong> to get the cover for corresponding
 * <em>Manifestation</em>, <strong>aid</strong> for the cover of an <em>Authority</em>,
 * <strong>issue_id</strong> for the cover of an <em>Issue</em>.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 */

/**
 * ClavisFileService Class
 *
 * @author Ciro Mattia Gonano <ciro@comperio.it>
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2011 Comperio srl
 * @version 2.7
 * @package Services
 * @since 2.5
 */
class ClavisFileService extends AuthTService
{
	const REMOTE_KEY = 'c24160fecc46e71ece61914511fc044f9dee40ac';

	/**
	 * Runs the service.
	 */
	public function run()
	{
		global $basePath;
	
		$filepath = '';
		$fid = $this->getRequest()->getServiceParameter();
		if ($fid == 'cover') {
			$a = $this->retrieveCover();
			if (is_string($a)) {
				$this->getResponse()->redirect($a);
				return;
			} else if (!$a instanceof Attachment) {
				$filepath = $basePath.'/themes/nocover.jpg';
				$filename = 'nocover.jpg';
				$mime_type = 'image/jpeg';
			}
		} else {
			$a = AttachmentQuery::create()->findPk($fid);
		}
                
                
                if (extension_loaded('newrelic')) {
                    newrelic_set_appname ("ClavisNG - " . $this->getApplication()->getID());
                    newrelic_name_transaction("FILESERVICE." . __METHOD__);
                    newrelic_add_custom_parameter('SERVPARAM', $fid );
                }
                
		
		if ($a instanceof Attachment) {
			$filepath = $a->getRealFilePath();
			$filename = $a->getFileName();
			$mime_type = $a->getMimeType();
			if (!$mime_type) {
				$mime = Clavis::mime_content_type($filepath);
				$a->setMimeType($mime)
					->save();
			}
		}

		$resp = Prado::getApplication()->getResponse();
		$resp->clear();
		$resp->setCacheControl('nocache');
		if (!$filepath || !file_exists($filepath)) {
			Prado::log(__CLASS__.": file not found [{$filepath}]",TLogger::WARNING,'FileService');
			$resp->write("File not found: {$filepath}");
			Prado::getApplication()->completeRequest();
			return;
		} else {
			$resp->writeFile($filename,
				file_get_contents($filepath),
				$mime_type,
				array('Content-type: '.$mime_type),
				false);
			die();
			//Prado::getApplication()->completeRequest();
		}
	}
	
	private function retrieveCover() {
		$req = $this->getRequest();

		if ($object_id = $req->itemAt('id')) {
			$object_type = 'Manifestation';
		} else if ($ean = $req->itemAt('ean') || $isbn = $req->itemAt('isbn')) {
			if (!$ean)
				$ean = $isbn;
			$m = ManifestationQuery::create()->findOneByEan($ean);
			if (! $m instanceof Manifestation)
				$m = ManifestationQuery::create()->findOneByIsbnissn(Clavis::Ean13ToIsbn($ean));
			if ($m instanceof Manifestation) {
				$object_id = $m->getManifestationId();
				$object_type = 'Manifestation';
			}
		} else if ($object_id = $req->itemAt('aid')) {
			$object_type = 'Authority';
		} else if ($object_id = $req->itemAt('issue_id')) {
			$object_type = 'Issue';
		}
		if (!$object_id)
			return null;

		$attachment = AttachmentQuery::create()
			->filterByAttachmentType(AttachmentPeer::TYPE_COVER)
			->filterByObjectType($object_type)
			->filterByObjectId($object_id)
			->orderByAttachmentId()
			->findOne();
		if ($attachment instanceof Attachment)
			return $attachment;
		// if we don't find a cover file, check in remote server, if there's one.
		$coverserver = ClavisParamQuery::getParam('CLAVISPARAM','RemoteCoverServer');
		if ($object_type == 'Manifestation' && $coverserver) {
			$m = ManifestationQuery::create()->findPk($object_id);
			if ($m instanceof Manifestation) {
				$ean = $m->getEan();
				if (!$ean)
					if ($isbn = $m->getIsbnissn())
						$ean = Clavis::IsbnToEan13($isbn);
				if ($ean) {
					$ean = urlencode($ean);
					try {
						if (file_get_contents("{$coverserver}/getcover.php?key=".self::REMOTE_KEY."&ean={$ean}&act=check") == 'OK')
							return "{$coverserver}/getcover.php?key=".self::REMOTE_KEY."&ean={$ean}&act=get";
					} catch (TPhpErrorException $e) {
						// connection error, return null
						return null;
					}
				}
			}
		}
		return null;
	}

}
