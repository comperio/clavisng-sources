<?php
/**
 * ClavisLibrarianTraceBehavior class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package propel
 */

/**
 * ClavisLibrarianTraceBehavior class
 *
 * @version 2.7
 * @package propel
 * @since 2.5.0
 */
class ClavisLibrarianTraceBehavior extends Behavior
{
	// default parameters value
	protected $parameters = array(
		'add_columns'   => 'true',
		'create_column' => 'created_by',
		'update_column' => 'modified_by'
	);

	/**
	 * Add the create_column and update_columns to the current table
	 */
	public function modifyTable()
	{
		$table = $this->getTable();
		$createColumn = $this->getParameter('create_column');
		$updateColumn = $this->getParameter('update_column');

		if(!$table->hasColumn($createColumn)) {
			$this->getTable()->addColumn(array(
				'name' => $createColumn,
				'type' => 'INTEGER'
			));
		}
		if(!$this->getTable()->hasColumn($updateColumn)) {
			$this->getTable()->addColumn(array(
				'name' => $updateColumn,
				'type' => 'INTEGER'
			));
		}
	}

	/**
	 * Get the setter of one of the columns of the behavior
	 *
	 * @param  string $column One of the behavior colums, 'create_column' or 'update_column'
	 * @return string The related setter, 'setCreatedBy' or 'setModifiedBy'
	 */
	protected function getColumnSetter($column)
	{
		return 'set' . $this->getColumnForParameter($column)->getPhpName();
	}

	/**
	 * Add code in ObjectBuilder::preUpdate
	 *
	 * @return    string The code to put at the hook
	 */
	public function preUpdate()
	{
		return "if (\$this->isModified() && !\$this->isColumnModified(" . $this->getColumnForParameter('update_column')->getConstantName() . ")) {
	\$this->" . $this->getColumnSetter('update_column') .
				"((class_exists('Prado') && (Prado::getApplication() instanceof TApplication) && (\$u = Prado::getApplication()->getUser()) instanceof ClavisLibrarian && \$u->getId() > 0) ? \$u->getId() : 1 );
}";
	}

	/**
	 * Add code in ObjectBuilder::preInsert
	 *
	 * @return    string The code to put at the hook
	 */
	public function preInsert()
	{
		return "\$librarianId = (class_exists('Prado') && (Prado::getApplication() instanceof TApplication) && (\$u = Prado::getApplication()->getUser()) instanceof ClavisLibrarian && \$u->getId() > 0) ? \$u->getId() : 1 ;
if (!\$this->isColumnModified(" . $this->getColumnForParameter('create_column')->getConstantName() . ")) {
	\$this->" . $this->getColumnSetter('create_column') . "(\$librarianId);
}
if (!\$this->isColumnModified(" . $this->getColumnForParameter('update_column')->getConstantName() . ")) {
	\$this->" . $this->getColumnSetter('update_column') . "(\$librarianId);
}";
	}

	public function objectMethods($builder)
	{
		return "
/**
 * Returns the complete name of the librarian that created this object.
 *
 * @return string
 */
public function getCreatedByNameString()
{
	\$l = \$this->getLibrarianRelatedBy" . $this->getColumnForParameter('create_column')->getPhpName() . "();
	return (\$l instanceof Librarian) ? \$l->getCompleteName() : '';
}

/**
 * Returns the complete name of the librarian that last updated this object.
 *
 * @return string
 */
public function getModifiedByNameString()
{
	\$l = \$this->getLibrarianRelatedBy" . $this->getColumnForParameter('update_column')->getPhpName() . "();
	return (\$l instanceof Librarian) ? \$l->getCompleteName() : '';
}

/**
 * Mark the current object so that the update date doesn't get updated during next save
 *
 * @return     " . $builder->getStubObjectBuilder()->getClassname() . " The current object (for fluent API support)
 */
public function keepUpdateLibrarianUnchanged()
{
	\$this->modifiedColumns[] = " . $this->getColumnForParameter('update_column')->getConstantName() . ";
	return \$this;
}
";
	}




}
