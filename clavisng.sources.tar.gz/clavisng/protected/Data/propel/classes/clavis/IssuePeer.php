<?php
/**
 * IssuePeer class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info
 * @comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package propel.generator.clavis
 */
require_once 'clavis/om/BaseIssuePeer.php';
include_once 'clavis/Issue.php';

/**
 * IssuePeer Class
 *
 * @version 2.7
 * @package propel.generator.clavis
 * @since 2.0
 */
class IssuePeer extends BaseIssuePeer {

	const TYPE_NORMAL = 'N';
	const TYPE_SUPPLEMENT = 'T';
	const TYPE_WITHSUPPLEMENT = 'S';

	static $period = array(	'a' => 1,
							'b' => 3,
							'c' => 7,
							'd' => 15,
							'e' => 15,
							'f' => 30,
							'g' => 60,
							'h' => 90,
							'i' => 120,
							'j' => 180,
							'k' => 365,
							'l' => 730,
							'm' => 1095,
							'n' => 2,
							'o' => 10,
							'p' => 0,
							'u' => 0,
							'y' => 0,
							'z' => 0);

	private static function days_in_month($month,$year)
	{
		return $month == 2
					? ($year % 4 
							? 28
							: ($year % 100
									? 29
									: ($year % 400
											? 28
											: 29)))
					: (($month - 1) % 7 % 2
							? 30
							: 31);
	}
	
	public static function getIssueVolumeDates($frequency,$startDate,$endDate)
	{
		if (in_array($frequency,array('u','y')))
			return array();
		
		//$y = date('Y',$startDate);
		$curDate = $startDate;
		
		$dates = array();
		switch ($frequency) 
		{
			case 'd':
			case 'e':	// 15 gg
				do 
				{
					$m = date('m', $curDate);
					$Y = date('Y', $curDate);
					$daysN = self::days_in_month($m, $Y);

					$dates[] = mktime(0, 0, 0, $m, 15, $Y);
					$dates[] = mktime(0, 0, 0, $m, $daysN, $Y);
				} 
				while (($curDate = mktime(0, 0, 0, $m + 1, 1, $Y)) < $endDate);
				
				break;
				
			case 'f':	// 30 gg, monthly
				do 
				{
					$m = date('m',$curDate);
					$Y = date('Y', $curDate);
					$daysN = self::days_in_month($m, $Y);

					$dates[] = mktime(0, 0, 0, $m, $daysN, $Y);
				}
				while (($curDate = mktime(0, 0, 0, $m + 1, 1, $Y)) < $endDate);
				
				break;
				
			case 'g':	// 2 mm
				do 
				{
					$m = date('m',$curDate);
					$Y = date('Y', $curDate);
					$daysN = self::days_in_month($m, $Y);
					
					$dates[] = mktime(0, 0, 0, $m, $daysN, $Y);
				}
				while (($curDate = mktime(0, 0, 0, $m + 2, 1, $Y)) < $endDate);
				
				break;
				
			case 'h':	// 3 mm
				do 
				{
					$m = date('m',$curDate);
					$Y = date('Y', $curDate);
					$daysN = self::days_in_month($m, $Y);
					
					$dates[] = mktime(0, 0, 0, $m, $daysN, $Y);
				} 
				while (($curDate = mktime(0, 0, 0, $m + 3, 1, $Y)) < $endDate);
				
				break;
			
			case 'i':	// 4m
				do 
				{
					$m = date('m',$curDate);
					$Y = date('Y', $curDate);
					$daysN = self::days_in_month($m, $Y);
					
					$dates[] = mktime(0, 0, 0, $m, $daysN, $Y);
				} 
				while (($curDate = mktime(0, 0, 0, $m + 4, 1, $Y)) < $endDate);
				
				break;
				
			case 'j':	// 6m
				do 
				{
					$m = date('m',$curDate);
					$Y = date('Y', $curDate);
					$daysN = self::days_in_month($m, $Y);
					
					$dates[] = mktime(0, 0, 0, $m, $daysN, $Y);
				} 
				while (($curDate = mktime(0, 0, 0, $m + 6, 1, $Y)) < $endDate);
				
				break;
				
			case 'k':	// 1 year
				do 
				{
					$Y = date('Y', $curDate);
					
					$dates[] = mktime(0 ,0, 0, 12, 31, $Y);
				} 
				while (($curDate = mktime(0, 0, 0, 1, 1, $Y + 1)) < $endDate);
				
				break;
				
			default:
				break;
		}

		return $dates;
	}
	
	public static function getNavigateUrl()
	{
		return 'index.php?page=Catalog.IssueViewPage&id=';
	}

	/**
	 * It duplicates issues from a source year, starting at a given  start number
	 *
	 * @param Manifestation $manifestation :
	 * @param int $sourceYear : the year to be cloned
	 * @param int $newYear : new year for destination copies
	 * @param int $startNumber : starting number
	 * @param ClavisLibrarian $clavisLibrarian : clavis user doing the action (for logging)
	 * @return boolean false if error or num of duplicated issues
	 */
	public static function duplicateVolume(	Manifestation $manifestation,
												$sourceYear,
												$newYear,
												$startNumber,
												$clavisLibrarian = null)
	{
		if(!is_numeric($sourceYear)
				|| !is_numeric($newYear)
				|| (!is_null($clavisLibrarian) && !$clavisLibrarian instanceof ClavisLibrarian))
			return false;

		//1) copia tanti fascicoli quanti sono quelli di una certa annata (usando la copy() di Propel) e poi incrementa l'annata
		$_connection = Propel::getConnection();
		try
		{
			$issues = IssueQuery::create()
						->filterByManifestation($manifestation)
						->filterByIssueYear($sourceYear)
						->find();
		
			$num_counter = $startNumber;
			foreach ($issues as $issue)
			{
				$issue_id = $issue->getIssueId();
				$issueCloned = $issue->copy(false);
				$issueCloned->setIssueYear($newYear);
				$issueCloned->setIssueNote(null);
				if($num_counter != '')
				{
					$issueCloned->setStartNumber($num_counter);
					$issueCloned->setEndNumber($num_counter);
					$issueCloned->setIssueNumber($num_counter);
					$num_counter++;
				}
				
				/* @var $issueCloned Issue */
				$date = $issueCloned->getIssueDate(null);
				$date->add(new DateInterval('P1Y')); // one year
				$issueCloned->setIssueDate($date);
				$issueCloned->save();
				ChangelogPeer::logAction(	$issueCloned,
											ChangelogPeer::LOG_CREATE,
											$clavisLibrarian,
											"copia da issue_id: $issue_id");
			}
			
			return count($issues);
		} 
		catch (PropelException $e)
		{
			$_connection->rollback();
			Prado::log('Error in '.__CLASS__.'::'.__FUNCTION__.'(): .'.$e);
		
			return false;
		}
	}

	/**
	 * It creates issues from some given parameters
	 *
	 * @param Manifestation $manifestation :
	 * @param int $Year : the year of the new issues
	 * @param int $howManyIssues : how many issues to be created
	 * @param int $startNumber : starting number
	 * @param ClavisLibrarian $clavisLibrarian : clavis user doing the action (for logging)
	 * @param int (timestamp) $startTime
	 * @param int (timestamp) $endTime
	 * @param ClavisLibrarian $clavisLibrarian : clavis user doing the action (for logging)
	 *
	 * @return boolean false if error or num of created issues
	 */
	public static function createForManifestation(	Manifestation $manifestation,
														$year,
														$howManyIssues,
														$startNumber,
														$startTime,
			
														$endTime,
														$clavisLibrarian = null)
	{
		$manifestation_id = $manifestation->getManifestationId();

		if (!is_numeric($year))
			throw new Exception('Non-numeric year');

		if (!is_numeric($howManyIssues))
			throw new Exception('Invalid number of issues');

		if (!is_numeric($startNumber))
			throw new Exception('Invalid start number');

		if (!is_numeric($startTime))
			throw new Exception('Start timestamp is not valid');

		if (!is_numeric($endTime))
			throw new Exception('End timestamp is not valid');

		if (!is_null($clavisLibrarian))
			if (! $clavisLibrarian instanceof ClavisLibrarian)
				throw new Exception('Librarian is not a ClavisLibrarian');

		$_connection = Propel::getConnection();

		try
		{
			$countCreated = 0;
			$interval = ($endTime - $startTime) / $howManyIssues;
			$issueTime = $startTime;
			$issueNumber = $startNumber;

			for($i=0; $i<$howManyIssues; ++$i)
			{
				$issue = new Issue();
				$issue->setManifestationId($manifestation_id);
				$issue->setIssueYear($year);
				$issue->setStartNumber($issueNumber);
				$issue->setEndNumber($issueNumber);
				$issue->setIssueNumber($issueNumber);
				$issue->setIssueDate($issueTime);
				$issue->setIssueNote(null);
				$issue->setIssueType(IssuePeer::TYPE_NORMAL);
				$issue->save();
				ChangelogPeer::logAction($issue, ChangelogPeer::LOG_CREATE, $clavisLibrarian);
				$issueTime += $interval;
				++$issueNumber;
				++$countCreated;
			}
			
			$_connection->commit();
			
			return $countCreated;
		} 
		catch (PropelException $e)
		{
			$_connection->rollback();
			throw new Exception('Issue generation failed: '.$e->getMessage());
		}
	}
	
} // IssuePeer