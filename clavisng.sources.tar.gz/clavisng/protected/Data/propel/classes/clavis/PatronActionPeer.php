<?php
/**
 * PatronActionPeer class file
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package propel.generator.clavis
 */

/**
 * PatronActionPeer class
 *
 * @version 2.7
 * @package propel.generator.clavis
 * @since 2.6.1
 */
class PatronActionPeer extends BasePatronActionPeer
{
	const ACTION_CHECKIN = 'I';
	const ACTION_CHECKOUT = 'O';

	public static function expireAccessLogs()
	{
		$now = new DateTime('now');
		PatronQuery::create()
			->filterByCheckOut(null)
			->filterByCheckIn($now->format('Y-m-d'),Criteria::LESS_THAN)
			->find();

		/*PatronActionQuery::create()
			->filterByActionDate($now->format('Y-m-d'),Criteria::LESS_THAN)
			->update();*/

	}

	public static function patronCheckIn(Patron $patron, $library_id, $datetime=null, $key=null)
	{
		return self::patronCheck('in', $patron, $library_id, $datetime, $key);
	}

	public static function patronCheckOut(Patron $patron, $library_id, $datetime=null, $key=null)
	{
		return self::patronCheck('out', $patron, $library_id, $datetime, $key);
	}

	protected static function patronCheck($direction='in', Patron $patron, $library_id, $datetime=null, $key=null)
	{
		if (!$patron instanceof Patron)
			throw new Exception('Invalid patron');
		if (!$datetime)
			$datetime = new DateTime();
		if ('in' == $direction) {
			$patron->setCheckIn($datetime);
			//$patron->setCheckOut(null);
			$patron->setCheckLibrary($library_id);
			$type = PatronActionPeer::ACTION_CHECKIN;
		} else {
			$patron->setCheckOut($datetime);
			$type = PatronActionPeer::ACTION_CHECKOUT;
		}
		$patron->save();
		$log = new PatronAction();
		$log->setPatron($patron);
		$log->setLibraryId($library_id);
		$log->setActionType($type);
		$log->setActionDate($datetime);
		$log->setActionKey($key);
		$log->save();
		return $log;
	}

	public static function expireYesterdayChecks()
	{
		if (ClavisParamQuery::getParam('CLAVISPARAM','PatronAccessControl') != 'true')
			return;
		$patrons = PatronQuery::create()
			->filterByCheckOut(null)
			->filterByCheckIn(null, Criteria::NOT_EQUAL)
			->filterByCheckIn(mktime(0,0,0), Criteria::LESS_THAN)
			->find();
		foreach ($patrons as $p) {
			$log = self::patronCheckOut($p, 1, mktime(0,0,0)-1);
			if ($log instanceof PatronAction) {
				$log->setActionNote('Uscita automatica di fine giornata.');
				$log->save();
			}
		}
		return count($patrons);
	}
}
