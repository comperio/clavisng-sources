<?php

/**
 * LookupValue class
 *
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2011 Comperio srl
 * @version 2.7
 * @package propel.generator.clavis
 * @since 2.0
 */
require_once 'clavis/om/BaseLookupValue.php';

class LookupValue extends BaseLookupValue {

	public function preSave(PropelPDO $con = null)
	{
		$this->setSortableScope($this->getValueClass().'-'.$this->getValueLanguage());
		return true;
	}

	public function getTrimmedValueLabel($count = null)
	{
		$valueLabel = $this->getValueLabel();
		if (!is_null($count) && strlen($valueLabel) > $count)
			$valueLabel = substr($valueLabel, 0, $count - 3).'...';
		return $valueLabel;
	}

} // LookupValue
