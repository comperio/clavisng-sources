<?php

require_once 'clavis/om/BaseConsortiaPeer.php';
  
include_once 'clavis/Consortia.php';

class ConsortiaPeer extends BaseConsortiaPeer {

} // ConsortiaPeer
