<?php
/**
 * Patron class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT  OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package propel.generator.clavis
 */
require_once('clavis/om/BasePatron.php');

/**
 * Patron class
 *
 * @version 2.7
 * @package propel.generator.clavis
 * @since 2.0
 */
class Patron extends BasePatron
{
	public function getCustom1String() {
		return LookupValuePeer::classExists('PATRONCUST1')
			? LookupValuePeer::getLookupValue('PATRONCUST1', self::getCustom1())
			: self::getCustom1();
	}

	public function getCustom2String() {
		return LookupValuePeer::classExists('PATRONCUST2')
			? LookupValuePeer::getLookupValue('PATRONCUST2', self::getCustom2())
			: self::getCustom2();
	}

	public function getCustom3String() {
		return LookupValuePeer::classExists('PATRONCUST3')
			? LookupValuePeer::getLookupValue('PATRONCUST3', self::getCustom3())
			: self::getCustom3();
	}

	/**
	 * Set the value of [username] column, checking uniqueness among Librarians and Patrons.
	 *
	 * @param	string $v new value
	 * @return	Patron The current object (for fluent API support)
	 * @throws	Exception if value is duplicated.
	 */
	public function setOpacUsername($v) {
		// overrides parent checking uniqueness among patrons too.
		if (!$this->allowedUsername($v))
			throw new Exception('Username is already in use.',LibrarianPeer::EXCP_USERNAME_DUP);
		return parent::setOpacUsername($v);
	}

	/**
	 * Checks if a username is allowed (i.e. not already in use by a Librarian or a Patron).
	 *
	 * @param string $username The username to search for.
	 * @return boolean true if username is in use, false elsewhere.
	 */
	private function allowedUsername($username)
	{
		$mylibrarian = $this->getLibrarian();
		$patron = PatronQuery::create()
			->prune($this)
			->filterByOpacUsername($username);
		$librarian = LibrarianQuery::create()
			->prune($mylibrarian)
			->filterByUsername($username);
		return ($librarian->count() < 1 && $patron->count() < 1);
	}

	public function getRegistrationLibrary()
	{
		return $this->getLibraryRelatedByRegistrationLibraryId();
	}

	public function getPreferredLibrary()
	{
		return $this->getLibraryRelatedByPreferredLibraryId();
	}


	/**
	 * It returns the id of this object (for compatibility).
	 *
	 * @return int
	 */
	public function getId()
	{
		return $this->getPatronId();
	}

	/**
	 * It returns the string concatenation of the fields
	 * "name" and "lastname". If both are present, they'll be
	 * separated by a comma.
	 *
	 * @return string
	 */
	public function getCompleteName($conn = ' ')
	{
		$name = trim($this->getName() . $conn . $this->getLastname());
		$class = $this->getLoanClass();

		if (is_null($class) || ctype_alpha($class))
			$class = '';
		else
			$class = '[' . $class . ']&nbsp;';

		return $class . ((!$name) ? '(senza nome e cognome)' : $name);
	}

	public function getReverseCompleteName($conn = ' ')
	{
		$name = trim($this->getLastname() . $conn . $this->getName());
		$class = $this->getLoanClass();

		if (is_null($class) || ctype_alpha($class))
			$class = '';
		else
			$class = '[' . $class . ']&nbsp;';

		return $class . ((!$name) ? '(senza cognome e nome)' : $name);
	}

	/**
	 * It returns a simple string made by a label "Nome" +
	 * the complete name and lastname.
	 *
	 * @return string
	 */
	public function getShelfDescription()
	{
		$completeName = $this->getCompleteName();
		if ($completeName !== '')
			return Prado::localize('nome') . ': ' . $completeName;
		else
			return '';
	}

	public function getShelfDescriptionLabel()
	{
		return Prado::localize('nome: ');
	}

	public function getShelfDescriptionText()
	{
		return $this->getCompleteName();
	}

	/**
	 * It returns the Portlet.Page which will be used in the
	 * url of the grid row, to hyper-transport ourselves to the
	 * right visualization page of the object.
	 *
	 * @return string
	 */
	public function getShelfUrl()
	{
		return PatronPeer::getViewPage() . '&id=';
	}

	public function getNavigateUrl($idFillFlag = false)
	{
		if ($idFillFlag)
			$id = $this->getPatronId();
		else
			$id = 0;

		return PatronPeer::getNavigateUrl($id);
	}

	public function getUrlPage()
	{
		return $this->getShelfUrl();
	}

	public function getUrlName()
	{
		return $this->getShelfDescriptionText();
	}

	/**
	 * Returns the shelves the object is contained in (or not in).
	 *
	 * @param ClavisLibrarian $user
	 * @param SehlfQuery $baseQuery
	 * @param int|string $limit
	 * @param int $offset
	 * @param boolean $except If true, returns all shelves the object is NOT contained in.
	 * @return PropelObjectCollection|array|int|mixed
	 */
	public function getShelvesIn(ClavisLibrarian $user, ShelfQuery $baseQuery, $limit=null, $offset=null, $except = false)
	{
		if (!$baseQuery)
			$baseQuery = ShelfQuery::create();
		if ($except)
			$sideQuery = clone $baseQuery;

		$baseQuery->useShelfItemQuery()
			->filterByObjectClass(ShelfPeer::TYPE_PATRON)
			->filterByObjectId($this->patron_id)
			->endUse();

		if ($except) {
			$shelvesIds = array_keys(ShelfPeer::getVisibleShelvesArray($user, null, null, null, $baseQuery));
			$sideQuery->filterByShelfId($shelvesIds,Criteria::NOT_IN);
			$shelves = ShelfPeer::getVisibleShelves($user, null, $limit, $offset, $baseQuery);
		} else {
			$shelves = ShelfPeer::getVisibleShelves($user, null, $limit, $offset, $baseQuery);
		}
		return $shelves;
	}

	public function getPatronStatusString()
	{
		return $this->patron_status ? LookupValuePeer::getLookupValue('PATRONSTATE', $this->patron_status) : '';
	}

	public function getPatronStateIconPath()
	{
		switch (strtoupper($this->patron_status))
		{
			case PatronPeer::STATUS_ENABLED:
				$path = 'themes/Default/icons/nav_plain_green-16.png';
				break;
			case PatronPeer::STATUS_EXPIRED:
				$path = 'themes/Default/icons/nav_plain_red-16.png';
				break;
			case PatronPeer::STATUS_REVOKED:
				$path = 'themes/Default/icons/nav_plain_red-16.png';
				break;
			case PatronPeer::STATUS_DECEASED:
				$path = 'themes/Default/icons/nav_plain_red-16.png';
				break;
			case PatronPeer::STATUS_INCOMPLETE:
				$path = 'themes/Default/icons/nav_plain_yellow-16.png';
				break;
			case PatronPeer::STATUS_AUTOMATICREVOKED:
				$path = 'themes/Default/icons/nav_plain_red-16_revoked.png';
				break;
			default:
				$path = 'themes/Default/punto_trasparente.png';
				break;
		}
		return $path;
	}

	public function setAreasOfInterest($value) {
		parent::setAreasOfInterest(empty($value)?'':serialize($value));
	}
	public function getAreasOfInterest() {
		$unser = parent::getAreasOfInterest();
		return (empty($unser))?array():(array)unserialize($unser);
	}

	public function getObjectTypeString()
	{
		return Prado::localize("utente");
	}

	public function UpdateLastSeen($forceSave = false)
	{
		$this->setLastSeen(time());

		if ($forceSave == true)
			$this->save();
	}

	public function getPatronCity()
	{
		$patronCity = "";
		foreach($this->getAddresss() as $address)
		{
			if ($address->getAddressPref() == true)
			{
				$patronCity = $address->getCity();
				break;
			}
			elseif ($address->getAddressType() == 'D')
			{
				$patronCity = $address->getCity();
				break;
			}
			elseif ($address->getAddressType() == 'R')
			{
				$patronCity = $address->getCity();
				break;
			}
		}

		return $patronCity;
	}

	public function getPatronAge($now = null)
  	{
		$birthDateT = intval($this->getBirthDate('U'));
		if ($birthDateT == 0)
			return null;

		if (is_null($now))
			$nowT = time();
		elseif (is_string($now))
			$nowT = strtotime($now);

		$now = new DateTime();
		$now->setTimestamp($nowT);
		$birthDate = new DateTime();
		$birthDate->setTimestamp($birthDateT);

		$res = date_diff($now, $birthDate);
		return ($res->format('%y'));
	}

    /**
     * It gets the email address/es of the patron (from table Contacts).
     *  If one of them is marked as 'preferred', then
     * this one address is returned (as well as if there's one only
     * address available).
     * If there are multiple email address and none of them
     * is the preferred one, the whole addresses are returned.
     *
     * The return type is always an array (1 element if one only
     * address is returned.
     * If no email address is available, an empty is returned.
     *
     * @return array
     */
    public function getEmail()
    {
    	require_once('Mail/RFC822.php');
    	$criteria = new Criteria();
    	$criteria->add(ContactPeer::CONTACT_TYPE, 'E');
    	$contacts = $this->getContacts($criteria);
        $mail = new Mail_RFC822();
    	$emails = array();
		
		$PEARClass = new PEAR();
		
    	foreach ($contacts as $index => $contact)
    	{
    		$email = trim($contact->getContactValue());
    		if (!$PEARClass->isError($mail->parseAddressList($email)) && ($email != ''))
    		{
				if ($contact->getContactPref())
					return array($email);    // $email
				else
					$emails[] = $email;
    		}
    	}
    	return $emails;
    }

    public function getEmail2String($separator = ',')
    {
    	$emails = $this->getEmail();
    	if (count($emails) == 0)
    		return '';

    	$emailsString = '';
    	foreach ($emails as $email)
    	{
    		$emailsString .= $separator . $email;
    	}
    	return substr($emailsString, strlen($separator));
    }

    /**
     * It gets the phone number/s of the patron (from table Contacts).
     *
     * @return array
     */
    public function getPhone()
    {
    	$criteria = new Criteria();
    	$criteria->add(ContactPeer::CONTACT_TYPE, 'C');
    	$cellContacts = $this->getContacts($criteria);

    	$criteria->clear();
    	$criteria->add(ContactPeer::CONTACT_TYPE, 'T');
    	$homePhoneContacts = $this->getContacts($criteria);

     	$phones = array();
    	foreach ($cellContacts as $contact)
    	{
    		$num = trim($contact->getContactValue());
    		if ($num != '')
    		{
				if ($contact->getContactPref())
					return array($num);
				else
					$phones[] = $num;
    		}
    	}
    	foreach ($homePhoneContacts as $contact)
    	{
    		$num = trim($contact->getContactValue());
    		if ($num != '')
    		{
				if ($contact->getContactPref())
					return array($num);
				else
					$phones[] = $num;
    		}
    	}

    	return $phones;
    }

    public function getPhone2String()
    {
    	$phonesString = '';
    	foreach ($this->getPhone() as $phone)
    		$phonesString .= $phone . ' - ';

    	if ($phonesString != '')
    		$phonesString = rtrim($phonesString, ' - ');
    	return $phonesString;
    }

	public function getPreferredContacts($includeType = false)
    {
    	$criteria = new Criteria();
    	$criteria->add(ContactPeer::CONTACT_TYPE, array('C', 'E', 'T'), Criteria::IN);
    	$criteria->addAscendingOrderByColumn(ContactPeer::CONTACT_TYPE);
    	$contactsResult = $this->getContacts($criteria);

     	$contacts = array();
    	foreach ($contactsResult as $contact)
    	{
    		$value = trim($contact->getContactValue());
    		if ($value != '')
    		{
				if ($includeType)
					$value = LookupValuePeer::getLookupValue('CONTACTTYPE', $contact->getContactType()) . ": " . $value;

    			$note = trim($contact->getContactNote());
    			if ($note != '')
    				$value .= ' (' . $note . ')';
				if ($contact->getContactPref())
					return array($value);
				else
					$contacts[] = $value;
    		}
    	}

		return $contacts;
	}

	public function getPreferredAddressArray()
    {
    	$output =	array(	'street' => '',
							'city' => '',
							'onlycity' => '',
							'country' => '',
							'zip' => '',
							'province' => '');

    	$criteria = new Criteria();

		$criteria->add(AddressPeer::ADDRESS_PREF, 1);
		$preferredAddressCount = $this->countAddresss($criteria);

		if ($preferredAddressCount == 0)
		{
			$criteria->clear();
			$criteria->add(AddressPeer::ADDRESS_TYPE, 'R');
			$criteria->addOr(AddressPeer::ADDRESS_TYPE, 'D');
			$criteria->addDescendingOrderByColumn(AddressPeer::ADDRESS_TYPE);
		}
		$addresses = $this->getAddresss($criteria);

		if (count($addresses) > 0)
		{
			$address = $addresses[0];

			$streetType = trim(LookupValuePeer::getLookupValue('STREET', $address->getStreetType()));
			if ($streetType == '')
				$streetType = LookupValuePeer::getLookupValue('STREET', 'V1');

			if ($streetType != '')
				$streetType .= ' ';
			$street = trim($address->getStreet());
			$streetNum = trim($address->getStreetNum());
			if ($streetNum != '')
				$streetNum = ', ' . $streetNum;
			$completeStreet = $streetType . $street . $streetNum;

			$zip = trim($address->getZip());
			if ($zip != '')
				$zip .= ' ';
			$city = trim($address->getCity());
			$province = trim($address->getProvince());
			if ($province != '')
				$bracketprovince = ' (' . $province . ')';
			else
				$bracketprovince = '';
			$completeCity = $zip . $city . $bracketprovince;

			$country = trim($address->getCountry());
			$zip = trim($address->getZip());

			$output['street'] = $completeStreet;
			$output['city'] = $completeCity;
			$output['onlycity'] = $city;
			$output['country'] = $country;
			$output['zip'] = $zip;
			$output['province'] = $province;
		}

		return $output;
    }

	public function getPreferredAddressString()
	{
		$addressArray = $this->getPreferredAddressArray();

		$street = $addressArray['street'];
		if ($street != '')
			$street .= "\n";
		$city = $addressArray['city'];
		if ($city != '')
			$city .= "\n";
		$country = $addressArray['country'];

		return $street . $city . $country;
	}

    /**
     * Changes the patron password.
     *
     * @param string $newpassword The new password
     * @param int $modifiedBy The operator ID (defaults to 1)
     */
    public function changePassword($newpassword,$modifiedBy=1) {
    	throw new Exception('Deprecated function. Use ClavisCrypt module.');
    }

    /**
	 * If this collection has already been initialized with
	 * an identical criteria, it returns the collection.
	 * Otherwise if this Patron has previously
	 * been saved, it will retrieve related Addresss from storage.
	 * If this Patron is new, it will return
	 * an empty collection or the current collection, the criteria
	 * is ignored on a new object.
	 *
	 * Override of BasePatron::getAddresss() with default ordering for
	 * recordset
	 *
	 * @param Connection $con
	 * @param Criteria $criteria
	 * @throws PropelException
	 */
	public function getAddresss($criteria = null, PropelPDO $con = null) {
		if (is_null($criteria)) {
			$criteria = new Criteria();
			$criteria->addAscendingOrderByColumn(AddressPeer::ADDRESS_ID);
		}
		return parent::getAddresss($criteria, $con);
	}

	/**
	 * If this collection has already been initialized with
	 * an identical criteria, it returns the collection.
	 * Otherwise if this Patron has previously
	 * been saved, it will retrieve related Addresss from storage.
	 * If this Patron is new, it will return
	 * an empty collection or the current collection, the criteria
	 * is ignored on a new object.
	 *
	 * Override of BasePatron::getContacts() with default ordering for
	 * recordset
	 *
	 * @param Connection $con
	 * @param Criteria $criteria
	 * @throws PropelException
	 */
	public function getContacts($criteria = null, PropelPDO $con = null) {
		if (is_null($criteria)) {
			$criteria = new Criteria();
			$criteria->addAscendingOrderByColumn(ContactPeer::CONTACT_ID);
		}
		return parent::getContacts($criteria, $con);
	}

	public function getPhotoFileId()
	{
		$photo = AttachmentQuery::create()
			->filterByObjectType('Patron')
			->filterByObjectId($this->patron_id)
			->filterByAttachmentType(AttachmentPeer::TYPE_PHOTO)
			->findOne();
		return ($photo instanceof Attachment) ? $photo->getAttachmentId() : '';
	}

	public function reload($deep = false, PropelPDO $con = null)
	{
		if (!$this->isNew())
			parent::reload ($deep, $con);
	}

	/**
	 * Get the associated Librarian object
	 *
	 * @param      PropelPDO Optional Connection object.
	 * @return     Librarian The associated Librarian object.
	 * @throws     PropelException
	 */
	public function getLibrarian(PropelPDO $con = null)
	{
		$l = parent::getLibrariansRelatedByPatronId($con);
		return $l->count() > 0 ? $l->shift() : null;
	}

	/**
	 * Declares an association between this object and a Librarian object.
	 *
	 * @param      Librarian $v
	 * @return     Patron The current object (for fluent API support)
	 * @throws     PropelException
	 */
	public function setLibrarian(Librarian $v = null, PropelPDO $con = null)
	{
		$lc = new PropelCollection();
		$lc->append($v);
		return parent::setLibrariansRelatedByPatronId($v, $con);
	}

	/**
	 * It replaces all the references of $patronSource whith the ones in $patronDestination
	 * and deletes $patronSource
	 *
	 * @param Patron $patronSource : source Patron to be replaced (it will be deleted on success replacement)
	 * @param Patron $patronDestination : destination Patron
	 * @param ClavisLibrarian $clavisLibrarian : clavis user doing the action (for logging)
	 *
	 * @return boolean (transaction result)
	 */
	public function replaceWith(Patron $dst, $clavisLibrarian = null)
	{
		$arrRowsAffected = array(); //associative array (key: db table, value: num of rows affected by update)
		$dst_id = $dst->getPatronId();

		if (!is_null($clavisLibrarian) && !$clavisLibrarian instanceof ClavisLibrarian)
			return false;
		if ($this->patron_id == $dst_id)
			return false;

		$_connection = Propel::getConnection();
		try {
			$_connection->beginTransaction();

			//address table
			$arrRowsAffected['address'] = AddressQuery::create()
				->filterByPatronId($this->patron_id)
				->update(array('PatronId'=>$dst_id));

			//contacts
			$arrRowsAffected['contact'] = ContactQuery::create()
				->filterByPatronId($this->patron_id)
				->update(array('PatronId'=>$dst_id));

			//attachment
			$arrRowsAffected['attachment'] = AttachmentQuery::create()
				->filterByObjectType('Patron')
				->filterByObjectId($this->patron_id)
				->update(array('ObjectId'=>$dst_id));

			//patron_property
			$arrRowsAffected['patron_property'] = PatronPropertyQuery::create()
				->filterByPatronId($this->patron_id)
				->update(array('PatronId'=>$dst_id));

			//changelog
			$arrRowsAffected['changelog'] = ChangelogQuery::create()
				->filterByObjectClass('Patron')
				->filterByObjectId($this->patron_id)
				->update(array('ObjectId'=>$dst_id));

			//purchase_proposals
			$arrRowsAffected['purchase_proposal'] = PurchaseProposalQuery::create()
				->filterByPatronId($this->patron_id)
				->update(array('PatronId'=>$dst_id));

			//ill_request
			$arrRowsAffected['ill_request'] = IllRequestQuery::create()
				->filterByPatronId($this->patron_id)
				->update(array('PatronId'=>$dst_id));

			//item
			$arrRowsAffected['item'] = ItemQuery::create()
				->filterByPatronId($this->patron_id)
				->update(array('PatronId'=>$dst_id));

			//item_action
			$arrRowsAffected['item_action'] = ItemActionQuery::create()
				->filterByPatronId($this->patron_id)
				->update(array('PatronId'=>$dst_id));

			//item_request
			$arrRowsAffected['item_request'] = ItemRequestQuery::create()
				->filterByPatronId($this->patron_id)
				->update(array('PatronId'=>$dst_id));

			//l_patron (TODO: da fare in entrambe le direzioni e verificare il problema della chiave duplicata)
			//// mo verifico io  (mbrancalion)
			
			$arrRowsAffected['l_patron'] = 0;

			$lPatron1Results = LPatronQuery::create()
				->setFormatter('PropelOnDemandFormatter')
				->filterByParentPatronId($this->patron_id)
				->find();
			
			foreach ($lPatron1Results as $lPatron)
			{
				$childPatronId = $lPatron->getChildPatronId();
				$linkType = $lPatron->getLinkType();
				
				$lPatron->delete();

				$newLPatron = LPatronQuery::create()
								->filterByParentPatronId($dst_id)
								->filterByChildPatronId($childPatronId)
								->findOne();
				
				if ($newLPatron instanceof LPatron)
					$newLPatron->setLinkType ($linkType);
				else
				{
					$newLPatron = new LPatron();
					$newLPatron->setParentPatronId($dst_id);
					$newLPatron->setChildPatronId($childPatronId);
					$newLPatron->setLinkType($linkType);
				}				
				
				if ($newLPatron->save())
					$arrRowsAffected['l_patron']++;
				
				unset ($newLPatron);
			}	
			
			$lPatron2Results = LPatronQuery::create()
				->setFormatter('PropelOnDemandFormatter')	
				->filterByChildPatronId($this->patron_id)
				->find();

			foreach ($lPatron2Results as $lPatron)
			{
				$parentPatronId = $lPatron->getParentPatronId();
				$linkType = $lPatron->getLinkType();
				
				$lPatron->delete();
				
				$newLPatron = LPatronQuery::create()
								->filterByParentPatronId($parentPatronId)
								->filterByChildPatronId($dst_id)
								->findOne();
				
				if ($newLPatron instanceof LPatron)
					$newLPatron->setLinkType ($linkType);
				else
				{
					$newLPatron = new LPatron();
					$newLPatron->setParentPatronId($parentPatronId);
					$newLPatron->setChildPatronId($dst_id);
					$newLPatron->setLinkType($linkType);
				}
				
				if ($newLPatron->save())
					$arrRowsAffected['l_patron']++;
				
				unset ($newLPatron);
			}	

			//loan (TODO: completare con campi 'patron_age', 'patron_city'....)
			$arrRowsAffected['loan'] = LoanQuery::create()
				->filterByPatronId($this->patron_id)
				->update(array('PatronId'=>$dst_id));

			//notification
			$arrRowsAffected['notification'] = NotificationQuery::create()
				->filterByObjectClass(NotificationPeer::OBJECTTYPE_PATRON)
				->filterByObjectId($this->patron_id)
				->update(array('ObjectId'=>$dst_id));

			$arrRowsAffected['shelf_item'] = 0;
			$links = ShelfItemQuery::create()
				->filterByObjectClass(ShelfPeer::TYPE_PATRON)
				->filterByObjectId($this->patron_id)
				->find();
			foreach ($links as $link) {
				/* @var $link ShelfItem */
				$newlink = ShelfItemQuery::create()
					->filterByPrimaryKey(array(
					$link->getShelfId(),
					$dst_id,
					ShelfPeer::TYPE_PATRON))
					->findOneOrCreate();
				if ($newlink->isNew()) {
					$newlink->setItemStatus($link->getItemStatus());
					$newlink->save();
				}
				$link->delete();
				++$arrRowsAffected['shelf_item'];
			}
			$_connection->commit();
			$this->delete();
			if (count($arrRowsAffected) > 0) {
				$description = "Patron con ID [{$this->patron_id}]";
				foreach ($arrRowsAffected as $table => $count)
					if ($count > 0)
						$description .= " [$table : $count entry]";
				$description .= " schiacciato su Patron con ID [{$dst_id}]";
				ChangelogPeer::logAction($dst, ChangelogPeer::LOG_UPDATE, $clavisLibrarian, $description);
			}
		} catch (PropelException $e) {
			$_connection->rollback();
			Prado::log('Error in '.__CLASS__.'::'.__FUNCTION__.'(): .'.$e);
			return false;
		}
		
		return true;
	}

    /**
     * Check if patron has late loans
     *
     *
     * @return bool true if Patron has late loans
     */

    public function hasLateLoans()
    {
        $lateLoan = LoanQuery::create()
            ->filterByPatron($this)
            ->filterByLoanStatus(ItemPeer::LOANSTATUS_INLOAN)
            ->filterByDueDate(date('Y-m-d'),Criteria::LESS_THAN)
            ->count();

        return ($lateLoan > 0);
    }

    /**
     * Check if patron has pending payments
     *
     *
     * @return bool true if Patron has pending payments
     */

    public function hasPendingWallets()
    {
        $pendingWallets = PatronWalletQuery::create()
            ->filterByPatron($this)
            ->filterByWalletStatus(PatronWallet::STATUS_OPEN)
            ->count();

        return ($pendingWallets > 0);
    }

    /**
     * Returns all data with the actual status of circulation:
     * Current and availables loans, operations, reservations.
     */

    public function getCirculationStatus()
    {
        $ret = array();
        $itemMedia = LookupValuePeer::getLookupClassValues('ITEMMEDIATYPE');

        $loans = ItemQuery::create()
            ->filterByPatron($this)
            ->filterByLoanStatus(ItemPeer::getLoanStatusActive())
            ->groupByItemMedia()
            ->withColumn("count(*)","nbLoans")
            ->select(array("Item.ItemMedia","nbLoans"))
            ->find();

        $resCount = ItemRequestQuery::create()
            ->filterByPatron($this)
            ->filterByRequestStatus(ItemRequestPeer::STATUS_PENDING)
            ->count();

        $loanCount = 0;
        foreach($loans as $l)
        {
            $ret['ItemMedia'][$itemMedia[$l['Item.ItemMedia']]]['Loan'] = $l['nbLoans'];
            $loanCount += $l['nbLoans'];
        }

        $ret['MaxOperations']= ClavisParamPeer::getParam("MAXTOTALOPERATIONS");
        $ret['Operations'] = $loanCount + $resCount;
        $ret['AvailOperations'] =$ret['MaxOperations'] - $ret['Operations'];

        $ret['MaxReservations']= ClavisParamPeer::getParam("MAXLOANRESERVATIONS");
        $ret['Reservations']=$resCount;
        $ret['AvailReservations'] = min($ret['MaxReservations'] - $ret['Reservations'],$ret['AvailOperations']);

        $ret['PatronMaxLoans']=intval($this->getMaxLoans());
        if($ret['PatronMaxLoans'] > 0)
        {
            $ret['MaxLoans'] = $ret['PatronMaxLoans']  ;
        } else {
            $ret['MaxLoans'] = ClavisParamPeer::getParam("MAXLOANSALLOWED");
        }
        $ret['Loans'] = $loanCount;
        $ret['AvailLoans'] = min(array($ret['MaxLoans'] - $ret['Loans'], $ret['AvailOperations']));

        foreach($itemMedia as $k=>$v)
        {
            if(!isset($ret['ItemMedia'][$v]['Loan']))
                $ret['ItemMedia'][$v]['Loan'] = 0;

            $ret['ItemMedia'][$v]['MaxLoan'] = ClavisParamPeer::getParam("MAXLOANSALLOWED",$k);
            $ret['ItemMedia'][$v]['AvailLoan'] = min($ret['ItemMedia'][$v]['MaxLoan'] - $ret['ItemMedia'][$v]['Loan'], $ret['AvailLoans']);
        }


        return $ret;
    }

} // Patron
