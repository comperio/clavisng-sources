<?php

require_once 'clavis/om/BaseItemAction.php';

class ItemAction extends BaseItemAction {

	/**
	 *
	 * @author Marco Brancalion <mbrancalion@e-portaltech.it>
	 * @link http://www.e-portaltech.it/
	 * @copyright Copyright &copy; 2006 ePortal Technologies
	 * @license http://www.e-portaltech.it/license/
	 *
	 */
	public function getItemActionLabel()
	{
		$actionId = $this->action_type;
		$label = LookupValuePeer::getLookupValue('ITEMACTIONTYPE', $actionId);
		return $label;
	}

	public function setExternalLibrary($library = null)
	{
		if (!is_null($library) && ($library instanceof Library))
		{
			$this->setExternalLibraryId($library->getLibraryId());
		}
	}
} // ItemAction
