<?php

  // include base peer class
  require_once 'clavis/om/BaseInventorySeriePeer.php';

  // include object class
  include_once 'clavis/InventorySerie.php';


class InventorySeriePeer extends BaseInventorySeriePeer {
	/**
	 * It returns the next inventory counter, providing the keys of the table
	 * This method implements a transaction:
	 *    - get the current inventory counter
	 *    - increment
	 *    - try to update db with the incremented one:
	 * 		- if fail, increment and repeat
	 *      - if OK return
     *
	 * @param int $inventorySerieId
	 * @param int $libraryId
	 *
	 * @return int >=0 or 'false'
	 */
	public function calculateNextInventoryCounter($inventorySerieId, $libraryId)
	{
		try
		{
			$currCounter = -1;

			$connection = Propel::getConnection();

			$initsql = "SELECT inventory_counter";
			$initsql .= " FROM inventory_serie";
			$initsql .= " WHERE inventory_serie_id = '$inventorySerieId'";
			$initsql .= " AND library_id = $libraryId";

			$initstm = $connection->prepare($initsql);
			$initstm->execute();

			while($fetch = $initstm->fetch()) {
				 $currCounter = $fetch["inventory_counter"];
				 break; //ce ne deve essere solo uno!
			}

			if ($currCounter == -1)
				return false;

			while (true) {
				if (!is_null($currCounter)) {
					$oldCounter = $currCounter;
					$currCounter++;
				} else {
					$currCounter = 1;
				}

				$sql = "UPDATE inventory_serie";
				$sql .= " SET inventory_counter=$currCounter";
				$sql .= " WHERE inventory_serie_id = '$inventorySerieId'";
				$sql .= " AND library_id = $libraryId";
				if ($currCounter == 1) {
					$sql .= " AND ((inventory_counter IS NULL) OR (inventory_counter = ''))";
				} else {
					$sql .= " AND inventory_counter=$oldCounter";
				}

				$pdo = $connection->prepare($sql);
				$pdo->execute();
				$numaffected = $pdo->rowCount();

				if($numaffected != 0)
					return $currCounter;
				
				$initstm->execute();

				while($fetch = $initstm->fetch()) {
					 $currCounter = $fetch["inventory_counter"];
					 break; //ce ne deve essere solo uno!
				}
				
				if ($currCounter >= 2147483647)
					return false;
			}

		} catch (Exception $e) {
		   return false;
		}
	}

} // InventorySeriePeer
