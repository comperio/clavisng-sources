<?php

require_once 'clavis/om/BaseAttachment.php';

class Attachment extends BaseAttachment {

	private $_realfilepath = '';

	public function hydrate($row, $startcol = 0, $rehydrate = false) {
		parent::hydrate($row, $startcol, $rehydrate);
		// set realfilepath, for keeping storage clean on update
		$this->getRealFilePath(true);
	}

	// every attachment HAS to represent a concrete file, so we implement
	// of preSave() and preDelete() hooks to transparently manage that link

	public function preSave(PropelPDO $con = null) {
		// make sure the represented file exists, if not return false (thus stopping saving)
		if (!$this->checkLinkedFile())
			return false;
		return true;
	}

	public function preDelete(PropelPDO $con = null) {
		// delete concrete file before deleting record
		$linkedFile = $this->getRealFilePath();
		if (file_exists($linkedFile))
			unlink($linkedFile);
		return true;

	}

	/**
	 * Returns the real filesystem path for the file this record represents.
	 *
	 * @param boolean $forceRefresh
	 * @return string The real filesystem path for the linked file
	 */
	public function getRealFilePath($forceRefresh = false) {
		if (!$this->_realfilepath || $forceRefresh)
			$this->_realfilepath = $this->file_path ?
				AttachmentPeer::getRealStoragePath().'/'.$this->file_path : '';
		return $this->_realfilepath;
	}

	/**
	 * Checks if the file this record represents exists.
	 *
	 * @return boolean
	 */
	public function checkLinkedFile() {
		return file_exists($this->getRealFilePath());
	}

	/**
	 *
	 * @param string $filepath
	 * @param string $filename
	 * @return Attachment or false if storing was not successful
	 */
	public function storeFile($filepath,$filename='')
	{
		$oldFilePath = $this->getRealFilePath();
		if (!file_exists($filepath))
 			return false;
		if (trim($filename))
			$this->setFileName(trim($filename));
		else if (!$this->file_name)
			$this->setFileName(basename($filepath));

		if (!$this->getMimeType())	// try to get it out of the file
			$this->setMimeType(Clavis::mime_content_type($filepath));
		
		$this->setFileSize(filesize($filepath));

		$hash_path = AttachmentPeer::hashEntryAsString($this->object_type, $this->object_id, $this->attachment_type, $this->file_name);
		$hash_parts = AttachmentPeer::hashEntry($this->object_type, $this->object_id, $this->attachment_type, $this->file_name);

		$full_path = AttachmentPeer::getRealStoragePath().
			'/'.$hash_parts['L1'].
			'/'.$hash_parts['L2'].
			'/'.$hash_parts['L3'];
		if(!file_exists($full_path))
			mkdir($full_path,0777,true);
		$full_path .= '/'.$hash_parts['filename'];

		if (file_exists($full_path))
			unlink($full_path);

		try {
			copy($filepath, $full_path);
			$this->setFilePath($hash_path);
			$this->save();
			// if we had a linked file, unlink it (but only if it has not been overwritten)
			if ($oldFilePath && $oldFilePath != $full_path) {
				// silence errors: if the file isn't there, we don't care.
				@unlink($oldFilePath);
				$this->getRealFilePath(true);
			}
		} catch (Exception $e) {
			throw $e;
		}
		return $this;
	}

	public function retrieveFile() {
		if (!$this->checkLinkedFile())
			return false;
		return file_get_contents($this->getRealFilePath());
	}

} // Attachment
