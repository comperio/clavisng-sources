<?php

require_once 'clavis/om/BaseAppAction.php';

class AppAction extends BaseAppAction {

} // AppAction
