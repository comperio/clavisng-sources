<?php

/**
 * @version 2.7
 * @package propel.generator.clavis
 * @since 2.0
 */
require_once 'clavis/om/BaseLookupValuePeer.php';
include_once 'clavis/LookupValue.php';

class LookupValuePeer extends BaseLookupValuePeer {

	const DEFAULTBLANKLABEL = '---';

    const FALLBACK_LANGUAGE = 'it_IT';

	public static $_localCache = array();
	public static $_culture = null;

	/**
	 * Returns the label for a given class/key pair.
	 * Fallbacks on default language if current locale is not available.
	 *
	 * @param string $class The class for the lookup value.
	 * @param string $key The key for the lookup value.
	 * @param string $mutual Whether to get the mutual value for the lookup, defaults to false.
	 * @return string The label associated for the given class/key pair.
	 */
	public static function getLookupValue($class, $key, $mutual=false)
	{
		self::loadCulture();
		if ($mutual)
			$key = strrev($key);

	    $cacheKey = $class.'-' .self::$_culture .'-'.$key;

        if(class_exists("Prado") && php_sapi_name()!=='cli')
        {
            $cacheKey = Prado::getApplication()->getID() . "-LV-{$cacheKey}";
            if(apc_exists($cacheKey))
                self::$_localCache[$cacheKey] = apc_fetch($cacheKey);
        }

		if (! array_key_exists($cacheKey,self::$_localCache)) {
			$value = LookupValueQuery::create()
				->filterByValueClass($class)
				->filterByValueLanguage(self::$_culture)
				->filterByValueKey($key)
				->findOne();
			if (!$value instanceof LookupValue && self::$_culture != self::FALLBACK_LANGUAGE)
				$value = LookupValueQuery::create()
					->filterByValueClass($class)
					->filterByValueLanguage(self::FALLBACK_LANGUAGE)
					->filterByValueKey($key)
					->find();
			self::$_localCache[$cacheKey] =
				$value instanceof LookupValue ? $value->getValueLabel() : '';

            apc_store($cacheKey,self::$_localCache[$cacheKey]);
		}
		return self::$_localCache[$cacheKey];
	}

	protected static function loadCulture() {
		if (self::$_culture === null)
			if (class_exists('Prado') && Prado::getApplication() instanceof TApplication)
				self::$_culture = Prado::getApplication()->getGlobalization()->getCulture();
			else if (defined('GLOBAL_CULTURE'))
				self::$_culture = GLOBAL_CULTURE;
			else
				self::$_culture = self::FALLBACK_LANGUAGE;
	}

	/**
	 * Returns an hash of key => label for a given lookup class.
	 * Merges current locale values with fallback language ones.
	 *
	 * @param string $class The wanted class.
	 * @param boolean $hasBlank Whether the hash should contain a starting "blank" element.
	 * @param string $blankLabel The label for the optional "blank" element.
	 * @param Array $set Whether the list should be filtered by a subset of keys.
	 * @param boolean $sortFlag Whether the list should be sorted by label.
	 * @param int $labelLength The max length for the label. 0 for no-trimming (default)
	 * @return array The hash for the given lookup class.
	 */
	public static function getLookupClassValues(	$class,
													$hasBlank = false,
													$blankLabel = null,
													$set = array(),
													$sortFlag = false,
			
													$labelLength = null)
	{
		if (is_null($blankLabel))
			$blankLabel = self::DEFAULTBLANKLABEL;

		if (!is_array($set))
			$set = array();

		self::loadCulture();

		$cacheKey = (count($set) > 0) ?
			$class.'-'.self::$_culture.'-('.implode('-',$set).')' :
			$class.'-'.self::$_culture;

        if(class_exists("Prado") && php_sapi_name()!=='cli')
        {
            $cacheKey = Prado::getApplication()->getID() . "-LV-{$cacheKey}";
            if(apc_exists($cacheKey))
                self::$_localCache[$cacheKey] = apc_fetch($cacheKey);
        }

		if (! array_key_exists($cacheKey,self::$_localCache)) {
			$c = new Criteria();
			$c->add(self::VALUE_CLASS , $class);
			$c->add(self::VALUE_LANGUAGE, self::$_culture);
			if (count($set) > 0)
				$c->add(self::VALUE_KEY, $set, Criteria::IN);

            $values = self::doSelectOrderByRank($c);

			$labels = array();

			foreach ($values as $row)
				$labels[$row->getValueKey()] = ($labelLength > 0) ? $row->getTrimmedValueLabel($labelLength) :  $row->getValueLabel();

			if (self::$_culture != self::FALLBACK_LANGUAGE) {
				$c->add(self::VALUE_LANGUAGE, self::FALLBACK_LANGUAGE);
				$fallbackValues = ($sortFlag) ? self::doSelect($c) : self::doSelectOrderByRank($c);
				foreach ($fallbackValues as $row)
					if (! array_key_exists($row->getValueKey(), $labels))
						$labels[$row->getValueKey()] = ($labelLength > 0) ? $row->getTrimmedValueLabel($labelLength) :  $row->getValueLabel();
			}

			self::$_localCache[$cacheKey] = $labels;
            apc_store($cacheKey,$labels);
		}

        $valueList = self::$_localCache[$cacheKey];

        if($sortFlag)
            asort($valueList);

        $valueList =  ($hasBlank) ? array(0 => $blankLabel) + $valueList : $valueList;

        return $valueList;
	}

	public static function classExists($class)
	{
        if(class_exists("Prado") && php_sapi_name()!=='cli')
        {
            $cacheKey = Prado::getApplication()->getID() . "-LV-{$class}";
            if(apc_exists($cacheKey)) return apc_fetch($cacheKey);
        }
        else
        {
            $cacheKey = null;
        }

		self::loadCulture();

		$value = LookupValueQuery::create()
			->filterByValueLanguage(self::$_culture)
			->filterByValueClass($class)
			->count() > 0;

        if($cacheKey != null) apc_store($cacheKey,$value);

        return $value;
	}
} // LookupValuePeer
