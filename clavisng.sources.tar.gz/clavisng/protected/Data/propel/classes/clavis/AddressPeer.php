<?php

  // include base peer class
  require_once 'clavis/om/BaseAddressPeer.php';

  // include object class
  include_once 'clavis/Address.php';

class AddressPeer extends BaseAddressPeer {

} // AddressPeer
