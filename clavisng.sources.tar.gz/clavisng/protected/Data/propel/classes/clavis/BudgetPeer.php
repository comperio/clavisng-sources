<?php

  // include base peer class
  require_once 'clavis/om/BaseBudgetPeer.php';

  // include object class
  include_once 'clavis/Budget.php';


class BudgetPeer extends BaseBudgetPeer {

	/**
	 * Get a list of budgets based on a start string and optional criterions.
	 *
	 * @param string $token The string to use as a base search.
	 * @param integer $limit The maximum of librarians to return (defaults to 10).
	 * @param Array $criterions Optional criterions to further filter the results.
	 * @return Array A list of Budgets.
	 */
	public function doSuggest($token,$limit=10) {
		$list = array();
		$c = new Criteria();
		$c->add(self::BUDGET_TITLE,$token.'%',Criteria::LIKE);
		$c->addAscendingOrderByColumn(self::BUDGET_TITLE);
		$c->setLimit($limit);
		$list = self::doSelect($c);
		return $list;
	}
	
	public static function getViewPage()
	{
		return 'Acquisition.BudgetViewPage';
	}
	
} // BudgetPeer
