<?php

require_once 'clavis/om/BaseAppProfileAcl.php';

class AppProfileAcl extends BaseAppProfileAcl {

} // AppProfileAcl
