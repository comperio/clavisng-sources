<?php
/**
 * ShelfPeer class file.
 *
 * Clavis is an Integrated Library Management System developed by Comperio srl.
 * Discovery is an OPAC bundled witch Clavis.
 * Copyright (C) 2000 - 2012 Comperio srl
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by
 * the Free Software Foundation with the addition of the following permission
 * added to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED
 * WORK IN WHICH THE COPYRIGHT IS OWNED BY COMPERIO, COMPERIO DISCLAIMS THE
 * WARRANTY OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program; if not, see http://www.gnu.org/licenses or write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA.
 *
 * You can contact Comperio srl headquarters at Via Nazionale, 154
 * 35048 Stanghella (Padova), ITALY, or at email address info@comperio.it.
 * Website: http://www.comperio.it
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License
 * version 3, these Appropriate Legal Notices must retain the display of the
 * "Powered by Comperio" logo. If the display of the logo is not reasonably
 * feasible for technical reasons, the Appropriate Legal Notices must display
 * the words "Powered by Comperio".
 *
 * Sources should be available via "Download" link available in all pages.
 * All modifications and changes should be delivered via patches to base
 * source release to simplify identification of changes.
 *
 * For Commercial Licenses and support please contact Comperio.
 *
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2006-2012 Comperio srl
 * @license http://www.gnu.org/licenses/agpl.html GNU Affero General Public License
 * @version 2.7
 * @package propel.generator.clavis
 */
require_once 'clavis/om/BaseShelfPeer.php';
include_once 'clavis/Shelf.php';

/**
 * ShelfPeer Class
 *
 * @version 2.7
 * @package propel.generator.clavis
 * @since 2.0
 */
class ShelfPeer extends BaseShelfPeer
{
	const ADDSHELF_CHUNK_NUMBER = 1000;
	
	const SHELF_NAMEEXISTS = 20;
	const ERROR = 42;
	const OK = 10;

	const NOTYPE = "**NOTYPE**";
	const TYPE_MANIFESTATION = 'manifestation';
	const TYPE_AUTHORITY = 'authority';
	const TYPE_ITEM = 'item';
	const TYPE_PATRON = 'patron';
	const TYPE_LOAN = 'loan';
	const TYPE_LIBRARY = 'library';
	const TYPE_LIBRARIAN = 'librarian';
	const TYPE_MANIFESTATION_BUY = 'manifestation_buy';

	const VISIBILITY_OWNER = 'A'; // only owner
	const VISIBILITY_LIBRARYOPS = 'B'; // only library ops
	const VISIBILITY_ADMINS = 'C'; // only admins
	const VISIBILITY_ALLOPS = 'D'; // by all ops (incl. OPAC)
	const VISIBILITY_OPAC = 'E'; // only library ops (incl. OPAC)
	const VISIBILITY_ALLREADONLY = 'F'; // by all ops, no write allowed but owner

	public static $plugins_edit = array('ShelfAssignItemsToLibrary',
										'ShelfChangeItems',
										'ShelfChangeItemsDiscard',
										'ShelfChangeManifestations',
										'ShelfContentDelete',
										'ShelfContentMove',
										'ShelfFilterMediaType',
										'ShelfItemInsertFromBarcode',
										'ShelfItemInsertFromCSV',
										'ShelfLoanFilterSection',
										'ShelfItemManagementChangeRequest');

	public static $plugins_nonedit = array(	'ShelfContentCopy',
												'ShelfContentEmailSend',
												'ShelfContentExtractISO2709',
												'ShelfContentJRPrint',
												'ShelfContentToItems',
												'ShelfContentToManifestation',
												'ShelfContentToPatron',
												'ShelfConvertToPurchaseProposal',
												'ShelfExport' );

	/**
	 * Returns the visible shelves for a given librarian.
	 *
	 * @static
	 * @param ClavisLibrarian $user
	 * @param null $shelfType The shelves type (will return all type = $shelfType AND type = null)
	 * @param null $limit
	 * @param null $offset
	 * @return PropelObjectCollection|array|int|mixed
	 */
	public static function getVisibleShelves(	ClavisLibrarian $user,
												$shelfType = null,
												$limit = null,
												$offset = null,
												ShelfQuery $baseQuery = null )
	{
		if (!$baseQuery)
			$baseQuery = ShelfQuery::create();
		if (!count($baseQuery->getOrderByColumns()))
			$baseQuery->orderByShelfName();

		$baseQuery->condition('status_owner', 'Shelf.ShelfStatus = ?', self::VISIBILITY_OWNER)
					->condition('status_library', 'Shelf.ShelfStatus IN (?,?)', array(self::VISIBILITY_LIBRARYOPS, self::VISIBILITY_OPAC))
					->condition('status_all', 'Shelf.ShelfStatus IN (?,?)', array(self::VISIBILITY_ALLOPS, self::VISIBILITY_ALLREADONLY))
					->condition('user', 'Shelf.LibrarianId = ?', $user->getId())
					->condition('library', 'Shelf.LibraryId = ?', $user->getActualLibraryId())
					->combine(array('status_owner', 'user'), 'and', 'visible_owner')
					->combine(array('status_library', 'library'), 'and', 'visible_library')
					->combine(array('visible_owner', 'visible_library', 'status_all'), 'or', 'visibility');
		
		$whereConds = array('visibility');
		
		if ($shelfType) {
			$baseQuery->condition('itemtype_null', 'Shelf.ShelfItemtype IS NULL')
						->condition('itemtype', 'Shelf.ShelfItemtype = ?', $shelfType)
						->combine(array('itemtype_null', 'itemtype'), 'or', 'shelftype');
			$whereConds[] = 'shelftype';
		}
		
		$baseQuery->where($whereConds, 'and');
		
		if ('count' == $limit) {
			return $baseQuery->count();
		} else {
			if (intval($limit))
				$baseQuery->limit($limit);
			if (intval($offset))
				$baseQuery->offset($offset);
			return $baseQuery->find();
		}
	}

	/**
	 * Returns an hash with the visible shelves for a given librarian, ID => ShelfName.
	 *
	 * @static
	 * @param ClavisLibrarian $user
	 * @param null $shelfType
	 * @param null $limit
	 * @param null $offset
	 * @param null $trimChars
	 * @param array $excludeIds
	 * @return array
	 */
	public static function getVisibleShelvesArray(	ClavisLibrarian $user,
														$shelfType = null,
														$limit = null,
														$offset = null,
														ShelfQuery $baseQuery = null,
				
														$trimChars = null,
														$excludeIds = array() )
	{
		$ret = array();
		$shelfList = self::getVisibleShelves(	$user,
												$shelfType,
												$limit,
												$offset,
												$baseQuery );
		if (!is_array($excludeIds))
			$excludeIds = array($excludeIds);

		foreach ($shelfList as $shelf)
		{
			$shelfId = $shelf->getShelfId();
			if (!in_array($shelfId, $excludeIds))
				if ($trimChars > 0)
					$ret[$shelfId] = '(' . $shelfId . ') ' . substr(strip_tags($shelf->getShelfName()), 0, $trimChars);
				else
					$ret[$shelfId] = $shelf->getShelfName();
		}
		
		return $ret;
	}

	/**
	 *
	 * @param string $name The shelf name
	 * @param string $description The shelf description
	 * @param ClavisLibrarian $user
	 * @param int $libraryId
	 * @param string $shelfStatus
	 * @return Shelf The created shelf
	 * @throws Exception
	 */
	public static function createShelf($name = '',
									   $description = '',
									   $user = null,
									   $libraryId = null,
									   $shelfStatus = null)
	{
		if (is_null($libraryId) && class_exists('Prado')) {
			$libraryId = Prado::getApplication()->getUser()->getActualLibraryId();
		} else {
			$libraryId = intval($libraryId);
			if ($libraryId == 0)
				throw new Exception('Library ID provided and not valid.', self::ERROR);
		}
		$name = trim(strip_tags($name));
		if ($name == '')
			throw new Exception('No name provided');
		else if (ShelfQuery::create()->filterByLibraryId($libraryId)->filterByShelfName($name)->count() > 0)
			throw new Exception('A shelf with the same name already exists.', self::SHELF_NAMEEXISTS);

		if (is_null($shelfStatus))
			$shelfStatus = self::VISIBILITY_LIBRARYOPS;

		if ($user instanceof ClavisLibrarian)
			$userId = $user->getId();
		else if (class_exists('Prado'))
			$userId = Prado::getApplication()->getUser()->getId();
		else
			$userId = 1;

		try
		{
			$newShelf = new Shelf();
			$newShelf->setShelfName($name);
			$newShelf->setShelfDescription(strip_tags($description));
			$newShelf->setLibrarianId($userId);
			$newShelf->setLibraryId($libraryId);
			$newShelf->setShelfStatus($shelfStatus);
			$newShelf->save();
			return $newShelf;
		}
		catch (Exception $e)
		{
			Prado::log($e);
			throw $e;
		}
		
		throw new Exception();
	}

	/**
	 * @param int|Shelf $shelf
	 * @param bool $autoSave
	 * @return Shelf
	 */
	public static function checkShelfItemTypes($shelf, $autoSave=false)
	{
		if (is_int($shelf))
			$shelf = ShelfQuery::create()->findPk($shelf);

		$classes = ShelfItemQuery::create()
			->filterByShelfId($shelf->getShelfId())
			->groupByObjectClass()
			->select('ObjectClass')
			->distinct()
			->find()->toArray();
		switch (count($classes)) {
			case 0:
				$shelf->setShelfItemtype(null);
				break;
			case 1:
				$shelf->setShelfItemtype($classes[0]);
				break;
			default:
				$shelf->setShelfItemtype(ShelfPeer::NOTYPE);
				break;
		}
		
		if ($shelf->isModified() && $autoSave)
			$shelf->save();
		
		return $shelf;
	}

	/**
	 * Returns an array with real actual shelfitem types present
	 * in the shelf passed as a parameter.
	 * 
	 * @param int|Shelf $shelfId
	 * @return array (shelf types constants)
	 */
	public static function getShelfItemTypes($shelfId)
	{
		if ($shelfId instanceof Shelf)
			$shelfId = $shelf->getShelfId();
				
		if (intval($shelfId) == 0)	// invalid
			return array();
		
		$classes = ShelfItemQuery::create($shelfId)
					->filterByShelfId($shelfId)
					->groupByObjectClass()
					->select('ObjectClass')
					->distinct()
					->find()->toArray();

		return $classes;
	}
	
	public static function addItemToShelf($shelf = null,
											$objectClass = null,
											$objectId = null)
	{
		if (!$shelf instanceof Shelf)
			$shelf = ShelfQuery::create()->findPk($shelf);

		if (!$shelf instanceof Shelf)
			return false;

		if ($objectClass === '' || !$objectId || !$shelf instanceof Shelf)
			return false;

		if (!is_array($objectId))
			$objectId = array(intval($objectId));

		if ($shelf->getShelfItemtype() == self::TYPE_MANIFESTATION_BUY)
			switch ($objectClass)
			{
				case self::TYPE_MANIFESTATION:
					$objectClass = self::TYPE_MANIFESTATION_BUY;
					
					break;

				case self::TYPE_ITEM:
					$manifestations = ManifestationQuery::create()
						->useItemQuery()
							->filterByItemId($objectId)
						->endUse()
						->select('ManifestationId')
						->find()->toArray();
					if ($manifestations) {
						$objectClass = self::TYPE_MANIFESTATION_BUY;
						$objectId = $manifestations;
					} else {
						throw new Exception('No manifestation could be retrieved for the specified item.');
					}
					
					break;

				default:
					throw new Exception('Wrong item type for this shelf.');
					
					break;
			}
			
		$conn = Propel::getConnection();
		$count = 0;
		foreach (array_chunk($objectId, self::ADDSHELF_CHUNK_NUMBER) as $chunk)
		{
			$sql = 'REPLACE INTO '.ShelfItemPeer::TABLE_NAME.' ('
				.ShelfItemPeer::SHELF_ID.','.ShelfItemPeer::OBJECT_CLASS.','
				.ShelfItemPeer::OBJECT_ID.') VALUES ';
		
			foreach ($chunk as $id)
				$sql .= "\n({$shelf->getShelfId()},'{$objectClass}',".intval($id).'),';
			$sql = rtrim($sql,',');
			
			try
			{
				$count += $conn->exec($sql);
				if (ShelfPeer::TYPE_MANIFESTATION == $objectClass ||
						ShelfPeer::TYPE_MANIFESTATION_BUY == $objectClass)
					ManifestationPeer::invalidateCache($objectId);
			}
			catch (PropelException $exception)
			{
				$errorMessage = $exception->getCause()->getMessage();
				$dbClass = Propel::getDB();
				if (!$dbClass instanceof DBMySQL || !strstr($errorMessage, 'Duplicate entry'))
					throw ($exception);
			}
		}
		
		self::checkShelfItemTypes($shelf, true);
		
		return $count;
	}

	public static function getPluginsNonEdit() {
		return self::getPlugins('nonedit');
	}

	public static function getPluginsEdit() {
		return self::getPlugins('edit');
	}

	public static function getPlugins($filter='all')
	{
		switch ($filter)
		{
			case 'all':
				return array_merge(self::$plugins_edit,self::$plugins_nonedit);
		
				break;
			
			case 'nonedit':
				return self::$plugins_nonedit;
				
				break;
			
			case 'edit':
				return self::$plugins_edit;
			
				break;
		}
	}
	
} // ShelfPeer
