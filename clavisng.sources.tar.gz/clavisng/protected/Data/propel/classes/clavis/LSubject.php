<?php

require 'clavis/om/BaseLSubject.php';


class LSubject extends BaseLSubject {

} // LSubject
