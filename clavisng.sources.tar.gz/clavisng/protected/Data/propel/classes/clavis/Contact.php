<?php

/**
 * Contact class
 *
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2011 Comperio srl
 * @version 2.7
 * @package propel.generator.clavis
 * @since 2.0
 */

require_once 'clavis/om/BaseContact.php';

class Contact extends BaseContact {
	
	public function preSave(PropelPDO $con = null)
	{
		if ($this->getContactPref()) {
			// ensure no other contacts belonging to the same patron are preferred
			$q = ContactQuery::create()
				->filterByPatronId($this->getPatronId())
				->prune($this)
				->update(array('ContactPref' => false));
		}
		return true;
	}
	
	public function getContactTypeString() {
		return LookupValuePeer::getLookupValue('CONTACTTYPE',$this->getContactType());
	}

	public function isLinkable()
	{
		switch ($this->getContactType()) {
			case ContactPeer::TYPE_EMAIL:
			case ContactPeer::TYPE_MSN:
			case ContactPeer::TYPE_JABBER:
			case ContactPeer::TYPE_YAHOO:
			case ContactPeer::TYPE_AOL:
			case ContactPeer::TYPE_SKYPE:
				return true;
			case ContactPeer::TYPE_MOBILE:
			case ContactPeer::TYPE_PHONE:
			case ContactPeer::TYPE_FAX:
			case ContactPeer::TYPE_ICQ:
			default:
				return false;
		}
	}

	public function getContactLink()
	{
		$ret = $this->getContactValue();
		switch ($this->getContactType()) {
			case ContactPeer::TYPE_EMAIL:
				$ret = "mailto:{$ret}";
				break;
			case ContactPeer::TYPE_MSN:
				$ret = "msnim:chat?contact={$ret}";
				break;
			case ContactPeer::TYPE_YAHOO:
				$ret = "ymsgr:sendim?{$ret}";
				break;
			case ContactPeer::TYPE_AOL:
				$ret = "aim:goim?screenname={$ret}";
				break;
			case ContactPeer::TYPE_SKYPE:
				$ret = "skype:{$ret}?chat";
				break;
			case ContactPeer::TYPE_MOBILE:
			case ContactPeer::TYPE_PHONE:
			case ContactPeer::TYPE_FAX:
			case ContactPeer::TYPE_ICQ:
			default:
				break;
		}
		return $ret;
	}
	
	
} // Contact
