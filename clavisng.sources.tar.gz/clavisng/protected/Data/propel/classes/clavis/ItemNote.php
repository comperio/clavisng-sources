<?php

require_once 'clavis/om/BaseItemNote.php';

class ItemNote extends BaseItemNote {

	public function getNoteTypeLabel()
	{
		return LookupValuePeer::getLookupValue('UNI3XXITEM',$this->note_type).
			' ('.$this->note_type. ')';
	}
} // ItemNote
