<?php

// include base peer class
require_once 'clavis/om/BaseAppProfilePeer.php';

// include object class
include_once 'clavis/AppProfile.php';

class AppProfilePeer extends BaseAppProfilePeer
{

	public function getProfileLabel($profileId)
	{
		$profile = self::retrieveByPK($profileId);
		return ($profile instanceof AppProfile) ?
			$profile->getName() : '';
	}

} // AppProfilePeer
