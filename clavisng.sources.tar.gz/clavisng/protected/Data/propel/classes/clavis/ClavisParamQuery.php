<?php
/**
 * @package    propel.generator.clavis
 */
class ClavisParamQuery extends BaseClavisParamQuery {

	private static $_localCache = array();

	/**
	 * @param string $class The parameter class
	 * @param string $name (optional) The parameter name
	 * @param int $libraryId (optional) The parameter library ID
	 * @param int $librarianId (optional) The parameter librarian ID
	 * @return string The parameter value or null if it's not found.
	 */
	public static function getParam($class, $name = null, $libraryId = 0, $librarianId = 0)
	{
		$cacheKey = "{$class}-{$name}-{$libraryId}-{$librarianId}";

        if(class_exists("Prado") && php_sapi_name()!=='cli')
        {
            $cacheKey = Prado::getApplication()->getID() . "-PARAM-{$cacheKey}";
            if(apc_exists($cacheKey)) return apc_fetch($cacheKey);
        }

		if (! array_key_exists($cacheKey,self::$_localCache)) {
			$q = self::create()
				->filterByParamClass($class);
			if (!is_null($name))
				$q->filterByParamName($name);
			if (intval($libraryId) > 0)
				$q->filterByLibraryId($libraryId);
			if (intval($librarianId) > 0)
				$q->filterByLibrarianId($librarianId);
			$value = $q->findOne();

			self::$_localCache[$cacheKey] = $value instanceof ClavisParam ? $value->getParamValue() : null;

            apc_store($cacheKey,self::$_localCache[$cacheKey]);
		}

		return self::$_localCache[$cacheKey];
	}

	public static function getClassParams($class, $libraryId = 0, $librarianId = 0)
	{
        if(class_exists("Prado") && php_sapi_name()!=='cli')
        {
            $cacheKey = Prado::getApplication()->getID() . "-PARAM-{$class}-{$libraryId}-{$librarianId}";
            if(apc_exists($cacheKey)) return apc_fetch($cacheKey);
        }

		$q = self::create()
			->filterByParamClass($class);
		if (intval($libraryId) > 0)
			$q->filterByLibraryId($libraryId);
		if (intval($librarianId) > 0)
			$q->filterByLibrarianId($librarianId);
		$labels = array();
		foreach ($q->find() as $param)
			$labels[$param->getParamName()] = $param->getParamValue();

        apc_store($cacheKey,$labels);

		return $labels;
	}

	public static function clearCache()
	{
		self::$_localCache = array();
	}

} // ClavisParamQuery
