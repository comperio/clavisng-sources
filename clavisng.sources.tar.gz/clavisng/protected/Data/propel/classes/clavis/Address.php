<?php
/**
 * Address class
 *
 * @link http://www.comperio.it/
 * @copyright Copyright &copy; 2011 Comperio srl
 * @version 2.7
 * @package propel.generator.clavis
 * @since 2.0
 */

require_once 'clavis/om/BaseAddress.php';

class Address extends BaseAddress {
	
	public function preSave(PropelPDO $con = null)
	{
		if ($this->getAddressPref()) {
			// ensure no other addresses belonging to the same patron are preferred
			$q = AddressQuery::create()
				->filterByPatronId($this->getPatronId())
				->prune($this)
				->update(array('AddressPref' => false));
		}
		return true;
	}
	
	public function getStreetTypeString() {
		return LookupValuePeer::getLookupValue('STREET',$this->getStreetType());
	}
	
	public function getAddressString() {
		return "{$this->getStreetTypeString()} {$this->getStreet()}, {$this->getStreetNum()}";
	}
	
	public function getAddressTypeString() {
		return LookupValuePeer::getLookupValue('ADDRESSTYPE',$this->getAddressType());
	}

} // Address
