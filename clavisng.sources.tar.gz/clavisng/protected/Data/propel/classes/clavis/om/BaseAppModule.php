<?php


/**
 * Base class that represents a row from the 'app_module' table.
 *
 *
 *
 * @package    propel.generator.clavis.om
 */
abstract class BaseAppModule extends BaseObject implements Persistent
{
    /**
     * Peer class name
     */
    const PEER = 'AppModulePeer';

    /**
     * The Peer class.
     * Instance provides a convenient way of calling static methods on a class
     * that calling code may not be able to identify.
     * @var        AppModulePeer
     */
    protected static $peer;

    /**
     * The flag var to prevent infinite loop in deep copy
     * @var       boolean
     */
    protected $startCopy = false;

    /**
     * The value for the module_id field.
     * @var        string
     */
    protected $module_id;

    /**
     * The value for the sort_order field.
     * @var        int
     */
    protected $sort_order;

    /**
     * The value for the label field.
     * @var        string
     */
    protected $label;

    /**
     * The value for the page field.
     * @var        string
     */
    protected $page;

    /**
     * The value for the always_view field.
     * Note: this column has a database default value of: true
     * @var        boolean
     */
    protected $always_view;

    /**
     * @var        PropelObjectCollection|AppAction[] Collection to store aggregation of AppAction objects.
     */
    protected $collAppActions;
    protected $collAppActionsPartial;

    /**
     * @var        PropelObjectCollection|AppProfileAcl[] Collection to store aggregation of AppProfileAcl objects.
     */
    protected $collAppProfileAcls;
    protected $collAppProfileAclsPartial;

    /**
     * Flag to prevent endless save loop, if this object is referenced
     * by another object which falls in this transaction.
     * @var        boolean
     */
    protected $alreadyInSave = false;

    /**
     * Flag to prevent endless validation loop, if this object is referenced
     * by another object which falls in this transaction.
     * @var        boolean
     */
    protected $alreadyInValidation = false;

    /**
     * Flag to prevent endless clearAllReferences($deep=true) loop, if this object is referenced
     * @var        boolean
     */
    protected $alreadyInClearAllReferencesDeep = false;

    // sortable behavior

    /**
     * Queries to be executed in the save transaction
     * @var        array
     */
    protected $sortableQueries = array();

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $appActionsScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $appProfileAclsScheduledForDeletion = null;

    /**
     * Applies default values to this object.
     * This method should be called from the object's constructor (or
     * equivalent initialization method).
     * @see        __construct()
     */
    public function applyDefaultValues()
    {
        $this->always_view = true;
    }

    /**
     * Initializes internal state of BaseAppModule object.
     * @see        applyDefaults()
     */
    public function __construct()
    {
        parent::__construct();
        $this->applyDefaultValues();
    }

    /**
     * Get the [module_id] column value.
     *
     * @return string
     */
    public function getModuleId()
    {

        return $this->module_id;
    }

    /**
     * Get the [sort_order] column value.
     *
     * @return int
     */
    public function getSortOrder()
    {

        return $this->sort_order;
    }

    /**
     * Get the [label] column value.
     *
     * @return string
     */
    public function getLabel()
    {

        return $this->label;
    }

    /**
     * Get the [page] column value.
     *
     * @return string
     */
    public function getPage()
    {

        return $this->page;
    }

    /**
     * Get the [always_view] column value.
     *
     * @return boolean
     */
    public function getAlwaysView()
    {

        return $this->always_view;
    }

    /**
     * Set the value of [module_id] column.
     *
     * @param  string $v new value
     * @return AppModule The current object (for fluent API support)
     */
    public function setModuleId($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->module_id !== $v) {
            $this->module_id = $v;
            $this->modifiedColumns[] = AppModulePeer::MODULE_ID;
        }


        return $this;
    } // setModuleId()

    /**
     * Set the value of [sort_order] column.
     *
     * @param  int $v new value
     * @return AppModule The current object (for fluent API support)
     */
    public function setSortOrder($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->sort_order !== $v) {
            $this->sort_order = $v;
            $this->modifiedColumns[] = AppModulePeer::SORT_ORDER;
        }


        return $this;
    } // setSortOrder()

    /**
     * Set the value of [label] column.
     *
     * @param  string $v new value
     * @return AppModule The current object (for fluent API support)
     */
    public function setLabel($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->label !== $v) {
            $this->label = $v;
            $this->modifiedColumns[] = AppModulePeer::LABEL;
        }


        return $this;
    } // setLabel()

    /**
     * Set the value of [page] column.
     *
     * @param  string $v new value
     * @return AppModule The current object (for fluent API support)
     */
    public function setPage($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->page !== $v) {
            $this->page = $v;
            $this->modifiedColumns[] = AppModulePeer::PAGE;
        }


        return $this;
    } // setPage()

    /**
     * Sets the value of the [always_view] column.
     * Non-boolean arguments are converted using the following rules:
     *   * 1, '1', 'true',  'on',  and 'yes' are converted to boolean true
     *   * 0, '0', 'false', 'off', and 'no'  are converted to boolean false
     * Check on string values is case insensitive (so 'FaLsE' is seen as 'false').
     *
     * @param boolean|integer|string $v The new value
     * @return AppModule The current object (for fluent API support)
     */
    public function setAlwaysView($v)
    {
        if ($v !== null) {
            if (is_string($v)) {
                $v = in_array(strtolower($v), array('false', 'off', '-', 'no', 'n', '0', '')) ? false : true;
            } else {
                $v = (boolean) $v;
            }
        }

        if ($this->always_view !== $v) {
            $this->always_view = $v;
            $this->modifiedColumns[] = AppModulePeer::ALWAYS_VIEW;
        }


        return $this;
    } // setAlwaysView()

    /**
     * Indicates whether the columns in this object are only set to default values.
     *
     * This method can be used in conjunction with isModified() to indicate whether an object is both
     * modified _and_ has some values set which are non-default.
     *
     * @return boolean Whether the columns in this object are only been set with default values.
     */
    public function hasOnlyDefaultValues()
    {
            if ($this->always_view !== true) {
                return false;
            }

        // otherwise, everything was equal, so return true
        return true;
    } // hasOnlyDefaultValues()

    /**
     * Hydrates (populates) the object variables with values from the database resultset.
     *
     * An offset (0-based "start column") is specified so that objects can be hydrated
     * with a subset of the columns in the resultset rows.  This is needed, for example,
     * for results of JOIN queries where the resultset row includes columns from two or
     * more tables.
     *
     * @param array $row The row returned by PDOStatement->fetch(PDO::FETCH_NUM)
     * @param int $startcol 0-based offset column which indicates which resultset column to start with.
     * @param boolean $rehydrate Whether this object is being re-hydrated from the database.
     * @return int             next starting column
     * @throws PropelException - Any caught Exception will be rewrapped as a PropelException.
     */
    public function hydrate($row, $startcol = 0, $rehydrate = false)
    {
        try {

            $this->module_id = ($row[$startcol + 0] !== null) ? (string) $row[$startcol + 0] : null;
            $this->sort_order = ($row[$startcol + 1] !== null) ? (int) $row[$startcol + 1] : null;
            $this->label = ($row[$startcol + 2] !== null) ? (string) $row[$startcol + 2] : null;
            $this->page = ($row[$startcol + 3] !== null) ? (string) $row[$startcol + 3] : null;
            $this->always_view = ($row[$startcol + 4] !== null) ? (boolean) $row[$startcol + 4] : null;
            $this->resetModified();

            $this->setNew(false);

            if ($rehydrate) {
                $this->ensureConsistency();
            }
            $this->postHydrate($row, $startcol, $rehydrate);

            return $startcol + 5; // 5 = AppModulePeer::NUM_HYDRATE_COLUMNS.

        } catch (Exception $e) {
            throw new PropelException("Error populating AppModule object", $e);
        }
    }

    /**
     * Checks and repairs the internal consistency of the object.
     *
     * This method is executed after an already-instantiated object is re-hydrated
     * from the database.  It exists to check any foreign keys to make sure that
     * the objects related to the current object are correct based on foreign key.
     *
     * You can override this method in the stub class, but you should always invoke
     * the base method from the overridden method (i.e. parent::ensureConsistency()),
     * in case your model changes.
     *
     * @throws PropelException
     */
    public function ensureConsistency()
    {

    } // ensureConsistency

    /**
     * Reloads this object from datastore based on primary key and (optionally) resets all associated objects.
     *
     * This will only work if the object has been saved and has a valid primary key set.
     *
     * @param boolean $deep (optional) Whether to also de-associated any related objects.
     * @param PropelPDO $con (optional) The PropelPDO connection to use.
     * @return void
     * @throws PropelException - if this object is deleted, unsaved or doesn't have pk match in db
     */
    public function reload($deep = false, PropelPDO $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("Cannot reload a deleted object.");
        }

        if ($this->isNew()) {
            throw new PropelException("Cannot reload an unsaved object.");
        }

        if ($con === null) {
            $con = Propel::getConnection(AppModulePeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        // We don't need to alter the object instance pool; we're just modifying this instance
        // already in the pool.

        $stmt = AppModulePeer::doSelectStmt($this->buildPkeyCriteria(), $con);
        $row = $stmt->fetch(PDO::FETCH_NUM);
        $stmt->closeCursor();
        if (!$row) {
            throw new PropelException('Cannot find matching row in the database to reload object values.');
        }
        $this->hydrate($row, 0, true); // rehydrate

        if ($deep) {  // also de-associate any related objects?

            $this->collAppActions = null;

            $this->collAppProfileAcls = null;

        } // if (deep)
    }

    /**
     * Removes this object from datastore and sets delete attribute.
     *
     * @param PropelPDO $con
     * @return void
     * @throws PropelException
     * @throws Exception
     * @see        BaseObject::setDeleted()
     * @see        BaseObject::isDeleted()
     */
    public function delete(PropelPDO $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("This object has already been deleted.");
        }

        if ($con === null) {
            $con = Propel::getConnection(AppModulePeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        $con->beginTransaction();
        try {
            $deleteQuery = AppModuleQuery::create()
                ->filterByPrimaryKey($this->getPrimaryKey());
            $ret = $this->preDelete($con);
            // sortable behavior

            AppModulePeer::shiftRank(-1, $this->getSortOrder() + 1, null, $con);
            AppModulePeer::clearInstancePool();

            if ($ret) {
                $deleteQuery->delete($con);
                $this->postDelete($con);
                $con->commit();
                $this->setDeleted(true);
            } else {
                $con->commit();
            }
        } catch (Exception $e) {
            $con->rollBack();
            throw $e;
        }
    }

    /**
     * Persists this object to the database.
     *
     * If the object is new, it inserts it; otherwise an update is performed.
     * All modified related objects will also be persisted in the doSave()
     * method.  This method wraps all precipitate database operations in a
     * single transaction.
     *
     * @param PropelPDO $con
     * @return int             The number of rows affected by this insert/update and any referring fk objects' save() operations.
     * @throws PropelException
     * @throws Exception
     * @see        doSave()
     */
    public function save(PropelPDO $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("You cannot save an object that has been deleted.");
        }

        if ($con === null) {
            $con = Propel::getConnection(AppModulePeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        $con->beginTransaction();
        $isInsert = $this->isNew();
        try {
            $ret = $this->preSave($con);
            // sortable behavior
            $this->processSortableQueries($con);
            if ($isInsert) {
                $ret = $ret && $this->preInsert($con);
                // sortable behavior
                if (!$this->isColumnModified(AppModulePeer::RANK_COL)) {
                    $this->setSortOrder(AppModuleQuery::create()->getMaxRankArray($con) + 1);
                }

            } else {
                $ret = $ret && $this->preUpdate($con);
            }
            if ($ret) {
                $affectedRows = $this->doSave($con);
                if ($isInsert) {
                    $this->postInsert($con);
                } else {
                    $this->postUpdate($con);
                }
                $this->postSave($con);
                AppModulePeer::addInstanceToPool($this);
            } else {
                $affectedRows = 0;
            }
            $con->commit();

            return $affectedRows;
        } catch (Exception $e) {
            $con->rollBack();
            throw $e;
        }
    }

    /**
     * Performs the work of inserting or updating the row in the database.
     *
     * If the object is new, it inserts it; otherwise an update is performed.
     * All related objects are also updated in this method.
     *
     * @param PropelPDO $con
     * @return int             The number of rows affected by this insert/update and any referring fk objects' save() operations.
     * @throws PropelException
     * @see        save()
     */
    protected function doSave(PropelPDO $con)
    {
        $affectedRows = 0; // initialize var to track total num of affected rows
        if (!$this->alreadyInSave) {
            $this->alreadyInSave = true;

            if ($this->isNew() || $this->isModified()) {
                // persist changes
                if ($this->isNew()) {
                    $this->doInsert($con);
                } else {
                    $this->doUpdate($con);
                }
                $affectedRows += 1;
                $this->resetModified();
            }

            if ($this->appActionsScheduledForDeletion !== null) {
                if (!$this->appActionsScheduledForDeletion->isEmpty()) {
                    foreach ($this->appActionsScheduledForDeletion as $appAction) {
                        // need to save related object because we set the relation to null
                        $appAction->save($con);
                    }
                    $this->appActionsScheduledForDeletion = null;
                }
            }

            if ($this->collAppActions !== null) {
                foreach ($this->collAppActions as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->appProfileAclsScheduledForDeletion !== null) {
                if (!$this->appProfileAclsScheduledForDeletion->isEmpty()) {
                    AppProfileAclQuery::create()
                        ->filterByPrimaryKeys($this->appProfileAclsScheduledForDeletion->getPrimaryKeys(false))
                        ->delete($con);
                    $this->appProfileAclsScheduledForDeletion = null;
                }
            }

            if ($this->collAppProfileAcls !== null) {
                foreach ($this->collAppProfileAcls as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            $this->alreadyInSave = false;

        }

        return $affectedRows;
    } // doSave()

    /**
     * Insert the row in the database.
     *
     * @param PropelPDO $con
     *
     * @throws PropelException
     * @see        doSave()
     */
    protected function doInsert(PropelPDO $con)
    {
        $modifiedColumns = array();
        $index = 0;


         // check the columns in natural order for more readable SQL queries
        if ($this->isColumnModified(AppModulePeer::MODULE_ID)) {
            $modifiedColumns[':p' . $index++]  = '`module_id`';
        }
        if ($this->isColumnModified(AppModulePeer::SORT_ORDER)) {
            $modifiedColumns[':p' . $index++]  = '`sort_order`';
        }
        if ($this->isColumnModified(AppModulePeer::LABEL)) {
            $modifiedColumns[':p' . $index++]  = '`label`';
        }
        if ($this->isColumnModified(AppModulePeer::PAGE)) {
            $modifiedColumns[':p' . $index++]  = '`page`';
        }
        if ($this->isColumnModified(AppModulePeer::ALWAYS_VIEW)) {
            $modifiedColumns[':p' . $index++]  = '`always_view`';
        }

        $sql = sprintf(
            'INSERT INTO `app_module` (%s) VALUES (%s)',
            implode(', ', $modifiedColumns),
            implode(', ', array_keys($modifiedColumns))
        );

        try {
            $stmt = $con->prepare($sql);
            foreach ($modifiedColumns as $identifier => $columnName) {
                switch ($columnName) {
                    case '`module_id`':
                        $stmt->bindValue($identifier, $this->module_id, PDO::PARAM_STR);
                        break;
                    case '`sort_order`':
                        $stmt->bindValue($identifier, $this->sort_order, PDO::PARAM_INT);
                        break;
                    case '`label`':
                        $stmt->bindValue($identifier, $this->label, PDO::PARAM_STR);
                        break;
                    case '`page`':
                        $stmt->bindValue($identifier, $this->page, PDO::PARAM_STR);
                        break;
                    case '`always_view`':
                        $stmt->bindValue($identifier, (int) $this->always_view, PDO::PARAM_INT);
                        break;
                }
            }
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute INSERT statement [%s]', $sql), $e);
        }

        $this->setNew(false);
    }

    /**
     * Update the row in the database.
     *
     * @param PropelPDO $con
     *
     * @see        doSave()
     */
    protected function doUpdate(PropelPDO $con)
    {
        $selectCriteria = $this->buildPkeyCriteria();
        $valuesCriteria = $this->buildCriteria();
        BasePeer::doUpdate($selectCriteria, $valuesCriteria, $con);
    }

    /**
     * Array of ValidationFailed objects.
     * @var        array ValidationFailed[]
     */
    protected $validationFailures = array();

    /**
     * Gets any ValidationFailed objects that resulted from last call to validate().
     *
     *
     * @return array ValidationFailed[]
     * @see        validate()
     */
    public function getValidationFailures()
    {
        return $this->validationFailures;
    }

    /**
     * Validates the objects modified field values and all objects related to this table.
     *
     * If $columns is either a column name or an array of column names
     * only those columns are validated.
     *
     * @param mixed $columns Column name or an array of column names.
     * @return boolean Whether all columns pass validation.
     * @see        doValidate()
     * @see        getValidationFailures()
     */
    public function validate($columns = null)
    {
        $res = $this->doValidate($columns);
        if ($res === true) {
            $this->validationFailures = array();

            return true;
        }

        $this->validationFailures = $res;

        return false;
    }

    /**
     * This function performs the validation work for complex object models.
     *
     * In addition to checking the current object, all related objects will
     * also be validated.  If all pass then <code>true</code> is returned; otherwise
     * an aggregated array of ValidationFailed objects will be returned.
     *
     * @param array $columns Array of column names to validate.
     * @return mixed <code>true</code> if all validations pass; array of <code>ValidationFailed</code> objects otherwise.
     */
    protected function doValidate($columns = null)
    {
        if (!$this->alreadyInValidation) {
            $this->alreadyInValidation = true;
            $retval = null;

            $failureMap = array();


            if (($retval = AppModulePeer::doValidate($this, $columns)) !== true) {
                $failureMap = array_merge($failureMap, $retval);
            }


                if ($this->collAppActions !== null) {
                    foreach ($this->collAppActions as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collAppProfileAcls !== null) {
                    foreach ($this->collAppProfileAcls as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }


            $this->alreadyInValidation = false;
        }

        return (!empty($failureMap) ? $failureMap : true);
    }

    /**
     * Retrieves a field from the object by name passed in as a string.
     *
     * @param string $name name
     * @param string $type The type of fieldname the $name is of:
     *               one of the class type constants BasePeer::TYPE_PHPNAME, BasePeer::TYPE_STUDLYPHPNAME
     *               BasePeer::TYPE_COLNAME, BasePeer::TYPE_FIELDNAME, BasePeer::TYPE_NUM.
     *               Defaults to BasePeer::TYPE_PHPNAME
     * @return mixed Value of field.
     */
    public function getByName($name, $type = BasePeer::TYPE_PHPNAME)
    {
        $pos = AppModulePeer::translateFieldName($name, $type, BasePeer::TYPE_NUM);
        $field = $this->getByPosition($pos);

        return $field;
    }

    /**
     * Retrieves a field from the object by Position as specified in the xml schema.
     * Zero-based.
     *
     * @param int $pos position in xml schema
     * @return mixed Value of field at $pos
     */
    public function getByPosition($pos)
    {
        switch ($pos) {
            case 0:
                return $this->getModuleId();
                break;
            case 1:
                return $this->getSortOrder();
                break;
            case 2:
                return $this->getLabel();
                break;
            case 3:
                return $this->getPage();
                break;
            case 4:
                return $this->getAlwaysView();
                break;
            default:
                return null;
                break;
        } // switch()
    }

    /**
     * Exports the object as an array.
     *
     * You can specify the key type of the array by passing one of the class
     * type constants.
     *
     * @param     string  $keyType (optional) One of the class type constants BasePeer::TYPE_PHPNAME, BasePeer::TYPE_STUDLYPHPNAME,
     *                    BasePeer::TYPE_COLNAME, BasePeer::TYPE_FIELDNAME, BasePeer::TYPE_NUM.
     *                    Defaults to BasePeer::TYPE_PHPNAME.
     * @param     boolean $includeLazyLoadColumns (optional) Whether to include lazy loaded columns. Defaults to true.
     * @param     array $alreadyDumpedObjects List of objects to skip to avoid recursion
     * @param     boolean $includeForeignObjects (optional) Whether to include hydrated related objects. Default to FALSE.
     *
     * @return array an associative array containing the field names (as keys) and field values
     */
    public function toArray($keyType = BasePeer::TYPE_PHPNAME, $includeLazyLoadColumns = true, $alreadyDumpedObjects = array(), $includeForeignObjects = false)
    {
        if (isset($alreadyDumpedObjects['AppModule'][$this->getPrimaryKey()])) {
            return '*RECURSION*';
        }
        $alreadyDumpedObjects['AppModule'][$this->getPrimaryKey()] = true;
        $keys = AppModulePeer::getFieldNames($keyType);
        $result = array(
            $keys[0] => $this->getModuleId(),
            $keys[1] => $this->getSortOrder(),
            $keys[2] => $this->getLabel(),
            $keys[3] => $this->getPage(),
            $keys[4] => $this->getAlwaysView(),
        );
        $virtualColumns = $this->virtualColumns;
        foreach ($virtualColumns as $key => $virtualColumn) {
            $result[$key] = $virtualColumn;
        }

        if ($includeForeignObjects) {
            if (null !== $this->collAppActions) {
                $result['AppActions'] = $this->collAppActions->toArray(null, true, $keyType, $includeLazyLoadColumns, $alreadyDumpedObjects);
            }
            if (null !== $this->collAppProfileAcls) {
                $result['AppProfileAcls'] = $this->collAppProfileAcls->toArray(null, true, $keyType, $includeLazyLoadColumns, $alreadyDumpedObjects);
            }
        }

        return $result;
    }

    /**
     * Sets a field from the object by name passed in as a string.
     *
     * @param string $name peer name
     * @param mixed $value field value
     * @param string $type The type of fieldname the $name is of:
     *                     one of the class type constants BasePeer::TYPE_PHPNAME, BasePeer::TYPE_STUDLYPHPNAME
     *                     BasePeer::TYPE_COLNAME, BasePeer::TYPE_FIELDNAME, BasePeer::TYPE_NUM.
     *                     Defaults to BasePeer::TYPE_PHPNAME
     * @return void
     */
    public function setByName($name, $value, $type = BasePeer::TYPE_PHPNAME)
    {
        $pos = AppModulePeer::translateFieldName($name, $type, BasePeer::TYPE_NUM);

        $this->setByPosition($pos, $value);
    }

    /**
     * Sets a field from the object by Position as specified in the xml schema.
     * Zero-based.
     *
     * @param int $pos position in xml schema
     * @param mixed $value field value
     * @return void
     */
    public function setByPosition($pos, $value)
    {
        switch ($pos) {
            case 0:
                $this->setModuleId($value);
                break;
            case 1:
                $this->setSortOrder($value);
                break;
            case 2:
                $this->setLabel($value);
                break;
            case 3:
                $this->setPage($value);
                break;
            case 4:
                $this->setAlwaysView($value);
                break;
        } // switch()
    }

    /**
     * Populates the object using an array.
     *
     * This is particularly useful when populating an object from one of the
     * request arrays (e.g. $_POST).  This method goes through the column
     * names, checking to see whether a matching key exists in populated
     * array. If so the setByName() method is called for that column.
     *
     * You can specify the key type of the array by additionally passing one
     * of the class type constants BasePeer::TYPE_PHPNAME, BasePeer::TYPE_STUDLYPHPNAME,
     * BasePeer::TYPE_COLNAME, BasePeer::TYPE_FIELDNAME, BasePeer::TYPE_NUM.
     * The default key type is the column's BasePeer::TYPE_PHPNAME
     *
     * @param array  $arr     An array to populate the object from.
     * @param string $keyType The type of keys the array uses.
     * @return void
     */
    public function fromArray($arr, $keyType = BasePeer::TYPE_PHPNAME)
    {
        $keys = AppModulePeer::getFieldNames($keyType);

        if (array_key_exists($keys[0], $arr)) $this->setModuleId($arr[$keys[0]]);
        if (array_key_exists($keys[1], $arr)) $this->setSortOrder($arr[$keys[1]]);
        if (array_key_exists($keys[2], $arr)) $this->setLabel($arr[$keys[2]]);
        if (array_key_exists($keys[3], $arr)) $this->setPage($arr[$keys[3]]);
        if (array_key_exists($keys[4], $arr)) $this->setAlwaysView($arr[$keys[4]]);
    }

    /**
     * Build a Criteria object containing the values of all modified columns in this object.
     *
     * @return Criteria The Criteria object containing all modified values.
     */
    public function buildCriteria()
    {
        $criteria = new Criteria(AppModulePeer::DATABASE_NAME);

        if ($this->isColumnModified(AppModulePeer::MODULE_ID)) $criteria->add(AppModulePeer::MODULE_ID, $this->module_id);
        if ($this->isColumnModified(AppModulePeer::SORT_ORDER)) $criteria->add(AppModulePeer::SORT_ORDER, $this->sort_order);
        if ($this->isColumnModified(AppModulePeer::LABEL)) $criteria->add(AppModulePeer::LABEL, $this->label);
        if ($this->isColumnModified(AppModulePeer::PAGE)) $criteria->add(AppModulePeer::PAGE, $this->page);
        if ($this->isColumnModified(AppModulePeer::ALWAYS_VIEW)) $criteria->add(AppModulePeer::ALWAYS_VIEW, $this->always_view);

        return $criteria;
    }

    /**
     * Builds a Criteria object containing the primary key for this object.
     *
     * Unlike buildCriteria() this method includes the primary key values regardless
     * of whether or not they have been modified.
     *
     * @return Criteria The Criteria object containing value(s) for primary key(s).
     */
    public function buildPkeyCriteria()
    {
        $criteria = new Criteria(AppModulePeer::DATABASE_NAME);
        $criteria->add(AppModulePeer::MODULE_ID, $this->module_id);

        return $criteria;
    }

    /**
     * Returns the primary key for this object (row).
     * @return string
     */
    public function getPrimaryKey()
    {
        return $this->getModuleId();
    }

    /**
     * Generic method to set the primary key (module_id column).
     *
     * @param  string $key Primary key.
     * @return void
     */
    public function setPrimaryKey($key)
    {
        $this->setModuleId($key);
    }

    /**
     * Returns true if the primary key for this object is null.
     * @return boolean
     */
    public function isPrimaryKeyNull()
    {

        return null === $this->getModuleId();
    }

    /**
     * Sets contents of passed object to values from current object.
     *
     * If desired, this method can also make copies of all associated (fkey referrers)
     * objects.
     *
     * @param object $copyObj An object of AppModule (or compatible) type.
     * @param boolean $deepCopy Whether to also copy all rows that refer (by fkey) to the current row.
     * @param boolean $makeNew Whether to reset autoincrement PKs and make the object new.
     * @throws PropelException
     */
    public function copyInto($copyObj, $deepCopy = false, $makeNew = true)
    {
        $copyObj->setSortOrder($this->getSortOrder());
        $copyObj->setLabel($this->getLabel());
        $copyObj->setPage($this->getPage());
        $copyObj->setAlwaysView($this->getAlwaysView());

        if ($deepCopy && !$this->startCopy) {
            // important: temporarily setNew(false) because this affects the behavior of
            // the getter/setter methods for fkey referrer objects.
            $copyObj->setNew(false);
            // store object hash to prevent cycle
            $this->startCopy = true;

            foreach ($this->getAppActions() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addAppAction($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getAppProfileAcls() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addAppProfileAcl($relObj->copy($deepCopy));
                }
            }

            //unflag object copy
            $this->startCopy = false;
        } // if ($deepCopy)

        if ($makeNew) {
            $copyObj->setNew(true);
            $copyObj->setModuleId(NULL); // this is a auto-increment column, so set to default value
        }
    }

    /**
     * Makes a copy of this object that will be inserted as a new row in table when saved.
     * It creates a new object filling in the simple attributes, but skipping any primary
     * keys that are defined for the table.
     *
     * If desired, this method can also make copies of all associated (fkey referrers)
     * objects.
     *
     * @param boolean $deepCopy Whether to also copy all rows that refer (by fkey) to the current row.
     * @return AppModule Clone of current object.
     * @throws PropelException
     */
    public function copy($deepCopy = false)
    {
        // we use get_class(), because this might be a subclass
        $clazz = get_class($this);
        $copyObj = new $clazz();
        $this->copyInto($copyObj, $deepCopy);

        return $copyObj;
    }

    /**
     * Returns a peer instance associated with this om.
     *
     * Since Peer classes are not to have any instance attributes, this method returns the
     * same instance for all member of this class. The method could therefore
     * be static, but this would prevent one from overriding the behavior.
     *
     * @return AppModulePeer
     */
    public function getPeer()
    {
        if (self::$peer === null) {
            self::$peer = new AppModulePeer();
        }

        return self::$peer;
    }


    /**
     * Initializes a collection based on the name of a relation.
     * Avoids crafting an 'init[$relationName]s' method name
     * that wouldn't work when StandardEnglishPluralizer is used.
     *
     * @param string $relationName The name of the relation to initialize
     * @return void
     */
    public function initRelation($relationName)
    {
        if ('AppAction' == $relationName) {
            $this->initAppActions();
        }
        if ('AppProfileAcl' == $relationName) {
            $this->initAppProfileAcls();
        }
    }

    /**
     * Clears out the collAppActions collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return AppModule The current object (for fluent API support)
     * @see        addAppActions()
     */
    public function clearAppActions()
    {
        $this->collAppActions = null; // important to set this to null since that means it is uninitialized
        $this->collAppActionsPartial = null;

        return $this;
    }

    /**
     * reset is the collAppActions collection loaded partially
     *
     * @return void
     */
    public function resetPartialAppActions($v = true)
    {
        $this->collAppActionsPartial = $v;
    }

    /**
     * Initializes the collAppActions collection.
     *
     * By default this just sets the collAppActions collection to an empty array (like clearcollAppActions());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initAppActions($overrideExisting = true)
    {
        if (null !== $this->collAppActions && !$overrideExisting) {
            return;
        }
        $this->collAppActions = new PropelObjectCollection();
        $this->collAppActions->setModel('AppAction');
    }

    /**
     * Gets an array of AppAction objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this AppModule is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|AppAction[] List of AppAction objects
     * @throws PropelException
     */
    public function getAppActions($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collAppActionsPartial && !$this->isNew();
        if (null === $this->collAppActions || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collAppActions) {
                // return empty collection
                $this->initAppActions();
            } else {
                $collAppActions = AppActionQuery::create(null, $criteria)
                    ->filterByAppModule($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collAppActionsPartial && count($collAppActions)) {
                      $this->initAppActions(false);

                      foreach ($collAppActions as $obj) {
                        if (false == $this->collAppActions->contains($obj)) {
                          $this->collAppActions->append($obj);
                        }
                      }

                      $this->collAppActionsPartial = true;
                    }

                    $collAppActions->getInternalIterator()->rewind();

                    return $collAppActions;
                }

                if ($partial && $this->collAppActions) {
                    foreach ($this->collAppActions as $obj) {
                        if ($obj->isNew()) {
                            $collAppActions[] = $obj;
                        }
                    }
                }

                $this->collAppActions = $collAppActions;
                $this->collAppActionsPartial = false;
            }
        }

        return $this->collAppActions;
    }

    /**
     * Sets a collection of AppAction objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $appActions A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return AppModule The current object (for fluent API support)
     */
    public function setAppActions(PropelCollection $appActions, PropelPDO $con = null)
    {
        $appActionsToDelete = $this->getAppActions(new Criteria(), $con)->diff($appActions);


        $this->appActionsScheduledForDeletion = $appActionsToDelete;

        foreach ($appActionsToDelete as $appActionRemoved) {
            $appActionRemoved->setAppModule(null);
        }

        $this->collAppActions = null;
        foreach ($appActions as $appAction) {
            $this->addAppAction($appAction);
        }

        $this->collAppActions = $appActions;
        $this->collAppActionsPartial = false;

        return $this;
    }

    /**
     * Returns the number of related AppAction objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related AppAction objects.
     * @throws PropelException
     */
    public function countAppActions(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collAppActionsPartial && !$this->isNew();
        if (null === $this->collAppActions || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collAppActions) {
                return 0;
            }

            if ($partial && !$criteria) {
                return count($this->getAppActions());
            }
            $query = AppActionQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByAppModule($this)
                ->count($con);
        }

        return count($this->collAppActions);
    }

    /**
     * Method called to associate a AppAction object to this object
     * through the AppAction foreign key attribute.
     *
     * @param    AppAction $l AppAction
     * @return AppModule The current object (for fluent API support)
     */
    public function addAppAction(AppAction $l)
    {
        if ($this->collAppActions === null) {
            $this->initAppActions();
            $this->collAppActionsPartial = true;
        }

        if (!in_array($l, $this->collAppActions->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddAppAction($l);

            if ($this->appActionsScheduledForDeletion and $this->appActionsScheduledForDeletion->contains($l)) {
                $this->appActionsScheduledForDeletion->remove($this->appActionsScheduledForDeletion->search($l));
            }
        }

        return $this;
    }

    /**
     * @param	AppAction $appAction The appAction object to add.
     */
    protected function doAddAppAction($appAction)
    {
        $this->collAppActions[]= $appAction;
        $appAction->setAppModule($this);
    }

    /**
     * @param	AppAction $appAction The appAction object to remove.
     * @return AppModule The current object (for fluent API support)
     */
    public function removeAppAction($appAction)
    {
        if ($this->getAppActions()->contains($appAction)) {
            $this->collAppActions->remove($this->collAppActions->search($appAction));
            if (null === $this->appActionsScheduledForDeletion) {
                $this->appActionsScheduledForDeletion = clone $this->collAppActions;
                $this->appActionsScheduledForDeletion->clear();
            }
            $this->appActionsScheduledForDeletion[]= $appAction;
            $appAction->setAppModule(null);
        }

        return $this;
    }

    /**
     * Clears out the collAppProfileAcls collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return AppModule The current object (for fluent API support)
     * @see        addAppProfileAcls()
     */
    public function clearAppProfileAcls()
    {
        $this->collAppProfileAcls = null; // important to set this to null since that means it is uninitialized
        $this->collAppProfileAclsPartial = null;

        return $this;
    }

    /**
     * reset is the collAppProfileAcls collection loaded partially
     *
     * @return void
     */
    public function resetPartialAppProfileAcls($v = true)
    {
        $this->collAppProfileAclsPartial = $v;
    }

    /**
     * Initializes the collAppProfileAcls collection.
     *
     * By default this just sets the collAppProfileAcls collection to an empty array (like clearcollAppProfileAcls());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initAppProfileAcls($overrideExisting = true)
    {
        if (null !== $this->collAppProfileAcls && !$overrideExisting) {
            return;
        }
        $this->collAppProfileAcls = new PropelObjectCollection();
        $this->collAppProfileAcls->setModel('AppProfileAcl');
    }

    /**
     * Gets an array of AppProfileAcl objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this AppModule is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|AppProfileAcl[] List of AppProfileAcl objects
     * @throws PropelException
     */
    public function getAppProfileAcls($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collAppProfileAclsPartial && !$this->isNew();
        if (null === $this->collAppProfileAcls || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collAppProfileAcls) {
                // return empty collection
                $this->initAppProfileAcls();
            } else {
                $collAppProfileAcls = AppProfileAclQuery::create(null, $criteria)
                    ->filterByAppModule($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collAppProfileAclsPartial && count($collAppProfileAcls)) {
                      $this->initAppProfileAcls(false);

                      foreach ($collAppProfileAcls as $obj) {
                        if (false == $this->collAppProfileAcls->contains($obj)) {
                          $this->collAppProfileAcls->append($obj);
                        }
                      }

                      $this->collAppProfileAclsPartial = true;
                    }

                    $collAppProfileAcls->getInternalIterator()->rewind();

                    return $collAppProfileAcls;
                }

                if ($partial && $this->collAppProfileAcls) {
                    foreach ($this->collAppProfileAcls as $obj) {
                        if ($obj->isNew()) {
                            $collAppProfileAcls[] = $obj;
                        }
                    }
                }

                $this->collAppProfileAcls = $collAppProfileAcls;
                $this->collAppProfileAclsPartial = false;
            }
        }

        return $this->collAppProfileAcls;
    }

    /**
     * Sets a collection of AppProfileAcl objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $appProfileAcls A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return AppModule The current object (for fluent API support)
     */
    public function setAppProfileAcls(PropelCollection $appProfileAcls, PropelPDO $con = null)
    {
        $appProfileAclsToDelete = $this->getAppProfileAcls(new Criteria(), $con)->diff($appProfileAcls);


        //since at least one column in the foreign key is at the same time a PK
        //we can not just set a PK to NULL in the lines below. We have to store
        //a backup of all values, so we are able to manipulate these items based on the onDelete value later.
        $this->appProfileAclsScheduledForDeletion = clone $appProfileAclsToDelete;

        foreach ($appProfileAclsToDelete as $appProfileAclRemoved) {
            $appProfileAclRemoved->setAppModule(null);
        }

        $this->collAppProfileAcls = null;
        foreach ($appProfileAcls as $appProfileAcl) {
            $this->addAppProfileAcl($appProfileAcl);
        }

        $this->collAppProfileAcls = $appProfileAcls;
        $this->collAppProfileAclsPartial = false;

        return $this;
    }

    /**
     * Returns the number of related AppProfileAcl objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related AppProfileAcl objects.
     * @throws PropelException
     */
    public function countAppProfileAcls(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collAppProfileAclsPartial && !$this->isNew();
        if (null === $this->collAppProfileAcls || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collAppProfileAcls) {
                return 0;
            }

            if ($partial && !$criteria) {
                return count($this->getAppProfileAcls());
            }
            $query = AppProfileAclQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByAppModule($this)
                ->count($con);
        }

        return count($this->collAppProfileAcls);
    }

    /**
     * Method called to associate a AppProfileAcl object to this object
     * through the AppProfileAcl foreign key attribute.
     *
     * @param    AppProfileAcl $l AppProfileAcl
     * @return AppModule The current object (for fluent API support)
     */
    public function addAppProfileAcl(AppProfileAcl $l)
    {
        if ($this->collAppProfileAcls === null) {
            $this->initAppProfileAcls();
            $this->collAppProfileAclsPartial = true;
        }

        if (!in_array($l, $this->collAppProfileAcls->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddAppProfileAcl($l);

            if ($this->appProfileAclsScheduledForDeletion and $this->appProfileAclsScheduledForDeletion->contains($l)) {
                $this->appProfileAclsScheduledForDeletion->remove($this->appProfileAclsScheduledForDeletion->search($l));
            }
        }

        return $this;
    }

    /**
     * @param	AppProfileAcl $appProfileAcl The appProfileAcl object to add.
     */
    protected function doAddAppProfileAcl($appProfileAcl)
    {
        $this->collAppProfileAcls[]= $appProfileAcl;
        $appProfileAcl->setAppModule($this);
    }

    /**
     * @param	AppProfileAcl $appProfileAcl The appProfileAcl object to remove.
     * @return AppModule The current object (for fluent API support)
     */
    public function removeAppProfileAcl($appProfileAcl)
    {
        if ($this->getAppProfileAcls()->contains($appProfileAcl)) {
            $this->collAppProfileAcls->remove($this->collAppProfileAcls->search($appProfileAcl));
            if (null === $this->appProfileAclsScheduledForDeletion) {
                $this->appProfileAclsScheduledForDeletion = clone $this->collAppProfileAcls;
                $this->appProfileAclsScheduledForDeletion->clear();
            }
            $this->appProfileAclsScheduledForDeletion[]= clone $appProfileAcl;
            $appProfileAcl->setAppModule(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this AppModule is new, it will return
     * an empty collection; or if this AppModule has previously
     * been saved, it will retrieve related AppProfileAcls from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in AppModule.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|AppProfileAcl[] List of AppProfileAcl objects
     */
    public function getAppProfileAclsJoinAppProfile($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = AppProfileAclQuery::create(null, $criteria);
        $query->joinWith('AppProfile', $join_behavior);

        return $this->getAppProfileAcls($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this AppModule is new, it will return
     * an empty collection; or if this AppModule has previously
     * been saved, it will retrieve related AppProfileAcls from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in AppModule.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|AppProfileAcl[] List of AppProfileAcl objects
     */
    public function getAppProfileAclsJoinAppAction($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = AppProfileAclQuery::create(null, $criteria);
        $query->joinWith('AppAction', $join_behavior);

        return $this->getAppProfileAcls($query, $con);
    }

    /**
     * Clears the current object and sets all attributes to their default values
     */
    public function clear()
    {
        $this->module_id = null;
        $this->sort_order = null;
        $this->label = null;
        $this->page = null;
        $this->always_view = null;
        $this->alreadyInSave = false;
        $this->alreadyInValidation = false;
        $this->alreadyInClearAllReferencesDeep = false;
        $this->clearAllReferences();
        $this->applyDefaultValues();
        $this->resetModified();
        $this->setNew(true);
        $this->setDeleted(false);
    }

    /**
     * Resets all references to other model objects or collections of model objects.
     *
     * This method is a user-space workaround for PHP's inability to garbage collect
     * objects with circular references (even in PHP 5.3). This is currently necessary
     * when using Propel in certain daemon or large-volume/high-memory operations.
     *
     * @param boolean $deep Whether to also clear the references on all referrer objects.
     */
    public function clearAllReferences($deep = false)
    {
        if ($deep && !$this->alreadyInClearAllReferencesDeep) {
            $this->alreadyInClearAllReferencesDeep = true;
            if ($this->collAppActions) {
                foreach ($this->collAppActions as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collAppProfileAcls) {
                foreach ($this->collAppProfileAcls as $o) {
                    $o->clearAllReferences($deep);
                }
            }

            $this->alreadyInClearAllReferencesDeep = false;
        } // if ($deep)

        if ($this->collAppActions instanceof PropelCollection) {
            $this->collAppActions->clearIterator();
        }
        $this->collAppActions = null;
        if ($this->collAppProfileAcls instanceof PropelCollection) {
            $this->collAppProfileAcls->clearIterator();
        }
        $this->collAppProfileAcls = null;
    }

    /**
     * return the string representation of this object
     *
     * @return string
     */
    public function __toString()
    {
        return (string) $this->exportTo(AppModulePeer::DEFAULT_STRING_FORMAT);
    }

    /**
     * return true is the object is in saving state
     *
     * @return boolean
     */
    public function isAlreadyInSave()
    {
        return $this->alreadyInSave;
    }

    // sortable behavior

    /**
     * Wrap the getter for rank value
     *
     * @return    int
     */
    public function getRank()
    {
        return $this->sort_order;
    }

    /**
     * Wrap the setter for rank value
     *
     * @param     int
     * @return    AppModule
     */
    public function setRank($v)
    {
        return $this->setSortOrder($v);
    }

    /**
     * Check if the object is first in the list, i.e. if it has 1 for rank
     *
     * @return    boolean
     */
    public function isFirst()
    {
        return $this->getSortOrder() == 1;
    }

    /**
     * Check if the object is last in the list, i.e. if its rank is the highest rank
     *
     * @param     PropelPDO  $con      optional connection
     *
     * @return    boolean
     */
    public function isLast(PropelPDO $con = null)
    {
        return $this->getSortOrder() == AppModuleQuery::create()->getMaxRankArray($con);
    }

    /**
     * Get the next item in the list, i.e. the one for which rank is immediately higher
     *
     * @param     PropelPDO  $con      optional connection
     *
     * @return    AppModule
     */
    public function getNext(PropelPDO $con = null)
    {

        $query = AppModuleQuery::create();

        $query->filterByRank($this->getSortOrder() + 1);


        return $query->findOne($con);
    }

    /**
     * Get the previous item in the list, i.e. the one for which rank is immediately lower
     *
     * @param     PropelPDO  $con      optional connection
     *
     * @return    AppModule
     */
    public function getPrevious(PropelPDO $con = null)
    {

        $query = AppModuleQuery::create();

        $query->filterByRank($this->getSortOrder() - 1);


        return $query->findOne($con);
    }

    /**
     * Insert at specified rank
     * The modifications are not persisted until the object is saved.
     *
     * @param     integer    $rank rank value
     * @param     PropelPDO  $con      optional connection
     *
     * @return    AppModule the current object
     *
     * @throws    PropelException
     */
    public function insertAtRank($rank, PropelPDO $con = null)
    {
        $maxRank = AppModuleQuery::create()->getMaxRankArray($con);
        if ($rank < 1 || $rank > $maxRank + 1) {
            throw new PropelException('Invalid rank ' . $rank);
        }
        // move the object in the list, at the given rank
        $this->setSortOrder($rank);
        if ($rank != $maxRank + 1) {
            // Keep the list modification query for the save() transaction
            $this->sortableQueries []= array(
                'callable'  => array(self::PEER, 'shiftRank'),
                'arguments' => array(1, $rank, null, )
            );
        }

        return $this;
    }

    /**
     * Insert in the last rank
     * The modifications are not persisted until the object is saved.
     *
     * @param PropelPDO $con optional connection
     *
     * @return    AppModule the current object
     *
     * @throws    PropelException
     */
    public function insertAtBottom(PropelPDO $con = null)
    {
        $this->setSortOrder(AppModuleQuery::create()->getMaxRankArray($con) + 1);

        return $this;
    }

    /**
     * Insert in the first rank
     * The modifications are not persisted until the object is saved.
     *
     * @return    AppModule the current object
     */
    public function insertAtTop()
    {
        return $this->insertAtRank(1);
    }

    /**
     * Move the object to a new rank, and shifts the rank
     * Of the objects inbetween the old and new rank accordingly
     *
     * @param     integer   $newRank rank value
     * @param     PropelPDO $con optional connection
     *
     * @return    AppModule the current object
     *
     * @throws    PropelException
     */
    public function moveToRank($newRank, PropelPDO $con = null)
    {
        if ($this->isNew()) {
            throw new PropelException('New objects cannot be moved. Please use insertAtRank() instead');
        }
        if ($con === null) {
            $con = Propel::getConnection(AppModulePeer::DATABASE_NAME);
        }
        if ($newRank < 1 || $newRank > AppModuleQuery::create()->getMaxRankArray($con)) {
            throw new PropelException('Invalid rank ' . $newRank);
        }

        $oldRank = $this->getSortOrder();
        if ($oldRank == $newRank) {
            return $this;
        }

        $con->beginTransaction();
        try {
            // shift the objects between the old and the new rank
            $delta = ($oldRank < $newRank) ? -1 : 1;
            AppModulePeer::shiftRank($delta, min($oldRank, $newRank), max($oldRank, $newRank), $con);

            // move the object to its new rank
            $this->setSortOrder($newRank);
            $this->save($con);

            $con->commit();

            return $this;
        } catch (Exception $e) {
            $con->rollback();
            throw $e;
        }
    }

    /**
     * Exchange the rank of the object with the one passed as argument, and saves both objects
     *
     * @param     AppModule $object
     * @param     PropelPDO $con optional connection
     *
     * @return    AppModule the current object
     *
     * @throws Exception if the database cannot execute the two updates
     */
    public function swapWith($object, PropelPDO $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection(AppModulePeer::DATABASE_NAME);
        }
        $con->beginTransaction();
        try {
            $oldRank = $this->getSortOrder();
            $newRank = $object->getSortOrder();
            $this->setSortOrder($newRank);
            $this->save($con);
            $object->setSortOrder($oldRank);
            $object->save($con);
            $con->commit();

            return $this;
        } catch (Exception $e) {
            $con->rollback();
            throw $e;
        }
    }

    /**
     * Move the object higher in the list, i.e. exchanges its rank with the one of the previous object
     *
     * @param     PropelPDO $con optional connection
     *
     * @return    AppModule the current object
     */
    public function moveUp(PropelPDO $con = null)
    {
        if ($this->isFirst()) {
            return $this;
        }
        if ($con === null) {
            $con = Propel::getConnection(AppModulePeer::DATABASE_NAME);
        }
        $con->beginTransaction();
        try {
            $prev = $this->getPrevious($con);
            $this->swapWith($prev, $con);
            $con->commit();

            return $this;
        } catch (Exception $e) {
            $con->rollback();
            throw $e;
        }
    }

    /**
     * Move the object higher in the list, i.e. exchanges its rank with the one of the next object
     *
     * @param     PropelPDO $con optional connection
     *
     * @return    AppModule the current object
     */
    public function moveDown(PropelPDO $con = null)
    {
        if ($this->isLast($con)) {
            return $this;
        }
        if ($con === null) {
            $con = Propel::getConnection(AppModulePeer::DATABASE_NAME);
        }
        $con->beginTransaction();
        try {
            $next = $this->getNext($con);
            $this->swapWith($next, $con);
            $con->commit();

            return $this;
        } catch (Exception $e) {
            $con->rollback();
            throw $e;
        }
    }

    /**
     * Move the object to the top of the list
     *
     * @param     PropelPDO $con optional connection
     *
     * @return    AppModule the current object
     */
    public function moveToTop(PropelPDO $con = null)
    {
        if ($this->isFirst()) {
            return $this;
        }

        return $this->moveToRank(1, $con);
    }

    /**
     * Move the object to the bottom of the list
     *
     * @param     PropelPDO $con optional connection
     *
     * @return integer the old object's rank
     */
    public function moveToBottom(PropelPDO $con = null)
    {
        if ($this->isLast($con)) {
            return false;
        }
        if ($con === null) {
            $con = Propel::getConnection(AppModulePeer::DATABASE_NAME);
        }
        $con->beginTransaction();
        try {
            $bottom = AppModuleQuery::create()->getMaxRankArray($con);
            $res = $this->moveToRank($bottom, $con);
            $con->commit();

            return $res;
        } catch (Exception $e) {
            $con->rollback();
            throw $e;
        }
    }

    /**
     * Removes the current object from the list.
     * The modifications are not persisted until the object is saved.
     *
     * @param     PropelPDO $con optional connection
     *
     * @return    AppModule the current object
     */
    public function removeFromList(PropelPDO $con = null)
    {
        // Keep the list modification query for the save() transaction
        $this->sortableQueries []= array(
            'callable'  => array(self::PEER, 'shiftRank'),
            'arguments' => array(-1, $this->getSortOrder() + 1, null)
        );
        // remove the object from the list
        $this->setSortOrder(null);

        return $this;
    }

    /**
     * Execute queries that were saved to be run inside the save transaction
     */
    protected function processSortableQueries($con)
    {
        foreach ($this->sortableQueries as $query) {
            $query['arguments'][]= $con;
            call_user_func_array($query['callable'], $query['arguments']);
        }
        $this->sortableQueries = array();
    }

}
