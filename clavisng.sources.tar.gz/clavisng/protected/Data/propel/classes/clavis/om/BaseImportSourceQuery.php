<?php


/**
 * Base class that represents a query for the 'import_source' table.
 *
 *
 *
 * @method ImportSourceQuery orderByName($order = Criteria::ASC) Order by the name column
 * @method ImportSourceQuery orderByLabel($order = Criteria::ASC) Order by the label column
 * @method ImportSourceQuery orderByDriver($order = Criteria::ASC) Order by the driver column
 * @method ImportSourceQuery orderByAddress($order = Criteria::ASC) Order by the address column
 * @method ImportSourceQuery orderByEnabled($order = Criteria::ASC) Order by the enabled column
 * @method ImportSourceQuery orderBySelected($order = Criteria::ASC) Order by the selected column
 * @method ImportSourceQuery orderByTimeout($order = Criteria::ASC) Order by the timeout column
 * @method ImportSourceQuery orderByEncoding($order = Criteria::ASC) Order by the encoding column
 * @method ImportSourceQuery orderBySearchFields($order = Criteria::ASC) Order by the search_fields column
 * @method ImportSourceQuery orderBySyntax($order = Criteria::ASC) Order by the syntax column
 * @method ImportSourceQuery orderByFormat($order = Criteria::ASC) Order by the format column
 * @method ImportSourceQuery orderByTurbomarcConversion($order = Criteria::ASC) Order by the turbomarc_conversion column
 * @method ImportSourceQuery orderByOptions($order = Criteria::ASC) Order by the options column
 * @method ImportSourceQuery orderByDefaultCatlevel($order = Criteria::ASC) Order by the default_catlevel column
 * @method ImportSourceQuery orderBySortableRank($order = Criteria::ASC) Order by the sortable_rank column
 * @method ImportSourceQuery orderByDateCreated($order = Criteria::ASC) Order by the date_created column
 * @method ImportSourceQuery orderByDateUpdated($order = Criteria::ASC) Order by the date_updated column
 * @method ImportSourceQuery orderByCreatedBy($order = Criteria::ASC) Order by the created_by column
 * @method ImportSourceQuery orderByModifiedBy($order = Criteria::ASC) Order by the modified_by column
 *
 * @method ImportSourceQuery groupByName() Group by the name column
 * @method ImportSourceQuery groupByLabel() Group by the label column
 * @method ImportSourceQuery groupByDriver() Group by the driver column
 * @method ImportSourceQuery groupByAddress() Group by the address column
 * @method ImportSourceQuery groupByEnabled() Group by the enabled column
 * @method ImportSourceQuery groupBySelected() Group by the selected column
 * @method ImportSourceQuery groupByTimeout() Group by the timeout column
 * @method ImportSourceQuery groupByEncoding() Group by the encoding column
 * @method ImportSourceQuery groupBySearchFields() Group by the search_fields column
 * @method ImportSourceQuery groupBySyntax() Group by the syntax column
 * @method ImportSourceQuery groupByFormat() Group by the format column
 * @method ImportSourceQuery groupByTurbomarcConversion() Group by the turbomarc_conversion column
 * @method ImportSourceQuery groupByOptions() Group by the options column
 * @method ImportSourceQuery groupByDefaultCatlevel() Group by the default_catlevel column
 * @method ImportSourceQuery groupBySortableRank() Group by the sortable_rank column
 * @method ImportSourceQuery groupByDateCreated() Group by the date_created column
 * @method ImportSourceQuery groupByDateUpdated() Group by the date_updated column
 * @method ImportSourceQuery groupByCreatedBy() Group by the created_by column
 * @method ImportSourceQuery groupByModifiedBy() Group by the modified_by column
 *
 * @method ImportSourceQuery leftJoin($relation) Adds a LEFT JOIN clause to the query
 * @method ImportSourceQuery rightJoin($relation) Adds a RIGHT JOIN clause to the query
 * @method ImportSourceQuery innerJoin($relation) Adds a INNER JOIN clause to the query
 *
 * @method ImportSourceQuery leftJoinLibrarianRelatedByCreatedBy($relationAlias = null) Adds a LEFT JOIN clause to the query using the LibrarianRelatedByCreatedBy relation
 * @method ImportSourceQuery rightJoinLibrarianRelatedByCreatedBy($relationAlias = null) Adds a RIGHT JOIN clause to the query using the LibrarianRelatedByCreatedBy relation
 * @method ImportSourceQuery innerJoinLibrarianRelatedByCreatedBy($relationAlias = null) Adds a INNER JOIN clause to the query using the LibrarianRelatedByCreatedBy relation
 *
 * @method ImportSourceQuery leftJoinLibrarianRelatedByModifiedBy($relationAlias = null) Adds a LEFT JOIN clause to the query using the LibrarianRelatedByModifiedBy relation
 * @method ImportSourceQuery rightJoinLibrarianRelatedByModifiedBy($relationAlias = null) Adds a RIGHT JOIN clause to the query using the LibrarianRelatedByModifiedBy relation
 * @method ImportSourceQuery innerJoinLibrarianRelatedByModifiedBy($relationAlias = null) Adds a INNER JOIN clause to the query using the LibrarianRelatedByModifiedBy relation
 *
 * @method ImportSource findOne(PropelPDO $con = null) Return the first ImportSource matching the query
 * @method ImportSource findOneOrCreate(PropelPDO $con = null) Return the first ImportSource matching the query, or a new ImportSource object populated from the query conditions when no match is found
 *
 * @method ImportSource findOneByLabel(string $label) Return the first ImportSource filtered by the label column
 * @method ImportSource findOneByDriver(string $driver) Return the first ImportSource filtered by the driver column
 * @method ImportSource findOneByAddress(string $address) Return the first ImportSource filtered by the address column
 * @method ImportSource findOneByEnabled(boolean $enabled) Return the first ImportSource filtered by the enabled column
 * @method ImportSource findOneBySelected(boolean $selected) Return the first ImportSource filtered by the selected column
 * @method ImportSource findOneByTimeout(int $timeout) Return the first ImportSource filtered by the timeout column
 * @method ImportSource findOneByEncoding(string $encoding) Return the first ImportSource filtered by the encoding column
 * @method ImportSource findOneBySearchFields(array $search_fields) Return the first ImportSource filtered by the search_fields column
 * @method ImportSource findOneBySyntax(string $syntax) Return the first ImportSource filtered by the syntax column
 * @method ImportSource findOneByFormat(string $format) Return the first ImportSource filtered by the format column
 * @method ImportSource findOneByTurbomarcConversion(array $turbomarc_conversion) Return the first ImportSource filtered by the turbomarc_conversion column
 * @method ImportSource findOneByOptions(string $options) Return the first ImportSource filtered by the options column
 * @method ImportSource findOneByDefaultCatlevel(string $default_catlevel) Return the first ImportSource filtered by the default_catlevel column
 * @method ImportSource findOneBySortableRank(int $sortable_rank) Return the first ImportSource filtered by the sortable_rank column
 * @method ImportSource findOneByDateCreated(string $date_created) Return the first ImportSource filtered by the date_created column
 * @method ImportSource findOneByDateUpdated(string $date_updated) Return the first ImportSource filtered by the date_updated column
 * @method ImportSource findOneByCreatedBy(int $created_by) Return the first ImportSource filtered by the created_by column
 * @method ImportSource findOneByModifiedBy(int $modified_by) Return the first ImportSource filtered by the modified_by column
 *
 * @method array findByName(string $name) Return ImportSource objects filtered by the name column
 * @method array findByLabel(string $label) Return ImportSource objects filtered by the label column
 * @method array findByDriver(string $driver) Return ImportSource objects filtered by the driver column
 * @method array findByAddress(string $address) Return ImportSource objects filtered by the address column
 * @method array findByEnabled(boolean $enabled) Return ImportSource objects filtered by the enabled column
 * @method array findBySelected(boolean $selected) Return ImportSource objects filtered by the selected column
 * @method array findByTimeout(int $timeout) Return ImportSource objects filtered by the timeout column
 * @method array findByEncoding(string $encoding) Return ImportSource objects filtered by the encoding column
 * @method array findBySearchFields(array $search_fields) Return ImportSource objects filtered by the search_fields column
 * @method array findBySyntax(string $syntax) Return ImportSource objects filtered by the syntax column
 * @method array findByFormat(string $format) Return ImportSource objects filtered by the format column
 * @method array findByTurbomarcConversion(array $turbomarc_conversion) Return ImportSource objects filtered by the turbomarc_conversion column
 * @method array findByOptions(string $options) Return ImportSource objects filtered by the options column
 * @method array findByDefaultCatlevel(string $default_catlevel) Return ImportSource objects filtered by the default_catlevel column
 * @method array findBySortableRank(int $sortable_rank) Return ImportSource objects filtered by the sortable_rank column
 * @method array findByDateCreated(string $date_created) Return ImportSource objects filtered by the date_created column
 * @method array findByDateUpdated(string $date_updated) Return ImportSource objects filtered by the date_updated column
 * @method array findByCreatedBy(int $created_by) Return ImportSource objects filtered by the created_by column
 * @method array findByModifiedBy(int $modified_by) Return ImportSource objects filtered by the modified_by column
 *
 * @package    propel.generator.clavis.om
 */
abstract class BaseImportSourceQuery extends ModelCriteria
{
    /**
     * Initializes internal state of BaseImportSourceQuery object.
     *
     * @param     string $dbName The dabase name
     * @param     string $modelName The phpName of a model, e.g. 'Book'
     * @param     string $modelAlias The alias for the model in this query, e.g. 'b'
     */
    public function __construct($dbName = null, $modelName = null, $modelAlias = null)
    {
        if (null === $dbName) {
            $dbName = 'clavis';
        }
        if (null === $modelName) {
            $modelName = 'ImportSource';
        }
        parent::__construct($dbName, $modelName, $modelAlias);
    }

    /**
     * Returns a new ImportSourceQuery object.
     *
     * @param     string $modelAlias The alias of a model in the query
     * @param   ImportSourceQuery|Criteria $criteria Optional Criteria to build the query from
     *
     * @return ImportSourceQuery
     */
    public static function create($modelAlias = null, $criteria = null)
    {
        if ($criteria instanceof ImportSourceQuery) {
            return $criteria;
        }
        $query = new ImportSourceQuery(null, null, $modelAlias);

        if ($criteria instanceof Criteria) {
            $query->mergeWith($criteria);
        }

        return $query;
    }

    /**
     * Find object by primary key.
     * Propel uses the instance pool to skip the database if the object exists.
     * Go fast if the query is untouched.
     *
     * <code>
     * $obj  = $c->findPk(12, $con);
     * </code>
     *
     * @param mixed $key Primary key to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return   ImportSource|ImportSource[]|mixed the result, formatted by the current formatter
     */
    public function findPk($key, $con = null)
    {
        if ($key === null) {
            return null;
        }
        if ((null !== ($obj = ImportSourcePeer::getInstanceFromPool((string) $key))) && !$this->formatter) {
            // the object is already in the instance pool
            return $obj;
        }
        if ($con === null) {
            $con = Propel::getConnection(ImportSourcePeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        if ($this->formatter || $this->modelAlias || $this->with || $this->select
         || $this->selectColumns || $this->asColumns || $this->selectModifiers
         || $this->map || $this->having || $this->joins) {
            return $this->findPkComplex($key, $con);
        } else {
            return $this->findPkSimple($key, $con);
        }
    }

    /**
     * Alias of findPk to use instance pooling
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 ImportSource A model object, or null if the key is not found
     * @throws PropelException
     */
     public function findOneByName($key, $con = null)
     {
        return $this->findPk($key, $con);
     }

    /**
     * Find object by primary key using raw SQL to go fast.
     * Bypass doSelect() and the object formatter by using generated code.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 ImportSource A model object, or null if the key is not found
     * @throws PropelException
     */
    protected function findPkSimple($key, $con)
    {
        $sql = 'SELECT `name`, `label`, `driver`, `address`, `enabled`, `selected`, `timeout`, `encoding`, `search_fields`, `syntax`, `format`, `turbomarc_conversion`, `options`, `default_catlevel`, `sortable_rank`, `date_created`, `date_updated`, `created_by`, `modified_by` FROM `import_source` WHERE `name` = :p0';
        try {
            $stmt = $con->prepare($sql);
            $stmt->bindValue(':p0', $key, PDO::PARAM_STR);
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute SELECT statement [%s]', $sql), $e);
        }
        $obj = null;
        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $obj = new ImportSource();
            $obj->hydrate($row);
            ImportSourcePeer::addInstanceToPool($obj, (string) $key);
        }
        $stmt->closeCursor();

        return $obj;
    }

    /**
     * Find object by primary key.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return ImportSource|ImportSource[]|mixed the result, formatted by the current formatter
     */
    protected function findPkComplex($key, $con)
    {
        // As the query uses a PK condition, no limit(1) is necessary.
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKey($key)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->formatOne($stmt);
    }

    /**
     * Find objects by primary key
     * <code>
     * $objs = $c->findPks(array(12, 56, 832), $con);
     * </code>
     * @param     array $keys Primary keys to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return PropelObjectCollection|ImportSource[]|mixed the list of results, formatted by the current formatter
     */
    public function findPks($keys, $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection($this->getDbName(), Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKeys($keys)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->format($stmt);
    }

    /**
     * Filter the query by primary key
     *
     * @param     mixed $key Primary key to use for the query
     *
     * @return ImportSourceQuery The current query, for fluid interface
     */
    public function filterByPrimaryKey($key)
    {

        return $this->addUsingAlias(ImportSourcePeer::NAME, $key, Criteria::EQUAL);
    }

    /**
     * Filter the query by a list of primary keys
     *
     * @param     array $keys The list of primary key to use for the query
     *
     * @return ImportSourceQuery The current query, for fluid interface
     */
    public function filterByPrimaryKeys($keys)
    {

        return $this->addUsingAlias(ImportSourcePeer::NAME, $keys, Criteria::IN);
    }

    /**
     * Filter the query on the name column
     *
     * Example usage:
     * <code>
     * $query->filterByName('fooValue');   // WHERE name = 'fooValue'
     * $query->filterByName('%fooValue%'); // WHERE name LIKE '%fooValue%'
     * </code>
     *
     * @param     string $name The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ImportSourceQuery The current query, for fluid interface
     */
    public function filterByName($name = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($name)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $name)) {
                $name = str_replace('*', '%', $name);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(ImportSourcePeer::NAME, $name, $comparison);
    }

    /**
     * Filter the query on the label column
     *
     * Example usage:
     * <code>
     * $query->filterByLabel('fooValue');   // WHERE label = 'fooValue'
     * $query->filterByLabel('%fooValue%'); // WHERE label LIKE '%fooValue%'
     * </code>
     *
     * @param     string $label The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ImportSourceQuery The current query, for fluid interface
     */
    public function filterByLabel($label = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($label)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $label)) {
                $label = str_replace('*', '%', $label);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(ImportSourcePeer::LABEL, $label, $comparison);
    }

    /**
     * Filter the query on the driver column
     *
     * Example usage:
     * <code>
     * $query->filterByDriver('fooValue');   // WHERE driver = 'fooValue'
     * $query->filterByDriver('%fooValue%'); // WHERE driver LIKE '%fooValue%'
     * </code>
     *
     * @param     string $driver The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ImportSourceQuery The current query, for fluid interface
     */
    public function filterByDriver($driver = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($driver)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $driver)) {
                $driver = str_replace('*', '%', $driver);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(ImportSourcePeer::DRIVER, $driver, $comparison);
    }

    /**
     * Filter the query on the address column
     *
     * Example usage:
     * <code>
     * $query->filterByAddress('fooValue');   // WHERE address = 'fooValue'
     * $query->filterByAddress('%fooValue%'); // WHERE address LIKE '%fooValue%'
     * </code>
     *
     * @param     string $address The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ImportSourceQuery The current query, for fluid interface
     */
    public function filterByAddress($address = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($address)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $address)) {
                $address = str_replace('*', '%', $address);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(ImportSourcePeer::ADDRESS, $address, $comparison);
    }

    /**
     * Filter the query on the enabled column
     *
     * Example usage:
     * <code>
     * $query->filterByEnabled(true); // WHERE enabled = true
     * $query->filterByEnabled('yes'); // WHERE enabled = true
     * </code>
     *
     * @param     boolean|string $enabled The value to use as filter.
     *              Non-boolean arguments are converted using the following rules:
     *                * 1, '1', 'true',  'on',  and 'yes' are converted to boolean true
     *                * 0, '0', 'false', 'off', and 'no'  are converted to boolean false
     *              Check on string values is case insensitive (so 'FaLsE' is seen as 'false').
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ImportSourceQuery The current query, for fluid interface
     */
    public function filterByEnabled($enabled = null, $comparison = null)
    {
        if (is_string($enabled)) {
            $enabled = in_array(strtolower($enabled), array('false', 'off', '-', 'no', 'n', '0', '')) ? false : true;
        }

        return $this->addUsingAlias(ImportSourcePeer::ENABLED, $enabled, $comparison);
    }

    /**
     * Filter the query on the selected column
     *
     * Example usage:
     * <code>
     * $query->filterBySelected(true); // WHERE selected = true
     * $query->filterBySelected('yes'); // WHERE selected = true
     * </code>
     *
     * @param     boolean|string $selected The value to use as filter.
     *              Non-boolean arguments are converted using the following rules:
     *                * 1, '1', 'true',  'on',  and 'yes' are converted to boolean true
     *                * 0, '0', 'false', 'off', and 'no'  are converted to boolean false
     *              Check on string values is case insensitive (so 'FaLsE' is seen as 'false').
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ImportSourceQuery The current query, for fluid interface
     */
    public function filterBySelected($selected = null, $comparison = null)
    {
        if (is_string($selected)) {
            $selected = in_array(strtolower($selected), array('false', 'off', '-', 'no', 'n', '0', '')) ? false : true;
        }

        return $this->addUsingAlias(ImportSourcePeer::SELECTED, $selected, $comparison);
    }

    /**
     * Filter the query on the timeout column
     *
     * Example usage:
     * <code>
     * $query->filterByTimeout(1234); // WHERE timeout = 1234
     * $query->filterByTimeout(array(12, 34)); // WHERE timeout IN (12, 34)
     * $query->filterByTimeout(array('min' => 12)); // WHERE timeout >= 12
     * $query->filterByTimeout(array('max' => 12)); // WHERE timeout <= 12
     * </code>
     *
     * @param     mixed $timeout The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ImportSourceQuery The current query, for fluid interface
     */
    public function filterByTimeout($timeout = null, $comparison = null)
    {
        if (is_array($timeout)) {
            $useMinMax = false;
            if (isset($timeout['min'])) {
                $this->addUsingAlias(ImportSourcePeer::TIMEOUT, $timeout['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($timeout['max'])) {
                $this->addUsingAlias(ImportSourcePeer::TIMEOUT, $timeout['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ImportSourcePeer::TIMEOUT, $timeout, $comparison);
    }

    /**
     * Filter the query on the encoding column
     *
     * Example usage:
     * <code>
     * $query->filterByEncoding('fooValue');   // WHERE encoding = 'fooValue'
     * $query->filterByEncoding('%fooValue%'); // WHERE encoding LIKE '%fooValue%'
     * </code>
     *
     * @param     string $encoding The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ImportSourceQuery The current query, for fluid interface
     */
    public function filterByEncoding($encoding = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($encoding)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $encoding)) {
                $encoding = str_replace('*', '%', $encoding);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(ImportSourcePeer::ENCODING, $encoding, $comparison);
    }

    /**
     * Filter the query on the search_fields column
     *
     * @param     array $searchFields The values to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ImportSourceQuery The current query, for fluid interface
     */
    public function filterBySearchFields($searchFields = null, $comparison = null)
    {
        $key = $this->getAliasedColName(ImportSourcePeer::SEARCH_FIELDS);
        if (null === $comparison || $comparison == Criteria::CONTAINS_ALL) {
            foreach ($searchFields as $value) {
                $value = '%| ' . $value . ' |%';
                if ($this->containsKey($key)) {
                    $this->addAnd($key, $value, Criteria::LIKE);
                } else {
                    $this->add($key, $value, Criteria::LIKE);
                }
            }

            return $this;
        } elseif ($comparison == Criteria::CONTAINS_SOME) {
            foreach ($searchFields as $value) {
                $value = '%| ' . $value . ' |%';
                if ($this->containsKey($key)) {
                    $this->addOr($key, $value, Criteria::LIKE);
                } else {
                    $this->add($key, $value, Criteria::LIKE);
                }
            }

            return $this;
        } elseif ($comparison == Criteria::CONTAINS_NONE) {
            foreach ($searchFields as $value) {
                $value = '%| ' . $value . ' |%';
                if ($this->containsKey($key)) {
                    $this->addAnd($key, $value, Criteria::NOT_LIKE);
                } else {
                    $this->add($key, $value, Criteria::NOT_LIKE);
                }
            }
            $this->addOr($key, null, Criteria::ISNULL);

            return $this;
        }

        return $this->addUsingAlias(ImportSourcePeer::SEARCH_FIELDS, $searchFields, $comparison);
    }

    /**
     * Filter the query on the search_fields column
     * @param     mixed $searchFields The value to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::CONTAINS_ALL
     *
     * @return ImportSourceQuery The current query, for fluid interface
     */
    public function filterBySearchField($searchFields = null, $comparison = null)
    {
        if (null === $comparison || $comparison == Criteria::CONTAINS_ALL) {
            if (is_scalar($searchFields)) {
                $searchFields = '%| ' . $searchFields . ' |%';
                $comparison = Criteria::LIKE;
            }
        } elseif ($comparison == Criteria::CONTAINS_NONE) {
            $searchFields = '%| ' . $searchFields . ' |%';
            $comparison = Criteria::NOT_LIKE;
            $key = $this->getAliasedColName(ImportSourcePeer::SEARCH_FIELDS);
            if ($this->containsKey($key)) {
                $this->addAnd($key, $searchFields, $comparison);
            } else {
                $this->addAnd($key, $searchFields, $comparison);
            }
            $this->addOr($key, null, Criteria::ISNULL);

            return $this;
        }

        return $this->addUsingAlias(ImportSourcePeer::SEARCH_FIELDS, $searchFields, $comparison);
    }

    /**
     * Filter the query on the syntax column
     *
     * Example usage:
     * <code>
     * $query->filterBySyntax('fooValue');   // WHERE syntax = 'fooValue'
     * $query->filterBySyntax('%fooValue%'); // WHERE syntax LIKE '%fooValue%'
     * </code>
     *
     * @param     string $syntax The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ImportSourceQuery The current query, for fluid interface
     */
    public function filterBySyntax($syntax = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($syntax)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $syntax)) {
                $syntax = str_replace('*', '%', $syntax);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(ImportSourcePeer::SYNTAX, $syntax, $comparison);
    }

    /**
     * Filter the query on the format column
     *
     * Example usage:
     * <code>
     * $query->filterByFormat('fooValue');   // WHERE format = 'fooValue'
     * $query->filterByFormat('%fooValue%'); // WHERE format LIKE '%fooValue%'
     * </code>
     *
     * @param     string $format The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ImportSourceQuery The current query, for fluid interface
     */
    public function filterByFormat($format = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($format)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $format)) {
                $format = str_replace('*', '%', $format);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(ImportSourcePeer::FORMAT, $format, $comparison);
    }

    /**
     * Filter the query on the turbomarc_conversion column
     *
     * @param     array $turbomarcConversion The values to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ImportSourceQuery The current query, for fluid interface
     */
    public function filterByTurbomarcConversion($turbomarcConversion = null, $comparison = null)
    {
        $key = $this->getAliasedColName(ImportSourcePeer::TURBOMARC_CONVERSION);
        if (null === $comparison || $comparison == Criteria::CONTAINS_ALL) {
            foreach ($turbomarcConversion as $value) {
                $value = '%| ' . $value . ' |%';
                if ($this->containsKey($key)) {
                    $this->addAnd($key, $value, Criteria::LIKE);
                } else {
                    $this->add($key, $value, Criteria::LIKE);
                }
            }

            return $this;
        } elseif ($comparison == Criteria::CONTAINS_SOME) {
            foreach ($turbomarcConversion as $value) {
                $value = '%| ' . $value . ' |%';
                if ($this->containsKey($key)) {
                    $this->addOr($key, $value, Criteria::LIKE);
                } else {
                    $this->add($key, $value, Criteria::LIKE);
                }
            }

            return $this;
        } elseif ($comparison == Criteria::CONTAINS_NONE) {
            foreach ($turbomarcConversion as $value) {
                $value = '%| ' . $value . ' |%';
                if ($this->containsKey($key)) {
                    $this->addAnd($key, $value, Criteria::NOT_LIKE);
                } else {
                    $this->add($key, $value, Criteria::NOT_LIKE);
                }
            }
            $this->addOr($key, null, Criteria::ISNULL);

            return $this;
        }

        return $this->addUsingAlias(ImportSourcePeer::TURBOMARC_CONVERSION, $turbomarcConversion, $comparison);
    }

    /**
     * Filter the query on the options column
     *
     * Example usage:
     * <code>
     * $query->filterByOptions('fooValue');   // WHERE options = 'fooValue'
     * $query->filterByOptions('%fooValue%'); // WHERE options LIKE '%fooValue%'
     * </code>
     *
     * @param     string $options The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ImportSourceQuery The current query, for fluid interface
     */
    public function filterByOptions($options = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($options)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $options)) {
                $options = str_replace('*', '%', $options);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(ImportSourcePeer::OPTIONS, $options, $comparison);
    }

    /**
     * Filter the query on the default_catlevel column
     *
     * Example usage:
     * <code>
     * $query->filterByDefaultCatlevel('fooValue');   // WHERE default_catlevel = 'fooValue'
     * $query->filterByDefaultCatlevel('%fooValue%'); // WHERE default_catlevel LIKE '%fooValue%'
     * </code>
     *
     * @param     string $defaultCatlevel The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ImportSourceQuery The current query, for fluid interface
     */
    public function filterByDefaultCatlevel($defaultCatlevel = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($defaultCatlevel)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $defaultCatlevel)) {
                $defaultCatlevel = str_replace('*', '%', $defaultCatlevel);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(ImportSourcePeer::DEFAULT_CATLEVEL, $defaultCatlevel, $comparison);
    }

    /**
     * Filter the query on the sortable_rank column
     *
     * Example usage:
     * <code>
     * $query->filterBySortableRank(1234); // WHERE sortable_rank = 1234
     * $query->filterBySortableRank(array(12, 34)); // WHERE sortable_rank IN (12, 34)
     * $query->filterBySortableRank(array('min' => 12)); // WHERE sortable_rank >= 12
     * $query->filterBySortableRank(array('max' => 12)); // WHERE sortable_rank <= 12
     * </code>
     *
     * @param     mixed $sortableRank The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ImportSourceQuery The current query, for fluid interface
     */
    public function filterBySortableRank($sortableRank = null, $comparison = null)
    {
        if (is_array($sortableRank)) {
            $useMinMax = false;
            if (isset($sortableRank['min'])) {
                $this->addUsingAlias(ImportSourcePeer::SORTABLE_RANK, $sortableRank['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($sortableRank['max'])) {
                $this->addUsingAlias(ImportSourcePeer::SORTABLE_RANK, $sortableRank['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ImportSourcePeer::SORTABLE_RANK, $sortableRank, $comparison);
    }

    /**
     * Filter the query on the date_created column
     *
     * Example usage:
     * <code>
     * $query->filterByDateCreated('2011-03-14'); // WHERE date_created = '2011-03-14'
     * $query->filterByDateCreated('now'); // WHERE date_created = '2011-03-14'
     * $query->filterByDateCreated(array('max' => 'yesterday')); // WHERE date_created < '2011-03-13'
     * </code>
     *
     * @param     mixed $dateCreated The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ImportSourceQuery The current query, for fluid interface
     */
    public function filterByDateCreated($dateCreated = null, $comparison = null)
    {
        if (is_array($dateCreated)) {
            $useMinMax = false;
            if (isset($dateCreated['min'])) {
                $this->addUsingAlias(ImportSourcePeer::DATE_CREATED, $dateCreated['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dateCreated['max'])) {
                $this->addUsingAlias(ImportSourcePeer::DATE_CREATED, $dateCreated['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ImportSourcePeer::DATE_CREATED, $dateCreated, $comparison);
    }

    /**
     * Filter the query on the date_updated column
     *
     * Example usage:
     * <code>
     * $query->filterByDateUpdated('2011-03-14'); // WHERE date_updated = '2011-03-14'
     * $query->filterByDateUpdated('now'); // WHERE date_updated = '2011-03-14'
     * $query->filterByDateUpdated(array('max' => 'yesterday')); // WHERE date_updated < '2011-03-13'
     * </code>
     *
     * @param     mixed $dateUpdated The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ImportSourceQuery The current query, for fluid interface
     */
    public function filterByDateUpdated($dateUpdated = null, $comparison = null)
    {
        if (is_array($dateUpdated)) {
            $useMinMax = false;
            if (isset($dateUpdated['min'])) {
                $this->addUsingAlias(ImportSourcePeer::DATE_UPDATED, $dateUpdated['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dateUpdated['max'])) {
                $this->addUsingAlias(ImportSourcePeer::DATE_UPDATED, $dateUpdated['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ImportSourcePeer::DATE_UPDATED, $dateUpdated, $comparison);
    }

    /**
     * Filter the query on the created_by column
     *
     * Example usage:
     * <code>
     * $query->filterByCreatedBy(1234); // WHERE created_by = 1234
     * $query->filterByCreatedBy(array(12, 34)); // WHERE created_by IN (12, 34)
     * $query->filterByCreatedBy(array('min' => 12)); // WHERE created_by >= 12
     * $query->filterByCreatedBy(array('max' => 12)); // WHERE created_by <= 12
     * </code>
     *
     * @see       filterByLibrarianRelatedByCreatedBy()
     *
     * @param     mixed $createdBy The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ImportSourceQuery The current query, for fluid interface
     */
    public function filterByCreatedBy($createdBy = null, $comparison = null)
    {
        if (is_array($createdBy)) {
            $useMinMax = false;
            if (isset($createdBy['min'])) {
                $this->addUsingAlias(ImportSourcePeer::CREATED_BY, $createdBy['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($createdBy['max'])) {
                $this->addUsingAlias(ImportSourcePeer::CREATED_BY, $createdBy['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ImportSourcePeer::CREATED_BY, $createdBy, $comparison);
    }

    /**
     * Filter the query on the modified_by column
     *
     * Example usage:
     * <code>
     * $query->filterByModifiedBy(1234); // WHERE modified_by = 1234
     * $query->filterByModifiedBy(array(12, 34)); // WHERE modified_by IN (12, 34)
     * $query->filterByModifiedBy(array('min' => 12)); // WHERE modified_by >= 12
     * $query->filterByModifiedBy(array('max' => 12)); // WHERE modified_by <= 12
     * </code>
     *
     * @see       filterByLibrarianRelatedByModifiedBy()
     *
     * @param     mixed $modifiedBy The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ImportSourceQuery The current query, for fluid interface
     */
    public function filterByModifiedBy($modifiedBy = null, $comparison = null)
    {
        if (is_array($modifiedBy)) {
            $useMinMax = false;
            if (isset($modifiedBy['min'])) {
                $this->addUsingAlias(ImportSourcePeer::MODIFIED_BY, $modifiedBy['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($modifiedBy['max'])) {
                $this->addUsingAlias(ImportSourcePeer::MODIFIED_BY, $modifiedBy['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ImportSourcePeer::MODIFIED_BY, $modifiedBy, $comparison);
    }

    /**
     * Filter the query by a related Librarian object
     *
     * @param   Librarian|PropelObjectCollection $librarian The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 ImportSourceQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByLibrarianRelatedByCreatedBy($librarian, $comparison = null)
    {
        if ($librarian instanceof Librarian) {
            return $this
                ->addUsingAlias(ImportSourcePeer::CREATED_BY, $librarian->getLibrarianId(), $comparison);
        } elseif ($librarian instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(ImportSourcePeer::CREATED_BY, $librarian->toKeyValue('PrimaryKey', 'LibrarianId'), $comparison);
        } else {
            throw new PropelException('filterByLibrarianRelatedByCreatedBy() only accepts arguments of type Librarian or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the LibrarianRelatedByCreatedBy relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return ImportSourceQuery The current query, for fluid interface
     */
    public function joinLibrarianRelatedByCreatedBy($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('LibrarianRelatedByCreatedBy');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'LibrarianRelatedByCreatedBy');
        }

        return $this;
    }

    /**
     * Use the LibrarianRelatedByCreatedBy relation Librarian object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   LibrarianQuery A secondary query class using the current class as primary query
     */
    public function useLibrarianRelatedByCreatedByQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinLibrarianRelatedByCreatedBy($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'LibrarianRelatedByCreatedBy', 'LibrarianQuery');
    }

    /**
     * Filter the query by a related Librarian object
     *
     * @param   Librarian|PropelObjectCollection $librarian The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 ImportSourceQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByLibrarianRelatedByModifiedBy($librarian, $comparison = null)
    {
        if ($librarian instanceof Librarian) {
            return $this
                ->addUsingAlias(ImportSourcePeer::MODIFIED_BY, $librarian->getLibrarianId(), $comparison);
        } elseif ($librarian instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(ImportSourcePeer::MODIFIED_BY, $librarian->toKeyValue('PrimaryKey', 'LibrarianId'), $comparison);
        } else {
            throw new PropelException('filterByLibrarianRelatedByModifiedBy() only accepts arguments of type Librarian or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the LibrarianRelatedByModifiedBy relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return ImportSourceQuery The current query, for fluid interface
     */
    public function joinLibrarianRelatedByModifiedBy($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('LibrarianRelatedByModifiedBy');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'LibrarianRelatedByModifiedBy');
        }

        return $this;
    }

    /**
     * Use the LibrarianRelatedByModifiedBy relation Librarian object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   LibrarianQuery A secondary query class using the current class as primary query
     */
    public function useLibrarianRelatedByModifiedByQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinLibrarianRelatedByModifiedBy($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'LibrarianRelatedByModifiedBy', 'LibrarianQuery');
    }

    /**
     * Exclude object from result
     *
     * @param   ImportSource $importSource Object to remove from the list of results
     *
     * @return ImportSourceQuery The current query, for fluid interface
     */
    public function prune($importSource = null)
    {
        if ($importSource) {
            $this->addUsingAlias(ImportSourcePeer::NAME, $importSource->getName(), Criteria::NOT_EQUAL);
        }

        return $this;
    }

    // sortable behavior

    /**
     * Filter the query based on a rank in the list
     *
     * @param     integer   $rank rank
     *
     * @return    ImportSourceQuery The current query, for fluid interface
     */
    public function filterByRank($rank)
    {


        return $this
            ->addUsingAlias(ImportSourcePeer::RANK_COL, $rank, Criteria::EQUAL);
    }

    /**
     * Order the query based on the rank in the list.
     * Using the default $order, returns the item with the lowest rank first
     *
     * @param     string $order either Criteria::ASC (default) or Criteria::DESC
     *
     * @return    ImportSourceQuery The current query, for fluid interface
     */
    public function orderByRank($order = Criteria::ASC)
    {
        $order = strtoupper($order);
        switch ($order) {
            case Criteria::ASC:
                return $this->addAscendingOrderByColumn($this->getAliasedColName(ImportSourcePeer::RANK_COL));
                break;
            case Criteria::DESC:
                return $this->addDescendingOrderByColumn($this->getAliasedColName(ImportSourcePeer::RANK_COL));
                break;
            default:
                throw new PropelException('ImportSourceQuery::orderBy() only accepts "asc" or "desc" as argument');
        }
    }

    /**
     * Get an item from the list based on its rank
     *
     * @param     integer   $rank rank
     * @param     PropelPDO $con optional connection
     *
     * @return    ImportSource
     */
    public function findOneByRank($rank, PropelPDO $con = null)
    {

        return $this
            ->filterByRank($rank)
            ->findOne($con);
    }

    /**
     * Returns the list of objects
     *
     * @param      PropelPDO $con	Connection to use.
     *
     * @return     mixed the list of results, formatted by the current formatter
     */
    public function findList($con = null)
    {


        return $this
            ->orderByRank()
            ->find($con);
    }

    /**
     * Get the highest rank
     *
     * @param     PropelPDO optional connection
     *
     * @return    integer highest position
     */
    public function getMaxRank(PropelPDO $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection(ImportSourcePeer::DATABASE_NAME);
        }
        // shift the objects with a position lower than the one of object
        $this->addSelectColumn('MAX(' . ImportSourcePeer::RANK_COL . ')');
        $stmt = $this->doSelect($con);

        return $stmt->fetchColumn();
    }

    /**
     * Get the highest rank by a scope with a array format.
     *
     * @param     PropelPDO optional connection
     *
     * @return    integer highest position
     */
    public function getMaxRankArray(PropelPDO $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection(ImportSourcePeer::DATABASE_NAME);
        }
        // shift the objects with a position lower than the one of object
        $this->addSelectColumn('MAX(' . ImportSourcePeer::RANK_COL . ')');
        $stmt = $this->doSelect($con);

        return $stmt->fetchColumn();
    }

    /**
     * Reorder a set of sortable objects based on a list of id/position
     * Beware that there is no check made on the positions passed
     * So incoherent positions will result in an incoherent list
     *
     * @param     array     $order id => rank pairs
     * @param     PropelPDO $con   optional connection
     *
     * @return    boolean true if the reordering took place, false if a database problem prevented it
     */
    public function reorder(array $order, PropelPDO $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection(ImportSourcePeer::DATABASE_NAME);
        }

        $con->beginTransaction();
        try {
            $ids = array_keys($order);
            $objects = $this->findPks($ids, $con);
            foreach ($objects as $object) {
                $pk = $object->getPrimaryKey();
                if ($object->getSortableRank() != $order[$pk]) {
                    $object->setSortableRank($order[$pk]);
                    $object->save($con);
                }
            }
            $con->commit();

            return true;
        } catch (Exception $e) {
            $con->rollback();
            throw $e;
        }
    }

    // timestampable behavior

    /**
     * Filter by the latest updated
     *
     * @param      int $nbDays Maximum age of the latest update in days
     *
     * @return     ImportSourceQuery The current query, for fluid interface
     */
    public function recentlyUpdated($nbDays = 7)
    {
        return $this->addUsingAlias(ImportSourcePeer::DATE_UPDATED, time() - $nbDays * 24 * 60 * 60, Criteria::GREATER_EQUAL);
    }

    /**
     * Order by update date desc
     *
     * @return     ImportSourceQuery The current query, for fluid interface
     */
    public function lastUpdatedFirst()
    {
        return $this->addDescendingOrderByColumn(ImportSourcePeer::DATE_UPDATED);
    }

    /**
     * Order by update date asc
     *
     * @return     ImportSourceQuery The current query, for fluid interface
     */
    public function firstUpdatedFirst()
    {
        return $this->addAscendingOrderByColumn(ImportSourcePeer::DATE_UPDATED);
    }

    /**
     * Filter by the latest created
     *
     * @param      int $nbDays Maximum age of in days
     *
     * @return     ImportSourceQuery The current query, for fluid interface
     */
    public function recentlyCreated($nbDays = 7)
    {
        return $this->addUsingAlias(ImportSourcePeer::DATE_CREATED, time() - $nbDays * 24 * 60 * 60, Criteria::GREATER_EQUAL);
    }

    /**
     * Order by create date desc
     *
     * @return     ImportSourceQuery The current query, for fluid interface
     */
    public function lastCreatedFirst()
    {
        return $this->addDescendingOrderByColumn(ImportSourcePeer::DATE_CREATED);
    }

    /**
     * Order by create date asc
     *
     * @return     ImportSourceQuery The current query, for fluid interface
     */
    public function firstCreatedFirst()
    {
        return $this->addAscendingOrderByColumn(ImportSourcePeer::DATE_CREATED);
    }
}
