<?php


/**
 * Base class that represents a query for the 'app_action' table.
 *
 *
 *
 * @method AppActionQuery orderByActionId($order = Criteria::ASC) Order by the action_id column
 * @method AppActionQuery orderBySortOrder($order = Criteria::ASC) Order by the sort_order column
 * @method AppActionQuery orderByLabel($order = Criteria::ASC) Order by the label column
 * @method AppActionQuery orderByPage($order = Criteria::ASC) Order by the page column
 * @method AppActionQuery orderByModuleId($order = Criteria::ASC) Order by the module_id column
 * @method AppActionQuery orderByMenuVisible($order = Criteria::ASC) Order by the menu_visible column
 *
 * @method AppActionQuery groupByActionId() Group by the action_id column
 * @method AppActionQuery groupBySortOrder() Group by the sort_order column
 * @method AppActionQuery groupByLabel() Group by the label column
 * @method AppActionQuery groupByPage() Group by the page column
 * @method AppActionQuery groupByModuleId() Group by the module_id column
 * @method AppActionQuery groupByMenuVisible() Group by the menu_visible column
 *
 * @method AppActionQuery leftJoin($relation) Adds a LEFT JOIN clause to the query
 * @method AppActionQuery rightJoin($relation) Adds a RIGHT JOIN clause to the query
 * @method AppActionQuery innerJoin($relation) Adds a INNER JOIN clause to the query
 *
 * @method AppActionQuery leftJoinAppModule($relationAlias = null) Adds a LEFT JOIN clause to the query using the AppModule relation
 * @method AppActionQuery rightJoinAppModule($relationAlias = null) Adds a RIGHT JOIN clause to the query using the AppModule relation
 * @method AppActionQuery innerJoinAppModule($relationAlias = null) Adds a INNER JOIN clause to the query using the AppModule relation
 *
 * @method AppActionQuery leftJoinAppProfileAcl($relationAlias = null) Adds a LEFT JOIN clause to the query using the AppProfileAcl relation
 * @method AppActionQuery rightJoinAppProfileAcl($relationAlias = null) Adds a RIGHT JOIN clause to the query using the AppProfileAcl relation
 * @method AppActionQuery innerJoinAppProfileAcl($relationAlias = null) Adds a INNER JOIN clause to the query using the AppProfileAcl relation
 *
 * @method AppAction findOne(PropelPDO $con = null) Return the first AppAction matching the query
 * @method AppAction findOneOrCreate(PropelPDO $con = null) Return the first AppAction matching the query, or a new AppAction object populated from the query conditions when no match is found
 *
 * @method AppAction findOneBySortOrder(int $sort_order) Return the first AppAction filtered by the sort_order column
 * @method AppAction findOneByLabel(string $label) Return the first AppAction filtered by the label column
 * @method AppAction findOneByPage(string $page) Return the first AppAction filtered by the page column
 * @method AppAction findOneByModuleId(string $module_id) Return the first AppAction filtered by the module_id column
 * @method AppAction findOneByMenuVisible(string $menu_visible) Return the first AppAction filtered by the menu_visible column
 *
 * @method array findByActionId(int $action_id) Return AppAction objects filtered by the action_id column
 * @method array findBySortOrder(int $sort_order) Return AppAction objects filtered by the sort_order column
 * @method array findByLabel(string $label) Return AppAction objects filtered by the label column
 * @method array findByPage(string $page) Return AppAction objects filtered by the page column
 * @method array findByModuleId(string $module_id) Return AppAction objects filtered by the module_id column
 * @method array findByMenuVisible(string $menu_visible) Return AppAction objects filtered by the menu_visible column
 *
 * @package    propel.generator.clavis.om
 */
abstract class BaseAppActionQuery extends ModelCriteria
{
    /**
     * Initializes internal state of BaseAppActionQuery object.
     *
     * @param     string $dbName The dabase name
     * @param     string $modelName The phpName of a model, e.g. 'Book'
     * @param     string $modelAlias The alias for the model in this query, e.g. 'b'
     */
    public function __construct($dbName = null, $modelName = null, $modelAlias = null)
    {
        if (null === $dbName) {
            $dbName = 'clavis';
        }
        if (null === $modelName) {
            $modelName = 'AppAction';
        }
        parent::__construct($dbName, $modelName, $modelAlias);
    }

    /**
     * Returns a new AppActionQuery object.
     *
     * @param     string $modelAlias The alias of a model in the query
     * @param   AppActionQuery|Criteria $criteria Optional Criteria to build the query from
     *
     * @return AppActionQuery
     */
    public static function create($modelAlias = null, $criteria = null)
    {
        if ($criteria instanceof AppActionQuery) {
            return $criteria;
        }
        $query = new AppActionQuery(null, null, $modelAlias);

        if ($criteria instanceof Criteria) {
            $query->mergeWith($criteria);
        }

        return $query;
    }

    /**
     * Find object by primary key.
     * Propel uses the instance pool to skip the database if the object exists.
     * Go fast if the query is untouched.
     *
     * <code>
     * $obj  = $c->findPk(12, $con);
     * </code>
     *
     * @param mixed $key Primary key to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return   AppAction|AppAction[]|mixed the result, formatted by the current formatter
     */
    public function findPk($key, $con = null)
    {
        if ($key === null) {
            return null;
        }
        if ((null !== ($obj = AppActionPeer::getInstanceFromPool((string) $key))) && !$this->formatter) {
            // the object is already in the instance pool
            return $obj;
        }
        if ($con === null) {
            $con = Propel::getConnection(AppActionPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        if ($this->formatter || $this->modelAlias || $this->with || $this->select
         || $this->selectColumns || $this->asColumns || $this->selectModifiers
         || $this->map || $this->having || $this->joins) {
            return $this->findPkComplex($key, $con);
        } else {
            return $this->findPkSimple($key, $con);
        }
    }

    /**
     * Alias of findPk to use instance pooling
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 AppAction A model object, or null if the key is not found
     * @throws PropelException
     */
     public function findOneByActionId($key, $con = null)
     {
        return $this->findPk($key, $con);
     }

    /**
     * Find object by primary key using raw SQL to go fast.
     * Bypass doSelect() and the object formatter by using generated code.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 AppAction A model object, or null if the key is not found
     * @throws PropelException
     */
    protected function findPkSimple($key, $con)
    {
        $sql = 'SELECT `action_id`, `sort_order`, `label`, `page`, `module_id`, `menu_visible` FROM `app_action` WHERE `action_id` = :p0';
        try {
            $stmt = $con->prepare($sql);
            $stmt->bindValue(':p0', $key, PDO::PARAM_INT);
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute SELECT statement [%s]', $sql), $e);
        }
        $obj = null;
        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $obj = new AppAction();
            $obj->hydrate($row);
            AppActionPeer::addInstanceToPool($obj, (string) $key);
        }
        $stmt->closeCursor();

        return $obj;
    }

    /**
     * Find object by primary key.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return AppAction|AppAction[]|mixed the result, formatted by the current formatter
     */
    protected function findPkComplex($key, $con)
    {
        // As the query uses a PK condition, no limit(1) is necessary.
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKey($key)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->formatOne($stmt);
    }

    /**
     * Find objects by primary key
     * <code>
     * $objs = $c->findPks(array(12, 56, 832), $con);
     * </code>
     * @param     array $keys Primary keys to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return PropelObjectCollection|AppAction[]|mixed the list of results, formatted by the current formatter
     */
    public function findPks($keys, $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection($this->getDbName(), Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKeys($keys)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->format($stmt);
    }

    /**
     * Filter the query by primary key
     *
     * @param     mixed $key Primary key to use for the query
     *
     * @return AppActionQuery The current query, for fluid interface
     */
    public function filterByPrimaryKey($key)
    {

        return $this->addUsingAlias(AppActionPeer::ACTION_ID, $key, Criteria::EQUAL);
    }

    /**
     * Filter the query by a list of primary keys
     *
     * @param     array $keys The list of primary key to use for the query
     *
     * @return AppActionQuery The current query, for fluid interface
     */
    public function filterByPrimaryKeys($keys)
    {

        return $this->addUsingAlias(AppActionPeer::ACTION_ID, $keys, Criteria::IN);
    }

    /**
     * Filter the query on the action_id column
     *
     * Example usage:
     * <code>
     * $query->filterByActionId(1234); // WHERE action_id = 1234
     * $query->filterByActionId(array(12, 34)); // WHERE action_id IN (12, 34)
     * $query->filterByActionId(array('min' => 12)); // WHERE action_id >= 12
     * $query->filterByActionId(array('max' => 12)); // WHERE action_id <= 12
     * </code>
     *
     * @param     mixed $actionId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return AppActionQuery The current query, for fluid interface
     */
    public function filterByActionId($actionId = null, $comparison = null)
    {
        if (is_array($actionId)) {
            $useMinMax = false;
            if (isset($actionId['min'])) {
                $this->addUsingAlias(AppActionPeer::ACTION_ID, $actionId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($actionId['max'])) {
                $this->addUsingAlias(AppActionPeer::ACTION_ID, $actionId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(AppActionPeer::ACTION_ID, $actionId, $comparison);
    }

    /**
     * Filter the query on the sort_order column
     *
     * Example usage:
     * <code>
     * $query->filterBySortOrder(1234); // WHERE sort_order = 1234
     * $query->filterBySortOrder(array(12, 34)); // WHERE sort_order IN (12, 34)
     * $query->filterBySortOrder(array('min' => 12)); // WHERE sort_order >= 12
     * $query->filterBySortOrder(array('max' => 12)); // WHERE sort_order <= 12
     * </code>
     *
     * @param     mixed $sortOrder The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return AppActionQuery The current query, for fluid interface
     */
    public function filterBySortOrder($sortOrder = null, $comparison = null)
    {
        if (is_array($sortOrder)) {
            $useMinMax = false;
            if (isset($sortOrder['min'])) {
                $this->addUsingAlias(AppActionPeer::SORT_ORDER, $sortOrder['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($sortOrder['max'])) {
                $this->addUsingAlias(AppActionPeer::SORT_ORDER, $sortOrder['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(AppActionPeer::SORT_ORDER, $sortOrder, $comparison);
    }

    /**
     * Filter the query on the label column
     *
     * Example usage:
     * <code>
     * $query->filterByLabel('fooValue');   // WHERE label = 'fooValue'
     * $query->filterByLabel('%fooValue%'); // WHERE label LIKE '%fooValue%'
     * </code>
     *
     * @param     string $label The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return AppActionQuery The current query, for fluid interface
     */
    public function filterByLabel($label = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($label)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $label)) {
                $label = str_replace('*', '%', $label);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(AppActionPeer::LABEL, $label, $comparison);
    }

    /**
     * Filter the query on the page column
     *
     * Example usage:
     * <code>
     * $query->filterByPage('fooValue');   // WHERE page = 'fooValue'
     * $query->filterByPage('%fooValue%'); // WHERE page LIKE '%fooValue%'
     * </code>
     *
     * @param     string $page The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return AppActionQuery The current query, for fluid interface
     */
    public function filterByPage($page = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($page)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $page)) {
                $page = str_replace('*', '%', $page);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(AppActionPeer::PAGE, $page, $comparison);
    }

    /**
     * Filter the query on the module_id column
     *
     * Example usage:
     * <code>
     * $query->filterByModuleId('fooValue');   // WHERE module_id = 'fooValue'
     * $query->filterByModuleId('%fooValue%'); // WHERE module_id LIKE '%fooValue%'
     * </code>
     *
     * @param     string $moduleId The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return AppActionQuery The current query, for fluid interface
     */
    public function filterByModuleId($moduleId = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($moduleId)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $moduleId)) {
                $moduleId = str_replace('*', '%', $moduleId);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(AppActionPeer::MODULE_ID, $moduleId, $comparison);
    }

    /**
     * Filter the query on the menu_visible column
     *
     * Example usage:
     * <code>
     * $query->filterByMenuVisible('fooValue');   // WHERE menu_visible = 'fooValue'
     * $query->filterByMenuVisible('%fooValue%'); // WHERE menu_visible LIKE '%fooValue%'
     * </code>
     *
     * @param     string $menuVisible The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return AppActionQuery The current query, for fluid interface
     */
    public function filterByMenuVisible($menuVisible = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($menuVisible)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $menuVisible)) {
                $menuVisible = str_replace('*', '%', $menuVisible);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(AppActionPeer::MENU_VISIBLE, $menuVisible, $comparison);
    }

    /**
     * Filter the query by a related AppModule object
     *
     * @param   AppModule|PropelObjectCollection $appModule The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 AppActionQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByAppModule($appModule, $comparison = null)
    {
        if ($appModule instanceof AppModule) {
            return $this
                ->addUsingAlias(AppActionPeer::MODULE_ID, $appModule->getModuleId(), $comparison);
        } elseif ($appModule instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(AppActionPeer::MODULE_ID, $appModule->toKeyValue('PrimaryKey', 'ModuleId'), $comparison);
        } else {
            throw new PropelException('filterByAppModule() only accepts arguments of type AppModule or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the AppModule relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return AppActionQuery The current query, for fluid interface
     */
    public function joinAppModule($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('AppModule');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'AppModule');
        }

        return $this;
    }

    /**
     * Use the AppModule relation AppModule object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   AppModuleQuery A secondary query class using the current class as primary query
     */
    public function useAppModuleQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinAppModule($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'AppModule', 'AppModuleQuery');
    }

    /**
     * Filter the query by a related AppProfileAcl object
     *
     * @param   AppProfileAcl|PropelObjectCollection $appProfileAcl  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 AppActionQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByAppProfileAcl($appProfileAcl, $comparison = null)
    {
        if ($appProfileAcl instanceof AppProfileAcl) {
            return $this
                ->addUsingAlias(AppActionPeer::ACTION_ID, $appProfileAcl->getActionId(), $comparison);
        } elseif ($appProfileAcl instanceof PropelObjectCollection) {
            return $this
                ->useAppProfileAclQuery()
                ->filterByPrimaryKeys($appProfileAcl->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByAppProfileAcl() only accepts arguments of type AppProfileAcl or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the AppProfileAcl relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return AppActionQuery The current query, for fluid interface
     */
    public function joinAppProfileAcl($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('AppProfileAcl');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'AppProfileAcl');
        }

        return $this;
    }

    /**
     * Use the AppProfileAcl relation AppProfileAcl object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   AppProfileAclQuery A secondary query class using the current class as primary query
     */
    public function useAppProfileAclQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinAppProfileAcl($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'AppProfileAcl', 'AppProfileAclQuery');
    }

    /**
     * Exclude object from result
     *
     * @param   AppAction $appAction Object to remove from the list of results
     *
     * @return AppActionQuery The current query, for fluid interface
     */
    public function prune($appAction = null)
    {
        if ($appAction) {
            $this->addUsingAlias(AppActionPeer::ACTION_ID, $appAction->getActionId(), Criteria::NOT_EQUAL);
        }

        return $this;
    }

    // sortable behavior

    /**
     * Returns the objects in a certain list, from the list scope
     *
     * @param string $scope Scope to determine which objects node to return
     *
     * @return AppActionQuery The current query, for fluid interface
     */
    public function inList($scope = null)
    {

        AppActionPeer::sortableApplyScopeCriteria($this, $scope, 'addUsingAlias');

        return $this;
    }

    /**
     * Filter the query based on a rank in the list
     *
     * @param     integer   $rank rank
     * @param string $scope Scope to determine which objects node to return

     *
     * @return    AppActionQuery The current query, for fluid interface
     */
    public function filterByRank($rank, $scope = null)
    {


        return $this
            ->inList($scope)
            ->addUsingAlias(AppActionPeer::RANK_COL, $rank, Criteria::EQUAL);
    }

    /**
     * Order the query based on the rank in the list.
     * Using the default $order, returns the item with the lowest rank first
     *
     * @param     string $order either Criteria::ASC (default) or Criteria::DESC
     *
     * @return    AppActionQuery The current query, for fluid interface
     */
    public function orderByRank($order = Criteria::ASC)
    {
        $order = strtoupper($order);
        switch ($order) {
            case Criteria::ASC:
                return $this->addAscendingOrderByColumn($this->getAliasedColName(AppActionPeer::RANK_COL));
                break;
            case Criteria::DESC:
                return $this->addDescendingOrderByColumn($this->getAliasedColName(AppActionPeer::RANK_COL));
                break;
            default:
                throw new PropelException('AppActionQuery::orderBy() only accepts "asc" or "desc" as argument');
        }
    }

    /**
     * Get an item from the list based on its rank
     *
     * @param     integer   $rank rank
     * @param string $scope Scope to determine which objects node to return
     * @param     PropelPDO $con optional connection
     *
     * @return    AppAction
     */
    public function findOneByRank($rank, $scope = null, PropelPDO $con = null)
    {

        return $this
            ->filterByRank($rank, $scope)
            ->findOne($con);
    }

    /**
     * Returns a list of objects
     *
     * @param string $scope Scope to determine which objects node to return

     * @param      PropelPDO $con	Connection to use.
     *
     * @return     mixed the list of results, formatted by the current formatter
     */
    public function findList($scope = null, $con = null)
    {


        return $this
            ->inList($scope)
            ->orderByRank()
            ->find($con);
    }

    /**
     * Get the highest rank
     *
     * @param string $scope Scope to determine which objects node to return

     * @param     PropelPDO optional connection
     *
     * @return    integer highest position
     */
    public function getMaxRank($scope = null, PropelPDO $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection(AppActionPeer::DATABASE_NAME);
        }
        // shift the objects with a position lower than the one of object
        $this->addSelectColumn('MAX(' . AppActionPeer::RANK_COL . ')');

        AppActionPeer::sortableApplyScopeCriteria($this, $scope);
        $stmt = $this->doSelect($con);

        return $stmt->fetchColumn();
    }

    /**
     * Get the highest rank by a scope with a array format.
     *
     * @param     int $scope		The scope value as scalar type or array($value1, ...).

     * @param     PropelPDO optional connection
     *
     * @return    integer highest position
     */
    public function getMaxRankArray($scope, PropelPDO $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection(AppActionPeer::DATABASE_NAME);
        }
        // shift the objects with a position lower than the one of object
        $this->addSelectColumn('MAX(' . AppActionPeer::RANK_COL . ')');
        AppActionPeer::sortableApplyScopeCriteria($this, $scope);
        $stmt = $this->doSelect($con);

        return $stmt->fetchColumn();
    }

    /**
     * Reorder a set of sortable objects based on a list of id/position
     * Beware that there is no check made on the positions passed
     * So incoherent positions will result in an incoherent list
     *
     * @param     array     $order id => rank pairs
     * @param     PropelPDO $con   optional connection
     *
     * @return    boolean true if the reordering took place, false if a database problem prevented it
     */
    public function reorder(array $order, PropelPDO $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection(AppActionPeer::DATABASE_NAME);
        }

        $con->beginTransaction();
        try {
            $ids = array_keys($order);
            $objects = $this->findPks($ids, $con);
            foreach ($objects as $object) {
                $pk = $object->getPrimaryKey();
                if ($object->getSortOrder() != $order[$pk]) {
                    $object->setSortOrder($order[$pk]);
                    $object->save($con);
                }
            }
            $con->commit();

            return true;
        } catch (Exception $e) {
            $con->rollback();
            throw $e;
        }
    }

}
