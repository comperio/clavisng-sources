<?php


/**
 * Base class that represents a query for the 'app_profile_acl' table.
 *
 *
 *
 * @method AppProfileAclQuery orderByModuleId($order = Criteria::ASC) Order by the module_id column
 * @method AppProfileAclQuery orderByActionId($order = Criteria::ASC) Order by the action_id column
 * @method AppProfileAclQuery orderByProfileId($order = Criteria::ASC) Order by the profile_id column
 * @method AppProfileAclQuery orderByAction($order = Criteria::ASC) Order by the action column
 *
 * @method AppProfileAclQuery groupByModuleId() Group by the module_id column
 * @method AppProfileAclQuery groupByActionId() Group by the action_id column
 * @method AppProfileAclQuery groupByProfileId() Group by the profile_id column
 * @method AppProfileAclQuery groupByAction() Group by the action column
 *
 * @method AppProfileAclQuery leftJoin($relation) Adds a LEFT JOIN clause to the query
 * @method AppProfileAclQuery rightJoin($relation) Adds a RIGHT JOIN clause to the query
 * @method AppProfileAclQuery innerJoin($relation) Adds a INNER JOIN clause to the query
 *
 * @method AppProfileAclQuery leftJoinAppProfile($relationAlias = null) Adds a LEFT JOIN clause to the query using the AppProfile relation
 * @method AppProfileAclQuery rightJoinAppProfile($relationAlias = null) Adds a RIGHT JOIN clause to the query using the AppProfile relation
 * @method AppProfileAclQuery innerJoinAppProfile($relationAlias = null) Adds a INNER JOIN clause to the query using the AppProfile relation
 *
 * @method AppProfileAclQuery leftJoinAppAction($relationAlias = null) Adds a LEFT JOIN clause to the query using the AppAction relation
 * @method AppProfileAclQuery rightJoinAppAction($relationAlias = null) Adds a RIGHT JOIN clause to the query using the AppAction relation
 * @method AppProfileAclQuery innerJoinAppAction($relationAlias = null) Adds a INNER JOIN clause to the query using the AppAction relation
 *
 * @method AppProfileAclQuery leftJoinAppModule($relationAlias = null) Adds a LEFT JOIN clause to the query using the AppModule relation
 * @method AppProfileAclQuery rightJoinAppModule($relationAlias = null) Adds a RIGHT JOIN clause to the query using the AppModule relation
 * @method AppProfileAclQuery innerJoinAppModule($relationAlias = null) Adds a INNER JOIN clause to the query using the AppModule relation
 *
 * @method AppProfileAcl findOne(PropelPDO $con = null) Return the first AppProfileAcl matching the query
 * @method AppProfileAcl findOneOrCreate(PropelPDO $con = null) Return the first AppProfileAcl matching the query, or a new AppProfileAcl object populated from the query conditions when no match is found
 *
 * @method AppProfileAcl findOneByModuleId(string $module_id) Return the first AppProfileAcl filtered by the module_id column
 * @method AppProfileAcl findOneByActionId(int $action_id) Return the first AppProfileAcl filtered by the action_id column
 * @method AppProfileAcl findOneByProfileId(int $profile_id) Return the first AppProfileAcl filtered by the profile_id column
 * @method AppProfileAcl findOneByAction(string $action) Return the first AppProfileAcl filtered by the action column
 *
 * @method array findByModuleId(string $module_id) Return AppProfileAcl objects filtered by the module_id column
 * @method array findByActionId(int $action_id) Return AppProfileAcl objects filtered by the action_id column
 * @method array findByProfileId(int $profile_id) Return AppProfileAcl objects filtered by the profile_id column
 * @method array findByAction(string $action) Return AppProfileAcl objects filtered by the action column
 *
 * @package    propel.generator.clavis.om
 */
abstract class BaseAppProfileAclQuery extends ModelCriteria
{
    /**
     * Initializes internal state of BaseAppProfileAclQuery object.
     *
     * @param     string $dbName The dabase name
     * @param     string $modelName The phpName of a model, e.g. 'Book'
     * @param     string $modelAlias The alias for the model in this query, e.g. 'b'
     */
    public function __construct($dbName = null, $modelName = null, $modelAlias = null)
    {
        if (null === $dbName) {
            $dbName = 'clavis';
        }
        if (null === $modelName) {
            $modelName = 'AppProfileAcl';
        }
        parent::__construct($dbName, $modelName, $modelAlias);
    }

    /**
     * Returns a new AppProfileAclQuery object.
     *
     * @param     string $modelAlias The alias of a model in the query
     * @param   AppProfileAclQuery|Criteria $criteria Optional Criteria to build the query from
     *
     * @return AppProfileAclQuery
     */
    public static function create($modelAlias = null, $criteria = null)
    {
        if ($criteria instanceof AppProfileAclQuery) {
            return $criteria;
        }
        $query = new AppProfileAclQuery(null, null, $modelAlias);

        if ($criteria instanceof Criteria) {
            $query->mergeWith($criteria);
        }

        return $query;
    }

    /**
     * Find object by primary key.
     * Propel uses the instance pool to skip the database if the object exists.
     * Go fast if the query is untouched.
     *
     * <code>
     * $obj = $c->findPk(array(12, 34, 56), $con);
     * </code>
     *
     * @param array $key Primary key to use for the query
                         A Primary key composition: [$module_id, $action_id, $profile_id]
     * @param     PropelPDO $con an optional connection object
     *
     * @return   AppProfileAcl|AppProfileAcl[]|mixed the result, formatted by the current formatter
     */
    public function findPk($key, $con = null)
    {
        if ($key === null) {
            return null;
        }
        if ((null !== ($obj = AppProfileAclPeer::getInstanceFromPool(serialize(array((string) $key[0], (string) $key[1], (string) $key[2]))))) && !$this->formatter) {
            // the object is already in the instance pool
            return $obj;
        }
        if ($con === null) {
            $con = Propel::getConnection(AppProfileAclPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        if ($this->formatter || $this->modelAlias || $this->with || $this->select
         || $this->selectColumns || $this->asColumns || $this->selectModifiers
         || $this->map || $this->having || $this->joins) {
            return $this->findPkComplex($key, $con);
        } else {
            return $this->findPkSimple($key, $con);
        }
    }

    /**
     * Find object by primary key using raw SQL to go fast.
     * Bypass doSelect() and the object formatter by using generated code.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 AppProfileAcl A model object, or null if the key is not found
     * @throws PropelException
     */
    protected function findPkSimple($key, $con)
    {
        $sql = 'SELECT `module_id`, `action_id`, `profile_id`, `action` FROM `app_profile_acl` WHERE `module_id` = :p0 AND `action_id` = :p1 AND `profile_id` = :p2';
        try {
            $stmt = $con->prepare($sql);
            $stmt->bindValue(':p0', $key[0], PDO::PARAM_STR);
            $stmt->bindValue(':p1', $key[1], PDO::PARAM_INT);
            $stmt->bindValue(':p2', $key[2], PDO::PARAM_INT);
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute SELECT statement [%s]', $sql), $e);
        }
        $obj = null;
        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $obj = new AppProfileAcl();
            $obj->hydrate($row);
            AppProfileAclPeer::addInstanceToPool($obj, serialize(array((string) $key[0], (string) $key[1], (string) $key[2])));
        }
        $stmt->closeCursor();

        return $obj;
    }

    /**
     * Find object by primary key.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return AppProfileAcl|AppProfileAcl[]|mixed the result, formatted by the current formatter
     */
    protected function findPkComplex($key, $con)
    {
        // As the query uses a PK condition, no limit(1) is necessary.
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKey($key)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->formatOne($stmt);
    }

    /**
     * Find objects by primary key
     * <code>
     * $objs = $c->findPks(array(array(12, 56), array(832, 123), array(123, 456)), $con);
     * </code>
     * @param     array $keys Primary keys to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return PropelObjectCollection|AppProfileAcl[]|mixed the list of results, formatted by the current formatter
     */
    public function findPks($keys, $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection($this->getDbName(), Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKeys($keys)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->format($stmt);
    }

    /**
     * Filter the query by primary key
     *
     * @param     mixed $key Primary key to use for the query
     *
     * @return AppProfileAclQuery The current query, for fluid interface
     */
    public function filterByPrimaryKey($key)
    {
        $this->addUsingAlias(AppProfileAclPeer::MODULE_ID, $key[0], Criteria::EQUAL);
        $this->addUsingAlias(AppProfileAclPeer::ACTION_ID, $key[1], Criteria::EQUAL);
        $this->addUsingAlias(AppProfileAclPeer::PROFILE_ID, $key[2], Criteria::EQUAL);

        return $this;
    }

    /**
     * Filter the query by a list of primary keys
     *
     * @param     array $keys The list of primary key to use for the query
     *
     * @return AppProfileAclQuery The current query, for fluid interface
     */
    public function filterByPrimaryKeys($keys)
    {
        if (empty($keys)) {
            return $this->add(null, '1<>1', Criteria::CUSTOM);
        }
        foreach ($keys as $key) {
            $cton0 = $this->getNewCriterion(AppProfileAclPeer::MODULE_ID, $key[0], Criteria::EQUAL);
            $cton1 = $this->getNewCriterion(AppProfileAclPeer::ACTION_ID, $key[1], Criteria::EQUAL);
            $cton0->addAnd($cton1);
            $cton2 = $this->getNewCriterion(AppProfileAclPeer::PROFILE_ID, $key[2], Criteria::EQUAL);
            $cton0->addAnd($cton2);
            $this->addOr($cton0);
        }

        return $this;
    }

    /**
     * Filter the query on the module_id column
     *
     * Example usage:
     * <code>
     * $query->filterByModuleId('fooValue');   // WHERE module_id = 'fooValue'
     * $query->filterByModuleId('%fooValue%'); // WHERE module_id LIKE '%fooValue%'
     * </code>
     *
     * @param     string $moduleId The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return AppProfileAclQuery The current query, for fluid interface
     */
    public function filterByModuleId($moduleId = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($moduleId)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $moduleId)) {
                $moduleId = str_replace('*', '%', $moduleId);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(AppProfileAclPeer::MODULE_ID, $moduleId, $comparison);
    }

    /**
     * Filter the query on the action_id column
     *
     * Example usage:
     * <code>
     * $query->filterByActionId(1234); // WHERE action_id = 1234
     * $query->filterByActionId(array(12, 34)); // WHERE action_id IN (12, 34)
     * $query->filterByActionId(array('min' => 12)); // WHERE action_id >= 12
     * $query->filterByActionId(array('max' => 12)); // WHERE action_id <= 12
     * </code>
     *
     * @see       filterByAppAction()
     *
     * @param     mixed $actionId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return AppProfileAclQuery The current query, for fluid interface
     */
    public function filterByActionId($actionId = null, $comparison = null)
    {
        if (is_array($actionId)) {
            $useMinMax = false;
            if (isset($actionId['min'])) {
                $this->addUsingAlias(AppProfileAclPeer::ACTION_ID, $actionId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($actionId['max'])) {
                $this->addUsingAlias(AppProfileAclPeer::ACTION_ID, $actionId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(AppProfileAclPeer::ACTION_ID, $actionId, $comparison);
    }

    /**
     * Filter the query on the profile_id column
     *
     * Example usage:
     * <code>
     * $query->filterByProfileId(1234); // WHERE profile_id = 1234
     * $query->filterByProfileId(array(12, 34)); // WHERE profile_id IN (12, 34)
     * $query->filterByProfileId(array('min' => 12)); // WHERE profile_id >= 12
     * $query->filterByProfileId(array('max' => 12)); // WHERE profile_id <= 12
     * </code>
     *
     * @see       filterByAppProfile()
     *
     * @param     mixed $profileId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return AppProfileAclQuery The current query, for fluid interface
     */
    public function filterByProfileId($profileId = null, $comparison = null)
    {
        if (is_array($profileId)) {
            $useMinMax = false;
            if (isset($profileId['min'])) {
                $this->addUsingAlias(AppProfileAclPeer::PROFILE_ID, $profileId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($profileId['max'])) {
                $this->addUsingAlias(AppProfileAclPeer::PROFILE_ID, $profileId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(AppProfileAclPeer::PROFILE_ID, $profileId, $comparison);
    }

    /**
     * Filter the query on the action column
     *
     * Example usage:
     * <code>
     * $query->filterByAction('fooValue');   // WHERE action = 'fooValue'
     * $query->filterByAction('%fooValue%'); // WHERE action LIKE '%fooValue%'
     * </code>
     *
     * @param     string $action The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return AppProfileAclQuery The current query, for fluid interface
     */
    public function filterByAction($action = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($action)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $action)) {
                $action = str_replace('*', '%', $action);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(AppProfileAclPeer::ACTION, $action, $comparison);
    }

    /**
     * Filter the query by a related AppProfile object
     *
     * @param   AppProfile|PropelObjectCollection $appProfile The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 AppProfileAclQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByAppProfile($appProfile, $comparison = null)
    {
        if ($appProfile instanceof AppProfile) {
            return $this
                ->addUsingAlias(AppProfileAclPeer::PROFILE_ID, $appProfile->getProfileId(), $comparison);
        } elseif ($appProfile instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(AppProfileAclPeer::PROFILE_ID, $appProfile->toKeyValue('PrimaryKey', 'ProfileId'), $comparison);
        } else {
            throw new PropelException('filterByAppProfile() only accepts arguments of type AppProfile or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the AppProfile relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return AppProfileAclQuery The current query, for fluid interface
     */
    public function joinAppProfile($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('AppProfile');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'AppProfile');
        }

        return $this;
    }

    /**
     * Use the AppProfile relation AppProfile object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   AppProfileQuery A secondary query class using the current class as primary query
     */
    public function useAppProfileQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinAppProfile($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'AppProfile', 'AppProfileQuery');
    }

    /**
     * Filter the query by a related AppAction object
     *
     * @param   AppAction|PropelObjectCollection $appAction The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 AppProfileAclQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByAppAction($appAction, $comparison = null)
    {
        if ($appAction instanceof AppAction) {
            return $this
                ->addUsingAlias(AppProfileAclPeer::ACTION_ID, $appAction->getActionId(), $comparison);
        } elseif ($appAction instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(AppProfileAclPeer::ACTION_ID, $appAction->toKeyValue('PrimaryKey', 'ActionId'), $comparison);
        } else {
            throw new PropelException('filterByAppAction() only accepts arguments of type AppAction or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the AppAction relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return AppProfileAclQuery The current query, for fluid interface
     */
    public function joinAppAction($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('AppAction');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'AppAction');
        }

        return $this;
    }

    /**
     * Use the AppAction relation AppAction object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   AppActionQuery A secondary query class using the current class as primary query
     */
    public function useAppActionQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinAppAction($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'AppAction', 'AppActionQuery');
    }

    /**
     * Filter the query by a related AppModule object
     *
     * @param   AppModule|PropelObjectCollection $appModule The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 AppProfileAclQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByAppModule($appModule, $comparison = null)
    {
        if ($appModule instanceof AppModule) {
            return $this
                ->addUsingAlias(AppProfileAclPeer::MODULE_ID, $appModule->getModuleId(), $comparison);
        } elseif ($appModule instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(AppProfileAclPeer::MODULE_ID, $appModule->toKeyValue('PrimaryKey', 'ModuleId'), $comparison);
        } else {
            throw new PropelException('filterByAppModule() only accepts arguments of type AppModule or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the AppModule relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return AppProfileAclQuery The current query, for fluid interface
     */
    public function joinAppModule($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('AppModule');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'AppModule');
        }

        return $this;
    }

    /**
     * Use the AppModule relation AppModule object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   AppModuleQuery A secondary query class using the current class as primary query
     */
    public function useAppModuleQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinAppModule($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'AppModule', 'AppModuleQuery');
    }

    /**
     * Exclude object from result
     *
     * @param   AppProfileAcl $appProfileAcl Object to remove from the list of results
     *
     * @return AppProfileAclQuery The current query, for fluid interface
     */
    public function prune($appProfileAcl = null)
    {
        if ($appProfileAcl) {
            $this->addCond('pruneCond0', $this->getAliasedColName(AppProfileAclPeer::MODULE_ID), $appProfileAcl->getModuleId(), Criteria::NOT_EQUAL);
            $this->addCond('pruneCond1', $this->getAliasedColName(AppProfileAclPeer::ACTION_ID), $appProfileAcl->getActionId(), Criteria::NOT_EQUAL);
            $this->addCond('pruneCond2', $this->getAliasedColName(AppProfileAclPeer::PROFILE_ID), $appProfileAcl->getProfileId(), Criteria::NOT_EQUAL);
            $this->combine(array('pruneCond0', 'pruneCond1', 'pruneCond2'), Criteria::LOGICAL_OR);
        }

        return $this;
    }

}
