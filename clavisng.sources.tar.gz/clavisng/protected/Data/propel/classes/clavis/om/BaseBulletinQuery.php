<?php


/**
 * Base class that represents a query for the 'bulletin' table.
 *
 *
 *
 * @method BulletinQuery orderByBulletinId($order = Criteria::ASC) Order by the bulletin_id column
 * @method BulletinQuery orderByPublishStartDate($order = Criteria::ASC) Order by the publish_start_date column
 * @method BulletinQuery orderByPublishEndDate($order = Criteria::ASC) Order by the publish_end_date column
 * @method BulletinQuery orderByTitle($order = Criteria::ASC) Order by the title column
 * @method BulletinQuery orderByBody($order = Criteria::ASC) Order by the body column
 * @method BulletinQuery orderByScope($order = Criteria::ASC) Order by the scope column
 * @method BulletinQuery orderBySticky($order = Criteria::ASC) Order by the sticky column
 * @method BulletinQuery orderByProtectedMessage($order = Criteria::ASC) Order by the protected_message column
 * @method BulletinQuery orderByLibrarianId($order = Criteria::ASC) Order by the librarian_id column
 * @method BulletinQuery orderByLibraryId($order = Criteria::ASC) Order by the library_id column
 * @method BulletinQuery orderByDateCreated($order = Criteria::ASC) Order by the date_created column
 * @method BulletinQuery orderByDateUpdated($order = Criteria::ASC) Order by the date_updated column
 * @method BulletinQuery orderByCreatedBy($order = Criteria::ASC) Order by the created_by column
 * @method BulletinQuery orderByModifiedBy($order = Criteria::ASC) Order by the modified_by column
 *
 * @method BulletinQuery groupByBulletinId() Group by the bulletin_id column
 * @method BulletinQuery groupByPublishStartDate() Group by the publish_start_date column
 * @method BulletinQuery groupByPublishEndDate() Group by the publish_end_date column
 * @method BulletinQuery groupByTitle() Group by the title column
 * @method BulletinQuery groupByBody() Group by the body column
 * @method BulletinQuery groupByScope() Group by the scope column
 * @method BulletinQuery groupBySticky() Group by the sticky column
 * @method BulletinQuery groupByProtectedMessage() Group by the protected_message column
 * @method BulletinQuery groupByLibrarianId() Group by the librarian_id column
 * @method BulletinQuery groupByLibraryId() Group by the library_id column
 * @method BulletinQuery groupByDateCreated() Group by the date_created column
 * @method BulletinQuery groupByDateUpdated() Group by the date_updated column
 * @method BulletinQuery groupByCreatedBy() Group by the created_by column
 * @method BulletinQuery groupByModifiedBy() Group by the modified_by column
 *
 * @method BulletinQuery leftJoin($relation) Adds a LEFT JOIN clause to the query
 * @method BulletinQuery rightJoin($relation) Adds a RIGHT JOIN clause to the query
 * @method BulletinQuery innerJoin($relation) Adds a INNER JOIN clause to the query
 *
 * @method BulletinQuery leftJoinLibrarianRelatedByCreatedBy($relationAlias = null) Adds a LEFT JOIN clause to the query using the LibrarianRelatedByCreatedBy relation
 * @method BulletinQuery rightJoinLibrarianRelatedByCreatedBy($relationAlias = null) Adds a RIGHT JOIN clause to the query using the LibrarianRelatedByCreatedBy relation
 * @method BulletinQuery innerJoinLibrarianRelatedByCreatedBy($relationAlias = null) Adds a INNER JOIN clause to the query using the LibrarianRelatedByCreatedBy relation
 *
 * @method BulletinQuery leftJoinLibrarianRelatedByModifiedBy($relationAlias = null) Adds a LEFT JOIN clause to the query using the LibrarianRelatedByModifiedBy relation
 * @method BulletinQuery rightJoinLibrarianRelatedByModifiedBy($relationAlias = null) Adds a RIGHT JOIN clause to the query using the LibrarianRelatedByModifiedBy relation
 * @method BulletinQuery innerJoinLibrarianRelatedByModifiedBy($relationAlias = null) Adds a INNER JOIN clause to the query using the LibrarianRelatedByModifiedBy relation
 *
 * @method BulletinQuery leftJoinLibrary($relationAlias = null) Adds a LEFT JOIN clause to the query using the Library relation
 * @method BulletinQuery rightJoinLibrary($relationAlias = null) Adds a RIGHT JOIN clause to the query using the Library relation
 * @method BulletinQuery innerJoinLibrary($relationAlias = null) Adds a INNER JOIN clause to the query using the Library relation
 *
 * @method BulletinQuery leftJoinLibrarianRelatedByLibrarianId($relationAlias = null) Adds a LEFT JOIN clause to the query using the LibrarianRelatedByLibrarianId relation
 * @method BulletinQuery rightJoinLibrarianRelatedByLibrarianId($relationAlias = null) Adds a RIGHT JOIN clause to the query using the LibrarianRelatedByLibrarianId relation
 * @method BulletinQuery innerJoinLibrarianRelatedByLibrarianId($relationAlias = null) Adds a INNER JOIN clause to the query using the LibrarianRelatedByLibrarianId relation
 *
 * @method Bulletin findOne(PropelPDO $con = null) Return the first Bulletin matching the query
 * @method Bulletin findOneOrCreate(PropelPDO $con = null) Return the first Bulletin matching the query, or a new Bulletin object populated from the query conditions when no match is found
 *
 * @method Bulletin findOneByPublishStartDate(string $publish_start_date) Return the first Bulletin filtered by the publish_start_date column
 * @method Bulletin findOneByPublishEndDate(string $publish_end_date) Return the first Bulletin filtered by the publish_end_date column
 * @method Bulletin findOneByTitle(string $title) Return the first Bulletin filtered by the title column
 * @method Bulletin findOneByBody(string $body) Return the first Bulletin filtered by the body column
 * @method Bulletin findOneByScope(string $scope) Return the first Bulletin filtered by the scope column
 * @method Bulletin findOneBySticky(boolean $sticky) Return the first Bulletin filtered by the sticky column
 * @method Bulletin findOneByProtectedMessage(boolean $protected_message) Return the first Bulletin filtered by the protected_message column
 * @method Bulletin findOneByLibrarianId(int $librarian_id) Return the first Bulletin filtered by the librarian_id column
 * @method Bulletin findOneByLibraryId(int $library_id) Return the first Bulletin filtered by the library_id column
 * @method Bulletin findOneByDateCreated(string $date_created) Return the first Bulletin filtered by the date_created column
 * @method Bulletin findOneByDateUpdated(string $date_updated) Return the first Bulletin filtered by the date_updated column
 * @method Bulletin findOneByCreatedBy(int $created_by) Return the first Bulletin filtered by the created_by column
 * @method Bulletin findOneByModifiedBy(int $modified_by) Return the first Bulletin filtered by the modified_by column
 *
 * @method array findByBulletinId(int $bulletin_id) Return Bulletin objects filtered by the bulletin_id column
 * @method array findByPublishStartDate(string $publish_start_date) Return Bulletin objects filtered by the publish_start_date column
 * @method array findByPublishEndDate(string $publish_end_date) Return Bulletin objects filtered by the publish_end_date column
 * @method array findByTitle(string $title) Return Bulletin objects filtered by the title column
 * @method array findByBody(string $body) Return Bulletin objects filtered by the body column
 * @method array findByScope(string $scope) Return Bulletin objects filtered by the scope column
 * @method array findBySticky(boolean $sticky) Return Bulletin objects filtered by the sticky column
 * @method array findByProtectedMessage(boolean $protected_message) Return Bulletin objects filtered by the protected_message column
 * @method array findByLibrarianId(int $librarian_id) Return Bulletin objects filtered by the librarian_id column
 * @method array findByLibraryId(int $library_id) Return Bulletin objects filtered by the library_id column
 * @method array findByDateCreated(string $date_created) Return Bulletin objects filtered by the date_created column
 * @method array findByDateUpdated(string $date_updated) Return Bulletin objects filtered by the date_updated column
 * @method array findByCreatedBy(int $created_by) Return Bulletin objects filtered by the created_by column
 * @method array findByModifiedBy(int $modified_by) Return Bulletin objects filtered by the modified_by column
 *
 * @package    propel.generator.clavis.om
 */
abstract class BaseBulletinQuery extends ModelCriteria
{
    /**
     * Initializes internal state of BaseBulletinQuery object.
     *
     * @param     string $dbName The dabase name
     * @param     string $modelName The phpName of a model, e.g. 'Book'
     * @param     string $modelAlias The alias for the model in this query, e.g. 'b'
     */
    public function __construct($dbName = null, $modelName = null, $modelAlias = null)
    {
        if (null === $dbName) {
            $dbName = 'clavis';
        }
        if (null === $modelName) {
            $modelName = 'Bulletin';
        }
        parent::__construct($dbName, $modelName, $modelAlias);
    }

    /**
     * Returns a new BulletinQuery object.
     *
     * @param     string $modelAlias The alias of a model in the query
     * @param   BulletinQuery|Criteria $criteria Optional Criteria to build the query from
     *
     * @return BulletinQuery
     */
    public static function create($modelAlias = null, $criteria = null)
    {
        if ($criteria instanceof BulletinQuery) {
            return $criteria;
        }
        $query = new BulletinQuery(null, null, $modelAlias);

        if ($criteria instanceof Criteria) {
            $query->mergeWith($criteria);
        }

        return $query;
    }

    /**
     * Find object by primary key.
     * Propel uses the instance pool to skip the database if the object exists.
     * Go fast if the query is untouched.
     *
     * <code>
     * $obj  = $c->findPk(12, $con);
     * </code>
     *
     * @param mixed $key Primary key to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return   Bulletin|Bulletin[]|mixed the result, formatted by the current formatter
     */
    public function findPk($key, $con = null)
    {
        if ($key === null) {
            return null;
        }
        if ((null !== ($obj = BulletinPeer::getInstanceFromPool((string) $key))) && !$this->formatter) {
            // the object is already in the instance pool
            return $obj;
        }
        if ($con === null) {
            $con = Propel::getConnection(BulletinPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        if ($this->formatter || $this->modelAlias || $this->with || $this->select
         || $this->selectColumns || $this->asColumns || $this->selectModifiers
         || $this->map || $this->having || $this->joins) {
            return $this->findPkComplex($key, $con);
        } else {
            return $this->findPkSimple($key, $con);
        }
    }

    /**
     * Alias of findPk to use instance pooling
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 Bulletin A model object, or null if the key is not found
     * @throws PropelException
     */
     public function findOneByBulletinId($key, $con = null)
     {
        return $this->findPk($key, $con);
     }

    /**
     * Find object by primary key using raw SQL to go fast.
     * Bypass doSelect() and the object formatter by using generated code.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 Bulletin A model object, or null if the key is not found
     * @throws PropelException
     */
    protected function findPkSimple($key, $con)
    {
        $sql = 'SELECT `bulletin_id`, `publish_start_date`, `publish_end_date`, `title`, `body`, `scope`, `sticky`, `protected_message`, `librarian_id`, `library_id`, `date_created`, `date_updated`, `created_by`, `modified_by` FROM `bulletin` WHERE `bulletin_id` = :p0';
        try {
            $stmt = $con->prepare($sql);
            $stmt->bindValue(':p0', $key, PDO::PARAM_INT);
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute SELECT statement [%s]', $sql), $e);
        }
        $obj = null;
        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $obj = new Bulletin();
            $obj->hydrate($row);
            BulletinPeer::addInstanceToPool($obj, (string) $key);
        }
        $stmt->closeCursor();

        return $obj;
    }

    /**
     * Find object by primary key.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return Bulletin|Bulletin[]|mixed the result, formatted by the current formatter
     */
    protected function findPkComplex($key, $con)
    {
        // As the query uses a PK condition, no limit(1) is necessary.
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKey($key)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->formatOne($stmt);
    }

    /**
     * Find objects by primary key
     * <code>
     * $objs = $c->findPks(array(12, 56, 832), $con);
     * </code>
     * @param     array $keys Primary keys to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return PropelObjectCollection|Bulletin[]|mixed the list of results, formatted by the current formatter
     */
    public function findPks($keys, $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection($this->getDbName(), Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKeys($keys)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->format($stmt);
    }

    /**
     * Filter the query by primary key
     *
     * @param     mixed $key Primary key to use for the query
     *
     * @return BulletinQuery The current query, for fluid interface
     */
    public function filterByPrimaryKey($key)
    {

        return $this->addUsingAlias(BulletinPeer::BULLETIN_ID, $key, Criteria::EQUAL);
    }

    /**
     * Filter the query by a list of primary keys
     *
     * @param     array $keys The list of primary key to use for the query
     *
     * @return BulletinQuery The current query, for fluid interface
     */
    public function filterByPrimaryKeys($keys)
    {

        return $this->addUsingAlias(BulletinPeer::BULLETIN_ID, $keys, Criteria::IN);
    }

    /**
     * Filter the query on the bulletin_id column
     *
     * Example usage:
     * <code>
     * $query->filterByBulletinId(1234); // WHERE bulletin_id = 1234
     * $query->filterByBulletinId(array(12, 34)); // WHERE bulletin_id IN (12, 34)
     * $query->filterByBulletinId(array('min' => 12)); // WHERE bulletin_id >= 12
     * $query->filterByBulletinId(array('max' => 12)); // WHERE bulletin_id <= 12
     * </code>
     *
     * @param     mixed $bulletinId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return BulletinQuery The current query, for fluid interface
     */
    public function filterByBulletinId($bulletinId = null, $comparison = null)
    {
        if (is_array($bulletinId)) {
            $useMinMax = false;
            if (isset($bulletinId['min'])) {
                $this->addUsingAlias(BulletinPeer::BULLETIN_ID, $bulletinId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($bulletinId['max'])) {
                $this->addUsingAlias(BulletinPeer::BULLETIN_ID, $bulletinId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(BulletinPeer::BULLETIN_ID, $bulletinId, $comparison);
    }

    /**
     * Filter the query on the publish_start_date column
     *
     * Example usage:
     * <code>
     * $query->filterByPublishStartDate('2011-03-14'); // WHERE publish_start_date = '2011-03-14'
     * $query->filterByPublishStartDate('now'); // WHERE publish_start_date = '2011-03-14'
     * $query->filterByPublishStartDate(array('max' => 'yesterday')); // WHERE publish_start_date < '2011-03-13'
     * </code>
     *
     * @param     mixed $publishStartDate The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return BulletinQuery The current query, for fluid interface
     */
    public function filterByPublishStartDate($publishStartDate = null, $comparison = null)
    {
        if (is_array($publishStartDate)) {
            $useMinMax = false;
            if (isset($publishStartDate['min'])) {
                $this->addUsingAlias(BulletinPeer::PUBLISH_START_DATE, $publishStartDate['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($publishStartDate['max'])) {
                $this->addUsingAlias(BulletinPeer::PUBLISH_START_DATE, $publishStartDate['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(BulletinPeer::PUBLISH_START_DATE, $publishStartDate, $comparison);
    }

    /**
     * Filter the query on the publish_end_date column
     *
     * Example usage:
     * <code>
     * $query->filterByPublishEndDate('2011-03-14'); // WHERE publish_end_date = '2011-03-14'
     * $query->filterByPublishEndDate('now'); // WHERE publish_end_date = '2011-03-14'
     * $query->filterByPublishEndDate(array('max' => 'yesterday')); // WHERE publish_end_date < '2011-03-13'
     * </code>
     *
     * @param     mixed $publishEndDate The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return BulletinQuery The current query, for fluid interface
     */
    public function filterByPublishEndDate($publishEndDate = null, $comparison = null)
    {
        if (is_array($publishEndDate)) {
            $useMinMax = false;
            if (isset($publishEndDate['min'])) {
                $this->addUsingAlias(BulletinPeer::PUBLISH_END_DATE, $publishEndDate['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($publishEndDate['max'])) {
                $this->addUsingAlias(BulletinPeer::PUBLISH_END_DATE, $publishEndDate['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(BulletinPeer::PUBLISH_END_DATE, $publishEndDate, $comparison);
    }

    /**
     * Filter the query on the title column
     *
     * Example usage:
     * <code>
     * $query->filterByTitle('fooValue');   // WHERE title = 'fooValue'
     * $query->filterByTitle('%fooValue%'); // WHERE title LIKE '%fooValue%'
     * </code>
     *
     * @param     string $title The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return BulletinQuery The current query, for fluid interface
     */
    public function filterByTitle($title = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($title)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $title)) {
                $title = str_replace('*', '%', $title);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(BulletinPeer::TITLE, $title, $comparison);
    }

    /**
     * Filter the query on the body column
     *
     * Example usage:
     * <code>
     * $query->filterByBody('fooValue');   // WHERE body = 'fooValue'
     * $query->filterByBody('%fooValue%'); // WHERE body LIKE '%fooValue%'
     * </code>
     *
     * @param     string $body The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return BulletinQuery The current query, for fluid interface
     */
    public function filterByBody($body = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($body)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $body)) {
                $body = str_replace('*', '%', $body);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(BulletinPeer::BODY, $body, $comparison);
    }

    /**
     * Filter the query on the scope column
     *
     * Example usage:
     * <code>
     * $query->filterByScope('fooValue');   // WHERE scope = 'fooValue'
     * $query->filterByScope('%fooValue%'); // WHERE scope LIKE '%fooValue%'
     * </code>
     *
     * @param     string $scope The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return BulletinQuery The current query, for fluid interface
     */
    public function filterByScope($scope = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($scope)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $scope)) {
                $scope = str_replace('*', '%', $scope);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(BulletinPeer::SCOPE, $scope, $comparison);
    }

    /**
     * Filter the query on the sticky column
     *
     * Example usage:
     * <code>
     * $query->filterBySticky(true); // WHERE sticky = true
     * $query->filterBySticky('yes'); // WHERE sticky = true
     * </code>
     *
     * @param     boolean|string $sticky The value to use as filter.
     *              Non-boolean arguments are converted using the following rules:
     *                * 1, '1', 'true',  'on',  and 'yes' are converted to boolean true
     *                * 0, '0', 'false', 'off', and 'no'  are converted to boolean false
     *              Check on string values is case insensitive (so 'FaLsE' is seen as 'false').
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return BulletinQuery The current query, for fluid interface
     */
    public function filterBySticky($sticky = null, $comparison = null)
    {
        if (is_string($sticky)) {
            $sticky = in_array(strtolower($sticky), array('false', 'off', '-', 'no', 'n', '0', '')) ? false : true;
        }

        return $this->addUsingAlias(BulletinPeer::STICKY, $sticky, $comparison);
    }

    /**
     * Filter the query on the protected_message column
     *
     * Example usage:
     * <code>
     * $query->filterByProtectedMessage(true); // WHERE protected_message = true
     * $query->filterByProtectedMessage('yes'); // WHERE protected_message = true
     * </code>
     *
     * @param     boolean|string $protectedMessage The value to use as filter.
     *              Non-boolean arguments are converted using the following rules:
     *                * 1, '1', 'true',  'on',  and 'yes' are converted to boolean true
     *                * 0, '0', 'false', 'off', and 'no'  are converted to boolean false
     *              Check on string values is case insensitive (so 'FaLsE' is seen as 'false').
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return BulletinQuery The current query, for fluid interface
     */
    public function filterByProtectedMessage($protectedMessage = null, $comparison = null)
    {
        if (is_string($protectedMessage)) {
            $protectedMessage = in_array(strtolower($protectedMessage), array('false', 'off', '-', 'no', 'n', '0', '')) ? false : true;
        }

        return $this->addUsingAlias(BulletinPeer::PROTECTED_MESSAGE, $protectedMessage, $comparison);
    }

    /**
     * Filter the query on the librarian_id column
     *
     * Example usage:
     * <code>
     * $query->filterByLibrarianId(1234); // WHERE librarian_id = 1234
     * $query->filterByLibrarianId(array(12, 34)); // WHERE librarian_id IN (12, 34)
     * $query->filterByLibrarianId(array('min' => 12)); // WHERE librarian_id >= 12
     * $query->filterByLibrarianId(array('max' => 12)); // WHERE librarian_id <= 12
     * </code>
     *
     * @see       filterByLibrarianRelatedByLibrarianId()
     *
     * @param     mixed $librarianId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return BulletinQuery The current query, for fluid interface
     */
    public function filterByLibrarianId($librarianId = null, $comparison = null)
    {
        if (is_array($librarianId)) {
            $useMinMax = false;
            if (isset($librarianId['min'])) {
                $this->addUsingAlias(BulletinPeer::LIBRARIAN_ID, $librarianId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($librarianId['max'])) {
                $this->addUsingAlias(BulletinPeer::LIBRARIAN_ID, $librarianId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(BulletinPeer::LIBRARIAN_ID, $librarianId, $comparison);
    }

    /**
     * Filter the query on the library_id column
     *
     * Example usage:
     * <code>
     * $query->filterByLibraryId(1234); // WHERE library_id = 1234
     * $query->filterByLibraryId(array(12, 34)); // WHERE library_id IN (12, 34)
     * $query->filterByLibraryId(array('min' => 12)); // WHERE library_id >= 12
     * $query->filterByLibraryId(array('max' => 12)); // WHERE library_id <= 12
     * </code>
     *
     * @see       filterByLibrary()
     *
     * @param     mixed $libraryId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return BulletinQuery The current query, for fluid interface
     */
    public function filterByLibraryId($libraryId = null, $comparison = null)
    {
        if (is_array($libraryId)) {
            $useMinMax = false;
            if (isset($libraryId['min'])) {
                $this->addUsingAlias(BulletinPeer::LIBRARY_ID, $libraryId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($libraryId['max'])) {
                $this->addUsingAlias(BulletinPeer::LIBRARY_ID, $libraryId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(BulletinPeer::LIBRARY_ID, $libraryId, $comparison);
    }

    /**
     * Filter the query on the date_created column
     *
     * Example usage:
     * <code>
     * $query->filterByDateCreated('2011-03-14'); // WHERE date_created = '2011-03-14'
     * $query->filterByDateCreated('now'); // WHERE date_created = '2011-03-14'
     * $query->filterByDateCreated(array('max' => 'yesterday')); // WHERE date_created < '2011-03-13'
     * </code>
     *
     * @param     mixed $dateCreated The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return BulletinQuery The current query, for fluid interface
     */
    public function filterByDateCreated($dateCreated = null, $comparison = null)
    {
        if (is_array($dateCreated)) {
            $useMinMax = false;
            if (isset($dateCreated['min'])) {
                $this->addUsingAlias(BulletinPeer::DATE_CREATED, $dateCreated['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dateCreated['max'])) {
                $this->addUsingAlias(BulletinPeer::DATE_CREATED, $dateCreated['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(BulletinPeer::DATE_CREATED, $dateCreated, $comparison);
    }

    /**
     * Filter the query on the date_updated column
     *
     * Example usage:
     * <code>
     * $query->filterByDateUpdated('2011-03-14'); // WHERE date_updated = '2011-03-14'
     * $query->filterByDateUpdated('now'); // WHERE date_updated = '2011-03-14'
     * $query->filterByDateUpdated(array('max' => 'yesterday')); // WHERE date_updated < '2011-03-13'
     * </code>
     *
     * @param     mixed $dateUpdated The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return BulletinQuery The current query, for fluid interface
     */
    public function filterByDateUpdated($dateUpdated = null, $comparison = null)
    {
        if (is_array($dateUpdated)) {
            $useMinMax = false;
            if (isset($dateUpdated['min'])) {
                $this->addUsingAlias(BulletinPeer::DATE_UPDATED, $dateUpdated['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dateUpdated['max'])) {
                $this->addUsingAlias(BulletinPeer::DATE_UPDATED, $dateUpdated['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(BulletinPeer::DATE_UPDATED, $dateUpdated, $comparison);
    }

    /**
     * Filter the query on the created_by column
     *
     * Example usage:
     * <code>
     * $query->filterByCreatedBy(1234); // WHERE created_by = 1234
     * $query->filterByCreatedBy(array(12, 34)); // WHERE created_by IN (12, 34)
     * $query->filterByCreatedBy(array('min' => 12)); // WHERE created_by >= 12
     * $query->filterByCreatedBy(array('max' => 12)); // WHERE created_by <= 12
     * </code>
     *
     * @see       filterByLibrarianRelatedByCreatedBy()
     *
     * @param     mixed $createdBy The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return BulletinQuery The current query, for fluid interface
     */
    public function filterByCreatedBy($createdBy = null, $comparison = null)
    {
        if (is_array($createdBy)) {
            $useMinMax = false;
            if (isset($createdBy['min'])) {
                $this->addUsingAlias(BulletinPeer::CREATED_BY, $createdBy['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($createdBy['max'])) {
                $this->addUsingAlias(BulletinPeer::CREATED_BY, $createdBy['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(BulletinPeer::CREATED_BY, $createdBy, $comparison);
    }

    /**
     * Filter the query on the modified_by column
     *
     * Example usage:
     * <code>
     * $query->filterByModifiedBy(1234); // WHERE modified_by = 1234
     * $query->filterByModifiedBy(array(12, 34)); // WHERE modified_by IN (12, 34)
     * $query->filterByModifiedBy(array('min' => 12)); // WHERE modified_by >= 12
     * $query->filterByModifiedBy(array('max' => 12)); // WHERE modified_by <= 12
     * </code>
     *
     * @see       filterByLibrarianRelatedByModifiedBy()
     *
     * @param     mixed $modifiedBy The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return BulletinQuery The current query, for fluid interface
     */
    public function filterByModifiedBy($modifiedBy = null, $comparison = null)
    {
        if (is_array($modifiedBy)) {
            $useMinMax = false;
            if (isset($modifiedBy['min'])) {
                $this->addUsingAlias(BulletinPeer::MODIFIED_BY, $modifiedBy['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($modifiedBy['max'])) {
                $this->addUsingAlias(BulletinPeer::MODIFIED_BY, $modifiedBy['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(BulletinPeer::MODIFIED_BY, $modifiedBy, $comparison);
    }

    /**
     * Filter the query by a related Librarian object
     *
     * @param   Librarian|PropelObjectCollection $librarian The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 BulletinQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByLibrarianRelatedByCreatedBy($librarian, $comparison = null)
    {
        if ($librarian instanceof Librarian) {
            return $this
                ->addUsingAlias(BulletinPeer::CREATED_BY, $librarian->getLibrarianId(), $comparison);
        } elseif ($librarian instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(BulletinPeer::CREATED_BY, $librarian->toKeyValue('PrimaryKey', 'LibrarianId'), $comparison);
        } else {
            throw new PropelException('filterByLibrarianRelatedByCreatedBy() only accepts arguments of type Librarian or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the LibrarianRelatedByCreatedBy relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return BulletinQuery The current query, for fluid interface
     */
    public function joinLibrarianRelatedByCreatedBy($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('LibrarianRelatedByCreatedBy');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'LibrarianRelatedByCreatedBy');
        }

        return $this;
    }

    /**
     * Use the LibrarianRelatedByCreatedBy relation Librarian object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   LibrarianQuery A secondary query class using the current class as primary query
     */
    public function useLibrarianRelatedByCreatedByQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinLibrarianRelatedByCreatedBy($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'LibrarianRelatedByCreatedBy', 'LibrarianQuery');
    }

    /**
     * Filter the query by a related Librarian object
     *
     * @param   Librarian|PropelObjectCollection $librarian The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 BulletinQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByLibrarianRelatedByModifiedBy($librarian, $comparison = null)
    {
        if ($librarian instanceof Librarian) {
            return $this
                ->addUsingAlias(BulletinPeer::MODIFIED_BY, $librarian->getLibrarianId(), $comparison);
        } elseif ($librarian instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(BulletinPeer::MODIFIED_BY, $librarian->toKeyValue('PrimaryKey', 'LibrarianId'), $comparison);
        } else {
            throw new PropelException('filterByLibrarianRelatedByModifiedBy() only accepts arguments of type Librarian or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the LibrarianRelatedByModifiedBy relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return BulletinQuery The current query, for fluid interface
     */
    public function joinLibrarianRelatedByModifiedBy($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('LibrarianRelatedByModifiedBy');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'LibrarianRelatedByModifiedBy');
        }

        return $this;
    }

    /**
     * Use the LibrarianRelatedByModifiedBy relation Librarian object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   LibrarianQuery A secondary query class using the current class as primary query
     */
    public function useLibrarianRelatedByModifiedByQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinLibrarianRelatedByModifiedBy($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'LibrarianRelatedByModifiedBy', 'LibrarianQuery');
    }

    /**
     * Filter the query by a related Library object
     *
     * @param   Library|PropelObjectCollection $library The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 BulletinQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByLibrary($library, $comparison = null)
    {
        if ($library instanceof Library) {
            return $this
                ->addUsingAlias(BulletinPeer::LIBRARY_ID, $library->getLibraryId(), $comparison);
        } elseif ($library instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(BulletinPeer::LIBRARY_ID, $library->toKeyValue('PrimaryKey', 'LibraryId'), $comparison);
        } else {
            throw new PropelException('filterByLibrary() only accepts arguments of type Library or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the Library relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return BulletinQuery The current query, for fluid interface
     */
    public function joinLibrary($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('Library');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'Library');
        }

        return $this;
    }

    /**
     * Use the Library relation Library object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   LibraryQuery A secondary query class using the current class as primary query
     */
    public function useLibraryQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinLibrary($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'Library', 'LibraryQuery');
    }

    /**
     * Filter the query by a related Librarian object
     *
     * @param   Librarian|PropelObjectCollection $librarian The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 BulletinQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByLibrarianRelatedByLibrarianId($librarian, $comparison = null)
    {
        if ($librarian instanceof Librarian) {
            return $this
                ->addUsingAlias(BulletinPeer::LIBRARIAN_ID, $librarian->getLibrarianId(), $comparison);
        } elseif ($librarian instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(BulletinPeer::LIBRARIAN_ID, $librarian->toKeyValue('PrimaryKey', 'LibrarianId'), $comparison);
        } else {
            throw new PropelException('filterByLibrarianRelatedByLibrarianId() only accepts arguments of type Librarian or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the LibrarianRelatedByLibrarianId relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return BulletinQuery The current query, for fluid interface
     */
    public function joinLibrarianRelatedByLibrarianId($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('LibrarianRelatedByLibrarianId');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'LibrarianRelatedByLibrarianId');
        }

        return $this;
    }

    /**
     * Use the LibrarianRelatedByLibrarianId relation Librarian object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   LibrarianQuery A secondary query class using the current class as primary query
     */
    public function useLibrarianRelatedByLibrarianIdQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinLibrarianRelatedByLibrarianId($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'LibrarianRelatedByLibrarianId', 'LibrarianQuery');
    }

    /**
     * Exclude object from result
     *
     * @param   Bulletin $bulletin Object to remove from the list of results
     *
     * @return BulletinQuery The current query, for fluid interface
     */
    public function prune($bulletin = null)
    {
        if ($bulletin) {
            $this->addUsingAlias(BulletinPeer::BULLETIN_ID, $bulletin->getBulletinId(), Criteria::NOT_EQUAL);
        }

        return $this;
    }

    // timestampable behavior

    /**
     * Filter by the latest updated
     *
     * @param      int $nbDays Maximum age of the latest update in days
     *
     * @return     BulletinQuery The current query, for fluid interface
     */
    public function recentlyUpdated($nbDays = 7)
    {
        return $this->addUsingAlias(BulletinPeer::DATE_UPDATED, time() - $nbDays * 24 * 60 * 60, Criteria::GREATER_EQUAL);
    }

    /**
     * Order by update date desc
     *
     * @return     BulletinQuery The current query, for fluid interface
     */
    public function lastUpdatedFirst()
    {
        return $this->addDescendingOrderByColumn(BulletinPeer::DATE_UPDATED);
    }

    /**
     * Order by update date asc
     *
     * @return     BulletinQuery The current query, for fluid interface
     */
    public function firstUpdatedFirst()
    {
        return $this->addAscendingOrderByColumn(BulletinPeer::DATE_UPDATED);
    }

    /**
     * Filter by the latest created
     *
     * @param      int $nbDays Maximum age of in days
     *
     * @return     BulletinQuery The current query, for fluid interface
     */
    public function recentlyCreated($nbDays = 7)
    {
        return $this->addUsingAlias(BulletinPeer::DATE_CREATED, time() - $nbDays * 24 * 60 * 60, Criteria::GREATER_EQUAL);
    }

    /**
     * Order by create date desc
     *
     * @return     BulletinQuery The current query, for fluid interface
     */
    public function lastCreatedFirst()
    {
        return $this->addDescendingOrderByColumn(BulletinPeer::DATE_CREATED);
    }

    /**
     * Order by create date asc
     *
     * @return     BulletinQuery The current query, for fluid interface
     */
    public function firstCreatedFirst()
    {
        return $this->addAscendingOrderByColumn(BulletinPeer::DATE_CREATED);
    }
}
