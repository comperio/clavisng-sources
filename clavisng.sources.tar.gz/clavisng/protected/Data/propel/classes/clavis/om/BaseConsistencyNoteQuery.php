<?php


/**
 * Base class that represents a query for the 'consistency_note' table.
 *
 *
 *
 * @method ConsistencyNoteQuery orderByConsistencyNoteId($order = Criteria::ASC) Order by the consistency_note_id column
 * @method ConsistencyNoteQuery orderByCollocation($order = Criteria::ASC) Order by the collocation column
 * @method ConsistencyNoteQuery orderByTextNote($order = Criteria::ASC) Order by the text_note column
 * @method ConsistencyNoteQuery orderByClosed($order = Criteria::ASC) Order by the closed column
 * @method ConsistencyNoteQuery orderByLibraryId($order = Criteria::ASC) Order by the library_id column
 * @method ConsistencyNoteQuery orderByManifestationId($order = Criteria::ASC) Order by the manifestation_id column
 * @method ConsistencyNoteQuery orderByDateCreated($order = Criteria::ASC) Order by the date_created column
 * @method ConsistencyNoteQuery orderByDateUpdated($order = Criteria::ASC) Order by the date_updated column
 * @method ConsistencyNoteQuery orderByCreatedBy($order = Criteria::ASC) Order by the created_by column
 * @method ConsistencyNoteQuery orderByModifiedBy($order = Criteria::ASC) Order by the modified_by column
 *
 * @method ConsistencyNoteQuery groupByConsistencyNoteId() Group by the consistency_note_id column
 * @method ConsistencyNoteQuery groupByCollocation() Group by the collocation column
 * @method ConsistencyNoteQuery groupByTextNote() Group by the text_note column
 * @method ConsistencyNoteQuery groupByClosed() Group by the closed column
 * @method ConsistencyNoteQuery groupByLibraryId() Group by the library_id column
 * @method ConsistencyNoteQuery groupByManifestationId() Group by the manifestation_id column
 * @method ConsistencyNoteQuery groupByDateCreated() Group by the date_created column
 * @method ConsistencyNoteQuery groupByDateUpdated() Group by the date_updated column
 * @method ConsistencyNoteQuery groupByCreatedBy() Group by the created_by column
 * @method ConsistencyNoteQuery groupByModifiedBy() Group by the modified_by column
 *
 * @method ConsistencyNoteQuery leftJoin($relation) Adds a LEFT JOIN clause to the query
 * @method ConsistencyNoteQuery rightJoin($relation) Adds a RIGHT JOIN clause to the query
 * @method ConsistencyNoteQuery innerJoin($relation) Adds a INNER JOIN clause to the query
 *
 * @method ConsistencyNoteQuery leftJoinLibrarianRelatedByCreatedBy($relationAlias = null) Adds a LEFT JOIN clause to the query using the LibrarianRelatedByCreatedBy relation
 * @method ConsistencyNoteQuery rightJoinLibrarianRelatedByCreatedBy($relationAlias = null) Adds a RIGHT JOIN clause to the query using the LibrarianRelatedByCreatedBy relation
 * @method ConsistencyNoteQuery innerJoinLibrarianRelatedByCreatedBy($relationAlias = null) Adds a INNER JOIN clause to the query using the LibrarianRelatedByCreatedBy relation
 *
 * @method ConsistencyNoteQuery leftJoinLibrarianRelatedByModifiedBy($relationAlias = null) Adds a LEFT JOIN clause to the query using the LibrarianRelatedByModifiedBy relation
 * @method ConsistencyNoteQuery rightJoinLibrarianRelatedByModifiedBy($relationAlias = null) Adds a RIGHT JOIN clause to the query using the LibrarianRelatedByModifiedBy relation
 * @method ConsistencyNoteQuery innerJoinLibrarianRelatedByModifiedBy($relationAlias = null) Adds a INNER JOIN clause to the query using the LibrarianRelatedByModifiedBy relation
 *
 * @method ConsistencyNoteQuery leftJoinLibrary($relationAlias = null) Adds a LEFT JOIN clause to the query using the Library relation
 * @method ConsistencyNoteQuery rightJoinLibrary($relationAlias = null) Adds a RIGHT JOIN clause to the query using the Library relation
 * @method ConsistencyNoteQuery innerJoinLibrary($relationAlias = null) Adds a INNER JOIN clause to the query using the Library relation
 *
 * @method ConsistencyNoteQuery leftJoinManifestation($relationAlias = null) Adds a LEFT JOIN clause to the query using the Manifestation relation
 * @method ConsistencyNoteQuery rightJoinManifestation($relationAlias = null) Adds a RIGHT JOIN clause to the query using the Manifestation relation
 * @method ConsistencyNoteQuery innerJoinManifestation($relationAlias = null) Adds a INNER JOIN clause to the query using the Manifestation relation
 *
 * @method ConsistencyNoteQuery leftJoinItem($relationAlias = null) Adds a LEFT JOIN clause to the query using the Item relation
 * @method ConsistencyNoteQuery rightJoinItem($relationAlias = null) Adds a RIGHT JOIN clause to the query using the Item relation
 * @method ConsistencyNoteQuery innerJoinItem($relationAlias = null) Adds a INNER JOIN clause to the query using the Item relation
 *
 * @method ConsistencyNote findOne(PropelPDO $con = null) Return the first ConsistencyNote matching the query
 * @method ConsistencyNote findOneOrCreate(PropelPDO $con = null) Return the first ConsistencyNote matching the query, or a new ConsistencyNote object populated from the query conditions when no match is found
 *
 * @method ConsistencyNote findOneByCollocation(string $collocation) Return the first ConsistencyNote filtered by the collocation column
 * @method ConsistencyNote findOneByTextNote(string $text_note) Return the first ConsistencyNote filtered by the text_note column
 * @method ConsistencyNote findOneByClosed(boolean $closed) Return the first ConsistencyNote filtered by the closed column
 * @method ConsistencyNote findOneByLibraryId(int $library_id) Return the first ConsistencyNote filtered by the library_id column
 * @method ConsistencyNote findOneByManifestationId(int $manifestation_id) Return the first ConsistencyNote filtered by the manifestation_id column
 * @method ConsistencyNote findOneByDateCreated(string $date_created) Return the first ConsistencyNote filtered by the date_created column
 * @method ConsistencyNote findOneByDateUpdated(string $date_updated) Return the first ConsistencyNote filtered by the date_updated column
 * @method ConsistencyNote findOneByCreatedBy(int $created_by) Return the first ConsistencyNote filtered by the created_by column
 * @method ConsistencyNote findOneByModifiedBy(int $modified_by) Return the first ConsistencyNote filtered by the modified_by column
 *
 * @method array findByConsistencyNoteId(int $consistency_note_id) Return ConsistencyNote objects filtered by the consistency_note_id column
 * @method array findByCollocation(string $collocation) Return ConsistencyNote objects filtered by the collocation column
 * @method array findByTextNote(string $text_note) Return ConsistencyNote objects filtered by the text_note column
 * @method array findByClosed(boolean $closed) Return ConsistencyNote objects filtered by the closed column
 * @method array findByLibraryId(int $library_id) Return ConsistencyNote objects filtered by the library_id column
 * @method array findByManifestationId(int $manifestation_id) Return ConsistencyNote objects filtered by the manifestation_id column
 * @method array findByDateCreated(string $date_created) Return ConsistencyNote objects filtered by the date_created column
 * @method array findByDateUpdated(string $date_updated) Return ConsistencyNote objects filtered by the date_updated column
 * @method array findByCreatedBy(int $created_by) Return ConsistencyNote objects filtered by the created_by column
 * @method array findByModifiedBy(int $modified_by) Return ConsistencyNote objects filtered by the modified_by column
 *
 * @package    propel.generator.clavis.om
 */
abstract class BaseConsistencyNoteQuery extends ModelCriteria
{
    /**
     * Initializes internal state of BaseConsistencyNoteQuery object.
     *
     * @param     string $dbName The dabase name
     * @param     string $modelName The phpName of a model, e.g. 'Book'
     * @param     string $modelAlias The alias for the model in this query, e.g. 'b'
     */
    public function __construct($dbName = null, $modelName = null, $modelAlias = null)
    {
        if (null === $dbName) {
            $dbName = 'clavis';
        }
        if (null === $modelName) {
            $modelName = 'ConsistencyNote';
        }
        parent::__construct($dbName, $modelName, $modelAlias);
    }

    /**
     * Returns a new ConsistencyNoteQuery object.
     *
     * @param     string $modelAlias The alias of a model in the query
     * @param   ConsistencyNoteQuery|Criteria $criteria Optional Criteria to build the query from
     *
     * @return ConsistencyNoteQuery
     */
    public static function create($modelAlias = null, $criteria = null)
    {
        if ($criteria instanceof ConsistencyNoteQuery) {
            return $criteria;
        }
        $query = new ConsistencyNoteQuery(null, null, $modelAlias);

        if ($criteria instanceof Criteria) {
            $query->mergeWith($criteria);
        }

        return $query;
    }

    /**
     * Find object by primary key.
     * Propel uses the instance pool to skip the database if the object exists.
     * Go fast if the query is untouched.
     *
     * <code>
     * $obj  = $c->findPk(12, $con);
     * </code>
     *
     * @param mixed $key Primary key to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return   ConsistencyNote|ConsistencyNote[]|mixed the result, formatted by the current formatter
     */
    public function findPk($key, $con = null)
    {
        if ($key === null) {
            return null;
        }
        if ((null !== ($obj = ConsistencyNotePeer::getInstanceFromPool((string) $key))) && !$this->formatter) {
            // the object is already in the instance pool
            return $obj;
        }
        if ($con === null) {
            $con = Propel::getConnection(ConsistencyNotePeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        if ($this->formatter || $this->modelAlias || $this->with || $this->select
         || $this->selectColumns || $this->asColumns || $this->selectModifiers
         || $this->map || $this->having || $this->joins) {
            return $this->findPkComplex($key, $con);
        } else {
            return $this->findPkSimple($key, $con);
        }
    }

    /**
     * Alias of findPk to use instance pooling
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 ConsistencyNote A model object, or null if the key is not found
     * @throws PropelException
     */
     public function findOneByConsistencyNoteId($key, $con = null)
     {
        return $this->findPk($key, $con);
     }

    /**
     * Find object by primary key using raw SQL to go fast.
     * Bypass doSelect() and the object formatter by using generated code.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 ConsistencyNote A model object, or null if the key is not found
     * @throws PropelException
     */
    protected function findPkSimple($key, $con)
    {
        $sql = 'SELECT `consistency_note_id`, `collocation`, `text_note`, `closed`, `library_id`, `manifestation_id`, `date_created`, `date_updated`, `created_by`, `modified_by` FROM `consistency_note` WHERE `consistency_note_id` = :p0';
        try {
            $stmt = $con->prepare($sql);
            $stmt->bindValue(':p0', $key, PDO::PARAM_INT);
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute SELECT statement [%s]', $sql), $e);
        }
        $obj = null;
        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $obj = new ConsistencyNote();
            $obj->hydrate($row);
            ConsistencyNotePeer::addInstanceToPool($obj, (string) $key);
        }
        $stmt->closeCursor();

        return $obj;
    }

    /**
     * Find object by primary key.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return ConsistencyNote|ConsistencyNote[]|mixed the result, formatted by the current formatter
     */
    protected function findPkComplex($key, $con)
    {
        // As the query uses a PK condition, no limit(1) is necessary.
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKey($key)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->formatOne($stmt);
    }

    /**
     * Find objects by primary key
     * <code>
     * $objs = $c->findPks(array(12, 56, 832), $con);
     * </code>
     * @param     array $keys Primary keys to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return PropelObjectCollection|ConsistencyNote[]|mixed the list of results, formatted by the current formatter
     */
    public function findPks($keys, $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection($this->getDbName(), Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKeys($keys)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->format($stmt);
    }

    /**
     * Filter the query by primary key
     *
     * @param     mixed $key Primary key to use for the query
     *
     * @return ConsistencyNoteQuery The current query, for fluid interface
     */
    public function filterByPrimaryKey($key)
    {

        return $this->addUsingAlias(ConsistencyNotePeer::CONSISTENCY_NOTE_ID, $key, Criteria::EQUAL);
    }

    /**
     * Filter the query by a list of primary keys
     *
     * @param     array $keys The list of primary key to use for the query
     *
     * @return ConsistencyNoteQuery The current query, for fluid interface
     */
    public function filterByPrimaryKeys($keys)
    {

        return $this->addUsingAlias(ConsistencyNotePeer::CONSISTENCY_NOTE_ID, $keys, Criteria::IN);
    }

    /**
     * Filter the query on the consistency_note_id column
     *
     * Example usage:
     * <code>
     * $query->filterByConsistencyNoteId(1234); // WHERE consistency_note_id = 1234
     * $query->filterByConsistencyNoteId(array(12, 34)); // WHERE consistency_note_id IN (12, 34)
     * $query->filterByConsistencyNoteId(array('min' => 12)); // WHERE consistency_note_id >= 12
     * $query->filterByConsistencyNoteId(array('max' => 12)); // WHERE consistency_note_id <= 12
     * </code>
     *
     * @param     mixed $consistencyNoteId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ConsistencyNoteQuery The current query, for fluid interface
     */
    public function filterByConsistencyNoteId($consistencyNoteId = null, $comparison = null)
    {
        if (is_array($consistencyNoteId)) {
            $useMinMax = false;
            if (isset($consistencyNoteId['min'])) {
                $this->addUsingAlias(ConsistencyNotePeer::CONSISTENCY_NOTE_ID, $consistencyNoteId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($consistencyNoteId['max'])) {
                $this->addUsingAlias(ConsistencyNotePeer::CONSISTENCY_NOTE_ID, $consistencyNoteId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ConsistencyNotePeer::CONSISTENCY_NOTE_ID, $consistencyNoteId, $comparison);
    }

    /**
     * Filter the query on the collocation column
     *
     * Example usage:
     * <code>
     * $query->filterByCollocation('fooValue');   // WHERE collocation = 'fooValue'
     * $query->filterByCollocation('%fooValue%'); // WHERE collocation LIKE '%fooValue%'
     * </code>
     *
     * @param     string $collocation The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ConsistencyNoteQuery The current query, for fluid interface
     */
    public function filterByCollocation($collocation = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($collocation)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $collocation)) {
                $collocation = str_replace('*', '%', $collocation);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(ConsistencyNotePeer::COLLOCATION, $collocation, $comparison);
    }

    /**
     * Filter the query on the text_note column
     *
     * Example usage:
     * <code>
     * $query->filterByTextNote('fooValue');   // WHERE text_note = 'fooValue'
     * $query->filterByTextNote('%fooValue%'); // WHERE text_note LIKE '%fooValue%'
     * </code>
     *
     * @param     string $textNote The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ConsistencyNoteQuery The current query, for fluid interface
     */
    public function filterByTextNote($textNote = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($textNote)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $textNote)) {
                $textNote = str_replace('*', '%', $textNote);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(ConsistencyNotePeer::TEXT_NOTE, $textNote, $comparison);
    }

    /**
     * Filter the query on the closed column
     *
     * Example usage:
     * <code>
     * $query->filterByClosed(true); // WHERE closed = true
     * $query->filterByClosed('yes'); // WHERE closed = true
     * </code>
     *
     * @param     boolean|string $closed The value to use as filter.
     *              Non-boolean arguments are converted using the following rules:
     *                * 1, '1', 'true',  'on',  and 'yes' are converted to boolean true
     *                * 0, '0', 'false', 'off', and 'no'  are converted to boolean false
     *              Check on string values is case insensitive (so 'FaLsE' is seen as 'false').
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ConsistencyNoteQuery The current query, for fluid interface
     */
    public function filterByClosed($closed = null, $comparison = null)
    {
        if (is_string($closed)) {
            $closed = in_array(strtolower($closed), array('false', 'off', '-', 'no', 'n', '0', '')) ? false : true;
        }

        return $this->addUsingAlias(ConsistencyNotePeer::CLOSED, $closed, $comparison);
    }

    /**
     * Filter the query on the library_id column
     *
     * Example usage:
     * <code>
     * $query->filterByLibraryId(1234); // WHERE library_id = 1234
     * $query->filterByLibraryId(array(12, 34)); // WHERE library_id IN (12, 34)
     * $query->filterByLibraryId(array('min' => 12)); // WHERE library_id >= 12
     * $query->filterByLibraryId(array('max' => 12)); // WHERE library_id <= 12
     * </code>
     *
     * @see       filterByLibrary()
     *
     * @param     mixed $libraryId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ConsistencyNoteQuery The current query, for fluid interface
     */
    public function filterByLibraryId($libraryId = null, $comparison = null)
    {
        if (is_array($libraryId)) {
            $useMinMax = false;
            if (isset($libraryId['min'])) {
                $this->addUsingAlias(ConsistencyNotePeer::LIBRARY_ID, $libraryId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($libraryId['max'])) {
                $this->addUsingAlias(ConsistencyNotePeer::LIBRARY_ID, $libraryId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ConsistencyNotePeer::LIBRARY_ID, $libraryId, $comparison);
    }

    /**
     * Filter the query on the manifestation_id column
     *
     * Example usage:
     * <code>
     * $query->filterByManifestationId(1234); // WHERE manifestation_id = 1234
     * $query->filterByManifestationId(array(12, 34)); // WHERE manifestation_id IN (12, 34)
     * $query->filterByManifestationId(array('min' => 12)); // WHERE manifestation_id >= 12
     * $query->filterByManifestationId(array('max' => 12)); // WHERE manifestation_id <= 12
     * </code>
     *
     * @see       filterByManifestation()
     *
     * @param     mixed $manifestationId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ConsistencyNoteQuery The current query, for fluid interface
     */
    public function filterByManifestationId($manifestationId = null, $comparison = null)
    {
        if (is_array($manifestationId)) {
            $useMinMax = false;
            if (isset($manifestationId['min'])) {
                $this->addUsingAlias(ConsistencyNotePeer::MANIFESTATION_ID, $manifestationId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($manifestationId['max'])) {
                $this->addUsingAlias(ConsistencyNotePeer::MANIFESTATION_ID, $manifestationId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ConsistencyNotePeer::MANIFESTATION_ID, $manifestationId, $comparison);
    }

    /**
     * Filter the query on the date_created column
     *
     * Example usage:
     * <code>
     * $query->filterByDateCreated('2011-03-14'); // WHERE date_created = '2011-03-14'
     * $query->filterByDateCreated('now'); // WHERE date_created = '2011-03-14'
     * $query->filterByDateCreated(array('max' => 'yesterday')); // WHERE date_created < '2011-03-13'
     * </code>
     *
     * @param     mixed $dateCreated The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ConsistencyNoteQuery The current query, for fluid interface
     */
    public function filterByDateCreated($dateCreated = null, $comparison = null)
    {
        if (is_array($dateCreated)) {
            $useMinMax = false;
            if (isset($dateCreated['min'])) {
                $this->addUsingAlias(ConsistencyNotePeer::DATE_CREATED, $dateCreated['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dateCreated['max'])) {
                $this->addUsingAlias(ConsistencyNotePeer::DATE_CREATED, $dateCreated['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ConsistencyNotePeer::DATE_CREATED, $dateCreated, $comparison);
    }

    /**
     * Filter the query on the date_updated column
     *
     * Example usage:
     * <code>
     * $query->filterByDateUpdated('2011-03-14'); // WHERE date_updated = '2011-03-14'
     * $query->filterByDateUpdated('now'); // WHERE date_updated = '2011-03-14'
     * $query->filterByDateUpdated(array('max' => 'yesterday')); // WHERE date_updated < '2011-03-13'
     * </code>
     *
     * @param     mixed $dateUpdated The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ConsistencyNoteQuery The current query, for fluid interface
     */
    public function filterByDateUpdated($dateUpdated = null, $comparison = null)
    {
        if (is_array($dateUpdated)) {
            $useMinMax = false;
            if (isset($dateUpdated['min'])) {
                $this->addUsingAlias(ConsistencyNotePeer::DATE_UPDATED, $dateUpdated['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dateUpdated['max'])) {
                $this->addUsingAlias(ConsistencyNotePeer::DATE_UPDATED, $dateUpdated['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ConsistencyNotePeer::DATE_UPDATED, $dateUpdated, $comparison);
    }

    /**
     * Filter the query on the created_by column
     *
     * Example usage:
     * <code>
     * $query->filterByCreatedBy(1234); // WHERE created_by = 1234
     * $query->filterByCreatedBy(array(12, 34)); // WHERE created_by IN (12, 34)
     * $query->filterByCreatedBy(array('min' => 12)); // WHERE created_by >= 12
     * $query->filterByCreatedBy(array('max' => 12)); // WHERE created_by <= 12
     * </code>
     *
     * @see       filterByLibrarianRelatedByCreatedBy()
     *
     * @param     mixed $createdBy The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ConsistencyNoteQuery The current query, for fluid interface
     */
    public function filterByCreatedBy($createdBy = null, $comparison = null)
    {
        if (is_array($createdBy)) {
            $useMinMax = false;
            if (isset($createdBy['min'])) {
                $this->addUsingAlias(ConsistencyNotePeer::CREATED_BY, $createdBy['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($createdBy['max'])) {
                $this->addUsingAlias(ConsistencyNotePeer::CREATED_BY, $createdBy['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ConsistencyNotePeer::CREATED_BY, $createdBy, $comparison);
    }

    /**
     * Filter the query on the modified_by column
     *
     * Example usage:
     * <code>
     * $query->filterByModifiedBy(1234); // WHERE modified_by = 1234
     * $query->filterByModifiedBy(array(12, 34)); // WHERE modified_by IN (12, 34)
     * $query->filterByModifiedBy(array('min' => 12)); // WHERE modified_by >= 12
     * $query->filterByModifiedBy(array('max' => 12)); // WHERE modified_by <= 12
     * </code>
     *
     * @see       filterByLibrarianRelatedByModifiedBy()
     *
     * @param     mixed $modifiedBy The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ConsistencyNoteQuery The current query, for fluid interface
     */
    public function filterByModifiedBy($modifiedBy = null, $comparison = null)
    {
        if (is_array($modifiedBy)) {
            $useMinMax = false;
            if (isset($modifiedBy['min'])) {
                $this->addUsingAlias(ConsistencyNotePeer::MODIFIED_BY, $modifiedBy['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($modifiedBy['max'])) {
                $this->addUsingAlias(ConsistencyNotePeer::MODIFIED_BY, $modifiedBy['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ConsistencyNotePeer::MODIFIED_BY, $modifiedBy, $comparison);
    }

    /**
     * Filter the query by a related Librarian object
     *
     * @param   Librarian|PropelObjectCollection $librarian The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 ConsistencyNoteQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByLibrarianRelatedByCreatedBy($librarian, $comparison = null)
    {
        if ($librarian instanceof Librarian) {
            return $this
                ->addUsingAlias(ConsistencyNotePeer::CREATED_BY, $librarian->getLibrarianId(), $comparison);
        } elseif ($librarian instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(ConsistencyNotePeer::CREATED_BY, $librarian->toKeyValue('PrimaryKey', 'LibrarianId'), $comparison);
        } else {
            throw new PropelException('filterByLibrarianRelatedByCreatedBy() only accepts arguments of type Librarian or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the LibrarianRelatedByCreatedBy relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return ConsistencyNoteQuery The current query, for fluid interface
     */
    public function joinLibrarianRelatedByCreatedBy($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('LibrarianRelatedByCreatedBy');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'LibrarianRelatedByCreatedBy');
        }

        return $this;
    }

    /**
     * Use the LibrarianRelatedByCreatedBy relation Librarian object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   LibrarianQuery A secondary query class using the current class as primary query
     */
    public function useLibrarianRelatedByCreatedByQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinLibrarianRelatedByCreatedBy($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'LibrarianRelatedByCreatedBy', 'LibrarianQuery');
    }

    /**
     * Filter the query by a related Librarian object
     *
     * @param   Librarian|PropelObjectCollection $librarian The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 ConsistencyNoteQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByLibrarianRelatedByModifiedBy($librarian, $comparison = null)
    {
        if ($librarian instanceof Librarian) {
            return $this
                ->addUsingAlias(ConsistencyNotePeer::MODIFIED_BY, $librarian->getLibrarianId(), $comparison);
        } elseif ($librarian instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(ConsistencyNotePeer::MODIFIED_BY, $librarian->toKeyValue('PrimaryKey', 'LibrarianId'), $comparison);
        } else {
            throw new PropelException('filterByLibrarianRelatedByModifiedBy() only accepts arguments of type Librarian or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the LibrarianRelatedByModifiedBy relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return ConsistencyNoteQuery The current query, for fluid interface
     */
    public function joinLibrarianRelatedByModifiedBy($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('LibrarianRelatedByModifiedBy');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'LibrarianRelatedByModifiedBy');
        }

        return $this;
    }

    /**
     * Use the LibrarianRelatedByModifiedBy relation Librarian object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   LibrarianQuery A secondary query class using the current class as primary query
     */
    public function useLibrarianRelatedByModifiedByQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinLibrarianRelatedByModifiedBy($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'LibrarianRelatedByModifiedBy', 'LibrarianQuery');
    }

    /**
     * Filter the query by a related Library object
     *
     * @param   Library|PropelObjectCollection $library The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 ConsistencyNoteQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByLibrary($library, $comparison = null)
    {
        if ($library instanceof Library) {
            return $this
                ->addUsingAlias(ConsistencyNotePeer::LIBRARY_ID, $library->getLibraryId(), $comparison);
        } elseif ($library instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(ConsistencyNotePeer::LIBRARY_ID, $library->toKeyValue('PrimaryKey', 'LibraryId'), $comparison);
        } else {
            throw new PropelException('filterByLibrary() only accepts arguments of type Library or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the Library relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return ConsistencyNoteQuery The current query, for fluid interface
     */
    public function joinLibrary($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('Library');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'Library');
        }

        return $this;
    }

    /**
     * Use the Library relation Library object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   LibraryQuery A secondary query class using the current class as primary query
     */
    public function useLibraryQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinLibrary($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'Library', 'LibraryQuery');
    }

    /**
     * Filter the query by a related Manifestation object
     *
     * @param   Manifestation|PropelObjectCollection $manifestation The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 ConsistencyNoteQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByManifestation($manifestation, $comparison = null)
    {
        if ($manifestation instanceof Manifestation) {
            return $this
                ->addUsingAlias(ConsistencyNotePeer::MANIFESTATION_ID, $manifestation->getManifestationId(), $comparison);
        } elseif ($manifestation instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(ConsistencyNotePeer::MANIFESTATION_ID, $manifestation->toKeyValue('PrimaryKey', 'ManifestationId'), $comparison);
        } else {
            throw new PropelException('filterByManifestation() only accepts arguments of type Manifestation or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the Manifestation relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return ConsistencyNoteQuery The current query, for fluid interface
     */
    public function joinManifestation($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('Manifestation');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'Manifestation');
        }

        return $this;
    }

    /**
     * Use the Manifestation relation Manifestation object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   ManifestationQuery A secondary query class using the current class as primary query
     */
    public function useManifestationQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinManifestation($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'Manifestation', 'ManifestationQuery');
    }

    /**
     * Filter the query by a related Item object
     *
     * @param   Item|PropelObjectCollection $item  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 ConsistencyNoteQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByItem($item, $comparison = null)
    {
        if ($item instanceof Item) {
            return $this
                ->addUsingAlias(ConsistencyNotePeer::CONSISTENCY_NOTE_ID, $item->getConsistencyNoteId(), $comparison);
        } elseif ($item instanceof PropelObjectCollection) {
            return $this
                ->useItemQuery()
                ->filterByPrimaryKeys($item->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByItem() only accepts arguments of type Item or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the Item relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return ConsistencyNoteQuery The current query, for fluid interface
     */
    public function joinItem($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('Item');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'Item');
        }

        return $this;
    }

    /**
     * Use the Item relation Item object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   ItemQuery A secondary query class using the current class as primary query
     */
    public function useItemQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinItem($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'Item', 'ItemQuery');
    }

    /**
     * Exclude object from result
     *
     * @param   ConsistencyNote $consistencyNote Object to remove from the list of results
     *
     * @return ConsistencyNoteQuery The current query, for fluid interface
     */
    public function prune($consistencyNote = null)
    {
        if ($consistencyNote) {
            $this->addUsingAlias(ConsistencyNotePeer::CONSISTENCY_NOTE_ID, $consistencyNote->getConsistencyNoteId(), Criteria::NOT_EQUAL);
        }

        return $this;
    }

    // timestampable behavior

    /**
     * Filter by the latest updated
     *
     * @param      int $nbDays Maximum age of the latest update in days
     *
     * @return     ConsistencyNoteQuery The current query, for fluid interface
     */
    public function recentlyUpdated($nbDays = 7)
    {
        return $this->addUsingAlias(ConsistencyNotePeer::DATE_UPDATED, time() - $nbDays * 24 * 60 * 60, Criteria::GREATER_EQUAL);
    }

    /**
     * Order by update date desc
     *
     * @return     ConsistencyNoteQuery The current query, for fluid interface
     */
    public function lastUpdatedFirst()
    {
        return $this->addDescendingOrderByColumn(ConsistencyNotePeer::DATE_UPDATED);
    }

    /**
     * Order by update date asc
     *
     * @return     ConsistencyNoteQuery The current query, for fluid interface
     */
    public function firstUpdatedFirst()
    {
        return $this->addAscendingOrderByColumn(ConsistencyNotePeer::DATE_UPDATED);
    }

    /**
     * Filter by the latest created
     *
     * @param      int $nbDays Maximum age of in days
     *
     * @return     ConsistencyNoteQuery The current query, for fluid interface
     */
    public function recentlyCreated($nbDays = 7)
    {
        return $this->addUsingAlias(ConsistencyNotePeer::DATE_CREATED, time() - $nbDays * 24 * 60 * 60, Criteria::GREATER_EQUAL);
    }

    /**
     * Order by create date desc
     *
     * @return     ConsistencyNoteQuery The current query, for fluid interface
     */
    public function lastCreatedFirst()
    {
        return $this->addDescendingOrderByColumn(ConsistencyNotePeer::DATE_CREATED);
    }

    /**
     * Order by create date asc
     *
     * @return     ConsistencyNoteQuery The current query, for fluid interface
     */
    public function firstCreatedFirst()
    {
        return $this->addAscendingOrderByColumn(ConsistencyNotePeer::DATE_CREATED);
    }
}
