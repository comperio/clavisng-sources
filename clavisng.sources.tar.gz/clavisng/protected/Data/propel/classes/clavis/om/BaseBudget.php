<?php


/**
 * Base class that represents a row from the 'budget' table.
 *
 *
 *
 * @package    propel.generator.clavis.om
 */
abstract class BaseBudget extends BaseObject implements Persistent
{
    /**
     * Peer class name
     */
    const PEER = 'BudgetPeer';

    /**
     * The Peer class.
     * Instance provides a convenient way of calling static methods on a class
     * that calling code may not be able to identify.
     * @var        BudgetPeer
     */
    protected static $peer;

    /**
     * The flag var to prevent infinite loop in deep copy
     * @var       boolean
     */
    protected $startCopy = false;

    /**
     * The value for the budget_id field.
     * @var        int
     */
    protected $budget_id;

    /**
     * The value for the library_id field.
     * @var        int
     */
    protected $library_id;

    /**
     * The value for the budget_title field.
     * @var        string
     */
    protected $budget_title;

    /**
     * The value for the budget_year field.
     * @var        int
     */
    protected $budget_year;

    /**
     * The value for the start_validity field.
     * @var        string
     */
    protected $start_validity;

    /**
     * The value for the end_validity field.
     * @var        string
     */
    protected $end_validity;

    /**
     * The value for the total_amount field.
     * @var        string
     */
    protected $total_amount;

    /**
     * The value for the tolerance field.
     * @var        string
     */
    protected $tolerance;

    /**
     * The value for the budget_notes field.
     * @var        string
     */
    protected $budget_notes;

    /**
     * The value for the date_created field.
     * @var        string
     */
    protected $date_created;

    /**
     * The value for the date_updated field.
     * @var        string
     */
    protected $date_updated;

    /**
     * The value for the created_by field.
     * @var        int
     */
    protected $created_by;

    /**
     * The value for the modified_by field.
     * @var        int
     */
    protected $modified_by;

    /**
     * @var        Librarian
     */
    protected $aLibrarianRelatedByCreatedBy;

    /**
     * @var        Librarian
     */
    protected $aLibrarianRelatedByModifiedBy;

    /**
     * @var        Library
     */
    protected $aLibrary;

    /**
     * @var        BudgetOperation one-to-one related BudgetOperation object
     */
    protected $singleBudgetOperation;

    /**
     * @var        PropelObjectCollection|Invoice[] Collection to store aggregation of Invoice objects.
     */
    protected $collInvoices;
    protected $collInvoicesPartial;

    /**
     * @var        PropelObjectCollection|Item[] Collection to store aggregation of Item objects.
     */
    protected $collItems;
    protected $collItemsPartial;

    /**
     * @var        PropelObjectCollection|Subscription[] Collection to store aggregation of Subscription objects.
     */
    protected $collSubscriptions;
    protected $collSubscriptionsPartial;

    /**
     * Flag to prevent endless save loop, if this object is referenced
     * by another object which falls in this transaction.
     * @var        boolean
     */
    protected $alreadyInSave = false;

    /**
     * Flag to prevent endless validation loop, if this object is referenced
     * by another object which falls in this transaction.
     * @var        boolean
     */
    protected $alreadyInValidation = false;

    /**
     * Flag to prevent endless clearAllReferences($deep=true) loop, if this object is referenced
     * @var        boolean
     */
    protected $alreadyInClearAllReferencesDeep = false;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $invoicesScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $itemsScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $subscriptionsScheduledForDeletion = null;

    /**
     * Get the [budget_id] column value.
     *
     * @return int
     */
    public function getBudgetId()
    {

        return $this->budget_id;
    }

    /**
     * Get the [library_id] column value.
     *
     * @return int
     */
    public function getLibraryId()
    {

        return $this->library_id;
    }

    /**
     * Get the [budget_title] column value.
     *
     * @return string
     */
    public function getBudgetTitle()
    {

        return $this->budget_title;
    }

    /**
     * Get the [budget_year] column value.
     *
     * @return int
     */
    public function getBudgetYear()
    {

        return $this->budget_year;
    }

    /**
     * Get the [optionally formatted] temporal [start_validity] column value.
     *
     *
     * @param string $format The date/time format string (either date()-style or strftime()-style).
     *				 If format is null, then the raw DateTime object will be returned.
     * @return mixed Formatted date/time value as string or DateTime object (if format is null), null if column is null, and 0 if column value is 0000-00-00
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getStartValidity($format = '%F %T')
    {
        if ($this->start_validity === null) {
            return null;
        }

        if ($this->start_validity === '0000-00-00') {
            // while technically this is not a default value of null,
            // this seems to be closest in meaning.
            return null;
        }

        try {
            $dt = new DateTime($this->start_validity);
        } catch (Exception $x) {
            throw new PropelException("Internally stored date/time/timestamp value could not be converted to DateTime: " . var_export($this->start_validity, true), $x);
        }

        if ($format === null) {
            // Because propel.useDateTimeClass is true, we return a DateTime object.
            return $dt;
        }

        if (strpos($format, '%') !== false) {
            return strftime($format, $dt->format('U'));
        }

        return $dt->format($format);

    }

    /**
     * Get the [optionally formatted] temporal [end_validity] column value.
     *
     *
     * @param string $format The date/time format string (either date()-style or strftime()-style).
     *				 If format is null, then the raw DateTime object will be returned.
     * @return mixed Formatted date/time value as string or DateTime object (if format is null), null if column is null, and 0 if column value is 0000-00-00
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getEndValidity($format = '%F %T')
    {
        if ($this->end_validity === null) {
            return null;
        }

        if ($this->end_validity === '0000-00-00') {
            // while technically this is not a default value of null,
            // this seems to be closest in meaning.
            return null;
        }

        try {
            $dt = new DateTime($this->end_validity);
        } catch (Exception $x) {
            throw new PropelException("Internally stored date/time/timestamp value could not be converted to DateTime: " . var_export($this->end_validity, true), $x);
        }

        if ($format === null) {
            // Because propel.useDateTimeClass is true, we return a DateTime object.
            return $dt;
        }

        if (strpos($format, '%') !== false) {
            return strftime($format, $dt->format('U'));
        }

        return $dt->format($format);

    }

    /**
     * Get the [total_amount] column value.
     *
     * @return string
     */
    public function getTotalAmount()
    {

        return $this->total_amount;
    }

    /**
     * Get the [tolerance] column value.
     *
     * @return string
     */
    public function getTolerance()
    {

        return $this->tolerance;
    }

    /**
     * Get the [budget_notes] column value.
     *
     * @return string
     */
    public function getBudgetNotes()
    {

        return $this->budget_notes;
    }

    /**
     * Get the [optionally formatted] temporal [date_created] column value.
     *
     *
     * @param string $format The date/time format string (either date()-style or strftime()-style).
     *				 If format is null, then the raw DateTime object will be returned.
     * @return mixed Formatted date/time value as string or DateTime object (if format is null), null if column is null, and 0 if column value is 0000-00-00 00:00:00
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getDateCreated($format = 'Y-m-d H:i:s')
    {
        if ($this->date_created === null) {
            return null;
        }

        if ($this->date_created === '0000-00-00 00:00:00') {
            // while technically this is not a default value of null,
            // this seems to be closest in meaning.
            return null;
        }

        try {
            $dt = new DateTime($this->date_created);
        } catch (Exception $x) {
            throw new PropelException("Internally stored date/time/timestamp value could not be converted to DateTime: " . var_export($this->date_created, true), $x);
        }

        if ($format === null) {
            // Because propel.useDateTimeClass is true, we return a DateTime object.
            return $dt;
        }

        if (strpos($format, '%') !== false) {
            return strftime($format, $dt->format('U'));
        }

        return $dt->format($format);

    }

    /**
     * Get the [optionally formatted] temporal [date_updated] column value.
     *
     *
     * @param string $format The date/time format string (either date()-style or strftime()-style).
     *				 If format is null, then the raw DateTime object will be returned.
     * @return mixed Formatted date/time value as string or DateTime object (if format is null), null if column is null, and 0 if column value is 0000-00-00 00:00:00
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getDateUpdated($format = 'Y-m-d H:i:s')
    {
        if ($this->date_updated === null) {
            return null;
        }

        if ($this->date_updated === '0000-00-00 00:00:00') {
            // while technically this is not a default value of null,
            // this seems to be closest in meaning.
            return null;
        }

        try {
            $dt = new DateTime($this->date_updated);
        } catch (Exception $x) {
            throw new PropelException("Internally stored date/time/timestamp value could not be converted to DateTime: " . var_export($this->date_updated, true), $x);
        }

        if ($format === null) {
            // Because propel.useDateTimeClass is true, we return a DateTime object.
            return $dt;
        }

        if (strpos($format, '%') !== false) {
            return strftime($format, $dt->format('U'));
        }

        return $dt->format($format);

    }

    /**
     * Get the [created_by] column value.
     *
     * @return int
     */
    public function getCreatedBy()
    {

        return $this->created_by;
    }

    /**
     * Get the [modified_by] column value.
     *
     * @return int
     */
    public function getModifiedBy()
    {

        return $this->modified_by;
    }

    /**
     * Set the value of [budget_id] column.
     *
     * @param  int $v new value
     * @return Budget The current object (for fluent API support)
     */
    public function setBudgetId($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->budget_id !== $v) {
            $this->budget_id = $v;
            $this->modifiedColumns[] = BudgetPeer::BUDGET_ID;
        }


        return $this;
    } // setBudgetId()

    /**
     * Set the value of [library_id] column.
     *
     * @param  int $v new value
     * @return Budget The current object (for fluent API support)
     */
    public function setLibraryId($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->library_id !== $v) {
            $this->library_id = $v;
            $this->modifiedColumns[] = BudgetPeer::LIBRARY_ID;
        }

        if ($this->aLibrary !== null && $this->aLibrary->getLibraryId() !== $v) {
            $this->aLibrary = null;
        }


        return $this;
    } // setLibraryId()

    /**
     * Set the value of [budget_title] column.
     *
     * @param  string $v new value
     * @return Budget The current object (for fluent API support)
     */
    public function setBudgetTitle($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->budget_title !== $v) {
            $this->budget_title = $v;
            $this->modifiedColumns[] = BudgetPeer::BUDGET_TITLE;
        }


        return $this;
    } // setBudgetTitle()

    /**
     * Set the value of [budget_year] column.
     *
     * @param  int $v new value
     * @return Budget The current object (for fluent API support)
     */
    public function setBudgetYear($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->budget_year !== $v) {
            $this->budget_year = $v;
            $this->modifiedColumns[] = BudgetPeer::BUDGET_YEAR;
        }


        return $this;
    } // setBudgetYear()

    /**
     * Sets the value of [start_validity] column to a normalized version of the date/time value specified.
     *
     * @param mixed $v string, integer (timestamp), or DateTime value.
     *               Empty strings are treated as null.
     * @return Budget The current object (for fluent API support)
     */
    public function setStartValidity($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->start_validity !== null || $dt !== null) {
            $currentDateAsString = ($this->start_validity !== null && $tmpDt = new DateTime($this->start_validity)) ? $tmpDt->format('Y-m-d') : null;
            $newDateAsString = $dt ? $dt->format('Y-m-d') : null;
            if ($currentDateAsString !== $newDateAsString) {
                $this->start_validity = $newDateAsString;
                $this->modifiedColumns[] = BudgetPeer::START_VALIDITY;
            }
        } // if either are not null


        return $this;
    } // setStartValidity()

    /**
     * Sets the value of [end_validity] column to a normalized version of the date/time value specified.
     *
     * @param mixed $v string, integer (timestamp), or DateTime value.
     *               Empty strings are treated as null.
     * @return Budget The current object (for fluent API support)
     */
    public function setEndValidity($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->end_validity !== null || $dt !== null) {
            $currentDateAsString = ($this->end_validity !== null && $tmpDt = new DateTime($this->end_validity)) ? $tmpDt->format('Y-m-d') : null;
            $newDateAsString = $dt ? $dt->format('Y-m-d') : null;
            if ($currentDateAsString !== $newDateAsString) {
                $this->end_validity = $newDateAsString;
                $this->modifiedColumns[] = BudgetPeer::END_VALIDITY;
            }
        } // if either are not null


        return $this;
    } // setEndValidity()

    /**
     * Set the value of [total_amount] column.
     *
     * @param  string $v new value
     * @return Budget The current object (for fluent API support)
     */
    public function setTotalAmount($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->total_amount !== $v) {
            $this->total_amount = $v;
            $this->modifiedColumns[] = BudgetPeer::TOTAL_AMOUNT;
        }


        return $this;
    } // setTotalAmount()

    /**
     * Set the value of [tolerance] column.
     *
     * @param  string $v new value
     * @return Budget The current object (for fluent API support)
     */
    public function setTolerance($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->tolerance !== $v) {
            $this->tolerance = $v;
            $this->modifiedColumns[] = BudgetPeer::TOLERANCE;
        }


        return $this;
    } // setTolerance()

    /**
     * Set the value of [budget_notes] column.
     *
     * @param  string $v new value
     * @return Budget The current object (for fluent API support)
     */
    public function setBudgetNotes($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->budget_notes !== $v) {
            $this->budget_notes = $v;
            $this->modifiedColumns[] = BudgetPeer::BUDGET_NOTES;
        }


        return $this;
    } // setBudgetNotes()

    /**
     * Sets the value of [date_created] column to a normalized version of the date/time value specified.
     *
     * @param mixed $v string, integer (timestamp), or DateTime value.
     *               Empty strings are treated as null.
     * @return Budget The current object (for fluent API support)
     */
    public function setDateCreated($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->date_created !== null || $dt !== null) {
            $currentDateAsString = ($this->date_created !== null && $tmpDt = new DateTime($this->date_created)) ? $tmpDt->format('Y-m-d H:i:s') : null;
            $newDateAsString = $dt ? $dt->format('Y-m-d H:i:s') : null;
            if ($currentDateAsString !== $newDateAsString) {
                $this->date_created = $newDateAsString;
                $this->modifiedColumns[] = BudgetPeer::DATE_CREATED;
            }
        } // if either are not null


        return $this;
    } // setDateCreated()

    /**
     * Sets the value of [date_updated] column to a normalized version of the date/time value specified.
     *
     * @param mixed $v string, integer (timestamp), or DateTime value.
     *               Empty strings are treated as null.
     * @return Budget The current object (for fluent API support)
     */
    public function setDateUpdated($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->date_updated !== null || $dt !== null) {
            $currentDateAsString = ($this->date_updated !== null && $tmpDt = new DateTime($this->date_updated)) ? $tmpDt->format('Y-m-d H:i:s') : null;
            $newDateAsString = $dt ? $dt->format('Y-m-d H:i:s') : null;
            if ($currentDateAsString !== $newDateAsString) {
                $this->date_updated = $newDateAsString;
                $this->modifiedColumns[] = BudgetPeer::DATE_UPDATED;
            }
        } // if either are not null


        return $this;
    } // setDateUpdated()

    /**
     * Set the value of [created_by] column.
     *
     * @param  int $v new value
     * @return Budget The current object (for fluent API support)
     */
    public function setCreatedBy($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->created_by !== $v) {
            $this->created_by = $v;
            $this->modifiedColumns[] = BudgetPeer::CREATED_BY;
        }

        if ($this->aLibrarianRelatedByCreatedBy !== null && $this->aLibrarianRelatedByCreatedBy->getLibrarianId() !== $v) {
            $this->aLibrarianRelatedByCreatedBy = null;
        }


        return $this;
    } // setCreatedBy()

    /**
     * Set the value of [modified_by] column.
     *
     * @param  int $v new value
     * @return Budget The current object (for fluent API support)
     */
    public function setModifiedBy($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->modified_by !== $v) {
            $this->modified_by = $v;
            $this->modifiedColumns[] = BudgetPeer::MODIFIED_BY;
        }

        if ($this->aLibrarianRelatedByModifiedBy !== null && $this->aLibrarianRelatedByModifiedBy->getLibrarianId() !== $v) {
            $this->aLibrarianRelatedByModifiedBy = null;
        }


        return $this;
    } // setModifiedBy()

    /**
     * Indicates whether the columns in this object are only set to default values.
     *
     * This method can be used in conjunction with isModified() to indicate whether an object is both
     * modified _and_ has some values set which are non-default.
     *
     * @return boolean Whether the columns in this object are only been set with default values.
     */
    public function hasOnlyDefaultValues()
    {
        // otherwise, everything was equal, so return true
        return true;
    } // hasOnlyDefaultValues()

    /**
     * Hydrates (populates) the object variables with values from the database resultset.
     *
     * An offset (0-based "start column") is specified so that objects can be hydrated
     * with a subset of the columns in the resultset rows.  This is needed, for example,
     * for results of JOIN queries where the resultset row includes columns from two or
     * more tables.
     *
     * @param array $row The row returned by PDOStatement->fetch(PDO::FETCH_NUM)
     * @param int $startcol 0-based offset column which indicates which resultset column to start with.
     * @param boolean $rehydrate Whether this object is being re-hydrated from the database.
     * @return int             next starting column
     * @throws PropelException - Any caught Exception will be rewrapped as a PropelException.
     */
    public function hydrate($row, $startcol = 0, $rehydrate = false)
    {
        try {

            $this->budget_id = ($row[$startcol + 0] !== null) ? (int) $row[$startcol + 0] : null;
            $this->library_id = ($row[$startcol + 1] !== null) ? (int) $row[$startcol + 1] : null;
            $this->budget_title = ($row[$startcol + 2] !== null) ? (string) $row[$startcol + 2] : null;
            $this->budget_year = ($row[$startcol + 3] !== null) ? (int) $row[$startcol + 3] : null;
            $this->start_validity = ($row[$startcol + 4] !== null) ? (string) $row[$startcol + 4] : null;
            $this->end_validity = ($row[$startcol + 5] !== null) ? (string) $row[$startcol + 5] : null;
            $this->total_amount = ($row[$startcol + 6] !== null) ? (string) $row[$startcol + 6] : null;
            $this->tolerance = ($row[$startcol + 7] !== null) ? (string) $row[$startcol + 7] : null;
            $this->budget_notes = ($row[$startcol + 8] !== null) ? (string) $row[$startcol + 8] : null;
            $this->date_created = ($row[$startcol + 9] !== null) ? (string) $row[$startcol + 9] : null;
            $this->date_updated = ($row[$startcol + 10] !== null) ? (string) $row[$startcol + 10] : null;
            $this->created_by = ($row[$startcol + 11] !== null) ? (int) $row[$startcol + 11] : null;
            $this->modified_by = ($row[$startcol + 12] !== null) ? (int) $row[$startcol + 12] : null;
            $this->resetModified();

            $this->setNew(false);

            if ($rehydrate) {
                $this->ensureConsistency();
            }
            $this->postHydrate($row, $startcol, $rehydrate);

            return $startcol + 13; // 13 = BudgetPeer::NUM_HYDRATE_COLUMNS.

        } catch (Exception $e) {
            throw new PropelException("Error populating Budget object", $e);
        }
    }

    /**
     * Checks and repairs the internal consistency of the object.
     *
     * This method is executed after an already-instantiated object is re-hydrated
     * from the database.  It exists to check any foreign keys to make sure that
     * the objects related to the current object are correct based on foreign key.
     *
     * You can override this method in the stub class, but you should always invoke
     * the base method from the overridden method (i.e. parent::ensureConsistency()),
     * in case your model changes.
     *
     * @throws PropelException
     */
    public function ensureConsistency()
    {

        if ($this->aLibrary !== null && $this->library_id !== $this->aLibrary->getLibraryId()) {
            $this->aLibrary = null;
        }
        if ($this->aLibrarianRelatedByCreatedBy !== null && $this->created_by !== $this->aLibrarianRelatedByCreatedBy->getLibrarianId()) {
            $this->aLibrarianRelatedByCreatedBy = null;
        }
        if ($this->aLibrarianRelatedByModifiedBy !== null && $this->modified_by !== $this->aLibrarianRelatedByModifiedBy->getLibrarianId()) {
            $this->aLibrarianRelatedByModifiedBy = null;
        }
    } // ensureConsistency

    /**
     * Reloads this object from datastore based on primary key and (optionally) resets all associated objects.
     *
     * This will only work if the object has been saved and has a valid primary key set.
     *
     * @param boolean $deep (optional) Whether to also de-associated any related objects.
     * @param PropelPDO $con (optional) The PropelPDO connection to use.
     * @return void
     * @throws PropelException - if this object is deleted, unsaved or doesn't have pk match in db
     */
    public function reload($deep = false, PropelPDO $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("Cannot reload a deleted object.");
        }

        if ($this->isNew()) {
            throw new PropelException("Cannot reload an unsaved object.");
        }

        if ($con === null) {
            $con = Propel::getConnection(BudgetPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        // We don't need to alter the object instance pool; we're just modifying this instance
        // already in the pool.

        $stmt = BudgetPeer::doSelectStmt($this->buildPkeyCriteria(), $con);
        $row = $stmt->fetch(PDO::FETCH_NUM);
        $stmt->closeCursor();
        if (!$row) {
            throw new PropelException('Cannot find matching row in the database to reload object values.');
        }
        $this->hydrate($row, 0, true); // rehydrate

        if ($deep) {  // also de-associate any related objects?

            $this->aLibrarianRelatedByCreatedBy = null;
            $this->aLibrarianRelatedByModifiedBy = null;
            $this->aLibrary = null;
            $this->singleBudgetOperation = null;

            $this->collInvoices = null;

            $this->collItems = null;

            $this->collSubscriptions = null;

        } // if (deep)
    }

    /**
     * Removes this object from datastore and sets delete attribute.
     *
     * @param PropelPDO $con
     * @return void
     * @throws PropelException
     * @throws Exception
     * @see        BaseObject::setDeleted()
     * @see        BaseObject::isDeleted()
     */
    public function delete(PropelPDO $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("This object has already been deleted.");
        }

        if ($con === null) {
            $con = Propel::getConnection(BudgetPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        $con->beginTransaction();
        try {
            $deleteQuery = BudgetQuery::create()
                ->filterByPrimaryKey($this->getPrimaryKey());
            $ret = $this->preDelete($con);
            if ($ret) {
                $deleteQuery->delete($con);
                $this->postDelete($con);
                $con->commit();
                $this->setDeleted(true);
            } else {
                $con->commit();
            }
        } catch (Exception $e) {
            $con->rollBack();
            throw $e;
        }
    }

    /**
     * Persists this object to the database.
     *
     * If the object is new, it inserts it; otherwise an update is performed.
     * All modified related objects will also be persisted in the doSave()
     * method.  This method wraps all precipitate database operations in a
     * single transaction.
     *
     * @param PropelPDO $con
     * @return int             The number of rows affected by this insert/update and any referring fk objects' save() operations.
     * @throws PropelException
     * @throws Exception
     * @see        doSave()
     */
    public function save(PropelPDO $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("You cannot save an object that has been deleted.");
        }

        if ($con === null) {
            $con = Propel::getConnection(BudgetPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        $con->beginTransaction();
        $isInsert = $this->isNew();
        try {
            $ret = $this->preSave($con);
            if ($isInsert) {
                $ret = $ret && $this->preInsert($con);
                // timestampable behavior
                if (!$this->isColumnModified(BudgetPeer::DATE_CREATED)) {
                    $this->setDateCreated(time());
                }
                if (!$this->isColumnModified(BudgetPeer::DATE_UPDATED)) {
                    $this->setDateUpdated(time());
                }
                // librariantrace behavior
                $librarianId = (class_exists('Prado') && (Prado::getApplication() instanceof TApplication) && ($u = Prado::getApplication()->getUser()) instanceof ClavisLibrarian && $u->getId() > 0) ? $u->getId() : 1 ;
                if (!$this->isColumnModified(BudgetPeer::CREATED_BY)) {
                    $this->setCreatedBy($librarianId);
                }
                if (!$this->isColumnModified(BudgetPeer::MODIFIED_BY)) {
                    $this->setModifiedBy($librarianId);
                }
            } else {
                $ret = $ret && $this->preUpdate($con);
                // timestampable behavior
                if ($this->isModified() && !$this->isColumnModified(BudgetPeer::DATE_UPDATED)) {
                    $this->setDateUpdated(time());
                }
                // librariantrace behavior
                if ($this->isModified() && !$this->isColumnModified(BudgetPeer::MODIFIED_BY)) {
                    $this->setModifiedBy((class_exists('Prado') && (Prado::getApplication() instanceof TApplication) && ($u = Prado::getApplication()->getUser()) instanceof ClavisLibrarian && $u->getId() > 0) ? $u->getId() : 1 );
                }
            }
            if ($ret) {
                $affectedRows = $this->doSave($con);
                if ($isInsert) {
                    $this->postInsert($con);
                } else {
                    $this->postUpdate($con);
                }
                $this->postSave($con);
                BudgetPeer::addInstanceToPool($this);
            } else {
                $affectedRows = 0;
            }
            $con->commit();

            return $affectedRows;
        } catch (Exception $e) {
            $con->rollBack();
            throw $e;
        }
    }

    /**
     * Performs the work of inserting or updating the row in the database.
     *
     * If the object is new, it inserts it; otherwise an update is performed.
     * All related objects are also updated in this method.
     *
     * @param PropelPDO $con
     * @return int             The number of rows affected by this insert/update and any referring fk objects' save() operations.
     * @throws PropelException
     * @see        save()
     */
    protected function doSave(PropelPDO $con)
    {
        $affectedRows = 0; // initialize var to track total num of affected rows
        if (!$this->alreadyInSave) {
            $this->alreadyInSave = true;

            // We call the save method on the following object(s) if they
            // were passed to this object by their corresponding set
            // method.  This object relates to these object(s) by a
            // foreign key reference.

            if ($this->aLibrarianRelatedByCreatedBy !== null) {
                if ($this->aLibrarianRelatedByCreatedBy->isModified() || $this->aLibrarianRelatedByCreatedBy->isNew()) {
                    $affectedRows += $this->aLibrarianRelatedByCreatedBy->save($con);
                }
                $this->setLibrarianRelatedByCreatedBy($this->aLibrarianRelatedByCreatedBy);
            }

            if ($this->aLibrarianRelatedByModifiedBy !== null) {
                if ($this->aLibrarianRelatedByModifiedBy->isModified() || $this->aLibrarianRelatedByModifiedBy->isNew()) {
                    $affectedRows += $this->aLibrarianRelatedByModifiedBy->save($con);
                }
                $this->setLibrarianRelatedByModifiedBy($this->aLibrarianRelatedByModifiedBy);
            }

            if ($this->aLibrary !== null) {
                if ($this->aLibrary->isModified() || $this->aLibrary->isNew()) {
                    $affectedRows += $this->aLibrary->save($con);
                }
                $this->setLibrary($this->aLibrary);
            }

            if ($this->isNew() || $this->isModified()) {
                // persist changes
                if ($this->isNew()) {
                    $this->doInsert($con);
                } else {
                    $this->doUpdate($con);
                }
                $affectedRows += 1;
                $this->resetModified();
            }

            if ($this->singleBudgetOperation !== null) {
                if (!$this->singleBudgetOperation->isDeleted() && ($this->singleBudgetOperation->isNew() || $this->singleBudgetOperation->isModified())) {
                        $affectedRows += $this->singleBudgetOperation->save($con);
                }
            }

            if ($this->invoicesScheduledForDeletion !== null) {
                if (!$this->invoicesScheduledForDeletion->isEmpty()) {
                    InvoiceQuery::create()
                        ->filterByPrimaryKeys($this->invoicesScheduledForDeletion->getPrimaryKeys(false))
                        ->delete($con);
                    $this->invoicesScheduledForDeletion = null;
                }
            }

            if ($this->collInvoices !== null) {
                foreach ($this->collInvoices as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->itemsScheduledForDeletion !== null) {
                if (!$this->itemsScheduledForDeletion->isEmpty()) {
                    foreach ($this->itemsScheduledForDeletion as $item) {
                        // need to save related object because we set the relation to null
                        $item->save($con);
                    }
                    $this->itemsScheduledForDeletion = null;
                }
            }

            if ($this->collItems !== null) {
                foreach ($this->collItems as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->subscriptionsScheduledForDeletion !== null) {
                if (!$this->subscriptionsScheduledForDeletion->isEmpty()) {
                    foreach ($this->subscriptionsScheduledForDeletion as $subscription) {
                        // need to save related object because we set the relation to null
                        $subscription->save($con);
                    }
                    $this->subscriptionsScheduledForDeletion = null;
                }
            }

            if ($this->collSubscriptions !== null) {
                foreach ($this->collSubscriptions as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            $this->alreadyInSave = false;

        }

        return $affectedRows;
    } // doSave()

    /**
     * Insert the row in the database.
     *
     * @param PropelPDO $con
     *
     * @throws PropelException
     * @see        doSave()
     */
    protected function doInsert(PropelPDO $con)
    {
        $modifiedColumns = array();
        $index = 0;

        $this->modifiedColumns[] = BudgetPeer::BUDGET_ID;
        if (null !== $this->budget_id) {
            throw new PropelException('Cannot insert a value for auto-increment primary key (' . BudgetPeer::BUDGET_ID . ')');
        }

         // check the columns in natural order for more readable SQL queries
        if ($this->isColumnModified(BudgetPeer::BUDGET_ID)) {
            $modifiedColumns[':p' . $index++]  = '`budget_id`';
        }
        if ($this->isColumnModified(BudgetPeer::LIBRARY_ID)) {
            $modifiedColumns[':p' . $index++]  = '`library_id`';
        }
        if ($this->isColumnModified(BudgetPeer::BUDGET_TITLE)) {
            $modifiedColumns[':p' . $index++]  = '`budget_title`';
        }
        if ($this->isColumnModified(BudgetPeer::BUDGET_YEAR)) {
            $modifiedColumns[':p' . $index++]  = '`budget_year`';
        }
        if ($this->isColumnModified(BudgetPeer::START_VALIDITY)) {
            $modifiedColumns[':p' . $index++]  = '`start_validity`';
        }
        if ($this->isColumnModified(BudgetPeer::END_VALIDITY)) {
            $modifiedColumns[':p' . $index++]  = '`end_validity`';
        }
        if ($this->isColumnModified(BudgetPeer::TOTAL_AMOUNT)) {
            $modifiedColumns[':p' . $index++]  = '`total_amount`';
        }
        if ($this->isColumnModified(BudgetPeer::TOLERANCE)) {
            $modifiedColumns[':p' . $index++]  = '`tolerance`';
        }
        if ($this->isColumnModified(BudgetPeer::BUDGET_NOTES)) {
            $modifiedColumns[':p' . $index++]  = '`budget_notes`';
        }
        if ($this->isColumnModified(BudgetPeer::DATE_CREATED)) {
            $modifiedColumns[':p' . $index++]  = '`date_created`';
        }
        if ($this->isColumnModified(BudgetPeer::DATE_UPDATED)) {
            $modifiedColumns[':p' . $index++]  = '`date_updated`';
        }
        if ($this->isColumnModified(BudgetPeer::CREATED_BY)) {
            $modifiedColumns[':p' . $index++]  = '`created_by`';
        }
        if ($this->isColumnModified(BudgetPeer::MODIFIED_BY)) {
            $modifiedColumns[':p' . $index++]  = '`modified_by`';
        }

        $sql = sprintf(
            'INSERT INTO `budget` (%s) VALUES (%s)',
            implode(', ', $modifiedColumns),
            implode(', ', array_keys($modifiedColumns))
        );

        try {
            $stmt = $con->prepare($sql);
            foreach ($modifiedColumns as $identifier => $columnName) {
                switch ($columnName) {
                    case '`budget_id`':
                        $stmt->bindValue($identifier, $this->budget_id, PDO::PARAM_INT);
                        break;
                    case '`library_id`':
                        $stmt->bindValue($identifier, $this->library_id, PDO::PARAM_INT);
                        break;
                    case '`budget_title`':
                        $stmt->bindValue($identifier, $this->budget_title, PDO::PARAM_STR);
                        break;
                    case '`budget_year`':
                        $stmt->bindValue($identifier, $this->budget_year, PDO::PARAM_INT);
                        break;
                    case '`start_validity`':
                        $stmt->bindValue($identifier, $this->start_validity, PDO::PARAM_STR);
                        break;
                    case '`end_validity`':
                        $stmt->bindValue($identifier, $this->end_validity, PDO::PARAM_STR);
                        break;
                    case '`total_amount`':
                        $stmt->bindValue($identifier, $this->total_amount, PDO::PARAM_STR);
                        break;
                    case '`tolerance`':
                        $stmt->bindValue($identifier, $this->tolerance, PDO::PARAM_STR);
                        break;
                    case '`budget_notes`':
                        $stmt->bindValue($identifier, $this->budget_notes, PDO::PARAM_STR);
                        break;
                    case '`date_created`':
                        $stmt->bindValue($identifier, $this->date_created, PDO::PARAM_STR);
                        break;
                    case '`date_updated`':
                        $stmt->bindValue($identifier, $this->date_updated, PDO::PARAM_STR);
                        break;
                    case '`created_by`':
                        $stmt->bindValue($identifier, $this->created_by, PDO::PARAM_INT);
                        break;
                    case '`modified_by`':
                        $stmt->bindValue($identifier, $this->modified_by, PDO::PARAM_INT);
                        break;
                }
            }
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute INSERT statement [%s]', $sql), $e);
        }

        try {
            $pk = $con->lastInsertId();
        } catch (Exception $e) {
            throw new PropelException('Unable to get autoincrement id.', $e);
        }
        $this->setBudgetId($pk);

        $this->setNew(false);
    }

    /**
     * Update the row in the database.
     *
     * @param PropelPDO $con
     *
     * @see        doSave()
     */
    protected function doUpdate(PropelPDO $con)
    {
        $selectCriteria = $this->buildPkeyCriteria();
        $valuesCriteria = $this->buildCriteria();
        BasePeer::doUpdate($selectCriteria, $valuesCriteria, $con);
    }

    /**
     * Array of ValidationFailed objects.
     * @var        array ValidationFailed[]
     */
    protected $validationFailures = array();

    /**
     * Gets any ValidationFailed objects that resulted from last call to validate().
     *
     *
     * @return array ValidationFailed[]
     * @see        validate()
     */
    public function getValidationFailures()
    {
        return $this->validationFailures;
    }

    /**
     * Validates the objects modified field values and all objects related to this table.
     *
     * If $columns is either a column name or an array of column names
     * only those columns are validated.
     *
     * @param mixed $columns Column name or an array of column names.
     * @return boolean Whether all columns pass validation.
     * @see        doValidate()
     * @see        getValidationFailures()
     */
    public function validate($columns = null)
    {
        $res = $this->doValidate($columns);
        if ($res === true) {
            $this->validationFailures = array();

            return true;
        }

        $this->validationFailures = $res;

        return false;
    }

    /**
     * This function performs the validation work for complex object models.
     *
     * In addition to checking the current object, all related objects will
     * also be validated.  If all pass then <code>true</code> is returned; otherwise
     * an aggregated array of ValidationFailed objects will be returned.
     *
     * @param array $columns Array of column names to validate.
     * @return mixed <code>true</code> if all validations pass; array of <code>ValidationFailed</code> objects otherwise.
     */
    protected function doValidate($columns = null)
    {
        if (!$this->alreadyInValidation) {
            $this->alreadyInValidation = true;
            $retval = null;

            $failureMap = array();


            // We call the validate method on the following object(s) if they
            // were passed to this object by their corresponding set
            // method.  This object relates to these object(s) by a
            // foreign key reference.

            if ($this->aLibrarianRelatedByCreatedBy !== null) {
                if (!$this->aLibrarianRelatedByCreatedBy->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aLibrarianRelatedByCreatedBy->getValidationFailures());
                }
            }

            if ($this->aLibrarianRelatedByModifiedBy !== null) {
                if (!$this->aLibrarianRelatedByModifiedBy->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aLibrarianRelatedByModifiedBy->getValidationFailures());
                }
            }

            if ($this->aLibrary !== null) {
                if (!$this->aLibrary->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aLibrary->getValidationFailures());
                }
            }


            if (($retval = BudgetPeer::doValidate($this, $columns)) !== true) {
                $failureMap = array_merge($failureMap, $retval);
            }


                if ($this->singleBudgetOperation !== null) {
                    if (!$this->singleBudgetOperation->validate($columns)) {
                        $failureMap = array_merge($failureMap, $this->singleBudgetOperation->getValidationFailures());
                    }
                }

                if ($this->collInvoices !== null) {
                    foreach ($this->collInvoices as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collItems !== null) {
                    foreach ($this->collItems as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collSubscriptions !== null) {
                    foreach ($this->collSubscriptions as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }


            $this->alreadyInValidation = false;
        }

        return (!empty($failureMap) ? $failureMap : true);
    }

    /**
     * Retrieves a field from the object by name passed in as a string.
     *
     * @param string $name name
     * @param string $type The type of fieldname the $name is of:
     *               one of the class type constants BasePeer::TYPE_PHPNAME, BasePeer::TYPE_STUDLYPHPNAME
     *               BasePeer::TYPE_COLNAME, BasePeer::TYPE_FIELDNAME, BasePeer::TYPE_NUM.
     *               Defaults to BasePeer::TYPE_PHPNAME
     * @return mixed Value of field.
     */
    public function getByName($name, $type = BasePeer::TYPE_PHPNAME)
    {
        $pos = BudgetPeer::translateFieldName($name, $type, BasePeer::TYPE_NUM);
        $field = $this->getByPosition($pos);

        return $field;
    }

    /**
     * Retrieves a field from the object by Position as specified in the xml schema.
     * Zero-based.
     *
     * @param int $pos position in xml schema
     * @return mixed Value of field at $pos
     */
    public function getByPosition($pos)
    {
        switch ($pos) {
            case 0:
                return $this->getBudgetId();
                break;
            case 1:
                return $this->getLibraryId();
                break;
            case 2:
                return $this->getBudgetTitle();
                break;
            case 3:
                return $this->getBudgetYear();
                break;
            case 4:
                return $this->getStartValidity();
                break;
            case 5:
                return $this->getEndValidity();
                break;
            case 6:
                return $this->getTotalAmount();
                break;
            case 7:
                return $this->getTolerance();
                break;
            case 8:
                return $this->getBudgetNotes();
                break;
            case 9:
                return $this->getDateCreated();
                break;
            case 10:
                return $this->getDateUpdated();
                break;
            case 11:
                return $this->getCreatedBy();
                break;
            case 12:
                return $this->getModifiedBy();
                break;
            default:
                return null;
                break;
        } // switch()
    }

    /**
     * Exports the object as an array.
     *
     * You can specify the key type of the array by passing one of the class
     * type constants.
     *
     * @param     string  $keyType (optional) One of the class type constants BasePeer::TYPE_PHPNAME, BasePeer::TYPE_STUDLYPHPNAME,
     *                    BasePeer::TYPE_COLNAME, BasePeer::TYPE_FIELDNAME, BasePeer::TYPE_NUM.
     *                    Defaults to BasePeer::TYPE_PHPNAME.
     * @param     boolean $includeLazyLoadColumns (optional) Whether to include lazy loaded columns. Defaults to true.
     * @param     array $alreadyDumpedObjects List of objects to skip to avoid recursion
     * @param     boolean $includeForeignObjects (optional) Whether to include hydrated related objects. Default to FALSE.
     *
     * @return array an associative array containing the field names (as keys) and field values
     */
    public function toArray($keyType = BasePeer::TYPE_PHPNAME, $includeLazyLoadColumns = true, $alreadyDumpedObjects = array(), $includeForeignObjects = false)
    {
        if (isset($alreadyDumpedObjects['Budget'][$this->getPrimaryKey()])) {
            return '*RECURSION*';
        }
        $alreadyDumpedObjects['Budget'][$this->getPrimaryKey()] = true;
        $keys = BudgetPeer::getFieldNames($keyType);
        $result = array(
            $keys[0] => $this->getBudgetId(),
            $keys[1] => $this->getLibraryId(),
            $keys[2] => $this->getBudgetTitle(),
            $keys[3] => $this->getBudgetYear(),
            $keys[4] => $this->getStartValidity(),
            $keys[5] => $this->getEndValidity(),
            $keys[6] => $this->getTotalAmount(),
            $keys[7] => $this->getTolerance(),
            $keys[8] => $this->getBudgetNotes(),
            $keys[9] => $this->getDateCreated(),
            $keys[10] => $this->getDateUpdated(),
            $keys[11] => $this->getCreatedBy(),
            $keys[12] => $this->getModifiedBy(),
        );
        $virtualColumns = $this->virtualColumns;
        foreach ($virtualColumns as $key => $virtualColumn) {
            $result[$key] = $virtualColumn;
        }

        if ($includeForeignObjects) {
            if (null !== $this->aLibrarianRelatedByCreatedBy) {
                $result['LibrarianRelatedByCreatedBy'] = $this->aLibrarianRelatedByCreatedBy->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->aLibrarianRelatedByModifiedBy) {
                $result['LibrarianRelatedByModifiedBy'] = $this->aLibrarianRelatedByModifiedBy->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->aLibrary) {
                $result['Library'] = $this->aLibrary->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->singleBudgetOperation) {
                $result['BudgetOperation'] = $this->singleBudgetOperation->toArray($keyType, $includeLazyLoadColumns, $alreadyDumpedObjects, true);
            }
            if (null !== $this->collInvoices) {
                $result['Invoices'] = $this->collInvoices->toArray(null, true, $keyType, $includeLazyLoadColumns, $alreadyDumpedObjects);
            }
            if (null !== $this->collItems) {
                $result['Items'] = $this->collItems->toArray(null, true, $keyType, $includeLazyLoadColumns, $alreadyDumpedObjects);
            }
            if (null !== $this->collSubscriptions) {
                $result['Subscriptions'] = $this->collSubscriptions->toArray(null, true, $keyType, $includeLazyLoadColumns, $alreadyDumpedObjects);
            }
        }

        return $result;
    }

    /**
     * Sets a field from the object by name passed in as a string.
     *
     * @param string $name peer name
     * @param mixed $value field value
     * @param string $type The type of fieldname the $name is of:
     *                     one of the class type constants BasePeer::TYPE_PHPNAME, BasePeer::TYPE_STUDLYPHPNAME
     *                     BasePeer::TYPE_COLNAME, BasePeer::TYPE_FIELDNAME, BasePeer::TYPE_NUM.
     *                     Defaults to BasePeer::TYPE_PHPNAME
     * @return void
     */
    public function setByName($name, $value, $type = BasePeer::TYPE_PHPNAME)
    {
        $pos = BudgetPeer::translateFieldName($name, $type, BasePeer::TYPE_NUM);

        $this->setByPosition($pos, $value);
    }

    /**
     * Sets a field from the object by Position as specified in the xml schema.
     * Zero-based.
     *
     * @param int $pos position in xml schema
     * @param mixed $value field value
     * @return void
     */
    public function setByPosition($pos, $value)
    {
        switch ($pos) {
            case 0:
                $this->setBudgetId($value);
                break;
            case 1:
                $this->setLibraryId($value);
                break;
            case 2:
                $this->setBudgetTitle($value);
                break;
            case 3:
                $this->setBudgetYear($value);
                break;
            case 4:
                $this->setStartValidity($value);
                break;
            case 5:
                $this->setEndValidity($value);
                break;
            case 6:
                $this->setTotalAmount($value);
                break;
            case 7:
                $this->setTolerance($value);
                break;
            case 8:
                $this->setBudgetNotes($value);
                break;
            case 9:
                $this->setDateCreated($value);
                break;
            case 10:
                $this->setDateUpdated($value);
                break;
            case 11:
                $this->setCreatedBy($value);
                break;
            case 12:
                $this->setModifiedBy($value);
                break;
        } // switch()
    }

    /**
     * Populates the object using an array.
     *
     * This is particularly useful when populating an object from one of the
     * request arrays (e.g. $_POST).  This method goes through the column
     * names, checking to see whether a matching key exists in populated
     * array. If so the setByName() method is called for that column.
     *
     * You can specify the key type of the array by additionally passing one
     * of the class type constants BasePeer::TYPE_PHPNAME, BasePeer::TYPE_STUDLYPHPNAME,
     * BasePeer::TYPE_COLNAME, BasePeer::TYPE_FIELDNAME, BasePeer::TYPE_NUM.
     * The default key type is the column's BasePeer::TYPE_PHPNAME
     *
     * @param array  $arr     An array to populate the object from.
     * @param string $keyType The type of keys the array uses.
     * @return void
     */
    public function fromArray($arr, $keyType = BasePeer::TYPE_PHPNAME)
    {
        $keys = BudgetPeer::getFieldNames($keyType);

        if (array_key_exists($keys[0], $arr)) $this->setBudgetId($arr[$keys[0]]);
        if (array_key_exists($keys[1], $arr)) $this->setLibraryId($arr[$keys[1]]);
        if (array_key_exists($keys[2], $arr)) $this->setBudgetTitle($arr[$keys[2]]);
        if (array_key_exists($keys[3], $arr)) $this->setBudgetYear($arr[$keys[3]]);
        if (array_key_exists($keys[4], $arr)) $this->setStartValidity($arr[$keys[4]]);
        if (array_key_exists($keys[5], $arr)) $this->setEndValidity($arr[$keys[5]]);
        if (array_key_exists($keys[6], $arr)) $this->setTotalAmount($arr[$keys[6]]);
        if (array_key_exists($keys[7], $arr)) $this->setTolerance($arr[$keys[7]]);
        if (array_key_exists($keys[8], $arr)) $this->setBudgetNotes($arr[$keys[8]]);
        if (array_key_exists($keys[9], $arr)) $this->setDateCreated($arr[$keys[9]]);
        if (array_key_exists($keys[10], $arr)) $this->setDateUpdated($arr[$keys[10]]);
        if (array_key_exists($keys[11], $arr)) $this->setCreatedBy($arr[$keys[11]]);
        if (array_key_exists($keys[12], $arr)) $this->setModifiedBy($arr[$keys[12]]);
    }

    /**
     * Build a Criteria object containing the values of all modified columns in this object.
     *
     * @return Criteria The Criteria object containing all modified values.
     */
    public function buildCriteria()
    {
        $criteria = new Criteria(BudgetPeer::DATABASE_NAME);

        if ($this->isColumnModified(BudgetPeer::BUDGET_ID)) $criteria->add(BudgetPeer::BUDGET_ID, $this->budget_id);
        if ($this->isColumnModified(BudgetPeer::LIBRARY_ID)) $criteria->add(BudgetPeer::LIBRARY_ID, $this->library_id);
        if ($this->isColumnModified(BudgetPeer::BUDGET_TITLE)) $criteria->add(BudgetPeer::BUDGET_TITLE, $this->budget_title);
        if ($this->isColumnModified(BudgetPeer::BUDGET_YEAR)) $criteria->add(BudgetPeer::BUDGET_YEAR, $this->budget_year);
        if ($this->isColumnModified(BudgetPeer::START_VALIDITY)) $criteria->add(BudgetPeer::START_VALIDITY, $this->start_validity);
        if ($this->isColumnModified(BudgetPeer::END_VALIDITY)) $criteria->add(BudgetPeer::END_VALIDITY, $this->end_validity);
        if ($this->isColumnModified(BudgetPeer::TOTAL_AMOUNT)) $criteria->add(BudgetPeer::TOTAL_AMOUNT, $this->total_amount);
        if ($this->isColumnModified(BudgetPeer::TOLERANCE)) $criteria->add(BudgetPeer::TOLERANCE, $this->tolerance);
        if ($this->isColumnModified(BudgetPeer::BUDGET_NOTES)) $criteria->add(BudgetPeer::BUDGET_NOTES, $this->budget_notes);
        if ($this->isColumnModified(BudgetPeer::DATE_CREATED)) $criteria->add(BudgetPeer::DATE_CREATED, $this->date_created);
        if ($this->isColumnModified(BudgetPeer::DATE_UPDATED)) $criteria->add(BudgetPeer::DATE_UPDATED, $this->date_updated);
        if ($this->isColumnModified(BudgetPeer::CREATED_BY)) $criteria->add(BudgetPeer::CREATED_BY, $this->created_by);
        if ($this->isColumnModified(BudgetPeer::MODIFIED_BY)) $criteria->add(BudgetPeer::MODIFIED_BY, $this->modified_by);

        return $criteria;
    }

    /**
     * Builds a Criteria object containing the primary key for this object.
     *
     * Unlike buildCriteria() this method includes the primary key values regardless
     * of whether or not they have been modified.
     *
     * @return Criteria The Criteria object containing value(s) for primary key(s).
     */
    public function buildPkeyCriteria()
    {
        $criteria = new Criteria(BudgetPeer::DATABASE_NAME);
        $criteria->add(BudgetPeer::BUDGET_ID, $this->budget_id);

        return $criteria;
    }

    /**
     * Returns the primary key for this object (row).
     * @return int
     */
    public function getPrimaryKey()
    {
        return $this->getBudgetId();
    }

    /**
     * Generic method to set the primary key (budget_id column).
     *
     * @param  int $key Primary key.
     * @return void
     */
    public function setPrimaryKey($key)
    {
        $this->setBudgetId($key);
    }

    /**
     * Returns true if the primary key for this object is null.
     * @return boolean
     */
    public function isPrimaryKeyNull()
    {

        return null === $this->getBudgetId();
    }

    /**
     * Sets contents of passed object to values from current object.
     *
     * If desired, this method can also make copies of all associated (fkey referrers)
     * objects.
     *
     * @param object $copyObj An object of Budget (or compatible) type.
     * @param boolean $deepCopy Whether to also copy all rows that refer (by fkey) to the current row.
     * @param boolean $makeNew Whether to reset autoincrement PKs and make the object new.
     * @throws PropelException
     */
    public function copyInto($copyObj, $deepCopy = false, $makeNew = true)
    {
        $copyObj->setLibraryId($this->getLibraryId());
        $copyObj->setBudgetTitle($this->getBudgetTitle());
        $copyObj->setBudgetYear($this->getBudgetYear());
        $copyObj->setStartValidity($this->getStartValidity());
        $copyObj->setEndValidity($this->getEndValidity());
        $copyObj->setTotalAmount($this->getTotalAmount());
        $copyObj->setTolerance($this->getTolerance());
        $copyObj->setBudgetNotes($this->getBudgetNotes());
        $copyObj->setDateCreated($this->getDateCreated());
        $copyObj->setDateUpdated($this->getDateUpdated());
        $copyObj->setCreatedBy($this->getCreatedBy());
        $copyObj->setModifiedBy($this->getModifiedBy());

        if ($deepCopy && !$this->startCopy) {
            // important: temporarily setNew(false) because this affects the behavior of
            // the getter/setter methods for fkey referrer objects.
            $copyObj->setNew(false);
            // store object hash to prevent cycle
            $this->startCopy = true;

            $relObj = $this->getBudgetOperation();
            if ($relObj) {
                $copyObj->setBudgetOperation($relObj->copy($deepCopy));
            }

            foreach ($this->getInvoices() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addInvoice($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getItems() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addItem($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getSubscriptions() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addSubscription($relObj->copy($deepCopy));
                }
            }

            //unflag object copy
            $this->startCopy = false;
        } // if ($deepCopy)

        if ($makeNew) {
            $copyObj->setNew(true);
            $copyObj->setBudgetId(NULL); // this is a auto-increment column, so set to default value
        }
    }

    /**
     * Makes a copy of this object that will be inserted as a new row in table when saved.
     * It creates a new object filling in the simple attributes, but skipping any primary
     * keys that are defined for the table.
     *
     * If desired, this method can also make copies of all associated (fkey referrers)
     * objects.
     *
     * @param boolean $deepCopy Whether to also copy all rows that refer (by fkey) to the current row.
     * @return Budget Clone of current object.
     * @throws PropelException
     */
    public function copy($deepCopy = false)
    {
        // we use get_class(), because this might be a subclass
        $clazz = get_class($this);
        $copyObj = new $clazz();
        $this->copyInto($copyObj, $deepCopy);

        return $copyObj;
    }

    /**
     * Returns a peer instance associated with this om.
     *
     * Since Peer classes are not to have any instance attributes, this method returns the
     * same instance for all member of this class. The method could therefore
     * be static, but this would prevent one from overriding the behavior.
     *
     * @return BudgetPeer
     */
    public function getPeer()
    {
        if (self::$peer === null) {
            self::$peer = new BudgetPeer();
        }

        return self::$peer;
    }

    /**
     * Declares an association between this object and a Librarian object.
     *
     * @param                  Librarian $v
     * @return Budget The current object (for fluent API support)
     * @throws PropelException
     */
    public function setLibrarianRelatedByCreatedBy(Librarian $v = null)
    {
        if ($v === null) {
            $this->setCreatedBy(NULL);
        } else {
            $this->setCreatedBy($v->getLibrarianId());
        }

        $this->aLibrarianRelatedByCreatedBy = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the Librarian object, it will not be re-added.
        if ($v !== null) {
            $v->addBudgetRelatedByCreatedBy($this);
        }


        return $this;
    }


    /**
     * Get the associated Librarian object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return Librarian The associated Librarian object.
     * @throws PropelException
     */
    public function getLibrarianRelatedByCreatedBy(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aLibrarianRelatedByCreatedBy === null && ($this->created_by !== null) && $doQuery) {
            $this->aLibrarianRelatedByCreatedBy = LibrarianQuery::create()->findPk($this->created_by, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aLibrarianRelatedByCreatedBy->addBudgetsRelatedByCreatedBy($this);
             */
        }

        return $this->aLibrarianRelatedByCreatedBy;
    }

    /**
     * Declares an association between this object and a Librarian object.
     *
     * @param                  Librarian $v
     * @return Budget The current object (for fluent API support)
     * @throws PropelException
     */
    public function setLibrarianRelatedByModifiedBy(Librarian $v = null)
    {
        if ($v === null) {
            $this->setModifiedBy(NULL);
        } else {
            $this->setModifiedBy($v->getLibrarianId());
        }

        $this->aLibrarianRelatedByModifiedBy = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the Librarian object, it will not be re-added.
        if ($v !== null) {
            $v->addBudgetRelatedByModifiedBy($this);
        }


        return $this;
    }


    /**
     * Get the associated Librarian object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return Librarian The associated Librarian object.
     * @throws PropelException
     */
    public function getLibrarianRelatedByModifiedBy(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aLibrarianRelatedByModifiedBy === null && ($this->modified_by !== null) && $doQuery) {
            $this->aLibrarianRelatedByModifiedBy = LibrarianQuery::create()->findPk($this->modified_by, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aLibrarianRelatedByModifiedBy->addBudgetsRelatedByModifiedBy($this);
             */
        }

        return $this->aLibrarianRelatedByModifiedBy;
    }

    /**
     * Declares an association between this object and a Library object.
     *
     * @param                  Library $v
     * @return Budget The current object (for fluent API support)
     * @throws PropelException
     */
    public function setLibrary(Library $v = null)
    {
        if ($v === null) {
            $this->setLibraryId(NULL);
        } else {
            $this->setLibraryId($v->getLibraryId());
        }

        $this->aLibrary = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the Library object, it will not be re-added.
        if ($v !== null) {
            $v->addBudget($this);
        }


        return $this;
    }


    /**
     * Get the associated Library object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return Library The associated Library object.
     * @throws PropelException
     */
    public function getLibrary(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aLibrary === null && ($this->library_id !== null) && $doQuery) {
            $this->aLibrary = LibraryQuery::create()->findPk($this->library_id, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aLibrary->addBudgets($this);
             */
        }

        return $this->aLibrary;
    }


    /**
     * Initializes a collection based on the name of a relation.
     * Avoids crafting an 'init[$relationName]s' method name
     * that wouldn't work when StandardEnglishPluralizer is used.
     *
     * @param string $relationName The name of the relation to initialize
     * @return void
     */
    public function initRelation($relationName)
    {
        if ('Invoice' == $relationName) {
            $this->initInvoices();
        }
        if ('Item' == $relationName) {
            $this->initItems();
        }
        if ('Subscription' == $relationName) {
            $this->initSubscriptions();
        }
    }

    /**
     * Gets a single BudgetOperation object, which is related to this object by a one-to-one relationship.
     *
     * @param PropelPDO $con optional connection object
     * @return BudgetOperation
     * @throws PropelException
     */
    public function getBudgetOperation(PropelPDO $con = null)
    {

        if ($this->singleBudgetOperation === null && !$this->isNew()) {
            $this->singleBudgetOperation = BudgetOperationQuery::create()->findPk($this->getPrimaryKey(), $con);
        }

        return $this->singleBudgetOperation;
    }

    /**
     * Sets a single BudgetOperation object as related to this object by a one-to-one relationship.
     *
     * @param                  BudgetOperation $v BudgetOperation
     * @return Budget The current object (for fluent API support)
     * @throws PropelException
     */
    public function setBudgetOperation(BudgetOperation $v = null)
    {
        $this->singleBudgetOperation = $v;

        // Make sure that that the passed-in BudgetOperation isn't already associated with this object
        if ($v !== null && $v->getBudget(null, false) === null) {
            $v->setBudget($this);
        }

        return $this;
    }

    /**
     * Clears out the collInvoices collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return Budget The current object (for fluent API support)
     * @see        addInvoices()
     */
    public function clearInvoices()
    {
        $this->collInvoices = null; // important to set this to null since that means it is uninitialized
        $this->collInvoicesPartial = null;

        return $this;
    }

    /**
     * reset is the collInvoices collection loaded partially
     *
     * @return void
     */
    public function resetPartialInvoices($v = true)
    {
        $this->collInvoicesPartial = $v;
    }

    /**
     * Initializes the collInvoices collection.
     *
     * By default this just sets the collInvoices collection to an empty array (like clearcollInvoices());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initInvoices($overrideExisting = true)
    {
        if (null !== $this->collInvoices && !$overrideExisting) {
            return;
        }
        $this->collInvoices = new PropelObjectCollection();
        $this->collInvoices->setModel('Invoice');
    }

    /**
     * Gets an array of Invoice objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this Budget is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|Invoice[] List of Invoice objects
     * @throws PropelException
     */
    public function getInvoices($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collInvoicesPartial && !$this->isNew();
        if (null === $this->collInvoices || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collInvoices) {
                // return empty collection
                $this->initInvoices();
            } else {
                $collInvoices = InvoiceQuery::create(null, $criteria)
                    ->filterByBudget($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collInvoicesPartial && count($collInvoices)) {
                      $this->initInvoices(false);

                      foreach ($collInvoices as $obj) {
                        if (false == $this->collInvoices->contains($obj)) {
                          $this->collInvoices->append($obj);
                        }
                      }

                      $this->collInvoicesPartial = true;
                    }

                    $collInvoices->getInternalIterator()->rewind();

                    return $collInvoices;
                }

                if ($partial && $this->collInvoices) {
                    foreach ($this->collInvoices as $obj) {
                        if ($obj->isNew()) {
                            $collInvoices[] = $obj;
                        }
                    }
                }

                $this->collInvoices = $collInvoices;
                $this->collInvoicesPartial = false;
            }
        }

        return $this->collInvoices;
    }

    /**
     * Sets a collection of Invoice objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $invoices A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return Budget The current object (for fluent API support)
     */
    public function setInvoices(PropelCollection $invoices, PropelPDO $con = null)
    {
        $invoicesToDelete = $this->getInvoices(new Criteria(), $con)->diff($invoices);


        $this->invoicesScheduledForDeletion = $invoicesToDelete;

        foreach ($invoicesToDelete as $invoiceRemoved) {
            $invoiceRemoved->setBudget(null);
        }

        $this->collInvoices = null;
        foreach ($invoices as $invoice) {
            $this->addInvoice($invoice);
        }

        $this->collInvoices = $invoices;
        $this->collInvoicesPartial = false;

        return $this;
    }

    /**
     * Returns the number of related Invoice objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related Invoice objects.
     * @throws PropelException
     */
    public function countInvoices(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collInvoicesPartial && !$this->isNew();
        if (null === $this->collInvoices || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collInvoices) {
                return 0;
            }

            if ($partial && !$criteria) {
                return count($this->getInvoices());
            }
            $query = InvoiceQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByBudget($this)
                ->count($con);
        }

        return count($this->collInvoices);
    }

    /**
     * Method called to associate a Invoice object to this object
     * through the Invoice foreign key attribute.
     *
     * @param    Invoice $l Invoice
     * @return Budget The current object (for fluent API support)
     */
    public function addInvoice(Invoice $l)
    {
        if ($this->collInvoices === null) {
            $this->initInvoices();
            $this->collInvoicesPartial = true;
        }

        if (!in_array($l, $this->collInvoices->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddInvoice($l);

            if ($this->invoicesScheduledForDeletion and $this->invoicesScheduledForDeletion->contains($l)) {
                $this->invoicesScheduledForDeletion->remove($this->invoicesScheduledForDeletion->search($l));
            }
        }

        return $this;
    }

    /**
     * @param	Invoice $invoice The invoice object to add.
     */
    protected function doAddInvoice($invoice)
    {
        $this->collInvoices[]= $invoice;
        $invoice->setBudget($this);
    }

    /**
     * @param	Invoice $invoice The invoice object to remove.
     * @return Budget The current object (for fluent API support)
     */
    public function removeInvoice($invoice)
    {
        if ($this->getInvoices()->contains($invoice)) {
            $this->collInvoices->remove($this->collInvoices->search($invoice));
            if (null === $this->invoicesScheduledForDeletion) {
                $this->invoicesScheduledForDeletion = clone $this->collInvoices;
                $this->invoicesScheduledForDeletion->clear();
            }
            $this->invoicesScheduledForDeletion[]= clone $invoice;
            $invoice->setBudget(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Budget is new, it will return
     * an empty collection; or if this Budget has previously
     * been saved, it will retrieve related Invoices from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Budget.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|Invoice[] List of Invoice objects
     */
    public function getInvoicesJoinLibrarianRelatedByCreatedBy($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = InvoiceQuery::create(null, $criteria);
        $query->joinWith('LibrarianRelatedByCreatedBy', $join_behavior);

        return $this->getInvoices($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Budget is new, it will return
     * an empty collection; or if this Budget has previously
     * been saved, it will retrieve related Invoices from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Budget.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|Invoice[] List of Invoice objects
     */
    public function getInvoicesJoinLibrarianRelatedByModifiedBy($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = InvoiceQuery::create(null, $criteria);
        $query->joinWith('LibrarianRelatedByModifiedBy', $join_behavior);

        return $this->getInvoices($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Budget is new, it will return
     * an empty collection; or if this Budget has previously
     * been saved, it will retrieve related Invoices from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Budget.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|Invoice[] List of Invoice objects
     */
    public function getInvoicesJoinSupplier($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = InvoiceQuery::create(null, $criteria);
        $query->joinWith('Supplier', $join_behavior);

        return $this->getInvoices($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Budget is new, it will return
     * an empty collection; or if this Budget has previously
     * been saved, it will retrieve related Invoices from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Budget.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|Invoice[] List of Invoice objects
     */
    public function getInvoicesJoinLibrary($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = InvoiceQuery::create(null, $criteria);
        $query->joinWith('Library', $join_behavior);

        return $this->getInvoices($query, $con);
    }

    /**
     * Clears out the collItems collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return Budget The current object (for fluent API support)
     * @see        addItems()
     */
    public function clearItems()
    {
        $this->collItems = null; // important to set this to null since that means it is uninitialized
        $this->collItemsPartial = null;

        return $this;
    }

    /**
     * reset is the collItems collection loaded partially
     *
     * @return void
     */
    public function resetPartialItems($v = true)
    {
        $this->collItemsPartial = $v;
    }

    /**
     * Initializes the collItems collection.
     *
     * By default this just sets the collItems collection to an empty array (like clearcollItems());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initItems($overrideExisting = true)
    {
        if (null !== $this->collItems && !$overrideExisting) {
            return;
        }
        $this->collItems = new PropelObjectCollection();
        $this->collItems->setModel('Item');
    }

    /**
     * Gets an array of Item objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this Budget is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|Item[] List of Item objects
     * @throws PropelException
     */
    public function getItems($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collItemsPartial && !$this->isNew();
        if (null === $this->collItems || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collItems) {
                // return empty collection
                $this->initItems();
            } else {
                $collItems = ItemQuery::create(null, $criteria)
                    ->filterByBudget($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collItemsPartial && count($collItems)) {
                      $this->initItems(false);

                      foreach ($collItems as $obj) {
                        if (false == $this->collItems->contains($obj)) {
                          $this->collItems->append($obj);
                        }
                      }

                      $this->collItemsPartial = true;
                    }

                    $collItems->getInternalIterator()->rewind();

                    return $collItems;
                }

                if ($partial && $this->collItems) {
                    foreach ($this->collItems as $obj) {
                        if ($obj->isNew()) {
                            $collItems[] = $obj;
                        }
                    }
                }

                $this->collItems = $collItems;
                $this->collItemsPartial = false;
            }
        }

        return $this->collItems;
    }

    /**
     * Sets a collection of Item objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $items A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return Budget The current object (for fluent API support)
     */
    public function setItems(PropelCollection $items, PropelPDO $con = null)
    {
        $itemsToDelete = $this->getItems(new Criteria(), $con)->diff($items);


        $this->itemsScheduledForDeletion = $itemsToDelete;

        foreach ($itemsToDelete as $itemRemoved) {
            $itemRemoved->setBudget(null);
        }

        $this->collItems = null;
        foreach ($items as $item) {
            $this->addItem($item);
        }

        $this->collItems = $items;
        $this->collItemsPartial = false;

        return $this;
    }

    /**
     * Returns the number of related Item objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related Item objects.
     * @throws PropelException
     */
    public function countItems(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collItemsPartial && !$this->isNew();
        if (null === $this->collItems || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collItems) {
                return 0;
            }

            if ($partial && !$criteria) {
                return count($this->getItems());
            }
            $query = ItemQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByBudget($this)
                ->count($con);
        }

        return count($this->collItems);
    }

    /**
     * Method called to associate a Item object to this object
     * through the Item foreign key attribute.
     *
     * @param    Item $l Item
     * @return Budget The current object (for fluent API support)
     */
    public function addItem(Item $l)
    {
        if ($this->collItems === null) {
            $this->initItems();
            $this->collItemsPartial = true;
        }

        if (!in_array($l, $this->collItems->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddItem($l);

            if ($this->itemsScheduledForDeletion and $this->itemsScheduledForDeletion->contains($l)) {
                $this->itemsScheduledForDeletion->remove($this->itemsScheduledForDeletion->search($l));
            }
        }

        return $this;
    }

    /**
     * @param	Item $item The item object to add.
     */
    protected function doAddItem($item)
    {
        $this->collItems[]= $item;
        $item->setBudget($this);
    }

    /**
     * @param	Item $item The item object to remove.
     * @return Budget The current object (for fluent API support)
     */
    public function removeItem($item)
    {
        if ($this->getItems()->contains($item)) {
            $this->collItems->remove($this->collItems->search($item));
            if (null === $this->itemsScheduledForDeletion) {
                $this->itemsScheduledForDeletion = clone $this->collItems;
                $this->itemsScheduledForDeletion->clear();
            }
            $this->itemsScheduledForDeletion[]= $item;
            $item->setBudget(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Budget is new, it will return
     * an empty collection; or if this Budget has previously
     * been saved, it will retrieve related Items from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Budget.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|Item[] List of Item objects
     */
    public function getItemsJoinLibrarianRelatedByCreatedBy($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = ItemQuery::create(null, $criteria);
        $query->joinWith('LibrarianRelatedByCreatedBy', $join_behavior);

        return $this->getItems($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Budget is new, it will return
     * an empty collection; or if this Budget has previously
     * been saved, it will retrieve related Items from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Budget.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|Item[] List of Item objects
     */
    public function getItemsJoinLibrarianRelatedByModifiedBy($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = ItemQuery::create(null, $criteria);
        $query->joinWith('LibrarianRelatedByModifiedBy', $join_behavior);

        return $this->getItems($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Budget is new, it will return
     * an empty collection; or if this Budget has previously
     * been saved, it will retrieve related Items from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Budget.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|Item[] List of Item objects
     */
    public function getItemsJoinIssue($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = ItemQuery::create(null, $criteria);
        $query->joinWith('Issue', $join_behavior);

        return $this->getItems($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Budget is new, it will return
     * an empty collection; or if this Budget has previously
     * been saved, it will retrieve related Items from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Budget.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|Item[] List of Item objects
     */
    public function getItemsJoinManifestation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = ItemQuery::create(null, $criteria);
        $query->joinWith('Manifestation', $join_behavior);

        return $this->getItems($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Budget is new, it will return
     * an empty collection; or if this Budget has previously
     * been saved, it will retrieve related Items from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Budget.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|Item[] List of Item objects
     */
    public function getItemsJoinConsistencyNote($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = ItemQuery::create(null, $criteria);
        $query->joinWith('ConsistencyNote', $join_behavior);

        return $this->getItems($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Budget is new, it will return
     * an empty collection; or if this Budget has previously
     * been saved, it will retrieve related Items from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Budget.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|Item[] List of Item objects
     */
    public function getItemsJoinLibraryRelatedByOwnerLibraryId($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = ItemQuery::create(null, $criteria);
        $query->joinWith('LibraryRelatedByOwnerLibraryId', $join_behavior);

        return $this->getItems($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Budget is new, it will return
     * an empty collection; or if this Budget has previously
     * been saved, it will retrieve related Items from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Budget.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|Item[] List of Item objects
     */
    public function getItemsJoinLibraryRelatedByHomeLibraryId($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = ItemQuery::create(null, $criteria);
        $query->joinWith('LibraryRelatedByHomeLibraryId', $join_behavior);

        return $this->getItems($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Budget is new, it will return
     * an empty collection; or if this Budget has previously
     * been saved, it will retrieve related Items from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Budget.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|Item[] List of Item objects
     */
    public function getItemsJoinLibraryRelatedByDeliveryLibraryId($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = ItemQuery::create(null, $criteria);
        $query->joinWith('LibraryRelatedByDeliveryLibraryId', $join_behavior);

        return $this->getItems($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Budget is new, it will return
     * an empty collection; or if this Budget has previously
     * been saved, it will retrieve related Items from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Budget.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|Item[] List of Item objects
     */
    public function getItemsJoinLibraryRelatedByActualLibraryId($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = ItemQuery::create(null, $criteria);
        $query->joinWith('LibraryRelatedByActualLibraryId', $join_behavior);

        return $this->getItems($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Budget is new, it will return
     * an empty collection; or if this Budget has previously
     * been saved, it will retrieve related Items from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Budget.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|Item[] List of Item objects
     */
    public function getItemsJoinInventorySerie($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = ItemQuery::create(null, $criteria);
        $query->joinWith('InventorySerie', $join_behavior);

        return $this->getItems($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Budget is new, it will return
     * an empty collection; or if this Budget has previously
     * been saved, it will retrieve related Items from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Budget.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|Item[] List of Item objects
     */
    public function getItemsJoinPurchaseOrder($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = ItemQuery::create(null, $criteria);
        $query->joinWith('PurchaseOrder', $join_behavior);

        return $this->getItems($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Budget is new, it will return
     * an empty collection; or if this Budget has previously
     * been saved, it will retrieve related Items from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Budget.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|Item[] List of Item objects
     */
    public function getItemsJoinInvoice($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = ItemQuery::create(null, $criteria);
        $query->joinWith('Invoice', $join_behavior);

        return $this->getItems($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Budget is new, it will return
     * an empty collection; or if this Budget has previously
     * been saved, it will retrieve related Items from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Budget.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|Item[] List of Item objects
     */
    public function getItemsJoinSupplier($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = ItemQuery::create(null, $criteria);
        $query->joinWith('Supplier', $join_behavior);

        return $this->getItems($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Budget is new, it will return
     * an empty collection; or if this Budget has previously
     * been saved, it will retrieve related Items from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Budget.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|Item[] List of Item objects
     */
    public function getItemsJoinPatron($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = ItemQuery::create(null, $criteria);
        $query->joinWith('Patron', $join_behavior);

        return $this->getItems($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Budget is new, it will return
     * an empty collection; or if this Budget has previously
     * been saved, it will retrieve related Items from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Budget.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|Item[] List of Item objects
     */
    public function getItemsJoinLibraryRelatedByExternalLibraryId($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = ItemQuery::create(null, $criteria);
        $query->joinWith('LibraryRelatedByExternalLibraryId', $join_behavior);

        return $this->getItems($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Budget is new, it will return
     * an empty collection; or if this Budget has previously
     * been saved, it will retrieve related Items from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Budget.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|Item[] List of Item objects
     */
    public function getItemsJoinLoanRelatedByCurrentLoanId($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = ItemQuery::create(null, $criteria);
        $query->joinWith('LoanRelatedByCurrentLoanId', $join_behavior);

        return $this->getItems($query, $con);
    }

    /**
     * Clears out the collSubscriptions collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return Budget The current object (for fluent API support)
     * @see        addSubscriptions()
     */
    public function clearSubscriptions()
    {
        $this->collSubscriptions = null; // important to set this to null since that means it is uninitialized
        $this->collSubscriptionsPartial = null;

        return $this;
    }

    /**
     * reset is the collSubscriptions collection loaded partially
     *
     * @return void
     */
    public function resetPartialSubscriptions($v = true)
    {
        $this->collSubscriptionsPartial = $v;
    }

    /**
     * Initializes the collSubscriptions collection.
     *
     * By default this just sets the collSubscriptions collection to an empty array (like clearcollSubscriptions());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initSubscriptions($overrideExisting = true)
    {
        if (null !== $this->collSubscriptions && !$overrideExisting) {
            return;
        }
        $this->collSubscriptions = new PropelObjectCollection();
        $this->collSubscriptions->setModel('Subscription');
    }

    /**
     * Gets an array of Subscription objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this Budget is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|Subscription[] List of Subscription objects
     * @throws PropelException
     */
    public function getSubscriptions($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collSubscriptionsPartial && !$this->isNew();
        if (null === $this->collSubscriptions || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collSubscriptions) {
                // return empty collection
                $this->initSubscriptions();
            } else {
                $collSubscriptions = SubscriptionQuery::create(null, $criteria)
                    ->filterByBudget($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collSubscriptionsPartial && count($collSubscriptions)) {
                      $this->initSubscriptions(false);

                      foreach ($collSubscriptions as $obj) {
                        if (false == $this->collSubscriptions->contains($obj)) {
                          $this->collSubscriptions->append($obj);
                        }
                      }

                      $this->collSubscriptionsPartial = true;
                    }

                    $collSubscriptions->getInternalIterator()->rewind();

                    return $collSubscriptions;
                }

                if ($partial && $this->collSubscriptions) {
                    foreach ($this->collSubscriptions as $obj) {
                        if ($obj->isNew()) {
                            $collSubscriptions[] = $obj;
                        }
                    }
                }

                $this->collSubscriptions = $collSubscriptions;
                $this->collSubscriptionsPartial = false;
            }
        }

        return $this->collSubscriptions;
    }

    /**
     * Sets a collection of Subscription objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $subscriptions A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return Budget The current object (for fluent API support)
     */
    public function setSubscriptions(PropelCollection $subscriptions, PropelPDO $con = null)
    {
        $subscriptionsToDelete = $this->getSubscriptions(new Criteria(), $con)->diff($subscriptions);


        $this->subscriptionsScheduledForDeletion = $subscriptionsToDelete;

        foreach ($subscriptionsToDelete as $subscriptionRemoved) {
            $subscriptionRemoved->setBudget(null);
        }

        $this->collSubscriptions = null;
        foreach ($subscriptions as $subscription) {
            $this->addSubscription($subscription);
        }

        $this->collSubscriptions = $subscriptions;
        $this->collSubscriptionsPartial = false;

        return $this;
    }

    /**
     * Returns the number of related Subscription objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related Subscription objects.
     * @throws PropelException
     */
    public function countSubscriptions(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collSubscriptionsPartial && !$this->isNew();
        if (null === $this->collSubscriptions || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collSubscriptions) {
                return 0;
            }

            if ($partial && !$criteria) {
                return count($this->getSubscriptions());
            }
            $query = SubscriptionQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByBudget($this)
                ->count($con);
        }

        return count($this->collSubscriptions);
    }

    /**
     * Method called to associate a Subscription object to this object
     * through the Subscription foreign key attribute.
     *
     * @param    Subscription $l Subscription
     * @return Budget The current object (for fluent API support)
     */
    public function addSubscription(Subscription $l)
    {
        if ($this->collSubscriptions === null) {
            $this->initSubscriptions();
            $this->collSubscriptionsPartial = true;
        }

        if (!in_array($l, $this->collSubscriptions->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddSubscription($l);

            if ($this->subscriptionsScheduledForDeletion and $this->subscriptionsScheduledForDeletion->contains($l)) {
                $this->subscriptionsScheduledForDeletion->remove($this->subscriptionsScheduledForDeletion->search($l));
            }
        }

        return $this;
    }

    /**
     * @param	Subscription $subscription The subscription object to add.
     */
    protected function doAddSubscription($subscription)
    {
        $this->collSubscriptions[]= $subscription;
        $subscription->setBudget($this);
    }

    /**
     * @param	Subscription $subscription The subscription object to remove.
     * @return Budget The current object (for fluent API support)
     */
    public function removeSubscription($subscription)
    {
        if ($this->getSubscriptions()->contains($subscription)) {
            $this->collSubscriptions->remove($this->collSubscriptions->search($subscription));
            if (null === $this->subscriptionsScheduledForDeletion) {
                $this->subscriptionsScheduledForDeletion = clone $this->collSubscriptions;
                $this->subscriptionsScheduledForDeletion->clear();
            }
            $this->subscriptionsScheduledForDeletion[]= $subscription;
            $subscription->setBudget(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Budget is new, it will return
     * an empty collection; or if this Budget has previously
     * been saved, it will retrieve related Subscriptions from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Budget.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|Subscription[] List of Subscription objects
     */
    public function getSubscriptionsJoinLibrarianRelatedByCreatedBy($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = SubscriptionQuery::create(null, $criteria);
        $query->joinWith('LibrarianRelatedByCreatedBy', $join_behavior);

        return $this->getSubscriptions($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Budget is new, it will return
     * an empty collection; or if this Budget has previously
     * been saved, it will retrieve related Subscriptions from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Budget.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|Subscription[] List of Subscription objects
     */
    public function getSubscriptionsJoinLibrarianRelatedByModifiedBy($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = SubscriptionQuery::create(null, $criteria);
        $query->joinWith('LibrarianRelatedByModifiedBy', $join_behavior);

        return $this->getSubscriptions($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Budget is new, it will return
     * an empty collection; or if this Budget has previously
     * been saved, it will retrieve related Subscriptions from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Budget.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|Subscription[] List of Subscription objects
     */
    public function getSubscriptionsJoinLibrary($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = SubscriptionQuery::create(null, $criteria);
        $query->joinWith('Library', $join_behavior);

        return $this->getSubscriptions($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Budget is new, it will return
     * an empty collection; or if this Budget has previously
     * been saved, it will retrieve related Subscriptions from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Budget.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|Subscription[] List of Subscription objects
     */
    public function getSubscriptionsJoinManifestation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = SubscriptionQuery::create(null, $criteria);
        $query->joinWith('Manifestation', $join_behavior);

        return $this->getSubscriptions($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Budget is new, it will return
     * an empty collection; or if this Budget has previously
     * been saved, it will retrieve related Subscriptions from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Budget.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|Subscription[] List of Subscription objects
     */
    public function getSubscriptionsJoinSupplier($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = SubscriptionQuery::create(null, $criteria);
        $query->joinWith('Supplier', $join_behavior);

        return $this->getSubscriptions($query, $con);
    }

    /**
     * Clears the current object and sets all attributes to their default values
     */
    public function clear()
    {
        $this->budget_id = null;
        $this->library_id = null;
        $this->budget_title = null;
        $this->budget_year = null;
        $this->start_validity = null;
        $this->end_validity = null;
        $this->total_amount = null;
        $this->tolerance = null;
        $this->budget_notes = null;
        $this->date_created = null;
        $this->date_updated = null;
        $this->created_by = null;
        $this->modified_by = null;
        $this->alreadyInSave = false;
        $this->alreadyInValidation = false;
        $this->alreadyInClearAllReferencesDeep = false;
        $this->clearAllReferences();
        $this->resetModified();
        $this->setNew(true);
        $this->setDeleted(false);
    }

    /**
     * Resets all references to other model objects or collections of model objects.
     *
     * This method is a user-space workaround for PHP's inability to garbage collect
     * objects with circular references (even in PHP 5.3). This is currently necessary
     * when using Propel in certain daemon or large-volume/high-memory operations.
     *
     * @param boolean $deep Whether to also clear the references on all referrer objects.
     */
    public function clearAllReferences($deep = false)
    {
        if ($deep && !$this->alreadyInClearAllReferencesDeep) {
            $this->alreadyInClearAllReferencesDeep = true;
            if ($this->singleBudgetOperation) {
                $this->singleBudgetOperation->clearAllReferences($deep);
            }
            if ($this->collInvoices) {
                foreach ($this->collInvoices as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collItems) {
                foreach ($this->collItems as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collSubscriptions) {
                foreach ($this->collSubscriptions as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->aLibrarianRelatedByCreatedBy instanceof Persistent) {
              $this->aLibrarianRelatedByCreatedBy->clearAllReferences($deep);
            }
            if ($this->aLibrarianRelatedByModifiedBy instanceof Persistent) {
              $this->aLibrarianRelatedByModifiedBy->clearAllReferences($deep);
            }
            if ($this->aLibrary instanceof Persistent) {
              $this->aLibrary->clearAllReferences($deep);
            }

            $this->alreadyInClearAllReferencesDeep = false;
        } // if ($deep)

        if ($this->singleBudgetOperation instanceof PropelCollection) {
            $this->singleBudgetOperation->clearIterator();
        }
        $this->singleBudgetOperation = null;
        if ($this->collInvoices instanceof PropelCollection) {
            $this->collInvoices->clearIterator();
        }
        $this->collInvoices = null;
        if ($this->collItems instanceof PropelCollection) {
            $this->collItems->clearIterator();
        }
        $this->collItems = null;
        if ($this->collSubscriptions instanceof PropelCollection) {
            $this->collSubscriptions->clearIterator();
        }
        $this->collSubscriptions = null;
        $this->aLibrarianRelatedByCreatedBy = null;
        $this->aLibrarianRelatedByModifiedBy = null;
        $this->aLibrary = null;
    }

    /**
     * return the string representation of this object
     *
     * @return string
     */
    public function __toString()
    {
        return (string) $this->exportTo(BudgetPeer::DEFAULT_STRING_FORMAT);
    }

    /**
     * return true is the object is in saving state
     *
     * @return boolean
     */
    public function isAlreadyInSave()
    {
        return $this->alreadyInSave;
    }

    // timestampable behavior

    /**
     * Mark the current object so that the update date doesn't get updated during next save
     *
     * @return     Budget The current object (for fluent API support)
     */
    public function keepUpdateDateUnchanged()
    {
        $this->modifiedColumns[] = BudgetPeer::DATE_UPDATED;

        return $this;
    }

    // librariantrace behavior

    /**
     * Returns the complete name of the librarian that created this object.
     *
     * @return string
     */
    public function getCreatedByNameString()
    {
        $l = $this->getLibrarianRelatedByCreatedBy();
        return ($l instanceof Librarian) ? $l->getCompleteName() : '';
    }

    /**
     * Returns the complete name of the librarian that last updated this object.
     *
     * @return string
     */
    public function getModifiedByNameString()
    {
        $l = $this->getLibrarianRelatedByModifiedBy();
        return ($l instanceof Librarian) ? $l->getCompleteName() : '';
    }

    /**
     * Mark the current object so that the update date doesn't get updated during next save
     *
     * @return     Budget The current object (for fluent API support)
     */
    public function keepUpdateLibrarianUnchanged()
    {
        $this->modifiedColumns[] = BudgetPeer::MODIFIED_BY;
        return $this;
    }

}
