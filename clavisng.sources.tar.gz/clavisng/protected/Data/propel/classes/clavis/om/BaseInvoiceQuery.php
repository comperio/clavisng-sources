<?php


/**
 * Base class that represents a query for the 'invoice' table.
 *
 *
 *
 * @method InvoiceQuery orderByInvoiceId($order = Criteria::ASC) Order by the invoice_id column
 * @method InvoiceQuery orderByInvoiceStatus($order = Criteria::ASC) Order by the invoice_status column
 * @method InvoiceQuery orderBySupplierId($order = Criteria::ASC) Order by the supplier_id column
 * @method InvoiceQuery orderByLibraryId($order = Criteria::ASC) Order by the library_id column
 * @method InvoiceQuery orderByBudgetId($order = Criteria::ASC) Order by the budget_id column
 * @method InvoiceQuery orderByInvoiceDate($order = Criteria::ASC) Order by the invoice_date column
 * @method InvoiceQuery orderByInvoiceNumber($order = Criteria::ASC) Order by the invoice_number column
 * @method InvoiceQuery orderByCurrierPrice($order = Criteria::ASC) Order by the currier_price column
 * @method InvoiceQuery orderByAccounted($order = Criteria::ASC) Order by the accounted column
 * @method InvoiceQuery orderByDateCreated($order = Criteria::ASC) Order by the date_created column
 * @method InvoiceQuery orderByDateUpdated($order = Criteria::ASC) Order by the date_updated column
 * @method InvoiceQuery orderByCreatedBy($order = Criteria::ASC) Order by the created_by column
 * @method InvoiceQuery orderByModifiedBy($order = Criteria::ASC) Order by the modified_by column
 *
 * @method InvoiceQuery groupByInvoiceId() Group by the invoice_id column
 * @method InvoiceQuery groupByInvoiceStatus() Group by the invoice_status column
 * @method InvoiceQuery groupBySupplierId() Group by the supplier_id column
 * @method InvoiceQuery groupByLibraryId() Group by the library_id column
 * @method InvoiceQuery groupByBudgetId() Group by the budget_id column
 * @method InvoiceQuery groupByInvoiceDate() Group by the invoice_date column
 * @method InvoiceQuery groupByInvoiceNumber() Group by the invoice_number column
 * @method InvoiceQuery groupByCurrierPrice() Group by the currier_price column
 * @method InvoiceQuery groupByAccounted() Group by the accounted column
 * @method InvoiceQuery groupByDateCreated() Group by the date_created column
 * @method InvoiceQuery groupByDateUpdated() Group by the date_updated column
 * @method InvoiceQuery groupByCreatedBy() Group by the created_by column
 * @method InvoiceQuery groupByModifiedBy() Group by the modified_by column
 *
 * @method InvoiceQuery leftJoin($relation) Adds a LEFT JOIN clause to the query
 * @method InvoiceQuery rightJoin($relation) Adds a RIGHT JOIN clause to the query
 * @method InvoiceQuery innerJoin($relation) Adds a INNER JOIN clause to the query
 *
 * @method InvoiceQuery leftJoinLibrarianRelatedByCreatedBy($relationAlias = null) Adds a LEFT JOIN clause to the query using the LibrarianRelatedByCreatedBy relation
 * @method InvoiceQuery rightJoinLibrarianRelatedByCreatedBy($relationAlias = null) Adds a RIGHT JOIN clause to the query using the LibrarianRelatedByCreatedBy relation
 * @method InvoiceQuery innerJoinLibrarianRelatedByCreatedBy($relationAlias = null) Adds a INNER JOIN clause to the query using the LibrarianRelatedByCreatedBy relation
 *
 * @method InvoiceQuery leftJoinLibrarianRelatedByModifiedBy($relationAlias = null) Adds a LEFT JOIN clause to the query using the LibrarianRelatedByModifiedBy relation
 * @method InvoiceQuery rightJoinLibrarianRelatedByModifiedBy($relationAlias = null) Adds a RIGHT JOIN clause to the query using the LibrarianRelatedByModifiedBy relation
 * @method InvoiceQuery innerJoinLibrarianRelatedByModifiedBy($relationAlias = null) Adds a INNER JOIN clause to the query using the LibrarianRelatedByModifiedBy relation
 *
 * @method InvoiceQuery leftJoinSupplier($relationAlias = null) Adds a LEFT JOIN clause to the query using the Supplier relation
 * @method InvoiceQuery rightJoinSupplier($relationAlias = null) Adds a RIGHT JOIN clause to the query using the Supplier relation
 * @method InvoiceQuery innerJoinSupplier($relationAlias = null) Adds a INNER JOIN clause to the query using the Supplier relation
 *
 * @method InvoiceQuery leftJoinLibrary($relationAlias = null) Adds a LEFT JOIN clause to the query using the Library relation
 * @method InvoiceQuery rightJoinLibrary($relationAlias = null) Adds a RIGHT JOIN clause to the query using the Library relation
 * @method InvoiceQuery innerJoinLibrary($relationAlias = null) Adds a INNER JOIN clause to the query using the Library relation
 *
 * @method InvoiceQuery leftJoinBudget($relationAlias = null) Adds a LEFT JOIN clause to the query using the Budget relation
 * @method InvoiceQuery rightJoinBudget($relationAlias = null) Adds a RIGHT JOIN clause to the query using the Budget relation
 * @method InvoiceQuery innerJoinBudget($relationAlias = null) Adds a INNER JOIN clause to the query using the Budget relation
 *
 * @method InvoiceQuery leftJoinItem($relationAlias = null) Adds a LEFT JOIN clause to the query using the Item relation
 * @method InvoiceQuery rightJoinItem($relationAlias = null) Adds a RIGHT JOIN clause to the query using the Item relation
 * @method InvoiceQuery innerJoinItem($relationAlias = null) Adds a INNER JOIN clause to the query using the Item relation
 *
 * @method Invoice findOne(PropelPDO $con = null) Return the first Invoice matching the query
 * @method Invoice findOneOrCreate(PropelPDO $con = null) Return the first Invoice matching the query, or a new Invoice object populated from the query conditions when no match is found
 *
 * @method Invoice findOneByInvoiceStatus(string $invoice_status) Return the first Invoice filtered by the invoice_status column
 * @method Invoice findOneBySupplierId(int $supplier_id) Return the first Invoice filtered by the supplier_id column
 * @method Invoice findOneByLibraryId(int $library_id) Return the first Invoice filtered by the library_id column
 * @method Invoice findOneByBudgetId(int $budget_id) Return the first Invoice filtered by the budget_id column
 * @method Invoice findOneByInvoiceDate(string $invoice_date) Return the first Invoice filtered by the invoice_date column
 * @method Invoice findOneByInvoiceNumber(string $invoice_number) Return the first Invoice filtered by the invoice_number column
 * @method Invoice findOneByCurrierPrice(string $currier_price) Return the first Invoice filtered by the currier_price column
 * @method Invoice findOneByAccounted(boolean $accounted) Return the first Invoice filtered by the accounted column
 * @method Invoice findOneByDateCreated(string $date_created) Return the first Invoice filtered by the date_created column
 * @method Invoice findOneByDateUpdated(string $date_updated) Return the first Invoice filtered by the date_updated column
 * @method Invoice findOneByCreatedBy(int $created_by) Return the first Invoice filtered by the created_by column
 * @method Invoice findOneByModifiedBy(int $modified_by) Return the first Invoice filtered by the modified_by column
 *
 * @method array findByInvoiceId(int $invoice_id) Return Invoice objects filtered by the invoice_id column
 * @method array findByInvoiceStatus(string $invoice_status) Return Invoice objects filtered by the invoice_status column
 * @method array findBySupplierId(int $supplier_id) Return Invoice objects filtered by the supplier_id column
 * @method array findByLibraryId(int $library_id) Return Invoice objects filtered by the library_id column
 * @method array findByBudgetId(int $budget_id) Return Invoice objects filtered by the budget_id column
 * @method array findByInvoiceDate(string $invoice_date) Return Invoice objects filtered by the invoice_date column
 * @method array findByInvoiceNumber(string $invoice_number) Return Invoice objects filtered by the invoice_number column
 * @method array findByCurrierPrice(string $currier_price) Return Invoice objects filtered by the currier_price column
 * @method array findByAccounted(boolean $accounted) Return Invoice objects filtered by the accounted column
 * @method array findByDateCreated(string $date_created) Return Invoice objects filtered by the date_created column
 * @method array findByDateUpdated(string $date_updated) Return Invoice objects filtered by the date_updated column
 * @method array findByCreatedBy(int $created_by) Return Invoice objects filtered by the created_by column
 * @method array findByModifiedBy(int $modified_by) Return Invoice objects filtered by the modified_by column
 *
 * @package    propel.generator.clavis.om
 */
abstract class BaseInvoiceQuery extends ModelCriteria
{
    /**
     * Initializes internal state of BaseInvoiceQuery object.
     *
     * @param     string $dbName The dabase name
     * @param     string $modelName The phpName of a model, e.g. 'Book'
     * @param     string $modelAlias The alias for the model in this query, e.g. 'b'
     */
    public function __construct($dbName = null, $modelName = null, $modelAlias = null)
    {
        if (null === $dbName) {
            $dbName = 'clavis';
        }
        if (null === $modelName) {
            $modelName = 'Invoice';
        }
        parent::__construct($dbName, $modelName, $modelAlias);
    }

    /**
     * Returns a new InvoiceQuery object.
     *
     * @param     string $modelAlias The alias of a model in the query
     * @param   InvoiceQuery|Criteria $criteria Optional Criteria to build the query from
     *
     * @return InvoiceQuery
     */
    public static function create($modelAlias = null, $criteria = null)
    {
        if ($criteria instanceof InvoiceQuery) {
            return $criteria;
        }
        $query = new InvoiceQuery(null, null, $modelAlias);

        if ($criteria instanceof Criteria) {
            $query->mergeWith($criteria);
        }

        return $query;
    }

    /**
     * Find object by primary key.
     * Propel uses the instance pool to skip the database if the object exists.
     * Go fast if the query is untouched.
     *
     * <code>
     * $obj  = $c->findPk(12, $con);
     * </code>
     *
     * @param mixed $key Primary key to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return   Invoice|Invoice[]|mixed the result, formatted by the current formatter
     */
    public function findPk($key, $con = null)
    {
        if ($key === null) {
            return null;
        }
        if ((null !== ($obj = InvoicePeer::getInstanceFromPool((string) $key))) && !$this->formatter) {
            // the object is already in the instance pool
            return $obj;
        }
        if ($con === null) {
            $con = Propel::getConnection(InvoicePeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        if ($this->formatter || $this->modelAlias || $this->with || $this->select
         || $this->selectColumns || $this->asColumns || $this->selectModifiers
         || $this->map || $this->having || $this->joins) {
            return $this->findPkComplex($key, $con);
        } else {
            return $this->findPkSimple($key, $con);
        }
    }

    /**
     * Alias of findPk to use instance pooling
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 Invoice A model object, or null if the key is not found
     * @throws PropelException
     */
     public function findOneByInvoiceId($key, $con = null)
     {
        return $this->findPk($key, $con);
     }

    /**
     * Find object by primary key using raw SQL to go fast.
     * Bypass doSelect() and the object formatter by using generated code.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 Invoice A model object, or null if the key is not found
     * @throws PropelException
     */
    protected function findPkSimple($key, $con)
    {
        $sql = 'SELECT `invoice_id`, `invoice_status`, `supplier_id`, `library_id`, `budget_id`, `invoice_date`, `invoice_number`, `currier_price`, `accounted`, `date_created`, `date_updated`, `created_by`, `modified_by` FROM `invoice` WHERE `invoice_id` = :p0';
        try {
            $stmt = $con->prepare($sql);
            $stmt->bindValue(':p0', $key, PDO::PARAM_INT);
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute SELECT statement [%s]', $sql), $e);
        }
        $obj = null;
        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $obj = new Invoice();
            $obj->hydrate($row);
            InvoicePeer::addInstanceToPool($obj, (string) $key);
        }
        $stmt->closeCursor();

        return $obj;
    }

    /**
     * Find object by primary key.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return Invoice|Invoice[]|mixed the result, formatted by the current formatter
     */
    protected function findPkComplex($key, $con)
    {
        // As the query uses a PK condition, no limit(1) is necessary.
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKey($key)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->formatOne($stmt);
    }

    /**
     * Find objects by primary key
     * <code>
     * $objs = $c->findPks(array(12, 56, 832), $con);
     * </code>
     * @param     array $keys Primary keys to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return PropelObjectCollection|Invoice[]|mixed the list of results, formatted by the current formatter
     */
    public function findPks($keys, $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection($this->getDbName(), Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKeys($keys)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->format($stmt);
    }

    /**
     * Filter the query by primary key
     *
     * @param     mixed $key Primary key to use for the query
     *
     * @return InvoiceQuery The current query, for fluid interface
     */
    public function filterByPrimaryKey($key)
    {

        return $this->addUsingAlias(InvoicePeer::INVOICE_ID, $key, Criteria::EQUAL);
    }

    /**
     * Filter the query by a list of primary keys
     *
     * @param     array $keys The list of primary key to use for the query
     *
     * @return InvoiceQuery The current query, for fluid interface
     */
    public function filterByPrimaryKeys($keys)
    {

        return $this->addUsingAlias(InvoicePeer::INVOICE_ID, $keys, Criteria::IN);
    }

    /**
     * Filter the query on the invoice_id column
     *
     * Example usage:
     * <code>
     * $query->filterByInvoiceId(1234); // WHERE invoice_id = 1234
     * $query->filterByInvoiceId(array(12, 34)); // WHERE invoice_id IN (12, 34)
     * $query->filterByInvoiceId(array('min' => 12)); // WHERE invoice_id >= 12
     * $query->filterByInvoiceId(array('max' => 12)); // WHERE invoice_id <= 12
     * </code>
     *
     * @param     mixed $invoiceId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return InvoiceQuery The current query, for fluid interface
     */
    public function filterByInvoiceId($invoiceId = null, $comparison = null)
    {
        if (is_array($invoiceId)) {
            $useMinMax = false;
            if (isset($invoiceId['min'])) {
                $this->addUsingAlias(InvoicePeer::INVOICE_ID, $invoiceId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($invoiceId['max'])) {
                $this->addUsingAlias(InvoicePeer::INVOICE_ID, $invoiceId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(InvoicePeer::INVOICE_ID, $invoiceId, $comparison);
    }

    /**
     * Filter the query on the invoice_status column
     *
     * Example usage:
     * <code>
     * $query->filterByInvoiceStatus('fooValue');   // WHERE invoice_status = 'fooValue'
     * $query->filterByInvoiceStatus('%fooValue%'); // WHERE invoice_status LIKE '%fooValue%'
     * </code>
     *
     * @param     string $invoiceStatus The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return InvoiceQuery The current query, for fluid interface
     */
    public function filterByInvoiceStatus($invoiceStatus = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($invoiceStatus)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $invoiceStatus)) {
                $invoiceStatus = str_replace('*', '%', $invoiceStatus);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(InvoicePeer::INVOICE_STATUS, $invoiceStatus, $comparison);
    }

    /**
     * Filter the query on the supplier_id column
     *
     * Example usage:
     * <code>
     * $query->filterBySupplierId(1234); // WHERE supplier_id = 1234
     * $query->filterBySupplierId(array(12, 34)); // WHERE supplier_id IN (12, 34)
     * $query->filterBySupplierId(array('min' => 12)); // WHERE supplier_id >= 12
     * $query->filterBySupplierId(array('max' => 12)); // WHERE supplier_id <= 12
     * </code>
     *
     * @see       filterBySupplier()
     *
     * @param     mixed $supplierId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return InvoiceQuery The current query, for fluid interface
     */
    public function filterBySupplierId($supplierId = null, $comparison = null)
    {
        if (is_array($supplierId)) {
            $useMinMax = false;
            if (isset($supplierId['min'])) {
                $this->addUsingAlias(InvoicePeer::SUPPLIER_ID, $supplierId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($supplierId['max'])) {
                $this->addUsingAlias(InvoicePeer::SUPPLIER_ID, $supplierId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(InvoicePeer::SUPPLIER_ID, $supplierId, $comparison);
    }

    /**
     * Filter the query on the library_id column
     *
     * Example usage:
     * <code>
     * $query->filterByLibraryId(1234); // WHERE library_id = 1234
     * $query->filterByLibraryId(array(12, 34)); // WHERE library_id IN (12, 34)
     * $query->filterByLibraryId(array('min' => 12)); // WHERE library_id >= 12
     * $query->filterByLibraryId(array('max' => 12)); // WHERE library_id <= 12
     * </code>
     *
     * @see       filterByLibrary()
     *
     * @param     mixed $libraryId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return InvoiceQuery The current query, for fluid interface
     */
    public function filterByLibraryId($libraryId = null, $comparison = null)
    {
        if (is_array($libraryId)) {
            $useMinMax = false;
            if (isset($libraryId['min'])) {
                $this->addUsingAlias(InvoicePeer::LIBRARY_ID, $libraryId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($libraryId['max'])) {
                $this->addUsingAlias(InvoicePeer::LIBRARY_ID, $libraryId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(InvoicePeer::LIBRARY_ID, $libraryId, $comparison);
    }

    /**
     * Filter the query on the budget_id column
     *
     * Example usage:
     * <code>
     * $query->filterByBudgetId(1234); // WHERE budget_id = 1234
     * $query->filterByBudgetId(array(12, 34)); // WHERE budget_id IN (12, 34)
     * $query->filterByBudgetId(array('min' => 12)); // WHERE budget_id >= 12
     * $query->filterByBudgetId(array('max' => 12)); // WHERE budget_id <= 12
     * </code>
     *
     * @see       filterByBudget()
     *
     * @param     mixed $budgetId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return InvoiceQuery The current query, for fluid interface
     */
    public function filterByBudgetId($budgetId = null, $comparison = null)
    {
        if (is_array($budgetId)) {
            $useMinMax = false;
            if (isset($budgetId['min'])) {
                $this->addUsingAlias(InvoicePeer::BUDGET_ID, $budgetId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($budgetId['max'])) {
                $this->addUsingAlias(InvoicePeer::BUDGET_ID, $budgetId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(InvoicePeer::BUDGET_ID, $budgetId, $comparison);
    }

    /**
     * Filter the query on the invoice_date column
     *
     * Example usage:
     * <code>
     * $query->filterByInvoiceDate('2011-03-14'); // WHERE invoice_date = '2011-03-14'
     * $query->filterByInvoiceDate('now'); // WHERE invoice_date = '2011-03-14'
     * $query->filterByInvoiceDate(array('max' => 'yesterday')); // WHERE invoice_date < '2011-03-13'
     * </code>
     *
     * @param     mixed $invoiceDate The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return InvoiceQuery The current query, for fluid interface
     */
    public function filterByInvoiceDate($invoiceDate = null, $comparison = null)
    {
        if (is_array($invoiceDate)) {
            $useMinMax = false;
            if (isset($invoiceDate['min'])) {
                $this->addUsingAlias(InvoicePeer::INVOICE_DATE, $invoiceDate['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($invoiceDate['max'])) {
                $this->addUsingAlias(InvoicePeer::INVOICE_DATE, $invoiceDate['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(InvoicePeer::INVOICE_DATE, $invoiceDate, $comparison);
    }

    /**
     * Filter the query on the invoice_number column
     *
     * Example usage:
     * <code>
     * $query->filterByInvoiceNumber('fooValue');   // WHERE invoice_number = 'fooValue'
     * $query->filterByInvoiceNumber('%fooValue%'); // WHERE invoice_number LIKE '%fooValue%'
     * </code>
     *
     * @param     string $invoiceNumber The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return InvoiceQuery The current query, for fluid interface
     */
    public function filterByInvoiceNumber($invoiceNumber = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($invoiceNumber)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $invoiceNumber)) {
                $invoiceNumber = str_replace('*', '%', $invoiceNumber);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(InvoicePeer::INVOICE_NUMBER, $invoiceNumber, $comparison);
    }

    /**
     * Filter the query on the currier_price column
     *
     * Example usage:
     * <code>
     * $query->filterByCurrierPrice(1234); // WHERE currier_price = 1234
     * $query->filterByCurrierPrice(array(12, 34)); // WHERE currier_price IN (12, 34)
     * $query->filterByCurrierPrice(array('min' => 12)); // WHERE currier_price >= 12
     * $query->filterByCurrierPrice(array('max' => 12)); // WHERE currier_price <= 12
     * </code>
     *
     * @param     mixed $currierPrice The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return InvoiceQuery The current query, for fluid interface
     */
    public function filterByCurrierPrice($currierPrice = null, $comparison = null)
    {
        if (is_array($currierPrice)) {
            $useMinMax = false;
            if (isset($currierPrice['min'])) {
                $this->addUsingAlias(InvoicePeer::CURRIER_PRICE, $currierPrice['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($currierPrice['max'])) {
                $this->addUsingAlias(InvoicePeer::CURRIER_PRICE, $currierPrice['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(InvoicePeer::CURRIER_PRICE, $currierPrice, $comparison);
    }

    /**
     * Filter the query on the accounted column
     *
     * Example usage:
     * <code>
     * $query->filterByAccounted(true); // WHERE accounted = true
     * $query->filterByAccounted('yes'); // WHERE accounted = true
     * </code>
     *
     * @param     boolean|string $accounted The value to use as filter.
     *              Non-boolean arguments are converted using the following rules:
     *                * 1, '1', 'true',  'on',  and 'yes' are converted to boolean true
     *                * 0, '0', 'false', 'off', and 'no'  are converted to boolean false
     *              Check on string values is case insensitive (so 'FaLsE' is seen as 'false').
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return InvoiceQuery The current query, for fluid interface
     */
    public function filterByAccounted($accounted = null, $comparison = null)
    {
        if (is_string($accounted)) {
            $accounted = in_array(strtolower($accounted), array('false', 'off', '-', 'no', 'n', '0', '')) ? false : true;
        }

        return $this->addUsingAlias(InvoicePeer::ACCOUNTED, $accounted, $comparison);
    }

    /**
     * Filter the query on the date_created column
     *
     * Example usage:
     * <code>
     * $query->filterByDateCreated('2011-03-14'); // WHERE date_created = '2011-03-14'
     * $query->filterByDateCreated('now'); // WHERE date_created = '2011-03-14'
     * $query->filterByDateCreated(array('max' => 'yesterday')); // WHERE date_created < '2011-03-13'
     * </code>
     *
     * @param     mixed $dateCreated The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return InvoiceQuery The current query, for fluid interface
     */
    public function filterByDateCreated($dateCreated = null, $comparison = null)
    {
        if (is_array($dateCreated)) {
            $useMinMax = false;
            if (isset($dateCreated['min'])) {
                $this->addUsingAlias(InvoicePeer::DATE_CREATED, $dateCreated['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dateCreated['max'])) {
                $this->addUsingAlias(InvoicePeer::DATE_CREATED, $dateCreated['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(InvoicePeer::DATE_CREATED, $dateCreated, $comparison);
    }

    /**
     * Filter the query on the date_updated column
     *
     * Example usage:
     * <code>
     * $query->filterByDateUpdated('2011-03-14'); // WHERE date_updated = '2011-03-14'
     * $query->filterByDateUpdated('now'); // WHERE date_updated = '2011-03-14'
     * $query->filterByDateUpdated(array('max' => 'yesterday')); // WHERE date_updated < '2011-03-13'
     * </code>
     *
     * @param     mixed $dateUpdated The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return InvoiceQuery The current query, for fluid interface
     */
    public function filterByDateUpdated($dateUpdated = null, $comparison = null)
    {
        if (is_array($dateUpdated)) {
            $useMinMax = false;
            if (isset($dateUpdated['min'])) {
                $this->addUsingAlias(InvoicePeer::DATE_UPDATED, $dateUpdated['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dateUpdated['max'])) {
                $this->addUsingAlias(InvoicePeer::DATE_UPDATED, $dateUpdated['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(InvoicePeer::DATE_UPDATED, $dateUpdated, $comparison);
    }

    /**
     * Filter the query on the created_by column
     *
     * Example usage:
     * <code>
     * $query->filterByCreatedBy(1234); // WHERE created_by = 1234
     * $query->filterByCreatedBy(array(12, 34)); // WHERE created_by IN (12, 34)
     * $query->filterByCreatedBy(array('min' => 12)); // WHERE created_by >= 12
     * $query->filterByCreatedBy(array('max' => 12)); // WHERE created_by <= 12
     * </code>
     *
     * @see       filterByLibrarianRelatedByCreatedBy()
     *
     * @param     mixed $createdBy The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return InvoiceQuery The current query, for fluid interface
     */
    public function filterByCreatedBy($createdBy = null, $comparison = null)
    {
        if (is_array($createdBy)) {
            $useMinMax = false;
            if (isset($createdBy['min'])) {
                $this->addUsingAlias(InvoicePeer::CREATED_BY, $createdBy['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($createdBy['max'])) {
                $this->addUsingAlias(InvoicePeer::CREATED_BY, $createdBy['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(InvoicePeer::CREATED_BY, $createdBy, $comparison);
    }

    /**
     * Filter the query on the modified_by column
     *
     * Example usage:
     * <code>
     * $query->filterByModifiedBy(1234); // WHERE modified_by = 1234
     * $query->filterByModifiedBy(array(12, 34)); // WHERE modified_by IN (12, 34)
     * $query->filterByModifiedBy(array('min' => 12)); // WHERE modified_by >= 12
     * $query->filterByModifiedBy(array('max' => 12)); // WHERE modified_by <= 12
     * </code>
     *
     * @see       filterByLibrarianRelatedByModifiedBy()
     *
     * @param     mixed $modifiedBy The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return InvoiceQuery The current query, for fluid interface
     */
    public function filterByModifiedBy($modifiedBy = null, $comparison = null)
    {
        if (is_array($modifiedBy)) {
            $useMinMax = false;
            if (isset($modifiedBy['min'])) {
                $this->addUsingAlias(InvoicePeer::MODIFIED_BY, $modifiedBy['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($modifiedBy['max'])) {
                $this->addUsingAlias(InvoicePeer::MODIFIED_BY, $modifiedBy['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(InvoicePeer::MODIFIED_BY, $modifiedBy, $comparison);
    }

    /**
     * Filter the query by a related Librarian object
     *
     * @param   Librarian|PropelObjectCollection $librarian The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 InvoiceQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByLibrarianRelatedByCreatedBy($librarian, $comparison = null)
    {
        if ($librarian instanceof Librarian) {
            return $this
                ->addUsingAlias(InvoicePeer::CREATED_BY, $librarian->getLibrarianId(), $comparison);
        } elseif ($librarian instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(InvoicePeer::CREATED_BY, $librarian->toKeyValue('PrimaryKey', 'LibrarianId'), $comparison);
        } else {
            throw new PropelException('filterByLibrarianRelatedByCreatedBy() only accepts arguments of type Librarian or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the LibrarianRelatedByCreatedBy relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return InvoiceQuery The current query, for fluid interface
     */
    public function joinLibrarianRelatedByCreatedBy($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('LibrarianRelatedByCreatedBy');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'LibrarianRelatedByCreatedBy');
        }

        return $this;
    }

    /**
     * Use the LibrarianRelatedByCreatedBy relation Librarian object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   LibrarianQuery A secondary query class using the current class as primary query
     */
    public function useLibrarianRelatedByCreatedByQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinLibrarianRelatedByCreatedBy($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'LibrarianRelatedByCreatedBy', 'LibrarianQuery');
    }

    /**
     * Filter the query by a related Librarian object
     *
     * @param   Librarian|PropelObjectCollection $librarian The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 InvoiceQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByLibrarianRelatedByModifiedBy($librarian, $comparison = null)
    {
        if ($librarian instanceof Librarian) {
            return $this
                ->addUsingAlias(InvoicePeer::MODIFIED_BY, $librarian->getLibrarianId(), $comparison);
        } elseif ($librarian instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(InvoicePeer::MODIFIED_BY, $librarian->toKeyValue('PrimaryKey', 'LibrarianId'), $comparison);
        } else {
            throw new PropelException('filterByLibrarianRelatedByModifiedBy() only accepts arguments of type Librarian or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the LibrarianRelatedByModifiedBy relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return InvoiceQuery The current query, for fluid interface
     */
    public function joinLibrarianRelatedByModifiedBy($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('LibrarianRelatedByModifiedBy');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'LibrarianRelatedByModifiedBy');
        }

        return $this;
    }

    /**
     * Use the LibrarianRelatedByModifiedBy relation Librarian object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   LibrarianQuery A secondary query class using the current class as primary query
     */
    public function useLibrarianRelatedByModifiedByQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinLibrarianRelatedByModifiedBy($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'LibrarianRelatedByModifiedBy', 'LibrarianQuery');
    }

    /**
     * Filter the query by a related Supplier object
     *
     * @param   Supplier|PropelObjectCollection $supplier The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 InvoiceQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterBySupplier($supplier, $comparison = null)
    {
        if ($supplier instanceof Supplier) {
            return $this
                ->addUsingAlias(InvoicePeer::SUPPLIER_ID, $supplier->getSupplierId(), $comparison);
        } elseif ($supplier instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(InvoicePeer::SUPPLIER_ID, $supplier->toKeyValue('PrimaryKey', 'SupplierId'), $comparison);
        } else {
            throw new PropelException('filterBySupplier() only accepts arguments of type Supplier or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the Supplier relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return InvoiceQuery The current query, for fluid interface
     */
    public function joinSupplier($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('Supplier');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'Supplier');
        }

        return $this;
    }

    /**
     * Use the Supplier relation Supplier object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   SupplierQuery A secondary query class using the current class as primary query
     */
    public function useSupplierQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinSupplier($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'Supplier', 'SupplierQuery');
    }

    /**
     * Filter the query by a related Library object
     *
     * @param   Library|PropelObjectCollection $library The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 InvoiceQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByLibrary($library, $comparison = null)
    {
        if ($library instanceof Library) {
            return $this
                ->addUsingAlias(InvoicePeer::LIBRARY_ID, $library->getLibraryId(), $comparison);
        } elseif ($library instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(InvoicePeer::LIBRARY_ID, $library->toKeyValue('PrimaryKey', 'LibraryId'), $comparison);
        } else {
            throw new PropelException('filterByLibrary() only accepts arguments of type Library or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the Library relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return InvoiceQuery The current query, for fluid interface
     */
    public function joinLibrary($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('Library');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'Library');
        }

        return $this;
    }

    /**
     * Use the Library relation Library object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   LibraryQuery A secondary query class using the current class as primary query
     */
    public function useLibraryQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinLibrary($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'Library', 'LibraryQuery');
    }

    /**
     * Filter the query by a related Budget object
     *
     * @param   Budget|PropelObjectCollection $budget The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 InvoiceQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByBudget($budget, $comparison = null)
    {
        if ($budget instanceof Budget) {
            return $this
                ->addUsingAlias(InvoicePeer::BUDGET_ID, $budget->getBudgetId(), $comparison);
        } elseif ($budget instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(InvoicePeer::BUDGET_ID, $budget->toKeyValue('PrimaryKey', 'BudgetId'), $comparison);
        } else {
            throw new PropelException('filterByBudget() only accepts arguments of type Budget or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the Budget relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return InvoiceQuery The current query, for fluid interface
     */
    public function joinBudget($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('Budget');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'Budget');
        }

        return $this;
    }

    /**
     * Use the Budget relation Budget object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   BudgetQuery A secondary query class using the current class as primary query
     */
    public function useBudgetQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinBudget($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'Budget', 'BudgetQuery');
    }

    /**
     * Filter the query by a related Item object
     *
     * @param   Item|PropelObjectCollection $item  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 InvoiceQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByItem($item, $comparison = null)
    {
        if ($item instanceof Item) {
            return $this
                ->addUsingAlias(InvoicePeer::INVOICE_ID, $item->getInvoiceId(), $comparison);
        } elseif ($item instanceof PropelObjectCollection) {
            return $this
                ->useItemQuery()
                ->filterByPrimaryKeys($item->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByItem() only accepts arguments of type Item or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the Item relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return InvoiceQuery The current query, for fluid interface
     */
    public function joinItem($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('Item');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'Item');
        }

        return $this;
    }

    /**
     * Use the Item relation Item object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   ItemQuery A secondary query class using the current class as primary query
     */
    public function useItemQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinItem($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'Item', 'ItemQuery');
    }

    /**
     * Exclude object from result
     *
     * @param   Invoice $invoice Object to remove from the list of results
     *
     * @return InvoiceQuery The current query, for fluid interface
     */
    public function prune($invoice = null)
    {
        if ($invoice) {
            $this->addUsingAlias(InvoicePeer::INVOICE_ID, $invoice->getInvoiceId(), Criteria::NOT_EQUAL);
        }

        return $this;
    }

    // timestampable behavior

    /**
     * Filter by the latest updated
     *
     * @param      int $nbDays Maximum age of the latest update in days
     *
     * @return     InvoiceQuery The current query, for fluid interface
     */
    public function recentlyUpdated($nbDays = 7)
    {
        return $this->addUsingAlias(InvoicePeer::DATE_UPDATED, time() - $nbDays * 24 * 60 * 60, Criteria::GREATER_EQUAL);
    }

    /**
     * Order by update date desc
     *
     * @return     InvoiceQuery The current query, for fluid interface
     */
    public function lastUpdatedFirst()
    {
        return $this->addDescendingOrderByColumn(InvoicePeer::DATE_UPDATED);
    }

    /**
     * Order by update date asc
     *
     * @return     InvoiceQuery The current query, for fluid interface
     */
    public function firstUpdatedFirst()
    {
        return $this->addAscendingOrderByColumn(InvoicePeer::DATE_UPDATED);
    }

    /**
     * Filter by the latest created
     *
     * @param      int $nbDays Maximum age of in days
     *
     * @return     InvoiceQuery The current query, for fluid interface
     */
    public function recentlyCreated($nbDays = 7)
    {
        return $this->addUsingAlias(InvoicePeer::DATE_CREATED, time() - $nbDays * 24 * 60 * 60, Criteria::GREATER_EQUAL);
    }

    /**
     * Order by create date desc
     *
     * @return     InvoiceQuery The current query, for fluid interface
     */
    public function lastCreatedFirst()
    {
        return $this->addDescendingOrderByColumn(InvoicePeer::DATE_CREATED);
    }

    /**
     * Order by create date asc
     *
     * @return     InvoiceQuery The current query, for fluid interface
     */
    public function firstCreatedFirst()
    {
        return $this->addAscendingOrderByColumn(InvoicePeer::DATE_CREATED);
    }
}
