<?php


/**
 * Base class that represents a query for the 'budget' table.
 *
 *
 *
 * @method BudgetQuery orderByBudgetId($order = Criteria::ASC) Order by the budget_id column
 * @method BudgetQuery orderByLibraryId($order = Criteria::ASC) Order by the library_id column
 * @method BudgetQuery orderByBudgetTitle($order = Criteria::ASC) Order by the budget_title column
 * @method BudgetQuery orderByBudgetYear($order = Criteria::ASC) Order by the budget_year column
 * @method BudgetQuery orderByStartValidity($order = Criteria::ASC) Order by the start_validity column
 * @method BudgetQuery orderByEndValidity($order = Criteria::ASC) Order by the end_validity column
 * @method BudgetQuery orderByTotalAmount($order = Criteria::ASC) Order by the total_amount column
 * @method BudgetQuery orderByTolerance($order = Criteria::ASC) Order by the tolerance column
 * @method BudgetQuery orderByBudgetNotes($order = Criteria::ASC) Order by the budget_notes column
 * @method BudgetQuery orderByDateCreated($order = Criteria::ASC) Order by the date_created column
 * @method BudgetQuery orderByDateUpdated($order = Criteria::ASC) Order by the date_updated column
 * @method BudgetQuery orderByCreatedBy($order = Criteria::ASC) Order by the created_by column
 * @method BudgetQuery orderByModifiedBy($order = Criteria::ASC) Order by the modified_by column
 *
 * @method BudgetQuery groupByBudgetId() Group by the budget_id column
 * @method BudgetQuery groupByLibraryId() Group by the library_id column
 * @method BudgetQuery groupByBudgetTitle() Group by the budget_title column
 * @method BudgetQuery groupByBudgetYear() Group by the budget_year column
 * @method BudgetQuery groupByStartValidity() Group by the start_validity column
 * @method BudgetQuery groupByEndValidity() Group by the end_validity column
 * @method BudgetQuery groupByTotalAmount() Group by the total_amount column
 * @method BudgetQuery groupByTolerance() Group by the tolerance column
 * @method BudgetQuery groupByBudgetNotes() Group by the budget_notes column
 * @method BudgetQuery groupByDateCreated() Group by the date_created column
 * @method BudgetQuery groupByDateUpdated() Group by the date_updated column
 * @method BudgetQuery groupByCreatedBy() Group by the created_by column
 * @method BudgetQuery groupByModifiedBy() Group by the modified_by column
 *
 * @method BudgetQuery leftJoin($relation) Adds a LEFT JOIN clause to the query
 * @method BudgetQuery rightJoin($relation) Adds a RIGHT JOIN clause to the query
 * @method BudgetQuery innerJoin($relation) Adds a INNER JOIN clause to the query
 *
 * @method BudgetQuery leftJoinLibrarianRelatedByCreatedBy($relationAlias = null) Adds a LEFT JOIN clause to the query using the LibrarianRelatedByCreatedBy relation
 * @method BudgetQuery rightJoinLibrarianRelatedByCreatedBy($relationAlias = null) Adds a RIGHT JOIN clause to the query using the LibrarianRelatedByCreatedBy relation
 * @method BudgetQuery innerJoinLibrarianRelatedByCreatedBy($relationAlias = null) Adds a INNER JOIN clause to the query using the LibrarianRelatedByCreatedBy relation
 *
 * @method BudgetQuery leftJoinLibrarianRelatedByModifiedBy($relationAlias = null) Adds a LEFT JOIN clause to the query using the LibrarianRelatedByModifiedBy relation
 * @method BudgetQuery rightJoinLibrarianRelatedByModifiedBy($relationAlias = null) Adds a RIGHT JOIN clause to the query using the LibrarianRelatedByModifiedBy relation
 * @method BudgetQuery innerJoinLibrarianRelatedByModifiedBy($relationAlias = null) Adds a INNER JOIN clause to the query using the LibrarianRelatedByModifiedBy relation
 *
 * @method BudgetQuery leftJoinLibrary($relationAlias = null) Adds a LEFT JOIN clause to the query using the Library relation
 * @method BudgetQuery rightJoinLibrary($relationAlias = null) Adds a RIGHT JOIN clause to the query using the Library relation
 * @method BudgetQuery innerJoinLibrary($relationAlias = null) Adds a INNER JOIN clause to the query using the Library relation
 *
 * @method BudgetQuery leftJoinBudgetOperation($relationAlias = null) Adds a LEFT JOIN clause to the query using the BudgetOperation relation
 * @method BudgetQuery rightJoinBudgetOperation($relationAlias = null) Adds a RIGHT JOIN clause to the query using the BudgetOperation relation
 * @method BudgetQuery innerJoinBudgetOperation($relationAlias = null) Adds a INNER JOIN clause to the query using the BudgetOperation relation
 *
 * @method BudgetQuery leftJoinInvoice($relationAlias = null) Adds a LEFT JOIN clause to the query using the Invoice relation
 * @method BudgetQuery rightJoinInvoice($relationAlias = null) Adds a RIGHT JOIN clause to the query using the Invoice relation
 * @method BudgetQuery innerJoinInvoice($relationAlias = null) Adds a INNER JOIN clause to the query using the Invoice relation
 *
 * @method BudgetQuery leftJoinItem($relationAlias = null) Adds a LEFT JOIN clause to the query using the Item relation
 * @method BudgetQuery rightJoinItem($relationAlias = null) Adds a RIGHT JOIN clause to the query using the Item relation
 * @method BudgetQuery innerJoinItem($relationAlias = null) Adds a INNER JOIN clause to the query using the Item relation
 *
 * @method BudgetQuery leftJoinSubscription($relationAlias = null) Adds a LEFT JOIN clause to the query using the Subscription relation
 * @method BudgetQuery rightJoinSubscription($relationAlias = null) Adds a RIGHT JOIN clause to the query using the Subscription relation
 * @method BudgetQuery innerJoinSubscription($relationAlias = null) Adds a INNER JOIN clause to the query using the Subscription relation
 *
 * @method Budget findOne(PropelPDO $con = null) Return the first Budget matching the query
 * @method Budget findOneOrCreate(PropelPDO $con = null) Return the first Budget matching the query, or a new Budget object populated from the query conditions when no match is found
 *
 * @method Budget findOneByLibraryId(int $library_id) Return the first Budget filtered by the library_id column
 * @method Budget findOneByBudgetTitle(string $budget_title) Return the first Budget filtered by the budget_title column
 * @method Budget findOneByBudgetYear(int $budget_year) Return the first Budget filtered by the budget_year column
 * @method Budget findOneByStartValidity(string $start_validity) Return the first Budget filtered by the start_validity column
 * @method Budget findOneByEndValidity(string $end_validity) Return the first Budget filtered by the end_validity column
 * @method Budget findOneByTotalAmount(string $total_amount) Return the first Budget filtered by the total_amount column
 * @method Budget findOneByTolerance(string $tolerance) Return the first Budget filtered by the tolerance column
 * @method Budget findOneByBudgetNotes(string $budget_notes) Return the first Budget filtered by the budget_notes column
 * @method Budget findOneByDateCreated(string $date_created) Return the first Budget filtered by the date_created column
 * @method Budget findOneByDateUpdated(string $date_updated) Return the first Budget filtered by the date_updated column
 * @method Budget findOneByCreatedBy(int $created_by) Return the first Budget filtered by the created_by column
 * @method Budget findOneByModifiedBy(int $modified_by) Return the first Budget filtered by the modified_by column
 *
 * @method array findByBudgetId(int $budget_id) Return Budget objects filtered by the budget_id column
 * @method array findByLibraryId(int $library_id) Return Budget objects filtered by the library_id column
 * @method array findByBudgetTitle(string $budget_title) Return Budget objects filtered by the budget_title column
 * @method array findByBudgetYear(int $budget_year) Return Budget objects filtered by the budget_year column
 * @method array findByStartValidity(string $start_validity) Return Budget objects filtered by the start_validity column
 * @method array findByEndValidity(string $end_validity) Return Budget objects filtered by the end_validity column
 * @method array findByTotalAmount(string $total_amount) Return Budget objects filtered by the total_amount column
 * @method array findByTolerance(string $tolerance) Return Budget objects filtered by the tolerance column
 * @method array findByBudgetNotes(string $budget_notes) Return Budget objects filtered by the budget_notes column
 * @method array findByDateCreated(string $date_created) Return Budget objects filtered by the date_created column
 * @method array findByDateUpdated(string $date_updated) Return Budget objects filtered by the date_updated column
 * @method array findByCreatedBy(int $created_by) Return Budget objects filtered by the created_by column
 * @method array findByModifiedBy(int $modified_by) Return Budget objects filtered by the modified_by column
 *
 * @package    propel.generator.clavis.om
 */
abstract class BaseBudgetQuery extends ModelCriteria
{
    /**
     * Initializes internal state of BaseBudgetQuery object.
     *
     * @param     string $dbName The dabase name
     * @param     string $modelName The phpName of a model, e.g. 'Book'
     * @param     string $modelAlias The alias for the model in this query, e.g. 'b'
     */
    public function __construct($dbName = null, $modelName = null, $modelAlias = null)
    {
        if (null === $dbName) {
            $dbName = 'clavis';
        }
        if (null === $modelName) {
            $modelName = 'Budget';
        }
        parent::__construct($dbName, $modelName, $modelAlias);
    }

    /**
     * Returns a new BudgetQuery object.
     *
     * @param     string $modelAlias The alias of a model in the query
     * @param   BudgetQuery|Criteria $criteria Optional Criteria to build the query from
     *
     * @return BudgetQuery
     */
    public static function create($modelAlias = null, $criteria = null)
    {
        if ($criteria instanceof BudgetQuery) {
            return $criteria;
        }
        $query = new BudgetQuery(null, null, $modelAlias);

        if ($criteria instanceof Criteria) {
            $query->mergeWith($criteria);
        }

        return $query;
    }

    /**
     * Find object by primary key.
     * Propel uses the instance pool to skip the database if the object exists.
     * Go fast if the query is untouched.
     *
     * <code>
     * $obj  = $c->findPk(12, $con);
     * </code>
     *
     * @param mixed $key Primary key to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return   Budget|Budget[]|mixed the result, formatted by the current formatter
     */
    public function findPk($key, $con = null)
    {
        if ($key === null) {
            return null;
        }
        if ((null !== ($obj = BudgetPeer::getInstanceFromPool((string) $key))) && !$this->formatter) {
            // the object is already in the instance pool
            return $obj;
        }
        if ($con === null) {
            $con = Propel::getConnection(BudgetPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        if ($this->formatter || $this->modelAlias || $this->with || $this->select
         || $this->selectColumns || $this->asColumns || $this->selectModifiers
         || $this->map || $this->having || $this->joins) {
            return $this->findPkComplex($key, $con);
        } else {
            return $this->findPkSimple($key, $con);
        }
    }

    /**
     * Alias of findPk to use instance pooling
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 Budget A model object, or null if the key is not found
     * @throws PropelException
     */
     public function findOneByBudgetId($key, $con = null)
     {
        return $this->findPk($key, $con);
     }

    /**
     * Find object by primary key using raw SQL to go fast.
     * Bypass doSelect() and the object formatter by using generated code.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 Budget A model object, or null if the key is not found
     * @throws PropelException
     */
    protected function findPkSimple($key, $con)
    {
        $sql = 'SELECT `budget_id`, `library_id`, `budget_title`, `budget_year`, `start_validity`, `end_validity`, `total_amount`, `tolerance`, `budget_notes`, `date_created`, `date_updated`, `created_by`, `modified_by` FROM `budget` WHERE `budget_id` = :p0';
        try {
            $stmt = $con->prepare($sql);
            $stmt->bindValue(':p0', $key, PDO::PARAM_INT);
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute SELECT statement [%s]', $sql), $e);
        }
        $obj = null;
        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $obj = new Budget();
            $obj->hydrate($row);
            BudgetPeer::addInstanceToPool($obj, (string) $key);
        }
        $stmt->closeCursor();

        return $obj;
    }

    /**
     * Find object by primary key.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return Budget|Budget[]|mixed the result, formatted by the current formatter
     */
    protected function findPkComplex($key, $con)
    {
        // As the query uses a PK condition, no limit(1) is necessary.
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKey($key)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->formatOne($stmt);
    }

    /**
     * Find objects by primary key
     * <code>
     * $objs = $c->findPks(array(12, 56, 832), $con);
     * </code>
     * @param     array $keys Primary keys to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return PropelObjectCollection|Budget[]|mixed the list of results, formatted by the current formatter
     */
    public function findPks($keys, $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection($this->getDbName(), Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKeys($keys)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->format($stmt);
    }

    /**
     * Filter the query by primary key
     *
     * @param     mixed $key Primary key to use for the query
     *
     * @return BudgetQuery The current query, for fluid interface
     */
    public function filterByPrimaryKey($key)
    {

        return $this->addUsingAlias(BudgetPeer::BUDGET_ID, $key, Criteria::EQUAL);
    }

    /**
     * Filter the query by a list of primary keys
     *
     * @param     array $keys The list of primary key to use for the query
     *
     * @return BudgetQuery The current query, for fluid interface
     */
    public function filterByPrimaryKeys($keys)
    {

        return $this->addUsingAlias(BudgetPeer::BUDGET_ID, $keys, Criteria::IN);
    }

    /**
     * Filter the query on the budget_id column
     *
     * Example usage:
     * <code>
     * $query->filterByBudgetId(1234); // WHERE budget_id = 1234
     * $query->filterByBudgetId(array(12, 34)); // WHERE budget_id IN (12, 34)
     * $query->filterByBudgetId(array('min' => 12)); // WHERE budget_id >= 12
     * $query->filterByBudgetId(array('max' => 12)); // WHERE budget_id <= 12
     * </code>
     *
     * @param     mixed $budgetId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return BudgetQuery The current query, for fluid interface
     */
    public function filterByBudgetId($budgetId = null, $comparison = null)
    {
        if (is_array($budgetId)) {
            $useMinMax = false;
            if (isset($budgetId['min'])) {
                $this->addUsingAlias(BudgetPeer::BUDGET_ID, $budgetId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($budgetId['max'])) {
                $this->addUsingAlias(BudgetPeer::BUDGET_ID, $budgetId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(BudgetPeer::BUDGET_ID, $budgetId, $comparison);
    }

    /**
     * Filter the query on the library_id column
     *
     * Example usage:
     * <code>
     * $query->filterByLibraryId(1234); // WHERE library_id = 1234
     * $query->filterByLibraryId(array(12, 34)); // WHERE library_id IN (12, 34)
     * $query->filterByLibraryId(array('min' => 12)); // WHERE library_id >= 12
     * $query->filterByLibraryId(array('max' => 12)); // WHERE library_id <= 12
     * </code>
     *
     * @see       filterByLibrary()
     *
     * @param     mixed $libraryId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return BudgetQuery The current query, for fluid interface
     */
    public function filterByLibraryId($libraryId = null, $comparison = null)
    {
        if (is_array($libraryId)) {
            $useMinMax = false;
            if (isset($libraryId['min'])) {
                $this->addUsingAlias(BudgetPeer::LIBRARY_ID, $libraryId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($libraryId['max'])) {
                $this->addUsingAlias(BudgetPeer::LIBRARY_ID, $libraryId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(BudgetPeer::LIBRARY_ID, $libraryId, $comparison);
    }

    /**
     * Filter the query on the budget_title column
     *
     * Example usage:
     * <code>
     * $query->filterByBudgetTitle('fooValue');   // WHERE budget_title = 'fooValue'
     * $query->filterByBudgetTitle('%fooValue%'); // WHERE budget_title LIKE '%fooValue%'
     * </code>
     *
     * @param     string $budgetTitle The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return BudgetQuery The current query, for fluid interface
     */
    public function filterByBudgetTitle($budgetTitle = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($budgetTitle)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $budgetTitle)) {
                $budgetTitle = str_replace('*', '%', $budgetTitle);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(BudgetPeer::BUDGET_TITLE, $budgetTitle, $comparison);
    }

    /**
     * Filter the query on the budget_year column
     *
     * Example usage:
     * <code>
     * $query->filterByBudgetYear(1234); // WHERE budget_year = 1234
     * $query->filterByBudgetYear(array(12, 34)); // WHERE budget_year IN (12, 34)
     * $query->filterByBudgetYear(array('min' => 12)); // WHERE budget_year >= 12
     * $query->filterByBudgetYear(array('max' => 12)); // WHERE budget_year <= 12
     * </code>
     *
     * @param     mixed $budgetYear The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return BudgetQuery The current query, for fluid interface
     */
    public function filterByBudgetYear($budgetYear = null, $comparison = null)
    {
        if (is_array($budgetYear)) {
            $useMinMax = false;
            if (isset($budgetYear['min'])) {
                $this->addUsingAlias(BudgetPeer::BUDGET_YEAR, $budgetYear['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($budgetYear['max'])) {
                $this->addUsingAlias(BudgetPeer::BUDGET_YEAR, $budgetYear['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(BudgetPeer::BUDGET_YEAR, $budgetYear, $comparison);
    }

    /**
     * Filter the query on the start_validity column
     *
     * Example usage:
     * <code>
     * $query->filterByStartValidity('2011-03-14'); // WHERE start_validity = '2011-03-14'
     * $query->filterByStartValidity('now'); // WHERE start_validity = '2011-03-14'
     * $query->filterByStartValidity(array('max' => 'yesterday')); // WHERE start_validity < '2011-03-13'
     * </code>
     *
     * @param     mixed $startValidity The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return BudgetQuery The current query, for fluid interface
     */
    public function filterByStartValidity($startValidity = null, $comparison = null)
    {
        if (is_array($startValidity)) {
            $useMinMax = false;
            if (isset($startValidity['min'])) {
                $this->addUsingAlias(BudgetPeer::START_VALIDITY, $startValidity['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($startValidity['max'])) {
                $this->addUsingAlias(BudgetPeer::START_VALIDITY, $startValidity['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(BudgetPeer::START_VALIDITY, $startValidity, $comparison);
    }

    /**
     * Filter the query on the end_validity column
     *
     * Example usage:
     * <code>
     * $query->filterByEndValidity('2011-03-14'); // WHERE end_validity = '2011-03-14'
     * $query->filterByEndValidity('now'); // WHERE end_validity = '2011-03-14'
     * $query->filterByEndValidity(array('max' => 'yesterday')); // WHERE end_validity < '2011-03-13'
     * </code>
     *
     * @param     mixed $endValidity The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return BudgetQuery The current query, for fluid interface
     */
    public function filterByEndValidity($endValidity = null, $comparison = null)
    {
        if (is_array($endValidity)) {
            $useMinMax = false;
            if (isset($endValidity['min'])) {
                $this->addUsingAlias(BudgetPeer::END_VALIDITY, $endValidity['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($endValidity['max'])) {
                $this->addUsingAlias(BudgetPeer::END_VALIDITY, $endValidity['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(BudgetPeer::END_VALIDITY, $endValidity, $comparison);
    }

    /**
     * Filter the query on the total_amount column
     *
     * Example usage:
     * <code>
     * $query->filterByTotalAmount(1234); // WHERE total_amount = 1234
     * $query->filterByTotalAmount(array(12, 34)); // WHERE total_amount IN (12, 34)
     * $query->filterByTotalAmount(array('min' => 12)); // WHERE total_amount >= 12
     * $query->filterByTotalAmount(array('max' => 12)); // WHERE total_amount <= 12
     * </code>
     *
     * @param     mixed $totalAmount The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return BudgetQuery The current query, for fluid interface
     */
    public function filterByTotalAmount($totalAmount = null, $comparison = null)
    {
        if (is_array($totalAmount)) {
            $useMinMax = false;
            if (isset($totalAmount['min'])) {
                $this->addUsingAlias(BudgetPeer::TOTAL_AMOUNT, $totalAmount['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($totalAmount['max'])) {
                $this->addUsingAlias(BudgetPeer::TOTAL_AMOUNT, $totalAmount['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(BudgetPeer::TOTAL_AMOUNT, $totalAmount, $comparison);
    }

    /**
     * Filter the query on the tolerance column
     *
     * Example usage:
     * <code>
     * $query->filterByTolerance(1234); // WHERE tolerance = 1234
     * $query->filterByTolerance(array(12, 34)); // WHERE tolerance IN (12, 34)
     * $query->filterByTolerance(array('min' => 12)); // WHERE tolerance >= 12
     * $query->filterByTolerance(array('max' => 12)); // WHERE tolerance <= 12
     * </code>
     *
     * @param     mixed $tolerance The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return BudgetQuery The current query, for fluid interface
     */
    public function filterByTolerance($tolerance = null, $comparison = null)
    {
        if (is_array($tolerance)) {
            $useMinMax = false;
            if (isset($tolerance['min'])) {
                $this->addUsingAlias(BudgetPeer::TOLERANCE, $tolerance['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($tolerance['max'])) {
                $this->addUsingAlias(BudgetPeer::TOLERANCE, $tolerance['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(BudgetPeer::TOLERANCE, $tolerance, $comparison);
    }

    /**
     * Filter the query on the budget_notes column
     *
     * Example usage:
     * <code>
     * $query->filterByBudgetNotes('fooValue');   // WHERE budget_notes = 'fooValue'
     * $query->filterByBudgetNotes('%fooValue%'); // WHERE budget_notes LIKE '%fooValue%'
     * </code>
     *
     * @param     string $budgetNotes The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return BudgetQuery The current query, for fluid interface
     */
    public function filterByBudgetNotes($budgetNotes = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($budgetNotes)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $budgetNotes)) {
                $budgetNotes = str_replace('*', '%', $budgetNotes);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(BudgetPeer::BUDGET_NOTES, $budgetNotes, $comparison);
    }

    /**
     * Filter the query on the date_created column
     *
     * Example usage:
     * <code>
     * $query->filterByDateCreated('2011-03-14'); // WHERE date_created = '2011-03-14'
     * $query->filterByDateCreated('now'); // WHERE date_created = '2011-03-14'
     * $query->filterByDateCreated(array('max' => 'yesterday')); // WHERE date_created < '2011-03-13'
     * </code>
     *
     * @param     mixed $dateCreated The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return BudgetQuery The current query, for fluid interface
     */
    public function filterByDateCreated($dateCreated = null, $comparison = null)
    {
        if (is_array($dateCreated)) {
            $useMinMax = false;
            if (isset($dateCreated['min'])) {
                $this->addUsingAlias(BudgetPeer::DATE_CREATED, $dateCreated['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dateCreated['max'])) {
                $this->addUsingAlias(BudgetPeer::DATE_CREATED, $dateCreated['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(BudgetPeer::DATE_CREATED, $dateCreated, $comparison);
    }

    /**
     * Filter the query on the date_updated column
     *
     * Example usage:
     * <code>
     * $query->filterByDateUpdated('2011-03-14'); // WHERE date_updated = '2011-03-14'
     * $query->filterByDateUpdated('now'); // WHERE date_updated = '2011-03-14'
     * $query->filterByDateUpdated(array('max' => 'yesterday')); // WHERE date_updated < '2011-03-13'
     * </code>
     *
     * @param     mixed $dateUpdated The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return BudgetQuery The current query, for fluid interface
     */
    public function filterByDateUpdated($dateUpdated = null, $comparison = null)
    {
        if (is_array($dateUpdated)) {
            $useMinMax = false;
            if (isset($dateUpdated['min'])) {
                $this->addUsingAlias(BudgetPeer::DATE_UPDATED, $dateUpdated['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dateUpdated['max'])) {
                $this->addUsingAlias(BudgetPeer::DATE_UPDATED, $dateUpdated['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(BudgetPeer::DATE_UPDATED, $dateUpdated, $comparison);
    }

    /**
     * Filter the query on the created_by column
     *
     * Example usage:
     * <code>
     * $query->filterByCreatedBy(1234); // WHERE created_by = 1234
     * $query->filterByCreatedBy(array(12, 34)); // WHERE created_by IN (12, 34)
     * $query->filterByCreatedBy(array('min' => 12)); // WHERE created_by >= 12
     * $query->filterByCreatedBy(array('max' => 12)); // WHERE created_by <= 12
     * </code>
     *
     * @see       filterByLibrarianRelatedByCreatedBy()
     *
     * @param     mixed $createdBy The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return BudgetQuery The current query, for fluid interface
     */
    public function filterByCreatedBy($createdBy = null, $comparison = null)
    {
        if (is_array($createdBy)) {
            $useMinMax = false;
            if (isset($createdBy['min'])) {
                $this->addUsingAlias(BudgetPeer::CREATED_BY, $createdBy['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($createdBy['max'])) {
                $this->addUsingAlias(BudgetPeer::CREATED_BY, $createdBy['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(BudgetPeer::CREATED_BY, $createdBy, $comparison);
    }

    /**
     * Filter the query on the modified_by column
     *
     * Example usage:
     * <code>
     * $query->filterByModifiedBy(1234); // WHERE modified_by = 1234
     * $query->filterByModifiedBy(array(12, 34)); // WHERE modified_by IN (12, 34)
     * $query->filterByModifiedBy(array('min' => 12)); // WHERE modified_by >= 12
     * $query->filterByModifiedBy(array('max' => 12)); // WHERE modified_by <= 12
     * </code>
     *
     * @see       filterByLibrarianRelatedByModifiedBy()
     *
     * @param     mixed $modifiedBy The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return BudgetQuery The current query, for fluid interface
     */
    public function filterByModifiedBy($modifiedBy = null, $comparison = null)
    {
        if (is_array($modifiedBy)) {
            $useMinMax = false;
            if (isset($modifiedBy['min'])) {
                $this->addUsingAlias(BudgetPeer::MODIFIED_BY, $modifiedBy['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($modifiedBy['max'])) {
                $this->addUsingAlias(BudgetPeer::MODIFIED_BY, $modifiedBy['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(BudgetPeer::MODIFIED_BY, $modifiedBy, $comparison);
    }

    /**
     * Filter the query by a related Librarian object
     *
     * @param   Librarian|PropelObjectCollection $librarian The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 BudgetQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByLibrarianRelatedByCreatedBy($librarian, $comparison = null)
    {
        if ($librarian instanceof Librarian) {
            return $this
                ->addUsingAlias(BudgetPeer::CREATED_BY, $librarian->getLibrarianId(), $comparison);
        } elseif ($librarian instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(BudgetPeer::CREATED_BY, $librarian->toKeyValue('PrimaryKey', 'LibrarianId'), $comparison);
        } else {
            throw new PropelException('filterByLibrarianRelatedByCreatedBy() only accepts arguments of type Librarian or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the LibrarianRelatedByCreatedBy relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return BudgetQuery The current query, for fluid interface
     */
    public function joinLibrarianRelatedByCreatedBy($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('LibrarianRelatedByCreatedBy');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'LibrarianRelatedByCreatedBy');
        }

        return $this;
    }

    /**
     * Use the LibrarianRelatedByCreatedBy relation Librarian object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   LibrarianQuery A secondary query class using the current class as primary query
     */
    public function useLibrarianRelatedByCreatedByQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinLibrarianRelatedByCreatedBy($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'LibrarianRelatedByCreatedBy', 'LibrarianQuery');
    }

    /**
     * Filter the query by a related Librarian object
     *
     * @param   Librarian|PropelObjectCollection $librarian The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 BudgetQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByLibrarianRelatedByModifiedBy($librarian, $comparison = null)
    {
        if ($librarian instanceof Librarian) {
            return $this
                ->addUsingAlias(BudgetPeer::MODIFIED_BY, $librarian->getLibrarianId(), $comparison);
        } elseif ($librarian instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(BudgetPeer::MODIFIED_BY, $librarian->toKeyValue('PrimaryKey', 'LibrarianId'), $comparison);
        } else {
            throw new PropelException('filterByLibrarianRelatedByModifiedBy() only accepts arguments of type Librarian or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the LibrarianRelatedByModifiedBy relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return BudgetQuery The current query, for fluid interface
     */
    public function joinLibrarianRelatedByModifiedBy($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('LibrarianRelatedByModifiedBy');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'LibrarianRelatedByModifiedBy');
        }

        return $this;
    }

    /**
     * Use the LibrarianRelatedByModifiedBy relation Librarian object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   LibrarianQuery A secondary query class using the current class as primary query
     */
    public function useLibrarianRelatedByModifiedByQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinLibrarianRelatedByModifiedBy($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'LibrarianRelatedByModifiedBy', 'LibrarianQuery');
    }

    /**
     * Filter the query by a related Library object
     *
     * @param   Library|PropelObjectCollection $library The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 BudgetQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByLibrary($library, $comparison = null)
    {
        if ($library instanceof Library) {
            return $this
                ->addUsingAlias(BudgetPeer::LIBRARY_ID, $library->getLibraryId(), $comparison);
        } elseif ($library instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(BudgetPeer::LIBRARY_ID, $library->toKeyValue('PrimaryKey', 'LibraryId'), $comparison);
        } else {
            throw new PropelException('filterByLibrary() only accepts arguments of type Library or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the Library relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return BudgetQuery The current query, for fluid interface
     */
    public function joinLibrary($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('Library');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'Library');
        }

        return $this;
    }

    /**
     * Use the Library relation Library object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   LibraryQuery A secondary query class using the current class as primary query
     */
    public function useLibraryQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinLibrary($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'Library', 'LibraryQuery');
    }

    /**
     * Filter the query by a related BudgetOperation object
     *
     * @param   BudgetOperation|PropelObjectCollection $budgetOperation  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 BudgetQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByBudgetOperation($budgetOperation, $comparison = null)
    {
        if ($budgetOperation instanceof BudgetOperation) {
            return $this
                ->addUsingAlias(BudgetPeer::BUDGET_ID, $budgetOperation->getBudgetId(), $comparison);
        } elseif ($budgetOperation instanceof PropelObjectCollection) {
            return $this
                ->useBudgetOperationQuery()
                ->filterByPrimaryKeys($budgetOperation->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByBudgetOperation() only accepts arguments of type BudgetOperation or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the BudgetOperation relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return BudgetQuery The current query, for fluid interface
     */
    public function joinBudgetOperation($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('BudgetOperation');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'BudgetOperation');
        }

        return $this;
    }

    /**
     * Use the BudgetOperation relation BudgetOperation object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   BudgetOperationQuery A secondary query class using the current class as primary query
     */
    public function useBudgetOperationQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinBudgetOperation($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'BudgetOperation', 'BudgetOperationQuery');
    }

    /**
     * Filter the query by a related Invoice object
     *
     * @param   Invoice|PropelObjectCollection $invoice  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 BudgetQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByInvoice($invoice, $comparison = null)
    {
        if ($invoice instanceof Invoice) {
            return $this
                ->addUsingAlias(BudgetPeer::BUDGET_ID, $invoice->getBudgetId(), $comparison);
        } elseif ($invoice instanceof PropelObjectCollection) {
            return $this
                ->useInvoiceQuery()
                ->filterByPrimaryKeys($invoice->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByInvoice() only accepts arguments of type Invoice or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the Invoice relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return BudgetQuery The current query, for fluid interface
     */
    public function joinInvoice($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('Invoice');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'Invoice');
        }

        return $this;
    }

    /**
     * Use the Invoice relation Invoice object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   InvoiceQuery A secondary query class using the current class as primary query
     */
    public function useInvoiceQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinInvoice($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'Invoice', 'InvoiceQuery');
    }

    /**
     * Filter the query by a related Item object
     *
     * @param   Item|PropelObjectCollection $item  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 BudgetQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByItem($item, $comparison = null)
    {
        if ($item instanceof Item) {
            return $this
                ->addUsingAlias(BudgetPeer::BUDGET_ID, $item->getBudgetId(), $comparison);
        } elseif ($item instanceof PropelObjectCollection) {
            return $this
                ->useItemQuery()
                ->filterByPrimaryKeys($item->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByItem() only accepts arguments of type Item or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the Item relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return BudgetQuery The current query, for fluid interface
     */
    public function joinItem($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('Item');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'Item');
        }

        return $this;
    }

    /**
     * Use the Item relation Item object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   ItemQuery A secondary query class using the current class as primary query
     */
    public function useItemQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinItem($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'Item', 'ItemQuery');
    }

    /**
     * Filter the query by a related Subscription object
     *
     * @param   Subscription|PropelObjectCollection $subscription  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 BudgetQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterBySubscription($subscription, $comparison = null)
    {
        if ($subscription instanceof Subscription) {
            return $this
                ->addUsingAlias(BudgetPeer::BUDGET_ID, $subscription->getBudgetId(), $comparison);
        } elseif ($subscription instanceof PropelObjectCollection) {
            return $this
                ->useSubscriptionQuery()
                ->filterByPrimaryKeys($subscription->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterBySubscription() only accepts arguments of type Subscription or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the Subscription relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return BudgetQuery The current query, for fluid interface
     */
    public function joinSubscription($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('Subscription');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'Subscription');
        }

        return $this;
    }

    /**
     * Use the Subscription relation Subscription object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   SubscriptionQuery A secondary query class using the current class as primary query
     */
    public function useSubscriptionQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinSubscription($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'Subscription', 'SubscriptionQuery');
    }

    /**
     * Exclude object from result
     *
     * @param   Budget $budget Object to remove from the list of results
     *
     * @return BudgetQuery The current query, for fluid interface
     */
    public function prune($budget = null)
    {
        if ($budget) {
            $this->addUsingAlias(BudgetPeer::BUDGET_ID, $budget->getBudgetId(), Criteria::NOT_EQUAL);
        }

        return $this;
    }

    // timestampable behavior

    /**
     * Filter by the latest updated
     *
     * @param      int $nbDays Maximum age of the latest update in days
     *
     * @return     BudgetQuery The current query, for fluid interface
     */
    public function recentlyUpdated($nbDays = 7)
    {
        return $this->addUsingAlias(BudgetPeer::DATE_UPDATED, time() - $nbDays * 24 * 60 * 60, Criteria::GREATER_EQUAL);
    }

    /**
     * Order by update date desc
     *
     * @return     BudgetQuery The current query, for fluid interface
     */
    public function lastUpdatedFirst()
    {
        return $this->addDescendingOrderByColumn(BudgetPeer::DATE_UPDATED);
    }

    /**
     * Order by update date asc
     *
     * @return     BudgetQuery The current query, for fluid interface
     */
    public function firstUpdatedFirst()
    {
        return $this->addAscendingOrderByColumn(BudgetPeer::DATE_UPDATED);
    }

    /**
     * Filter by the latest created
     *
     * @param      int $nbDays Maximum age of in days
     *
     * @return     BudgetQuery The current query, for fluid interface
     */
    public function recentlyCreated($nbDays = 7)
    {
        return $this->addUsingAlias(BudgetPeer::DATE_CREATED, time() - $nbDays * 24 * 60 * 60, Criteria::GREATER_EQUAL);
    }

    /**
     * Order by create date desc
     *
     * @return     BudgetQuery The current query, for fluid interface
     */
    public function lastCreatedFirst()
    {
        return $this->addDescendingOrderByColumn(BudgetPeer::DATE_CREATED);
    }

    /**
     * Order by create date asc
     *
     * @return     BudgetQuery The current query, for fluid interface
     */
    public function firstCreatedFirst()
    {
        return $this->addAscendingOrderByColumn(BudgetPeer::DATE_CREATED);
    }
}
