<?php


/**
 * Base class that represents a query for the 'item' table.
 *
 *
 *
 * @method ItemQuery orderByItemId($order = Criteria::ASC) Order by the item_id column
 * @method ItemQuery orderByTitle($order = Criteria::ASC) Order by the title column
 * @method ItemQuery orderByManifestationId($order = Criteria::ASC) Order by the manifestation_id column
 * @method ItemQuery orderByManifestationDewey($order = Criteria::ASC) Order by the manifestation_dewey column
 * @method ItemQuery orderByItemMedia($order = Criteria::ASC) Order by the item_media column
 * @method ItemQuery orderByItemStatus($order = Criteria::ASC) Order by the item_status column
 * @method ItemQuery orderByItemOrderStatus($order = Criteria::ASC) Order by the item_order_status column
 * @method ItemQuery orderByItemIcon($order = Criteria::ASC) Order by the item_icon column
 * @method ItemQuery orderByPhysicalStatus($order = Criteria::ASC) Order by the physical_status column
 * @method ItemQuery orderByItemSource($order = Criteria::ASC) Order by the item_source column
 * @method ItemQuery orderByOpacVisible($order = Criteria::ASC) Order by the opac_visible column
 * @method ItemQuery orderByInventorySerieId($order = Criteria::ASC) Order by the inventory_serie_id column
 * @method ItemQuery orderByInventoryNumber($order = Criteria::ASC) Order by the inventory_number column
 * @method ItemQuery orderByInventoryDate($order = Criteria::ASC) Order by the inventory_date column
 * @method ItemQuery orderByOwnerLibraryId($order = Criteria::ASC) Order by the owner_library_id column
 * @method ItemQuery orderByHomeLibraryId($order = Criteria::ASC) Order by the home_library_id column
 * @method ItemQuery orderByCollocation($order = Criteria::ASC) Order by the collocation column
 * @method ItemQuery orderBySection($order = Criteria::ASC) Order by the section column
 * @method ItemQuery orderBySequence1($order = Criteria::ASC) Order by the sequence1 column
 * @method ItemQuery orderBySequence2($order = Criteria::ASC) Order by the sequence2 column
 * @method ItemQuery orderBySpecification($order = Criteria::ASC) Order by the specification column
 * @method ItemQuery orderByReprint($order = Criteria::ASC) Order by the reprint column
 * @method ItemQuery orderByWidth($order = Criteria::ASC) Order by the width column
 * @method ItemQuery orderByHeight($order = Criteria::ASC) Order by the height column
 * @method ItemQuery orderByWeight($order = Criteria::ASC) Order by the weight column
 * @method ItemQuery orderByVolumeNumber($order = Criteria::ASC) Order by the volume_number column
 * @method ItemQuery orderByVolumeText($order = Criteria::ASC) Order by the volume_text column
 * @method ItemQuery orderByMediapackageSize($order = Criteria::ASC) Order by the mediapackage_size column
 * @method ItemQuery orderByCurrentLoanId($order = Criteria::ASC) Order by the current_loan_id column
 * @method ItemQuery orderByLoanClass($order = Criteria::ASC) Order by the loan_class column
 * @method ItemQuery orderByLastSeen($order = Criteria::ASC) Order by the last_seen column
 * @method ItemQuery orderByLoanStatus($order = Criteria::ASC) Order by the loan_status column
 * @method ItemQuery orderByLoanAlert($order = Criteria::ASC) Order by the loan_alert column
 * @method ItemQuery orderByLoanAlertNote($order = Criteria::ASC) Order by the loan_alert_note column
 * @method ItemQuery orderByUsageCount($order = Criteria::ASC) Order by the usage_count column
 * @method ItemQuery orderByDeliveryLibraryId($order = Criteria::ASC) Order by the delivery_library_id column
 * @method ItemQuery orderByDueDate($order = Criteria::ASC) Order by the due_date column
 * @method ItemQuery orderByPatronId($order = Criteria::ASC) Order by the patron_id column
 * @method ItemQuery orderByExternalLibraryId($order = Criteria::ASC) Order by the external_library_id column
 * @method ItemQuery orderByRenewalCount($order = Criteria::ASC) Order by the renewal_count column
 * @method ItemQuery orderByNotifyCount($order = Criteria::ASC) Order by the notify_count column
 * @method ItemQuery orderByCheckOut($order = Criteria::ASC) Order by the check_out column
 * @method ItemQuery orderByCheckIn($order = Criteria::ASC) Order by the check_in column
 * @method ItemQuery orderByIllTimestamp($order = Criteria::ASC) Order by the ill_timestamp column
 * @method ItemQuery orderBySupplierId($order = Criteria::ASC) Order by the supplier_id column
 * @method ItemQuery orderByInvoiceId($order = Criteria::ASC) Order by the invoice_id column
 * @method ItemQuery orderByOrderId($order = Criteria::ASC) Order by the order_id column
 * @method ItemQuery orderByBudgetId($order = Criteria::ASC) Order by the budget_id column
 * @method ItemQuery orderByCurrency($order = Criteria::ASC) Order by the currency column
 * @method ItemQuery orderByCurrencyValue($order = Criteria::ASC) Order by the currency_value column
 * @method ItemQuery orderByDiscountValue($order = Criteria::ASC) Order by the discount_value column
 * @method ItemQuery orderByInventoryValue($order = Criteria::ASC) Order by the inventory_value column
 * @method ItemQuery orderByIssueInventoryNumber($order = Criteria::ASC) Order by the issue_inventory_number column
 * @method ItemQuery orderByIssueId($order = Criteria::ASC) Order by the issue_id column
 * @method ItemQuery orderByIssueYear($order = Criteria::ASC) Order by the issue_year column
 * @method ItemQuery orderByIssueNumber($order = Criteria::ASC) Order by the issue_number column
 * @method ItemQuery orderByIssueDescription($order = Criteria::ASC) Order by the issue_description column
 * @method ItemQuery orderByIssueArrivalDate($order = Criteria::ASC) Order by the issue_arrival_date column
 * @method ItemQuery orderByIssueArrivalDateExpected($order = Criteria::ASC) Order by the issue_arrival_date_expected column
 * @method ItemQuery orderByIssueStatus($order = Criteria::ASC) Order by the issue_status column
 * @method ItemQuery orderBySubscriptionId($order = Criteria::ASC) Order by the subscription_id column
 * @method ItemQuery orderByConsistencyNoteId($order = Criteria::ASC) Order by the consistency_note_id column
 * @method ItemQuery orderByActualLibraryId($order = Criteria::ASC) Order by the actual_library_id column
 * @method ItemQuery orderByBarcode($order = Criteria::ASC) Order by the barcode column
 * @method ItemQuery orderByRfidCode($order = Criteria::ASC) Order by the rfid_code column
 * @method ItemQuery orderByCustomField1($order = Criteria::ASC) Order by the custom_field1 column
 * @method ItemQuery orderByCustomField2($order = Criteria::ASC) Order by the custom_field2 column
 * @method ItemQuery orderByCustomField3($order = Criteria::ASC) Order by the custom_field3 column
 * @method ItemQuery orderByUnimarc($order = Criteria::ASC) Order by the unimarc column
 * @method ItemQuery orderByLastSbnSync($order = Criteria::ASC) Order by the last_sbn_sync column
 * @method ItemQuery orderByDateDiscarded($order = Criteria::ASC) Order by the date_discarded column
 * @method ItemQuery orderByDiscardNote($order = Criteria::ASC) Order by the discard_note column
 * @method ItemQuery orderByDateCreated($order = Criteria::ASC) Order by the date_created column
 * @method ItemQuery orderByDateUpdated($order = Criteria::ASC) Order by the date_updated column
 * @method ItemQuery orderByCreatedBy($order = Criteria::ASC) Order by the created_by column
 * @method ItemQuery orderByModifiedBy($order = Criteria::ASC) Order by the modified_by column
 *
 * @method ItemQuery groupByItemId() Group by the item_id column
 * @method ItemQuery groupByTitle() Group by the title column
 * @method ItemQuery groupByManifestationId() Group by the manifestation_id column
 * @method ItemQuery groupByManifestationDewey() Group by the manifestation_dewey column
 * @method ItemQuery groupByItemMedia() Group by the item_media column
 * @method ItemQuery groupByItemStatus() Group by the item_status column
 * @method ItemQuery groupByItemOrderStatus() Group by the item_order_status column
 * @method ItemQuery groupByItemIcon() Group by the item_icon column
 * @method ItemQuery groupByPhysicalStatus() Group by the physical_status column
 * @method ItemQuery groupByItemSource() Group by the item_source column
 * @method ItemQuery groupByOpacVisible() Group by the opac_visible column
 * @method ItemQuery groupByInventorySerieId() Group by the inventory_serie_id column
 * @method ItemQuery groupByInventoryNumber() Group by the inventory_number column
 * @method ItemQuery groupByInventoryDate() Group by the inventory_date column
 * @method ItemQuery groupByOwnerLibraryId() Group by the owner_library_id column
 * @method ItemQuery groupByHomeLibraryId() Group by the home_library_id column
 * @method ItemQuery groupByCollocation() Group by the collocation column
 * @method ItemQuery groupBySection() Group by the section column
 * @method ItemQuery groupBySequence1() Group by the sequence1 column
 * @method ItemQuery groupBySequence2() Group by the sequence2 column
 * @method ItemQuery groupBySpecification() Group by the specification column
 * @method ItemQuery groupByReprint() Group by the reprint column
 * @method ItemQuery groupByWidth() Group by the width column
 * @method ItemQuery groupByHeight() Group by the height column
 * @method ItemQuery groupByWeight() Group by the weight column
 * @method ItemQuery groupByVolumeNumber() Group by the volume_number column
 * @method ItemQuery groupByVolumeText() Group by the volume_text column
 * @method ItemQuery groupByMediapackageSize() Group by the mediapackage_size column
 * @method ItemQuery groupByCurrentLoanId() Group by the current_loan_id column
 * @method ItemQuery groupByLoanClass() Group by the loan_class column
 * @method ItemQuery groupByLastSeen() Group by the last_seen column
 * @method ItemQuery groupByLoanStatus() Group by the loan_status column
 * @method ItemQuery groupByLoanAlert() Group by the loan_alert column
 * @method ItemQuery groupByLoanAlertNote() Group by the loan_alert_note column
 * @method ItemQuery groupByUsageCount() Group by the usage_count column
 * @method ItemQuery groupByDeliveryLibraryId() Group by the delivery_library_id column
 * @method ItemQuery groupByDueDate() Group by the due_date column
 * @method ItemQuery groupByPatronId() Group by the patron_id column
 * @method ItemQuery groupByExternalLibraryId() Group by the external_library_id column
 * @method ItemQuery groupByRenewalCount() Group by the renewal_count column
 * @method ItemQuery groupByNotifyCount() Group by the notify_count column
 * @method ItemQuery groupByCheckOut() Group by the check_out column
 * @method ItemQuery groupByCheckIn() Group by the check_in column
 * @method ItemQuery groupByIllTimestamp() Group by the ill_timestamp column
 * @method ItemQuery groupBySupplierId() Group by the supplier_id column
 * @method ItemQuery groupByInvoiceId() Group by the invoice_id column
 * @method ItemQuery groupByOrderId() Group by the order_id column
 * @method ItemQuery groupByBudgetId() Group by the budget_id column
 * @method ItemQuery groupByCurrency() Group by the currency column
 * @method ItemQuery groupByCurrencyValue() Group by the currency_value column
 * @method ItemQuery groupByDiscountValue() Group by the discount_value column
 * @method ItemQuery groupByInventoryValue() Group by the inventory_value column
 * @method ItemQuery groupByIssueInventoryNumber() Group by the issue_inventory_number column
 * @method ItemQuery groupByIssueId() Group by the issue_id column
 * @method ItemQuery groupByIssueYear() Group by the issue_year column
 * @method ItemQuery groupByIssueNumber() Group by the issue_number column
 * @method ItemQuery groupByIssueDescription() Group by the issue_description column
 * @method ItemQuery groupByIssueArrivalDate() Group by the issue_arrival_date column
 * @method ItemQuery groupByIssueArrivalDateExpected() Group by the issue_arrival_date_expected column
 * @method ItemQuery groupByIssueStatus() Group by the issue_status column
 * @method ItemQuery groupBySubscriptionId() Group by the subscription_id column
 * @method ItemQuery groupByConsistencyNoteId() Group by the consistency_note_id column
 * @method ItemQuery groupByActualLibraryId() Group by the actual_library_id column
 * @method ItemQuery groupByBarcode() Group by the barcode column
 * @method ItemQuery groupByRfidCode() Group by the rfid_code column
 * @method ItemQuery groupByCustomField1() Group by the custom_field1 column
 * @method ItemQuery groupByCustomField2() Group by the custom_field2 column
 * @method ItemQuery groupByCustomField3() Group by the custom_field3 column
 * @method ItemQuery groupByUnimarc() Group by the unimarc column
 * @method ItemQuery groupByLastSbnSync() Group by the last_sbn_sync column
 * @method ItemQuery groupByDateDiscarded() Group by the date_discarded column
 * @method ItemQuery groupByDiscardNote() Group by the discard_note column
 * @method ItemQuery groupByDateCreated() Group by the date_created column
 * @method ItemQuery groupByDateUpdated() Group by the date_updated column
 * @method ItemQuery groupByCreatedBy() Group by the created_by column
 * @method ItemQuery groupByModifiedBy() Group by the modified_by column
 *
 * @method ItemQuery leftJoin($relation) Adds a LEFT JOIN clause to the query
 * @method ItemQuery rightJoin($relation) Adds a RIGHT JOIN clause to the query
 * @method ItemQuery innerJoin($relation) Adds a INNER JOIN clause to the query
 *
 * @method ItemQuery leftJoinLibrarianRelatedByCreatedBy($relationAlias = null) Adds a LEFT JOIN clause to the query using the LibrarianRelatedByCreatedBy relation
 * @method ItemQuery rightJoinLibrarianRelatedByCreatedBy($relationAlias = null) Adds a RIGHT JOIN clause to the query using the LibrarianRelatedByCreatedBy relation
 * @method ItemQuery innerJoinLibrarianRelatedByCreatedBy($relationAlias = null) Adds a INNER JOIN clause to the query using the LibrarianRelatedByCreatedBy relation
 *
 * @method ItemQuery leftJoinLibrarianRelatedByModifiedBy($relationAlias = null) Adds a LEFT JOIN clause to the query using the LibrarianRelatedByModifiedBy relation
 * @method ItemQuery rightJoinLibrarianRelatedByModifiedBy($relationAlias = null) Adds a RIGHT JOIN clause to the query using the LibrarianRelatedByModifiedBy relation
 * @method ItemQuery innerJoinLibrarianRelatedByModifiedBy($relationAlias = null) Adds a INNER JOIN clause to the query using the LibrarianRelatedByModifiedBy relation
 *
 * @method ItemQuery leftJoinIssue($relationAlias = null) Adds a LEFT JOIN clause to the query using the Issue relation
 * @method ItemQuery rightJoinIssue($relationAlias = null) Adds a RIGHT JOIN clause to the query using the Issue relation
 * @method ItemQuery innerJoinIssue($relationAlias = null) Adds a INNER JOIN clause to the query using the Issue relation
 *
 * @method ItemQuery leftJoinManifestation($relationAlias = null) Adds a LEFT JOIN clause to the query using the Manifestation relation
 * @method ItemQuery rightJoinManifestation($relationAlias = null) Adds a RIGHT JOIN clause to the query using the Manifestation relation
 * @method ItemQuery innerJoinManifestation($relationAlias = null) Adds a INNER JOIN clause to the query using the Manifestation relation
 *
 * @method ItemQuery leftJoinConsistencyNote($relationAlias = null) Adds a LEFT JOIN clause to the query using the ConsistencyNote relation
 * @method ItemQuery rightJoinConsistencyNote($relationAlias = null) Adds a RIGHT JOIN clause to the query using the ConsistencyNote relation
 * @method ItemQuery innerJoinConsistencyNote($relationAlias = null) Adds a INNER JOIN clause to the query using the ConsistencyNote relation
 *
 * @method ItemQuery leftJoinLibraryRelatedByOwnerLibraryId($relationAlias = null) Adds a LEFT JOIN clause to the query using the LibraryRelatedByOwnerLibraryId relation
 * @method ItemQuery rightJoinLibraryRelatedByOwnerLibraryId($relationAlias = null) Adds a RIGHT JOIN clause to the query using the LibraryRelatedByOwnerLibraryId relation
 * @method ItemQuery innerJoinLibraryRelatedByOwnerLibraryId($relationAlias = null) Adds a INNER JOIN clause to the query using the LibraryRelatedByOwnerLibraryId relation
 *
 * @method ItemQuery leftJoinLibraryRelatedByHomeLibraryId($relationAlias = null) Adds a LEFT JOIN clause to the query using the LibraryRelatedByHomeLibraryId relation
 * @method ItemQuery rightJoinLibraryRelatedByHomeLibraryId($relationAlias = null) Adds a RIGHT JOIN clause to the query using the LibraryRelatedByHomeLibraryId relation
 * @method ItemQuery innerJoinLibraryRelatedByHomeLibraryId($relationAlias = null) Adds a INNER JOIN clause to the query using the LibraryRelatedByHomeLibraryId relation
 *
 * @method ItemQuery leftJoinLibraryRelatedByDeliveryLibraryId($relationAlias = null) Adds a LEFT JOIN clause to the query using the LibraryRelatedByDeliveryLibraryId relation
 * @method ItemQuery rightJoinLibraryRelatedByDeliveryLibraryId($relationAlias = null) Adds a RIGHT JOIN clause to the query using the LibraryRelatedByDeliveryLibraryId relation
 * @method ItemQuery innerJoinLibraryRelatedByDeliveryLibraryId($relationAlias = null) Adds a INNER JOIN clause to the query using the LibraryRelatedByDeliveryLibraryId relation
 *
 * @method ItemQuery leftJoinLibraryRelatedByActualLibraryId($relationAlias = null) Adds a LEFT JOIN clause to the query using the LibraryRelatedByActualLibraryId relation
 * @method ItemQuery rightJoinLibraryRelatedByActualLibraryId($relationAlias = null) Adds a RIGHT JOIN clause to the query using the LibraryRelatedByActualLibraryId relation
 * @method ItemQuery innerJoinLibraryRelatedByActualLibraryId($relationAlias = null) Adds a INNER JOIN clause to the query using the LibraryRelatedByActualLibraryId relation
 *
 * @method ItemQuery leftJoinInventorySerie($relationAlias = null) Adds a LEFT JOIN clause to the query using the InventorySerie relation
 * @method ItemQuery rightJoinInventorySerie($relationAlias = null) Adds a RIGHT JOIN clause to the query using the InventorySerie relation
 * @method ItemQuery innerJoinInventorySerie($relationAlias = null) Adds a INNER JOIN clause to the query using the InventorySerie relation
 *
 * @method ItemQuery leftJoinPurchaseOrder($relationAlias = null) Adds a LEFT JOIN clause to the query using the PurchaseOrder relation
 * @method ItemQuery rightJoinPurchaseOrder($relationAlias = null) Adds a RIGHT JOIN clause to the query using the PurchaseOrder relation
 * @method ItemQuery innerJoinPurchaseOrder($relationAlias = null) Adds a INNER JOIN clause to the query using the PurchaseOrder relation
 *
 * @method ItemQuery leftJoinInvoice($relationAlias = null) Adds a LEFT JOIN clause to the query using the Invoice relation
 * @method ItemQuery rightJoinInvoice($relationAlias = null) Adds a RIGHT JOIN clause to the query using the Invoice relation
 * @method ItemQuery innerJoinInvoice($relationAlias = null) Adds a INNER JOIN clause to the query using the Invoice relation
 *
 * @method ItemQuery leftJoinSupplier($relationAlias = null) Adds a LEFT JOIN clause to the query using the Supplier relation
 * @method ItemQuery rightJoinSupplier($relationAlias = null) Adds a RIGHT JOIN clause to the query using the Supplier relation
 * @method ItemQuery innerJoinSupplier($relationAlias = null) Adds a INNER JOIN clause to the query using the Supplier relation
 *
 * @method ItemQuery leftJoinPatron($relationAlias = null) Adds a LEFT JOIN clause to the query using the Patron relation
 * @method ItemQuery rightJoinPatron($relationAlias = null) Adds a RIGHT JOIN clause to the query using the Patron relation
 * @method ItemQuery innerJoinPatron($relationAlias = null) Adds a INNER JOIN clause to the query using the Patron relation
 *
 * @method ItemQuery leftJoinLibraryRelatedByExternalLibraryId($relationAlias = null) Adds a LEFT JOIN clause to the query using the LibraryRelatedByExternalLibraryId relation
 * @method ItemQuery rightJoinLibraryRelatedByExternalLibraryId($relationAlias = null) Adds a RIGHT JOIN clause to the query using the LibraryRelatedByExternalLibraryId relation
 * @method ItemQuery innerJoinLibraryRelatedByExternalLibraryId($relationAlias = null) Adds a INNER JOIN clause to the query using the LibraryRelatedByExternalLibraryId relation
 *
 * @method ItemQuery leftJoinLoanRelatedByCurrentLoanId($relationAlias = null) Adds a LEFT JOIN clause to the query using the LoanRelatedByCurrentLoanId relation
 * @method ItemQuery rightJoinLoanRelatedByCurrentLoanId($relationAlias = null) Adds a RIGHT JOIN clause to the query using the LoanRelatedByCurrentLoanId relation
 * @method ItemQuery innerJoinLoanRelatedByCurrentLoanId($relationAlias = null) Adds a INNER JOIN clause to the query using the LoanRelatedByCurrentLoanId relation
 *
 * @method ItemQuery leftJoinBudget($relationAlias = null) Adds a LEFT JOIN clause to the query using the Budget relation
 * @method ItemQuery rightJoinBudget($relationAlias = null) Adds a RIGHT JOIN clause to the query using the Budget relation
 * @method ItemQuery innerJoinBudget($relationAlias = null) Adds a INNER JOIN clause to the query using the Budget relation
 *
 * @method ItemQuery leftJoinItemAction($relationAlias = null) Adds a LEFT JOIN clause to the query using the ItemAction relation
 * @method ItemQuery rightJoinItemAction($relationAlias = null) Adds a RIGHT JOIN clause to the query using the ItemAction relation
 * @method ItemQuery innerJoinItemAction($relationAlias = null) Adds a INNER JOIN clause to the query using the ItemAction relation
 *
 * @method ItemQuery leftJoinItemNote($relationAlias = null) Adds a LEFT JOIN clause to the query using the ItemNote relation
 * @method ItemQuery rightJoinItemNote($relationAlias = null) Adds a RIGHT JOIN clause to the query using the ItemNote relation
 * @method ItemQuery innerJoinItemNote($relationAlias = null) Adds a INNER JOIN clause to the query using the ItemNote relation
 *
 * @method ItemQuery leftJoinItemRequest($relationAlias = null) Adds a LEFT JOIN clause to the query using the ItemRequest relation
 * @method ItemQuery rightJoinItemRequest($relationAlias = null) Adds a RIGHT JOIN clause to the query using the ItemRequest relation
 * @method ItemQuery innerJoinItemRequest($relationAlias = null) Adds a INNER JOIN clause to the query using the ItemRequest relation
 *
 * @method ItemQuery leftJoinLoanRelatedByItemId($relationAlias = null) Adds a LEFT JOIN clause to the query using the LoanRelatedByItemId relation
 * @method ItemQuery rightJoinLoanRelatedByItemId($relationAlias = null) Adds a RIGHT JOIN clause to the query using the LoanRelatedByItemId relation
 * @method ItemQuery innerJoinLoanRelatedByItemId($relationAlias = null) Adds a INNER JOIN clause to the query using the LoanRelatedByItemId relation
 *
 * @method ItemQuery leftJoinLAuthorityItem($relationAlias = null) Adds a LEFT JOIN clause to the query using the LAuthorityItem relation
 * @method ItemQuery rightJoinLAuthorityItem($relationAlias = null) Adds a RIGHT JOIN clause to the query using the LAuthorityItem relation
 * @method ItemQuery innerJoinLAuthorityItem($relationAlias = null) Adds a INNER JOIN clause to the query using the LAuthorityItem relation
 *
 * @method ItemQuery leftJoinPurchaseProposal($relationAlias = null) Adds a LEFT JOIN clause to the query using the PurchaseProposal relation
 * @method ItemQuery rightJoinPurchaseProposal($relationAlias = null) Adds a RIGHT JOIN clause to the query using the PurchaseProposal relation
 * @method ItemQuery innerJoinPurchaseProposal($relationAlias = null) Adds a INNER JOIN clause to the query using the PurchaseProposal relation
 *
 * @method Item findOne(PropelPDO $con = null) Return the first Item matching the query
 * @method Item findOneOrCreate(PropelPDO $con = null) Return the first Item matching the query, or a new Item object populated from the query conditions when no match is found
 *
 * @method Item findOneByTitle(string $title) Return the first Item filtered by the title column
 * @method Item findOneByManifestationId(int $manifestation_id) Return the first Item filtered by the manifestation_id column
 * @method Item findOneByManifestationDewey(string $manifestation_dewey) Return the first Item filtered by the manifestation_dewey column
 * @method Item findOneByItemMedia(string $item_media) Return the first Item filtered by the item_media column
 * @method Item findOneByItemStatus(string $item_status) Return the first Item filtered by the item_status column
 * @method Item findOneByItemOrderStatus(string $item_order_status) Return the first Item filtered by the item_order_status column
 * @method Item findOneByItemIcon(string $item_icon) Return the first Item filtered by the item_icon column
 * @method Item findOneByPhysicalStatus(string $physical_status) Return the first Item filtered by the physical_status column
 * @method Item findOneByItemSource(string $item_source) Return the first Item filtered by the item_source column
 * @method Item findOneByOpacVisible(boolean $opac_visible) Return the first Item filtered by the opac_visible column
 * @method Item findOneByInventorySerieId(string $inventory_serie_id) Return the first Item filtered by the inventory_serie_id column
 * @method Item findOneByInventoryNumber(int $inventory_number) Return the first Item filtered by the inventory_number column
 * @method Item findOneByInventoryDate(string $inventory_date) Return the first Item filtered by the inventory_date column
 * @method Item findOneByOwnerLibraryId(int $owner_library_id) Return the first Item filtered by the owner_library_id column
 * @method Item findOneByHomeLibraryId(int $home_library_id) Return the first Item filtered by the home_library_id column
 * @method Item findOneByCollocation(string $collocation) Return the first Item filtered by the collocation column
 * @method Item findOneBySection(string $section) Return the first Item filtered by the section column
 * @method Item findOneBySequence1(string $sequence1) Return the first Item filtered by the sequence1 column
 * @method Item findOneBySequence2(string $sequence2) Return the first Item filtered by the sequence2 column
 * @method Item findOneBySpecification(string $specification) Return the first Item filtered by the specification column
 * @method Item findOneByReprint(string $reprint) Return the first Item filtered by the reprint column
 * @method Item findOneByWidth(int $width) Return the first Item filtered by the width column
 * @method Item findOneByHeight(int $height) Return the first Item filtered by the height column
 * @method Item findOneByWeight(string $weight) Return the first Item filtered by the weight column
 * @method Item findOneByVolumeNumber(int $volume_number) Return the first Item filtered by the volume_number column
 * @method Item findOneByVolumeText(string $volume_text) Return the first Item filtered by the volume_text column
 * @method Item findOneByMediapackageSize(int $mediapackage_size) Return the first Item filtered by the mediapackage_size column
 * @method Item findOneByCurrentLoanId(int $current_loan_id) Return the first Item filtered by the current_loan_id column
 * @method Item findOneByLoanClass(string $loan_class) Return the first Item filtered by the loan_class column
 * @method Item findOneByLastSeen(string $last_seen) Return the first Item filtered by the last_seen column
 * @method Item findOneByLoanStatus(string $loan_status) Return the first Item filtered by the loan_status column
 * @method Item findOneByLoanAlert(string $loan_alert) Return the first Item filtered by the loan_alert column
 * @method Item findOneByLoanAlertNote(string $loan_alert_note) Return the first Item filtered by the loan_alert_note column
 * @method Item findOneByUsageCount(int $usage_count) Return the first Item filtered by the usage_count column
 * @method Item findOneByDeliveryLibraryId(int $delivery_library_id) Return the first Item filtered by the delivery_library_id column
 * @method Item findOneByDueDate(string $due_date) Return the first Item filtered by the due_date column
 * @method Item findOneByPatronId(int $patron_id) Return the first Item filtered by the patron_id column
 * @method Item findOneByExternalLibraryId(int $external_library_id) Return the first Item filtered by the external_library_id column
 * @method Item findOneByRenewalCount(int $renewal_count) Return the first Item filtered by the renewal_count column
 * @method Item findOneByNotifyCount(int $notify_count) Return the first Item filtered by the notify_count column
 * @method Item findOneByCheckOut(string $check_out) Return the first Item filtered by the check_out column
 * @method Item findOneByCheckIn(string $check_in) Return the first Item filtered by the check_in column
 * @method Item findOneByIllTimestamp(string $ill_timestamp) Return the first Item filtered by the ill_timestamp column
 * @method Item findOneBySupplierId(int $supplier_id) Return the first Item filtered by the supplier_id column
 * @method Item findOneByInvoiceId(int $invoice_id) Return the first Item filtered by the invoice_id column
 * @method Item findOneByOrderId(int $order_id) Return the first Item filtered by the order_id column
 * @method Item findOneByBudgetId(int $budget_id) Return the first Item filtered by the budget_id column
 * @method Item findOneByCurrency(string $currency) Return the first Item filtered by the currency column
 * @method Item findOneByCurrencyValue(string $currency_value) Return the first Item filtered by the currency_value column
 * @method Item findOneByDiscountValue(string $discount_value) Return the first Item filtered by the discount_value column
 * @method Item findOneByInventoryValue(string $inventory_value) Return the first Item filtered by the inventory_value column
 * @method Item findOneByIssueInventoryNumber(int $issue_inventory_number) Return the first Item filtered by the issue_inventory_number column
 * @method Item findOneByIssueId(int $issue_id) Return the first Item filtered by the issue_id column
 * @method Item findOneByIssueYear(string $issue_year) Return the first Item filtered by the issue_year column
 * @method Item findOneByIssueNumber(int $issue_number) Return the first Item filtered by the issue_number column
 * @method Item findOneByIssueDescription(string $issue_description) Return the first Item filtered by the issue_description column
 * @method Item findOneByIssueArrivalDate(string $issue_arrival_date) Return the first Item filtered by the issue_arrival_date column
 * @method Item findOneByIssueArrivalDateExpected(string $issue_arrival_date_expected) Return the first Item filtered by the issue_arrival_date_expected column
 * @method Item findOneByIssueStatus(string $issue_status) Return the first Item filtered by the issue_status column
 * @method Item findOneBySubscriptionId(int $subscription_id) Return the first Item filtered by the subscription_id column
 * @method Item findOneByConsistencyNoteId(int $consistency_note_id) Return the first Item filtered by the consistency_note_id column
 * @method Item findOneByActualLibraryId(int $actual_library_id) Return the first Item filtered by the actual_library_id column
 * @method Item findOneByBarcode(string $barcode) Return the first Item filtered by the barcode column
 * @method Item findOneByRfidCode(string $rfid_code) Return the first Item filtered by the rfid_code column
 * @method Item findOneByCustomField1(string $custom_field1) Return the first Item filtered by the custom_field1 column
 * @method Item findOneByCustomField2(string $custom_field2) Return the first Item filtered by the custom_field2 column
 * @method Item findOneByCustomField3(string $custom_field3) Return the first Item filtered by the custom_field3 column
 * @method Item findOneByUnimarc(string $unimarc) Return the first Item filtered by the unimarc column
 * @method Item findOneByLastSbnSync(string $last_sbn_sync) Return the first Item filtered by the last_sbn_sync column
 * @method Item findOneByDateDiscarded(string $date_discarded) Return the first Item filtered by the date_discarded column
 * @method Item findOneByDiscardNote(string $discard_note) Return the first Item filtered by the discard_note column
 * @method Item findOneByDateCreated(string $date_created) Return the first Item filtered by the date_created column
 * @method Item findOneByDateUpdated(string $date_updated) Return the first Item filtered by the date_updated column
 * @method Item findOneByCreatedBy(int $created_by) Return the first Item filtered by the created_by column
 * @method Item findOneByModifiedBy(int $modified_by) Return the first Item filtered by the modified_by column
 *
 * @method array findByItemId(int $item_id) Return Item objects filtered by the item_id column
 * @method array findByTitle(string $title) Return Item objects filtered by the title column
 * @method array findByManifestationId(int $manifestation_id) Return Item objects filtered by the manifestation_id column
 * @method array findByManifestationDewey(string $manifestation_dewey) Return Item objects filtered by the manifestation_dewey column
 * @method array findByItemMedia(string $item_media) Return Item objects filtered by the item_media column
 * @method array findByItemStatus(string $item_status) Return Item objects filtered by the item_status column
 * @method array findByItemOrderStatus(string $item_order_status) Return Item objects filtered by the item_order_status column
 * @method array findByItemIcon(string $item_icon) Return Item objects filtered by the item_icon column
 * @method array findByPhysicalStatus(string $physical_status) Return Item objects filtered by the physical_status column
 * @method array findByItemSource(string $item_source) Return Item objects filtered by the item_source column
 * @method array findByOpacVisible(boolean $opac_visible) Return Item objects filtered by the opac_visible column
 * @method array findByInventorySerieId(string $inventory_serie_id) Return Item objects filtered by the inventory_serie_id column
 * @method array findByInventoryNumber(int $inventory_number) Return Item objects filtered by the inventory_number column
 * @method array findByInventoryDate(string $inventory_date) Return Item objects filtered by the inventory_date column
 * @method array findByOwnerLibraryId(int $owner_library_id) Return Item objects filtered by the owner_library_id column
 * @method array findByHomeLibraryId(int $home_library_id) Return Item objects filtered by the home_library_id column
 * @method array findByCollocation(string $collocation) Return Item objects filtered by the collocation column
 * @method array findBySection(string $section) Return Item objects filtered by the section column
 * @method array findBySequence1(string $sequence1) Return Item objects filtered by the sequence1 column
 * @method array findBySequence2(string $sequence2) Return Item objects filtered by the sequence2 column
 * @method array findBySpecification(string $specification) Return Item objects filtered by the specification column
 * @method array findByReprint(string $reprint) Return Item objects filtered by the reprint column
 * @method array findByWidth(int $width) Return Item objects filtered by the width column
 * @method array findByHeight(int $height) Return Item objects filtered by the height column
 * @method array findByWeight(string $weight) Return Item objects filtered by the weight column
 * @method array findByVolumeNumber(int $volume_number) Return Item objects filtered by the volume_number column
 * @method array findByVolumeText(string $volume_text) Return Item objects filtered by the volume_text column
 * @method array findByMediapackageSize(int $mediapackage_size) Return Item objects filtered by the mediapackage_size column
 * @method array findByCurrentLoanId(int $current_loan_id) Return Item objects filtered by the current_loan_id column
 * @method array findByLoanClass(string $loan_class) Return Item objects filtered by the loan_class column
 * @method array findByLastSeen(string $last_seen) Return Item objects filtered by the last_seen column
 * @method array findByLoanStatus(string $loan_status) Return Item objects filtered by the loan_status column
 * @method array findByLoanAlert(string $loan_alert) Return Item objects filtered by the loan_alert column
 * @method array findByLoanAlertNote(string $loan_alert_note) Return Item objects filtered by the loan_alert_note column
 * @method array findByUsageCount(int $usage_count) Return Item objects filtered by the usage_count column
 * @method array findByDeliveryLibraryId(int $delivery_library_id) Return Item objects filtered by the delivery_library_id column
 * @method array findByDueDate(string $due_date) Return Item objects filtered by the due_date column
 * @method array findByPatronId(int $patron_id) Return Item objects filtered by the patron_id column
 * @method array findByExternalLibraryId(int $external_library_id) Return Item objects filtered by the external_library_id column
 * @method array findByRenewalCount(int $renewal_count) Return Item objects filtered by the renewal_count column
 * @method array findByNotifyCount(int $notify_count) Return Item objects filtered by the notify_count column
 * @method array findByCheckOut(string $check_out) Return Item objects filtered by the check_out column
 * @method array findByCheckIn(string $check_in) Return Item objects filtered by the check_in column
 * @method array findByIllTimestamp(string $ill_timestamp) Return Item objects filtered by the ill_timestamp column
 * @method array findBySupplierId(int $supplier_id) Return Item objects filtered by the supplier_id column
 * @method array findByInvoiceId(int $invoice_id) Return Item objects filtered by the invoice_id column
 * @method array findByOrderId(int $order_id) Return Item objects filtered by the order_id column
 * @method array findByBudgetId(int $budget_id) Return Item objects filtered by the budget_id column
 * @method array findByCurrency(string $currency) Return Item objects filtered by the currency column
 * @method array findByCurrencyValue(string $currency_value) Return Item objects filtered by the currency_value column
 * @method array findByDiscountValue(string $discount_value) Return Item objects filtered by the discount_value column
 * @method array findByInventoryValue(string $inventory_value) Return Item objects filtered by the inventory_value column
 * @method array findByIssueInventoryNumber(int $issue_inventory_number) Return Item objects filtered by the issue_inventory_number column
 * @method array findByIssueId(int $issue_id) Return Item objects filtered by the issue_id column
 * @method array findByIssueYear(string $issue_year) Return Item objects filtered by the issue_year column
 * @method array findByIssueNumber(int $issue_number) Return Item objects filtered by the issue_number column
 * @method array findByIssueDescription(string $issue_description) Return Item objects filtered by the issue_description column
 * @method array findByIssueArrivalDate(string $issue_arrival_date) Return Item objects filtered by the issue_arrival_date column
 * @method array findByIssueArrivalDateExpected(string $issue_arrival_date_expected) Return Item objects filtered by the issue_arrival_date_expected column
 * @method array findByIssueStatus(string $issue_status) Return Item objects filtered by the issue_status column
 * @method array findBySubscriptionId(int $subscription_id) Return Item objects filtered by the subscription_id column
 * @method array findByConsistencyNoteId(int $consistency_note_id) Return Item objects filtered by the consistency_note_id column
 * @method array findByActualLibraryId(int $actual_library_id) Return Item objects filtered by the actual_library_id column
 * @method array findByBarcode(string $barcode) Return Item objects filtered by the barcode column
 * @method array findByRfidCode(string $rfid_code) Return Item objects filtered by the rfid_code column
 * @method array findByCustomField1(string $custom_field1) Return Item objects filtered by the custom_field1 column
 * @method array findByCustomField2(string $custom_field2) Return Item objects filtered by the custom_field2 column
 * @method array findByCustomField3(string $custom_field3) Return Item objects filtered by the custom_field3 column
 * @method array findByUnimarc(string $unimarc) Return Item objects filtered by the unimarc column
 * @method array findByLastSbnSync(string $last_sbn_sync) Return Item objects filtered by the last_sbn_sync column
 * @method array findByDateDiscarded(string $date_discarded) Return Item objects filtered by the date_discarded column
 * @method array findByDiscardNote(string $discard_note) Return Item objects filtered by the discard_note column
 * @method array findByDateCreated(string $date_created) Return Item objects filtered by the date_created column
 * @method array findByDateUpdated(string $date_updated) Return Item objects filtered by the date_updated column
 * @method array findByCreatedBy(int $created_by) Return Item objects filtered by the created_by column
 * @method array findByModifiedBy(int $modified_by) Return Item objects filtered by the modified_by column
 *
 * @package    propel.generator.clavis.om
 */
abstract class BaseItemQuery extends ModelCriteria
{
    /**
     * Initializes internal state of BaseItemQuery object.
     *
     * @param     string $dbName The dabase name
     * @param     string $modelName The phpName of a model, e.g. 'Book'
     * @param     string $modelAlias The alias for the model in this query, e.g. 'b'
     */
    public function __construct($dbName = null, $modelName = null, $modelAlias = null)
    {
        if (null === $dbName) {
            $dbName = 'clavis';
        }
        if (null === $modelName) {
            $modelName = 'Item';
        }
        parent::__construct($dbName, $modelName, $modelAlias);
    }

    /**
     * Returns a new ItemQuery object.
     *
     * @param     string $modelAlias The alias of a model in the query
     * @param   ItemQuery|Criteria $criteria Optional Criteria to build the query from
     *
     * @return ItemQuery
     */
    public static function create($modelAlias = null, $criteria = null)
    {
        if ($criteria instanceof ItemQuery) {
            return $criteria;
        }
        $query = new ItemQuery(null, null, $modelAlias);

        if ($criteria instanceof Criteria) {
            $query->mergeWith($criteria);
        }

        return $query;
    }

    /**
     * Find object by primary key.
     * Propel uses the instance pool to skip the database if the object exists.
     * Go fast if the query is untouched.
     *
     * <code>
     * $obj  = $c->findPk(12, $con);
     * </code>
     *
     * @param mixed $key Primary key to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return   Item|Item[]|mixed the result, formatted by the current formatter
     */
    public function findPk($key, $con = null)
    {
        if ($key === null) {
            return null;
        }
        if ((null !== ($obj = ItemPeer::getInstanceFromPool((string) $key))) && !$this->formatter) {
            // the object is already in the instance pool
            return $obj;
        }
        if ($con === null) {
            $con = Propel::getConnection(ItemPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        if ($this->formatter || $this->modelAlias || $this->with || $this->select
         || $this->selectColumns || $this->asColumns || $this->selectModifiers
         || $this->map || $this->having || $this->joins) {
            return $this->findPkComplex($key, $con);
        } else {
            return $this->findPkSimple($key, $con);
        }
    }

    /**
     * Alias of findPk to use instance pooling
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 Item A model object, or null if the key is not found
     * @throws PropelException
     */
     public function findOneByItemId($key, $con = null)
     {
        return $this->findPk($key, $con);
     }

    /**
     * Find object by primary key using raw SQL to go fast.
     * Bypass doSelect() and the object formatter by using generated code.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 Item A model object, or null if the key is not found
     * @throws PropelException
     */
    protected function findPkSimple($key, $con)
    {
        $sql = 'SELECT `item_id`, `title`, `manifestation_id`, `manifestation_dewey`, `item_media`, `item_status`, `item_order_status`, `item_icon`, `physical_status`, `item_source`, `opac_visible`, `inventory_serie_id`, `inventory_number`, `inventory_date`, `owner_library_id`, `home_library_id`, `collocation`, `section`, `sequence1`, `sequence2`, `specification`, `reprint`, `width`, `height`, `weight`, `volume_number`, `volume_text`, `mediapackage_size`, `current_loan_id`, `loan_class`, `last_seen`, `loan_status`, `loan_alert`, `loan_alert_note`, `usage_count`, `delivery_library_id`, `due_date`, `patron_id`, `external_library_id`, `renewal_count`, `notify_count`, `check_out`, `check_in`, `ill_timestamp`, `supplier_id`, `invoice_id`, `order_id`, `budget_id`, `currency`, `currency_value`, `discount_value`, `inventory_value`, `issue_inventory_number`, `issue_id`, `issue_year`, `issue_number`, `issue_description`, `issue_arrival_date`, `issue_arrival_date_expected`, `issue_status`, `subscription_id`, `consistency_note_id`, `actual_library_id`, `barcode`, `rfid_code`, `custom_field1`, `custom_field2`, `custom_field3`, `unimarc`, `last_sbn_sync`, `date_discarded`, `discard_note`, `date_created`, `date_updated`, `created_by`, `modified_by` FROM `item` WHERE `item_id` = :p0';
        try {
            $stmt = $con->prepare($sql);
            $stmt->bindValue(':p0', $key, PDO::PARAM_INT);
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute SELECT statement [%s]', $sql), $e);
        }
        $obj = null;
        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $obj = new Item();
            $obj->hydrate($row);
            ItemPeer::addInstanceToPool($obj, (string) $key);
        }
        $stmt->closeCursor();

        return $obj;
    }

    /**
     * Find object by primary key.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return Item|Item[]|mixed the result, formatted by the current formatter
     */
    protected function findPkComplex($key, $con)
    {
        // As the query uses a PK condition, no limit(1) is necessary.
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKey($key)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->formatOne($stmt);
    }

    /**
     * Find objects by primary key
     * <code>
     * $objs = $c->findPks(array(12, 56, 832), $con);
     * </code>
     * @param     array $keys Primary keys to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return PropelObjectCollection|Item[]|mixed the list of results, formatted by the current formatter
     */
    public function findPks($keys, $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection($this->getDbName(), Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKeys($keys)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->format($stmt);
    }

    /**
     * Filter the query by primary key
     *
     * @param     mixed $key Primary key to use for the query
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByPrimaryKey($key)
    {

        return $this->addUsingAlias(ItemPeer::ITEM_ID, $key, Criteria::EQUAL);
    }

    /**
     * Filter the query by a list of primary keys
     *
     * @param     array $keys The list of primary key to use for the query
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByPrimaryKeys($keys)
    {

        return $this->addUsingAlias(ItemPeer::ITEM_ID, $keys, Criteria::IN);
    }

    /**
     * Filter the query on the item_id column
     *
     * Example usage:
     * <code>
     * $query->filterByItemId(1234); // WHERE item_id = 1234
     * $query->filterByItemId(array(12, 34)); // WHERE item_id IN (12, 34)
     * $query->filterByItemId(array('min' => 12)); // WHERE item_id >= 12
     * $query->filterByItemId(array('max' => 12)); // WHERE item_id <= 12
     * </code>
     *
     * @param     mixed $itemId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByItemId($itemId = null, $comparison = null)
    {
        if (is_array($itemId)) {
            $useMinMax = false;
            if (isset($itemId['min'])) {
                $this->addUsingAlias(ItemPeer::ITEM_ID, $itemId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($itemId['max'])) {
                $this->addUsingAlias(ItemPeer::ITEM_ID, $itemId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ItemPeer::ITEM_ID, $itemId, $comparison);
    }

    /**
     * Filter the query on the title column
     *
     * Example usage:
     * <code>
     * $query->filterByTitle('fooValue');   // WHERE title = 'fooValue'
     * $query->filterByTitle('%fooValue%'); // WHERE title LIKE '%fooValue%'
     * </code>
     *
     * @param     string $title The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByTitle($title = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($title)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $title)) {
                $title = str_replace('*', '%', $title);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(ItemPeer::TITLE, $title, $comparison);
    }

    /**
     * Filter the query on the manifestation_id column
     *
     * Example usage:
     * <code>
     * $query->filterByManifestationId(1234); // WHERE manifestation_id = 1234
     * $query->filterByManifestationId(array(12, 34)); // WHERE manifestation_id IN (12, 34)
     * $query->filterByManifestationId(array('min' => 12)); // WHERE manifestation_id >= 12
     * $query->filterByManifestationId(array('max' => 12)); // WHERE manifestation_id <= 12
     * </code>
     *
     * @see       filterByManifestation()
     *
     * @param     mixed $manifestationId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByManifestationId($manifestationId = null, $comparison = null)
    {
        if (is_array($manifestationId)) {
            $useMinMax = false;
            if (isset($manifestationId['min'])) {
                $this->addUsingAlias(ItemPeer::MANIFESTATION_ID, $manifestationId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($manifestationId['max'])) {
                $this->addUsingAlias(ItemPeer::MANIFESTATION_ID, $manifestationId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ItemPeer::MANIFESTATION_ID, $manifestationId, $comparison);
    }

    /**
     * Filter the query on the manifestation_dewey column
     *
     * Example usage:
     * <code>
     * $query->filterByManifestationDewey('fooValue');   // WHERE manifestation_dewey = 'fooValue'
     * $query->filterByManifestationDewey('%fooValue%'); // WHERE manifestation_dewey LIKE '%fooValue%'
     * </code>
     *
     * @param     string $manifestationDewey The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByManifestationDewey($manifestationDewey = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($manifestationDewey)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $manifestationDewey)) {
                $manifestationDewey = str_replace('*', '%', $manifestationDewey);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(ItemPeer::MANIFESTATION_DEWEY, $manifestationDewey, $comparison);
    }

    /**
     * Filter the query on the item_media column
     *
     * Example usage:
     * <code>
     * $query->filterByItemMedia('fooValue');   // WHERE item_media = 'fooValue'
     * $query->filterByItemMedia('%fooValue%'); // WHERE item_media LIKE '%fooValue%'
     * </code>
     *
     * @param     string $itemMedia The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByItemMedia($itemMedia = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($itemMedia)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $itemMedia)) {
                $itemMedia = str_replace('*', '%', $itemMedia);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(ItemPeer::ITEM_MEDIA, $itemMedia, $comparison);
    }

    /**
     * Filter the query on the item_status column
     *
     * Example usage:
     * <code>
     * $query->filterByItemStatus('fooValue');   // WHERE item_status = 'fooValue'
     * $query->filterByItemStatus('%fooValue%'); // WHERE item_status LIKE '%fooValue%'
     * </code>
     *
     * @param     string $itemStatus The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByItemStatus($itemStatus = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($itemStatus)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $itemStatus)) {
                $itemStatus = str_replace('*', '%', $itemStatus);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(ItemPeer::ITEM_STATUS, $itemStatus, $comparison);
    }

    /**
     * Filter the query on the item_order_status column
     *
     * Example usage:
     * <code>
     * $query->filterByItemOrderStatus('fooValue');   // WHERE item_order_status = 'fooValue'
     * $query->filterByItemOrderStatus('%fooValue%'); // WHERE item_order_status LIKE '%fooValue%'
     * </code>
     *
     * @param     string $itemOrderStatus The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByItemOrderStatus($itemOrderStatus = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($itemOrderStatus)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $itemOrderStatus)) {
                $itemOrderStatus = str_replace('*', '%', $itemOrderStatus);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(ItemPeer::ITEM_ORDER_STATUS, $itemOrderStatus, $comparison);
    }

    /**
     * Filter the query on the item_icon column
     *
     * Example usage:
     * <code>
     * $query->filterByItemIcon('fooValue');   // WHERE item_icon = 'fooValue'
     * $query->filterByItemIcon('%fooValue%'); // WHERE item_icon LIKE '%fooValue%'
     * </code>
     *
     * @param     string $itemIcon The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByItemIcon($itemIcon = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($itemIcon)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $itemIcon)) {
                $itemIcon = str_replace('*', '%', $itemIcon);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(ItemPeer::ITEM_ICON, $itemIcon, $comparison);
    }

    /**
     * Filter the query on the physical_status column
     *
     * Example usage:
     * <code>
     * $query->filterByPhysicalStatus('fooValue');   // WHERE physical_status = 'fooValue'
     * $query->filterByPhysicalStatus('%fooValue%'); // WHERE physical_status LIKE '%fooValue%'
     * </code>
     *
     * @param     string $physicalStatus The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByPhysicalStatus($physicalStatus = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($physicalStatus)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $physicalStatus)) {
                $physicalStatus = str_replace('*', '%', $physicalStatus);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(ItemPeer::PHYSICAL_STATUS, $physicalStatus, $comparison);
    }

    /**
     * Filter the query on the item_source column
     *
     * Example usage:
     * <code>
     * $query->filterByItemSource('fooValue');   // WHERE item_source = 'fooValue'
     * $query->filterByItemSource('%fooValue%'); // WHERE item_source LIKE '%fooValue%'
     * </code>
     *
     * @param     string $itemSource The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByItemSource($itemSource = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($itemSource)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $itemSource)) {
                $itemSource = str_replace('*', '%', $itemSource);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(ItemPeer::ITEM_SOURCE, $itemSource, $comparison);
    }

    /**
     * Filter the query on the opac_visible column
     *
     * Example usage:
     * <code>
     * $query->filterByOpacVisible(true); // WHERE opac_visible = true
     * $query->filterByOpacVisible('yes'); // WHERE opac_visible = true
     * </code>
     *
     * @param     boolean|string $opacVisible The value to use as filter.
     *              Non-boolean arguments are converted using the following rules:
     *                * 1, '1', 'true',  'on',  and 'yes' are converted to boolean true
     *                * 0, '0', 'false', 'off', and 'no'  are converted to boolean false
     *              Check on string values is case insensitive (so 'FaLsE' is seen as 'false').
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByOpacVisible($opacVisible = null, $comparison = null)
    {
        if (is_string($opacVisible)) {
            $opacVisible = in_array(strtolower($opacVisible), array('false', 'off', '-', 'no', 'n', '0', '')) ? false : true;
        }

        return $this->addUsingAlias(ItemPeer::OPAC_VISIBLE, $opacVisible, $comparison);
    }

    /**
     * Filter the query on the inventory_serie_id column
     *
     * Example usage:
     * <code>
     * $query->filterByInventorySerieId('fooValue');   // WHERE inventory_serie_id = 'fooValue'
     * $query->filterByInventorySerieId('%fooValue%'); // WHERE inventory_serie_id LIKE '%fooValue%'
     * </code>
     *
     * @param     string $inventorySerieId The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByInventorySerieId($inventorySerieId = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($inventorySerieId)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $inventorySerieId)) {
                $inventorySerieId = str_replace('*', '%', $inventorySerieId);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(ItemPeer::INVENTORY_SERIE_ID, $inventorySerieId, $comparison);
    }

    /**
     * Filter the query on the inventory_number column
     *
     * Example usage:
     * <code>
     * $query->filterByInventoryNumber(1234); // WHERE inventory_number = 1234
     * $query->filterByInventoryNumber(array(12, 34)); // WHERE inventory_number IN (12, 34)
     * $query->filterByInventoryNumber(array('min' => 12)); // WHERE inventory_number >= 12
     * $query->filterByInventoryNumber(array('max' => 12)); // WHERE inventory_number <= 12
     * </code>
     *
     * @param     mixed $inventoryNumber The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByInventoryNumber($inventoryNumber = null, $comparison = null)
    {
        if (is_array($inventoryNumber)) {
            $useMinMax = false;
            if (isset($inventoryNumber['min'])) {
                $this->addUsingAlias(ItemPeer::INVENTORY_NUMBER, $inventoryNumber['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($inventoryNumber['max'])) {
                $this->addUsingAlias(ItemPeer::INVENTORY_NUMBER, $inventoryNumber['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ItemPeer::INVENTORY_NUMBER, $inventoryNumber, $comparison);
    }

    /**
     * Filter the query on the inventory_date column
     *
     * Example usage:
     * <code>
     * $query->filterByInventoryDate('2011-03-14'); // WHERE inventory_date = '2011-03-14'
     * $query->filterByInventoryDate('now'); // WHERE inventory_date = '2011-03-14'
     * $query->filterByInventoryDate(array('max' => 'yesterday')); // WHERE inventory_date < '2011-03-13'
     * </code>
     *
     * @param     mixed $inventoryDate The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByInventoryDate($inventoryDate = null, $comparison = null)
    {
        if (is_array($inventoryDate)) {
            $useMinMax = false;
            if (isset($inventoryDate['min'])) {
                $this->addUsingAlias(ItemPeer::INVENTORY_DATE, $inventoryDate['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($inventoryDate['max'])) {
                $this->addUsingAlias(ItemPeer::INVENTORY_DATE, $inventoryDate['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ItemPeer::INVENTORY_DATE, $inventoryDate, $comparison);
    }

    /**
     * Filter the query on the owner_library_id column
     *
     * Example usage:
     * <code>
     * $query->filterByOwnerLibraryId(1234); // WHERE owner_library_id = 1234
     * $query->filterByOwnerLibraryId(array(12, 34)); // WHERE owner_library_id IN (12, 34)
     * $query->filterByOwnerLibraryId(array('min' => 12)); // WHERE owner_library_id >= 12
     * $query->filterByOwnerLibraryId(array('max' => 12)); // WHERE owner_library_id <= 12
     * </code>
     *
     * @see       filterByLibraryRelatedByOwnerLibraryId()
     *
     * @param     mixed $ownerLibraryId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByOwnerLibraryId($ownerLibraryId = null, $comparison = null)
    {
        if (is_array($ownerLibraryId)) {
            $useMinMax = false;
            if (isset($ownerLibraryId['min'])) {
                $this->addUsingAlias(ItemPeer::OWNER_LIBRARY_ID, $ownerLibraryId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($ownerLibraryId['max'])) {
                $this->addUsingAlias(ItemPeer::OWNER_LIBRARY_ID, $ownerLibraryId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ItemPeer::OWNER_LIBRARY_ID, $ownerLibraryId, $comparison);
    }

    /**
     * Filter the query on the home_library_id column
     *
     * Example usage:
     * <code>
     * $query->filterByHomeLibraryId(1234); // WHERE home_library_id = 1234
     * $query->filterByHomeLibraryId(array(12, 34)); // WHERE home_library_id IN (12, 34)
     * $query->filterByHomeLibraryId(array('min' => 12)); // WHERE home_library_id >= 12
     * $query->filterByHomeLibraryId(array('max' => 12)); // WHERE home_library_id <= 12
     * </code>
     *
     * @see       filterByLibraryRelatedByHomeLibraryId()
     *
     * @param     mixed $homeLibraryId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByHomeLibraryId($homeLibraryId = null, $comparison = null)
    {
        if (is_array($homeLibraryId)) {
            $useMinMax = false;
            if (isset($homeLibraryId['min'])) {
                $this->addUsingAlias(ItemPeer::HOME_LIBRARY_ID, $homeLibraryId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($homeLibraryId['max'])) {
                $this->addUsingAlias(ItemPeer::HOME_LIBRARY_ID, $homeLibraryId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ItemPeer::HOME_LIBRARY_ID, $homeLibraryId, $comparison);
    }

    /**
     * Filter the query on the collocation column
     *
     * Example usage:
     * <code>
     * $query->filterByCollocation('fooValue');   // WHERE collocation = 'fooValue'
     * $query->filterByCollocation('%fooValue%'); // WHERE collocation LIKE '%fooValue%'
     * </code>
     *
     * @param     string $collocation The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByCollocation($collocation = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($collocation)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $collocation)) {
                $collocation = str_replace('*', '%', $collocation);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(ItemPeer::COLLOCATION, $collocation, $comparison);
    }

    /**
     * Filter the query on the section column
     *
     * Example usage:
     * <code>
     * $query->filterBySection('fooValue');   // WHERE section = 'fooValue'
     * $query->filterBySection('%fooValue%'); // WHERE section LIKE '%fooValue%'
     * </code>
     *
     * @param     string $section The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterBySection($section = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($section)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $section)) {
                $section = str_replace('*', '%', $section);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(ItemPeer::SECTION, $section, $comparison);
    }

    /**
     * Filter the query on the sequence1 column
     *
     * Example usage:
     * <code>
     * $query->filterBySequence1('fooValue');   // WHERE sequence1 = 'fooValue'
     * $query->filterBySequence1('%fooValue%'); // WHERE sequence1 LIKE '%fooValue%'
     * </code>
     *
     * @param     string $sequence1 The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterBySequence1($sequence1 = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($sequence1)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $sequence1)) {
                $sequence1 = str_replace('*', '%', $sequence1);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(ItemPeer::SEQUENCE1, $sequence1, $comparison);
    }

    /**
     * Filter the query on the sequence2 column
     *
     * Example usage:
     * <code>
     * $query->filterBySequence2('fooValue');   // WHERE sequence2 = 'fooValue'
     * $query->filterBySequence2('%fooValue%'); // WHERE sequence2 LIKE '%fooValue%'
     * </code>
     *
     * @param     string $sequence2 The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterBySequence2($sequence2 = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($sequence2)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $sequence2)) {
                $sequence2 = str_replace('*', '%', $sequence2);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(ItemPeer::SEQUENCE2, $sequence2, $comparison);
    }

    /**
     * Filter the query on the specification column
     *
     * Example usage:
     * <code>
     * $query->filterBySpecification('fooValue');   // WHERE specification = 'fooValue'
     * $query->filterBySpecification('%fooValue%'); // WHERE specification LIKE '%fooValue%'
     * </code>
     *
     * @param     string $specification The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterBySpecification($specification = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($specification)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $specification)) {
                $specification = str_replace('*', '%', $specification);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(ItemPeer::SPECIFICATION, $specification, $comparison);
    }

    /**
     * Filter the query on the reprint column
     *
     * Example usage:
     * <code>
     * $query->filterByReprint('fooValue');   // WHERE reprint = 'fooValue'
     * $query->filterByReprint('%fooValue%'); // WHERE reprint LIKE '%fooValue%'
     * </code>
     *
     * @param     string $reprint The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByReprint($reprint = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($reprint)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $reprint)) {
                $reprint = str_replace('*', '%', $reprint);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(ItemPeer::REPRINT, $reprint, $comparison);
    }

    /**
     * Filter the query on the width column
     *
     * Example usage:
     * <code>
     * $query->filterByWidth(1234); // WHERE width = 1234
     * $query->filterByWidth(array(12, 34)); // WHERE width IN (12, 34)
     * $query->filterByWidth(array('min' => 12)); // WHERE width >= 12
     * $query->filterByWidth(array('max' => 12)); // WHERE width <= 12
     * </code>
     *
     * @param     mixed $width The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByWidth($width = null, $comparison = null)
    {
        if (is_array($width)) {
            $useMinMax = false;
            if (isset($width['min'])) {
                $this->addUsingAlias(ItemPeer::WIDTH, $width['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($width['max'])) {
                $this->addUsingAlias(ItemPeer::WIDTH, $width['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ItemPeer::WIDTH, $width, $comparison);
    }

    /**
     * Filter the query on the height column
     *
     * Example usage:
     * <code>
     * $query->filterByHeight(1234); // WHERE height = 1234
     * $query->filterByHeight(array(12, 34)); // WHERE height IN (12, 34)
     * $query->filterByHeight(array('min' => 12)); // WHERE height >= 12
     * $query->filterByHeight(array('max' => 12)); // WHERE height <= 12
     * </code>
     *
     * @param     mixed $height The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByHeight($height = null, $comparison = null)
    {
        if (is_array($height)) {
            $useMinMax = false;
            if (isset($height['min'])) {
                $this->addUsingAlias(ItemPeer::HEIGHT, $height['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($height['max'])) {
                $this->addUsingAlias(ItemPeer::HEIGHT, $height['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ItemPeer::HEIGHT, $height, $comparison);
    }

    /**
     * Filter the query on the weight column
     *
     * Example usage:
     * <code>
     * $query->filterByWeight(1234); // WHERE weight = 1234
     * $query->filterByWeight(array(12, 34)); // WHERE weight IN (12, 34)
     * $query->filterByWeight(array('min' => 12)); // WHERE weight >= 12
     * $query->filterByWeight(array('max' => 12)); // WHERE weight <= 12
     * </code>
     *
     * @param     mixed $weight The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByWeight($weight = null, $comparison = null)
    {
        if (is_array($weight)) {
            $useMinMax = false;
            if (isset($weight['min'])) {
                $this->addUsingAlias(ItemPeer::WEIGHT, $weight['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($weight['max'])) {
                $this->addUsingAlias(ItemPeer::WEIGHT, $weight['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ItemPeer::WEIGHT, $weight, $comparison);
    }

    /**
     * Filter the query on the volume_number column
     *
     * Example usage:
     * <code>
     * $query->filterByVolumeNumber(1234); // WHERE volume_number = 1234
     * $query->filterByVolumeNumber(array(12, 34)); // WHERE volume_number IN (12, 34)
     * $query->filterByVolumeNumber(array('min' => 12)); // WHERE volume_number >= 12
     * $query->filterByVolumeNumber(array('max' => 12)); // WHERE volume_number <= 12
     * </code>
     *
     * @param     mixed $volumeNumber The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByVolumeNumber($volumeNumber = null, $comparison = null)
    {
        if (is_array($volumeNumber)) {
            $useMinMax = false;
            if (isset($volumeNumber['min'])) {
                $this->addUsingAlias(ItemPeer::VOLUME_NUMBER, $volumeNumber['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($volumeNumber['max'])) {
                $this->addUsingAlias(ItemPeer::VOLUME_NUMBER, $volumeNumber['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ItemPeer::VOLUME_NUMBER, $volumeNumber, $comparison);
    }

    /**
     * Filter the query on the volume_text column
     *
     * Example usage:
     * <code>
     * $query->filterByVolumeText('fooValue');   // WHERE volume_text = 'fooValue'
     * $query->filterByVolumeText('%fooValue%'); // WHERE volume_text LIKE '%fooValue%'
     * </code>
     *
     * @param     string $volumeText The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByVolumeText($volumeText = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($volumeText)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $volumeText)) {
                $volumeText = str_replace('*', '%', $volumeText);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(ItemPeer::VOLUME_TEXT, $volumeText, $comparison);
    }

    /**
     * Filter the query on the mediapackage_size column
     *
     * Example usage:
     * <code>
     * $query->filterByMediapackageSize(1234); // WHERE mediapackage_size = 1234
     * $query->filterByMediapackageSize(array(12, 34)); // WHERE mediapackage_size IN (12, 34)
     * $query->filterByMediapackageSize(array('min' => 12)); // WHERE mediapackage_size >= 12
     * $query->filterByMediapackageSize(array('max' => 12)); // WHERE mediapackage_size <= 12
     * </code>
     *
     * @param     mixed $mediapackageSize The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByMediapackageSize($mediapackageSize = null, $comparison = null)
    {
        if (is_array($mediapackageSize)) {
            $useMinMax = false;
            if (isset($mediapackageSize['min'])) {
                $this->addUsingAlias(ItemPeer::MEDIAPACKAGE_SIZE, $mediapackageSize['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($mediapackageSize['max'])) {
                $this->addUsingAlias(ItemPeer::MEDIAPACKAGE_SIZE, $mediapackageSize['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ItemPeer::MEDIAPACKAGE_SIZE, $mediapackageSize, $comparison);
    }

    /**
     * Filter the query on the current_loan_id column
     *
     * Example usage:
     * <code>
     * $query->filterByCurrentLoanId(1234); // WHERE current_loan_id = 1234
     * $query->filterByCurrentLoanId(array(12, 34)); // WHERE current_loan_id IN (12, 34)
     * $query->filterByCurrentLoanId(array('min' => 12)); // WHERE current_loan_id >= 12
     * $query->filterByCurrentLoanId(array('max' => 12)); // WHERE current_loan_id <= 12
     * </code>
     *
     * @see       filterByLoanRelatedByCurrentLoanId()
     *
     * @param     mixed $currentLoanId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByCurrentLoanId($currentLoanId = null, $comparison = null)
    {
        if (is_array($currentLoanId)) {
            $useMinMax = false;
            if (isset($currentLoanId['min'])) {
                $this->addUsingAlias(ItemPeer::CURRENT_LOAN_ID, $currentLoanId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($currentLoanId['max'])) {
                $this->addUsingAlias(ItemPeer::CURRENT_LOAN_ID, $currentLoanId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ItemPeer::CURRENT_LOAN_ID, $currentLoanId, $comparison);
    }

    /**
     * Filter the query on the loan_class column
     *
     * Example usage:
     * <code>
     * $query->filterByLoanClass('fooValue');   // WHERE loan_class = 'fooValue'
     * $query->filterByLoanClass('%fooValue%'); // WHERE loan_class LIKE '%fooValue%'
     * </code>
     *
     * @param     string $loanClass The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByLoanClass($loanClass = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($loanClass)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $loanClass)) {
                $loanClass = str_replace('*', '%', $loanClass);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(ItemPeer::LOAN_CLASS, $loanClass, $comparison);
    }

    /**
     * Filter the query on the last_seen column
     *
     * Example usage:
     * <code>
     * $query->filterByLastSeen('2011-03-14'); // WHERE last_seen = '2011-03-14'
     * $query->filterByLastSeen('now'); // WHERE last_seen = '2011-03-14'
     * $query->filterByLastSeen(array('max' => 'yesterday')); // WHERE last_seen < '2011-03-13'
     * </code>
     *
     * @param     mixed $lastSeen The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByLastSeen($lastSeen = null, $comparison = null)
    {
        if (is_array($lastSeen)) {
            $useMinMax = false;
            if (isset($lastSeen['min'])) {
                $this->addUsingAlias(ItemPeer::LAST_SEEN, $lastSeen['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($lastSeen['max'])) {
                $this->addUsingAlias(ItemPeer::LAST_SEEN, $lastSeen['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ItemPeer::LAST_SEEN, $lastSeen, $comparison);
    }

    /**
     * Filter the query on the loan_status column
     *
     * Example usage:
     * <code>
     * $query->filterByLoanStatus('fooValue');   // WHERE loan_status = 'fooValue'
     * $query->filterByLoanStatus('%fooValue%'); // WHERE loan_status LIKE '%fooValue%'
     * </code>
     *
     * @param     string $loanStatus The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByLoanStatus($loanStatus = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($loanStatus)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $loanStatus)) {
                $loanStatus = str_replace('*', '%', $loanStatus);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(ItemPeer::LOAN_STATUS, $loanStatus, $comparison);
    }

    /**
     * Filter the query on the loan_alert column
     *
     * Example usage:
     * <code>
     * $query->filterByLoanAlert('fooValue');   // WHERE loan_alert = 'fooValue'
     * $query->filterByLoanAlert('%fooValue%'); // WHERE loan_alert LIKE '%fooValue%'
     * </code>
     *
     * @param     string $loanAlert The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByLoanAlert($loanAlert = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($loanAlert)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $loanAlert)) {
                $loanAlert = str_replace('*', '%', $loanAlert);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(ItemPeer::LOAN_ALERT, $loanAlert, $comparison);
    }

    /**
     * Filter the query on the loan_alert_note column
     *
     * Example usage:
     * <code>
     * $query->filterByLoanAlertNote('fooValue');   // WHERE loan_alert_note = 'fooValue'
     * $query->filterByLoanAlertNote('%fooValue%'); // WHERE loan_alert_note LIKE '%fooValue%'
     * </code>
     *
     * @param     string $loanAlertNote The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByLoanAlertNote($loanAlertNote = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($loanAlertNote)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $loanAlertNote)) {
                $loanAlertNote = str_replace('*', '%', $loanAlertNote);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(ItemPeer::LOAN_ALERT_NOTE, $loanAlertNote, $comparison);
    }

    /**
     * Filter the query on the usage_count column
     *
     * Example usage:
     * <code>
     * $query->filterByUsageCount(1234); // WHERE usage_count = 1234
     * $query->filterByUsageCount(array(12, 34)); // WHERE usage_count IN (12, 34)
     * $query->filterByUsageCount(array('min' => 12)); // WHERE usage_count >= 12
     * $query->filterByUsageCount(array('max' => 12)); // WHERE usage_count <= 12
     * </code>
     *
     * @param     mixed $usageCount The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByUsageCount($usageCount = null, $comparison = null)
    {
        if (is_array($usageCount)) {
            $useMinMax = false;
            if (isset($usageCount['min'])) {
                $this->addUsingAlias(ItemPeer::USAGE_COUNT, $usageCount['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($usageCount['max'])) {
                $this->addUsingAlias(ItemPeer::USAGE_COUNT, $usageCount['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ItemPeer::USAGE_COUNT, $usageCount, $comparison);
    }

    /**
     * Filter the query on the delivery_library_id column
     *
     * Example usage:
     * <code>
     * $query->filterByDeliveryLibraryId(1234); // WHERE delivery_library_id = 1234
     * $query->filterByDeliveryLibraryId(array(12, 34)); // WHERE delivery_library_id IN (12, 34)
     * $query->filterByDeliveryLibraryId(array('min' => 12)); // WHERE delivery_library_id >= 12
     * $query->filterByDeliveryLibraryId(array('max' => 12)); // WHERE delivery_library_id <= 12
     * </code>
     *
     * @see       filterByLibraryRelatedByDeliveryLibraryId()
     *
     * @param     mixed $deliveryLibraryId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByDeliveryLibraryId($deliveryLibraryId = null, $comparison = null)
    {
        if (is_array($deliveryLibraryId)) {
            $useMinMax = false;
            if (isset($deliveryLibraryId['min'])) {
                $this->addUsingAlias(ItemPeer::DELIVERY_LIBRARY_ID, $deliveryLibraryId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($deliveryLibraryId['max'])) {
                $this->addUsingAlias(ItemPeer::DELIVERY_LIBRARY_ID, $deliveryLibraryId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ItemPeer::DELIVERY_LIBRARY_ID, $deliveryLibraryId, $comparison);
    }

    /**
     * Filter the query on the due_date column
     *
     * Example usage:
     * <code>
     * $query->filterByDueDate('2011-03-14'); // WHERE due_date = '2011-03-14'
     * $query->filterByDueDate('now'); // WHERE due_date = '2011-03-14'
     * $query->filterByDueDate(array('max' => 'yesterday')); // WHERE due_date < '2011-03-13'
     * </code>
     *
     * @param     mixed $dueDate The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByDueDate($dueDate = null, $comparison = null)
    {
        if (is_array($dueDate)) {
            $useMinMax = false;
            if (isset($dueDate['min'])) {
                $this->addUsingAlias(ItemPeer::DUE_DATE, $dueDate['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dueDate['max'])) {
                $this->addUsingAlias(ItemPeer::DUE_DATE, $dueDate['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ItemPeer::DUE_DATE, $dueDate, $comparison);
    }

    /**
     * Filter the query on the patron_id column
     *
     * Example usage:
     * <code>
     * $query->filterByPatronId(1234); // WHERE patron_id = 1234
     * $query->filterByPatronId(array(12, 34)); // WHERE patron_id IN (12, 34)
     * $query->filterByPatronId(array('min' => 12)); // WHERE patron_id >= 12
     * $query->filterByPatronId(array('max' => 12)); // WHERE patron_id <= 12
     * </code>
     *
     * @see       filterByPatron()
     *
     * @param     mixed $patronId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByPatronId($patronId = null, $comparison = null)
    {
        if (is_array($patronId)) {
            $useMinMax = false;
            if (isset($patronId['min'])) {
                $this->addUsingAlias(ItemPeer::PATRON_ID, $patronId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($patronId['max'])) {
                $this->addUsingAlias(ItemPeer::PATRON_ID, $patronId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ItemPeer::PATRON_ID, $patronId, $comparison);
    }

    /**
     * Filter the query on the external_library_id column
     *
     * Example usage:
     * <code>
     * $query->filterByExternalLibraryId(1234); // WHERE external_library_id = 1234
     * $query->filterByExternalLibraryId(array(12, 34)); // WHERE external_library_id IN (12, 34)
     * $query->filterByExternalLibraryId(array('min' => 12)); // WHERE external_library_id >= 12
     * $query->filterByExternalLibraryId(array('max' => 12)); // WHERE external_library_id <= 12
     * </code>
     *
     * @see       filterByLibraryRelatedByExternalLibraryId()
     *
     * @param     mixed $externalLibraryId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByExternalLibraryId($externalLibraryId = null, $comparison = null)
    {
        if (is_array($externalLibraryId)) {
            $useMinMax = false;
            if (isset($externalLibraryId['min'])) {
                $this->addUsingAlias(ItemPeer::EXTERNAL_LIBRARY_ID, $externalLibraryId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($externalLibraryId['max'])) {
                $this->addUsingAlias(ItemPeer::EXTERNAL_LIBRARY_ID, $externalLibraryId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ItemPeer::EXTERNAL_LIBRARY_ID, $externalLibraryId, $comparison);
    }

    /**
     * Filter the query on the renewal_count column
     *
     * Example usage:
     * <code>
     * $query->filterByRenewalCount(1234); // WHERE renewal_count = 1234
     * $query->filterByRenewalCount(array(12, 34)); // WHERE renewal_count IN (12, 34)
     * $query->filterByRenewalCount(array('min' => 12)); // WHERE renewal_count >= 12
     * $query->filterByRenewalCount(array('max' => 12)); // WHERE renewal_count <= 12
     * </code>
     *
     * @param     mixed $renewalCount The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByRenewalCount($renewalCount = null, $comparison = null)
    {
        if (is_array($renewalCount)) {
            $useMinMax = false;
            if (isset($renewalCount['min'])) {
                $this->addUsingAlias(ItemPeer::RENEWAL_COUNT, $renewalCount['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($renewalCount['max'])) {
                $this->addUsingAlias(ItemPeer::RENEWAL_COUNT, $renewalCount['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ItemPeer::RENEWAL_COUNT, $renewalCount, $comparison);
    }

    /**
     * Filter the query on the notify_count column
     *
     * Example usage:
     * <code>
     * $query->filterByNotifyCount(1234); // WHERE notify_count = 1234
     * $query->filterByNotifyCount(array(12, 34)); // WHERE notify_count IN (12, 34)
     * $query->filterByNotifyCount(array('min' => 12)); // WHERE notify_count >= 12
     * $query->filterByNotifyCount(array('max' => 12)); // WHERE notify_count <= 12
     * </code>
     *
     * @param     mixed $notifyCount The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByNotifyCount($notifyCount = null, $comparison = null)
    {
        if (is_array($notifyCount)) {
            $useMinMax = false;
            if (isset($notifyCount['min'])) {
                $this->addUsingAlias(ItemPeer::NOTIFY_COUNT, $notifyCount['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($notifyCount['max'])) {
                $this->addUsingAlias(ItemPeer::NOTIFY_COUNT, $notifyCount['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ItemPeer::NOTIFY_COUNT, $notifyCount, $comparison);
    }

    /**
     * Filter the query on the check_out column
     *
     * Example usage:
     * <code>
     * $query->filterByCheckOut('2011-03-14'); // WHERE check_out = '2011-03-14'
     * $query->filterByCheckOut('now'); // WHERE check_out = '2011-03-14'
     * $query->filterByCheckOut(array('max' => 'yesterday')); // WHERE check_out < '2011-03-13'
     * </code>
     *
     * @param     mixed $checkOut The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByCheckOut($checkOut = null, $comparison = null)
    {
        if (is_array($checkOut)) {
            $useMinMax = false;
            if (isset($checkOut['min'])) {
                $this->addUsingAlias(ItemPeer::CHECK_OUT, $checkOut['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($checkOut['max'])) {
                $this->addUsingAlias(ItemPeer::CHECK_OUT, $checkOut['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ItemPeer::CHECK_OUT, $checkOut, $comparison);
    }

    /**
     * Filter the query on the check_in column
     *
     * Example usage:
     * <code>
     * $query->filterByCheckIn('2011-03-14'); // WHERE check_in = '2011-03-14'
     * $query->filterByCheckIn('now'); // WHERE check_in = '2011-03-14'
     * $query->filterByCheckIn(array('max' => 'yesterday')); // WHERE check_in < '2011-03-13'
     * </code>
     *
     * @param     mixed $checkIn The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByCheckIn($checkIn = null, $comparison = null)
    {
        if (is_array($checkIn)) {
            $useMinMax = false;
            if (isset($checkIn['min'])) {
                $this->addUsingAlias(ItemPeer::CHECK_IN, $checkIn['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($checkIn['max'])) {
                $this->addUsingAlias(ItemPeer::CHECK_IN, $checkIn['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ItemPeer::CHECK_IN, $checkIn, $comparison);
    }

    /**
     * Filter the query on the ill_timestamp column
     *
     * Example usage:
     * <code>
     * $query->filterByIllTimestamp('2011-03-14'); // WHERE ill_timestamp = '2011-03-14'
     * $query->filterByIllTimestamp('now'); // WHERE ill_timestamp = '2011-03-14'
     * $query->filterByIllTimestamp(array('max' => 'yesterday')); // WHERE ill_timestamp < '2011-03-13'
     * </code>
     *
     * @param     mixed $illTimestamp The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByIllTimestamp($illTimestamp = null, $comparison = null)
    {
        if (is_array($illTimestamp)) {
            $useMinMax = false;
            if (isset($illTimestamp['min'])) {
                $this->addUsingAlias(ItemPeer::ILL_TIMESTAMP, $illTimestamp['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($illTimestamp['max'])) {
                $this->addUsingAlias(ItemPeer::ILL_TIMESTAMP, $illTimestamp['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ItemPeer::ILL_TIMESTAMP, $illTimestamp, $comparison);
    }

    /**
     * Filter the query on the supplier_id column
     *
     * Example usage:
     * <code>
     * $query->filterBySupplierId(1234); // WHERE supplier_id = 1234
     * $query->filterBySupplierId(array(12, 34)); // WHERE supplier_id IN (12, 34)
     * $query->filterBySupplierId(array('min' => 12)); // WHERE supplier_id >= 12
     * $query->filterBySupplierId(array('max' => 12)); // WHERE supplier_id <= 12
     * </code>
     *
     * @see       filterBySupplier()
     *
     * @param     mixed $supplierId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterBySupplierId($supplierId = null, $comparison = null)
    {
        if (is_array($supplierId)) {
            $useMinMax = false;
            if (isset($supplierId['min'])) {
                $this->addUsingAlias(ItemPeer::SUPPLIER_ID, $supplierId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($supplierId['max'])) {
                $this->addUsingAlias(ItemPeer::SUPPLIER_ID, $supplierId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ItemPeer::SUPPLIER_ID, $supplierId, $comparison);
    }

    /**
     * Filter the query on the invoice_id column
     *
     * Example usage:
     * <code>
     * $query->filterByInvoiceId(1234); // WHERE invoice_id = 1234
     * $query->filterByInvoiceId(array(12, 34)); // WHERE invoice_id IN (12, 34)
     * $query->filterByInvoiceId(array('min' => 12)); // WHERE invoice_id >= 12
     * $query->filterByInvoiceId(array('max' => 12)); // WHERE invoice_id <= 12
     * </code>
     *
     * @see       filterByInvoice()
     *
     * @param     mixed $invoiceId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByInvoiceId($invoiceId = null, $comparison = null)
    {
        if (is_array($invoiceId)) {
            $useMinMax = false;
            if (isset($invoiceId['min'])) {
                $this->addUsingAlias(ItemPeer::INVOICE_ID, $invoiceId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($invoiceId['max'])) {
                $this->addUsingAlias(ItemPeer::INVOICE_ID, $invoiceId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ItemPeer::INVOICE_ID, $invoiceId, $comparison);
    }

    /**
     * Filter the query on the order_id column
     *
     * Example usage:
     * <code>
     * $query->filterByOrderId(1234); // WHERE order_id = 1234
     * $query->filterByOrderId(array(12, 34)); // WHERE order_id IN (12, 34)
     * $query->filterByOrderId(array('min' => 12)); // WHERE order_id >= 12
     * $query->filterByOrderId(array('max' => 12)); // WHERE order_id <= 12
     * </code>
     *
     * @see       filterByPurchaseOrder()
     *
     * @param     mixed $orderId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByOrderId($orderId = null, $comparison = null)
    {
        if (is_array($orderId)) {
            $useMinMax = false;
            if (isset($orderId['min'])) {
                $this->addUsingAlias(ItemPeer::ORDER_ID, $orderId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($orderId['max'])) {
                $this->addUsingAlias(ItemPeer::ORDER_ID, $orderId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ItemPeer::ORDER_ID, $orderId, $comparison);
    }

    /**
     * Filter the query on the budget_id column
     *
     * Example usage:
     * <code>
     * $query->filterByBudgetId(1234); // WHERE budget_id = 1234
     * $query->filterByBudgetId(array(12, 34)); // WHERE budget_id IN (12, 34)
     * $query->filterByBudgetId(array('min' => 12)); // WHERE budget_id >= 12
     * $query->filterByBudgetId(array('max' => 12)); // WHERE budget_id <= 12
     * </code>
     *
     * @see       filterByBudget()
     *
     * @param     mixed $budgetId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByBudgetId($budgetId = null, $comparison = null)
    {
        if (is_array($budgetId)) {
            $useMinMax = false;
            if (isset($budgetId['min'])) {
                $this->addUsingAlias(ItemPeer::BUDGET_ID, $budgetId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($budgetId['max'])) {
                $this->addUsingAlias(ItemPeer::BUDGET_ID, $budgetId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ItemPeer::BUDGET_ID, $budgetId, $comparison);
    }

    /**
     * Filter the query on the currency column
     *
     * Example usage:
     * <code>
     * $query->filterByCurrency('fooValue');   // WHERE currency = 'fooValue'
     * $query->filterByCurrency('%fooValue%'); // WHERE currency LIKE '%fooValue%'
     * </code>
     *
     * @param     string $currency The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByCurrency($currency = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($currency)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $currency)) {
                $currency = str_replace('*', '%', $currency);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(ItemPeer::CURRENCY, $currency, $comparison);
    }

    /**
     * Filter the query on the currency_value column
     *
     * Example usage:
     * <code>
     * $query->filterByCurrencyValue(1234); // WHERE currency_value = 1234
     * $query->filterByCurrencyValue(array(12, 34)); // WHERE currency_value IN (12, 34)
     * $query->filterByCurrencyValue(array('min' => 12)); // WHERE currency_value >= 12
     * $query->filterByCurrencyValue(array('max' => 12)); // WHERE currency_value <= 12
     * </code>
     *
     * @param     mixed $currencyValue The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByCurrencyValue($currencyValue = null, $comparison = null)
    {
        if (is_array($currencyValue)) {
            $useMinMax = false;
            if (isset($currencyValue['min'])) {
                $this->addUsingAlias(ItemPeer::CURRENCY_VALUE, $currencyValue['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($currencyValue['max'])) {
                $this->addUsingAlias(ItemPeer::CURRENCY_VALUE, $currencyValue['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ItemPeer::CURRENCY_VALUE, $currencyValue, $comparison);
    }

    /**
     * Filter the query on the discount_value column
     *
     * Example usage:
     * <code>
     * $query->filterByDiscountValue(1234); // WHERE discount_value = 1234
     * $query->filterByDiscountValue(array(12, 34)); // WHERE discount_value IN (12, 34)
     * $query->filterByDiscountValue(array('min' => 12)); // WHERE discount_value >= 12
     * $query->filterByDiscountValue(array('max' => 12)); // WHERE discount_value <= 12
     * </code>
     *
     * @param     mixed $discountValue The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByDiscountValue($discountValue = null, $comparison = null)
    {
        if (is_array($discountValue)) {
            $useMinMax = false;
            if (isset($discountValue['min'])) {
                $this->addUsingAlias(ItemPeer::DISCOUNT_VALUE, $discountValue['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($discountValue['max'])) {
                $this->addUsingAlias(ItemPeer::DISCOUNT_VALUE, $discountValue['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ItemPeer::DISCOUNT_VALUE, $discountValue, $comparison);
    }

    /**
     * Filter the query on the inventory_value column
     *
     * Example usage:
     * <code>
     * $query->filterByInventoryValue(1234); // WHERE inventory_value = 1234
     * $query->filterByInventoryValue(array(12, 34)); // WHERE inventory_value IN (12, 34)
     * $query->filterByInventoryValue(array('min' => 12)); // WHERE inventory_value >= 12
     * $query->filterByInventoryValue(array('max' => 12)); // WHERE inventory_value <= 12
     * </code>
     *
     * @param     mixed $inventoryValue The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByInventoryValue($inventoryValue = null, $comparison = null)
    {
        if (is_array($inventoryValue)) {
            $useMinMax = false;
            if (isset($inventoryValue['min'])) {
                $this->addUsingAlias(ItemPeer::INVENTORY_VALUE, $inventoryValue['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($inventoryValue['max'])) {
                $this->addUsingAlias(ItemPeer::INVENTORY_VALUE, $inventoryValue['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ItemPeer::INVENTORY_VALUE, $inventoryValue, $comparison);
    }

    /**
     * Filter the query on the issue_inventory_number column
     *
     * Example usage:
     * <code>
     * $query->filterByIssueInventoryNumber(1234); // WHERE issue_inventory_number = 1234
     * $query->filterByIssueInventoryNumber(array(12, 34)); // WHERE issue_inventory_number IN (12, 34)
     * $query->filterByIssueInventoryNumber(array('min' => 12)); // WHERE issue_inventory_number >= 12
     * $query->filterByIssueInventoryNumber(array('max' => 12)); // WHERE issue_inventory_number <= 12
     * </code>
     *
     * @param     mixed $issueInventoryNumber The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByIssueInventoryNumber($issueInventoryNumber = null, $comparison = null)
    {
        if (is_array($issueInventoryNumber)) {
            $useMinMax = false;
            if (isset($issueInventoryNumber['min'])) {
                $this->addUsingAlias(ItemPeer::ISSUE_INVENTORY_NUMBER, $issueInventoryNumber['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($issueInventoryNumber['max'])) {
                $this->addUsingAlias(ItemPeer::ISSUE_INVENTORY_NUMBER, $issueInventoryNumber['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ItemPeer::ISSUE_INVENTORY_NUMBER, $issueInventoryNumber, $comparison);
    }

    /**
     * Filter the query on the issue_id column
     *
     * Example usage:
     * <code>
     * $query->filterByIssueId(1234); // WHERE issue_id = 1234
     * $query->filterByIssueId(array(12, 34)); // WHERE issue_id IN (12, 34)
     * $query->filterByIssueId(array('min' => 12)); // WHERE issue_id >= 12
     * $query->filterByIssueId(array('max' => 12)); // WHERE issue_id <= 12
     * </code>
     *
     * @see       filterByIssue()
     *
     * @param     mixed $issueId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByIssueId($issueId = null, $comparison = null)
    {
        if (is_array($issueId)) {
            $useMinMax = false;
            if (isset($issueId['min'])) {
                $this->addUsingAlias(ItemPeer::ISSUE_ID, $issueId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($issueId['max'])) {
                $this->addUsingAlias(ItemPeer::ISSUE_ID, $issueId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ItemPeer::ISSUE_ID, $issueId, $comparison);
    }

    /**
     * Filter the query on the issue_year column
     *
     * Example usage:
     * <code>
     * $query->filterByIssueYear('fooValue');   // WHERE issue_year = 'fooValue'
     * $query->filterByIssueYear('%fooValue%'); // WHERE issue_year LIKE '%fooValue%'
     * </code>
     *
     * @param     string $issueYear The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByIssueYear($issueYear = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($issueYear)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $issueYear)) {
                $issueYear = str_replace('*', '%', $issueYear);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(ItemPeer::ISSUE_YEAR, $issueYear, $comparison);
    }

    /**
     * Filter the query on the issue_number column
     *
     * Example usage:
     * <code>
     * $query->filterByIssueNumber(1234); // WHERE issue_number = 1234
     * $query->filterByIssueNumber(array(12, 34)); // WHERE issue_number IN (12, 34)
     * $query->filterByIssueNumber(array('min' => 12)); // WHERE issue_number >= 12
     * $query->filterByIssueNumber(array('max' => 12)); // WHERE issue_number <= 12
     * </code>
     *
     * @param     mixed $issueNumber The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByIssueNumber($issueNumber = null, $comparison = null)
    {
        if (is_array($issueNumber)) {
            $useMinMax = false;
            if (isset($issueNumber['min'])) {
                $this->addUsingAlias(ItemPeer::ISSUE_NUMBER, $issueNumber['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($issueNumber['max'])) {
                $this->addUsingAlias(ItemPeer::ISSUE_NUMBER, $issueNumber['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ItemPeer::ISSUE_NUMBER, $issueNumber, $comparison);
    }

    /**
     * Filter the query on the issue_description column
     *
     * Example usage:
     * <code>
     * $query->filterByIssueDescription('fooValue');   // WHERE issue_description = 'fooValue'
     * $query->filterByIssueDescription('%fooValue%'); // WHERE issue_description LIKE '%fooValue%'
     * </code>
     *
     * @param     string $issueDescription The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByIssueDescription($issueDescription = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($issueDescription)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $issueDescription)) {
                $issueDescription = str_replace('*', '%', $issueDescription);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(ItemPeer::ISSUE_DESCRIPTION, $issueDescription, $comparison);
    }

    /**
     * Filter the query on the issue_arrival_date column
     *
     * Example usage:
     * <code>
     * $query->filterByIssueArrivalDate('2011-03-14'); // WHERE issue_arrival_date = '2011-03-14'
     * $query->filterByIssueArrivalDate('now'); // WHERE issue_arrival_date = '2011-03-14'
     * $query->filterByIssueArrivalDate(array('max' => 'yesterday')); // WHERE issue_arrival_date < '2011-03-13'
     * </code>
     *
     * @param     mixed $issueArrivalDate The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByIssueArrivalDate($issueArrivalDate = null, $comparison = null)
    {
        if (is_array($issueArrivalDate)) {
            $useMinMax = false;
            if (isset($issueArrivalDate['min'])) {
                $this->addUsingAlias(ItemPeer::ISSUE_ARRIVAL_DATE, $issueArrivalDate['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($issueArrivalDate['max'])) {
                $this->addUsingAlias(ItemPeer::ISSUE_ARRIVAL_DATE, $issueArrivalDate['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ItemPeer::ISSUE_ARRIVAL_DATE, $issueArrivalDate, $comparison);
    }

    /**
     * Filter the query on the issue_arrival_date_expected column
     *
     * Example usage:
     * <code>
     * $query->filterByIssueArrivalDateExpected('2011-03-14'); // WHERE issue_arrival_date_expected = '2011-03-14'
     * $query->filterByIssueArrivalDateExpected('now'); // WHERE issue_arrival_date_expected = '2011-03-14'
     * $query->filterByIssueArrivalDateExpected(array('max' => 'yesterday')); // WHERE issue_arrival_date_expected < '2011-03-13'
     * </code>
     *
     * @param     mixed $issueArrivalDateExpected The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByIssueArrivalDateExpected($issueArrivalDateExpected = null, $comparison = null)
    {
        if (is_array($issueArrivalDateExpected)) {
            $useMinMax = false;
            if (isset($issueArrivalDateExpected['min'])) {
                $this->addUsingAlias(ItemPeer::ISSUE_ARRIVAL_DATE_EXPECTED, $issueArrivalDateExpected['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($issueArrivalDateExpected['max'])) {
                $this->addUsingAlias(ItemPeer::ISSUE_ARRIVAL_DATE_EXPECTED, $issueArrivalDateExpected['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ItemPeer::ISSUE_ARRIVAL_DATE_EXPECTED, $issueArrivalDateExpected, $comparison);
    }

    /**
     * Filter the query on the issue_status column
     *
     * Example usage:
     * <code>
     * $query->filterByIssueStatus('fooValue');   // WHERE issue_status = 'fooValue'
     * $query->filterByIssueStatus('%fooValue%'); // WHERE issue_status LIKE '%fooValue%'
     * </code>
     *
     * @param     string $issueStatus The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByIssueStatus($issueStatus = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($issueStatus)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $issueStatus)) {
                $issueStatus = str_replace('*', '%', $issueStatus);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(ItemPeer::ISSUE_STATUS, $issueStatus, $comparison);
    }

    /**
     * Filter the query on the subscription_id column
     *
     * Example usage:
     * <code>
     * $query->filterBySubscriptionId(1234); // WHERE subscription_id = 1234
     * $query->filterBySubscriptionId(array(12, 34)); // WHERE subscription_id IN (12, 34)
     * $query->filterBySubscriptionId(array('min' => 12)); // WHERE subscription_id >= 12
     * $query->filterBySubscriptionId(array('max' => 12)); // WHERE subscription_id <= 12
     * </code>
     *
     * @param     mixed $subscriptionId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterBySubscriptionId($subscriptionId = null, $comparison = null)
    {
        if (is_array($subscriptionId)) {
            $useMinMax = false;
            if (isset($subscriptionId['min'])) {
                $this->addUsingAlias(ItemPeer::SUBSCRIPTION_ID, $subscriptionId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($subscriptionId['max'])) {
                $this->addUsingAlias(ItemPeer::SUBSCRIPTION_ID, $subscriptionId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ItemPeer::SUBSCRIPTION_ID, $subscriptionId, $comparison);
    }

    /**
     * Filter the query on the consistency_note_id column
     *
     * Example usage:
     * <code>
     * $query->filterByConsistencyNoteId(1234); // WHERE consistency_note_id = 1234
     * $query->filterByConsistencyNoteId(array(12, 34)); // WHERE consistency_note_id IN (12, 34)
     * $query->filterByConsistencyNoteId(array('min' => 12)); // WHERE consistency_note_id >= 12
     * $query->filterByConsistencyNoteId(array('max' => 12)); // WHERE consistency_note_id <= 12
     * </code>
     *
     * @see       filterByConsistencyNote()
     *
     * @param     mixed $consistencyNoteId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByConsistencyNoteId($consistencyNoteId = null, $comparison = null)
    {
        if (is_array($consistencyNoteId)) {
            $useMinMax = false;
            if (isset($consistencyNoteId['min'])) {
                $this->addUsingAlias(ItemPeer::CONSISTENCY_NOTE_ID, $consistencyNoteId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($consistencyNoteId['max'])) {
                $this->addUsingAlias(ItemPeer::CONSISTENCY_NOTE_ID, $consistencyNoteId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ItemPeer::CONSISTENCY_NOTE_ID, $consistencyNoteId, $comparison);
    }

    /**
     * Filter the query on the actual_library_id column
     *
     * Example usage:
     * <code>
     * $query->filterByActualLibraryId(1234); // WHERE actual_library_id = 1234
     * $query->filterByActualLibraryId(array(12, 34)); // WHERE actual_library_id IN (12, 34)
     * $query->filterByActualLibraryId(array('min' => 12)); // WHERE actual_library_id >= 12
     * $query->filterByActualLibraryId(array('max' => 12)); // WHERE actual_library_id <= 12
     * </code>
     *
     * @see       filterByLibraryRelatedByActualLibraryId()
     *
     * @param     mixed $actualLibraryId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByActualLibraryId($actualLibraryId = null, $comparison = null)
    {
        if (is_array($actualLibraryId)) {
            $useMinMax = false;
            if (isset($actualLibraryId['min'])) {
                $this->addUsingAlias(ItemPeer::ACTUAL_LIBRARY_ID, $actualLibraryId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($actualLibraryId['max'])) {
                $this->addUsingAlias(ItemPeer::ACTUAL_LIBRARY_ID, $actualLibraryId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ItemPeer::ACTUAL_LIBRARY_ID, $actualLibraryId, $comparison);
    }

    /**
     * Filter the query on the barcode column
     *
     * Example usage:
     * <code>
     * $query->filterByBarcode('fooValue');   // WHERE barcode = 'fooValue'
     * $query->filterByBarcode('%fooValue%'); // WHERE barcode LIKE '%fooValue%'
     * </code>
     *
     * @param     string $barcode The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByBarcode($barcode = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($barcode)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $barcode)) {
                $barcode = str_replace('*', '%', $barcode);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(ItemPeer::BARCODE, $barcode, $comparison);
    }

    /**
     * Filter the query on the rfid_code column
     *
     * Example usage:
     * <code>
     * $query->filterByRfidCode('fooValue');   // WHERE rfid_code = 'fooValue'
     * $query->filterByRfidCode('%fooValue%'); // WHERE rfid_code LIKE '%fooValue%'
     * </code>
     *
     * @param     string $rfidCode The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByRfidCode($rfidCode = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($rfidCode)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $rfidCode)) {
                $rfidCode = str_replace('*', '%', $rfidCode);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(ItemPeer::RFID_CODE, $rfidCode, $comparison);
    }

    /**
     * Filter the query on the custom_field1 column
     *
     * Example usage:
     * <code>
     * $query->filterByCustomField1('fooValue');   // WHERE custom_field1 = 'fooValue'
     * $query->filterByCustomField1('%fooValue%'); // WHERE custom_field1 LIKE '%fooValue%'
     * </code>
     *
     * @param     string $customField1 The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByCustomField1($customField1 = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($customField1)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $customField1)) {
                $customField1 = str_replace('*', '%', $customField1);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(ItemPeer::CUSTOM_FIELD1, $customField1, $comparison);
    }

    /**
     * Filter the query on the custom_field2 column
     *
     * Example usage:
     * <code>
     * $query->filterByCustomField2('fooValue');   // WHERE custom_field2 = 'fooValue'
     * $query->filterByCustomField2('%fooValue%'); // WHERE custom_field2 LIKE '%fooValue%'
     * </code>
     *
     * @param     string $customField2 The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByCustomField2($customField2 = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($customField2)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $customField2)) {
                $customField2 = str_replace('*', '%', $customField2);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(ItemPeer::CUSTOM_FIELD2, $customField2, $comparison);
    }

    /**
     * Filter the query on the custom_field3 column
     *
     * Example usage:
     * <code>
     * $query->filterByCustomField3('fooValue');   // WHERE custom_field3 = 'fooValue'
     * $query->filterByCustomField3('%fooValue%'); // WHERE custom_field3 LIKE '%fooValue%'
     * </code>
     *
     * @param     string $customField3 The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByCustomField3($customField3 = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($customField3)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $customField3)) {
                $customField3 = str_replace('*', '%', $customField3);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(ItemPeer::CUSTOM_FIELD3, $customField3, $comparison);
    }

    /**
     * Filter the query on the unimarc column
     *
     * Example usage:
     * <code>
     * $query->filterByUnimarc('fooValue');   // WHERE unimarc = 'fooValue'
     * $query->filterByUnimarc('%fooValue%'); // WHERE unimarc LIKE '%fooValue%'
     * </code>
     *
     * @param     string $unimarc The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByUnimarc($unimarc = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($unimarc)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $unimarc)) {
                $unimarc = str_replace('*', '%', $unimarc);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(ItemPeer::UNIMARC, $unimarc, $comparison);
    }

    /**
     * Filter the query on the last_sbn_sync column
     *
     * Example usage:
     * <code>
     * $query->filterByLastSbnSync('2011-03-14'); // WHERE last_sbn_sync = '2011-03-14'
     * $query->filterByLastSbnSync('now'); // WHERE last_sbn_sync = '2011-03-14'
     * $query->filterByLastSbnSync(array('max' => 'yesterday')); // WHERE last_sbn_sync < '2011-03-13'
     * </code>
     *
     * @param     mixed $lastSbnSync The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByLastSbnSync($lastSbnSync = null, $comparison = null)
    {
        if (is_array($lastSbnSync)) {
            $useMinMax = false;
            if (isset($lastSbnSync['min'])) {
                $this->addUsingAlias(ItemPeer::LAST_SBN_SYNC, $lastSbnSync['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($lastSbnSync['max'])) {
                $this->addUsingAlias(ItemPeer::LAST_SBN_SYNC, $lastSbnSync['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ItemPeer::LAST_SBN_SYNC, $lastSbnSync, $comparison);
    }

    /**
     * Filter the query on the date_discarded column
     *
     * Example usage:
     * <code>
     * $query->filterByDateDiscarded('2011-03-14'); // WHERE date_discarded = '2011-03-14'
     * $query->filterByDateDiscarded('now'); // WHERE date_discarded = '2011-03-14'
     * $query->filterByDateDiscarded(array('max' => 'yesterday')); // WHERE date_discarded < '2011-03-13'
     * </code>
     *
     * @param     mixed $dateDiscarded The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByDateDiscarded($dateDiscarded = null, $comparison = null)
    {
        if (is_array($dateDiscarded)) {
            $useMinMax = false;
            if (isset($dateDiscarded['min'])) {
                $this->addUsingAlias(ItemPeer::DATE_DISCARDED, $dateDiscarded['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dateDiscarded['max'])) {
                $this->addUsingAlias(ItemPeer::DATE_DISCARDED, $dateDiscarded['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ItemPeer::DATE_DISCARDED, $dateDiscarded, $comparison);
    }

    /**
     * Filter the query on the discard_note column
     *
     * Example usage:
     * <code>
     * $query->filterByDiscardNote('fooValue');   // WHERE discard_note = 'fooValue'
     * $query->filterByDiscardNote('%fooValue%'); // WHERE discard_note LIKE '%fooValue%'
     * </code>
     *
     * @param     string $discardNote The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByDiscardNote($discardNote = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($discardNote)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $discardNote)) {
                $discardNote = str_replace('*', '%', $discardNote);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(ItemPeer::DISCARD_NOTE, $discardNote, $comparison);
    }

    /**
     * Filter the query on the date_created column
     *
     * Example usage:
     * <code>
     * $query->filterByDateCreated('2011-03-14'); // WHERE date_created = '2011-03-14'
     * $query->filterByDateCreated('now'); // WHERE date_created = '2011-03-14'
     * $query->filterByDateCreated(array('max' => 'yesterday')); // WHERE date_created < '2011-03-13'
     * </code>
     *
     * @param     mixed $dateCreated The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByDateCreated($dateCreated = null, $comparison = null)
    {
        if (is_array($dateCreated)) {
            $useMinMax = false;
            if (isset($dateCreated['min'])) {
                $this->addUsingAlias(ItemPeer::DATE_CREATED, $dateCreated['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dateCreated['max'])) {
                $this->addUsingAlias(ItemPeer::DATE_CREATED, $dateCreated['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ItemPeer::DATE_CREATED, $dateCreated, $comparison);
    }

    /**
     * Filter the query on the date_updated column
     *
     * Example usage:
     * <code>
     * $query->filterByDateUpdated('2011-03-14'); // WHERE date_updated = '2011-03-14'
     * $query->filterByDateUpdated('now'); // WHERE date_updated = '2011-03-14'
     * $query->filterByDateUpdated(array('max' => 'yesterday')); // WHERE date_updated < '2011-03-13'
     * </code>
     *
     * @param     mixed $dateUpdated The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByDateUpdated($dateUpdated = null, $comparison = null)
    {
        if (is_array($dateUpdated)) {
            $useMinMax = false;
            if (isset($dateUpdated['min'])) {
                $this->addUsingAlias(ItemPeer::DATE_UPDATED, $dateUpdated['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dateUpdated['max'])) {
                $this->addUsingAlias(ItemPeer::DATE_UPDATED, $dateUpdated['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ItemPeer::DATE_UPDATED, $dateUpdated, $comparison);
    }

    /**
     * Filter the query on the created_by column
     *
     * Example usage:
     * <code>
     * $query->filterByCreatedBy(1234); // WHERE created_by = 1234
     * $query->filterByCreatedBy(array(12, 34)); // WHERE created_by IN (12, 34)
     * $query->filterByCreatedBy(array('min' => 12)); // WHERE created_by >= 12
     * $query->filterByCreatedBy(array('max' => 12)); // WHERE created_by <= 12
     * </code>
     *
     * @see       filterByLibrarianRelatedByCreatedBy()
     *
     * @param     mixed $createdBy The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByCreatedBy($createdBy = null, $comparison = null)
    {
        if (is_array($createdBy)) {
            $useMinMax = false;
            if (isset($createdBy['min'])) {
                $this->addUsingAlias(ItemPeer::CREATED_BY, $createdBy['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($createdBy['max'])) {
                $this->addUsingAlias(ItemPeer::CREATED_BY, $createdBy['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ItemPeer::CREATED_BY, $createdBy, $comparison);
    }

    /**
     * Filter the query on the modified_by column
     *
     * Example usage:
     * <code>
     * $query->filterByModifiedBy(1234); // WHERE modified_by = 1234
     * $query->filterByModifiedBy(array(12, 34)); // WHERE modified_by IN (12, 34)
     * $query->filterByModifiedBy(array('min' => 12)); // WHERE modified_by >= 12
     * $query->filterByModifiedBy(array('max' => 12)); // WHERE modified_by <= 12
     * </code>
     *
     * @see       filterByLibrarianRelatedByModifiedBy()
     *
     * @param     mixed $modifiedBy The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function filterByModifiedBy($modifiedBy = null, $comparison = null)
    {
        if (is_array($modifiedBy)) {
            $useMinMax = false;
            if (isset($modifiedBy['min'])) {
                $this->addUsingAlias(ItemPeer::MODIFIED_BY, $modifiedBy['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($modifiedBy['max'])) {
                $this->addUsingAlias(ItemPeer::MODIFIED_BY, $modifiedBy['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ItemPeer::MODIFIED_BY, $modifiedBy, $comparison);
    }

    /**
     * Filter the query by a related Librarian object
     *
     * @param   Librarian|PropelObjectCollection $librarian The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 ItemQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByLibrarianRelatedByCreatedBy($librarian, $comparison = null)
    {
        if ($librarian instanceof Librarian) {
            return $this
                ->addUsingAlias(ItemPeer::CREATED_BY, $librarian->getLibrarianId(), $comparison);
        } elseif ($librarian instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(ItemPeer::CREATED_BY, $librarian->toKeyValue('PrimaryKey', 'LibrarianId'), $comparison);
        } else {
            throw new PropelException('filterByLibrarianRelatedByCreatedBy() only accepts arguments of type Librarian or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the LibrarianRelatedByCreatedBy relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function joinLibrarianRelatedByCreatedBy($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('LibrarianRelatedByCreatedBy');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'LibrarianRelatedByCreatedBy');
        }

        return $this;
    }

    /**
     * Use the LibrarianRelatedByCreatedBy relation Librarian object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   LibrarianQuery A secondary query class using the current class as primary query
     */
    public function useLibrarianRelatedByCreatedByQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinLibrarianRelatedByCreatedBy($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'LibrarianRelatedByCreatedBy', 'LibrarianQuery');
    }

    /**
     * Filter the query by a related Librarian object
     *
     * @param   Librarian|PropelObjectCollection $librarian The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 ItemQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByLibrarianRelatedByModifiedBy($librarian, $comparison = null)
    {
        if ($librarian instanceof Librarian) {
            return $this
                ->addUsingAlias(ItemPeer::MODIFIED_BY, $librarian->getLibrarianId(), $comparison);
        } elseif ($librarian instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(ItemPeer::MODIFIED_BY, $librarian->toKeyValue('PrimaryKey', 'LibrarianId'), $comparison);
        } else {
            throw new PropelException('filterByLibrarianRelatedByModifiedBy() only accepts arguments of type Librarian or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the LibrarianRelatedByModifiedBy relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function joinLibrarianRelatedByModifiedBy($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('LibrarianRelatedByModifiedBy');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'LibrarianRelatedByModifiedBy');
        }

        return $this;
    }

    /**
     * Use the LibrarianRelatedByModifiedBy relation Librarian object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   LibrarianQuery A secondary query class using the current class as primary query
     */
    public function useLibrarianRelatedByModifiedByQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinLibrarianRelatedByModifiedBy($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'LibrarianRelatedByModifiedBy', 'LibrarianQuery');
    }

    /**
     * Filter the query by a related Issue object
     *
     * @param   Issue|PropelObjectCollection $issue The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 ItemQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByIssue($issue, $comparison = null)
    {
        if ($issue instanceof Issue) {
            return $this
                ->addUsingAlias(ItemPeer::ISSUE_ID, $issue->getIssueId(), $comparison);
        } elseif ($issue instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(ItemPeer::ISSUE_ID, $issue->toKeyValue('PrimaryKey', 'IssueId'), $comparison);
        } else {
            throw new PropelException('filterByIssue() only accepts arguments of type Issue or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the Issue relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function joinIssue($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('Issue');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'Issue');
        }

        return $this;
    }

    /**
     * Use the Issue relation Issue object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   IssueQuery A secondary query class using the current class as primary query
     */
    public function useIssueQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinIssue($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'Issue', 'IssueQuery');
    }

    /**
     * Filter the query by a related Manifestation object
     *
     * @param   Manifestation|PropelObjectCollection $manifestation The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 ItemQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByManifestation($manifestation, $comparison = null)
    {
        if ($manifestation instanceof Manifestation) {
            return $this
                ->addUsingAlias(ItemPeer::MANIFESTATION_ID, $manifestation->getManifestationId(), $comparison);
        } elseif ($manifestation instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(ItemPeer::MANIFESTATION_ID, $manifestation->toKeyValue('PrimaryKey', 'ManifestationId'), $comparison);
        } else {
            throw new PropelException('filterByManifestation() only accepts arguments of type Manifestation or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the Manifestation relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function joinManifestation($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('Manifestation');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'Manifestation');
        }

        return $this;
    }

    /**
     * Use the Manifestation relation Manifestation object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   ManifestationQuery A secondary query class using the current class as primary query
     */
    public function useManifestationQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinManifestation($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'Manifestation', 'ManifestationQuery');
    }

    /**
     * Filter the query by a related ConsistencyNote object
     *
     * @param   ConsistencyNote|PropelObjectCollection $consistencyNote The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 ItemQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByConsistencyNote($consistencyNote, $comparison = null)
    {
        if ($consistencyNote instanceof ConsistencyNote) {
            return $this
                ->addUsingAlias(ItemPeer::CONSISTENCY_NOTE_ID, $consistencyNote->getConsistencyNoteId(), $comparison);
        } elseif ($consistencyNote instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(ItemPeer::CONSISTENCY_NOTE_ID, $consistencyNote->toKeyValue('PrimaryKey', 'ConsistencyNoteId'), $comparison);
        } else {
            throw new PropelException('filterByConsistencyNote() only accepts arguments of type ConsistencyNote or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the ConsistencyNote relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function joinConsistencyNote($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('ConsistencyNote');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'ConsistencyNote');
        }

        return $this;
    }

    /**
     * Use the ConsistencyNote relation ConsistencyNote object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   ConsistencyNoteQuery A secondary query class using the current class as primary query
     */
    public function useConsistencyNoteQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinConsistencyNote($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'ConsistencyNote', 'ConsistencyNoteQuery');
    }

    /**
     * Filter the query by a related Library object
     *
     * @param   Library|PropelObjectCollection $library The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 ItemQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByLibraryRelatedByOwnerLibraryId($library, $comparison = null)
    {
        if ($library instanceof Library) {
            return $this
                ->addUsingAlias(ItemPeer::OWNER_LIBRARY_ID, $library->getLibraryId(), $comparison);
        } elseif ($library instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(ItemPeer::OWNER_LIBRARY_ID, $library->toKeyValue('PrimaryKey', 'LibraryId'), $comparison);
        } else {
            throw new PropelException('filterByLibraryRelatedByOwnerLibraryId() only accepts arguments of type Library or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the LibraryRelatedByOwnerLibraryId relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function joinLibraryRelatedByOwnerLibraryId($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('LibraryRelatedByOwnerLibraryId');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'LibraryRelatedByOwnerLibraryId');
        }

        return $this;
    }

    /**
     * Use the LibraryRelatedByOwnerLibraryId relation Library object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   LibraryQuery A secondary query class using the current class as primary query
     */
    public function useLibraryRelatedByOwnerLibraryIdQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinLibraryRelatedByOwnerLibraryId($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'LibraryRelatedByOwnerLibraryId', 'LibraryQuery');
    }

    /**
     * Filter the query by a related Library object
     *
     * @param   Library|PropelObjectCollection $library The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 ItemQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByLibraryRelatedByHomeLibraryId($library, $comparison = null)
    {
        if ($library instanceof Library) {
            return $this
                ->addUsingAlias(ItemPeer::HOME_LIBRARY_ID, $library->getLibraryId(), $comparison);
        } elseif ($library instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(ItemPeer::HOME_LIBRARY_ID, $library->toKeyValue('PrimaryKey', 'LibraryId'), $comparison);
        } else {
            throw new PropelException('filterByLibraryRelatedByHomeLibraryId() only accepts arguments of type Library or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the LibraryRelatedByHomeLibraryId relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function joinLibraryRelatedByHomeLibraryId($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('LibraryRelatedByHomeLibraryId');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'LibraryRelatedByHomeLibraryId');
        }

        return $this;
    }

    /**
     * Use the LibraryRelatedByHomeLibraryId relation Library object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   LibraryQuery A secondary query class using the current class as primary query
     */
    public function useLibraryRelatedByHomeLibraryIdQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinLibraryRelatedByHomeLibraryId($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'LibraryRelatedByHomeLibraryId', 'LibraryQuery');
    }

    /**
     * Filter the query by a related Library object
     *
     * @param   Library|PropelObjectCollection $library The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 ItemQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByLibraryRelatedByDeliveryLibraryId($library, $comparison = null)
    {
        if ($library instanceof Library) {
            return $this
                ->addUsingAlias(ItemPeer::DELIVERY_LIBRARY_ID, $library->getLibraryId(), $comparison);
        } elseif ($library instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(ItemPeer::DELIVERY_LIBRARY_ID, $library->toKeyValue('PrimaryKey', 'LibraryId'), $comparison);
        } else {
            throw new PropelException('filterByLibraryRelatedByDeliveryLibraryId() only accepts arguments of type Library or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the LibraryRelatedByDeliveryLibraryId relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function joinLibraryRelatedByDeliveryLibraryId($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('LibraryRelatedByDeliveryLibraryId');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'LibraryRelatedByDeliveryLibraryId');
        }

        return $this;
    }

    /**
     * Use the LibraryRelatedByDeliveryLibraryId relation Library object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   LibraryQuery A secondary query class using the current class as primary query
     */
    public function useLibraryRelatedByDeliveryLibraryIdQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinLibraryRelatedByDeliveryLibraryId($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'LibraryRelatedByDeliveryLibraryId', 'LibraryQuery');
    }

    /**
     * Filter the query by a related Library object
     *
     * @param   Library|PropelObjectCollection $library The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 ItemQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByLibraryRelatedByActualLibraryId($library, $comparison = null)
    {
        if ($library instanceof Library) {
            return $this
                ->addUsingAlias(ItemPeer::ACTUAL_LIBRARY_ID, $library->getLibraryId(), $comparison);
        } elseif ($library instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(ItemPeer::ACTUAL_LIBRARY_ID, $library->toKeyValue('PrimaryKey', 'LibraryId'), $comparison);
        } else {
            throw new PropelException('filterByLibraryRelatedByActualLibraryId() only accepts arguments of type Library or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the LibraryRelatedByActualLibraryId relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function joinLibraryRelatedByActualLibraryId($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('LibraryRelatedByActualLibraryId');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'LibraryRelatedByActualLibraryId');
        }

        return $this;
    }

    /**
     * Use the LibraryRelatedByActualLibraryId relation Library object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   LibraryQuery A secondary query class using the current class as primary query
     */
    public function useLibraryRelatedByActualLibraryIdQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinLibraryRelatedByActualLibraryId($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'LibraryRelatedByActualLibraryId', 'LibraryQuery');
    }

    /**
     * Filter the query by a related InventorySerie object
     *
     * @param   InventorySerie|PropelObjectCollection $inventorySerie The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 ItemQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByInventorySerie($inventorySerie, $comparison = null)
    {
        if ($inventorySerie instanceof InventorySerie) {
            return $this
                ->addUsingAlias(ItemPeer::INVENTORY_SERIE_ID, $inventorySerie->getInventorySerieId(), $comparison);
        } elseif ($inventorySerie instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(ItemPeer::INVENTORY_SERIE_ID, $inventorySerie->toKeyValue('InventorySerieId', 'InventorySerieId'), $comparison);
        } else {
            throw new PropelException('filterByInventorySerie() only accepts arguments of type InventorySerie or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the InventorySerie relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function joinInventorySerie($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('InventorySerie');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'InventorySerie');
        }

        return $this;
    }

    /**
     * Use the InventorySerie relation InventorySerie object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   InventorySerieQuery A secondary query class using the current class as primary query
     */
    public function useInventorySerieQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinInventorySerie($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'InventorySerie', 'InventorySerieQuery');
    }

    /**
     * Filter the query by a related PurchaseOrder object
     *
     * @param   PurchaseOrder|PropelObjectCollection $purchaseOrder The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 ItemQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByPurchaseOrder($purchaseOrder, $comparison = null)
    {
        if ($purchaseOrder instanceof PurchaseOrder) {
            return $this
                ->addUsingAlias(ItemPeer::ORDER_ID, $purchaseOrder->getOrderId(), $comparison);
        } elseif ($purchaseOrder instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(ItemPeer::ORDER_ID, $purchaseOrder->toKeyValue('PrimaryKey', 'OrderId'), $comparison);
        } else {
            throw new PropelException('filterByPurchaseOrder() only accepts arguments of type PurchaseOrder or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the PurchaseOrder relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function joinPurchaseOrder($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('PurchaseOrder');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'PurchaseOrder');
        }

        return $this;
    }

    /**
     * Use the PurchaseOrder relation PurchaseOrder object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   PurchaseOrderQuery A secondary query class using the current class as primary query
     */
    public function usePurchaseOrderQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinPurchaseOrder($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'PurchaseOrder', 'PurchaseOrderQuery');
    }

    /**
     * Filter the query by a related Invoice object
     *
     * @param   Invoice|PropelObjectCollection $invoice The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 ItemQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByInvoice($invoice, $comparison = null)
    {
        if ($invoice instanceof Invoice) {
            return $this
                ->addUsingAlias(ItemPeer::INVOICE_ID, $invoice->getInvoiceId(), $comparison);
        } elseif ($invoice instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(ItemPeer::INVOICE_ID, $invoice->toKeyValue('PrimaryKey', 'InvoiceId'), $comparison);
        } else {
            throw new PropelException('filterByInvoice() only accepts arguments of type Invoice or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the Invoice relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function joinInvoice($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('Invoice');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'Invoice');
        }

        return $this;
    }

    /**
     * Use the Invoice relation Invoice object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   InvoiceQuery A secondary query class using the current class as primary query
     */
    public function useInvoiceQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinInvoice($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'Invoice', 'InvoiceQuery');
    }

    /**
     * Filter the query by a related Supplier object
     *
     * @param   Supplier|PropelObjectCollection $supplier The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 ItemQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterBySupplier($supplier, $comparison = null)
    {
        if ($supplier instanceof Supplier) {
            return $this
                ->addUsingAlias(ItemPeer::SUPPLIER_ID, $supplier->getSupplierId(), $comparison);
        } elseif ($supplier instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(ItemPeer::SUPPLIER_ID, $supplier->toKeyValue('PrimaryKey', 'SupplierId'), $comparison);
        } else {
            throw new PropelException('filterBySupplier() only accepts arguments of type Supplier or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the Supplier relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function joinSupplier($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('Supplier');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'Supplier');
        }

        return $this;
    }

    /**
     * Use the Supplier relation Supplier object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   SupplierQuery A secondary query class using the current class as primary query
     */
    public function useSupplierQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinSupplier($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'Supplier', 'SupplierQuery');
    }

    /**
     * Filter the query by a related Patron object
     *
     * @param   Patron|PropelObjectCollection $patron The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 ItemQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByPatron($patron, $comparison = null)
    {
        if ($patron instanceof Patron) {
            return $this
                ->addUsingAlias(ItemPeer::PATRON_ID, $patron->getPatronId(), $comparison);
        } elseif ($patron instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(ItemPeer::PATRON_ID, $patron->toKeyValue('PrimaryKey', 'PatronId'), $comparison);
        } else {
            throw new PropelException('filterByPatron() only accepts arguments of type Patron or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the Patron relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function joinPatron($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('Patron');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'Patron');
        }

        return $this;
    }

    /**
     * Use the Patron relation Patron object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   PatronQuery A secondary query class using the current class as primary query
     */
    public function usePatronQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinPatron($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'Patron', 'PatronQuery');
    }

    /**
     * Filter the query by a related Library object
     *
     * @param   Library|PropelObjectCollection $library The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 ItemQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByLibraryRelatedByExternalLibraryId($library, $comparison = null)
    {
        if ($library instanceof Library) {
            return $this
                ->addUsingAlias(ItemPeer::EXTERNAL_LIBRARY_ID, $library->getLibraryId(), $comparison);
        } elseif ($library instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(ItemPeer::EXTERNAL_LIBRARY_ID, $library->toKeyValue('PrimaryKey', 'LibraryId'), $comparison);
        } else {
            throw new PropelException('filterByLibraryRelatedByExternalLibraryId() only accepts arguments of type Library or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the LibraryRelatedByExternalLibraryId relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function joinLibraryRelatedByExternalLibraryId($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('LibraryRelatedByExternalLibraryId');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'LibraryRelatedByExternalLibraryId');
        }

        return $this;
    }

    /**
     * Use the LibraryRelatedByExternalLibraryId relation Library object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   LibraryQuery A secondary query class using the current class as primary query
     */
    public function useLibraryRelatedByExternalLibraryIdQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinLibraryRelatedByExternalLibraryId($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'LibraryRelatedByExternalLibraryId', 'LibraryQuery');
    }

    /**
     * Filter the query by a related Loan object
     *
     * @param   Loan|PropelObjectCollection $loan The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 ItemQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByLoanRelatedByCurrentLoanId($loan, $comparison = null)
    {
        if ($loan instanceof Loan) {
            return $this
                ->addUsingAlias(ItemPeer::CURRENT_LOAN_ID, $loan->getLoanId(), $comparison);
        } elseif ($loan instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(ItemPeer::CURRENT_LOAN_ID, $loan->toKeyValue('PrimaryKey', 'LoanId'), $comparison);
        } else {
            throw new PropelException('filterByLoanRelatedByCurrentLoanId() only accepts arguments of type Loan or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the LoanRelatedByCurrentLoanId relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function joinLoanRelatedByCurrentLoanId($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('LoanRelatedByCurrentLoanId');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'LoanRelatedByCurrentLoanId');
        }

        return $this;
    }

    /**
     * Use the LoanRelatedByCurrentLoanId relation Loan object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   LoanQuery A secondary query class using the current class as primary query
     */
    public function useLoanRelatedByCurrentLoanIdQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinLoanRelatedByCurrentLoanId($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'LoanRelatedByCurrentLoanId', 'LoanQuery');
    }

    /**
     * Filter the query by a related Budget object
     *
     * @param   Budget|PropelObjectCollection $budget The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 ItemQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByBudget($budget, $comparison = null)
    {
        if ($budget instanceof Budget) {
            return $this
                ->addUsingAlias(ItemPeer::BUDGET_ID, $budget->getBudgetId(), $comparison);
        } elseif ($budget instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(ItemPeer::BUDGET_ID, $budget->toKeyValue('PrimaryKey', 'BudgetId'), $comparison);
        } else {
            throw new PropelException('filterByBudget() only accepts arguments of type Budget or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the Budget relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function joinBudget($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('Budget');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'Budget');
        }

        return $this;
    }

    /**
     * Use the Budget relation Budget object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   BudgetQuery A secondary query class using the current class as primary query
     */
    public function useBudgetQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinBudget($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'Budget', 'BudgetQuery');
    }

    /**
     * Filter the query by a related ItemAction object
     *
     * @param   ItemAction|PropelObjectCollection $itemAction  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 ItemQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByItemAction($itemAction, $comparison = null)
    {
        if ($itemAction instanceof ItemAction) {
            return $this
                ->addUsingAlias(ItemPeer::ITEM_ID, $itemAction->getItemId(), $comparison);
        } elseif ($itemAction instanceof PropelObjectCollection) {
            return $this
                ->useItemActionQuery()
                ->filterByPrimaryKeys($itemAction->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByItemAction() only accepts arguments of type ItemAction or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the ItemAction relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function joinItemAction($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('ItemAction');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'ItemAction');
        }

        return $this;
    }

    /**
     * Use the ItemAction relation ItemAction object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   ItemActionQuery A secondary query class using the current class as primary query
     */
    public function useItemActionQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinItemAction($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'ItemAction', 'ItemActionQuery');
    }

    /**
     * Filter the query by a related ItemNote object
     *
     * @param   ItemNote|PropelObjectCollection $itemNote  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 ItemQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByItemNote($itemNote, $comparison = null)
    {
        if ($itemNote instanceof ItemNote) {
            return $this
                ->addUsingAlias(ItemPeer::ITEM_ID, $itemNote->getItemId(), $comparison);
        } elseif ($itemNote instanceof PropelObjectCollection) {
            return $this
                ->useItemNoteQuery()
                ->filterByPrimaryKeys($itemNote->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByItemNote() only accepts arguments of type ItemNote or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the ItemNote relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function joinItemNote($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('ItemNote');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'ItemNote');
        }

        return $this;
    }

    /**
     * Use the ItemNote relation ItemNote object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   ItemNoteQuery A secondary query class using the current class as primary query
     */
    public function useItemNoteQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinItemNote($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'ItemNote', 'ItemNoteQuery');
    }

    /**
     * Filter the query by a related ItemRequest object
     *
     * @param   ItemRequest|PropelObjectCollection $itemRequest  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 ItemQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByItemRequest($itemRequest, $comparison = null)
    {
        if ($itemRequest instanceof ItemRequest) {
            return $this
                ->addUsingAlias(ItemPeer::ITEM_ID, $itemRequest->getItemId(), $comparison);
        } elseif ($itemRequest instanceof PropelObjectCollection) {
            return $this
                ->useItemRequestQuery()
                ->filterByPrimaryKeys($itemRequest->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByItemRequest() only accepts arguments of type ItemRequest or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the ItemRequest relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function joinItemRequest($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('ItemRequest');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'ItemRequest');
        }

        return $this;
    }

    /**
     * Use the ItemRequest relation ItemRequest object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   ItemRequestQuery A secondary query class using the current class as primary query
     */
    public function useItemRequestQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinItemRequest($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'ItemRequest', 'ItemRequestQuery');
    }

    /**
     * Filter the query by a related Loan object
     *
     * @param   Loan|PropelObjectCollection $loan  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 ItemQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByLoanRelatedByItemId($loan, $comparison = null)
    {
        if ($loan instanceof Loan) {
            return $this
                ->addUsingAlias(ItemPeer::ITEM_ID, $loan->getItemId(), $comparison);
        } elseif ($loan instanceof PropelObjectCollection) {
            return $this
                ->useLoanRelatedByItemIdQuery()
                ->filterByPrimaryKeys($loan->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByLoanRelatedByItemId() only accepts arguments of type Loan or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the LoanRelatedByItemId relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function joinLoanRelatedByItemId($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('LoanRelatedByItemId');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'LoanRelatedByItemId');
        }

        return $this;
    }

    /**
     * Use the LoanRelatedByItemId relation Loan object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   LoanQuery A secondary query class using the current class as primary query
     */
    public function useLoanRelatedByItemIdQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinLoanRelatedByItemId($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'LoanRelatedByItemId', 'LoanQuery');
    }

    /**
     * Filter the query by a related LAuthorityItem object
     *
     * @param   LAuthorityItem|PropelObjectCollection $lAuthorityItem  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 ItemQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByLAuthorityItem($lAuthorityItem, $comparison = null)
    {
        if ($lAuthorityItem instanceof LAuthorityItem) {
            return $this
                ->addUsingAlias(ItemPeer::ITEM_ID, $lAuthorityItem->getItemId(), $comparison);
        } elseif ($lAuthorityItem instanceof PropelObjectCollection) {
            return $this
                ->useLAuthorityItemQuery()
                ->filterByPrimaryKeys($lAuthorityItem->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByLAuthorityItem() only accepts arguments of type LAuthorityItem or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the LAuthorityItem relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function joinLAuthorityItem($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('LAuthorityItem');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'LAuthorityItem');
        }

        return $this;
    }

    /**
     * Use the LAuthorityItem relation LAuthorityItem object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   LAuthorityItemQuery A secondary query class using the current class as primary query
     */
    public function useLAuthorityItemQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinLAuthorityItem($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'LAuthorityItem', 'LAuthorityItemQuery');
    }

    /**
     * Filter the query by a related PurchaseProposal object
     *
     * @param   PurchaseProposal|PropelObjectCollection $purchaseProposal  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 ItemQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByPurchaseProposal($purchaseProposal, $comparison = null)
    {
        if ($purchaseProposal instanceof PurchaseProposal) {
            return $this
                ->addUsingAlias(ItemPeer::ITEM_ID, $purchaseProposal->getItemId(), $comparison);
        } elseif ($purchaseProposal instanceof PropelObjectCollection) {
            return $this
                ->usePurchaseProposalQuery()
                ->filterByPrimaryKeys($purchaseProposal->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByPurchaseProposal() only accepts arguments of type PurchaseProposal or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the PurchaseProposal relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function joinPurchaseProposal($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('PurchaseProposal');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'PurchaseProposal');
        }

        return $this;
    }

    /**
     * Use the PurchaseProposal relation PurchaseProposal object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   PurchaseProposalQuery A secondary query class using the current class as primary query
     */
    public function usePurchaseProposalQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinPurchaseProposal($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'PurchaseProposal', 'PurchaseProposalQuery');
    }

    /**
     * Exclude object from result
     *
     * @param   Item $item Object to remove from the list of results
     *
     * @return ItemQuery The current query, for fluid interface
     */
    public function prune($item = null)
    {
        if ($item) {
            $this->addUsingAlias(ItemPeer::ITEM_ID, $item->getItemId(), Criteria::NOT_EQUAL);
        }

        return $this;
    }

    // timestampable behavior

    /**
     * Filter by the latest updated
     *
     * @param      int $nbDays Maximum age of the latest update in days
     *
     * @return     ItemQuery The current query, for fluid interface
     */
    public function recentlyUpdated($nbDays = 7)
    {
        return $this->addUsingAlias(ItemPeer::DATE_UPDATED, time() - $nbDays * 24 * 60 * 60, Criteria::GREATER_EQUAL);
    }

    /**
     * Order by update date desc
     *
     * @return     ItemQuery The current query, for fluid interface
     */
    public function lastUpdatedFirst()
    {
        return $this->addDescendingOrderByColumn(ItemPeer::DATE_UPDATED);
    }

    /**
     * Order by update date asc
     *
     * @return     ItemQuery The current query, for fluid interface
     */
    public function firstUpdatedFirst()
    {
        return $this->addAscendingOrderByColumn(ItemPeer::DATE_UPDATED);
    }

    /**
     * Filter by the latest created
     *
     * @param      int $nbDays Maximum age of in days
     *
     * @return     ItemQuery The current query, for fluid interface
     */
    public function recentlyCreated($nbDays = 7)
    {
        return $this->addUsingAlias(ItemPeer::DATE_CREATED, time() - $nbDays * 24 * 60 * 60, Criteria::GREATER_EQUAL);
    }

    /**
     * Order by create date desc
     *
     * @return     ItemQuery The current query, for fluid interface
     */
    public function lastCreatedFirst()
    {
        return $this->addDescendingOrderByColumn(ItemPeer::DATE_CREATED);
    }

    /**
     * Order by create date asc
     *
     * @return     ItemQuery The current query, for fluid interface
     */
    public function firstCreatedFirst()
    {
        return $this->addAscendingOrderByColumn(ItemPeer::DATE_CREATED);
    }
}
