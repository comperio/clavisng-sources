<?php


/**
 * Base class that represents a query for the 'document_template' table.
 *
 *
 *
 * @method DocumentTemplateQuery orderByDocumentTemplateId($order = Criteria::ASC) Order by the document_template_id column
 * @method DocumentTemplateQuery orderByTemplateMedia($order = Criteria::ASC) Order by the template_media column
 * @method DocumentTemplateQuery orderByTemplateDescription($order = Criteria::ASC) Order by the template_description column
 * @method DocumentTemplateQuery orderByTemplateTitle($order = Criteria::ASC) Order by the template_title column
 * @method DocumentTemplateQuery orderByTemplateSubject($order = Criteria::ASC) Order by the template_subject column
 * @method DocumentTemplateQuery orderByTemplateBody($order = Criteria::ASC) Order by the template_body column
 * @method DocumentTemplateQuery orderByTemplateClass($order = Criteria::ASC) Order by the template_class column
 * @method DocumentTemplateQuery orderByTemplateLang($order = Criteria::ASC) Order by the template_lang column
 * @method DocumentTemplateQuery orderByLibraryId($order = Criteria::ASC) Order by the library_id column
 * @method DocumentTemplateQuery orderByDateCreated($order = Criteria::ASC) Order by the date_created column
 * @method DocumentTemplateQuery orderByDateUpdated($order = Criteria::ASC) Order by the date_updated column
 * @method DocumentTemplateQuery orderByCreatedBy($order = Criteria::ASC) Order by the created_by column
 * @method DocumentTemplateQuery orderByModifiedBy($order = Criteria::ASC) Order by the modified_by column
 *
 * @method DocumentTemplateQuery groupByDocumentTemplateId() Group by the document_template_id column
 * @method DocumentTemplateQuery groupByTemplateMedia() Group by the template_media column
 * @method DocumentTemplateQuery groupByTemplateDescription() Group by the template_description column
 * @method DocumentTemplateQuery groupByTemplateTitle() Group by the template_title column
 * @method DocumentTemplateQuery groupByTemplateSubject() Group by the template_subject column
 * @method DocumentTemplateQuery groupByTemplateBody() Group by the template_body column
 * @method DocumentTemplateQuery groupByTemplateClass() Group by the template_class column
 * @method DocumentTemplateQuery groupByTemplateLang() Group by the template_lang column
 * @method DocumentTemplateQuery groupByLibraryId() Group by the library_id column
 * @method DocumentTemplateQuery groupByDateCreated() Group by the date_created column
 * @method DocumentTemplateQuery groupByDateUpdated() Group by the date_updated column
 * @method DocumentTemplateQuery groupByCreatedBy() Group by the created_by column
 * @method DocumentTemplateQuery groupByModifiedBy() Group by the modified_by column
 *
 * @method DocumentTemplateQuery leftJoin($relation) Adds a LEFT JOIN clause to the query
 * @method DocumentTemplateQuery rightJoin($relation) Adds a RIGHT JOIN clause to the query
 * @method DocumentTemplateQuery innerJoin($relation) Adds a INNER JOIN clause to the query
 *
 * @method DocumentTemplateQuery leftJoinLibrarianRelatedByCreatedBy($relationAlias = null) Adds a LEFT JOIN clause to the query using the LibrarianRelatedByCreatedBy relation
 * @method DocumentTemplateQuery rightJoinLibrarianRelatedByCreatedBy($relationAlias = null) Adds a RIGHT JOIN clause to the query using the LibrarianRelatedByCreatedBy relation
 * @method DocumentTemplateQuery innerJoinLibrarianRelatedByCreatedBy($relationAlias = null) Adds a INNER JOIN clause to the query using the LibrarianRelatedByCreatedBy relation
 *
 * @method DocumentTemplateQuery leftJoinLibrarianRelatedByModifiedBy($relationAlias = null) Adds a LEFT JOIN clause to the query using the LibrarianRelatedByModifiedBy relation
 * @method DocumentTemplateQuery rightJoinLibrarianRelatedByModifiedBy($relationAlias = null) Adds a RIGHT JOIN clause to the query using the LibrarianRelatedByModifiedBy relation
 * @method DocumentTemplateQuery innerJoinLibrarianRelatedByModifiedBy($relationAlias = null) Adds a INNER JOIN clause to the query using the LibrarianRelatedByModifiedBy relation
 *
 * @method DocumentTemplateQuery leftJoinLibrary($relationAlias = null) Adds a LEFT JOIN clause to the query using the Library relation
 * @method DocumentTemplateQuery rightJoinLibrary($relationAlias = null) Adds a RIGHT JOIN clause to the query using the Library relation
 * @method DocumentTemplateQuery innerJoinLibrary($relationAlias = null) Adds a INNER JOIN clause to the query using the Library relation
 *
 * @method DocumentTemplate findOne(PropelPDO $con = null) Return the first DocumentTemplate matching the query
 * @method DocumentTemplate findOneOrCreate(PropelPDO $con = null) Return the first DocumentTemplate matching the query, or a new DocumentTemplate object populated from the query conditions when no match is found
 *
 * @method DocumentTemplate findOneByTemplateMedia(string $template_media) Return the first DocumentTemplate filtered by the template_media column
 * @method DocumentTemplate findOneByTemplateDescription(string $template_description) Return the first DocumentTemplate filtered by the template_description column
 * @method DocumentTemplate findOneByTemplateTitle(string $template_title) Return the first DocumentTemplate filtered by the template_title column
 * @method DocumentTemplate findOneByTemplateSubject(string $template_subject) Return the first DocumentTemplate filtered by the template_subject column
 * @method DocumentTemplate findOneByTemplateBody(string $template_body) Return the first DocumentTemplate filtered by the template_body column
 * @method DocumentTemplate findOneByTemplateClass(string $template_class) Return the first DocumentTemplate filtered by the template_class column
 * @method DocumentTemplate findOneByTemplateLang(string $template_lang) Return the first DocumentTemplate filtered by the template_lang column
 * @method DocumentTemplate findOneByLibraryId(int $library_id) Return the first DocumentTemplate filtered by the library_id column
 * @method DocumentTemplate findOneByDateCreated(string $date_created) Return the first DocumentTemplate filtered by the date_created column
 * @method DocumentTemplate findOneByDateUpdated(string $date_updated) Return the first DocumentTemplate filtered by the date_updated column
 * @method DocumentTemplate findOneByCreatedBy(int $created_by) Return the first DocumentTemplate filtered by the created_by column
 * @method DocumentTemplate findOneByModifiedBy(int $modified_by) Return the first DocumentTemplate filtered by the modified_by column
 *
 * @method array findByDocumentTemplateId(int $document_template_id) Return DocumentTemplate objects filtered by the document_template_id column
 * @method array findByTemplateMedia(string $template_media) Return DocumentTemplate objects filtered by the template_media column
 * @method array findByTemplateDescription(string $template_description) Return DocumentTemplate objects filtered by the template_description column
 * @method array findByTemplateTitle(string $template_title) Return DocumentTemplate objects filtered by the template_title column
 * @method array findByTemplateSubject(string $template_subject) Return DocumentTemplate objects filtered by the template_subject column
 * @method array findByTemplateBody(string $template_body) Return DocumentTemplate objects filtered by the template_body column
 * @method array findByTemplateClass(string $template_class) Return DocumentTemplate objects filtered by the template_class column
 * @method array findByTemplateLang(string $template_lang) Return DocumentTemplate objects filtered by the template_lang column
 * @method array findByLibraryId(int $library_id) Return DocumentTemplate objects filtered by the library_id column
 * @method array findByDateCreated(string $date_created) Return DocumentTemplate objects filtered by the date_created column
 * @method array findByDateUpdated(string $date_updated) Return DocumentTemplate objects filtered by the date_updated column
 * @method array findByCreatedBy(int $created_by) Return DocumentTemplate objects filtered by the created_by column
 * @method array findByModifiedBy(int $modified_by) Return DocumentTemplate objects filtered by the modified_by column
 *
 * @package    propel.generator.clavis.om
 */
abstract class BaseDocumentTemplateQuery extends ModelCriteria
{
    /**
     * Initializes internal state of BaseDocumentTemplateQuery object.
     *
     * @param     string $dbName The dabase name
     * @param     string $modelName The phpName of a model, e.g. 'Book'
     * @param     string $modelAlias The alias for the model in this query, e.g. 'b'
     */
    public function __construct($dbName = null, $modelName = null, $modelAlias = null)
    {
        if (null === $dbName) {
            $dbName = 'clavis';
        }
        if (null === $modelName) {
            $modelName = 'DocumentTemplate';
        }
        parent::__construct($dbName, $modelName, $modelAlias);
    }

    /**
     * Returns a new DocumentTemplateQuery object.
     *
     * @param     string $modelAlias The alias of a model in the query
     * @param   DocumentTemplateQuery|Criteria $criteria Optional Criteria to build the query from
     *
     * @return DocumentTemplateQuery
     */
    public static function create($modelAlias = null, $criteria = null)
    {
        if ($criteria instanceof DocumentTemplateQuery) {
            return $criteria;
        }
        $query = new DocumentTemplateQuery(null, null, $modelAlias);

        if ($criteria instanceof Criteria) {
            $query->mergeWith($criteria);
        }

        return $query;
    }

    /**
     * Find object by primary key.
     * Propel uses the instance pool to skip the database if the object exists.
     * Go fast if the query is untouched.
     *
     * <code>
     * $obj  = $c->findPk(12, $con);
     * </code>
     *
     * @param mixed $key Primary key to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return   DocumentTemplate|DocumentTemplate[]|mixed the result, formatted by the current formatter
     */
    public function findPk($key, $con = null)
    {
        if ($key === null) {
            return null;
        }
        if ((null !== ($obj = DocumentTemplatePeer::getInstanceFromPool((string) $key))) && !$this->formatter) {
            // the object is already in the instance pool
            return $obj;
        }
        if ($con === null) {
            $con = Propel::getConnection(DocumentTemplatePeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        if ($this->formatter || $this->modelAlias || $this->with || $this->select
         || $this->selectColumns || $this->asColumns || $this->selectModifiers
         || $this->map || $this->having || $this->joins) {
            return $this->findPkComplex($key, $con);
        } else {
            return $this->findPkSimple($key, $con);
        }
    }

    /**
     * Alias of findPk to use instance pooling
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 DocumentTemplate A model object, or null if the key is not found
     * @throws PropelException
     */
     public function findOneByDocumentTemplateId($key, $con = null)
     {
        return $this->findPk($key, $con);
     }

    /**
     * Find object by primary key using raw SQL to go fast.
     * Bypass doSelect() and the object formatter by using generated code.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 DocumentTemplate A model object, or null if the key is not found
     * @throws PropelException
     */
    protected function findPkSimple($key, $con)
    {
        $sql = 'SELECT `document_template_id`, `template_media`, `template_description`, `template_title`, `template_subject`, `template_body`, `template_class`, `template_lang`, `library_id`, `date_created`, `date_updated`, `created_by`, `modified_by` FROM `document_template` WHERE `document_template_id` = :p0';
        try {
            $stmt = $con->prepare($sql);
            $stmt->bindValue(':p0', $key, PDO::PARAM_INT);
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute SELECT statement [%s]', $sql), $e);
        }
        $obj = null;
        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $obj = new DocumentTemplate();
            $obj->hydrate($row);
            DocumentTemplatePeer::addInstanceToPool($obj, (string) $key);
        }
        $stmt->closeCursor();

        return $obj;
    }

    /**
     * Find object by primary key.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return DocumentTemplate|DocumentTemplate[]|mixed the result, formatted by the current formatter
     */
    protected function findPkComplex($key, $con)
    {
        // As the query uses a PK condition, no limit(1) is necessary.
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKey($key)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->formatOne($stmt);
    }

    /**
     * Find objects by primary key
     * <code>
     * $objs = $c->findPks(array(12, 56, 832), $con);
     * </code>
     * @param     array $keys Primary keys to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return PropelObjectCollection|DocumentTemplate[]|mixed the list of results, formatted by the current formatter
     */
    public function findPks($keys, $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection($this->getDbName(), Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKeys($keys)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->format($stmt);
    }

    /**
     * Filter the query by primary key
     *
     * @param     mixed $key Primary key to use for the query
     *
     * @return DocumentTemplateQuery The current query, for fluid interface
     */
    public function filterByPrimaryKey($key)
    {

        return $this->addUsingAlias(DocumentTemplatePeer::DOCUMENT_TEMPLATE_ID, $key, Criteria::EQUAL);
    }

    /**
     * Filter the query by a list of primary keys
     *
     * @param     array $keys The list of primary key to use for the query
     *
     * @return DocumentTemplateQuery The current query, for fluid interface
     */
    public function filterByPrimaryKeys($keys)
    {

        return $this->addUsingAlias(DocumentTemplatePeer::DOCUMENT_TEMPLATE_ID, $keys, Criteria::IN);
    }

    /**
     * Filter the query on the document_template_id column
     *
     * Example usage:
     * <code>
     * $query->filterByDocumentTemplateId(1234); // WHERE document_template_id = 1234
     * $query->filterByDocumentTemplateId(array(12, 34)); // WHERE document_template_id IN (12, 34)
     * $query->filterByDocumentTemplateId(array('min' => 12)); // WHERE document_template_id >= 12
     * $query->filterByDocumentTemplateId(array('max' => 12)); // WHERE document_template_id <= 12
     * </code>
     *
     * @param     mixed $documentTemplateId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return DocumentTemplateQuery The current query, for fluid interface
     */
    public function filterByDocumentTemplateId($documentTemplateId = null, $comparison = null)
    {
        if (is_array($documentTemplateId)) {
            $useMinMax = false;
            if (isset($documentTemplateId['min'])) {
                $this->addUsingAlias(DocumentTemplatePeer::DOCUMENT_TEMPLATE_ID, $documentTemplateId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($documentTemplateId['max'])) {
                $this->addUsingAlias(DocumentTemplatePeer::DOCUMENT_TEMPLATE_ID, $documentTemplateId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(DocumentTemplatePeer::DOCUMENT_TEMPLATE_ID, $documentTemplateId, $comparison);
    }

    /**
     * Filter the query on the template_media column
     *
     * Example usage:
     * <code>
     * $query->filterByTemplateMedia('fooValue');   // WHERE template_media = 'fooValue'
     * $query->filterByTemplateMedia('%fooValue%'); // WHERE template_media LIKE '%fooValue%'
     * </code>
     *
     * @param     string $templateMedia The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return DocumentTemplateQuery The current query, for fluid interface
     */
    public function filterByTemplateMedia($templateMedia = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($templateMedia)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $templateMedia)) {
                $templateMedia = str_replace('*', '%', $templateMedia);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(DocumentTemplatePeer::TEMPLATE_MEDIA, $templateMedia, $comparison);
    }

    /**
     * Filter the query on the template_description column
     *
     * Example usage:
     * <code>
     * $query->filterByTemplateDescription('fooValue');   // WHERE template_description = 'fooValue'
     * $query->filterByTemplateDescription('%fooValue%'); // WHERE template_description LIKE '%fooValue%'
     * </code>
     *
     * @param     string $templateDescription The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return DocumentTemplateQuery The current query, for fluid interface
     */
    public function filterByTemplateDescription($templateDescription = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($templateDescription)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $templateDescription)) {
                $templateDescription = str_replace('*', '%', $templateDescription);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(DocumentTemplatePeer::TEMPLATE_DESCRIPTION, $templateDescription, $comparison);
    }

    /**
     * Filter the query on the template_title column
     *
     * Example usage:
     * <code>
     * $query->filterByTemplateTitle('fooValue');   // WHERE template_title = 'fooValue'
     * $query->filterByTemplateTitle('%fooValue%'); // WHERE template_title LIKE '%fooValue%'
     * </code>
     *
     * @param     string $templateTitle The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return DocumentTemplateQuery The current query, for fluid interface
     */
    public function filterByTemplateTitle($templateTitle = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($templateTitle)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $templateTitle)) {
                $templateTitle = str_replace('*', '%', $templateTitle);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(DocumentTemplatePeer::TEMPLATE_TITLE, $templateTitle, $comparison);
    }

    /**
     * Filter the query on the template_subject column
     *
     * Example usage:
     * <code>
     * $query->filterByTemplateSubject('fooValue');   // WHERE template_subject = 'fooValue'
     * $query->filterByTemplateSubject('%fooValue%'); // WHERE template_subject LIKE '%fooValue%'
     * </code>
     *
     * @param     string $templateSubject The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return DocumentTemplateQuery The current query, for fluid interface
     */
    public function filterByTemplateSubject($templateSubject = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($templateSubject)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $templateSubject)) {
                $templateSubject = str_replace('*', '%', $templateSubject);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(DocumentTemplatePeer::TEMPLATE_SUBJECT, $templateSubject, $comparison);
    }

    /**
     * Filter the query on the template_body column
     *
     * Example usage:
     * <code>
     * $query->filterByTemplateBody('fooValue');   // WHERE template_body = 'fooValue'
     * $query->filterByTemplateBody('%fooValue%'); // WHERE template_body LIKE '%fooValue%'
     * </code>
     *
     * @param     string $templateBody The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return DocumentTemplateQuery The current query, for fluid interface
     */
    public function filterByTemplateBody($templateBody = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($templateBody)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $templateBody)) {
                $templateBody = str_replace('*', '%', $templateBody);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(DocumentTemplatePeer::TEMPLATE_BODY, $templateBody, $comparison);
    }

    /**
     * Filter the query on the template_class column
     *
     * Example usage:
     * <code>
     * $query->filterByTemplateClass('fooValue');   // WHERE template_class = 'fooValue'
     * $query->filterByTemplateClass('%fooValue%'); // WHERE template_class LIKE '%fooValue%'
     * </code>
     *
     * @param     string $templateClass The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return DocumentTemplateQuery The current query, for fluid interface
     */
    public function filterByTemplateClass($templateClass = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($templateClass)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $templateClass)) {
                $templateClass = str_replace('*', '%', $templateClass);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(DocumentTemplatePeer::TEMPLATE_CLASS, $templateClass, $comparison);
    }

    /**
     * Filter the query on the template_lang column
     *
     * Example usage:
     * <code>
     * $query->filterByTemplateLang('fooValue');   // WHERE template_lang = 'fooValue'
     * $query->filterByTemplateLang('%fooValue%'); // WHERE template_lang LIKE '%fooValue%'
     * </code>
     *
     * @param     string $templateLang The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return DocumentTemplateQuery The current query, for fluid interface
     */
    public function filterByTemplateLang($templateLang = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($templateLang)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $templateLang)) {
                $templateLang = str_replace('*', '%', $templateLang);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(DocumentTemplatePeer::TEMPLATE_LANG, $templateLang, $comparison);
    }

    /**
     * Filter the query on the library_id column
     *
     * Example usage:
     * <code>
     * $query->filterByLibraryId(1234); // WHERE library_id = 1234
     * $query->filterByLibraryId(array(12, 34)); // WHERE library_id IN (12, 34)
     * $query->filterByLibraryId(array('min' => 12)); // WHERE library_id >= 12
     * $query->filterByLibraryId(array('max' => 12)); // WHERE library_id <= 12
     * </code>
     *
     * @see       filterByLibrary()
     *
     * @param     mixed $libraryId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return DocumentTemplateQuery The current query, for fluid interface
     */
    public function filterByLibraryId($libraryId = null, $comparison = null)
    {
        if (is_array($libraryId)) {
            $useMinMax = false;
            if (isset($libraryId['min'])) {
                $this->addUsingAlias(DocumentTemplatePeer::LIBRARY_ID, $libraryId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($libraryId['max'])) {
                $this->addUsingAlias(DocumentTemplatePeer::LIBRARY_ID, $libraryId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(DocumentTemplatePeer::LIBRARY_ID, $libraryId, $comparison);
    }

    /**
     * Filter the query on the date_created column
     *
     * Example usage:
     * <code>
     * $query->filterByDateCreated('2011-03-14'); // WHERE date_created = '2011-03-14'
     * $query->filterByDateCreated('now'); // WHERE date_created = '2011-03-14'
     * $query->filterByDateCreated(array('max' => 'yesterday')); // WHERE date_created < '2011-03-13'
     * </code>
     *
     * @param     mixed $dateCreated The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return DocumentTemplateQuery The current query, for fluid interface
     */
    public function filterByDateCreated($dateCreated = null, $comparison = null)
    {
        if (is_array($dateCreated)) {
            $useMinMax = false;
            if (isset($dateCreated['min'])) {
                $this->addUsingAlias(DocumentTemplatePeer::DATE_CREATED, $dateCreated['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dateCreated['max'])) {
                $this->addUsingAlias(DocumentTemplatePeer::DATE_CREATED, $dateCreated['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(DocumentTemplatePeer::DATE_CREATED, $dateCreated, $comparison);
    }

    /**
     * Filter the query on the date_updated column
     *
     * Example usage:
     * <code>
     * $query->filterByDateUpdated('2011-03-14'); // WHERE date_updated = '2011-03-14'
     * $query->filterByDateUpdated('now'); // WHERE date_updated = '2011-03-14'
     * $query->filterByDateUpdated(array('max' => 'yesterday')); // WHERE date_updated < '2011-03-13'
     * </code>
     *
     * @param     mixed $dateUpdated The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return DocumentTemplateQuery The current query, for fluid interface
     */
    public function filterByDateUpdated($dateUpdated = null, $comparison = null)
    {
        if (is_array($dateUpdated)) {
            $useMinMax = false;
            if (isset($dateUpdated['min'])) {
                $this->addUsingAlias(DocumentTemplatePeer::DATE_UPDATED, $dateUpdated['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dateUpdated['max'])) {
                $this->addUsingAlias(DocumentTemplatePeer::DATE_UPDATED, $dateUpdated['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(DocumentTemplatePeer::DATE_UPDATED, $dateUpdated, $comparison);
    }

    /**
     * Filter the query on the created_by column
     *
     * Example usage:
     * <code>
     * $query->filterByCreatedBy(1234); // WHERE created_by = 1234
     * $query->filterByCreatedBy(array(12, 34)); // WHERE created_by IN (12, 34)
     * $query->filterByCreatedBy(array('min' => 12)); // WHERE created_by >= 12
     * $query->filterByCreatedBy(array('max' => 12)); // WHERE created_by <= 12
     * </code>
     *
     * @see       filterByLibrarianRelatedByCreatedBy()
     *
     * @param     mixed $createdBy The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return DocumentTemplateQuery The current query, for fluid interface
     */
    public function filterByCreatedBy($createdBy = null, $comparison = null)
    {
        if (is_array($createdBy)) {
            $useMinMax = false;
            if (isset($createdBy['min'])) {
                $this->addUsingAlias(DocumentTemplatePeer::CREATED_BY, $createdBy['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($createdBy['max'])) {
                $this->addUsingAlias(DocumentTemplatePeer::CREATED_BY, $createdBy['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(DocumentTemplatePeer::CREATED_BY, $createdBy, $comparison);
    }

    /**
     * Filter the query on the modified_by column
     *
     * Example usage:
     * <code>
     * $query->filterByModifiedBy(1234); // WHERE modified_by = 1234
     * $query->filterByModifiedBy(array(12, 34)); // WHERE modified_by IN (12, 34)
     * $query->filterByModifiedBy(array('min' => 12)); // WHERE modified_by >= 12
     * $query->filterByModifiedBy(array('max' => 12)); // WHERE modified_by <= 12
     * </code>
     *
     * @see       filterByLibrarianRelatedByModifiedBy()
     *
     * @param     mixed $modifiedBy The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return DocumentTemplateQuery The current query, for fluid interface
     */
    public function filterByModifiedBy($modifiedBy = null, $comparison = null)
    {
        if (is_array($modifiedBy)) {
            $useMinMax = false;
            if (isset($modifiedBy['min'])) {
                $this->addUsingAlias(DocumentTemplatePeer::MODIFIED_BY, $modifiedBy['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($modifiedBy['max'])) {
                $this->addUsingAlias(DocumentTemplatePeer::MODIFIED_BY, $modifiedBy['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(DocumentTemplatePeer::MODIFIED_BY, $modifiedBy, $comparison);
    }

    /**
     * Filter the query by a related Librarian object
     *
     * @param   Librarian|PropelObjectCollection $librarian The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 DocumentTemplateQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByLibrarianRelatedByCreatedBy($librarian, $comparison = null)
    {
        if ($librarian instanceof Librarian) {
            return $this
                ->addUsingAlias(DocumentTemplatePeer::CREATED_BY, $librarian->getLibrarianId(), $comparison);
        } elseif ($librarian instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(DocumentTemplatePeer::CREATED_BY, $librarian->toKeyValue('PrimaryKey', 'LibrarianId'), $comparison);
        } else {
            throw new PropelException('filterByLibrarianRelatedByCreatedBy() only accepts arguments of type Librarian or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the LibrarianRelatedByCreatedBy relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return DocumentTemplateQuery The current query, for fluid interface
     */
    public function joinLibrarianRelatedByCreatedBy($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('LibrarianRelatedByCreatedBy');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'LibrarianRelatedByCreatedBy');
        }

        return $this;
    }

    /**
     * Use the LibrarianRelatedByCreatedBy relation Librarian object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   LibrarianQuery A secondary query class using the current class as primary query
     */
    public function useLibrarianRelatedByCreatedByQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinLibrarianRelatedByCreatedBy($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'LibrarianRelatedByCreatedBy', 'LibrarianQuery');
    }

    /**
     * Filter the query by a related Librarian object
     *
     * @param   Librarian|PropelObjectCollection $librarian The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 DocumentTemplateQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByLibrarianRelatedByModifiedBy($librarian, $comparison = null)
    {
        if ($librarian instanceof Librarian) {
            return $this
                ->addUsingAlias(DocumentTemplatePeer::MODIFIED_BY, $librarian->getLibrarianId(), $comparison);
        } elseif ($librarian instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(DocumentTemplatePeer::MODIFIED_BY, $librarian->toKeyValue('PrimaryKey', 'LibrarianId'), $comparison);
        } else {
            throw new PropelException('filterByLibrarianRelatedByModifiedBy() only accepts arguments of type Librarian or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the LibrarianRelatedByModifiedBy relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return DocumentTemplateQuery The current query, for fluid interface
     */
    public function joinLibrarianRelatedByModifiedBy($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('LibrarianRelatedByModifiedBy');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'LibrarianRelatedByModifiedBy');
        }

        return $this;
    }

    /**
     * Use the LibrarianRelatedByModifiedBy relation Librarian object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   LibrarianQuery A secondary query class using the current class as primary query
     */
    public function useLibrarianRelatedByModifiedByQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinLibrarianRelatedByModifiedBy($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'LibrarianRelatedByModifiedBy', 'LibrarianQuery');
    }

    /**
     * Filter the query by a related Library object
     *
     * @param   Library|PropelObjectCollection $library The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 DocumentTemplateQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByLibrary($library, $comparison = null)
    {
        if ($library instanceof Library) {
            return $this
                ->addUsingAlias(DocumentTemplatePeer::LIBRARY_ID, $library->getLibraryId(), $comparison);
        } elseif ($library instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(DocumentTemplatePeer::LIBRARY_ID, $library->toKeyValue('PrimaryKey', 'LibraryId'), $comparison);
        } else {
            throw new PropelException('filterByLibrary() only accepts arguments of type Library or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the Library relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return DocumentTemplateQuery The current query, for fluid interface
     */
    public function joinLibrary($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('Library');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'Library');
        }

        return $this;
    }

    /**
     * Use the Library relation Library object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   LibraryQuery A secondary query class using the current class as primary query
     */
    public function useLibraryQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinLibrary($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'Library', 'LibraryQuery');
    }

    /**
     * Exclude object from result
     *
     * @param   DocumentTemplate $documentTemplate Object to remove from the list of results
     *
     * @return DocumentTemplateQuery The current query, for fluid interface
     */
    public function prune($documentTemplate = null)
    {
        if ($documentTemplate) {
            $this->addUsingAlias(DocumentTemplatePeer::DOCUMENT_TEMPLATE_ID, $documentTemplate->getDocumentTemplateId(), Criteria::NOT_EQUAL);
        }

        return $this;
    }

    // timestampable behavior

    /**
     * Filter by the latest updated
     *
     * @param      int $nbDays Maximum age of the latest update in days
     *
     * @return     DocumentTemplateQuery The current query, for fluid interface
     */
    public function recentlyUpdated($nbDays = 7)
    {
        return $this->addUsingAlias(DocumentTemplatePeer::DATE_UPDATED, time() - $nbDays * 24 * 60 * 60, Criteria::GREATER_EQUAL);
    }

    /**
     * Order by update date desc
     *
     * @return     DocumentTemplateQuery The current query, for fluid interface
     */
    public function lastUpdatedFirst()
    {
        return $this->addDescendingOrderByColumn(DocumentTemplatePeer::DATE_UPDATED);
    }

    /**
     * Order by update date asc
     *
     * @return     DocumentTemplateQuery The current query, for fluid interface
     */
    public function firstUpdatedFirst()
    {
        return $this->addAscendingOrderByColumn(DocumentTemplatePeer::DATE_UPDATED);
    }

    /**
     * Filter by the latest created
     *
     * @param      int $nbDays Maximum age of in days
     *
     * @return     DocumentTemplateQuery The current query, for fluid interface
     */
    public function recentlyCreated($nbDays = 7)
    {
        return $this->addUsingAlias(DocumentTemplatePeer::DATE_CREATED, time() - $nbDays * 24 * 60 * 60, Criteria::GREATER_EQUAL);
    }

    /**
     * Order by create date desc
     *
     * @return     DocumentTemplateQuery The current query, for fluid interface
     */
    public function lastCreatedFirst()
    {
        return $this->addDescendingOrderByColumn(DocumentTemplatePeer::DATE_CREATED);
    }

    /**
     * Order by create date asc
     *
     * @return     DocumentTemplateQuery The current query, for fluid interface
     */
    public function firstCreatedFirst()
    {
        return $this->addAscendingOrderByColumn(DocumentTemplatePeer::DATE_CREATED);
    }
}
