<?php


/**
 * Base static class for performing query and update operations on the 'authority' table.
 *
 *
 *
 * @package propel.generator.clavis.om
 */
abstract class BaseAuthorityPeer
{

    /** the default database name for this class */
    const DATABASE_NAME = 'clavis';

    /** the table name for this class */
    const TABLE_NAME = 'authority';

    /** the related Propel class for this table */
    const OM_CLASS = 'Authority';

    /** the related TableMap class for this table */
    const TM_CLASS = 'AuthorityTableMap';

    /** The total number of columns. */
    const NUM_COLUMNS = 22;

    /** The number of lazy-loaded columns. */
    const NUM_LAZY_LOAD_COLUMNS = 0;

    /** The number of columns to hydrate (NUM_COLUMNS - NUM_LAZY_LOAD_COLUMNS) */
    const NUM_HYDRATE_COLUMNS = 22;

    /** the column name for the authority_id field */
    const AUTHORITY_ID = 'authority.authority_id';

    /** the column name for the non_sort_text field */
    const NON_SORT_TEXT = 'authority.non_sort_text';

    /** the column name for the sort_text field */
    const SORT_TEXT = 'authority.sort_text';

    /** the column name for the full_text field */
    const FULL_TEXT = 'authority.full_text';

    /** the column name for the authority_type field */
    const AUTHORITY_TYPE = 'authority.authority_type';

    /** the column name for the authority_subtype field */
    const AUTHORITY_SUBTYPE = 'authority.authority_subtype';

    /** the column name for the authority_rectype field */
    const AUTHORITY_RECTYPE = 'authority.authority_rectype';

    /** the column name for the authority_status field */
    const AUTHORITY_STATUS = 'authority.authority_status';

    /** the column name for the unimarc field */
    const UNIMARC = 'authority.unimarc';

    /** the column name for the ext_data field */
    const EXT_DATA = 'authority.ext_data';

    /** the column name for the authority_lang field */
    const AUTHORITY_LANG = 'authority.authority_lang';

    /** the column name for the authority_codlevel field */
    const AUTHORITY_CODLEVEL = 'authority.authority_codlevel';

    /** the column name for the parent_id field */
    const PARENT_ID = 'authority.parent_id';

    /** the column name for the subject_class field */
    const SUBJECT_CLASS = 'authority.subject_class';

    /** the column name for the class_code field */
    const CLASS_CODE = 'authority.class_code';

    /** the column name for the bid_source field */
    const BID_SOURCE = 'authority.bid_source';

    /** the column name for the bid field */
    const BID = 'authority.bid';

    /** the column name for the last_sbn_sync field */
    const LAST_SBN_SYNC = 'authority.last_sbn_sync';

    /** the column name for the date_created field */
    const DATE_CREATED = 'authority.date_created';

    /** the column name for the date_updated field */
    const DATE_UPDATED = 'authority.date_updated';

    /** the column name for the created_by field */
    const CREATED_BY = 'authority.created_by';

    /** the column name for the modified_by field */
    const MODIFIED_BY = 'authority.modified_by';

    /** The default string format for model objects of the related table **/
    const DEFAULT_STRING_FORMAT = 'YAML';

    /**
     * An identity map to hold any loaded instances of Authority objects.
     * This must be public so that other peer classes can access this when hydrating from JOIN
     * queries.
     * @var        array Authority[]
     */
    public static $instances = array();


    /**
     * holds an array of fieldnames
     *
     * first dimension keys are the type constants
     * e.g. AuthorityPeer::$fieldNames[AuthorityPeer::TYPE_PHPNAME][0] = 'Id'
     */
    protected static $fieldNames = array (
        BasePeer::TYPE_PHPNAME => array ('AuthorityId', 'NonSortText', 'SortText', 'FullText', 'AuthorityType', 'AuthoritySubtype', 'AuthorityRectype', 'AuthorityStatus', 'Unimarc', 'ExtData', 'AuthorityLang', 'AuthorityCodlevel', 'ParentId', 'SubjectClass', 'ClassCode', 'BidSource', 'Bid', 'LastSbnSync', 'DateCreated', 'DateUpdated', 'CreatedBy', 'ModifiedBy', ),
        BasePeer::TYPE_STUDLYPHPNAME => array ('authorityId', 'nonSortText', 'sortText', 'fullText', 'authorityType', 'authoritySubtype', 'authorityRectype', 'authorityStatus', 'unimarc', 'extData', 'authorityLang', 'authorityCodlevel', 'parentId', 'subjectClass', 'classCode', 'bidSource', 'bid', 'lastSbnSync', 'dateCreated', 'dateUpdated', 'createdBy', 'modifiedBy', ),
        BasePeer::TYPE_COLNAME => array (AuthorityPeer::AUTHORITY_ID, AuthorityPeer::NON_SORT_TEXT, AuthorityPeer::SORT_TEXT, AuthorityPeer::FULL_TEXT, AuthorityPeer::AUTHORITY_TYPE, AuthorityPeer::AUTHORITY_SUBTYPE, AuthorityPeer::AUTHORITY_RECTYPE, AuthorityPeer::AUTHORITY_STATUS, AuthorityPeer::UNIMARC, AuthorityPeer::EXT_DATA, AuthorityPeer::AUTHORITY_LANG, AuthorityPeer::AUTHORITY_CODLEVEL, AuthorityPeer::PARENT_ID, AuthorityPeer::SUBJECT_CLASS, AuthorityPeer::CLASS_CODE, AuthorityPeer::BID_SOURCE, AuthorityPeer::BID, AuthorityPeer::LAST_SBN_SYNC, AuthorityPeer::DATE_CREATED, AuthorityPeer::DATE_UPDATED, AuthorityPeer::CREATED_BY, AuthorityPeer::MODIFIED_BY, ),
        BasePeer::TYPE_RAW_COLNAME => array ('AUTHORITY_ID', 'NON_SORT_TEXT', 'SORT_TEXT', 'FULL_TEXT', 'AUTHORITY_TYPE', 'AUTHORITY_SUBTYPE', 'AUTHORITY_RECTYPE', 'AUTHORITY_STATUS', 'UNIMARC', 'EXT_DATA', 'AUTHORITY_LANG', 'AUTHORITY_CODLEVEL', 'PARENT_ID', 'SUBJECT_CLASS', 'CLASS_CODE', 'BID_SOURCE', 'BID', 'LAST_SBN_SYNC', 'DATE_CREATED', 'DATE_UPDATED', 'CREATED_BY', 'MODIFIED_BY', ),
        BasePeer::TYPE_FIELDNAME => array ('authority_id', 'non_sort_text', 'sort_text', 'full_text', 'authority_type', 'authority_subtype', 'authority_rectype', 'authority_status', 'unimarc', 'ext_data', 'authority_lang', 'authority_codlevel', 'parent_id', 'subject_class', 'class_code', 'bid_source', 'bid', 'last_sbn_sync', 'date_created', 'date_updated', 'created_by', 'modified_by', ),
        BasePeer::TYPE_NUM => array (0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, )
    );

    /**
     * holds an array of keys for quick access to the fieldnames array
     *
     * first dimension keys are the type constants
     * e.g. AuthorityPeer::$fieldNames[BasePeer::TYPE_PHPNAME]['Id'] = 0
     */
    protected static $fieldKeys = array (
        BasePeer::TYPE_PHPNAME => array ('AuthorityId' => 0, 'NonSortText' => 1, 'SortText' => 2, 'FullText' => 3, 'AuthorityType' => 4, 'AuthoritySubtype' => 5, 'AuthorityRectype' => 6, 'AuthorityStatus' => 7, 'Unimarc' => 8, 'ExtData' => 9, 'AuthorityLang' => 10, 'AuthorityCodlevel' => 11, 'ParentId' => 12, 'SubjectClass' => 13, 'ClassCode' => 14, 'BidSource' => 15, 'Bid' => 16, 'LastSbnSync' => 17, 'DateCreated' => 18, 'DateUpdated' => 19, 'CreatedBy' => 20, 'ModifiedBy' => 21, ),
        BasePeer::TYPE_STUDLYPHPNAME => array ('authorityId' => 0, 'nonSortText' => 1, 'sortText' => 2, 'fullText' => 3, 'authorityType' => 4, 'authoritySubtype' => 5, 'authorityRectype' => 6, 'authorityStatus' => 7, 'unimarc' => 8, 'extData' => 9, 'authorityLang' => 10, 'authorityCodlevel' => 11, 'parentId' => 12, 'subjectClass' => 13, 'classCode' => 14, 'bidSource' => 15, 'bid' => 16, 'lastSbnSync' => 17, 'dateCreated' => 18, 'dateUpdated' => 19, 'createdBy' => 20, 'modifiedBy' => 21, ),
        BasePeer::TYPE_COLNAME => array (AuthorityPeer::AUTHORITY_ID => 0, AuthorityPeer::NON_SORT_TEXT => 1, AuthorityPeer::SORT_TEXT => 2, AuthorityPeer::FULL_TEXT => 3, AuthorityPeer::AUTHORITY_TYPE => 4, AuthorityPeer::AUTHORITY_SUBTYPE => 5, AuthorityPeer::AUTHORITY_RECTYPE => 6, AuthorityPeer::AUTHORITY_STATUS => 7, AuthorityPeer::UNIMARC => 8, AuthorityPeer::EXT_DATA => 9, AuthorityPeer::AUTHORITY_LANG => 10, AuthorityPeer::AUTHORITY_CODLEVEL => 11, AuthorityPeer::PARENT_ID => 12, AuthorityPeer::SUBJECT_CLASS => 13, AuthorityPeer::CLASS_CODE => 14, AuthorityPeer::BID_SOURCE => 15, AuthorityPeer::BID => 16, AuthorityPeer::LAST_SBN_SYNC => 17, AuthorityPeer::DATE_CREATED => 18, AuthorityPeer::DATE_UPDATED => 19, AuthorityPeer::CREATED_BY => 20, AuthorityPeer::MODIFIED_BY => 21, ),
        BasePeer::TYPE_RAW_COLNAME => array ('AUTHORITY_ID' => 0, 'NON_SORT_TEXT' => 1, 'SORT_TEXT' => 2, 'FULL_TEXT' => 3, 'AUTHORITY_TYPE' => 4, 'AUTHORITY_SUBTYPE' => 5, 'AUTHORITY_RECTYPE' => 6, 'AUTHORITY_STATUS' => 7, 'UNIMARC' => 8, 'EXT_DATA' => 9, 'AUTHORITY_LANG' => 10, 'AUTHORITY_CODLEVEL' => 11, 'PARENT_ID' => 12, 'SUBJECT_CLASS' => 13, 'CLASS_CODE' => 14, 'BID_SOURCE' => 15, 'BID' => 16, 'LAST_SBN_SYNC' => 17, 'DATE_CREATED' => 18, 'DATE_UPDATED' => 19, 'CREATED_BY' => 20, 'MODIFIED_BY' => 21, ),
        BasePeer::TYPE_FIELDNAME => array ('authority_id' => 0, 'non_sort_text' => 1, 'sort_text' => 2, 'full_text' => 3, 'authority_type' => 4, 'authority_subtype' => 5, 'authority_rectype' => 6, 'authority_status' => 7, 'unimarc' => 8, 'ext_data' => 9, 'authority_lang' => 10, 'authority_codlevel' => 11, 'parent_id' => 12, 'subject_class' => 13, 'class_code' => 14, 'bid_source' => 15, 'bid' => 16, 'last_sbn_sync' => 17, 'date_created' => 18, 'date_updated' => 19, 'created_by' => 20, 'modified_by' => 21, ),
        BasePeer::TYPE_NUM => array (0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, )
    );

    /**
     * Translates a fieldname to another type
     *
     * @param      string $name field name
     * @param      string $fromType One of the class type constants BasePeer::TYPE_PHPNAME, BasePeer::TYPE_STUDLYPHPNAME
     *                         BasePeer::TYPE_COLNAME, BasePeer::TYPE_FIELDNAME, BasePeer::TYPE_NUM
     * @param      string $toType   One of the class type constants
     * @return string          translated name of the field.
     * @throws PropelException - if the specified name could not be found in the fieldname mappings.
     */
    public static function translateFieldName($name, $fromType, $toType)
    {
        $toNames = AuthorityPeer::getFieldNames($toType);
        $key = isset(AuthorityPeer::$fieldKeys[$fromType][$name]) ? AuthorityPeer::$fieldKeys[$fromType][$name] : null;
        if ($key === null) {
            throw new PropelException("'$name' could not be found in the field names of type '$fromType'. These are: " . print_r(AuthorityPeer::$fieldKeys[$fromType], true));
        }

        return $toNames[$key];
    }

    /**
     * Returns an array of field names.
     *
     * @param      string $type The type of fieldnames to return:
     *                      One of the class type constants BasePeer::TYPE_PHPNAME, BasePeer::TYPE_STUDLYPHPNAME
     *                      BasePeer::TYPE_COLNAME, BasePeer::TYPE_FIELDNAME, BasePeer::TYPE_NUM
     * @return array           A list of field names
     * @throws PropelException - if the type is not valid.
     */
    public static function getFieldNames($type = BasePeer::TYPE_PHPNAME)
    {
        if (!array_key_exists($type, AuthorityPeer::$fieldNames)) {
            throw new PropelException('Method getFieldNames() expects the parameter $type to be one of the class constants BasePeer::TYPE_PHPNAME, BasePeer::TYPE_STUDLYPHPNAME, BasePeer::TYPE_COLNAME, BasePeer::TYPE_FIELDNAME, BasePeer::TYPE_NUM. ' . $type . ' was given.');
        }

        return AuthorityPeer::$fieldNames[$type];
    }

    /**
     * Convenience method which changes table.column to alias.column.
     *
     * Using this method you can maintain SQL abstraction while using column aliases.
     * <code>
     *		$c->addAlias("alias1", TablePeer::TABLE_NAME);
     *		$c->addJoin(TablePeer::alias("alias1", TablePeer::PRIMARY_KEY_COLUMN), TablePeer::PRIMARY_KEY_COLUMN);
     * </code>
     * @param      string $alias The alias for the current table.
     * @param      string $column The column name for current table. (i.e. AuthorityPeer::COLUMN_NAME).
     * @return string
     */
    public static function alias($alias, $column)
    {
        return str_replace(AuthorityPeer::TABLE_NAME.'.', $alias.'.', $column);
    }

    /**
     * Add all the columns needed to create a new object.
     *
     * Note: any columns that were marked with lazyLoad="true" in the
     * XML schema will not be added to the select list and only loaded
     * on demand.
     *
     * @param      Criteria $criteria object containing the columns to add.
     * @param      string   $alias    optional table alias
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function addSelectColumns(Criteria $criteria, $alias = null)
    {
        if (null === $alias) {
            $criteria->addSelectColumn(AuthorityPeer::AUTHORITY_ID);
            $criteria->addSelectColumn(AuthorityPeer::NON_SORT_TEXT);
            $criteria->addSelectColumn(AuthorityPeer::SORT_TEXT);
            $criteria->addSelectColumn(AuthorityPeer::FULL_TEXT);
            $criteria->addSelectColumn(AuthorityPeer::AUTHORITY_TYPE);
            $criteria->addSelectColumn(AuthorityPeer::AUTHORITY_SUBTYPE);
            $criteria->addSelectColumn(AuthorityPeer::AUTHORITY_RECTYPE);
            $criteria->addSelectColumn(AuthorityPeer::AUTHORITY_STATUS);
            $criteria->addSelectColumn(AuthorityPeer::UNIMARC);
            $criteria->addSelectColumn(AuthorityPeer::EXT_DATA);
            $criteria->addSelectColumn(AuthorityPeer::AUTHORITY_LANG);
            $criteria->addSelectColumn(AuthorityPeer::AUTHORITY_CODLEVEL);
            $criteria->addSelectColumn(AuthorityPeer::PARENT_ID);
            $criteria->addSelectColumn(AuthorityPeer::SUBJECT_CLASS);
            $criteria->addSelectColumn(AuthorityPeer::CLASS_CODE);
            $criteria->addSelectColumn(AuthorityPeer::BID_SOURCE);
            $criteria->addSelectColumn(AuthorityPeer::BID);
            $criteria->addSelectColumn(AuthorityPeer::LAST_SBN_SYNC);
            $criteria->addSelectColumn(AuthorityPeer::DATE_CREATED);
            $criteria->addSelectColumn(AuthorityPeer::DATE_UPDATED);
            $criteria->addSelectColumn(AuthorityPeer::CREATED_BY);
            $criteria->addSelectColumn(AuthorityPeer::MODIFIED_BY);
        } else {
            $criteria->addSelectColumn($alias . '.authority_id');
            $criteria->addSelectColumn($alias . '.non_sort_text');
            $criteria->addSelectColumn($alias . '.sort_text');
            $criteria->addSelectColumn($alias . '.full_text');
            $criteria->addSelectColumn($alias . '.authority_type');
            $criteria->addSelectColumn($alias . '.authority_subtype');
            $criteria->addSelectColumn($alias . '.authority_rectype');
            $criteria->addSelectColumn($alias . '.authority_status');
            $criteria->addSelectColumn($alias . '.unimarc');
            $criteria->addSelectColumn($alias . '.ext_data');
            $criteria->addSelectColumn($alias . '.authority_lang');
            $criteria->addSelectColumn($alias . '.authority_codlevel');
            $criteria->addSelectColumn($alias . '.parent_id');
            $criteria->addSelectColumn($alias . '.subject_class');
            $criteria->addSelectColumn($alias . '.class_code');
            $criteria->addSelectColumn($alias . '.bid_source');
            $criteria->addSelectColumn($alias . '.bid');
            $criteria->addSelectColumn($alias . '.last_sbn_sync');
            $criteria->addSelectColumn($alias . '.date_created');
            $criteria->addSelectColumn($alias . '.date_updated');
            $criteria->addSelectColumn($alias . '.created_by');
            $criteria->addSelectColumn($alias . '.modified_by');
        }
    }

    /**
     * Returns the number of rows matching criteria.
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @return int Number of matching rows.
     */
    public static function doCount(Criteria $criteria, $distinct = false, PropelPDO $con = null)
    {
        // we may modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(AuthorityPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            AuthorityPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count
        $criteria->setDbName(AuthorityPeer::DATABASE_NAME); // Set the correct dbName

        if ($con === null) {
            $con = Propel::getConnection(AuthorityPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }
        // BasePeer returns a PDOStatement
        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }
    /**
     * Selects one object from the DB.
     *
     * @param      Criteria $criteria object used to create the SELECT statement.
     * @param      PropelPDO $con
     * @return Authority
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectOne(Criteria $criteria, PropelPDO $con = null)
    {
        $critcopy = clone $criteria;
        $critcopy->setLimit(1);
        $objects = AuthorityPeer::doSelect($critcopy, $con);
        if ($objects) {
            return $objects[0];
        }

        return null;
    }
    /**
     * Selects several row from the DB.
     *
     * @param      Criteria $criteria The Criteria object used to build the SELECT statement.
     * @param      PropelPDO $con
     * @return array           Array of selected Objects
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelect(Criteria $criteria, PropelPDO $con = null)
    {
        return AuthorityPeer::populateObjects(AuthorityPeer::doSelectStmt($criteria, $con));
    }
    /**
     * Prepares the Criteria object and uses the parent doSelect() method to execute a PDOStatement.
     *
     * Use this method directly if you want to work with an executed statement directly (for example
     * to perform your own object hydration).
     *
     * @param      Criteria $criteria The Criteria object used to build the SELECT statement.
     * @param      PropelPDO $con The connection to use
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     * @return PDOStatement The executed PDOStatement object.
     * @see        BasePeer::doSelect()
     */
    public static function doSelectStmt(Criteria $criteria, PropelPDO $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection(AuthorityPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        if (!$criteria->hasSelectClause()) {
            $criteria = clone $criteria;
            AuthorityPeer::addSelectColumns($criteria);
        }

        // Set the correct dbName
        $criteria->setDbName(AuthorityPeer::DATABASE_NAME);

        // BasePeer returns a PDOStatement
        return BasePeer::doSelect($criteria, $con);
    }
    /**
     * Adds an object to the instance pool.
     *
     * Propel keeps cached copies of objects in an instance pool when they are retrieved
     * from the database.  In some cases -- especially when you override doSelect*()
     * methods in your stub classes -- you may need to explicitly add objects
     * to the cache in order to ensure that the same objects are always returned by doSelect*()
     * and retrieveByPK*() calls.
     *
     * @param Authority $obj A Authority object.
     * @param      string $key (optional) key to use for instance map (for performance boost if key was already calculated externally).
     */
    public static function addInstanceToPool($obj, $key = null)
    {
        if (Propel::isInstancePoolingEnabled()) {
            if ($key === null) {
                $key = (string) $obj->getAuthorityId();
            } // if key === null
            AuthorityPeer::$instances[$key] = $obj;
        }
    }

    /**
     * Removes an object from the instance pool.
     *
     * Propel keeps cached copies of objects in an instance pool when they are retrieved
     * from the database.  In some cases -- especially when you override doDelete
     * methods in your stub classes -- you may need to explicitly remove objects
     * from the cache in order to prevent returning objects that no longer exist.
     *
     * @param      mixed $value A Authority object or a primary key value.
     *
     * @return void
     * @throws PropelException - if the value is invalid.
     */
    public static function removeInstanceFromPool($value)
    {
        if (Propel::isInstancePoolingEnabled() && $value !== null) {
            if (is_object($value) && $value instanceof Authority) {
                $key = (string) $value->getAuthorityId();
            } elseif (is_scalar($value)) {
                // assume we've been passed a primary key
                $key = (string) $value;
            } else {
                $e = new PropelException("Invalid value passed to removeInstanceFromPool().  Expected primary key or Authority object; got " . (is_object($value) ? get_class($value) . ' object.' : var_export($value,true)));
                throw $e;
            }

            unset(AuthorityPeer::$instances[$key]);
        }
    } // removeInstanceFromPool()

    /**
     * Retrieves a string version of the primary key from the DB resultset row that can be used to uniquely identify a row in this table.
     *
     * For tables with a single-column primary key, that simple pkey value will be returned.  For tables with
     * a multi-column primary key, a serialize()d version of the primary key will be returned.
     *
     * @param      string $key The key (@see getPrimaryKeyHash()) for this instance.
     * @return Authority Found object or null if 1) no instance exists for specified key or 2) instance pooling has been disabled.
     * @see        getPrimaryKeyHash()
     */
    public static function getInstanceFromPool($key)
    {
        if (Propel::isInstancePoolingEnabled()) {
            if (isset(AuthorityPeer::$instances[$key])) {
                return AuthorityPeer::$instances[$key];
            }
        }

        return null; // just to be explicit
    }

    /**
     * Clear the instance pool.
     *
     * @return void
     */
    public static function clearInstancePool($and_clear_all_references = false)
    {
      if ($and_clear_all_references) {
        foreach (AuthorityPeer::$instances as $instance) {
          $instance->clearAllReferences(true);
        }
      }
        AuthorityPeer::$instances = array();
    }

    /**
     * Method to invalidate the instance pool of all tables related to authority
     * by a foreign key with ON DELETE CASCADE
     */
    public static function clearRelatedInstancePool()
    {
    }

    /**
     * Retrieves a string version of the primary key from the DB resultset row that can be used to uniquely identify a row in this table.
     *
     * For tables with a single-column primary key, that simple pkey value will be returned.  For tables with
     * a multi-column primary key, a serialize()d version of the primary key will be returned.
     *
     * @param      array $row PropelPDO resultset row.
     * @param      int $startcol The 0-based offset for reading from the resultset row.
     * @return string A string version of PK or null if the components of primary key in result array are all null.
     */
    public static function getPrimaryKeyHashFromRow($row, $startcol = 0)
    {
        // If the PK cannot be derived from the row, return null.
        if ($row[$startcol] === null) {
            return null;
        }

        return (string) $row[$startcol];
    }

    /**
     * Retrieves the primary key from the DB resultset row
     * For tables with a single-column primary key, that simple pkey value will be returned.  For tables with
     * a multi-column primary key, an array of the primary key columns will be returned.
     *
     * @param      array $row PropelPDO resultset row.
     * @param      int $startcol The 0-based offset for reading from the resultset row.
     * @return mixed The primary key of the row
     */
    public static function getPrimaryKeyFromRow($row, $startcol = 0)
    {

        return (int) $row[$startcol];
    }

    /**
     * The returned array will contain objects of the default type or
     * objects that inherit from the default.
     *
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function populateObjects(PDOStatement $stmt)
    {
        $results = array();

        // set the class once to avoid overhead in the loop
        $cls = AuthorityPeer::getOMClass();
        // populate the object(s)
        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key = AuthorityPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj = AuthorityPeer::getInstanceFromPool($key))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj->hydrate($row, 0, true); // rehydrate
                $results[] = $obj;
            } else {
                $obj = new $cls();
                $obj->hydrate($row);
                $results[] = $obj;
                AuthorityPeer::addInstanceToPool($obj, $key);
            } // if key exists
        }
        $stmt->closeCursor();

        return $results;
    }
    /**
     * Populates an object of the default type or an object that inherit from the default.
     *
     * @param      array $row PropelPDO resultset row.
     * @param      int $startcol The 0-based offset for reading from the resultset row.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     * @return array (Authority object, last column rank)
     */
    public static function populateObject($row, $startcol = 0)
    {
        $key = AuthorityPeer::getPrimaryKeyHashFromRow($row, $startcol);
        if (null !== ($obj = AuthorityPeer::getInstanceFromPool($key))) {
            // We no longer rehydrate the object, since this can cause data loss.
            // See http://www.propelorm.org/ticket/509
            // $obj->hydrate($row, $startcol, true); // rehydrate
            $col = $startcol + AuthorityPeer::NUM_HYDRATE_COLUMNS;
        } else {
            $cls = AuthorityPeer::OM_CLASS;
            $obj = new $cls();
            $col = $obj->hydrate($row, $startcol);
            AuthorityPeer::addInstanceToPool($obj, $key);
        }

        return array($obj, $col);
    }


    /**
     * Returns the number of rows matching criteria, joining the related LibrarianRelatedByCreatedBy table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinLibrarianRelatedByCreatedBy(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(AuthorityPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            AuthorityPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(AuthorityPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(AuthorityPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(AuthorityPeer::CREATED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related LibrarianRelatedByModifiedBy table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinLibrarianRelatedByModifiedBy(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(AuthorityPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            AuthorityPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(AuthorityPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(AuthorityPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(AuthorityPeer::MODIFIED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Selects a collection of Authority objects pre-filled with their Librarian objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of Authority objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinLibrarianRelatedByCreatedBy(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(AuthorityPeer::DATABASE_NAME);
        }

        AuthorityPeer::addSelectColumns($criteria);
        $startcol = AuthorityPeer::NUM_HYDRATE_COLUMNS;
        LibrarianPeer::addSelectColumns($criteria);

        $criteria->addJoin(AuthorityPeer::CREATED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = AuthorityPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = AuthorityPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = AuthorityPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                AuthorityPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = LibrarianPeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = LibrarianPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = LibrarianPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    LibrarianPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (Authority) to $obj2 (Librarian)
                $obj2->addAuthorityRelatedByCreatedBy($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of Authority objects pre-filled with their Librarian objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of Authority objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinLibrarianRelatedByModifiedBy(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(AuthorityPeer::DATABASE_NAME);
        }

        AuthorityPeer::addSelectColumns($criteria);
        $startcol = AuthorityPeer::NUM_HYDRATE_COLUMNS;
        LibrarianPeer::addSelectColumns($criteria);

        $criteria->addJoin(AuthorityPeer::MODIFIED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = AuthorityPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = AuthorityPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = AuthorityPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                AuthorityPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = LibrarianPeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = LibrarianPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = LibrarianPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    LibrarianPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (Authority) to $obj2 (Librarian)
                $obj2->addAuthorityRelatedByModifiedBy($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Returns the number of rows matching criteria, joining all related tables
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAll(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(AuthorityPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            AuthorityPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(AuthorityPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(AuthorityPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(AuthorityPeer::CREATED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(AuthorityPeer::MODIFIED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }

    /**
     * Selects a collection of Authority objects pre-filled with all related objects.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of Authority objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAll(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(AuthorityPeer::DATABASE_NAME);
        }

        AuthorityPeer::addSelectColumns($criteria);
        $startcol2 = AuthorityPeer::NUM_HYDRATE_COLUMNS;

        LibrarianPeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + LibrarianPeer::NUM_HYDRATE_COLUMNS;

        LibrarianPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + LibrarianPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(AuthorityPeer::CREATED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(AuthorityPeer::MODIFIED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = AuthorityPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = AuthorityPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = AuthorityPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                AuthorityPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

            // Add objects for joined Librarian rows

            $key2 = LibrarianPeer::getPrimaryKeyHashFromRow($row, $startcol2);
            if ($key2 !== null) {
                $obj2 = LibrarianPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = LibrarianPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    LibrarianPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 loaded

                // Add the $obj1 (Authority) to the collection in $obj2 (Librarian)
                $obj2->addAuthorityRelatedByCreatedBy($obj1);
            } // if joined row not null

            // Add objects for joined Librarian rows

            $key3 = LibrarianPeer::getPrimaryKeyHashFromRow($row, $startcol3);
            if ($key3 !== null) {
                $obj3 = LibrarianPeer::getInstanceFromPool($key3);
                if (!$obj3) {

                    $cls = LibrarianPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    LibrarianPeer::addInstanceToPool($obj3, $key3);
                } // if obj3 loaded

                // Add the $obj1 (Authority) to the collection in $obj3 (Librarian)
                $obj3->addAuthorityRelatedByModifiedBy($obj1);
            } // if joined row not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Returns the number of rows matching criteria, joining the related LibrarianRelatedByCreatedBy table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptLibrarianRelatedByCreatedBy(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(AuthorityPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            AuthorityPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(AuthorityPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(AuthorityPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related LibrarianRelatedByModifiedBy table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptLibrarianRelatedByModifiedBy(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(AuthorityPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            AuthorityPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(AuthorityPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(AuthorityPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related AuthorityRelatedByParentId table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptAuthorityRelatedByParentId(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(AuthorityPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            AuthorityPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(AuthorityPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(AuthorityPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(AuthorityPeer::CREATED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(AuthorityPeer::MODIFIED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Selects a collection of Authority objects pre-filled with all related objects except LibrarianRelatedByCreatedBy.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of Authority objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptLibrarianRelatedByCreatedBy(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(AuthorityPeer::DATABASE_NAME);
        }

        AuthorityPeer::addSelectColumns($criteria);
        $startcol2 = AuthorityPeer::NUM_HYDRATE_COLUMNS;


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = AuthorityPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = AuthorityPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = AuthorityPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                AuthorityPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of Authority objects pre-filled with all related objects except LibrarianRelatedByModifiedBy.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of Authority objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptLibrarianRelatedByModifiedBy(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(AuthorityPeer::DATABASE_NAME);
        }

        AuthorityPeer::addSelectColumns($criteria);
        $startcol2 = AuthorityPeer::NUM_HYDRATE_COLUMNS;


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = AuthorityPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = AuthorityPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = AuthorityPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                AuthorityPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of Authority objects pre-filled with all related objects except AuthorityRelatedByParentId.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of Authority objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptAuthorityRelatedByParentId(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(AuthorityPeer::DATABASE_NAME);
        }

        AuthorityPeer::addSelectColumns($criteria);
        $startcol2 = AuthorityPeer::NUM_HYDRATE_COLUMNS;

        LibrarianPeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + LibrarianPeer::NUM_HYDRATE_COLUMNS;

        LibrarianPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + LibrarianPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(AuthorityPeer::CREATED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(AuthorityPeer::MODIFIED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = AuthorityPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = AuthorityPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = AuthorityPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                AuthorityPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

                // Add objects for joined Librarian rows

                $key2 = LibrarianPeer::getPrimaryKeyHashFromRow($row, $startcol2);
                if ($key2 !== null) {
                    $obj2 = LibrarianPeer::getInstanceFromPool($key2);
                    if (!$obj2) {

                        $cls = LibrarianPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    LibrarianPeer::addInstanceToPool($obj2, $key2);
                } // if $obj2 already loaded

                // Add the $obj1 (Authority) to the collection in $obj2 (Librarian)
                $obj2->addAuthorityRelatedByCreatedBy($obj1);

            } // if joined row is not null

                // Add objects for joined Librarian rows

                $key3 = LibrarianPeer::getPrimaryKeyHashFromRow($row, $startcol3);
                if ($key3 !== null) {
                    $obj3 = LibrarianPeer::getInstanceFromPool($key3);
                    if (!$obj3) {

                        $cls = LibrarianPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    LibrarianPeer::addInstanceToPool($obj3, $key3);
                } // if $obj3 already loaded

                // Add the $obj1 (Authority) to the collection in $obj3 (Librarian)
                $obj3->addAuthorityRelatedByModifiedBy($obj1);

            } // if joined row is not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }

    /**
     * Returns the TableMap related to this peer.
     * This method is not needed for general use but a specific application could have a need.
     * @return TableMap
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function getTableMap()
    {
        return Propel::getDatabaseMap(AuthorityPeer::DATABASE_NAME)->getTable(AuthorityPeer::TABLE_NAME);
    }

    /**
     * Add a TableMap instance to the database for this peer class.
     */
    public static function buildTableMap()
    {
      $dbMap = Propel::getDatabaseMap(BaseAuthorityPeer::DATABASE_NAME);
      if (!$dbMap->hasTable(BaseAuthorityPeer::TABLE_NAME)) {
        $dbMap->addTableObject(new \AuthorityTableMap());
      }
    }

    /**
     * The class that the Peer will make instances of.
     *
     *
     * @return string ClassName
     */
    public static function getOMClass($row = 0, $colnum = 0)
    {
        return AuthorityPeer::OM_CLASS;
    }

    /**
     * Performs an INSERT on the database, given a Authority or Criteria object.
     *
     * @param      mixed $values Criteria or Authority object containing data that is used to create the INSERT statement.
     * @param      PropelPDO $con the PropelPDO connection to use
     * @return mixed           The new primary key.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doInsert($values, PropelPDO $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection(AuthorityPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        if ($values instanceof Criteria) {
            $criteria = clone $values; // rename for clarity
        } else {
            $criteria = $values->buildCriteria(); // build Criteria from Authority object
        }

        if ($criteria->containsKey(AuthorityPeer::AUTHORITY_ID) && $criteria->keyContainsValue(AuthorityPeer::AUTHORITY_ID) ) {
            throw new PropelException('Cannot insert a value for auto-increment primary key ('.AuthorityPeer::AUTHORITY_ID.')');
        }


        // Set the correct dbName
        $criteria->setDbName(AuthorityPeer::DATABASE_NAME);

        try {
            // use transaction because $criteria could contain info
            // for more than one table (I guess, conceivably)
            $con->beginTransaction();
            $pk = BasePeer::doInsert($criteria, $con);
            $con->commit();
        } catch (Exception $e) {
            $con->rollBack();
            throw $e;
        }

        return $pk;
    }

    /**
     * Performs an UPDATE on the database, given a Authority or Criteria object.
     *
     * @param      mixed $values Criteria or Authority object containing data that is used to create the UPDATE statement.
     * @param      PropelPDO $con The connection to use (specify PropelPDO connection object to exert more control over transactions).
     * @return int             The number of affected rows (if supported by underlying database driver).
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doUpdate($values, PropelPDO $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection(AuthorityPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        $selectCriteria = new Criteria(AuthorityPeer::DATABASE_NAME);

        if ($values instanceof Criteria) {
            $criteria = clone $values; // rename for clarity

            $comparison = $criteria->getComparison(AuthorityPeer::AUTHORITY_ID);
            $value = $criteria->remove(AuthorityPeer::AUTHORITY_ID);
            if ($value) {
                $selectCriteria->add(AuthorityPeer::AUTHORITY_ID, $value, $comparison);
            } else {
                $selectCriteria->setPrimaryTableName(AuthorityPeer::TABLE_NAME);
            }

        } else { // $values is Authority object
            $criteria = $values->buildCriteria(); // gets full criteria
            $selectCriteria = $values->buildPkeyCriteria(); // gets criteria w/ primary key(s)
        }

        // set the correct dbName
        $criteria->setDbName(AuthorityPeer::DATABASE_NAME);

        return BasePeer::doUpdate($selectCriteria, $criteria, $con);
    }

    /**
     * Deletes all rows from the authority table.
     *
     * @param      PropelPDO $con the connection to use
     * @return int             The number of affected rows (if supported by underlying database driver).
     * @throws PropelException
     */
    public static function doDeleteAll(PropelPDO $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection(AuthorityPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }
        $affectedRows = 0; // initialize var to track total num of affected rows
        try {
            // use transaction because $criteria could contain info
            // for more than one table or we could emulating ON DELETE CASCADE, etc.
            $con->beginTransaction();
            $affectedRows += BasePeer::doDeleteAll(AuthorityPeer::TABLE_NAME, $con, AuthorityPeer::DATABASE_NAME);
            // Because this db requires some delete cascade/set null emulation, we have to
            // clear the cached instance *after* the emulation has happened (since
            // instances get re-added by the select statement contained therein).
            AuthorityPeer::clearInstancePool();
            AuthorityPeer::clearRelatedInstancePool();
            $con->commit();

            return $affectedRows;
        } catch (Exception $e) {
            $con->rollBack();
            throw $e;
        }
    }

    /**
     * Performs a DELETE on the database, given a Authority or Criteria object OR a primary key value.
     *
     * @param      mixed $values Criteria or Authority object or primary key or array of primary keys
     *              which is used to create the DELETE statement
     * @param      PropelPDO $con the connection to use
     * @return int The number of affected rows (if supported by underlying database driver).  This includes CASCADE-related rows
     *				if supported by native driver or if emulated using Propel.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
     public static function doDelete($values, PropelPDO $con = null)
     {
        if ($con === null) {
            $con = Propel::getConnection(AuthorityPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        if ($values instanceof Criteria) {
            // invalidate the cache for all objects of this type, since we have no
            // way of knowing (without running a query) what objects should be invalidated
            // from the cache based on this Criteria.
            AuthorityPeer::clearInstancePool();
            // rename for clarity
            $criteria = clone $values;
        } elseif ($values instanceof Authority) { // it's a model object
            // invalidate the cache for this single object
            AuthorityPeer::removeInstanceFromPool($values);
            // create criteria based on pk values
            $criteria = $values->buildPkeyCriteria();
        } else { // it's a primary key, or an array of pks
            $criteria = new Criteria(AuthorityPeer::DATABASE_NAME);
            $criteria->add(AuthorityPeer::AUTHORITY_ID, (array) $values, Criteria::IN);
            // invalidate the cache for this object(s)
            foreach ((array) $values as $singleval) {
                AuthorityPeer::removeInstanceFromPool($singleval);
            }
        }

        // Set the correct dbName
        $criteria->setDbName(AuthorityPeer::DATABASE_NAME);

        $affectedRows = 0; // initialize var to track total num of affected rows

        try {
            // use transaction because $criteria could contain info
            // for more than one table or we could emulating ON DELETE CASCADE, etc.
            $con->beginTransaction();

            $affectedRows += BasePeer::doDelete($criteria, $con);
            AuthorityPeer::clearRelatedInstancePool();
            $con->commit();

            return $affectedRows;
        } catch (Exception $e) {
            $con->rollBack();
            throw $e;
        }
    }

    /**
     * Validates all modified columns of given Authority object.
     * If parameter $columns is either a single column name or an array of column names
     * than only those columns are validated.
     *
     * NOTICE: This does not apply to primary or foreign keys for now.
     *
     * @param Authority $obj The object to validate.
     * @param      mixed $cols Column name or array of column names.
     *
     * @return mixed TRUE if all columns are valid or the error message of the first invalid column.
     */
    public static function doValidate($obj, $cols = null)
    {
        $columns = array();

        if ($cols) {
            $dbMap = Propel::getDatabaseMap(AuthorityPeer::DATABASE_NAME);
            $tableMap = $dbMap->getTable(AuthorityPeer::TABLE_NAME);

            if (! is_array($cols)) {
                $cols = array($cols);
            }

            foreach ($cols as $colName) {
                if ($tableMap->hasColumn($colName)) {
                    $get = 'get' . $tableMap->getColumn($colName)->getPhpName();
                    $columns[$colName] = $obj->$get();
                }
            }
        } else {

        }

        return BasePeer::doValidate(AuthorityPeer::DATABASE_NAME, AuthorityPeer::TABLE_NAME, $columns);
    }

    /**
     * Retrieve a single object by pkey.
     *
     * @param int $pk the primary key.
     * @param      PropelPDO $con the connection to use
     * @return Authority
     */
    public static function retrieveByPK($pk, PropelPDO $con = null)
    {

        if (null !== ($obj = AuthorityPeer::getInstanceFromPool((string) $pk))) {
            return $obj;
        }

        if ($con === null) {
            $con = Propel::getConnection(AuthorityPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria = new Criteria(AuthorityPeer::DATABASE_NAME);
        $criteria->add(AuthorityPeer::AUTHORITY_ID, $pk);

        $v = AuthorityPeer::doSelect($criteria, $con);

        return !empty($v) > 0 ? $v[0] : null;
    }

    /**
     * Retrieve multiple objects by pkey.
     *
     * @param      array $pks List of primary keys
     * @param      PropelPDO $con the connection to use
     * @return Authority[]
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function retrieveByPKs($pks, PropelPDO $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection(AuthorityPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $objs = null;
        if (empty($pks)) {
            $objs = array();
        } else {
            $criteria = new Criteria(AuthorityPeer::DATABASE_NAME);
            $criteria->add(AuthorityPeer::AUTHORITY_ID, $pks, Criteria::IN);
            $objs = AuthorityPeer::doSelect($criteria, $con);
        }

        return $objs;
    }

} // BaseAuthorityPeer

// This is the static code needed to register the TableMap for this table with the main Propel class.
//
BaseAuthorityPeer::buildTableMap();

