<?php


/**
 * Base static class for performing query and update operations on the 'item_action' table.
 *
 *
 *
 * @package propel.generator.clavis.om
 */
abstract class BaseItemActionPeer
{

    /** the default database name for this class */
    const DATABASE_NAME = 'clavis';

    /** the table name for this class */
    const TABLE_NAME = 'item_action';

    /** the related Propel class for this table */
    const OM_CLASS = 'ItemAction';

    /** the related TableMap class for this table */
    const TM_CLASS = 'ItemActionTableMap';

    /** The total number of columns. */
    const NUM_COLUMNS = 15;

    /** The number of lazy-loaded columns. */
    const NUM_LAZY_LOAD_COLUMNS = 0;

    /** The number of columns to hydrate (NUM_COLUMNS - NUM_LAZY_LOAD_COLUMNS) */
    const NUM_HYDRATE_COLUMNS = 15;

    /** the column name for the item_action_id field */
    const ITEM_ACTION_ID = 'item_action.item_action_id';

    /** the column name for the library_id field */
    const LIBRARY_ID = 'item_action.library_id';

    /** the column name for the item_id field */
    const ITEM_ID = 'item_action.item_id';

    /** the column name for the patron_id field */
    const PATRON_ID = 'item_action.patron_id';

    /** the column name for the external_library_id field */
    const EXTERNAL_LIBRARY_ID = 'item_action.external_library_id';

    /** the column name for the librarian_id field */
    const LIBRARIAN_ID = 'item_action.librarian_id';

    /** the column name for the action_type field */
    const ACTION_TYPE = 'item_action.action_type';

    /** the column name for the action_date field */
    const ACTION_DATE = 'item_action.action_date';

    /** the column name for the from_library_id field */
    const FROM_LIBRARY_ID = 'item_action.from_library_id';

    /** the column name for the to_library_id field */
    const TO_LIBRARY_ID = 'item_action.to_library_id';

    /** the column name for the action_note field */
    const ACTION_NOTE = 'item_action.action_note';

    /** the column name for the date_created field */
    const DATE_CREATED = 'item_action.date_created';

    /** the column name for the date_updated field */
    const DATE_UPDATED = 'item_action.date_updated';

    /** the column name for the created_by field */
    const CREATED_BY = 'item_action.created_by';

    /** the column name for the modified_by field */
    const MODIFIED_BY = 'item_action.modified_by';

    /** The default string format for model objects of the related table **/
    const DEFAULT_STRING_FORMAT = 'YAML';

    /**
     * An identity map to hold any loaded instances of ItemAction objects.
     * This must be public so that other peer classes can access this when hydrating from JOIN
     * queries.
     * @var        array ItemAction[]
     */
    public static $instances = array();


    /**
     * holds an array of fieldnames
     *
     * first dimension keys are the type constants
     * e.g. ItemActionPeer::$fieldNames[ItemActionPeer::TYPE_PHPNAME][0] = 'Id'
     */
    protected static $fieldNames = array (
        BasePeer::TYPE_PHPNAME => array ('ItemActionId', 'LibraryId', 'ItemId', 'PatronId', 'ExternalLibraryId', 'LibrarianId', 'ActionType', 'ActionDate', 'FromLibraryId', 'ToLibraryId', 'ActionNote', 'DateCreated', 'DateUpdated', 'CreatedBy', 'ModifiedBy', ),
        BasePeer::TYPE_STUDLYPHPNAME => array ('itemActionId', 'libraryId', 'itemId', 'patronId', 'externalLibraryId', 'librarianId', 'actionType', 'actionDate', 'fromLibraryId', 'toLibraryId', 'actionNote', 'dateCreated', 'dateUpdated', 'createdBy', 'modifiedBy', ),
        BasePeer::TYPE_COLNAME => array (ItemActionPeer::ITEM_ACTION_ID, ItemActionPeer::LIBRARY_ID, ItemActionPeer::ITEM_ID, ItemActionPeer::PATRON_ID, ItemActionPeer::EXTERNAL_LIBRARY_ID, ItemActionPeer::LIBRARIAN_ID, ItemActionPeer::ACTION_TYPE, ItemActionPeer::ACTION_DATE, ItemActionPeer::FROM_LIBRARY_ID, ItemActionPeer::TO_LIBRARY_ID, ItemActionPeer::ACTION_NOTE, ItemActionPeer::DATE_CREATED, ItemActionPeer::DATE_UPDATED, ItemActionPeer::CREATED_BY, ItemActionPeer::MODIFIED_BY, ),
        BasePeer::TYPE_RAW_COLNAME => array ('ITEM_ACTION_ID', 'LIBRARY_ID', 'ITEM_ID', 'PATRON_ID', 'EXTERNAL_LIBRARY_ID', 'LIBRARIAN_ID', 'ACTION_TYPE', 'ACTION_DATE', 'FROM_LIBRARY_ID', 'TO_LIBRARY_ID', 'ACTION_NOTE', 'DATE_CREATED', 'DATE_UPDATED', 'CREATED_BY', 'MODIFIED_BY', ),
        BasePeer::TYPE_FIELDNAME => array ('item_action_id', 'library_id', 'item_id', 'patron_id', 'external_library_id', 'librarian_id', 'action_type', 'action_date', 'from_library_id', 'to_library_id', 'action_note', 'date_created', 'date_updated', 'created_by', 'modified_by', ),
        BasePeer::TYPE_NUM => array (0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, )
    );

    /**
     * holds an array of keys for quick access to the fieldnames array
     *
     * first dimension keys are the type constants
     * e.g. ItemActionPeer::$fieldNames[BasePeer::TYPE_PHPNAME]['Id'] = 0
     */
    protected static $fieldKeys = array (
        BasePeer::TYPE_PHPNAME => array ('ItemActionId' => 0, 'LibraryId' => 1, 'ItemId' => 2, 'PatronId' => 3, 'ExternalLibraryId' => 4, 'LibrarianId' => 5, 'ActionType' => 6, 'ActionDate' => 7, 'FromLibraryId' => 8, 'ToLibraryId' => 9, 'ActionNote' => 10, 'DateCreated' => 11, 'DateUpdated' => 12, 'CreatedBy' => 13, 'ModifiedBy' => 14, ),
        BasePeer::TYPE_STUDLYPHPNAME => array ('itemActionId' => 0, 'libraryId' => 1, 'itemId' => 2, 'patronId' => 3, 'externalLibraryId' => 4, 'librarianId' => 5, 'actionType' => 6, 'actionDate' => 7, 'fromLibraryId' => 8, 'toLibraryId' => 9, 'actionNote' => 10, 'dateCreated' => 11, 'dateUpdated' => 12, 'createdBy' => 13, 'modifiedBy' => 14, ),
        BasePeer::TYPE_COLNAME => array (ItemActionPeer::ITEM_ACTION_ID => 0, ItemActionPeer::LIBRARY_ID => 1, ItemActionPeer::ITEM_ID => 2, ItemActionPeer::PATRON_ID => 3, ItemActionPeer::EXTERNAL_LIBRARY_ID => 4, ItemActionPeer::LIBRARIAN_ID => 5, ItemActionPeer::ACTION_TYPE => 6, ItemActionPeer::ACTION_DATE => 7, ItemActionPeer::FROM_LIBRARY_ID => 8, ItemActionPeer::TO_LIBRARY_ID => 9, ItemActionPeer::ACTION_NOTE => 10, ItemActionPeer::DATE_CREATED => 11, ItemActionPeer::DATE_UPDATED => 12, ItemActionPeer::CREATED_BY => 13, ItemActionPeer::MODIFIED_BY => 14, ),
        BasePeer::TYPE_RAW_COLNAME => array ('ITEM_ACTION_ID' => 0, 'LIBRARY_ID' => 1, 'ITEM_ID' => 2, 'PATRON_ID' => 3, 'EXTERNAL_LIBRARY_ID' => 4, 'LIBRARIAN_ID' => 5, 'ACTION_TYPE' => 6, 'ACTION_DATE' => 7, 'FROM_LIBRARY_ID' => 8, 'TO_LIBRARY_ID' => 9, 'ACTION_NOTE' => 10, 'DATE_CREATED' => 11, 'DATE_UPDATED' => 12, 'CREATED_BY' => 13, 'MODIFIED_BY' => 14, ),
        BasePeer::TYPE_FIELDNAME => array ('item_action_id' => 0, 'library_id' => 1, 'item_id' => 2, 'patron_id' => 3, 'external_library_id' => 4, 'librarian_id' => 5, 'action_type' => 6, 'action_date' => 7, 'from_library_id' => 8, 'to_library_id' => 9, 'action_note' => 10, 'date_created' => 11, 'date_updated' => 12, 'created_by' => 13, 'modified_by' => 14, ),
        BasePeer::TYPE_NUM => array (0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, )
    );

    /**
     * Translates a fieldname to another type
     *
     * @param      string $name field name
     * @param      string $fromType One of the class type constants BasePeer::TYPE_PHPNAME, BasePeer::TYPE_STUDLYPHPNAME
     *                         BasePeer::TYPE_COLNAME, BasePeer::TYPE_FIELDNAME, BasePeer::TYPE_NUM
     * @param      string $toType   One of the class type constants
     * @return string          translated name of the field.
     * @throws PropelException - if the specified name could not be found in the fieldname mappings.
     */
    public static function translateFieldName($name, $fromType, $toType)
    {
        $toNames = ItemActionPeer::getFieldNames($toType);
        $key = isset(ItemActionPeer::$fieldKeys[$fromType][$name]) ? ItemActionPeer::$fieldKeys[$fromType][$name] : null;
        if ($key === null) {
            throw new PropelException("'$name' could not be found in the field names of type '$fromType'. These are: " . print_r(ItemActionPeer::$fieldKeys[$fromType], true));
        }

        return $toNames[$key];
    }

    /**
     * Returns an array of field names.
     *
     * @param      string $type The type of fieldnames to return:
     *                      One of the class type constants BasePeer::TYPE_PHPNAME, BasePeer::TYPE_STUDLYPHPNAME
     *                      BasePeer::TYPE_COLNAME, BasePeer::TYPE_FIELDNAME, BasePeer::TYPE_NUM
     * @return array           A list of field names
     * @throws PropelException - if the type is not valid.
     */
    public static function getFieldNames($type = BasePeer::TYPE_PHPNAME)
    {
        if (!array_key_exists($type, ItemActionPeer::$fieldNames)) {
            throw new PropelException('Method getFieldNames() expects the parameter $type to be one of the class constants BasePeer::TYPE_PHPNAME, BasePeer::TYPE_STUDLYPHPNAME, BasePeer::TYPE_COLNAME, BasePeer::TYPE_FIELDNAME, BasePeer::TYPE_NUM. ' . $type . ' was given.');
        }

        return ItemActionPeer::$fieldNames[$type];
    }

    /**
     * Convenience method which changes table.column to alias.column.
     *
     * Using this method you can maintain SQL abstraction while using column aliases.
     * <code>
     *		$c->addAlias("alias1", TablePeer::TABLE_NAME);
     *		$c->addJoin(TablePeer::alias("alias1", TablePeer::PRIMARY_KEY_COLUMN), TablePeer::PRIMARY_KEY_COLUMN);
     * </code>
     * @param      string $alias The alias for the current table.
     * @param      string $column The column name for current table. (i.e. ItemActionPeer::COLUMN_NAME).
     * @return string
     */
    public static function alias($alias, $column)
    {
        return str_replace(ItemActionPeer::TABLE_NAME.'.', $alias.'.', $column);
    }

    /**
     * Add all the columns needed to create a new object.
     *
     * Note: any columns that were marked with lazyLoad="true" in the
     * XML schema will not be added to the select list and only loaded
     * on demand.
     *
     * @param      Criteria $criteria object containing the columns to add.
     * @param      string   $alias    optional table alias
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function addSelectColumns(Criteria $criteria, $alias = null)
    {
        if (null === $alias) {
            $criteria->addSelectColumn(ItemActionPeer::ITEM_ACTION_ID);
            $criteria->addSelectColumn(ItemActionPeer::LIBRARY_ID);
            $criteria->addSelectColumn(ItemActionPeer::ITEM_ID);
            $criteria->addSelectColumn(ItemActionPeer::PATRON_ID);
            $criteria->addSelectColumn(ItemActionPeer::EXTERNAL_LIBRARY_ID);
            $criteria->addSelectColumn(ItemActionPeer::LIBRARIAN_ID);
            $criteria->addSelectColumn(ItemActionPeer::ACTION_TYPE);
            $criteria->addSelectColumn(ItemActionPeer::ACTION_DATE);
            $criteria->addSelectColumn(ItemActionPeer::FROM_LIBRARY_ID);
            $criteria->addSelectColumn(ItemActionPeer::TO_LIBRARY_ID);
            $criteria->addSelectColumn(ItemActionPeer::ACTION_NOTE);
            $criteria->addSelectColumn(ItemActionPeer::DATE_CREATED);
            $criteria->addSelectColumn(ItemActionPeer::DATE_UPDATED);
            $criteria->addSelectColumn(ItemActionPeer::CREATED_BY);
            $criteria->addSelectColumn(ItemActionPeer::MODIFIED_BY);
        } else {
            $criteria->addSelectColumn($alias . '.item_action_id');
            $criteria->addSelectColumn($alias . '.library_id');
            $criteria->addSelectColumn($alias . '.item_id');
            $criteria->addSelectColumn($alias . '.patron_id');
            $criteria->addSelectColumn($alias . '.external_library_id');
            $criteria->addSelectColumn($alias . '.librarian_id');
            $criteria->addSelectColumn($alias . '.action_type');
            $criteria->addSelectColumn($alias . '.action_date');
            $criteria->addSelectColumn($alias . '.from_library_id');
            $criteria->addSelectColumn($alias . '.to_library_id');
            $criteria->addSelectColumn($alias . '.action_note');
            $criteria->addSelectColumn($alias . '.date_created');
            $criteria->addSelectColumn($alias . '.date_updated');
            $criteria->addSelectColumn($alias . '.created_by');
            $criteria->addSelectColumn($alias . '.modified_by');
        }
    }

    /**
     * Returns the number of rows matching criteria.
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @return int Number of matching rows.
     */
    public static function doCount(Criteria $criteria, $distinct = false, PropelPDO $con = null)
    {
        // we may modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(ItemActionPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            ItemActionPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count
        $criteria->setDbName(ItemActionPeer::DATABASE_NAME); // Set the correct dbName

        if ($con === null) {
            $con = Propel::getConnection(ItemActionPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }
        // BasePeer returns a PDOStatement
        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }
    /**
     * Selects one object from the DB.
     *
     * @param      Criteria $criteria object used to create the SELECT statement.
     * @param      PropelPDO $con
     * @return ItemAction
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectOne(Criteria $criteria, PropelPDO $con = null)
    {
        $critcopy = clone $criteria;
        $critcopy->setLimit(1);
        $objects = ItemActionPeer::doSelect($critcopy, $con);
        if ($objects) {
            return $objects[0];
        }

        return null;
    }
    /**
     * Selects several row from the DB.
     *
     * @param      Criteria $criteria The Criteria object used to build the SELECT statement.
     * @param      PropelPDO $con
     * @return array           Array of selected Objects
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelect(Criteria $criteria, PropelPDO $con = null)
    {
        return ItemActionPeer::populateObjects(ItemActionPeer::doSelectStmt($criteria, $con));
    }
    /**
     * Prepares the Criteria object and uses the parent doSelect() method to execute a PDOStatement.
     *
     * Use this method directly if you want to work with an executed statement directly (for example
     * to perform your own object hydration).
     *
     * @param      Criteria $criteria The Criteria object used to build the SELECT statement.
     * @param      PropelPDO $con The connection to use
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     * @return PDOStatement The executed PDOStatement object.
     * @see        BasePeer::doSelect()
     */
    public static function doSelectStmt(Criteria $criteria, PropelPDO $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection(ItemActionPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        if (!$criteria->hasSelectClause()) {
            $criteria = clone $criteria;
            ItemActionPeer::addSelectColumns($criteria);
        }

        // Set the correct dbName
        $criteria->setDbName(ItemActionPeer::DATABASE_NAME);

        // BasePeer returns a PDOStatement
        return BasePeer::doSelect($criteria, $con);
    }
    /**
     * Adds an object to the instance pool.
     *
     * Propel keeps cached copies of objects in an instance pool when they are retrieved
     * from the database.  In some cases -- especially when you override doSelect*()
     * methods in your stub classes -- you may need to explicitly add objects
     * to the cache in order to ensure that the same objects are always returned by doSelect*()
     * and retrieveByPK*() calls.
     *
     * @param ItemAction $obj A ItemAction object.
     * @param      string $key (optional) key to use for instance map (for performance boost if key was already calculated externally).
     */
    public static function addInstanceToPool($obj, $key = null)
    {
        if (Propel::isInstancePoolingEnabled()) {
            if ($key === null) {
                $key = (string) $obj->getItemActionId();
            } // if key === null
            ItemActionPeer::$instances[$key] = $obj;
        }
    }

    /**
     * Removes an object from the instance pool.
     *
     * Propel keeps cached copies of objects in an instance pool when they are retrieved
     * from the database.  In some cases -- especially when you override doDelete
     * methods in your stub classes -- you may need to explicitly remove objects
     * from the cache in order to prevent returning objects that no longer exist.
     *
     * @param      mixed $value A ItemAction object or a primary key value.
     *
     * @return void
     * @throws PropelException - if the value is invalid.
     */
    public static function removeInstanceFromPool($value)
    {
        if (Propel::isInstancePoolingEnabled() && $value !== null) {
            if (is_object($value) && $value instanceof ItemAction) {
                $key = (string) $value->getItemActionId();
            } elseif (is_scalar($value)) {
                // assume we've been passed a primary key
                $key = (string) $value;
            } else {
                $e = new PropelException("Invalid value passed to removeInstanceFromPool().  Expected primary key or ItemAction object; got " . (is_object($value) ? get_class($value) . ' object.' : var_export($value,true)));
                throw $e;
            }

            unset(ItemActionPeer::$instances[$key]);
        }
    } // removeInstanceFromPool()

    /**
     * Retrieves a string version of the primary key from the DB resultset row that can be used to uniquely identify a row in this table.
     *
     * For tables with a single-column primary key, that simple pkey value will be returned.  For tables with
     * a multi-column primary key, a serialize()d version of the primary key will be returned.
     *
     * @param      string $key The key (@see getPrimaryKeyHash()) for this instance.
     * @return ItemAction Found object or null if 1) no instance exists for specified key or 2) instance pooling has been disabled.
     * @see        getPrimaryKeyHash()
     */
    public static function getInstanceFromPool($key)
    {
        if (Propel::isInstancePoolingEnabled()) {
            if (isset(ItemActionPeer::$instances[$key])) {
                return ItemActionPeer::$instances[$key];
            }
        }

        return null; // just to be explicit
    }

    /**
     * Clear the instance pool.
     *
     * @return void
     */
    public static function clearInstancePool($and_clear_all_references = false)
    {
      if ($and_clear_all_references) {
        foreach (ItemActionPeer::$instances as $instance) {
          $instance->clearAllReferences(true);
        }
      }
        ItemActionPeer::$instances = array();
    }

    /**
     * Method to invalidate the instance pool of all tables related to item_action
     * by a foreign key with ON DELETE CASCADE
     */
    public static function clearRelatedInstancePool()
    {
    }

    /**
     * Retrieves a string version of the primary key from the DB resultset row that can be used to uniquely identify a row in this table.
     *
     * For tables with a single-column primary key, that simple pkey value will be returned.  For tables with
     * a multi-column primary key, a serialize()d version of the primary key will be returned.
     *
     * @param      array $row PropelPDO resultset row.
     * @param      int $startcol The 0-based offset for reading from the resultset row.
     * @return string A string version of PK or null if the components of primary key in result array are all null.
     */
    public static function getPrimaryKeyHashFromRow($row, $startcol = 0)
    {
        // If the PK cannot be derived from the row, return null.
        if ($row[$startcol] === null) {
            return null;
        }

        return (string) $row[$startcol];
    }

    /**
     * Retrieves the primary key from the DB resultset row
     * For tables with a single-column primary key, that simple pkey value will be returned.  For tables with
     * a multi-column primary key, an array of the primary key columns will be returned.
     *
     * @param      array $row PropelPDO resultset row.
     * @param      int $startcol The 0-based offset for reading from the resultset row.
     * @return mixed The primary key of the row
     */
    public static function getPrimaryKeyFromRow($row, $startcol = 0)
    {

        return (int) $row[$startcol];
    }

    /**
     * The returned array will contain objects of the default type or
     * objects that inherit from the default.
     *
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function populateObjects(PDOStatement $stmt)
    {
        $results = array();

        // set the class once to avoid overhead in the loop
        $cls = ItemActionPeer::getOMClass();
        // populate the object(s)
        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key = ItemActionPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj = ItemActionPeer::getInstanceFromPool($key))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj->hydrate($row, 0, true); // rehydrate
                $results[] = $obj;
            } else {
                $obj = new $cls();
                $obj->hydrate($row);
                $results[] = $obj;
                ItemActionPeer::addInstanceToPool($obj, $key);
            } // if key exists
        }
        $stmt->closeCursor();

        return $results;
    }
    /**
     * Populates an object of the default type or an object that inherit from the default.
     *
     * @param      array $row PropelPDO resultset row.
     * @param      int $startcol The 0-based offset for reading from the resultset row.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     * @return array (ItemAction object, last column rank)
     */
    public static function populateObject($row, $startcol = 0)
    {
        $key = ItemActionPeer::getPrimaryKeyHashFromRow($row, $startcol);
        if (null !== ($obj = ItemActionPeer::getInstanceFromPool($key))) {
            // We no longer rehydrate the object, since this can cause data loss.
            // See http://www.propelorm.org/ticket/509
            // $obj->hydrate($row, $startcol, true); // rehydrate
            $col = $startcol + ItemActionPeer::NUM_HYDRATE_COLUMNS;
        } else {
            $cls = ItemActionPeer::OM_CLASS;
            $obj = new $cls();
            $col = $obj->hydrate($row, $startcol);
            ItemActionPeer::addInstanceToPool($obj, $key);
        }

        return array($obj, $col);
    }


    /**
     * Returns the number of rows matching criteria, joining the related LibrarianRelatedByCreatedBy table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinLibrarianRelatedByCreatedBy(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(ItemActionPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            ItemActionPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(ItemActionPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(ItemActionPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(ItemActionPeer::CREATED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related LibrarianRelatedByModifiedBy table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinLibrarianRelatedByModifiedBy(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(ItemActionPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            ItemActionPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(ItemActionPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(ItemActionPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(ItemActionPeer::MODIFIED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related Item table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinItem(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(ItemActionPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            ItemActionPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(ItemActionPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(ItemActionPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(ItemActionPeer::ITEM_ID, ItemPeer::ITEM_ID, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related Patron table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinPatron(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(ItemActionPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            ItemActionPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(ItemActionPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(ItemActionPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(ItemActionPeer::PATRON_ID, PatronPeer::PATRON_ID, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related LibraryRelatedByExternalLibraryId table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinLibraryRelatedByExternalLibraryId(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(ItemActionPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            ItemActionPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(ItemActionPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(ItemActionPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(ItemActionPeer::EXTERNAL_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related LibraryRelatedByLibraryId table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinLibraryRelatedByLibraryId(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(ItemActionPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            ItemActionPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(ItemActionPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(ItemActionPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(ItemActionPeer::LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related LibraryRelatedByFromLibraryId table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinLibraryRelatedByFromLibraryId(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(ItemActionPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            ItemActionPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(ItemActionPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(ItemActionPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(ItemActionPeer::FROM_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related LibraryRelatedByToLibraryId table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinLibraryRelatedByToLibraryId(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(ItemActionPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            ItemActionPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(ItemActionPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(ItemActionPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(ItemActionPeer::TO_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Selects a collection of ItemAction objects pre-filled with their Librarian objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of ItemAction objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinLibrarianRelatedByCreatedBy(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(ItemActionPeer::DATABASE_NAME);
        }

        ItemActionPeer::addSelectColumns($criteria);
        $startcol = ItemActionPeer::NUM_HYDRATE_COLUMNS;
        LibrarianPeer::addSelectColumns($criteria);

        $criteria->addJoin(ItemActionPeer::CREATED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = ItemActionPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = ItemActionPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = ItemActionPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                ItemActionPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = LibrarianPeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = LibrarianPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = LibrarianPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    LibrarianPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (ItemAction) to $obj2 (Librarian)
                $obj2->addItemActionRelatedByCreatedBy($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of ItemAction objects pre-filled with their Librarian objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of ItemAction objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinLibrarianRelatedByModifiedBy(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(ItemActionPeer::DATABASE_NAME);
        }

        ItemActionPeer::addSelectColumns($criteria);
        $startcol = ItemActionPeer::NUM_HYDRATE_COLUMNS;
        LibrarianPeer::addSelectColumns($criteria);

        $criteria->addJoin(ItemActionPeer::MODIFIED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = ItemActionPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = ItemActionPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = ItemActionPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                ItemActionPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = LibrarianPeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = LibrarianPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = LibrarianPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    LibrarianPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (ItemAction) to $obj2 (Librarian)
                $obj2->addItemActionRelatedByModifiedBy($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of ItemAction objects pre-filled with their Item objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of ItemAction objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinItem(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(ItemActionPeer::DATABASE_NAME);
        }

        ItemActionPeer::addSelectColumns($criteria);
        $startcol = ItemActionPeer::NUM_HYDRATE_COLUMNS;
        ItemPeer::addSelectColumns($criteria);

        $criteria->addJoin(ItemActionPeer::ITEM_ID, ItemPeer::ITEM_ID, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = ItemActionPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = ItemActionPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = ItemActionPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                ItemActionPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = ItemPeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = ItemPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = ItemPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    ItemPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (ItemAction) to $obj2 (Item)
                $obj2->addItemAction($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of ItemAction objects pre-filled with their Patron objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of ItemAction objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinPatron(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(ItemActionPeer::DATABASE_NAME);
        }

        ItemActionPeer::addSelectColumns($criteria);
        $startcol = ItemActionPeer::NUM_HYDRATE_COLUMNS;
        PatronPeer::addSelectColumns($criteria);

        $criteria->addJoin(ItemActionPeer::PATRON_ID, PatronPeer::PATRON_ID, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = ItemActionPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = ItemActionPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = ItemActionPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                ItemActionPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = PatronPeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = PatronPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = PatronPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    PatronPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (ItemAction) to $obj2 (Patron)
                $obj2->addItemAction($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of ItemAction objects pre-filled with their Library objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of ItemAction objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinLibraryRelatedByExternalLibraryId(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(ItemActionPeer::DATABASE_NAME);
        }

        ItemActionPeer::addSelectColumns($criteria);
        $startcol = ItemActionPeer::NUM_HYDRATE_COLUMNS;
        LibraryPeer::addSelectColumns($criteria);

        $criteria->addJoin(ItemActionPeer::EXTERNAL_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = ItemActionPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = ItemActionPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = ItemActionPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                ItemActionPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = LibraryPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = LibraryPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    LibraryPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (ItemAction) to $obj2 (Library)
                $obj2->addItemActionRelatedByExternalLibraryId($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of ItemAction objects pre-filled with their Library objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of ItemAction objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinLibraryRelatedByLibraryId(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(ItemActionPeer::DATABASE_NAME);
        }

        ItemActionPeer::addSelectColumns($criteria);
        $startcol = ItemActionPeer::NUM_HYDRATE_COLUMNS;
        LibraryPeer::addSelectColumns($criteria);

        $criteria->addJoin(ItemActionPeer::LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = ItemActionPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = ItemActionPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = ItemActionPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                ItemActionPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = LibraryPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = LibraryPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    LibraryPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (ItemAction) to $obj2 (Library)
                $obj2->addItemActionRelatedByLibraryId($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of ItemAction objects pre-filled with their Library objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of ItemAction objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinLibraryRelatedByFromLibraryId(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(ItemActionPeer::DATABASE_NAME);
        }

        ItemActionPeer::addSelectColumns($criteria);
        $startcol = ItemActionPeer::NUM_HYDRATE_COLUMNS;
        LibraryPeer::addSelectColumns($criteria);

        $criteria->addJoin(ItemActionPeer::FROM_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = ItemActionPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = ItemActionPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = ItemActionPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                ItemActionPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = LibraryPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = LibraryPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    LibraryPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (ItemAction) to $obj2 (Library)
                $obj2->addItemActionRelatedByFromLibraryId($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of ItemAction objects pre-filled with their Library objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of ItemAction objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinLibraryRelatedByToLibraryId(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(ItemActionPeer::DATABASE_NAME);
        }

        ItemActionPeer::addSelectColumns($criteria);
        $startcol = ItemActionPeer::NUM_HYDRATE_COLUMNS;
        LibraryPeer::addSelectColumns($criteria);

        $criteria->addJoin(ItemActionPeer::TO_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = ItemActionPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = ItemActionPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = ItemActionPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                ItemActionPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = LibraryPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = LibraryPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    LibraryPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (ItemAction) to $obj2 (Library)
                $obj2->addItemActionRelatedByToLibraryId($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Returns the number of rows matching criteria, joining all related tables
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAll(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(ItemActionPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            ItemActionPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(ItemActionPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(ItemActionPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(ItemActionPeer::CREATED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::MODIFIED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::ITEM_ID, ItemPeer::ITEM_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::PATRON_ID, PatronPeer::PATRON_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::EXTERNAL_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::FROM_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::TO_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }

    /**
     * Selects a collection of ItemAction objects pre-filled with all related objects.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of ItemAction objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAll(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(ItemActionPeer::DATABASE_NAME);
        }

        ItemActionPeer::addSelectColumns($criteria);
        $startcol2 = ItemActionPeer::NUM_HYDRATE_COLUMNS;

        LibrarianPeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + LibrarianPeer::NUM_HYDRATE_COLUMNS;

        LibrarianPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + LibrarianPeer::NUM_HYDRATE_COLUMNS;

        ItemPeer::addSelectColumns($criteria);
        $startcol5 = $startcol4 + ItemPeer::NUM_HYDRATE_COLUMNS;

        PatronPeer::addSelectColumns($criteria);
        $startcol6 = $startcol5 + PatronPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol7 = $startcol6 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol8 = $startcol7 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol9 = $startcol8 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol10 = $startcol9 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(ItemActionPeer::CREATED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::MODIFIED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::ITEM_ID, ItemPeer::ITEM_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::PATRON_ID, PatronPeer::PATRON_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::EXTERNAL_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::FROM_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::TO_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = ItemActionPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = ItemActionPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = ItemActionPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                ItemActionPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

            // Add objects for joined Librarian rows

            $key2 = LibrarianPeer::getPrimaryKeyHashFromRow($row, $startcol2);
            if ($key2 !== null) {
                $obj2 = LibrarianPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = LibrarianPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    LibrarianPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 loaded

                // Add the $obj1 (ItemAction) to the collection in $obj2 (Librarian)
                $obj2->addItemActionRelatedByCreatedBy($obj1);
            } // if joined row not null

            // Add objects for joined Librarian rows

            $key3 = LibrarianPeer::getPrimaryKeyHashFromRow($row, $startcol3);
            if ($key3 !== null) {
                $obj3 = LibrarianPeer::getInstanceFromPool($key3);
                if (!$obj3) {

                    $cls = LibrarianPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    LibrarianPeer::addInstanceToPool($obj3, $key3);
                } // if obj3 loaded

                // Add the $obj1 (ItemAction) to the collection in $obj3 (Librarian)
                $obj3->addItemActionRelatedByModifiedBy($obj1);
            } // if joined row not null

            // Add objects for joined Item rows

            $key4 = ItemPeer::getPrimaryKeyHashFromRow($row, $startcol4);
            if ($key4 !== null) {
                $obj4 = ItemPeer::getInstanceFromPool($key4);
                if (!$obj4) {

                    $cls = ItemPeer::getOMClass();

                    $obj4 = new $cls();
                    $obj4->hydrate($row, $startcol4);
                    ItemPeer::addInstanceToPool($obj4, $key4);
                } // if obj4 loaded

                // Add the $obj1 (ItemAction) to the collection in $obj4 (Item)
                $obj4->addItemAction($obj1);
            } // if joined row not null

            // Add objects for joined Patron rows

            $key5 = PatronPeer::getPrimaryKeyHashFromRow($row, $startcol5);
            if ($key5 !== null) {
                $obj5 = PatronPeer::getInstanceFromPool($key5);
                if (!$obj5) {

                    $cls = PatronPeer::getOMClass();

                    $obj5 = new $cls();
                    $obj5->hydrate($row, $startcol5);
                    PatronPeer::addInstanceToPool($obj5, $key5);
                } // if obj5 loaded

                // Add the $obj1 (ItemAction) to the collection in $obj5 (Patron)
                $obj5->addItemAction($obj1);
            } // if joined row not null

            // Add objects for joined Library rows

            $key6 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol6);
            if ($key6 !== null) {
                $obj6 = LibraryPeer::getInstanceFromPool($key6);
                if (!$obj6) {

                    $cls = LibraryPeer::getOMClass();

                    $obj6 = new $cls();
                    $obj6->hydrate($row, $startcol6);
                    LibraryPeer::addInstanceToPool($obj6, $key6);
                } // if obj6 loaded

                // Add the $obj1 (ItemAction) to the collection in $obj6 (Library)
                $obj6->addItemActionRelatedByExternalLibraryId($obj1);
            } // if joined row not null

            // Add objects for joined Library rows

            $key7 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol7);
            if ($key7 !== null) {
                $obj7 = LibraryPeer::getInstanceFromPool($key7);
                if (!$obj7) {

                    $cls = LibraryPeer::getOMClass();

                    $obj7 = new $cls();
                    $obj7->hydrate($row, $startcol7);
                    LibraryPeer::addInstanceToPool($obj7, $key7);
                } // if obj7 loaded

                // Add the $obj1 (ItemAction) to the collection in $obj7 (Library)
                $obj7->addItemActionRelatedByLibraryId($obj1);
            } // if joined row not null

            // Add objects for joined Library rows

            $key8 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol8);
            if ($key8 !== null) {
                $obj8 = LibraryPeer::getInstanceFromPool($key8);
                if (!$obj8) {

                    $cls = LibraryPeer::getOMClass();

                    $obj8 = new $cls();
                    $obj8->hydrate($row, $startcol8);
                    LibraryPeer::addInstanceToPool($obj8, $key8);
                } // if obj8 loaded

                // Add the $obj1 (ItemAction) to the collection in $obj8 (Library)
                $obj8->addItemActionRelatedByFromLibraryId($obj1);
            } // if joined row not null

            // Add objects for joined Library rows

            $key9 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol9);
            if ($key9 !== null) {
                $obj9 = LibraryPeer::getInstanceFromPool($key9);
                if (!$obj9) {

                    $cls = LibraryPeer::getOMClass();

                    $obj9 = new $cls();
                    $obj9->hydrate($row, $startcol9);
                    LibraryPeer::addInstanceToPool($obj9, $key9);
                } // if obj9 loaded

                // Add the $obj1 (ItemAction) to the collection in $obj9 (Library)
                $obj9->addItemActionRelatedByToLibraryId($obj1);
            } // if joined row not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Returns the number of rows matching criteria, joining the related LibrarianRelatedByCreatedBy table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptLibrarianRelatedByCreatedBy(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(ItemActionPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            ItemActionPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(ItemActionPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(ItemActionPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(ItemActionPeer::ITEM_ID, ItemPeer::ITEM_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::PATRON_ID, PatronPeer::PATRON_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::EXTERNAL_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::FROM_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::TO_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related LibrarianRelatedByModifiedBy table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptLibrarianRelatedByModifiedBy(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(ItemActionPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            ItemActionPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(ItemActionPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(ItemActionPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(ItemActionPeer::ITEM_ID, ItemPeer::ITEM_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::PATRON_ID, PatronPeer::PATRON_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::EXTERNAL_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::FROM_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::TO_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related Item table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptItem(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(ItemActionPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            ItemActionPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(ItemActionPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(ItemActionPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(ItemActionPeer::CREATED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::MODIFIED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::PATRON_ID, PatronPeer::PATRON_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::EXTERNAL_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::FROM_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::TO_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related Patron table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptPatron(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(ItemActionPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            ItemActionPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(ItemActionPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(ItemActionPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(ItemActionPeer::CREATED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::MODIFIED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::ITEM_ID, ItemPeer::ITEM_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::EXTERNAL_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::FROM_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::TO_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related LibraryRelatedByExternalLibraryId table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptLibraryRelatedByExternalLibraryId(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(ItemActionPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            ItemActionPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(ItemActionPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(ItemActionPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(ItemActionPeer::CREATED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::MODIFIED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::ITEM_ID, ItemPeer::ITEM_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::PATRON_ID, PatronPeer::PATRON_ID, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related LibraryRelatedByLibraryId table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptLibraryRelatedByLibraryId(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(ItemActionPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            ItemActionPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(ItemActionPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(ItemActionPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(ItemActionPeer::CREATED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::MODIFIED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::ITEM_ID, ItemPeer::ITEM_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::PATRON_ID, PatronPeer::PATRON_ID, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related LibraryRelatedByFromLibraryId table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptLibraryRelatedByFromLibraryId(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(ItemActionPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            ItemActionPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(ItemActionPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(ItemActionPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(ItemActionPeer::CREATED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::MODIFIED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::ITEM_ID, ItemPeer::ITEM_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::PATRON_ID, PatronPeer::PATRON_ID, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related LibraryRelatedByToLibraryId table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptLibraryRelatedByToLibraryId(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(ItemActionPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            ItemActionPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(ItemActionPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(ItemActionPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(ItemActionPeer::CREATED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::MODIFIED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::ITEM_ID, ItemPeer::ITEM_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::PATRON_ID, PatronPeer::PATRON_ID, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Selects a collection of ItemAction objects pre-filled with all related objects except LibrarianRelatedByCreatedBy.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of ItemAction objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptLibrarianRelatedByCreatedBy(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(ItemActionPeer::DATABASE_NAME);
        }

        ItemActionPeer::addSelectColumns($criteria);
        $startcol2 = ItemActionPeer::NUM_HYDRATE_COLUMNS;

        ItemPeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + ItemPeer::NUM_HYDRATE_COLUMNS;

        PatronPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + PatronPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol5 = $startcol4 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol6 = $startcol5 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol7 = $startcol6 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol8 = $startcol7 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(ItemActionPeer::ITEM_ID, ItemPeer::ITEM_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::PATRON_ID, PatronPeer::PATRON_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::EXTERNAL_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::FROM_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::TO_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = ItemActionPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = ItemActionPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = ItemActionPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                ItemActionPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

                // Add objects for joined Item rows

                $key2 = ItemPeer::getPrimaryKeyHashFromRow($row, $startcol2);
                if ($key2 !== null) {
                    $obj2 = ItemPeer::getInstanceFromPool($key2);
                    if (!$obj2) {

                        $cls = ItemPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    ItemPeer::addInstanceToPool($obj2, $key2);
                } // if $obj2 already loaded

                // Add the $obj1 (ItemAction) to the collection in $obj2 (Item)
                $obj2->addItemAction($obj1);

            } // if joined row is not null

                // Add objects for joined Patron rows

                $key3 = PatronPeer::getPrimaryKeyHashFromRow($row, $startcol3);
                if ($key3 !== null) {
                    $obj3 = PatronPeer::getInstanceFromPool($key3);
                    if (!$obj3) {

                        $cls = PatronPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    PatronPeer::addInstanceToPool($obj3, $key3);
                } // if $obj3 already loaded

                // Add the $obj1 (ItemAction) to the collection in $obj3 (Patron)
                $obj3->addItemAction($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key4 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol4);
                if ($key4 !== null) {
                    $obj4 = LibraryPeer::getInstanceFromPool($key4);
                    if (!$obj4) {

                        $cls = LibraryPeer::getOMClass();

                    $obj4 = new $cls();
                    $obj4->hydrate($row, $startcol4);
                    LibraryPeer::addInstanceToPool($obj4, $key4);
                } // if $obj4 already loaded

                // Add the $obj1 (ItemAction) to the collection in $obj4 (Library)
                $obj4->addItemActionRelatedByExternalLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key5 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol5);
                if ($key5 !== null) {
                    $obj5 = LibraryPeer::getInstanceFromPool($key5);
                    if (!$obj5) {

                        $cls = LibraryPeer::getOMClass();

                    $obj5 = new $cls();
                    $obj5->hydrate($row, $startcol5);
                    LibraryPeer::addInstanceToPool($obj5, $key5);
                } // if $obj5 already loaded

                // Add the $obj1 (ItemAction) to the collection in $obj5 (Library)
                $obj5->addItemActionRelatedByLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key6 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol6);
                if ($key6 !== null) {
                    $obj6 = LibraryPeer::getInstanceFromPool($key6);
                    if (!$obj6) {

                        $cls = LibraryPeer::getOMClass();

                    $obj6 = new $cls();
                    $obj6->hydrate($row, $startcol6);
                    LibraryPeer::addInstanceToPool($obj6, $key6);
                } // if $obj6 already loaded

                // Add the $obj1 (ItemAction) to the collection in $obj6 (Library)
                $obj6->addItemActionRelatedByFromLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key7 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol7);
                if ($key7 !== null) {
                    $obj7 = LibraryPeer::getInstanceFromPool($key7);
                    if (!$obj7) {

                        $cls = LibraryPeer::getOMClass();

                    $obj7 = new $cls();
                    $obj7->hydrate($row, $startcol7);
                    LibraryPeer::addInstanceToPool($obj7, $key7);
                } // if $obj7 already loaded

                // Add the $obj1 (ItemAction) to the collection in $obj7 (Library)
                $obj7->addItemActionRelatedByToLibraryId($obj1);

            } // if joined row is not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of ItemAction objects pre-filled with all related objects except LibrarianRelatedByModifiedBy.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of ItemAction objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptLibrarianRelatedByModifiedBy(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(ItemActionPeer::DATABASE_NAME);
        }

        ItemActionPeer::addSelectColumns($criteria);
        $startcol2 = ItemActionPeer::NUM_HYDRATE_COLUMNS;

        ItemPeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + ItemPeer::NUM_HYDRATE_COLUMNS;

        PatronPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + PatronPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol5 = $startcol4 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol6 = $startcol5 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol7 = $startcol6 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol8 = $startcol7 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(ItemActionPeer::ITEM_ID, ItemPeer::ITEM_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::PATRON_ID, PatronPeer::PATRON_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::EXTERNAL_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::FROM_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::TO_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = ItemActionPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = ItemActionPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = ItemActionPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                ItemActionPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

                // Add objects for joined Item rows

                $key2 = ItemPeer::getPrimaryKeyHashFromRow($row, $startcol2);
                if ($key2 !== null) {
                    $obj2 = ItemPeer::getInstanceFromPool($key2);
                    if (!$obj2) {

                        $cls = ItemPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    ItemPeer::addInstanceToPool($obj2, $key2);
                } // if $obj2 already loaded

                // Add the $obj1 (ItemAction) to the collection in $obj2 (Item)
                $obj2->addItemAction($obj1);

            } // if joined row is not null

                // Add objects for joined Patron rows

                $key3 = PatronPeer::getPrimaryKeyHashFromRow($row, $startcol3);
                if ($key3 !== null) {
                    $obj3 = PatronPeer::getInstanceFromPool($key3);
                    if (!$obj3) {

                        $cls = PatronPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    PatronPeer::addInstanceToPool($obj3, $key3);
                } // if $obj3 already loaded

                // Add the $obj1 (ItemAction) to the collection in $obj3 (Patron)
                $obj3->addItemAction($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key4 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol4);
                if ($key4 !== null) {
                    $obj4 = LibraryPeer::getInstanceFromPool($key4);
                    if (!$obj4) {

                        $cls = LibraryPeer::getOMClass();

                    $obj4 = new $cls();
                    $obj4->hydrate($row, $startcol4);
                    LibraryPeer::addInstanceToPool($obj4, $key4);
                } // if $obj4 already loaded

                // Add the $obj1 (ItemAction) to the collection in $obj4 (Library)
                $obj4->addItemActionRelatedByExternalLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key5 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol5);
                if ($key5 !== null) {
                    $obj5 = LibraryPeer::getInstanceFromPool($key5);
                    if (!$obj5) {

                        $cls = LibraryPeer::getOMClass();

                    $obj5 = new $cls();
                    $obj5->hydrate($row, $startcol5);
                    LibraryPeer::addInstanceToPool($obj5, $key5);
                } // if $obj5 already loaded

                // Add the $obj1 (ItemAction) to the collection in $obj5 (Library)
                $obj5->addItemActionRelatedByLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key6 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol6);
                if ($key6 !== null) {
                    $obj6 = LibraryPeer::getInstanceFromPool($key6);
                    if (!$obj6) {

                        $cls = LibraryPeer::getOMClass();

                    $obj6 = new $cls();
                    $obj6->hydrate($row, $startcol6);
                    LibraryPeer::addInstanceToPool($obj6, $key6);
                } // if $obj6 already loaded

                // Add the $obj1 (ItemAction) to the collection in $obj6 (Library)
                $obj6->addItemActionRelatedByFromLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key7 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol7);
                if ($key7 !== null) {
                    $obj7 = LibraryPeer::getInstanceFromPool($key7);
                    if (!$obj7) {

                        $cls = LibraryPeer::getOMClass();

                    $obj7 = new $cls();
                    $obj7->hydrate($row, $startcol7);
                    LibraryPeer::addInstanceToPool($obj7, $key7);
                } // if $obj7 already loaded

                // Add the $obj1 (ItemAction) to the collection in $obj7 (Library)
                $obj7->addItemActionRelatedByToLibraryId($obj1);

            } // if joined row is not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of ItemAction objects pre-filled with all related objects except Item.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of ItemAction objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptItem(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(ItemActionPeer::DATABASE_NAME);
        }

        ItemActionPeer::addSelectColumns($criteria);
        $startcol2 = ItemActionPeer::NUM_HYDRATE_COLUMNS;

        LibrarianPeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + LibrarianPeer::NUM_HYDRATE_COLUMNS;

        LibrarianPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + LibrarianPeer::NUM_HYDRATE_COLUMNS;

        PatronPeer::addSelectColumns($criteria);
        $startcol5 = $startcol4 + PatronPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol6 = $startcol5 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol7 = $startcol6 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol8 = $startcol7 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol9 = $startcol8 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(ItemActionPeer::CREATED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::MODIFIED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::PATRON_ID, PatronPeer::PATRON_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::EXTERNAL_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::FROM_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::TO_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = ItemActionPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = ItemActionPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = ItemActionPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                ItemActionPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

                // Add objects for joined Librarian rows

                $key2 = LibrarianPeer::getPrimaryKeyHashFromRow($row, $startcol2);
                if ($key2 !== null) {
                    $obj2 = LibrarianPeer::getInstanceFromPool($key2);
                    if (!$obj2) {

                        $cls = LibrarianPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    LibrarianPeer::addInstanceToPool($obj2, $key2);
                } // if $obj2 already loaded

                // Add the $obj1 (ItemAction) to the collection in $obj2 (Librarian)
                $obj2->addItemActionRelatedByCreatedBy($obj1);

            } // if joined row is not null

                // Add objects for joined Librarian rows

                $key3 = LibrarianPeer::getPrimaryKeyHashFromRow($row, $startcol3);
                if ($key3 !== null) {
                    $obj3 = LibrarianPeer::getInstanceFromPool($key3);
                    if (!$obj3) {

                        $cls = LibrarianPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    LibrarianPeer::addInstanceToPool($obj3, $key3);
                } // if $obj3 already loaded

                // Add the $obj1 (ItemAction) to the collection in $obj3 (Librarian)
                $obj3->addItemActionRelatedByModifiedBy($obj1);

            } // if joined row is not null

                // Add objects for joined Patron rows

                $key4 = PatronPeer::getPrimaryKeyHashFromRow($row, $startcol4);
                if ($key4 !== null) {
                    $obj4 = PatronPeer::getInstanceFromPool($key4);
                    if (!$obj4) {

                        $cls = PatronPeer::getOMClass();

                    $obj4 = new $cls();
                    $obj4->hydrate($row, $startcol4);
                    PatronPeer::addInstanceToPool($obj4, $key4);
                } // if $obj4 already loaded

                // Add the $obj1 (ItemAction) to the collection in $obj4 (Patron)
                $obj4->addItemAction($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key5 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol5);
                if ($key5 !== null) {
                    $obj5 = LibraryPeer::getInstanceFromPool($key5);
                    if (!$obj5) {

                        $cls = LibraryPeer::getOMClass();

                    $obj5 = new $cls();
                    $obj5->hydrate($row, $startcol5);
                    LibraryPeer::addInstanceToPool($obj5, $key5);
                } // if $obj5 already loaded

                // Add the $obj1 (ItemAction) to the collection in $obj5 (Library)
                $obj5->addItemActionRelatedByExternalLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key6 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol6);
                if ($key6 !== null) {
                    $obj6 = LibraryPeer::getInstanceFromPool($key6);
                    if (!$obj6) {

                        $cls = LibraryPeer::getOMClass();

                    $obj6 = new $cls();
                    $obj6->hydrate($row, $startcol6);
                    LibraryPeer::addInstanceToPool($obj6, $key6);
                } // if $obj6 already loaded

                // Add the $obj1 (ItemAction) to the collection in $obj6 (Library)
                $obj6->addItemActionRelatedByLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key7 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol7);
                if ($key7 !== null) {
                    $obj7 = LibraryPeer::getInstanceFromPool($key7);
                    if (!$obj7) {

                        $cls = LibraryPeer::getOMClass();

                    $obj7 = new $cls();
                    $obj7->hydrate($row, $startcol7);
                    LibraryPeer::addInstanceToPool($obj7, $key7);
                } // if $obj7 already loaded

                // Add the $obj1 (ItemAction) to the collection in $obj7 (Library)
                $obj7->addItemActionRelatedByFromLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key8 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol8);
                if ($key8 !== null) {
                    $obj8 = LibraryPeer::getInstanceFromPool($key8);
                    if (!$obj8) {

                        $cls = LibraryPeer::getOMClass();

                    $obj8 = new $cls();
                    $obj8->hydrate($row, $startcol8);
                    LibraryPeer::addInstanceToPool($obj8, $key8);
                } // if $obj8 already loaded

                // Add the $obj1 (ItemAction) to the collection in $obj8 (Library)
                $obj8->addItemActionRelatedByToLibraryId($obj1);

            } // if joined row is not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of ItemAction objects pre-filled with all related objects except Patron.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of ItemAction objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptPatron(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(ItemActionPeer::DATABASE_NAME);
        }

        ItemActionPeer::addSelectColumns($criteria);
        $startcol2 = ItemActionPeer::NUM_HYDRATE_COLUMNS;

        LibrarianPeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + LibrarianPeer::NUM_HYDRATE_COLUMNS;

        LibrarianPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + LibrarianPeer::NUM_HYDRATE_COLUMNS;

        ItemPeer::addSelectColumns($criteria);
        $startcol5 = $startcol4 + ItemPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol6 = $startcol5 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol7 = $startcol6 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol8 = $startcol7 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        LibraryPeer::addSelectColumns($criteria);
        $startcol9 = $startcol8 + LibraryPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(ItemActionPeer::CREATED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::MODIFIED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::ITEM_ID, ItemPeer::ITEM_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::EXTERNAL_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::FROM_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::TO_LIBRARY_ID, LibraryPeer::LIBRARY_ID, $join_behavior);


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = ItemActionPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = ItemActionPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = ItemActionPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                ItemActionPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

                // Add objects for joined Librarian rows

                $key2 = LibrarianPeer::getPrimaryKeyHashFromRow($row, $startcol2);
                if ($key2 !== null) {
                    $obj2 = LibrarianPeer::getInstanceFromPool($key2);
                    if (!$obj2) {

                        $cls = LibrarianPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    LibrarianPeer::addInstanceToPool($obj2, $key2);
                } // if $obj2 already loaded

                // Add the $obj1 (ItemAction) to the collection in $obj2 (Librarian)
                $obj2->addItemActionRelatedByCreatedBy($obj1);

            } // if joined row is not null

                // Add objects for joined Librarian rows

                $key3 = LibrarianPeer::getPrimaryKeyHashFromRow($row, $startcol3);
                if ($key3 !== null) {
                    $obj3 = LibrarianPeer::getInstanceFromPool($key3);
                    if (!$obj3) {

                        $cls = LibrarianPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    LibrarianPeer::addInstanceToPool($obj3, $key3);
                } // if $obj3 already loaded

                // Add the $obj1 (ItemAction) to the collection in $obj3 (Librarian)
                $obj3->addItemActionRelatedByModifiedBy($obj1);

            } // if joined row is not null

                // Add objects for joined Item rows

                $key4 = ItemPeer::getPrimaryKeyHashFromRow($row, $startcol4);
                if ($key4 !== null) {
                    $obj4 = ItemPeer::getInstanceFromPool($key4);
                    if (!$obj4) {

                        $cls = ItemPeer::getOMClass();

                    $obj4 = new $cls();
                    $obj4->hydrate($row, $startcol4);
                    ItemPeer::addInstanceToPool($obj4, $key4);
                } // if $obj4 already loaded

                // Add the $obj1 (ItemAction) to the collection in $obj4 (Item)
                $obj4->addItemAction($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key5 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol5);
                if ($key5 !== null) {
                    $obj5 = LibraryPeer::getInstanceFromPool($key5);
                    if (!$obj5) {

                        $cls = LibraryPeer::getOMClass();

                    $obj5 = new $cls();
                    $obj5->hydrate($row, $startcol5);
                    LibraryPeer::addInstanceToPool($obj5, $key5);
                } // if $obj5 already loaded

                // Add the $obj1 (ItemAction) to the collection in $obj5 (Library)
                $obj5->addItemActionRelatedByExternalLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key6 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol6);
                if ($key6 !== null) {
                    $obj6 = LibraryPeer::getInstanceFromPool($key6);
                    if (!$obj6) {

                        $cls = LibraryPeer::getOMClass();

                    $obj6 = new $cls();
                    $obj6->hydrate($row, $startcol6);
                    LibraryPeer::addInstanceToPool($obj6, $key6);
                } // if $obj6 already loaded

                // Add the $obj1 (ItemAction) to the collection in $obj6 (Library)
                $obj6->addItemActionRelatedByLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key7 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol7);
                if ($key7 !== null) {
                    $obj7 = LibraryPeer::getInstanceFromPool($key7);
                    if (!$obj7) {

                        $cls = LibraryPeer::getOMClass();

                    $obj7 = new $cls();
                    $obj7->hydrate($row, $startcol7);
                    LibraryPeer::addInstanceToPool($obj7, $key7);
                } // if $obj7 already loaded

                // Add the $obj1 (ItemAction) to the collection in $obj7 (Library)
                $obj7->addItemActionRelatedByFromLibraryId($obj1);

            } // if joined row is not null

                // Add objects for joined Library rows

                $key8 = LibraryPeer::getPrimaryKeyHashFromRow($row, $startcol8);
                if ($key8 !== null) {
                    $obj8 = LibraryPeer::getInstanceFromPool($key8);
                    if (!$obj8) {

                        $cls = LibraryPeer::getOMClass();

                    $obj8 = new $cls();
                    $obj8->hydrate($row, $startcol8);
                    LibraryPeer::addInstanceToPool($obj8, $key8);
                } // if $obj8 already loaded

                // Add the $obj1 (ItemAction) to the collection in $obj8 (Library)
                $obj8->addItemActionRelatedByToLibraryId($obj1);

            } // if joined row is not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of ItemAction objects pre-filled with all related objects except LibraryRelatedByExternalLibraryId.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of ItemAction objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptLibraryRelatedByExternalLibraryId(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(ItemActionPeer::DATABASE_NAME);
        }

        ItemActionPeer::addSelectColumns($criteria);
        $startcol2 = ItemActionPeer::NUM_HYDRATE_COLUMNS;

        LibrarianPeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + LibrarianPeer::NUM_HYDRATE_COLUMNS;

        LibrarianPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + LibrarianPeer::NUM_HYDRATE_COLUMNS;

        ItemPeer::addSelectColumns($criteria);
        $startcol5 = $startcol4 + ItemPeer::NUM_HYDRATE_COLUMNS;

        PatronPeer::addSelectColumns($criteria);
        $startcol6 = $startcol5 + PatronPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(ItemActionPeer::CREATED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::MODIFIED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::ITEM_ID, ItemPeer::ITEM_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::PATRON_ID, PatronPeer::PATRON_ID, $join_behavior);


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = ItemActionPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = ItemActionPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = ItemActionPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                ItemActionPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

                // Add objects for joined Librarian rows

                $key2 = LibrarianPeer::getPrimaryKeyHashFromRow($row, $startcol2);
                if ($key2 !== null) {
                    $obj2 = LibrarianPeer::getInstanceFromPool($key2);
                    if (!$obj2) {

                        $cls = LibrarianPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    LibrarianPeer::addInstanceToPool($obj2, $key2);
                } // if $obj2 already loaded

                // Add the $obj1 (ItemAction) to the collection in $obj2 (Librarian)
                $obj2->addItemActionRelatedByCreatedBy($obj1);

            } // if joined row is not null

                // Add objects for joined Librarian rows

                $key3 = LibrarianPeer::getPrimaryKeyHashFromRow($row, $startcol3);
                if ($key3 !== null) {
                    $obj3 = LibrarianPeer::getInstanceFromPool($key3);
                    if (!$obj3) {

                        $cls = LibrarianPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    LibrarianPeer::addInstanceToPool($obj3, $key3);
                } // if $obj3 already loaded

                // Add the $obj1 (ItemAction) to the collection in $obj3 (Librarian)
                $obj3->addItemActionRelatedByModifiedBy($obj1);

            } // if joined row is not null

                // Add objects for joined Item rows

                $key4 = ItemPeer::getPrimaryKeyHashFromRow($row, $startcol4);
                if ($key4 !== null) {
                    $obj4 = ItemPeer::getInstanceFromPool($key4);
                    if (!$obj4) {

                        $cls = ItemPeer::getOMClass();

                    $obj4 = new $cls();
                    $obj4->hydrate($row, $startcol4);
                    ItemPeer::addInstanceToPool($obj4, $key4);
                } // if $obj4 already loaded

                // Add the $obj1 (ItemAction) to the collection in $obj4 (Item)
                $obj4->addItemAction($obj1);

            } // if joined row is not null

                // Add objects for joined Patron rows

                $key5 = PatronPeer::getPrimaryKeyHashFromRow($row, $startcol5);
                if ($key5 !== null) {
                    $obj5 = PatronPeer::getInstanceFromPool($key5);
                    if (!$obj5) {

                        $cls = PatronPeer::getOMClass();

                    $obj5 = new $cls();
                    $obj5->hydrate($row, $startcol5);
                    PatronPeer::addInstanceToPool($obj5, $key5);
                } // if $obj5 already loaded

                // Add the $obj1 (ItemAction) to the collection in $obj5 (Patron)
                $obj5->addItemAction($obj1);

            } // if joined row is not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of ItemAction objects pre-filled with all related objects except LibraryRelatedByLibraryId.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of ItemAction objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptLibraryRelatedByLibraryId(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(ItemActionPeer::DATABASE_NAME);
        }

        ItemActionPeer::addSelectColumns($criteria);
        $startcol2 = ItemActionPeer::NUM_HYDRATE_COLUMNS;

        LibrarianPeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + LibrarianPeer::NUM_HYDRATE_COLUMNS;

        LibrarianPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + LibrarianPeer::NUM_HYDRATE_COLUMNS;

        ItemPeer::addSelectColumns($criteria);
        $startcol5 = $startcol4 + ItemPeer::NUM_HYDRATE_COLUMNS;

        PatronPeer::addSelectColumns($criteria);
        $startcol6 = $startcol5 + PatronPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(ItemActionPeer::CREATED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::MODIFIED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::ITEM_ID, ItemPeer::ITEM_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::PATRON_ID, PatronPeer::PATRON_ID, $join_behavior);


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = ItemActionPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = ItemActionPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = ItemActionPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                ItemActionPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

                // Add objects for joined Librarian rows

                $key2 = LibrarianPeer::getPrimaryKeyHashFromRow($row, $startcol2);
                if ($key2 !== null) {
                    $obj2 = LibrarianPeer::getInstanceFromPool($key2);
                    if (!$obj2) {

                        $cls = LibrarianPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    LibrarianPeer::addInstanceToPool($obj2, $key2);
                } // if $obj2 already loaded

                // Add the $obj1 (ItemAction) to the collection in $obj2 (Librarian)
                $obj2->addItemActionRelatedByCreatedBy($obj1);

            } // if joined row is not null

                // Add objects for joined Librarian rows

                $key3 = LibrarianPeer::getPrimaryKeyHashFromRow($row, $startcol3);
                if ($key3 !== null) {
                    $obj3 = LibrarianPeer::getInstanceFromPool($key3);
                    if (!$obj3) {

                        $cls = LibrarianPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    LibrarianPeer::addInstanceToPool($obj3, $key3);
                } // if $obj3 already loaded

                // Add the $obj1 (ItemAction) to the collection in $obj3 (Librarian)
                $obj3->addItemActionRelatedByModifiedBy($obj1);

            } // if joined row is not null

                // Add objects for joined Item rows

                $key4 = ItemPeer::getPrimaryKeyHashFromRow($row, $startcol4);
                if ($key4 !== null) {
                    $obj4 = ItemPeer::getInstanceFromPool($key4);
                    if (!$obj4) {

                        $cls = ItemPeer::getOMClass();

                    $obj4 = new $cls();
                    $obj4->hydrate($row, $startcol4);
                    ItemPeer::addInstanceToPool($obj4, $key4);
                } // if $obj4 already loaded

                // Add the $obj1 (ItemAction) to the collection in $obj4 (Item)
                $obj4->addItemAction($obj1);

            } // if joined row is not null

                // Add objects for joined Patron rows

                $key5 = PatronPeer::getPrimaryKeyHashFromRow($row, $startcol5);
                if ($key5 !== null) {
                    $obj5 = PatronPeer::getInstanceFromPool($key5);
                    if (!$obj5) {

                        $cls = PatronPeer::getOMClass();

                    $obj5 = new $cls();
                    $obj5->hydrate($row, $startcol5);
                    PatronPeer::addInstanceToPool($obj5, $key5);
                } // if $obj5 already loaded

                // Add the $obj1 (ItemAction) to the collection in $obj5 (Patron)
                $obj5->addItemAction($obj1);

            } // if joined row is not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of ItemAction objects pre-filled with all related objects except LibraryRelatedByFromLibraryId.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of ItemAction objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptLibraryRelatedByFromLibraryId(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(ItemActionPeer::DATABASE_NAME);
        }

        ItemActionPeer::addSelectColumns($criteria);
        $startcol2 = ItemActionPeer::NUM_HYDRATE_COLUMNS;

        LibrarianPeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + LibrarianPeer::NUM_HYDRATE_COLUMNS;

        LibrarianPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + LibrarianPeer::NUM_HYDRATE_COLUMNS;

        ItemPeer::addSelectColumns($criteria);
        $startcol5 = $startcol4 + ItemPeer::NUM_HYDRATE_COLUMNS;

        PatronPeer::addSelectColumns($criteria);
        $startcol6 = $startcol5 + PatronPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(ItemActionPeer::CREATED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::MODIFIED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::ITEM_ID, ItemPeer::ITEM_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::PATRON_ID, PatronPeer::PATRON_ID, $join_behavior);


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = ItemActionPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = ItemActionPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = ItemActionPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                ItemActionPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

                // Add objects for joined Librarian rows

                $key2 = LibrarianPeer::getPrimaryKeyHashFromRow($row, $startcol2);
                if ($key2 !== null) {
                    $obj2 = LibrarianPeer::getInstanceFromPool($key2);
                    if (!$obj2) {

                        $cls = LibrarianPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    LibrarianPeer::addInstanceToPool($obj2, $key2);
                } // if $obj2 already loaded

                // Add the $obj1 (ItemAction) to the collection in $obj2 (Librarian)
                $obj2->addItemActionRelatedByCreatedBy($obj1);

            } // if joined row is not null

                // Add objects for joined Librarian rows

                $key3 = LibrarianPeer::getPrimaryKeyHashFromRow($row, $startcol3);
                if ($key3 !== null) {
                    $obj3 = LibrarianPeer::getInstanceFromPool($key3);
                    if (!$obj3) {

                        $cls = LibrarianPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    LibrarianPeer::addInstanceToPool($obj3, $key3);
                } // if $obj3 already loaded

                // Add the $obj1 (ItemAction) to the collection in $obj3 (Librarian)
                $obj3->addItemActionRelatedByModifiedBy($obj1);

            } // if joined row is not null

                // Add objects for joined Item rows

                $key4 = ItemPeer::getPrimaryKeyHashFromRow($row, $startcol4);
                if ($key4 !== null) {
                    $obj4 = ItemPeer::getInstanceFromPool($key4);
                    if (!$obj4) {

                        $cls = ItemPeer::getOMClass();

                    $obj4 = new $cls();
                    $obj4->hydrate($row, $startcol4);
                    ItemPeer::addInstanceToPool($obj4, $key4);
                } // if $obj4 already loaded

                // Add the $obj1 (ItemAction) to the collection in $obj4 (Item)
                $obj4->addItemAction($obj1);

            } // if joined row is not null

                // Add objects for joined Patron rows

                $key5 = PatronPeer::getPrimaryKeyHashFromRow($row, $startcol5);
                if ($key5 !== null) {
                    $obj5 = PatronPeer::getInstanceFromPool($key5);
                    if (!$obj5) {

                        $cls = PatronPeer::getOMClass();

                    $obj5 = new $cls();
                    $obj5->hydrate($row, $startcol5);
                    PatronPeer::addInstanceToPool($obj5, $key5);
                } // if $obj5 already loaded

                // Add the $obj1 (ItemAction) to the collection in $obj5 (Patron)
                $obj5->addItemAction($obj1);

            } // if joined row is not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of ItemAction objects pre-filled with all related objects except LibraryRelatedByToLibraryId.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of ItemAction objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptLibraryRelatedByToLibraryId(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(ItemActionPeer::DATABASE_NAME);
        }

        ItemActionPeer::addSelectColumns($criteria);
        $startcol2 = ItemActionPeer::NUM_HYDRATE_COLUMNS;

        LibrarianPeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + LibrarianPeer::NUM_HYDRATE_COLUMNS;

        LibrarianPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + LibrarianPeer::NUM_HYDRATE_COLUMNS;

        ItemPeer::addSelectColumns($criteria);
        $startcol5 = $startcol4 + ItemPeer::NUM_HYDRATE_COLUMNS;

        PatronPeer::addSelectColumns($criteria);
        $startcol6 = $startcol5 + PatronPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(ItemActionPeer::CREATED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::MODIFIED_BY, LibrarianPeer::LIBRARIAN_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::ITEM_ID, ItemPeer::ITEM_ID, $join_behavior);

        $criteria->addJoin(ItemActionPeer::PATRON_ID, PatronPeer::PATRON_ID, $join_behavior);


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = ItemActionPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = ItemActionPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = ItemActionPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                ItemActionPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

                // Add objects for joined Librarian rows

                $key2 = LibrarianPeer::getPrimaryKeyHashFromRow($row, $startcol2);
                if ($key2 !== null) {
                    $obj2 = LibrarianPeer::getInstanceFromPool($key2);
                    if (!$obj2) {

                        $cls = LibrarianPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    LibrarianPeer::addInstanceToPool($obj2, $key2);
                } // if $obj2 already loaded

                // Add the $obj1 (ItemAction) to the collection in $obj2 (Librarian)
                $obj2->addItemActionRelatedByCreatedBy($obj1);

            } // if joined row is not null

                // Add objects for joined Librarian rows

                $key3 = LibrarianPeer::getPrimaryKeyHashFromRow($row, $startcol3);
                if ($key3 !== null) {
                    $obj3 = LibrarianPeer::getInstanceFromPool($key3);
                    if (!$obj3) {

                        $cls = LibrarianPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    LibrarianPeer::addInstanceToPool($obj3, $key3);
                } // if $obj3 already loaded

                // Add the $obj1 (ItemAction) to the collection in $obj3 (Librarian)
                $obj3->addItemActionRelatedByModifiedBy($obj1);

            } // if joined row is not null

                // Add objects for joined Item rows

                $key4 = ItemPeer::getPrimaryKeyHashFromRow($row, $startcol4);
                if ($key4 !== null) {
                    $obj4 = ItemPeer::getInstanceFromPool($key4);
                    if (!$obj4) {

                        $cls = ItemPeer::getOMClass();

                    $obj4 = new $cls();
                    $obj4->hydrate($row, $startcol4);
                    ItemPeer::addInstanceToPool($obj4, $key4);
                } // if $obj4 already loaded

                // Add the $obj1 (ItemAction) to the collection in $obj4 (Item)
                $obj4->addItemAction($obj1);

            } // if joined row is not null

                // Add objects for joined Patron rows

                $key5 = PatronPeer::getPrimaryKeyHashFromRow($row, $startcol5);
                if ($key5 !== null) {
                    $obj5 = PatronPeer::getInstanceFromPool($key5);
                    if (!$obj5) {

                        $cls = PatronPeer::getOMClass();

                    $obj5 = new $cls();
                    $obj5->hydrate($row, $startcol5);
                    PatronPeer::addInstanceToPool($obj5, $key5);
                } // if $obj5 already loaded

                // Add the $obj1 (ItemAction) to the collection in $obj5 (Patron)
                $obj5->addItemAction($obj1);

            } // if joined row is not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }

    /**
     * Returns the TableMap related to this peer.
     * This method is not needed for general use but a specific application could have a need.
     * @return TableMap
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function getTableMap()
    {
        return Propel::getDatabaseMap(ItemActionPeer::DATABASE_NAME)->getTable(ItemActionPeer::TABLE_NAME);
    }

    /**
     * Add a TableMap instance to the database for this peer class.
     */
    public static function buildTableMap()
    {
      $dbMap = Propel::getDatabaseMap(BaseItemActionPeer::DATABASE_NAME);
      if (!$dbMap->hasTable(BaseItemActionPeer::TABLE_NAME)) {
        $dbMap->addTableObject(new \ItemActionTableMap());
      }
    }

    /**
     * The class that the Peer will make instances of.
     *
     *
     * @return string ClassName
     */
    public static function getOMClass($row = 0, $colnum = 0)
    {
        return ItemActionPeer::OM_CLASS;
    }

    /**
     * Performs an INSERT on the database, given a ItemAction or Criteria object.
     *
     * @param      mixed $values Criteria or ItemAction object containing data that is used to create the INSERT statement.
     * @param      PropelPDO $con the PropelPDO connection to use
     * @return mixed           The new primary key.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doInsert($values, PropelPDO $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection(ItemActionPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        if ($values instanceof Criteria) {
            $criteria = clone $values; // rename for clarity
        } else {
            $criteria = $values->buildCriteria(); // build Criteria from ItemAction object
        }

        if ($criteria->containsKey(ItemActionPeer::ITEM_ACTION_ID) && $criteria->keyContainsValue(ItemActionPeer::ITEM_ACTION_ID) ) {
            throw new PropelException('Cannot insert a value for auto-increment primary key ('.ItemActionPeer::ITEM_ACTION_ID.')');
        }


        // Set the correct dbName
        $criteria->setDbName(ItemActionPeer::DATABASE_NAME);

        try {
            // use transaction because $criteria could contain info
            // for more than one table (I guess, conceivably)
            $con->beginTransaction();
            $pk = BasePeer::doInsert($criteria, $con);
            $con->commit();
        } catch (Exception $e) {
            $con->rollBack();
            throw $e;
        }

        return $pk;
    }

    /**
     * Performs an UPDATE on the database, given a ItemAction or Criteria object.
     *
     * @param      mixed $values Criteria or ItemAction object containing data that is used to create the UPDATE statement.
     * @param      PropelPDO $con The connection to use (specify PropelPDO connection object to exert more control over transactions).
     * @return int             The number of affected rows (if supported by underlying database driver).
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doUpdate($values, PropelPDO $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection(ItemActionPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        $selectCriteria = new Criteria(ItemActionPeer::DATABASE_NAME);

        if ($values instanceof Criteria) {
            $criteria = clone $values; // rename for clarity

            $comparison = $criteria->getComparison(ItemActionPeer::ITEM_ACTION_ID);
            $value = $criteria->remove(ItemActionPeer::ITEM_ACTION_ID);
            if ($value) {
                $selectCriteria->add(ItemActionPeer::ITEM_ACTION_ID, $value, $comparison);
            } else {
                $selectCriteria->setPrimaryTableName(ItemActionPeer::TABLE_NAME);
            }

        } else { // $values is ItemAction object
            $criteria = $values->buildCriteria(); // gets full criteria
            $selectCriteria = $values->buildPkeyCriteria(); // gets criteria w/ primary key(s)
        }

        // set the correct dbName
        $criteria->setDbName(ItemActionPeer::DATABASE_NAME);

        return BasePeer::doUpdate($selectCriteria, $criteria, $con);
    }

    /**
     * Deletes all rows from the item_action table.
     *
     * @param      PropelPDO $con the connection to use
     * @return int             The number of affected rows (if supported by underlying database driver).
     * @throws PropelException
     */
    public static function doDeleteAll(PropelPDO $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection(ItemActionPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }
        $affectedRows = 0; // initialize var to track total num of affected rows
        try {
            // use transaction because $criteria could contain info
            // for more than one table or we could emulating ON DELETE CASCADE, etc.
            $con->beginTransaction();
            $affectedRows += BasePeer::doDeleteAll(ItemActionPeer::TABLE_NAME, $con, ItemActionPeer::DATABASE_NAME);
            // Because this db requires some delete cascade/set null emulation, we have to
            // clear the cached instance *after* the emulation has happened (since
            // instances get re-added by the select statement contained therein).
            ItemActionPeer::clearInstancePool();
            ItemActionPeer::clearRelatedInstancePool();
            $con->commit();

            return $affectedRows;
        } catch (Exception $e) {
            $con->rollBack();
            throw $e;
        }
    }

    /**
     * Performs a DELETE on the database, given a ItemAction or Criteria object OR a primary key value.
     *
     * @param      mixed $values Criteria or ItemAction object or primary key or array of primary keys
     *              which is used to create the DELETE statement
     * @param      PropelPDO $con the connection to use
     * @return int The number of affected rows (if supported by underlying database driver).  This includes CASCADE-related rows
     *				if supported by native driver or if emulated using Propel.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
     public static function doDelete($values, PropelPDO $con = null)
     {
        if ($con === null) {
            $con = Propel::getConnection(ItemActionPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        if ($values instanceof Criteria) {
            // invalidate the cache for all objects of this type, since we have no
            // way of knowing (without running a query) what objects should be invalidated
            // from the cache based on this Criteria.
            ItemActionPeer::clearInstancePool();
            // rename for clarity
            $criteria = clone $values;
        } elseif ($values instanceof ItemAction) { // it's a model object
            // invalidate the cache for this single object
            ItemActionPeer::removeInstanceFromPool($values);
            // create criteria based on pk values
            $criteria = $values->buildPkeyCriteria();
        } else { // it's a primary key, or an array of pks
            $criteria = new Criteria(ItemActionPeer::DATABASE_NAME);
            $criteria->add(ItemActionPeer::ITEM_ACTION_ID, (array) $values, Criteria::IN);
            // invalidate the cache for this object(s)
            foreach ((array) $values as $singleval) {
                ItemActionPeer::removeInstanceFromPool($singleval);
            }
        }

        // Set the correct dbName
        $criteria->setDbName(ItemActionPeer::DATABASE_NAME);

        $affectedRows = 0; // initialize var to track total num of affected rows

        try {
            // use transaction because $criteria could contain info
            // for more than one table or we could emulating ON DELETE CASCADE, etc.
            $con->beginTransaction();

            $affectedRows += BasePeer::doDelete($criteria, $con);
            ItemActionPeer::clearRelatedInstancePool();
            $con->commit();

            return $affectedRows;
        } catch (Exception $e) {
            $con->rollBack();
            throw $e;
        }
    }

    /**
     * Validates all modified columns of given ItemAction object.
     * If parameter $columns is either a single column name or an array of column names
     * than only those columns are validated.
     *
     * NOTICE: This does not apply to primary or foreign keys for now.
     *
     * @param ItemAction $obj The object to validate.
     * @param      mixed $cols Column name or array of column names.
     *
     * @return mixed TRUE if all columns are valid or the error message of the first invalid column.
     */
    public static function doValidate($obj, $cols = null)
    {
        $columns = array();

        if ($cols) {
            $dbMap = Propel::getDatabaseMap(ItemActionPeer::DATABASE_NAME);
            $tableMap = $dbMap->getTable(ItemActionPeer::TABLE_NAME);

            if (! is_array($cols)) {
                $cols = array($cols);
            }

            foreach ($cols as $colName) {
                if ($tableMap->hasColumn($colName)) {
                    $get = 'get' . $tableMap->getColumn($colName)->getPhpName();
                    $columns[$colName] = $obj->$get();
                }
            }
        } else {

        }

        return BasePeer::doValidate(ItemActionPeer::DATABASE_NAME, ItemActionPeer::TABLE_NAME, $columns);
    }

    /**
     * Retrieve a single object by pkey.
     *
     * @param int $pk the primary key.
     * @param      PropelPDO $con the connection to use
     * @return ItemAction
     */
    public static function retrieveByPK($pk, PropelPDO $con = null)
    {

        if (null !== ($obj = ItemActionPeer::getInstanceFromPool((string) $pk))) {
            return $obj;
        }

        if ($con === null) {
            $con = Propel::getConnection(ItemActionPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria = new Criteria(ItemActionPeer::DATABASE_NAME);
        $criteria->add(ItemActionPeer::ITEM_ACTION_ID, $pk);

        $v = ItemActionPeer::doSelect($criteria, $con);

        return !empty($v) > 0 ? $v[0] : null;
    }

    /**
     * Retrieve multiple objects by pkey.
     *
     * @param      array $pks List of primary keys
     * @param      PropelPDO $con the connection to use
     * @return ItemAction[]
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function retrieveByPKs($pks, PropelPDO $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection(ItemActionPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $objs = null;
        if (empty($pks)) {
            $objs = array();
        } else {
            $criteria = new Criteria(ItemActionPeer::DATABASE_NAME);
            $criteria->add(ItemActionPeer::ITEM_ACTION_ID, $pks, Criteria::IN);
            $objs = ItemActionPeer::doSelect($criteria, $con);
        }

        return $objs;
    }

} // BaseItemActionPeer

// This is the static code needed to register the TableMap for this table with the main Propel class.
//
BaseItemActionPeer::buildTableMap();

