<?php


/**
 * Base class that represents a row from the 'item' table.
 *
 *
 *
 * @package    propel.generator.clavis.om
 */
abstract class BaseItem extends BaseObject implements Persistent
{
    /**
     * Peer class name
     */
    const PEER = 'ItemPeer';

    /**
     * The Peer class.
     * Instance provides a convenient way of calling static methods on a class
     * that calling code may not be able to identify.
     * @var        ItemPeer
     */
    protected static $peer;

    /**
     * The flag var to prevent infinite loop in deep copy
     * @var       boolean
     */
    protected $startCopy = false;

    /**
     * The value for the item_id field.
     * @var        int
     */
    protected $item_id;

    /**
     * The value for the title field.
     * @var        string
     */
    protected $title;

    /**
     * The value for the manifestation_id field.
     * @var        int
     */
    protected $manifestation_id;

    /**
     * The value for the manifestation_dewey field.
     * @var        string
     */
    protected $manifestation_dewey;

    /**
     * The value for the item_media field.
     * @var        string
     */
    protected $item_media;

    /**
     * The value for the item_status field.
     * @var        string
     */
    protected $item_status;

    /**
     * The value for the item_order_status field.
     * @var        string
     */
    protected $item_order_status;

    /**
     * The value for the item_icon field.
     * @var        string
     */
    protected $item_icon;

    /**
     * The value for the physical_status field.
     * @var        string
     */
    protected $physical_status;

    /**
     * The value for the item_source field.
     * @var        string
     */
    protected $item_source;

    /**
     * The value for the opac_visible field.
     * @var        boolean
     */
    protected $opac_visible;

    /**
     * The value for the inventory_serie_id field.
     * @var        string
     */
    protected $inventory_serie_id;

    /**
     * The value for the inventory_number field.
     * @var        int
     */
    protected $inventory_number;

    /**
     * The value for the inventory_date field.
     * @var        string
     */
    protected $inventory_date;

    /**
     * The value for the owner_library_id field.
     * @var        int
     */
    protected $owner_library_id;

    /**
     * The value for the home_library_id field.
     * @var        int
     */
    protected $home_library_id;

    /**
     * The value for the collocation field.
     * @var        string
     */
    protected $collocation;

    /**
     * The value for the section field.
     * @var        string
     */
    protected $section;

    /**
     * The value for the sequence1 field.
     * @var        string
     */
    protected $sequence1;

    /**
     * The value for the sequence2 field.
     * @var        string
     */
    protected $sequence2;

    /**
     * The value for the specification field.
     * @var        string
     */
    protected $specification;

    /**
     * The value for the reprint field.
     * @var        string
     */
    protected $reprint;

    /**
     * The value for the width field.
     * @var        int
     */
    protected $width;

    /**
     * The value for the height field.
     * @var        int
     */
    protected $height;

    /**
     * The value for the weight field.
     * @var        string
     */
    protected $weight;

    /**
     * The value for the volume_number field.
     * @var        int
     */
    protected $volume_number;

    /**
     * The value for the volume_text field.
     * @var        string
     */
    protected $volume_text;

    /**
     * The value for the mediapackage_size field.
     * Note: this column has a database default value of: 1
     * @var        int
     */
    protected $mediapackage_size;

    /**
     * The value for the current_loan_id field.
     * @var        int
     */
    protected $current_loan_id;

    /**
     * The value for the loan_class field.
     * @var        string
     */
    protected $loan_class;

    /**
     * The value for the last_seen field.
     * @var        string
     */
    protected $last_seen;

    /**
     * The value for the loan_status field.
     * @var        string
     */
    protected $loan_status;

    /**
     * The value for the loan_alert field.
     * @var        string
     */
    protected $loan_alert;

    /**
     * The value for the loan_alert_note field.
     * @var        string
     */
    protected $loan_alert_note;

    /**
     * The value for the usage_count field.
     * Note: this column has a database default value of: 0
     * @var        int
     */
    protected $usage_count;

    /**
     * The value for the delivery_library_id field.
     * @var        int
     */
    protected $delivery_library_id;

    /**
     * The value for the due_date field.
     * @var        string
     */
    protected $due_date;

    /**
     * The value for the patron_id field.
     * @var        int
     */
    protected $patron_id;

    /**
     * The value for the external_library_id field.
     * @var        int
     */
    protected $external_library_id;

    /**
     * The value for the renewal_count field.
     * @var        int
     */
    protected $renewal_count;

    /**
     * The value for the notify_count field.
     * Note: this column has a database default value of: 0
     * @var        int
     */
    protected $notify_count;

    /**
     * The value for the check_out field.
     * @var        string
     */
    protected $check_out;

    /**
     * The value for the check_in field.
     * @var        string
     */
    protected $check_in;

    /**
     * The value for the ill_timestamp field.
     * @var        string
     */
    protected $ill_timestamp;

    /**
     * The value for the supplier_id field.
     * @var        int
     */
    protected $supplier_id;

    /**
     * The value for the invoice_id field.
     * @var        int
     */
    protected $invoice_id;

    /**
     * The value for the order_id field.
     * @var        int
     */
    protected $order_id;

    /**
     * The value for the budget_id field.
     * @var        int
     */
    protected $budget_id;

    /**
     * The value for the currency field.
     * @var        string
     */
    protected $currency;

    /**
     * The value for the currency_value field.
     * @var        string
     */
    protected $currency_value;

    /**
     * The value for the discount_value field.
     * @var        string
     */
    protected $discount_value;

    /**
     * The value for the inventory_value field.
     * @var        string
     */
    protected $inventory_value;

    /**
     * The value for the issue_inventory_number field.
     * @var        int
     */
    protected $issue_inventory_number;

    /**
     * The value for the issue_id field.
     * @var        int
     */
    protected $issue_id;

    /**
     * The value for the issue_year field.
     * @var        string
     */
    protected $issue_year;

    /**
     * The value for the issue_number field.
     * @var        int
     */
    protected $issue_number;

    /**
     * The value for the issue_description field.
     * @var        string
     */
    protected $issue_description;

    /**
     * The value for the issue_arrival_date field.
     * @var        string
     */
    protected $issue_arrival_date;

    /**
     * The value for the issue_arrival_date_expected field.
     * @var        string
     */
    protected $issue_arrival_date_expected;

    /**
     * The value for the issue_status field.
     * @var        string
     */
    protected $issue_status;

    /**
     * The value for the subscription_id field.
     * @var        int
     */
    protected $subscription_id;

    /**
     * The value for the consistency_note_id field.
     * @var        int
     */
    protected $consistency_note_id;

    /**
     * The value for the actual_library_id field.
     * @var        int
     */
    protected $actual_library_id;

    /**
     * The value for the barcode field.
     * @var        string
     */
    protected $barcode;

    /**
     * The value for the rfid_code field.
     * @var        string
     */
    protected $rfid_code;

    /**
     * The value for the custom_field1 field.
     * @var        string
     */
    protected $custom_field1;

    /**
     * The value for the custom_field2 field.
     * @var        string
     */
    protected $custom_field2;

    /**
     * The value for the custom_field3 field.
     * @var        string
     */
    protected $custom_field3;

    /**
     * The value for the unimarc field.
     * @var        string
     */
    protected $unimarc;

    /**
     * The value for the last_sbn_sync field.
     * @var        string
     */
    protected $last_sbn_sync;

    /**
     * The value for the date_discarded field.
     * @var        string
     */
    protected $date_discarded;

    /**
     * The value for the discard_note field.
     * @var        string
     */
    protected $discard_note;

    /**
     * The value for the date_created field.
     * @var        string
     */
    protected $date_created;

    /**
     * The value for the date_updated field.
     * @var        string
     */
    protected $date_updated;

    /**
     * The value for the created_by field.
     * @var        int
     */
    protected $created_by;

    /**
     * The value for the modified_by field.
     * @var        int
     */
    protected $modified_by;

    /**
     * @var        Librarian
     */
    protected $aLibrarianRelatedByCreatedBy;

    /**
     * @var        Librarian
     */
    protected $aLibrarianRelatedByModifiedBy;

    /**
     * @var        Issue
     */
    protected $aIssue;

    /**
     * @var        Manifestation
     */
    protected $aManifestation;

    /**
     * @var        ConsistencyNote
     */
    protected $aConsistencyNote;

    /**
     * @var        Library
     */
    protected $aLibraryRelatedByOwnerLibraryId;

    /**
     * @var        Library
     */
    protected $aLibraryRelatedByHomeLibraryId;

    /**
     * @var        Library
     */
    protected $aLibraryRelatedByDeliveryLibraryId;

    /**
     * @var        Library
     */
    protected $aLibraryRelatedByActualLibraryId;

    /**
     * @var        InventorySerie
     */
    protected $aInventorySerie;

    /**
     * @var        PurchaseOrder
     */
    protected $aPurchaseOrder;

    /**
     * @var        Invoice
     */
    protected $aInvoice;

    /**
     * @var        Supplier
     */
    protected $aSupplier;

    /**
     * @var        Patron
     */
    protected $aPatron;

    /**
     * @var        Library
     */
    protected $aLibraryRelatedByExternalLibraryId;

    /**
     * @var        Loan
     */
    protected $aLoanRelatedByCurrentLoanId;

    /**
     * @var        Budget
     */
    protected $aBudget;

    /**
     * @var        PropelObjectCollection|ItemAction[] Collection to store aggregation of ItemAction objects.
     */
    protected $collItemActions;
    protected $collItemActionsPartial;

    /**
     * @var        PropelObjectCollection|ItemNote[] Collection to store aggregation of ItemNote objects.
     */
    protected $collItemNotes;
    protected $collItemNotesPartial;

    /**
     * @var        PropelObjectCollection|ItemRequest[] Collection to store aggregation of ItemRequest objects.
     */
    protected $collItemRequests;
    protected $collItemRequestsPartial;

    /**
     * @var        PropelObjectCollection|Loan[] Collection to store aggregation of Loan objects.
     */
    protected $collLoansRelatedByItemId;
    protected $collLoansRelatedByItemIdPartial;

    /**
     * @var        PropelObjectCollection|LAuthorityItem[] Collection to store aggregation of LAuthorityItem objects.
     */
    protected $collLAuthorityItems;
    protected $collLAuthorityItemsPartial;

    /**
     * @var        PropelObjectCollection|PurchaseProposal[] Collection to store aggregation of PurchaseProposal objects.
     */
    protected $collPurchaseProposals;
    protected $collPurchaseProposalsPartial;

    /**
     * Flag to prevent endless save loop, if this object is referenced
     * by another object which falls in this transaction.
     * @var        boolean
     */
    protected $alreadyInSave = false;

    /**
     * Flag to prevent endless validation loop, if this object is referenced
     * by another object which falls in this transaction.
     * @var        boolean
     */
    protected $alreadyInValidation = false;

    /**
     * Flag to prevent endless clearAllReferences($deep=true) loop, if this object is referenced
     * @var        boolean
     */
    protected $alreadyInClearAllReferencesDeep = false;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $itemActionsScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $itemNotesScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $itemRequestsScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $loansRelatedByItemIdScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $lAuthorityItemsScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $purchaseProposalsScheduledForDeletion = null;

    /**
     * Applies default values to this object.
     * This method should be called from the object's constructor (or
     * equivalent initialization method).
     * @see        __construct()
     */
    public function applyDefaultValues()
    {
        $this->mediapackage_size = 1;
        $this->usage_count = 0;
        $this->notify_count = 0;
    }

    /**
     * Initializes internal state of BaseItem object.
     * @see        applyDefaults()
     */
    public function __construct()
    {
        parent::__construct();
        $this->applyDefaultValues();
    }

    /**
     * Get the [item_id] column value.
     *
     * @return int
     */
    public function getItemId()
    {

        return $this->item_id;
    }

    /**
     * Get the [title] column value.
     *
     * @return string
     */
    public function getTitle()
    {

        return $this->title;
    }

    /**
     * Get the [manifestation_id] column value.
     *
     * @return int
     */
    public function getManifestationId()
    {

        return $this->manifestation_id;
    }

    /**
     * Get the [manifestation_dewey] column value.
     *
     * @return string
     */
    public function getManifestationDewey()
    {

        return $this->manifestation_dewey;
    }

    /**
     * Get the [item_media] column value.
     *
     * @return string
     */
    public function getItemMedia()
    {

        return $this->item_media;
    }

    /**
     * Get the [item_status] column value.
     *
     * @return string
     */
    public function getItemStatus()
    {

        return $this->item_status;
    }

    /**
     * Get the [item_order_status] column value.
     *
     * @return string
     */
    public function getItemOrderStatus()
    {

        return $this->item_order_status;
    }

    /**
     * Get the [item_icon] column value.
     *
     * @return string
     */
    public function getItemIcon()
    {

        return $this->item_icon;
    }

    /**
     * Get the [physical_status] column value.
     *
     * @return string
     */
    public function getPhysicalStatus()
    {

        return $this->physical_status;
    }

    /**
     * Get the [item_source] column value.
     *
     * @return string
     */
    public function getItemSource()
    {

        return $this->item_source;
    }

    /**
     * Get the [opac_visible] column value.
     *
     * @return boolean
     */
    public function getOpacVisible()
    {

        return $this->opac_visible;
    }

    /**
     * Get the [inventory_serie_id] column value.
     *
     * @return string
     */
    public function getInventorySerieId()
    {

        return $this->inventory_serie_id;
    }

    /**
     * Get the [inventory_number] column value.
     *
     * @return int
     */
    public function getInventoryNumber()
    {

        return $this->inventory_number;
    }

    /**
     * Get the [optionally formatted] temporal [inventory_date] column value.
     *
     *
     * @param string $format The date/time format string (either date()-style or strftime()-style).
     *				 If format is null, then the raw DateTime object will be returned.
     * @return mixed Formatted date/time value as string or DateTime object (if format is null), null if column is null, and 0 if column value is 0000-00-00
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getInventoryDate($format = '%F %T')
    {
        if ($this->inventory_date === null) {
            return null;
        }

        if ($this->inventory_date === '0000-00-00') {
            // while technically this is not a default value of null,
            // this seems to be closest in meaning.
            return null;
        }

        try {
            $dt = new DateTime($this->inventory_date);
        } catch (Exception $x) {
            throw new PropelException("Internally stored date/time/timestamp value could not be converted to DateTime: " . var_export($this->inventory_date, true), $x);
        }

        if ($format === null) {
            // Because propel.useDateTimeClass is true, we return a DateTime object.
            return $dt;
        }

        if (strpos($format, '%') !== false) {
            return strftime($format, $dt->format('U'));
        }

        return $dt->format($format);

    }

    /**
     * Get the [owner_library_id] column value.
     *
     * @return int
     */
    public function getOwnerLibraryId()
    {

        return $this->owner_library_id;
    }

    /**
     * Get the [home_library_id] column value.
     *
     * @return int
     */
    public function getHomeLibraryId()
    {

        return $this->home_library_id;
    }

    /**
     * Get the [collocation] column value.
     *
     * @return string
     */
    public function getCollocation()
    {

        return $this->collocation;
    }

    /**
     * Get the [section] column value.
     *
     * @return string
     */
    public function getSection()
    {

        return $this->section;
    }

    /**
     * Get the [sequence1] column value.
     *
     * @return string
     */
    public function getSequence1()
    {

        return $this->sequence1;
    }

    /**
     * Get the [sequence2] column value.
     *
     * @return string
     */
    public function getSequence2()
    {

        return $this->sequence2;
    }

    /**
     * Get the [specification] column value.
     *
     * @return string
     */
    public function getSpecification()
    {

        return $this->specification;
    }

    /**
     * Get the [reprint] column value.
     *
     * @return string
     */
    public function getReprint()
    {

        return $this->reprint;
    }

    /**
     * Get the [width] column value.
     *
     * @return int
     */
    public function getWidth()
    {

        return $this->width;
    }

    /**
     * Get the [height] column value.
     *
     * @return int
     */
    public function getHeight()
    {

        return $this->height;
    }

    /**
     * Get the [weight] column value.
     *
     * @return string
     */
    public function getWeight()
    {

        return $this->weight;
    }

    /**
     * Get the [volume_number] column value.
     *
     * @return int
     */
    public function getVolumeNumber()
    {

        return $this->volume_number;
    }

    /**
     * Get the [volume_text] column value.
     *
     * @return string
     */
    public function getVolumeText()
    {

        return $this->volume_text;
    }

    /**
     * Get the [mediapackage_size] column value.
     *
     * @return int
     */
    public function getMediapackageSize()
    {

        return $this->mediapackage_size;
    }

    /**
     * Get the [current_loan_id] column value.
     *
     * @return int
     */
    public function getCurrentLoanId()
    {

        return $this->current_loan_id;
    }

    /**
     * Get the [loan_class] column value.
     *
     * @return string
     */
    public function getLoanClass()
    {

        return $this->loan_class;
    }

    /**
     * Get the [optionally formatted] temporal [last_seen] column value.
     *
     *
     * @param string $format The date/time format string (either date()-style or strftime()-style).
     *				 If format is null, then the raw DateTime object will be returned.
     * @return mixed Formatted date/time value as string or DateTime object (if format is null), null if column is null, and 0 if column value is 0000-00-00
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getLastSeen($format = '%F %T')
    {
        if ($this->last_seen === null) {
            return null;
        }

        if ($this->last_seen === '0000-00-00') {
            // while technically this is not a default value of null,
            // this seems to be closest in meaning.
            return null;
        }

        try {
            $dt = new DateTime($this->last_seen);
        } catch (Exception $x) {
            throw new PropelException("Internally stored date/time/timestamp value could not be converted to DateTime: " . var_export($this->last_seen, true), $x);
        }

        if ($format === null) {
            // Because propel.useDateTimeClass is true, we return a DateTime object.
            return $dt;
        }

        if (strpos($format, '%') !== false) {
            return strftime($format, $dt->format('U'));
        }

        return $dt->format($format);

    }

    /**
     * Get the [loan_status] column value.
     *
     * @return string
     */
    public function getLoanStatus()
    {

        return $this->loan_status;
    }

    /**
     * Get the [loan_alert] column value.
     *
     * @return string
     */
    public function getLoanAlert()
    {

        return $this->loan_alert;
    }

    /**
     * Get the [loan_alert_note] column value.
     *
     * @return string
     */
    public function getLoanAlertNote()
    {

        return $this->loan_alert_note;
    }

    /**
     * Get the [usage_count] column value.
     *
     * @return int
     */
    public function getUsageCount()
    {

        return $this->usage_count;
    }

    /**
     * Get the [delivery_library_id] column value.
     *
     * @return int
     */
    public function getDeliveryLibraryId()
    {

        return $this->delivery_library_id;
    }

    /**
     * Get the [optionally formatted] temporal [due_date] column value.
     *
     *
     * @param string $format The date/time format string (either date()-style or strftime()-style).
     *				 If format is null, then the raw DateTime object will be returned.
     * @return mixed Formatted date/time value as string or DateTime object (if format is null), null if column is null, and 0 if column value is 0000-00-00
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getDueDate($format = '%F %T')
    {
        if ($this->due_date === null) {
            return null;
        }

        if ($this->due_date === '0000-00-00') {
            // while technically this is not a default value of null,
            // this seems to be closest in meaning.
            return null;
        }

        try {
            $dt = new DateTime($this->due_date);
        } catch (Exception $x) {
            throw new PropelException("Internally stored date/time/timestamp value could not be converted to DateTime: " . var_export($this->due_date, true), $x);
        }

        if ($format === null) {
            // Because propel.useDateTimeClass is true, we return a DateTime object.
            return $dt;
        }

        if (strpos($format, '%') !== false) {
            return strftime($format, $dt->format('U'));
        }

        return $dt->format($format);

    }

    /**
     * Get the [patron_id] column value.
     *
     * @return int
     */
    public function getPatronId()
    {

        return $this->patron_id;
    }

    /**
     * Get the [external_library_id] column value.
     *
     * @return int
     */
    public function getExternalLibraryId()
    {

        return $this->external_library_id;
    }

    /**
     * Get the [renewal_count] column value.
     *
     * @return int
     */
    public function getRenewalCount()
    {

        return $this->renewal_count;
    }

    /**
     * Get the [notify_count] column value.
     *
     * @return int
     */
    public function getNotifyCount()
    {

        return $this->notify_count;
    }

    /**
     * Get the [optionally formatted] temporal [check_out] column value.
     *
     *
     * @param string $format The date/time format string (either date()-style or strftime()-style).
     *				 If format is null, then the raw DateTime object will be returned.
     * @return mixed Formatted date/time value as string or DateTime object (if format is null), null if column is null, and 0 if column value is 0000-00-00 00:00:00
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getCheckOut($format = 'Y-m-d H:i:s')
    {
        if ($this->check_out === null) {
            return null;
        }

        if ($this->check_out === '0000-00-00 00:00:00') {
            // while technically this is not a default value of null,
            // this seems to be closest in meaning.
            return null;
        }

        try {
            $dt = new DateTime($this->check_out);
        } catch (Exception $x) {
            throw new PropelException("Internally stored date/time/timestamp value could not be converted to DateTime: " . var_export($this->check_out, true), $x);
        }

        if ($format === null) {
            // Because propel.useDateTimeClass is true, we return a DateTime object.
            return $dt;
        }

        if (strpos($format, '%') !== false) {
            return strftime($format, $dt->format('U'));
        }

        return $dt->format($format);

    }

    /**
     * Get the [optionally formatted] temporal [check_in] column value.
     *
     *
     * @param string $format The date/time format string (either date()-style or strftime()-style).
     *				 If format is null, then the raw DateTime object will be returned.
     * @return mixed Formatted date/time value as string or DateTime object (if format is null), null if column is null, and 0 if column value is 0000-00-00 00:00:00
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getCheckIn($format = 'Y-m-d H:i:s')
    {
        if ($this->check_in === null) {
            return null;
        }

        if ($this->check_in === '0000-00-00 00:00:00') {
            // while technically this is not a default value of null,
            // this seems to be closest in meaning.
            return null;
        }

        try {
            $dt = new DateTime($this->check_in);
        } catch (Exception $x) {
            throw new PropelException("Internally stored date/time/timestamp value could not be converted to DateTime: " . var_export($this->check_in, true), $x);
        }

        if ($format === null) {
            // Because propel.useDateTimeClass is true, we return a DateTime object.
            return $dt;
        }

        if (strpos($format, '%') !== false) {
            return strftime($format, $dt->format('U'));
        }

        return $dt->format($format);

    }

    /**
     * Get the [optionally formatted] temporal [ill_timestamp] column value.
     *
     *
     * @param string $format The date/time format string (either date()-style or strftime()-style).
     *				 If format is null, then the raw DateTime object will be returned.
     * @return mixed Formatted date/time value as string or DateTime object (if format is null), null if column is null, and 0 if column value is 0000-00-00 00:00:00
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getIllTimestamp($format = 'Y-m-d H:i:s')
    {
        if ($this->ill_timestamp === null) {
            return null;
        }

        if ($this->ill_timestamp === '0000-00-00 00:00:00') {
            // while technically this is not a default value of null,
            // this seems to be closest in meaning.
            return null;
        }

        try {
            $dt = new DateTime($this->ill_timestamp);
        } catch (Exception $x) {
            throw new PropelException("Internally stored date/time/timestamp value could not be converted to DateTime: " . var_export($this->ill_timestamp, true), $x);
        }

        if ($format === null) {
            // Because propel.useDateTimeClass is true, we return a DateTime object.
            return $dt;
        }

        if (strpos($format, '%') !== false) {
            return strftime($format, $dt->format('U'));
        }

        return $dt->format($format);

    }

    /**
     * Get the [supplier_id] column value.
     *
     * @return int
     */
    public function getSupplierId()
    {

        return $this->supplier_id;
    }

    /**
     * Get the [invoice_id] column value.
     *
     * @return int
     */
    public function getInvoiceId()
    {

        return $this->invoice_id;
    }

    /**
     * Get the [order_id] column value.
     *
     * @return int
     */
    public function getOrderId()
    {

        return $this->order_id;
    }

    /**
     * Get the [budget_id] column value.
     *
     * @return int
     */
    public function getBudgetId()
    {

        return $this->budget_id;
    }

    /**
     * Get the [currency] column value.
     *
     * @return string
     */
    public function getCurrency()
    {

        return $this->currency;
    }

    /**
     * Get the [currency_value] column value.
     *
     * @return string
     */
    public function getCurrencyValue()
    {

        return $this->currency_value;
    }

    /**
     * Get the [discount_value] column value.
     *
     * @return string
     */
    public function getDiscountValue()
    {

        return $this->discount_value;
    }

    /**
     * Get the [inventory_value] column value.
     *
     * @return string
     */
    public function getInventoryValue()
    {

        return $this->inventory_value;
    }

    /**
     * Get the [issue_inventory_number] column value.
     *
     * @return int
     */
    public function getIssueInventoryNumber()
    {

        return $this->issue_inventory_number;
    }

    /**
     * Get the [issue_id] column value.
     *
     * @return int
     */
    public function getIssueId()
    {

        return $this->issue_id;
    }

    /**
     * Get the [issue_year] column value.
     *
     * @return string
     */
    public function getIssueYear()
    {

        return $this->issue_year;
    }

    /**
     * Get the [issue_number] column value.
     *
     * @return int
     */
    public function getIssueNumber()
    {

        return $this->issue_number;
    }

    /**
     * Get the [issue_description] column value.
     *
     * @return string
     */
    public function getIssueDescription()
    {

        return $this->issue_description;
    }

    /**
     * Get the [optionally formatted] temporal [issue_arrival_date] column value.
     *
     *
     * @param string $format The date/time format string (either date()-style or strftime()-style).
     *				 If format is null, then the raw DateTime object will be returned.
     * @return mixed Formatted date/time value as string or DateTime object (if format is null), null if column is null, and 0 if column value is 0000-00-00
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getIssueArrivalDate($format = '%F %T')
    {
        if ($this->issue_arrival_date === null) {
            return null;
        }

        if ($this->issue_arrival_date === '0000-00-00') {
            // while technically this is not a default value of null,
            // this seems to be closest in meaning.
            return null;
        }

        try {
            $dt = new DateTime($this->issue_arrival_date);
        } catch (Exception $x) {
            throw new PropelException("Internally stored date/time/timestamp value could not be converted to DateTime: " . var_export($this->issue_arrival_date, true), $x);
        }

        if ($format === null) {
            // Because propel.useDateTimeClass is true, we return a DateTime object.
            return $dt;
        }

        if (strpos($format, '%') !== false) {
            return strftime($format, $dt->format('U'));
        }

        return $dt->format($format);

    }

    /**
     * Get the [optionally formatted] temporal [issue_arrival_date_expected] column value.
     *
     *
     * @param string $format The date/time format string (either date()-style or strftime()-style).
     *				 If format is null, then the raw DateTime object will be returned.
     * @return mixed Formatted date/time value as string or DateTime object (if format is null), null if column is null, and 0 if column value is 0000-00-00
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getIssueArrivalDateExpected($format = '%F %T')
    {
        if ($this->issue_arrival_date_expected === null) {
            return null;
        }

        if ($this->issue_arrival_date_expected === '0000-00-00') {
            // while technically this is not a default value of null,
            // this seems to be closest in meaning.
            return null;
        }

        try {
            $dt = new DateTime($this->issue_arrival_date_expected);
        } catch (Exception $x) {
            throw new PropelException("Internally stored date/time/timestamp value could not be converted to DateTime: " . var_export($this->issue_arrival_date_expected, true), $x);
        }

        if ($format === null) {
            // Because propel.useDateTimeClass is true, we return a DateTime object.
            return $dt;
        }

        if (strpos($format, '%') !== false) {
            return strftime($format, $dt->format('U'));
        }

        return $dt->format($format);

    }

    /**
     * Get the [issue_status] column value.
     *
     * @return string
     */
    public function getIssueStatus()
    {

        return $this->issue_status;
    }

    /**
     * Get the [subscription_id] column value.
     *
     * @return int
     */
    public function getSubscriptionId()
    {

        return $this->subscription_id;
    }

    /**
     * Get the [consistency_note_id] column value.
     *
     * @return int
     */
    public function getConsistencyNoteId()
    {

        return $this->consistency_note_id;
    }

    /**
     * Get the [actual_library_id] column value.
     *
     * @return int
     */
    public function getActualLibraryId()
    {

        return $this->actual_library_id;
    }

    /**
     * Get the [barcode] column value.
     *
     * @return string
     */
    public function getBarcode()
    {

        return $this->barcode;
    }

    /**
     * Get the [rfid_code] column value.
     *
     * @return string
     */
    public function getRfidCode()
    {

        return $this->rfid_code;
    }

    /**
     * Get the [custom_field1] column value.
     *
     * @return string
     */
    public function getCustomField1()
    {

        return $this->custom_field1;
    }

    /**
     * Get the [custom_field2] column value.
     *
     * @return string
     */
    public function getCustomField2()
    {

        return $this->custom_field2;
    }

    /**
     * Get the [custom_field3] column value.
     *
     * @return string
     */
    public function getCustomField3()
    {

        return $this->custom_field3;
    }

    /**
     * Get the [unimarc] column value.
     *
     * @return string
     */
    public function getUnimarc()
    {

        return $this->unimarc;
    }

    /**
     * Get the [optionally formatted] temporal [last_sbn_sync] column value.
     *
     *
     * @param string $format The date/time format string (either date()-style or strftime()-style).
     *				 If format is null, then the raw DateTime object will be returned.
     * @return mixed Formatted date/time value as string or DateTime object (if format is null), null if column is null, and 0 if column value is 0000-00-00 00:00:00
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getLastSbnSync($format = 'Y-m-d H:i:s')
    {
        if ($this->last_sbn_sync === null) {
            return null;
        }

        if ($this->last_sbn_sync === '0000-00-00 00:00:00') {
            // while technically this is not a default value of null,
            // this seems to be closest in meaning.
            return null;
        }

        try {
            $dt = new DateTime($this->last_sbn_sync);
        } catch (Exception $x) {
            throw new PropelException("Internally stored date/time/timestamp value could not be converted to DateTime: " . var_export($this->last_sbn_sync, true), $x);
        }

        if ($format === null) {
            // Because propel.useDateTimeClass is true, we return a DateTime object.
            return $dt;
        }

        if (strpos($format, '%') !== false) {
            return strftime($format, $dt->format('U'));
        }

        return $dt->format($format);

    }

    /**
     * Get the [optionally formatted] temporal [date_discarded] column value.
     *
     *
     * @param string $format The date/time format string (either date()-style or strftime()-style).
     *				 If format is null, then the raw DateTime object will be returned.
     * @return mixed Formatted date/time value as string or DateTime object (if format is null), null if column is null, and 0 if column value is 0000-00-00 00:00:00
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getDateDiscarded($format = 'Y-m-d H:i:s')
    {
        if ($this->date_discarded === null) {
            return null;
        }

        if ($this->date_discarded === '0000-00-00 00:00:00') {
            // while technically this is not a default value of null,
            // this seems to be closest in meaning.
            return null;
        }

        try {
            $dt = new DateTime($this->date_discarded);
        } catch (Exception $x) {
            throw new PropelException("Internally stored date/time/timestamp value could not be converted to DateTime: " . var_export($this->date_discarded, true), $x);
        }

        if ($format === null) {
            // Because propel.useDateTimeClass is true, we return a DateTime object.
            return $dt;
        }

        if (strpos($format, '%') !== false) {
            return strftime($format, $dt->format('U'));
        }

        return $dt->format($format);

    }

    /**
     * Get the [discard_note] column value.
     *
     * @return string
     */
    public function getDiscardNote()
    {

        return $this->discard_note;
    }

    /**
     * Get the [optionally formatted] temporal [date_created] column value.
     *
     *
     * @param string $format The date/time format string (either date()-style or strftime()-style).
     *				 If format is null, then the raw DateTime object will be returned.
     * @return mixed Formatted date/time value as string or DateTime object (if format is null), null if column is null, and 0 if column value is 0000-00-00 00:00:00
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getDateCreated($format = 'Y-m-d H:i:s')
    {
        if ($this->date_created === null) {
            return null;
        }

        if ($this->date_created === '0000-00-00 00:00:00') {
            // while technically this is not a default value of null,
            // this seems to be closest in meaning.
            return null;
        }

        try {
            $dt = new DateTime($this->date_created);
        } catch (Exception $x) {
            throw new PropelException("Internally stored date/time/timestamp value could not be converted to DateTime: " . var_export($this->date_created, true), $x);
        }

        if ($format === null) {
            // Because propel.useDateTimeClass is true, we return a DateTime object.
            return $dt;
        }

        if (strpos($format, '%') !== false) {
            return strftime($format, $dt->format('U'));
        }

        return $dt->format($format);

    }

    /**
     * Get the [optionally formatted] temporal [date_updated] column value.
     *
     *
     * @param string $format The date/time format string (either date()-style or strftime()-style).
     *				 If format is null, then the raw DateTime object will be returned.
     * @return mixed Formatted date/time value as string or DateTime object (if format is null), null if column is null, and 0 if column value is 0000-00-00 00:00:00
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getDateUpdated($format = 'Y-m-d H:i:s')
    {
        if ($this->date_updated === null) {
            return null;
        }

        if ($this->date_updated === '0000-00-00 00:00:00') {
            // while technically this is not a default value of null,
            // this seems to be closest in meaning.
            return null;
        }

        try {
            $dt = new DateTime($this->date_updated);
        } catch (Exception $x) {
            throw new PropelException("Internally stored date/time/timestamp value could not be converted to DateTime: " . var_export($this->date_updated, true), $x);
        }

        if ($format === null) {
            // Because propel.useDateTimeClass is true, we return a DateTime object.
            return $dt;
        }

        if (strpos($format, '%') !== false) {
            return strftime($format, $dt->format('U'));
        }

        return $dt->format($format);

    }

    /**
     * Get the [created_by] column value.
     *
     * @return int
     */
    public function getCreatedBy()
    {

        return $this->created_by;
    }

    /**
     * Get the [modified_by] column value.
     *
     * @return int
     */
    public function getModifiedBy()
    {

        return $this->modified_by;
    }

    /**
     * Set the value of [item_id] column.
     *
     * @param  int $v new value
     * @return Item The current object (for fluent API support)
     */
    public function setItemId($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->item_id !== $v) {
            $this->item_id = $v;
            $this->modifiedColumns[] = ItemPeer::ITEM_ID;
        }


        return $this;
    } // setItemId()

    /**
     * Set the value of [title] column.
     *
     * @param  string $v new value
     * @return Item The current object (for fluent API support)
     */
    public function setTitle($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->title !== $v) {
            $this->title = $v;
            $this->modifiedColumns[] = ItemPeer::TITLE;
        }


        return $this;
    } // setTitle()

    /**
     * Set the value of [manifestation_id] column.
     *
     * @param  int $v new value
     * @return Item The current object (for fluent API support)
     */
    public function setManifestationId($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->manifestation_id !== $v) {
            $this->manifestation_id = $v;
            $this->modifiedColumns[] = ItemPeer::MANIFESTATION_ID;
        }

        if ($this->aManifestation !== null && $this->aManifestation->getManifestationId() !== $v) {
            $this->aManifestation = null;
        }


        return $this;
    } // setManifestationId()

    /**
     * Set the value of [manifestation_dewey] column.
     *
     * @param  string $v new value
     * @return Item The current object (for fluent API support)
     */
    public function setManifestationDewey($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->manifestation_dewey !== $v) {
            $this->manifestation_dewey = $v;
            $this->modifiedColumns[] = ItemPeer::MANIFESTATION_DEWEY;
        }


        return $this;
    } // setManifestationDewey()

    /**
     * Set the value of [item_media] column.
     *
     * @param  string $v new value
     * @return Item The current object (for fluent API support)
     */
    public function setItemMedia($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->item_media !== $v) {
            $this->item_media = $v;
            $this->modifiedColumns[] = ItemPeer::ITEM_MEDIA;
        }


        return $this;
    } // setItemMedia()

    /**
     * Set the value of [item_status] column.
     *
     * @param  string $v new value
     * @return Item The current object (for fluent API support)
     */
    public function setItemStatus($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->item_status !== $v) {
            $this->item_status = $v;
            $this->modifiedColumns[] = ItemPeer::ITEM_STATUS;
        }


        return $this;
    } // setItemStatus()

    /**
     * Set the value of [item_order_status] column.
     *
     * @param  string $v new value
     * @return Item The current object (for fluent API support)
     */
    public function setItemOrderStatus($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->item_order_status !== $v) {
            $this->item_order_status = $v;
            $this->modifiedColumns[] = ItemPeer::ITEM_ORDER_STATUS;
        }


        return $this;
    } // setItemOrderStatus()

    /**
     * Set the value of [item_icon] column.
     *
     * @param  string $v new value
     * @return Item The current object (for fluent API support)
     */
    public function setItemIcon($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->item_icon !== $v) {
            $this->item_icon = $v;
            $this->modifiedColumns[] = ItemPeer::ITEM_ICON;
        }


        return $this;
    } // setItemIcon()

    /**
     * Set the value of [physical_status] column.
     *
     * @param  string $v new value
     * @return Item The current object (for fluent API support)
     */
    public function setPhysicalStatus($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->physical_status !== $v) {
            $this->physical_status = $v;
            $this->modifiedColumns[] = ItemPeer::PHYSICAL_STATUS;
        }


        return $this;
    } // setPhysicalStatus()

    /**
     * Set the value of [item_source] column.
     *
     * @param  string $v new value
     * @return Item The current object (for fluent API support)
     */
    public function setItemSource($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->item_source !== $v) {
            $this->item_source = $v;
            $this->modifiedColumns[] = ItemPeer::ITEM_SOURCE;
        }


        return $this;
    } // setItemSource()

    /**
     * Sets the value of the [opac_visible] column.
     * Non-boolean arguments are converted using the following rules:
     *   * 1, '1', 'true',  'on',  and 'yes' are converted to boolean true
     *   * 0, '0', 'false', 'off', and 'no'  are converted to boolean false
     * Check on string values is case insensitive (so 'FaLsE' is seen as 'false').
     *
     * @param boolean|integer|string $v The new value
     * @return Item The current object (for fluent API support)
     */
    public function setOpacVisible($v)
    {
        if ($v !== null) {
            if (is_string($v)) {
                $v = in_array(strtolower($v), array('false', 'off', '-', 'no', 'n', '0', '')) ? false : true;
            } else {
                $v = (boolean) $v;
            }
        }

        if ($this->opac_visible !== $v) {
            $this->opac_visible = $v;
            $this->modifiedColumns[] = ItemPeer::OPAC_VISIBLE;
        }


        return $this;
    } // setOpacVisible()

    /**
     * Set the value of [inventory_serie_id] column.
     *
     * @param  string $v new value
     * @return Item The current object (for fluent API support)
     */
    public function setInventorySerieId($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->inventory_serie_id !== $v) {
            $this->inventory_serie_id = $v;
            $this->modifiedColumns[] = ItemPeer::INVENTORY_SERIE_ID;
        }

        if ($this->aInventorySerie !== null && $this->aInventorySerie->getInventorySerieId() !== $v) {
            $this->aInventorySerie = null;
        }


        return $this;
    } // setInventorySerieId()

    /**
     * Set the value of [inventory_number] column.
     *
     * @param  int $v new value
     * @return Item The current object (for fluent API support)
     */
    public function setInventoryNumber($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->inventory_number !== $v) {
            $this->inventory_number = $v;
            $this->modifiedColumns[] = ItemPeer::INVENTORY_NUMBER;
        }


        return $this;
    } // setInventoryNumber()

    /**
     * Sets the value of [inventory_date] column to a normalized version of the date/time value specified.
     *
     * @param mixed $v string, integer (timestamp), or DateTime value.
     *               Empty strings are treated as null.
     * @return Item The current object (for fluent API support)
     */
    public function setInventoryDate($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->inventory_date !== null || $dt !== null) {
            $currentDateAsString = ($this->inventory_date !== null && $tmpDt = new DateTime($this->inventory_date)) ? $tmpDt->format('Y-m-d') : null;
            $newDateAsString = $dt ? $dt->format('Y-m-d') : null;
            if ($currentDateAsString !== $newDateAsString) {
                $this->inventory_date = $newDateAsString;
                $this->modifiedColumns[] = ItemPeer::INVENTORY_DATE;
            }
        } // if either are not null


        return $this;
    } // setInventoryDate()

    /**
     * Set the value of [owner_library_id] column.
     *
     * @param  int $v new value
     * @return Item The current object (for fluent API support)
     */
    public function setOwnerLibraryId($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->owner_library_id !== $v) {
            $this->owner_library_id = $v;
            $this->modifiedColumns[] = ItemPeer::OWNER_LIBRARY_ID;
        }

        if ($this->aLibraryRelatedByOwnerLibraryId !== null && $this->aLibraryRelatedByOwnerLibraryId->getLibraryId() !== $v) {
            $this->aLibraryRelatedByOwnerLibraryId = null;
        }


        return $this;
    } // setOwnerLibraryId()

    /**
     * Set the value of [home_library_id] column.
     *
     * @param  int $v new value
     * @return Item The current object (for fluent API support)
     */
    public function setHomeLibraryId($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->home_library_id !== $v) {
            $this->home_library_id = $v;
            $this->modifiedColumns[] = ItemPeer::HOME_LIBRARY_ID;
        }

        if ($this->aLibraryRelatedByHomeLibraryId !== null && $this->aLibraryRelatedByHomeLibraryId->getLibraryId() !== $v) {
            $this->aLibraryRelatedByHomeLibraryId = null;
        }


        return $this;
    } // setHomeLibraryId()

    /**
     * Set the value of [collocation] column.
     *
     * @param  string $v new value
     * @return Item The current object (for fluent API support)
     */
    public function setCollocation($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->collocation !== $v) {
            $this->collocation = $v;
            $this->modifiedColumns[] = ItemPeer::COLLOCATION;
        }


        return $this;
    } // setCollocation()

    /**
     * Set the value of [section] column.
     *
     * @param  string $v new value
     * @return Item The current object (for fluent API support)
     */
    public function setSection($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->section !== $v) {
            $this->section = $v;
            $this->modifiedColumns[] = ItemPeer::SECTION;
        }


        return $this;
    } // setSection()

    /**
     * Set the value of [sequence1] column.
     *
     * @param  string $v new value
     * @return Item The current object (for fluent API support)
     */
    public function setSequence1($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->sequence1 !== $v) {
            $this->sequence1 = $v;
            $this->modifiedColumns[] = ItemPeer::SEQUENCE1;
        }


        return $this;
    } // setSequence1()

    /**
     * Set the value of [sequence2] column.
     *
     * @param  string $v new value
     * @return Item The current object (for fluent API support)
     */
    public function setSequence2($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->sequence2 !== $v) {
            $this->sequence2 = $v;
            $this->modifiedColumns[] = ItemPeer::SEQUENCE2;
        }


        return $this;
    } // setSequence2()

    /**
     * Set the value of [specification] column.
     *
     * @param  string $v new value
     * @return Item The current object (for fluent API support)
     */
    public function setSpecification($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->specification !== $v) {
            $this->specification = $v;
            $this->modifiedColumns[] = ItemPeer::SPECIFICATION;
        }


        return $this;
    } // setSpecification()

    /**
     * Set the value of [reprint] column.
     *
     * @param  string $v new value
     * @return Item The current object (for fluent API support)
     */
    public function setReprint($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->reprint !== $v) {
            $this->reprint = $v;
            $this->modifiedColumns[] = ItemPeer::REPRINT;
        }


        return $this;
    } // setReprint()

    /**
     * Set the value of [width] column.
     *
     * @param  int $v new value
     * @return Item The current object (for fluent API support)
     */
    public function setWidth($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->width !== $v) {
            $this->width = $v;
            $this->modifiedColumns[] = ItemPeer::WIDTH;
        }


        return $this;
    } // setWidth()

    /**
     * Set the value of [height] column.
     *
     * @param  int $v new value
     * @return Item The current object (for fluent API support)
     */
    public function setHeight($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->height !== $v) {
            $this->height = $v;
            $this->modifiedColumns[] = ItemPeer::HEIGHT;
        }


        return $this;
    } // setHeight()

    /**
     * Set the value of [weight] column.
     *
     * @param  string $v new value
     * @return Item The current object (for fluent API support)
     */
    public function setWeight($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->weight !== $v) {
            $this->weight = $v;
            $this->modifiedColumns[] = ItemPeer::WEIGHT;
        }


        return $this;
    } // setWeight()

    /**
     * Set the value of [volume_number] column.
     *
     * @param  int $v new value
     * @return Item The current object (for fluent API support)
     */
    public function setVolumeNumber($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->volume_number !== $v) {
            $this->volume_number = $v;
            $this->modifiedColumns[] = ItemPeer::VOLUME_NUMBER;
        }


        return $this;
    } // setVolumeNumber()

    /**
     * Set the value of [volume_text] column.
     *
     * @param  string $v new value
     * @return Item The current object (for fluent API support)
     */
    public function setVolumeText($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->volume_text !== $v) {
            $this->volume_text = $v;
            $this->modifiedColumns[] = ItemPeer::VOLUME_TEXT;
        }


        return $this;
    } // setVolumeText()

    /**
     * Set the value of [mediapackage_size] column.
     *
     * @param  int $v new value
     * @return Item The current object (for fluent API support)
     */
    public function setMediapackageSize($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->mediapackage_size !== $v) {
            $this->mediapackage_size = $v;
            $this->modifiedColumns[] = ItemPeer::MEDIAPACKAGE_SIZE;
        }


        return $this;
    } // setMediapackageSize()

    /**
     * Set the value of [current_loan_id] column.
     *
     * @param  int $v new value
     * @return Item The current object (for fluent API support)
     */
    public function setCurrentLoanId($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->current_loan_id !== $v) {
            $this->current_loan_id = $v;
            $this->modifiedColumns[] = ItemPeer::CURRENT_LOAN_ID;
        }

        if ($this->aLoanRelatedByCurrentLoanId !== null && $this->aLoanRelatedByCurrentLoanId->getLoanId() !== $v) {
            $this->aLoanRelatedByCurrentLoanId = null;
        }


        return $this;
    } // setCurrentLoanId()

    /**
     * Set the value of [loan_class] column.
     *
     * @param  string $v new value
     * @return Item The current object (for fluent API support)
     */
    public function setLoanClass($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->loan_class !== $v) {
            $this->loan_class = $v;
            $this->modifiedColumns[] = ItemPeer::LOAN_CLASS;
        }


        return $this;
    } // setLoanClass()

    /**
     * Sets the value of [last_seen] column to a normalized version of the date/time value specified.
     *
     * @param mixed $v string, integer (timestamp), or DateTime value.
     *               Empty strings are treated as null.
     * @return Item The current object (for fluent API support)
     */
    public function setLastSeen($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->last_seen !== null || $dt !== null) {
            $currentDateAsString = ($this->last_seen !== null && $tmpDt = new DateTime($this->last_seen)) ? $tmpDt->format('Y-m-d') : null;
            $newDateAsString = $dt ? $dt->format('Y-m-d') : null;
            if ($currentDateAsString !== $newDateAsString) {
                $this->last_seen = $newDateAsString;
                $this->modifiedColumns[] = ItemPeer::LAST_SEEN;
            }
        } // if either are not null


        return $this;
    } // setLastSeen()

    /**
     * Set the value of [loan_status] column.
     *
     * @param  string $v new value
     * @return Item The current object (for fluent API support)
     */
    public function setLoanStatus($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->loan_status !== $v) {
            $this->loan_status = $v;
            $this->modifiedColumns[] = ItemPeer::LOAN_STATUS;
        }


        return $this;
    } // setLoanStatus()

    /**
     * Set the value of [loan_alert] column.
     *
     * @param  string $v new value
     * @return Item The current object (for fluent API support)
     */
    public function setLoanAlert($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->loan_alert !== $v) {
            $this->loan_alert = $v;
            $this->modifiedColumns[] = ItemPeer::LOAN_ALERT;
        }


        return $this;
    } // setLoanAlert()

    /**
     * Set the value of [loan_alert_note] column.
     *
     * @param  string $v new value
     * @return Item The current object (for fluent API support)
     */
    public function setLoanAlertNote($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->loan_alert_note !== $v) {
            $this->loan_alert_note = $v;
            $this->modifiedColumns[] = ItemPeer::LOAN_ALERT_NOTE;
        }


        return $this;
    } // setLoanAlertNote()

    /**
     * Set the value of [usage_count] column.
     *
     * @param  int $v new value
     * @return Item The current object (for fluent API support)
     */
    public function setUsageCount($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->usage_count !== $v) {
            $this->usage_count = $v;
            $this->modifiedColumns[] = ItemPeer::USAGE_COUNT;
        }


        return $this;
    } // setUsageCount()

    /**
     * Set the value of [delivery_library_id] column.
     *
     * @param  int $v new value
     * @return Item The current object (for fluent API support)
     */
    public function setDeliveryLibraryId($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->delivery_library_id !== $v) {
            $this->delivery_library_id = $v;
            $this->modifiedColumns[] = ItemPeer::DELIVERY_LIBRARY_ID;
        }

        if ($this->aLibraryRelatedByDeliveryLibraryId !== null && $this->aLibraryRelatedByDeliveryLibraryId->getLibraryId() !== $v) {
            $this->aLibraryRelatedByDeliveryLibraryId = null;
        }


        return $this;
    } // setDeliveryLibraryId()

    /**
     * Sets the value of [due_date] column to a normalized version of the date/time value specified.
     *
     * @param mixed $v string, integer (timestamp), or DateTime value.
     *               Empty strings are treated as null.
     * @return Item The current object (for fluent API support)
     */
    public function setDueDate($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->due_date !== null || $dt !== null) {
            $currentDateAsString = ($this->due_date !== null && $tmpDt = new DateTime($this->due_date)) ? $tmpDt->format('Y-m-d') : null;
            $newDateAsString = $dt ? $dt->format('Y-m-d') : null;
            if ($currentDateAsString !== $newDateAsString) {
                $this->due_date = $newDateAsString;
                $this->modifiedColumns[] = ItemPeer::DUE_DATE;
            }
        } // if either are not null


        return $this;
    } // setDueDate()

    /**
     * Set the value of [patron_id] column.
     *
     * @param  int $v new value
     * @return Item The current object (for fluent API support)
     */
    public function setPatronId($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->patron_id !== $v) {
            $this->patron_id = $v;
            $this->modifiedColumns[] = ItemPeer::PATRON_ID;
        }

        if ($this->aPatron !== null && $this->aPatron->getPatronId() !== $v) {
            $this->aPatron = null;
        }


        return $this;
    } // setPatronId()

    /**
     * Set the value of [external_library_id] column.
     *
     * @param  int $v new value
     * @return Item The current object (for fluent API support)
     */
    public function setExternalLibraryId($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->external_library_id !== $v) {
            $this->external_library_id = $v;
            $this->modifiedColumns[] = ItemPeer::EXTERNAL_LIBRARY_ID;
        }

        if ($this->aLibraryRelatedByExternalLibraryId !== null && $this->aLibraryRelatedByExternalLibraryId->getLibraryId() !== $v) {
            $this->aLibraryRelatedByExternalLibraryId = null;
        }


        return $this;
    } // setExternalLibraryId()

    /**
     * Set the value of [renewal_count] column.
     *
     * @param  int $v new value
     * @return Item The current object (for fluent API support)
     */
    public function setRenewalCount($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->renewal_count !== $v) {
            $this->renewal_count = $v;
            $this->modifiedColumns[] = ItemPeer::RENEWAL_COUNT;
        }


        return $this;
    } // setRenewalCount()

    /**
     * Set the value of [notify_count] column.
     *
     * @param  int $v new value
     * @return Item The current object (for fluent API support)
     */
    public function setNotifyCount($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->notify_count !== $v) {
            $this->notify_count = $v;
            $this->modifiedColumns[] = ItemPeer::NOTIFY_COUNT;
        }


        return $this;
    } // setNotifyCount()

    /**
     * Sets the value of [check_out] column to a normalized version of the date/time value specified.
     *
     * @param mixed $v string, integer (timestamp), or DateTime value.
     *               Empty strings are treated as null.
     * @return Item The current object (for fluent API support)
     */
    public function setCheckOut($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->check_out !== null || $dt !== null) {
            $currentDateAsString = ($this->check_out !== null && $tmpDt = new DateTime($this->check_out)) ? $tmpDt->format('Y-m-d H:i:s') : null;
            $newDateAsString = $dt ? $dt->format('Y-m-d H:i:s') : null;
            if ($currentDateAsString !== $newDateAsString) {
                $this->check_out = $newDateAsString;
                $this->modifiedColumns[] = ItemPeer::CHECK_OUT;
            }
        } // if either are not null


        return $this;
    } // setCheckOut()

    /**
     * Sets the value of [check_in] column to a normalized version of the date/time value specified.
     *
     * @param mixed $v string, integer (timestamp), or DateTime value.
     *               Empty strings are treated as null.
     * @return Item The current object (for fluent API support)
     */
    public function setCheckIn($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->check_in !== null || $dt !== null) {
            $currentDateAsString = ($this->check_in !== null && $tmpDt = new DateTime($this->check_in)) ? $tmpDt->format('Y-m-d H:i:s') : null;
            $newDateAsString = $dt ? $dt->format('Y-m-d H:i:s') : null;
            if ($currentDateAsString !== $newDateAsString) {
                $this->check_in = $newDateAsString;
                $this->modifiedColumns[] = ItemPeer::CHECK_IN;
            }
        } // if either are not null


        return $this;
    } // setCheckIn()

    /**
     * Sets the value of [ill_timestamp] column to a normalized version of the date/time value specified.
     *
     * @param mixed $v string, integer (timestamp), or DateTime value.
     *               Empty strings are treated as null.
     * @return Item The current object (for fluent API support)
     */
    public function setIllTimestamp($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->ill_timestamp !== null || $dt !== null) {
            $currentDateAsString = ($this->ill_timestamp !== null && $tmpDt = new DateTime($this->ill_timestamp)) ? $tmpDt->format('Y-m-d H:i:s') : null;
            $newDateAsString = $dt ? $dt->format('Y-m-d H:i:s') : null;
            if ($currentDateAsString !== $newDateAsString) {
                $this->ill_timestamp = $newDateAsString;
                $this->modifiedColumns[] = ItemPeer::ILL_TIMESTAMP;
            }
        } // if either are not null


        return $this;
    } // setIllTimestamp()

    /**
     * Set the value of [supplier_id] column.
     *
     * @param  int $v new value
     * @return Item The current object (for fluent API support)
     */
    public function setSupplierId($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->supplier_id !== $v) {
            $this->supplier_id = $v;
            $this->modifiedColumns[] = ItemPeer::SUPPLIER_ID;
        }

        if ($this->aSupplier !== null && $this->aSupplier->getSupplierId() !== $v) {
            $this->aSupplier = null;
        }


        return $this;
    } // setSupplierId()

    /**
     * Set the value of [invoice_id] column.
     *
     * @param  int $v new value
     * @return Item The current object (for fluent API support)
     */
    public function setInvoiceId($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->invoice_id !== $v) {
            $this->invoice_id = $v;
            $this->modifiedColumns[] = ItemPeer::INVOICE_ID;
        }

        if ($this->aInvoice !== null && $this->aInvoice->getInvoiceId() !== $v) {
            $this->aInvoice = null;
        }


        return $this;
    } // setInvoiceId()

    /**
     * Set the value of [order_id] column.
     *
     * @param  int $v new value
     * @return Item The current object (for fluent API support)
     */
    public function setOrderId($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->order_id !== $v) {
            $this->order_id = $v;
            $this->modifiedColumns[] = ItemPeer::ORDER_ID;
        }

        if ($this->aPurchaseOrder !== null && $this->aPurchaseOrder->getOrderId() !== $v) {
            $this->aPurchaseOrder = null;
        }


        return $this;
    } // setOrderId()

    /**
     * Set the value of [budget_id] column.
     *
     * @param  int $v new value
     * @return Item The current object (for fluent API support)
     */
    public function setBudgetId($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->budget_id !== $v) {
            $this->budget_id = $v;
            $this->modifiedColumns[] = ItemPeer::BUDGET_ID;
        }

        if ($this->aBudget !== null && $this->aBudget->getBudgetId() !== $v) {
            $this->aBudget = null;
        }


        return $this;
    } // setBudgetId()

    /**
     * Set the value of [currency] column.
     *
     * @param  string $v new value
     * @return Item The current object (for fluent API support)
     */
    public function setCurrency($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->currency !== $v) {
            $this->currency = $v;
            $this->modifiedColumns[] = ItemPeer::CURRENCY;
        }


        return $this;
    } // setCurrency()

    /**
     * Set the value of [currency_value] column.
     *
     * @param  string $v new value
     * @return Item The current object (for fluent API support)
     */
    public function setCurrencyValue($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->currency_value !== $v) {
            $this->currency_value = $v;
            $this->modifiedColumns[] = ItemPeer::CURRENCY_VALUE;
        }


        return $this;
    } // setCurrencyValue()

    /**
     * Set the value of [discount_value] column.
     *
     * @param  string $v new value
     * @return Item The current object (for fluent API support)
     */
    public function setDiscountValue($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->discount_value !== $v) {
            $this->discount_value = $v;
            $this->modifiedColumns[] = ItemPeer::DISCOUNT_VALUE;
        }


        return $this;
    } // setDiscountValue()

    /**
     * Set the value of [inventory_value] column.
     *
     * @param  string $v new value
     * @return Item The current object (for fluent API support)
     */
    public function setInventoryValue($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->inventory_value !== $v) {
            $this->inventory_value = $v;
            $this->modifiedColumns[] = ItemPeer::INVENTORY_VALUE;
        }


        return $this;
    } // setInventoryValue()

    /**
     * Set the value of [issue_inventory_number] column.
     *
     * @param  int $v new value
     * @return Item The current object (for fluent API support)
     */
    public function setIssueInventoryNumber($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->issue_inventory_number !== $v) {
            $this->issue_inventory_number = $v;
            $this->modifiedColumns[] = ItemPeer::ISSUE_INVENTORY_NUMBER;
        }


        return $this;
    } // setIssueInventoryNumber()

    /**
     * Set the value of [issue_id] column.
     *
     * @param  int $v new value
     * @return Item The current object (for fluent API support)
     */
    public function setIssueId($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->issue_id !== $v) {
            $this->issue_id = $v;
            $this->modifiedColumns[] = ItemPeer::ISSUE_ID;
        }

        if ($this->aIssue !== null && $this->aIssue->getIssueId() !== $v) {
            $this->aIssue = null;
        }


        return $this;
    } // setIssueId()

    /**
     * Set the value of [issue_year] column.
     *
     * @param  string $v new value
     * @return Item The current object (for fluent API support)
     */
    public function setIssueYear($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->issue_year !== $v) {
            $this->issue_year = $v;
            $this->modifiedColumns[] = ItemPeer::ISSUE_YEAR;
        }


        return $this;
    } // setIssueYear()

    /**
     * Set the value of [issue_number] column.
     *
     * @param  int $v new value
     * @return Item The current object (for fluent API support)
     */
    public function setIssueNumber($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->issue_number !== $v) {
            $this->issue_number = $v;
            $this->modifiedColumns[] = ItemPeer::ISSUE_NUMBER;
        }


        return $this;
    } // setIssueNumber()

    /**
     * Set the value of [issue_description] column.
     *
     * @param  string $v new value
     * @return Item The current object (for fluent API support)
     */
    public function setIssueDescription($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->issue_description !== $v) {
            $this->issue_description = $v;
            $this->modifiedColumns[] = ItemPeer::ISSUE_DESCRIPTION;
        }


        return $this;
    } // setIssueDescription()

    /**
     * Sets the value of [issue_arrival_date] column to a normalized version of the date/time value specified.
     *
     * @param mixed $v string, integer (timestamp), or DateTime value.
     *               Empty strings are treated as null.
     * @return Item The current object (for fluent API support)
     */
    public function setIssueArrivalDate($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->issue_arrival_date !== null || $dt !== null) {
            $currentDateAsString = ($this->issue_arrival_date !== null && $tmpDt = new DateTime($this->issue_arrival_date)) ? $tmpDt->format('Y-m-d') : null;
            $newDateAsString = $dt ? $dt->format('Y-m-d') : null;
            if ($currentDateAsString !== $newDateAsString) {
                $this->issue_arrival_date = $newDateAsString;
                $this->modifiedColumns[] = ItemPeer::ISSUE_ARRIVAL_DATE;
            }
        } // if either are not null


        return $this;
    } // setIssueArrivalDate()

    /**
     * Sets the value of [issue_arrival_date_expected] column to a normalized version of the date/time value specified.
     *
     * @param mixed $v string, integer (timestamp), or DateTime value.
     *               Empty strings are treated as null.
     * @return Item The current object (for fluent API support)
     */
    public function setIssueArrivalDateExpected($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->issue_arrival_date_expected !== null || $dt !== null) {
            $currentDateAsString = ($this->issue_arrival_date_expected !== null && $tmpDt = new DateTime($this->issue_arrival_date_expected)) ? $tmpDt->format('Y-m-d') : null;
            $newDateAsString = $dt ? $dt->format('Y-m-d') : null;
            if ($currentDateAsString !== $newDateAsString) {
                $this->issue_arrival_date_expected = $newDateAsString;
                $this->modifiedColumns[] = ItemPeer::ISSUE_ARRIVAL_DATE_EXPECTED;
            }
        } // if either are not null


        return $this;
    } // setIssueArrivalDateExpected()

    /**
     * Set the value of [issue_status] column.
     *
     * @param  string $v new value
     * @return Item The current object (for fluent API support)
     */
    public function setIssueStatus($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->issue_status !== $v) {
            $this->issue_status = $v;
            $this->modifiedColumns[] = ItemPeer::ISSUE_STATUS;
        }


        return $this;
    } // setIssueStatus()

    /**
     * Set the value of [subscription_id] column.
     *
     * @param  int $v new value
     * @return Item The current object (for fluent API support)
     */
    public function setSubscriptionId($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->subscription_id !== $v) {
            $this->subscription_id = $v;
            $this->modifiedColumns[] = ItemPeer::SUBSCRIPTION_ID;
        }


        return $this;
    } // setSubscriptionId()

    /**
     * Set the value of [consistency_note_id] column.
     *
     * @param  int $v new value
     * @return Item The current object (for fluent API support)
     */
    public function setConsistencyNoteId($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->consistency_note_id !== $v) {
            $this->consistency_note_id = $v;
            $this->modifiedColumns[] = ItemPeer::CONSISTENCY_NOTE_ID;
        }

        if ($this->aConsistencyNote !== null && $this->aConsistencyNote->getConsistencyNoteId() !== $v) {
            $this->aConsistencyNote = null;
        }


        return $this;
    } // setConsistencyNoteId()

    /**
     * Set the value of [actual_library_id] column.
     *
     * @param  int $v new value
     * @return Item The current object (for fluent API support)
     */
    public function setActualLibraryId($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->actual_library_id !== $v) {
            $this->actual_library_id = $v;
            $this->modifiedColumns[] = ItemPeer::ACTUAL_LIBRARY_ID;
        }

        if ($this->aLibraryRelatedByActualLibraryId !== null && $this->aLibraryRelatedByActualLibraryId->getLibraryId() !== $v) {
            $this->aLibraryRelatedByActualLibraryId = null;
        }


        return $this;
    } // setActualLibraryId()

    /**
     * Set the value of [barcode] column.
     *
     * @param  string $v new value
     * @return Item The current object (for fluent API support)
     */
    public function setBarcode($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->barcode !== $v) {
            $this->barcode = $v;
            $this->modifiedColumns[] = ItemPeer::BARCODE;
        }


        return $this;
    } // setBarcode()

    /**
     * Set the value of [rfid_code] column.
     *
     * @param  string $v new value
     * @return Item The current object (for fluent API support)
     */
    public function setRfidCode($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->rfid_code !== $v) {
            $this->rfid_code = $v;
            $this->modifiedColumns[] = ItemPeer::RFID_CODE;
        }


        return $this;
    } // setRfidCode()

    /**
     * Set the value of [custom_field1] column.
     *
     * @param  string $v new value
     * @return Item The current object (for fluent API support)
     */
    public function setCustomField1($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->custom_field1 !== $v) {
            $this->custom_field1 = $v;
            $this->modifiedColumns[] = ItemPeer::CUSTOM_FIELD1;
        }


        return $this;
    } // setCustomField1()

    /**
     * Set the value of [custom_field2] column.
     *
     * @param  string $v new value
     * @return Item The current object (for fluent API support)
     */
    public function setCustomField2($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->custom_field2 !== $v) {
            $this->custom_field2 = $v;
            $this->modifiedColumns[] = ItemPeer::CUSTOM_FIELD2;
        }


        return $this;
    } // setCustomField2()

    /**
     * Set the value of [custom_field3] column.
     *
     * @param  string $v new value
     * @return Item The current object (for fluent API support)
     */
    public function setCustomField3($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->custom_field3 !== $v) {
            $this->custom_field3 = $v;
            $this->modifiedColumns[] = ItemPeer::CUSTOM_FIELD3;
        }


        return $this;
    } // setCustomField3()

    /**
     * Set the value of [unimarc] column.
     *
     * @param  string $v new value
     * @return Item The current object (for fluent API support)
     */
    public function setUnimarc($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->unimarc !== $v) {
            $this->unimarc = $v;
            $this->modifiedColumns[] = ItemPeer::UNIMARC;
        }


        return $this;
    } // setUnimarc()

    /**
     * Sets the value of [last_sbn_sync] column to a normalized version of the date/time value specified.
     *
     * @param mixed $v string, integer (timestamp), or DateTime value.
     *               Empty strings are treated as null.
     * @return Item The current object (for fluent API support)
     */
    public function setLastSbnSync($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->last_sbn_sync !== null || $dt !== null) {
            $currentDateAsString = ($this->last_sbn_sync !== null && $tmpDt = new DateTime($this->last_sbn_sync)) ? $tmpDt->format('Y-m-d H:i:s') : null;
            $newDateAsString = $dt ? $dt->format('Y-m-d H:i:s') : null;
            if ($currentDateAsString !== $newDateAsString) {
                $this->last_sbn_sync = $newDateAsString;
                $this->modifiedColumns[] = ItemPeer::LAST_SBN_SYNC;
            }
        } // if either are not null


        return $this;
    } // setLastSbnSync()

    /**
     * Sets the value of [date_discarded] column to a normalized version of the date/time value specified.
     *
     * @param mixed $v string, integer (timestamp), or DateTime value.
     *               Empty strings are treated as null.
     * @return Item The current object (for fluent API support)
     */
    public function setDateDiscarded($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->date_discarded !== null || $dt !== null) {
            $currentDateAsString = ($this->date_discarded !== null && $tmpDt = new DateTime($this->date_discarded)) ? $tmpDt->format('Y-m-d H:i:s') : null;
            $newDateAsString = $dt ? $dt->format('Y-m-d H:i:s') : null;
            if ($currentDateAsString !== $newDateAsString) {
                $this->date_discarded = $newDateAsString;
                $this->modifiedColumns[] = ItemPeer::DATE_DISCARDED;
            }
        } // if either are not null


        return $this;
    } // setDateDiscarded()

    /**
     * Set the value of [discard_note] column.
     *
     * @param  string $v new value
     * @return Item The current object (for fluent API support)
     */
    public function setDiscardNote($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->discard_note !== $v) {
            $this->discard_note = $v;
            $this->modifiedColumns[] = ItemPeer::DISCARD_NOTE;
        }


        return $this;
    } // setDiscardNote()

    /**
     * Sets the value of [date_created] column to a normalized version of the date/time value specified.
     *
     * @param mixed $v string, integer (timestamp), or DateTime value.
     *               Empty strings are treated as null.
     * @return Item The current object (for fluent API support)
     */
    public function setDateCreated($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->date_created !== null || $dt !== null) {
            $currentDateAsString = ($this->date_created !== null && $tmpDt = new DateTime($this->date_created)) ? $tmpDt->format('Y-m-d H:i:s') : null;
            $newDateAsString = $dt ? $dt->format('Y-m-d H:i:s') : null;
            if ($currentDateAsString !== $newDateAsString) {
                $this->date_created = $newDateAsString;
                $this->modifiedColumns[] = ItemPeer::DATE_CREATED;
            }
        } // if either are not null


        return $this;
    } // setDateCreated()

    /**
     * Sets the value of [date_updated] column to a normalized version of the date/time value specified.
     *
     * @param mixed $v string, integer (timestamp), or DateTime value.
     *               Empty strings are treated as null.
     * @return Item The current object (for fluent API support)
     */
    public function setDateUpdated($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->date_updated !== null || $dt !== null) {
            $currentDateAsString = ($this->date_updated !== null && $tmpDt = new DateTime($this->date_updated)) ? $tmpDt->format('Y-m-d H:i:s') : null;
            $newDateAsString = $dt ? $dt->format('Y-m-d H:i:s') : null;
            if ($currentDateAsString !== $newDateAsString) {
                $this->date_updated = $newDateAsString;
                $this->modifiedColumns[] = ItemPeer::DATE_UPDATED;
            }
        } // if either are not null


        return $this;
    } // setDateUpdated()

    /**
     * Set the value of [created_by] column.
     *
     * @param  int $v new value
     * @return Item The current object (for fluent API support)
     */
    public function setCreatedBy($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->created_by !== $v) {
            $this->created_by = $v;
            $this->modifiedColumns[] = ItemPeer::CREATED_BY;
        }

        if ($this->aLibrarianRelatedByCreatedBy !== null && $this->aLibrarianRelatedByCreatedBy->getLibrarianId() !== $v) {
            $this->aLibrarianRelatedByCreatedBy = null;
        }


        return $this;
    } // setCreatedBy()

    /**
     * Set the value of [modified_by] column.
     *
     * @param  int $v new value
     * @return Item The current object (for fluent API support)
     */
    public function setModifiedBy($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->modified_by !== $v) {
            $this->modified_by = $v;
            $this->modifiedColumns[] = ItemPeer::MODIFIED_BY;
        }

        if ($this->aLibrarianRelatedByModifiedBy !== null && $this->aLibrarianRelatedByModifiedBy->getLibrarianId() !== $v) {
            $this->aLibrarianRelatedByModifiedBy = null;
        }


        return $this;
    } // setModifiedBy()

    /**
     * Indicates whether the columns in this object are only set to default values.
     *
     * This method can be used in conjunction with isModified() to indicate whether an object is both
     * modified _and_ has some values set which are non-default.
     *
     * @return boolean Whether the columns in this object are only been set with default values.
     */
    public function hasOnlyDefaultValues()
    {
            if ($this->mediapackage_size !== 1) {
                return false;
            }

            if ($this->usage_count !== 0) {
                return false;
            }

            if ($this->notify_count !== 0) {
                return false;
            }

        // otherwise, everything was equal, so return true
        return true;
    } // hasOnlyDefaultValues()

    /**
     * Hydrates (populates) the object variables with values from the database resultset.
     *
     * An offset (0-based "start column") is specified so that objects can be hydrated
     * with a subset of the columns in the resultset rows.  This is needed, for example,
     * for results of JOIN queries where the resultset row includes columns from two or
     * more tables.
     *
     * @param array $row The row returned by PDOStatement->fetch(PDO::FETCH_NUM)
     * @param int $startcol 0-based offset column which indicates which resultset column to start with.
     * @param boolean $rehydrate Whether this object is being re-hydrated from the database.
     * @return int             next starting column
     * @throws PropelException - Any caught Exception will be rewrapped as a PropelException.
     */
    public function hydrate($row, $startcol = 0, $rehydrate = false)
    {
        try {

            $this->item_id = ($row[$startcol + 0] !== null) ? (int) $row[$startcol + 0] : null;
            $this->title = ($row[$startcol + 1] !== null) ? (string) $row[$startcol + 1] : null;
            $this->manifestation_id = ($row[$startcol + 2] !== null) ? (int) $row[$startcol + 2] : null;
            $this->manifestation_dewey = ($row[$startcol + 3] !== null) ? (string) $row[$startcol + 3] : null;
            $this->item_media = ($row[$startcol + 4] !== null) ? (string) $row[$startcol + 4] : null;
            $this->item_status = ($row[$startcol + 5] !== null) ? (string) $row[$startcol + 5] : null;
            $this->item_order_status = ($row[$startcol + 6] !== null) ? (string) $row[$startcol + 6] : null;
            $this->item_icon = ($row[$startcol + 7] !== null) ? (string) $row[$startcol + 7] : null;
            $this->physical_status = ($row[$startcol + 8] !== null) ? (string) $row[$startcol + 8] : null;
            $this->item_source = ($row[$startcol + 9] !== null) ? (string) $row[$startcol + 9] : null;
            $this->opac_visible = ($row[$startcol + 10] !== null) ? (boolean) $row[$startcol + 10] : null;
            $this->inventory_serie_id = ($row[$startcol + 11] !== null) ? (string) $row[$startcol + 11] : null;
            $this->inventory_number = ($row[$startcol + 12] !== null) ? (int) $row[$startcol + 12] : null;
            $this->inventory_date = ($row[$startcol + 13] !== null) ? (string) $row[$startcol + 13] : null;
            $this->owner_library_id = ($row[$startcol + 14] !== null) ? (int) $row[$startcol + 14] : null;
            $this->home_library_id = ($row[$startcol + 15] !== null) ? (int) $row[$startcol + 15] : null;
            $this->collocation = ($row[$startcol + 16] !== null) ? (string) $row[$startcol + 16] : null;
            $this->section = ($row[$startcol + 17] !== null) ? (string) $row[$startcol + 17] : null;
            $this->sequence1 = ($row[$startcol + 18] !== null) ? (string) $row[$startcol + 18] : null;
            $this->sequence2 = ($row[$startcol + 19] !== null) ? (string) $row[$startcol + 19] : null;
            $this->specification = ($row[$startcol + 20] !== null) ? (string) $row[$startcol + 20] : null;
            $this->reprint = ($row[$startcol + 21] !== null) ? (string) $row[$startcol + 21] : null;
            $this->width = ($row[$startcol + 22] !== null) ? (int) $row[$startcol + 22] : null;
            $this->height = ($row[$startcol + 23] !== null) ? (int) $row[$startcol + 23] : null;
            $this->weight = ($row[$startcol + 24] !== null) ? (string) $row[$startcol + 24] : null;
            $this->volume_number = ($row[$startcol + 25] !== null) ? (int) $row[$startcol + 25] : null;
            $this->volume_text = ($row[$startcol + 26] !== null) ? (string) $row[$startcol + 26] : null;
            $this->mediapackage_size = ($row[$startcol + 27] !== null) ? (int) $row[$startcol + 27] : null;
            $this->current_loan_id = ($row[$startcol + 28] !== null) ? (int) $row[$startcol + 28] : null;
            $this->loan_class = ($row[$startcol + 29] !== null) ? (string) $row[$startcol + 29] : null;
            $this->last_seen = ($row[$startcol + 30] !== null) ? (string) $row[$startcol + 30] : null;
            $this->loan_status = ($row[$startcol + 31] !== null) ? (string) $row[$startcol + 31] : null;
            $this->loan_alert = ($row[$startcol + 32] !== null) ? (string) $row[$startcol + 32] : null;
            $this->loan_alert_note = ($row[$startcol + 33] !== null) ? (string) $row[$startcol + 33] : null;
            $this->usage_count = ($row[$startcol + 34] !== null) ? (int) $row[$startcol + 34] : null;
            $this->delivery_library_id = ($row[$startcol + 35] !== null) ? (int) $row[$startcol + 35] : null;
            $this->due_date = ($row[$startcol + 36] !== null) ? (string) $row[$startcol + 36] : null;
            $this->patron_id = ($row[$startcol + 37] !== null) ? (int) $row[$startcol + 37] : null;
            $this->external_library_id = ($row[$startcol + 38] !== null) ? (int) $row[$startcol + 38] : null;
            $this->renewal_count = ($row[$startcol + 39] !== null) ? (int) $row[$startcol + 39] : null;
            $this->notify_count = ($row[$startcol + 40] !== null) ? (int) $row[$startcol + 40] : null;
            $this->check_out = ($row[$startcol + 41] !== null) ? (string) $row[$startcol + 41] : null;
            $this->check_in = ($row[$startcol + 42] !== null) ? (string) $row[$startcol + 42] : null;
            $this->ill_timestamp = ($row[$startcol + 43] !== null) ? (string) $row[$startcol + 43] : null;
            $this->supplier_id = ($row[$startcol + 44] !== null) ? (int) $row[$startcol + 44] : null;
            $this->invoice_id = ($row[$startcol + 45] !== null) ? (int) $row[$startcol + 45] : null;
            $this->order_id = ($row[$startcol + 46] !== null) ? (int) $row[$startcol + 46] : null;
            $this->budget_id = ($row[$startcol + 47] !== null) ? (int) $row[$startcol + 47] : null;
            $this->currency = ($row[$startcol + 48] !== null) ? (string) $row[$startcol + 48] : null;
            $this->currency_value = ($row[$startcol + 49] !== null) ? (string) $row[$startcol + 49] : null;
            $this->discount_value = ($row[$startcol + 50] !== null) ? (string) $row[$startcol + 50] : null;
            $this->inventory_value = ($row[$startcol + 51] !== null) ? (string) $row[$startcol + 51] : null;
            $this->issue_inventory_number = ($row[$startcol + 52] !== null) ? (int) $row[$startcol + 52] : null;
            $this->issue_id = ($row[$startcol + 53] !== null) ? (int) $row[$startcol + 53] : null;
            $this->issue_year = ($row[$startcol + 54] !== null) ? (string) $row[$startcol + 54] : null;
            $this->issue_number = ($row[$startcol + 55] !== null) ? (int) $row[$startcol + 55] : null;
            $this->issue_description = ($row[$startcol + 56] !== null) ? (string) $row[$startcol + 56] : null;
            $this->issue_arrival_date = ($row[$startcol + 57] !== null) ? (string) $row[$startcol + 57] : null;
            $this->issue_arrival_date_expected = ($row[$startcol + 58] !== null) ? (string) $row[$startcol + 58] : null;
            $this->issue_status = ($row[$startcol + 59] !== null) ? (string) $row[$startcol + 59] : null;
            $this->subscription_id = ($row[$startcol + 60] !== null) ? (int) $row[$startcol + 60] : null;
            $this->consistency_note_id = ($row[$startcol + 61] !== null) ? (int) $row[$startcol + 61] : null;
            $this->actual_library_id = ($row[$startcol + 62] !== null) ? (int) $row[$startcol + 62] : null;
            $this->barcode = ($row[$startcol + 63] !== null) ? (string) $row[$startcol + 63] : null;
            $this->rfid_code = ($row[$startcol + 64] !== null) ? (string) $row[$startcol + 64] : null;
            $this->custom_field1 = ($row[$startcol + 65] !== null) ? (string) $row[$startcol + 65] : null;
            $this->custom_field2 = ($row[$startcol + 66] !== null) ? (string) $row[$startcol + 66] : null;
            $this->custom_field3 = ($row[$startcol + 67] !== null) ? (string) $row[$startcol + 67] : null;
            $this->unimarc = ($row[$startcol + 68] !== null) ? (string) $row[$startcol + 68] : null;
            $this->last_sbn_sync = ($row[$startcol + 69] !== null) ? (string) $row[$startcol + 69] : null;
            $this->date_discarded = ($row[$startcol + 70] !== null) ? (string) $row[$startcol + 70] : null;
            $this->discard_note = ($row[$startcol + 71] !== null) ? (string) $row[$startcol + 71] : null;
            $this->date_created = ($row[$startcol + 72] !== null) ? (string) $row[$startcol + 72] : null;
            $this->date_updated = ($row[$startcol + 73] !== null) ? (string) $row[$startcol + 73] : null;
            $this->created_by = ($row[$startcol + 74] !== null) ? (int) $row[$startcol + 74] : null;
            $this->modified_by = ($row[$startcol + 75] !== null) ? (int) $row[$startcol + 75] : null;
            $this->resetModified();

            $this->setNew(false);

            if ($rehydrate) {
                $this->ensureConsistency();
            }
            $this->postHydrate($row, $startcol, $rehydrate);

            return $startcol + 76; // 76 = ItemPeer::NUM_HYDRATE_COLUMNS.

        } catch (Exception $e) {
            throw new PropelException("Error populating Item object", $e);
        }
    }

    /**
     * Checks and repairs the internal consistency of the object.
     *
     * This method is executed after an already-instantiated object is re-hydrated
     * from the database.  It exists to check any foreign keys to make sure that
     * the objects related to the current object are correct based on foreign key.
     *
     * You can override this method in the stub class, but you should always invoke
     * the base method from the overridden method (i.e. parent::ensureConsistency()),
     * in case your model changes.
     *
     * @throws PropelException
     */
    public function ensureConsistency()
    {

        if ($this->aManifestation !== null && $this->manifestation_id !== $this->aManifestation->getManifestationId()) {
            $this->aManifestation = null;
        }
        if ($this->aInventorySerie !== null && $this->inventory_serie_id !== $this->aInventorySerie->getInventorySerieId()) {
            $this->aInventorySerie = null;
        }
        if ($this->aLibraryRelatedByOwnerLibraryId !== null && $this->owner_library_id !== $this->aLibraryRelatedByOwnerLibraryId->getLibraryId()) {
            $this->aLibraryRelatedByOwnerLibraryId = null;
        }
        if ($this->aLibraryRelatedByHomeLibraryId !== null && $this->home_library_id !== $this->aLibraryRelatedByHomeLibraryId->getLibraryId()) {
            $this->aLibraryRelatedByHomeLibraryId = null;
        }
        if ($this->aLoanRelatedByCurrentLoanId !== null && $this->current_loan_id !== $this->aLoanRelatedByCurrentLoanId->getLoanId()) {
            $this->aLoanRelatedByCurrentLoanId = null;
        }
        if ($this->aLibraryRelatedByDeliveryLibraryId !== null && $this->delivery_library_id !== $this->aLibraryRelatedByDeliveryLibraryId->getLibraryId()) {
            $this->aLibraryRelatedByDeliveryLibraryId = null;
        }
        if ($this->aPatron !== null && $this->patron_id !== $this->aPatron->getPatronId()) {
            $this->aPatron = null;
        }
        if ($this->aLibraryRelatedByExternalLibraryId !== null && $this->external_library_id !== $this->aLibraryRelatedByExternalLibraryId->getLibraryId()) {
            $this->aLibraryRelatedByExternalLibraryId = null;
        }
        if ($this->aSupplier !== null && $this->supplier_id !== $this->aSupplier->getSupplierId()) {
            $this->aSupplier = null;
        }
        if ($this->aInvoice !== null && $this->invoice_id !== $this->aInvoice->getInvoiceId()) {
            $this->aInvoice = null;
        }
        if ($this->aPurchaseOrder !== null && $this->order_id !== $this->aPurchaseOrder->getOrderId()) {
            $this->aPurchaseOrder = null;
        }
        if ($this->aBudget !== null && $this->budget_id !== $this->aBudget->getBudgetId()) {
            $this->aBudget = null;
        }
        if ($this->aIssue !== null && $this->issue_id !== $this->aIssue->getIssueId()) {
            $this->aIssue = null;
        }
        if ($this->aConsistencyNote !== null && $this->consistency_note_id !== $this->aConsistencyNote->getConsistencyNoteId()) {
            $this->aConsistencyNote = null;
        }
        if ($this->aLibraryRelatedByActualLibraryId !== null && $this->actual_library_id !== $this->aLibraryRelatedByActualLibraryId->getLibraryId()) {
            $this->aLibraryRelatedByActualLibraryId = null;
        }
        if ($this->aLibrarianRelatedByCreatedBy !== null && $this->created_by !== $this->aLibrarianRelatedByCreatedBy->getLibrarianId()) {
            $this->aLibrarianRelatedByCreatedBy = null;
        }
        if ($this->aLibrarianRelatedByModifiedBy !== null && $this->modified_by !== $this->aLibrarianRelatedByModifiedBy->getLibrarianId()) {
            $this->aLibrarianRelatedByModifiedBy = null;
        }
    } // ensureConsistency

    /**
     * Reloads this object from datastore based on primary key and (optionally) resets all associated objects.
     *
     * This will only work if the object has been saved and has a valid primary key set.
     *
     * @param boolean $deep (optional) Whether to also de-associated any related objects.
     * @param PropelPDO $con (optional) The PropelPDO connection to use.
     * @return void
     * @throws PropelException - if this object is deleted, unsaved or doesn't have pk match in db
     */
    public function reload($deep = false, PropelPDO $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("Cannot reload a deleted object.");
        }

        if ($this->isNew()) {
            throw new PropelException("Cannot reload an unsaved object.");
        }

        if ($con === null) {
            $con = Propel::getConnection(ItemPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        // We don't need to alter the object instance pool; we're just modifying this instance
        // already in the pool.

        $stmt = ItemPeer::doSelectStmt($this->buildPkeyCriteria(), $con);
        $row = $stmt->fetch(PDO::FETCH_NUM);
        $stmt->closeCursor();
        if (!$row) {
            throw new PropelException('Cannot find matching row in the database to reload object values.');
        }
        $this->hydrate($row, 0, true); // rehydrate

        if ($deep) {  // also de-associate any related objects?

            $this->aLibrarianRelatedByCreatedBy = null;
            $this->aLibrarianRelatedByModifiedBy = null;
            $this->aIssue = null;
            $this->aManifestation = null;
            $this->aConsistencyNote = null;
            $this->aLibraryRelatedByOwnerLibraryId = null;
            $this->aLibraryRelatedByHomeLibraryId = null;
            $this->aLibraryRelatedByDeliveryLibraryId = null;
            $this->aLibraryRelatedByActualLibraryId = null;
            $this->aInventorySerie = null;
            $this->aPurchaseOrder = null;
            $this->aInvoice = null;
            $this->aSupplier = null;
            $this->aPatron = null;
            $this->aLibraryRelatedByExternalLibraryId = null;
            $this->aLoanRelatedByCurrentLoanId = null;
            $this->aBudget = null;
            $this->collItemActions = null;

            $this->collItemNotes = null;

            $this->collItemRequests = null;

            $this->collLoansRelatedByItemId = null;

            $this->collLAuthorityItems = null;

            $this->collPurchaseProposals = null;

        } // if (deep)
    }

    /**
     * Removes this object from datastore and sets delete attribute.
     *
     * @param PropelPDO $con
     * @return void
     * @throws PropelException
     * @throws Exception
     * @see        BaseObject::setDeleted()
     * @see        BaseObject::isDeleted()
     */
    public function delete(PropelPDO $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("This object has already been deleted.");
        }

        if ($con === null) {
            $con = Propel::getConnection(ItemPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        $con->beginTransaction();
        try {
            $deleteQuery = ItemQuery::create()
                ->filterByPrimaryKey($this->getPrimaryKey());
            $ret = $this->preDelete($con);
            if ($ret) {
                $deleteQuery->delete($con);
                $this->postDelete($con);
                $con->commit();
                $this->setDeleted(true);
            } else {
                $con->commit();
            }
        } catch (Exception $e) {
            $con->rollBack();
            throw $e;
        }
    }

    /**
     * Persists this object to the database.
     *
     * If the object is new, it inserts it; otherwise an update is performed.
     * All modified related objects will also be persisted in the doSave()
     * method.  This method wraps all precipitate database operations in a
     * single transaction.
     *
     * @param PropelPDO $con
     * @return int             The number of rows affected by this insert/update and any referring fk objects' save() operations.
     * @throws PropelException
     * @throws Exception
     * @see        doSave()
     */
    public function save(PropelPDO $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("You cannot save an object that has been deleted.");
        }

        if ($con === null) {
            $con = Propel::getConnection(ItemPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        $con->beginTransaction();
        $isInsert = $this->isNew();
        try {
            $ret = $this->preSave($con);
            if ($isInsert) {
                $ret = $ret && $this->preInsert($con);
                // timestampable behavior
                if (!$this->isColumnModified(ItemPeer::DATE_CREATED)) {
                    $this->setDateCreated(time());
                }
                if (!$this->isColumnModified(ItemPeer::DATE_UPDATED)) {
                    $this->setDateUpdated(time());
                }
                // librariantrace behavior
                $librarianId = (class_exists('Prado') && (Prado::getApplication() instanceof TApplication) && ($u = Prado::getApplication()->getUser()) instanceof ClavisLibrarian && $u->getId() > 0) ? $u->getId() : 1 ;
                if (!$this->isColumnModified(ItemPeer::CREATED_BY)) {
                    $this->setCreatedBy($librarianId);
                }
                if (!$this->isColumnModified(ItemPeer::MODIFIED_BY)) {
                    $this->setModifiedBy($librarianId);
                }
            } else {
                $ret = $ret && $this->preUpdate($con);
                // timestampable behavior
                if ($this->isModified() && !$this->isColumnModified(ItemPeer::DATE_UPDATED)) {
                    $this->setDateUpdated(time());
                }
                // librariantrace behavior
                if ($this->isModified() && !$this->isColumnModified(ItemPeer::MODIFIED_BY)) {
                    $this->setModifiedBy((class_exists('Prado') && (Prado::getApplication() instanceof TApplication) && ($u = Prado::getApplication()->getUser()) instanceof ClavisLibrarian && $u->getId() > 0) ? $u->getId() : 1 );
                }
            }
            if ($ret) {
                $affectedRows = $this->doSave($con);
                if ($isInsert) {
                    $this->postInsert($con);
                } else {
                    $this->postUpdate($con);
                }
                $this->postSave($con);
                ItemPeer::addInstanceToPool($this);
            } else {
                $affectedRows = 0;
            }
            $con->commit();

            return $affectedRows;
        } catch (Exception $e) {
            $con->rollBack();
            throw $e;
        }
    }

    /**
     * Performs the work of inserting or updating the row in the database.
     *
     * If the object is new, it inserts it; otherwise an update is performed.
     * All related objects are also updated in this method.
     *
     * @param PropelPDO $con
     * @return int             The number of rows affected by this insert/update and any referring fk objects' save() operations.
     * @throws PropelException
     * @see        save()
     */
    protected function doSave(PropelPDO $con)
    {
        $affectedRows = 0; // initialize var to track total num of affected rows
        if (!$this->alreadyInSave) {
            $this->alreadyInSave = true;

            // We call the save method on the following object(s) if they
            // were passed to this object by their corresponding set
            // method.  This object relates to these object(s) by a
            // foreign key reference.

            if ($this->aLibrarianRelatedByCreatedBy !== null) {
                if ($this->aLibrarianRelatedByCreatedBy->isModified() || $this->aLibrarianRelatedByCreatedBy->isNew()) {
                    $affectedRows += $this->aLibrarianRelatedByCreatedBy->save($con);
                }
                $this->setLibrarianRelatedByCreatedBy($this->aLibrarianRelatedByCreatedBy);
            }

            if ($this->aLibrarianRelatedByModifiedBy !== null) {
                if ($this->aLibrarianRelatedByModifiedBy->isModified() || $this->aLibrarianRelatedByModifiedBy->isNew()) {
                    $affectedRows += $this->aLibrarianRelatedByModifiedBy->save($con);
                }
                $this->setLibrarianRelatedByModifiedBy($this->aLibrarianRelatedByModifiedBy);
            }

            if ($this->aIssue !== null) {
                if ($this->aIssue->isModified() || $this->aIssue->isNew()) {
                    $affectedRows += $this->aIssue->save($con);
                }
                $this->setIssue($this->aIssue);
            }

            if ($this->aManifestation !== null) {
                if ($this->aManifestation->isModified() || $this->aManifestation->isNew()) {
                    $affectedRows += $this->aManifestation->save($con);
                }
                $this->setManifestation($this->aManifestation);
            }

            if ($this->aConsistencyNote !== null) {
                if ($this->aConsistencyNote->isModified() || $this->aConsistencyNote->isNew()) {
                    $affectedRows += $this->aConsistencyNote->save($con);
                }
                $this->setConsistencyNote($this->aConsistencyNote);
            }

            if ($this->aLibraryRelatedByOwnerLibraryId !== null) {
                if ($this->aLibraryRelatedByOwnerLibraryId->isModified() || $this->aLibraryRelatedByOwnerLibraryId->isNew()) {
                    $affectedRows += $this->aLibraryRelatedByOwnerLibraryId->save($con);
                }
                $this->setLibraryRelatedByOwnerLibraryId($this->aLibraryRelatedByOwnerLibraryId);
            }

            if ($this->aLibraryRelatedByHomeLibraryId !== null) {
                if ($this->aLibraryRelatedByHomeLibraryId->isModified() || $this->aLibraryRelatedByHomeLibraryId->isNew()) {
                    $affectedRows += $this->aLibraryRelatedByHomeLibraryId->save($con);
                }
                $this->setLibraryRelatedByHomeLibraryId($this->aLibraryRelatedByHomeLibraryId);
            }

            if ($this->aLibraryRelatedByDeliveryLibraryId !== null) {
                if ($this->aLibraryRelatedByDeliveryLibraryId->isModified() || $this->aLibraryRelatedByDeliveryLibraryId->isNew()) {
                    $affectedRows += $this->aLibraryRelatedByDeliveryLibraryId->save($con);
                }
                $this->setLibraryRelatedByDeliveryLibraryId($this->aLibraryRelatedByDeliveryLibraryId);
            }

            if ($this->aLibraryRelatedByActualLibraryId !== null) {
                if ($this->aLibraryRelatedByActualLibraryId->isModified() || $this->aLibraryRelatedByActualLibraryId->isNew()) {
                    $affectedRows += $this->aLibraryRelatedByActualLibraryId->save($con);
                }
                $this->setLibraryRelatedByActualLibraryId($this->aLibraryRelatedByActualLibraryId);
            }

            if ($this->aInventorySerie !== null) {
                if ($this->aInventorySerie->isModified() || $this->aInventorySerie->isNew()) {
                    $affectedRows += $this->aInventorySerie->save($con);
                }
                $this->setInventorySerie($this->aInventorySerie);
            }

            if ($this->aPurchaseOrder !== null) {
                if ($this->aPurchaseOrder->isModified() || $this->aPurchaseOrder->isNew()) {
                    $affectedRows += $this->aPurchaseOrder->save($con);
                }
                $this->setPurchaseOrder($this->aPurchaseOrder);
            }

            if ($this->aInvoice !== null) {
                if ($this->aInvoice->isModified() || $this->aInvoice->isNew()) {
                    $affectedRows += $this->aInvoice->save($con);
                }
                $this->setInvoice($this->aInvoice);
            }

            if ($this->aSupplier !== null) {
                if ($this->aSupplier->isModified() || $this->aSupplier->isNew()) {
                    $affectedRows += $this->aSupplier->save($con);
                }
                $this->setSupplier($this->aSupplier);
            }

            if ($this->aPatron !== null) {
                if ($this->aPatron->isModified() || $this->aPatron->isNew()) {
                    $affectedRows += $this->aPatron->save($con);
                }
                $this->setPatron($this->aPatron);
            }

            if ($this->aLibraryRelatedByExternalLibraryId !== null) {
                if ($this->aLibraryRelatedByExternalLibraryId->isModified() || $this->aLibraryRelatedByExternalLibraryId->isNew()) {
                    $affectedRows += $this->aLibraryRelatedByExternalLibraryId->save($con);
                }
                $this->setLibraryRelatedByExternalLibraryId($this->aLibraryRelatedByExternalLibraryId);
            }

            if ($this->aLoanRelatedByCurrentLoanId !== null) {
                if ($this->aLoanRelatedByCurrentLoanId->isModified() || $this->aLoanRelatedByCurrentLoanId->isNew()) {
                    $affectedRows += $this->aLoanRelatedByCurrentLoanId->save($con);
                }
                $this->setLoanRelatedByCurrentLoanId($this->aLoanRelatedByCurrentLoanId);
            }

            if ($this->aBudget !== null) {
                if ($this->aBudget->isModified() || $this->aBudget->isNew()) {
                    $affectedRows += $this->aBudget->save($con);
                }
                $this->setBudget($this->aBudget);
            }

            if ($this->isNew() || $this->isModified()) {
                // persist changes
                if ($this->isNew()) {
                    $this->doInsert($con);
                } else {
                    $this->doUpdate($con);
                }
                $affectedRows += 1;
                $this->resetModified();
            }

            if ($this->itemActionsScheduledForDeletion !== null) {
                if (!$this->itemActionsScheduledForDeletion->isEmpty()) {
                    foreach ($this->itemActionsScheduledForDeletion as $itemAction) {
                        // need to save related object because we set the relation to null
                        $itemAction->save($con);
                    }
                    $this->itemActionsScheduledForDeletion = null;
                }
            }

            if ($this->collItemActions !== null) {
                foreach ($this->collItemActions as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->itemNotesScheduledForDeletion !== null) {
                if (!$this->itemNotesScheduledForDeletion->isEmpty()) {
                    foreach ($this->itemNotesScheduledForDeletion as $itemNote) {
                        // need to save related object because we set the relation to null
                        $itemNote->save($con);
                    }
                    $this->itemNotesScheduledForDeletion = null;
                }
            }

            if ($this->collItemNotes !== null) {
                foreach ($this->collItemNotes as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->itemRequestsScheduledForDeletion !== null) {
                if (!$this->itemRequestsScheduledForDeletion->isEmpty()) {
                    foreach ($this->itemRequestsScheduledForDeletion as $itemRequest) {
                        // need to save related object because we set the relation to null
                        $itemRequest->save($con);
                    }
                    $this->itemRequestsScheduledForDeletion = null;
                }
            }

            if ($this->collItemRequests !== null) {
                foreach ($this->collItemRequests as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->loansRelatedByItemIdScheduledForDeletion !== null) {
                if (!$this->loansRelatedByItemIdScheduledForDeletion->isEmpty()) {
                    foreach ($this->loansRelatedByItemIdScheduledForDeletion as $loanRelatedByItemId) {
                        // need to save related object because we set the relation to null
                        $loanRelatedByItemId->save($con);
                    }
                    $this->loansRelatedByItemIdScheduledForDeletion = null;
                }
            }

            if ($this->collLoansRelatedByItemId !== null) {
                foreach ($this->collLoansRelatedByItemId as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->lAuthorityItemsScheduledForDeletion !== null) {
                if (!$this->lAuthorityItemsScheduledForDeletion->isEmpty()) {
                    LAuthorityItemQuery::create()
                        ->filterByPrimaryKeys($this->lAuthorityItemsScheduledForDeletion->getPrimaryKeys(false))
                        ->delete($con);
                    $this->lAuthorityItemsScheduledForDeletion = null;
                }
            }

            if ($this->collLAuthorityItems !== null) {
                foreach ($this->collLAuthorityItems as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->purchaseProposalsScheduledForDeletion !== null) {
                if (!$this->purchaseProposalsScheduledForDeletion->isEmpty()) {
                    foreach ($this->purchaseProposalsScheduledForDeletion as $purchaseProposal) {
                        // need to save related object because we set the relation to null
                        $purchaseProposal->save($con);
                    }
                    $this->purchaseProposalsScheduledForDeletion = null;
                }
            }

            if ($this->collPurchaseProposals !== null) {
                foreach ($this->collPurchaseProposals as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            $this->alreadyInSave = false;

        }

        return $affectedRows;
    } // doSave()

    /**
     * Insert the row in the database.
     *
     * @param PropelPDO $con
     *
     * @throws PropelException
     * @see        doSave()
     */
    protected function doInsert(PropelPDO $con)
    {
        $modifiedColumns = array();
        $index = 0;

        $this->modifiedColumns[] = ItemPeer::ITEM_ID;
        if (null !== $this->item_id) {
            throw new PropelException('Cannot insert a value for auto-increment primary key (' . ItemPeer::ITEM_ID . ')');
        }

         // check the columns in natural order for more readable SQL queries
        if ($this->isColumnModified(ItemPeer::ITEM_ID)) {
            $modifiedColumns[':p' . $index++]  = '`item_id`';
        }
        if ($this->isColumnModified(ItemPeer::TITLE)) {
            $modifiedColumns[':p' . $index++]  = '`title`';
        }
        if ($this->isColumnModified(ItemPeer::MANIFESTATION_ID)) {
            $modifiedColumns[':p' . $index++]  = '`manifestation_id`';
        }
        if ($this->isColumnModified(ItemPeer::MANIFESTATION_DEWEY)) {
            $modifiedColumns[':p' . $index++]  = '`manifestation_dewey`';
        }
        if ($this->isColumnModified(ItemPeer::ITEM_MEDIA)) {
            $modifiedColumns[':p' . $index++]  = '`item_media`';
        }
        if ($this->isColumnModified(ItemPeer::ITEM_STATUS)) {
            $modifiedColumns[':p' . $index++]  = '`item_status`';
        }
        if ($this->isColumnModified(ItemPeer::ITEM_ORDER_STATUS)) {
            $modifiedColumns[':p' . $index++]  = '`item_order_status`';
        }
        if ($this->isColumnModified(ItemPeer::ITEM_ICON)) {
            $modifiedColumns[':p' . $index++]  = '`item_icon`';
        }
        if ($this->isColumnModified(ItemPeer::PHYSICAL_STATUS)) {
            $modifiedColumns[':p' . $index++]  = '`physical_status`';
        }
        if ($this->isColumnModified(ItemPeer::ITEM_SOURCE)) {
            $modifiedColumns[':p' . $index++]  = '`item_source`';
        }
        if ($this->isColumnModified(ItemPeer::OPAC_VISIBLE)) {
            $modifiedColumns[':p' . $index++]  = '`opac_visible`';
        }
        if ($this->isColumnModified(ItemPeer::INVENTORY_SERIE_ID)) {
            $modifiedColumns[':p' . $index++]  = '`inventory_serie_id`';
        }
        if ($this->isColumnModified(ItemPeer::INVENTORY_NUMBER)) {
            $modifiedColumns[':p' . $index++]  = '`inventory_number`';
        }
        if ($this->isColumnModified(ItemPeer::INVENTORY_DATE)) {
            $modifiedColumns[':p' . $index++]  = '`inventory_date`';
        }
        if ($this->isColumnModified(ItemPeer::OWNER_LIBRARY_ID)) {
            $modifiedColumns[':p' . $index++]  = '`owner_library_id`';
        }
        if ($this->isColumnModified(ItemPeer::HOME_LIBRARY_ID)) {
            $modifiedColumns[':p' . $index++]  = '`home_library_id`';
        }
        if ($this->isColumnModified(ItemPeer::COLLOCATION)) {
            $modifiedColumns[':p' . $index++]  = '`collocation`';
        }
        if ($this->isColumnModified(ItemPeer::SECTION)) {
            $modifiedColumns[':p' . $index++]  = '`section`';
        }
        if ($this->isColumnModified(ItemPeer::SEQUENCE1)) {
            $modifiedColumns[':p' . $index++]  = '`sequence1`';
        }
        if ($this->isColumnModified(ItemPeer::SEQUENCE2)) {
            $modifiedColumns[':p' . $index++]  = '`sequence2`';
        }
        if ($this->isColumnModified(ItemPeer::SPECIFICATION)) {
            $modifiedColumns[':p' . $index++]  = '`specification`';
        }
        if ($this->isColumnModified(ItemPeer::REPRINT)) {
            $modifiedColumns[':p' . $index++]  = '`reprint`';
        }
        if ($this->isColumnModified(ItemPeer::WIDTH)) {
            $modifiedColumns[':p' . $index++]  = '`width`';
        }
        if ($this->isColumnModified(ItemPeer::HEIGHT)) {
            $modifiedColumns[':p' . $index++]  = '`height`';
        }
        if ($this->isColumnModified(ItemPeer::WEIGHT)) {
            $modifiedColumns[':p' . $index++]  = '`weight`';
        }
        if ($this->isColumnModified(ItemPeer::VOLUME_NUMBER)) {
            $modifiedColumns[':p' . $index++]  = '`volume_number`';
        }
        if ($this->isColumnModified(ItemPeer::VOLUME_TEXT)) {
            $modifiedColumns[':p' . $index++]  = '`volume_text`';
        }
        if ($this->isColumnModified(ItemPeer::MEDIAPACKAGE_SIZE)) {
            $modifiedColumns[':p' . $index++]  = '`mediapackage_size`';
        }
        if ($this->isColumnModified(ItemPeer::CURRENT_LOAN_ID)) {
            $modifiedColumns[':p' . $index++]  = '`current_loan_id`';
        }
        if ($this->isColumnModified(ItemPeer::LOAN_CLASS)) {
            $modifiedColumns[':p' . $index++]  = '`loan_class`';
        }
        if ($this->isColumnModified(ItemPeer::LAST_SEEN)) {
            $modifiedColumns[':p' . $index++]  = '`last_seen`';
        }
        if ($this->isColumnModified(ItemPeer::LOAN_STATUS)) {
            $modifiedColumns[':p' . $index++]  = '`loan_status`';
        }
        if ($this->isColumnModified(ItemPeer::LOAN_ALERT)) {
            $modifiedColumns[':p' . $index++]  = '`loan_alert`';
        }
        if ($this->isColumnModified(ItemPeer::LOAN_ALERT_NOTE)) {
            $modifiedColumns[':p' . $index++]  = '`loan_alert_note`';
        }
        if ($this->isColumnModified(ItemPeer::USAGE_COUNT)) {
            $modifiedColumns[':p' . $index++]  = '`usage_count`';
        }
        if ($this->isColumnModified(ItemPeer::DELIVERY_LIBRARY_ID)) {
            $modifiedColumns[':p' . $index++]  = '`delivery_library_id`';
        }
        if ($this->isColumnModified(ItemPeer::DUE_DATE)) {
            $modifiedColumns[':p' . $index++]  = '`due_date`';
        }
        if ($this->isColumnModified(ItemPeer::PATRON_ID)) {
            $modifiedColumns[':p' . $index++]  = '`patron_id`';
        }
        if ($this->isColumnModified(ItemPeer::EXTERNAL_LIBRARY_ID)) {
            $modifiedColumns[':p' . $index++]  = '`external_library_id`';
        }
        if ($this->isColumnModified(ItemPeer::RENEWAL_COUNT)) {
            $modifiedColumns[':p' . $index++]  = '`renewal_count`';
        }
        if ($this->isColumnModified(ItemPeer::NOTIFY_COUNT)) {
            $modifiedColumns[':p' . $index++]  = '`notify_count`';
        }
        if ($this->isColumnModified(ItemPeer::CHECK_OUT)) {
            $modifiedColumns[':p' . $index++]  = '`check_out`';
        }
        if ($this->isColumnModified(ItemPeer::CHECK_IN)) {
            $modifiedColumns[':p' . $index++]  = '`check_in`';
        }
        if ($this->isColumnModified(ItemPeer::ILL_TIMESTAMP)) {
            $modifiedColumns[':p' . $index++]  = '`ill_timestamp`';
        }
        if ($this->isColumnModified(ItemPeer::SUPPLIER_ID)) {
            $modifiedColumns[':p' . $index++]  = '`supplier_id`';
        }
        if ($this->isColumnModified(ItemPeer::INVOICE_ID)) {
            $modifiedColumns[':p' . $index++]  = '`invoice_id`';
        }
        if ($this->isColumnModified(ItemPeer::ORDER_ID)) {
            $modifiedColumns[':p' . $index++]  = '`order_id`';
        }
        if ($this->isColumnModified(ItemPeer::BUDGET_ID)) {
            $modifiedColumns[':p' . $index++]  = '`budget_id`';
        }
        if ($this->isColumnModified(ItemPeer::CURRENCY)) {
            $modifiedColumns[':p' . $index++]  = '`currency`';
        }
        if ($this->isColumnModified(ItemPeer::CURRENCY_VALUE)) {
            $modifiedColumns[':p' . $index++]  = '`currency_value`';
        }
        if ($this->isColumnModified(ItemPeer::DISCOUNT_VALUE)) {
            $modifiedColumns[':p' . $index++]  = '`discount_value`';
        }
        if ($this->isColumnModified(ItemPeer::INVENTORY_VALUE)) {
            $modifiedColumns[':p' . $index++]  = '`inventory_value`';
        }
        if ($this->isColumnModified(ItemPeer::ISSUE_INVENTORY_NUMBER)) {
            $modifiedColumns[':p' . $index++]  = '`issue_inventory_number`';
        }
        if ($this->isColumnModified(ItemPeer::ISSUE_ID)) {
            $modifiedColumns[':p' . $index++]  = '`issue_id`';
        }
        if ($this->isColumnModified(ItemPeer::ISSUE_YEAR)) {
            $modifiedColumns[':p' . $index++]  = '`issue_year`';
        }
        if ($this->isColumnModified(ItemPeer::ISSUE_NUMBER)) {
            $modifiedColumns[':p' . $index++]  = '`issue_number`';
        }
        if ($this->isColumnModified(ItemPeer::ISSUE_DESCRIPTION)) {
            $modifiedColumns[':p' . $index++]  = '`issue_description`';
        }
        if ($this->isColumnModified(ItemPeer::ISSUE_ARRIVAL_DATE)) {
            $modifiedColumns[':p' . $index++]  = '`issue_arrival_date`';
        }
        if ($this->isColumnModified(ItemPeer::ISSUE_ARRIVAL_DATE_EXPECTED)) {
            $modifiedColumns[':p' . $index++]  = '`issue_arrival_date_expected`';
        }
        if ($this->isColumnModified(ItemPeer::ISSUE_STATUS)) {
            $modifiedColumns[':p' . $index++]  = '`issue_status`';
        }
        if ($this->isColumnModified(ItemPeer::SUBSCRIPTION_ID)) {
            $modifiedColumns[':p' . $index++]  = '`subscription_id`';
        }
        if ($this->isColumnModified(ItemPeer::CONSISTENCY_NOTE_ID)) {
            $modifiedColumns[':p' . $index++]  = '`consistency_note_id`';
        }
        if ($this->isColumnModified(ItemPeer::ACTUAL_LIBRARY_ID)) {
            $modifiedColumns[':p' . $index++]  = '`actual_library_id`';
        }
        if ($this->isColumnModified(ItemPeer::BARCODE)) {
            $modifiedColumns[':p' . $index++]  = '`barcode`';
        }
        if ($this->isColumnModified(ItemPeer::RFID_CODE)) {
            $modifiedColumns[':p' . $index++]  = '`rfid_code`';
        }
        if ($this->isColumnModified(ItemPeer::CUSTOM_FIELD1)) {
            $modifiedColumns[':p' . $index++]  = '`custom_field1`';
        }
        if ($this->isColumnModified(ItemPeer::CUSTOM_FIELD2)) {
            $modifiedColumns[':p' . $index++]  = '`custom_field2`';
        }
        if ($this->isColumnModified(ItemPeer::CUSTOM_FIELD3)) {
            $modifiedColumns[':p' . $index++]  = '`custom_field3`';
        }
        if ($this->isColumnModified(ItemPeer::UNIMARC)) {
            $modifiedColumns[':p' . $index++]  = '`unimarc`';
        }
        if ($this->isColumnModified(ItemPeer::LAST_SBN_SYNC)) {
            $modifiedColumns[':p' . $index++]  = '`last_sbn_sync`';
        }
        if ($this->isColumnModified(ItemPeer::DATE_DISCARDED)) {
            $modifiedColumns[':p' . $index++]  = '`date_discarded`';
        }
        if ($this->isColumnModified(ItemPeer::DISCARD_NOTE)) {
            $modifiedColumns[':p' . $index++]  = '`discard_note`';
        }
        if ($this->isColumnModified(ItemPeer::DATE_CREATED)) {
            $modifiedColumns[':p' . $index++]  = '`date_created`';
        }
        if ($this->isColumnModified(ItemPeer::DATE_UPDATED)) {
            $modifiedColumns[':p' . $index++]  = '`date_updated`';
        }
        if ($this->isColumnModified(ItemPeer::CREATED_BY)) {
            $modifiedColumns[':p' . $index++]  = '`created_by`';
        }
        if ($this->isColumnModified(ItemPeer::MODIFIED_BY)) {
            $modifiedColumns[':p' . $index++]  = '`modified_by`';
        }

        $sql = sprintf(
            'INSERT INTO `item` (%s) VALUES (%s)',
            implode(', ', $modifiedColumns),
            implode(', ', array_keys($modifiedColumns))
        );

        try {
            $stmt = $con->prepare($sql);
            foreach ($modifiedColumns as $identifier => $columnName) {
                switch ($columnName) {
                    case '`item_id`':
                        $stmt->bindValue($identifier, $this->item_id, PDO::PARAM_INT);
                        break;
                    case '`title`':
                        $stmt->bindValue($identifier, $this->title, PDO::PARAM_STR);
                        break;
                    case '`manifestation_id`':
                        $stmt->bindValue($identifier, $this->manifestation_id, PDO::PARAM_INT);
                        break;
                    case '`manifestation_dewey`':
                        $stmt->bindValue($identifier, $this->manifestation_dewey, PDO::PARAM_STR);
                        break;
                    case '`item_media`':
                        $stmt->bindValue($identifier, $this->item_media, PDO::PARAM_STR);
                        break;
                    case '`item_status`':
                        $stmt->bindValue($identifier, $this->item_status, PDO::PARAM_STR);
                        break;
                    case '`item_order_status`':
                        $stmt->bindValue($identifier, $this->item_order_status, PDO::PARAM_STR);
                        break;
                    case '`item_icon`':
                        $stmt->bindValue($identifier, $this->item_icon, PDO::PARAM_STR);
                        break;
                    case '`physical_status`':
                        $stmt->bindValue($identifier, $this->physical_status, PDO::PARAM_STR);
                        break;
                    case '`item_source`':
                        $stmt->bindValue($identifier, $this->item_source, PDO::PARAM_STR);
                        break;
                    case '`opac_visible`':
                        $stmt->bindValue($identifier, (int) $this->opac_visible, PDO::PARAM_INT);
                        break;
                    case '`inventory_serie_id`':
                        $stmt->bindValue($identifier, $this->inventory_serie_id, PDO::PARAM_STR);
                        break;
                    case '`inventory_number`':
                        $stmt->bindValue($identifier, $this->inventory_number, PDO::PARAM_INT);
                        break;
                    case '`inventory_date`':
                        $stmt->bindValue($identifier, $this->inventory_date, PDO::PARAM_STR);
                        break;
                    case '`owner_library_id`':
                        $stmt->bindValue($identifier, $this->owner_library_id, PDO::PARAM_INT);
                        break;
                    case '`home_library_id`':
                        $stmt->bindValue($identifier, $this->home_library_id, PDO::PARAM_INT);
                        break;
                    case '`collocation`':
                        $stmt->bindValue($identifier, $this->collocation, PDO::PARAM_STR);
                        break;
                    case '`section`':
                        $stmt->bindValue($identifier, $this->section, PDO::PARAM_STR);
                        break;
                    case '`sequence1`':
                        $stmt->bindValue($identifier, $this->sequence1, PDO::PARAM_STR);
                        break;
                    case '`sequence2`':
                        $stmt->bindValue($identifier, $this->sequence2, PDO::PARAM_STR);
                        break;
                    case '`specification`':
                        $stmt->bindValue($identifier, $this->specification, PDO::PARAM_STR);
                        break;
                    case '`reprint`':
                        $stmt->bindValue($identifier, $this->reprint, PDO::PARAM_STR);
                        break;
                    case '`width`':
                        $stmt->bindValue($identifier, $this->width, PDO::PARAM_INT);
                        break;
                    case '`height`':
                        $stmt->bindValue($identifier, $this->height, PDO::PARAM_INT);
                        break;
                    case '`weight`':
                        $stmt->bindValue($identifier, $this->weight, PDO::PARAM_STR);
                        break;
                    case '`volume_number`':
                        $stmt->bindValue($identifier, $this->volume_number, PDO::PARAM_INT);
                        break;
                    case '`volume_text`':
                        $stmt->bindValue($identifier, $this->volume_text, PDO::PARAM_STR);
                        break;
                    case '`mediapackage_size`':
                        $stmt->bindValue($identifier, $this->mediapackage_size, PDO::PARAM_INT);
                        break;
                    case '`current_loan_id`':
                        $stmt->bindValue($identifier, $this->current_loan_id, PDO::PARAM_INT);
                        break;
                    case '`loan_class`':
                        $stmt->bindValue($identifier, $this->loan_class, PDO::PARAM_STR);
                        break;
                    case '`last_seen`':
                        $stmt->bindValue($identifier, $this->last_seen, PDO::PARAM_STR);
                        break;
                    case '`loan_status`':
                        $stmt->bindValue($identifier, $this->loan_status, PDO::PARAM_STR);
                        break;
                    case '`loan_alert`':
                        $stmt->bindValue($identifier, $this->loan_alert, PDO::PARAM_STR);
                        break;
                    case '`loan_alert_note`':
                        $stmt->bindValue($identifier, $this->loan_alert_note, PDO::PARAM_STR);
                        break;
                    case '`usage_count`':
                        $stmt->bindValue($identifier, $this->usage_count, PDO::PARAM_INT);
                        break;
                    case '`delivery_library_id`':
                        $stmt->bindValue($identifier, $this->delivery_library_id, PDO::PARAM_INT);
                        break;
                    case '`due_date`':
                        $stmt->bindValue($identifier, $this->due_date, PDO::PARAM_STR);
                        break;
                    case '`patron_id`':
                        $stmt->bindValue($identifier, $this->patron_id, PDO::PARAM_INT);
                        break;
                    case '`external_library_id`':
                        $stmt->bindValue($identifier, $this->external_library_id, PDO::PARAM_INT);
                        break;
                    case '`renewal_count`':
                        $stmt->bindValue($identifier, $this->renewal_count, PDO::PARAM_INT);
                        break;
                    case '`notify_count`':
                        $stmt->bindValue($identifier, $this->notify_count, PDO::PARAM_INT);
                        break;
                    case '`check_out`':
                        $stmt->bindValue($identifier, $this->check_out, PDO::PARAM_STR);
                        break;
                    case '`check_in`':
                        $stmt->bindValue($identifier, $this->check_in, PDO::PARAM_STR);
                        break;
                    case '`ill_timestamp`':
                        $stmt->bindValue($identifier, $this->ill_timestamp, PDO::PARAM_STR);
                        break;
                    case '`supplier_id`':
                        $stmt->bindValue($identifier, $this->supplier_id, PDO::PARAM_INT);
                        break;
                    case '`invoice_id`':
                        $stmt->bindValue($identifier, $this->invoice_id, PDO::PARAM_INT);
                        break;
                    case '`order_id`':
                        $stmt->bindValue($identifier, $this->order_id, PDO::PARAM_INT);
                        break;
                    case '`budget_id`':
                        $stmt->bindValue($identifier, $this->budget_id, PDO::PARAM_INT);
                        break;
                    case '`currency`':
                        $stmt->bindValue($identifier, $this->currency, PDO::PARAM_STR);
                        break;
                    case '`currency_value`':
                        $stmt->bindValue($identifier, $this->currency_value, PDO::PARAM_STR);
                        break;
                    case '`discount_value`':
                        $stmt->bindValue($identifier, $this->discount_value, PDO::PARAM_STR);
                        break;
                    case '`inventory_value`':
                        $stmt->bindValue($identifier, $this->inventory_value, PDO::PARAM_STR);
                        break;
                    case '`issue_inventory_number`':
                        $stmt->bindValue($identifier, $this->issue_inventory_number, PDO::PARAM_INT);
                        break;
                    case '`issue_id`':
                        $stmt->bindValue($identifier, $this->issue_id, PDO::PARAM_INT);
                        break;
                    case '`issue_year`':
                        $stmt->bindValue($identifier, $this->issue_year, PDO::PARAM_STR);
                        break;
                    case '`issue_number`':
                        $stmt->bindValue($identifier, $this->issue_number, PDO::PARAM_INT);
                        break;
                    case '`issue_description`':
                        $stmt->bindValue($identifier, $this->issue_description, PDO::PARAM_STR);
                        break;
                    case '`issue_arrival_date`':
                        $stmt->bindValue($identifier, $this->issue_arrival_date, PDO::PARAM_STR);
                        break;
                    case '`issue_arrival_date_expected`':
                        $stmt->bindValue($identifier, $this->issue_arrival_date_expected, PDO::PARAM_STR);
                        break;
                    case '`issue_status`':
                        $stmt->bindValue($identifier, $this->issue_status, PDO::PARAM_STR);
                        break;
                    case '`subscription_id`':
                        $stmt->bindValue($identifier, $this->subscription_id, PDO::PARAM_INT);
                        break;
                    case '`consistency_note_id`':
                        $stmt->bindValue($identifier, $this->consistency_note_id, PDO::PARAM_INT);
                        break;
                    case '`actual_library_id`':
                        $stmt->bindValue($identifier, $this->actual_library_id, PDO::PARAM_INT);
                        break;
                    case '`barcode`':
                        $stmt->bindValue($identifier, $this->barcode, PDO::PARAM_STR);
                        break;
                    case '`rfid_code`':
                        $stmt->bindValue($identifier, $this->rfid_code, PDO::PARAM_STR);
                        break;
                    case '`custom_field1`':
                        $stmt->bindValue($identifier, $this->custom_field1, PDO::PARAM_STR);
                        break;
                    case '`custom_field2`':
                        $stmt->bindValue($identifier, $this->custom_field2, PDO::PARAM_STR);
                        break;
                    case '`custom_field3`':
                        $stmt->bindValue($identifier, $this->custom_field3, PDO::PARAM_STR);
                        break;
                    case '`unimarc`':
                        $stmt->bindValue($identifier, $this->unimarc, PDO::PARAM_STR);
                        break;
                    case '`last_sbn_sync`':
                        $stmt->bindValue($identifier, $this->last_sbn_sync, PDO::PARAM_STR);
                        break;
                    case '`date_discarded`':
                        $stmt->bindValue($identifier, $this->date_discarded, PDO::PARAM_STR);
                        break;
                    case '`discard_note`':
                        $stmt->bindValue($identifier, $this->discard_note, PDO::PARAM_STR);
                        break;
                    case '`date_created`':
                        $stmt->bindValue($identifier, $this->date_created, PDO::PARAM_STR);
                        break;
                    case '`date_updated`':
                        $stmt->bindValue($identifier, $this->date_updated, PDO::PARAM_STR);
                        break;
                    case '`created_by`':
                        $stmt->bindValue($identifier, $this->created_by, PDO::PARAM_INT);
                        break;
                    case '`modified_by`':
                        $stmt->bindValue($identifier, $this->modified_by, PDO::PARAM_INT);
                        break;
                }
            }
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute INSERT statement [%s]', $sql), $e);
        }

        try {
            $pk = $con->lastInsertId();
        } catch (Exception $e) {
            throw new PropelException('Unable to get autoincrement id.', $e);
        }
        $this->setItemId($pk);

        $this->setNew(false);
    }

    /**
     * Update the row in the database.
     *
     * @param PropelPDO $con
     *
     * @see        doSave()
     */
    protected function doUpdate(PropelPDO $con)
    {
        $selectCriteria = $this->buildPkeyCriteria();
        $valuesCriteria = $this->buildCriteria();
        BasePeer::doUpdate($selectCriteria, $valuesCriteria, $con);
    }

    /**
     * Array of ValidationFailed objects.
     * @var        array ValidationFailed[]
     */
    protected $validationFailures = array();

    /**
     * Gets any ValidationFailed objects that resulted from last call to validate().
     *
     *
     * @return array ValidationFailed[]
     * @see        validate()
     */
    public function getValidationFailures()
    {
        return $this->validationFailures;
    }

    /**
     * Validates the objects modified field values and all objects related to this table.
     *
     * If $columns is either a column name or an array of column names
     * only those columns are validated.
     *
     * @param mixed $columns Column name or an array of column names.
     * @return boolean Whether all columns pass validation.
     * @see        doValidate()
     * @see        getValidationFailures()
     */
    public function validate($columns = null)
    {
        $res = $this->doValidate($columns);
        if ($res === true) {
            $this->validationFailures = array();

            return true;
        }

        $this->validationFailures = $res;

        return false;
    }

    /**
     * This function performs the validation work for complex object models.
     *
     * In addition to checking the current object, all related objects will
     * also be validated.  If all pass then <code>true</code> is returned; otherwise
     * an aggregated array of ValidationFailed objects will be returned.
     *
     * @param array $columns Array of column names to validate.
     * @return mixed <code>true</code> if all validations pass; array of <code>ValidationFailed</code> objects otherwise.
     */
    protected function doValidate($columns = null)
    {
        if (!$this->alreadyInValidation) {
            $this->alreadyInValidation = true;
            $retval = null;

            $failureMap = array();


            // We call the validate method on the following object(s) if they
            // were passed to this object by their corresponding set
            // method.  This object relates to these object(s) by a
            // foreign key reference.

            if ($this->aLibrarianRelatedByCreatedBy !== null) {
                if (!$this->aLibrarianRelatedByCreatedBy->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aLibrarianRelatedByCreatedBy->getValidationFailures());
                }
            }

            if ($this->aLibrarianRelatedByModifiedBy !== null) {
                if (!$this->aLibrarianRelatedByModifiedBy->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aLibrarianRelatedByModifiedBy->getValidationFailures());
                }
            }

            if ($this->aIssue !== null) {
                if (!$this->aIssue->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aIssue->getValidationFailures());
                }
            }

            if ($this->aManifestation !== null) {
                if (!$this->aManifestation->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aManifestation->getValidationFailures());
                }
            }

            if ($this->aConsistencyNote !== null) {
                if (!$this->aConsistencyNote->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aConsistencyNote->getValidationFailures());
                }
            }

            if ($this->aLibraryRelatedByOwnerLibraryId !== null) {
                if (!$this->aLibraryRelatedByOwnerLibraryId->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aLibraryRelatedByOwnerLibraryId->getValidationFailures());
                }
            }

            if ($this->aLibraryRelatedByHomeLibraryId !== null) {
                if (!$this->aLibraryRelatedByHomeLibraryId->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aLibraryRelatedByHomeLibraryId->getValidationFailures());
                }
            }

            if ($this->aLibraryRelatedByDeliveryLibraryId !== null) {
                if (!$this->aLibraryRelatedByDeliveryLibraryId->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aLibraryRelatedByDeliveryLibraryId->getValidationFailures());
                }
            }

            if ($this->aLibraryRelatedByActualLibraryId !== null) {
                if (!$this->aLibraryRelatedByActualLibraryId->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aLibraryRelatedByActualLibraryId->getValidationFailures());
                }
            }

            if ($this->aInventorySerie !== null) {
                if (!$this->aInventorySerie->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aInventorySerie->getValidationFailures());
                }
            }

            if ($this->aPurchaseOrder !== null) {
                if (!$this->aPurchaseOrder->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aPurchaseOrder->getValidationFailures());
                }
            }

            if ($this->aInvoice !== null) {
                if (!$this->aInvoice->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aInvoice->getValidationFailures());
                }
            }

            if ($this->aSupplier !== null) {
                if (!$this->aSupplier->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aSupplier->getValidationFailures());
                }
            }

            if ($this->aPatron !== null) {
                if (!$this->aPatron->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aPatron->getValidationFailures());
                }
            }

            if ($this->aLibraryRelatedByExternalLibraryId !== null) {
                if (!$this->aLibraryRelatedByExternalLibraryId->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aLibraryRelatedByExternalLibraryId->getValidationFailures());
                }
            }

            if ($this->aLoanRelatedByCurrentLoanId !== null) {
                if (!$this->aLoanRelatedByCurrentLoanId->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aLoanRelatedByCurrentLoanId->getValidationFailures());
                }
            }

            if ($this->aBudget !== null) {
                if (!$this->aBudget->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aBudget->getValidationFailures());
                }
            }


            if (($retval = ItemPeer::doValidate($this, $columns)) !== true) {
                $failureMap = array_merge($failureMap, $retval);
            }


                if ($this->collItemActions !== null) {
                    foreach ($this->collItemActions as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collItemNotes !== null) {
                    foreach ($this->collItemNotes as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collItemRequests !== null) {
                    foreach ($this->collItemRequests as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collLoansRelatedByItemId !== null) {
                    foreach ($this->collLoansRelatedByItemId as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collLAuthorityItems !== null) {
                    foreach ($this->collLAuthorityItems as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collPurchaseProposals !== null) {
                    foreach ($this->collPurchaseProposals as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }


            $this->alreadyInValidation = false;
        }

        return (!empty($failureMap) ? $failureMap : true);
    }

    /**
     * Retrieves a field from the object by name passed in as a string.
     *
     * @param string $name name
     * @param string $type The type of fieldname the $name is of:
     *               one of the class type constants BasePeer::TYPE_PHPNAME, BasePeer::TYPE_STUDLYPHPNAME
     *               BasePeer::TYPE_COLNAME, BasePeer::TYPE_FIELDNAME, BasePeer::TYPE_NUM.
     *               Defaults to BasePeer::TYPE_PHPNAME
     * @return mixed Value of field.
     */
    public function getByName($name, $type = BasePeer::TYPE_PHPNAME)
    {
        $pos = ItemPeer::translateFieldName($name, $type, BasePeer::TYPE_NUM);
        $field = $this->getByPosition($pos);

        return $field;
    }

    /**
     * Retrieves a field from the object by Position as specified in the xml schema.
     * Zero-based.
     *
     * @param int $pos position in xml schema
     * @return mixed Value of field at $pos
     */
    public function getByPosition($pos)
    {
        switch ($pos) {
            case 0:
                return $this->getItemId();
                break;
            case 1:
                return $this->getTitle();
                break;
            case 2:
                return $this->getManifestationId();
                break;
            case 3:
                return $this->getManifestationDewey();
                break;
            case 4:
                return $this->getItemMedia();
                break;
            case 5:
                return $this->getItemStatus();
                break;
            case 6:
                return $this->getItemOrderStatus();
                break;
            case 7:
                return $this->getItemIcon();
                break;
            case 8:
                return $this->getPhysicalStatus();
                break;
            case 9:
                return $this->getItemSource();
                break;
            case 10:
                return $this->getOpacVisible();
                break;
            case 11:
                return $this->getInventorySerieId();
                break;
            case 12:
                return $this->getInventoryNumber();
                break;
            case 13:
                return $this->getInventoryDate();
                break;
            case 14:
                return $this->getOwnerLibraryId();
                break;
            case 15:
                return $this->getHomeLibraryId();
                break;
            case 16:
                return $this->getCollocation();
                break;
            case 17:
                return $this->getSection();
                break;
            case 18:
                return $this->getSequence1();
                break;
            case 19:
                return $this->getSequence2();
                break;
            case 20:
                return $this->getSpecification();
                break;
            case 21:
                return $this->getReprint();
                break;
            case 22:
                return $this->getWidth();
                break;
            case 23:
                return $this->getHeight();
                break;
            case 24:
                return $this->getWeight();
                break;
            case 25:
                return $this->getVolumeNumber();
                break;
            case 26:
                return $this->getVolumeText();
                break;
            case 27:
                return $this->getMediapackageSize();
                break;
            case 28:
                return $this->getCurrentLoanId();
                break;
            case 29:
                return $this->getLoanClass();
                break;
            case 30:
                return $this->getLastSeen();
                break;
            case 31:
                return $this->getLoanStatus();
                break;
            case 32:
                return $this->getLoanAlert();
                break;
            case 33:
                return $this->getLoanAlertNote();
                break;
            case 34:
                return $this->getUsageCount();
                break;
            case 35:
                return $this->getDeliveryLibraryId();
                break;
            case 36:
                return $this->getDueDate();
                break;
            case 37:
                return $this->getPatronId();
                break;
            case 38:
                return $this->getExternalLibraryId();
                break;
            case 39:
                return $this->getRenewalCount();
                break;
            case 40:
                return $this->getNotifyCount();
                break;
            case 41:
                return $this->getCheckOut();
                break;
            case 42:
                return $this->getCheckIn();
                break;
            case 43:
                return $this->getIllTimestamp();
                break;
            case 44:
                return $this->getSupplierId();
                break;
            case 45:
                return $this->getInvoiceId();
                break;
            case 46:
                return $this->getOrderId();
                break;
            case 47:
                return $this->getBudgetId();
                break;
            case 48:
                return $this->getCurrency();
                break;
            case 49:
                return $this->getCurrencyValue();
                break;
            case 50:
                return $this->getDiscountValue();
                break;
            case 51:
                return $this->getInventoryValue();
                break;
            case 52:
                return $this->getIssueInventoryNumber();
                break;
            case 53:
                return $this->getIssueId();
                break;
            case 54:
                return $this->getIssueYear();
                break;
            case 55:
                return $this->getIssueNumber();
                break;
            case 56:
                return $this->getIssueDescription();
                break;
            case 57:
                return $this->getIssueArrivalDate();
                break;
            case 58:
                return $this->getIssueArrivalDateExpected();
                break;
            case 59:
                return $this->getIssueStatus();
                break;
            case 60:
                return $this->getSubscriptionId();
                break;
            case 61:
                return $this->getConsistencyNoteId();
                break;
            case 62:
                return $this->getActualLibraryId();
                break;
            case 63:
                return $this->getBarcode();
                break;
            case 64:
                return $this->getRfidCode();
                break;
            case 65:
                return $this->getCustomField1();
                break;
            case 66:
                return $this->getCustomField2();
                break;
            case 67:
                return $this->getCustomField3();
                break;
            case 68:
                return $this->getUnimarc();
                break;
            case 69:
                return $this->getLastSbnSync();
                break;
            case 70:
                return $this->getDateDiscarded();
                break;
            case 71:
                return $this->getDiscardNote();
                break;
            case 72:
                return $this->getDateCreated();
                break;
            case 73:
                return $this->getDateUpdated();
                break;
            case 74:
                return $this->getCreatedBy();
                break;
            case 75:
                return $this->getModifiedBy();
                break;
            default:
                return null;
                break;
        } // switch()
    }

    /**
     * Exports the object as an array.
     *
     * You can specify the key type of the array by passing one of the class
     * type constants.
     *
     * @param     string  $keyType (optional) One of the class type constants BasePeer::TYPE_PHPNAME, BasePeer::TYPE_STUDLYPHPNAME,
     *                    BasePeer::TYPE_COLNAME, BasePeer::TYPE_FIELDNAME, BasePeer::TYPE_NUM.
     *                    Defaults to BasePeer::TYPE_PHPNAME.
     * @param     boolean $includeLazyLoadColumns (optional) Whether to include lazy loaded columns. Defaults to true.
     * @param     array $alreadyDumpedObjects List of objects to skip to avoid recursion
     * @param     boolean $includeForeignObjects (optional) Whether to include hydrated related objects. Default to FALSE.
     *
     * @return array an associative array containing the field names (as keys) and field values
     */
    public function toArray($keyType = BasePeer::TYPE_PHPNAME, $includeLazyLoadColumns = true, $alreadyDumpedObjects = array(), $includeForeignObjects = false)
    {
        if (isset($alreadyDumpedObjects['Item'][$this->getPrimaryKey()])) {
            return '*RECURSION*';
        }
        $alreadyDumpedObjects['Item'][$this->getPrimaryKey()] = true;
        $keys = ItemPeer::getFieldNames($keyType);
        $result = array(
            $keys[0] => $this->getItemId(),
            $keys[1] => $this->getTitle(),
            $keys[2] => $this->getManifestationId(),
            $keys[3] => $this->getManifestationDewey(),
            $keys[4] => $this->getItemMedia(),
            $keys[5] => $this->getItemStatus(),
            $keys[6] => $this->getItemOrderStatus(),
            $keys[7] => $this->getItemIcon(),
            $keys[8] => $this->getPhysicalStatus(),
            $keys[9] => $this->getItemSource(),
            $keys[10] => $this->getOpacVisible(),
            $keys[11] => $this->getInventorySerieId(),
            $keys[12] => $this->getInventoryNumber(),
            $keys[13] => $this->getInventoryDate(),
            $keys[14] => $this->getOwnerLibraryId(),
            $keys[15] => $this->getHomeLibraryId(),
            $keys[16] => $this->getCollocation(),
            $keys[17] => $this->getSection(),
            $keys[18] => $this->getSequence1(),
            $keys[19] => $this->getSequence2(),
            $keys[20] => $this->getSpecification(),
            $keys[21] => $this->getReprint(),
            $keys[22] => $this->getWidth(),
            $keys[23] => $this->getHeight(),
            $keys[24] => $this->getWeight(),
            $keys[25] => $this->getVolumeNumber(),
            $keys[26] => $this->getVolumeText(),
            $keys[27] => $this->getMediapackageSize(),
            $keys[28] => $this->getCurrentLoanId(),
            $keys[29] => $this->getLoanClass(),
            $keys[30] => $this->getLastSeen(),
            $keys[31] => $this->getLoanStatus(),
            $keys[32] => $this->getLoanAlert(),
            $keys[33] => $this->getLoanAlertNote(),
            $keys[34] => $this->getUsageCount(),
            $keys[35] => $this->getDeliveryLibraryId(),
            $keys[36] => $this->getDueDate(),
            $keys[37] => $this->getPatronId(),
            $keys[38] => $this->getExternalLibraryId(),
            $keys[39] => $this->getRenewalCount(),
            $keys[40] => $this->getNotifyCount(),
            $keys[41] => $this->getCheckOut(),
            $keys[42] => $this->getCheckIn(),
            $keys[43] => $this->getIllTimestamp(),
            $keys[44] => $this->getSupplierId(),
            $keys[45] => $this->getInvoiceId(),
            $keys[46] => $this->getOrderId(),
            $keys[47] => $this->getBudgetId(),
            $keys[48] => $this->getCurrency(),
            $keys[49] => $this->getCurrencyValue(),
            $keys[50] => $this->getDiscountValue(),
            $keys[51] => $this->getInventoryValue(),
            $keys[52] => $this->getIssueInventoryNumber(),
            $keys[53] => $this->getIssueId(),
            $keys[54] => $this->getIssueYear(),
            $keys[55] => $this->getIssueNumber(),
            $keys[56] => $this->getIssueDescription(),
            $keys[57] => $this->getIssueArrivalDate(),
            $keys[58] => $this->getIssueArrivalDateExpected(),
            $keys[59] => $this->getIssueStatus(),
            $keys[60] => $this->getSubscriptionId(),
            $keys[61] => $this->getConsistencyNoteId(),
            $keys[62] => $this->getActualLibraryId(),
            $keys[63] => $this->getBarcode(),
            $keys[64] => $this->getRfidCode(),
            $keys[65] => $this->getCustomField1(),
            $keys[66] => $this->getCustomField2(),
            $keys[67] => $this->getCustomField3(),
            $keys[68] => $this->getUnimarc(),
            $keys[69] => $this->getLastSbnSync(),
            $keys[70] => $this->getDateDiscarded(),
            $keys[71] => $this->getDiscardNote(),
            $keys[72] => $this->getDateCreated(),
            $keys[73] => $this->getDateUpdated(),
            $keys[74] => $this->getCreatedBy(),
            $keys[75] => $this->getModifiedBy(),
        );
        $virtualColumns = $this->virtualColumns;
        foreach ($virtualColumns as $key => $virtualColumn) {
            $result[$key] = $virtualColumn;
        }

        if ($includeForeignObjects) {
            if (null !== $this->aLibrarianRelatedByCreatedBy) {
                $result['LibrarianRelatedByCreatedBy'] = $this->aLibrarianRelatedByCreatedBy->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->aLibrarianRelatedByModifiedBy) {
                $result['LibrarianRelatedByModifiedBy'] = $this->aLibrarianRelatedByModifiedBy->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->aIssue) {
                $result['Issue'] = $this->aIssue->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->aManifestation) {
                $result['Manifestation'] = $this->aManifestation->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->aConsistencyNote) {
                $result['ConsistencyNote'] = $this->aConsistencyNote->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->aLibraryRelatedByOwnerLibraryId) {
                $result['LibraryRelatedByOwnerLibraryId'] = $this->aLibraryRelatedByOwnerLibraryId->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->aLibraryRelatedByHomeLibraryId) {
                $result['LibraryRelatedByHomeLibraryId'] = $this->aLibraryRelatedByHomeLibraryId->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->aLibraryRelatedByDeliveryLibraryId) {
                $result['LibraryRelatedByDeliveryLibraryId'] = $this->aLibraryRelatedByDeliveryLibraryId->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->aLibraryRelatedByActualLibraryId) {
                $result['LibraryRelatedByActualLibraryId'] = $this->aLibraryRelatedByActualLibraryId->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->aInventorySerie) {
                $result['InventorySerie'] = $this->aInventorySerie->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->aPurchaseOrder) {
                $result['PurchaseOrder'] = $this->aPurchaseOrder->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->aInvoice) {
                $result['Invoice'] = $this->aInvoice->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->aSupplier) {
                $result['Supplier'] = $this->aSupplier->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->aPatron) {
                $result['Patron'] = $this->aPatron->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->aLibraryRelatedByExternalLibraryId) {
                $result['LibraryRelatedByExternalLibraryId'] = $this->aLibraryRelatedByExternalLibraryId->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->aLoanRelatedByCurrentLoanId) {
                $result['LoanRelatedByCurrentLoanId'] = $this->aLoanRelatedByCurrentLoanId->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->aBudget) {
                $result['Budget'] = $this->aBudget->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->collItemActions) {
                $result['ItemActions'] = $this->collItemActions->toArray(null, true, $keyType, $includeLazyLoadColumns, $alreadyDumpedObjects);
            }
            if (null !== $this->collItemNotes) {
                $result['ItemNotes'] = $this->collItemNotes->toArray(null, true, $keyType, $includeLazyLoadColumns, $alreadyDumpedObjects);
            }
            if (null !== $this->collItemRequests) {
                $result['ItemRequests'] = $this->collItemRequests->toArray(null, true, $keyType, $includeLazyLoadColumns, $alreadyDumpedObjects);
            }
            if (null !== $this->collLoansRelatedByItemId) {
                $result['LoansRelatedByItemId'] = $this->collLoansRelatedByItemId->toArray(null, true, $keyType, $includeLazyLoadColumns, $alreadyDumpedObjects);
            }
            if (null !== $this->collLAuthorityItems) {
                $result['LAuthorityItems'] = $this->collLAuthorityItems->toArray(null, true, $keyType, $includeLazyLoadColumns, $alreadyDumpedObjects);
            }
            if (null !== $this->collPurchaseProposals) {
                $result['PurchaseProposals'] = $this->collPurchaseProposals->toArray(null, true, $keyType, $includeLazyLoadColumns, $alreadyDumpedObjects);
            }
        }

        return $result;
    }

    /**
     * Sets a field from the object by name passed in as a string.
     *
     * @param string $name peer name
     * @param mixed $value field value
     * @param string $type The type of fieldname the $name is of:
     *                     one of the class type constants BasePeer::TYPE_PHPNAME, BasePeer::TYPE_STUDLYPHPNAME
     *                     BasePeer::TYPE_COLNAME, BasePeer::TYPE_FIELDNAME, BasePeer::TYPE_NUM.
     *                     Defaults to BasePeer::TYPE_PHPNAME
     * @return void
     */
    public function setByName($name, $value, $type = BasePeer::TYPE_PHPNAME)
    {
        $pos = ItemPeer::translateFieldName($name, $type, BasePeer::TYPE_NUM);

        $this->setByPosition($pos, $value);
    }

    /**
     * Sets a field from the object by Position as specified in the xml schema.
     * Zero-based.
     *
     * @param int $pos position in xml schema
     * @param mixed $value field value
     * @return void
     */
    public function setByPosition($pos, $value)
    {
        switch ($pos) {
            case 0:
                $this->setItemId($value);
                break;
            case 1:
                $this->setTitle($value);
                break;
            case 2:
                $this->setManifestationId($value);
                break;
            case 3:
                $this->setManifestationDewey($value);
                break;
            case 4:
                $this->setItemMedia($value);
                break;
            case 5:
                $this->setItemStatus($value);
                break;
            case 6:
                $this->setItemOrderStatus($value);
                break;
            case 7:
                $this->setItemIcon($value);
                break;
            case 8:
                $this->setPhysicalStatus($value);
                break;
            case 9:
                $this->setItemSource($value);
                break;
            case 10:
                $this->setOpacVisible($value);
                break;
            case 11:
                $this->setInventorySerieId($value);
                break;
            case 12:
                $this->setInventoryNumber($value);
                break;
            case 13:
                $this->setInventoryDate($value);
                break;
            case 14:
                $this->setOwnerLibraryId($value);
                break;
            case 15:
                $this->setHomeLibraryId($value);
                break;
            case 16:
                $this->setCollocation($value);
                break;
            case 17:
                $this->setSection($value);
                break;
            case 18:
                $this->setSequence1($value);
                break;
            case 19:
                $this->setSequence2($value);
                break;
            case 20:
                $this->setSpecification($value);
                break;
            case 21:
                $this->setReprint($value);
                break;
            case 22:
                $this->setWidth($value);
                break;
            case 23:
                $this->setHeight($value);
                break;
            case 24:
                $this->setWeight($value);
                break;
            case 25:
                $this->setVolumeNumber($value);
                break;
            case 26:
                $this->setVolumeText($value);
                break;
            case 27:
                $this->setMediapackageSize($value);
                break;
            case 28:
                $this->setCurrentLoanId($value);
                break;
            case 29:
                $this->setLoanClass($value);
                break;
            case 30:
                $this->setLastSeen($value);
                break;
            case 31:
                $this->setLoanStatus($value);
                break;
            case 32:
                $this->setLoanAlert($value);
                break;
            case 33:
                $this->setLoanAlertNote($value);
                break;
            case 34:
                $this->setUsageCount($value);
                break;
            case 35:
                $this->setDeliveryLibraryId($value);
                break;
            case 36:
                $this->setDueDate($value);
                break;
            case 37:
                $this->setPatronId($value);
                break;
            case 38:
                $this->setExternalLibraryId($value);
                break;
            case 39:
                $this->setRenewalCount($value);
                break;
            case 40:
                $this->setNotifyCount($value);
                break;
            case 41:
                $this->setCheckOut($value);
                break;
            case 42:
                $this->setCheckIn($value);
                break;
            case 43:
                $this->setIllTimestamp($value);
                break;
            case 44:
                $this->setSupplierId($value);
                break;
            case 45:
                $this->setInvoiceId($value);
                break;
            case 46:
                $this->setOrderId($value);
                break;
            case 47:
                $this->setBudgetId($value);
                break;
            case 48:
                $this->setCurrency($value);
                break;
            case 49:
                $this->setCurrencyValue($value);
                break;
            case 50:
                $this->setDiscountValue($value);
                break;
            case 51:
                $this->setInventoryValue($value);
                break;
            case 52:
                $this->setIssueInventoryNumber($value);
                break;
            case 53:
                $this->setIssueId($value);
                break;
            case 54:
                $this->setIssueYear($value);
                break;
            case 55:
                $this->setIssueNumber($value);
                break;
            case 56:
                $this->setIssueDescription($value);
                break;
            case 57:
                $this->setIssueArrivalDate($value);
                break;
            case 58:
                $this->setIssueArrivalDateExpected($value);
                break;
            case 59:
                $this->setIssueStatus($value);
                break;
            case 60:
                $this->setSubscriptionId($value);
                break;
            case 61:
                $this->setConsistencyNoteId($value);
                break;
            case 62:
                $this->setActualLibraryId($value);
                break;
            case 63:
                $this->setBarcode($value);
                break;
            case 64:
                $this->setRfidCode($value);
                break;
            case 65:
                $this->setCustomField1($value);
                break;
            case 66:
                $this->setCustomField2($value);
                break;
            case 67:
                $this->setCustomField3($value);
                break;
            case 68:
                $this->setUnimarc($value);
                break;
            case 69:
                $this->setLastSbnSync($value);
                break;
            case 70:
                $this->setDateDiscarded($value);
                break;
            case 71:
                $this->setDiscardNote($value);
                break;
            case 72:
                $this->setDateCreated($value);
                break;
            case 73:
                $this->setDateUpdated($value);
                break;
            case 74:
                $this->setCreatedBy($value);
                break;
            case 75:
                $this->setModifiedBy($value);
                break;
        } // switch()
    }

    /**
     * Populates the object using an array.
     *
     * This is particularly useful when populating an object from one of the
     * request arrays (e.g. $_POST).  This method goes through the column
     * names, checking to see whether a matching key exists in populated
     * array. If so the setByName() method is called for that column.
     *
     * You can specify the key type of the array by additionally passing one
     * of the class type constants BasePeer::TYPE_PHPNAME, BasePeer::TYPE_STUDLYPHPNAME,
     * BasePeer::TYPE_COLNAME, BasePeer::TYPE_FIELDNAME, BasePeer::TYPE_NUM.
     * The default key type is the column's BasePeer::TYPE_PHPNAME
     *
     * @param array  $arr     An array to populate the object from.
     * @param string $keyType The type of keys the array uses.
     * @return void
     */
    public function fromArray($arr, $keyType = BasePeer::TYPE_PHPNAME)
    {
        $keys = ItemPeer::getFieldNames($keyType);

        if (array_key_exists($keys[0], $arr)) $this->setItemId($arr[$keys[0]]);
        if (array_key_exists($keys[1], $arr)) $this->setTitle($arr[$keys[1]]);
        if (array_key_exists($keys[2], $arr)) $this->setManifestationId($arr[$keys[2]]);
        if (array_key_exists($keys[3], $arr)) $this->setManifestationDewey($arr[$keys[3]]);
        if (array_key_exists($keys[4], $arr)) $this->setItemMedia($arr[$keys[4]]);
        if (array_key_exists($keys[5], $arr)) $this->setItemStatus($arr[$keys[5]]);
        if (array_key_exists($keys[6], $arr)) $this->setItemOrderStatus($arr[$keys[6]]);
        if (array_key_exists($keys[7], $arr)) $this->setItemIcon($arr[$keys[7]]);
        if (array_key_exists($keys[8], $arr)) $this->setPhysicalStatus($arr[$keys[8]]);
        if (array_key_exists($keys[9], $arr)) $this->setItemSource($arr[$keys[9]]);
        if (array_key_exists($keys[10], $arr)) $this->setOpacVisible($arr[$keys[10]]);
        if (array_key_exists($keys[11], $arr)) $this->setInventorySerieId($arr[$keys[11]]);
        if (array_key_exists($keys[12], $arr)) $this->setInventoryNumber($arr[$keys[12]]);
        if (array_key_exists($keys[13], $arr)) $this->setInventoryDate($arr[$keys[13]]);
        if (array_key_exists($keys[14], $arr)) $this->setOwnerLibraryId($arr[$keys[14]]);
        if (array_key_exists($keys[15], $arr)) $this->setHomeLibraryId($arr[$keys[15]]);
        if (array_key_exists($keys[16], $arr)) $this->setCollocation($arr[$keys[16]]);
        if (array_key_exists($keys[17], $arr)) $this->setSection($arr[$keys[17]]);
        if (array_key_exists($keys[18], $arr)) $this->setSequence1($arr[$keys[18]]);
        if (array_key_exists($keys[19], $arr)) $this->setSequence2($arr[$keys[19]]);
        if (array_key_exists($keys[20], $arr)) $this->setSpecification($arr[$keys[20]]);
        if (array_key_exists($keys[21], $arr)) $this->setReprint($arr[$keys[21]]);
        if (array_key_exists($keys[22], $arr)) $this->setWidth($arr[$keys[22]]);
        if (array_key_exists($keys[23], $arr)) $this->setHeight($arr[$keys[23]]);
        if (array_key_exists($keys[24], $arr)) $this->setWeight($arr[$keys[24]]);
        if (array_key_exists($keys[25], $arr)) $this->setVolumeNumber($arr[$keys[25]]);
        if (array_key_exists($keys[26], $arr)) $this->setVolumeText($arr[$keys[26]]);
        if (array_key_exists($keys[27], $arr)) $this->setMediapackageSize($arr[$keys[27]]);
        if (array_key_exists($keys[28], $arr)) $this->setCurrentLoanId($arr[$keys[28]]);
        if (array_key_exists($keys[29], $arr)) $this->setLoanClass($arr[$keys[29]]);
        if (array_key_exists($keys[30], $arr)) $this->setLastSeen($arr[$keys[30]]);
        if (array_key_exists($keys[31], $arr)) $this->setLoanStatus($arr[$keys[31]]);
        if (array_key_exists($keys[32], $arr)) $this->setLoanAlert($arr[$keys[32]]);
        if (array_key_exists($keys[33], $arr)) $this->setLoanAlertNote($arr[$keys[33]]);
        if (array_key_exists($keys[34], $arr)) $this->setUsageCount($arr[$keys[34]]);
        if (array_key_exists($keys[35], $arr)) $this->setDeliveryLibraryId($arr[$keys[35]]);
        if (array_key_exists($keys[36], $arr)) $this->setDueDate($arr[$keys[36]]);
        if (array_key_exists($keys[37], $arr)) $this->setPatronId($arr[$keys[37]]);
        if (array_key_exists($keys[38], $arr)) $this->setExternalLibraryId($arr[$keys[38]]);
        if (array_key_exists($keys[39], $arr)) $this->setRenewalCount($arr[$keys[39]]);
        if (array_key_exists($keys[40], $arr)) $this->setNotifyCount($arr[$keys[40]]);
        if (array_key_exists($keys[41], $arr)) $this->setCheckOut($arr[$keys[41]]);
        if (array_key_exists($keys[42], $arr)) $this->setCheckIn($arr[$keys[42]]);
        if (array_key_exists($keys[43], $arr)) $this->setIllTimestamp($arr[$keys[43]]);
        if (array_key_exists($keys[44], $arr)) $this->setSupplierId($arr[$keys[44]]);
        if (array_key_exists($keys[45], $arr)) $this->setInvoiceId($arr[$keys[45]]);
        if (array_key_exists($keys[46], $arr)) $this->setOrderId($arr[$keys[46]]);
        if (array_key_exists($keys[47], $arr)) $this->setBudgetId($arr[$keys[47]]);
        if (array_key_exists($keys[48], $arr)) $this->setCurrency($arr[$keys[48]]);
        if (array_key_exists($keys[49], $arr)) $this->setCurrencyValue($arr[$keys[49]]);
        if (array_key_exists($keys[50], $arr)) $this->setDiscountValue($arr[$keys[50]]);
        if (array_key_exists($keys[51], $arr)) $this->setInventoryValue($arr[$keys[51]]);
        if (array_key_exists($keys[52], $arr)) $this->setIssueInventoryNumber($arr[$keys[52]]);
        if (array_key_exists($keys[53], $arr)) $this->setIssueId($arr[$keys[53]]);
        if (array_key_exists($keys[54], $arr)) $this->setIssueYear($arr[$keys[54]]);
        if (array_key_exists($keys[55], $arr)) $this->setIssueNumber($arr[$keys[55]]);
        if (array_key_exists($keys[56], $arr)) $this->setIssueDescription($arr[$keys[56]]);
        if (array_key_exists($keys[57], $arr)) $this->setIssueArrivalDate($arr[$keys[57]]);
        if (array_key_exists($keys[58], $arr)) $this->setIssueArrivalDateExpected($arr[$keys[58]]);
        if (array_key_exists($keys[59], $arr)) $this->setIssueStatus($arr[$keys[59]]);
        if (array_key_exists($keys[60], $arr)) $this->setSubscriptionId($arr[$keys[60]]);
        if (array_key_exists($keys[61], $arr)) $this->setConsistencyNoteId($arr[$keys[61]]);
        if (array_key_exists($keys[62], $arr)) $this->setActualLibraryId($arr[$keys[62]]);
        if (array_key_exists($keys[63], $arr)) $this->setBarcode($arr[$keys[63]]);
        if (array_key_exists($keys[64], $arr)) $this->setRfidCode($arr[$keys[64]]);
        if (array_key_exists($keys[65], $arr)) $this->setCustomField1($arr[$keys[65]]);
        if (array_key_exists($keys[66], $arr)) $this->setCustomField2($arr[$keys[66]]);
        if (array_key_exists($keys[67], $arr)) $this->setCustomField3($arr[$keys[67]]);
        if (array_key_exists($keys[68], $arr)) $this->setUnimarc($arr[$keys[68]]);
        if (array_key_exists($keys[69], $arr)) $this->setLastSbnSync($arr[$keys[69]]);
        if (array_key_exists($keys[70], $arr)) $this->setDateDiscarded($arr[$keys[70]]);
        if (array_key_exists($keys[71], $arr)) $this->setDiscardNote($arr[$keys[71]]);
        if (array_key_exists($keys[72], $arr)) $this->setDateCreated($arr[$keys[72]]);
        if (array_key_exists($keys[73], $arr)) $this->setDateUpdated($arr[$keys[73]]);
        if (array_key_exists($keys[74], $arr)) $this->setCreatedBy($arr[$keys[74]]);
        if (array_key_exists($keys[75], $arr)) $this->setModifiedBy($arr[$keys[75]]);
    }

    /**
     * Build a Criteria object containing the values of all modified columns in this object.
     *
     * @return Criteria The Criteria object containing all modified values.
     */
    public function buildCriteria()
    {
        $criteria = new Criteria(ItemPeer::DATABASE_NAME);

        if ($this->isColumnModified(ItemPeer::ITEM_ID)) $criteria->add(ItemPeer::ITEM_ID, $this->item_id);
        if ($this->isColumnModified(ItemPeer::TITLE)) $criteria->add(ItemPeer::TITLE, $this->title);
        if ($this->isColumnModified(ItemPeer::MANIFESTATION_ID)) $criteria->add(ItemPeer::MANIFESTATION_ID, $this->manifestation_id);
        if ($this->isColumnModified(ItemPeer::MANIFESTATION_DEWEY)) $criteria->add(ItemPeer::MANIFESTATION_DEWEY, $this->manifestation_dewey);
        if ($this->isColumnModified(ItemPeer::ITEM_MEDIA)) $criteria->add(ItemPeer::ITEM_MEDIA, $this->item_media);
        if ($this->isColumnModified(ItemPeer::ITEM_STATUS)) $criteria->add(ItemPeer::ITEM_STATUS, $this->item_status);
        if ($this->isColumnModified(ItemPeer::ITEM_ORDER_STATUS)) $criteria->add(ItemPeer::ITEM_ORDER_STATUS, $this->item_order_status);
        if ($this->isColumnModified(ItemPeer::ITEM_ICON)) $criteria->add(ItemPeer::ITEM_ICON, $this->item_icon);
        if ($this->isColumnModified(ItemPeer::PHYSICAL_STATUS)) $criteria->add(ItemPeer::PHYSICAL_STATUS, $this->physical_status);
        if ($this->isColumnModified(ItemPeer::ITEM_SOURCE)) $criteria->add(ItemPeer::ITEM_SOURCE, $this->item_source);
        if ($this->isColumnModified(ItemPeer::OPAC_VISIBLE)) $criteria->add(ItemPeer::OPAC_VISIBLE, $this->opac_visible);
        if ($this->isColumnModified(ItemPeer::INVENTORY_SERIE_ID)) $criteria->add(ItemPeer::INVENTORY_SERIE_ID, $this->inventory_serie_id);
        if ($this->isColumnModified(ItemPeer::INVENTORY_NUMBER)) $criteria->add(ItemPeer::INVENTORY_NUMBER, $this->inventory_number);
        if ($this->isColumnModified(ItemPeer::INVENTORY_DATE)) $criteria->add(ItemPeer::INVENTORY_DATE, $this->inventory_date);
        if ($this->isColumnModified(ItemPeer::OWNER_LIBRARY_ID)) $criteria->add(ItemPeer::OWNER_LIBRARY_ID, $this->owner_library_id);
        if ($this->isColumnModified(ItemPeer::HOME_LIBRARY_ID)) $criteria->add(ItemPeer::HOME_LIBRARY_ID, $this->home_library_id);
        if ($this->isColumnModified(ItemPeer::COLLOCATION)) $criteria->add(ItemPeer::COLLOCATION, $this->collocation);
        if ($this->isColumnModified(ItemPeer::SECTION)) $criteria->add(ItemPeer::SECTION, $this->section);
        if ($this->isColumnModified(ItemPeer::SEQUENCE1)) $criteria->add(ItemPeer::SEQUENCE1, $this->sequence1);
        if ($this->isColumnModified(ItemPeer::SEQUENCE2)) $criteria->add(ItemPeer::SEQUENCE2, $this->sequence2);
        if ($this->isColumnModified(ItemPeer::SPECIFICATION)) $criteria->add(ItemPeer::SPECIFICATION, $this->specification);
        if ($this->isColumnModified(ItemPeer::REPRINT)) $criteria->add(ItemPeer::REPRINT, $this->reprint);
        if ($this->isColumnModified(ItemPeer::WIDTH)) $criteria->add(ItemPeer::WIDTH, $this->width);
        if ($this->isColumnModified(ItemPeer::HEIGHT)) $criteria->add(ItemPeer::HEIGHT, $this->height);
        if ($this->isColumnModified(ItemPeer::WEIGHT)) $criteria->add(ItemPeer::WEIGHT, $this->weight);
        if ($this->isColumnModified(ItemPeer::VOLUME_NUMBER)) $criteria->add(ItemPeer::VOLUME_NUMBER, $this->volume_number);
        if ($this->isColumnModified(ItemPeer::VOLUME_TEXT)) $criteria->add(ItemPeer::VOLUME_TEXT, $this->volume_text);
        if ($this->isColumnModified(ItemPeer::MEDIAPACKAGE_SIZE)) $criteria->add(ItemPeer::MEDIAPACKAGE_SIZE, $this->mediapackage_size);
        if ($this->isColumnModified(ItemPeer::CURRENT_LOAN_ID)) $criteria->add(ItemPeer::CURRENT_LOAN_ID, $this->current_loan_id);
        if ($this->isColumnModified(ItemPeer::LOAN_CLASS)) $criteria->add(ItemPeer::LOAN_CLASS, $this->loan_class);
        if ($this->isColumnModified(ItemPeer::LAST_SEEN)) $criteria->add(ItemPeer::LAST_SEEN, $this->last_seen);
        if ($this->isColumnModified(ItemPeer::LOAN_STATUS)) $criteria->add(ItemPeer::LOAN_STATUS, $this->loan_status);
        if ($this->isColumnModified(ItemPeer::LOAN_ALERT)) $criteria->add(ItemPeer::LOAN_ALERT, $this->loan_alert);
        if ($this->isColumnModified(ItemPeer::LOAN_ALERT_NOTE)) $criteria->add(ItemPeer::LOAN_ALERT_NOTE, $this->loan_alert_note);
        if ($this->isColumnModified(ItemPeer::USAGE_COUNT)) $criteria->add(ItemPeer::USAGE_COUNT, $this->usage_count);
        if ($this->isColumnModified(ItemPeer::DELIVERY_LIBRARY_ID)) $criteria->add(ItemPeer::DELIVERY_LIBRARY_ID, $this->delivery_library_id);
        if ($this->isColumnModified(ItemPeer::DUE_DATE)) $criteria->add(ItemPeer::DUE_DATE, $this->due_date);
        if ($this->isColumnModified(ItemPeer::PATRON_ID)) $criteria->add(ItemPeer::PATRON_ID, $this->patron_id);
        if ($this->isColumnModified(ItemPeer::EXTERNAL_LIBRARY_ID)) $criteria->add(ItemPeer::EXTERNAL_LIBRARY_ID, $this->external_library_id);
        if ($this->isColumnModified(ItemPeer::RENEWAL_COUNT)) $criteria->add(ItemPeer::RENEWAL_COUNT, $this->renewal_count);
        if ($this->isColumnModified(ItemPeer::NOTIFY_COUNT)) $criteria->add(ItemPeer::NOTIFY_COUNT, $this->notify_count);
        if ($this->isColumnModified(ItemPeer::CHECK_OUT)) $criteria->add(ItemPeer::CHECK_OUT, $this->check_out);
        if ($this->isColumnModified(ItemPeer::CHECK_IN)) $criteria->add(ItemPeer::CHECK_IN, $this->check_in);
        if ($this->isColumnModified(ItemPeer::ILL_TIMESTAMP)) $criteria->add(ItemPeer::ILL_TIMESTAMP, $this->ill_timestamp);
        if ($this->isColumnModified(ItemPeer::SUPPLIER_ID)) $criteria->add(ItemPeer::SUPPLIER_ID, $this->supplier_id);
        if ($this->isColumnModified(ItemPeer::INVOICE_ID)) $criteria->add(ItemPeer::INVOICE_ID, $this->invoice_id);
        if ($this->isColumnModified(ItemPeer::ORDER_ID)) $criteria->add(ItemPeer::ORDER_ID, $this->order_id);
        if ($this->isColumnModified(ItemPeer::BUDGET_ID)) $criteria->add(ItemPeer::BUDGET_ID, $this->budget_id);
        if ($this->isColumnModified(ItemPeer::CURRENCY)) $criteria->add(ItemPeer::CURRENCY, $this->currency);
        if ($this->isColumnModified(ItemPeer::CURRENCY_VALUE)) $criteria->add(ItemPeer::CURRENCY_VALUE, $this->currency_value);
        if ($this->isColumnModified(ItemPeer::DISCOUNT_VALUE)) $criteria->add(ItemPeer::DISCOUNT_VALUE, $this->discount_value);
        if ($this->isColumnModified(ItemPeer::INVENTORY_VALUE)) $criteria->add(ItemPeer::INVENTORY_VALUE, $this->inventory_value);
        if ($this->isColumnModified(ItemPeer::ISSUE_INVENTORY_NUMBER)) $criteria->add(ItemPeer::ISSUE_INVENTORY_NUMBER, $this->issue_inventory_number);
        if ($this->isColumnModified(ItemPeer::ISSUE_ID)) $criteria->add(ItemPeer::ISSUE_ID, $this->issue_id);
        if ($this->isColumnModified(ItemPeer::ISSUE_YEAR)) $criteria->add(ItemPeer::ISSUE_YEAR, $this->issue_year);
        if ($this->isColumnModified(ItemPeer::ISSUE_NUMBER)) $criteria->add(ItemPeer::ISSUE_NUMBER, $this->issue_number);
        if ($this->isColumnModified(ItemPeer::ISSUE_DESCRIPTION)) $criteria->add(ItemPeer::ISSUE_DESCRIPTION, $this->issue_description);
        if ($this->isColumnModified(ItemPeer::ISSUE_ARRIVAL_DATE)) $criteria->add(ItemPeer::ISSUE_ARRIVAL_DATE, $this->issue_arrival_date);
        if ($this->isColumnModified(ItemPeer::ISSUE_ARRIVAL_DATE_EXPECTED)) $criteria->add(ItemPeer::ISSUE_ARRIVAL_DATE_EXPECTED, $this->issue_arrival_date_expected);
        if ($this->isColumnModified(ItemPeer::ISSUE_STATUS)) $criteria->add(ItemPeer::ISSUE_STATUS, $this->issue_status);
        if ($this->isColumnModified(ItemPeer::SUBSCRIPTION_ID)) $criteria->add(ItemPeer::SUBSCRIPTION_ID, $this->subscription_id);
        if ($this->isColumnModified(ItemPeer::CONSISTENCY_NOTE_ID)) $criteria->add(ItemPeer::CONSISTENCY_NOTE_ID, $this->consistency_note_id);
        if ($this->isColumnModified(ItemPeer::ACTUAL_LIBRARY_ID)) $criteria->add(ItemPeer::ACTUAL_LIBRARY_ID, $this->actual_library_id);
        if ($this->isColumnModified(ItemPeer::BARCODE)) $criteria->add(ItemPeer::BARCODE, $this->barcode);
        if ($this->isColumnModified(ItemPeer::RFID_CODE)) $criteria->add(ItemPeer::RFID_CODE, $this->rfid_code);
        if ($this->isColumnModified(ItemPeer::CUSTOM_FIELD1)) $criteria->add(ItemPeer::CUSTOM_FIELD1, $this->custom_field1);
        if ($this->isColumnModified(ItemPeer::CUSTOM_FIELD2)) $criteria->add(ItemPeer::CUSTOM_FIELD2, $this->custom_field2);
        if ($this->isColumnModified(ItemPeer::CUSTOM_FIELD3)) $criteria->add(ItemPeer::CUSTOM_FIELD3, $this->custom_field3);
        if ($this->isColumnModified(ItemPeer::UNIMARC)) $criteria->add(ItemPeer::UNIMARC, $this->unimarc);
        if ($this->isColumnModified(ItemPeer::LAST_SBN_SYNC)) $criteria->add(ItemPeer::LAST_SBN_SYNC, $this->last_sbn_sync);
        if ($this->isColumnModified(ItemPeer::DATE_DISCARDED)) $criteria->add(ItemPeer::DATE_DISCARDED, $this->date_discarded);
        if ($this->isColumnModified(ItemPeer::DISCARD_NOTE)) $criteria->add(ItemPeer::DISCARD_NOTE, $this->discard_note);
        if ($this->isColumnModified(ItemPeer::DATE_CREATED)) $criteria->add(ItemPeer::DATE_CREATED, $this->date_created);
        if ($this->isColumnModified(ItemPeer::DATE_UPDATED)) $criteria->add(ItemPeer::DATE_UPDATED, $this->date_updated);
        if ($this->isColumnModified(ItemPeer::CREATED_BY)) $criteria->add(ItemPeer::CREATED_BY, $this->created_by);
        if ($this->isColumnModified(ItemPeer::MODIFIED_BY)) $criteria->add(ItemPeer::MODIFIED_BY, $this->modified_by);

        return $criteria;
    }

    /**
     * Builds a Criteria object containing the primary key for this object.
     *
     * Unlike buildCriteria() this method includes the primary key values regardless
     * of whether or not they have been modified.
     *
     * @return Criteria The Criteria object containing value(s) for primary key(s).
     */
    public function buildPkeyCriteria()
    {
        $criteria = new Criteria(ItemPeer::DATABASE_NAME);
        $criteria->add(ItemPeer::ITEM_ID, $this->item_id);

        return $criteria;
    }

    /**
     * Returns the primary key for this object (row).
     * @return int
     */
    public function getPrimaryKey()
    {
        return $this->getItemId();
    }

    /**
     * Generic method to set the primary key (item_id column).
     *
     * @param  int $key Primary key.
     * @return void
     */
    public function setPrimaryKey($key)
    {
        $this->setItemId($key);
    }

    /**
     * Returns true if the primary key for this object is null.
     * @return boolean
     */
    public function isPrimaryKeyNull()
    {

        return null === $this->getItemId();
    }

    /**
     * Sets contents of passed object to values from current object.
     *
     * If desired, this method can also make copies of all associated (fkey referrers)
     * objects.
     *
     * @param object $copyObj An object of Item (or compatible) type.
     * @param boolean $deepCopy Whether to also copy all rows that refer (by fkey) to the current row.
     * @param boolean $makeNew Whether to reset autoincrement PKs and make the object new.
     * @throws PropelException
     */
    public function copyInto($copyObj, $deepCopy = false, $makeNew = true)
    {
        $copyObj->setTitle($this->getTitle());
        $copyObj->setManifestationId($this->getManifestationId());
        $copyObj->setManifestationDewey($this->getManifestationDewey());
        $copyObj->setItemMedia($this->getItemMedia());
        $copyObj->setItemStatus($this->getItemStatus());
        $copyObj->setItemOrderStatus($this->getItemOrderStatus());
        $copyObj->setItemIcon($this->getItemIcon());
        $copyObj->setPhysicalStatus($this->getPhysicalStatus());
        $copyObj->setItemSource($this->getItemSource());
        $copyObj->setOpacVisible($this->getOpacVisible());
        $copyObj->setInventorySerieId($this->getInventorySerieId());
        $copyObj->setInventoryNumber($this->getInventoryNumber());
        $copyObj->setInventoryDate($this->getInventoryDate());
        $copyObj->setOwnerLibraryId($this->getOwnerLibraryId());
        $copyObj->setHomeLibraryId($this->getHomeLibraryId());
        $copyObj->setCollocation($this->getCollocation());
        $copyObj->setSection($this->getSection());
        $copyObj->setSequence1($this->getSequence1());
        $copyObj->setSequence2($this->getSequence2());
        $copyObj->setSpecification($this->getSpecification());
        $copyObj->setReprint($this->getReprint());
        $copyObj->setWidth($this->getWidth());
        $copyObj->setHeight($this->getHeight());
        $copyObj->setWeight($this->getWeight());
        $copyObj->setVolumeNumber($this->getVolumeNumber());
        $copyObj->setVolumeText($this->getVolumeText());
        $copyObj->setMediapackageSize($this->getMediapackageSize());
        $copyObj->setCurrentLoanId($this->getCurrentLoanId());
        $copyObj->setLoanClass($this->getLoanClass());
        $copyObj->setLastSeen($this->getLastSeen());
        $copyObj->setLoanStatus($this->getLoanStatus());
        $copyObj->setLoanAlert($this->getLoanAlert());
        $copyObj->setLoanAlertNote($this->getLoanAlertNote());
        $copyObj->setUsageCount($this->getUsageCount());
        $copyObj->setDeliveryLibraryId($this->getDeliveryLibraryId());
        $copyObj->setDueDate($this->getDueDate());
        $copyObj->setPatronId($this->getPatronId());
        $copyObj->setExternalLibraryId($this->getExternalLibraryId());
        $copyObj->setRenewalCount($this->getRenewalCount());
        $copyObj->setNotifyCount($this->getNotifyCount());
        $copyObj->setCheckOut($this->getCheckOut());
        $copyObj->setCheckIn($this->getCheckIn());
        $copyObj->setIllTimestamp($this->getIllTimestamp());
        $copyObj->setSupplierId($this->getSupplierId());
        $copyObj->setInvoiceId($this->getInvoiceId());
        $copyObj->setOrderId($this->getOrderId());
        $copyObj->setBudgetId($this->getBudgetId());
        $copyObj->setCurrency($this->getCurrency());
        $copyObj->setCurrencyValue($this->getCurrencyValue());
        $copyObj->setDiscountValue($this->getDiscountValue());
        $copyObj->setInventoryValue($this->getInventoryValue());
        $copyObj->setIssueInventoryNumber($this->getIssueInventoryNumber());
        $copyObj->setIssueId($this->getIssueId());
        $copyObj->setIssueYear($this->getIssueYear());
        $copyObj->setIssueNumber($this->getIssueNumber());
        $copyObj->setIssueDescription($this->getIssueDescription());
        $copyObj->setIssueArrivalDate($this->getIssueArrivalDate());
        $copyObj->setIssueArrivalDateExpected($this->getIssueArrivalDateExpected());
        $copyObj->setIssueStatus($this->getIssueStatus());
        $copyObj->setSubscriptionId($this->getSubscriptionId());
        $copyObj->setConsistencyNoteId($this->getConsistencyNoteId());
        $copyObj->setActualLibraryId($this->getActualLibraryId());
        $copyObj->setBarcode($this->getBarcode());
        $copyObj->setRfidCode($this->getRfidCode());
        $copyObj->setCustomField1($this->getCustomField1());
        $copyObj->setCustomField2($this->getCustomField2());
        $copyObj->setCustomField3($this->getCustomField3());
        $copyObj->setUnimarc($this->getUnimarc());
        $copyObj->setLastSbnSync($this->getLastSbnSync());
        $copyObj->setDateDiscarded($this->getDateDiscarded());
        $copyObj->setDiscardNote($this->getDiscardNote());
        $copyObj->setDateCreated($this->getDateCreated());
        $copyObj->setDateUpdated($this->getDateUpdated());
        $copyObj->setCreatedBy($this->getCreatedBy());
        $copyObj->setModifiedBy($this->getModifiedBy());

        if ($deepCopy && !$this->startCopy) {
            // important: temporarily setNew(false) because this affects the behavior of
            // the getter/setter methods for fkey referrer objects.
            $copyObj->setNew(false);
            // store object hash to prevent cycle
            $this->startCopy = true;

            foreach ($this->getItemActions() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addItemAction($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getItemNotes() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addItemNote($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getItemRequests() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addItemRequest($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getLoansRelatedByItemId() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addLoanRelatedByItemId($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getLAuthorityItems() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addLAuthorityItem($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getPurchaseProposals() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addPurchaseProposal($relObj->copy($deepCopy));
                }
            }

            //unflag object copy
            $this->startCopy = false;
        } // if ($deepCopy)

        if ($makeNew) {
            $copyObj->setNew(true);
            $copyObj->setItemId(NULL); // this is a auto-increment column, so set to default value
        }
    }

    /**
     * Makes a copy of this object that will be inserted as a new row in table when saved.
     * It creates a new object filling in the simple attributes, but skipping any primary
     * keys that are defined for the table.
     *
     * If desired, this method can also make copies of all associated (fkey referrers)
     * objects.
     *
     * @param boolean $deepCopy Whether to also copy all rows that refer (by fkey) to the current row.
     * @return Item Clone of current object.
     * @throws PropelException
     */
    public function copy($deepCopy = false)
    {
        // we use get_class(), because this might be a subclass
        $clazz = get_class($this);
        $copyObj = new $clazz();
        $this->copyInto($copyObj, $deepCopy);

        return $copyObj;
    }

    /**
     * Returns a peer instance associated with this om.
     *
     * Since Peer classes are not to have any instance attributes, this method returns the
     * same instance for all member of this class. The method could therefore
     * be static, but this would prevent one from overriding the behavior.
     *
     * @return ItemPeer
     */
    public function getPeer()
    {
        if (self::$peer === null) {
            self::$peer = new ItemPeer();
        }

        return self::$peer;
    }

    /**
     * Declares an association between this object and a Librarian object.
     *
     * @param                  Librarian $v
     * @return Item The current object (for fluent API support)
     * @throws PropelException
     */
    public function setLibrarianRelatedByCreatedBy(Librarian $v = null)
    {
        if ($v === null) {
            $this->setCreatedBy(NULL);
        } else {
            $this->setCreatedBy($v->getLibrarianId());
        }

        $this->aLibrarianRelatedByCreatedBy = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the Librarian object, it will not be re-added.
        if ($v !== null) {
            $v->addItemRelatedByCreatedBy($this);
        }


        return $this;
    }


    /**
     * Get the associated Librarian object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return Librarian The associated Librarian object.
     * @throws PropelException
     */
    public function getLibrarianRelatedByCreatedBy(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aLibrarianRelatedByCreatedBy === null && ($this->created_by !== null) && $doQuery) {
            $this->aLibrarianRelatedByCreatedBy = LibrarianQuery::create()->findPk($this->created_by, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aLibrarianRelatedByCreatedBy->addItemsRelatedByCreatedBy($this);
             */
        }

        return $this->aLibrarianRelatedByCreatedBy;
    }

    /**
     * Declares an association between this object and a Librarian object.
     *
     * @param                  Librarian $v
     * @return Item The current object (for fluent API support)
     * @throws PropelException
     */
    public function setLibrarianRelatedByModifiedBy(Librarian $v = null)
    {
        if ($v === null) {
            $this->setModifiedBy(NULL);
        } else {
            $this->setModifiedBy($v->getLibrarianId());
        }

        $this->aLibrarianRelatedByModifiedBy = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the Librarian object, it will not be re-added.
        if ($v !== null) {
            $v->addItemRelatedByModifiedBy($this);
        }


        return $this;
    }


    /**
     * Get the associated Librarian object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return Librarian The associated Librarian object.
     * @throws PropelException
     */
    public function getLibrarianRelatedByModifiedBy(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aLibrarianRelatedByModifiedBy === null && ($this->modified_by !== null) && $doQuery) {
            $this->aLibrarianRelatedByModifiedBy = LibrarianQuery::create()->findPk($this->modified_by, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aLibrarianRelatedByModifiedBy->addItemsRelatedByModifiedBy($this);
             */
        }

        return $this->aLibrarianRelatedByModifiedBy;
    }

    /**
     * Declares an association between this object and a Issue object.
     *
     * @param                  Issue $v
     * @return Item The current object (for fluent API support)
     * @throws PropelException
     */
    public function setIssue(Issue $v = null)
    {
        if ($v === null) {
            $this->setIssueId(NULL);
        } else {
            $this->setIssueId($v->getIssueId());
        }

        $this->aIssue = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the Issue object, it will not be re-added.
        if ($v !== null) {
            $v->addItem($this);
        }


        return $this;
    }


    /**
     * Get the associated Issue object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return Issue The associated Issue object.
     * @throws PropelException
     */
    public function getIssue(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aIssue === null && ($this->issue_id !== null) && $doQuery) {
            $this->aIssue = IssueQuery::create()->findPk($this->issue_id, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aIssue->addItems($this);
             */
        }

        return $this->aIssue;
    }

    /**
     * Declares an association between this object and a Manifestation object.
     *
     * @param                  Manifestation $v
     * @return Item The current object (for fluent API support)
     * @throws PropelException
     */
    public function setManifestation(Manifestation $v = null)
    {
        if ($v === null) {
            $this->setManifestationId(NULL);
        } else {
            $this->setManifestationId($v->getManifestationId());
        }

        $this->aManifestation = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the Manifestation object, it will not be re-added.
        if ($v !== null) {
            $v->addItem($this);
        }


        return $this;
    }


    /**
     * Get the associated Manifestation object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return Manifestation The associated Manifestation object.
     * @throws PropelException
     */
    public function getManifestation(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aManifestation === null && ($this->manifestation_id !== null) && $doQuery) {
            $this->aManifestation = ManifestationQuery::create()->findPk($this->manifestation_id, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aManifestation->addItems($this);
             */
        }

        return $this->aManifestation;
    }

    /**
     * Declares an association between this object and a ConsistencyNote object.
     *
     * @param                  ConsistencyNote $v
     * @return Item The current object (for fluent API support)
     * @throws PropelException
     */
    public function setConsistencyNote(ConsistencyNote $v = null)
    {
        if ($v === null) {
            $this->setConsistencyNoteId(NULL);
        } else {
            $this->setConsistencyNoteId($v->getConsistencyNoteId());
        }

        $this->aConsistencyNote = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the ConsistencyNote object, it will not be re-added.
        if ($v !== null) {
            $v->addItem($this);
        }


        return $this;
    }


    /**
     * Get the associated ConsistencyNote object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return ConsistencyNote The associated ConsistencyNote object.
     * @throws PropelException
     */
    public function getConsistencyNote(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aConsistencyNote === null && ($this->consistency_note_id !== null) && $doQuery) {
            $this->aConsistencyNote = ConsistencyNoteQuery::create()->findPk($this->consistency_note_id, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aConsistencyNote->addItems($this);
             */
        }

        return $this->aConsistencyNote;
    }

    /**
     * Declares an association between this object and a Library object.
     *
     * @param                  Library $v
     * @return Item The current object (for fluent API support)
     * @throws PropelException
     */
    public function setLibraryRelatedByOwnerLibraryId(Library $v = null)
    {
        if ($v === null) {
            $this->setOwnerLibraryId(NULL);
        } else {
            $this->setOwnerLibraryId($v->getLibraryId());
        }

        $this->aLibraryRelatedByOwnerLibraryId = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the Library object, it will not be re-added.
        if ($v !== null) {
            $v->addItemRelatedByOwnerLibraryId($this);
        }


        return $this;
    }


    /**
     * Get the associated Library object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return Library The associated Library object.
     * @throws PropelException
     */
    public function getLibraryRelatedByOwnerLibraryId(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aLibraryRelatedByOwnerLibraryId === null && ($this->owner_library_id !== null) && $doQuery) {
            $this->aLibraryRelatedByOwnerLibraryId = LibraryQuery::create()->findPk($this->owner_library_id, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aLibraryRelatedByOwnerLibraryId->addItemsRelatedByOwnerLibraryId($this);
             */
        }

        return $this->aLibraryRelatedByOwnerLibraryId;
    }

    /**
     * Declares an association between this object and a Library object.
     *
     * @param                  Library $v
     * @return Item The current object (for fluent API support)
     * @throws PropelException
     */
    public function setLibraryRelatedByHomeLibraryId(Library $v = null)
    {
        if ($v === null) {
            $this->setHomeLibraryId(NULL);
        } else {
            $this->setHomeLibraryId($v->getLibraryId());
        }

        $this->aLibraryRelatedByHomeLibraryId = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the Library object, it will not be re-added.
        if ($v !== null) {
            $v->addItemRelatedByHomeLibraryId($this);
        }


        return $this;
    }


    /**
     * Get the associated Library object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return Library The associated Library object.
     * @throws PropelException
     */
    public function getLibraryRelatedByHomeLibraryId(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aLibraryRelatedByHomeLibraryId === null && ($this->home_library_id !== null) && $doQuery) {
            $this->aLibraryRelatedByHomeLibraryId = LibraryQuery::create()->findPk($this->home_library_id, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aLibraryRelatedByHomeLibraryId->addItemsRelatedByHomeLibraryId($this);
             */
        }

        return $this->aLibraryRelatedByHomeLibraryId;
    }

    /**
     * Declares an association between this object and a Library object.
     *
     * @param                  Library $v
     * @return Item The current object (for fluent API support)
     * @throws PropelException
     */
    public function setLibraryRelatedByDeliveryLibraryId(Library $v = null)
    {
        if ($v === null) {
            $this->setDeliveryLibraryId(NULL);
        } else {
            $this->setDeliveryLibraryId($v->getLibraryId());
        }

        $this->aLibraryRelatedByDeliveryLibraryId = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the Library object, it will not be re-added.
        if ($v !== null) {
            $v->addItemRelatedByDeliveryLibraryId($this);
        }


        return $this;
    }


    /**
     * Get the associated Library object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return Library The associated Library object.
     * @throws PropelException
     */
    public function getLibraryRelatedByDeliveryLibraryId(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aLibraryRelatedByDeliveryLibraryId === null && ($this->delivery_library_id !== null) && $doQuery) {
            $this->aLibraryRelatedByDeliveryLibraryId = LibraryQuery::create()->findPk($this->delivery_library_id, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aLibraryRelatedByDeliveryLibraryId->addItemsRelatedByDeliveryLibraryId($this);
             */
        }

        return $this->aLibraryRelatedByDeliveryLibraryId;
    }

    /**
     * Declares an association between this object and a Library object.
     *
     * @param                  Library $v
     * @return Item The current object (for fluent API support)
     * @throws PropelException
     */
    public function setLibraryRelatedByActualLibraryId(Library $v = null)
    {
        if ($v === null) {
            $this->setActualLibraryId(NULL);
        } else {
            $this->setActualLibraryId($v->getLibraryId());
        }

        $this->aLibraryRelatedByActualLibraryId = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the Library object, it will not be re-added.
        if ($v !== null) {
            $v->addItemRelatedByActualLibraryId($this);
        }


        return $this;
    }


    /**
     * Get the associated Library object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return Library The associated Library object.
     * @throws PropelException
     */
    public function getLibraryRelatedByActualLibraryId(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aLibraryRelatedByActualLibraryId === null && ($this->actual_library_id !== null) && $doQuery) {
            $this->aLibraryRelatedByActualLibraryId = LibraryQuery::create()->findPk($this->actual_library_id, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aLibraryRelatedByActualLibraryId->addItemsRelatedByActualLibraryId($this);
             */
        }

        return $this->aLibraryRelatedByActualLibraryId;
    }

    /**
     * Declares an association between this object and a InventorySerie object.
     *
     * @param                  InventorySerie $v
     * @return Item The current object (for fluent API support)
     * @throws PropelException
     */
    public function setInventorySerie(InventorySerie $v = null)
    {
        if ($v === null) {
            $this->setInventorySerieId(NULL);
        } else {
            $this->setInventorySerieId($v->getInventorySerieId());
        }

        $this->aInventorySerie = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the InventorySerie object, it will not be re-added.
        if ($v !== null) {
            $v->addItem($this);
        }


        return $this;
    }


    /**
     * Get the associated InventorySerie object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return InventorySerie The associated InventorySerie object.
     * @throws PropelException
     */
    public function getInventorySerie(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aInventorySerie === null && (($this->inventory_serie_id !== "" && $this->inventory_serie_id !== null)) && $doQuery) {
            $this->aInventorySerie = InventorySerieQuery::create()
                ->filterByItem($this) // here
                ->findOne($con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aInventorySerie->addItems($this);
             */
        }

        return $this->aInventorySerie;
    }

    /**
     * Declares an association between this object and a PurchaseOrder object.
     *
     * @param                  PurchaseOrder $v
     * @return Item The current object (for fluent API support)
     * @throws PropelException
     */
    public function setPurchaseOrder(PurchaseOrder $v = null)
    {
        if ($v === null) {
            $this->setOrderId(NULL);
        } else {
            $this->setOrderId($v->getOrderId());
        }

        $this->aPurchaseOrder = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the PurchaseOrder object, it will not be re-added.
        if ($v !== null) {
            $v->addItem($this);
        }


        return $this;
    }


    /**
     * Get the associated PurchaseOrder object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return PurchaseOrder The associated PurchaseOrder object.
     * @throws PropelException
     */
    public function getPurchaseOrder(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aPurchaseOrder === null && ($this->order_id !== null) && $doQuery) {
            $this->aPurchaseOrder = PurchaseOrderQuery::create()->findPk($this->order_id, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aPurchaseOrder->addItems($this);
             */
        }

        return $this->aPurchaseOrder;
    }

    /**
     * Declares an association between this object and a Invoice object.
     *
     * @param                  Invoice $v
     * @return Item The current object (for fluent API support)
     * @throws PropelException
     */
    public function setInvoice(Invoice $v = null)
    {
        if ($v === null) {
            $this->setInvoiceId(NULL);
        } else {
            $this->setInvoiceId($v->getInvoiceId());
        }

        $this->aInvoice = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the Invoice object, it will not be re-added.
        if ($v !== null) {
            $v->addItem($this);
        }


        return $this;
    }


    /**
     * Get the associated Invoice object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return Invoice The associated Invoice object.
     * @throws PropelException
     */
    public function getInvoice(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aInvoice === null && ($this->invoice_id !== null) && $doQuery) {
            $this->aInvoice = InvoiceQuery::create()->findPk($this->invoice_id, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aInvoice->addItems($this);
             */
        }

        return $this->aInvoice;
    }

    /**
     * Declares an association between this object and a Supplier object.
     *
     * @param                  Supplier $v
     * @return Item The current object (for fluent API support)
     * @throws PropelException
     */
    public function setSupplier(Supplier $v = null)
    {
        if ($v === null) {
            $this->setSupplierId(NULL);
        } else {
            $this->setSupplierId($v->getSupplierId());
        }

        $this->aSupplier = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the Supplier object, it will not be re-added.
        if ($v !== null) {
            $v->addItem($this);
        }


        return $this;
    }


    /**
     * Get the associated Supplier object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return Supplier The associated Supplier object.
     * @throws PropelException
     */
    public function getSupplier(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aSupplier === null && ($this->supplier_id !== null) && $doQuery) {
            $this->aSupplier = SupplierQuery::create()->findPk($this->supplier_id, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aSupplier->addItems($this);
             */
        }

        return $this->aSupplier;
    }

    /**
     * Declares an association between this object and a Patron object.
     *
     * @param                  Patron $v
     * @return Item The current object (for fluent API support)
     * @throws PropelException
     */
    public function setPatron(Patron $v = null)
    {
        if ($v === null) {
            $this->setPatronId(NULL);
        } else {
            $this->setPatronId($v->getPatronId());
        }

        $this->aPatron = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the Patron object, it will not be re-added.
        if ($v !== null) {
            $v->addItem($this);
        }


        return $this;
    }


    /**
     * Get the associated Patron object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return Patron The associated Patron object.
     * @throws PropelException
     */
    public function getPatron(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aPatron === null && ($this->patron_id !== null) && $doQuery) {
            $this->aPatron = PatronQuery::create()->findPk($this->patron_id, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aPatron->addItems($this);
             */
        }

        return $this->aPatron;
    }

    /**
     * Declares an association between this object and a Library object.
     *
     * @param                  Library $v
     * @return Item The current object (for fluent API support)
     * @throws PropelException
     */
    public function setLibraryRelatedByExternalLibraryId(Library $v = null)
    {
        if ($v === null) {
            $this->setExternalLibraryId(NULL);
        } else {
            $this->setExternalLibraryId($v->getLibraryId());
        }

        $this->aLibraryRelatedByExternalLibraryId = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the Library object, it will not be re-added.
        if ($v !== null) {
            $v->addItemRelatedByExternalLibraryId($this);
        }


        return $this;
    }


    /**
     * Get the associated Library object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return Library The associated Library object.
     * @throws PropelException
     */
    public function getLibraryRelatedByExternalLibraryId(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aLibraryRelatedByExternalLibraryId === null && ($this->external_library_id !== null) && $doQuery) {
            $this->aLibraryRelatedByExternalLibraryId = LibraryQuery::create()->findPk($this->external_library_id, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aLibraryRelatedByExternalLibraryId->addItemsRelatedByExternalLibraryId($this);
             */
        }

        return $this->aLibraryRelatedByExternalLibraryId;
    }

    /**
     * Declares an association between this object and a Loan object.
     *
     * @param                  Loan $v
     * @return Item The current object (for fluent API support)
     * @throws PropelException
     */
    public function setLoanRelatedByCurrentLoanId(Loan $v = null)
    {
        if ($v === null) {
            $this->setCurrentLoanId(NULL);
        } else {
            $this->setCurrentLoanId($v->getLoanId());
        }

        $this->aLoanRelatedByCurrentLoanId = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the Loan object, it will not be re-added.
        if ($v !== null) {
            $v->addItemRelatedByCurrentLoanId($this);
        }


        return $this;
    }


    /**
     * Get the associated Loan object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return Loan The associated Loan object.
     * @throws PropelException
     */
    public function getLoanRelatedByCurrentLoanId(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aLoanRelatedByCurrentLoanId === null && ($this->current_loan_id !== null) && $doQuery) {
            $this->aLoanRelatedByCurrentLoanId = LoanQuery::create()->findPk($this->current_loan_id, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aLoanRelatedByCurrentLoanId->addItemsRelatedByCurrentLoanId($this);
             */
        }

        return $this->aLoanRelatedByCurrentLoanId;
    }

    /**
     * Declares an association between this object and a Budget object.
     *
     * @param                  Budget $v
     * @return Item The current object (for fluent API support)
     * @throws PropelException
     */
    public function setBudget(Budget $v = null)
    {
        if ($v === null) {
            $this->setBudgetId(NULL);
        } else {
            $this->setBudgetId($v->getBudgetId());
        }

        $this->aBudget = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the Budget object, it will not be re-added.
        if ($v !== null) {
            $v->addItem($this);
        }


        return $this;
    }


    /**
     * Get the associated Budget object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return Budget The associated Budget object.
     * @throws PropelException
     */
    public function getBudget(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aBudget === null && ($this->budget_id !== null) && $doQuery) {
            $this->aBudget = BudgetQuery::create()->findPk($this->budget_id, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aBudget->addItems($this);
             */
        }

        return $this->aBudget;
    }


    /**
     * Initializes a collection based on the name of a relation.
     * Avoids crafting an 'init[$relationName]s' method name
     * that wouldn't work when StandardEnglishPluralizer is used.
     *
     * @param string $relationName The name of the relation to initialize
     * @return void
     */
    public function initRelation($relationName)
    {
        if ('ItemAction' == $relationName) {
            $this->initItemActions();
        }
        if ('ItemNote' == $relationName) {
            $this->initItemNotes();
        }
        if ('ItemRequest' == $relationName) {
            $this->initItemRequests();
        }
        if ('LoanRelatedByItemId' == $relationName) {
            $this->initLoansRelatedByItemId();
        }
        if ('LAuthorityItem' == $relationName) {
            $this->initLAuthorityItems();
        }
        if ('PurchaseProposal' == $relationName) {
            $this->initPurchaseProposals();
        }
    }

    /**
     * Clears out the collItemActions collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return Item The current object (for fluent API support)
     * @see        addItemActions()
     */
    public function clearItemActions()
    {
        $this->collItemActions = null; // important to set this to null since that means it is uninitialized
        $this->collItemActionsPartial = null;

        return $this;
    }

    /**
     * reset is the collItemActions collection loaded partially
     *
     * @return void
     */
    public function resetPartialItemActions($v = true)
    {
        $this->collItemActionsPartial = $v;
    }

    /**
     * Initializes the collItemActions collection.
     *
     * By default this just sets the collItemActions collection to an empty array (like clearcollItemActions());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initItemActions($overrideExisting = true)
    {
        if (null !== $this->collItemActions && !$overrideExisting) {
            return;
        }
        $this->collItemActions = new PropelObjectCollection();
        $this->collItemActions->setModel('ItemAction');
    }

    /**
     * Gets an array of ItemAction objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this Item is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|ItemAction[] List of ItemAction objects
     * @throws PropelException
     */
    public function getItemActions($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collItemActionsPartial && !$this->isNew();
        if (null === $this->collItemActions || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collItemActions) {
                // return empty collection
                $this->initItemActions();
            } else {
                $collItemActions = ItemActionQuery::create(null, $criteria)
                    ->filterByItem($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collItemActionsPartial && count($collItemActions)) {
                      $this->initItemActions(false);

                      foreach ($collItemActions as $obj) {
                        if (false == $this->collItemActions->contains($obj)) {
                          $this->collItemActions->append($obj);
                        }
                      }

                      $this->collItemActionsPartial = true;
                    }

                    $collItemActions->getInternalIterator()->rewind();

                    return $collItemActions;
                }

                if ($partial && $this->collItemActions) {
                    foreach ($this->collItemActions as $obj) {
                        if ($obj->isNew()) {
                            $collItemActions[] = $obj;
                        }
                    }
                }

                $this->collItemActions = $collItemActions;
                $this->collItemActionsPartial = false;
            }
        }

        return $this->collItemActions;
    }

    /**
     * Sets a collection of ItemAction objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $itemActions A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return Item The current object (for fluent API support)
     */
    public function setItemActions(PropelCollection $itemActions, PropelPDO $con = null)
    {
        $itemActionsToDelete = $this->getItemActions(new Criteria(), $con)->diff($itemActions);


        $this->itemActionsScheduledForDeletion = $itemActionsToDelete;

        foreach ($itemActionsToDelete as $itemActionRemoved) {
            $itemActionRemoved->setItem(null);
        }

        $this->collItemActions = null;
        foreach ($itemActions as $itemAction) {
            $this->addItemAction($itemAction);
        }

        $this->collItemActions = $itemActions;
        $this->collItemActionsPartial = false;

        return $this;
    }

    /**
     * Returns the number of related ItemAction objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related ItemAction objects.
     * @throws PropelException
     */
    public function countItemActions(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collItemActionsPartial && !$this->isNew();
        if (null === $this->collItemActions || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collItemActions) {
                return 0;
            }

            if ($partial && !$criteria) {
                return count($this->getItemActions());
            }
            $query = ItemActionQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByItem($this)
                ->count($con);
        }

        return count($this->collItemActions);
    }

    /**
     * Method called to associate a ItemAction object to this object
     * through the ItemAction foreign key attribute.
     *
     * @param    ItemAction $l ItemAction
     * @return Item The current object (for fluent API support)
     */
    public function addItemAction(ItemAction $l)
    {
        if ($this->collItemActions === null) {
            $this->initItemActions();
            $this->collItemActionsPartial = true;
        }

        if (!in_array($l, $this->collItemActions->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddItemAction($l);

            if ($this->itemActionsScheduledForDeletion and $this->itemActionsScheduledForDeletion->contains($l)) {
                $this->itemActionsScheduledForDeletion->remove($this->itemActionsScheduledForDeletion->search($l));
            }
        }

        return $this;
    }

    /**
     * @param	ItemAction $itemAction The itemAction object to add.
     */
    protected function doAddItemAction($itemAction)
    {
        $this->collItemActions[]= $itemAction;
        $itemAction->setItem($this);
    }

    /**
     * @param	ItemAction $itemAction The itemAction object to remove.
     * @return Item The current object (for fluent API support)
     */
    public function removeItemAction($itemAction)
    {
        if ($this->getItemActions()->contains($itemAction)) {
            $this->collItemActions->remove($this->collItemActions->search($itemAction));
            if (null === $this->itemActionsScheduledForDeletion) {
                $this->itemActionsScheduledForDeletion = clone $this->collItemActions;
                $this->itemActionsScheduledForDeletion->clear();
            }
            $this->itemActionsScheduledForDeletion[]= $itemAction;
            $itemAction->setItem(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Item is new, it will return
     * an empty collection; or if this Item has previously
     * been saved, it will retrieve related ItemActions from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Item.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|ItemAction[] List of ItemAction objects
     */
    public function getItemActionsJoinLibrarianRelatedByCreatedBy($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = ItemActionQuery::create(null, $criteria);
        $query->joinWith('LibrarianRelatedByCreatedBy', $join_behavior);

        return $this->getItemActions($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Item is new, it will return
     * an empty collection; or if this Item has previously
     * been saved, it will retrieve related ItemActions from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Item.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|ItemAction[] List of ItemAction objects
     */
    public function getItemActionsJoinLibrarianRelatedByModifiedBy($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = ItemActionQuery::create(null, $criteria);
        $query->joinWith('LibrarianRelatedByModifiedBy', $join_behavior);

        return $this->getItemActions($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Item is new, it will return
     * an empty collection; or if this Item has previously
     * been saved, it will retrieve related ItemActions from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Item.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|ItemAction[] List of ItemAction objects
     */
    public function getItemActionsJoinPatron($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = ItemActionQuery::create(null, $criteria);
        $query->joinWith('Patron', $join_behavior);

        return $this->getItemActions($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Item is new, it will return
     * an empty collection; or if this Item has previously
     * been saved, it will retrieve related ItemActions from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Item.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|ItemAction[] List of ItemAction objects
     */
    public function getItemActionsJoinLibraryRelatedByExternalLibraryId($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = ItemActionQuery::create(null, $criteria);
        $query->joinWith('LibraryRelatedByExternalLibraryId', $join_behavior);

        return $this->getItemActions($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Item is new, it will return
     * an empty collection; or if this Item has previously
     * been saved, it will retrieve related ItemActions from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Item.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|ItemAction[] List of ItemAction objects
     */
    public function getItemActionsJoinLibraryRelatedByLibraryId($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = ItemActionQuery::create(null, $criteria);
        $query->joinWith('LibraryRelatedByLibraryId', $join_behavior);

        return $this->getItemActions($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Item is new, it will return
     * an empty collection; or if this Item has previously
     * been saved, it will retrieve related ItemActions from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Item.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|ItemAction[] List of ItemAction objects
     */
    public function getItemActionsJoinLibraryRelatedByFromLibraryId($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = ItemActionQuery::create(null, $criteria);
        $query->joinWith('LibraryRelatedByFromLibraryId', $join_behavior);

        return $this->getItemActions($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Item is new, it will return
     * an empty collection; or if this Item has previously
     * been saved, it will retrieve related ItemActions from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Item.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|ItemAction[] List of ItemAction objects
     */
    public function getItemActionsJoinLibraryRelatedByToLibraryId($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = ItemActionQuery::create(null, $criteria);
        $query->joinWith('LibraryRelatedByToLibraryId', $join_behavior);

        return $this->getItemActions($query, $con);
    }

    /**
     * Clears out the collItemNotes collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return Item The current object (for fluent API support)
     * @see        addItemNotes()
     */
    public function clearItemNotes()
    {
        $this->collItemNotes = null; // important to set this to null since that means it is uninitialized
        $this->collItemNotesPartial = null;

        return $this;
    }

    /**
     * reset is the collItemNotes collection loaded partially
     *
     * @return void
     */
    public function resetPartialItemNotes($v = true)
    {
        $this->collItemNotesPartial = $v;
    }

    /**
     * Initializes the collItemNotes collection.
     *
     * By default this just sets the collItemNotes collection to an empty array (like clearcollItemNotes());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initItemNotes($overrideExisting = true)
    {
        if (null !== $this->collItemNotes && !$overrideExisting) {
            return;
        }
        $this->collItemNotes = new PropelObjectCollection();
        $this->collItemNotes->setModel('ItemNote');
    }

    /**
     * Gets an array of ItemNote objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this Item is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|ItemNote[] List of ItemNote objects
     * @throws PropelException
     */
    public function getItemNotes($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collItemNotesPartial && !$this->isNew();
        if (null === $this->collItemNotes || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collItemNotes) {
                // return empty collection
                $this->initItemNotes();
            } else {
                $collItemNotes = ItemNoteQuery::create(null, $criteria)
                    ->filterByItem($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collItemNotesPartial && count($collItemNotes)) {
                      $this->initItemNotes(false);

                      foreach ($collItemNotes as $obj) {
                        if (false == $this->collItemNotes->contains($obj)) {
                          $this->collItemNotes->append($obj);
                        }
                      }

                      $this->collItemNotesPartial = true;
                    }

                    $collItemNotes->getInternalIterator()->rewind();

                    return $collItemNotes;
                }

                if ($partial && $this->collItemNotes) {
                    foreach ($this->collItemNotes as $obj) {
                        if ($obj->isNew()) {
                            $collItemNotes[] = $obj;
                        }
                    }
                }

                $this->collItemNotes = $collItemNotes;
                $this->collItemNotesPartial = false;
            }
        }

        return $this->collItemNotes;
    }

    /**
     * Sets a collection of ItemNote objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $itemNotes A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return Item The current object (for fluent API support)
     */
    public function setItemNotes(PropelCollection $itemNotes, PropelPDO $con = null)
    {
        $itemNotesToDelete = $this->getItemNotes(new Criteria(), $con)->diff($itemNotes);


        $this->itemNotesScheduledForDeletion = $itemNotesToDelete;

        foreach ($itemNotesToDelete as $itemNoteRemoved) {
            $itemNoteRemoved->setItem(null);
        }

        $this->collItemNotes = null;
        foreach ($itemNotes as $itemNote) {
            $this->addItemNote($itemNote);
        }

        $this->collItemNotes = $itemNotes;
        $this->collItemNotesPartial = false;

        return $this;
    }

    /**
     * Returns the number of related ItemNote objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related ItemNote objects.
     * @throws PropelException
     */
    public function countItemNotes(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collItemNotesPartial && !$this->isNew();
        if (null === $this->collItemNotes || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collItemNotes) {
                return 0;
            }

            if ($partial && !$criteria) {
                return count($this->getItemNotes());
            }
            $query = ItemNoteQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByItem($this)
                ->count($con);
        }

        return count($this->collItemNotes);
    }

    /**
     * Method called to associate a ItemNote object to this object
     * through the ItemNote foreign key attribute.
     *
     * @param    ItemNote $l ItemNote
     * @return Item The current object (for fluent API support)
     */
    public function addItemNote(ItemNote $l)
    {
        if ($this->collItemNotes === null) {
            $this->initItemNotes();
            $this->collItemNotesPartial = true;
        }

        if (!in_array($l, $this->collItemNotes->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddItemNote($l);

            if ($this->itemNotesScheduledForDeletion and $this->itemNotesScheduledForDeletion->contains($l)) {
                $this->itemNotesScheduledForDeletion->remove($this->itemNotesScheduledForDeletion->search($l));
            }
        }

        return $this;
    }

    /**
     * @param	ItemNote $itemNote The itemNote object to add.
     */
    protected function doAddItemNote($itemNote)
    {
        $this->collItemNotes[]= $itemNote;
        $itemNote->setItem($this);
    }

    /**
     * @param	ItemNote $itemNote The itemNote object to remove.
     * @return Item The current object (for fluent API support)
     */
    public function removeItemNote($itemNote)
    {
        if ($this->getItemNotes()->contains($itemNote)) {
            $this->collItemNotes->remove($this->collItemNotes->search($itemNote));
            if (null === $this->itemNotesScheduledForDeletion) {
                $this->itemNotesScheduledForDeletion = clone $this->collItemNotes;
                $this->itemNotesScheduledForDeletion->clear();
            }
            $this->itemNotesScheduledForDeletion[]= $itemNote;
            $itemNote->setItem(null);
        }

        return $this;
    }

    /**
     * Clears out the collItemRequests collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return Item The current object (for fluent API support)
     * @see        addItemRequests()
     */
    public function clearItemRequests()
    {
        $this->collItemRequests = null; // important to set this to null since that means it is uninitialized
        $this->collItemRequestsPartial = null;

        return $this;
    }

    /**
     * reset is the collItemRequests collection loaded partially
     *
     * @return void
     */
    public function resetPartialItemRequests($v = true)
    {
        $this->collItemRequestsPartial = $v;
    }

    /**
     * Initializes the collItemRequests collection.
     *
     * By default this just sets the collItemRequests collection to an empty array (like clearcollItemRequests());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initItemRequests($overrideExisting = true)
    {
        if (null !== $this->collItemRequests && !$overrideExisting) {
            return;
        }
        $this->collItemRequests = new PropelObjectCollection();
        $this->collItemRequests->setModel('ItemRequest');
    }

    /**
     * Gets an array of ItemRequest objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this Item is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|ItemRequest[] List of ItemRequest objects
     * @throws PropelException
     */
    public function getItemRequests($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collItemRequestsPartial && !$this->isNew();
        if (null === $this->collItemRequests || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collItemRequests) {
                // return empty collection
                $this->initItemRequests();
            } else {
                $collItemRequests = ItemRequestQuery::create(null, $criteria)
                    ->filterByItem($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collItemRequestsPartial && count($collItemRequests)) {
                      $this->initItemRequests(false);

                      foreach ($collItemRequests as $obj) {
                        if (false == $this->collItemRequests->contains($obj)) {
                          $this->collItemRequests->append($obj);
                        }
                      }

                      $this->collItemRequestsPartial = true;
                    }

                    $collItemRequests->getInternalIterator()->rewind();

                    return $collItemRequests;
                }

                if ($partial && $this->collItemRequests) {
                    foreach ($this->collItemRequests as $obj) {
                        if ($obj->isNew()) {
                            $collItemRequests[] = $obj;
                        }
                    }
                }

                $this->collItemRequests = $collItemRequests;
                $this->collItemRequestsPartial = false;
            }
        }

        return $this->collItemRequests;
    }

    /**
     * Sets a collection of ItemRequest objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $itemRequests A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return Item The current object (for fluent API support)
     */
    public function setItemRequests(PropelCollection $itemRequests, PropelPDO $con = null)
    {
        $itemRequestsToDelete = $this->getItemRequests(new Criteria(), $con)->diff($itemRequests);


        $this->itemRequestsScheduledForDeletion = $itemRequestsToDelete;

        foreach ($itemRequestsToDelete as $itemRequestRemoved) {
            $itemRequestRemoved->setItem(null);
        }

        $this->collItemRequests = null;
        foreach ($itemRequests as $itemRequest) {
            $this->addItemRequest($itemRequest);
        }

        $this->collItemRequests = $itemRequests;
        $this->collItemRequestsPartial = false;

        return $this;
    }

    /**
     * Returns the number of related ItemRequest objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related ItemRequest objects.
     * @throws PropelException
     */
    public function countItemRequests(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collItemRequestsPartial && !$this->isNew();
        if (null === $this->collItemRequests || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collItemRequests) {
                return 0;
            }

            if ($partial && !$criteria) {
                return count($this->getItemRequests());
            }
            $query = ItemRequestQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByItem($this)
                ->count($con);
        }

        return count($this->collItemRequests);
    }

    /**
     * Method called to associate a ItemRequest object to this object
     * through the ItemRequest foreign key attribute.
     *
     * @param    ItemRequest $l ItemRequest
     * @return Item The current object (for fluent API support)
     */
    public function addItemRequest(ItemRequest $l)
    {
        if ($this->collItemRequests === null) {
            $this->initItemRequests();
            $this->collItemRequestsPartial = true;
        }

        if (!in_array($l, $this->collItemRequests->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddItemRequest($l);

            if ($this->itemRequestsScheduledForDeletion and $this->itemRequestsScheduledForDeletion->contains($l)) {
                $this->itemRequestsScheduledForDeletion->remove($this->itemRequestsScheduledForDeletion->search($l));
            }
        }

        return $this;
    }

    /**
     * @param	ItemRequest $itemRequest The itemRequest object to add.
     */
    protected function doAddItemRequest($itemRequest)
    {
        $this->collItemRequests[]= $itemRequest;
        $itemRequest->setItem($this);
    }

    /**
     * @param	ItemRequest $itemRequest The itemRequest object to remove.
     * @return Item The current object (for fluent API support)
     */
    public function removeItemRequest($itemRequest)
    {
        if ($this->getItemRequests()->contains($itemRequest)) {
            $this->collItemRequests->remove($this->collItemRequests->search($itemRequest));
            if (null === $this->itemRequestsScheduledForDeletion) {
                $this->itemRequestsScheduledForDeletion = clone $this->collItemRequests;
                $this->itemRequestsScheduledForDeletion->clear();
            }
            $this->itemRequestsScheduledForDeletion[]= $itemRequest;
            $itemRequest->setItem(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Item is new, it will return
     * an empty collection; or if this Item has previously
     * been saved, it will retrieve related ItemRequests from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Item.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|ItemRequest[] List of ItemRequest objects
     */
    public function getItemRequestsJoinLibrarianRelatedByCreatedBy($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = ItemRequestQuery::create(null, $criteria);
        $query->joinWith('LibrarianRelatedByCreatedBy', $join_behavior);

        return $this->getItemRequests($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Item is new, it will return
     * an empty collection; or if this Item has previously
     * been saved, it will retrieve related ItemRequests from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Item.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|ItemRequest[] List of ItemRequest objects
     */
    public function getItemRequestsJoinLibrarianRelatedByModifiedBy($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = ItemRequestQuery::create(null, $criteria);
        $query->joinWith('LibrarianRelatedByModifiedBy', $join_behavior);

        return $this->getItemRequests($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Item is new, it will return
     * an empty collection; or if this Item has previously
     * been saved, it will retrieve related ItemRequests from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Item.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|ItemRequest[] List of ItemRequest objects
     */
    public function getItemRequestsJoinLibrarianRelatedByLibrarianId($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = ItemRequestQuery::create(null, $criteria);
        $query->joinWith('LibrarianRelatedByLibrarianId', $join_behavior);

        return $this->getItemRequests($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Item is new, it will return
     * an empty collection; or if this Item has previously
     * been saved, it will retrieve related ItemRequests from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Item.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|ItemRequest[] List of ItemRequest objects
     */
    public function getItemRequestsJoinPatron($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = ItemRequestQuery::create(null, $criteria);
        $query->joinWith('Patron', $join_behavior);

        return $this->getItemRequests($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Item is new, it will return
     * an empty collection; or if this Item has previously
     * been saved, it will retrieve related ItemRequests from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Item.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|ItemRequest[] List of ItemRequest objects
     */
    public function getItemRequestsJoinLibraryRelatedByExternalLibraryId($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = ItemRequestQuery::create(null, $criteria);
        $query->joinWith('LibraryRelatedByExternalLibraryId', $join_behavior);

        return $this->getItemRequests($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Item is new, it will return
     * an empty collection; or if this Item has previously
     * been saved, it will retrieve related ItemRequests from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Item.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|ItemRequest[] List of ItemRequest objects
     */
    public function getItemRequestsJoinManifestation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = ItemRequestQuery::create(null, $criteria);
        $query->joinWith('Manifestation', $join_behavior);

        return $this->getItemRequests($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Item is new, it will return
     * an empty collection; or if this Item has previously
     * been saved, it will retrieve related ItemRequests from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Item.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|ItemRequest[] List of ItemRequest objects
     */
    public function getItemRequestsJoinIssue($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = ItemRequestQuery::create(null, $criteria);
        $query->joinWith('Issue', $join_behavior);

        return $this->getItemRequests($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Item is new, it will return
     * an empty collection; or if this Item has previously
     * been saved, it will retrieve related ItemRequests from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Item.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|ItemRequest[] List of ItemRequest objects
     */
    public function getItemRequestsJoinLibraryRelatedByDeliveryLibraryId($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = ItemRequestQuery::create(null, $criteria);
        $query->joinWith('LibraryRelatedByDeliveryLibraryId', $join_behavior);

        return $this->getItemRequests($query, $con);
    }

    /**
     * Clears out the collLoansRelatedByItemId collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return Item The current object (for fluent API support)
     * @see        addLoansRelatedByItemId()
     */
    public function clearLoansRelatedByItemId()
    {
        $this->collLoansRelatedByItemId = null; // important to set this to null since that means it is uninitialized
        $this->collLoansRelatedByItemIdPartial = null;

        return $this;
    }

    /**
     * reset is the collLoansRelatedByItemId collection loaded partially
     *
     * @return void
     */
    public function resetPartialLoansRelatedByItemId($v = true)
    {
        $this->collLoansRelatedByItemIdPartial = $v;
    }

    /**
     * Initializes the collLoansRelatedByItemId collection.
     *
     * By default this just sets the collLoansRelatedByItemId collection to an empty array (like clearcollLoansRelatedByItemId());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initLoansRelatedByItemId($overrideExisting = true)
    {
        if (null !== $this->collLoansRelatedByItemId && !$overrideExisting) {
            return;
        }
        $this->collLoansRelatedByItemId = new PropelObjectCollection();
        $this->collLoansRelatedByItemId->setModel('Loan');
    }

    /**
     * Gets an array of Loan objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this Item is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|Loan[] List of Loan objects
     * @throws PropelException
     */
    public function getLoansRelatedByItemId($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collLoansRelatedByItemIdPartial && !$this->isNew();
        if (null === $this->collLoansRelatedByItemId || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collLoansRelatedByItemId) {
                // return empty collection
                $this->initLoansRelatedByItemId();
            } else {
                $collLoansRelatedByItemId = LoanQuery::create(null, $criteria)
                    ->filterByItemRelatedByItemId($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collLoansRelatedByItemIdPartial && count($collLoansRelatedByItemId)) {
                      $this->initLoansRelatedByItemId(false);

                      foreach ($collLoansRelatedByItemId as $obj) {
                        if (false == $this->collLoansRelatedByItemId->contains($obj)) {
                          $this->collLoansRelatedByItemId->append($obj);
                        }
                      }

                      $this->collLoansRelatedByItemIdPartial = true;
                    }

                    $collLoansRelatedByItemId->getInternalIterator()->rewind();

                    return $collLoansRelatedByItemId;
                }

                if ($partial && $this->collLoansRelatedByItemId) {
                    foreach ($this->collLoansRelatedByItemId as $obj) {
                        if ($obj->isNew()) {
                            $collLoansRelatedByItemId[] = $obj;
                        }
                    }
                }

                $this->collLoansRelatedByItemId = $collLoansRelatedByItemId;
                $this->collLoansRelatedByItemIdPartial = false;
            }
        }

        return $this->collLoansRelatedByItemId;
    }

    /**
     * Sets a collection of LoanRelatedByItemId objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $loansRelatedByItemId A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return Item The current object (for fluent API support)
     */
    public function setLoansRelatedByItemId(PropelCollection $loansRelatedByItemId, PropelPDO $con = null)
    {
        $loansRelatedByItemIdToDelete = $this->getLoansRelatedByItemId(new Criteria(), $con)->diff($loansRelatedByItemId);


        $this->loansRelatedByItemIdScheduledForDeletion = $loansRelatedByItemIdToDelete;

        foreach ($loansRelatedByItemIdToDelete as $loanRelatedByItemIdRemoved) {
            $loanRelatedByItemIdRemoved->setItemRelatedByItemId(null);
        }

        $this->collLoansRelatedByItemId = null;
        foreach ($loansRelatedByItemId as $loanRelatedByItemId) {
            $this->addLoanRelatedByItemId($loanRelatedByItemId);
        }

        $this->collLoansRelatedByItemId = $loansRelatedByItemId;
        $this->collLoansRelatedByItemIdPartial = false;

        return $this;
    }

    /**
     * Returns the number of related Loan objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related Loan objects.
     * @throws PropelException
     */
    public function countLoansRelatedByItemId(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collLoansRelatedByItemIdPartial && !$this->isNew();
        if (null === $this->collLoansRelatedByItemId || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collLoansRelatedByItemId) {
                return 0;
            }

            if ($partial && !$criteria) {
                return count($this->getLoansRelatedByItemId());
            }
            $query = LoanQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByItemRelatedByItemId($this)
                ->count($con);
        }

        return count($this->collLoansRelatedByItemId);
    }

    /**
     * Method called to associate a Loan object to this object
     * through the Loan foreign key attribute.
     *
     * @param    Loan $l Loan
     * @return Item The current object (for fluent API support)
     */
    public function addLoanRelatedByItemId(Loan $l)
    {
        if ($this->collLoansRelatedByItemId === null) {
            $this->initLoansRelatedByItemId();
            $this->collLoansRelatedByItemIdPartial = true;
        }

        if (!in_array($l, $this->collLoansRelatedByItemId->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddLoanRelatedByItemId($l);

            if ($this->loansRelatedByItemIdScheduledForDeletion and $this->loansRelatedByItemIdScheduledForDeletion->contains($l)) {
                $this->loansRelatedByItemIdScheduledForDeletion->remove($this->loansRelatedByItemIdScheduledForDeletion->search($l));
            }
        }

        return $this;
    }

    /**
     * @param	LoanRelatedByItemId $loanRelatedByItemId The loanRelatedByItemId object to add.
     */
    protected function doAddLoanRelatedByItemId($loanRelatedByItemId)
    {
        $this->collLoansRelatedByItemId[]= $loanRelatedByItemId;
        $loanRelatedByItemId->setItemRelatedByItemId($this);
    }

    /**
     * @param	LoanRelatedByItemId $loanRelatedByItemId The loanRelatedByItemId object to remove.
     * @return Item The current object (for fluent API support)
     */
    public function removeLoanRelatedByItemId($loanRelatedByItemId)
    {
        if ($this->getLoansRelatedByItemId()->contains($loanRelatedByItemId)) {
            $this->collLoansRelatedByItemId->remove($this->collLoansRelatedByItemId->search($loanRelatedByItemId));
            if (null === $this->loansRelatedByItemIdScheduledForDeletion) {
                $this->loansRelatedByItemIdScheduledForDeletion = clone $this->collLoansRelatedByItemId;
                $this->loansRelatedByItemIdScheduledForDeletion->clear();
            }
            $this->loansRelatedByItemIdScheduledForDeletion[]= $loanRelatedByItemId;
            $loanRelatedByItemId->setItemRelatedByItemId(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Item is new, it will return
     * an empty collection; or if this Item has previously
     * been saved, it will retrieve related LoansRelatedByItemId from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Item.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|Loan[] List of Loan objects
     */
    public function getLoansRelatedByItemIdJoinManifestation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = LoanQuery::create(null, $criteria);
        $query->joinWith('Manifestation', $join_behavior);

        return $this->getLoansRelatedByItemId($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Item is new, it will return
     * an empty collection; or if this Item has previously
     * been saved, it will retrieve related LoansRelatedByItemId from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Item.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|Loan[] List of Loan objects
     */
    public function getLoansRelatedByItemIdJoinItemRequest($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = LoanQuery::create(null, $criteria);
        $query->joinWith('ItemRequest', $join_behavior);

        return $this->getLoansRelatedByItemId($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Item is new, it will return
     * an empty collection; or if this Item has previously
     * been saved, it will retrieve related LoansRelatedByItemId from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Item.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|Loan[] List of Loan objects
     */
    public function getLoansRelatedByItemIdJoinPatron($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = LoanQuery::create(null, $criteria);
        $query->joinWith('Patron', $join_behavior);

        return $this->getLoansRelatedByItemId($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Item is new, it will return
     * an empty collection; or if this Item has previously
     * been saved, it will retrieve related LoansRelatedByItemId from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Item.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|Loan[] List of Loan objects
     */
    public function getLoansRelatedByItemIdJoinLibraryRelatedByExternalLibraryId($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = LoanQuery::create(null, $criteria);
        $query->joinWith('LibraryRelatedByExternalLibraryId', $join_behavior);

        return $this->getLoansRelatedByItemId($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Item is new, it will return
     * an empty collection; or if this Item has previously
     * been saved, it will retrieve related LoansRelatedByItemId from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Item.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|Loan[] List of Loan objects
     */
    public function getLoansRelatedByItemIdJoinLibraryRelatedByFromLibrary($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = LoanQuery::create(null, $criteria);
        $query->joinWith('LibraryRelatedByFromLibrary', $join_behavior);

        return $this->getLoansRelatedByItemId($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Item is new, it will return
     * an empty collection; or if this Item has previously
     * been saved, it will retrieve related LoansRelatedByItemId from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Item.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|Loan[] List of Loan objects
     */
    public function getLoansRelatedByItemIdJoinLibraryRelatedByToLibrary($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = LoanQuery::create(null, $criteria);
        $query->joinWith('LibraryRelatedByToLibrary', $join_behavior);

        return $this->getLoansRelatedByItemId($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Item is new, it will return
     * an empty collection; or if this Item has previously
     * been saved, it will retrieve related LoansRelatedByItemId from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Item.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|Loan[] List of Loan objects
     */
    public function getLoansRelatedByItemIdJoinLibraryRelatedByEndLibrary($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = LoanQuery::create(null, $criteria);
        $query->joinWith('LibraryRelatedByEndLibrary', $join_behavior);

        return $this->getLoansRelatedByItemId($query, $con);
    }

    /**
     * Clears out the collLAuthorityItems collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return Item The current object (for fluent API support)
     * @see        addLAuthorityItems()
     */
    public function clearLAuthorityItems()
    {
        $this->collLAuthorityItems = null; // important to set this to null since that means it is uninitialized
        $this->collLAuthorityItemsPartial = null;

        return $this;
    }

    /**
     * reset is the collLAuthorityItems collection loaded partially
     *
     * @return void
     */
    public function resetPartialLAuthorityItems($v = true)
    {
        $this->collLAuthorityItemsPartial = $v;
    }

    /**
     * Initializes the collLAuthorityItems collection.
     *
     * By default this just sets the collLAuthorityItems collection to an empty array (like clearcollLAuthorityItems());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initLAuthorityItems($overrideExisting = true)
    {
        if (null !== $this->collLAuthorityItems && !$overrideExisting) {
            return;
        }
        $this->collLAuthorityItems = new PropelObjectCollection();
        $this->collLAuthorityItems->setModel('LAuthorityItem');
    }

    /**
     * Gets an array of LAuthorityItem objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this Item is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|LAuthorityItem[] List of LAuthorityItem objects
     * @throws PropelException
     */
    public function getLAuthorityItems($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collLAuthorityItemsPartial && !$this->isNew();
        if (null === $this->collLAuthorityItems || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collLAuthorityItems) {
                // return empty collection
                $this->initLAuthorityItems();
            } else {
                $collLAuthorityItems = LAuthorityItemQuery::create(null, $criteria)
                    ->filterByItem($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collLAuthorityItemsPartial && count($collLAuthorityItems)) {
                      $this->initLAuthorityItems(false);

                      foreach ($collLAuthorityItems as $obj) {
                        if (false == $this->collLAuthorityItems->contains($obj)) {
                          $this->collLAuthorityItems->append($obj);
                        }
                      }

                      $this->collLAuthorityItemsPartial = true;
                    }

                    $collLAuthorityItems->getInternalIterator()->rewind();

                    return $collLAuthorityItems;
                }

                if ($partial && $this->collLAuthorityItems) {
                    foreach ($this->collLAuthorityItems as $obj) {
                        if ($obj->isNew()) {
                            $collLAuthorityItems[] = $obj;
                        }
                    }
                }

                $this->collLAuthorityItems = $collLAuthorityItems;
                $this->collLAuthorityItemsPartial = false;
            }
        }

        return $this->collLAuthorityItems;
    }

    /**
     * Sets a collection of LAuthorityItem objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $lAuthorityItems A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return Item The current object (for fluent API support)
     */
    public function setLAuthorityItems(PropelCollection $lAuthorityItems, PropelPDO $con = null)
    {
        $lAuthorityItemsToDelete = $this->getLAuthorityItems(new Criteria(), $con)->diff($lAuthorityItems);


        //since at least one column in the foreign key is at the same time a PK
        //we can not just set a PK to NULL in the lines below. We have to store
        //a backup of all values, so we are able to manipulate these items based on the onDelete value later.
        $this->lAuthorityItemsScheduledForDeletion = clone $lAuthorityItemsToDelete;

        foreach ($lAuthorityItemsToDelete as $lAuthorityItemRemoved) {
            $lAuthorityItemRemoved->setItem(null);
        }

        $this->collLAuthorityItems = null;
        foreach ($lAuthorityItems as $lAuthorityItem) {
            $this->addLAuthorityItem($lAuthorityItem);
        }

        $this->collLAuthorityItems = $lAuthorityItems;
        $this->collLAuthorityItemsPartial = false;

        return $this;
    }

    /**
     * Returns the number of related LAuthorityItem objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related LAuthorityItem objects.
     * @throws PropelException
     */
    public function countLAuthorityItems(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collLAuthorityItemsPartial && !$this->isNew();
        if (null === $this->collLAuthorityItems || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collLAuthorityItems) {
                return 0;
            }

            if ($partial && !$criteria) {
                return count($this->getLAuthorityItems());
            }
            $query = LAuthorityItemQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByItem($this)
                ->count($con);
        }

        return count($this->collLAuthorityItems);
    }

    /**
     * Method called to associate a LAuthorityItem object to this object
     * through the LAuthorityItem foreign key attribute.
     *
     * @param    LAuthorityItem $l LAuthorityItem
     * @return Item The current object (for fluent API support)
     */
    public function addLAuthorityItem(LAuthorityItem $l)
    {
        if ($this->collLAuthorityItems === null) {
            $this->initLAuthorityItems();
            $this->collLAuthorityItemsPartial = true;
        }

        if (!in_array($l, $this->collLAuthorityItems->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddLAuthorityItem($l);

            if ($this->lAuthorityItemsScheduledForDeletion and $this->lAuthorityItemsScheduledForDeletion->contains($l)) {
                $this->lAuthorityItemsScheduledForDeletion->remove($this->lAuthorityItemsScheduledForDeletion->search($l));
            }
        }

        return $this;
    }

    /**
     * @param	LAuthorityItem $lAuthorityItem The lAuthorityItem object to add.
     */
    protected function doAddLAuthorityItem($lAuthorityItem)
    {
        $this->collLAuthorityItems[]= $lAuthorityItem;
        $lAuthorityItem->setItem($this);
    }

    /**
     * @param	LAuthorityItem $lAuthorityItem The lAuthorityItem object to remove.
     * @return Item The current object (for fluent API support)
     */
    public function removeLAuthorityItem($lAuthorityItem)
    {
        if ($this->getLAuthorityItems()->contains($lAuthorityItem)) {
            $this->collLAuthorityItems->remove($this->collLAuthorityItems->search($lAuthorityItem));
            if (null === $this->lAuthorityItemsScheduledForDeletion) {
                $this->lAuthorityItemsScheduledForDeletion = clone $this->collLAuthorityItems;
                $this->lAuthorityItemsScheduledForDeletion->clear();
            }
            $this->lAuthorityItemsScheduledForDeletion[]= clone $lAuthorityItem;
            $lAuthorityItem->setItem(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Item is new, it will return
     * an empty collection; or if this Item has previously
     * been saved, it will retrieve related LAuthorityItems from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Item.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|LAuthorityItem[] List of LAuthorityItem objects
     */
    public function getLAuthorityItemsJoinAuthority($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = LAuthorityItemQuery::create(null, $criteria);
        $query->joinWith('Authority', $join_behavior);

        return $this->getLAuthorityItems($query, $con);
    }

    /**
     * Clears out the collPurchaseProposals collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return Item The current object (for fluent API support)
     * @see        addPurchaseProposals()
     */
    public function clearPurchaseProposals()
    {
        $this->collPurchaseProposals = null; // important to set this to null since that means it is uninitialized
        $this->collPurchaseProposalsPartial = null;

        return $this;
    }

    /**
     * reset is the collPurchaseProposals collection loaded partially
     *
     * @return void
     */
    public function resetPartialPurchaseProposals($v = true)
    {
        $this->collPurchaseProposalsPartial = $v;
    }

    /**
     * Initializes the collPurchaseProposals collection.
     *
     * By default this just sets the collPurchaseProposals collection to an empty array (like clearcollPurchaseProposals());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initPurchaseProposals($overrideExisting = true)
    {
        if (null !== $this->collPurchaseProposals && !$overrideExisting) {
            return;
        }
        $this->collPurchaseProposals = new PropelObjectCollection();
        $this->collPurchaseProposals->setModel('PurchaseProposal');
    }

    /**
     * Gets an array of PurchaseProposal objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this Item is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|PurchaseProposal[] List of PurchaseProposal objects
     * @throws PropelException
     */
    public function getPurchaseProposals($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collPurchaseProposalsPartial && !$this->isNew();
        if (null === $this->collPurchaseProposals || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collPurchaseProposals) {
                // return empty collection
                $this->initPurchaseProposals();
            } else {
                $collPurchaseProposals = PurchaseProposalQuery::create(null, $criteria)
                    ->filterByItem($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collPurchaseProposalsPartial && count($collPurchaseProposals)) {
                      $this->initPurchaseProposals(false);

                      foreach ($collPurchaseProposals as $obj) {
                        if (false == $this->collPurchaseProposals->contains($obj)) {
                          $this->collPurchaseProposals->append($obj);
                        }
                      }

                      $this->collPurchaseProposalsPartial = true;
                    }

                    $collPurchaseProposals->getInternalIterator()->rewind();

                    return $collPurchaseProposals;
                }

                if ($partial && $this->collPurchaseProposals) {
                    foreach ($this->collPurchaseProposals as $obj) {
                        if ($obj->isNew()) {
                            $collPurchaseProposals[] = $obj;
                        }
                    }
                }

                $this->collPurchaseProposals = $collPurchaseProposals;
                $this->collPurchaseProposalsPartial = false;
            }
        }

        return $this->collPurchaseProposals;
    }

    /**
     * Sets a collection of PurchaseProposal objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $purchaseProposals A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return Item The current object (for fluent API support)
     */
    public function setPurchaseProposals(PropelCollection $purchaseProposals, PropelPDO $con = null)
    {
        $purchaseProposalsToDelete = $this->getPurchaseProposals(new Criteria(), $con)->diff($purchaseProposals);


        $this->purchaseProposalsScheduledForDeletion = $purchaseProposalsToDelete;

        foreach ($purchaseProposalsToDelete as $purchaseProposalRemoved) {
            $purchaseProposalRemoved->setItem(null);
        }

        $this->collPurchaseProposals = null;
        foreach ($purchaseProposals as $purchaseProposal) {
            $this->addPurchaseProposal($purchaseProposal);
        }

        $this->collPurchaseProposals = $purchaseProposals;
        $this->collPurchaseProposalsPartial = false;

        return $this;
    }

    /**
     * Returns the number of related PurchaseProposal objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related PurchaseProposal objects.
     * @throws PropelException
     */
    public function countPurchaseProposals(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collPurchaseProposalsPartial && !$this->isNew();
        if (null === $this->collPurchaseProposals || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collPurchaseProposals) {
                return 0;
            }

            if ($partial && !$criteria) {
                return count($this->getPurchaseProposals());
            }
            $query = PurchaseProposalQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByItem($this)
                ->count($con);
        }

        return count($this->collPurchaseProposals);
    }

    /**
     * Method called to associate a PurchaseProposal object to this object
     * through the PurchaseProposal foreign key attribute.
     *
     * @param    PurchaseProposal $l PurchaseProposal
     * @return Item The current object (for fluent API support)
     */
    public function addPurchaseProposal(PurchaseProposal $l)
    {
        if ($this->collPurchaseProposals === null) {
            $this->initPurchaseProposals();
            $this->collPurchaseProposalsPartial = true;
        }

        if (!in_array($l, $this->collPurchaseProposals->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddPurchaseProposal($l);

            if ($this->purchaseProposalsScheduledForDeletion and $this->purchaseProposalsScheduledForDeletion->contains($l)) {
                $this->purchaseProposalsScheduledForDeletion->remove($this->purchaseProposalsScheduledForDeletion->search($l));
            }
        }

        return $this;
    }

    /**
     * @param	PurchaseProposal $purchaseProposal The purchaseProposal object to add.
     */
    protected function doAddPurchaseProposal($purchaseProposal)
    {
        $this->collPurchaseProposals[]= $purchaseProposal;
        $purchaseProposal->setItem($this);
    }

    /**
     * @param	PurchaseProposal $purchaseProposal The purchaseProposal object to remove.
     * @return Item The current object (for fluent API support)
     */
    public function removePurchaseProposal($purchaseProposal)
    {
        if ($this->getPurchaseProposals()->contains($purchaseProposal)) {
            $this->collPurchaseProposals->remove($this->collPurchaseProposals->search($purchaseProposal));
            if (null === $this->purchaseProposalsScheduledForDeletion) {
                $this->purchaseProposalsScheduledForDeletion = clone $this->collPurchaseProposals;
                $this->purchaseProposalsScheduledForDeletion->clear();
            }
            $this->purchaseProposalsScheduledForDeletion[]= $purchaseProposal;
            $purchaseProposal->setItem(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Item is new, it will return
     * an empty collection; or if this Item has previously
     * been saved, it will retrieve related PurchaseProposals from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Item.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|PurchaseProposal[] List of PurchaseProposal objects
     */
    public function getPurchaseProposalsJoinLibrarianRelatedByCreatedBy($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = PurchaseProposalQuery::create(null, $criteria);
        $query->joinWith('LibrarianRelatedByCreatedBy', $join_behavior);

        return $this->getPurchaseProposals($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Item is new, it will return
     * an empty collection; or if this Item has previously
     * been saved, it will retrieve related PurchaseProposals from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Item.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|PurchaseProposal[] List of PurchaseProposal objects
     */
    public function getPurchaseProposalsJoinLibrarianRelatedByModifiedBy($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = PurchaseProposalQuery::create(null, $criteria);
        $query->joinWith('LibrarianRelatedByModifiedBy', $join_behavior);

        return $this->getPurchaseProposals($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Item is new, it will return
     * an empty collection; or if this Item has previously
     * been saved, it will retrieve related PurchaseProposals from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Item.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|PurchaseProposal[] List of PurchaseProposal objects
     */
    public function getPurchaseProposalsJoinPatron($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = PurchaseProposalQuery::create(null, $criteria);
        $query->joinWith('Patron', $join_behavior);

        return $this->getPurchaseProposals($query, $con);
    }

    /**
     * Clears the current object and sets all attributes to their default values
     */
    public function clear()
    {
        $this->item_id = null;
        $this->title = null;
        $this->manifestation_id = null;
        $this->manifestation_dewey = null;
        $this->item_media = null;
        $this->item_status = null;
        $this->item_order_status = null;
        $this->item_icon = null;
        $this->physical_status = null;
        $this->item_source = null;
        $this->opac_visible = null;
        $this->inventory_serie_id = null;
        $this->inventory_number = null;
        $this->inventory_date = null;
        $this->owner_library_id = null;
        $this->home_library_id = null;
        $this->collocation = null;
        $this->section = null;
        $this->sequence1 = null;
        $this->sequence2 = null;
        $this->specification = null;
        $this->reprint = null;
        $this->width = null;
        $this->height = null;
        $this->weight = null;
        $this->volume_number = null;
        $this->volume_text = null;
        $this->mediapackage_size = null;
        $this->current_loan_id = null;
        $this->loan_class = null;
        $this->last_seen = null;
        $this->loan_status = null;
        $this->loan_alert = null;
        $this->loan_alert_note = null;
        $this->usage_count = null;
        $this->delivery_library_id = null;
        $this->due_date = null;
        $this->patron_id = null;
        $this->external_library_id = null;
        $this->renewal_count = null;
        $this->notify_count = null;
        $this->check_out = null;
        $this->check_in = null;
        $this->ill_timestamp = null;
        $this->supplier_id = null;
        $this->invoice_id = null;
        $this->order_id = null;
        $this->budget_id = null;
        $this->currency = null;
        $this->currency_value = null;
        $this->discount_value = null;
        $this->inventory_value = null;
        $this->issue_inventory_number = null;
        $this->issue_id = null;
        $this->issue_year = null;
        $this->issue_number = null;
        $this->issue_description = null;
        $this->issue_arrival_date = null;
        $this->issue_arrival_date_expected = null;
        $this->issue_status = null;
        $this->subscription_id = null;
        $this->consistency_note_id = null;
        $this->actual_library_id = null;
        $this->barcode = null;
        $this->rfid_code = null;
        $this->custom_field1 = null;
        $this->custom_field2 = null;
        $this->custom_field3 = null;
        $this->unimarc = null;
        $this->last_sbn_sync = null;
        $this->date_discarded = null;
        $this->discard_note = null;
        $this->date_created = null;
        $this->date_updated = null;
        $this->created_by = null;
        $this->modified_by = null;
        $this->alreadyInSave = false;
        $this->alreadyInValidation = false;
        $this->alreadyInClearAllReferencesDeep = false;
        $this->clearAllReferences();
        $this->applyDefaultValues();
        $this->resetModified();
        $this->setNew(true);
        $this->setDeleted(false);
    }

    /**
     * Resets all references to other model objects or collections of model objects.
     *
     * This method is a user-space workaround for PHP's inability to garbage collect
     * objects with circular references (even in PHP 5.3). This is currently necessary
     * when using Propel in certain daemon or large-volume/high-memory operations.
     *
     * @param boolean $deep Whether to also clear the references on all referrer objects.
     */
    public function clearAllReferences($deep = false)
    {
        if ($deep && !$this->alreadyInClearAllReferencesDeep) {
            $this->alreadyInClearAllReferencesDeep = true;
            if ($this->collItemActions) {
                foreach ($this->collItemActions as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collItemNotes) {
                foreach ($this->collItemNotes as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collItemRequests) {
                foreach ($this->collItemRequests as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collLoansRelatedByItemId) {
                foreach ($this->collLoansRelatedByItemId as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collLAuthorityItems) {
                foreach ($this->collLAuthorityItems as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collPurchaseProposals) {
                foreach ($this->collPurchaseProposals as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->aLibrarianRelatedByCreatedBy instanceof Persistent) {
              $this->aLibrarianRelatedByCreatedBy->clearAllReferences($deep);
            }
            if ($this->aLibrarianRelatedByModifiedBy instanceof Persistent) {
              $this->aLibrarianRelatedByModifiedBy->clearAllReferences($deep);
            }
            if ($this->aIssue instanceof Persistent) {
              $this->aIssue->clearAllReferences($deep);
            }
            if ($this->aManifestation instanceof Persistent) {
              $this->aManifestation->clearAllReferences($deep);
            }
            if ($this->aConsistencyNote instanceof Persistent) {
              $this->aConsistencyNote->clearAllReferences($deep);
            }
            if ($this->aLibraryRelatedByOwnerLibraryId instanceof Persistent) {
              $this->aLibraryRelatedByOwnerLibraryId->clearAllReferences($deep);
            }
            if ($this->aLibraryRelatedByHomeLibraryId instanceof Persistent) {
              $this->aLibraryRelatedByHomeLibraryId->clearAllReferences($deep);
            }
            if ($this->aLibraryRelatedByDeliveryLibraryId instanceof Persistent) {
              $this->aLibraryRelatedByDeliveryLibraryId->clearAllReferences($deep);
            }
            if ($this->aLibraryRelatedByActualLibraryId instanceof Persistent) {
              $this->aLibraryRelatedByActualLibraryId->clearAllReferences($deep);
            }
            if ($this->aInventorySerie instanceof Persistent) {
              $this->aInventorySerie->clearAllReferences($deep);
            }
            if ($this->aPurchaseOrder instanceof Persistent) {
              $this->aPurchaseOrder->clearAllReferences($deep);
            }
            if ($this->aInvoice instanceof Persistent) {
              $this->aInvoice->clearAllReferences($deep);
            }
            if ($this->aSupplier instanceof Persistent) {
              $this->aSupplier->clearAllReferences($deep);
            }
            if ($this->aPatron instanceof Persistent) {
              $this->aPatron->clearAllReferences($deep);
            }
            if ($this->aLibraryRelatedByExternalLibraryId instanceof Persistent) {
              $this->aLibraryRelatedByExternalLibraryId->clearAllReferences($deep);
            }
            if ($this->aLoanRelatedByCurrentLoanId instanceof Persistent) {
              $this->aLoanRelatedByCurrentLoanId->clearAllReferences($deep);
            }
            if ($this->aBudget instanceof Persistent) {
              $this->aBudget->clearAllReferences($deep);
            }

            $this->alreadyInClearAllReferencesDeep = false;
        } // if ($deep)

        if ($this->collItemActions instanceof PropelCollection) {
            $this->collItemActions->clearIterator();
        }
        $this->collItemActions = null;
        if ($this->collItemNotes instanceof PropelCollection) {
            $this->collItemNotes->clearIterator();
        }
        $this->collItemNotes = null;
        if ($this->collItemRequests instanceof PropelCollection) {
            $this->collItemRequests->clearIterator();
        }
        $this->collItemRequests = null;
        if ($this->collLoansRelatedByItemId instanceof PropelCollection) {
            $this->collLoansRelatedByItemId->clearIterator();
        }
        $this->collLoansRelatedByItemId = null;
        if ($this->collLAuthorityItems instanceof PropelCollection) {
            $this->collLAuthorityItems->clearIterator();
        }
        $this->collLAuthorityItems = null;
        if ($this->collPurchaseProposals instanceof PropelCollection) {
            $this->collPurchaseProposals->clearIterator();
        }
        $this->collPurchaseProposals = null;
        $this->aLibrarianRelatedByCreatedBy = null;
        $this->aLibrarianRelatedByModifiedBy = null;
        $this->aIssue = null;
        $this->aManifestation = null;
        $this->aConsistencyNote = null;
        $this->aLibraryRelatedByOwnerLibraryId = null;
        $this->aLibraryRelatedByHomeLibraryId = null;
        $this->aLibraryRelatedByDeliveryLibraryId = null;
        $this->aLibraryRelatedByActualLibraryId = null;
        $this->aInventorySerie = null;
        $this->aPurchaseOrder = null;
        $this->aInvoice = null;
        $this->aSupplier = null;
        $this->aPatron = null;
        $this->aLibraryRelatedByExternalLibraryId = null;
        $this->aLoanRelatedByCurrentLoanId = null;
        $this->aBudget = null;
    }

    /**
     * return the string representation of this object
     *
     * @return string
     */
    public function __toString()
    {
        return (string) $this->exportTo(ItemPeer::DEFAULT_STRING_FORMAT);
    }

    /**
     * return true is the object is in saving state
     *
     * @return boolean
     */
    public function isAlreadyInSave()
    {
        return $this->alreadyInSave;
    }

    // timestampable behavior

    /**
     * Mark the current object so that the update date doesn't get updated during next save
     *
     * @return     Item The current object (for fluent API support)
     */
    public function keepUpdateDateUnchanged()
    {
        $this->modifiedColumns[] = ItemPeer::DATE_UPDATED;

        return $this;
    }

    // librariantrace behavior

    /**
     * Returns the complete name of the librarian that created this object.
     *
     * @return string
     */
    public function getCreatedByNameString()
    {
        $l = $this->getLibrarianRelatedByCreatedBy();
        return ($l instanceof Librarian) ? $l->getCompleteName() : '';
    }

    /**
     * Returns the complete name of the librarian that last updated this object.
     *
     * @return string
     */
    public function getModifiedByNameString()
    {
        $l = $this->getLibrarianRelatedByModifiedBy();
        return ($l instanceof Librarian) ? $l->getCompleteName() : '';
    }

    /**
     * Mark the current object so that the update date doesn't get updated during next save
     *
     * @return     Item The current object (for fluent API support)
     */
    public function keepUpdateLibrarianUnchanged()
    {
        $this->modifiedColumns[] = ItemPeer::MODIFIED_BY;
        return $this;
    }

}
