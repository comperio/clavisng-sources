<?php


/**
 * Base class that represents a row from the 'ill_request' table.
 *
 *
 *
 * @package    propel.generator.clavis.om
 */
abstract class BaseIllRequest extends BaseObject implements Persistent
{
    /**
     * Peer class name
     */
    const PEER = 'IllRequestPeer';

    /**
     * The Peer class.
     * Instance provides a convenient way of calling static methods on a class
     * that calling code may not be able to identify.
     * @var        IllRequestPeer
     */
    protected static $peer;

    /**
     * The flag var to prevent infinite loop in deep copy
     * @var       boolean
     */
    protected $startCopy = false;

    /**
     * The value for the ill_request_id field.
     * @var        int
     */
    protected $ill_request_id;

    /**
     * The value for the request_status field.
     * @var        string
     */
    protected $request_status;

    /**
     * The value for the request_date field.
     * @var        string
     */
    protected $request_date;

    /**
     * The value for the from_library_id field.
     * @var        int
     */
    protected $from_library_id;

    /**
     * The value for the to_library_id field.
     * @var        int
     */
    protected $to_library_id;

    /**
     * The value for the patron_id field.
     * @var        int
     */
    protected $patron_id;

    /**
     * The value for the request_key field.
     * @var        string
     */
    protected $request_key;

    /**
     * The value for the librarian_id field.
     * @var        int
     */
    protected $librarian_id;

    /**
     * The value for the item_location field.
     * @var        string
     */
    protected $item_location;

    /**
     * The value for the item_title field.
     * @var        string
     */
    protected $item_title;

    /**
     * The value for the start_loan_date field.
     * @var        string
     */
    protected $start_loan_date;

    /**
     * The value for the due_date field.
     * @var        string
     */
    protected $due_date;

    /**
     * The value for the title field.
     * @var        string
     */
    protected $title;

    /**
     * The value for the unimarc field.
     * @var        string
     */
    protected $unimarc;

    /**
     * The value for the date_created field.
     * @var        string
     */
    protected $date_created;

    /**
     * The value for the date_updated field.
     * @var        string
     */
    protected $date_updated;

    /**
     * The value for the created_by field.
     * @var        int
     */
    protected $created_by;

    /**
     * The value for the modified_by field.
     * @var        int
     */
    protected $modified_by;

    /**
     * @var        Librarian
     */
    protected $aLibrarianRelatedByCreatedBy;

    /**
     * @var        Librarian
     */
    protected $aLibrarianRelatedByModifiedBy;

    /**
     * Flag to prevent endless save loop, if this object is referenced
     * by another object which falls in this transaction.
     * @var        boolean
     */
    protected $alreadyInSave = false;

    /**
     * Flag to prevent endless validation loop, if this object is referenced
     * by another object which falls in this transaction.
     * @var        boolean
     */
    protected $alreadyInValidation = false;

    /**
     * Flag to prevent endless clearAllReferences($deep=true) loop, if this object is referenced
     * @var        boolean
     */
    protected $alreadyInClearAllReferencesDeep = false;

    /**
     * Get the [ill_request_id] column value.
     *
     * @return int
     */
    public function getIllRequestId()
    {

        return $this->ill_request_id;
    }

    /**
     * Get the [request_status] column value.
     *
     * @return string
     */
    public function getRequestStatus()
    {

        return $this->request_status;
    }

    /**
     * Get the [optionally formatted] temporal [request_date] column value.
     *
     *
     * @param string $format The date/time format string (either date()-style or strftime()-style).
     *				 If format is null, then the raw DateTime object will be returned.
     * @return mixed Formatted date/time value as string or DateTime object (if format is null), null if column is null, and 0 if column value is 0000-00-00 00:00:00
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getRequestDate($format = 'Y-m-d H:i:s')
    {
        if ($this->request_date === null) {
            return null;
        }

        if ($this->request_date === '0000-00-00 00:00:00') {
            // while technically this is not a default value of null,
            // this seems to be closest in meaning.
            return null;
        }

        try {
            $dt = new DateTime($this->request_date);
        } catch (Exception $x) {
            throw new PropelException("Internally stored date/time/timestamp value could not be converted to DateTime: " . var_export($this->request_date, true), $x);
        }

        if ($format === null) {
            // Because propel.useDateTimeClass is true, we return a DateTime object.
            return $dt;
        }

        if (strpos($format, '%') !== false) {
            return strftime($format, $dt->format('U'));
        }

        return $dt->format($format);

    }

    /**
     * Get the [from_library_id] column value.
     *
     * @return int
     */
    public function getFromLibraryId()
    {

        return $this->from_library_id;
    }

    /**
     * Get the [to_library_id] column value.
     *
     * @return int
     */
    public function getToLibraryId()
    {

        return $this->to_library_id;
    }

    /**
     * Get the [patron_id] column value.
     *
     * @return int
     */
    public function getPatronId()
    {

        return $this->patron_id;
    }

    /**
     * Get the [request_key] column value.
     *
     * @return string
     */
    public function getRequestKey()
    {

        return $this->request_key;
    }

    /**
     * Get the [librarian_id] column value.
     *
     * @return int
     */
    public function getLibrarianId()
    {

        return $this->librarian_id;
    }

    /**
     * Get the [item_location] column value.
     *
     * @return string
     */
    public function getItemLocation()
    {

        return $this->item_location;
    }

    /**
     * Get the [item_title] column value.
     *
     * @return string
     */
    public function getItemTitle()
    {

        return $this->item_title;
    }

    /**
     * Get the [optionally formatted] temporal [start_loan_date] column value.
     *
     *
     * @param string $format The date/time format string (either date()-style or strftime()-style).
     *				 If format is null, then the raw DateTime object will be returned.
     * @return mixed Formatted date/time value as string or DateTime object (if format is null), null if column is null, and 0 if column value is 0000-00-00
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getStartLoanDate($format = '%F %T')
    {
        if ($this->start_loan_date === null) {
            return null;
        }

        if ($this->start_loan_date === '0000-00-00') {
            // while technically this is not a default value of null,
            // this seems to be closest in meaning.
            return null;
        }

        try {
            $dt = new DateTime($this->start_loan_date);
        } catch (Exception $x) {
            throw new PropelException("Internally stored date/time/timestamp value could not be converted to DateTime: " . var_export($this->start_loan_date, true), $x);
        }

        if ($format === null) {
            // Because propel.useDateTimeClass is true, we return a DateTime object.
            return $dt;
        }

        if (strpos($format, '%') !== false) {
            return strftime($format, $dt->format('U'));
        }

        return $dt->format($format);

    }

    /**
     * Get the [optionally formatted] temporal [due_date] column value.
     *
     *
     * @param string $format The date/time format string (either date()-style or strftime()-style).
     *				 If format is null, then the raw DateTime object will be returned.
     * @return mixed Formatted date/time value as string or DateTime object (if format is null), null if column is null, and 0 if column value is 0000-00-00
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getDueDate($format = '%F %T')
    {
        if ($this->due_date === null) {
            return null;
        }

        if ($this->due_date === '0000-00-00') {
            // while technically this is not a default value of null,
            // this seems to be closest in meaning.
            return null;
        }

        try {
            $dt = new DateTime($this->due_date);
        } catch (Exception $x) {
            throw new PropelException("Internally stored date/time/timestamp value could not be converted to DateTime: " . var_export($this->due_date, true), $x);
        }

        if ($format === null) {
            // Because propel.useDateTimeClass is true, we return a DateTime object.
            return $dt;
        }

        if (strpos($format, '%') !== false) {
            return strftime($format, $dt->format('U'));
        }

        return $dt->format($format);

    }

    /**
     * Get the [title] column value.
     *
     * @return string
     */
    public function getTitle()
    {

        return $this->title;
    }

    /**
     * Get the [unimarc] column value.
     *
     * @return string
     */
    public function getUnimarc()
    {

        return $this->unimarc;
    }

    /**
     * Get the [optionally formatted] temporal [date_created] column value.
     *
     *
     * @param string $format The date/time format string (either date()-style or strftime()-style).
     *				 If format is null, then the raw DateTime object will be returned.
     * @return mixed Formatted date/time value as string or DateTime object (if format is null), null if column is null, and 0 if column value is 0000-00-00 00:00:00
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getDateCreated($format = 'Y-m-d H:i:s')
    {
        if ($this->date_created === null) {
            return null;
        }

        if ($this->date_created === '0000-00-00 00:00:00') {
            // while technically this is not a default value of null,
            // this seems to be closest in meaning.
            return null;
        }

        try {
            $dt = new DateTime($this->date_created);
        } catch (Exception $x) {
            throw new PropelException("Internally stored date/time/timestamp value could not be converted to DateTime: " . var_export($this->date_created, true), $x);
        }

        if ($format === null) {
            // Because propel.useDateTimeClass is true, we return a DateTime object.
            return $dt;
        }

        if (strpos($format, '%') !== false) {
            return strftime($format, $dt->format('U'));
        }

        return $dt->format($format);

    }

    /**
     * Get the [optionally formatted] temporal [date_updated] column value.
     *
     *
     * @param string $format The date/time format string (either date()-style or strftime()-style).
     *				 If format is null, then the raw DateTime object will be returned.
     * @return mixed Formatted date/time value as string or DateTime object (if format is null), null if column is null, and 0 if column value is 0000-00-00 00:00:00
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getDateUpdated($format = 'Y-m-d H:i:s')
    {
        if ($this->date_updated === null) {
            return null;
        }

        if ($this->date_updated === '0000-00-00 00:00:00') {
            // while technically this is not a default value of null,
            // this seems to be closest in meaning.
            return null;
        }

        try {
            $dt = new DateTime($this->date_updated);
        } catch (Exception $x) {
            throw new PropelException("Internally stored date/time/timestamp value could not be converted to DateTime: " . var_export($this->date_updated, true), $x);
        }

        if ($format === null) {
            // Because propel.useDateTimeClass is true, we return a DateTime object.
            return $dt;
        }

        if (strpos($format, '%') !== false) {
            return strftime($format, $dt->format('U'));
        }

        return $dt->format($format);

    }

    /**
     * Get the [created_by] column value.
     *
     * @return int
     */
    public function getCreatedBy()
    {

        return $this->created_by;
    }

    /**
     * Get the [modified_by] column value.
     *
     * @return int
     */
    public function getModifiedBy()
    {

        return $this->modified_by;
    }

    /**
     * Set the value of [ill_request_id] column.
     *
     * @param  int $v new value
     * @return IllRequest The current object (for fluent API support)
     */
    public function setIllRequestId($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->ill_request_id !== $v) {
            $this->ill_request_id = $v;
            $this->modifiedColumns[] = IllRequestPeer::ILL_REQUEST_ID;
        }


        return $this;
    } // setIllRequestId()

    /**
     * Set the value of [request_status] column.
     *
     * @param  string $v new value
     * @return IllRequest The current object (for fluent API support)
     */
    public function setRequestStatus($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->request_status !== $v) {
            $this->request_status = $v;
            $this->modifiedColumns[] = IllRequestPeer::REQUEST_STATUS;
        }


        return $this;
    } // setRequestStatus()

    /**
     * Sets the value of [request_date] column to a normalized version of the date/time value specified.
     *
     * @param mixed $v string, integer (timestamp), or DateTime value.
     *               Empty strings are treated as null.
     * @return IllRequest The current object (for fluent API support)
     */
    public function setRequestDate($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->request_date !== null || $dt !== null) {
            $currentDateAsString = ($this->request_date !== null && $tmpDt = new DateTime($this->request_date)) ? $tmpDt->format('Y-m-d H:i:s') : null;
            $newDateAsString = $dt ? $dt->format('Y-m-d H:i:s') : null;
            if ($currentDateAsString !== $newDateAsString) {
                $this->request_date = $newDateAsString;
                $this->modifiedColumns[] = IllRequestPeer::REQUEST_DATE;
            }
        } // if either are not null


        return $this;
    } // setRequestDate()

    /**
     * Set the value of [from_library_id] column.
     *
     * @param  int $v new value
     * @return IllRequest The current object (for fluent API support)
     */
    public function setFromLibraryId($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->from_library_id !== $v) {
            $this->from_library_id = $v;
            $this->modifiedColumns[] = IllRequestPeer::FROM_LIBRARY_ID;
        }


        return $this;
    } // setFromLibraryId()

    /**
     * Set the value of [to_library_id] column.
     *
     * @param  int $v new value
     * @return IllRequest The current object (for fluent API support)
     */
    public function setToLibraryId($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->to_library_id !== $v) {
            $this->to_library_id = $v;
            $this->modifiedColumns[] = IllRequestPeer::TO_LIBRARY_ID;
        }


        return $this;
    } // setToLibraryId()

    /**
     * Set the value of [patron_id] column.
     *
     * @param  int $v new value
     * @return IllRequest The current object (for fluent API support)
     */
    public function setPatronId($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->patron_id !== $v) {
            $this->patron_id = $v;
            $this->modifiedColumns[] = IllRequestPeer::PATRON_ID;
        }


        return $this;
    } // setPatronId()

    /**
     * Set the value of [request_key] column.
     *
     * @param  string $v new value
     * @return IllRequest The current object (for fluent API support)
     */
    public function setRequestKey($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->request_key !== $v) {
            $this->request_key = $v;
            $this->modifiedColumns[] = IllRequestPeer::REQUEST_KEY;
        }


        return $this;
    } // setRequestKey()

    /**
     * Set the value of [librarian_id] column.
     *
     * @param  int $v new value
     * @return IllRequest The current object (for fluent API support)
     */
    public function setLibrarianId($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->librarian_id !== $v) {
            $this->librarian_id = $v;
            $this->modifiedColumns[] = IllRequestPeer::LIBRARIAN_ID;
        }


        return $this;
    } // setLibrarianId()

    /**
     * Set the value of [item_location] column.
     *
     * @param  string $v new value
     * @return IllRequest The current object (for fluent API support)
     */
    public function setItemLocation($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->item_location !== $v) {
            $this->item_location = $v;
            $this->modifiedColumns[] = IllRequestPeer::ITEM_LOCATION;
        }


        return $this;
    } // setItemLocation()

    /**
     * Set the value of [item_title] column.
     *
     * @param  string $v new value
     * @return IllRequest The current object (for fluent API support)
     */
    public function setItemTitle($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->item_title !== $v) {
            $this->item_title = $v;
            $this->modifiedColumns[] = IllRequestPeer::ITEM_TITLE;
        }


        return $this;
    } // setItemTitle()

    /**
     * Sets the value of [start_loan_date] column to a normalized version of the date/time value specified.
     *
     * @param mixed $v string, integer (timestamp), or DateTime value.
     *               Empty strings are treated as null.
     * @return IllRequest The current object (for fluent API support)
     */
    public function setStartLoanDate($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->start_loan_date !== null || $dt !== null) {
            $currentDateAsString = ($this->start_loan_date !== null && $tmpDt = new DateTime($this->start_loan_date)) ? $tmpDt->format('Y-m-d') : null;
            $newDateAsString = $dt ? $dt->format('Y-m-d') : null;
            if ($currentDateAsString !== $newDateAsString) {
                $this->start_loan_date = $newDateAsString;
                $this->modifiedColumns[] = IllRequestPeer::START_LOAN_DATE;
            }
        } // if either are not null


        return $this;
    } // setStartLoanDate()

    /**
     * Sets the value of [due_date] column to a normalized version of the date/time value specified.
     *
     * @param mixed $v string, integer (timestamp), or DateTime value.
     *               Empty strings are treated as null.
     * @return IllRequest The current object (for fluent API support)
     */
    public function setDueDate($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->due_date !== null || $dt !== null) {
            $currentDateAsString = ($this->due_date !== null && $tmpDt = new DateTime($this->due_date)) ? $tmpDt->format('Y-m-d') : null;
            $newDateAsString = $dt ? $dt->format('Y-m-d') : null;
            if ($currentDateAsString !== $newDateAsString) {
                $this->due_date = $newDateAsString;
                $this->modifiedColumns[] = IllRequestPeer::DUE_DATE;
            }
        } // if either are not null


        return $this;
    } // setDueDate()

    /**
     * Set the value of [title] column.
     *
     * @param  string $v new value
     * @return IllRequest The current object (for fluent API support)
     */
    public function setTitle($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->title !== $v) {
            $this->title = $v;
            $this->modifiedColumns[] = IllRequestPeer::TITLE;
        }


        return $this;
    } // setTitle()

    /**
     * Set the value of [unimarc] column.
     *
     * @param  string $v new value
     * @return IllRequest The current object (for fluent API support)
     */
    public function setUnimarc($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->unimarc !== $v) {
            $this->unimarc = $v;
            $this->modifiedColumns[] = IllRequestPeer::UNIMARC;
        }


        return $this;
    } // setUnimarc()

    /**
     * Sets the value of [date_created] column to a normalized version of the date/time value specified.
     *
     * @param mixed $v string, integer (timestamp), or DateTime value.
     *               Empty strings are treated as null.
     * @return IllRequest The current object (for fluent API support)
     */
    public function setDateCreated($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->date_created !== null || $dt !== null) {
            $currentDateAsString = ($this->date_created !== null && $tmpDt = new DateTime($this->date_created)) ? $tmpDt->format('Y-m-d H:i:s') : null;
            $newDateAsString = $dt ? $dt->format('Y-m-d H:i:s') : null;
            if ($currentDateAsString !== $newDateAsString) {
                $this->date_created = $newDateAsString;
                $this->modifiedColumns[] = IllRequestPeer::DATE_CREATED;
            }
        } // if either are not null


        return $this;
    } // setDateCreated()

    /**
     * Sets the value of [date_updated] column to a normalized version of the date/time value specified.
     *
     * @param mixed $v string, integer (timestamp), or DateTime value.
     *               Empty strings are treated as null.
     * @return IllRequest The current object (for fluent API support)
     */
    public function setDateUpdated($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->date_updated !== null || $dt !== null) {
            $currentDateAsString = ($this->date_updated !== null && $tmpDt = new DateTime($this->date_updated)) ? $tmpDt->format('Y-m-d H:i:s') : null;
            $newDateAsString = $dt ? $dt->format('Y-m-d H:i:s') : null;
            if ($currentDateAsString !== $newDateAsString) {
                $this->date_updated = $newDateAsString;
                $this->modifiedColumns[] = IllRequestPeer::DATE_UPDATED;
            }
        } // if either are not null


        return $this;
    } // setDateUpdated()

    /**
     * Set the value of [created_by] column.
     *
     * @param  int $v new value
     * @return IllRequest The current object (for fluent API support)
     */
    public function setCreatedBy($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->created_by !== $v) {
            $this->created_by = $v;
            $this->modifiedColumns[] = IllRequestPeer::CREATED_BY;
        }

        if ($this->aLibrarianRelatedByCreatedBy !== null && $this->aLibrarianRelatedByCreatedBy->getLibrarianId() !== $v) {
            $this->aLibrarianRelatedByCreatedBy = null;
        }


        return $this;
    } // setCreatedBy()

    /**
     * Set the value of [modified_by] column.
     *
     * @param  int $v new value
     * @return IllRequest The current object (for fluent API support)
     */
    public function setModifiedBy($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->modified_by !== $v) {
            $this->modified_by = $v;
            $this->modifiedColumns[] = IllRequestPeer::MODIFIED_BY;
        }

        if ($this->aLibrarianRelatedByModifiedBy !== null && $this->aLibrarianRelatedByModifiedBy->getLibrarianId() !== $v) {
            $this->aLibrarianRelatedByModifiedBy = null;
        }


        return $this;
    } // setModifiedBy()

    /**
     * Indicates whether the columns in this object are only set to default values.
     *
     * This method can be used in conjunction with isModified() to indicate whether an object is both
     * modified _and_ has some values set which are non-default.
     *
     * @return boolean Whether the columns in this object are only been set with default values.
     */
    public function hasOnlyDefaultValues()
    {
        // otherwise, everything was equal, so return true
        return true;
    } // hasOnlyDefaultValues()

    /**
     * Hydrates (populates) the object variables with values from the database resultset.
     *
     * An offset (0-based "start column") is specified so that objects can be hydrated
     * with a subset of the columns in the resultset rows.  This is needed, for example,
     * for results of JOIN queries where the resultset row includes columns from two or
     * more tables.
     *
     * @param array $row The row returned by PDOStatement->fetch(PDO::FETCH_NUM)
     * @param int $startcol 0-based offset column which indicates which resultset column to start with.
     * @param boolean $rehydrate Whether this object is being re-hydrated from the database.
     * @return int             next starting column
     * @throws PropelException - Any caught Exception will be rewrapped as a PropelException.
     */
    public function hydrate($row, $startcol = 0, $rehydrate = false)
    {
        try {

            $this->ill_request_id = ($row[$startcol + 0] !== null) ? (int) $row[$startcol + 0] : null;
            $this->request_status = ($row[$startcol + 1] !== null) ? (string) $row[$startcol + 1] : null;
            $this->request_date = ($row[$startcol + 2] !== null) ? (string) $row[$startcol + 2] : null;
            $this->from_library_id = ($row[$startcol + 3] !== null) ? (int) $row[$startcol + 3] : null;
            $this->to_library_id = ($row[$startcol + 4] !== null) ? (int) $row[$startcol + 4] : null;
            $this->patron_id = ($row[$startcol + 5] !== null) ? (int) $row[$startcol + 5] : null;
            $this->request_key = ($row[$startcol + 6] !== null) ? (string) $row[$startcol + 6] : null;
            $this->librarian_id = ($row[$startcol + 7] !== null) ? (int) $row[$startcol + 7] : null;
            $this->item_location = ($row[$startcol + 8] !== null) ? (string) $row[$startcol + 8] : null;
            $this->item_title = ($row[$startcol + 9] !== null) ? (string) $row[$startcol + 9] : null;
            $this->start_loan_date = ($row[$startcol + 10] !== null) ? (string) $row[$startcol + 10] : null;
            $this->due_date = ($row[$startcol + 11] !== null) ? (string) $row[$startcol + 11] : null;
            $this->title = ($row[$startcol + 12] !== null) ? (string) $row[$startcol + 12] : null;
            $this->unimarc = ($row[$startcol + 13] !== null) ? (string) $row[$startcol + 13] : null;
            $this->date_created = ($row[$startcol + 14] !== null) ? (string) $row[$startcol + 14] : null;
            $this->date_updated = ($row[$startcol + 15] !== null) ? (string) $row[$startcol + 15] : null;
            $this->created_by = ($row[$startcol + 16] !== null) ? (int) $row[$startcol + 16] : null;
            $this->modified_by = ($row[$startcol + 17] !== null) ? (int) $row[$startcol + 17] : null;
            $this->resetModified();

            $this->setNew(false);

            if ($rehydrate) {
                $this->ensureConsistency();
            }
            $this->postHydrate($row, $startcol, $rehydrate);

            return $startcol + 18; // 18 = IllRequestPeer::NUM_HYDRATE_COLUMNS.

        } catch (Exception $e) {
            throw new PropelException("Error populating IllRequest object", $e);
        }
    }

    /**
     * Checks and repairs the internal consistency of the object.
     *
     * This method is executed after an already-instantiated object is re-hydrated
     * from the database.  It exists to check any foreign keys to make sure that
     * the objects related to the current object are correct based on foreign key.
     *
     * You can override this method in the stub class, but you should always invoke
     * the base method from the overridden method (i.e. parent::ensureConsistency()),
     * in case your model changes.
     *
     * @throws PropelException
     */
    public function ensureConsistency()
    {

        if ($this->aLibrarianRelatedByCreatedBy !== null && $this->created_by !== $this->aLibrarianRelatedByCreatedBy->getLibrarianId()) {
            $this->aLibrarianRelatedByCreatedBy = null;
        }
        if ($this->aLibrarianRelatedByModifiedBy !== null && $this->modified_by !== $this->aLibrarianRelatedByModifiedBy->getLibrarianId()) {
            $this->aLibrarianRelatedByModifiedBy = null;
        }
    } // ensureConsistency

    /**
     * Reloads this object from datastore based on primary key and (optionally) resets all associated objects.
     *
     * This will only work if the object has been saved and has a valid primary key set.
     *
     * @param boolean $deep (optional) Whether to also de-associated any related objects.
     * @param PropelPDO $con (optional) The PropelPDO connection to use.
     * @return void
     * @throws PropelException - if this object is deleted, unsaved or doesn't have pk match in db
     */
    public function reload($deep = false, PropelPDO $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("Cannot reload a deleted object.");
        }

        if ($this->isNew()) {
            throw new PropelException("Cannot reload an unsaved object.");
        }

        if ($con === null) {
            $con = Propel::getConnection(IllRequestPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        // We don't need to alter the object instance pool; we're just modifying this instance
        // already in the pool.

        $stmt = IllRequestPeer::doSelectStmt($this->buildPkeyCriteria(), $con);
        $row = $stmt->fetch(PDO::FETCH_NUM);
        $stmt->closeCursor();
        if (!$row) {
            throw new PropelException('Cannot find matching row in the database to reload object values.');
        }
        $this->hydrate($row, 0, true); // rehydrate

        if ($deep) {  // also de-associate any related objects?

            $this->aLibrarianRelatedByCreatedBy = null;
            $this->aLibrarianRelatedByModifiedBy = null;
        } // if (deep)
    }

    /**
     * Removes this object from datastore and sets delete attribute.
     *
     * @param PropelPDO $con
     * @return void
     * @throws PropelException
     * @throws Exception
     * @see        BaseObject::setDeleted()
     * @see        BaseObject::isDeleted()
     */
    public function delete(PropelPDO $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("This object has already been deleted.");
        }

        if ($con === null) {
            $con = Propel::getConnection(IllRequestPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        $con->beginTransaction();
        try {
            $deleteQuery = IllRequestQuery::create()
                ->filterByPrimaryKey($this->getPrimaryKey());
            $ret = $this->preDelete($con);
            if ($ret) {
                $deleteQuery->delete($con);
                $this->postDelete($con);
                $con->commit();
                $this->setDeleted(true);
            } else {
                $con->commit();
            }
        } catch (Exception $e) {
            $con->rollBack();
            throw $e;
        }
    }

    /**
     * Persists this object to the database.
     *
     * If the object is new, it inserts it; otherwise an update is performed.
     * All modified related objects will also be persisted in the doSave()
     * method.  This method wraps all precipitate database operations in a
     * single transaction.
     *
     * @param PropelPDO $con
     * @return int             The number of rows affected by this insert/update and any referring fk objects' save() operations.
     * @throws PropelException
     * @throws Exception
     * @see        doSave()
     */
    public function save(PropelPDO $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("You cannot save an object that has been deleted.");
        }

        if ($con === null) {
            $con = Propel::getConnection(IllRequestPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        $con->beginTransaction();
        $isInsert = $this->isNew();
        try {
            $ret = $this->preSave($con);
            if ($isInsert) {
                $ret = $ret && $this->preInsert($con);
                // timestampable behavior
                if (!$this->isColumnModified(IllRequestPeer::DATE_CREATED)) {
                    $this->setDateCreated(time());
                }
                if (!$this->isColumnModified(IllRequestPeer::DATE_UPDATED)) {
                    $this->setDateUpdated(time());
                }
                // librariantrace behavior
                $librarianId = (class_exists('Prado') && (Prado::getApplication() instanceof TApplication) && ($u = Prado::getApplication()->getUser()) instanceof ClavisLibrarian && $u->getId() > 0) ? $u->getId() : 1 ;
                if (!$this->isColumnModified(IllRequestPeer::CREATED_BY)) {
                    $this->setCreatedBy($librarianId);
                }
                if (!$this->isColumnModified(IllRequestPeer::MODIFIED_BY)) {
                    $this->setModifiedBy($librarianId);
                }
            } else {
                $ret = $ret && $this->preUpdate($con);
                // timestampable behavior
                if ($this->isModified() && !$this->isColumnModified(IllRequestPeer::DATE_UPDATED)) {
                    $this->setDateUpdated(time());
                }
                // librariantrace behavior
                if ($this->isModified() && !$this->isColumnModified(IllRequestPeer::MODIFIED_BY)) {
                    $this->setModifiedBy((class_exists('Prado') && (Prado::getApplication() instanceof TApplication) && ($u = Prado::getApplication()->getUser()) instanceof ClavisLibrarian && $u->getId() > 0) ? $u->getId() : 1 );
                }
            }
            if ($ret) {
                $affectedRows = $this->doSave($con);
                if ($isInsert) {
                    $this->postInsert($con);
                } else {
                    $this->postUpdate($con);
                }
                $this->postSave($con);
                IllRequestPeer::addInstanceToPool($this);
            } else {
                $affectedRows = 0;
            }
            $con->commit();

            return $affectedRows;
        } catch (Exception $e) {
            $con->rollBack();
            throw $e;
        }
    }

    /**
     * Performs the work of inserting or updating the row in the database.
     *
     * If the object is new, it inserts it; otherwise an update is performed.
     * All related objects are also updated in this method.
     *
     * @param PropelPDO $con
     * @return int             The number of rows affected by this insert/update and any referring fk objects' save() operations.
     * @throws PropelException
     * @see        save()
     */
    protected function doSave(PropelPDO $con)
    {
        $affectedRows = 0; // initialize var to track total num of affected rows
        if (!$this->alreadyInSave) {
            $this->alreadyInSave = true;

            // We call the save method on the following object(s) if they
            // were passed to this object by their corresponding set
            // method.  This object relates to these object(s) by a
            // foreign key reference.

            if ($this->aLibrarianRelatedByCreatedBy !== null) {
                if ($this->aLibrarianRelatedByCreatedBy->isModified() || $this->aLibrarianRelatedByCreatedBy->isNew()) {
                    $affectedRows += $this->aLibrarianRelatedByCreatedBy->save($con);
                }
                $this->setLibrarianRelatedByCreatedBy($this->aLibrarianRelatedByCreatedBy);
            }

            if ($this->aLibrarianRelatedByModifiedBy !== null) {
                if ($this->aLibrarianRelatedByModifiedBy->isModified() || $this->aLibrarianRelatedByModifiedBy->isNew()) {
                    $affectedRows += $this->aLibrarianRelatedByModifiedBy->save($con);
                }
                $this->setLibrarianRelatedByModifiedBy($this->aLibrarianRelatedByModifiedBy);
            }

            if ($this->isNew() || $this->isModified()) {
                // persist changes
                if ($this->isNew()) {
                    $this->doInsert($con);
                } else {
                    $this->doUpdate($con);
                }
                $affectedRows += 1;
                $this->resetModified();
            }

            $this->alreadyInSave = false;

        }

        return $affectedRows;
    } // doSave()

    /**
     * Insert the row in the database.
     *
     * @param PropelPDO $con
     *
     * @throws PropelException
     * @see        doSave()
     */
    protected function doInsert(PropelPDO $con)
    {
        $modifiedColumns = array();
        $index = 0;

        $this->modifiedColumns[] = IllRequestPeer::ILL_REQUEST_ID;
        if (null !== $this->ill_request_id) {
            throw new PropelException('Cannot insert a value for auto-increment primary key (' . IllRequestPeer::ILL_REQUEST_ID . ')');
        }

         // check the columns in natural order for more readable SQL queries
        if ($this->isColumnModified(IllRequestPeer::ILL_REQUEST_ID)) {
            $modifiedColumns[':p' . $index++]  = '`ill_request_id`';
        }
        if ($this->isColumnModified(IllRequestPeer::REQUEST_STATUS)) {
            $modifiedColumns[':p' . $index++]  = '`request_status`';
        }
        if ($this->isColumnModified(IllRequestPeer::REQUEST_DATE)) {
            $modifiedColumns[':p' . $index++]  = '`request_date`';
        }
        if ($this->isColumnModified(IllRequestPeer::FROM_LIBRARY_ID)) {
            $modifiedColumns[':p' . $index++]  = '`from_library_id`';
        }
        if ($this->isColumnModified(IllRequestPeer::TO_LIBRARY_ID)) {
            $modifiedColumns[':p' . $index++]  = '`to_library_id`';
        }
        if ($this->isColumnModified(IllRequestPeer::PATRON_ID)) {
            $modifiedColumns[':p' . $index++]  = '`patron_id`';
        }
        if ($this->isColumnModified(IllRequestPeer::REQUEST_KEY)) {
            $modifiedColumns[':p' . $index++]  = '`request_key`';
        }
        if ($this->isColumnModified(IllRequestPeer::LIBRARIAN_ID)) {
            $modifiedColumns[':p' . $index++]  = '`librarian_id`';
        }
        if ($this->isColumnModified(IllRequestPeer::ITEM_LOCATION)) {
            $modifiedColumns[':p' . $index++]  = '`item_location`';
        }
        if ($this->isColumnModified(IllRequestPeer::ITEM_TITLE)) {
            $modifiedColumns[':p' . $index++]  = '`item_title`';
        }
        if ($this->isColumnModified(IllRequestPeer::START_LOAN_DATE)) {
            $modifiedColumns[':p' . $index++]  = '`start_loan_date`';
        }
        if ($this->isColumnModified(IllRequestPeer::DUE_DATE)) {
            $modifiedColumns[':p' . $index++]  = '`due_date`';
        }
        if ($this->isColumnModified(IllRequestPeer::TITLE)) {
            $modifiedColumns[':p' . $index++]  = '`title`';
        }
        if ($this->isColumnModified(IllRequestPeer::UNIMARC)) {
            $modifiedColumns[':p' . $index++]  = '`unimarc`';
        }
        if ($this->isColumnModified(IllRequestPeer::DATE_CREATED)) {
            $modifiedColumns[':p' . $index++]  = '`date_created`';
        }
        if ($this->isColumnModified(IllRequestPeer::DATE_UPDATED)) {
            $modifiedColumns[':p' . $index++]  = '`date_updated`';
        }
        if ($this->isColumnModified(IllRequestPeer::CREATED_BY)) {
            $modifiedColumns[':p' . $index++]  = '`created_by`';
        }
        if ($this->isColumnModified(IllRequestPeer::MODIFIED_BY)) {
            $modifiedColumns[':p' . $index++]  = '`modified_by`';
        }

        $sql = sprintf(
            'INSERT INTO `ill_request` (%s) VALUES (%s)',
            implode(', ', $modifiedColumns),
            implode(', ', array_keys($modifiedColumns))
        );

        try {
            $stmt = $con->prepare($sql);
            foreach ($modifiedColumns as $identifier => $columnName) {
                switch ($columnName) {
                    case '`ill_request_id`':
                        $stmt->bindValue($identifier, $this->ill_request_id, PDO::PARAM_INT);
                        break;
                    case '`request_status`':
                        $stmt->bindValue($identifier, $this->request_status, PDO::PARAM_STR);
                        break;
                    case '`request_date`':
                        $stmt->bindValue($identifier, $this->request_date, PDO::PARAM_STR);
                        break;
                    case '`from_library_id`':
                        $stmt->bindValue($identifier, $this->from_library_id, PDO::PARAM_INT);
                        break;
                    case '`to_library_id`':
                        $stmt->bindValue($identifier, $this->to_library_id, PDO::PARAM_INT);
                        break;
                    case '`patron_id`':
                        $stmt->bindValue($identifier, $this->patron_id, PDO::PARAM_INT);
                        break;
                    case '`request_key`':
                        $stmt->bindValue($identifier, $this->request_key, PDO::PARAM_STR);
                        break;
                    case '`librarian_id`':
                        $stmt->bindValue($identifier, $this->librarian_id, PDO::PARAM_INT);
                        break;
                    case '`item_location`':
                        $stmt->bindValue($identifier, $this->item_location, PDO::PARAM_STR);
                        break;
                    case '`item_title`':
                        $stmt->bindValue($identifier, $this->item_title, PDO::PARAM_STR);
                        break;
                    case '`start_loan_date`':
                        $stmt->bindValue($identifier, $this->start_loan_date, PDO::PARAM_STR);
                        break;
                    case '`due_date`':
                        $stmt->bindValue($identifier, $this->due_date, PDO::PARAM_STR);
                        break;
                    case '`title`':
                        $stmt->bindValue($identifier, $this->title, PDO::PARAM_STR);
                        break;
                    case '`unimarc`':
                        $stmt->bindValue($identifier, $this->unimarc, PDO::PARAM_STR);
                        break;
                    case '`date_created`':
                        $stmt->bindValue($identifier, $this->date_created, PDO::PARAM_STR);
                        break;
                    case '`date_updated`':
                        $stmt->bindValue($identifier, $this->date_updated, PDO::PARAM_STR);
                        break;
                    case '`created_by`':
                        $stmt->bindValue($identifier, $this->created_by, PDO::PARAM_INT);
                        break;
                    case '`modified_by`':
                        $stmt->bindValue($identifier, $this->modified_by, PDO::PARAM_INT);
                        break;
                }
            }
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute INSERT statement [%s]', $sql), $e);
        }

        try {
            $pk = $con->lastInsertId();
        } catch (Exception $e) {
            throw new PropelException('Unable to get autoincrement id.', $e);
        }
        $this->setIllRequestId($pk);

        $this->setNew(false);
    }

    /**
     * Update the row in the database.
     *
     * @param PropelPDO $con
     *
     * @see        doSave()
     */
    protected function doUpdate(PropelPDO $con)
    {
        $selectCriteria = $this->buildPkeyCriteria();
        $valuesCriteria = $this->buildCriteria();
        BasePeer::doUpdate($selectCriteria, $valuesCriteria, $con);
    }

    /**
     * Array of ValidationFailed objects.
     * @var        array ValidationFailed[]
     */
    protected $validationFailures = array();

    /**
     * Gets any ValidationFailed objects that resulted from last call to validate().
     *
     *
     * @return array ValidationFailed[]
     * @see        validate()
     */
    public function getValidationFailures()
    {
        return $this->validationFailures;
    }

    /**
     * Validates the objects modified field values and all objects related to this table.
     *
     * If $columns is either a column name or an array of column names
     * only those columns are validated.
     *
     * @param mixed $columns Column name or an array of column names.
     * @return boolean Whether all columns pass validation.
     * @see        doValidate()
     * @see        getValidationFailures()
     */
    public function validate($columns = null)
    {
        $res = $this->doValidate($columns);
        if ($res === true) {
            $this->validationFailures = array();

            return true;
        }

        $this->validationFailures = $res;

        return false;
    }

    /**
     * This function performs the validation work for complex object models.
     *
     * In addition to checking the current object, all related objects will
     * also be validated.  If all pass then <code>true</code> is returned; otherwise
     * an aggregated array of ValidationFailed objects will be returned.
     *
     * @param array $columns Array of column names to validate.
     * @return mixed <code>true</code> if all validations pass; array of <code>ValidationFailed</code> objects otherwise.
     */
    protected function doValidate($columns = null)
    {
        if (!$this->alreadyInValidation) {
            $this->alreadyInValidation = true;
            $retval = null;

            $failureMap = array();


            // We call the validate method on the following object(s) if they
            // were passed to this object by their corresponding set
            // method.  This object relates to these object(s) by a
            // foreign key reference.

            if ($this->aLibrarianRelatedByCreatedBy !== null) {
                if (!$this->aLibrarianRelatedByCreatedBy->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aLibrarianRelatedByCreatedBy->getValidationFailures());
                }
            }

            if ($this->aLibrarianRelatedByModifiedBy !== null) {
                if (!$this->aLibrarianRelatedByModifiedBy->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aLibrarianRelatedByModifiedBy->getValidationFailures());
                }
            }


            if (($retval = IllRequestPeer::doValidate($this, $columns)) !== true) {
                $failureMap = array_merge($failureMap, $retval);
            }



            $this->alreadyInValidation = false;
        }

        return (!empty($failureMap) ? $failureMap : true);
    }

    /**
     * Retrieves a field from the object by name passed in as a string.
     *
     * @param string $name name
     * @param string $type The type of fieldname the $name is of:
     *               one of the class type constants BasePeer::TYPE_PHPNAME, BasePeer::TYPE_STUDLYPHPNAME
     *               BasePeer::TYPE_COLNAME, BasePeer::TYPE_FIELDNAME, BasePeer::TYPE_NUM.
     *               Defaults to BasePeer::TYPE_PHPNAME
     * @return mixed Value of field.
     */
    public function getByName($name, $type = BasePeer::TYPE_PHPNAME)
    {
        $pos = IllRequestPeer::translateFieldName($name, $type, BasePeer::TYPE_NUM);
        $field = $this->getByPosition($pos);

        return $field;
    }

    /**
     * Retrieves a field from the object by Position as specified in the xml schema.
     * Zero-based.
     *
     * @param int $pos position in xml schema
     * @return mixed Value of field at $pos
     */
    public function getByPosition($pos)
    {
        switch ($pos) {
            case 0:
                return $this->getIllRequestId();
                break;
            case 1:
                return $this->getRequestStatus();
                break;
            case 2:
                return $this->getRequestDate();
                break;
            case 3:
                return $this->getFromLibraryId();
                break;
            case 4:
                return $this->getToLibraryId();
                break;
            case 5:
                return $this->getPatronId();
                break;
            case 6:
                return $this->getRequestKey();
                break;
            case 7:
                return $this->getLibrarianId();
                break;
            case 8:
                return $this->getItemLocation();
                break;
            case 9:
                return $this->getItemTitle();
                break;
            case 10:
                return $this->getStartLoanDate();
                break;
            case 11:
                return $this->getDueDate();
                break;
            case 12:
                return $this->getTitle();
                break;
            case 13:
                return $this->getUnimarc();
                break;
            case 14:
                return $this->getDateCreated();
                break;
            case 15:
                return $this->getDateUpdated();
                break;
            case 16:
                return $this->getCreatedBy();
                break;
            case 17:
                return $this->getModifiedBy();
                break;
            default:
                return null;
                break;
        } // switch()
    }

    /**
     * Exports the object as an array.
     *
     * You can specify the key type of the array by passing one of the class
     * type constants.
     *
     * @param     string  $keyType (optional) One of the class type constants BasePeer::TYPE_PHPNAME, BasePeer::TYPE_STUDLYPHPNAME,
     *                    BasePeer::TYPE_COLNAME, BasePeer::TYPE_FIELDNAME, BasePeer::TYPE_NUM.
     *                    Defaults to BasePeer::TYPE_PHPNAME.
     * @param     boolean $includeLazyLoadColumns (optional) Whether to include lazy loaded columns. Defaults to true.
     * @param     array $alreadyDumpedObjects List of objects to skip to avoid recursion
     * @param     boolean $includeForeignObjects (optional) Whether to include hydrated related objects. Default to FALSE.
     *
     * @return array an associative array containing the field names (as keys) and field values
     */
    public function toArray($keyType = BasePeer::TYPE_PHPNAME, $includeLazyLoadColumns = true, $alreadyDumpedObjects = array(), $includeForeignObjects = false)
    {
        if (isset($alreadyDumpedObjects['IllRequest'][$this->getPrimaryKey()])) {
            return '*RECURSION*';
        }
        $alreadyDumpedObjects['IllRequest'][$this->getPrimaryKey()] = true;
        $keys = IllRequestPeer::getFieldNames($keyType);
        $result = array(
            $keys[0] => $this->getIllRequestId(),
            $keys[1] => $this->getRequestStatus(),
            $keys[2] => $this->getRequestDate(),
            $keys[3] => $this->getFromLibraryId(),
            $keys[4] => $this->getToLibraryId(),
            $keys[5] => $this->getPatronId(),
            $keys[6] => $this->getRequestKey(),
            $keys[7] => $this->getLibrarianId(),
            $keys[8] => $this->getItemLocation(),
            $keys[9] => $this->getItemTitle(),
            $keys[10] => $this->getStartLoanDate(),
            $keys[11] => $this->getDueDate(),
            $keys[12] => $this->getTitle(),
            $keys[13] => $this->getUnimarc(),
            $keys[14] => $this->getDateCreated(),
            $keys[15] => $this->getDateUpdated(),
            $keys[16] => $this->getCreatedBy(),
            $keys[17] => $this->getModifiedBy(),
        );
        $virtualColumns = $this->virtualColumns;
        foreach ($virtualColumns as $key => $virtualColumn) {
            $result[$key] = $virtualColumn;
        }

        if ($includeForeignObjects) {
            if (null !== $this->aLibrarianRelatedByCreatedBy) {
                $result['LibrarianRelatedByCreatedBy'] = $this->aLibrarianRelatedByCreatedBy->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->aLibrarianRelatedByModifiedBy) {
                $result['LibrarianRelatedByModifiedBy'] = $this->aLibrarianRelatedByModifiedBy->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
        }

        return $result;
    }

    /**
     * Sets a field from the object by name passed in as a string.
     *
     * @param string $name peer name
     * @param mixed $value field value
     * @param string $type The type of fieldname the $name is of:
     *                     one of the class type constants BasePeer::TYPE_PHPNAME, BasePeer::TYPE_STUDLYPHPNAME
     *                     BasePeer::TYPE_COLNAME, BasePeer::TYPE_FIELDNAME, BasePeer::TYPE_NUM.
     *                     Defaults to BasePeer::TYPE_PHPNAME
     * @return void
     */
    public function setByName($name, $value, $type = BasePeer::TYPE_PHPNAME)
    {
        $pos = IllRequestPeer::translateFieldName($name, $type, BasePeer::TYPE_NUM);

        $this->setByPosition($pos, $value);
    }

    /**
     * Sets a field from the object by Position as specified in the xml schema.
     * Zero-based.
     *
     * @param int $pos position in xml schema
     * @param mixed $value field value
     * @return void
     */
    public function setByPosition($pos, $value)
    {
        switch ($pos) {
            case 0:
                $this->setIllRequestId($value);
                break;
            case 1:
                $this->setRequestStatus($value);
                break;
            case 2:
                $this->setRequestDate($value);
                break;
            case 3:
                $this->setFromLibraryId($value);
                break;
            case 4:
                $this->setToLibraryId($value);
                break;
            case 5:
                $this->setPatronId($value);
                break;
            case 6:
                $this->setRequestKey($value);
                break;
            case 7:
                $this->setLibrarianId($value);
                break;
            case 8:
                $this->setItemLocation($value);
                break;
            case 9:
                $this->setItemTitle($value);
                break;
            case 10:
                $this->setStartLoanDate($value);
                break;
            case 11:
                $this->setDueDate($value);
                break;
            case 12:
                $this->setTitle($value);
                break;
            case 13:
                $this->setUnimarc($value);
                break;
            case 14:
                $this->setDateCreated($value);
                break;
            case 15:
                $this->setDateUpdated($value);
                break;
            case 16:
                $this->setCreatedBy($value);
                break;
            case 17:
                $this->setModifiedBy($value);
                break;
        } // switch()
    }

    /**
     * Populates the object using an array.
     *
     * This is particularly useful when populating an object from one of the
     * request arrays (e.g. $_POST).  This method goes through the column
     * names, checking to see whether a matching key exists in populated
     * array. If so the setByName() method is called for that column.
     *
     * You can specify the key type of the array by additionally passing one
     * of the class type constants BasePeer::TYPE_PHPNAME, BasePeer::TYPE_STUDLYPHPNAME,
     * BasePeer::TYPE_COLNAME, BasePeer::TYPE_FIELDNAME, BasePeer::TYPE_NUM.
     * The default key type is the column's BasePeer::TYPE_PHPNAME
     *
     * @param array  $arr     An array to populate the object from.
     * @param string $keyType The type of keys the array uses.
     * @return void
     */
    public function fromArray($arr, $keyType = BasePeer::TYPE_PHPNAME)
    {
        $keys = IllRequestPeer::getFieldNames($keyType);

        if (array_key_exists($keys[0], $arr)) $this->setIllRequestId($arr[$keys[0]]);
        if (array_key_exists($keys[1], $arr)) $this->setRequestStatus($arr[$keys[1]]);
        if (array_key_exists($keys[2], $arr)) $this->setRequestDate($arr[$keys[2]]);
        if (array_key_exists($keys[3], $arr)) $this->setFromLibraryId($arr[$keys[3]]);
        if (array_key_exists($keys[4], $arr)) $this->setToLibraryId($arr[$keys[4]]);
        if (array_key_exists($keys[5], $arr)) $this->setPatronId($arr[$keys[5]]);
        if (array_key_exists($keys[6], $arr)) $this->setRequestKey($arr[$keys[6]]);
        if (array_key_exists($keys[7], $arr)) $this->setLibrarianId($arr[$keys[7]]);
        if (array_key_exists($keys[8], $arr)) $this->setItemLocation($arr[$keys[8]]);
        if (array_key_exists($keys[9], $arr)) $this->setItemTitle($arr[$keys[9]]);
        if (array_key_exists($keys[10], $arr)) $this->setStartLoanDate($arr[$keys[10]]);
        if (array_key_exists($keys[11], $arr)) $this->setDueDate($arr[$keys[11]]);
        if (array_key_exists($keys[12], $arr)) $this->setTitle($arr[$keys[12]]);
        if (array_key_exists($keys[13], $arr)) $this->setUnimarc($arr[$keys[13]]);
        if (array_key_exists($keys[14], $arr)) $this->setDateCreated($arr[$keys[14]]);
        if (array_key_exists($keys[15], $arr)) $this->setDateUpdated($arr[$keys[15]]);
        if (array_key_exists($keys[16], $arr)) $this->setCreatedBy($arr[$keys[16]]);
        if (array_key_exists($keys[17], $arr)) $this->setModifiedBy($arr[$keys[17]]);
    }

    /**
     * Build a Criteria object containing the values of all modified columns in this object.
     *
     * @return Criteria The Criteria object containing all modified values.
     */
    public function buildCriteria()
    {
        $criteria = new Criteria(IllRequestPeer::DATABASE_NAME);

        if ($this->isColumnModified(IllRequestPeer::ILL_REQUEST_ID)) $criteria->add(IllRequestPeer::ILL_REQUEST_ID, $this->ill_request_id);
        if ($this->isColumnModified(IllRequestPeer::REQUEST_STATUS)) $criteria->add(IllRequestPeer::REQUEST_STATUS, $this->request_status);
        if ($this->isColumnModified(IllRequestPeer::REQUEST_DATE)) $criteria->add(IllRequestPeer::REQUEST_DATE, $this->request_date);
        if ($this->isColumnModified(IllRequestPeer::FROM_LIBRARY_ID)) $criteria->add(IllRequestPeer::FROM_LIBRARY_ID, $this->from_library_id);
        if ($this->isColumnModified(IllRequestPeer::TO_LIBRARY_ID)) $criteria->add(IllRequestPeer::TO_LIBRARY_ID, $this->to_library_id);
        if ($this->isColumnModified(IllRequestPeer::PATRON_ID)) $criteria->add(IllRequestPeer::PATRON_ID, $this->patron_id);
        if ($this->isColumnModified(IllRequestPeer::REQUEST_KEY)) $criteria->add(IllRequestPeer::REQUEST_KEY, $this->request_key);
        if ($this->isColumnModified(IllRequestPeer::LIBRARIAN_ID)) $criteria->add(IllRequestPeer::LIBRARIAN_ID, $this->librarian_id);
        if ($this->isColumnModified(IllRequestPeer::ITEM_LOCATION)) $criteria->add(IllRequestPeer::ITEM_LOCATION, $this->item_location);
        if ($this->isColumnModified(IllRequestPeer::ITEM_TITLE)) $criteria->add(IllRequestPeer::ITEM_TITLE, $this->item_title);
        if ($this->isColumnModified(IllRequestPeer::START_LOAN_DATE)) $criteria->add(IllRequestPeer::START_LOAN_DATE, $this->start_loan_date);
        if ($this->isColumnModified(IllRequestPeer::DUE_DATE)) $criteria->add(IllRequestPeer::DUE_DATE, $this->due_date);
        if ($this->isColumnModified(IllRequestPeer::TITLE)) $criteria->add(IllRequestPeer::TITLE, $this->title);
        if ($this->isColumnModified(IllRequestPeer::UNIMARC)) $criteria->add(IllRequestPeer::UNIMARC, $this->unimarc);
        if ($this->isColumnModified(IllRequestPeer::DATE_CREATED)) $criteria->add(IllRequestPeer::DATE_CREATED, $this->date_created);
        if ($this->isColumnModified(IllRequestPeer::DATE_UPDATED)) $criteria->add(IllRequestPeer::DATE_UPDATED, $this->date_updated);
        if ($this->isColumnModified(IllRequestPeer::CREATED_BY)) $criteria->add(IllRequestPeer::CREATED_BY, $this->created_by);
        if ($this->isColumnModified(IllRequestPeer::MODIFIED_BY)) $criteria->add(IllRequestPeer::MODIFIED_BY, $this->modified_by);

        return $criteria;
    }

    /**
     * Builds a Criteria object containing the primary key for this object.
     *
     * Unlike buildCriteria() this method includes the primary key values regardless
     * of whether or not they have been modified.
     *
     * @return Criteria The Criteria object containing value(s) for primary key(s).
     */
    public function buildPkeyCriteria()
    {
        $criteria = new Criteria(IllRequestPeer::DATABASE_NAME);
        $criteria->add(IllRequestPeer::ILL_REQUEST_ID, $this->ill_request_id);

        return $criteria;
    }

    /**
     * Returns the primary key for this object (row).
     * @return int
     */
    public function getPrimaryKey()
    {
        return $this->getIllRequestId();
    }

    /**
     * Generic method to set the primary key (ill_request_id column).
     *
     * @param  int $key Primary key.
     * @return void
     */
    public function setPrimaryKey($key)
    {
        $this->setIllRequestId($key);
    }

    /**
     * Returns true if the primary key for this object is null.
     * @return boolean
     */
    public function isPrimaryKeyNull()
    {

        return null === $this->getIllRequestId();
    }

    /**
     * Sets contents of passed object to values from current object.
     *
     * If desired, this method can also make copies of all associated (fkey referrers)
     * objects.
     *
     * @param object $copyObj An object of IllRequest (or compatible) type.
     * @param boolean $deepCopy Whether to also copy all rows that refer (by fkey) to the current row.
     * @param boolean $makeNew Whether to reset autoincrement PKs and make the object new.
     * @throws PropelException
     */
    public function copyInto($copyObj, $deepCopy = false, $makeNew = true)
    {
        $copyObj->setRequestStatus($this->getRequestStatus());
        $copyObj->setRequestDate($this->getRequestDate());
        $copyObj->setFromLibraryId($this->getFromLibraryId());
        $copyObj->setToLibraryId($this->getToLibraryId());
        $copyObj->setPatronId($this->getPatronId());
        $copyObj->setRequestKey($this->getRequestKey());
        $copyObj->setLibrarianId($this->getLibrarianId());
        $copyObj->setItemLocation($this->getItemLocation());
        $copyObj->setItemTitle($this->getItemTitle());
        $copyObj->setStartLoanDate($this->getStartLoanDate());
        $copyObj->setDueDate($this->getDueDate());
        $copyObj->setTitle($this->getTitle());
        $copyObj->setUnimarc($this->getUnimarc());
        $copyObj->setDateCreated($this->getDateCreated());
        $copyObj->setDateUpdated($this->getDateUpdated());
        $copyObj->setCreatedBy($this->getCreatedBy());
        $copyObj->setModifiedBy($this->getModifiedBy());

        if ($deepCopy && !$this->startCopy) {
            // important: temporarily setNew(false) because this affects the behavior of
            // the getter/setter methods for fkey referrer objects.
            $copyObj->setNew(false);
            // store object hash to prevent cycle
            $this->startCopy = true;

            //unflag object copy
            $this->startCopy = false;
        } // if ($deepCopy)

        if ($makeNew) {
            $copyObj->setNew(true);
            $copyObj->setIllRequestId(NULL); // this is a auto-increment column, so set to default value
        }
    }

    /**
     * Makes a copy of this object that will be inserted as a new row in table when saved.
     * It creates a new object filling in the simple attributes, but skipping any primary
     * keys that are defined for the table.
     *
     * If desired, this method can also make copies of all associated (fkey referrers)
     * objects.
     *
     * @param boolean $deepCopy Whether to also copy all rows that refer (by fkey) to the current row.
     * @return IllRequest Clone of current object.
     * @throws PropelException
     */
    public function copy($deepCopy = false)
    {
        // we use get_class(), because this might be a subclass
        $clazz = get_class($this);
        $copyObj = new $clazz();
        $this->copyInto($copyObj, $deepCopy);

        return $copyObj;
    }

    /**
     * Returns a peer instance associated with this om.
     *
     * Since Peer classes are not to have any instance attributes, this method returns the
     * same instance for all member of this class. The method could therefore
     * be static, but this would prevent one from overriding the behavior.
     *
     * @return IllRequestPeer
     */
    public function getPeer()
    {
        if (self::$peer === null) {
            self::$peer = new IllRequestPeer();
        }

        return self::$peer;
    }

    /**
     * Declares an association between this object and a Librarian object.
     *
     * @param                  Librarian $v
     * @return IllRequest The current object (for fluent API support)
     * @throws PropelException
     */
    public function setLibrarianRelatedByCreatedBy(Librarian $v = null)
    {
        if ($v === null) {
            $this->setCreatedBy(NULL);
        } else {
            $this->setCreatedBy($v->getLibrarianId());
        }

        $this->aLibrarianRelatedByCreatedBy = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the Librarian object, it will not be re-added.
        if ($v !== null) {
            $v->addIllRequestRelatedByCreatedBy($this);
        }


        return $this;
    }


    /**
     * Get the associated Librarian object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return Librarian The associated Librarian object.
     * @throws PropelException
     */
    public function getLibrarianRelatedByCreatedBy(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aLibrarianRelatedByCreatedBy === null && ($this->created_by !== null) && $doQuery) {
            $this->aLibrarianRelatedByCreatedBy = LibrarianQuery::create()->findPk($this->created_by, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aLibrarianRelatedByCreatedBy->addIllRequestsRelatedByCreatedBy($this);
             */
        }

        return $this->aLibrarianRelatedByCreatedBy;
    }

    /**
     * Declares an association between this object and a Librarian object.
     *
     * @param                  Librarian $v
     * @return IllRequest The current object (for fluent API support)
     * @throws PropelException
     */
    public function setLibrarianRelatedByModifiedBy(Librarian $v = null)
    {
        if ($v === null) {
            $this->setModifiedBy(NULL);
        } else {
            $this->setModifiedBy($v->getLibrarianId());
        }

        $this->aLibrarianRelatedByModifiedBy = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the Librarian object, it will not be re-added.
        if ($v !== null) {
            $v->addIllRequestRelatedByModifiedBy($this);
        }


        return $this;
    }


    /**
     * Get the associated Librarian object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return Librarian The associated Librarian object.
     * @throws PropelException
     */
    public function getLibrarianRelatedByModifiedBy(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aLibrarianRelatedByModifiedBy === null && ($this->modified_by !== null) && $doQuery) {
            $this->aLibrarianRelatedByModifiedBy = LibrarianQuery::create()->findPk($this->modified_by, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aLibrarianRelatedByModifiedBy->addIllRequestsRelatedByModifiedBy($this);
             */
        }

        return $this->aLibrarianRelatedByModifiedBy;
    }

    /**
     * Clears the current object and sets all attributes to their default values
     */
    public function clear()
    {
        $this->ill_request_id = null;
        $this->request_status = null;
        $this->request_date = null;
        $this->from_library_id = null;
        $this->to_library_id = null;
        $this->patron_id = null;
        $this->request_key = null;
        $this->librarian_id = null;
        $this->item_location = null;
        $this->item_title = null;
        $this->start_loan_date = null;
        $this->due_date = null;
        $this->title = null;
        $this->unimarc = null;
        $this->date_created = null;
        $this->date_updated = null;
        $this->created_by = null;
        $this->modified_by = null;
        $this->alreadyInSave = false;
        $this->alreadyInValidation = false;
        $this->alreadyInClearAllReferencesDeep = false;
        $this->clearAllReferences();
        $this->resetModified();
        $this->setNew(true);
        $this->setDeleted(false);
    }

    /**
     * Resets all references to other model objects or collections of model objects.
     *
     * This method is a user-space workaround for PHP's inability to garbage collect
     * objects with circular references (even in PHP 5.3). This is currently necessary
     * when using Propel in certain daemon or large-volume/high-memory operations.
     *
     * @param boolean $deep Whether to also clear the references on all referrer objects.
     */
    public function clearAllReferences($deep = false)
    {
        if ($deep && !$this->alreadyInClearAllReferencesDeep) {
            $this->alreadyInClearAllReferencesDeep = true;
            if ($this->aLibrarianRelatedByCreatedBy instanceof Persistent) {
              $this->aLibrarianRelatedByCreatedBy->clearAllReferences($deep);
            }
            if ($this->aLibrarianRelatedByModifiedBy instanceof Persistent) {
              $this->aLibrarianRelatedByModifiedBy->clearAllReferences($deep);
            }

            $this->alreadyInClearAllReferencesDeep = false;
        } // if ($deep)

        $this->aLibrarianRelatedByCreatedBy = null;
        $this->aLibrarianRelatedByModifiedBy = null;
    }

    /**
     * return the string representation of this object
     *
     * @return string
     */
    public function __toString()
    {
        return (string) $this->exportTo(IllRequestPeer::DEFAULT_STRING_FORMAT);
    }

    /**
     * return true is the object is in saving state
     *
     * @return boolean
     */
    public function isAlreadyInSave()
    {
        return $this->alreadyInSave;
    }

    // timestampable behavior

    /**
     * Mark the current object so that the update date doesn't get updated during next save
     *
     * @return     IllRequest The current object (for fluent API support)
     */
    public function keepUpdateDateUnchanged()
    {
        $this->modifiedColumns[] = IllRequestPeer::DATE_UPDATED;

        return $this;
    }

    // librariantrace behavior

    /**
     * Returns the complete name of the librarian that created this object.
     *
     * @return string
     */
    public function getCreatedByNameString()
    {
        $l = $this->getLibrarianRelatedByCreatedBy();
        return ($l instanceof Librarian) ? $l->getCompleteName() : '';
    }

    /**
     * Returns the complete name of the librarian that last updated this object.
     *
     * @return string
     */
    public function getModifiedByNameString()
    {
        $l = $this->getLibrarianRelatedByModifiedBy();
        return ($l instanceof Librarian) ? $l->getCompleteName() : '';
    }

    /**
     * Mark the current object so that the update date doesn't get updated during next save
     *
     * @return     IllRequest The current object (for fluent API support)
     */
    public function keepUpdateLibrarianUnchanged()
    {
        $this->modifiedColumns[] = IllRequestPeer::MODIFIED_BY;
        return $this;
    }

}
