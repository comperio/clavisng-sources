<?php


/**
 * Base class that represents a query for the 'clavis_param' table.
 *
 *
 *
 * @method ClavisParamQuery orderByParamName($order = Criteria::ASC) Order by the param_name column
 * @method ClavisParamQuery orderByLibraryId($order = Criteria::ASC) Order by the library_id column
 * @method ClavisParamQuery orderByLibrarianId($order = Criteria::ASC) Order by the librarian_id column
 * @method ClavisParamQuery orderByParamClass($order = Criteria::ASC) Order by the param_class column
 * @method ClavisParamQuery orderByParamValue($order = Criteria::ASC) Order by the param_value column
 *
 * @method ClavisParamQuery groupByParamName() Group by the param_name column
 * @method ClavisParamQuery groupByLibraryId() Group by the library_id column
 * @method ClavisParamQuery groupByLibrarianId() Group by the librarian_id column
 * @method ClavisParamQuery groupByParamClass() Group by the param_class column
 * @method ClavisParamQuery groupByParamValue() Group by the param_value column
 *
 * @method ClavisParamQuery leftJoin($relation) Adds a LEFT JOIN clause to the query
 * @method ClavisParamQuery rightJoin($relation) Adds a RIGHT JOIN clause to the query
 * @method ClavisParamQuery innerJoin($relation) Adds a INNER JOIN clause to the query
 *
 * @method ClavisParam findOne(PropelPDO $con = null) Return the first ClavisParam matching the query
 * @method ClavisParam findOneOrCreate(PropelPDO $con = null) Return the first ClavisParam matching the query, or a new ClavisParam object populated from the query conditions when no match is found
 *
 * @method ClavisParam findOneByParamName(string $param_name) Return the first ClavisParam filtered by the param_name column
 * @method ClavisParam findOneByLibraryId(int $library_id) Return the first ClavisParam filtered by the library_id column
 * @method ClavisParam findOneByLibrarianId(int $librarian_id) Return the first ClavisParam filtered by the librarian_id column
 * @method ClavisParam findOneByParamClass(string $param_class) Return the first ClavisParam filtered by the param_class column
 * @method ClavisParam findOneByParamValue(string $param_value) Return the first ClavisParam filtered by the param_value column
 *
 * @method array findByParamName(string $param_name) Return ClavisParam objects filtered by the param_name column
 * @method array findByLibraryId(int $library_id) Return ClavisParam objects filtered by the library_id column
 * @method array findByLibrarianId(int $librarian_id) Return ClavisParam objects filtered by the librarian_id column
 * @method array findByParamClass(string $param_class) Return ClavisParam objects filtered by the param_class column
 * @method array findByParamValue(string $param_value) Return ClavisParam objects filtered by the param_value column
 *
 * @package    propel.generator.clavis.om
 */
abstract class BaseClavisParamQuery extends ModelCriteria
{
    /**
     * Initializes internal state of BaseClavisParamQuery object.
     *
     * @param     string $dbName The dabase name
     * @param     string $modelName The phpName of a model, e.g. 'Book'
     * @param     string $modelAlias The alias for the model in this query, e.g. 'b'
     */
    public function __construct($dbName = null, $modelName = null, $modelAlias = null)
    {
        if (null === $dbName) {
            $dbName = 'clavis';
        }
        if (null === $modelName) {
            $modelName = 'ClavisParam';
        }
        parent::__construct($dbName, $modelName, $modelAlias);
    }

    /**
     * Returns a new ClavisParamQuery object.
     *
     * @param     string $modelAlias The alias of a model in the query
     * @param   ClavisParamQuery|Criteria $criteria Optional Criteria to build the query from
     *
     * @return ClavisParamQuery
     */
    public static function create($modelAlias = null, $criteria = null)
    {
        if ($criteria instanceof ClavisParamQuery) {
            return $criteria;
        }
        $query = new ClavisParamQuery(null, null, $modelAlias);

        if ($criteria instanceof Criteria) {
            $query->mergeWith($criteria);
        }

        return $query;
    }

    /**
     * Find object by primary key.
     * Propel uses the instance pool to skip the database if the object exists.
     * Go fast if the query is untouched.
     *
     * <code>
     * $obj = $c->findPk(array(12, 34, 56, 78), $con);
     * </code>
     *
     * @param array $key Primary key to use for the query
                         A Primary key composition: [$param_name, $library_id, $librarian_id, $param_class]
     * @param     PropelPDO $con an optional connection object
     *
     * @return   ClavisParam|ClavisParam[]|mixed the result, formatted by the current formatter
     */
    public function findPk($key, $con = null)
    {
        if ($key === null) {
            return null;
        }
        if ((null !== ($obj = ClavisParamPeer::getInstanceFromPool(serialize(array((string) $key[0], (string) $key[1], (string) $key[2], (string) $key[3]))))) && !$this->formatter) {
            // the object is already in the instance pool
            return $obj;
        }
        if ($con === null) {
            $con = Propel::getConnection(ClavisParamPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        if ($this->formatter || $this->modelAlias || $this->with || $this->select
         || $this->selectColumns || $this->asColumns || $this->selectModifiers
         || $this->map || $this->having || $this->joins) {
            return $this->findPkComplex($key, $con);
        } else {
            return $this->findPkSimple($key, $con);
        }
    }

    /**
     * Find object by primary key using raw SQL to go fast.
     * Bypass doSelect() and the object formatter by using generated code.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 ClavisParam A model object, or null if the key is not found
     * @throws PropelException
     */
    protected function findPkSimple($key, $con)
    {
        $sql = 'SELECT `param_name`, `library_id`, `librarian_id`, `param_class`, `param_value` FROM `clavis_param` WHERE `param_name` = :p0 AND `library_id` = :p1 AND `librarian_id` = :p2 AND `param_class` = :p3';
        try {
            $stmt = $con->prepare($sql);
            $stmt->bindValue(':p0', $key[0], PDO::PARAM_STR);
            $stmt->bindValue(':p1', $key[1], PDO::PARAM_INT);
            $stmt->bindValue(':p2', $key[2], PDO::PARAM_INT);
            $stmt->bindValue(':p3', $key[3], PDO::PARAM_STR);
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute SELECT statement [%s]', $sql), $e);
        }
        $obj = null;
        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $obj = new ClavisParam();
            $obj->hydrate($row);
            ClavisParamPeer::addInstanceToPool($obj, serialize(array((string) $key[0], (string) $key[1], (string) $key[2], (string) $key[3])));
        }
        $stmt->closeCursor();

        return $obj;
    }

    /**
     * Find object by primary key.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return ClavisParam|ClavisParam[]|mixed the result, formatted by the current formatter
     */
    protected function findPkComplex($key, $con)
    {
        // As the query uses a PK condition, no limit(1) is necessary.
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKey($key)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->formatOne($stmt);
    }

    /**
     * Find objects by primary key
     * <code>
     * $objs = $c->findPks(array(array(12, 56), array(832, 123), array(123, 456)), $con);
     * </code>
     * @param     array $keys Primary keys to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return PropelObjectCollection|ClavisParam[]|mixed the list of results, formatted by the current formatter
     */
    public function findPks($keys, $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection($this->getDbName(), Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKeys($keys)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->format($stmt);
    }

    /**
     * Filter the query by primary key
     *
     * @param     mixed $key Primary key to use for the query
     *
     * @return ClavisParamQuery The current query, for fluid interface
     */
    public function filterByPrimaryKey($key)
    {
        $this->addUsingAlias(ClavisParamPeer::PARAM_NAME, $key[0], Criteria::EQUAL);
        $this->addUsingAlias(ClavisParamPeer::LIBRARY_ID, $key[1], Criteria::EQUAL);
        $this->addUsingAlias(ClavisParamPeer::LIBRARIAN_ID, $key[2], Criteria::EQUAL);
        $this->addUsingAlias(ClavisParamPeer::PARAM_CLASS, $key[3], Criteria::EQUAL);

        return $this;
    }

    /**
     * Filter the query by a list of primary keys
     *
     * @param     array $keys The list of primary key to use for the query
     *
     * @return ClavisParamQuery The current query, for fluid interface
     */
    public function filterByPrimaryKeys($keys)
    {
        if (empty($keys)) {
            return $this->add(null, '1<>1', Criteria::CUSTOM);
        }
        foreach ($keys as $key) {
            $cton0 = $this->getNewCriterion(ClavisParamPeer::PARAM_NAME, $key[0], Criteria::EQUAL);
            $cton1 = $this->getNewCriterion(ClavisParamPeer::LIBRARY_ID, $key[1], Criteria::EQUAL);
            $cton0->addAnd($cton1);
            $cton2 = $this->getNewCriterion(ClavisParamPeer::LIBRARIAN_ID, $key[2], Criteria::EQUAL);
            $cton0->addAnd($cton2);
            $cton3 = $this->getNewCriterion(ClavisParamPeer::PARAM_CLASS, $key[3], Criteria::EQUAL);
            $cton0->addAnd($cton3);
            $this->addOr($cton0);
        }

        return $this;
    }

    /**
     * Filter the query on the param_name column
     *
     * Example usage:
     * <code>
     * $query->filterByParamName('fooValue');   // WHERE param_name = 'fooValue'
     * $query->filterByParamName('%fooValue%'); // WHERE param_name LIKE '%fooValue%'
     * </code>
     *
     * @param     string $paramName The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ClavisParamQuery The current query, for fluid interface
     */
    public function filterByParamName($paramName = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($paramName)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $paramName)) {
                $paramName = str_replace('*', '%', $paramName);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(ClavisParamPeer::PARAM_NAME, $paramName, $comparison);
    }

    /**
     * Filter the query on the library_id column
     *
     * Example usage:
     * <code>
     * $query->filterByLibraryId(1234); // WHERE library_id = 1234
     * $query->filterByLibraryId(array(12, 34)); // WHERE library_id IN (12, 34)
     * $query->filterByLibraryId(array('min' => 12)); // WHERE library_id >= 12
     * $query->filterByLibraryId(array('max' => 12)); // WHERE library_id <= 12
     * </code>
     *
     * @param     mixed $libraryId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ClavisParamQuery The current query, for fluid interface
     */
    public function filterByLibraryId($libraryId = null, $comparison = null)
    {
        if (is_array($libraryId)) {
            $useMinMax = false;
            if (isset($libraryId['min'])) {
                $this->addUsingAlias(ClavisParamPeer::LIBRARY_ID, $libraryId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($libraryId['max'])) {
                $this->addUsingAlias(ClavisParamPeer::LIBRARY_ID, $libraryId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ClavisParamPeer::LIBRARY_ID, $libraryId, $comparison);
    }

    /**
     * Filter the query on the librarian_id column
     *
     * Example usage:
     * <code>
     * $query->filterByLibrarianId(1234); // WHERE librarian_id = 1234
     * $query->filterByLibrarianId(array(12, 34)); // WHERE librarian_id IN (12, 34)
     * $query->filterByLibrarianId(array('min' => 12)); // WHERE librarian_id >= 12
     * $query->filterByLibrarianId(array('max' => 12)); // WHERE librarian_id <= 12
     * </code>
     *
     * @param     mixed $librarianId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ClavisParamQuery The current query, for fluid interface
     */
    public function filterByLibrarianId($librarianId = null, $comparison = null)
    {
        if (is_array($librarianId)) {
            $useMinMax = false;
            if (isset($librarianId['min'])) {
                $this->addUsingAlias(ClavisParamPeer::LIBRARIAN_ID, $librarianId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($librarianId['max'])) {
                $this->addUsingAlias(ClavisParamPeer::LIBRARIAN_ID, $librarianId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ClavisParamPeer::LIBRARIAN_ID, $librarianId, $comparison);
    }

    /**
     * Filter the query on the param_class column
     *
     * Example usage:
     * <code>
     * $query->filterByParamClass('fooValue');   // WHERE param_class = 'fooValue'
     * $query->filterByParamClass('%fooValue%'); // WHERE param_class LIKE '%fooValue%'
     * </code>
     *
     * @param     string $paramClass The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ClavisParamQuery The current query, for fluid interface
     */
    public function filterByParamClass($paramClass = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($paramClass)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $paramClass)) {
                $paramClass = str_replace('*', '%', $paramClass);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(ClavisParamPeer::PARAM_CLASS, $paramClass, $comparison);
    }

    /**
     * Filter the query on the param_value column
     *
     * Example usage:
     * <code>
     * $query->filterByParamValue('fooValue');   // WHERE param_value = 'fooValue'
     * $query->filterByParamValue('%fooValue%'); // WHERE param_value LIKE '%fooValue%'
     * </code>
     *
     * @param     string $paramValue The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ClavisParamQuery The current query, for fluid interface
     */
    public function filterByParamValue($paramValue = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($paramValue)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $paramValue)) {
                $paramValue = str_replace('*', '%', $paramValue);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(ClavisParamPeer::PARAM_VALUE, $paramValue, $comparison);
    }

    /**
     * Exclude object from result
     *
     * @param   ClavisParam $clavisParam Object to remove from the list of results
     *
     * @return ClavisParamQuery The current query, for fluid interface
     */
    public function prune($clavisParam = null)
    {
        if ($clavisParam) {
            $this->addCond('pruneCond0', $this->getAliasedColName(ClavisParamPeer::PARAM_NAME), $clavisParam->getParamName(), Criteria::NOT_EQUAL);
            $this->addCond('pruneCond1', $this->getAliasedColName(ClavisParamPeer::LIBRARY_ID), $clavisParam->getLibraryId(), Criteria::NOT_EQUAL);
            $this->addCond('pruneCond2', $this->getAliasedColName(ClavisParamPeer::LIBRARIAN_ID), $clavisParam->getLibrarianId(), Criteria::NOT_EQUAL);
            $this->addCond('pruneCond3', $this->getAliasedColName(ClavisParamPeer::PARAM_CLASS), $clavisParam->getParamClass(), Criteria::NOT_EQUAL);
            $this->combine(array('pruneCond0', 'pruneCond1', 'pruneCond2', 'pruneCond3'), Criteria::LOGICAL_OR);
        }

        return $this;
    }

}
