<?php


/**
 * Base class that represents a query for the 'changelog' table.
 *
 *
 *
 * @method ChangelogQuery orderByEventId($order = Criteria::ASC) Order by the event_id column
 * @method ChangelogQuery orderByEventDate($order = Criteria::ASC) Order by the event_date column
 * @method ChangelogQuery orderByEventDescription($order = Criteria::ASC) Order by the event_description column
 * @method ChangelogQuery orderByEventType($order = Criteria::ASC) Order by the event_type column
 * @method ChangelogQuery orderByObjectId($order = Criteria::ASC) Order by the object_id column
 * @method ChangelogQuery orderByObjectClass($order = Criteria::ASC) Order by the object_class column
 * @method ChangelogQuery orderByUserId($order = Criteria::ASC) Order by the user_id column
 * @method ChangelogQuery orderByUserClass($order = Criteria::ASC) Order by the user_class column
 * @method ChangelogQuery orderBySessionId($order = Criteria::ASC) Order by the session_id column
 * @method ChangelogQuery orderByLibraryId($order = Criteria::ASC) Order by the library_id column
 *
 * @method ChangelogQuery groupByEventId() Group by the event_id column
 * @method ChangelogQuery groupByEventDate() Group by the event_date column
 * @method ChangelogQuery groupByEventDescription() Group by the event_description column
 * @method ChangelogQuery groupByEventType() Group by the event_type column
 * @method ChangelogQuery groupByObjectId() Group by the object_id column
 * @method ChangelogQuery groupByObjectClass() Group by the object_class column
 * @method ChangelogQuery groupByUserId() Group by the user_id column
 * @method ChangelogQuery groupByUserClass() Group by the user_class column
 * @method ChangelogQuery groupBySessionId() Group by the session_id column
 * @method ChangelogQuery groupByLibraryId() Group by the library_id column
 *
 * @method ChangelogQuery leftJoin($relation) Adds a LEFT JOIN clause to the query
 * @method ChangelogQuery rightJoin($relation) Adds a RIGHT JOIN clause to the query
 * @method ChangelogQuery innerJoin($relation) Adds a INNER JOIN clause to the query
 *
 * @method Changelog findOne(PropelPDO $con = null) Return the first Changelog matching the query
 * @method Changelog findOneOrCreate(PropelPDO $con = null) Return the first Changelog matching the query, or a new Changelog object populated from the query conditions when no match is found
 *
 * @method Changelog findOneByEventDate(string $event_date) Return the first Changelog filtered by the event_date column
 * @method Changelog findOneByEventDescription(string $event_description) Return the first Changelog filtered by the event_description column
 * @method Changelog findOneByEventType(string $event_type) Return the first Changelog filtered by the event_type column
 * @method Changelog findOneByObjectId(int $object_id) Return the first Changelog filtered by the object_id column
 * @method Changelog findOneByObjectClass(string $object_class) Return the first Changelog filtered by the object_class column
 * @method Changelog findOneByUserId(int $user_id) Return the first Changelog filtered by the user_id column
 * @method Changelog findOneByUserClass(string $user_class) Return the first Changelog filtered by the user_class column
 * @method Changelog findOneBySessionId(int $session_id) Return the first Changelog filtered by the session_id column
 * @method Changelog findOneByLibraryId(int $library_id) Return the first Changelog filtered by the library_id column
 *
 * @method array findByEventId(int $event_id) Return Changelog objects filtered by the event_id column
 * @method array findByEventDate(string $event_date) Return Changelog objects filtered by the event_date column
 * @method array findByEventDescription(string $event_description) Return Changelog objects filtered by the event_description column
 * @method array findByEventType(string $event_type) Return Changelog objects filtered by the event_type column
 * @method array findByObjectId(int $object_id) Return Changelog objects filtered by the object_id column
 * @method array findByObjectClass(string $object_class) Return Changelog objects filtered by the object_class column
 * @method array findByUserId(int $user_id) Return Changelog objects filtered by the user_id column
 * @method array findByUserClass(string $user_class) Return Changelog objects filtered by the user_class column
 * @method array findBySessionId(int $session_id) Return Changelog objects filtered by the session_id column
 * @method array findByLibraryId(int $library_id) Return Changelog objects filtered by the library_id column
 *
 * @package    propel.generator.clavis.om
 */
abstract class BaseChangelogQuery extends ModelCriteria
{
    /**
     * Initializes internal state of BaseChangelogQuery object.
     *
     * @param     string $dbName The dabase name
     * @param     string $modelName The phpName of a model, e.g. 'Book'
     * @param     string $modelAlias The alias for the model in this query, e.g. 'b'
     */
    public function __construct($dbName = null, $modelName = null, $modelAlias = null)
    {
        if (null === $dbName) {
            $dbName = 'clavis';
        }
        if (null === $modelName) {
            $modelName = 'Changelog';
        }
        parent::__construct($dbName, $modelName, $modelAlias);
    }

    /**
     * Returns a new ChangelogQuery object.
     *
     * @param     string $modelAlias The alias of a model in the query
     * @param   ChangelogQuery|Criteria $criteria Optional Criteria to build the query from
     *
     * @return ChangelogQuery
     */
    public static function create($modelAlias = null, $criteria = null)
    {
        if ($criteria instanceof ChangelogQuery) {
            return $criteria;
        }
        $query = new ChangelogQuery(null, null, $modelAlias);

        if ($criteria instanceof Criteria) {
            $query->mergeWith($criteria);
        }

        return $query;
    }

    /**
     * Find object by primary key.
     * Propel uses the instance pool to skip the database if the object exists.
     * Go fast if the query is untouched.
     *
     * <code>
     * $obj  = $c->findPk(12, $con);
     * </code>
     *
     * @param mixed $key Primary key to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return   Changelog|Changelog[]|mixed the result, formatted by the current formatter
     */
    public function findPk($key, $con = null)
    {
        if ($key === null) {
            return null;
        }
        if ((null !== ($obj = ChangelogPeer::getInstanceFromPool((string) $key))) && !$this->formatter) {
            // the object is already in the instance pool
            return $obj;
        }
        if ($con === null) {
            $con = Propel::getConnection(ChangelogPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        if ($this->formatter || $this->modelAlias || $this->with || $this->select
         || $this->selectColumns || $this->asColumns || $this->selectModifiers
         || $this->map || $this->having || $this->joins) {
            return $this->findPkComplex($key, $con);
        } else {
            return $this->findPkSimple($key, $con);
        }
    }

    /**
     * Alias of findPk to use instance pooling
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 Changelog A model object, or null if the key is not found
     * @throws PropelException
     */
     public function findOneByEventId($key, $con = null)
     {
        return $this->findPk($key, $con);
     }

    /**
     * Find object by primary key using raw SQL to go fast.
     * Bypass doSelect() and the object formatter by using generated code.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 Changelog A model object, or null if the key is not found
     * @throws PropelException
     */
    protected function findPkSimple($key, $con)
    {
        $sql = 'SELECT `event_id`, `event_date`, `event_description`, `event_type`, `object_id`, `object_class`, `user_id`, `user_class`, `session_id`, `library_id` FROM `changelog` WHERE `event_id` = :p0';
        try {
            $stmt = $con->prepare($sql);
            $stmt->bindValue(':p0', $key, PDO::PARAM_INT);
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute SELECT statement [%s]', $sql), $e);
        }
        $obj = null;
        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $obj = new Changelog();
            $obj->hydrate($row);
            ChangelogPeer::addInstanceToPool($obj, (string) $key);
        }
        $stmt->closeCursor();

        return $obj;
    }

    /**
     * Find object by primary key.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return Changelog|Changelog[]|mixed the result, formatted by the current formatter
     */
    protected function findPkComplex($key, $con)
    {
        // As the query uses a PK condition, no limit(1) is necessary.
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKey($key)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->formatOne($stmt);
    }

    /**
     * Find objects by primary key
     * <code>
     * $objs = $c->findPks(array(12, 56, 832), $con);
     * </code>
     * @param     array $keys Primary keys to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return PropelObjectCollection|Changelog[]|mixed the list of results, formatted by the current formatter
     */
    public function findPks($keys, $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection($this->getDbName(), Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKeys($keys)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->format($stmt);
    }

    /**
     * Filter the query by primary key
     *
     * @param     mixed $key Primary key to use for the query
     *
     * @return ChangelogQuery The current query, for fluid interface
     */
    public function filterByPrimaryKey($key)
    {

        return $this->addUsingAlias(ChangelogPeer::EVENT_ID, $key, Criteria::EQUAL);
    }

    /**
     * Filter the query by a list of primary keys
     *
     * @param     array $keys The list of primary key to use for the query
     *
     * @return ChangelogQuery The current query, for fluid interface
     */
    public function filterByPrimaryKeys($keys)
    {

        return $this->addUsingAlias(ChangelogPeer::EVENT_ID, $keys, Criteria::IN);
    }

    /**
     * Filter the query on the event_id column
     *
     * Example usage:
     * <code>
     * $query->filterByEventId(1234); // WHERE event_id = 1234
     * $query->filterByEventId(array(12, 34)); // WHERE event_id IN (12, 34)
     * $query->filterByEventId(array('min' => 12)); // WHERE event_id >= 12
     * $query->filterByEventId(array('max' => 12)); // WHERE event_id <= 12
     * </code>
     *
     * @param     mixed $eventId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ChangelogQuery The current query, for fluid interface
     */
    public function filterByEventId($eventId = null, $comparison = null)
    {
        if (is_array($eventId)) {
            $useMinMax = false;
            if (isset($eventId['min'])) {
                $this->addUsingAlias(ChangelogPeer::EVENT_ID, $eventId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($eventId['max'])) {
                $this->addUsingAlias(ChangelogPeer::EVENT_ID, $eventId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ChangelogPeer::EVENT_ID, $eventId, $comparison);
    }

    /**
     * Filter the query on the event_date column
     *
     * Example usage:
     * <code>
     * $query->filterByEventDate('2011-03-14'); // WHERE event_date = '2011-03-14'
     * $query->filterByEventDate('now'); // WHERE event_date = '2011-03-14'
     * $query->filterByEventDate(array('max' => 'yesterday')); // WHERE event_date < '2011-03-13'
     * </code>
     *
     * @param     mixed $eventDate The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ChangelogQuery The current query, for fluid interface
     */
    public function filterByEventDate($eventDate = null, $comparison = null)
    {
        if (is_array($eventDate)) {
            $useMinMax = false;
            if (isset($eventDate['min'])) {
                $this->addUsingAlias(ChangelogPeer::EVENT_DATE, $eventDate['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($eventDate['max'])) {
                $this->addUsingAlias(ChangelogPeer::EVENT_DATE, $eventDate['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ChangelogPeer::EVENT_DATE, $eventDate, $comparison);
    }

    /**
     * Filter the query on the event_description column
     *
     * Example usage:
     * <code>
     * $query->filterByEventDescription('fooValue');   // WHERE event_description = 'fooValue'
     * $query->filterByEventDescription('%fooValue%'); // WHERE event_description LIKE '%fooValue%'
     * </code>
     *
     * @param     string $eventDescription The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ChangelogQuery The current query, for fluid interface
     */
    public function filterByEventDescription($eventDescription = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($eventDescription)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $eventDescription)) {
                $eventDescription = str_replace('*', '%', $eventDescription);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(ChangelogPeer::EVENT_DESCRIPTION, $eventDescription, $comparison);
    }

    /**
     * Filter the query on the event_type column
     *
     * Example usage:
     * <code>
     * $query->filterByEventType('fooValue');   // WHERE event_type = 'fooValue'
     * $query->filterByEventType('%fooValue%'); // WHERE event_type LIKE '%fooValue%'
     * </code>
     *
     * @param     string $eventType The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ChangelogQuery The current query, for fluid interface
     */
    public function filterByEventType($eventType = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($eventType)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $eventType)) {
                $eventType = str_replace('*', '%', $eventType);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(ChangelogPeer::EVENT_TYPE, $eventType, $comparison);
    }

    /**
     * Filter the query on the object_id column
     *
     * Example usage:
     * <code>
     * $query->filterByObjectId(1234); // WHERE object_id = 1234
     * $query->filterByObjectId(array(12, 34)); // WHERE object_id IN (12, 34)
     * $query->filterByObjectId(array('min' => 12)); // WHERE object_id >= 12
     * $query->filterByObjectId(array('max' => 12)); // WHERE object_id <= 12
     * </code>
     *
     * @param     mixed $objectId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ChangelogQuery The current query, for fluid interface
     */
    public function filterByObjectId($objectId = null, $comparison = null)
    {
        if (is_array($objectId)) {
            $useMinMax = false;
            if (isset($objectId['min'])) {
                $this->addUsingAlias(ChangelogPeer::OBJECT_ID, $objectId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($objectId['max'])) {
                $this->addUsingAlias(ChangelogPeer::OBJECT_ID, $objectId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ChangelogPeer::OBJECT_ID, $objectId, $comparison);
    }

    /**
     * Filter the query on the object_class column
     *
     * Example usage:
     * <code>
     * $query->filterByObjectClass('fooValue');   // WHERE object_class = 'fooValue'
     * $query->filterByObjectClass('%fooValue%'); // WHERE object_class LIKE '%fooValue%'
     * </code>
     *
     * @param     string $objectClass The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ChangelogQuery The current query, for fluid interface
     */
    public function filterByObjectClass($objectClass = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($objectClass)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $objectClass)) {
                $objectClass = str_replace('*', '%', $objectClass);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(ChangelogPeer::OBJECT_CLASS, $objectClass, $comparison);
    }

    /**
     * Filter the query on the user_id column
     *
     * Example usage:
     * <code>
     * $query->filterByUserId(1234); // WHERE user_id = 1234
     * $query->filterByUserId(array(12, 34)); // WHERE user_id IN (12, 34)
     * $query->filterByUserId(array('min' => 12)); // WHERE user_id >= 12
     * $query->filterByUserId(array('max' => 12)); // WHERE user_id <= 12
     * </code>
     *
     * @param     mixed $userId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ChangelogQuery The current query, for fluid interface
     */
    public function filterByUserId($userId = null, $comparison = null)
    {
        if (is_array($userId)) {
            $useMinMax = false;
            if (isset($userId['min'])) {
                $this->addUsingAlias(ChangelogPeer::USER_ID, $userId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($userId['max'])) {
                $this->addUsingAlias(ChangelogPeer::USER_ID, $userId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ChangelogPeer::USER_ID, $userId, $comparison);
    }

    /**
     * Filter the query on the user_class column
     *
     * Example usage:
     * <code>
     * $query->filterByUserClass('fooValue');   // WHERE user_class = 'fooValue'
     * $query->filterByUserClass('%fooValue%'); // WHERE user_class LIKE '%fooValue%'
     * </code>
     *
     * @param     string $userClass The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ChangelogQuery The current query, for fluid interface
     */
    public function filterByUserClass($userClass = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($userClass)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $userClass)) {
                $userClass = str_replace('*', '%', $userClass);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(ChangelogPeer::USER_CLASS, $userClass, $comparison);
    }

    /**
     * Filter the query on the session_id column
     *
     * Example usage:
     * <code>
     * $query->filterBySessionId(1234); // WHERE session_id = 1234
     * $query->filterBySessionId(array(12, 34)); // WHERE session_id IN (12, 34)
     * $query->filterBySessionId(array('min' => 12)); // WHERE session_id >= 12
     * $query->filterBySessionId(array('max' => 12)); // WHERE session_id <= 12
     * </code>
     *
     * @param     mixed $sessionId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ChangelogQuery The current query, for fluid interface
     */
    public function filterBySessionId($sessionId = null, $comparison = null)
    {
        if (is_array($sessionId)) {
            $useMinMax = false;
            if (isset($sessionId['min'])) {
                $this->addUsingAlias(ChangelogPeer::SESSION_ID, $sessionId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($sessionId['max'])) {
                $this->addUsingAlias(ChangelogPeer::SESSION_ID, $sessionId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ChangelogPeer::SESSION_ID, $sessionId, $comparison);
    }

    /**
     * Filter the query on the library_id column
     *
     * Example usage:
     * <code>
     * $query->filterByLibraryId(1234); // WHERE library_id = 1234
     * $query->filterByLibraryId(array(12, 34)); // WHERE library_id IN (12, 34)
     * $query->filterByLibraryId(array('min' => 12)); // WHERE library_id >= 12
     * $query->filterByLibraryId(array('max' => 12)); // WHERE library_id <= 12
     * </code>
     *
     * @param     mixed $libraryId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ChangelogQuery The current query, for fluid interface
     */
    public function filterByLibraryId($libraryId = null, $comparison = null)
    {
        if (is_array($libraryId)) {
            $useMinMax = false;
            if (isset($libraryId['min'])) {
                $this->addUsingAlias(ChangelogPeer::LIBRARY_ID, $libraryId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($libraryId['max'])) {
                $this->addUsingAlias(ChangelogPeer::LIBRARY_ID, $libraryId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ChangelogPeer::LIBRARY_ID, $libraryId, $comparison);
    }

    /**
     * Exclude object from result
     *
     * @param   Changelog $changelog Object to remove from the list of results
     *
     * @return ChangelogQuery The current query, for fluid interface
     */
    public function prune($changelog = null)
    {
        if ($changelog) {
            $this->addUsingAlias(ChangelogPeer::EVENT_ID, $changelog->getEventId(), Criteria::NOT_EQUAL);
        }

        return $this;
    }

}
