<?php


/**
 * Base class that represents a row from the 'document_template' table.
 *
 *
 *
 * @package    propel.generator.clavis.om
 */
abstract class BaseDocumentTemplate extends BaseObject implements Persistent
{
    /**
     * Peer class name
     */
    const PEER = 'DocumentTemplatePeer';

    /**
     * The Peer class.
     * Instance provides a convenient way of calling static methods on a class
     * that calling code may not be able to identify.
     * @var        DocumentTemplatePeer
     */
    protected static $peer;

    /**
     * The flag var to prevent infinite loop in deep copy
     * @var       boolean
     */
    protected $startCopy = false;

    /**
     * The value for the document_template_id field.
     * @var        int
     */
    protected $document_template_id;

    /**
     * The value for the template_media field.
     * @var        string
     */
    protected $template_media;

    /**
     * The value for the template_description field.
     * @var        string
     */
    protected $template_description;

    /**
     * The value for the template_title field.
     * @var        string
     */
    protected $template_title;

    /**
     * The value for the template_subject field.
     * @var        string
     */
    protected $template_subject;

    /**
     * The value for the template_body field.
     * @var        string
     */
    protected $template_body;

    /**
     * The value for the template_class field.
     * @var        string
     */
    protected $template_class;

    /**
     * The value for the template_lang field.
     * @var        string
     */
    protected $template_lang;

    /**
     * The value for the library_id field.
     * @var        int
     */
    protected $library_id;

    /**
     * The value for the date_created field.
     * @var        string
     */
    protected $date_created;

    /**
     * The value for the date_updated field.
     * @var        string
     */
    protected $date_updated;

    /**
     * The value for the created_by field.
     * @var        int
     */
    protected $created_by;

    /**
     * The value for the modified_by field.
     * @var        int
     */
    protected $modified_by;

    /**
     * @var        Librarian
     */
    protected $aLibrarianRelatedByCreatedBy;

    /**
     * @var        Librarian
     */
    protected $aLibrarianRelatedByModifiedBy;

    /**
     * @var        Library
     */
    protected $aLibrary;

    /**
     * Flag to prevent endless save loop, if this object is referenced
     * by another object which falls in this transaction.
     * @var        boolean
     */
    protected $alreadyInSave = false;

    /**
     * Flag to prevent endless validation loop, if this object is referenced
     * by another object which falls in this transaction.
     * @var        boolean
     */
    protected $alreadyInValidation = false;

    /**
     * Flag to prevent endless clearAllReferences($deep=true) loop, if this object is referenced
     * @var        boolean
     */
    protected $alreadyInClearAllReferencesDeep = false;

    /**
     * Get the [document_template_id] column value.
     *
     * @return int
     */
    public function getDocumentTemplateId()
    {

        return $this->document_template_id;
    }

    /**
     * Get the [template_media] column value.
     *
     * @return string
     */
    public function getTemplateMedia()
    {

        return $this->template_media;
    }

    /**
     * Get the [template_description] column value.
     *
     * @return string
     */
    public function getTemplateDescription()
    {

        return $this->template_description;
    }

    /**
     * Get the [template_title] column value.
     *
     * @return string
     */
    public function getTemplateTitle()
    {

        return $this->template_title;
    }

    /**
     * Get the [template_subject] column value.
     *
     * @return string
     */
    public function getTemplateSubject()
    {

        return $this->template_subject;
    }

    /**
     * Get the [template_body] column value.
     *
     * @return string
     */
    public function getTemplateBody()
    {

        return $this->template_body;
    }

    /**
     * Get the [template_class] column value.
     *
     * @return string
     */
    public function getTemplateClass()
    {

        return $this->template_class;
    }

    /**
     * Get the [template_lang] column value.
     *
     * @return string
     */
    public function getTemplateLang()
    {

        return $this->template_lang;
    }

    /**
     * Get the [library_id] column value.
     *
     * @return int
     */
    public function getLibraryId()
    {

        return $this->library_id;
    }

    /**
     * Get the [optionally formatted] temporal [date_created] column value.
     *
     *
     * @param string $format The date/time format string (either date()-style or strftime()-style).
     *				 If format is null, then the raw DateTime object will be returned.
     * @return mixed Formatted date/time value as string or DateTime object (if format is null), null if column is null, and 0 if column value is 0000-00-00 00:00:00
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getDateCreated($format = 'Y-m-d H:i:s')
    {
        if ($this->date_created === null) {
            return null;
        }

        if ($this->date_created === '0000-00-00 00:00:00') {
            // while technically this is not a default value of null,
            // this seems to be closest in meaning.
            return null;
        }

        try {
            $dt = new DateTime($this->date_created);
        } catch (Exception $x) {
            throw new PropelException("Internally stored date/time/timestamp value could not be converted to DateTime: " . var_export($this->date_created, true), $x);
        }

        if ($format === null) {
            // Because propel.useDateTimeClass is true, we return a DateTime object.
            return $dt;
        }

        if (strpos($format, '%') !== false) {
            return strftime($format, $dt->format('U'));
        }

        return $dt->format($format);

    }

    /**
     * Get the [optionally formatted] temporal [date_updated] column value.
     *
     *
     * @param string $format The date/time format string (either date()-style or strftime()-style).
     *				 If format is null, then the raw DateTime object will be returned.
     * @return mixed Formatted date/time value as string or DateTime object (if format is null), null if column is null, and 0 if column value is 0000-00-00 00:00:00
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getDateUpdated($format = 'Y-m-d H:i:s')
    {
        if ($this->date_updated === null) {
            return null;
        }

        if ($this->date_updated === '0000-00-00 00:00:00') {
            // while technically this is not a default value of null,
            // this seems to be closest in meaning.
            return null;
        }

        try {
            $dt = new DateTime($this->date_updated);
        } catch (Exception $x) {
            throw new PropelException("Internally stored date/time/timestamp value could not be converted to DateTime: " . var_export($this->date_updated, true), $x);
        }

        if ($format === null) {
            // Because propel.useDateTimeClass is true, we return a DateTime object.
            return $dt;
        }

        if (strpos($format, '%') !== false) {
            return strftime($format, $dt->format('U'));
        }

        return $dt->format($format);

    }

    /**
     * Get the [created_by] column value.
     *
     * @return int
     */
    public function getCreatedBy()
    {

        return $this->created_by;
    }

    /**
     * Get the [modified_by] column value.
     *
     * @return int
     */
    public function getModifiedBy()
    {

        return $this->modified_by;
    }

    /**
     * Set the value of [document_template_id] column.
     *
     * @param  int $v new value
     * @return DocumentTemplate The current object (for fluent API support)
     */
    public function setDocumentTemplateId($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->document_template_id !== $v) {
            $this->document_template_id = $v;
            $this->modifiedColumns[] = DocumentTemplatePeer::DOCUMENT_TEMPLATE_ID;
        }


        return $this;
    } // setDocumentTemplateId()

    /**
     * Set the value of [template_media] column.
     *
     * @param  string $v new value
     * @return DocumentTemplate The current object (for fluent API support)
     */
    public function setTemplateMedia($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->template_media !== $v) {
            $this->template_media = $v;
            $this->modifiedColumns[] = DocumentTemplatePeer::TEMPLATE_MEDIA;
        }


        return $this;
    } // setTemplateMedia()

    /**
     * Set the value of [template_description] column.
     *
     * @param  string $v new value
     * @return DocumentTemplate The current object (for fluent API support)
     */
    public function setTemplateDescription($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->template_description !== $v) {
            $this->template_description = $v;
            $this->modifiedColumns[] = DocumentTemplatePeer::TEMPLATE_DESCRIPTION;
        }


        return $this;
    } // setTemplateDescription()

    /**
     * Set the value of [template_title] column.
     *
     * @param  string $v new value
     * @return DocumentTemplate The current object (for fluent API support)
     */
    public function setTemplateTitle($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->template_title !== $v) {
            $this->template_title = $v;
            $this->modifiedColumns[] = DocumentTemplatePeer::TEMPLATE_TITLE;
        }


        return $this;
    } // setTemplateTitle()

    /**
     * Set the value of [template_subject] column.
     *
     * @param  string $v new value
     * @return DocumentTemplate The current object (for fluent API support)
     */
    public function setTemplateSubject($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->template_subject !== $v) {
            $this->template_subject = $v;
            $this->modifiedColumns[] = DocumentTemplatePeer::TEMPLATE_SUBJECT;
        }


        return $this;
    } // setTemplateSubject()

    /**
     * Set the value of [template_body] column.
     *
     * @param  string $v new value
     * @return DocumentTemplate The current object (for fluent API support)
     */
    public function setTemplateBody($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->template_body !== $v) {
            $this->template_body = $v;
            $this->modifiedColumns[] = DocumentTemplatePeer::TEMPLATE_BODY;
        }


        return $this;
    } // setTemplateBody()

    /**
     * Set the value of [template_class] column.
     *
     * @param  string $v new value
     * @return DocumentTemplate The current object (for fluent API support)
     */
    public function setTemplateClass($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->template_class !== $v) {
            $this->template_class = $v;
            $this->modifiedColumns[] = DocumentTemplatePeer::TEMPLATE_CLASS;
        }


        return $this;
    } // setTemplateClass()

    /**
     * Set the value of [template_lang] column.
     *
     * @param  string $v new value
     * @return DocumentTemplate The current object (for fluent API support)
     */
    public function setTemplateLang($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->template_lang !== $v) {
            $this->template_lang = $v;
            $this->modifiedColumns[] = DocumentTemplatePeer::TEMPLATE_LANG;
        }


        return $this;
    } // setTemplateLang()

    /**
     * Set the value of [library_id] column.
     *
     * @param  int $v new value
     * @return DocumentTemplate The current object (for fluent API support)
     */
    public function setLibraryId($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->library_id !== $v) {
            $this->library_id = $v;
            $this->modifiedColumns[] = DocumentTemplatePeer::LIBRARY_ID;
        }

        if ($this->aLibrary !== null && $this->aLibrary->getLibraryId() !== $v) {
            $this->aLibrary = null;
        }


        return $this;
    } // setLibraryId()

    /**
     * Sets the value of [date_created] column to a normalized version of the date/time value specified.
     *
     * @param mixed $v string, integer (timestamp), or DateTime value.
     *               Empty strings are treated as null.
     * @return DocumentTemplate The current object (for fluent API support)
     */
    public function setDateCreated($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->date_created !== null || $dt !== null) {
            $currentDateAsString = ($this->date_created !== null && $tmpDt = new DateTime($this->date_created)) ? $tmpDt->format('Y-m-d H:i:s') : null;
            $newDateAsString = $dt ? $dt->format('Y-m-d H:i:s') : null;
            if ($currentDateAsString !== $newDateAsString) {
                $this->date_created = $newDateAsString;
                $this->modifiedColumns[] = DocumentTemplatePeer::DATE_CREATED;
            }
        } // if either are not null


        return $this;
    } // setDateCreated()

    /**
     * Sets the value of [date_updated] column to a normalized version of the date/time value specified.
     *
     * @param mixed $v string, integer (timestamp), or DateTime value.
     *               Empty strings are treated as null.
     * @return DocumentTemplate The current object (for fluent API support)
     */
    public function setDateUpdated($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->date_updated !== null || $dt !== null) {
            $currentDateAsString = ($this->date_updated !== null && $tmpDt = new DateTime($this->date_updated)) ? $tmpDt->format('Y-m-d H:i:s') : null;
            $newDateAsString = $dt ? $dt->format('Y-m-d H:i:s') : null;
            if ($currentDateAsString !== $newDateAsString) {
                $this->date_updated = $newDateAsString;
                $this->modifiedColumns[] = DocumentTemplatePeer::DATE_UPDATED;
            }
        } // if either are not null


        return $this;
    } // setDateUpdated()

    /**
     * Set the value of [created_by] column.
     *
     * @param  int $v new value
     * @return DocumentTemplate The current object (for fluent API support)
     */
    public function setCreatedBy($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->created_by !== $v) {
            $this->created_by = $v;
            $this->modifiedColumns[] = DocumentTemplatePeer::CREATED_BY;
        }

        if ($this->aLibrarianRelatedByCreatedBy !== null && $this->aLibrarianRelatedByCreatedBy->getLibrarianId() !== $v) {
            $this->aLibrarianRelatedByCreatedBy = null;
        }


        return $this;
    } // setCreatedBy()

    /**
     * Set the value of [modified_by] column.
     *
     * @param  int $v new value
     * @return DocumentTemplate The current object (for fluent API support)
     */
    public function setModifiedBy($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->modified_by !== $v) {
            $this->modified_by = $v;
            $this->modifiedColumns[] = DocumentTemplatePeer::MODIFIED_BY;
        }

        if ($this->aLibrarianRelatedByModifiedBy !== null && $this->aLibrarianRelatedByModifiedBy->getLibrarianId() !== $v) {
            $this->aLibrarianRelatedByModifiedBy = null;
        }


        return $this;
    } // setModifiedBy()

    /**
     * Indicates whether the columns in this object are only set to default values.
     *
     * This method can be used in conjunction with isModified() to indicate whether an object is both
     * modified _and_ has some values set which are non-default.
     *
     * @return boolean Whether the columns in this object are only been set with default values.
     */
    public function hasOnlyDefaultValues()
    {
        // otherwise, everything was equal, so return true
        return true;
    } // hasOnlyDefaultValues()

    /**
     * Hydrates (populates) the object variables with values from the database resultset.
     *
     * An offset (0-based "start column") is specified so that objects can be hydrated
     * with a subset of the columns in the resultset rows.  This is needed, for example,
     * for results of JOIN queries where the resultset row includes columns from two or
     * more tables.
     *
     * @param array $row The row returned by PDOStatement->fetch(PDO::FETCH_NUM)
     * @param int $startcol 0-based offset column which indicates which resultset column to start with.
     * @param boolean $rehydrate Whether this object is being re-hydrated from the database.
     * @return int             next starting column
     * @throws PropelException - Any caught Exception will be rewrapped as a PropelException.
     */
    public function hydrate($row, $startcol = 0, $rehydrate = false)
    {
        try {

            $this->document_template_id = ($row[$startcol + 0] !== null) ? (int) $row[$startcol + 0] : null;
            $this->template_media = ($row[$startcol + 1] !== null) ? (string) $row[$startcol + 1] : null;
            $this->template_description = ($row[$startcol + 2] !== null) ? (string) $row[$startcol + 2] : null;
            $this->template_title = ($row[$startcol + 3] !== null) ? (string) $row[$startcol + 3] : null;
            $this->template_subject = ($row[$startcol + 4] !== null) ? (string) $row[$startcol + 4] : null;
            $this->template_body = ($row[$startcol + 5] !== null) ? (string) $row[$startcol + 5] : null;
            $this->template_class = ($row[$startcol + 6] !== null) ? (string) $row[$startcol + 6] : null;
            $this->template_lang = ($row[$startcol + 7] !== null) ? (string) $row[$startcol + 7] : null;
            $this->library_id = ($row[$startcol + 8] !== null) ? (int) $row[$startcol + 8] : null;
            $this->date_created = ($row[$startcol + 9] !== null) ? (string) $row[$startcol + 9] : null;
            $this->date_updated = ($row[$startcol + 10] !== null) ? (string) $row[$startcol + 10] : null;
            $this->created_by = ($row[$startcol + 11] !== null) ? (int) $row[$startcol + 11] : null;
            $this->modified_by = ($row[$startcol + 12] !== null) ? (int) $row[$startcol + 12] : null;
            $this->resetModified();

            $this->setNew(false);

            if ($rehydrate) {
                $this->ensureConsistency();
            }
            $this->postHydrate($row, $startcol, $rehydrate);

            return $startcol + 13; // 13 = DocumentTemplatePeer::NUM_HYDRATE_COLUMNS.

        } catch (Exception $e) {
            throw new PropelException("Error populating DocumentTemplate object", $e);
        }
    }

    /**
     * Checks and repairs the internal consistency of the object.
     *
     * This method is executed after an already-instantiated object is re-hydrated
     * from the database.  It exists to check any foreign keys to make sure that
     * the objects related to the current object are correct based on foreign key.
     *
     * You can override this method in the stub class, but you should always invoke
     * the base method from the overridden method (i.e. parent::ensureConsistency()),
     * in case your model changes.
     *
     * @throws PropelException
     */
    public function ensureConsistency()
    {

        if ($this->aLibrary !== null && $this->library_id !== $this->aLibrary->getLibraryId()) {
            $this->aLibrary = null;
        }
        if ($this->aLibrarianRelatedByCreatedBy !== null && $this->created_by !== $this->aLibrarianRelatedByCreatedBy->getLibrarianId()) {
            $this->aLibrarianRelatedByCreatedBy = null;
        }
        if ($this->aLibrarianRelatedByModifiedBy !== null && $this->modified_by !== $this->aLibrarianRelatedByModifiedBy->getLibrarianId()) {
            $this->aLibrarianRelatedByModifiedBy = null;
        }
    } // ensureConsistency

    /**
     * Reloads this object from datastore based on primary key and (optionally) resets all associated objects.
     *
     * This will only work if the object has been saved and has a valid primary key set.
     *
     * @param boolean $deep (optional) Whether to also de-associated any related objects.
     * @param PropelPDO $con (optional) The PropelPDO connection to use.
     * @return void
     * @throws PropelException - if this object is deleted, unsaved or doesn't have pk match in db
     */
    public function reload($deep = false, PropelPDO $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("Cannot reload a deleted object.");
        }

        if ($this->isNew()) {
            throw new PropelException("Cannot reload an unsaved object.");
        }

        if ($con === null) {
            $con = Propel::getConnection(DocumentTemplatePeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        // We don't need to alter the object instance pool; we're just modifying this instance
        // already in the pool.

        $stmt = DocumentTemplatePeer::doSelectStmt($this->buildPkeyCriteria(), $con);
        $row = $stmt->fetch(PDO::FETCH_NUM);
        $stmt->closeCursor();
        if (!$row) {
            throw new PropelException('Cannot find matching row in the database to reload object values.');
        }
        $this->hydrate($row, 0, true); // rehydrate

        if ($deep) {  // also de-associate any related objects?

            $this->aLibrarianRelatedByCreatedBy = null;
            $this->aLibrarianRelatedByModifiedBy = null;
            $this->aLibrary = null;
        } // if (deep)
    }

    /**
     * Removes this object from datastore and sets delete attribute.
     *
     * @param PropelPDO $con
     * @return void
     * @throws PropelException
     * @throws Exception
     * @see        BaseObject::setDeleted()
     * @see        BaseObject::isDeleted()
     */
    public function delete(PropelPDO $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("This object has already been deleted.");
        }

        if ($con === null) {
            $con = Propel::getConnection(DocumentTemplatePeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        $con->beginTransaction();
        try {
            $deleteQuery = DocumentTemplateQuery::create()
                ->filterByPrimaryKey($this->getPrimaryKey());
            $ret = $this->preDelete($con);
            if ($ret) {
                $deleteQuery->delete($con);
                $this->postDelete($con);
                $con->commit();
                $this->setDeleted(true);
            } else {
                $con->commit();
            }
        } catch (Exception $e) {
            $con->rollBack();
            throw $e;
        }
    }

    /**
     * Persists this object to the database.
     *
     * If the object is new, it inserts it; otherwise an update is performed.
     * All modified related objects will also be persisted in the doSave()
     * method.  This method wraps all precipitate database operations in a
     * single transaction.
     *
     * @param PropelPDO $con
     * @return int             The number of rows affected by this insert/update and any referring fk objects' save() operations.
     * @throws PropelException
     * @throws Exception
     * @see        doSave()
     */
    public function save(PropelPDO $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("You cannot save an object that has been deleted.");
        }

        if ($con === null) {
            $con = Propel::getConnection(DocumentTemplatePeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        $con->beginTransaction();
        $isInsert = $this->isNew();
        try {
            $ret = $this->preSave($con);
            if ($isInsert) {
                $ret = $ret && $this->preInsert($con);
                // timestampable behavior
                if (!$this->isColumnModified(DocumentTemplatePeer::DATE_CREATED)) {
                    $this->setDateCreated(time());
                }
                if (!$this->isColumnModified(DocumentTemplatePeer::DATE_UPDATED)) {
                    $this->setDateUpdated(time());
                }
                // librariantrace behavior
                $librarianId = (class_exists('Prado') && (Prado::getApplication() instanceof TApplication) && ($u = Prado::getApplication()->getUser()) instanceof ClavisLibrarian && $u->getId() > 0) ? $u->getId() : 1 ;
                if (!$this->isColumnModified(DocumentTemplatePeer::CREATED_BY)) {
                    $this->setCreatedBy($librarianId);
                }
                if (!$this->isColumnModified(DocumentTemplatePeer::MODIFIED_BY)) {
                    $this->setModifiedBy($librarianId);
                }
            } else {
                $ret = $ret && $this->preUpdate($con);
                // timestampable behavior
                if ($this->isModified() && !$this->isColumnModified(DocumentTemplatePeer::DATE_UPDATED)) {
                    $this->setDateUpdated(time());
                }
                // librariantrace behavior
                if ($this->isModified() && !$this->isColumnModified(DocumentTemplatePeer::MODIFIED_BY)) {
                    $this->setModifiedBy((class_exists('Prado') && (Prado::getApplication() instanceof TApplication) && ($u = Prado::getApplication()->getUser()) instanceof ClavisLibrarian && $u->getId() > 0) ? $u->getId() : 1 );
                }
            }
            if ($ret) {
                $affectedRows = $this->doSave($con);
                if ($isInsert) {
                    $this->postInsert($con);
                } else {
                    $this->postUpdate($con);
                }
                $this->postSave($con);
                DocumentTemplatePeer::addInstanceToPool($this);
            } else {
                $affectedRows = 0;
            }
            $con->commit();

            return $affectedRows;
        } catch (Exception $e) {
            $con->rollBack();
            throw $e;
        }
    }

    /**
     * Performs the work of inserting or updating the row in the database.
     *
     * If the object is new, it inserts it; otherwise an update is performed.
     * All related objects are also updated in this method.
     *
     * @param PropelPDO $con
     * @return int             The number of rows affected by this insert/update and any referring fk objects' save() operations.
     * @throws PropelException
     * @see        save()
     */
    protected function doSave(PropelPDO $con)
    {
        $affectedRows = 0; // initialize var to track total num of affected rows
        if (!$this->alreadyInSave) {
            $this->alreadyInSave = true;

            // We call the save method on the following object(s) if they
            // were passed to this object by their corresponding set
            // method.  This object relates to these object(s) by a
            // foreign key reference.

            if ($this->aLibrarianRelatedByCreatedBy !== null) {
                if ($this->aLibrarianRelatedByCreatedBy->isModified() || $this->aLibrarianRelatedByCreatedBy->isNew()) {
                    $affectedRows += $this->aLibrarianRelatedByCreatedBy->save($con);
                }
                $this->setLibrarianRelatedByCreatedBy($this->aLibrarianRelatedByCreatedBy);
            }

            if ($this->aLibrarianRelatedByModifiedBy !== null) {
                if ($this->aLibrarianRelatedByModifiedBy->isModified() || $this->aLibrarianRelatedByModifiedBy->isNew()) {
                    $affectedRows += $this->aLibrarianRelatedByModifiedBy->save($con);
                }
                $this->setLibrarianRelatedByModifiedBy($this->aLibrarianRelatedByModifiedBy);
            }

            if ($this->aLibrary !== null) {
                if ($this->aLibrary->isModified() || $this->aLibrary->isNew()) {
                    $affectedRows += $this->aLibrary->save($con);
                }
                $this->setLibrary($this->aLibrary);
            }

            if ($this->isNew() || $this->isModified()) {
                // persist changes
                if ($this->isNew()) {
                    $this->doInsert($con);
                } else {
                    $this->doUpdate($con);
                }
                $affectedRows += 1;
                $this->resetModified();
            }

            $this->alreadyInSave = false;

        }

        return $affectedRows;
    } // doSave()

    /**
     * Insert the row in the database.
     *
     * @param PropelPDO $con
     *
     * @throws PropelException
     * @see        doSave()
     */
    protected function doInsert(PropelPDO $con)
    {
        $modifiedColumns = array();
        $index = 0;

        $this->modifiedColumns[] = DocumentTemplatePeer::DOCUMENT_TEMPLATE_ID;
        if (null !== $this->document_template_id) {
            throw new PropelException('Cannot insert a value for auto-increment primary key (' . DocumentTemplatePeer::DOCUMENT_TEMPLATE_ID . ')');
        }

         // check the columns in natural order for more readable SQL queries
        if ($this->isColumnModified(DocumentTemplatePeer::DOCUMENT_TEMPLATE_ID)) {
            $modifiedColumns[':p' . $index++]  = '`document_template_id`';
        }
        if ($this->isColumnModified(DocumentTemplatePeer::TEMPLATE_MEDIA)) {
            $modifiedColumns[':p' . $index++]  = '`template_media`';
        }
        if ($this->isColumnModified(DocumentTemplatePeer::TEMPLATE_DESCRIPTION)) {
            $modifiedColumns[':p' . $index++]  = '`template_description`';
        }
        if ($this->isColumnModified(DocumentTemplatePeer::TEMPLATE_TITLE)) {
            $modifiedColumns[':p' . $index++]  = '`template_title`';
        }
        if ($this->isColumnModified(DocumentTemplatePeer::TEMPLATE_SUBJECT)) {
            $modifiedColumns[':p' . $index++]  = '`template_subject`';
        }
        if ($this->isColumnModified(DocumentTemplatePeer::TEMPLATE_BODY)) {
            $modifiedColumns[':p' . $index++]  = '`template_body`';
        }
        if ($this->isColumnModified(DocumentTemplatePeer::TEMPLATE_CLASS)) {
            $modifiedColumns[':p' . $index++]  = '`template_class`';
        }
        if ($this->isColumnModified(DocumentTemplatePeer::TEMPLATE_LANG)) {
            $modifiedColumns[':p' . $index++]  = '`template_lang`';
        }
        if ($this->isColumnModified(DocumentTemplatePeer::LIBRARY_ID)) {
            $modifiedColumns[':p' . $index++]  = '`library_id`';
        }
        if ($this->isColumnModified(DocumentTemplatePeer::DATE_CREATED)) {
            $modifiedColumns[':p' . $index++]  = '`date_created`';
        }
        if ($this->isColumnModified(DocumentTemplatePeer::DATE_UPDATED)) {
            $modifiedColumns[':p' . $index++]  = '`date_updated`';
        }
        if ($this->isColumnModified(DocumentTemplatePeer::CREATED_BY)) {
            $modifiedColumns[':p' . $index++]  = '`created_by`';
        }
        if ($this->isColumnModified(DocumentTemplatePeer::MODIFIED_BY)) {
            $modifiedColumns[':p' . $index++]  = '`modified_by`';
        }

        $sql = sprintf(
            'INSERT INTO `document_template` (%s) VALUES (%s)',
            implode(', ', $modifiedColumns),
            implode(', ', array_keys($modifiedColumns))
        );

        try {
            $stmt = $con->prepare($sql);
            foreach ($modifiedColumns as $identifier => $columnName) {
                switch ($columnName) {
                    case '`document_template_id`':
                        $stmt->bindValue($identifier, $this->document_template_id, PDO::PARAM_INT);
                        break;
                    case '`template_media`':
                        $stmt->bindValue($identifier, $this->template_media, PDO::PARAM_STR);
                        break;
                    case '`template_description`':
                        $stmt->bindValue($identifier, $this->template_description, PDO::PARAM_STR);
                        break;
                    case '`template_title`':
                        $stmt->bindValue($identifier, $this->template_title, PDO::PARAM_STR);
                        break;
                    case '`template_subject`':
                        $stmt->bindValue($identifier, $this->template_subject, PDO::PARAM_STR);
                        break;
                    case '`template_body`':
                        $stmt->bindValue($identifier, $this->template_body, PDO::PARAM_STR);
                        break;
                    case '`template_class`':
                        $stmt->bindValue($identifier, $this->template_class, PDO::PARAM_STR);
                        break;
                    case '`template_lang`':
                        $stmt->bindValue($identifier, $this->template_lang, PDO::PARAM_STR);
                        break;
                    case '`library_id`':
                        $stmt->bindValue($identifier, $this->library_id, PDO::PARAM_INT);
                        break;
                    case '`date_created`':
                        $stmt->bindValue($identifier, $this->date_created, PDO::PARAM_STR);
                        break;
                    case '`date_updated`':
                        $stmt->bindValue($identifier, $this->date_updated, PDO::PARAM_STR);
                        break;
                    case '`created_by`':
                        $stmt->bindValue($identifier, $this->created_by, PDO::PARAM_INT);
                        break;
                    case '`modified_by`':
                        $stmt->bindValue($identifier, $this->modified_by, PDO::PARAM_INT);
                        break;
                }
            }
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute INSERT statement [%s]', $sql), $e);
        }

        try {
            $pk = $con->lastInsertId();
        } catch (Exception $e) {
            throw new PropelException('Unable to get autoincrement id.', $e);
        }
        $this->setDocumentTemplateId($pk);

        $this->setNew(false);
    }

    /**
     * Update the row in the database.
     *
     * @param PropelPDO $con
     *
     * @see        doSave()
     */
    protected function doUpdate(PropelPDO $con)
    {
        $selectCriteria = $this->buildPkeyCriteria();
        $valuesCriteria = $this->buildCriteria();
        BasePeer::doUpdate($selectCriteria, $valuesCriteria, $con);
    }

    /**
     * Array of ValidationFailed objects.
     * @var        array ValidationFailed[]
     */
    protected $validationFailures = array();

    /**
     * Gets any ValidationFailed objects that resulted from last call to validate().
     *
     *
     * @return array ValidationFailed[]
     * @see        validate()
     */
    public function getValidationFailures()
    {
        return $this->validationFailures;
    }

    /**
     * Validates the objects modified field values and all objects related to this table.
     *
     * If $columns is either a column name or an array of column names
     * only those columns are validated.
     *
     * @param mixed $columns Column name or an array of column names.
     * @return boolean Whether all columns pass validation.
     * @see        doValidate()
     * @see        getValidationFailures()
     */
    public function validate($columns = null)
    {
        $res = $this->doValidate($columns);
        if ($res === true) {
            $this->validationFailures = array();

            return true;
        }

        $this->validationFailures = $res;

        return false;
    }

    /**
     * This function performs the validation work for complex object models.
     *
     * In addition to checking the current object, all related objects will
     * also be validated.  If all pass then <code>true</code> is returned; otherwise
     * an aggregated array of ValidationFailed objects will be returned.
     *
     * @param array $columns Array of column names to validate.
     * @return mixed <code>true</code> if all validations pass; array of <code>ValidationFailed</code> objects otherwise.
     */
    protected function doValidate($columns = null)
    {
        if (!$this->alreadyInValidation) {
            $this->alreadyInValidation = true;
            $retval = null;

            $failureMap = array();


            // We call the validate method on the following object(s) if they
            // were passed to this object by their corresponding set
            // method.  This object relates to these object(s) by a
            // foreign key reference.

            if ($this->aLibrarianRelatedByCreatedBy !== null) {
                if (!$this->aLibrarianRelatedByCreatedBy->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aLibrarianRelatedByCreatedBy->getValidationFailures());
                }
            }

            if ($this->aLibrarianRelatedByModifiedBy !== null) {
                if (!$this->aLibrarianRelatedByModifiedBy->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aLibrarianRelatedByModifiedBy->getValidationFailures());
                }
            }

            if ($this->aLibrary !== null) {
                if (!$this->aLibrary->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aLibrary->getValidationFailures());
                }
            }


            if (($retval = DocumentTemplatePeer::doValidate($this, $columns)) !== true) {
                $failureMap = array_merge($failureMap, $retval);
            }



            $this->alreadyInValidation = false;
        }

        return (!empty($failureMap) ? $failureMap : true);
    }

    /**
     * Retrieves a field from the object by name passed in as a string.
     *
     * @param string $name name
     * @param string $type The type of fieldname the $name is of:
     *               one of the class type constants BasePeer::TYPE_PHPNAME, BasePeer::TYPE_STUDLYPHPNAME
     *               BasePeer::TYPE_COLNAME, BasePeer::TYPE_FIELDNAME, BasePeer::TYPE_NUM.
     *               Defaults to BasePeer::TYPE_PHPNAME
     * @return mixed Value of field.
     */
    public function getByName($name, $type = BasePeer::TYPE_PHPNAME)
    {
        $pos = DocumentTemplatePeer::translateFieldName($name, $type, BasePeer::TYPE_NUM);
        $field = $this->getByPosition($pos);

        return $field;
    }

    /**
     * Retrieves a field from the object by Position as specified in the xml schema.
     * Zero-based.
     *
     * @param int $pos position in xml schema
     * @return mixed Value of field at $pos
     */
    public function getByPosition($pos)
    {
        switch ($pos) {
            case 0:
                return $this->getDocumentTemplateId();
                break;
            case 1:
                return $this->getTemplateMedia();
                break;
            case 2:
                return $this->getTemplateDescription();
                break;
            case 3:
                return $this->getTemplateTitle();
                break;
            case 4:
                return $this->getTemplateSubject();
                break;
            case 5:
                return $this->getTemplateBody();
                break;
            case 6:
                return $this->getTemplateClass();
                break;
            case 7:
                return $this->getTemplateLang();
                break;
            case 8:
                return $this->getLibraryId();
                break;
            case 9:
                return $this->getDateCreated();
                break;
            case 10:
                return $this->getDateUpdated();
                break;
            case 11:
                return $this->getCreatedBy();
                break;
            case 12:
                return $this->getModifiedBy();
                break;
            default:
                return null;
                break;
        } // switch()
    }

    /**
     * Exports the object as an array.
     *
     * You can specify the key type of the array by passing one of the class
     * type constants.
     *
     * @param     string  $keyType (optional) One of the class type constants BasePeer::TYPE_PHPNAME, BasePeer::TYPE_STUDLYPHPNAME,
     *                    BasePeer::TYPE_COLNAME, BasePeer::TYPE_FIELDNAME, BasePeer::TYPE_NUM.
     *                    Defaults to BasePeer::TYPE_PHPNAME.
     * @param     boolean $includeLazyLoadColumns (optional) Whether to include lazy loaded columns. Defaults to true.
     * @param     array $alreadyDumpedObjects List of objects to skip to avoid recursion
     * @param     boolean $includeForeignObjects (optional) Whether to include hydrated related objects. Default to FALSE.
     *
     * @return array an associative array containing the field names (as keys) and field values
     */
    public function toArray($keyType = BasePeer::TYPE_PHPNAME, $includeLazyLoadColumns = true, $alreadyDumpedObjects = array(), $includeForeignObjects = false)
    {
        if (isset($alreadyDumpedObjects['DocumentTemplate'][$this->getPrimaryKey()])) {
            return '*RECURSION*';
        }
        $alreadyDumpedObjects['DocumentTemplate'][$this->getPrimaryKey()] = true;
        $keys = DocumentTemplatePeer::getFieldNames($keyType);
        $result = array(
            $keys[0] => $this->getDocumentTemplateId(),
            $keys[1] => $this->getTemplateMedia(),
            $keys[2] => $this->getTemplateDescription(),
            $keys[3] => $this->getTemplateTitle(),
            $keys[4] => $this->getTemplateSubject(),
            $keys[5] => $this->getTemplateBody(),
            $keys[6] => $this->getTemplateClass(),
            $keys[7] => $this->getTemplateLang(),
            $keys[8] => $this->getLibraryId(),
            $keys[9] => $this->getDateCreated(),
            $keys[10] => $this->getDateUpdated(),
            $keys[11] => $this->getCreatedBy(),
            $keys[12] => $this->getModifiedBy(),
        );
        $virtualColumns = $this->virtualColumns;
        foreach ($virtualColumns as $key => $virtualColumn) {
            $result[$key] = $virtualColumn;
        }

        if ($includeForeignObjects) {
            if (null !== $this->aLibrarianRelatedByCreatedBy) {
                $result['LibrarianRelatedByCreatedBy'] = $this->aLibrarianRelatedByCreatedBy->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->aLibrarianRelatedByModifiedBy) {
                $result['LibrarianRelatedByModifiedBy'] = $this->aLibrarianRelatedByModifiedBy->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->aLibrary) {
                $result['Library'] = $this->aLibrary->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
        }

        return $result;
    }

    /**
     * Sets a field from the object by name passed in as a string.
     *
     * @param string $name peer name
     * @param mixed $value field value
     * @param string $type The type of fieldname the $name is of:
     *                     one of the class type constants BasePeer::TYPE_PHPNAME, BasePeer::TYPE_STUDLYPHPNAME
     *                     BasePeer::TYPE_COLNAME, BasePeer::TYPE_FIELDNAME, BasePeer::TYPE_NUM.
     *                     Defaults to BasePeer::TYPE_PHPNAME
     * @return void
     */
    public function setByName($name, $value, $type = BasePeer::TYPE_PHPNAME)
    {
        $pos = DocumentTemplatePeer::translateFieldName($name, $type, BasePeer::TYPE_NUM);

        $this->setByPosition($pos, $value);
    }

    /**
     * Sets a field from the object by Position as specified in the xml schema.
     * Zero-based.
     *
     * @param int $pos position in xml schema
     * @param mixed $value field value
     * @return void
     */
    public function setByPosition($pos, $value)
    {
        switch ($pos) {
            case 0:
                $this->setDocumentTemplateId($value);
                break;
            case 1:
                $this->setTemplateMedia($value);
                break;
            case 2:
                $this->setTemplateDescription($value);
                break;
            case 3:
                $this->setTemplateTitle($value);
                break;
            case 4:
                $this->setTemplateSubject($value);
                break;
            case 5:
                $this->setTemplateBody($value);
                break;
            case 6:
                $this->setTemplateClass($value);
                break;
            case 7:
                $this->setTemplateLang($value);
                break;
            case 8:
                $this->setLibraryId($value);
                break;
            case 9:
                $this->setDateCreated($value);
                break;
            case 10:
                $this->setDateUpdated($value);
                break;
            case 11:
                $this->setCreatedBy($value);
                break;
            case 12:
                $this->setModifiedBy($value);
                break;
        } // switch()
    }

    /**
     * Populates the object using an array.
     *
     * This is particularly useful when populating an object from one of the
     * request arrays (e.g. $_POST).  This method goes through the column
     * names, checking to see whether a matching key exists in populated
     * array. If so the setByName() method is called for that column.
     *
     * You can specify the key type of the array by additionally passing one
     * of the class type constants BasePeer::TYPE_PHPNAME, BasePeer::TYPE_STUDLYPHPNAME,
     * BasePeer::TYPE_COLNAME, BasePeer::TYPE_FIELDNAME, BasePeer::TYPE_NUM.
     * The default key type is the column's BasePeer::TYPE_PHPNAME
     *
     * @param array  $arr     An array to populate the object from.
     * @param string $keyType The type of keys the array uses.
     * @return void
     */
    public function fromArray($arr, $keyType = BasePeer::TYPE_PHPNAME)
    {
        $keys = DocumentTemplatePeer::getFieldNames($keyType);

        if (array_key_exists($keys[0], $arr)) $this->setDocumentTemplateId($arr[$keys[0]]);
        if (array_key_exists($keys[1], $arr)) $this->setTemplateMedia($arr[$keys[1]]);
        if (array_key_exists($keys[2], $arr)) $this->setTemplateDescription($arr[$keys[2]]);
        if (array_key_exists($keys[3], $arr)) $this->setTemplateTitle($arr[$keys[3]]);
        if (array_key_exists($keys[4], $arr)) $this->setTemplateSubject($arr[$keys[4]]);
        if (array_key_exists($keys[5], $arr)) $this->setTemplateBody($arr[$keys[5]]);
        if (array_key_exists($keys[6], $arr)) $this->setTemplateClass($arr[$keys[6]]);
        if (array_key_exists($keys[7], $arr)) $this->setTemplateLang($arr[$keys[7]]);
        if (array_key_exists($keys[8], $arr)) $this->setLibraryId($arr[$keys[8]]);
        if (array_key_exists($keys[9], $arr)) $this->setDateCreated($arr[$keys[9]]);
        if (array_key_exists($keys[10], $arr)) $this->setDateUpdated($arr[$keys[10]]);
        if (array_key_exists($keys[11], $arr)) $this->setCreatedBy($arr[$keys[11]]);
        if (array_key_exists($keys[12], $arr)) $this->setModifiedBy($arr[$keys[12]]);
    }

    /**
     * Build a Criteria object containing the values of all modified columns in this object.
     *
     * @return Criteria The Criteria object containing all modified values.
     */
    public function buildCriteria()
    {
        $criteria = new Criteria(DocumentTemplatePeer::DATABASE_NAME);

        if ($this->isColumnModified(DocumentTemplatePeer::DOCUMENT_TEMPLATE_ID)) $criteria->add(DocumentTemplatePeer::DOCUMENT_TEMPLATE_ID, $this->document_template_id);
        if ($this->isColumnModified(DocumentTemplatePeer::TEMPLATE_MEDIA)) $criteria->add(DocumentTemplatePeer::TEMPLATE_MEDIA, $this->template_media);
        if ($this->isColumnModified(DocumentTemplatePeer::TEMPLATE_DESCRIPTION)) $criteria->add(DocumentTemplatePeer::TEMPLATE_DESCRIPTION, $this->template_description);
        if ($this->isColumnModified(DocumentTemplatePeer::TEMPLATE_TITLE)) $criteria->add(DocumentTemplatePeer::TEMPLATE_TITLE, $this->template_title);
        if ($this->isColumnModified(DocumentTemplatePeer::TEMPLATE_SUBJECT)) $criteria->add(DocumentTemplatePeer::TEMPLATE_SUBJECT, $this->template_subject);
        if ($this->isColumnModified(DocumentTemplatePeer::TEMPLATE_BODY)) $criteria->add(DocumentTemplatePeer::TEMPLATE_BODY, $this->template_body);
        if ($this->isColumnModified(DocumentTemplatePeer::TEMPLATE_CLASS)) $criteria->add(DocumentTemplatePeer::TEMPLATE_CLASS, $this->template_class);
        if ($this->isColumnModified(DocumentTemplatePeer::TEMPLATE_LANG)) $criteria->add(DocumentTemplatePeer::TEMPLATE_LANG, $this->template_lang);
        if ($this->isColumnModified(DocumentTemplatePeer::LIBRARY_ID)) $criteria->add(DocumentTemplatePeer::LIBRARY_ID, $this->library_id);
        if ($this->isColumnModified(DocumentTemplatePeer::DATE_CREATED)) $criteria->add(DocumentTemplatePeer::DATE_CREATED, $this->date_created);
        if ($this->isColumnModified(DocumentTemplatePeer::DATE_UPDATED)) $criteria->add(DocumentTemplatePeer::DATE_UPDATED, $this->date_updated);
        if ($this->isColumnModified(DocumentTemplatePeer::CREATED_BY)) $criteria->add(DocumentTemplatePeer::CREATED_BY, $this->created_by);
        if ($this->isColumnModified(DocumentTemplatePeer::MODIFIED_BY)) $criteria->add(DocumentTemplatePeer::MODIFIED_BY, $this->modified_by);

        return $criteria;
    }

    /**
     * Builds a Criteria object containing the primary key for this object.
     *
     * Unlike buildCriteria() this method includes the primary key values regardless
     * of whether or not they have been modified.
     *
     * @return Criteria The Criteria object containing value(s) for primary key(s).
     */
    public function buildPkeyCriteria()
    {
        $criteria = new Criteria(DocumentTemplatePeer::DATABASE_NAME);
        $criteria->add(DocumentTemplatePeer::DOCUMENT_TEMPLATE_ID, $this->document_template_id);

        return $criteria;
    }

    /**
     * Returns the primary key for this object (row).
     * @return int
     */
    public function getPrimaryKey()
    {
        return $this->getDocumentTemplateId();
    }

    /**
     * Generic method to set the primary key (document_template_id column).
     *
     * @param  int $key Primary key.
     * @return void
     */
    public function setPrimaryKey($key)
    {
        $this->setDocumentTemplateId($key);
    }

    /**
     * Returns true if the primary key for this object is null.
     * @return boolean
     */
    public function isPrimaryKeyNull()
    {

        return null === $this->getDocumentTemplateId();
    }

    /**
     * Sets contents of passed object to values from current object.
     *
     * If desired, this method can also make copies of all associated (fkey referrers)
     * objects.
     *
     * @param object $copyObj An object of DocumentTemplate (or compatible) type.
     * @param boolean $deepCopy Whether to also copy all rows that refer (by fkey) to the current row.
     * @param boolean $makeNew Whether to reset autoincrement PKs and make the object new.
     * @throws PropelException
     */
    public function copyInto($copyObj, $deepCopy = false, $makeNew = true)
    {
        $copyObj->setTemplateMedia($this->getTemplateMedia());
        $copyObj->setTemplateDescription($this->getTemplateDescription());
        $copyObj->setTemplateTitle($this->getTemplateTitle());
        $copyObj->setTemplateSubject($this->getTemplateSubject());
        $copyObj->setTemplateBody($this->getTemplateBody());
        $copyObj->setTemplateClass($this->getTemplateClass());
        $copyObj->setTemplateLang($this->getTemplateLang());
        $copyObj->setLibraryId($this->getLibraryId());
        $copyObj->setDateCreated($this->getDateCreated());
        $copyObj->setDateUpdated($this->getDateUpdated());
        $copyObj->setCreatedBy($this->getCreatedBy());
        $copyObj->setModifiedBy($this->getModifiedBy());

        if ($deepCopy && !$this->startCopy) {
            // important: temporarily setNew(false) because this affects the behavior of
            // the getter/setter methods for fkey referrer objects.
            $copyObj->setNew(false);
            // store object hash to prevent cycle
            $this->startCopy = true;

            //unflag object copy
            $this->startCopy = false;
        } // if ($deepCopy)

        if ($makeNew) {
            $copyObj->setNew(true);
            $copyObj->setDocumentTemplateId(NULL); // this is a auto-increment column, so set to default value
        }
    }

    /**
     * Makes a copy of this object that will be inserted as a new row in table when saved.
     * It creates a new object filling in the simple attributes, but skipping any primary
     * keys that are defined for the table.
     *
     * If desired, this method can also make copies of all associated (fkey referrers)
     * objects.
     *
     * @param boolean $deepCopy Whether to also copy all rows that refer (by fkey) to the current row.
     * @return DocumentTemplate Clone of current object.
     * @throws PropelException
     */
    public function copy($deepCopy = false)
    {
        // we use get_class(), because this might be a subclass
        $clazz = get_class($this);
        $copyObj = new $clazz();
        $this->copyInto($copyObj, $deepCopy);

        return $copyObj;
    }

    /**
     * Returns a peer instance associated with this om.
     *
     * Since Peer classes are not to have any instance attributes, this method returns the
     * same instance for all member of this class. The method could therefore
     * be static, but this would prevent one from overriding the behavior.
     *
     * @return DocumentTemplatePeer
     */
    public function getPeer()
    {
        if (self::$peer === null) {
            self::$peer = new DocumentTemplatePeer();
        }

        return self::$peer;
    }

    /**
     * Declares an association between this object and a Librarian object.
     *
     * @param                  Librarian $v
     * @return DocumentTemplate The current object (for fluent API support)
     * @throws PropelException
     */
    public function setLibrarianRelatedByCreatedBy(Librarian $v = null)
    {
        if ($v === null) {
            $this->setCreatedBy(NULL);
        } else {
            $this->setCreatedBy($v->getLibrarianId());
        }

        $this->aLibrarianRelatedByCreatedBy = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the Librarian object, it will not be re-added.
        if ($v !== null) {
            $v->addDocumentTemplateRelatedByCreatedBy($this);
        }


        return $this;
    }


    /**
     * Get the associated Librarian object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return Librarian The associated Librarian object.
     * @throws PropelException
     */
    public function getLibrarianRelatedByCreatedBy(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aLibrarianRelatedByCreatedBy === null && ($this->created_by !== null) && $doQuery) {
            $this->aLibrarianRelatedByCreatedBy = LibrarianQuery::create()->findPk($this->created_by, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aLibrarianRelatedByCreatedBy->addDocumentTemplatesRelatedByCreatedBy($this);
             */
        }

        return $this->aLibrarianRelatedByCreatedBy;
    }

    /**
     * Declares an association between this object and a Librarian object.
     *
     * @param                  Librarian $v
     * @return DocumentTemplate The current object (for fluent API support)
     * @throws PropelException
     */
    public function setLibrarianRelatedByModifiedBy(Librarian $v = null)
    {
        if ($v === null) {
            $this->setModifiedBy(NULL);
        } else {
            $this->setModifiedBy($v->getLibrarianId());
        }

        $this->aLibrarianRelatedByModifiedBy = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the Librarian object, it will not be re-added.
        if ($v !== null) {
            $v->addDocumentTemplateRelatedByModifiedBy($this);
        }


        return $this;
    }


    /**
     * Get the associated Librarian object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return Librarian The associated Librarian object.
     * @throws PropelException
     */
    public function getLibrarianRelatedByModifiedBy(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aLibrarianRelatedByModifiedBy === null && ($this->modified_by !== null) && $doQuery) {
            $this->aLibrarianRelatedByModifiedBy = LibrarianQuery::create()->findPk($this->modified_by, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aLibrarianRelatedByModifiedBy->addDocumentTemplatesRelatedByModifiedBy($this);
             */
        }

        return $this->aLibrarianRelatedByModifiedBy;
    }

    /**
     * Declares an association between this object and a Library object.
     *
     * @param                  Library $v
     * @return DocumentTemplate The current object (for fluent API support)
     * @throws PropelException
     */
    public function setLibrary(Library $v = null)
    {
        if ($v === null) {
            $this->setLibraryId(NULL);
        } else {
            $this->setLibraryId($v->getLibraryId());
        }

        $this->aLibrary = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the Library object, it will not be re-added.
        if ($v !== null) {
            $v->addDocumentTemplate($this);
        }


        return $this;
    }


    /**
     * Get the associated Library object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return Library The associated Library object.
     * @throws PropelException
     */
    public function getLibrary(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aLibrary === null && ($this->library_id !== null) && $doQuery) {
            $this->aLibrary = LibraryQuery::create()->findPk($this->library_id, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aLibrary->addDocumentTemplates($this);
             */
        }

        return $this->aLibrary;
    }

    /**
     * Clears the current object and sets all attributes to their default values
     */
    public function clear()
    {
        $this->document_template_id = null;
        $this->template_media = null;
        $this->template_description = null;
        $this->template_title = null;
        $this->template_subject = null;
        $this->template_body = null;
        $this->template_class = null;
        $this->template_lang = null;
        $this->library_id = null;
        $this->date_created = null;
        $this->date_updated = null;
        $this->created_by = null;
        $this->modified_by = null;
        $this->alreadyInSave = false;
        $this->alreadyInValidation = false;
        $this->alreadyInClearAllReferencesDeep = false;
        $this->clearAllReferences();
        $this->resetModified();
        $this->setNew(true);
        $this->setDeleted(false);
    }

    /**
     * Resets all references to other model objects or collections of model objects.
     *
     * This method is a user-space workaround for PHP's inability to garbage collect
     * objects with circular references (even in PHP 5.3). This is currently necessary
     * when using Propel in certain daemon or large-volume/high-memory operations.
     *
     * @param boolean $deep Whether to also clear the references on all referrer objects.
     */
    public function clearAllReferences($deep = false)
    {
        if ($deep && !$this->alreadyInClearAllReferencesDeep) {
            $this->alreadyInClearAllReferencesDeep = true;
            if ($this->aLibrarianRelatedByCreatedBy instanceof Persistent) {
              $this->aLibrarianRelatedByCreatedBy->clearAllReferences($deep);
            }
            if ($this->aLibrarianRelatedByModifiedBy instanceof Persistent) {
              $this->aLibrarianRelatedByModifiedBy->clearAllReferences($deep);
            }
            if ($this->aLibrary instanceof Persistent) {
              $this->aLibrary->clearAllReferences($deep);
            }

            $this->alreadyInClearAllReferencesDeep = false;
        } // if ($deep)

        $this->aLibrarianRelatedByCreatedBy = null;
        $this->aLibrarianRelatedByModifiedBy = null;
        $this->aLibrary = null;
    }

    /**
     * return the string representation of this object
     *
     * @return string
     */
    public function __toString()
    {
        return (string) $this->exportTo(DocumentTemplatePeer::DEFAULT_STRING_FORMAT);
    }

    /**
     * return true is the object is in saving state
     *
     * @return boolean
     */
    public function isAlreadyInSave()
    {
        return $this->alreadyInSave;
    }

    // timestampable behavior

    /**
     * Mark the current object so that the update date doesn't get updated during next save
     *
     * @return     DocumentTemplate The current object (for fluent API support)
     */
    public function keepUpdateDateUnchanged()
    {
        $this->modifiedColumns[] = DocumentTemplatePeer::DATE_UPDATED;

        return $this;
    }

    // librariantrace behavior

    /**
     * Returns the complete name of the librarian that created this object.
     *
     * @return string
     */
    public function getCreatedByNameString()
    {
        $l = $this->getLibrarianRelatedByCreatedBy();
        return ($l instanceof Librarian) ? $l->getCompleteName() : '';
    }

    /**
     * Returns the complete name of the librarian that last updated this object.
     *
     * @return string
     */
    public function getModifiedByNameString()
    {
        $l = $this->getLibrarianRelatedByModifiedBy();
        return ($l instanceof Librarian) ? $l->getCompleteName() : '';
    }

    /**
     * Mark the current object so that the update date doesn't get updated during next save
     *
     * @return     DocumentTemplate The current object (for fluent API support)
     */
    public function keepUpdateLibrarianUnchanged()
    {
        $this->modifiedColumns[] = DocumentTemplatePeer::MODIFIED_BY;
        return $this;
    }

}
