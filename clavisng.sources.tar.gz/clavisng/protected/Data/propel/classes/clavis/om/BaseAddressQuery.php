<?php


/**
 * Base class that represents a query for the 'address' table.
 *
 *
 *
 * @method AddressQuery orderByAddressId($order = Criteria::ASC) Order by the address_id column
 * @method AddressQuery orderByPatronId($order = Criteria::ASC) Order by the patron_id column
 * @method AddressQuery orderByAddressType($order = Criteria::ASC) Order by the address_type column
 * @method AddressQuery orderByAddressPref($order = Criteria::ASC) Order by the address_pref column
 * @method AddressQuery orderByAddressNote($order = Criteria::ASC) Order by the address_note column
 * @method AddressQuery orderByStreetType($order = Criteria::ASC) Order by the street_type column
 * @method AddressQuery orderByStreet($order = Criteria::ASC) Order by the street column
 * @method AddressQuery orderByStreetNum($order = Criteria::ASC) Order by the street_num column
 * @method AddressQuery orderByVillage($order = Criteria::ASC) Order by the village column
 * @method AddressQuery orderByCity($order = Criteria::ASC) Order by the city column
 * @method AddressQuery orderByZip($order = Criteria::ASC) Order by the zip column
 * @method AddressQuery orderByProvince($order = Criteria::ASC) Order by the province column
 * @method AddressQuery orderByCountry($order = Criteria::ASC) Order by the country column
 *
 * @method AddressQuery groupByAddressId() Group by the address_id column
 * @method AddressQuery groupByPatronId() Group by the patron_id column
 * @method AddressQuery groupByAddressType() Group by the address_type column
 * @method AddressQuery groupByAddressPref() Group by the address_pref column
 * @method AddressQuery groupByAddressNote() Group by the address_note column
 * @method AddressQuery groupByStreetType() Group by the street_type column
 * @method AddressQuery groupByStreet() Group by the street column
 * @method AddressQuery groupByStreetNum() Group by the street_num column
 * @method AddressQuery groupByVillage() Group by the village column
 * @method AddressQuery groupByCity() Group by the city column
 * @method AddressQuery groupByZip() Group by the zip column
 * @method AddressQuery groupByProvince() Group by the province column
 * @method AddressQuery groupByCountry() Group by the country column
 *
 * @method AddressQuery leftJoin($relation) Adds a LEFT JOIN clause to the query
 * @method AddressQuery rightJoin($relation) Adds a RIGHT JOIN clause to the query
 * @method AddressQuery innerJoin($relation) Adds a INNER JOIN clause to the query
 *
 * @method AddressQuery leftJoinPatron($relationAlias = null) Adds a LEFT JOIN clause to the query using the Patron relation
 * @method AddressQuery rightJoinPatron($relationAlias = null) Adds a RIGHT JOIN clause to the query using the Patron relation
 * @method AddressQuery innerJoinPatron($relationAlias = null) Adds a INNER JOIN clause to the query using the Patron relation
 *
 * @method Address findOne(PropelPDO $con = null) Return the first Address matching the query
 * @method Address findOneOrCreate(PropelPDO $con = null) Return the first Address matching the query, or a new Address object populated from the query conditions when no match is found
 *
 * @method Address findOneByPatronId(int $patron_id) Return the first Address filtered by the patron_id column
 * @method Address findOneByAddressType(string $address_type) Return the first Address filtered by the address_type column
 * @method Address findOneByAddressPref(string $address_pref) Return the first Address filtered by the address_pref column
 * @method Address findOneByAddressNote(string $address_note) Return the first Address filtered by the address_note column
 * @method Address findOneByStreetType(string $street_type) Return the first Address filtered by the street_type column
 * @method Address findOneByStreet(string $street) Return the first Address filtered by the street column
 * @method Address findOneByStreetNum(string $street_num) Return the first Address filtered by the street_num column
 * @method Address findOneByVillage(string $village) Return the first Address filtered by the village column
 * @method Address findOneByCity(string $city) Return the first Address filtered by the city column
 * @method Address findOneByZip(string $zip) Return the first Address filtered by the zip column
 * @method Address findOneByProvince(string $province) Return the first Address filtered by the province column
 * @method Address findOneByCountry(string $country) Return the first Address filtered by the country column
 *
 * @method array findByAddressId(int $address_id) Return Address objects filtered by the address_id column
 * @method array findByPatronId(int $patron_id) Return Address objects filtered by the patron_id column
 * @method array findByAddressType(string $address_type) Return Address objects filtered by the address_type column
 * @method array findByAddressPref(string $address_pref) Return Address objects filtered by the address_pref column
 * @method array findByAddressNote(string $address_note) Return Address objects filtered by the address_note column
 * @method array findByStreetType(string $street_type) Return Address objects filtered by the street_type column
 * @method array findByStreet(string $street) Return Address objects filtered by the street column
 * @method array findByStreetNum(string $street_num) Return Address objects filtered by the street_num column
 * @method array findByVillage(string $village) Return Address objects filtered by the village column
 * @method array findByCity(string $city) Return Address objects filtered by the city column
 * @method array findByZip(string $zip) Return Address objects filtered by the zip column
 * @method array findByProvince(string $province) Return Address objects filtered by the province column
 * @method array findByCountry(string $country) Return Address objects filtered by the country column
 *
 * @package    propel.generator.clavis.om
 */
abstract class BaseAddressQuery extends ModelCriteria
{
    /**
     * Initializes internal state of BaseAddressQuery object.
     *
     * @param     string $dbName The dabase name
     * @param     string $modelName The phpName of a model, e.g. 'Book'
     * @param     string $modelAlias The alias for the model in this query, e.g. 'b'
     */
    public function __construct($dbName = null, $modelName = null, $modelAlias = null)
    {
        if (null === $dbName) {
            $dbName = 'clavis';
        }
        if (null === $modelName) {
            $modelName = 'Address';
        }
        parent::__construct($dbName, $modelName, $modelAlias);
    }

    /**
     * Returns a new AddressQuery object.
     *
     * @param     string $modelAlias The alias of a model in the query
     * @param   AddressQuery|Criteria $criteria Optional Criteria to build the query from
     *
     * @return AddressQuery
     */
    public static function create($modelAlias = null, $criteria = null)
    {
        if ($criteria instanceof AddressQuery) {
            return $criteria;
        }
        $query = new AddressQuery(null, null, $modelAlias);

        if ($criteria instanceof Criteria) {
            $query->mergeWith($criteria);
        }

        return $query;
    }

    /**
     * Find object by primary key.
     * Propel uses the instance pool to skip the database if the object exists.
     * Go fast if the query is untouched.
     *
     * <code>
     * $obj  = $c->findPk(12, $con);
     * </code>
     *
     * @param mixed $key Primary key to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return   Address|Address[]|mixed the result, formatted by the current formatter
     */
    public function findPk($key, $con = null)
    {
        if ($key === null) {
            return null;
        }
        if ((null !== ($obj = AddressPeer::getInstanceFromPool((string) $key))) && !$this->formatter) {
            // the object is already in the instance pool
            return $obj;
        }
        if ($con === null) {
            $con = Propel::getConnection(AddressPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        if ($this->formatter || $this->modelAlias || $this->with || $this->select
         || $this->selectColumns || $this->asColumns || $this->selectModifiers
         || $this->map || $this->having || $this->joins) {
            return $this->findPkComplex($key, $con);
        } else {
            return $this->findPkSimple($key, $con);
        }
    }

    /**
     * Alias of findPk to use instance pooling
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 Address A model object, or null if the key is not found
     * @throws PropelException
     */
     public function findOneByAddressId($key, $con = null)
     {
        return $this->findPk($key, $con);
     }

    /**
     * Find object by primary key using raw SQL to go fast.
     * Bypass doSelect() and the object formatter by using generated code.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 Address A model object, or null if the key is not found
     * @throws PropelException
     */
    protected function findPkSimple($key, $con)
    {
        $sql = 'SELECT `address_id`, `patron_id`, `address_type`, `address_pref`, `address_note`, `street_type`, `street`, `street_num`, `village`, `city`, `zip`, `province`, `country` FROM `address` WHERE `address_id` = :p0';
        try {
            $stmt = $con->prepare($sql);
            $stmt->bindValue(':p0', $key, PDO::PARAM_INT);
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute SELECT statement [%s]', $sql), $e);
        }
        $obj = null;
        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $obj = new Address();
            $obj->hydrate($row);
            AddressPeer::addInstanceToPool($obj, (string) $key);
        }
        $stmt->closeCursor();

        return $obj;
    }

    /**
     * Find object by primary key.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return Address|Address[]|mixed the result, formatted by the current formatter
     */
    protected function findPkComplex($key, $con)
    {
        // As the query uses a PK condition, no limit(1) is necessary.
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKey($key)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->formatOne($stmt);
    }

    /**
     * Find objects by primary key
     * <code>
     * $objs = $c->findPks(array(12, 56, 832), $con);
     * </code>
     * @param     array $keys Primary keys to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return PropelObjectCollection|Address[]|mixed the list of results, formatted by the current formatter
     */
    public function findPks($keys, $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection($this->getDbName(), Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKeys($keys)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->format($stmt);
    }

    /**
     * Filter the query by primary key
     *
     * @param     mixed $key Primary key to use for the query
     *
     * @return AddressQuery The current query, for fluid interface
     */
    public function filterByPrimaryKey($key)
    {

        return $this->addUsingAlias(AddressPeer::ADDRESS_ID, $key, Criteria::EQUAL);
    }

    /**
     * Filter the query by a list of primary keys
     *
     * @param     array $keys The list of primary key to use for the query
     *
     * @return AddressQuery The current query, for fluid interface
     */
    public function filterByPrimaryKeys($keys)
    {

        return $this->addUsingAlias(AddressPeer::ADDRESS_ID, $keys, Criteria::IN);
    }

    /**
     * Filter the query on the address_id column
     *
     * Example usage:
     * <code>
     * $query->filterByAddressId(1234); // WHERE address_id = 1234
     * $query->filterByAddressId(array(12, 34)); // WHERE address_id IN (12, 34)
     * $query->filterByAddressId(array('min' => 12)); // WHERE address_id >= 12
     * $query->filterByAddressId(array('max' => 12)); // WHERE address_id <= 12
     * </code>
     *
     * @param     mixed $addressId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return AddressQuery The current query, for fluid interface
     */
    public function filterByAddressId($addressId = null, $comparison = null)
    {
        if (is_array($addressId)) {
            $useMinMax = false;
            if (isset($addressId['min'])) {
                $this->addUsingAlias(AddressPeer::ADDRESS_ID, $addressId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($addressId['max'])) {
                $this->addUsingAlias(AddressPeer::ADDRESS_ID, $addressId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(AddressPeer::ADDRESS_ID, $addressId, $comparison);
    }

    /**
     * Filter the query on the patron_id column
     *
     * Example usage:
     * <code>
     * $query->filterByPatronId(1234); // WHERE patron_id = 1234
     * $query->filterByPatronId(array(12, 34)); // WHERE patron_id IN (12, 34)
     * $query->filterByPatronId(array('min' => 12)); // WHERE patron_id >= 12
     * $query->filterByPatronId(array('max' => 12)); // WHERE patron_id <= 12
     * </code>
     *
     * @see       filterByPatron()
     *
     * @param     mixed $patronId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return AddressQuery The current query, for fluid interface
     */
    public function filterByPatronId($patronId = null, $comparison = null)
    {
        if (is_array($patronId)) {
            $useMinMax = false;
            if (isset($patronId['min'])) {
                $this->addUsingAlias(AddressPeer::PATRON_ID, $patronId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($patronId['max'])) {
                $this->addUsingAlias(AddressPeer::PATRON_ID, $patronId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(AddressPeer::PATRON_ID, $patronId, $comparison);
    }

    /**
     * Filter the query on the address_type column
     *
     * Example usage:
     * <code>
     * $query->filterByAddressType('fooValue');   // WHERE address_type = 'fooValue'
     * $query->filterByAddressType('%fooValue%'); // WHERE address_type LIKE '%fooValue%'
     * </code>
     *
     * @param     string $addressType The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return AddressQuery The current query, for fluid interface
     */
    public function filterByAddressType($addressType = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($addressType)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $addressType)) {
                $addressType = str_replace('*', '%', $addressType);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(AddressPeer::ADDRESS_TYPE, $addressType, $comparison);
    }

    /**
     * Filter the query on the address_pref column
     *
     * Example usage:
     * <code>
     * $query->filterByAddressPref('fooValue');   // WHERE address_pref = 'fooValue'
     * $query->filterByAddressPref('%fooValue%'); // WHERE address_pref LIKE '%fooValue%'
     * </code>
     *
     * @param     string $addressPref The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return AddressQuery The current query, for fluid interface
     */
    public function filterByAddressPref($addressPref = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($addressPref)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $addressPref)) {
                $addressPref = str_replace('*', '%', $addressPref);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(AddressPeer::ADDRESS_PREF, $addressPref, $comparison);
    }

    /**
     * Filter the query on the address_note column
     *
     * Example usage:
     * <code>
     * $query->filterByAddressNote('fooValue');   // WHERE address_note = 'fooValue'
     * $query->filterByAddressNote('%fooValue%'); // WHERE address_note LIKE '%fooValue%'
     * </code>
     *
     * @param     string $addressNote The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return AddressQuery The current query, for fluid interface
     */
    public function filterByAddressNote($addressNote = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($addressNote)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $addressNote)) {
                $addressNote = str_replace('*', '%', $addressNote);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(AddressPeer::ADDRESS_NOTE, $addressNote, $comparison);
    }

    /**
     * Filter the query on the street_type column
     *
     * Example usage:
     * <code>
     * $query->filterByStreetType('fooValue');   // WHERE street_type = 'fooValue'
     * $query->filterByStreetType('%fooValue%'); // WHERE street_type LIKE '%fooValue%'
     * </code>
     *
     * @param     string $streetType The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return AddressQuery The current query, for fluid interface
     */
    public function filterByStreetType($streetType = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($streetType)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $streetType)) {
                $streetType = str_replace('*', '%', $streetType);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(AddressPeer::STREET_TYPE, $streetType, $comparison);
    }

    /**
     * Filter the query on the street column
     *
     * Example usage:
     * <code>
     * $query->filterByStreet('fooValue');   // WHERE street = 'fooValue'
     * $query->filterByStreet('%fooValue%'); // WHERE street LIKE '%fooValue%'
     * </code>
     *
     * @param     string $street The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return AddressQuery The current query, for fluid interface
     */
    public function filterByStreet($street = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($street)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $street)) {
                $street = str_replace('*', '%', $street);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(AddressPeer::STREET, $street, $comparison);
    }

    /**
     * Filter the query on the street_num column
     *
     * Example usage:
     * <code>
     * $query->filterByStreetNum('fooValue');   // WHERE street_num = 'fooValue'
     * $query->filterByStreetNum('%fooValue%'); // WHERE street_num LIKE '%fooValue%'
     * </code>
     *
     * @param     string $streetNum The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return AddressQuery The current query, for fluid interface
     */
    public function filterByStreetNum($streetNum = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($streetNum)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $streetNum)) {
                $streetNum = str_replace('*', '%', $streetNum);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(AddressPeer::STREET_NUM, $streetNum, $comparison);
    }

    /**
     * Filter the query on the village column
     *
     * Example usage:
     * <code>
     * $query->filterByVillage('fooValue');   // WHERE village = 'fooValue'
     * $query->filterByVillage('%fooValue%'); // WHERE village LIKE '%fooValue%'
     * </code>
     *
     * @param     string $village The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return AddressQuery The current query, for fluid interface
     */
    public function filterByVillage($village = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($village)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $village)) {
                $village = str_replace('*', '%', $village);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(AddressPeer::VILLAGE, $village, $comparison);
    }

    /**
     * Filter the query on the city column
     *
     * Example usage:
     * <code>
     * $query->filterByCity('fooValue');   // WHERE city = 'fooValue'
     * $query->filterByCity('%fooValue%'); // WHERE city LIKE '%fooValue%'
     * </code>
     *
     * @param     string $city The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return AddressQuery The current query, for fluid interface
     */
    public function filterByCity($city = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($city)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $city)) {
                $city = str_replace('*', '%', $city);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(AddressPeer::CITY, $city, $comparison);
    }

    /**
     * Filter the query on the zip column
     *
     * Example usage:
     * <code>
     * $query->filterByZip('fooValue');   // WHERE zip = 'fooValue'
     * $query->filterByZip('%fooValue%'); // WHERE zip LIKE '%fooValue%'
     * </code>
     *
     * @param     string $zip The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return AddressQuery The current query, for fluid interface
     */
    public function filterByZip($zip = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($zip)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $zip)) {
                $zip = str_replace('*', '%', $zip);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(AddressPeer::ZIP, $zip, $comparison);
    }

    /**
     * Filter the query on the province column
     *
     * Example usage:
     * <code>
     * $query->filterByProvince('fooValue');   // WHERE province = 'fooValue'
     * $query->filterByProvince('%fooValue%'); // WHERE province LIKE '%fooValue%'
     * </code>
     *
     * @param     string $province The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return AddressQuery The current query, for fluid interface
     */
    public function filterByProvince($province = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($province)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $province)) {
                $province = str_replace('*', '%', $province);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(AddressPeer::PROVINCE, $province, $comparison);
    }

    /**
     * Filter the query on the country column
     *
     * Example usage:
     * <code>
     * $query->filterByCountry('fooValue');   // WHERE country = 'fooValue'
     * $query->filterByCountry('%fooValue%'); // WHERE country LIKE '%fooValue%'
     * </code>
     *
     * @param     string $country The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return AddressQuery The current query, for fluid interface
     */
    public function filterByCountry($country = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($country)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $country)) {
                $country = str_replace('*', '%', $country);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(AddressPeer::COUNTRY, $country, $comparison);
    }

    /**
     * Filter the query by a related Patron object
     *
     * @param   Patron|PropelObjectCollection $patron The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 AddressQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByPatron($patron, $comparison = null)
    {
        if ($patron instanceof Patron) {
            return $this
                ->addUsingAlias(AddressPeer::PATRON_ID, $patron->getPatronId(), $comparison);
        } elseif ($patron instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(AddressPeer::PATRON_ID, $patron->toKeyValue('PrimaryKey', 'PatronId'), $comparison);
        } else {
            throw new PropelException('filterByPatron() only accepts arguments of type Patron or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the Patron relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return AddressQuery The current query, for fluid interface
     */
    public function joinPatron($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('Patron');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'Patron');
        }

        return $this;
    }

    /**
     * Use the Patron relation Patron object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   PatronQuery A secondary query class using the current class as primary query
     */
    public function usePatronQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinPatron($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'Patron', 'PatronQuery');
    }

    /**
     * Exclude object from result
     *
     * @param   Address $address Object to remove from the list of results
     *
     * @return AddressQuery The current query, for fluid interface
     */
    public function prune($address = null)
    {
        if ($address) {
            $this->addUsingAlias(AddressPeer::ADDRESS_ID, $address->getAddressId(), Criteria::NOT_EQUAL);
        }

        return $this;
    }

}
