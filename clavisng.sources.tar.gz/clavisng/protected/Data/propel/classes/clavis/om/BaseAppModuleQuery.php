<?php


/**
 * Base class that represents a query for the 'app_module' table.
 *
 *
 *
 * @method AppModuleQuery orderByModuleId($order = Criteria::ASC) Order by the module_id column
 * @method AppModuleQuery orderBySortOrder($order = Criteria::ASC) Order by the sort_order column
 * @method AppModuleQuery orderByLabel($order = Criteria::ASC) Order by the label column
 * @method AppModuleQuery orderByPage($order = Criteria::ASC) Order by the page column
 * @method AppModuleQuery orderByAlwaysView($order = Criteria::ASC) Order by the always_view column
 *
 * @method AppModuleQuery groupByModuleId() Group by the module_id column
 * @method AppModuleQuery groupBySortOrder() Group by the sort_order column
 * @method AppModuleQuery groupByLabel() Group by the label column
 * @method AppModuleQuery groupByPage() Group by the page column
 * @method AppModuleQuery groupByAlwaysView() Group by the always_view column
 *
 * @method AppModuleQuery leftJoin($relation) Adds a LEFT JOIN clause to the query
 * @method AppModuleQuery rightJoin($relation) Adds a RIGHT JOIN clause to the query
 * @method AppModuleQuery innerJoin($relation) Adds a INNER JOIN clause to the query
 *
 * @method AppModuleQuery leftJoinAppAction($relationAlias = null) Adds a LEFT JOIN clause to the query using the AppAction relation
 * @method AppModuleQuery rightJoinAppAction($relationAlias = null) Adds a RIGHT JOIN clause to the query using the AppAction relation
 * @method AppModuleQuery innerJoinAppAction($relationAlias = null) Adds a INNER JOIN clause to the query using the AppAction relation
 *
 * @method AppModuleQuery leftJoinAppProfileAcl($relationAlias = null) Adds a LEFT JOIN clause to the query using the AppProfileAcl relation
 * @method AppModuleQuery rightJoinAppProfileAcl($relationAlias = null) Adds a RIGHT JOIN clause to the query using the AppProfileAcl relation
 * @method AppModuleQuery innerJoinAppProfileAcl($relationAlias = null) Adds a INNER JOIN clause to the query using the AppProfileAcl relation
 *
 * @method AppModule findOne(PropelPDO $con = null) Return the first AppModule matching the query
 * @method AppModule findOneOrCreate(PropelPDO $con = null) Return the first AppModule matching the query, or a new AppModule object populated from the query conditions when no match is found
 *
 * @method AppModule findOneBySortOrder(int $sort_order) Return the first AppModule filtered by the sort_order column
 * @method AppModule findOneByLabel(string $label) Return the first AppModule filtered by the label column
 * @method AppModule findOneByPage(string $page) Return the first AppModule filtered by the page column
 * @method AppModule findOneByAlwaysView(boolean $always_view) Return the first AppModule filtered by the always_view column
 *
 * @method array findByModuleId(string $module_id) Return AppModule objects filtered by the module_id column
 * @method array findBySortOrder(int $sort_order) Return AppModule objects filtered by the sort_order column
 * @method array findByLabel(string $label) Return AppModule objects filtered by the label column
 * @method array findByPage(string $page) Return AppModule objects filtered by the page column
 * @method array findByAlwaysView(boolean $always_view) Return AppModule objects filtered by the always_view column
 *
 * @package    propel.generator.clavis.om
 */
abstract class BaseAppModuleQuery extends ModelCriteria
{
    /**
     * Initializes internal state of BaseAppModuleQuery object.
     *
     * @param     string $dbName The dabase name
     * @param     string $modelName The phpName of a model, e.g. 'Book'
     * @param     string $modelAlias The alias for the model in this query, e.g. 'b'
     */
    public function __construct($dbName = null, $modelName = null, $modelAlias = null)
    {
        if (null === $dbName) {
            $dbName = 'clavis';
        }
        if (null === $modelName) {
            $modelName = 'AppModule';
        }
        parent::__construct($dbName, $modelName, $modelAlias);
    }

    /**
     * Returns a new AppModuleQuery object.
     *
     * @param     string $modelAlias The alias of a model in the query
     * @param   AppModuleQuery|Criteria $criteria Optional Criteria to build the query from
     *
     * @return AppModuleQuery
     */
    public static function create($modelAlias = null, $criteria = null)
    {
        if ($criteria instanceof AppModuleQuery) {
            return $criteria;
        }
        $query = new AppModuleQuery(null, null, $modelAlias);

        if ($criteria instanceof Criteria) {
            $query->mergeWith($criteria);
        }

        return $query;
    }

    /**
     * Find object by primary key.
     * Propel uses the instance pool to skip the database if the object exists.
     * Go fast if the query is untouched.
     *
     * <code>
     * $obj  = $c->findPk(12, $con);
     * </code>
     *
     * @param mixed $key Primary key to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return   AppModule|AppModule[]|mixed the result, formatted by the current formatter
     */
    public function findPk($key, $con = null)
    {
        if ($key === null) {
            return null;
        }
        if ((null !== ($obj = AppModulePeer::getInstanceFromPool((string) $key))) && !$this->formatter) {
            // the object is already in the instance pool
            return $obj;
        }
        if ($con === null) {
            $con = Propel::getConnection(AppModulePeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        if ($this->formatter || $this->modelAlias || $this->with || $this->select
         || $this->selectColumns || $this->asColumns || $this->selectModifiers
         || $this->map || $this->having || $this->joins) {
            return $this->findPkComplex($key, $con);
        } else {
            return $this->findPkSimple($key, $con);
        }
    }

    /**
     * Alias of findPk to use instance pooling
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 AppModule A model object, or null if the key is not found
     * @throws PropelException
     */
     public function findOneByModuleId($key, $con = null)
     {
        return $this->findPk($key, $con);
     }

    /**
     * Find object by primary key using raw SQL to go fast.
     * Bypass doSelect() and the object formatter by using generated code.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 AppModule A model object, or null if the key is not found
     * @throws PropelException
     */
    protected function findPkSimple($key, $con)
    {
        $sql = 'SELECT `module_id`, `sort_order`, `label`, `page`, `always_view` FROM `app_module` WHERE `module_id` = :p0';
        try {
            $stmt = $con->prepare($sql);
            $stmt->bindValue(':p0', $key, PDO::PARAM_STR);
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute SELECT statement [%s]', $sql), $e);
        }
        $obj = null;
        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $obj = new AppModule();
            $obj->hydrate($row);
            AppModulePeer::addInstanceToPool($obj, (string) $key);
        }
        $stmt->closeCursor();

        return $obj;
    }

    /**
     * Find object by primary key.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return AppModule|AppModule[]|mixed the result, formatted by the current formatter
     */
    protected function findPkComplex($key, $con)
    {
        // As the query uses a PK condition, no limit(1) is necessary.
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKey($key)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->formatOne($stmt);
    }

    /**
     * Find objects by primary key
     * <code>
     * $objs = $c->findPks(array(12, 56, 832), $con);
     * </code>
     * @param     array $keys Primary keys to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return PropelObjectCollection|AppModule[]|mixed the list of results, formatted by the current formatter
     */
    public function findPks($keys, $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection($this->getDbName(), Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKeys($keys)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->format($stmt);
    }

    /**
     * Filter the query by primary key
     *
     * @param     mixed $key Primary key to use for the query
     *
     * @return AppModuleQuery The current query, for fluid interface
     */
    public function filterByPrimaryKey($key)
    {

        return $this->addUsingAlias(AppModulePeer::MODULE_ID, $key, Criteria::EQUAL);
    }

    /**
     * Filter the query by a list of primary keys
     *
     * @param     array $keys The list of primary key to use for the query
     *
     * @return AppModuleQuery The current query, for fluid interface
     */
    public function filterByPrimaryKeys($keys)
    {

        return $this->addUsingAlias(AppModulePeer::MODULE_ID, $keys, Criteria::IN);
    }

    /**
     * Filter the query on the module_id column
     *
     * Example usage:
     * <code>
     * $query->filterByModuleId('fooValue');   // WHERE module_id = 'fooValue'
     * $query->filterByModuleId('%fooValue%'); // WHERE module_id LIKE '%fooValue%'
     * </code>
     *
     * @param     string $moduleId The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return AppModuleQuery The current query, for fluid interface
     */
    public function filterByModuleId($moduleId = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($moduleId)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $moduleId)) {
                $moduleId = str_replace('*', '%', $moduleId);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(AppModulePeer::MODULE_ID, $moduleId, $comparison);
    }

    /**
     * Filter the query on the sort_order column
     *
     * Example usage:
     * <code>
     * $query->filterBySortOrder(1234); // WHERE sort_order = 1234
     * $query->filterBySortOrder(array(12, 34)); // WHERE sort_order IN (12, 34)
     * $query->filterBySortOrder(array('min' => 12)); // WHERE sort_order >= 12
     * $query->filterBySortOrder(array('max' => 12)); // WHERE sort_order <= 12
     * </code>
     *
     * @param     mixed $sortOrder The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return AppModuleQuery The current query, for fluid interface
     */
    public function filterBySortOrder($sortOrder = null, $comparison = null)
    {
        if (is_array($sortOrder)) {
            $useMinMax = false;
            if (isset($sortOrder['min'])) {
                $this->addUsingAlias(AppModulePeer::SORT_ORDER, $sortOrder['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($sortOrder['max'])) {
                $this->addUsingAlias(AppModulePeer::SORT_ORDER, $sortOrder['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(AppModulePeer::SORT_ORDER, $sortOrder, $comparison);
    }

    /**
     * Filter the query on the label column
     *
     * Example usage:
     * <code>
     * $query->filterByLabel('fooValue');   // WHERE label = 'fooValue'
     * $query->filterByLabel('%fooValue%'); // WHERE label LIKE '%fooValue%'
     * </code>
     *
     * @param     string $label The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return AppModuleQuery The current query, for fluid interface
     */
    public function filterByLabel($label = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($label)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $label)) {
                $label = str_replace('*', '%', $label);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(AppModulePeer::LABEL, $label, $comparison);
    }

    /**
     * Filter the query on the page column
     *
     * Example usage:
     * <code>
     * $query->filterByPage('fooValue');   // WHERE page = 'fooValue'
     * $query->filterByPage('%fooValue%'); // WHERE page LIKE '%fooValue%'
     * </code>
     *
     * @param     string $page The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return AppModuleQuery The current query, for fluid interface
     */
    public function filterByPage($page = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($page)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $page)) {
                $page = str_replace('*', '%', $page);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(AppModulePeer::PAGE, $page, $comparison);
    }

    /**
     * Filter the query on the always_view column
     *
     * Example usage:
     * <code>
     * $query->filterByAlwaysView(true); // WHERE always_view = true
     * $query->filterByAlwaysView('yes'); // WHERE always_view = true
     * </code>
     *
     * @param     boolean|string $alwaysView The value to use as filter.
     *              Non-boolean arguments are converted using the following rules:
     *                * 1, '1', 'true',  'on',  and 'yes' are converted to boolean true
     *                * 0, '0', 'false', 'off', and 'no'  are converted to boolean false
     *              Check on string values is case insensitive (so 'FaLsE' is seen as 'false').
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return AppModuleQuery The current query, for fluid interface
     */
    public function filterByAlwaysView($alwaysView = null, $comparison = null)
    {
        if (is_string($alwaysView)) {
            $alwaysView = in_array(strtolower($alwaysView), array('false', 'off', '-', 'no', 'n', '0', '')) ? false : true;
        }

        return $this->addUsingAlias(AppModulePeer::ALWAYS_VIEW, $alwaysView, $comparison);
    }

    /**
     * Filter the query by a related AppAction object
     *
     * @param   AppAction|PropelObjectCollection $appAction  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 AppModuleQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByAppAction($appAction, $comparison = null)
    {
        if ($appAction instanceof AppAction) {
            return $this
                ->addUsingAlias(AppModulePeer::MODULE_ID, $appAction->getModuleId(), $comparison);
        } elseif ($appAction instanceof PropelObjectCollection) {
            return $this
                ->useAppActionQuery()
                ->filterByPrimaryKeys($appAction->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByAppAction() only accepts arguments of type AppAction or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the AppAction relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return AppModuleQuery The current query, for fluid interface
     */
    public function joinAppAction($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('AppAction');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'AppAction');
        }

        return $this;
    }

    /**
     * Use the AppAction relation AppAction object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   AppActionQuery A secondary query class using the current class as primary query
     */
    public function useAppActionQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinAppAction($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'AppAction', 'AppActionQuery');
    }

    /**
     * Filter the query by a related AppProfileAcl object
     *
     * @param   AppProfileAcl|PropelObjectCollection $appProfileAcl  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 AppModuleQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByAppProfileAcl($appProfileAcl, $comparison = null)
    {
        if ($appProfileAcl instanceof AppProfileAcl) {
            return $this
                ->addUsingAlias(AppModulePeer::MODULE_ID, $appProfileAcl->getModuleId(), $comparison);
        } elseif ($appProfileAcl instanceof PropelObjectCollection) {
            return $this
                ->useAppProfileAclQuery()
                ->filterByPrimaryKeys($appProfileAcl->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByAppProfileAcl() only accepts arguments of type AppProfileAcl or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the AppProfileAcl relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return AppModuleQuery The current query, for fluid interface
     */
    public function joinAppProfileAcl($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('AppProfileAcl');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'AppProfileAcl');
        }

        return $this;
    }

    /**
     * Use the AppProfileAcl relation AppProfileAcl object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   AppProfileAclQuery A secondary query class using the current class as primary query
     */
    public function useAppProfileAclQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinAppProfileAcl($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'AppProfileAcl', 'AppProfileAclQuery');
    }

    /**
     * Exclude object from result
     *
     * @param   AppModule $appModule Object to remove from the list of results
     *
     * @return AppModuleQuery The current query, for fluid interface
     */
    public function prune($appModule = null)
    {
        if ($appModule) {
            $this->addUsingAlias(AppModulePeer::MODULE_ID, $appModule->getModuleId(), Criteria::NOT_EQUAL);
        }

        return $this;
    }

    // sortable behavior

    /**
     * Filter the query based on a rank in the list
     *
     * @param     integer   $rank rank
     *
     * @return    AppModuleQuery The current query, for fluid interface
     */
    public function filterByRank($rank)
    {


        return $this
            ->addUsingAlias(AppModulePeer::RANK_COL, $rank, Criteria::EQUAL);
    }

    /**
     * Order the query based on the rank in the list.
     * Using the default $order, returns the item with the lowest rank first
     *
     * @param     string $order either Criteria::ASC (default) or Criteria::DESC
     *
     * @return    AppModuleQuery The current query, for fluid interface
     */
    public function orderByRank($order = Criteria::ASC)
    {
        $order = strtoupper($order);
        switch ($order) {
            case Criteria::ASC:
                return $this->addAscendingOrderByColumn($this->getAliasedColName(AppModulePeer::RANK_COL));
                break;
            case Criteria::DESC:
                return $this->addDescendingOrderByColumn($this->getAliasedColName(AppModulePeer::RANK_COL));
                break;
            default:
                throw new PropelException('AppModuleQuery::orderBy() only accepts "asc" or "desc" as argument');
        }
    }

    /**
     * Get an item from the list based on its rank
     *
     * @param     integer   $rank rank
     * @param     PropelPDO $con optional connection
     *
     * @return    AppModule
     */
    public function findOneByRank($rank, PropelPDO $con = null)
    {

        return $this
            ->filterByRank($rank)
            ->findOne($con);
    }

    /**
     * Returns the list of objects
     *
     * @param      PropelPDO $con	Connection to use.
     *
     * @return     mixed the list of results, formatted by the current formatter
     */
    public function findList($con = null)
    {


        return $this
            ->orderByRank()
            ->find($con);
    }

    /**
     * Get the highest rank
     *
     * @param     PropelPDO optional connection
     *
     * @return    integer highest position
     */
    public function getMaxRank(PropelPDO $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection(AppModulePeer::DATABASE_NAME);
        }
        // shift the objects with a position lower than the one of object
        $this->addSelectColumn('MAX(' . AppModulePeer::RANK_COL . ')');
        $stmt = $this->doSelect($con);

        return $stmt->fetchColumn();
    }

    /**
     * Get the highest rank by a scope with a array format.
     *
     * @param     PropelPDO optional connection
     *
     * @return    integer highest position
     */
    public function getMaxRankArray(PropelPDO $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection(AppModulePeer::DATABASE_NAME);
        }
        // shift the objects with a position lower than the one of object
        $this->addSelectColumn('MAX(' . AppModulePeer::RANK_COL . ')');
        $stmt = $this->doSelect($con);

        return $stmt->fetchColumn();
    }

    /**
     * Reorder a set of sortable objects based on a list of id/position
     * Beware that there is no check made on the positions passed
     * So incoherent positions will result in an incoherent list
     *
     * @param     array     $order id => rank pairs
     * @param     PropelPDO $con   optional connection
     *
     * @return    boolean true if the reordering took place, false if a database problem prevented it
     */
    public function reorder(array $order, PropelPDO $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection(AppModulePeer::DATABASE_NAME);
        }

        $con->beginTransaction();
        try {
            $ids = array_keys($order);
            $objects = $this->findPks($ids, $con);
            foreach ($objects as $object) {
                $pk = $object->getPrimaryKey();
                if ($object->getSortOrder() != $order[$pk]) {
                    $object->setSortOrder($order[$pk]);
                    $object->save($con);
                }
            }
            $con->commit();

            return true;
        } catch (Exception $e) {
            $con->rollback();
            throw $e;
        }
    }

}
