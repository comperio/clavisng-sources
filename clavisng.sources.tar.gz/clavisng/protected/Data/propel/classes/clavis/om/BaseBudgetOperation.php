<?php


/**
 * Base class that represents a row from the 'budget_operation' table.
 *
 *
 *
 * @package    propel.generator.clavis.om
 */
abstract class BaseBudgetOperation extends BaseObject implements Persistent
{
    /**
     * Peer class name
     */
    const PEER = 'BudgetOperationPeer';

    /**
     * The Peer class.
     * Instance provides a convenient way of calling static methods on a class
     * that calling code may not be able to identify.
     * @var        BudgetOperationPeer
     */
    protected static $peer;

    /**
     * The flag var to prevent infinite loop in deep copy
     * @var       boolean
     */
    protected $startCopy = false;

    /**
     * The value for the budget_id field.
     * @var        int
     */
    protected $budget_id;

    /**
     * The value for the amount field.
     * @var        string
     */
    protected $amount;

    /**
     * The value for the operation_note field.
     * @var        string
     */
    protected $operation_note;

    /**
     * The value for the operation_date field.
     * @var        string
     */
    protected $operation_date;

    /**
     * The value for the date_created field.
     * @var        string
     */
    protected $date_created;

    /**
     * The value for the date_updated field.
     * @var        string
     */
    protected $date_updated;

    /**
     * The value for the created_by field.
     * @var        int
     */
    protected $created_by;

    /**
     * The value for the modified_by field.
     * @var        int
     */
    protected $modified_by;

    /**
     * @var        Librarian
     */
    protected $aLibrarianRelatedByCreatedBy;

    /**
     * @var        Librarian
     */
    protected $aLibrarianRelatedByModifiedBy;

    /**
     * @var        Budget
     */
    protected $aBudget;

    /**
     * Flag to prevent endless save loop, if this object is referenced
     * by another object which falls in this transaction.
     * @var        boolean
     */
    protected $alreadyInSave = false;

    /**
     * Flag to prevent endless validation loop, if this object is referenced
     * by another object which falls in this transaction.
     * @var        boolean
     */
    protected $alreadyInValidation = false;

    /**
     * Flag to prevent endless clearAllReferences($deep=true) loop, if this object is referenced
     * @var        boolean
     */
    protected $alreadyInClearAllReferencesDeep = false;

    /**
     * Get the [budget_id] column value.
     *
     * @return int
     */
    public function getBudgetId()
    {

        return $this->budget_id;
    }

    /**
     * Get the [amount] column value.
     *
     * @return string
     */
    public function getAmount()
    {

        return $this->amount;
    }

    /**
     * Get the [operation_note] column value.
     *
     * @return string
     */
    public function getOperationNote()
    {

        return $this->operation_note;
    }

    /**
     * Get the [optionally formatted] temporal [operation_date] column value.
     *
     *
     * @param string $format The date/time format string (either date()-style or strftime()-style).
     *				 If format is null, then the raw DateTime object will be returned.
     * @return mixed Formatted date/time value as string or DateTime object (if format is null), null if column is null, and 0 if column value is 0000-00-00
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getOperationDate($format = '%F %T')
    {
        if ($this->operation_date === null) {
            return null;
        }

        if ($this->operation_date === '0000-00-00') {
            // while technically this is not a default value of null,
            // this seems to be closest in meaning.
            return null;
        }

        try {
            $dt = new DateTime($this->operation_date);
        } catch (Exception $x) {
            throw new PropelException("Internally stored date/time/timestamp value could not be converted to DateTime: " . var_export($this->operation_date, true), $x);
        }

        if ($format === null) {
            // Because propel.useDateTimeClass is true, we return a DateTime object.
            return $dt;
        }

        if (strpos($format, '%') !== false) {
            return strftime($format, $dt->format('U'));
        }

        return $dt->format($format);

    }

    /**
     * Get the [optionally formatted] temporal [date_created] column value.
     *
     *
     * @param string $format The date/time format string (either date()-style or strftime()-style).
     *				 If format is null, then the raw DateTime object will be returned.
     * @return mixed Formatted date/time value as string or DateTime object (if format is null), null if column is null, and 0 if column value is 0000-00-00 00:00:00
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getDateCreated($format = 'Y-m-d H:i:s')
    {
        if ($this->date_created === null) {
            return null;
        }

        if ($this->date_created === '0000-00-00 00:00:00') {
            // while technically this is not a default value of null,
            // this seems to be closest in meaning.
            return null;
        }

        try {
            $dt = new DateTime($this->date_created);
        } catch (Exception $x) {
            throw new PropelException("Internally stored date/time/timestamp value could not be converted to DateTime: " . var_export($this->date_created, true), $x);
        }

        if ($format === null) {
            // Because propel.useDateTimeClass is true, we return a DateTime object.
            return $dt;
        }

        if (strpos($format, '%') !== false) {
            return strftime($format, $dt->format('U'));
        }

        return $dt->format($format);

    }

    /**
     * Get the [optionally formatted] temporal [date_updated] column value.
     *
     *
     * @param string $format The date/time format string (either date()-style or strftime()-style).
     *				 If format is null, then the raw DateTime object will be returned.
     * @return mixed Formatted date/time value as string or DateTime object (if format is null), null if column is null, and 0 if column value is 0000-00-00 00:00:00
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getDateUpdated($format = 'Y-m-d H:i:s')
    {
        if ($this->date_updated === null) {
            return null;
        }

        if ($this->date_updated === '0000-00-00 00:00:00') {
            // while technically this is not a default value of null,
            // this seems to be closest in meaning.
            return null;
        }

        try {
            $dt = new DateTime($this->date_updated);
        } catch (Exception $x) {
            throw new PropelException("Internally stored date/time/timestamp value could not be converted to DateTime: " . var_export($this->date_updated, true), $x);
        }

        if ($format === null) {
            // Because propel.useDateTimeClass is true, we return a DateTime object.
            return $dt;
        }

        if (strpos($format, '%') !== false) {
            return strftime($format, $dt->format('U'));
        }

        return $dt->format($format);

    }

    /**
     * Get the [created_by] column value.
     *
     * @return int
     */
    public function getCreatedBy()
    {

        return $this->created_by;
    }

    /**
     * Get the [modified_by] column value.
     *
     * @return int
     */
    public function getModifiedBy()
    {

        return $this->modified_by;
    }

    /**
     * Set the value of [budget_id] column.
     *
     * @param  int $v new value
     * @return BudgetOperation The current object (for fluent API support)
     */
    public function setBudgetId($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->budget_id !== $v) {
            $this->budget_id = $v;
            $this->modifiedColumns[] = BudgetOperationPeer::BUDGET_ID;
        }

        if ($this->aBudget !== null && $this->aBudget->getBudgetId() !== $v) {
            $this->aBudget = null;
        }


        return $this;
    } // setBudgetId()

    /**
     * Set the value of [amount] column.
     *
     * @param  string $v new value
     * @return BudgetOperation The current object (for fluent API support)
     */
    public function setAmount($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->amount !== $v) {
            $this->amount = $v;
            $this->modifiedColumns[] = BudgetOperationPeer::AMOUNT;
        }


        return $this;
    } // setAmount()

    /**
     * Set the value of [operation_note] column.
     *
     * @param  string $v new value
     * @return BudgetOperation The current object (for fluent API support)
     */
    public function setOperationNote($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->operation_note !== $v) {
            $this->operation_note = $v;
            $this->modifiedColumns[] = BudgetOperationPeer::OPERATION_NOTE;
        }


        return $this;
    } // setOperationNote()

    /**
     * Sets the value of [operation_date] column to a normalized version of the date/time value specified.
     *
     * @param mixed $v string, integer (timestamp), or DateTime value.
     *               Empty strings are treated as null.
     * @return BudgetOperation The current object (for fluent API support)
     */
    public function setOperationDate($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->operation_date !== null || $dt !== null) {
            $currentDateAsString = ($this->operation_date !== null && $tmpDt = new DateTime($this->operation_date)) ? $tmpDt->format('Y-m-d') : null;
            $newDateAsString = $dt ? $dt->format('Y-m-d') : null;
            if ($currentDateAsString !== $newDateAsString) {
                $this->operation_date = $newDateAsString;
                $this->modifiedColumns[] = BudgetOperationPeer::OPERATION_DATE;
            }
        } // if either are not null


        return $this;
    } // setOperationDate()

    /**
     * Sets the value of [date_created] column to a normalized version of the date/time value specified.
     *
     * @param mixed $v string, integer (timestamp), or DateTime value.
     *               Empty strings are treated as null.
     * @return BudgetOperation The current object (for fluent API support)
     */
    public function setDateCreated($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->date_created !== null || $dt !== null) {
            $currentDateAsString = ($this->date_created !== null && $tmpDt = new DateTime($this->date_created)) ? $tmpDt->format('Y-m-d H:i:s') : null;
            $newDateAsString = $dt ? $dt->format('Y-m-d H:i:s') : null;
            if ($currentDateAsString !== $newDateAsString) {
                $this->date_created = $newDateAsString;
                $this->modifiedColumns[] = BudgetOperationPeer::DATE_CREATED;
            }
        } // if either are not null


        return $this;
    } // setDateCreated()

    /**
     * Sets the value of [date_updated] column to a normalized version of the date/time value specified.
     *
     * @param mixed $v string, integer (timestamp), or DateTime value.
     *               Empty strings are treated as null.
     * @return BudgetOperation The current object (for fluent API support)
     */
    public function setDateUpdated($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->date_updated !== null || $dt !== null) {
            $currentDateAsString = ($this->date_updated !== null && $tmpDt = new DateTime($this->date_updated)) ? $tmpDt->format('Y-m-d H:i:s') : null;
            $newDateAsString = $dt ? $dt->format('Y-m-d H:i:s') : null;
            if ($currentDateAsString !== $newDateAsString) {
                $this->date_updated = $newDateAsString;
                $this->modifiedColumns[] = BudgetOperationPeer::DATE_UPDATED;
            }
        } // if either are not null


        return $this;
    } // setDateUpdated()

    /**
     * Set the value of [created_by] column.
     *
     * @param  int $v new value
     * @return BudgetOperation The current object (for fluent API support)
     */
    public function setCreatedBy($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->created_by !== $v) {
            $this->created_by = $v;
            $this->modifiedColumns[] = BudgetOperationPeer::CREATED_BY;
        }

        if ($this->aLibrarianRelatedByCreatedBy !== null && $this->aLibrarianRelatedByCreatedBy->getLibrarianId() !== $v) {
            $this->aLibrarianRelatedByCreatedBy = null;
        }


        return $this;
    } // setCreatedBy()

    /**
     * Set the value of [modified_by] column.
     *
     * @param  int $v new value
     * @return BudgetOperation The current object (for fluent API support)
     */
    public function setModifiedBy($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->modified_by !== $v) {
            $this->modified_by = $v;
            $this->modifiedColumns[] = BudgetOperationPeer::MODIFIED_BY;
        }

        if ($this->aLibrarianRelatedByModifiedBy !== null && $this->aLibrarianRelatedByModifiedBy->getLibrarianId() !== $v) {
            $this->aLibrarianRelatedByModifiedBy = null;
        }


        return $this;
    } // setModifiedBy()

    /**
     * Indicates whether the columns in this object are only set to default values.
     *
     * This method can be used in conjunction with isModified() to indicate whether an object is both
     * modified _and_ has some values set which are non-default.
     *
     * @return boolean Whether the columns in this object are only been set with default values.
     */
    public function hasOnlyDefaultValues()
    {
        // otherwise, everything was equal, so return true
        return true;
    } // hasOnlyDefaultValues()

    /**
     * Hydrates (populates) the object variables with values from the database resultset.
     *
     * An offset (0-based "start column") is specified so that objects can be hydrated
     * with a subset of the columns in the resultset rows.  This is needed, for example,
     * for results of JOIN queries where the resultset row includes columns from two or
     * more tables.
     *
     * @param array $row The row returned by PDOStatement->fetch(PDO::FETCH_NUM)
     * @param int $startcol 0-based offset column which indicates which resultset column to start with.
     * @param boolean $rehydrate Whether this object is being re-hydrated from the database.
     * @return int             next starting column
     * @throws PropelException - Any caught Exception will be rewrapped as a PropelException.
     */
    public function hydrate($row, $startcol = 0, $rehydrate = false)
    {
        try {

            $this->budget_id = ($row[$startcol + 0] !== null) ? (int) $row[$startcol + 0] : null;
            $this->amount = ($row[$startcol + 1] !== null) ? (string) $row[$startcol + 1] : null;
            $this->operation_note = ($row[$startcol + 2] !== null) ? (string) $row[$startcol + 2] : null;
            $this->operation_date = ($row[$startcol + 3] !== null) ? (string) $row[$startcol + 3] : null;
            $this->date_created = ($row[$startcol + 4] !== null) ? (string) $row[$startcol + 4] : null;
            $this->date_updated = ($row[$startcol + 5] !== null) ? (string) $row[$startcol + 5] : null;
            $this->created_by = ($row[$startcol + 6] !== null) ? (int) $row[$startcol + 6] : null;
            $this->modified_by = ($row[$startcol + 7] !== null) ? (int) $row[$startcol + 7] : null;
            $this->resetModified();

            $this->setNew(false);

            if ($rehydrate) {
                $this->ensureConsistency();
            }
            $this->postHydrate($row, $startcol, $rehydrate);

            return $startcol + 8; // 8 = BudgetOperationPeer::NUM_HYDRATE_COLUMNS.

        } catch (Exception $e) {
            throw new PropelException("Error populating BudgetOperation object", $e);
        }
    }

    /**
     * Checks and repairs the internal consistency of the object.
     *
     * This method is executed after an already-instantiated object is re-hydrated
     * from the database.  It exists to check any foreign keys to make sure that
     * the objects related to the current object are correct based on foreign key.
     *
     * You can override this method in the stub class, but you should always invoke
     * the base method from the overridden method (i.e. parent::ensureConsistency()),
     * in case your model changes.
     *
     * @throws PropelException
     */
    public function ensureConsistency()
    {

        if ($this->aBudget !== null && $this->budget_id !== $this->aBudget->getBudgetId()) {
            $this->aBudget = null;
        }
        if ($this->aLibrarianRelatedByCreatedBy !== null && $this->created_by !== $this->aLibrarianRelatedByCreatedBy->getLibrarianId()) {
            $this->aLibrarianRelatedByCreatedBy = null;
        }
        if ($this->aLibrarianRelatedByModifiedBy !== null && $this->modified_by !== $this->aLibrarianRelatedByModifiedBy->getLibrarianId()) {
            $this->aLibrarianRelatedByModifiedBy = null;
        }
    } // ensureConsistency

    /**
     * Reloads this object from datastore based on primary key and (optionally) resets all associated objects.
     *
     * This will only work if the object has been saved and has a valid primary key set.
     *
     * @param boolean $deep (optional) Whether to also de-associated any related objects.
     * @param PropelPDO $con (optional) The PropelPDO connection to use.
     * @return void
     * @throws PropelException - if this object is deleted, unsaved or doesn't have pk match in db
     */
    public function reload($deep = false, PropelPDO $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("Cannot reload a deleted object.");
        }

        if ($this->isNew()) {
            throw new PropelException("Cannot reload an unsaved object.");
        }

        if ($con === null) {
            $con = Propel::getConnection(BudgetOperationPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        // We don't need to alter the object instance pool; we're just modifying this instance
        // already in the pool.

        $stmt = BudgetOperationPeer::doSelectStmt($this->buildPkeyCriteria(), $con);
        $row = $stmt->fetch(PDO::FETCH_NUM);
        $stmt->closeCursor();
        if (!$row) {
            throw new PropelException('Cannot find matching row in the database to reload object values.');
        }
        $this->hydrate($row, 0, true); // rehydrate

        if ($deep) {  // also de-associate any related objects?

            $this->aLibrarianRelatedByCreatedBy = null;
            $this->aLibrarianRelatedByModifiedBy = null;
            $this->aBudget = null;
        } // if (deep)
    }

    /**
     * Removes this object from datastore and sets delete attribute.
     *
     * @param PropelPDO $con
     * @return void
     * @throws PropelException
     * @throws Exception
     * @see        BaseObject::setDeleted()
     * @see        BaseObject::isDeleted()
     */
    public function delete(PropelPDO $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("This object has already been deleted.");
        }

        if ($con === null) {
            $con = Propel::getConnection(BudgetOperationPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        $con->beginTransaction();
        try {
            $deleteQuery = BudgetOperationQuery::create()
                ->filterByPrimaryKey($this->getPrimaryKey());
            $ret = $this->preDelete($con);
            if ($ret) {
                $deleteQuery->delete($con);
                $this->postDelete($con);
                $con->commit();
                $this->setDeleted(true);
            } else {
                $con->commit();
            }
        } catch (Exception $e) {
            $con->rollBack();
            throw $e;
        }
    }

    /**
     * Persists this object to the database.
     *
     * If the object is new, it inserts it; otherwise an update is performed.
     * All modified related objects will also be persisted in the doSave()
     * method.  This method wraps all precipitate database operations in a
     * single transaction.
     *
     * @param PropelPDO $con
     * @return int             The number of rows affected by this insert/update and any referring fk objects' save() operations.
     * @throws PropelException
     * @throws Exception
     * @see        doSave()
     */
    public function save(PropelPDO $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("You cannot save an object that has been deleted.");
        }

        if ($con === null) {
            $con = Propel::getConnection(BudgetOperationPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        $con->beginTransaction();
        $isInsert = $this->isNew();
        try {
            $ret = $this->preSave($con);
            if ($isInsert) {
                $ret = $ret && $this->preInsert($con);
                // timestampable behavior
                if (!$this->isColumnModified(BudgetOperationPeer::DATE_CREATED)) {
                    $this->setDateCreated(time());
                }
                if (!$this->isColumnModified(BudgetOperationPeer::DATE_UPDATED)) {
                    $this->setDateUpdated(time());
                }
                // librariantrace behavior
                $librarianId = (class_exists('Prado') && (Prado::getApplication() instanceof TApplication) && ($u = Prado::getApplication()->getUser()) instanceof ClavisLibrarian && $u->getId() > 0) ? $u->getId() : 1 ;
                if (!$this->isColumnModified(BudgetOperationPeer::CREATED_BY)) {
                    $this->setCreatedBy($librarianId);
                }
                if (!$this->isColumnModified(BudgetOperationPeer::MODIFIED_BY)) {
                    $this->setModifiedBy($librarianId);
                }
            } else {
                $ret = $ret && $this->preUpdate($con);
                // timestampable behavior
                if ($this->isModified() && !$this->isColumnModified(BudgetOperationPeer::DATE_UPDATED)) {
                    $this->setDateUpdated(time());
                }
                // librariantrace behavior
                if ($this->isModified() && !$this->isColumnModified(BudgetOperationPeer::MODIFIED_BY)) {
                    $this->setModifiedBy((class_exists('Prado') && (Prado::getApplication() instanceof TApplication) && ($u = Prado::getApplication()->getUser()) instanceof ClavisLibrarian && $u->getId() > 0) ? $u->getId() : 1 );
                }
            }
            if ($ret) {
                $affectedRows = $this->doSave($con);
                if ($isInsert) {
                    $this->postInsert($con);
                } else {
                    $this->postUpdate($con);
                }
                $this->postSave($con);
                BudgetOperationPeer::addInstanceToPool($this);
            } else {
                $affectedRows = 0;
            }
            $con->commit();

            return $affectedRows;
        } catch (Exception $e) {
            $con->rollBack();
            throw $e;
        }
    }

    /**
     * Performs the work of inserting or updating the row in the database.
     *
     * If the object is new, it inserts it; otherwise an update is performed.
     * All related objects are also updated in this method.
     *
     * @param PropelPDO $con
     * @return int             The number of rows affected by this insert/update and any referring fk objects' save() operations.
     * @throws PropelException
     * @see        save()
     */
    protected function doSave(PropelPDO $con)
    {
        $affectedRows = 0; // initialize var to track total num of affected rows
        if (!$this->alreadyInSave) {
            $this->alreadyInSave = true;

            // We call the save method on the following object(s) if they
            // were passed to this object by their corresponding set
            // method.  This object relates to these object(s) by a
            // foreign key reference.

            if ($this->aLibrarianRelatedByCreatedBy !== null) {
                if ($this->aLibrarianRelatedByCreatedBy->isModified() || $this->aLibrarianRelatedByCreatedBy->isNew()) {
                    $affectedRows += $this->aLibrarianRelatedByCreatedBy->save($con);
                }
                $this->setLibrarianRelatedByCreatedBy($this->aLibrarianRelatedByCreatedBy);
            }

            if ($this->aLibrarianRelatedByModifiedBy !== null) {
                if ($this->aLibrarianRelatedByModifiedBy->isModified() || $this->aLibrarianRelatedByModifiedBy->isNew()) {
                    $affectedRows += $this->aLibrarianRelatedByModifiedBy->save($con);
                }
                $this->setLibrarianRelatedByModifiedBy($this->aLibrarianRelatedByModifiedBy);
            }

            if ($this->aBudget !== null) {
                if ($this->aBudget->isModified() || $this->aBudget->isNew()) {
                    $affectedRows += $this->aBudget->save($con);
                }
                $this->setBudget($this->aBudget);
            }

            if ($this->isNew() || $this->isModified()) {
                // persist changes
                if ($this->isNew()) {
                    $this->doInsert($con);
                } else {
                    $this->doUpdate($con);
                }
                $affectedRows += 1;
                $this->resetModified();
            }

            $this->alreadyInSave = false;

        }

        return $affectedRows;
    } // doSave()

    /**
     * Insert the row in the database.
     *
     * @param PropelPDO $con
     *
     * @throws PropelException
     * @see        doSave()
     */
    protected function doInsert(PropelPDO $con)
    {
        $modifiedColumns = array();
        $index = 0;


         // check the columns in natural order for more readable SQL queries
        if ($this->isColumnModified(BudgetOperationPeer::BUDGET_ID)) {
            $modifiedColumns[':p' . $index++]  = '`budget_id`';
        }
        if ($this->isColumnModified(BudgetOperationPeer::AMOUNT)) {
            $modifiedColumns[':p' . $index++]  = '`amount`';
        }
        if ($this->isColumnModified(BudgetOperationPeer::OPERATION_NOTE)) {
            $modifiedColumns[':p' . $index++]  = '`operation_note`';
        }
        if ($this->isColumnModified(BudgetOperationPeer::OPERATION_DATE)) {
            $modifiedColumns[':p' . $index++]  = '`operation_date`';
        }
        if ($this->isColumnModified(BudgetOperationPeer::DATE_CREATED)) {
            $modifiedColumns[':p' . $index++]  = '`date_created`';
        }
        if ($this->isColumnModified(BudgetOperationPeer::DATE_UPDATED)) {
            $modifiedColumns[':p' . $index++]  = '`date_updated`';
        }
        if ($this->isColumnModified(BudgetOperationPeer::CREATED_BY)) {
            $modifiedColumns[':p' . $index++]  = '`created_by`';
        }
        if ($this->isColumnModified(BudgetOperationPeer::MODIFIED_BY)) {
            $modifiedColumns[':p' . $index++]  = '`modified_by`';
        }

        $sql = sprintf(
            'INSERT INTO `budget_operation` (%s) VALUES (%s)',
            implode(', ', $modifiedColumns),
            implode(', ', array_keys($modifiedColumns))
        );

        try {
            $stmt = $con->prepare($sql);
            foreach ($modifiedColumns as $identifier => $columnName) {
                switch ($columnName) {
                    case '`budget_id`':
                        $stmt->bindValue($identifier, $this->budget_id, PDO::PARAM_INT);
                        break;
                    case '`amount`':
                        $stmt->bindValue($identifier, $this->amount, PDO::PARAM_STR);
                        break;
                    case '`operation_note`':
                        $stmt->bindValue($identifier, $this->operation_note, PDO::PARAM_STR);
                        break;
                    case '`operation_date`':
                        $stmt->bindValue($identifier, $this->operation_date, PDO::PARAM_STR);
                        break;
                    case '`date_created`':
                        $stmt->bindValue($identifier, $this->date_created, PDO::PARAM_STR);
                        break;
                    case '`date_updated`':
                        $stmt->bindValue($identifier, $this->date_updated, PDO::PARAM_STR);
                        break;
                    case '`created_by`':
                        $stmt->bindValue($identifier, $this->created_by, PDO::PARAM_INT);
                        break;
                    case '`modified_by`':
                        $stmt->bindValue($identifier, $this->modified_by, PDO::PARAM_INT);
                        break;
                }
            }
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute INSERT statement [%s]', $sql), $e);
        }

        $this->setNew(false);
    }

    /**
     * Update the row in the database.
     *
     * @param PropelPDO $con
     *
     * @see        doSave()
     */
    protected function doUpdate(PropelPDO $con)
    {
        $selectCriteria = $this->buildPkeyCriteria();
        $valuesCriteria = $this->buildCriteria();
        BasePeer::doUpdate($selectCriteria, $valuesCriteria, $con);
    }

    /**
     * Array of ValidationFailed objects.
     * @var        array ValidationFailed[]
     */
    protected $validationFailures = array();

    /**
     * Gets any ValidationFailed objects that resulted from last call to validate().
     *
     *
     * @return array ValidationFailed[]
     * @see        validate()
     */
    public function getValidationFailures()
    {
        return $this->validationFailures;
    }

    /**
     * Validates the objects modified field values and all objects related to this table.
     *
     * If $columns is either a column name or an array of column names
     * only those columns are validated.
     *
     * @param mixed $columns Column name or an array of column names.
     * @return boolean Whether all columns pass validation.
     * @see        doValidate()
     * @see        getValidationFailures()
     */
    public function validate($columns = null)
    {
        $res = $this->doValidate($columns);
        if ($res === true) {
            $this->validationFailures = array();

            return true;
        }

        $this->validationFailures = $res;

        return false;
    }

    /**
     * This function performs the validation work for complex object models.
     *
     * In addition to checking the current object, all related objects will
     * also be validated.  If all pass then <code>true</code> is returned; otherwise
     * an aggregated array of ValidationFailed objects will be returned.
     *
     * @param array $columns Array of column names to validate.
     * @return mixed <code>true</code> if all validations pass; array of <code>ValidationFailed</code> objects otherwise.
     */
    protected function doValidate($columns = null)
    {
        if (!$this->alreadyInValidation) {
            $this->alreadyInValidation = true;
            $retval = null;

            $failureMap = array();


            // We call the validate method on the following object(s) if they
            // were passed to this object by their corresponding set
            // method.  This object relates to these object(s) by a
            // foreign key reference.

            if ($this->aLibrarianRelatedByCreatedBy !== null) {
                if (!$this->aLibrarianRelatedByCreatedBy->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aLibrarianRelatedByCreatedBy->getValidationFailures());
                }
            }

            if ($this->aLibrarianRelatedByModifiedBy !== null) {
                if (!$this->aLibrarianRelatedByModifiedBy->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aLibrarianRelatedByModifiedBy->getValidationFailures());
                }
            }

            if ($this->aBudget !== null) {
                if (!$this->aBudget->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aBudget->getValidationFailures());
                }
            }


            if (($retval = BudgetOperationPeer::doValidate($this, $columns)) !== true) {
                $failureMap = array_merge($failureMap, $retval);
            }



            $this->alreadyInValidation = false;
        }

        return (!empty($failureMap) ? $failureMap : true);
    }

    /**
     * Retrieves a field from the object by name passed in as a string.
     *
     * @param string $name name
     * @param string $type The type of fieldname the $name is of:
     *               one of the class type constants BasePeer::TYPE_PHPNAME, BasePeer::TYPE_STUDLYPHPNAME
     *               BasePeer::TYPE_COLNAME, BasePeer::TYPE_FIELDNAME, BasePeer::TYPE_NUM.
     *               Defaults to BasePeer::TYPE_PHPNAME
     * @return mixed Value of field.
     */
    public function getByName($name, $type = BasePeer::TYPE_PHPNAME)
    {
        $pos = BudgetOperationPeer::translateFieldName($name, $type, BasePeer::TYPE_NUM);
        $field = $this->getByPosition($pos);

        return $field;
    }

    /**
     * Retrieves a field from the object by Position as specified in the xml schema.
     * Zero-based.
     *
     * @param int $pos position in xml schema
     * @return mixed Value of field at $pos
     */
    public function getByPosition($pos)
    {
        switch ($pos) {
            case 0:
                return $this->getBudgetId();
                break;
            case 1:
                return $this->getAmount();
                break;
            case 2:
                return $this->getOperationNote();
                break;
            case 3:
                return $this->getOperationDate();
                break;
            case 4:
                return $this->getDateCreated();
                break;
            case 5:
                return $this->getDateUpdated();
                break;
            case 6:
                return $this->getCreatedBy();
                break;
            case 7:
                return $this->getModifiedBy();
                break;
            default:
                return null;
                break;
        } // switch()
    }

    /**
     * Exports the object as an array.
     *
     * You can specify the key type of the array by passing one of the class
     * type constants.
     *
     * @param     string  $keyType (optional) One of the class type constants BasePeer::TYPE_PHPNAME, BasePeer::TYPE_STUDLYPHPNAME,
     *                    BasePeer::TYPE_COLNAME, BasePeer::TYPE_FIELDNAME, BasePeer::TYPE_NUM.
     *                    Defaults to BasePeer::TYPE_PHPNAME.
     * @param     boolean $includeLazyLoadColumns (optional) Whether to include lazy loaded columns. Defaults to true.
     * @param     array $alreadyDumpedObjects List of objects to skip to avoid recursion
     * @param     boolean $includeForeignObjects (optional) Whether to include hydrated related objects. Default to FALSE.
     *
     * @return array an associative array containing the field names (as keys) and field values
     */
    public function toArray($keyType = BasePeer::TYPE_PHPNAME, $includeLazyLoadColumns = true, $alreadyDumpedObjects = array(), $includeForeignObjects = false)
    {
        if (isset($alreadyDumpedObjects['BudgetOperation'][$this->getPrimaryKey()])) {
            return '*RECURSION*';
        }
        $alreadyDumpedObjects['BudgetOperation'][$this->getPrimaryKey()] = true;
        $keys = BudgetOperationPeer::getFieldNames($keyType);
        $result = array(
            $keys[0] => $this->getBudgetId(),
            $keys[1] => $this->getAmount(),
            $keys[2] => $this->getOperationNote(),
            $keys[3] => $this->getOperationDate(),
            $keys[4] => $this->getDateCreated(),
            $keys[5] => $this->getDateUpdated(),
            $keys[6] => $this->getCreatedBy(),
            $keys[7] => $this->getModifiedBy(),
        );
        $virtualColumns = $this->virtualColumns;
        foreach ($virtualColumns as $key => $virtualColumn) {
            $result[$key] = $virtualColumn;
        }

        if ($includeForeignObjects) {
            if (null !== $this->aLibrarianRelatedByCreatedBy) {
                $result['LibrarianRelatedByCreatedBy'] = $this->aLibrarianRelatedByCreatedBy->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->aLibrarianRelatedByModifiedBy) {
                $result['LibrarianRelatedByModifiedBy'] = $this->aLibrarianRelatedByModifiedBy->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->aBudget) {
                $result['Budget'] = $this->aBudget->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
        }

        return $result;
    }

    /**
     * Sets a field from the object by name passed in as a string.
     *
     * @param string $name peer name
     * @param mixed $value field value
     * @param string $type The type of fieldname the $name is of:
     *                     one of the class type constants BasePeer::TYPE_PHPNAME, BasePeer::TYPE_STUDLYPHPNAME
     *                     BasePeer::TYPE_COLNAME, BasePeer::TYPE_FIELDNAME, BasePeer::TYPE_NUM.
     *                     Defaults to BasePeer::TYPE_PHPNAME
     * @return void
     */
    public function setByName($name, $value, $type = BasePeer::TYPE_PHPNAME)
    {
        $pos = BudgetOperationPeer::translateFieldName($name, $type, BasePeer::TYPE_NUM);

        $this->setByPosition($pos, $value);
    }

    /**
     * Sets a field from the object by Position as specified in the xml schema.
     * Zero-based.
     *
     * @param int $pos position in xml schema
     * @param mixed $value field value
     * @return void
     */
    public function setByPosition($pos, $value)
    {
        switch ($pos) {
            case 0:
                $this->setBudgetId($value);
                break;
            case 1:
                $this->setAmount($value);
                break;
            case 2:
                $this->setOperationNote($value);
                break;
            case 3:
                $this->setOperationDate($value);
                break;
            case 4:
                $this->setDateCreated($value);
                break;
            case 5:
                $this->setDateUpdated($value);
                break;
            case 6:
                $this->setCreatedBy($value);
                break;
            case 7:
                $this->setModifiedBy($value);
                break;
        } // switch()
    }

    /**
     * Populates the object using an array.
     *
     * This is particularly useful when populating an object from one of the
     * request arrays (e.g. $_POST).  This method goes through the column
     * names, checking to see whether a matching key exists in populated
     * array. If so the setByName() method is called for that column.
     *
     * You can specify the key type of the array by additionally passing one
     * of the class type constants BasePeer::TYPE_PHPNAME, BasePeer::TYPE_STUDLYPHPNAME,
     * BasePeer::TYPE_COLNAME, BasePeer::TYPE_FIELDNAME, BasePeer::TYPE_NUM.
     * The default key type is the column's BasePeer::TYPE_PHPNAME
     *
     * @param array  $arr     An array to populate the object from.
     * @param string $keyType The type of keys the array uses.
     * @return void
     */
    public function fromArray($arr, $keyType = BasePeer::TYPE_PHPNAME)
    {
        $keys = BudgetOperationPeer::getFieldNames($keyType);

        if (array_key_exists($keys[0], $arr)) $this->setBudgetId($arr[$keys[0]]);
        if (array_key_exists($keys[1], $arr)) $this->setAmount($arr[$keys[1]]);
        if (array_key_exists($keys[2], $arr)) $this->setOperationNote($arr[$keys[2]]);
        if (array_key_exists($keys[3], $arr)) $this->setOperationDate($arr[$keys[3]]);
        if (array_key_exists($keys[4], $arr)) $this->setDateCreated($arr[$keys[4]]);
        if (array_key_exists($keys[5], $arr)) $this->setDateUpdated($arr[$keys[5]]);
        if (array_key_exists($keys[6], $arr)) $this->setCreatedBy($arr[$keys[6]]);
        if (array_key_exists($keys[7], $arr)) $this->setModifiedBy($arr[$keys[7]]);
    }

    /**
     * Build a Criteria object containing the values of all modified columns in this object.
     *
     * @return Criteria The Criteria object containing all modified values.
     */
    public function buildCriteria()
    {
        $criteria = new Criteria(BudgetOperationPeer::DATABASE_NAME);

        if ($this->isColumnModified(BudgetOperationPeer::BUDGET_ID)) $criteria->add(BudgetOperationPeer::BUDGET_ID, $this->budget_id);
        if ($this->isColumnModified(BudgetOperationPeer::AMOUNT)) $criteria->add(BudgetOperationPeer::AMOUNT, $this->amount);
        if ($this->isColumnModified(BudgetOperationPeer::OPERATION_NOTE)) $criteria->add(BudgetOperationPeer::OPERATION_NOTE, $this->operation_note);
        if ($this->isColumnModified(BudgetOperationPeer::OPERATION_DATE)) $criteria->add(BudgetOperationPeer::OPERATION_DATE, $this->operation_date);
        if ($this->isColumnModified(BudgetOperationPeer::DATE_CREATED)) $criteria->add(BudgetOperationPeer::DATE_CREATED, $this->date_created);
        if ($this->isColumnModified(BudgetOperationPeer::DATE_UPDATED)) $criteria->add(BudgetOperationPeer::DATE_UPDATED, $this->date_updated);
        if ($this->isColumnModified(BudgetOperationPeer::CREATED_BY)) $criteria->add(BudgetOperationPeer::CREATED_BY, $this->created_by);
        if ($this->isColumnModified(BudgetOperationPeer::MODIFIED_BY)) $criteria->add(BudgetOperationPeer::MODIFIED_BY, $this->modified_by);

        return $criteria;
    }

    /**
     * Builds a Criteria object containing the primary key for this object.
     *
     * Unlike buildCriteria() this method includes the primary key values regardless
     * of whether or not they have been modified.
     *
     * @return Criteria The Criteria object containing value(s) for primary key(s).
     */
    public function buildPkeyCriteria()
    {
        $criteria = new Criteria(BudgetOperationPeer::DATABASE_NAME);
        $criteria->add(BudgetOperationPeer::BUDGET_ID, $this->budget_id);

        return $criteria;
    }

    /**
     * Returns the primary key for this object (row).
     * @return int
     */
    public function getPrimaryKey()
    {
        return $this->getBudgetId();
    }

    /**
     * Generic method to set the primary key (budget_id column).
     *
     * @param  int $key Primary key.
     * @return void
     */
    public function setPrimaryKey($key)
    {
        $this->setBudgetId($key);
    }

    /**
     * Returns true if the primary key for this object is null.
     * @return boolean
     */
    public function isPrimaryKeyNull()
    {

        return null === $this->getBudgetId();
    }

    /**
     * Sets contents of passed object to values from current object.
     *
     * If desired, this method can also make copies of all associated (fkey referrers)
     * objects.
     *
     * @param object $copyObj An object of BudgetOperation (or compatible) type.
     * @param boolean $deepCopy Whether to also copy all rows that refer (by fkey) to the current row.
     * @param boolean $makeNew Whether to reset autoincrement PKs and make the object new.
     * @throws PropelException
     */
    public function copyInto($copyObj, $deepCopy = false, $makeNew = true)
    {
        $copyObj->setAmount($this->getAmount());
        $copyObj->setOperationNote($this->getOperationNote());
        $copyObj->setOperationDate($this->getOperationDate());
        $copyObj->setDateCreated($this->getDateCreated());
        $copyObj->setDateUpdated($this->getDateUpdated());
        $copyObj->setCreatedBy($this->getCreatedBy());
        $copyObj->setModifiedBy($this->getModifiedBy());

        if ($deepCopy && !$this->startCopy) {
            // important: temporarily setNew(false) because this affects the behavior of
            // the getter/setter methods for fkey referrer objects.
            $copyObj->setNew(false);
            // store object hash to prevent cycle
            $this->startCopy = true;

            $relObj = $this->getBudget();
            if ($relObj) {
                $copyObj->setBudget($relObj->copy($deepCopy));
            }

            //unflag object copy
            $this->startCopy = false;
        } // if ($deepCopy)

        if ($makeNew) {
            $copyObj->setNew(true);
            $copyObj->setBudgetId(NULL); // this is a auto-increment column, so set to default value
        }
    }

    /**
     * Makes a copy of this object that will be inserted as a new row in table when saved.
     * It creates a new object filling in the simple attributes, but skipping any primary
     * keys that are defined for the table.
     *
     * If desired, this method can also make copies of all associated (fkey referrers)
     * objects.
     *
     * @param boolean $deepCopy Whether to also copy all rows that refer (by fkey) to the current row.
     * @return BudgetOperation Clone of current object.
     * @throws PropelException
     */
    public function copy($deepCopy = false)
    {
        // we use get_class(), because this might be a subclass
        $clazz = get_class($this);
        $copyObj = new $clazz();
        $this->copyInto($copyObj, $deepCopy);

        return $copyObj;
    }

    /**
     * Returns a peer instance associated with this om.
     *
     * Since Peer classes are not to have any instance attributes, this method returns the
     * same instance for all member of this class. The method could therefore
     * be static, but this would prevent one from overriding the behavior.
     *
     * @return BudgetOperationPeer
     */
    public function getPeer()
    {
        if (self::$peer === null) {
            self::$peer = new BudgetOperationPeer();
        }

        return self::$peer;
    }

    /**
     * Declares an association between this object and a Librarian object.
     *
     * @param                  Librarian $v
     * @return BudgetOperation The current object (for fluent API support)
     * @throws PropelException
     */
    public function setLibrarianRelatedByCreatedBy(Librarian $v = null)
    {
        if ($v === null) {
            $this->setCreatedBy(NULL);
        } else {
            $this->setCreatedBy($v->getLibrarianId());
        }

        $this->aLibrarianRelatedByCreatedBy = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the Librarian object, it will not be re-added.
        if ($v !== null) {
            $v->addBudgetOperationRelatedByCreatedBy($this);
        }


        return $this;
    }


    /**
     * Get the associated Librarian object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return Librarian The associated Librarian object.
     * @throws PropelException
     */
    public function getLibrarianRelatedByCreatedBy(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aLibrarianRelatedByCreatedBy === null && ($this->created_by !== null) && $doQuery) {
            $this->aLibrarianRelatedByCreatedBy = LibrarianQuery::create()->findPk($this->created_by, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aLibrarianRelatedByCreatedBy->addBudgetOperationsRelatedByCreatedBy($this);
             */
        }

        return $this->aLibrarianRelatedByCreatedBy;
    }

    /**
     * Declares an association between this object and a Librarian object.
     *
     * @param                  Librarian $v
     * @return BudgetOperation The current object (for fluent API support)
     * @throws PropelException
     */
    public function setLibrarianRelatedByModifiedBy(Librarian $v = null)
    {
        if ($v === null) {
            $this->setModifiedBy(NULL);
        } else {
            $this->setModifiedBy($v->getLibrarianId());
        }

        $this->aLibrarianRelatedByModifiedBy = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the Librarian object, it will not be re-added.
        if ($v !== null) {
            $v->addBudgetOperationRelatedByModifiedBy($this);
        }


        return $this;
    }


    /**
     * Get the associated Librarian object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return Librarian The associated Librarian object.
     * @throws PropelException
     */
    public function getLibrarianRelatedByModifiedBy(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aLibrarianRelatedByModifiedBy === null && ($this->modified_by !== null) && $doQuery) {
            $this->aLibrarianRelatedByModifiedBy = LibrarianQuery::create()->findPk($this->modified_by, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aLibrarianRelatedByModifiedBy->addBudgetOperationsRelatedByModifiedBy($this);
             */
        }

        return $this->aLibrarianRelatedByModifiedBy;
    }

    /**
     * Declares an association between this object and a Budget object.
     *
     * @param                  Budget $v
     * @return BudgetOperation The current object (for fluent API support)
     * @throws PropelException
     */
    public function setBudget(Budget $v = null)
    {
        if ($v === null) {
            $this->setBudgetId(NULL);
        } else {
            $this->setBudgetId($v->getBudgetId());
        }

        $this->aBudget = $v;

        // Add binding for other direction of this 1:1 relationship.
        if ($v !== null) {
            $v->setBudgetOperation($this);
        }


        return $this;
    }


    /**
     * Get the associated Budget object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return Budget The associated Budget object.
     * @throws PropelException
     */
    public function getBudget(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aBudget === null && ($this->budget_id !== null) && $doQuery) {
            $this->aBudget = BudgetQuery::create()->findPk($this->budget_id, $con);
            // Because this foreign key represents a one-to-one relationship, we will create a bi-directional association.
            $this->aBudget->setBudgetOperation($this);
        }

        return $this->aBudget;
    }

    /**
     * Clears the current object and sets all attributes to their default values
     */
    public function clear()
    {
        $this->budget_id = null;
        $this->amount = null;
        $this->operation_note = null;
        $this->operation_date = null;
        $this->date_created = null;
        $this->date_updated = null;
        $this->created_by = null;
        $this->modified_by = null;
        $this->alreadyInSave = false;
        $this->alreadyInValidation = false;
        $this->alreadyInClearAllReferencesDeep = false;
        $this->clearAllReferences();
        $this->resetModified();
        $this->setNew(true);
        $this->setDeleted(false);
    }

    /**
     * Resets all references to other model objects or collections of model objects.
     *
     * This method is a user-space workaround for PHP's inability to garbage collect
     * objects with circular references (even in PHP 5.3). This is currently necessary
     * when using Propel in certain daemon or large-volume/high-memory operations.
     *
     * @param boolean $deep Whether to also clear the references on all referrer objects.
     */
    public function clearAllReferences($deep = false)
    {
        if ($deep && !$this->alreadyInClearAllReferencesDeep) {
            $this->alreadyInClearAllReferencesDeep = true;
            if ($this->aLibrarianRelatedByCreatedBy instanceof Persistent) {
              $this->aLibrarianRelatedByCreatedBy->clearAllReferences($deep);
            }
            if ($this->aLibrarianRelatedByModifiedBy instanceof Persistent) {
              $this->aLibrarianRelatedByModifiedBy->clearAllReferences($deep);
            }
            if ($this->aBudget instanceof Persistent) {
              $this->aBudget->clearAllReferences($deep);
            }

            $this->alreadyInClearAllReferencesDeep = false;
        } // if ($deep)

        $this->aLibrarianRelatedByCreatedBy = null;
        $this->aLibrarianRelatedByModifiedBy = null;
        $this->aBudget = null;
    }

    /**
     * return the string representation of this object
     *
     * @return string
     */
    public function __toString()
    {
        return (string) $this->exportTo(BudgetOperationPeer::DEFAULT_STRING_FORMAT);
    }

    /**
     * return true is the object is in saving state
     *
     * @return boolean
     */
    public function isAlreadyInSave()
    {
        return $this->alreadyInSave;
    }

    // timestampable behavior

    /**
     * Mark the current object so that the update date doesn't get updated during next save
     *
     * @return     BudgetOperation The current object (for fluent API support)
     */
    public function keepUpdateDateUnchanged()
    {
        $this->modifiedColumns[] = BudgetOperationPeer::DATE_UPDATED;

        return $this;
    }

    // librariantrace behavior

    /**
     * Returns the complete name of the librarian that created this object.
     *
     * @return string
     */
    public function getCreatedByNameString()
    {
        $l = $this->getLibrarianRelatedByCreatedBy();
        return ($l instanceof Librarian) ? $l->getCompleteName() : '';
    }

    /**
     * Returns the complete name of the librarian that last updated this object.
     *
     * @return string
     */
    public function getModifiedByNameString()
    {
        $l = $this->getLibrarianRelatedByModifiedBy();
        return ($l instanceof Librarian) ? $l->getCompleteName() : '';
    }

    /**
     * Mark the current object so that the update date doesn't get updated during next save
     *
     * @return     BudgetOperation The current object (for fluent API support)
     */
    public function keepUpdateLibrarianUnchanged()
    {
        $this->modifiedColumns[] = BudgetOperationPeer::MODIFIED_BY;
        return $this;
    }

}
