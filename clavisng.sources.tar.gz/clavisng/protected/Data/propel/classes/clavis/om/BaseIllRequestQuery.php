<?php


/**
 * Base class that represents a query for the 'ill_request' table.
 *
 *
 *
 * @method IllRequestQuery orderByIllRequestId($order = Criteria::ASC) Order by the ill_request_id column
 * @method IllRequestQuery orderByRequestStatus($order = Criteria::ASC) Order by the request_status column
 * @method IllRequestQuery orderByRequestDate($order = Criteria::ASC) Order by the request_date column
 * @method IllRequestQuery orderByFromLibraryId($order = Criteria::ASC) Order by the from_library_id column
 * @method IllRequestQuery orderByToLibraryId($order = Criteria::ASC) Order by the to_library_id column
 * @method IllRequestQuery orderByPatronId($order = Criteria::ASC) Order by the patron_id column
 * @method IllRequestQuery orderByRequestKey($order = Criteria::ASC) Order by the request_key column
 * @method IllRequestQuery orderByLibrarianId($order = Criteria::ASC) Order by the librarian_id column
 * @method IllRequestQuery orderByItemLocation($order = Criteria::ASC) Order by the item_location column
 * @method IllRequestQuery orderByItemTitle($order = Criteria::ASC) Order by the item_title column
 * @method IllRequestQuery orderByStartLoanDate($order = Criteria::ASC) Order by the start_loan_date column
 * @method IllRequestQuery orderByDueDate($order = Criteria::ASC) Order by the due_date column
 * @method IllRequestQuery orderByTitle($order = Criteria::ASC) Order by the title column
 * @method IllRequestQuery orderByUnimarc($order = Criteria::ASC) Order by the unimarc column
 * @method IllRequestQuery orderByDateCreated($order = Criteria::ASC) Order by the date_created column
 * @method IllRequestQuery orderByDateUpdated($order = Criteria::ASC) Order by the date_updated column
 * @method IllRequestQuery orderByCreatedBy($order = Criteria::ASC) Order by the created_by column
 * @method IllRequestQuery orderByModifiedBy($order = Criteria::ASC) Order by the modified_by column
 *
 * @method IllRequestQuery groupByIllRequestId() Group by the ill_request_id column
 * @method IllRequestQuery groupByRequestStatus() Group by the request_status column
 * @method IllRequestQuery groupByRequestDate() Group by the request_date column
 * @method IllRequestQuery groupByFromLibraryId() Group by the from_library_id column
 * @method IllRequestQuery groupByToLibraryId() Group by the to_library_id column
 * @method IllRequestQuery groupByPatronId() Group by the patron_id column
 * @method IllRequestQuery groupByRequestKey() Group by the request_key column
 * @method IllRequestQuery groupByLibrarianId() Group by the librarian_id column
 * @method IllRequestQuery groupByItemLocation() Group by the item_location column
 * @method IllRequestQuery groupByItemTitle() Group by the item_title column
 * @method IllRequestQuery groupByStartLoanDate() Group by the start_loan_date column
 * @method IllRequestQuery groupByDueDate() Group by the due_date column
 * @method IllRequestQuery groupByTitle() Group by the title column
 * @method IllRequestQuery groupByUnimarc() Group by the unimarc column
 * @method IllRequestQuery groupByDateCreated() Group by the date_created column
 * @method IllRequestQuery groupByDateUpdated() Group by the date_updated column
 * @method IllRequestQuery groupByCreatedBy() Group by the created_by column
 * @method IllRequestQuery groupByModifiedBy() Group by the modified_by column
 *
 * @method IllRequestQuery leftJoin($relation) Adds a LEFT JOIN clause to the query
 * @method IllRequestQuery rightJoin($relation) Adds a RIGHT JOIN clause to the query
 * @method IllRequestQuery innerJoin($relation) Adds a INNER JOIN clause to the query
 *
 * @method IllRequestQuery leftJoinLibrarianRelatedByCreatedBy($relationAlias = null) Adds a LEFT JOIN clause to the query using the LibrarianRelatedByCreatedBy relation
 * @method IllRequestQuery rightJoinLibrarianRelatedByCreatedBy($relationAlias = null) Adds a RIGHT JOIN clause to the query using the LibrarianRelatedByCreatedBy relation
 * @method IllRequestQuery innerJoinLibrarianRelatedByCreatedBy($relationAlias = null) Adds a INNER JOIN clause to the query using the LibrarianRelatedByCreatedBy relation
 *
 * @method IllRequestQuery leftJoinLibrarianRelatedByModifiedBy($relationAlias = null) Adds a LEFT JOIN clause to the query using the LibrarianRelatedByModifiedBy relation
 * @method IllRequestQuery rightJoinLibrarianRelatedByModifiedBy($relationAlias = null) Adds a RIGHT JOIN clause to the query using the LibrarianRelatedByModifiedBy relation
 * @method IllRequestQuery innerJoinLibrarianRelatedByModifiedBy($relationAlias = null) Adds a INNER JOIN clause to the query using the LibrarianRelatedByModifiedBy relation
 *
 * @method IllRequest findOne(PropelPDO $con = null) Return the first IllRequest matching the query
 * @method IllRequest findOneOrCreate(PropelPDO $con = null) Return the first IllRequest matching the query, or a new IllRequest object populated from the query conditions when no match is found
 *
 * @method IllRequest findOneByRequestStatus(string $request_status) Return the first IllRequest filtered by the request_status column
 * @method IllRequest findOneByRequestDate(string $request_date) Return the first IllRequest filtered by the request_date column
 * @method IllRequest findOneByFromLibraryId(int $from_library_id) Return the first IllRequest filtered by the from_library_id column
 * @method IllRequest findOneByToLibraryId(int $to_library_id) Return the first IllRequest filtered by the to_library_id column
 * @method IllRequest findOneByPatronId(int $patron_id) Return the first IllRequest filtered by the patron_id column
 * @method IllRequest findOneByRequestKey(string $request_key) Return the first IllRequest filtered by the request_key column
 * @method IllRequest findOneByLibrarianId(int $librarian_id) Return the first IllRequest filtered by the librarian_id column
 * @method IllRequest findOneByItemLocation(string $item_location) Return the first IllRequest filtered by the item_location column
 * @method IllRequest findOneByItemTitle(string $item_title) Return the first IllRequest filtered by the item_title column
 * @method IllRequest findOneByStartLoanDate(string $start_loan_date) Return the first IllRequest filtered by the start_loan_date column
 * @method IllRequest findOneByDueDate(string $due_date) Return the first IllRequest filtered by the due_date column
 * @method IllRequest findOneByTitle(string $title) Return the first IllRequest filtered by the title column
 * @method IllRequest findOneByUnimarc(string $unimarc) Return the first IllRequest filtered by the unimarc column
 * @method IllRequest findOneByDateCreated(string $date_created) Return the first IllRequest filtered by the date_created column
 * @method IllRequest findOneByDateUpdated(string $date_updated) Return the first IllRequest filtered by the date_updated column
 * @method IllRequest findOneByCreatedBy(int $created_by) Return the first IllRequest filtered by the created_by column
 * @method IllRequest findOneByModifiedBy(int $modified_by) Return the first IllRequest filtered by the modified_by column
 *
 * @method array findByIllRequestId(int $ill_request_id) Return IllRequest objects filtered by the ill_request_id column
 * @method array findByRequestStatus(string $request_status) Return IllRequest objects filtered by the request_status column
 * @method array findByRequestDate(string $request_date) Return IllRequest objects filtered by the request_date column
 * @method array findByFromLibraryId(int $from_library_id) Return IllRequest objects filtered by the from_library_id column
 * @method array findByToLibraryId(int $to_library_id) Return IllRequest objects filtered by the to_library_id column
 * @method array findByPatronId(int $patron_id) Return IllRequest objects filtered by the patron_id column
 * @method array findByRequestKey(string $request_key) Return IllRequest objects filtered by the request_key column
 * @method array findByLibrarianId(int $librarian_id) Return IllRequest objects filtered by the librarian_id column
 * @method array findByItemLocation(string $item_location) Return IllRequest objects filtered by the item_location column
 * @method array findByItemTitle(string $item_title) Return IllRequest objects filtered by the item_title column
 * @method array findByStartLoanDate(string $start_loan_date) Return IllRequest objects filtered by the start_loan_date column
 * @method array findByDueDate(string $due_date) Return IllRequest objects filtered by the due_date column
 * @method array findByTitle(string $title) Return IllRequest objects filtered by the title column
 * @method array findByUnimarc(string $unimarc) Return IllRequest objects filtered by the unimarc column
 * @method array findByDateCreated(string $date_created) Return IllRequest objects filtered by the date_created column
 * @method array findByDateUpdated(string $date_updated) Return IllRequest objects filtered by the date_updated column
 * @method array findByCreatedBy(int $created_by) Return IllRequest objects filtered by the created_by column
 * @method array findByModifiedBy(int $modified_by) Return IllRequest objects filtered by the modified_by column
 *
 * @package    propel.generator.clavis.om
 */
abstract class BaseIllRequestQuery extends ModelCriteria
{
    /**
     * Initializes internal state of BaseIllRequestQuery object.
     *
     * @param     string $dbName The dabase name
     * @param     string $modelName The phpName of a model, e.g. 'Book'
     * @param     string $modelAlias The alias for the model in this query, e.g. 'b'
     */
    public function __construct($dbName = null, $modelName = null, $modelAlias = null)
    {
        if (null === $dbName) {
            $dbName = 'clavis';
        }
        if (null === $modelName) {
            $modelName = 'IllRequest';
        }
        parent::__construct($dbName, $modelName, $modelAlias);
    }

    /**
     * Returns a new IllRequestQuery object.
     *
     * @param     string $modelAlias The alias of a model in the query
     * @param   IllRequestQuery|Criteria $criteria Optional Criteria to build the query from
     *
     * @return IllRequestQuery
     */
    public static function create($modelAlias = null, $criteria = null)
    {
        if ($criteria instanceof IllRequestQuery) {
            return $criteria;
        }
        $query = new IllRequestQuery(null, null, $modelAlias);

        if ($criteria instanceof Criteria) {
            $query->mergeWith($criteria);
        }

        return $query;
    }

    /**
     * Find object by primary key.
     * Propel uses the instance pool to skip the database if the object exists.
     * Go fast if the query is untouched.
     *
     * <code>
     * $obj  = $c->findPk(12, $con);
     * </code>
     *
     * @param mixed $key Primary key to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return   IllRequest|IllRequest[]|mixed the result, formatted by the current formatter
     */
    public function findPk($key, $con = null)
    {
        if ($key === null) {
            return null;
        }
        if ((null !== ($obj = IllRequestPeer::getInstanceFromPool((string) $key))) && !$this->formatter) {
            // the object is already in the instance pool
            return $obj;
        }
        if ($con === null) {
            $con = Propel::getConnection(IllRequestPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        if ($this->formatter || $this->modelAlias || $this->with || $this->select
         || $this->selectColumns || $this->asColumns || $this->selectModifiers
         || $this->map || $this->having || $this->joins) {
            return $this->findPkComplex($key, $con);
        } else {
            return $this->findPkSimple($key, $con);
        }
    }

    /**
     * Alias of findPk to use instance pooling
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 IllRequest A model object, or null if the key is not found
     * @throws PropelException
     */
     public function findOneByIllRequestId($key, $con = null)
     {
        return $this->findPk($key, $con);
     }

    /**
     * Find object by primary key using raw SQL to go fast.
     * Bypass doSelect() and the object formatter by using generated code.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 IllRequest A model object, or null if the key is not found
     * @throws PropelException
     */
    protected function findPkSimple($key, $con)
    {
        $sql = 'SELECT `ill_request_id`, `request_status`, `request_date`, `from_library_id`, `to_library_id`, `patron_id`, `request_key`, `librarian_id`, `item_location`, `item_title`, `start_loan_date`, `due_date`, `title`, `unimarc`, `date_created`, `date_updated`, `created_by`, `modified_by` FROM `ill_request` WHERE `ill_request_id` = :p0';
        try {
            $stmt = $con->prepare($sql);
            $stmt->bindValue(':p0', $key, PDO::PARAM_INT);
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute SELECT statement [%s]', $sql), $e);
        }
        $obj = null;
        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $obj = new IllRequest();
            $obj->hydrate($row);
            IllRequestPeer::addInstanceToPool($obj, (string) $key);
        }
        $stmt->closeCursor();

        return $obj;
    }

    /**
     * Find object by primary key.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return IllRequest|IllRequest[]|mixed the result, formatted by the current formatter
     */
    protected function findPkComplex($key, $con)
    {
        // As the query uses a PK condition, no limit(1) is necessary.
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKey($key)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->formatOne($stmt);
    }

    /**
     * Find objects by primary key
     * <code>
     * $objs = $c->findPks(array(12, 56, 832), $con);
     * </code>
     * @param     array $keys Primary keys to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return PropelObjectCollection|IllRequest[]|mixed the list of results, formatted by the current formatter
     */
    public function findPks($keys, $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection($this->getDbName(), Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKeys($keys)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->format($stmt);
    }

    /**
     * Filter the query by primary key
     *
     * @param     mixed $key Primary key to use for the query
     *
     * @return IllRequestQuery The current query, for fluid interface
     */
    public function filterByPrimaryKey($key)
    {

        return $this->addUsingAlias(IllRequestPeer::ILL_REQUEST_ID, $key, Criteria::EQUAL);
    }

    /**
     * Filter the query by a list of primary keys
     *
     * @param     array $keys The list of primary key to use for the query
     *
     * @return IllRequestQuery The current query, for fluid interface
     */
    public function filterByPrimaryKeys($keys)
    {

        return $this->addUsingAlias(IllRequestPeer::ILL_REQUEST_ID, $keys, Criteria::IN);
    }

    /**
     * Filter the query on the ill_request_id column
     *
     * Example usage:
     * <code>
     * $query->filterByIllRequestId(1234); // WHERE ill_request_id = 1234
     * $query->filterByIllRequestId(array(12, 34)); // WHERE ill_request_id IN (12, 34)
     * $query->filterByIllRequestId(array('min' => 12)); // WHERE ill_request_id >= 12
     * $query->filterByIllRequestId(array('max' => 12)); // WHERE ill_request_id <= 12
     * </code>
     *
     * @param     mixed $illRequestId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return IllRequestQuery The current query, for fluid interface
     */
    public function filterByIllRequestId($illRequestId = null, $comparison = null)
    {
        if (is_array($illRequestId)) {
            $useMinMax = false;
            if (isset($illRequestId['min'])) {
                $this->addUsingAlias(IllRequestPeer::ILL_REQUEST_ID, $illRequestId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($illRequestId['max'])) {
                $this->addUsingAlias(IllRequestPeer::ILL_REQUEST_ID, $illRequestId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(IllRequestPeer::ILL_REQUEST_ID, $illRequestId, $comparison);
    }

    /**
     * Filter the query on the request_status column
     *
     * Example usage:
     * <code>
     * $query->filterByRequestStatus('fooValue');   // WHERE request_status = 'fooValue'
     * $query->filterByRequestStatus('%fooValue%'); // WHERE request_status LIKE '%fooValue%'
     * </code>
     *
     * @param     string $requestStatus The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return IllRequestQuery The current query, for fluid interface
     */
    public function filterByRequestStatus($requestStatus = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($requestStatus)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $requestStatus)) {
                $requestStatus = str_replace('*', '%', $requestStatus);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(IllRequestPeer::REQUEST_STATUS, $requestStatus, $comparison);
    }

    /**
     * Filter the query on the request_date column
     *
     * Example usage:
     * <code>
     * $query->filterByRequestDate('2011-03-14'); // WHERE request_date = '2011-03-14'
     * $query->filterByRequestDate('now'); // WHERE request_date = '2011-03-14'
     * $query->filterByRequestDate(array('max' => 'yesterday')); // WHERE request_date < '2011-03-13'
     * </code>
     *
     * @param     mixed $requestDate The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return IllRequestQuery The current query, for fluid interface
     */
    public function filterByRequestDate($requestDate = null, $comparison = null)
    {
        if (is_array($requestDate)) {
            $useMinMax = false;
            if (isset($requestDate['min'])) {
                $this->addUsingAlias(IllRequestPeer::REQUEST_DATE, $requestDate['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($requestDate['max'])) {
                $this->addUsingAlias(IllRequestPeer::REQUEST_DATE, $requestDate['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(IllRequestPeer::REQUEST_DATE, $requestDate, $comparison);
    }

    /**
     * Filter the query on the from_library_id column
     *
     * Example usage:
     * <code>
     * $query->filterByFromLibraryId(1234); // WHERE from_library_id = 1234
     * $query->filterByFromLibraryId(array(12, 34)); // WHERE from_library_id IN (12, 34)
     * $query->filterByFromLibraryId(array('min' => 12)); // WHERE from_library_id >= 12
     * $query->filterByFromLibraryId(array('max' => 12)); // WHERE from_library_id <= 12
     * </code>
     *
     * @param     mixed $fromLibraryId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return IllRequestQuery The current query, for fluid interface
     */
    public function filterByFromLibraryId($fromLibraryId = null, $comparison = null)
    {
        if (is_array($fromLibraryId)) {
            $useMinMax = false;
            if (isset($fromLibraryId['min'])) {
                $this->addUsingAlias(IllRequestPeer::FROM_LIBRARY_ID, $fromLibraryId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($fromLibraryId['max'])) {
                $this->addUsingAlias(IllRequestPeer::FROM_LIBRARY_ID, $fromLibraryId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(IllRequestPeer::FROM_LIBRARY_ID, $fromLibraryId, $comparison);
    }

    /**
     * Filter the query on the to_library_id column
     *
     * Example usage:
     * <code>
     * $query->filterByToLibraryId(1234); // WHERE to_library_id = 1234
     * $query->filterByToLibraryId(array(12, 34)); // WHERE to_library_id IN (12, 34)
     * $query->filterByToLibraryId(array('min' => 12)); // WHERE to_library_id >= 12
     * $query->filterByToLibraryId(array('max' => 12)); // WHERE to_library_id <= 12
     * </code>
     *
     * @param     mixed $toLibraryId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return IllRequestQuery The current query, for fluid interface
     */
    public function filterByToLibraryId($toLibraryId = null, $comparison = null)
    {
        if (is_array($toLibraryId)) {
            $useMinMax = false;
            if (isset($toLibraryId['min'])) {
                $this->addUsingAlias(IllRequestPeer::TO_LIBRARY_ID, $toLibraryId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($toLibraryId['max'])) {
                $this->addUsingAlias(IllRequestPeer::TO_LIBRARY_ID, $toLibraryId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(IllRequestPeer::TO_LIBRARY_ID, $toLibraryId, $comparison);
    }

    /**
     * Filter the query on the patron_id column
     *
     * Example usage:
     * <code>
     * $query->filterByPatronId(1234); // WHERE patron_id = 1234
     * $query->filterByPatronId(array(12, 34)); // WHERE patron_id IN (12, 34)
     * $query->filterByPatronId(array('min' => 12)); // WHERE patron_id >= 12
     * $query->filterByPatronId(array('max' => 12)); // WHERE patron_id <= 12
     * </code>
     *
     * @param     mixed $patronId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return IllRequestQuery The current query, for fluid interface
     */
    public function filterByPatronId($patronId = null, $comparison = null)
    {
        if (is_array($patronId)) {
            $useMinMax = false;
            if (isset($patronId['min'])) {
                $this->addUsingAlias(IllRequestPeer::PATRON_ID, $patronId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($patronId['max'])) {
                $this->addUsingAlias(IllRequestPeer::PATRON_ID, $patronId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(IllRequestPeer::PATRON_ID, $patronId, $comparison);
    }

    /**
     * Filter the query on the request_key column
     *
     * Example usage:
     * <code>
     * $query->filterByRequestKey('fooValue');   // WHERE request_key = 'fooValue'
     * $query->filterByRequestKey('%fooValue%'); // WHERE request_key LIKE '%fooValue%'
     * </code>
     *
     * @param     string $requestKey The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return IllRequestQuery The current query, for fluid interface
     */
    public function filterByRequestKey($requestKey = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($requestKey)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $requestKey)) {
                $requestKey = str_replace('*', '%', $requestKey);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(IllRequestPeer::REQUEST_KEY, $requestKey, $comparison);
    }

    /**
     * Filter the query on the librarian_id column
     *
     * Example usage:
     * <code>
     * $query->filterByLibrarianId(1234); // WHERE librarian_id = 1234
     * $query->filterByLibrarianId(array(12, 34)); // WHERE librarian_id IN (12, 34)
     * $query->filterByLibrarianId(array('min' => 12)); // WHERE librarian_id >= 12
     * $query->filterByLibrarianId(array('max' => 12)); // WHERE librarian_id <= 12
     * </code>
     *
     * @param     mixed $librarianId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return IllRequestQuery The current query, for fluid interface
     */
    public function filterByLibrarianId($librarianId = null, $comparison = null)
    {
        if (is_array($librarianId)) {
            $useMinMax = false;
            if (isset($librarianId['min'])) {
                $this->addUsingAlias(IllRequestPeer::LIBRARIAN_ID, $librarianId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($librarianId['max'])) {
                $this->addUsingAlias(IllRequestPeer::LIBRARIAN_ID, $librarianId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(IllRequestPeer::LIBRARIAN_ID, $librarianId, $comparison);
    }

    /**
     * Filter the query on the item_location column
     *
     * Example usage:
     * <code>
     * $query->filterByItemLocation('fooValue');   // WHERE item_location = 'fooValue'
     * $query->filterByItemLocation('%fooValue%'); // WHERE item_location LIKE '%fooValue%'
     * </code>
     *
     * @param     string $itemLocation The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return IllRequestQuery The current query, for fluid interface
     */
    public function filterByItemLocation($itemLocation = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($itemLocation)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $itemLocation)) {
                $itemLocation = str_replace('*', '%', $itemLocation);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(IllRequestPeer::ITEM_LOCATION, $itemLocation, $comparison);
    }

    /**
     * Filter the query on the item_title column
     *
     * Example usage:
     * <code>
     * $query->filterByItemTitle('fooValue');   // WHERE item_title = 'fooValue'
     * $query->filterByItemTitle('%fooValue%'); // WHERE item_title LIKE '%fooValue%'
     * </code>
     *
     * @param     string $itemTitle The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return IllRequestQuery The current query, for fluid interface
     */
    public function filterByItemTitle($itemTitle = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($itemTitle)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $itemTitle)) {
                $itemTitle = str_replace('*', '%', $itemTitle);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(IllRequestPeer::ITEM_TITLE, $itemTitle, $comparison);
    }

    /**
     * Filter the query on the start_loan_date column
     *
     * Example usage:
     * <code>
     * $query->filterByStartLoanDate('2011-03-14'); // WHERE start_loan_date = '2011-03-14'
     * $query->filterByStartLoanDate('now'); // WHERE start_loan_date = '2011-03-14'
     * $query->filterByStartLoanDate(array('max' => 'yesterday')); // WHERE start_loan_date < '2011-03-13'
     * </code>
     *
     * @param     mixed $startLoanDate The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return IllRequestQuery The current query, for fluid interface
     */
    public function filterByStartLoanDate($startLoanDate = null, $comparison = null)
    {
        if (is_array($startLoanDate)) {
            $useMinMax = false;
            if (isset($startLoanDate['min'])) {
                $this->addUsingAlias(IllRequestPeer::START_LOAN_DATE, $startLoanDate['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($startLoanDate['max'])) {
                $this->addUsingAlias(IllRequestPeer::START_LOAN_DATE, $startLoanDate['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(IllRequestPeer::START_LOAN_DATE, $startLoanDate, $comparison);
    }

    /**
     * Filter the query on the due_date column
     *
     * Example usage:
     * <code>
     * $query->filterByDueDate('2011-03-14'); // WHERE due_date = '2011-03-14'
     * $query->filterByDueDate('now'); // WHERE due_date = '2011-03-14'
     * $query->filterByDueDate(array('max' => 'yesterday')); // WHERE due_date < '2011-03-13'
     * </code>
     *
     * @param     mixed $dueDate The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return IllRequestQuery The current query, for fluid interface
     */
    public function filterByDueDate($dueDate = null, $comparison = null)
    {
        if (is_array($dueDate)) {
            $useMinMax = false;
            if (isset($dueDate['min'])) {
                $this->addUsingAlias(IllRequestPeer::DUE_DATE, $dueDate['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dueDate['max'])) {
                $this->addUsingAlias(IllRequestPeer::DUE_DATE, $dueDate['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(IllRequestPeer::DUE_DATE, $dueDate, $comparison);
    }

    /**
     * Filter the query on the title column
     *
     * Example usage:
     * <code>
     * $query->filterByTitle('fooValue');   // WHERE title = 'fooValue'
     * $query->filterByTitle('%fooValue%'); // WHERE title LIKE '%fooValue%'
     * </code>
     *
     * @param     string $title The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return IllRequestQuery The current query, for fluid interface
     */
    public function filterByTitle($title = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($title)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $title)) {
                $title = str_replace('*', '%', $title);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(IllRequestPeer::TITLE, $title, $comparison);
    }

    /**
     * Filter the query on the unimarc column
     *
     * Example usage:
     * <code>
     * $query->filterByUnimarc('fooValue');   // WHERE unimarc = 'fooValue'
     * $query->filterByUnimarc('%fooValue%'); // WHERE unimarc LIKE '%fooValue%'
     * </code>
     *
     * @param     string $unimarc The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return IllRequestQuery The current query, for fluid interface
     */
    public function filterByUnimarc($unimarc = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($unimarc)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $unimarc)) {
                $unimarc = str_replace('*', '%', $unimarc);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(IllRequestPeer::UNIMARC, $unimarc, $comparison);
    }

    /**
     * Filter the query on the date_created column
     *
     * Example usage:
     * <code>
     * $query->filterByDateCreated('2011-03-14'); // WHERE date_created = '2011-03-14'
     * $query->filterByDateCreated('now'); // WHERE date_created = '2011-03-14'
     * $query->filterByDateCreated(array('max' => 'yesterday')); // WHERE date_created < '2011-03-13'
     * </code>
     *
     * @param     mixed $dateCreated The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return IllRequestQuery The current query, for fluid interface
     */
    public function filterByDateCreated($dateCreated = null, $comparison = null)
    {
        if (is_array($dateCreated)) {
            $useMinMax = false;
            if (isset($dateCreated['min'])) {
                $this->addUsingAlias(IllRequestPeer::DATE_CREATED, $dateCreated['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dateCreated['max'])) {
                $this->addUsingAlias(IllRequestPeer::DATE_CREATED, $dateCreated['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(IllRequestPeer::DATE_CREATED, $dateCreated, $comparison);
    }

    /**
     * Filter the query on the date_updated column
     *
     * Example usage:
     * <code>
     * $query->filterByDateUpdated('2011-03-14'); // WHERE date_updated = '2011-03-14'
     * $query->filterByDateUpdated('now'); // WHERE date_updated = '2011-03-14'
     * $query->filterByDateUpdated(array('max' => 'yesterday')); // WHERE date_updated < '2011-03-13'
     * </code>
     *
     * @param     mixed $dateUpdated The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return IllRequestQuery The current query, for fluid interface
     */
    public function filterByDateUpdated($dateUpdated = null, $comparison = null)
    {
        if (is_array($dateUpdated)) {
            $useMinMax = false;
            if (isset($dateUpdated['min'])) {
                $this->addUsingAlias(IllRequestPeer::DATE_UPDATED, $dateUpdated['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dateUpdated['max'])) {
                $this->addUsingAlias(IllRequestPeer::DATE_UPDATED, $dateUpdated['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(IllRequestPeer::DATE_UPDATED, $dateUpdated, $comparison);
    }

    /**
     * Filter the query on the created_by column
     *
     * Example usage:
     * <code>
     * $query->filterByCreatedBy(1234); // WHERE created_by = 1234
     * $query->filterByCreatedBy(array(12, 34)); // WHERE created_by IN (12, 34)
     * $query->filterByCreatedBy(array('min' => 12)); // WHERE created_by >= 12
     * $query->filterByCreatedBy(array('max' => 12)); // WHERE created_by <= 12
     * </code>
     *
     * @see       filterByLibrarianRelatedByCreatedBy()
     *
     * @param     mixed $createdBy The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return IllRequestQuery The current query, for fluid interface
     */
    public function filterByCreatedBy($createdBy = null, $comparison = null)
    {
        if (is_array($createdBy)) {
            $useMinMax = false;
            if (isset($createdBy['min'])) {
                $this->addUsingAlias(IllRequestPeer::CREATED_BY, $createdBy['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($createdBy['max'])) {
                $this->addUsingAlias(IllRequestPeer::CREATED_BY, $createdBy['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(IllRequestPeer::CREATED_BY, $createdBy, $comparison);
    }

    /**
     * Filter the query on the modified_by column
     *
     * Example usage:
     * <code>
     * $query->filterByModifiedBy(1234); // WHERE modified_by = 1234
     * $query->filterByModifiedBy(array(12, 34)); // WHERE modified_by IN (12, 34)
     * $query->filterByModifiedBy(array('min' => 12)); // WHERE modified_by >= 12
     * $query->filterByModifiedBy(array('max' => 12)); // WHERE modified_by <= 12
     * </code>
     *
     * @see       filterByLibrarianRelatedByModifiedBy()
     *
     * @param     mixed $modifiedBy The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return IllRequestQuery The current query, for fluid interface
     */
    public function filterByModifiedBy($modifiedBy = null, $comparison = null)
    {
        if (is_array($modifiedBy)) {
            $useMinMax = false;
            if (isset($modifiedBy['min'])) {
                $this->addUsingAlias(IllRequestPeer::MODIFIED_BY, $modifiedBy['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($modifiedBy['max'])) {
                $this->addUsingAlias(IllRequestPeer::MODIFIED_BY, $modifiedBy['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(IllRequestPeer::MODIFIED_BY, $modifiedBy, $comparison);
    }

    /**
     * Filter the query by a related Librarian object
     *
     * @param   Librarian|PropelObjectCollection $librarian The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 IllRequestQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByLibrarianRelatedByCreatedBy($librarian, $comparison = null)
    {
        if ($librarian instanceof Librarian) {
            return $this
                ->addUsingAlias(IllRequestPeer::CREATED_BY, $librarian->getLibrarianId(), $comparison);
        } elseif ($librarian instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(IllRequestPeer::CREATED_BY, $librarian->toKeyValue('PrimaryKey', 'LibrarianId'), $comparison);
        } else {
            throw new PropelException('filterByLibrarianRelatedByCreatedBy() only accepts arguments of type Librarian or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the LibrarianRelatedByCreatedBy relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return IllRequestQuery The current query, for fluid interface
     */
    public function joinLibrarianRelatedByCreatedBy($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('LibrarianRelatedByCreatedBy');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'LibrarianRelatedByCreatedBy');
        }

        return $this;
    }

    /**
     * Use the LibrarianRelatedByCreatedBy relation Librarian object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   LibrarianQuery A secondary query class using the current class as primary query
     */
    public function useLibrarianRelatedByCreatedByQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinLibrarianRelatedByCreatedBy($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'LibrarianRelatedByCreatedBy', 'LibrarianQuery');
    }

    /**
     * Filter the query by a related Librarian object
     *
     * @param   Librarian|PropelObjectCollection $librarian The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 IllRequestQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByLibrarianRelatedByModifiedBy($librarian, $comparison = null)
    {
        if ($librarian instanceof Librarian) {
            return $this
                ->addUsingAlias(IllRequestPeer::MODIFIED_BY, $librarian->getLibrarianId(), $comparison);
        } elseif ($librarian instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(IllRequestPeer::MODIFIED_BY, $librarian->toKeyValue('PrimaryKey', 'LibrarianId'), $comparison);
        } else {
            throw new PropelException('filterByLibrarianRelatedByModifiedBy() only accepts arguments of type Librarian or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the LibrarianRelatedByModifiedBy relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return IllRequestQuery The current query, for fluid interface
     */
    public function joinLibrarianRelatedByModifiedBy($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('LibrarianRelatedByModifiedBy');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'LibrarianRelatedByModifiedBy');
        }

        return $this;
    }

    /**
     * Use the LibrarianRelatedByModifiedBy relation Librarian object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   LibrarianQuery A secondary query class using the current class as primary query
     */
    public function useLibrarianRelatedByModifiedByQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinLibrarianRelatedByModifiedBy($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'LibrarianRelatedByModifiedBy', 'LibrarianQuery');
    }

    /**
     * Exclude object from result
     *
     * @param   IllRequest $illRequest Object to remove from the list of results
     *
     * @return IllRequestQuery The current query, for fluid interface
     */
    public function prune($illRequest = null)
    {
        if ($illRequest) {
            $this->addUsingAlias(IllRequestPeer::ILL_REQUEST_ID, $illRequest->getIllRequestId(), Criteria::NOT_EQUAL);
        }

        return $this;
    }

    // timestampable behavior

    /**
     * Filter by the latest updated
     *
     * @param      int $nbDays Maximum age of the latest update in days
     *
     * @return     IllRequestQuery The current query, for fluid interface
     */
    public function recentlyUpdated($nbDays = 7)
    {
        return $this->addUsingAlias(IllRequestPeer::DATE_UPDATED, time() - $nbDays * 24 * 60 * 60, Criteria::GREATER_EQUAL);
    }

    /**
     * Order by update date desc
     *
     * @return     IllRequestQuery The current query, for fluid interface
     */
    public function lastUpdatedFirst()
    {
        return $this->addDescendingOrderByColumn(IllRequestPeer::DATE_UPDATED);
    }

    /**
     * Order by update date asc
     *
     * @return     IllRequestQuery The current query, for fluid interface
     */
    public function firstUpdatedFirst()
    {
        return $this->addAscendingOrderByColumn(IllRequestPeer::DATE_UPDATED);
    }

    /**
     * Filter by the latest created
     *
     * @param      int $nbDays Maximum age of in days
     *
     * @return     IllRequestQuery The current query, for fluid interface
     */
    public function recentlyCreated($nbDays = 7)
    {
        return $this->addUsingAlias(IllRequestPeer::DATE_CREATED, time() - $nbDays * 24 * 60 * 60, Criteria::GREATER_EQUAL);
    }

    /**
     * Order by create date desc
     *
     * @return     IllRequestQuery The current query, for fluid interface
     */
    public function lastCreatedFirst()
    {
        return $this->addDescendingOrderByColumn(IllRequestPeer::DATE_CREATED);
    }

    /**
     * Order by create date asc
     *
     * @return     IllRequestQuery The current query, for fluid interface
     */
    public function firstCreatedFirst()
    {
        return $this->addAscendingOrderByColumn(IllRequestPeer::DATE_CREATED);
    }
}
