<?php


/**
 * Base class that represents a query for the 'item_action' table.
 *
 *
 *
 * @method ItemActionQuery orderByItemActionId($order = Criteria::ASC) Order by the item_action_id column
 * @method ItemActionQuery orderByLibraryId($order = Criteria::ASC) Order by the library_id column
 * @method ItemActionQuery orderByItemId($order = Criteria::ASC) Order by the item_id column
 * @method ItemActionQuery orderByPatronId($order = Criteria::ASC) Order by the patron_id column
 * @method ItemActionQuery orderByExternalLibraryId($order = Criteria::ASC) Order by the external_library_id column
 * @method ItemActionQuery orderByLibrarianId($order = Criteria::ASC) Order by the librarian_id column
 * @method ItemActionQuery orderByActionType($order = Criteria::ASC) Order by the action_type column
 * @method ItemActionQuery orderByActionDate($order = Criteria::ASC) Order by the action_date column
 * @method ItemActionQuery orderByFromLibraryId($order = Criteria::ASC) Order by the from_library_id column
 * @method ItemActionQuery orderByToLibraryId($order = Criteria::ASC) Order by the to_library_id column
 * @method ItemActionQuery orderByActionNote($order = Criteria::ASC) Order by the action_note column
 * @method ItemActionQuery orderByDateCreated($order = Criteria::ASC) Order by the date_created column
 * @method ItemActionQuery orderByDateUpdated($order = Criteria::ASC) Order by the date_updated column
 * @method ItemActionQuery orderByCreatedBy($order = Criteria::ASC) Order by the created_by column
 * @method ItemActionQuery orderByModifiedBy($order = Criteria::ASC) Order by the modified_by column
 *
 * @method ItemActionQuery groupByItemActionId() Group by the item_action_id column
 * @method ItemActionQuery groupByLibraryId() Group by the library_id column
 * @method ItemActionQuery groupByItemId() Group by the item_id column
 * @method ItemActionQuery groupByPatronId() Group by the patron_id column
 * @method ItemActionQuery groupByExternalLibraryId() Group by the external_library_id column
 * @method ItemActionQuery groupByLibrarianId() Group by the librarian_id column
 * @method ItemActionQuery groupByActionType() Group by the action_type column
 * @method ItemActionQuery groupByActionDate() Group by the action_date column
 * @method ItemActionQuery groupByFromLibraryId() Group by the from_library_id column
 * @method ItemActionQuery groupByToLibraryId() Group by the to_library_id column
 * @method ItemActionQuery groupByActionNote() Group by the action_note column
 * @method ItemActionQuery groupByDateCreated() Group by the date_created column
 * @method ItemActionQuery groupByDateUpdated() Group by the date_updated column
 * @method ItemActionQuery groupByCreatedBy() Group by the created_by column
 * @method ItemActionQuery groupByModifiedBy() Group by the modified_by column
 *
 * @method ItemActionQuery leftJoin($relation) Adds a LEFT JOIN clause to the query
 * @method ItemActionQuery rightJoin($relation) Adds a RIGHT JOIN clause to the query
 * @method ItemActionQuery innerJoin($relation) Adds a INNER JOIN clause to the query
 *
 * @method ItemActionQuery leftJoinLibrarianRelatedByCreatedBy($relationAlias = null) Adds a LEFT JOIN clause to the query using the LibrarianRelatedByCreatedBy relation
 * @method ItemActionQuery rightJoinLibrarianRelatedByCreatedBy($relationAlias = null) Adds a RIGHT JOIN clause to the query using the LibrarianRelatedByCreatedBy relation
 * @method ItemActionQuery innerJoinLibrarianRelatedByCreatedBy($relationAlias = null) Adds a INNER JOIN clause to the query using the LibrarianRelatedByCreatedBy relation
 *
 * @method ItemActionQuery leftJoinLibrarianRelatedByModifiedBy($relationAlias = null) Adds a LEFT JOIN clause to the query using the LibrarianRelatedByModifiedBy relation
 * @method ItemActionQuery rightJoinLibrarianRelatedByModifiedBy($relationAlias = null) Adds a RIGHT JOIN clause to the query using the LibrarianRelatedByModifiedBy relation
 * @method ItemActionQuery innerJoinLibrarianRelatedByModifiedBy($relationAlias = null) Adds a INNER JOIN clause to the query using the LibrarianRelatedByModifiedBy relation
 *
 * @method ItemActionQuery leftJoinItem($relationAlias = null) Adds a LEFT JOIN clause to the query using the Item relation
 * @method ItemActionQuery rightJoinItem($relationAlias = null) Adds a RIGHT JOIN clause to the query using the Item relation
 * @method ItemActionQuery innerJoinItem($relationAlias = null) Adds a INNER JOIN clause to the query using the Item relation
 *
 * @method ItemActionQuery leftJoinPatron($relationAlias = null) Adds a LEFT JOIN clause to the query using the Patron relation
 * @method ItemActionQuery rightJoinPatron($relationAlias = null) Adds a RIGHT JOIN clause to the query using the Patron relation
 * @method ItemActionQuery innerJoinPatron($relationAlias = null) Adds a INNER JOIN clause to the query using the Patron relation
 *
 * @method ItemActionQuery leftJoinLibraryRelatedByExternalLibraryId($relationAlias = null) Adds a LEFT JOIN clause to the query using the LibraryRelatedByExternalLibraryId relation
 * @method ItemActionQuery rightJoinLibraryRelatedByExternalLibraryId($relationAlias = null) Adds a RIGHT JOIN clause to the query using the LibraryRelatedByExternalLibraryId relation
 * @method ItemActionQuery innerJoinLibraryRelatedByExternalLibraryId($relationAlias = null) Adds a INNER JOIN clause to the query using the LibraryRelatedByExternalLibraryId relation
 *
 * @method ItemActionQuery leftJoinLibraryRelatedByLibraryId($relationAlias = null) Adds a LEFT JOIN clause to the query using the LibraryRelatedByLibraryId relation
 * @method ItemActionQuery rightJoinLibraryRelatedByLibraryId($relationAlias = null) Adds a RIGHT JOIN clause to the query using the LibraryRelatedByLibraryId relation
 * @method ItemActionQuery innerJoinLibraryRelatedByLibraryId($relationAlias = null) Adds a INNER JOIN clause to the query using the LibraryRelatedByLibraryId relation
 *
 * @method ItemActionQuery leftJoinLibraryRelatedByFromLibraryId($relationAlias = null) Adds a LEFT JOIN clause to the query using the LibraryRelatedByFromLibraryId relation
 * @method ItemActionQuery rightJoinLibraryRelatedByFromLibraryId($relationAlias = null) Adds a RIGHT JOIN clause to the query using the LibraryRelatedByFromLibraryId relation
 * @method ItemActionQuery innerJoinLibraryRelatedByFromLibraryId($relationAlias = null) Adds a INNER JOIN clause to the query using the LibraryRelatedByFromLibraryId relation
 *
 * @method ItemActionQuery leftJoinLibraryRelatedByToLibraryId($relationAlias = null) Adds a LEFT JOIN clause to the query using the LibraryRelatedByToLibraryId relation
 * @method ItemActionQuery rightJoinLibraryRelatedByToLibraryId($relationAlias = null) Adds a RIGHT JOIN clause to the query using the LibraryRelatedByToLibraryId relation
 * @method ItemActionQuery innerJoinLibraryRelatedByToLibraryId($relationAlias = null) Adds a INNER JOIN clause to the query using the LibraryRelatedByToLibraryId relation
 *
 * @method ItemAction findOne(PropelPDO $con = null) Return the first ItemAction matching the query
 * @method ItemAction findOneOrCreate(PropelPDO $con = null) Return the first ItemAction matching the query, or a new ItemAction object populated from the query conditions when no match is found
 *
 * @method ItemAction findOneByLibraryId(int $library_id) Return the first ItemAction filtered by the library_id column
 * @method ItemAction findOneByItemId(int $item_id) Return the first ItemAction filtered by the item_id column
 * @method ItemAction findOneByPatronId(int $patron_id) Return the first ItemAction filtered by the patron_id column
 * @method ItemAction findOneByExternalLibraryId(int $external_library_id) Return the first ItemAction filtered by the external_library_id column
 * @method ItemAction findOneByLibrarianId(int $librarian_id) Return the first ItemAction filtered by the librarian_id column
 * @method ItemAction findOneByActionType(string $action_type) Return the first ItemAction filtered by the action_type column
 * @method ItemAction findOneByActionDate(string $action_date) Return the first ItemAction filtered by the action_date column
 * @method ItemAction findOneByFromLibraryId(int $from_library_id) Return the first ItemAction filtered by the from_library_id column
 * @method ItemAction findOneByToLibraryId(int $to_library_id) Return the first ItemAction filtered by the to_library_id column
 * @method ItemAction findOneByActionNote(string $action_note) Return the first ItemAction filtered by the action_note column
 * @method ItemAction findOneByDateCreated(string $date_created) Return the first ItemAction filtered by the date_created column
 * @method ItemAction findOneByDateUpdated(string $date_updated) Return the first ItemAction filtered by the date_updated column
 * @method ItemAction findOneByCreatedBy(int $created_by) Return the first ItemAction filtered by the created_by column
 * @method ItemAction findOneByModifiedBy(int $modified_by) Return the first ItemAction filtered by the modified_by column
 *
 * @method array findByItemActionId(int $item_action_id) Return ItemAction objects filtered by the item_action_id column
 * @method array findByLibraryId(int $library_id) Return ItemAction objects filtered by the library_id column
 * @method array findByItemId(int $item_id) Return ItemAction objects filtered by the item_id column
 * @method array findByPatronId(int $patron_id) Return ItemAction objects filtered by the patron_id column
 * @method array findByExternalLibraryId(int $external_library_id) Return ItemAction objects filtered by the external_library_id column
 * @method array findByLibrarianId(int $librarian_id) Return ItemAction objects filtered by the librarian_id column
 * @method array findByActionType(string $action_type) Return ItemAction objects filtered by the action_type column
 * @method array findByActionDate(string $action_date) Return ItemAction objects filtered by the action_date column
 * @method array findByFromLibraryId(int $from_library_id) Return ItemAction objects filtered by the from_library_id column
 * @method array findByToLibraryId(int $to_library_id) Return ItemAction objects filtered by the to_library_id column
 * @method array findByActionNote(string $action_note) Return ItemAction objects filtered by the action_note column
 * @method array findByDateCreated(string $date_created) Return ItemAction objects filtered by the date_created column
 * @method array findByDateUpdated(string $date_updated) Return ItemAction objects filtered by the date_updated column
 * @method array findByCreatedBy(int $created_by) Return ItemAction objects filtered by the created_by column
 * @method array findByModifiedBy(int $modified_by) Return ItemAction objects filtered by the modified_by column
 *
 * @package    propel.generator.clavis.om
 */
abstract class BaseItemActionQuery extends ModelCriteria
{
    /**
     * Initializes internal state of BaseItemActionQuery object.
     *
     * @param     string $dbName The dabase name
     * @param     string $modelName The phpName of a model, e.g. 'Book'
     * @param     string $modelAlias The alias for the model in this query, e.g. 'b'
     */
    public function __construct($dbName = null, $modelName = null, $modelAlias = null)
    {
        if (null === $dbName) {
            $dbName = 'clavis';
        }
        if (null === $modelName) {
            $modelName = 'ItemAction';
        }
        parent::__construct($dbName, $modelName, $modelAlias);
    }

    /**
     * Returns a new ItemActionQuery object.
     *
     * @param     string $modelAlias The alias of a model in the query
     * @param   ItemActionQuery|Criteria $criteria Optional Criteria to build the query from
     *
     * @return ItemActionQuery
     */
    public static function create($modelAlias = null, $criteria = null)
    {
        if ($criteria instanceof ItemActionQuery) {
            return $criteria;
        }
        $query = new ItemActionQuery(null, null, $modelAlias);

        if ($criteria instanceof Criteria) {
            $query->mergeWith($criteria);
        }

        return $query;
    }

    /**
     * Find object by primary key.
     * Propel uses the instance pool to skip the database if the object exists.
     * Go fast if the query is untouched.
     *
     * <code>
     * $obj  = $c->findPk(12, $con);
     * </code>
     *
     * @param mixed $key Primary key to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return   ItemAction|ItemAction[]|mixed the result, formatted by the current formatter
     */
    public function findPk($key, $con = null)
    {
        if ($key === null) {
            return null;
        }
        if ((null !== ($obj = ItemActionPeer::getInstanceFromPool((string) $key))) && !$this->formatter) {
            // the object is already in the instance pool
            return $obj;
        }
        if ($con === null) {
            $con = Propel::getConnection(ItemActionPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        if ($this->formatter || $this->modelAlias || $this->with || $this->select
         || $this->selectColumns || $this->asColumns || $this->selectModifiers
         || $this->map || $this->having || $this->joins) {
            return $this->findPkComplex($key, $con);
        } else {
            return $this->findPkSimple($key, $con);
        }
    }

    /**
     * Alias of findPk to use instance pooling
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 ItemAction A model object, or null if the key is not found
     * @throws PropelException
     */
     public function findOneByItemActionId($key, $con = null)
     {
        return $this->findPk($key, $con);
     }

    /**
     * Find object by primary key using raw SQL to go fast.
     * Bypass doSelect() and the object formatter by using generated code.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 ItemAction A model object, or null if the key is not found
     * @throws PropelException
     */
    protected function findPkSimple($key, $con)
    {
        $sql = 'SELECT `item_action_id`, `library_id`, `item_id`, `patron_id`, `external_library_id`, `librarian_id`, `action_type`, `action_date`, `from_library_id`, `to_library_id`, `action_note`, `date_created`, `date_updated`, `created_by`, `modified_by` FROM `item_action` WHERE `item_action_id` = :p0';
        try {
            $stmt = $con->prepare($sql);
            $stmt->bindValue(':p0', $key, PDO::PARAM_INT);
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute SELECT statement [%s]', $sql), $e);
        }
        $obj = null;
        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $obj = new ItemAction();
            $obj->hydrate($row);
            ItemActionPeer::addInstanceToPool($obj, (string) $key);
        }
        $stmt->closeCursor();

        return $obj;
    }

    /**
     * Find object by primary key.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return ItemAction|ItemAction[]|mixed the result, formatted by the current formatter
     */
    protected function findPkComplex($key, $con)
    {
        // As the query uses a PK condition, no limit(1) is necessary.
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKey($key)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->formatOne($stmt);
    }

    /**
     * Find objects by primary key
     * <code>
     * $objs = $c->findPks(array(12, 56, 832), $con);
     * </code>
     * @param     array $keys Primary keys to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return PropelObjectCollection|ItemAction[]|mixed the list of results, formatted by the current formatter
     */
    public function findPks($keys, $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection($this->getDbName(), Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKeys($keys)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->format($stmt);
    }

    /**
     * Filter the query by primary key
     *
     * @param     mixed $key Primary key to use for the query
     *
     * @return ItemActionQuery The current query, for fluid interface
     */
    public function filterByPrimaryKey($key)
    {

        return $this->addUsingAlias(ItemActionPeer::ITEM_ACTION_ID, $key, Criteria::EQUAL);
    }

    /**
     * Filter the query by a list of primary keys
     *
     * @param     array $keys The list of primary key to use for the query
     *
     * @return ItemActionQuery The current query, for fluid interface
     */
    public function filterByPrimaryKeys($keys)
    {

        return $this->addUsingAlias(ItemActionPeer::ITEM_ACTION_ID, $keys, Criteria::IN);
    }

    /**
     * Filter the query on the item_action_id column
     *
     * Example usage:
     * <code>
     * $query->filterByItemActionId(1234); // WHERE item_action_id = 1234
     * $query->filterByItemActionId(array(12, 34)); // WHERE item_action_id IN (12, 34)
     * $query->filterByItemActionId(array('min' => 12)); // WHERE item_action_id >= 12
     * $query->filterByItemActionId(array('max' => 12)); // WHERE item_action_id <= 12
     * </code>
     *
     * @param     mixed $itemActionId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemActionQuery The current query, for fluid interface
     */
    public function filterByItemActionId($itemActionId = null, $comparison = null)
    {
        if (is_array($itemActionId)) {
            $useMinMax = false;
            if (isset($itemActionId['min'])) {
                $this->addUsingAlias(ItemActionPeer::ITEM_ACTION_ID, $itemActionId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($itemActionId['max'])) {
                $this->addUsingAlias(ItemActionPeer::ITEM_ACTION_ID, $itemActionId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ItemActionPeer::ITEM_ACTION_ID, $itemActionId, $comparison);
    }

    /**
     * Filter the query on the library_id column
     *
     * Example usage:
     * <code>
     * $query->filterByLibraryId(1234); // WHERE library_id = 1234
     * $query->filterByLibraryId(array(12, 34)); // WHERE library_id IN (12, 34)
     * $query->filterByLibraryId(array('min' => 12)); // WHERE library_id >= 12
     * $query->filterByLibraryId(array('max' => 12)); // WHERE library_id <= 12
     * </code>
     *
     * @see       filterByLibraryRelatedByLibraryId()
     *
     * @param     mixed $libraryId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemActionQuery The current query, for fluid interface
     */
    public function filterByLibraryId($libraryId = null, $comparison = null)
    {
        if (is_array($libraryId)) {
            $useMinMax = false;
            if (isset($libraryId['min'])) {
                $this->addUsingAlias(ItemActionPeer::LIBRARY_ID, $libraryId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($libraryId['max'])) {
                $this->addUsingAlias(ItemActionPeer::LIBRARY_ID, $libraryId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ItemActionPeer::LIBRARY_ID, $libraryId, $comparison);
    }

    /**
     * Filter the query on the item_id column
     *
     * Example usage:
     * <code>
     * $query->filterByItemId(1234); // WHERE item_id = 1234
     * $query->filterByItemId(array(12, 34)); // WHERE item_id IN (12, 34)
     * $query->filterByItemId(array('min' => 12)); // WHERE item_id >= 12
     * $query->filterByItemId(array('max' => 12)); // WHERE item_id <= 12
     * </code>
     *
     * @see       filterByItem()
     *
     * @param     mixed $itemId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemActionQuery The current query, for fluid interface
     */
    public function filterByItemId($itemId = null, $comparison = null)
    {
        if (is_array($itemId)) {
            $useMinMax = false;
            if (isset($itemId['min'])) {
                $this->addUsingAlias(ItemActionPeer::ITEM_ID, $itemId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($itemId['max'])) {
                $this->addUsingAlias(ItemActionPeer::ITEM_ID, $itemId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ItemActionPeer::ITEM_ID, $itemId, $comparison);
    }

    /**
     * Filter the query on the patron_id column
     *
     * Example usage:
     * <code>
     * $query->filterByPatronId(1234); // WHERE patron_id = 1234
     * $query->filterByPatronId(array(12, 34)); // WHERE patron_id IN (12, 34)
     * $query->filterByPatronId(array('min' => 12)); // WHERE patron_id >= 12
     * $query->filterByPatronId(array('max' => 12)); // WHERE patron_id <= 12
     * </code>
     *
     * @see       filterByPatron()
     *
     * @param     mixed $patronId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemActionQuery The current query, for fluid interface
     */
    public function filterByPatronId($patronId = null, $comparison = null)
    {
        if (is_array($patronId)) {
            $useMinMax = false;
            if (isset($patronId['min'])) {
                $this->addUsingAlias(ItemActionPeer::PATRON_ID, $patronId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($patronId['max'])) {
                $this->addUsingAlias(ItemActionPeer::PATRON_ID, $patronId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ItemActionPeer::PATRON_ID, $patronId, $comparison);
    }

    /**
     * Filter the query on the external_library_id column
     *
     * Example usage:
     * <code>
     * $query->filterByExternalLibraryId(1234); // WHERE external_library_id = 1234
     * $query->filterByExternalLibraryId(array(12, 34)); // WHERE external_library_id IN (12, 34)
     * $query->filterByExternalLibraryId(array('min' => 12)); // WHERE external_library_id >= 12
     * $query->filterByExternalLibraryId(array('max' => 12)); // WHERE external_library_id <= 12
     * </code>
     *
     * @see       filterByLibraryRelatedByExternalLibraryId()
     *
     * @param     mixed $externalLibraryId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemActionQuery The current query, for fluid interface
     */
    public function filterByExternalLibraryId($externalLibraryId = null, $comparison = null)
    {
        if (is_array($externalLibraryId)) {
            $useMinMax = false;
            if (isset($externalLibraryId['min'])) {
                $this->addUsingAlias(ItemActionPeer::EXTERNAL_LIBRARY_ID, $externalLibraryId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($externalLibraryId['max'])) {
                $this->addUsingAlias(ItemActionPeer::EXTERNAL_LIBRARY_ID, $externalLibraryId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ItemActionPeer::EXTERNAL_LIBRARY_ID, $externalLibraryId, $comparison);
    }

    /**
     * Filter the query on the librarian_id column
     *
     * Example usage:
     * <code>
     * $query->filterByLibrarianId(1234); // WHERE librarian_id = 1234
     * $query->filterByLibrarianId(array(12, 34)); // WHERE librarian_id IN (12, 34)
     * $query->filterByLibrarianId(array('min' => 12)); // WHERE librarian_id >= 12
     * $query->filterByLibrarianId(array('max' => 12)); // WHERE librarian_id <= 12
     * </code>
     *
     * @param     mixed $librarianId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemActionQuery The current query, for fluid interface
     */
    public function filterByLibrarianId($librarianId = null, $comparison = null)
    {
        if (is_array($librarianId)) {
            $useMinMax = false;
            if (isset($librarianId['min'])) {
                $this->addUsingAlias(ItemActionPeer::LIBRARIAN_ID, $librarianId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($librarianId['max'])) {
                $this->addUsingAlias(ItemActionPeer::LIBRARIAN_ID, $librarianId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ItemActionPeer::LIBRARIAN_ID, $librarianId, $comparison);
    }

    /**
     * Filter the query on the action_type column
     *
     * Example usage:
     * <code>
     * $query->filterByActionType('fooValue');   // WHERE action_type = 'fooValue'
     * $query->filterByActionType('%fooValue%'); // WHERE action_type LIKE '%fooValue%'
     * </code>
     *
     * @param     string $actionType The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemActionQuery The current query, for fluid interface
     */
    public function filterByActionType($actionType = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($actionType)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $actionType)) {
                $actionType = str_replace('*', '%', $actionType);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(ItemActionPeer::ACTION_TYPE, $actionType, $comparison);
    }

    /**
     * Filter the query on the action_date column
     *
     * Example usage:
     * <code>
     * $query->filterByActionDate('2011-03-14'); // WHERE action_date = '2011-03-14'
     * $query->filterByActionDate('now'); // WHERE action_date = '2011-03-14'
     * $query->filterByActionDate(array('max' => 'yesterday')); // WHERE action_date < '2011-03-13'
     * </code>
     *
     * @param     mixed $actionDate The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemActionQuery The current query, for fluid interface
     */
    public function filterByActionDate($actionDate = null, $comparison = null)
    {
        if (is_array($actionDate)) {
            $useMinMax = false;
            if (isset($actionDate['min'])) {
                $this->addUsingAlias(ItemActionPeer::ACTION_DATE, $actionDate['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($actionDate['max'])) {
                $this->addUsingAlias(ItemActionPeer::ACTION_DATE, $actionDate['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ItemActionPeer::ACTION_DATE, $actionDate, $comparison);
    }

    /**
     * Filter the query on the from_library_id column
     *
     * Example usage:
     * <code>
     * $query->filterByFromLibraryId(1234); // WHERE from_library_id = 1234
     * $query->filterByFromLibraryId(array(12, 34)); // WHERE from_library_id IN (12, 34)
     * $query->filterByFromLibraryId(array('min' => 12)); // WHERE from_library_id >= 12
     * $query->filterByFromLibraryId(array('max' => 12)); // WHERE from_library_id <= 12
     * </code>
     *
     * @see       filterByLibraryRelatedByFromLibraryId()
     *
     * @param     mixed $fromLibraryId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemActionQuery The current query, for fluid interface
     */
    public function filterByFromLibraryId($fromLibraryId = null, $comparison = null)
    {
        if (is_array($fromLibraryId)) {
            $useMinMax = false;
            if (isset($fromLibraryId['min'])) {
                $this->addUsingAlias(ItemActionPeer::FROM_LIBRARY_ID, $fromLibraryId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($fromLibraryId['max'])) {
                $this->addUsingAlias(ItemActionPeer::FROM_LIBRARY_ID, $fromLibraryId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ItemActionPeer::FROM_LIBRARY_ID, $fromLibraryId, $comparison);
    }

    /**
     * Filter the query on the to_library_id column
     *
     * Example usage:
     * <code>
     * $query->filterByToLibraryId(1234); // WHERE to_library_id = 1234
     * $query->filterByToLibraryId(array(12, 34)); // WHERE to_library_id IN (12, 34)
     * $query->filterByToLibraryId(array('min' => 12)); // WHERE to_library_id >= 12
     * $query->filterByToLibraryId(array('max' => 12)); // WHERE to_library_id <= 12
     * </code>
     *
     * @see       filterByLibraryRelatedByToLibraryId()
     *
     * @param     mixed $toLibraryId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemActionQuery The current query, for fluid interface
     */
    public function filterByToLibraryId($toLibraryId = null, $comparison = null)
    {
        if (is_array($toLibraryId)) {
            $useMinMax = false;
            if (isset($toLibraryId['min'])) {
                $this->addUsingAlias(ItemActionPeer::TO_LIBRARY_ID, $toLibraryId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($toLibraryId['max'])) {
                $this->addUsingAlias(ItemActionPeer::TO_LIBRARY_ID, $toLibraryId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ItemActionPeer::TO_LIBRARY_ID, $toLibraryId, $comparison);
    }

    /**
     * Filter the query on the action_note column
     *
     * Example usage:
     * <code>
     * $query->filterByActionNote('fooValue');   // WHERE action_note = 'fooValue'
     * $query->filterByActionNote('%fooValue%'); // WHERE action_note LIKE '%fooValue%'
     * </code>
     *
     * @param     string $actionNote The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemActionQuery The current query, for fluid interface
     */
    public function filterByActionNote($actionNote = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($actionNote)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $actionNote)) {
                $actionNote = str_replace('*', '%', $actionNote);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(ItemActionPeer::ACTION_NOTE, $actionNote, $comparison);
    }

    /**
     * Filter the query on the date_created column
     *
     * Example usage:
     * <code>
     * $query->filterByDateCreated('2011-03-14'); // WHERE date_created = '2011-03-14'
     * $query->filterByDateCreated('now'); // WHERE date_created = '2011-03-14'
     * $query->filterByDateCreated(array('max' => 'yesterday')); // WHERE date_created < '2011-03-13'
     * </code>
     *
     * @param     mixed $dateCreated The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemActionQuery The current query, for fluid interface
     */
    public function filterByDateCreated($dateCreated = null, $comparison = null)
    {
        if (is_array($dateCreated)) {
            $useMinMax = false;
            if (isset($dateCreated['min'])) {
                $this->addUsingAlias(ItemActionPeer::DATE_CREATED, $dateCreated['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dateCreated['max'])) {
                $this->addUsingAlias(ItemActionPeer::DATE_CREATED, $dateCreated['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ItemActionPeer::DATE_CREATED, $dateCreated, $comparison);
    }

    /**
     * Filter the query on the date_updated column
     *
     * Example usage:
     * <code>
     * $query->filterByDateUpdated('2011-03-14'); // WHERE date_updated = '2011-03-14'
     * $query->filterByDateUpdated('now'); // WHERE date_updated = '2011-03-14'
     * $query->filterByDateUpdated(array('max' => 'yesterday')); // WHERE date_updated < '2011-03-13'
     * </code>
     *
     * @param     mixed $dateUpdated The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemActionQuery The current query, for fluid interface
     */
    public function filterByDateUpdated($dateUpdated = null, $comparison = null)
    {
        if (is_array($dateUpdated)) {
            $useMinMax = false;
            if (isset($dateUpdated['min'])) {
                $this->addUsingAlias(ItemActionPeer::DATE_UPDATED, $dateUpdated['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dateUpdated['max'])) {
                $this->addUsingAlias(ItemActionPeer::DATE_UPDATED, $dateUpdated['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ItemActionPeer::DATE_UPDATED, $dateUpdated, $comparison);
    }

    /**
     * Filter the query on the created_by column
     *
     * Example usage:
     * <code>
     * $query->filterByCreatedBy(1234); // WHERE created_by = 1234
     * $query->filterByCreatedBy(array(12, 34)); // WHERE created_by IN (12, 34)
     * $query->filterByCreatedBy(array('min' => 12)); // WHERE created_by >= 12
     * $query->filterByCreatedBy(array('max' => 12)); // WHERE created_by <= 12
     * </code>
     *
     * @see       filterByLibrarianRelatedByCreatedBy()
     *
     * @param     mixed $createdBy The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemActionQuery The current query, for fluid interface
     */
    public function filterByCreatedBy($createdBy = null, $comparison = null)
    {
        if (is_array($createdBy)) {
            $useMinMax = false;
            if (isset($createdBy['min'])) {
                $this->addUsingAlias(ItemActionPeer::CREATED_BY, $createdBy['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($createdBy['max'])) {
                $this->addUsingAlias(ItemActionPeer::CREATED_BY, $createdBy['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ItemActionPeer::CREATED_BY, $createdBy, $comparison);
    }

    /**
     * Filter the query on the modified_by column
     *
     * Example usage:
     * <code>
     * $query->filterByModifiedBy(1234); // WHERE modified_by = 1234
     * $query->filterByModifiedBy(array(12, 34)); // WHERE modified_by IN (12, 34)
     * $query->filterByModifiedBy(array('min' => 12)); // WHERE modified_by >= 12
     * $query->filterByModifiedBy(array('max' => 12)); // WHERE modified_by <= 12
     * </code>
     *
     * @see       filterByLibrarianRelatedByModifiedBy()
     *
     * @param     mixed $modifiedBy The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ItemActionQuery The current query, for fluid interface
     */
    public function filterByModifiedBy($modifiedBy = null, $comparison = null)
    {
        if (is_array($modifiedBy)) {
            $useMinMax = false;
            if (isset($modifiedBy['min'])) {
                $this->addUsingAlias(ItemActionPeer::MODIFIED_BY, $modifiedBy['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($modifiedBy['max'])) {
                $this->addUsingAlias(ItemActionPeer::MODIFIED_BY, $modifiedBy['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(ItemActionPeer::MODIFIED_BY, $modifiedBy, $comparison);
    }

    /**
     * Filter the query by a related Librarian object
     *
     * @param   Librarian|PropelObjectCollection $librarian The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 ItemActionQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByLibrarianRelatedByCreatedBy($librarian, $comparison = null)
    {
        if ($librarian instanceof Librarian) {
            return $this
                ->addUsingAlias(ItemActionPeer::CREATED_BY, $librarian->getLibrarianId(), $comparison);
        } elseif ($librarian instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(ItemActionPeer::CREATED_BY, $librarian->toKeyValue('PrimaryKey', 'LibrarianId'), $comparison);
        } else {
            throw new PropelException('filterByLibrarianRelatedByCreatedBy() only accepts arguments of type Librarian or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the LibrarianRelatedByCreatedBy relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return ItemActionQuery The current query, for fluid interface
     */
    public function joinLibrarianRelatedByCreatedBy($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('LibrarianRelatedByCreatedBy');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'LibrarianRelatedByCreatedBy');
        }

        return $this;
    }

    /**
     * Use the LibrarianRelatedByCreatedBy relation Librarian object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   LibrarianQuery A secondary query class using the current class as primary query
     */
    public function useLibrarianRelatedByCreatedByQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinLibrarianRelatedByCreatedBy($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'LibrarianRelatedByCreatedBy', 'LibrarianQuery');
    }

    /**
     * Filter the query by a related Librarian object
     *
     * @param   Librarian|PropelObjectCollection $librarian The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 ItemActionQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByLibrarianRelatedByModifiedBy($librarian, $comparison = null)
    {
        if ($librarian instanceof Librarian) {
            return $this
                ->addUsingAlias(ItemActionPeer::MODIFIED_BY, $librarian->getLibrarianId(), $comparison);
        } elseif ($librarian instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(ItemActionPeer::MODIFIED_BY, $librarian->toKeyValue('PrimaryKey', 'LibrarianId'), $comparison);
        } else {
            throw new PropelException('filterByLibrarianRelatedByModifiedBy() only accepts arguments of type Librarian or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the LibrarianRelatedByModifiedBy relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return ItemActionQuery The current query, for fluid interface
     */
    public function joinLibrarianRelatedByModifiedBy($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('LibrarianRelatedByModifiedBy');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'LibrarianRelatedByModifiedBy');
        }

        return $this;
    }

    /**
     * Use the LibrarianRelatedByModifiedBy relation Librarian object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   LibrarianQuery A secondary query class using the current class as primary query
     */
    public function useLibrarianRelatedByModifiedByQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinLibrarianRelatedByModifiedBy($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'LibrarianRelatedByModifiedBy', 'LibrarianQuery');
    }

    /**
     * Filter the query by a related Item object
     *
     * @param   Item|PropelObjectCollection $item The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 ItemActionQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByItem($item, $comparison = null)
    {
        if ($item instanceof Item) {
            return $this
                ->addUsingAlias(ItemActionPeer::ITEM_ID, $item->getItemId(), $comparison);
        } elseif ($item instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(ItemActionPeer::ITEM_ID, $item->toKeyValue('PrimaryKey', 'ItemId'), $comparison);
        } else {
            throw new PropelException('filterByItem() only accepts arguments of type Item or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the Item relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return ItemActionQuery The current query, for fluid interface
     */
    public function joinItem($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('Item');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'Item');
        }

        return $this;
    }

    /**
     * Use the Item relation Item object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   ItemQuery A secondary query class using the current class as primary query
     */
    public function useItemQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinItem($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'Item', 'ItemQuery');
    }

    /**
     * Filter the query by a related Patron object
     *
     * @param   Patron|PropelObjectCollection $patron The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 ItemActionQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByPatron($patron, $comparison = null)
    {
        if ($patron instanceof Patron) {
            return $this
                ->addUsingAlias(ItemActionPeer::PATRON_ID, $patron->getPatronId(), $comparison);
        } elseif ($patron instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(ItemActionPeer::PATRON_ID, $patron->toKeyValue('PrimaryKey', 'PatronId'), $comparison);
        } else {
            throw new PropelException('filterByPatron() only accepts arguments of type Patron or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the Patron relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return ItemActionQuery The current query, for fluid interface
     */
    public function joinPatron($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('Patron');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'Patron');
        }

        return $this;
    }

    /**
     * Use the Patron relation Patron object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   PatronQuery A secondary query class using the current class as primary query
     */
    public function usePatronQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinPatron($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'Patron', 'PatronQuery');
    }

    /**
     * Filter the query by a related Library object
     *
     * @param   Library|PropelObjectCollection $library The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 ItemActionQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByLibraryRelatedByExternalLibraryId($library, $comparison = null)
    {
        if ($library instanceof Library) {
            return $this
                ->addUsingAlias(ItemActionPeer::EXTERNAL_LIBRARY_ID, $library->getLibraryId(), $comparison);
        } elseif ($library instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(ItemActionPeer::EXTERNAL_LIBRARY_ID, $library->toKeyValue('PrimaryKey', 'LibraryId'), $comparison);
        } else {
            throw new PropelException('filterByLibraryRelatedByExternalLibraryId() only accepts arguments of type Library or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the LibraryRelatedByExternalLibraryId relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return ItemActionQuery The current query, for fluid interface
     */
    public function joinLibraryRelatedByExternalLibraryId($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('LibraryRelatedByExternalLibraryId');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'LibraryRelatedByExternalLibraryId');
        }

        return $this;
    }

    /**
     * Use the LibraryRelatedByExternalLibraryId relation Library object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   LibraryQuery A secondary query class using the current class as primary query
     */
    public function useLibraryRelatedByExternalLibraryIdQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinLibraryRelatedByExternalLibraryId($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'LibraryRelatedByExternalLibraryId', 'LibraryQuery');
    }

    /**
     * Filter the query by a related Library object
     *
     * @param   Library|PropelObjectCollection $library The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 ItemActionQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByLibraryRelatedByLibraryId($library, $comparison = null)
    {
        if ($library instanceof Library) {
            return $this
                ->addUsingAlias(ItemActionPeer::LIBRARY_ID, $library->getLibraryId(), $comparison);
        } elseif ($library instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(ItemActionPeer::LIBRARY_ID, $library->toKeyValue('PrimaryKey', 'LibraryId'), $comparison);
        } else {
            throw new PropelException('filterByLibraryRelatedByLibraryId() only accepts arguments of type Library or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the LibraryRelatedByLibraryId relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return ItemActionQuery The current query, for fluid interface
     */
    public function joinLibraryRelatedByLibraryId($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('LibraryRelatedByLibraryId');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'LibraryRelatedByLibraryId');
        }

        return $this;
    }

    /**
     * Use the LibraryRelatedByLibraryId relation Library object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   LibraryQuery A secondary query class using the current class as primary query
     */
    public function useLibraryRelatedByLibraryIdQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinLibraryRelatedByLibraryId($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'LibraryRelatedByLibraryId', 'LibraryQuery');
    }

    /**
     * Filter the query by a related Library object
     *
     * @param   Library|PropelObjectCollection $library The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 ItemActionQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByLibraryRelatedByFromLibraryId($library, $comparison = null)
    {
        if ($library instanceof Library) {
            return $this
                ->addUsingAlias(ItemActionPeer::FROM_LIBRARY_ID, $library->getLibraryId(), $comparison);
        } elseif ($library instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(ItemActionPeer::FROM_LIBRARY_ID, $library->toKeyValue('PrimaryKey', 'LibraryId'), $comparison);
        } else {
            throw new PropelException('filterByLibraryRelatedByFromLibraryId() only accepts arguments of type Library or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the LibraryRelatedByFromLibraryId relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return ItemActionQuery The current query, for fluid interface
     */
    public function joinLibraryRelatedByFromLibraryId($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('LibraryRelatedByFromLibraryId');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'LibraryRelatedByFromLibraryId');
        }

        return $this;
    }

    /**
     * Use the LibraryRelatedByFromLibraryId relation Library object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   LibraryQuery A secondary query class using the current class as primary query
     */
    public function useLibraryRelatedByFromLibraryIdQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinLibraryRelatedByFromLibraryId($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'LibraryRelatedByFromLibraryId', 'LibraryQuery');
    }

    /**
     * Filter the query by a related Library object
     *
     * @param   Library|PropelObjectCollection $library The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 ItemActionQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByLibraryRelatedByToLibraryId($library, $comparison = null)
    {
        if ($library instanceof Library) {
            return $this
                ->addUsingAlias(ItemActionPeer::TO_LIBRARY_ID, $library->getLibraryId(), $comparison);
        } elseif ($library instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(ItemActionPeer::TO_LIBRARY_ID, $library->toKeyValue('PrimaryKey', 'LibraryId'), $comparison);
        } else {
            throw new PropelException('filterByLibraryRelatedByToLibraryId() only accepts arguments of type Library or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the LibraryRelatedByToLibraryId relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return ItemActionQuery The current query, for fluid interface
     */
    public function joinLibraryRelatedByToLibraryId($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('LibraryRelatedByToLibraryId');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'LibraryRelatedByToLibraryId');
        }

        return $this;
    }

    /**
     * Use the LibraryRelatedByToLibraryId relation Library object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   LibraryQuery A secondary query class using the current class as primary query
     */
    public function useLibraryRelatedByToLibraryIdQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinLibraryRelatedByToLibraryId($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'LibraryRelatedByToLibraryId', 'LibraryQuery');
    }

    /**
     * Exclude object from result
     *
     * @param   ItemAction $itemAction Object to remove from the list of results
     *
     * @return ItemActionQuery The current query, for fluid interface
     */
    public function prune($itemAction = null)
    {
        if ($itemAction) {
            $this->addUsingAlias(ItemActionPeer::ITEM_ACTION_ID, $itemAction->getItemActionId(), Criteria::NOT_EQUAL);
        }

        return $this;
    }

    // timestampable behavior

    /**
     * Filter by the latest updated
     *
     * @param      int $nbDays Maximum age of the latest update in days
     *
     * @return     ItemActionQuery The current query, for fluid interface
     */
    public function recentlyUpdated($nbDays = 7)
    {
        return $this->addUsingAlias(ItemActionPeer::DATE_UPDATED, time() - $nbDays * 24 * 60 * 60, Criteria::GREATER_EQUAL);
    }

    /**
     * Order by update date desc
     *
     * @return     ItemActionQuery The current query, for fluid interface
     */
    public function lastUpdatedFirst()
    {
        return $this->addDescendingOrderByColumn(ItemActionPeer::DATE_UPDATED);
    }

    /**
     * Order by update date asc
     *
     * @return     ItemActionQuery The current query, for fluid interface
     */
    public function firstUpdatedFirst()
    {
        return $this->addAscendingOrderByColumn(ItemActionPeer::DATE_UPDATED);
    }

    /**
     * Filter by the latest created
     *
     * @param      int $nbDays Maximum age of in days
     *
     * @return     ItemActionQuery The current query, for fluid interface
     */
    public function recentlyCreated($nbDays = 7)
    {
        return $this->addUsingAlias(ItemActionPeer::DATE_CREATED, time() - $nbDays * 24 * 60 * 60, Criteria::GREATER_EQUAL);
    }

    /**
     * Order by create date desc
     *
     * @return     ItemActionQuery The current query, for fluid interface
     */
    public function lastCreatedFirst()
    {
        return $this->addDescendingOrderByColumn(ItemActionPeer::DATE_CREATED);
    }

    /**
     * Order by create date asc
     *
     * @return     ItemActionQuery The current query, for fluid interface
     */
    public function firstCreatedFirst()
    {
        return $this->addAscendingOrderByColumn(ItemActionPeer::DATE_CREATED);
    }
}
