<?php


/**
 * Base class that represents a query for the 'authority' table.
 *
 *
 *
 * @method AuthorityQuery orderByAuthorityId($order = Criteria::ASC) Order by the authority_id column
 * @method AuthorityQuery orderByNonSortText($order = Criteria::ASC) Order by the non_sort_text column
 * @method AuthorityQuery orderBySortText($order = Criteria::ASC) Order by the sort_text column
 * @method AuthorityQuery orderByFullText($order = Criteria::ASC) Order by the full_text column
 * @method AuthorityQuery orderByAuthorityType($order = Criteria::ASC) Order by the authority_type column
 * @method AuthorityQuery orderByAuthoritySubtype($order = Criteria::ASC) Order by the authority_subtype column
 * @method AuthorityQuery orderByAuthorityRectype($order = Criteria::ASC) Order by the authority_rectype column
 * @method AuthorityQuery orderByAuthorityStatus($order = Criteria::ASC) Order by the authority_status column
 * @method AuthorityQuery orderByUnimarc($order = Criteria::ASC) Order by the unimarc column
 * @method AuthorityQuery orderByExtData($order = Criteria::ASC) Order by the ext_data column
 * @method AuthorityQuery orderByAuthorityLang($order = Criteria::ASC) Order by the authority_lang column
 * @method AuthorityQuery orderByAuthorityCodlevel($order = Criteria::ASC) Order by the authority_codlevel column
 * @method AuthorityQuery orderByParentId($order = Criteria::ASC) Order by the parent_id column
 * @method AuthorityQuery orderBySubjectClass($order = Criteria::ASC) Order by the subject_class column
 * @method AuthorityQuery orderByClassCode($order = Criteria::ASC) Order by the class_code column
 * @method AuthorityQuery orderByBidSource($order = Criteria::ASC) Order by the bid_source column
 * @method AuthorityQuery orderByBid($order = Criteria::ASC) Order by the bid column
 * @method AuthorityQuery orderByLastSbnSync($order = Criteria::ASC) Order by the last_sbn_sync column
 * @method AuthorityQuery orderByDateCreated($order = Criteria::ASC) Order by the date_created column
 * @method AuthorityQuery orderByDateUpdated($order = Criteria::ASC) Order by the date_updated column
 * @method AuthorityQuery orderByCreatedBy($order = Criteria::ASC) Order by the created_by column
 * @method AuthorityQuery orderByModifiedBy($order = Criteria::ASC) Order by the modified_by column
 *
 * @method AuthorityQuery groupByAuthorityId() Group by the authority_id column
 * @method AuthorityQuery groupByNonSortText() Group by the non_sort_text column
 * @method AuthorityQuery groupBySortText() Group by the sort_text column
 * @method AuthorityQuery groupByFullText() Group by the full_text column
 * @method AuthorityQuery groupByAuthorityType() Group by the authority_type column
 * @method AuthorityQuery groupByAuthoritySubtype() Group by the authority_subtype column
 * @method AuthorityQuery groupByAuthorityRectype() Group by the authority_rectype column
 * @method AuthorityQuery groupByAuthorityStatus() Group by the authority_status column
 * @method AuthorityQuery groupByUnimarc() Group by the unimarc column
 * @method AuthorityQuery groupByExtData() Group by the ext_data column
 * @method AuthorityQuery groupByAuthorityLang() Group by the authority_lang column
 * @method AuthorityQuery groupByAuthorityCodlevel() Group by the authority_codlevel column
 * @method AuthorityQuery groupByParentId() Group by the parent_id column
 * @method AuthorityQuery groupBySubjectClass() Group by the subject_class column
 * @method AuthorityQuery groupByClassCode() Group by the class_code column
 * @method AuthorityQuery groupByBidSource() Group by the bid_source column
 * @method AuthorityQuery groupByBid() Group by the bid column
 * @method AuthorityQuery groupByLastSbnSync() Group by the last_sbn_sync column
 * @method AuthorityQuery groupByDateCreated() Group by the date_created column
 * @method AuthorityQuery groupByDateUpdated() Group by the date_updated column
 * @method AuthorityQuery groupByCreatedBy() Group by the created_by column
 * @method AuthorityQuery groupByModifiedBy() Group by the modified_by column
 *
 * @method AuthorityQuery leftJoin($relation) Adds a LEFT JOIN clause to the query
 * @method AuthorityQuery rightJoin($relation) Adds a RIGHT JOIN clause to the query
 * @method AuthorityQuery innerJoin($relation) Adds a INNER JOIN clause to the query
 *
 * @method AuthorityQuery leftJoinLibrarianRelatedByCreatedBy($relationAlias = null) Adds a LEFT JOIN clause to the query using the LibrarianRelatedByCreatedBy relation
 * @method AuthorityQuery rightJoinLibrarianRelatedByCreatedBy($relationAlias = null) Adds a RIGHT JOIN clause to the query using the LibrarianRelatedByCreatedBy relation
 * @method AuthorityQuery innerJoinLibrarianRelatedByCreatedBy($relationAlias = null) Adds a INNER JOIN clause to the query using the LibrarianRelatedByCreatedBy relation
 *
 * @method AuthorityQuery leftJoinLibrarianRelatedByModifiedBy($relationAlias = null) Adds a LEFT JOIN clause to the query using the LibrarianRelatedByModifiedBy relation
 * @method AuthorityQuery rightJoinLibrarianRelatedByModifiedBy($relationAlias = null) Adds a RIGHT JOIN clause to the query using the LibrarianRelatedByModifiedBy relation
 * @method AuthorityQuery innerJoinLibrarianRelatedByModifiedBy($relationAlias = null) Adds a INNER JOIN clause to the query using the LibrarianRelatedByModifiedBy relation
 *
 * @method AuthorityQuery leftJoinAuthorityRelatedByParentId($relationAlias = null) Adds a LEFT JOIN clause to the query using the AuthorityRelatedByParentId relation
 * @method AuthorityQuery rightJoinAuthorityRelatedByParentId($relationAlias = null) Adds a RIGHT JOIN clause to the query using the AuthorityRelatedByParentId relation
 * @method AuthorityQuery innerJoinAuthorityRelatedByParentId($relationAlias = null) Adds a INNER JOIN clause to the query using the AuthorityRelatedByParentId relation
 *
 * @method AuthorityQuery leftJoinAuthorityRelatedByAuthorityId($relationAlias = null) Adds a LEFT JOIN clause to the query using the AuthorityRelatedByAuthorityId relation
 * @method AuthorityQuery rightJoinAuthorityRelatedByAuthorityId($relationAlias = null) Adds a RIGHT JOIN clause to the query using the AuthorityRelatedByAuthorityId relation
 * @method AuthorityQuery innerJoinAuthorityRelatedByAuthorityId($relationAlias = null) Adds a INNER JOIN clause to the query using the AuthorityRelatedByAuthorityId relation
 *
 * @method AuthorityQuery leftJoinLAuthorityRelatedByAuthorityIdDown($relationAlias = null) Adds a LEFT JOIN clause to the query using the LAuthorityRelatedByAuthorityIdDown relation
 * @method AuthorityQuery rightJoinLAuthorityRelatedByAuthorityIdDown($relationAlias = null) Adds a RIGHT JOIN clause to the query using the LAuthorityRelatedByAuthorityIdDown relation
 * @method AuthorityQuery innerJoinLAuthorityRelatedByAuthorityIdDown($relationAlias = null) Adds a INNER JOIN clause to the query using the LAuthorityRelatedByAuthorityIdDown relation
 *
 * @method AuthorityQuery leftJoinLAuthorityRelatedByAuthorityIdUp($relationAlias = null) Adds a LEFT JOIN clause to the query using the LAuthorityRelatedByAuthorityIdUp relation
 * @method AuthorityQuery rightJoinLAuthorityRelatedByAuthorityIdUp($relationAlias = null) Adds a RIGHT JOIN clause to the query using the LAuthorityRelatedByAuthorityIdUp relation
 * @method AuthorityQuery innerJoinLAuthorityRelatedByAuthorityIdUp($relationAlias = null) Adds a INNER JOIN clause to the query using the LAuthorityRelatedByAuthorityIdUp relation
 *
 * @method AuthorityQuery leftJoinLAuthorityItem($relationAlias = null) Adds a LEFT JOIN clause to the query using the LAuthorityItem relation
 * @method AuthorityQuery rightJoinLAuthorityItem($relationAlias = null) Adds a RIGHT JOIN clause to the query using the LAuthorityItem relation
 * @method AuthorityQuery innerJoinLAuthorityItem($relationAlias = null) Adds a INNER JOIN clause to the query using the LAuthorityItem relation
 *
 * @method AuthorityQuery leftJoinLAuthorityManifestation($relationAlias = null) Adds a LEFT JOIN clause to the query using the LAuthorityManifestation relation
 * @method AuthorityQuery rightJoinLAuthorityManifestation($relationAlias = null) Adds a RIGHT JOIN clause to the query using the LAuthorityManifestation relation
 * @method AuthorityQuery innerJoinLAuthorityManifestation($relationAlias = null) Adds a INNER JOIN clause to the query using the LAuthorityManifestation relation
 *
 * @method AuthorityQuery leftJoinLSubjectRelatedByAuthorityId($relationAlias = null) Adds a LEFT JOIN clause to the query using the LSubjectRelatedByAuthorityId relation
 * @method AuthorityQuery rightJoinLSubjectRelatedByAuthorityId($relationAlias = null) Adds a RIGHT JOIN clause to the query using the LSubjectRelatedByAuthorityId relation
 * @method AuthorityQuery innerJoinLSubjectRelatedByAuthorityId($relationAlias = null) Adds a INNER JOIN clause to the query using the LSubjectRelatedByAuthorityId relation
 *
 * @method AuthorityQuery leftJoinLSubjectRelatedBySubjectId($relationAlias = null) Adds a LEFT JOIN clause to the query using the LSubjectRelatedBySubjectId relation
 * @method AuthorityQuery rightJoinLSubjectRelatedBySubjectId($relationAlias = null) Adds a RIGHT JOIN clause to the query using the LSubjectRelatedBySubjectId relation
 * @method AuthorityQuery innerJoinLSubjectRelatedBySubjectId($relationAlias = null) Adds a INNER JOIN clause to the query using the LSubjectRelatedBySubjectId relation
 *
 * @method AuthorityQuery leftJoinTurbomarcauthorityCache($relationAlias = null) Adds a LEFT JOIN clause to the query using the TurbomarcauthorityCache relation
 * @method AuthorityQuery rightJoinTurbomarcauthorityCache($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TurbomarcauthorityCache relation
 * @method AuthorityQuery innerJoinTurbomarcauthorityCache($relationAlias = null) Adds a INNER JOIN clause to the query using the TurbomarcauthorityCache relation
 *
 * @method Authority findOne(PropelPDO $con = null) Return the first Authority matching the query
 * @method Authority findOneOrCreate(PropelPDO $con = null) Return the first Authority matching the query, or a new Authority object populated from the query conditions when no match is found
 *
 * @method Authority findOneByNonSortText(string $non_sort_text) Return the first Authority filtered by the non_sort_text column
 * @method Authority findOneBySortText(string $sort_text) Return the first Authority filtered by the sort_text column
 * @method Authority findOneByFullText(string $full_text) Return the first Authority filtered by the full_text column
 * @method Authority findOneByAuthorityType(string $authority_type) Return the first Authority filtered by the authority_type column
 * @method Authority findOneByAuthoritySubtype(string $authority_subtype) Return the first Authority filtered by the authority_subtype column
 * @method Authority findOneByAuthorityRectype(string $authority_rectype) Return the first Authority filtered by the authority_rectype column
 * @method Authority findOneByAuthorityStatus(string $authority_status) Return the first Authority filtered by the authority_status column
 * @method Authority findOneByUnimarc(string $unimarc) Return the first Authority filtered by the unimarc column
 * @method Authority findOneByExtData(string $ext_data) Return the first Authority filtered by the ext_data column
 * @method Authority findOneByAuthorityLang(string $authority_lang) Return the first Authority filtered by the authority_lang column
 * @method Authority findOneByAuthorityCodlevel(string $authority_codlevel) Return the first Authority filtered by the authority_codlevel column
 * @method Authority findOneByParentId(int $parent_id) Return the first Authority filtered by the parent_id column
 * @method Authority findOneBySubjectClass(string $subject_class) Return the first Authority filtered by the subject_class column
 * @method Authority findOneByClassCode(string $class_code) Return the first Authority filtered by the class_code column
 * @method Authority findOneByBidSource(string $bid_source) Return the first Authority filtered by the bid_source column
 * @method Authority findOneByBid(string $bid) Return the first Authority filtered by the bid column
 * @method Authority findOneByLastSbnSync(string $last_sbn_sync) Return the first Authority filtered by the last_sbn_sync column
 * @method Authority findOneByDateCreated(string $date_created) Return the first Authority filtered by the date_created column
 * @method Authority findOneByDateUpdated(string $date_updated) Return the first Authority filtered by the date_updated column
 * @method Authority findOneByCreatedBy(int $created_by) Return the first Authority filtered by the created_by column
 * @method Authority findOneByModifiedBy(int $modified_by) Return the first Authority filtered by the modified_by column
 *
 * @method array findByAuthorityId(int $authority_id) Return Authority objects filtered by the authority_id column
 * @method array findByNonSortText(string $non_sort_text) Return Authority objects filtered by the non_sort_text column
 * @method array findBySortText(string $sort_text) Return Authority objects filtered by the sort_text column
 * @method array findByFullText(string $full_text) Return Authority objects filtered by the full_text column
 * @method array findByAuthorityType(string $authority_type) Return Authority objects filtered by the authority_type column
 * @method array findByAuthoritySubtype(string $authority_subtype) Return Authority objects filtered by the authority_subtype column
 * @method array findByAuthorityRectype(string $authority_rectype) Return Authority objects filtered by the authority_rectype column
 * @method array findByAuthorityStatus(string $authority_status) Return Authority objects filtered by the authority_status column
 * @method array findByUnimarc(string $unimarc) Return Authority objects filtered by the unimarc column
 * @method array findByExtData(string $ext_data) Return Authority objects filtered by the ext_data column
 * @method array findByAuthorityLang(string $authority_lang) Return Authority objects filtered by the authority_lang column
 * @method array findByAuthorityCodlevel(string $authority_codlevel) Return Authority objects filtered by the authority_codlevel column
 * @method array findByParentId(int $parent_id) Return Authority objects filtered by the parent_id column
 * @method array findBySubjectClass(string $subject_class) Return Authority objects filtered by the subject_class column
 * @method array findByClassCode(string $class_code) Return Authority objects filtered by the class_code column
 * @method array findByBidSource(string $bid_source) Return Authority objects filtered by the bid_source column
 * @method array findByBid(string $bid) Return Authority objects filtered by the bid column
 * @method array findByLastSbnSync(string $last_sbn_sync) Return Authority objects filtered by the last_sbn_sync column
 * @method array findByDateCreated(string $date_created) Return Authority objects filtered by the date_created column
 * @method array findByDateUpdated(string $date_updated) Return Authority objects filtered by the date_updated column
 * @method array findByCreatedBy(int $created_by) Return Authority objects filtered by the created_by column
 * @method array findByModifiedBy(int $modified_by) Return Authority objects filtered by the modified_by column
 *
 * @package    propel.generator.clavis.om
 */
abstract class BaseAuthorityQuery extends ModelCriteria
{
    /**
     * Initializes internal state of BaseAuthorityQuery object.
     *
     * @param     string $dbName The dabase name
     * @param     string $modelName The phpName of a model, e.g. 'Book'
     * @param     string $modelAlias The alias for the model in this query, e.g. 'b'
     */
    public function __construct($dbName = null, $modelName = null, $modelAlias = null)
    {
        if (null === $dbName) {
            $dbName = 'clavis';
        }
        if (null === $modelName) {
            $modelName = 'Authority';
        }
        parent::__construct($dbName, $modelName, $modelAlias);
    }

    /**
     * Returns a new AuthorityQuery object.
     *
     * @param     string $modelAlias The alias of a model in the query
     * @param   AuthorityQuery|Criteria $criteria Optional Criteria to build the query from
     *
     * @return AuthorityQuery
     */
    public static function create($modelAlias = null, $criteria = null)
    {
        if ($criteria instanceof AuthorityQuery) {
            return $criteria;
        }
        $query = new AuthorityQuery(null, null, $modelAlias);

        if ($criteria instanceof Criteria) {
            $query->mergeWith($criteria);
        }

        return $query;
    }

    /**
     * Find object by primary key.
     * Propel uses the instance pool to skip the database if the object exists.
     * Go fast if the query is untouched.
     *
     * <code>
     * $obj  = $c->findPk(12, $con);
     * </code>
     *
     * @param mixed $key Primary key to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return   Authority|Authority[]|mixed the result, formatted by the current formatter
     */
    public function findPk($key, $con = null)
    {
        if ($key === null) {
            return null;
        }
        if ((null !== ($obj = AuthorityPeer::getInstanceFromPool((string) $key))) && !$this->formatter) {
            // the object is already in the instance pool
            return $obj;
        }
        if ($con === null) {
            $con = Propel::getConnection(AuthorityPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        if ($this->formatter || $this->modelAlias || $this->with || $this->select
         || $this->selectColumns || $this->asColumns || $this->selectModifiers
         || $this->map || $this->having || $this->joins) {
            return $this->findPkComplex($key, $con);
        } else {
            return $this->findPkSimple($key, $con);
        }
    }

    /**
     * Alias of findPk to use instance pooling
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 Authority A model object, or null if the key is not found
     * @throws PropelException
     */
     public function findOneByAuthorityId($key, $con = null)
     {
        return $this->findPk($key, $con);
     }

    /**
     * Find object by primary key using raw SQL to go fast.
     * Bypass doSelect() and the object formatter by using generated code.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 Authority A model object, or null if the key is not found
     * @throws PropelException
     */
    protected function findPkSimple($key, $con)
    {
        $sql = 'SELECT `authority_id`, `non_sort_text`, `sort_text`, `full_text`, `authority_type`, `authority_subtype`, `authority_rectype`, `authority_status`, `unimarc`, `ext_data`, `authority_lang`, `authority_codlevel`, `parent_id`, `subject_class`, `class_code`, `bid_source`, `bid`, `last_sbn_sync`, `date_created`, `date_updated`, `created_by`, `modified_by` FROM `authority` WHERE `authority_id` = :p0';
        try {
            $stmt = $con->prepare($sql);
            $stmt->bindValue(':p0', $key, PDO::PARAM_INT);
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute SELECT statement [%s]', $sql), $e);
        }
        $obj = null;
        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $obj = new Authority();
            $obj->hydrate($row);
            AuthorityPeer::addInstanceToPool($obj, (string) $key);
        }
        $stmt->closeCursor();

        return $obj;
    }

    /**
     * Find object by primary key.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return Authority|Authority[]|mixed the result, formatted by the current formatter
     */
    protected function findPkComplex($key, $con)
    {
        // As the query uses a PK condition, no limit(1) is necessary.
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKey($key)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->formatOne($stmt);
    }

    /**
     * Find objects by primary key
     * <code>
     * $objs = $c->findPks(array(12, 56, 832), $con);
     * </code>
     * @param     array $keys Primary keys to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return PropelObjectCollection|Authority[]|mixed the list of results, formatted by the current formatter
     */
    public function findPks($keys, $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection($this->getDbName(), Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKeys($keys)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->format($stmt);
    }

    /**
     * Filter the query by primary key
     *
     * @param     mixed $key Primary key to use for the query
     *
     * @return AuthorityQuery The current query, for fluid interface
     */
    public function filterByPrimaryKey($key)
    {

        return $this->addUsingAlias(AuthorityPeer::AUTHORITY_ID, $key, Criteria::EQUAL);
    }

    /**
     * Filter the query by a list of primary keys
     *
     * @param     array $keys The list of primary key to use for the query
     *
     * @return AuthorityQuery The current query, for fluid interface
     */
    public function filterByPrimaryKeys($keys)
    {

        return $this->addUsingAlias(AuthorityPeer::AUTHORITY_ID, $keys, Criteria::IN);
    }

    /**
     * Filter the query on the authority_id column
     *
     * Example usage:
     * <code>
     * $query->filterByAuthorityId(1234); // WHERE authority_id = 1234
     * $query->filterByAuthorityId(array(12, 34)); // WHERE authority_id IN (12, 34)
     * $query->filterByAuthorityId(array('min' => 12)); // WHERE authority_id >= 12
     * $query->filterByAuthorityId(array('max' => 12)); // WHERE authority_id <= 12
     * </code>
     *
     * @param     mixed $authorityId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return AuthorityQuery The current query, for fluid interface
     */
    public function filterByAuthorityId($authorityId = null, $comparison = null)
    {
        if (is_array($authorityId)) {
            $useMinMax = false;
            if (isset($authorityId['min'])) {
                $this->addUsingAlias(AuthorityPeer::AUTHORITY_ID, $authorityId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($authorityId['max'])) {
                $this->addUsingAlias(AuthorityPeer::AUTHORITY_ID, $authorityId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(AuthorityPeer::AUTHORITY_ID, $authorityId, $comparison);
    }

    /**
     * Filter the query on the non_sort_text column
     *
     * Example usage:
     * <code>
     * $query->filterByNonSortText('fooValue');   // WHERE non_sort_text = 'fooValue'
     * $query->filterByNonSortText('%fooValue%'); // WHERE non_sort_text LIKE '%fooValue%'
     * </code>
     *
     * @param     string $nonSortText The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return AuthorityQuery The current query, for fluid interface
     */
    public function filterByNonSortText($nonSortText = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($nonSortText)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $nonSortText)) {
                $nonSortText = str_replace('*', '%', $nonSortText);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(AuthorityPeer::NON_SORT_TEXT, $nonSortText, $comparison);
    }

    /**
     * Filter the query on the sort_text column
     *
     * Example usage:
     * <code>
     * $query->filterBySortText('fooValue');   // WHERE sort_text = 'fooValue'
     * $query->filterBySortText('%fooValue%'); // WHERE sort_text LIKE '%fooValue%'
     * </code>
     *
     * @param     string $sortText The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return AuthorityQuery The current query, for fluid interface
     */
    public function filterBySortText($sortText = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($sortText)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $sortText)) {
                $sortText = str_replace('*', '%', $sortText);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(AuthorityPeer::SORT_TEXT, $sortText, $comparison);
    }

    /**
     * Filter the query on the full_text column
     *
     * Example usage:
     * <code>
     * $query->filterByFullText('fooValue');   // WHERE full_text = 'fooValue'
     * $query->filterByFullText('%fooValue%'); // WHERE full_text LIKE '%fooValue%'
     * </code>
     *
     * @param     string $fullText The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return AuthorityQuery The current query, for fluid interface
     */
    public function filterByFullText($fullText = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($fullText)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $fullText)) {
                $fullText = str_replace('*', '%', $fullText);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(AuthorityPeer::FULL_TEXT, $fullText, $comparison);
    }

    /**
     * Filter the query on the authority_type column
     *
     * Example usage:
     * <code>
     * $query->filterByAuthorityType('fooValue');   // WHERE authority_type = 'fooValue'
     * $query->filterByAuthorityType('%fooValue%'); // WHERE authority_type LIKE '%fooValue%'
     * </code>
     *
     * @param     string $authorityType The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return AuthorityQuery The current query, for fluid interface
     */
    public function filterByAuthorityType($authorityType = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($authorityType)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $authorityType)) {
                $authorityType = str_replace('*', '%', $authorityType);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(AuthorityPeer::AUTHORITY_TYPE, $authorityType, $comparison);
    }

    /**
     * Filter the query on the authority_subtype column
     *
     * Example usage:
     * <code>
     * $query->filterByAuthoritySubtype('fooValue');   // WHERE authority_subtype = 'fooValue'
     * $query->filterByAuthoritySubtype('%fooValue%'); // WHERE authority_subtype LIKE '%fooValue%'
     * </code>
     *
     * @param     string $authoritySubtype The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return AuthorityQuery The current query, for fluid interface
     */
    public function filterByAuthoritySubtype($authoritySubtype = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($authoritySubtype)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $authoritySubtype)) {
                $authoritySubtype = str_replace('*', '%', $authoritySubtype);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(AuthorityPeer::AUTHORITY_SUBTYPE, $authoritySubtype, $comparison);
    }

    /**
     * Filter the query on the authority_rectype column
     *
     * Example usage:
     * <code>
     * $query->filterByAuthorityRectype('fooValue');   // WHERE authority_rectype = 'fooValue'
     * $query->filterByAuthorityRectype('%fooValue%'); // WHERE authority_rectype LIKE '%fooValue%'
     * </code>
     *
     * @param     string $authorityRectype The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return AuthorityQuery The current query, for fluid interface
     */
    public function filterByAuthorityRectype($authorityRectype = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($authorityRectype)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $authorityRectype)) {
                $authorityRectype = str_replace('*', '%', $authorityRectype);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(AuthorityPeer::AUTHORITY_RECTYPE, $authorityRectype, $comparison);
    }

    /**
     * Filter the query on the authority_status column
     *
     * Example usage:
     * <code>
     * $query->filterByAuthorityStatus('fooValue');   // WHERE authority_status = 'fooValue'
     * $query->filterByAuthorityStatus('%fooValue%'); // WHERE authority_status LIKE '%fooValue%'
     * </code>
     *
     * @param     string $authorityStatus The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return AuthorityQuery The current query, for fluid interface
     */
    public function filterByAuthorityStatus($authorityStatus = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($authorityStatus)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $authorityStatus)) {
                $authorityStatus = str_replace('*', '%', $authorityStatus);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(AuthorityPeer::AUTHORITY_STATUS, $authorityStatus, $comparison);
    }

    /**
     * Filter the query on the unimarc column
     *
     * Example usage:
     * <code>
     * $query->filterByUnimarc('fooValue');   // WHERE unimarc = 'fooValue'
     * $query->filterByUnimarc('%fooValue%'); // WHERE unimarc LIKE '%fooValue%'
     * </code>
     *
     * @param     string $unimarc The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return AuthorityQuery The current query, for fluid interface
     */
    public function filterByUnimarc($unimarc = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($unimarc)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $unimarc)) {
                $unimarc = str_replace('*', '%', $unimarc);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(AuthorityPeer::UNIMARC, $unimarc, $comparison);
    }

    /**
     * Filter the query on the ext_data column
     *
     * Example usage:
     * <code>
     * $query->filterByExtData('fooValue');   // WHERE ext_data = 'fooValue'
     * $query->filterByExtData('%fooValue%'); // WHERE ext_data LIKE '%fooValue%'
     * </code>
     *
     * @param     string $extData The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return AuthorityQuery The current query, for fluid interface
     */
    public function filterByExtData($extData = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($extData)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $extData)) {
                $extData = str_replace('*', '%', $extData);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(AuthorityPeer::EXT_DATA, $extData, $comparison);
    }

    /**
     * Filter the query on the authority_lang column
     *
     * Example usage:
     * <code>
     * $query->filterByAuthorityLang('fooValue');   // WHERE authority_lang = 'fooValue'
     * $query->filterByAuthorityLang('%fooValue%'); // WHERE authority_lang LIKE '%fooValue%'
     * </code>
     *
     * @param     string $authorityLang The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return AuthorityQuery The current query, for fluid interface
     */
    public function filterByAuthorityLang($authorityLang = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($authorityLang)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $authorityLang)) {
                $authorityLang = str_replace('*', '%', $authorityLang);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(AuthorityPeer::AUTHORITY_LANG, $authorityLang, $comparison);
    }

    /**
     * Filter the query on the authority_codlevel column
     *
     * Example usage:
     * <code>
     * $query->filterByAuthorityCodlevel('fooValue');   // WHERE authority_codlevel = 'fooValue'
     * $query->filterByAuthorityCodlevel('%fooValue%'); // WHERE authority_codlevel LIKE '%fooValue%'
     * </code>
     *
     * @param     string $authorityCodlevel The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return AuthorityQuery The current query, for fluid interface
     */
    public function filterByAuthorityCodlevel($authorityCodlevel = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($authorityCodlevel)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $authorityCodlevel)) {
                $authorityCodlevel = str_replace('*', '%', $authorityCodlevel);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(AuthorityPeer::AUTHORITY_CODLEVEL, $authorityCodlevel, $comparison);
    }

    /**
     * Filter the query on the parent_id column
     *
     * Example usage:
     * <code>
     * $query->filterByParentId(1234); // WHERE parent_id = 1234
     * $query->filterByParentId(array(12, 34)); // WHERE parent_id IN (12, 34)
     * $query->filterByParentId(array('min' => 12)); // WHERE parent_id >= 12
     * $query->filterByParentId(array('max' => 12)); // WHERE parent_id <= 12
     * </code>
     *
     * @see       filterByAuthorityRelatedByParentId()
     *
     * @param     mixed $parentId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return AuthorityQuery The current query, for fluid interface
     */
    public function filterByParentId($parentId = null, $comparison = null)
    {
        if (is_array($parentId)) {
            $useMinMax = false;
            if (isset($parentId['min'])) {
                $this->addUsingAlias(AuthorityPeer::PARENT_ID, $parentId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($parentId['max'])) {
                $this->addUsingAlias(AuthorityPeer::PARENT_ID, $parentId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(AuthorityPeer::PARENT_ID, $parentId, $comparison);
    }

    /**
     * Filter the query on the subject_class column
     *
     * Example usage:
     * <code>
     * $query->filterBySubjectClass('fooValue');   // WHERE subject_class = 'fooValue'
     * $query->filterBySubjectClass('%fooValue%'); // WHERE subject_class LIKE '%fooValue%'
     * </code>
     *
     * @param     string $subjectClass The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return AuthorityQuery The current query, for fluid interface
     */
    public function filterBySubjectClass($subjectClass = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($subjectClass)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $subjectClass)) {
                $subjectClass = str_replace('*', '%', $subjectClass);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(AuthorityPeer::SUBJECT_CLASS, $subjectClass, $comparison);
    }

    /**
     * Filter the query on the class_code column
     *
     * Example usage:
     * <code>
     * $query->filterByClassCode('fooValue');   // WHERE class_code = 'fooValue'
     * $query->filterByClassCode('%fooValue%'); // WHERE class_code LIKE '%fooValue%'
     * </code>
     *
     * @param     string $classCode The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return AuthorityQuery The current query, for fluid interface
     */
    public function filterByClassCode($classCode = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($classCode)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $classCode)) {
                $classCode = str_replace('*', '%', $classCode);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(AuthorityPeer::CLASS_CODE, $classCode, $comparison);
    }

    /**
     * Filter the query on the bid_source column
     *
     * Example usage:
     * <code>
     * $query->filterByBidSource('fooValue');   // WHERE bid_source = 'fooValue'
     * $query->filterByBidSource('%fooValue%'); // WHERE bid_source LIKE '%fooValue%'
     * </code>
     *
     * @param     string $bidSource The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return AuthorityQuery The current query, for fluid interface
     */
    public function filterByBidSource($bidSource = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($bidSource)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $bidSource)) {
                $bidSource = str_replace('*', '%', $bidSource);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(AuthorityPeer::BID_SOURCE, $bidSource, $comparison);
    }

    /**
     * Filter the query on the bid column
     *
     * Example usage:
     * <code>
     * $query->filterByBid('fooValue');   // WHERE bid = 'fooValue'
     * $query->filterByBid('%fooValue%'); // WHERE bid LIKE '%fooValue%'
     * </code>
     *
     * @param     string $bid The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return AuthorityQuery The current query, for fluid interface
     */
    public function filterByBid($bid = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($bid)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $bid)) {
                $bid = str_replace('*', '%', $bid);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(AuthorityPeer::BID, $bid, $comparison);
    }

    /**
     * Filter the query on the last_sbn_sync column
     *
     * Example usage:
     * <code>
     * $query->filterByLastSbnSync('2011-03-14'); // WHERE last_sbn_sync = '2011-03-14'
     * $query->filterByLastSbnSync('now'); // WHERE last_sbn_sync = '2011-03-14'
     * $query->filterByLastSbnSync(array('max' => 'yesterday')); // WHERE last_sbn_sync < '2011-03-13'
     * </code>
     *
     * @param     mixed $lastSbnSync The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return AuthorityQuery The current query, for fluid interface
     */
    public function filterByLastSbnSync($lastSbnSync = null, $comparison = null)
    {
        if (is_array($lastSbnSync)) {
            $useMinMax = false;
            if (isset($lastSbnSync['min'])) {
                $this->addUsingAlias(AuthorityPeer::LAST_SBN_SYNC, $lastSbnSync['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($lastSbnSync['max'])) {
                $this->addUsingAlias(AuthorityPeer::LAST_SBN_SYNC, $lastSbnSync['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(AuthorityPeer::LAST_SBN_SYNC, $lastSbnSync, $comparison);
    }

    /**
     * Filter the query on the date_created column
     *
     * Example usage:
     * <code>
     * $query->filterByDateCreated('2011-03-14'); // WHERE date_created = '2011-03-14'
     * $query->filterByDateCreated('now'); // WHERE date_created = '2011-03-14'
     * $query->filterByDateCreated(array('max' => 'yesterday')); // WHERE date_created < '2011-03-13'
     * </code>
     *
     * @param     mixed $dateCreated The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return AuthorityQuery The current query, for fluid interface
     */
    public function filterByDateCreated($dateCreated = null, $comparison = null)
    {
        if (is_array($dateCreated)) {
            $useMinMax = false;
            if (isset($dateCreated['min'])) {
                $this->addUsingAlias(AuthorityPeer::DATE_CREATED, $dateCreated['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dateCreated['max'])) {
                $this->addUsingAlias(AuthorityPeer::DATE_CREATED, $dateCreated['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(AuthorityPeer::DATE_CREATED, $dateCreated, $comparison);
    }

    /**
     * Filter the query on the date_updated column
     *
     * Example usage:
     * <code>
     * $query->filterByDateUpdated('2011-03-14'); // WHERE date_updated = '2011-03-14'
     * $query->filterByDateUpdated('now'); // WHERE date_updated = '2011-03-14'
     * $query->filterByDateUpdated(array('max' => 'yesterday')); // WHERE date_updated < '2011-03-13'
     * </code>
     *
     * @param     mixed $dateUpdated The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return AuthorityQuery The current query, for fluid interface
     */
    public function filterByDateUpdated($dateUpdated = null, $comparison = null)
    {
        if (is_array($dateUpdated)) {
            $useMinMax = false;
            if (isset($dateUpdated['min'])) {
                $this->addUsingAlias(AuthorityPeer::DATE_UPDATED, $dateUpdated['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dateUpdated['max'])) {
                $this->addUsingAlias(AuthorityPeer::DATE_UPDATED, $dateUpdated['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(AuthorityPeer::DATE_UPDATED, $dateUpdated, $comparison);
    }

    /**
     * Filter the query on the created_by column
     *
     * Example usage:
     * <code>
     * $query->filterByCreatedBy(1234); // WHERE created_by = 1234
     * $query->filterByCreatedBy(array(12, 34)); // WHERE created_by IN (12, 34)
     * $query->filterByCreatedBy(array('min' => 12)); // WHERE created_by >= 12
     * $query->filterByCreatedBy(array('max' => 12)); // WHERE created_by <= 12
     * </code>
     *
     * @see       filterByLibrarianRelatedByCreatedBy()
     *
     * @param     mixed $createdBy The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return AuthorityQuery The current query, for fluid interface
     */
    public function filterByCreatedBy($createdBy = null, $comparison = null)
    {
        if (is_array($createdBy)) {
            $useMinMax = false;
            if (isset($createdBy['min'])) {
                $this->addUsingAlias(AuthorityPeer::CREATED_BY, $createdBy['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($createdBy['max'])) {
                $this->addUsingAlias(AuthorityPeer::CREATED_BY, $createdBy['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(AuthorityPeer::CREATED_BY, $createdBy, $comparison);
    }

    /**
     * Filter the query on the modified_by column
     *
     * Example usage:
     * <code>
     * $query->filterByModifiedBy(1234); // WHERE modified_by = 1234
     * $query->filterByModifiedBy(array(12, 34)); // WHERE modified_by IN (12, 34)
     * $query->filterByModifiedBy(array('min' => 12)); // WHERE modified_by >= 12
     * $query->filterByModifiedBy(array('max' => 12)); // WHERE modified_by <= 12
     * </code>
     *
     * @see       filterByLibrarianRelatedByModifiedBy()
     *
     * @param     mixed $modifiedBy The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return AuthorityQuery The current query, for fluid interface
     */
    public function filterByModifiedBy($modifiedBy = null, $comparison = null)
    {
        if (is_array($modifiedBy)) {
            $useMinMax = false;
            if (isset($modifiedBy['min'])) {
                $this->addUsingAlias(AuthorityPeer::MODIFIED_BY, $modifiedBy['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($modifiedBy['max'])) {
                $this->addUsingAlias(AuthorityPeer::MODIFIED_BY, $modifiedBy['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(AuthorityPeer::MODIFIED_BY, $modifiedBy, $comparison);
    }

    /**
     * Filter the query by a related Librarian object
     *
     * @param   Librarian|PropelObjectCollection $librarian The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 AuthorityQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByLibrarianRelatedByCreatedBy($librarian, $comparison = null)
    {
        if ($librarian instanceof Librarian) {
            return $this
                ->addUsingAlias(AuthorityPeer::CREATED_BY, $librarian->getLibrarianId(), $comparison);
        } elseif ($librarian instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(AuthorityPeer::CREATED_BY, $librarian->toKeyValue('PrimaryKey', 'LibrarianId'), $comparison);
        } else {
            throw new PropelException('filterByLibrarianRelatedByCreatedBy() only accepts arguments of type Librarian or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the LibrarianRelatedByCreatedBy relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return AuthorityQuery The current query, for fluid interface
     */
    public function joinLibrarianRelatedByCreatedBy($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('LibrarianRelatedByCreatedBy');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'LibrarianRelatedByCreatedBy');
        }

        return $this;
    }

    /**
     * Use the LibrarianRelatedByCreatedBy relation Librarian object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   LibrarianQuery A secondary query class using the current class as primary query
     */
    public function useLibrarianRelatedByCreatedByQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinLibrarianRelatedByCreatedBy($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'LibrarianRelatedByCreatedBy', 'LibrarianQuery');
    }

    /**
     * Filter the query by a related Librarian object
     *
     * @param   Librarian|PropelObjectCollection $librarian The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 AuthorityQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByLibrarianRelatedByModifiedBy($librarian, $comparison = null)
    {
        if ($librarian instanceof Librarian) {
            return $this
                ->addUsingAlias(AuthorityPeer::MODIFIED_BY, $librarian->getLibrarianId(), $comparison);
        } elseif ($librarian instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(AuthorityPeer::MODIFIED_BY, $librarian->toKeyValue('PrimaryKey', 'LibrarianId'), $comparison);
        } else {
            throw new PropelException('filterByLibrarianRelatedByModifiedBy() only accepts arguments of type Librarian or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the LibrarianRelatedByModifiedBy relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return AuthorityQuery The current query, for fluid interface
     */
    public function joinLibrarianRelatedByModifiedBy($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('LibrarianRelatedByModifiedBy');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'LibrarianRelatedByModifiedBy');
        }

        return $this;
    }

    /**
     * Use the LibrarianRelatedByModifiedBy relation Librarian object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   LibrarianQuery A secondary query class using the current class as primary query
     */
    public function useLibrarianRelatedByModifiedByQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinLibrarianRelatedByModifiedBy($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'LibrarianRelatedByModifiedBy', 'LibrarianQuery');
    }

    /**
     * Filter the query by a related Authority object
     *
     * @param   Authority|PropelObjectCollection $authority The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 AuthorityQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByAuthorityRelatedByParentId($authority, $comparison = null)
    {
        if ($authority instanceof Authority) {
            return $this
                ->addUsingAlias(AuthorityPeer::PARENT_ID, $authority->getAuthorityId(), $comparison);
        } elseif ($authority instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(AuthorityPeer::PARENT_ID, $authority->toKeyValue('PrimaryKey', 'AuthorityId'), $comparison);
        } else {
            throw new PropelException('filterByAuthorityRelatedByParentId() only accepts arguments of type Authority or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the AuthorityRelatedByParentId relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return AuthorityQuery The current query, for fluid interface
     */
    public function joinAuthorityRelatedByParentId($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('AuthorityRelatedByParentId');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'AuthorityRelatedByParentId');
        }

        return $this;
    }

    /**
     * Use the AuthorityRelatedByParentId relation Authority object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   AuthorityQuery A secondary query class using the current class as primary query
     */
    public function useAuthorityRelatedByParentIdQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinAuthorityRelatedByParentId($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'AuthorityRelatedByParentId', 'AuthorityQuery');
    }

    /**
     * Filter the query by a related Authority object
     *
     * @param   Authority|PropelObjectCollection $authority  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 AuthorityQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByAuthorityRelatedByAuthorityId($authority, $comparison = null)
    {
        if ($authority instanceof Authority) {
            return $this
                ->addUsingAlias(AuthorityPeer::AUTHORITY_ID, $authority->getParentId(), $comparison);
        } elseif ($authority instanceof PropelObjectCollection) {
            return $this
                ->useAuthorityRelatedByAuthorityIdQuery()
                ->filterByPrimaryKeys($authority->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByAuthorityRelatedByAuthorityId() only accepts arguments of type Authority or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the AuthorityRelatedByAuthorityId relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return AuthorityQuery The current query, for fluid interface
     */
    public function joinAuthorityRelatedByAuthorityId($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('AuthorityRelatedByAuthorityId');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'AuthorityRelatedByAuthorityId');
        }

        return $this;
    }

    /**
     * Use the AuthorityRelatedByAuthorityId relation Authority object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   AuthorityQuery A secondary query class using the current class as primary query
     */
    public function useAuthorityRelatedByAuthorityIdQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinAuthorityRelatedByAuthorityId($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'AuthorityRelatedByAuthorityId', 'AuthorityQuery');
    }

    /**
     * Filter the query by a related LAuthority object
     *
     * @param   LAuthority|PropelObjectCollection $lAuthority  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 AuthorityQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByLAuthorityRelatedByAuthorityIdDown($lAuthority, $comparison = null)
    {
        if ($lAuthority instanceof LAuthority) {
            return $this
                ->addUsingAlias(AuthorityPeer::AUTHORITY_ID, $lAuthority->getAuthorityIdDown(), $comparison);
        } elseif ($lAuthority instanceof PropelObjectCollection) {
            return $this
                ->useLAuthorityRelatedByAuthorityIdDownQuery()
                ->filterByPrimaryKeys($lAuthority->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByLAuthorityRelatedByAuthorityIdDown() only accepts arguments of type LAuthority or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the LAuthorityRelatedByAuthorityIdDown relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return AuthorityQuery The current query, for fluid interface
     */
    public function joinLAuthorityRelatedByAuthorityIdDown($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('LAuthorityRelatedByAuthorityIdDown');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'LAuthorityRelatedByAuthorityIdDown');
        }

        return $this;
    }

    /**
     * Use the LAuthorityRelatedByAuthorityIdDown relation LAuthority object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   LAuthorityQuery A secondary query class using the current class as primary query
     */
    public function useLAuthorityRelatedByAuthorityIdDownQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinLAuthorityRelatedByAuthorityIdDown($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'LAuthorityRelatedByAuthorityIdDown', 'LAuthorityQuery');
    }

    /**
     * Filter the query by a related LAuthority object
     *
     * @param   LAuthority|PropelObjectCollection $lAuthority  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 AuthorityQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByLAuthorityRelatedByAuthorityIdUp($lAuthority, $comparison = null)
    {
        if ($lAuthority instanceof LAuthority) {
            return $this
                ->addUsingAlias(AuthorityPeer::AUTHORITY_ID, $lAuthority->getAuthorityIdUp(), $comparison);
        } elseif ($lAuthority instanceof PropelObjectCollection) {
            return $this
                ->useLAuthorityRelatedByAuthorityIdUpQuery()
                ->filterByPrimaryKeys($lAuthority->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByLAuthorityRelatedByAuthorityIdUp() only accepts arguments of type LAuthority or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the LAuthorityRelatedByAuthorityIdUp relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return AuthorityQuery The current query, for fluid interface
     */
    public function joinLAuthorityRelatedByAuthorityIdUp($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('LAuthorityRelatedByAuthorityIdUp');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'LAuthorityRelatedByAuthorityIdUp');
        }

        return $this;
    }

    /**
     * Use the LAuthorityRelatedByAuthorityIdUp relation LAuthority object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   LAuthorityQuery A secondary query class using the current class as primary query
     */
    public function useLAuthorityRelatedByAuthorityIdUpQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinLAuthorityRelatedByAuthorityIdUp($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'LAuthorityRelatedByAuthorityIdUp', 'LAuthorityQuery');
    }

    /**
     * Filter the query by a related LAuthorityItem object
     *
     * @param   LAuthorityItem|PropelObjectCollection $lAuthorityItem  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 AuthorityQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByLAuthorityItem($lAuthorityItem, $comparison = null)
    {
        if ($lAuthorityItem instanceof LAuthorityItem) {
            return $this
                ->addUsingAlias(AuthorityPeer::AUTHORITY_ID, $lAuthorityItem->getAuthorityId(), $comparison);
        } elseif ($lAuthorityItem instanceof PropelObjectCollection) {
            return $this
                ->useLAuthorityItemQuery()
                ->filterByPrimaryKeys($lAuthorityItem->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByLAuthorityItem() only accepts arguments of type LAuthorityItem or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the LAuthorityItem relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return AuthorityQuery The current query, for fluid interface
     */
    public function joinLAuthorityItem($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('LAuthorityItem');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'LAuthorityItem');
        }

        return $this;
    }

    /**
     * Use the LAuthorityItem relation LAuthorityItem object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   LAuthorityItemQuery A secondary query class using the current class as primary query
     */
    public function useLAuthorityItemQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinLAuthorityItem($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'LAuthorityItem', 'LAuthorityItemQuery');
    }

    /**
     * Filter the query by a related LAuthorityManifestation object
     *
     * @param   LAuthorityManifestation|PropelObjectCollection $lAuthorityManifestation  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 AuthorityQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByLAuthorityManifestation($lAuthorityManifestation, $comparison = null)
    {
        if ($lAuthorityManifestation instanceof LAuthorityManifestation) {
            return $this
                ->addUsingAlias(AuthorityPeer::AUTHORITY_ID, $lAuthorityManifestation->getAuthorityId(), $comparison);
        } elseif ($lAuthorityManifestation instanceof PropelObjectCollection) {
            return $this
                ->useLAuthorityManifestationQuery()
                ->filterByPrimaryKeys($lAuthorityManifestation->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByLAuthorityManifestation() only accepts arguments of type LAuthorityManifestation or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the LAuthorityManifestation relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return AuthorityQuery The current query, for fluid interface
     */
    public function joinLAuthorityManifestation($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('LAuthorityManifestation');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'LAuthorityManifestation');
        }

        return $this;
    }

    /**
     * Use the LAuthorityManifestation relation LAuthorityManifestation object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   LAuthorityManifestationQuery A secondary query class using the current class as primary query
     */
    public function useLAuthorityManifestationQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinLAuthorityManifestation($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'LAuthorityManifestation', 'LAuthorityManifestationQuery');
    }

    /**
     * Filter the query by a related LSubject object
     *
     * @param   LSubject|PropelObjectCollection $lSubject  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 AuthorityQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByLSubjectRelatedByAuthorityId($lSubject, $comparison = null)
    {
        if ($lSubject instanceof LSubject) {
            return $this
                ->addUsingAlias(AuthorityPeer::AUTHORITY_ID, $lSubject->getAuthorityId(), $comparison);
        } elseif ($lSubject instanceof PropelObjectCollection) {
            return $this
                ->useLSubjectRelatedByAuthorityIdQuery()
                ->filterByPrimaryKeys($lSubject->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByLSubjectRelatedByAuthorityId() only accepts arguments of type LSubject or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the LSubjectRelatedByAuthorityId relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return AuthorityQuery The current query, for fluid interface
     */
    public function joinLSubjectRelatedByAuthorityId($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('LSubjectRelatedByAuthorityId');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'LSubjectRelatedByAuthorityId');
        }

        return $this;
    }

    /**
     * Use the LSubjectRelatedByAuthorityId relation LSubject object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   LSubjectQuery A secondary query class using the current class as primary query
     */
    public function useLSubjectRelatedByAuthorityIdQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinLSubjectRelatedByAuthorityId($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'LSubjectRelatedByAuthorityId', 'LSubjectQuery');
    }

    /**
     * Filter the query by a related LSubject object
     *
     * @param   LSubject|PropelObjectCollection $lSubject  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 AuthorityQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByLSubjectRelatedBySubjectId($lSubject, $comparison = null)
    {
        if ($lSubject instanceof LSubject) {
            return $this
                ->addUsingAlias(AuthorityPeer::AUTHORITY_ID, $lSubject->getSubjectId(), $comparison);
        } elseif ($lSubject instanceof PropelObjectCollection) {
            return $this
                ->useLSubjectRelatedBySubjectIdQuery()
                ->filterByPrimaryKeys($lSubject->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByLSubjectRelatedBySubjectId() only accepts arguments of type LSubject or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the LSubjectRelatedBySubjectId relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return AuthorityQuery The current query, for fluid interface
     */
    public function joinLSubjectRelatedBySubjectId($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('LSubjectRelatedBySubjectId');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'LSubjectRelatedBySubjectId');
        }

        return $this;
    }

    /**
     * Use the LSubjectRelatedBySubjectId relation LSubject object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   LSubjectQuery A secondary query class using the current class as primary query
     */
    public function useLSubjectRelatedBySubjectIdQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinLSubjectRelatedBySubjectId($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'LSubjectRelatedBySubjectId', 'LSubjectQuery');
    }

    /**
     * Filter the query by a related TurbomarcauthorityCache object
     *
     * @param   TurbomarcauthorityCache|PropelObjectCollection $turbomarcauthorityCache  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 AuthorityQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTurbomarcauthorityCache($turbomarcauthorityCache, $comparison = null)
    {
        if ($turbomarcauthorityCache instanceof TurbomarcauthorityCache) {
            return $this
                ->addUsingAlias(AuthorityPeer::AUTHORITY_ID, $turbomarcauthorityCache->getAuthorityId(), $comparison);
        } elseif ($turbomarcauthorityCache instanceof PropelObjectCollection) {
            return $this
                ->useTurbomarcauthorityCacheQuery()
                ->filterByPrimaryKeys($turbomarcauthorityCache->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTurbomarcauthorityCache() only accepts arguments of type TurbomarcauthorityCache or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TurbomarcauthorityCache relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return AuthorityQuery The current query, for fluid interface
     */
    public function joinTurbomarcauthorityCache($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TurbomarcauthorityCache');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TurbomarcauthorityCache');
        }

        return $this;
    }

    /**
     * Use the TurbomarcauthorityCache relation TurbomarcauthorityCache object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TurbomarcauthorityCacheQuery A secondary query class using the current class as primary query
     */
    public function useTurbomarcauthorityCacheQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinTurbomarcauthorityCache($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TurbomarcauthorityCache', 'TurbomarcauthorityCacheQuery');
    }

    /**
     * Exclude object from result
     *
     * @param   Authority $authority Object to remove from the list of results
     *
     * @return AuthorityQuery The current query, for fluid interface
     */
    public function prune($authority = null)
    {
        if ($authority) {
            $this->addUsingAlias(AuthorityPeer::AUTHORITY_ID, $authority->getAuthorityId(), Criteria::NOT_EQUAL);
        }

        return $this;
    }

    // timestampable behavior

    /**
     * Filter by the latest updated
     *
     * @param      int $nbDays Maximum age of the latest update in days
     *
     * @return     AuthorityQuery The current query, for fluid interface
     */
    public function recentlyUpdated($nbDays = 7)
    {
        return $this->addUsingAlias(AuthorityPeer::DATE_UPDATED, time() - $nbDays * 24 * 60 * 60, Criteria::GREATER_EQUAL);
    }

    /**
     * Order by update date desc
     *
     * @return     AuthorityQuery The current query, for fluid interface
     */
    public function lastUpdatedFirst()
    {
        return $this->addDescendingOrderByColumn(AuthorityPeer::DATE_UPDATED);
    }

    /**
     * Order by update date asc
     *
     * @return     AuthorityQuery The current query, for fluid interface
     */
    public function firstUpdatedFirst()
    {
        return $this->addAscendingOrderByColumn(AuthorityPeer::DATE_UPDATED);
    }

    /**
     * Filter by the latest created
     *
     * @param      int $nbDays Maximum age of in days
     *
     * @return     AuthorityQuery The current query, for fluid interface
     */
    public function recentlyCreated($nbDays = 7)
    {
        return $this->addUsingAlias(AuthorityPeer::DATE_CREATED, time() - $nbDays * 24 * 60 * 60, Criteria::GREATER_EQUAL);
    }

    /**
     * Order by create date desc
     *
     * @return     AuthorityQuery The current query, for fluid interface
     */
    public function lastCreatedFirst()
    {
        return $this->addDescendingOrderByColumn(AuthorityPeer::DATE_CREATED);
    }

    /**
     * Order by create date asc
     *
     * @return     AuthorityQuery The current query, for fluid interface
     */
    public function firstCreatedFirst()
    {
        return $this->addAscendingOrderByColumn(AuthorityPeer::DATE_CREATED);
    }
}
