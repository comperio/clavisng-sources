<?php


/**
 * Base class that represents a query for the 'issue' table.
 *
 *
 *
 * @method IssueQuery orderByIssueId($order = Criteria::ASC) Order by the issue_id column
 * @method IssueQuery orderByIssueNumber($order = Criteria::ASC) Order by the issue_number column
 * @method IssueQuery orderByStartNumber($order = Criteria::ASC) Order by the start_number column
 * @method IssueQuery orderByEndNumber($order = Criteria::ASC) Order by the end_number column
 * @method IssueQuery orderByIssueYear($order = Criteria::ASC) Order by the issue_year column
 * @method IssueQuery orderByIssueVolume($order = Criteria::ASC) Order by the issue_volume column
 * @method IssueQuery orderByIssueNote($order = Criteria::ASC) Order by the issue_note column
 * @method IssueQuery orderByIssueType($order = Criteria::ASC) Order by the issue_type column
 * @method IssueQuery orderByIssueDate($order = Criteria::ASC) Order by the issue_date column
 * @method IssueQuery orderByManifestationId($order = Criteria::ASC) Order by the manifestation_id column
 * @method IssueQuery orderByDateCreated($order = Criteria::ASC) Order by the date_created column
 * @method IssueQuery orderByDateUpdated($order = Criteria::ASC) Order by the date_updated column
 * @method IssueQuery orderByCreatedBy($order = Criteria::ASC) Order by the created_by column
 * @method IssueQuery orderByModifiedBy($order = Criteria::ASC) Order by the modified_by column
 *
 * @method IssueQuery groupByIssueId() Group by the issue_id column
 * @method IssueQuery groupByIssueNumber() Group by the issue_number column
 * @method IssueQuery groupByStartNumber() Group by the start_number column
 * @method IssueQuery groupByEndNumber() Group by the end_number column
 * @method IssueQuery groupByIssueYear() Group by the issue_year column
 * @method IssueQuery groupByIssueVolume() Group by the issue_volume column
 * @method IssueQuery groupByIssueNote() Group by the issue_note column
 * @method IssueQuery groupByIssueType() Group by the issue_type column
 * @method IssueQuery groupByIssueDate() Group by the issue_date column
 * @method IssueQuery groupByManifestationId() Group by the manifestation_id column
 * @method IssueQuery groupByDateCreated() Group by the date_created column
 * @method IssueQuery groupByDateUpdated() Group by the date_updated column
 * @method IssueQuery groupByCreatedBy() Group by the created_by column
 * @method IssueQuery groupByModifiedBy() Group by the modified_by column
 *
 * @method IssueQuery leftJoin($relation) Adds a LEFT JOIN clause to the query
 * @method IssueQuery rightJoin($relation) Adds a RIGHT JOIN clause to the query
 * @method IssueQuery innerJoin($relation) Adds a INNER JOIN clause to the query
 *
 * @method IssueQuery leftJoinLibrarianRelatedByCreatedBy($relationAlias = null) Adds a LEFT JOIN clause to the query using the LibrarianRelatedByCreatedBy relation
 * @method IssueQuery rightJoinLibrarianRelatedByCreatedBy($relationAlias = null) Adds a RIGHT JOIN clause to the query using the LibrarianRelatedByCreatedBy relation
 * @method IssueQuery innerJoinLibrarianRelatedByCreatedBy($relationAlias = null) Adds a INNER JOIN clause to the query using the LibrarianRelatedByCreatedBy relation
 *
 * @method IssueQuery leftJoinLibrarianRelatedByModifiedBy($relationAlias = null) Adds a LEFT JOIN clause to the query using the LibrarianRelatedByModifiedBy relation
 * @method IssueQuery rightJoinLibrarianRelatedByModifiedBy($relationAlias = null) Adds a RIGHT JOIN clause to the query using the LibrarianRelatedByModifiedBy relation
 * @method IssueQuery innerJoinLibrarianRelatedByModifiedBy($relationAlias = null) Adds a INNER JOIN clause to the query using the LibrarianRelatedByModifiedBy relation
 *
 * @method IssueQuery leftJoinManifestation($relationAlias = null) Adds a LEFT JOIN clause to the query using the Manifestation relation
 * @method IssueQuery rightJoinManifestation($relationAlias = null) Adds a RIGHT JOIN clause to the query using the Manifestation relation
 * @method IssueQuery innerJoinManifestation($relationAlias = null) Adds a INNER JOIN clause to the query using the Manifestation relation
 *
 * @method IssueQuery leftJoinItem($relationAlias = null) Adds a LEFT JOIN clause to the query using the Item relation
 * @method IssueQuery rightJoinItem($relationAlias = null) Adds a RIGHT JOIN clause to the query using the Item relation
 * @method IssueQuery innerJoinItem($relationAlias = null) Adds a INNER JOIN clause to the query using the Item relation
 *
 * @method IssueQuery leftJoinItemRequest($relationAlias = null) Adds a LEFT JOIN clause to the query using the ItemRequest relation
 * @method IssueQuery rightJoinItemRequest($relationAlias = null) Adds a RIGHT JOIN clause to the query using the ItemRequest relation
 * @method IssueQuery innerJoinItemRequest($relationAlias = null) Adds a INNER JOIN clause to the query using the ItemRequest relation
 *
 * @method IssueQuery leftJoinLManifestation($relationAlias = null) Adds a LEFT JOIN clause to the query using the LManifestation relation
 * @method IssueQuery rightJoinLManifestation($relationAlias = null) Adds a RIGHT JOIN clause to the query using the LManifestation relation
 * @method IssueQuery innerJoinLManifestation($relationAlias = null) Adds a INNER JOIN clause to the query using the LManifestation relation
 *
 * @method Issue findOne(PropelPDO $con = null) Return the first Issue matching the query
 * @method Issue findOneOrCreate(PropelPDO $con = null) Return the first Issue matching the query, or a new Issue object populated from the query conditions when no match is found
 *
 * @method Issue findOneByIssueNumber(string $issue_number) Return the first Issue filtered by the issue_number column
 * @method Issue findOneByStartNumber(int $start_number) Return the first Issue filtered by the start_number column
 * @method Issue findOneByEndNumber(int $end_number) Return the first Issue filtered by the end_number column
 * @method Issue findOneByIssueYear(string $issue_year) Return the first Issue filtered by the issue_year column
 * @method Issue findOneByIssueVolume(string $issue_volume) Return the first Issue filtered by the issue_volume column
 * @method Issue findOneByIssueNote(string $issue_note) Return the first Issue filtered by the issue_note column
 * @method Issue findOneByIssueType(string $issue_type) Return the first Issue filtered by the issue_type column
 * @method Issue findOneByIssueDate(string $issue_date) Return the first Issue filtered by the issue_date column
 * @method Issue findOneByManifestationId(int $manifestation_id) Return the first Issue filtered by the manifestation_id column
 * @method Issue findOneByDateCreated(string $date_created) Return the first Issue filtered by the date_created column
 * @method Issue findOneByDateUpdated(string $date_updated) Return the first Issue filtered by the date_updated column
 * @method Issue findOneByCreatedBy(int $created_by) Return the first Issue filtered by the created_by column
 * @method Issue findOneByModifiedBy(int $modified_by) Return the first Issue filtered by the modified_by column
 *
 * @method array findByIssueId(int $issue_id) Return Issue objects filtered by the issue_id column
 * @method array findByIssueNumber(string $issue_number) Return Issue objects filtered by the issue_number column
 * @method array findByStartNumber(int $start_number) Return Issue objects filtered by the start_number column
 * @method array findByEndNumber(int $end_number) Return Issue objects filtered by the end_number column
 * @method array findByIssueYear(string $issue_year) Return Issue objects filtered by the issue_year column
 * @method array findByIssueVolume(string $issue_volume) Return Issue objects filtered by the issue_volume column
 * @method array findByIssueNote(string $issue_note) Return Issue objects filtered by the issue_note column
 * @method array findByIssueType(string $issue_type) Return Issue objects filtered by the issue_type column
 * @method array findByIssueDate(string $issue_date) Return Issue objects filtered by the issue_date column
 * @method array findByManifestationId(int $manifestation_id) Return Issue objects filtered by the manifestation_id column
 * @method array findByDateCreated(string $date_created) Return Issue objects filtered by the date_created column
 * @method array findByDateUpdated(string $date_updated) Return Issue objects filtered by the date_updated column
 * @method array findByCreatedBy(int $created_by) Return Issue objects filtered by the created_by column
 * @method array findByModifiedBy(int $modified_by) Return Issue objects filtered by the modified_by column
 *
 * @package    propel.generator.clavis.om
 */
abstract class BaseIssueQuery extends ModelCriteria
{
    /**
     * Initializes internal state of BaseIssueQuery object.
     *
     * @param     string $dbName The dabase name
     * @param     string $modelName The phpName of a model, e.g. 'Book'
     * @param     string $modelAlias The alias for the model in this query, e.g. 'b'
     */
    public function __construct($dbName = null, $modelName = null, $modelAlias = null)
    {
        if (null === $dbName) {
            $dbName = 'clavis';
        }
        if (null === $modelName) {
            $modelName = 'Issue';
        }
        parent::__construct($dbName, $modelName, $modelAlias);
    }

    /**
     * Returns a new IssueQuery object.
     *
     * @param     string $modelAlias The alias of a model in the query
     * @param   IssueQuery|Criteria $criteria Optional Criteria to build the query from
     *
     * @return IssueQuery
     */
    public static function create($modelAlias = null, $criteria = null)
    {
        if ($criteria instanceof IssueQuery) {
            return $criteria;
        }
        $query = new IssueQuery(null, null, $modelAlias);

        if ($criteria instanceof Criteria) {
            $query->mergeWith($criteria);
        }

        return $query;
    }

    /**
     * Find object by primary key.
     * Propel uses the instance pool to skip the database if the object exists.
     * Go fast if the query is untouched.
     *
     * <code>
     * $obj  = $c->findPk(12, $con);
     * </code>
     *
     * @param mixed $key Primary key to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return   Issue|Issue[]|mixed the result, formatted by the current formatter
     */
    public function findPk($key, $con = null)
    {
        if ($key === null) {
            return null;
        }
        if ((null !== ($obj = IssuePeer::getInstanceFromPool((string) $key))) && !$this->formatter) {
            // the object is already in the instance pool
            return $obj;
        }
        if ($con === null) {
            $con = Propel::getConnection(IssuePeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        if ($this->formatter || $this->modelAlias || $this->with || $this->select
         || $this->selectColumns || $this->asColumns || $this->selectModifiers
         || $this->map || $this->having || $this->joins) {
            return $this->findPkComplex($key, $con);
        } else {
            return $this->findPkSimple($key, $con);
        }
    }

    /**
     * Alias of findPk to use instance pooling
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 Issue A model object, or null if the key is not found
     * @throws PropelException
     */
     public function findOneByIssueId($key, $con = null)
     {
        return $this->findPk($key, $con);
     }

    /**
     * Find object by primary key using raw SQL to go fast.
     * Bypass doSelect() and the object formatter by using generated code.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 Issue A model object, or null if the key is not found
     * @throws PropelException
     */
    protected function findPkSimple($key, $con)
    {
        $sql = 'SELECT `issue_id`, `issue_number`, `start_number`, `end_number`, `issue_year`, `issue_volume`, `issue_note`, `issue_type`, `issue_date`, `manifestation_id`, `date_created`, `date_updated`, `created_by`, `modified_by` FROM `issue` WHERE `issue_id` = :p0';
        try {
            $stmt = $con->prepare($sql);
            $stmt->bindValue(':p0', $key, PDO::PARAM_INT);
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute SELECT statement [%s]', $sql), $e);
        }
        $obj = null;
        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $obj = new Issue();
            $obj->hydrate($row);
            IssuePeer::addInstanceToPool($obj, (string) $key);
        }
        $stmt->closeCursor();

        return $obj;
    }

    /**
     * Find object by primary key.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return Issue|Issue[]|mixed the result, formatted by the current formatter
     */
    protected function findPkComplex($key, $con)
    {
        // As the query uses a PK condition, no limit(1) is necessary.
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKey($key)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->formatOne($stmt);
    }

    /**
     * Find objects by primary key
     * <code>
     * $objs = $c->findPks(array(12, 56, 832), $con);
     * </code>
     * @param     array $keys Primary keys to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return PropelObjectCollection|Issue[]|mixed the list of results, formatted by the current formatter
     */
    public function findPks($keys, $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection($this->getDbName(), Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKeys($keys)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->format($stmt);
    }

    /**
     * Filter the query by primary key
     *
     * @param     mixed $key Primary key to use for the query
     *
     * @return IssueQuery The current query, for fluid interface
     */
    public function filterByPrimaryKey($key)
    {

        return $this->addUsingAlias(IssuePeer::ISSUE_ID, $key, Criteria::EQUAL);
    }

    /**
     * Filter the query by a list of primary keys
     *
     * @param     array $keys The list of primary key to use for the query
     *
     * @return IssueQuery The current query, for fluid interface
     */
    public function filterByPrimaryKeys($keys)
    {

        return $this->addUsingAlias(IssuePeer::ISSUE_ID, $keys, Criteria::IN);
    }

    /**
     * Filter the query on the issue_id column
     *
     * Example usage:
     * <code>
     * $query->filterByIssueId(1234); // WHERE issue_id = 1234
     * $query->filterByIssueId(array(12, 34)); // WHERE issue_id IN (12, 34)
     * $query->filterByIssueId(array('min' => 12)); // WHERE issue_id >= 12
     * $query->filterByIssueId(array('max' => 12)); // WHERE issue_id <= 12
     * </code>
     *
     * @param     mixed $issueId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return IssueQuery The current query, for fluid interface
     */
    public function filterByIssueId($issueId = null, $comparison = null)
    {
        if (is_array($issueId)) {
            $useMinMax = false;
            if (isset($issueId['min'])) {
                $this->addUsingAlias(IssuePeer::ISSUE_ID, $issueId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($issueId['max'])) {
                $this->addUsingAlias(IssuePeer::ISSUE_ID, $issueId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(IssuePeer::ISSUE_ID, $issueId, $comparison);
    }

    /**
     * Filter the query on the issue_number column
     *
     * Example usage:
     * <code>
     * $query->filterByIssueNumber('fooValue');   // WHERE issue_number = 'fooValue'
     * $query->filterByIssueNumber('%fooValue%'); // WHERE issue_number LIKE '%fooValue%'
     * </code>
     *
     * @param     string $issueNumber The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return IssueQuery The current query, for fluid interface
     */
    public function filterByIssueNumber($issueNumber = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($issueNumber)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $issueNumber)) {
                $issueNumber = str_replace('*', '%', $issueNumber);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(IssuePeer::ISSUE_NUMBER, $issueNumber, $comparison);
    }

    /**
     * Filter the query on the start_number column
     *
     * Example usage:
     * <code>
     * $query->filterByStartNumber(1234); // WHERE start_number = 1234
     * $query->filterByStartNumber(array(12, 34)); // WHERE start_number IN (12, 34)
     * $query->filterByStartNumber(array('min' => 12)); // WHERE start_number >= 12
     * $query->filterByStartNumber(array('max' => 12)); // WHERE start_number <= 12
     * </code>
     *
     * @param     mixed $startNumber The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return IssueQuery The current query, for fluid interface
     */
    public function filterByStartNumber($startNumber = null, $comparison = null)
    {
        if (is_array($startNumber)) {
            $useMinMax = false;
            if (isset($startNumber['min'])) {
                $this->addUsingAlias(IssuePeer::START_NUMBER, $startNumber['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($startNumber['max'])) {
                $this->addUsingAlias(IssuePeer::START_NUMBER, $startNumber['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(IssuePeer::START_NUMBER, $startNumber, $comparison);
    }

    /**
     * Filter the query on the end_number column
     *
     * Example usage:
     * <code>
     * $query->filterByEndNumber(1234); // WHERE end_number = 1234
     * $query->filterByEndNumber(array(12, 34)); // WHERE end_number IN (12, 34)
     * $query->filterByEndNumber(array('min' => 12)); // WHERE end_number >= 12
     * $query->filterByEndNumber(array('max' => 12)); // WHERE end_number <= 12
     * </code>
     *
     * @param     mixed $endNumber The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return IssueQuery The current query, for fluid interface
     */
    public function filterByEndNumber($endNumber = null, $comparison = null)
    {
        if (is_array($endNumber)) {
            $useMinMax = false;
            if (isset($endNumber['min'])) {
                $this->addUsingAlias(IssuePeer::END_NUMBER, $endNumber['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($endNumber['max'])) {
                $this->addUsingAlias(IssuePeer::END_NUMBER, $endNumber['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(IssuePeer::END_NUMBER, $endNumber, $comparison);
    }

    /**
     * Filter the query on the issue_year column
     *
     * Example usage:
     * <code>
     * $query->filterByIssueYear('fooValue');   // WHERE issue_year = 'fooValue'
     * $query->filterByIssueYear('%fooValue%'); // WHERE issue_year LIKE '%fooValue%'
     * </code>
     *
     * @param     string $issueYear The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return IssueQuery The current query, for fluid interface
     */
    public function filterByIssueYear($issueYear = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($issueYear)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $issueYear)) {
                $issueYear = str_replace('*', '%', $issueYear);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(IssuePeer::ISSUE_YEAR, $issueYear, $comparison);
    }

    /**
     * Filter the query on the issue_volume column
     *
     * Example usage:
     * <code>
     * $query->filterByIssueVolume('fooValue');   // WHERE issue_volume = 'fooValue'
     * $query->filterByIssueVolume('%fooValue%'); // WHERE issue_volume LIKE '%fooValue%'
     * </code>
     *
     * @param     string $issueVolume The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return IssueQuery The current query, for fluid interface
     */
    public function filterByIssueVolume($issueVolume = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($issueVolume)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $issueVolume)) {
                $issueVolume = str_replace('*', '%', $issueVolume);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(IssuePeer::ISSUE_VOLUME, $issueVolume, $comparison);
    }

    /**
     * Filter the query on the issue_note column
     *
     * Example usage:
     * <code>
     * $query->filterByIssueNote('fooValue');   // WHERE issue_note = 'fooValue'
     * $query->filterByIssueNote('%fooValue%'); // WHERE issue_note LIKE '%fooValue%'
     * </code>
     *
     * @param     string $issueNote The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return IssueQuery The current query, for fluid interface
     */
    public function filterByIssueNote($issueNote = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($issueNote)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $issueNote)) {
                $issueNote = str_replace('*', '%', $issueNote);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(IssuePeer::ISSUE_NOTE, $issueNote, $comparison);
    }

    /**
     * Filter the query on the issue_type column
     *
     * Example usage:
     * <code>
     * $query->filterByIssueType('fooValue');   // WHERE issue_type = 'fooValue'
     * $query->filterByIssueType('%fooValue%'); // WHERE issue_type LIKE '%fooValue%'
     * </code>
     *
     * @param     string $issueType The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return IssueQuery The current query, for fluid interface
     */
    public function filterByIssueType($issueType = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($issueType)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $issueType)) {
                $issueType = str_replace('*', '%', $issueType);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(IssuePeer::ISSUE_TYPE, $issueType, $comparison);
    }

    /**
     * Filter the query on the issue_date column
     *
     * Example usage:
     * <code>
     * $query->filterByIssueDate('2011-03-14'); // WHERE issue_date = '2011-03-14'
     * $query->filterByIssueDate('now'); // WHERE issue_date = '2011-03-14'
     * $query->filterByIssueDate(array('max' => 'yesterday')); // WHERE issue_date < '2011-03-13'
     * </code>
     *
     * @param     mixed $issueDate The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return IssueQuery The current query, for fluid interface
     */
    public function filterByIssueDate($issueDate = null, $comparison = null)
    {
        if (is_array($issueDate)) {
            $useMinMax = false;
            if (isset($issueDate['min'])) {
                $this->addUsingAlias(IssuePeer::ISSUE_DATE, $issueDate['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($issueDate['max'])) {
                $this->addUsingAlias(IssuePeer::ISSUE_DATE, $issueDate['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(IssuePeer::ISSUE_DATE, $issueDate, $comparison);
    }

    /**
     * Filter the query on the manifestation_id column
     *
     * Example usage:
     * <code>
     * $query->filterByManifestationId(1234); // WHERE manifestation_id = 1234
     * $query->filterByManifestationId(array(12, 34)); // WHERE manifestation_id IN (12, 34)
     * $query->filterByManifestationId(array('min' => 12)); // WHERE manifestation_id >= 12
     * $query->filterByManifestationId(array('max' => 12)); // WHERE manifestation_id <= 12
     * </code>
     *
     * @see       filterByManifestation()
     *
     * @param     mixed $manifestationId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return IssueQuery The current query, for fluid interface
     */
    public function filterByManifestationId($manifestationId = null, $comparison = null)
    {
        if (is_array($manifestationId)) {
            $useMinMax = false;
            if (isset($manifestationId['min'])) {
                $this->addUsingAlias(IssuePeer::MANIFESTATION_ID, $manifestationId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($manifestationId['max'])) {
                $this->addUsingAlias(IssuePeer::MANIFESTATION_ID, $manifestationId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(IssuePeer::MANIFESTATION_ID, $manifestationId, $comparison);
    }

    /**
     * Filter the query on the date_created column
     *
     * Example usage:
     * <code>
     * $query->filterByDateCreated('2011-03-14'); // WHERE date_created = '2011-03-14'
     * $query->filterByDateCreated('now'); // WHERE date_created = '2011-03-14'
     * $query->filterByDateCreated(array('max' => 'yesterday')); // WHERE date_created < '2011-03-13'
     * </code>
     *
     * @param     mixed $dateCreated The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return IssueQuery The current query, for fluid interface
     */
    public function filterByDateCreated($dateCreated = null, $comparison = null)
    {
        if (is_array($dateCreated)) {
            $useMinMax = false;
            if (isset($dateCreated['min'])) {
                $this->addUsingAlias(IssuePeer::DATE_CREATED, $dateCreated['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dateCreated['max'])) {
                $this->addUsingAlias(IssuePeer::DATE_CREATED, $dateCreated['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(IssuePeer::DATE_CREATED, $dateCreated, $comparison);
    }

    /**
     * Filter the query on the date_updated column
     *
     * Example usage:
     * <code>
     * $query->filterByDateUpdated('2011-03-14'); // WHERE date_updated = '2011-03-14'
     * $query->filterByDateUpdated('now'); // WHERE date_updated = '2011-03-14'
     * $query->filterByDateUpdated(array('max' => 'yesterday')); // WHERE date_updated < '2011-03-13'
     * </code>
     *
     * @param     mixed $dateUpdated The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return IssueQuery The current query, for fluid interface
     */
    public function filterByDateUpdated($dateUpdated = null, $comparison = null)
    {
        if (is_array($dateUpdated)) {
            $useMinMax = false;
            if (isset($dateUpdated['min'])) {
                $this->addUsingAlias(IssuePeer::DATE_UPDATED, $dateUpdated['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dateUpdated['max'])) {
                $this->addUsingAlias(IssuePeer::DATE_UPDATED, $dateUpdated['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(IssuePeer::DATE_UPDATED, $dateUpdated, $comparison);
    }

    /**
     * Filter the query on the created_by column
     *
     * Example usage:
     * <code>
     * $query->filterByCreatedBy(1234); // WHERE created_by = 1234
     * $query->filterByCreatedBy(array(12, 34)); // WHERE created_by IN (12, 34)
     * $query->filterByCreatedBy(array('min' => 12)); // WHERE created_by >= 12
     * $query->filterByCreatedBy(array('max' => 12)); // WHERE created_by <= 12
     * </code>
     *
     * @see       filterByLibrarianRelatedByCreatedBy()
     *
     * @param     mixed $createdBy The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return IssueQuery The current query, for fluid interface
     */
    public function filterByCreatedBy($createdBy = null, $comparison = null)
    {
        if (is_array($createdBy)) {
            $useMinMax = false;
            if (isset($createdBy['min'])) {
                $this->addUsingAlias(IssuePeer::CREATED_BY, $createdBy['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($createdBy['max'])) {
                $this->addUsingAlias(IssuePeer::CREATED_BY, $createdBy['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(IssuePeer::CREATED_BY, $createdBy, $comparison);
    }

    /**
     * Filter the query on the modified_by column
     *
     * Example usage:
     * <code>
     * $query->filterByModifiedBy(1234); // WHERE modified_by = 1234
     * $query->filterByModifiedBy(array(12, 34)); // WHERE modified_by IN (12, 34)
     * $query->filterByModifiedBy(array('min' => 12)); // WHERE modified_by >= 12
     * $query->filterByModifiedBy(array('max' => 12)); // WHERE modified_by <= 12
     * </code>
     *
     * @see       filterByLibrarianRelatedByModifiedBy()
     *
     * @param     mixed $modifiedBy The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return IssueQuery The current query, for fluid interface
     */
    public function filterByModifiedBy($modifiedBy = null, $comparison = null)
    {
        if (is_array($modifiedBy)) {
            $useMinMax = false;
            if (isset($modifiedBy['min'])) {
                $this->addUsingAlias(IssuePeer::MODIFIED_BY, $modifiedBy['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($modifiedBy['max'])) {
                $this->addUsingAlias(IssuePeer::MODIFIED_BY, $modifiedBy['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(IssuePeer::MODIFIED_BY, $modifiedBy, $comparison);
    }

    /**
     * Filter the query by a related Librarian object
     *
     * @param   Librarian|PropelObjectCollection $librarian The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 IssueQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByLibrarianRelatedByCreatedBy($librarian, $comparison = null)
    {
        if ($librarian instanceof Librarian) {
            return $this
                ->addUsingAlias(IssuePeer::CREATED_BY, $librarian->getLibrarianId(), $comparison);
        } elseif ($librarian instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(IssuePeer::CREATED_BY, $librarian->toKeyValue('PrimaryKey', 'LibrarianId'), $comparison);
        } else {
            throw new PropelException('filterByLibrarianRelatedByCreatedBy() only accepts arguments of type Librarian or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the LibrarianRelatedByCreatedBy relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return IssueQuery The current query, for fluid interface
     */
    public function joinLibrarianRelatedByCreatedBy($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('LibrarianRelatedByCreatedBy');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'LibrarianRelatedByCreatedBy');
        }

        return $this;
    }

    /**
     * Use the LibrarianRelatedByCreatedBy relation Librarian object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   LibrarianQuery A secondary query class using the current class as primary query
     */
    public function useLibrarianRelatedByCreatedByQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinLibrarianRelatedByCreatedBy($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'LibrarianRelatedByCreatedBy', 'LibrarianQuery');
    }

    /**
     * Filter the query by a related Librarian object
     *
     * @param   Librarian|PropelObjectCollection $librarian The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 IssueQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByLibrarianRelatedByModifiedBy($librarian, $comparison = null)
    {
        if ($librarian instanceof Librarian) {
            return $this
                ->addUsingAlias(IssuePeer::MODIFIED_BY, $librarian->getLibrarianId(), $comparison);
        } elseif ($librarian instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(IssuePeer::MODIFIED_BY, $librarian->toKeyValue('PrimaryKey', 'LibrarianId'), $comparison);
        } else {
            throw new PropelException('filterByLibrarianRelatedByModifiedBy() only accepts arguments of type Librarian or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the LibrarianRelatedByModifiedBy relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return IssueQuery The current query, for fluid interface
     */
    public function joinLibrarianRelatedByModifiedBy($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('LibrarianRelatedByModifiedBy');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'LibrarianRelatedByModifiedBy');
        }

        return $this;
    }

    /**
     * Use the LibrarianRelatedByModifiedBy relation Librarian object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   LibrarianQuery A secondary query class using the current class as primary query
     */
    public function useLibrarianRelatedByModifiedByQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinLibrarianRelatedByModifiedBy($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'LibrarianRelatedByModifiedBy', 'LibrarianQuery');
    }

    /**
     * Filter the query by a related Manifestation object
     *
     * @param   Manifestation|PropelObjectCollection $manifestation The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 IssueQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByManifestation($manifestation, $comparison = null)
    {
        if ($manifestation instanceof Manifestation) {
            return $this
                ->addUsingAlias(IssuePeer::MANIFESTATION_ID, $manifestation->getManifestationId(), $comparison);
        } elseif ($manifestation instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(IssuePeer::MANIFESTATION_ID, $manifestation->toKeyValue('PrimaryKey', 'ManifestationId'), $comparison);
        } else {
            throw new PropelException('filterByManifestation() only accepts arguments of type Manifestation or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the Manifestation relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return IssueQuery The current query, for fluid interface
     */
    public function joinManifestation($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('Manifestation');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'Manifestation');
        }

        return $this;
    }

    /**
     * Use the Manifestation relation Manifestation object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   ManifestationQuery A secondary query class using the current class as primary query
     */
    public function useManifestationQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinManifestation($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'Manifestation', 'ManifestationQuery');
    }

    /**
     * Filter the query by a related Item object
     *
     * @param   Item|PropelObjectCollection $item  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 IssueQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByItem($item, $comparison = null)
    {
        if ($item instanceof Item) {
            return $this
                ->addUsingAlias(IssuePeer::ISSUE_ID, $item->getIssueId(), $comparison);
        } elseif ($item instanceof PropelObjectCollection) {
            return $this
                ->useItemQuery()
                ->filterByPrimaryKeys($item->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByItem() only accepts arguments of type Item or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the Item relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return IssueQuery The current query, for fluid interface
     */
    public function joinItem($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('Item');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'Item');
        }

        return $this;
    }

    /**
     * Use the Item relation Item object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   ItemQuery A secondary query class using the current class as primary query
     */
    public function useItemQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinItem($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'Item', 'ItemQuery');
    }

    /**
     * Filter the query by a related ItemRequest object
     *
     * @param   ItemRequest|PropelObjectCollection $itemRequest  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 IssueQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByItemRequest($itemRequest, $comparison = null)
    {
        if ($itemRequest instanceof ItemRequest) {
            return $this
                ->addUsingAlias(IssuePeer::ISSUE_ID, $itemRequest->getIssueId(), $comparison);
        } elseif ($itemRequest instanceof PropelObjectCollection) {
            return $this
                ->useItemRequestQuery()
                ->filterByPrimaryKeys($itemRequest->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByItemRequest() only accepts arguments of type ItemRequest or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the ItemRequest relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return IssueQuery The current query, for fluid interface
     */
    public function joinItemRequest($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('ItemRequest');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'ItemRequest');
        }

        return $this;
    }

    /**
     * Use the ItemRequest relation ItemRequest object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   ItemRequestQuery A secondary query class using the current class as primary query
     */
    public function useItemRequestQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinItemRequest($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'ItemRequest', 'ItemRequestQuery');
    }

    /**
     * Filter the query by a related LManifestation object
     *
     * @param   LManifestation|PropelObjectCollection $lManifestation  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 IssueQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByLManifestation($lManifestation, $comparison = null)
    {
        if ($lManifestation instanceof LManifestation) {
            return $this
                ->addUsingAlias(IssuePeer::ISSUE_ID, $lManifestation->getIssueId(), $comparison);
        } elseif ($lManifestation instanceof PropelObjectCollection) {
            return $this
                ->useLManifestationQuery()
                ->filterByPrimaryKeys($lManifestation->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByLManifestation() only accepts arguments of type LManifestation or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the LManifestation relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return IssueQuery The current query, for fluid interface
     */
    public function joinLManifestation($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('LManifestation');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'LManifestation');
        }

        return $this;
    }

    /**
     * Use the LManifestation relation LManifestation object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   LManifestationQuery A secondary query class using the current class as primary query
     */
    public function useLManifestationQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinLManifestation($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'LManifestation', 'LManifestationQuery');
    }

    /**
     * Exclude object from result
     *
     * @param   Issue $issue Object to remove from the list of results
     *
     * @return IssueQuery The current query, for fluid interface
     */
    public function prune($issue = null)
    {
        if ($issue) {
            $this->addUsingAlias(IssuePeer::ISSUE_ID, $issue->getIssueId(), Criteria::NOT_EQUAL);
        }

        return $this;
    }

    // timestampable behavior

    /**
     * Filter by the latest updated
     *
     * @param      int $nbDays Maximum age of the latest update in days
     *
     * @return     IssueQuery The current query, for fluid interface
     */
    public function recentlyUpdated($nbDays = 7)
    {
        return $this->addUsingAlias(IssuePeer::DATE_UPDATED, time() - $nbDays * 24 * 60 * 60, Criteria::GREATER_EQUAL);
    }

    /**
     * Order by update date desc
     *
     * @return     IssueQuery The current query, for fluid interface
     */
    public function lastUpdatedFirst()
    {
        return $this->addDescendingOrderByColumn(IssuePeer::DATE_UPDATED);
    }

    /**
     * Order by update date asc
     *
     * @return     IssueQuery The current query, for fluid interface
     */
    public function firstUpdatedFirst()
    {
        return $this->addAscendingOrderByColumn(IssuePeer::DATE_UPDATED);
    }

    /**
     * Filter by the latest created
     *
     * @param      int $nbDays Maximum age of in days
     *
     * @return     IssueQuery The current query, for fluid interface
     */
    public function recentlyCreated($nbDays = 7)
    {
        return $this->addUsingAlias(IssuePeer::DATE_CREATED, time() - $nbDays * 24 * 60 * 60, Criteria::GREATER_EQUAL);
    }

    /**
     * Order by create date desc
     *
     * @return     IssueQuery The current query, for fluid interface
     */
    public function lastCreatedFirst()
    {
        return $this->addDescendingOrderByColumn(IssuePeer::DATE_CREATED);
    }

    /**
     * Order by create date asc
     *
     * @return     IssueQuery The current query, for fluid interface
     */
    public function firstCreatedFirst()
    {
        return $this->addAscendingOrderByColumn(IssuePeer::DATE_CREATED);
    }
}
